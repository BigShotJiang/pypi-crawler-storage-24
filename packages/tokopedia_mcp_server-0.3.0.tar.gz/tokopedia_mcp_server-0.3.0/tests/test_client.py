"""Tests for tokopedia_mcp.client — all bug fixes from HAR analysis."""

from __future__ import annotations

import base64
import json
import os
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from tokopedia_mcp import client as tokopedia


def _mock_post(data: dict, *, status: int = 200):
    async def fake_post(url, **kwargs):
        resp = MagicMock()
        resp.status_code = status
        resp.raise_for_status = MagicMock()
        resp.json.return_value = [{"data": data}]
        return resp
    return fake_post


def _mock_session(post_fn):
    s = AsyncMock()
    s.__aenter__ = AsyncMock(return_value=s)
    s.__aexit__ = AsyncMock(return_value=None)
    s.post = post_fn
    return s


def _mock_http_session(*, get_fn=None, post_fn=None):
    s = AsyncMock()
    s.__aenter__ = AsyncMock(return_value=s)
    s.__aexit__ = AsyncMock(return_value=None)
    if get_fn is not None:
        s.get = get_fn
    if post_fn is not None:
        s.post = post_fn
    return s


# ---------------------------------------------------------------------------
# CRITICAL: GQL URL must include operation name in path
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_gql_url_includes_operation_name():
    """URL must be /graphql/{OperationName}, NOT just /graphql/ or /."""
    captured_url = {}

    async def fake_post(url, **kwargs):
        captured_url["url"] = url
        resp = MagicMock()
        resp.status_code = 200
        resp.raise_for_status = MagicMock()
        resp.json.return_value = [{"data": {"searchProductV5": {"header": {"totalData": 0}, "data": {"products": []}}}}]
        return resp

    with patch("tokopedia_mcp.client._make_session", return_value=_mock_session(fake_post)):
        await tokopedia.search_products("usb hub")

    assert captured_url["url"].endswith("/SearchProductV5Query"), (
        f"URL must end with /SearchProductV5Query, got: {captured_url['url']}"
    )
    assert "gql.tokopedia.com/graphql/" in captured_url["url"]


# ---------------------------------------------------------------------------
# CRITICAL: payload must be a JSON array
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_gql_sends_array_payload():
    captured = {}

    async def fake_post(url, **kwargs):
        captured["json"] = kwargs.get("json")
        resp = MagicMock()
        resp.status_code = 200
        resp.raise_for_status = MagicMock()
        resp.json.return_value = [{"data": {"searchProductV5": {"header": {"totalData": 0}, "data": {"products": []}}}}]
        return resp

    with patch("tokopedia_mcp.client._make_session", return_value=_mock_session(fake_post)):
        await tokopedia.search_products("usb hub")

    assert isinstance(captured["json"], list), "Payload must be a JSON array"
    assert len(captured["json"]) == 1
    assert "operationName" in captured["json"][0]


# ---------------------------------------------------------------------------
# CRITICAL: search uses searchProductV5, not ace_search_product_v4
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_search_uses_v5_api():
    captured = {}

    async def fake_post(url, **kwargs):
        captured["body"] = kwargs.get("json", [{}])
        resp = MagicMock()
        resp.status_code = 200
        resp.raise_for_status = MagicMock()
        resp.json.return_value = [{"data": {"searchProductV5": {"header": {"totalData": 5}, "data": {"products": [
            {"id": "1", "id_str_auto_": "1", "name": "USB Hub", "url": "https://tok.com/shop/hub",
             "mediaURL": {"image": "img.jpg"}, "shop": {"name": "Shop", "city": "JKT", "tier": 2},
             "price": {"text": "Rp50.000", "number": 50000, "original": None, "discountPercentage": 0},
             "badge": {"title": "Best Seller"}, "category": {"name": "Electronics"}, "rating": 4.8}
        ]}}}}]
        return resp

    with patch("tokopedia_mcp.client._make_session", return_value=_mock_session(fake_post)):
        result = await tokopedia.search_products("usb hub")

    op = captured["body"][0]["operationName"]
    assert op == "SearchProductV5Query", f"Expected SearchProductV5Query, got {op}"
    assert "searchProductV5" in captured["body"][0]["query"]
    assert result["total"] == 5
    assert result["products"][0]["name"] == "USB Hub"
    assert result["products"][0]["price"] == "Rp50.000"


# ---------------------------------------------------------------------------
# CRITICAL: all required HAR-derived params present
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_search_products_har_required_params():
    captured_vars = {}

    async def fake_post(url, **kwargs):
        captured_vars.update(kwargs.get("json", [{}])[0].get("variables", {}))
        resp = MagicMock()
        resp.status_code = 200
        resp.raise_for_status = MagicMock()
        resp.json.return_value = [{"data": {"searchProductV5": {"header": {"totalData": 0}, "data": {"products": []}}}}]
        return resp

    with patch("tokopedia_mcp.client._make_session", return_value=_mock_session(fake_post)):
        await tokopedia.search_products("laptop", price_max=400000)

    params = captured_vars.get("params", "")
    required = [
        "enter_method=normal_search",
        "l_name=sre",
        "source=search",
        "scheme=https",
        "st=product",
        "topads_bucket=true",
        "unique_id=",
        "user_cityId=",
        "user_warehouseId=",
        "srp_component_id=02.01.00.00",
        "pmax=400000",
    ]
    for req in required:
        assert req in params, f"Missing required param: {req}"


# ---------------------------------------------------------------------------
# CRITICAL: required headers from HAR
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_required_headers_present():
    captured_headers = {}

    async def fake_post(url, **kwargs):
        resp = MagicMock()
        resp.status_code = 200
        resp.raise_for_status = MagicMock()
        resp.json.return_value = [{"data": {"searchProductV5": {"header": {"totalData": 0}, "data": {"products": []}}}}]
        return resp

    original_make_session = tokopedia._make_session
    def patched_make_session(*args, **kwargs):
        session = original_make_session(*args, **kwargs)
        # Capture what headers the session was configured with by checking _DEFAULT_HEADERS
        return session

    # Just check _DEFAULT_HEADERS directly — it's module-level truth
    h = tokopedia._DEFAULT_HEADERS
    assert h.get("x-price-center") == "true", "Missing x-price-center: true"
    assert h.get("x-dark-mode") == "false", "Missing x-dark-mode: false"
    assert h.get("x-device") == "desktop-0.0", f"x-device must be 'desktop-0.0', got {h.get('x-device')}"
    # x-version is refreshed dynamically; verify it is present and looks like a build hash
    assert h.get("x-version"), "Missing x-version header"
    assert "bd-device-id" in h, "Missing bd-device-id"
    assert "bd-web-id" in h, "Missing bd-web-id"
    assert h["bd-device-id"] == h["bd-web-id"], "bd-device-id and bd-web-id must match"


# ---------------------------------------------------------------------------
# GQL unwraps list response correctly
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_gql_unwraps_list_response():
    async def fake_post(url, **kwargs):
        resp = MagicMock()
        resp.status_code = 200
        resp.raise_for_status = MagicMock()
        resp.json.return_value = [{"data": {"searchProductV5": {"header": {"totalData": 3}, "data": {"products": [
            {"id": "1", "id_str_auto_": "1", "name": "Hub A", "url": "u", "mediaURL": {"image": "i"},
             "shop": {"name": "S", "city": "C", "tier": 1},
             "price": {"text": "Rp30.000", "number": 30000, "original": None, "discountPercentage": 0},
             "badge": {}, "category": {"name": "Tech"}, "rating": 4.5},
        ]}}}}]
        return resp

    with patch("tokopedia_mcp.client._make_session", return_value=_mock_session(fake_post)):
        result = await tokopedia.search_products("hub")

    assert result["total"] == 3
    assert result["products"][0]["name"] == "Hub A"


# ---------------------------------------------------------------------------
# Retry on transient errors
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_gql_retries_on_network_error():
    import asyncio
    call_count = 0

    async def fake_post(url, **kwargs):
        nonlocal call_count
        call_count += 1
        if call_count < 3:
            raise ConnectionError("Network blip")
        resp = MagicMock()
        resp.status_code = 200
        resp.raise_for_status = MagicMock()
        resp.json.return_value = [{"data": {"searchProductV5": {"header": {"totalData": 0}, "data": {"products": []}}}}]
        return resp

    with patch("tokopedia_mcp.client._make_session", return_value=_mock_session(fake_post)):
        with patch("asyncio.sleep", new_callable=AsyncMock):
            result = await tokopedia.search_products("test")

    assert call_count == 3


# ---------------------------------------------------------------------------
# product detail: handles both list and dict data formats
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_product_detail_data_as_list():
    layout = {
        "name": "USB Hub 4 Port", "pdpSession": "x",
        "basicInfo": {"id": "123", "shopID": "456", "shopName": "TechShop",
                      "weight": "100", "weightUnit": "gram", "condition": "NEW",
                      "status": "active", "url": "https://tok.com/techshop/usb-hub",
                      "txStats": {"itemSoldPaymentVerified": 200},
                      "stats": {"countReview": 50, "rating": 4.7, "countView": 1000, "countTalk": 5},
                      "category": {"name": "Computer Accessories"}},
        "components": [
            {"name": "desc", "type": "description", "position": 1,
             "data": [{"__typename": "ProductDescription", "content": "Great hub", "isShow": True}]},
        ],
    }

    with patch("tokopedia_mcp.client._make_session",
               return_value=_mock_session(_mock_post({"pdpGetLayout": layout}))):
        result = await tokopedia.get_product_detail("https://www.tokopedia.com/techshop/usb-hub")

    assert result["description"] == "Great hub"
    assert result["name"] == "USB Hub 4 Port"
    assert "media" not in result


@pytest.mark.asyncio
async def test_product_detail_resolves_shortened_url_before_gql():
    captured = {}
    layout = {
        "basicInfo": {
            "alias": "USB Hub 4 Port",
            "id": "123",
            "shopID": "456",
            "shopName": "TechShop",
            "url": "https://tok.com/techshop/usb-hub",
        },
        "components": [],
    }

    async def fake_get(url, **kwargs):
        captured["short_url"] = url
        resp = MagicMock()
        resp.raise_for_status = MagicMock()
        resp.url = "https://www.tokopedia.com/techshop/usb-hub"
        return resp

    async def fake_post(url, **kwargs):
        captured["gql_url"] = url
        captured["variables"] = kwargs.get("json", [{}])[0].get("variables", {})
        resp = MagicMock()
        resp.status_code = 200
        resp.raise_for_status = MagicMock()
        resp.json.return_value = [{"data": {"pdpMainInfo": {"data": layout}}}]
        return resp

    with patch(
        "tokopedia_mcp.client._make_session",
        side_effect=[
            _mock_http_session(get_fn=fake_get),
            _mock_http_session(post_fn=fake_post),
        ],
    ):
        result = await tokopedia.get_product_detail("https://tk.tokopedia.com/ZSu5SnNdj/")

    assert captured["short_url"] == "https://tk.tokopedia.com/ZSu5SnNdj/"
    assert captured["variables"]["shopDomain"] == "techshop"
    assert captured["variables"]["productKey"] == "usb-hub"
    assert result["name"] == "USB Hub 4 Port"


@pytest.mark.asyncio
async def test_product_detail_includes_media_when_requested():
    layout = {
        "name": "USB Hub 4 Port",
        "basicInfo": {"id": "123", "shopID": "456", "shopName": "TechShop", "url": "https://tok.com/techshop/usb-hub"},
        "components": [
            {"name": "media", "type": "media", "data": [{
                "__typename": "ProductMedia",
                "media": [{"type": "image", "url": "full.jpg", "urlThumbnail": "thumb.jpg", "videoUrl": None}],
            }]},
        ],
    }

    with patch("tokopedia_mcp.client._make_session",
               return_value=_mock_session(_mock_post({"pdpGetLayout": layout}))):
        result = await tokopedia.get_product_detail("https://www.tokopedia.com/techshop/usb-hub", include_media=True)

    assert result["media"][0]["url"] == "full.jpg"


@pytest.mark.asyncio
async def test_product_detail_includes_variants_when_available():
    layout = {
        "name": "Kemeja Pria",
        "basicInfo": {"id": "123", "shopID": "456", "shopName": "TechShop", "url": "https://tok.com/techshop/kemeja"},
        "components": [
            {
                "name": "new_variant_options",
                "type": "variant",
                "data": [
                    {
                        "variants": [
                            {
                                "name": "Warna",
                                "option": [
                                    {"productVariantOptionID": "3", "value": "Hitam", "stock": "22"},
                                    {"productVariantOptionID": "4", "value": "Grey", "stock": "0"},
                                ],
                            },
                            {
                                "name": "Ukuran",
                                "option": [
                                    {"productVariantOptionID": "13", "value": "M", "stock": "10", "selected": True},
                                ],
                            },
                        ]
                        ,
                        "children": [
                            {
                                "productID": "sku-m-hitam",
                                "optionName": "Hitam, M",
                                "price": 129000,
                                "priceFmt": "Rp129.000",
                                "stock": 10,
                                "productURL": "https://tok.com/techshop/kemeja-hitam-m",
                            },
                            {
                                "productID": "sku-g-hitam",
                                "optionName": "Hitam, L",
                                "price": 139000,
                                "priceFmt": "Rp139.000",
                                "stock": 3,
                                "productURL": "https://tok.com/techshop/kemeja-hitam-l",
                            },
                        ]
                    }
                ],
            }
        ],
    }

    with patch("tokopedia_mcp.client._make_session",
               return_value=_mock_session(_mock_post({"pdpGetLayout": layout}))):
        result = await tokopedia.get_product_detail("https://www.tokopedia.com/techshop/kemeja")

    assert result["variants"]["groups"][0]["name"] == "Warna"
    assert result["variants"]["groups"][0]["options"][0]["value"] == "Hitam"
    assert result["variants"]["groups"][0]["options"][0]["stock"] == 22
    assert result["variants"]["selected"][0]["group"] == "Ukuran"
    assert result["variants"]["selected"][0]["value"] == "M"
    assert result["variants"]["selected_confidence"] == "explicit"
    assert len(result["variant_offers"]) == 2
    assert result["price_range"]["min_price_value"] == 129000
    assert result["price_range"]["max_price_value"] == 139000
    assert result["selected_offer"]["option_name"] == "Hitam, M"


def test_build_detail_from_html_extracts_variants_from_window_cache():
    cache = {
        "x.components.4.data.0.variants.0": {"name": "Warna"},
        "x.components.4.data.0.variants.0.option.0": {
            "productVariantOptionID": "3",
            "value": "Hitam Diamond",
            "stock": "22",
            "hex": "",
        },
        "x.components.4.data.0.variants.0.option.1": {
            "productVariantOptionID": "4",
            "value": "Grey Diamond",
            "stock": "31",
            "hex": "",
        },
        "x.components.4.data.0.children.0": {
            "productID": "sku-1",
            "optionName": "Hitam Diamond, MEDIUM",
            "price": 199000,
            "priceFmt": "Rp199.000",
            "stock": 22,
            "productURL": "https://www.tokopedia.com/detakoriginals/produk-a-1",
        },
        "x.components.4.data.0.children.1": {
            "productID": "sku-2",
            "optionName": "Grey Diamond, MEDIUM",
            "price": 209000,
            "priceFmt": "Rp209.000",
            "stock": 31,
            "productURL": "https://www.tokopedia.com/detakoriginals/produk-a-2",
        },
    }
    html = (
        "<html><head><title>Produk A | Tokopedia</title>"
        "<meta property='og:image' content='https://img.example/a.jpg'></head>"
        f"<body><script>window.__cache={json.dumps(cache)};window.__state={{}};</script></body></html>"
    )

    result = tokopedia._build_detail_from_html(
        html,
        shop_domain="detakoriginals",
        product_key="produk-a",
        product_url="https://www.tokopedia.com/detakoriginals/produk-a",
    )

    assert result["variants"]["groups"][0]["name"] == "Warna"
    assert result["variants"]["groups"][0]["options"][0]["option_id"] == "3"
    assert result["variants"]["groups"][0]["options"][0]["stock"] == 22
    assert len(result["variant_offers"]) == 2
    assert result["price_range"]["min_price_value"] == 199000
    assert result["price_range"]["max_price_value"] == 209000


def test_build_detail_from_html_extracts_selected_variants_from_window_cache_flags():
    cache = {
        "x.components.4.data.0.variants.0": {"name": "Warna"},
        "x.components.4.data.0.variants.0.option.0": {
            "productVariantOptionID": "3",
            "value": "Hitam Diamond",
            "stock": "22",
            "selected": True,
        },
    }
    html = (
        "<html><head><title>Produk A | Tokopedia</title></head>"
        f"<body><script>window.__cache={json.dumps(cache)};window.__state={{}};</script></body></html>"
    )

    result = tokopedia._build_detail_from_html(
        html,
        shop_domain="detakoriginals",
        product_key="produk-a",
        product_url="https://www.tokopedia.com/detakoriginals/produk-a",
    )

    assert result["variants"]["selected"][0]["group"] == "Warna"
    assert result["variants"]["selected"][0]["value"] == "Hitam Diamond"
    assert result["variants"]["selected_confidence"] == "explicit"


def test_build_detail_from_html_infers_selected_variants_from_title():
    cache = {
        "x.components.4.data.0.variants.0": {"name": "Warna"},
        "x.components.4.data.0.variants.0.option.0": {"productVariantOptionID": "3", "value": "Hitam Diamond", "stock": "22"},
        "x.components.4.data.0.variants.0.option.1": {"productVariantOptionID": "4", "value": "Grey Diamond", "stock": "31"},
        "x.components.4.data.0.variants.1": {"name": "Ukuran"},
        "x.components.4.data.0.variants.1.option.0": {"productVariantOptionID": "13", "value": "MEDIUM", "stock": "10"},
        "x.components.4.data.0.variants.1.option.1": {"productVariantOptionID": "14", "value": "LARGE", "stock": "10"},
        "x.components.4.data.0.children.0": {
            "productID": "sku-m",
            "optionName": "Hitam Diamond, MEDIUM",
            "price": 199000,
            "priceFmt": "Rp199.000",
            "stock": 10,
            "productURL": "https://www.tokopedia.com/detakoriginals/produk-a-m",
        },
        "x.components.4.data.0.children.1": {
            "productID": "sku-l",
            "optionName": "Hitam Diamond, LARGE",
            "price": 219000,
            "priceFmt": "Rp219.000",
            "stock": 10,
            "productURL": "https://www.tokopedia.com/detakoriginals/produk-a-l",
        },
    }
    html = (
        "<html><head>"
        "<title>Promo Produk A - Hitam Diamond, MEDIUM - Kota Tangerang | Tokopedia</title>"
        "</head>"
        f"<body><script>window.__cache={json.dumps(cache)};window.__state={{}};</script></body></html>"
    )

    result = tokopedia._build_detail_from_html(
        html,
        shop_domain="detakoriginals",
        product_key="produk-a",
        product_url="https://www.tokopedia.com/detakoriginals/produk-a",
    )

    assert {item["group"]: item["value"] for item in result["variants"]["selected"]} == {
        "Warna": "Hitam Diamond",
        "Ukuran": "MEDIUM",
    }
    assert result["variants"]["selected_confidence"] == "inferred"
    assert result["selected_offer"]["option_name"] == "Hitam Diamond, MEDIUM"


def test_build_detail_from_html_extracts_description_from_window_cache():
    cache = {
        "x.components.5.data.0.productDetailDescription": {
            "title": "Deskripsi",
            "content": "<p>Kabel LAN Cat 6 kualitas bagus.</p><p>Support gigabit.</p>",
            "__typename": "ProductDetailDescription",
        }
    }
    html = (
        "<html><head><title>Produk B | Tokopedia</title></head>"
        f"<body><script>window.__cache={json.dumps(cache)};window.__state={{}};</script></body></html>"
    )

    result = tokopedia._build_detail_from_html(
        html,
        shop_domain="sinshe-tekno",
        product_key="produk-b",
        product_url="https://www.tokopedia.com/sinshe-tekno/produk-b",
    )

    assert result["description"] == "Kabel LAN Cat 6 kualitas bagus. Support gigabit."


def test_build_detail_from_html_extracts_basic_info_from_window_cache():
    cache = {
        "pdpBasicInfo11111111111": {
            "productID": "11111111111",
            "shopID": "9999999",
            "shopName": "Toko Super",
            "minOrder": 2,
            "weight": 0.5,
            "weightUnit": "KILOGRAM",
            "condition": "NEW",
            "url": "https://www.tokopedia.com/tokosupeer/produk-c",
            "__typename": "pdpBasicInfo",
            "category": {"type": "id", "generated": False, "id": "pdpCategory77", "typename": "pdpCategory"},
            "stats": {"type": "id", "generated": True, "id": "$pdpBasicInfo11111111111.stats", "typename": "pdpStats"},
            "txStats": {"type": "id", "generated": True, "id": "$pdpBasicInfo11111111111.txStats", "typename": "pdpTxStats"},
        },
        "pdpCategory77": {"id": "77", "name": "Sepatu Pria", "__typename": "pdpCategory"},
        "$pdpBasicInfo11111111111.stats": {"countReview": "128", "rating": 4, "__typename": "pdpStats"},
        "$pdpBasicInfo11111111111.txStats": {"countSold": "500", "itemSoldFmt": "500+", "__typename": "pdpTxStats"},
    }
    html = (
        "<html><head><title>Produk C | Tokopedia</title></head>"
        f"<body><script>window.__cache={json.dumps(cache)};window.__state={{}};</script></body></html>"
    )

    result = tokopedia._build_detail_from_html(
        html,
        shop_domain="tokosupeer",
        product_key="produk-c",
        product_url="https://www.tokopedia.com/tokosupeer/produk-c",
    )

    assert result["product_id"] == "11111111111"
    assert result["shop_id"] == "9999999"
    assert result["shop_name"] == "Toko Super"
    assert result["condition"] == "NEW"
    assert result["weight"] == "0.5 KILOGRAM"
    assert result["min_order"] == 2
    assert result["category"] == "Sepatu Pria"
    assert result["rating"] == 4
    assert result["review_count"] == 128
    assert result["sold_count"] == "500+"


def test_build_detail_from_html_extracts_details_and_media_from_window_cache():
    cache = {
        "pdpBasicInfo22222222222": {
            "productID": "22222222222",
            "shopID": "8888888",
            "shopName": "Toko Dua",
            "minOrder": 1,
            "weight": 0.2,
            "weightUnit": "GR",
            "condition": "NEW",
            "__typename": "pdpBasicInfo",
        },
        "detail_entry_0": {
            "title": "Kondisi",
            "subtitle": "Baru",
            "__typename": "pdpContentProductDetail",
        },
        "detail_entry_1": {
            "title": "Kategori",
            "subtitle": "Elektronik",
            "__typename": "pdpContentProductDetail",
        },
        "media_entry_0": {
            "type": "image",
            "URLOriginal": "https://img.example.com/a.jpg",
            "URLThumbnail": "https://img.example.com/a_thumb.jpg",
            "videoURLAndroid": "",
            "__typename": "pdpContentSnapshotMedia",
        },
        "media_entry_1": {
            "type": "image",
            "URLOriginal": "https://img.example.com/b.jpg",
            "URLThumbnail": "https://img.example.com/b_thumb.jpg",
            "videoURLAndroid": "",
            "__typename": "pdpContentSnapshotMedia",
        },
    }
    html = (
        "<html><head><title>Produk D | Tokopedia</title></head>"
        f"<body><script>window.__cache={json.dumps(cache)};window.__state={{}};</script></body></html>"
    )

    result = tokopedia._build_detail_from_html(
        html,
        shop_domain="tokodua",
        product_key="produk-d",
        product_url="https://www.tokopedia.com/tokodua/produk-d",
    )

    assert result["details"] == [
        {"label": "Kondisi", "value": "Baru"},
        {"label": "Kategori", "value": "Elektronik"},
    ]
    assert result["media"][0]["url"] == "https://img.example.com/a.jpg"
    assert result["media"][0]["thumbnail"] == "https://img.example.com/a_thumb.jpg"
    assert result["media"][0]["video_url"] is None
    assert len(result["media"]) == 2


# ---------------------------------------------------------------------------
# logout clears state
# ---------------------------------------------------------------------------

def test_logout_clears_auth_state():
    tokopedia._auth_state.update({"access_token": "tok", "user_id": "99",
                                   "email": "u@e.com", "is_logged_in": True})
    result = tokopedia.logout()
    assert not tokopedia._auth_state["is_logged_in"]
    assert tokopedia._auth_state["access_token"] is None
    assert result["previous_email"] == "u@e.com"


def test_make_session_includes_extra_cookies_when_logged_out():
    original_auth = dict(tokopedia._auth_state)
    captured = {}

    def fake_async_session(*args, **kwargs):
        captured.update(kwargs)
        return MagicMock()

    try:
        tokopedia._auth_state.update({
            "access_token": None,
            "token_type": "bearer",
            "user_id": None,
            "email": None,
            "cookies": {},
            "is_logged_in": False,
        })
        with patch("tokopedia_mcp.client.AsyncSession", side_effect=fake_async_session):
            tokopedia._make_session(extra_cookies={"_SID_Tokopedia_": "sid"})

        assert captured["cookies"] == {"_SID_Tokopedia_": "sid"}
    finally:
        tokopedia._auth_state.update(original_auth)


# ---------------------------------------------------------------------------
# URL parsing
# ---------------------------------------------------------------------------

def test_parse_product_url_valid():
    d, k = tokopedia._parse_product_url("https://www.tokopedia.com/samsung-id/galaxy-s24")
    assert d == "samsung-id" and k == "galaxy-s24"


def test_parse_product_url_invalid():
    with pytest.raises(ValueError):
        tokopedia._parse_product_url("https://www.tokopedia.com/")


# ---------------------------------------------------------------------------
# _ensure_fresh: x-version auto-refresh
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_ensure_fresh_updates_x_version_when_stale():
    """_ensure_fresh() should update x-version in _DEFAULT_HEADERS when cache is stale."""
    import time
    from unittest.mock import AsyncMock, MagicMock, patch

    # Force cache to be stale
    original_expires = tokopedia._version_expires
    tokopedia._version_expires = 0.0
    original_version = tokopedia._DEFAULT_HEADERS.get("x-version")

    # window.version lives inside an inline <script> tag; wrap it so selectolax can find it
    full_sha1 = "abc1234" + "a" * 33   # 7 + 33 = 40 chars
    html_with_window_version = f'<html><head></head><body><script>window.version="{full_sha1}";</script></body></html>'
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.text = html_with_window_version

    mock_session = AsyncMock()
    mock_session.__aenter__ = AsyncMock(return_value=mock_session)
    mock_session.__aexit__ = AsyncMock(return_value=None)
    mock_session.get = AsyncMock(return_value=mock_resp)

    try:
        with patch("tokopedia_mcp.client.AsyncSession", return_value=mock_session):
            await tokopedia._ensure_fresh()

        assert tokopedia._DEFAULT_HEADERS["x-version"] == "abc1234", (
            f"Expected x-version='abc1234' (first 7 of SHA1), got {tokopedia._DEFAULT_HEADERS['x-version']!r}"
        )
        assert tokopedia._version_expires > time.monotonic() - 5
    finally:
        # Restore state
        tokopedia._version_expires = original_expires
        tokopedia._DEFAULT_HEADERS["x-version"] = original_version or "50c57b0"


@pytest.mark.asyncio
async def test_ensure_fresh_skips_network_when_cache_is_valid():
    """_ensure_fresh() must NOT make a network call when the cache is still valid."""
    import time
    from unittest.mock import patch

    # Mark cache as fresh for 1 hour
    tokopedia._version_expires = time.monotonic() + 3600.0

    with patch("tokopedia_mcp.client.AsyncSession") as mock_cls:
        await tokopedia._ensure_fresh()
        mock_cls.assert_not_called()


@pytest.mark.asyncio
async def test_ensure_fresh_keeps_existing_version_on_fetch_failure():
    """_ensure_fresh() must keep the current x-version when the network call fails."""
    import time
    from unittest.mock import AsyncMock, patch

    tokopedia._version_expires = 0.0
    before = tokopedia._DEFAULT_HEADERS["x-version"]

    mock_session = AsyncMock()
    mock_session.__aenter__ = AsyncMock(return_value=mock_session)
    mock_session.__aexit__ = AsyncMock(return_value=None)
    mock_session.get = AsyncMock(side_effect=ConnectionError("network down"))

    with patch("tokopedia_mcp.client.AsyncSession", return_value=mock_session):
        await tokopedia._ensure_fresh()

    assert tokopedia._DEFAULT_HEADERS["x-version"] == before, (
        "x-version should be unchanged after a failed refresh"
    )
    # Cache expiry should still be set so we don't hammer the network
    assert tokopedia._version_expires > time.monotonic() - 5


# ---------------------------------------------------------------------------
# _extract_window_version — regex-first extraction with parser fallback
# ---------------------------------------------------------------------------

def test_extract_window_version_finds_sha1_in_script_tag():
    """_extract_window_version() must return the 7-char prefix from a <script> tag."""
    full_sha1 = "abc1234" + "b" * 33
    html = f'<html><body><script>var a=1;window.version="{full_sha1}";var b=2;</script></body></html>'
    assert tokopedia._extract_window_version(html) == "abc1234"


def test_extract_window_version_single_quotes():
    """_extract_window_version() must handle single-quoted values."""
    full_sha1 = "def5678" + "c" * 33
    html = f"<html><body><script>window.version='{full_sha1}';</script></body></html>"
    assert tokopedia._extract_window_version(html) == "def5678"


def test_extract_window_version_allows_whitespace_around_equals():
    """_extract_window_version() must handle optional spaces around assignment."""
    full_sha1 = "f1e2d3c" + "a" * 33
    html = f'<html><body><script>window.version = "{full_sha1}";</script></body></html>'
    assert tokopedia._extract_window_version(html) == "f1e2d3c"


def test_extract_window_version_from_json_payload():
    """_extract_window_version() must fall back to JSON-like version payloads."""
    full_sha1 = "1234abc" + "d" * 33
    html = f'<html><body><script>window.__DATA__={{"version":"{full_sha1}"}};</script></body></html>'
    assert tokopedia._extract_window_version(html) == "1234abc"


def test_extract_window_version_from_script_src_hash():
    """_extract_window_version() must fall back to hash values embedded in script src URLs."""
    full_sha1 = "7654fed" + "e" * 33
    html = f'<html><head><script src="https://assets.tokopedia.net/{full_sha1}/runtime.js"></script></head></html>'
    assert tokopedia._extract_window_version(html) == "7654fed"


def test_extract_window_version_returns_none_when_absent():
    """_extract_window_version() must return None when no matching tag exists."""
    html = "<html><body><script>var x = 1;</script></body></html>"
    assert tokopedia._extract_window_version(html) is None


def test_extract_window_version_ignores_short_hash():
    """_extract_window_version() must reject values shorter than 40 chars."""
    html = '<html><body><script>window.version="abc1234";</script></body></html>'
    assert tokopedia._extract_window_version(html) is None


def test_extract_window_version_ignores_non_hex():
    """_extract_window_version() must reject values that contain non-hex characters."""
    non_hex = "z" * 40
    html = f'<html><body><script>window.version="{non_hex}";</script></body></html>'
    assert tokopedia._extract_window_version(html) is None


def test_extract_window_version_returns_none_for_empty_html():
    """_extract_window_version() must return None for empty or script-free HTML."""
    assert tokopedia._extract_window_version("") is None
    assert tokopedia._extract_window_version("<html><body></body></html>") is None


# ---------------------------------------------------------------------------
# GraphQL error handling
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_gql_raises_on_graphql_error():
    """_gql() must raise RuntimeError immediately when the server returns errors[]."""
    async def fake_post(url, **kwargs):
        resp = MagicMock()
        resp.status_code = 200
        resp.raise_for_status = MagicMock()
        resp.json.return_value = [{"errors": [{"message": "Unauthorized"}]}]
        return resp

    with patch("tokopedia_mcp.client._make_session", return_value=_mock_session(fake_post)):
        with pytest.raises(RuntimeError, match="GraphQL error"):
            await tokopedia.search_products("test")


# ---------------------------------------------------------------------------
# _make_session adds Authorization header when logged in
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_make_session_adds_auth_header_when_logged_in():
    """_make_session() must inject Authorization and tkpd-userid when authenticated."""
    captured_headers = {}

    original_auth = dict(tokopedia._auth_state)
    tokopedia._auth_state.update({
        "access_token": "mytoken123",
        "token_type": "bearer",
        "user_id": "42",
        "is_logged_in": True,
        "cookies": {},
    })

    try:
        # Instantiate a real session (no network) and inspect the headers
        # We patch AsyncSession to capture what kwargs it receives
        with patch("tokopedia_mcp.client.AsyncSession") as mock_cls:
            mock_cls.return_value.__aenter__ = AsyncMock(return_value=AsyncMock())
            mock_cls.return_value.__aexit__ = AsyncMock(return_value=None)
            tokopedia._make_session()
            _, kwargs = mock_cls.call_args
            captured_headers = kwargs.get("headers", {})
    finally:
        tokopedia._auth_state.update(original_auth)

    assert captured_headers.get("Authorization") == "Bearer mytoken123"
    assert captured_headers.get("tkpd-userid") == "42"


@pytest.mark.asyncio
async def test_make_session_no_auth_header_when_logged_out():
    """_make_session() must NOT inject Authorization when not authenticated."""
    original_auth = dict(tokopedia._auth_state)
    tokopedia._auth_state.update({"is_logged_in": False, "access_token": None})

    try:
        with patch("tokopedia_mcp.client.AsyncSession") as mock_cls:
            mock_cls.return_value.__aenter__ = AsyncMock(return_value=AsyncMock())
            mock_cls.return_value.__aexit__ = AsyncMock(return_value=None)
            tokopedia._make_session()
            _, kwargs = mock_cls.call_args
            headers = kwargs.get("headers", {})
    finally:
        tokopedia._auth_state.update(original_auth)

    assert "Authorization" not in headers


# ---------------------------------------------------------------------------
# search_products: rows clamping and sort_by mapping
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_search_products_rows_clamped_to_60():
    """rows > 60 must be silently clamped to 60."""
    captured = {}

    async def fake_post(url, **kwargs):
        captured["vars"] = kwargs.get("json", [{}])[0].get("variables", {})
        resp = MagicMock()
        resp.status_code = 200
        resp.raise_for_status = MagicMock()
        resp.json.return_value = [{"data": {"searchProductV5": {"header": {"totalData": 0}, "data": {"products": []}}}}]
        return resp

    with patch("tokopedia_mcp.client._make_session", return_value=_mock_session(fake_post)):
        result = await tokopedia.search_products("laptop", rows=999)

    assert result["rows"] == 60
    assert "rows=60" in captured["vars"].get("params", "")


@pytest.mark.asyncio
async def test_search_products_sort_by_mapping():
    """sort_by='lowest_price' must map to ob=5 in the params string."""
    captured = {}

    async def fake_post(url, **kwargs):
        captured["params"] = kwargs.get("json", [{}])[0].get("variables", {}).get("params", "")
        resp = MagicMock()
        resp.status_code = 200
        resp.raise_for_status = MagicMock()
        resp.json.return_value = [{"data": {"searchProductV5": {"header": {"totalData": 0}, "data": {"products": []}}}}]
        return resp

    with patch("tokopedia_mcp.client._make_session", return_value=_mock_session(fake_post)):
        await tokopedia.search_products("laptop", sort_by="lowest_price")

    assert "ob=5" in captured["params"], f"Expected ob=5 for lowest_price, got: {captured['params']}"


@pytest.mark.asyncio
async def test_search_products_pagination():
    """page and start must be set correctly for page=2, rows=10."""
    captured = {}

    async def fake_post(url, **kwargs):
        captured["params"] = kwargs.get("json", [{}])[0].get("variables", {}).get("params", "")
        resp = MagicMock()
        resp.status_code = 200
        resp.raise_for_status = MagicMock()
        resp.json.return_value = [{"data": {"searchProductV5": {"header": {"totalData": 0}, "data": {"products": []}}}}]
        return resp

    with patch("tokopedia_mcp.client._make_session", return_value=_mock_session(fake_post)):
        result = await tokopedia.search_products("laptop", page=2, rows=10)

    assert result["page"] == 2
    assert "page=2" in captured["params"]
    assert "start=10" in captured["params"]


# ---------------------------------------------------------------------------
# get_product_reviews
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_get_product_reviews_basic():
    """get_product_reviews() must return structured review data."""
    review_list = [
           {"reviewID": "r1", "message": "Great product!", "productRating": 5,
            "variantName": "Hitam, M",
         "reviewerName": "Alice", "avatar": "img.jpg", "createTime": "2024-01-01",
         "likeDislike": {"totalLike": 10, "totalDislike": 1},
         "imageAttachments": [], "videoAttachments": []},
    ]
    mock_data = {
        "productReviewList": {
            "list": review_list,
            "hasNext": False,
            "totalRatings": 100,
            "totalReviews": 50,
        }
    }

    with patch("tokopedia_mcp.client._make_session", return_value=_mock_session(_mock_post(mock_data))):
        result = await tokopedia.get_product_reviews("123", page=1, limit=10)

    assert result["total_reviews"] == 50
    assert result["total_ratings"] == 100
    assert result["has_next"] is False
    assert result["page"] == 1
    assert result["filtered_low_signal_reviews"] == 0
    assert result["reviews"][0]["reviewer_name"] == "Alice"
    assert result["reviews"][0]["content"] == "Great product!"
    assert result["reviews"][0]["variant_name"] == "Hitam, M"
    assert result["reviews"][0]["image_count"] == 0
    assert "image_attachments" not in result["reviews"][0]


@pytest.mark.asyncio
async def test_get_product_reviews_variant_name_defaults_empty_string():
    mock_data = {
        "productReviewList": {
            "list": [
                {
                    "reviewID": "r1",
                    "message": "Bagus",
                    "productRating": 5,
                    "reviewerName": "Alice",
                    "imageAttachments": [],
                    "videoAttachments": [],
                },
            ],
            "hasNext": False,
            "totalRatings": 1,
            "totalReviews": 1,
        }
    }

    with patch("tokopedia_mcp.client._make_session", return_value=_mock_session(_mock_post(mock_data))):
        result = await tokopedia.get_product_reviews("123")

    assert result["reviews"][0]["variant_name"] == ""


@pytest.mark.asyncio
async def test_get_product_reviews_filters_low_signal_arrival_reviews_by_default():
    mock_data = {
        "productReviewList": {
            "list": [
                {
                    "reviewID": "r-arrival",
                    "message": "Barang baru sampai, packing rapi, belum dicoba. Semoga awet",
                    "productRating": 5,
                    "reviewerName": "Bob",
                    "likeDislike": {"totalLike": 0},
                    "imageAttachments": [],
                    "videoAttachments": [],
                },
                {
                    "reviewID": "r-real",
                    "message": "Sudah dipakai, ukuran pas, bahan terasa bagus, dan warna sesuai foto",
                    "productRating": 5,
                    "reviewerName": "Alice",
                    "likeDislike": {"totalLike": 3},
                    "imageAttachments": [],
                    "videoAttachments": [],
                },
            ],
            "hasNext": False,
            "totalRatings": 2,
            "totalReviews": 2,
        }
    }

    with patch("tokopedia_mcp.client._make_session", return_value=_mock_session(_mock_post(mock_data))):
        result = await tokopedia.get_product_reviews("123")

    assert result["filtered_low_signal_reviews"] == 1
    assert len(result["reviews"]) == 1
    assert result["reviews"][0]["review_id"] == "r-real"


@pytest.mark.asyncio
async def test_get_product_reviews_can_include_low_signal_reviews_when_requested():
    mock_data = {
        "productReviewList": {
            "list": [
                {
                    "reviewID": "r-arrival",
                    "message": "Barang baru sampai, packing rapi, belum dicoba. Semoga awet",
                    "productRating": 5,
                    "reviewerName": "Bob",
                    "likeDislike": {"totalLike": 0},
                    "imageAttachments": [],
                    "videoAttachments": [],
                },
            ],
            "hasNext": False,
            "totalRatings": 1,
            "totalReviews": 1,
        }
    }

    with patch("tokopedia_mcp.client._make_session", return_value=_mock_session(_mock_post(mock_data))):
        result = await tokopedia.get_product_reviews("123", include_low_signal=True)

    assert result["filtered_low_signal_reviews"] == 0
    assert len(result["reviews"]) == 1
    assert result["reviews"][0]["review_id"] == "r-arrival"


@pytest.mark.asyncio
async def test_get_product_reviews_includes_media_when_requested():
    mock_data = {
        "productReviewList": {
            "list": [
                {"reviewID": "r1", "reviewerName": "Alice", "productRating": 5,
                 "message": "Great product!",
                 "imageAttachments": [{"attachmentID": "img1", "imageThumbnailUrl": "thumb.jpg", "imageUrl": "full.jpg"}],
                 "videoAttachments": []},
            ],
            "hasNext": False,
            "totalRatings": 100,
            "totalReviews": 50,
        }
    }

    with patch("tokopedia_mcp.client._make_session", return_value=_mock_session(_mock_post(mock_data))):
        result = await tokopedia.get_product_reviews("123", include_media=True)

    assert result["reviews"][0]["image_attachments"][0]["imageUrl"] == "full.jpg"


@pytest.mark.asyncio
async def test_get_product_reviews_sort_by_newest():
    """sort_by='newest' must be translated to create_time%3Bdesc in variables."""
    captured = {}

    async def fake_post(url, **kwargs):
        captured["vars"] = kwargs.get("json", [{}])[0].get("variables", {})
        resp = MagicMock()
        resp.status_code = 200
        resp.raise_for_status = MagicMock()
        resp.json.return_value = [{"data": {"productReviewList": {
            "list": [], "hasNext": False, "totalRatings": 0, "totalReviews": 0
        }}}]
        return resp

    with patch("tokopedia_mcp.client._make_session", return_value=_mock_session(fake_post)):
        await tokopedia.get_product_reviews("456", sort_by="newest")

    assert "create_time" in captured["vars"].get("sortBy", ""), (
        f"sort_by='newest' should map to create_time, got: {captured['vars'].get('sortBy')}"
    )


@pytest.mark.asyncio
async def test_get_product_reviews_gql_url():
    """GQL call must use 'productReviewList' as the operation name in the URL."""
    captured_url = {}

    async def fake_post(url, **kwargs):
        captured_url["url"] = url
        resp = MagicMock()
        resp.status_code = 200
        resp.raise_for_status = MagicMock()
        resp.json.return_value = [{"data": {"productReviewList": {
            "list": [], "hasNext": False, "totalRatings": 0, "totalReviews": 0
        }}}]
        return resp

    with patch("tokopedia_mcp.client._make_session", return_value=_mock_session(fake_post)):
        await tokopedia.get_product_reviews("789")

    assert captured_url["url"].endswith("/productReviewList")


# ---------------------------------------------------------------------------
# get_shop_info
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_get_shop_info_basic():
    """get_shop_info() must return normalised shop data."""
    mock_data = {
        "shopInfoByID": {
            "result": [{
                "shopCore": {"shopID": "1", "name": "TechShop", "domain": "techshop",
                             "tagLine": "Best tech", "description": "We sell tech",
                             "avatarURL": "ava.jpg", "coverURL": "cover.jpg"},
                "location": {"city": "Jakarta", "province": "DKI Jakarta", "countryName": "Indonesia"},
                "goldOS": {"isGold": True, "isGoldBadge": True},
                "shopStats": {"totalTx": 5000, "totalShowcase": 200, "totalFavorite": 1000},
            }],
            "error": {},
        }
    }

    with patch("tokopedia_mcp.client._make_session", return_value=_mock_session(_mock_post(mock_data))):
        result = await tokopedia.get_shop_info("techshop")

    assert result["name"] == "TechShop"
    assert result["domain"] == "techshop"
    assert result["city"] == "Jakarta"
    assert result["is_gold"] is True
    assert result["total_transactions"] == 5000


@pytest.mark.asyncio
async def test_get_shop_info_empty_result():
    """get_shop_info() returns an empty dict when no shop is found."""
    mock_data = {"shopInfoByID": {"result": [], "error": {"message": "not found"}}}

    with patch("tokopedia_mcp.client._make_session", return_value=_mock_session(_mock_post(mock_data))):
        result = await tokopedia.get_shop_info("nonexistent-shop")

    assert result == {}


@pytest.mark.asyncio
async def test_get_shop_info_gql_url():
    """GQL call must use 'ShopInfoCore' in the URL."""
    captured_url = {}

    async def fake_post(url, **kwargs):
        captured_url["url"] = url
        resp = MagicMock()
        resp.status_code = 200
        resp.raise_for_status = MagicMock()
        resp.json.return_value = [{"data": {"shopInfoByID": {"result": [], "error": {}}}}]
        return resp

    with patch("tokopedia_mcp.client._make_session", return_value=_mock_session(fake_post)):
        await tokopedia.get_shop_info("someshop")

    assert captured_url["url"].endswith("/ShopInfoCore")


# ---------------------------------------------------------------------------
# search_shops
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_search_shops_basic():
    """search_shops() must return a list of shops with correct total."""
    mock_data = {
        "aceSearchShopV2": {
            "header": {"totalData": 2, "responseCode": 200, "errorMessage": ""},
            "data": {
                "shops": [
                    {"shopID": "1", "name": "Shop A", "shopDomain": "shop-a",
                     "avatarURL": "a.jpg", "city": "Jakarta", "isGold": False,
                     "isGoldBadge": False, "isOfficial": False, "rating": 4.5,
                     "totalReview": 100, "productList": []},
                ]
            }
        }
    }

    with patch("tokopedia_mcp.client._make_session", return_value=_mock_session(_mock_post(mock_data))):
        result = await tokopedia.search_shops("electronics")

    assert result["total"] == 2
    assert result["shops"][0]["name"] == "Shop A"


@pytest.mark.asyncio
async def test_search_shops_rows_clamped_to_20():
    """rows > 20 must be clamped to 20 for search_shops."""
    with patch("tokopedia_mcp.client._make_session", return_value=_mock_session(_mock_post(
        {"aceSearchShopV2": {"header": {"totalData": 0}, "data": {"shops": []}}}
    ))):
        result = await tokopedia.search_shops("test", rows=999)

    assert result["rows"] == 20


# ---------------------------------------------------------------------------
# get_shop_products
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_get_shop_products_basic():
    """get_shop_products() must normalise product data."""
    async def fake_post(url, **kwargs):
        resp = MagicMock()
        resp.status_code = 200
        resp.raise_for_status = MagicMock()
        if url.endswith("/ShopInfoCore"):
            resp.json.return_value = [{"data": {"shopInfoByID": {"result": [{"shopCore": {"shopID": "1"}}]}}}]
            return resp
        resp.json.return_value = [{"data": {"GetShopProduct": {
            "status": "success",
            "links": {},
            "data": [
                {
                    "product_id": "p1",
                    "name": "USB Hub",
                    "product_url": "url1",
                    "price": {"text_idr": "Rp50.000"},
                    "primary_image": {"thumbnail": "img.jpg"},
                    "stats": {"averageRating": 4.8, "reviewCount": 30},
                }
            ]
        }}}]
        return resp

    with patch("tokopedia_mcp.client._make_session", return_value=_mock_session(fake_post)):
        result = await tokopedia.get_shop_products("techshop")

    assert result["total"] == 1
    assert result["products"][0]["name"] == "USB Hub"
    assert result["products"][0]["price"] == "Rp50.000"
    assert result["products"][0]["price_value"] is None
    assert result["products"][0]["rating"] == 4.8


@pytest.mark.asyncio
async def test_get_shop_products_gql_url():
    """get_shop_products() should call ShopInfoCore then ShopProducts."""
    captured_urls = []

    async def fake_post(url, **kwargs):
        captured_urls.append(url)
        resp = MagicMock()
        resp.status_code = 200
        resp.raise_for_status = MagicMock()
        if url.endswith("/ShopInfoCore"):
            resp.json.return_value = [{"data": {"shopInfoByID": {"result": [{"shopCore": {"shopID": "1"}}]}}}]
        else:
            resp.json.return_value = [{"data": {"GetShopProduct": {"data": []}}}]
        return resp

    with patch("tokopedia_mcp.client._make_session", return_value=_mock_session(fake_post)):
        await tokopedia.get_shop_products("myshop")

    assert any(url.endswith("/ShopInfoCore") for url in captured_urls)
    assert any(url.endswith("/ShopProducts") for url in captured_urls)


@pytest.mark.asyncio
async def test_get_shop_products_falls_back_to_html():
        """get_shop_products() should parse rendered product cards when GraphQL fails."""
        html = """
        <html><body>
            <a href="https://www.tokopedia.com/sinshe-tekno/product">ignore listing</a>
            <a href="https://www.tokopedia.com/sinshe-tekno/vention-kabel-usb-c-1733917977132107175?extParam=src%3Dshop">
                <img alt="product-image" src="https://images.example.com/item.webp" />
                <span>Vention Kabel USB C</span>
                <div>Rp50.000</div>
                <span>4.9</span>
                <span>30+ terjual</span>
            </a>
        </body></html>
        """

        session = AsyncMock()
        session.__aenter__ = AsyncMock(return_value=session)
        session.__aexit__ = AsyncMock(return_value=None)
        session.post = AsyncMock(side_effect=RuntimeError("Invalid request schema"))

        async def fake_get(url, **kwargs):
                resp = MagicMock()
                resp.status_code = 200
                resp.raise_for_status = MagicMock()
                resp.text = html
                return resp

        session.get = AsyncMock(side_effect=fake_get)

        with patch("tokopedia_mcp.client._make_session", return_value=session):
                result = await tokopedia.get_shop_products("sinshe-tekno", keyword="kabel usb c")

        assert result["total"] == 1
        assert result["products"][0]["product_id"] == "1733917977132107175"
        assert result["products"][0]["name"] == "Vention Kabel USB C"
        assert result["products"][0]["price"] == "Rp50.000"
        assert result["products"][0]["price_value"] == 50000
        assert result["products"][0]["image_url"] == "https://images.example.com/item.webp"
        assert result["products"][0]["rating"] == 4.9


# ---------------------------------------------------------------------------
# get_review_media
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_get_review_media_extracts_images_and_videos():
    """get_review_media() must separate image and video attachments from review data."""
    mock_data = {
        "productReviewList": {
            "list": [
                {"reviewID": "r1", "reviewerName": "Alice", "productRating": 5,
                 "message": "Great!", "createTime": "2024-01-01",
                 "likeDislike": {"totalLike": 1, "totalDislike": 0},
                 "imageAttachments": [
                     {"attachmentID": "img1", "imageThumbnailUrl": "thumb.jpg", "imageUrl": "full.jpg"}
                 ],
                 "videoAttachments": [
                     {"attachmentID": "vid1", "videoUrl": "video.mp4", "thumbnailUrl": "vthumb.jpg"}
                 ]},
            ],
            "hasNext": True,
            "totalRatings": 10,
            "totalReviews": 5,
        }
    }

    with patch("tokopedia_mcp.client._make_session", return_value=_mock_session(_mock_post(mock_data))):
        result = await tokopedia.get_review_media("123")

    assert result["product_id"] == "123"
    assert result["has_next"] is True
    assert len(result["images"]) == 1
    assert result["images"][0]["image_url"] == "full.jpg"
    assert result["images"][0]["reviewer"] == "Alice"
    assert len(result["videos"]) == 1
    assert result["videos"][0]["video_url"] == "video.mp4"


@pytest.mark.asyncio
async def test_get_review_media_empty():
    """get_review_media() must return empty lists when reviews have no attachments."""
    mock_data = {
        "productReviewList": {
            "list": [
                {"reviewID": "r1", "reviewerName": "Bob", "productRating": 4,
                 "message": "OK", "createTime": "2024-01-01",
                 "likeDislike": {"totalLike": 0, "totalDislike": 0},
                 "imageAttachments": [], "videoAttachments": []},
            ],
            "hasNext": False, "totalRatings": 1, "totalReviews": 1,
        }
    }

    with patch("tokopedia_mcp.client._make_session", return_value=_mock_session(_mock_post(mock_data))):
        result = await tokopedia.get_review_media("456")

    assert result["images"] == []
    assert result["videos"] == []


# ---------------------------------------------------------------------------
# download_media
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_download_media_returns_base64():
    """download_media() must return content-type, size, and base64-encoded data."""
    fake_content = b"PNG\x89\x50\x4e\x47"  # fake PNG bytes

    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.raise_for_status = MagicMock()
    mock_resp.headers = {"content-type": "image/png"}
    mock_resp.content = fake_content

    mock_session = AsyncMock()
    mock_session.__aenter__ = AsyncMock(return_value=mock_session)
    mock_session.__aexit__ = AsyncMock(return_value=None)
    mock_session.get = AsyncMock(return_value=mock_resp)

    with patch("tokopedia_mcp.client.AsyncSession", return_value=mock_session):
        result = await tokopedia.download_media("https://images.tokopedia.net/img/test.jpg")

    import base64
    assert result["content_type"] == "image/png"
    assert result["size_bytes"] == len(fake_content)
    assert result["data_base64"] == base64.b64encode(fake_content).decode()
    assert result["url"] == "https://images.tokopedia.net/img/test.jpg"


# ---------------------------------------------------------------------------
# login
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_login_success():
    """login() must update _auth_state and return logged_in=True on success."""
    original_auth = dict(tokopedia._auth_state)

    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.raise_for_status = MagicMock()
    mock_resp.json.return_value = {"access_token": "tok_abc", "token_type": "bearer"}

    mock_session = AsyncMock()
    mock_session.__aenter__ = AsyncMock(return_value=mock_session)
    mock_session.__aexit__ = AsyncMock(return_value=None)
    mock_session.post = AsyncMock(return_value=mock_resp)

    try:
        with patch("tokopedia_mcp.client.AsyncSession", return_value=mock_session):
            result = await tokopedia.login("user@example.com", "secret")

        assert result["logged_in"] is True
        assert result["email"] == "user@example.com"
        assert tokopedia._auth_state["is_logged_in"] is True
        assert tokopedia._auth_state["access_token"] == "tok_abc"
    finally:
        tokopedia._auth_state.update(original_auth)


@pytest.mark.asyncio
async def test_login_failure():
    """login() must return logged_in=False and include error when server rejects."""
    original_auth = dict(tokopedia._auth_state)

    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.raise_for_status = MagicMock()
    mock_resp.json.return_value = {"error": "invalid_grant", "error_description": "Wrong password"}

    mock_session = AsyncMock()
    mock_session.__aenter__ = AsyncMock(return_value=mock_session)
    mock_session.__aexit__ = AsyncMock(return_value=None)
    mock_session.post = AsyncMock(return_value=mock_resp)

    try:
        with patch("tokopedia_mcp.client.AsyncSession", return_value=mock_session):
            result = await tokopedia.login("user@example.com", "wrong")

        assert result["logged_in"] is False
        assert "Wrong password" in result.get("error", "")
        assert tokopedia._auth_state["is_logged_in"] is False
    finally:
        tokopedia._auth_state.update(original_auth)


# ---------------------------------------------------------------------------
# generate_login_qr
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_generate_login_qr_returns_uuid_and_qr():
    """generate_login_qr() must return uuid, qr_png_base64, and instructions."""
    mock_data = {
        "OTPRequestQR": {
            "is_success": True,
            "error_message": "",
            "token": "test-uuid-1234",
            "code": base64.b64encode(b"fake-jpeg").decode(),
            "status": "successrequestqr",
        }
    }

    prime_session = _mock_session(_mock_post(mock_data))
    homepage_resp = MagicMock()
    homepage_resp.status_code = 200
    homepage_resp.raise_for_status = MagicMock()
    homepage_resp.text = "<html></html>"
    prime_session.get = AsyncMock(return_value=homepage_resp)
    prime_session.cookies = {"_SID_Tokopedia_": "sid"}

    gql_session = _mock_session(_mock_post(mock_data))
    gql_session.cookies = {"_SID_Tokopedia_": "sid", "DID": "did-cookie", "DID_JS": "did-js-cookie"}

    bootstrap = AsyncMock(return_value={"DID": "did-cookie", "DID_JS": "did-js-cookie"})

    with patch("tokopedia_mcp.client._make_session", side_effect=[prime_session, gql_session]), \
         patch("tokopedia_mcp.client._ensure_fresh", new_callable=AsyncMock), \
         patch("tokopedia_mcp.client._image_base64_to_png_base64", return_value="png-converted"), \
         patch("tokopedia_mcp.client._bootstrap_qr_cookies_via_playwright", bootstrap):
        result = await tokopedia.generate_login_qr()

    bootstrap.assert_awaited_once()
    assert result["uuid"] == "test-uuid-1234"
    assert result["validation_token"] == "test-uuid-1234"
    assert result["expired_time"] is None
    assert result["qr_status"] == "successrequestqr"
    assert result["qr_image_mime_type"] == "image/jpeg"
    assert result["qr_image_data_url"].startswith("data:image/jpeg;base64,")
    assert result["qr_png_base64"] == "png-converted"
    assert result["qr_ascii"]       # should be non-empty ASCII art
    assert "Tokopedia app" in result["instructions"]


@pytest.mark.asyncio
async def test_generate_login_qr_skips_playwright_when_did_cookies_exist():
    mock_data = {
        "OTPRequestQR": {
            "is_success": True,
            "error_message": "",
            "token": "existing-did-token",
            "code": "",
            "status": "successrequestqr",
        }
    }

    prime_session = _mock_session(_mock_post(mock_data))
    homepage_resp = MagicMock()
    homepage_resp.status_code = 200
    homepage_resp.raise_for_status = MagicMock()
    homepage_resp.text = "<html></html>"
    prime_session.get = AsyncMock(return_value=homepage_resp)
    prime_session.cookies = {"DID": "did-cookie", "DID_JS": "did-js-cookie"}

    gql_session = _mock_session(_mock_post(mock_data))
    gql_session.cookies = {"DID": "did-cookie", "DID_JS": "did-js-cookie"}

    bootstrap = AsyncMock(return_value={})

    with patch("tokopedia_mcp.client._make_session", side_effect=[prime_session, gql_session]), \
         patch("tokopedia_mcp.client._ensure_fresh", new_callable=AsyncMock), \
         patch("tokopedia_mcp.client._bootstrap_qr_cookies_via_playwright", bootstrap):
        result = await tokopedia.generate_login_qr()

    bootstrap.assert_not_awaited()
    assert result["uuid"] == "existing-did-token"


@pytest.mark.asyncio
async def test_generate_login_qr_retries_transient_otprequest_errors():
    mock_data = {
        "OTPRequestQR": {
            "is_success": True,
            "error_message": "",
            "token": "retry-token",
            "code": "",
            "status": "successrequestqr",
        }
    }

    prime_session = _mock_session(_mock_post(mock_data))
    homepage_resp = MagicMock()
    homepage_resp.status_code = 200
    homepage_resp.raise_for_status = MagicMock()
    homepage_resp.text = "<html></html>"
    prime_session.get = AsyncMock(return_value=homepage_resp)
    prime_session.cookies = {"DID": "did-cookie", "DID_JS": "did-js-cookie"}

    gql_session = _mock_session(_mock_post(mock_data))
    gql_session.cookies = {"DID": "did-cookie", "DID_JS": "did-js-cookie"}

    gql_call = AsyncMock(side_effect=[RuntimeError("service unavailable"), mock_data])

    with patch("tokopedia_mcp.client._make_session", side_effect=[prime_session, gql_session]), \
         patch("tokopedia_mcp.client._ensure_fresh", new_callable=AsyncMock), \
         patch("tokopedia_mcp.client._gql", gql_call), \
         patch("tokopedia_mcp.client.asyncio.sleep", new_callable=AsyncMock) as sleep_mock:
        result = await tokopedia.generate_login_qr()

    assert result["uuid"] == "retry-token"
    assert gql_call.await_count == 2
    sleep_mock.assert_awaited_once()


@pytest.mark.asyncio
async def test_generate_login_qr_uses_env_retry_settings():
    mock_data = {
        "OTPRequestQR": {
            "is_success": True,
            "error_message": "",
            "token": "env-retry-token",
            "code": "",
            "status": "successrequestqr",
        }
    }

    prime_session = _mock_session(_mock_post(mock_data))
    homepage_resp = MagicMock()
    homepage_resp.status_code = 200
    homepage_resp.raise_for_status = MagicMock()
    homepage_resp.text = "<html></html>"
    prime_session.get = AsyncMock(return_value=homepage_resp)
    prime_session.cookies = {"DID": "did-cookie", "DID_JS": "did-js-cookie"}

    gql_session = _mock_session(_mock_post(mock_data))
    gql_session.cookies = {"DID": "did-cookie", "DID_JS": "did-js-cookie"}

    gql_call = AsyncMock(side_effect=[RuntimeError("service unavailable"), mock_data])

    with patch.dict(os.environ, {
        "TOKOPEDIA_QR_REQUEST_MAX_RETRIES": "2",
        "TOKOPEDIA_QR_REQUEST_BACKOFF_BASE_SECONDS": "0.1",
    }, clear=False), \
         patch("tokopedia_mcp.client._make_session", side_effect=[prime_session, gql_session]), \
         patch("tokopedia_mcp.client._ensure_fresh", new_callable=AsyncMock), \
         patch("tokopedia_mcp.client._gql", gql_call), \
         patch("tokopedia_mcp.client.asyncio.sleep", new_callable=AsyncMock) as sleep_mock:
        result = await tokopedia.generate_login_qr()

    assert result["uuid"] == "env-retry-token"
    assert gql_call.await_count == 2
    sleep_mock.assert_awaited_once_with(0.1)


# ---------------------------------------------------------------------------
# check_qr_login_status
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_check_qr_login_status_approved():
    """check_qr_login_status() must update cookie-backed auth state when approved via SSE."""
    original_auth = dict(tokopedia._auth_state)
    original_qr = dict(tokopedia._qr_login_state)

    response = MagicMock()
    response.status_code = 200
    response.raise_for_status = MagicMock()
    response.text = 'event:test-token\ndata:{"status_verification":2,"uuid":"approved-uuid-1"}\n\n'

    mock_session = AsyncMock()
    mock_session.__aenter__ = AsyncMock(return_value=mock_session)
    mock_session.__aexit__ = AsyncMock(return_value=None)
    mock_session.get = AsyncMock(return_value=response)
    mock_session.cookies = {"_SID_Tokopedia_": "approved-cookie"}

    tokopedia._qr_login_state.update({"token": "test-uuid-1234", "cookies": {"_SID_Tokopedia_": "pending-cookie"}})

    try:
        with patch("tokopedia_mcp.client._make_session", return_value=mock_session), \
             patch("tokopedia_mcp.client._ensure_fresh", new_callable=AsyncMock), \
             patch("tokopedia_mcp.client._get_profile_from_cookies", new_callable=AsyncMock,
                   return_value={"cookies": {"_SID_Tokopedia_": "approved-cookie"}, "user_id": "999"}):
            result = await tokopedia.check_qr_login_status("test-uuid-1234")

        assert result["status"] == "approved"
        assert result["logged_in"] is True
        assert result["user_id"] == "999"
        assert result["approved_uuid"] == "approved-uuid-1"
        assert tokopedia._auth_state["is_logged_in"] is True
        assert tokopedia._auth_state["access_token"] is None
        assert tokopedia._auth_state["cookies"] == {"_SID_Tokopedia_": "approved-cookie"}
    finally:
        tokopedia._auth_state.update(original_auth)
        tokopedia._qr_login_state.update(original_qr)


@pytest.mark.asyncio
async def test_check_qr_login_status_waiting():
    """check_qr_login_status() must return waiting status without touching auth."""
    original_is_logged_in = tokopedia._auth_state["is_logged_in"]
    response = MagicMock()
    response.status_code = 200
    response.raise_for_status = MagicMock()
    response.text = "event:test-token\ndata:{}\n\n"

    mock_session = AsyncMock()
    mock_session.__aenter__ = AsyncMock(return_value=mock_session)
    mock_session.__aexit__ = AsyncMock(return_value=None)
    mock_session.get = AsyncMock(return_value=response)
    mock_session.cookies = {}

    with patch("tokopedia_mcp.client._make_session", return_value=mock_session), \
         patch("tokopedia_mcp.client._ensure_fresh", new_callable=AsyncMock):
        result = await tokopedia.check_qr_login_status("test-uuid-5678")

    assert result["status"] == "waiting"
    assert result["logged_in"] is False
    assert tokopedia._auth_state["is_logged_in"] == original_is_logged_in


@pytest.mark.asyncio
async def test_wait_for_qr_login_approval_stops_on_approved():
    status_calls = AsyncMock(side_effect=[
        {"status": "waiting", "logged_in": False},
        {"status": "approved", "logged_in": True, "user_id": "321"},
    ])

    with patch("tokopedia_mcp.client.check_qr_login_status", status_calls), \
         patch("tokopedia_mcp.client.asyncio.sleep", new_callable=AsyncMock) as sleep_mock:
        result = await tokopedia.wait_for_qr_login_approval("uuid-1", timeout_seconds=30, poll_interval_seconds=0.1)

    assert result["status"] == "approved"
    assert result["logged_in"] is True
    assert result["attempts"] == 2
    assert result["timed_out"] is False
    sleep_mock.assert_awaited_once()


@pytest.mark.asyncio
async def test_wait_for_qr_login_approval_timeout():
    status_calls = AsyncMock(return_value={"status": "waiting", "logged_in": False})

    with patch("tokopedia_mcp.client.check_qr_login_status", status_calls), \
         patch("tokopedia_mcp.client.asyncio.sleep", new_callable=AsyncMock), \
         patch("tokopedia_mcp.client.time.monotonic", side_effect=[0.0, 0.0, 2.0]):
        result = await tokopedia.wait_for_qr_login_approval("uuid-2", timeout_seconds=1, poll_interval_seconds=1.2)

    assert result["status"] == "timeout"
    assert result["logged_in"] is False
    assert result["timed_out"] is True
    assert result["attempts"] == 1


@pytest.mark.asyncio
async def test_wait_for_qr_login_approval_validates_input():
    with pytest.raises(ValueError, match="uuid is required"):
        await tokopedia.wait_for_qr_login_approval("")

    with pytest.raises(ValueError, match="timeout_seconds must be > 0"):
        await tokopedia.wait_for_qr_login_approval("uuid-3", timeout_seconds=0)

    with pytest.raises(ValueError, match="poll_interval_seconds must be > 0"):
        await tokopedia.wait_for_qr_login_approval("uuid-3", poll_interval_seconds=0)


@pytest.mark.asyncio
async def test_wait_for_qr_login_approval_uses_env_defaults_when_omitted():
    status_calls = AsyncMock(return_value={"status": "waiting", "logged_in": False})

    with patch.dict(os.environ, {
        "TOKOPEDIA_QR_WAIT_TIMEOUT_SECONDS": "1",
        "TOKOPEDIA_QR_WAIT_POLL_INTERVAL_SECONDS": "0.5",
    }, clear=False), \
         patch("tokopedia_mcp.client.check_qr_login_status", status_calls), \
         patch("tokopedia_mcp.client.asyncio.sleep", new_callable=AsyncMock) as sleep_mock, \
         patch("tokopedia_mcp.client.time.monotonic", side_effect=[0.0, 0.0, 2.0]):
        result = await tokopedia.wait_for_qr_login_approval("uuid-env")

    assert result["status"] == "timeout"
    assert result["attempts"] == 1
    sleep_mock.assert_awaited_once_with(0.5)


@pytest.mark.asyncio
async def test_search_products_respects_requested_rows_when_backend_returns_more():
    products = []
    for index in range(5):
        products.append({
            "id": str(index),
            "id_str_auto_": str(index),
            "name": f"USB Hub {index}",
            "url": f"https://tok.com/shop/hub-{index}",
            "mediaURL": {"image": f"img-{index}.jpg"},
            "shop": {"name": "Shop", "city": "JKT", "tier": 2},
            "price": {"text": "Rp50.000", "number": 50000, "original": None, "discountPercentage": 0},
            "badge": {"title": "Best Seller"},
            "category": {"name": "Electronics"},
            "rating": 4.8,
        })

    async def fake_post(url, **kwargs):
        resp = MagicMock()
        resp.status_code = 200
        resp.raise_for_status = MagicMock()
        resp.json.return_value = [{"data": {"searchProductV5": {"header": {"totalData": 5}, "data": {"products": products}}}}]
        return resp

    with patch("tokopedia_mcp.client._make_session", return_value=_mock_session(fake_post)):
        result = await tokopedia.search_products("usb hub", rows=3)

    assert result["rows"] == 3
    assert len(result["products"]) == 3
    assert "image" not in result["products"][0]


@pytest.mark.asyncio
async def test_search_products_includes_images_when_requested():
    async def fake_post(url, **kwargs):
        resp = MagicMock()
        resp.status_code = 200
        resp.raise_for_status = MagicMock()
        resp.json.return_value = [{"data": {"searchProductV5": {"header": {"totalData": 1}, "data": {"products": [{
            "id": "1",
            "name": "USB Hub",
            "url": "https://tok.com/shop/hub",
            "mediaURL": {"image": "img.jpg"},
            "shop": {"name": "Shop", "city": "JKT", "tier": 2},
            "price": {"text": "Rp50.000", "number": 50000, "original": None, "discountPercentage": 0},
            "badge": {"title": "Best Seller"},
            "category": {"name": "Electronics"},
            "rating": 4.8,
        }]}}}}]
        return resp

    with patch("tokopedia_mcp.client._make_session", return_value=_mock_session(fake_post)):
        result = await tokopedia.search_products("usb hub", include_images=True)

    assert result["products"][0]["image"] == "img.jpg"


# ---------------------------------------------------------------------------
# get_current_user
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_get_current_user_not_logged_in():
    """get_current_user() must return an error when the user is not authenticated."""
    original_auth = dict(tokopedia._auth_state)
    tokopedia._auth_state["is_logged_in"] = False
    try:
        result = await tokopedia.get_current_user()
    finally:
        tokopedia._auth_state.update(original_auth)

    assert "error" in result
    assert "login" in result["error"].lower() or "logged" in result["error"].lower()


@pytest.mark.asyncio
async def test_get_current_user_logged_in():
    """get_current_user() must return profile data when authenticated."""
    original_auth = dict(tokopedia._auth_state)
    tokopedia._auth_state.update({"is_logged_in": True, "email": "user@example.com",
                                   "access_token": "tok", "user_id": "7"})

    mock_data = {
        "profileHeader": {
            "data": {
                "id": "7", "fullName": "Test User", "userID": "7",
                "imagePath": "avatar.jpg", "bio": "Hello world",
                "stats": {"follower": 10, "following": 5, "review": 3},
            }
        }
    }

    try:
        with patch("tokopedia_mcp.client._make_session", return_value=_mock_session(_mock_post(mock_data))):
            result = await tokopedia.get_current_user()
    finally:
        tokopedia._auth_state.update(original_auth)

    assert result["full_name"] == "Test User"
    assert result["email"] == "user@example.com"
    assert result["followers"] == 10


# ---------------------------------------------------------------------------
# get_wishlist
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_get_wishlist_not_logged_in():
    """get_wishlist() must return an error when the user is not authenticated."""
    original_auth = dict(tokopedia._auth_state)
    tokopedia._auth_state["is_logged_in"] = False
    try:
        result = await tokopedia.get_wishlist()
    finally:
        tokopedia._auth_state.update(original_auth)

    assert "error" in result


@pytest.mark.asyncio
async def test_get_wishlist_logged_in():
    """get_wishlist() must return paginated wishlist data when authenticated."""
    original_auth = dict(tokopedia._auth_state)
    tokopedia._auth_state.update({"is_logged_in": True, "access_token": "tok", "user_id": "7"})

    mock_data = {
        "get_wishlist_collection_items": {
            "total_data": 5,
            "items": [
                {
                    "id": "p1",
                    "name": "Wishlist Item",
                    "image_url": "img.jpg",
                    "url": "url",
                    "price_fmt": "Rp100.000",
                    "rating": 4.5,
                    "sold_count": 20,
                    "shop": {"name": "TechShop", "location": "Jakarta"},
                }
            ],
        }
    }

    try:
        with patch("tokopedia_mcp.client._make_session", return_value=_mock_session(_mock_post(mock_data))):
            result = await tokopedia.get_wishlist(page=1, per_page=10)
    finally:
        tokopedia._auth_state.update(original_auth)

    assert result["total"] == 5
    assert result["page"] == 1
    assert result["products"][0]["name"] == "Wishlist Item"
