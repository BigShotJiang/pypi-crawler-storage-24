"""Unit tests for the FastMCP server tool registration."""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest

from tokopedia_mcp import server
from tokopedia_mcp.server import mcp


def test_server_has_expected_tools() -> None:
    """All tools must be registered on the MCP server."""
    expected = {
        # Auth
        "login",
        "logout",
        "generate_login_qr",
        "check_qr_login_status",
        "wait_for_qr_login_approval",
        "get_current_user",
        "get_wishlist",
        "add_to_wishlist",
        "remove_from_wishlist",
        # Products & search
        "search_products",
        "get_product_detail",
        "get_product_reviews",
        # Shops
        "get_shop_info",
        "search_shops",
        "get_shop_products",
        # Media
        "get_review_media",
        "download_media",
    }
    # FastMCP exposes tools through _tool_manager
    registered = {t.name for t in mcp._tool_manager.list_tools()}
    assert expected == registered


def test_server_name() -> None:
    assert mcp.name == "tokopedia-mcp-server"


def test_err_payload_has_machine_readable_fields() -> None:
    payload = server._err(ValueError("uuid is required"))

    assert payload["ok"] is False
    assert payload["error"] == "ValueError"
    assert payload["error_code"] == "invalid_input"
    assert payload["retryable"] is False
    assert "hint" in payload


@pytest.mark.parametrize(
    ("exc", "expected_code", "retryable"),
    [
        (TimeoutError("request timed out"), "upstream_timeout", True),
        (RuntimeError("service unavailable"), "upstream_unavailable", True),
        (RuntimeError("unexpected upstream payload"), "upstream_error", False),
        (ImportError("playwright missing"), "dependency_missing", False),
    ],
)
def test_error_classification_variants(exc: Exception, expected_code: str, retryable: bool) -> None:
    payload = server._err(exc)
    assert payload["error_code"] == expected_code
    assert payload["retryable"] is retryable


@pytest.mark.asyncio
async def test_login_tool_returns_structured_error() -> None:
    with patch("tokopedia_mcp.server.tokopedia.login", AsyncMock(side_effect=ValueError("bad credentials"))):
        result = await server.login("user@example.com", "wrong")

    assert result["ok"] is False
    assert result["error_code"] == "invalid_input"
    assert result["message"] == "bad credentials"
