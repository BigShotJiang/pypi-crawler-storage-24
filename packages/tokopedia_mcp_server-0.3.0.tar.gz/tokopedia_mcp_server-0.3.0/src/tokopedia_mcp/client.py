"""Async Tokopedia GraphQL API client.

Uses curl-cffi for browser-grade TLS fingerprinting.

Root-cause fixes derived from HAR analysis (2026-03-14):
  [CRITICAL] GQL URL must include operation name: /graphql/{OperationName}
  [CRITICAL] Search uses searchProductV5, not ace_search_product_v4
  [CRITICAL] x-version is Tokopedia's frontend build hash — fetched dynamically
  [CRITICAL] Missing headers: bd-device-id, bd-web-id, x-price-center, x-dark-mode
  [CRITICAL] x-device must be "desktop-0.0" not "desktop"
  [CRITICAL] Search params: 20+ required fields were absent
  [FIX]      Retry with exponential back-off for transient errors
  [FIX]      price_min / price_max filter support
  [FIX]      Full pagination via page + rows (max 60/page)
  [FIX]      impersonate="chrome" (latest) — UA set automatically by curl_cffi
  [FIX]      x-version auto-refreshed from Tokopedia homepage (1 h TTL)
"""

from __future__ import annotations

import asyncio
import base64
import io
import json
import logging
import os
import random
import re
import string
import time
import urllib.parse
import uuid
from typing import Any, cast

import qrcode
import qrcode.constants
from curl_cffi.requests import AsyncSession
from PIL import Image
from selectolax.parser import HTMLParser

logger = logging.getLogger(__name__)

# CRITICAL: operation name goes IN the path
GQL_BASE_URL = "https://gql.tokopedia.com/graphql/"
LOGIN_URL = "https://accounts.tokopedia.com/token"
QR_STATUS_STREAM_URL = "https://sse.tokopedia.com/otp/qr/event-validate"
TOKOPEDIA_HOME_URL = "https://www.tokopedia.com/"

# Generates a stable random device-id for this process lifetime
_DEVICE_ID = str(random.randint(10**18, 10**19 - 1))

_DEFAULT_HEADERS: dict[str, str] = {
    "Content-Type": "application/json",
    "Referer": "https://www.tokopedia.com/",
    "Origin": "https://www.tokopedia.com",
    "Accept": "*/*",
    "Accept-Language": "en-US,id;q=0.9,en;q=0.8",
    # Required headers from HAR analysis
    "x-tkpd-lite-service": "zeus",
    "x-price-center": "true",
    "x-version": "50c57b0",  # refreshed at runtime by _ensure_fresh()
    "content-type": "application/json",
    "x-device": "desktop-0.0",
    "x-dark-mode": "false",
    "x-source": "tokopedia-lite",
    "bd-device-id": _DEVICE_ID,
    "bd-web-id": _DEVICE_ID,
    "tkpd-userid": "0",
    "iris_session_id": "",
}

# ---------------------------------------------------------------------------
# Auth state
# ---------------------------------------------------------------------------

_auth_state: dict[str, Any] = {
    "access_token": None,
    "token_type": "bearer",
    "user_id": None,
    "email": None,
    "cookies": {},
    "is_logged_in": False,
}

_qr_login_state: dict[str, Any] = {
    "token": None,
    "cookies": {},
    "status": None,
    "approved_uuid": None,
}

_TRANSIENT_QR_ERROR_MARKERS = (
    "service unavailable",
    "service not available",
    "temporarily unavailable",
    "timeout",
    "timed out",
    "try again",
)

_ENV_QR_WAIT_TIMEOUT_SECONDS = "TOKOPEDIA_QR_WAIT_TIMEOUT_SECONDS"
_ENV_QR_WAIT_POLL_INTERVAL_SECONDS = "TOKOPEDIA_QR_WAIT_POLL_INTERVAL_SECONDS"
_ENV_QR_REQUEST_MAX_RETRIES = "TOKOPEDIA_QR_REQUEST_MAX_RETRIES"
_ENV_QR_REQUEST_BACKOFF_BASE_SECONDS = "TOKOPEDIA_QR_REQUEST_BACKOFF_BASE_SECONDS"
_ENV_DEFAULT_USER_ADDRESS_ID = "TOKOPEDIA_DEFAULT_USER_ADDRESS_ID"
_ENV_DEFAULT_USER_CITY_ID = "TOKOPEDIA_DEFAULT_USER_CITY_ID"
_ENV_DEFAULT_USER_DISTRICT_ID = "TOKOPEDIA_DEFAULT_USER_DISTRICT_ID"
_ENV_DEFAULT_USER_WAREHOUSE_ID = "TOKOPEDIA_DEFAULT_USER_WAREHOUSE_ID"
_ENV_DEFAULT_USER_POSTAL_CODE = "TOKOPEDIA_DEFAULT_USER_POSTAL_CODE"
_ENV_DEFAULT_USER_LAT = "TOKOPEDIA_DEFAULT_USER_LAT"
_ENV_DEFAULT_USER_LONG = "TOKOPEDIA_DEFAULT_USER_LONG"

# ---------------------------------------------------------------------------
# Sort options
# ---------------------------------------------------------------------------
SORT_OPTIONS: dict[str, int] = {
    "best_match": 23,
    "newest": 9,
    "highest_sales": 8,
    "lowest_price": 5,
    "highest_price": 6,
    "most_reviews": 3,
}

# ---------------------------------------------------------------------------
# Dynamic header refresh — x-version
#
# x-version is Tokopedia's frontend build hash; it changes with every
# deployment.  We fetch the current value from the Tokopedia homepage and
# cache it for _VERSION_TTL seconds.  On failure the existing value is kept.
# ---------------------------------------------------------------------------

_VERSION_TTL: float = 3600.0  # seconds
_version_expires: float = 0.0
_HEX_CHARS: frozenset[str] = frozenset("0123456789abcdef")
_WINDOW_VERSION_ASSIGN_RE = re.compile(r"window\.version\s*=\s*[\"']([0-9a-f]{40})[\"']")
_WINDOW_VERSION_JSON_RE = re.compile(r"[\"']version[\"']\s*:\s*[\"']([0-9a-f]{40})[\"']")
_SCRIPT_SRC_RE = re.compile(r"<script\b[^>]*\bsrc=[\"']([^\"']+)[\"'][^>]*>", re.IGNORECASE)
_SRC_SHA1_RE = re.compile(r"(?:[/?=&_-])([0-9a-f]{40})(?:[/?&._-]|$)")
_WINDOW_CACHE_MARKER = "window.__cache="
_WINDOW_STATE_MARKER = "window.__state="
_VARIANT_GROUP_PATH_RE = re.compile(r"\.variants\.(\d+)$")
_VARIANT_OPTION_PATH_RE = re.compile(r"\.variants\.(\d+)\.option\.\d+$")
_VARIANT_CHILD_PATH_RE = re.compile(r"\.children\.\d+$")
_PDP_BASIC_INFO_KEY_RE = re.compile(r"^pdpBasicInfo\d+$")


def _env_int(name: str, default: int, minimum: int) -> int:
    raw = os.getenv(name)
    if raw is None or raw == "":
        return default
    try:
        value = int(raw)
    except ValueError:
        logger.warning("Invalid %s=%r, falling back to %d", name, raw, default)
        return default
    if value < minimum:
        logger.warning("Invalid %s=%r, must be >= %d; falling back to %d", name, raw, minimum, default)
        return default
    return value


def _env_float(name: str, default: float, minimum: float) -> float:
    raw = os.getenv(name)
    if raw is None or raw == "":
        return default
    try:
        value = float(raw)
    except ValueError:
        logger.warning("Invalid %s=%r, falling back to %.3f", name, raw, default)
        return default
    if value < minimum:
        logger.warning("Invalid %s=%r, must be >= %.3f; falling back to %.3f", name, raw, minimum, default)
        return default
    return value


def _env_str(name: str, default: str) -> str:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip()


def _compact_text(value: Any) -> str:
    if not isinstance(value, str):
        return ""
    return " ".join(value.split())


def _compact_rich_text(value: Any) -> str:
    if isinstance(value, list):
        joined = " ".join(part for part in value if isinstance(part, str))
        return _compact_rich_text(joined)
    if not isinstance(value, str):
        return ""
    text = re.sub(r"<[^>]+>", " ", value)
    return _compact_text(text)


def _normalize_match_text(value: str) -> str:
    return re.sub(r"[^0-9a-z]+", " ", value.lower()).strip()


def _resolve_cache_value(cache: dict[str, Any] | None, value: Any, depth: int = 0) -> Any:
    if depth > 3 or not isinstance(value, dict):
        return value

    value_type = value.get("type")
    if value_type == "json":
        return value.get("json")
    if value_type == "id":
        ref_id = value.get("id")
        if isinstance(ref_id, str) and cache:
            return _resolve_cache_value(cache, cache.get(ref_id), depth + 1)
    return value


def _value_to_text(value: Any) -> str:
    if isinstance(value, str):
        return _compact_text(value)
    if isinstance(value, list):
        parts = [_value_to_text(item) for item in value]
        parts = [part for part in parts if part]
        return ", ".join(parts)
    return ""


def _extract_int_value(value: Any) -> int | None:
    as_int = _coerce_int(value)
    if as_int is not None:
        return as_int
    if isinstance(value, dict):
        for key in ("value", "price", "amount", "stock", "quantity"):
            nested = _coerce_int(value.get(key))
            if nested is not None:
                return nested
    return None


def _coerce_int(value: Any) -> int | None:
    if value is None:
        return None
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        return None


_LOW_SIGNAL_REVIEW_PATTERNS: tuple[re.Pattern[str], ...] = (
    # just-arrived, not yet used
    re.compile(r"\bbarang(?:nya)?\s+(?:baru\s+)?samp(?:a|e)i\b", re.IGNORECASE),
    re.compile(r"\bbaru\s+(?:tiba|terima|diterima)\b", re.IGNORECASE),
    re.compile(r"\b(?:cepat|langsung)\s+sampai\b", re.IGNORECASE),
    re.compile(r"\b(?:belum|blm|belom)\s+(?:di)?coba\b", re.IGNORECASE),
    re.compile(r"\b(?:belum|blm|belom)\s+(?:di)?(?:test|tes)\b", re.IGNORECASE),
    re.compile(r"\b(?:belum|blm|belom)\s+digunakan\b", re.IGNORECASE),
    # shipping/packaging only praise
    re.compile(r"\bpacking\s+(?:rapi|aman|baik|bagus|oke|ok)\b", re.IGNORECASE),
    re.compile(r"\bpengiriman(?:nya)?\s+(?:cepat|aman|oke|ok|tepat\s+waktu)\b", re.IGNORECASE),
    re.compile(r"\bseller\s+(?:responsif|fast\s+respon|ramah|baik)\b", re.IGNORECASE),
    re.compile(r"\bpenjual\s+(?:responsif|fast\s+respon|ramah|baik)\b", re.IGNORECASE),
    # pure wishful/hope phrases
    re.compile(r"\bsemoga\s+(?:awet|tahan\s+lama|memuaskan|bagus)\b", re.IGNORECASE),
    re.compile(r"\bmudah[- ]mudahan\s+(?:awet|bagus|memuaskan)\b", re.IGNORECASE),
)

_REVIEW_USAGE_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"\b(?:sudah|udah|telah)\s+(?:di)?(?:coba|tes|test|pakai|gunakan|konsumsi|pasang|install|buka)\b", re.IGNORECASE),
    re.compile(r"\b(?:berfungsi|works?|working|cocok|pas|sesuai)\b", re.IGNORECASE),
    # food-specific: confirming taste/consumption
    re.compile(r"\b(?:enak|lezat|gurih|renyah|manis|asin|pedas|segar|mantap)\b", re.IGNORECASE),
)

_REVIEW_ATTRIBUTE_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"\b(?:kualitas|quality|bahan|material|ukuran|warna|rasa|aroma|tekstur|jahitan|finishing|fit)\b", re.IGNORECASE),
    re.compile(r"\b(?:nyaman|lembut|halus|kokoh|ringan|berat|tipis|tebal|rusak|cacat|pecah|patah|error)\b", re.IGNORECASE),
    # common clothing attributes seen in real reviews
    re.compile(r"\b(?:adem|sablon|corak|motif|desain|model|potongan|size)\b", re.IGNORECASE),
    # food/product condition attributes
    re.compile(r"\b(?:exp|expired|kadaluarsa|basi|lengkap|isinya|porsi)\b", re.IGNORECASE),
)


def _is_low_signal_review(title: str, content: str) -> bool:
    text = _compact_text(f"{title} {content}").lower()
    if not text:
        return True
    if any(pattern.search(text) for pattern in _REVIEW_USAGE_PATTERNS):
        return False
    if any(pattern.search(text) for pattern in _REVIEW_ATTRIBUTE_PATTERNS):
        return False
    return any(pattern.search(text) for pattern in _LOW_SIGNAL_REVIEW_PATTERNS)


def _default_user_location() -> dict[str, str]:
    return {
        "address_id": _env_str(_ENV_DEFAULT_USER_ADDRESS_ID, "0"),
        "city_id": _env_str(_ENV_DEFAULT_USER_CITY_ID, ""),
        "district_id": _env_str(_ENV_DEFAULT_USER_DISTRICT_ID, ""),
        "warehouse_id": _env_str(_ENV_DEFAULT_USER_WAREHOUSE_ID, ""),
        "postal_code": _env_str(_ENV_DEFAULT_USER_POSTAL_CODE, ""),
        "lat": _env_str(_ENV_DEFAULT_USER_LAT, ""),
        "long": _env_str(_ENV_DEFAULT_USER_LONG, ""),
    }


def _search_location_params(*, user_id: str) -> dict[str, str]:
    defaults = _default_user_location()
    return {
        "user_addressId": defaults["address_id"],
        "user_cityId": defaults["city_id"],
        "user_districtId": defaults["district_id"],
        "user_id": user_id,
        "user_lat": defaults["lat"],
        "user_long": defaults["long"],
        "user_postCode": defaults["postal_code"],
        "user_warehouseId": defaults["warehouse_id"],
    }


def _product_user_location() -> dict[str, str]:
    defaults = _default_user_location()
    latlon = ""
    if defaults["lat"] and defaults["long"]:
        latlon = f"{defaults['lat']},{defaults['long']}"
    return {
        "addressID": defaults["address_id"],
        "districtID": defaults["district_id"],
        "postalCode": defaults["postal_code"],
        "latlon": latlon,
        "cityID": defaults["city_id"],
    }


def _shop_products_location_params() -> dict[str, str]:
    defaults = _default_user_location()
    return {
        "user_districtId": defaults["district_id"],
        "user_cityId": defaults["city_id"],
        "user_lat": defaults["lat"],
        "user_long": defaults["long"],
    }


async def _ensure_fresh() -> None:
    """Refresh dynamic headers (x-version) when the cache is stale.

    Tokopedia embeds the current frontend build commit in the homepage HTML as an
    inline <script> tag containing:
        window.version="<full-sha1>"
    The ``x-version`` request header uses the first 7 characters of that SHA1,
    matching the git short-hash format (e.g. "50c57b0").

    selectolax is used to locate the <script> node; the value is then extracted
    with plain string operations — no regex involved.
    """
    global _version_expires
    if time.monotonic() < _version_expires:
        return
    try:
        async with AsyncSession(impersonate="chrome", timeout=10.0) as _s:
            _r = await _s.get(
                "https://www.tokopedia.com/",
                headers={
                    "Referer": "https://www.tokopedia.com/",
                    "Origin": "https://www.tokopedia.com",
                    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                },
            )
            if _r.status_code == 200:
                _version = _extract_window_version(_r.text)
                if _version:
                    _DEFAULT_HEADERS["x-version"] = _version
                    logger.debug("x-version refreshed to %s", _DEFAULT_HEADERS["x-version"])
    except Exception as _exc:
        logger.debug("x-version refresh failed: %s", _exc)
    _version_expires = time.monotonic() + _VERSION_TTL


def _extract_window_version(html: str) -> str | None:
    """Return the 7-char x-version short-hash from a Tokopedia homepage HTML string.

    Uses selectolax to locate inline <script> tags, then extracts the value of
    ``window.version`` with plain string operations.  Returns ``None`` when the
    value cannot be found or does not look like a valid SHA1.
    """
    assign_match = _WINDOW_VERSION_ASSIGN_RE.search(html)
    if assign_match:
        return assign_match.group(1)[:7]

    json_match = _WINDOW_VERSION_JSON_RE.search(html)
    if json_match:
        return json_match.group(1)[:7]

    for src in _SCRIPT_SRC_RE.findall(html):
        src_match = _SRC_SHA1_RE.search(src)
        if src_match:
            return src_match.group(1)[:7]

    _MARKER = "window.version="
    _SHA1_LEN = 40
    _SHORT_LEN = 7

    for node in HTMLParser(html).css("script"):
        text = node.text(strip=True)
        if _MARKER not in text:
            continue
        idx = text.find(_MARKER)
        rest = text[idx + len(_MARKER):]
        if not rest or rest[0] not in ('"', "'"):
            continue
        quote = rest[0]
        end = rest.find(quote, 1)
        if end == -1:
            continue
        candidate = rest[1:end]
        if len(candidate) == _SHA1_LEN and all(c in _HEX_CHARS for c in candidate):
            return candidate[:_SHORT_LEN]
    return None

# ---------------------------------------------------------------------------
# GraphQL queries — using correct API names from HAR
# ---------------------------------------------------------------------------

_SEARCH_QUERY_V5 = """
query SearchProductV5Query($params: String!) {
  searchProductV5(params: $params) {
    header {
      totalData
      responseCode
      keywordProcess
      additionalParams
      __typename
    }
    data {
      products {
        oldID: id
        id: id_str_auto_
        name
        url
        mediaURL {
          image
          __typename
        }
        shop {
          oldID: id
          id: id_str_auto_
          name
          url
          city
          tier
          __typename
        }
        badge {
          oldID: id
          id: id_str_auto_
          title
          url
          __typename
        }
        price {
          text
          number
          range
          original
          discountPercentage
          __typename
        }
        labelGroups {
          position
          title
          type
          url
          __typename
        }
        category {
          oldID: id
          id: id_str_auto_
          name
          __typename
        }
        rating
        __typename
      }
      __typename
    }
    __typename
  }
}
"""

_PRODUCT_DETAIL_QUERY = """
query PDPMainInfo(
    $productKey: String,
    $shopDomain: String,
    $layoutID: String,
    $extraPayload: String,
    $queryParam: String,
    $source: String,
    $userLocation: pdpUserLocation
) {
    pdpMainInfo(
        shopDomain: $shopDomain,
        productKey: $productKey,
        layoutID: $layoutID,
        extraPayload: $extraPayload,
        queryParam: $queryParam,
        source: $source,
        userLocation: $userLocation
    ) {
        data {
            basicInfo {
                alias
                id: productID
                shopID
                shopName
                minOrder
                maxOrder
                weight
                weightUnit
                condition
                status
                url
                txStats {
                    itemSoldFmt
                    countSold
                    paymentVerified
                }
                stats {
                    countReview
                    rating
                }
                category {
                    name
                }
            }
            components {
                name
                type
                data
            }
        }
    }
}
"""

_REVIEWS_QUERY = """
query productReviewList(
  $productID: String!,
  $page: Int!,
  $limit: Int!,
  $sortBy: String,
  $filterBy: String
) {
    productrevGetProductReviewList(
    productID: $productID,
    page: $page,
    limit: $limit,
    sortBy: $sortBy,
    filterBy: $filterBy
  ) {
        productID
    list {
            feedbackID
            reviewCreateTime
            reviewCreateTimestamp
            variantName
      message
      productRating
            isReportable
            isAnonymous
      imageAttachments { attachmentID imageThumbnailUrl imageUrl }
            videoAttachments { attachmentID videoUrl }
            reviewResponse { message createTime }
            user { userID fullName image url }
            likeDislike { totalLike likeStatus }
            stats { key formatted count }
            badRatingReasonFmt
    }
        shop { shopID name url image }
    hasNext
    totalReviews
  }
}
"""

_SHOP_INFO_QUERY = """
query ShopInfoCore($id: Int!, $domain: String) {
  shopInfoByID(
    input: {
            shopIDs: [$id]
            fields: ["active_product", "allow_manage_all", "assets", "core", "closed_info", "create_info", "favorite", "location", "status", "is_open", "other-goldos", "shipment", "shopstats", "shop-snippet", "other-shiploc", "shopHomeType", "goapotik", "fs_type"]
      domain: $domain
            source: "shoppage"
    }
  ) {
    result {
            shopCore { shopID name domain defaultSort }
            shopAssets { avatar cover }
            favoriteData { totalFavorite alreadyFavorited }
            activeProduct
            location
            shippingLoc { districtName cityName }
            goldOS { isGold isGoldBadge isOfficial badge shopTier }
            shopStats { productSold totalTxSuccess totalShowcase }
    }
    error { message }
  }
}
"""

_SEARCH_SHOPS_QUERY = """
query SearchShopQuery($params: String) {
  aceSearchShopV2(params: $params) {
    header { totalData responseCode errorMessage }
    data {
      shops {
        shopID name shopDomain avatarURL city
        isGold isGoldBadge isOfficial
        rating totalReview
        productList { id name price imageUrl url }
      }
    }
  }
}
"""

_SHOP_PRODUCTS_QUERY = """
query ShopProducts(
    $sid: String!,
    $source: String,
  $page: Int,
  $perPage: Int,
  $keyword: String,
    $etalaseId: String,
  $sort: Int
    $user_districtId: String,
    $user_cityId: String,
    $user_lat: String,
    $user_long: String,
    $usecase: String
) {
  GetShopProduct(
        shopID: $sid,
        source: $source,
        filter: {
            page: $page
            perPage: $perPage
            fkeyword: $keyword
            fmenu: $etalaseId
            sort: $sort
            user_districtId: $user_districtId
            user_cityId: $user_cityId
            user_lat: $user_lat
            user_long: $user_long
            usecase: $usecase
        }
  ) {
    status
        links { prev next }
    data {
            name product_id product_url
            price { text_idr }
            primary_image { thumbnail }
            stats { averageRating reviewCount }
    }
  }
}
"""

_PROFILE_QUERY = """
query ProfileHeaderQuery {
  profileHeader {
    data {
      id fullName userID imagePath bio
      stats { follower following review }
    }
  }
}
"""

_WISHLIST_QUERY = """
query GetWishlistCollectionItems($page: Int!, $per_page: Int!) {
    get_wishlist_collection_items(page: $page, per_page: $per_page) {
        total_data
        items {
            id
            name
            image_url
            url
            price_fmt
            rating
            sold_count
            shop { name location }
        }
    }
}
"""

_WISHLIST_ADD_MUTATION = """
mutation WishlistAddV2($product_id: String!) {
    wishlist_add_v2(product_id: $product_id) {
        success
        message
    }
}
"""

_WISHLIST_REMOVE_MUTATION = """
mutation WishlistRemoveV2($product_id: String!) {
    wishlist_remove_v2(product_id: $product_id) {
        success
        message
    }
}
"""

_QR_LOGIN_REQUEST_QUERY = """
query OTPRequestQRQuery($token: String) {
  OTPRequestQR(token: $token) {
    is_success
    error_message
    token
    code
    status
    __typename
  }
}
"""

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _parse_product_url(product_url: str) -> tuple[str, str]:
    parsed = urllib.parse.urlparse(product_url.strip())
    parts = [p for p in parsed.path.split("/") if p]
    if len(parts) < 2:
        raise ValueError(
            f"Cannot parse shop_domain/product_key from URL: {product_url!r}. "
            "Expected: https://www.tokopedia.com/<shop>/<product>"
        )
    return parts[0], parts[1]


async def _resolve_product_detail_url(product_url: str) -> str:
    normalized_url = product_url.strip()
    parsed = urllib.parse.urlparse(normalized_url)
    host = parsed.netloc.lower()
    parts = [p for p in parsed.path.split("/") if p]

    if host in {"www.tokopedia.com", "tokopedia.com"} and len(parts) >= 2:
        return normalized_url

    async with _make_session() as session:
        response = await session.get(
            normalized_url,
            allow_redirects=True,
            headers={
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "Referer": TOKOPEDIA_HOME_URL,
            },
        )
        response.raise_for_status()

    final_url = getattr(response, "url", None)
    if isinstance(final_url, bytes):
        final_url = final_url.decode("utf-8", errors="ignore")
    return str(final_url or normalized_url)


def _make_session(timeout: float = 30.0, *, extra_cookies: dict[str, str] | None = None, **kwargs: Any) -> AsyncSession:
    """curl-cffi session with Chrome TLS fingerprint (latest version auto-selected).

    User-Agent is intentionally omitted from headers so that curl_cffi's
    impersonation sets it automatically, keeping the TLS fingerprint and UA
    consistent without hardcoding a specific browser version string.
    """
    headers = dict(_DEFAULT_HEADERS)
    cookies: dict[str, str] = {}

    if _auth_state["is_logged_in"]:
        if _auth_state["access_token"]:
            headers["Authorization"] = (
                f"{_auth_state['token_type'].capitalize()} "
                f"{_auth_state['access_token']}"
            )
        if _auth_state.get("user_id"):
            headers["tkpd-userid"] = str(_auth_state["user_id"])
        cookies = dict(_auth_state.get("cookies") or {})

    if extra_cookies:
        cookies.update(extra_cookies)

    return AsyncSession(
        impersonate="chrome",
        headers=headers,
        cookies=cookies,
        timeout=timeout,
        **kwargs,
    )


def _build_qr_code(content: str) -> dict[str, str]:
    qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_L, box_size=10, border=4)
    qr.add_data(content)
    qr.make(fit=True)
    buf = io.BytesIO()
    qr.make_image(fill_color="black", back_color="white").save(buf, "PNG")
    ascii_buf = io.StringIO()
    qr.print_ascii(out=ascii_buf)
    return {"png_base64": base64.b64encode(buf.getvalue()).decode(), "ascii": ascii_buf.getvalue()}


def _image_base64_to_png_base64(image_base64: str) -> str:
    image = Image.open(io.BytesIO(base64.b64decode(image_base64)))
    png_buf = io.BytesIO()
    image.save(png_buf, "PNG")
    return base64.b64encode(png_buf.getvalue()).decode()


def _extract_session_cookies(session: AsyncSession) -> dict[str, str]:
    jar = getattr(session, "cookies", None)
    if jar is None:
        return {}
    if hasattr(jar, "items"):
        return {str(key): str(value) for key, value in jar.items()}
    return {str(key): str(value) for key, value in dict(jar).items()}


def _parse_qr_status_stream(stream_text: str) -> dict[str, Any] | None:
    payload: dict[str, Any] | None = None
    for line in stream_text.splitlines():
        if not line.startswith("data:"):
            continue
        raw = line[5:].strip()
        if not raw or raw == "{}":
            continue
        try:
            candidate = json.loads(raw)
        except json.JSONDecodeError:
            continue
        if isinstance(candidate, dict):
            payload = candidate
    return payload


async def _get_profile_from_cookies(cookies: dict[str, str]) -> dict[str, Any]:
    async with _make_session(extra_cookies=cookies) as session:
        data = await _gql(session, "ProfileHeaderQuery", _PROFILE_QUERY, {})
        merged_cookies = _extract_session_cookies(session)

    profile = (data.get("profileHeader") or {}).get("data") or {}
    stats = profile.get("stats") or {}
    return {
        "cookies": merged_cookies or cookies,
        "user_id": profile.get("userID"),
        "full_name": profile.get("fullName"),
        "bio": profile.get("bio"),
        "avatar_url": profile.get("imagePath"),
        "followers": stats.get("follower"),
        "following": stats.get("following"),
        "reviews": stats.get("review"),
    }


async def _prime_tokopedia_session(session: AsyncSession) -> None:
    response = await session.get(
        TOKOPEDIA_HOME_URL,
        headers={
            "Referer": TOKOPEDIA_HOME_URL,
            "Origin": "https://www.tokopedia.com",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        },
    )
    response.raise_for_status()


def _has_required_qr_cookies(cookies: dict[str, str]) -> bool:
    return bool(cookies.get("DID") and cookies.get("DID_JS"))


def _is_transient_qr_error(exc: Exception) -> bool:
    message = str(exc).lower()
    return any(marker in message for marker in _TRANSIENT_QR_ERROR_MARKERS)


async def _bootstrap_qr_cookies_via_playwright(existing_cookies: dict[str, str] | None = None) -> dict[str, str]:
    try:
        from playwright.async_api import async_playwright
    except ImportError as exc:
        raise RuntimeError(
            "QR login requires Playwright for browser cookie bootstrap. "
            "Install the optional QR dependency with 'pip install .[qr]' and then run "
            "'python -m playwright install firefox'."
        ) from exc

    attempts: list[str] = []

    async with async_playwright() as playwright:
        browser = None
        context = None
        try:
            browser = await playwright.firefox.launch(headless=True)
            context = await browser.new_context(locale="en-US")

            if existing_cookies:
                await context.add_cookies([
                    {"name": name, "value": value, "url": TOKOPEDIA_HOME_URL}
                    for name, value in existing_cookies.items()
                ])

            page = await context.new_page()
            # Multiple passes are needed in some environments before Akamai issues DID cookies.
            await page.goto(TOKOPEDIA_HOME_URL, wait_until="domcontentloaded", timeout=30000)
            await page.wait_for_timeout(4000)
            await page.goto(TOKOPEDIA_HOME_URL, wait_until="domcontentloaded", timeout=30000)
            await page.wait_for_timeout(2500)

            cookies = {
                str(cookie.get("name")): str(cookie.get("value"))
                for cookie in await context.cookies()
                if cookie.get("name") is not None and cookie.get("value") is not None
            }
            if _has_required_qr_cookies(cookies):
                return cookies
            attempts.append("firefox: no DID cookies issued")
        except Exception as exc:
            attempts.append(f"firefox: {exc}")
        finally:
            if context is not None:
                await context.close()
            if browser is not None:
                await browser.close()

    raise RuntimeError(
        "Playwright QR bootstrap failed before Tokopedia issued DID cookies. "
        "Tried browser: " + "; ".join(attempts)
    )


async def _gql(
    session: AsyncSession,
    operation_name: str,
    query: str,
    variables: dict[str, Any],
    *,
    max_retries: int = 3,
) -> dict[str, Any]:
    """Execute a GraphQL operation.

    CRITICAL: URL must be /graphql/{OperationName}, payload must be a JSON array.
    """
    url = GQL_BASE_URL + operation_name  # e.g. /graphql/SearchProductV5Query
    payload = [{"operationName": operation_name, "query": query, "variables": variables}]

    last_exc: Exception | None = None
    for attempt in range(max_retries):
        try:
            response = await session.post(url, json=payload)
            response.raise_for_status()
            body = response.json()
            if isinstance(body, list):
                body = body[0]
            errors = body.get("errors")
            if errors:
                msg = "; ".join(e.get("message", str(e)) for e in errors)
                raise RuntimeError(f"GraphQL error: {msg}")
            return body.get("data", {})
        except Exception as exc:
            last_exc = exc
            if isinstance(exc, RuntimeError) and "GraphQL error" in str(exc):
                raise
            if attempt < max_retries - 1:
                wait = 2 ** attempt + random.random()
                logger.warning("GQL attempt %d/%d failed, retry in %.1fs: %s", attempt + 1, max_retries, wait, exc)
                await asyncio.sleep(wait)

    raise RuntimeError(f"GQL failed after {max_retries} attempts") from last_exc


def _infer_component_type(name: str, type_: str) -> str:
    key = (name + type_).lower()
    if "description" in key:
        return "ProductDescription"
    if "media" in key or "image" in key or "photo" in key:
        return "ProductMedia"
    if "detail" in key or "spec" in key:
        return "ProductDetail"
    return ""


def _extract_product_json_ld(html: str) -> dict[str, Any] | None:
    for node in HTMLParser(html).css("script[type='application/ld+json']"):
        raw = node.text(strip=True)
        if not raw:
            continue
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError:
            continue

        candidates: list[Any]
        if isinstance(payload, list):
            candidates = payload
        else:
            candidates = [payload]

        for item in candidates:
            if not isinstance(item, dict):
                continue
            graph = item.get("@graph")
            if isinstance(graph, list):
                candidates.extend(graph)
                continue

            typ = item.get("@type")
            if isinstance(typ, str) and typ.lower() == "product":
                return item
            if isinstance(typ, list) and any(str(x).lower() == "product" for x in typ):
                return item
    return None


def _normalize_variant_payload(raw_variants: Any) -> dict[str, Any] | None:
    if not isinstance(raw_variants, list):
        return None

    groups: list[dict[str, Any]] = []
    selected: list[dict[str, str]] = []

    for index, group in enumerate(raw_variants):
        if not isinstance(group, dict):
            continue

        group_name = _compact_text(
            group.get("name")
            or group.get("title")
            or group.get("label")
            or group.get("variantName")
            or group.get("unitName")
        )

        options_raw = group.get("option") or group.get("options") or []
        if not isinstance(options_raw, list):
            continue

        options: list[dict[str, Any]] = []
        selected_value = ""
        for option in options_raw:
            if not isinstance(option, dict):
                continue

            value = _compact_text(option.get("value") or option.get("name") or option.get("title"))
            if not value:
                continue

            option_item: dict[str, Any] = {
                "option_id": option.get("productVariantOptionID") or option.get("variantOptionID") or option.get("id"),
                "value": value,
                "stock": _coerce_int(option.get("stock")),
            }
            hex_color = _compact_text(option.get("hex"))
            if hex_color:
                option_item["hex"] = hex_color
            if bool(option.get("selected") or option.get("isSelected") or option.get("active") or option.get("isActive")):
                option_item["selected"] = True
                selected_value = value

            options.append(option_item)

        if not options:
            continue

        normalized_group_name = group_name or f"Variant {index + 1}"
        groups.append({"name": normalized_group_name, "options": options})
        if selected_value:
            selected.append({"group": normalized_group_name, "value": selected_value})

    if not groups:
        return None

    result: dict[str, Any] = {"groups": groups}
    if selected:
        result["selected"] = selected
        result["selected_confidence"] = "explicit"
    return result


def _extract_variants_from_components(components: list[Any]) -> dict[str, Any] | None:
    for comp in components:
        if not isinstance(comp, dict):
            continue
        raw = comp.get("data")
        items = raw if isinstance(raw, list) else ([raw] if raw else [])
        for item in items:
            if not isinstance(item, dict):
                continue
            variants = _normalize_variant_payload(item.get("variants"))
            if variants:
                return variants
    return None


def _extract_window_cache(html: str) -> dict[str, Any] | None:
    marker_idx = html.find(_WINDOW_CACHE_MARKER)
    if marker_idx == -1:
        return None

    start_idx = html.find("{", marker_idx + len(_WINDOW_CACHE_MARKER))
    if start_idx == -1:
        return None

    end_idx = html.find(_WINDOW_STATE_MARKER, start_idx)
    payload = html[start_idx:end_idx] if end_idx != -1 else html[start_idx:]
    payload = payload.rstrip(" ;\n\r\t")

    decoder = json.JSONDecoder()
    try:
        parsed, _ = decoder.raw_decode(payload)
    except json.JSONDecodeError:
        return None
    return parsed if isinstance(parsed, dict) else None


def _extract_variants_from_window_cache(cache: dict[str, Any]) -> dict[str, Any] | None:
    group_names: dict[int, str] = {}
    options_by_group: dict[int, list[dict[str, Any]]] = {}
    selected_by_group: dict[int, str] = {}

    for key, value in cache.items():
        if not isinstance(key, str) or not isinstance(value, dict):
            continue

        group_match = _VARIANT_GROUP_PATH_RE.search(key)
        if group_match:
            group_name = _compact_text(value.get("name") or value.get("title") or value.get("label"))
            if group_name:
                group_names[int(group_match.group(1))] = group_name

        option_match = _VARIANT_OPTION_PATH_RE.search(key)
        if not option_match:
            continue

        group_idx = int(option_match.group(1))
        option_value = _compact_text(value.get("value") or value.get("name") or value.get("title"))
        if not option_value:
            continue

        option_item: dict[str, Any] = {
            "option_id": value.get("productVariantOptionID") or value.get("variantOptionID") or value.get("id"),
            "value": option_value,
            "stock": _coerce_int(value.get("stock")),
        }
        if bool(value.get("selected") or value.get("isSelected") or value.get("active") or value.get("isActive")):
            option_item["selected"] = True
            selected_by_group[group_idx] = option_value
        hex_color = _compact_text(value.get("hex"))
        if hex_color:
            option_item["hex"] = hex_color

        bucket = options_by_group.setdefault(group_idx, [])
        if any(existing.get("option_id") == option_item.get("option_id") and existing.get("value") == option_item.get("value")
               for existing in bucket):
            continue
        bucket.append(option_item)

    if not options_by_group:
        return None

    groups = []
    selected = []
    for group_idx in sorted(options_by_group):
        group_name = group_names.get(group_idx) or f"Variant {group_idx + 1}"
        groups.append({"name": group_name, "options": options_by_group[group_idx]})
        selected_value = selected_by_group.get(group_idx)
        if selected_value:
            selected.append({"group": group_name, "value": selected_value})

    result: dict[str, Any] = {"groups": groups}
    if selected:
        result["selected"] = selected
        result["selected_confidence"] = "explicit"
    return result


def _infer_selected_variants_from_title(variants: dict[str, Any] | None, title: str) -> dict[str, Any] | None:
    if not variants:
        return variants
    if variants.get("selected"):
        return variants

    groups = variants.get("groups") or []
    normalized_title = _normalize_match_text(title)
    if not normalized_title:
        return variants

    inferred_selected: list[dict[str, str]] = []
    for group in groups:
        if not isinstance(group, dict):
            continue
        options = group.get("options") or []
        if not isinstance(options, list):
            continue

        matched_value = ""
        matched_len = -1
        for option in options:
            if not isinstance(option, dict):
                continue
            value = _compact_text(option.get("value"))
            if not value:
                continue
            normalized_value = _normalize_match_text(value)
            if not normalized_value:
                continue
            if normalized_value in normalized_title and len(normalized_value) > matched_len:
                matched_value = value
                matched_len = len(normalized_value)

        if matched_value:
            inferred_selected.append({
                "group": _compact_text(group.get("name")) or "Variant",
                "value": matched_value,
            })

    if inferred_selected:
        variants["selected"] = inferred_selected
        variants["selected_confidence"] = "inferred"
    return variants


def _normalize_variant_offer(child: dict[str, Any], *, cache: dict[str, Any] | None = None) -> dict[str, Any] | None:
    option_name_raw = _resolve_cache_value(cache, child.get("optionName") or child.get("variantName"))
    option_name = _value_to_text(option_name_raw)
    if not option_name:
        return None

    price_value = _extract_int_value(_resolve_cache_value(cache, child.get("price")))
    price_fmt = _value_to_text(_resolve_cache_value(cache, child.get("priceFmt")))
    if not price_fmt and price_value is not None:
        price_fmt = f"Rp{price_value:,}".replace(",", ".")

    return {
        "option_name": option_name,
        "price_value": price_value,
        "price": price_fmt,
        "stock": _extract_int_value(_resolve_cache_value(cache, child.get("stock"))),
        "product_id": _resolve_cache_value(cache, child.get("productID") or child.get("id")),
        "url": _value_to_text(_resolve_cache_value(cache, child.get("productURL") or child.get("url"))),
    }


def _extract_variant_offers_from_components(components: list[Any]) -> list[dict[str, Any]]:
    offers: list[dict[str, Any]] = []
    seen_keys: set[tuple[str, int | None]] = set()

    for comp in components:
        if not isinstance(comp, dict):
            continue
        raw = comp.get("data")
        items = raw if isinstance(raw, list) else ([raw] if raw else [])
        for item in items:
            if not isinstance(item, dict):
                continue
            children = item.get("children")
            if not isinstance(children, list):
                continue
            for child in children:
                if not isinstance(child, dict):
                    continue
                offer = _normalize_variant_offer(child)
                if not offer:
                    continue
                dedupe_key = (offer["option_name"], offer["price_value"])
                if dedupe_key in seen_keys:
                    continue
                seen_keys.add(dedupe_key)
                offers.append(offer)

    return offers


def _extract_variant_offers_from_window_cache(cache: dict[str, Any]) -> list[dict[str, Any]]:
    offers: list[dict[str, Any]] = []
    seen_keys: set[tuple[str, int | None]] = set()

    for key, value in cache.items():
        if not isinstance(key, str) or not isinstance(value, dict):
            continue
        if not _VARIANT_CHILD_PATH_RE.search(key):
            continue

        offer = _normalize_variant_offer(value, cache=cache)
        if not offer:
            continue
        dedupe_key = (offer["option_name"], offer["price_value"])
        if dedupe_key in seen_keys:
            continue
        seen_keys.add(dedupe_key)
        offers.append(offer)

    return offers


def _attach_variant_pricing(result: dict[str, Any], variants: dict[str, Any] | None, offers: list[dict[str, Any]]) -> None:
    if not offers:
        return

    result["variant_offers"] = offers

    priced = [offer for offer in offers if isinstance(offer.get("price_value"), int)]
    if priced:
        min_offer = min(priced, key=lambda item: cast(int, item["price_value"]))
        max_offer = max(priced, key=lambda item: cast(int, item["price_value"]))
        result["price_range"] = {
            "min_price_value": min_offer.get("price_value"),
            "min_price": min_offer.get("price"),
            "max_price_value": max_offer.get("price_value"),
            "max_price": max_offer.get("price"),
        }

    selected = (variants or {}).get("selected") or []
    if not isinstance(selected, list) or not selected:
        return

    selected_values = [
        _normalize_match_text(str(item.get("value", "")))
        for item in selected
        if isinstance(item, dict)
    ]
    selected_values = [value for value in selected_values if value]
    if not selected_values:
        return

    for offer in offers:
        option_text = _normalize_match_text(str(offer.get("option_name") or ""))
        if option_text and all(value in option_text for value in selected_values):
            result["selected_offer"] = offer
            return


def _extract_description_from_window_cache(cache: dict[str, Any]) -> str:
    for key, value in cache.items():
        if not isinstance(key, str) or not isinstance(value, dict):
            continue

        key_lower = key.lower()
        typename = str(value.get("__typename") or "").lower()
        if "productdetaildescription" not in key_lower and "productdetaildescription" not in typename:
            continue

        description = _compact_rich_text(value.get("content") or value.get("description"))
        if description:
            return description
    return ""


def _extract_basic_info_from_window_cache(cache: dict[str, Any]) -> dict[str, Any]:
    basic = next(
        (v for k, v in cache.items() if _PDP_BASIC_INFO_KEY_RE.match(k) and isinstance(v, dict)),
        None,
    )
    if not basic:
        return {}

    weight = basic.get("weight")
    weight_unit = _compact_text(basic.get("weightUnit") or "")
    weight_str = f"{weight} {weight_unit}".strip() if weight is not None else ""

    cat_val = _resolve_cache_value(cache, basic.get("category"))
    category = _compact_text((cat_val or {}).get("name") or "") if isinstance(cat_val, dict) else ""

    stats_val = _resolve_cache_value(cache, basic.get("stats"))
    rating = stats_val.get("rating") if isinstance(stats_val, dict) else None
    review_count = _coerce_int((stats_val or {}).get("countReview")) if isinstance(stats_val, dict) else None

    tx_val = _resolve_cache_value(cache, basic.get("txStats"))
    if isinstance(tx_val, dict):
        sold_count = (
            _compact_text(tx_val.get("itemSoldFmt") or "")
            or _compact_text(str(tx_val.get("countSold") or ""))
            or None
        )
    else:
        sold_count = None

    return {
        "product_id": str(basic.get("productID") or "") or None,
        "shop_id": str(basic.get("shopID") or "") or None,
        "shop_name": _compact_text(basic.get("shopName") or ""),
        "url": _compact_text(basic.get("url") or ""),
        "condition": _compact_text(basic.get("condition") or "") or None,
        "weight": weight_str,
        "min_order": _coerce_int(basic.get("minOrder")),
        "category": category or None,
        "rating": rating,
        "review_count": review_count,
        "sold_count": sold_count,
    }


def _extract_details_from_window_cache(cache: dict[str, Any]) -> list[dict[str, Any]]:
    seen: set[tuple[str, str]] = set()
    details: list[dict[str, Any]] = []
    for value in cache.values():
        if not isinstance(value, dict):
            continue
        if value.get("__typename") != "pdpContentProductDetail":
            continue
        label = _compact_text(value.get("title") or "")
        val = _compact_text(value.get("subtitle") or "")
        if label and val and (label, val) not in seen:
            seen.add((label, val))
            details.append({"label": label, "value": val})
    return details


def _extract_media_from_window_cache(cache: dict[str, Any]) -> list[dict[str, Any]]:
    media: list[dict[str, Any]] = []
    seen_urls: set[str] = set()
    for value in cache.values():
        if not isinstance(value, dict):
            continue
        if value.get("__typename") != "pdpContentSnapshotMedia":
            continue
        url = _compact_text(value.get("URLOriginal") or value.get("url") or "")
        if not url or url in seen_urls:
            continue
        seen_urls.add(url)
        media.append({
            "type": value.get("type") or "image",
            "url": url,
            "thumbnail": _compact_text(value.get("URLThumbnail") or url),
            "video_url": _compact_text(value.get("videoURLAndroid") or "") or None,
        })
    return media


def _build_detail_from_json_ld(json_ld: dict[str, Any], *, shop_domain: str, product_url: str) -> dict[str, Any]:
    images = json_ld.get("image")
    image_list = images if isinstance(images, list) else ([images] if images else [])
    aggregate = cast(dict[str, Any], json_ld.get("aggregateRating") or {})
    offers = cast(dict[str, Any], json_ld.get("offers") or {})
    seller = cast(dict[str, Any], offers.get("seller") or {})

    return {
        "product_id": json_ld.get("sku") or json_ld.get("productID"),
        "name": json_ld.get("name"),
        "shop_id": None,
        "shop_name": seller.get("name") or shop_domain,
        "url": json_ld.get("url") or product_url,
        "condition": None,
        "weight": "",
        "min_order": None,
        "category": json_ld.get("category"),
        "rating": aggregate.get("ratingValue"),
        "review_count": aggregate.get("reviewCount"),
        "sold_count": None,
        "description": json_ld.get("description") or "",
        "details": [],
        "media": [{"type": "image", "url": img, "thumbnail": img, "video_url": None} for img in image_list],
    }


def _build_detail_from_html(html: str, *, shop_domain: str, product_key: str, product_url: str) -> dict[str, Any]:
    cache = _extract_window_cache(html)
    variants = _extract_variants_from_window_cache(cache) if cache else None
    variant_offers = _extract_variant_offers_from_window_cache(cache) if cache else []
    description = _extract_description_from_window_cache(cache) if cache else ""
    basic_info = _extract_basic_info_from_window_cache(cache) if cache else {}
    details = _extract_details_from_window_cache(cache) if cache else []
    media_items = _extract_media_from_window_cache(cache) if cache else []

    parser = HTMLParser(html)
    title = ""
    title_nodes = parser.css("title")
    if title_nodes:
        title = title_nodes[0].text(strip=True)
    if "|" in title:
        title = title.split("|", 1)[0].strip()
    variants = _infer_selected_variants_from_title(variants, title)

    json_ld = _extract_product_json_ld(html)
    if json_ld:
        result = _build_detail_from_json_ld(json_ld, shop_domain=shop_domain, product_url=product_url)
        if not result.get("description") and description:
            result["description"] = description
        if not result.get("shop_id") and basic_info.get("shop_id"):
            result["shop_id"] = basic_info["shop_id"]
        if not result.get("condition") and basic_info.get("condition"):
            result["condition"] = basic_info["condition"]
        if not result.get("weight") and basic_info.get("weight"):
            result["weight"] = basic_info["weight"]
        if result.get("min_order") is None and basic_info.get("min_order") is not None:
            result["min_order"] = basic_info["min_order"]
        if result.get("sold_count") is None and basic_info.get("sold_count"):
            result["sold_count"] = basic_info["sold_count"]
        if not result.get("details") and details:
            result["details"] = details
        if not result.get("media") and media_items:
            result["media"] = media_items
        if variants:
            result["variants"] = variants
        _attach_variant_pricing(result, variants, variant_offers)
        return result

    image_url = None
    for meta in parser.css("meta[property='og:image']"):
        image_url = meta.attributes.get("content")
        if image_url:
            break

    result = {
        "product_id": basic_info.get("product_id"),
        "name": title or product_key.replace("-", " "),
        "shop_id": basic_info.get("shop_id"),
        "shop_name": basic_info.get("shop_name") or shop_domain,
        "url": product_url,
        "condition": basic_info.get("condition"),
        "weight": basic_info.get("weight", ""),
        "min_order": basic_info.get("min_order"),
        "category": basic_info.get("category"),
        "rating": basic_info.get("rating"),
        "review_count": basic_info.get("review_count"),
        "sold_count": basic_info.get("sold_count"),
        "description": description,
        "details": details,
        "media": media_items or ([{"type": "image", "url": image_url, "thumbnail": image_url, "video_url": None}] if image_url else []),
    }
    if variants:
        result["variants"] = variants
    _attach_variant_pricing(result, variants, variant_offers)
    return result


def _clean_html_text(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def _extract_shop_products_from_html(html: str, *, shop_domain: str) -> list[dict[str, Any]]:
    parser = HTMLParser(html)
    products: list[dict[str, Any]] = []
    seen_urls: set[str] = set()
    reserved_paths = {"product", "review", "etalase"}

    for anchor in parser.css("a[href]"):
        href = anchor.attributes.get("href") or ""
        if not href:
            continue

        full_url = urllib.parse.urljoin("https://www.tokopedia.com", href)
        parsed = urllib.parse.urlparse(full_url)
        parts = [part for part in parsed.path.split("/") if part]
        if len(parts) < 2 or parts[0] != shop_domain or parts[1] in reserved_paths:
            continue
        if full_url in seen_urls:
            continue

        texts: list[str] = []
        for node in anchor.css("span, p, div"):
            text = _clean_html_text(node.text(strip=True))
            if text and text not in texts:
                texts.append(text)

        price_text = next((text for text in texts if re.search(r"Rp\s*[\d\.,]+", text, re.IGNORECASE)), None)
        sold_text = next((text for text in texts if "terjual" in text.lower()), None)
        rating_value = next(
            (
                float(text)
                for text in texts
                if re.fullmatch(r"(?:[0-4](?:\.\d)?|5(?:\.0)?)", text)
            ),
            None,
        )

        name_candidates = [
            text for text in texts
            if len(text) >= 8
            and not re.search(r"Rp\s*[\d\.,]+", text, re.IGNORECASE)
            and "terjual" not in text.lower()
            and not re.fullmatch(r"(?:[0-4](?:\.\d)?|5(?:\.0)?)", text)
            and "hemat s.d" not in text.lower()
            and "pakai bonus" not in text.lower()
        ]
        if not name_candidates:
            continue

        image_url = None
        fallback_image_url = None
        for image in anchor.css("img"):
            for attr in ("src", "data-src", "data-original", "data-lazy-src"):
                candidate = image.attributes.get(attr)
                if not candidate:
                    continue
                candidate_url = urllib.parse.urljoin(full_url, candidate)
                if fallback_image_url is None:
                    fallback_image_url = candidate_url
                if "85cc883d.svg" not in candidate_url:
                    image_url = candidate_url
                    break
            if image_url:
                break
        if image_url is None:
            image_url = fallback_image_url

        product_slug = parts[1]
        product_id_match = re.search(r"-(\d{10,})$", product_slug)
        normalized_price = None
        if price_text:
            price_match = re.search(r"Rp\s*[\d\.,]+", price_text, re.IGNORECASE)
            normalized_price = price_match.group(0).replace(" ", "") if price_match else price_text

        products.append(
            {
                "product_id": product_id_match.group(1) if product_id_match else None,
                "name": max(name_candidates, key=len),
                "price": normalized_price,
                "price_value": int(re.sub(r"\D", "", normalized_price)) if normalized_price else None,
                "image_url": image_url,
                "url": full_url,
                "rating": rating_value,
                "review_count": None,
                "sold_text": sold_text,
            }
        )
        seen_urls.add(full_url)

    return products


async def _get_shop_products_from_html(
    session: AsyncSession,
    *,
    shop_domain: str,
    page: int,
    per_page: int,
    keyword: str,
    sort: int,
) -> dict[str, Any]:
    url = f"https://www.tokopedia.com/{shop_domain}/product"
    if page > 1:
        url += f"/page/{page}"

    params: dict[str, Any] = {"perpage": min(max(1, per_page), 80)}
    if keyword:
        params["q"] = keyword
    if sort:
        params["sort"] = sort

    response = await session.get(
        url,
        params=params,
        headers={
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Referer": f"https://www.tokopedia.com/{shop_domain}",
        },
    )
    response.raise_for_status()
    products = _extract_shop_products_from_html(response.text, shop_domain=shop_domain)

    return {
        "total": len(products),
        "page": page,
        "per_page": per_page,
        "products": [
            {
                "product_id": product.get("product_id"),
                "name": product.get("name"),
                "price": product.get("price"),
                "price_value": product.get("price_value"),
                "image_url": product.get("image_url"),
                "url": product.get("url"),
                "rating": product.get("rating"),
                "review_count": product.get("review_count"),
            }
            for product in products
        ],
    }


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------


async def generate_login_qr() -> dict[str, Any]:
    await _ensure_fresh()
    async with _make_session() as session:
        await _prime_tokopedia_session(session)
        qr_cookies = _extract_session_cookies(session)

    if not _has_required_qr_cookies(qr_cookies):
        qr_cookies.update(await _bootstrap_qr_cookies_via_playwright(qr_cookies))

    max_qr_retries = _env_int(_ENV_QR_REQUEST_MAX_RETRIES, default=3, minimum=1)
    retry_backoff_base_seconds = _env_float(_ENV_QR_REQUEST_BACKOFF_BASE_SECONDS, default=0.7, minimum=0.1)

    async with _make_session(extra_cookies=qr_cookies) as session:
        data: dict[str, Any] | None = None
        for attempt in range(1, max_qr_retries + 1):
            try:
                data = await _gql(session, "OTPRequestQRQuery", _QR_LOGIN_REQUEST_QUERY, {})
                break
            except RuntimeError as exc:
                if attempt == max_qr_retries or not _is_transient_qr_error(exc):
                    raise
                backoff = retry_backoff_base_seconds * attempt
                logger.warning(
                    "OTPRequestQRQuery transient failure (%d/%d), retrying in %.1fs: %s",
                    attempt,
                    max_qr_retries,
                    backoff,
                    exc,
                )
                await asyncio.sleep(backoff)

        if data is None:
            raise RuntimeError("OTPRequestQR did not return a response")

        qr_cookies.update(_extract_session_cookies(session))

    result = data.get("OTPRequestQR", {})
    if not result.get("is_success"):
        error_message = result.get("error_message") or "OTPRequestQR returned an unsuccessful response"
        if "DID" in error_message and not _has_required_qr_cookies(qr_cookies):
            raise RuntimeError(
                "Tokopedia QR login still failed after browser bootstrap because DID cookies were not issued. "
                f"Upstream message: {error_message}"
            )
        raise RuntimeError(error_message)

    validation_token = result.get("token") or ""
    if not validation_token:
        raise RuntimeError("OTPRequestQR did not return a validation token")

    exact_image_base64 = result.get("code") or ""
    fallback_qr = _build_qr_code(validation_token)
    qr_png_base64 = fallback_qr["png_base64"]
    qr_image_mime_type = "image/png"
    qr_image_data_url = f"data:image/png;base64,{qr_png_base64}"
    if exact_image_base64:
        qr_image_mime_type = "image/jpeg"
        qr_image_data_url = f"data:image/jpeg;base64,{exact_image_base64}"
        try:
            qr_png_base64 = _image_base64_to_png_base64(exact_image_base64)
        except Exception as exc:
            logger.debug("Failed to convert Tokopedia QR image to PNG: %s", exc)

    _qr_login_state.update({
        "token": validation_token,
        "cookies": qr_cookies,
        "status": result.get("status"),
        "approved_uuid": None,
    })

    return {
        "uuid": validation_token,
        "validation_token": validation_token,
        "expired_time": None,
        "qr_status": result.get("status"),
        "qr_image_base64": exact_image_base64 or qr_png_base64,
        "qr_image_mime_type": qr_image_mime_type,
        "qr_image_data_url": qr_image_data_url,
        "qr_png_base64": qr_png_base64,
        "qr_ascii": fallback_qr["ascii"],
        "instructions": (
            "1. Open the Tokopedia app on your phone.\n"
            "2. Tap the QR-scan icon (top-right of the home screen).\n"
            "3. Scan the QR code shown above.\n"
            "4. Confirm the login in the app.\n"
            "5. Call check_qr_login_status with the returned uuid field to complete sign-in."
        ),
    }


async def check_qr_login_status(uuid_val: str) -> dict[str, Any]:
    await _ensure_fresh()
    qr_cookies = {}
    if _qr_login_state.get("token") == uuid_val:
        qr_cookies.update(_qr_login_state.get("cookies") or {})

    try:
        async with _make_session(timeout=20.0, extra_cookies=qr_cookies) as session:
            response = await session.get(
                QR_STATUS_STREAM_URL,
                params={"token": uuid_val},
                headers={"Accept": "text/event-stream"},
            )
            response.raise_for_status()
            stream_payload = _parse_qr_status_stream(response.text)
            qr_cookies.update(_extract_session_cookies(session))
    except Exception as exc:
        if "timed out" in str(exc).lower():
            return {"status": "waiting", "logged_in": False, "message": "QR code not yet scanned."}
        raise

    _qr_login_state.update({"token": uuid_val, "cookies": qr_cookies})

    if not stream_payload:
        return {"status": "waiting", "logged_in": False, "message": "QR code not yet scanned."}

    status_code_raw = stream_payload.get("status_verification")
    status_code = status_code_raw if isinstance(status_code_raw, int) else None
    status_map = {1: "rejected", 2: "approved", 4: "expired"}
    status = status_map[status_code] if status_code in status_map else "unknown"
    approved_uuid = stream_payload.get("uuid")
    _qr_login_state["approved_uuid"] = approved_uuid
    _qr_login_state["status"] = status

    if status == "approved":
        profile: dict[str, Any] = {}
        try:
            profile = await _get_profile_from_cookies(qr_cookies)
        except Exception as exc:
            logger.debug("Unable to hydrate Tokopedia profile from QR cookies: %s", exc)

        merged_cookies = profile.get("cookies") or qr_cookies
        _auth_state.update({
            "access_token": None,
            "token_type": "bearer",
            "user_id": profile.get("user_id"),
            "cookies": merged_cookies,
            "is_logged_in": True,
        })
        return {
            "status": "approved",
            "logged_in": True,
            "user_id": profile.get("user_id"),
            "approved_uuid": approved_uuid,
            "message": "QR login approved.",
        }

    if status in {"rejected", "expired"}:
        return {
            "status": status,
            "logged_in": False,
            "approved_uuid": approved_uuid,
            "message": f"QR login {status}.",
        }

    return {
        "status": "waiting",
        "logged_in": False,
        "approved_uuid": approved_uuid,
        "raw_status": status_code_raw,
        "message": "QR status stream did not report approval yet.",
    }


async def wait_for_qr_login_approval(
    uuid_val: str,
    timeout_seconds: int | None = None,
    poll_interval_seconds: float | None = None,
) -> dict[str, Any]:
    if not uuid_val:
        raise ValueError("uuid is required")

    timeout = timeout_seconds if timeout_seconds is not None else _env_int(
        _ENV_QR_WAIT_TIMEOUT_SECONDS, default=120, minimum=1
    )
    poll_interval = poll_interval_seconds if poll_interval_seconds is not None else _env_float(
        _ENV_QR_WAIT_POLL_INTERVAL_SECONDS, default=2.0, minimum=0.1
    )
    if timeout <= 0:
        raise ValueError("timeout_seconds must be > 0")
    if poll_interval <= 0:
        raise ValueError("poll_interval_seconds must be > 0")

    deadline = time.monotonic() + timeout
    attempts = 0
    last_result: dict[str, Any] = {"status": "waiting", "logged_in": False}

    while time.monotonic() < deadline:
        attempts += 1
        last_result = await check_qr_login_status(uuid_val)
        status = str(last_result.get("status") or "waiting").lower()
        if status in {"approved", "rejected", "expired"}:
            return {
                **last_result,
                "attempts": attempts,
                "timed_out": False,
            }
        await asyncio.sleep(poll_interval)

    return {
        **last_result,
        "status": "timeout",
        "logged_in": False,
        "timed_out": True,
        "attempts": attempts,
        "message": (
            f"QR login timed out after {timeout} seconds. "
            "Call generate_login_qr again for a new token."
        ),
    }


async def login(email: str, password: str) -> dict[str, Any]:
    async with AsyncSession(impersonate="chrome", timeout=30.0) as session:
        response = await session.post(
            LOGIN_URL,
            data={"grant_type": "password", "username": email, "password": password, "client_id": "5"},
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )
        response.raise_for_status()
        data = response.json()
    if data.get("access_token"):
        _auth_state.update({"access_token": data["access_token"], "token_type": data.get("token_type", "bearer"),
                             "is_logged_in": True, "email": email, "cookies": {}})
        return {"logged_in": True, "email": email}
    return {"logged_in": False, "error": data.get("error_description") or data.get("error") or "Login failed"}


def logout() -> dict[str, Any]:
    email = _auth_state.get("email")
    _auth_state.update({"access_token": None, "token_type": "bearer", "user_id": None,
                         "email": None, "cookies": {}, "is_logged_in": False})
    return {"logged_out": True, "previous_email": email}


async def get_current_user() -> dict[str, Any]:
    if not _auth_state["is_logged_in"]:
        return {"error": "Not logged in. Call login() first."}
    await _ensure_fresh()
    async with _make_session() as session:
        data = await _gql(session, "ProfileHeaderQuery", _PROFILE_QUERY, {})
    p = (data.get("profileHeader") or {}).get("data")
    if not p:
        return {}
    s = p.get("stats") or {}
    return {"user_id": p.get("userID"), "full_name": p.get("fullName"), "bio": p.get("bio"),
            "avatar_url": p.get("imagePath"), "followers": s.get("follower"),
            "following": s.get("following"), "reviews": s.get("review"), "email": _auth_state.get("email")}


async def get_wishlist(*, page: int = 1, per_page: int = 20) -> dict[str, Any]:
    if not _auth_state["is_logged_in"]:
        return {"error": "Not logged in. Call login() first."}
    await _ensure_fresh()
    async with _make_session() as session:
        data = await _gql(
            session,
            "GetWishlistCollectionItems",
            _WISHLIST_QUERY,
            {"page": max(1, page), "per_page": min(max(1, per_page), 50)},
        )

    payload = data.get("get_wishlist_collection_items") or {}
    products = []
    for item in payload.get("items") or []:
        shop = item.get("shop") or {}
        products.append(
            {
                "product_id": item.get("id"),
                "name": item.get("name"),
                "image_url": item.get("image_url"),
                "url": item.get("url"),
                "price": item.get("price_fmt"),
                "rating": item.get("rating"),
                "sold_count": item.get("sold_count"),
                "shop_name": shop.get("name"),
                "city": shop.get("location"),
            }
        )

    return {
        "total": payload.get("total_data", 0),
        "page": page,
        "per_page": per_page,
        "products": products,
    }


async def add_to_wishlist(product_id: str) -> dict[str, Any]:
    if not _auth_state["is_logged_in"]:
        return {"error": "Not logged in. Call login() first."}
    await _ensure_fresh()
    async with _make_session() as session:
        data = await _gql(
            session,
            "WishlistAddV2",
            _WISHLIST_ADD_MUTATION,
            {"product_id": str(product_id)},
        )
    result = data.get("wishlist_add_v2") or {}
    return {
        "success": bool(result.get("success")),
        "message": result.get("message") or "",
        "product_id": str(product_id),
    }


async def remove_from_wishlist(product_id: str) -> dict[str, Any]:
    if not _auth_state["is_logged_in"]:
        return {"error": "Not logged in. Call login() first."}
    await _ensure_fresh()
    async with _make_session() as session:
        data = await _gql(
            session,
            "WishlistRemoveV2",
            _WISHLIST_REMOVE_MUTATION,
            {"product_id": str(product_id)},
        )
    result = data.get("wishlist_remove_v2") or {}
    return {
        "success": bool(result.get("success")),
        "message": result.get("message") or "",
        "product_id": str(product_id),
    }


# ---------------------------------------------------------------------------
# Products & Search
# ---------------------------------------------------------------------------


async def search_products(
    query: str,
    *,
    page: int = 1,
    rows: int = 20,
    sort_by: str = "best_match",
    price_min: int | None = None,
    price_max: int | None = None,
    include_images: bool = False,
) -> dict[str, Any]:
    """Search Tokopedia products using the v5 API (exact HAR-verified params).

    Pagination: increment page to scroll. Each page returns up to rows (max 60).
    Total pages = ceil(total / rows).
    """
    rows = min(max(1, rows), 60)
    page = max(1, page)
    sort_code = SORT_OPTIONS.get(sort_by, SORT_OPTIONS["best_match"])
    user_id = str(_auth_state.get("user_id") or 0)
    await _ensure_fresh()

    # Exact params from HAR — all 20+ fields required
    params: dict[str, Any] = {
        "device": "desktop",
        "enter_method": "normal_search",
        "l_name": "sre",
        "navsource": "",
        "ob": sort_code,
        "page": page,
        "q": query,
        "related": "true",
        "rows": rows,
        "safe_search": "false",
        "sc": "",
        "scheme": "https",
        "shipping": "",
        "show_adult": "false",
        "source": "search",
        "srp_component_id": "02.01.00.00",
        "srp_page_id": "",
        "srp_page_title": "",
        "st": "product",
        "start": (page - 1) * rows,
        "topads_bucket": "true",
        "unique_id": uuid.uuid4().hex,
        "variants": "",
        "warehouses": "",
    }
    params.update(_search_location_params(user_id=user_id))
    if price_min is not None:
        params["pmin"] = price_min
    if price_max is not None:
        params["pmax"] = price_max

    async with _make_session() as session:
        data = await _gql(session, "SearchProductV5Query", _SEARCH_QUERY_V5,
                          {"params": urllib.parse.urlencode(params)})

    sv5 = data.get("searchProductV5", {})
    total = (sv5.get("header") or {}).get("totalData", 0)
    products_raw = (sv5.get("data") or {}).get("products", [])

    # Normalise product shape to a clean, consistent format
    products = []
    for p in products_raw:
        price_info = p.get("price") or {}
        shop = p.get("shop") or {}
        product = {
            "id": p.get("id") or p.get("oldID"),
            "name": p.get("name"),
            "url": p.get("url"),
            "price": price_info.get("text"),
            "price_number": price_info.get("number"),
            "price_original": price_info.get("original"),
            "discount_pct": price_info.get("discountPercentage"),
            "rating": p.get("rating"),
            "shop_name": shop.get("name"),
            "shop_city": shop.get("city"),
            "shop_tier": shop.get("tier"),  # 2=gold, 3=official
            "category": (p.get("category") or {}).get("name"),
            "badge": (p.get("badge") or {}).get("title"),
        }
        if include_images:
            product["image"] = (p.get("mediaURL") or {}).get("image")
        products.append(product)

    return {"total": total, "page": page, "rows": rows, "products": products[:rows]}


async def get_product_detail(product_url: str, *, include_media: bool = False) -> dict[str, Any]:
    await _ensure_fresh()
    resolved_product_url = await _resolve_product_detail_url(product_url)
    shop_domain, product_key = _parse_product_url(resolved_product_url)
    try:
        async with _make_session() as session:
            data = await _gql(
                session,
                "PDPMainInfo",
                _PRODUCT_DETAIL_QUERY,
                {
                    "shopDomain": shop_domain,
                    "productKey": product_key,
                    "layoutID": "",
                    "extraPayload": "",
                    "queryParam": "",
                    "source": "P1",
                    "userLocation": _product_user_location(),
                },
            )
    except RuntimeError as exc:
        if "unauthorized request" not in str(exc).lower() and "invalid request schema" not in str(exc).lower():
            raise
        async with _make_session() as session:
            response = await session.get(resolved_product_url)
            response.raise_for_status()
        result = _build_detail_from_html(response.text, shop_domain=shop_domain, product_key=product_key, product_url=resolved_product_url)
        if not include_media:
            result.pop("media", None)
        return result

    pdp_main = data.get("pdpMainInfo") or {}
    if pdp_main:
        basic = ((pdp_main.get("data") or {}).get("basicInfo") or {})
        components = ((pdp_main.get("data") or {}).get("components") or pdp_main.get("components") or [])
        product_name = basic.get("alias")
    else:
        layout = data.get("pdpGetLayout", {})
        if not layout:
            return {}
        basic = layout.get("basicInfo", {})
        components = layout.get("components", [])
        product_name = layout.get("name")

    if not basic:
        return {}

    description, details, media = "", [], []
    variants = _extract_variants_from_components(components)
    variant_offers = _extract_variant_offers_from_components(components)
    for comp in components:
        raw = comp.get("data")
        items = raw if isinstance(raw, list) else ([raw] if raw else [])
        for cd in items:
            if not isinstance(cd, dict):
                continue
            tn = cd.get("__typename") or _infer_component_type(comp.get("name", ""), comp.get("type", ""))
            if tn in {"ProductDescription", "ProductDetailDescription"} and not description:
                description = _compact_rich_text(cd.get("content", ""))
            elif not description and isinstance(cd.get("productDetailDescription"), dict):
                description = _compact_rich_text((cd.get("productDetailDescription") or {}).get("content", ""))
            elif tn == "ProductInfo" and not product_name:
                product_name = cd.get("name")
            elif tn == "ProductDetail":
                for item in cd.get("content", []):
                    if item.get("title") and item.get("subtitle"):
                        details.append({
                            "label": _compact_text(item["title"]),
                            "value": _compact_text(item["subtitle"]),
                        })
            elif tn == "ProductMedia":
                for m in cd.get("media", []):
                    media.append({"type": m.get("type"), "url": m.get("url"),
                                  "thumbnail": m.get("urlThumbnail"), "video_url": m.get("videoUrl")})
    result = {
        "product_id": basic.get("id"), "name": product_name,
        "shop_id": basic.get("shopID"), "shop_name": basic.get("shopName"),
        "url": basic.get("url"), "condition": basic.get("condition"),
        "weight": f"{basic.get('weight', '')} {basic.get('weightUnit', '')}".strip(),
        "min_order": basic.get("minOrder"),
        "category": (basic.get("category") or {}).get("name"),
        "rating": (basic.get("stats") or {}).get("rating"),
        "review_count": (basic.get("stats") or {}).get("countReview"),
        "sold_count": (basic.get("txStats") or {}).get("itemSoldPaymentVerified")
        or (basic.get("txStats") or {}).get("countSold")
        or (basic.get("txStats") or {}).get("itemSoldFmt"),
        "description": description, "details": details,
    }
    if variants:
        result["variants"] = variants
    _attach_variant_pricing(result, variants, variant_offers)
    if include_media:
        result["media"] = media
    return result


async def get_product_reviews(
    product_id: str,
    *,
    page: int = 1,
    limit: int = 10,
    sort_by: str = "helpful",
    include_media: bool = False,
    include_low_signal: bool = False,
) -> dict[str, Any]:
    sort_map = {
        "helpful": "informative_score desc",
        "newest": "review_create_time desc",
        "highest_rating": "product_rating desc",
        "lowest_rating": "product_rating asc",
    }
    await _ensure_fresh()
    async with _make_session() as session:
        data = await _gql(session, "productReviewList", _REVIEWS_QUERY,
                          {"productID": str(product_id), "page": max(1, page),
                           "limit": max(1, min(limit, 100)),
                           "sortBy": sort_map.get(sort_by, sort_map["helpful"]), "filterBy": ""})
    r = data.get("productrevGetProductReviewList") or data.get("productReviewList") or {}
    reviews = []
    filtered_low_signal_reviews = 0
    for item in r.get("list", []):
        user = item.get("user") or {}
        like_dislike = item.get("likeDislike") or {}
        title = _compact_text(item.get("title", ""))
        content = _compact_text(item.get("message", ""))
        if not include_low_signal and _is_low_signal_review(title, content):
            filtered_low_signal_reviews += 1
            continue
        review = {
            "review_id": item.get("reviewID") or item.get("id") or item.get("feedbackID"),
            "rating": item.get("productRating"),
            "title": title,
            "content": content,
            "variant_name": _compact_text(item.get("variantName", "")),
            "reviewer_name": user.get("fullName") or item.get("reviewerName"),
            "created_at": item.get("reviewCreateTime") or item.get("createTime"),
            "helpful_count": like_dislike.get("totalLike") if isinstance(like_dislike, dict) else None,
            "image_count": len(item.get("imageAttachments") or []),
            "video_count": len(item.get("videoAttachments") or []),
        }
        if include_media:
            review["image_attachments"] = item.get("imageAttachments") or []
            review["video_attachments"] = item.get("videoAttachments") or []
        reviews.append(review)

    return {
        "total_reviews": r.get("totalReviews", 0),
        "total_ratings": r.get("totalRatings"),
        "has_next": r.get("hasNext", False),
        "page": page,
        "filtered_low_signal_reviews": filtered_low_signal_reviews,
        "reviews": reviews,
    }


async def get_shop_info(shop_domain: str) -> dict[str, Any]:
    await _ensure_fresh()
    async with _make_session() as session:
        data = await _gql(session, "ShopInfoCore", _SHOP_INFO_QUERY, {"id": 0, "domain": shop_domain})
    results = (data.get("shopInfoByID") or {}).get("result", [])
    if not results:
        return {}
    r = results[0]
    core = r.get("shopCore", {})
    gold = r.get("goldOS", {})
    stats = r.get("shopStats", {})
    assets = r.get("shopAssets", {})
    shipping = r.get("shippingLoc", {})
    location = r.get("location") or ""

    return {"shop_id": core.get("shopID"), "name": core.get("name"), "domain": core.get("domain"),
            "tagline": core.get("tagLine"), "description": core.get("description"),
            "avatar_url": assets.get("avatar") or core.get("avatarURL"),
            "cover_url": assets.get("cover") or core.get("coverURL"),
            "city": shipping.get("cityName") or (location if isinstance(location, str) else location.get("city")),
            "province": shipping.get("districtName") if isinstance(shipping, dict) else None,
            "is_gold": gold.get("isGold"), "is_gold_badge": gold.get("isGoldBadge"),
            "total_transactions": stats.get("totalTx") or stats.get("totalTxSuccess"),
            "total_products": stats.get("totalShowcase"),
            "total_favorites": (r.get("favoriteData") or {}).get("totalFavorite")}


async def search_shops(query: str, *, page: int = 1, rows: int = 10) -> dict[str, Any]:
    rows = min(max(1, rows), 20)
    page = max(1, page)
    await _ensure_fresh()
    try:
        async with _make_session() as session:
            data = await _gql(session, "SearchShopQuery", _SEARCH_SHOPS_QUERY,
                              {"params": urllib.parse.urlencode({"q": query, "start": (page - 1) * rows,
                               "rows": rows, "device": "desktop", "source": "search", "page": page})})
        r = data.get("aceSearchShopV2", {})
        return {"total": (r.get("header") or {}).get("totalData", 0), "page": page, "rows": rows,
                "shops": (r.get("data") or {}).get("shops", [])}
    except RuntimeError as exc:
        if "Invalid request schema" not in str(exc):
            raise

    params = {
        "device": "desktop",
        "enter_method": "normal_search",
        "l_name": "sre",
        "navsource": "",
        "ob": SORT_OPTIONS["best_match"],
        "page": page,
        "q": query,
        "related": "true",
        "rows": rows,
        "safe_search": "false",
        "sc": "",
        "scheme": "https",
        "shipping": "",
        "show_adult": "false",
        "source": "search",
        "srp_component_id": "02.01.00.00",
        "srp_page_id": "",
        "srp_page_title": "",
        "st": "shop",
        "start": (page - 1) * rows,
        "topads_bucket": "true",
        "unique_id": uuid.uuid4().hex,
        "variants": "",
        "warehouses": "",
    }
    params.update(_search_location_params(user_id=str(_auth_state.get("user_id") or 0)))
    async with _make_session() as session:
        data = await _gql(
            session,
            "SearchProductV5Query",
            _SEARCH_QUERY_V5,
            {"params": urllib.parse.urlencode(params)},
        )

    products = ((data.get("searchProductV5") or {}).get("data") or {}).get("products") or []
    shop_map: dict[str, dict[str, Any]] = {}
    for product in products:
        shop = product.get("shop") or {}
        shop_id = str(shop.get("id") or shop.get("oldID") or "")
        domain = urllib.parse.urlparse(shop.get("url") or "").path.strip("/")
        key = shop_id or domain or shop.get("name") or ""
        if not key:
            continue
        if key in shop_map:
            continue
        shop_map[key] = {
            "shopID": shop_id,
            "name": shop.get("name"),
            "shopDomain": domain,
            "avatarURL": None,
            "city": shop.get("city"),
            "isGold": bool((shop.get("tier") or 0) >= 2),
            "isGoldBadge": bool((shop.get("tier") or 0) >= 2),
            "isOfficial": bool((shop.get("tier") or 0) >= 3),
            "rating": None,
            "totalReview": None,
            "productList": [],
        }

    shops = list(shop_map.values())
    return {
        "total": len(shops),
        "page": page,
        "rows": rows,
        "shops": shops[:rows],
    }


async def get_shop_products(shop_domain: str, *, page: int = 1, per_page: int = 20,
                            keyword: str = "", sort: int = 1) -> dict[str, Any]:
    await _ensure_fresh()
    async with _make_session() as session:
        try:
            shop_info = await _gql(session, "ShopInfoCore", _SHOP_INFO_QUERY, {"id": 0, "domain": shop_domain})
            info_rows = (shop_info.get("shopInfoByID") or {}).get("result") or []
            shop_id = str((((info_rows[0] if info_rows else {}).get("shopCore") or {}).get("shopID") or "0"))
            data = await _gql(session, "ShopProducts", _SHOP_PRODUCTS_QUERY,
                              {
                                  "sid": shop_id,
                                  "source": "shop",
                                  "page": max(1, page),
                                  "perPage": min(max(1, per_page), 80),
                                  "keyword": keyword,
                                  "etalaseId": "etalase",
                                  "sort": sort,
                                  "usecase": "ace_get_shop_product_v2",
                                  **_shop_products_location_params(),
                              })
        except RuntimeError:
            return await _get_shop_products_from_html(
                session,
                shop_domain=shop_domain,
                page=max(1, page),
                per_page=min(max(1, per_page), 80),
                keyword=keyword,
                sort=sort,
            )
    r = data.get("GetShopProduct", {})
    product_rows = r.get("data") or []
    total = r.get("totalData") if r.get("totalData") is not None else len(product_rows)

    def _pick(row: dict[str, Any], *paths: str) -> Any:
        for path in paths:
            current: Any = row
            ok = True
            for part in path.split("."):
                if not isinstance(current, dict) or part not in current:
                    ok = False
                    break
                current = current[part]
            if ok:
                return current
        return None

    return {
        "total": total,
        "page": page,
        "per_page": per_page,
        "products": [
            {
                "product_id": _pick(p, "productID", "product_id"),
                "name": p.get("name"),
                "price": _pick(p, "price.textIdr", "price.text_idr"),
                "price_value": _pick(p, "price.value"),
                "image_url": _pick(p, "imageUrl", "primary_image.thumbnail"),
                "url": _pick(p, "url", "product_url"),
                "rating": _pick(p, "rating", "stats.averageRating"),
                "review_count": _pick(p, "countReview", "stats.reviewCount"),
            }
            for p in product_rows
        ],
    }


async def get_review_media(product_id: str, *, page: int = 1, limit: int = 10) -> dict[str, Any]:
    review_data = await get_product_reviews(
        product_id,
        page=page,
        limit=limit,
        include_media=True,
        include_low_signal=True,
    )
    images, videos = [], []
    for review in review_data.get("reviews", []):
        meta = {"review_id": review.get("review_id"), "reviewer": review.get("reviewer_name", ""),
                "rating": review.get("rating")}
        for img in review.get("image_attachments", []):
            images.append({**meta, "attachment_id": img.get("attachmentID"),
                           "thumbnail_url": img.get("imageThumbnailUrl"), "image_url": img.get("imageUrl")})
        for vid in review.get("video_attachments", []):
            videos.append({**meta, "attachment_id": vid.get("attachmentID"),
                           "video_url": vid.get("videoUrl"), "thumbnail_url": vid.get("thumbnailUrl")})
    return {"product_id": product_id, "page": page,
            "has_next": review_data.get("has_next", False), "images": images, "videos": videos}


async def download_media(media_url: str) -> dict[str, Any]:
    async with AsyncSession(impersonate="chrome",
                            headers={"Referer": "https://www.tokopedia.com/"}, timeout=60.0) as session:
        response = await session.get(media_url)
        response.raise_for_status()
    return {"url": media_url, "content_type": response.headers.get("content-type", "application/octet-stream"),
            "size_bytes": len(response.content),
            "data_base64": base64.b64encode(response.content).decode()}
