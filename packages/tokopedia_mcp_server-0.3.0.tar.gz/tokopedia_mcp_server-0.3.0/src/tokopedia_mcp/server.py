"""Tokopedia MCP Server — v0.4.0

Uses curl-cffi for API calls and Playwright for QR cookie bootstrap.
"""

from __future__ import annotations

import logging
from typing import Any

from mcp.server.fastmcp import FastMCP
from tokopedia_mcp import client as tokopedia

_TRANSIENT_ERROR_MARKERS = (
    "service unavailable",
    "service not available",
    "temporarily unavailable",
    "timeout",
    "timed out",
)


def _error_code(exc: Exception) -> str:
    message = str(exc).lower()
    if isinstance(exc, ValueError):
        return "invalid_input"
    if isinstance(exc, (ImportError, ModuleNotFoundError)):
        return "dependency_missing"
    if isinstance(exc, TimeoutError) or "timed out" in message or "timeout" in message:
        return "upstream_timeout"
    if any(marker in message for marker in _TRANSIENT_ERROR_MARKERS):
        return "upstream_unavailable"
    if "login" in message and ("require" in message or "must" in message or "not" in message):
        return "auth_required"
    if "not found" in message:
        return "not_found"
    if isinstance(exc, RuntimeError):
        return "upstream_error"
    return "internal_error"


def _retryable_error(error_code: str) -> bool:
    return error_code in {"upstream_timeout", "upstream_unavailable"}


def _error_hint(error_code: str) -> str | None:
    hints = {
        "invalid_input": "Check parameters and value ranges, then retry.",
        "auth_required": "Run login or generate_login_qr flow before this call.",
        "dependency_missing": "Install required runtime dependencies (e.g., Playwright browsers).",
        "upstream_timeout": "Retry shortly; Tokopedia upstream may be slow.",
        "upstream_unavailable": "Retry shortly; Tokopedia upstream appears temporarily unavailable.",
    }
    return hints.get(error_code)

mcp = FastMCP(
    name="tokopedia-mcp-server",
    instructions=(
        "Search, inspect, and compare products on Tokopedia.\n\n"
        "SEARCH & PAGINATION:\n"
        "  search_products(query, page, rows, sort_by, price_min, price_max)\n"
        "  — Always use rows=60 (the maximum) to return the most results per call.\n"
        "  — Increment page to get more results beyond the first 60.\n"
        "  — Use total from response to know how many pages exist.\n\n"
        "PRODUCT:\n"
        "  get_product_detail(product_url) — specs, description, media\n"
        "  get_product_reviews(product_id, page, limit, sort_by)\n"
        "  get_review_media(product_id, page) — photo/video from reviews\n"
        "  download_media(media_url) — fetch media as base64\n\n"
        "SHOPS:\n"
        "  search_shops(query, page, rows)\n"
        "  get_shop_info(shop_domain)\n"
        "  get_shop_products(shop_domain, page, per_page, keyword, sort)\n\n"
        "AUTH (optional — for wishlist/profile):\n"
        "  login(email, password) or generate_login_qr → wait_for_qr_login_approval\n"
        "  check_qr_login_status(uuid) is available for manual polling\n"
        "  get_current_user(), get_wishlist(page, per_page)\n"
        "  add_to_wishlist(product_id), remove_from_wishlist(product_id)\n"
        "  logout()\n"
    ),
)


def _err(exc: Exception) -> dict[str, Any]:
    code = _error_code(exc)
    payload: dict[str, Any] = {
        "ok": False,
        "error": type(exc).__name__,
        "error_code": code,
        "retryable": _retryable_error(code),
        "message": str(exc),
    }
    hint = _error_hint(code)
    if hint:
        payload["hint"] = hint
    return payload


@mcp.tool()
async def login(email: str, password: str) -> dict[str, Any]:
    """Log in to Tokopedia with email and password."""
    try:
        return await tokopedia.login(email, password)
    except Exception as exc:
        return _err(exc)


@mcp.tool()
def logout() -> dict[str, Any]:
    """Clear the stored Tokopedia session."""
    return tokopedia.logout()


@mcp.tool()
async def generate_login_qr() -> dict[str, Any]:
    """Generate a QR code for passwordless Tokopedia login.
    After user scans, call check_qr_login_status(uuid).
    """
    try:
        return await tokopedia.generate_login_qr()
    except Exception as exc:
        return _err(exc)


@mcp.tool()
async def check_qr_login_status(uuid: str) -> dict[str, Any]:
    """Check if a QR-code login was approved. Pass uuid from generate_login_qr."""
    try:
        return await tokopedia.check_qr_login_status(uuid)
    except Exception as exc:
        return _err(exc)


@mcp.tool()
async def wait_for_qr_login_approval(
    uuid: str,
    timeout_seconds: int | None = None,
    poll_interval_seconds: float | None = None,
) -> dict[str, Any]:
    """Poll QR login status until approved/rejected/expired or timeout."""
    try:
        return await tokopedia.wait_for_qr_login_approval(
            uuid,
            timeout_seconds=timeout_seconds,
            poll_interval_seconds=poll_interval_seconds,
        )
    except Exception as exc:
        return _err(exc)


@mcp.tool()
async def get_current_user() -> dict[str, Any]:
    """Get profile of the logged-in user. Requires login first."""
    try:
        return await tokopedia.get_current_user()
    except Exception as exc:
        return _err(exc)


@mcp.tool()
async def get_wishlist(page: int = 1, per_page: int = 20) -> dict[str, Any]:
    """Get the logged-in user's wishlist. Requires login first."""
    try:
        return await tokopedia.get_wishlist(page=page, per_page=per_page)
    except Exception as exc:
        return _err(exc)


@mcp.tool()
async def add_to_wishlist(product_id: str) -> dict[str, Any]:
    """Add a product to the logged-in user's wishlist. Requires login first."""
    try:
        return await tokopedia.add_to_wishlist(product_id)
    except Exception as exc:
        return _err(exc)


@mcp.tool()
async def remove_from_wishlist(product_id: str) -> dict[str, Any]:
    """Remove a product from the logged-in user's wishlist. Requires login first."""
    try:
        return await tokopedia.remove_from_wishlist(product_id)
    except Exception as exc:
        return _err(exc)


@mcp.tool()
async def search_products(
    query: str,
    page: int = 1,
    rows: int = 60,
    sort_by: str = "best_match",
    price_min: int | None = None,
    price_max: int | None = None,
    include_images: bool = False,
) -> dict[str, Any]:
    """Search Tokopedia products.

    Parameters
    ----------
    query     : keyword (e.g. "usb hub")
    page      : page number — increment to get more results
    rows      : results per page, max 60. Always use 60 to get the most results
                in a single call. Only reduce if explicitly asked.
    sort_by   : best_match | newest | highest_sales | lowest_price | highest_price | most_reviews
    price_min : minimum price in IDR (optional)
    price_max : maximum price in IDR (optional)

    Pagination: response includes ``total``. Pages = ceil(total / rows).
    To return more results than one page allows, call again with page=2, page=3, etc.
    """
    try:
        return await tokopedia.search_products(
            query,
            page=page,
            rows=rows,
            sort_by=sort_by,
            price_min=price_min,
            price_max=price_max,
            include_images=include_images,
        )
    except Exception as exc:
        return _err(exc)


@mcp.tool()
async def get_product_detail(product_url: str, include_media: bool = False) -> dict[str, Any]:
    """Get full product details. Accepts normal product URLs and Tokopedia short links."""
    try:
        return await tokopedia.get_product_detail(product_url, include_media=include_media)
    except Exception as exc:
        return _err(exc)


@mcp.tool()
async def get_product_reviews(
    product_id: str,
    page: int = 1,
    limit: int = 10,
    sort_by: str = "helpful",
    include_media: bool = False,
    include_low_signal: bool = False,
) -> dict[str, Any]:
    """Get buyer reviews. sort_by: helpful | newest | highest_rating | lowest_rating"""
    try:
        return await tokopedia.get_product_reviews(
            product_id,
            page=page,
            limit=limit,
            sort_by=sort_by,
            include_media=include_media,
            include_low_signal=include_low_signal,
        )
    except Exception as exc:
        return _err(exc)


@mcp.tool()
async def get_shop_info(shop_domain: str) -> dict[str, Any]:
    """Get shop details. Pass the shop's URL slug (e.g. 'samsung-id')."""
    try:
        return await tokopedia.get_shop_info(shop_domain)
    except Exception as exc:
        return _err(exc)


@mcp.tool()
async def search_shops(query: str, page: int = 1, rows: int = 10) -> dict[str, Any]:
    """Search shops by keyword."""
    try:
        return await tokopedia.search_shops(query, page=page, rows=rows)
    except Exception as exc:
        return _err(exc)


@mcp.tool()
async def get_shop_products(
    shop_domain: str, page: int = 1, per_page: int = 20, keyword: str = "", sort: int = 1
) -> dict[str, Any]:
    """List products in a shop. sort: 1=newest 2=best-selling 3=highest-price 4=lowest-price"""
    try:
        return await tokopedia.get_shop_products(
            shop_domain, page=page, per_page=per_page, keyword=keyword, sort=sort
        )
    except Exception as exc:
        return _err(exc)


@mcp.tool()
async def get_review_media(product_id: str, page: int = 1, limit: int = 10) -> dict[str, Any]:
    """Get image/video URLs from product reviews."""
    try:
        return await tokopedia.get_review_media(product_id, page=page, limit=limit)
    except Exception as exc:
        return _err(exc)


@mcp.tool()
async def download_media(media_url: str) -> dict[str, Any]:
    """Download a media file and return it as base64."""
    try:
        return await tokopedia.download_media(media_url)
    except Exception as exc:
        return _err(exc)


def main() -> None:
    logging.getLogger("mcp").setLevel(logging.WARNING)
    logging.getLogger("mcp.server").setLevel(logging.WARNING)
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
