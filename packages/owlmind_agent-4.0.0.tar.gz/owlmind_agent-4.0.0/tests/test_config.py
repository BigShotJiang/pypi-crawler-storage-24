"""Tests for owlmind.config — environment-based configuration."""

from __future__ import annotations

import os
from unittest.mock import patch

from owlmind.config import (
    AnthropicConfig,
    OwlMindConfig,
    GeminiConfig,
    OpenAIConfig,
    PricingConfig,
    TelegramConfig,
    WorkerConfig,
    parse_chat_ids,
)


class TestTelegramConfig:
    def test_defaults(self) -> None:
        cfg = TelegramConfig()
        assert cfg.bot_token == ""
        assert cfg.allowed_chat_ids == []
        assert cfg.default_chat_id is None
        assert cfg.rate_limit_seconds == 2.0

    def test_enabled_with_token(self) -> None:
        cfg = TelegramConfig(bot_token="123:ABC")
        assert cfg.enabled is True

    def test_disabled_without_token(self) -> None:
        cfg = TelegramConfig()
        assert cfg.enabled is False


class TestOpenAIConfig:
    def test_defaults(self) -> None:
        cfg = OpenAIConfig()
        assert cfg.planner_model == "gpt-4o-2024-08-06"
        assert cfg.max_output_tokens == 1200
        assert cfg.timeout_sec == 60

    def test_enabled_with_key(self) -> None:
        cfg = OpenAIConfig(api_key="sk-test")
        assert cfg.enabled is True

    def test_disabled_without_key(self) -> None:
        assert OpenAIConfig().enabled is False


class TestAnthropicConfig:
    def test_defaults(self) -> None:
        cfg = AnthropicConfig()
        assert "claude" in cfg.model
        assert cfg.enabled is False

    def test_enabled(self) -> None:
        cfg = AnthropicConfig(api_key="sk-ant-test")
        assert cfg.enabled is True


class TestGeminiConfig:
    def test_defaults(self) -> None:
        cfg = GeminiConfig()
        assert "gemini" in cfg.model
        assert cfg.enabled is False


class TestWorkerConfig:
    def test_disabled_by_default(self) -> None:
        cfg = WorkerConfig()
        assert cfg.mode == "none"
        assert cfg.enabled is False

    def test_enabled_with_claude_cli(self) -> None:
        cfg = WorkerConfig(mode="claude_cli")
        assert cfg.enabled is True


class TestPricingConfig:
    def test_defaults(self) -> None:
        cfg = PricingConfig()
        assert cfg.openai_price_per_1k_input > 0
        assert cfg.currency == "USD"

    def test_price_for_openai(self) -> None:
        cfg = PricingConfig()
        price_in, price_out = cfg.price_for_provider("openai")
        assert price_in == cfg.openai_price_per_1k_input
        assert price_out == cfg.openai_price_per_1k_output

    def test_price_for_anthropic(self) -> None:
        cfg = PricingConfig()
        price_in, price_out = cfg.price_for_provider("anthropic")
        assert price_in == cfg.anthropic_price_per_1k_input
        assert price_out == cfg.anthropic_price_per_1k_output

    def test_price_for_gemini(self) -> None:
        cfg = PricingConfig()
        price_in, price_out = cfg.price_for_provider("gemini")
        assert price_in == cfg.gemini_price_per_1k_input

    def test_price_for_unknown_falls_back_to_openai(self) -> None:
        cfg = PricingConfig()
        price_in, _ = cfg.price_for_provider("unknown")
        assert price_in == cfg.openai_price_per_1k_input


class TestOwlMindConfigFromEnv:
    def test_defaults_from_empty_env(self) -> None:
        with patch.dict(os.environ, {}, clear=True):
            cfg = OwlMindConfig.from_env()
        assert cfg.telegram.bot_token == ""
        assert cfg.openai.api_key == ""
        assert cfg.anthropic.api_key == ""
        assert cfg.gemini.api_key == ""
        assert cfg.worker.mode == "none"

    def test_loads_telegram_config(self) -> None:
        env = {
            "TELEGRAM_BOT_TOKEN": "123:TESTBOT",
            "TELEGRAM_ALLOWED_CHAT_IDS": "111,222",
            "OWLMIND_NOTIFY_DEFAULT_CHAT_ID": "111",
        }
        with patch.dict(os.environ, env, clear=True):
            cfg = OwlMindConfig.from_env()
        assert cfg.telegram.bot_token == "123:TESTBOT"
        assert cfg.telegram.allowed_chat_ids == [111, 222]
        assert cfg.telegram.default_chat_id == 111

    def test_loads_openai_config(self) -> None:
        env = {
            "OPENAI_API_KEY": "sk-test123",
            "OWLMIND_OPENAI_PLANNER_MODEL": "gpt-4-turbo",
            "OWLMIND_OPENAI_MAX_OUTPUT_TOKENS": "2000",
            "OWLMIND_OPENAI_TIMEOUT_SEC": "90",
        }
        with patch.dict(os.environ, env, clear=True):
            cfg = OwlMindConfig.from_env()
        assert cfg.openai.api_key == "sk-test123"
        assert cfg.openai.planner_model == "gpt-4-turbo"
        assert cfg.openai.max_output_tokens == 2000
        assert cfg.openai.timeout_sec == 90

    def test_loads_anthropic_config(self) -> None:
        env = {
            "ANTHROPIC_API_KEY": "sk-ant-test",
            "OWLMIND_ANTHROPIC_MODEL": "claude-opus",
        }
        with patch.dict(os.environ, env, clear=True):
            cfg = OwlMindConfig.from_env()
        assert cfg.anthropic.api_key == "sk-ant-test"
        assert cfg.anthropic.model == "claude-opus"

    def test_loads_gemini_config_from_google_key(self) -> None:
        env = {"GOOGLE_API_KEY": "goog-test"}
        with patch.dict(os.environ, env, clear=True):
            cfg = OwlMindConfig.from_env()
        assert cfg.gemini.api_key == "goog-test"

    def test_loads_router_config(self) -> None:
        env = {
            "OWLMIND_PLANNER_PROVIDERS": "anthropic,openai",
            "OWLMIND_JUDGE_PROVIDERS": "gemini",
        }
        with patch.dict(os.environ, env, clear=True):
            cfg = OwlMindConfig.from_env()
        assert cfg.router.planner_providers == ["anthropic", "openai"]
        assert cfg.router.judge_providers == ["gemini"]

    def test_loads_worker_config(self) -> None:
        env = {
            "OWLMIND_WORKER_MODE": "claude_cli",
            "OWLMIND_CLAUDE_CLI_CONTINUE": "true",
        }
        with patch.dict(os.environ, env, clear=True):
            cfg = OwlMindConfig.from_env()
        assert cfg.worker.mode == "claude_cli"
        assert cfg.worker.claude_cli_continue is True

    def test_loads_budget_config(self) -> None:
        env = {
            "OWLMIND_BUDGET_MAX_TOKENS_PER_RUN": "50000",
            "OWLMIND_BUDGET_MAX_USD_PER_DAY": "5.0",
        }
        with patch.dict(os.environ, env, clear=True):
            cfg = OwlMindConfig.from_env()
        assert cfg.budget.max_tokens_per_run == 50000
        assert cfg.budget.max_usd_per_day == 5.0

    def test_loads_workspace_config(self) -> None:
        env = {
            "OWLMIND_DEFAULT_WORKSPACE": "/tmp/ws",
            "OWLMIND_ALLOWED_WORKSPACES": "/tmp/ws,/home/user/code",
        }
        with patch.dict(os.environ, env, clear=True):
            cfg = OwlMindConfig.from_env()
        assert cfg.workspace.default_workspace == "/tmp/ws"
        assert cfg.workspace.allowed_workspaces == ["/tmp/ws", "/home/user/code"]

    def test_heartbeat_config(self) -> None:
        env = {
            "OWLMIND_HEARTBEAT_INTERVAL": "30",
            "OWLMIND_QUOTA_AUTO_STARTS_PER_HOUR": "5",
        }
        with patch.dict(os.environ, env, clear=True):
            cfg = OwlMindConfig.from_env()
        assert cfg.heartbeat.interval_seconds == 30
        assert cfg.heartbeat.max_auto_starts_per_hour == 5


class TestParseChatIds:
    def test_empty_string(self) -> None:
        assert parse_chat_ids("") == []

    def test_whitespace(self) -> None:
        assert parse_chat_ids("   ") == []

    def test_single_id(self) -> None:
        assert parse_chat_ids("12345") == [12345]

    def test_multiple_ids(self) -> None:
        assert parse_chat_ids("111,222,333") == [111, 222, 333]

    def test_ids_with_spaces(self) -> None:
        assert parse_chat_ids(" 111 , 222 , 333 ") == [111, 222, 333]

    def test_trailing_comma(self) -> None:
        assert parse_chat_ids("111,222,") == [111, 222]
