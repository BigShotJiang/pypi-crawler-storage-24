"""Tests for owlmind.dashboard — static HTML dashboard generator."""

from __future__ import annotations

import json
from pathlib import Path

from owlmind.dashboard import _render_html, generate_dashboard


def _setup_ledger(tmp_path: Path) -> Path:
    """Create a minimal ledger directory with data."""
    ledger_dir = tmp_path / "ledger"
    ledger_dir.mkdir()
    # Create a minimal ledger JSONL file for today
    from datetime import UTC, datetime

    today = datetime.now(tz=UTC).strftime("%Y-%m-%d")
    ledger_file = ledger_dir / f"{today}.jsonl"
    entry = {
        "ts": datetime.now(tz=UTC).isoformat(),
        "run_id": "cycle-test-001",
        "stage": "planner",
        "provider": "openai",
        "model": "gpt-4o",
        "input_tokens": 100,
        "output_tokens": 50,
        "total_tokens": 150,
        "estimated_usd": 0.001,
        "latency_ms": 500,
        "price_per_1k_input": 0.0025,
        "price_per_1k_output": 0.01,
    }
    ledger_file.write_text(json.dumps(entry) + "\n")
    return ledger_dir


class TestRenderHtml:
    def test_contains_title(self) -> None:
        html = _render_html([], [], [])
        assert "OWLMIND Analytics Dashboard" in html

    def test_contains_daily_data(self) -> None:
        daily = [{"date": "2025-01-01", "tokens": 1000, "usd": 0.5, "calls": 3}]
        html = _render_html(daily, [], [])
        assert "2025-01-01" in html
        assert "1,000" in html

    def test_contains_run_data(self) -> None:
        runs = [
            {
                "run_id": "cycle-abc",
                "state": "DONE",
                "goal": "Test goal",
                "tokens": 500,
                "usd": 0.25,
                "pr_pack": "",
            }
        ]
        html = _render_html([], [], runs)
        assert "cycle-abc" in html
        assert "DONE" in html

    def test_state_css_classes(self) -> None:
        runs = [
            {"run_id": "a", "state": "DONE", "goal": "x", "tokens": 0, "usd": 0, "pr_pack": ""},
            {"run_id": "b", "state": "FAILED", "goal": "y", "tokens": 0, "usd": 0, "pr_pack": ""},
            {
                "run_id": "c",
                "state": "WAIT_WORKER",
                "goal": "z",
                "tokens": 0,
                "usd": 0,
                "pr_pack": "",
            },
        ]
        html = _render_html([], [], runs)
        assert 'class="done"' in html
        assert 'class="failed"' in html
        assert 'class="pending"' in html


class TestGenerateDashboard:
    def test_creates_html_file(self, tmp_path: Path) -> None:
        ledger_dir = _setup_ledger(tmp_path)
        runs_dir = tmp_path / "runs"
        runs_dir.mkdir()
        out_path = tmp_path / "dashboard.html"

        generate_dashboard(ledger_dir, runs_dir, out_path)

        assert out_path.exists()
        html = out_path.read_text()
        assert "OWLMIND Analytics Dashboard" in html

    def test_with_run_metadata(self, tmp_path: Path) -> None:
        ledger_dir = _setup_ledger(tmp_path)
        runs_dir = tmp_path / "runs"
        run_dir = runs_dir / "cycle-test-001"
        run_dir.mkdir(parents=True)
        meta = {
            "run_id": "cycle-test-001",
            "goal": "Dashboard test goal",
            "state": "DONE",
            "iteration": 1,
        }
        (run_dir / "cycle_meta.json").write_text(json.dumps(meta))

        out_path = tmp_path / "dashboard.html"
        generate_dashboard(ledger_dir, runs_dir, out_path)

        html = out_path.read_text()
        assert "cycle-test-001" in html
        assert "DONE" in html

    def test_empty_ledger(self, tmp_path: Path) -> None:
        ledger_dir = tmp_path / "ledger"
        ledger_dir.mkdir()
        runs_dir = tmp_path / "runs"
        runs_dir.mkdir()
        out_path = tmp_path / "dashboard.html"

        generate_dashboard(ledger_dir, runs_dir, out_path)

        assert out_path.exists()
        html = out_path.read_text()
        assert "OWLMIND Analytics Dashboard" in html

    def test_creates_parent_dirs(self, tmp_path: Path) -> None:
        ledger_dir = tmp_path / "ledger"
        ledger_dir.mkdir()
        runs_dir = tmp_path / "runs"
        runs_dir.mkdir()
        out_path = tmp_path / "deep" / "nested" / "dashboard.html"

        generate_dashboard(ledger_dir, runs_dir, out_path)
        assert out_path.exists()


class TestGenerateDashboardBadJson:
    """Lines 60-61: corrupt cycle_meta.json is skipped via continue."""

    def test_bad_cycle_meta_skipped(self, tmp_path: Path) -> None:
        ledger_dir = _setup_ledger(tmp_path)
        runs_dir = tmp_path / "runs"
        bad_dir = runs_dir / "cycle-bad-001"
        bad_dir.mkdir(parents=True)
        (bad_dir / "cycle_meta.json").write_text("NOT JSON {{{")

        out_path = tmp_path / "dashboard_exc.html"
        generate_dashboard(ledger_dir, runs_dir, out_path)

        assert out_path.exists()
        html = out_path.read_text()
        assert "OWLMIND Analytics Dashboard" in html
