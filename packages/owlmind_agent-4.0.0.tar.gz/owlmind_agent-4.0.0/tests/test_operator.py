"""Tests for operator service — unit tests only, no network."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from owlmind.operator import OperatorService, RunInfo, RunLock, _map_state_to_status


class TestRunInfo:
    def test_defaults(self) -> None:
        info = RunInfo(run_id="cycle-1", goal="test", workspace=".")
        assert info.status == "running"
        assert info.final_state == ""
        assert info.stop_reason == ""

    def test_custom_fields(self) -> None:
        info = RunInfo(
            run_id="cycle-2",
            goal="deploy",
            workspace="/tmp",
            status="done",
            final_state="DONE",
        )
        assert info.status == "done"
        assert info.goal == "deploy"


class TestMapState:
    def test_done(self) -> None:
        assert _map_state_to_status("DONE") == "done"

    def test_failed(self) -> None:
        assert _map_state_to_status("FAILED") == "failed"

    def test_blocked_states(self) -> None:
        for state in ("WAIT_APPROVAL", "STARTED_WAIT_PLANNER", "WAIT_WORKER", "WAIT_JUDGE"):
            assert _map_state_to_status(state) == "blocked"

    def test_unknown_is_running(self) -> None:
        assert _map_state_to_status("SOMETHING") == "running"


class TestRunLock:
    def test_acquire_and_release(self, tmp_path: Path) -> None:
        lock_path = tmp_path / "run-1" / ".lock"
        lock = RunLock(lock_path)

        assert lock.acquire() is True
        lock.release()

    def test_double_acquire_fails(self, tmp_path: Path) -> None:
        lock_path = tmp_path / "run-2" / ".lock"
        lock1 = RunLock(lock_path)
        lock2 = RunLock(lock_path)

        assert lock1.acquire() is True
        assert lock2.acquire() is False

        lock1.release()
        # Now second lock should succeed
        assert lock2.acquire() is True
        lock2.release()

    def test_context_manager(self, tmp_path: Path) -> None:
        lock_path = tmp_path / "run-3" / ".lock"
        with RunLock(lock_path):
            # Lock is held
            other = RunLock(lock_path)
            assert other.acquire() is False

        # After exit, lock should be released
        other = RunLock(lock_path)
        assert other.acquire() is True
        other.release()

    def test_release_without_acquire(self, tmp_path: Path) -> None:
        lock_path = tmp_path / "run-4" / ".lock"
        lock = RunLock(lock_path)
        lock.release()  # Should not raise


class TestWorkspaceAllowlist:
    def test_empty_allowlist_permits_all(self, tmp_path: Path) -> None:
        svc = OperatorService(
            runs_dir=tmp_path / "runs",
            policies_dir=tmp_path / "policies",
            ledger_dir=tmp_path / "ledger",
        )
        assert svc.is_workspace_allowed("/any/path") is True

    def test_allowlist_permits_matching(self, tmp_path: Path) -> None:
        allowed = tmp_path / "projects"
        allowed.mkdir()

        svc = OperatorService(
            runs_dir=tmp_path / "runs",
            policies_dir=tmp_path / "policies",
            ledger_dir=tmp_path / "ledger",
            allowed_workspaces=[str(allowed)],
        )
        assert svc.is_workspace_allowed(str(allowed / "myapp")) is True

    def test_allowlist_rejects_outside(self, tmp_path: Path) -> None:
        allowed = tmp_path / "projects"
        allowed.mkdir()

        svc = OperatorService(
            runs_dir=tmp_path / "runs",
            policies_dir=tmp_path / "policies",
            ledger_dir=tmp_path / "ledger",
            allowed_workspaces=[str(allowed)],
        )
        assert svc.is_workspace_allowed("/etc/passwd") is False


class TestOperatorRunRegistry:
    def _make_svc(self, tmp_path: Path) -> OperatorService:
        return OperatorService(
            runs_dir=tmp_path / "runs",
            policies_dir=tmp_path / "policies",
            ledger_dir=tmp_path / "ledger",
        )

    def test_no_runs_initially(self, tmp_path: Path) -> None:
        svc = self._make_svc(tmp_path)
        assert svc.all_runs() == []
        assert svc.active_runs() == []

    def test_get_nonexistent_run(self, tmp_path: Path) -> None:
        svc = self._make_svc(tmp_path)
        assert svc.get_run("missing") is None

    def test_stop_nonexistent(self, tmp_path: Path) -> None:
        svc = self._make_svc(tmp_path)
        assert svc.stop_run("missing") is False

    def test_lock_acquire_release(self, tmp_path: Path) -> None:
        svc = self._make_svc(tmp_path)
        run_dir = tmp_path / "runs" / "cycle-test"
        run_dir.mkdir(parents=True)

        assert svc.acquire_lock("cycle-test") is True
        svc.release_lock("cycle-test")

    def test_preflight(self, tmp_path: Path) -> None:
        svc = self._make_svc(tmp_path)
        result = svc.run_preflight(str(tmp_path), use_llm="none")
        assert result["ok"] is True
        assert result["checks_total"] > 0

    def test_start_autopilot_calls_run(self, tmp_path: Path) -> None:
        """Verify start_autopilot calls autopilot.run with correct config."""
        svc = self._make_svc(tmp_path)

        # Mock the autopilot.run
        mock_result = MagicMock()
        mock_result.run_id = "cycle-mock"
        mock_result.final_state = "DONE"
        mock_result.stop_reason = "terminal state: DONE"

        with patch("owlmind.autopilot.run", return_value=mock_result):
            info = svc.start_autopilot("test goal", str(tmp_path))

        assert info.run_id == "cycle-mock"
        assert info.status == "done"
        assert svc.get_run("cycle-mock") is not None

    def test_stop_tracked_run(self, tmp_path: Path) -> None:
        """Verify stop_run updates status."""
        svc = self._make_svc(tmp_path)
        svc._runs["cycle-1"] = RunInfo(
            run_id="cycle-1",
            goal="test",
            workspace=".",
        )
        assert svc.stop_run("cycle-1") is True
        info = svc.get_run("cycle-1")
        assert info is not None
        assert info.status == "stopped"


class TestRecoverRunsFromDisk:
    def _make_svc(self, tmp_path: Path) -> OperatorService:
        return OperatorService(
            runs_dir=tmp_path / "runs",
            policies_dir=tmp_path / "policies",
            ledger_dir=tmp_path / "ledger",
        )

    def test_runs_dir_missing_returns_empty_list(self, tmp_path: Path) -> None:
        """When runs_dir does not exist, recover returns []."""
        svc = self._make_svc(tmp_path)
        # runs_dir was not created
        result = svc.recover_runs_from_disk()
        assert result == []

    def test_run_dir_without_cycle_meta_is_skipped(self, tmp_path: Path) -> None:
        """A run directory with no cycle_meta.json is ignored."""
        svc = self._make_svc(tmp_path)
        runs_dir = tmp_path / "runs"
        runs_dir.mkdir(parents=True)
        (runs_dir / "run-no-meta").mkdir()

        result = svc.recover_runs_from_disk()
        assert result == []

    def test_running_state_is_recovered(self, tmp_path: Path) -> None:
        """A run in RUNNING state is recovered and returned."""
        import json

        svc = self._make_svc(tmp_path)
        runs_dir = tmp_path / "runs"
        run_dir = runs_dir / "run-001"
        run_dir.mkdir(parents=True)
        meta = {
            "run_id": "run-001",
            "goal": "do something",
            "workspace": "/tmp/ws",
            "state": "RUNNING",
        }
        (run_dir / "cycle_meta.json").write_text(json.dumps(meta))

        result = svc.recover_runs_from_disk()

        assert len(result) == 1
        info = result[0]
        assert info.run_id == "run-001"
        assert info.goal == "do something"
        assert info.workspace == "/tmp/ws"
        assert info.status == "running"
        assert info.final_state == "RUNNING"
        assert info.stop_reason == "recovered"

    def test_all_active_states_are_recovered(self, tmp_path: Path) -> None:
        """All _ACTIVE_STATES result in recovery."""
        import json

        svc = self._make_svc(tmp_path)
        runs_dir = tmp_path / "runs"
        active_states = [
            "RUNNING",
            "STARTED",
            "WAIT_APPROVAL",
            "STARTED_WAIT_PLANNER",
            "WAIT_WORKER",
            "WAIT_JUDGE",
        ]
        for i, state in enumerate(active_states):
            run_dir = runs_dir / f"run-{i:03d}"
            run_dir.mkdir(parents=True)
            meta = {"run_id": f"run-{i:03d}", "goal": f"goal {i}", "workspace": ".", "state": state}
            (run_dir / "cycle_meta.json").write_text(json.dumps(meta))

        result = svc.recover_runs_from_disk()
        assert len(result) == len(active_states)

    def test_done_state_is_not_recovered(self, tmp_path: Path) -> None:
        """A run in DONE state is not recovered."""
        import json

        svc = self._make_svc(tmp_path)
        runs_dir = tmp_path / "runs"
        run_dir = runs_dir / "run-done"
        run_dir.mkdir(parents=True)
        meta = {"run_id": "run-done", "goal": "finished", "workspace": ".", "state": "DONE"}
        (run_dir / "cycle_meta.json").write_text(json.dumps(meta))

        result = svc.recover_runs_from_disk()
        assert result == []

    def test_already_tracked_run_is_skipped(self, tmp_path: Path) -> None:
        """If run_id is already in self._runs, it is not re-added."""
        import json

        svc = self._make_svc(tmp_path)
        # Pre-populate _runs
        existing_info = RunInfo(run_id="run-exists", goal="already tracked", workspace=".")
        svc._runs["run-exists"] = existing_info

        runs_dir = tmp_path / "runs"
        run_dir = runs_dir / "run-exists"
        run_dir.mkdir(parents=True)
        meta = {"run_id": "run-exists", "goal": "on disk", "workspace": ".", "state": "RUNNING"}
        (run_dir / "cycle_meta.json").write_text(json.dumps(meta))

        result = svc.recover_runs_from_disk()
        assert result == []
        # Original in-memory info unchanged
        assert svc._runs["run-exists"] is existing_info

    def test_invalid_json_in_cycle_meta_is_skipped(self, tmp_path: Path) -> None:
        """A cycle_meta.json with invalid JSON is silently skipped."""
        svc = self._make_svc(tmp_path)
        runs_dir = tmp_path / "runs"
        run_dir = runs_dir / "run-bad-json"
        run_dir.mkdir(parents=True)
        (run_dir / "cycle_meta.json").write_text("{not valid json!!!")

        result = svc.recover_runs_from_disk()
        assert result == []

    def test_run_id_falls_back_to_dir_name(self, tmp_path: Path) -> None:
        """If cycle_meta.json has no run_id, the directory name is used."""
        import json

        svc = self._make_svc(tmp_path)
        runs_dir = tmp_path / "runs"
        run_dir = runs_dir / "cycle-fallback-id"
        run_dir.mkdir(parents=True)
        # No run_id key in meta
        meta = {"goal": "fallback goal", "workspace": ".", "state": "STARTED"}
        (run_dir / "cycle_meta.json").write_text(json.dumps(meta))

        result = svc.recover_runs_from_disk()
        assert len(result) == 1
        assert result[0].run_id == "cycle-fallback-id"

    def test_recovered_run_added_to_internal_registry(self, tmp_path: Path) -> None:
        """Recovered run is also inserted into self._runs."""
        import json

        svc = self._make_svc(tmp_path)
        runs_dir = tmp_path / "runs"
        run_dir = runs_dir / "run-reg"
        run_dir.mkdir(parents=True)
        meta = {"run_id": "run-reg", "goal": "registry test", "workspace": ".", "state": "RUNNING"}
        (run_dir / "cycle_meta.json").write_text(json.dumps(meta))

        svc.recover_runs_from_disk()
        assert "run-reg" in svc._runs
        assert svc._runs["run-reg"].status == "running"

    def test_non_directory_entries_are_skipped(self, tmp_path: Path) -> None:
        """Files in runs_dir (not directories) are ignored."""
        import json

        svc = self._make_svc(tmp_path)
        runs_dir = tmp_path / "runs"
        runs_dir.mkdir(parents=True)
        # Place a plain file in runs_dir
        (runs_dir / "README.txt").write_text("not a run dir")
        # Also add a valid run
        run_dir = runs_dir / "run-valid"
        run_dir.mkdir()
        meta = {"run_id": "run-valid", "goal": "valid", "workspace": ".", "state": "WAIT_WORKER"}
        (run_dir / "cycle_meta.json").write_text(json.dumps(meta))

        result = svc.recover_runs_from_disk()
        assert len(result) == 1
        assert result[0].run_id == "run-valid"


class TestOperatorSessionAPIs:
    def _make_svc(self, tmp_path: Path) -> OperatorService:
        return OperatorService(
            runs_dir=tmp_path / "runs",
            policies_dir=tmp_path / "policies",
            ledger_dir=tmp_path / "ledger",
        )

    def test_start_session_goals_file_not_found(self, tmp_path: Path) -> None:
        """start_session raises FileNotFoundError when goals file doesn't exist."""
        svc = self._make_svc(tmp_path)
        with pytest.raises(FileNotFoundError):
            svc.start_session(str(tmp_path / "missing.yaml"), str(tmp_path))

    def test_start_session_calls_create_and_run(self, tmp_path: Path) -> None:
        """start_session creates session and runs it; returns dict with session_id."""
        goals_file = tmp_path / "goals.yaml"
        goals_file.write_text("goals:\n  - goal: test\n")

        mock_meta = MagicMock()
        mock_meta.session_id = "sess-001"
        mock_meta.goals = []
        mock_meta.config = {}

        mock_result = MagicMock()
        mock_result.session_id = "sess-001"
        mock_result.status = "done"
        mock_result.goals_total = 1
        mock_result.goals_done = 1
        mock_result.goals_failed = 0
        mock_result.goals_blocked = 0
        mock_result.goals_skipped = 0
        mock_result.last_block_reason = ""
        mock_result.next_commands = []

        svc = self._make_svc(tmp_path)
        with (
            patch("owlmind.session.create_session", return_value=mock_meta),
            patch("owlmind.session.save_session"),
            patch("owlmind.session_runner.run_session", return_value=mock_result),
        ):
            result = svc.start_session(str(goals_file), str(tmp_path))

        assert result["session_id"] == "sess-001"
        assert result["status"] == "done"

    def test_resume_session_delegates_to_runner(self, tmp_path: Path) -> None:
        """resume_session calls run_session with the correct session_id."""
        mock_result = MagicMock()
        mock_result.session_id = "sess-resume-42"
        mock_result.status = "done"
        mock_result.goals_total = 2
        mock_result.goals_done = 2
        mock_result.goals_failed = 0
        mock_result.goals_blocked = 0
        mock_result.goals_skipped = 0
        mock_result.last_block_reason = ""
        mock_result.next_commands = []

        svc = self._make_svc(tmp_path)
        with patch("owlmind.session_runner.run_session", return_value=mock_result) as mock_run:
            result = svc.resume_session("sess-resume-42")

        mock_run.assert_called_once()
        call_args = mock_run.call_args
        assert call_args.args[0] == "sess-resume-42"
        assert result["session_id"] == "sess-resume-42"


# ---------------------------------------------------------------------------
# New tests targeting previously uncovered lines
# ---------------------------------------------------------------------------


class TestRunLockContextManagerError:
    """Lines 64-67: __enter__ raises RuntimeError when lock cannot be acquired."""

    def test_context_manager_raises_when_lock_already_held(self, tmp_path: Path) -> None:
        lock_path = tmp_path / "sub" / ".lock"
        held = RunLock(lock_path)
        assert held.acquire() is True

        try:
            with pytest.raises(RuntimeError, match="Could not acquire lock"), RunLock(lock_path):
                pass
        finally:
            held.release()

    def test_context_manager_releases_on_exit(self, tmp_path: Path) -> None:
        """After __exit__, lock is released so a new lock can be acquired."""
        lock_path = tmp_path / "sub2" / ".lock"
        with RunLock(lock_path):
            pass  # acquired and released via context

        second = RunLock(lock_path)
        assert second.acquire() is True
        second.release()


class TestRunLockReleaseOSError:
    """Lines 58-61: release() swallows OSError when flock fails."""

    def test_release_survives_oserror(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        import fcntl

        lock_path = tmp_path / "sub3" / ".lock"
        lock = RunLock(lock_path)
        assert lock.acquire() is True

        # Make flock raise on unlock attempt
        original_flock = fcntl.flock

        def bad_flock(fd: int, op: int) -> None:
            if op == fcntl.LOCK_UN:
                raise OSError("simulated flock error")
            original_flock(fd, op)

        monkeypatch.setattr(fcntl, "flock", bad_flock)
        lock.release()  # must not raise
        assert lock._file is None


class TestStartAutopilotSemaphore:
    """Lines 194-201: semaphore blocking when max_concurrent_runs reached."""

    def _make_svc(self, tmp_path: Path, max_concurrent: int) -> OperatorService:
        return OperatorService(
            runs_dir=tmp_path / "runs",
            policies_dir=tmp_path / "policies",
            ledger_dir=tmp_path / "ledger",
            max_concurrent_runs=max_concurrent,
        )

    def test_semaphore_blocks_when_full(self, tmp_path: Path) -> None:
        svc = self._make_svc(tmp_path, max_concurrent=1)
        assert svc._semaphore is not None
        # Exhaust the semaphore manually
        acquired = svc._semaphore.acquire(blocking=False)
        assert acquired is True

        try:
            with pytest.raises(RuntimeError, match="Max concurrent runs"):
                svc.start_autopilot("goal", str(tmp_path))
        finally:
            svc._semaphore.release()

    def test_semaphore_released_after_successful_run(self, tmp_path: Path) -> None:
        svc = self._make_svc(tmp_path, max_concurrent=1)

        mock_result = MagicMock()
        mock_result.run_id = "cycle-sem-ok"
        mock_result.final_state = "DONE"
        mock_result.stop_reason = ""

        with patch("owlmind.autopilot.run", return_value=mock_result):
            svc.start_autopilot("goal", str(tmp_path))

        # After completion the semaphore should be available again
        assert svc._semaphore is not None
        assert svc._semaphore.acquire(blocking=False)
        svc._semaphore.release()


class TestRunE2ESmoke:
    """Lines 266-304: run_e2e_smoke method."""

    def _make_svc(self, tmp_path: Path) -> OperatorService:
        return OperatorService(
            runs_dir=tmp_path / "runs",
            policies_dir=tmp_path / "policies",
            ledger_dir=tmp_path / "ledger",
        )

    def test_run_e2e_smoke_done(self, tmp_path: Path) -> None:
        svc = self._make_svc(tmp_path)
        mock_result = MagicMock()
        mock_result.run_id = "e2e-001"
        mock_result.exit_code = 0
        mock_result.final_state = "DONE"
        mock_result.preflight_ok = True
        mock_result.blocked_reason = ""
        mock_result.next_commands = []
        mock_result.report_path = "/tmp/report.json"

        with patch("owlmind.e2e.run_e2e", return_value=mock_result):
            result = svc.run_e2e_smoke("build hello world", str(tmp_path))

        assert result["run_id"] == "e2e-001"
        assert result["exit_code"] == 0
        assert result["final_state"] == "DONE"
        assert result["preflight_ok"] is True
        run_001 = svc.get_run("e2e-001")
        assert run_001 is not None
        assert run_001.status == "done"

    def test_run_e2e_smoke_blocked(self, tmp_path: Path) -> None:
        svc = self._make_svc(tmp_path)
        mock_result = MagicMock()
        mock_result.run_id = "e2e-002"
        mock_result.exit_code = 2
        mock_result.final_state = "WAIT_APPROVAL"
        mock_result.preflight_ok = True
        mock_result.blocked_reason = "needs human review"
        mock_result.next_commands = ["owlmind cycle approve"]
        mock_result.report_path = ""

        with patch("owlmind.e2e.run_e2e", return_value=mock_result):
            result = svc.run_e2e_smoke("risky task", str(tmp_path))

        assert result["exit_code"] == 2
        run_002 = svc.get_run("e2e-002")
        assert run_002 is not None
        assert run_002.status == "blocked"

    def test_run_e2e_smoke_failed(self, tmp_path: Path) -> None:
        svc = self._make_svc(tmp_path)
        mock_result = MagicMock()
        mock_result.run_id = "e2e-003"
        mock_result.exit_code = 1
        mock_result.final_state = "FAILED"
        mock_result.preflight_ok = False
        mock_result.blocked_reason = ""
        mock_result.next_commands = []
        mock_result.report_path = ""

        with patch("owlmind.e2e.run_e2e", return_value=mock_result):
            result = svc.run_e2e_smoke("bad task", str(tmp_path))

        assert result["exit_code"] == 1
        run_003 = svc.get_run("e2e-003")
        assert run_003 is not None
        assert run_003.status == "failed"


class TestUpdateModelConfig:
    """Lines 418-441: update_model_config sets env vars and profile."""

    def _make_svc(self, tmp_path: Path) -> OperatorService:
        return OperatorService(
            runs_dir=tmp_path / "runs",
            policies_dir=tmp_path / "policies",
            ledger_dir=tmp_path / "ledger",
        )

    def test_fast_profile(self, tmp_path: Path) -> None:
        import os

        svc = self._make_svc(tmp_path)
        svc.update_model_config("fast")
        assert svc.llm_profile == "fast"
        assert os.environ["OWLMIND_LLM_PROFILE"] == "fast"
        assert os.environ["OWLMIND_LLM_MODEL"] == "claude-3-haiku-20240307"
        assert os.environ["OWLMIND_ANTHROPIC_MODEL"] == "claude-3-haiku-20240307"

    def test_balanced_profile(self, tmp_path: Path) -> None:
        import os

        svc = self._make_svc(tmp_path)
        svc.update_model_config("balanced")
        assert svc.llm_profile == "balanced"
        assert os.environ["OWLMIND_LLM_PROFILE"] == "balanced"
        assert "sonnet" in os.environ["OWLMIND_LLM_MODEL"].lower()

    def test_powerful_profile(self, tmp_path: Path) -> None:
        import os

        svc = self._make_svc(tmp_path)
        svc.update_model_config("powerful")
        assert svc.llm_profile == "powerful"
        assert os.environ["OWLMIND_LLM_PROFILE"] == "powerful"
        assert "opus" in os.environ["OWLMIND_LLM_MODEL"].lower()

    def test_unknown_profile_raises(self, tmp_path: Path) -> None:
        svc = self._make_svc(tmp_path)
        with pytest.raises(ValueError, match="Unknown LLM profile"):
            svc.update_model_config("turbo-9000")

    def test_llm_profile_property_default(self, tmp_path: Path) -> None:
        """Line 446: llm_profile property returns initial value."""
        svc = self._make_svc(tmp_path)
        assert svc.llm_profile == "balanced"


class TestResumeSessionMethod:
    """Lines 532-554: resume_session passes optional kwargs correctly."""

    def _make_svc(self, tmp_path: Path) -> OperatorService:
        return OperatorService(
            runs_dir=tmp_path / "runs",
            policies_dir=tmp_path / "policies",
            ledger_dir=tmp_path / "ledger",
        )

    def test_resume_passes_max_concurrency(self, tmp_path: Path) -> None:
        svc = self._make_svc(tmp_path)

        mock_result = MagicMock()
        mock_result.session_id = "sess-r1"
        mock_result.status = "done"
        mock_result.goals_total = 1
        mock_result.goals_done = 1
        mock_result.goals_failed = 0
        mock_result.goals_blocked = 0
        mock_result.goals_skipped = 0
        mock_result.last_block_reason = ""
        mock_result.next_commands = []

        with patch("owlmind.session_runner.run_session", return_value=mock_result) as mock_run:
            svc.resume_session("sess-r1", max_concurrency=3, continue_on_fail=True)

        call_kwargs = mock_run.call_args.kwargs
        assert call_kwargs["max_concurrency"] == 3
        assert call_kwargs["continue_on_fail"] is True


class TestListSessionsErrorHandling:
    """Lines 730-731: list_sessions swallows exceptions per broken session."""

    def _make_svc(self, tmp_path: Path) -> OperatorService:
        return OperatorService(
            runs_dir=tmp_path / "runs",
            policies_dir=tmp_path / "policies",
            ledger_dir=tmp_path / "ledger",
            sessions_dir=tmp_path / "sessions",
        )

    def test_broken_session_gets_fallback_entry(self, tmp_path: Path) -> None:
        svc = self._make_svc(tmp_path)
        sessions_dir = tmp_path / "sessions"

        # Create a session directory with a malformed session_meta.json
        sdir = sessions_dir / "bad-session"
        sdir.mkdir(parents=True)
        (sdir / "session_meta.json").write_text("{not valid json!!")

        result = svc.list_sessions(n=10)
        # The broken session should appear with fallback status "?"
        assert len(result) == 1
        assert result[0]["session_id"] == "bad-session"
        assert result[0]["status"] == "?"
        assert result[0]["goals_total"] == 0


class TestStartAutopilotAsync:
    """Lines 226-227: start_autopilot_async wraps sync in executor."""

    def _make_svc(self, tmp_path: Path) -> OperatorService:
        return OperatorService(
            runs_dir=tmp_path / "runs",
            policies_dir=tmp_path / "policies",
            ledger_dir=tmp_path / "ledger",
        )

    def test_async_returns_run_info(self, tmp_path: Path) -> None:
        import asyncio

        svc = self._make_svc(tmp_path)

        mock_result = MagicMock()
        mock_result.run_id = "cycle-async-01"
        mock_result.final_state = "DONE"
        mock_result.stop_reason = ""

        with patch("owlmind.autopilot.run", return_value=mock_result):
            info = asyncio.run(svc.start_autopilot_async("async goal", str(tmp_path)))

        assert info.run_id == "cycle-async-01"
        assert info.status == "done"


class TestRecoverSessionsFromDisk:
    """Lines 369-408: recover_sessions_from_disk method."""

    def _make_svc(self, tmp_path: Path) -> OperatorService:
        return OperatorService(
            runs_dir=tmp_path / "runs",
            policies_dir=tmp_path / "policies",
            ledger_dir=tmp_path / "ledger",
        )

    def test_no_sessions_dir_returns_empty(self, tmp_path: Path) -> None:
        svc = self._make_svc(tmp_path)
        # sessions_dir = runs_dir.parent / "sessions" = tmp_path / "sessions", not created
        result = svc.recover_sessions_from_disk()
        assert result == []

    def test_running_session_recovered(self, tmp_path: Path) -> None:
        svc = self._make_svc(tmp_path)
        sessions_dir = tmp_path / "sessions"

        # create a session with RUNNING status
        import json

        sid = "orphan-sess-001"
        sdir = sessions_dir / sid
        sdir.mkdir(parents=True)
        session_meta = {
            "session_id": sid,
            "created_at": "2025-01-01T00:00:00",
            "updated_at": "2025-01-01T00:00:00",
            "status": "RUNNING",
            "current_goal_index": 0,
            "goals": [],
            "runs": [],
            "last_block_reason": "",
            "config": {},
            "max_concurrency": 1,
            "continue_on_fail": False,
        }
        (sdir / "session_meta.json").write_text(json.dumps(session_meta))

        result = svc.recover_sessions_from_disk()
        assert len(result) == 1
        assert result[0]["session_id"] == sid
        assert result[0]["status"] == "RUNNING"

    def test_done_session_not_recovered(self, tmp_path: Path) -> None:
        svc = self._make_svc(tmp_path)
        sessions_dir = tmp_path / "sessions"

        import json

        sid = "done-sess"
        sdir = sessions_dir / sid
        sdir.mkdir(parents=True)
        session_meta = {
            "session_id": sid,
            "created_at": "2025-01-01T00:00:00",
            "updated_at": "2025-01-01T00:00:00",
            "status": "DONE",
            "current_goal_index": 0,
            "goals": [],
            "runs": [],
            "last_block_reason": "",
            "config": {},
            "max_concurrency": 1,
            "continue_on_fail": False,
        }
        (sdir / "session_meta.json").write_text(json.dumps(session_meta))

        result = svc.recover_sessions_from_disk()
        assert result == []

    def test_load_session_exception_is_skipped(self, tmp_path: Path) -> None:
        svc = self._make_svc(tmp_path)
        sessions_dir = tmp_path / "sessions"

        # A directory that has no valid session_meta.json -> load_session will raise
        sdir = sessions_dir / "broken-sess"
        sdir.mkdir(parents=True)
        # no session_meta.json

        result = svc.recover_sessions_from_disk()
        assert result == []


# ---------------------------------------------------------------------------
# New tests for previously uncovered lines
# ---------------------------------------------------------------------------


class TestAcquireLockReturnsFalse:
    """Line 158: acquire_lock returns False when lock already held."""

    def _make_svc(self, tmp_path: Path) -> OperatorService:
        return OperatorService(
            runs_dir=tmp_path / "runs",
            policies_dir=tmp_path / "policies",
            ledger_dir=tmp_path / "ledger",
        )

    def test_acquire_lock_false_when_held(self, tmp_path: Path) -> None:
        svc = self._make_svc(tmp_path)
        run_dir = tmp_path / "runs" / "cycle-lock-test"
        run_dir.mkdir(parents=True)
        ext = RunLock(run_dir / ".lock")
        assert ext.acquire() is True
        try:
            assert svc.acquire_lock("cycle-lock-test") is False
        finally:
            ext.release()


class TestRecoverSessionsNonDirSkipped:
    """Line 380: non-directory entries in sessions_dir are skipped."""

    def _make_svc(self, tmp_path: Path) -> OperatorService:
        return OperatorService(
            runs_dir=tmp_path / "runs",
            policies_dir=tmp_path / "policies",
            ledger_dir=tmp_path / "ledger",
        )

    def test_plain_file_skipped(self, tmp_path: Path) -> None:
        import json

        svc = self._make_svc(tmp_path)
        sessions_dir = tmp_path / "sessions"
        sessions_dir.mkdir(parents=True)
        (sessions_dir / "stale.lock").write_text("lock")

        sid = "valid-sess"
        sdir = sessions_dir / sid
        sdir.mkdir()
        meta = {
            "session_id": sid,
            "created_at": "2025-01-01T00:00:00",
            "updated_at": "2025-01-01T00:00:00",
            "status": "RUNNING",
            "current_goal_index": 0,
            "goals": [],
            "runs": [],
            "last_block_reason": "",
            "config": {},
            "max_concurrency": 1,
            "continue_on_fail": False,
        }
        (sdir / "session_meta.json").write_text(json.dumps(meta))

        result = svc.recover_sessions_from_disk()
        assert len(result) == 1
        assert result[0]["session_id"] == sid


class TestStartSessionGoalOverrides:
    """Lines 490-495: sandbox/use_llm/use_worker overrides applied to goals."""

    def _make_svc(self, tmp_path: Path) -> OperatorService:
        return OperatorService(
            runs_dir=tmp_path / "runs",
            policies_dir=tmp_path / "policies",
            ledger_dir=tmp_path / "ledger",
        )

    def _mock_meta_result(self, sid: str = "sess-x") -> tuple[MagicMock, MagicMock, MagicMock]:
        goal = MagicMock()
        goal.sandbox = False
        goal.use_llm = "both"
        goal.use_worker = "none"
        meta = MagicMock()
        meta.session_id = sid
        meta.goals = [goal]
        meta.config = {}
        res = MagicMock()
        res.session_id = sid
        res.status = "done"
        res.goals_total = 1
        res.goals_done = 1
        res.goals_failed = 0
        res.goals_blocked = 0
        res.goals_skipped = 0
        res.last_block_reason = ""
        res.next_commands = []
        return goal, meta, res

    def test_sandbox_override(self, tmp_path: Path) -> None:
        goals_file = tmp_path / "goals.yaml"
        goals_file.write_text("goals:\n  - goal: sandboxed\n")
        goal, meta, res = self._mock_meta_result()
        svc = self._make_svc(tmp_path)
        with (
            patch("owlmind.session.create_session", return_value=meta),
            patch("owlmind.session.save_session"),
            patch("owlmind.session_runner.run_session", return_value=res),
        ):
            svc.start_session(str(goals_file), str(tmp_path), sandbox=True)
        assert goal.sandbox is True

    def test_use_llm_override(self, tmp_path: Path) -> None:
        goals_file = tmp_path / "goals.yaml"
        goals_file.write_text("goals:\n  - goal: llm-only\n")
        goal, meta, res = self._mock_meta_result("sess-llm")
        svc = self._make_svc(tmp_path)
        with (
            patch("owlmind.session.create_session", return_value=meta),
            patch("owlmind.session.save_session"),
            patch("owlmind.session_runner.run_session", return_value=res),
        ):
            svc.start_session(str(goals_file), str(tmp_path), use_llm="llm")
        assert goal.use_llm == "llm"

    def test_use_worker_override(self, tmp_path: Path) -> None:
        goals_file = tmp_path / "goals.yaml"
        goals_file.write_text("goals:\n  - goal: worker-task\n")
        goal, meta, res = self._mock_meta_result("sess-wk")
        svc = self._make_svc(tmp_path)
        with (
            patch("owlmind.session.create_session", return_value=meta),
            patch("owlmind.session.save_session"),
            patch("owlmind.session_runner.run_session", return_value=res),
        ):
            svc.start_session(str(goals_file), str(tmp_path), use_worker="worker")
        assert goal.use_worker == "worker"


class TestStartSessionAsync:
    """Lines 526-527: start_session_async runs in executor."""

    def _make_svc(self, tmp_path: Path) -> OperatorService:
        return OperatorService(
            runs_dir=tmp_path / "runs",
            policies_dir=tmp_path / "policies",
            ledger_dir=tmp_path / "ledger",
        )

    @pytest.mark.asyncio()
    async def test_start_session_async(self, tmp_path: Path) -> None:
        goals_file = tmp_path / "goals.yaml"
        goals_file.write_text("goals:\n  - goal: async task\n")
        meta = MagicMock()
        meta.session_id = "sess-async-01"
        meta.goals = []
        meta.config = {}
        res = MagicMock()
        res.session_id = "sess-async-01"
        res.status = "done"
        res.goals_total = 1
        res.goals_done = 1
        res.goals_failed = 0
        res.goals_blocked = 0
        res.goals_skipped = 0
        res.last_block_reason = ""
        res.next_commands = []
        svc = self._make_svc(tmp_path)
        with (
            patch("owlmind.session.create_session", return_value=meta),
            patch("owlmind.session.save_session"),
            patch("owlmind.session_runner.run_session", return_value=res),
        ):
            result = await svc.start_session_async(str(goals_file), str(tmp_path))
        assert result["session_id"] == "sess-async-01"
        assert result["status"] == "done"


class TestResumeSessionAsync:
    """Lines 562-563: resume_session_async runs in executor."""

    def _make_svc(self, tmp_path: Path) -> OperatorService:
        return OperatorService(
            runs_dir=tmp_path / "runs",
            policies_dir=tmp_path / "policies",
            ledger_dir=tmp_path / "ledger",
        )

    @pytest.mark.asyncio()
    async def test_resume_session_async(self, tmp_path: Path) -> None:
        res = MagicMock()
        res.session_id = "sess-resume"
        res.status = "done"
        res.goals_total = 2
        res.goals_done = 2
        res.goals_failed = 0
        res.goals_blocked = 0
        res.goals_skipped = 0
        res.last_block_reason = ""
        res.next_commands = []
        svc = self._make_svc(tmp_path)
        with patch("owlmind.session_runner.run_session", return_value=res):
            result = await svc.resume_session_async("sess-resume")
        assert result["session_id"] == "sess-resume"
