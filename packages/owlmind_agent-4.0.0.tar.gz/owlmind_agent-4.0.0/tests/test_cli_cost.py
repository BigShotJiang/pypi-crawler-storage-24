"""Tests for FS66 — CLI cost estimation commands (estimate-goal, estimate-session)."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from owlmind.cli import app

runner = CliRunner()


def _mock_goal_estimate() -> MagicMock:
    """Build a mock GoalCostEstimate with all required numeric attributes."""
    est = MagicMock()
    est.provider = "openai"
    est.iterations = 1
    est.estimated_input_tokens = 1_000
    est.estimated_output_tokens = 200
    est.estimated_total_tokens = 1_200
    est.display_range = "$0.01 - $0.02"
    est.budget_pct = 5.0
    est.budget_warning = False
    est.details = {"complexity_multiplier": 1.0}
    return est


def _mock_session_estimate() -> MagicMock:
    """Build a mock SessionCostEstimate with all required numeric attributes."""
    est = MagicMock()
    est.provider = "openai"
    est.iterations = 1
    est.estimated_input_tokens = 5_000
    est.estimated_output_tokens = 1_000
    est.estimated_total_tokens = 6_000
    est.display_range = "$0.05 - $0.10"
    est.budget_pct = 25.0
    est.budget_warning = False
    est.details = {"goal_count": 2, "goals": []}
    return est


def _mock_config() -> MagicMock:
    cfg = MagicMock()
    cfg.budget.max_usd_per_day = 10.0
    return cfg


class TestCostEstimateGoal:
    def test_estimate_goal_ok(self) -> None:
        """estimate-goal with valid goal → exit 0, table rendered."""
        with (
            patch("owlmind.cli.cost_cmd.OwlMindConfig") as MockCfg,
            patch("owlmind.cli.cost_cmd.estimate_goal", return_value=_mock_goal_estimate()),
        ):
            MockCfg.from_env.return_value = _mock_config()
            result = runner.invoke(app, ["cost", "estimate-goal", "add unit tests"])

        assert result.exit_code == 0, result.output

    def test_estimate_goal_default_provider(self) -> None:
        """estimate-goal without --provider uses 'openai' by default."""
        with (
            patch("owlmind.cli.cost_cmd.OwlMindConfig") as MockCfg,
            patch(
                "owlmind.cli.cost_cmd.estimate_goal", return_value=_mock_goal_estimate()
            ) as mock_fn,
        ):
            MockCfg.from_env.return_value = _mock_config()
            runner.invoke(app, ["cost", "estimate-goal", "test goal"])

        mock_fn.assert_called_once()
        # Second positional arg is provider
        assert mock_fn.call_args.args[1] == "openai"


class TestCostEstimateSession:
    def test_estimate_session_file_not_found(self, tmp_path: Path) -> None:
        """estimate-session with missing YAML → exit 1."""
        result = runner.invoke(app, ["cost", "estimate-session", str(tmp_path / "missing.yaml")])

        assert result.exit_code == 1
        assert "not found" in result.output

    def test_estimate_session_ok(self, tmp_path: Path) -> None:
        """estimate-session with valid goals YAML → exit 0."""
        goals_file = tmp_path / "goals.yaml"
        goals_file.write_text("goals:\n  - goal: first task\n  - goal: second task\n")

        with (
            patch("owlmind.cli.cost_cmd.OwlMindConfig") as MockCfg,
            patch("owlmind.cli.cost_cmd.estimate_session", return_value=_mock_session_estimate()),
        ):
            MockCfg.from_env.return_value = _mock_config()
            result = runner.invoke(app, ["cost", "estimate-session", str(goals_file)])

        assert result.exit_code == 0, result.output

    def test_estimate_session_empty_goals(self, tmp_path: Path) -> None:
        """estimate-session with empty goals list → exit 0 (not an error)."""
        goals_file = tmp_path / "goals.yaml"
        goals_file.write_text("goals: []\n")

        result = runner.invoke(app, ["cost", "estimate-session", str(goals_file)])

        assert result.exit_code == 0
        assert "No goals found" in result.output


class TestCostEstimateGoalBudgetWarning:
    def test_estimate_goal_budget_warning_printed(self) -> None:
        """Line 53: budget_warning=True → warning message is printed."""
        est = _mock_goal_estimate()
        est.budget_warning = True

        with (
            patch("owlmind.cli.cost_cmd.OwlMindConfig") as MockCfg,
            patch("owlmind.cli.cost_cmd.estimate_goal", return_value=est),
        ):
            MockCfg.from_env.return_value = _mock_config()
            result = runner.invoke(app, ["cost", "estimate-goal", "big expensive goal"])

        assert result.exit_code == 0, result.output
        assert "WARNING" in result.output
        assert "50%" in result.output

    def test_estimate_goal_no_warning_when_false(self) -> None:
        """Line 52-53: budget_warning=False → no warning message."""
        est = _mock_goal_estimate()
        est.budget_warning = False

        with (
            patch("owlmind.cli.cost_cmd.OwlMindConfig") as MockCfg,
            patch("owlmind.cli.cost_cmd.estimate_goal", return_value=est),
        ):
            MockCfg.from_env.return_value = _mock_config()
            result = runner.invoke(app, ["cost", "estimate-goal", "small goal"])

        assert result.exit_code == 0, result.output
        assert "WARNING" not in result.output


class TestCostEstimateSessionFormats:
    def test_estimate_session_list_format(self, tmp_path: Path) -> None:
        """Lines 78-79: YAML root is a plain list of strings → goals parsed correctly."""
        goals_file = tmp_path / "goals.yaml"
        goals_file.write_text("- first goal\n- second goal\n")

        with (
            patch("owlmind.cli.cost_cmd.OwlMindConfig") as MockCfg,
            patch(
                "owlmind.cli.cost_cmd.estimate_session", return_value=_mock_session_estimate()
            ) as mock_fn,
        ):
            MockCfg.from_env.return_value = _mock_config()
            result = runner.invoke(app, ["cost", "estimate-session", str(goals_file)])

        assert result.exit_code == 0, result.output
        # estimate_session should have been called with two goals
        call_args = mock_fn.call_args
        assert call_args.args[0] == ["first goal", "second goal"]

    def test_estimate_session_invalid_format(self, tmp_path: Path) -> None:
        """Lines 80-82: YAML root is not dict or list → exit 1 with error."""
        goals_file = tmp_path / "goals.yaml"
        goals_file.write_text("just a plain string\n")

        result = runner.invoke(app, ["cost", "estimate-session", str(goals_file)])

        assert result.exit_code == 1
        assert "Invalid goals file format" in result.output

    def test_estimate_session_dict_with_string_goals(self, tmp_path: Path) -> None:
        """Line 86: dict format with plain string goals → appended directly."""
        goals_file = tmp_path / "goals.yaml"
        goals_file.write_text("goals:\n  - plain string goal\n  - another plain goal\n")

        with (
            patch("owlmind.cli.cost_cmd.OwlMindConfig") as MockCfg,
            patch(
                "owlmind.cli.cost_cmd.estimate_session", return_value=_mock_session_estimate()
            ) as mock_fn,
        ):
            MockCfg.from_env.return_value = _mock_config()
            result = runner.invoke(app, ["cost", "estimate-session", str(goals_file)])

        assert result.exit_code == 0, result.output
        call_args = mock_fn.call_args
        assert "plain string goal" in call_args.args[0]
        assert "another plain goal" in call_args.args[0]

    def test_estimate_session_list_of_strings(self, tmp_path: Path) -> None:
        """Line 86: list-of-strings root format → all items appended."""
        goals_file = tmp_path / "goals.yaml"
        goals_file.write_text("- task alpha\n- task beta\n- task gamma\n")

        with (
            patch("owlmind.cli.cost_cmd.OwlMindConfig") as MockCfg,
            patch(
                "owlmind.cli.cost_cmd.estimate_session", return_value=_mock_session_estimate()
            ) as mock_fn,
        ):
            MockCfg.from_env.return_value = _mock_config()
            result = runner.invoke(app, ["cost", "estimate-session", str(goals_file)])

        assert result.exit_code == 0, result.output
        call_args = mock_fn.call_args
        assert len(call_args.args[0]) == 3


class TestCostEstimateSessionBreakdownAndWarning:
    def _make_session_with_goals(self) -> MagicMock:
        """Session estimate with per-goal detail rows."""
        est = _mock_session_estimate()
        est.details = {
            "goal_count": 2,
            "goals": [
                {"goal": "first task", "usd_range": "$0.01 - $0.02"},
                {"goal": "second task", "usd_range": "$0.02 - $0.04"},
            ],
        }
        return est

    def test_per_goal_breakdown_table_rendered(self, tmp_path: Path) -> None:
        """Lines 122-130: when goal_details is non-empty, breakdown table is printed."""
        goals_file = tmp_path / "goals.yaml"
        goals_file.write_text("- first task\n- second task\n")

        est = self._make_session_with_goals()

        with (
            patch("owlmind.cli.cost_cmd.OwlMindConfig") as MockCfg,
            patch("owlmind.cli.cost_cmd.estimate_session", return_value=est),
        ):
            MockCfg.from_env.return_value = _mock_config()
            result = runner.invoke(app, ["cost", "estimate-session", str(goals_file)])

        assert result.exit_code == 0, result.output
        assert "Per-Goal Breakdown" in result.output

    def test_session_budget_warning_printed(self, tmp_path: Path) -> None:
        """Line 133: budget_warning=True on session → warning printed."""
        goals_file = tmp_path / "goals.yaml"
        goals_file.write_text("- task one\n- task two\n")

        est = _mock_session_estimate()
        est.budget_warning = True

        with (
            patch("owlmind.cli.cost_cmd.OwlMindConfig") as MockCfg,
            patch("owlmind.cli.cost_cmd.estimate_session", return_value=est),
        ):
            MockCfg.from_env.return_value = _mock_config()
            result = runner.invoke(app, ["cost", "estimate-session", str(goals_file)])

        assert result.exit_code == 0, result.output
        assert "WARNING" in result.output
        assert "session" in result.output.lower()

    def test_session_no_warning_when_false(self, tmp_path: Path) -> None:
        """Line 132-133: budget_warning=False on session → no warning."""
        goals_file = tmp_path / "goals.yaml"
        goals_file.write_text("- task one\n")

        est = _mock_session_estimate()
        est.budget_warning = False

        with (
            patch("owlmind.cli.cost_cmd.OwlMindConfig") as MockCfg,
            patch("owlmind.cli.cost_cmd.estimate_session", return_value=est),
        ):
            MockCfg.from_env.return_value = _mock_config()
            result = runner.invoke(app, ["cost", "estimate-session", str(goals_file)])

        assert result.exit_code == 0, result.output
        assert "WARNING" not in result.output

    def test_breakdown_and_warning_combined(self, tmp_path: Path) -> None:
        """Lines 122-130, 133: breakdown table + budget warning together."""
        goals_file = tmp_path / "goals.yaml"
        goals_file.write_text("- first task\n- second task\n")

        est = self._make_session_with_goals()
        est.budget_warning = True

        with (
            patch("owlmind.cli.cost_cmd.OwlMindConfig") as MockCfg,
            patch("owlmind.cli.cost_cmd.estimate_session", return_value=est),
        ):
            MockCfg.from_env.return_value = _mock_config()
            result = runner.invoke(app, ["cost", "estimate-session", str(goals_file)])

        assert result.exit_code == 0, result.output
        assert "Per-Goal Breakdown" in result.output
        assert "WARNING" in result.output
