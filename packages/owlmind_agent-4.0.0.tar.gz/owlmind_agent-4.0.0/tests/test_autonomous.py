"""Tests for owlmind.autonomous — AutonomousScheduler."""
from __future__ import annotations

import time
from pathlib import Path
from unittest.mock import MagicMock, patch

from owlmind.autonomous import AutonomousScheduler, RunRecord, ScheduledGoal

# ---------------------------------------------------------------------------
# ScheduledGoal / RunRecord
# ---------------------------------------------------------------------------


class TestScheduledGoal:
    def test_defaults(self) -> None:
        sg = ScheduledGoal(goal="fix tests")
        assert sg.goal == "fix tests"
        assert sg.workspace == "."
        assert sg.priority == 0
        assert sg.source == "manual"
        assert sg.created_at  # non-empty ISO timestamp

    def test_custom_fields(self) -> None:
        sg = ScheduledGoal(goal="g", workspace="/tmp", priority=5, source="github:owner/repo")
        assert sg.workspace == "/tmp"
        assert sg.priority == 5
        assert sg.source == "github:owner/repo"


class TestRunRecord:
    def test_success_property_approved(self) -> None:
        r = RunRecord(goal="g", workspace=".", started_at="t", verdict="APPROVED")
        assert r.success is True

    def test_success_property_needs_fix(self) -> None:
        r = RunRecord(goal="g", workspace=".", started_at="t", verdict="NEEDS_FIX")
        assert r.success is False

    def test_success_property_error(self) -> None:
        r = RunRecord(goal="g", workspace=".", started_at="t", error="oops")
        assert r.success is False


# ---------------------------------------------------------------------------
# AutonomousScheduler — queue management
# ---------------------------------------------------------------------------


class TestQueueManagement:
    def test_add_goal_enqueues(self) -> None:
        sched = AutonomousScheduler()
        sg = sched.add_goal("write tests")
        assert isinstance(sg, ScheduledGoal)
        assert len(sched._queue) == 1
        assert sched._queue[0].goal == "write tests"

    def test_add_goal_custom_workspace(self) -> None:
        sched = AutonomousScheduler(workspace="/default")
        sched.add_goal("task", workspace="/custom")
        assert sched._queue[0].workspace == "/custom"

    def test_add_goal_uses_default_workspace(self) -> None:
        sched = AutonomousScheduler(workspace="/default")
        sched.add_goal("task")
        assert sched._queue[0].workspace == "/default"

    def test_priority_ordering(self) -> None:
        sched = AutonomousScheduler()
        sched.add_goal("low", priority=0)
        sched.add_goal("high", priority=10)
        sched.add_goal("mid", priority=5)
        # Queue sorted descending by priority
        assert sched._queue[0].goal == "high"
        assert sched._queue[1].goal == "mid"
        assert sched._queue[2].goal == "low"

    def test_pop_goal_removes_from_queue(self) -> None:
        sched = AutonomousScheduler()
        sched.add_goal("task")
        sg = sched._pop_goal()
        assert sg is not None
        assert sg.goal == "task"
        assert len(sched._queue) == 0

    def test_pop_goal_returns_none_when_empty(self) -> None:
        sched = AutonomousScheduler()
        assert sched._pop_goal() is None


# ---------------------------------------------------------------------------
# AutonomousScheduler — run_once
# ---------------------------------------------------------------------------


class TestRunOnce:
    def test_run_once_empty_queue(self) -> None:
        sched = AutonomousScheduler()
        records = sched.run_once()
        assert records == []

    def test_run_once_calls_graph_runner(self, tmp_path: Path) -> None:
        sched = AutonomousScheduler(workspace=str(tmp_path))
        sched.add_goal("write hello.py")

        mock_state = MagicMock()
        mock_state.final_verdict = "APPROVED"

        mock_runner = MagicMock()
        mock_runner.run.return_value = mock_state

        with patch("owlmind.autonomous.GraphRunner", return_value=mock_runner):
            records = sched.run_once()

        assert len(records) == 1
        assert records[0].verdict == "APPROVED"
        assert records[0].success is True
        assert records[0].goal == "write hello.py"

    def test_run_once_handles_runner_error(self, tmp_path: Path) -> None:
        sched = AutonomousScheduler(workspace=str(tmp_path))
        sched.add_goal("fail task")

        with patch("owlmind.autonomous.GraphRunner", side_effect=RuntimeError("API down")):
            records = sched.run_once()

        assert len(records) == 1
        assert records[0].error == "API down"
        assert records[0].verdict == ""
        assert records[0].success is False

    def test_run_once_calls_on_complete_callback(self, tmp_path: Path) -> None:
        completed: list[RunRecord] = []
        sched = AutonomousScheduler(
            workspace=str(tmp_path),
            on_run_complete=lambda r: completed.append(r),
        )
        sched.add_goal("task")

        mock_state = MagicMock()
        mock_state.final_verdict = "NEEDS_FIX"

        with patch("owlmind.autonomous.GraphRunner") as MockRunner:
            MockRunner.return_value.run.return_value = mock_state
            sched.run_once()

        assert len(completed) == 1
        assert completed[0].verdict == "NEEDS_FIX"

    def test_run_once_processes_all_queued_goals(self, tmp_path: Path) -> None:
        sched = AutonomousScheduler(workspace=str(tmp_path))
        for i in range(3):
            sched.add_goal(f"goal {i}")

        mock_state = MagicMock()
        mock_state.final_verdict = "APPROVED"

        with patch("owlmind.autonomous.GraphRunner") as MockRunner:
            MockRunner.return_value.run.return_value = mock_state
            records = sched.run_once()

        assert len(records) == 3
        assert len(sched._queue) == 0

    def test_run_once_stores_history(self, tmp_path: Path) -> None:
        sched = AutonomousScheduler(workspace=str(tmp_path))
        sched.add_goal("task")

        mock_state = MagicMock()
        mock_state.final_verdict = "APPROVED"

        with patch("owlmind.autonomous.GraphRunner") as MockRunner:
            MockRunner.return_value.run.return_value = mock_state
            sched.run_once()

        assert len(sched._history) == 1


# ---------------------------------------------------------------------------
# AutonomousScheduler — file watcher
# ---------------------------------------------------------------------------


class TestFileWatcher:
    def test_watch_file_registers(self, tmp_path: Path) -> None:
        f = tmp_path / "test.py"
        f.write_text("x = 1")
        sched = AutonomousScheduler()
        sched.watch_file(str(f))
        assert len(sched._file_watchers) == 1
        assert sched._file_watchers[0]["path"] == str(f)

    def test_poll_files_triggers_on_change(self, tmp_path: Path) -> None:
        f = tmp_path / "watched.py"
        f.write_text("x = 1")
        sched = AutonomousScheduler()
        sched.watch_file(str(f), goal_template="Handle change in {file}")

        # Advance mtime by simulating a write
        time.sleep(0.01)
        f.write_text("x = 2")
        # Artificially set last_mtime to before the file change
        sched._file_watchers[0]["last_mtime"] = 0

        sched._poll_files()
        assert len(sched._queue) == 1
        assert "watched.py" in sched._queue[0].goal

    def test_poll_files_no_trigger_if_unchanged(self, tmp_path: Path) -> None:
        f = tmp_path / "stable.py"
        f.write_text("y = 1")
        sched = AutonomousScheduler()
        sched.watch_file(str(f))
        # Set last_mtime to current mtime (no change)
        sched._file_watchers[0]["last_mtime"] = f.stat().st_mtime
        sched._poll_files()
        assert len(sched._queue) == 0

    def test_poll_files_ignores_missing_file(self, tmp_path: Path) -> None:
        sched = AutonomousScheduler()
        sched.watch_file(str(tmp_path / "nonexistent.py"))
        # Should not raise
        sched._poll_files()
        assert len(sched._queue) == 0


# ---------------------------------------------------------------------------
# AutonomousScheduler — GitHub watcher
# ---------------------------------------------------------------------------


class TestGitHubWatcher:
    def test_watch_github_registers(self) -> None:
        sched = AutonomousScheduler()
        sched.watch_github("owner/repo", event="issues", label="bug")
        assert len(sched._github_watchers) == 1
        w = sched._github_watchers[0]
        assert w["repo"] == "owner/repo"
        assert w["event"] == "issues"
        assert w["label"] == "bug"

    def test_poll_github_enqueues_new_issues(self) -> None:
        sched = AutonomousScheduler()
        sched.watch_github("owner/repo")

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = [
            {"id": 1, "number": 42, "title": "Bug: crash on startup", "body": "", "labels": []},
        ]

        with patch("owlmind.autonomous.httpx") as mock_httpx:
            mock_httpx.get.return_value = mock_resp
            sched._poll_github(sched._github_watchers[0])

        assert len(sched._queue) == 1
        assert "42" in sched._queue[0].goal
        assert "Bug: crash on startup" in sched._queue[0].goal

    def test_poll_github_skips_seen_issues(self) -> None:
        sched = AutonomousScheduler()
        sched.watch_github("owner/repo")

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = [
            {"id": 1, "number": 1, "title": "Old issue", "body": "", "labels": []},
        ]

        watcher = sched._github_watchers[0]
        watcher["seen_ids"].add(1)  # Already seen

        with patch("owlmind.autonomous.httpx") as mock_httpx:
            mock_httpx.get.return_value = mock_resp
            sched._poll_github(watcher)

        assert len(sched._queue) == 0

    def test_poll_github_handles_http_error(self) -> None:
        sched = AutonomousScheduler()
        sched.watch_github("owner/repo")

        with patch("owlmind.autonomous.httpx") as mock_httpx:
            mock_httpx.get.side_effect = Exception("network error")
            # Should not raise
            sched._poll_github(sched._github_watchers[0])

        assert len(sched._queue) == 0

    def test_poll_github_skips_non_matching_labels(self) -> None:
        sched = AutonomousScheduler()
        sched.watch_github("owner/repo", label="bug")

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = [
            {
                "id": 10,
                "number": 10,
                "title": "Feature request",
                "body": "",
                "labels": [{"name": "enhancement"}],
            },
        ]

        with patch("owlmind.autonomous.httpx") as mock_httpx:
            mock_httpx.get.return_value = mock_resp
            sched._poll_github(sched._github_watchers[0])

        assert len(sched._queue) == 0


# ---------------------------------------------------------------------------
# AutonomousScheduler — status
# ---------------------------------------------------------------------------


class TestStatus:
    def test_status_structure(self) -> None:
        sched = AutonomousScheduler()
        sched.add_goal("pending task")
        s = sched.status()
        assert s["queue_size"] == 1
        assert s["history_count"] == 0
        assert s["running"] is False
        assert isinstance(s["recent"], list)

    def test_status_after_run(self, tmp_path: Path) -> None:
        sched = AutonomousScheduler(workspace=str(tmp_path))
        sched.add_goal("done task")

        mock_state = MagicMock()
        mock_state.final_verdict = "APPROVED"

        with patch("owlmind.autonomous.GraphRunner") as MockRunner:
            MockRunner.return_value.run.return_value = mock_state
            sched.run_once()

        s = sched.status()
        assert s["queue_size"] == 0
        assert s["history_count"] == 1
        assert s["recent"][0]["verdict"] == "APPROVED"


# ---------------------------------------------------------------------------
# AutonomousScheduler — background thread
# ---------------------------------------------------------------------------


class TestBackgroundThread:
    def test_start_and_stop(self) -> None:
        sched = AutonomousScheduler()
        sched.start(interval=60)
        assert sched._thread is not None
        assert sched._thread.is_alive()
        sched.stop()
        assert not sched._thread.is_alive()

    def test_start_processes_goals_in_background(self, tmp_path: Path) -> None:
        sched = AutonomousScheduler(workspace=str(tmp_path))

        completed: list[RunRecord] = []
        sched._on_run_complete = lambda r: completed.append(r)

        mock_state = MagicMock()
        mock_state.final_verdict = "APPROVED"

        with patch("owlmind.autonomous.GraphRunner") as MockRunner:
            MockRunner.return_value.run.return_value = mock_state
            sched.add_goal("background task")
            sched.start(interval=60)
            # Wait briefly for the loop to execute
            deadline = time.monotonic() + 5
            while not completed and time.monotonic() < deadline:
                time.sleep(0.1)
            sched.stop()

        assert len(completed) >= 1
        assert completed[0].verdict == "APPROVED"
