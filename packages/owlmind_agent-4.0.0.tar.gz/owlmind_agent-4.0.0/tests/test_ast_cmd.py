"""Tests for owlmind.cli.ast_cmd."""
from __future__ import annotations

from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from owlmind.cli.ast_cmd import ast_app

runner = CliRunner()


def test_cmd_index_success() -> None:
    mock_rag = MagicMock()
    mock_stats = MagicMock()
    mock_stats.files_indexed = 42
    mock_stats.chunks_indexed = 150
    mock_stats.backend = "qdrant"
    mock_stats.duration_ms = 123
    mock_stats.error = ""
    mock_rag.index.return_value = mock_stats
    with patch("owlmind.cli.ast_cmd.CodeRAG", return_value=mock_rag):
        result = runner.invoke(ast_app, ["index", "--workspace", "."])
    assert result.exit_code == 0
    assert "42" in result.output
    assert "150" in result.output


def test_cmd_index_with_force() -> None:
    mock_rag = MagicMock()
    mock_stats = MagicMock()
    mock_stats.files_indexed = 10
    mock_stats.chunks_indexed = 50
    mock_stats.backend = "tfidf"
    mock_stats.duration_ms = 200
    mock_stats.error = ""
    mock_rag.index.return_value = mock_stats
    with patch("owlmind.cli.ast_cmd.CodeRAG", return_value=mock_rag):
        result = runner.invoke(ast_app, ["index", "--workspace", "/tmp", "--force"])
    assert result.exit_code == 0
    mock_rag.index.assert_called_once_with(force=True)


def test_cmd_index_with_qdrant_url() -> None:
    mock_rag = MagicMock()
    mock_stats = MagicMock()
    mock_stats.files_indexed = 5
    mock_stats.chunks_indexed = 20
    mock_stats.backend = "qdrant"
    mock_stats.duration_ms = 50
    mock_stats.error = ""
    mock_rag.index.return_value = mock_stats
    with patch("owlmind.cli.ast_cmd.CodeRAG", return_value=mock_rag) as mock_cls:
        result = runner.invoke(ast_app, ["index", "--qdrant-url", "http://myhost:6333"])
    assert result.exit_code == 0
    mock_cls.assert_called_once_with(workspace=".", qdrant_url="http://myhost:6333")


def test_cmd_index_error() -> None:
    mock_rag = MagicMock()
    mock_stats = MagicMock()
    mock_stats.error = "Connection refused"
    mock_rag.index.return_value = mock_stats
    with patch("owlmind.cli.ast_cmd.CodeRAG", return_value=mock_rag):
        result = runner.invoke(ast_app, ["index"])
    assert result.exit_code == 1
    assert "Connection refused" in result.output


def test_cmd_search_success() -> None:
    mock_rag = MagicMock()
    mock_hit = MagicMock()
    mock_hit.file = "src/main.py"
    mock_hit.line_start = 10
    mock_hit.line_end = 20
    mock_hit.symbol = "my_function"
    mock_hit.score = 0.95
    mock_hit.content = "def my_function():\n    pass"
    mock_rag.search.return_value = [mock_hit]
    with patch("owlmind.cli.ast_cmd.CodeRAG", return_value=mock_rag):
        result = runner.invoke(ast_app, ["search", "my_function"])
    assert result.exit_code == 0
    assert "src/main.py" in result.output
    mock_rag.search.assert_called_once_with("my_function", top_k=5)


def test_cmd_search_no_results() -> None:
    mock_rag = MagicMock()
    mock_rag.search.return_value = []
    with patch("owlmind.cli.ast_cmd.CodeRAG", return_value=mock_rag):
        result = runner.invoke(ast_app, ["search", "nonexistent"])
    assert result.exit_code == 0
    assert "No results" in result.output


def test_cmd_search_top_k() -> None:
    mock_rag = MagicMock()
    mock_rag.search.return_value = []
    with patch("owlmind.cli.ast_cmd.CodeRAG", return_value=mock_rag):
        result = runner.invoke(ast_app, ["search", "query", "--top-k", "10"])
    assert result.exit_code == 0
    mock_rag.search.assert_called_once_with("query", top_k=10)


def test_cmd_status() -> None:
    mock_rag = MagicMock()
    mock_rag.backend.return_value = "tfidf"
    mock_rag.is_available.return_value = True
    with patch("owlmind.cli.ast_cmd.CodeRAG", return_value=mock_rag):
        result = runner.invoke(ast_app, ["status"])
    assert result.exit_code == 0
    assert "tfidf" in result.output


def test_cmd_status_with_workspace() -> None:
    mock_rag = MagicMock()
    mock_rag.backend.return_value = "qdrant"
    mock_rag.is_available.return_value = True
    with patch("owlmind.cli.ast_cmd.CodeRAG", return_value=mock_rag) as mock_cls:
        result = runner.invoke(ast_app, ["status", "--workspace", "/some/path"])
    assert result.exit_code == 0
    mock_cls.assert_called_once_with(workspace="/some/path")
    assert "qdrant" in result.output
