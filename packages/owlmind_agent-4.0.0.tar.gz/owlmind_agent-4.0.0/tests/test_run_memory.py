"""Tests for RunMemory — run history persistence between sessions."""
from __future__ import annotations

import json
from pathlib import Path

from owlmind.graph.run_memory import RunMemory, RunRecord


def _make_record(n: int = 1, verdict: str = "APPROVED") -> RunRecord:
    return RunRecord(
        run_id=f"run{n:03d}",
        goal=f"Goal number {n}",
        verdict=verdict,
        workspace="/tmp/ws",
        summary=f"Summary for run {n}",
        timestamp=f"1700000000.{n}",
    )


# ---------------------------------------------------------------------------
# 1. Save and retrieve a single record
# ---------------------------------------------------------------------------

def test_save_and_retrieve(tmp_path: Path) -> None:
    mem = RunMemory(path=tmp_path / "mem.jsonl")
    rec = _make_record(1)
    mem.save(rec)

    results = mem.recent(5)
    assert len(results) == 1
    assert results[0].run_id == "run001"
    assert results[0].goal == "Goal number 1"
    assert results[0].verdict == "APPROVED"


# ---------------------------------------------------------------------------
# 2. recent() returns correct count (n records from the end)
# ---------------------------------------------------------------------------

def test_recent_returns_correct_count(tmp_path: Path) -> None:
    mem = RunMemory(path=tmp_path / "mem.jsonl")
    for i in range(1, 8):
        mem.save(_make_record(i))

    recent = mem.recent(3)
    assert len(recent) == 3
    # Should be the last 3 records
    assert [r.run_id for r in recent] == ["run005", "run006", "run007"]


# ---------------------------------------------------------------------------
# 3. context_for() returns a non-empty formatted string
# ---------------------------------------------------------------------------

def test_context_for_returns_formatted_string(tmp_path: Path) -> None:
    mem = RunMemory(path=tmp_path / "mem.jsonl")
    mem.save(_make_record(1, verdict="APPROVED"))
    mem.save(_make_record(2, verdict="REJECTED"))

    ctx = mem.context_for("some new goal", n=3)
    assert ctx.startswith("Previous runs (most recent first):")
    # Most recent first → run002 appears before run001
    lines = ctx.splitlines()
    assert any("[REJECTED]" in l for l in lines)
    assert any("[APPROVED]" in l for l in lines)
    idx_rejected = next(i for i, l in enumerate(lines) if "[REJECTED]" in l)
    idx_approved = next(i for i, l in enumerate(lines) if "[APPROVED]" in l)
    assert idx_rejected < idx_approved, "Most recent (REJECTED) should appear first"


# ---------------------------------------------------------------------------
# 4. Empty memory returns empty string from context_for()
# ---------------------------------------------------------------------------

def test_empty_memory_context_for(tmp_path: Path) -> None:
    mem = RunMemory(path=tmp_path / "empty.jsonl")
    assert mem.context_for("anything") == ""


# ---------------------------------------------------------------------------
# 5. Multiple saves append correctly (file grows line by line)
# ---------------------------------------------------------------------------

def test_multiple_saves_append(tmp_path: Path) -> None:
    path = tmp_path / "mem.jsonl"
    mem = RunMemory(path=path)

    for i in range(1, 6):
        mem.save(_make_record(i))

    lines = path.read_text().strip().splitlines()
    assert len(lines) == 5
    # Each line must be valid JSON with correct run_id
    for i, line in enumerate(lines, start=1):
        data = json.loads(line)
        assert data["run_id"] == f"run{i:03d}"


# ---------------------------------------------------------------------------
# 6. recent() on non-existent file returns empty list
# ---------------------------------------------------------------------------

def test_recent_missing_file(tmp_path: Path) -> None:
    mem = RunMemory(path=tmp_path / "nonexistent.jsonl")
    assert mem.recent() == []


# ---------------------------------------------------------------------------
# 7. context_for() respects the n parameter
# ---------------------------------------------------------------------------

def test_context_for_respects_n(tmp_path: Path) -> None:
    mem = RunMemory(path=tmp_path / "mem.jsonl")
    for i in range(1, 7):
        mem.save(_make_record(i))

    ctx = mem.context_for("goal", n=2)
    lines = ctx.splitlines()
    # Header + 2 entries = 3 lines
    assert len(lines) == 3
    assert "Goal number 6" in ctx
    assert "Goal number 5" in ctx
    assert "Goal number 4" not in ctx
