"""Tests for owlmind.channels.telegram — TelegramChannel and create_polling_app."""

from __future__ import annotations

import importlib
import sys
from types import ModuleType
from unittest.mock import AsyncMock, MagicMock

import pytest

from owlmind.config import TelegramConfig

# ── Setup: fake telegram modules ─────────────────────────────────────

_registered_handlers: dict[str, object] = {}


def _fake_command_handler(name: str, func: object) -> tuple[str, object]:
    _registered_handlers[name] = func
    return (name, func)


_fake_telegram = ModuleType("telegram")
_fake_telegram.Bot = MagicMock(name="Bot")  # type: ignore[attr-defined]
_fake_telegram.Update = MagicMock(name="Update")  # type: ignore[attr-defined]

_fake_ext = ModuleType("telegram.ext")
_mock_built_app = MagicMock()
_mock_builder = MagicMock()
_mock_builder.token.return_value = _mock_builder
_mock_builder.build.return_value = _mock_built_app
_AppClass = MagicMock()
_AppClass.builder.return_value = _mock_builder

_fake_ext.Application = _AppClass  # type: ignore[attr-defined]
_fake_ext.CommandHandler = _fake_command_handler  # type: ignore[attr-defined]
_fake_ext.ContextTypes = MagicMock(name="ContextTypes")  # type: ignore[attr-defined]
_fake_ext.ContextTypes.DEFAULT_TYPE = type  # type: ignore[attr-defined]

_orig_telegram = sys.modules.get("telegram")
_orig_telegram_ext = sys.modules.get("telegram.ext")
sys.modules["telegram"] = _fake_telegram  # type: ignore[assignment]
sys.modules["telegram.ext"] = _fake_ext  # type: ignore[assignment]

import owlmind.channels.telegram as _ct  # noqa: E402

importlib.reload(_ct)


# ── Helpers ──────────────────────────────────────────────────────────


def _make_update(chat_id: int = 100) -> MagicMock:
    update = MagicMock()
    update.message = MagicMock()
    update.message.chat_id = chat_id
    update.message.reply_text = AsyncMock()
    return update


def _make_context(args: list[str] | None = None) -> MagicMock:
    ctx = MagicMock()
    ctx.args = args or []
    return ctx


# ── TelegramChannel tests ───────────────────────────────────────────


class TestTelegramChannelDisabled:
    def test_not_enabled_when_no_token(self) -> None:
        config = TelegramConfig(bot_token="", allowed_chat_ids=[])
        channel = _ct.TelegramChannel(config)
        assert channel.enabled is False

    def test_chat_allowed_empty_list(self) -> None:
        config = TelegramConfig(bot_token="", allowed_chat_ids=[])
        channel = _ct.TelegramChannel(config)
        assert channel.is_chat_allowed(12345) is True

    def test_chat_allowed_in_list(self) -> None:
        config = TelegramConfig(bot_token="", allowed_chat_ids=[100, 200])
        channel = _ct.TelegramChannel(config)
        assert channel.is_chat_allowed(100) is True
        assert channel.is_chat_allowed(999) is False


class TestTelegramChannelEnabled:
    def _make_channel(self) -> _ct.TelegramChannel:
        channel = _ct.TelegramChannel(
            TelegramConfig(bot_token="tok", allowed_chat_ids=[100]),
        )
        # Force enabled by setting _bot
        channel._bot = AsyncMock()
        channel.config = TelegramConfig(bot_token="tok", allowed_chat_ids=[100])
        # Hack: override enabled check
        channel.config.__dict__["enabled"] = True
        return channel

    @pytest.mark.asyncio()
    async def test_send_message_disabled(self) -> None:
        config = TelegramConfig(bot_token="", allowed_chat_ids=[])
        channel = _ct.TelegramChannel(config)
        result = await channel.send_message(100, "hello")
        assert result is False

    @pytest.mark.asyncio()
    async def test_send_notification_no_default(self) -> None:
        config = TelegramConfig(bot_token="", allowed_chat_ids=[])
        channel = _ct.TelegramChannel(config)
        result = await channel.send_notification("hello")
        assert result is False

    def test_rate_limiting(self) -> None:
        config = TelegramConfig(bot_token="", allowed_chat_ids=[], rate_limit_seconds=5)
        channel = _ct.TelegramChannel(config)
        # First call always passes (no previous send recorded)
        assert channel._rate_limited(100) is False
        # Immediate second call within rate_limit_seconds should be limited
        assert channel._rate_limited(100) is True

    def test_event_subscriber_not_enabled(self) -> None:
        config = TelegramConfig(bot_token="", allowed_chat_ids=[])
        channel = _ct.TelegramChannel(config)
        sub = channel.make_event_subscriber()
        # Should not raise when called
        sub("cycle_start", {"run_id": "r1"})

    def test_is_available(self) -> None:
        assert _ct.is_telegram_available() is True


# ── create_polling_app tests ─────────────────────────────────────────


class TestCreatePollingApp:
    def test_returns_none_when_disabled(self) -> None:
        config = TelegramConfig(bot_token="", allowed_chat_ids=[])
        result = _ct.create_polling_app(config)
        assert result is None

    def test_creates_app_when_enabled(self) -> None:
        config = TelegramConfig(bot_token="tok", allowed_chat_ids=[])
        config.__dict__["enabled"] = True
        _registered_handlers.clear()
        result = _ct.create_polling_app(config)
        assert result is not None
        expected_cmds = {"status", "approve", "deny", "next", "export"}
        assert set(_registered_handlers.keys()) == expected_cmds


class TestPollingAppHandlers:
    @pytest.fixture()
    def handlers(self) -> dict[str, object]:
        _registered_handlers.clear()
        config = TelegramConfig(bot_token="tok", allowed_chat_ids=[100])
        config.__dict__["enabled"] = True
        cm = MagicMock()
        _ct.create_polling_app(config, cycle_manager=cm)
        return dict(_registered_handlers)

    @pytest.mark.asyncio()
    async def test_status_no_args(self, handlers: dict[str, object]) -> None:
        update = _make_update()
        ctx = _make_context([])
        await handlers["status"](update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "Usage" in text

    @pytest.mark.asyncio()
    async def test_status_unauthorized(self, handlers: dict[str, object]) -> None:
        update = _make_update(chat_id=999)
        ctx = _make_context(["r-1"])
        await handlers["status"](update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "Unauthorized" in text

    @pytest.mark.asyncio()
    async def test_approve_no_args(self, handlers: dict[str, object]) -> None:
        update = _make_update()
        ctx = _make_context(["only-one"])
        await handlers["approve"](update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "Usage" in text

    @pytest.mark.asyncio()
    async def test_deny_no_args(self, handlers: dict[str, object]) -> None:
        update = _make_update()
        ctx = _make_context(["only-one"])
        await handlers["deny"](update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "Usage" in text

    @pytest.mark.asyncio()
    async def test_next_no_args(self, handlers: dict[str, object]) -> None:
        update = _make_update()
        ctx = _make_context([])
        await handlers["next"](update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "Usage" in text

    @pytest.mark.asyncio()
    async def test_export_no_args(self, handlers: dict[str, object]) -> None:
        update = _make_update()
        ctx = _make_context([])
        await handlers["export"](update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "Usage" in text

    @pytest.mark.asyncio()
    async def test_no_message(self, handlers: dict[str, object]) -> None:
        for cmd in ["status", "approve", "deny", "next", "export"]:
            update = MagicMock()
            update.message = None
            ctx = _make_context()
            await handlers[cmd](update, ctx)

    @pytest.mark.asyncio()
    async def test_no_cycle_manager(self) -> None:
        _registered_handlers.clear()
        config = TelegramConfig(bot_token="tok", allowed_chat_ids=[100])
        config.__dict__["enabled"] = True
        _ct.create_polling_app(config, cycle_manager=None)
        for cmd in ["status", "approve", "deny", "next", "export"]:
            update = _make_update()
            ctx = _make_context(["r-1", "tok-1"])
            await _registered_handlers[cmd](update, ctx)
            text = update.message.reply_text.call_args[0][0]
            assert "not configured" in text or "Usage" in text


# ── Deep handler paths (with cycle_manager) ──────────────────────────


class TestHandlerDeepPaths:
    """Test handler success/error paths with a real cycle_manager mock."""

    @pytest.fixture()
    def cm_and_handlers(self) -> tuple[MagicMock, dict[str, object]]:
        _registered_handlers.clear()
        config = TelegramConfig(bot_token="tok", allowed_chat_ids=[100])
        config.__dict__["enabled"] = True
        cm = MagicMock()
        _ct.create_polling_app(config, cycle_manager=cm)
        return cm, dict(_registered_handlers)

    @pytest.mark.asyncio()
    async def test_status_success(self, cm_and_handlers: tuple[MagicMock, dict]) -> None:
        cm, handlers = cm_and_handlers
        meta = MagicMock()
        meta.run_id = "r-1"
        meta.state.value = "PLANNING"
        meta.iteration = 2
        meta.limits.max_iterations = 5
        meta.goal = "Fix bug"
        cm.status.return_value = meta
        update = _make_update()
        ctx = _make_context(["r-1"])
        await handlers["status"](update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "r-1" in text
        assert "PLANNING" in text
        assert "Fix bug" in text

    @pytest.mark.asyncio()
    async def test_status_error(self, cm_and_handlers: tuple[MagicMock, dict]) -> None:
        cm, handlers = cm_and_handlers
        cm.status.side_effect = RuntimeError("not found")
        update = _make_update()
        ctx = _make_context(["r-1"])
        await handlers["status"](update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "Error" in text

    @pytest.mark.asyncio()
    async def test_approve_success(self, cm_and_handlers: tuple[MagicMock, dict]) -> None:
        cm, handlers = cm_and_handlers
        from unittest.mock import patch

        with patch("owlmind.approval.resolve_approval", return_value=(True, "Approved!")):
            update = _make_update()
            ctx = _make_context(["r-1", "tok-1"])
            await handlers["approve"](update, ctx)
            text = update.message.reply_text.call_args[0][0]
            assert "Approved!" in text

    @pytest.mark.asyncio()
    async def test_approve_failed(self, cm_and_handlers: tuple[MagicMock, dict]) -> None:
        cm, handlers = cm_and_handlers
        from unittest.mock import patch

        with patch("owlmind.approval.resolve_approval", return_value=(False, "Invalid token")):
            update = _make_update()
            ctx = _make_context(["r-1", "tok-1"])
            await handlers["approve"](update, ctx)
            text = update.message.reply_text.call_args[0][0]
            assert "Failed" in text

    @pytest.mark.asyncio()
    async def test_approve_exception(self, cm_and_handlers: tuple[MagicMock, dict]) -> None:
        cm, handlers = cm_and_handlers
        from unittest.mock import patch

        with patch("owlmind.approval.resolve_approval", side_effect=RuntimeError("boom")):
            update = _make_update()
            ctx = _make_context(["r-1", "tok-1"])
            await handlers["approve"](update, ctx)
            text = update.message.reply_text.call_args[0][0]
            assert "Error" in text

    @pytest.mark.asyncio()
    async def test_deny_success(self, cm_and_handlers: tuple[MagicMock, dict]) -> None:
        cm, handlers = cm_and_handlers
        from unittest.mock import patch

        with patch("owlmind.approval.resolve_approval", return_value=(True, "Denied!")):
            update = _make_update()
            ctx = _make_context(["r-1", "tok-1"])
            await handlers["deny"](update, ctx)
            text = update.message.reply_text.call_args[0][0]
            assert "Denied!" in text

    @pytest.mark.asyncio()
    async def test_deny_exception(self, cm_and_handlers: tuple[MagicMock, dict]) -> None:
        cm, handlers = cm_and_handlers
        from unittest.mock import patch

        with patch("owlmind.approval.resolve_approval", side_effect=ValueError("bad")):
            update = _make_update()
            ctx = _make_context(["r-1", "tok-1"])
            await handlers["deny"](update, ctx)
            text = update.message.reply_text.call_args[0][0]
            assert "Error" in text

    @pytest.mark.asyncio()
    async def test_next_success(self, cm_and_handlers: tuple[MagicMock, dict]) -> None:
        cm, handlers = cm_and_handlers
        meta = MagicMock()
        meta.state.value = "WORKING"
        cm.next.return_value = (meta, "Advanced to next step")
        update = _make_update()
        ctx = _make_context(["r-1"])
        await handlers["next"](update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "WORKING" in text

    @pytest.mark.asyncio()
    async def test_next_error(self, cm_and_handlers: tuple[MagicMock, dict]) -> None:
        cm, handlers = cm_and_handlers
        cm.next.side_effect = RuntimeError("no such run")
        update = _make_update()
        ctx = _make_context(["r-1"])
        await handlers["next"](update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "Error" in text

    @pytest.mark.asyncio()
    async def test_export_success(self, cm_and_handlers: tuple[MagicMock, dict]) -> None:
        cm, handlers = cm_and_handlers
        from pathlib import Path

        mock_path = MagicMock(spec=Path)
        mock_path.__str__ = lambda self: "/tmp/export.zip"
        mock_path.stat.return_value.st_size = 1234
        cm.export.return_value = mock_path
        update = _make_update()
        ctx = _make_context(["r-1"])
        await handlers["export"](update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "1234" in text

    @pytest.mark.asyncio()
    async def test_export_error(self, cm_and_handlers: tuple[MagicMock, dict]) -> None:
        cm, handlers = cm_and_handlers
        cm.export.side_effect = FileNotFoundError("no run dir")
        update = _make_update()
        ctx = _make_context(["r-1"])
        await handlers["export"](update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "Error" in text


# ── TelegramChannel send_message deep paths ──────────────────────────


class TestSendMessagePaths:
    def _make_enabled_channel(self) -> _ct.TelegramChannel:
        channel = _ct.TelegramChannel(
            TelegramConfig(bot_token="tok", allowed_chat_ids=[100], default_chat_id=100),
        )
        channel._bot = AsyncMock()
        return channel

    @pytest.mark.asyncio()
    async def test_send_message_not_allowed(self) -> None:
        channel = self._make_enabled_channel()
        result = await channel.send_message(999, "test")
        assert result is False

    @pytest.mark.asyncio()
    async def test_send_message_rate_limited(self) -> None:
        channel = self._make_enabled_channel()
        channel.config = TelegramConfig(
            bot_token="tok",
            allowed_chat_ids=[100],
            rate_limit_seconds=999,
        )
        await channel.send_message(100, "first")
        result = await channel.send_message(100, "second")
        assert result is False

    @pytest.mark.asyncio()
    async def test_send_message_success(self) -> None:
        channel = self._make_enabled_channel()
        result = await channel.send_message(100, "hello")
        assert result is True
        channel._bot.send_message.assert_awaited_once()

    @pytest.mark.asyncio()
    async def test_send_message_exception(self) -> None:
        channel = self._make_enabled_channel()
        channel._bot.send_message.side_effect = RuntimeError("network error")
        result = await channel.send_message(100, "hello")
        assert result is False

    @pytest.mark.asyncio()
    async def test_send_notification_with_default(self) -> None:
        channel = self._make_enabled_channel()
        result = await channel.send_notification("test notification")
        assert result is True


# ── Event subscriber paths ───────────────────────────────────────────


class TestEventSubscriberPaths:
    def _make_enabled_channel(self) -> _ct.TelegramChannel:
        channel = _ct.TelegramChannel(
            TelegramConfig(bot_token="tok", allowed_chat_ids=[], default_chat_id=100),
        )
        channel._bot = AsyncMock()
        return channel

    def test_subscriber_ignores_non_notifiable(self) -> None:
        channel = self._make_enabled_channel()
        sub = channel.make_event_subscriber()
        sub("unknown_event", {"run_id": "r1"})

    def test_subscriber_cycle_start(self) -> None:
        channel = self._make_enabled_channel()
        sub = channel.make_event_subscriber()
        sub("cycle_start", {"run_id": "r1", "goal": "test"})

    def test_subscriber_hard_fail(self) -> None:
        channel = self._make_enabled_channel()
        sub = channel.make_event_subscriber()
        sub("hard_fail", {"run_id": "r1", "reasons": ["leak"]})

    def test_subscriber_approval_created(self) -> None:
        channel = self._make_enabled_channel()
        sub = channel.make_event_subscriber()
        sub("APPROVAL_CREATED", {"run_id": "r1", "token": "tok-1"})


# ── Cleanup ──────────────────────────────────────────────────────────


def teardown_module() -> None:
    if _orig_telegram is not None:
        sys.modules["telegram"] = _orig_telegram
    else:
        sys.modules.pop("telegram", None)
    if _orig_telegram_ext is not None:
        sys.modules["telegram.ext"] = _orig_telegram_ext
    else:
        sys.modules.pop("telegram.ext", None)
    importlib.reload(_ct)
