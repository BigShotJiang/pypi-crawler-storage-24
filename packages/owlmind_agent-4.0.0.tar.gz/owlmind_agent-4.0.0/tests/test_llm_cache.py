"""Tests for LLM response cache."""

from __future__ import annotations

import time
from pathlib import Path

import pytest


@pytest.fixture
def cache_dir(tmp_path: Path) -> Path:
    d = tmp_path / "llm_cache"
    d.mkdir()
    return d


class TestLLMCache:
    def test_put_and_get(self, cache_dir: Path) -> None:
        from owlmind.llm.cache import LLMCache

        cache = LLMCache(cache_dir)
        key = cache.make_key({"model": "gpt-4o", "prompt": "hello"}, {"type": "object"})

        assert cache.get(key) is None

        response = {"result": "world"}
        meta = {"provider": "openai", "tokens": 10}
        cache.put(key, response, meta)

        result = cache.get(key)
        assert result is not None
        resp, m = result
        assert resp["result"] == "world"
        assert m["provider"] == "openai"

    def test_make_key_deterministic(self, cache_dir: Path) -> None:
        from owlmind.llm.cache import LLMCache

        cache = LLMCache(cache_dir)
        k1 = cache.make_key({"a": 1, "b": 2}, {"type": "object"})
        k2 = cache.make_key({"b": 2, "a": 1}, {"type": "object"})
        assert k1 == k2  # canonical JSON = same key regardless of order

    def test_ttl_expiration(self, cache_dir: Path) -> None:
        from owlmind.llm.cache import LLMCache

        cache = LLMCache(cache_dir, ttl_seconds=1)
        key = cache.make_key({"prompt": "test"}, {})
        cache.put(key, {"r": 1}, {"m": 1})

        assert cache.get(key) is not None
        time.sleep(1.1)
        assert cache.get(key) is None

    def test_evict_expired(self, cache_dir: Path) -> None:
        from owlmind.llm.cache import LLMCache

        cache = LLMCache(cache_dir, ttl_seconds=1)
        for i in range(5):
            key = cache.make_key({"i": i}, {})
            cache.put(key, {"r": i}, {})

        time.sleep(1.1)
        evicted = cache.evict_expired()
        assert evicted == 5

    def test_stats(self, cache_dir: Path) -> None:
        from owlmind.llm.cache import LLMCache

        cache = LLMCache(cache_dir)
        key = cache.make_key({"prompt": "test"}, {})
        cache.put(key, {"r": 1}, {})

        cache.get(key)  # hit
        cache.get("nonexistent")  # miss

        stats = cache.stats()
        assert stats["hits"] >= 1
        assert stats["misses"] >= 1
