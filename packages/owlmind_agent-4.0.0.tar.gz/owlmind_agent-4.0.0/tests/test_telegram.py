"""Tests for Telegram channel — pure functions and whitelist parsing."""

from __future__ import annotations

from owlmind.channels.telegram import TelegramChannel, is_telegram_available
from owlmind.config import TelegramConfig


class TestTelegramChannel:
    def test_disabled_without_token(self) -> None:
        config = TelegramConfig()
        channel = TelegramChannel(config)
        assert channel.enabled is False

    def test_chat_allowed_empty_list(self) -> None:
        config = TelegramConfig(bot_token="test", allowed_chat_ids=[])
        channel = TelegramChannel(config)
        # Empty list means all allowed
        assert channel.is_chat_allowed(12345) is True

    def test_chat_allowed_whitelist(self) -> None:
        config = TelegramConfig(bot_token="test", allowed_chat_ids=[111, 222])
        channel = TelegramChannel(config)
        assert channel.is_chat_allowed(111) is True
        assert channel.is_chat_allowed(222) is True
        assert channel.is_chat_allowed(333) is False

    def test_rate_limiting(self) -> None:
        config = TelegramConfig(bot_token="test", rate_limit_seconds=1.0)
        channel = TelegramChannel(config)

        # First call should not be rate limited
        assert channel._rate_limited(111) is False
        # Immediately after, should be rate limited
        assert channel._rate_limited(111) is True

    def test_rate_limiting_different_chats(self) -> None:
        config = TelegramConfig(bot_token="test", rate_limit_seconds=1.0)
        channel = TelegramChannel(config)

        assert channel._rate_limited(111) is False
        assert channel._rate_limited(222) is False

    def test_is_telegram_available(self) -> None:
        # Just check it returns a bool (may or may not have PTB installed)
        result = is_telegram_available()
        assert isinstance(result, bool)
