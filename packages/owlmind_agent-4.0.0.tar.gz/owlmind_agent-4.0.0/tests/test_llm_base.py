"""Tests for owlmind.llm.base — LLM driver protocol."""

from __future__ import annotations

from typing import Any

from owlmind.llm.base import LLMDriver


class StubLLMDriver:
    """Concrete stub implementing the LLMDriver protocol."""

    @property
    def name(self) -> str:
        return "stub"

    @property
    def supports_structured(self) -> bool:
        return True

    def plan(
        self,
        planner_request: dict[str, Any],
        schema: dict[str, Any],
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        return {"plan": "test"}, {"model": "stub"}

    def judge(
        self,
        judge_request: dict[str, Any],
        schema: dict[str, Any],
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        return {"verdict": "APPROVED"}, {"model": "stub"}


class IncompleteDriver:
    """Does NOT implement the full protocol."""

    @property
    def name(self) -> str:
        return "incomplete"


class TestLLMDriverProtocol:
    def test_stub_is_llm_driver(self) -> None:
        assert isinstance(StubLLMDriver(), LLMDriver)

    def test_incomplete_is_not_llm_driver(self) -> None:
        assert not isinstance(IncompleteDriver(), LLMDriver)

    def test_stub_name(self) -> None:
        assert StubLLMDriver().name == "stub"

    def test_stub_supports_structured(self) -> None:
        assert StubLLMDriver().supports_structured is True

    def test_plan_returns_tuple(self) -> None:
        driver = StubLLMDriver()
        result = driver.plan({"goal": "test"}, {})
        assert isinstance(result, tuple)
        assert len(result) == 2

    def test_judge_returns_tuple(self) -> None:
        driver = StubLLMDriver()
        result = driver.judge({"evidence": "test"}, {})
        assert isinstance(result, tuple)
        assert result[0]["verdict"] == "APPROVED"

    def test_protocol_is_runtime_checkable(self) -> None:
        assert (
            hasattr(LLMDriver, "__protocol_attrs__")
            or hasattr(LLMDriver, "__abstractmethods__")
            or isinstance(StubLLMDriver(), LLMDriver)
        )
