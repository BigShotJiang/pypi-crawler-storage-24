"""Tests for self_improve module."""

from __future__ import annotations

import json
from pathlib import Path

from owlmind.self_improve import (
    ImprovementInsight,
    RunSummary,
    analyze_runs,
    format_insights_markdown,
    load_recent_runs,
    save_insights_to_memory,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_run_dir(
    tmp_path: Path,
    run_id: str,
    state: str = "DONE",
    goal: str = "test goal",
    stop_reason: str = "judge_done",
    iteration: int = 3,
    workspace: str = "/tmp/ws",
    created_at: str = "2026-02-21T10:00:00+00:00",
) -> Path:
    """Create a minimal run directory with cycle_meta.json."""
    run_dir = tmp_path / run_id
    run_dir.mkdir()
    meta = {
        "run_id": run_id,
        "goal": goal,
        "state": state,
        "stop_reason": stop_reason,
        "workspace": workspace,
        "created_at": created_at,
        "finished_at": "2026-02-21T10:05:00+00:00",
        "iteration": iteration,
        "step": 10,
    }
    (run_dir / "cycle_meta.json").write_text(json.dumps(meta))
    return run_dir


def _make_run_summary(
    state: str = "DONE",
    goal: str = "test goal",
    stop_reason: str = "judge_done",
    workspace: str = "/tmp/ws",
    iterations: int = 3,
    run_id: str = "run-001",
) -> RunSummary:
    """Create a RunSummary directly for testing analyze_runs."""
    return RunSummary(
        run_id=run_id,
        goal=goal,
        workspace=workspace,
        state=state,
        stop_reason=stop_reason,
        iterations=iterations,
        steps=10,
        created_at="2026-02-21T10:00:00+00:00",
    )


# ===========================================================================
# TestLoadRecentRuns
# ===========================================================================


class TestLoadRecentRuns:
    def test_empty_dir_returns_empty_list(self, tmp_path: Path) -> None:
        runs = load_recent_runs(tmp_path, days=7)
        assert runs == []

    def test_loads_done_runs(self, tmp_path: Path) -> None:
        _make_run_dir(tmp_path, "run-001", "DONE")
        _make_run_dir(tmp_path, "run-002", "DONE")
        runs = load_recent_runs(tmp_path, days=7)
        assert len(runs) == 2

    def test_loads_failed_runs(self, tmp_path: Path) -> None:
        _make_run_dir(tmp_path, "run-001", "FAILED")
        runs = load_recent_runs(tmp_path, days=7)
        assert len(runs) == 1
        assert runs[0].state == "FAILED"

    def test_loads_blocked_runs(self, tmp_path: Path) -> None:
        _make_run_dir(tmp_path, "run-001", "BLOCKED")
        runs = load_recent_runs(tmp_path, days=7)
        assert len(runs) == 1
        assert runs[0].state == "BLOCKED"

    def test_loads_hard_fail_runs(self, tmp_path: Path) -> None:
        _make_run_dir(tmp_path, "run-001", "HARD_FAIL")
        runs = load_recent_runs(tmp_path, days=7)
        assert len(runs) == 1
        assert runs[0].state == "HARD_FAIL"

    def test_skips_running_state(self, tmp_path: Path) -> None:
        _make_run_dir(tmp_path, "run-001", "RUNNING")
        runs = load_recent_runs(tmp_path, days=7)
        assert runs == []

    def test_missing_meta_file_skipped(self, tmp_path: Path) -> None:
        (tmp_path / "empty-run").mkdir()
        runs = load_recent_runs(tmp_path, days=7)
        assert runs == []

    def test_returns_run_summary_objects(self, tmp_path: Path) -> None:
        _make_run_dir(tmp_path, "run-001", "DONE", goal="my goal")
        runs = load_recent_runs(tmp_path, days=7)
        assert len(runs) == 1
        r = runs[0]
        assert isinstance(r, RunSummary)
        assert r.run_id == "run-001"
        assert r.goal == "my goal"
        assert r.workspace == "/tmp/ws"

    def test_invalid_json_skipped(self, tmp_path: Path) -> None:
        run_dir = tmp_path / "bad-run"
        run_dir.mkdir()
        (run_dir / "cycle_meta.json").write_text("{invalid!}")
        runs = load_recent_runs(tmp_path, days=7)
        assert runs == []

    def test_non_dir_entries_skipped(self, tmp_path: Path) -> None:
        (tmp_path / "stray_file.txt").write_text("not a run")
        _make_run_dir(tmp_path, "run-001", "DONE")
        runs = load_recent_runs(tmp_path, days=7)
        assert len(runs) == 1

    def test_loads_events_from_jsonl(self, tmp_path: Path) -> None:
        run_dir = _make_run_dir(tmp_path, "run-001", "DONE")
        events_file = run_dir / "events.jsonl"
        events_file.write_text(
            json.dumps({"type": "step", "n": 1})
            + "\n"
            + json.dumps({"type": "step", "n": 2})
            + "\n"
        )
        runs = load_recent_runs(tmp_path, days=7)
        assert len(runs) == 1
        assert len(runs[0].events) == 2

    def test_sorted_by_created_at_descending(self, tmp_path: Path) -> None:
        _make_run_dir(tmp_path, "run-old", "DONE", created_at="2026-01-01T00:00:00+00:00")
        _make_run_dir(tmp_path, "run-new", "DONE", created_at="2026-02-01T00:00:00+00:00")
        runs = load_recent_runs(tmp_path, days=365)
        assert runs[0].run_id == "run-new"
        assert runs[1].run_id == "run-old"


# ===========================================================================
# TestAnalyzeRuns
# ===========================================================================


class TestAnalyzeRuns:
    def test_empty_returns_empty_list(self) -> None:
        assert analyze_runs([]) == []

    def test_returns_list_of_improvement_insights(self) -> None:
        runs = [_make_run_summary("DONE")]
        insights = analyze_runs(runs)
        assert isinstance(insights, list)
        assert all(isinstance(i, ImprovementInsight) for i in insights)

    def test_stats_insight_always_present(self) -> None:
        runs = [_make_run_summary("DONE")]
        insights = analyze_runs(runs)
        categories = [i.category for i in insights]
        assert "stats" in categories

    def test_all_done_success_rate_100_percent(self) -> None:
        runs = [_make_run_summary("DONE", run_id=f"r{i}") for i in range(5)]
        insights = analyze_runs(runs)
        stats = next(i for i in insights if i.category == "stats")
        assert "100%" in stats.description

    def test_mixed_states_stats_description(self) -> None:
        runs = [
            _make_run_summary("DONE", run_id="r1"),
            _make_run_summary("FAILED", run_id="r2"),
            _make_run_summary("BLOCKED", run_id="r3"),
        ]
        insights = analyze_runs(runs)
        stats = next(i for i in insights if i.category == "stats")
        assert "33%" in stats.description

    def test_failure_pattern_insight_when_failures_exist(self) -> None:
        runs = [
            _make_run_summary("DONE", run_id="r1"),
            _make_run_summary("FAILED", stop_reason="timeout", run_id="r2"),
            _make_run_summary("FAILED", stop_reason="timeout", run_id="r3"),
        ]
        insights = analyze_runs(runs)
        categories = [i.category for i in insights]
        assert "failure_pattern" in categories

    def test_no_failure_insight_when_all_done(self) -> None:
        runs = [_make_run_summary("DONE", run_id=f"r{i}") for i in range(3)]
        insights = analyze_runs(runs)
        categories = [i.category for i in insights]
        assert "failure_pattern" not in categories

    def test_performance_insight_for_slow_runs(self) -> None:
        runs = [
            _make_run_summary("DONE", iterations=2, run_id="r1"),
            _make_run_summary("DONE", iterations=2, run_id="r2"),
            _make_run_summary("DONE", iterations=20, run_id="r3"),
        ]
        insights = analyze_runs(runs)
        categories = [i.category for i in insights]
        assert "performance" in categories

    def test_workspace_hint_when_mostly_failures_in_workspace(self) -> None:
        ws = "/tmp/problematic_project"
        runs = [
            _make_run_summary("FAILED", workspace=ws, run_id="r1"),
            _make_run_summary("FAILED", workspace=ws, run_id="r2"),
            _make_run_summary("FAILED", workspace=ws, run_id="r3"),
        ]
        insights = analyze_runs(runs)
        categories = [i.category for i in insights]
        assert "workspace_hint" in categories

    def test_stats_examples_contain_goals(self) -> None:
        runs = [_make_run_summary("DONE", goal="fix the bug")]
        insights = analyze_runs(runs)
        stats = next(i for i in insights if i.category == "stats")
        assert "fix the bug" in stats.examples


# ===========================================================================
# TestFormatInsightsMarkdown
# ===========================================================================


class TestFormatInsightsMarkdown:
    def test_empty_insights_returns_no_data_message(self) -> None:
        md = format_insights_markdown([], days=7)
        assert isinstance(md, str)
        assert len(md) > 0

    def test_returns_string(self) -> None:
        runs = [_make_run_summary("DONE")]
        insights = analyze_runs(runs)
        md = format_insights_markdown(insights, days=7)
        assert isinstance(md, str)

    def test_contains_days_count(self) -> None:
        runs = [_make_run_summary("DONE")]
        insights = analyze_runs(runs)
        md = format_insights_markdown(insights, days=14)
        assert "14" in md

    def test_contains_owlmind_branding(self) -> None:
        runs = [_make_run_summary("DONE")]
        insights = analyze_runs(runs)
        md = format_insights_markdown(insights, days=7)
        assert "OWLMIND" in md

    def test_failure_stop_reason_present_when_failures(self) -> None:
        runs = [
            _make_run_summary("DONE", run_id="r1"),
            _make_run_summary("FAILED", stop_reason="api_error", run_id="r2"),
        ]
        insights = analyze_runs(runs)
        md = format_insights_markdown(insights, days=7)
        assert "api_error" in md

    def test_default_days_is_7(self) -> None:
        insights = [ImprovementInsight(category="stats", description="hi")]
        md = format_insights_markdown(insights)
        assert "7" in md


# ===========================================================================
# TestSaveInsightsToMemory
# ===========================================================================


class TestSaveInsightsToMemory:
    def test_creates_file_when_missing(self, tmp_path: Path) -> None:
        insights = [ImprovementInsight(category="stats", description="test")]
        memory_file = tmp_path / "memory.json"
        save_insights_to_memory(insights, memory_file)
        assert memory_file.exists()

    def test_file_contains_valid_json_list(self, tmp_path: Path) -> None:
        insights = [ImprovementInsight(category="stats", description="test")]
        memory_file = tmp_path / "memory.json"
        save_insights_to_memory(insights, memory_file)
        data = json.loads(memory_file.read_text())
        assert isinstance(data, list)
        assert len(data) == 1

    def test_saved_entry_has_required_fields(self, tmp_path: Path) -> None:
        insights = [ImprovementInsight(category="stats", description="some insight", frequency=3)]
        memory_file = tmp_path / "memory.json"
        save_insights_to_memory(insights, memory_file)
        data = json.loads(memory_file.read_text())
        entry = data[0]
        assert "timestamp" in entry
        assert entry["category"] == "stats"
        assert entry["description"] == "some insight"
        assert entry["frequency"] == 3

    def test_appends_on_multiple_calls(self, tmp_path: Path) -> None:
        insights = [ImprovementInsight(category="stats", description="first")]
        memory_file = tmp_path / "memory.json"
        save_insights_to_memory(insights, memory_file)
        save_insights_to_memory(insights, memory_file)
        data = json.loads(memory_file.read_text())
        assert len(data) == 2

    def test_multiple_insights_all_saved(self, tmp_path: Path) -> None:
        insights = [
            ImprovementInsight(category="stats", description="stat insight"),
            ImprovementInsight(category="failure_pattern", description="fail insight"),
        ]
        memory_file = tmp_path / "memory.json"
        save_insights_to_memory(insights, memory_file)
        data = json.loads(memory_file.read_text())
        assert len(data) == 2

    def test_empty_insights_saves_empty_list(self, tmp_path: Path) -> None:
        memory_file = tmp_path / "memory.json"
        save_insights_to_memory([], memory_file)
        data = json.loads(memory_file.read_text())
        assert data == []

    def test_overwrites_corrupt_existing_file(self, tmp_path: Path) -> None:
        memory_file = tmp_path / "memory.json"
        memory_file.write_text("{bad json!!!")
        insights = [ImprovementInsight(category="stats", description="ok")]
        save_insights_to_memory(insights, memory_file)
        data = json.loads(memory_file.read_text())
        assert len(data) == 1

    def test_caps_at_200_entries(self, tmp_path: Path) -> None:
        memory_file = tmp_path / "memory.json"
        existing = [
            {"timestamp": "x", "category": "stats", "description": f"e{i}", "frequency": 1}
            for i in range(199)
        ]
        memory_file.write_text(json.dumps(existing))
        insights = [ImprovementInsight(category="stats", description=f"new-{i}") for i in range(5)]
        save_insights_to_memory(insights, memory_file)
        data = json.loads(memory_file.read_text())
        assert len(data) == 200
