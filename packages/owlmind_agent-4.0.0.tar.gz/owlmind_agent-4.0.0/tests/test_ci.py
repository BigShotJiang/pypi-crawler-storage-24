"""Tests for CI operations — unit tests with mocked gh CLI."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
import yaml

from owlmind.ci import (
    WorkflowRun,
    failed_jobs,
    generate_fix_goals,
    list_runs,
    run_logs,
    run_status,
)
from owlmind.github import configure_gh


class TestListRuns:
    def test_success(self) -> None:
        runs_data = [
            {
                "databaseId": 1,
                "name": "CI",
                "status": "completed",
                "conclusion": "success",
                "headBranch": "main",
                "url": "https://example.com",
                "event": "push",
                "createdAt": "2025-01-01T00:00:00Z",
            },
        ]
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = json.dumps(runs_data)

        with patch("owlmind.ci.subprocess.run", return_value=mock_result):
            runs = list_runs("/workspace")

        assert len(runs) == 1
        assert isinstance(runs[0], WorkflowRun)
        assert runs[0].name == "CI"
        assert runs[0].conclusion == "success"

    def test_with_branch(self) -> None:
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "[]"

        with patch("owlmind.ci.subprocess.run", return_value=mock_result) as mock_run:
            list_runs("/workspace", branch="feature")
            args = mock_run.call_args[0][0]
            assert "--branch" in args
            assert "feature" in args

    def test_failure_returns_empty(self) -> None:
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stderr = "error"

        with patch("owlmind.ci.subprocess.run", return_value=mock_result):
            runs = list_runs("/workspace")

        assert runs == []


class TestRunStatus:
    def test_success(self) -> None:
        data = {
            "databaseId": 123,
            "name": "CI",
            "status": "completed",
            "conclusion": "failure",
            "jobs": [
                {"name": "test", "conclusion": "failure"},
            ],
        }
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = json.dumps(data)

        with patch("owlmind.ci.subprocess.run", return_value=mock_result):
            result = run_status("/workspace", 123)

        assert result["conclusion"] == "failure"
        assert len(result["jobs"]) == 1

    def test_failure_raises(self) -> None:
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stderr = "not found"

        with (
            patch("owlmind.ci.subprocess.run", return_value=mock_result),
            pytest.raises(RuntimeError, match="not found"),
        ):
            run_status("/workspace", 999)


class TestRunLogs:
    def test_success(self) -> None:
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "line1\nline2\nERROR: test failed\n"

        with patch("owlmind.ci.subprocess.run", return_value=mock_result):
            logs = run_logs("/workspace", 123)

        assert "ERROR" in logs
        assert "line1" in logs

    def test_failure_raises(self) -> None:
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stderr = "error"

        with (
            patch("owlmind.ci.subprocess.run", return_value=mock_result),
            pytest.raises(RuntimeError),
        ):
            run_logs("/workspace", 999)


class TestFailedJobs:
    def test_extracts_failed_jobs(self) -> None:
        data = {
            "jobs": [
                {
                    "databaseId": 1,
                    "name": "lint",
                    "status": "completed",
                    "conclusion": "success",
                    "steps": [],
                },
                {
                    "databaseId": 2,
                    "name": "test",
                    "status": "completed",
                    "conclusion": "failure",
                    "steps": [
                        {"name": "Run pytest", "conclusion": "failure"},
                        {"name": "Setup", "conclusion": "success"},
                    ],
                },
            ],
        }
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = json.dumps(data)

        with patch("owlmind.ci.subprocess.run", return_value=mock_result):
            jobs = failed_jobs("/workspace", 123)

        assert len(jobs) == 1
        assert jobs[0].name == "test"
        assert len(jobs[0].steps) == 2

    def test_no_failed_jobs(self) -> None:
        data = {
            "jobs": [
                {"name": "test", "conclusion": "success", "steps": []},
            ],
        }
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = json.dumps(data)

        with patch("owlmind.ci.subprocess.run", return_value=mock_result):
            jobs = failed_jobs("/workspace", 123)

        assert jobs == []

    def test_api_error_returns_empty(self) -> None:
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stderr = "error"

        with patch("owlmind.ci.subprocess.run", return_value=mock_result):
            jobs = failed_jobs("/workspace", 999)

        assert jobs == []


class TestGenerateFixGoals:
    def test_generates_goals_yaml(self, tmp_path: Path) -> None:
        data = {
            "jobs": [
                {
                    "databaseId": 1,
                    "name": "test-unit",
                    "status": "completed",
                    "conclusion": "failure",
                    "steps": [
                        {"name": "Run pytest", "conclusion": "failure"},
                    ],
                },
                {
                    "databaseId": 2,
                    "name": "test-integration",
                    "status": "completed",
                    "conclusion": "failure",
                    "steps": [
                        {"name": "Run integration", "conclusion": "failure"},
                    ],
                },
            ],
        }
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = json.dumps(data)

        out = tmp_path / "fix.yaml"
        with patch("owlmind.ci.subprocess.run", return_value=mock_result):
            path = generate_fix_goals(str(tmp_path), 42, out_path=out)

        assert path == out
        assert path.exists()

        goals_data = yaml.safe_load(path.read_text())
        assert goals_data["version"] == 2
        assert len(goals_data["goals"]) == 2
        assert goals_data["goals"][0]["id"] == "FIX-1"
        assert "test-unit" in goals_data["goals"][0]["goal"]
        assert "Run pytest" in goals_data["goals"][0]["goal"]
        # Second goal depends on first
        assert goals_data["goals"][1]["depends_on"] == ["FIX-1"]

    def test_no_failed_jobs_raises(self, tmp_path: Path) -> None:
        data = {"jobs": [{"name": "test", "conclusion": "success", "steps": []}]}
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = json.dumps(data)

        with (
            patch("owlmind.ci.subprocess.run", return_value=mock_result),
            pytest.raises(ValueError, match="No failed jobs"),
        ):
            generate_fix_goals(str(tmp_path), 42)

    def test_default_output_path(self, tmp_path: Path) -> None:
        data = {
            "jobs": [
                {
                    "databaseId": 1,
                    "name": "build",
                    "status": "completed",
                    "conclusion": "failure",
                    "steps": [],
                },
            ],
        }
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = json.dumps(data)

        with patch("owlmind.ci.subprocess.run", return_value=mock_result):
            path = generate_fix_goals(str(tmp_path), 99)

        expected = tmp_path / "fix_ci_99.yaml"
        assert path == expected
        assert path.exists()

    def test_metadata_includes_run_id(self, tmp_path: Path) -> None:
        data = {
            "jobs": [
                {"databaseId": 1, "name": "lint", "conclusion": "failure", "steps": []},
            ],
        }
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = json.dumps(data)

        with patch("owlmind.ci.subprocess.run", return_value=mock_result):
            path = generate_fix_goals(str(tmp_path), 777)

        goals_data = yaml.safe_load(path.read_text())
        assert goals_data["metadata"]["ci_run_id"] == 777
        assert goals_data["metadata"]["source"] == "ci-fix"


class TestCIDryRun:
    def setup_method(self) -> None:
        configure_gh()

    def teardown_method(self) -> None:
        configure_gh()

    def test_dry_run_list_runs(self) -> None:
        configure_gh(dry_run=True)
        runs = list_runs("/workspace")
        assert runs == []

    def test_dry_run_run_status(self) -> None:
        configure_gh(dry_run=True)
        # dry-run returns empty stdout → json.loads("") → JSONDecodeError
        with pytest.raises(json.JSONDecodeError):
            run_status("/workspace", 123)
