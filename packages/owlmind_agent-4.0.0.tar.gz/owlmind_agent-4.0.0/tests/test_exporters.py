"""Tests for Ops Export — CSV/JSON/ZIP export."""

from __future__ import annotations

import csv
import io
import json
import zipfile
from datetime import UTC, datetime
from pathlib import Path

from owlmind.exporters import (
    export_all_zip,
    export_ledger_csv,
    export_runs_csv,
    export_sessions_csv,
)


def _write_run(runs_dir: Path, name: str, state: str, goal: str = "") -> None:
    d = runs_dir / name
    d.mkdir(parents=True, exist_ok=True)
    (d / "cycle_meta.json").write_text(
        json.dumps(
            {
                "state": state,
                "goal": goal,
                "started_at": "2025-01-01T00:00:00Z",
                "ended_at": "2025-01-01T01:00:00Z",
            }
        )
    )


def _write_session(sessions_dir: Path, name: str, status: str) -> None:
    d = sessions_dir / name
    d.mkdir(parents=True, exist_ok=True)
    now = datetime.now(tz=UTC).isoformat()
    (d / "session_meta.json").write_text(
        json.dumps(
            {
                "status": status,
                "created_at": now,
                "updated_at": now,
                "goals": [{"id": "G1"}],
            }
        )
    )


class TestExportLedgerCSV:
    def test_empty_ledger(self, tmp_path: Path) -> None:
        ledger_dir = tmp_path / "ledger"
        ledger_dir.mkdir()
        out = tmp_path / "ledger.csv"

        result = export_ledger_csv(ledger_dir, out)
        assert result == out
        assert out.exists()
        content = out.read_text()
        assert "ts" in content
        assert "total_tokens" in content

    def test_with_entries(self, tmp_path: Path) -> None:
        ledger_dir = tmp_path / "ledger"
        ledger_dir.mkdir()
        entry = {
            "ts": "2025-01-01T00:00:00Z",
            "run_id": "r1",
            "stage": "worker",
            "provider": "openai",
            "model": "gpt-4o",
            "input_tokens": 100,
            "output_tokens": 50,
            "total_tokens": 150,
            "estimated_usd": 0.005,
            "latency_ms": 1000,
            "price_per_1k_input": 0.03,
            "price_per_1k_output": 0.06,
        }
        (ledger_dir / "usage.jsonl").write_text(json.dumps(entry) + "\n")

        out = tmp_path / "ledger.csv"
        export_ledger_csv(ledger_dir, out)

        reader = csv.DictReader(io.StringIO(out.read_text()))
        rows = list(reader)
        assert len(rows) == 1
        assert rows[0]["run_id"] == "r1"


class TestExportSessionsCSV:
    def test_empty(self, tmp_path: Path) -> None:
        out = tmp_path / "sessions.csv"
        export_sessions_csv(tmp_path / "sessions", out)
        assert out.exists()
        assert "session_id" in out.read_text()

    def test_with_sessions(self, tmp_path: Path) -> None:
        sessions_dir = tmp_path / "sessions"
        _write_session(sessions_dir, "s1", "DONE")
        _write_session(sessions_dir, "s2", "FAILED")

        out = tmp_path / "sessions.csv"
        export_sessions_csv(sessions_dir, out)

        reader = csv.DictReader(io.StringIO(out.read_text()))
        rows = list(reader)
        assert len(rows) == 2
        statuses = {r["status"] for r in rows}
        assert statuses == {"DONE", "FAILED"}


class TestExportRunsCSV:
    def test_empty(self, tmp_path: Path) -> None:
        out = tmp_path / "runs.csv"
        export_runs_csv(tmp_path / "runs", out)
        assert out.exists()
        assert "run_id" in out.read_text()

    def test_with_runs(self, tmp_path: Path) -> None:
        runs_dir = tmp_path / "runs"
        _write_run(runs_dir, "r1", "DONE", "build feature")
        _write_run(runs_dir, "r2", "FAILED", "fix bug")

        out = tmp_path / "runs.csv"
        export_runs_csv(runs_dir, out)

        reader = csv.DictReader(io.StringIO(out.read_text()))
        rows = list(reader)
        assert len(rows) == 2


class TestExportSessionsCSVEdgeCases:
    def test_skips_non_directory_entries(self, tmp_path: Path) -> None:
        """export_sessions_csv skips plain files inside sessions_dir (line 46)."""
        sessions_dir = tmp_path / "sessions"
        sessions_dir.mkdir()
        _write_session(sessions_dir, "s1", "DONE")
        (sessions_dir / "stray_file.txt").write_text("not a session")

        out = tmp_path / "sessions.csv"
        export_sessions_csv(sessions_dir, out)

        reader = csv.DictReader(io.StringIO(out.read_text()))
        rows = list(reader)
        assert len(rows) == 1
        assert rows[0]["session_id"] == "s1"

    def test_skips_session_without_meta_file(self, tmp_path: Path) -> None:
        """export_sessions_csv skips dirs with no session_meta.json (line 49)."""
        sessions_dir = tmp_path / "sessions"
        sessions_dir.mkdir()
        _write_session(sessions_dir, "s_ok", "DONE")
        (sessions_dir / "s_no_meta").mkdir()

        out = tmp_path / "sessions.csv"
        export_sessions_csv(sessions_dir, out)

        reader = csv.DictReader(io.StringIO(out.read_text()))
        rows = list(reader)
        assert len(rows) == 1
        assert rows[0]["session_id"] == "s_ok"


class TestExportRunsCSVEdgeCases:
    def test_skips_non_directory_entries(self, tmp_path: Path) -> None:
        """export_runs_csv skips plain files inside runs_dir (line 81)."""
        runs_dir = tmp_path / "runs"
        runs_dir.mkdir()
        _write_run(runs_dir, "r1", "DONE")
        (runs_dir / "README.txt").write_text("not a run")

        out = tmp_path / "runs.csv"
        export_runs_csv(runs_dir, out)

        reader = csv.DictReader(io.StringIO(out.read_text()))
        rows = list(reader)
        assert len(rows) == 1
        assert rows[0]["run_id"] == "r1"

    def test_skips_run_without_meta_file(self, tmp_path: Path) -> None:
        """export_runs_csv skips run dirs with no cycle_meta.json (line 84)."""
        runs_dir = tmp_path / "runs"
        runs_dir.mkdir()
        _write_run(runs_dir, "r_ok", "DONE")
        (runs_dir / "r_no_meta").mkdir()

        out = tmp_path / "runs.csv"
        export_runs_csv(runs_dir, out)

        reader = csv.DictReader(io.StringIO(out.read_text()))
        rows = list(reader)
        assert len(rows) == 1
        assert rows[0]["run_id"] == "r_ok"


class TestWriteHelpersViaZip:
    def test_write_ledger_csv_with_entries_in_zip(self, tmp_path: Path) -> None:
        """_write_ledger_csv with-entries path is covered via export_all_zip (lines 144-148)."""
        ledger_dir = tmp_path / "ledger"
        ledger_dir.mkdir()
        entry = {
            "ts": "2025-01-01T00:00:00Z",
            "run_id": "r99",
            "stage": "worker",
            "provider": "openai",
            "model": "gpt-4o",
            "input_tokens": 10,
            "output_tokens": 5,
            "total_tokens": 15,
            "estimated_usd": 0.001,
            "latency_ms": 500,
            "price_per_1k_input": 0.03,
            "price_per_1k_output": 0.06,
        }
        (ledger_dir / "usage.jsonl").write_text(json.dumps(entry) + "\n")

        out = tmp_path / "export.zip"
        export_all_zip(
            out,
            ledger_dir=ledger_dir,
            sessions_dir=tmp_path / "sessions",
            runs_dir=tmp_path / "runs",
        )

        with zipfile.ZipFile(out) as zf:
            ledger_csv = zf.read("ledger.csv").decode()
        assert "r99" in ledger_csv
        assert "total_tokens" in ledger_csv

    def test_write_sessions_csv_skips_files_and_no_meta_in_zip(self, tmp_path: Path) -> None:
        """_write_sessions_csv skips plain files and no-meta dirs via zip (lines 165, 168)."""
        sessions_dir = tmp_path / "sessions"
        sessions_dir.mkdir()
        _write_session(sessions_dir, "sess_valid", "DONE")
        (sessions_dir / "stray.txt").write_text("noise")
        (sessions_dir / "sess_no_meta").mkdir()

        out = tmp_path / "export.zip"
        export_all_zip(
            out,
            ledger_dir=tmp_path / "ledger",
            sessions_dir=sessions_dir,
            runs_dir=tmp_path / "runs",
        )

        with zipfile.ZipFile(out) as zf:
            sessions_csv = zf.read("sessions.csv").decode()
        assert "sess_valid" in sessions_csv
        assert "stray.txt" not in sessions_csv
        assert "sess_no_meta" not in sessions_csv

    def test_write_runs_csv_skips_files_and_no_meta_in_zip(self, tmp_path: Path) -> None:
        """_write_runs_csv skips plain files and no-meta dirs via zip (lines 190, 193)."""
        runs_dir = tmp_path / "runs"
        runs_dir.mkdir()
        _write_run(runs_dir, "run_valid", "DONE")
        (runs_dir / "notes.txt").write_text("noise")
        (runs_dir / "run_no_meta").mkdir()

        out = tmp_path / "export.zip"
        export_all_zip(
            out,
            ledger_dir=tmp_path / "ledger",
            sessions_dir=tmp_path / "sessions",
            runs_dir=runs_dir,
        )

        with zipfile.ZipFile(out) as zf:
            runs_csv = zf.read("runs.csv").decode()
        assert "run_valid" in runs_csv
        assert "notes.txt" not in runs_csv
        assert "run_no_meta" not in runs_csv


class TestExportAllZip:
    def test_creates_zip(self, tmp_path: Path) -> None:
        ledger_dir = tmp_path / "ledger"
        ledger_dir.mkdir()
        runs_dir = tmp_path / "runs"
        sessions_dir = tmp_path / "sessions"

        out = tmp_path / "export.zip"
        result = export_all_zip(
            out,
            ledger_dir=ledger_dir,
            sessions_dir=sessions_dir,
            runs_dir=runs_dir,
        )

        assert result == out
        assert out.exists()

        with zipfile.ZipFile(out) as zf:
            names = zf.namelist()
            assert "ledger.csv" in names
            assert "sessions.csv" in names
            assert "runs.csv" in names

    def test_zip_with_data(self, tmp_path: Path) -> None:
        ledger_dir = tmp_path / "ledger"
        ledger_dir.mkdir()
        runs_dir = tmp_path / "runs"
        sessions_dir = tmp_path / "sessions"
        _write_run(runs_dir, "r1", "DONE")
        _write_session(sessions_dir, "s1", "DONE")

        out = tmp_path / "export.zip"
        export_all_zip(
            out,
            ledger_dir=ledger_dir,
            sessions_dir=sessions_dir,
            runs_dir=runs_dir,
        )

        with zipfile.ZipFile(out) as zf:
            runs_csv = zf.read("runs.csv").decode()
            assert "r1" in runs_csv
            sessions_csv = zf.read("sessions.csv").decode()
            assert "s1" in sessions_csv
