"""Tests for Slack integration: verifier, client, commands, and API route."""

from __future__ import annotations

import hashlib
import hmac
import json
import time
from unittest.mock import MagicMock, patch

import pytest
from starlette.testclient import TestClient

from owlmind.integrations.slack.client import SlackClient, SlackMessage
from owlmind.integrations.slack.commands import (
    SlashCommandPayload,
    format_task_status,
    parse_payload,
    route_command,
)
from owlmind.integrations.slack.verifier import SlackSignatureError, verify_slack_signature

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_slack_signature(secret: str, timestamp: str, body: bytes) -> str:
    basestring = f"v0:{timestamp}:{body.decode()}".encode()
    digest = hmac.new(secret.encode(), basestring, hashlib.sha256).hexdigest()
    return f"v0={digest}"


def _make_payload(**kwargs) -> SlashCommandPayload:
    defaults = {
        "command": "/owlmind",
        "text": "help",
        "user_id": "U123",
        "user_name": "alice",
        "channel_id": "C456",
        "team_id": "T789",
        "response_url": "https://hooks.slack.com/commands/T789/xxx",
        "trigger_id": "trigger-1",
    }
    defaults.update(kwargs)
    return SlashCommandPayload(**defaults)


# ---------------------------------------------------------------------------
# TestSlackSignatureVerifier
# ---------------------------------------------------------------------------


class TestSlackSignatureVerifier:
    def test_valid_signature_passes(self):
        secret = "my-secret"
        ts = str(int(time.time()))
        body = b"command=%2Fowlmind&text=help"
        sig = _make_slack_signature(secret, ts, body)
        # Should not raise
        verify_slack_signature(signing_secret=secret, timestamp=ts, body=body, signature=sig)

    def test_wrong_signature_raises(self):
        secret = "my-secret"
        ts = str(int(time.time()))
        body = b"command=%2Fowlmind&text=help"
        with pytest.raises(SlackSignatureError, match="Signature mismatch"):
            verify_slack_signature(
                signing_secret=secret,
                timestamp=ts,
                body=body,
                signature="v0=invalidsig",
            )

    def test_stale_timestamp_raises(self):
        secret = "my-secret"
        old_ts = str(int(time.time()) - 400)  # 400s old, max is 300
        body = b"text=help"
        sig = _make_slack_signature(secret, old_ts, body)
        with pytest.raises(SlackSignatureError, match="too old"):
            verify_slack_signature(signing_secret=secret, timestamp=old_ts, body=body, signature=sig)

    def test_future_timestamp_within_tolerance_passes(self):
        """Timestamps slightly in the future (clock skew) are accepted."""
        secret = "my-secret"
        future_ts = str(int(time.time()) + 10)  # 10s in future, still ok
        body = b"text=run"
        sig = _make_slack_signature(secret, future_ts, body)
        verify_slack_signature(signing_secret=secret, timestamp=future_ts, body=body, signature=sig)

    def test_invalid_timestamp_raises(self):
        with pytest.raises(SlackSignatureError, match="Invalid timestamp"):
            verify_slack_signature(
                signing_secret="s",
                timestamp="not-a-number",
                body=b"x",
                signature="v0=abc",
            )

    def test_custom_max_age(self):
        secret = "secret"
        ts = str(int(time.time()) - 10)
        body = b"hello"
        sig = _make_slack_signature(secret, ts, body)
        with pytest.raises(SlackSignatureError, match="too old"):
            verify_slack_signature(
                signing_secret=secret, timestamp=ts, body=body, signature=sig, max_age=5
            )


# ---------------------------------------------------------------------------
# TestSlackMessage
# ---------------------------------------------------------------------------


class TestSlackMessage:
    def test_basic_message(self):
        msg = SlackMessage(channel="C1", text="Hello")
        d = msg.to_dict()
        assert d["channel"] == "C1"
        assert d["text"] == "Hello"
        assert "thread_ts" not in d
        assert "blocks" not in d

    def test_threaded_message(self):
        msg = SlackMessage(channel="C1", text="reply", thread_ts="1234567890.000100")
        d = msg.to_dict()
        assert d["thread_ts"] == "1234567890.000100"

    def test_message_with_blocks(self):
        blocks = [{"type": "section", "text": {"type": "mrkdwn", "text": "hi"}}]
        msg = SlackMessage(channel="C1", text="fallback", blocks=blocks)
        d = msg.to_dict()
        assert d["blocks"] == blocks


# ---------------------------------------------------------------------------
# TestSlackClient
# ---------------------------------------------------------------------------


class TestSlackClient:
    @pytest.mark.asyncio
    async def test_post_message_calls_api(self):
        client = SlackClient(bot_token="xoxb-test")
        fake_resp = MagicMock()
        fake_resp.__enter__ = MagicMock(return_value=fake_resp)
        fake_resp.__exit__ = MagicMock(return_value=False)
        fake_resp.read.return_value = json.dumps({"ok": True, "ts": "123"}).encode()

        with patch("urllib.request.urlopen", return_value=fake_resp):
            result = await client.post_message("C1", "Hello from OWLMIND")
        assert result["ok"] is True
        assert result["ts"] == "123"

    @pytest.mark.asyncio
    async def test_post_message_http_error_returns_ok_false(self):
        import urllib.error

        client = SlackClient(bot_token="xoxb-test")
        exc = urllib.error.HTTPError(url="http://x", code=500, msg="Error", hdrs=MagicMock(), fp=None)
        with patch("urllib.request.urlopen", side_effect=exc):
            result = await client.post_message("C1", "test")
        assert result["ok"] is False

    @pytest.mark.asyncio
    async def test_respond_url_success(self):
        client = SlackClient(bot_token="xoxb-test")
        fake_resp = MagicMock()
        fake_resp.__enter__ = MagicMock(return_value=fake_resp)
        fake_resp.__exit__ = MagicMock(return_value=False)
        fake_resp.read.return_value = b'{"ok": true}'

        with patch("urllib.request.urlopen", return_value=fake_resp):
            result = await client.respond_url("https://hooks.slack.com/xxx", "Done!")
        assert result["ok"] is True

    @pytest.mark.asyncio
    async def test_respond_url_empty_body_returns_ok(self):
        client = SlackClient(bot_token="xoxb-test")
        fake_resp = MagicMock()
        fake_resp.__enter__ = MagicMock(return_value=fake_resp)
        fake_resp.__exit__ = MagicMock(return_value=False)
        fake_resp.read.return_value = b""  # Slack returns empty on success for response_url

        with patch("urllib.request.urlopen", return_value=fake_resp):
            result = await client.respond_url("https://hooks.slack.com/xxx", "Done!")
        assert result["ok"] is True


# ---------------------------------------------------------------------------
# TestSlashCommandParsing
# ---------------------------------------------------------------------------


class TestSlashCommandParsing:
    def test_parse_basic_payload(self):
        data = {
            "command": "/owlmind",
            "text": "run fix the bug",
            "user_id": "U123",
            "user_name": "bob",
            "channel_id": "C789",
            "team_id": "T001",
            "response_url": "https://hooks.slack.com/xxx",
            "trigger_id": "trig-1",
        }
        p = parse_payload(data)
        assert p.command == "/owlmind"
        assert p.text == "run fix the bug"
        assert p.user_id == "U123"
        assert p.channel_id == "C789"

    def test_parse_missing_fields_use_defaults(self):
        p = parse_payload({})
        assert p.command == "/owlmind"
        assert p.text == ""
        assert p.user_id == ""


# ---------------------------------------------------------------------------
# TestRouteCommand
# ---------------------------------------------------------------------------


class TestRouteCommand:
    def test_help_command(self):
        payload = _make_payload(text="help")
        resp = route_command(payload)
        assert resp["response_type"] == "ephemeral"
        assert "OWLMIND Slash Commands" in resp["text"]

    def test_empty_text_defaults_to_help(self):
        payload = _make_payload(text="")
        resp = route_command(payload)
        assert "OWLMIND Slash Commands" in resp["text"]

    def test_run_command_with_goal(self):
        payload = _make_payload(text="run fix the CI pipeline")
        resp = route_command(payload)
        assert resp["response_type"] == "in_channel"
        assert "fix the CI pipeline" in resp["text"]
        assert resp.get("_goal") == "fix the CI pipeline"

    def test_run_command_no_goal_returns_error(self):
        payload = _make_payload(text="run")
        resp = route_command(payload)
        assert resp["response_type"] == "ephemeral"
        assert "Please provide a goal" in resp["text"]

    def test_status_command(self):
        payload = _make_payload(text="status abc-123")
        resp = route_command(payload)
        assert resp.get("_task_id") == "abc-123"

    def test_status_command_alias_st(self):
        payload = _make_payload(text="st")
        resp = route_command(payload)
        assert "_task_id" in resp

    def test_queue_command(self):
        payload = _make_payload(text="queue")
        resp = route_command(payload)
        assert resp.get("_list_queue") is True

    def test_unknown_command_returns_help(self):
        payload = _make_payload(text="xyz unknown")
        resp = route_command(payload)
        assert "OWLMIND Slash Commands" in resp["text"]


# ---------------------------------------------------------------------------
# TestFormatTaskStatus
# ---------------------------------------------------------------------------


class TestFormatTaskStatus:
    def test_format_done_task(self):
        task = {
            "id": "abc-123-456",
            "goal": "Fix the bug",
            "status": "DONE",
            "run_id": "run-001",
            "created_at": "2026-03-01T10:00:00+00:00",
        }
        text = format_task_status(task)
        assert "✅" in text
        assert "DONE" in text
        assert "Fix the bug" in text
        assert "run-001" in text

    def test_format_pending_task(self):
        text = format_task_status({"id": "x", "goal": "Refactor", "status": "PENDING"})
        assert "⏳" in text

    def test_format_unknown_status(self):
        text = format_task_status({"id": "x", "goal": "task", "status": "WEIRD"})
        assert "❓" in text

    def test_truncates_long_goal(self):
        long_goal = "A" * 200
        text = format_task_status({"id": "x", "goal": long_goal, "status": "DONE"})
        assert len(text) < 500  # Should be truncated


# ---------------------------------------------------------------------------
# TestSlackWebhookEndpoint
# ---------------------------------------------------------------------------


class TestSlackWebhookEndpoint:
    """Integration tests for the FastAPI /api/v1/webhooks/slack endpoint."""

    def _make_app(self, signing_secret: str = "", queue_dir=None):
        from owlmind.api.app import create_app

        return create_app(
            runs_dir="/tmp/test-runs",
            ledger_dir="/tmp/test-ledger",
            queue_path=str(queue_dir) if queue_dir else "/tmp/test-queue",
            policies_dir="/tmp/test-policies",
            slack_signing_secret=signing_secret,
        )

    def _form_body(self, **kwargs) -> bytes:
        defaults = {
            "command": "%2Fowlmind",
            "text": "help",
            "user_id": "U123",
            "user_name": "alice",
            "channel_id": "C456",
            "team_id": "T789",
            "response_url": "https%3A%2F%2Fhooks.slack.com%2Fxxx",
        }
        defaults.update(kwargs)
        return "&".join(f"{k}={v}" for k, v in defaults.items()).encode()

    def test_help_command_returns_200(self):
        app = self._make_app()
        with TestClient(app) as client:
            resp = client.post(
                "/api/v1/webhooks/slack",
                content=self._form_body(text="help"),
                headers={"Content-Type": "application/x-www-form-urlencoded"},
            )
        assert resp.status_code == 200
        data = resp.json()
        assert "OWLMIND Slash Commands" in data["text"]

    def test_signature_verification_missing_headers(self):
        app = self._make_app(signing_secret="mysecret")
        with TestClient(app) as client:
            resp = client.post(
                "/api/v1/webhooks/slack",
                content=self._form_body(),
                headers={"Content-Type": "application/x-www-form-urlencoded"},
            )
        assert resp.status_code == 400

    def test_signature_verification_invalid_signature(self):
        app = self._make_app(signing_secret="mysecret")
        ts = str(int(time.time()))
        with TestClient(app) as client:
            resp = client.post(
                "/api/v1/webhooks/slack",
                content=self._form_body(),
                headers={
                    "Content-Type": "application/x-www-form-urlencoded",
                    "X-Slack-Request-Timestamp": ts,
                    "X-Slack-Signature": "v0=invalidsig",
                },
            )
        assert resp.status_code == 403

    def test_signature_verification_valid_passes(self):
        secret = "valid-secret"
        body = self._form_body(text="help")
        ts = str(int(time.time()))
        sig = _make_slack_signature(secret, ts, body)
        app = self._make_app(signing_secret=secret)
        with TestClient(app) as client:
            resp = client.post(
                "/api/v1/webhooks/slack",
                content=body,
                headers={
                    "Content-Type": "application/x-www-form-urlencoded",
                    "X-Slack-Request-Timestamp": ts,
                    "X-Slack-Signature": sig,
                },
            )
        assert resp.status_code == 200

    def test_run_command_queues_task(self, tmp_path):
        app = self._make_app(queue_dir=tmp_path)
        with TestClient(app) as client:
            resp = client.post(
                "/api/v1/webhooks/slack",
                content=self._form_body(text="run+fix+the+tests"),
                headers={"Content-Type": "application/x-www-form-urlencoded"},
            )
        assert resp.status_code == 200
        data = resp.json()
        assert "Task queued" in data["text"] or "fix the tests" in data["text"]
        # Verify task was written to queue file
        queue_file = tmp_path / "queue.jsonl"
        assert queue_file.exists()
        content = queue_file.read_text()
        assert "fix the tests" in content

    def test_status_command_no_queue(self):
        app = self._make_app()
        with TestClient(app) as client:
            resp = client.post(
                "/api/v1/webhooks/slack",
                content=self._form_body(text="status"),
                headers={"Content-Type": "application/x-www-form-urlencoded"},
            )
        assert resp.status_code == 200

    def test_queue_command_empty(self, tmp_path):
        app = self._make_app(queue_dir=tmp_path)
        with TestClient(app) as client:
            resp = client.post(
                "/api/v1/webhooks/slack",
                content=self._form_body(text="queue"),
                headers={"Content-Type": "application/x-www-form-urlencoded"},
            )
        assert resp.status_code == 200
        assert "empty" in resp.json()["text"].lower() or "queue" in resp.json()["text"].lower()
