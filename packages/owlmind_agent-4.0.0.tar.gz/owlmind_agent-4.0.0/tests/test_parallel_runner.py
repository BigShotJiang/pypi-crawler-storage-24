"""Tests for owlmind.graph.parallel_runner."""
from __future__ import annotations

import asyncio
import threading
import time
from unittest.mock import MagicMock, patch

from owlmind.graph.parallel_runner import (
    ParallelGraphRunner,
    ParallelResult,
    ParallelRunResult,
    ParallelTask,
    SubtaskResult,
)


def _make_state(verdict: str) -> MagicMock:
    state = MagicMock()
    state.final_verdict = verdict
    return state


def test_subtask_result_success() -> None:
    r = SubtaskResult(goal="fix tests", workspace=".", verdict="APPROVED")
    assert r.success is True

def test_subtask_result_failure() -> None:
    r = SubtaskResult(goal="fix tests", workspace=".", verdict="REJECTED")
    assert r.success is False

def test_parallel_run_result_counts() -> None:
    result = ParallelRunResult(subtasks=[
        SubtaskResult(goal="a", workspace=".", verdict="APPROVED"),
        SubtaskResult(goal="b", workspace=".", verdict="REJECTED"),
        SubtaskResult(goal="c", workspace=".", verdict="APPROVED"),
    ])
    assert result.approved_count == 2
    assert result.failed_count == 1
    assert result.all_approved is False

def test_parallel_run_result_all_approved() -> None:
    result = ParallelRunResult(subtasks=[
        SubtaskResult(goal="a", workspace=".", verdict="APPROVED"),
        SubtaskResult(goal="b", workspace=".", verdict="APPROVED"),
    ])
    assert result.all_approved is True

def test_parallel_run_result_summary() -> None:
    result = ParallelRunResult(subtasks=[
        SubtaskResult(goal="task one", workspace=".", verdict="APPROVED"),
    ], total_ms=500)
    s = result.summary()
    assert "task one" in s
    assert "500ms" in s

def test_run_parallel_success() -> None:
    """Mock GraphRunner and verify parallel execution."""
    mock_state = _make_state("APPROVED")

    with patch("owlmind.graph.parallel_runner.GraphRunner") as mock_cls, \
         patch("owlmind.graph.parallel_runner._build_llm_client", return_value=MagicMock()):
        mock_runner = MagicMock()
        mock_runner.run.return_value = mock_state
        mock_cls.return_value = mock_runner

        runner = ParallelGraphRunner(workers=2, max_iterations=1)
        result = runner.run_parallel(["task a", "task b"], workspace=".")

    assert len(result.subtasks) == 2
    assert all(s.verdict == "APPROVED" for s in result.subtasks)
    assert result.all_approved is True

def test_run_parallel_no_llm() -> None:
    """When LLM not configured, subtask returns error."""
    with patch("owlmind.graph.parallel_runner._build_llm_client", return_value=None):
        runner = ParallelGraphRunner(workers=1)
        result = runner.run_parallel(["task a"], workspace=".")

    assert len(result.subtasks) == 1
    assert result.subtasks[0].error == "No LLM configured"
    assert not result.subtasks[0].success

def test_run_parallel_handles_exception() -> None:
    """Exception in one subtask doesn't kill others."""
    call_count = [0]

    def mock_run(goal, workspace, max_iterations, skip_tester):
        call_count[0] += 1
        if goal == "bad task":
            raise RuntimeError("task failed")
        return _make_state("APPROVED")

    with patch("owlmind.graph.parallel_runner.GraphRunner") as mock_cls, \
         patch("owlmind.graph.parallel_runner._build_llm_client", return_value=MagicMock()):
        mock_runner = MagicMock()
        mock_runner.run.side_effect = mock_run
        mock_cls.return_value = mock_runner

        runner = ParallelGraphRunner(workers=2)
        result = runner.run_parallel(["good task", "bad task"], workspace=".")

    assert len(result.subtasks) == 2
    good = next(s for s in result.subtasks if s.goal == "good task")
    bad = next(s for s in result.subtasks if s.goal == "bad task")
    assert good.success
    assert bad.error == "task failed"

def test_run_parallel_empty() -> None:
    runner = ParallelGraphRunner()
    result = runner.run_parallel([], workspace=".")
    assert result.subtasks == []
    assert result.all_approved is False  # empty list


# ---------------------------------------------------------------------------
# Task-based API tests (ParallelTask / ParallelResult / run_all)
# ---------------------------------------------------------------------------


def _make_task_state(verdict: str = "APPROVED", review: str = "All good") -> MagicMock:
    state = MagicMock()
    state.final_verdict = verdict
    state.review = review
    state.plan = "some plan"
    return state


class TestRunAllEmpty:
    def test_empty_returns_empty_list(self) -> None:
        runner = ParallelGraphRunner(max_workers=3)
        results = asyncio.run(runner.run_all([]))
        assert results == []


class TestRunAllBothTasks:
    def test_both_tasks_run_and_return_results(self) -> None:
        task1 = ParallelTask(goal="fix lint errors", workspace=".")
        task2 = ParallelTask(goal="add type hints", workspace=".")

        state1 = _make_task_state(verdict="APPROVED", review="Great")
        state2 = _make_task_state(verdict="NEEDS_FIX", review="Some issues")

        call_order: list[str] = []

        def fake_run(goal: str = "", workspace: str = ".", **kwargs: object) -> MagicMock:
            call_order.append(goal)
            return state1 if goal == "fix lint errors" else state2

        fake_runner = MagicMock()
        fake_runner.run.side_effect = fake_run

        with patch(
            "owlmind.graph.parallel_runner.GraphRunner",
            return_value=fake_runner,
        ), patch(
            "owlmind.graph.parallel_runner._build_llm_client",
            return_value=MagicMock(),
        ):
            runner = ParallelGraphRunner(max_workers=3)
            results = asyncio.run(runner.run_all([task1, task2]))

        assert len(results) == 2
        assert results[0].task is task1
        assert results[1].task is task2
        assert results[0].verdict == "APPROVED"
        assert results[1].verdict == "NEEDS_FIX"
        assert set(call_order) == {"fix lint errors", "add type hints"}


class TestRunAllErrorHandling:
    def test_one_task_raises_others_still_complete(self) -> None:
        task_good = ParallelTask(goal="write docstrings", workspace=".")
        task_bad = ParallelTask(goal="explode everything", workspace=".")

        state_good = _make_task_state(verdict="APPROVED")

        def fake_run(goal: str = "", workspace: str = ".", **kwargs: object) -> MagicMock:
            if goal == "explode everything":
                raise RuntimeError("boom!")
            return state_good

        fake_runner = MagicMock()
        fake_runner.run.side_effect = fake_run

        with patch(
            "owlmind.graph.parallel_runner.GraphRunner",
            return_value=fake_runner,
        ), patch(
            "owlmind.graph.parallel_runner._build_llm_client",
            return_value=MagicMock(),
        ):
            runner = ParallelGraphRunner(max_workers=3)
            results = asyncio.run(runner.run_all([task_good, task_bad]))

        assert len(results) == 2
        good = next(r for r in results if r.task.goal == "write docstrings")
        bad = next(r for r in results if r.task.goal == "explode everything")

        assert good.verdict == "APPROVED"
        assert good.error is None
        assert bad.verdict == "ERROR"
        assert bad.error is not None
        assert "boom!" in bad.error

    def test_error_result_has_empty_summary(self) -> None:
        task = ParallelTask(goal="fail", workspace=".")

        fake_runner = MagicMock()
        fake_runner.run.side_effect = ValueError("something went wrong")

        with patch(
            "owlmind.graph.parallel_runner.GraphRunner",
            return_value=fake_runner,
        ), patch(
            "owlmind.graph.parallel_runner._build_llm_client",
            return_value=MagicMock(),
        ):
            runner = ParallelGraphRunner(max_workers=3)
            results = asyncio.run(runner.run_all([task]))

        assert len(results) == 1
        assert results[0].verdict == "ERROR"
        assert results[0].summary == ""
        assert "something went wrong" in (results[0].error or "")


class TestSemaphoreConcurrency:
    def test_semaphore_limits_concurrency_to_max_workers(self) -> None:
        """Verify at most max_workers tasks run simultaneously."""
        max_workers = 2
        n_tasks = 4
        tasks = [ParallelTask(goal=f"task {i}", workspace=".") for i in range(n_tasks)]

        active_count = 0
        peak_active = 0
        lock = threading.Lock()

        def fake_run(goal: str = "", workspace: str = ".", **kwargs: object) -> MagicMock:
            nonlocal active_count, peak_active
            with lock:
                active_count += 1
                if active_count > peak_active:
                    peak_active = active_count
            time.sleep(0.05)
            with lock:
                active_count -= 1
            return _make_task_state(verdict="APPROVED")

        fake_runner = MagicMock()
        fake_runner.run.side_effect = fake_run

        with patch(
            "owlmind.graph.parallel_runner.GraphRunner",
            return_value=fake_runner,
        ), patch(
            "owlmind.graph.parallel_runner._build_llm_client",
            return_value=MagicMock(),
        ):
            runner = ParallelGraphRunner(max_workers=max_workers)
            results = asyncio.run(runner.run_all(tasks))

        assert len(results) == n_tasks
        assert all(r.verdict == "APPROVED" for r in results)
        assert peak_active <= max_workers, (
            f"Peak concurrency {peak_active} exceeded max_workers={max_workers}"
        )


class TestParallelTaskDataclass:
    def test_fields(self) -> None:
        t = ParallelTask(goal="my goal", workspace="/tmp", run_id="abc123")
        assert t.goal == "my goal"
        assert t.workspace == "/tmp"
        assert t.run_id == "abc123"

    def test_run_id_defaults_none(self) -> None:
        t = ParallelTask(goal="g", workspace=".")
        assert t.run_id is None


class TestParallelResultDataclass:
    def test_fields(self) -> None:
        task = ParallelTask(goal="g", workspace=".")
        r = ParallelResult(task=task, verdict="APPROVED", summary="done")
        assert r.verdict == "APPROVED"
        assert r.summary == "done"
        assert r.error is None

    def test_error_field(self) -> None:
        task = ParallelTask(goal="g", workspace=".")
        r = ParallelResult(task=task, verdict="ERROR", summary="", error="oops")
        assert r.error == "oops"


class TestMaxWorkersAlias:
    def test_max_workers_kwarg_accepted(self) -> None:
        runner = ParallelGraphRunner(max_workers=5)
        assert runner._workers == 5

    def test_workers_positional_still_works(self) -> None:
        runner = ParallelGraphRunner(workers=4)
        assert runner._workers == 4

    def test_max_workers_overrides_workers(self) -> None:
        runner = ParallelGraphRunner(workers=2, max_workers=7)
        assert runner._workers == 7
