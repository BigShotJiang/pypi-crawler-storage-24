"""Tests for pre-run cost estimation."""

from __future__ import annotations

import pytest

from owlmind.config import BudgetConfig, PricingConfig
from owlmind.cost import CostEstimate, _goal_complexity, estimate_goal, estimate_session

# ── Fixtures ──


@pytest.fixture()
def pricing() -> PricingConfig:
    return PricingConfig(
        openai_price_per_1k_input=0.0025,
        openai_price_per_1k_output=0.01,
        anthropic_price_per_1k_input=0.003,
        anthropic_price_per_1k_output=0.015,
        gemini_price_per_1k_input=0.0,
        gemini_price_per_1k_output=0.0,
    )


@pytest.fixture()
def budget() -> BudgetConfig:
    return BudgetConfig(
        max_tokens_per_run=200_000,
        max_tokens_per_day=500_000,
        max_usd_per_day=10.0,
    )


# ── CostEstimate dataclass ──


class TestCostEstimate:
    def test_to_dict_has_all_fields(self) -> None:
        est = CostEstimate(
            estimated_input_tokens=100,
            estimated_output_tokens=200,
            estimated_total_tokens=300,
            estimated_usd_low=0.01,
            estimated_usd_high=0.05,
            provider="openai",
        )
        d = est.to_dict()
        assert d["estimated_input_tokens"] == 100
        assert d["estimated_total_tokens"] == 300
        assert d["provider"] == "openai"

    def test_display_range(self) -> None:
        est = CostEstimate(estimated_usd_low=0.1234, estimated_usd_high=0.5678)
        assert "$0.1234" in est.display_range
        assert "$0.5678" in est.display_range

    def test_default_values(self) -> None:
        est = CostEstimate()
        assert est.estimated_input_tokens == 0
        assert est.budget_warning is False
        assert est.details == {}


# ── Complexity heuristic ──


class TestGoalComplexity:
    def test_short_goal_low_complexity(self) -> None:
        c = _goal_complexity("Fix typo in README")
        assert c == 1.0

    def test_medium_goal(self) -> None:
        goal = " ".join(["word"] * 60)
        c = _goal_complexity(goal)
        assert c > 1.0

    def test_long_goal_high_complexity(self) -> None:
        goal = " ".join(["word"] * 120)
        c = _goal_complexity(goal)
        assert c >= 2.0

    def test_multiline_goal(self) -> None:
        goal = "\n".join([f"Step {i}: do something" for i in range(10)])
        c = _goal_complexity(goal)
        assert c >= 2.0

    def test_max_cap_at_3(self) -> None:
        goal = "\n".join([" ".join(["word"] * 30) for _ in range(20)])
        c = _goal_complexity(goal)
        assert c <= 3.0


# ── estimate_goal ──


class TestEstimateGoal:
    def test_basic_estimate(self, pricing: PricingConfig, budget: BudgetConfig) -> None:
        est = estimate_goal("Fix bug", "openai", pricing, budget)
        assert est.estimated_input_tokens > 0
        assert est.estimated_output_tokens > 0
        assert (
            est.estimated_total_tokens == est.estimated_input_tokens + est.estimated_output_tokens
        )
        assert est.estimated_usd_low > 0
        assert est.estimated_usd_high > est.estimated_usd_low

    def test_provider_is_set(self, pricing: PricingConfig, budget: BudgetConfig) -> None:
        est = estimate_goal("Fix bug", "anthropic", pricing, budget)
        assert est.provider == "anthropic"

    def test_more_iterations_more_cost(self, pricing: PricingConfig, budget: BudgetConfig) -> None:
        est1 = estimate_goal("Fix bug", "openai", pricing, budget, iterations=1)
        est3 = estimate_goal("Fix bug", "openai", pricing, budget, iterations=3)
        assert est3.estimated_usd_high > est1.estimated_usd_high

    def test_complex_goal_more_expensive(
        self, pricing: PricingConfig, budget: BudgetConfig
    ) -> None:
        simple = estimate_goal("Fix typo", "openai", pricing, budget)
        complex_goal = " ".join(["Implement"] * 120)
        complex_est = estimate_goal(complex_goal, "openai", pricing, budget)
        assert complex_est.estimated_usd_high > simple.estimated_usd_high

    def test_gemini_free_tier(self, pricing: PricingConfig, budget: BudgetConfig) -> None:
        est = estimate_goal("Fix bug", "gemini", pricing, budget)
        assert est.estimated_usd_low == 0.0
        assert est.estimated_usd_high == 0.0

    def test_budget_warning_triggered(self, pricing: PricingConfig) -> None:
        tiny_budget = BudgetConfig(max_usd_per_day=0.001)
        est = estimate_goal("Fix bug", "openai", pricing, tiny_budget)
        assert est.budget_warning is True
        assert est.budget_pct > 50.0

    def test_budget_no_warning_large_budget(
        self, pricing: PricingConfig, budget: BudgetConfig
    ) -> None:
        est = estimate_goal("Fix bug", "openai", pricing, budget)
        assert est.budget_warning is False

    def test_remaining_usd_override(self, pricing: PricingConfig, budget: BudgetConfig) -> None:
        est_full = estimate_goal("Fix bug", "openai", pricing, budget, remaining_usd=10.0)
        est_low = estimate_goal("Fix bug", "openai", pricing, budget, remaining_usd=0.001)
        assert est_low.budget_pct > est_full.budget_pct

    def test_details_contain_stages(self, pricing: PricingConfig, budget: BudgetConfig) -> None:
        est = estimate_goal("Fix bug", "openai", pricing, budget)
        stages = est.details.get("stages", {})
        assert "planner" in stages
        assert "worker" in stages
        assert "judge" in stages

    def test_details_contain_complexity(self, pricing: PricingConfig, budget: BudgetConfig) -> None:
        est = estimate_goal("Fix bug", "openai", pricing, budget)
        assert "complexity_multiplier" in est.details


# ── estimate_session ──


class TestEstimateSession:
    def test_empty_goals(self, pricing: PricingConfig, budget: BudgetConfig) -> None:
        est = estimate_session([], "openai", pricing, budget)
        assert est.estimated_total_tokens == 0
        assert est.estimated_usd_low == 0.0

    def test_single_goal_session(self, pricing: PricingConfig, budget: BudgetConfig) -> None:
        est = estimate_session(["Fix bug"], "openai", pricing, budget)
        single = estimate_goal("Fix bug", "openai", pricing, budget)
        assert est.estimated_total_tokens == single.estimated_total_tokens

    def test_multiple_goals_additive(self, pricing: PricingConfig, budget: BudgetConfig) -> None:
        goals = ["Fix bug", "Add feature", "Write tests"]
        est = estimate_session(goals, "openai", pricing, budget)
        assert est.estimated_total_tokens > 0
        assert est.details.get("goal_count") == 3

    def test_session_details_have_goals(self, pricing: PricingConfig, budget: BudgetConfig) -> None:
        goals = ["Fix bug", "Add feature"]
        est = estimate_session(goals, "openai", pricing, budget)
        goal_details = est.details.get("goals", [])
        assert len(goal_details) == 2
        assert "usd_range" in goal_details[0]

    def test_session_budget_warning(self, pricing: PricingConfig) -> None:
        tiny = BudgetConfig(max_usd_per_day=0.001)
        goals = ["A", "B", "C"]
        est = estimate_session(goals, "openai", pricing, tiny)
        assert est.budget_warning is True

    def test_long_goal_truncated_in_details(
        self, pricing: PricingConfig, budget: BudgetConfig
    ) -> None:
        long_goal = "A" * 200
        est = estimate_session([long_goal], "openai", pricing, budget)
        goal_text = est.details["goals"][0]["goal"]
        assert len(goal_text) <= 84  # 80 + "..."

    def test_session_iterations(self, pricing: PricingConfig, budget: BudgetConfig) -> None:
        est1 = estimate_session(["Fix bug"], "openai", pricing, budget, iterations_per_goal=1)
        est3 = estimate_session(["Fix bug"], "openai", pricing, budget, iterations_per_goal=3)
        assert est3.estimated_usd_high > est1.estimated_usd_high

    def test_session_remaining_usd(self, pricing: PricingConfig, budget: BudgetConfig) -> None:
        est = estimate_session(["Fix bug"], "openai", pricing, budget, remaining_usd=0.001)
        assert est.budget_warning is True
