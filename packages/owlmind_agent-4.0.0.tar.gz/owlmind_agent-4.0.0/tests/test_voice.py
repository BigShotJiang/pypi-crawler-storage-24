"""Tests for owlmind.voice — Whisper transcription module."""
from __future__ import annotations

import asyncio
import os
from unittest.mock import MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# is_available()
# ---------------------------------------------------------------------------


def test_is_available_no_key(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    from owlmind import voice as v

    with patch.dict(os.environ, {}, clear=True):
        assert v.is_available() is False


def test_is_available_with_key_and_httpx(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
    import sys

    fake_httpx = MagicMock()
    with patch.dict(sys.modules, {"httpx": fake_httpx}):
        from owlmind import voice as v

        assert v.is_available() is True


def test_is_available_returns_bool(monkeypatch: pytest.MonkeyPatch) -> None:
    """is_available() always returns a bool regardless of env."""
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
    from owlmind import voice as v

    result = v.is_available()
    assert isinstance(result, bool)


# ---------------------------------------------------------------------------
# transcribe_bytes() — no API key
# ---------------------------------------------------------------------------


def test_transcribe_bytes_no_key(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("WHISPER_API_KEY", raising=False)
    os.environ.pop("OPENAI_API_KEY", None)
    os.environ.pop("WHISPER_API_KEY", None)

    from owlmind.voice import transcribe_bytes

    with pytest.raises(RuntimeError, match="No API key"):
        transcribe_bytes(b"audio", filename="voice.ogg")


# ---------------------------------------------------------------------------
# transcribe_bytes() — openai SDK path
# ---------------------------------------------------------------------------


def test_transcribe_bytes_via_openai_sdk(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
    import sys

    fake_openai = MagicMock()
    fake_client = MagicMock()
    fake_response = MagicMock()
    fake_response.text = "Hello world"
    fake_client.audio.transcriptions.create.return_value = fake_response
    fake_openai.OpenAI.return_value = fake_client

    with patch.dict(sys.modules, {"openai": fake_openai}):
        from owlmind.voice import transcribe_bytes

        result = transcribe_bytes(b"audio data", filename="voice.ogg")

    assert result == "Hello world"
    fake_client.audio.transcriptions.create.assert_called_once()


def test_transcribe_bytes_openai_sdk_with_language(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
    import sys

    fake_openai = MagicMock()
    fake_client = MagicMock()
    fake_response = MagicMock()
    fake_response.text = "Привет мир"
    fake_client.audio.transcriptions.create.return_value = fake_response
    fake_openai.OpenAI.return_value = fake_client

    with patch.dict(sys.modules, {"openai": fake_openai}):
        from owlmind.voice import transcribe_bytes

        result = transcribe_bytes(b"audio", filename="voice.ogg", language="ru")

    assert result == "Привет мир"
    call_kwargs = fake_client.audio.transcriptions.create.call_args[1]
    assert call_kwargs.get("language") == "ru" or "ru" in str(call_kwargs)


# ---------------------------------------------------------------------------
# _transcribe_openai_sdk() — SDK not available
# ---------------------------------------------------------------------------


def test_transcribe_openai_sdk_not_available() -> None:
    import sys

    with patch.dict(sys.modules, {"openai": None}):
        from owlmind.voice import _transcribe_openai_sdk

        result = _transcribe_openai_sdk(
            b"audio", "voice.ogg",
            model="whisper-1", language="", api_key="sk-test",
            base_url="https://api.openai.com",
        )
    assert result is None


# ---------------------------------------------------------------------------
# _transcribe_httpx() — success
# ---------------------------------------------------------------------------


def test_transcribe_httpx_success() -> None:
    import sys

    fake_httpx = MagicMock()
    fake_response = MagicMock()
    fake_response.json.return_value = {"text": "Test transcription"}
    fake_httpx.post.return_value = fake_response

    with patch.dict(sys.modules, {"httpx": fake_httpx}):
        from owlmind.voice import _transcribe_httpx

        result = _transcribe_httpx(
            b"audio bytes", "voice.ogg",
            model="whisper-1", language="",
            api_key="sk-test", base_url="https://api.openai.com",
        )

    assert result == "Test transcription"
    fake_httpx.post.assert_called_once()
    call_args = fake_httpx.post.call_args
    assert "/v1/audio/transcriptions" in call_args[0][0]


def test_transcribe_httpx_with_language() -> None:
    import sys

    fake_httpx = MagicMock()
    fake_response = MagicMock()
    fake_response.json.return_value = {"text": "Bonjour"}
    fake_httpx.post.return_value = fake_response

    with patch.dict(sys.modules, {"httpx": fake_httpx}):
        from owlmind.voice import _transcribe_httpx

        result = _transcribe_httpx(
            b"audio", "voice.mp3",
            model="whisper-1", language="fr",
            api_key="sk-test", base_url="https://api.openai.com",
        )

    assert result == "Bonjour"
    call_kwargs = fake_httpx.post.call_args[1]
    assert call_kwargs["data"]["language"] == "fr"


def test_transcribe_httpx_not_available() -> None:
    import sys

    with patch.dict(sys.modules, {"httpx": None}):
        from owlmind.voice import _transcribe_httpx

        with pytest.raises(RuntimeError, match="httpx not installed"):
            _transcribe_httpx(
                b"audio", "voice.ogg",
                model="whisper-1", language="",
                api_key="sk", base_url="https://api.openai.com",
            )


def test_transcribe_httpx_api_error() -> None:
    import sys

    fake_httpx = MagicMock()
    fake_httpx.post.side_effect = Exception("Connection refused")

    with patch.dict(sys.modules, {"httpx": fake_httpx}):
        from owlmind.voice import _transcribe_httpx

        with pytest.raises(RuntimeError, match="Whisper API error"):
            _transcribe_httpx(
                b"audio", "voice.ogg",
                model="whisper-1", language="",
                api_key="sk", base_url="https://api.openai.com",
            )


# ---------------------------------------------------------------------------
# transcribe_file()
# ---------------------------------------------------------------------------


def test_transcribe_file_unsupported_format(tmp_path: object) -> None:
    from pathlib import Path
    bad_file = Path(str(tmp_path)) / "audio.xyz"
    bad_file.write_bytes(b"data")

    from owlmind.voice import transcribe_file

    with pytest.raises(ValueError, match="Unsupported audio format"):
        transcribe_file(str(bad_file))


def test_transcribe_file_reads_and_delegates(tmp_path: object, monkeypatch: pytest.MonkeyPatch) -> None:
    from pathlib import Path
    ogg_file = Path(str(tmp_path)) / "voice.ogg"
    ogg_file.write_bytes(b"ogg data")

    monkeypatch.setenv("OPENAI_API_KEY", "sk-test")

    calls: list[tuple[bytes, str]] = []

    def fake_transcribe_bytes(data: bytes, filename: str = "audio.ogg", **kwargs: object) -> str:
        calls.append((data, filename))
        return "transcribed"

    with patch("owlmind.voice.transcribe_bytes", fake_transcribe_bytes):
        from owlmind.voice import transcribe_file

        result = transcribe_file(str(ogg_file))

    assert result == "transcribed"
    assert calls[0] == (b"ogg data", "voice.ogg")


# ---------------------------------------------------------------------------
# transcribe_telegram_voice() — tested via asyncio.run()
# ---------------------------------------------------------------------------


def test_transcribe_telegram_voice_success(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test")

    with patch("owlmind.voice.transcribe_bytes", return_value="voice text"):
        from owlmind.voice import transcribe_telegram_voice

        result = asyncio.run(transcribe_telegram_voice(b"ogg bytes"))

    assert result == "voice text"


def test_transcribe_telegram_voice_failure(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test")

    with patch("owlmind.voice.transcribe_bytes", side_effect=RuntimeError("API down")):
        from owlmind.voice import transcribe_telegram_voice

        result = asyncio.run(transcribe_telegram_voice(b"ogg bytes"))

    assert result == ""


# ---------------------------------------------------------------------------
# transcribe_telegram_voice_sync()
# ---------------------------------------------------------------------------


def test_transcribe_telegram_voice_sync_success(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test")

    with patch("owlmind.voice.transcribe_bytes", return_value="synced text"):
        from owlmind.voice import transcribe_telegram_voice_sync

        result = transcribe_telegram_voice_sync(b"ogg bytes")

    assert result == "synced text"


def test_transcribe_telegram_voice_sync_failure(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test")

    with patch("owlmind.voice.transcribe_bytes", side_effect=Exception("network error")):
        from owlmind.voice import transcribe_telegram_voice_sync

        result = transcribe_telegram_voice_sync(b"ogg bytes")

    assert result == ""


# ---------------------------------------------------------------------------
# Content-type mapping
# ---------------------------------------------------------------------------


def test_content_type_mapping_ogg() -> None:
    """Verify OGG files get correct content-type in httpx call."""
    import sys

    fake_httpx = MagicMock()
    fake_response = MagicMock()
    fake_response.json.return_value = {"text": "ok"}
    fake_httpx.post.return_value = fake_response

    with patch.dict(sys.modules, {"httpx": fake_httpx}):
        from owlmind.voice import _transcribe_httpx

        _transcribe_httpx(
            b"d", "voice.ogg",
            model="whisper-1", language="",
            api_key="sk", base_url="https://api.openai.com",
        )

    files_arg = fake_httpx.post.call_args[1]["files"]
    assert files_arg["file"][2] == "audio/ogg"


def test_content_type_mapping_mp3() -> None:
    import sys

    fake_httpx = MagicMock()
    fake_response = MagicMock()
    fake_response.json.return_value = {"text": "ok"}
    fake_httpx.post.return_value = fake_response

    with patch.dict(sys.modules, {"httpx": fake_httpx}):
        from owlmind.voice import _transcribe_httpx

        _transcribe_httpx(
            b"d", "audio.mp3",
            model="whisper-1", language="",
            api_key="sk", base_url="https://api.openai.com",
        )

    files_arg = fake_httpx.post.call_args[1]["files"]
    assert files_arg["file"][2] == "audio/mpeg"
