"""Integration tests for streaming endpoints (SSE and WebSocket).

Uses FastAPI TestClient (backed by httpx) to exercise the SSE endpoint
and WebSocket endpoints defined in owlmind.api.routes.streaming.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

try:
    from fastapi import FastAPI
    from fastapi.testclient import TestClient

    HAS_FASTAPI = True
except ImportError:
    HAS_FASTAPI = False

pytestmark = pytest.mark.skipif(not HAS_FASTAPI, reason="fastapi not installed")


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def runs_dir(tmp_path: Path) -> Path:
    d = tmp_path / "runs"
    d.mkdir()
    return d


@pytest.fixture
def app(runs_dir: Path) -> FastAPI:
    from owlmind.api.routes.streaming import make_streaming_router

    app = FastAPI()
    app.include_router(make_streaming_router(runs_dir))
    return app


@pytest.fixture
def client(app: FastAPI) -> TestClient:
    return TestClient(app)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _write_run_jsonl(runs_dir: Path, run_id: str, events: list[dict]) -> Path:
    """Create a runs/<run_id>/run.jsonl file with the given events."""
    run_dir = runs_dir / run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    jsonl_path = run_dir / "run.jsonl"
    lines = [json.dumps(evt) for evt in events]
    jsonl_path.write_text("\n".join(lines) + "\n")
    return jsonl_path


# ---------------------------------------------------------------------------
# Tests: SSE endpoint
# ---------------------------------------------------------------------------


class TestSSEEndpoint:
    def test_sse_returns_events_from_jsonl(
        self, runs_dir: Path, client: TestClient
    ) -> None:
        """GET /api/v1/runs/{run_id}/live should stream events from run.jsonl."""
        events = [
            {"step": 1, "action": "plan", "status": "ok"},
            {"step": 2, "action": "execute", "status": "ok"},
            {"step": 3, "action": "judge", "status": "done"},
        ]
        _write_run_jsonl(runs_dir, "run-001", events)

        # The SSE endpoint returns a streaming response.
        # TestClient buffers the entire response (it does not actually stream
        # indefinitely) because it runs synchronously.
        with client.stream("GET", "/api/v1/runs/run-001/live") as resp:
            assert resp.status_code == 200
            assert "text/event-stream" in resp.headers.get("content-type", "")

            # Read the first chunk of data lines
            collected: list[str] = []
            for line in resp.iter_lines():
                if line.startswith("data: "):
                    collected.append(line[len("data: "):])
                # Stop after collecting the initial events to avoid blocking
                if len(collected) >= 3:
                    break

        # Each collected line should be valid JSON with event_type "log"
        assert len(collected) >= 3
        for raw in collected[:3]:
            parsed = json.loads(raw)
            assert parsed["event_type"] == "log"
            assert "data" in parsed

    def test_sse_empty_run_returns_200(
        self, runs_dir: Path, client: TestClient
    ) -> None:
        """SSE endpoint for a run with no jsonl file should still return 200."""
        # Create an empty run directory (no run.jsonl)
        (runs_dir / "run-empty").mkdir()

        with client.stream("GET", "/api/v1/runs/run-empty/live") as resp:
            assert resp.status_code == 200

    def test_sse_nonexistent_run_returns_200(
        self, runs_dir: Path, client: TestClient
    ) -> None:
        """SSE endpoint for a run_id with no directory returns 200 (streams nothing)."""
        with client.stream("GET", "/api/v1/runs/no-such-run/live") as resp:
            assert resp.status_code == 200


# ---------------------------------------------------------------------------
# Tests: WebSocket endpoint
# ---------------------------------------------------------------------------


class TestWebSocketEndpoint:
    def test_ws_receives_initial_events(
        self, runs_dir: Path, app: FastAPI
    ) -> None:
        """WebSocket should send stored events on connect."""
        events = [
            {"step": i, "action": "test", "status": "ok"} for i in range(5)
        ]
        _write_run_jsonl(runs_dir, "run-ws-001", events)

        client = TestClient(app)
        with client.websocket_connect("/api/v1/ws/runs/run-ws-001") as ws:
            received: list[dict] = []
            # Read the initial batch of events
            for _ in range(5):
                msg = ws.receive_text()
                received.append(json.loads(msg))

            assert len(received) == 5
            for evt in received:
                assert evt["event_type"] == "log"
                assert "data" in evt

    def test_ws_empty_run_connects_ok(
        self, runs_dir: Path, app: FastAPI
    ) -> None:
        """WebSocket should accept connection even when run.jsonl is missing."""
        (runs_dir / "run-ws-empty").mkdir()

        client = TestClient(app)
        # Just verify the connection succeeds without error
        with client.websocket_connect("/api/v1/ws/runs/run-ws-empty"):
            # No initial events expected; close immediately
            pass

    def test_ws_events_contain_timestamp(
        self, runs_dir: Path, app: FastAPI
    ) -> None:
        """Each event sent via WebSocket should include a timestamp field."""
        events = [{"step": 1, "action": "plan"}]
        _write_run_jsonl(runs_dir, "run-ws-ts", events)

        client = TestClient(app)
        with client.websocket_connect("/api/v1/ws/runs/run-ws-ts") as ws:
            msg = ws.receive_text()
            parsed = json.loads(msg)
            assert "timestamp" in parsed


# ---------------------------------------------------------------------------
# Tests: StreamEvent model
# ---------------------------------------------------------------------------


class TestStreamEventModel:
    def test_stream_event_serialization(self) -> None:
        from owlmind.api.routes.streaming import StreamEvent

        evt = StreamEvent(
            event_type="log",
            data={"step": 1, "action": "plan"},
        )
        dumped = evt.model_dump()
        assert dumped["event_type"] == "log"
        assert dumped["data"]["step"] == 1
        assert "timestamp" in dumped

    def test_stream_event_json(self) -> None:
        from owlmind.api.routes.streaming import StreamEvent

        evt = StreamEvent(event_type="heartbeat", data={"run_id": "r1"})
        raw = evt.model_dump_json()
        parsed = json.loads(raw)
        assert parsed["event_type"] == "heartbeat"


class TestMakeStreamEvent:
    def test_make_stream_event_helper(self) -> None:
        from owlmind.api.routes.streaming import _make_stream_event

        raw = _make_stream_event("log", {"step": 42})
        parsed = json.loads(raw)
        assert parsed["event_type"] == "log"
        assert parsed["data"]["step"] == 42
        assert "timestamp" in parsed

    def test_make_stream_event_defaults(self) -> None:
        from owlmind.api.routes.streaming import _make_stream_event

        raw = _make_stream_event("heartbeat")
        parsed = json.loads(raw)
        assert parsed["event_type"] == "heartbeat"
        assert parsed["data"] == {}
