"""Tests for owlmind.telegram_bot — helper functions and event formatting."""

from __future__ import annotations

from unittest.mock import MagicMock

from owlmind.telegram_bot import (
    _format_event_message,
    _format_session_result,
    make_event_notifier,
    parse_session_resume_args,
    parse_session_start_args,
    parse_session_start_args_full,
    parse_workspace_from_args,
)

# ── _format_event_message — uncovered branches ──


class TestFormatEventMessage:
    def test_started_event(self) -> None:
        msg = _format_event_message("started", {"run_id": "r1", "goal": "fix bug"})
        assert "started" in msg
        assert "fix bug" in msg
        assert "r1" in msg

    def test_terminal_event(self) -> None:
        msg = _format_event_message("terminal", {"run_id": "r1", "state": "DONE"})
        assert "terminal" in msg
        assert "DONE" in msg

    def test_blocked_event(self) -> None:
        msg = _format_event_message("blocked", {"run_id": "r1", "state": "BLOCKED"})
        assert "blocked" in msg
        assert "BLOCKED" in msg

    def test_error_event(self) -> None:
        msg = _format_event_message("error", {"run_id": "r1", "error": "timeout"})
        assert "error" in msg
        assert "timeout" in msg

    def test_finished_event(self) -> None:
        msg = _format_event_message(
            "finished", {"run_id": "r1", "final_state": "DONE", "stop_reason": "complete"}
        )
        assert "finished" in msg
        assert "DONE" in msg
        assert "complete" in msg

    def test_worker_approval_needed(self) -> None:
        msg = _format_event_message(
            "worker_approval_needed", {"run_id": "r1", "message": "Approve?"}
        )
        assert "worker_approval_needed" in msg
        assert "Approve?" in msg

    def test_session_goal_starting(self) -> None:
        msg = _format_event_message("session_goal_starting", {"session_id": "s1", "goal_id": "g1"})
        assert "Goal starting" in msg
        assert "g1" in msg
        assert "s1" in msg

    def test_session_goal_done(self) -> None:
        msg = _format_event_message("session_goal_done", {"session_id": "s1", "goal_id": "g1"})
        assert "Goal done" in msg

    def test_session_started(self) -> None:
        msg = _format_event_message("session_started", {"session_id": "s1"})
        assert "Started" in msg
        assert "s1" in msg

    def test_session_done(self) -> None:
        msg = _format_event_message("session_done", {"session_id": "s1"})
        assert "Complete" in msg
        assert "s1" in msg

    def test_session_blocked(self) -> None:
        msg = _format_event_message("session_blocked", {"session_id": "s1", "reason": "deps"})
        assert "Blocked" in msg
        assert "deps" in msg

    def test_session_failed(self) -> None:
        msg = _format_event_message("session_failed", {"session_id": "s1", "reason": "error"})
        assert "Failed" in msg
        assert "error" in msg

    def test_unknown_event(self) -> None:
        msg = _format_event_message("custom_event", {"run_id": "r1"})
        assert "custom_event" in msg
        assert "r1" in msg

    def test_no_run_id(self) -> None:
        msg = _format_event_message("started", {"goal": "test"})
        assert "Run:" not in msg


# ── make_event_notifier ──


class TestMakeEventNotifier:
    def test_ignores_non_notable_event(self) -> None:
        bot_app = MagicMock()
        handler = make_event_notifier(bot_app, 123, {}, 60.0)
        handler("some_random_event", {})
        bot_app.bot.send_message.assert_not_called()

    def test_rate_limited(self) -> None:
        bot_app = MagicMock()
        last_event: dict[int, float] = {}
        handler = make_event_notifier(bot_app, 123, last_event, 9999.0)
        # First call goes through (or tries to — no loop)
        handler("started", {"run_id": "r1", "goal": "test"})
        # Second call should be rate limited
        handler("started", {"run_id": "r2", "goal": "test2"})

    def test_dedupe_same_event(self) -> None:
        bot_app = MagicMock()
        last_event: dict[int, float] = {}
        handler = make_event_notifier(bot_app, 123, last_event, 0.0)
        handler("started", {"run_id": "r1", "goal": "test"})
        # Same event+run_id should be deduped
        handler("started", {"run_id": "r1", "goal": "test"})


# ── _format_session_result ──


class TestFormatSessionResult:
    def test_basic(self) -> None:
        result = _format_session_result(
            {
                "status": "done",
                "session_id": "s1",
                "goals_done": 3,
                "goals_total": 5,
            }
        )
        assert "done" in result
        assert "3/5" in result

    def test_with_failed_blocked_skipped(self) -> None:
        result = _format_session_result(
            {
                "status": "partial",
                "session_id": "s1",
                "goals_done": 1,
                "goals_total": 5,
                "goals_failed": 2,
                "goals_blocked": 1,
                "goals_skipped": 1,
                "last_block_reason": "deps",
            }
        )
        assert "Failed: 2" in result
        assert "Blocked: 1" in result
        assert "Skipped: 1" in result
        assert "deps" in result

    def test_with_next_commands(self) -> None:
        result = _format_session_result(
            {
                "status": "done",
                "session_id": "s1",
                "goals_done": 0,
                "goals_total": 0,
                "next_commands": ["cmd1", "cmd2"],
            }
        )
        assert "cmd1" in result
        assert "cmd2" in result


# ── parse_workspace_from_args ──


class TestParseWorkspaceFromArgs:
    def test_default_workspace(self) -> None:
        workspace, remaining = parse_workspace_from_args(["goal", "text"], "/default")
        assert workspace == "/default"
        assert remaining == ["goal", "text"]

    def test_explicit_workspace(self) -> None:
        workspace, remaining = parse_workspace_from_args(
            ["--workspace", "/custom", "goal"],
            "/default",
        )
        assert workspace == "/custom"
        assert remaining == ["goal"]

    def test_workspace_at_end(self) -> None:
        workspace, remaining = parse_workspace_from_args(
            ["goal", "--workspace", "/custom"],
            "/default",
        )
        assert workspace == "/custom"
        assert remaining == ["goal"]


# ── parse_session_start_args_full ──


class TestParseSessionStartArgsFull:
    def test_basic(self) -> None:
        result = parse_session_start_args_full(["goals.yaml"], "/ws")
        assert result.goals_file == "goals.yaml"
        assert result.workspace == "/ws"

    def test_all_flags(self) -> None:
        result = parse_session_start_args_full(
            [
                "goals.yaml",
                "--workspace",
                "/custom",
                "--max-concurrency",
                "4",
                "--continue-on-fail",
                "--sandbox",
                "on",
                "--llm",
                "planner",
                "--worker",
                "claude_cli",
            ],
            "/default",
        )
        assert result.goals_file == "goals.yaml"
        assert result.workspace == "/custom"
        assert result.max_concurrency == 4
        assert result.continue_on_fail is True
        assert result.sandbox is True
        assert result.use_llm == "planner"
        assert result.use_worker == "claude_cli"

    def test_invalid_llm_ignored(self) -> None:
        result = parse_session_start_args_full(["goals.yaml", "--llm", "invalid"], "/ws")
        assert result.use_llm == "both"

    def test_invalid_worker_ignored(self) -> None:
        result = parse_session_start_args_full(["goals.yaml", "--worker", "invalid"], "/ws")
        assert result.use_worker == "none"

    def test_no_args(self) -> None:
        result = parse_session_start_args_full([], "/ws")
        assert result.goals_file == ""


# ── parse_session_start_args (backward compat) ──


class TestParseSessionStartArgs:
    def test_returns_4_tuple(self) -> None:
        gf, ws, mc, cof = parse_session_start_args(["g.yaml", "--max-concurrency", "3"], "/ws")
        assert gf == "g.yaml"
        assert ws == "/ws"
        assert mc == 3
        assert cof is False


# ── parse_session_resume_args ──


class TestParseSessionResumeArgs:
    def test_basic(self) -> None:
        sid, mc, cof = parse_session_resume_args(["sess-123"])
        assert sid == "sess-123"
        assert mc == 0
        assert cof is None

    def test_with_flags(self) -> None:
        sid, mc, cof = parse_session_resume_args(
            ["sess-123", "--max-concurrency", "2", "--continue-on-fail"],
        )
        assert sid == "sess-123"
        assert mc == 2
        assert cof is True


# ── create_operator_bot early return ──


class TestCreateOperatorBot:
    def test_returns_none_when_no_token(self) -> None:
        from owlmind.telegram_bot import create_operator_bot

        result = create_operator_bot(bot_token="")
        assert result is None

    def test_is_telegram_available(self) -> None:
        from owlmind.telegram_bot import is_telegram_available

        # Just verify it returns a bool
        assert isinstance(is_telegram_available(), bool)
