"""Tests for owlmind.graph.test_runner."""
from __future__ import annotations

import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

from owlmind.graph.test_runner import TestResult, detect_runner, run_tests

# ---------------------------------------------------------------------------
# detect_runner tests
# ---------------------------------------------------------------------------

def test_detect_runner_jest(tmp_path: Path) -> None:
    (tmp_path / "package.json").write_text("{}")
    assert detect_runner(str(tmp_path)) == "jest"


def test_detect_runner_cargo(tmp_path: Path) -> None:
    (tmp_path / "Cargo.toml").write_text("[package]")
    assert detect_runner(str(tmp_path)) == "cargo"


def test_detect_runner_go(tmp_path: Path) -> None:
    (tmp_path / "go.mod").write_text("module example.com/m")
    assert detect_runner(str(tmp_path)) == "go"


def test_detect_runner_maven_pom(tmp_path: Path) -> None:
    (tmp_path / "pom.xml").write_text("<project/>")
    assert detect_runner(str(tmp_path)) == "maven"


def test_detect_runner_maven_gradle(tmp_path: Path) -> None:
    (tmp_path / "build.gradle").write_text("// gradle")
    assert detect_runner(str(tmp_path)) == "maven"


def test_detect_runner_default_pytest(tmp_path: Path) -> None:
    # No indicator files — should default to pytest
    assert detect_runner(str(tmp_path)) == "pytest"


def test_detect_runner_jest_takes_precedence_over_default(tmp_path: Path) -> None:
    # package.json beats the default
    (tmp_path / "package.json").write_text("{}")
    result = detect_runner(str(tmp_path))
    assert result == "jest"


# ---------------------------------------------------------------------------
# run_tests tests
# ---------------------------------------------------------------------------

def test_run_tests_returns_test_result(tmp_path: Path) -> None:
    """run_tests must always return a TestResult instance."""
    with patch("owlmind.graph.test_runner.subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0, stdout="1 passed", stderr="")
        result = run_tests(str(tmp_path), runner="pytest")
    assert isinstance(result, TestResult)
    assert result.runner == "pytest"
    assert result.exit_code == 0
    assert result.success is True


def test_run_tests_non_zero_exit_code(tmp_path: Path) -> None:
    with patch("owlmind.graph.test_runner.subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=1, stdout="", stderr="1 failed")
        result = run_tests(str(tmp_path), runner="pytest")
    assert result.exit_code == 1
    assert result.success is False


def test_run_tests_handles_timeout(tmp_path: Path) -> None:
    with patch("owlmind.graph.test_runner.subprocess.run", side_effect=subprocess.TimeoutExpired(cmd="pytest", timeout=1)):
        result = run_tests(str(tmp_path), runner="pytest", timeout=1)
    assert result.exit_code == 1
    assert "timeout" in result.stderr.lower()
    assert result.success is False


def test_run_tests_handles_file_not_found(tmp_path: Path) -> None:
    with patch("owlmind.graph.test_runner.subprocess.run", side_effect=FileNotFoundError("no such file")):
        result = run_tests(str(tmp_path), runner="cargo")
    assert result.exit_code == 1
    assert result.success is False
    assert "cargo" in result.stderr


def test_run_tests_auto_detects_runner(tmp_path: Path) -> None:
    """When runner=None, detect_runner is called automatically."""
    (tmp_path / "go.mod").write_text("module m")
    with patch("owlmind.graph.test_runner.subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0, stdout="ok", stderr="")
        result = run_tests(str(tmp_path))  # no runner specified
    assert result.runner == "go"


def test_run_tests_unknown_runner_falls_back_to_pytest(tmp_path: Path) -> None:
    """An unrecognised runner key falls back to the pytest command."""
    with patch("owlmind.graph.test_runner.subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
        result = run_tests(str(tmp_path), runner="unknown_runner")
    # The call should still succeed (subprocess didn't raise)
    assert result.runner == "unknown_runner"
    assert result.exit_code == 0
