"""Tests for GET /api/v1/skills/packs and GET /api/v1/skills/packs/{id}."""

from __future__ import annotations

from pathlib import Path

import pytest
import yaml
from starlette.testclient import TestClient

from owlmind.api.app import create_app

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def tmp_dirs(tmp_path: Path) -> dict[str, Path]:
    dirs = {
        "runs": tmp_path / "runs",
        "ledger": tmp_path / "ledger",
        "queue": tmp_path / "queue",
        "policies": tmp_path / "policies",
        "packs": tmp_path / "skill-packs",
    }
    for d in dirs.values():
        d.mkdir(parents=True, exist_ok=True)
    return dirs


@pytest.fixture()
def client(tmp_dirs: dict[str, Path]) -> TestClient:
    app = create_app(
        runs_dir=tmp_dirs["runs"],
        ledger_dir=tmp_dirs["ledger"],
        queue_path=tmp_dirs["queue"],
        policies_dir=tmp_dirs["policies"],
        packs_dir=tmp_dirs["packs"],
    )
    return TestClient(app)


@pytest.fixture(autouse=True)
def _no_auth(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("owlmind.api.auth.verify_api_key", lambda: None)


def _make_pack(packs_dir: Path, pack_id: str, name: str = "", tags: list | None = None) -> Path:
    """Create a minimal skill pack directory."""
    pack_dir = packs_dir / pack_id
    pack_dir.mkdir(parents=True, exist_ok=True)
    (pack_dir / "pack.yaml").write_text(
        yaml.dump(
            {
                "id": pack_id,
                "name": name or pack_id.replace("_", " ").title(),
                "version": "1.0.0",
                "description": f"Test pack for {pack_id}",
                "tags": tags or ["test"],
            }
        )
    )
    # Add a workflow
    workflows_dir = pack_dir / "workflows"
    workflows_dir.mkdir()
    (workflows_dir / "main.yaml").write_text("id: main\nsteps: []")
    # Add a system prompt
    prompts_dir = pack_dir / "prompts"
    prompts_dir.mkdir()
    (prompts_dir / "system_prompt.md").write_text(f"# {name or pack_id}\nYou are a test assistant.")
    return pack_dir


# ===========================================================================
# GET /api/v1/skills/packs
# ===========================================================================


class TestListSkillPacks:
    def test_empty_packs_dir_returns_empty_list(self, client: TestClient) -> None:
        resp = client.get("/api/v1/skills/packs")
        assert resp.status_code == 200
        assert resp.json() == []

    def test_returns_list_of_packs(self, client: TestClient, tmp_dirs: dict[str, Path]) -> None:
        _make_pack(tmp_dirs["packs"], "code_review")
        _make_pack(tmp_dirs["packs"], "test_writer")
        resp = client.get("/api/v1/skills/packs")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 2

    def test_pack_has_required_fields(self, client: TestClient, tmp_dirs: dict[str, Path]) -> None:
        _make_pack(tmp_dirs["packs"], "my_pack", name="My Pack", tags=["python"])
        resp = client.get("/api/v1/skills/packs")
        assert resp.status_code == 200
        pack = resp.json()[0]
        assert pack["id"] == "my_pack"
        assert pack["name"] == "My Pack"
        assert pack["version"] == "1.0.0"
        assert isinstance(pack["description"], str)
        assert isinstance(pack["tags"], list)
        assert "python" in pack["tags"]

    def test_does_not_include_pack_dir_path(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        _make_pack(tmp_dirs["packs"], "my_pack")
        resp = client.get("/api/v1/skills/packs")
        pack = resp.json()[0]
        assert "pack_dir" not in pack

    def test_returns_sorted_by_name(self, client: TestClient, tmp_dirs: dict[str, Path]) -> None:
        _make_pack(tmp_dirs["packs"], "z_pack")
        _make_pack(tmp_dirs["packs"], "a_pack")
        resp = client.get("/api/v1/skills/packs")
        ids = [p["id"] for p in resp.json()]
        assert ids == sorted(ids)


# ===========================================================================
# GET /api/v1/skills/packs/{pack_id}
# ===========================================================================


class TestGetSkillPack:
    def test_returns_pack_metadata(self, client: TestClient, tmp_dirs: dict[str, Path]) -> None:
        _make_pack(tmp_dirs["packs"], "code_review", name="Code Review", tags=["quality"])
        resp = client.get("/api/v1/skills/packs/code_review")
        assert resp.status_code == 200
        data = resp.json()
        assert data["id"] == "code_review"
        assert data["name"] == "Code Review"
        assert "quality" in data["tags"]

    def test_returns_context_string(self, client: TestClient, tmp_dirs: dict[str, Path]) -> None:
        _make_pack(tmp_dirs["packs"], "code_review")
        resp = client.get("/api/v1/skills/packs/code_review")
        assert resp.status_code == 200
        assert isinstance(resp.json()["context"], str)
        assert len(resp.json()["context"]) > 0

    def test_context_contains_pack_name(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        _make_pack(tmp_dirs["packs"], "my_pack", name="My Special Pack")
        resp = client.get("/api/v1/skills/packs/my_pack")
        assert "My Special Pack" in resp.json()["context"]

    def test_returns_404_for_unknown_pack(self, client: TestClient) -> None:
        resp = client.get("/api/v1/skills/packs/nonexistent_pack")
        assert resp.status_code == 404

    def test_has_workflows_and_knowledge_fields(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        _make_pack(tmp_dirs["packs"], "my_pack")
        resp = client.get("/api/v1/skills/packs/my_pack")
        data = resp.json()
        assert "workflows" in data
        assert "knowledge_files" in data

    def test_context_contains_system_prompt(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        pack_dir = _make_pack(tmp_dirs["packs"], "my_pack")
        (pack_dir / "prompts" / "system_prompt.md").write_text("You are a code reviewer.")
        resp = client.get("/api/v1/skills/packs/my_pack")
        assert "code reviewer" in resp.json()["context"]


# ===========================================================================
# 500 error paths — exceptions in registry raise HTTP 500
# ===========================================================================


class TestListSkillPacksError:
    def test_list_packs_exception_returns_500(self, client: TestClient) -> None:
        """GET /skills/packs → list_packs raises → 500."""
        from unittest.mock import patch

        with patch(
            "owlmind.skills.registry.list_packs",
            side_effect=RuntimeError("registry exploded"),
        ):
            resp = client.get("/api/v1/skills/packs")

        assert resp.status_code == 500
        assert "skill" in resp.json()["detail"].lower() or "registry" in resp.json()["detail"]


class TestGetSkillPackError:
    def test_load_pack_generic_exception_returns_500(self, client: TestClient) -> None:
        """GET /skills/packs/{id} → load_pack raises generic error → 500."""
        from unittest.mock import patch

        with patch(
            "owlmind.skills.registry.load_pack",
            side_effect=RuntimeError("yaml parse error"),
        ):
            resp = client.get("/api/v1/skills/packs/bad_pack")

        assert resp.status_code == 500
        assert "skill" in resp.json()["detail"].lower() or "yaml" in resp.json()["detail"]

    def test_load_pack_not_found_returns_404(self, client: TestClient) -> None:
        """GET /skills/packs/{id} → load_pack raises FileNotFoundError → 404."""
        from unittest.mock import patch

        with patch(
            "owlmind.skills.registry.load_pack",
            side_effect=FileNotFoundError("no such pack"),
        ):
            resp = client.get("/api/v1/skills/packs/missing_pack")

        assert resp.status_code == 404
        assert "missing_pack" in resp.json()["detail"]
