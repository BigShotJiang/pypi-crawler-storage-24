"""Tests for push notification token registration and sending."""

from __future__ import annotations

from pathlib import Path
from typing import Any
from unittest.mock import patch

import pytest
from starlette.testclient import TestClient

from owlmind.api.routes.push import PushTokenStore, send_push_notifications


@pytest.fixture()
def store(tmp_path: Path) -> PushTokenStore:
    """Create a push token store with a temporary database."""
    return PushTokenStore(tmp_path / "push.db")


@pytest.fixture()
def app_with_push(tmp_path: Path):
    """Create a FastAPI app with push endpoints enabled."""
    from owlmind.api.app import create_app

    app = create_app(
        runs_dir=tmp_path / "runs",
        ledger_dir=tmp_path / "ledger",
        queue_path=tmp_path / "queue",
        policies_dir=tmp_path / "policies",
        push_db=tmp_path / "push.db",
    )
    return TestClient(app)


@pytest.fixture()
def app_without_push(tmp_path: Path):
    """Create a FastAPI app without push endpoints."""
    from owlmind.api.app import create_app

    app = create_app(
        runs_dir=tmp_path / "runs",
        ledger_dir=tmp_path / "ledger",
        queue_path=tmp_path / "queue",
        policies_dir=tmp_path / "policies",
        push_db=None,
    )
    return TestClient(app)


# ---------------------------------------------------------------------------
# PushTokenStore unit tests
# ---------------------------------------------------------------------------


class TestPushTokenStore:
    """Tests for the SQLite push token storage."""

    def test_register_token(self, store: PushTokenStore) -> None:
        """Register a new push token."""
        result = store.register_token("ExponentPushToken[xxx]", "ios")
        assert result["token"] == "ExponentPushToken[xxx]"
        assert result["platform"] == "ios"
        assert "id" in result
        assert "created_at" in result

    def test_register_same_token_updates(self, store: PushTokenStore) -> None:
        """Re-registering the same token updates it instead of duplicating."""
        store.register_token("ExponentPushToken[xxx]", "ios")
        result = store.register_token("ExponentPushToken[xxx]", "android")
        assert result["platform"] == "android"
        tokens = store.list_tokens()
        assert len(tokens) == 1

    def test_list_tokens(self, store: PushTokenStore) -> None:
        """List all registered tokens."""
        store.register_token("token-1", "ios")
        store.register_token("token-2", "android")
        tokens = store.list_tokens()
        assert len(tokens) == 2

    def test_list_tokens_empty(self, store: PushTokenStore) -> None:
        """Empty store returns empty list."""
        assert store.list_tokens() == []

    def test_remove_token(self, store: PushTokenStore) -> None:
        """Remove a registered token."""
        store.register_token("token-to-remove", "ios")
        assert store.remove_token("token-to-remove") is True
        assert store.list_tokens() == []

    def test_remove_nonexistent_token(self, store: PushTokenStore) -> None:
        """Removing a nonexistent token returns False."""
        assert store.remove_token("nonexistent") is False

    def test_register_with_label(self, store: PushTokenStore) -> None:
        """Register a token with user label."""
        result = store.register_token("token-labeled", "ios", "user123")
        assert result["user_label"] == "user123"


# ---------------------------------------------------------------------------
# API endpoint tests
# ---------------------------------------------------------------------------


class TestPushAPI:
    """Tests for push notification API endpoints."""

    def test_register_token(self, app_with_push: TestClient) -> None:
        """POST /push-token registers a token."""
        resp = app_with_push.post(
            "/api/v1/push-token",
            json={"token": "ExponentPushToken[test123]", "platform": "ios"},
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["status"] == "registered"
        assert data["token"] == "ExponentPushToken[test123]"

    def test_register_token_default_platform(self, app_with_push: TestClient) -> None:
        """POST /push-token accepts unknown platform."""
        resp = app_with_push.post(
            "/api/v1/push-token",
            json={"token": "ExponentPushToken[test456]"},
        )
        assert resp.status_code == 201
        assert resp.json()["platform"] == "unknown"

    def test_register_empty_token_fails(self, app_with_push: TestClient) -> None:
        """POST /push-token rejects empty token."""
        resp = app_with_push.post(
            "/api/v1/push-token",
            json={"token": "", "platform": "ios"},
        )
        assert resp.status_code == 422

    def test_list_tokens(self, app_with_push: TestClient) -> None:
        """GET /push-tokens lists registered tokens."""
        app_with_push.post(
            "/api/v1/push-token",
            json={"token": "token-a", "platform": "ios"},
        )
        app_with_push.post(
            "/api/v1/push-token",
            json={"token": "token-b", "platform": "android"},
        )
        resp = app_with_push.get("/api/v1/push-tokens")
        assert resp.status_code == 200
        assert len(resp.json()) == 2

    def test_delete_token(self, app_with_push: TestClient) -> None:
        """DELETE /push-token/{token} removes a token."""
        app_with_push.post(
            "/api/v1/push-token",
            json={"token": "token-to-delete", "platform": "ios"},
        )
        resp = app_with_push.delete("/api/v1/push-token/token-to-delete")
        assert resp.status_code == 200
        assert resp.json()["status"] == "removed"

    def test_delete_nonexistent_token(self, app_with_push: TestClient) -> None:
        """DELETE /push-token/{token} returns 404 for unknown token."""
        resp = app_with_push.delete("/api/v1/push-token/nonexistent")
        assert resp.status_code == 404

    def test_idempotent_register(self, app_with_push: TestClient) -> None:
        """Registering the same token twice is idempotent."""
        app_with_push.post(
            "/api/v1/push-token",
            json={"token": "same-token", "platform": "ios"},
        )
        resp = app_with_push.post(
            "/api/v1/push-token",
            json={"token": "same-token", "platform": "android"},
        )
        assert resp.status_code == 201

        tokens = app_with_push.get("/api/v1/push-tokens").json()
        assert len(tokens) == 1
        assert tokens[0]["platform"] == "android"


class TestPushDisabled:
    """Tests that the app works when push is disabled."""

    def test_health_works(self, app_without_push: TestClient) -> None:
        """Health endpoint works without push."""
        resp = app_without_push.get("/health")
        assert resp.status_code == 200


# ---------------------------------------------------------------------------
# send_push_notifications tests
# ---------------------------------------------------------------------------


class TestSendPushNotifications:
    """Tests for the push notification sender."""

    def test_empty_tokens(self) -> None:
        """No tokens means no notifications sent."""
        result = send_push_notifications([], "Title", "Body")
        assert result == []

    @patch("owlmind.api.routes.push.urllib.request.urlopen")
    def test_sends_to_expo(self, mock_urlopen: Any) -> None:
        """Send notifications via Expo Push API."""
        import io
        import json

        mock_response = io.BytesIO(json.dumps({"data": [{"status": "ok"}]}).encode())
        mock_response.read = mock_response.read  # type: ignore[assignment]
        mock_urlopen.return_value.__enter__ = lambda s: mock_response
        mock_urlopen.return_value.__exit__ = lambda s, *a: None

        result = send_push_notifications(
            tokens=["ExponentPushToken[xxx]"],
            title="Test",
            body="Hello",
        )
        assert len(result) == 1
        assert result[0]["status"] == "ok"

    @patch("owlmind.api.routes.push.urllib.request.urlopen", side_effect=Exception("Network error"))
    def test_handles_error(self, mock_urlopen: Any) -> None:
        """Network errors are handled gracefully."""
        result = send_push_notifications(
            tokens=["ExponentPushToken[xxx]"],
            title="Test",
            body="Hello",
        )
        assert result == []


# ---------------------------------------------------------------------------
# notify_session_complete tests
# ---------------------------------------------------------------------------


class TestNotifySessionComplete:
    """Tests for session completion notifications."""

    def test_no_tokens_returns_zero(self, store: PushTokenStore) -> None:
        """No registered tokens means 0 notifications."""
        from owlmind.api.routes.push import notify_session_complete

        count = notify_session_complete(store, "session-123", "DONE")
        assert count == 0

    @patch("owlmind.api.routes.push.send_push_notifications")
    def test_sends_to_all_tokens(self, mock_send: Any, store: PushTokenStore) -> None:
        """Sends notifications to all registered tokens."""
        from owlmind.api.routes.push import notify_session_complete

        store.register_token("token-a", "ios")
        store.register_token("token-b", "android")
        mock_send.return_value = [{"status": "ok"}, {"status": "ok"}]

        count = notify_session_complete(store, "session-456", "DONE")
        assert count == 2
        mock_send.assert_called_once()
        call_args = mock_send.call_args
        assert len(call_args[1]["tokens"]) == 2
        assert "session-456" in call_args[1]["body"]
