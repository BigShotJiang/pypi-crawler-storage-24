"""Tests for private registry authentication, RBAC, and user management."""

from __future__ import annotations

import asyncio
import io
import json
import zipfile
from pathlib import Path
from typing import Any

import pytest
from fastapi import FastAPI
from starlette.testclient import TestClient

from owlmind.api.registry_auth import hash_api_key
from owlmind.api.routes.registry import make_registry_router
from owlmind.registry.models import PublishRequest
from owlmind.registry.public import SQLitePublicPackRegistry

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _run(coro):
    """Run an async coroutine synchronously."""
    return asyncio.run(coro)


def _make_zip(manifest: dict[str, Any]) -> bytes:
    """Create a minimal ZIP with manifest.json."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        zf.writestr("manifest.json", json.dumps(manifest))
    return buf.getvalue()


@pytest.fixture()
def registry(tmp_path: Path) -> SQLitePublicPackRegistry:
    """Fresh registry for each test."""
    return SQLitePublicPackRegistry(tmp_path / "test.db")


@pytest.fixture()
def app_setup(tmp_path: Path):
    """Create test app with registry router and pre-seeded users."""
    db_path = tmp_path / "test.db"
    archive_dir = tmp_path / "archives"

    app = FastAPI()
    router = make_registry_router(registry_db=db_path, archive_dir=archive_dir)
    app.include_router(router)

    client = TestClient(app)
    reg = SQLitePublicPackRegistry(db_path)

    # Create admin and regular user
    admin_key = "cwrk_test_admin_key_123"
    user_key = "cwrk_test_user_key_456"

    admin = _run(
        reg.create_user(
            username="admin",
            email="admin@test.com",
            role="admin",
            api_key_hash=hash_api_key(admin_key),
        )
    )
    user = _run(
        reg.create_user(
            username="developer",
            email="dev@test.com",
            role="user",
            api_key_hash=hash_api_key(user_key),
        )
    )

    class Setup:
        pass

    s = Setup()
    s.client = client  # type: ignore[attr-defined]
    s.registry = reg  # type: ignore[attr-defined]
    s.admin_key = admin_key  # type: ignore[attr-defined]
    s.user_key = user_key  # type: ignore[attr-defined]
    s.admin = admin  # type: ignore[attr-defined]
    s.user = user  # type: ignore[attr-defined]
    s.archive_dir = archive_dir  # type: ignore[attr-defined]
    return s


def _admin_headers(setup) -> dict[str, str]:
    return {"X-Registry-Token": setup.admin_key}


def _user_headers(setup) -> dict[str, str]:
    return {"X-Registry-Token": setup.user_key}


def _publish_and_approve(setup, pack_id: str = "test-pack", name: str = "Test Pack") -> None:
    """Publish and approve a pack via direct DB calls."""
    req = PublishRequest(name=name, version="1.0.0", tags=["python"], author_name="tester")
    _run(setup.registry.publish_pack(pack_id, req))
    _run(setup.registry.approve_pack(pack_id))


# ---------------------------------------------------------------------------
# hash_api_key unit tests
# ---------------------------------------------------------------------------


class TestHashApiKey:
    def test_deterministic(self) -> None:
        """Same key always produces same hash."""
        h1 = hash_api_key("cwrk_test123")
        h2 = hash_api_key("cwrk_test123")
        assert h1 == h2

    def test_different_keys(self) -> None:
        """Different keys produce different hashes."""
        h1 = hash_api_key("cwrk_key1")
        h2 = hash_api_key("cwrk_key2")
        assert h1 != h2

    def test_returns_hex_string(self) -> None:
        """Hash is a 64-char hex string (SHA256)."""
        h = hash_api_key("cwrk_test")
        assert len(h) == 64
        assert all(c in "0123456789abcdef" for c in h)


# ---------------------------------------------------------------------------
# User storage tests
# ---------------------------------------------------------------------------


class TestUserStorage:
    def test_create_user(self, registry: SQLitePublicPackRegistry) -> None:
        """Creating a user stores correct fields."""
        user = _run(
            registry.create_user(
                username="alice",
                email="alice@example.com",
                role="user",
                api_key_hash="hash123",
            )
        )
        assert user["username"] == "alice"
        assert user["email"] == "alice@example.com"
        assert user["role"] == "user"
        assert user["is_active"] is True
        assert user["user_id"].startswith("usr-")

    def test_create_user_unique_username(self, registry: SQLitePublicPackRegistry) -> None:
        """Duplicate username raises an error."""
        _run(registry.create_user("alice", "", "user", "hash1"))
        with pytest.raises(Exception, match="UNIQUE"):
            _run(registry.create_user("alice", "", "user", "hash2"))

    def test_create_user_unique_key_hash(self, registry: SQLitePublicPackRegistry) -> None:
        """Duplicate api_key_hash raises an error."""
        _run(registry.create_user("alice", "", "user", "samehash"))
        with pytest.raises(Exception, match="UNIQUE"):
            _run(registry.create_user("bob", "", "user", "samehash"))

    def test_get_user_by_key_hash_found(self, registry: SQLitePublicPackRegistry) -> None:
        """Lookup by key hash returns user."""
        _run(registry.create_user("alice", "", "user", "myhash"))
        user = _run(registry.get_user_by_key_hash("myhash"))
        assert user is not None
        assert user["username"] == "alice"

    def test_get_user_by_key_hash_not_found(self, registry: SQLitePublicPackRegistry) -> None:
        """Lookup with unknown hash returns None."""
        assert _run(registry.get_user_by_key_hash("nope")) is None

    def test_get_user_by_id(self, registry: SQLitePublicPackRegistry) -> None:
        """Get user by user_id."""
        user = _run(registry.create_user("alice", "", "user", "hash1"))
        found = _run(registry.get_user(user["user_id"]))
        assert found is not None
        assert found["username"] == "alice"

    def test_list_users_empty(self, registry: SQLitePublicPackRegistry) -> None:
        """Empty registry has no users."""
        assert _run(registry.list_users()) == []

    def test_list_users_excludes_inactive(self, registry: SQLitePublicPackRegistry) -> None:
        """Default listing excludes deactivated users."""
        user = _run(registry.create_user("alice", "", "user", "hash1"))
        _run(registry.create_user("bob", "", "user", "hash2"))
        _run(registry.deactivate_user(user["user_id"]))

        active = _run(registry.list_users())
        assert len(active) == 1
        assert active[0]["username"] == "bob"

    def test_list_users_includes_inactive(self, registry: SQLitePublicPackRegistry) -> None:
        """include_inactive=True shows all users."""
        user = _run(registry.create_user("alice", "", "user", "hash1"))
        _run(registry.create_user("bob", "", "user", "hash2"))
        _run(registry.deactivate_user(user["user_id"]))

        all_users = _run(registry.list_users(include_inactive=True))
        assert len(all_users) == 2

    def test_deactivate_user(self, registry: SQLitePublicPackRegistry) -> None:
        """Deactivating sets is_active to False."""
        user = _run(registry.create_user("alice", "", "user", "hash1"))
        assert _run(registry.deactivate_user(user["user_id"])) is True

        found = _run(registry.get_user(user["user_id"]))
        assert found is not None
        assert found["is_active"] is False

    def test_deactivate_nonexistent(self, registry: SQLitePublicPackRegistry) -> None:
        """Deactivating unknown user returns False."""
        assert _run(registry.deactivate_user("usr-missing")) is False

    def test_user_dict_no_hash(self, registry: SQLitePublicPackRegistry) -> None:
        """User dict does not expose api_key_hash."""
        user = _run(registry.create_user("alice", "", "user", "secret_hash"))
        assert "api_key_hash" not in user


# ---------------------------------------------------------------------------
# API auth enforcement — unauthenticated requests
# ---------------------------------------------------------------------------


class TestAuthEnforcement:
    def test_get_packs_is_public(self, app_setup) -> None:
        """GET /packs without token returns 200 (public read-only endpoint)."""
        resp = app_setup.client.get("/api/v1/registry/packs")
        assert resp.status_code == 200

    def test_get_pack_requires_auth(self, app_setup) -> None:
        """GET /packs/{id} without token returns 401."""
        resp = app_setup.client.get("/api/v1/registry/packs/test-pack")
        assert resp.status_code == 401

    def test_get_versions_requires_auth(self, app_setup) -> None:
        """GET /packs/{id}/versions without token returns 401."""
        resp = app_setup.client.get("/api/v1/registry/packs/test-pack/versions")
        assert resp.status_code == 401

    def test_download_requires_auth(self, app_setup) -> None:
        """GET /download without token returns 401."""
        resp = app_setup.client.get("/api/v1/registry/packs/test-pack/download/1.0.0")
        assert resp.status_code == 401

    def test_get_reviews_requires_auth(self, app_setup) -> None:
        """GET /reviews without token returns 401."""
        resp = app_setup.client.get("/api/v1/registry/packs/test-pack/reviews")
        assert resp.status_code == 401

    def test_publish_requires_auth(self, app_setup) -> None:
        """POST /packs without token returns 401."""
        manifest = {"id": "x", "name": "X", "version": "1.0.0"}
        resp = app_setup.client.post(
            "/api/v1/registry/packs",
            files={"archive": ("p.zip", _make_zip(manifest), "application/zip")},
            data={"tags": "[]"},
        )
        assert resp.status_code == 401

    def test_add_review_requires_auth(self, app_setup) -> None:
        """POST /reviews without token returns 401."""
        resp = app_setup.client.post(
            "/api/v1/registry/packs/test-pack/reviews",
            json={"rating": 5, "author_name": "x"},
        )
        assert resp.status_code == 401

    def test_invalid_token_returns_401(self, app_setup) -> None:
        """Invalid token returns 401 on protected endpoints."""
        resp = app_setup.client.get(
            "/api/v1/registry/packs/nonexistent-pack",
            headers={"X-Registry-Token": "cwrk_invalid_bogus_key"},
        )
        assert resp.status_code == 401

    def test_deactivated_user_returns_403(self, app_setup) -> None:
        """Deactivated user gets 403 on protected endpoints."""
        _run(app_setup.registry.deactivate_user(app_setup.user["user_id"]))
        resp = app_setup.client.get(
            "/api/v1/registry/packs/nonexistent-pack",
            headers=_user_headers(app_setup),
        )
        assert resp.status_code == 403


# ---------------------------------------------------------------------------
# Role-based access
# ---------------------------------------------------------------------------


class TestRBAC:
    def test_user_can_browse(self, app_setup) -> None:
        """Regular user can browse packs."""
        resp = app_setup.client.get(
            "/api/v1/registry/packs",
            headers=_user_headers(app_setup),
        )
        assert resp.status_code == 200

    def test_user_can_publish(self, app_setup) -> None:
        """Regular user can publish packs."""
        manifest = {"id": "my-pack", "name": "My Pack", "version": "1.0.0"}
        resp = app_setup.client.post(
            "/api/v1/registry/packs",
            files={"archive": ("p.zip", _make_zip(manifest), "application/zip")},
            data={"tags": "[]"},
            headers=_user_headers(app_setup),
        )
        assert resp.status_code == 201

    def test_user_can_add_review(self, app_setup) -> None:
        """Regular user can add reviews."""
        _publish_and_approve(app_setup, "pk-1")
        resp = app_setup.client.post(
            "/api/v1/registry/packs/pk-1/reviews",
            json={"rating": 4, "author_name": "dev", "comment": "Nice"},
            headers=_user_headers(app_setup),
        )
        assert resp.status_code == 201

    def test_user_cannot_approve(self, app_setup) -> None:
        """Regular user cannot approve packs (403)."""
        _publish_and_approve(app_setup, "pk-1")
        resp = app_setup.client.post(
            "/api/v1/registry/admin/approve/pk-1",
            headers=_user_headers(app_setup),
        )
        assert resp.status_code == 403

    def test_user_cannot_reject(self, app_setup) -> None:
        """Regular user cannot reject packs (403)."""
        _publish_and_approve(app_setup, "pk-1")
        resp = app_setup.client.post(
            "/api/v1/registry/admin/reject/pk-1",
            headers=_user_headers(app_setup),
        )
        assert resp.status_code == 403

    def test_user_cannot_create_users(self, app_setup) -> None:
        """Regular user cannot create users (403)."""
        resp = app_setup.client.post(
            "/api/v1/registry/admin/users",
            json={"username": "newguy"},
            headers=_user_headers(app_setup),
        )
        assert resp.status_code == 403

    def test_user_cannot_list_users(self, app_setup) -> None:
        """Regular user cannot list users (403)."""
        resp = app_setup.client.get(
            "/api/v1/registry/admin/users",
            headers=_user_headers(app_setup),
        )
        assert resp.status_code == 403

    def test_user_cannot_deactivate(self, app_setup) -> None:
        """Regular user cannot deactivate users (403)."""
        resp = app_setup.client.post(
            "/api/v1/registry/admin/users/usr-xxx/deactivate",
            headers=_user_headers(app_setup),
        )
        assert resp.status_code == 403

    def test_admin_can_approve(self, app_setup) -> None:
        """Admin can approve packs."""
        req = PublishRequest(name="Pack", version="1.0.0", author_name="x")
        _run(app_setup.registry.publish_pack("pk-1", req))

        resp = app_setup.client.post(
            "/api/v1/registry/admin/approve/pk-1",
            headers=_admin_headers(app_setup),
        )
        assert resp.status_code == 200
        assert resp.json()["status"] == "approved"

    def test_admin_can_reject(self, app_setup) -> None:
        """Admin can reject packs."""
        req = PublishRequest(name="Pack", version="1.0.0", author_name="x")
        _run(app_setup.registry.publish_pack("pk-1", req))

        resp = app_setup.client.post(
            "/api/v1/registry/admin/reject/pk-1",
            headers=_admin_headers(app_setup),
        )
        assert resp.status_code == 200
        assert resp.json()["status"] == "rejected"


# ---------------------------------------------------------------------------
# Admin user management endpoints
# ---------------------------------------------------------------------------


class TestAdminUserManagement:
    def test_create_user_returns_api_key(self, app_setup) -> None:
        """Creating user returns API key starting with cwrk_."""
        resp = app_setup.client.post(
            "/api/v1/registry/admin/users",
            json={"username": "newdev", "email": "new@test.com"},
            headers=_admin_headers(app_setup),
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["api_key"].startswith("cwrk_")
        assert data["user"]["username"] == "newdev"
        assert data["user"]["role"] == "user"

    def test_created_key_works(self, app_setup) -> None:
        """The returned API key can authenticate subsequent requests."""
        resp = app_setup.client.post(
            "/api/v1/registry/admin/users",
            json={"username": "newdev"},
            headers=_admin_headers(app_setup),
        )
        new_key = resp.json()["api_key"]

        # Use the new key to browse
        resp2 = app_setup.client.get(
            "/api/v1/registry/packs",
            headers={"X-Registry-Token": new_key},
        )
        assert resp2.status_code == 200

    def test_create_duplicate_username_409(self, app_setup) -> None:
        """Creating user with existing username returns 409."""
        resp = app_setup.client.post(
            "/api/v1/registry/admin/users",
            json={"username": "admin"},  # already exists
            headers=_admin_headers(app_setup),
        )
        assert resp.status_code == 409

    def test_list_users(self, app_setup) -> None:
        """Listing users returns all active users."""
        resp = app_setup.client.get(
            "/api/v1/registry/admin/users",
            headers=_admin_headers(app_setup),
        )
        assert resp.status_code == 200
        users = resp.json()
        assert len(users) == 2  # admin + developer
        usernames = {u["username"] for u in users}
        assert "admin" in usernames
        assert "developer" in usernames

    def test_list_users_no_hash_exposed(self, app_setup) -> None:
        """User listing does not expose api_key_hash."""
        resp = app_setup.client.get(
            "/api/v1/registry/admin/users",
            headers=_admin_headers(app_setup),
        )
        for user in resp.json():
            assert "api_key_hash" not in user

    def test_deactivate_user_success(self, app_setup) -> None:
        """Admin can deactivate a user."""
        resp = app_setup.client.post(
            f"/api/v1/registry/admin/users/{app_setup.user['user_id']}/deactivate",
            headers=_admin_headers(app_setup),
        )
        assert resp.status_code == 200
        assert resp.json()["status"] == "deactivated"

    def test_deactivated_user_cannot_access(self, app_setup) -> None:
        """Deactivated user cannot make requests."""
        # Deactivate
        app_setup.client.post(
            f"/api/v1/registry/admin/users/{app_setup.user['user_id']}/deactivate",
            headers=_admin_headers(app_setup),
        )
        # Try to browse
        resp = app_setup.client.get(
            "/api/v1/registry/packs",
            headers=_user_headers(app_setup),
        )
        assert resp.status_code == 403

    def test_deactivate_not_found(self, app_setup) -> None:
        """Deactivating nonexistent user returns 404."""
        resp = app_setup.client.post(
            "/api/v1/registry/admin/users/usr-missing/deactivate",
            headers=_admin_headers(app_setup),
        )
        assert resp.status_code == 404

    def test_create_admin_user(self, app_setup) -> None:
        """Admin can create another admin."""
        resp = app_setup.client.post(
            "/api/v1/registry/admin/users",
            json={"username": "admin2", "role": "admin"},
            headers=_admin_headers(app_setup),
        )
        assert resp.status_code == 201
        assert resp.json()["user"]["role"] == "admin"


# ---------------------------------------------------------------------------
# E2E flows
# ---------------------------------------------------------------------------


class TestE2EFlows:
    def test_full_user_lifecycle(self, app_setup) -> None:
        """Create user → authenticate → browse → publish → deactivate."""
        # 1. Admin creates user
        resp = app_setup.client.post(
            "/api/v1/registry/admin/users",
            json={"username": "lifecycle_user"},
            headers=_admin_headers(app_setup),
        )
        assert resp.status_code == 201
        new_key = resp.json()["api_key"]
        new_user_id = resp.json()["user"]["user_id"]
        headers = {"X-Registry-Token": new_key}

        # 2. User browses (empty results, but 200)
        resp = app_setup.client.get("/api/v1/registry/packs", headers=headers)
        assert resp.status_code == 200

        # 3. User publishes a pack
        manifest = {"id": "lc-pack", "name": "LC Pack", "version": "1.0.0"}
        resp = app_setup.client.post(
            "/api/v1/registry/packs",
            files={"archive": ("p.zip", _make_zip(manifest), "application/zip")},
            data={"tags": "[]"},
            headers=headers,
        )
        assert resp.status_code == 201

        # 4. Admin deactivates user
        resp = app_setup.client.post(
            f"/api/v1/registry/admin/users/{new_user_id}/deactivate",
            headers=_admin_headers(app_setup),
        )
        assert resp.status_code == 200

        # 5. User can no longer access
        resp = app_setup.client.get("/api/v1/registry/packs", headers=headers)
        assert resp.status_code == 403

    def test_admin_moderates_pack(self, app_setup) -> None:
        """User publishes → admin approves → user can search it."""
        # Publish
        manifest = {"id": "mod-pack", "name": "Mod Pack", "version": "1.0.0"}
        app_setup.client.post(
            "/api/v1/registry/packs",
            files={"archive": ("p.zip", _make_zip(manifest), "application/zip")},
            data={"tags": "[]"},
            headers=_user_headers(app_setup),
        )

        # Not yet in search results (pending)
        resp = app_setup.client.get(
            "/api/v1/registry/packs",
            headers=_user_headers(app_setup),
        )
        assert len(resp.json()) == 0

        # Admin approves
        resp = app_setup.client.post(
            "/api/v1/registry/admin/approve/mod-pack",
            headers=_admin_headers(app_setup),
        )
        assert resp.status_code == 200

        # Now visible in search
        resp = app_setup.client.get(
            "/api/v1/registry/packs",
            headers=_user_headers(app_setup),
        )
        assert len(resp.json()) == 1
        assert resp.json()[0]["name"] == "Mod Pack"
