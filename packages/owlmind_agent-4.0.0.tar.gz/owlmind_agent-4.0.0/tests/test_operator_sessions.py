"""Tests for operator session APIs — unit tests only, no network."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import yaml

from owlmind.operator import OperatorService, _session_result_to_dict


def _write_goals(tmp_path: Path, goals: list[dict[str, Any]]) -> Path:
    data = {"version": 2, "goals": goals}
    path = tmp_path / "goals.yaml"
    path.write_text(yaml.dump(data))
    return path


def _make_policies(tmp_path: Path) -> Path:
    policies_dir = tmp_path / "policies"
    policies_dir.mkdir(exist_ok=True)
    (policies_dir / "allowlist.yaml").write_text('allowed_commands:\n  - "^echo "\n  - "^pytest"\n')
    (policies_dir / "policy.yaml").write_text('forbidden_patterns:\n  - "rm -rf"\n')
    return policies_dir


def _make_svc(tmp_path: Path) -> OperatorService:
    policies_dir = _make_policies(tmp_path)
    return OperatorService(
        runs_dir=tmp_path / "runs",
        policies_dir=policies_dir,
        ledger_dir=tmp_path / "ledger",
        sessions_dir=tmp_path / "sessions",
    )


class TestSessionsDir:
    def test_default_sessions_dir(self, tmp_path: Path) -> None:
        svc = OperatorService(
            runs_dir=tmp_path / "runs",
            policies_dir=tmp_path / "policies",
            ledger_dir=tmp_path / "ledger",
        )
        assert svc.sessions_dir == tmp_path / "sessions"

    def test_custom_sessions_dir(self, tmp_path: Path) -> None:
        custom = tmp_path / "my_sessions"
        svc = OperatorService(
            runs_dir=tmp_path / "runs",
            policies_dir=tmp_path / "policies",
            ledger_dir=tmp_path / "ledger",
            sessions_dir=custom,
        )
        assert svc.sessions_dir == custom


class TestSessionResultToDict:
    def test_converts_result(self) -> None:
        result = MagicMock()
        result.session_id = "session-abc"
        result.status = "DONE"
        result.goals_total = 3
        result.goals_done = 2
        result.goals_failed = 1
        result.goals_blocked = 0
        result.goals_skipped = 0
        result.last_block_reason = ""
        result.next_commands = ["cmd1"]

        d = _session_result_to_dict(result)
        assert d["session_id"] == "session-abc"
        assert d["status"] == "DONE"
        assert d["goals_total"] == 3
        assert d["goals_done"] == 2
        assert d["goals_failed"] == 1
        assert d["next_commands"] == ["cmd1"]


class TestStartSession:
    def test_goals_file_not_found(self, tmp_path: Path) -> None:
        svc = _make_svc(tmp_path)
        import pytest

        with pytest.raises(FileNotFoundError, match="not found"):
            svc.start_session("/nonexistent/goals.yaml", str(tmp_path))

    def test_start_session_mocked(self, tmp_path: Path) -> None:
        svc = _make_svc(tmp_path)
        goals_path = _write_goals(
            tmp_path,
            [
                {"id": "G1", "goal": "Test goal", "depends_on": []},
            ],
        )

        mock_result = MagicMock()
        mock_result.session_id = "session-test"
        mock_result.status = "BLOCKED"
        mock_result.goals_total = 1
        mock_result.goals_done = 0
        mock_result.goals_failed = 0
        mock_result.goals_blocked = 1
        mock_result.goals_skipped = 0
        mock_result.last_block_reason = "waiting"
        mock_result.next_commands = []

        with (
            patch("owlmind.session.create_session") as mock_create,
            patch("owlmind.session.save_session"),
            patch("owlmind.session_runner.run_session", return_value=mock_result),
        ):
            mock_meta = MagicMock()
            mock_meta.session_id = "session-test"
            mock_meta.goals = []
            mock_meta.config = {}
            mock_create.return_value = mock_meta

            result = svc.start_session(str(goals_path), str(tmp_path))

        assert result["session_id"] == "session-test"
        assert result["status"] == "BLOCKED"
        assert result["goals_blocked"] == 1


class TestResumeSession:
    def test_resume_mocked(self, tmp_path: Path) -> None:
        svc = _make_svc(tmp_path)

        mock_result = MagicMock()
        mock_result.session_id = "session-resume"
        mock_result.status = "DONE"
        mock_result.goals_total = 2
        mock_result.goals_done = 2
        mock_result.goals_failed = 0
        mock_result.goals_blocked = 0
        mock_result.goals_skipped = 0
        mock_result.last_block_reason = ""
        mock_result.next_commands = ["export"]

        with patch("owlmind.session_runner.run_session", return_value=mock_result):
            result = svc.resume_session("session-resume")

        assert result["status"] == "DONE"
        assert result["goals_done"] == 2


class TestSessionStatus:
    def test_get_status(self, tmp_path: Path) -> None:
        svc = _make_svc(tmp_path)

        # Create a session manually
        sessions_dir = tmp_path / "sessions"
        sid = "session-status-test"
        sdir = sessions_dir / sid
        sdir.mkdir(parents=True)
        meta = {
            "session_id": sid,
            "created_at": "2025-01-01T00:00:00",
            "updated_at": "2025-01-01T00:00:00",
            "status": "BLOCKED",
            "current_goal_index": 0,
            "goals": [
                {
                    "id": "G1",
                    "goal": "Test",
                    "workspace": ".",
                    "sandbox": False,
                    "use_llm": "none",
                    "use_worker": "none",
                    "max_steps": 5,
                    "interval_sec": 1.0,
                    "export_on_done": True,
                    "stop_on_approval": True,
                    "stop_on_blocked": True,
                    "notes": "",
                    "depends_on": [],
                    "concurrency_group": "",
                    "provider_planner": None,
                    "provider_judge": None,
                    "rollback": {"mode": "none", "require_approval": True},
                },
            ],
            "runs": [
                {
                    "goal_id": "G1",
                    "run_id": "cycle-1",
                    "status": "blocked",
                    "started_at": "2025-01-01",
                    "ended_at": "",
                },
            ],
            "last_block_reason": "waiting for approval",
            "config": {},
            "max_concurrency": 1,
            "continue_on_fail": False,
        }
        (sdir / "session_meta.json").write_text(json.dumps(meta))

        info = svc.get_session_status(sid)
        assert info["session_id"] == sid
        assert info["status"] == "BLOCKED"
        assert info["goals_total"] == 1
        assert len(info["goals"]) == 1
        assert info["goals"][0]["id"] == "G1"
        assert info["goals"][0]["status"] == "blocked"


class TestStopSession:
    def test_stop_mocked(self, tmp_path: Path) -> None:
        svc = _make_svc(tmp_path)

        mock_meta = MagicMock()
        mock_meta.session_id = "session-stop"
        mock_meta.status = "STOPPED"

        with patch("owlmind.session_runner.stop_session", return_value=mock_meta):
            result = svc.stop_session("session-stop")

        assert result["session_id"] == "session-stop"
        assert result["status"] == "STOPPED"


class TestSessionGraph:
    def test_graph(self, tmp_path: Path) -> None:
        svc = _make_svc(tmp_path)

        # Create a session with DAG
        sessions_dir = tmp_path / "sessions"
        sid = "session-graph-test"
        sdir = sessions_dir / sid
        sdir.mkdir(parents=True)
        meta = {
            "session_id": sid,
            "created_at": "2025-01-01T00:00:00",
            "updated_at": "2025-01-01T00:00:00",
            "status": "RUNNING",
            "current_goal_index": 0,
            "goals": [
                {
                    "id": "G1",
                    "goal": "Base",
                    "workspace": ".",
                    "sandbox": False,
                    "use_llm": "none",
                    "use_worker": "none",
                    "max_steps": 5,
                    "interval_sec": 1.0,
                    "export_on_done": True,
                    "stop_on_approval": True,
                    "stop_on_blocked": True,
                    "notes": "",
                    "depends_on": [],
                    "concurrency_group": "",
                    "provider_planner": None,
                    "provider_judge": None,
                    "rollback": {"mode": "none", "require_approval": True},
                },
                {
                    "id": "G2",
                    "goal": "Build",
                    "workspace": ".",
                    "sandbox": False,
                    "use_llm": "none",
                    "use_worker": "none",
                    "max_steps": 5,
                    "interval_sec": 1.0,
                    "export_on_done": True,
                    "stop_on_approval": True,
                    "stop_on_blocked": True,
                    "notes": "",
                    "depends_on": ["G1"],
                    "concurrency_group": "",
                    "provider_planner": None,
                    "provider_judge": None,
                    "rollback": {"mode": "none", "require_approval": True},
                },
            ],
            "runs": [],
            "last_block_reason": "",
            "config": {},
            "max_concurrency": 1,
            "continue_on_fail": False,
        }
        (sdir / "session_meta.json").write_text(json.dumps(meta))

        graph = svc.get_session_graph(sid)
        assert "G1" in graph
        assert "G2" in graph
        assert "Layer" in graph


class TestSessionExport:
    def test_export_mocked(self, tmp_path: Path) -> None:
        svc = _make_svc(tmp_path)

        with patch("owlmind.session_export.export_session", return_value=Path("/tmp/export.zip")):
            result = svc.export_session("session-exp")

        assert result == "/tmp/export.zip"


class TestRollbackSessionGoal:
    def test_goal_not_found(self, tmp_path: Path) -> None:
        svc = _make_svc(tmp_path)

        # Create a session
        sessions_dir = tmp_path / "sessions"
        sid = "session-rb"
        sdir = sessions_dir / sid
        sdir.mkdir(parents=True)
        meta = {
            "session_id": sid,
            "created_at": "2025-01-01T00:00:00",
            "updated_at": "2025-01-01T00:00:00",
            "status": "DONE",
            "current_goal_index": 0,
            "goals": [],
            "runs": [],
            "last_block_reason": "",
            "config": {},
            "max_concurrency": 1,
            "continue_on_fail": False,
        }
        (sdir / "session_meta.json").write_text(json.dumps(meta))

        import pytest

        with pytest.raises(ValueError, match="not found"):
            svc.rollback_session_goal(sid, "G999")

    def test_rollback_mode_none(self, tmp_path: Path) -> None:
        svc = _make_svc(tmp_path)

        sessions_dir = tmp_path / "sessions"
        sid = "session-rb-none"
        sdir = sessions_dir / sid
        sdir.mkdir(parents=True)
        meta = {
            "session_id": sid,
            "created_at": "2025-01-01T00:00:00",
            "updated_at": "2025-01-01T00:00:00",
            "status": "DONE",
            "current_goal_index": 0,
            "goals": [
                {
                    "id": "G1",
                    "goal": "Test",
                    "workspace": ".",
                    "sandbox": False,
                    "use_llm": "none",
                    "use_worker": "none",
                    "max_steps": 5,
                    "interval_sec": 1.0,
                    "export_on_done": True,
                    "stop_on_approval": True,
                    "stop_on_blocked": True,
                    "notes": "",
                    "depends_on": [],
                    "concurrency_group": "",
                    "provider_planner": None,
                    "provider_judge": None,
                    "rollback": {"mode": "none", "require_approval": True},
                },
            ],
            "runs": [],
            "last_block_reason": "",
            "config": {},
            "max_concurrency": 1,
            "continue_on_fail": False,
        }
        (sdir / "session_meta.json").write_text(json.dumps(meta))

        result = svc.rollback_session_goal(sid, "G1")
        assert result["status"] == "skipped"

    def test_rollback_approval_required(self, tmp_path: Path) -> None:
        svc = _make_svc(tmp_path)

        sessions_dir = tmp_path / "sessions"
        sid = "session-rb-approval"
        sdir = sessions_dir / sid
        sdir.mkdir(parents=True)
        meta = {
            "session_id": sid,
            "created_at": "2025-01-01T00:00:00",
            "updated_at": "2025-01-01T00:00:00",
            "status": "FAILED",
            "current_goal_index": 0,
            "goals": [
                {
                    "id": "G1",
                    "goal": "Test",
                    "workspace": ".",
                    "sandbox": False,
                    "use_llm": "none",
                    "use_worker": "none",
                    "max_steps": 5,
                    "interval_sec": 1.0,
                    "export_on_done": True,
                    "stop_on_approval": True,
                    "stop_on_blocked": True,
                    "notes": "",
                    "depends_on": [],
                    "concurrency_group": "",
                    "provider_planner": None,
                    "provider_judge": None,
                    "rollback": {"mode": "worktree_reset", "require_approval": True},
                },
            ],
            "runs": [
                {
                    "goal_id": "G1",
                    "run_id": "cycle-1",
                    "status": "failed",
                    "started_at": "2025-01-01",
                    "ended_at": "2025-01-01",
                },
            ],
            "last_block_reason": "",
            "config": {},
            "max_concurrency": 1,
            "continue_on_fail": False,
        }
        (sdir / "session_meta.json").write_text(json.dumps(meta))

        result = svc.rollback_session_goal(sid, "G1")
        assert result["status"] == "approval_required"
        assert "token" in result

    def test_rollback_with_yes(self, tmp_path: Path) -> None:
        svc = _make_svc(tmp_path)

        sessions_dir = tmp_path / "sessions"
        sid = "session-rb-yes"
        sdir = sessions_dir / sid
        sdir.mkdir(parents=True)

        # Create run dir for worktree_reset
        runs_dir = tmp_path / "runs"
        (runs_dir / "cycle-1").mkdir(parents=True)

        meta = {
            "session_id": sid,
            "created_at": "2025-01-01T00:00:00",
            "updated_at": "2025-01-01T00:00:00",
            "status": "FAILED",
            "current_goal_index": 0,
            "goals": [
                {
                    "id": "G1",
                    "goal": "Test",
                    "workspace": ".",
                    "sandbox": False,
                    "use_llm": "none",
                    "use_worker": "none",
                    "max_steps": 5,
                    "interval_sec": 1.0,
                    "export_on_done": True,
                    "stop_on_approval": True,
                    "stop_on_blocked": True,
                    "notes": "",
                    "depends_on": [],
                    "concurrency_group": "",
                    "provider_planner": None,
                    "provider_judge": None,
                    "rollback": {"mode": "worktree_reset", "require_approval": True},
                },
            ],
            "runs": [
                {
                    "goal_id": "G1",
                    "run_id": "cycle-1",
                    "status": "failed",
                    "started_at": "2025-01-01",
                    "ended_at": "2025-01-01",
                },
            ],
            "last_block_reason": "",
            "config": {},
            "max_concurrency": 1,
            "continue_on_fail": False,
        }
        (sdir / "session_meta.json").write_text(json.dumps(meta))

        result = svc.rollback_session_goal(sid, "G1", yes=True)
        assert result["status"] == "no_worktree"


class TestAllowlistRejection:
    """Workspace allowlist must reject unauthorized paths."""

    def test_session_start_rejected_workspace(self, tmp_path: Path) -> None:
        policies_dir = _make_policies(tmp_path)
        svc = OperatorService(
            runs_dir=tmp_path / "runs",
            policies_dir=policies_dir,
            ledger_dir=tmp_path / "ledger",
            sessions_dir=tmp_path / "sessions",
            allowed_workspaces=["/safe/only"],
        )
        assert svc.is_workspace_allowed("/tmp/evil") is False
        assert svc.is_workspace_allowed("/safe/only/sub") is True

    def test_empty_allowlist_allows_all(self, tmp_path: Path) -> None:
        svc = _make_svc(tmp_path)
        assert svc.is_workspace_allowed("/literally/anywhere") is True


class TestExportPathSafety:
    """Export path must stay within sessions/<id>/exports."""

    def test_export_path_outside_rejected(self, tmp_path: Path) -> None:
        import pytest

        from owlmind.session_export import export_session

        # Create a minimal session
        sessions_dir = tmp_path / "sessions"
        sid = "session-safe"
        sdir = sessions_dir / sid
        sdir.mkdir(parents=True)
        meta = {
            "session_id": sid,
            "created_at": "2025-01-01T00:00:00",
            "updated_at": "2025-01-01T00:00:00",
            "status": "DONE",
            "current_goal_index": 0,
            "goals": [],
            "runs": [],
            "last_block_reason": "",
            "config": {},
            "max_concurrency": 1,
            "continue_on_fail": False,
        }
        (sdir / "session_meta.json").write_text(json.dumps(meta))

        evil_path = tmp_path / "evil" / "export.zip"
        with pytest.raises(ValueError, match="Export path must be inside"):
            export_session(
                sid,
                sessions_dir,
                tmp_path / "runs",
                out_path=evil_path,
            )

    def test_export_default_path_ok(self, tmp_path: Path) -> None:
        from owlmind.session_export import export_session

        sessions_dir = tmp_path / "sessions"
        sid = "session-ok"
        sdir = sessions_dir / sid
        sdir.mkdir(parents=True)
        meta = {
            "session_id": sid,
            "created_at": "2025-01-01T00:00:00",
            "updated_at": "2025-01-01T00:00:00",
            "status": "DONE",
            "current_goal_index": 0,
            "goals": [],
            "runs": [],
            "last_block_reason": "",
            "config": {},
            "max_concurrency": 1,
            "continue_on_fail": False,
        }
        (sdir / "session_meta.json").write_text(json.dumps(meta))
        (sdir / "session.jsonl").write_text("")

        zip_path = export_session(sid, sessions_dir, tmp_path / "runs")
        assert zip_path.exists()
        assert str(zip_path).startswith(str(sdir / "exports"))


class TestListSessions:
    def test_no_sessions(self, tmp_path: Path) -> None:
        svc = _make_svc(tmp_path)
        assert svc.list_sessions() == []

    def test_lists_sessions(self, tmp_path: Path) -> None:
        svc = _make_svc(tmp_path)
        sessions_dir = tmp_path / "sessions"

        # Create two sessions
        for i, sid in enumerate(["session-a", "session-b"]):
            sdir = sessions_dir / sid
            sdir.mkdir(parents=True)
            meta = {
                "session_id": sid,
                "created_at": f"2025-01-0{i + 1}T00:00:00",
                "updated_at": f"2025-01-0{i + 1}T00:00:00",
                "status": "DONE" if i == 0 else "BLOCKED",
                "current_goal_index": 0,
                "goals": [],
                "runs": [],
                "last_block_reason": "",
                "config": {},
                "max_concurrency": 1,
                "continue_on_fail": False,
            }
            (sdir / "session_meta.json").write_text(json.dumps(meta))

        result = svc.list_sessions(n=10)
        assert len(result) == 2
        # Newest first
        ids = [r["session_id"] for r in result]
        assert "session-a" in ids
        assert "session-b" in ids

    def test_list_with_limit(self, tmp_path: Path) -> None:
        svc = _make_svc(tmp_path)
        sessions_dir = tmp_path / "sessions"

        for i in range(5):
            sdir = sessions_dir / f"session-{i}"
            sdir.mkdir(parents=True)
            meta = {
                "session_id": f"session-{i}",
                "created_at": "2025-01-01T00:00:00",
                "updated_at": "2025-01-01T00:00:00",
                "status": "DONE",
                "current_goal_index": 0,
                "goals": [],
                "runs": [],
                "last_block_reason": "",
                "config": {},
                "max_concurrency": 1,
                "continue_on_fail": False,
            }
            (sdir / "session_meta.json").write_text(json.dumps(meta))

        result = svc.list_sessions(n=3)
        assert len(result) == 3
