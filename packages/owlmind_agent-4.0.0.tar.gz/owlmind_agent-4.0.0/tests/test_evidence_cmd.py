"""Tests for FS60 — Evidence Verify CLI."""

from __future__ import annotations

import json
from pathlib import Path

from typer.testing import CliRunner

from owlmind.cli.evidence_cmd import evidence_app

runner = CliRunner()

# ---------------------------------------------------------------------------
# evidence verify — OK chain
# ---------------------------------------------------------------------------


def test_verify_ok(tmp_path: Path) -> None:
    """Healthy chain → exit 0 and 'Chain OK' message."""
    from owlmind.evidence import EvidenceStore

    runs_dir = tmp_path / "runs"
    evidence = EvidenceStore(runs_dir)
    run_id = "ev-verify-001"
    evidence.create_run(run_id)
    evidence.append_event(run_id, {"event": "step_one", "data": "hello"})
    evidence.append_event(run_id, {"event": "step_two", "data": "world"})

    result = runner.invoke(evidence_app, [run_id, "--runs", str(runs_dir)])

    assert result.exit_code == 0, result.output
    assert "Chain OK" in result.output


def test_verify_ok_shows_seq_and_tip(tmp_path: Path) -> None:
    """Output includes seq and first chars of tip_hash."""
    from owlmind.evidence import EvidenceStore

    runs_dir = tmp_path / "runs"
    evidence = EvidenceStore(runs_dir)
    run_id = "ev-verify-002"
    evidence.create_run(run_id)
    evidence.append_event(run_id, {"event": "test"})

    result = runner.invoke(evidence_app, [run_id, "--runs", str(runs_dir)])

    assert result.exit_code == 0
    assert "seq=" in result.output
    assert "tip=" in result.output


# ---------------------------------------------------------------------------
# evidence verify — invalid chain
# ---------------------------------------------------------------------------


def test_verify_invalid_chain(tmp_path: Path) -> None:
    """Corrupted _hash in run.jsonl → exit 1 and 'INVALID' message."""
    from owlmind.evidence import EvidenceStore

    runs_dir = tmp_path / "runs"
    evidence = EvidenceStore(runs_dir)
    run_id = "ev-verify-003"
    evidence.create_run(run_id)
    evidence.append_event(run_id, {"event": "test_event"})

    # Corrupt _hash of every entry
    run_log = runs_dir / run_id / "run.jsonl"
    corrupted: list[str] = []
    for line in run_log.read_text().strip().splitlines():
        if line:
            evt = json.loads(line)
            evt["_hash"] = "0" * 64
            corrupted.append(json.dumps(evt))
    run_log.write_text("\n".join(corrupted) + "\n")

    result = runner.invoke(evidence_app, [run_id, "--runs", str(runs_dir)])

    assert result.exit_code == 1
    assert "INVALID" in result.output


# ---------------------------------------------------------------------------
# evidence verify — run not found
# ---------------------------------------------------------------------------


def test_verify_run_not_found(tmp_path: Path) -> None:
    """Non-existent run_id → exit 1 (run.jsonl not found)."""
    runs_dir = tmp_path / "runs"
    runs_dir.mkdir()  # directory must exist for path validation to pass

    result = runner.invoke(evidence_app, ["ghost-run-999", "--runs", str(runs_dir)])

    assert result.exit_code == 1
    assert "INVALID" in result.output
