"""Tests for owlmind.llm.retry — unified retry logic."""

from __future__ import annotations

import json

import pytest

from owlmind.errors import StructuralError, TransientError
from owlmind.llm.retry import classify_error, is_transient, with_retry


class TestIsTransient:
    def test_timeout(self) -> None:
        assert is_transient(RuntimeError("Request timeout after 30s"))

    def test_rate_limit(self) -> None:
        assert is_transient(RuntimeError("Rate limit exceeded (429)"))

    def test_server_error_503(self) -> None:
        assert is_transient(RuntimeError("Service Unavailable 503"))

    def test_connection_error(self) -> None:
        assert is_transient(RuntimeError("Connection refused"))

    def test_auth_error_not_transient(self) -> None:
        assert not is_transient(RuntimeError("Invalid API key"))

    def test_schema_error_not_transient(self) -> None:
        assert not is_transient(RuntimeError("Schema validation failed"))


class TestWithRetry:
    def test_success_first_attempt(self) -> None:
        result = with_retry(lambda: 42, provider="test")
        assert result == 42

    def test_success_after_transient(self) -> None:
        calls = {"n": 0}

        def flaky() -> str:
            calls["n"] += 1
            if calls["n"] < 2:
                raise RuntimeError("timeout error")
            return "ok"

        result = with_retry(flaky, provider="test", base_delay=0.01)
        assert result == "ok"
        assert calls["n"] == 2

    def test_structural_error_no_retry(self) -> None:
        calls = {"n": 0}

        def bad_json() -> None:
            calls["n"] += 1
            raise StructuralError("bad schema")

        with pytest.raises(StructuralError, match="bad schema"):
            with_retry(bad_json, provider="test", base_delay=0.01)

        assert calls["n"] == 1  # no retry

    def test_json_decode_error_no_retry(self) -> None:
        import json

        calls = {"n": 0}

        def bad_parse() -> None:
            calls["n"] += 1
            json.loads("{invalid")

        with pytest.raises(StructuralError, match="JSON decode"):
            with_retry(bad_parse, provider="test", base_delay=0.01)

        assert calls["n"] == 1

    def test_non_transient_error_no_retry(self) -> None:
        calls = {"n": 0}

        def auth_fail() -> None:
            calls["n"] += 1
            raise RuntimeError("Invalid API key supplied")

        with pytest.raises(StructuralError, match="Invalid API key"):
            with_retry(auth_fail, provider="test", base_delay=0.01)

        assert calls["n"] == 1

    def test_all_retries_exhausted(self) -> None:
        calls = {"n": 0}

        def always_timeout() -> None:
            calls["n"] += 1
            raise RuntimeError("timeout")

        with pytest.raises(TransientError, match="3 retries"):
            with_retry(always_timeout, provider="test", max_retries=3, base_delay=0.01)

        assert calls["n"] == 3


class TestClassifyError:
    def test_owlmind_error_returned_as_is(self) -> None:
        """OwlMindError subclasses must be returned unchanged (lines 41-42)."""
        original = TransientError("already classified")
        result = classify_error(original, provider="test")
        assert result is original

    def test_structural_owlmind_error_returned_as_is(self) -> None:
        """StructuralError (also a OwlMindError) must be returned unchanged."""
        original = StructuralError("already structural")
        result = classify_error(original, provider="test")
        assert result is original

    def test_json_decode_error_becomes_structural(self) -> None:
        """json.JSONDecodeError must map to StructuralError (lines 43-44)."""
        exc = json.JSONDecodeError("Expecting value", "{invalid", 0)
        result = classify_error(exc, provider="openai")
        assert isinstance(result, StructuralError)
        assert "openai" in str(result)
        assert "JSON decode" in str(result)

    def test_transient_runtime_error_becomes_transient(self) -> None:
        """A transient RuntimeError must map to TransientError (lines 45-46)."""
        exc = RuntimeError("connection refused")
        result = classify_error(exc, provider="anthropic")
        assert isinstance(result, TransientError)
        assert "anthropic" in str(result)
        assert "transient" in str(result)

    def test_non_transient_runtime_error_becomes_structural(self) -> None:
        """A non-transient RuntimeError must map to StructuralError (line 47)."""
        exc = RuntimeError("Invalid API key")
        result = classify_error(exc, provider="gemini")
        assert isinstance(result, StructuralError)
        assert "gemini" in str(result)
        assert "Invalid API key" in str(result)
