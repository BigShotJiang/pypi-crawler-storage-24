"""Tests for the skills system — registry, installer, and cycle integration."""

from __future__ import annotations

from pathlib import Path

import pytest
import yaml

from owlmind.skills.installer import install
from owlmind.skills.registry import get_pack_context, list_packs, load_pack

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def fake_pack_dir(tmp_path: Path) -> Path:
    """Create a minimal fake skill pack directory."""
    packs_dir = tmp_path / "skill-packs"
    pack_dir = packs_dir / "test_pack"
    (pack_dir / "prompts").mkdir(parents=True)
    (pack_dir / "policies").mkdir()
    (pack_dir / "workflows").mkdir()

    # pack.yaml
    manifest = {
        "id": "test_pack",
        "name": "Test Pack",
        "version": "1.0.0",
        "description": "A minimal test pack",
        "tags": ["test"],
        "knowledge_dir": "knowledge/test_pack",
        "required_files": [
            "prompts/system_prompt.md",
        ],
        "knowledge_files": ["info.md"],
    }
    (pack_dir / "pack.yaml").write_text(yaml.dump(manifest))
    (pack_dir / "prompts" / "system_prompt.md").write_text("You are a test assistant.")
    (pack_dir / "policies" / "rules.yaml").write_text("quality_checks:\n  - 'Check everything'\n")
    (pack_dir / "workflows" / "sample.yaml").write_text("session:\n  name: sample\n  goals: []\n")

    # knowledge dir
    knowledge_dir = tmp_path / "knowledge" / "test_pack"
    knowledge_dir.mkdir(parents=True)
    (knowledge_dir / "info.md").write_text("# Info\nThis is test knowledge content.\n")

    return packs_dir


# ---------------------------------------------------------------------------
# Registry tests
# ---------------------------------------------------------------------------


def test_list_packs_finds_pack(fake_pack_dir: Path) -> None:
    """list_packs should find the test pack and return correct metadata."""
    packs = list_packs(fake_pack_dir)
    assert len(packs) == 1
    pack = packs[0]
    assert pack["id"] == "test_pack"
    assert pack["name"] == "Test Pack"
    assert pack["version"] == "1.0.0"
    assert "test" in pack["tags"]


def test_list_packs_finds_lead_nurture() -> None:
    """list_packs finds the real lead_nurture pack in the repo."""
    repo_root = Path(__file__).parent.parent
    packs_dir = repo_root / "skill-packs"
    if not packs_dir.exists():
        pytest.skip("skill-packs directory not found")
    packs = list_packs(packs_dir)
    ids = [p["id"] for p in packs]
    assert "lead_nurture" in ids


def test_list_packs_empty_dir(tmp_path: Path) -> None:
    """list_packs returns empty list when no packs present."""
    packs = list_packs(tmp_path / "nonexistent")
    assert packs == []


def test_load_pack_success(fake_pack_dir: Path) -> None:
    """load_pack returns full metadata including pack_dir."""
    pack = load_pack("test_pack", fake_pack_dir)
    assert pack["id"] == "test_pack"
    assert pack["version"] == "1.0.0"
    assert isinstance(pack["pack_dir"], Path)
    assert pack["pack_dir"].is_dir()


def test_load_pack_not_found(tmp_path: Path) -> None:
    """load_pack raises FileNotFoundError for missing pack."""
    with pytest.raises(FileNotFoundError, match="ghost_pack"):
        load_pack("ghost_pack", tmp_path)


def test_get_pack_context_contains_system_prompt(fake_pack_dir: Path) -> None:
    """get_pack_context includes system_prompt content."""
    ctx = get_pack_context("test_pack", fake_pack_dir)
    assert "test assistant" in ctx
    assert "Test Pack" in ctx


def test_get_pack_context_contains_knowledge_index(fake_pack_dir: Path) -> None:
    """get_pack_context lists knowledge files."""
    ctx = get_pack_context("test_pack", fake_pack_dir)
    assert "info.md" in ctx


def test_get_pack_context_contains_workflow_index(fake_pack_dir: Path) -> None:
    """get_pack_context lists workflow names."""
    ctx = get_pack_context("test_pack", fake_pack_dir)
    assert "sample" in ctx


# ---------------------------------------------------------------------------
# Installer tests
# ---------------------------------------------------------------------------


def test_install_ingests_into_memory(tmp_path: Path, fake_pack_dir: Path) -> None:
    """install() ingests docs into MemoryStore — stats should show documents > 0."""
    from owlmind.memory.store import MemoryStore

    db_path = tmp_path / "memory.db"
    mem = MemoryStore(db_path)

    try:
        result = install(
            "test_pack",
            tmp_path / "workspace",
            base_dir=fake_pack_dir,
            memory_store=mem,
        )
        stats = mem.stats()
    finally:
        mem.close()

    assert result["pack_id"] == "test_pack"
    assert result["ingested_docs"] > 0
    assert stats["documents"] > 0


def test_install_writes_evidence_event(tmp_path: Path, fake_pack_dir: Path) -> None:
    """install() appends a SKILL_PACK_INSTALLED event to the evidence chain."""
    import json

    from owlmind.evidence import EvidenceStore

    runs_dir = tmp_path / "runs"
    ev = EvidenceStore(runs_dir)
    run_id = "skill-install-test"
    ev.create_run(run_id)

    install(
        "test_pack",
        tmp_path / "workspace",
        base_dir=fake_pack_dir,
        evidence_store=ev,
        run_id=run_id,
    )

    log_path = runs_dir / run_id / "run.jsonl"
    assert log_path.exists()
    events = [json.loads(line) for line in log_path.read_text().splitlines() if line.strip()]
    event_types = [e.get("event") for e in events]
    assert "SKILL_PACK_INSTALLED" in event_types

    skill_event = next(e for e in events if e.get("event") == "SKILL_PACK_INSTALLED")
    assert skill_event["pack_id"] == "test_pack"
    assert "key_file_hashes" in skill_event


def test_install_copies_to_workspace(tmp_path: Path, fake_pack_dir: Path) -> None:
    """install() copies pack files when workspace != repo root."""
    workspace = tmp_path / "my_workspace"
    workspace.mkdir()

    install("test_pack", workspace, base_dir=fake_pack_dir)

    dest = workspace / "skill-packs" / "test_pack"
    assert dest.is_dir()
    assert (dest / "pack.yaml").exists()


def test_install_no_copy_when_same_root(tmp_path: Path, fake_pack_dir: Path) -> None:
    """install() does not copy when workspace is the repo root (same resolved path)."""
    # Use the parent of fake_pack_dir as the "repo root" and workspace
    repo_root = fake_pack_dir.parent
    install("test_pack", repo_root, base_dir=fake_pack_dir)
    # No skill-packs/<id> copy under workspace (it already IS repo root)
    dest = repo_root / "skill-packs" / "test_pack"
    # The pack dir already exists but should not be a NEW copy (no nested skill-packs/skill-packs)
    nested = dest / "skill-packs"
    assert not nested.exists()


# ---------------------------------------------------------------------------
# Cycle integration test
# ---------------------------------------------------------------------------


def test_cycle_start_accepts_skill_pack_option(tmp_path: Path) -> None:
    """cycle start command accepts --skill-pack without error."""
    from typer.testing import CliRunner

    from owlmind.cli import app

    runner = CliRunner()
    result = runner.invoke(
        app,
        [
            "cycle",
            "start",
            "--goal",
            "Test goal with skill pack",
            "--workspace",
            str(tmp_path),
            "--skill-pack",
            "lead_nurture",
            "--runs",
            str(tmp_path / "runs"),
        ],
    )
    # Should not fail with unrecognized option error
    assert result.exit_code != 2, f"CLI rejected option: {result.output}"


def test_planner_prompt_includes_skill_pack_context() -> None:
    """_build_planner_prompt injects skill_pack_context into the prompt."""
    from owlmind.agent.cycle import _build_planner_prompt
    from owlmind.agent.schemas import PlannerRequest

    req = PlannerRequest(
        run_id="test-run-001",
        iteration=1,
        goal="Build something",
        skill_pack_context="## Skill Pack Context\nTest skill pack content here.",
    )
    prompt = _build_planner_prompt(req)
    assert "Skill Pack Context" in prompt
    assert "Test skill pack content here." in prompt


def test_planner_prompt_without_skill_pack_context() -> None:
    """_build_planner_prompt omits skill section when context is empty."""
    from owlmind.agent.cycle import _build_planner_prompt
    from owlmind.agent.schemas import PlannerRequest

    req = PlannerRequest(
        run_id="test-run-002",
        iteration=1,
        goal="Build something",
        skill_pack_context="",
    )
    prompt = _build_planner_prompt(req)
    assert "Skill Pack Context" not in prompt


def test_install_replaces_existing_dest(tmp_path: Path, fake_pack_dir: Path) -> None:
    """Line 67: shutil.rmtree(dest) — existing dest is removed before copy."""
    workspace = tmp_path / "my_workspace"
    workspace.mkdir()

    # Pre-create dest with a stale file
    dest = workspace / "skill-packs" / "test_pack"
    dest.mkdir(parents=True)
    stale_file = dest / "stale_file.txt"
    stale_file.write_text("stale content")

    install("test_pack", workspace, base_dir=fake_pack_dir)

    # dest should have been replaced — stale file must be gone
    assert dest.is_dir()
    assert not stale_file.exists()
    assert (dest / "pack.yaml").exists()


def test_install_ingest_dir_skips_missing_directory(tmp_path: Path, fake_pack_dir: Path) -> None:
    """Line 77: _ingest_dir returns early when directory does not exist."""
    import yaml as _yaml

    # Create a pack without knowledge/, prompts/, or workflows/ subdirs
    packs_dir = tmp_path / "sparse-packs"
    pack_dir = packs_dir / "sparse_pack"
    pack_dir.mkdir(parents=True)
    manifest = {
        "id": "sparse_pack",
        "name": "Sparse Pack",
        "version": "0.1.0",
        "knowledge_dir": "knowledge/sparse_pack",  # does not exist
    }
    (pack_dir / "pack.yaml").write_text(_yaml.dump(manifest))
    # No prompts/, workflows/, or knowledge/ dirs exist

    workspace = tmp_path / "ws_sparse"
    workspace.mkdir()

    result = install("sparse_pack", workspace, base_dir=packs_dir)

    # Should complete without errors and report zero ingested docs
    assert result["pack_id"] == "sparse_pack"
    assert result["ingested_docs"] == 0
