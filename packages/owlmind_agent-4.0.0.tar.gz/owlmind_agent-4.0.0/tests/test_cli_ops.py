"""Tests for FS72 — CLI ops commands (github, ci, security, setup, goals)."""

from __future__ import annotations

import os
from pathlib import Path
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from owlmind.cli import app

runner = CliRunner()


def _mock_scan_result(ok: bool = True, findings_count: int = 0) -> MagicMock:
    """Build a mock scan result."""
    result = MagicMock()
    result.ok = ok
    result.files_scanned = 10
    findings = []
    for i in range(findings_count):
        f = MagicMock()
        f.file = f"src/file_{i}.py"
        f.line = i + 1
        f.pattern_name = "AWS_KEY"
        f.snippet = "AKIAIOSFODNN7EXAMPLE"
        findings.append(f)
    result.findings = findings
    return result


class TestGithubPrList:
    def test_pr_list_empty(self) -> None:
        """github pr-list with no PRs → exit 0, 'No PRs' in output."""
        with patch("owlmind.github.pr_list", return_value=[]):
            result = runner.invoke(app, ["github", "pr-list"])

        assert result.exit_code == 0
        assert "No PRs" in result.output

    def test_pr_list_with_prs(self) -> None:
        """github pr-list with PRs → exit 0, table rendered."""
        mock_prs = [
            {
                "number": 42,
                "title": "Fix authentication bug",
                "headRefName": "feat/auth",
                "state": "OPEN",
            },
            {"number": 43, "title": "Add tests", "headRefName": "feat/tests", "state": "OPEN"},
        ]

        with patch("owlmind.github.pr_list", return_value=mock_prs):
            result = runner.invoke(app, ["github", "pr-list"])

        assert result.exit_code == 0, result.output


class TestGithubPrCreate:
    def test_pr_create_requires_yes(self) -> None:
        """github pr-create without --yes → exit 2, approval message in output."""
        result = runner.invoke(app, ["github", "pr-create", "--title", "Test PR"])

        assert result.exit_code == 2
        assert "--yes" in result.output


class TestCiRuns:
    def test_ci_runs_empty(self) -> None:
        """ci runs with no results → exit 0, 'No runs' in output."""
        with patch("owlmind.ci.list_runs", return_value=[]):
            result = runner.invoke(app, ["ci", "runs"])

        assert result.exit_code == 0
        assert "No runs" in result.output


class TestSecurityScan:
    def test_scan_no_findings(self, tmp_path: Path) -> None:
        """security scan with clean result → exit 0, 'No secrets' in output."""
        mock_result = _mock_scan_result(ok=True)

        with patch("owlmind.security.scan_secrets", return_value=mock_result):
            result = runner.invoke(app, ["security", "scan", "--path", str(tmp_path)])

        assert result.exit_code == 0, result.output
        assert "No secrets" in result.output

    def test_scan_with_findings_fail_flag(self, tmp_path: Path) -> None:
        """security scan with findings + --fail-on-findings → exit 1."""
        mock_result = _mock_scan_result(ok=False, findings_count=1)

        with patch("owlmind.security.scan_secrets", return_value=mock_result):
            result = runner.invoke(
                app,
                ["security", "scan", "--path", str(tmp_path), "--fail-on-findings"],
            )

        assert result.exit_code == 1


class TestSetupInit:
    def test_setup_init_ok(self, tmp_path: Path) -> None:
        """setup init → exit 0, created dirs/files printed."""
        mock_result = MagicMock()
        mock_result.created_dirs = ["runs", "sessions"]
        mock_result.created_files = [".env.example"]
        mock_result.skipped = []

        with patch("owlmind.setup.setup_init", return_value=mock_result):
            result = runner.invoke(app, ["setup", "init", "--workspace", str(tmp_path)])

        assert result.exit_code == 0, result.output


class TestGoalsTemplates:
    def test_templates_ok(self) -> None:
        """goals templates → exit 0."""
        with (
            patch("owlmind.templates.list_templates", return_value=["bugfix", "feature"]),
            patch("owlmind.templates.get_template_info", return_value="Template description"),
        ):
            result = runner.invoke(app, ["goals", "templates"])

        assert result.exit_code == 0, result.output


# ===========================================================================
# pr-view
# ===========================================================================


class TestGithubPrView:
    def _make_pr_info(self) -> MagicMock:
        info = MagicMock()
        info.number = 42
        info.title = "Fix the auth bug"
        info.state = "OPEN"
        info.head_branch = "feat/auth"
        info.base_branch = "main"
        info.additions = 10
        info.deletions = 3
        info.mergeable = "MERGEABLE"
        info.url = "https://github.com/org/repo/pull/42"
        return info

    def test_pr_view_success(self) -> None:
        """github pr-view with valid PR number → exit 0, PR info printed."""
        with patch("owlmind.github.pr_view", return_value=self._make_pr_info()):
            result = runner.invoke(app, ["github", "pr-view", "--pr", "42"])

        assert result.exit_code == 0, result.output
        assert "42" in result.output
        assert "Fix the auth bug" in result.output
        assert "OPEN" in result.output

    def test_pr_view_shows_branch_and_changes(self) -> None:
        """github pr-view prints branch arrows and change counts."""
        with patch("owlmind.github.pr_view", return_value=self._make_pr_info()):
            result = runner.invoke(app, ["github", "pr-view", "--pr", "42"])

        assert result.exit_code == 0, result.output
        assert "feat/auth" in result.output
        assert "main" in result.output
        assert "+10" in result.output
        assert "-3" in result.output

    def test_pr_view_runtime_error_exits_1(self) -> None:
        """github pr-view when RuntimeError raised → exit 1, error in output."""
        with patch("owlmind.github.pr_view", side_effect=RuntimeError("PR not found")):
            result = runner.invoke(app, ["github", "pr-view", "--pr", "999"])

        assert result.exit_code == 1
        assert "PR not found" in result.output


# ===========================================================================
# pr-merge
# ===========================================================================


class TestGithubPrMerge:
    def test_pr_merge_requires_yes(self) -> None:
        """github pr-merge without --yes → exit 2, approval message."""
        result = runner.invoke(app, ["github", "pr-merge", "--pr", "42"])

        assert result.exit_code == 2
        assert "--yes" in result.output

    def test_pr_merge_success(self) -> None:
        """github pr-merge --yes → exit 0, merged message."""
        mock_result = MagicMock()
        mock_result.ok = True
        mock_result.error = ""

        with patch("owlmind.github.pr_merge", return_value=mock_result):
            result = runner.invoke(app, ["github", "pr-merge", "--pr", "42", "--yes"])

        assert result.exit_code == 0, result.output
        assert "merged" in result.output.lower()

    def test_pr_merge_failure(self) -> None:
        """github pr-merge when merge fails → exit 1, error in output."""
        mock_result = MagicMock()
        mock_result.ok = False
        mock_result.error = "Merge conflict detected"

        with patch("owlmind.github.pr_merge", return_value=mock_result):
            result = runner.invoke(app, ["github", "pr-merge", "--pr", "42", "--yes"])

        assert result.exit_code == 1
        assert "Merge conflict detected" in result.output

    def test_pr_merge_custom_method(self) -> None:
        """github pr-merge --method rebase passes method arg to pr_merge."""
        mock_result = MagicMock()
        mock_result.ok = True
        mock_result.error = ""

        with patch("owlmind.github.pr_merge", return_value=mock_result) as mock_fn:
            runner.invoke(app, ["github", "pr-merge", "--pr", "7", "--yes", "--method", "rebase"])

        mock_fn.assert_called_once()
        _, kwargs = mock_fn.call_args
        assert kwargs.get("method") == "rebase"


# ===========================================================================
# ci status
# ===========================================================================


class TestCiStatus:
    def _make_run_data(self, jobs: list[dict[str, str]] | None = None) -> dict[str, object]:
        return {
            "name": "CI Pipeline",
            "status": "completed",
            "conclusion": "success",
            "headBranch": "main",
            "jobs": jobs or [],
        }

    def test_ci_status_success(self) -> None:
        """ci status --run-id → exit 0, run name/status printed."""
        with patch("owlmind.ci.run_status", return_value=self._make_run_data()):
            result = runner.invoke(app, ["ci", "status", "--run-id", "12345"])

        assert result.exit_code == 0, result.output
        assert "CI Pipeline" in result.output
        assert "completed" in result.output

    def test_ci_status_with_jobs(self) -> None:
        """ci status --run-id with jobs list → jobs printed."""
        jobs = [
            {"name": "lint", "conclusion": "success"},
            {"name": "tests", "conclusion": "failure"},
        ]
        with patch("owlmind.ci.run_status", return_value=self._make_run_data(jobs=jobs)):
            result = runner.invoke(app, ["ci", "status", "--run-id", "12345"])

        assert result.exit_code == 0, result.output
        assert "lint" in result.output
        assert "tests" in result.output

    def test_ci_status_runtime_error_exits_1(self) -> None:
        """ci status when RuntimeError raised → exit 1."""
        with patch("owlmind.ci.run_status", side_effect=RuntimeError("Run not found")):
            result = runner.invoke(app, ["ci", "status", "--run-id", "99999"])

        assert result.exit_code == 1
        assert "Run not found" in result.output


# ===========================================================================
# ci logs
# ===========================================================================


class TestCiLogs:
    def test_ci_logs_success(self) -> None:
        """ci logs --run-id → exit 0, log lines printed."""
        log_text = "\n".join(f"line {i}" for i in range(5))
        with patch("owlmind.ci.run_logs", return_value=log_text):
            result = runner.invoke(app, ["ci", "logs", "--run-id", "12345"])

        assert result.exit_code == 0, result.output
        assert "line 0" in result.output
        assert "line 4" in result.output

    def test_ci_logs_tail_truncates(self) -> None:
        """ci logs --tail 2 prints only the last 2 lines."""
        log_text = "\n".join(f"line {i}" for i in range(10))
        with patch("owlmind.ci.run_logs", return_value=log_text):
            result = runner.invoke(app, ["ci", "logs", "--run-id", "12345", "--tail", "2"])

        assert result.exit_code == 0, result.output
        assert "line 8" in result.output
        assert "line 9" in result.output
        assert "line 0" not in result.output

    def test_ci_logs_runtime_error_exits_1(self) -> None:
        """ci logs when RuntimeError raised → exit 1."""
        with patch("owlmind.ci.run_logs", side_effect=RuntimeError("No logs available")):
            result = runner.invoke(app, ["ci", "logs", "--run-id", "99999"])

        assert result.exit_code == 1
        assert "No logs available" in result.output


# ===========================================================================
# release changelog
# ===========================================================================


class TestReleaseChangelog:
    def test_release_changelog_success(self, tmp_path: Path) -> None:
        """release changelog → exit 0, output path printed."""
        changelog_path = tmp_path / "CHANGELOG.md"
        with patch("owlmind.release.generate_changelog", return_value=changelog_path):
            result = runner.invoke(app, ["release", "changelog"])

        assert result.exit_code == 0, result.output
        # Rich may line-wrap long paths; join output lines for full-path check
        assert "CHANGELOG.md" in result.output.replace("\n", "")

    def test_release_changelog_since_tag(self, tmp_path: Path) -> None:
        """release changelog --since v0.18.0 passes since_tag arg."""
        changelog_path = tmp_path / "CHANGELOG.md"
        with patch("owlmind.release.generate_changelog", return_value=changelog_path) as mock_fn:
            runner.invoke(app, ["release", "changelog", "--since", "v0.18.0"])

        mock_fn.assert_called_once()
        _, kwargs = mock_fn.call_args
        assert kwargs.get("since_tag") == "v0.18.0"


# ===========================================================================
# dashboard index
# ===========================================================================


class TestDashboardIndex:
    def test_dashboard_index_success(self, tmp_path: Path) -> None:
        """dashboard index → exit 0, output path printed."""
        index_path = tmp_path / "dashboards" / "index.html"
        with patch("owlmind.dashboard_index.build_index", return_value=index_path):
            result = runner.invoke(app, ["dashboard", "index"])

        assert result.exit_code == 0, result.output
        # Rich may line-wrap long paths; join output lines for full-path check
        assert "index.html" in result.output.replace("\n", "")

    def test_dashboard_index_custom_out(self, tmp_path: Path) -> None:
        """dashboard index --out custom.html passes the path to build_index."""
        custom_out = tmp_path / "custom.html"
        with patch("owlmind.dashboard_index.build_index", return_value=custom_out) as mock_fn:
            runner.invoke(app, ["dashboard", "index", "--out", str(custom_out)])

        mock_fn.assert_called_once()
        call_args = mock_fn.call_args[0]
        # First positional arg is the output path
        assert str(custom_out) in str(call_args[0])


# ===========================================================================
# owlmind up
# ===========================================================================


class TestOwlMindUp:
    def _make_setup_result(
        self,
        *,
        dirs: list[str] | None = None,
        files: list[str] | None = None,
        skipped: list[str] | None = None,
    ) -> MagicMock:
        r = MagicMock()
        r.created_dirs = dirs or []
        r.created_files = files or []
        r.skipped = skipped or []
        return r

    def _make_doctor_result(
        self, fixes: list[MagicMock] | None = None, warnings: list[str] | None = None
    ) -> MagicMock:
        r = MagicMock()
        r.fixes = fixes or []
        r.warnings = warnings or []
        return r

    def test_up_fresh_workspace(self, tmp_path: Path) -> None:
        """owlmind up on fresh workspace → exit 0, setup/doctor/scan sections printed."""
        setup_result = self._make_setup_result(dirs=["runs", "sessions"], files=[".env.example"])
        doctor_result = self._make_doctor_result()
        scan_result = _mock_scan_result(ok=True)

        with (
            patch("owlmind.setup.setup_init", return_value=setup_result),
            patch("owlmind.setup.doctor_fix", return_value=doctor_result),
            patch("owlmind.security.scan_secrets", return_value=scan_result),
        ):
            result = runner.invoke(app, ["up", "--workspace", str(tmp_path)])

        assert result.exit_code == 0, result.output
        assert "Setup init" in result.output
        assert "Doctor fix" in result.output
        assert "Security scan" in result.output

    def test_up_already_initialized(self, tmp_path: Path) -> None:
        """owlmind up on already-initialized workspace → 'Already initialized' hint."""
        setup_result = self._make_setup_result(skipped=["runs", "sessions"])
        doctor_result = self._make_doctor_result()
        scan_result = _mock_scan_result(ok=True)

        with (
            patch("owlmind.setup.setup_init", return_value=setup_result),
            patch("owlmind.setup.doctor_fix", return_value=doctor_result),
            patch("owlmind.security.scan_secrets", return_value=scan_result),
        ):
            result = runner.invoke(app, ["up", "--workspace", str(tmp_path)])

        assert result.exit_code == 0, result.output
        assert "Already initialized" in result.output

    def test_up_with_doctor_fixes(self, tmp_path: Path) -> None:
        """owlmind up with doctor fixes → fixed items printed."""
        setup_result = self._make_setup_result()
        fix = MagicMock()
        fix.fixed = True
        fix.name = "missing_env"
        fix.detail = "Created .env.example"
        doctor_result = self._make_doctor_result(fixes=[fix])
        scan_result = _mock_scan_result(ok=True)

        with (
            patch("owlmind.setup.setup_init", return_value=setup_result),
            patch("owlmind.setup.doctor_fix", return_value=doctor_result),
            patch("owlmind.security.scan_secrets", return_value=scan_result),
        ):
            result = runner.invoke(app, ["up", "--workspace", str(tmp_path)])

        assert result.exit_code == 0, result.output
        assert "missing_env" in result.output

    def test_up_scan_with_findings(self, tmp_path: Path) -> None:
        """owlmind up with scan findings → findings count printed, still exit 0."""
        setup_result = self._make_setup_result()
        doctor_result = self._make_doctor_result()
        scan_result = _mock_scan_result(ok=False, findings_count=2)

        with (
            patch("owlmind.setup.setup_init", return_value=setup_result),
            patch("owlmind.setup.doctor_fix", return_value=doctor_result),
            patch("owlmind.security.scan_secrets", return_value=scan_result),
        ):
            result = runner.invoke(app, ["up", "--workspace", str(tmp_path)])

        assert result.exit_code == 0, result.output
        assert "findings" in result.output

    def test_up_telegram_no_token(self, tmp_path: Path) -> None:
        """owlmind up --telegram without TELEGRAM_BOT_TOKEN → warning printed."""
        setup_result = self._make_setup_result()
        doctor_result = self._make_doctor_result()
        scan_result = _mock_scan_result(ok=True)

        env_no_token = {k: v for k, v in os.environ.items() if k != "TELEGRAM_BOT_TOKEN"}
        with (
            patch("owlmind.setup.setup_init", return_value=setup_result),
            patch("owlmind.setup.doctor_fix", return_value=doctor_result),
            patch("owlmind.security.scan_secrets", return_value=scan_result),
            patch("dotenv.load_dotenv"),  # prevent .env from restoring TELEGRAM_BOT_TOKEN
            patch.dict("os.environ", env_no_token, clear=True),
        ):
            result = runner.invoke(app, ["up", "--workspace", str(tmp_path), "--telegram"])

        assert result.exit_code == 0, result.output
        assert "TELEGRAM_BOT_TOKEN" in result.output

    def test_up_shows_next_steps(self, tmp_path: Path) -> None:
        """owlmind up prints recommended next commands."""
        setup_result = self._make_setup_result()
        doctor_result = self._make_doctor_result()
        scan_result = _mock_scan_result(ok=True)

        with (
            patch("owlmind.setup.setup_init", return_value=setup_result),
            patch("owlmind.setup.doctor_fix", return_value=doctor_result),
            patch("owlmind.security.scan_secrets", return_value=scan_result),
        ):
            result = runner.invoke(app, ["up", "--workspace", str(tmp_path)])

        assert result.exit_code == 0, result.output
        assert "owlmind session start" in result.output


# ===========================================================================
# Lines 132-140: github pr-create with --yes (success + failure)
# ===========================================================================


class TestGithubPrCreateApproved:
    def test_pr_create_success(self) -> None:
        """github pr-create --yes → exit 0, PR number in output."""
        mock_result = MagicMock()
        mock_result.ok = True
        mock_result.pr_number = 101
        mock_result.url = "https://github.com/org/repo/pull/101"

        with patch("owlmind.github.pr_create", return_value=mock_result):
            result = runner.invoke(
                app,
                ["github", "pr-create", "--title", "My PR", "--yes"],
            )

        assert result.exit_code == 0, result.output
        assert "101" in result.output
        assert "https://github.com" in result.output

    def test_pr_create_failure(self) -> None:
        """github pr-create --yes when pr_create fails → exit 1, error printed."""
        mock_result = MagicMock()
        mock_result.ok = False
        mock_result.error = "Branch already has a PR"

        with patch("owlmind.github.pr_create", return_value=mock_result):
            result = runner.invoke(
                app,
                ["github", "pr-create", "--title", "My PR", "--yes"],
            )

        assert result.exit_code == 1
        assert "Branch already has a PR" in result.output

    def test_pr_create_passes_draft_and_base(self) -> None:
        """github pr-create --draft --base develop passes args to pr_create."""
        mock_result = MagicMock()
        mock_result.ok = True
        mock_result.pr_number = 55
        mock_result.url = "https://github.com/org/repo/pull/55"

        with patch("owlmind.github.pr_create", return_value=mock_result) as mock_fn:
            runner.invoke(
                app,
                [
                    "github",
                    "pr-create",
                    "--title",
                    "Draft",
                    "--base",
                    "develop",
                    "--draft",
                    "--yes",
                ],
            )

        mock_fn.assert_called_once()
        _, kwargs = mock_fn.call_args
        assert kwargs.get("base") == "develop"
        assert kwargs.get("draft") is True


# ===========================================================================
# Lines 153-180: github create-pr (from run / from session)
# ===========================================================================


class TestGithubCreatePrFromResult:
    def test_create_pr_no_args_exits_2(self) -> None:
        """github create-pr with no --run-id or --session-id → exit 2."""
        result = runner.invoke(app, ["github", "create-pr"])
        assert result.exit_code == 2
        assert "run-id" in result.output.lower() or "session-id" in result.output.lower()

    def test_create_pr_both_args_exits_2(self) -> None:
        """github create-pr with both --run-id and --session-id → exit 2."""
        result = runner.invoke(
            app,
            ["github", "create-pr", "--run-id", "abc", "--session-id", "xyz"],
        )
        assert result.exit_code == 2

    def test_create_pr_from_run_success(self) -> None:
        """github create-pr --run-id → exit 0, PR number in output."""
        with patch(
            "owlmind.github_pr.create_pr_from_run",
            return_value={"created": True, "number": 77, "url": "https://github.com/pr/77"},
        ):
            result = runner.invoke(app, ["github", "create-pr", "--run-id", "run-abc"])

        assert result.exit_code == 0, result.output
        assert "77" in result.output

    def test_create_pr_from_run_failure(self) -> None:
        """github create-pr --run-id when create fails → exit 1, error in output."""
        with patch(
            "owlmind.github_pr.create_pr_from_run",
            return_value={"created": False, "error": "Run artefact missing"},
        ):
            result = runner.invoke(app, ["github", "create-pr", "--run-id", "run-bad"])

        assert result.exit_code == 1
        assert "Run artefact missing" in result.output

    def test_create_pr_from_session_success(self) -> None:
        """github create-pr --session-id → exit 0, PR URL in output."""
        with patch(
            "owlmind.github_pr.create_pr_from_session",
            return_value={
                "created": True,
                "number": 88,
                "url": "https://github.com/pr/88",
            },
        ):
            result = runner.invoke(app, ["github", "create-pr", "--session-id", "sess-xyz"])

        assert result.exit_code == 0, result.output
        assert "https://github.com/pr/88" in result.output

    def test_create_pr_from_session_failure(self) -> None:
        """github create-pr --session-id when create fails → exit 1."""
        with patch(
            "owlmind.github_pr.create_pr_from_session",
            return_value={"created": False, "error": "Session not found"},
        ):
            result = runner.invoke(app, ["github", "create-pr", "--session-id", "sess-bad"])

        assert result.exit_code == 1
        assert "Session not found" in result.output


# ===========================================================================
# Lines 228-248: ci runs with actual run objects (success/failure conclusions)
# ===========================================================================


class TestCiRunsWithData:
    def _make_run(
        self, run_id: int, name: str, status: str, conclusion: str, branch: str
    ) -> MagicMock:
        r = MagicMock()
        r.id = run_id
        r.name = name
        r.status = status
        r.conclusion = conclusion
        r.head_branch = branch
        return r

    def test_ci_runs_success_conclusion(self) -> None:
        """ci runs with success conclusion → exit 0, run name in table."""
        runs = [self._make_run(1, "Build and Test", "completed", "success", "main")]

        with patch("owlmind.ci.list_runs", return_value=runs):
            result = runner.invoke(app, ["ci", "runs"])

        assert result.exit_code == 0, result.output
        assert "Build and Test" in result.output

    def test_ci_runs_failure_conclusion(self) -> None:
        """ci runs with failure conclusion → exit 0, run rendered in red style path."""
        runs = [self._make_run(2, "Failing Job", "completed", "failure", "feat/bug")]

        with patch("owlmind.ci.list_runs", return_value=runs):
            result = runner.invoke(app, ["ci", "runs"])

        assert result.exit_code == 0, result.output
        assert "Failing Job" in result.output

    def test_ci_runs_other_conclusion(self) -> None:
        """ci runs with cancelled conclusion → dim style path covered."""
        runs = [self._make_run(3, "Cancelled", "completed", "cancelled", "main")]

        with patch("owlmind.ci.list_runs", return_value=runs):
            result = runner.invoke(app, ["ci", "runs"])

        assert result.exit_code == 0, result.output
        assert "Cancelled" in result.output

    def test_ci_runs_custom_limit_and_branch(self) -> None:
        """ci runs --limit 5 --branch feature → args forwarded to list_runs."""
        with patch("owlmind.ci.list_runs", return_value=[]) as mock_fn:
            runner.invoke(app, ["ci", "runs", "--limit", "5", "--branch", "feature"])

        mock_fn.assert_called_once()
        _, kwargs = mock_fn.call_args
        assert kwargs.get("limit") == 5
        assert kwargs.get("branch") == "feature"


# ===========================================================================
# Lines 308-322: ci fix-session (success, ValueError, RuntimeError)
# ===========================================================================


class TestCiFixSession:
    def test_fix_session_success(self, tmp_path: Path) -> None:
        """ci fix-session --run-id → exit 0, goals file path printed."""
        goals_path = tmp_path / "fix_goals.yaml"

        with patch("owlmind.ci.generate_fix_goals", return_value=goals_path):
            result = runner.invoke(app, ["ci", "fix-session", "--run-id", "12345"])

        assert result.exit_code == 0, result.output
        assert "fix_goals.yaml" in result.output.replace("\n", "")
        assert "owlmind session start" in result.output

    def test_fix_session_value_error_exits_1(self) -> None:
        """ci fix-session when ValueError raised → exit 1, yellow warning."""
        with patch(
            "owlmind.ci.generate_fix_goals",
            side_effect=ValueError("No failed jobs found"),
        ):
            result = runner.invoke(app, ["ci", "fix-session", "--run-id", "12345"])

        assert result.exit_code == 1
        assert "No failed jobs found" in result.output

    def test_fix_session_runtime_error_exits_1(self) -> None:
        """ci fix-session when RuntimeError raised → exit 1, red error."""
        with patch(
            "owlmind.ci.generate_fix_goals",
            side_effect=RuntimeError("gh CLI not found"),
        ):
            result = runner.invoke(app, ["ci", "fix-session", "--run-id", "12345"])

        assert result.exit_code == 1
        assert "gh CLI not found" in result.output


# ===========================================================================
# Lines 371-381: security install-hooks (success + FileNotFoundError)
# ===========================================================================


class TestSecurityInstallHooks:
    def test_install_hooks_success(self, tmp_path: Path) -> None:
        """security install-hooks → exit 0, installed hooks listed."""
        hooks = [".git/hooks/pre-commit", ".git/hooks/commit-msg"]

        with patch("owlmind.security.install_hooks", return_value=hooks):
            result = runner.invoke(app, ["security", "install-hooks", "--repo", str(tmp_path)])

        assert result.exit_code == 0, result.output
        assert "pre-commit" in result.output

    def test_install_hooks_file_not_found_exits_1(self, tmp_path: Path) -> None:
        """security install-hooks when .git missing → exit 1, error printed."""
        with patch(
            "owlmind.security.install_hooks",
            side_effect=FileNotFoundError("Not a git repo"),
        ):
            result = runner.invoke(app, ["security", "install-hooks", "--repo", str(tmp_path)])

        assert result.exit_code == 1
        assert "Not a git repo" in result.output


# ===========================================================================
# Lines 411-430: release verify (pass + fail)
# ===========================================================================


class TestReleaseVerify:
    def _make_check(self, name: str, ok: bool, detail: str = "") -> MagicMock:
        c = MagicMock()
        c.name = name
        c.ok = ok
        c.detail = detail or ("All good" if ok else "Error")
        return c

    def _make_report(self, ok: bool, version: str = "1.0.0") -> MagicMock:
        r = MagicMock()
        r.ok = ok
        r.version = version
        r.checks = []
        return r

    def test_release_verify_all_pass(self) -> None:
        """release verify with all checks passing → exit 0, READY printed."""
        report = self._make_report(ok=True, version="2.0.0")
        report.checks = [
            self._make_check("version", ok=True),
            self._make_check("tests", ok=True),
            self._make_check("lint", ok=True),
        ]

        with patch("owlmind.release.verify_release", return_value=report):
            result = runner.invoke(app, ["release", "verify"])

        assert result.exit_code == 0, result.output
        assert "READY" in result.output
        assert "2.0.0" in result.output

    def test_release_verify_some_fail(self) -> None:
        """release verify with failing check → exit 1, NOT ready printed."""
        report = self._make_report(ok=False, version="2.0.0")
        report.checks = [
            self._make_check("version", ok=True),
            self._make_check("tests", ok=False, detail="2 tests failed"),
        ]

        with patch("owlmind.release.verify_release", return_value=report):
            result = runner.invoke(app, ["release", "verify"])

        assert result.exit_code == 1
        assert "NOT ready" in result.output
        assert "2 tests failed" in result.output

    def test_release_verify_skip_tests_and_lint(self) -> None:
        """release verify --skip-tests --skip-lint forwards flags to verify_release."""
        report = self._make_report(ok=True)

        with patch("owlmind.release.verify_release", return_value=report) as mock_fn:
            runner.invoke(app, ["release", "verify", "--skip-tests", "--skip-lint"])

        mock_fn.assert_called_once()
        _, kwargs = mock_fn.call_args
        assert kwargs.get("run_tests") is False
        assert kwargs.get("run_lint") is False


# ===========================================================================
# Lines 439-452: release bundle
# ===========================================================================


class TestReleaseBundle:
    def test_release_bundle_ok(self, tmp_path: Path) -> None:
        """release bundle success → exit 0, 'successfully' in output."""
        bundle_result = {
            "ok": True,
            "version": "1.5.0",
            "out_dir": str(tmp_path),
            "artifacts": {"changelog": str(tmp_path / "CHANGELOG.md")},
        }

        with patch("owlmind.release.create_release_bundle", return_value=bundle_result):
            result = runner.invoke(app, ["release", "bundle"])

        assert result.exit_code == 0, result.output
        assert "successfully" in result.output.lower()
        assert "1.5.0" in result.output

    def test_release_bundle_partial_failure(self, tmp_path: Path) -> None:
        """release bundle with ok=False → exit 0 but warning about failed checks."""
        bundle_result = {
            "ok": False,
            "version": "1.5.0",
            "out_dir": str(tmp_path),
            "artifacts": {"changelog": str(tmp_path / "CHANGELOG.md")},
        }

        with patch("owlmind.release.create_release_bundle", return_value=bundle_result):
            result = runner.invoke(app, ["release", "bundle"])

        assert result.exit_code == 0, result.output
        assert "some checks failed" in result.output.lower()

    def test_release_bundle_multiple_artifacts(self, tmp_path: Path) -> None:
        """release bundle prints each artifact name and path."""
        bundle_result = {
            "ok": True,
            "version": "2.0.0",
            "out_dir": str(tmp_path),
            "artifacts": {
                "changelog": str(tmp_path / "CHANGELOG.md"),
                "report": str(tmp_path / "report.json"),
            },
        }

        with patch("owlmind.release.create_release_bundle", return_value=bundle_result):
            result = runner.invoke(app, ["release", "bundle"])

        assert result.exit_code == 0, result.output
        assert "changelog" in result.output
        assert "report" in result.output


# ===========================================================================
# Lines 475: setup init skipped items printed
# ===========================================================================


class TestSetupInitSkipped:
    def test_setup_init_skipped_items_printed(self, tmp_path: Path) -> None:
        """setup init with skipped items → 'Exists:' printed for each."""
        mock_result = MagicMock()
        mock_result.created_dirs = []
        mock_result.created_files = []
        mock_result.skipped = ["runs", "sessions", ".env.example"]

        with patch("owlmind.setup.setup_init", return_value=mock_result):
            result = runner.invoke(app, ["setup", "init", "--workspace", str(tmp_path)])

        assert result.exit_code == 0, result.output
        assert "Exists:" in result.output
        assert "runs" in result.output


# ===========================================================================
# Lines 489-516: setup install-hooks and setup doctor
# ===========================================================================


class TestSetupHooksCmd:
    def test_setup_install_hooks_success(self, tmp_path: Path) -> None:
        """setup install-hooks → exit 0, installed hooks listed."""
        hooks = [".git/hooks/pre-commit"]

        with patch("owlmind.security.install_hooks", return_value=hooks):
            result = runner.invoke(app, ["setup", "install-hooks", "--repo", str(tmp_path)])

        assert result.exit_code == 0, result.output
        assert "pre-commit" in result.output

    def test_setup_install_hooks_empty_list(self, tmp_path: Path) -> None:
        """setup install-hooks with no hooks returned → exit 0, no error."""
        with patch("owlmind.security.install_hooks", return_value=[]):
            result = runner.invoke(app, ["setup", "install-hooks", "--repo", str(tmp_path)])

        assert result.exit_code == 0, result.output


class TestSetupDoctorCmd:
    def test_setup_doctor_clean(self, tmp_path: Path) -> None:
        """setup doctor with clean scan → exit 0, 'Clean' printed."""
        scan = _mock_scan_result(ok=True)

        with patch("owlmind.security.scan_secrets", return_value=scan):
            result = runner.invoke(app, ["setup", "doctor", "--workspace", str(tmp_path)])

        assert result.exit_code == 0, result.output
        assert "Clean" in result.output

    def test_setup_doctor_with_findings(self, tmp_path: Path) -> None:
        """setup doctor with findings → findings count and file:line printed."""
        scan = _mock_scan_result(ok=False, findings_count=3)

        with patch("owlmind.security.scan_secrets", return_value=scan):
            result = runner.invoke(app, ["setup", "doctor", "--workspace", str(tmp_path)])

        assert result.exit_code == 0, result.output
        assert "findings" in result.output.lower() or "3" in result.output


# ===========================================================================
# Lines 542-553: goals init (success + ValueError)
# ===========================================================================


class TestGoalsInit:
    def test_goals_init_success(self, tmp_path: Path) -> None:
        """goals init --template bugfix → exit 0, goals file written."""
        out_file = tmp_path / "goals.yaml"

        with patch("owlmind.templates.render_template", return_value="goals: []"):
            result = runner.invoke(
                app,
                ["goals", "init", "--template", "bugfix", "--out", str(out_file)],
            )

        assert result.exit_code == 0, result.output
        assert "goals.yaml" in result.output.replace("\n", "")

    def test_goals_init_invalid_template_exits_1(self, tmp_path: Path) -> None:
        """goals init --template nonexistent → exit 1, error in output."""
        out_file = tmp_path / "goals.yaml"

        with patch(
            "owlmind.templates.render_template",
            side_effect=ValueError("Unknown template: nonexistent"),
        ):
            result = runner.invoke(
                app,
                ["goals", "init", "--template", "nonexistent", "--out", str(out_file)],
            )

        assert result.exit_code == 1
        assert "Unknown template" in result.output

    def test_goals_init_creates_parent_dirs(self, tmp_path: Path) -> None:
        """goals init with nested out path → parent dirs created."""
        out_file = tmp_path / "subdir" / "goals.yaml"

        with patch("owlmind.templates.render_template", return_value="goals: []"):
            result = runner.invoke(
                app,
                ["goals", "init", "--template", "feature", "--out", str(out_file)],
            )

        assert result.exit_code == 0, result.output
        assert out_file.exists()


# ===========================================================================
# Lines 586-595: dashboard live
# ===========================================================================


class TestDashboardLive:
    def test_dashboard_live_starts(self) -> None:
        """dashboard live → exit 0, LiveDashboard.start() called once."""
        mock_dash = MagicMock()

        with patch("owlmind.tui.dashboard.LiveDashboard", return_value=mock_dash) as mock_cls:
            result = runner.invoke(app, ["dashboard", "live"])

        assert result.exit_code == 0, result.output
        mock_cls.assert_called_once()
        mock_dash.start.assert_called_once()

    def test_dashboard_live_custom_options(self) -> None:
        """dashboard live --interval 5 --max-ticks 3 passes args to LiveDashboard."""
        mock_dash = MagicMock()

        with patch("owlmind.tui.dashboard.LiveDashboard", return_value=mock_dash) as mock_cls:
            runner.invoke(
                app,
                ["dashboard", "live", "--interval", "5", "--max-ticks", "3"],
            )

        _, kwargs = mock_cls.call_args
        assert kwargs.get("refresh_interval") == 5
        assert kwargs.get("max_ticks") == 3


# ===========================================================================
# Lines 608-613: dashboard open (exists + not found)
# ===========================================================================


class TestDashboardOpen:
    def test_dashboard_open_existing_file(self, tmp_path: Path) -> None:
        """dashboard open --path <existing file> → prints resolved path and open hint."""
        html_file = tmp_path / "index.html"
        html_file.write_text("<html></html>")

        result = runner.invoke(app, ["dashboard", "open", "--path", str(html_file)])

        assert result.exit_code == 0, result.output
        assert "index.html" in result.output
        assert "open" in result.output.lower()

    def test_dashboard_open_missing_file(self, tmp_path: Path) -> None:
        """dashboard open with missing path → 'Not found' warning printed."""
        missing = tmp_path / "nonexistent.html"

        result = runner.invoke(app, ["dashboard", "open", "--path", str(missing)])

        assert result.exit_code == 0, result.output
        assert "Not found" in result.output
        assert "owlmind dashboard index" in result.output


# ===========================================================================
# Lines 644-646, 656, 659-661: owlmind up error branches
# ===========================================================================


class TestOwlMindUpErrorBranches:
    def _make_doctor_result(
        self, fixes: list[MagicMock] | None = None, warnings: list[str] | None = None
    ) -> MagicMock:
        r = MagicMock()
        r.fixes = fixes or []
        r.warnings = warnings or []
        return r

    def test_up_setup_init_exception(self, tmp_path: Path) -> None:
        """owlmind up when setup_init raises → error printed, continues."""
        doctor_result = self._make_doctor_result()
        scan_result = _mock_scan_result(ok=True)

        with (
            patch("owlmind.setup.setup_init", side_effect=OSError("disk full")),
            patch("owlmind.setup.doctor_fix", return_value=doctor_result),
            patch("owlmind.security.scan_secrets", return_value=scan_result),
        ):
            result = runner.invoke(app, ["up", "--workspace", str(tmp_path)])

        assert result.exit_code == 0, result.output
        assert "Setup init failed" in result.output
        assert "disk full" in result.output

    def test_up_doctor_fix_exception(self, tmp_path: Path) -> None:
        """owlmind up when doctor_fix raises → error printed, continues."""
        setup_result = MagicMock()
        setup_result.created_dirs = []
        setup_result.created_files = []
        setup_result.skipped = []
        scan_result = _mock_scan_result(ok=True)

        with (
            patch("owlmind.setup.setup_init", return_value=setup_result),
            patch("owlmind.setup.doctor_fix", side_effect=RuntimeError("doctor crashed")),
            patch("owlmind.security.scan_secrets", return_value=scan_result),
        ):
            result = runner.invoke(app, ["up", "--workspace", str(tmp_path)])

        assert result.exit_code == 0, result.output
        assert "Doctor fix failed" in result.output
        assert "doctor crashed" in result.output

    def test_up_doctor_warnings_printed(self, tmp_path: Path) -> None:
        """owlmind up with doctor warnings → warnings appear in output."""
        setup_result = MagicMock()
        setup_result.created_dirs = []
        setup_result.created_files = []
        setup_result.skipped = []
        doctor_result = self._make_doctor_result(warnings=["Missing .env file"])
        scan_result = _mock_scan_result(ok=True)

        with (
            patch("owlmind.setup.setup_init", return_value=setup_result),
            patch("owlmind.setup.doctor_fix", return_value=doctor_result),
            patch("owlmind.security.scan_secrets", return_value=scan_result),
        ):
            result = runner.invoke(app, ["up", "--workspace", str(tmp_path)])

        assert result.exit_code == 0, result.output
        assert "Missing .env file" in result.output

    def test_up_security_scan_exception(self, tmp_path: Path) -> None:
        """owlmind up when scan_secrets raises → error printed, continues."""
        setup_result = MagicMock()
        setup_result.created_dirs = []
        setup_result.created_files = []
        setup_result.skipped = []
        doctor_result = self._make_doctor_result()

        with (
            patch("owlmind.setup.setup_init", return_value=setup_result),
            patch("owlmind.setup.doctor_fix", return_value=doctor_result),
            patch("owlmind.security.scan_secrets", side_effect=OSError("permission denied")),
        ):
            result = runner.invoke(app, ["up", "--workspace", str(tmp_path)])

        assert result.exit_code == 0, result.output
        assert "Security scan failed" in result.output
        assert "permission denied" in result.output


# ===========================================================================
# Lines 675-677: owlmind up scan findings printed (up to 5)
# ===========================================================================


class TestOwlMindUpScanFindings:
    def test_up_scan_findings_details_printed(self, tmp_path: Path) -> None:
        """owlmind up with scan findings shows file:line pattern details."""
        setup_result = MagicMock()
        setup_result.created_dirs = []
        setup_result.created_files = []
        setup_result.skipped = []
        doctor_result = MagicMock()
        doctor_result.fixes = []
        doctor_result.warnings = []
        scan_result = _mock_scan_result(ok=False, findings_count=2)

        with (
            patch("owlmind.setup.setup_init", return_value=setup_result),
            patch("owlmind.setup.doctor_fix", return_value=doctor_result),
            patch("owlmind.security.scan_secrets", return_value=scan_result),
        ):
            result = runner.invoke(app, ["up", "--workspace", str(tmp_path)])

        assert result.exit_code == 0, result.output
        assert "src/file_0.py" in result.output
        assert "AWS_KEY" in result.output


# ===========================================================================
# Lines 688-698: owlmind up --telegram with token (bot start + errors)
# ===========================================================================


class TestOwlMindUpTelegram:
    def _base_patches(self) -> tuple[MagicMock, MagicMock, MagicMock]:
        setup_result = MagicMock()
        setup_result.created_dirs = []
        setup_result.created_files = []
        setup_result.skipped = []
        doctor_result = MagicMock()
        doctor_result.fixes = []
        doctor_result.warnings = []
        scan_result = _mock_scan_result(ok=True)
        return setup_result, doctor_result, scan_result

    def test_up_telegram_with_token_starts_bot(self, tmp_path: Path) -> None:
        """owlmind up --telegram with token → bot created and run_polling called."""
        setup_result, doctor_result, scan_result = self._base_patches()
        mock_bot_app = MagicMock()
        mock_create = MagicMock(return_value=mock_bot_app)

        with (
            patch("owlmind.setup.setup_init", return_value=setup_result),
            patch("owlmind.setup.doctor_fix", return_value=doctor_result),
            patch("owlmind.security.scan_secrets", return_value=scan_result),
            patch.dict("os.environ", {"TELEGRAM_BOT_TOKEN": "test-token-123"}),
            patch("owlmind.telegram_bot.create_operator_bot", mock_create),
        ):
            result = runner.invoke(app, ["up", "--workspace", str(tmp_path), "--telegram"])

        assert result.exit_code == 0, result.output
        mock_create.assert_called_once()
        call_kwargs = mock_create.call_args[1]
        assert call_kwargs["bot_token"] == "test-token-123"
        mock_bot_app.run_polling.assert_called_once()

    def test_up_telegram_import_error(self, tmp_path: Path) -> None:
        """owlmind up --telegram when owlmind.telegram_bot missing → install hint."""
        setup_result, doctor_result, scan_result = self._base_patches()

        with (
            patch("owlmind.setup.setup_init", return_value=setup_result),
            patch("owlmind.setup.doctor_fix", return_value=doctor_result),
            patch("owlmind.security.scan_secrets", return_value=scan_result),
            patch.dict("os.environ", {"TELEGRAM_BOT_TOKEN": "test-token-123"}),
            patch(
                "owlmind.telegram_bot.create_operator_bot",
                side_effect=ImportError("No module named 'telegram'"),
            ),
        ):
            result = runner.invoke(app, ["up", "--workspace", str(tmp_path), "--telegram"])

        assert result.exit_code == 0, result.output
        assert "Telegram not installed" in result.output
        assert "pip install" in result.output

    def test_up_telegram_bot_exception(self, tmp_path: Path) -> None:
        """owlmind up --telegram when bot raises generic exception → error printed."""
        setup_result, doctor_result, scan_result = self._base_patches()
        mock_bot_app = MagicMock()
        mock_bot_app.run_polling.side_effect = RuntimeError("connection refused")
        mock_create = MagicMock(return_value=mock_bot_app)

        with (
            patch("owlmind.setup.setup_init", return_value=setup_result),
            patch("owlmind.setup.doctor_fix", return_value=doctor_result),
            patch("owlmind.security.scan_secrets", return_value=scan_result),
            patch.dict("os.environ", {"TELEGRAM_BOT_TOKEN": "test-token-123"}),
            patch("owlmind.telegram_bot.create_operator_bot", mock_create),
        ):
            result = runner.invoke(app, ["up", "--workspace", str(tmp_path), "--telegram"])

        assert result.exit_code == 0, result.output
        assert "Telegram bot failed" in result.output
        assert "connection refused" in result.output
