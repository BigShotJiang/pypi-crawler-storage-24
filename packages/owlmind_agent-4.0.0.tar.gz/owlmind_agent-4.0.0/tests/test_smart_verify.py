"""Tests for FS56 — Smart Verify git-aware test selection."""

from __future__ import annotations

import subprocess
from pathlib import Path
from unittest.mock import patch

from owlmind.agent.smart_verify import _map_to_test_files, suggest_smart_verify

# ---------------------------------------------------------------------------
# suggest_smart_verify — no git repo
# ---------------------------------------------------------------------------


def test_suggest_smart_verify_no_git_returns_empty(tmp_path: Path) -> None:
    """Returns empty list when workspace is not a git repo."""
    result = suggest_smart_verify(tmp_path)
    assert result == []


# ---------------------------------------------------------------------------
# suggest_smart_verify — git repo with mocked diff
# ---------------------------------------------------------------------------


def test_suggest_smart_verify_no_changes_returns_full_suite(tmp_path: Path) -> None:
    """No changed files → pytest -q + ruff + mypy."""
    (tmp_path / ".git").mkdir()
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = _make_proc(returncode=0, stdout="")
        result = suggest_smart_verify(tmp_path)
    assert "pytest -q" in result
    assert "ruff check ." in result
    assert "mypy ." in result


def test_suggest_smart_verify_maps_src_to_test(tmp_path: Path) -> None:
    """Changed src file → maps to matching test file."""
    (tmp_path / ".git").mkdir()
    tests_dir = tmp_path / "tests"
    tests_dir.mkdir()
    (tests_dir / "test_auth.py").write_text("# test file")

    with patch("subprocess.run") as mock_run:
        mock_run.return_value = _make_proc(
            returncode=0,
            stdout="src/owlmind/auth.py\n",
        )
        result = suggest_smart_verify(tmp_path)

    assert any("test_auth.py" in cmd for cmd in result), f"Expected test_auth.py in {result}"
    assert "ruff check ." in result
    assert "mypy ." in result


def test_suggest_smart_verify_falls_back_to_full_suite_no_test_match(tmp_path: Path) -> None:
    """Changed file with no matching test → full pytest -q."""
    (tmp_path / ".git").mkdir()
    (tmp_path / "tests").mkdir()
    # No test_nomatch.py exists

    with patch("subprocess.run") as mock_run:
        mock_run.return_value = _make_proc(
            returncode=0,
            stdout="src/owlmind/nomatch.py\n",
        )
        result = suggest_smart_verify(tmp_path)

    assert "pytest -q" in result
    assert not any("test_nomatch" in cmd for cmd in result)


def test_suggest_smart_verify_many_files_full_suite(tmp_path: Path) -> None:
    """More than max_files changed → full pytest -q."""
    (tmp_path / ".git").mkdir()

    many_files = "\n".join(f"src/mod{i}.py" for i in range(10))
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = _make_proc(returncode=0, stdout=many_files)
        result = suggest_smart_verify(tmp_path, max_files=5)

    assert "pytest -q" in result


def test_suggest_smart_verify_git_error_returns_empty(tmp_path: Path) -> None:
    """Git command failure → empty list (graceful fallback)."""
    (tmp_path / ".git").mkdir()

    with patch("subprocess.run") as mock_run:
        mock_run.return_value = _make_proc(returncode=128, stdout="")
        result = suggest_smart_verify(tmp_path)

    # returncode != 0 → returns [] which means fallback to profile
    assert result == []


def test_suggest_smart_verify_git_timeout_returns_empty(tmp_path: Path) -> None:
    """subprocess.TimeoutExpired → empty list (graceful fallback)."""
    (tmp_path / ".git").mkdir()

    with patch("subprocess.run", side_effect=subprocess.TimeoutExpired(cmd="git", timeout=10)):
        result = suggest_smart_verify(tmp_path)

    assert result == []


# ---------------------------------------------------------------------------
# _map_to_test_files helpers
# ---------------------------------------------------------------------------


def test_map_to_test_files_finds_matching(tmp_path: Path) -> None:
    tests_dir = tmp_path / "tests"
    tests_dir.mkdir()
    (tests_dir / "test_foo.py").write_text("")

    result = _map_to_test_files(["src/owlmind/foo.py"], tmp_path)
    assert "tests/test_foo.py" in result


def test_map_to_test_files_skips_missing(tmp_path: Path) -> None:
    (tmp_path / "tests").mkdir()
    result = _map_to_test_files(["src/owlmind/ghost.py"], tmp_path)
    assert result == []


def test_map_to_test_files_deduplicates(tmp_path: Path) -> None:
    tests_dir = tmp_path / "tests"
    tests_dir.mkdir()
    (tests_dir / "test_bar.py").write_text("")

    result = _map_to_test_files(["src/a/bar.py", "src/b/bar.py"], tmp_path)
    assert result.count("tests/test_bar.py") == 1


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_proc(returncode: int, stdout: str) -> subprocess.CompletedProcess:  # type: ignore[type-arg]
    proc = subprocess.CompletedProcess(args=["git"], returncode=returncode)
    proc.stdout = stdout
    proc.stderr = ""
    return proc
