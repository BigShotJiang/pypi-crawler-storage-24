"""Tests for FS78 — CLI automation commands (auto, llm, e2e, telegram)."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from owlmind.cli import app

runner = CliRunner()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _ap_result(final_state: str = "DONE") -> MagicMock:
    """Build a mock AutoPilotResult."""
    r = MagicMock()
    r.final_state = final_state
    r.run_id = "run-auto-001"
    r.steps = 5
    r.iterations = 2
    r.stop_reason = "goal achieved"
    r.export_path = None
    return r


def _mock_owlmind_config() -> MagicMock:
    """Build a mock OwlMindConfig with LLM defaults."""
    cfg = MagicMock()
    cfg.openai.enabled = True
    cfg.openai.planner_model = "gpt-4o"
    cfg.anthropic.enabled = False
    cfg.anthropic.model = "claude-3-5-sonnet-20241022"
    cfg.gemini.enabled = False
    cfg.gemini.model = "gemini-2.0-flash"
    cfg.router.planner_providers = ["openai"]
    cfg.router.judge_providers = ["anthropic"]
    cfg.telegram.enabled = True
    cfg.telegram.allowed_chat_ids = [123456]
    cfg.telegram.bot_token = "bot:TOKEN"
    cfg.workspace.default_workspace = "/workspace"
    cfg.workspace.allowed_workspaces = []
    return cfg


# ---------------------------------------------------------------------------
# auto command
# ---------------------------------------------------------------------------


class TestAutoCommand:
    def test_auto_no_goal_no_run_id(self) -> None:
        """auto without --goal or --run-id → exit 1, helpful message."""
        result = runner.invoke(app, ["auto"])

        assert result.exit_code == 1
        assert "goal" in result.output.lower() or "run-id" in result.output.lower()

    def test_auto_done(self) -> None:
        """auto --goal 'Fix bug' → autopilot returns DONE → exit 0."""
        with (
            patch("owlmind.autopilot.AutoPilotConfig"),
            patch("owlmind.autopilot.run", return_value=_ap_result("DONE")),
        ):
            result = runner.invoke(app, ["auto", "--goal", "Fix authentication bug"])

        assert result.exit_code == 0, result.output
        assert "DONE" in result.output

    def test_auto_not_done(self) -> None:
        """auto → autopilot returns FAILED → exit 1."""
        with (
            patch("owlmind.autopilot.AutoPilotConfig"),
            patch("owlmind.autopilot.run", return_value=_ap_result("FAILED")),
        ):
            result = runner.invoke(app, ["auto", "--goal", "Fix bug"])

        assert result.exit_code == 1
        assert "FAILED" in result.output


# ---------------------------------------------------------------------------
# llm providers
# ---------------------------------------------------------------------------


class TestLlmProviders:
    def test_llm_providers_ok(self) -> None:
        """llm providers → exit 0, table with provider names printed."""
        cfg = _mock_owlmind_config()

        with (
            patch("owlmind.config.OwlMindConfig") as MockCfg,
            patch("owlmind.llm.openai_driver.is_openai_available", return_value=True),
            patch("owlmind.llm.anthropic_driver.is_anthropic_available", return_value=False),
            patch("owlmind.llm.gemini_driver.is_gemini_available", return_value=False),
        ):
            MockCfg.from_env.return_value = cfg
            result = runner.invoke(app, ["llm", "providers"])

        assert result.exit_code == 0, result.output
        assert "openai" in result.output
        assert "anthropic" in result.output


# ---------------------------------------------------------------------------
# e2e preflight
# ---------------------------------------------------------------------------


class TestE2ePreflight:
    def test_e2e_preflight_ok(self) -> None:
        """e2e preflight → all checks pass → exit 0, 'Preflight PASSED'."""
        mock_report = MagicMock()
        mock_report.ok = True
        mock_report.checks = []
        mock_report.provider_status = {}
        mock_report.budget_summary = None
        mock_report.recommended_installs = []

        with (
            patch("owlmind.preflight.PreflightConfig"),
            patch("owlmind.preflight.run_preflight", return_value=mock_report),
        ):
            result = runner.invoke(app, ["e2e", "preflight", "--use-llm", "none"])

        assert result.exit_code == 0, result.output
        assert "PASSED" in result.output

    def test_e2e_preflight_fail(self) -> None:
        """e2e preflight → check fails → exit 3."""
        mock_report = MagicMock()
        mock_report.ok = False
        mock_report.checks = []
        mock_report.provider_status = {}
        mock_report.budget_summary = None
        mock_report.recommended_installs = []

        with (
            patch("owlmind.preflight.PreflightConfig"),
            patch("owlmind.preflight.run_preflight", return_value=mock_report),
        ):
            result = runner.invoke(app, ["e2e", "preflight"])

        assert result.exit_code == 3
        assert "FAILED" in result.output


# ---------------------------------------------------------------------------
# e2e smoke
# ---------------------------------------------------------------------------


class TestE2eSmoke:
    def test_e2e_smoke_no_goal(self) -> None:
        """e2e smoke without --goal or --run-id → exit 1."""
        result = runner.invoke(app, ["e2e", "smoke"])

        assert result.exit_code == 1

    def test_e2e_smoke_done(self) -> None:
        """e2e smoke --goal '...' → run_e2e returns exit_code=0 → exit 0."""
        mock_result = MagicMock()
        mock_result.exit_code = 0
        mock_result.final_state = "DONE"
        mock_result.run_id = "run-e2e-001"
        mock_result.blocked_reason = None
        mock_result.report_path = None
        mock_result.next_commands = []

        with (
            patch("owlmind.e2e.E2EConfig"),
            patch("owlmind.e2e.run_e2e", return_value=mock_result),
        ):
            result = runner.invoke(app, ["e2e", "smoke", "--goal", "Run smoke test"])

        assert result.exit_code == 0, result.output
        assert "DONE" in result.output


# ---------------------------------------------------------------------------
# telegram
# ---------------------------------------------------------------------------


class TestTelegram:
    def test_telegram_run_no_sdk(self) -> None:
        """telegram run → python-telegram-bot not installed → exit 1."""
        with patch("owlmind.telegram_bot.is_telegram_available", return_value=False):
            result = runner.invoke(app, ["telegram", "run"])

        assert result.exit_code == 1
        assert "telegram-bot" in result.output.lower() or "not installed" in result.output.lower()

    def test_telegram_dry_run_ok(self, tmp_path: Path) -> None:
        """telegram dry-run → all checks pass → exit 0, 'Ready to run'."""
        cfg = _mock_owlmind_config()

        with (
            patch("owlmind.telegram_bot.is_telegram_available", return_value=True),
            patch("owlmind.config.OwlMindConfig") as MockCfg,
        ):
            MockCfg.from_env.return_value = cfg
            result = runner.invoke(
                app,
                ["telegram", "dry-run", "--policies", str(tmp_path)],
            )

        assert result.exit_code == 0, result.output
        assert "Ready to run" in result.output


# ---------------------------------------------------------------------------
# Additional auto command coverage
# ---------------------------------------------------------------------------


class TestAutoCommandExtra:
    def test_auto_resume_run_id_prints_resuming(self) -> None:
        """auto --run-id → prints 'Resuming' line (line 111)."""
        with (
            patch("owlmind.autopilot.AutoPilotConfig"),
            patch("owlmind.autopilot.run", return_value=_ap_result("DONE")),
        ):
            result = runner.invoke(app, ["auto", "--run-id", "run-existing-123"])

        assert result.exit_code == 0, result.output
        assert "Resuming" in result.output
        assert "run-existing-123" in result.output

    def test_auto_wait_approval_state_color_yellow(self) -> None:
        """auto → WAIT_APPROVAL state sets yellow color (line 118)."""
        with (
            patch("owlmind.autopilot.AutoPilotConfig"),
            patch("owlmind.autopilot.run", return_value=_ap_result("WAIT_APPROVAL")),
        ):
            result = runner.invoke(app, ["auto", "--goal", "Fix something"])

        assert result.exit_code == 1
        assert "WAIT_APPROVAL" in result.output

    def test_auto_done_with_export_path(self) -> None:
        """auto → DONE with export_path set → prints Export line (line 128)."""
        r = _ap_result("DONE")
        r.export_path = "/tmp/export/run.zip"

        with (
            patch("owlmind.autopilot.AutoPilotConfig"),
            patch("owlmind.autopilot.run", return_value=r),
        ):
            result = runner.invoke(app, ["auto", "--goal", "Build feature"])

        assert result.exit_code == 0, result.output
        assert "Export" in result.output
        assert "/tmp/export/run.zip" in result.output


# ---------------------------------------------------------------------------
# Additional e2e preflight coverage
# ---------------------------------------------------------------------------


class TestE2ePreflightExtra:
    def test_e2e_preflight_with_providers_flag(self) -> None:
        """e2e preflight --providers → provider_list parsed (line 200)."""
        mock_report = MagicMock()
        mock_report.ok = True
        mock_report.checks = []
        mock_report.provider_status = {}
        mock_report.budget_summary = None
        mock_report.recommended_installs = []

        with (
            patch("owlmind.preflight.PreflightConfig"),
            patch("owlmind.preflight.run_preflight", return_value=mock_report),
        ):
            result = runner.invoke(
                app,
                ["e2e", "preflight", "--providers", "openai,anthropic"],
            )

        assert result.exit_code == 0, result.output
        assert "PASSED" in result.output

    def test_e2e_preflight_shows_check_rows(self) -> None:
        """e2e preflight → table rows rendered from checks (lines 219-220)."""
        check = MagicMock()
        check.name = "sdk_check"
        check.ok = True
        check.details = "installed"

        mock_report = MagicMock()
        mock_report.ok = True
        mock_report.checks = [check]
        mock_report.provider_status = {}
        mock_report.budget_summary = None
        mock_report.recommended_installs = []

        with (
            patch("owlmind.preflight.PreflightConfig"),
            patch("owlmind.preflight.run_preflight", return_value=mock_report),
        ):
            result = runner.invoke(app, ["e2e", "preflight", "--use-llm", "none"])

        assert result.exit_code == 0, result.output
        assert "sdk_check" in result.output

    def test_e2e_preflight_shows_provider_status(self) -> None:
        """e2e preflight → provider_status section printed (lines 225-228)."""
        mock_report = MagicMock()
        mock_report.ok = True
        mock_report.checks = []
        mock_report.provider_status = {"openai": "enabled", "gemini": "disabled"}
        mock_report.budget_summary = None
        mock_report.recommended_installs = []

        with (
            patch("owlmind.preflight.PreflightConfig"),
            patch("owlmind.preflight.run_preflight", return_value=mock_report),
        ):
            result = runner.invoke(app, ["e2e", "preflight", "--use-llm", "none"])

        assert result.exit_code == 0, result.output
        assert "openai" in result.output

    def test_e2e_preflight_shows_budget_summary(self) -> None:
        """e2e preflight → budget_summary displayed (line 231)."""
        mock_report = MagicMock()
        mock_report.ok = True
        mock_report.checks = []
        mock_report.provider_status = {}
        mock_report.budget_summary = "daily: $10 / $50"
        mock_report.recommended_installs = []

        with (
            patch("owlmind.preflight.PreflightConfig"),
            patch("owlmind.preflight.run_preflight", return_value=mock_report),
        ):
            result = runner.invoke(app, ["e2e", "preflight", "--use-llm", "none"])

        assert result.exit_code == 0, result.output
        assert "daily: $10" in result.output

    def test_e2e_preflight_shows_recommended_installs(self) -> None:
        """e2e preflight → recommended_installs printed (lines 234-236)."""
        mock_report = MagicMock()
        mock_report.ok = True
        mock_report.checks = []
        mock_report.provider_status = {}
        mock_report.budget_summary = None
        mock_report.recommended_installs = ["pip install owlmind[openai]"]

        with (
            patch("owlmind.preflight.PreflightConfig"),
            patch("owlmind.preflight.run_preflight", return_value=mock_report),
        ):
            result = runner.invoke(app, ["e2e", "preflight", "--use-llm", "none"])

        assert result.exit_code == 0, result.output
        assert "Recommended" in result.output
        assert "pip install" in result.output

    def test_e2e_preflight_json_out(self, tmp_path: Path) -> None:
        """e2e preflight --json-out → JSON file written (lines 239-241)."""
        json_file = tmp_path / "report.json"

        mock_report = MagicMock()
        mock_report.ok = True
        mock_report.checks = []
        mock_report.provider_status = {}
        mock_report.budget_summary = None
        mock_report.recommended_installs = []
        mock_report.to_json.return_value = '{"ok": true}'

        with (
            patch("owlmind.preflight.PreflightConfig"),
            patch("owlmind.preflight.run_preflight", return_value=mock_report),
        ):
            result = runner.invoke(
                app,
                ["e2e", "preflight", "--json-out", str(json_file)],
            )

        assert result.exit_code == 0, result.output
        assert json_file.exists()
        assert json_file.read_text() == '{"ok": true}'

    def test_e2e_preflight_quiet_mode(self) -> None:
        """e2e preflight --quiet → table suppressed, only PASSED shown."""
        mock_report = MagicMock()
        mock_report.ok = True
        mock_report.checks = []
        mock_report.provider_status = {}
        mock_report.budget_summary = None
        mock_report.recommended_installs = []

        with (
            patch("owlmind.preflight.PreflightConfig"),
            patch("owlmind.preflight.run_preflight", return_value=mock_report),
        ):
            result = runner.invoke(app, ["e2e", "preflight", "--quiet"])

        assert result.exit_code == 0, result.output
        assert "PASSED" in result.output
        # No table header in quiet mode
        assert "Preflight Checks" not in result.output


# ---------------------------------------------------------------------------
# Additional e2e smoke coverage
# ---------------------------------------------------------------------------


class TestE2eSmokeExtra:
    def test_e2e_smoke_resume_run_id_prints_resuming(self) -> None:
        """e2e smoke --run-id → prints 'Resuming' line (line 299)."""
        mock_result = MagicMock()
        mock_result.exit_code = 0
        mock_result.final_state = "DONE"
        mock_result.run_id = "run-smoke-resume"
        mock_result.blocked_reason = None
        mock_result.report_path = None
        mock_result.next_commands = []

        with (
            patch("owlmind.e2e.E2EConfig"),
            patch("owlmind.e2e.run_e2e", return_value=mock_result),
        ):
            result = runner.invoke(app, ["e2e", "smoke", "--run-id", "run-smoke-resume"])

        assert result.exit_code == 0, result.output
        assert "Resuming" in result.output

    def test_e2e_smoke_exit_code_2_yellow(self) -> None:
        """e2e smoke → exit_code=2 sets yellow color (line 306)."""
        mock_result = MagicMock()
        mock_result.exit_code = 2
        mock_result.final_state = "WAIT_APPROVAL"
        mock_result.run_id = "run-approval"
        mock_result.blocked_reason = None
        mock_result.report_path = None
        mock_result.next_commands = []

        with (
            patch("owlmind.e2e.E2EConfig"),
            patch("owlmind.e2e.run_e2e", return_value=mock_result),
        ):
            result = runner.invoke(app, ["e2e", "smoke", "--goal", "Do stuff"])

        assert result.exit_code == 2
        assert "WAIT_APPROVAL" in result.output

    def test_e2e_smoke_shows_blocked_reason(self) -> None:
        """e2e smoke → blocked_reason printed (line 312)."""
        mock_result = MagicMock()
        mock_result.exit_code = 1
        mock_result.final_state = "BLOCKED"
        mock_result.run_id = "run-blocked"
        mock_result.blocked_reason = "Tool not allowed: rm"
        mock_result.report_path = None
        mock_result.next_commands = []

        with (
            patch("owlmind.e2e.E2EConfig"),
            patch("owlmind.e2e.run_e2e", return_value=mock_result),
        ):
            result = runner.invoke(app, ["e2e", "smoke", "--goal", "Risky action"])

        assert result.exit_code == 1
        assert "Tool not allowed: rm" in result.output

    def test_e2e_smoke_shows_report_path(self) -> None:
        """e2e smoke → report_path printed (line 314)."""
        mock_result = MagicMock()
        mock_result.exit_code = 0
        mock_result.final_state = "DONE"
        mock_result.run_id = "run-with-report"
        mock_result.blocked_reason = None
        mock_result.report_path = "/tmp/reports/run.json"
        mock_result.next_commands = []

        with (
            patch("owlmind.e2e.E2EConfig"),
            patch("owlmind.e2e.run_e2e", return_value=mock_result),
        ):
            result = runner.invoke(app, ["e2e", "smoke", "--goal", "Build"])

        assert result.exit_code == 0, result.output
        assert "/tmp/reports/run.json" in result.output

    def test_e2e_smoke_shows_next_commands(self) -> None:
        """e2e smoke → next_commands printed (lines 317-319)."""
        mock_result = MagicMock()
        mock_result.exit_code = 0
        mock_result.final_state = "DONE"
        mock_result.run_id = "run-with-cmds"
        mock_result.blocked_reason = None
        mock_result.report_path = None
        mock_result.next_commands = ["owlmind show run-with-cmds", "owlmind auto --goal '...'"]

        with (
            patch("owlmind.e2e.E2EConfig"),
            patch("owlmind.e2e.run_e2e", return_value=mock_result),
        ):
            result = runner.invoke(app, ["e2e", "smoke", "--goal", "Next steps"])

        assert result.exit_code == 0, result.output
        assert "owlmind show run-with-cmds" in result.output


# ---------------------------------------------------------------------------
# Additional telegram coverage
# ---------------------------------------------------------------------------


class TestTelegramExtra:
    def test_telegram_run_token_not_set(self) -> None:
        """telegram run → SDK available but token missing → exit 1 (line 348-349)."""
        cfg = _mock_owlmind_config()
        cfg.telegram.enabled = False

        with (
            patch("owlmind.telegram_bot.is_telegram_available", return_value=True),
            patch("owlmind.config.OwlMindConfig") as MockCfg,
        ):
            MockCfg.from_env.return_value = cfg
            result = runner.invoke(app, ["telegram", "run"])

        assert result.exit_code == 1
        assert "TELEGRAM_BOT_TOKEN" in result.output

    def test_telegram_run_bot_creation_fails(self) -> None:
        """telegram run → bot creation returns None → exit 1 (lines 393-395)."""
        cfg = _mock_owlmind_config()

        mock_operator = MagicMock()
        mock_operator.recover_runs_from_disk.return_value = []
        mock_operator.recover_sessions_from_disk.return_value = []

        with (
            patch("owlmind.telegram_bot.is_telegram_available", return_value=True),
            patch("owlmind.config.OwlMindConfig") as MockCfg,
            patch("owlmind.operator.OperatorService", return_value=mock_operator),
            patch("owlmind.telegram_bot.create_operator_bot", return_value=None),
            patch(
                "owlmind.cli.automation.make_cycle_manager",
                side_effect=Exception("no budget"),
            ),
        ):
            MockCfg.from_env.return_value = cfg
            result = runner.invoke(app, ["telegram", "run"])

        assert result.exit_code == 1
        assert "Failed to create" in result.output

    def test_telegram_run_with_recovered_runs_and_sessions(self) -> None:
        """telegram run → recovered runs and sessions printed (lines 362-373)."""
        cfg = _mock_owlmind_config()

        orphan_run = MagicMock()
        orphan_run.run_id = "abcdef1234567890"
        orphan_run.final_state = "INTERRUPTED"
        orphan_run.goal = "Fix the database migration"

        orphan_session = {
            "session_id": "sess-xyz-1234567890",
            "status": "RUNNING",
            "current_goal_index": 1,
            "total_goals": 3,
        }

        mock_operator = MagicMock()
        mock_operator.recover_runs_from_disk.return_value = [orphan_run]
        mock_operator.recover_sessions_from_disk.return_value = [orphan_session]

        mock_bot = MagicMock()
        mock_bot.run_polling.side_effect = KeyboardInterrupt

        with (
            patch("owlmind.telegram_bot.is_telegram_available", return_value=True),
            patch("owlmind.config.OwlMindConfig") as MockCfg,
            patch("owlmind.operator.OperatorService", return_value=mock_operator),
            patch("owlmind.telegram_bot.create_operator_bot", return_value=mock_bot),
            patch(
                "owlmind.cli.automation.make_cycle_manager",
                side_effect=Exception("no budget"),
            ),
        ):
            MockCfg.from_env.return_value = cfg
            result = runner.invoke(app, ["telegram", "run"])

        assert "Recovered" in result.output
        assert "orphaned session" in result.output.lower()

    def test_telegram_run_polling_keyboard_interrupt(self) -> None:
        """telegram run → KeyboardInterrupt during polling → graceful stop (lines 403-406)."""
        cfg = _mock_owlmind_config()

        mock_operator = MagicMock()
        mock_operator.recover_runs_from_disk.return_value = []
        mock_operator.recover_sessions_from_disk.return_value = []

        mock_bot = MagicMock()
        mock_bot.run_polling.side_effect = KeyboardInterrupt

        with (
            patch("owlmind.telegram_bot.is_telegram_available", return_value=True),
            patch("owlmind.config.OwlMindConfig") as MockCfg,
            patch("owlmind.operator.OperatorService", return_value=mock_operator),
            patch("owlmind.telegram_bot.create_operator_bot", return_value=mock_bot),
            patch(
                "owlmind.cli.automation.make_cycle_manager",
                side_effect=Exception("no budget"),
            ),
        ):
            MockCfg.from_env.return_value = cfg
            result = runner.invoke(app, ["telegram", "run"])

        assert "stopped" in result.output.lower()

    def test_telegram_run_success_with_cycle_manager(self) -> None:
        """telegram run → cycle manager created, bot runs, KeyboardInterrupt (lines 376-406)."""
        cfg = _mock_owlmind_config()
        cfg.workspace.allowed_workspaces = ["/projects"]

        mock_operator = MagicMock()
        mock_operator.recover_runs_from_disk.return_value = []
        mock_operator.recover_sessions_from_disk.return_value = []

        mock_bot = MagicMock()
        mock_bot.run_polling.side_effect = KeyboardInterrupt

        mock_cycle_manager = MagicMock()

        with (
            patch("owlmind.telegram_bot.is_telegram_available", return_value=True),
            patch("owlmind.config.OwlMindConfig") as MockCfg,
            patch("owlmind.operator.OperatorService", return_value=mock_operator),
            patch("owlmind.telegram_bot.create_operator_bot", return_value=mock_bot),
            patch(
                "owlmind.cli.automation.make_cycle_manager",
                return_value=(None, None, mock_cycle_manager),
            ),
        ):
            MockCfg.from_env.return_value = cfg
            result = runner.invoke(app, ["telegram", "run"])

        assert "Bot started" in result.output
        assert "Polling" in result.output

    def test_telegram_dry_run_fail_no_token(self) -> None:
        """telegram dry-run → token not set → exit 1 (lines 460-461)."""
        cfg = _mock_owlmind_config()
        cfg.telegram.enabled = False

        with (
            patch("owlmind.telegram_bot.is_telegram_available", return_value=True),
            patch("owlmind.config.OwlMindConfig") as MockCfg,
        ):
            MockCfg.from_env.return_value = cfg
            result = runner.invoke(app, ["telegram", "dry-run"])

        assert result.exit_code == 1
        assert "Fix issues" in result.output

    def test_telegram_dry_run_fail_no_sdk(self) -> None:
        """telegram dry-run → sdk missing → exit 1, sets all_ok=False (line 452)."""
        cfg = _mock_owlmind_config()

        with (
            patch("owlmind.telegram_bot.is_telegram_available", return_value=False),
            patch("owlmind.config.OwlMindConfig") as MockCfg,
        ):
            MockCfg.from_env.return_value = cfg
            result = runner.invoke(app, ["telegram", "dry-run"])

        assert result.exit_code == 1
        assert "Fix issues" in result.output
