"""Tests for owlmind.agent.pr_pack — PR-ready markdown generation."""

from __future__ import annotations

from owlmind.agent.pr_pack import build_pr_pack


class TestBuildPrPack:
    def test_basic_pass(self) -> None:
        md = build_pr_pack(
            run_id="run-1",
            goal="Add tests",
            iteration=1,
            planner_plan_summary=["step1"],
            worker_done_summary=["done1"],
            verify_results=["PASS: lint"],
        )
        assert "# PR Pack" in md
        assert "PASS" in md
        assert "Add tests" in md

    def test_hard_fail(self) -> None:
        md = build_pr_pack(
            run_id="run-2",
            goal="Refactor",
            iteration=2,
            planner_plan_summary=[],
            worker_done_summary=[],
            verify_results=[],
            hard_fail_ok=False,
            hard_fail_reasons=["Secret leak detected"],
        )
        assert "HARD FAIL" in md
        assert "Secret leak detected" in md

    def test_diff_stat(self) -> None:
        md = build_pr_pack(
            run_id="run-3",
            goal="Fix",
            iteration=1,
            planner_plan_summary=[],
            worker_done_summary=[],
            verify_results=[],
            diff_stat="3 files changed, 10 insertions(+), 2 deletions(-)",
        )
        assert "Diff Stats" in md
        assert "3 files changed" in md

    def test_files_changed(self) -> None:
        md = build_pr_pack(
            run_id="run-4",
            goal="Add",
            iteration=1,
            planner_plan_summary=[],
            worker_done_summary=[],
            verify_results=[],
            files_changed=["src/foo.py", "tests/test_foo.py"],
        )
        assert "Files Changed" in md
        assert "`src/foo.py`" in md

    def test_risk_notes(self) -> None:
        md = build_pr_pack(
            run_id="run-5",
            goal="Migrate",
            iteration=1,
            planner_plan_summary=[],
            worker_done_summary=[],
            verify_results=[],
            risk_notes=["Breaking change in API"],
        )
        assert "Risk Notes" in md
        assert "Breaking change" in md

    def test_verify_commands(self) -> None:
        md = build_pr_pack(
            run_id="run-6",
            goal="Test",
            iteration=1,
            planner_plan_summary=[],
            worker_done_summary=[],
            verify_results=[],
            verify_commands=["pytest tests/", "ruff check"],
        )
        assert "How to Test" in md
        assert "pytest tests/" in md

    def test_evidence_fields(self) -> None:
        md = build_pr_pack(
            run_id="run-7",
            goal="Ship",
            iteration=1,
            planner_plan_summary=[],
            worker_done_summary=[],
            verify_results=[],
            manifest_sha256="abc123",
            chain_tip_hash="def456",
            evidence_paths=["runs/run-7/evidence.json"],
        )
        assert "abc123" in md
        assert "def456" in md
        assert "evidence.json" in md

    def test_fail_verify_result(self) -> None:
        md = build_pr_pack(
            run_id="run-8",
            goal="Test",
            iteration=1,
            planner_plan_summary=[],
            worker_done_summary=[],
            verify_results=["FAIL: mypy"],
        )
        assert "- FAIL: mypy" in md
