"""Tests for SQLitePublicPackRegistry storage layer."""

from __future__ import annotations

import asyncio
from pathlib import Path

import pytest

from owlmind.registry.models import PublishRequest
from owlmind.registry.public import SQLitePublicPackRegistry


@pytest.fixture()
def registry(tmp_path: Path) -> SQLitePublicPackRegistry:
    """Create a fresh in-memory-like registry for each test."""
    return SQLitePublicPackRegistry(tmp_path / "test_registry.db")


def _run(coro):
    """Run an async coroutine synchronously."""
    return asyncio.run(coro)


def _publish_req(**kwargs) -> PublishRequest:
    """Build a PublishRequest with sensible defaults."""
    defaults = {
        "name": "Test Pack",
        "description": "A test skill pack",
        "tags": ["python", "testing"],
        "version": "1.0.0",
        "changelog": "Initial release",
        "author_name": "tester",
        "author_github": "tester",
    }
    defaults.update(kwargs)
    return PublishRequest(**defaults)


# ---------------------------------------------------------------------------
# Publish
# ---------------------------------------------------------------------------


class TestPublishPack:
    def test_publish_new(self, registry: SQLitePublicPackRegistry) -> None:
        """Publishing a new pack creates it with pending status."""
        result = _run(registry.publish_pack("pk-1", _publish_req()))
        assert result["pack_id"] == "pk-1"
        assert result["name"] == "Test Pack"
        assert result["status"] == "pending"
        assert result["downloads"] == 0

    def test_duplicate_updates(self, registry: SQLitePublicPackRegistry) -> None:
        """Re-publishing the same pack_id updates metadata."""
        _run(registry.publish_pack("pk-1", _publish_req(version="1.0.0")))
        result = _run(
            registry.publish_pack(
                "pk-1",
                _publish_req(name="Updated Pack", version="2.0.0"),
            )
        )
        assert result["name"] == "Updated Pack"
        assert result["latest_version"] == "2.0.0"

    def test_starts_as_pending(self, registry: SQLitePublicPackRegistry) -> None:
        """New packs always start with pending status."""
        result = _run(registry.publish_pack("pk-1", _publish_req()))
        assert result["status"] == "pending"


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------


class TestSearchPacks:
    def test_empty_registry(self, registry: SQLitePublicPackRegistry) -> None:
        """Searching empty registry returns empty list."""
        results = _run(registry.search_packs())
        assert results == []

    def test_by_name(self, registry: SQLitePublicPackRegistry) -> None:
        """Search finds packs by name."""
        _run(registry.publish_pack("pk-1", _publish_req(name="Code Review")))
        _run(registry.approve_pack("pk-1"))

        results = _run(registry.search_packs(q="Code"))
        assert len(results) == 1
        assert results[0]["name"] == "Code Review"

    def test_by_tag(self, registry: SQLitePublicPackRegistry) -> None:
        """Search filters by tag."""
        _run(registry.publish_pack("pk-1", _publish_req(tags=["python"])))
        _run(registry.publish_pack("pk-2", _publish_req(tags=["rust"])))
        _run(registry.approve_pack("pk-1"))
        _run(registry.approve_pack("pk-2"))

        results = _run(registry.search_packs(tags=["python"]))
        assert len(results) == 1
        assert results[0]["pack_id"] == "pk-1"

    def test_only_approved(self, registry: SQLitePublicPackRegistry) -> None:
        """Default search only returns approved packs."""
        _run(registry.publish_pack("pk-1", _publish_req()))
        # pk-1 is pending
        results = _run(registry.search_packs())
        assert len(results) == 0

        _run(registry.approve_pack("pk-1"))
        results = _run(registry.search_packs())
        assert len(results) == 1

    def test_sort_downloads(self, registry: SQLitePublicPackRegistry) -> None:
        """Sort by downloads puts most downloaded first."""
        _run(registry.publish_pack("pk-1", _publish_req(name="Low")))
        _run(registry.publish_pack("pk-2", _publish_req(name="High")))
        _run(registry.approve_pack("pk-1"))
        _run(registry.approve_pack("pk-2"))

        # Give pk-2 more downloads
        for _ in range(5):
            _run(registry.increment_downloads("pk-2"))

        results = _run(registry.search_packs(sort="downloads"))
        assert results[0]["pack_id"] == "pk-2"
        assert results[0]["downloads"] == 5

    def test_sort_rating(self, registry: SQLitePublicPackRegistry) -> None:
        """Sort by rating puts highest rated first."""
        _run(registry.publish_pack("pk-1", _publish_req(name="Low")))
        _run(registry.publish_pack("pk-2", _publish_req(name="High")))
        _run(registry.approve_pack("pk-1"))
        _run(registry.approve_pack("pk-2"))

        _run(registry.add_review("pk-1", "user1", 2))
        _run(registry.add_review("pk-2", "user2", 5))

        results = _run(registry.search_packs(sort="rating"))
        assert results[0]["pack_id"] == "pk-2"
        assert results[0]["avg_rating"] == 5.0

    def test_pagination(self, registry: SQLitePublicPackRegistry) -> None:
        """Pagination limits and offsets work."""
        for i in range(5):
            _run(registry.publish_pack(f"pk-{i}", _publish_req(name=f"Pack {i}")))
            _run(registry.approve_pack(f"pk-{i}"))

        page1 = _run(registry.search_packs(limit=2, offset=0))
        page2 = _run(registry.search_packs(limit=2, offset=2))

        assert len(page1) == 2
        assert len(page2) == 2
        assert page1[0]["pack_id"] != page2[0]["pack_id"]


# ---------------------------------------------------------------------------
# Moderation
# ---------------------------------------------------------------------------


class TestModeration:
    def test_approve(self, registry: SQLitePublicPackRegistry) -> None:
        """Approving a pack changes its status."""
        _run(registry.publish_pack("pk-1", _publish_req()))
        assert _run(registry.approve_pack("pk-1")) is True

        pack = _run(registry.get_pack("pk-1"))
        assert pack is not None
        assert pack["status"] == "approved"

    def test_reject(self, registry: SQLitePublicPackRegistry) -> None:
        """Rejecting a pack changes its status."""
        _run(registry.publish_pack("pk-1", _publish_req()))
        assert _run(registry.reject_pack("pk-1")) is True

        pack = _run(registry.get_pack("pk-1"))
        assert pack is not None
        assert pack["status"] == "rejected"

    def test_approve_nonexistent(self, registry: SQLitePublicPackRegistry) -> None:
        """Approving nonexistent pack returns False."""
        assert _run(registry.approve_pack("missing")) is False


# ---------------------------------------------------------------------------
# Versions
# ---------------------------------------------------------------------------


class TestVersions:
    def test_add(self, registry: SQLitePublicPackRegistry) -> None:
        """Adding a version records it."""
        _run(registry.publish_pack("pk-1", _publish_req(version="1.0.0")))
        ver = _run(registry.add_version("pk-1", "1.1.0", changelog="Bug fixes"))
        assert ver["version"] == "1.1.0"
        assert ver["changelog"] == "Bug fixes"

    def test_updates_latest(self, registry: SQLitePublicPackRegistry) -> None:
        """Adding a version updates the pack's latest_version."""
        _run(registry.publish_pack("pk-1", _publish_req(version="1.0.0")))
        _run(registry.add_version("pk-1", "2.0.0"))

        pack = _run(registry.get_pack("pk-1"))
        assert pack is not None
        assert pack["latest_version"] == "2.0.0"

    def test_list_ordered(self, registry: SQLitePublicPackRegistry) -> None:
        """Versions are listed newest first."""
        _run(registry.publish_pack("pk-1", _publish_req(version="1.0.0")))
        _run(registry.add_version("pk-1", "2.0.0"))
        _run(registry.add_version("pk-1", "3.0.0"))

        versions = _run(registry.list_versions("pk-1"))
        assert len(versions) >= 2
        # Most recent should be first
        assert versions[0]["version"] == "3.0.0"

    def test_get_specific(self, registry: SQLitePublicPackRegistry) -> None:
        """Can retrieve a specific version."""
        _run(registry.publish_pack("pk-1", _publish_req(version="1.0.0")))
        _run(registry.add_version("pk-1", "2.0.0", archive_sha256="abc123"))

        ver = _run(registry.get_version("pk-1", "2.0.0"))
        assert ver is not None
        assert ver["archive_sha256"] == "abc123"

        # Nonexistent version
        assert _run(registry.get_version("pk-1", "9.9.9")) is None


# ---------------------------------------------------------------------------
# Reviews
# ---------------------------------------------------------------------------


class TestReviews:
    def test_add(self, registry: SQLitePublicPackRegistry) -> None:
        """Adding a review creates it with correct fields."""
        _run(registry.publish_pack("pk-1", _publish_req()))
        review = _run(registry.add_review("pk-1", "reviewer", 4, "Great pack"))
        assert review["rating"] == 4
        assert review["comment"] == "Great pack"
        assert review["author_name"] == "reviewer"
        assert review["review_id"].startswith("rev-")

    def test_updates_avg_rating(self, registry: SQLitePublicPackRegistry) -> None:
        """Reviews update the pack's average rating and count."""
        _run(registry.publish_pack("pk-1", _publish_req()))
        _run(registry.add_review("pk-1", "user1", 5))
        _run(registry.add_review("pk-1", "user2", 3))

        pack = _run(registry.get_pack("pk-1"))
        assert pack is not None
        assert pack["avg_rating"] == 4.0
        assert pack["rating_count"] == 2

    def test_list(self, registry: SQLitePublicPackRegistry) -> None:
        """Reviews are listed newest first."""
        _run(registry.publish_pack("pk-1", _publish_req()))
        _run(registry.add_review("pk-1", "user1", 3, "Ok"))
        _run(registry.add_review("pk-1", "user2", 5, "Excellent"))

        reviews = _run(registry.list_reviews("pk-1"))
        assert len(reviews) == 2
        # Newest first
        assert reviews[0]["author_name"] == "user2"


# ---------------------------------------------------------------------------
# Downloads
# ---------------------------------------------------------------------------


class TestDownloads:
    def test_increment(self, registry: SQLitePublicPackRegistry) -> None:
        """Incrementing downloads increases the counter."""
        _run(registry.publish_pack("pk-1", _publish_req()))
        _run(registry.increment_downloads("pk-1"))

        pack = _run(registry.get_pack("pk-1"))
        assert pack is not None
        assert pack["downloads"] == 1

    def test_multiple_increments(self, registry: SQLitePublicPackRegistry) -> None:
        """Multiple increments accumulate."""
        _run(registry.publish_pack("pk-1", _publish_req()))
        for _ in range(10):
            _run(registry.increment_downloads("pk-1"))

        pack = _run(registry.get_pack("pk-1"))
        assert pack is not None
        assert pack["downloads"] == 10


# ---------------------------------------------------------------------------
# Delete
# ---------------------------------------------------------------------------


class TestDeletePack:
    def test_delete_existing(self, registry: SQLitePublicPackRegistry) -> None:
        """Deleting an existing pack returns True."""
        _run(registry.publish_pack("pk-1", _publish_req()))
        assert _run(registry.delete_pack("pk-1")) is True
        assert _run(registry.get_pack("pk-1")) is None

    def test_delete_nonexistent(self, registry: SQLitePublicPackRegistry) -> None:
        """Deleting a nonexistent pack returns False."""
        assert _run(registry.delete_pack("missing")) is False
