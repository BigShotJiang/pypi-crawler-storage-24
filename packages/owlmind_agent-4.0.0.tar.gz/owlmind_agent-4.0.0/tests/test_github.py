"""Tests for GitHub PR operations — unit tests with mocked gh CLI."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from owlmind.github import (
    GhConfig,
    PRInfo,
    check_repo_allowed,
    configure_gh,
    is_gh_available,
    pr_checks,
    pr_create,
    pr_diff,
    pr_list,
    pr_merge,
    pr_view,
)


class TestIsGhAvailable:
    def test_not_installed(self) -> None:
        with patch("owlmind.github.shutil.which", return_value=None):
            assert is_gh_available() is False

    def test_installed_authenticated(self) -> None:
        mock_result = MagicMock()
        mock_result.returncode = 0
        with (
            patch("owlmind.github.shutil.which", return_value="/usr/bin/gh"),
            patch("owlmind.github.subprocess.run", return_value=mock_result),
        ):
            assert is_gh_available() is True

    def test_installed_not_authenticated(self) -> None:
        mock_result = MagicMock()
        mock_result.returncode = 1
        with (
            patch("owlmind.github.shutil.which", return_value="/usr/bin/gh"),
            patch("owlmind.github.subprocess.run", return_value=mock_result),
        ):
            assert is_gh_available() is False


class TestPRList:
    def test_success(self) -> None:
        prs = [
            {"number": 1, "title": "Fix bug", "state": "OPEN"},
            {"number": 2, "title": "Add feature", "state": "OPEN"},
        ]
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = json.dumps(prs)

        with patch("owlmind.github.subprocess.run", return_value=mock_result):
            result = pr_list("/workspace")

        assert len(result) == 2
        assert result[0]["number"] == 1

    def test_failure_returns_empty(self) -> None:
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stderr = "error"

        with patch("owlmind.github.subprocess.run", return_value=mock_result):
            result = pr_list("/workspace")

        assert result == []


class TestPRView:
    def test_success(self) -> None:
        data = {
            "number": 42,
            "title": "My PR",
            "state": "OPEN",
            "url": "https://github.com/owner/repo/pull/42",
            "headRefName": "feature",
            "baseRefName": "main",
            "body": "Description",
            "mergeable": "MERGEABLE",
            "additions": 100,
            "deletions": 20,
        }
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = json.dumps(data)

        with patch("owlmind.github.subprocess.run", return_value=mock_result):
            info = pr_view("/workspace", 42)

        assert isinstance(info, PRInfo)
        assert info.number == 42
        assert info.title == "My PR"
        assert info.additions == 100

    def test_failure_raises(self) -> None:
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stderr = "not found"

        with (
            patch("owlmind.github.subprocess.run", return_value=mock_result),
            pytest.raises(RuntimeError, match="not found"),
        ):
            pr_view("/workspace", 999)


class TestPRCreate:
    def test_requires_approval(self) -> None:
        result = pr_create("/workspace", title="Test PR", approved=False)
        assert not result.ok
        assert "approval" in result.error.lower()

    def test_success(self) -> None:
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "https://github.com/owner/repo/pull/123\n"

        with patch("owlmind.github.subprocess.run", return_value=mock_result):
            result = pr_create("/workspace", title="Test PR", approved=True)

        assert result.ok
        assert result.pr_number == 123
        assert "github.com" in result.url

    def test_with_draft(self) -> None:
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "https://github.com/owner/repo/pull/1\n"

        with patch("owlmind.github.subprocess.run", return_value=mock_result) as mock_run:
            pr_create("/workspace", title="Draft", draft=True, approved=True)
            args = mock_run.call_args[0][0]
            assert "--draft" in args

    def test_failure(self) -> None:
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stderr = "auth required"

        with patch("owlmind.github.subprocess.run", return_value=mock_result):
            result = pr_create("/workspace", title="Test", approved=True)

        assert not result.ok
        assert "auth required" in result.error


class TestPRMerge:
    def test_requires_approval(self) -> None:
        result = pr_merge("/workspace", 1, approved=False)
        assert not result.ok
        assert "approval" in result.error.lower()

    def test_success(self) -> None:
        mock_result = MagicMock()
        mock_result.returncode = 0

        with patch("owlmind.github.subprocess.run", return_value=mock_result):
            result = pr_merge("/workspace", 1, method="squash", approved=True)

        assert result.ok
        assert result.merged

    def test_invalid_method(self) -> None:
        result = pr_merge("/workspace", 1, method="invalid", approved=True)
        assert not result.ok
        assert "Invalid" in result.error

    def test_merge_failure(self) -> None:
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stderr = "merge conflict"

        with patch("owlmind.github.subprocess.run", return_value=mock_result):
            result = pr_merge("/workspace", 1, approved=True)

        assert not result.ok
        assert "merge conflict" in result.error


class TestPRDiff:
    def test_success(self) -> None:
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "+new line\n-old line\n"

        with patch("owlmind.github.subprocess.run", return_value=mock_result):
            diff = pr_diff("/workspace", 1)

        assert "+new line" in diff

    def test_failure_raises(self) -> None:
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stderr = "error"

        with (
            patch("owlmind.github.subprocess.run", return_value=mock_result),
            pytest.raises(RuntimeError),
        ):
            pr_diff("/workspace", 999)


class TestPRChecks:
    def test_success(self) -> None:
        checks = [
            {"name": "CI", "state": "SUCCESS", "conclusion": "SUCCESS"},
        ]
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = json.dumps(checks)

        with patch("owlmind.github.subprocess.run", return_value=mock_result):
            result = pr_checks("/workspace", 1)

        assert len(result) == 1
        assert result[0]["name"] == "CI"

    def test_failure_returns_empty(self) -> None:
        mock_result = MagicMock()
        mock_result.returncode = 1

        with patch("owlmind.github.subprocess.run", return_value=mock_result):
            result = pr_checks("/workspace", 1)

        assert result == []


class TestGhConfig:
    def setup_method(self) -> None:
        configure_gh()  # reset to defaults

    def teardown_method(self) -> None:
        configure_gh()  # reset after each test

    def test_default_config(self) -> None:
        cfg = GhConfig()
        assert cfg.allowed_repos == frozenset()
        assert cfg.dry_run is False
        assert cfg.cooldown == 2.0

    def test_configure_gh(self) -> None:
        configure_gh(allowed_repos=["owner/repo"], dry_run=True, cooldown=5.0)
        from owlmind.github import _config

        assert "owner/repo" in _config.allowed_repos
        assert _config.dry_run is True
        assert _config.cooldown == 5.0


class TestRepoAllowlist:
    def setup_method(self) -> None:
        configure_gh()

    def teardown_method(self) -> None:
        configure_gh()

    def test_empty_allowlist_allows_all(self) -> None:
        configure_gh(allowed_repos=None)
        assert check_repo_allowed("/any/workspace") is True

    def test_allowed_repo_passes(self) -> None:
        configure_gh(allowed_repos=["owner/myrepo"])
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "https://github.com/owner/myrepo.git\n"
        with patch("owlmind.github.subprocess.run", return_value=mock_result):
            assert check_repo_allowed("/workspace") is True

    def test_disallowed_repo_blocked(self) -> None:
        configure_gh(allowed_repos=["owner/allowed"])
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "https://github.com/evil/hacked.git\n"
        with patch("owlmind.github.subprocess.run", return_value=mock_result):
            assert check_repo_allowed("/workspace") is False

    def test_pr_create_blocked_by_allowlist(self) -> None:
        configure_gh(allowed_repos=["owner/allowed"])
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "https://github.com/evil/hacked.git\n"
        with patch("owlmind.github.subprocess.run", return_value=mock_result):
            result = pr_create("/workspace", title="Evil PR", approved=True)
        assert not result.ok
        assert "allowlist" in result.error

    def test_pr_merge_blocked_by_allowlist(self) -> None:
        configure_gh(allowed_repos=["owner/allowed"])
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "https://github.com/evil/hacked.git\n"
        with patch("owlmind.github.subprocess.run", return_value=mock_result):
            result = pr_merge("/workspace", 1, approved=True)
        assert not result.ok
        assert "allowlist" in result.error


class TestDryRun:
    def setup_method(self) -> None:
        configure_gh()

    def teardown_method(self) -> None:
        configure_gh()

    def test_dry_run_no_subprocess(self) -> None:
        configure_gh(dry_run=True)
        # pr_list should return empty (dry-run returns stdout="")
        result = pr_list("/workspace")
        assert result == []

    def test_dry_run_pr_create(self) -> None:
        configure_gh(dry_run=True, allowed_repos=None)
        # check_repo_allowed returns True with empty allowlist
        result = pr_create("/workspace", title="Test", approved=True)
        # dry-run returns empty stdout → pr_number = 0 but ok=True
        assert result.ok


class TestCheckRepoAllowedEdgeCases:
    """Lines 75, 78-79: non-zero returncode and exception paths."""

    def test_nonzero_returncode_returns_false(self) -> None:
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=1, stdout="")
            configure_gh(allowed_repos=["org/repo"])
            result = check_repo_allowed("/workspace")
        assert result is False

    def test_timeout_returns_false(self) -> None:
        import subprocess

        with patch("subprocess.run", side_effect=subprocess.TimeoutExpired("git", 5)):
            configure_gh(allowed_repos=["org/repo"])
            result = check_repo_allowed("/workspace")
        assert result is False

    def test_oserror_returns_false(self) -> None:
        with patch("subprocess.run", side_effect=OSError("git not found")):
            configure_gh(allowed_repos=["org/repo"])
            result = check_repo_allowed("/workspace")
        assert result is False


class TestIsGhAvailableEdgeCases:
    """Lines 139-140: TimeoutExpired and OSError in is_gh_available."""

    def test_timeout_returns_false(self) -> None:
        import subprocess

        with patch("subprocess.run", side_effect=subprocess.TimeoutExpired("gh", 10)):
            result = is_gh_available()
        assert result is False

    def test_oserror_returns_false(self) -> None:
        with patch("subprocess.run", side_effect=OSError("gh not found")):
            result = is_gh_available()
        assert result is False


class TestPrCreateOptionalArgs:
    """Lines 260, 262, 264: body/base/head optional args passed to gh."""

    def test_create_with_body_base_head(self) -> None:
        captured: list[list[str]] = []

        def _mock_run(cmd: list[str], **kwargs: object) -> MagicMock:
            captured.append(cmd)
            return MagicMock(returncode=0, stdout="https://github.com/org/repo/pull/42")

        configure_gh(dry_run=False, allowed_repos=[])
        with patch("subprocess.run", side_effect=_mock_run):
            pr_create(
                "/workspace",
                title="My PR",
                approved=True,
                body="desc",
                base="main",
                head="feature",
            )
        cmd = captured[0]
        assert "--body" in cmd
        assert "--base" in cmd
        assert "--head" in cmd


class TestPrChecksInvalidJson:
    """Lines 337-338: JSONDecodeError in pr_checks → return []."""

    def test_invalid_json_returns_empty(self) -> None:
        mock_result = MagicMock(returncode=0, stdout="not-valid-json{")
        with patch("subprocess.run", return_value=mock_result):
            result = pr_checks("/workspace", pr_number=1)
        assert result == []
