"""Tests for cycle next — auto-advance command."""

from __future__ import annotations

import json
from pathlib import Path

from owlmind.agent.cycle import CycleManager
from owlmind.agent.schemas import CycleState
from owlmind.evidence import EvidenceStore
from owlmind.policy import PolicyEngine


def _make_manager(tmp_path: Path) -> CycleManager:
    """Create a CycleManager backed by tmp_path with real policies."""
    policies_dir = tmp_path / "policies"
    policies_dir.mkdir()

    (policies_dir / "allowlist.yaml").write_text(
        "allowed_commands:\n"
        '  - "^echo "\n'
        '  - "^pytest"\n'
        '  - "^ruff check"\n'
        '  - "^mypy"\n'
        '  - "^git status"\n'
        '  - "^git diff"\n'
        '  - "^ls"\n'
    )
    (policies_dir / "policy.yaml").write_text(
        'forbidden_patterns:\n  - "rm -rf"\n  - "sudo"\nrisk_behavior:\n  CRITICAL: BLOCK\n'
    )

    policy = PolicyEngine.from_directory(policies_dir)
    evidence = EvidenceStore(tmp_path / "runs")
    return CycleManager(evidence=evidence, policy=policy)


def _write_inbox(tmp_path: Path, run_id: str, filename: str, data: dict) -> None:  # type: ignore[type-arg]
    inbox = tmp_path / "runs" / run_id / "inbox"
    inbox.mkdir(parents=True, exist_ok=True)
    (inbox / filename).write_text(json.dumps(data))


class TestCycleNext:
    def test_next_no_inbox_prints_instructions(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Test next", workspace=str(tmp_path))

        updated, msg = mgr.next(meta.run_id)
        assert updated.state == CycleState.STARTED_WAIT_PLANNER
        assert "Waiting for planner response" in msg
        assert "ingest" in msg

    def test_next_with_planner_inbox_advances(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Test next advance", workspace=str(tmp_path))

        planner_resp = {
            "run_id": meta.run_id,
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        _write_inbox(tmp_path, meta.run_id, "planner_response.json", planner_resp)

        updated, msg = mgr.next(meta.run_id)
        assert updated.state == CycleState.WAIT_WORKER
        assert "Planner response submitted" in msg

    def test_next_wait_worker_no_inbox(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Test", workspace=str(tmp_path))

        # Advance to WAIT_WORKER
        planner_resp = {
            "run_id": meta.run_id,
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        _write_inbox(tmp_path, meta.run_id, "planner_response.json", planner_resp)
        mgr.submit_planner(meta.run_id)

        updated, msg = mgr.next(meta.run_id)
        assert updated.state == CycleState.WAIT_WORKER
        assert "Waiting for worker report" in msg

    def test_next_wait_worker_with_inbox_advances(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Test", workspace=str(tmp_path))

        # Advance to WAIT_WORKER
        planner_resp = {
            "run_id": meta.run_id,
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        _write_inbox(tmp_path, meta.run_id, "planner_response.json", planner_resp)
        mgr.submit_planner(meta.run_id)

        # Write worker report
        worker_report = {
            "run_id": meta.run_id,
            "iteration": 1,
            "status": "READY_FOR_VERIFY",
            "done_summary": ["Done"],
            "questions": [],
            "commands_run": [],
        }
        _write_inbox(tmp_path, meta.run_id, "worker_report.json", worker_report)

        updated, msg = mgr.next(meta.run_id)
        assert updated.state == CycleState.WAIT_JUDGE
        assert "Worker report submitted" in msg

    def test_next_logs_event(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Events test", workspace=str(tmp_path))

        mgr.next(meta.run_id)

        events = mgr.evidence.read_events(meta.run_id)
        next_events = [e for e in events if e.get("event") == "next_called"]
        assert len(next_events) == 1

    def test_next_done_state(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Full", workspace=str(tmp_path))

        # Run through full cycle to DONE
        planner_resp = {
            "run_id": meta.run_id,
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        _write_inbox(tmp_path, meta.run_id, "planner_response.json", planner_resp)
        mgr.submit_planner(meta.run_id)

        worker_report = {
            "run_id": meta.run_id,
            "iteration": 1,
            "status": "READY_FOR_VERIFY",
            "done_summary": ["Done"],
            "questions": [],
            "commands_run": [],
        }
        _write_inbox(tmp_path, meta.run_id, "worker_report.json", worker_report)
        mgr.submit_worker(meta.run_id)

        judge_resp = {
            "run_id": meta.run_id,
            "iteration": 1,
            "verdict": "APPROVED",
            "notes": ["Good"],
            "next_worker_instructions": "",
            "evidence_chain_verified": True,
        }
        _write_inbox(tmp_path, meta.run_id, "judge_response.json", judge_resp)
        mgr.submit_judge(meta.run_id)

        updated, msg = mgr.next(meta.run_id)
        assert updated.state == CycleState.DONE
        assert "Cycle complete" in msg
