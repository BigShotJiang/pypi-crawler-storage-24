"""Tests for memory prompt injection safety."""

from __future__ import annotations

from pathlib import Path

from owlmind.llm.prompts import build_planner_prompts
from owlmind.memory.retrieval import build_memory_context
from owlmind.memory.store import MemoryStore


class TestPromptInjection:
    def test_memory_context_in_planner_prompt(self, tmp_path: Path) -> None:
        store = MemoryStore(tmp_path / "mem.db")
        store.ingest("doc", "readme.md", "Use pytest for testing code quality")
        ctx = build_memory_context(store, "run tests")
        store.close()

        request = {
            "run_id": "test-001",
            "goal": "Run tests",
            "memory_context": ctx,
        }
        _, user_prompt = build_planner_prompts(request)
        if ctx:
            assert ctx in user_prompt

    def test_no_memory_no_extra_content(self) -> None:
        request = {
            "run_id": "test-001",
            "goal": "Run tests",
        }
        _, user_prompt = build_planner_prompts(request)
        assert "Relevant Memory" not in user_prompt

    def test_secrets_not_in_memory_context(self, tmp_path: Path) -> None:
        store = MemoryStore(tmp_path / "mem.db")
        store.ingest("doc", "env.md", "OPENAI_API_KEY=sk-secret-real-key-12345")
        ctx = build_memory_context(store, "API key configuration")
        store.close()
        assert "sk-secret-real-key-12345" not in ctx

    def test_prompt_size_bounded(self, tmp_path: Path) -> None:
        store = MemoryStore(tmp_path / "mem.db")
        for i in range(50):
            store.ingest("doc", f"big_{i}.md", f"Large document {i} content " * 200)
        ctx = build_memory_context(store, "document content", max_chars=1000)
        store.close()

        request = {
            "run_id": "test-001",
            "goal": "Test",
            "memory_context": ctx,
        }
        _, user_prompt = build_planner_prompts(request)
        # Memory context should be bounded
        assert len(ctx) <= 1100  # tolerance

    def test_signal_redaction_in_context(self, tmp_path: Path) -> None:
        store = MemoryStore(tmp_path / "mem.db")
        store.add_signal("error", "API failed with token ghp_AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA")
        ctx = build_memory_context(store, "API error")
        store.close()
        assert "ghp_" not in ctx
