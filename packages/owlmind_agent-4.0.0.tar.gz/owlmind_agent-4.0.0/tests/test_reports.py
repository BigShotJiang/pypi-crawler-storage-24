"""Tests for cost/usage reports from the JSONL ledger."""

from __future__ import annotations

import json
from datetime import UTC, datetime, timedelta
from pathlib import Path

from owlmind.ledger import UsageEntry, UsageLedger
from owlmind.reports import (
    daily_report,
    format_report_json,
    format_report_text,
    monthly_report,
    provider_breakdown,
    weekly_report,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_entry(**overrides: object) -> UsageEntry:
    """Create a UsageEntry with sensible defaults."""
    defaults = {
        "ts": datetime.now(tz=UTC).isoformat(),
        "run_id": "run-001",
        "stage": "planner",
        "provider": "openai",
        "model": "gpt-4o",
        "input_tokens": 100,
        "output_tokens": 50,
        "total_tokens": 150,
        "estimated_usd": 0.001,
        "latency_ms": 400,
        "price_per_1k_input": 0.0025,
        "price_per_1k_output": 0.01,
        "currency": "USD",
    }
    defaults.update(overrides)
    return UsageEntry(**defaults)  # type: ignore[arg-type]


def _seed_ledger(ledger_dir: Path, entries: list[UsageEntry]) -> None:
    """Write entries to a ledger directory."""
    ledger = UsageLedger(ledger_dir)
    for e in entries:
        ledger.record(e)


# ---------------------------------------------------------------------------
# daily_report
# ---------------------------------------------------------------------------


class TestDailyReport:
    def test_empty_ledger(self, tmp_path: Path) -> None:
        d = tmp_path / "ledger"
        report = daily_report(d)
        assert report["total_tokens"] == 0
        assert report["total_usd"] == 0.0
        assert report["by_provider"] == {}
        assert report["by_model"] == {}

    def test_today_default(self, tmp_path: Path) -> None:
        d = tmp_path / "ledger"
        _seed_ledger(d, [_make_entry(), _make_entry(total_tokens=200, estimated_usd=0.002)])

        report = daily_report(d)
        today_str = datetime.now(tz=UTC).date().isoformat()
        assert report["date"] == today_str
        assert report["total_tokens"] == 350
        assert report["total_usd"] == 0.003

    def test_specific_date(self, tmp_path: Path) -> None:
        d = tmp_path / "ledger"
        ts_yesterday = (datetime.now(tz=UTC) - timedelta(days=1)).isoformat()
        _seed_ledger(
            d,
            [
                _make_entry(ts=ts_yesterday, total_tokens=500, estimated_usd=0.005),
                _make_entry(),  # today
            ],
        )

        yesterday_str = (datetime.now(tz=UTC) - timedelta(days=1)).date().isoformat()
        report = daily_report(d, date=yesterday_str)
        assert report["date"] == yesterday_str
        assert report["total_tokens"] == 500

    def test_by_provider_grouping(self, tmp_path: Path) -> None:
        d = tmp_path / "ledger"
        _seed_ledger(
            d,
            [
                _make_entry(provider="openai", total_tokens=100, estimated_usd=0.001),
                _make_entry(provider="anthropic", total_tokens=200, estimated_usd=0.003),
                _make_entry(provider="openai", total_tokens=300, estimated_usd=0.002),
            ],
        )

        report = daily_report(d)
        assert report["by_provider"]["openai"]["tokens"] == 400
        assert report["by_provider"]["openai"]["calls"] == 2
        assert report["by_provider"]["anthropic"]["tokens"] == 200
        assert report["by_provider"]["anthropic"]["calls"] == 1

    def test_by_model_grouping(self, tmp_path: Path) -> None:
        d = tmp_path / "ledger"
        _seed_ledger(
            d,
            [
                _make_entry(model="gpt-4o", total_tokens=100),
                _make_entry(model="claude-sonnet", total_tokens=200),
                _make_entry(model="gpt-4o", total_tokens=300),
            ],
        )

        report = daily_report(d)
        assert report["by_model"]["gpt-4o"]["tokens"] == 400
        assert report["by_model"]["claude-sonnet"]["tokens"] == 200


# ---------------------------------------------------------------------------
# weekly_report
# ---------------------------------------------------------------------------


class TestWeeklyReport:
    def test_empty_ledger(self, tmp_path: Path) -> None:
        d = tmp_path / "ledger"
        report = weekly_report(d)
        assert "period" in report
        assert len(report["days"]) == 7
        assert report["totals"]["total_tokens"] == 0

    def test_entries_across_days(self, tmp_path: Path) -> None:
        d = tmp_path / "ledger"
        now = datetime.now(tz=UTC)
        entries = []
        for offset in range(3):
            ts = (now - timedelta(days=offset)).isoformat()
            entries.append(
                _make_entry(ts=ts, total_tokens=100 * (offset + 1), estimated_usd=0.001),
            )
        _seed_ledger(d, entries)

        report = weekly_report(d)
        assert report["totals"]["total_tokens"] == 100 + 200 + 300
        assert report["totals"]["total_usd"] == 0.003
        assert len(report["days"]) == 7

    def test_period_format(self, tmp_path: Path) -> None:
        d = tmp_path / "ledger"
        report = weekly_report(d)
        assert ".." in report["period"]

    def test_each_day_has_keys(self, tmp_path: Path) -> None:
        d = tmp_path / "ledger"
        _seed_ledger(d, [_make_entry()])
        report = weekly_report(d)
        for day in report["days"]:
            assert "date" in day
            assert "total_tokens" in day
            assert "total_usd" in day
            assert "by_provider" in day
            assert "by_model" in day


# ---------------------------------------------------------------------------
# monthly_report
# ---------------------------------------------------------------------------


class TestMonthlyReport:
    def test_empty_ledger(self, tmp_path: Path) -> None:
        d = tmp_path / "ledger"
        report = monthly_report(d)
        assert report["total_tokens"] == 0
        assert report["total_usd"] == 0.0
        assert report["by_provider"] == {}
        assert report["by_day"] == {}

    def test_entries_in_current_month(self, tmp_path: Path) -> None:
        d = tmp_path / "ledger"
        _seed_ledger(
            d,
            [
                _make_entry(total_tokens=100, estimated_usd=0.001),
                _make_entry(total_tokens=200, estimated_usd=0.002),
            ],
        )

        report = monthly_report(d)
        assert report["total_tokens"] == 300
        assert report["total_usd"] == 0.003
        assert "period" in report

    def test_by_day_grouping(self, tmp_path: Path) -> None:
        d = tmp_path / "ledger"
        now = datetime.now(tz=UTC)
        today_str = now.date().isoformat()

        _seed_ledger(
            d,
            [
                _make_entry(total_tokens=100, estimated_usd=0.001),
                _make_entry(total_tokens=200, estimated_usd=0.002),
            ],
        )

        report = monthly_report(d)
        assert today_str in report["by_day"]
        day_data = report["by_day"][today_str]
        assert day_data["total_tokens"] == 300
        assert day_data["calls"] == 2

    def test_previous_month_excluded(self, tmp_path: Path) -> None:
        d = tmp_path / "ledger"
        now = datetime.now(tz=UTC)
        # Entry from last month
        last_month = now.replace(day=1) - timedelta(days=1)
        _seed_ledger(
            d,
            [
                _make_entry(ts=last_month.isoformat(), total_tokens=999, estimated_usd=9.0),
                _make_entry(total_tokens=100, estimated_usd=0.001),
            ],
        )

        report = monthly_report(d)
        assert report["total_tokens"] == 100


# ---------------------------------------------------------------------------
# provider_breakdown
# ---------------------------------------------------------------------------


class TestProviderBreakdown:
    def test_empty_ledger(self, tmp_path: Path) -> None:
        d = tmp_path / "ledger"
        result = provider_breakdown(d)
        assert result == []

    def test_single_provider(self, tmp_path: Path) -> None:
        d = tmp_path / "ledger"
        _seed_ledger(
            d,
            [
                _make_entry(provider="openai", model="gpt-4o", estimated_usd=0.01),
            ],
        )

        result = provider_breakdown(d)
        assert len(result) == 1
        assert result[0]["provider"] == "openai"
        assert result[0]["model"] == "gpt-4o"
        assert result[0]["pct"] == 100.0

    def test_sorted_by_cost_descending(self, tmp_path: Path) -> None:
        d = tmp_path / "ledger"
        _seed_ledger(
            d,
            [
                _make_entry(provider="openai", model="gpt-4o", estimated_usd=0.001),
                _make_entry(provider="anthropic", model="claude-sonnet", estimated_usd=0.01),
                _make_entry(provider="openai", model="gpt-4o", estimated_usd=0.001),
            ],
        )

        result = provider_breakdown(d)
        assert len(result) == 2
        assert result[0]["provider"] == "anthropic"
        assert result[0]["usd"] > result[1]["usd"]

    def test_multiple_models_same_provider(self, tmp_path: Path) -> None:
        d = tmp_path / "ledger"
        _seed_ledger(
            d,
            [
                _make_entry(provider="openai", model="gpt-4o", estimated_usd=0.005),
                _make_entry(provider="openai", model="gpt-3.5", estimated_usd=0.001),
            ],
        )

        result = provider_breakdown(d)
        assert len(result) == 2  # grouped by (provider, model)
        providers = {r["model"] for r in result}
        assert providers == {"gpt-4o", "gpt-3.5"}

    def test_pct_sums_to_100(self, tmp_path: Path) -> None:
        d = tmp_path / "ledger"
        _seed_ledger(
            d,
            [
                _make_entry(provider="openai", model="gpt-4o", estimated_usd=0.006),
                _make_entry(provider="anthropic", model="claude-sonnet", estimated_usd=0.004),
            ],
        )

        result = provider_breakdown(d)
        total_pct = sum(r["pct"] for r in result)
        assert abs(total_pct - 100.0) < 0.2  # allow rounding

    def test_breakdown_entry_keys(self, tmp_path: Path) -> None:
        d = tmp_path / "ledger"
        _seed_ledger(d, [_make_entry()])

        result = provider_breakdown(d)
        assert len(result) == 1
        entry = result[0]
        assert set(entry.keys()) == {"provider", "model", "tokens", "usd", "calls", "pct"}


# ---------------------------------------------------------------------------
# format_report_text
# ---------------------------------------------------------------------------


class TestFormatReportText:
    def test_daily_format(self, tmp_path: Path) -> None:
        d = tmp_path / "ledger"
        _seed_ledger(
            d,
            [
                _make_entry(provider="openai", model="gpt-4o"),
            ],
        )
        report = daily_report(d)
        text = format_report_text(report)

        assert "Cost Report" in text
        assert "Total tokens" in text
        assert "By provider" in text
        assert "openai" in text

    def test_weekly_format(self, tmp_path: Path) -> None:
        d = tmp_path / "ledger"
        _seed_ledger(d, [_make_entry()])
        report = weekly_report(d)
        text = format_report_text(report)

        assert "Cost Report" in text
        assert "Daily breakdown" in text
        assert "Week totals" in text

    def test_monthly_format(self, tmp_path: Path) -> None:
        d = tmp_path / "ledger"
        _seed_ledger(d, [_make_entry()])
        report = monthly_report(d)
        text = format_report_text(report)

        assert "Cost Report" in text
        assert "By day" in text

    def test_empty_report(self) -> None:
        text = format_report_text({})
        assert "Cost Report" in text


# ---------------------------------------------------------------------------
# format_report_json
# ---------------------------------------------------------------------------


class TestFormatReportJson:
    def test_valid_json(self, tmp_path: Path) -> None:
        d = tmp_path / "ledger"
        _seed_ledger(d, [_make_entry()])
        report = daily_report(d)
        result = format_report_json(report)
        parsed = json.loads(result)
        assert parsed["total_tokens"] == 150

    def test_weekly_json(self, tmp_path: Path) -> None:
        d = tmp_path / "ledger"
        _seed_ledger(d, [_make_entry()])
        report = weekly_report(d)
        result = format_report_json(report)
        parsed = json.loads(result)
        assert "days" in parsed
        assert "totals" in parsed

    def test_empty_report_json(self) -> None:
        result = format_report_json({"total_tokens": 0})
        parsed = json.loads(result)
        assert parsed["total_tokens"] == 0
