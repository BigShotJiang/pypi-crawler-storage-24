"""Tests for Stage 4.3 — CLI/API integration for distributed mode.

Tests cover:
- session start --scheduler flag (distributed mode)
- session status with expanded goal table
- session logs command
- REST API: POST /sessions, GET /sessions/{id}/goals, GET goals/{id}/logs
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from starlette.testclient import TestClient
from typer.testing import CliRunner

from owlmind.api.app import create_app
from owlmind.cli import app

runner = CliRunner()


# ===================================================================
# Fixtures
# ===================================================================


@pytest.fixture()
def tmp_workspace(tmp_path: Path) -> dict[str, Path]:
    """Create a minimal workspace with all required dirs."""
    dirs = {
        "runs": tmp_path / "runs",
        "ledger": tmp_path / "ledger",
        "queue": tmp_path / "queue",
        "policies": tmp_path / "policies",
        "sessions": tmp_path / "sessions",
    }
    for d in dirs.values():
        d.mkdir()
    return dirs


@pytest.fixture()
def api_client(tmp_workspace: dict[str, Path]) -> TestClient:
    """Create a test client for API tests (dev mode, no auth)."""
    fastapi_app = create_app(
        runs_dir=tmp_workspace["runs"],
        ledger_dir=tmp_workspace["ledger"],
        queue_path=tmp_workspace["queue"],
        policies_dir=tmp_workspace["policies"],
    )
    return TestClient(fastapi_app)


# ===================================================================
# Helpers
# ===================================================================


def _mock_session_meta(
    session_id: str = "sess-001",
    goals: list | None = None,
) -> MagicMock:
    """Build a mock SessionMeta."""
    meta = MagicMock()
    meta.session_id = session_id
    meta.status = "RUNNING"
    meta.created_at = "2026-02-27T00:00:00"

    if goals is None:
        g1 = MagicMock()
        g1.id = "G1"
        g1.goal = "Write tests"
        g1.depends_on = []
        g2 = MagicMock()
        g2.id = "G2"
        g2.goal = "Fix bugs"
        g2.depends_on = ["G1"]
        meta.goals = [g1, g2]
    else:
        meta.goals = goals

    meta.runs = []
    meta.max_concurrency = 1
    meta.continue_on_fail = False
    meta.last_block_reason = ""
    meta.current_goal_index = 0
    return meta


def _create_session_dir(
    sessions_dir: Path,
    session_id: str,
    meta: dict,
) -> Path:
    """Create a fake session directory with session_meta.json."""
    session_path = sessions_dir / session_id
    session_path.mkdir(parents=True, exist_ok=True)
    (session_path / "session_meta.json").write_text(json.dumps(meta, indent=2))
    return session_path


def _create_session_events(
    sessions_dir: Path,
    session_id: str,
    events: list[dict],
) -> None:
    """Write session events to session.jsonl."""
    session_path = sessions_dir / session_id
    session_path.mkdir(parents=True, exist_ok=True)
    lines = [json.dumps(e) for e in events]
    (session_path / "session.jsonl").write_text("\n".join(lines) + "\n")


def _session_meta_dict(
    session_id: str = "sess-test",
    status: str = "RUNNING",
    goals: list | None = None,
    runs: list | None = None,
) -> dict:
    """Build a session metadata dict."""
    return {
        "session_id": session_id,
        "status": status,
        "created_at": "2026-02-27T00:00:00",
        "updated_at": "2026-02-27T00:30:00",
        "current_goal_index": 0,
        "goals": goals
        or [
            {"id": "G1", "goal": "Write tests", "depends_on": [], "workspace": "."},
            {"id": "G2", "goal": "Fix bugs", "depends_on": ["G1"], "workspace": "."},
        ],
        "runs": runs or [],
        "last_block_reason": "",
        "config": {},
        "max_concurrency": 2,
        "continue_on_fail": False,
    }


# ===================================================================
# TestSessionStartScheduler — CLI --scheduler flag
# ===================================================================


class TestSessionStartScheduler:
    """Tests for session start --scheduler (distributed mode)."""

    def test_scheduler_flag_creates_session_without_running(self, tmp_path: Path) -> None:
        """With --scheduler, session is created but run_session is NOT called."""
        goals_file = tmp_path / "goals.yaml"
        goals_file.write_text("goals:\n  - goal: first task\n  - goal: second task\n")

        mock_meta = _mock_session_meta()

        with patch("owlmind.session.create_session", return_value=mock_meta) as mock_create:
            result = runner.invoke(
                app,
                [
                    "session",
                    "start",
                    "--goals-file",
                    str(goals_file),
                    "--scheduler",
                ],
            )

        assert result.exit_code == 0, result.output
        assert "distributed" in result.output.lower()
        assert "scheduler" in result.output.lower()
        mock_create.assert_called_once()

    def test_scheduler_flag_does_not_call_run_session(self, tmp_path: Path) -> None:
        """--scheduler flag prevents run_session from being called."""
        goals_file = tmp_path / "goals.yaml"
        goals_file.write_text("goals:\n  - goal: task one\n")

        mock_meta = _mock_session_meta()

        with (
            patch("owlmind.session.create_session", return_value=mock_meta),
            patch("owlmind.session_runner.run_session") as mock_run,
        ):
            result = runner.invoke(
                app,
                [
                    "session",
                    "start",
                    "--goals-file",
                    str(goals_file),
                    "--scheduler",
                ],
            )

        assert result.exit_code == 0
        mock_run.assert_not_called()

    def test_scheduler_flag_shows_session_id(self, tmp_path: Path) -> None:
        goals_file = tmp_path / "goals.yaml"
        goals_file.write_text("goals:\n  - goal: task\n")

        mock_meta = _mock_session_meta(session_id="sess-abc123")

        with patch("owlmind.session.create_session", return_value=mock_meta):
            result = runner.invoke(
                app,
                [
                    "session",
                    "start",
                    "--goals-file",
                    str(goals_file),
                    "--scheduler",
                ],
            )

        assert result.exit_code == 0
        assert "sess-abc123" in result.output

    def test_without_scheduler_runs_locally(self, tmp_path: Path) -> None:
        """Without --scheduler, run_session IS called (local mode)."""
        goals_file = tmp_path / "goals.yaml"
        goals_file.write_text("goals:\n  - goal: task\n")

        mock_meta = _mock_session_meta()
        mock_result = MagicMock()
        mock_result.status = "DONE"
        mock_result.session_id = "sess-001"
        mock_result.goals_total = 1
        mock_result.goals_done = 1
        mock_result.goals_failed = 0
        mock_result.goals_blocked = 0
        mock_result.goals_skipped = 0
        mock_result.last_block_reason = ""
        mock_result.next_commands = []

        with (
            patch("owlmind.session.create_session", return_value=mock_meta),
            patch("owlmind.session_runner.run_session", return_value=mock_result) as mock_run,
        ):
            result = runner.invoke(
                app,
                ["session", "start", "--goals-file", str(goals_file)],
            )

        assert result.exit_code == 0
        mock_run.assert_called_once()


# ===================================================================
# TestSessionStatusEnhanced — updated goals table
# ===================================================================


class TestSessionStatusEnhanced:
    """Tests for enhanced session status with Deps column."""

    def test_status_shows_deps_column(self) -> None:
        mock_meta = _mock_session_meta()

        with patch("owlmind.session.load_session", return_value=mock_meta):
            result = runner.invoke(
                app,
                ["session", "status", "--session-id", "sess-001"],
            )

        assert result.exit_code == 0
        assert "Deps" in result.output

    def test_status_shows_dispatched_status(self) -> None:
        mock_meta = _mock_session_meta()
        run_info = MagicMock()
        run_info.goal_id = "G1"
        run_info.run_id = "run-abc"
        run_info.status = "dispatched"
        mock_meta.runs = [run_info]

        with patch("owlmind.session.load_session", return_value=mock_meta):
            result = runner.invoke(
                app,
                ["session", "status", "--session-id", "sess-001"],
            )

        assert result.exit_code == 0
        assert "dispatched" in result.output

    def test_status_shows_concurrency_info(self) -> None:
        mock_meta = _mock_session_meta()
        mock_meta.max_concurrency = 4
        mock_meta.continue_on_fail = True

        with patch("owlmind.session.load_session", return_value=mock_meta):
            result = runner.invoke(
                app,
                ["session", "status", "--session-id", "sess-001"],
            )

        assert result.exit_code == 0
        assert "4" in result.output
        assert "Continue on fail" in result.output


# ===================================================================
# TestSessionLogs — session logs command
# ===================================================================


class TestSessionLogs:
    """Tests for session logs command."""

    def test_logs_session_not_found(self) -> None:
        with patch(
            "owlmind.session.load_session",
            side_effect=FileNotFoundError("Session not found"),
        ):
            result = runner.invoke(
                app,
                ["session", "logs", "--session-id", "nonexistent"],
            )

        assert result.exit_code == 1

    def test_logs_shows_events(self, tmp_path: Path) -> None:
        mock_meta = _mock_session_meta()

        events = [
            {"event": "SESSION_CREATED", "timestamp": "2026-02-27T00:00:00"},
            {"event": "GOAL_DISPATCHED", "goal_id": "G1", "timestamp": "2026-02-27T00:01:00"},
            {"event": "GOAL_DONE", "goal_id": "G1", "timestamp": "2026-02-27T00:05:00"},
        ]

        with (
            patch("owlmind.session.load_session", return_value=mock_meta),
            patch("owlmind.session.read_session_events", return_value=events),
        ):
            result = runner.invoke(
                app,
                ["session", "logs", "--session-id", "sess-001"],
            )

        assert result.exit_code == 0
        assert "SESSION_CREATED" in result.output
        assert "GOAL_DISPATCHED" in result.output
        assert "GOAL_DONE" in result.output

    def test_logs_filters_by_goal(self, tmp_path: Path) -> None:
        mock_meta = _mock_session_meta()

        events = [
            {"event": "SESSION_CREATED", "timestamp": "2026-02-27T00:00:00"},
            {"event": "GOAL_DISPATCHED", "goal_id": "G1", "timestamp": "2026-02-27T00:01:00"},
            {"event": "GOAL_DISPATCHED", "goal_id": "G2", "timestamp": "2026-02-27T00:02:00"},
        ]

        with (
            patch("owlmind.session.load_session", return_value=mock_meta),
            patch("owlmind.session.read_session_events", return_value=events),
        ):
            result = runner.invoke(
                app,
                ["session", "logs", "--session-id", "sess-001", "--goal", "G1"],
            )

        assert result.exit_code == 0
        assert "G1" in result.output

    def test_logs_no_events(self) -> None:
        mock_meta = _mock_session_meta()

        with (
            patch("owlmind.session.load_session", return_value=mock_meta),
            patch("owlmind.session.read_session_events", return_value=[]),
        ):
            result = runner.invoke(
                app,
                ["session", "logs", "--session-id", "sess-001"],
            )

        assert result.exit_code == 0
        assert "No events" in result.output


# ===================================================================
# TestAPICreateSession — POST /api/v1/sessions
# ===================================================================


class TestAPICreateSession:
    """Tests for POST /api/v1/sessions endpoint."""

    def test_create_session_success(
        self,
        api_client: TestClient,
    ) -> None:
        resp = api_client.post(
            "/api/v1/sessions",
            json={
                "goals": [
                    {"id": "G1", "goal": "Write tests"},
                    {"id": "G2", "goal": "Fix bugs", "depends_on": ["G1"]},
                ],
                "workspace": "/tmp/ws",
                "max_concurrency": 2,
            },
        )

        assert resp.status_code == 201
        data = resp.json()
        assert "session_id" in data
        assert data["status"] == "RUNNING"
        assert data["goals_count"] == 2
        assert data["mode"] == "local"

    def test_create_session_scheduler_mode(
        self,
        api_client: TestClient,
    ) -> None:
        resp = api_client.post(
            "/api/v1/sessions",
            json={
                "goals": [{"id": "G1", "goal": "Deploy"}],
                "scheduler": True,
            },
        )

        assert resp.status_code == 201
        data = resp.json()
        assert data["mode"] == "scheduler"
        assert data["goals_count"] == 1

    def test_create_session_empty_goals_rejected(
        self,
        api_client: TestClient,
    ) -> None:
        resp = api_client.post(
            "/api/v1/sessions",
            json={"goals": []},
        )

        assert resp.status_code == 422  # validation error

    def test_create_session_goal_without_text_rejected(
        self,
        api_client: TestClient,
    ) -> None:
        resp = api_client.post(
            "/api/v1/sessions",
            json={
                "goals": [{"id": "G1"}],
            },
        )

        assert resp.status_code == 400
        assert "no 'goal' text" in resp.json()["detail"].lower()

    def test_created_session_appears_in_list(
        self,
        api_client: TestClient,
    ) -> None:
        # Create session
        resp = api_client.post(
            "/api/v1/sessions",
            json={
                "goals": [{"id": "G1", "goal": "Test"}],
            },
        )
        assert resp.status_code == 201
        session_id = resp.json()["session_id"]

        # Check it appears in list
        resp_list = api_client.get("/api/v1/sessions")
        assert resp_list.status_code == 200
        ids = [s["session_id"] for s in resp_list.json()]
        assert session_id in ids

    def test_created_session_detail(
        self,
        api_client: TestClient,
    ) -> None:
        resp = api_client.post(
            "/api/v1/sessions",
            json={
                "goals": [
                    {"id": "G1", "goal": "First task"},
                    {"id": "G2", "goal": "Second task", "depends_on": ["G1"]},
                ],
                "max_concurrency": 3,
                "continue_on_fail": True,
            },
        )
        assert resp.status_code == 201
        session_id = resp.json()["session_id"]

        # Get detail
        resp_detail = api_client.get(f"/api/v1/sessions/{session_id}")
        assert resp_detail.status_code == 200
        data = resp_detail.json()
        assert data["max_concurrency"] == 3
        assert data["continue_on_fail"] is True
        assert len(data["goals"]) == 2


# ===================================================================
# TestAPISessionGoals — GET /api/v1/sessions/{id}/goals
# ===================================================================


class TestAPISessionGoals:
    """Tests for GET /api/v1/sessions/{id}/goals endpoint."""

    def test_goals_endpoint_returns_goals(
        self,
        api_client: TestClient,
        tmp_workspace: dict[str, Path],
    ) -> None:
        meta = _session_meta_dict(
            "sess-goals-test",
            runs=[
                {
                    "goal_id": "G1",
                    "run_id": "run-001",
                    "status": "done",
                    "started_at": "t0",
                    "ended_at": "t1",
                },
            ],
        )
        _create_session_dir(tmp_workspace["sessions"], "sess-goals-test", meta)

        resp = api_client.get("/api/v1/sessions/sess-goals-test/goals")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 2
        assert data[0]["id"] == "G1"
        assert data[0]["status"] == "done"
        assert data[0]["run_id"] == "run-001"
        assert data[1]["id"] == "G2"
        assert data[1]["status"] == "pending"
        assert data[1]["depends_on"] == ["G1"]

    def test_goals_endpoint_session_not_found(
        self,
        api_client: TestClient,
    ) -> None:
        resp = api_client.get("/api/v1/sessions/nonexistent/goals")
        assert resp.status_code == 404

    def test_goals_endpoint_all_pending(
        self,
        api_client: TestClient,
        tmp_workspace: dict[str, Path],
    ) -> None:
        meta = _session_meta_dict("sess-pending")
        _create_session_dir(tmp_workspace["sessions"], "sess-pending", meta)

        resp = api_client.get("/api/v1/sessions/sess-pending/goals")
        assert resp.status_code == 200
        data = resp.json()
        assert all(g["status"] == "pending" for g in data)


# ===================================================================
# TestAPIGoalLogs — GET /api/v1/sessions/{id}/goals/{gid}/logs
# ===================================================================


class TestAPIGoalLogs:
    """Tests for GET /api/v1/sessions/{id}/goals/{gid}/logs endpoint."""

    def test_goal_logs_with_session_events(
        self,
        api_client: TestClient,
        tmp_workspace: dict[str, Path],
    ) -> None:
        meta = _session_meta_dict("sess-logs")
        _create_session_dir(tmp_workspace["sessions"], "sess-logs", meta)
        _create_session_events(
            tmp_workspace["sessions"],
            "sess-logs",
            [
                {"event": "GOAL_DISPATCHED", "goal_id": "G1", "timestamp": "t0"},
                {"event": "GOAL_DONE", "goal_id": "G1", "timestamp": "t1"},
                {"event": "GOAL_DISPATCHED", "goal_id": "G2", "timestamp": "t2"},
            ],
        )

        resp = api_client.get("/api/v1/sessions/sess-logs/goals/G1/logs")
        assert resp.status_code == 200
        data = resp.json()
        assert data["goal_id"] == "G1"
        assert len(data["session_events"]) == 2  # G1 events only
        assert data["run_events"] == []

    def test_goal_logs_with_run_events(
        self,
        api_client: TestClient,
        tmp_workspace: dict[str, Path],
    ) -> None:
        meta = _session_meta_dict(
            "sess-run-logs",
            runs=[
                {
                    "goal_id": "G1",
                    "run_id": "run-001",
                    "status": "done",
                    "started_at": "",
                    "ended_at": "",
                },
            ],
        )
        _create_session_dir(tmp_workspace["sessions"], "sess-run-logs", meta)

        # Create run events
        run_dir = tmp_workspace["runs"] / "run-001"
        run_dir.mkdir(parents=True)
        run_events = [
            {"type": "WORKER_CALLED", "timestamp": "t0"},
            {"type": "WORKER_DONE", "timestamp": "t1"},
        ]
        (run_dir / "run.jsonl").write_text("\n".join(json.dumps(e) for e in run_events) + "\n")

        resp = api_client.get("/api/v1/sessions/sess-run-logs/goals/G1/logs")
        assert resp.status_code == 200
        data = resp.json()
        assert data["run_id"] == "run-001"
        assert len(data["run_events"]) == 2

    def test_goal_logs_session_not_found(
        self,
        api_client: TestClient,
    ) -> None:
        resp = api_client.get("/api/v1/sessions/nonexistent/goals/G1/logs")
        assert resp.status_code == 404

    def test_goal_logs_goal_not_found(
        self,
        api_client: TestClient,
        tmp_workspace: dict[str, Path],
    ) -> None:
        meta = _session_meta_dict("sess-no-goal")
        _create_session_dir(tmp_workspace["sessions"], "sess-no-goal", meta)

        resp = api_client.get("/api/v1/sessions/sess-no-goal/goals/NONEXISTENT/logs")
        assert resp.status_code == 404
        assert "Goal not found" in resp.json()["detail"]

    def test_goal_logs_empty(
        self,
        api_client: TestClient,
        tmp_workspace: dict[str, Path],
    ) -> None:
        meta = _session_meta_dict("sess-empty-logs")
        _create_session_dir(tmp_workspace["sessions"], "sess-empty-logs", meta)

        resp = api_client.get("/api/v1/sessions/sess-empty-logs/goals/G1/logs")
        assert resp.status_code == 200
        data = resp.json()
        assert data["session_events"] == []
        assert data["run_events"] == []


# ===================================================================
# TestExistingSessionsAPIStillWorks — regression
# ===================================================================


class TestExistingSessionsAPIStillWorks:
    """Regression tests: existing GET endpoints still work."""

    def test_list_sessions_empty(self, api_client: TestClient) -> None:
        resp = api_client.get("/api/v1/sessions")
        assert resp.status_code == 200
        assert resp.json() == []

    def test_get_session_detail(
        self,
        api_client: TestClient,
        tmp_workspace: dict[str, Path],
    ) -> None:
        meta = _session_meta_dict("sess-regression")
        _create_session_dir(tmp_workspace["sessions"], "sess-regression", meta)

        resp = api_client.get("/api/v1/sessions/sess-regression")
        assert resp.status_code == 200
        data = resp.json()
        assert data["session_id"] == "sess-regression"
        assert data["max_concurrency"] == 2

    def test_get_session_not_found(self, api_client: TestClient) -> None:
        resp = api_client.get("/api/v1/sessions/nonexistent")
        assert resp.status_code == 404
