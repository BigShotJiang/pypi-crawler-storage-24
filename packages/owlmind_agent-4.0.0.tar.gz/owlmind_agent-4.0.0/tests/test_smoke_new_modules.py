"""Smoke tests for vision, browser, and ast_parser modules.

Verifies imports and basic class instantiation without requiring
external dependencies (playwright, pyautogui, tree-sitter, etc.).
"""

from __future__ import annotations

import time

# ---------------------------------------------------------------------------
# vision
# ---------------------------------------------------------------------------


def test_vision_models_import() -> None:
    from owlmind.vision.models import ComputerAction, ScreenshotResult

    r = ScreenshotResult(
        base64_image="aGVsbG8=",
        width=1920,
        height=1080,
        timestamp=time.time(),
    )
    assert r.width == 1920
    assert r.height == 1080
    assert r.media_type == "image/png"

    action = ComputerAction(action_type="screenshot")
    assert action.action_type == "screenshot"


def test_vision_smart_driver_import() -> None:
    from owlmind.vision.smart_driver import AgentResult, AgentStep

    step = AgentStep(step_num=1, description="click button")
    assert step.step_num == 1
    assert step.success is False

    result = AgentResult(task="open browser")
    assert result.task == "open browser"
    assert result.step_count == 0


def test_vision_smart_driver_module_attrs() -> None:
    from owlmind.vision import smart_driver as sd

    assert hasattr(sd, "AgentStep")
    assert hasattr(sd, "AgentResult")
    assert hasattr(sd, "SmartComputerAgent")


def test_vision_screenshot_module_import() -> None:
    from owlmind.vision import screenshot

    assert hasattr(screenshot, "capture_screenshot")
    assert hasattr(screenshot, "encode_image_file")


def test_vision_macos_module_import() -> None:
    from owlmind.vision import macos

    assert hasattr(macos, "get_screen_size")


# ---------------------------------------------------------------------------
# browser
# ---------------------------------------------------------------------------


def test_browser_models_import() -> None:
    from owlmind.browser.models import PageResult, SearchResult

    page = PageResult(url="https://example.com", title="Example", content="hello")
    assert page.url == "https://example.com"
    assert page.status_code == 200

    search = SearchResult(query="python owlmind")
    assert search.query == "python owlmind"
    assert search.results == []


def test_browser_driver_import() -> None:
    from owlmind.browser import driver as bd

    assert hasattr(bd, "BrowserDriver")


def test_browser_models_browser_action() -> None:
    from owlmind.browser.models import BrowserAction

    action = BrowserAction(action="navigate", url="https://example.com")
    assert action.action == "navigate"
    assert action.url == "https://example.com"


# ---------------------------------------------------------------------------
# ast_parser
# ---------------------------------------------------------------------------


def test_ast_parser_models_import() -> None:
    from owlmind.ast_parser.models import CodeChunk, FileAnalysis

    chunk = CodeChunk(
        file_path="src/foo.py",
        language="python",
        content="def my_func(): pass",
        start_line=1,
        end_line=1,
        chunk_type="function",
        name="my_func",
    )
    assert chunk.name == "my_func"
    assert chunk.chunk_type == "function"
    assert len(chunk.chunk_id) > 0

    analysis = FileAnalysis(file_path="src/foo.py", language="python")
    assert analysis.language == "python"
    assert analysis.functions == []


def test_ast_parser_analyzer_import() -> None:
    from owlmind.ast_parser.analyzer import CodeAnalyzer

    analyzer = CodeAnalyzer()
    assert analyzer is not None
    assert hasattr(analyzer, "analyze_file")
    assert hasattr(analyzer, "generate_repo_map")
    assert hasattr(analyzer, "chunk_for_rag")


def test_ast_parser_analyzer_repo_map(tmp_path: object) -> None:
    """generate_repo_map works even without tree-sitter (fallback path)."""
    import tempfile
    from pathlib import Path

    from owlmind.ast_parser.analyzer import CodeAnalyzer

    with tempfile.TemporaryDirectory() as d:
        p = Path(d)
        (p / "hello.py").write_text("def hello(): pass\n")
        analyzer = CodeAnalyzer()
        result = analyzer.generate_repo_map(str(p), max_tokens=500)
        assert isinstance(result, str)


def test_ast_parser_analyze_file(tmp_path: object) -> None:
    """analyze_file returns FileAnalysis (fallback without tree-sitter)."""
    import tempfile
    from pathlib import Path

    from owlmind.ast_parser.analyzer import CodeAnalyzer
    from owlmind.ast_parser.models import FileAnalysis

    with tempfile.TemporaryDirectory() as d:
        p = Path(d) / "utils.py"
        p.write_text("def add(a, b):\n    return a + b\n")
        analyzer = CodeAnalyzer()
        result = analyzer.analyze_file(str(p))
        assert isinstance(result, FileAnalysis)
        assert result.file_path == str(p)
