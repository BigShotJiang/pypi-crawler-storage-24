"""Tests for FS77 — CLI cycle commands (start, status, next, submit, approve, verify)."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from owlmind.cli import app

runner = CliRunner()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_cycle_meta(extra: dict | None = None) -> MagicMock:
    """Build a mock CycleMeta object."""
    meta = MagicMock()
    meta.run_id = "run-001"
    meta.goal = "Fix authentication bug"
    meta.state.value = "STARTED_WAIT_PLANNER"
    meta.iteration = 1
    meta.limits.max_iterations = 5
    meta.workspace = "."
    meta.extra = extra or {}
    meta.hard_fail_reasons = []
    return meta


def _make_mgr(meta: MagicMock | None = None) -> MagicMock:
    """Build a mock CycleManager with all common methods preset."""
    m = meta or _make_cycle_meta()
    mgr = MagicMock()
    mgr.start.return_value = m
    mgr.status.return_value = m
    mgr.next.return_value = (m, "Next: submit planner response")
    mgr.submit_planner.return_value = m
    mgr.submit_worker.return_value = m
    mgr.submit_judge.return_value = m
    mgr.run_planner_llm.return_value = m
    mgr.run_judge_llm.return_value = m
    mgr.next_inbox_hint.return_value = "owlmind cycle submit-planner --run-id run-001"
    return mgr


def _mcm_patch(
    target: str,
    mgr: MagicMock,
    read_events_count: int = 0,
) -> tuple:
    """Return (evidence_mock, patch_ctx) for make_cycle_manager."""
    evidence = MagicMock()
    evidence.read_events.return_value = list(range(read_events_count))
    return evidence, patch(target, return_value=(MagicMock(), evidence, mgr))


# ---------------------------------------------------------------------------
# cycle start
# ---------------------------------------------------------------------------


class TestCycleStart:
    def test_start_ok(self) -> None:
        """cycle start --goal 'Fix' → exit 0, run-id and 'Cycle started' in output."""
        mgr = _make_mgr()
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "start", "--goal", "Fix bug"])

        assert result.exit_code == 0, result.output
        assert "Cycle started" in result.output
        assert "run-001" in result.output

    def test_start_sandbox(self) -> None:
        """cycle start with sandbox meta → 'Sandbox' label printed."""
        sandbox_extra = {
            "sandbox": {"enabled": True, "kind": "worktree", "branch_name": "owlmind/run-001"},
        }
        meta = _make_cycle_meta(extra=sandbox_extra)
        mgr = _make_mgr(meta)
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "start", "--goal", "Fix bug"])

        assert result.exit_code == 0, result.output
        assert "Sandbox" in result.output


# ---------------------------------------------------------------------------
# cycle status
# ---------------------------------------------------------------------------


class TestCycleStatus:
    def test_status_ok(self) -> None:
        """cycle status → exit 0, run-id shown, event count printed."""
        mgr = _make_mgr()
        evidence, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr, read_events_count=3)

        with ctx:
            result = runner.invoke(app, ["cycle", "status", "--run-id", "run-001"])

        assert result.exit_code == 0, result.output
        assert "run-001" in result.output
        assert "3" in result.output  # events count

    def test_status_error(self) -> None:
        """cycle status when mgr.status raises → exit 1."""
        mgr = _make_mgr()
        mgr.status.side_effect = FileNotFoundError("run not found")
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "status", "--run-id", "run-missing"])

        assert result.exit_code == 1


# ---------------------------------------------------------------------------
# cycle next
# ---------------------------------------------------------------------------


class TestCycleNext:
    def test_next_ok(self) -> None:
        """cycle next → exit 0, state value in output."""
        mgr = _make_mgr()
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "next", "--run-id", "run-001"])

        assert result.exit_code == 0, result.output
        assert "STARTED_WAIT_PLANNER" in result.output

    def test_next_error(self) -> None:
        """cycle next when mgr.next raises → exit 1."""
        mgr = _make_mgr()
        mgr.next.side_effect = RuntimeError("no inbox")
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "next", "--run-id", "run-001"])

        assert result.exit_code == 1


# ---------------------------------------------------------------------------
# cycle submit-planner
# ---------------------------------------------------------------------------


class TestCycleSubmit:
    def test_submit_planner_ok(self) -> None:
        """cycle submit-planner → exit 0, 'accepted' in output."""
        mgr = _make_mgr()
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "submit-planner", "--run-id", "run-001"])

        assert result.exit_code == 0, result.output
        assert "accepted" in result.output

    def test_submit_planner_error(self) -> None:
        """cycle submit-planner when mgr.submit_planner raises ValueError → exit 1."""
        mgr = _make_mgr()
        mgr.submit_planner.side_effect = ValueError("inbox missing")
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "submit-planner", "--run-id", "run-001"])

        assert result.exit_code == 1


# ---------------------------------------------------------------------------
# cycle approve / deny
# ---------------------------------------------------------------------------


class TestCycleApproval:
    def test_approve_ok(self) -> None:
        """cycle approve with correct token → exit 0, success message."""
        mgr = _make_mgr()
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with (
            ctx,
            patch("owlmind.approval.resolve_approval", return_value=(True, "Approved!")),
        ):
            result = runner.invoke(
                app,
                ["cycle", "approve", "--run-id", "run-001", "--token", "tok-abc"],
            )

        assert result.exit_code == 0, result.output
        assert "Approved" in result.output

    def test_approve_fail(self) -> None:
        """cycle approve with wrong token → exit 1, error message."""
        mgr = _make_mgr()
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with (
            ctx,
            patch("owlmind.approval.resolve_approval", return_value=(False, "Bad token")),
        ):
            result = runner.invoke(
                app,
                ["cycle", "approve", "--run-id", "run-001", "--token", "wrong"],
            )

        assert result.exit_code == 1
        assert "Bad token" in result.output


# ---------------------------------------------------------------------------
# cycle verify-chain
# ---------------------------------------------------------------------------


class TestCycleVerifyChain:
    def test_verify_chain_ok(self) -> None:
        """cycle verify-chain → chain ok → exit 0, 'Chain integrity: OK'."""
        chain_result = MagicMock()
        chain_result.ok = True
        chain_result.errors = []
        chain_result.tip_hash = "abcdef1234567890" * 4
        chain_result.seq = 7

        with patch("owlmind.cli.cycle.EvidenceStore") as MockEv:
            MockEv.return_value.verify_chain.return_value = chain_result
            result = runner.invoke(app, ["cycle", "verify-chain", "--run-id", "run-001"])

        assert result.exit_code == 0, result.output
        assert "OK" in result.output

    def test_verify_chain_fail(self) -> None:
        """cycle verify-chain → chain failed → exit 1."""
        chain_result = MagicMock()
        chain_result.ok = False
        chain_result.errors = ["hash mismatch at seq 3"]
        chain_result.tip_hash = "deadbeef" * 8
        chain_result.seq = 3

        with patch("owlmind.cli.cycle.EvidenceStore") as MockEv:
            MockEv.return_value.verify_chain.return_value = chain_result
            result = runner.invoke(app, ["cycle", "verify-chain", "--run-id", "run-001"])

        assert result.exit_code == 1
        assert "FAILED" in result.output


# ---------------------------------------------------------------------------
# cycle submit-worker
# ---------------------------------------------------------------------------


class TestCycleSubmitWorker:
    def test_submit_worker_ok_wait_judge(self) -> None:
        """cycle submit-worker → state WAIT_JUDGE → exit 0, green state printed."""
        from owlmind.agent.schemas import CycleState

        mgr = _make_mgr()
        meta = _make_cycle_meta()
        meta.state = CycleState.WAIT_JUDGE
        meta.hard_fail_reasons = []
        mgr.submit_worker.return_value = meta
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "submit-worker", "--run-id", "run-001"])

        assert result.exit_code == 0, result.output
        assert "Worker processed" in result.output

    def test_submit_worker_hard_fail(self) -> None:
        """cycle submit-worker → hard_fail_reasons set → prints them."""
        from owlmind.agent.schemas import CycleState

        mgr = _make_mgr()
        meta = _make_cycle_meta()
        meta.state = CycleState.FAILED
        meta.hard_fail_reasons = ["verify command exited 1", "test suite failed"]
        mgr.submit_worker.return_value = meta
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "submit-worker", "--run-id", "run-001"])

        assert result.exit_code == 0, result.output
        assert "verify command exited 1" in result.output
        assert "test suite failed" in result.output

    def test_submit_worker_error(self) -> None:
        """cycle submit-worker when mgr.submit_worker raises → exit 1."""
        mgr = _make_mgr()
        mgr.submit_worker.side_effect = RuntimeError("inbox missing")
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "submit-worker", "--run-id", "run-001"])

        assert result.exit_code == 1
        assert "inbox missing" in result.output


# ---------------------------------------------------------------------------
# cycle submit-judge
# ---------------------------------------------------------------------------


class TestCycleSubmitJudge:
    def test_submit_judge_done(self) -> None:
        """cycle submit-judge → state DONE → exit 0, green verdict printed."""
        from owlmind.agent.schemas import CycleState

        mgr = _make_mgr()
        meta = _make_cycle_meta()
        meta.state = CycleState.DONE
        mgr.submit_judge.return_value = meta
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "submit-judge", "--run-id", "run-001"])

        assert result.exit_code == 0, result.output
        assert "Judge verdict processed" in result.output

    def test_submit_judge_failed(self) -> None:
        """cycle submit-judge → state FAILED → exit 0, red state color."""
        from owlmind.agent.schemas import CycleState

        mgr = _make_mgr()
        meta = _make_cycle_meta()
        meta.state = CycleState.FAILED
        mgr.submit_judge.return_value = meta
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "submit-judge", "--run-id", "run-001"])

        assert result.exit_code == 0, result.output
        assert "Judge verdict processed" in result.output

    def test_submit_judge_error(self) -> None:
        """cycle submit-judge when mgr.submit_judge raises → exit 1."""
        mgr = _make_mgr()
        mgr.submit_judge.side_effect = ValueError("wrong state")
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "submit-judge", "--run-id", "run-001"])

        assert result.exit_code == 1
        assert "wrong state" in result.output


# ---------------------------------------------------------------------------
# cycle plan
# ---------------------------------------------------------------------------


class TestCyclePlan:
    def test_plan_ok(self) -> None:
        """cycle plan → exit 0, 'Planner response generated by LLM' in output."""
        mgr = _make_mgr()
        meta = _make_cycle_meta()
        meta.state.value = "WAIT_WORKER"
        mgr.run_planner_llm.return_value = meta
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "plan", "--run-id", "run-001"])

        assert result.exit_code == 0, result.output
        assert "Planner response generated by LLM" in result.output

    def test_plan_error(self) -> None:
        """cycle plan when mgr.run_planner_llm raises → exit 1."""
        mgr = _make_mgr()
        mgr.run_planner_llm.side_effect = RuntimeError("LLM unavailable")
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "plan", "--run-id", "run-001"])

        assert result.exit_code == 1
        assert "LLM unavailable" in result.output


# ---------------------------------------------------------------------------
# cycle judge
# ---------------------------------------------------------------------------


class TestCycleJudge:
    def test_judge_ok(self) -> None:
        """cycle judge → exit 0, 'Judge response generated by LLM' in output."""
        mgr = _make_mgr()
        meta = _make_cycle_meta()
        meta.state.value = "WAIT_JUDGE"
        mgr.run_judge_llm.return_value = meta
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "judge", "--run-id", "run-001"])

        assert result.exit_code == 0, result.output
        assert "Judge response generated by LLM" in result.output

    def test_judge_error(self) -> None:
        """cycle judge when mgr.run_judge_llm raises → exit 1."""
        mgr = _make_mgr()
        mgr.run_judge_llm.side_effect = RuntimeError("no judge inbox")
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "judge", "--run-id", "run-001"])

        assert result.exit_code == 1
        assert "no judge inbox" in result.output


# ---------------------------------------------------------------------------
# cycle work
# ---------------------------------------------------------------------------


class TestCycleWork:
    def test_work_ok(self) -> None:
        """cycle work → exit 0, state printed."""
        from owlmind.agent.schemas import CycleState

        mgr = _make_mgr()
        meta = _make_cycle_meta()
        meta.state = CycleState.WAIT_WORKER
        mgr.run_worker_cli.return_value = (meta, "Worker done.")
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "work", "--run-id", "run-001"])

        assert result.exit_code == 0, result.output
        assert "WAIT_WORKER" in result.output

    def test_work_wait_approval(self) -> None:
        """cycle work → state WAIT_APPROVAL → exit 0, state shown."""
        from owlmind.agent.schemas import CycleState

        mgr = _make_mgr()
        meta = _make_cycle_meta()
        meta.state = CycleState.WAIT_APPROVAL
        mgr.run_worker_cli.return_value = (meta, "Approval required.")
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "work", "--run-id", "run-001"])

        assert result.exit_code == 0, result.output
        assert "WAIT_APPROVAL" in result.output

    def test_work_error(self) -> None:
        """cycle work when mgr.run_worker_cli raises → exit 1."""
        mgr = _make_mgr()
        mgr.run_worker_cli.side_effect = RuntimeError("worker failed")
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "work", "--run-id", "run-001"])

        assert result.exit_code == 1
        assert "worker failed" in result.output


# ---------------------------------------------------------------------------
# cycle auto
# ---------------------------------------------------------------------------


class TestCycleAuto:
    def test_auto_reaches_done(self) -> None:
        """cycle auto → mgr.next returns DONE → exits after printing terminal state."""
        from owlmind.agent.schemas import CycleState

        mgr = _make_mgr()
        meta_done = _make_cycle_meta()
        meta_done.state = CycleState.DONE
        meta_done.hard_fail_reasons = []
        mgr.next.return_value = (meta_done, "Cycle complete!")
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(
                app,
                ["cycle", "auto", "--run-id", "run-001", "--interval", "0"],
            )

        assert result.exit_code == 0, result.output
        assert "DONE" in result.output

    def test_auto_reaches_failed(self) -> None:
        """cycle auto → mgr.next returns FAILED → exits after printing failure."""
        from owlmind.agent.schemas import CycleState

        mgr = _make_mgr()
        meta_fail = _make_cycle_meta()
        meta_fail.state = CycleState.FAILED
        meta_fail.hard_fail_reasons = []
        mgr.next.return_value = (meta_fail, "Cycle failed!")
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(
                app,
                ["cycle", "auto", "--run-id", "run-001", "--interval", "0"],
            )

        assert result.exit_code == 0, result.output
        assert "FAILED" in result.output

    def test_auto_max_steps(self) -> None:
        """cycle auto → max_steps=1 → stops after 1 step and prints max steps msg."""
        from owlmind.agent.schemas import CycleState

        mgr = _make_mgr()
        meta_wait = _make_cycle_meta()
        meta_wait.state = CycleState.WAIT_WORKER
        meta_wait.hard_fail_reasons = []
        mgr.next.return_value = (meta_wait, "Waiting for worker inbox.")
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(
                app,
                [
                    "cycle",
                    "auto",
                    "--run-id",
                    "run-001",
                    "--max-steps",
                    "1",
                    "--interval",
                    "0",
                ],
            )

        assert result.exit_code == 0, result.output
        assert "Max steps" in result.output

    def test_auto_wait_approval_breaks(self) -> None:
        """cycle auto → WAIT_APPROVAL state → stops and prints blocked message."""
        from owlmind.agent.schemas import CycleState

        mgr = _make_mgr()
        meta_approval = _make_cycle_meta()
        meta_approval.state = CycleState.WAIT_APPROVAL
        meta_approval.hard_fail_reasons = []
        mgr.next.return_value = (meta_approval, "Approval required. Use approve cmd.")
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(
                app,
                ["cycle", "auto", "--run-id", "run-001", "--interval", "0"],
            )

        assert result.exit_code == 0, result.output
        assert "Approval required" in result.output

    def test_auto_next_error_breaks(self) -> None:
        """cycle auto → mgr.next raises RuntimeError → breaks loop."""
        mgr = _make_mgr()
        mgr.next.side_effect = RuntimeError("run not found")
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(
                app,
                ["cycle", "auto", "--run-id", "run-missing", "--interval", "0"],
            )

        assert result.exit_code == 0, result.output
        assert "run not found" in result.output


# ---------------------------------------------------------------------------
# cycle deny
# ---------------------------------------------------------------------------


class TestCycleDeny:
    def test_deny_ok(self) -> None:
        """cycle deny with valid token → exit 0, success message."""
        mgr = _make_mgr()
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with (
            ctx,
            patch("owlmind.approval.resolve_approval", return_value=(True, "Denied!")),
        ):
            result = runner.invoke(
                app,
                ["cycle", "deny", "--run-id", "run-001", "--token", "tok-abc"],
            )

        assert result.exit_code == 0, result.output
        assert "Denied" in result.output

    def test_deny_fail(self) -> None:
        """cycle deny with invalid token → exit 1, error message."""
        mgr = _make_mgr()
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with (
            ctx,
            patch("owlmind.approval.resolve_approval", return_value=(False, "Invalid token")),
        ):
            result = runner.invoke(
                app,
                ["cycle", "deny", "--run-id", "run-001", "--token", "bad-tok"],
            )

        assert result.exit_code == 1
        assert "Invalid token" in result.output


# ---------------------------------------------------------------------------
# cycle approve-required
# ---------------------------------------------------------------------------


class TestCycleApproveRequired:
    def test_approve_required_ok(self) -> None:
        """cycle approve-required → exit 0, token and approve/deny commands shown."""
        mgr = _make_mgr()
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        approval = MagicMock()
        approval.token = "tok-xyz"
        approval.reason = "Manual test"
        approval.expires_at = 1000000.0 + 3600
        approval.created_at = 1000000.0

        with (
            ctx,
            patch("owlmind.approval.create_approval", return_value=approval),
        ):
            result = runner.invoke(
                app,
                [
                    "cycle",
                    "approve-required",
                    "--run-id",
                    "run-001",
                    "--reason",
                    "Manual test",
                ],
            )

        assert result.exit_code == 0, result.output
        assert "tok-xyz" in result.output
        assert "Approval required" in result.output


# ---------------------------------------------------------------------------
# cycle ingest
# ---------------------------------------------------------------------------


class TestCycleIngest:
    def test_ingest_ok(self) -> None:
        """cycle ingest → file exists, mgr.ingest returns meta → exit 0."""
        from owlmind.agent.schemas import CycleState

        mgr = _make_mgr()
        meta = _make_cycle_meta()
        meta.state = CycleState.WAIT_WORKER
        target = MagicMock()
        target.__str__ = lambda self: "/tmp/runs/run-001/worker_inbox.json"
        mgr.ingest.return_value = (meta, target)
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with (
            ctx,
            patch("pathlib.Path.exists", return_value=True),
        ):
            result = runner.invoke(
                app,
                [
                    "cycle",
                    "ingest",
                    "--run-id",
                    "run-001",
                    "--file",
                    "/tmp/response.json",
                ],
            )

        assert result.exit_code == 0, result.output
        assert "ingested successfully" in result.output

    def test_ingest_file_not_found(self) -> None:
        """cycle ingest → file does not exist → exit 1."""
        mgr = _make_mgr()
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with (
            ctx,
            patch("pathlib.Path.exists", return_value=False),
        ):
            result = runner.invoke(
                app,
                [
                    "cycle",
                    "ingest",
                    "--run-id",
                    "run-001",
                    "--file",
                    "/tmp/missing.json",
                ],
            )

        assert result.exit_code == 1
        assert "File not found" in result.output

    def test_ingest_error(self) -> None:
        """cycle ingest → mgr.ingest raises → exit 1."""
        mgr = _make_mgr()
        mgr.ingest.side_effect = ValueError("wrong state for ingest")
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with (
            ctx,
            patch("pathlib.Path.exists", return_value=True),
        ):
            result = runner.invoke(
                app,
                [
                    "cycle",
                    "ingest",
                    "--run-id",
                    "run-001",
                    "--file",
                    "/tmp/response.json",
                ],
            )

        assert result.exit_code == 1
        assert "wrong state for ingest" in result.output


# ---------------------------------------------------------------------------
# cycle pack
# ---------------------------------------------------------------------------


class TestCyclePack:
    def test_pack_ok_short_content(self) -> None:
        """cycle pack → mgr.generate_pr_pack returns short content → exit 0."""
        mgr = _make_mgr()
        mgr.generate_pr_pack.return_value = "# PR Pack\n\nShort content."
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "pack", "--run-id", "run-001"])

        assert result.exit_code == 0, result.output
        assert "PR pack written to" in result.output

    def test_pack_ok_long_content(self) -> None:
        """cycle pack → mgr.generate_pr_pack returns >500 chars → truncated with '...'."""
        mgr = _make_mgr()
        mgr.generate_pr_pack.return_value = "x" * 600
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "pack", "--run-id", "run-001"])

        assert result.exit_code == 0, result.output
        assert "..." in result.output

    def test_pack_error(self) -> None:
        """cycle pack when mgr.generate_pr_pack raises → exit 1."""
        mgr = _make_mgr()
        mgr.generate_pr_pack.side_effect = FileNotFoundError("run not found")
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "pack", "--run-id", "run-001"])

        assert result.exit_code == 1
        assert "run not found" in result.output


# ---------------------------------------------------------------------------
# cycle export
# ---------------------------------------------------------------------------


class TestCycleExport:
    def test_export_ok(self) -> None:
        """cycle export → mgr.export returns zip path → exit 0, size printed."""
        mgr = _make_mgr()
        zip_path = MagicMock()
        zip_path.__str__ = lambda self: "/tmp/run-001.zip"
        zip_path.stat.return_value.st_size = 4096
        mgr.export.return_value = zip_path
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "export", "--run-id", "run-001"])

        assert result.exit_code == 0, result.output
        assert "Export created" in result.output
        assert "4096" in result.output

    def test_export_error(self) -> None:
        """cycle export when mgr.export raises → exit 1."""
        mgr = _make_mgr()
        mgr.export.side_effect = FileNotFoundError("run not found")
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "export", "--run-id", "run-001"])

        assert result.exit_code == 1
        assert "run not found" in result.output


# ---------------------------------------------------------------------------
# cycle detect-profile
# ---------------------------------------------------------------------------


class TestCycleDetectProfile:
    def test_detect_profile_python(self) -> None:
        """cycle detect-profile → python project detected → prints profile kind."""
        from owlmind.agent.profile import RepoProfile

        profile = RepoProfile(
            kind="python",
            markers=["pyproject.toml"],
            suggested_verify_commands=["python -m pytest"],
        )

        with patch("owlmind.agent.profile.detect_profile", return_value=profile):
            result = runner.invoke(app, ["cycle", "detect-profile"])

        assert result.exit_code == 0, result.output
        assert "python" in result.output
        assert "pyproject.toml" in result.output
        assert "python -m pytest" in result.output

    def test_detect_profile_unknown_no_commands(self) -> None:
        """cycle detect-profile → unknown profile → 'No verify commands suggested'."""
        from owlmind.agent.profile import RepoProfile

        profile = RepoProfile(
            kind="unknown",
            markers=[],
            suggested_verify_commands=[],
        )

        with patch("owlmind.agent.profile.detect_profile", return_value=profile):
            result = runner.invoke(app, ["cycle", "detect-profile"])

        assert result.exit_code == 0, result.output
        assert "unknown" in result.output
        assert "No verify commands suggested" in result.output


# ---------------------------------------------------------------------------
# cycle sandbox
# ---------------------------------------------------------------------------


class TestCycleSandbox:
    def test_sandbox_status_enabled(self) -> None:
        """cycle sandbox status → sandbox enabled → prints worktree info."""
        mgr = _make_mgr()
        info = MagicMock()
        info.enabled = True
        info.kind = "worktree"
        info.worktree_path = "/tmp/worktrees/run-001"
        info.branch_name = "owlmind/run-001"
        mgr.sandbox_status.return_value = info
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "sandbox", "--run-id", "run-001", "status"])

        assert result.exit_code == 0, result.output
        assert "worktree" in result.output
        assert "owlmind/run-001" in result.output

    def test_sandbox_status_disabled(self) -> None:
        """cycle sandbox status → no sandbox → 'No sandbox found'."""
        mgr = _make_mgr()
        info = MagicMock()
        info.enabled = False
        mgr.sandbox_status.return_value = info
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "sandbox", "--run-id", "run-001", "status"])

        assert result.exit_code == 0, result.output
        assert "No sandbox found" in result.output

    def test_sandbox_cleanup_requires_yes(self) -> None:
        """cycle sandbox cleanup without --yes → exit 1, confirmation message."""
        mgr = _make_mgr()
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "sandbox", "--run-id", "run-001", "cleanup"])

        assert result.exit_code == 1
        assert "Cleanup requires --yes" in result.output

    def test_sandbox_cleanup_ok(self) -> None:
        """cycle sandbox cleanup --yes → mgr.sandbox_cleanup returns ok → exit 0."""
        mgr = _make_mgr()
        meta = _make_cycle_meta()
        meta.workspace = "/tmp/project"
        meta.extra = {"sandbox": {"base_repo_path": "/tmp/project"}}
        mgr.status.return_value = meta
        mgr.sandbox_cleanup.return_value = (True, "Sandbox cleaned up.")
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(
                app,
                ["cycle", "sandbox", "--run-id", "run-001", "--yes", "cleanup"],
            )

        assert result.exit_code == 0, result.output
        assert "Sandbox cleaned up" in result.output

    def test_sandbox_unknown_action(self) -> None:
        """cycle sandbox unknown-action → exit 1, 'Unknown action' message."""
        mgr = _make_mgr()
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "sandbox", "--run-id", "run-001", "nuke"])

        assert result.exit_code == 1
        assert "Unknown action" in result.output


# ---------------------------------------------------------------------------
# cycle sandbox cleanup — failure path (lines 673-674)
# ---------------------------------------------------------------------------


class TestCycleSandboxCleanupFail:
    def test_sandbox_cleanup_fail_exits_1(self) -> None:
        """cycle sandbox cleanup --yes → mgr.sandbox_cleanup returns ok=False → exit 1."""
        mgr = _make_mgr()
        meta = _make_cycle_meta()
        meta.workspace = "/tmp/project"
        meta.extra = {"sandbox": {}}
        mgr.status.return_value = meta
        mgr.sandbox_cleanup.return_value = (False, "No worktree found to clean.")
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(
                app,
                ["cycle", "sandbox", "--run-id", "run-001", "--yes", "cleanup"],
            )

        assert result.exit_code == 1
        assert "No worktree found to clean" in result.output


# ---------------------------------------------------------------------------
# cycle start — refined goal, profile info, skill_pack (lines 74, 81-82, 92-96)
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# cycle start — skill_pack printed (line 74)
# ---------------------------------------------------------------------------


class TestCycleStartSkillPack:
    def test_start_with_skill_pack_printed(self) -> None:
        """cycle start --skill-pack sk1 → 'Skills' line with skill id printed."""
        mgr = _make_mgr()
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(
                app,
                ["cycle", "start", "--goal", "Fix bug", "--skill-pack", "sk1"],
            )

        assert result.exit_code == 0, result.output
        assert "Skills" in result.output
        assert "sk1" in result.output

    def test_start_without_skill_pack_no_skills_line(self) -> None:
        """cycle start without --skill-pack → no 'Skills' line in output."""
        mgr = _make_mgr()
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "start", "--goal", "Fix bug"])

        assert result.exit_code == 0, result.output
        assert "Skills" not in result.output


# ---------------------------------------------------------------------------
# cycle start — refined goal (lines 81-82), profile info (lines 92-96)
# ---------------------------------------------------------------------------


class TestCycleStartExtras:
    def test_start_refined_goal_changed(self) -> None:
        """cycle start with refined_goal.changed=True → 'Refined' and 'Risk' printed."""
        extra = {
            "refined_goal": {
                "changed": True,
                "refined": "Improved goal text that was refined by LLM analysis",
                "risk_level": "low",
            },
        }
        meta = _make_cycle_meta(extra=extra)
        mgr = _make_mgr(meta)
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "start", "--goal", "Fix bug"])

        assert result.exit_code == 0, result.output
        assert "Refined" in result.output
        assert "Risk" in result.output
        assert "low" in result.output

    def test_start_refined_goal_not_changed(self) -> None:
        """cycle start with refined_goal.changed=False → no 'Refined' line printed."""
        extra = {
            "refined_goal": {
                "changed": False,
                "refined": "Same goal text",
                "risk_level": "low",
            },
        }
        meta = _make_cycle_meta(extra=extra)
        mgr = _make_mgr(meta)
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "start", "--goal", "Fix bug"])

        assert result.exit_code == 0, result.output
        assert "Refined" not in result.output

    def test_start_profile_info_known_with_verify(self) -> None:
        """cycle start with profile.kind != 'unknown' → 'Profile' and 'Suggested' printed."""
        extra = {
            "profile": {
                "kind": "python",
                "markers": ["pyproject.toml", "pytest.ini"],
                "suggested_verify": "python -m pytest",
            },
        }
        meta = _make_cycle_meta(extra=extra)
        mgr = _make_mgr(meta)
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "start", "--goal", "Fix bug"])

        assert result.exit_code == 0, result.output
        assert "Profile" in result.output
        assert "python" in result.output
        assert "pyproject.toml" in result.output
        assert "python -m pytest" in result.output

    def test_start_profile_info_known_no_suggested_verify(self) -> None:
        """cycle start with known profile but no suggested_verify → no 'Suggested' line."""
        extra = {
            "profile": {
                "kind": "node",
                "markers": ["package.json"],
                "suggested_verify": "",
            },
        }
        meta = _make_cycle_meta(extra=extra)
        mgr = _make_mgr(meta)
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "start", "--goal", "Fix bug"])

        assert result.exit_code == 0, result.output
        assert "Profile" in result.output
        assert "node" in result.output
        assert "Suggested" not in result.output


# ---------------------------------------------------------------------------
# cycle status — sandbox in status output (line 206)
# ---------------------------------------------------------------------------


class TestCycleStatusSandbox:
    def test_status_sandbox_enabled(self) -> None:
        """cycle status with sandbox.enabled=True → 'Sandbox' line printed."""
        extra = {"sandbox": {"enabled": True, "kind": "worktree"}}
        meta = _make_cycle_meta(extra=extra)
        mgr = _make_mgr(meta)
        evidence, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr, read_events_count=2)

        with ctx:
            result = runner.invoke(app, ["cycle", "status", "--run-id", "run-001"])

        assert result.exit_code == 0, result.output
        assert "Sandbox" in result.output
        assert "worktree" in result.output


# ---------------------------------------------------------------------------
# cycle next — FAILED and DONE state colors (lines 233, 235)
# ---------------------------------------------------------------------------


class TestCycleNextStateColors:
    def test_next_state_failed_red(self) -> None:
        """cycle next → FAILED state → output contains 'FAILED'."""
        from owlmind.agent.schemas import CycleState

        meta = _make_cycle_meta()
        meta.state = CycleState.FAILED
        mgr = _make_mgr(meta)
        mgr.next.return_value = (meta, "Cycle failed hard.")
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "next", "--run-id", "run-001"])

        assert result.exit_code == 0, result.output
        assert "FAILED" in result.output

    def test_next_state_done_bold_green(self) -> None:
        """cycle next → DONE state → output contains 'DONE'."""
        from owlmind.agent.schemas import CycleState

        meta = _make_cycle_meta()
        meta.state = CycleState.DONE
        mgr = _make_mgr(meta)
        mgr.next.return_value = (meta, "All goals completed successfully.")
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(app, ["cycle", "next", "--run-id", "run-001"])

        assert result.exit_code == 0, result.output
        assert "DONE" in result.output


# ---------------------------------------------------------------------------
# cycle auto — LLM planner/judge/worker_auto paths (lines 399-426, 432-433, 436-437)
# ---------------------------------------------------------------------------


class TestCycleAutoLLMPaths:
    def test_auto_llm_planner_succeeds(self) -> None:
        """cycle auto --use-llm planner → LLM called when waiting for planner response."""
        from owlmind.agent.schemas import CycleState

        mgr = _make_mgr()
        meta_wait = _make_cycle_meta()
        meta_wait.state = CycleState.STARTED_WAIT_PLANNER
        meta_wait.hard_fail_reasons = []

        meta_done = _make_cycle_meta()
        meta_done.state = CycleState.DONE
        meta_done.hard_fail_reasons = []

        mgr.next.side_effect = [
            (meta_wait, "Waiting for planner response"),
            (meta_done, "Done!"),
        ]
        mgr.run_planner_llm.return_value = meta_wait
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx, patch("time.sleep"):
            result = runner.invoke(
                app,
                [
                    "cycle",
                    "auto",
                    "--run-id",
                    "run-001",
                    "--use-llm",
                    "planner",
                    "--interval",
                    "0",
                ],
            )

        assert result.exit_code == 0, result.output
        assert "Planner response generated" in result.output

    def test_auto_llm_planner_error(self) -> None:
        """cycle auto --use-llm planner → LLM raises → error printed, blocked."""
        from owlmind.agent.schemas import CycleState

        mgr = _make_mgr()
        meta_wait = _make_cycle_meta()
        meta_wait.state = CycleState.STARTED_WAIT_PLANNER
        meta_wait.hard_fail_reasons = []

        mgr.next.return_value = (meta_wait, "Waiting for planner response")
        mgr.run_planner_llm.side_effect = RuntimeError("LLM timeout")
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(
                app,
                [
                    "cycle",
                    "auto",
                    "--run-id",
                    "run-001",
                    "--use-llm",
                    "planner",
                    "--interval",
                    "0",
                ],
            )

        assert result.exit_code == 0, result.output
        assert "LLM planner error" in result.output

    def test_auto_llm_judge_succeeds(self) -> None:
        """cycle auto --use-llm judge → judge LLM called when waiting for judge response."""
        from owlmind.agent.schemas import CycleState

        mgr = _make_mgr()
        meta_wait = _make_cycle_meta()
        meta_wait.state = CycleState.WAIT_JUDGE
        meta_wait.hard_fail_reasons = []

        meta_done = _make_cycle_meta()
        meta_done.state = CycleState.DONE
        meta_done.hard_fail_reasons = []

        mgr.next.side_effect = [
            (meta_wait, "Waiting for judge response"),
            (meta_done, "Done!"),
        ]
        mgr.run_judge_llm.return_value = meta_wait
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx, patch("time.sleep"):
            result = runner.invoke(
                app,
                [
                    "cycle",
                    "auto",
                    "--run-id",
                    "run-001",
                    "--use-llm",
                    "judge",
                    "--interval",
                    "0",
                ],
            )

        assert result.exit_code == 0, result.output
        assert "Judge response generated" in result.output

    def test_auto_llm_judge_error(self) -> None:
        """cycle auto --use-llm judge → LLM raises → error printed, blocked."""
        from owlmind.agent.schemas import CycleState

        mgr = _make_mgr()
        meta_wait = _make_cycle_meta()
        meta_wait.state = CycleState.WAIT_JUDGE
        meta_wait.hard_fail_reasons = []

        mgr.next.return_value = (meta_wait, "Waiting for judge response")
        mgr.run_judge_llm.side_effect = RuntimeError("Judge timeout")
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(
                app,
                [
                    "cycle",
                    "auto",
                    "--run-id",
                    "run-001",
                    "--use-llm",
                    "judge",
                    "--interval",
                    "0",
                ],
            )

        assert result.exit_code == 0, result.output
        assert "LLM judge error" in result.output

    def test_auto_worker_cli_succeeds(self) -> None:
        """cycle auto --use-worker claude_cli → worker runs and advances cycle."""
        from owlmind.agent.schemas import CycleState

        mgr = _make_mgr()
        meta_wait = _make_cycle_meta()
        meta_wait.state = CycleState.WAIT_WORKER
        meta_wait.hard_fail_reasons = []

        meta_done = _make_cycle_meta()
        meta_done.state = CycleState.DONE
        meta_done.hard_fail_reasons = []

        w_meta = _make_cycle_meta()
        w_meta.state = CycleState.WAIT_JUDGE

        mgr.next.side_effect = [
            (meta_wait, "Waiting for worker"),
            (meta_done, "Done!"),
        ]
        mgr.run_worker_cli.return_value = (w_meta, "Worker completed successfully.")
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx, patch("time.sleep"):
            result = runner.invoke(
                app,
                [
                    "cycle",
                    "auto",
                    "--run-id",
                    "run-001",
                    "--use-worker",
                    "claude_cli",
                    "--interval",
                    "0",
                ],
            )

        assert result.exit_code == 0, result.output
        assert "Worker completed successfully" in result.output

    def test_auto_worker_cli_wait_approval_breaks(self) -> None:
        """cycle auto --use-worker → worker returns WAIT_APPROVAL → loop breaks."""
        from owlmind.agent.schemas import CycleState

        mgr = _make_mgr()
        meta_wait = _make_cycle_meta()
        meta_wait.state = CycleState.WAIT_WORKER
        meta_wait.hard_fail_reasons = []

        w_meta = _make_cycle_meta()
        w_meta.state = CycleState.WAIT_APPROVAL

        mgr.next.return_value = (meta_wait, "Waiting for worker")
        mgr.run_worker_cli.return_value = (w_meta, "Approval required for this action.")
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(
                app,
                [
                    "cycle",
                    "auto",
                    "--run-id",
                    "run-001",
                    "--use-worker",
                    "claude_cli",
                    "--interval",
                    "0",
                ],
            )

        assert result.exit_code == 0, result.output
        assert "Approval required" in result.output

    def test_auto_worker_cli_error(self) -> None:
        """cycle auto --use-worker → worker raises → error printed, blocked."""
        from owlmind.agent.schemas import CycleState

        mgr = _make_mgr()
        meta_wait = _make_cycle_meta()
        meta_wait.state = CycleState.WAIT_WORKER
        meta_wait.hard_fail_reasons = []

        mgr.next.return_value = (meta_wait, "Waiting for worker")
        mgr.run_worker_cli.side_effect = RuntimeError("Worker crashed")
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(
                app,
                [
                    "cycle",
                    "auto",
                    "--run-id",
                    "run-001",
                    "--use-worker",
                    "claude_cli",
                    "--interval",
                    "0",
                ],
            )

        assert result.exit_code == 0, result.output
        assert "Worker error" in result.output

    def test_auto_hard_fail_reasons_breaks(self) -> None:
        """cycle auto → hard_fail_reasons set → 'Hard fail' printed and loop breaks."""
        from owlmind.agent.schemas import CycleState

        mgr = _make_mgr()
        meta_fail = _make_cycle_meta()
        meta_fail.state = CycleState.WAIT_WORKER
        meta_fail.hard_fail_reasons = ["Test suite failed", "Lint errors found"]

        mgr.next.return_value = (meta_fail, "Processing, please wait...")
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx:
            result = runner.invoke(
                app,
                ["cycle", "auto", "--run-id", "run-001", "--interval", "0"],
            )

        assert result.exit_code == 0, result.output
        assert "Hard fail" in result.output


# ---------------------------------------------------------------------------
# cycle auto — max_steps reached (lines 371-372), time.sleep (line 439)
# ---------------------------------------------------------------------------


class TestCycleAutoRemainingPaths:
    def test_auto_max_steps_reached_on_second_step(self) -> None:
        """cycle auto --max-steps 1 → after first step exceeds max → 'Max steps' printed."""
        from owlmind.agent.schemas import CycleState

        mgr = _make_mgr()
        # Return a state that advances (not terminal/blocking/waiting+Waiting)
        # so the loop completes one full iteration and hits time.sleep,
        # then on step 2 (> max_steps=1) triggers the max_steps break.
        meta_running = _make_cycle_meta()
        meta_running.state = CycleState.WAIT_WORKER
        meta_running.hard_fail_reasons = []

        # message does NOT contain "Waiting" — falls through to time.sleep path
        mgr.next.return_value = (meta_running, "Processing, please wait...")
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx, patch("time.sleep"):
            result = runner.invoke(
                app,
                [
                    "cycle",
                    "auto",
                    "--run-id",
                    "run-001",
                    "--max-steps",
                    "1",
                    "--interval",
                    "0",
                ],
            )

        assert result.exit_code == 0, result.output
        assert "Max steps" in result.output

    def test_auto_time_sleep_called_for_non_waiting_state(self) -> None:
        """cycle auto with non-waiting, non-terminal state → time.sleep called once."""
        from owlmind.agent.schemas import CycleState

        mgr = _make_mgr()
        meta_running = _make_cycle_meta()
        meta_running.state = CycleState.WAIT_WORKER
        meta_running.hard_fail_reasons = []

        meta_done = _make_cycle_meta()
        meta_done.state = CycleState.DONE
        meta_done.hard_fail_reasons = []

        # First call: non-waiting message → hits time.sleep; second: DONE → breaks
        mgr.next.side_effect = [
            (meta_running, "Processing, please wait..."),
            (meta_done, "Done!"),
        ]
        _, ctx = _mcm_patch("owlmind.cli.cycle.make_cycle_manager", mgr)

        with ctx, patch("time.sleep") as mock_sleep:
            result = runner.invoke(
                app,
                ["cycle", "auto", "--run-id", "run-001", "--interval", "1"],
            )

        assert result.exit_code == 0, result.output
        # time.sleep(1) should have been called once for the non-terminal step
        mock_sleep.assert_called_with(1)


# ---------------------------------------------------------------------------
# memory/retrieval — build_memory_context result entries appended (lines 165-166)
# ---------------------------------------------------------------------------


class TestBuildMemoryContextResultsAppended:
    """Tests that result entries ARE appended (lines 165-166 in retrieval.py)."""

    def test_results_appended_when_within_budget(self) -> None:
        """build_memory_context appends result entries that fit within max_chars."""
        import pathlib
        import tempfile

        from owlmind.memory.retrieval import build_memory_context
        from owlmind.memory.store import MemoryStore

        with tempfile.TemporaryDirectory() as d:
            store = MemoryStore(pathlib.Path(d) / "mem.db")
            # Use unique term so IDF > 0
            store.ingest("doc", "target.md", "uniqueword alpha coding patterns guide")
            store.ingest("doc", "noise.md", "zephyr quasar xenon unrelated filler content")
            ctx = build_memory_context(store, "uniqueword", max_chars=2000)
            store.close()

        assert "Relevant Memory" in ctx
        assert "target.md" in ctx
