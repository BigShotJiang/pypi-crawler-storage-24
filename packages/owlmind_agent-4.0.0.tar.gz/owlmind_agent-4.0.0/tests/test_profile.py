"""Tests for repo profile detection."""

from __future__ import annotations

import json
from pathlib import Path

from owlmind.agent.profile import detect_profile


class TestDetectProfile:
    def test_python_project(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text("[project]\nname = 'test'\n")
        (tmp_path / "requirements.txt").write_text("pytest\n")

        profile = detect_profile(tmp_path)
        assert profile.kind == "python"
        assert "pyproject.toml" in profile.markers
        assert "requirements.txt" in profile.markers
        assert "pytest -q" in profile.suggested_verify_commands
        assert "ruff check ." in profile.suggested_verify_commands
        assert "mypy ." in profile.suggested_verify_commands

    def test_node_project(self, tmp_path: Path) -> None:
        pkg = {"name": "test", "scripts": {"test": "jest", "lint": "eslint .", "build": "tsc"}}
        (tmp_path / "package.json").write_text(json.dumps(pkg))

        profile = detect_profile(tmp_path)
        assert profile.kind == "node"
        assert "package.json" in profile.markers
        assert "npm test" in profile.suggested_verify_commands
        assert "npm run lint" in profile.suggested_verify_commands
        assert "npm run build" in profile.suggested_verify_commands

    def test_node_project_no_scripts(self, tmp_path: Path) -> None:
        pkg = {"name": "test"}
        (tmp_path / "package.json").write_text(json.dumps(pkg))

        profile = detect_profile(tmp_path)
        assert profile.kind == "node"
        assert profile.suggested_verify_commands == []

    def test_mixed_project(self, tmp_path: Path) -> None:
        (tmp_path / "pyproject.toml").write_text("[project]\n")
        pkg = {"name": "test", "scripts": {"test": "jest"}}
        (tmp_path / "package.json").write_text(json.dumps(pkg))

        profile = detect_profile(tmp_path)
        assert profile.kind == "mixed"
        assert "pytest -q" in profile.suggested_verify_commands
        assert "npm test" in profile.suggested_verify_commands

    def test_unknown_project(self, tmp_path: Path) -> None:
        profile = detect_profile(tmp_path)
        assert profile.kind == "unknown"
        assert profile.markers == []
        assert profile.suggested_verify_commands == []

    def test_node_partial_scripts(self, tmp_path: Path) -> None:
        pkg = {"name": "test", "scripts": {"test": "jest"}}
        (tmp_path / "package.json").write_text(json.dumps(pkg))

        profile = detect_profile(tmp_path)
        assert "npm test" in profile.suggested_verify_commands
        assert "npm run lint" not in profile.suggested_verify_commands
        assert "npm run build" not in profile.suggested_verify_commands
