"""Tests for Qdrant-backed MemoryStorage with mocked qdrant-client."""

from __future__ import annotations

import sys
import types
from unittest.mock import MagicMock

import pytest

from owlmind.storage.interface import MemoryStorage

# ===================================================================
# Mock qdrant_client module (not installed in dev env)
# ===================================================================


class _PointStruct:
    """Fake PointStruct for testing."""

    def __init__(self, id: str, vector: list[float], payload: dict) -> None:
        self.id = id
        self.vector = vector
        self.payload = payload


class _VectorParams:
    def __init__(self, size: int, distance: str) -> None:
        self.size = size
        self.distance = distance


class _Distance:
    COSINE = "Cosine"


class _Filter:
    def __init__(self, must: list | None = None) -> None:
        self.must = must or []


class _FieldCondition:
    def __init__(self, key: str, match: object = None, range: object = None) -> None:
        self.key = key
        self.match = match
        self.range = range


class _MatchValue:
    def __init__(self, value: object) -> None:
        self.value = value


class _Range:
    def __init__(
        self,
        lt: float | None = None,
        gt: float | None = None,
        gte: float | None = None,
        lte: float | None = None,
    ) -> None:
        self.lt = lt
        self.gt = gt
        self.gte = gte
        self.lte = lte


class _FilterSelector:
    def __init__(self, filter: _Filter) -> None:
        self.filter = filter


# ===================================================================
# _FakeQdrantClient — in-memory Qdrant replacement
# ===================================================================


class _FakeScoredPoint:
    def __init__(self, id: str, score: float, payload: dict) -> None:
        self.id = id
        self.score = score
        self.payload = payload


class _FakePoint:
    def __init__(self, id: str, payload: dict) -> None:
        self.id = id
        self.payload = payload


class _FakeCollectionInfo:
    def __init__(self, name: str) -> None:
        self.name = name


class _FakeQdrantClient:
    """In-memory QdrantClient replacement for unit tests."""

    def __init__(self, **kwargs: object) -> None:
        self._collections: dict[str, dict[str, dict]] = {}

    def get_collections(self) -> MagicMock:
        result = MagicMock()
        result.collections = [_FakeCollectionInfo(n) for n in self._collections]
        return result

    def create_collection(self, collection_name: str, vectors_config: object = None) -> None:
        self._collections[collection_name] = {}

    def delete_collection(self, collection_name: str) -> None:
        self._collections.pop(collection_name, None)

    def upsert(self, collection_name: str, points: list) -> None:
        coll = self._collections[collection_name]
        for pt in points:
            coll[pt.id] = {"vector": pt.vector, "payload": dict(pt.payload)}

    def search(
        self,
        collection_name: str,
        query_vector: list[float],
        query_filter: _Filter | None = None,
        limit: int = 5,
        **kwargs: object,
    ) -> list[_FakeScoredPoint]:
        coll = self._collections.get(collection_name, {})
        scored = []
        for pid, data in coll.items():
            if query_filter and not self._matches(data["payload"], query_filter):
                continue
            score = self._cosine_sim(query_vector, data["vector"])
            scored.append(_FakeScoredPoint(id=pid, score=score, payload=data["payload"]))
        scored.sort(key=lambda x: x.score, reverse=True)
        return scored[:limit]

    def scroll(
        self,
        collection_name: str,
        scroll_filter: _Filter | None = None,
        limit: int = 100,
        **kwargs: object,
    ) -> tuple[list[_FakePoint], None]:
        coll = self._collections.get(collection_name, {})
        results = []
        for pid, data in coll.items():
            if scroll_filter and not self._matches(data["payload"], scroll_filter):
                continue
            results.append(_FakePoint(id=pid, payload=data["payload"]))
        return results[:limit], None

    def count(
        self,
        collection_name: str,
        count_filter: _Filter | None = None,
        **kwargs: object,
    ) -> MagicMock:
        coll = self._collections.get(collection_name, {})
        cnt = sum(
            1
            for d in coll.values()
            if not count_filter or self._matches(d["payload"], count_filter)
        )
        result = MagicMock()
        result.count = cnt
        return result

    def delete(self, collection_name: str, points_selector: _FilterSelector) -> None:
        coll = self._collections.get(collection_name, {})
        to_delete = [
            pid for pid, d in coll.items() if self._matches(d["payload"], points_selector.filter)
        ]
        for pid in to_delete:
            del coll[pid]

    def close(self) -> None:
        pass

    @staticmethod
    def _cosine_sim(a: list[float], b: list[float]) -> float:
        dot = sum(x * y for x, y in zip(a, b, strict=True))
        na = sum(x * x for x in a) ** 0.5
        nb = sum(x * x for x in b) ** 0.5
        return dot / (na * nb) if na and nb else 0.0

    @staticmethod
    def _matches(payload: dict, filter_obj: _Filter) -> bool:
        for cond in filter_obj.must or []:
            val = payload.get(cond.key)
            if cond.match is not None and val != cond.match.value:
                return False
            if cond.range is not None:
                if cond.range.lt is not None and not (val is not None and val < cond.range.lt):
                    return False
                if cond.range.gt is not None and not (val is not None and val > cond.range.gt):
                    return False
        return True


# ===================================================================
# Wire mock modules into sys.modules
# ===================================================================

_mock_qdrant = types.ModuleType("qdrant_client")
_mock_models = types.ModuleType("qdrant_client.models")

_mock_models.PointStruct = _PointStruct  # type: ignore[attr-defined]
_mock_models.Distance = _Distance  # type: ignore[attr-defined]
_mock_models.VectorParams = _VectorParams  # type: ignore[attr-defined]
_mock_models.Filter = _Filter  # type: ignore[attr-defined]
_mock_models.FieldCondition = _FieldCondition  # type: ignore[attr-defined]
_mock_models.MatchValue = _MatchValue  # type: ignore[attr-defined]
_mock_models.Range = _Range  # type: ignore[attr-defined]
_mock_models.FilterSelector = _FilterSelector  # type: ignore[attr-defined]

_mock_qdrant.QdrantClient = _FakeQdrantClient  # type: ignore[attr-defined]
_mock_qdrant.models = _mock_models  # type: ignore[attr-defined]

sys.modules.setdefault("qdrant_client", _mock_qdrant)
sys.modules.setdefault("qdrant_client.models", _mock_models)

from owlmind.storage.qdrant import QdrantMemoryStorage  # noqa: E402

# ===================================================================
# Test embedding function
# ===================================================================

_EMBED_DIM = 64


def _test_embed(texts: list[str]) -> list[list[float]]:
    """Character-frequency embedding: similar texts produce similar vectors."""
    results = []
    for text in texts:
        vec = [0.0] * _EMBED_DIM
        for ch in text.lower():
            vec[ord(ch) % _EMBED_DIM] += 1.0
        norm = sum(x * x for x in vec) ** 0.5
        if norm > 0:
            vec = [x / norm for x in vec]
        results.append(vec)
    return results


# ===================================================================
# Fixtures
# ===================================================================


@pytest.fixture
def qdrant_storage():
    return QdrantMemoryStorage(
        url="",
        collection="test_memory",
        vector_size=_EMBED_DIM,
        embed_fn=_test_embed,
    )


# ===================================================================
# TestQdrantProtocol
# ===================================================================


class TestQdrantProtocol:
    def test_satisfies_memory_storage_protocol(self, qdrant_storage):
        assert isinstance(qdrant_storage, MemoryStorage)

    def test_embedding_function_pluggable(self):
        custom_fn = lambda texts: [[0.0] * 32 for _ in texts]  # noqa: E731
        storage = QdrantMemoryStorage(collection="test", vector_size=32, embed_fn=custom_fn)
        assert storage._custom_embed_fn is custom_fn


# ===================================================================
# TestQdrantIngest
# ===================================================================


class TestQdrantIngest:
    @pytest.mark.asyncio
    async def test_ingest_returns_doc_id(self, qdrant_storage):
        doc_id = await qdrant_storage.ingest("doc", "test.txt", "Hello world")
        assert doc_id.startswith("doc-")
        assert len(doc_id) == 20  # "doc-" + 16 hex chars

    @pytest.mark.asyncio
    async def test_ingest_dedup_by_sha256(self, qdrant_storage):
        doc_id1 = await qdrant_storage.ingest("doc", "a.txt", "same content")
        doc_id2 = await qdrant_storage.ingest("doc", "b.txt", "same content")
        assert doc_id1 == doc_id2

        # Should only have one set of chunks
        chunks = await qdrant_storage.get_chunks(doc_id1)
        assert len(chunks) == 1

    @pytest.mark.asyncio
    async def test_ingest_chunks_long_content(self, qdrant_storage):
        long_text = "A" * 2000
        doc_id = await qdrant_storage.ingest("doc", "long.txt", long_text)

        chunks = await qdrant_storage.get_chunks(doc_id)
        assert len(chunks) > 1
        assert chunks[0].seq == 0
        assert chunks[1].seq == 1

    @pytest.mark.asyncio
    async def test_ingest_redacts_secrets(self, qdrant_storage):
        # Content with a pattern that looks like a secret
        content = "API key is sk-1234567890abcdef1234567890abcdef"
        doc_id = await qdrant_storage.ingest("doc", "secrets.txt", content)

        chunks = await qdrant_storage.get_chunks(doc_id)
        # redact_secrets should have sanitized the content
        assert len(chunks) > 0


# ===================================================================
# TestQdrantSignals
# ===================================================================


class TestQdrantSignals:
    @pytest.mark.asyncio
    async def test_add_signal_returns_id(self, qdrant_storage):
        signal_id = await qdrant_storage.add_signal("lesson", "Always test before deploy")
        assert isinstance(signal_id, int)
        assert signal_id > 0

    @pytest.mark.asyncio
    async def test_get_signals_filtered_by_kind(self, qdrant_storage):
        await qdrant_storage.add_signal("lesson", "Lesson signal")
        await qdrant_storage.add_signal("error", "Error signal")
        await qdrant_storage.add_signal("lesson", "Another lesson")

        lessons = await qdrant_storage.get_signals(kind="lesson")
        assert len(lessons) == 2
        assert all(s.kind == "lesson" for s in lessons)

    @pytest.mark.asyncio
    async def test_get_signals_all(self, qdrant_storage):
        await qdrant_storage.add_signal("lesson", "L1")
        await qdrant_storage.add_signal("error", "E1")

        all_signals = await qdrant_storage.get_signals()
        assert len(all_signals) == 2


# ===================================================================
# TestQdrantQuery
# ===================================================================


class TestQdrantQuery:
    @pytest.mark.asyncio
    async def test_query_returns_relevant_results(self, qdrant_storage):
        await qdrant_storage.ingest("doc", "python.txt", "Python programming language")
        await qdrant_storage.ingest("doc", "java.txt", "Java programming language")

        results = await qdrant_storage.query("Python programming language", top_k=2)
        assert len(results) == 2
        # Exact match should score highest
        assert results[0]["source"] == "python.txt"
        assert results[0]["score"] > results[1]["score"]

    @pytest.mark.asyncio
    async def test_query_empty_returns_empty(self, qdrant_storage):
        results = await qdrant_storage.query("anything", top_k=5)
        assert results == []

    @pytest.mark.asyncio
    async def test_query_respects_top_k(self, qdrant_storage):
        for i in range(5):
            await qdrant_storage.ingest("doc", f"doc{i}.txt", f"Document number {i}")

        results = await qdrant_storage.query("Document", top_k=2)
        assert len(results) == 2

    @pytest.mark.asyncio
    async def test_query_result_format(self, qdrant_storage):
        await qdrant_storage.ingest("doc", "test.md", "Test content")

        results = await qdrant_storage.query("Test content", top_k=1)
        assert len(results) == 1
        r = results[0]
        assert "chunk_id" in r
        assert "doc_id" in r
        assert "source" in r
        assert "score" in r
        assert "snippet" in r
        assert r["source"] == "test.md"
        assert isinstance(r["score"], float)


# ===================================================================
# TestQdrantGetChunks
# ===================================================================


class TestQdrantGetChunks:
    @pytest.mark.asyncio
    async def test_get_chunks_for_doc(self, qdrant_storage):
        doc_id = await qdrant_storage.ingest("doc", "f.txt", "Short text")
        chunks = await qdrant_storage.get_chunks(doc_id)
        assert len(chunks) == 1
        assert chunks[0].doc_id == doc_id
        assert chunks[0].seq == 0
        assert "Short text" in chunks[0].content

    @pytest.mark.asyncio
    async def test_get_chunks_empty_doc(self, qdrant_storage):
        chunks = await qdrant_storage.get_chunks("doc-nonexistent123")
        assert chunks == []


# ===================================================================
# TestQdrantStats
# ===================================================================


class TestQdrantStats:
    @pytest.mark.asyncio
    async def test_stats_returns_correct_counts(self, qdrant_storage):
        await qdrant_storage.ingest("doc", "a.txt", "Document A content")
        await qdrant_storage.ingest("run", "b.txt", "Document B content")
        await qdrant_storage.add_signal("lesson", "A lesson")

        stats = await qdrant_storage.stats()
        assert stats["documents"] == 2
        assert stats["chunks"] >= 2
        assert stats["signals"] == 1
        assert stats["docs_by_kind"]["doc"] == 1
        assert stats["docs_by_kind"]["run"] == 1


# ===================================================================
# TestQdrantPurge
# ===================================================================


class TestQdrantPurge:
    @pytest.mark.asyncio
    async def test_purge_all(self, qdrant_storage):
        await qdrant_storage.ingest("doc", "a.txt", "Content A")
        await qdrant_storage.add_signal("lesson", "Lesson A")

        await qdrant_storage.purge()

        stats = await qdrant_storage.stats()
        assert stats["documents"] == 0
        assert stats["signals"] == 0

    @pytest.mark.asyncio
    async def test_purge_older_than_days(self, qdrant_storage):
        await qdrant_storage.ingest("doc", "a.txt", "Content A")

        # Purge with very large threshold — nothing should be deleted
        deleted = await qdrant_storage.purge(older_than_days=99999)
        assert deleted == 0

        stats = await qdrant_storage.stats()
        assert stats["documents"] == 1


# ===================================================================
# TestQdrantBuildMemoryContext
# ===================================================================


class TestQdrantBuildMemoryContext:
    @pytest.mark.asyncio
    async def test_build_memory_context_format(self, qdrant_storage):
        await qdrant_storage.ingest("doc", "guide.md", "Python best practices for testing")
        await qdrant_storage.add_signal("lesson", "Always write tests first")

        ctx = await qdrant_storage.build_memory_context("Python testing", top_k=3, max_chars=2000)

        assert "## Relevant Memory" in ctx
        assert "guide.md" in ctx
        assert "## Signals from Past Runs" in ctx
        assert "lesson" in ctx


# ===================================================================
# TestQdrantLifecycle
# ===================================================================


class TestQdrantLifecycle:
    def test_client_none_before_first_call(self):
        storage = QdrantMemoryStorage(
            collection="test", vector_size=_EMBED_DIM, embed_fn=_test_embed
        )
        assert storage._client is None
        assert storage._embedder is None

    @pytest.mark.asyncio
    async def test_close_noop_when_not_connected(self):
        storage = QdrantMemoryStorage(
            collection="test", vector_size=_EMBED_DIM, embed_fn=_test_embed
        )
        await storage.close()  # should not raise
        assert storage._client is None


# ===================================================================
# TestQdrantFactory
# ===================================================================


class TestQdrantFactory:
    def test_qdrant_url_creates_qdrant_memory(self, tmp_path):
        from owlmind.storage import create_storage

        storage = create_storage(
            backend="file",
            runs_dir=str(tmp_path / "runs"),
            ledger_dir=str(tmp_path / "ledger"),
            queue_dir=str(tmp_path / "queue"),
            sessions_dir=str(tmp_path / "sessions"),
            qdrant_url="http://localhost:6333",
            qdrant_collection="test_coll",
            qdrant_vector_size=64,
        )
        assert isinstance(storage.memory, QdrantMemoryStorage)
        assert storage.memory._collection == "test_coll"
        assert storage.memory._vector_size == 64

    def test_qdrant_url_overrides_memory_db(self, tmp_path):
        from owlmind.storage import create_storage

        storage = create_storage(
            backend="file",
            runs_dir=str(tmp_path / "runs"),
            ledger_dir=str(tmp_path / "ledger"),
            queue_dir=str(tmp_path / "queue"),
            sessions_dir=str(tmp_path / "sessions"),
            memory_db=str(tmp_path / "memory.db"),
            qdrant_url="http://localhost:6333",
        )
        # Qdrant takes priority over memory_db
        assert isinstance(storage.memory, QdrantMemoryStorage)
