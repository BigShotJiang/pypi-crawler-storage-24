"""Tests for WebSocket streaming API routes."""

from __future__ import annotations

from pathlib import Path

import pytest

try:
    from fastapi.testclient import TestClient

    HAS_FASTAPI = True
except ImportError:
    HAS_FASTAPI = False


@pytest.fixture
def runs_dir(tmp_path: Path) -> Path:
    d = tmp_path / "runs"
    d.mkdir()
    return d


@pytest.mark.skipif(not HAS_FASTAPI, reason="fastapi not installed")
class TestStreamingRoute:
    def test_make_streaming_router(self, runs_dir: Path) -> None:
        from owlmind.api.routes.streaming import make_streaming_router

        router = make_streaming_router(runs_dir)
        assert router is not None
        # Check routes are registered
        route_paths = [r.path for r in router.routes]
        assert any("ws" in p or "live" in p for p in route_paths)

    def test_sse_endpoint_no_run(self, runs_dir: Path) -> None:
        from fastapi import FastAPI

        from owlmind.api.routes.streaming import make_streaming_router

        app = FastAPI()
        app.include_router(make_streaming_router(runs_dir))

        client = TestClient(app)
        resp = client.get("/api/v1/runs/nonexistent/live")
        assert resp.status_code in (404, 200)
