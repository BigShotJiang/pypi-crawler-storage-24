"""Tests for observability modules (tracing, langfuse, observer)."""

from __future__ import annotations


class TestTracing:
    def test_get_tracer_noop_without_otel(self) -> None:
        from owlmind.monitoring.tracing import get_tracer

        tracer = get_tracer("test")
        assert tracer is not None

    def test_traced_decorator_works(self) -> None:
        from owlmind.monitoring.tracing import traced

        @traced("test_op")
        def my_func(x: int) -> int:
            return x * 2

        assert my_func(5) == 10

    def test_trace_llm_call_noop(self) -> None:
        from owlmind.monitoring.tracing import trace_llm_call

        trace_llm_call(
            provider="openai",
            model="gpt-4o",
            input_tokens=100,
            output_tokens=50,
            latency=0.5,
            success=True,
        )


class TestLangfuseTracker:
    def test_tracker_noop_without_langfuse(self) -> None:
        from owlmind.monitoring.langfuse_tracker import LangfuseTracker

        tracker = LangfuseTracker()
        tracker.track_generation(
            run_id="test-run",
            stage="planner",
            provider="openai",
            model="gpt-4o",
            prompt="test",
            response="test",
            tokens=100,
            cost=0.01,
            latency=0.5,
        )
        tracker.flush()


class TestLLMObserver:
    def test_observer_lifecycle(self) -> None:
        from owlmind.monitoring.llm_observer import LLMObserver

        observer = LLMObserver()
        observer.on_call_start("openai", "planner", {"prompt": "test"})
        observer.on_call_end(
            "openai",
            "planner",
            {"result": "ok"},
            {"tokens": 100, "latency_ms": 500},
        )

        stats = observer.get_stats()
        assert stats["calls_total"] >= 1

    def test_observer_handles_errors(self) -> None:
        from owlmind.monitoring.llm_observer import LLMObserver

        observer = LLMObserver()
        observer.on_call_start("openai", "planner", {})
        observer.on_call_end(
            "openai", "planner", {}, {},
            error=RuntimeError("timeout"),
        )

        stats = observer.get_stats()
        assert stats["calls_failed"] >= 1
