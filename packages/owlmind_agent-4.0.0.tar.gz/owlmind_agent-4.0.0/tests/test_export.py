"""Tests for cycle export — zip bundle creation."""

from __future__ import annotations

import zipfile
from pathlib import Path

from owlmind.agent.cycle import CycleManager
from owlmind.evidence import EvidenceStore
from owlmind.policy import PolicyEngine


def _make_manager(tmp_path: Path) -> CycleManager:
    """Create a CycleManager backed by tmp_path with real policies."""
    policies_dir = tmp_path / "policies"
    policies_dir.mkdir()

    (policies_dir / "allowlist.yaml").write_text(
        "allowed_commands:\n"
        '  - "^echo "\n'
        '  - "^pytest"\n'
        '  - "^ruff check"\n'
        '  - "^mypy"\n'
        '  - "^git status"\n'
        '  - "^git diff"\n'
        '  - "^ls"\n'
    )
    (policies_dir / "policy.yaml").write_text(
        'forbidden_patterns:\n  - "rm -rf"\nrisk_behavior:\n  CRITICAL: BLOCK\n'
    )

    policy = PolicyEngine.from_directory(policies_dir)
    evidence = EvidenceStore(tmp_path / "runs")
    return CycleManager(evidence=evidence, policy=policy)


class TestExport:
    def test_export_creates_zip(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Export test", workspace=str(tmp_path))

        zip_path = mgr.export(meta.run_id)
        assert zip_path.exists()
        assert zip_path.suffix == ".zip"
        assert f"owlmind_export_{meta.run_id}" in zip_path.name

    def test_export_contains_key_files(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Export contents test", workspace=str(tmp_path))

        # Generate PR pack so it's in the export
        mgr.generate_pr_pack(meta.run_id)

        zip_path = mgr.export(meta.run_id)

        with zipfile.ZipFile(zip_path, "r") as zf:
            names = zf.namelist()

        assert "run.jsonl" in names
        assert "cycle_meta.json" in names
        assert "pr_pack.md" in names
        # Outbox should be included
        outbox_files = [n for n in names if n.startswith("outbox/")]
        assert len(outbox_files) >= 1

    def test_export_custom_path(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Custom path", workspace=str(tmp_path))

        custom_out = tmp_path / "my_export.zip"
        zip_path = mgr.export(meta.run_id, out_path=custom_out)
        assert zip_path == custom_out
        assert custom_out.exists()

    def test_export_excludes_worktree(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Exclude test", workspace=str(tmp_path))

        # Create fake worktree dir
        wt_dir = tmp_path / "runs" / meta.run_id / "worktree"
        wt_dir.mkdir(parents=True)
        (wt_dir / "src.py").write_text("print('hello')")

        zip_path = mgr.export(meta.run_id)
        with zipfile.ZipFile(zip_path, "r") as zf:
            names = zf.namelist()

        worktree_files = [n for n in names if "worktree" in n]
        assert worktree_files == []

    def test_export_logs_event(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Event test", workspace=str(tmp_path))

        mgr.export(meta.run_id)

        events = mgr.evidence.read_events(meta.run_id)
        export_events = [e for e in events if e.get("event") == "EXPORT_CREATED"]
        assert len(export_events) == 1
        assert "sha256" in export_events[0]
        assert "bytes" in export_events[0]

    def test_export_not_found(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        import pytest

        with pytest.raises(FileNotFoundError):
            mgr.export("nonexistent-run")
