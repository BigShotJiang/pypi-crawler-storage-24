"""Tests for local LLM drivers: Ollama and llama.cpp."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from owlmind.config import OwlMindConfig, LLamaCppConfig, OllamaConfig
from owlmind.llm.llamacpp_driver import LLamaCppDriver, is_llamacpp_available
from owlmind.llm.ollama_driver import OllamaDriver, is_ollama_available

# ---------------------------------------------------------------------------
# Config tests
# ---------------------------------------------------------------------------


class TestOllamaConfig:
    """Tests for OllamaConfig model."""

    def test_defaults(self) -> None:
        cfg = OllamaConfig()
        assert cfg.base_url == "http://localhost:11434"
        assert cfg.model == "llama3"
        assert cfg.max_output_tokens == 1200
        assert cfg.timeout_sec == 120
        assert cfg.enabled is False

    def test_custom(self) -> None:
        cfg = OllamaConfig(
            base_url="http://gpu-server:11434",
            model="codellama",
            enabled=True,
        )
        assert cfg.base_url == "http://gpu-server:11434"
        assert cfg.model == "codellama"
        assert cfg.enabled is True


class TestLLamaCppConfig:
    """Tests for LLamaCppConfig model."""

    def test_defaults(self) -> None:
        cfg = LLamaCppConfig()
        assert cfg.base_url == "http://localhost:8080"
        assert cfg.model == "default"
        assert cfg.timeout_sec == 120
        assert cfg.enabled is False

    def test_custom(self) -> None:
        cfg = LLamaCppConfig(
            base_url="http://192.168.1.100:8080",
            model="mistral-7b",
            enabled=True,
        )
        assert cfg.model == "mistral-7b"
        assert cfg.enabled is True


class TestConfigFromEnv:
    """Tests for OwlMindConfig.from_env() with local LLM vars."""

    def test_ollama_defaults(self) -> None:
        cfg = OwlMindConfig.from_env()
        assert cfg.ollama.enabled is False
        assert cfg.ollama.model == "llama3"

    @patch.dict("os.environ", {"OWLMIND_OLLAMA_ENABLED": "true", "OLLAMA_MODEL": "codellama"})
    def test_ollama_enabled_from_env(self) -> None:
        cfg = OwlMindConfig.from_env()
        assert cfg.ollama.enabled is True
        assert cfg.ollama.model == "codellama"

    @patch.dict("os.environ", {"OWLMIND_LLAMACPP_ENABLED": "true", "LLAMACPP_MODEL": "phi-3"})
    def test_llamacpp_enabled_from_env(self) -> None:
        cfg = OwlMindConfig.from_env()
        assert cfg.llamacpp.enabled is True
        assert cfg.llamacpp.model == "phi-3"

    @patch.dict("os.environ", {"OLLAMA_BASE_URL": "http://remote:11434"})
    def test_ollama_custom_url(self) -> None:
        cfg = OwlMindConfig.from_env()
        assert cfg.ollama.base_url == "http://remote:11434"

    @patch.dict("os.environ", {"LLAMACPP_BASE_URL": "http://remote:8080"})
    def test_llamacpp_custom_url(self) -> None:
        cfg = OwlMindConfig.from_env()
        assert cfg.llamacpp.base_url == "http://remote:8080"


class TestPricingLocal:
    """Tests for local provider pricing (should be free)."""

    def test_ollama_free(self) -> None:
        from owlmind.config import PricingConfig

        pricing = PricingConfig()
        assert pricing.price_for_provider("ollama") == (0.0, 0.0)

    def test_llamacpp_free(self) -> None:
        from owlmind.config import PricingConfig

        pricing = PricingConfig()
        assert pricing.price_for_provider("llamacpp") == (0.0, 0.0)


# ---------------------------------------------------------------------------
# Availability checks
# ---------------------------------------------------------------------------


class TestAvailabilityChecks:
    """Tests for is_ollama_available() and is_llamacpp_available()."""

    @patch("owlmind.llm.ollama_driver.urllib.request.urlopen")
    def test_ollama_available(self, mock_urlopen: MagicMock) -> None:
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.__enter__ = lambda s: mock_resp
        mock_resp.__exit__ = lambda s, *a: None
        mock_urlopen.return_value = mock_resp
        assert is_ollama_available() is True

    @patch("owlmind.llm.ollama_driver.urllib.request.urlopen", side_effect=Exception("refused"))
    def test_ollama_not_available(self, mock_urlopen: MagicMock) -> None:
        assert is_ollama_available() is False

    @patch("owlmind.llm.llamacpp_driver.urllib.request.urlopen")
    def test_llamacpp_available(self, mock_urlopen: MagicMock) -> None:
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.__enter__ = lambda s: mock_resp
        mock_resp.__exit__ = lambda s, *a: None
        mock_urlopen.return_value = mock_resp
        assert is_llamacpp_available() is True

    @patch("owlmind.llm.llamacpp_driver.urllib.request.urlopen", side_effect=Exception("refused"))
    def test_llamacpp_not_available(self, mock_urlopen: MagicMock) -> None:
        assert is_llamacpp_available() is False


# ---------------------------------------------------------------------------
# OllamaDriver tests
# ---------------------------------------------------------------------------


class TestOllamaDriver:
    """Tests for OllamaDriver."""

    def _make_driver(self) -> OllamaDriver:
        cfg = OllamaConfig(
            base_url="http://localhost:11434",
            model="llama3",
            enabled=True,
        )
        return OllamaDriver(cfg)

    def test_name(self) -> None:
        driver = self._make_driver()
        assert driver.name == "ollama"

    def test_supports_structured(self) -> None:
        driver = self._make_driver()
        assert driver.supports_structured is False

    @patch("owlmind.llm.ollama_driver.urllib.request.urlopen")
    def test_plan_success(self, mock_urlopen: MagicMock) -> None:
        driver = self._make_driver()

        planner_response = {
            "run_id": "test-1",
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Do the thing",
            "verify_commands": ["pytest"],
            "risk_notes": [],
        }
        ollama_response = {
            "model": "llama3",
            "message": {"role": "assistant", "content": json.dumps(planner_response)},
            "prompt_eval_count": 100,
            "eval_count": 50,
        }

        mock_resp = MagicMock()
        mock_resp.read.return_value = json.dumps(ollama_response).encode()
        mock_resp.__enter__ = lambda s: mock_resp
        mock_resp.__exit__ = lambda s, *a: None
        mock_urlopen.return_value = mock_resp

        schema = {"type": "object", "properties": {}}
        request = {"run_id": "test-1", "iteration": 1, "goal": "Fix bug"}
        result, meta = driver.plan(request, schema)

        assert result["run_id"] == "test-1"
        assert meta["provider"] == "ollama"
        assert meta["model"] == "llama3"
        assert meta["usage"]["input_tokens"] == 100
        assert meta["usage"]["output_tokens"] == 50

    @patch("owlmind.llm.ollama_driver.urllib.request.urlopen")
    def test_judge_success(self, mock_urlopen: MagicMock) -> None:
        driver = self._make_driver()

        judge_response = {
            "run_id": "test-1",
            "iteration": 1,
            "verdict": "APPROVED",
            "notes": ["All good"],
            "next_worker_instructions": "",
            "evidence_chain_verified": True,
        }
        ollama_response = {
            "model": "llama3",
            "message": {"role": "assistant", "content": json.dumps(judge_response)},
            "eval_count": 30,
        }

        mock_resp = MagicMock()
        mock_resp.read.return_value = json.dumps(ollama_response).encode()
        mock_resp.__enter__ = lambda s: mock_resp
        mock_resp.__exit__ = lambda s, *a: None
        mock_urlopen.return_value = mock_resp

        schema = {"type": "object", "properties": {}}
        request = {
            "run_id": "test-1",
            "iteration": 1,
            "goal": "Review",
            "planner_plan_summary": [],
            "worker_done_summary": [],
            "verify_results_summary": [],
            "evidence_paths": [],
        }
        result, meta = driver.judge(request, schema)

        assert result["verdict"] == "APPROVED"
        assert meta["provider"] == "ollama"

    @patch("owlmind.llm.ollama_driver.urllib.request.urlopen")
    def test_usage_without_token_counts(self, mock_urlopen: MagicMock) -> None:
        """Ollama response without token counts should still work."""
        driver = self._make_driver()
        ollama_response = {
            "model": "llama3",
            "message": {"role": "assistant", "content": '{"run_id":"x","iteration":1}'},
        }
        mock_resp = MagicMock()
        mock_resp.read.return_value = json.dumps(ollama_response).encode()
        mock_resp.__enter__ = lambda s: mock_resp
        mock_resp.__exit__ = lambda s, *a: None
        mock_urlopen.return_value = mock_resp

        result, meta = driver.plan(
            {"run_id": "x", "iteration": 1, "goal": "test"},
            {"type": "object"},
        )
        assert "usage" not in meta

    @patch(
        "owlmind.llm.ollama_driver.urllib.request.urlopen",
        side_effect=Exception("Connection refused"),
    )
    def test_connection_error(self, mock_urlopen: MagicMock) -> None:
        """Connection errors should be classified and raised."""
        from owlmind.errors import TransientError

        driver = self._make_driver()
        with pytest.raises(TransientError):
            driver.plan(
                {"run_id": "x", "iteration": 1, "goal": "test"},
                {"type": "object"},
            )


# ---------------------------------------------------------------------------
# LLamaCppDriver tests
# ---------------------------------------------------------------------------


class TestLLamaCppDriver:
    """Tests for LLamaCppDriver."""

    def _make_driver(self) -> LLamaCppDriver:
        cfg = LLamaCppConfig(
            base_url="http://localhost:8080",
            model="mistral-7b",
            enabled=True,
        )
        return LLamaCppDriver(cfg)

    def test_name(self) -> None:
        driver = self._make_driver()
        assert driver.name == "llamacpp"

    def test_supports_structured(self) -> None:
        driver = self._make_driver()
        assert driver.supports_structured is False

    @patch("owlmind.llm.llamacpp_driver.urllib.request.urlopen")
    def test_plan_success(self, mock_urlopen: MagicMock) -> None:
        driver = self._make_driver()

        planner_response = {
            "run_id": "lc-1",
            "iteration": 1,
            "plan_summary": ["Analyze"],
            "worker_instructions": "Fix it",
            "verify_commands": ["ruff check"],
            "risk_notes": [],
        }
        oai_response = {
            "id": "chatcmpl-123",
            "model": "mistral-7b",
            "choices": [
                {"message": {"role": "assistant", "content": json.dumps(planner_response)}}
            ],
            "usage": {
                "prompt_tokens": 200,
                "completion_tokens": 80,
                "total_tokens": 280,
            },
        }

        mock_resp = MagicMock()
        mock_resp.read.return_value = json.dumps(oai_response).encode()
        mock_resp.__enter__ = lambda s: mock_resp
        mock_resp.__exit__ = lambda s, *a: None
        mock_urlopen.return_value = mock_resp

        result, meta = driver.plan(
            {"run_id": "lc-1", "iteration": 1, "goal": "Fix bug"},
            {"type": "object"},
        )

        assert result["run_id"] == "lc-1"
        assert meta["provider"] == "llamacpp"
        assert meta["model"] == "mistral-7b"
        assert meta["response_id"] == "chatcmpl-123"
        assert meta["usage"]["input_tokens"] == 200
        assert meta["usage"]["output_tokens"] == 80

    @patch("owlmind.llm.llamacpp_driver.urllib.request.urlopen")
    def test_judge_success(self, mock_urlopen: MagicMock) -> None:
        driver = self._make_driver()

        judge_response = {
            "run_id": "lc-1",
            "iteration": 1,
            "verdict": "NEEDS_FIX",
            "notes": ["Tests fail"],
            "next_worker_instructions": "Fix test",
            "evidence_chain_verified": False,
        }
        oai_response = {
            "id": "chatcmpl-456",
            "model": "mistral-7b",
            "choices": [{"message": {"role": "assistant", "content": json.dumps(judge_response)}}],
            "usage": {"prompt_tokens": 150, "completion_tokens": 60, "total_tokens": 210},
        }

        mock_resp = MagicMock()
        mock_resp.read.return_value = json.dumps(oai_response).encode()
        mock_resp.__enter__ = lambda s: mock_resp
        mock_resp.__exit__ = lambda s, *a: None
        mock_urlopen.return_value = mock_resp

        result, meta = driver.judge(
            {
                "run_id": "lc-1",
                "iteration": 1,
                "goal": "Review",
                "planner_plan_summary": [],
                "worker_done_summary": [],
                "verify_results_summary": [],
                "evidence_paths": [],
            },
            {"type": "object"},
        )

        assert result["verdict"] == "NEEDS_FIX"
        assert meta["provider"] == "llamacpp"

    @patch("owlmind.llm.llamacpp_driver.urllib.request.urlopen")
    def test_no_choices_raises(self, mock_urlopen: MagicMock) -> None:
        """Empty choices array should raise RuntimeError."""
        from owlmind.errors import StructuralError

        driver = self._make_driver()
        oai_response = {"id": "x", "model": "m", "choices": []}

        mock_resp = MagicMock()
        mock_resp.read.return_value = json.dumps(oai_response).encode()
        mock_resp.__enter__ = lambda s: mock_resp
        mock_resp.__exit__ = lambda s, *a: None
        mock_urlopen.return_value = mock_resp

        with pytest.raises(StructuralError):
            driver.plan(
                {"run_id": "x", "iteration": 1, "goal": "test"},
                {"type": "object"},
            )

    @patch("owlmind.llm.llamacpp_driver.urllib.request.urlopen")
    def test_usage_without_usage_field(self, mock_urlopen: MagicMock) -> None:
        """Response without usage field should still work."""
        driver = self._make_driver()
        oai_response = {
            "id": "x",
            "model": "m",
            "choices": [{"message": {"content": '{"run_id":"x","iteration":1}'}}],
        }
        mock_resp = MagicMock()
        mock_resp.read.return_value = json.dumps(oai_response).encode()
        mock_resp.__enter__ = lambda s: mock_resp
        mock_resp.__exit__ = lambda s, *a: None
        mock_urlopen.return_value = mock_resp

        result, meta = driver.plan(
            {"run_id": "x", "iteration": 1, "goal": "test"},
            {"type": "object"},
        )
        assert "usage" not in meta

    @patch(
        "owlmind.llm.llamacpp_driver.urllib.request.urlopen",
        side_effect=Exception("Connection refused"),
    )
    def test_connection_error(self, mock_urlopen: MagicMock) -> None:
        """Connection errors should be classified and raised."""
        from owlmind.errors import TransientError

        driver = self._make_driver()
        with pytest.raises(TransientError):
            driver.plan(
                {"run_id": "x", "iteration": 1, "goal": "test"},
                {"type": "object"},
            )


# ---------------------------------------------------------------------------
# Factory integration tests
# ---------------------------------------------------------------------------


class TestFactoryWithLocalProviders:
    """Tests for build_llm_router with local providers."""

    class _FakeConfig:
        class _Provider:
            def __init__(self, *, enabled: bool = False) -> None:
                self.enabled = enabled
                self.api_key = "test-key"
                self.timeout_sec = 10
                self.model = "test-model"
                self.planner_model = "test-planner"
                self.judge_model = "test-judge"
                self.max_output_tokens = 1000

        class _LocalProvider:
            def __init__(self, *, enabled: bool = False) -> None:
                self.enabled = enabled
                self.base_url = "http://localhost:11434"
                self.model = "test-model"
                self.max_output_tokens = 1000
                self.timeout_sec = 120

        class _Router:
            planner_providers = ["ollama"]
            judge_providers = ["ollama"]

        def __init__(
            self,
            *,
            openai: bool = False,
            anthropic: bool = False,
            gemini: bool = False,
            ollama: bool = False,
            llamacpp: bool = False,
        ) -> None:
            self.openai = self._Provider(enabled=openai)
            self.anthropic = self._Provider(enabled=anthropic)
            self.gemini = self._Provider(enabled=gemini)
            self.ollama = self._LocalProvider(enabled=ollama)
            self.llamacpp = self._LocalProvider(enabled=llamacpp)
            self.router = self._Router()

    def test_ollama_only(self) -> None:
        from owlmind.llm.factory import build_llm_router

        cfg = self._FakeConfig(ollama=True)
        router = build_llm_router(cfg)
        assert "ollama" in router.available_providers()

    def test_llamacpp_only(self) -> None:
        from owlmind.llm.factory import build_llm_router

        cfg = self._FakeConfig(llamacpp=True)
        cfg.router.planner_providers = ["llamacpp"]
        cfg.router.judge_providers = ["llamacpp"]
        router = build_llm_router(cfg)
        assert "llamacpp" in router.available_providers()

    @patch("owlmind.llm.openai_driver.is_openai_available", return_value=True)
    @patch("owlmind.llm.openai_driver.OpenAIDriver", new_callable=lambda: MagicMock)
    def test_mixed_providers(self, mock_driver: MagicMock, mock_avail: MagicMock) -> None:
        from owlmind.llm.factory import build_llm_router

        cfg = self._FakeConfig(openai=True, ollama=True)
        cfg.router.planner_providers = ["ollama", "openai"]
        cfg.router.judge_providers = ["openai"]
        router = build_llm_router(cfg)
        providers = router.available_providers()
        assert "ollama" in providers
        assert "openai" in providers

    def test_force_ollama(self) -> None:
        from owlmind.llm.factory import build_llm_router

        cfg = self._FakeConfig(ollama=True)
        router = build_llm_router(cfg, force_planner="ollama", force_judge="ollama")
        assert "ollama" in router.available_providers()

    def test_no_providers_still_raises(self) -> None:
        from owlmind.llm.factory import build_llm_router

        cfg = self._FakeConfig()
        with pytest.raises(RuntimeError, match="No LLM providers available"):
            build_llm_router(cfg)
