"""Tests for Anthropic LLM driver — NO network calls (fully mocked)."""

from __future__ import annotations

from types import SimpleNamespace
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from owlmind.config import AnthropicConfig
from owlmind.errors import StructuralError, TransientError
from owlmind.llm.anthropic_driver import AnthropicDriver, is_anthropic_available


def _make_config(**overrides: Any) -> AnthropicConfig:
    return AnthropicConfig(
        api_key=overrides.get("api_key", "test-key-123"),
        model=overrides.get("model", "claude-sonnet-test"),
        max_output_tokens=overrides.get("max_output_tokens", 500),
        timeout_sec=overrides.get("timeout_sec", 10),
    )


def _mock_response(content_dict: dict[str, Any]) -> SimpleNamespace:
    """Build a mock Anthropic messages response."""
    import json

    text_block = SimpleNamespace(type="text", text=json.dumps(content_dict))
    usage = SimpleNamespace(input_tokens=120, output_tokens=60)
    return SimpleNamespace(
        id="msg-abc123",
        content=[text_block],
        usage=usage,
    )


_PLANNER_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "run_id": {"type": "string"},
        "iteration": {"type": "integer"},
        "plan_summary": {"type": "array", "items": {"type": "string"}},
        "worker_instructions": {"type": "string"},
        "verify_commands": {"type": "array", "items": {"type": "string"}},
        "risk_notes": {"type": "array", "items": {"type": "string"}},
    },
    "required": [
        "run_id",
        "iteration",
        "plan_summary",
        "worker_instructions",
        "verify_commands",
        "risk_notes",
    ],
    "additionalProperties": False,
}

_JUDGE_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "run_id": {"type": "string"},
        "iteration": {"type": "integer"},
        "verdict": {"type": "string", "enum": ["APPROVED", "NEEDS_FIX", "REJECTED"]},
        "notes": {"type": "array", "items": {"type": "string"}},
        "next_worker_instructions": {"type": "string"},
        "evidence_chain_verified": {"type": "boolean"},
    },
    "required": [
        "run_id",
        "iteration",
        "verdict",
        "notes",
        "next_worker_instructions",
        "evidence_chain_verified",
    ],
    "additionalProperties": False,
}


class TestIsAnthropicAvailable:
    def test_returns_bool(self) -> None:
        result = is_anthropic_available()
        assert isinstance(result, bool)


class TestAnthropicDriverInit:
    @patch("owlmind.llm.anthropic_driver._ANTHROPIC_AVAILABLE", False)
    def test_no_client_without_sdk(self) -> None:
        config = _make_config()
        driver = AnthropicDriver(config)
        assert driver._client is None

    def test_no_client_without_key(self) -> None:
        config = _make_config(api_key="")
        driver = AnthropicDriver(config)
        assert driver._client is None

    def test_name(self) -> None:
        config = _make_config(api_key="")
        driver = AnthropicDriver(config)
        assert driver.name == "anthropic"

    def test_supports_structured(self) -> None:
        config = _make_config(api_key="")
        driver = AnthropicDriver(config)
        assert driver.supports_structured is True


class TestAnthropicDriverPlan:
    def test_plan_returns_valid_response(self) -> None:
        config = _make_config()
        driver = AnthropicDriver(config)

        planner_response = {
            "run_id": "cycle-test",
            "iteration": 1,
            "plan_summary": ["Step 1: Do thing"],
            "worker_instructions": "Do the thing",
            "verify_commands": ["pytest -q"],
            "risk_notes": [],
        }
        mock_resp = _mock_response(planner_response)

        mock_client = MagicMock()
        mock_client.messages.create.return_value = mock_resp
        driver._client = mock_client

        request = {
            "run_id": "cycle-test",
            "iteration": 1,
            "goal": "Test goal",
            "repo_context": "Test repo",
            "constraints": ["Be safe"],
        }

        result, meta = driver.plan(request, _PLANNER_SCHEMA)

        assert result["run_id"] == "cycle-test"
        assert result["plan_summary"] == ["Step 1: Do thing"]
        assert meta["provider"] == "anthropic"
        assert meta["model"] == "claude-sonnet-test"
        assert meta["usage"]["input_tokens"] == 120
        assert meta["usage"]["output_tokens"] == 60
        assert meta["usage"]["total_tokens"] == 180

    def test_plan_passes_output_config(self) -> None:
        config = _make_config()
        driver = AnthropicDriver(config)

        mock_client = MagicMock()
        mock_client.messages.create.return_value = _mock_response(
            {
                "run_id": "x",
                "iteration": 1,
                "plan_summary": [],
                "worker_instructions": "x",
                "verify_commands": [],
                "risk_notes": [],
            }
        )
        driver._client = mock_client

        driver.plan({"run_id": "x"}, _PLANNER_SCHEMA)

        call_kwargs = mock_client.messages.create.call_args.kwargs
        output_config = call_kwargs["output_config"]
        assert output_config["format"]["type"] == "json_schema"
        assert output_config["format"]["schema"] == _PLANNER_SCHEMA


class TestAnthropicDriverJudge:
    def test_judge_returns_valid_response(self) -> None:
        config = _make_config()
        driver = AnthropicDriver(config)

        judge_response = {
            "run_id": "cycle-test",
            "iteration": 1,
            "verdict": "APPROVED",
            "notes": ["Good work"],
            "next_worker_instructions": "",
            "evidence_chain_verified": True,
        }
        mock_resp = _mock_response(judge_response)

        mock_client = MagicMock()
        mock_client.messages.create.return_value = mock_resp
        driver._client = mock_client

        request = {
            "run_id": "cycle-test",
            "iteration": 1,
            "goal": "Test goal",
            "planner_plan_summary": ["Step 1"],
            "worker_done_summary": ["Done"],
            "verify_results_summary": ["pytest: PASS"],
            "evidence_paths": [],
        }

        result, meta = driver.judge(request, _JUDGE_SCHEMA)

        assert result["verdict"] == "APPROVED"
        assert meta["provider"] == "anthropic"
        assert meta["usage"]["total_tokens"] == 180


class TestAnthropicDriverErrors:
    def test_raises_without_client(self) -> None:
        config = _make_config(api_key="")
        driver = AnthropicDriver(config)

        with pytest.raises(RuntimeError, match="not initialized"):
            driver.plan({"run_id": "x"}, _PLANNER_SCHEMA)

    @patch("owlmind.llm.anthropic_driver.time.sleep")
    def test_retries_on_transient_error(self, mock_sleep: MagicMock) -> None:
        config = _make_config()
        driver = AnthropicDriver(config)

        mock_client = MagicMock()
        mock_client.messages.create.side_effect = [
            RuntimeError("Connection timeout"),
            _mock_response(
                {
                    "run_id": "x",
                    "iteration": 1,
                    "plan_summary": [],
                    "worker_instructions": "x",
                    "verify_commands": [],
                    "risk_notes": [],
                }
            ),
        ]
        driver._client = mock_client

        result, meta = driver.plan({"run_id": "x"}, _PLANNER_SCHEMA)
        assert result["run_id"] == "x"
        assert mock_client.messages.create.call_count == 2

    @patch("owlmind.llm.retry.time.sleep")
    def test_fails_after_max_retries(self, mock_sleep: MagicMock) -> None:
        config = _make_config()
        driver = AnthropicDriver(config)

        mock_client = MagicMock()
        mock_client.messages.create.side_effect = RuntimeError("Connection timeout")
        driver._client = mock_client

        with pytest.raises(TransientError, match="failed after 5 retries"):
            driver.plan({"run_id": "x"}, _PLANNER_SCHEMA)

    def test_json_decode_error_no_retry(self) -> None:
        config = _make_config()
        driver = AnthropicDriver(config)

        text_block = SimpleNamespace(type="text", text="not valid json{{{")
        usage = SimpleNamespace(input_tokens=10, output_tokens=5)
        bad_response = SimpleNamespace(id="msg-bad", content=[text_block], usage=usage)

        mock_client = MagicMock()
        mock_client.messages.create.return_value = bad_response
        driver._client = mock_client

        with pytest.raises(StructuralError, match="JSON decode error"):
            driver.plan({"run_id": "x"}, _PLANNER_SCHEMA)

        # Should NOT have retried
        assert mock_client.messages.create.call_count == 1


class TestAnthropicDriverUsageMissing:
    def test_handles_missing_usage(self) -> None:
        config = _make_config()
        driver = AnthropicDriver(config)

        import json

        text_block = SimpleNamespace(
            type="text",
            text=json.dumps(
                {
                    "run_id": "x",
                    "iteration": 1,
                    "plan_summary": [],
                    "worker_instructions": "x",
                    "verify_commands": [],
                    "risk_notes": [],
                }
            ),
        )
        # Response without usage attribute
        resp = SimpleNamespace(id="msg-nousage", content=[text_block])

        mock_client = MagicMock()
        mock_client.messages.create.return_value = resp
        driver._client = mock_client

        _, meta = driver.plan({"run_id": "x"}, _PLANNER_SCHEMA)
        assert meta["usage"]["usage_missing"] is True
        assert meta["usage"]["total_tokens"] == 0
