"""Tests for FS71 — CLI analytics, monitor, and export commands."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from owlmind.cli import app

runner = CliRunner()


class TestAnalyticsToday:
    def test_today_ok(self, tmp_path: Path) -> None:
        """analytics today → exit 0, print_totals called once."""
        with (
            patch("owlmind.ledger.UsageLedger") as MockLedger,
            patch("owlmind.cli.analytics.print_totals") as mock_print,
        ):
            MockLedger.return_value.totals_for_day.return_value = MagicMock()
            result = runner.invoke(
                app, ["analytics", "today", "--ledger-dir", str(tmp_path / "ledger")]
            )

        assert result.exit_code == 0, result.output
        mock_print.assert_called_once()


class TestAnalyticsDay:
    def test_day_ok(self, tmp_path: Path) -> None:
        """analytics day --date 2024-01-01 → exit 0."""
        with (
            patch("owlmind.ledger.UsageLedger") as MockLedger,
            patch("owlmind.cli.analytics.print_totals") as mock_print,
        ):
            MockLedger.return_value.totals_for_day.return_value = MagicMock()
            result = runner.invoke(
                app,
                [
                    "analytics",
                    "day",
                    "--date",
                    "2024-01-01",
                    "--ledger-dir",
                    str(tmp_path / "ledger"),
                ],
            )

        assert result.exit_code == 0, result.output
        mock_print.assert_called_once()


class TestAnalyticsCostReport:
    def test_invalid_period(self) -> None:
        """analytics cost-report --period invalid → exit 1."""
        result = runner.invoke(app, ["analytics", "cost-report", "--period", "invalid"])

        assert result.exit_code == 1
        assert "Unknown period" in result.output

    def test_ok_day_period(self, tmp_path: Path) -> None:
        """analytics cost-report --period day → exit 0."""
        mock_report = MagicMock()

        with (
            patch("owlmind.reports.daily_report", return_value=mock_report),
            patch("owlmind.reports.format_report_text", return_value="Cost report text"),
        ):
            result = runner.invoke(
                app,
                [
                    "analytics",
                    "cost-report",
                    "--period",
                    "day",
                    "--ledger-dir",
                    str(tmp_path / "ledger"),
                ],
            )

        assert result.exit_code == 0, result.output


class TestMonitorDigest:
    def test_digest_ok(self, tmp_path: Path) -> None:
        """monitor digest → exit 0, digest markdown printed."""
        mock_report = MagicMock()

        with (
            patch("owlmind.monitor.build_digest", return_value=mock_report),
            patch("owlmind.monitor.format_digest_markdown", return_value="## Digest\nAll good."),
        ):
            result = runner.invoke(
                app,
                ["monitor", "digest", "--ledger-dir", str(tmp_path / "ledger")],
            )

        assert result.exit_code == 0, result.output


class TestMonitorStuck:
    def test_stuck_none(self, tmp_path: Path) -> None:
        """monitor stuck with no stuck sessions → exit 0."""
        with (
            patch("owlmind.monitor.detect_stuck_sessions", return_value=[]),
            patch("owlmind.monitor.format_stuck_text", return_value="No stuck sessions."),
        ):
            result = runner.invoke(
                app,
                ["monitor", "stuck", "--sessions-dir", str(tmp_path / "sessions")],
            )

        assert result.exit_code == 0

    def test_stuck_found(self, tmp_path: Path) -> None:
        """monitor stuck with stuck sessions → exit 2."""
        mock_session = MagicMock()
        mock_session.session_id = "sess-stuck"

        with (
            patch("owlmind.monitor.detect_stuck_sessions", return_value=[mock_session]),
            patch("owlmind.monitor.format_stuck_text", return_value="Session sess-stuck is stuck."),
        ):
            result = runner.invoke(
                app,
                ["monitor", "stuck", "--sessions-dir", str(tmp_path / "sessions")],
            )

        assert result.exit_code == 2


class TestExportLedger:
    def test_ledger_ok(self, tmp_path: Path) -> None:
        """export ledger → exit 0, path in output."""
        out_path = tmp_path / "ledger.csv"

        with patch("owlmind.exporters.export_ledger_csv", return_value=out_path):
            result = runner.invoke(
                app,
                [
                    "export",
                    "ledger",
                    "--out",
                    str(out_path),
                    "--ledger-dir",
                    str(tmp_path / "ledger"),
                ],
            )

        assert result.exit_code == 0, result.output
        assert "ledger.csv" in result.output


class TestAnalyticsRun:
    def test_run_ok(self, tmp_path: Path) -> None:
        """analytics run --run-id abc123 → exit 0, print_totals called once."""
        with (
            patch("owlmind.ledger.UsageLedger") as MockLedger,
            patch("owlmind.cli.analytics.print_totals") as mock_print,
        ):
            MockLedger.return_value.totals_for_run.return_value = MagicMock()
            result = runner.invoke(
                app,
                [
                    "analytics",
                    "run",
                    "--run-id",
                    "abc123",
                    "--ledger-dir",
                    str(tmp_path / "ledger"),
                ],
            )

        assert result.exit_code == 0, result.output
        mock_print.assert_called_once()

    def test_run_correct_run_id_passed(self, tmp_path: Path) -> None:
        """analytics run passes run_id to ledger.totals_for_run."""
        mock_ledger_instance = MagicMock()
        mock_ledger_instance.totals_for_run.return_value = MagicMock()

        with (
            patch("owlmind.ledger.UsageLedger", return_value=mock_ledger_instance),
            patch("owlmind.cli.analytics.print_totals"),
        ):
            result = runner.invoke(
                app,
                [
                    "analytics",
                    "run",
                    "--run-id",
                    "run-xyz-999",
                    "--ledger-dir",
                    str(tmp_path / "ledger"),
                ],
            )

        assert result.exit_code == 0, result.output
        mock_ledger_instance.totals_for_run.assert_called_once_with("run-xyz-999")


class TestAnalyticsRecent:
    def test_recent_no_entries(self, tmp_path: Path) -> None:
        """analytics recent with empty ledger → 'No usage entries found'."""
        with patch("owlmind.ledger.UsageLedger") as MockLedger:
            MockLedger.return_value.recent.return_value = []
            result = runner.invoke(
                app,
                ["analytics", "recent", "--ledger-dir", str(tmp_path / "ledger")],
            )

        assert result.exit_code == 0, result.output
        assert "No usage entries" in result.output

    def test_recent_with_entries(self, tmp_path: Path) -> None:
        """analytics recent with entries → table rendered, exit 0."""
        entry = MagicMock()
        entry.ts = "2024-01-15T10:30:00Z"
        entry.run_id = "run-001"
        entry.stage = "plan"
        entry.model = "gpt-4o"
        entry.total_tokens = 1500
        entry.estimated_usd = 0.003

        with patch("owlmind.ledger.UsageLedger") as MockLedger:
            MockLedger.return_value.recent.return_value = [entry]
            result = runner.invoke(
                app,
                ["analytics", "recent", "--ledger-dir", str(tmp_path / "ledger")],
            )

        assert result.exit_code == 0, result.output

    def test_recent_custom_n(self, tmp_path: Path) -> None:
        """analytics recent -n 5 → recent called with n=5."""
        mock_ledger_instance = MagicMock()
        mock_ledger_instance.recent.return_value = []

        with patch("owlmind.ledger.UsageLedger", return_value=mock_ledger_instance):
            result = runner.invoke(
                app,
                ["analytics", "recent", "--ledger-dir", str(tmp_path / "ledger"), "-n", "5"],
            )

        assert result.exit_code == 0, result.output
        mock_ledger_instance.recent.assert_called_once_with(5)

    def test_recent_short_ts(self, tmp_path: Path) -> None:
        """analytics recent handles entries with short ts (< 19 chars)."""
        entry = MagicMock()
        entry.ts = "2024-01-15"
        entry.run_id = "run-short-ts"
        entry.stage = "judge"
        entry.model = "claude-3"
        entry.total_tokens = 500
        entry.estimated_usd = 0.001

        with patch("owlmind.ledger.UsageLedger") as MockLedger:
            MockLedger.return_value.recent.return_value = [entry]
            result = runner.invoke(
                app,
                ["analytics", "recent", "--ledger-dir", str(tmp_path / "ledger")],
            )

        assert result.exit_code == 0, result.output


class TestAnalyticsDashboard:
    def test_dashboard_ok(self, tmp_path: Path) -> None:
        """analytics dashboard --out output.html → exit 0, path in output."""
        out_path = tmp_path / "dashboard.html"

        with patch("owlmind.dashboard.generate_dashboard") as mock_gen:
            result = runner.invoke(
                app,
                [
                    "analytics",
                    "dashboard",
                    "--out",
                    str(out_path),
                    "--ledger-dir",
                    str(tmp_path / "ledger"),
                    "--runs",
                    str(tmp_path / "runs"),
                ],
            )

        assert result.exit_code == 0, result.output
        mock_gen.assert_called_once()
        assert "dashboard.html" in result.output


class TestAnalyticsCostReportExtended:
    def test_week_period(self, tmp_path: Path) -> None:
        """analytics cost-report --period week → exit 0."""
        mock_report = MagicMock()

        with (
            patch("owlmind.reports.weekly_report", return_value=mock_report),
            patch("owlmind.reports.format_report_text", return_value="Weekly report"),
        ):
            result = runner.invoke(
                app,
                [
                    "analytics",
                    "cost-report",
                    "--period",
                    "week",
                    "--ledger-dir",
                    str(tmp_path / "ledger"),
                ],
            )

        assert result.exit_code == 0, result.output

    def test_month_period(self, tmp_path: Path) -> None:
        """analytics cost-report --period month → exit 0."""
        mock_report = MagicMock()

        with (
            patch("owlmind.reports.monthly_report", return_value=mock_report),
            patch("owlmind.reports.format_report_text", return_value="Monthly report"),
        ):
            result = runner.invoke(
                app,
                [
                    "analytics",
                    "cost-report",
                    "--period",
                    "month",
                    "--ledger-dir",
                    str(tmp_path / "ledger"),
                ],
            )

        assert result.exit_code == 0, result.output

    def test_json_format(self, tmp_path: Path) -> None:
        """analytics cost-report --format json → format_report_json called."""
        mock_report = MagicMock()

        with (
            patch("owlmind.reports.daily_report", return_value=mock_report),
            patch("owlmind.reports.format_report_json", return_value='{"total": 0}') as mock_json,
        ):
            result = runner.invoke(
                app,
                [
                    "analytics",
                    "cost-report",
                    "--period",
                    "day",
                    "--format",
                    "json",
                    "--ledger-dir",
                    str(tmp_path / "ledger"),
                ],
            )

        assert result.exit_code == 0, result.output
        mock_json.assert_called_once_with(mock_report)


class TestAnalyticsProviderBreakdown:
    def test_provider_breakdown_no_data(self, tmp_path: Path) -> None:
        """analytics provider-breakdown with no data → 'No usage data found'."""
        with patch("owlmind.reports.provider_breakdown", return_value=[]):
            result = runner.invoke(
                app,
                [
                    "analytics",
                    "provider-breakdown",
                    "--ledger-dir",
                    str(tmp_path / "ledger"),
                ],
            )

        assert result.exit_code == 0, result.output
        assert "No usage data" in result.output

    def test_provider_breakdown_text(self, tmp_path: Path) -> None:
        """analytics provider-breakdown with data → table rendered."""
        rows = [
            {
                "provider": "openai",
                "model": "gpt-4o",
                "tokens": 10000,
                "usd": 0.05,
                "calls": 3,
                "pct": 75.0,
            },
            {
                "provider": "anthropic",
                "model": "claude-3",
                "tokens": 3000,
                "usd": 0.015,
                "calls": 1,
                "pct": 25.0,
            },
        ]

        with patch("owlmind.reports.provider_breakdown", return_value=rows):
            result = runner.invoke(
                app,
                [
                    "analytics",
                    "provider-breakdown",
                    "--ledger-dir",
                    str(tmp_path / "ledger"),
                ],
            )

        assert result.exit_code == 0, result.output

    def test_provider_breakdown_json(self, tmp_path: Path) -> None:
        """analytics provider-breakdown --format json → JSON output."""
        rows = [
            {
                "provider": "openai",
                "model": "gpt-4o",
                "tokens": 500,
                "usd": 0.01,
                "calls": 1,
                "pct": 100.0,
            }
        ]

        with patch("owlmind.reports.provider_breakdown", return_value=rows):
            result = runner.invoke(
                app,
                [
                    "analytics",
                    "provider-breakdown",
                    "--format",
                    "json",
                    "--ledger-dir",
                    str(tmp_path / "ledger"),
                ],
            )

        assert result.exit_code == 0, result.output
        assert "openai" in result.output


class TestMonitorDigestExtended:
    def test_digest_writes_file(self, tmp_path: Path) -> None:
        """monitor digest --out file.md → digest written to file."""
        out_path = tmp_path / "digest.md"
        mock_report = MagicMock()

        with (
            patch("owlmind.monitor.build_digest", return_value=mock_report),
            patch(
                "owlmind.monitor.format_digest_markdown",
                return_value="## Digest\nContent here.",
            ),
        ):
            result = runner.invoke(
                app,
                [
                    "monitor",
                    "digest",
                    "--out",
                    str(out_path),
                    "--ledger-dir",
                    str(tmp_path / "ledger"),
                ],
            )

        assert result.exit_code == 0, result.output
        assert "Digest written to" in result.output
        assert out_path.read_text() == "## Digest\nContent here."

    def test_digest_custom_days(self, tmp_path: Path) -> None:
        """monitor digest --days 7 → build_digest called with days=7."""
        mock_report = MagicMock()

        with (
            patch("owlmind.monitor.build_digest", return_value=mock_report) as mock_build,
            patch("owlmind.monitor.format_digest_markdown", return_value="## Weekly Digest"),
        ):
            result = runner.invoke(
                app,
                [
                    "monitor",
                    "digest",
                    "--days",
                    "7",
                    "--ledger-dir",
                    str(tmp_path / "ledger"),
                ],
            )

        assert result.exit_code == 0, result.output
        mock_build.assert_called_once()
        call_kwargs = mock_build.call_args.kwargs
        assert call_kwargs.get("days") == 7


class TestMonitorNotify:
    def test_notify_no_telegram_config(self, tmp_path: Path, monkeypatch: object) -> None:
        """monitor notify without Telegram env vars → setup guide printed."""
        import os

        monkeypatch.delenv("TELEGRAM_BOT_TOKEN", raising=False)
        monkeypatch.delenv("OWLMIND_NOTIFY_DEFAULT_CHAT_ID", raising=False)

        mock_report = MagicMock()

        with (
            patch("owlmind.monitor.build_digest", return_value=mock_report),
            patch(
                "owlmind.monitor.format_digest_markdown",
                return_value="## Digest\nPreview.",
            ),
        ):
            result = runner.invoke(
                app,
                ["monitor", "notify", "--ledger-dir", str(tmp_path / "ledger")],
                env={
                    k: v
                    for k, v in os.environ.items()
                    if k not in ("TELEGRAM_BOT_TOKEN", "OWLMIND_NOTIFY_DEFAULT_CHAT_ID")
                },
            )

        assert result.exit_code == 0, result.output
        assert "Telegram not configured" in result.output

    def test_notify_with_telegram_config(self, tmp_path: Path) -> None:
        """monitor notify with Telegram env vars → digest preview printed."""
        mock_report = MagicMock()

        with (
            patch("owlmind.monitor.build_digest", return_value=mock_report),
            patch(
                "owlmind.monitor.format_digest_markdown",
                return_value="## Digest\nSent.",
            ),
        ):
            result = runner.invoke(
                app,
                ["monitor", "notify", "--ledger-dir", str(tmp_path / "ledger")],
                env={"TELEGRAM_BOT_TOKEN": "tok123", "OWLMIND_NOTIFY_DEFAULT_CHAT_ID": "456"},
            )

        assert result.exit_code == 0, result.output
        assert "Telegram notification would be sent" in result.output


class TestExportSessions:
    def test_sessions_ok(self, tmp_path: Path) -> None:
        """export sessions → exit 0, path in output."""
        out_path = tmp_path / "sessions.csv"

        with patch("owlmind.exporters.export_sessions_csv", return_value=out_path):
            result = runner.invoke(
                app,
                [
                    "export",
                    "sessions",
                    "--out",
                    str(out_path),
                    "--sessions-dir",
                    str(tmp_path / "sessions"),
                ],
            )

        assert result.exit_code == 0, result.output
        assert "sessions.csv" in result.output


class TestExportRuns:
    def test_runs_ok(self, tmp_path: Path) -> None:
        """export runs → exit 0, path in output."""
        out_path = tmp_path / "runs.csv"

        with patch("owlmind.exporters.export_runs_csv", return_value=out_path):
            result = runner.invoke(
                app,
                [
                    "export",
                    "runs",
                    "--out",
                    str(out_path),
                    "--runs-dir",
                    str(tmp_path / "runs"),
                ],
            )

        assert result.exit_code == 0, result.output
        assert "runs.csv" in result.output


class TestExportAll:
    def test_export_all_ok(self, tmp_path: Path) -> None:
        """export all → exit 0, zip path in output."""
        out_path = tmp_path / "ops_export.zip"

        with patch("owlmind.exporters.export_all_zip", return_value=out_path):
            result = runner.invoke(
                app,
                [
                    "export",
                    "all",
                    "--out",
                    str(out_path),
                    "--ledger-dir",
                    str(tmp_path / "ledger"),
                    "--sessions-dir",
                    str(tmp_path / "sessions"),
                    "--runs-dir",
                    str(tmp_path / "runs"),
                ],
            )

        assert result.exit_code == 0, result.output
        assert "ops_export.zip" in result.output
