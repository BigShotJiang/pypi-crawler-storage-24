"""Tests for owlmind.tui.widgets — Rich-based TUI widget functions."""

from __future__ import annotations

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from owlmind.tui.widgets import budget_panel, event_log, queue_panel, runs_table


def _render(renderable: object) -> str:
    """Render a Rich object to plain text for assertions."""
    console = Console(file=None, force_terminal=False, width=120)
    with console.capture() as capture:
        console.print(renderable)
    return capture.get()


class TestRunsTable:
    def test_returns_table(self) -> None:
        result = runs_table([])
        assert isinstance(result, Table)

    def test_empty_runs(self) -> None:
        result = runs_table([])
        text = _render(result)
        assert "Runs" in text

    def test_single_run(self) -> None:
        runs = [
            {
                "run_id": "cycle-abc123",
                "state": "DONE",
                "goal": "Fix the tests",
                "iteration": 3,
                "updated_at": "2025-01-15T10:30:00Z",
            }
        ]
        result = runs_table(runs)
        text = _render(result)
        assert "cycle-abc123" in text
        assert "DONE" in text
        assert "Fix the tests" in text
        assert "3" in text

    def test_multiple_states(self) -> None:
        runs = [
            {
                "run_id": "r1",
                "state": "DONE",
                "goal": "g1",
                "iteration": 1,
                "updated_at": "2025-01-01T00:00:00Z",
            },
            {
                "run_id": "r2",
                "state": "FAILED",
                "goal": "g2",
                "iteration": 2,
                "updated_at": "2025-01-01T00:00:00Z",
            },
            {"run_id": "r3", "state": "PLANNING", "goal": "g3", "iteration": 0, "updated_at": None},
        ]
        result = runs_table(runs)
        text = _render(result)
        assert "DONE" in text
        assert "FAILED" in text
        assert "PLANNING" in text

    def test_goal_truncation(self) -> None:
        long_goal = "A" * 100
        runs = [
            {
                "run_id": "r1",
                "state": "?",
                "goal": long_goal,
                "iteration": 0,
                "updated_at": "2025-01-01T00:00:00",
            }
        ]
        result = runs_table(runs)
        text = _render(result)
        # Goal should be truncated to 40 chars
        assert "A" * 40 in text

    def test_missing_fields(self) -> None:
        runs = [{}]
        result = runs_table(runs)
        text = _render(result)
        assert "?" in text


class TestBudgetPanel:
    def test_returns_panel(self) -> None:
        result = budget_panel({})
        assert isinstance(result, Panel)

    def test_zero_budget(self) -> None:
        totals = {
            "total_tokens": 0,
            "estimated_usd": 0.0,
            "max_tokens": 500_000,
            "max_usd": 10.0,
        }
        result = budget_panel(totals)
        text = _render(result)
        assert "Budget" in text
        assert "0%" in text
        assert "Tokens" in text
        assert "USD" in text

    def test_partial_budget(self) -> None:
        totals = {
            "total_tokens": 250_000,
            "estimated_usd": 5.0,
            "max_tokens": 500_000,
            "max_usd": 10.0,
        }
        result = budget_panel(totals)
        text = _render(result)
        assert "50%" in text
        assert "250,000" in text

    def test_full_budget(self) -> None:
        totals = {
            "total_tokens": 500_000,
            "estimated_usd": 10.0,
            "max_tokens": 500_000,
            "max_usd": 10.0,
        }
        result = budget_panel(totals)
        text = _render(result)
        assert "100%" in text

    def test_zero_max_no_division_error(self) -> None:
        totals = {
            "total_tokens": 100,
            "estimated_usd": 0.5,
            "max_tokens": 0,
            "max_usd": 0.0,
        }
        # Should not raise ZeroDivisionError
        result = budget_panel(totals)
        text = _render(result)
        assert "Budget" in text

    def test_missing_keys(self) -> None:
        result = budget_panel({})
        text = _render(result)
        assert "Budget" in text
        assert "0%" in text


class TestEventLog:
    def test_returns_panel(self) -> None:
        result = event_log([])
        assert isinstance(result, Panel)

    def test_empty_events(self) -> None:
        result = event_log([])
        text = _render(result)
        assert "Events" in text
        assert "No events yet" in text

    def test_single_event(self) -> None:
        events = [
            {"event": "run_started", "timestamp": "10:30:00", "run_id": "cycle-001"},
        ]
        result = event_log(events)
        text = _render(result)
        assert "run_started" in text
        assert "10:30:00" in text
        assert "cycle-001" in text

    def test_multiple_event_types(self) -> None:
        events = [
            {"event": "run_started", "timestamp": "10:30:00", "run_id": "r1"},
            {"event": "run_done", "timestamp": "10:31:00", "run_id": "r1"},
            {"event": "run_failed", "timestamp": "10:32:00", "run_id": "r2"},
            {"event": "budget_warning", "timestamp": "10:33:00", "run_id": ""},
            {"event": "budget_exceeded", "timestamp": "10:34:00", "run_id": ""},
        ]
        result = event_log(events)
        text = _render(result)
        assert "run_started" in text
        assert "run_done" in text
        assert "run_failed" in text
        assert "budget_warning" in text
        assert "budget_exceeded" in text

    def test_max_items_limit(self) -> None:
        events = [
            {"event": f"event_{i}", "timestamp": f"10:{i:02d}:00", "run_id": ""} for i in range(20)
        ]
        result = event_log(events, max_items=5)
        text = _render(result)
        # Should only show last 5
        assert "event_19" in text
        assert "event_15" in text
        assert "event_0" not in text

    def test_event_without_run_id(self) -> None:
        events = [
            {"event": "budget_warning", "timestamp": "10:00:00", "run_id": ""},
        ]
        result = event_log(events)
        text = _render(result)
        assert "budget_warning" in text


class TestQueuePanel:
    def test_returns_panel(self) -> None:
        result = queue_panel([])
        assert isinstance(result, Panel)

    def test_empty_queue(self) -> None:
        result = queue_panel([])
        text = _render(result)
        assert "Queue" in text
        assert "Queue empty" in text

    def test_single_item(self) -> None:
        items = [{"status": "PENDING", "goal": "Run unit tests"}]
        result = queue_panel(items)
        text = _render(result)
        assert "PENDING" in text
        assert "Run unit tests" in text
        assert "Queue (1)" in text

    def test_multiple_statuses(self) -> None:
        items = [
            {"status": "RUNNING", "goal": "Build project"},
            {"status": "PENDING", "goal": "Deploy app"},
            {"status": "DONE", "goal": "Lint code"},
            {"status": "FAILED", "goal": "Integration tests"},
        ]
        result = queue_panel(items)
        text = _render(result)
        assert "RUNNING" in text
        assert "PENDING" in text
        assert "DONE" in text
        assert "FAILED" in text
        assert "Queue (4)" in text

    def test_max_five_items(self) -> None:
        items = [{"status": "PENDING", "goal": f"Task {i}"} for i in range(10)]
        result = queue_panel(items)
        text = _render(result)
        # Should only show first 5
        assert "Task 0" in text
        assert "Task 4" in text
        # Title should show total count
        assert "Queue (10)" in text

    def test_goal_truncation(self) -> None:
        long_goal = "X" * 100
        items = [{"status": "PENDING", "goal": long_goal}]
        result = queue_panel(items)
        text = _render(result)
        # Goal should be truncated to 50 chars
        assert "X" * 50 in text

    def test_missing_fields(self) -> None:
        items = [{}]
        result = queue_panel(items)
        text = _render(result)
        assert "?" in text
