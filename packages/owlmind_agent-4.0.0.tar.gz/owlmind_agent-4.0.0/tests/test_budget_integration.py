"""Integration tests for budget governor with CycleManager — NO network calls."""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from owlmind.agent.cycle import CycleManager
from owlmind.agent.schemas import CycleState
from owlmind.budget import BudgetGovernor
from owlmind.config import BudgetConfig, PricingConfig
from owlmind.evidence import EvidenceStore
from owlmind.ledger import UsageEntry, UsageLedger
from owlmind.policy import PolicyEngine


class FakeLLMDriverWithUsage:
    """Fake LLM driver that returns usage metadata."""

    def __init__(self, planner_response: dict[str, Any] | None = None) -> None:
        self._planner_response = planner_response or {}
        self.plan_calls: list[dict[str, Any]] = []

    @property
    def name(self) -> str:
        return "fake"

    @property
    def supports_structured(self) -> bool:
        return True

    def plan(
        self,
        planner_request: dict[str, Any],
        schema: dict[str, Any],
        **kwargs: Any,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        self.plan_calls.append(planner_request)
        meta = {
            "provider": "fake",
            "model": "gpt-4o-test",
            "response_id": "fake-resp",
            "latency_ms": 100,
            "usage": {"input_tokens": 500, "output_tokens": 200, "total_tokens": 700},
        }
        return self._planner_response, meta

    def judge(
        self,
        judge_request: dict[str, Any],
        schema: dict[str, Any],
        **kwargs: Any,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        return {}, {"provider": "fake", "model": "gpt-4o", "latency_ms": 50, "usage": {}}


def _make_setup(
    tmp_path: Path,
    *,
    max_tokens_per_run: int = 200_000,
    max_tokens_per_day: int = 500_000,
    planner_resp: dict[str, Any] | None = None,
) -> tuple[CycleManager, FakeLLMDriverWithUsage, UsageLedger]:
    policies_dir = tmp_path / "policies"
    policies_dir.mkdir()
    (policies_dir / "allowlist.yaml").write_text('allowed_commands:\n  - "^echo "\n  - "^pytest"\n')
    (policies_dir / "policy.yaml").write_text('forbidden_patterns:\n  - "rm -rf"\n')

    policy = PolicyEngine.from_directory(policies_dir)
    evidence = EvidenceStore(tmp_path / "runs")
    ledger = UsageLedger(tmp_path / "ledger")

    budget = BudgetConfig(
        max_tokens_per_run=max_tokens_per_run,
        max_tokens_per_day=max_tokens_per_day,
    )
    pricing = PricingConfig()
    governor = BudgetGovernor(budget, pricing, ledger)

    driver = FakeLLMDriverWithUsage(planner_response=planner_resp)

    mgr = CycleManager(
        evidence=evidence,
        policy=policy,
        policies_dir=policies_dir,
        llm_driver=driver,
        budget_governor=governor,
        ledger=ledger,
    )
    return mgr, driver, ledger


class TestBudgetIntegrationPlanner:
    def test_records_usage_in_ledger(self, tmp_path: Path) -> None:
        planner_resp = {
            "run_id": "x",
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        mgr, driver, ledger = _make_setup(tmp_path, planner_resp=planner_resp)

        meta = mgr.start(goal="Budget test", workspace=str(tmp_path))
        planner_resp["run_id"] = meta.run_id
        driver._planner_response = planner_resp

        mgr.run_planner_llm(meta.run_id)

        # Ledger should have one entry
        entries = ledger._read_all()
        assert len(entries) == 1
        assert entries[0].stage == "planner"
        assert entries[0].input_tokens == 500
        assert entries[0].output_tokens == 200

    def test_logs_budget_check_event(self, tmp_path: Path) -> None:
        planner_resp = {
            "run_id": "x",
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        mgr, driver, ledger = _make_setup(tmp_path, planner_resp=planner_resp)

        meta = mgr.start(goal="Event test", workspace=str(tmp_path))
        planner_resp["run_id"] = meta.run_id
        driver._planner_response = planner_resp

        mgr.run_planner_llm(meta.run_id)

        events = mgr.evidence.read_events(meta.run_id)
        budget_events = [e for e in events if e.get("event") == "BUDGET_CHECK"]
        assert len(budget_events) == 1
        assert budget_events[0]["allowed"] is True

        usage_events = [e for e in events if e.get("event") == "LLM_USAGE_RECORDED"]
        assert len(usage_events) == 1
        assert usage_events[0]["input_tokens"] == 500

    def test_blocks_when_run_limit_exceeded(self, tmp_path: Path) -> None:
        planner_resp = {
            "run_id": "x",
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        mgr, driver, ledger = _make_setup(
            tmp_path,
            planner_resp=planner_resp,
            max_tokens_per_run=500,
        )

        meta = mgr.start(goal="Block test", workspace=str(tmp_path))
        run_id = meta.run_id
        planner_resp["run_id"] = run_id
        driver._planner_response = planner_resp

        # Pre-fill ledger to exceed limit
        ledger.record(
            UsageEntry(
                ts=datetime.now(tz=UTC).isoformat(),
                run_id=run_id,
                stage="planner",
                provider="fake",
                model="gpt-4o",
                input_tokens=400,
                output_tokens=200,
                total_tokens=600,
                estimated_usd=0.003,
                latency_ms=100,
                price_per_1k_input=0.0025,
                price_per_1k_output=0.01,
            )
        )

        # Should create approval instead of calling LLM
        result_meta = mgr.run_planner_llm(run_id)

        # LLM should NOT have been called
        assert len(driver.plan_calls) == 0

        # State should be WAIT_APPROVAL
        assert result_meta.state == CycleState.WAIT_APPROVAL
        assert "BUDGET_OVERRIDE" in result_meta.extra.get("pending_approval", {}).get("reason", "")

    def test_blocks_daily_limit(self, tmp_path: Path) -> None:
        planner_resp = {
            "run_id": "x",
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        mgr, driver, ledger = _make_setup(
            tmp_path,
            planner_resp=planner_resp,
            max_tokens_per_day=1000,
        )

        # Pre-fill with entries from other runs
        for i in range(3):
            ledger.record(
                UsageEntry(
                    ts=datetime.now(tz=UTC).isoformat(),
                    run_id=f"run-{i}",
                    stage="planner",
                    provider="fake",
                    model="gpt-4o",
                    input_tokens=300,
                    output_tokens=150,
                    total_tokens=450,
                    estimated_usd=0.002,
                    latency_ms=100,
                    price_per_1k_input=0.0025,
                    price_per_1k_output=0.01,
                )
            )

        meta = mgr.start(goal="Daily block test", workspace=str(tmp_path))
        planner_resp["run_id"] = meta.run_id
        driver._planner_response = planner_resp

        result_meta = mgr.run_planner_llm(meta.run_id)

        assert len(driver.plan_calls) == 0
        assert result_meta.state == CycleState.WAIT_APPROVAL
