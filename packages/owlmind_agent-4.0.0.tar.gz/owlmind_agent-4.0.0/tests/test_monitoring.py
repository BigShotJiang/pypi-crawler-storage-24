"""Tests for owlmind.monitoring — metrics, structured logging, middleware, tracing."""

from __future__ import annotations

import json
import logging
import time
from io import StringIO
from typing import Any
from unittest.mock import patch

import pytest

# ---------------------------------------------------------------------------
# Metrics tests
# ---------------------------------------------------------------------------


class TestNoOpMetric:
    """Test the no-op metric stub used when prometheus_client is absent."""

    def test_inc(self) -> None:
        from owlmind.monitoring.metrics import _NoOpMetric

        m = _NoOpMetric()
        m.inc()
        m.inc(5)

    def test_dec(self) -> None:
        from owlmind.monitoring.metrics import _NoOpMetric

        m = _NoOpMetric()
        m.dec()
        m.dec(3)

    def test_set(self) -> None:
        from owlmind.monitoring.metrics import _NoOpMetric

        m = _NoOpMetric()
        m.set(42)

    def test_observe(self) -> None:
        from owlmind.monitoring.metrics import _NoOpMetric

        m = _NoOpMetric()
        m.observe(0.5)

    def test_labels_returns_self(self) -> None:
        from owlmind.monitoring.metrics import _NoOpMetric

        m = _NoOpMetric()
        labeled = m.labels(method="GET", endpoint="/foo")
        assert isinstance(labeled, _NoOpMetric)

    def test_time_context_manager(self) -> None:
        from owlmind.monitoring.metrics import _NoOpMetric

        m = _NoOpMetric()
        with m.time():
            pass


class TestSchedulerMetricsDataclass:
    """Test SchedulerMetrics defaults to no-ops."""

    def test_defaults_are_noop(self) -> None:
        from owlmind.monitoring.metrics import SchedulerMetrics

        sm = SchedulerMetrics()
        # Should not raise
        sm.tick_duration.observe(0.1)
        sm.goals_dispatched.inc()
        sm.goals_completed.inc()
        sm.goals_failed.inc()
        sm.goals_stale_reset.inc()
        sm.sessions_scanned.inc()
        sm.active_sessions.set(5)
        sm.tick_errors.inc()


class TestWorkerMetricsDataclass:
    """Test WorkerMetrics defaults to no-ops."""

    def test_defaults_are_noop(self) -> None:
        from owlmind.monitoring.metrics import WorkerMetrics

        wm = WorkerMetrics()
        wm.task_duration.observe(1.0)
        wm.tasks_picked.inc()
        wm.tasks_completed.inc()
        wm.tasks_failed.inc()
        wm.active_tasks.set(2)
        wm.ticks_total.inc()


class TestAPIMetricsDataclass:
    """Test APIMetrics defaults to no-ops."""

    def test_defaults_are_noop(self) -> None:
        from owlmind.monitoring.metrics import APIMetrics

        am = APIMetrics()
        am.requests_total.labels(method="GET", endpoint="/", status_code="200").inc()
        am.request_duration.labels(method="GET", endpoint="/").observe(0.01)
        am.requests_in_progress.inc()
        am.requests_in_progress.dec()


class TestTelegramMetricsDataclass:
    """Test TelegramMetrics defaults to no-ops."""

    def test_defaults_are_noop(self) -> None:
        from owlmind.monitoring.metrics import TelegramMetrics

        tm = TelegramMetrics()
        tm.commands_total.labels(command="help", status="ok").inc()
        tm.command_duration.labels(command="help").observe(0.05)
        tm.errors_total.labels(command="help").inc()

    def test_track_telegram_command_ok(self) -> None:
        from owlmind.monitoring.metrics import track_telegram_command

        with track_telegram_command("help"):
            pass  # should not raise

    def test_track_telegram_command_records_error(self) -> None:
        from owlmind.monitoring.metrics import track_telegram_command

        with pytest.raises(ValueError), track_telegram_command("help"):
            raise ValueError("test error")

    def test_track_telegram_command_reraises(self) -> None:
        from owlmind.monitoring.metrics import track_telegram_command

        raised = False
        try:
            with track_telegram_command("help"):
                raise RuntimeError("boom")
        except RuntimeError:
            raised = True
        assert raised


class TestIntegrationMetricsDataclass:
    """Test IntegrationMetrics defaults to no-ops."""

    def test_defaults_are_noop(self) -> None:
        from owlmind.monitoring.metrics import IntegrationMetrics

        im = IntegrationMetrics()
        im.requests_total.labels(integration="jira", operation="create_issue", status="ok").inc()
        im.request_duration.labels(integration="jira", operation="create_issue").observe(0.3)
        im.errors_total.labels(integration="jira", operation="create_issue").inc()

    def test_track_integration_request_ok(self) -> None:
        from owlmind.monitoring.metrics import track_integration_request

        with track_integration_request("jira", "create_issue"):
            pass  # should not raise

    def test_track_integration_request_reraises(self) -> None:
        from owlmind.monitoring.metrics import track_integration_request

        raised = False
        try:
            with track_integration_request("trello", "create_issue"):
                raise ConnectionError("timeout")
        except ConnectionError:
            raised = True
        assert raised


class TestSetupMetrics:
    """Test setup_metrics() with real prometheus_client (if installed)."""

    def test_setup_idempotent(self) -> None:
        from owlmind.monitoring.metrics import reset_metrics, setup_metrics

        reset_metrics()
        try:
            from prometheus_client import CollectorRegistry

            reg = CollectorRegistry()
            setup_metrics(registry=reg)
            setup_metrics(registry=reg)  # second call is no-op
        except ImportError:
            setup_metrics()
            setup_metrics()
        finally:
            reset_metrics()

    def test_reset_restores_noops(self) -> None:
        from owlmind.monitoring.metrics import (
            _NoOpMetric,
            reset_metrics,
            scheduler_metrics,
            setup_metrics,
        )

        reset_metrics()
        try:
            from prometheus_client import CollectorRegistry

            reg = CollectorRegistry()
            setup_metrics(registry=reg)
            # After setup, metrics should be real (not noop)
            assert not isinstance(scheduler_metrics.tick_duration, _NoOpMetric)
        except ImportError:
            setup_metrics()
            assert isinstance(scheduler_metrics.tick_duration, _NoOpMetric)
        finally:
            reset_metrics()
            # After reset, should be noop again
            assert isinstance(scheduler_metrics.tick_duration, _NoOpMetric)

    def test_setup_creates_real_metrics(self) -> None:
        """If prometheus_client is installed, real metrics are created."""
        from owlmind.monitoring.metrics import (
            HAS_PROMETHEUS,
            _NoOpMetric,
            reset_metrics,
            scheduler_metrics,
            setup_metrics,
            worker_metrics,
        )

        reset_metrics()
        if not HAS_PROMETHEUS:
            pytest.skip("prometheus_client not installed")
        try:
            from prometheus_client import CollectorRegistry

            reg = CollectorRegistry()
            setup_metrics(registry=reg)
            assert not isinstance(scheduler_metrics.goals_dispatched, _NoOpMetric)
            assert not isinstance(worker_metrics.tasks_picked, _NoOpMetric)
        finally:
            reset_metrics()


class TestTrackTime:
    """Test the track_time context manager."""

    def test_track_time_observes_duration(self) -> None:
        from owlmind.monitoring.metrics import track_time

        observed: list[float] = []

        class FakeHistogram:
            def observe(self, val: float) -> None:
                observed.append(val)

        with track_time(FakeHistogram()):
            time.sleep(0.01)

        assert len(observed) == 1
        assert observed[0] >= 0.01

    def test_track_time_with_noop(self) -> None:
        from owlmind.monitoring.metrics import _NoOpMetric, track_time

        with track_time(_NoOpMetric()):
            pass  # should not raise


class TestGetMetricsText:
    """Test Prometheus text exposition."""

    def test_returns_string(self) -> None:
        from owlmind.monitoring.metrics import get_metrics_text, reset_metrics

        reset_metrics()
        text = get_metrics_text()
        assert isinstance(text, str)

    def test_with_custom_registry(self) -> None:
        from owlmind.monitoring.metrics import (
            HAS_PROMETHEUS,
            get_metrics_text,
            reset_metrics,
            setup_metrics,
        )

        reset_metrics()
        if not HAS_PROMETHEUS:
            pytest.skip("prometheus_client not installed")

        from prometheus_client import CollectorRegistry

        reg = CollectorRegistry()
        setup_metrics(registry=reg)
        try:
            text = get_metrics_text(registry=reg)
            assert "owlmind_scheduler" in text
            assert "owlmind_worker" in text
        finally:
            reset_metrics()


# ---------------------------------------------------------------------------
# Structured logging tests
# ---------------------------------------------------------------------------


class TestStructuredLogging:
    """Test configure_structured_logging and get_logger."""

    def test_configure_fallback_no_structlog(self) -> None:
        """When structlog is missing, falls back to setup_logging()."""
        from owlmind.monitoring.structured_log import configure_structured_logging

        buf = StringIO()
        with patch("owlmind.monitoring.structured_log.HAS_STRUCTLOG", False):
            configure_structured_logging(level="DEBUG", json_format=True, stream=buf)

        root = logging.getLogger("owlmind")
        assert root.level == logging.DEBUG
        assert len(root.handlers) >= 1

    def test_configure_with_text_format(self) -> None:
        from owlmind.monitoring.structured_log import configure_structured_logging

        buf = StringIO()
        with patch("owlmind.monitoring.structured_log.HAS_STRUCTLOG", False):
            configure_structured_logging(level="WARNING", json_format=False, stream=buf)

        root = logging.getLogger("owlmind")
        assert root.level == logging.WARNING

    def test_get_logger_without_structlog(self) -> None:
        from owlmind.monitoring.structured_log import get_logger

        with patch("owlmind.monitoring.structured_log.HAS_STRUCTLOG", False):
            lg = get_logger("owlmind.test")
            assert isinstance(lg, logging.Logger)

    def test_get_logger_with_structlog(self) -> None:
        """If structlog is available, get_logger returns a structlog logger."""
        try:
            import structlog  # noqa: F401
        except ImportError:
            pytest.skip("structlog not installed")

        from owlmind.monitoring.structured_log import get_logger

        lg = get_logger("owlmind.test")
        # structlog loggers have a bind() method
        assert hasattr(lg, "bind")


class TestStructuredLoggingWithStructlog:
    """Test structured logging when structlog IS installed."""

    def test_configure_structlog_json(self) -> None:
        try:
            import structlog  # noqa: F401
        except ImportError:
            pytest.skip("structlog not installed")

        from owlmind.monitoring.structured_log import configure_structured_logging

        buf = StringIO()
        configure_structured_logging(level="INFO", json_format=True, stream=buf)

        root = logging.getLogger("owlmind")
        assert root.level == logging.INFO
        assert len(root.handlers) >= 1

    def test_configure_structlog_console(self) -> None:
        try:
            import structlog  # noqa: F401
        except ImportError:
            pytest.skip("structlog not installed")

        from owlmind.monitoring.structured_log import configure_structured_logging

        buf = StringIO()
        configure_structured_logging(level="DEBUG", json_format=False, stream=buf)

        root = logging.getLogger("owlmind")
        assert root.level == logging.DEBUG


# ---------------------------------------------------------------------------
# Middleware tests
# ---------------------------------------------------------------------------


class TestNormalizePath:
    """Test path normalization for label cardinality control."""

    def test_static_path_unchanged(self) -> None:
        from owlmind.monitoring.middleware import _normalize_path

        assert _normalize_path("/api/v1/health") == "/api/v1/health"

    def test_run_id_collapsed(self) -> None:
        from owlmind.monitoring.middleware import _normalize_path

        result = _normalize_path("/api/v1/runs/run-abc123def456")
        assert result == "/api/v1/runs/{id}"

    def test_session_id_collapsed(self) -> None:
        from owlmind.monitoring.middleware import _normalize_path

        result = _normalize_path("/api/v1/sessions/sess-abc123/goals")
        assert result == "/api/v1/sessions/{id}/goals"

    def test_long_hex_collapsed(self) -> None:
        from owlmind.monitoring.middleware import _normalize_path

        result = _normalize_path("/api/v1/items/abcdef1234567890abcd")
        assert "{id}" in result

    def test_short_path_unchanged(self) -> None:
        from owlmind.monitoring.middleware import _normalize_path

        assert _normalize_path("/metrics") == "/metrics"


class TestIsVariableSegment:
    """Test heuristic for ID detection."""

    def test_empty_segment(self) -> None:
        from owlmind.monitoring.middleware import _is_variable_segment

        assert not _is_variable_segment("")

    def test_run_prefix(self) -> None:
        from owlmind.monitoring.middleware import _is_variable_segment

        assert _is_variable_segment("run-abc123")

    def test_session_prefix(self) -> None:
        from owlmind.monitoring.middleware import _is_variable_segment

        assert _is_variable_segment("sess-xyz")

    def test_long_string(self) -> None:
        from owlmind.monitoring.middleware import _is_variable_segment

        assert _is_variable_segment("a" * 25)

    def test_short_word(self) -> None:
        from owlmind.monitoring.middleware import _is_variable_segment

        assert not _is_variable_segment("health")

    def test_pure_digits(self) -> None:
        from owlmind.monitoring.middleware import _is_variable_segment

        assert _is_variable_segment("123456789")


class TestMetricsMiddleware:
    """Test add_metrics_middleware integration with FastAPI."""

    def test_adds_metrics_endpoint(self) -> None:
        from owlmind.monitoring.metrics import reset_metrics
        from owlmind.monitoring.middleware import add_metrics_middleware

        reset_metrics()
        try:
            from fastapi import FastAPI

            app = FastAPI()
            add_metrics_middleware(app)

            routes = [r.path for r in app.routes]
            assert "/metrics" in routes
        except ImportError:
            pytest.skip("fastapi not installed")
        finally:
            reset_metrics()

    @pytest.mark.asyncio
    async def test_metrics_endpoint_returns_text(self) -> None:
        from owlmind.monitoring.metrics import HAS_PROMETHEUS, reset_metrics
        from owlmind.monitoring.middleware import add_metrics_middleware

        reset_metrics()
        try:
            from fastapi import FastAPI
            from fastapi.testclient import TestClient

            if not HAS_PROMETHEUS:
                from prometheus_client import CollectorRegistry

                reg = CollectorRegistry()
            else:
                from prometheus_client import CollectorRegistry

                reg = CollectorRegistry()

            app = FastAPI()
            add_metrics_middleware(app, registry=reg)

            client = TestClient(app)
            resp = client.get("/metrics")
            assert resp.status_code == 200
            assert "text/plain" in resp.headers["content-type"]
        except ImportError:
            pytest.skip("fastapi or prometheus_client not installed")
        finally:
            reset_metrics()


# ---------------------------------------------------------------------------
# Tracing tests
# ---------------------------------------------------------------------------


class TestTracingNoOps:
    """Test tracing no-op stubs."""

    def test_noop_span(self) -> None:
        from owlmind.monitoring.tracing import _NoOpSpan

        span = _NoOpSpan()
        span.set_attribute("key", "value")
        span.set_status(None)
        span.record_exception(RuntimeError("test"))
        span.end()

    def test_noop_span_context_manager(self) -> None:
        from owlmind.monitoring.tracing import _NoOpSpan

        with _NoOpSpan() as span:
            span.set_attribute("key", "value")

    def test_noop_tracer_start_as_current_span(self) -> None:
        from owlmind.monitoring.tracing import _NoOpTracer

        tracer = _NoOpTracer()
        with tracer.start_as_current_span("test_op") as span:
            span.set_attribute("key", "value")

    def test_noop_tracer_start_span(self) -> None:
        from owlmind.monitoring.tracing import _NoOpTracer

        tracer = _NoOpTracer()
        span = tracer.start_span("test_op")
        span.set_attribute("key", "value")
        span.end()


class TestGetTracer:
    """Test get_tracer returns appropriate tracer type."""

    def test_returns_noop_when_otel_absent(self) -> None:
        from owlmind.monitoring.tracing import _NoOpTracer, get_tracer

        with patch("owlmind.monitoring.tracing.HAS_OTEL", False):
            tracer = get_tracer("test")
            assert isinstance(tracer, _NoOpTracer)

    def test_get_tracer_works(self) -> None:
        from owlmind.monitoring.tracing import get_tracer

        tracer = get_tracer("owlmind.test")
        # Should work regardless of OTel availability
        with tracer.start_as_current_span("test_span") as span:
            span.set_attribute("test", True)


class TestSetupTracing:
    """Test setup_tracing function."""

    def test_setup_returns_false_when_otel_absent(self) -> None:
        from owlmind.monitoring.tracing import reset_tracing, setup_tracing

        reset_tracing()
        with patch("owlmind.monitoring.tracing.HAS_OTEL", False):
            result = setup_tracing(service_name="test")
            assert result is False

    def test_setup_idempotent(self) -> None:
        from owlmind.monitoring.tracing import reset_tracing, setup_tracing

        reset_tracing()
        with patch("owlmind.monitoring.tracing.HAS_OTEL", False):
            setup_tracing()
            setup_tracing()  # second call is no-op

    def test_reset_tracing(self) -> None:
        from owlmind.monitoring.tracing import reset_tracing

        reset_tracing()  # should not raise


# ---------------------------------------------------------------------------
# Package import tests
# ---------------------------------------------------------------------------


class TestPackageImports:
    """Test that the monitoring package imports correctly."""

    def test_import_monitoring(self) -> None:
        import owlmind.monitoring

        assert hasattr(owlmind.monitoring, "setup_metrics")
        assert hasattr(owlmind.monitoring, "scheduler_metrics")
        assert hasattr(owlmind.monitoring, "worker_metrics")
        assert hasattr(owlmind.monitoring, "api_metrics")
        assert hasattr(owlmind.monitoring, "telegram_metrics")
        assert hasattr(owlmind.monitoring, "integration_metrics")
        assert hasattr(owlmind.monitoring, "configure_structured_logging")
        assert hasattr(owlmind.monitoring, "HAS_PROMETHEUS")

    def test_import_metrics(self) -> None:
        from owlmind.monitoring.metrics import (
            get_metrics_text,
            reset_metrics,
            setup_metrics,
            track_time,
        )

        assert callable(setup_metrics)
        assert callable(reset_metrics)
        assert callable(get_metrics_text)
        assert callable(track_time)

    def test_import_structured_log(self) -> None:
        from owlmind.monitoring.structured_log import (
            configure_structured_logging,
            get_logger,
        )

        assert callable(configure_structured_logging)
        assert callable(get_logger)

    def test_import_tracing(self) -> None:
        from owlmind.monitoring.tracing import (
            get_tracer,
            reset_tracing,
            setup_tracing,
        )

        assert callable(setup_tracing)
        assert callable(get_tracer)
        assert callable(reset_tracing)

    def test_import_middleware(self) -> None:
        from owlmind.monitoring.middleware import add_metrics_middleware

        assert callable(add_metrics_middleware)


# ---------------------------------------------------------------------------
# Integration: Scheduler with metrics
# ---------------------------------------------------------------------------


class TestSchedulerMetricsIntegration:
    """Test that scheduler.py imports and uses monitoring metrics."""

    def test_scheduler_imports_metrics(self) -> None:
        """Scheduler module should import monitoring metrics."""
        import owlmind.scheduler as sched_mod

        # The import should work without error
        assert hasattr(sched_mod, "scheduler_metrics")

    def test_scheduler_has_track_time(self) -> None:
        import owlmind.scheduler as sched_mod

        assert hasattr(sched_mod, "track_time")


# ---------------------------------------------------------------------------
# Integration: Worker with metrics
# ---------------------------------------------------------------------------


class TestWorkerMetricsIntegration:
    """Test that worker.py imports and uses monitoring metrics."""

    def test_worker_imports_metrics(self) -> None:
        import owlmind.worker.worker as worker_mod

        assert hasattr(worker_mod, "worker_metrics")

    def test_worker_uses_monitoring(self) -> None:
        """Worker module imports from owlmind.monitoring.metrics."""
        import owlmind.worker.worker as worker_mod

        # worker_metrics is imported at module level
        assert worker_mod.worker_metrics is not None


# ---------------------------------------------------------------------------
# Integration: API app with middleware
# ---------------------------------------------------------------------------


class TestAPIMetricsIntegration:
    """Test that API app includes metrics middleware."""

    def test_app_has_metrics_endpoint(self) -> None:
        try:
            from owlmind.monitoring.metrics import reset_metrics

            reset_metrics()
            from owlmind.api.app import create_app

            app = create_app()
            routes = [r.path for r in app.routes]
            assert "/metrics" in routes
        except ImportError:
            pytest.skip("fastapi not installed")
        finally:
            from owlmind.monitoring.metrics import reset_metrics

            reset_metrics()


# ---------------------------------------------------------------------------
# Grafana dashboard validation
# ---------------------------------------------------------------------------


class TestGrafanaDashboard:
    """Validate Grafana dashboard JSON structure."""

    def _load_dashboard(self) -> dict[str, Any]:
        from pathlib import Path

        dashboard_path = Path(__file__).parent.parent / "grafana" / "owlmind-dashboard.json"
        with dashboard_path.open() as f:
            return json.load(f)

    def test_dashboard_is_valid_json(self) -> None:
        dashboard = self._load_dashboard()
        assert isinstance(dashboard, dict)

    def test_dashboard_has_title(self) -> None:
        dashboard = self._load_dashboard()
        assert "title" in dashboard
        assert "OWLMIND" in dashboard["title"]

    def test_dashboard_has_panels(self) -> None:
        dashboard = self._load_dashboard()
        assert "panels" in dashboard
        assert len(dashboard["panels"]) > 10

    def test_dashboard_has_scheduler_panels(self) -> None:
        dashboard = self._load_dashboard()
        titles = [p.get("title", "") for p in dashboard["panels"]]
        assert any("Scheduler" in t for t in titles)

    def test_dashboard_has_worker_panels(self) -> None:
        dashboard = self._load_dashboard()
        titles = [p.get("title", "") for p in dashboard["panels"]]
        assert any("Worker" in t for t in titles)

    def test_dashboard_has_api_panels(self) -> None:
        dashboard = self._load_dashboard()
        titles = [p.get("title", "") for p in dashboard["panels"]]
        assert any("API" in t or "Request" in t for t in titles)

    def test_dashboard_has_telegram_panels(self) -> None:
        dashboard = self._load_dashboard()
        titles = [p.get("title", "") for p in dashboard["panels"]]
        assert any("Telegram" in t for t in titles)

    def test_dashboard_has_integration_panels(self) -> None:
        dashboard = self._load_dashboard()
        titles = [p.get("title", "") for p in dashboard["panels"]]
        assert any("Integration" in t for t in titles)

    def test_dashboard_telegram_uses_prometheus_queries(self) -> None:
        dashboard = self._load_dashboard()
        all_exprs: list[str] = []
        for panel in dashboard["panels"]:
            for target in panel.get("targets", []):
                expr = target.get("expr", "")
                if expr:
                    all_exprs.append(expr)
        assert any("owlmind_telegram" in e for e in all_exprs)
        assert any("owlmind_integration" in e for e in all_exprs)

    def test_dashboard_uses_prometheus_queries(self) -> None:
        dashboard = self._load_dashboard()
        all_exprs: list[str] = []
        for panel in dashboard["panels"]:
            for target in panel.get("targets", []):
                expr = target.get("expr", "")
                if expr:
                    all_exprs.append(expr)
        assert any("owlmind_scheduler" in e for e in all_exprs)
        assert any("owlmind_worker" in e for e in all_exprs)
        assert any("owlmind_api" in e for e in all_exprs)

    def test_dashboard_has_uid(self) -> None:
        dashboard = self._load_dashboard()
        assert dashboard.get("uid") == "owlmind-overview"

    def test_dashboard_has_auto_refresh(self) -> None:
        dashboard = self._load_dashboard()
        assert "refresh" in dashboard
