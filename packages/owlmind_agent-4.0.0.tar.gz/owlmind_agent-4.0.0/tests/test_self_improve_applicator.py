"""Tests for owlmind.self_improve.applicator module.

Covers _apply_patch (dry-run + real), _apply_advisory, apply_batch,
and rejection of non-approved improvements.
"""

from __future__ import annotations

import subprocess
from unittest.mock import MagicMock, patch

from owlmind.self_improve.applicator import (
    ApplyResult,
    apply_batch,
    apply_improvement,
)
from owlmind.self_improve.models import Improvement, ImprovementStatus

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _imp(
    *,
    status: str = ImprovementStatus.APPROVED,
    patch: str = "",
    target_file: str = "",
    title: str = "Test improvement",
    description: str = "Test description",
) -> Improvement:
    return Improvement(
        improvement_id="imp-001",
        title=title,
        description=description,
        status=status,
        patch=patch,
        target_file=target_file,
    )


# ---------------------------------------------------------------------------
# TestApplyImprovementGuard — status checks
# ---------------------------------------------------------------------------


class TestApplyImprovementGuard:
    def test_rejects_proposed_status(self, tmp_path):
        imp = _imp(status=ImprovementStatus.PROPOSED)
        result = apply_improvement(imp, tmp_path)
        assert not result.success
        assert "Cannot apply" in result.message
        assert result.improvement_id == "imp-001"

    def test_rejects_rejected_status(self, tmp_path):
        imp = _imp(status=ImprovementStatus.REJECTED)
        result = apply_improvement(imp, tmp_path)
        assert not result.success

    def test_rejects_applied_status(self, tmp_path):
        imp = _imp(status=ImprovementStatus.APPLIED)
        result = apply_improvement(imp, tmp_path)
        assert not result.success

    def test_allows_approved_status(self, tmp_path):
        """Approved improvement with no patch/target returns specific failure."""
        imp = _imp(status=ImprovementStatus.APPROVED)
        result = apply_improvement(imp, tmp_path)
        # No patch and no target_file → "No patch or target file"
        assert not result.success
        assert "No patch or target file" in result.message

    def test_allows_testing_status(self, tmp_path):
        """TESTING status is also allowed to be applied."""
        imp = _imp(status=ImprovementStatus.TESTING)
        result = apply_improvement(imp, tmp_path)
        assert "No patch or target file" in result.message

    def test_no_patch_no_target_returns_failure(self, tmp_path):
        imp = _imp()
        result = apply_improvement(imp, tmp_path)
        assert not result.success
        assert result.dry_run is False


# ---------------------------------------------------------------------------
# TestApplyPatch — _apply_patch via subprocess mock
# ---------------------------------------------------------------------------


class TestApplyPatch:
    PATCH_TEXT = """\
--- a/src/foo.py
+++ b/src/foo.py
@@ -1 +1 @@
-old
+new
"""

    def test_dry_run_success(self, tmp_path):
        imp = _imp(patch=self.PATCH_TEXT, target_file="src/foo.py")
        mock_result = MagicMock(returncode=0, stdout="dry run ok", stderr="")
        with patch("subprocess.run", return_value=mock_result):
            result = apply_improvement(imp, tmp_path, dry_run=True)

        assert result.success
        assert result.dry_run is True
        assert result.message == "dry run ok"
        assert "src/foo.py" in result.files_modified

    def test_dry_run_failure(self, tmp_path):
        imp = _imp(patch=self.PATCH_TEXT, target_file="src/foo.py")
        mock_result = MagicMock(returncode=1, stdout="", stderr="hunk failed")
        with patch("subprocess.run", return_value=mock_result):
            result = apply_improvement(imp, tmp_path, dry_run=True)

        assert not result.success
        assert result.dry_run is True
        assert "hunk failed" in result.message

    def test_dry_run_timeout(self, tmp_path):
        imp = _imp(patch=self.PATCH_TEXT)
        with patch("subprocess.run", side_effect=subprocess.TimeoutExpired("patch", 30)):
            result = apply_improvement(imp, tmp_path, dry_run=True)

        assert not result.success
        assert result.dry_run is True
        assert "validation failed" in result.message.lower()

    def test_dry_run_file_not_found(self, tmp_path):
        imp = _imp(patch=self.PATCH_TEXT)
        with patch("subprocess.run", side_effect=FileNotFoundError("patch not found")):
            result = apply_improvement(imp, tmp_path, dry_run=True)

        assert not result.success
        assert "validation failed" in result.message.lower()

    def test_real_apply_success(self, tmp_path):
        imp = _imp(patch=self.PATCH_TEXT, target_file="src/foo.py")
        mock_result = MagicMock(returncode=0, stdout="patching file src/foo.py", stderr="")
        with patch("subprocess.run", return_value=mock_result):
            result = apply_improvement(imp, tmp_path)

        assert result.success
        assert result.dry_run is False
        assert "src/foo.py" in result.files_modified

    def test_real_apply_failure(self, tmp_path):
        imp = _imp(patch=self.PATCH_TEXT, target_file="src/foo.py")
        mock_result = MagicMock(returncode=1, stdout="", stderr="patch failed")
        with patch("subprocess.run", return_value=mock_result):
            result = apply_improvement(imp, tmp_path)

        assert not result.success
        assert "patch failed" in result.message

    def test_real_apply_timeout(self, tmp_path):
        imp = _imp(patch=self.PATCH_TEXT)
        with patch("subprocess.run", side_effect=subprocess.TimeoutExpired("patch", 30)):
            result = apply_improvement(imp, tmp_path)

        assert not result.success
        assert "application failed" in result.message.lower()

    def test_subprocess_called_with_correct_args_dry_run(self, tmp_path):
        imp = _imp(patch=self.PATCH_TEXT)
        mock_result = MagicMock(returncode=0, stdout="ok", stderr="")
        with patch("subprocess.run", return_value=mock_result) as mock_sp:
            apply_improvement(imp, tmp_path, dry_run=True)

        args = mock_sp.call_args[0][0]
        assert "patch" in args
        assert "--dry-run" in args
        assert "-p1" in args

    def test_subprocess_called_with_correct_args_real(self, tmp_path):
        imp = _imp(patch=self.PATCH_TEXT)
        mock_result = MagicMock(returncode=0, stdout="ok", stderr="")
        with patch("subprocess.run", return_value=mock_result) as mock_sp:
            apply_improvement(imp, tmp_path)

        args = mock_sp.call_args[0][0]
        assert "patch" in args
        assert "--dry-run" not in args


# ---------------------------------------------------------------------------
# TestApplyAdvisory — _apply_advisory via target_file without patch
# ---------------------------------------------------------------------------


class TestApplyAdvisory:
    def test_dry_run_returns_success_without_writing(self, tmp_path):
        imp = _imp(target_file="docs/notes.md", title="Improve docs")
        result = apply_improvement(imp, tmp_path, dry_run=True)

        assert result.success
        assert result.dry_run is True
        assert "Would append" in result.message
        assert "docs/notes.md" in result.files_modified
        # File should NOT be created in dry-run mode
        assert not (tmp_path / "docs/notes.md").exists()

    def test_real_apply_creates_and_appends_to_file(self, tmp_path):
        imp = _imp(target_file="docs/notes.md", title="Add docs", description="Add better docs")
        result = apply_improvement(imp, tmp_path)

        assert result.success
        assert result.dry_run is False
        target = tmp_path / "docs/notes.md"
        assert target.exists()
        content = target.read_text()
        assert "Add docs" in content
        assert "Add better docs" in content

    def test_real_apply_appends_to_existing_file(self, tmp_path):
        target = tmp_path / "notes.md"
        target.write_text("# Existing content\n")
        imp = _imp(target_file="notes.md", title="Addition")
        apply_improvement(imp, tmp_path)

        content = target.read_text()
        assert "# Existing content" in content
        assert "Addition" in content

    def test_real_apply_creates_parent_dirs(self, tmp_path):
        imp = _imp(target_file="deep/nested/dir/file.md")
        result = apply_improvement(imp, tmp_path)

        assert result.success
        assert (tmp_path / "deep/nested/dir/file.md").exists()

    def test_real_apply_oserror(self, tmp_path):
        imp = _imp(target_file="notes.md", title="Fail")
        with patch("pathlib.Path.open", side_effect=OSError("permission denied")):
            result = apply_improvement(imp, tmp_path)

        assert not result.success
        assert "Failed to write" in result.message


# ---------------------------------------------------------------------------
# TestApplyBatch
# ---------------------------------------------------------------------------


class TestApplyBatch:
    def test_empty_list_returns_empty(self, tmp_path):
        results = apply_batch([], tmp_path)
        assert results == []

    def test_all_succeed(self, tmp_path):
        imps = [_imp(target_file=f"file{i}.md", title=f"Imp {i}") for i in range(3)]
        results = apply_batch(imps, tmp_path)
        assert len(results) == 3
        assert all(r.success for r in results)

    def test_stop_on_failure_true(self, tmp_path):
        """stop_on_failure=True (default) stops after first non-dry-run failure."""
        mock_result = MagicMock(returncode=1, stdout="", stderr="fail")
        failing_patch = "--- a\n+++ b\n@@ -1 +1 @@\n-x\n+y\n"
        imps = [
            _imp(status=ImprovementStatus.APPROVED, patch=failing_patch),
            _imp(status=ImprovementStatus.APPROVED, patch=failing_patch),
            _imp(status=ImprovementStatus.APPROVED, patch=failing_patch),
        ]
        with patch("subprocess.run", return_value=mock_result):
            results = apply_batch(imps, tmp_path, stop_on_failure=True)

        # Should stop after first failure
        assert len(results) == 1
        assert not results[0].success

    def test_stop_on_failure_false_continues(self, tmp_path):
        """stop_on_failure=False continues despite failures."""
        mock_result = MagicMock(returncode=1, stdout="", stderr="fail")
        failing_patch = "--- a\n+++ b\n@@ -1 +1 @@\n-x\n+y\n"
        imps = [_imp(patch=failing_patch) for _ in range(3)]
        with patch("subprocess.run", return_value=mock_result):
            results = apply_batch(imps, tmp_path, stop_on_failure=False)

        assert len(results) == 3

    def test_dry_run_does_not_stop_on_failure(self, tmp_path):
        """In dry_run mode stop_on_failure is skipped (dry_run guard)."""
        mock_result = MagicMock(returncode=1, stdout="", stderr="dry fail")
        failing_patch = "--- a\n+++ b\n@@ -1 +1 @@\n-x\n+y\n"
        imps = [_imp(patch=failing_patch) for _ in range(3)]
        with patch("subprocess.run", return_value=mock_result):
            results = apply_batch(imps, tmp_path, dry_run=True, stop_on_failure=True)

        # dry_run=True → stop_on_failure branch is skipped (guarded by `not dry_run`)
        assert len(results) == 3

    def test_returns_apply_result_instances(self, tmp_path):
        imp = _imp(target_file="f.md")
        results = apply_batch([imp], tmp_path)
        assert isinstance(results[0], ApplyResult)
        assert results[0].improvement_id == "imp-001"
