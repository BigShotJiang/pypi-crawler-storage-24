"""Tests for webhook event delivery."""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field

import pytest

from owlmind.webhook import (
    RELAYED_EVENTS,
    WebhookConfig,
    WebhookNotifier,
    build_payload,
    sign_payload_hmac,
)

# ── Fake HTTP client ──


@dataclass
class FakeHttpClient:
    """Captures requests for test assertions."""

    requests: list[dict[str, object]] = field(default_factory=list)
    response_status: int = 200
    fail_count: int = 0
    _call_count: int = 0

    def post(self, url: str, body: bytes, headers: dict[str, str], timeout: int) -> int:
        self._call_count += 1
        self.requests.append(
            {
                "url": url,
                "body": body,
                "headers": headers,
                "timeout": timeout,
            }
        )
        if self._call_count <= self.fail_count:
            raise ConnectionError("fake connection error")
        return self.response_status


@pytest.fixture()
def webhook_config() -> WebhookConfig:
    return WebhookConfig(
        enabled=True,
        url="https://hooks.example.com/owlmind",
        secret="test-secret-key",
        timeout_sec=5,
        max_retries=3,
        backoff_base=0.01,  # fast for tests
    )


@pytest.fixture()
def fake_client() -> FakeHttpClient:
    return FakeHttpClient()


# ── WebhookConfig ──


class TestWebhookConfig:
    def test_hostname_extracted(self) -> None:
        cfg = WebhookConfig(url="https://hooks.slack.com/services/T00/B00/xxx")
        assert cfg.hostname == "hooks.slack.com"

    def test_hostname_empty(self) -> None:
        cfg = WebhookConfig(url="")
        assert cfg.hostname == ""

    def test_domain_allowed_no_allowlist(self) -> None:
        cfg = WebhookConfig(url="https://any.domain.com/hook")
        assert cfg.is_domain_allowed() is True

    def test_domain_allowed_in_list(self) -> None:
        cfg = WebhookConfig(
            url="https://hooks.slack.com/x",
            allowlist_domains=["hooks.slack.com", "github.com"],
        )
        assert cfg.is_domain_allowed() is True

    def test_domain_blocked(self) -> None:
        cfg = WebhookConfig(
            url="https://evil.com/steal",
            allowlist_domains=["hooks.slack.com"],
        )
        assert cfg.is_domain_allowed() is False


# ── Payload building ──


class TestBuildPayload:
    def test_payload_structure(self) -> None:
        payload = build_payload("run_started", {"run_id": "r-001", "goal": "Fix bug"})
        assert payload["event"] == "run_started"
        assert "timestamp" in payload
        assert payload["data"]["run_id"] == "r-001"

    def test_secrets_redacted(self) -> None:
        payload = build_payload(
            "run_started",
            {
                "info": "key is sk-AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
            },
        )
        assert "sk-" not in json.dumps(payload)

    def test_nested_dict_redacted(self) -> None:
        payload = build_payload(
            "run_started",
            {
                "meta": {"token": "token=ghp_AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"},
            },
        )
        assert "ghp_" not in json.dumps(payload)


# ── HMAC signing ──


class TestSignPayload:
    def test_signature_deterministic(self) -> None:
        data = b'{"event": "test"}'
        sig1 = sign_payload_hmac(data, "secret")
        sig2 = sign_payload_hmac(data, "secret")
        assert sig1 == sig2

    def test_signature_changes_with_secret(self) -> None:
        data = b'{"event": "test"}'
        sig1 = sign_payload_hmac(data, "secret1")
        sig2 = sign_payload_hmac(data, "secret2")
        assert sig1 != sig2

    def test_signature_is_hex(self) -> None:
        sig = sign_payload_hmac(b"data", "key")
        assert all(c in "0123456789abcdef" for c in sig)
        assert len(sig) == 64  # SHA256 hex


# ── WebhookNotifier ──


class TestWebhookNotifier:
    def test_send_success(self, webhook_config: WebhookConfig, fake_client: FakeHttpClient) -> None:
        notifier = WebhookNotifier(config=webhook_config, http_client=fake_client)
        result = notifier.send_event("run_started", {"run_id": "r-001"})
        assert result["sent"] is True
        assert result["status"] == 200
        assert len(fake_client.requests) == 1

    def test_disabled_webhook(self, fake_client: FakeHttpClient) -> None:
        cfg = WebhookConfig(enabled=False, url="https://x.com")
        notifier = WebhookNotifier(config=cfg, http_client=fake_client)
        result = notifier.send_event("run_started", {"run_id": "r-001"})
        assert result["sent"] is False
        assert "disabled" in result["reason"]

    def test_no_url(self, fake_client: FakeHttpClient) -> None:
        cfg = WebhookConfig(enabled=True, url="")
        notifier = WebhookNotifier(config=cfg, http_client=fake_client)
        result = notifier.send_event("run_started", {})
        assert result["sent"] is False

    def test_non_relayed_event(
        self, webhook_config: WebhookConfig, fake_client: FakeHttpClient
    ) -> None:
        notifier = WebhookNotifier(config=webhook_config, http_client=fake_client)
        result = notifier.send_event("some_internal_event", {})
        assert result["sent"] is False
        assert "not relayed" in result["reason"]

    def test_domain_not_allowed(self, fake_client: FakeHttpClient) -> None:
        cfg = WebhookConfig(
            enabled=True,
            url="https://evil.com/hook",
            allowlist_domains=["hooks.slack.com"],
        )
        notifier = WebhookNotifier(config=cfg, http_client=fake_client)
        result = notifier.send_event("run_started", {})
        assert result["sent"] is False
        assert "allowlist" in result["reason"]

    def test_hmac_header_present(
        self, webhook_config: WebhookConfig, fake_client: FakeHttpClient
    ) -> None:
        notifier = WebhookNotifier(config=webhook_config, http_client=fake_client)
        notifier.send_event("run_started", {"run_id": "r-001"})
        headers = fake_client.requests[0]["headers"]
        assert "X-OwlMind-Signature" in headers
        assert headers["X-OwlMind-Signature"].startswith("sha256=")

    def test_no_hmac_without_secret(self, fake_client: FakeHttpClient) -> None:
        cfg = WebhookConfig(enabled=True, url="https://x.com", secret="")
        notifier = WebhookNotifier(config=cfg, http_client=fake_client)
        notifier.send_event("run_started", {"run_id": "r-001"})
        headers = fake_client.requests[0]["headers"]
        assert "X-OwlMind-Signature" not in headers

    def test_retry_on_failure(self, webhook_config: WebhookConfig) -> None:
        client = FakeHttpClient(fail_count=2)  # first 2 fail, 3rd succeeds
        webhook_config.backoff_base = 0.001
        notifier = WebhookNotifier(config=webhook_config, http_client=client)
        result = notifier.send_event("run_started", {"run_id": "r-001"})
        assert result["sent"] is True
        assert result["attempt"] == 3
        assert len(client.requests) == 3

    def test_all_retries_exhausted(self, webhook_config: WebhookConfig) -> None:
        client = FakeHttpClient(fail_count=10)
        webhook_config.backoff_base = 0.001
        notifier = WebhookNotifier(config=webhook_config, http_client=client)
        result = notifier.send_event("run_started", {"run_id": "r-001"})
        assert result["sent"] is False
        assert "retries failed" in result["reason"]

    def test_http_error_status(self, webhook_config: WebhookConfig) -> None:
        client = FakeHttpClient(response_status=500)
        webhook_config.backoff_base = 0.001
        notifier = WebhookNotifier(config=webhook_config, http_client=client)
        result = notifier.send_event("run_started", {"run_id": "r-001"})
        assert result["sent"] is False

    def test_dedupe_same_event(
        self, webhook_config: WebhookConfig, fake_client: FakeHttpClient
    ) -> None:
        notifier = WebhookNotifier(config=webhook_config, http_client=fake_client)
        r1 = notifier.send_event("run_started", {"run_id": "r-001"})
        r2 = notifier.send_event("run_started", {"run_id": "r-001"})
        assert r1["sent"] is True
        assert r2["sent"] is False
        assert "duplicate" in r2["reason"]

    def test_dedupe_different_data(
        self, webhook_config: WebhookConfig, fake_client: FakeHttpClient
    ) -> None:
        notifier = WebhookNotifier(config=webhook_config, http_client=fake_client)
        r1 = notifier.send_event("run_started", {"run_id": "r-001"})
        r2 = notifier.send_event("run_started", {"run_id": "r-002"})
        assert r1["sent"] is True
        assert r2["sent"] is True

    def test_dedupe_expired(
        self, webhook_config: WebhookConfig, fake_client: FakeHttpClient
    ) -> None:
        notifier = WebhookNotifier(
            config=webhook_config,
            http_client=fake_client,
            _dedupe_window=0.01,
        )
        notifier.send_event("run_started", {"run_id": "r-001"})
        time.sleep(0.02)
        r2 = notifier.send_event("run_started", {"run_id": "r-001"})
        assert r2["sent"] is True

    def test_event_bus_handler(
        self, webhook_config: WebhookConfig, fake_client: FakeHttpClient
    ) -> None:
        notifier = WebhookNotifier(config=webhook_config, http_client=fake_client)
        notifier.event_bus_handler("run_done", {"run_id": "r-001"})
        assert len(fake_client.requests) == 1

    def test_error_messages_redacted(self, webhook_config: WebhookConfig) -> None:
        """Ensure exception messages don't leak secrets."""

        class FailClient:
            def post(self, url: str, body: bytes, headers: dict[str, str], timeout: int) -> int:
                raise ConnectionError("Failed connecting with token=sk-AAAAAAAAAAAAAAAAAAAAAA")

        webhook_config.backoff_base = 0.001
        notifier = WebhookNotifier(config=webhook_config, http_client=FailClient())
        result = notifier.send_event("run_started", {"run_id": "r-001"})
        assert result["sent"] is False
        assert "sk-" not in result.get("reason", "")

    def test_relayed_events_set(self) -> None:
        assert "run_started" in RELAYED_EVENTS
        assert "session_done" in RELAYED_EVENTS
        assert "budget_exceeded" in RELAYED_EVENTS
        assert "recovery_retry" in RELAYED_EVENTS


# ── UrllibClient ──


class TestUrllibClient:
    def test_http_error_returns_error_code(self) -> None:
        """urllib.error.HTTPError must be caught and its code returned (lines 86-91)."""
        import urllib.error
        import urllib.request
        from unittest.mock import patch

        from owlmind.webhook import UrllibClient

        client = UrllibClient()

        http_err = urllib.error.HTTPError(
            url="https://hooks.example.com/owlmind",
            code=422,
            msg="Unprocessable Entity",
            hdrs=None,  # type: ignore[arg-type]
            fp=None,
        )

        with patch("urllib.request.urlopen", side_effect=http_err):
            status = client.post(
                url="https://hooks.example.com/owlmind",
                body=b'{"event": "run_started"}',
                headers={"Content-Type": "application/json"},
                timeout=5,
            )

        assert status == 422

    def test_http_error_500_returned(self) -> None:
        """HTTP 500 from server is caught and returned as status code."""
        import urllib.error
        from unittest.mock import patch

        from owlmind.webhook import UrllibClient

        client = UrllibClient()
        http_err = urllib.error.HTTPError(
            url="https://hooks.example.com/",
            code=500,
            msg="Internal Server Error",
            hdrs=None,  # type: ignore[arg-type]
            fp=None,
        )

        with patch("urllib.request.urlopen", side_effect=http_err):
            status = client.post(
                url="https://hooks.example.com/",
                body=b"{}",
                headers={},
                timeout=5,
            )

        assert status == 500

    def test_successful_post_returns_status(self) -> None:
        """Successful urlopen returns the HTTP status code (line 89)."""
        from unittest.mock import MagicMock, patch

        from owlmind.webhook import UrllibClient

        client = UrllibClient()

        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        with patch("urllib.request.urlopen", return_value=mock_resp):
            status = client.post(
                url="https://hooks.example.com/owlmind",
                body=b'{"event": "run_started"}',
                headers={"Content-Type": "application/json"},
                timeout=5,
            )

        assert status == 200


# ── build_payload — non-string/non-dict values ──


class TestBuildPayloadNonStringValues:
    def test_int_value_passed_through_unchanged(self) -> None:
        """Integer values should appear as-is in payload data (line 112)."""
        payload = build_payload("run_started", {"attempt": 3})
        assert payload["data"]["attempt"] == 3

    def test_bool_value_passed_through_unchanged(self) -> None:
        """Boolean values should appear as-is in payload data (line 112)."""
        payload = build_payload("run_started", {"success": True})
        assert payload["data"]["success"] is True

    def test_list_value_passed_through_unchanged(self) -> None:
        """List values should appear as-is in payload data (line 112)."""
        payload = build_payload("run_started", {"tags": ["ci", "nightly"]})
        assert payload["data"]["tags"] == ["ci", "nightly"]

    def test_none_value_passed_through_unchanged(self) -> None:
        """None values should appear as-is in payload data (line 112)."""
        payload = build_payload("run_started", {"end_time": None})
        assert payload["data"]["end_time"] is None

    def test_mixed_value_types(self) -> None:
        """Mix of str, int, bool, list in one payload — all handled correctly."""
        payload = build_payload(
            "run_done",
            {
                "run_id": "r-001",
                "tokens": 1024,
                "success": False,
                "steps": [1, 2, 3],
            },
        )
        data = payload["data"]
        assert isinstance(data["run_id"], str)
        assert data["tokens"] == 1024
        assert data["success"] is False
        assert data["steps"] == [1, 2, 3]
