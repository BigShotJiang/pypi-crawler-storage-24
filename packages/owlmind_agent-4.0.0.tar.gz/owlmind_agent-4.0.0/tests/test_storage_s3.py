"""Tests for S3/MinIO artifact storage and PostgresRunStorage S3 integration."""

from __future__ import annotations

import pytest

# Re-use FakePostgresPool from postgres tests
from test_storage_postgres import FakePostgresPool

from owlmind.storage.interface import ArtifactStorage, StorageBackend
from owlmind.storage.postgres import PostgresRunStorage

# ===================================================================
# FakeS3Storage — in-memory replacement for S3ArtifactStorage
# ===================================================================


class FakeS3Storage:
    """In-memory ``ArtifactStorage`` for tests (no aiobotocore dependency)."""

    def __init__(self) -> None:
        self._store: dict[str, bytes] = {}
        self._content_types: dict[str, str] = {}

    async def put(
        self,
        key: str,
        data: bytes,
        *,
        content_type: str = "application/octet-stream",
    ) -> None:
        self._store[key] = data
        self._content_types[key] = content_type

    async def get(self, key: str) -> bytes:
        if key not in self._store:
            raise KeyError(key)
        return self._store[key]

    async def delete(self, key: str) -> None:
        self._store.pop(key, None)

    async def close(self) -> None:
        pass


# ===================================================================
# Fixtures
# ===================================================================


@pytest.fixture
def fake_s3():
    return FakeS3Storage()


@pytest.fixture
def fake_pool():
    return FakePostgresPool()


@pytest.fixture
def run_storage_with_s3(fake_pool, fake_s3):
    return PostgresRunStorage(fake_pool, artifact_storage=fake_s3)


@pytest.fixture
def run_storage_no_s3(fake_pool):
    return PostgresRunStorage(fake_pool)


# ===================================================================
# TestArtifactStorageProtocol — FakeS3Storage satisfies Protocol
# ===================================================================


class TestArtifactStorageProtocol:
    def test_fake_satisfies_protocol(self, fake_s3):
        assert isinstance(fake_s3, ArtifactStorage)

    @pytest.mark.asyncio
    async def test_put_and_get_roundtrip(self, fake_s3):
        await fake_s3.put("key/test.bin", b"\x00\x01\x02")
        result = await fake_s3.get("key/test.bin")
        assert result == b"\x00\x01\x02"

    @pytest.mark.asyncio
    async def test_get_missing_raises_key_error(self, fake_s3):
        with pytest.raises(KeyError, match="nonexistent"):
            await fake_s3.get("nonexistent")


# ===================================================================
# TestPostgresWithS3 — write_artifact / read_artifact with S3
# ===================================================================


class TestPostgresWithS3:
    @pytest.mark.asyncio
    async def test_write_stores_key_in_pg(self, run_storage_with_s3, fake_pool):
        await run_storage_with_s3.create_run("run-001")
        await run_storage_with_s3.write_artifact("run-001", "out.txt", "hello")

        art = fake_pool.run_artifacts[("run-001", "out.txt")]
        assert art["storage_key"] == "runs/run-001/artifacts/out.txt"
        assert art["content"] is None

    @pytest.mark.asyncio
    async def test_write_uploads_to_s3(self, run_storage_with_s3, fake_s3):
        await run_storage_with_s3.create_run("run-001")
        await run_storage_with_s3.write_artifact("run-001", "data.json", '{"ok":true}')

        key = "runs/run-001/artifacts/data.json"
        assert key in fake_s3._store
        assert fake_s3._store[key] == b'{"ok":true}'
        assert fake_s3._content_types[key] == "text/plain"

    @pytest.mark.asyncio
    async def test_write_binary_to_s3(self, run_storage_with_s3, fake_s3):
        await run_storage_with_s3.create_run("run-001")
        data = b"\x89PNG\r\n"
        await run_storage_with_s3.write_artifact("run-001", "img.png", data)

        key = "runs/run-001/artifacts/img.png"
        assert fake_s3._store[key] == data
        assert fake_s3._content_types[key] == "application/octet-stream"

    @pytest.mark.asyncio
    async def test_write_without_s3_stores_bytea(self, run_storage_no_s3, fake_pool):
        await run_storage_no_s3.create_run("run-001")
        await run_storage_no_s3.write_artifact("run-001", "out.txt", "hello")

        art = fake_pool.run_artifacts[("run-001", "out.txt")]
        assert art["content"] == b"hello"
        assert art["storage_key"] is None

    @pytest.mark.asyncio
    async def test_read_from_s3(self, run_storage_with_s3, fake_s3):
        await run_storage_with_s3.create_run("run-001")
        await run_storage_with_s3.write_artifact("run-001", "out.txt", "s3 data")

        result = await run_storage_with_s3.read_artifact("run-001", "out.txt")
        assert result == b"s3 data"

    @pytest.mark.asyncio
    async def test_read_from_bytea(self, run_storage_no_s3, fake_pool):
        await run_storage_no_s3.create_run("run-001")
        await run_storage_no_s3.write_artifact("run-001", "f.txt", "local data")

        result = await run_storage_no_s3.read_artifact("run-001", "f.txt")
        assert result == b"local data"

    @pytest.mark.asyncio
    async def test_read_missing_raises(self, run_storage_with_s3):
        with pytest.raises(FileNotFoundError, match="Artifact not found"):
            await run_storage_with_s3.read_artifact("run-001", "nope.txt")

    @pytest.mark.asyncio
    async def test_read_s3_without_storage_raises_runtime(self, fake_pool):
        """Artifact has storage_key but no ArtifactStorage configured."""
        # Manually insert an artifact with storage_key
        fake_pool.run_artifacts[("run-001", "remote.txt")] = {
            "filename": "remote.txt",
            "content": None,
            "storage_key": "runs/run-001/artifacts/remote.txt",
            "sha256": "abc",
            "size_bytes": 10,
            "kind": "text",
        }
        storage = PostgresRunStorage(fake_pool)  # no artifact_storage
        with pytest.raises(RuntimeError, match="no ArtifactStorage configured"):
            await storage.read_artifact("run-001", "remote.txt")

    @pytest.mark.asyncio
    async def test_s3_key_format(self):
        assert PostgresRunStorage._s3_key("r-1", "out.log") == "runs/r-1/artifacts/out.log"


# ===================================================================
# TestOverwrite — overwriting existing artifacts
# ===================================================================


class TestOverwrite:
    @pytest.mark.asyncio
    async def test_overwrite_replaces_s3_object(self, run_storage_with_s3, fake_s3):
        await run_storage_with_s3.create_run("run-001")
        await run_storage_with_s3.write_artifact("run-001", "f.txt", "v1")
        await run_storage_with_s3.write_artifact("run-001", "f.txt", "v2")

        key = "runs/run-001/artifacts/f.txt"
        assert fake_s3._store[key] == b"v2"

    @pytest.mark.asyncio
    async def test_overwrite_updates_pg_metadata(self, run_storage_with_s3, fake_pool):
        await run_storage_with_s3.create_run("run-001")
        sha1 = await run_storage_with_s3.write_artifact("run-001", "f.txt", "v1")
        sha2 = await run_storage_with_s3.write_artifact("run-001", "f.txt", "v2")

        assert sha1 != sha2
        art = fake_pool.run_artifacts[("run-001", "f.txt")]
        assert art["sha256"] == sha2
        assert art["size_bytes"] == 2


# ===================================================================
# TestFactoryS3 — create_storage with S3 options
# ===================================================================


class TestFactoryS3:
    def test_postgres_with_s3_creates_artifact_storage(self, tmp_path):
        from owlmind.storage import create_storage
        from owlmind.storage.s3 import S3ArtifactStorage

        storage = create_storage(
            backend="postgres",
            postgres_dsn="postgresql://test/db",
            queue_dir=str(tmp_path / "q"),
            s3_bucket="my-bucket",
            s3_endpoint_url="http://localhost:9000",
            s3_access_key="key",
            s3_secret_key="secret",
        )
        assert storage.artifact is not None
        assert isinstance(storage.artifact, S3ArtifactStorage)
        assert isinstance(storage.runs, PostgresRunStorage)
        assert storage.runs._artifact_storage is storage.artifact

    def test_postgres_without_s3_no_artifact_storage(self, tmp_path):
        from owlmind.storage import create_storage

        storage = create_storage(
            backend="postgres",
            postgres_dsn="postgresql://test/db",
            queue_dir=str(tmp_path / "q"),
        )
        assert storage.artifact is None
        assert storage.runs._artifact_storage is None

    def test_artifact_in_storage_backend(self, fake_s3):
        from owlmind.storage.file import (
            FileLedgerStorage,
            FileQueueStorage,
            FileRunStorage,
            FileSessionStorage,
        )

        backend = StorageBackend(
            runs=FileRunStorage("runs"),
            ledger=FileLedgerStorage("ledger"),
            queue=FileQueueStorage("queue"),
            sessions=FileSessionStorage("sessions"),
            artifact=fake_s3,
        )
        assert backend.artifact is fake_s3


# ===================================================================
# TestS3Lifecycle — lazy init and close
# ===================================================================


class TestS3Lifecycle:
    def test_client_none_before_first_call(self):
        from owlmind.storage.s3 import S3ArtifactStorage

        s3 = S3ArtifactStorage(bucket="test")
        assert s3._client is None
        assert s3._ctx is None

    @pytest.mark.asyncio
    async def test_close_noop_when_not_connected(self):
        from owlmind.storage.s3 import S3ArtifactStorage

        s3 = S3ArtifactStorage(bucket="test")
        await s3.close()  # should not raise
        assert s3._client is None


# ===================================================================
# TestWriteManifestWithS3 — manifest works with S3 artifacts
# ===================================================================


class TestWriteManifestWithS3:
    @pytest.mark.asyncio
    async def test_manifest_with_s3_artifacts(self, run_storage_with_s3, fake_s3):
        await run_storage_with_s3.create_run("run-001")
        await run_storage_with_s3.write_artifact("run-001", "out.txt", "result")
        await run_storage_with_s3.write_artifact("run-001", "log.json", '{"ok":true}')

        manifest = await run_storage_with_s3.write_manifest("run-001")
        assert manifest["run_id"] == "run-001"
        assert manifest["artifact_count"] == 2
        assert "manifest_sha256" in manifest
