"""Tests for S3ArtifactStorage with mocked aiobotocore.

Covers the lazy client init, put/get/delete/close paths
that require aiobotocore (not covered in test_storage_s3.py).
"""

from __future__ import annotations

import sys
import types
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from owlmind.storage.s3 import S3ArtifactStorage

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_session_and_client():
    """Return (session_mod, client_mock, store_dict).

    The session_mod is a fake 'aiobotocore.session' module.
    The client_mock is the fake S3 client injected by __aenter__.
    store_dict is the in-memory backing store for put/get/delete.
    """
    store: dict[str, bytes] = {}
    client = MagicMock()

    # put_object
    async def _put(**kwargs):
        store[kwargs["Key"]] = kwargs["Body"]

    client.put_object = _put

    # get_object — returns a dict with "Body" as async context manager
    class _BodyStream:
        def __init__(self, data: bytes):
            self._data = data

        async def read(self):
            return self._data

        async def __aenter__(self):
            return self

        async def __aexit__(self, *a):
            pass

    NoSuchKey = type("NoSuchKey", (Exception,), {})
    client.exceptions = MagicMock()
    client.exceptions.NoSuchKey = NoSuchKey

    async def _get(**kwargs):
        key = kwargs["Key"]
        if key not in store:
            raise NoSuchKey(key)
        return {"Body": _BodyStream(store[key])}

    client.get_object = _get

    async def _delete(**kwargs):
        store.pop(kwargs["Key"], None)

    client.delete_object = _delete

    # ctx is the async context manager returned by session.create_client()
    ctx = MagicMock()
    ctx.__aenter__ = AsyncMock(return_value=client)
    ctx.__aexit__ = AsyncMock(return_value=None)

    session = MagicMock()
    session.create_client.return_value = ctx

    # Build a fake aiobotocore.session module
    session_mod = types.ModuleType("aiobotocore.session")
    session_mod.get_session = MagicMock(return_value=session)

    return session_mod, client, store, session


def _patch_abcs(session_mod):
    """Patch sys.modules so `import aiobotocore.session` returns session_mod."""
    aiobotocore_mod = types.ModuleType("aiobotocore")
    aiobotocore_mod.session = session_mod
    return patch.dict(
        sys.modules,
        {"aiobotocore": aiobotocore_mod, "aiobotocore.session": session_mod},
    )


# ---------------------------------------------------------------------------
# TestEnsureClient
# ---------------------------------------------------------------------------


class TestEnsureClient:
    @pytest.mark.asyncio
    async def test_client_created_on_first_call(self):
        session_mod, client, _store, _session = _make_session_and_client()
        s3 = S3ArtifactStorage(bucket="b")
        with _patch_abcs(session_mod):
            result = await s3._ensure_client()
        assert result is client

    @pytest.mark.asyncio
    async def test_client_cached_on_second_call(self):
        session_mod, client, _store, _session = _make_session_and_client()
        s3 = S3ArtifactStorage(bucket="b")
        with _patch_abcs(session_mod):
            c1 = await s3._ensure_client()
            c2 = await s3._ensure_client()
        assert c1 is c2 is client

    @pytest.mark.asyncio
    async def test_endpoint_url_and_credentials_forwarded(self):
        session_mod, _client, _store, session = _make_session_and_client()
        s3 = S3ArtifactStorage(
            bucket="b",
            endpoint_url="http://minio:9000",
            aws_access_key_id="my-key",
            aws_secret_access_key="my-secret",
        )
        with _patch_abcs(session_mod):
            await s3._ensure_client()

        kwargs = session.create_client.call_args[1]
        assert kwargs["endpoint_url"] == "http://minio:9000"
        assert kwargs["aws_access_key_id"] == "my-key"
        assert kwargs["aws_secret_access_key"] == "my-secret"

    @pytest.mark.asyncio
    async def test_no_endpoint_when_not_specified(self):
        session_mod, _client, _store, session = _make_session_and_client()
        s3 = S3ArtifactStorage(bucket="b", region_name="eu-west-1")
        with _patch_abcs(session_mod):
            await s3._ensure_client()

        kwargs = session.create_client.call_args[1]
        assert "endpoint_url" not in kwargs
        assert kwargs["region_name"] == "eu-west-1"


# ---------------------------------------------------------------------------
# TestPut
# ---------------------------------------------------------------------------


class TestPut:
    @pytest.mark.asyncio
    async def test_put_stores_bytes(self):
        session_mod, _client, store, _ = _make_session_and_client()
        s3 = S3ArtifactStorage(bucket="mybucket")
        with _patch_abcs(session_mod):
            await s3.put("folder/key.bin", b"\x01\x02\x03")
        assert store["folder/key.bin"] == b"\x01\x02\x03"

    @pytest.mark.asyncio
    async def test_put_default_content_type(self):
        """Default content_type is application/octet-stream."""
        called_kwargs: dict = {}

        session_mod, _client, _store, _ = _make_session_and_client()

        async def _put_capture(**kwargs):
            called_kwargs.update(kwargs)

        session_mod_fresh, c, s, session = _make_session_and_client()
        c.put_object = _put_capture
        s3 = S3ArtifactStorage(bucket="b")
        with _patch_abcs(session_mod_fresh):
            await s3.put("k", b"data")
        assert called_kwargs.get("ContentType") == "application/octet-stream"

    @pytest.mark.asyncio
    async def test_put_custom_content_type(self):
        called_kwargs: dict = {}

        async def _put_capture(**kwargs):
            called_kwargs.update(kwargs)

        session_mod, c, s, _ = _make_session_and_client()
        c.put_object = _put_capture
        s3 = S3ArtifactStorage(bucket="b")
        with _patch_abcs(session_mod):
            await s3.put("k", b"img", content_type="image/png")
        assert called_kwargs.get("ContentType") == "image/png"
        assert called_kwargs.get("Bucket") == "b"


# ---------------------------------------------------------------------------
# TestGet
# ---------------------------------------------------------------------------


class TestGet:
    @pytest.mark.asyncio
    async def test_get_returns_bytes(self):
        session_mod, _c, store, _ = _make_session_and_client()
        store["mykey"] = b"hello world"
        s3 = S3ArtifactStorage(bucket="b")
        with _patch_abcs(session_mod):
            data = await s3.get("mykey")
        assert data == b"hello world"

    @pytest.mark.asyncio
    async def test_get_missing_raises_key_error(self):
        session_mod, _c, _store, _ = _make_session_and_client()
        s3 = S3ArtifactStorage(bucket="b")
        with _patch_abcs(session_mod), pytest.raises(KeyError, match="no-such-key"):
            await s3.get("no-such-key")


# ---------------------------------------------------------------------------
# TestDelete
# ---------------------------------------------------------------------------


class TestDelete:
    @pytest.mark.asyncio
    async def test_delete_removes_object(self):
        session_mod, _c, store, _ = _make_session_and_client()
        store["to-delete"] = b"bye"
        s3 = S3ArtifactStorage(bucket="b")
        with _patch_abcs(session_mod):
            await s3.delete("to-delete")
        assert "to-delete" not in store

    @pytest.mark.asyncio
    async def test_delete_noop_for_missing(self):
        session_mod, _c, store, _ = _make_session_and_client()
        s3 = S3ArtifactStorage(bucket="b")
        with _patch_abcs(session_mod):
            await s3.delete("ghost")  # must not raise
        assert store == {}


# ---------------------------------------------------------------------------
# TestClose
# ---------------------------------------------------------------------------


class TestClose:
    @pytest.mark.asyncio
    async def test_close_before_init_is_noop(self):
        s3 = S3ArtifactStorage(bucket="b")
        await s3.close()  # must not raise
        assert s3._client is None
        assert s3._ctx is None

    @pytest.mark.asyncio
    async def test_close_after_use_clears_state(self):
        session_mod, _c, _store, _ = _make_session_and_client()
        s3 = S3ArtifactStorage(bucket="b")
        with _patch_abcs(session_mod):
            await s3._ensure_client()
            assert s3._client is not None
            await s3.close()
        assert s3._client is None
        assert s3._ctx is None
