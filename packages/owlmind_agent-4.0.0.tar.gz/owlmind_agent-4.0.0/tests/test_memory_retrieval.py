"""Tests for owlmind.memory.retrieval — lexical search and context building."""

from __future__ import annotations

from pathlib import Path

from owlmind.memory.retrieval import (
    _term_freq,
    _tokenize,
    build_memory_context,
    query,
)
from owlmind.memory.store import MemoryStore


class TestTokenize:
    def test_basic(self) -> None:
        tokens = _tokenize("Hello World 123")
        assert "hello" in tokens
        assert "world" in tokens
        assert "123" in tokens

    def test_empty(self) -> None:
        assert _tokenize("") == []

    def test_special_chars_stripped(self) -> None:
        tokens = _tokenize("foo.bar! baz@qux")
        assert "foo" in tokens
        assert "bar" in tokens


class TestTermFreq:
    def test_single_token(self) -> None:
        tf = _term_freq(["hello"])
        assert tf == {"hello": 1.0}

    def test_empty(self) -> None:
        assert _term_freq([]) == {}

    def test_normalized(self) -> None:
        tf = _term_freq(["a", "b", "a"])
        assert abs(tf["a"] - 2 / 3) < 0.001
        assert abs(tf["b"] - 1 / 3) < 0.001


class TestQuery:
    def test_empty_store(self, tmp_path: Path) -> None:
        store = MemoryStore(tmp_path / "mem.db")
        results = query(store, "test query")
        assert results == []
        store.close()

    def test_basic_search(self, tmp_path: Path) -> None:
        store = MemoryStore(tmp_path / "mem.db")
        store.ingest("doc", "python.md", "Python is a great programming language for testing")
        store.ingest("doc", "rust.md", "Rust is fast and memory safe language")
        results = query(store, "Python testing")
        assert len(results) >= 1
        assert results[0].source == "python.md"
        store.close()

    def test_top_k_limits(self, tmp_path: Path) -> None:
        store = MemoryStore(tmp_path / "mem.db")
        for i in range(10):
            store.ingest("doc", f"doc{i}.md", f"Document {i} about testing and code")
        results = query(store, "testing code", top_k=3)
        assert len(results) <= 3
        store.close()

    def test_scores_sorted_desc(self, tmp_path: Path) -> None:
        store = MemoryStore(tmp_path / "mem.db")
        store.ingest("doc", "a.md", "apple banana cherry")
        store.ingest("doc", "b.md", "apple apple apple banana")
        results = query(store, "apple")
        if len(results) >= 2:
            assert results[0].score >= results[1].score
        store.close()

    def test_snippet_redacted(self, tmp_path: Path) -> None:
        store = MemoryStore(tmp_path / "mem.db")
        store.ingest("doc", "keys.md", "connection string with password: hunter2 and auth")
        results = query(store, "connection auth")
        # Redaction happens at ingest, so content should be clean
        for r in results:
            assert isinstance(r.snippet, str)
        store.close()

    def test_empty_query(self, tmp_path: Path) -> None:
        store = MemoryStore(tmp_path / "mem.db")
        store.ingest("doc", "a.md", "some content")
        results = query(store, "")
        assert results == []
        store.close()


class TestBuildMemoryContext:
    def test_empty_store(self, tmp_path: Path) -> None:
        store = MemoryStore(tmp_path / "mem.db")
        ctx = build_memory_context(store, "test goal")
        assert ctx == ""
        store.close()

    def test_with_data(self, tmp_path: Path) -> None:
        store = MemoryStore(tmp_path / "mem.db")
        store.ingest(
            "doc", "readme.md", "This project uses pytest for testing and ruff for linting"
        )
        store.add_signal("lesson", "Always run ruff before committing")
        ctx = build_memory_context(store, "run pytest and ruff")
        assert "Relevant Memory" in ctx or "Signals" in ctx
        store.close()

    def test_respects_max_chars(self, tmp_path: Path) -> None:
        store = MemoryStore(tmp_path / "mem.db")
        for i in range(20):
            store.ingest("doc", f"big_{i}.md", f"Long document {i} " * 100)
        ctx = build_memory_context(store, "document", max_chars=500)
        assert len(ctx) <= 600  # some tolerance for headers
        store.close()

    def test_includes_source_refs(self, tmp_path: Path) -> None:
        store = MemoryStore(tmp_path / "mem.db")
        store.ingest("doc", "api_guide.md", "API endpoints for user authentication")
        ctx = build_memory_context(store, "authentication API")
        if ctx:
            assert "api_guide.md" in ctx
        store.close()

    def test_results_appended_within_budget(self, tmp_path: Path) -> None:
        """build_memory_context appends result entries that fit within max_chars."""
        store = MemoryStore(tmp_path / "mem.db")
        store.ingest("doc", "target.md", "uniqueword alpha coding patterns guide")
        store.ingest("doc", "noise.md", "zephyr quasar xenon unrelated filler")
        ctx = build_memory_context(store, "uniqueword", max_chars=2000)
        store.close()
        assert "Relevant Memory" in ctx
        assert "target.md" in ctx

    def test_signals_appended_within_budget(self, tmp_path: Path) -> None:
        """build_memory_context appends signal entries that fit within max_chars."""
        store = MemoryStore(tmp_path / "mem.db")
        store.add_signal("lesson", "Always run tests before committing")
        ctx = build_memory_context(store, "nonexistent query xyz999abc", max_chars=2000)
        store.close()
        assert "Signals" in ctx
        assert "lesson" in ctx

    def test_signal_entry_truncated_at_max_chars(self, tmp_path: Path) -> None:
        """build_memory_context stops adding signals when chars budget is exhausted."""
        store = MemoryStore(tmp_path / "mem.db")
        for i in range(5):
            store.add_signal("lesson", f"Signal entry {i} " + "padding " * 10)
        # Very small budget — header + a couple signals should fill it up fast
        ctx = build_memory_context(store, "nonexistent xyz999", max_chars=80)
        store.close()
        assert isinstance(ctx, str)

    def test_results_entry_skipped_when_over_budget(self, tmp_path: Path) -> None:
        """build_memory_context breaks result loop when entry would exceed max_chars."""
        store = MemoryStore(tmp_path / "mem.db")
        store.ingest("doc", "target.md", "omega alpha coding patterns unique result")
        store.ingest("doc", "noise.md", "zephyr quasar xenon filler content beta")
        # max_chars=25 — header "## Relevant Memory" is 20 chars, so only 5 left
        # which is not enough for any entry → loop breaks immediately
        ctx = build_memory_context(store, "omega", max_chars=25)
        store.close()
        assert len(ctx) <= 100


class TestQueryTopKAndSnippets:
    def test_snippet_truncated_with_ellipsis(self, tmp_path: Path) -> None:
        """Content longer than max_snippet_chars gets '...' appended to snippet."""
        store = MemoryStore(tmp_path / "mem.db")
        store.ingest("doc", "target.md", "alpha " * 40 + "extra filler words here")
        store.ingest("doc", "noise.md", "zephyr quasar xenon unrelated content beta")
        results = query(store, "alpha", max_snippet_chars=30)
        store.close()
        assert len(results) >= 1
        target = results[0]
        assert target.snippet.endswith("...")
        assert len(target.snippet) == 33

    def test_snippet_not_truncated_when_fits(self, tmp_path: Path) -> None:
        """Content shorter than max_snippet_chars returned without trailing ellipsis."""
        store = MemoryStore(tmp_path / "mem.db")
        store.ingest("doc", "short.md", "uniqueterm is great coding")
        store.ingest("doc", "noise.md", "zephyr quasar xenon unrelated filler")
        results = query(store, "uniqueterm", max_snippet_chars=400)
        store.close()
        assert len(results) >= 1
        assert not results[0].snippet.endswith("...")

    def test_top_k_stops_at_limit(self, tmp_path: Path) -> None:
        """top_k=1 stops after returning exactly 1 result even when multiple scored."""
        store = MemoryStore(tmp_path / "mem.db")
        for i in range(4):
            store.ingest(
                "doc",
                f"match{i}.md",
                f"sentinel{i} raretoken query unique match content",
            )
        for i in range(4):
            store.ingest("doc", f"noise{i}.md", f"gamma{i} delta{i} epsilon{i} filler")
        results = query(store, "raretoken", top_k=1)
        store.close()
        assert len(results) == 1

    def test_multiple_docs_within_top_k(self, tmp_path: Path) -> None:
        """Multiple unique docs all returned when within top_k."""
        store = MemoryStore(tmp_path / "mem.db")
        store.ingest("doc", "a.md", "kappa kappa kappa rare unique term")
        store.ingest("doc", "b.md", "zephyr quasar xenon unrelated content")
        results = query(store, "kappa", top_k=5)
        store.close()
        assert len(results) >= 1
