"""Tests for owlmind.memory.store — SQLite-backed memory store."""

from __future__ import annotations

from pathlib import Path

from owlmind.memory.store import MemoryStore, MemoryStoreConfig, _chunk_text, _sha256


class TestSha256:
    def test_deterministic(self) -> None:
        assert _sha256("hello") == _sha256("hello")

    def test_different_inputs(self) -> None:
        assert _sha256("a") != _sha256("b")


class TestChunkText:
    def test_short_text_single_chunk(self) -> None:
        chunks = _chunk_text("hello world", max_chars=100, overlap=10)
        assert chunks == ["hello world"]

    def test_long_text_multiple_chunks(self) -> None:
        text = "A" * 200
        chunks = _chunk_text(text, max_chars=100, overlap=20)
        assert len(chunks) >= 2
        assert all(len(c) <= 100 for c in chunks)

    def test_overlap(self) -> None:
        text = "ABCDEFGHIJ" * 10  # 100 chars
        chunks = _chunk_text(text, max_chars=40, overlap=10)
        assert len(chunks) >= 3


class TestMemoryStoreIngest:
    def test_ingest_returns_doc_id(self, tmp_path: Path) -> None:
        store = MemoryStore(tmp_path / "mem.db")
        doc_id = store.ingest("doc", "test.md", "Hello world content")
        assert doc_id.startswith("doc-")
        store.close()

    def test_duplicate_skipped(self, tmp_path: Path) -> None:
        store = MemoryStore(tmp_path / "mem.db")
        id1 = store.ingest("doc", "a.md", "Same content")
        id2 = store.ingest("doc", "b.md", "Same content")
        assert id1 == id2
        assert store.stats()["documents"] == 1
        store.close()

    def test_chunks_created(self, tmp_path: Path) -> None:
        store = MemoryStore(tmp_path / "mem.db")
        doc_id = store.ingest("doc", "test.md", "A" * 2000)
        chunks = store.get_chunks(doc_id)
        assert len(chunks) >= 2
        store.close()

    def test_redaction_applied(self, tmp_path: Path) -> None:
        store = MemoryStore(tmp_path / "mem.db")
        store.ingest("doc", "secrets.md", "api_key = sk-secret-12345")
        s = store.stats()
        assert s["documents"] == 1
        # Content should be redacted — verify via chunks
        rows = store._conn.execute("SELECT content FROM documents").fetchall()
        for (content,) in rows:
            assert "sk-secret-12345" not in content
        store.close()


class TestMemoryStoreSignals:
    def test_add_and_get_signal(self, tmp_path: Path) -> None:
        store = MemoryStore(tmp_path / "mem.db")
        sid = store.add_signal("lesson", "Always run tests first", run_id="run-001")
        assert sid > 0
        signals = store.get_signals()
        assert len(signals) == 1
        assert signals[0].summary == "Always run tests first"
        store.close()

    def test_filter_by_kind(self, tmp_path: Path) -> None:
        store = MemoryStore(tmp_path / "mem.db")
        store.add_signal("error", "Timeout in planner")
        store.add_signal("lesson", "Use shorter prompts")
        errors = store.get_signals(kind="error")
        assert len(errors) == 1
        assert errors[0].kind == "error"
        store.close()

    def test_signal_redaction(self, tmp_path: Path) -> None:
        store = MemoryStore(tmp_path / "mem.db")
        store.add_signal("error", "Failed with api_key = sk-real-key")
        signals = store.get_signals()
        assert "sk-real-key" not in signals[0].summary
        store.close()


class TestMemoryStoreStats:
    def test_empty_stats(self, tmp_path: Path) -> None:
        store = MemoryStore(tmp_path / "mem.db")
        s = store.stats()
        assert s["documents"] == 0
        assert s["chunks"] == 0
        assert s["signals"] == 0
        store.close()

    def test_stats_after_ingest(self, tmp_path: Path) -> None:
        store = MemoryStore(tmp_path / "mem.db")
        store.ingest("doc", "a.md", "Hello")
        store.ingest("run", "run-1", "Run data")
        s = store.stats()
        assert s["documents"] == 2
        assert s["docs_by_kind"]["doc"] == 1
        assert s["docs_by_kind"]["run"] == 1
        store.close()


class TestMemoryStorePurge:
    def test_purge_all(self, tmp_path: Path) -> None:
        store = MemoryStore(tmp_path / "mem.db")
        store.ingest("doc", "a.md", "Content A")
        store.ingest("doc", "b.md", "Content B")
        deleted = store.purge()
        assert deleted == 2
        assert store.stats()["documents"] == 0
        store.close()


class TestMemoryStoreEviction:
    def test_eviction_oldest(self, tmp_path: Path) -> None:
        cfg = MemoryStoreConfig(max_docs=3)
        store = MemoryStore(tmp_path / "mem.db", config=cfg)
        store.ingest("doc", "a.md", "Content A")
        store.ingest("doc", "b.md", "Content B")
        store.ingest("doc", "c.md", "Content C")
        # This should evict the oldest
        store.ingest("doc", "d.md", "Content D")
        assert store.stats()["documents"] == 3
        store.close()


class TestAddSignalWithDetail:
    """Line 162: detail is not None → redact_secrets(detail) is called."""

    def test_add_signal_with_detail(self, tmp_path: Path) -> None:
        store = MemoryStore(tmp_path / "mem.db")
        store.add_signal("lesson", "learned something", run_id="run-1", detail="extra detail here")
        signals = store.get_signals(kind="lesson")
        assert len(signals) == 1
        store.close()


class TestPurgeOlderThan:
    """Lines 212-213: purge(older_than_days=N) uses cutoff timestamp."""

    def test_purge_with_older_than_days(self, tmp_path: Path) -> None:
        store = MemoryStore(tmp_path / "mem.db")
        store.ingest("doc", "old.md", "old content")
        # Purge everything older than 0 days (all docs)
        count = store.purge(older_than_days=0)
        assert count >= 0  # may be 0 if docs created within the window
        store.close()

    def test_purge_without_older_than(self, tmp_path: Path) -> None:
        store = MemoryStore(tmp_path / "mem.db")
        store.ingest("doc", "file.md", "content")
        count = store.purge()  # purges all
        assert count >= 1
        store.close()
