"""Tests for release module — changelog, verification, bundle."""

from __future__ import annotations

import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

from owlmind.release import (
    create_release_bundle,
    generate_changelog,
    verify_release,
)


def _init_git_repo(tmp_path: Path) -> Path:
    """Create a minimal git repo with some commits."""
    subprocess.run(["git", "init"], cwd=tmp_path, capture_output=True)
    subprocess.run(
        ["git", "config", "user.email", "test@test.com"],
        cwd=tmp_path,
        capture_output=True,
    )
    subprocess.run(
        ["git", "config", "user.name", "Test"],
        cwd=tmp_path,
        capture_output=True,
    )
    (tmp_path / "hello.py").write_text('print("hello")\n')
    subprocess.run(["git", "add", "."], cwd=tmp_path, capture_output=True)
    subprocess.run(
        ["git", "commit", "-m", "Initial commit"],
        cwd=tmp_path,
        capture_output=True,
    )
    (tmp_path / "hello.py").write_text('print("world")\n')
    subprocess.run(["git", "add", "."], cwd=tmp_path, capture_output=True)
    subprocess.run(
        ["git", "commit", "-m", "Add world"],
        cwd=tmp_path,
        capture_output=True,
    )
    return tmp_path


class TestGenerateChangelog:
    def test_generates_markdown(self, tmp_path: Path) -> None:
        repo = _init_git_repo(tmp_path)
        out = tmp_path / "CHANGELOG.md"

        result = generate_changelog(repo, out_path=out)
        assert result == out
        assert result.exists()

        md = result.read_text()
        assert "OWLMIND Changelog" in md
        assert "Initial commit" in md
        assert "Add world" in md

    def test_default_path(self, tmp_path: Path) -> None:
        repo = _init_git_repo(tmp_path)

        result = generate_changelog(repo)
        assert result == repo / "CHANGELOG.md"
        assert result.exists()

    def test_empty_repo(self, tmp_path: Path) -> None:
        """Changelog with no commits should still be valid."""
        mock_result = MagicMock()
        mock_result.returncode = 128
        mock_result.stdout = ""

        out = tmp_path / "CHANGELOG.md"
        with patch("owlmind.release.subprocess.run", return_value=mock_result):
            result = generate_changelog(tmp_path, out_path=out)

        assert result.exists()
        md = result.read_text()
        assert "No commits found" in md

    def test_since_tag(self, tmp_path: Path) -> None:
        repo = _init_git_repo(tmp_path)
        # Tag the first commit
        subprocess.run(
            ["git", "tag", "v0.1.0", "HEAD~1"],
            cwd=repo,
            capture_output=True,
        )

        out = tmp_path / "CHANGELOG.md"
        result = generate_changelog(repo, out_path=out, since_tag="v0.1.0")
        assert result.exists()
        md = result.read_text()
        assert "Add world" in md
        # Initial commit should NOT be included (it's before the tag)


class TestVerifyRelease:
    def test_version_consistency_pass(self, tmp_path: Path) -> None:
        """Both files have same version."""
        repo = _init_git_repo(tmp_path)
        src_dir = repo / "src" / "owlmind"
        src_dir.mkdir(parents=True)
        (src_dir / "__init__.py").write_text('__version__ = "0.19.0"\n')
        (repo / "pyproject.toml").write_text('version = "0.19.0"\n')
        (repo / "CHANGELOG.md").write_text("# Changelog\n\nContent here.\n")

        report = verify_release(repo, run_tests=False, run_lint=False)
        version_check = next(c for c in report.checks if c.name == "version_consistency")
        assert version_check.ok

    def test_version_consistency_fail(self, tmp_path: Path) -> None:
        """Version mismatch."""
        repo = _init_git_repo(tmp_path)
        src_dir = repo / "src" / "owlmind"
        src_dir.mkdir(parents=True)
        (src_dir / "__init__.py").write_text('__version__ = "0.18.0"\n')
        (repo / "pyproject.toml").write_text('version = "0.19.0"\n')

        report = verify_release(repo, run_tests=False, run_lint=False)
        version_check = next(c for c in report.checks if c.name == "version_consistency")
        assert not version_check.ok

    def test_changelog_missing(self, tmp_path: Path) -> None:
        repo = _init_git_repo(tmp_path)

        report = verify_release(repo, run_tests=False, run_lint=False)
        changelog_check = next(c for c in report.checks if c.name == "changelog")
        assert not changelog_check.ok

    def test_changelog_exists(self, tmp_path: Path) -> None:
        repo = _init_git_repo(tmp_path)
        (repo / "CHANGELOG.md").write_text("# Changelog\n")

        report = verify_release(repo, run_tests=False, run_lint=False)
        changelog_check = next(c for c in report.checks if c.name == "changelog")
        assert changelog_check.ok

    def test_git_clean_check(self, tmp_path: Path) -> None:
        repo = _init_git_repo(tmp_path)

        report = verify_release(repo, run_tests=False, run_lint=False)
        git_check = next(c for c in report.checks if c.name == "git_clean")
        assert git_check.ok  # No uncommitted changes after commits

    def test_git_dirty(self, tmp_path: Path) -> None:
        repo = _init_git_repo(tmp_path)
        (repo / "dirty.txt").write_text("uncommitted\n")

        report = verify_release(repo, run_tests=False, run_lint=False)
        git_check = next(c for c in report.checks if c.name == "git_clean")
        assert not git_check.ok

    def test_report_ok_all_pass(self, tmp_path: Path) -> None:
        repo = _init_git_repo(tmp_path)
        src_dir = repo / "src" / "owlmind"
        src_dir.mkdir(parents=True)
        (src_dir / "__init__.py").write_text('__version__ = "0.19.0"\n')
        (repo / "pyproject.toml").write_text('version = "0.19.0"\n')
        (repo / "CHANGELOG.md").write_text("# Changelog\n\nContent.\n")

        # Commit to make git clean
        subprocess.run(["git", "add", "."], cwd=repo, capture_output=True)
        subprocess.run(
            ["git", "commit", "-m", "release prep"],
            cwd=repo,
            capture_output=True,
        )

        report = verify_release(repo, run_tests=False, run_lint=False)
        assert report.ok


class TestCreateReleaseBundle:
    def test_creates_bundle(self, tmp_path: Path) -> None:
        repo = _init_git_repo(tmp_path)
        out_dir = tmp_path / "release_out"

        result = create_release_bundle(repo, out_dir=out_dir)
        assert result["out_dir"] == str(out_dir)
        assert "changelog" in result["artifacts"]
        assert "report" in result["artifacts"]

        changelog_path = Path(result["artifacts"]["changelog"])
        assert changelog_path.exists()

        report_path = Path(result["artifacts"]["report"])
        assert report_path.exists()
        assert "Release Report" in report_path.read_text()

    def test_default_output_dir(self, tmp_path: Path) -> None:
        repo = _init_git_repo(tmp_path)

        result = create_release_bundle(repo)
        assert result["out_dir"] == str(repo / "release")
        assert (repo / "release" / "CHANGELOG.md").exists()

    def test_bundle_includes_version(self, tmp_path: Path) -> None:
        repo = _init_git_repo(tmp_path)

        result = create_release_bundle(repo)
        from owlmind import __version__

        assert result["version"] == __version__


# ---------------------------------------------------------------------------
# verify_release — run_tests and run_lint branches
# ---------------------------------------------------------------------------


class TestVerifyReleaseSubprocessBranches:
    """Cover the run_tests=True and run_lint=True branches of verify_release."""

    def test_run_tests_branch_calls_check_tests(self, tmp_path: Path) -> None:
        """verify_release(run_tests=True) must include a 'tests' check."""
        repo = _init_git_repo(tmp_path)

        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "5 passed"
        mock_result.stderr = ""

        with patch("owlmind.release.subprocess.run", return_value=mock_result):
            report = verify_release(repo, run_tests=True, run_lint=False)

        check_names = [c.name for c in report.checks]
        assert "tests" in check_names

        tests_check = next(c for c in report.checks if c.name == "tests")
        assert tests_check.ok

    def test_run_lint_branch_calls_check_lint(self, tmp_path: Path) -> None:
        """verify_release(run_lint=True) must include a 'lint' check."""
        repo = _init_git_repo(tmp_path)

        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = ""
        mock_result.stderr = ""

        with patch("owlmind.release.subprocess.run", return_value=mock_result):
            report = verify_release(repo, run_tests=False, run_lint=True)

        check_names = [c.name for c in report.checks]
        assert "lint" in check_names

        lint_check = next(c for c in report.checks if c.name == "lint")
        assert lint_check.ok


# ---------------------------------------------------------------------------
# _check_tests — pass and fail scenarios
# ---------------------------------------------------------------------------


class TestCheckTests:
    """Cover _check_tests() directly via verify_release(run_tests=True)."""

    def test_tests_pass(self, tmp_path: Path) -> None:
        """When pytest exits 0, tests check is ok."""
        repo = _init_git_repo(tmp_path)

        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "10 passed in 1.23s"
        mock_result.stderr = ""

        with patch("owlmind.release.subprocess.run", return_value=mock_result):
            report = verify_release(repo, run_tests=True, run_lint=False)

        tests_check = next(c for c in report.checks if c.name == "tests")
        assert tests_check.ok
        assert "passed" in tests_check.detail

    def test_tests_fail(self, tmp_path: Path) -> None:
        """When pytest exits non-zero, tests check is not ok."""
        repo = _init_git_repo(tmp_path)

        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stdout = "2 failed, 8 passed in 1.10s"
        mock_result.stderr = ""

        with patch("owlmind.release.subprocess.run", return_value=mock_result):
            report = verify_release(repo, run_tests=True, run_lint=False)

        tests_check = next(c for c in report.checks if c.name == "tests")
        assert not tests_check.ok
        assert "failed" in tests_check.detail

    def test_tests_no_output(self, tmp_path: Path) -> None:
        """When pytest produces no output, detail falls back to 'no output'."""
        repo = _init_git_repo(tmp_path)

        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stdout = ""
        mock_result.stderr = ""

        with patch("owlmind.release.subprocess.run", return_value=mock_result):
            report = verify_release(repo, run_tests=True, run_lint=False)

        tests_check = next(c for c in report.checks if c.name == "tests")
        assert not tests_check.ok
        assert tests_check.detail == "no output"


# ---------------------------------------------------------------------------
# _check_lint — pass and fail scenarios
# ---------------------------------------------------------------------------


class TestCheckLint:
    """Cover _check_lint() directly via verify_release(run_lint=True)."""

    def test_lint_passes(self, tmp_path: Path) -> None:
        """When ruff exits 0, lint check is ok and detail is 'passed'."""
        repo = _init_git_repo(tmp_path)

        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = ""
        mock_result.stderr = ""

        with patch("owlmind.release.subprocess.run", return_value=mock_result):
            report = verify_release(repo, run_tests=False, run_lint=True)

        lint_check = next(c for c in report.checks if c.name == "lint")
        assert lint_check.ok
        assert lint_check.detail == "passed"

    def test_lint_fails(self, tmp_path: Path) -> None:
        """When ruff exits non-zero, lint check is not ok and detail contains output."""
        repo = _init_git_repo(tmp_path)

        ruff_output = "src/owlmind/foo.py:10:5: E501 Line too long (120 > 88)"
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stdout = ruff_output
        mock_result.stderr = ""

        with patch("owlmind.release.subprocess.run", return_value=mock_result):
            report = verify_release(repo, run_tests=False, run_lint=True)

        lint_check = next(c for c in report.checks if c.name == "lint")
        assert not lint_check.ok
        assert "E501" in lint_check.detail

    def test_lint_detail_truncated_at_100(self, tmp_path: Path) -> None:
        """Lint failure detail is truncated at 100 characters."""
        repo = _init_git_repo(tmp_path)

        long_output = "E" * 200
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stdout = long_output
        mock_result.stderr = ""

        with patch("owlmind.release.subprocess.run", return_value=mock_result):
            report = verify_release(repo, run_tests=False, run_lint=True)

        lint_check = next(c for c in report.checks if c.name == "lint")
        assert not lint_check.ok
        assert len(lint_check.detail) <= 100
