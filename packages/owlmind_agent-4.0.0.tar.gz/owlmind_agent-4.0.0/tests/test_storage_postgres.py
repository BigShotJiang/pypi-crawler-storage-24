"""Tests for PostgreSQL-backed storage adapters with FakePostgresPool."""

from __future__ import annotations

import asyncio
import json
from datetime import UTC, datetime
from datetime import date as date_type
from typing import Any

import pytest

from owlmind.evidence import _GENESIS_HASH
from owlmind.ledger import UsageEntry
from owlmind.session import GoalRunInfo, GoalSpec, SessionMeta
from owlmind.storage.postgres import (
    PostgresLedgerStorage,
    PostgresPool,
    PostgresRunStorage,
    PostgresSessionStorage,
)

# ===================================================================
# FakePostgresPool — in-memory replacement for unit tests
# ===================================================================


class _FakeRecord(dict):
    """Dict subclass mimicking asyncpg.Record (subscript access)."""


class _FakeTransaction:
    async def __aenter__(self):
        return self

    async def __aexit__(self, *a):
        pass


class _FakeConnection:
    def __init__(self, pool: FakePostgresPool) -> None:
        self._pool = pool

    def transaction(self):
        return _FakeTransaction()

    async def execute(self, query, *args):
        return await self._pool.execute(query, *args)

    async def fetchrow(self, query, *args):
        return await self._pool.fetchrow(query, *args)

    async def fetchval(self, query, *args):
        return await self._pool.fetchval(query, *args)


class _FakeAcquireContext:
    """Both awaitable and async context manager (like asyncpg PoolAcquireContext)."""

    def __init__(self, conn: _FakeConnection) -> None:
        self._conn = conn

    def __await__(self):
        async def _resolve():
            return self._conn

        return _resolve().__await__()

    async def __aenter__(self):
        return self._conn

    async def __aexit__(self, *a):
        pass


class FakePostgresPool:
    """In-memory PostgresPool replacement routing SQL by pattern matching."""

    def __init__(self) -> None:
        self.runs: dict[str, bool] = {}
        self.run_events: dict[str, list[dict]] = {}
        self.run_artifacts: dict[tuple[str, str], dict] = {}
        self.run_meta: dict[str, dict] = {}
        self.run_summaries: dict[str, dict] = {}
        self._ledger: list[dict] = []
        self._ledger_id_seq = 0
        self.sessions: dict[str, dict] = {}
        self.session_events: dict[str, list[dict]] = {}
        self._locks: set[str] = set()
        self._pool: Any = None
        self._lock = asyncio.Lock()
        self._schema_applied = True

    async def _ensure_pool(self):
        return self

    def acquire(self):
        return _FakeAcquireContext(_FakeConnection(self))

    async def release(self, conn):
        pass

    async def close(self):
        pass

    # --- helpers ---

    def _parse_date(self, ts_str: str) -> date_type:
        return datetime.fromisoformat(ts_str).date()

    def _filter_ledger(self, query: str, args: tuple) -> list[dict]:
        entries = list(self._ledger)
        q = query.upper()
        if "TS::DATE" in q and args:
            entries = [e for e in entries if self._parse_date(e["ts"]) == args[0]]
        elif "RUN_ID = $1" in q and args:
            entries = [e for e in entries if e["run_id"] == args[0]]
        return entries

    # --- query dispatch ---

    async def execute(self, query: str, *args) -> str:
        q = query.upper().strip()

        if "PG_ADVISORY_UNLOCK" in q:
            if args:
                self._locks.discard(args[0])
            return "SELECT"
        if "PG_ADVISORY" in q:
            return "SELECT"

        if "INTO RUNS " in q and "RUN_EVENTS" not in q:
            self.runs[args[0]] = True
            return "INSERT"

        if "INTO RUN_EVENTS" in q:
            run_id, seq, prev_hash, hash_, payload_json = args
            payload = json.loads(payload_json) if isinstance(payload_json, str) else payload_json
            self.run_events.setdefault(run_id, []).append(
                {"seq": seq, "prev_hash": prev_hash, "hash": hash_, "payload": payload}
            )
            return "INSERT"

        if "INTO RUN_ARTIFACTS" in q:
            run_id, filename = args[0], args[1]
            # Detect S3 path vs PG path by 3rd arg type:
            # S3: args = (run_id, filename, key:str, hash, size, kind) — content=NULL
            # PG: args = (run_id, filename, data:bytes, hash, size, kind) — storage_key=NULL
            if isinstance(args[2], bytes):
                # PG path
                content, sha256_hash, size, kind = args[2], args[3], args[4], args[5]
                storage_key = None
            else:
                # S3 path
                storage_key, sha256_hash, size, kind = args[2], args[3], args[4], args[5]
                content = None
            self.run_artifacts[(run_id, filename)] = {
                "filename": filename,
                "content": content,
                "storage_key": storage_key,
                "sha256": sha256_hash,
                "size_bytes": size,
                "kind": kind,
            }
            return "INSERT"

        if "INTO RUN_META" in q:
            run_id, meta_json = args
            self.run_meta[run_id] = (
                json.loads(meta_json) if isinstance(meta_json, str) else meta_json
            )
            return "INSERT"

        if "INTO RUN_SUMMARIES" in q:
            run_id, summary_json = args
            self.run_summaries[run_id] = (
                json.loads(summary_json) if isinstance(summary_json, str) else summary_json
            )
            return "INSERT"

        if "INTO LEDGER_ENTRIES" in q:
            self._ledger_id_seq += 1
            self._ledger.append(
                {
                    "id": self._ledger_id_seq,
                    "ts": args[0],
                    "run_id": args[1],
                    "stage": args[2],
                    "provider": args[3],
                    "model": args[4],
                    "input_tokens": args[5],
                    "output_tokens": args[6],
                    "total_tokens": args[7],
                    "estimated_usd": args[8],
                    "latency_ms": args[9],
                    "price_per_1k_in": args[10],
                    "price_per_1k_out": args[11],
                    "currency": args[12],
                }
            )
            return "INSERT"

        if "INTO SESSIONS " in q and "SESSION_EVENTS" not in q:
            sid, meta_json = args
            meta = json.loads(meta_json) if isinstance(meta_json, str) else meta_json
            self.sessions[sid] = {
                "meta": meta,
                "updated_at": datetime.now(tz=UTC).isoformat(),
            }
            return "INSERT"

        if "INTO SESSION_EVENTS" in q:
            sid, event_json = args
            event = json.loads(event_json) if isinstance(event_json, str) else event_json
            self.session_events.setdefault(sid, []).append(event)
            return "INSERT"

        return "OK"

    async def fetch(self, query: str, *args) -> list[Any]:
        q = query.upper().strip()

        if "PAYLOAD FROM RUN_EVENTS" in q:
            events = sorted(self.run_events.get(args[0], []), key=lambda e: e["seq"])
            return [_FakeRecord({"payload": e["payload"]}) for e in events]

        if "FROM RUN_ARTIFACTS" in q:
            arts = sorted(
                [v for (rid, _), v in self.run_artifacts.items() if rid == args[0]],
                key=lambda a: a["filename"],
            )
            return [_FakeRecord(a) for a in arts]

        if "RUN_ID FROM RUNS" in q:
            return [_FakeRecord({"run_id": rid}) for rid in sorted(self.runs)]

        if "GROUP BY MODEL" in q:
            filtered = self._filter_ledger(query, args)
            counts: dict[str, int] = {}
            for e in filtered:
                counts[e["model"]] = counts.get(e["model"], 0) + 1
            return [_FakeRecord({"model": m, "cnt": c}) for m, c in counts.items()]

        if "ORDER BY ID DESC" in q:
            n = args[0]
            return [_FakeRecord(e) for e in reversed(self._ledger[-n:])]

        if "FROM LEDGER_ENTRIES" in q and "ORDER BY TS" in q:
            return [_FakeRecord(e) for e in self._filter_ledger(query, args)]

        if "EVENT FROM SESSION_EVENTS" in q:
            return [_FakeRecord({"event": e}) for e in self.session_events.get(args[0], [])]

        if "SESSION_ID FROM SESSIONS" in q:
            n = args[0] if args else 20
            items = sorted(self.sessions.items(), key=lambda x: x[1]["updated_at"], reverse=True)
            return [_FakeRecord({"session_id": sid}) for sid, _ in items[:n]]

        return []

    async def fetchrow(self, query: str, *args) -> Any:
        q = query.upper().strip()

        if "CONTENT, STORAGE_KEY FROM RUN_ARTIFACTS" in q:
            art = self.run_artifacts.get((args[0], args[1]))
            if art is None:
                return None
            return _FakeRecord({"content": art["content"], "storage_key": art["storage_key"]})

        if "HASH, SEQ FROM RUN_EVENTS" in q:
            events = self.run_events.get(args[0], [])
            if not events:
                return None
            tip = max(events, key=lambda e: e["seq"])
            return _FakeRecord({"hash": tip["hash"], "seq": tip["seq"]})

        if "META FROM RUN_META" in q:
            meta = self.run_meta.get(args[0])
            return _FakeRecord({"meta": meta}) if meta is not None else None

        if "SUMMARY FROM RUN_SUMMARIES" in q:
            summary = self.run_summaries.get(args[0])
            return _FakeRecord({"summary": summary}) if summary is not None else None

        if "COALESCE" in q and "SUM" in q:
            filtered = self._filter_ledger(query, args)
            return _FakeRecord(
                {
                    "input_tokens": sum(e["input_tokens"] for e in filtered),
                    "output_tokens": sum(e["output_tokens"] for e in filtered),
                    "total_tokens": sum(e["total_tokens"] for e in filtered),
                    "estimated_usd": sum(e["estimated_usd"] for e in filtered),
                    "llm_calls": len(filtered),
                }
            )

        if "META FROM SESSIONS" in q:
            sess = self.sessions.get(args[0])
            return _FakeRecord({"meta": sess["meta"]}) if sess else None

        return None

    async def fetchval(self, query: str, *args) -> Any:
        q = query.upper().strip()

        if "COUNT(*)" in q and "LEDGER_ENTRIES" in q:
            return len(self._ledger)

        if "PG_TRY_ADVISORY_LOCK" in q:
            sid = args[0]
            if sid in self._locks:
                return False
            self._locks.add(sid)
            return True

        return None


# ===================================================================
# Fixtures
# ===================================================================


@pytest.fixture
def fake_pool():
    return FakePostgresPool()


@pytest.fixture
def run_storage(fake_pool):
    return PostgresRunStorage(fake_pool)


@pytest.fixture
def ledger_storage(fake_pool):
    return PostgresLedgerStorage(fake_pool)


@pytest.fixture
def session_storage(fake_pool):
    return PostgresSessionStorage(fake_pool)


def _make_usage_entry(**overrides) -> UsageEntry:
    defaults = {
        "ts": datetime.now(tz=UTC).isoformat(),
        "run_id": "run-001",
        "stage": "planner",
        "provider": "anthropic",
        "model": "claude-3-haiku",
        "input_tokens": 100,
        "output_tokens": 50,
        "total_tokens": 150,
        "estimated_usd": 0.001,
        "latency_ms": 200,
        "price_per_1k_input": 0.00025,
        "price_per_1k_output": 0.00125,
        "currency": "USD",
    }
    defaults.update(overrides)
    return UsageEntry(**defaults)


def _make_session_meta(**overrides) -> SessionMeta:
    defaults = {
        "session_id": "sess-001",
        "created_at": datetime.now(tz=UTC).isoformat(),
        "updated_at": datetime.now(tz=UTC).isoformat(),
        "status": "RUNNING",
        "current_goal_index": 0,
        "goals": [GoalSpec(id="g1", goal="Build feature X", workspace="/tmp/ws")],
        "runs": [GoalRunInfo(goal_id="g1", run_id="run-001", status="running")],
        "last_block_reason": "",
        "config": {"key": "value"},
        "max_concurrency": 2,
        "continue_on_fail": True,
    }
    defaults.update(overrides)
    return SessionMeta(**defaults)


# ===================================================================
# PostgresRunStorage
# ===================================================================


class TestPostgresRunStorage:
    @pytest.mark.asyncio
    async def test_create_run(self, run_storage, fake_pool):
        await run_storage.create_run("run-001")
        assert "run-001" in fake_pool.runs

    @pytest.mark.asyncio
    async def test_create_run_idempotent(self, run_storage, fake_pool):
        await run_storage.create_run("run-001")
        await run_storage.create_run("run-001")
        assert "run-001" in fake_pool.runs

    @pytest.mark.asyncio
    async def test_append_and_read_events(self, run_storage):
        await run_storage.create_run("run-001")
        h1 = await run_storage.append_event("run-001", {"event": "PLAN", "goal": "test"})
        h2 = await run_storage.append_event("run-001", {"event": "STEP", "step": 1})

        events = await run_storage.read_events("run-001")
        assert len(events) == 2
        assert events[0]["event"] == "PLAN"
        assert events[0]["_seq"] == 1
        assert events[0]["_hash"] == h1
        assert events[1]["event"] == "STEP"
        assert events[1]["_seq"] == 2
        assert events[1]["_hash"] == h2
        assert events[1]["_prev_hash"] == h1

    @pytest.mark.asyncio
    async def test_chain_tip_genesis(self, run_storage):
        tip_hash, seq = await run_storage.get_chain_tip("run-nonexistent")
        assert tip_hash == _GENESIS_HASH
        assert seq == 0

    @pytest.mark.asyncio
    async def test_chain_tip_after_events(self, run_storage):
        await run_storage.create_run("run-001")
        await run_storage.append_event("run-001", {"event": "PLAN"})
        h2 = await run_storage.append_event("run-001", {"event": "STEP"})

        tip_hash, seq = await run_storage.get_chain_tip("run-001")
        assert tip_hash == h2
        assert seq == 2

    @pytest.mark.asyncio
    async def test_verify_chain_ok(self, run_storage):
        await run_storage.create_run("run-001")
        await run_storage.append_event("run-001", {"event": "PLAN", "goal": "test"})
        await run_storage.append_event("run-001", {"event": "STEP", "step": 1})

        result = await run_storage.verify_chain("run-001")
        assert result.ok is True
        assert result.errors == []
        assert result.seq == 2

    @pytest.mark.asyncio
    async def test_verify_chain_tampered(self, run_storage, fake_pool):
        await run_storage.create_run("run-001")
        await run_storage.append_event("run-001", {"event": "PLAN", "goal": "test"})
        await run_storage.append_event("run-001", {"event": "STEP", "step": 1})

        # Tamper with first event payload
        fake_pool.run_events["run-001"][0]["payload"]["goal"] = "tampered"

        result = await run_storage.verify_chain("run-001")
        assert result.ok is False
        assert len(result.errors) > 0

    @pytest.mark.asyncio
    async def test_verify_chain_empty(self, run_storage):
        result = await run_storage.verify_chain("run-nonexistent")
        assert result.ok is False
        assert "No events" in result.errors[0]

    @pytest.mark.asyncio
    async def test_write_meta_and_read(self, run_storage):
        await run_storage.create_run("run-001")
        await run_storage.write_meta("run-001", {"goal": "test", "steps": 5})

        meta = await run_storage.read_meta("run-001")
        assert meta == {"goal": "test", "steps": 5}

    @pytest.mark.asyncio
    async def test_write_summary_and_read(self, run_storage):
        await run_storage.create_run("run-001")
        await run_storage.write_summary("run-001", {"result": "success"})

        summary = await run_storage.read_summary("run-001")
        assert summary == {"result": "success"}

    @pytest.mark.asyncio
    async def test_read_missing_meta(self, run_storage):
        assert await run_storage.read_meta("nonexistent") == {}

    @pytest.mark.asyncio
    async def test_read_missing_summary(self, run_storage):
        assert await run_storage.read_summary("nonexistent") == {}

    @pytest.mark.asyncio
    async def test_list_runs(self, run_storage):
        await run_storage.create_run("run-003")
        await run_storage.create_run("run-001")
        await run_storage.create_run("run-002")

        assert await run_storage.list_runs() == ["run-001", "run-002", "run-003"]

    @pytest.mark.asyncio
    async def test_write_artifact_text(self, run_storage, fake_pool):
        await run_storage.create_run("run-001")
        sha = await run_storage.write_artifact("run-001", "readme.md", "# Hello")

        assert sha
        art = fake_pool.run_artifacts[("run-001", "readme.md")]
        assert art["kind"] == "text"
        assert art["content"] == b"# Hello"

    @pytest.mark.asyncio
    async def test_write_artifact_binary(self, run_storage, fake_pool):
        await run_storage.create_run("run-001")
        data = b"\x89PNG\r\n\x1a\n"
        sha = await run_storage.write_artifact("run-001", "image.png", data)

        assert sha
        art = fake_pool.run_artifacts[("run-001", "image.png")]
        assert art["kind"] == "binary"
        assert art["content"] == data

    @pytest.mark.asyncio
    async def test_write_manifest(self, run_storage):
        await run_storage.create_run("run-001")
        await run_storage.write_artifact("run-001", "output.txt", "result data")
        await run_storage.write_artifact("run-001", "log.json", '{"ok": true}')

        manifest = await run_storage.write_manifest("run-001")
        assert manifest["run_id"] == "run-001"
        assert manifest["artifact_count"] == 2
        assert "manifest_sha256" in manifest
        assert len(manifest["artifacts"]) == 2

        events = await run_storage.read_events("run-001")
        manifest_events = [e for e in events if e.get("event") == "MANIFEST_WRITTEN"]
        assert len(manifest_events) == 1


# ===================================================================
# PostgresLedgerStorage
# ===================================================================


class TestPostgresLedgerStorage:
    @pytest.mark.asyncio
    async def test_record_and_recent(self, ledger_storage):
        e1 = _make_usage_entry(run_id="run-001", input_tokens=100)
        e2 = _make_usage_entry(run_id="run-002", input_tokens=200)
        await ledger_storage.record(e1)
        await ledger_storage.record(e2)

        recent = await ledger_storage.recent(10)
        assert len(recent) == 2
        assert recent[0].run_id == "run-001"
        assert recent[1].run_id == "run-002"

    @pytest.mark.asyncio
    async def test_totals_for_day(self, ledger_storage):
        today = datetime.now(tz=UTC).date()
        e1 = _make_usage_entry(
            input_tokens=100, output_tokens=50, total_tokens=150, estimated_usd=0.01
        )
        e2 = _make_usage_entry(
            input_tokens=200, output_tokens=100, total_tokens=300, estimated_usd=0.02
        )
        await ledger_storage.record(e1)
        await ledger_storage.record(e2)

        totals = await ledger_storage.totals_for_day(today)
        assert totals.input_tokens == 300
        assert totals.output_tokens == 150
        assert totals.llm_calls == 2
        assert "claude-3-haiku" in totals.models

    @pytest.mark.asyncio
    async def test_totals_for_run(self, ledger_storage):
        e1 = _make_usage_entry(run_id="run-A", input_tokens=100, estimated_usd=0.01)
        e2 = _make_usage_entry(run_id="run-A", input_tokens=200, estimated_usd=0.02)
        e3 = _make_usage_entry(run_id="run-B", input_tokens=500, estimated_usd=0.05)
        await ledger_storage.record(e1)
        await ledger_storage.record(e2)
        await ledger_storage.record(e3)

        totals = await ledger_storage.totals_for_run("run-A")
        assert totals.input_tokens == 300
        assert totals.llm_calls == 2
        assert abs(totals.estimated_usd - 0.03) < 1e-9

    @pytest.mark.asyncio
    async def test_entries_for_day(self, ledger_storage):
        today = datetime.now(tz=UTC).date()
        await ledger_storage.record(_make_usage_entry(run_id="run-001"))
        await ledger_storage.record(_make_usage_entry(run_id="run-002"))

        entries = await ledger_storage.entries_for_day(today)
        assert len(entries) == 2

    @pytest.mark.asyncio
    async def test_calls_in_last_hour(self, ledger_storage):
        await ledger_storage.record(_make_usage_entry())
        await ledger_storage.record(_make_usage_entry())
        await ledger_storage.record(_make_usage_entry())

        assert await ledger_storage.calls_in_last_hour() == 3

    @pytest.mark.asyncio
    async def test_empty_totals(self, ledger_storage):
        totals = await ledger_storage.totals_for_day(datetime.now(tz=UTC).date())
        assert totals.input_tokens == 0
        assert totals.llm_calls == 0
        assert totals.estimated_usd == 0.0


# ===================================================================
# PostgresSessionStorage
# ===================================================================


class TestPostgresSessionStorage:
    @pytest.mark.asyncio
    async def test_save_and_load_roundtrip(self, session_storage):
        meta = _make_session_meta()
        await session_storage.save_session(meta)

        loaded = await session_storage.load_session("sess-001")
        assert loaded.session_id == "sess-001"
        assert loaded.status == "RUNNING"
        assert loaded.max_concurrency == 2
        assert loaded.continue_on_fail is True
        assert len(loaded.goals) == 1
        assert loaded.goals[0].id == "g1"
        assert loaded.goals[0].goal == "Build feature X"
        assert len(loaded.runs) == 1
        assert loaded.runs[0].goal_id == "g1"

    @pytest.mark.asyncio
    async def test_load_missing_raises(self, session_storage):
        with pytest.raises(FileNotFoundError, match="Session not found"):
            await session_storage.load_session("nonexistent")

    @pytest.mark.asyncio
    async def test_append_and_read_events(self, session_storage):
        await session_storage.append_event("sess-001", {"action": "start"})
        await session_storage.append_event("sess-001", {"action": "step", "n": 1})

        events = await session_storage.read_events("sess-001")
        assert len(events) == 2
        assert events[0]["action"] == "start"
        assert events[1]["action"] == "step"
        assert "timestamp" in events[0]

    @pytest.mark.asyncio
    async def test_list_sessions(self, session_storage):
        await session_storage.save_session(_make_session_meta(session_id="sess-A"))
        await session_storage.save_session(_make_session_meta(session_id="sess-B"))

        sessions = await session_storage.list_sessions(n=10)
        assert len(sessions) == 2
        assert set(sessions) == {"sess-A", "sess-B"}

    @pytest.mark.asyncio
    async def test_lock_acquire_release(self, session_storage):
        assert await session_storage.acquire_lock("sess-001") is True
        await session_storage.release_lock("sess-001")
        assert await session_storage.acquire_lock("sess-001") is True

    @pytest.mark.asyncio
    async def test_lock_conflict(self, session_storage):
        assert await session_storage.acquire_lock("sess-001") is True
        assert await session_storage.acquire_lock("sess-001") is False


# ===================================================================
# Factory
# ===================================================================


class TestFactory:
    def test_postgres_backend_creates_storage(self, tmp_path):
        from owlmind.storage import create_storage
        from owlmind.storage.file import FileQueueStorage

        storage = create_storage(
            backend="postgres",
            postgres_dsn="postgresql://test:test@localhost/testdb",
            queue_dir=str(tmp_path / "queue"),
        )
        assert isinstance(storage.runs, PostgresRunStorage)
        assert isinstance(storage.ledger, PostgresLedgerStorage)
        assert isinstance(storage.sessions, PostgresSessionStorage)
        assert isinstance(storage.queue, FileQueueStorage)

    def test_postgres_without_dsn_raises(self):
        from owlmind.storage import create_storage

        with pytest.raises(ValueError, match="postgres_dsn is required"):
            create_storage(backend="postgres")

    def test_postgres_uses_file_for_queue(self, tmp_path):
        from owlmind.storage import create_storage
        from owlmind.storage.file import FileQueueStorage

        storage = create_storage(
            backend="postgres",
            postgres_dsn="postgresql://test/db",
            queue_dir=str(tmp_path / "q"),
        )
        assert isinstance(storage.queue, FileQueueStorage)


# ===================================================================
# PostgresPool
# ===================================================================


class TestPostgresPool:
    def test_lazy_init(self):
        pool = PostgresPool("postgresql://test/db")
        assert pool._pool is None
        assert pool._schema_applied is False

    @pytest.mark.asyncio
    async def test_close_noop_when_not_connected(self):
        pool = PostgresPool("postgresql://test/db")
        await pool.close()
        assert pool._pool is None
