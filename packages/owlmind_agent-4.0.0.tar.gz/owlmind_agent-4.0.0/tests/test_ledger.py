"""Tests for Usage Ledger — append-only JSONL token tracking."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from pathlib import Path

from owlmind.ledger import UsageEntry, UsageLedger, UsageTotals


def _make_entry(**overrides: object) -> UsageEntry:
    defaults = {
        "ts": datetime.now(tz=UTC).isoformat(),
        "run_id": "cycle-test123",
        "stage": "planner",
        "provider": "openai",
        "model": "gpt-4o-test",
        "input_tokens": 100,
        "output_tokens": 50,
        "total_tokens": 150,
        "estimated_usd": 0.00075,
        "latency_ms": 500,
        "price_per_1k_input": 0.0025,
        "price_per_1k_output": 0.01,
        "currency": "USD",
    }
    defaults.update(overrides)
    return UsageEntry(**defaults)  # type: ignore[arg-type]


class TestUsageEntry:
    def test_to_dict(self) -> None:
        entry = _make_entry()
        d = entry.to_dict()
        assert d["run_id"] == "cycle-test123"
        assert d["stage"] == "planner"
        assert d["input_tokens"] == 100

    def test_from_dict(self) -> None:
        data = {
            "ts": "2026-01-01T00:00:00",
            "run_id": "r1",
            "stage": "judge",
            "provider": "openai",
            "model": "gpt-4o",
            "input_tokens": 200,
            "output_tokens": 100,
            "total_tokens": 300,
            "estimated_usd": 0.0015,
            "latency_ms": 750,
            "price_per_1k_input": 0.0025,
            "price_per_1k_output": 0.01,
        }
        entry = UsageEntry.from_dict(data)
        assert entry.run_id == "r1"
        assert entry.total_tokens == 300


class TestUsageTotals:
    def test_defaults(self) -> None:
        t = UsageTotals()
        assert t.total_tokens == 0
        assert t.llm_calls == 0
        assert t.models == {}

    def test_to_dict(self) -> None:
        t = UsageTotals(input_tokens=100, llm_calls=2)
        d = t.to_dict()
        assert d["input_tokens"] == 100
        assert d["llm_calls"] == 2


class TestUsageLedger:
    def test_record_and_read(self, tmp_path: Path) -> None:
        ledger = UsageLedger(tmp_path / "ledger")
        entry = _make_entry()
        ledger.record(entry)

        entries = ledger._read_all()
        assert len(entries) == 1
        assert entries[0].run_id == "cycle-test123"

    def test_multiple_records(self, tmp_path: Path) -> None:
        ledger = UsageLedger(tmp_path / "ledger")
        for i in range(5):
            ledger.record(_make_entry(input_tokens=100 + i))

        entries = ledger._read_all()
        assert len(entries) == 5

    def test_totals_for_day_today(self, tmp_path: Path) -> None:
        ledger = UsageLedger(tmp_path / "ledger")
        ledger.record(_make_entry(input_tokens=100, output_tokens=50, total_tokens=150))
        ledger.record(_make_entry(input_tokens=200, output_tokens=100, total_tokens=300))

        totals = ledger.totals_for_day()
        assert totals.input_tokens == 300
        assert totals.output_tokens == 150
        assert totals.total_tokens == 450
        assert totals.llm_calls == 2

    def test_totals_for_day_different_date(self, tmp_path: Path) -> None:
        ledger = UsageLedger(tmp_path / "ledger")
        yesterday = (datetime.now(tz=UTC) - timedelta(days=1)).isoformat()
        ledger.record(_make_entry(ts=yesterday, total_tokens=500))

        # Today should be empty
        today_totals = ledger.totals_for_day()
        assert today_totals.total_tokens == 0

        # Yesterday should have data
        yesterday_date = (datetime.now(tz=UTC) - timedelta(days=1)).date()
        y_totals = ledger.totals_for_day(yesterday_date)
        assert y_totals.total_tokens == 500

    def test_totals_for_run(self, tmp_path: Path) -> None:
        ledger = UsageLedger(tmp_path / "ledger")
        ledger.record(_make_entry(run_id="run-A", total_tokens=100))
        ledger.record(_make_entry(run_id="run-B", total_tokens=200))
        ledger.record(_make_entry(run_id="run-A", total_tokens=300))

        a_totals = ledger.totals_for_run("run-A")
        assert a_totals.total_tokens == 400
        assert a_totals.llm_calls == 2

        b_totals = ledger.totals_for_run("run-B")
        assert b_totals.total_tokens == 200

    def test_recent(self, tmp_path: Path) -> None:
        ledger = UsageLedger(tmp_path / "ledger")
        for i in range(10):
            ledger.record(_make_entry(input_tokens=i * 10))

        recent = ledger.recent(3)
        assert len(recent) == 3
        assert recent[-1].input_tokens == 90

    def test_empty_ledger(self, tmp_path: Path) -> None:
        ledger = UsageLedger(tmp_path / "ledger")
        assert ledger.totals_for_day().total_tokens == 0
        assert ledger.totals_for_run("nope").llm_calls == 0
        assert ledger.recent() == []

    def test_calls_in_last_hour(self, tmp_path: Path) -> None:
        ledger = UsageLedger(tmp_path / "ledger")
        # Recent entry
        ledger.record(_make_entry())
        assert ledger.calls_in_last_hour() >= 1

    def test_models_aggregation(self, tmp_path: Path) -> None:
        ledger = UsageLedger(tmp_path / "ledger")
        ledger.record(_make_entry(model="gpt-4o"))
        ledger.record(_make_entry(model="gpt-4o"))
        ledger.record(_make_entry(model="gpt-3.5"))

        totals = ledger.totals_for_day()
        assert totals.models["gpt-4o"] == 2
        assert totals.models["gpt-3.5"] == 1


class TestCallsInLastHourInvalidTs:
    """Lines 159-160: ValueError on bad timestamp → continue."""

    def test_invalid_timestamp_skipped(self, tmp_path: Path) -> None:
        ledger = UsageLedger(tmp_path / "ledger")
        # Write an entry with a corrupt timestamp directly
        import json

        entry_line = json.dumps(
            {
                "ts": "not-a-timestamp",
                "run_id": "r1",
                "stage": "planner",
                "model": "claude-3",
                "input_tokens": 100,
                "output_tokens": 50,
                "cache_read_tokens": 0,
                "cache_write_tokens": 0,
                "estimated_usd": 0.001,
            }
        )
        (tmp_path / "ledger" / "usage.jsonl").parent.mkdir(parents=True, exist_ok=True)
        (tmp_path / "ledger" / "usage.jsonl").write_text(entry_line + "\n")
        # Should not raise; corrupted entry is skipped
        count = ledger.calls_in_last_hour()
        assert count == 0
