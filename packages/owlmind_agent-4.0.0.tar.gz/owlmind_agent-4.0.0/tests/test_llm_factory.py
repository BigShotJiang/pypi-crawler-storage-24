"""Tests for owlmind.llm.factory — LLM router factory."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from owlmind.llm.factory import build_llm_router


class _FakeConfig:
    """Minimal config stub for factory tests."""

    class _Provider:
        def __init__(self, *, enabled: bool = False) -> None:
            self.enabled = enabled
            self.api_key = "test-key"
            self.timeout_sec = 10
            self.model = "test-model"
            self.planner_model = "test-planner"
            self.judge_model = "test-judge"
            self.max_output_tokens = 1000

    class _Router:
        planner_providers = ["openai", "anthropic"]
        judge_providers = ["openai", "anthropic"]

    class _LocalProvider:
        def __init__(self, *, enabled: bool = False) -> None:
            self.enabled = enabled
            self.base_url = "http://localhost:11434"
            self.model = "test-model"
            self.max_output_tokens = 1000
            self.timeout_sec = 120

    def __init__(
        self,
        *,
        openai: bool = False,
        anthropic: bool = False,
        gemini: bool = False,
        ollama: bool = False,
        llamacpp: bool = False,
    ) -> None:
        self.openai = self._Provider(enabled=openai)
        self.anthropic = self._Provider(enabled=anthropic)
        self.gemini = self._Provider(enabled=gemini)
        self.ollama = self._LocalProvider(enabled=ollama)
        self.llamacpp = self._LocalProvider(enabled=llamacpp)
        self.router = self._Router()


class TestBuildLLMRouter:
    def test_no_providers_raises(self) -> None:
        cfg = _FakeConfig()
        with pytest.raises(RuntimeError, match="No LLM providers available"):
            build_llm_router(cfg)

    @patch("owlmind.llm.openai_driver.is_openai_available", return_value=True)
    @patch("owlmind.llm.openai_driver.OpenAIDriver", new_callable=lambda: MagicMock)
    def test_openai_only(self, mock_driver: MagicMock, mock_avail: MagicMock) -> None:
        cfg = _FakeConfig(openai=True)
        router = build_llm_router(cfg)
        assert "openai" in router.available_providers()

    @patch("owlmind.llm.openai_driver.is_openai_available", return_value=True)
    @patch("owlmind.llm.openai_driver.OpenAIDriver", new_callable=lambda: MagicMock)
    def test_force_planner_not_available(
        self, mock_driver: MagicMock, mock_avail: MagicMock
    ) -> None:
        cfg = _FakeConfig(openai=True)
        with pytest.raises(RuntimeError, match="not available"):
            build_llm_router(cfg, force_planner="gemini")

    @patch("owlmind.llm.openai_driver.is_openai_available", return_value=True)
    @patch("owlmind.llm.openai_driver.OpenAIDriver", new_callable=lambda: MagicMock)
    def test_force_planner_available(self, mock_driver: MagicMock, mock_avail: MagicMock) -> None:
        cfg = _FakeConfig(openai=True)
        router = build_llm_router(cfg, force_planner="openai")
        assert router is not None

    @patch("owlmind.llm.openai_driver.is_openai_available", return_value=True)
    @patch("owlmind.llm.openai_driver.OpenAIDriver", new_callable=lambda: MagicMock)
    def test_force_judge_not_available(self, mock_driver: MagicMock, mock_avail: MagicMock) -> None:
        cfg = _FakeConfig(openai=True)
        with pytest.raises(RuntimeError, match="not available"):
            build_llm_router(cfg, force_judge="anthropic")

    @patch("owlmind.llm.openai_driver.is_openai_available", return_value=True)
    @patch("owlmind.llm.openai_driver.OpenAIDriver", new_callable=lambda: MagicMock)
    def test_force_judge_available(self, mock_driver: MagicMock, mock_avail: MagicMock) -> None:
        """factory.py:70 — force_judge is in drivers → judge_providers = [force_judge]."""
        cfg = _FakeConfig(openai=True)
        router = build_llm_router(cfg, force_judge="openai")
        assert router is not None
