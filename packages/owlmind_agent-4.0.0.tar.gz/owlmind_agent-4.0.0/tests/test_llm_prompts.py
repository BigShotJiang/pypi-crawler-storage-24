"""Tests for owlmind.llm.prompts — shared prompt builders."""

from __future__ import annotations

from owlmind.llm.prompts import (
    JUDGE_SYSTEM,
    PLANNER_SYSTEM,
    build_judge_prompts,
    build_planner_prompts,
)


class TestBuildPlannerPrompts:
    def test_returns_tuple(self) -> None:
        sys, user = build_planner_prompts({"goal": "Add tests"})
        assert isinstance(sys, str)
        assert isinstance(user, str)

    def test_system_prompt_is_planner(self) -> None:
        sys, _ = build_planner_prompts({"goal": "x"})
        assert sys == PLANNER_SYSTEM

    def test_user_prompt_contains_goal(self) -> None:
        _, user = build_planner_prompts({"goal": "Fix the login bug"})
        assert "Fix the login bug" in user

    def test_user_prompt_contains_constraints(self) -> None:
        _, user = build_planner_prompts(
            {
                "goal": "x",
                "constraints": ["no force push", "use ruff"],
            }
        )
        assert "no force push" in user
        assert "use ruff" in user

    def test_defaults_for_missing_keys(self) -> None:
        sys, user = build_planner_prompts({})
        assert "Run ID: ?" in user
        assert sys == PLANNER_SYSTEM

    def test_memory_context_appended_to_user_prompt(self) -> None:
        """Line 51: memory_context non-empty → appended to user_prompt."""
        _, user = build_planner_prompts(
            {"goal": "Fix tests", "memory_context": "Past lesson: always run linter"}
        )
        assert "Past lesson: always run linter" in user


class TestBuildJudgePrompts:
    def test_returns_tuple(self) -> None:
        sys, user = build_judge_prompts({"goal": "Add tests"})
        assert isinstance(sys, str)
        assert isinstance(user, str)

    def test_system_prompt_is_judge(self) -> None:
        sys, _ = build_judge_prompts({"goal": "x"})
        assert sys == JUDGE_SYSTEM

    def test_user_prompt_contains_verdict_context(self) -> None:
        _, user = build_judge_prompts(
            {
                "goal": "Add tests",
                "planner_plan_summary": ["step 1"],
                "worker_done_summary": ["done 1"],
                "verify_results_summary": ["pytest: PASS"],
            }
        )
        assert "step 1" in user
        assert "done 1" in user
        assert "pytest: PASS" in user
