"""Tests for HardFailChecker — secrets, forbidden paths, size limits."""

from __future__ import annotations

from pathlib import Path

from owlmind.agent.rules import HardFailChecker, JudgeRules, parse_numstat


class TestParseNumstat:
    def test_basic(self) -> None:
        numstat = "10\t5\tsrc/main.py\n3\t0\tsrc/utils.py\n"
        files, ins, dels = parse_numstat(numstat)
        assert files == 2
        assert ins == 13
        assert dels == 5

    def test_binary_files(self) -> None:
        numstat = "-\t-\timage.png\n5\t2\tREADME.md\n"
        files, ins, dels = parse_numstat(numstat)
        assert files == 2
        assert ins == 5
        assert dels == 2

    def test_empty(self) -> None:
        files, ins, dels = parse_numstat("")
        assert files == 0
        assert ins == 0
        assert dels == 0


class TestJudgeRules:
    def test_defaults(self) -> None:
        rules = JudgeRules.defaults()
        assert len(rules.secret_patterns) > 0
        assert len(rules.forbidden_paths) > 0
        assert rules.max_files_changed == 20
        assert rules.max_insertions == 800
        assert rules.max_deletions == 800

    def test_from_yaml(self, tmp_path: Path) -> None:
        yaml_content = """
secret_patterns:
  - "sk-[A-Za-z0-9]{20,}"
forbidden_paths:
  - ".github/workflows/"
  - "deploy/"
size_limits:
  max_files_changed: 5
  max_insertions: 100
  max_deletions: 100
"""
        yaml_path = tmp_path / "judge_rules.yaml"
        yaml_path.write_text(yaml_content)

        rules = JudgeRules.from_yaml(yaml_path)
        assert len(rules.secret_patterns) == 1
        assert len(rules.forbidden_paths) == 2
        assert rules.max_files_changed == 5
        assert rules.max_insertions == 100

    def test_from_yaml_missing_file(self, tmp_path: Path) -> None:
        rules = JudgeRules.from_yaml(tmp_path / "nonexistent.yaml")
        assert len(rules.secret_patterns) > 0  # defaults


class TestHardFailChecker:
    def test_check_secrets_finds_sk(self) -> None:
        checker = HardFailChecker()
        diff = 'api_key = "sk-abcdefghijklmnopqrstuvwxyz1234"'
        findings = checker.check_secrets(diff)
        assert len(findings) >= 1
        assert any("Secret" in f for f in findings)

    def test_check_secrets_finds_aws_key(self) -> None:
        checker = HardFailChecker()
        diff = "aws_access_key = AKIAIOSFODNN7EXAMPLE"
        findings = checker.check_secrets(diff)
        assert len(findings) >= 1

    def test_check_secrets_finds_private_key(self) -> None:
        checker = HardFailChecker()
        diff = "-----BEGIN RSA PRIVATE KEY-----\nblahblah\n-----END RSA PRIVATE KEY-----"
        findings = checker.check_secrets(diff)
        assert len(findings) >= 1

    def test_check_secrets_finds_bearer(self) -> None:
        checker = HardFailChecker()
        diff = "Authorization: bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.xxxxx"
        findings = checker.check_secrets(diff)
        assert len(findings) >= 1

    def test_check_secrets_finds_github_token(self) -> None:
        checker = HardFailChecker()
        diff = 'token = "ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghij"'
        findings = checker.check_secrets(diff)
        assert len(findings) >= 1

    def test_check_secrets_clean(self) -> None:
        checker = HardFailChecker()
        diff = "def hello():\n    return 'world'\n"
        findings = checker.check_secrets(diff)
        assert findings == []

    def test_check_forbidden_paths(self) -> None:
        checker = HardFailChecker()
        files = [".github/workflows/ci.yml", "src/main.py"]
        findings = checker.check_forbidden_paths(files)
        assert len(findings) == 1
        assert "Forbidden path" in findings[0]

    def test_check_forbidden_paths_clean(self) -> None:
        checker = HardFailChecker()
        files = ["src/main.py", "tests/test_main.py"]
        findings = checker.check_forbidden_paths(files)
        assert findings == []

    def test_check_size_limits_over(self) -> None:
        checker = HardFailChecker()
        findings = checker.check_size_limits(files_changed=25, insertions=1000, deletions=50)
        assert len(findings) >= 2  # files + insertions

    def test_check_size_limits_ok(self) -> None:
        checker = HardFailChecker()
        findings = checker.check_size_limits(files_changed=5, insertions=100, deletions=50)
        assert findings == []

    def test_check_all_clean(self) -> None:
        checker = HardFailChecker()
        result = checker.check_all(
            diff_content="def hello(): pass\n",
            files_changed=["src/main.py"],
            numstat="5\t2\tsrc/main.py\n",
            chain_ok=True,
        )
        assert result.ok is True
        assert result.reasons == []
        assert result.risk_level == "LOW"

    def test_check_all_secret_found(self) -> None:
        checker = HardFailChecker()
        result = checker.check_all(
            diff_content='key = "sk-abcdefghijklmnopqrstuvwxyz1234"',
            chain_ok=True,
        )
        assert result.ok is False
        assert result.risk_level == "CRITICAL"

    def test_check_all_forbidden_path(self) -> None:
        checker = HardFailChecker()
        result = checker.check_all(
            files_changed=["deploy/docker-compose.yml"],
            chain_ok=True,
        )
        assert result.ok is False
        assert result.risk_level == "HIGH"

    def test_check_all_chain_broken(self) -> None:
        checker = HardFailChecker()
        result = checker.check_all(chain_ok=False)
        assert result.ok is False
        assert any("chain" in r.lower() for r in result.reasons)

    def test_check_all_size_exceeded(self) -> None:
        checker = HardFailChecker()
        # 25 files, 900 insertions each
        numstat_lines = "\n".join(f"900\t0\tsrc/file{i}.py" for i in range(25))
        result = checker.check_all(
            numstat=numstat_lines,
            chain_ok=True,
        )
        assert result.ok is False
        assert any("files" in r.lower() or "insertions" in r.lower() for r in result.reasons)


class TestCheckSizeLimitsDeletions:
    """rules.py:116 — deletions > max_deletions branch."""

    def test_deletions_exceeded_adds_finding(self) -> None:
        checker = HardFailChecker()
        # 25 files, 0 insertions, 900 deletions → exceeds default max_deletions=800
        numstat_lines = "\n".join(f"0\t900\tsrc/file{i}.py" for i in range(25))
        result = checker.check_all(numstat=numstat_lines, chain_ok=True)
        assert result.ok is False
        assert any("deletions" in r.lower() for r in result.reasons)


class TestParseNumstatValueError:
    """rules.py:166-167 — ValueError in int() → continue."""

    def test_non_numeric_insertions_skipped(self) -> None:
        # First column is non-numeric, non-"-" → int() raises ValueError → continue
        numstat = "abc\t5\tfile.py\n10\t2\tother.py\n"
        files, ins, dels = parse_numstat(numstat)
        # "abc\t5\tfile.py" hits ValueError and is skipped, but still counted as a file
        assert files == 2
        assert ins == 10  # only the valid line's insertions
        assert dels == 2
