"""Tests for owlmind.telegram.api_client — typed error handling and is_api_error helper."""

from __future__ import annotations

import json
import urllib.error
import urllib.request
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from owlmind.telegram.api_client import api_delete, api_get, api_post, is_api_error
from owlmind.telegram.context import BotContext

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _make_ctx() -> BotContext:
    """Create a minimal BotContext for testing."""
    ctx = MagicMock(spec=BotContext)
    ctx.api_base = "http://127.0.0.1:8765"
    ctx.api_key = "test-key"
    return ctx  # type: ignore[return-value]


def _mock_urlopen_json(payload: Any):
    """Patch urllib.request.urlopen to return JSON bytes."""
    mock_resp = MagicMock()
    mock_resp.read.return_value = json.dumps(payload).encode()
    mock_resp.__enter__ = lambda s: s
    mock_resp.__exit__ = MagicMock(return_value=False)
    return patch("urllib.request.urlopen", return_value=mock_resp)


def _make_http_error(code: int) -> urllib.error.HTTPError:
    """Build an HTTPError with the given status code."""
    return urllib.error.HTTPError(
        url="http://127.0.0.1:8765/test",
        code=code,
        msg=f"HTTP {code}",
        hdrs=MagicMock(),  # type: ignore[arg-type]
        fp=None,
    )


# ---------------------------------------------------------------------------
# is_api_error
# ---------------------------------------------------------------------------


class TestIsApiError:
    def test_returns_true_when_error_key_present(self) -> None:
        assert is_api_error({"error": "server_error", "status": 500}) is True

    def test_returns_true_for_any_error_value(self) -> None:
        assert is_api_error({"error": "network_error", "message": "refused"}) is True

    def test_returns_false_for_successful_response(self) -> None:
        assert is_api_error({"id": "task-001", "status": "PENDING"}) is False

    def test_returns_false_for_empty_dict(self) -> None:
        assert is_api_error({}) is False

    def test_returns_false_when_no_error_key(self) -> None:
        assert is_api_error({"items": [], "count": 0}) is False


# ---------------------------------------------------------------------------
# api_get
# ---------------------------------------------------------------------------


class TestApiGet:
    @pytest.mark.asyncio()
    async def test_success_returns_parsed_json(self) -> None:
        ctx = _make_ctx()
        payload = {"runs": [], "count": 0}
        with _mock_urlopen_json(payload):
            result = await api_get(ctx, "/api/v1/runs")
        assert result == payload

    @pytest.mark.asyncio()
    async def test_http_401_returns_auth_error(self) -> None:
        ctx = _make_ctx()
        with patch("urllib.request.urlopen", side_effect=_make_http_error(401)):
            result = await api_get(ctx, "/api/v1/runs")
        assert result == {"error": "auth_error", "status": 401}

    @pytest.mark.asyncio()
    async def test_http_403_returns_auth_error(self) -> None:
        ctx = _make_ctx()
        with patch("urllib.request.urlopen", side_effect=_make_http_error(403)):
            result = await api_get(ctx, "/api/v1/runs")
        assert result == {"error": "auth_error", "status": 403}

    @pytest.mark.asyncio()
    async def test_http_404_returns_client_error(self) -> None:
        ctx = _make_ctx()
        with patch("urllib.request.urlopen", side_effect=_make_http_error(404)):
            result = await api_get(ctx, "/api/v1/missing")
        assert result["error"] == "client_error"
        assert result["status"] == 404
        assert "message" in result

    @pytest.mark.asyncio()
    async def test_http_422_returns_client_error(self) -> None:
        ctx = _make_ctx()
        with patch("urllib.request.urlopen", side_effect=_make_http_error(422)):
            result = await api_get(ctx, "/api/v1/runs")
        assert result["error"] == "client_error"
        assert result["status"] == 422

    @pytest.mark.asyncio()
    async def test_http_500_returns_server_error(self) -> None:
        ctx = _make_ctx()
        with patch("urllib.request.urlopen", side_effect=_make_http_error(500)):
            result = await api_get(ctx, "/api/v1/runs")
        assert result["error"] == "server_error"
        assert result["status"] == 500
        assert "message" in result

    @pytest.mark.asyncio()
    async def test_http_503_returns_server_error(self) -> None:
        ctx = _make_ctx()
        with patch("urllib.request.urlopen", side_effect=_make_http_error(503)):
            result = await api_get(ctx, "/api/v1/runs")
        assert result["error"] == "server_error"
        assert result["status"] == 503

    @pytest.mark.asyncio()
    async def test_network_error_returns_network_error(self) -> None:
        ctx = _make_ctx()
        url_err = urllib.error.URLError(reason="Connection refused")
        with patch("urllib.request.urlopen", side_effect=url_err):
            result = await api_get(ctx, "/api/v1/runs")
        assert result["error"] == "network_error"
        assert "message" in result

    @pytest.mark.asyncio()
    async def test_socket_timeout_returns_timeout_error(self) -> None:
        ctx = _make_ctx()
        with patch("urllib.request.urlopen", side_effect=TimeoutError()):
            result = await api_get(ctx, "/api/v1/runs")
        assert result == {"error": "timeout_error"}

    @pytest.mark.asyncio()
    async def test_oserror_returns_network_error(self) -> None:
        ctx = _make_ctx()
        with patch("urllib.request.urlopen", side_effect=OSError("connection reset")):
            result = await api_get(ctx, "/api/v1/runs")
        assert result["error"] == "network_error"

    @pytest.mark.asyncio()
    async def test_is_api_error_true_on_http_error(self) -> None:
        ctx = _make_ctx()
        with patch("urllib.request.urlopen", side_effect=_make_http_error(500)):
            result = await api_get(ctx, "/api/v1/runs")
        assert is_api_error(result) is True

    @pytest.mark.asyncio()
    async def test_is_api_error_false_on_success(self) -> None:
        ctx = _make_ctx()
        with _mock_urlopen_json({"items": []}):
            result = await api_get(ctx, "/api/v1/queue")
        assert is_api_error(result) is False


# ---------------------------------------------------------------------------
# api_post
# ---------------------------------------------------------------------------


class TestApiPost:
    @pytest.mark.asyncio()
    async def test_success_returns_parsed_json(self) -> None:
        ctx = _make_ctx()
        payload = {"id": "task-001"}
        with _mock_urlopen_json(payload):
            result = await api_post(ctx, "/api/v1/queue", body={"goal": "fix bug"})
        assert result == payload

    @pytest.mark.asyncio()
    async def test_http_401_returns_auth_error(self) -> None:
        ctx = _make_ctx()
        with patch("urllib.request.urlopen", side_effect=_make_http_error(401)):
            result = await api_post(ctx, "/api/v1/queue", body={"goal": "test"})
        assert result == {"error": "auth_error", "status": 401}

    @pytest.mark.asyncio()
    async def test_http_403_returns_auth_error(self) -> None:
        ctx = _make_ctx()
        with patch("urllib.request.urlopen", side_effect=_make_http_error(403)):
            result = await api_post(ctx, "/api/v1/queue", body={"goal": "test"})
        assert result == {"error": "auth_error", "status": 403}

    @pytest.mark.asyncio()
    async def test_http_400_returns_client_error(self) -> None:
        ctx = _make_ctx()
        with patch("urllib.request.urlopen", side_effect=_make_http_error(400)):
            result = await api_post(ctx, "/api/v1/queue", body={})
        assert result["error"] == "client_error"
        assert result["status"] == 400

    @pytest.mark.asyncio()
    async def test_http_500_returns_server_error(self) -> None:
        ctx = _make_ctx()
        with patch("urllib.request.urlopen", side_effect=_make_http_error(500)):
            result = await api_post(ctx, "/api/v1/queue", body={"goal": "test"})
        assert result["error"] == "server_error"
        assert result["status"] == 500

    @pytest.mark.asyncio()
    async def test_network_error_returns_network_error(self) -> None:
        ctx = _make_ctx()
        url_err = urllib.error.URLError(reason="Name resolution failed")
        with patch("urllib.request.urlopen", side_effect=url_err):
            result = await api_post(ctx, "/api/v1/queue", body={"goal": "test"})
        assert result["error"] == "network_error"
        assert "message" in result

    @pytest.mark.asyncio()
    async def test_socket_timeout_returns_timeout_error(self) -> None:
        ctx = _make_ctx()
        with patch("urllib.request.urlopen", side_effect=TimeoutError()):
            result = await api_post(ctx, "/api/v1/queue", body={"goal": "test"})
        assert result == {"error": "timeout_error"}

    @pytest.mark.asyncio()
    async def test_no_body_posts_empty_bytes(self) -> None:
        ctx = _make_ctx()
        payload = {"ok": True}
        with _mock_urlopen_json(payload):
            result = await api_post(ctx, "/api/v1/sessions")
        assert result == payload

    @pytest.mark.asyncio()
    async def test_params_appended_to_url(self) -> None:
        ctx = _make_ctx()
        payload = {"ok": True}
        captured_urls: list[str] = []

        original_request = urllib.request.Request

        def capturing_request(url: str, **kwargs: Any) -> Any:
            captured_urls.append(url)
            return original_request(url, **kwargs)

        with (
            patch("urllib.request.Request", side_effect=capturing_request),
            _mock_urlopen_json(payload),
        ):
            await api_post(ctx, "/api/v1/sessions", params="workspace=/tmp")

        assert len(captured_urls) == 1
        assert "workspace=/tmp" in captured_urls[0]


# ---------------------------------------------------------------------------
# api_delete
# ---------------------------------------------------------------------------


class TestApiDelete:
    @pytest.mark.asyncio()
    async def test_success_returns_parsed_json(self) -> None:
        ctx = _make_ctx()
        payload = {"deleted": True}
        with _mock_urlopen_json(payload):
            result = await api_delete(ctx, "/api/v1/queue/item-001")
        assert result == payload

    @pytest.mark.asyncio()
    async def test_http_401_returns_auth_error(self) -> None:
        ctx = _make_ctx()
        with patch("urllib.request.urlopen", side_effect=_make_http_error(401)):
            result = await api_delete(ctx, "/api/v1/queue/item-001")
        assert result == {"error": "auth_error", "status": 401}

    @pytest.mark.asyncio()
    async def test_http_403_returns_auth_error(self) -> None:
        ctx = _make_ctx()
        with patch("urllib.request.urlopen", side_effect=_make_http_error(403)):
            result = await api_delete(ctx, "/api/v1/queue/item-001")
        assert result == {"error": "auth_error", "status": 403}

    @pytest.mark.asyncio()
    async def test_http_404_returns_client_error(self) -> None:
        ctx = _make_ctx()
        with patch("urllib.request.urlopen", side_effect=_make_http_error(404)):
            result = await api_delete(ctx, "/api/v1/queue/nonexistent")
        assert result["error"] == "client_error"
        assert result["status"] == 404

    @pytest.mark.asyncio()
    async def test_http_500_returns_server_error(self) -> None:
        ctx = _make_ctx()
        with patch("urllib.request.urlopen", side_effect=_make_http_error(500)):
            result = await api_delete(ctx, "/api/v1/queue/item-001")
        assert result["error"] == "server_error"
        assert result["status"] == 500

    @pytest.mark.asyncio()
    async def test_network_error_returns_network_error(self) -> None:
        ctx = _make_ctx()
        url_err = urllib.error.URLError(reason="Connection refused")
        with patch("urllib.request.urlopen", side_effect=url_err):
            result = await api_delete(ctx, "/api/v1/queue/item-001")
        assert result["error"] == "network_error"

    @pytest.mark.asyncio()
    async def test_socket_timeout_returns_timeout_error(self) -> None:
        ctx = _make_ctx()
        with patch("urllib.request.urlopen", side_effect=TimeoutError()):
            result = await api_delete(ctx, "/api/v1/queue/item-001")
        assert result == {"error": "timeout_error"}

    @pytest.mark.asyncio()
    async def test_oserror_returns_network_error(self) -> None:
        ctx = _make_ctx()
        with patch("urllib.request.urlopen", side_effect=OSError("broken pipe")):
            result = await api_delete(ctx, "/api/v1/queue/item-001")
        assert result["error"] == "network_error"
