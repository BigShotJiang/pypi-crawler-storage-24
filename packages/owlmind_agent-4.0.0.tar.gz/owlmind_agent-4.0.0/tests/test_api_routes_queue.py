"""Tests for GET/POST/DELETE /api/v1/queue/items."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from fastapi.testclient import TestClient

from owlmind.api.app import create_app
from owlmind.queue import QueueItem, QueueStatus

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def tmp_dirs(tmp_path: Path) -> dict[str, Path]:
    runs = tmp_path / "runs"
    runs.mkdir()
    ledger = tmp_path / "ledger"
    ledger.mkdir()
    queue = tmp_path / "queue"
    queue.mkdir()
    policies = tmp_path / "policies"
    policies.mkdir()
    return {"runs": runs, "ledger": ledger, "queue": queue, "policies": policies}


@pytest.fixture()
def client(tmp_dirs: dict[str, Path]) -> TestClient:
    app = create_app(
        runs_dir=tmp_dirs["runs"],
        ledger_dir=tmp_dirs["ledger"],
        queue_path=tmp_dirs["queue"],
        policies_dir=tmp_dirs["policies"],
    )
    return TestClient(app, headers={"X-API-Key": "test-key"})


@pytest.fixture(autouse=True)
def _patch_auth(monkeypatch: pytest.MonkeyPatch) -> None:
    """Bypass API key verification for all tests."""
    monkeypatch.setattr("owlmind.api.auth.verify_api_key", lambda: None)


def _write_queue(queue_dir: Path, items: list[dict]) -> None:
    """Write items to queue.jsonl."""
    lines = [json.dumps(item) for item in items]
    (queue_dir / "queue.jsonl").write_text("\n".join(lines) + "\n")


# ===========================================================================
# GET /api/v1/queue/items
# ===========================================================================


class TestGetQueueItems:
    def test_empty_queue_returns_empty_list(self, client: TestClient) -> None:
        resp = client.get("/api/v1/queue/items")
        assert resp.status_code == 200
        assert resp.json() == []

    def test_returns_items_from_queue_file(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        _write_queue(
            tmp_dirs["runs"].parent / "queue",
            [
                {
                    "id": "task-abc",
                    "goal": "do something",
                    "workspace": "/tmp",
                    "status": "PENDING",
                    "created_at": "",
                    "priority": 0,
                }
            ],
        )
        resp = client.get("/api/v1/queue/items")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 1
        assert data[0]["id"] == "task-abc"
        assert data[0]["goal"] == "do something"

    def test_response_has_priority_field(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        _write_queue(
            tmp_dirs["runs"].parent / "queue",
            [
                {
                    "id": "t1",
                    "goal": "g",
                    "workspace": "",
                    "status": "PENDING",
                    "created_at": "",
                    "priority": 2,
                }
            ],
        )
        resp = client.get("/api/v1/queue/items")
        assert resp.status_code == 200
        assert resp.json()[0]["priority"] == 2

    def test_skips_blank_lines_in_queue_file(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        queue_file = tmp_dirs["runs"].parent / "queue" / "queue.jsonl"
        queue_file.write_text(
            '{"id": "t1", "goal": "g", "workspace": "", "status": "PENDING", "created_at": "", "priority": 0}\n\n\n'
        )
        resp = client.get("/api/v1/queue/items")
        assert resp.status_code == 200
        assert len(resp.json()) == 1


# ===========================================================================
# POST /api/v1/queue/items
# ===========================================================================


class TestPostQueueItem:
    def test_adds_item_to_queue(self, client: TestClient) -> None:
        mock_item = QueueItem(
            id="task-xyz",
            goal="build the thing",
            workspace="/tmp/ws",
            status=QueueStatus.PENDING,
            created_at="2026-02-21T10:00:00+00:00",
            priority=0,
        )
        with patch("owlmind.queue.TaskQueue") as mock_tq_cls:
            mock_tq = MagicMock()
            mock_tq.add.return_value = mock_item
            mock_tq_cls.return_value = mock_tq

            resp = client.post(
                "/api/v1/queue/items",
                json={"goal": "build the thing", "workspace": "/tmp/ws"},
            )

        assert resp.status_code == 201
        data = resp.json()
        assert data["id"] == "task-xyz"
        assert data["goal"] == "build the thing"
        assert data["status"] == QueueStatus.PENDING

    def test_passes_priority_to_task_queue(self, client: TestClient) -> None:
        mock_item = QueueItem(
            id="task-abc",
            goal="urgent task",
            workspace="",
            status=QueueStatus.PENDING,
            created_at="2026-02-21T10:00:00+00:00",
            priority=2,
        )
        with patch("owlmind.queue.TaskQueue") as mock_tq_cls:
            mock_tq = MagicMock()
            mock_tq.add.return_value = mock_item
            mock_tq_cls.return_value = mock_tq

            resp = client.post(
                "/api/v1/queue/items",
                json={"goal": "urgent task", "workspace": "", "priority": 2},
            )

        assert resp.status_code == 201
        assert resp.json()["priority"] == 2
        mock_tq.add.assert_called_once_with(goal="urgent task", workspace="", priority=2)

    def test_returns_500_when_task_queue_raises(self, client: TestClient) -> None:
        with patch("owlmind.queue.TaskQueue", side_effect=RuntimeError("disk full")):
            resp = client.post(
                "/api/v1/queue/items",
                json={"goal": "task", "workspace": ""},
            )
        assert resp.status_code == 500

    def test_default_priority_is_zero(self, client: TestClient) -> None:
        mock_item = QueueItem(
            id="task-001",
            goal="normal task",
            workspace="",
            status=QueueStatus.PENDING,
            created_at="2026-02-21T10:00:00+00:00",
            priority=0,
        )
        with patch("owlmind.queue.TaskQueue") as mock_tq_cls:
            mock_tq = MagicMock()
            mock_tq.add.return_value = mock_item
            mock_tq_cls.return_value = mock_tq

            resp = client.post(
                "/api/v1/queue/items",
                json={"goal": "normal task"},
            )

        assert resp.status_code == 201
        mock_tq.add.assert_called_once_with(goal="normal task", workspace="", priority=0)


# ===========================================================================
# DELETE /api/v1/queue/items/{item_id}
# ===========================================================================


class TestDeleteQueueItem:
    def _queue_dir(self, tmp_dirs: dict[str, Path]) -> Path:
        return tmp_dirs["runs"].parent / "queue"

    def test_deletes_pending_item(self, client: TestClient, tmp_dirs: dict[str, Path]) -> None:
        qdir = self._queue_dir(tmp_dirs)
        _write_queue(
            qdir,
            [
                {
                    "id": "task-del",
                    "goal": "delete me",
                    "workspace": "",
                    "status": "PENDING",
                    "created_at": "",
                    "priority": 0,
                },
            ],
        )
        resp = client.delete("/api/v1/queue/items/task-del")
        assert resp.status_code == 200
        assert resp.json()["status"] == "deleted"

    def test_deletes_failed_item(self, client: TestClient, tmp_dirs: dict[str, Path]) -> None:
        qdir = self._queue_dir(tmp_dirs)
        _write_queue(
            qdir,
            [
                {
                    "id": "task-fail",
                    "goal": "failed task",
                    "workspace": "",
                    "status": "FAILED",
                    "created_at": "",
                    "priority": 0,
                },
            ],
        )
        resp = client.delete("/api/v1/queue/items/task-fail")
        assert resp.status_code == 200

    def test_returns_404_when_item_not_found(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        qdir = self._queue_dir(tmp_dirs)
        _write_queue(
            qdir,
            [
                {
                    "id": "task-other",
                    "goal": "other",
                    "workspace": "",
                    "status": "PENDING",
                    "created_at": "",
                    "priority": 0,
                },
            ],
        )
        resp = client.delete("/api/v1/queue/items/nonexistent-id")
        assert resp.status_code == 404

    def test_returns_404_when_queue_empty(self, client: TestClient) -> None:
        resp = client.delete("/api/v1/queue/items/any-id")
        assert resp.status_code == 404

    def test_returns_409_for_running_item(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        qdir = self._queue_dir(tmp_dirs)
        _write_queue(
            qdir,
            [
                {
                    "id": "task-run",
                    "goal": "running task",
                    "workspace": "",
                    "status": "RUNNING",
                    "created_at": "",
                    "priority": 0,
                },
            ],
        )
        resp = client.delete("/api/v1/queue/items/task-run")
        assert resp.status_code == 409

    def test_returns_409_for_done_item(self, client: TestClient, tmp_dirs: dict[str, Path]) -> None:
        qdir = self._queue_dir(tmp_dirs)
        _write_queue(
            qdir,
            [
                {
                    "id": "task-done",
                    "goal": "done task",
                    "workspace": "",
                    "status": "DONE",
                    "created_at": "",
                    "priority": 0,
                },
            ],
        )
        resp = client.delete("/api/v1/queue/items/task-done")
        assert resp.status_code == 409

    def test_item_removed_from_file_after_delete(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        qdir = self._queue_dir(tmp_dirs)
        _write_queue(
            qdir,
            [
                {
                    "id": "task-1",
                    "goal": "keep me",
                    "workspace": "",
                    "status": "PENDING",
                    "created_at": "",
                    "priority": 0,
                },
                {
                    "id": "task-2",
                    "goal": "delete me",
                    "workspace": "",
                    "status": "PENDING",
                    "created_at": "",
                    "priority": 0,
                },
            ],
        )
        client.delete("/api/v1/queue/items/task-2")
        queue_file = qdir / "queue.jsonl"
        remaining = [
            json.loads(line) for line in queue_file.read_text().splitlines() if line.strip()
        ]
        assert len(remaining) == 1
        assert remaining[0]["id"] == "task-1"


# ===========================================================================
# GET /api/v1/queue/items/{item_id}  (v3.8.0)
# ===========================================================================


class TestGetQueueItem:
    """Tests for the new GET /api/v1/queue/items/{item_id} endpoint."""

    def _queue_dir(self, tmp_dirs: dict[str, Path]) -> Path:
        return tmp_dirs["runs"].parent / "queue"

    def test_get_existing_item(self, client: TestClient, tmp_dirs: dict[str, Path]) -> None:
        """Returns 200 with full item details when item_id exists."""
        qdir = self._queue_dir(tmp_dirs)
        _write_queue(
            qdir,
            [
                {
                    "id": "item-detail-1",
                    "goal": "run the build",
                    "workspace": "/tmp/ws",
                    "status": "PENDING",
                    "created_at": "2026-02-22T10:00:00+00:00",
                    "priority": 1,
                }
            ],
        )
        resp = client.get("/api/v1/queue/items/item-detail-1")
        assert resp.status_code == 200
        data = resp.json()
        assert data["id"] == "item-detail-1"
        assert data["goal"] == "run the build"
        assert data["workspace"] == "/tmp/ws"
        assert data["status"] == "PENDING"
        assert data["priority"] == 1

    def test_get_nonexistent_item(self, client: TestClient, tmp_dirs: dict[str, Path]) -> None:
        """Returns 404 when item_id is not in the queue."""
        qdir = self._queue_dir(tmp_dirs)
        _write_queue(
            qdir,
            [
                {
                    "id": "item-other",
                    "goal": "other goal",
                    "workspace": "",
                    "status": "PENDING",
                    "created_at": "",
                    "priority": 0,
                }
            ],
        )
        resp = client.get("/api/v1/queue/items/does-not-exist")
        assert resp.status_code == 404

    def test_get_item_from_empty_queue(self, client: TestClient) -> None:
        """Returns 404 when queue file does not exist."""
        resp = client.get("/api/v1/queue/items/any-id")
        assert resp.status_code == 404

    def test_get_item_returns_all_fields(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        """Response includes all QueueItemResponse fields."""
        qdir = self._queue_dir(tmp_dirs)
        _write_queue(
            qdir,
            [
                {
                    "id": "full-item",
                    "goal": "full test",
                    "workspace": "/home/user",
                    "status": "RUNNING",
                    "created_at": "2026-02-22",
                    "priority": 3,
                }
            ],
        )
        resp = client.get("/api/v1/queue/items/full-item")
        assert resp.status_code == 200
        data = resp.json()
        assert "id" in data
        assert "goal" in data
        assert "workspace" in data
        assert "status" in data
        assert "created_at" in data
        assert "priority" in data

    def test_get_item_among_multiple(self, client: TestClient, tmp_dirs: dict[str, Path]) -> None:
        """Returns the correct item when multiple items exist."""
        qdir = self._queue_dir(tmp_dirs)
        _write_queue(
            qdir,
            [
                {
                    "id": "item-A",
                    "goal": "goal A",
                    "workspace": "",
                    "status": "PENDING",
                    "created_at": "",
                    "priority": 0,
                },
                {
                    "id": "item-B",
                    "goal": "goal B",
                    "workspace": "",
                    "status": "DONE",
                    "created_at": "",
                    "priority": 2,
                },
                {
                    "id": "item-C",
                    "goal": "goal C",
                    "workspace": "",
                    "status": "FAILED",
                    "created_at": "",
                    "priority": 0,
                },
            ],
        )
        resp = client.get("/api/v1/queue/items/item-B")
        assert resp.status_code == 200
        data = resp.json()
        assert data["id"] == "item-B"
        assert data["goal"] == "goal B"
        assert data["priority"] == 2
