"""Tests for FS61 — Heartbeat → AutoPilot integration."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

# ---------------------------------------------------------------------------
# AutoPilotConfig — enable_heartbeat field
# ---------------------------------------------------------------------------


def test_heartbeat_disabled_by_default() -> None:
    """AutoPilotConfig.enable_heartbeat defaults to False."""
    from owlmind.autopilot import AutoPilotConfig

    assert AutoPilotConfig().enable_heartbeat is False


def test_heartbeat_can_be_enabled() -> None:
    """AutoPilotConfig accepts enable_heartbeat=True."""
    from owlmind.autopilot import AutoPilotConfig

    cfg = AutoPilotConfig(enable_heartbeat=True)
    assert cfg.enable_heartbeat is True


# ---------------------------------------------------------------------------
# run() — tick() is called when enable_heartbeat=True
# ---------------------------------------------------------------------------


def test_heartbeat_tick_called_when_enabled(tmp_path: Path) -> None:
    """HeartbeatEngine.tick() is called at least once during autopilot run."""
    from owlmind.autopilot import AutoPilotConfig, run

    (tmp_path / "policies").mkdir()
    (tmp_path / "runs").mkdir()

    mock_hb_instance = MagicMock()
    mock_hb_instance.tick.return_value = []
    mock_hb_class = MagicMock(return_value=mock_hb_instance)

    config = AutoPilotConfig(
        goal="test heartbeat tick",
        workspace=str(tmp_path),
        runs_dir=tmp_path / "runs",
        policies_dir=tmp_path / "policies",
        ledger_dir=tmp_path / "ledger",
        use_llm="none",
        use_worker="none",
        enable_heartbeat=True,
    )

    with patch("owlmind.heartbeat.HeartbeatEngine", mock_hb_class):
        run(config)

    mock_hb_instance.tick.assert_called()


def test_heartbeat_not_created_when_disabled(tmp_path: Path) -> None:
    """HeartbeatEngine is never instantiated when enable_heartbeat=False."""
    from owlmind.autopilot import AutoPilotConfig, run

    (tmp_path / "policies").mkdir()
    (tmp_path / "runs").mkdir()

    mock_hb_class = MagicMock()

    config = AutoPilotConfig(
        goal="test no heartbeat",
        workspace=str(tmp_path),
        runs_dir=tmp_path / "runs",
        policies_dir=tmp_path / "policies",
        ledger_dir=tmp_path / "ledger",
        use_llm="none",
        use_worker="none",
        enable_heartbeat=False,
    )

    with patch("owlmind.heartbeat.HeartbeatEngine", mock_hb_class):
        run(config)

    mock_hb_class.assert_not_called()


def test_heartbeat_emits_event_when_messages(tmp_path: Path) -> None:
    """on_event callback receives 'heartbeat' event when tick returns messages."""
    from owlmind.autopilot import AutoPilotConfig, run

    (tmp_path / "policies").mkdir()
    (tmp_path / "runs").mkdir()

    emitted: list[tuple[str, dict]] = []

    mock_hb_instance = MagicMock()
    mock_hb_instance.tick.return_value = ["Queue: 1 pending task(s)"]
    mock_hb_class = MagicMock(return_value=mock_hb_instance)

    config = AutoPilotConfig(
        goal="test heartbeat events",
        workspace=str(tmp_path),
        runs_dir=tmp_path / "runs",
        policies_dir=tmp_path / "policies",
        ledger_dir=tmp_path / "ledger",
        use_llm="none",
        use_worker="none",
        enable_heartbeat=True,
        on_event=lambda name, data: emitted.append((name, data)),
    )

    with patch("owlmind.heartbeat.HeartbeatEngine", mock_hb_class):
        run(config)

    heartbeat_events = [e for e in emitted if e[0] == "heartbeat"]
    assert len(heartbeat_events) >= 1
    assert "messages" in heartbeat_events[0][1]
