"""Tests for v3.2.0 runs endpoints: /live SSE, /{id}/log, /{id}/events, /{id}/recover.

Covers lines 93, 117-146, 221-222, 231-238, 242-259, 263-274 of
src/owlmind/api/routes/runs.py to push coverage from 59% to 85%+.
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from starlette.testclient import TestClient

from owlmind.api.app import create_app

# ---------------------------------------------------------------------------
# Fixtures — mirrors test_api_routes_dashboard.py pattern
# ---------------------------------------------------------------------------


@pytest.fixture()
def tmp_dirs(tmp_path: Path) -> dict[str, Path]:
    dirs = {
        "runs": tmp_path / "runs",
        "ledger": tmp_path / "ledger",
        "queue": tmp_path / "queue",
        "policies": tmp_path / "policies",
        "memory_db": tmp_path / "memory" / "memory.db",
    }
    for key, d in dirs.items():
        if key == "memory_db":
            d.parent.mkdir(parents=True, exist_ok=True)
        else:
            d.mkdir(parents=True, exist_ok=True)
    return dirs


@pytest.fixture()
def client(tmp_dirs: dict[str, Path]) -> TestClient:
    app = create_app(
        runs_dir=tmp_dirs["runs"],
        ledger_dir=tmp_dirs["ledger"],
        queue_path=tmp_dirs["queue"],
        policies_dir=tmp_dirs["policies"],
        memory_db=tmp_dirs["memory_db"],
    )
    return TestClient(app)


@pytest.fixture(autouse=True)
def _no_auth(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("owlmind.api.auth.verify_api_key", lambda: None)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_run(runs_dir: Path, run_id: str, meta: dict | None = None) -> Path:
    """Create a run directory with cycle_meta.json."""
    run_path = runs_dir / run_id
    run_path.mkdir(parents=True, exist_ok=True)
    if meta is not None:
        (run_path / "cycle_meta.json").write_text(json.dumps(meta, indent=2))
    return run_path


def _write_jsonl(run_path: Path, events: list[dict]) -> Path:
    """Write run.jsonl into a run directory."""
    log_path = run_path / "run.jsonl"
    log_path.write_text("\n".join(json.dumps(e) for e in events) + "\n")
    return log_path


def _make_deadline_loop_mock(expire_after_calls: int = 2) -> MagicMock:
    """Return a mock for asyncio.get_event_loop() whose .time() expires quickly.

    The runs.py code does:
        deadline = asyncio.get_event_loop().time() + 600
        while asyncio.get_event_loop().time() < deadline:
            ...

    We make .time() return a small value on the first call (so `deadline` is
    set to ~small + 600), then return a value > deadline on subsequent calls
    so the while loop exits after one iteration.
    """
    mock_loop = MagicMock()
    call_count = 0
    base = time.monotonic()

    def _time() -> float:
        nonlocal call_count
        call_count += 1
        if call_count <= expire_after_calls:
            return base  # initial calls — loop is "fresh"
        return base + 700  # past the 600 s deadline

    mock_loop.time.side_effect = _time
    return mock_loop


async def _instant_sleep(_: float) -> None:
    """Replacement for asyncio.sleep that returns immediately."""
    pass


# ===========================================================================
# GET /api/v1/runs/ — list_runs edge cases
# ===========================================================================


class TestListRunsEdgeCases:
    """Cover line 93: runs_dir does not exist → empty list returned."""

    def test_list_runs_when_runs_dir_missing(
        self, tmp_dirs: dict[str, Path], client: TestClient
    ) -> None:
        """When runs_dir is absent, list_runs returns []."""
        # Remove the runs directory entirely so is_dir() returns False
        tmp_dirs["runs"].rmdir()
        resp = client.get("/api/v1/runs")
        assert resp.status_code == 200
        assert resp.json() == []


# ===========================================================================
# GET /api/v1/runs/live — SSE global stream (lines 117-146)
# ===========================================================================


class TestLiveSSEStream:
    """Cover the /live SSE endpoint and its async generator."""

    def test_live_returns_streaming_response(self, client: TestClient) -> None:
        """GET /live returns 200 with text/event-stream content type."""
        mock_loop = _make_deadline_loop_mock(expire_after_calls=1)
        with (
            patch("owlmind.api.routes.runs.asyncio.sleep", new=_instant_sleep),
            patch("owlmind.api.routes.runs.asyncio.get_event_loop", return_value=mock_loop),
        ):
            resp = client.get("/api/v1/runs/live")
        assert resp.status_code == 200
        assert "text/event-stream" in resp.headers["content-type"]

    def test_live_stream_closed_event_when_no_runs(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        """When runs_dir is empty the stream still terminates with stream_closed."""
        mock_loop = _make_deadline_loop_mock(expire_after_calls=1)
        with (
            patch("owlmind.api.routes.runs.asyncio.sleep", new=_instant_sleep),
            patch("owlmind.api.routes.runs.asyncio.get_event_loop", return_value=mock_loop),
        ):
            resp = client.get("/api/v1/runs/live")
        assert resp.status_code == 200
        assert "stream_closed" in resp.text

    def test_live_stream_emits_events_for_existing_jsonl(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        """Events from run.jsonl are broadcast with run_id injected."""
        run_path = _make_run(tmp_dirs["runs"], "run-live-01")
        _write_jsonl(run_path, [{"event": "step", "step": 1}])

        # Allow 3 calls before expiry so the generator body runs once
        mock_loop = _make_deadline_loop_mock(expire_after_calls=3)
        with (
            patch("owlmind.api.routes.runs.asyncio.sleep", new=_instant_sleep),
            patch("owlmind.api.routes.runs.asyncio.get_event_loop", return_value=mock_loop),
        ):
            resp = client.get("/api/v1/runs/live")

        assert resp.status_code == 200
        # At least one SSE data line should contain the run_id
        assert "run-live-01" in resp.text

    def test_live_stream_handles_invalid_json_line(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        """Non-JSON lines in run.jsonl are emitted as {raw: line} objects."""
        run_path = _make_run(tmp_dirs["runs"], "run-bad-json")
        (run_path / "run.jsonl").write_text("not-valid-json\n")

        mock_loop = _make_deadline_loop_mock(expire_after_calls=3)
        with (
            patch("owlmind.api.routes.runs.asyncio.sleep", new=_instant_sleep),
            patch("owlmind.api.routes.runs.asyncio.get_event_loop", return_value=mock_loop),
        ):
            resp = client.get("/api/v1/runs/live")

        assert resp.status_code == 200
        assert "raw" in resp.text

    def test_live_stream_skips_non_directory_entries(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        """Files in runs_dir (not dirs) are skipped without error."""
        (tmp_dirs["runs"] / "stray.txt").write_text("ignore me")

        mock_loop = _make_deadline_loop_mock(expire_after_calls=1)
        with (
            patch("owlmind.api.routes.runs.asyncio.sleep", new=_instant_sleep),
            patch("owlmind.api.routes.runs.asyncio.get_event_loop", return_value=mock_loop),
        ):
            resp = client.get("/api/v1/runs/live")

        assert resp.status_code == 200
        assert "stream_closed" in resp.text


# ===========================================================================
# POST /api/v1/runs/{run_id}/cancel — error path (lines 221-222)
# ===========================================================================


class TestCancelRunErrorPath:
    """Cover the OSError/JSONDecodeError 500 path in cancel_run."""

    def test_cancel_run_io_error_returns_500(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        """If reading cycle_meta.json raises OSError, cancel returns 500."""
        _make_run(tmp_dirs["runs"], "run-ioerr", meta={"state": "RUNNING"})

        with patch.object(
            Path,
            "read_text",
            side_effect=OSError("disk read error"),
        ):
            resp = client.post("/api/v1/runs/run-ioerr/cancel")

        assert resp.status_code == 500
        assert "Failed to cancel run" in resp.json()["detail"]

    def test_cancel_run_corrupt_json_returns_500(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        """If cycle_meta.json contains invalid JSON, cancel returns 500."""
        run_path = _make_run(tmp_dirs["runs"], "run-badjson")
        (run_path / "cycle_meta.json").write_text("{broken json")

        resp = client.post("/api/v1/runs/run-badjson/cancel")

        assert resp.status_code == 500
        assert "Failed to cancel run" in resp.json()["detail"]


# ===========================================================================
# GET /api/v1/runs/{run_id}/log (lines 231-238)
# ===========================================================================


class TestGetRunLog:
    """Cover GET /{run_id}/log: existing log, missing log, lines param, OSError."""

    def test_log_missing_run_returns_empty(self, client: TestClient) -> None:
        """When run.jsonl does not exist, returns empty lines list."""
        resp = client.get("/api/v1/runs/nonexistent-run/log")
        assert resp.status_code == 200
        data = resp.json()
        assert data["run_id"] == "nonexistent-run"
        assert data["lines"] == []

    def test_log_returns_last_n_lines(self, client: TestClient, tmp_dirs: dict[str, Path]) -> None:
        """log endpoint returns up to `lines` most-recent lines."""
        run_path = _make_run(tmp_dirs["runs"], "run-log-01", meta={"state": "DONE"})
        events = [{"event": "step", "n": i} for i in range(10)]
        _write_jsonl(run_path, events)

        resp = client.get("/api/v1/runs/run-log-01/log?lines=3")
        assert resp.status_code == 200
        data = resp.json()
        assert data["run_id"] == "run-log-01"
        assert len(data["lines"]) == 3
        # Last 3 lines correspond to events 7, 8, 9
        last = json.loads(data["lines"][-1])
        assert last["n"] == 9

    def test_log_default_50_lines(self, client: TestClient, tmp_dirs: dict[str, Path]) -> None:
        """Default lines parameter is 50."""
        run_path = _make_run(tmp_dirs["runs"], "run-log-50", meta={"state": "DONE"})
        events = [{"event": "step", "n": i} for i in range(60)]
        _write_jsonl(run_path, events)

        resp = client.get("/api/v1/runs/run-log-50/log")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data["lines"]) == 50

    def test_log_os_error_returns_empty(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        """If read_text raises OSError, returns empty lines (graceful degradation)."""
        run_path = _make_run(tmp_dirs["runs"], "run-log-oserr", meta={"state": "DONE"})
        (run_path / "run.jsonl").write_text("irrelevant")

        with patch.object(Path, "read_text", side_effect=OSError("read error")):
            resp = client.get("/api/v1/runs/run-log-oserr/log")

        assert resp.status_code == 200
        data = resp.json()
        assert data["run_id"] == "run-log-oserr"
        assert data["lines"] == []

    def test_log_all_lines_when_fewer_than_limit(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        """When log has fewer lines than the limit, all lines are returned."""
        run_path = _make_run(tmp_dirs["runs"], "run-log-few", meta={"state": "DONE"})
        events = [{"event": "step", "n": i} for i in range(5)]
        _write_jsonl(run_path, events)

        resp = client.get("/api/v1/runs/run-log-few/log?lines=50")
        assert resp.status_code == 200
        assert len(resp.json()["lines"]) == 5


# ===========================================================================
# GET /api/v1/runs/{run_id}/events — per-run SSE stream (lines 242-259)
# ===========================================================================


class TestRunEventsSSE:
    """Cover GET /{run_id}/events streaming endpoint."""

    def test_events_returns_streaming_response(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        """GET /{run_id}/events returns 200 with text/event-stream content type."""
        _make_run(tmp_dirs["runs"], "run-events-01", meta={"state": "RUNNING"})

        mock_loop = _make_deadline_loop_mock(expire_after_calls=1)
        with (
            patch("owlmind.api.routes.runs.asyncio.sleep", new=_instant_sleep),
            patch("owlmind.api.routes.runs.asyncio.get_event_loop", return_value=mock_loop),
        ):
            resp = client.get("/api/v1/runs/run-events-01/events")

        assert resp.status_code == 200
        assert "text/event-stream" in resp.headers["content-type"]

    def test_events_stream_closed_when_no_log(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        """Stream terminates with stream_closed even when run.jsonl does not exist."""
        _make_run(tmp_dirs["runs"], "run-events-nolog", meta={"state": "RUNNING"})

        mock_loop = _make_deadline_loop_mock(expire_after_calls=1)
        with (
            patch("owlmind.api.routes.runs.asyncio.sleep", new=_instant_sleep),
            patch("owlmind.api.routes.runs.asyncio.get_event_loop", return_value=mock_loop),
        ):
            resp = client.get("/api/v1/runs/run-events-nolog/events")

        assert resp.status_code == 200
        assert "stream_closed" in resp.text

    def test_events_stream_emits_jsonl_lines(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        """Lines in run.jsonl are forwarded as SSE data: lines."""
        run_path = _make_run(tmp_dirs["runs"], "run-events-data", meta={"state": "RUNNING"})
        _write_jsonl(run_path, [{"event": "step", "n": 1}, {"event": "done"}])

        mock_loop = _make_deadline_loop_mock(expire_after_calls=3)
        with (
            patch("owlmind.api.routes.runs.asyncio.sleep", new=_instant_sleep),
            patch("owlmind.api.routes.runs.asyncio.get_event_loop", return_value=mock_loop),
        ):
            resp = client.get("/api/v1/runs/run-events-data/events")

        assert resp.status_code == 200
        body = resp.text
        assert '"event"' in body

    def test_events_for_nonexistent_run(self, client: TestClient) -> None:
        """GET /events for a run that does not exist still returns 200 stream."""
        mock_loop = _make_deadline_loop_mock(expire_after_calls=1)
        with (
            patch("owlmind.api.routes.runs.asyncio.sleep", new=_instant_sleep),
            patch("owlmind.api.routes.runs.asyncio.get_event_loop", return_value=mock_loop),
        ):
            resp = client.get("/api/v1/runs/totally-missing-run/events")

        assert resp.status_code == 200
        assert "stream_closed" in resp.text


# ===========================================================================
# POST /api/v1/runs/{run_id}/recover (lines 263-274)
# ===========================================================================


class TestRecoverRun:
    """Cover POST /{run_id}/recover endpoint."""

    def test_recover_not_found_returns_not_found_status(self, client: TestClient) -> None:
        """When run does not exist, recover returns {status: not_found}."""
        resp = client.post("/api/v1/runs/no-such-run/recover")
        assert resp.status_code == 200
        data = resp.json()
        assert data["run_id"] == "no-such-run"
        assert data["status"] == "not_found"

    def test_recover_marks_run_as_cancelled(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        """recover writes state=CANCELLED + stop_reason=manual_recover to cycle_meta.json."""
        run_path = _make_run(
            tmp_dirs["runs"],
            "run-recover-01",
            meta={"run_id": "run-recover-01", "state": "RUNNING", "goal": "test"},
        )

        resp = client.post("/api/v1/runs/run-recover-01/recover")
        assert resp.status_code == 200
        data = resp.json()
        assert data["run_id"] == "run-recover-01"
        assert data["status"] == "cancelled"

        # Verify the file was actually updated
        saved = json.loads((run_path / "cycle_meta.json").read_text())
        assert saved["state"] == "CANCELLED"
        assert saved["stop_reason"] == "manual_recover"

    def test_recover_returns_cancelled_status(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        """recover returns {status: cancelled} on success."""
        _make_run(
            tmp_dirs["runs"],
            "run-recover-02",
            meta={"run_id": "run-recover-02", "state": "STUCK"},
        )

        resp = client.post("/api/v1/runs/run-recover-02/recover")
        assert resp.status_code == 200
        assert resp.json()["status"] == "cancelled"

    def test_recover_os_error_returns_error_status(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        """When reading cycle_meta.json raises OSError, recover returns {status: error}."""
        _make_run(
            tmp_dirs["runs"],
            "run-recover-err",
            meta={"run_id": "run-recover-err", "state": "RUNNING"},
        )

        with patch.object(Path, "read_text", side_effect=OSError("disk read error")):
            resp = client.post("/api/v1/runs/run-recover-err/recover")

        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "error"
        assert "error" in data

    def test_recover_corrupt_json_returns_error_status(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        """When cycle_meta.json has invalid JSON, recover returns {status: error}."""
        run_path = _make_run(tmp_dirs["runs"], "run-recover-badmeta")
        (run_path / "cycle_meta.json").write_text("{not valid json")

        resp = client.post("/api/v1/runs/run-recover-badmeta/recover")

        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "error"

    def test_recover_preserves_existing_meta_fields(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        """recover preserves existing fields like goal, run_id in cycle_meta.json."""
        run_path = _make_run(
            tmp_dirs["runs"],
            "run-recover-03",
            meta={
                "run_id": "run-recover-03",
                "state": "RUNNING",
                "goal": "important goal",
                "iteration": 5,
            },
        )

        resp = client.post("/api/v1/runs/run-recover-03/recover")
        assert resp.status_code == 200

        saved = json.loads((run_path / "cycle_meta.json").read_text())
        assert saved["goal"] == "important goal"
        assert saved["iteration"] == 5
        assert saved["state"] == "CANCELLED"
