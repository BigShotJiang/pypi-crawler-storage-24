"""Tests for sandbox — worktree isolation and E2B sandbox tool."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from owlmind.agent.sandbox import (
    cleanup_sandbox,
    create_sandbox,
    is_git_repo,
    sandbox_status,
)
from owlmind.policy import PolicyEngine
from owlmind.tools.sandbox import SandboxResult, run_in_sandbox
from owlmind.tools.sandbox import is_available as e2b_is_available


def _git_available() -> bool:
    """Check if git is available on PATH."""
    try:
        subprocess.run(["git", "--version"], capture_output=True, check=True)
        return True
    except (FileNotFoundError, subprocess.CalledProcessError):
        return False


def _make_policy(tmp_path: Path) -> PolicyEngine:
    policies_dir = tmp_path / "policies"
    policies_dir.mkdir()
    (policies_dir / "allowlist.yaml").write_text('allowed_commands:\n  - "^git "\n  - "^echo "\n')
    (policies_dir / "policy.yaml").write_text('forbidden_patterns:\n  - "rm -rf"\n')
    return PolicyEngine.from_directory(policies_dir)


def _init_git_repo(repo_dir: Path) -> None:
    """Create a minimal git repo with one commit."""
    repo_dir.mkdir(parents=True, exist_ok=True)
    subprocess.run(["git", "init", str(repo_dir)], capture_output=True, check=True)
    subprocess.run(
        ["git", "-C", str(repo_dir), "config", "user.email", "test@test.com"],
        capture_output=True,
        check=True,
    )
    subprocess.run(
        ["git", "-C", str(repo_dir), "config", "user.name", "Test"],
        capture_output=True,
        check=True,
    )
    (repo_dir / "README.md").write_text("# Test\n")
    subprocess.run(["git", "-C", str(repo_dir), "add", "."], capture_output=True, check=True)
    subprocess.run(
        ["git", "-C", str(repo_dir), "commit", "-m", "init"],
        capture_output=True,
        check=True,
    )


class TestIsGitRepo:
    def test_not_git(self, tmp_path: Path) -> None:
        assert is_git_repo(tmp_path) is False

    @pytest.mark.skipif(not _git_available(), reason="git not available")
    def test_is_git(self, tmp_path: Path) -> None:
        _init_git_repo(tmp_path / "repo")
        assert is_git_repo(tmp_path / "repo") is True


class TestSandboxStatus:
    def test_no_sandbox(self, tmp_path: Path) -> None:
        runs_dir = tmp_path / "runs"
        runs_dir.mkdir()
        info = sandbox_status("run-1", runs_dir)
        assert info.enabled is False
        assert info.kind == "none"

    def test_plain_dir_sandbox(self, tmp_path: Path) -> None:
        runs_dir = tmp_path / "runs"
        workdir = runs_dir / "run-1" / "workdir"
        workdir.mkdir(parents=True)
        info = sandbox_status("run-1", runs_dir)
        assert info.enabled is True
        assert info.kind == "plain-dir"

    def test_worktree_sandbox(self, tmp_path: Path) -> None:
        runs_dir = tmp_path / "runs"
        wt = runs_dir / "run-1" / "worktree"
        wt.mkdir(parents=True)
        info = sandbox_status("run-1", runs_dir)
        assert info.enabled is True
        assert info.kind == "git-worktree"


class TestCreateSandbox:
    def test_non_git_creates_plain_dir(self, tmp_path: Path) -> None:
        policy = _make_policy(tmp_path)
        runs_dir = tmp_path / "runs"
        runs_dir.mkdir()

        info = create_sandbox("run-1", str(tmp_path / "workspace"), runs_dir, policy)
        assert info.enabled is True
        assert info.kind == "plain-dir"
        assert Path(info.worktree_path).is_dir()

    @pytest.mark.skipif(not _git_available(), reason="git not available")
    def test_git_creates_worktree(self, tmp_path: Path) -> None:
        repo = tmp_path / "repo"
        _init_git_repo(repo)
        policy = _make_policy(tmp_path)
        runs_dir = tmp_path / "runs"
        runs_dir.mkdir()

        info = create_sandbox("run-1", str(repo), runs_dir, policy)
        assert info.enabled is True
        assert info.kind == "git-worktree"
        assert info.branch_name == "owlmind/run-1"
        assert len(info.base_head_sha) > 0
        assert Path(info.worktree_path).is_dir()

    @pytest.mark.skipif(not _git_available(), reason="git not available")
    def test_cleanup_removes_worktree(self, tmp_path: Path) -> None:
        repo = tmp_path / "repo"
        _init_git_repo(repo)
        policy = _make_policy(tmp_path)
        runs_dir = tmp_path / "runs"
        runs_dir.mkdir()

        info = create_sandbox("run-1", str(repo), runs_dir, policy)
        assert Path(info.worktree_path).is_dir()

        ok, msg = cleanup_sandbox("run-1", str(repo), runs_dir, policy)
        assert ok is True
        assert "Removed" in msg

    def test_cleanup_plain_dir(self, tmp_path: Path) -> None:
        policy = _make_policy(tmp_path)
        runs_dir = tmp_path / "runs"
        runs_dir.mkdir()

        info = create_sandbox("run-1", str(tmp_path / "workspace"), runs_dir, policy)
        assert Path(info.worktree_path).is_dir()

        ok, msg = cleanup_sandbox("run-1", str(tmp_path / "workspace"), runs_dir, policy)
        assert ok is True
        assert not Path(info.worktree_path).is_dir()

    @pytest.mark.skipif(not _git_available(), reason="git not available")
    def test_git_worktree_both_fail_falls_back_to_plain_dir(self, tmp_path: Path) -> None:
        """When both worktree add attempts fail, fall back to a plain directory (lines 73, 77-79)."""
        from unittest.mock import MagicMock, patch

        repo = tmp_path / "repo"
        _init_git_repo(repo)
        policy = _make_policy(tmp_path)
        runs_dir = tmp_path / "runs"
        runs_dir.mkdir()

        fail_result = MagicMock()
        fail_result.exit_code = 1
        fail_result.stdout = ""

        ok_result = MagicMock()
        ok_result.exit_code = 0
        ok_result.stdout = "abc123def456\n"

        from owlmind.tools.shell import ShellTool

        def patched_run(self: ShellTool, cmd: str) -> MagicMock:  # type: ignore[misc]
            if "worktree add" in cmd:
                return fail_result
            return ok_result

        with patch.object(ShellTool, "run", patched_run):
            info = create_sandbox("run-fallback", str(repo), runs_dir, policy)

        assert info.enabled is True
        assert info.kind == "plain-dir"
        assert Path(info.worktree_path).is_dir()

    @pytest.mark.skipif(not _git_available(), reason="git not available")
    def test_git_worktree_first_fail_retries_without_b(self, tmp_path: Path) -> None:
        """When 'git worktree add -b' fails, retries without -b (line 73)."""
        from unittest.mock import MagicMock, patch

        repo = tmp_path / "repo"
        _init_git_repo(repo)
        policy = _make_policy(tmp_path)
        runs_dir = tmp_path / "runs"
        runs_dir.mkdir()

        from owlmind.tools.shell import ShellTool

        original_run = ShellTool.run
        calls: list[str] = []

        def recording_run(self: ShellTool, cmd: str) -> MagicMock:  # type: ignore[misc]
            calls.append(cmd)
            if "worktree add -b" in cmd:
                r = MagicMock()
                r.exit_code = 1
                r.stdout = ""
                return r
            return original_run(self, cmd)

        with patch.object(ShellTool, "run", recording_run):
            info = create_sandbox("run-retry", str(repo), runs_dir, policy)

        assert any("worktree add -b" in c for c in calls)
        assert info.enabled is True

    def test_cleanup_no_sandbox_found(self, tmp_path: Path) -> None:
        """cleanup_sandbox returns (False, msg) when no sandbox exists (line 116)."""
        policy = _make_policy(tmp_path)
        runs_dir = tmp_path / "runs"
        runs_dir.mkdir()

        ok, msg = cleanup_sandbox("run-missing", str(tmp_path / "workspace"), runs_dir, policy)
        assert ok is False
        assert "No sandbox found" in msg

    def test_cleanup_worktree_non_git_workspace(self, tmp_path: Path) -> None:
        """cleanup_sandbox removes worktree dir when workspace is not a git repo (lines 119-120)."""
        policy = _make_policy(tmp_path)
        runs_dir = tmp_path / "runs"

        worktree_dir = runs_dir / "run-nongit" / "worktree"
        worktree_dir.mkdir(parents=True)

        workspace = tmp_path / "plain_workspace"
        workspace.mkdir()

        ok, msg = cleanup_sandbox("run-nongit", str(workspace), runs_dir, policy)
        assert ok is True
        assert "Removed directory" in msg
        assert not worktree_dir.exists()

    @pytest.mark.skipif(not _git_available(), reason="git not available")
    def test_cleanup_git_worktree_force_removes_on_failure(self, tmp_path: Path) -> None:
        """When 'git worktree remove' fails, shutil force-removes the dir (line 128)."""
        from unittest.mock import MagicMock, patch

        repo = tmp_path / "repo"
        _init_git_repo(repo)
        policy = _make_policy(tmp_path)
        runs_dir = tmp_path / "runs"

        worktree_dir = runs_dir / "run-force" / "worktree"
        worktree_dir.mkdir(parents=True)
        (worktree_dir / "file.txt").write_text("content")

        fail_result = MagicMock()
        fail_result.exit_code = 1
        fail_result.stdout = ""

        from owlmind.tools.shell import ShellTool

        def always_fail(self: ShellTool, cmd: str) -> MagicMock:  # type: ignore[misc]
            return fail_result

        with patch.object(ShellTool, "run", always_fail):
            ok, msg = cleanup_sandbox("run-force", str(repo), runs_dir, policy)

        assert ok is True
        assert not worktree_dir.exists()


# ---------------------------------------------------------------------------
# E2B SandboxResult tests
# ---------------------------------------------------------------------------


def test_e2b_sandbox_result_success() -> None:
    result = SandboxResult(stdout="hello", stderr="", exit_code=0, error="")
    assert result.success is True
    assert str(result) == "hello"


def test_e2b_sandbox_result_failure() -> None:
    result = SandboxResult(stdout="", stderr="bad", exit_code=1, error="oops")
    assert result.success is False
    assert "[stderr] bad" in str(result)
    assert "[error] oops" in str(result)


def test_e2b_sandbox_result_exit_code_failure() -> None:
    result = SandboxResult(stdout="out", stderr="", exit_code=2, error="")
    assert result.success is False


def test_e2b_sandbox_result_error_only() -> None:
    result = SandboxResult(stdout="", stderr="", exit_code=0, error="crash")
    assert result.success is False
    assert "[error] crash" in str(result)


# ---------------------------------------------------------------------------
# is_available tests
# ---------------------------------------------------------------------------


def test_is_available_no_key(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("E2B_API_KEY", raising=False)
    assert e2b_is_available() is False


def test_is_available_no_e2b(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("E2B_API_KEY", "test-key")
    with patch.dict(sys.modules, {"e2b_code_interpreter": None}):
        assert e2b_is_available() is False


def test_is_available_with_key_and_module(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("E2B_API_KEY", "test-key")
    fake_e2b = MagicMock()
    with patch.dict(sys.modules, {"e2b_code_interpreter": fake_e2b}):
        assert e2b_is_available() is True


# ---------------------------------------------------------------------------
# run_in_sandbox — local fallback (no API key)
# ---------------------------------------------------------------------------


def test_run_local_python() -> None:
    """Actually run simple Python code via local fallback (no E2B key needed)."""
    result = run_in_sandbox("print('hello')", language="python")
    assert result.success
    assert "hello" in result.stdout


def test_run_local_error() -> None:
    result = run_in_sandbox("raise ValueError('boom')", language="python")
    assert not result.success
    assert result.exit_code != 0 or result.stderr or result.error


def test_run_in_sandbox_no_key_uses_local(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("E2B_API_KEY", raising=False)
    result = run_in_sandbox("print(1 + 1)", language="python")
    assert result.success
    assert "2" in result.stdout


# ---------------------------------------------------------------------------
# _run_e2b path
# ---------------------------------------------------------------------------


def test_run_e2b_not_installed() -> None:
    """_run_e2b raises RuntimeError when e2b_code_interpreter is absent."""
    from owlmind.tools.sandbox import _run_e2b

    with patch.dict(sys.modules, {"e2b_code_interpreter": None}):
        with pytest.raises(RuntimeError, match="not installed"):
            _run_e2b("print(1)", language="python", timeout=10, api_key="k")


def test_run_e2b_success() -> None:
    """Mock e2b_code_interpreter to test the happy path of _run_e2b."""
    from owlmind.tools.sandbox import _run_e2b

    fake_logs = MagicMock()
    fake_logs.stdout = ["hello from sandbox\n"]
    fake_logs.stderr = []

    fake_execution = MagicMock()
    fake_execution.logs = fake_logs
    fake_execution.error = None

    fake_sbx = MagicMock()
    fake_sbx.run_code.return_value = fake_execution
    fake_sbx.__enter__ = MagicMock(return_value=fake_sbx)
    fake_sbx.__exit__ = MagicMock(return_value=False)

    fake_e2b = MagicMock()
    fake_e2b.Sandbox.create.return_value = fake_sbx

    with patch.dict(sys.modules, {"e2b_code_interpreter": fake_e2b}):
        result = _run_e2b(
            "print('hello from sandbox')", language="python", timeout=10, api_key="k"
        )

    assert result.success
    assert "hello from sandbox" in result.stdout


def test_run_e2b_with_error_field() -> None:
    """When execution.error is set, exit_code should be 1 and success False."""
    from owlmind.tools.sandbox import _run_e2b

    fake_logs = MagicMock()
    fake_logs.stdout = []
    fake_logs.stderr = []

    fake_execution = MagicMock()
    fake_execution.logs = fake_logs
    fake_execution.error = "NameError: name 'x' is not defined"

    fake_sbx = MagicMock()
    fake_sbx.run_code.return_value = fake_execution
    fake_sbx.__enter__ = MagicMock(return_value=fake_sbx)
    fake_sbx.__exit__ = MagicMock(return_value=False)

    fake_e2b = MagicMock()
    fake_e2b.Sandbox.create.return_value = fake_sbx

    with patch.dict(sys.modules, {"e2b_code_interpreter": fake_e2b}):
        result = _run_e2b("print(x)", language="python", timeout=10, api_key="k")

    assert not result.success
    assert result.exit_code == 1


def test_run_e2b_fallback_on_error(monkeypatch: pytest.MonkeyPatch) -> None:
    """When _run_e2b raises, run_in_sandbox falls back to local execution."""
    monkeypatch.setenv("E2B_API_KEY", "test-key")

    fake_e2b = MagicMock()
    fake_e2b.Sandbox.create.side_effect = RuntimeError("network error")

    with patch.dict(sys.modules, {"e2b_code_interpreter": fake_e2b}):
        result = run_in_sandbox("print('fallback')", language="python", api_key="test-key")

    assert result.success
    assert "fallback" in result.stdout


# ---------------------------------------------------------------------------
# E2BSandbox class tests
# ---------------------------------------------------------------------------


def test_e2b_sandbox_class_is_available_no_module(monkeypatch: pytest.MonkeyPatch) -> None:
    """E2BSandbox.is_available() returns False when _E2B_OK is False (module missing)."""
    monkeypatch.setenv("E2B_API_KEY", "some-key")

    import owlmind.tools.sandbox as sandbox_mod

    original = sandbox_mod._E2B_OK
    try:
        sandbox_mod._E2B_OK = False
        from owlmind.tools.sandbox import E2BSandbox
        assert E2BSandbox.is_available() is False
    finally:
        sandbox_mod._E2B_OK = original


def test_e2b_sandbox_class_is_available_no_key(monkeypatch: pytest.MonkeyPatch) -> None:
    """E2BSandbox.is_available() returns False when E2B_API_KEY is not set."""
    monkeypatch.delenv("E2B_API_KEY", raising=False)

    import owlmind.tools.sandbox as sandbox_mod

    original = sandbox_mod._E2B_OK
    try:
        sandbox_mod._E2B_OK = True
        from owlmind.tools.sandbox import E2BSandbox
        assert E2BSandbox.is_available() is False
    finally:
        sandbox_mod._E2B_OK = original


def test_e2b_sandbox_class_is_available_true(monkeypatch: pytest.MonkeyPatch) -> None:
    """E2BSandbox.is_available() returns True when module present and key set."""
    monkeypatch.setenv("E2B_API_KEY", "test-key")

    import owlmind.tools.sandbox as sandbox_mod

    original = sandbox_mod._E2B_OK
    try:
        sandbox_mod._E2B_OK = True
        from owlmind.tools.sandbox import E2BSandbox
        assert E2BSandbox.is_available() is True
    finally:
        sandbox_mod._E2B_OK = original


# ---------------------------------------------------------------------------
# ShellTool sandbox integration tests
# ---------------------------------------------------------------------------


def _make_shell_policy(tmp_path: Path):  # type: ignore[return]
    """Create a permissive PolicyEngine for testing."""
    import re as _re

    from owlmind.policy import PolicyEngine

    return PolicyEngine(
        allowed_patterns=[_re.compile(r".*")],
        forbidden_patterns=[],
    )


def test_shell_tool_sandbox_false_runs_locally(tmp_path: Path) -> None:
    """ShellTool(sandbox=False) runs locally — default behaviour unchanged."""
    from owlmind.tools.shell import ShellTool

    policy = _make_shell_policy(tmp_path)
    shell = ShellTool(policy=policy, sandbox=False)

    result = shell.run("echo hello_local")
    assert result.exit_code == 0
    assert "hello_local" in result.stdout


def test_shell_tool_sandbox_true_falls_back_when_e2b_unavailable(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """ShellTool(sandbox=True) logs a warning and falls back to local when E2B unavailable."""
    from unittest.mock import patch

    from owlmind.tools import sandbox as sandbox_mod
    from owlmind.tools.shell import ShellTool

    policy = _make_shell_policy(tmp_path)
    monkeypatch.delenv("E2B_API_KEY", raising=False)

    with patch.object(sandbox_mod.E2BSandbox, "is_available", return_value=False):
        shell = ShellTool(policy=policy, sandbox=True)
        result = shell.run("echo fallback_local")

    assert result.exit_code == 0
    assert "fallback_local" in result.stdout
