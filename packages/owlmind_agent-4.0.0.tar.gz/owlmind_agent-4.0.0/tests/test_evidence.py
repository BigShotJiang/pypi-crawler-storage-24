"""Tests for EvidenceStore."""

from __future__ import annotations

from pathlib import Path

from owlmind.evidence import EvidenceStore
from owlmind.utils import sha256


class TestEvidenceStore:
    def test_create_run(self, tmp_path: Path) -> None:
        store = EvidenceStore(tmp_path / "runs")
        run_dir = store.create_run("run-test-001")
        assert run_dir.exists()
        assert (run_dir / "artifacts").exists()

    def test_append_and_read_events(self, tmp_path: Path) -> None:
        store = EvidenceStore(tmp_path / "runs")
        store.create_run("run-test-002")

        store.append_event("run-test-002", {"event": "started", "task": "T-1"})
        store.append_event("run-test-002", {"event": "finished", "task": "T-1"})

        events = store.read_events("run-test-002")
        assert len(events) == 2
        assert events[0]["event"] == "started"
        assert events[1]["event"] == "finished"
        assert "timestamp" in events[0]

    def test_write_and_read_artifact(self, tmp_path: Path) -> None:
        store = EvidenceStore(tmp_path / "runs")
        store.create_run("run-test-003")

        content = "pytest: 42 passed in 1.2s"
        artifact_hash = store.write_artifact("run-test-003", "pytest.txt", content)

        assert artifact_hash == sha256(content)
        art_path = tmp_path / "runs" / "run-test-003" / "artifacts" / "pytest.txt"
        assert art_path.exists()
        assert art_path.read_text() == content

    def test_write_and_read_meta(self, tmp_path: Path) -> None:
        store = EvidenceStore(tmp_path / "runs")
        store.create_run("run-test-004")

        meta = {"task_id": "T-1", "goal": "test"}
        store.write_meta("run-test-004", meta)

        loaded = store.read_meta("run-test-004")
        assert loaded["task_id"] == "T-1"

    def test_write_and_read_summary(self, tmp_path: Path) -> None:
        store = EvidenceStore(tmp_path / "runs")
        store.create_run("run-test-005")

        summary = {"status": "DONE", "actions": 3}
        store.write_summary("run-test-005", summary)

        loaded = store.read_summary("run-test-005")
        assert loaded["status"] == "DONE"

    def test_list_runs(self, tmp_path: Path) -> None:
        store = EvidenceStore(tmp_path / "runs")
        store.create_run("run-a")
        store.create_run("run-b")
        store.append_event("run-a", {"event": "test"})
        store.append_event("run-b", {"event": "test"})

        runs = store.list_runs()
        assert "run-a" in runs
        assert "run-b" in runs

    def test_read_missing_run(self, tmp_path: Path) -> None:
        store = EvidenceStore(tmp_path / "runs")
        assert store.read_events("nonexistent") == []
        assert store.read_meta("nonexistent") == {}
        assert store.read_summary("nonexistent") == {}


class TestListRunsNonExistentBase:
    """Line 289: base_dir does not exist → list_runs returns []."""

    def test_list_runs_missing_dir(self, tmp_path: Path) -> None:
        store = EvidenceStore(tmp_path / "nonexistent")
        assert store.list_runs() == []


class TestGetChainTipEmptyLog:
    """Line 73: log file exists but has only blank lines → returns genesis values."""

    def test_blank_log_returns_genesis(self, tmp_path: Path) -> None:
        store = EvidenceStore(tmp_path / "runs")
        run_dir = store.create_run("run-blank")
        (run_dir / "run.jsonl").write_text("\n   \n\n")
        tip_hash, seq = store.get_chain_tip("run-blank")
        assert seq == 0
        assert tip_hash == "0" * 64


class TestVerifyChainEdgeCases:
    """Lines 196, 199-201, 208-209: blank lines, bad JSON, missing _hash."""

    def test_blank_lines_skipped(self, tmp_path: Path) -> None:
        store = EvidenceStore(tmp_path / "runs")
        store.create_run("r-blank")
        store.append_event("r-blank", {"event": "e1"})
        store.append_event("r-blank", {"event": "e2"})
        log_path = tmp_path / "runs" / "r-blank" / "run.jsonl"
        lines = [ln for ln in log_path.read_text().splitlines() if ln.strip()]
        log_path.write_text(lines[0] + "\n\n\n" + lines[1] + "\n")
        result = store.verify_chain("r-blank")
        assert result.ok is True

    def test_invalid_json_error(self, tmp_path: Path) -> None:
        store = EvidenceStore(tmp_path / "runs")
        store.create_run("r-bad")
        log_path = tmp_path / "runs" / "r-bad" / "run.jsonl"
        log_path.write_text("not valid json\n")
        result = store.verify_chain("r-bad")
        assert result.ok is False
        assert any("invalid JSON" in e for e in result.errors)

    def test_missing_hash_field_error(self, tmp_path: Path) -> None:
        import json

        store = EvidenceStore(tmp_path / "runs")
        store.create_run("r-nohash")
        log_path = tmp_path / "runs" / "r-nohash" / "run.jsonl"
        log_path.write_text(json.dumps({"_seq": 1, "_prev_hash": "0" * 64, "event": "e1"}) + "\n")
        result = store.verify_chain("r-nohash")
        assert result.ok is False
        assert any("missing _hash" in e for e in result.errors)
