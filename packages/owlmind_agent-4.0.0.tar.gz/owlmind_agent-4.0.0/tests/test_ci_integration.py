"""Tests for CI/CD integration CLI commands."""

from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from typer.testing import CliRunner

from owlmind.cli.ops import ci_app
from owlmind.queue import QueueItem

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

runner = CliRunner()


def _make_session_meta(
    session_id: str = "ci-test001",
    status: str = "DONE",
    goals: list[dict[str, Any]] | None = None,
    runs: list[dict[str, Any]] | None = None,
) -> Any:
    """Create a mock SessionMeta."""
    from owlmind.session import GoalRunInfo, GoalSpec, SessionMeta

    now = datetime.now(tz=UTC).isoformat()
    goal_specs = []
    run_infos = []

    if goals:
        for g in goals:
            goal_specs.append(GoalSpec(id=g.get("id", "g-1"), goal=g.get("goal", "test")))
    else:
        goal_specs = [GoalSpec(id="goal-1", goal="test goal")]

    if runs:
        for r in runs:
            run_infos.append(
                GoalRunInfo(
                    goal_id=r.get("goal_id", "goal-1"),
                    run_id=r.get("run_id", "run-001"),
                    status=r.get("status", "done"),
                )
            )

    return SessionMeta(
        session_id=session_id,
        created_at=now,
        updated_at=now,
        status=status,
        goals=goal_specs,
        runs=run_infos,
    )


# ---------------------------------------------------------------------------
# ci session-status
# ---------------------------------------------------------------------------


class TestCISessionStatus:
    def test_session_status_done(self, tmp_path: Path) -> None:
        """ci session-status shows DONE status."""
        meta = _make_session_meta(status="DONE")

        mock_sessions = AsyncMock()
        mock_sessions.load_session = AsyncMock(return_value=meta)

        with patch("owlmind.storage.create_storage") as mock_create:
            mock_storage = MagicMock()
            mock_storage.sessions = mock_sessions
            mock_create.return_value = mock_storage

            import typer

            app = typer.Typer()
            app.add_typer(ci_app, name="ci")

            result = runner.invoke(
                app,
                ["ci", "session-status", "--session-id", "ci-test001", "--json"],
            )

        if result.exit_code == 0:
            data = json.loads(result.stdout)
            assert data["status"] == "DONE"
            assert data["exit_code"] == 0

    def test_session_status_running(self, tmp_path: Path) -> None:
        """ci session-status shows RUNNING status."""
        meta = _make_session_meta(status="RUNNING")

        mock_sessions = AsyncMock()
        mock_sessions.load_session = AsyncMock(return_value=meta)

        with patch("owlmind.storage.create_storage") as mock_create:
            mock_storage = MagicMock()
            mock_storage.sessions = mock_sessions
            mock_create.return_value = mock_storage

            import typer

            app = typer.Typer()
            app.add_typer(ci_app, name="ci")

            result = runner.invoke(
                app,
                ["ci", "session-status", "--session-id", "ci-test001", "--json"],
            )

        if result.exit_code == 1:
            data = json.loads(result.stdout)
            assert data["status"] == "RUNNING"
            assert data["exit_code"] == 1

    def test_session_status_error(self) -> None:
        """ci session-status handles errors gracefully."""
        with patch("owlmind.storage.create_storage") as mock_create:
            mock_storage = MagicMock()
            mock_sessions = AsyncMock()
            mock_sessions.load_session = AsyncMock(side_effect=FileNotFoundError("not found"))
            mock_storage.sessions = mock_sessions
            mock_create.return_value = mock_storage

            import typer

            app = typer.Typer()
            app.add_typer(ci_app, name="ci")

            result = runner.invoke(
                app,
                ["ci", "session-status", "--session-id", "missing", "--json"],
            )

        # Should return error
        assert result.exit_code == 1


# ---------------------------------------------------------------------------
# ci artifacts
# ---------------------------------------------------------------------------


class TestCIArtifacts:
    def test_artifacts_collects_files(self, tmp_path: Path) -> None:
        """ci artifacts copies run artifacts to output directory."""
        # Create mock run directory with artifacts
        runs_dir = tmp_path / "runs"
        run_dir = runs_dir / "run-001"
        run_dir.mkdir(parents=True)
        (run_dir / "diff.patch").write_text("--- a/file\n+++ b/file\n")
        (run_dir / "summary.json").write_text('{"ok": true}')

        meta = _make_session_meta(
            runs=[{"goal_id": "goal-1", "run_id": "run-001", "status": "done"}]
        )
        mock_sessions = AsyncMock()
        mock_sessions.load_session = AsyncMock(return_value=meta)

        with patch("owlmind.storage.create_storage") as mock_create:
            mock_storage = MagicMock()
            mock_storage.sessions = mock_sessions
            mock_create.return_value = mock_storage

            import typer

            app = typer.Typer()
            app.add_typer(ci_app, name="ci")

            output_dir = tmp_path / "ci-output"
            result = runner.invoke(
                app,
                [
                    "ci",
                    "artifacts",
                    "--session-id",
                    "ci-test001",
                    "--output-dir",
                    str(output_dir),
                    "--runs-dir",
                    str(runs_dir),
                ],
            )

        assert result.exit_code == 0
        assert "Collected" in result.stdout


# ---------------------------------------------------------------------------
# QueueItem session fields
# ---------------------------------------------------------------------------


class TestQueueItemSessionFields:
    def test_defaults_empty(self) -> None:
        """QueueItem has empty session_id and goal_id by default."""
        item = QueueItem(id="t-1", goal="test", workspace="/w")
        assert item.session_id == ""
        assert item.goal_id == ""

    def test_to_dict_includes_fields(self) -> None:
        """to_dict() includes session_id and goal_id."""
        item = QueueItem(id="t-1", goal="test", workspace="/w", session_id="s-1", goal_id="g-1")
        d = item.to_dict()
        assert d["session_id"] == "s-1"
        assert d["goal_id"] == "g-1"

    def test_from_dict_reads_fields(self) -> None:
        """from_dict() reads session_id and goal_id."""
        data = {
            "id": "t-1",
            "goal": "test",
            "workspace": "/w",
            "session_id": "s-1",
            "goal_id": "g-1",
        }
        item = QueueItem.from_dict(data)
        assert item.session_id == "s-1"
        assert item.goal_id == "g-1"

    def test_from_dict_defaults(self) -> None:
        """from_dict() defaults session fields to empty strings."""
        data = {"id": "t-1", "goal": "test", "workspace": "/w"}
        item = QueueItem.from_dict(data)
        assert item.session_id == ""
        assert item.goal_id == ""


# ---------------------------------------------------------------------------
# Storage factory — kafka backend
# ---------------------------------------------------------------------------


class TestKafkaFactory:
    def test_kafka_requires_bootstrap_servers(self) -> None:
        """create_storage raises ValueError without kafka_bootstrap_servers."""
        from owlmind.storage import create_storage

        with pytest.raises(ValueError, match="kafka_bootstrap_servers"):
            create_storage(backend="kafka")

    def test_unknown_backend_raises(self) -> None:
        """create_storage raises ValueError for unknown backend."""
        from owlmind.storage import create_storage

        with pytest.raises(ValueError, match="Unknown"):
            create_storage(backend="nosql")


# ---------------------------------------------------------------------------
# Serialization
# ---------------------------------------------------------------------------


class TestSerialization:
    def test_json_dumps_returns_bytes(self) -> None:
        """json_dumps returns bytes."""
        from owlmind.storage.serialization import json_dumps

        result = json_dumps({"key": "value"})
        assert isinstance(result, bytes)
        assert b"key" in result

    def test_json_dumps_str_returns_str(self) -> None:
        """json_dumps_str returns str."""
        from owlmind.storage.serialization import json_dumps_str

        result = json_dumps_str({"key": "value"})
        assert isinstance(result, str)
        assert "key" in result

    def test_json_roundtrip(self) -> None:
        """json_dumps + json_loads is lossless."""
        from owlmind.storage.serialization import json_dumps, json_loads

        original = {"a": 1, "b": [2, 3], "c": {"d": True}}
        encoded = json_dumps(original)
        decoded = json_loads(encoded)
        assert decoded == original

    def test_json_loads_str_input(self) -> None:
        """json_loads accepts str input."""
        from owlmind.storage.serialization import json_loads

        result = json_loads('{"x": 42}')
        assert result == {"x": 42}
