"""Tests for owlmind.tools.web_search_tool."""
from __future__ import annotations

from unittest.mock import patch

from owlmind.tools.web_search_tool import WebResult, WebSearchResult, WebSearchTool, fetch_page_text

# ---------------------------------------------------------------------------
# WebResult
# ---------------------------------------------------------------------------


class TestWebResult:
    def test_fields(self) -> None:
        r = WebResult(title="Example", url="https://example.com", snippet="Some text")
        assert r.title == "Example"
        assert r.url == "https://example.com"
        assert r.snippet == "Some text"

    def test_default_snippet(self) -> None:
        r = WebResult(title="T", url="https://t.com")
        assert r.snippet == ""


# ---------------------------------------------------------------------------
# WebSearchResult
# ---------------------------------------------------------------------------


class TestWebSearchResult:
    def test_empty_count(self) -> None:
        result = WebSearchResult(query="test", results=[])
        assert result.count == 0

    def test_as_text_no_results(self) -> None:
        result = WebSearchResult(query="test", results=[])
        text = result.as_text()
        assert "test" in text
        assert "No results" in text or "not found" in text.lower() or "no results" in text.lower()

    def test_as_text_with_results(self) -> None:
        results = [
            WebResult(title="A", url="https://a.com", snippet="Snippet A"),
            WebResult(title="B", url="https://b.com", snippet="Snippet B"),
        ]
        result = WebSearchResult(query="hello", results=results)
        assert result.count == 2
        text = result.as_text()
        assert "A" in text
        assert "https://a.com" in text
        assert "Snippet A" in text

    def test_as_text_error(self) -> None:
        result = WebSearchResult(query="q", results=[], error="timeout")
        text = result.as_text()
        assert "timeout" in text or "error" in text.lower()

    def test_source_default(self) -> None:
        result = WebSearchResult(query="q")
        assert result.source == "duckduckgo"


# ---------------------------------------------------------------------------
# WebSearchTool
# ---------------------------------------------------------------------------


class TestWebSearchTool:
    def test_is_available_returns_bool(self) -> None:
        tool = WebSearchTool()
        assert isinstance(tool.is_available(), bool)

    def test_search_returns_web_search_result(self) -> None:
        """search() always returns WebSearchResult, even on failure."""
        tool = WebSearchTool()
        # Make _search_httpx return None; browser fallback will fail naturally
        with patch.object(tool, "_search_httpx", return_value=None):
            result = tool.search("python tutorial", num_results=3)
        assert isinstance(result, WebSearchResult)
        assert result.query == "python tutorial"

    def test_search_uses_httpx_results(self) -> None:
        """search() returns httpx results when available."""
        tool = WebSearchTool()
        fake_results = [WebResult(title="T", url="https://t.com", snippet="s")]
        with patch.object(tool, "_search_httpx", return_value=fake_results):
            result = tool.search("query")
        assert result.count == 1
        assert result.results[0].title == "T"

    def test_search_falls_back_when_httpx_returns_none(self) -> None:
        """search() returns empty result when _search_httpx returns None and no browser."""
        tool = WebSearchTool()
        with patch.object(tool, "_search_httpx", return_value=None):
            with patch("owlmind.tools.web_search_tool.logger"):
                result = tool.search("query")
        assert isinstance(result, WebSearchResult)

    def test_parse_ddg_html_returns_list(self) -> None:
        """_parse_ddg_html always returns a list."""
        tool = WebSearchTool()
        results = tool._parse_ddg_html("<html><body>no results</body></html>", num_results=5)
        assert isinstance(results, list)

    def test_parse_ddg_html_extracts_result(self) -> None:
        """_parse_ddg_html extracts links from DDG HTML structure."""
        tool = WebSearchTool()
        # Minimal DDG-like HTML with a result block
        html = (
            'class="result results_links"'
            ' <a class="result__a" href="/l/?uddg=https%3A%2F%2Fexample.com">Example Title</a>'
            ' <a class="result__snippet">A useful snippet</a>'
        )
        results = tool._parse_ddg_html(html, num_results=5)
        # May or may not parse — just no crash
        assert isinstance(results, list)
        if results:
            assert results[0].title
            assert results[0].url.startswith("http")


# ---------------------------------------------------------------------------
# fetch_page_text
# ---------------------------------------------------------------------------


class TestFetchPageText:
    def test_returns_string_on_success(self) -> None:
        """fetch_page_text() always returns a string."""
        # httpx is imported inside the function; just call and verify return type
        result = fetch_page_text("https://example.com", max_chars=1000)
        assert isinstance(result, str)

    def test_returns_string_on_failure(self) -> None:
        """fetch_page_text() returns a string even when fetch fails."""
        result = fetch_page_text("https://this-does-not-exist-xyzzy-12345.invalid/")
        assert isinstance(result, str)

    def test_respects_max_chars_conceptually(self) -> None:
        """fetch_page_text max_chars param is accepted without error."""
        result = fetch_page_text("https://example.com", max_chars=100)
        assert isinstance(result, str)
        assert len(result) <= 4000  # Whatever came back should be reasonable
