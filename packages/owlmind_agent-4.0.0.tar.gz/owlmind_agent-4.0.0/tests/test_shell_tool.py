"""Tests for ShellTool."""

from __future__ import annotations

import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

from owlmind.policy import PolicyDecision, PolicyEngine, PolicyResult
from owlmind.tools.shell import ShellTool
from owlmind.utils import ToolLimits

POLICIES_DIR = Path(__file__).resolve().parent.parent / "policies"


class TestShellTool:
    def setup_method(self) -> None:
        self.policy = PolicyEngine.from_directory(POLICIES_DIR)
        self.tool = ShellTool(policy=self.policy, limits=ToolLimits(timeout_seconds=10))

    def test_allowed_command_runs(self) -> None:
        result = self.tool.run("echo hello")
        assert result.exit_code == 0
        assert "hello" in result.stdout

    def test_denied_command_returns_policy_error(self) -> None:
        result = self.tool.run("nc -l 8080")
        assert result.exit_code == -1
        assert "POLICY DENIED" in result.stderr

    def test_forbidden_command_denied(self) -> None:
        result = self.tool.run("rm -rf /tmp/test")
        assert result.exit_code == -1
        assert "POLICY DENIED" in result.stderr

    def test_stdout_hash_populated(self) -> None:
        result = self.tool.run("echo test")
        assert len(result.stdout_hash) == 64  # SHA-256 hex

    def test_env_fingerprint_populated(self) -> None:
        result = self.tool.run("echo fp")
        assert len(result.env_fingerprint) == 64

    def test_ls_command(self) -> None:
        result = self.tool.run("ls /tmp")
        assert result.exit_code == 0

    def test_cat_command(self) -> None:
        result = self.tool.run("cat /dev/null")
        assert result.exit_code == 0


class TestShellToolEdgeCases:
    """Test uncovered edge cases: invalid syntax, timeout, command not found."""

    def _make_tool(self) -> ShellTool:
        policy = MagicMock()
        policy.evaluate.return_value = PolicyResult(decision=PolicyDecision.ALLOW, reason="ok")
        return ShellTool(policy=policy, limits=ToolLimits(timeout_seconds=5))

    def test_invalid_command_syntax(self) -> None:
        tool = self._make_tool()
        result = tool.run("echo 'unterminated")
        assert result.exit_code == -3
        assert "Invalid command syntax" in result.stderr

    @patch("owlmind.tools.shell.subprocess.run")
    def test_timeout_expired(self, mock_run: MagicMock) -> None:
        mock_run.side_effect = subprocess.TimeoutExpired(cmd="sleep", timeout=5)
        tool = self._make_tool()
        result = tool.run("sleep 999")
        assert result.exit_code == -2
        assert "TIMEOUT" in result.stderr
        assert result.duration_ms >= 0

    def test_command_not_found(self) -> None:
        tool = self._make_tool()
        result = tool.run("__nonexistent_command_xyz_42__")
        assert result.exit_code == -4
        assert "Command not found" in result.stderr
        assert result.duration_ms >= 0
