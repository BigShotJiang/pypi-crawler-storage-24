"""Tests for sync storage adapters and helper functions."""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path

from owlmind.storage.adapters import (
    LedgerStorageSync,
    MemoryStorageSync,
    QueueStorageSync,
    RunStorageSync,
    get_sync_ledger,
    get_sync_memory,
    get_sync_queue,
    get_sync_run_storage,
)
from owlmind.storage.file import (
    FileLedgerStorage,
    FileMemoryStorage,
    FileQueueStorage,
    FileRunStorage,
)

# ===================================================================
# RunStorageSync
# ===================================================================


class TestRunStorageSync:
    def test_create_and_read(self, tmp_path: Path) -> None:
        async_store = FileRunStorage(tmp_path / "runs")
        sync_store = RunStorageSync(async_store)

        sync_store.create_run("run-sync-001")
        assert (tmp_path / "runs" / "run-sync-001").is_dir()

    def test_append_and_read_events(self, tmp_path: Path) -> None:
        async_store = FileRunStorage(tmp_path / "runs")
        sync_store = RunStorageSync(async_store)

        sync_store.create_run("run-sync-002")
        h1 = sync_store.append_event("run-sync-002", {"event": "START"})
        h2 = sync_store.append_event("run-sync-002", {"event": "STOP"})

        assert isinstance(h1, str) and len(h1) == 64
        assert h1 != h2

        events = sync_store.read_events("run-sync-002")
        assert len(events) == 2
        assert events[0]["event"] == "START"

    def test_chain_tip(self, tmp_path: Path) -> None:
        async_store = FileRunStorage(tmp_path / "runs")
        sync_store = RunStorageSync(async_store)

        sync_store.create_run("run-sync-003")
        tip_hash, seq = sync_store.get_chain_tip("run-sync-003")
        assert seq == 0

        sync_store.append_event("run-sync-003", {"event": "A"})
        tip_hash, seq = sync_store.get_chain_tip("run-sync-003")
        assert seq == 1
        assert len(tip_hash) == 64

    def test_verify_chain(self, tmp_path: Path) -> None:
        async_store = FileRunStorage(tmp_path / "runs")
        sync_store = RunStorageSync(async_store)

        sync_store.create_run("run-sync-004")
        sync_store.append_event("run-sync-004", {"event": "X"})
        sync_store.append_event("run-sync-004", {"event": "Y"})

        result = sync_store.verify_chain("run-sync-004")
        assert result.ok
        assert result.seq == 2

    def test_meta_roundtrip(self, tmp_path: Path) -> None:
        async_store = FileRunStorage(tmp_path / "runs")
        sync_store = RunStorageSync(async_store)

        sync_store.create_run("run-sync-005")
        sync_store.write_meta("run-sync-005", {"goal": "test"})
        loaded = sync_store.read_meta("run-sync-005")
        assert loaded["goal"] == "test"

    def test_summary_roundtrip(self, tmp_path: Path) -> None:
        async_store = FileRunStorage(tmp_path / "runs")
        sync_store = RunStorageSync(async_store)

        sync_store.create_run("run-sync-006")
        sync_store.write_summary("run-sync-006", {"verdict": "OK"})
        loaded = sync_store.read_summary("run-sync-006")
        assert loaded["verdict"] == "OK"

    def test_write_artifact(self, tmp_path: Path) -> None:
        async_store = FileRunStorage(tmp_path / "runs")
        sync_store = RunStorageSync(async_store)

        sync_store.create_run("run-sync-007")
        sha = sync_store.write_artifact("run-sync-007", "test.txt", "hello")
        assert isinstance(sha, str) and len(sha) == 64

    def test_write_manifest(self, tmp_path: Path) -> None:
        async_store = FileRunStorage(tmp_path / "runs")
        sync_store = RunStorageSync(async_store)

        sync_store.create_run("run-sync-008")
        sync_store.write_artifact("run-sync-008", "data.txt", "data")
        manifest = sync_store.write_manifest("run-sync-008")
        assert manifest["artifact_count"] == 1

    def test_list_runs(self, tmp_path: Path) -> None:
        async_store = FileRunStorage(tmp_path / "runs")
        sync_store = RunStorageSync(async_store)

        sync_store.create_run("run-a")
        sync_store.append_event("run-a", {"event": "init"})
        sync_store.create_run("run-b")
        sync_store.append_event("run-b", {"event": "init"})

        runs = sync_store.list_runs()
        assert "run-a" in runs
        assert "run-b" in runs

    def test_base_dir_proxy(self, tmp_path: Path) -> None:
        async_store = FileRunStorage(tmp_path / "runs")
        sync_store = RunStorageSync(async_store)
        assert sync_store.base_dir == tmp_path / "runs"

    def test_read_missing_returns_empty(self, tmp_path: Path) -> None:
        async_store = FileRunStorage(tmp_path / "runs")
        sync_store = RunStorageSync(async_store)
        assert sync_store.read_meta("nonexistent") == {}
        assert sync_store.read_summary("nonexistent") == {}
        assert sync_store.read_events("nonexistent") == []


# ===================================================================
# LedgerStorageSync
# ===================================================================


class TestLedgerStorageSync:
    def _make_entry(self, run_id: str = "run-1") -> object:
        from owlmind.ledger import UsageEntry

        return UsageEntry(
            ts=datetime.now(tz=UTC).isoformat(),
            run_id=run_id,
            stage="planner",
            provider="openai",
            model="gpt-4o",
            input_tokens=100,
            output_tokens=50,
            total_tokens=150,
            estimated_usd=0.005,
            latency_ms=200,
            price_per_1k_input=0.0025,
            price_per_1k_output=0.01,
        )

    def test_record_and_recent(self, tmp_path: Path) -> None:
        async_store = FileLedgerStorage(tmp_path / "ledger")
        sync_store = LedgerStorageSync(async_store)

        sync_store.record(self._make_entry())
        sync_store.record(self._make_entry())

        recent = sync_store.recent(10)
        assert len(recent) == 2

    def test_totals_for_day(self, tmp_path: Path) -> None:
        async_store = FileLedgerStorage(tmp_path / "ledger")
        sync_store = LedgerStorageSync(async_store)

        sync_store.record(self._make_entry())
        totals = sync_store.totals_for_day()
        assert totals.llm_calls == 1
        assert totals.total_tokens == 150

    def test_totals_for_run(self, tmp_path: Path) -> None:
        async_store = FileLedgerStorage(tmp_path / "ledger")
        sync_store = LedgerStorageSync(async_store)

        sync_store.record(self._make_entry("run-x"))
        sync_store.record(self._make_entry("run-y"))

        totals = sync_store.totals_for_run("run-x")
        assert totals.llm_calls == 1

    def test_entries_for_day(self, tmp_path: Path) -> None:
        async_store = FileLedgerStorage(tmp_path / "ledger")
        sync_store = LedgerStorageSync(async_store)

        sync_store.record(self._make_entry())
        entries = sync_store.entries_for_day()
        assert len(entries) == 1

    def test_calls_in_last_hour(self, tmp_path: Path) -> None:
        async_store = FileLedgerStorage(tmp_path / "ledger")
        sync_store = LedgerStorageSync(async_store)

        sync_store.record(self._make_entry())
        count = sync_store.calls_in_last_hour()
        assert count == 1

    def test_ledger_dir_proxy(self, tmp_path: Path) -> None:
        async_store = FileLedgerStorage(tmp_path / "ledger")
        sync_store = LedgerStorageSync(async_store)
        assert sync_store.ledger_dir == tmp_path / "ledger"


# ===================================================================
# QueueStorageSync
# ===================================================================


class TestQueueStorageSync:
    def test_add_and_list(self, tmp_path: Path) -> None:
        async_store = FileQueueStorage(tmp_path / "queue")
        sync_store = QueueStorageSync(async_store)

        item = sync_store.add("build app", "/workspace")
        assert item.goal == "build app"
        assert item.id.startswith("task-")

        items = sync_store.list_items()
        assert len(items) == 1

    def test_next_pending_priority(self, tmp_path: Path) -> None:
        async_store = FileQueueStorage(tmp_path / "queue")
        sync_store = QueueStorageSync(async_store)

        sync_store.add("low", "/ws", priority=1)
        sync_store.add("high", "/ws", priority=10)

        nxt = sync_store.next_pending()
        assert nxt is not None
        assert nxt.goal == "high"

    def test_mark_lifecycle(self, tmp_path: Path) -> None:
        async_store = FileQueueStorage(tmp_path / "queue")
        sync_store = QueueStorageSync(async_store)

        item = sync_store.add("task", "/ws")
        sync_store.mark_running(item.id, "run-001")
        items = sync_store.list_items(status="RUNNING")
        assert len(items) == 1

        sync_store.mark_done(item.id)
        items = sync_store.list_items(status="DONE")
        assert len(items) == 1

    def test_mark_failed(self, tmp_path: Path) -> None:
        async_store = FileQueueStorage(tmp_path / "queue")
        sync_store = QueueStorageSync(async_store)

        item = sync_store.add("fail-task", "/ws")
        sync_store.mark_failed(item.id, error="timeout")
        items = sync_store.list_items(status="FAILED")
        assert len(items) == 1
        assert items[0].error == "timeout"

    def test_next_pending_empty(self, tmp_path: Path) -> None:
        async_store = FileQueueStorage(tmp_path / "queue")
        sync_store = QueueStorageSync(async_store)
        assert sync_store.next_pending() is None


# ===================================================================
# MemoryStorageSync
# ===================================================================


class TestMemoryStorageSync:
    def test_ingest_and_query(self, tmp_path: Path) -> None:
        async_store = FileMemoryStorage(tmp_path / "memory.db")
        sync_store = MemoryStorageSync(async_store)

        doc_id = sync_store.ingest("doc", "search.py", "python sorting algorithm binary search")
        sync_store.ingest("doc", "unrelated.py", "javascript react component rendering hooks state")
        assert doc_id.startswith("doc-")

        results = sync_store.query("python sorting algorithm", top_k=3)
        assert len(results) >= 1
        assert results[0]["source"] == "search.py"

        sync_store.close()

    def test_signals(self, tmp_path: Path) -> None:
        async_store = FileMemoryStorage(tmp_path / "memory.db")
        sync_store = MemoryStorageSync(async_store)

        sid = sync_store.add_signal("lesson", "Always test edge cases", run_id="r1")
        assert sid > 0

        signals = sync_store.get_signals("lesson")
        assert len(signals) == 1
        assert signals[0].summary == "Always test edge cases"

        sync_store.close()

    def test_stats(self, tmp_path: Path) -> None:
        async_store = FileMemoryStorage(tmp_path / "memory.db")
        sync_store = MemoryStorageSync(async_store)

        sync_store.ingest("doc", "a.py", "content A")
        sync_store.add_signal("error", "Something failed")

        st = sync_store.stats()
        assert st["documents"] == 1
        assert st["signals"] == 1

        sync_store.close()

    def test_build_memory_context(self, tmp_path: Path) -> None:
        async_store = FileMemoryStorage(tmp_path / "memory.db")
        sync_store = MemoryStorageSync(async_store)

        sync_store.ingest("doc", "api.py", "REST API endpoint for users")
        sync_store.add_signal("lesson", "Use pagination for large datasets")

        ctx = sync_store.build_memory_context("API endpoint", top_k=3)
        assert "Relevant Memory" in ctx or "Signals" in ctx

        sync_store.close()

    def test_purge(self, tmp_path: Path) -> None:
        async_store = FileMemoryStorage(tmp_path / "memory.db")
        sync_store = MemoryStorageSync(async_store)

        sync_store.ingest("doc", "old.py", "old content")
        count = sync_store.purge()
        assert count >= 1

        st = sync_store.stats()
        assert st["documents"] == 0

        sync_store.close()

    def test_get_chunks(self, tmp_path: Path) -> None:
        async_store = FileMemoryStorage(tmp_path / "memory.db")
        sync_store = MemoryStorageSync(async_store)

        doc_id = sync_store.ingest("doc", "big.py", "A" * 2000)
        chunks = sync_store.get_chunks(doc_id)
        assert len(chunks) >= 1

        sync_store.close()


# ===================================================================
# Helper functions — get_sync_*
# ===================================================================


class TestGetSyncHelpers:
    def test_get_sync_run_storage_file_backend(self, tmp_path: Path) -> None:
        """File backend returns underlying EvidenceStore via .sync."""
        from owlmind.evidence import EvidenceStore

        async_store = FileRunStorage(tmp_path / "runs")
        result = get_sync_run_storage(async_store)
        assert isinstance(result, EvidenceStore)

    def test_get_sync_run_storage_generic(self, tmp_path: Path) -> None:
        """Object without .sync gets wrapped in RunStorageSync."""

        class FakeRunStorage:
            """Minimal RunStorage without .sync property."""

            async def create_run(self, run_id: str) -> None:
                pass

        result = get_sync_run_storage(FakeRunStorage())
        assert isinstance(result, RunStorageSync)

    def test_get_sync_ledger_file_backend(self, tmp_path: Path) -> None:
        from owlmind.ledger import UsageLedger

        async_store = FileLedgerStorage(tmp_path / "ledger")
        result = get_sync_ledger(async_store)
        assert isinstance(result, UsageLedger)

    def test_get_sync_queue_file_backend(self, tmp_path: Path) -> None:
        from owlmind.queue import TaskQueue

        async_store = FileQueueStorage(tmp_path / "queue")
        result = get_sync_queue(async_store)
        assert isinstance(result, TaskQueue)

    def test_get_sync_memory_file_backend(self, tmp_path: Path) -> None:
        from owlmind.memory.store import MemoryStore

        async_store = FileMemoryStorage(tmp_path / "memory.db")
        result = get_sync_memory(async_store)
        assert isinstance(result, MemoryStore)
        async_store.sync.close()


# ===================================================================
# make_storage helper
# ===================================================================


class TestMakeStorage:
    def test_make_storage(self, tmp_path: Path) -> None:
        from owlmind.cli._helpers import make_storage
        from owlmind.storage.interface import StorageBackend

        sb = make_storage(
            runs_dir=tmp_path / "runs",
            ledger_dir=tmp_path / "ledger",
            queue_dir=tmp_path / "queue",
            sessions_dir=tmp_path / "sessions",
        )
        assert isinstance(sb, StorageBackend)

    def test_make_storage_with_memory(self, tmp_path: Path) -> None:
        from owlmind.cli._helpers import make_storage
        from owlmind.storage.file import FileMemoryStorage

        sb = make_storage(
            runs_dir=tmp_path / "runs",
            ledger_dir=tmp_path / "ledger",
            queue_dir=tmp_path / "queue",
            sessions_dir=tmp_path / "sessions",
            memory_db=tmp_path / "memory" / "memory.db",
        )
        assert isinstance(sb.memory, FileMemoryStorage)


# ===================================================================
# Integration: StorageBackend in API app
# ===================================================================


class TestAPIStorageIntegration:
    def test_create_app_with_storage(self, tmp_path: Path) -> None:
        from owlmind.api.app import create_app
        from owlmind.storage import create_storage

        sb = create_storage(
            runs_dir=tmp_path / "runs",
            ledger_dir=tmp_path / "ledger",
            queue_dir=tmp_path / "queue",
            sessions_dir=tmp_path / "sessions",
        )
        app = create_app(
            runs_dir=tmp_path / "runs",
            ledger_dir=tmp_path / "ledger",
            queue_path=tmp_path / "queue",
            policies_dir=tmp_path / "policies",
            storage=sb,
        )
        assert app.state.storage is sb

    def test_create_app_without_storage(self, tmp_path: Path) -> None:
        from owlmind.api.app import create_app

        app = create_app(
            runs_dir=tmp_path / "runs",
            ledger_dir=tmp_path / "ledger",
            queue_path=tmp_path / "queue",
            policies_dir=tmp_path / "policies",
        )
        assert app.state.storage is None
