"""Tests for FS62 — OperatorService max_concurrent_runs semaphore."""

import contextlib
from pathlib import Path
from unittest.mock import MagicMock, patch

from owlmind.operator import OperatorService


def _make_svc(tmp_path: Path, max_concurrent_runs: int = 0) -> OperatorService:
    return OperatorService(
        runs_dir=tmp_path / "runs",
        policies_dir=tmp_path / "policies",
        ledger_dir=tmp_path / "ledger",
        max_concurrent_runs=max_concurrent_runs,
    )


def test_zero_means_unlimited(tmp_path: Path) -> None:
    """max_concurrent_runs=0 → _semaphore is None (no limit)."""
    svc = _make_svc(tmp_path, max_concurrent_runs=0)
    assert svc._semaphore is None
    assert svc.max_concurrent_runs == 0


def test_semaphore_created_for_positive(tmp_path: Path) -> None:
    """max_concurrent_runs=2 → _semaphore is a Semaphore."""
    import threading

    svc = _make_svc(tmp_path, max_concurrent_runs=2)
    assert isinstance(svc._semaphore, threading.Semaphore)
    assert svc.max_concurrent_runs == 2


def test_blocks_when_at_capacity(tmp_path: Path) -> None:
    """Manually exhaust semaphore → start_autopilot raises RuntimeError."""
    svc = _make_svc(tmp_path, max_concurrent_runs=1)
    assert svc._semaphore is not None

    # Manually acquire the only slot
    svc._semaphore.acquire()

    mock_result = MagicMock()
    mock_result.run_id = "cycle-should-not-run"
    mock_result.final_state = "DONE"
    mock_result.stop_reason = ""

    try:
        with patch("owlmind.autopilot.run", return_value=mock_result):
            raised = False
            try:
                svc.start_autopilot("blocked goal", str(tmp_path))
            except RuntimeError as exc:
                raised = True
                assert "Max concurrent runs" in str(exc)
            assert raised, "Expected RuntimeError but none was raised"
    finally:
        svc._semaphore.release()


def test_semaphore_released_on_error(tmp_path: Path) -> None:
    """If autopilot.run raises, semaphore is still released."""
    svc = _make_svc(tmp_path, max_concurrent_runs=1)
    assert svc._semaphore is not None

    with (
        patch("owlmind.autopilot.run", side_effect=RuntimeError("autopilot exploded")),
        contextlib.suppress(RuntimeError),
    ):
        svc.start_autopilot("failing goal", str(tmp_path))

    # Semaphore should have been released — acquiring it again must succeed (non-blocking)
    acquired = svc._semaphore.acquire(blocking=False)
    assert acquired, "Semaphore was not released after error"
    svc._semaphore.release()
