"""Tests for FS65 — CLI core commands (doctor, run, show, replay, heartbeat)."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from owlmind.cli import app

runner = CliRunner()


class TestDoctorCommand:
    def test_doctor_ok(self, tmp_path: Path) -> None:
        """doctor with all policy files present → exit 0."""
        policies_dir = tmp_path / "policies"
        policies_dir.mkdir()
        (policies_dir / "allowlist.yaml").write_text("allowed: []\n")
        (policies_dir / "policy.yaml").write_text("policy: {}\n")
        (policies_dir / "judge_rules.yaml").write_text("rules: []\n")

        mock_engine = MagicMock()
        mock_engine.allowed_patterns = []
        mock_engine.forbidden_patterns = []

        with patch("owlmind.cli.core.PolicyEngine") as MockPE:
            MockPE.from_directory.return_value = mock_engine
            result = runner.invoke(app, ["doctor", "--policies", str(policies_dir)])

        assert result.exit_code == 0, result.output
        assert "All checks passed" in result.output

    def test_doctor_fails_without_policies_dir(self, tmp_path: Path) -> None:
        """doctor with missing policies_dir → exit 1."""
        missing = tmp_path / "no-such-dir"
        result = runner.invoke(app, ["doctor", "--policies", str(missing)])

        assert result.exit_code == 1
        assert "Some checks failed" in result.output

    def test_doctor_fix_calls_doctor_fix(self, tmp_path: Path) -> None:
        """doctor --fix invokes owlmind.setup.doctor_fix."""
        mock_report = MagicMock()
        mock_report.fixes = []
        mock_report.warnings = []

        with patch("owlmind.setup.doctor_fix", return_value=mock_report) as mock_fix:
            runner.invoke(
                app,
                [
                    "doctor",
                    "--policies",
                    str(tmp_path / "p"),
                    "--fix",
                    "--workspace",
                    str(tmp_path),
                ],
            )

        mock_fix.assert_called_once()


class TestRunCommand:
    def test_run_task_file_not_found(self, tmp_path: Path) -> None:
        """run with missing task file → exit 1."""
        result = runner.invoke(app, ["run", str(tmp_path / "missing.json")])

        assert result.exit_code == 1
        assert "not found" in result.output

    def test_run_executes_task(self, tmp_path: Path) -> None:
        """run with valid task + mocked Orchestrator → exit 0."""
        task_file = tmp_path / "task.json"
        task_file.write_text(json.dumps({"goal": "test goal", "actions": []}))

        mock_summary = MagicMock()
        mock_summary.state.value = "DONE"
        mock_summary.actions_executed = 0
        mock_summary.actions_failed = 0

        mock_orch = MagicMock()
        mock_orch.run.return_value = mock_summary
        mock_orch.run_id = "run-001"

        with (
            patch("owlmind.cli.core.TaskSpec") as MockTS,
            patch("owlmind.cli.core.PolicyEngine"),
            patch("owlmind.cli.core.EvidenceStore"),
            patch("owlmind.cli.core.ToolLimits"),
            patch("owlmind.cli.core.Orchestrator", return_value=mock_orch),
        ):
            MockTS.return_value.goal = "test goal"
            MockTS.return_value.actions = []
            result = runner.invoke(
                app,
                ["run", str(task_file), "--runs", str(tmp_path / "runs")],
            )

        assert result.exit_code == 0, result.output
        assert "DONE" in result.output


class TestShowCommand:
    def test_show_run_not_found(self, tmp_path: Path) -> None:
        """show with unknown run_id → exit 1."""
        mock_es = MagicMock()
        mock_es.return_value.read_meta.return_value = None

        with patch("owlmind.cli.core.EvidenceStore", mock_es):
            result = runner.invoke(app, ["show", "ghost-run", "--runs", str(tmp_path)])

        assert result.exit_code == 1
        assert "not found" in result.output

    def test_show_ok(self, tmp_path: Path) -> None:
        """show with existing run → exit 0, run_id in output."""
        mock_es = MagicMock()
        mock_es.return_value.read_meta.return_value = {
            "task_id": "t-1",
            "goal": "test goal",
            "started_at": "2024-01-01T00:00:00",
        }
        mock_es.return_value.read_summary.return_value = {}
        mock_es.return_value.read_events.return_value = []

        with patch("owlmind.cli.core.EvidenceStore", mock_es):
            result = runner.invoke(app, ["show", "run-001", "--runs", str(tmp_path)])

        assert result.exit_code == 0
        assert "run-001" in result.output


class TestReplayCommand:
    def test_replay_no_events(self, tmp_path: Path) -> None:
        """replay with no events → exit 1."""
        mock_es = MagicMock()
        mock_es.return_value.read_events.return_value = []

        with patch("owlmind.cli.core.EvidenceStore", mock_es):
            result = runner.invoke(app, ["replay", "empty-run", "--runs", str(tmp_path)])

        assert result.exit_code == 1

    def test_replay_ok(self, tmp_path: Path) -> None:
        """replay with events → exit 0, event type shown in output."""
        mock_es = MagicMock()
        mock_es.return_value.read_events.return_value = [
            {"event": "step_done", "timestamp": "2024-01-01T00:00:00"},
        ]

        with patch("owlmind.cli.core.EvidenceStore", mock_es):
            result = runner.invoke(app, ["replay", "run-with-events", "--runs", str(tmp_path)])

        assert result.exit_code == 0
        assert "step_done" in result.output


class TestHeartbeatCommand:
    def test_heartbeat_once_no_messages(self, tmp_path: Path) -> None:
        """heartbeat --once with no messages → 'Nothing to report' in output."""
        mock_hb = MagicMock()
        mock_hb.return_value.tick.return_value = []

        with (
            patch("owlmind.heartbeat.HeartbeatEngine", mock_hb),
            patch("owlmind.queue.TaskQueue"),
            patch("owlmind.events.EventBus"),
        ):
            result = runner.invoke(
                app,
                [
                    "heartbeat",
                    "--once",
                    "--runs",
                    str(tmp_path),
                    "--queue-dir",
                    str(tmp_path / "q"),
                ],
            )

        assert result.exit_code == 0
        assert "Nothing to report" in result.output

    def test_heartbeat_once_with_messages(self, tmp_path: Path) -> None:
        """heartbeat --once with messages → messages printed (lines 240-241)."""
        mock_hb = MagicMock()
        mock_hb.return_value.tick.return_value = ["run-001 stuck", "queue empty"]

        with (
            patch("owlmind.heartbeat.HeartbeatEngine", mock_hb),
            patch("owlmind.queue.TaskQueue"),
            patch("owlmind.events.EventBus"),
        ):
            result = runner.invoke(
                app,
                [
                    "heartbeat",
                    "--once",
                    "--runs",
                    str(tmp_path),
                    "--queue-dir",
                    str(tmp_path / "q"),
                ],
            )

        assert result.exit_code == 0
        assert "run-001 stuck" in result.output
        assert "queue empty" in result.output

    def test_heartbeat_loop_keyboard_interrupt(self, tmp_path: Path) -> None:
        """heartbeat loop mode → KeyboardInterrupt → graceful stop (lines 246-252)."""
        mock_hb = MagicMock()
        mock_hb.return_value.run_loop.side_effect = KeyboardInterrupt

        with (
            patch("owlmind.heartbeat.HeartbeatEngine", mock_hb),
            patch("owlmind.queue.TaskQueue"),
            patch("owlmind.events.EventBus"),
        ):
            result = runner.invoke(
                app,
                [
                    "heartbeat",
                    "--runs",
                    str(tmp_path),
                    "--queue-dir",
                    str(tmp_path / "q"),
                ],
            )

        assert result.exit_code == 0
        assert "stopped" in result.output.lower()

    def test_heartbeat_loop_auto_queue(self, tmp_path: Path) -> None:
        """heartbeat --auto-queue loop → auto_start=True passed (lines 248-252)."""
        mock_hb = MagicMock()
        mock_hb.return_value.run_loop.side_effect = KeyboardInterrupt

        with (
            patch("owlmind.heartbeat.HeartbeatEngine", mock_hb),
            patch("owlmind.queue.TaskQueue"),
            patch("owlmind.events.EventBus"),
        ):
            result = runner.invoke(
                app,
                [
                    "heartbeat",
                    "--auto-queue",
                    "--runs",
                    str(tmp_path),
                    "--queue-dir",
                    str(tmp_path / "q"),
                ],
            )

        assert result.exit_code == 0
        mock_hb.return_value.run_loop.assert_called_once_with(auto_start=True)


# ---------------------------------------------------------------------------
# Additional doctor command coverage
# ---------------------------------------------------------------------------


class TestDoctorExtra:
    def test_doctor_policy_engine_load_exception(self, tmp_path: Path) -> None:
        """doctor → PolicyEngine.from_directory raises → engine_msg set (lines 78-79)."""
        policies_dir = tmp_path / "policies"
        policies_dir.mkdir()
        (policies_dir / "allowlist.yaml").write_text("allowed: []\n")

        with patch("owlmind.cli.core.PolicyEngine") as MockPE:
            MockPE.from_directory.side_effect = Exception("bad YAML syntax")
            result = runner.invoke(app, ["doctor", "--policies", str(policies_dir)])

        assert result.exit_code == 1
        assert "bad YAML syntax" in result.output

    def test_doctor_preflight_flag(self, tmp_path: Path) -> None:
        """doctor --preflight → calls _run_doctor_preflight (line 100)."""
        mock_pf_report = MagicMock()
        mock_pf_report.checks = []
        mock_pf_report.missing_env = []
        mock_pf_report.missing_deps = []
        mock_pf_report.recommended_installs = []
        mock_pf_report.missing_binaries = []

        with (
            patch("owlmind.preflight.PreflightConfig"),
            patch("owlmind.preflight.run_preflight", return_value=mock_pf_report),
        ):
            result = runner.invoke(
                app,
                ["doctor", "--policies", str(tmp_path / "nope"), "--preflight"],
            )

        # preflight ran → output contains preflight table heading
        assert "Preflight" in result.output

    def test_doctor_fix_with_warnings(self, tmp_path: Path) -> None:
        """doctor --fix with warnings → warnings printed (lines 263-264, 267)."""
        fix_item = MagicMock()
        fix_item.fixed = True
        fix_item.name = "runs_dir"
        fix_item.detail = "created"

        mock_report = MagicMock()
        mock_report.fixes = [fix_item]
        mock_report.warnings = ["API key not set for openai"]

        with patch("owlmind.setup.doctor_fix", return_value=mock_report):
            result = runner.invoke(
                app,
                [
                    "doctor",
                    "--policies",
                    str(tmp_path / "nope"),
                    "--fix",
                    "--workspace",
                    str(tmp_path),
                ],
            )

        assert "runs_dir" in result.output
        assert "API key not set for openai" in result.output

    def test_doctor_preflight_with_missing_env(self, tmp_path: Path) -> None:
        """_run_doctor_preflight → missing_env printed (lines 294-295)."""
        mock_pf_report = MagicMock()
        mock_pf_report.checks = []
        mock_pf_report.missing_env = ["OPENAI_API_KEY"]
        mock_pf_report.missing_deps = []
        mock_pf_report.recommended_installs = []
        mock_pf_report.missing_binaries = []

        with (
            patch("owlmind.preflight.PreflightConfig"),
            patch("owlmind.preflight.run_preflight", return_value=mock_pf_report),
        ):
            result = runner.invoke(
                app,
                ["doctor", "--policies", str(tmp_path / "nope"), "--preflight"],
            )

        assert "OPENAI_API_KEY" in result.output

    def test_doctor_preflight_with_missing_deps(self, tmp_path: Path) -> None:
        """_run_doctor_preflight → missing_deps printed (lines 296-297)."""
        mock_pf_report = MagicMock()
        mock_pf_report.checks = []
        mock_pf_report.missing_env = []
        mock_pf_report.missing_deps = ["openai"]
        mock_pf_report.recommended_installs = []
        mock_pf_report.missing_binaries = []

        with (
            patch("owlmind.preflight.PreflightConfig"),
            patch("owlmind.preflight.run_preflight", return_value=mock_pf_report),
        ):
            result = runner.invoke(
                app,
                ["doctor", "--policies", str(tmp_path / "nope"), "--preflight"],
            )

        assert "openai" in result.output

    def test_doctor_preflight_with_recommended_installs(self, tmp_path: Path) -> None:
        """_run_doctor_preflight → recommended_installs printed (lines 298-301)."""
        mock_pf_report = MagicMock()
        mock_pf_report.checks = []
        mock_pf_report.missing_env = []
        mock_pf_report.missing_deps = []
        mock_pf_report.recommended_installs = ["pip install 'owlmind[openai]'"]
        mock_pf_report.missing_binaries = []

        with (
            patch("owlmind.preflight.PreflightConfig"),
            patch("owlmind.preflight.run_preflight", return_value=mock_pf_report),
        ):
            result = runner.invoke(
                app,
                ["doctor", "--policies", str(tmp_path / "nope"), "--preflight"],
            )

        assert "Recommended installs" in result.output
        assert "pip install" in result.output

    def test_doctor_preflight_with_missing_binaries(self, tmp_path: Path) -> None:
        """_run_doctor_preflight → missing_binaries printed (lines 302-303)."""
        mock_pf_report = MagicMock()
        mock_pf_report.checks = []
        mock_pf_report.missing_env = []
        mock_pf_report.missing_deps = []
        mock_pf_report.recommended_installs = []
        mock_pf_report.missing_binaries = ["claude"]

        with (
            patch("owlmind.preflight.PreflightConfig"),
            patch("owlmind.preflight.run_preflight", return_value=mock_pf_report),
        ):
            result = runner.invoke(
                app,
                ["doctor", "--policies", str(tmp_path / "nope"), "--preflight"],
            )

        assert "claude" in result.output


# ---------------------------------------------------------------------------
# Additional show command coverage
# ---------------------------------------------------------------------------


class TestShowExtra:
    def test_show_with_summary_report_commands(self, tmp_path: Path) -> None:
        """show → summary with report.commands_run → exit/color logic (lines 168-173)."""
        mock_es = MagicMock()
        mock_es.return_value.read_meta.return_value = {
            "task_id": "t-2",
            "goal": "deploy app",
            "started_at": "2024-01-02T00:00:00",
        }
        mock_es.return_value.read_summary.return_value = {
            "report": {
                "status": "DONE",
                "commands_run": [
                    {"cmd": "pytest", "exit_code": 0},
                    {"cmd": "rm -rf /", "exit_code": 1},
                ],
            }
        }
        mock_es.return_value.read_events.return_value = []

        with patch("owlmind.cli.core.EvidenceStore", mock_es):
            result = runner.invoke(app, ["show", "run-002", "--runs", str(tmp_path)])

        assert result.exit_code == 0
        assert "pytest" in result.output
        assert "DONE" in result.output

    def test_show_with_summary_no_report_key(self, tmp_path: Path) -> None:
        """show → summary data present but no 'report' key → no crash."""
        mock_es = MagicMock()
        mock_es.return_value.read_meta.return_value = {
            "task_id": "t-3",
            "goal": "test goal",
            "started_at": "2024-01-03T00:00:00",
        }
        mock_es.return_value.read_summary.return_value = {"other_key": "other_val"}
        mock_es.return_value.read_events.return_value = []

        with patch("owlmind.cli.core.EvidenceStore", mock_es):
            result = runner.invoke(app, ["show", "run-003", "--runs", str(tmp_path)])

        assert result.exit_code == 0
        assert "run-003" in result.output


# ---------------------------------------------------------------------------
# Additional replay command coverage
# ---------------------------------------------------------------------------


class TestReplayExtra:
    def test_replay_event_with_extra_details(self, tmp_path: Path) -> None:
        """replay → event with extra key/value details printed (lines 203-204)."""
        mock_es = MagicMock()
        mock_es.return_value.read_events.return_value = [
            {
                "event": "action_run",
                "timestamp": "2024-01-01T00:01:00",
                "tool": "bash",
                "cmd": "pytest",
            },
        ]

        with patch("owlmind.cli.core.EvidenceStore", mock_es):
            result = runner.invoke(app, ["replay", "run-details", "--runs", str(tmp_path)])

        assert result.exit_code == 0
        assert "action_run" in result.output
        assert "tool" in result.output
        assert "bash" in result.output


# ---------------------------------------------------------------------------
# Additional run command coverage
# ---------------------------------------------------------------------------


class TestRunExtra:
    def test_run_task_failed_state(self, tmp_path: Path) -> None:
        """run → orchestrator returns FAILED → output shows red/FAILED (line 141)."""
        task_file = tmp_path / "task.json"
        task_file.write_text(json.dumps({"goal": "risky goal", "actions": []}))

        mock_summary = MagicMock()
        mock_summary.state.value = "FAILED"
        mock_summary.actions_executed = 3
        mock_summary.actions_failed = 2

        mock_orch = MagicMock()
        mock_orch.run.return_value = mock_summary
        mock_orch.run_id = "run-fail-001"

        with (
            patch("owlmind.cli.core.TaskSpec") as MockTS,
            patch("owlmind.cli.core.PolicyEngine"),
            patch("owlmind.cli.core.EvidenceStore"),
            patch("owlmind.cli.core.ToolLimits"),
            patch("owlmind.cli.core.Orchestrator", return_value=mock_orch),
        ):
            MockTS.return_value.goal = "risky goal"
            MockTS.return_value.actions = []
            result = runner.invoke(
                app,
                ["run", str(task_file), "--runs", str(tmp_path / "runs")],
            )

        assert result.exit_code == 0
        assert "FAILED" in result.output
