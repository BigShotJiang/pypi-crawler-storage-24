"""Tests for the distributed scheduler (DAG-aware goal dispatch)."""

from __future__ import annotations

import time
from datetime import UTC, datetime
from typing import Any

import pytest

from owlmind.queue import QueueItem, QueueStatus
from owlmind.scheduler import (
    Scheduler,
    SchedulerConfig,
    SchedulerTickResult,
)
from owlmind.session import (
    SESSION_DONE,
    SESSION_FAILED,
    SESSION_RUNNING,
    SESSION_STOPPED,
    GoalRunInfo,
    GoalSpec,
    SessionMeta,
)
from owlmind.storage.interface import StorageBackend

# ===================================================================
# Fake storage implementations (Protocol-level, not SQL)
# ===================================================================


class _FakeSessionStorage:
    """In-memory SessionStorage for scheduler tests."""

    def __init__(self) -> None:
        self._sessions: dict[str, SessionMeta] = {}
        self._events: dict[str, list[dict[str, Any]]] = {}
        self._locks: set[str] = set()

    async def save_session(self, meta: Any) -> None:
        self._sessions[meta.session_id] = meta

    async def load_session(self, session_id: str) -> Any:
        if session_id not in self._sessions:
            raise FileNotFoundError(f"Session not found: {session_id}")
        return self._sessions[session_id]

    async def append_event(self, session_id: str, event: dict[str, Any]) -> None:
        self._events.setdefault(session_id, []).append(event)

    async def read_events(self, session_id: str) -> list[dict[str, Any]]:
        return list(self._events.get(session_id, []))

    async def list_sessions(self, *, n: int = 20) -> list[str]:
        return list(self._sessions.keys())[:n]

    async def acquire_lock(self, session_id: str) -> bool:
        if session_id in self._locks:
            return False
        self._locks.add(session_id)
        return True

    async def release_lock(self, session_id: str) -> None:
        self._locks.discard(session_id)


class _FakeQueueStorage:
    """In-memory QueueStorage with session_id/goal_id support."""

    def __init__(self) -> None:
        self._items: list[QueueItem] = []
        self._next_id = 1

    async def add(
        self,
        goal: str,
        workspace: str,
        *,
        sandbox: bool = False,
        priority: int = 0,
        session_id: str = "",
        goal_id: str = "",
    ) -> QueueItem:
        item = QueueItem(
            id=f"task-{self._next_id:04d}",
            goal=goal,
            workspace=workspace,
            sandbox=sandbox,
            priority=priority,
            created_at=datetime.now(tz=UTC).isoformat(),
            status=QueueStatus.PENDING,
            session_id=session_id,
            goal_id=goal_id,
        )
        self._next_id += 1
        self._items.append(item)
        return item

    async def list_items(self, *, status: str | None = None) -> list[QueueItem]:
        if status:
            return [i for i in self._items if i.status == status]
        return list(self._items)

    async def next_pending(self) -> QueueItem | None:
        pending = [i for i in self._items if i.status == QueueStatus.PENDING]
        if not pending:
            return None
        pending.sort(key=lambda i: (-i.priority, i.created_at))
        return pending[0]

    async def mark_running(self, item_id: str, run_id: str) -> None:
        for item in self._items:
            if item.id == item_id:
                item.status = QueueStatus.RUNNING
                item.run_id = run_id
                break

    async def mark_done(self, item_id: str) -> None:
        for item in self._items:
            if item.id == item_id:
                item.status = QueueStatus.DONE
                break

    async def mark_failed(self, item_id: str, error: str = "") -> None:
        for item in self._items:
            if item.id == item_id:
                item.status = QueueStatus.FAILED
                item.error = error
                break


class _FakeLedgerStorage:
    """Minimal LedgerStorage stub."""

    async def record(self, entry: Any) -> None:
        pass

    async def totals_for_day(self, day: Any = None) -> Any:
        return None

    async def totals_for_run(self, run_id: str) -> Any:
        return None

    async def recent(self, n: int = 20) -> list[Any]:
        return []

    async def entries_for_day(self, day: Any = None) -> list[Any]:
        return []

    async def calls_in_last_hour(self) -> int:
        return 0


class _FakeRunStorage:
    """Minimal RunStorage stub."""

    async def create_run(self, run_id: str) -> None:
        pass

    async def append_event(self, run_id: str, event: dict[str, Any]) -> str:
        return ""

    async def get_chain_tip(self, run_id: str) -> tuple[str, int]:
        return ("", 0)

    async def verify_chain(self, run_id: str) -> Any:
        return None

    async def write_artifact(self, run_id: str, filename: str, content: Any) -> str:
        return ""

    async def write_manifest(self, run_id: str) -> dict[str, Any]:
        return {}

    async def write_meta(self, run_id: str, meta: dict[str, Any]) -> None:
        pass

    async def write_summary(self, run_id: str, summary: dict[str, Any]) -> None:
        pass

    async def read_events(self, run_id: str) -> list[dict[str, Any]]:
        return []

    async def read_meta(self, run_id: str) -> dict[str, Any]:
        return {}

    async def read_summary(self, run_id: str) -> dict[str, Any]:
        return {}

    async def list_runs(self) -> list[str]:
        return []


# ===================================================================
# Helpers
# ===================================================================


def _now_iso() -> str:
    return datetime.now(UTC).isoformat()


def _make_goal(
    goal_id: str,
    goal_text: str = "Do something",
    workspace: str = "/tmp/work",
    depends_on: list[str] | None = None,
) -> GoalSpec:
    return GoalSpec(
        id=goal_id,
        goal=goal_text,
        workspace=workspace,
        depends_on=depends_on or [],
    )


def _make_session(
    session_id: str = "sess-001",
    goals: list[GoalSpec] | None = None,
    runs: list[GoalRunInfo] | None = None,
    status: str = SESSION_RUNNING,
    max_concurrency: int = 1,
    continue_on_fail: bool = False,
) -> SessionMeta:
    if goals is None:
        goals = [_make_goal("g1", "Build feature")]
    return SessionMeta(
        session_id=session_id,
        created_at=_now_iso(),
        updated_at=_now_iso(),
        status=status,
        goals=goals,
        runs=runs or [],
        max_concurrency=max_concurrency,
        continue_on_fail=continue_on_fail,
    )


def _make_scheduler(
    sessions: list[SessionMeta] | None = None,
    queue_items: list[QueueItem] | None = None,
    config: SchedulerConfig | None = None,
) -> tuple[Scheduler, _FakeSessionStorage, _FakeQueueStorage]:
    """Create scheduler with fake storage pre-loaded with data."""
    fake_sessions = _FakeSessionStorage()
    fake_queue = _FakeQueueStorage()

    if sessions:
        for s in sessions:
            fake_sessions._sessions[s.session_id] = s

    if queue_items:
        fake_queue._items = list(queue_items)

    storage = StorageBackend(
        runs=_FakeRunStorage(),
        ledger=_FakeLedgerStorage(),
        queue=fake_queue,
        sessions=fake_sessions,
    )

    scheduler = Scheduler(storage, config or SchedulerConfig())
    return scheduler, fake_sessions, fake_queue


# ===================================================================
# TestQueueItemExtension
# ===================================================================


class TestQueueItemExtension:
    def test_session_id_goal_id_defaults(self):
        item = QueueItem(id="t1", goal="test", workspace="/w")
        assert item.session_id == ""
        assert item.goal_id == ""

    def test_to_dict_includes_new_fields(self):
        item = QueueItem(id="t1", goal="test", workspace="/w", session_id="s1", goal_id="g1")
        d = item.to_dict()
        assert d["session_id"] == "s1"
        assert d["goal_id"] == "g1"

    def test_from_dict_reads_new_fields(self):
        d = {
            "id": "t1",
            "goal": "test",
            "workspace": "/w",
            "session_id": "s1",
            "goal_id": "g1",
        }
        item = QueueItem.from_dict(d)
        assert item.session_id == "s1"
        assert item.goal_id == "g1"

    def test_from_dict_missing_new_fields(self):
        d = {"id": "t1", "goal": "test", "workspace": "/w"}
        item = QueueItem.from_dict(d)
        assert item.session_id == ""
        assert item.goal_id == ""


# ===================================================================
# TestSchedulerInit
# ===================================================================


class TestSchedulerInit:
    def test_default_config(self):
        scheduler, _, _ = _make_scheduler()
        assert scheduler._config.poll_interval == 5.0
        assert scheduler._config.stale_timeout == 3600.0
        assert scheduler._shutdown is False

    def test_custom_config(self):
        config = SchedulerConfig(poll_interval=1.0, stale_timeout=300.0, max_sessions=50)
        scheduler, _, _ = _make_scheduler(config=config)
        assert scheduler._config.poll_interval == 1.0
        assert scheduler._config.max_sessions == 50


# ===================================================================
# TestSchedulerDispatch
# ===================================================================


class TestSchedulerDispatch:
    @pytest.mark.asyncio
    async def test_dispatches_ready_goal(self):
        session = _make_session(goals=[_make_goal("g1", "Build it")])
        scheduler, sessions, queue = _make_scheduler(sessions=[session])

        result = await scheduler._tick()

        assert result.goals_dispatched == 1
        assert len(queue._items) == 1
        assert queue._items[0].session_id == "sess-001"
        assert queue._items[0].goal_id == "g1"
        assert queue._items[0].goal == "Build it"

        # Check GoalRunInfo was added
        meta = sessions._sessions["sess-001"]
        assert len(meta.runs) == 1
        assert meta.runs[0].goal_id == "g1"
        assert meta.runs[0].status == "dispatched"

    @pytest.mark.asyncio
    async def test_skips_non_running_sessions(self):
        done_session = _make_session(session_id="done-1", status=SESSION_DONE)
        failed_session = _make_session(session_id="fail-1", status=SESSION_FAILED)
        stopped_session = _make_session(session_id="stop-1", status=SESSION_STOPPED)
        scheduler, _, queue = _make_scheduler(
            sessions=[done_session, failed_session, stopped_session]
        )

        result = await scheduler._tick()

        assert result.goals_dispatched == 0
        assert len(queue._items) == 0

    @pytest.mark.asyncio
    async def test_respects_max_concurrency(self):
        goals = [
            _make_goal("g1", "Task 1"),
            _make_goal("g2", "Task 2"),
            _make_goal("g3", "Task 3"),
        ]
        session = _make_session(
            goals=goals,
            max_concurrency=2,
        )
        scheduler, _, queue = _make_scheduler(sessions=[session])

        result = await scheduler._tick()

        # Should dispatch at most 2 goals (max_concurrency)
        assert result.goals_dispatched == 2
        assert len(queue._items) == 2

    @pytest.mark.asyncio
    async def test_dispatches_dag_layer_order(self):
        goals = [
            _make_goal("g1", "First"),
            _make_goal("g2", "Second", depends_on=["g1"]),
            _make_goal("g3", "Third", depends_on=["g2"]),
        ]
        session = _make_session(goals=goals, max_concurrency=3)
        scheduler, _, queue = _make_scheduler(sessions=[session])

        # First tick: only g1 is ready (g2 depends on g1, g3 depends on g2)
        result = await scheduler._tick()
        assert result.goals_dispatched == 1
        assert queue._items[0].goal_id == "g1"

    @pytest.mark.asyncio
    async def test_skips_already_dispatched_goals(self):
        goals = [_make_goal("g1", "Task 1")]
        runs = [GoalRunInfo(goal_id="g1", run_id="", status="dispatched", started_at=_now_iso())]
        session = _make_session(goals=goals, runs=runs)
        scheduler, _, queue = _make_scheduler(sessions=[session])

        result = await scheduler._tick()

        assert result.goals_dispatched == 0
        assert len(queue._items) == 0


# ===================================================================
# TestSchedulerCollectResults
# ===================================================================


class TestSchedulerCollectResults:
    @pytest.mark.asyncio
    async def test_marks_goal_done_on_queue_done(self):
        goals = [_make_goal("g1")]
        runs = [GoalRunInfo(goal_id="g1", run_id="", status="dispatched", started_at=_now_iso())]
        session = _make_session(goals=goals, runs=runs)

        done_item = QueueItem(
            id="task-001",
            goal="Build",
            workspace="/w",
            status=QueueStatus.DONE,
            session_id="sess-001",
            goal_id="g1",
            run_id="run-abc",
        )
        scheduler, sessions, _ = _make_scheduler(sessions=[session], queue_items=[done_item])

        result = await scheduler._tick()

        assert result.goals_completed == 1
        meta = sessions._sessions["sess-001"]
        run_info = meta.runs[0]
        assert run_info.status == "done"
        assert run_info.run_id == "run-abc"
        assert run_info.ended_at != ""

    @pytest.mark.asyncio
    async def test_marks_goal_failed_on_queue_failed(self):
        goals = [_make_goal("g1")]
        runs = [GoalRunInfo(goal_id="g1", run_id="", status="dispatched", started_at=_now_iso())]
        session = _make_session(goals=goals, runs=runs)

        failed_item = QueueItem(
            id="task-001",
            goal="Build",
            workspace="/w",
            status=QueueStatus.FAILED,
            session_id="sess-001",
            goal_id="g1",
            error="timeout",
        )
        scheduler, sessions, _ = _make_scheduler(sessions=[session], queue_items=[failed_item])

        result = await scheduler._tick()

        assert result.goals_failed == 1
        meta = sessions._sessions["sess-001"]
        assert meta.runs[0].status == "failed"

    @pytest.mark.asyncio
    async def test_updates_run_id_from_queue_item(self):
        goals = [_make_goal("g1")]
        runs = [GoalRunInfo(goal_id="g1", run_id="", status="dispatched", started_at=_now_iso())]
        session = _make_session(goals=goals, runs=runs)

        running_item = QueueItem(
            id="task-001",
            goal="Build",
            workspace="/w",
            status=QueueStatus.RUNNING,
            session_id="sess-001",
            goal_id="g1",
            run_id="run-xyz",
        )
        scheduler, sessions, _ = _make_scheduler(sessions=[session], queue_items=[running_item])

        await scheduler._tick()

        meta = sessions._sessions["sess-001"]
        assert meta.runs[0].status == "running"
        assert meta.runs[0].run_id == "run-xyz"

    @pytest.mark.asyncio
    async def test_ignores_standalone_items(self):
        """Queue items without session_id should not affect sessions."""
        goals = [_make_goal("g1")]
        session = _make_session(goals=goals)

        standalone_item = QueueItem(
            id="task-099",
            goal="Standalone task",
            workspace="/w",
            status=QueueStatus.DONE,
        )
        scheduler, sessions, _ = _make_scheduler(sessions=[session], queue_items=[standalone_item])

        result = await scheduler._tick()

        # Standalone item should not cause any result collection
        assert result.goals_completed == 0


# ===================================================================
# TestSchedulerSessionCompletion
# ===================================================================


class TestSchedulerSessionCompletion:
    @pytest.mark.asyncio
    async def test_session_done_when_all_goals_done(self):
        goals = [_make_goal("g1"), _make_goal("g2")]
        runs = [
            GoalRunInfo(goal_id="g1", run_id="r1", status="dispatched", started_at=_now_iso()),
            GoalRunInfo(goal_id="g2", run_id="r2", status="dispatched", started_at=_now_iso()),
        ]
        session = _make_session(goals=goals, runs=runs)

        items = [
            QueueItem(
                id="t1",
                goal="A",
                workspace="/w",
                status=QueueStatus.DONE,
                session_id="sess-001",
                goal_id="g1",
                run_id="r1",
            ),
            QueueItem(
                id="t2",
                goal="B",
                workspace="/w",
                status=QueueStatus.DONE,
                session_id="sess-001",
                goal_id="g2",
                run_id="r2",
            ),
        ]
        scheduler, sessions, _ = _make_scheduler(sessions=[session], queue_items=items)

        await scheduler._tick()

        meta = sessions._sessions["sess-001"]
        assert meta.status == SESSION_DONE

    @pytest.mark.asyncio
    async def test_session_failed_on_goal_fail_no_continue(self):
        goals = [_make_goal("g1"), _make_goal("g2")]
        runs = [
            GoalRunInfo(goal_id="g1", run_id="", status="dispatched", started_at=_now_iso()),
        ]
        session = _make_session(goals=goals, runs=runs, continue_on_fail=False)

        items = [
            QueueItem(
                id="t1",
                goal="A",
                workspace="/w",
                status=QueueStatus.FAILED,
                session_id="sess-001",
                goal_id="g1",
            ),
        ]
        scheduler, sessions, _ = _make_scheduler(sessions=[session], queue_items=items)

        await scheduler._tick()

        meta = sessions._sessions["sess-001"]
        assert meta.status == SESSION_FAILED
        assert "g1" in meta.last_block_reason

    @pytest.mark.asyncio
    async def test_session_continues_on_fail_skips_deps(self):
        goals = [
            _make_goal("g1", "First"),
            _make_goal("g2", "Second", depends_on=["g1"]),
        ]
        runs = [
            GoalRunInfo(goal_id="g1", run_id="", status="dispatched", started_at=_now_iso()),
        ]
        session = _make_session(
            goals=goals,
            runs=runs,
            continue_on_fail=True,
            max_concurrency=2,
        )

        items = [
            QueueItem(
                id="t1",
                goal="A",
                workspace="/w",
                status=QueueStatus.FAILED,
                session_id="sess-001",
                goal_id="g1",
            ),
        ]
        scheduler, sessions, _ = _make_scheduler(sessions=[session], queue_items=items)

        # Tick 1: collect failure, try to dispatch — g2 depends on g1 (failed)
        await scheduler._tick()

        meta = sessions._sessions["sess-001"]
        # With continue_on_fail and allow_skipped_deps, g2 should be dispatchable
        # or session should complete with skips
        assert meta.status in (SESSION_RUNNING, SESSION_DONE)


# ===================================================================
# TestSchedulerStaleRecovery
# ===================================================================


class TestSchedulerStaleRecovery:
    @pytest.mark.asyncio
    async def test_resets_stale_dispatched_goals(self):
        # Create a goal dispatched 2 hours ago
        old_time = datetime.fromtimestamp(time.time() - 7200, tz=UTC).isoformat()

        goals = [_make_goal("g1")]
        runs = [GoalRunInfo(goal_id="g1", run_id="", status="dispatched", started_at=old_time)]
        session = _make_session(goals=goals, runs=runs)

        config = SchedulerConfig(stale_timeout=3600.0)  # 1 hour
        scheduler, sessions, queue = _make_scheduler(sessions=[session], config=config)

        result = await scheduler._tick()

        # Stale goal should be reset to pending and re-dispatched
        assert result.goals_stale_reset == 1
        meta = sessions._sessions["sess-001"]
        # After reset, the goal should be re-dispatched in the same tick
        dispatched_runs = [r for r in meta.runs if r.status == "dispatched"]
        assert len(dispatched_runs) >= 1

    @pytest.mark.asyncio
    async def test_no_reset_within_timeout(self):
        # Create a goal dispatched just now
        goals = [_make_goal("g1")]
        runs = [GoalRunInfo(goal_id="g1", run_id="", status="dispatched", started_at=_now_iso())]
        session = _make_session(goals=goals, runs=runs)

        config = SchedulerConfig(stale_timeout=3600.0)
        scheduler, sessions, _ = _make_scheduler(sessions=[session], config=config)

        result = await scheduler._tick()

        assert result.goals_stale_reset == 0


# ===================================================================
# TestSchedulerTick
# ===================================================================


class TestSchedulerTick:
    @pytest.mark.asyncio
    async def test_full_tick_dispatch_and_collect(self):
        """Full cycle: dispatch g1, then on next tick collect its result and dispatch g2."""
        goals = [
            _make_goal("g1", "First"),
            _make_goal("g2", "Second", depends_on=["g1"]),
        ]
        session = _make_session(goals=goals, max_concurrency=2)
        scheduler, sessions, queue = _make_scheduler(sessions=[session])

        # Tick 1: dispatch g1
        r1 = await scheduler._tick()
        assert r1.goals_dispatched == 1
        assert queue._items[0].goal_id == "g1"

        # Simulate worker completing g1
        queue._items[0].status = QueueStatus.DONE
        queue._items[0].run_id = "run-001"

        # Tick 2: collect g1 result, dispatch g2
        r2 = await scheduler._tick()
        assert r2.goals_completed == 1
        assert r2.goals_dispatched == 1
        assert len(queue._items) == 2
        assert queue._items[1].goal_id == "g2"

        # Simulate worker completing g2
        queue._items[1].status = QueueStatus.DONE
        queue._items[1].run_id = "run-002"

        # Tick 3: collect g2 result, session should be DONE
        r3 = await scheduler._tick()
        assert r3.goals_completed == 1
        meta = sessions._sessions["sess-001"]
        assert meta.status == SESSION_DONE

    @pytest.mark.asyncio
    async def test_tick_result_stats(self):
        session = _make_session(
            goals=[_make_goal("g1"), _make_goal("g2")],
            max_concurrency=5,
        )
        scheduler, _, _ = _make_scheduler(sessions=[session])

        result = await scheduler._tick()

        assert isinstance(result, SchedulerTickResult)
        assert result.sessions_scanned == 1
        assert result.goals_dispatched == 2
        assert result.goals_completed == 0
        assert result.goals_failed == 0


# ===================================================================
# TestSchedulerShutdown
# ===================================================================


class TestSchedulerShutdown:
    @pytest.mark.asyncio
    async def test_graceful_shutdown_sets_flag(self):
        scheduler, _, _ = _make_scheduler()

        assert scheduler._shutdown is False
        await scheduler.shutdown()
        assert scheduler._shutdown is True
