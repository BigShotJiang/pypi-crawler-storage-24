"""Tests for Analytics CLI and Dashboard — smoke tests."""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path

from owlmind.dashboard import generate_dashboard
from owlmind.ledger import UsageEntry, UsageLedger


def _make_entry(**overrides: object) -> UsageEntry:
    defaults = {
        "ts": datetime.now(tz=UTC).isoformat(),
        "run_id": "cycle-analytics",
        "stage": "planner",
        "provider": "openai",
        "model": "gpt-4o",
        "input_tokens": 100,
        "output_tokens": 50,
        "total_tokens": 150,
        "estimated_usd": 0.00075,
        "latency_ms": 500,
        "price_per_1k_input": 0.0025,
        "price_per_1k_output": 0.01,
    }
    defaults.update(overrides)
    return UsageEntry(**defaults)  # type: ignore[arg-type]


class TestDashboardGeneration:
    def test_generates_html_file(self, tmp_path: Path) -> None:
        ledger_dir = tmp_path / "ledger"
        runs_dir = tmp_path / "runs"
        runs_dir.mkdir()
        out = tmp_path / "dashboard.html"

        ledger = UsageLedger(ledger_dir)
        ledger.record(_make_entry())
        ledger.record(_make_entry(stage="judge", model="gpt-4o-mini"))

        generate_dashboard(ledger_dir, runs_dir, out)

        assert out.exists()
        content = out.read_text()
        assert "OWLMIND Analytics Dashboard" in content
        assert "Last 7 Days" in content
        assert "Recent Entries" in content

    def test_empty_ledger_dashboard(self, tmp_path: Path) -> None:
        ledger_dir = tmp_path / "ledger"
        runs_dir = tmp_path / "runs"
        runs_dir.mkdir()
        out = tmp_path / "dashboard.html"

        generate_dashboard(ledger_dir, runs_dir, out)

        assert out.exists()
        content = out.read_text()
        assert "OWLMIND" in content

    def test_dashboard_with_run_meta(self, tmp_path: Path) -> None:
        ledger_dir = tmp_path / "ledger"
        runs_dir = tmp_path / "runs"
        run_dir = runs_dir / "cycle-abc123"
        run_dir.mkdir(parents=True)

        import json

        meta = {
            "run_id": "cycle-abc123",
            "goal": "Test goal",
            "state": "DONE",
            "iteration": 1,
        }
        (run_dir / "cycle_meta.json").write_text(json.dumps(meta))

        ledger = UsageLedger(ledger_dir)
        ledger.record(_make_entry(run_id="cycle-abc123"))

        out = tmp_path / "dashboard.html"
        generate_dashboard(ledger_dir, runs_dir, out)

        content = out.read_text()
        assert "cycle-abc123" in content
        assert "DONE" in content


class TestLedgerEntriesForDay:
    def test_entries_for_today(self, tmp_path: Path) -> None:
        ledger = UsageLedger(tmp_path / "ledger")
        ledger.record(_make_entry())
        ledger.record(_make_entry(stage="judge"))

        entries = ledger.entries_for_day()
        assert len(entries) == 2
