"""Tests for self-improvement subsystem (Stage 6).

Covers:
- RunExtended model
- Analyzer (collect_run_extended, analyze)
- Generator (generate_improvements, generate_with_llm, FileImprovementStore)
- A/B Testing (ABTestScheduler)
- Applicator (apply_improvement, apply_batch)
- CLI commands
- API routes
- Integration scenario
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any
from unittest.mock import patch

from owlmind.self_improve.models import (
    ABTest,
    ABTestStatus,
    AnalysisReport,
    Improvement,
    ImprovementStatus,
    RunExtended,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_run_dir(
    tmp_path: Path,
    run_id: str,
    *,
    state: str = "DONE",
    goal: str = "test goal",
    stop_reason: str = "judge_done",
    iteration: int = 3,
    workspace: str = "/tmp/ws",
    created_at: str = "2026-02-21T10:00:00+00:00",
    verdict: str = "",
    commands: list[dict[str, Any]] | None = None,
    with_extended: bool = False,
) -> Path:
    """Create a minimal run directory with cycle_meta.json."""
    run_dir = tmp_path / run_id
    run_dir.mkdir(parents=True, exist_ok=True)

    meta = {
        "run_id": run_id,
        "goal": goal,
        "state": state,
        "stop_reason": stop_reason,
        "workspace": workspace,
        "iteration": iteration,
        "step": iteration * 3,
        "created_at": created_at,
    }
    (run_dir / "cycle_meta.json").write_text(json.dumps(meta))

    # Optionally add inbox with judge/worker responses
    if verdict:
        inbox = run_dir / "inbox"
        inbox.mkdir(exist_ok=True)
        (inbox / "judge_response.json").write_text(
            json.dumps({"verdict": verdict, "run_id": run_id})
        )

    if commands:
        inbox = run_dir / "inbox"
        inbox.mkdir(exist_ok=True)
        (inbox / "worker_report.json").write_text(
            json.dumps({"commands_run": commands, "run_id": run_id})
        )

    if with_extended:
        ext = RunExtended(
            run_id=run_id,
            judge_verdict=verdict or state,
            duration_ms=5000,
            error_details=stop_reason if state == "FAILED" else "",
            commands_executed=commands or [],
            created_at=created_at,
        )
        (run_dir / "run_extended.json").write_text(json.dumps(ext.to_dict(), indent=2))

    return run_dir


def _make_report(
    *,
    runs: int = 10,
    success_rate: float = 0.8,
    avg_duration: float = 5000.0,
    avg_iterations: float = 3.0,
    failure_patterns: list[dict[str, Any]] | None = None,
    performance_issues: list[dict[str, Any]] | None = None,
) -> AnalysisReport:
    """Create an AnalysisReport for testing."""
    return AnalysisReport(
        runs_analyzed=runs,
        success_rate=success_rate,
        avg_duration_ms=avg_duration,
        avg_iterations=avg_iterations,
        failure_patterns=failure_patterns or [],
        performance_issues=performance_issues or [],
    )


# ===================================================================
# RunExtended model tests
# ===================================================================


class TestRunExtended:
    def test_defaults(self) -> None:
        ext = RunExtended(run_id="run-001")
        assert ext.run_id == "run-001"
        assert ext.prompts_used == []
        assert ext.commands_executed == []
        assert ext.judge_verdict == ""
        assert ext.duration_ms == 0
        assert ext.error_details == ""
        assert ext.tags == []

    def test_to_dict(self) -> None:
        ext = RunExtended(
            run_id="run-001",
            judge_verdict="APPROVED",
            duration_ms=5000,
            tags=["fast"],
        )
        d = ext.to_dict()
        assert d["run_id"] == "run-001"
        assert d["judge_verdict"] == "APPROVED"
        assert d["duration_ms"] == 5000
        assert d["tags"] == ["fast"]

    def test_from_dict(self) -> None:
        d = {
            "run_id": "run-002",
            "judge_verdict": "REJECTED",
            "duration_ms": 10000,
            "error_details": "some error",
        }
        ext = RunExtended.from_dict(d)
        assert ext.run_id == "run-002"
        assert ext.judge_verdict == "REJECTED"
        assert ext.duration_ms == 10000
        assert ext.error_details == "some error"

    def test_roundtrip(self) -> None:
        ext = RunExtended(
            run_id="run-003",
            prompts_used=["planner_prompt.md"],
            commands_executed=[{"cmd": "pytest", "exit_code": 0}],
            judge_verdict="APPROVED",
            llm_usage={"tokens": 1000},
            duration_ms=3000,
            tags=["test"],
        )
        d = ext.to_dict()
        ext2 = RunExtended.from_dict(d)
        assert ext2.run_id == ext.run_id
        assert ext2.prompts_used == ext.prompts_used
        assert ext2.commands_executed == ext.commands_executed
        assert ext2.judge_verdict == ext.judge_verdict


# ===================================================================
# AnalysisReport model tests
# ===================================================================


class TestAnalysisReport:
    def test_auto_fields(self) -> None:
        r = AnalysisReport()
        assert r.report_id.startswith("report-")
        assert r.created_at != ""
        assert r.runs_analyzed == 0

    def test_to_dict(self) -> None:
        r = _make_report(runs=5, success_rate=0.6)
        d = r.to_dict()
        assert d["runs_analyzed"] == 5
        assert d["success_rate"] == 0.6


# ===================================================================
# Improvement model tests
# ===================================================================


class TestImprovement:
    def test_auto_id(self) -> None:
        imp = Improvement(category="test", title="Test improvement")
        assert imp.improvement_id.startswith("imp-")
        assert imp.status == ImprovementStatus.PROPOSED

    def test_from_dict(self) -> None:
        d = {
            "improvement_id": "imp-001",
            "category": "prompt_tuning",
            "title": "Better prompts",
            "confidence": 0.8,
            "status": "approved",
        }
        imp = Improvement.from_dict(d)
        assert imp.improvement_id == "imp-001"
        assert imp.confidence == 0.8
        assert imp.status == "approved"

    def test_roundtrip(self) -> None:
        imp = Improvement(
            category="performance",
            title="Optimize",
            description="Speed things up",
            confidence=0.7,
        )
        d = imp.to_dict()
        imp2 = Improvement.from_dict(d)
        assert imp2.category == imp.category
        assert imp2.title == imp.title
        assert imp2.confidence == imp.confidence


# ===================================================================
# ABTest model tests
# ===================================================================


class TestABTest:
    def test_auto_id(self) -> None:
        t = ABTest(improvement_id="imp-001")
        assert t.test_id.startswith("ab-")
        assert t.status == ABTestStatus.PENDING

    def test_from_dict(self) -> None:
        d = {
            "test_id": "ab-001",
            "improvement_id": "imp-001",
            "runs_a": 5,
            "runs_b": 5,
            "score_a": 3.0,
            "score_b": 4.0,
            "status": "running",
        }
        t = ABTest.from_dict(d)
        assert t.test_id == "ab-001"
        assert t.runs_a == 5
        assert t.score_b == 4.0

    def test_roundtrip(self) -> None:
        t = ABTest(
            improvement_id="imp-002",
            metric="duration",
            min_runs=20,
        )
        d = t.to_dict()
        t2 = ABTest.from_dict(d)
        assert t2.improvement_id == t.improvement_id
        assert t2.metric == t.metric
        assert t2.min_runs == t.min_runs


# ===================================================================
# Analyzer tests
# ===================================================================


class TestAnalyzerCollect:
    def test_collect_from_extended_file(self, tmp_path: Path) -> None:
        from owlmind.self_improve.analyzer import collect_run_extended

        _make_run_dir(tmp_path, "run-001", with_extended=True, verdict="APPROVED")
        result = collect_run_extended(tmp_path)
        assert len(result) == 1
        assert result[0].run_id == "run-001"
        assert result[0].judge_verdict == "APPROVED"

    def test_collect_from_meta_fallback(self, tmp_path: Path) -> None:
        from owlmind.self_improve.analyzer import collect_run_extended

        _make_run_dir(
            tmp_path,
            "run-002",
            state="DONE",
            verdict="APPROVED",
            commands=[{"cmd": "pytest", "exit_code": 0}],
        )
        result = collect_run_extended(tmp_path)
        assert len(result) == 1
        assert result[0].run_id == "run-002"
        # Should have picked up commands from worker_report.json
        assert len(result[0].commands_executed) == 1

    def test_collect_specific_ids(self, tmp_path: Path) -> None:
        from owlmind.self_improve.analyzer import collect_run_extended

        _make_run_dir(tmp_path, "run-001", with_extended=True)
        _make_run_dir(tmp_path, "run-002", with_extended=True)
        _make_run_dir(tmp_path, "run-003", with_extended=True)

        result = collect_run_extended(tmp_path, run_ids=["run-001", "run-003"])
        assert len(result) == 2
        assert {r.run_id for r in result} == {"run-001", "run-003"}

    def test_collect_empty_dir(self, tmp_path: Path) -> None:
        from owlmind.self_improve.analyzer import collect_run_extended

        result = collect_run_extended(tmp_path)
        assert result == []

    def test_collect_nonexistent_dir(self, tmp_path: Path) -> None:
        from owlmind.self_improve.analyzer import collect_run_extended

        result = collect_run_extended(tmp_path / "nope")
        assert result == []


class TestAnalyzerAnalyze:
    def test_empty_runs(self) -> None:
        from owlmind.self_improve.analyzer import analyze

        report = analyze([])
        assert report.runs_analyzed == 0
        assert report.success_rate == 0.0

    def test_all_success(self) -> None:
        from owlmind.self_improve.analyzer import analyze

        runs = [
            RunExtended(run_id=f"run-{i}", judge_verdict="APPROVED", duration_ms=1000)
            for i in range(5)
        ]
        report = analyze(runs)
        assert report.runs_analyzed == 5
        assert report.success_rate == 1.0

    def test_mixed_results(self) -> None:
        from owlmind.self_improve.analyzer import analyze

        runs = [
            RunExtended(run_id="r1", judge_verdict="APPROVED", duration_ms=1000),
            RunExtended(run_id="r2", judge_verdict="APPROVED", duration_ms=2000),
            RunExtended(
                run_id="r3", judge_verdict="REJECTED", duration_ms=3000, error_details="fail reason"
            ),
            RunExtended(
                run_id="r4", judge_verdict="FAILED", duration_ms=4000, error_details="fail reason"
            ),
        ]
        report = analyze(runs)
        assert report.success_rate == 0.5  # 2/4
        assert report.avg_duration_ms == 2500.0  # (1000+2000+3000+4000)/4
        assert len(report.failure_patterns) >= 1

    def test_performance_issues_detection(self) -> None:
        from owlmind.self_improve.analyzer import analyze

        runs = [
            RunExtended(run_id="r1", judge_verdict="DONE", duration_ms=1000),
            RunExtended(run_id="r2", judge_verdict="DONE", duration_ms=1000),
            RunExtended(run_id="r3", judge_verdict="DONE", duration_ms=1000),
            RunExtended(run_id="r4", judge_verdict="DONE", duration_ms=50000),  # 50x average
        ]
        report = analyze(runs)
        # Should detect slow run
        slow_issues = [p for p in report.performance_issues if p["issue"] == "slow_runs"]
        assert len(slow_issues) == 1

    def test_command_failure_patterns(self) -> None:
        from owlmind.self_improve.analyzer import analyze

        runs = [
            RunExtended(
                run_id=f"r{i}",
                judge_verdict="DONE",
                commands_executed=[
                    {"cmd": "pytest tests/", "exit_code": 1},
                    {"cmd": "ruff check", "exit_code": 0},
                ],
            )
            for i in range(3)
        ]
        report = analyze(runs)
        cmd_failures = [p for p in report.failure_patterns if "Command failed" in p["error"]]
        assert len(cmd_failures) >= 1

    def test_recommendations(self) -> None:
        from owlmind.self_improve.analyzer import analyze

        runs = [
            RunExtended(run_id=f"r{i}", judge_verdict="FAILED", error_details="some error")
            for i in range(5)
        ]
        report = analyze(runs)
        assert report.success_rate == 0.0
        assert len(report.recommendations) >= 1


class TestAnalyzerSaveRunExtended:
    def test_save_and_load(self, tmp_path: Path) -> None:
        from owlmind.self_improve.analyzer import collect_run_extended, save_run_extended

        ext = RunExtended(run_id="run-save-test", judge_verdict="DONE", duration_ms=1234)
        save_run_extended(tmp_path, ext)

        # Should be loadable
        loaded = collect_run_extended(tmp_path, run_ids=["run-save-test"])
        assert len(loaded) == 1
        assert loaded[0].duration_ms == 1234


# ===================================================================
# Generator tests
# ===================================================================


class TestGeneratorRules:
    def test_low_success_rate(self) -> None:
        from owlmind.self_improve.generator import generate_improvements

        report = _make_report(runs=5, success_rate=0.3)
        improvements = generate_improvements(report)
        assert any(i.category == "prompt_tuning" for i in improvements)

    def test_high_success_rate_no_prompt_tuning(self) -> None:
        from owlmind.self_improve.generator import generate_improvements

        report = _make_report(runs=5, success_rate=0.95)
        improvements = generate_improvements(report)
        assert not any(i.category == "prompt_tuning" for i in improvements)

    def test_failure_patterns(self) -> None:
        from owlmind.self_improve.generator import generate_improvements

        report = _make_report(failure_patterns=[{"error": "timeout exceeded", "count": 5}])
        improvements = generate_improvements(report)
        assert any("timeout" in i.title.lower() for i in improvements)

    def test_performance_issues(self) -> None:
        from owlmind.self_improve.generator import generate_improvements

        report = _make_report(
            performance_issues=[
                {"issue": "excessive_commands", "description": "10 runs exceeded", "run_ids": []}
            ]
        )
        improvements = generate_improvements(report)
        assert any(i.category == "performance" for i in improvements)

    def test_high_iterations(self) -> None:
        from owlmind.self_improve.generator import generate_improvements

        report = _make_report(runs=5, avg_iterations=8.0)
        improvements = generate_improvements(report)
        assert any(i.category == "workflow" for i in improvements)

    def test_max_proposals_limit(self) -> None:
        from owlmind.self_improve.generator import generate_improvements

        report = _make_report(
            runs=5,
            success_rate=0.2,
            avg_iterations=10.0,
            failure_patterns=[{"error": f"error_{i}", "count": 3} for i in range(10)],
            performance_issues=[
                {"issue": "slow_runs", "description": "slow", "run_ids": []},
                {"issue": "excessive_commands", "description": "heavy", "run_ids": []},
            ],
        )
        improvements = generate_improvements(report, max_proposals=3)
        assert len(improvements) <= 3

    def test_sorted_by_confidence(self) -> None:
        from owlmind.self_improve.generator import generate_improvements

        report = _make_report(
            runs=5,
            success_rate=0.2,
            failure_patterns=[{"error": "fail", "count": 5}],
        )
        improvements = generate_improvements(report)
        if len(improvements) >= 2:
            assert improvements[0].confidence >= improvements[1].confidence


class TestGeneratorLLM:
    def test_fallback_to_rules_when_no_fn(self) -> None:
        from owlmind.self_improve.generator import generate_with_llm

        report = _make_report(runs=5, success_rate=0.3)
        improvements = generate_with_llm(report)
        assert len(improvements) >= 1

    def test_llm_fn_called(self) -> None:
        from owlmind.self_improve.generator import generate_with_llm

        response = json.dumps(
            [
                {
                    "category": "llm_idea",
                    "title": "Better error handling",
                    "description": "Improve retry logic",
                    "confidence": 0.8,
                }
            ]
        )

        def mock_llm(prompt: str) -> str:
            assert "analysis report" in prompt.lower() or "runs analyzed" in prompt.lower()
            return response

        report = _make_report(runs=5)
        improvements = generate_with_llm(report, llm_fn=mock_llm)
        assert len(improvements) == 1
        assert improvements[0].category == "llm_idea"

    def test_llm_fn_error_fallback(self) -> None:
        from owlmind.self_improve.generator import generate_with_llm

        def bad_llm(prompt: str) -> str:
            raise RuntimeError("LLM unavailable")

        report = _make_report(runs=5, success_rate=0.2)
        improvements = generate_with_llm(report, llm_fn=bad_llm)
        # Should fall back to rule-based
        assert len(improvements) >= 1

    def test_llm_bad_json(self) -> None:
        from owlmind.self_improve.generator import generate_with_llm

        def bad_json_llm(prompt: str) -> str:
            return "I think you should improve things!"

        report = _make_report(runs=5, success_rate=0.2)
        # Falls back to rules since parse fails
        improvements = generate_with_llm(report, llm_fn=bad_json_llm)
        assert isinstance(improvements, list)


class TestFileImprovementStore:
    def test_save_and_load(self, tmp_path: Path) -> None:
        from owlmind.self_improve.generator import FileImprovementStore

        store = FileImprovementStore(tmp_path)
        imp = Improvement(category="test", title="Test fix", confidence=0.7)
        store.save(imp)

        loaded = store.load(imp.improvement_id)
        assert loaded is not None
        assert loaded.title == "Test fix"
        assert loaded.confidence == 0.7

    def test_load_nonexistent(self, tmp_path: Path) -> None:
        from owlmind.self_improve.generator import FileImprovementStore

        store = FileImprovementStore(tmp_path)
        assert store.load("nonexistent") is None

    def test_list_all(self, tmp_path: Path) -> None:
        from owlmind.self_improve.generator import FileImprovementStore

        store = FileImprovementStore(tmp_path)
        for i in range(3):
            store.save(Improvement(category=f"cat-{i}", title=f"Fix {i}"))

        all_imps = store.list_improvements()
        assert len(all_imps) == 3

    def test_list_filtered(self, tmp_path: Path) -> None:
        from owlmind.self_improve.generator import FileImprovementStore

        store = FileImprovementStore(tmp_path)
        imp1 = Improvement(category="a", title="Fix 1", status=ImprovementStatus.PROPOSED)
        imp2 = Improvement(category="b", title="Fix 2", status=ImprovementStatus.APPROVED)
        store.save(imp1)
        store.save(imp2)

        proposed = store.list_improvements(status=ImprovementStatus.PROPOSED)
        assert len(proposed) == 1
        assert proposed[0].improvement_id == imp1.improvement_id

    def test_update_status(self, tmp_path: Path) -> None:
        from owlmind.self_improve.generator import FileImprovementStore

        store = FileImprovementStore(tmp_path)
        imp = Improvement(category="test", title="Fix")
        store.save(imp)

        assert store.update_status(imp.improvement_id, ImprovementStatus.APPROVED)
        loaded = store.load(imp.improvement_id)
        assert loaded is not None
        assert loaded.status == ImprovementStatus.APPROVED

    def test_update_nonexistent(self, tmp_path: Path) -> None:
        from owlmind.self_improve.generator import FileImprovementStore

        store = FileImprovementStore(tmp_path)
        assert not store.update_status("nonexistent", ImprovementStatus.APPROVED)


# ===================================================================
# A/B Testing tests
# ===================================================================


class TestABTestScheduler:
    def test_create_test(self, tmp_path: Path) -> None:
        from owlmind.self_improve.ab_testing import ABTestScheduler

        scheduler = ABTestScheduler(tmp_path)
        test = scheduler.create_test("imp-001", min_runs=5)
        assert test.test_id.startswith("ab-")
        assert test.improvement_id == "imp-001"
        assert test.status == ABTestStatus.PENDING
        assert test.min_runs == 5

    def test_start_test(self, tmp_path: Path) -> None:
        from owlmind.self_improve.ab_testing import ABTestScheduler

        scheduler = ABTestScheduler(tmp_path)
        test = scheduler.create_test("imp-001")
        started = scheduler.start_test(test.test_id)
        assert started is not None
        assert started.status == ABTestStatus.RUNNING

    def test_start_nonexistent(self, tmp_path: Path) -> None:
        from owlmind.self_improve.ab_testing import ABTestScheduler

        scheduler = ABTestScheduler(tmp_path)
        assert scheduler.start_test("ab-nonexistent") is None

    def test_start_non_pending(self, tmp_path: Path) -> None:
        from owlmind.self_improve.ab_testing import ABTestScheduler

        scheduler = ABTestScheduler(tmp_path)
        test = scheduler.create_test("imp-001")
        scheduler.start_test(test.test_id)
        # Try to start again — should fail since already running
        assert scheduler.start_test(test.test_id) is None

    def test_record_results(self, tmp_path: Path) -> None:
        from owlmind.self_improve.ab_testing import ABTestScheduler

        scheduler = ABTestScheduler(tmp_path)
        test = scheduler.create_test("imp-001", min_runs=3)
        scheduler.start_test(test.test_id)

        scheduler.record_result(test.test_id, "a", success=True)
        scheduler.record_result(test.test_id, "a", success=False)
        updated = scheduler.record_result(test.test_id, "b", success=True)

        assert updated is not None
        assert updated.runs_a == 2
        assert updated.runs_b == 1
        assert updated.score_a == 1.0
        assert updated.score_b == 1.0

    def test_record_non_running(self, tmp_path: Path) -> None:
        from owlmind.self_improve.ab_testing import ABTestScheduler

        scheduler = ABTestScheduler(tmp_path)
        test = scheduler.create_test("imp-001")
        # Test is still PENDING, not RUNNING
        result = scheduler.record_result(test.test_id, "a", success=True)
        assert result is None

    def test_auto_evaluate_on_min_runs(self, tmp_path: Path) -> None:
        from owlmind.self_improve.ab_testing import ABTestScheduler

        scheduler = ABTestScheduler(tmp_path)
        test = scheduler.create_test("imp-001", min_runs=2)
        scheduler.start_test(test.test_id)

        # Variant A: 1/2 success
        scheduler.record_result(test.test_id, "a", success=True)
        scheduler.record_result(test.test_id, "a", success=False)

        # Variant B: 2/2 success (should trigger auto-evaluate)
        scheduler.record_result(test.test_id, "b", success=True)
        result = scheduler.record_result(test.test_id, "b", success=True)

        assert result is not None
        assert result.status == ABTestStatus.COMPLETED
        assert result.winner == "b"  # 100% vs 50%

    def test_tie_when_close(self, tmp_path: Path) -> None:
        from owlmind.self_improve.ab_testing import ABTestScheduler

        scheduler = ABTestScheduler(tmp_path)
        test = scheduler.create_test("imp-001", min_runs=2)
        scheduler.start_test(test.test_id)

        # Both variants: same results
        scheduler.record_result(test.test_id, "a", success=True)
        scheduler.record_result(test.test_id, "a", success=False)
        scheduler.record_result(test.test_id, "b", success=True)
        result = scheduler.record_result(test.test_id, "b", success=False)

        assert result is not None
        assert result.status == ABTestStatus.COMPLETED
        assert result.winner == "tie"

    def test_manual_evaluate(self, tmp_path: Path) -> None:
        from owlmind.self_improve.ab_testing import ABTestScheduler

        scheduler = ABTestScheduler(tmp_path)
        test = scheduler.create_test("imp-001", min_runs=100)
        scheduler.start_test(test.test_id)

        # Only a few runs — manual evaluate
        scheduler.record_result(test.test_id, "a", success=True)
        scheduler.record_result(test.test_id, "b", success=False)

        evaluated = scheduler.evaluate(test.test_id)
        assert evaluated is not None
        assert evaluated.status == ABTestStatus.COMPLETED

    def test_cancel_test(self, tmp_path: Path) -> None:
        from owlmind.self_improve.ab_testing import ABTestScheduler

        scheduler = ABTestScheduler(tmp_path)
        test = scheduler.create_test("imp-001")
        cancelled = scheduler.cancel_test(test.test_id)
        assert cancelled is not None
        assert cancelled.status == ABTestStatus.CANCELLED

    def test_list_tests(self, tmp_path: Path) -> None:
        from owlmind.self_improve.ab_testing import ABTestScheduler

        scheduler = ABTestScheduler(tmp_path)
        scheduler.create_test("imp-001")
        scheduler.create_test("imp-002")

        all_tests = scheduler.list_tests()
        assert len(all_tests) == 2

    def test_list_tests_filtered(self, tmp_path: Path) -> None:
        from owlmind.self_improve.ab_testing import ABTestScheduler

        scheduler = ABTestScheduler(tmp_path)
        t1 = scheduler.create_test("imp-001")
        scheduler.create_test("imp-002")
        scheduler.start_test(t1.test_id)

        running = scheduler.list_tests(status=ABTestStatus.RUNNING)
        assert len(running) == 1
        assert running[0].test_id == t1.test_id


# ===================================================================
# Applicator tests
# ===================================================================


class TestApplicator:
    def test_reject_wrong_status(self, tmp_path: Path) -> None:
        from owlmind.self_improve.applicator import apply_improvement

        imp = Improvement(
            category="test",
            title="Fix",
            status=ImprovementStatus.PROPOSED,  # Not approved
        )
        result = apply_improvement(imp, tmp_path)
        assert not result.success
        assert "status" in result.message.lower()

    def test_no_patch_no_target(self, tmp_path: Path) -> None:
        from owlmind.self_improve.applicator import apply_improvement

        imp = Improvement(
            category="test",
            title="Fix",
            status=ImprovementStatus.APPROVED,
        )
        result = apply_improvement(imp, tmp_path)
        assert not result.success
        assert "no patch" in result.message.lower()

    def test_advisory_dry_run(self, tmp_path: Path) -> None:
        from owlmind.self_improve.applicator import apply_improvement

        imp = Improvement(
            category="test",
            title="Add advisory",
            description="Improve error handling",
            target_file="policies/worker_system.md",
            status=ImprovementStatus.APPROVED,
        )
        result = apply_improvement(imp, tmp_path, dry_run=True)
        assert result.success
        assert result.dry_run
        assert "advisory" in result.message.lower()

    def test_advisory_apply(self, tmp_path: Path) -> None:
        from owlmind.self_improve.applicator import apply_improvement

        policies = tmp_path / "policies"
        policies.mkdir()
        (policies / "worker_system.md").write_text("# Worker System\n")

        imp = Improvement(
            category="test",
            title="Add advisory",
            description="Improve error handling",
            target_file="policies/worker_system.md",
            status=ImprovementStatus.APPROVED,
        )
        result = apply_improvement(imp, tmp_path)
        assert result.success
        assert not result.dry_run
        content = (policies / "worker_system.md").read_text()
        assert "Improvement: Add advisory" in content

    def test_batch_apply(self, tmp_path: Path) -> None:
        from owlmind.self_improve.applicator import apply_batch

        improvements = [
            Improvement(
                category="test",
                title=f"Fix {i}",
                target_file=f"file_{i}.md",
                status=ImprovementStatus.APPROVED,
            )
            for i in range(3)
        ]
        results = apply_batch(improvements, tmp_path)
        assert len(results) == 3
        assert all(r.success for r in results)

    def test_batch_stop_on_failure(self, tmp_path: Path) -> None:
        from owlmind.self_improve.applicator import apply_batch

        improvements = [
            Improvement(
                category="test",
                title="Will fail",
                status=ImprovementStatus.PROPOSED,  # Wrong status
            ),
            Improvement(
                category="test",
                title="Never reached",
                target_file="file.md",
                status=ImprovementStatus.APPROVED,
            ),
        ]
        results = apply_batch(improvements, tmp_path, stop_on_failure=True)
        assert len(results) == 1  # Stopped after first failure


# ===================================================================
# CLI tests
# ===================================================================


class TestSelfImproveCLI:
    def test_analyze_command(self, tmp_path: Path) -> None:
        from typer.testing import CliRunner

        from owlmind.cli.self_improve_cmd import self_improve_app

        runner = CliRunner()
        result = runner.invoke(self_improve_app, ["analyze", "--runs-dir", str(tmp_path)])
        # Should not error (just shows "no data")
        assert result.exit_code == 0 or "not found" in (result.output or "").lower()

    def test_proposals_empty(self, tmp_path: Path) -> None:
        from typer.testing import CliRunner

        from owlmind.cli.self_improve_cmd import self_improve_app

        runner = CliRunner()
        result = runner.invoke(self_improve_app, ["proposals", "--runs-dir", str(tmp_path)])
        assert result.exit_code == 0

    def test_list_empty(self, tmp_path: Path) -> None:
        from typer.testing import CliRunner

        from owlmind.cli.self_improve_cmd import self_improve_app

        runner = CliRunner()
        result = runner.invoke(self_improve_app, ["list", "--improvements-dir", str(tmp_path)])
        assert result.exit_code == 0

    def test_ab_test_list_empty(self, tmp_path: Path) -> None:
        from typer.testing import CliRunner

        from owlmind.cli.self_improve_cmd import self_improve_app

        runner = CliRunner()
        result = runner.invoke(self_improve_app, ["ab-test", "list", "--ab-dir", str(tmp_path)])
        assert result.exit_code == 0

    def test_apply_not_found(self, tmp_path: Path) -> None:
        from typer.testing import CliRunner

        from owlmind.cli.self_improve_cmd import self_improve_app

        runner = CliRunner()
        result = runner.invoke(
            self_improve_app,
            ["apply", "nonexistent", "--improvements-dir", str(tmp_path)],
        )
        assert result.exit_code == 1


# ===================================================================
# API route tests
# ===================================================================


class TestSelfImproveAPI:
    def test_get_report(self, tmp_path: Path) -> None:
        from fastapi.testclient import TestClient

        from owlmind.api.routes.self_improve import make_self_improve_router

        router = make_self_improve_router(tmp_path)

        from fastapi import FastAPI

        app = FastAPI()
        app.include_router(router)

        with patch("owlmind.api.auth.verify_api_key", return_value=None):
            client = TestClient(app)
            # Override dependency
            app.dependency_overrides[
                __import__("owlmind.api.auth", fromlist=["verify_api_key"]).verify_api_key
            ] = lambda: None

            resp = client.get("/api/v1/self-improve/report")
            assert resp.status_code == 200
            data = resp.json()
            assert "runs_analyzed" in data

    def test_post_proposals(self, tmp_path: Path) -> None:
        from fastapi.testclient import TestClient

        from owlmind.api.routes.self_improve import make_self_improve_router

        router = make_self_improve_router(tmp_path)

        from fastapi import FastAPI

        app = FastAPI()
        app.include_router(router)

        from owlmind.api.auth import verify_api_key

        app.dependency_overrides[verify_api_key] = lambda: None

        client = TestClient(app)
        resp = client.post(
            "/api/v1/self-improve/proposals",
            json={"max_proposals": 5},
            headers={"x-api-key": "test"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert "count" in data
        assert "proposals" in data

    def test_ab_tests_crud(self, tmp_path: Path) -> None:
        from fastapi.testclient import TestClient

        from owlmind.api.routes.self_improve import make_self_improve_router

        router = make_self_improve_router(tmp_path)

        from fastapi import FastAPI

        app = FastAPI()
        app.include_router(router)

        from owlmind.api.auth import verify_api_key

        app.dependency_overrides[verify_api_key] = lambda: None

        client = TestClient(app)

        # List empty
        resp = client.get(
            "/api/v1/self-improve/ab-tests",
            headers={"x-api-key": "test"},
        )
        assert resp.status_code == 200
        assert resp.json()["count"] == 0

        # Create
        resp = client.post(
            "/api/v1/self-improve/ab-tests",
            json={"improvement_id": "imp-001", "min_runs": 5},
            headers={"x-api-key": "test"},
        )
        assert resp.status_code == 200
        test_id = resp.json()["test_id"]
        assert test_id.startswith("ab-")


# ===================================================================
# PostgreSQL schema tests
# ===================================================================


class TestPostgresSchema:
    def test_run_extended_in_schema(self) -> None:
        from owlmind.storage.postgres import _PG_SCHEMA

        assert "run_extended" in _PG_SCHEMA
        assert "prompts_used" in _PG_SCHEMA
        assert "commands_executed" in _PG_SCHEMA
        assert "judge_verdict" in _PG_SCHEMA
        assert "duration_ms" in _PG_SCHEMA

    def test_improvements_in_schema(self) -> None:
        from owlmind.storage.postgres import _PG_SCHEMA

        assert "improvements" in _PG_SCHEMA
        assert "improvement_id" in _PG_SCHEMA
        assert "confidence" in _PG_SCHEMA
        assert "ab_test_id" in _PG_SCHEMA

    def test_ab_tests_in_schema(self) -> None:
        from owlmind.storage.postgres import _PG_SCHEMA

        assert "ab_tests" in _PG_SCHEMA
        assert "variant_a" in _PG_SCHEMA
        assert "variant_b" in _PG_SCHEMA
        assert "winner" in _PG_SCHEMA


# ===================================================================
# Migration file tests
# ===================================================================


class TestMigration:
    def test_migration_file_exists(self) -> None:
        import owlmind

        project_root = Path(owlmind.__file__).parent.parent.parent
        migration = project_root / "migrations" / "003_run_extended.sql"
        assert migration.exists(), f"Migration file not found: {migration}"

    def test_migration_contains_tables(self) -> None:
        import owlmind

        project_root = Path(owlmind.__file__).parent.parent.parent
        migration = project_root / "migrations" / "003_run_extended.sql"
        content = migration.read_text()
        assert "run_extended" in content
        assert "improvements" in content
        assert "ab_tests" in content


# ===================================================================
# Integration test
# ===================================================================


class TestIntegration:
    def test_full_pipeline(self, tmp_path: Path) -> None:
        """Full pipeline: create runs → analyze → generate → A/B test → apply."""
        from owlmind.self_improve.ab_testing import ABTestScheduler
        from owlmind.self_improve.analyzer import analyze, collect_run_extended
        from owlmind.self_improve.applicator import apply_improvement
        from owlmind.self_improve.generator import FileImprovementStore, generate_improvements

        # 1. Create test runs
        runs_dir = tmp_path / "runs"
        for i in range(5):
            state = "DONE" if i < 3 else "FAILED"
            verdict = "APPROVED" if i < 3 else "REJECTED"
            _make_run_dir(
                runs_dir,
                f"run-{i:03d}",
                state=state,
                verdict=verdict,
                with_extended=True,
                stop_reason="fail_reason" if state == "FAILED" else "judge_done",
            )

        # 2. Collect and analyze
        extended = collect_run_extended(runs_dir)
        assert len(extended) == 5

        report = analyze(extended)
        assert report.runs_analyzed == 5
        assert 0.0 < report.success_rate <= 1.0

        # 3. Generate improvements
        improvements = generate_improvements(report)
        assert len(improvements) >= 1

        # 4. Save improvements
        store = FileImprovementStore(tmp_path / "improvements")
        for imp in improvements:
            store.save(imp)

        saved = store.list_improvements()
        assert len(saved) == len(improvements)

        # 5. Create A/B test for first improvement
        ab_scheduler = ABTestScheduler(tmp_path / "ab_tests")
        first_imp = improvements[0]
        test = ab_scheduler.create_test(first_imp.improvement_id, min_runs=2)
        ab_scheduler.start_test(test.test_id)

        # 6. Record results
        ab_scheduler.record_result(test.test_id, "a", success=True)
        ab_scheduler.record_result(test.test_id, "a", success=False)
        ab_scheduler.record_result(test.test_id, "b", success=True)
        result = ab_scheduler.record_result(test.test_id, "b", success=True)
        assert result is not None
        assert result.status == ABTestStatus.COMPLETED

        # 7. If B won, approve and apply
        if result.winner == "b":
            first_imp.status = ImprovementStatus.APPROVED
            first_imp.target_file = "policies/test.md"
            store.save(first_imp)

            apply_result = apply_improvement(first_imp, tmp_path)
            assert apply_result.success


# ===================================================================
# Package import tests
# ===================================================================


class TestPackageImports:
    def test_self_improve_package_imports(self) -> None:
        from owlmind.self_improve import (
            ABTest,
            AnalysisReport,
            Improvement,
            RunExtended,
        )

        assert RunExtended is not None
        assert AnalysisReport is not None
        assert Improvement is not None
        assert ABTest is not None

    def test_analyzer_import(self) -> None:
        from owlmind.self_improve.analyzer import analyze, collect_run_extended, save_run_extended

        assert callable(analyze)
        assert callable(collect_run_extended)
        assert callable(save_run_extended)

    def test_generator_import(self) -> None:
        from owlmind.self_improve.generator import (
            FileImprovementStore,
            generate_improvements,
            generate_with_llm,
        )

        assert callable(generate_improvements)
        assert callable(generate_with_llm)
        assert FileImprovementStore is not None

    def test_ab_testing_import(self) -> None:
        from owlmind.self_improve.ab_testing import ABTestScheduler

        assert ABTestScheduler is not None

    def test_applicator_import(self) -> None:
        from owlmind.self_improve.applicator import apply_batch, apply_improvement

        assert callable(apply_improvement)
        assert callable(apply_batch)

    def test_cli_import(self) -> None:
        from owlmind.cli.self_improve_cmd import self_improve_app

        assert self_improve_app is not None

    def test_cli_registered(self) -> None:
        from owlmind.cli import app

        # Typer stores groups differently — just check import works
        assert app is not None
