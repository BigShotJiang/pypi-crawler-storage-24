"""Tests for LLM integration in CycleManager — NO network calls."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from owlmind.agent.cycle import CycleManager
from owlmind.agent.schemas import CycleState
from owlmind.evidence import EvidenceStore
from owlmind.policy import PolicyEngine


class FakeLLMDriver:
    """Fake LLM driver for tests — returns canned responses."""

    def __init__(
        self,
        planner_response: dict[str, Any] | None = None,
        judge_response: dict[str, Any] | None = None,
    ) -> None:
        self._planner_response = planner_response or {}
        self._judge_response = judge_response or {}
        self.plan_calls: list[dict[str, Any]] = []
        self.judge_calls: list[dict[str, Any]] = []

    @property
    def name(self) -> str:
        return "fake"

    @property
    def supports_structured(self) -> bool:
        return True

    def plan(
        self,
        planner_request: dict[str, Any],
        schema: dict[str, Any],
        **kwargs: Any,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        self.plan_calls.append(planner_request)
        meta = {
            "provider": "fake",
            "model": "fake-model",
            "response_id": "fake-resp-1",
            "latency_ms": 42,
            "usage": {"input_tokens": 10, "output_tokens": 20, "total_tokens": 30},
        }
        return self._planner_response, meta

    def judge(
        self,
        judge_request: dict[str, Any],
        schema: dict[str, Any],
        **kwargs: Any,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        self.judge_calls.append(judge_request)
        meta = {
            "provider": "fake",
            "model": "fake-model",
            "response_id": "fake-resp-2",
            "latency_ms": 55,
            "usage": {"input_tokens": 15, "output_tokens": 25, "total_tokens": 40},
        }
        return self._judge_response, meta


def _make_manager(tmp_path: Path, driver: FakeLLMDriver | None = None) -> CycleManager:
    policies_dir = tmp_path / "policies"
    policies_dir.mkdir()
    (policies_dir / "allowlist.yaml").write_text(
        'allowed_commands:\n  - "^echo "\n  - "^pytest"\n  - "^ruff"\n  - "^mypy"\n'
    )
    (policies_dir / "policy.yaml").write_text('forbidden_patterns:\n  - "rm -rf"\n')
    policy = PolicyEngine.from_directory(policies_dir)
    evidence = EvidenceStore(tmp_path / "runs")
    return CycleManager(
        evidence=evidence,
        policy=policy,
        policies_dir=policies_dir,
        llm_driver=driver,
    )


class TestRunPlannerLLM:
    def test_writes_inbox_and_evidence(self, tmp_path: Path) -> None:
        planner_resp = {
            "run_id": "placeholder",
            "iteration": 1,
            "plan_summary": ["Step 1: Test thing"],
            "worker_instructions": "Do the test thing",
            "verify_commands": ["pytest -q"],
            "risk_notes": [],
        }
        driver = FakeLLMDriver(planner_response=planner_resp)
        mgr = _make_manager(tmp_path, driver)

        meta = mgr.start(goal="LLM test", workspace=str(tmp_path))
        run_id = meta.run_id

        # Update placeholder run_id in response
        planner_resp["run_id"] = run_id
        driver._planner_response = planner_resp

        mgr.run_planner_llm(run_id)

        # Inbox file written
        inbox_path = tmp_path / "runs" / run_id / "inbox" / "planner_response.json"
        assert inbox_path.exists()
        data = json.loads(inbox_path.read_text())
        assert data["worker_instructions"] == "Do the test thing"

        # Evidence artifacts written
        art_dir = tmp_path / "runs" / run_id / "artifacts"
        request_art = art_dir / "openai_planner_request.json"
        response_art = art_dir / "openai_planner_response.json"
        assert request_art.exists()
        assert response_art.exists()

        # LLM was called once
        assert len(driver.plan_calls) == 1

    def test_logs_chain_event(self, tmp_path: Path) -> None:
        planner_resp = {
            "run_id": "x",
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        driver = FakeLLMDriver(planner_response=planner_resp)
        mgr = _make_manager(tmp_path, driver)

        meta = mgr.start(goal="Chain event test", workspace=str(tmp_path))
        planner_resp["run_id"] = meta.run_id
        driver._planner_response = planner_resp

        mgr.run_planner_llm(meta.run_id)

        events = mgr.evidence.read_events(meta.run_id)
        llm_events = [e for e in events if e.get("event") == "LLM_PLANNER_CALLED"]
        assert len(llm_events) == 1
        assert llm_events[0]["provider"] == "fake"
        assert llm_events[0]["model"] == "fake-model"
        assert llm_events[0]["latency_ms"] == 42

    def test_rejects_wrong_state(self, tmp_path: Path) -> None:
        driver = FakeLLMDriver()
        mgr = _make_manager(tmp_path, driver)

        meta = mgr.start(goal="Wrong state test", workspace=str(tmp_path))

        # Manually advance to WAIT_WORKER
        planner_resp = {
            "run_id": meta.run_id,
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        inbox = tmp_path / "runs" / meta.run_id / "inbox"
        inbox.mkdir(parents=True, exist_ok=True)
        (inbox / "planner_response.json").write_text(json.dumps(planner_resp))
        mgr.submit_planner(meta.run_id)

        import pytest

        with pytest.raises(RuntimeError, match="STARTED_WAIT_PLANNER"):
            mgr.run_planner_llm(meta.run_id)

    def test_rejects_no_driver(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path, driver=None)
        meta = mgr.start(goal="No driver test", workspace=str(tmp_path))

        import pytest

        with pytest.raises(RuntimeError, match="No LLM driver"):
            mgr.run_planner_llm(meta.run_id)


class TestRunJudgeLLM:
    def _setup_wait_judge(self, tmp_path: Path, mgr: CycleManager) -> str:
        """Start a cycle and advance to WAIT_JUDGE state."""
        meta = mgr.start(goal="Judge LLM test", workspace=str(tmp_path))
        run_id = meta.run_id

        # Submit planner
        planner_resp = {
            "run_id": run_id,
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        inbox = tmp_path / "runs" / run_id / "inbox"
        inbox.mkdir(parents=True, exist_ok=True)
        (inbox / "planner_response.json").write_text(json.dumps(planner_resp))
        mgr.submit_planner(run_id)

        # Submit worker
        worker_report = {
            "run_id": run_id,
            "iteration": 1,
            "status": "READY_FOR_VERIFY",
            "done_summary": ["Done"],
            "questions": [],
            "commands_run": [],
        }
        (inbox / "worker_report.json").write_text(json.dumps(worker_report))
        mgr.submit_worker(run_id)

        return run_id

    def test_writes_inbox_and_evidence(self, tmp_path: Path) -> None:
        judge_resp = {
            "run_id": "placeholder",
            "iteration": 1,
            "verdict": "APPROVED",
            "notes": ["All good"],
            "next_worker_instructions": "",
            "evidence_chain_verified": True,
        }
        driver = FakeLLMDriver(judge_response=judge_resp)
        mgr = _make_manager(tmp_path, driver)

        run_id = self._setup_wait_judge(tmp_path, mgr)
        judge_resp["run_id"] = run_id
        driver._judge_response = judge_resp

        mgr.run_judge_llm(run_id)

        # Inbox file written
        inbox_path = tmp_path / "runs" / run_id / "inbox" / "judge_response.json"
        assert inbox_path.exists()
        data = json.loads(inbox_path.read_text())
        assert data["verdict"] == "APPROVED"

        # Evidence artifacts written
        art_dir = tmp_path / "runs" / run_id / "artifacts"
        assert (art_dir / "openai_judge_request.json").exists()
        assert (art_dir / "openai_judge_response.json").exists()

        # LLM was called once
        assert len(driver.judge_calls) == 1

    def test_logs_chain_event(self, tmp_path: Path) -> None:
        judge_resp = {
            "run_id": "x",
            "iteration": 1,
            "verdict": "APPROVED",
            "notes": ["OK"],
            "next_worker_instructions": "",
            "evidence_chain_verified": True,
        }
        driver = FakeLLMDriver(judge_response=judge_resp)
        mgr = _make_manager(tmp_path, driver)

        run_id = self._setup_wait_judge(tmp_path, mgr)
        judge_resp["run_id"] = run_id
        driver._judge_response = judge_resp

        mgr.run_judge_llm(run_id)

        events = mgr.evidence.read_events(run_id)
        llm_events = [e for e in events if e.get("event") == "LLM_JUDGE_CALLED"]
        assert len(llm_events) == 1
        assert llm_events[0]["provider"] == "fake"

    def test_rejects_wrong_state(self, tmp_path: Path) -> None:
        driver = FakeLLMDriver()
        mgr = _make_manager(tmp_path, driver)
        meta = mgr.start(goal="Wrong state judge", workspace=str(tmp_path))

        import pytest

        with pytest.raises(RuntimeError, match="WAIT_JUDGE"):
            mgr.run_judge_llm(meta.run_id)

    def test_rejects_no_driver(self, tmp_path: Path) -> None:
        """Cannot call judge LLM if no driver is set."""
        planner_resp = {
            "run_id": "x",
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        # Use a driver for setup, then remove it
        driver = FakeLLMDriver(planner_response=planner_resp)
        mgr = _make_manager(tmp_path, driver)

        run_id = self._setup_wait_judge(tmp_path, mgr)

        # Remove driver
        mgr.llm_driver = None

        import pytest

        with pytest.raises(RuntimeError, match="No LLM driver"):
            mgr.run_judge_llm(run_id)


class TestEndToEndLLM:
    def test_plan_then_submit_advances_state(self, tmp_path: Path) -> None:
        """run_planner_llm + submit_planner should advance to WAIT_WORKER."""
        planner_resp = {
            "run_id": "placeholder",
            "iteration": 1,
            "plan_summary": ["Step 1: E2E test"],
            "worker_instructions": "Do the E2E",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        driver = FakeLLMDriver(planner_response=planner_resp)
        mgr = _make_manager(tmp_path, driver)

        meta = mgr.start(goal="E2E LLM test", workspace=str(tmp_path))
        planner_resp["run_id"] = meta.run_id
        driver._planner_response = planner_resp

        # LLM generates planner response
        mgr.run_planner_llm(meta.run_id)

        # submit_planner should now work (inbox file exists)
        updated = mgr.submit_planner(meta.run_id)
        assert updated.state == CycleState.WAIT_WORKER
        assert updated.planner_plan_summary == ["Step 1: E2E test"]
