"""Tests for FS74 — session runner orchestration (DAG, parallel, lock)."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from owlmind.session_runner import SessionResult, run_session, stop_session

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_goal(
    gid: str = "g1",
    goal_text: str = "Fix bug",
    depends_on: list[str] | None = None,
) -> MagicMock:
    """Build a mock Goal object."""
    g = MagicMock()
    g.id = gid
    g.goal = goal_text
    g.depends_on = depends_on or []
    g.workspace = "."
    g.sandbox = False
    g.use_llm = "none"
    g.use_worker = "none"
    g.provider_planner = None
    g.provider_judge = None
    g.max_steps = 10
    g.interval_sec = 0
    g.export_on_done = False
    return g


def _make_meta(
    goals: list[MagicMock] | None = None,
    max_concurrency: int = 1,
    continue_on_fail: bool = False,
) -> MagicMock:
    """Build a mock SessionMeta object."""
    meta = MagicMock()
    meta.session_id = "sess-test"
    meta.status = "RUNNING"
    meta.max_concurrency = max_concurrency
    meta.continue_on_fail = continue_on_fail
    meta.goals = goals or []
    meta.runs = []
    meta.last_block_reason = ""
    meta.current_goal_index = 0
    return meta


def _ap_result(final_state: str = "DONE") -> MagicMock:
    """Build a mock AutoPilotResult."""
    r = MagicMock()
    r.final_state = final_state
    r.run_id = "run-abc"
    r.stop_reason = "" if final_state == "DONE" else "Max steps reached"
    return r


def _base_patches(
    lock_acquires: bool = True,
    meta: MagicMock | None = None,
    layers: list[list[str]] | None = None,
    ap_final_state: str = "DONE",
) -> list[MagicMock]:
    """Return a list of context-manager patch objects for common tests."""
    # Callers must use these via nested `with` or contextlib.ExitStack.
    return []  # unused — patches are inline per-test for clarity


# ---------------------------------------------------------------------------
# Lock behaviour
# ---------------------------------------------------------------------------


class TestRunSessionLock:
    def test_lock_acquired_and_released(self, tmp_path: Path) -> None:
        """Lock is acquired before running and released in the finally block."""
        with (
            patch("owlmind.session_runner.SessionLock") as MockLock,
            patch("owlmind.session_runner.load_session") as mock_load,
            patch("owlmind.session_runner.save_session"),
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.render_protocol"),
            patch("owlmind.session_runner.validate_dag"),
            patch("owlmind.session_runner.topological_layers", return_value=[]),
            patch("owlmind.autopilot.run"),
            patch("owlmind.autopilot.AutoPilotConfig"),
        ):
            MockLock.return_value.acquire.return_value = True
            meta = _make_meta()
            meta.status = "DONE"  # early return — no autopilot needed
            mock_load.return_value = meta

            result = run_session("sess-test", tmp_path, tmp_path, tmp_path, tmp_path)

        MockLock.return_value.acquire.assert_called_once()
        MockLock.return_value.release.assert_called_once()
        assert result.session_id == "sess-test"

    def test_lock_fails_raises(self, tmp_path: Path) -> None:
        """RuntimeError is raised when the session lock cannot be acquired."""
        with patch("owlmind.session_runner.SessionLock") as MockLock:
            MockLock.return_value.acquire.return_value = False

            with pytest.raises(RuntimeError, match="locked"):
                run_session("sess-test", tmp_path, tmp_path, tmp_path, tmp_path)


# ---------------------------------------------------------------------------
# Sequential execution
# ---------------------------------------------------------------------------


class TestRunSessionSequential:
    def test_single_goal_done(self, tmp_path: Path) -> None:
        """One goal that completes -> session status DONE, goals_done=1."""
        with (
            patch("owlmind.session_runner.SessionLock") as MockLock,
            patch("owlmind.session_runner.load_session") as mock_load,
            patch("owlmind.session_runner.save_session"),
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.render_protocol"),
            patch("owlmind.session_runner.validate_dag"),
            patch("owlmind.session_runner.topological_layers", return_value=[["g1"]]),
            patch("owlmind.autopilot.run", return_value=_ap_result("DONE")),
            patch("owlmind.autopilot.AutoPilotConfig"),
        ):
            MockLock.return_value.acquire.return_value = True
            goal = _make_goal("g1")
            meta = _make_meta(goals=[goal])
            mock_load.return_value = meta

            result = run_session("sess-test", tmp_path, tmp_path, tmp_path, tmp_path)

        assert result.status == "DONE"
        assert result.goals_done == 1

    def test_single_goal_blocked(self, tmp_path: Path) -> None:
        """One goal that blocks -> session status BLOCKED."""
        with (
            patch("owlmind.session_runner.SessionLock") as MockLock,
            patch("owlmind.session_runner.load_session") as mock_load,
            patch("owlmind.session_runner.save_session"),
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.render_protocol"),
            patch("owlmind.session_runner.validate_dag"),
            patch("owlmind.session_runner.topological_layers", return_value=[["g1"]]),
            patch("owlmind.autopilot.run", return_value=_ap_result("WAIT_APPROVAL")),
            patch("owlmind.autopilot.AutoPilotConfig"),
        ):
            MockLock.return_value.acquire.return_value = True
            goal = _make_goal("g1")
            meta = _make_meta(goals=[goal])
            mock_load.return_value = meta

            result = run_session("sess-test", tmp_path, tmp_path, tmp_path, tmp_path)

        assert result.status == "BLOCKED"

    def test_single_goal_failed_stop(self, tmp_path: Path) -> None:
        """Goal fails + continue_on_fail=False -> session FAILED, stops immediately."""
        with (
            patch("owlmind.session_runner.SessionLock") as MockLock,
            patch("owlmind.session_runner.load_session") as mock_load,
            patch("owlmind.session_runner.save_session"),
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.render_protocol"),
            patch("owlmind.session_runner.validate_dag"),
            patch("owlmind.session_runner.topological_layers", return_value=[["g1"]]),
            patch("owlmind.autopilot.run", return_value=_ap_result("FAILED")),
            patch("owlmind.autopilot.AutoPilotConfig"),
        ):
            MockLock.return_value.acquire.return_value = True
            goal = _make_goal("g1")
            meta = _make_meta(goals=[goal], continue_on_fail=False)
            mock_load.return_value = meta

            result = run_session("sess-test", tmp_path, tmp_path, tmp_path, tmp_path)

        assert result.status == "FAILED"

    def test_goal_failed_continue_on_fail(self, tmp_path: Path) -> None:
        """Goal fails but continue_on_fail=True -> session runs to completion."""
        with (
            patch("owlmind.session_runner.SessionLock") as MockLock,
            patch("owlmind.session_runner.load_session") as mock_load,
            patch("owlmind.session_runner.save_session"),
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.render_protocol"),
            patch("owlmind.session_runner.validate_dag"),
            patch("owlmind.session_runner.topological_layers", return_value=[["g1"]]),
            patch("owlmind.autopilot.run", return_value=_ap_result("FAILED")),
            patch("owlmind.autopilot.AutoPilotConfig"),
        ):
            MockLock.return_value.acquire.return_value = True
            goal = _make_goal("g1")
            meta = _make_meta(goals=[goal], continue_on_fail=True)
            mock_load.return_value = meta

            result = run_session("sess-test", tmp_path, tmp_path, tmp_path, tmp_path)

        assert result.status == "DONE"

    def test_already_done_session_returns_early(self, tmp_path: Path) -> None:
        """If session is already DONE, autopilot is never invoked."""
        with (
            patch("owlmind.session_runner.SessionLock") as MockLock,
            patch("owlmind.session_runner.load_session") as mock_load,
            patch("owlmind.session_runner.save_session"),
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.render_protocol"),
            patch("owlmind.autopilot.run") as mock_ap_run,
            patch("owlmind.autopilot.AutoPilotConfig"),
        ):
            MockLock.return_value.acquire.return_value = True
            meta = _make_meta()
            meta.status = "DONE"
            mock_load.return_value = meta

            result = run_session("sess-test", tmp_path, tmp_path, tmp_path, tmp_path)

        mock_ap_run.assert_not_called()
        assert result.status == "DONE"

    def test_invalid_dag_fails_session(self, tmp_path: Path) -> None:
        """DAG validation error -> session FAILED with DAG message."""
        with (
            patch("owlmind.session_runner.SessionLock") as MockLock,
            patch("owlmind.session_runner.load_session") as mock_load,
            patch("owlmind.session_runner.save_session"),
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.render_protocol"),
            patch("owlmind.session_runner.validate_dag", side_effect=ValueError("cycle")),
            patch("owlmind.autopilot.run") as mock_ap_run,
            patch("owlmind.autopilot.AutoPilotConfig"),
        ):
            MockLock.return_value.acquire.return_value = True
            goal = _make_goal("g1")
            meta = _make_meta(goals=[goal])
            mock_load.return_value = meta

            result = run_session("sess-test", tmp_path, tmp_path, tmp_path, tmp_path)

        assert result.status == "FAILED"
        assert "DAG" in result.last_block_reason
        mock_ap_run.assert_not_called()


# ---------------------------------------------------------------------------
# Parallel execution
# ---------------------------------------------------------------------------


class TestRunSessionParallel:
    def test_parallel_two_goals_done(self, tmp_path: Path) -> None:
        """Two independent goals run in parallel, both DONE -> session DONE."""
        with (
            patch("owlmind.session_runner.SessionLock") as MockLock,
            patch("owlmind.session_runner.load_session") as mock_load,
            patch("owlmind.session_runner.save_session"),
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.render_protocol"),
            patch("owlmind.session_runner.validate_dag"),
            patch("owlmind.session_runner.topological_layers", return_value=[["g1", "g2"]]),
            patch("owlmind.autopilot.run", return_value=_ap_result("DONE")),
            patch("owlmind.autopilot.AutoPilotConfig"),
        ):
            MockLock.return_value.acquire.return_value = True
            goal1 = _make_goal("g1", "Fix bug A")
            goal2 = _make_goal("g2", "Fix bug B")
            meta = _make_meta(goals=[goal1, goal2], max_concurrency=2)
            mock_load.return_value = meta

            result = run_session(
                "sess-test",
                tmp_path,
                tmp_path,
                tmp_path,
                tmp_path,
                max_concurrency=2,
            )

        assert result.status == "DONE"
        assert result.goals_done == 2

    def test_parallel_one_failed_no_continue(self, tmp_path: Path) -> None:
        """Goal fails in parallel mode, continue_on_fail=False -> session FAILED."""
        with (
            patch("owlmind.session_runner.SessionLock") as MockLock,
            patch("owlmind.session_runner.load_session") as mock_load,
            patch("owlmind.session_runner.save_session"),
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.render_protocol"),
            patch("owlmind.session_runner.validate_dag"),
            patch("owlmind.session_runner.topological_layers", return_value=[["g1"]]),
            patch("owlmind.autopilot.run", return_value=_ap_result("FAILED")),
            patch("owlmind.autopilot.AutoPilotConfig"),
        ):
            MockLock.return_value.acquire.return_value = True
            goal = _make_goal("g1")
            meta = _make_meta(goals=[goal], max_concurrency=2, continue_on_fail=False)
            mock_load.return_value = meta

            result = run_session(
                "sess-test",
                tmp_path,
                tmp_path,
                tmp_path,
                tmp_path,
                max_concurrency=2,
            )

        assert result.status == "FAILED"


# ---------------------------------------------------------------------------
# stop_session
# ---------------------------------------------------------------------------


class TestStopSession:
    def test_stop_marks_stopped(self, tmp_path: Path) -> None:
        """stop_session marks the session as STOPPED and saves state."""
        with (
            patch("owlmind.session_runner.load_session") as mock_load,
            patch("owlmind.session_runner.save_session") as mock_save,
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.render_protocol"),
        ):
            meta = _make_meta()
            mock_load.return_value = meta

            returned_meta = stop_session("sess-test", tmp_path, tmp_path)

        assert returned_meta.status == "STOPPED"
        mock_save.assert_called()


# ---------------------------------------------------------------------------
# Result fields
# ---------------------------------------------------------------------------


class TestBuildResult:
    def test_result_fields_populated(self, tmp_path: Path) -> None:
        """SessionResult has correct session_id, goals_total, goals_done."""
        with (
            patch("owlmind.session_runner.SessionLock") as MockLock,
            patch("owlmind.session_runner.load_session") as mock_load,
            patch("owlmind.session_runner.save_session"),
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.render_protocol"),
            patch("owlmind.session_runner.validate_dag"),
            patch("owlmind.session_runner.topological_layers", return_value=[["g1"]]),
            patch("owlmind.autopilot.run", return_value=_ap_result("DONE")),
            patch("owlmind.autopilot.AutoPilotConfig"),
        ):
            MockLock.return_value.acquire.return_value = True
            goal = _make_goal("g1")
            meta = _make_meta(goals=[goal])
            mock_load.return_value = meta

            result = run_session("sess-test", tmp_path, tmp_path, tmp_path, tmp_path)

        assert isinstance(result, SessionResult)
        assert result.session_id == "sess-test"
        assert result.goals_total == 1
        assert result.goals_done == 1
        assert result.status == "DONE"


# ---------------------------------------------------------------------------
# Self-eval memory signals (FS76)
# ---------------------------------------------------------------------------


class TestSelfEvalSignal:
    def test_memory_signal_written_on_goal_done(self, tmp_path: Path) -> None:
        """memory_db param -> MemoryStore.add_signal called after goal completes."""
        with (
            patch("owlmind.session_runner.SessionLock") as MockLock,
            patch("owlmind.session_runner.load_session") as mock_load,
            patch("owlmind.session_runner.save_session"),
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.render_protocol"),
            patch("owlmind.session_runner.validate_dag"),
            patch("owlmind.session_runner.topological_layers", return_value=[["g1"]]),
            patch("owlmind.autopilot.run", return_value=_ap_result("DONE")),
            patch("owlmind.autopilot.AutoPilotConfig"),
            patch("owlmind.memory.store.MemoryStore") as MockStore,
        ):
            MockLock.return_value.acquire.return_value = True
            goal = _make_goal("g1", "Fix authentication bug")
            meta = _make_meta(goals=[goal])
            mock_load.return_value = meta
            memory_db = tmp_path / "memory.db"

            run_session(
                "sess-test",
                tmp_path,
                tmp_path,
                tmp_path,
                tmp_path,
                memory_db=memory_db,
            )

        MockStore.assert_called_once_with(memory_db)
        MockStore.return_value.add_signal.assert_called_once()
        MockStore.return_value.close.assert_called_once()


# ---------------------------------------------------------------------------
# Additional coverage
# ---------------------------------------------------------------------------


class TestSessionRunnerAdditional:
    def test_run_session_no_goals(self, tmp_path: Path) -> None:
        """Session with no goals -> immediately DONE, goals_done=0."""
        with (
            patch("owlmind.session_runner.SessionLock") as MockLock,
            patch("owlmind.session_runner.load_session") as mock_load,
            patch("owlmind.session_runner.save_session"),
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.render_protocol"),
            patch("owlmind.session_runner.validate_dag"),
            patch("owlmind.session_runner.topological_layers", return_value=[]),
            patch("owlmind.autopilot.run") as mock_ap_run,
            patch("owlmind.autopilot.AutoPilotConfig"),
        ):
            MockLock.return_value.acquire.return_value = True
            meta = _make_meta(goals=[])
            mock_load.return_value = meta

            result = run_session("sess-test", tmp_path, tmp_path, tmp_path, tmp_path)

        mock_ap_run.assert_not_called()
        assert result.status == "DONE"
        assert result.goals_done == 0
        assert result.goals_total == 0

    def test_goal_id_missing_from_meta(self, tmp_path: Path) -> None:
        """Goal id in topological layer not found in meta.goals -> KeyError."""
        with (
            patch("owlmind.session_runner.SessionLock") as MockLock,
            patch("owlmind.session_runner.load_session") as mock_load,
            patch("owlmind.session_runner.save_session"),
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.render_protocol"),
            patch("owlmind.session_runner.validate_dag"),
            # layer references "g-nonexistent" but meta only has "g1"
            patch("owlmind.session_runner.topological_layers", return_value=[["g-nonexistent"]]),
            patch("owlmind.autopilot.run") as mock_ap_run,
            patch("owlmind.autopilot.AutoPilotConfig"),
        ):
            MockLock.return_value.acquire.return_value = True
            goal = _make_goal("g1")
            meta = _make_meta(goals=[goal])
            mock_load.return_value = meta

            with pytest.raises(KeyError):
                run_session("sess-test", tmp_path, tmp_path, tmp_path, tmp_path)

        mock_ap_run.assert_not_called()

    def test_run_session_with_memory_db(self, tmp_path: Path) -> None:
        """memory_db param provided -> MemoryStore instantiated and add_signal called."""
        with (
            patch("owlmind.session_runner.SessionLock") as MockLock,
            patch("owlmind.session_runner.load_session") as mock_load,
            patch("owlmind.session_runner.save_session"),
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.render_protocol"),
            patch("owlmind.session_runner.validate_dag"),
            patch("owlmind.session_runner.topological_layers", return_value=[["g1"]]),
            patch("owlmind.autopilot.run", return_value=_ap_result("DONE")),
            patch("owlmind.autopilot.AutoPilotConfig"),
            patch("owlmind.memory.store.MemoryStore") as MockStore,
        ):
            MockLock.return_value.acquire.return_value = True
            goal = _make_goal("g1", "Implement feature X")
            meta = _make_meta(goals=[goal])
            mock_load.return_value = meta
            memory_db = tmp_path / "signals.db"

            result = run_session(
                "sess-test",
                tmp_path,
                tmp_path,
                tmp_path,
                tmp_path,
                memory_db=memory_db,
            )

        assert result.status == "DONE"
        MockStore.assert_called_once_with(memory_db)
        MockStore.return_value.add_signal.assert_called_once()
        MockStore.return_value.close.assert_called_once()

    def test_stop_session_already_stopped(self, tmp_path: Path) -> None:
        """stop_session on already-STOPPED session sets status STOPPED again (idempotent)."""
        with (
            patch("owlmind.session_runner.load_session") as mock_load,
            patch("owlmind.session_runner.save_session") as mock_save,
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.render_protocol"),
        ):
            meta = _make_meta()
            meta.status = "STOPPED"
            mock_load.return_value = meta

            returned_meta = stop_session("sess-test", tmp_path, tmp_path)

        assert returned_meta.status == "STOPPED"
        mock_save.assert_called()

    def test_parallel_execution_memory_db(self, tmp_path: Path) -> None:
        """Parallel run with memory_db -> MemoryStore called per goal completion."""
        with (
            patch("owlmind.session_runner.SessionLock") as MockLock,
            patch("owlmind.session_runner.load_session") as mock_load,
            patch("owlmind.session_runner.save_session"),
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.render_protocol"),
            patch("owlmind.session_runner.validate_dag"),
            patch("owlmind.session_runner.topological_layers", return_value=[["g1", "g2"]]),
            patch("owlmind.autopilot.run", return_value=_ap_result("DONE")),
            patch("owlmind.autopilot.AutoPilotConfig"),
            patch("owlmind.memory.store.MemoryStore") as MockStore,
        ):
            MockLock.return_value.acquire.return_value = True
            goal1 = _make_goal("g1", "Deploy service A")
            goal2 = _make_goal("g2", "Deploy service B")
            meta = _make_meta(goals=[goal1, goal2], max_concurrency=2)
            mock_load.return_value = meta
            memory_db = tmp_path / "parallel_signals.db"

            result = run_session(
                "sess-test",
                tmp_path,
                tmp_path,
                tmp_path,
                tmp_path,
                max_concurrency=2,
                memory_db=memory_db,
            )

        assert result.status == "DONE"
        assert result.goals_done == 2
        MockStore.assert_called_with(memory_db)
        assert MockStore.return_value.add_signal.call_count == 2


# ---------------------------------------------------------------------------
# Tests: memory signal write failure is swallowed (lines 127-128)
# ---------------------------------------------------------------------------


class TestMemorySignalWriteFailure:
    """Cover the except-block when MemoryStore.add_signal raises."""

    def test_memory_signal_exception_is_swallowed(self, tmp_path: Path) -> None:
        mock_store = MagicMock()
        mock_store.add_signal.side_effect = RuntimeError("db locked")

        with (
            patch("owlmind.session_runner.SessionLock") as MockLock,
            patch("owlmind.session_runner.load_session") as mock_load,
            patch("owlmind.session_runner.save_session"),
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.render_protocol"),
            patch("owlmind.session_runner.validate_dag"),
            patch("owlmind.session_runner.topological_layers", return_value=[["g1"]]),
            patch("owlmind.autopilot.run", return_value=_ap_result("DONE")),
            patch("owlmind.autopilot.AutoPilotConfig"),
            patch("owlmind.memory.store.MemoryStore", return_value=mock_store),
        ):
            MockLock.return_value.acquire.return_value = True
            goal = _make_goal("g1", "Test memory fail")
            meta = _make_meta(goals=[goal])
            mock_load.return_value = meta
            memory_db = tmp_path / "test.db"

            # Should NOT raise despite add_signal throwing
            result = run_session(
                "sess-test",
                tmp_path,
                tmp_path,
                tmp_path,
                tmp_path,
                memory_db=memory_db,
            )

        assert result.status == "DONE"


# ---------------------------------------------------------------------------
# Tests: continue_on_fail override (line 140)
# ---------------------------------------------------------------------------


class TestContinueOnFailOverride:
    """Cover the branch that sets meta.continue_on_fail from the parameter."""

    def test_continue_on_fail_override_applied(self, tmp_path: Path) -> None:
        with (
            patch("owlmind.session_runner.SessionLock") as MockLock,
            patch("owlmind.session_runner.load_session") as mock_load,
            patch("owlmind.session_runner.save_session"),
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.render_protocol"),
            patch("owlmind.session_runner.validate_dag"),
            patch("owlmind.session_runner.topological_layers", return_value=[["g1"]]),
            patch("owlmind.autopilot.run", return_value=_ap_result("FAILED")),
            patch("owlmind.autopilot.AutoPilotConfig"),
        ):
            MockLock.return_value.acquire.return_value = True
            goal = _make_goal("g1")
            # meta.continue_on_fail starts as False
            meta = _make_meta(goals=[goal], continue_on_fail=False)
            mock_load.return_value = meta

            # Pass continue_on_fail=True as override -> session should complete as DONE
            result = run_session(
                "sess-test",
                tmp_path,
                tmp_path,
                tmp_path,
                tmp_path,
                continue_on_fail=True,
            )

        # With continue_on_fail=True the failed goal doesn't stop the session
        assert result.status == "DONE"


# ---------------------------------------------------------------------------
# Tests: sequential - previously-failed goal with continue_on_fail=True (line 234)
# ---------------------------------------------------------------------------


class TestSequentialPreviouslyFailed:
    """Cover the 'continue' branch for already-failed goals when continue_on_fail=True."""

    def test_previously_failed_goal_skipped_continue_on_fail(self, tmp_path: Path) -> None:
        """A goal already in 'failed' status is skipped when continue_on_fail=True."""
        with (
            patch("owlmind.session_runner.SessionLock") as MockLock,
            patch("owlmind.session_runner.load_session") as mock_load,
            patch("owlmind.session_runner.save_session"),
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.render_protocol"),
            patch("owlmind.session_runner.validate_dag"),
            patch("owlmind.session_runner.topological_layers", return_value=[["g1", "g2"]]),
            patch("owlmind.autopilot.run", return_value=_ap_result("DONE")),
            patch("owlmind.autopilot.AutoPilotConfig"),
        ):
            MockLock.return_value.acquire.return_value = True
            goal1 = _make_goal("g1")
            goal2 = _make_goal("g2")
            meta = _make_meta(goals=[goal1, goal2], continue_on_fail=True)
            # Pre-populate run_map with g1 as already failed
            failed_run = MagicMock()
            failed_run.goal_id = "g1"
            failed_run.status = "failed"
            failed_run.run_id = "run-g1-failed"
            meta.runs = [failed_run]
            mock_load.return_value = meta

            result = run_session("sess-test", tmp_path, tmp_path, tmp_path, tmp_path)

        assert result.status == "DONE"


# ---------------------------------------------------------------------------
# Tests: sequential - dep failed with continue_on_fail=True -> skip (lines 236-242)
# ---------------------------------------------------------------------------


class TestSequentialDepFailedSkip:
    """Cover dep-failed -> _mark_skipped branch when continue_on_fail=True."""

    def test_dep_failed_continue_marks_skipped(self, tmp_path: Path) -> None:
        """When a dep has failed and continue_on_fail=True, dependent goal is skipped."""
        with (
            patch("owlmind.session_runner.SessionLock") as MockLock,
            patch("owlmind.session_runner.load_session") as mock_load,
            patch("owlmind.session_runner.save_session"),
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.render_protocol"),
            patch("owlmind.session_runner.validate_dag"),
            # Two layers: g1 first, g2 depends on g1
            patch(
                "owlmind.session_runner.topological_layers",
                return_value=[["g1"], ["g2"]],
            ),
            patch("owlmind.autopilot.run", return_value=_ap_result("DONE")),
            patch("owlmind.autopilot.AutoPilotConfig"),
        ):
            MockLock.return_value.acquire.return_value = True
            goal1 = _make_goal("g1")
            goal2 = _make_goal("g2", depends_on=["g1"])
            meta = _make_meta(goals=[goal1, goal2], continue_on_fail=True)
            # g1 already failed
            failed_run = MagicMock()
            failed_run.goal_id = "g1"
            failed_run.status = "failed"
            failed_run.run_id = "run-g1"
            meta.runs = [failed_run]
            mock_load.return_value = meta

            result = run_session("sess-test", tmp_path, tmp_path, tmp_path, tmp_path)

        # g2 should be skipped, session should still complete as DONE
        assert result.status == "DONE"
        assert result.goals_skipped == 1


# ---------------------------------------------------------------------------
# Tests: sequential - dep failed with continue_on_fail=False (lines 255-262)
# ---------------------------------------------------------------------------


class TestSequentialDepFailedStop:
    """Cover dep-failed -> SESSION_FAILED when continue_on_fail=False (lines 255-262)."""

    def test_dep_failed_no_continue_fails_session(self, tmp_path: Path) -> None:
        """g2 is in the layer, g2 is pending, g2's dep g1 is already failed.

        To reach lines 255-262 (the deps_ok=False + dep_failed + not continue_on_fail
        branch), we need g2 to be scheduled but its dep to be failed. We put only
        g2 in the topological layer so the loop doesn't process g1 first and
        return early via the status=='failed' check.
        """
        with (
            patch("owlmind.session_runner.SessionLock") as MockLock,
            patch("owlmind.session_runner.load_session") as mock_load,
            patch("owlmind.session_runner.save_session"),
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.render_protocol"),
            patch("owlmind.session_runner.validate_dag"),
            # Only g2 in the layer; g1 is already failed in run_map
            patch(
                "owlmind.session_runner.topological_layers",
                return_value=[["g2"]],
            ),
            patch("owlmind.autopilot.run", return_value=_ap_result("DONE")),
            patch("owlmind.autopilot.AutoPilotConfig"),
        ):
            MockLock.return_value.acquire.return_value = True
            goal1 = _make_goal("g1")
            goal2 = _make_goal("g2", depends_on=["g1"])
            meta = _make_meta(goals=[goal1, goal2], continue_on_fail=False)
            # g1 already failed — in run_map but NOT in the topo layer
            failed_run = MagicMock()
            failed_run.goal_id = "g1"
            failed_run.status = "failed"
            failed_run.run_id = "run-g1"
            meta.runs = [failed_run]
            mock_load.return_value = meta

            result = run_session("sess-test", tmp_path, tmp_path, tmp_path, tmp_path)

        assert result.status == "FAILED"
        assert "failed" in result.last_block_reason.lower()


# ---------------------------------------------------------------------------
# Tests: parallel - session_blocked breaks subsequent layers (line 382)
# ---------------------------------------------------------------------------


class TestParallelEarlyBreak:
    """Cover the early-break on session_blocked in parallel loop."""

    def test_parallel_session_blocked_breaks_subsequent_layers(self, tmp_path: Path) -> None:
        """When first layer blocks, second layer is never processed."""
        with (
            patch("owlmind.session_runner.SessionLock") as MockLock,
            patch("owlmind.session_runner.load_session") as mock_load,
            patch("owlmind.session_runner.save_session"),
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.render_protocol"),
            patch("owlmind.session_runner.validate_dag"),
            # Two layers - g1 then g2
            patch(
                "owlmind.session_runner.topological_layers",
                return_value=[["g1"], ["g2"]],
            ),
            patch("owlmind.autopilot.run", return_value=_ap_result("WAIT_APPROVAL")),
            patch("owlmind.autopilot.AutoPilotConfig"),
        ):
            MockLock.return_value.acquire.return_value = True
            goal1 = _make_goal("g1")
            goal2 = _make_goal("g2")
            meta = _make_meta(goals=[goal1, goal2], max_concurrency=2)
            mock_load.return_value = meta

            result = run_session(
                "sess-test",
                tmp_path,
                tmp_path,
                tmp_path,
                tmp_path,
                max_concurrency=2,
            )

        assert result.status == "BLOCKED"


# ---------------------------------------------------------------------------
# Tests: parallel - dep failed handling (lines 401-411)
# ---------------------------------------------------------------------------


class TestParallelDepFailed:
    """Cover dep-failed handling in parallel loop."""

    def test_parallel_dep_failed_continue_marks_skipped(self, tmp_path: Path) -> None:
        with (
            patch("owlmind.session_runner.SessionLock") as MockLock,
            patch("owlmind.session_runner.load_session") as mock_load,
            patch("owlmind.session_runner.save_session"),
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.render_protocol"),
            patch("owlmind.session_runner.validate_dag"),
            # Two layers
            patch(
                "owlmind.session_runner.topological_layers",
                return_value=[["g1"], ["g2"]],
            ),
            patch("owlmind.autopilot.run", return_value=_ap_result("DONE")),
            patch("owlmind.autopilot.AutoPilotConfig"),
        ):
            MockLock.return_value.acquire.return_value = True
            goal1 = _make_goal("g1")
            goal2 = _make_goal("g2", depends_on=["g1"])
            meta = _make_meta(goals=[goal1, goal2], max_concurrency=2, continue_on_fail=True)
            # g1 already failed
            failed_run = MagicMock()
            failed_run.goal_id = "g1"
            failed_run.status = "failed"
            failed_run.run_id = "run-g1"
            meta.runs = [failed_run]
            mock_load.return_value = meta

            result = run_session(
                "sess-test",
                tmp_path,
                tmp_path,
                tmp_path,
                tmp_path,
                max_concurrency=2,
            )

        assert result.status == "DONE"
        assert result.goals_skipped >= 1

    def test_parallel_dep_failed_no_continue_fails_session(self, tmp_path: Path) -> None:
        with (
            patch("owlmind.session_runner.SessionLock") as MockLock,
            patch("owlmind.session_runner.load_session") as mock_load,
            patch("owlmind.session_runner.save_session"),
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.render_protocol"),
            patch("owlmind.session_runner.validate_dag"),
            patch(
                "owlmind.session_runner.topological_layers",
                return_value=[["g1"], ["g2"]],
            ),
            patch("owlmind.autopilot.run", return_value=_ap_result("DONE")),
            patch("owlmind.autopilot.AutoPilotConfig"),
        ):
            MockLock.return_value.acquire.return_value = True
            goal1 = _make_goal("g1")
            goal2 = _make_goal("g2", depends_on=["g1"])
            meta = _make_meta(goals=[goal1, goal2], max_concurrency=2, continue_on_fail=False)
            failed_run = MagicMock()
            failed_run.goal_id = "g1"
            failed_run.status = "failed"
            failed_run.run_id = "run-g1"
            meta.runs = [failed_run]
            mock_load.return_value = meta

            result = run_session(
                "sess-test",
                tmp_path,
                tmp_path,
                tmp_path,
                tmp_path,
                max_concurrency=2,
            )

        assert result.status == "FAILED"


# ---------------------------------------------------------------------------
# Tests: parallel - not-to-run layer is skipped (line 417)
# ---------------------------------------------------------------------------


class TestParallelNoReadyGoals:
    """Cover the 'if not to_run: continue' path in parallel loop."""

    def test_parallel_all_done_goals_skipped_in_layer(self, tmp_path: Path) -> None:
        """A layer where all goals are already done -> to_run is empty -> continue."""
        with (
            patch("owlmind.session_runner.SessionLock") as MockLock,
            patch("owlmind.session_runner.load_session") as mock_load,
            patch("owlmind.session_runner.save_session"),
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.render_protocol"),
            patch("owlmind.session_runner.validate_dag"),
            patch(
                "owlmind.session_runner.topological_layers",
                return_value=[["g1"], ["g2"]],
            ),
            patch("owlmind.autopilot.run", return_value=_ap_result("DONE")),
            patch("owlmind.autopilot.AutoPilotConfig"),
        ):
            MockLock.return_value.acquire.return_value = True
            goal1 = _make_goal("g1")
            goal2 = _make_goal("g2")
            meta = _make_meta(goals=[goal1, goal2], max_concurrency=2)
            # g1 already done -> first layer has no pending goals
            done_run = MagicMock()
            done_run.goal_id = "g1"
            done_run.status = "done"
            done_run.run_id = "run-g1-done"
            meta.runs = [done_run]
            mock_load.return_value = meta

            result = run_session(
                "sess-test",
                tmp_path,
                tmp_path,
                tmp_path,
                tmp_path,
                max_concurrency=2,
            )

        assert result.status == "DONE"


# ---------------------------------------------------------------------------
# Tests: parallel - BaseException in gather results (lines 424-426)
# ---------------------------------------------------------------------------


class TestParallelGatherException:
    """Cover the BaseException path in the gather results loop."""

    def test_parallel_goal_exception_is_logged_and_continues(self, tmp_path: Path) -> None:
        """If a goal task raises, it is logged but the session continues."""
        from owlmind.session_runner import _run_parallel

        meta = _make_meta(goals=[_make_goal("g1"), _make_goal("g2")], max_concurrency=2)
        meta.status = "RUNNING"

        with (
            patch("owlmind.session_runner.save_session"),
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.render_protocol"),
            patch("owlmind.session_runner.topological_layers", return_value=[["g1", "g2"]]),
            patch(
                "owlmind.session_runner._execute_autopilot",
                side_effect=RuntimeError("task exploded"),
            ),
        ):
            goal_dicts = [
                {"id": "g1", "depends_on": [], "goal": "g1"},
                {"id": "g2", "depends_on": [], "goal": "g2"},
            ]
            run_map: dict[str, MagicMock] = {}

            def status_map() -> dict[str, str]:
                return {"g1": "pending", "g2": "pending"}

            def failing_autopilot(cfg: object) -> object:
                msg = "autopilot exploded"
                raise RuntimeError(msg)

            result = _run_parallel(
                meta,
                "sess-test",
                MagicMock(),
                MagicMock(),
                MagicMock(),
                MagicMock(),
                goal_dicts,
                run_map,
                status_map,
                failing_autopilot,
                MagicMock(),
                None,
            )

        # Despite exceptions, session completes (no goal statuses -> DONE)
        assert result.session_id == "sess-test"


# ---------------------------------------------------------------------------
# Tests: _execute_autopilot - existing run done returns early (lines 492, 494)
# ---------------------------------------------------------------------------


class TestExecuteAutopilotExistingRun:
    """Cover the existing_run early-return and resume branches."""

    def test_execute_autopilot_done_run_returns_early(self, tmp_path: Path) -> None:
        """Call _execute_autopilot directly: existing run 'done' -> returns 'done' at line 494."""
        from owlmind.session_runner import _execute_autopilot

        goal = _make_goal("g1")
        meta = _make_meta(goals=[goal])

        done_run = MagicMock()
        done_run.goal_id = "g1"
        done_run.status = "done"
        done_run.run_id = "run-already-done"
        run_map: dict[str, MagicMock] = {"g1": done_run}

        autopilot_called = []

        def fake_ap_run(cfg: object) -> object:
            autopilot_called.append(cfg)
            return _ap_result("DONE")

        with (
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.save_session"),
        ):
            status = _execute_autopilot(
                goal,
                meta,
                run_map,
                "sess-test",
                tmp_path,
                tmp_path,
                tmp_path,
                tmp_path,
                fake_ap_run,
                MagicMock(),
                None,
            )

        assert status == "done"
        assert len(autopilot_called) == 0

    def test_existing_run_done_returns_done_early(self, tmp_path: Path) -> None:
        """Goal already done in session -> skipped by _run_sequential, autopilot not called."""
        with (
            patch("owlmind.session_runner.SessionLock") as MockLock,
            patch("owlmind.session_runner.load_session") as mock_load,
            patch("owlmind.session_runner.save_session"),
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.render_protocol"),
            patch("owlmind.session_runner.validate_dag"),
            patch("owlmind.session_runner.topological_layers", return_value=[["g1"]]),
            patch("owlmind.autopilot.run") as mock_ap_run,
            patch("owlmind.autopilot.AutoPilotConfig"),
        ):
            MockLock.return_value.acquire.return_value = True
            goal = _make_goal("g1")
            meta = _make_meta(goals=[goal])
            # Pre-populate with existing done run
            done_run = MagicMock()
            done_run.goal_id = "g1"
            done_run.status = "done"
            done_run.run_id = "run-already-done"
            meta.runs = [done_run]
            mock_load.return_value = meta

            result = run_session("sess-test", tmp_path, tmp_path, tmp_path, tmp_path)

        # autopilot.run should NOT be called for already-done goal
        mock_ap_run.assert_not_called()
        assert result.status == "DONE"
        assert result.goals_done == 1

    def test_existing_run_blocked_resumes(self, tmp_path: Path) -> None:
        """Goal in 'blocked' status -> run_id_to_resume is set, autopilot called once."""
        with (
            patch("owlmind.session_runner.SessionLock") as MockLock,
            patch("owlmind.session_runner.load_session") as mock_load,
            patch("owlmind.session_runner.save_session"),
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.render_protocol"),
            patch("owlmind.session_runner.validate_dag"),
            patch("owlmind.session_runner.topological_layers", return_value=[["g1"]]),
            patch("owlmind.autopilot.run", return_value=_ap_result("DONE")) as mock_ap_run,
            patch("owlmind.autopilot.AutoPilotConfig") as MockConfig,
        ):
            MockLock.return_value.acquire.return_value = True
            goal = _make_goal("g1")
            meta = _make_meta(goals=[goal])
            # Pre-populate with blocked run
            blocked_run = MagicMock()
            blocked_run.goal_id = "g1"
            blocked_run.status = "blocked"
            blocked_run.run_id = "run-blocked-123"
            meta.runs = [blocked_run]
            mock_load.return_value = meta

            result = run_session("sess-test", tmp_path, tmp_path, tmp_path, tmp_path)

        mock_ap_run.assert_called_once()
        # Check run_id passed to AutoPilotConfig is the blocked run's id
        call_kwargs = MockConfig.call_args
        assert call_kwargs.kwargs.get("run_id") == "run-blocked-123"
        assert result.status == "DONE"


# ---------------------------------------------------------------------------
# Tests: _execute_autopilot - existing_run update path (lines 528-529)
# ---------------------------------------------------------------------------


class TestExecuteAutopilotUpdateExistingRun:
    """Cover the 'if existing_run: update status/ended_at' branch."""

    def test_existing_run_running_updates_status_on_completion(self, tmp_path: Path) -> None:
        with (
            patch("owlmind.session_runner.SessionLock") as MockLock,
            patch("owlmind.session_runner.load_session") as mock_load,
            patch("owlmind.session_runner.save_session"),
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.render_protocol"),
            patch("owlmind.session_runner.validate_dag"),
            patch("owlmind.session_runner.topological_layers", return_value=[["g1"]]),
            patch("owlmind.autopilot.run", return_value=_ap_result("DONE")),
            patch("owlmind.autopilot.AutoPilotConfig"),
        ):
            MockLock.return_value.acquire.return_value = True
            goal = _make_goal("g1")
            meta = _make_meta(goals=[goal])
            # Pre-populate with running run
            running_run = MagicMock()
            running_run.goal_id = "g1"
            running_run.status = "running"
            running_run.run_id = "run-running-456"
            meta.runs = [running_run]
            mock_load.return_value = meta

            result = run_session("sess-test", tmp_path, tmp_path, tmp_path, tmp_path)

        # Status should have been updated on the existing run object
        assert running_run.status == "done"
        assert result.status == "DONE"


# ---------------------------------------------------------------------------
# Tests: _mark_skipped - existing run in run_map (lines 665-667)
# ---------------------------------------------------------------------------


class TestMarkSkippedExistingRun:
    """Cover the 'if existing:' branch in _mark_skipped."""

    def test_mark_skipped_updates_existing_run(self, tmp_path: Path) -> None:
        from owlmind.session_runner import _mark_skipped

        meta = _make_meta(goals=[_make_goal("g1")])

        existing = MagicMock()
        existing.status = "pending"
        existing.ended_at = None
        run_map: dict[str, MagicMock] = {"g1": existing}

        with (
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.save_session"),
        ):
            _mark_skipped(meta, run_map, "g1", "sess-test", tmp_path)

        assert existing.status == "skipped"
        assert existing.ended_at is not None


# ---------------------------------------------------------------------------
# Tests: _build_next_commands - SESSION_RUNNING/STOPPED branch (line 758)
# ---------------------------------------------------------------------------


class TestBuildNextCommandsRunning:
    """Cover the SESSION_RUNNING and SESSION_STOPPED branches."""

    def test_running_status_suggests_resume(self, tmp_path: Path) -> None:
        from owlmind.session import SESSION_RUNNING
        from owlmind.session_runner import _build_next_commands

        meta = _make_meta()
        meta.status = SESSION_RUNNING

        cmds = _build_next_commands(meta)

        assert any("resume" in cmd for cmd in cmds)

    def test_stopped_status_suggests_resume(self, tmp_path: Path) -> None:
        from owlmind.session import SESSION_STOPPED
        from owlmind.session_runner import _build_next_commands

        meta = _make_meta()
        meta.status = SESSION_STOPPED

        cmds = _build_next_commands(meta)

        assert any("resume" in cmd for cmd in cmds)


# ---------------------------------------------------------------------------
# Tests: session_runner._emit (lines 769-775)
# ---------------------------------------------------------------------------


class TestSessionRunnerEmit:
    """Cover the _emit helper in session_runner."""

    def test_emit_fires_callback(self) -> None:
        from owlmind.session_runner import _emit

        received: list[tuple[str, dict[str, str]]] = []
        _emit(lambda n, d: received.append((n, d)), "test_event", {"key": "val"})

        assert len(received) == 1
        assert received[0] == ("test_event", {"key": "val"})

    def test_emit_none_callback_does_nothing(self) -> None:
        from owlmind.session_runner import _emit

        # Should not raise
        _emit(None, "test_event", {"key": "val"})

    def test_emit_swallows_callback_exception(self) -> None:
        from owlmind.session_runner import _emit

        def bad_cb(name: str, data: dict[str, str]) -> None:
            msg = "boom"
            raise ValueError(msg)

        # Should not raise
        _emit(bad_cb, "test_event", {})


# ---------------------------------------------------------------------------
# Tests: parallel - blocked goal in results (lines 428-429)
# ---------------------------------------------------------------------------


class TestParallelBlockedGoalResult:
    """Cover the 'status == blocked' check in gather results."""

    def test_parallel_blocked_goal_sets_session_blocked(self, tmp_path: Path) -> None:
        with (
            patch("owlmind.session_runner.SessionLock") as MockLock,
            patch("owlmind.session_runner.load_session") as mock_load,
            patch("owlmind.session_runner.save_session"),
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.render_protocol"),
            patch("owlmind.session_runner.validate_dag"),
            patch("owlmind.session_runner.topological_layers", return_value=[["g1", "g2"]]),
            # g1 blocks, g2 succeeds
            patch(
                "owlmind.autopilot.run",
                side_effect=[_ap_result("WAIT_APPROVAL"), _ap_result("DONE")],
            ),
            patch("owlmind.autopilot.AutoPilotConfig"),
        ):
            MockLock.return_value.acquire.return_value = True
            goal1 = _make_goal("g1")
            goal2 = _make_goal("g2")
            meta = _make_meta(goals=[goal1, goal2], max_concurrency=2)
            mock_load.return_value = meta

            result = run_session(
                "sess-test",
                tmp_path,
                tmp_path,
                tmp_path,
                tmp_path,
                max_concurrency=2,
            )

        assert result.status == "BLOCKED"


class TestSequentialPreviouslyFailedNoContinue:
    """Lines 237-241: previously-failed goal with continue_on_fail=False stops session."""

    def test_failed_goal_stops_session(self, tmp_path: Path) -> None:
        goal = _make_goal("g-fail")
        meta = _make_meta(goals=[goal], continue_on_fail=False)

        # Mark the goal as already failed in runs
        run_mock = MagicMock()
        run_mock.goal_id = "g-fail"
        run_mock.run_id = "run-prev"
        run_mock.status = "failed"
        meta.runs = [run_mock]

        with (
            patch("owlmind.session_runner.SessionLock"),
            patch("owlmind.session_runner.load_session", return_value=meta),
            patch("owlmind.session_runner.save_session"),
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.render_protocol"),
            patch("owlmind.session_runner.validate_dag"),
            patch("owlmind.session_runner.topological_layers", return_value=[["g-fail"]]),
        ):
            result = run_session("sess-test", tmp_path, tmp_path, tmp_path, tmp_path)

        assert result.status in ("FAILED", "done", "failed")
        assert "g-fail" in (meta.last_block_reason or "")


class TestSequentialDepBlocked:
    """Line 262: dep blocked (not failed) → skip goal for now."""

    def test_blocked_dep_skips_goal(self, tmp_path: Path) -> None:
        g_dep = _make_goal("g-dep")
        g_main = _make_goal("g-main", depends_on=["g-dep"])
        meta = _make_meta(goals=[g_dep, g_main], continue_on_fail=False)

        # Mark g-dep as blocked (not failed, not done)
        run_dep = MagicMock()
        run_dep.goal_id = "g-dep"
        run_dep.run_id = "run-dep"
        run_dep.status = "blocked"
        meta.runs = [run_dep]

        with (
            patch("owlmind.session_runner.SessionLock"),
            patch("owlmind.session_runner.load_session", return_value=meta),
            patch("owlmind.session_runner.save_session"),
            patch("owlmind.session_runner.append_session_event"),
            patch("owlmind.session_runner.render_protocol"),
            patch("owlmind.session_runner.validate_dag"),
            # Only g-main in the layer; g-dep's "blocked" status appears as a dep
            patch("owlmind.session_runner.topological_layers", return_value=[["g-main"]]),
        ):
            result = run_session("sess-test", tmp_path, tmp_path, tmp_path, tmp_path)

        # g-main is skipped (dep blocked, not failed) → session finishes DONE
        assert result.status in ("BLOCKED", "DONE", "blocked", "done")
