"""Tests for owlmind.telegram.handlers_voice — voice message handling and /voice_mode command."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

# ── Helpers ──────────────────────────────────────────────────────────────────


def _make_bot_ctx(auto_graph_voice: bool = False) -> MagicMock:
    ctx = MagicMock()
    ctx.auto_graph_voice = auto_graph_voice
    ctx.allowed = []  # no allowlist → everyone allowed
    ctx.allowed_ids = []
    ctx.workspace = "."
    return ctx


def _make_voice_update(user_id: int = 42) -> MagicMock:
    update = MagicMock()
    msg = MagicMock()
    msg.reply_text = AsyncMock()
    msg.from_user = MagicMock()
    msg.from_user.id = user_id
    voice = MagicMock()
    voice.file_id = "file123"
    msg.voice = voice
    msg.audio = None
    update.message = msg
    update.effective_chat = MagicMock()
    update.effective_chat.id = user_id
    return update


def _make_cmd_update(user_id: int = 42, chat_id: int = 42) -> MagicMock:
    update = MagicMock()
    msg = MagicMock()
    msg.reply_text = AsyncMock()
    msg.from_user = MagicMock()
    msg.from_user.id = user_id
    update.message = msg
    update.effective_chat = MagicMock()
    update.effective_chat.id = chat_id
    return update


def _make_tg_context(args: list[str] | None = None) -> MagicMock:
    ctx = MagicMock()
    ctx.args = args or []
    bot = MagicMock()
    file_obj = MagicMock()
    file_obj.download_as_bytearray = AsyncMock(return_value=bytearray(b"ogg_bytes"))
    bot.get_file = AsyncMock(return_value=file_obj)
    ctx.bot = bot
    return ctx


# ── Test 1: voice_mode ON → GraphRunner is called after transcription ─────────


@pytest.mark.asyncio
async def test_voice_mode_on_calls_graph_runner() -> None:
    """When auto_graph_voice is True, GraphRunner.run() should be invoked."""
    from owlmind.telegram.handlers_voice import handle_voice_message

    bot_ctx = _make_bot_ctx(auto_graph_voice=True)
    update = _make_voice_update()
    tg_context = _make_tg_context()

    with (
        patch("owlmind.voice.is_available", return_value=True),
        patch(
            "owlmind.voice.transcribe_telegram_voice",
            new=AsyncMock(return_value="build a REST API"),
        ),
        patch("owlmind.graph.runner.GraphRunner") as MockRunner,
    ):
        mock_state = MagicMock()
        mock_state.final_verdict = "APPROVED"
        mock_state.review = "Looks good"
        MockRunner.return_value.run.return_value = mock_state

        await handle_voice_message(update, tg_context, bot_ctx)

    # GraphRunner.run should have been called
    MockRunner.return_value.run.assert_called_once()
    call_args = MockRunner.return_value.run.call_args
    assert "build a REST API" in call_args[0] or call_args[1].get("goal", "") or call_args[0][0]

    # The combined transcription+graph reply should have been sent
    reply_calls = [str(c) for c in update.message.reply_text.call_args_list]
    combined = " ".join(reply_calls)
    assert "build a REST API" in combined
    assert "Running graph" in combined or "graph" in combined.lower()


# ── Test 2: voice_mode OFF → GraphRunner is NOT called ───────────────────────


@pytest.mark.asyncio
async def test_voice_mode_off_no_graph_runner() -> None:
    """When auto_graph_voice is False (default), GraphRunner should not be invoked."""
    from owlmind.telegram.handlers_voice import handle_voice_message

    bot_ctx = _make_bot_ctx(auto_graph_voice=False)
    update = _make_voice_update()
    tg_context = _make_tg_context()

    with (
        patch("owlmind.voice.is_available", return_value=True),
        patch(
            "owlmind.voice.transcribe_telegram_voice",
            new=AsyncMock(return_value="hello world"),
        ),
        patch("owlmind.graph.runner.GraphRunner") as MockRunner,
    ):
        await handle_voice_message(update, tg_context, bot_ctx)

    # GraphRunner should NOT have been constructed or called
    MockRunner.assert_not_called()

    # Only a plain transcription reply should be sent (not the combined format)
    reply_calls = [str(c) for c in update.message.reply_text.call_args_list]
    combined = " ".join(reply_calls)
    assert "hello world" in combined
    assert "Running graph" not in combined


# ── Test 3: /voice_mode command toggles the flag ─────────────────────────────


@pytest.mark.asyncio
async def test_voice_mode_command_toggles_flag() -> None:
    """The /voice_mode command should toggle auto_graph_voice on BotContext."""
    from owlmind.telegram.handlers_voice import cmd_voice_mode

    # Start with auto_graph_voice = False
    bot_ctx = _make_bot_ctx(auto_graph_voice=False)

    # /voice_mode on
    update = _make_cmd_update()
    tg_context = _make_tg_context(args=["on"])
    await cmd_voice_mode(bot_ctx, update, tg_context)
    assert bot_ctx.auto_graph_voice is True
    update.message.reply_text.assert_called_once()
    reply_text = update.message.reply_text.call_args[0][0]
    assert "ON" in reply_text

    # /voice_mode off
    update2 = _make_cmd_update()
    tg_context2 = _make_tg_context(args=["off"])
    await cmd_voice_mode(bot_ctx, update2, tg_context2)
    assert bot_ctx.auto_graph_voice is False
    update2.message.reply_text.assert_called_once()
    reply_text2 = update2.message.reply_text.call_args[0][0]
    assert "OFF" in reply_text2

    # /voice_mode (no args) → show current status
    update3 = _make_cmd_update()
    tg_context3 = _make_tg_context(args=[])
    await cmd_voice_mode(bot_ctx, update3, tg_context3)
    update3.message.reply_text.assert_called_once()
    status_reply = update3.message.reply_text.call_args[0][0]
    assert "off" in status_reply.lower() or "Voice mode" in status_reply
