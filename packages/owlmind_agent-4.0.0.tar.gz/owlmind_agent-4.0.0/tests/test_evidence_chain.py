"""Tests for EvidenceStore — hash chain, manifest, and verification."""

from __future__ import annotations

import json
from pathlib import Path

from owlmind.evidence import EvidenceStore, canonical_json


class TestCanonicalJson:
    def test_sorted_keys(self) -> None:
        result = canonical_json({"z": 1, "a": 2})
        assert result == b'{"a":2,"z":1}'

    def test_no_spaces(self) -> None:
        result = canonical_json({"key": "value"})
        assert b" " not in result

    def test_deterministic(self) -> None:
        obj = {"b": [1, 2], "a": "hello"}
        assert canonical_json(obj) == canonical_json(obj)


class TestHashChain:
    def test_append_returns_hash(self, tmp_path: Path) -> None:
        store = EvidenceStore(tmp_path / "runs")
        store.create_run("r1")
        h = store.append_event("r1", {"event": "test", "data": "hello"})
        assert isinstance(h, str)
        assert len(h) == 64

    def test_chain_tip_genesis(self, tmp_path: Path) -> None:
        store = EvidenceStore(tmp_path / "runs")
        store.create_run("r1")
        tip_hash, seq = store.get_chain_tip("r1")
        assert tip_hash == "0" * 64
        assert seq == 0

    def test_chain_tip_after_events(self, tmp_path: Path) -> None:
        store = EvidenceStore(tmp_path / "runs")
        store.create_run("r1")
        h1 = store.append_event("r1", {"event": "e1"})
        h2 = store.append_event("r1", {"event": "e2"})
        tip_hash, seq = store.get_chain_tip("r1")
        assert tip_hash == h2
        assert seq == 2
        assert h1 != h2

    def test_events_have_chain_fields(self, tmp_path: Path) -> None:
        store = EvidenceStore(tmp_path / "runs")
        store.create_run("r1")
        store.append_event("r1", {"event": "e1"})
        store.append_event("r1", {"event": "e2"})

        events = store.read_events("r1")
        assert len(events) == 2

        assert events[0]["_seq"] == 1
        assert events[0]["_prev_hash"] == "0" * 64
        assert "_hash" in events[0]

        assert events[1]["_seq"] == 2
        assert events[1]["_prev_hash"] == events[0]["_hash"]

    def test_verify_chain_ok(self, tmp_path: Path) -> None:
        store = EvidenceStore(tmp_path / "runs")
        store.create_run("r1")
        store.append_event("r1", {"event": "start", "goal": "test"})
        store.append_event("r1", {"event": "planner_submitted", "plan": ["step1"]})
        store.append_event("r1", {"event": "worker_submitted"})

        result = store.verify_chain("r1")
        assert result.ok is True
        assert result.errors == []
        assert result.seq == 3
        assert len(result.tip_hash) == 64

    def test_verify_chain_tampered(self, tmp_path: Path) -> None:
        store = EvidenceStore(tmp_path / "runs")
        store.create_run("r1")
        store.append_event("r1", {"event": "e1"})
        store.append_event("r1", {"event": "e2"})
        store.append_event("r1", {"event": "e3"})

        # Tamper with line 2
        log_path = tmp_path / "runs" / "r1" / "run.jsonl"
        lines = log_path.read_text().splitlines()
        assert len(lines) == 3

        event2 = json.loads(lines[1])
        event2["event"] = "TAMPERED"
        lines[1] = json.dumps(event2, default=str)
        log_path.write_text("\n".join(lines) + "\n")

        result = store.verify_chain("r1")
        assert result.ok is False
        assert len(result.errors) > 0
        assert any("_hash mismatch" in e for e in result.errors)

    def test_verify_chain_missing_log(self, tmp_path: Path) -> None:
        store = EvidenceStore(tmp_path / "runs")
        store.create_run("r1")
        result = store.verify_chain("r1")
        assert result.ok is False
        assert any("not found" in e for e in result.errors)

    def test_verify_chain_broken_sequence(self, tmp_path: Path) -> None:
        store = EvidenceStore(tmp_path / "runs")
        store.create_run("r1")
        store.append_event("r1", {"event": "e1"})
        store.append_event("r1", {"event": "e2"})

        # Duplicate the first line (seq=1 repeated)
        log_path = tmp_path / "runs" / "r1" / "run.jsonl"
        lines = log_path.read_text().splitlines()
        lines[1] = lines[0]  # same seq=1
        log_path.write_text("\n".join(lines) + "\n")

        result = store.verify_chain("r1")
        assert result.ok is False


class TestManifest:
    def test_write_manifest(self, tmp_path: Path) -> None:
        store = EvidenceStore(tmp_path / "runs")
        store.create_run("r1")

        store.write_artifact("r1", "output.txt", "hello world")
        store.write_artifact("r1", "data.json", '{"key": "value"}')

        manifest = store.write_manifest("r1")
        assert manifest["run_id"] == "r1"
        assert manifest["artifact_count"] == 2
        assert len(manifest["artifacts"]) == 2
        assert "manifest_sha256" in manifest
        assert len(manifest["manifest_sha256"]) == 64

        # Manifest file should exist on disk
        manifest_path = tmp_path / "runs" / "r1" / "evidence" / "manifest.json"
        assert manifest_path.exists()

        # Should also log a MANIFEST_WRITTEN event
        events = store.read_events("r1")
        manifest_events = [e for e in events if e.get("event") == "MANIFEST_WRITTEN"]
        assert len(manifest_events) == 1
        assert manifest_events[0]["manifest_sha256"] == manifest["manifest_sha256"]

    def test_manifest_artifact_kind(self, tmp_path: Path) -> None:
        store = EvidenceStore(tmp_path / "runs")
        store.create_run("r1")

        store.write_artifact("r1", "readme.md", "# Hello")
        store.write_artifact("r1", "data.yaml", "key: val")
        store.write_artifact("r1", "image.png", b"\x89PNG")

        manifest = store.write_manifest("r1")
        by_name = {a["name"]: a for a in manifest["artifacts"]}
        assert by_name["readme.md"]["kind"] == "text"
        assert by_name["data.yaml"]["kind"] == "text"
        assert by_name["image.png"]["kind"] == "binary"

    def test_manifest_empty_artifacts(self, tmp_path: Path) -> None:
        store = EvidenceStore(tmp_path / "runs")
        store.create_run("r1")

        manifest = store.write_manifest("r1")
        assert manifest["artifact_count"] == 0
        assert manifest["artifacts"] == []


class TestWriteArtifact:
    def test_write_and_read(self, tmp_path: Path) -> None:
        store = EvidenceStore(tmp_path / "runs")
        store.create_run("r1")
        h = store.write_artifact("r1", "test.txt", "hello")
        assert len(h) == 64

        path = tmp_path / "runs" / "r1" / "artifacts" / "test.txt"
        assert path.read_text() == "hello"

    def test_write_bytes(self, tmp_path: Path) -> None:
        store = EvidenceStore(tmp_path / "runs")
        store.create_run("r1")
        store.write_artifact("r1", "binary.bin", b"\x00\x01\x02")

        path = tmp_path / "runs" / "r1" / "artifacts" / "binary.bin"
        assert path.read_bytes() == b"\x00\x01\x02"


class TestListRuns:
    def test_list_runs(self, tmp_path: Path) -> None:
        store = EvidenceStore(tmp_path / "runs")
        store.create_run("run-a")
        store.append_event("run-a", {"event": "start"})
        store.create_run("run-b")
        store.append_event("run-b", {"event": "start"})

        runs = store.list_runs()
        assert runs == ["run-a", "run-b"]

    def test_list_runs_empty(self, tmp_path: Path) -> None:
        store = EvidenceStore(tmp_path / "runs")
        assert store.list_runs() == []
