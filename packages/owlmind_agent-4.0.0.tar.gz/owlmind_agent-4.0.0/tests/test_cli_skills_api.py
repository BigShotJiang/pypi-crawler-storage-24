"""Tests for FS79 — CLI skills commands and API server command."""

from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from owlmind.cli import app

runner = CliRunner()


# ---------------------------------------------------------------------------
# skills list
# ---------------------------------------------------------------------------


class TestSkillsList:
    def test_list_empty(self) -> None:
        """skills list with no packs → 'No skill packs found' in output."""
        with patch("owlmind.cli.skills_cmd.list_packs", return_value=[]):
            result = runner.invoke(app, ["skills", "list"])

        assert result.exit_code == 0, result.output
        assert "No skill packs" in result.output

    def test_list_ok(self) -> None:
        """skills list with packs → exit 0, pack ID in output."""
        mock_packs = [
            {
                "id": "bugfix",
                "version": "1.0.0",
                "name": "Bug Fixer",
                "description": "Fixes bugs automatically",
                "tags": ["testing", "bugfix"],
            }
        ]

        with patch("owlmind.cli.skills_cmd.list_packs", return_value=mock_packs):
            result = runner.invoke(app, ["skills", "list"])

        assert result.exit_code == 0, result.output
        assert "bugfix" in result.output


# ---------------------------------------------------------------------------
# skills show
# ---------------------------------------------------------------------------


class TestSkillsShow:
    def test_show_ok(self, tmp_path: Path) -> None:
        """skills show <pack-id> → exit 0, pack details shown."""
        mock_pack = {
            "id": "bugfix",
            "name": "Bug Fixer",
            "version": "1.0.0",
            "description": "Fixes bugs automatically",
            "tags": ["testing"],
            "pack_dir": tmp_path,
            "knowledge_dir": "knowledge/bugfix",
        }

        with patch("owlmind.cli.skills_cmd.load_pack", return_value=mock_pack):
            result = runner.invoke(app, ["skills", "show", "bugfix"])

        assert result.exit_code == 0, result.output
        assert "Bug Fixer" in result.output
        assert "1.0.0" in result.output

    def test_show_not_found(self) -> None:
        """skills show unknown-pack → FileNotFoundError → exit 1."""
        with patch(
            "owlmind.cli.skills_cmd.load_pack",
            side_effect=FileNotFoundError("Pack 'unknown' not found"),
        ):
            result = runner.invoke(app, ["skills", "show", "unknown"])

        assert result.exit_code == 1
        assert "not found" in result.output.lower() or "error" in result.output.lower()


# ---------------------------------------------------------------------------
# skills install
# ---------------------------------------------------------------------------


class TestSkillsInstall:
    def test_install_ok(self, tmp_path: Path) -> None:
        """skills install <pack-id> → install succeeds → exit 0, 'Installed' in output."""
        install_result = {
            "pack_id": "bugfix",
            "ingested_docs": 3,
            "key_file_hashes": {"fix_pattern.py": "abc123"},
        }

        with (
            patch("owlmind.evidence.EvidenceStore"),
            patch("owlmind.memory.store.MemoryStore"),
            patch("owlmind.skills.installer.install", return_value=install_result),
        ):
            result = runner.invoke(
                app,
                [
                    "skills",
                    "install",
                    "bugfix",
                    "--workspace",
                    str(tmp_path),
                    "--runs",
                    str(tmp_path / "runs"),
                    "--memory-db",
                    str(tmp_path / "memory.db"),
                ],
            )

        assert result.exit_code == 0, result.output
        assert "Installed" in result.output
        assert "3" in result.output  # ingested_docs


# ---------------------------------------------------------------------------
# skills show — file listing and knowledge dir
# ---------------------------------------------------------------------------


class TestSkillsShowFiles:
    def test_show_lists_files_in_pack_dir(self, tmp_path: Path) -> None:
        """skills show lists files inside pack_dir (lines 76-78)."""
        pack_dir = tmp_path / "skill-packs" / "bugfix"
        pack_dir.mkdir(parents=True)
        (pack_dir / "prompt.md").write_text("# Prompt")
        (pack_dir / "config.yaml").write_text("key: val")

        mock_pack = {
            "id": "bugfix",
            "name": "Bug Fixer",
            "version": "1.0.0",
            "description": "Fixes bugs",
            "tags": [],
            "pack_dir": pack_dir,
            "knowledge_dir": "knowledge/bugfix",
        }

        with patch("owlmind.cli.skills_cmd.load_pack", return_value=mock_pack):
            result = runner.invoke(app, ["skills", "show", "bugfix"])

        assert result.exit_code == 0, result.output
        assert "prompt.md" in result.output
        assert "config.yaml" in result.output

    def test_show_lists_knowledge_dir_files(self, tmp_path: Path) -> None:
        """skills show lists knowledge dir when it exists (lines 84-87).

        repo_root = pack_dir.parent.parent = tmp_path
        """
        pack_dir = tmp_path / "skill-packs" / "bugfix"
        pack_dir.mkdir(parents=True)
        (pack_dir / "skill.yaml").write_text("name: bugfix")

        knowledge_dir = tmp_path / "knowledge" / "bugfix"
        knowledge_dir.mkdir(parents=True)
        (knowledge_dir / "patterns.md").write_text("# Patterns")
        (knowledge_dir / "examples.md").write_text("# Examples")

        mock_pack = {
            "id": "bugfix",
            "name": "Bug Fixer",
            "version": "1.0.0",
            "description": "Fixes bugs",
            "tags": [],
            "pack_dir": pack_dir,
            "knowledge_dir": "knowledge/bugfix",
        }

        with patch("owlmind.cli.skills_cmd.load_pack", return_value=mock_pack):
            result = runner.invoke(app, ["skills", "show", "bugfix"])

        assert result.exit_code == 0, result.output
        assert "Knowledge" in result.output
        assert "patterns.md" in result.output
        assert "examples.md" in result.output


# ---------------------------------------------------------------------------
# skills install — edge cases
# ---------------------------------------------------------------------------


class TestSkillsInstallEdgeCases:
    def test_install_memory_store_failure_warns_and_continues(self, tmp_path: Path) -> None:
        """MemoryStore init failure warns but install still completes (lines 116-117)."""
        install_result = {
            "pack_id": "bugfix",
            "ingested_docs": 0,
            "key_file_hashes": {},
        }

        with (
            patch("owlmind.evidence.EvidenceStore"),
            patch(
                "owlmind.memory.store.MemoryStore",
                side_effect=Exception("DB locked"),
            ),
            patch("owlmind.skills.installer.install", return_value=install_result),
        ):
            result = runner.invoke(
                app,
                [
                    "skills",
                    "install",
                    "bugfix",
                    "--workspace",
                    str(tmp_path),
                    "--runs",
                    str(tmp_path / "runs"),
                    "--memory-db",
                    str(tmp_path / "memory.db"),
                ],
            )

        assert result.exit_code == 0, result.output
        assert "Warning" in result.output or "warning" in result.output.lower()
        assert "Installed" in result.output

    def test_install_not_found_exits_1(self, tmp_path: Path) -> None:
        """install() FileNotFoundError → exit code 1 (lines 134-136)."""
        with (
            patch("owlmind.evidence.EvidenceStore"),
            patch("owlmind.memory.store.MemoryStore"),
            patch(
                "owlmind.skills.installer.install",
                side_effect=FileNotFoundError("Pack 'nope' not found"),
            ),
        ):
            result = runner.invoke(
                app,
                [
                    "skills",
                    "install",
                    "nope",
                    "--workspace",
                    str(tmp_path),
                    "--runs",
                    str(tmp_path / "runs"),
                    "--memory-db",
                    str(tmp_path / "memory.db"),
                    "--no-memory",
                ],
            )

        assert result.exit_code == 1
        assert "nope" in result.output or "not found" in result.output.lower()


# ---------------------------------------------------------------------------
# api serve
# ---------------------------------------------------------------------------


class TestApiServe:
    def test_serve_no_uvicorn(self) -> None:
        """api serve → uvicorn not installed → exit 1, message shown."""
        with patch.dict(sys.modules, {"uvicorn": None}):
            result = runner.invoke(app, ["api", "serve"])

        assert result.exit_code == 1
        assert "uvicorn" in result.output.lower()

    def test_serve_no_fastapi(self) -> None:
        """api serve → uvicorn ok, fastapi missing → exit 1, message shown."""
        mock_uvicorn = MagicMock()

        # Simulate owlmind.api.app not importable (fastapi missing)
        with patch.dict(sys.modules, {"uvicorn": mock_uvicorn, "owlmind.api.app": None}):
            result = runner.invoke(app, ["api", "serve"])

        assert result.exit_code == 1
        assert "fastapi" in result.output.lower()

    def test_serve_ok(self) -> None:
        """api serve → uvicorn + fastapi ok → uvicorn.run called → exit 0."""
        mock_uvicorn = MagicMock()
        mock_app = MagicMock()

        with (
            patch.dict(sys.modules, {"uvicorn": mock_uvicorn}),
            patch("owlmind.api.app.create_app", return_value=mock_app),
        ):
            result = runner.invoke(app, ["api", "serve"])

        assert result.exit_code == 0, result.output
        mock_uvicorn.run.assert_called_once()
