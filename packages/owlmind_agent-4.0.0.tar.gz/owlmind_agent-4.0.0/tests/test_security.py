"""Tests for security module — secret scanning, path validation, git hooks."""

from __future__ import annotations

from pathlib import Path

import pytest

from owlmind.security import (
    generate_pre_commit_hook,
    install_hooks,
    scan_secrets,
    validate_path_within,
    validate_workspace_path,
)


class TestSecretScanner:
    def test_clean_directory(self, tmp_path: Path) -> None:
        (tmp_path / "hello.py").write_text('print("hello world")\n')
        result = scan_secrets(tmp_path)
        assert result.ok
        assert result.files_scanned == 1
        assert result.findings == []

    def test_detects_aws_key(self, tmp_path: Path) -> None:
        (tmp_path / "config.py").write_text('AWS_KEY = "AKIAIOSFODNN7EXAMPLE"\n')
        result = scan_secrets(tmp_path)
        assert not result.ok
        assert len(result.findings) == 1
        assert result.findings[0].pattern_name == "AWS Access Key"

    def test_detects_github_token(self, tmp_path: Path) -> None:
        (tmp_path / "env.sh").write_text(
            "export GITHUB_TOKEN=ghp_aBcDeFgHiJkLmNoPqRsTuVwXyZ0123456789\n",
        )
        result = scan_secrets(tmp_path)
        assert not result.ok
        assert any(f.pattern_name == "GitHub Token" for f in result.findings)

    def test_detects_private_key(self, tmp_path: Path) -> None:
        (tmp_path / "key.pem").write_text(
            "-----BEGIN RSA PRIVATE KEY-----\nbase64data\n-----END RSA PRIVATE KEY-----\n",
        )
        result = scan_secrets(tmp_path)
        assert not result.ok
        assert any(f.pattern_name == "Private Key Block" for f in result.findings)

    def test_detects_generic_api_key(self, tmp_path: Path) -> None:
        (tmp_path / "app.cfg").write_text(
            'api_key = "abcdefghijklmnopqrstuvwxyz"\n',
        )
        result = scan_secrets(tmp_path)
        assert not result.ok
        assert any(f.pattern_name == "Generic API Key" for f in result.findings)

    def test_detects_openai_key(self, tmp_path: Path) -> None:
        (tmp_path / ".env").write_text(
            "OPENAI_API_KEY=sk-abcdefghijklmnopqrstuvwxyz12345\n",
        )
        result = scan_secrets(tmp_path)
        assert not result.ok
        assert any(f.pattern_name == "OpenAI API Key" for f in result.findings)

    def test_skips_binary_files(self, tmp_path: Path) -> None:
        (tmp_path / "image.png").write_bytes(b"\x89PNG\r\n")
        result = scan_secrets(tmp_path)
        assert result.files_scanned == 0

    def test_skips_large_files(self, tmp_path: Path) -> None:
        big = tmp_path / "big.txt"
        big.write_text("x" * 600_000)
        result = scan_secrets(tmp_path, max_file_size=500_000)
        assert result.files_scanned == 0

    def test_skips_git_dir(self, tmp_path: Path) -> None:
        git_dir = tmp_path / ".git" / "objects"
        git_dir.mkdir(parents=True)
        (git_dir / "secret.txt").write_text("AKIAIOSFODNN7EXAMPLE")
        result = scan_secrets(tmp_path)
        assert result.ok

    def test_extra_patterns(self, tmp_path: Path) -> None:
        (tmp_path / "custom.txt").write_text("CUSTOM_SECRET_12345\n")
        result = scan_secrets(
            tmp_path,
            extra_patterns=[("Custom", r"CUSTOM_SECRET_\d+")],
        )
        assert not result.ok
        assert result.findings[0].pattern_name == "Custom"

    def test_finding_includes_line_number(self, tmp_path: Path) -> None:
        (tmp_path / "multi.txt").write_text(
            "line1\nline2\nAKIAIOSFODNN7EXAMPLE\nline4\n",
        )
        result = scan_secrets(tmp_path)
        assert result.findings[0].line == 3

    def test_multiple_findings(self, tmp_path: Path) -> None:
        (tmp_path / "bad.py").write_text(
            'key1 = "AKIAIOSFODNN7EXAMPLE"\nkey2 = "ghp_aBcDeFgHiJkLmNoPqRsTuVwXyZ0123456789"\n',
        )
        result = scan_secrets(tmp_path)
        assert len(result.findings) >= 2

    def test_empty_directory(self, tmp_path: Path) -> None:
        result = scan_secrets(tmp_path)
        assert result.ok
        assert result.files_scanned == 0

    def test_detects_telegram_token(self, tmp_path: Path) -> None:
        (tmp_path / "config.txt").write_text(
            "BOT_TOKEN=8522846320:AAGWpv5pxcs6xKwqhKkqh_jO3rPTOF0VlFQ\n",
        )
        result = scan_secrets(tmp_path)
        assert not result.ok
        assert any(f.pattern_name == "Telegram Bot Token" for f in result.findings)

    def test_detects_gemini_key(self, tmp_path: Path) -> None:
        (tmp_path / ".env").write_text(
            "GEMINI_KEY=AIzaSyDKaBEWfu779Z3TkAv6oeskLO2R-s5NWsk\n",
        )
        result = scan_secrets(tmp_path)
        assert not result.ok
        assert any(f.pattern_name == "Google/Gemini API Key" for f in result.findings)

    def test_scans_nested_run_dirs(self, tmp_path: Path) -> None:
        """Scanner must reach into runs/ and sessions/ subdirectories."""
        runs_dir = tmp_path / "runs" / "abc123"
        runs_dir.mkdir(parents=True)
        (runs_dir / "report.md").write_text(
            "token: 1234567890:ABCDEFghijklmnopqrstuvwxyz012345678\n",
        )
        sessions_dir = tmp_path / "sessions" / "s1"
        sessions_dir.mkdir(parents=True)
        (sessions_dir / "log.txt").write_text(
            "export KEY=AIzaSyDKaBEWfu779Z3TkAv6oeskLO2R-s5NWsk\n",
        )
        result = scan_secrets(tmp_path)
        assert not result.ok
        assert len(result.findings) >= 2


class TestPathValidation:
    def test_within(self, tmp_path: Path) -> None:
        child = tmp_path / "sub" / "file.txt"
        assert validate_path_within(child, tmp_path) is True

    def test_outside(self, tmp_path: Path) -> None:
        other = Path("/etc/passwd")
        assert validate_path_within(other, tmp_path) is False

    def test_traversal_blocked(self, tmp_path: Path) -> None:
        sneaky = tmp_path / "sub" / ".." / ".." / "etc" / "passwd"
        assert validate_path_within(sneaky, tmp_path) is False

    def test_workspace_path_valid(self) -> None:
        assert validate_workspace_path("/home/user/project") is True

    def test_workspace_path_traversal(self) -> None:
        assert validate_workspace_path("/home/../etc") is False

    def test_workspace_path_null_byte(self) -> None:
        assert validate_workspace_path("/home/\x00evil") is False


class TestGitHooks:
    def test_generate_pre_commit(self, tmp_path: Path) -> None:
        hooks_dir = tmp_path / ".git" / "hooks"
        hooks_dir.mkdir(parents=True)

        hook = generate_pre_commit_hook(tmp_path)
        assert hook.exists()
        assert hook.name == "pre-commit"
        content = hook.read_text()
        assert "OWLMIND" in content
        assert "secret scan" in content.lower()
        # Check executable
        assert hook.stat().st_mode & 0o111

    def test_no_git_dir(self, tmp_path: Path) -> None:
        with pytest.raises(FileNotFoundError, match="Not a git"):
            generate_pre_commit_hook(tmp_path)

    def test_install_hooks(self, tmp_path: Path) -> None:
        hooks_dir = tmp_path / ".git" / "hooks"
        hooks_dir.mkdir(parents=True)

        installed = install_hooks(tmp_path)
        assert len(installed) == 1
        assert "pre-commit" in installed[0]


class TestScanSecretsErrorHandling:
    def test_oserror_on_read_is_skipped(self, tmp_path: Path) -> None:
        """OSError raised during file read must be silently skipped (lines 120-121)."""
        from unittest.mock import patch

        # Create a real .txt file so it passes extension, size, and is_file() checks
        target = tmp_path / "readable.txt"
        target.write_text("harmless content\n")

        original_read_text = Path.read_text

        def fake_read_text(self: Path, **kwargs: object) -> str:  # type: ignore[override]
            if self == target:
                raise OSError("Permission denied")
            return original_read_text(self, **kwargs)

        with patch.object(Path, "read_text", fake_read_text):
            result = scan_secrets(tmp_path)

        # File was counted (files_scanned incremented before read), no findings
        assert result.files_scanned == 1
        assert result.findings == []
        assert result.ok


class TestValidatePathWithinExceptionPath:
    def test_oserror_raises_returns_false(self, tmp_path: Path) -> None:
        """OSError or ValueError during path.resolve() must return False (lines 151-152)."""
        from unittest.mock import patch

        child = tmp_path / "sub" / "file.txt"

        # Patch Path.resolve to raise OSError on the call for 'child'
        original_resolve = Path.resolve

        def fake_resolve(self: Path, **kwargs: object) -> Path:
            if self == child:
                raise OSError("resolve failed")
            return original_resolve(self, **kwargs)

        with patch.object(Path, "resolve", fake_resolve):
            result = validate_path_within(child, tmp_path)

        assert result is False

    def test_value_error_returns_false(self, tmp_path: Path) -> None:
        """ValueError during path resolution must return False (lines 151-152)."""
        from unittest.mock import patch

        child = tmp_path / "some" / "path.txt"

        original_resolve = Path.resolve

        def fake_resolve(self: Path, **kwargs: object) -> Path:
            if self == child:
                raise ValueError("bad path")
            return original_resolve(self, **kwargs)

        with patch.object(Path, "resolve", fake_resolve):
            result = validate_path_within(child, tmp_path)

        assert result is False


# ---------------------------------------------------------------------------
# Master password check
# ---------------------------------------------------------------------------


class TestCheckMasterPassword:
    """Tests for check_master_password()."""

    def test_skip_flag_bypasses_check(self, monkeypatch):
        """OWLMIND_SKIP_PASSWORD_CHECK=1 skips the check entirely."""
        monkeypatch.setenv("OWLMIND_SKIP_PASSWORD_CHECK", "1")
        monkeypatch.delenv("OWLMIND_MASTER_PASSWORD", raising=False)
        from owlmind.security import check_master_password

        check_master_password()

    def test_correct_password_passes(self, monkeypatch):
        """Correct OWLMIND_MASTER_PASSWORD passes without error."""
        monkeypatch.delenv("OWLMIND_SKIP_PASSWORD_CHECK", raising=False)
        monkeypatch.setenv("OWLMIND_MASTER_PASSWORD", "20210428AnXiaYasminaJon@")
        from owlmind.security import check_master_password

        check_master_password()

    def test_missing_password_exits(self, monkeypatch):
        """Missing OWLMIND_MASTER_PASSWORD causes SystemExit(1)."""
        monkeypatch.delenv("OWLMIND_SKIP_PASSWORD_CHECK", raising=False)
        monkeypatch.delenv("OWLMIND_MASTER_PASSWORD", raising=False)
        from owlmind.security import check_master_password

        with pytest.raises(SystemExit) as exc_info:
            check_master_password()
        assert exc_info.value.code == 1

    def test_wrong_password_exits(self, monkeypatch):
        """Wrong OWLMIND_MASTER_PASSWORD causes SystemExit(1)."""
        monkeypatch.delenv("OWLMIND_SKIP_PASSWORD_CHECK", raising=False)
        monkeypatch.setenv("OWLMIND_MASTER_PASSWORD", "wrong-password-123")
        from owlmind.security import check_master_password

        with pytest.raises(SystemExit) as exc_info:
            check_master_password()
        assert exc_info.value.code == 1

    def test_empty_string_exits(self, monkeypatch):
        """Empty string OWLMIND_MASTER_PASSWORD is treated as missing."""
        monkeypatch.delenv("OWLMIND_SKIP_PASSWORD_CHECK", raising=False)
        monkeypatch.setenv("OWLMIND_MASTER_PASSWORD", "")
        from owlmind.security import check_master_password

        with pytest.raises(SystemExit) as exc_info:
            check_master_password()
        assert exc_info.value.code == 1

    def test_skip_flag_zero_does_not_skip(self, monkeypatch):
        """OWLMIND_SKIP_PASSWORD_CHECK=0 does NOT skip the check."""
        monkeypatch.setenv("OWLMIND_SKIP_PASSWORD_CHECK", "0")
        monkeypatch.delenv("OWLMIND_MASTER_PASSWORD", raising=False)
        from owlmind.security import check_master_password

        with pytest.raises(SystemExit):
            check_master_password()

    def test_error_message_on_wrong_password(self, monkeypatch, capsys):
        """Wrong password prints an error message to stderr."""
        monkeypatch.delenv("OWLMIND_SKIP_PASSWORD_CHECK", raising=False)
        monkeypatch.setenv("OWLMIND_MASTER_PASSWORD", "bad-password")
        from owlmind.security import check_master_password

        with pytest.raises(SystemExit):
            check_master_password()
        captured = capsys.readouterr()
        assert "denied" in captured.err.lower() or "invalid" in captured.err.lower()

    def test_error_message_on_missing_password(self, monkeypatch, capsys):
        """Missing password prints an error message to stderr."""
        monkeypatch.delenv("OWLMIND_SKIP_PASSWORD_CHECK", raising=False)
        monkeypatch.delenv("OWLMIND_MASTER_PASSWORD", raising=False)
        from owlmind.security import check_master_password

        with pytest.raises(SystemExit):
            check_master_password()
        captured = capsys.readouterr()
        assert "denied" in captured.err.lower() or "not set" in captured.err.lower()
