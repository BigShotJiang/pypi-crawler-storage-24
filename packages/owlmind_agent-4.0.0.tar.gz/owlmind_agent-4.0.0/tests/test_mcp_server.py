"""Tests for owlmind.mcp.server — MCP server JSON-RPC protocol."""

from __future__ import annotations

import io
import json
from pathlib import Path
from unittest.mock import MagicMock, patch

from owlmind.mcp.server import TOOLS, MCPServer, _get_version


class TestInitialize:
    def test_returns_protocol_version(self) -> None:
        server = MCPServer()
        resp = server.handle_one({"jsonrpc": "2.0", "method": "initialize", "params": {}, "id": 1})
        assert resp is not None
        assert resp["result"]["protocolVersion"] == "2024-11-05"

    def test_returns_capabilities(self) -> None:
        server = MCPServer()
        resp = server.handle_one({"jsonrpc": "2.0", "method": "initialize", "params": {}, "id": 1})
        assert resp is not None
        assert "tools" in resp["result"]["capabilities"]

    def test_returns_server_info(self) -> None:
        server = MCPServer()
        resp = server.handle_one({"jsonrpc": "2.0", "method": "initialize", "params": {}, "id": 1})
        assert resp is not None
        assert resp["result"]["serverInfo"]["name"] == "owlmind"


class TestToolsList:
    def test_returns_tools(self) -> None:
        server = MCPServer()
        resp = server.handle_one({"jsonrpc": "2.0", "method": "tools/list", "params": {}, "id": 2})
        assert resp is not None
        assert len(resp["result"]["tools"]) == 21

    def test_all_tool_names_present(self) -> None:
        names = {t["name"] for t in TOOLS}
        expected = {
            "owlmind_doctor",
            "owlmind_cost_estimate",
            "owlmind_memory_query",
            "owlmind_run",
            "owlmind_status",
            "owlmind_events",
            "owlmind_queue_add",
            "owlmind_session_start",
            "owlmind_skill_run",
            "owlmind_vision_screenshot",
            "owlmind_vision_analyze",
            "owlmind_vision_run",
            "owlmind_browser_search",
            "owlmind_browser_fetch",
            "owlmind_ast_map",
            "owlmind_ast_analyze",
            "owlmind_self_improve_analyze",
            "owlmind_multi_repo_scan",
            "owlmind_diff_review",
            "owlmind_provider_health",
            "owlmind_marketplace_search",
        }
        assert names == expected

    def test_tool_schemas_valid(self) -> None:
        for tool in TOOLS:
            assert "name" in tool
            assert "description" in tool
            assert "inputSchema" in tool
            assert tool["inputSchema"]["type"] == "object"


class TestToolsCall:
    def test_unknown_tool_returns_error(self) -> None:
        server = MCPServer()
        resp = server.handle_one(
            {
                "jsonrpc": "2.0",
                "method": "tools/call",
                "params": {"name": "unknown_tool", "arguments": {}},
                "id": 3,
            }
        )
        assert resp is not None
        assert resp["result"]["isError"] is True
        assert "Unknown tool" in resp["result"]["content"][0]["text"]

    @patch("owlmind.mcp.server._tool_cost_estimate")
    def test_cost_estimate_dispatches(self, mock_cost: MagicMock) -> None:
        mock_cost.return_value = {"estimated_usd_low": 0.01}
        server = MCPServer()
        resp = server.handle_one(
            {
                "jsonrpc": "2.0",
                "method": "tools/call",
                "params": {"name": "owlmind_cost_estimate", "arguments": {"goal": "test"}},
                "id": 4,
            }
        )
        assert resp is not None
        assert "isError" not in resp["result"]
        mock_cost.assert_called_once()

    def test_run_starts_cycle(self, tmp_path: Path) -> None:
        (tmp_path / "policies").mkdir()
        server = MCPServer()
        mock_meta = MagicMock()
        mock_meta.run_id = "mcp-test-001"
        mock_meta.state.value = "STARTED_WAIT_PLANNER"
        with patch("owlmind.agent.cycle.CycleManager") as MockMgr:
            MockMgr.return_value.start.return_value = mock_meta
            resp = server.handle_one(
                {
                    "jsonrpc": "2.0",
                    "method": "tools/call",
                    "params": {
                        "name": "owlmind_run",
                        "arguments": {"goal": "test goal", "workspace": str(tmp_path)},
                    },
                    "id": 5,
                }
            )
        assert resp is not None
        content = json.loads(resp["result"]["content"][0]["text"])
        assert content["status"] == "started"
        assert content["run_id"] == "mcp-test-001"

    def test_run_missing_goal_returns_error(self) -> None:
        server = MCPServer()
        resp = server.handle_one(
            {
                "jsonrpc": "2.0",
                "method": "tools/call",
                "params": {"name": "owlmind_run", "arguments": {"workspace": "."}},
                "id": 5,
            }
        )
        assert resp is not None
        content = json.loads(resp["result"]["content"][0]["text"])
        assert content["status"] == "failed"
        assert "goal" in content["error"]

    def test_status_not_found(self, tmp_path: Path) -> None:
        server = MCPServer()
        resp = server.handle_one(
            {
                "jsonrpc": "2.0",
                "method": "tools/call",
                "params": {
                    "name": "owlmind_status",
                    "arguments": {"run_id": "nonexistent", "workspace": str(tmp_path)},
                },
                "id": 6,
            }
        )
        assert resp is not None
        content = json.loads(resp["result"]["content"][0]["text"])
        assert "error" in content

    def test_events_returns_events(self, tmp_path: Path) -> None:
        """owlmind_events returns events list when EvidenceStore has data."""
        server = MCPServer()
        mock_events = [
            {"event": "step_one", "data": "hello", "_hash": "aaa", "_prev": ""},
            {"event": "step_two", "data": "world", "_hash": "bbb", "_prev": "aaa"},
        ]
        with patch("owlmind.evidence.EvidenceStore.read_events", return_value=mock_events):
            resp = server.handle_one(
                {
                    "jsonrpc": "2.0",
                    "method": "tools/call",
                    "params": {
                        "name": "owlmind_events",
                        "arguments": {"run_id": "run-123", "workspace": str(tmp_path), "limit": 10},
                    },
                    "id": 9,
                }
            )
        assert resp is not None
        content = json.loads(resp["result"]["content"][0]["text"])
        assert "events" in content
        assert content["total_events"] == 2
        # Private fields (_hash, _prev) must be stripped
        for evt in content["events"]:
            assert all(not k.startswith("_") for k in evt)

    def test_events_run_not_found(self, tmp_path: Path) -> None:
        """owlmind_events returns error dict (not isError) when run doesn't exist."""
        server = MCPServer()
        resp = server.handle_one(
            {
                "jsonrpc": "2.0",
                "method": "tools/call",
                "params": {
                    "name": "owlmind_events",
                    "arguments": {"run_id": "ghost-run-999", "workspace": str(tmp_path)},
                },
                "id": 10,
            }
        )
        assert resp is not None
        assert "isError" not in resp["result"]
        content = json.loads(resp["result"]["content"][0]["text"])
        assert "error" in content
        assert content["run_id"] == "ghost-run-999"

    def test_memory_query_no_db(self, tmp_path: Path) -> None:
        server = MCPServer()
        resp = server.handle_one(
            {
                "jsonrpc": "2.0",
                "method": "tools/call",
                "params": {
                    "name": "owlmind_memory_query",
                    "arguments": {"query": "test", "workspace": str(tmp_path)},
                },
                "id": 7,
            }
        )
        assert resp is not None
        content = json.loads(resp["result"]["content"][0]["text"])
        assert content["results"] == []

    @patch("owlmind.mcp.server._tool_doctor")
    def test_tool_exception_returns_error(self, mock_doctor: MagicMock) -> None:
        mock_doctor.side_effect = RuntimeError("doctor failed")
        server = MCPServer()
        resp = server.handle_one(
            {
                "jsonrpc": "2.0",
                "method": "tools/call",
                "params": {"name": "owlmind_doctor", "arguments": {"workspace": "."}},
                "id": 8,
            }
        )
        assert resp is not None
        assert resp["result"]["isError"] is True
        assert "doctor failed" in resp["result"]["content"][0]["text"]


class TestNotifications:
    def test_notification_returns_none(self) -> None:
        server = MCPServer()
        resp = server.handle_one(
            {"jsonrpc": "2.0", "method": "notifications/initialized", "params": {}}
        )
        assert resp is None

    def test_unknown_notification_returns_none(self) -> None:
        server = MCPServer()
        resp = server.handle_one({"jsonrpc": "2.0", "method": "unknown/notification", "params": {}})
        assert resp is None


class TestMethodNotFound:
    def test_unknown_method_returns_error(self) -> None:
        server = MCPServer()
        resp = server.handle_one(
            {"jsonrpc": "2.0", "method": "bogus/method", "params": {}, "id": 10}
        )
        assert resp is not None
        assert resp["error"]["code"] == -32601
        assert "Method not found" in resp["error"]["message"]


class TestToolDoctorDirect:
    @patch("owlmind.diag.build_diag_report")
    def test_doctor_calls_diag(self, mock_diag: MagicMock) -> None:
        mock_diag.return_value = "/tmp/report.json"
        server = MCPServer()
        resp = server.handle_one(
            {
                "jsonrpc": "2.0",
                "method": "tools/call",
                "params": {"name": "owlmind_doctor", "arguments": {"workspace": "/ws"}},
                "id": 20,
            }
        )
        assert resp is not None
        content = json.loads(resp["result"]["content"][0]["text"])
        assert content["status"] == "ok"
        mock_diag.assert_called_once_with("/ws")

    @patch("owlmind.diag.build_diag_report")
    def test_doctor_default_workspace(self, mock_diag: MagicMock) -> None:
        mock_diag.return_value = "/tmp/report.json"
        server = MCPServer()
        resp = server.handle_one(
            {
                "jsonrpc": "2.0",
                "method": "tools/call",
                "params": {"name": "owlmind_doctor", "arguments": {}},
                "id": 21,
            }
        )
        assert resp is not None
        content = json.loads(resp["result"]["content"][0]["text"])
        assert content["status"] == "ok"


class TestToolCostEstimateDirect:
    @patch("owlmind.cost.estimate_goal")
    @patch("owlmind.config.OwlMindConfig.from_env")
    def test_cost_estimate_calls_estimator(
        self, mock_from_env: MagicMock, mock_est: MagicMock
    ) -> None:
        mock_cfg = MagicMock()
        mock_from_env.return_value = mock_cfg
        mock_result = MagicMock()
        mock_result.to_dict.return_value = {"low": 0.01, "high": 0.05}
        mock_est.return_value = mock_result
        server = MCPServer()
        resp = server.handle_one(
            {
                "jsonrpc": "2.0",
                "method": "tools/call",
                "params": {
                    "name": "owlmind_cost_estimate",
                    "arguments": {
                        "goal": "test goal",
                        "provider": "anthropic",
                        "iterations": 3,
                    },
                },
                "id": 22,
            }
        )
        assert resp is not None
        content = json.loads(resp["result"]["content"][0]["text"])
        assert "low" in content
        mock_est.assert_called_once()


class TestToolStatusDirect:
    def test_status_found(self, tmp_path: Path) -> None:
        run_dir = tmp_path / "runs" / "run-123"
        run_dir.mkdir(parents=True)
        meta = {"state": "DONE", "goal": "test", "iteration": 3}
        (run_dir / "meta.json").write_text(json.dumps(meta))
        server = MCPServer()
        resp = server.handle_one(
            {
                "jsonrpc": "2.0",
                "method": "tools/call",
                "params": {
                    "name": "owlmind_status",
                    "arguments": {"run_id": "run-123", "workspace": str(tmp_path)},
                },
                "id": 23,
            }
        )
        assert resp is not None
        content = json.loads(resp["result"]["content"][0]["text"])
        assert content["state"] == "DONE"
        assert content["run_id"] == "run-123"


class TestToolMemoryQueryDirect:
    @patch("owlmind.memory.retrieval.query")
    @patch("owlmind.memory.store.MemoryStore")
    def test_query_with_results(
        self, mock_store_cls: MagicMock, mock_query: MagicMock, tmp_path: Path
    ) -> None:
        db_path = tmp_path / ".owlmind" / "memory.db"
        db_path.parent.mkdir(parents=True)
        db_path.write_text("")
        result = MagicMock()
        result.source = "file.py"
        result.score = 0.95
        result.snippet = "def foo():"
        mock_query.return_value = [result]
        server = MCPServer()
        resp = server.handle_one(
            {
                "jsonrpc": "2.0",
                "method": "tools/call",
                "params": {
                    "name": "owlmind_memory_query",
                    "arguments": {"query": "foo", "workspace": str(tmp_path), "top_k": 3},
                },
                "id": 24,
            }
        )
        assert resp is not None
        content = json.loads(resp["result"]["content"][0]["text"])
        assert len(content["results"]) == 1
        assert content["results"][0]["source"] == "file.py"


class TestGetVersionEdge:
    def test_version_returns_string(self) -> None:
        version = _get_version()
        assert isinstance(version, str)
        assert version != ""


class TestHandleRequestException:
    def test_handler_exception_returns_internal_error(self) -> None:
        server = MCPServer()
        # Patch _handle_initialize to raise
        server._handlers["initialize"] = lambda p: (_ for _ in ()).throw(RuntimeError("boom"))
        resp = server.handle_one({"jsonrpc": "2.0", "method": "initialize", "params": {}, "id": 30})
        assert resp is not None
        assert resp["error"]["code"] == -32603
        assert "boom" in resp["error"]["message"]


class TestServerVersion:
    def test_version_matches_package(self) -> None:
        from owlmind import __version__

        assert _get_version() == __version__


class TestServeForever:
    def test_basic_serve(self) -> None:
        req = json.dumps({"jsonrpc": "2.0", "method": "initialize", "params": {}, "id": 1})
        inp = io.StringIO(req + "\n")
        out = io.StringIO()
        server = MCPServer(input_stream=inp, output_stream=out)
        server.serve_forever()
        output = out.getvalue().strip()
        resp = json.loads(output)
        assert resp["id"] == 1
        assert "result" in resp

    def test_empty_lines_ignored(self) -> None:
        inp = io.StringIO("\n\n\n")
        out = io.StringIO()
        server = MCPServer(input_stream=inp, output_stream=out)
        server.serve_forever()
        assert out.getvalue() == ""

    def test_invalid_json_returns_parse_error(self) -> None:
        inp = io.StringIO("not json\n")
        out = io.StringIO()
        server = MCPServer(input_stream=inp, output_stream=out)
        server.serve_forever()
        resp = json.loads(out.getvalue().strip())
        assert resp["error"]["code"] == -32700


class TestGetVersionImportError:
    """Lines 142-143: _get_version returns 'unknown' on ImportError."""

    def test_import_error_returns_unknown(self) -> None:
        import sys

        saved = sys.modules.get("owlmind")
        sys.modules["owlmind"] = None  # type: ignore[assignment]
        try:
            result = _get_version()
        finally:
            if saved is None:
                sys.modules.pop("owlmind", None)
            else:
                sys.modules["owlmind"] = saved
        assert result == "unknown"


class TestToolRunException:
    """Lines 278-279: _tool_run exception handler returns error dict."""

    def test_run_exception_returns_error(self, tmp_path: Path) -> None:
        server = MCPServer()
        with patch("owlmind.mcp.server._tool_run", side_effect=Exception("boom")):
            resp = server.handle_one(
                {
                    "jsonrpc": "2.0",
                    "method": "tools/call",
                    "params": {
                        "name": "owlmind_run",
                        "arguments": {"goal": "test", "workspace": str(tmp_path)},
                    },
                    "id": 99,
                }
            )
        # The outer handler catches errors from _tool_run as well
        assert resp is not None

    def test_tool_run_internal_exception(self, tmp_path: Path) -> None:
        """_tool_run itself catches exceptions and returns error dict."""
        from owlmind.mcp.server import _tool_run

        with patch(
            "owlmind.agent.cycle.CycleManager.__init__", side_effect=RuntimeError("init failed")
        ):
            result = _tool_run({"goal": "test goal", "workspace": str(tmp_path)})
        assert result.get("status") == "failed"
        assert "init failed" in result.get("error", "")


class TestToolEventsException:
    """Lines 305-306: _tool_events exception handler returns error dict."""

    def test_events_exception_returns_error(self, tmp_path: Path) -> None:
        from owlmind.mcp.server import _tool_events

        with patch(
            "owlmind.evidence.EvidenceStore.read_events", side_effect=RuntimeError("read fail")
        ):
            result = _tool_events({"run_id": "run-exc", "workspace": str(tmp_path)})
        assert "error" in result
        assert result.get("run_id") == "run-exc"


class TestMCPLogging:
    """Verify logging is emitted on tool invocation (audit trail)."""

    @patch("owlmind.mcp.server._tool_cost_estimate")
    def test_logger_info_called_on_success(self, mock_cost: MagicMock) -> None:
        """logger.info is called before and after a successful tool call."""
        mock_cost.return_value = {"estimated_usd_low": 0.01}
        server = MCPServer()
        with patch("owlmind.mcp.server.logger") as mock_logger:
            server.handle_one(
                {
                    "jsonrpc": "2.0",
                    "method": "tools/call",
                    "params": {
                        "name": "owlmind_cost_estimate",
                        "arguments": {"goal": "test goal"},
                    },
                    "id": 100,
                }
            )
        # logger.info must be called at least twice: "called" and "completed"
        info_calls = [str(c) for c in mock_logger.info.call_args_list]
        assert any("MCP tool called" in c for c in info_calls), (
            f"Expected 'MCP tool called' log, got: {info_calls}"
        )
        assert any("MCP tool completed" in c for c in info_calls), (
            f"Expected 'MCP tool completed' log, got: {info_calls}"
        )

    @patch("owlmind.mcp.server._tool_doctor")
    def test_logger_error_called_on_failure(self, mock_doctor: MagicMock) -> None:
        """logger.error is called when tool raises an exception."""
        mock_doctor.side_effect = RuntimeError("boom from test")
        server = MCPServer()
        with patch("owlmind.mcp.server.logger") as mock_logger:
            resp = server.handle_one(
                {
                    "jsonrpc": "2.0",
                    "method": "tools/call",
                    "params": {"name": "owlmind_doctor", "arguments": {"workspace": "."}},
                    "id": 101,
                }
            )
        assert resp is not None
        assert resp["result"]["isError"] is True
        error_calls = [str(c) for c in mock_logger.error.call_args_list]
        assert any("MCP tool failed" in c for c in error_calls), (
            f"Expected 'MCP tool failed' in error log, got: {error_calls}"
        )
        assert any("boom from test" in c for c in error_calls), (
            f"Expected error message in log, got: {error_calls}"
        )

    def test_audit_logger_called_on_success(self) -> None:
        """audit_logger.info is called with JSON-L record on successful tool call."""
        import json as _json

        server = MCPServer()
        with patch("owlmind.mcp.server._tool_cost_estimate", return_value={"low": 0.01}):
            with patch("owlmind.mcp.server.audit_logger") as mock_audit:
                server.handle_one(
                    {
                        "jsonrpc": "2.0",
                        "method": "tools/call",
                        "params": {
                            "name": "owlmind_cost_estimate",
                            "arguments": {"goal": "audit test", "provider": "openai"},
                        },
                        "id": 102,
                    }
                )
        mock_audit.info.assert_called_once()
        # The second positional arg to logger.info("%s", payload) is the JSON string
        call_args = mock_audit.info.call_args
        payload_str = call_args[0][1]  # positional arg at index 1
        payload = _json.loads(payload_str)
        assert payload["tool"] == "owlmind_cost_estimate"
        assert payload["success"] is True
        assert "ts" in payload
        assert set(payload["args_keys"]) == {"goal", "provider"}

    def test_audit_logger_called_on_failure(self) -> None:
        """audit_logger.info records success=False when tool raises."""
        import json as _json

        server = MCPServer()
        with patch("owlmind.mcp.server._tool_doctor", side_effect=ValueError("fail")):
            with patch("owlmind.mcp.server.audit_logger") as mock_audit:
                server.handle_one(
                    {
                        "jsonrpc": "2.0",
                        "method": "tools/call",
                        "params": {"name": "owlmind_doctor", "arguments": {"workspace": "/ws"}},
                        "id": 103,
                    }
                )
        mock_audit.info.assert_called_once()
        call_args = mock_audit.info.call_args
        payload = _json.loads(call_args[0][1])
        assert payload["tool"] == "owlmind_doctor"
        assert payload["success"] is False
        assert "fail" in payload.get("error", "")

    def test_audit_logger_called_on_unknown_tool(self) -> None:
        """audit_logger.info records unknown tool with success=False."""
        import json as _json

        server = MCPServer()
        with patch("owlmind.mcp.server.audit_logger") as mock_audit:
            server.handle_one(
                {
                    "jsonrpc": "2.0",
                    "method": "tools/call",
                    "params": {"name": "does_not_exist", "arguments": {"x": 1}},
                    "id": 104,
                }
            )
        mock_audit.info.assert_called_once()
        call_args = mock_audit.info.call_args
        payload = _json.loads(call_args[0][1])
        assert payload["tool"] == "does_not_exist"
        assert payload["success"] is False
        assert payload.get("error") == "unknown_tool"

    def test_logger_info_includes_tool_name(self) -> None:
        """The 'MCP tool called' log message includes the tool name."""
        server = MCPServer()
        with patch("owlmind.mcp.server._tool_cost_estimate", return_value={}):
            with patch("owlmind.mcp.server.logger") as mock_logger:
                server.handle_one(
                    {
                        "jsonrpc": "2.0",
                        "method": "tools/call",
                        "params": {
                            "name": "owlmind_cost_estimate",
                            "arguments": {"goal": "test"},
                        },
                        "id": 105,
                    }
                )
        called_args = mock_logger.info.call_args_list
        # First call: "MCP tool called: %s, args: %s" with tool name
        first_call_args = called_args[0][0]
        assert "owlmind_cost_estimate" in first_call_args
