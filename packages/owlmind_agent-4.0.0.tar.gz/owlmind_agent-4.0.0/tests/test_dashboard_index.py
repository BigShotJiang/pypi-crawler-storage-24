"""Tests for Dashboard Index — HTML generation, link presence, safety."""

from __future__ import annotations

from pathlib import Path

from owlmind.dashboard_index import build_index


class TestBuildIndex:
    def test_empty_dirs(self, tmp_path: Path) -> None:
        """Index with no dashboards produces valid HTML."""
        out = tmp_path / "index.html"
        result = build_index(out, [tmp_path])

        assert result == out
        assert out.exists()
        content = out.read_text()
        assert "OWLMIND Dashboard Index" in content
        assert "No dashboards found" in content

    def test_finds_session_protocol(self, tmp_path: Path) -> None:
        """Index includes session protocol.md files."""
        sess = tmp_path / "sessions" / "s1"
        sess.mkdir(parents=True)
        (sess / "protocol.md").write_text("# Protocol")

        out = tmp_path / "index.html"
        build_index(out, [tmp_path])

        content = out.read_text()
        assert "sessions/s1/protocol.md" in content
        assert "protocol" in content

    def test_finds_session_dashboard(self, tmp_path: Path) -> None:
        """Index includes session dashboard HTML files."""
        exports = tmp_path / "sessions" / "s1" / "exports"
        exports.mkdir(parents=True)
        (exports / "dashboard.html").write_text("<html></html>")

        out = tmp_path / "index.html"
        build_index(out, [tmp_path])

        content = out.read_text()
        assert "dashboard.html" in content
        assert "dashboard" in content

    def test_finds_run_dashboard(self, tmp_path: Path) -> None:
        """Index includes run HTML dashboards."""
        run_dir = tmp_path / "runs" / "r1"
        run_dir.mkdir(parents=True)
        (run_dir / "report.html").write_text("<html></html>")

        out = tmp_path / "index.html"
        build_index(out, [tmp_path])

        content = out.read_text()
        assert "runs/r1/report.html" in content
        assert "run-dashboard" in content

    def test_multiple_roots(self, tmp_path: Path) -> None:
        """Index handles multiple root directories."""
        root1 = tmp_path / "project1"
        root2 = tmp_path / "project2"

        sess1 = root1 / "sessions" / "s1"
        sess1.mkdir(parents=True)
        (sess1 / "protocol.md").write_text("# P1")

        sess2 = root2 / "sessions" / "s2"
        sess2.mkdir(parents=True)
        (sess2 / "protocol.md").write_text("# P2")

        out = tmp_path / "index.html"
        build_index(out, [root1, root2])

        content = out.read_text()
        assert "sessions/s1/protocol.md" in content
        assert "sessions/s2/protocol.md" in content

    def test_nonexistent_root_skipped(self, tmp_path: Path) -> None:
        """Non-existent root dirs are silently skipped."""
        out = tmp_path / "index.html"
        build_index(out, [tmp_path / "does_not_exist"])

        assert out.exists()
        assert "No dashboards found" in out.read_text()

    def test_creates_parent_dirs(self, tmp_path: Path) -> None:
        """Output directory is created if it doesn't exist."""
        out = tmp_path / "deep" / "nested" / "index.html"
        build_index(out, [tmp_path])

        assert out.exists()

    def test_html_escaping(self, tmp_path: Path) -> None:
        """Special characters in paths are HTML-escaped."""
        sess = tmp_path / "sessions" / "s<script>"
        sess.mkdir(parents=True)
        (sess / "protocol.md").write_text("x")

        out = tmp_path / "index.html"
        build_index(out, [tmp_path])

        content = out.read_text()
        assert "<script>" not in content
        assert "&lt;script&gt;" in content


class TestEntryOsError:
    """Lines 49-50: OSError on stat → mtime='?'."""

    def test_oserror_gives_question_mark_mtime(self, tmp_path: Path) -> None:
        from unittest.mock import patch

        from owlmind.dashboard_index import _entry

        p = tmp_path / "fake.html"
        p.write_text("<html/>")

        with patch("pathlib.Path.stat", side_effect=OSError("no stat")):
            entry = _entry(p, "run-dashboard", tmp_path)

        assert entry["mtime"] == "?"
        assert entry["kind"] == "run-dashboard"
