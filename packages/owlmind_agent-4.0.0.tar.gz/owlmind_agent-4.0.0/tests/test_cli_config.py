"""Tests for owlmind.cli.config_cmd — config show, paths, completions."""

from __future__ import annotations

import json
import os
from pathlib import Path
from unittest.mock import patch

from typer.testing import CliRunner

from owlmind.cli import app
from owlmind.cli.config_cmd import _redact_dict, _resolve_config

runner = CliRunner()


class TestRedactDict:
    def test_redacts_api_key(self) -> None:
        d = {"api_key": "sk-secret123", "model": "gpt-4o"}
        result = _redact_dict(d)
        assert result["api_key"] == "***"
        assert result["model"] == "gpt-4o"

    def test_empty_secret_stays_empty(self) -> None:
        d = {"api_key": "", "model": "gpt-4o"}
        result = _redact_dict(d)
        assert result["api_key"] == ""

    def test_redacts_bot_token(self) -> None:
        d = {"bot_token": "123:ABCDEF", "rate_limit": 2.0}
        result = _redact_dict(d)
        assert result["bot_token"] == "***"

    def test_nested_redaction(self) -> None:
        d = {"openai": {"api_key": "sk-test", "model": "gpt-4o"}}
        result = _redact_dict(d)
        assert result["openai"]["api_key"] == "***"
        assert result["openai"]["model"] == "gpt-4o"

    def test_preserves_non_secret_fields(self) -> None:
        d = {"model": "gpt-4o", "timeout": 60, "enabled": True}
        result = _redact_dict(d)
        assert result == d


class TestResolveConfig:
    def test_returns_redacted_dict(self) -> None:
        env = {"OPENAI_API_KEY": "sk-real-key-123"}
        with patch.dict(os.environ, env, clear=True):
            data = _resolve_config()
        assert data["openai"]["api_key"] == "***"
        assert isinstance(data, dict)

    def test_no_raw_secrets_in_output(self) -> None:
        env = {
            "OPENAI_API_KEY": "sk-real-key-123",
            "ANTHROPIC_API_KEY": "sk-ant-secret",
            "TELEGRAM_BOT_TOKEN": "123:BOTTOKEN",
        }
        with patch.dict(os.environ, env, clear=True):
            data = _resolve_config()
        serialized = json.dumps(data)
        assert "sk-real-key-123" not in serialized
        assert "sk-ant-secret" not in serialized
        assert "123:BOTTOKEN" not in serialized


class TestConfigShowCommand:
    def test_show_table(self) -> None:
        with patch.dict(os.environ, {}, clear=True):
            result = runner.invoke(app, ["config", "show"])
        assert result.exit_code == 0

    def test_show_json(self) -> None:
        with patch.dict(os.environ, {}, clear=True):
            result = runner.invoke(app, ["config", "show", "--json"])
        assert result.exit_code == 0
        # Output should contain valid JSON structure
        assert "openai" in result.output
        assert "telegram" in result.output


class TestConfigPathsCommand:
    def test_paths_default(self, tmp_path: Path) -> None:
        result = runner.invoke(app, ["config", "paths", "-w", str(tmp_path)])
        assert result.exit_code == 0
        assert "runs" in result.output
        assert "sessions" in result.output
        assert "ledger" in result.output

    def test_paths_shows_existence(self, tmp_path: Path) -> None:
        (tmp_path / "runs").mkdir()
        result = runner.invoke(app, ["config", "paths", "-w", str(tmp_path)])
        assert result.exit_code == 0


class TestCompletionsCommand:
    def test_invalid_shell(self) -> None:
        result = runner.invoke(app, ["config", "completions", "powershell"])
        assert result.exit_code == 1

    def test_bash_completions(self) -> None:
        result = runner.invoke(app, ["config", "completions", "bash"])
        # May succeed or fail depending on Click version, but should not crash
        assert result.exit_code in (0, 1)
