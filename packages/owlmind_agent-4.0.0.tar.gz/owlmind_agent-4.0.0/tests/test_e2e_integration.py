"""Integration tests for E2E — SKIPPED unless OWLMIND_RUN_E2E=1.

These tests may make real API calls and require:
- OPENAI_API_KEY (or chosen provider key)
- `claude` binary if use_worker=claude_cli
"""

from __future__ import annotations

import os
from pathlib import Path

import pytest

# Skip entire module unless explicitly enabled
pytestmark = pytest.mark.skipif(
    os.environ.get("OWLMIND_RUN_E2E", "0") != "1",
    reason="Set OWLMIND_RUN_E2E=1 to run E2E integration tests",
)


def _make_policies(tmp_path: Path) -> Path:
    """Create minimal policies directory."""
    policies_dir = tmp_path / "policies"
    policies_dir.mkdir(exist_ok=True)
    (policies_dir / "allowlist.yaml").write_text('allowed_commands:\n  - "^echo "\n  - "^pytest"\n')
    (policies_dir / "policy.yaml").write_text('forbidden_patterns:\n  - "rm -rf"\n')
    return policies_dir


class TestE2ERealPlanner:
    """Test real LLM planner call — reaches WAIT_WORKER or WAIT_APPROVAL."""

    def test_reaches_worker_or_approval(self, tmp_path: Path) -> None:
        from owlmind.e2e import EXIT_BLOCKED, E2EConfig, run_e2e

        policies_dir = _make_policies(tmp_path)

        config = E2EConfig(
            goal="E2E integration: echo hello",
            workspace=str(tmp_path),
            sandbox=False,
            use_llm="planner",
            use_worker="none",
            max_steps=10,
            interval_sec=0.5,
            policies_dir=policies_dir,
            runs_dir=tmp_path / "runs",
            ledger_dir=tmp_path / "ledger",
        )
        result = run_e2e(config)

        # Should either reach WAIT_WORKER (planner done) or WAIT_APPROVAL (budget)
        assert result.exit_code == EXIT_BLOCKED
        assert result.final_state in (
            "WAIT_WORKER",
            "WAIT_APPROVAL",
            "STARTED_WAIT_PLANNER",
        )
        assert result.run_id.startswith("cycle-")


class TestE2EPreflight:
    """Test preflight with real environment."""

    def test_preflight_passes_with_key(self) -> None:
        from owlmind.preflight import PreflightConfig, run_preflight

        # Should pass if at least one provider key is set
        has_key = any(
            os.environ.get(k)
            for k in ("OPENAI_API_KEY", "ANTHROPIC_API_KEY", "GEMINI_API_KEY", "GOOGLE_API_KEY")
        )
        assert has_key, "No API key found — set at least one to run E2E tests"

        config = PreflightConfig(use_llm="both", workspace=".")
        report = run_preflight(config)

        # At least one provider should be enabled
        enabled = [p for p, s in report.provider_status.items() if s == "enabled"]
        assert len(enabled) >= 1
