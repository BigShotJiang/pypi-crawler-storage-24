"""Tests for the Slack bot integration."""

from __future__ import annotations

import sys
import types
from unittest.mock import AsyncMock, MagicMock, patch

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_command(text: str = "", user_id: str = "U123", channel_id: str = "C456") -> dict:
    return {"text": text, "user_id": user_id, "channel_id": channel_id}


# ---------------------------------------------------------------------------
# 1. is_slack_available() returns False when bolt not installed
# ---------------------------------------------------------------------------


def test_is_slack_available_false_when_not_installed() -> None:
    """is_slack_available() must return False when slack_bolt is absent."""
    # Temporarily mask the module if it happens to be installed
    bolt_mod = sys.modules.get("slack_bolt")
    try:
        sys.modules["slack_bolt"] = None  # type: ignore[assignment]
        # Force reimport
        if "owlmind.slack_bot" in sys.modules:
            del sys.modules["owlmind.slack_bot"]
        import importlib

        import owlmind.slack_bot as sb
        importlib.reload(sb)
        assert sb.is_slack_available() is False
    finally:
        if bolt_mod is None:
            sys.modules.pop("slack_bolt", None)
        else:
            sys.modules["slack_bolt"] = bolt_mod
        if "owlmind.slack_bot" in sys.modules:
            del sys.modules["owlmind.slack_bot"]


# ---------------------------------------------------------------------------
# 2. create_slack_bot() returns None when bolt not available
# ---------------------------------------------------------------------------


def test_create_slack_bot_returns_none_when_unavailable() -> None:
    """create_slack_bot() returns None if _BOLT_AVAILABLE is False."""
    bolt_mod = sys.modules.get("slack_bolt")
    try:
        sys.modules["slack_bolt"] = None  # type: ignore[assignment]
        if "owlmind.slack_bot" in sys.modules:
            del sys.modules["owlmind.slack_bot"]
        import importlib

        import owlmind.slack_bot as sb
        importlib.reload(sb)
        result = sb.create_slack_bot(bot_token="xoxb-test", app_token="xapp-test")
        assert result is None
    finally:
        if bolt_mod is None:
            sys.modules.pop("slack_bolt", None)
        else:
            sys.modules["slack_bolt"] = bolt_mod
        if "owlmind.slack_bot" in sys.modules:
            del sys.modules["owlmind.slack_bot"]


# ---------------------------------------------------------------------------
# 3. create_slack_bot() returns app when bolt available (mock App)
# ---------------------------------------------------------------------------


def test_create_slack_bot_returns_app_when_available() -> None:
    """create_slack_bot() returns an App instance when slack_bolt is present."""
    mock_app_instance = MagicMock()
    mock_app_cls = MagicMock(return_value=mock_app_instance)

    # Build a minimal fake slack_bolt package tree
    fake_bolt = types.ModuleType("slack_bolt")
    fake_bolt_async = types.ModuleType("slack_bolt.async_app")
    fake_bolt_async.AsyncApp = mock_app_cls  # type: ignore[attr-defined]

    fake_adapter = types.ModuleType("slack_bolt.adapter")
    fake_socket = types.ModuleType("slack_bolt.adapter.socket_mode")
    fake_socket_async = types.ModuleType("slack_bolt.adapter.socket_mode.async_handler")
    fake_socket_async.AsyncSocketModeHandler = MagicMock()  # type: ignore[attr-defined]

    with patch.dict(
        sys.modules,
        {
            "slack_bolt": fake_bolt,
            "slack_bolt.async_app": fake_bolt_async,
            "slack_bolt.adapter": fake_adapter,
            "slack_bolt.adapter.socket_mode": fake_socket,
            "slack_bolt.adapter.socket_mode.async_handler": fake_socket_async,
        },
    ):
        if "owlmind.slack_bot" in sys.modules:
            del sys.modules["owlmind.slack_bot"]
        import importlib

        import owlmind.slack_bot as sb
        importlib.reload(sb)

        # Patch _BOLT_AVAILABLE so we bypass the real import check
        sb._BOLT_AVAILABLE = True
        result = sb.create_slack_bot(bot_token="xoxb-test", app_token="xapp-test")
        assert result is not None


# ---------------------------------------------------------------------------
# Handler tests — we test the handler functions directly (no real Slack)
# ---------------------------------------------------------------------------


import asyncio

import pytest


def _run(coro):
    return asyncio.get_event_loop().run_until_complete(coro)


def _make_ctx(allowed_user_ids=None):
    from owlmind.slack.context import SlackBotContext

    ctx = SlackBotContext(
        app=MagicMock(),
        operator=None,
        allowed_user_ids=allowed_user_ids or [],
        llm_profiles={
            "fast": {"name": "Fast", "model": "claude-haiku"},
            "balanced": {"name": "Balanced", "model": "claude-sonnet"},
            "powerful": {"name": "Powerful", "model": "claude-opus"},
        },
        state={"llm_profile": "balanced"},
        state_file="/tmp/.test_slack_state.json",
        api_port=8765,
        api_key="",
    )
    return ctx


# ---------------------------------------------------------------------------
# 4. cmd_cw_help — sends help text
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_cmd_cw_help_sends_text() -> None:
    from owlmind.slack.handlers import cmd_cw_help

    ack = AsyncMock()
    say = AsyncMock()
    ctx = _make_ctx()
    await cmd_cw_help(ack=ack, say=say, command=_make_command(), ctx=ctx)
    ack.assert_awaited_once()
    say.assert_awaited_once()
    text = say.call_args[0][0]
    assert "/cw_graph" in text
    assert "/cw_help" in text


# ---------------------------------------------------------------------------
# 5. cmd_cw_help — unauthorized user is rejected
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_cmd_cw_help_unauthorized() -> None:
    from owlmind.slack.handlers import cmd_cw_help

    ack = AsyncMock()
    say = AsyncMock()
    ctx = _make_ctx(allowed_user_ids=["U999"])  # only U999 allowed
    await cmd_cw_help(ack=ack, say=say, command=_make_command(user_id="U123"), ctx=ctx)
    ack.assert_awaited_once()
    say.assert_awaited_once()
    assert "Not authorized" in say.call_args[0][0]


# ---------------------------------------------------------------------------
# 6. cmd_cw_graph — missing goal shows usage
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_cmd_cw_graph_no_goal_shows_usage() -> None:
    from owlmind.slack.handlers import cmd_cw_graph

    ack = AsyncMock()
    say = AsyncMock()
    ctx = _make_ctx()
    await cmd_cw_graph(ack=ack, say=say, command=_make_command(text=""), ctx=ctx)
    ack.assert_awaited_once()
    say.assert_awaited_once()
    assert "Usage" in say.call_args[0][0]


# ---------------------------------------------------------------------------
# 7. cmd_cw_watch_start — missing goal shows usage
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_cmd_cw_watch_start_no_goal_shows_usage() -> None:
    from owlmind.slack.handlers import cmd_cw_watch_start

    ack = AsyncMock()
    say = AsyncMock()
    ctx = _make_ctx()
    await cmd_cw_watch_start(ack=ack, say=say, command=_make_command(text=""), ctx=ctx)
    ack.assert_awaited_once()
    assert "Usage" in say.call_args[0][0]


# ---------------------------------------------------------------------------
# 8. cmd_cw_watch_stop — no scheduler running
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_cmd_cw_watch_stop_no_scheduler() -> None:
    from owlmind.slack import handlers as h

    # Ensure no leftover scheduler
    h._schedulers.clear()
    ack = AsyncMock()
    say = AsyncMock()
    ctx = _make_ctx()
    await h.cmd_cw_watch_stop(ack=ack, say=say, command=_make_command(), ctx=ctx)
    ack.assert_awaited_once()
    assert "No scheduler" in say.call_args[0][0]


# ---------------------------------------------------------------------------
# 9. cmd_cw_watch_start → cmd_cw_watch_stop full cycle
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_cmd_cw_watch_start_stop_cycle() -> None:
    from owlmind.slack import handlers as h

    h._schedulers.clear()
    ack = AsyncMock()
    say = AsyncMock()
    ctx = _make_ctx()

    mock_scheduler = MagicMock()
    mock_scheduler.status.return_value = {"running": True, "queue_size": 1, "history_count": 0}

    with patch("owlmind.slack.handlers.AutonomousScheduler", return_value=mock_scheduler, create=True):
        with patch.dict(
            sys.modules,
            {"owlmind.autonomous": MagicMock(AutonomousScheduler=MagicMock(return_value=mock_scheduler))},
        ):
            await h.cmd_cw_watch_start(
                ack=ack, say=say, command=_make_command(text="fix all errors"), ctx=ctx
            )

    channel_id = "C456"
    # Manually insert mock so stop can find it
    h._schedulers[channel_id] = mock_scheduler

    ack2 = AsyncMock()
    say2 = AsyncMock()
    await h.cmd_cw_watch_stop(ack=ack2, say=say2, command=_make_command(), ctx=ctx)
    mock_scheduler.stop.assert_called_once()
    assert channel_id not in h._schedulers
    assert "stopped" in say2.call_args[0][0].lower()


# ---------------------------------------------------------------------------
# 10. cmd_cw_model — switch profile
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_cmd_cw_model_switch() -> None:
    from owlmind.slack.handlers import cmd_cw_model

    ack = AsyncMock()
    say = AsyncMock()
    ctx = _make_ctx()
    ctx.state["llm_profile"] = "balanced"

    await cmd_cw_model(ack=ack, say=say, command=_make_command(text="fast"), ctx=ctx)
    ack.assert_awaited_once()
    assert ctx.state["llm_profile"] == "fast"
    assert "fast" in say.call_args[0][0].lower() or "Fast" in say.call_args[0][0]


# ---------------------------------------------------------------------------
# 11. cmd_cw_model — unknown profile
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_cmd_cw_model_unknown_profile() -> None:
    from owlmind.slack.handlers import cmd_cw_model

    ack = AsyncMock()
    say = AsyncMock()
    ctx = _make_ctx()

    await cmd_cw_model(ack=ack, say=say, command=_make_command(text="super_turbo"), ctx=ctx)
    ack.assert_awaited_once()
    assert "Unknown" in say.call_args[0][0]


# ---------------------------------------------------------------------------
# 12. SlackBotContext.check_auth
# ---------------------------------------------------------------------------


def test_slack_bot_context_check_auth() -> None:
    ctx = _make_ctx(allowed_user_ids=["U001", "U002"])
    assert ctx.check_auth("U001") is True
    assert ctx.check_auth("U003") is False
    # Empty allowlist = everyone allowed
    ctx2 = _make_ctx(allowed_user_ids=[])
    assert ctx2.check_auth("anyone") is True
