"""Tests for FS57 — Task Complexity Classifier."""

from __future__ import annotations

import pytest

from owlmind.llm.complexity import (
    COMPLEXITY_PROVIDERS,
    classify_goal,
    provider_for_complexity,
)

# ---------------------------------------------------------------------------
# classify_goal tests
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "goal",
    [
        "fix typo in README",
        "add comment to function",
        "rename variable foo to bar",
        "update string in config",
        "fix comment in module",
    ],
)
def test_classify_simple_by_keyword(goal: str) -> None:
    assert classify_goal(goal) == "simple"


@pytest.mark.parametrize(
    "goal",
    [
        "refactor the authentication module",
        "migrate database to PostgreSQL",
        "architect a new microservice system",
        "redesign the API layer",
        "perform a security audit of the codebase",
    ],
)
def test_classify_complex_by_keyword(goal: str) -> None:
    assert classify_goal(goal) == "complex"


def test_classify_simple_by_length() -> None:
    """Short goals (≤ 50 chars) without complex keywords → simple."""
    goal = "Add a new endpoint"  # 18 chars, no keywords
    assert classify_goal(goal) == "simple"


def test_classify_complex_by_length() -> None:
    """Long goals (≥ 200 chars) without simple keywords → complex."""
    goal = " ".join(["add feature"] * 20)  # >200 chars
    assert classify_goal(goal) == "complex"


def test_classify_medium_for_normal_goal() -> None:
    """Normal-length goal without strong keywords → medium."""
    goal = "Add a new REST endpoint for user profile updates with validation"
    assert classify_goal(goal) == "medium"


def test_classify_empty_goal() -> None:
    """Empty goal → simple (safe default)."""
    assert classify_goal("") == "simple"


def test_classify_complex_keyword_beats_short_length() -> None:
    """Complex keyword takes priority over short length."""
    goal = "refactor auth"  # short but has 'refactor'
    assert classify_goal(goal) == "complex"


def test_classify_complex_keyword_beats_simple_keyword() -> None:
    """Complex keywords take priority over simple keywords."""
    goal = "refactor and rename the module"  # both 'refactor' and 'rename'
    assert classify_goal(goal) == "complex"


# ---------------------------------------------------------------------------
# COMPLEXITY_PROVIDERS structure tests
# ---------------------------------------------------------------------------


def test_complexity_providers_has_all_levels() -> None:
    assert "simple" in COMPLEXITY_PROVIDERS
    assert "medium" in COMPLEXITY_PROVIDERS
    assert "complex" in COMPLEXITY_PROVIDERS


def test_complexity_providers_are_lists() -> None:
    for level, providers in COMPLEXITY_PROVIDERS.items():
        assert isinstance(providers, list), f"{level} providers should be a list"
        assert len(providers) >= 1, f"{level} providers should be non-empty"


# ---------------------------------------------------------------------------
# provider_for_complexity tests
# ---------------------------------------------------------------------------


def test_provider_for_medium_returns_none() -> None:
    """Medium complexity returns None (no routing change)."""
    assert provider_for_complexity("medium") is None


def test_provider_for_simple_returns_string() -> None:
    """Simple complexity returns a provider string."""
    result = provider_for_complexity("simple")
    assert isinstance(result, str)
    assert len(result) > 0


def test_provider_for_complex_returns_string() -> None:
    """Complex complexity returns a provider string."""
    result = provider_for_complexity("complex")
    assert isinstance(result, str)
    assert len(result) > 0


def test_provider_for_simple_matches_providers_list() -> None:
    """provider_for_complexity returns first item from COMPLEXITY_PROVIDERS."""
    assert provider_for_complexity("simple") == COMPLEXITY_PROVIDERS["simple"][0]


def test_provider_for_complex_matches_providers_list() -> None:
    assert provider_for_complexity("complex") == COMPLEXITY_PROVIDERS["complex"][0]


# ---------------------------------------------------------------------------
# Integration: classify_goal + provider_for_complexity round-trip
# ---------------------------------------------------------------------------


def test_classify_and_route_simple_goal() -> None:
    """Short simple goal gets a non-None provider (anthropic for simple)."""
    goal = "fix typo in readme"
    complexity = classify_goal(goal)
    assert complexity == "simple"
    provider = provider_for_complexity(complexity)
    assert provider is not None


def test_classify_and_route_medium_goal() -> None:
    """Medium goal gets None provider (no routing change)."""
    goal = "Add input validation logic to the user registration form handler"
    complexity = classify_goal(goal)
    assert complexity == "medium"
    assert provider_for_complexity(complexity) is None
