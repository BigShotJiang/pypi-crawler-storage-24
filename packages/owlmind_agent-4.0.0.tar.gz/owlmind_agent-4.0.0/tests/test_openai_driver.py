"""Tests for OpenAI LLM driver — NO network calls (fully mocked)."""

from __future__ import annotations

from types import SimpleNamespace
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from owlmind.config import OpenAIConfig
from owlmind.errors import TransientError
from owlmind.llm.openai_driver import (
    JUDGE_RESPONSE_SCHEMA,
    PLANNER_RESPONSE_SCHEMA,
    OpenAIDriver,
    is_openai_available,
)


def _make_config(**overrides: Any) -> OpenAIConfig:
    return OpenAIConfig(
        api_key=overrides.get("api_key", "test-key-123"),
        planner_model=overrides.get("planner_model", "gpt-4o-test"),
        judge_model=overrides.get("judge_model", "gpt-4o-test"),
        max_output_tokens=overrides.get("max_output_tokens", 500),
        timeout_sec=overrides.get("timeout_sec", 10),
    )


def _mock_response(content_dict: dict[str, Any]) -> SimpleNamespace:
    """Build a mock OpenAI ChatCompletion response."""
    import json

    usage = SimpleNamespace(prompt_tokens=100, completion_tokens=50, total_tokens=150)
    message = SimpleNamespace(content=json.dumps(content_dict))
    choice = SimpleNamespace(message=message)
    return SimpleNamespace(id="resp-abc123", choices=[choice], usage=usage)


class TestIsOpenAIAvailable:
    def test_returns_bool(self) -> None:
        result = is_openai_available()
        assert isinstance(result, bool)


class TestOpenAIDriverInit:
    @patch("owlmind.llm.openai_driver._OPENAI_AVAILABLE", False)
    def test_no_client_without_sdk(self) -> None:
        config = _make_config()
        driver = OpenAIDriver(config)
        assert driver._client is None

    def test_no_client_without_key(self) -> None:
        config = _make_config(api_key="")
        driver = OpenAIDriver(config)
        assert driver._client is None

    def test_name(self) -> None:
        config = _make_config(api_key="")
        driver = OpenAIDriver(config)
        assert driver.name == "openai"

    def test_supports_structured(self) -> None:
        config = _make_config(api_key="")
        driver = OpenAIDriver(config)
        assert driver.supports_structured is True


class TestOpenAIDriverPlan:
    def test_plan_returns_valid_response(self) -> None:
        config = _make_config()
        driver = OpenAIDriver(config)

        planner_response = {
            "run_id": "cycle-test",
            "iteration": 1,
            "plan_summary": ["Step 1: Do thing"],
            "worker_instructions": "Do the thing",
            "verify_commands": ["pytest -q"],
            "risk_notes": [],
        }
        mock_resp = _mock_response(planner_response)

        mock_client = MagicMock()
        mock_client.chat.completions.create.return_value = mock_resp
        driver._client = mock_client

        request = {
            "run_id": "cycle-test",
            "iteration": 1,
            "goal": "Test goal",
            "repo_context": "Test repo",
            "constraints": ["Be safe"],
        }

        result, meta = driver.plan(request, PLANNER_RESPONSE_SCHEMA)

        assert result["run_id"] == "cycle-test"
        assert result["plan_summary"] == ["Step 1: Do thing"]
        assert result["worker_instructions"] == "Do the thing"
        assert meta["provider"] == "openai"
        assert meta["model"] == "gpt-4o-test"
        assert meta["response_id"] == "resp-abc123"
        assert meta["usage"]["total_tokens"] == 150
        assert meta["latency_ms"] >= 0

    def test_plan_uses_correct_model(self) -> None:
        config = _make_config(planner_model="gpt-custom")
        driver = OpenAIDriver(config)

        mock_client = MagicMock()
        mock_client.chat.completions.create.return_value = _mock_response(
            {
                "run_id": "x",
                "iteration": 1,
                "plan_summary": [],
                "worker_instructions": "x",
                "verify_commands": [],
                "risk_notes": [],
            }
        )
        driver._client = mock_client

        driver.plan({"run_id": "x", "iteration": 1, "goal": "x"}, PLANNER_RESPONSE_SCHEMA)

        call_kwargs = mock_client.chat.completions.create.call_args.kwargs
        assert call_kwargs["model"] == "gpt-custom"

    def test_plan_enforces_structured_output(self) -> None:
        config = _make_config()
        driver = OpenAIDriver(config)

        mock_client = MagicMock()
        mock_client.chat.completions.create.return_value = _mock_response(
            {
                "run_id": "x",
                "iteration": 1,
                "plan_summary": [],
                "worker_instructions": "x",
                "verify_commands": [],
                "risk_notes": [],
            }
        )
        driver._client = mock_client

        driver.plan({"run_id": "x"}, PLANNER_RESPONSE_SCHEMA)

        call_kwargs = mock_client.chat.completions.create.call_args.kwargs
        rf = call_kwargs["response_format"]
        assert rf["type"] == "json_schema"
        assert rf["json_schema"]["strict"] is True
        assert rf["json_schema"]["name"] == "PlannerResponse"


class TestOpenAIDriverJudge:
    def test_judge_returns_valid_response(self) -> None:
        config = _make_config()
        driver = OpenAIDriver(config)

        judge_response = {
            "run_id": "cycle-test",
            "iteration": 1,
            "verdict": "APPROVED",
            "notes": ["Good work"],
            "next_worker_instructions": "",
            "evidence_chain_verified": True,
        }
        mock_resp = _mock_response(judge_response)

        mock_client = MagicMock()
        mock_client.chat.completions.create.return_value = mock_resp
        driver._client = mock_client

        request = {
            "run_id": "cycle-test",
            "iteration": 1,
            "goal": "Test goal",
            "planner_plan_summary": ["Step 1"],
            "worker_done_summary": ["Done"],
            "verify_results_summary": ["pytest: PASS"],
            "evidence_paths": [],
        }

        result, meta = driver.judge(request, JUDGE_RESPONSE_SCHEMA)

        assert result["verdict"] == "APPROVED"
        assert result["evidence_chain_verified"] is True
        assert meta["provider"] == "openai"
        assert meta["usage"]["input_tokens"] == 100

    def test_judge_uses_correct_model(self) -> None:
        config = _make_config(judge_model="gpt-judge")
        driver = OpenAIDriver(config)

        mock_client = MagicMock()
        mock_client.chat.completions.create.return_value = _mock_response(
            {
                "run_id": "x",
                "iteration": 1,
                "verdict": "APPROVED",
                "notes": [],
                "next_worker_instructions": "",
                "evidence_chain_verified": True,
            }
        )
        driver._client = mock_client

        driver.judge({"run_id": "x"}, JUDGE_RESPONSE_SCHEMA)

        call_kwargs = mock_client.chat.completions.create.call_args.kwargs
        assert call_kwargs["model"] == "gpt-judge"


class TestOpenAIDriverErrors:
    def test_raises_without_client(self) -> None:
        config = _make_config(api_key="")
        driver = OpenAIDriver(config)

        with pytest.raises(RuntimeError, match="not initialized"):
            driver.plan({"run_id": "x"}, PLANNER_RESPONSE_SCHEMA)

    @patch("owlmind.llm.retry.time.sleep")
    def test_retries_on_error(self, mock_sleep: MagicMock) -> None:
        config = _make_config()
        driver = OpenAIDriver(config)

        mock_client = MagicMock()
        mock_client.chat.completions.create.side_effect = [
            RuntimeError("Connection error"),
            RuntimeError("Connection error"),
            _mock_response(
                {
                    "run_id": "x",
                    "iteration": 1,
                    "plan_summary": [],
                    "worker_instructions": "x",
                    "verify_commands": [],
                    "risk_notes": [],
                }
            ),
        ]
        driver._client = mock_client

        result, meta = driver.plan({"run_id": "x"}, PLANNER_RESPONSE_SCHEMA)
        assert result["run_id"] == "x"
        assert mock_client.chat.completions.create.call_count == 3

    @patch("owlmind.llm.retry.time.sleep")
    def test_fails_after_max_retries(self, mock_sleep: MagicMock) -> None:
        config = _make_config()
        driver = OpenAIDriver(config)

        mock_client = MagicMock()
        mock_client.chat.completions.create.side_effect = RuntimeError("Connection timeout")
        driver._client = mock_client

        with pytest.raises(TransientError, match="failed after 3 retries"):
            driver.plan({"run_id": "x"}, PLANNER_RESPONSE_SCHEMA)


class TestSchemas:
    def test_planner_schema_structure(self) -> None:
        assert PLANNER_RESPONSE_SCHEMA["type"] == "object"
        assert "run_id" in PLANNER_RESPONSE_SCHEMA["properties"]
        assert "worker_instructions" in PLANNER_RESPONSE_SCHEMA["properties"]
        assert PLANNER_RESPONSE_SCHEMA["additionalProperties"] is False

    def test_judge_schema_structure(self) -> None:
        assert JUDGE_RESPONSE_SCHEMA["type"] == "object"
        assert "verdict" in JUDGE_RESPONSE_SCHEMA["properties"]
        assert JUDGE_RESPONSE_SCHEMA["properties"]["verdict"]["enum"] == [
            "APPROVED",
            "NEEDS_FIX",
            "REJECTED",
        ]
        assert JUDGE_RESPONSE_SCHEMA["additionalProperties"] is False
