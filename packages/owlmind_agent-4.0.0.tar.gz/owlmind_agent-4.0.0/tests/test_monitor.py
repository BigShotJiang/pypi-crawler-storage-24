"""Tests for the monitoring module — digest, stuck detection, formatters."""

from __future__ import annotations

import json
from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest

from owlmind.monitor import (
    DigestReport,
    StuckSession,
    build_digest,
    detect_stuck_sessions,
    format_digest_markdown,
    format_stuck_text,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _write_run(runs_dir: Path, name: str, state: str) -> None:
    d = runs_dir / name
    d.mkdir(parents=True, exist_ok=True)
    (d / "cycle_meta.json").write_text(json.dumps({"state": state}))


def _write_session(sessions_dir: Path, name: str, status: str, updated_at: str) -> None:
    d = sessions_dir / name
    d.mkdir(parents=True, exist_ok=True)
    (d / "session_meta.json").write_text(
        json.dumps(
            {
                "status": status,
                "updated_at": updated_at,
            }
        )
    )


def _empty_totals():
    """Return a mock UsageTotals with zeroes."""
    from owlmind.ledger import UsageTotals

    return UsageTotals()


# ---------------------------------------------------------------------------
# build_digest
# ---------------------------------------------------------------------------


class TestBuildDigest:
    def test_empty_repo(self, tmp_path: Path) -> None:
        """Digest on empty workspace returns all zeroes."""
        ledger_dir = tmp_path / "ledger"
        runs_dir = tmp_path / "runs"
        sessions_dir = tmp_path / "sessions"
        ledger_dir.mkdir()

        report = build_digest(
            ledger_dir=ledger_dir,
            runs_dir=runs_dir,
            sessions_dir=sessions_dir,
        )

        assert report.total_tokens == 0
        assert report.estimated_usd == 0.0
        assert report.llm_calls == 0
        assert report.runs_done == 0
        assert report.runs_failed == 0
        assert report.sessions_done == 0
        assert report.sessions_running == 0
        assert report.recent_failures == []
        assert report.action_list == []

    def test_with_runs_and_sessions(self, tmp_path: Path) -> None:
        """Digest correctly counts runs and sessions by state."""
        ledger_dir = tmp_path / "ledger"
        runs_dir = tmp_path / "runs"
        sessions_dir = tmp_path / "sessions"
        ledger_dir.mkdir()
        runs_dir.mkdir()
        sessions_dir.mkdir()

        # Runs: 2 DONE, 1 FAILED, 1 BLOCKED
        _write_run(runs_dir, "run-001", "DONE")
        _write_run(runs_dir, "run-002", "DONE")
        _write_run(runs_dir, "run-003", "FAILED")
        _write_run(runs_dir, "run-004", "BLOCKED")

        # Sessions: 1 DONE, 1 FAILED, 1 RUNNING, 1 BLOCKED
        now = datetime.now(tz=UTC).isoformat()
        _write_session(sessions_dir, "sess-001", "DONE", now)
        _write_session(sessions_dir, "sess-002", "FAILED", now)
        _write_session(sessions_dir, "sess-003", "RUNNING", now)
        _write_session(sessions_dir, "sess-004", "BLOCKED", now)

        report = build_digest(
            ledger_dir=ledger_dir,
            runs_dir=runs_dir,
            sessions_dir=sessions_dir,
        )

        assert report.runs_done == 2
        assert report.runs_failed == 1
        assert report.runs_blocked == 1
        assert report.sessions_done == 1
        assert report.sessions_failed == 1
        assert report.sessions_running == 1
        assert report.sessions_blocked == 1
        # Failed items in recent_failures
        assert len(report.recent_failures) == 2
        types = {f["type"] for f in report.recent_failures}
        assert types == {"run", "session"}
        # Blocked items generate actions
        assert len(report.action_list) == 2

    def test_wait_approval_counts_as_blocked(self, tmp_path: Path) -> None:
        """WAIT_APPROVAL runs are counted as blocked."""
        ledger_dir = tmp_path / "ledger"
        runs_dir = tmp_path / "runs"
        sessions_dir = tmp_path / "sessions"
        ledger_dir.mkdir()
        runs_dir.mkdir()

        _write_run(runs_dir, "run-wait", "WAIT_APPROVAL")

        report = build_digest(
            ledger_dir=ledger_dir,
            runs_dir=runs_dir,
            sessions_dir=sessions_dir,
        )

        assert report.runs_blocked == 1

    def test_corrupt_meta_skipped(self, tmp_path: Path) -> None:
        """Corrupt JSON in meta files is safely skipped."""
        ledger_dir = tmp_path / "ledger"
        runs_dir = tmp_path / "runs"
        sessions_dir = tmp_path / "sessions"
        ledger_dir.mkdir()
        runs_dir.mkdir()

        d = runs_dir / "corrupt-run"
        d.mkdir()
        (d / "cycle_meta.json").write_text("{bad json!!!}")

        # Should not raise
        report = build_digest(
            ledger_dir=ledger_dir,
            runs_dir=runs_dir,
            sessions_dir=sessions_dir,
        )
        assert report.runs_done == 0

    def test_recent_failures_capped_at_10(self, tmp_path: Path) -> None:
        """Recent failures list is capped at 10."""
        ledger_dir = tmp_path / "ledger"
        runs_dir = tmp_path / "runs"
        sessions_dir = tmp_path / "sessions"
        ledger_dir.mkdir()
        runs_dir.mkdir()

        for i in range(15):
            _write_run(runs_dir, f"fail-{i:03}", "FAILED")

        report = build_digest(
            ledger_dir=ledger_dir,
            runs_dir=runs_dir,
            sessions_dir=sessions_dir,
        )

        assert report.runs_failed == 15
        assert len(report.recent_failures) == 10

    def test_with_ledger_data(self, tmp_path: Path) -> None:
        """Digest reads real ledger entries."""
        ledger_dir = tmp_path / "ledger"
        runs_dir = tmp_path / "runs"
        sessions_dir = tmp_path / "sessions"
        ledger_dir.mkdir()

        now = datetime.now(tz=UTC)
        entry = {
            "ts": now.isoformat(),
            "run_id": "r1",
            "stage": "worker",
            "provider": "openai",
            "model": "gpt-4o",
            "input_tokens": 100,
            "output_tokens": 50,
            "total_tokens": 150,
            "estimated_usd": 0.005,
            "latency_ms": 1000,
            "price_per_1k_input": 0.03,
            "price_per_1k_output": 0.06,
        }
        (ledger_dir / "usage.jsonl").write_text(json.dumps(entry) + "\n")

        report = build_digest(
            ledger_dir=ledger_dir,
            runs_dir=runs_dir,
            sessions_dir=sessions_dir,
        )

        assert report.total_tokens == 150
        assert report.estimated_usd == pytest.approx(0.005)
        assert report.llm_calls == 1


# ---------------------------------------------------------------------------
# detect_stuck_sessions
# ---------------------------------------------------------------------------


class TestDetectStuckSessions:
    def test_no_sessions_dir(self, tmp_path: Path) -> None:
        """Missing sessions dir returns empty list."""
        stuck = detect_stuck_sessions(tmp_path / "sessions")
        assert stuck == []

    def test_no_stuck(self, tmp_path: Path) -> None:
        """Recent RUNNING sessions are not stuck."""
        sessions_dir = tmp_path / "sessions"
        now = datetime.now(tz=UTC).isoformat()
        _write_session(sessions_dir, "fresh", "RUNNING", now)

        stuck = detect_stuck_sessions(sessions_dir, threshold_minutes=30)
        assert stuck == []

    def test_detects_stuck(self, tmp_path: Path) -> None:
        """Old RUNNING sessions are detected as stuck."""
        sessions_dir = tmp_path / "sessions"
        old = (datetime.now(tz=UTC) - timedelta(hours=2)).isoformat()
        _write_session(sessions_dir, "old-sess", "RUNNING", old)

        stuck = detect_stuck_sessions(sessions_dir, threshold_minutes=30)

        assert len(stuck) == 1
        assert stuck[0].session_id == "old-sess"
        assert stuck[0].minutes_since_update >= 119
        assert len(stuck[0].suggested_commands) == 2
        assert "old-sess" in stuck[0].suggested_commands[0]

    def test_done_sessions_ignored(self, tmp_path: Path) -> None:
        """DONE sessions are never stuck regardless of age."""
        sessions_dir = tmp_path / "sessions"
        old = (datetime.now(tz=UTC) - timedelta(hours=24)).isoformat()
        _write_session(sessions_dir, "old-done", "DONE", old)

        stuck = detect_stuck_sessions(sessions_dir, threshold_minutes=30)
        assert stuck == []

    def test_custom_threshold(self, tmp_path: Path) -> None:
        """Custom threshold works correctly."""
        sessions_dir = tmp_path / "sessions"
        ten_min_ago = (datetime.now(tz=UTC) - timedelta(minutes=10)).isoformat()
        _write_session(sessions_dir, "s1", "RUNNING", ten_min_ago)

        # 30-min threshold → not stuck
        assert detect_stuck_sessions(sessions_dir, threshold_minutes=30) == []
        # 5-min threshold → stuck
        stuck = detect_stuck_sessions(sessions_dir, threshold_minutes=5)
        assert len(stuck) == 1

    def test_corrupt_session_skipped(self, tmp_path: Path) -> None:
        """Corrupt session meta is safely skipped."""
        sessions_dir = tmp_path / "sessions"
        d = sessions_dir / "bad-sess"
        d.mkdir(parents=True)
        (d / "session_meta.json").write_text("not json")

        stuck = detect_stuck_sessions(sessions_dir, threshold_minutes=1)
        assert stuck == []


# ---------------------------------------------------------------------------
# Formatters
# ---------------------------------------------------------------------------


class TestFormatDigestMarkdown:
    def test_basic_format(self) -> None:
        report = DigestReport(
            days=1,
            total_tokens=1500,
            estimated_usd=0.0123,
            llm_calls=3,
            runs_done=2,
            runs_failed=1,
        )
        md = format_digest_markdown(report)

        assert "# OWLMIND Daily Digest" in md
        assert "1,500" in md
        assert "$0.0123" in md
        assert "LLM calls: 3" in md
        assert "Done: 2" in md
        assert "Failed: 1" in md

    def test_failures_section(self) -> None:
        report = DigestReport(
            recent_failures=[
                {"type": "run", "id": "r1", "state": "FAILED"},
            ],
        )
        md = format_digest_markdown(report)
        assert "## Recent Failures" in md
        assert "[run] r1: FAILED" in md

    def test_actions_section(self) -> None:
        report = DigestReport(
            action_list=["owlmind cycle status --run-id r1"],
        )
        md = format_digest_markdown(report)
        assert "## Actions Needed" in md
        assert "`owlmind cycle status --run-id r1`" in md

    def test_empty_report(self) -> None:
        md = format_digest_markdown(DigestReport())
        assert "# OWLMIND Daily Digest" in md
        assert "Recent Failures" not in md
        assert "Actions Needed" not in md


class TestFormatStuckText:
    def test_no_stuck(self) -> None:
        text = format_stuck_text([])
        assert "No stuck sessions found" in text

    def test_with_stuck(self) -> None:
        stuck = [
            StuckSession(
                session_id="s1",
                status="RUNNING",
                updated_at="2025-01-01T00:00:00+00:00",
                minutes_since_update=120,
                suggested_commands=["owlmind session status --session-id s1"],
            ),
        ]
        text = format_stuck_text(stuck)
        assert "1 stuck session" in text
        assert "s1" in text
        assert "120min" in text
        assert "owlmind session status" in text


# ---------------------------------------------------------------------------
# build_digest — edge cases for skipped entries
# ---------------------------------------------------------------------------


class TestBuildDigestSkipBranches:
    """Cover the 'continue' branches in build_digest for non-dir and missing meta."""

    def test_file_in_runs_dir_is_skipped(self, tmp_path: Path) -> None:
        """A plain file inside runs_dir must be skipped (not a dir)."""
        ledger_dir = tmp_path / "ledger"
        runs_dir = tmp_path / "runs"
        sessions_dir = tmp_path / "sessions"
        ledger_dir.mkdir()
        runs_dir.mkdir()

        # Place a regular file, not a directory, inside runs_dir
        (runs_dir / "not-a-dir.txt").write_text("just a file")

        report = build_digest(
            ledger_dir=ledger_dir,
            runs_dir=runs_dir,
            sessions_dir=sessions_dir,
        )

        assert report.runs_done == 0
        assert report.runs_failed == 0
        assert report.runs_other == 0

    def test_run_dir_without_meta_is_skipped(self, tmp_path: Path) -> None:
        """A run directory that has no cycle_meta.json must be skipped."""
        ledger_dir = tmp_path / "ledger"
        runs_dir = tmp_path / "runs"
        sessions_dir = tmp_path / "sessions"
        ledger_dir.mkdir()
        runs_dir.mkdir()

        # Create run dir but omit cycle_meta.json
        (runs_dir / "run-no-meta").mkdir()

        report = build_digest(
            ledger_dir=ledger_dir,
            runs_dir=runs_dir,
            sessions_dir=sessions_dir,
        )

        assert report.runs_done == 0

    def test_unknown_run_state_increments_runs_other(self, tmp_path: Path) -> None:
        """A cycle_meta.json with an unrecognised state increments runs_other."""
        ledger_dir = tmp_path / "ledger"
        runs_dir = tmp_path / "runs"
        sessions_dir = tmp_path / "sessions"
        ledger_dir.mkdir()
        runs_dir.mkdir()

        _write_run(runs_dir, "run-unknown", "SOME_UNKNOWN_STATE")

        report = build_digest(
            ledger_dir=ledger_dir,
            runs_dir=runs_dir,
            sessions_dir=sessions_dir,
        )

        assert report.runs_other == 1
        assert report.runs_done == 0
        assert report.runs_failed == 0

    def test_file_in_sessions_dir_is_skipped(self, tmp_path: Path) -> None:
        """A plain file inside sessions_dir must be skipped (not a dir)."""
        ledger_dir = tmp_path / "ledger"
        runs_dir = tmp_path / "runs"
        sessions_dir = tmp_path / "sessions"
        ledger_dir.mkdir()
        sessions_dir.mkdir()

        # Place a regular file, not a directory, inside sessions_dir
        (sessions_dir / "not-a-dir.log").write_text("just a log")

        report = build_digest(
            ledger_dir=ledger_dir,
            runs_dir=runs_dir,
            sessions_dir=sessions_dir,
        )

        assert report.sessions_done == 0
        assert report.sessions_running == 0

    def test_session_dir_without_meta_is_skipped(self, tmp_path: Path) -> None:
        """A session directory without session_meta.json must be skipped."""
        ledger_dir = tmp_path / "ledger"
        runs_dir = tmp_path / "runs"
        sessions_dir = tmp_path / "sessions"
        ledger_dir.mkdir()
        sessions_dir.mkdir()

        # Create session dir but omit session_meta.json
        (sessions_dir / "sess-no-meta").mkdir()

        report = build_digest(
            ledger_dir=ledger_dir,
            runs_dir=runs_dir,
            sessions_dir=sessions_dir,
        )

        assert report.sessions_done == 0


# ---------------------------------------------------------------------------
# detect_stuck_sessions — edge cases for skipped entries
# ---------------------------------------------------------------------------


class TestDetectStuckSessionsSkipBranches:
    """Cover the 'continue' branches in detect_stuck_sessions."""

    def test_file_in_sessions_dir_is_skipped(self, tmp_path: Path) -> None:
        """A plain file inside sessions_dir is not treated as a session."""
        sessions_dir = tmp_path / "sessions"
        sessions_dir.mkdir()

        # Place a regular file, not a directory
        (sessions_dir / "stray-file.txt").write_text("not a session")

        stuck = detect_stuck_sessions(sessions_dir, threshold_minutes=1)
        assert stuck == []

    def test_session_dir_without_meta_is_skipped(self, tmp_path: Path) -> None:
        """A session directory without session_meta.json is safely skipped."""
        sessions_dir = tmp_path / "sessions"
        sessions_dir.mkdir()

        # Create session dir but omit session_meta.json
        (sessions_dir / "sess-no-meta").mkdir()

        stuck = detect_stuck_sessions(sessions_dir, threshold_minutes=1)
        assert stuck == []

    def test_running_session_without_updated_at_is_skipped(self, tmp_path: Path) -> None:
        """A RUNNING session with no 'updated_at' field is safely skipped."""
        sessions_dir = tmp_path / "sessions"
        sessions_dir.mkdir()

        sess_dir = sessions_dir / "sess-no-ts"
        sess_dir.mkdir()
        # Write meta with status RUNNING but without updated_at
        (sess_dir / "session_meta.json").write_text(json.dumps({"status": "RUNNING"}))

        stuck = detect_stuck_sessions(sessions_dir, threshold_minutes=1)
        assert stuck == []

    def test_running_session_with_empty_updated_at_is_skipped(self, tmp_path: Path) -> None:
        """A RUNNING session with updated_at='' is safely skipped."""
        sessions_dir = tmp_path / "sessions"
        sessions_dir.mkdir()

        sess_dir = sessions_dir / "sess-empty-ts"
        sess_dir.mkdir()
        (sess_dir / "session_meta.json").write_text(
            json.dumps({"status": "RUNNING", "updated_at": ""})
        )

        stuck = detect_stuck_sessions(sessions_dir, threshold_minutes=1)
        assert stuck == []
