"""Tests for owlmind.heartbeat — polling engine."""

from __future__ import annotations

import json
import time
from pathlib import Path

from owlmind.config import HeartbeatConfig
from owlmind.events import EventBus
from owlmind.heartbeat import HeartbeatEngine
from owlmind.queue import TaskQueue


def _make_engine(
    tmp_path: Path,
    *,
    interval: int = 10,
    max_auto_starts: int = 3,
    stuck_threshold: int = 3600,
    cooldown: int = 60,
) -> HeartbeatEngine:
    config = HeartbeatConfig(
        interval_seconds=interval,
        max_auto_starts_per_hour=max_auto_starts,
        notification_cooldown_seconds=cooldown,
        stuck_threshold_seconds=stuck_threshold,
    )
    queue = TaskQueue(tmp_path / "queue.json")
    bus = EventBus()
    policies_dir = tmp_path / "policies"
    policies_dir.mkdir(exist_ok=True)
    (policies_dir / "allowlist.yaml").write_text("allowed_commands:\n  - '^echo '\n")
    (policies_dir / "policy.yaml").write_text("forbidden_patterns:\n  - 'rm -rf'\n")
    return HeartbeatEngine(
        config=config,
        queue=queue,
        event_bus=bus,
        policies_dir=policies_dir,
        runs_dir=tmp_path / "runs",
        ledger_dir=tmp_path / "ledger",
    )


class TestCanAutoStart:
    def test_initially_allowed(self, tmp_path: Path) -> None:
        engine = _make_engine(tmp_path, max_auto_starts=3)
        assert engine._can_auto_start() is True

    def test_quota_exhausted(self, tmp_path: Path) -> None:
        engine = _make_engine(tmp_path, max_auto_starts=2)
        engine._auto_starts_this_hour = [time.time(), time.time()]
        assert engine._can_auto_start() is False

    def test_old_entries_pruned(self, tmp_path: Path) -> None:
        engine = _make_engine(tmp_path, max_auto_starts=1)
        engine._auto_starts_this_hour = [time.time() - 7200]  # 2 hours ago
        assert engine._can_auto_start() is True
        assert len(engine._auto_starts_this_hour) == 0


class TestShouldNotify:
    def test_first_notification_allowed(self, tmp_path: Path) -> None:
        engine = _make_engine(tmp_path, cooldown=60)
        assert engine._should_notify("run-1") is True

    def test_cooldown_blocks_repeat(self, tmp_path: Path) -> None:
        engine = _make_engine(tmp_path, cooldown=60)
        engine._should_notify("run-1")
        assert engine._should_notify("run-1") is False

    def test_different_runs_independent(self, tmp_path: Path) -> None:
        engine = _make_engine(tmp_path, cooldown=60)
        engine._should_notify("run-1")
        assert engine._should_notify("run-2") is True


class TestCheckQueue:
    def test_empty_queue(self, tmp_path: Path) -> None:
        engine = _make_engine(tmp_path)
        messages = engine.check_queue()
        assert messages == []

    def test_pending_tasks_reported(self, tmp_path: Path) -> None:
        engine = _make_engine(tmp_path)
        engine.queue.add("Test goal", workspace=str(tmp_path))
        messages = engine.check_queue()
        assert any("1 pending" in m for m in messages)


class TestCheckStuckRuns:
    def test_no_runs(self, tmp_path: Path) -> None:
        engine = _make_engine(tmp_path)
        (tmp_path / "runs").mkdir(exist_ok=True)
        messages = engine.check_stuck_runs()
        assert messages == []

    def test_stuck_run_detected(self, tmp_path: Path) -> None:
        engine = _make_engine(tmp_path, stuck_threshold=0, cooldown=0)
        run_dir = tmp_path / "runs" / "cycle-stuck001"
        run_dir.mkdir(parents=True)
        meta = {
            "run_id": "cycle-stuck001",
            "state": "WAIT_WORKER",
            "updated_at": "2020-01-01T00:00:00+00:00",
        }
        (run_dir / "cycle_meta.json").write_text(json.dumps(meta))

        messages = engine.check_stuck_runs()
        assert any("stuck" in m.lower() for m in messages)

    def test_done_runs_ignored(self, tmp_path: Path) -> None:
        engine = _make_engine(tmp_path, stuck_threshold=0, cooldown=0)
        run_dir = tmp_path / "runs" / "cycle-done001"
        run_dir.mkdir(parents=True)
        meta = {
            "run_id": "cycle-done001",
            "state": "DONE",
            "updated_at": "2020-01-01T00:00:00+00:00",
        }
        (run_dir / "cycle_meta.json").write_text(json.dumps(meta))

        messages = engine.check_stuck_runs()
        assert messages == []

    def test_approval_pending_notification(self, tmp_path: Path) -> None:
        engine = _make_engine(tmp_path, stuck_threshold=0, cooldown=0)
        run_dir = tmp_path / "runs" / "cycle-appr001"
        run_dir.mkdir(parents=True)
        meta = {
            "run_id": "cycle-appr001",
            "state": "WAIT_APPROVAL",
            "updated_at": "2020-01-01T00:00:00+00:00",
            "extra": {"pending_approval": {"token": "abc123"}},
        }
        (run_dir / "cycle_meta.json").write_text(json.dumps(meta))

        messages = engine.check_stuck_runs()
        assert any("approval" in m.lower() for m in messages)


class TestTick:
    def test_tick_combines_checks(self, tmp_path: Path) -> None:
        engine = _make_engine(tmp_path)
        (tmp_path / "runs").mkdir(exist_ok=True)
        messages = engine.tick()
        assert isinstance(messages, list)


class TestCheckDailyBudget:
    def test_budget_ok(self, tmp_path: Path) -> None:
        from unittest.mock import MagicMock, patch

        engine = _make_engine(tmp_path)
        mock_cfg = MagicMock()
        mock_cfg.budget.max_tokens_per_day = 1_000_000
        mock_cfg.budget.max_usd_per_day = 100.0
        mock_totals = MagicMock()
        mock_totals.total_tokens = 100
        mock_totals.estimated_usd = 0.01
        with (
            patch("owlmind.config.OwlMindConfig.from_env", return_value=mock_cfg),
            patch("owlmind.ledger.UsageLedger") as mock_ledger_cls,
        ):
            mock_ledger_cls.return_value.totals_for_day.return_value = mock_totals
            ok, msg = engine._check_daily_budget()
            assert ok is True

    def test_tokens_exceeded(self, tmp_path: Path) -> None:
        from unittest.mock import MagicMock, patch

        engine = _make_engine(tmp_path)
        mock_cfg = MagicMock()
        mock_cfg.budget.max_tokens_per_day = 100
        mock_cfg.budget.max_usd_per_day = 100.0
        mock_totals = MagicMock()
        mock_totals.total_tokens = 200
        mock_totals.estimated_usd = 0.01
        with (
            patch("owlmind.config.OwlMindConfig.from_env", return_value=mock_cfg),
            patch("owlmind.ledger.UsageLedger") as mock_ledger_cls,
        ):
            mock_ledger_cls.return_value.totals_for_day.return_value = mock_totals
            ok, msg = engine._check_daily_budget()
            assert ok is False
            assert "token" in msg.lower()

    def test_usd_exceeded(self, tmp_path: Path) -> None:
        from unittest.mock import MagicMock, patch

        engine = _make_engine(tmp_path)
        mock_cfg = MagicMock()
        mock_cfg.budget.max_tokens_per_day = 1_000_000
        mock_cfg.budget.max_usd_per_day = 1.0
        mock_totals = MagicMock()
        mock_totals.total_tokens = 100
        mock_totals.estimated_usd = 5.0
        with (
            patch("owlmind.config.OwlMindConfig.from_env", return_value=mock_cfg),
            patch("owlmind.ledger.UsageLedger") as mock_ledger_cls,
        ):
            mock_ledger_cls.return_value.totals_for_day.return_value = mock_totals
            ok, msg = engine._check_daily_budget()
            assert ok is False
            assert "USD" in msg

    def test_exception_returns_ok(self, tmp_path: Path) -> None:
        from unittest.mock import patch

        engine = _make_engine(tmp_path)
        with patch("owlmind.config.OwlMindConfig.from_env", side_effect=RuntimeError("no env")):
            ok, msg = engine._check_daily_budget()
            assert ok is True
            assert "skipped" in msg.lower()


class TestAutoStartPaths:
    def test_auto_start_success(self, tmp_path: Path) -> None:
        from unittest.mock import MagicMock, patch

        engine = _make_engine(tmp_path)
        engine.queue.add("My goal", workspace=str(tmp_path))
        mock_meta = MagicMock()
        mock_meta.run_id = "cycle-abc"
        mock_mgr = MagicMock()
        mock_mgr.start.return_value = mock_meta
        with (
            patch.object(engine, "_check_daily_budget", return_value=(True, "OK")),
            patch.object(engine, "_make_cycle_manager", return_value=mock_mgr),
        ):
            msgs = engine.check_queue(auto_start=True)
            assert any("Auto-started" in m for m in msgs)

    def test_auto_start_error(self, tmp_path: Path) -> None:
        from unittest.mock import MagicMock, patch

        engine = _make_engine(tmp_path)
        engine.queue.add("My goal", workspace=str(tmp_path))
        mock_mgr = MagicMock()
        mock_mgr.start.side_effect = RuntimeError("LLM error")
        with (
            patch.object(engine, "_check_daily_budget", return_value=(True, "OK")),
            patch.object(engine, "_make_cycle_manager", return_value=mock_mgr),
        ):
            msgs = engine.check_queue(auto_start=True)
            assert any("Failed" in m for m in msgs)

    def test_budget_blocks_auto_start(self, tmp_path: Path) -> None:
        from unittest.mock import patch

        engine = _make_engine(tmp_path)
        engine.queue.add("My goal", workspace=str(tmp_path))
        with patch.object(engine, "_check_daily_budget", return_value=(False, "Over limit")):
            msgs = engine.check_queue(auto_start=True)
            assert any("Budget" in m or "limit" in m.lower() for m in msgs)

    def test_budget_warn_once(self, tmp_path: Path) -> None:
        from unittest.mock import patch

        engine = _make_engine(tmp_path)
        engine.queue.add("My goal", workspace=str(tmp_path))
        with patch.object(engine, "_check_daily_budget", return_value=(False, "Over limit")):
            engine.check_queue(auto_start=True)
            msgs = engine.check_queue(auto_start=True)
            # Second time should not re-warn
            assert not any("Budget" in m for m in msgs)


class TestStuckRunEdgeCases:
    def test_no_updated_at_skipped(self, tmp_path: Path) -> None:
        engine = _make_engine(tmp_path, stuck_threshold=0, cooldown=0)
        run_dir = tmp_path / "runs" / "cycle-notime"
        run_dir.mkdir(parents=True)
        meta = {"run_id": "cycle-notime", "state": "PLANNING"}
        (run_dir / "cycle_meta.json").write_text(json.dumps(meta))
        msgs = engine.check_stuck_runs()
        assert msgs == []

    def test_invalid_json_skipped(self, tmp_path: Path) -> None:
        engine = _make_engine(tmp_path, stuck_threshold=0, cooldown=0)
        run_dir = tmp_path / "runs" / "cycle-badjson"
        run_dir.mkdir(parents=True)
        (run_dir / "cycle_meta.json").write_text("{{not valid")
        msgs = engine.check_stuck_runs()
        assert msgs == []

    def test_failed_run_skipped(self, tmp_path: Path) -> None:
        engine = _make_engine(tmp_path, stuck_threshold=0, cooldown=0)
        run_dir = tmp_path / "runs" / "cycle-failx"
        run_dir.mkdir(parents=True)
        meta = {
            "run_id": "cycle-failx",
            "state": "FAILED",
            "updated_at": "2020-01-01T00:00:00+00:00",
        }
        (run_dir / "cycle_meta.json").write_text(json.dumps(meta))
        msgs = engine.check_stuck_runs()
        assert msgs == []


class TestRunLoop:
    def test_max_ticks(self, tmp_path: Path) -> None:
        engine = _make_engine(tmp_path, interval=0)
        (tmp_path / "runs").mkdir(exist_ok=True)
        engine.run_loop(max_ticks=2)  # should not hang

    def test_run_loop_with_auto_start(self, tmp_path: Path) -> None:
        engine = _make_engine(tmp_path, interval=0)
        (tmp_path / "runs").mkdir(exist_ok=True)
        engine.run_loop(auto_start=True, max_ticks=1)


class TestMakeCycleManager:
    def test_returns_cycle_manager_instance(self, tmp_path: Path) -> None:
        """_make_cycle_manager() must return a CycleManager (lines 64-70)."""
        from unittest.mock import MagicMock, patch

        engine = _make_engine(tmp_path)

        mock_policy = MagicMock()
        mock_evidence = MagicMock()
        mock_cycle_mgr = MagicMock()
        mock_cycle_mgr_cls = MagicMock(return_value=mock_cycle_mgr)
        mock_policy_cls = MagicMock()
        mock_policy_cls.from_directory.return_value = mock_policy
        mock_evidence_cls = MagicMock(return_value=mock_evidence)

        with (
            patch.dict(
                "sys.modules",
                {
                    "owlmind.agent.cycle": MagicMock(CycleManager=mock_cycle_mgr_cls),
                    "owlmind.evidence": MagicMock(EvidenceStore=mock_evidence_cls),
                    "owlmind.policy": MagicMock(PolicyEngine=mock_policy_cls),
                },
            ),
        ):
            result = engine._make_cycle_manager()

        assert result is mock_cycle_mgr
        mock_policy_cls.from_directory.assert_called_once_with(engine.policies_dir)
        mock_evidence_cls.assert_called_once_with(engine.runs_dir)
        mock_cycle_mgr_cls.assert_called_once_with(
            evidence=mock_evidence,
            policy=mock_policy,
            policies_dir=engine.policies_dir,
        )


class TestRunLoopLogging:
    def test_tick_messages_logged(self, tmp_path: Path) -> None:
        """Messages returned by tick() are passed to logger.info (line 224)."""
        from unittest.mock import call, patch

        engine = _make_engine(tmp_path, interval=0)
        (tmp_path / "runs").mkdir(exist_ok=True)

        tick_messages = ["Queue OK", "No stuck runs"]

        with (
            patch.object(engine, "tick", return_value=tick_messages),
            patch("owlmind.heartbeat.logger") as mock_logger,
        ):
            engine.run_loop(max_ticks=1)

        expected_calls = [
            call.info(
                "Heartbeat started (interval=%ds, auto_start=%s)",
                engine.config.interval_seconds,
                False,
            ),
            call.info("[heartbeat] %s", "Queue OK"),
            call.info("[heartbeat] %s", "No stuck runs"),
        ]
        mock_logger.info.assert_has_calls(expected_calls, any_order=False)

    def test_empty_tick_no_log_messages(self, tmp_path: Path) -> None:
        """When tick() returns no messages, only the start log is emitted."""
        from unittest.mock import patch

        engine = _make_engine(tmp_path, interval=0)
        (tmp_path / "runs").mkdir(exist_ok=True)

        with (
            patch.object(engine, "tick", return_value=[]),
            patch("owlmind.heartbeat.logger") as mock_logger,
        ):
            engine.run_loop(max_ticks=1)

        # Only the startup info call, no [heartbeat] calls
        calls = [str(c) for c in mock_logger.info.call_args_list]
        assert all("[heartbeat]" not in c for c in calls)
