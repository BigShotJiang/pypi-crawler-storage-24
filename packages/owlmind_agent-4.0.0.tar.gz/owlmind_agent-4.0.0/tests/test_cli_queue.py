"""Tests for FS69 — CLI queue commands (add, list, run)."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from owlmind.cli import app

runner = CliRunner()


def _mock_queue_item() -> MagicMock:
    """Build a mock QueueItem with all required attributes."""
    item = MagicMock()
    item.id = "task-001"
    item.goal = "test goal"
    item.workspace = "."
    item.sandbox = False
    item.status = "PENDING"
    item.run_id = None
    return item


class TestQueueAdd:
    def test_add_ok(self, tmp_path: Path) -> None:
        """queue add → exit 0, task ID in output."""
        mock_item = _mock_queue_item()
        mock_q = MagicMock()
        mock_q.return_value.add.return_value = mock_item

        with patch("owlmind.queue.TaskQueue", mock_q):
            result = runner.invoke(
                app,
                [
                    "queue",
                    "add",
                    "--goal",
                    "test goal",
                    "--queue-dir",
                    str(tmp_path / "q"),
                ],
            )

        assert result.exit_code == 0, result.output
        assert "task-001" in result.output


class TestQueueList:
    def test_list_empty(self, tmp_path: Path) -> None:
        """queue list with no items → exit 0, 'empty' in output."""
        mock_q = MagicMock()
        mock_q.return_value.list_items.return_value = []

        with patch("owlmind.queue.TaskQueue", mock_q):
            result = runner.invoke(
                app,
                ["queue", "list", "--queue-dir", str(tmp_path / "q")],
            )

        assert result.exit_code == 0
        assert "empty" in result.output.lower()

    def test_list_with_items(self, tmp_path: Path) -> None:
        """queue list with items → exit 0, item ID in output."""
        mock_item = _mock_queue_item()
        mock_q = MagicMock()
        mock_q.return_value.list_items.return_value = [mock_item]

        with patch("owlmind.queue.TaskQueue", mock_q):
            result = runner.invoke(
                app,
                ["queue", "list", "--queue-dir", str(tmp_path / "q")],
            )

        assert result.exit_code == 0, result.output


class TestQueueRun:
    def test_run_requires_flag(self, tmp_path: Path) -> None:
        """queue run without --once or --daemon → exit 1."""
        mock_q = MagicMock()

        with patch("owlmind.queue.TaskQueue", mock_q):
            result = runner.invoke(
                app,
                ["queue", "run", "--queue-dir", str(tmp_path / "q")],
            )

        assert result.exit_code == 1
        assert "--once" in result.output or "flag" in result.output.lower()

    def test_run_once_no_pending(self, tmp_path: Path) -> None:
        """queue run --once with no pending tasks → exit 0, 'No pending' in output."""
        mock_q = MagicMock()
        mock_q.return_value.next_pending.return_value = None

        with patch("owlmind.queue.TaskQueue", mock_q):
            result = runner.invoke(
                app,
                ["queue", "run", "--once", "--queue-dir", str(tmp_path / "q")],
            )

        assert result.exit_code == 0
        assert "No pending" in result.output

    def test_run_once_success(self, tmp_path: Path) -> None:
        """queue run --once with pending task → cycle started, exit 0."""
        mock_item = _mock_queue_item()
        mock_q = MagicMock()
        mock_q.return_value.next_pending.return_value = mock_item

        mock_meta = MagicMock()
        mock_meta.run_id = "run-abc-123"
        mock_mgr = MagicMock()
        mock_mgr.start.return_value = mock_meta

        with (
            patch("owlmind.queue.TaskQueue", mock_q),
            patch("owlmind.cli.queue.make_cycle_manager", return_value=(None, None, mock_mgr)),
        ):
            result = runner.invoke(
                app,
                ["queue", "run", "--once", "--queue-dir", str(tmp_path / "q")],
            )

        assert result.exit_code == 0, result.output
        assert "run-abc-123" in result.output
        mock_q.return_value.mark_running.assert_called_once_with("task-001", "run-abc-123")

    def test_run_once_cycle_exception_marks_failed(self, tmp_path: Path) -> None:
        """queue run --once when cycle raises → task marked FAILED, exit 0."""
        mock_item = _mock_queue_item()
        mock_q = MagicMock()
        mock_q.return_value.next_pending.return_value = mock_item

        mock_mgr = MagicMock()
        mock_mgr.start.side_effect = RuntimeError("cycle boom")

        with (
            patch("owlmind.queue.TaskQueue", mock_q),
            patch("owlmind.cli.queue.make_cycle_manager", return_value=(None, None, mock_mgr)),
        ):
            result = runner.invoke(
                app,
                ["queue", "run", "--once", "--queue-dir", str(tmp_path / "q")],
            )

        assert result.exit_code == 0, result.output
        assert "Failed" in result.output or "boom" in result.output
        mock_q.return_value.mark_failed.assert_called_once()


class TestQueueRunDaemon:
    def test_daemon_skips_when_budget_exceeded(self, tmp_path: Path) -> None:
        """queue run --daemon skips task when daily budget exceeded."""
        mock_q = MagicMock()
        mock_q.return_value.next_pending.return_value = None

        mock_day = MagicMock()
        mock_day.total_tokens = 10_000_000
        mock_day.estimated_usd = 999.0

        mock_ledger_inst = MagicMock()
        mock_ledger_inst.totals_for_day.return_value = mock_day
        mock_ledger_cls = MagicMock(return_value=mock_ledger_inst)

        mock_budget = MagicMock()
        mock_budget.max_tokens_per_day = 1_000
        mock_budget.max_usd_per_day = 1.0

        mock_cfg = MagicMock()
        mock_cfg.budget = mock_budget
        mock_cfg_cls = MagicMock()
        mock_cfg_cls.from_env.return_value = mock_cfg

        call_count = 0

        def _fake_sleep(interval: int) -> None:
            nonlocal call_count
            call_count += 1
            if call_count >= 1:
                raise KeyboardInterrupt

        with (
            patch("owlmind.queue.TaskQueue", mock_q),
            patch("owlmind.config.OwlMindConfig", mock_cfg_cls),
            patch("owlmind.ledger.UsageLedger", mock_ledger_cls),
            patch("time.sleep", side_effect=_fake_sleep),
        ):
            result = runner.invoke(
                app,
                [
                    "queue",
                    "run",
                    "--daemon",
                    "--interval",
                    "1",
                    "--queue-dir",
                    str(tmp_path / "q"),
                ],
            )

        assert "budget" in result.output.lower() or "exceeded" in result.output.lower()

    def test_daemon_runs_task_within_budget(self, tmp_path: Path) -> None:
        """queue run --daemon runs task when within budget then exits on interrupt."""
        mock_item = _mock_queue_item()
        mock_q = MagicMock()
        mock_q.return_value.next_pending.return_value = mock_item

        mock_meta = MagicMock()
        mock_meta.run_id = "run-daemon-001"
        mock_mgr = MagicMock()
        mock_mgr.start.return_value = mock_meta

        mock_day = MagicMock()
        mock_day.total_tokens = 0
        mock_day.estimated_usd = 0.0

        mock_ledger_inst = MagicMock()
        mock_ledger_inst.totals_for_day.return_value = mock_day
        mock_ledger_cls = MagicMock(return_value=mock_ledger_inst)

        mock_budget = MagicMock()
        mock_budget.max_tokens_per_day = 1_000_000
        mock_budget.max_usd_per_day = 100.0

        mock_cfg = MagicMock()
        mock_cfg.budget = mock_budget
        mock_cfg_cls = MagicMock()
        mock_cfg_cls.from_env.return_value = mock_cfg

        call_count = 0

        def _fake_sleep(interval: int) -> None:
            nonlocal call_count
            call_count += 1
            if call_count >= 1:
                raise KeyboardInterrupt

        with (
            patch("owlmind.queue.TaskQueue", mock_q),
            patch("owlmind.cli.queue.make_cycle_manager", return_value=(None, None, mock_mgr)),
            patch("owlmind.config.OwlMindConfig", mock_cfg_cls),
            patch("owlmind.ledger.UsageLedger", mock_ledger_cls),
            patch("time.sleep", side_effect=_fake_sleep),
        ):
            result = runner.invoke(
                app,
                [
                    "queue",
                    "run",
                    "--daemon",
                    "--interval",
                    "1",
                    "--queue-dir",
                    str(tmp_path / "q"),
                ],
            )

        assert "run-daemon-001" in result.output or "Started" in result.output
