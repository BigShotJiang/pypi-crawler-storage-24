"""Tests for setup module — init, doctor --fix."""

from __future__ import annotations

from pathlib import Path

from owlmind.setup import doctor_fix, setup_init


class TestSetupInit:
    def test_creates_dirs_and_files(self, tmp_path: Path) -> None:
        result = setup_init(tmp_path)
        assert (tmp_path / "runs").is_dir()
        assert (tmp_path / "sessions").is_dir()
        assert (tmp_path / "ledger").is_dir()
        assert (tmp_path / ".env.example").is_file()
        assert (tmp_path / "examples" / "goals_template.yaml").is_file()
        assert len(result.created_dirs) == 3
        assert len(result.created_files) == 2

    def test_idempotent(self, tmp_path: Path) -> None:
        setup_init(tmp_path)
        result = setup_init(tmp_path)
        assert len(result.created_dirs) == 0
        assert len(result.created_files) == 0
        assert len(result.skipped) == 5

    def test_env_example_has_no_secrets(self, tmp_path: Path) -> None:
        setup_init(tmp_path)
        content = (tmp_path / ".env.example").read_text()
        assert "OPENAI_API_KEY=" in content
        # No real API keys or tokens in the file
        assert "sk-" not in content
        assert "ghp_" not in content
        assert "xox" not in content

    def test_goals_template_valid_yaml(self, tmp_path: Path) -> None:
        import yaml

        setup_init(tmp_path)
        data = yaml.safe_load((tmp_path / "examples" / "goals_template.yaml").read_text())
        assert data["version"] == 2
        assert len(data["goals"]) >= 1


class TestDoctorFix:
    def test_creates_missing_dirs(self, tmp_path: Path) -> None:
        report = doctor_fix(tmp_path)
        assert (tmp_path / "runs").is_dir()
        assert (tmp_path / "sessions").is_dir()
        assert (tmp_path / "ledger").is_dir()
        assert all(f.fixed for f in report.fixes)

    def test_creates_env_example(self, tmp_path: Path) -> None:
        report = doctor_fix(tmp_path)
        assert (tmp_path / ".env.example").is_file()
        env_fix = next(f for f in report.fixes if f.name == ".env.example")
        assert env_fix.fixed
        assert env_fix.detail == "created"

    def test_idempotent(self, tmp_path: Path) -> None:
        doctor_fix(tmp_path)
        report = doctor_fix(tmp_path)
        for f in report.fixes:
            assert f.detail == "already exists"

    def test_warns_missing_env_vars(self, tmp_path: Path, monkeypatch: object) -> None:

        monkeypatch.delenv("OPENAI_API_KEY", raising=False)  # type: ignore[attr-defined]
        report = doctor_fix(tmp_path)
        assert any("OPENAI_API_KEY" in w for w in report.warnings)

    def test_does_not_touch_secrets(self, tmp_path: Path) -> None:
        report = doctor_fix(tmp_path)
        # .env.example should not contain real values
        content = (tmp_path / ".env.example").read_text()
        assert "sk-" not in content
        assert "ghp_" not in content
        # No shell commands executed (no subprocess usage in setup.py)
        for f in report.fixes:
            assert f.fixed

    def test_does_not_run_shell(self, tmp_path: Path) -> None:
        """Verify no subprocess calls are made during fix."""
        import subprocess
        from unittest.mock import patch

        with patch.object(subprocess, "run", side_effect=AssertionError("No shell!")):
            doctor_fix(tmp_path)


class TestDoctorFixReportOkWithWarnings:
    """Line 121: DoctorFixReport.ok returns False when warnings list is non-empty."""

    def test_ok_false_when_warnings(self) -> None:
        from owlmind.setup import DoctorFix, DoctorFixReport

        fix = DoctorFix(name="test-fix", fixed=True, detail="created")
        report = DoctorFixReport(fixes=[fix], warnings=["some warning"])
        assert report.ok is False

    def test_ok_true_when_no_warnings(self) -> None:
        from owlmind.setup import DoctorFix, DoctorFixReport

        fix = DoctorFix(name="test-fix", fixed=True, detail="created")
        report = DoctorFixReport(fixes=[fix], warnings=[])
        assert report.ok is True
