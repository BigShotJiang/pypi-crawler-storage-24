"""Tests for owlmind.tools.file_tools — FileTools."""

from __future__ import annotations

from pathlib import Path

import pytest

from owlmind.tools.file_tools import FileTools, WorkspaceError


@pytest.fixture
def ws(tmp_path: Path) -> FileTools:
    return FileTools(tmp_path)


# ---------------------------------------------------------------------------
# write / read
# ---------------------------------------------------------------------------


def test_write_and_read(ws: FileTools) -> None:
    r = ws.write("hello.txt", "hello world")
    assert r.success
    assert r.bytes_written == len(b"hello world")

    r2 = ws.read("hello.txt")
    assert r2.success
    assert r2.content == "hello world"
    assert r2.lines == 1


def test_write_creates_parents(ws: FileTools) -> None:
    r = ws.write("a/b/c/deep.txt", "deep")
    assert r.success
    r2 = ws.read("a/b/c/deep.txt")
    assert r2.success
    assert r2.content == "deep"


def test_read_missing(ws: FileTools) -> None:
    r = ws.read("missing.txt")
    assert not r.success
    assert "not found" in r.error.lower()


def test_read_too_large(ws: FileTools, tmp_path: Path) -> None:
    big = tmp_path / "big.txt"
    big.write_bytes(b"x" * 2000)
    ft = FileTools(tmp_path)
    r = ft.read("big.txt", max_bytes=100)
    assert not r.success
    assert "large" in r.error.lower()


# ---------------------------------------------------------------------------
# edit
# ---------------------------------------------------------------------------


def test_edit_replaces_unique_string(ws: FileTools) -> None:
    ws.write("code.py", "def foo():\n    return 1\n")
    r = ws.edit("code.py", "return 1", "return 42")
    assert r.success
    r2 = ws.read("code.py")
    assert "return 42" in r2.content
    assert "---" in r.diff  # unified diff produced


def test_edit_not_found(ws: FileTools) -> None:
    ws.write("code.py", "def foo(): pass\n")
    r = ws.edit("code.py", "DOES_NOT_EXIST", "new")
    assert not r.success
    assert "not found" in r.error


def test_edit_ambiguous(ws: FileTools) -> None:
    ws.write("code.py", "x = 1\nx = 1\n")
    r = ws.edit("code.py", "x = 1", "x = 2")
    assert not r.success
    assert "2 times" in r.error


# ---------------------------------------------------------------------------
# append
# ---------------------------------------------------------------------------


def test_append_creates_file(ws: FileTools) -> None:
    r = ws.append("new.txt", "line1\n")
    assert r.success
    r2 = ws.append("new.txt", "line2\n")
    assert r2.success
    r3 = ws.read("new.txt")
    assert r3.content == "line1\nline2\n"


# ---------------------------------------------------------------------------
# delete
# ---------------------------------------------------------------------------


def test_delete(ws: FileTools) -> None:
    ws.write("to_delete.txt", "bye")
    r = ws.delete("to_delete.txt")
    assert r.success
    assert not ws.exists("to_delete.txt")


def test_delete_missing(ws: FileTools) -> None:
    r = ws.delete("ghost.txt")
    assert not r.success


# ---------------------------------------------------------------------------
# list_dir
# ---------------------------------------------------------------------------


def test_list_dir(ws: FileTools) -> None:
    ws.write("a.py", "")
    ws.write("b.py", "")
    ws.write("sub/c.py", "")
    entries = ws.list_dir(".")
    paths = [e["path"] for e in entries]
    assert "a.py" in paths
    assert "b.py" in paths
    # non-recursive: sub/c.py should not appear
    assert "sub/c.py" not in paths


def test_list_dir_recursive(ws: FileTools) -> None:
    ws.write("sub/deep.py", "")
    entries = ws.list_dir(".", recursive=True)
    paths = [e["path"] for e in entries]
    assert any("deep.py" in p for p in paths)


# ---------------------------------------------------------------------------
# workspace escape prevention
# ---------------------------------------------------------------------------


def test_escape_raises(ws: FileTools) -> None:
    with pytest.raises(WorkspaceError):
        ws._resolve("../../etc/passwd")


def test_write_escape_returns_error(ws: FileTools) -> None:
    r = ws.write("../../evil.txt", "evil")
    assert not r.success


# ---------------------------------------------------------------------------
# write_many
# ---------------------------------------------------------------------------


def test_write_many(ws: FileTools) -> None:
    files = {
        "src/main.py": "print('hello')\n",
        "tests/test_main.py": "def test_pass(): pass\n",
    }
    results = ws.write_many(files)
    assert all(r.success for r in results)
    assert ws.is_file("src/main.py")
    assert ws.is_file("tests/test_main.py")
