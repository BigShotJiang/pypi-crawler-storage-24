"""Tests for owlmind.engine.orchestrator — state machine and task execution."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from owlmind.contracts import (
    Action,
    ActionType,
    OrchestratorState,
    PlanStep,
    RunSummary,
    TaskPlan,
    TaskSpec,
)
from owlmind.engine.orchestrator import _TRANSITIONS, Orchestrator

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_orchestrator(
    tmp_path: Path,
    *,
    policy: MagicMock | None = None,
) -> Orchestrator:
    from owlmind.evidence import EvidenceStore

    if policy is None:
        policy = MagicMock()
    evidence = EvidenceStore(tmp_path / "runs")
    return Orchestrator(policy=policy, evidence=evidence, project_dir=str(tmp_path))


def _make_task(
    *,
    task_id: str = "task-001",
    goal: str = "Run tests",
    actions: list[Action] | None = None,
) -> TaskSpec:
    return TaskSpec(
        task_id=task_id,
        goal=goal,
        actions=actions or [],
        plan=TaskPlan(steps=[PlanStep(id="s1", action="do something")]),
    )


def _successful_shell_result() -> MagicMock:
    result = MagicMock()
    result.exit_code = 0
    result.stdout = "ok"
    result.stderr = ""
    result.stdout_hash = "abc123"
    result.stderr_hash = "def456"
    result.duration_ms = 100
    result.policy_result = None
    return result


def _failed_shell_result() -> MagicMock:
    result = MagicMock()
    result.exit_code = 1
    result.stdout = ""
    result.stderr = "command failed"
    result.stdout_hash = "000"
    result.stderr_hash = "111"
    result.duration_ms = 50
    result.policy_result = None
    return result


# ---------------------------------------------------------------------------
# Tests — Transitions map
# ---------------------------------------------------------------------------


class TestTransitions:
    def test_intake_goes_to_plan(self) -> None:
        assert OrchestratorState.PLAN in _TRANSITIONS[OrchestratorState.INTAKE]

    def test_plan_goes_to_execute(self) -> None:
        assert OrchestratorState.EXECUTE in _TRANSITIONS[OrchestratorState.PLAN]

    def test_execute_goes_to_verify_or_failed(self) -> None:
        allowed = _TRANSITIONS[OrchestratorState.EXECUTE]
        assert OrchestratorState.VERIFY in allowed
        assert OrchestratorState.FAILED in allowed

    def test_done_is_terminal(self) -> None:
        assert _TRANSITIONS[OrchestratorState.DONE] == []

    def test_failed_is_terminal(self) -> None:
        assert _TRANSITIONS[OrchestratorState.FAILED] == []


# ---------------------------------------------------------------------------
# Tests — Orchestrator init
# ---------------------------------------------------------------------------


class TestOrchestratorInit:
    def test_initial_state_is_intake(self, tmp_path: Path) -> None:
        orch = _make_orchestrator(tmp_path)
        assert orch.state == OrchestratorState.INTAKE

    def test_run_id_initially_empty(self, tmp_path: Path) -> None:
        orch = _make_orchestrator(tmp_path)
        assert orch.run_id == ""

    def test_project_dir_stored(self, tmp_path: Path) -> None:
        orch = _make_orchestrator(tmp_path)
        assert orch.project_dir == str(tmp_path)

    def test_project_dir_none(self, tmp_path: Path) -> None:
        from owlmind.evidence import EvidenceStore

        orch = Orchestrator(
            policy=MagicMock(),
            evidence=EvidenceStore(tmp_path / "runs"),
        )
        assert orch.project_dir is None


# ---------------------------------------------------------------------------
# Tests — _transition
# ---------------------------------------------------------------------------


class TestTransitionMethod:
    def test_valid_transition(self, tmp_path: Path) -> None:
        orch = _make_orchestrator(tmp_path)
        orch.run_id = "test-run"
        orch.evidence.create_run("test-run")
        orch._transition(OrchestratorState.PLAN)
        assert orch.state == OrchestratorState.PLAN

    def test_invalid_transition_raises(self, tmp_path: Path) -> None:
        orch = _make_orchestrator(tmp_path)
        orch.run_id = "test-run"
        orch.evidence.create_run("test-run")
        with pytest.raises(RuntimeError, match="Invalid transition"):
            orch._transition(OrchestratorState.DONE)

    def test_transition_logs_event(self, tmp_path: Path) -> None:
        orch = _make_orchestrator(tmp_path)
        orch.run_id = "test-run"
        orch.evidence.create_run("test-run")
        orch._transition(OrchestratorState.PLAN)

        events = orch.evidence.read_events("test-run")
        state_events = [e for e in events if e.get("event") == "state_transition"]
        assert len(state_events) == 1
        assert state_events[0]["from"] == "INTAKE"
        assert state_events[0]["to"] == "PLAN"


# ---------------------------------------------------------------------------
# Tests — run() with no actions
# ---------------------------------------------------------------------------


class TestRunNoActions:
    @patch("owlmind.engine.orchestrator.ShellTool")
    def test_empty_actions_reaches_done(
        self,
        mock_shell_cls: MagicMock,
        tmp_path: Path,
    ) -> None:
        orch = _make_orchestrator(tmp_path)
        task = _make_task(actions=[])
        summary = orch.run(task)

        assert summary.state == OrchestratorState.DONE
        assert summary.actions_executed == 0
        assert summary.actions_failed == 0

    @patch("owlmind.engine.orchestrator.ShellTool")
    def test_run_generates_run_id(
        self,
        mock_shell_cls: MagicMock,
        tmp_path: Path,
    ) -> None:
        orch = _make_orchestrator(tmp_path)
        task = _make_task()
        orch.run(task)

        assert orch.run_id.startswith("run-")
        assert len(orch.run_id) > 4

    @patch("owlmind.engine.orchestrator.ShellTool")
    def test_run_returns_run_summary(
        self,
        mock_shell_cls: MagicMock,
        tmp_path: Path,
    ) -> None:
        orch = _make_orchestrator(tmp_path)
        task = _make_task()
        summary = orch.run(task)

        assert isinstance(summary, RunSummary)
        assert summary.started_at is not None
        assert summary.finished_at is not None
        assert summary.finished_at >= summary.started_at


# ---------------------------------------------------------------------------
# Tests — run() with successful actions
# ---------------------------------------------------------------------------


class TestRunSuccessfulActions:
    @patch("owlmind.engine.orchestrator.ShellTool")
    def test_single_successful_command(
        self,
        mock_shell_cls: MagicMock,
        tmp_path: Path,
    ) -> None:
        mock_shell_cls.return_value.run.return_value = _successful_shell_result()

        action = Action(
            action_id="a1",
            type=ActionType.RUN_COMMAND,
            payload={"cmd": "echo hello"},
        )
        orch = _make_orchestrator(tmp_path)
        summary = orch.run(_make_task(actions=[action]))

        assert summary.state == OrchestratorState.DONE
        assert summary.actions_executed == 1
        assert summary.actions_failed == 0

    @patch("owlmind.engine.orchestrator.ShellTool")
    def test_multiple_successful_commands(
        self,
        mock_shell_cls: MagicMock,
        tmp_path: Path,
    ) -> None:
        mock_shell_cls.return_value.run.return_value = _successful_shell_result()

        actions = [
            Action(action_id="a1", type=ActionType.RUN_COMMAND, payload={"cmd": "echo 1"}),
            Action(action_id="a2", type=ActionType.RUN_COMMAND, payload={"cmd": "echo 2"}),
        ]
        orch = _make_orchestrator(tmp_path)
        summary = orch.run(_make_task(actions=actions))

        assert summary.state == OrchestratorState.DONE
        assert summary.actions_executed == 2


# ---------------------------------------------------------------------------
# Tests — run() with failed actions
# ---------------------------------------------------------------------------


class TestRunFailedActions:
    @patch("owlmind.engine.orchestrator.ShellTool")
    def test_failed_command_reaches_failed(
        self,
        mock_shell_cls: MagicMock,
        tmp_path: Path,
    ) -> None:
        mock_shell_cls.return_value.run.return_value = _failed_shell_result()

        action = Action(
            action_id="a1",
            type=ActionType.RUN_COMMAND,
            payload={"cmd": "false"},
        )
        orch = _make_orchestrator(tmp_path)
        summary = orch.run(_make_task(actions=[action]))

        assert summary.state == OrchestratorState.FAILED
        assert summary.actions_failed == 1

    @patch("owlmind.engine.orchestrator.ShellTool")
    def test_mixed_pass_fail(
        self,
        mock_shell_cls: MagicMock,
        tmp_path: Path,
    ) -> None:
        mock_shell_cls.return_value.run.side_effect = [
            _successful_shell_result(),
            _failed_shell_result(),
        ]

        actions = [
            Action(action_id="a1", type=ActionType.RUN_COMMAND, payload={"cmd": "echo ok"}),
            Action(action_id="a2", type=ActionType.RUN_COMMAND, payload={"cmd": "false"}),
        ]
        orch = _make_orchestrator(tmp_path)
        summary = orch.run(_make_task(actions=actions))

        assert summary.state == OrchestratorState.FAILED
        assert summary.actions_failed == 1


# ---------------------------------------------------------------------------
# Tests — non-RUN_COMMAND actions (skipped)
# ---------------------------------------------------------------------------


class TestRunNonCommandActions:
    @patch("owlmind.engine.orchestrator.ShellTool")
    def test_edit_file_action_is_skipped(
        self,
        mock_shell_cls: MagicMock,
        tmp_path: Path,
    ) -> None:
        action = Action(
            action_id="a1",
            type=ActionType.EDIT_FILE,
            payload={},
        )
        orch = _make_orchestrator(tmp_path)
        summary = orch.run(_make_task(actions=[action]))

        assert summary.state == OrchestratorState.DONE
        assert summary.actions_failed == 0


# ---------------------------------------------------------------------------
# Tests — evidence persistence
# ---------------------------------------------------------------------------


class TestRunEvidence:
    @patch("owlmind.engine.orchestrator.ShellTool")
    def test_meta_persisted(
        self,
        mock_shell_cls: MagicMock,
        tmp_path: Path,
    ) -> None:
        orch = _make_orchestrator(tmp_path)
        task = _make_task(task_id="t-meta")
        orch.run(task)

        meta = orch.evidence.read_meta(orch.run_id)
        assert meta["task_id"] == "t-meta"

    @patch("owlmind.engine.orchestrator.ShellTool")
    def test_summary_persisted(
        self,
        mock_shell_cls: MagicMock,
        tmp_path: Path,
    ) -> None:
        orch = _make_orchestrator(tmp_path)
        task = _make_task(task_id="t-summary")
        orch.run(task)

        stored = orch.evidence.read_summary(orch.run_id)
        assert "report" in stored
        assert "summary" in stored

    @patch("owlmind.engine.orchestrator.ShellTool")
    def test_command_artifacts_written(
        self,
        mock_shell_cls: MagicMock,
        tmp_path: Path,
    ) -> None:
        mock_shell_cls.return_value.run.return_value = _successful_shell_result()

        action = Action(
            action_id="cmd1",
            type=ActionType.RUN_COMMAND,
            payload={"cmd": "echo hello"},
        )
        orch = _make_orchestrator(tmp_path)
        orch.run(_make_task(actions=[action]))

        run_dir = tmp_path / "runs" / orch.run_id
        assert (run_dir / "artifacts" / "cmd1_stdout.txt").exists()
        assert (run_dir / "artifacts" / "cmd1_stderr.txt").exists()

    @patch("owlmind.engine.orchestrator.ShellTool")
    def test_events_logged(
        self,
        mock_shell_cls: MagicMock,
        tmp_path: Path,
    ) -> None:
        mock_shell_cls.return_value.run.return_value = _successful_shell_result()

        action = Action(
            action_id="a1",
            type=ActionType.RUN_COMMAND,
            payload={"cmd": "echo hi"},
        )
        orch = _make_orchestrator(tmp_path)
        orch.run(_make_task(actions=[action]))

        events = orch.evidence.read_events(orch.run_id)
        event_types = [e.get("event") for e in events]
        assert "state_transition" in event_types
        assert "plan_loaded" in event_types
        assert "action_start" in event_types
        assert "action_done" in event_types
