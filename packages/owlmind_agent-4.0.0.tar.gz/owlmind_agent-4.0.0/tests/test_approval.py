"""Tests for approval token mechanism."""

from __future__ import annotations

import time
from pathlib import Path

from owlmind.agent.cycle import CycleManager
from owlmind.agent.schemas import CycleState
from owlmind.approval import ApprovalToken, create_approval, get_pending_approval, resolve_approval
from owlmind.evidence import EvidenceStore
from owlmind.policy import PolicyEngine


def _make_manager(tmp_path: Path) -> CycleManager:
    policies_dir = tmp_path / "policies"
    policies_dir.mkdir()
    (policies_dir / "allowlist.yaml").write_text('allowed_commands:\n  - "^echo "\n')
    (policies_dir / "policy.yaml").write_text('forbidden_patterns:\n  - "rm -rf"\n')
    policy = PolicyEngine.from_directory(policies_dir)
    evidence = EvidenceStore(tmp_path / "runs")
    return CycleManager(evidence=evidence, policy=policy)


class TestApprovalToken:
    def test_token_not_expired(self) -> None:
        token = ApprovalToken(
            token="abc",
            run_id="run-1",
            reason="test",
            created_at=time.time(),
            expires_at=time.time() + 3600,
        )
        assert not token.is_expired()

    def test_token_expired(self) -> None:
        token = ApprovalToken(
            token="abc",
            run_id="run-1",
            reason="test",
            created_at=time.time() - 7200,
            expires_at=time.time() - 3600,
        )
        assert token.is_expired()

    def test_to_dict_from_dict(self) -> None:
        now = time.time()
        token = ApprovalToken(
            token="xyz",
            run_id="run-2",
            reason="testing",
            created_at=now,
            expires_at=now + 3600,
        )
        d = token.to_dict()
        restored = ApprovalToken.from_dict(d)
        assert restored.token == "xyz"
        assert restored.run_id == "run-2"
        assert restored.reason == "testing"


class TestCreateApproval:
    def test_creates_token_and_sets_state(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Approval test", workspace=str(tmp_path))

        approval = create_approval(mgr.meta_store, meta.run_id, "High-risk action")
        assert len(approval.token) > 0
        assert approval.reason == "High-risk action"
        assert not approval.resolved

        updated = mgr.status(meta.run_id)
        assert updated.state == CycleState.WAIT_APPROVAL
        assert "pending_approval" in updated.extra
        assert updated.extra["pre_approval_state"] == CycleState.STARTED_WAIT_PLANNER.value

    def test_approval_logged_in_evidence(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Evidence test", workspace=str(tmp_path))
        create_approval(mgr.meta_store, meta.run_id, "test")

        events = mgr.evidence.read_events(meta.run_id)
        approval_events = [e for e in events if e.get("event") == "APPROVAL_CREATED"]
        assert len(approval_events) == 1


class TestResolveApproval:
    def test_approve_restores_state(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Test", workspace=str(tmp_path))
        approval = create_approval(mgr.meta_store, meta.run_id, "test")

        ok, msg = resolve_approval(mgr.meta_store, meta.run_id, approval.token, approved=True)
        assert ok is True
        assert "approved" in msg

        updated = mgr.status(meta.run_id)
        assert updated.state == CycleState.STARTED_WAIT_PLANNER

    def test_deny_fails_run(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Test", workspace=str(tmp_path))
        approval = create_approval(mgr.meta_store, meta.run_id, "test")

        ok, msg = resolve_approval(mgr.meta_store, meta.run_id, approval.token, approved=False)
        assert ok is True
        assert "denied" in msg

        updated = mgr.status(meta.run_id)
        assert updated.state == CycleState.FAILED

    def test_wrong_token_rejected(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Test", workspace=str(tmp_path))
        create_approval(mgr.meta_store, meta.run_id, "test")

        ok, msg = resolve_approval(mgr.meta_store, meta.run_id, "wrong-token", approved=True)
        assert ok is False
        assert "Invalid" in msg

    def test_no_pending_approval(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Test", workspace=str(tmp_path))

        ok, msg = resolve_approval(mgr.meta_store, meta.run_id, "any-token", approved=True)
        assert ok is False
        assert "No pending" in msg

    def test_expired_approval(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Test", workspace=str(tmp_path))
        approval = create_approval(mgr.meta_store, meta.run_id, "test", ttl_minutes=0)

        # Force expiry by sleeping a tiny bit
        time.sleep(0.01)

        ok, msg = resolve_approval(mgr.meta_store, meta.run_id, approval.token, approved=True)
        assert ok is False
        assert "expired" in msg.lower()

    def test_double_resolve(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Test", workspace=str(tmp_path))
        approval = create_approval(mgr.meta_store, meta.run_id, "test")

        resolve_approval(mgr.meta_store, meta.run_id, approval.token, approved=True)
        ok, msg = resolve_approval(mgr.meta_store, meta.run_id, approval.token, approved=True)
        assert ok is False
        assert "already resolved" in msg.lower()


class TestGetPendingApproval:
    def test_no_pending(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Test", workspace=str(tmp_path))
        assert get_pending_approval(mgr.meta_store, meta.run_id) is None

    def test_pending_exists(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Test", workspace=str(tmp_path))
        create_approval(mgr.meta_store, meta.run_id, "test")

        pending = get_pending_approval(mgr.meta_store, meta.run_id)
        assert pending is not None
        assert pending.reason == "test"
