"""Tests for KafkaQueueStorage (with mocked aiokafka)."""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from owlmind.queue import QueueStatus

# ---------------------------------------------------------------------------
# Helpers — import with mocked aiokafka
# ---------------------------------------------------------------------------


@pytest.fixture()
def kafka_storage(tmp_path: Path) -> Any:
    """Create a KafkaQueueStorage with a temp SQLite DB."""
    from owlmind.storage.kafka import KafkaQueueStorage

    return KafkaQueueStorage(
        bootstrap_servers="localhost:9092",
        topic="test.tasks",
        group_id="test-workers",
        state_db_path=tmp_path / "kafka_state.db",
    )


# ---------------------------------------------------------------------------
# SQLite state init
# ---------------------------------------------------------------------------


class TestKafkaStateDB:
    def test_state_db_created(self, kafka_storage: Any) -> None:
        """State DB file exists and has the queue_items table."""
        assert kafka_storage._state_db_path.exists()
        cursor = kafka_storage._db.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='queue_items'"
        )
        assert cursor.fetchone() is not None

    def test_state_db_wal_mode(self, kafka_storage: Any) -> None:
        """State DB uses WAL journal mode."""
        cursor = kafka_storage._db.execute("PRAGMA journal_mode")
        assert cursor.fetchone()[0].lower() == "wal"

    def test_item_from_row(self, kafka_storage: Any) -> None:
        """_item_from_row correctly converts SQLite row to QueueItem."""
        now = datetime.now(tz=UTC).isoformat()
        kafka_storage._db.execute(
            "INSERT INTO queue_items "
            "(id, goal, workspace, sandbox, priority, created_at, status, "
            "run_id, error, updated_at, session_id, goal_id) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            ("t-001", "test goal", "/tmp", 0, 5, now, "PENDING", "", "", now, "s-1", "g-1"),
        )
        kafka_storage._db.commit()

        row = kafka_storage._db.execute(
            "SELECT * FROM queue_items WHERE id = ?", ("t-001",)
        ).fetchone()
        item = kafka_storage._item_from_row(row)

        assert item.id == "t-001"
        assert item.goal == "test goal"
        assert item.priority == 5
        assert item.session_id == "s-1"
        assert item.goal_id == "g-1"


# ---------------------------------------------------------------------------
# add()
# ---------------------------------------------------------------------------


class TestKafkaAdd:
    @pytest.mark.asyncio()
    async def test_add_inserts_sqlite_and_produces(self, kafka_storage: Any) -> None:
        """add() inserts into SQLite and calls producer.send_and_wait()."""
        mock_producer = AsyncMock()
        kafka_storage._producer = mock_producer
        kafka_storage._consumer = AsyncMock()

        item = await kafka_storage.add("do stuff", "/work", priority=3)

        assert item.goal == "do stuff"
        assert item.priority == 3
        assert item.status == QueueStatus.PENDING

        # SQLite has the record
        row = kafka_storage._db.execute(
            "SELECT * FROM queue_items WHERE id = ?", (item.id,)
        ).fetchone()
        assert row is not None
        assert row["goal"] == "do stuff"

        # Producer was called
        mock_producer.send_and_wait.assert_awaited_once()

    @pytest.mark.asyncio()
    async def test_add_with_session_fields(self, kafka_storage: Any) -> None:
        """add() stores session_id and goal_id."""
        kafka_storage._producer = AsyncMock()
        kafka_storage._consumer = AsyncMock()

        item = await kafka_storage.add("task", "/w", session_id="sess-1", goal_id="g-2")

        assert item.session_id == "sess-1"
        assert item.goal_id == "g-2"

        row = kafka_storage._db.execute(
            "SELECT session_id, goal_id FROM queue_items WHERE id = ?", (item.id,)
        ).fetchone()
        assert row["session_id"] == "sess-1"
        assert row["goal_id"] == "g-2"

    @pytest.mark.asyncio()
    async def test_add_auto_connects(self, kafka_storage: Any) -> None:
        """add() calls connect() if not yet connected."""
        with patch.object(kafka_storage, "connect", new_callable=AsyncMock) as mock_connect:
            # After connect, mock producer
            async def _setup_mocks() -> None:
                kafka_storage._producer = AsyncMock()
                kafka_storage._consumer = AsyncMock()

            mock_connect.side_effect = _setup_mocks
            await kafka_storage.add("test", "/work")
            mock_connect.assert_awaited_once()


# ---------------------------------------------------------------------------
# list_items()
# ---------------------------------------------------------------------------


class TestKafkaListItems:
    @pytest.mark.asyncio()
    async def test_list_all(self, kafka_storage: Any) -> None:
        """list_items() returns all items."""
        kafka_storage._producer = AsyncMock()
        kafka_storage._consumer = AsyncMock()

        await kafka_storage.add("a", "/w", priority=1)
        await kafka_storage.add("b", "/w", priority=5)

        items = await kafka_storage.list_items()
        assert len(items) == 2
        # Higher priority first
        assert items[0].priority >= items[1].priority

    @pytest.mark.asyncio()
    async def test_list_by_status(self, kafka_storage: Any) -> None:
        """list_items(status=...) filters correctly."""
        kafka_storage._producer = AsyncMock()
        kafka_storage._consumer = AsyncMock()

        item = await kafka_storage.add("a", "/w")
        await kafka_storage.mark_running(item.id, "run-1")

        pending = await kafka_storage.list_items(status=QueueStatus.PENDING)
        running = await kafka_storage.list_items(status=QueueStatus.RUNNING)

        assert len(pending) == 0
        assert len(running) == 1
        assert running[0].id == item.id


# ---------------------------------------------------------------------------
# mark_running / mark_done / mark_failed
# ---------------------------------------------------------------------------


class TestKafkaMarkMethods:
    @pytest.mark.asyncio()
    async def test_mark_running(self, kafka_storage: Any) -> None:
        """mark_running() updates status and run_id."""
        kafka_storage._producer = AsyncMock()
        kafka_storage._consumer = AsyncMock()

        item = await kafka_storage.add("task", "/w")
        await kafka_storage.mark_running(item.id, "run-42")

        row = kafka_storage._db.execute(
            "SELECT status, run_id FROM queue_items WHERE id = ?", (item.id,)
        ).fetchone()
        assert row["status"] == QueueStatus.RUNNING
        assert row["run_id"] == "run-42"

    @pytest.mark.asyncio()
    async def test_mark_done(self, kafka_storage: Any) -> None:
        """mark_done() commits offset and updates status."""
        mock_consumer = AsyncMock()
        kafka_storage._producer = AsyncMock()
        kafka_storage._consumer = mock_consumer

        item = await kafka_storage.add("task", "/w")
        await kafka_storage.mark_done(item.id)

        row = kafka_storage._db.execute(
            "SELECT status FROM queue_items WHERE id = ?", (item.id,)
        ).fetchone()
        assert row["status"] == QueueStatus.DONE
        mock_consumer.commit.assert_awaited_once()

    @pytest.mark.asyncio()
    async def test_mark_failed(self, kafka_storage: Any) -> None:
        """mark_failed() commits offset, stores error, and updates status."""
        mock_consumer = AsyncMock()
        kafka_storage._producer = AsyncMock()
        kafka_storage._consumer = mock_consumer

        item = await kafka_storage.add("task", "/w")
        await kafka_storage.mark_failed(item.id, "boom")

        row = kafka_storage._db.execute(
            "SELECT status, error FROM queue_items WHERE id = ?", (item.id,)
        ).fetchone()
        assert row["status"] == QueueStatus.FAILED
        assert row["error"] == "boom"
        mock_consumer.commit.assert_awaited_once()

    @pytest.mark.asyncio()
    async def test_mark_done_handles_commit_failure(self, kafka_storage: Any) -> None:
        """mark_done() logs warning if Kafka commit fails."""
        mock_consumer = AsyncMock()
        mock_consumer.commit.side_effect = RuntimeError("kafka down")
        kafka_storage._producer = AsyncMock()
        kafka_storage._consumer = mock_consumer

        item = await kafka_storage.add("task", "/w")
        # Should not raise
        await kafka_storage.mark_done(item.id)

        row = kafka_storage._db.execute(
            "SELECT status FROM queue_items WHERE id = ?", (item.id,)
        ).fetchone()
        assert row["status"] == QueueStatus.DONE


# ---------------------------------------------------------------------------
# next_pending()
# ---------------------------------------------------------------------------


class TestKafkaNextPending:
    @pytest.mark.asyncio()
    async def test_next_pending_returns_item(self, kafka_storage: Any) -> None:
        """next_pending() consumes from Kafka and returns QueueItem."""
        kafka_storage._producer = AsyncMock()
        kafka_storage._consumer = AsyncMock()

        item = await kafka_storage.add("task", "/w")

        # Mock consumer.getone() to return a Kafka message
        mock_msg = MagicMock()
        mock_msg.value = item.to_dict()
        mock_msg.offset = 42
        kafka_storage._consumer.getone = AsyncMock(return_value=mock_msg)

        result = await kafka_storage.next_pending()
        assert result is not None
        assert result.id == item.id

    @pytest.mark.asyncio()
    async def test_next_pending_skips_done_items(self, kafka_storage: Any) -> None:
        """next_pending() skips items already DONE in SQLite."""
        kafka_storage._producer = AsyncMock()
        kafka_storage._consumer = AsyncMock()

        item = await kafka_storage.add("task", "/w")
        await kafka_storage.mark_done(item.id)

        mock_msg = MagicMock()
        mock_msg.value = item.to_dict()
        mock_msg.offset = 100
        kafka_storage._consumer.getone = AsyncMock(return_value=mock_msg)

        result = await kafka_storage.next_pending()
        assert result is None
        kafka_storage._consumer.commit.assert_awaited()

    @pytest.mark.asyncio()
    async def test_next_pending_returns_none_on_empty(self, kafka_storage: Any) -> None:
        """next_pending() returns None when consumer returns None."""
        kafka_storage._producer = AsyncMock()
        kafka_storage._consumer = AsyncMock()
        kafka_storage._consumer.getone = AsyncMock(return_value=None)

        result = await kafka_storage.next_pending()
        assert result is None


# ---------------------------------------------------------------------------
# close()
# ---------------------------------------------------------------------------


class TestKafkaClose:
    @pytest.mark.asyncio()
    async def test_close_stops_producer_and_consumer(self, kafka_storage: Any) -> None:
        """close() stops Kafka producer and consumer."""
        mock_producer = AsyncMock()
        mock_consumer = AsyncMock()
        kafka_storage._producer = mock_producer
        kafka_storage._consumer = mock_consumer

        await kafka_storage.close()

        mock_producer.stop.assert_awaited_once()
        mock_consumer.stop.assert_awaited_once()
        assert kafka_storage._producer is None
        assert kafka_storage._consumer is None

    @pytest.mark.asyncio()
    async def test_close_idempotent(self, kafka_storage: Any) -> None:
        """close() is safe to call multiple times."""
        await kafka_storage.close()
        await kafka_storage.close()  # should not raise
