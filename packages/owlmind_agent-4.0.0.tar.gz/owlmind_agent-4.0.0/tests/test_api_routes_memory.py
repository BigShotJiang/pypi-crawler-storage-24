"""Tests for memory REST endpoints (/api/v1/memory/*)."""

from __future__ import annotations

from pathlib import Path

import pytest
from starlette.testclient import TestClient

from owlmind.api.app import create_app
from owlmind.memory.store import MemoryStore

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def tmp_dirs(tmp_path: Path) -> dict[str, Path]:
    dirs = {
        "runs": tmp_path / "runs",
        "ledger": tmp_path / "ledger",
        "queue": tmp_path / "queue",
        "policies": tmp_path / "policies",
        "memory_db": tmp_path / "memory" / "memory.db",
    }
    for key, d in dirs.items():
        if key == "memory_db":
            d.parent.mkdir(parents=True, exist_ok=True)
        else:
            d.mkdir(parents=True, exist_ok=True)
    return dirs


@pytest.fixture()
def client(tmp_dirs: dict[str, Path]) -> TestClient:
    app = create_app(
        runs_dir=tmp_dirs["runs"],
        ledger_dir=tmp_dirs["ledger"],
        queue_path=tmp_dirs["queue"],
        policies_dir=tmp_dirs["policies"],
        memory_db=tmp_dirs["memory_db"],
    )
    return TestClient(app)


@pytest.fixture(autouse=True)
def _no_auth(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("owlmind.api.auth.verify_api_key", lambda: None)


@pytest.fixture()
def seeded_store(tmp_dirs: dict[str, Path]) -> MemoryStore:
    """Return a MemoryStore with sample data."""
    store = MemoryStore(tmp_dirs["memory_db"])
    store.ingest(kind="doc", source="test.py", content="def hello(): return 'hello'")
    store.add_signal(kind="lesson", summary="Always write tests", run_id="run-001")
    store.add_signal(kind="error", summary="API rate limit hit", run_id="run-002")
    store.close()
    return store


# ===========================================================================
# GET /api/v1/memory/stats
# ===========================================================================


class TestMemoryStats:
    def test_returns_200(self, client: TestClient) -> None:
        resp = client.get("/api/v1/memory/stats")
        assert resp.status_code == 200

    def test_empty_store_zero_counts(self, client: TestClient) -> None:
        resp = client.get("/api/v1/memory/stats")
        data = resp.json()
        assert data["documents"] == 0
        assert data["chunks"] == 0
        assert data["signals"] == 0

    def test_counts_increase_after_ingest(
        self, client: TestClient, seeded_store: MemoryStore
    ) -> None:
        resp = client.get("/api/v1/memory/stats")
        data = resp.json()
        assert data["documents"] >= 1
        assert data["chunks"] >= 1
        assert data["signals"] >= 2

    def test_has_docs_by_kind_field(self, client: TestClient) -> None:
        resp = client.get("/api/v1/memory/stats")
        assert "docs_by_kind" in resp.json()


# ===========================================================================
# GET /api/v1/memory/signals
# ===========================================================================


class TestGetSignals:
    def test_empty_returns_empty_list(self, client: TestClient) -> None:
        resp = client.get("/api/v1/memory/signals")
        assert resp.status_code == 200
        assert resp.json() == []

    def test_returns_all_signals(self, client: TestClient, seeded_store: MemoryStore) -> None:
        resp = client.get("/api/v1/memory/signals")
        assert resp.status_code == 200
        assert len(resp.json()) >= 2

    def test_signal_has_required_fields(
        self, client: TestClient, seeded_store: MemoryStore
    ) -> None:
        resp = client.get("/api/v1/memory/signals")
        s = resp.json()[0]
        assert "signal_id" in s
        assert "kind" in s
        assert "summary" in s
        assert "created" in s
        assert "run_id" in s

    def test_filter_by_kind(self, client: TestClient, seeded_store: MemoryStore) -> None:
        resp = client.get("/api/v1/memory/signals?kind=lesson")
        assert resp.status_code == 200
        data = resp.json()
        assert all(s["kind"] == "lesson" for s in data)

    def test_filter_by_error_kind(self, client: TestClient, seeded_store: MemoryStore) -> None:
        resp = client.get("/api/v1/memory/signals?kind=error")
        assert resp.status_code == 200
        data = resp.json()
        assert all(s["kind"] == "error" for s in data)

    def test_limit_parameter(self, client: TestClient, tmp_dirs: dict[str, Path]) -> None:
        store = MemoryStore(tmp_dirs["memory_db"])
        for i in range(10):
            store.add_signal(kind="pattern", summary=f"Pattern {i}")
        store.close()
        resp = client.get("/api/v1/memory/signals?limit=3")
        assert resp.status_code == 200
        assert len(resp.json()) <= 3


# ===========================================================================
# POST /api/v1/memory/query
# ===========================================================================


class TestQueryMemory:
    def test_empty_store_returns_empty_results(self, client: TestClient) -> None:
        resp = client.post("/api/v1/memory/query?text=hello")
        assert resp.status_code == 200
        assert resp.json() == []

    def test_returns_matching_results(self, client: TestClient, seeded_store: MemoryStore) -> None:
        resp = client.post("/api/v1/memory/query?text=hello")
        assert resp.status_code == 200
        # May return results (TF-IDF matching depends on corpus)
        assert isinstance(resp.json(), list)

    def test_result_has_required_fields(
        self, client: TestClient, seeded_store: MemoryStore
    ) -> None:
        resp = client.post("/api/v1/memory/query?text=hello")
        results = resp.json()
        if results:
            r = results[0]
            assert "chunk_id" in r
            assert "doc_id" in r
            assert "source" in r
            assert "score" in r
            assert "snippet" in r

    def test_top_k_limits_results(self, client: TestClient, tmp_dirs: dict[str, Path]) -> None:
        store = MemoryStore(tmp_dirs["memory_db"])
        for i in range(10):
            store.ingest(kind="doc", source=f"file{i}.py", content=f"def func_{i}(): return {i}")
        store.close()
        resp = client.post("/api/v1/memory/query?text=func&top_k=2")
        assert resp.status_code == 200
        assert len(resp.json()) <= 2

    def test_missing_text_returns_422(self, client: TestClient) -> None:
        resp = client.post("/api/v1/memory/query")
        assert resp.status_code == 422


# ===========================================================================
# POST /api/v1/memory/ingest
# ===========================================================================


class TestIngestDocument:
    def test_ingest_returns_201(self, client: TestClient) -> None:
        resp = client.post(
            "/api/v1/memory/ingest",
            json={"kind": "doc", "source": "test.py", "content": "def hello(): pass"},
        )
        assert resp.status_code == 201

    def test_ingest_returns_doc_id(self, client: TestClient) -> None:
        resp = client.post(
            "/api/v1/memory/ingest",
            json={"content": "some content"},
        )
        assert resp.status_code == 201
        data = resp.json()
        assert "doc_id" in data
        assert data["doc_id"].startswith("doc-")

    def test_ingest_increases_stats(self, client: TestClient) -> None:
        client.post(
            "/api/v1/memory/ingest",
            json={"kind": "doc", "source": "api", "content": "unique content for testing"},
        )
        stats = client.get("/api/v1/memory/stats").json()
        assert stats["documents"] >= 1

    def test_duplicate_content_returns_same_doc_id(self, client: TestClient) -> None:
        body = {"content": "duplicate content test"}
        resp1 = client.post("/api/v1/memory/ingest", json=body)
        resp2 = client.post("/api/v1/memory/ingest", json=body)
        assert resp1.json()["doc_id"] == resp2.json()["doc_id"]

    def test_ingest_without_content_returns_422(self, client: TestClient) -> None:
        resp = client.post("/api/v1/memory/ingest", json={"kind": "doc"})
        assert resp.status_code == 422


# ===========================================================================
# POST /api/v1/memory/signals (add signal)
# ===========================================================================


class TestAddSignal:
    def test_add_signal_returns_201(self, client: TestClient) -> None:
        resp = client.post(
            "/api/v1/memory/signals",
            json={"kind": "lesson", "summary": "Test lesson learned"},
        )
        assert resp.status_code == 201

    def test_add_signal_returns_signal_id(self, client: TestClient) -> None:
        resp = client.post(
            "/api/v1/memory/signals",
            json={"kind": "error", "summary": "Something failed"},
        )
        data = resp.json()
        assert "signal_id" in data
        assert isinstance(data["signal_id"], int)

    def test_signal_appears_in_get_signals(self, client: TestClient) -> None:
        client.post(
            "/api/v1/memory/signals",
            json={"kind": "pattern", "summary": "Always use context managers"},
        )
        resp = client.get("/api/v1/memory/signals")
        summaries = [s["summary"] for s in resp.json()]
        assert "Always use context managers" in summaries

    def test_signal_with_run_id(self, client: TestClient) -> None:
        resp = client.post(
            "/api/v1/memory/signals",
            json={"kind": "decision", "summary": "Chose approach A", "run_id": "run-xyz"},
        )
        assert resp.status_code == 201
        # Verify run_id is stored
        signals = client.get("/api/v1/memory/signals").json()
        found = next((s for s in signals if s["summary"] == "Chose approach A"), None)
        assert found is not None
        assert found["run_id"] == "run-xyz"

    def test_add_signal_missing_kind_returns_422(self, client: TestClient) -> None:
        resp = client.post(
            "/api/v1/memory/signals",
            json={"summary": "No kind provided"},
        )
        assert resp.status_code == 422


# ===========================================================================
# 500 error paths — exception in store raises HTTP 500
# ===========================================================================


class TestMemoryStatsError:
    def test_stats_store_exception_returns_500(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        """GET /memory/stats → store.stats() raises → 500."""
        from unittest.mock import MagicMock, patch

        mock_store = MagicMock()
        mock_store.stats.side_effect = RuntimeError("db locked")

        # MemoryStore is imported lazily inside _get_store(); patch at the source module.
        with patch("owlmind.memory.store.MemoryStore", return_value=mock_store):
            resp = client.get("/api/v1/memory/stats")

        assert resp.status_code == 500
        assert "stats" in resp.json()["detail"].lower() or "db locked" in resp.json()["detail"]


class TestGetSignalsError:
    def test_signals_store_exception_returns_500(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        """GET /memory/signals → store.get_signals() raises → 500."""
        from unittest.mock import MagicMock, patch

        mock_store = MagicMock()
        mock_store.get_signals.side_effect = RuntimeError("corrupt index")

        with patch("owlmind.memory.store.MemoryStore", return_value=mock_store):
            resp = client.get("/api/v1/memory/signals")

        assert resp.status_code == 500
        assert "signal" in resp.json()["detail"].lower() or "corrupt" in resp.json()["detail"]


class TestQueryMemoryError:
    def test_query_store_exception_returns_500(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        """POST /memory/query → query() raises → 500."""
        from unittest.mock import MagicMock, patch

        mock_store = MagicMock()

        with (
            patch("owlmind.memory.store.MemoryStore", return_value=mock_store),
            patch(
                "owlmind.memory.retrieval.query",
                side_effect=RuntimeError("index not ready"),
            ),
        ):
            resp = client.post("/api/v1/memory/query?text=hello")

        assert resp.status_code == 500
        assert "query" in resp.json()["detail"].lower() or "index" in resp.json()["detail"]


class TestIngestDocumentError:
    def test_ingest_store_exception_returns_500(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        """POST /memory/ingest → store.ingest() raises → 500."""
        from unittest.mock import MagicMock, patch

        mock_store = MagicMock()
        mock_store.ingest.side_effect = RuntimeError("disk full")

        with patch("owlmind.memory.store.MemoryStore", return_value=mock_store):
            resp = client.post(
                "/api/v1/memory/ingest",
                json={"content": "some content"},
            )

        assert resp.status_code == 500
        assert "ingest" in resp.json()["detail"].lower() or "disk" in resp.json()["detail"]


class TestAddSignalError:
    def test_add_signal_store_exception_returns_500(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        """POST /memory/signals → store.add_signal() raises → 500."""
        from unittest.mock import MagicMock, patch

        mock_store = MagicMock()
        mock_store.add_signal.side_effect = RuntimeError("write error")

        with patch("owlmind.memory.store.MemoryStore", return_value=mock_store):
            resp = client.post(
                "/api/v1/memory/signals",
                json={"kind": "error", "summary": "Something broke"},
            )

        assert resp.status_code == 500
        assert "signal" in resp.json()["detail"].lower() or "write" in resp.json()["detail"]


# ===========================================================================
# DELETE /api/v1/memory/signals/{signal_id}
# ===========================================================================


class TestDeleteSignal:
    def test_delete_existing_signal_returns_204(self, client: TestClient) -> None:
        resp = client.post(
            "/api/v1/memory/signals",
            json={"kind": "lesson", "summary": "To be deleted"},
        )
        assert resp.status_code == 201
        signal_id = resp.json()["signal_id"]

        del_resp = client.delete(f"/api/v1/memory/signals/{signal_id}")
        assert del_resp.status_code == 204

    def test_deleted_signal_no_longer_in_list(self, client: TestClient) -> None:
        resp = client.post(
            "/api/v1/memory/signals",
            json={"kind": "error", "summary": "Temporary error signal"},
        )
        signal_id = resp.json()["signal_id"]

        client.delete(f"/api/v1/memory/signals/{signal_id}")

        signals = client.get("/api/v1/memory/signals").json()
        ids = [s["signal_id"] for s in signals]
        assert signal_id not in ids

    def test_delete_nonexistent_signal_returns_404(self, client: TestClient) -> None:
        resp = client.delete("/api/v1/memory/signals/999999")
        assert resp.status_code == 404
        assert "999999" in resp.json()["detail"]

    def test_delete_twice_returns_404_on_second(self, client: TestClient) -> None:
        resp = client.post(
            "/api/v1/memory/signals",
            json={"kind": "pattern", "summary": "Delete me twice"},
        )
        signal_id = resp.json()["signal_id"]

        assert client.delete(f"/api/v1/memory/signals/{signal_id}").status_code == 204
        assert client.delete(f"/api/v1/memory/signals/{signal_id}").status_code == 404

    def test_delete_signal_stats_decrease(self, client: TestClient) -> None:
        client.post(
            "/api/v1/memory/signals",
            json={"kind": "decision", "summary": "Count me"},
        )
        before = client.get("/api/v1/memory/stats").json()["signals"]

        resp = client.post(
            "/api/v1/memory/signals",
            json={"kind": "decision", "summary": "Then delete me"},
        )
        signal_id = resp.json()["signal_id"]
        client.delete(f"/api/v1/memory/signals/{signal_id}")

        after = client.get("/api/v1/memory/stats").json()["signals"]
        assert after == before


class TestDeleteSignalError:
    def test_delete_signal_store_exception_returns_500(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        """DELETE /memory/signals/{id} → store.delete_signal() raises → 500."""
        from unittest.mock import MagicMock, patch

        mock_store = MagicMock()
        mock_store.delete_signal.side_effect = RuntimeError("db error")

        with patch("owlmind.memory.store.MemoryStore", return_value=mock_store):
            resp = client.delete("/api/v1/memory/signals/1")

        assert resp.status_code == 500
        assert "signal" in resp.json()["detail"].lower() or "db error" in resp.json()["detail"]
