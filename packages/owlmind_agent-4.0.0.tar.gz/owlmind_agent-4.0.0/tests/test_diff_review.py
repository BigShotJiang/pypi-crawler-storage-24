"""Tests for diff review and partial approval."""

from __future__ import annotations

from pathlib import Path

import pytest


@pytest.fixture
def workspace(tmp_path: Path) -> Path:
    ws = tmp_path / "workspace"
    ws.mkdir()
    (ws / "main.py").write_text("print('hello')\n")
    (ws / "config.yaml").write_text("key: value\n")
    (ws / "secret.env").write_text("API_KEY=abc\n")
    return ws


class TestDiffReview:
    def test_classify_risk_low(self) -> None:
        from owlmind.agent.diff_review import FileDiff, classify_risk

        diff = FileDiff(
            path="readme.md",
            old_content="# Hello",
            new_content="# Hello World",
            diff_text="",
            risk_level="",
        )
        level = classify_risk(diff)
        assert level == "low"

    def test_classify_risk_high_for_config(self) -> None:
        from owlmind.agent.diff_review import FileDiff, classify_risk

        diff = FileDiff(
            path=".env",
            old_content="KEY=old",
            new_content="KEY=new",
            diff_text="",
            risk_level="",
        )
        level = classify_risk(diff)
        assert level == "high"

    def test_classify_risk_medium_for_code(self) -> None:
        from owlmind.agent.diff_review import FileDiff, classify_risk

        # Generate diff_text with 30+ changed lines to trigger medium/high
        diff_lines = "\n".join(f"+x = {i}" for i in range(30))
        diff = FileDiff(
            path="src/app.py",
            old_content="x = 1\n" * 5,
            new_content="x = 2\n" * 50,
            diff_text=diff_lines,
            risk_level="",
        )
        level = classify_risk(diff)
        assert level in ("medium", "high")
