"""Tests for pydantic-based settings layer."""

from __future__ import annotations

import os
from pathlib import Path
from unittest.mock import patch

from owlmind.config import (
    OwlMindConfig,
    OpenAIConfig,
    TelegramConfig,
    _redact,
)


class TestRedaction:
    def test_redact_api_key(self) -> None:
        d = {"api_key": "sk-secret123", "model": "gpt-4o"}
        result = _redact(d)
        assert result["api_key"] == "***"
        assert result["model"] == "gpt-4o"

    def test_redact_empty_secret(self) -> None:
        d = {"api_key": "", "model": "gpt-4o"}
        result = _redact(d)
        assert result["api_key"] == ""

    def test_redact_bot_token(self) -> None:
        d = {"bot_token": "123:ABC", "rate_limit_seconds": 2.0}
        result = _redact(d)
        assert result["bot_token"] == "***"

    def test_redact_nested(self) -> None:
        d = {"openai": {"api_key": "sk-test", "model": "gpt-4o"}}
        result = _redact(d)
        assert result["openai"]["api_key"] == "***"
        assert result["openai"]["model"] == "gpt-4o"

    def test_redact_secret_field(self) -> None:
        d = {"secret": "my-hmac-key", "url": "https://example.com"}
        result = _redact(d)
        assert result["secret"] == "***"
        assert result["url"] == "https://example.com"


class TestPydanticModels:
    def test_telegram_model_dump(self) -> None:
        cfg = TelegramConfig(bot_token="123:ABC", allowed_chat_ids=[111, 222])
        d = cfg.model_dump()
        assert d["bot_token"] == "123:ABC"
        assert d["allowed_chat_ids"] == [111, 222]

    def test_openai_model_dump(self) -> None:
        cfg = OpenAIConfig(api_key="sk-test")
        d = cfg.model_dump()
        assert d["api_key"] == "sk-test"
        assert d["planner_model"] == "gpt-4o-2024-08-06"

    def test_config_model_dump(self) -> None:
        cfg = OwlMindConfig()
        d = cfg.model_dump()
        assert "telegram" in d
        assert "openai" in d
        assert "budget" in d


class TestRedactedDict:
    def test_redacted_dict_masks_secrets(self) -> None:
        cfg = OwlMindConfig(
            openai=OpenAIConfig(api_key="sk-real-key"),
            telegram=TelegramConfig(bot_token="123:ABC"),
        )
        d = cfg.redacted_dict()
        assert d["openai"]["api_key"] == "***"
        assert d["telegram"]["bot_token"] == "***"

    def test_redacted_dict_keeps_non_secrets(self) -> None:
        cfg = OwlMindConfig()
        d = cfg.redacted_dict()
        assert d["openai"]["planner_model"] == "gpt-4o-2024-08-06"
        assert d["budget"]["max_usd_per_day"] == 10.0


class TestSafeRepr:
    def test_repr_no_secrets(self) -> None:
        cfg = OwlMindConfig(
            openai=OpenAIConfig(api_key="sk-real-key"),
        )
        r = repr(cfg)
        assert "sk-real-key" not in r
        assert "***" in r

    def test_repr_safe_for_logging(self) -> None:
        cfg = OwlMindConfig(
            telegram=TelegramConfig(bot_token="123:TOP_SECRET"),
        )
        r = repr(cfg)
        assert "TOP_SECRET" not in r


class TestEnvPrecedence:
    def test_env_overrides_defaults(self) -> None:
        env = {
            "OWLMIND_BUDGET_MAX_USD_PER_DAY": "25.0",
            "OWLMIND_HEARTBEAT_INTERVAL": "30",
        }
        with patch.dict(os.environ, env, clear=True):
            cfg = OwlMindConfig.from_env()
        assert cfg.budget.max_usd_per_day == 25.0
        assert cfg.heartbeat.interval_seconds == 30

    def test_defaults_when_env_empty(self) -> None:
        with patch.dict(os.environ, {}, clear=True):
            cfg = OwlMindConfig.from_env()
        assert cfg.budget.max_usd_per_day == 10.0
        assert cfg.openai.planner_model == "gpt-4o-2024-08-06"


class TestListFieldParsing:
    def test_allowed_workspaces(self) -> None:
        env = {"OWLMIND_ALLOWED_WORKSPACES": "/tmp/ws,/home/user/code"}
        with patch.dict(os.environ, env, clear=True):
            cfg = OwlMindConfig.from_env()
        assert cfg.workspace.allowed_workspaces == ["/tmp/ws", "/home/user/code"]

    def test_allowed_chat_ids(self) -> None:
        env = {"TELEGRAM_ALLOWED_CHAT_IDS": "111, 222, 333"}
        with patch.dict(os.environ, env, clear=True):
            cfg = OwlMindConfig.from_env()
        assert cfg.telegram.allowed_chat_ids == [111, 222, 333]

    def test_provider_list(self) -> None:
        env = {"OWLMIND_PLANNER_PROVIDERS": "anthropic,openai,gemini"}
        with patch.dict(os.environ, env, clear=True):
            cfg = OwlMindConfig.from_env()
        assert cfg.router.planner_providers == ["anthropic", "openai", "gemini"]


class TestDotenvLoading:
    def test_dotenv_file_loaded(self, tmp_path: Path) -> None:
        env_file = tmp_path / ".env"
        env_file.write_text("OWLMIND_BUDGET_MAX_USD_PER_DAY=99.0\n")

        with patch.dict(os.environ, {}, clear=True):
            cfg = OwlMindConfig.from_env(env_file=env_file)
        assert cfg.budget.max_usd_per_day == 99.0

    def test_dotenv_no_override(self, tmp_path: Path) -> None:
        env_file = tmp_path / ".env"
        env_file.write_text("OWLMIND_BUDGET_MAX_USD_PER_DAY=99.0\n")

        with patch.dict(os.environ, {"OWLMIND_BUDGET_MAX_USD_PER_DAY": "5.0"}, clear=True):
            cfg = OwlMindConfig.from_env(env_file=env_file)
        # Real env takes precedence over .env
        assert cfg.budget.max_usd_per_day == 5.0

    def test_dotenv_comments_ignored(self, tmp_path: Path) -> None:
        env_file = tmp_path / ".env"
        env_file.write_text(
            "# This is a comment\nOWLMIND_HEARTBEAT_INTERVAL=42\n  # Another comment\n"
        )
        with patch.dict(os.environ, {}, clear=True):
            cfg = OwlMindConfig.from_env(env_file=env_file)
        assert cfg.heartbeat.interval_seconds == 42

    def test_dotenv_missing_file_ok(self, tmp_path: Path) -> None:
        with patch.dict(os.environ, {}, clear=True):
            cfg = OwlMindConfig.from_env(env_file=tmp_path / "nonexistent.env")
        assert cfg.budget.max_usd_per_day == 10.0


class TestNoSecretsInPrint:
    def test_str_no_secrets(self) -> None:
        from owlmind.config import AnthropicConfig

        cfg = OwlMindConfig(
            openai=OpenAIConfig(api_key="sk-real-key"),
            anthropic=AnthropicConfig(api_key="sk-ant-real"),
        )
        text = str(cfg.redacted_dict())
        assert "sk-real-key" not in text
        assert "sk-ant-real" not in text
