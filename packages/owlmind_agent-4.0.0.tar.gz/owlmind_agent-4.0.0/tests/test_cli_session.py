"""Tests for FS68 — CLI session commands (start, status, list, stop, export, resume, render, graph, dashboard, rollback)."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from owlmind.cli import app

runner = CliRunner()


def _mock_session_meta() -> MagicMock:
    """Build a mock SessionMeta with all required attributes."""
    meta = MagicMock()
    meta.session_id = "sess-001"
    meta.status = "DONE"
    meta.created_at = "2024-01-01T00:00:00"
    meta.goals = []
    meta.runs = []
    meta.max_concurrency = 1
    meta.continue_on_fail = False
    meta.last_block_reason = ""
    meta.current_goal_index = 0
    return meta


def _mock_run_result() -> MagicMock:
    """Build a mock SessionResult with all required attributes."""
    result = MagicMock()
    result.session_id = "sess-001"
    result.status = "DONE"
    result.goals_total = 2
    result.goals_done = 2
    result.goals_failed = 0
    result.goals_blocked = 0
    result.goals_skipped = 0
    result.last_block_reason = ""
    result.next_commands = []
    return result


class TestSessionStart:
    def test_start_file_not_found(self, tmp_path: Path) -> None:
        """session start with missing goals file → exit 1."""
        result = runner.invoke(
            app,
            ["session", "start", "--goals-file", str(tmp_path / "missing.yaml")],
        )

        assert result.exit_code == 1
        assert "not found" in result.output.lower()

    def test_start_ok(self, tmp_path: Path) -> None:
        """session start with valid goals YAML + mocks → exit 0."""
        goals_file = tmp_path / "goals.yaml"
        goals_file.write_text("goals:\n  - goal: first task\n  - goal: second task\n")

        mock_meta = _mock_session_meta()
        mock_result = _mock_run_result()

        with (
            patch("owlmind.session.create_session", return_value=mock_meta),
            patch("owlmind.session_runner.run_session", return_value=mock_result),
        ):
            result = runner.invoke(
                app,
                ["session", "start", "--goals-file", str(goals_file)],
            )

        assert result.exit_code == 0, result.output


class TestSessionStatus:
    def test_status_not_found(self) -> None:
        """session status with unknown session → exit 1."""
        with patch(
            "owlmind.session.load_session",
            side_effect=FileNotFoundError("Session not found"),
        ):
            result = runner.invoke(
                app,
                ["session", "status", "--session-id", "ghost-sess"],
            )

        assert result.exit_code == 1
        assert "not found" in result.output.lower()

    def test_status_ok(self) -> None:
        """session status with known session → exit 0, session ID in output."""
        mock_meta = _mock_session_meta()

        with patch("owlmind.session.load_session", return_value=mock_meta):
            result = runner.invoke(
                app,
                ["session", "status", "--session-id", "sess-001"],
            )

        assert result.exit_code == 0, result.output
        assert "sess-001" in result.output


class TestSessionList:
    def test_list_empty(self, tmp_path: Path) -> None:
        """session list with nonexistent sessions_dir → exit 0, 'No sessions' in output."""
        result = runner.invoke(
            app,
            ["session", "list", "--sessions-dir", str(tmp_path / "sessions")],
        )

        assert result.exit_code == 0
        assert "No sessions" in result.output

    def test_list_with_sessions(self, tmp_path: Path) -> None:
        """session list with session dirs present → exit 0."""
        sessions_dir = tmp_path / "sessions"
        sessions_dir.mkdir()
        sess_dir = sessions_dir / "sess-001"
        sess_dir.mkdir()
        (sess_dir / "session_meta.json").write_text("{}")

        mock_meta = _mock_session_meta()

        with patch("owlmind.session.load_session", return_value=mock_meta):
            result = runner.invoke(
                app,
                ["session", "list", "--sessions-dir", str(sessions_dir)],
            )

        assert result.exit_code == 0, result.output


class TestSessionStop:
    def test_stop_ok(self) -> None:
        """session stop → exit 0, 'stopped' in output."""
        mock_meta = _mock_session_meta()
        mock_meta.status = "STOPPED"

        with patch("owlmind.session_runner.stop_session", return_value=mock_meta):
            result = runner.invoke(
                app,
                ["session", "stop", "--session-id", "sess-001"],
            )

        assert result.exit_code == 0, result.output
        assert "stopped" in result.output.lower()


class TestSessionExport:
    def test_export_ok(self, tmp_path: Path) -> None:
        """session export → exit 0, zip path in output."""
        zip_path = tmp_path / "export.zip"
        zip_path.write_bytes(b"PK")  # file must exist for stat()

        with patch("owlmind.session_export.export_session", return_value=zip_path):
            result = runner.invoke(
                app,
                ["session", "export", "--session-id", "sess-001"],
            )

        assert result.exit_code == 0, result.output
        assert "Export created" in result.output
        assert zip_path.name in result.output


class TestSessionResume:
    def test_resume_ok(self) -> None:
        """session resume with a valid session → exit 0, session ID echoed."""
        mock_result = _mock_run_result()
        mock_result.status = "DONE"

        with patch("owlmind.session_runner.run_session", return_value=mock_result):
            result = runner.invoke(
                app,
                ["session", "resume", "--session-id", "sess-001"],
            )

        assert result.exit_code == 0, result.output
        assert "sess-001" in result.output

    def test_resume_file_not_found(self) -> None:
        """session resume with unknown session → exit 1, error in output."""
        with patch(
            "owlmind.session_runner.run_session",
            side_effect=FileNotFoundError("Session not found: ghost-sess"),
        ):
            result = runner.invoke(
                app,
                ["session", "resume", "--session-id", "ghost-sess"],
            )

        assert result.exit_code == 1
        assert "Error" in result.output

    def test_resume_runtime_error(self) -> None:
        """session resume that raises RuntimeError → exit 1."""
        with patch(
            "owlmind.session_runner.run_session",
            side_effect=RuntimeError("Corrupt session state"),
        ):
            result = runner.invoke(
                app,
                ["session", "resume", "--session-id", "sess-bad"],
            )

        assert result.exit_code == 1
        assert "Error" in result.output

    def test_resume_blocked_exits_2(self) -> None:
        """session resume that ends BLOCKED → exit 2."""
        mock_result = _mock_run_result()
        mock_result.status = "BLOCKED"
        mock_result.last_block_reason = "Waiting for human approval"

        with patch("owlmind.session_runner.run_session", return_value=mock_result):
            result = runner.invoke(
                app,
                ["session", "resume", "--session-id", "sess-001"],
            )

        assert result.exit_code == 2, result.output

    def test_resume_with_max_concurrency_override(self) -> None:
        """session resume --max-concurrency 3 passes override through → exit 0."""
        mock_result = _mock_run_result()
        mock_result.status = "DONE"

        with patch("owlmind.session_runner.run_session", return_value=mock_result) as mock_run:
            result = runner.invoke(
                app,
                ["session", "resume", "--session-id", "sess-001", "--max-concurrency", "3"],
            )

        assert result.exit_code == 0, result.output
        _, kwargs = mock_run.call_args
        assert kwargs.get("max_concurrency") == 3


class TestSessionRender:
    def test_render_ok(self, tmp_path: Path) -> None:
        """session render with valid session → exit 0, protocol path in output."""
        protocol_content = "# Protocol\n\nGoal 1: done\n"

        with patch(
            "owlmind.session.render_protocol",
            return_value=protocol_content,
        ):
            result = runner.invoke(
                app,
                [
                    "session",
                    "render",
                    "--session-id",
                    "sess-001",
                    "--sessions-dir",
                    str(tmp_path / "sessions"),
                ],
            )

        assert result.exit_code == 0, result.output
        assert "Protocol written" in result.output

    def test_render_file_not_found(self, tmp_path: Path) -> None:
        """session render with unknown session → exit 1, error in output."""
        with patch(
            "owlmind.session.render_protocol",
            side_effect=FileNotFoundError("Session not found: ghost-sess"),
        ):
            result = runner.invoke(
                app,
                [
                    "session",
                    "render",
                    "--session-id",
                    "ghost-sess",
                    "--sessions-dir",
                    str(tmp_path / "sessions"),
                ],
            )

        assert result.exit_code == 1
        assert "not found" in result.output.lower()

    def test_render_long_content_truncated(self, tmp_path: Path) -> None:
        """session render with long protocol → output contains truncation ellipsis."""
        long_content = "x" * 600

        with patch(
            "owlmind.session.render_protocol",
            return_value=long_content,
        ):
            result = runner.invoke(
                app,
                [
                    "session",
                    "render",
                    "--session-id",
                    "sess-001",
                    "--sessions-dir",
                    str(tmp_path / "sessions"),
                ],
            )

        assert result.exit_code == 0, result.output
        assert "..." in result.output


class TestSessionGraph:
    def _make_goal(self, goal_id: str, depends_on: list[str] | None = None) -> MagicMock:
        g = MagicMock()
        g.id = goal_id
        g.goal = f"Do {goal_id}"
        g.depends_on = depends_on or []
        return g

    def test_graph_ok(self) -> None:
        """session graph with goals → exit 0, summary in output."""
        meta = _mock_session_meta()
        meta.goals = [self._make_goal("g1"), self._make_goal("g2", depends_on=["g1"])]
        meta.runs = []

        dag_summary = "Layer 0: g1\nLayer 1: g2\n"

        with (
            patch("owlmind.session.load_session", return_value=meta),
            patch("owlmind.dag.format_dag_summary", return_value=dag_summary),
        ):
            result = runner.invoke(
                app,
                ["session", "graph", "--session-id", "sess-001"],
            )

        assert result.exit_code == 0, result.output
        assert "Layer" in result.output

    def test_graph_empty_goals(self) -> None:
        """session graph with no goals → exit 0, empty summary printed."""
        meta = _mock_session_meta()
        meta.goals = []
        meta.runs = []

        with (
            patch("owlmind.session.load_session", return_value=meta),
            patch("owlmind.dag.format_dag_summary", return_value="(empty graph)"),
        ):
            result = runner.invoke(
                app,
                ["session", "graph", "--session-id", "sess-001"],
            )

        assert result.exit_code == 0, result.output
        assert "empty graph" in result.output

    def test_graph_session_not_found(self) -> None:
        """session graph with unknown session → exit 1."""
        with patch(
            "owlmind.session.load_session",
            side_effect=FileNotFoundError("Session not found: ghost"),
        ):
            result = runner.invoke(
                app,
                ["session", "graph", "--session-id", "ghost"],
            )

        assert result.exit_code == 1
        assert "not found" in result.output.lower()


class TestSessionDashboard:
    def test_dashboard_ok(self, tmp_path: Path) -> None:
        """session dashboard → exit 0, dashboard path in output."""
        html_path = tmp_path / "dashboard.html"
        html_path.write_text("<html/>")

        with patch(
            "owlmind.session_dashboard.generate_session_dashboard",
            return_value=html_path,
        ):
            result = runner.invoke(
                app,
                ["session", "dashboard", "--session-id", "sess-001"],
            )

        assert result.exit_code == 0, result.output
        assert "Dashboard written" in result.output

    def test_dashboard_custom_out(self, tmp_path: Path) -> None:
        """session dashboard --out <path> → exit 0, custom path respected."""
        html_path = tmp_path / "custom.html"
        html_path.write_text("<html/>")

        with patch(
            "owlmind.session_dashboard.generate_session_dashboard",
            return_value=html_path,
        ) as mock_gen:
            result = runner.invoke(
                app,
                [
                    "session",
                    "dashboard",
                    "--session-id",
                    "sess-001",
                    "--out",
                    str(html_path),
                ],
            )

        assert result.exit_code == 0, result.output
        # Confirm --out value was forwarded
        _, kwargs = mock_gen.call_args
        assert kwargs.get("out") == html_path or mock_gen.call_args[0][3] == html_path

    def test_dashboard_session_not_found(self) -> None:
        """session dashboard with unknown session → exit 1."""
        with patch(
            "owlmind.session_dashboard.generate_session_dashboard",
            side_effect=FileNotFoundError("Session not found"),
        ):
            result = runner.invoke(
                app,
                ["session", "dashboard", "--session-id", "ghost-sess"],
            )

        assert result.exit_code == 1
        assert "not found" in result.output.lower()


class TestRunDashboard:
    def test_run_dashboard_ok(self, tmp_path: Path) -> None:
        """run-dashboard --run-id <id> → exit 0, dashboard path in output."""
        html_path = tmp_path / "dashboard.html"
        html_path.write_text("<html/>")

        with patch(
            "owlmind.run_dashboard.generate_run_dashboard",
            return_value=html_path,
        ):
            result = runner.invoke(
                app,
                ["session", "run-dashboard", "--run-id", "run-001"],
            )

        assert result.exit_code == 0, result.output
        assert "Dashboard written" in result.output

    def test_run_dashboard_custom_out(self, tmp_path: Path) -> None:
        """run-dashboard --run-id <id> --out <path> → exit 0."""
        html_path = tmp_path / "run.html"
        html_path.write_text("<html/>")

        with patch(
            "owlmind.run_dashboard.generate_run_dashboard",
            return_value=html_path,
        ):
            result = runner.invoke(
                app,
                [
                    "session",
                    "run-dashboard",
                    "--run-id",
                    "run-001",
                    "--out",
                    str(html_path),
                ],
            )

        assert result.exit_code == 0, result.output

    def test_run_dashboard_not_found(self) -> None:
        """run-dashboard with unknown run ID → exit 1."""
        with patch(
            "owlmind.run_dashboard.generate_run_dashboard",
            side_effect=FileNotFoundError("Run not found: ghost-run"),
        ):
            result = runner.invoke(
                app,
                ["session", "run-dashboard", "--run-id", "ghost-run"],
            )

        assert result.exit_code == 1
        assert "not found" in result.output.lower()


class TestSessionRollback:
    def _make_rollback_meta(
        self,
        *,
        mode: str = "restore",
        require_approval: bool = False,
    ) -> MagicMock:
        """Build a SessionMeta mock with one goal that has rollback config."""
        meta = _mock_session_meta()

        rollback_cfg = MagicMock()
        rollback_cfg.mode = mode
        rollback_cfg.require_approval = require_approval

        goal = MagicMock()
        goal.id = "g1"
        goal.goal = "Do something"
        goal.rollback = rollback_cfg

        run = MagicMock()
        run.goal_id = "g1"
        run.run_id = "run-001"

        meta.goals = [goal]
        meta.runs = [run]
        return meta

    def test_rollback_ok(self) -> None:
        """session rollback --yes with valid goal → exit 0, result printed."""
        meta = self._make_rollback_meta(mode="restore", require_approval=False)

        mock_request = MagicMock()
        mock_request.require_approval = False
        mock_request.approved = True

        rollback_result = {"files_restored": 3, "status": "success"}

        with (
            patch("owlmind.session.load_session", return_value=meta),
            patch("owlmind.rollback.create_rollback_request", return_value=mock_request),
            patch("owlmind.rollback.execute_rollback", return_value=rollback_result),
            patch("owlmind.rollback.log_rollback_event"),
        ):
            result = runner.invoke(
                app,
                [
                    "session",
                    "rollback",
                    "--session-id",
                    "sess-001",
                    "--goal-id",
                    "g1",
                    "--yes",
                ],
            )

        assert result.exit_code == 0, result.output
        assert "Rollback executed" in result.output

    def test_rollback_session_not_found(self) -> None:
        """session rollback with unknown session → exit 1."""
        with patch(
            "owlmind.session.load_session",
            side_effect=FileNotFoundError("Session not found: ghost"),
        ):
            result = runner.invoke(
                app,
                [
                    "session",
                    "rollback",
                    "--session-id",
                    "ghost",
                    "--goal-id",
                    "g1",
                    "--yes",
                ],
            )

        assert result.exit_code == 1
        assert "not found" in result.output.lower()

    def test_rollback_goal_not_found(self) -> None:
        """session rollback with unknown goal_id → exit 1, goal error message."""
        meta = self._make_rollback_meta()

        with patch("owlmind.session.load_session", return_value=meta):
            result = runner.invoke(
                app,
                [
                    "session",
                    "rollback",
                    "--session-id",
                    "sess-001",
                    "--goal-id",
                    "nonexistent-goal",
                    "--yes",
                ],
            )

        assert result.exit_code == 1
        assert "not found" in result.output.lower()

    def test_rollback_mode_none_exits_0(self) -> None:
        """session rollback when rollback.mode is 'none' → exit 0, no-op message."""
        meta = self._make_rollback_meta(mode="none")

        with patch("owlmind.session.load_session", return_value=meta):
            result = runner.invoke(
                app,
                [
                    "session",
                    "rollback",
                    "--session-id",
                    "sess-001",
                    "--goal-id",
                    "g1",
                    "--yes",
                ],
            )

        assert result.exit_code == 0, result.output
        assert "nothing to do" in result.output.lower()

    def test_rollback_requires_approval_without_yes_exits_2(self) -> None:
        """session rollback without --yes when approval required → exit 2."""
        meta = self._make_rollback_meta(mode="restore", require_approval=True)

        mock_request = MagicMock()
        mock_request.require_approval = True
        mock_request.approved = False
        mock_request.approval_token = "tok-abc"
        mock_request.instructions = "Run: owlmind rollback approve tok-abc"

        with (
            patch("owlmind.session.load_session", return_value=meta),
            patch("owlmind.rollback.create_rollback_request", return_value=mock_request),
            patch("owlmind.rollback.log_rollback_event"),
        ):
            result = runner.invoke(
                app,
                [
                    "session",
                    "rollback",
                    "--session-id",
                    "sess-001",
                    "--goal-id",
                    "g1",
                ],
            )

        assert result.exit_code == 2, result.output
        assert "approval" in result.output.lower()

    def test_rollback_logs_events(self) -> None:
        """session rollback should call log_rollback_event twice (requested + executed)."""
        meta = self._make_rollback_meta(mode="restore", require_approval=False)

        mock_request = MagicMock()
        mock_request.require_approval = False
        mock_request.approved = True

        rollback_result = {"status": "success"}

        with (
            patch("owlmind.session.load_session", return_value=meta),
            patch("owlmind.rollback.create_rollback_request", return_value=mock_request),
            patch("owlmind.rollback.execute_rollback", return_value=rollback_result),
            patch("owlmind.rollback.log_rollback_event") as mock_log,
        ):
            result = runner.invoke(
                app,
                [
                    "session",
                    "rollback",
                    "--session-id",
                    "sess-001",
                    "--goal-id",
                    "g1",
                    "--yes",
                ],
            )

        assert result.exit_code == 0, result.output
        assert mock_log.call_count == 2
        event_names = [call.args[2] for call in mock_log.call_args_list]
        assert "GOAL_ROLLBACK_REQUESTED" in event_names
        assert "GOAL_ROLLBACK_EXECUTED" in event_names

    def test_rollback_goal_without_run_uses_unknown_run_id(self) -> None:
        """session rollback when goal has no associated run → run_id fallback used."""
        meta = _mock_session_meta()

        rollback_cfg = MagicMock()
        rollback_cfg.mode = "restore"
        rollback_cfg.require_approval = False

        goal = MagicMock()
        goal.id = "g1"
        goal.goal = "Do something"
        goal.rollback = rollback_cfg

        # No run for g1
        meta.goals = [goal]
        meta.runs = []

        mock_request = MagicMock()
        mock_request.require_approval = False
        mock_request.approved = True

        rollback_result = {"status": "success"}

        with (
            patch("owlmind.session.load_session", return_value=meta),
            patch(
                "owlmind.rollback.create_rollback_request", return_value=mock_request
            ) as mock_create,
            patch("owlmind.rollback.execute_rollback", return_value=rollback_result),
            patch("owlmind.rollback.log_rollback_event"),
        ):
            result = runner.invoke(
                app,
                [
                    "session",
                    "rollback",
                    "--session-id",
                    "sess-001",
                    "--goal-id",
                    "g1",
                    "--yes",
                ],
            )

        assert result.exit_code == 0, result.output
        _, kwargs = mock_create.call_args
        # run_id should fall back to "unknown-g1"
        assert "unknown" in (kwargs.get("run_id") or mock_create.call_args[0][1])


# ---------------------------------------------------------------------------
# New tests for previously uncovered lines
# ---------------------------------------------------------------------------


class TestSessionStartStopOnFail:
    """Line 50: --stop-on-fail sets continue_on_fail=False."""

    def test_stop_on_fail_flag(self, tmp_path: Path) -> None:
        goals_file = tmp_path / "goals.yaml"
        goals_file.write_text("goals:\n  - goal: task one\n")
        mock_meta = _mock_session_meta()
        mock_meta.goals = []
        mock_result = _mock_run_result()
        with (
            patch("owlmind.session.create_session", return_value=mock_meta) as mock_create,
            patch("owlmind.session_runner.run_session", return_value=mock_result),
        ):
            result = runner.invoke(
                app,
                ["session", "start", "--goals-file", str(goals_file), "--stop-on-fail"],
            )
        assert result.exit_code == 0, result.output
        _, kwargs = mock_create.call_args
        assert kwargs.get("continue_on_fail") is False


class TestSessionStartCreateSessionError:
    """Lines 69-71: create_session raises ValueError or FileNotFoundError → exit 1."""

    def test_value_error(self, tmp_path: Path) -> None:
        goals_file = tmp_path / "goals.yaml"
        goals_file.write_text("goals:\n  - goal: bad\n")
        with patch("owlmind.session.create_session", side_effect=ValueError("dup ids")):
            result = runner.invoke(app, ["session", "start", "--goals-file", str(goals_file)])
        assert result.exit_code == 1

    def test_file_not_found_error(self, tmp_path: Path) -> None:
        goals_file = tmp_path / "goals.yaml"
        goals_file.write_text("goals:\n  - goal: task\n")
        with patch("owlmind.session.create_session", side_effect=FileNotFoundError("missing")):
            result = runner.invoke(app, ["session", "start", "--goals-file", str(goals_file)])
        assert result.exit_code == 1


class TestSessionStartPrintsGoalsList:
    """Line 79: goals printed for each goal in meta.goals."""

    def test_prints_goal_ids(self, tmp_path: Path) -> None:
        goals_file = tmp_path / "goals.yaml"
        goals_file.write_text("goals:\n  - goal: alpha\n  - goal: beta\n")
        mock_meta = _mock_session_meta()
        g1, g2 = MagicMock(), MagicMock()
        g1.id = "goal-alpha"
        g1.goal = "alpha"
        g2.id = "goal-beta"
        g2.goal = "beta"
        mock_meta.goals = [g1, g2]
        mock_result = _mock_run_result()
        with (
            patch("owlmind.session.create_session", return_value=mock_meta),
            patch("owlmind.session_runner.run_session", return_value=mock_result),
        ):
            result = runner.invoke(app, ["session", "start", "--goals-file", str(goals_file)])
        assert result.exit_code == 0, result.output
        assert "goal-alpha" in result.output
        assert "goal-beta" in result.output


class TestSessionStatusBlockReason:
    """Line 168: last_block_reason printed when non-empty."""

    def test_block_reason_in_output(self) -> None:
        mock_meta = _mock_session_meta()
        mock_meta.status = "BLOCKED"
        mock_meta.last_block_reason = "Needs approval XYZ"
        with patch("owlmind.session.load_session", return_value=mock_meta):
            result = runner.invoke(app, ["session", "status", "--session-id", "sess-001"])
        assert result.exit_code == 0, result.output
        assert "Needs approval XYZ" in result.output


class TestSessionStatusGoalRows:
    """Lines 179-183: goal table rows with run info."""

    def test_goal_with_run(self) -> None:
        mock_meta = _mock_session_meta()
        goal = MagicMock()
        goal.id = "g-done"
        goal.goal = "Task done"
        run = MagicMock()
        run.goal_id = "g-done"
        run.run_id = "run-abcdefgh12345678901"
        run.status = "done"
        mock_meta.goals = [goal]
        mock_meta.runs = [run]
        with patch("owlmind.session.load_session", return_value=mock_meta):
            result = runner.invoke(app, ["session", "status", "--session-id", "sess-001"])
        assert result.exit_code == 0, result.output
        assert "run-abcdefgh12345678" in result.output

    def test_goal_without_run_shows_pending(self) -> None:
        mock_meta = _mock_session_meta()
        goal = MagicMock()
        goal.id = "g-pending"
        goal.goal = "Upcoming"
        mock_meta.goals = [goal]
        mock_meta.runs = []
        with patch("owlmind.session.load_session", return_value=mock_meta):
            result = runner.invoke(app, ["session", "status", "--session-id", "sess-001"])
        assert result.exit_code == 0, result.output
        assert "pending" in result.output


class TestSessionStopNotFound:
    """Lines 202-204: stop_session raises FileNotFoundError → exit 1."""

    def test_stop_not_found(self) -> None:
        with patch(
            "owlmind.session_runner.stop_session",
            side_effect=FileNotFoundError("Session not found"),
        ):
            result = runner.invoke(app, ["session", "stop", "--session-id", "ghost"])
        assert result.exit_code == 1


class TestSessionExportNotFound:
    """Lines 230-232: export raises FileNotFoundError → exit 1."""

    def test_export_not_found(self) -> None:
        with patch(
            "owlmind.session_export.export_session",
            side_effect=FileNotFoundError("not found"),
        ):
            result = runner.invoke(app, ["session", "export", "--session-id", "ghost"])
        assert result.exit_code == 1


class TestSessionListNoSessions:
    """Lines 281-282: no session subdirs → 'No sessions found'."""

    def test_list_empty_dir(self, tmp_path: Path) -> None:
        sessions_dir = tmp_path / "sessions"
        sessions_dir.mkdir()
        result = runner.invoke(app, ["session", "list", "--sessions-dir", str(sessions_dir)])
        assert result.exit_code == 0
        assert "No sessions" in result.output


class TestSessionListBrokenMeta:
    """Lines 307-308: load_session raises → fallback '?' row."""

    def test_broken_meta_shows_fallback(self, tmp_path: Path) -> None:
        sessions_dir = tmp_path / "sessions"
        sessions_dir.mkdir()
        sdir = sessions_dir / "broken-sess"
        sdir.mkdir()
        (sdir / "session_meta.json").write_text("{invalid}")
        with patch("owlmind.session.load_session", side_effect=Exception("parse error")):
            result = runner.invoke(app, ["session", "list", "--sessions-dir", str(sessions_dir)])
        assert result.exit_code == 0
        assert "broken-sess" in result.output
