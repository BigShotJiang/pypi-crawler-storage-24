"""Tests for Stage 5: Agent Registry and Skill Pack Registry.

Covers:
- FileSkillPackRegistry: CRUD, versioning, tag filtering
- FileAgentRegistry: CRUD, heartbeat, status, listing
- StorageBackend integration with registries
- Protocol compliance
- GoalSpec/GoalRunInfo new fields (agent_id, skill_pack)
- Worker skill pack context loading
- CLI commands (skill-pack, agent)
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock

import pytest

from owlmind.registry.agents import FileAgentRegistry
from owlmind.registry.skill_packs import FileSkillPackRegistry
from owlmind.session import GoalRunInfo, GoalSpec, SessionMeta
from owlmind.storage.interface import (
    AgentRegistry,
    SkillPackRegistry,
    StorageBackend,
)

# ===================================================================
# Helpers
# ===================================================================


def _run(coro: Any) -> Any:
    """Run async coroutine synchronously."""
    return asyncio.run(coro)


@pytest.fixture()
def sp_registry(tmp_path: Path) -> FileSkillPackRegistry:
    return FileSkillPackRegistry(tmp_path / "skill_packs")


@pytest.fixture()
def ag_registry(tmp_path: Path) -> FileAgentRegistry:
    return FileAgentRegistry(tmp_path / "agents")


# ===================================================================
# FileSkillPackRegistry
# ===================================================================


class TestSkillPackRegistryRegister:
    """Register and retrieve skill packs."""

    def test_register_new_pack(self, sp_registry: FileSkillPackRegistry) -> None:
        result = _run(
            sp_registry.register_pack("code_review", name="Code Review", description="Review code")
        )
        assert result["pack_id"] == "code_review"
        assert result["name"] == "Code Review"
        assert result["description"] == "Review code"
        assert result["latest_version"] == ""
        assert result["created_at"]

    def test_register_with_tags(self, sp_registry: FileSkillPackRegistry) -> None:
        result = _run(
            sp_registry.register_pack("test_writer", name="Test Writer", tags=["testing", "qa"])
        )
        assert result["tags"] == ["testing", "qa"]

    def test_register_updates_existing(self, sp_registry: FileSkillPackRegistry) -> None:
        _run(sp_registry.register_pack("pack1", name="V1"))
        result = _run(sp_registry.register_pack("pack1", name="V2"))
        assert result["name"] == "V2"
        # created_at should be preserved
        assert result["created_at"]

    def test_get_pack(self, sp_registry: FileSkillPackRegistry) -> None:
        _run(sp_registry.register_pack("mypack", name="My Pack"))
        pack = _run(sp_registry.get_pack("mypack"))
        assert pack is not None
        assert pack["pack_id"] == "mypack"

    def test_get_nonexistent_pack(self, sp_registry: FileSkillPackRegistry) -> None:
        result = _run(sp_registry.get_pack("nonexistent"))
        assert result is None


class TestSkillPackRegistryList:
    """List and filter skill packs."""

    def test_list_empty(self, sp_registry: FileSkillPackRegistry) -> None:
        packs = _run(sp_registry.list_packs())
        assert packs == []

    def test_list_multiple(self, sp_registry: FileSkillPackRegistry) -> None:
        _run(sp_registry.register_pack("a", name="A"))
        _run(sp_registry.register_pack("b", name="B"))
        packs = _run(sp_registry.list_packs())
        assert len(packs) == 2
        ids = [p["pack_id"] for p in packs]
        assert "a" in ids
        assert "b" in ids

    def test_list_filter_by_tags(self, sp_registry: FileSkillPackRegistry) -> None:
        _run(sp_registry.register_pack("a", name="A", tags=["code"]))
        _run(sp_registry.register_pack("b", name="B", tags=["test"]))
        _run(sp_registry.register_pack("c", name="C", tags=["code", "test"]))

        code_packs = _run(sp_registry.list_packs(tags=["code"]))
        assert len(code_packs) == 2
        ids = [p["pack_id"] for p in code_packs]
        assert "a" in ids
        assert "c" in ids


class TestSkillPackRegistryVersions:
    """Publish and list versions."""

    def test_publish_version(self, sp_registry: FileSkillPackRegistry) -> None:
        _run(sp_registry.register_pack("pack1", name="Pack 1"))
        result = _run(
            sp_registry.publish_version(
                "pack1", "1.0.0", archive_key="s3://bucket/pack1-1.0.0.tar.gz", changelog="Init"
            )
        )
        assert result["version"] == "1.0.0"
        assert result["archive_key"] == "s3://bucket/pack1-1.0.0.tar.gz"
        assert result["changelog"] == "Init"

        # Check latest_version updated
        pack = _run(sp_registry.get_pack("pack1"))
        assert pack is not None
        assert pack["latest_version"] == "1.0.0"

    def test_publish_version_nonexistent_pack(self, sp_registry: FileSkillPackRegistry) -> None:
        with pytest.raises(FileNotFoundError, match="Skill pack not found"):
            _run(sp_registry.publish_version("nonexistent", "1.0.0"))

    def test_list_versions(self, sp_registry: FileSkillPackRegistry) -> None:
        _run(sp_registry.register_pack("pack1", name="Pack 1"))
        _run(sp_registry.publish_version("pack1", "1.0.0"))
        _run(sp_registry.publish_version("pack1", "1.1.0"))

        versions = _run(sp_registry.list_versions("pack1"))
        assert len(versions) == 2
        assert versions[0]["version"] == "1.0.0"
        assert versions[1]["version"] == "1.1.0"

    def test_get_version(self, sp_registry: FileSkillPackRegistry) -> None:
        _run(sp_registry.register_pack("pack1", name="Pack 1"))
        _run(sp_registry.publish_version("pack1", "2.0.0", sha256="abc123"))

        v = _run(sp_registry.get_version("pack1", "2.0.0"))
        assert v is not None
        assert v["sha256"] == "abc123"

    def test_get_version_nonexistent(self, sp_registry: FileSkillPackRegistry) -> None:
        _run(sp_registry.register_pack("pack1", name="Pack 1"))
        v = _run(sp_registry.get_version("pack1", "999.0.0"))
        assert v is None

    def test_list_versions_empty(self, sp_registry: FileSkillPackRegistry) -> None:
        _run(sp_registry.register_pack("pack1", name="Pack 1"))
        versions = _run(sp_registry.list_versions("pack1"))
        assert versions == []


class TestSkillPackRegistryDelete:
    """Delete skill packs."""

    def test_delete_existing(self, sp_registry: FileSkillPackRegistry) -> None:
        _run(sp_registry.register_pack("pack1", name="P1"))
        deleted = _run(sp_registry.delete_pack("pack1"))
        assert deleted is True
        assert _run(sp_registry.get_pack("pack1")) is None

    def test_delete_nonexistent(self, sp_registry: FileSkillPackRegistry) -> None:
        deleted = _run(sp_registry.delete_pack("nonexistent"))
        assert deleted is False


# ===================================================================
# FileAgentRegistry
# ===================================================================


class TestAgentRegistryRegister:
    """Register and retrieve agents."""

    def test_register_new_agent(self, ag_registry: FileAgentRegistry) -> None:
        result = _run(ag_registry.register_agent("worker-001", hostname="host1", max_concurrent=4))
        assert result["agent_id"] == "worker-001"
        assert result["hostname"] == "host1"
        assert result["max_concurrent"] == 4
        assert result["status"] == "idle"
        assert result["current_tasks"] == 0

    def test_register_with_capabilities(self, ag_registry: FileAgentRegistry) -> None:
        result = _run(
            ag_registry.register_agent("worker-002", capabilities=["code_review", "testing"])
        )
        assert result["capabilities"] == ["code_review", "testing"]

    def test_get_agent(self, ag_registry: FileAgentRegistry) -> None:
        _run(ag_registry.register_agent("a1", hostname="h1"))
        agent = _run(ag_registry.get_agent("a1"))
        assert agent is not None
        assert agent["hostname"] == "h1"

    def test_get_nonexistent_agent(self, ag_registry: FileAgentRegistry) -> None:
        result = _run(ag_registry.get_agent("nonexistent"))
        assert result is None


class TestAgentRegistryHeartbeat:
    """Heartbeat updates."""

    def test_heartbeat_updates_timestamp(self, ag_registry: FileAgentRegistry) -> None:
        _run(ag_registry.register_agent("a1"))
        agent_before = _run(ag_registry.get_agent("a1"))
        assert agent_before is not None

        _run(ag_registry.heartbeat("a1"))
        agent_after = _run(ag_registry.get_agent("a1"))
        assert agent_after is not None
        # Heartbeat should update (or at least not be empty)
        assert agent_after["last_heartbeat"]

    def test_heartbeat_nonexistent_raises(self, ag_registry: FileAgentRegistry) -> None:
        with pytest.raises(FileNotFoundError, match="Agent not found"):
            _run(ag_registry.heartbeat("nonexistent"))


class TestAgentRegistryStatus:
    """Status and task count updates."""

    def test_set_status(self, ag_registry: FileAgentRegistry) -> None:
        _run(ag_registry.register_agent("a1"))
        _run(ag_registry.set_status("a1", "busy", current_tasks=3))
        agent = _run(ag_registry.get_agent("a1"))
        assert agent is not None
        assert agent["status"] == "busy"
        assert agent["current_tasks"] == 3

    def test_set_status_nonexistent_raises(self, ag_registry: FileAgentRegistry) -> None:
        with pytest.raises(FileNotFoundError, match="Agent not found"):
            _run(ag_registry.set_status("nonexistent", "idle"))


class TestAgentRegistryList:
    """List and filter agents."""

    def test_list_empty(self, ag_registry: FileAgentRegistry) -> None:
        agents = _run(ag_registry.list_agents())
        assert agents == []

    def test_list_multiple(self, ag_registry: FileAgentRegistry) -> None:
        _run(ag_registry.register_agent("a1"))
        _run(ag_registry.register_agent("a2"))
        agents = _run(ag_registry.list_agents())
        assert len(agents) == 2

    def test_list_filter_by_status(self, ag_registry: FileAgentRegistry) -> None:
        _run(ag_registry.register_agent("a1"))
        _run(ag_registry.register_agent("a2"))
        _run(ag_registry.set_status("a1", "busy"))

        busy = _run(ag_registry.list_agents(status="busy"))
        assert len(busy) == 1
        assert busy[0]["agent_id"] == "a1"

        idle = _run(ag_registry.list_agents(status="idle"))
        assert len(idle) == 1
        assert idle[0]["agent_id"] == "a2"


class TestAgentRegistryDeregister:
    """Deregister agents."""

    def test_deregister_existing(self, ag_registry: FileAgentRegistry) -> None:
        _run(ag_registry.register_agent("a1"))
        _run(ag_registry.deregister("a1"))
        assert _run(ag_registry.get_agent("a1")) is None

    def test_deregister_nonexistent_no_error(self, ag_registry: FileAgentRegistry) -> None:
        # Should not raise
        _run(ag_registry.deregister("nonexistent"))


# ===================================================================
# Protocol compliance
# ===================================================================


class TestProtocolCompliance:
    """Verify implementations satisfy Protocol interfaces."""

    def test_skill_pack_registry_protocol(self, sp_registry: FileSkillPackRegistry) -> None:
        assert isinstance(sp_registry, SkillPackRegistry)

    def test_agent_registry_protocol(self, ag_registry: FileAgentRegistry) -> None:
        assert isinstance(ag_registry, AgentRegistry)


# ===================================================================
# StorageBackend integration
# ===================================================================


class TestStorageBackendRegistries:
    """StorageBackend includes registry fields."""

    def test_default_registries_none(self) -> None:
        """New fields default to None."""
        mock_runs = MagicMock()
        mock_ledger = MagicMock()
        mock_queue = MagicMock()
        mock_sessions = MagicMock()

        backend = StorageBackend(
            runs=mock_runs,
            ledger=mock_ledger,
            queue=mock_queue,
            sessions=mock_sessions,
        )
        assert backend.skill_pack_registry is None
        assert backend.agent_registry is None

    def test_registries_set(self, tmp_path: Path) -> None:
        """Registries can be set on StorageBackend."""
        sp = FileSkillPackRegistry(tmp_path / "sp")
        ag = FileAgentRegistry(tmp_path / "ag")

        backend = StorageBackend(
            runs=MagicMock(),
            ledger=MagicMock(),
            queue=MagicMock(),
            sessions=MagicMock(),
            skill_pack_registry=sp,
            agent_registry=ag,
        )
        assert backend.skill_pack_registry is sp
        assert backend.agent_registry is ag


class TestCreateStorageRegistries:
    """create_storage() populates registries."""

    def test_file_backend_has_registries(self, tmp_path: Path) -> None:
        from owlmind.storage import create_storage

        storage = create_storage(
            backend="file",
            runs_dir=tmp_path / "runs",
            ledger_dir=tmp_path / "ledger",
            queue_dir=tmp_path / "queue",
            sessions_dir=tmp_path / "sessions",
        )
        assert storage.skill_pack_registry is not None
        assert storage.agent_registry is not None
        assert isinstance(storage.skill_pack_registry, SkillPackRegistry)
        assert isinstance(storage.agent_registry, AgentRegistry)


# ===================================================================
# GoalSpec / GoalRunInfo new fields
# ===================================================================


class TestGoalSpecNewFields:
    """GoalSpec has agent_id and skill_pack fields."""

    def test_defaults(self) -> None:
        goal = GoalSpec(id="G1", goal="Test")
        assert goal.agent_id == ""
        assert goal.skill_pack == ""

    def test_set_values(self) -> None:
        goal = GoalSpec(id="G1", goal="Test", agent_id="worker-001", skill_pack="code_review")
        assert goal.agent_id == "worker-001"
        assert goal.skill_pack == "code_review"

    def test_asdict_includes_new_fields(self) -> None:
        from dataclasses import asdict

        goal = GoalSpec(id="G1", goal="Test", agent_id="w1", skill_pack="sp1")
        d = asdict(goal)
        assert d["agent_id"] == "w1"
        assert d["skill_pack"] == "sp1"


class TestGoalRunInfoNewFields:
    """GoalRunInfo has agent_id field."""

    def test_default(self) -> None:
        run = GoalRunInfo(goal_id="G1", run_id="run-001")
        assert run.agent_id == ""

    def test_set_value(self) -> None:
        run = GoalRunInfo(goal_id="G1", run_id="run-001", agent_id="worker-001")
        assert run.agent_id == "worker-001"


class TestSessionMetaSerialization:
    """Session meta serialization includes new fields."""

    def test_save_load_with_new_fields(self, tmp_path: Path) -> None:
        from owlmind.session import load_session, save_session

        sessions_dir = tmp_path / "sessions"
        sessions_dir.mkdir()

        meta = SessionMeta(
            session_id="sess-test",
            created_at="2026-01-01T00:00:00",
            updated_at="2026-01-01T00:00:00",
            status="RUNNING",
            goals=[
                GoalSpec(
                    id="G1", goal="Review code", agent_id="worker-001", skill_pack="code_review"
                ),
            ],
            runs=[
                GoalRunInfo(goal_id="G1", run_id="run-001", agent_id="worker-001"),
            ],
        )

        save_session(meta, sessions_dir)
        loaded = load_session("sess-test", sessions_dir)

        assert loaded.goals[0].agent_id == "worker-001"
        assert loaded.goals[0].skill_pack == "code_review"
        assert loaded.runs[0].agent_id == "worker-001"


class TestResolveGoalsNewFields:
    """resolve_goals() passes agent_id and skill_pack."""

    def test_resolve_with_new_fields(self) -> None:
        from owlmind.session import resolve_goals

        goals = resolve_goals(
            defaults={"agent_id": "default-agent"},
            goals_raw=[
                {"id": "G1", "goal": "Task 1", "skill_pack": "code_review"},
                {"id": "G2", "goal": "Task 2", "agent_id": "special-agent"},
            ],
            base_workspace="/tmp",
        )

        assert goals[0].agent_id == "default-agent"
        assert goals[0].skill_pack == "code_review"
        assert goals[1].agent_id == "special-agent"
        assert goals[1].skill_pack == ""


# ===================================================================
# Worker integration
# ===================================================================


class TestWorkerSkillPackIntegration:
    """Worker loads skill pack context."""

    def test_load_skill_pack_context_empty(self) -> None:
        """No skill pack → empty context."""
        from owlmind.worker.worker import WorkerConfig, WorkerService

        storage = MagicMock(spec=StorageBackend)
        storage.agent_registry = None
        config = WorkerConfig()
        worker = WorkerService(storage, config)
        assert worker._load_skill_pack_context("") == ""

    def test_load_skill_pack_context_no_dir(self) -> None:
        """No skill_packs_dir → empty context."""
        from owlmind.worker.worker import WorkerConfig, WorkerService

        storage = MagicMock(spec=StorageBackend)
        storage.agent_registry = None
        config = WorkerConfig(skill_packs_dir="")
        worker = WorkerService(storage, config)
        assert worker._load_skill_pack_context("code_review") == ""

    def test_load_skill_pack_context_pack_exists(self, tmp_path: Path) -> None:
        """Existing pack → context string."""
        from owlmind.worker.worker import WorkerConfig, WorkerService

        # Create a minimal skill pack
        pack_dir = tmp_path / "packs" / "mypack"
        pack_dir.mkdir(parents=True)
        (pack_dir / "pack.yaml").write_text(
            "id: mypack\nname: My Pack\nversion: '1.0'\ndescription: Test pack\n"
        )
        prompts_dir = pack_dir / "prompts"
        prompts_dir.mkdir()
        (prompts_dir / "system_prompt.md").write_text("You are a test assistant.")

        storage = MagicMock(spec=StorageBackend)
        storage.agent_registry = None
        config = WorkerConfig(skill_packs_dir=str(tmp_path / "packs"))
        worker = WorkerService(storage, config)
        context = worker._load_skill_pack_context("mypack")
        assert "My Pack" in context
        assert "test assistant" in context


class TestWorkerAgentConfig:
    """Worker config includes agent_id and skill_packs_dir."""

    def test_default_agent_id(self) -> None:
        from owlmind.worker.worker import WorkerConfig

        config = WorkerConfig()
        assert config.agent_id == ""
        assert config.skill_packs_dir == ""

    def test_custom_agent_id(self) -> None:
        from owlmind.worker.worker import WorkerConfig

        config = WorkerConfig(agent_id="w-001", skill_packs_dir="/packs")
        assert config.agent_id == "w-001"
        assert config.skill_packs_dir == "/packs"


# ===================================================================
# CLI commands
# ===================================================================


class TestSkillPackCLI:
    """Skill pack CLI commands."""

    def test_list_empty(self, tmp_path: Path) -> None:
        from typer.testing import CliRunner

        from owlmind.cli.skillpack_cmd import skillpack_app

        runner = CliRunner()
        result = runner.invoke(
            skillpack_app,
            [
                "list",
                "--sessions-dir",
                str(tmp_path / "sessions"),
                "--runs-dir",
                str(tmp_path / "runs"),
                "--ledger-dir",
                str(tmp_path / "ledger"),
                "--queue-dir",
                str(tmp_path / "queue"),
            ],
        )
        assert result.exit_code == 0
        assert "No skill packs registered" in result.output

    def test_register_and_list(self, tmp_path: Path) -> None:
        from typer.testing import CliRunner

        from owlmind.cli.skillpack_cmd import skillpack_app

        runner = CliRunner()
        base_args = [
            "--sessions-dir",
            str(tmp_path / "sessions"),
            "--runs-dir",
            str(tmp_path / "runs"),
            "--ledger-dir",
            str(tmp_path / "ledger"),
            "--queue-dir",
            str(tmp_path / "queue"),
        ]

        # Register
        result = runner.invoke(
            skillpack_app,
            ["register", "test_pack", "--name", "Test Pack", *base_args],
        )
        assert result.exit_code == 0
        assert "Registered" in result.output

        # List
        result = runner.invoke(skillpack_app, ["list", *base_args])
        assert result.exit_code == 0
        assert "test_pack" in result.output

    def test_info_not_found(self, tmp_path: Path) -> None:
        from typer.testing import CliRunner

        from owlmind.cli.skillpack_cmd import skillpack_app

        runner = CliRunner()
        result = runner.invoke(
            skillpack_app,
            [
                "info",
                "nonexistent",
                "--sessions-dir",
                str(tmp_path / "sessions"),
                "--runs-dir",
                str(tmp_path / "runs"),
                "--ledger-dir",
                str(tmp_path / "ledger"),
                "--queue-dir",
                str(tmp_path / "queue"),
            ],
        )
        assert result.exit_code == 1


class TestAgentCLI:
    """Agent CLI commands."""

    def test_list_empty(self, tmp_path: Path) -> None:
        from typer.testing import CliRunner

        from owlmind.cli.agent_cmd import agent_app

        runner = CliRunner()
        result = runner.invoke(
            agent_app,
            [
                "list",
                "--sessions-dir",
                str(tmp_path / "sessions"),
                "--runs-dir",
                str(tmp_path / "runs"),
                "--ledger-dir",
                str(tmp_path / "ledger"),
                "--queue-dir",
                str(tmp_path / "queue"),
            ],
        )
        assert result.exit_code == 0
        assert "No agents registered" in result.output

    def test_register_and_list(self, tmp_path: Path) -> None:
        from typer.testing import CliRunner

        from owlmind.cli.agent_cmd import agent_app

        runner = CliRunner()
        base_args = [
            "--sessions-dir",
            str(tmp_path / "sessions"),
            "--runs-dir",
            str(tmp_path / "runs"),
            "--ledger-dir",
            str(tmp_path / "ledger"),
            "--queue-dir",
            str(tmp_path / "queue"),
        ]

        # Register
        result = runner.invoke(
            agent_app,
            ["register", "worker-001", "--hostname", "host1", *base_args],
        )
        assert result.exit_code == 0
        assert "Registered agent" in result.output

        # List
        result = runner.invoke(agent_app, ["list", *base_args])
        assert result.exit_code == 0
        assert "worker-001" in result.output

    def test_info_not_found(self, tmp_path: Path) -> None:
        from typer.testing import CliRunner

        from owlmind.cli.agent_cmd import agent_app

        runner = CliRunner()
        result = runner.invoke(
            agent_app,
            [
                "info",
                "nonexistent",
                "--sessions-dir",
                str(tmp_path / "sessions"),
                "--runs-dir",
                str(tmp_path / "runs"),
                "--ledger-dir",
                str(tmp_path / "ledger"),
                "--queue-dir",
                str(tmp_path / "queue"),
            ],
        )
        assert result.exit_code == 1

    def test_deregister(self, tmp_path: Path) -> None:
        from typer.testing import CliRunner

        from owlmind.cli.agent_cmd import agent_app

        runner = CliRunner()
        base_args = [
            "--sessions-dir",
            str(tmp_path / "sessions"),
            "--runs-dir",
            str(tmp_path / "runs"),
            "--ledger-dir",
            str(tmp_path / "ledger"),
            "--queue-dir",
            str(tmp_path / "queue"),
        ]

        # Register then deregister
        runner.invoke(agent_app, ["register", "w1", *base_args])
        result = runner.invoke(agent_app, ["deregister", "w1", *base_args])
        assert result.exit_code == 0
        assert "Deregistered" in result.output


# ===================================================================
# Migration SQL file existence
# ===================================================================


class TestMigration:
    """Migration file exists and is valid SQL."""

    def test_migration_file_exists(self) -> None:
        migration = Path(__file__).parent.parent / "migrations" / "002_skill_packs_agents.sql"
        assert migration.exists(), f"Migration file not found: {migration}"

    def test_migration_contains_tables(self) -> None:
        migration = Path(__file__).parent.parent / "migrations" / "002_skill_packs_agents.sql"
        content = migration.read_text()
        assert "skill_packs" in content
        assert "skill_pack_versions" in content
        assert "agents" in content
        assert "CREATE TABLE IF NOT EXISTS" in content


# ===================================================================
# PostgreSQL schema includes new tables
# ===================================================================


class TestPostgresSchema:
    """PostgreSQL schema includes registry tables."""

    def test_schema_has_skill_packs(self) -> None:
        from owlmind.storage.postgres import _PG_SCHEMA

        assert "skill_packs" in _PG_SCHEMA
        assert "skill_pack_versions" in _PG_SCHEMA

    def test_schema_has_agents(self) -> None:
        from owlmind.storage.postgres import _PG_SCHEMA

        assert "CREATE TABLE IF NOT EXISTS agents" in _PG_SCHEMA
        assert "idx_agents_status" in _PG_SCHEMA
