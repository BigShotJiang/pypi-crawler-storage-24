"""Tests for FS75 — rollback controller (all modes, approval, event log)."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

import pytest

from owlmind.rollback import (
    create_rollback_request,
    execute_rollback,
    log_rollback_event,
)

# ---------------------------------------------------------------------------
# create_rollback_request
# ---------------------------------------------------------------------------


class TestCreateRollbackRequest:
    def test_none_mode_auto_approved(self) -> None:
        """mode='none' → request is auto-approved with no token."""
        req = create_rollback_request("g1", "run-1", "none")

        assert req.approved is True
        assert req.approval_token == ""
        assert req.mode == "none"

    def test_manual_mode_has_token(self) -> None:
        """mode='manual', require_approval=True → approval_token is a 16-char hex."""
        req = create_rollback_request("g1", "run-1", "manual", require_approval=True)

        assert len(req.approval_token) == 16
        assert req.approved is False

    def test_worktree_no_approval_required(self) -> None:
        """mode='worktree_reset', require_approval=False → pre-approved, no token."""
        req = create_rollback_request("g1", "run-1", "worktree_reset", require_approval=False)

        assert req.approved is True
        assert req.approval_token == ""

    def test_branch_delete_instructions_contain_run_id(self) -> None:
        """mode='branch_delete' → instructions reference 'owlmind/{run_id}'."""
        req = create_rollback_request("g1", "run-1", "branch_delete")

        assert "owlmind/run-1" in req.instructions


# ---------------------------------------------------------------------------
# execute_rollback
# ---------------------------------------------------------------------------


class TestExecuteRollback:
    def test_none_mode_skipped(self) -> None:
        """mode='none' → result status is 'skipped', no-op."""
        req = create_rollback_request("g1", "run-1", "none")
        result = execute_rollback(req, Path("."))

        assert result["status"] == "skipped"

    def test_manual_mode_provides_instructions(self) -> None:
        """manual mode with correct token → status='instructions_provided'."""
        req = create_rollback_request("g1", "run-1", "manual", require_approval=True)
        result = execute_rollback(req, Path("."), approval_token=req.approval_token)

        assert result["status"] == "instructions_provided"
        assert "instructions" in result

    def test_worktree_exists_deleted(self, tmp_path: Path) -> None:
        """worktree dir exists → shutil.rmtree called, status='executed'."""
        req = create_rollback_request("g1", "run-1", "worktree_reset", require_approval=False)
        worktree_dir = tmp_path / "run-1" / "worktree"
        worktree_dir.mkdir(parents=True)

        with patch("owlmind.rollback.shutil.rmtree") as mock_rmtree:
            result = execute_rollback(req, tmp_path)

        assert result["status"] == "executed"
        mock_rmtree.assert_called_once_with(worktree_dir)

    def test_worktree_not_exists(self, tmp_path: Path) -> None:
        """No worktree dir → status='no_worktree', nothing deleted."""
        req = create_rollback_request("g1", "run-1", "worktree_reset", require_approval=False)
        result = execute_rollback(req, tmp_path)

        assert result["status"] == "no_worktree"

    def test_wrong_token_raises(self) -> None:
        """Wrong approval token → RuntimeError."""
        req = create_rollback_request("g1", "run-1", "manual", require_approval=True)

        with pytest.raises(RuntimeError):
            execute_rollback(req, Path("."), approval_token="wrong-token-xyz")

    def test_branch_delete_recorded(self, tmp_path: Path) -> None:
        """mode='branch_delete' → status='recorded', action mentions run_id."""
        req = create_rollback_request("g1", "run-1", "branch_delete", require_approval=False)
        result = execute_rollback(req, tmp_path)

        assert result["status"] == "recorded"
        assert "run-1" in result.get("action", "")


# ---------------------------------------------------------------------------
# log_rollback_event
# ---------------------------------------------------------------------------


class TestLogRollbackEvent:
    def test_event_written_to_jsonl(self, tmp_path: Path) -> None:
        """log_rollback_event appends a valid JSON line to session.jsonl."""
        log_rollback_event(
            "sess-1",
            tmp_path,
            "ROLLBACK_CREATED",
            {"goal_id": "g1", "mode": "manual"},
        )

        log_path = tmp_path / "sess-1" / "session.jsonl"
        assert log_path.exists()

        data = json.loads(log_path.read_text().strip())
        assert data["event"] == "ROLLBACK_CREATED"
        assert data["goal_id"] == "g1"
        assert data["mode"] == "manual"
        assert "timestamp" in data

    def test_event_appends_multiple_lines(self, tmp_path: Path) -> None:
        """Multiple calls append separate JSON lines (not overwrite)."""
        log_rollback_event("sess-2", tmp_path, "ROLLBACK_CREATED", {"n": 1})
        log_rollback_event("sess-2", tmp_path, "ROLLBACK_EXECUTED", {"n": 2})

        log_path = tmp_path / "sess-2" / "session.jsonl"
        lines = [ln for ln in log_path.read_text().splitlines() if ln.strip()]
        assert len(lines) == 2

        events = [json.loads(ln) for ln in lines]
        assert events[0]["event"] == "ROLLBACK_CREATED"
        assert events[1]["event"] == "ROLLBACK_EXECUTED"

    def test_session_dir_created_if_missing(self, tmp_path: Path) -> None:
        """Session directory is created automatically if it doesn't exist."""
        new_sessions = tmp_path / "new_sessions"
        log_rollback_event("sess-new", new_sessions, "ROLLBACK_CREATED", {})

        assert (new_sessions / "sess-new" / "session.jsonl").exists()


class TestExecuteRollbackUnknownMode:
    """Lines 141-142: unknown mode returns status='unknown_mode'."""

    def test_unknown_mode_returns_status(self, tmp_path: Path) -> None:
        req = create_rollback_request("g-x", "run-x", "none")
        req.mode = "invalid_mode"  # force unknown mode
        result = execute_rollback(req, tmp_path)
        assert result.get("status") == "unknown_mode"
