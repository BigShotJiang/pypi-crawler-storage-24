"""Tests for Telegram operator bot — parsing, allowlist, rate limiting."""

from __future__ import annotations

from owlmind.telegram_bot import make_event_notifier, parse_workspace_from_args


class TestParseWorkspaceFromArgs:
    def test_no_workspace_flag(self) -> None:
        workspace, remaining = parse_workspace_from_args(
            ["hello", "world"],
            "/default",
        )
        assert workspace == "/default"
        assert remaining == ["hello", "world"]

    def test_workspace_at_start(self) -> None:
        workspace, remaining = parse_workspace_from_args(
            ["--workspace", "/tmp/proj", "do", "stuff"],
            "/default",
        )
        assert workspace == "/tmp/proj"
        assert remaining == ["do", "stuff"]

    def test_workspace_at_end(self) -> None:
        workspace, remaining = parse_workspace_from_args(
            ["goal", "text", "--workspace", "/home/me"],
            "/default",
        )
        assert workspace == "/home/me"
        assert remaining == ["goal", "text"]

    def test_workspace_in_middle(self) -> None:
        workspace, remaining = parse_workspace_from_args(
            ["fix", "--workspace", "/app", "bugs"],
            "/default",
        )
        assert workspace == "/app"
        assert remaining == ["fix", "bugs"]

    def test_empty_args(self) -> None:
        workspace, remaining = parse_workspace_from_args([], "/default")
        assert workspace == "/default"
        assert remaining == []

    def test_workspace_flag_without_value(self) -> None:
        workspace, remaining = parse_workspace_from_args(
            ["goal", "--workspace"],
            "/default",
        )
        # --workspace at end with no value → treated as regular arg
        assert workspace == "/default"
        assert remaining == ["goal", "--workspace"]


class TestEventNotifierRateLimit:
    def test_notable_events_fire(self) -> None:
        """Notable events should trigger handler logic."""

        # Provide a mock bot_app
        class _MockBot:
            async def send_message(self, **kwargs: object) -> None:
                pass

        class _MockApp:
            bot = _MockBot()

        last: dict[int, float] = {}
        handler = make_event_notifier(_MockApp(), 123, last, 0.01)

        # Non-notable event should not update last_event
        handler("some_random_event", {})
        assert 123 not in last

        # Notable event should update last_event
        handler("started", {"run_id": "r1", "goal": "test"})
        assert 123 in last

    def test_rate_limiting(self) -> None:
        """Back-to-back notable events should be rate-limited."""

        class _MockBot:
            async def send_message(self, **kwargs: object) -> None:
                pass

        class _MockApp:
            bot = _MockBot()

        last: dict[int, float] = {}
        cooldown = 10.0  # 10 second cooldown
        handler = make_event_notifier(_MockApp(), 456, last, cooldown)

        # First event fires
        handler("started", {"run_id": "r1"})
        t1 = last.get(456, 0.0)
        assert t1 > 0

        # Second event within cooldown should NOT update timestamp
        handler("finished", {"run_id": "r1"})
        assert last[456] == t1  # unchanged


class TestWorkspaceAllowlistInBot:
    """Test workspace validation that happens in the operator (used by bot)."""

    def test_allowed_workspace(self) -> None:
        from owlmind.operator import OperatorService

        svc = OperatorService(
            runs_dir=None,  # type: ignore[arg-type]
            policies_dir=None,  # type: ignore[arg-type]
            ledger_dir=None,  # type: ignore[arg-type]
            allowed_workspaces=["/home/user/projects"],
        )
        assert svc.is_workspace_allowed("/home/user/projects/myapp") is True

    def test_denied_workspace(self) -> None:
        from owlmind.operator import OperatorService

        svc = OperatorService(
            runs_dir=None,  # type: ignore[arg-type]
            policies_dir=None,  # type: ignore[arg-type]
            ledger_dir=None,  # type: ignore[arg-type]
            allowed_workspaces=["/home/user/projects"],
        )
        assert svc.is_workspace_allowed("/etc/secrets") is False

    def test_empty_allowlist_allows_all(self) -> None:
        from owlmind.operator import OperatorService

        svc = OperatorService(
            runs_dir=None,  # type: ignore[arg-type]
            policies_dir=None,  # type: ignore[arg-type]
            ledger_dir=None,  # type: ignore[arg-type]
        )
        assert svc.is_workspace_allowed("/anywhere") is True
