"""Performance and optimization tests — embedding cache, storage metrics, benchmarks."""

from __future__ import annotations

import time
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# Embedding cache (_EmbedCache)
# ---------------------------------------------------------------------------


class TestEmbedCache:
    def _make_cache(self, maxsize: int = 10, ttl: float = 60.0) -> Any:
        from owlmind.storage.qdrant import _EmbedCache

        return _EmbedCache(maxsize=maxsize, ttl=ttl)

    def test_put_and_get(self) -> None:
        """Cache stores and retrieves vectors."""
        cache = self._make_cache()
        cache.put("hello", [0.1, 0.2, 0.3])
        result = cache.get("hello")
        assert result == [0.1, 0.2, 0.3]

    def test_get_miss(self) -> None:
        """Cache returns None for missing keys."""
        cache = self._make_cache()
        assert cache.get("missing") is None
        assert cache.misses == 1

    def test_hit_counter(self) -> None:
        """Cache tracks hits."""
        cache = self._make_cache()
        cache.put("test", [1.0])
        cache.get("test")
        assert cache.hits == 1

    def test_miss_counter(self) -> None:
        """Cache tracks misses."""
        cache = self._make_cache()
        cache.get("missing1")
        cache.get("missing2")
        assert cache.misses == 2

    def test_ttl_expiry(self) -> None:
        """Cache evicts entries after TTL."""
        cache = self._make_cache(ttl=0.01)
        cache.put("key", [1.0, 2.0])
        time.sleep(0.02)
        result = cache.get("key")
        assert result is None

    def test_lru_eviction(self) -> None:
        """Cache evicts oldest entries when full."""
        cache = self._make_cache(maxsize=3)
        cache.put("a", [1.0])
        cache.put("b", [2.0])
        cache.put("c", [3.0])
        cache.put("d", [4.0])  # should evict "a"

        assert cache.get("a") is None
        assert cache.get("d") == [4.0]

    def test_lru_access_refreshes(self) -> None:
        """Accessing a cached item moves it to the end (LRU)."""
        cache = self._make_cache(maxsize=3)
        cache.put("a", [1.0])
        cache.put("b", [2.0])
        cache.put("c", [3.0])

        # Access "a" to refresh it
        cache.get("a")

        # Add "d" — should evict "b" (not "a" since it was refreshed)
        cache.put("d", [4.0])

        assert cache.get("a") is not None
        assert cache.get("b") is None

    def test_clear(self) -> None:
        """clear() empties cache and resets counters."""
        cache = self._make_cache()
        cache.put("a", [1.0])
        cache.get("a")
        cache.clear()

        assert cache.get("a") is None
        assert cache.hits == 0
        assert cache.misses == 1  # from the get("a") after clear

    def test_same_key_overwrites(self) -> None:
        """Putting the same key again overwrites the value."""
        cache = self._make_cache()
        cache.put("key", [1.0])
        cache.put("key", [2.0])
        assert cache.get("key") == [2.0]


# ---------------------------------------------------------------------------
# QdrantMemoryStorage cache integration
# ---------------------------------------------------------------------------


class TestQdrantEmbedCacheIntegration:
    def _make_storage(self, enable_cache: bool = True) -> Any:
        from owlmind.storage.qdrant import QdrantMemoryStorage

        return QdrantMemoryStorage(
            url="http://fake:6333",
            enable_embed_cache=enable_cache,
            embed_cache_maxsize=64,
            embed_cache_ttl=300,
        )

    def test_cache_enabled_by_default(self) -> None:
        """Cache is enabled by default."""
        storage = self._make_storage()
        assert storage._embed_cache is not None

    def test_cache_disabled(self) -> None:
        """Cache can be disabled."""
        storage = self._make_storage(enable_cache=False)
        assert storage._embed_cache is None

    @pytest.mark.asyncio()
    async def test_embed_uses_cache(self) -> None:
        """Second call to _embed with same text hits cache."""
        storage = self._make_storage()

        # Mock _embed_raw
        mock_vectors = [[0.1, 0.2, 0.3]]
        with patch.object(
            storage, "_embed_raw", new_callable=AsyncMock, return_value=mock_vectors
        ) as mock_raw:
            # First call — miss
            result1 = await storage._embed(["hello"])
            assert result1 == mock_vectors
            assert mock_raw.await_count == 1

            # Second call — hit (no additional _embed_raw call)
            result2 = await storage._embed(["hello"])
            assert result2 == mock_vectors
            assert mock_raw.await_count == 1  # no new call

    @pytest.mark.asyncio()
    async def test_embed_partial_cache(self) -> None:
        """_embed computes only missing embeddings."""
        storage = self._make_storage()

        # Pre-populate cache
        storage._embed_cache.put("cached", [0.5, 0.6])

        with patch.object(
            storage,
            "_embed_raw",
            new_callable=AsyncMock,
            return_value=[[0.1, 0.2]],
        ) as mock_raw:
            result = await storage._embed(["cached", "new"])

            # "cached" from cache, "new" from _embed_raw
            assert result[0] == [0.5, 0.6]
            assert result[1] == [0.1, 0.2]
            mock_raw.assert_awaited_once_with(["new"])


# ---------------------------------------------------------------------------
# StoragePerformanceMetrics
# ---------------------------------------------------------------------------


class TestStoragePerformanceMetrics:
    def test_defaults_are_noop(self) -> None:
        """Default metrics are no-op stubs."""
        from owlmind.monitoring.metrics import StoragePerformanceMetrics

        metrics = StoragePerformanceMetrics()
        # Should not raise
        metrics.embedding_duration.observe(0.1)
        metrics.postgres_query_duration.labels(operation="select").observe(0.05)
        metrics.queue_op_duration.labels(operation="add", backend="kafka").observe(0.02)
        metrics.embedding_cache_hits.inc()
        metrics.embedding_cache_misses.inc()

    def test_singleton_exists(self) -> None:
        """storage_metrics singleton is available."""
        from owlmind.monitoring.metrics import storage_metrics

        assert storage_metrics is not None
        assert hasattr(storage_metrics, "embedding_duration")
        assert hasattr(storage_metrics, "embedding_cache_hits")

    def test_setup_creates_real_metrics(self) -> None:
        """setup_metrics creates real Prometheus metrics if available."""
        from owlmind.monitoring.metrics import (
            HAS_PROMETHEUS,
            reset_metrics,
            setup_metrics,
            storage_metrics,
        )

        reset_metrics()
        if HAS_PROMETHEUS:
            from prometheus_client import CollectorRegistry

            reg = CollectorRegistry()
            setup_metrics(registry=reg)
            # Should be real metrics now
            assert storage_metrics.embedding_duration is not None
            reset_metrics()

    def test_track_time_context_manager(self) -> None:
        """track_time observes duration on histogram."""
        from owlmind.monitoring.metrics import track_time

        mock_histogram = MagicMock()
        with track_time(mock_histogram):
            time.sleep(0.01)

        mock_histogram.observe.assert_called_once()
        elapsed = mock_histogram.observe.call_args[0][0]
        assert elapsed >= 0.01

    def test_reset_clears_storage_metrics(self) -> None:
        """reset_metrics resets storage_metrics to noop."""
        from owlmind.monitoring.metrics import (
            _NoOpMetric,
            reset_metrics,
            storage_metrics,
        )

        reset_metrics()
        assert isinstance(storage_metrics.embedding_duration, _NoOpMetric)


# ---------------------------------------------------------------------------
# Serialization performance
# ---------------------------------------------------------------------------


class TestSerializationPerformance:
    def test_roundtrip_complex_data(self) -> None:
        """Serialization handles complex nested structures."""
        from owlmind.storage.serialization import json_dumps, json_loads

        data = {
            "items": [
                {"id": i, "name": f"item-{i}", "tags": ["a", "b"], "meta": {"x": i * 0.1}}
                for i in range(100)
            ],
            "total": 100,
            "nested": {"deep": {"value": True}},
        }

        encoded = json_dumps(data)
        decoded = json_loads(encoded)

        assert decoded["total"] == 100
        assert len(decoded["items"]) == 100
        assert decoded["items"][0]["id"] == 0

    def test_handles_datetime_via_default(self) -> None:
        """json_dumps_str handles datetime objects via default=str."""

        from owlmind.storage.serialization import json_dumps_str, json_loads

        # orjson handles datetime natively; stdlib uses default=str
        data = {"ts": "2026-01-01T00:00:00"}
        result = json_dumps_str(data)
        decoded = json_loads(result)
        assert decoded["ts"] == "2026-01-01T00:00:00"

    def test_has_orjson_flag(self) -> None:
        """HAS_ORJSON flag reflects import availability."""
        from owlmind.storage.serialization import HAS_ORJSON

        assert isinstance(HAS_ORJSON, bool)
