"""Tests for Telegram bot session parsing and session event notifier."""

from __future__ import annotations

from owlmind.telegram_bot import (
    _format_event_message,
    _format_session_result,
    make_event_notifier,
    parse_session_resume_args,
    parse_session_start_args,
    parse_session_start_args_full,
)


class TestParseSessionStartArgs:
    def test_basic(self) -> None:
        goals, ws, mc, cf = parse_session_start_args(
            ["goals.yaml"],
            "/default",
        )
        assert goals == "goals.yaml"
        assert ws == "/default"
        assert mc == 1
        assert cf is False

    def test_with_workspace(self) -> None:
        goals, ws, mc, cf = parse_session_start_args(
            ["goals.yaml", "--workspace", "/tmp/proj"],
            "/default",
        )
        assert goals == "goals.yaml"
        assert ws == "/tmp/proj"

    def test_with_max_concurrency(self) -> None:
        goals, ws, mc, cf = parse_session_start_args(
            ["goals.yaml", "--max-concurrency", "4"],
            "/default",
        )
        assert goals == "goals.yaml"
        assert mc == 4

    def test_with_continue_on_fail(self) -> None:
        goals, ws, mc, cf = parse_session_start_args(
            ["goals.yaml", "--continue-on-fail"],
            "/default",
        )
        assert goals == "goals.yaml"
        assert cf is True

    def test_all_flags(self) -> None:
        goals, ws, mc, cf = parse_session_start_args(
            [
                "--workspace",
                "/app",
                "goals.yaml",
                "--max-concurrency",
                "2",
                "--continue-on-fail",
            ],
            "/default",
        )
        assert goals == "goals.yaml"
        assert ws == "/app"
        assert mc == 2
        assert cf is True

    def test_empty_args(self) -> None:
        goals, ws, mc, cf = parse_session_start_args([], "/default")
        assert goals == ""
        assert ws == "/default"

    def test_invalid_concurrency(self) -> None:
        goals, ws, mc, cf = parse_session_start_args(
            ["goals.yaml", "--max-concurrency", "abc"],
            "/default",
        )
        assert mc == 1  # default unchanged

    def test_workspace_at_end_no_value(self) -> None:
        goals, ws, mc, cf = parse_session_start_args(
            ["goals.yaml", "--workspace"],
            "/default",
        )
        assert ws == "/default"
        assert goals == "goals.yaml"


class TestParseSessionStartArgsFull:
    """Tests for extended session_start args: --sandbox, --llm, --worker."""

    def test_sandbox_on(self) -> None:
        sa = parse_session_start_args_full(
            ["goals.yaml", "--sandbox", "on"],
            "/default",
        )
        assert sa.goals_file == "goals.yaml"
        assert sa.sandbox is True

    def test_sandbox_off(self) -> None:
        sa = parse_session_start_args_full(
            ["goals.yaml", "--sandbox", "off"],
            "/default",
        )
        assert sa.sandbox is False

    def test_llm_planner(self) -> None:
        sa = parse_session_start_args_full(
            ["goals.yaml", "--llm", "planner"],
            "/default",
        )
        assert sa.use_llm == "planner"

    def test_llm_judge(self) -> None:
        sa = parse_session_start_args_full(
            ["goals.yaml", "--llm", "judge"],
            "/default",
        )
        assert sa.use_llm == "judge"

    def test_llm_none(self) -> None:
        sa = parse_session_start_args_full(
            ["goals.yaml", "--llm", "none"],
            "/default",
        )
        assert sa.use_llm == "none"

    def test_llm_invalid_ignored(self) -> None:
        sa = parse_session_start_args_full(
            ["goals.yaml", "--llm", "invalid_value"],
            "/default",
        )
        assert sa.use_llm == "both"  # default unchanged

    def test_worker_claude_cli(self) -> None:
        sa = parse_session_start_args_full(
            ["goals.yaml", "--worker", "claude_cli"],
            "/default",
        )
        assert sa.use_worker == "claude_cli"

    def test_worker_invalid_ignored(self) -> None:
        sa = parse_session_start_args_full(
            ["goals.yaml", "--worker", "bad"],
            "/default",
        )
        assert sa.use_worker == "none"  # default unchanged

    def test_all_extended_flags(self) -> None:
        sa = parse_session_start_args_full(
            [
                "goals.yaml",
                "--workspace",
                "/proj",
                "--sandbox",
                "on",
                "--llm",
                "judge",
                "--worker",
                "claude_cli",
                "--max-concurrency",
                "3",
                "--continue-on-fail",
            ],
            "/default",
        )
        assert sa.goals_file == "goals.yaml"
        assert sa.workspace == "/proj"
        assert sa.sandbox is True
        assert sa.use_llm == "judge"
        assert sa.use_worker == "claude_cli"
        assert sa.max_concurrency == 3
        assert sa.continue_on_fail is True

    def test_backward_compat_4tuple(self) -> None:
        """parse_session_start_args still returns 4-tuple."""
        goals, ws, mc, cf = parse_session_start_args(
            ["goals.yaml", "--sandbox", "on", "--llm", "none"],
            "/d",
        )
        assert goals == "goals.yaml"
        assert ws == "/d"
        assert mc == 1
        assert cf is False


class TestParseSessionResumeArgs:
    def test_basic(self) -> None:
        sid, mc, cf = parse_session_resume_args(["session-abc"])
        assert sid == "session-abc"
        assert mc == 0
        assert cf is None

    def test_with_max_concurrency(self) -> None:
        sid, mc, cf = parse_session_resume_args(
            ["session-abc", "--max-concurrency", "3"],
        )
        assert sid == "session-abc"
        assert mc == 3

    def test_with_continue_on_fail(self) -> None:
        sid, mc, cf = parse_session_resume_args(
            ["session-abc", "--continue-on-fail"],
        )
        assert sid == "session-abc"
        assert cf is True

    def test_empty_args(self) -> None:
        sid, mc, cf = parse_session_resume_args([])
        assert sid == ""
        assert mc == 0


class TestFormatSessionResult:
    def test_done(self) -> None:
        result = {
            "session_id": "session-1",
            "status": "DONE",
            "goals_total": 3,
            "goals_done": 3,
            "goals_failed": 0,
            "goals_blocked": 0,
            "goals_skipped": 0,
            "last_block_reason": "",
            "next_commands": [],
        }
        text = _format_session_result(result)
        assert "DONE" in text
        assert "3/3" in text

    def test_blocked_with_reason(self) -> None:
        result = {
            "session_id": "session-2",
            "status": "BLOCKED",
            "goals_total": 2,
            "goals_done": 1,
            "goals_failed": 0,
            "goals_blocked": 1,
            "goals_skipped": 0,
            "last_block_reason": "waiting for approval",
            "next_commands": ["owlmind session resume"],
        }
        text = _format_session_result(result)
        assert "BLOCKED" in text
        assert "Blocked: 1" in text
        assert "waiting for approval" in text
        assert "owlmind session resume" in text

    def test_with_skipped(self) -> None:
        result = {
            "session_id": "session-3",
            "status": "DONE",
            "goals_total": 3,
            "goals_done": 1,
            "goals_failed": 1,
            "goals_blocked": 0,
            "goals_skipped": 1,
            "last_block_reason": "",
            "next_commands": [],
        }
        text = _format_session_result(result)
        assert "Skipped: 1" in text
        assert "Failed: 1" in text


class TestFormatEventMessage:
    def test_autopilot_started(self) -> None:
        msg = _format_event_message("started", {"run_id": "r1", "goal": "test"})
        assert "started" in msg
        assert "test" in msg

    def test_autopilot_error(self) -> None:
        msg = _format_event_message("error", {"error": "boom"})
        assert "boom" in msg

    def test_session_goal_starting(self) -> None:
        msg = _format_event_message(
            "session_goal_starting",
            {
                "session_id": "s1",
                "goal_id": "G2",
            },
        )
        assert "SESSION" in msg
        assert "G2" in msg
        assert "s1" in msg

    def test_session_goal_done(self) -> None:
        msg = _format_event_message(
            "session_goal_done",
            {
                "session_id": "s1",
                "goal_id": "G3",
            },
        )
        assert "done" in msg.lower() or "Done" in msg or "SESSION" in msg
        assert "G3" in msg

    def test_session_blocked(self) -> None:
        msg = _format_event_message(
            "session_blocked",
            {
                "session_id": "s1",
                "reason": "approval needed",
            },
        )
        assert "Blocked" in msg
        assert "approval needed" in msg

    def test_session_failed(self) -> None:
        msg = _format_event_message(
            "session_failed",
            {
                "session_id": "s1",
                "reason": "goal G1 failed",
            },
        )
        assert "Failed" in msg
        assert "goal G1 failed" in msg


class TestSessionEventNotifier:
    def test_session_events_are_notable(self) -> None:
        """Session events should trigger handler logic."""

        class _MockBot:
            async def send_message(self, **kwargs: object) -> None:
                pass

        class _MockApp:
            bot = _MockBot()

        last: dict[int, float] = {}
        handler = make_event_notifier(_MockApp(), 100, last, 0.01)

        # Session event should update last_event
        handler("session_goal_starting", {"session_id": "s1", "goal_id": "G1"})
        assert 100 in last

    def test_session_event_dedupe(self) -> None:
        """Same session event should be deduplicated."""

        class _MockBot:
            async def send_message(self, **kwargs: object) -> None:
                pass

        class _MockApp:
            bot = _MockBot()

        last: dict[int, float] = {}
        handler = make_event_notifier(_MockApp(), 200, last, 0.0)

        # First event fires
        handler("session_goal_starting", {"session_id": "s1", "goal_id": "G1"})
        t1 = last.get(200, 0.0)
        assert t1 > 0

        # Same event immediately — deduplicated
        handler("session_goal_starting", {"session_id": "s1", "goal_id": "G1"})
        # Timestamp should not change because of dedupe
        assert last[200] == t1

    def test_different_goal_events_not_deduped(self) -> None:
        """Different goal IDs should not be deduplicated."""
        import time

        class _MockBot:
            async def send_message(self, **kwargs: object) -> None:
                pass

        class _MockApp:
            bot = _MockBot()

        last: dict[int, float] = {}
        handler = make_event_notifier(_MockApp(), 300, last, 0.0)

        handler("session_goal_starting", {"session_id": "s1", "goal_id": "G1"})
        t1 = last.get(300, 0.0)

        # Small delay to ensure monotonic clock advances
        time.sleep(0.001)

        handler("session_goal_starting", {"session_id": "s1", "goal_id": "G2"})
        t2 = last.get(300, 0.0)
        assert t2 > t1  # Different goal = not deduped
