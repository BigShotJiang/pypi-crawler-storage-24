"""Tests for owlmind.errors — error hierarchy and semantics."""

from __future__ import annotations

import pytest

from owlmind.errors import OwlMindError, StructuralError, TransientError


class TestOwlMindError:
    def test_is_exception_subclass(self) -> None:
        assert issubclass(OwlMindError, Exception)

    def test_raise_and_catch(self) -> None:
        with pytest.raises(OwlMindError, match="base error"):
            raise OwlMindError("base error")

    def test_message_preserved(self) -> None:
        err = OwlMindError("something went wrong")
        assert str(err) == "something went wrong"

    def test_empty_message(self) -> None:
        err = OwlMindError()
        assert str(err) == ""


class TestTransientError:
    def test_is_owlmind_error_subclass(self) -> None:
        assert issubclass(TransientError, OwlMindError)

    def test_is_exception_subclass(self) -> None:
        assert issubclass(TransientError, Exception)

    def test_caught_by_owlmind_error_handler(self) -> None:
        with pytest.raises(OwlMindError):
            raise TransientError("timeout")

    def test_isinstance_check(self) -> None:
        err = TransientError("rate limit")
        assert isinstance(err, OwlMindError)
        assert isinstance(err, TransientError)
        assert isinstance(err, Exception)

    def test_message_preserved(self) -> None:
        err = TransientError("503 Service Unavailable")
        assert "503" in str(err)


class TestStructuralError:
    def test_is_owlmind_error_subclass(self) -> None:
        assert issubclass(StructuralError, OwlMindError)

    def test_is_exception_subclass(self) -> None:
        assert issubclass(StructuralError, Exception)

    def test_caught_by_owlmind_error_handler(self) -> None:
        with pytest.raises(OwlMindError):
            raise StructuralError("schema violation")

    def test_isinstance_check(self) -> None:
        err = StructuralError("bad request")
        assert isinstance(err, OwlMindError)
        assert isinstance(err, StructuralError)
        assert isinstance(err, Exception)

    def test_not_transient(self) -> None:
        err = StructuralError("auth failure")
        assert not isinstance(err, TransientError)


class TestErrorDiscrimination:
    def test_transient_is_not_structural(self) -> None:
        err = TransientError("timeout")
        assert not isinstance(err, StructuralError)

    def test_structural_is_not_transient(self) -> None:
        err = StructuralError("schema")
        assert not isinstance(err, TransientError)

    def test_base_is_neither_subtype(self) -> None:
        err = OwlMindError("generic")
        assert not isinstance(err, TransientError)
        assert not isinstance(err, StructuralError)
