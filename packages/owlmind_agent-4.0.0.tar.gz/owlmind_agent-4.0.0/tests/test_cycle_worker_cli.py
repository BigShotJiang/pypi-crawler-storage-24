"""Tests for CycleManager.run_worker_cli — NO real Claude CLI calls."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest

from owlmind.agent.cycle import CycleManager
from owlmind.agent.schemas import CycleState
from owlmind.approval import create_approval, resolve_approval
from owlmind.evidence import EvidenceStore
from owlmind.policy import PolicyEngine


class FakeWorkerDriver:
    """Fake worker driver for tests — returns canned responses."""

    def __init__(
        self,
        report: dict[str, Any] | None = None,
        *,
        should_fail: bool = False,
    ) -> None:
        self._report = report or {}
        self._should_fail = should_fail
        self.run_calls: list[dict[str, Any]] = []

    @property
    def name(self) -> str:
        return "fake_worker"

    def run(
        self,
        worker_request: dict[str, Any],
        schema: dict[str, Any],
        cwd: Path,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        self.run_calls.append(worker_request)
        if self._should_fail:
            msg = "Fake worker failure"
            raise RuntimeError(msg)
        meta = {
            "provider": "fake_worker",
            "exit_code": 0,
            "duration_ms": 1000,
            "raw_output_sha256": "abc123",
            "parsed_ok": True,
        }
        return self._report, meta


def _make_manager(
    tmp_path: Path,
    worker: FakeWorkerDriver | None = None,
) -> CycleManager:
    policies_dir = tmp_path / "policies"
    policies_dir.mkdir()
    (policies_dir / "allowlist.yaml").write_text(
        'allowed_commands:\n  - "^echo "\n  - "^pytest"\n  - "^ruff"\n  - "^mypy"\n'
    )
    (policies_dir / "policy.yaml").write_text('forbidden_patterns:\n  - "rm -rf"\n')
    policy = PolicyEngine.from_directory(policies_dir)
    evidence = EvidenceStore(tmp_path / "runs")
    return CycleManager(
        evidence=evidence,
        policy=policy,
        policies_dir=policies_dir,
        worker_driver=worker,
    )


def _advance_to_wait_worker(
    tmp_path: Path,
    mgr: CycleManager,
) -> str:
    """Start a cycle and advance to WAIT_WORKER state."""
    meta = mgr.start(goal="Worker CLI test", workspace=str(tmp_path))
    run_id = meta.run_id

    # Submit planner response
    planner_resp = {
        "run_id": run_id,
        "iteration": 1,
        "plan_summary": ["Step 1: Do it"],
        "worker_instructions": "Implement the feature",
        "verify_commands": ["echo ok"],
        "risk_notes": [],
    }
    inbox = tmp_path / "runs" / run_id / "inbox"
    inbox.mkdir(parents=True, exist_ok=True)
    (inbox / "planner_response.json").write_text(json.dumps(planner_resp))
    mgr.submit_planner(run_id)

    return run_id


class TestRunWorkerCliApproval:
    def test_creates_approval_when_wait_worker(self, tmp_path: Path) -> None:
        report = {
            "run_id": "placeholder",
            "iteration": 1,
            "status": "READY_FOR_VERIFY",
            "done_summary": ["Did it"],
            "questions": [],
            "commands_run": [],
        }
        driver = FakeWorkerDriver(report=report)
        mgr = _make_manager(tmp_path, driver)

        run_id = _advance_to_wait_worker(tmp_path, mgr)

        meta, message = mgr.run_worker_cli(run_id)

        # Should have created an approval
        assert meta.state == CycleState.WAIT_APPROVAL
        assert "Approval required" in message
        assert "Token" in message

        # Worker was NOT called yet
        assert len(driver.run_calls) == 0

    def test_runs_worker_after_approval(self, tmp_path: Path) -> None:
        report = {
            "run_id": "placeholder",
            "iteration": 1,
            "status": "READY_FOR_VERIFY",
            "done_summary": ["Feature implemented"],
            "questions": [],
            "commands_run": [{"cmd": "echo ok", "exit_code": 0, "summary": "ok"}],
        }
        driver = FakeWorkerDriver(report=report)
        mgr = _make_manager(tmp_path, driver)

        run_id = _advance_to_wait_worker(tmp_path, mgr)
        report["run_id"] = run_id

        # First call — creates approval
        meta1, msg1 = mgr.run_worker_cli(run_id)
        assert meta1.state == CycleState.WAIT_APPROVAL

        # Extract token from meta
        token = meta1.extra["pending_approval"]["token"]

        # Approve
        ok, msg = resolve_approval(mgr.meta_store, run_id, token, approved=True)
        assert ok

        # Second call — should run worker
        meta2, msg2 = mgr.run_worker_cli(run_id)
        assert "Worker report generated" in msg2
        assert len(driver.run_calls) == 1

        # Inbox should have worker_report.json
        inbox_path = tmp_path / "runs" / run_id / "inbox" / "worker_report.json"
        assert inbox_path.exists()
        data = json.loads(inbox_path.read_text())
        assert data["done_summary"] == ["Feature implemented"]

    def test_denied_approval_fails_run(self, tmp_path: Path) -> None:
        driver = FakeWorkerDriver(report={})
        mgr = _make_manager(tmp_path, driver)

        run_id = _advance_to_wait_worker(tmp_path, mgr)

        # Create approval
        meta1, _ = mgr.run_worker_cli(run_id)
        token = meta1.extra["pending_approval"]["token"]

        # Deny
        ok, msg = resolve_approval(mgr.meta_store, run_id, token, approved=False)
        assert ok

        # Trying to run worker should fail — state is FAILED
        with pytest.raises(RuntimeError, match="WAIT_WORKER or WAIT_APPROVAL"):
            mgr.run_worker_cli(run_id)


class TestRunWorkerCliExecution:
    def test_writes_evidence_artifacts(self, tmp_path: Path) -> None:
        report = {
            "run_id": "placeholder",
            "iteration": 1,
            "status": "READY_FOR_VERIFY",
            "done_summary": ["Done"],
            "questions": [],
            "commands_run": [],
        }
        driver = FakeWorkerDriver(report=report)
        mgr = _make_manager(tmp_path, driver)

        run_id = _advance_to_wait_worker(tmp_path, mgr)
        report["run_id"] = run_id

        # Create and approve immediately
        approval = create_approval(mgr.meta_store, run_id, "test")
        resolve_approval(mgr.meta_store, run_id, approval.token, approved=True)

        meta, msg = mgr.run_worker_cli(run_id)

        # Evidence artifacts should exist
        art_dir = tmp_path / "runs" / run_id / "artifacts"
        assert (art_dir / "claude_worker_prompt.txt").exists()
        assert (art_dir / "claude_worker_raw_output.txt").exists()
        assert (art_dir / "claude_worker_report.json").exists()

    def test_logs_chain_events(self, tmp_path: Path) -> None:
        report = {
            "run_id": "placeholder",
            "iteration": 1,
            "status": "READY_FOR_VERIFY",
            "done_summary": ["Done"],
            "questions": [],
            "commands_run": [],
        }
        driver = FakeWorkerDriver(report=report)
        mgr = _make_manager(tmp_path, driver)

        run_id = _advance_to_wait_worker(tmp_path, mgr)
        report["run_id"] = run_id

        # Approve and run
        approval = create_approval(mgr.meta_store, run_id, "test")
        resolve_approval(mgr.meta_store, run_id, approval.token, approved=True)
        mgr.run_worker_cli(run_id)

        events = mgr.evidence.read_events(run_id)
        worker_events = [
            e
            for e in events
            if e.get("event") in ("WORKER_CLAUDE_CLI_CALLED", "WORKER_CLAUDE_CLI_PARSED")
        ]
        assert len(worker_events) == 2

        called = [e for e in worker_events if e["event"] == "WORKER_CLAUDE_CLI_CALLED"]
        assert called[0]["provider"] == "fake_worker"

    def test_worker_failure_raises_and_logs(self, tmp_path: Path) -> None:
        driver = FakeWorkerDriver(should_fail=True)
        mgr = _make_manager(tmp_path, driver)

        run_id = _advance_to_wait_worker(tmp_path, mgr)

        # Approve
        approval = create_approval(mgr.meta_store, run_id, "test")
        resolve_approval(mgr.meta_store, run_id, approval.token, approved=True)

        with pytest.raises(RuntimeError, match="Fake worker failure"):
            mgr.run_worker_cli(run_id)

        # Failure event should be logged
        events = mgr.evidence.read_events(run_id)
        fail_events = [
            e
            for e in events
            if e.get("event") == "WORKER_CLAUDE_CLI_CALLED" and e.get("parsed_ok") is False
        ]
        assert len(fail_events) == 1


class TestRunWorkerCliEdgeCases:
    def test_rejects_wrong_state(self, tmp_path: Path) -> None:
        driver = FakeWorkerDriver()
        mgr = _make_manager(tmp_path, driver)

        meta = mgr.start(goal="Wrong state", workspace=str(tmp_path))

        with pytest.raises(RuntimeError, match="WAIT_WORKER or WAIT_APPROVAL"):
            mgr.run_worker_cli(meta.run_id)

    def test_rejects_no_driver(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path, worker=None)

        run_id = _advance_to_wait_worker(tmp_path, mgr)

        # Approve manually
        approval = create_approval(mgr.meta_store, run_id, "test")
        resolve_approval(mgr.meta_store, run_id, approval.token, approved=True)

        with pytest.raises(RuntimeError, match="No worker driver"):
            mgr.run_worker_cli(run_id)

    def test_wait_approval_pending_returns_message(self, tmp_path: Path) -> None:
        driver = FakeWorkerDriver()
        mgr = _make_manager(tmp_path, driver)

        run_id = _advance_to_wait_worker(tmp_path, mgr)

        # Create approval (moves to WAIT_APPROVAL)
        mgr.run_worker_cli(run_id)

        # Call again while still pending — should return "Waiting"
        meta, msg = mgr.run_worker_cli(run_id)
        assert meta.state == CycleState.WAIT_APPROVAL
        assert "Waiting for approval" in msg
