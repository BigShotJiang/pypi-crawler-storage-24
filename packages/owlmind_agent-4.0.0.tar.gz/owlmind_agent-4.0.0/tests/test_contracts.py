"""Tests for OWLMIND data contracts."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from owlmind.contracts import (
    Action,
    ActionType,
    CheckCategory,
    CheckItem,
    JudgeVerdict,
    OrchestratorState,
    RiskLevel,
    RunSummary,
    TaskSpec,
    Verdict,
)


class TestAction:
    def test_valid_action(self) -> None:
        a = Action(
            action_id="A-001",
            type=ActionType.RUN_COMMAND,
            payload={"cmd": "pytest -q"},
            risk_level=RiskLevel.LOW,
        )
        assert a.action_id == "A-001"
        assert a.type == ActionType.RUN_COMMAND

    def test_multiline_cmd_rejected(self) -> None:
        with pytest.raises(ValidationError, match="single line"):
            Action(
                action_id="A-002",
                type=ActionType.RUN_COMMAND,
                payload={"cmd": "line1\nline2"},
            )

    def test_default_risk_level(self) -> None:
        a = Action(action_id="A-003", type=ActionType.EDIT_FILE)
        assert a.risk_level == RiskLevel.LOW


class TestTaskSpec:
    def test_minimal_taskspec(self) -> None:
        t = TaskSpec(task_id="T-001", goal="Do something")
        assert t.task_id == "T-001"
        assert t.goal == "Do something"
        assert t.actions == []
        assert t.definition_of_done == []

    def test_taskspec_with_actions(self) -> None:
        t = TaskSpec(
            task_id="T-002",
            goal="Run tests",
            actions=[
                Action(
                    action_id="A-001",
                    type=ActionType.RUN_COMMAND,
                    payload={"cmd": "pytest"},
                ),
            ],
        )
        assert len(t.actions) == 1


class TestJudgeVerdict:
    def test_valid_verdict(self) -> None:
        v = JudgeVerdict(
            task_id="T-001",
            verdict=Verdict.APPROVED,
            score=8,
            confidence=0.9,
            checklist={
                "SECURITY": CheckCategory(
                    passed=True,
                    blocking=True,
                    checks=[
                        CheckItem(name="no_secrets", passed=True, evidence="clean"),
                    ],
                ),
            },
            evidence_chain_verified=True,
        )
        assert v.verdict == Verdict.APPROVED
        assert v.score == 8

    def test_score_bounds(self) -> None:
        with pytest.raises(ValidationError):
            JudgeVerdict(
                task_id="T-001",
                verdict=Verdict.REJECTED,
                score=0,  # below min=1
                confidence=0.5,
            )

        with pytest.raises(ValidationError):
            JudgeVerdict(
                task_id="T-001",
                verdict=Verdict.REJECTED,
                score=11,  # above max=10
                confidence=0.5,
            )


class TestRunSummary:
    def test_default_state(self) -> None:
        s = RunSummary(task_id="T-001", state=OrchestratorState.DONE)
        assert s.actions_executed == 0
        assert s.finished_at is None
