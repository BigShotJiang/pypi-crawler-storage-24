"""Tests for new MCP server tools: owlmind_queue_add, owlmind_session_start, owlmind_skill_run."""
from __future__ import annotations

import json

from owlmind.mcp.server import MCPServer


def _call_tool(server: MCPServer, name: str, args: dict) -> dict:
    """Helper to call a tool via JSON-RPC."""
    response = server.handle_one(
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {"name": name, "arguments": args},
        }
    )
    assert response is not None
    assert "result" in response
    return json.loads(response["result"]["content"][0]["text"])


class TestOwlMindQueueAdd:
    """Tests for owlmind_queue_add MCP tool."""

    def test_queue_add_success(self, tmp_path):
        server = MCPServer()
        result = _call_tool(
            server,
            "owlmind_queue_add",
            {
                "goal": "Fix the login bug",
                "workspace": str(tmp_path),
            },
        )
        assert result["status"] == "queued"
        assert "task_id" in result
        assert result["goal"] == "Fix the login bug"

    def test_queue_add_creates_queue_file(self, tmp_path):
        server = MCPServer()
        _call_tool(
            server,
            "owlmind_queue_add",
            {
                "goal": "Add tests",
                "workspace": str(tmp_path),
            },
        )
        queue_file = tmp_path / ".owlmind" / "queue" / "queue.jsonl"
        assert queue_file.exists()
        data = json.loads(queue_file.read_text().strip())
        assert data["goal"] == "Add tests"
        assert data["status"] == "PENDING"

    def test_queue_add_with_priority(self, tmp_path):
        server = MCPServer()
        result = _call_tool(
            server,
            "owlmind_queue_add",
            {
                "goal": "Urgent fix",
                "workspace": str(tmp_path),
                "priority": 5,
            },
        )
        assert result["status"] == "queued"

    def test_queue_add_with_sandbox(self, tmp_path):
        server = MCPServer()
        result = _call_tool(
            server,
            "owlmind_queue_add",
            {
                "goal": "Risky change",
                "workspace": str(tmp_path),
                "sandbox": True,
            },
        )
        assert result["status"] == "queued"

    def test_queue_add_empty_goal_returns_error(self, tmp_path):
        server = MCPServer()
        result = _call_tool(
            server,
            "owlmind_queue_add",
            {
                "goal": "",
                "workspace": str(tmp_path),
            },
        )
        assert result["status"] == "failed"
        assert "error" in result

    def test_queue_add_multiple_items(self, tmp_path):
        server = MCPServer()
        for i in range(3):
            _call_tool(
                server,
                "owlmind_queue_add",
                {
                    "goal": f"Goal {i}",
                    "workspace": str(tmp_path),
                },
            )
        queue_file = tmp_path / ".owlmind" / "queue" / "queue.jsonl"
        lines = [line for line in queue_file.read_text().strip().splitlines() if line]
        assert len(lines) == 3

    def test_queue_add_returns_priority_field(self, tmp_path):
        server = MCPServer()
        result = _call_tool(
            server,
            "owlmind_queue_add",
            {
                "goal": "prioritized task",
                "workspace": str(tmp_path),
                "priority": 3,
            },
        )
        assert result["priority"] == 3

    def test_queue_add_task_id_starts_with_prefix(self, tmp_path):
        server = MCPServer()
        result = _call_tool(
            server,
            "owlmind_queue_add",
            {
                "goal": "some task",
                "workspace": str(tmp_path),
            },
        )
        assert result["task_id"].startswith("task-")


class TestOwlMindSessionStart:
    """Tests for owlmind_session_start MCP tool."""

    def test_session_start_success(self, tmp_path):
        server = MCPServer()
        result = _call_tool(
            server,
            "owlmind_session_start",
            {
                "goals": ["Add auth", "Add tests", "Deploy"],
                "workspace": str(tmp_path),
            },
        )
        assert result["status"] == "session_queued"
        assert result["task_count"] == 3
        assert len(result["task_ids"]) == 3

    def test_session_start_creates_queue_items(self, tmp_path):
        server = MCPServer()
        _call_tool(
            server,
            "owlmind_session_start",
            {
                "goals": ["Goal A", "Goal B"],
                "workspace": str(tmp_path),
            },
        )
        queue_file = tmp_path / ".owlmind" / "queue" / "queue.jsonl"
        lines = [json.loads(line) for line in queue_file.read_text().strip().splitlines() if line]
        assert len(lines) == 2

    def test_session_start_assigns_session_id(self, tmp_path):
        server = MCPServer()
        result = _call_tool(
            server,
            "owlmind_session_start",
            {
                "goals": ["Goal 1"],
                "workspace": str(tmp_path),
            },
        )
        assert "session_id" in result
        assert result["session_id"]

    def test_session_start_custom_name(self, tmp_path):
        server = MCPServer()
        result = _call_tool(
            server,
            "owlmind_session_start",
            {
                "goals": ["Build feature"],
                "workspace": str(tmp_path),
                "session_name": "my-sprint",
            },
        )
        assert result["session_id"] == "my-sprint"

    def test_session_start_empty_goals_returns_error(self, tmp_path):
        server = MCPServer()
        result = _call_tool(
            server,
            "owlmind_session_start",
            {
                "goals": [],
                "workspace": str(tmp_path),
            },
        )
        assert result["status"] == "failed"

    def test_session_start_session_id_auto_generated(self, tmp_path):
        """When no session_name given, a session-<hex> ID is auto-generated."""
        server = MCPServer()
        result = _call_tool(
            server,
            "owlmind_session_start",
            {
                "goals": ["task 1"],
                "workspace": str(tmp_path),
            },
        )
        assert result["session_id"].startswith("session-")

    def test_session_start_returns_workspace(self, tmp_path):
        server = MCPServer()
        result = _call_tool(
            server,
            "owlmind_session_start",
            {
                "goals": ["task 1", "task 2"],
                "workspace": str(tmp_path),
            },
        )
        assert result["workspace"] == str(tmp_path)


class TestOwlMindSkillRun:
    """Tests for owlmind_skill_run MCP tool."""

    def test_skill_run_known_pack(self, tmp_path):
        """code_review is a built-in skill pack."""
        server = MCPServer()
        result = _call_tool(
            server,
            "owlmind_skill_run",
            {
                "pack_id": "code_review",
                "goal": "Review src/owlmind/queue.py",
                "workspace": str(tmp_path),
            },
        )
        # Either succeeds or fails gracefully (skill packs path may vary)
        assert "status" in result

    def test_skill_run_unknown_pack_returns_error(self, tmp_path):
        server = MCPServer()
        result = _call_tool(
            server,
            "owlmind_skill_run",
            {
                "pack_id": "nonexistent_pack_xyz",
                "goal": "Do something",
                "workspace": str(tmp_path),
            },
        )
        assert result["status"] == "failed"
        assert "not found" in result.get("error", "").lower()

    def test_skill_run_empty_pack_id_returns_error(self, tmp_path):
        server = MCPServer()
        result = _call_tool(
            server,
            "owlmind_skill_run",
            {
                "pack_id": "",
                "goal": "Do something",
                "workspace": str(tmp_path),
            },
        )
        assert result["status"] == "failed"

    def test_skill_run_empty_goal_returns_error(self, tmp_path):
        server = MCPServer()
        result = _call_tool(
            server,
            "owlmind_skill_run",
            {
                "pack_id": "code_review",
                "goal": "",
                "workspace": str(tmp_path),
            },
        )
        assert result["status"] == "failed"

    def test_skill_run_missing_both_returns_error(self, tmp_path):
        """Both pack_id and goal empty → single failed response."""
        server = MCPServer()
        result = _call_tool(
            server,
            "owlmind_skill_run",
            {
                "pack_id": "",
                "goal": "",
                "workspace": str(tmp_path),
            },
        )
        assert result["status"] == "failed"
        assert "error" in result


class TestMCPToolsListIncludesNewTools:
    """Verify new tools appear in tools/list."""

    def test_tools_list_includes_queue_add(self):
        server = MCPServer()
        response = server.handle_one(
            {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "tools/list",
                "params": {},
            }
        )
        tool_names = [t["name"] for t in response["result"]["tools"]]
        assert "owlmind_queue_add" in tool_names
        assert "owlmind_session_start" in tool_names
        assert "owlmind_skill_run" in tool_names

    def test_tools_list_total_count(self):
        server = MCPServer()
        response = server.handle_one(
            {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "tools/list",
                "params": {},
            }
        )
        # Should have at least 9 tools now (6 existing + 3 new)
        assert len(response["result"]["tools"]) >= 9

    def test_tools_list_schemas_have_required(self):
        """Every tool that needs required params should declare them."""
        server = MCPServer()
        response = server.handle_one(
            {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "tools/list",
                "params": {},
            }
        )
        tools_by_name = {t["name"]: t for t in response["result"]["tools"]}

        # owlmind_queue_add requires goal and workspace
        qa_schema = tools_by_name["owlmind_queue_add"]["inputSchema"]
        assert "goal" in qa_schema["required"]
        assert "workspace" in qa_schema["required"]

        # owlmind_session_start requires goals and workspace
        ss_schema = tools_by_name["owlmind_session_start"]["inputSchema"]
        assert "goals" in ss_schema["required"]
        assert "workspace" in ss_schema["required"]

        # owlmind_skill_run requires pack_id, goal, workspace
        sr_schema = tools_by_name["owlmind_skill_run"]["inputSchema"]
        assert "pack_id" in sr_schema["required"]
        assert "goal" in sr_schema["required"]
        assert "workspace" in sr_schema["required"]
