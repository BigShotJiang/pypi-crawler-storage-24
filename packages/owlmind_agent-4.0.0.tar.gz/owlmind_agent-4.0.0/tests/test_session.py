"""Tests for session model, parsing, runner — no network calls."""

from __future__ import annotations

from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import yaml

from owlmind.session import (
    SESSION_BLOCKED,
    SESSION_DONE,
    SESSION_FAILED,
    SESSION_RUNNING,
    SESSION_STOPPED,
    GoalSpec,
    SessionLock,
    SessionMeta,
    append_session_event,
    create_session,
    load_session,
    parse_goals_file,
    read_session_events,
    render_protocol,
    resolve_goals,
    save_session,
)


def _write_goals(
    tmp_path: Path, goals: list[dict[str, Any]], defaults: dict[str, Any] | None = None
) -> Path:
    """Write a minimal goals.yaml and return its path."""
    data: dict[str, Any] = {"version": 1, "goals": goals}
    if defaults:
        data["defaults"] = defaults
    path = tmp_path / "goals.yaml"
    path.write_text(yaml.dump(data))
    return path


def _make_policies(tmp_path: Path) -> Path:
    """Create minimal policies directory."""
    policies_dir = tmp_path / "policies"
    policies_dir.mkdir(exist_ok=True)
    (policies_dir / "allowlist.yaml").write_text('allowed_commands:\n  - "^echo "\n  - "^pytest"\n')
    (policies_dir / "policy.yaml").write_text('forbidden_patterns:\n  - "rm -rf"\n')
    return policies_dir


class TestParseGoalsFile:
    def test_parses_basic(self, tmp_path: Path) -> None:
        path = _write_goals(
            tmp_path,
            [
                {"id": "G1", "goal": "Do thing one"},
                {"id": "G2", "goal": "Do thing two"},
            ],
        )
        defaults, goals = parse_goals_file(path)
        assert len(goals) == 2
        assert goals[0]["id"] == "G1"
        assert defaults == {}

    def test_parses_with_defaults(self, tmp_path: Path) -> None:
        path = _write_goals(
            tmp_path,
            [{"id": "G1", "goal": "Test"}],
            defaults={"use_llm": "none", "sandbox": True},
        )
        defaults, goals = parse_goals_file(path)
        assert defaults["use_llm"] == "none"
        assert defaults["sandbox"] is True

    def test_raises_on_empty_goals(self, tmp_path: Path) -> None:
        path = _write_goals(tmp_path, [])
        import pytest

        with pytest.raises(ValueError, match="No goals"):
            parse_goals_file(path)


class TestResolveGoals:
    def test_merges_defaults(self) -> None:
        defaults = {"use_llm": "planner", "max_steps": 10}
        goals_raw = [{"id": "G1", "goal": "Test goal"}]
        result = resolve_goals(defaults, goals_raw, "/tmp")
        assert len(result) == 1
        assert result[0].use_llm == "planner"
        assert result[0].max_steps == 10

    def test_goal_overrides_defaults(self) -> None:
        defaults = {"use_llm": "both"}
        goals_raw = [{"id": "G1", "goal": "Test", "use_llm": "none"}]
        result = resolve_goals(defaults, goals_raw, "/tmp")
        assert result[0].use_llm == "none"

    def test_workspace_resolution(self, tmp_path: Path) -> None:
        goals_raw = [{"id": "G1", "goal": "Test", "workspace": "subdir"}]
        result = resolve_goals({}, goals_raw, str(tmp_path))
        assert str(tmp_path / "subdir") in result[0].workspace

    def test_auto_generates_ids(self) -> None:
        goals_raw = [{"goal": "No ID"}, {"goal": "Also no ID"}]
        result = resolve_goals({}, goals_raw, "/tmp")
        assert result[0].id == "G1"
        assert result[1].id == "G2"

    def test_raises_on_missing_goal_text(self) -> None:
        goals_raw = [{"id": "G1"}]
        import pytest

        with pytest.raises(ValueError, match="no 'goal' text"):
            resolve_goals({}, goals_raw, "/tmp")


class TestSessionLock:
    def test_acquire_release(self, tmp_path: Path) -> None:
        lock = SessionLock(tmp_path / "s1" / ".lock")
        assert lock.acquire() is True
        lock.release()

    def test_double_acquire_fails(self, tmp_path: Path) -> None:
        lock1 = SessionLock(tmp_path / "s2" / ".lock")
        lock2 = SessionLock(tmp_path / "s2" / ".lock")
        assert lock1.acquire() is True
        assert lock2.acquire() is False
        lock1.release()
        assert lock2.acquire() is True
        lock2.release()

    def test_context_manager(self, tmp_path: Path) -> None:
        with SessionLock(tmp_path / "s3" / ".lock"):
            other = SessionLock(tmp_path / "s3" / ".lock")
            assert other.acquire() is False


class TestCreateSession:
    def test_creates_files(self, tmp_path: Path) -> None:
        goals_path = _write_goals(
            tmp_path,
            [
                {"id": "G1", "goal": "First goal"},
                {"id": "G2", "goal": "Second goal"},
            ],
            defaults={"use_llm": "none"},
        )

        sessions_dir = tmp_path / "sessions"
        meta = create_session(
            goals_file=goals_path,
            workspace=str(tmp_path),
            sessions_dir=sessions_dir,
        )

        assert meta.session_id.startswith("session-")
        assert meta.status == SESSION_RUNNING
        assert len(meta.goals) == 2

        sdir = sessions_dir / meta.session_id
        assert (sdir / "session_meta.json").exists()
        assert (sdir / "goals_resolved.yaml").exists()
        assert (sdir / "session.jsonl").exists()
        assert (sdir / "protocol.md").exists()


class TestSaveLoadSession:
    def test_roundtrip(self, tmp_path: Path) -> None:
        sessions_dir = tmp_path / "sessions"
        meta = SessionMeta(
            session_id="session-test123",
            created_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            status=SESSION_RUNNING,
            goals=[GoalSpec(id="G1", goal="Test")],
            runs=[],
        )
        save_session(meta, sessions_dir)

        loaded = load_session("session-test123", sessions_dir)
        assert loaded.session_id == "session-test123"
        assert loaded.status == SESSION_RUNNING
        assert len(loaded.goals) == 1
        assert loaded.goals[0].id == "G1"


class TestSessionEvents:
    def test_append_and_read(self, tmp_path: Path) -> None:
        sessions_dir = tmp_path / "sessions"
        sid = "session-evt1"
        (sessions_dir / sid).mkdir(parents=True)

        append_session_event(sid, sessions_dir, {"event": "TEST_EVENT", "data": 42})
        append_session_event(sid, sessions_dir, {"event": "ANOTHER", "data": "hello"})

        events = read_session_events(sid, sessions_dir)
        assert len(events) == 2
        assert events[0]["event"] == "TEST_EVENT"
        assert events[1]["data"] == "hello"
        assert "timestamp" in events[0]


class TestRenderProtocol:
    def test_renders_basic(self, tmp_path: Path) -> None:
        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"

        meta = SessionMeta(
            session_id="session-proto1",
            created_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            status=SESSION_RUNNING,
            goals=[
                GoalSpec(id="G1", goal="First goal"),
                GoalSpec(id="G2", goal="Second goal", notes="Important"),
            ],
            runs=[],
        )
        save_session(meta, sessions_dir)
        # Need jsonl file for events reading
        (sessions_dir / meta.session_id).mkdir(parents=True, exist_ok=True)

        content = render_protocol(meta.session_id, sessions_dir, runs_dir)

        assert "Session Protocol" in content
        assert "G1" in content
        assert "G2" in content
        assert "Important" in content
        assert "pending" in content


class TestSessionRunnerBlocked:
    def test_blocks_on_planner_wait(self, tmp_path: Path) -> None:
        """Session should BLOCK when autopilot blocks."""
        from owlmind.session_runner import run_session

        goals_path = _write_goals(
            tmp_path,
            [
                {
                    "id": "G1",
                    "goal": "Test goal",
                    "use_llm": "none",
                    "use_worker": "none",
                    "max_steps": 3,
                },
            ],
        )
        policies_dir = _make_policies(tmp_path)
        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"
        ledger_dir = tmp_path / "ledger"

        meta = create_session(
            goals_file=goals_path,
            workspace=str(tmp_path),
            sessions_dir=sessions_dir,
            policies_dir=str(policies_dir),
            runs_dir=str(runs_dir),
            ledger_dir=str(ledger_dir),
        )

        result = run_session(
            meta.session_id,
            sessions_dir=sessions_dir,
            runs_dir=runs_dir,
            policies_dir=policies_dir,
            ledger_dir=ledger_dir,
        )

        assert result.status == SESSION_BLOCKED
        assert result.goals_blocked >= 1
        assert any("resume" in cmd for cmd in result.next_commands)

    def test_resumes_after_mock_done(self, tmp_path: Path) -> None:
        """Session resumes and completes when autopilot returns DONE."""
        from owlmind.session_runner import run_session

        goals_path = _write_goals(
            tmp_path,
            [
                {"id": "G1", "goal": "Goal one"},
                {"id": "G2", "goal": "Goal two"},
            ],
        )
        policies_dir = _make_policies(tmp_path)
        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"
        ledger_dir = tmp_path / "ledger"

        meta = create_session(
            goals_file=goals_path,
            workspace=str(tmp_path),
            sessions_dir=sessions_dir,
            policies_dir=str(policies_dir),
            runs_dir=str(runs_dir),
            ledger_dir=str(ledger_dir),
        )

        # Mock autopilot.run to return DONE for both goals
        mock_result_1 = MagicMock()
        mock_result_1.run_id = "cycle-mock1"
        mock_result_1.final_state = "DONE"
        mock_result_1.stop_reason = "terminal state: DONE"
        mock_result_1.export_path = None

        mock_result_2 = MagicMock()
        mock_result_2.run_id = "cycle-mock2"
        mock_result_2.final_state = "DONE"
        mock_result_2.stop_reason = "terminal state: DONE"
        mock_result_2.export_path = None

        with patch("owlmind.autopilot.run", side_effect=[mock_result_1, mock_result_2]):
            result = run_session(
                meta.session_id,
                sessions_dir=sessions_dir,
                runs_dir=runs_dir,
                policies_dir=policies_dir,
                ledger_dir=ledger_dir,
            )

        assert result.status == SESSION_DONE
        assert result.goals_done == 2
        assert result.goals_total == 2
        assert any("export" in cmd for cmd in result.next_commands)

    def test_fails_on_goal_failure(self, tmp_path: Path) -> None:
        """Session should FAIL when a goal fails."""
        from owlmind.session_runner import run_session

        goals_path = _write_goals(
            tmp_path,
            [
                {"id": "G1", "goal": "Failing goal"},
            ],
        )
        policies_dir = _make_policies(tmp_path)
        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"
        ledger_dir = tmp_path / "ledger"

        meta = create_session(
            goals_file=goals_path,
            workspace=str(tmp_path),
            sessions_dir=sessions_dir,
            policies_dir=str(policies_dir),
            runs_dir=str(runs_dir),
            ledger_dir=str(ledger_dir),
        )

        mock_result = MagicMock()
        mock_result.run_id = "cycle-fail1"
        mock_result.final_state = "FAILED"
        mock_result.stop_reason = "hard_fail"
        mock_result.export_path = None

        with patch("owlmind.autopilot.run", return_value=mock_result):
            result = run_session(
                meta.session_id,
                sessions_dir=sessions_dir,
                runs_dir=runs_dir,
                policies_dir=policies_dir,
                ledger_dir=ledger_dir,
            )

        assert result.status == SESSION_FAILED
        assert result.goals_failed == 1


class TestSessionStop:
    def test_stop(self, tmp_path: Path) -> None:
        from owlmind.session_runner import stop_session

        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"

        meta = SessionMeta(
            session_id="session-stop1",
            created_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            status=SESSION_RUNNING,
            goals=[GoalSpec(id="G1", goal="Test")],
            runs=[],
        )
        save_session(meta, sessions_dir)
        (sessions_dir / meta.session_id).mkdir(parents=True, exist_ok=True)

        stopped = stop_session(meta.session_id, sessions_dir, runs_dir)
        assert stopped.status == "STOPPED"


# ---------------------------------------------------------------------------
# New tests targeting previously uncovered lines
# ---------------------------------------------------------------------------


class TestSessionLockContextManagerFailure:
    """Lines 128-129, 134-135: lock OSError path and __enter__ failure."""

    def test_release_handles_oserror(self, tmp_path: Path) -> None:
        """Lines 128-129: OSError during flock unlock is silently swallowed."""
        from unittest.mock import patch

        lock = SessionLock(tmp_path / "oserr" / ".lock")
        assert lock.acquire() is True

        with patch("fcntl.flock", side_effect=OSError("simulated unlock error")):
            # Must not raise — OSError is suppressed
            lock.release()

        # _file should be reset regardless
        assert lock._file is None

    def test_context_manager_raises_when_already_locked(self, tmp_path: Path) -> None:
        """Lines 134-135: __enter__ raises RuntimeError when lock cannot be acquired."""
        import pytest

        lock1 = SessionLock(tmp_path / "cme" / ".lock")
        lock2 = SessionLock(tmp_path / "cme" / ".lock")
        lock1.acquire()
        try:
            with pytest.raises(RuntimeError, match="Could not acquire session lock"), lock2:
                pass
        finally:
            lock1.release()


class TestResolveGoalsRollbackNonDict:
    """Line 195: non-dict rollback value falls back to default RollbackPolicy."""

    def test_non_dict_rollback_uses_default(self) -> None:
        from owlmind.session import RollbackPolicy

        goals_raw = [{"id": "G1", "goal": "Test goal", "rollback": "invalid_string"}]
        result = resolve_goals({}, goals_raw, "/tmp")

        assert len(result) == 1
        assert isinstance(result[0].rollback, RollbackPolicy)
        assert result[0].rollback.mode == "none"


class TestRenderProtocolPrPack:
    """Lines 504-508: render_protocol reads pr_pack.md and extracts PR Description."""

    def test_renders_pr_pack_summary(self, tmp_path: Path) -> None:
        from owlmind.session import GoalRunInfo

        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"

        run_id = "cycle-prpack1"
        (runs_dir / run_id).mkdir(parents=True)
        pr_pack_content = "# PR Description\n\nThis is the summary.\n\n# Other Section\nstuff\n"
        (runs_dir / run_id / "pr_pack.md").write_text(pr_pack_content)

        meta = SessionMeta(
            session_id="session-prpack1",
            created_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            status=SESSION_DONE,
            goals=[GoalSpec(id="G1", goal="Goal with pr_pack")],
            runs=[
                GoalRunInfo(
                    goal_id="G1",
                    run_id=run_id,
                    status="done",
                    started_at="2026-01-01T00:00:00Z",
                    ended_at="2026-01-01T01:00:00Z",
                )
            ],
        )
        save_session(meta, sessions_dir)

        content = render_protocol(meta.session_id, sessions_dir, runs_dir)

        assert "Summary" in content
        assert "This is the summary." in content


class TestRenderProtocolSummaryJson:
    """Lines 513-518: render_protocol reads summary.json as fallback."""

    def test_renders_summary_json_invalid_json_skipped(self, tmp_path: Path) -> None:
        """Lines 517-518: invalid JSON in summary.json → caught and skipped."""
        from owlmind.session import GoalRunInfo

        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"

        run_id = "cycle-invalidjson"
        (runs_dir / run_id).mkdir(parents=True)
        # Write invalid JSON — no pr_pack.md, so fallback to summary.json
        (runs_dir / run_id / "summary.json").write_text("INVALID {{{")

        meta = SessionMeta(
            session_id="session-invalidjson",
            created_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            status=SESSION_DONE,
            goals=[GoalSpec(id="G1", goal="Goal with invalid json")],
            runs=[GoalRunInfo(goal_id="G1", run_id=run_id, status="done")],
        )
        save_session(meta, sessions_dir)

        # Must not raise — exception is caught at lines 517-518
        content = render_protocol(meta.session_id, sessions_dir, runs_dir)
        assert "G1" in content

    def test_renders_summary_json_fallback(self, tmp_path: Path) -> None:
        import json

        from owlmind.session import GoalRunInfo

        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"

        run_id = "cycle-sumjson1"
        (runs_dir / run_id).mkdir(parents=True)
        summary_data = {"report": {"status": "APPROVED"}}
        (runs_dir / run_id / "summary.json").write_text(json.dumps(summary_data))

        meta = SessionMeta(
            session_id="session-sumjson1",
            created_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            status=SESSION_DONE,
            goals=[GoalSpec(id="G1", goal="Goal with summary json")],
            runs=[
                GoalRunInfo(
                    goal_id="G1",
                    run_id=run_id,
                    status="done",
                )
            ],
        )
        save_session(meta, sessions_dir)

        content = render_protocol(meta.session_id, sessions_dir, runs_dir)

        assert "Verdict" in content or "APPROVED" in content


class TestRenderProtocolRollbackSection:
    """Lines 523-528: render_protocol shows Rollback Policies section."""

    def test_renders_rollback_policies(self, tmp_path: Path) -> None:
        from owlmind.session import RollbackPolicy

        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"

        meta = SessionMeta(
            session_id="session-rollback1",
            created_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            status=SESSION_RUNNING,
            goals=[
                GoalSpec(
                    id="G1",
                    goal="Goal with rollback",
                    rollback=RollbackPolicy(mode="worktree_reset", require_approval=True),
                )
            ],
            runs=[],
        )
        save_session(meta, sessions_dir)

        content = render_protocol(meta.session_id, sessions_dir, runs_dir)

        assert "Rollback Policies" in content
        assert "worktree_reset" in content
        assert "G1" in content


class TestRenderProtocolBlockedState:
    """Line 541, lines 576-592: protocol shows blocked commands and block events."""

    def test_renders_blocked_status_commands(self, tmp_path: Path) -> None:
        from owlmind.session import GoalRunInfo

        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"

        meta = SessionMeta(
            session_id="session-blocked1",
            created_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            status=SESSION_BLOCKED,
            last_block_reason="Waiting for human approval",
            goals=[GoalSpec(id="G1", goal="Blocked goal")],
            runs=[
                GoalRunInfo(
                    goal_id="G1",
                    run_id="cycle-blk1",
                    status="blocked",
                )
            ],
        )
        save_session(meta, sessions_dir)

        content = render_protocol(meta.session_id, sessions_dir, runs_dir)

        assert "blocked" in content.lower()
        assert "approve" in content.lower() or "resume" in content.lower()
        assert "cycle-blk1" in content

    def test_renders_block_events_from_log(self, tmp_path: Path) -> None:
        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"

        sid = "session-blockevt1"
        meta = SessionMeta(
            session_id=sid,
            created_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            status=SESSION_RUNNING,
            goals=[GoalSpec(id="G1", goal="Event goal")],
            runs=[],
        )
        save_session(meta, sessions_dir)

        # Append a GOAL_BLOCKED event to the log
        append_session_event(
            sid,
            sessions_dir,
            {
                "event": "GOAL_BLOCKED",
                "goal_id": "G1",
                "reason": "Needs human review",
            },
        )

        content = render_protocol(sid, sessions_dir, runs_dir)

        assert "GOAL_BLOCKED" in content
        assert "Needs human review" in content

    def test_renders_session_blocked_event_with_no_last_block_reason(self, tmp_path: Path) -> None:
        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"

        sid = "session-blockevt2"
        meta = SessionMeta(
            session_id=sid,
            created_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            status=SESSION_RUNNING,
            last_block_reason="",
            goals=[GoalSpec(id="G1", goal="Block event goal")],
            runs=[],
        )
        save_session(meta, sessions_dir)

        # Use SESSION_BLOCKED event type (triggers line 541 branch)
        append_session_event(
            sid,
            sessions_dir,
            {"event": "SESSION_BLOCKED", "goal_id": "G1", "reason": "Blocked by policy"},
        )

        content = render_protocol(sid, sessions_dir, runs_dir)
        assert "Decisions & Blocks" in content


class TestRenderProtocolFailedState:
    """Lines 611-635: protocol renders FAILED and STOPPED states."""

    def test_renders_failed_state(self, tmp_path: Path) -> None:
        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"

        meta = SessionMeta(
            session_id="session-failed1",
            created_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            status=SESSION_FAILED,
            goals=[GoalSpec(id="G1", goal="Failing goal")],
            runs=[],
        )
        save_session(meta, sessions_dir)

        content = render_protocol(meta.session_id, sessions_dir, runs_dir)

        assert "failed" in content.lower()
        assert "status" in content.lower()

    def test_renders_stopped_state(self, tmp_path: Path) -> None:
        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"

        meta = SessionMeta(
            session_id="session-stopped2",
            created_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            status=SESSION_STOPPED,
            goals=[GoalSpec(id="G1", goal="Stopped goal")],
            runs=[],
        )
        save_session(meta, sessions_dir)

        content = render_protocol(meta.session_id, sessions_dir, runs_dir)

        assert "resume" in content.lower()


class TestExtractSection:
    """Lines 576-592: _extract_section helper."""

    def test_extracts_section_content(self) -> None:
        from owlmind.session import _extract_section

        text = "# Intro\nsome intro\n\n# PR Description\nThis is it.\n\n# Other\nignored\n"
        result = _extract_section(text, "PR Description")
        assert "This is it." in result
        assert "ignored" not in result

    def test_truncates_long_content(self) -> None:
        from owlmind.session import _extract_section

        long_content = "x" * 1000
        text = f"# PR Description\n{long_content}\n"
        result = _extract_section(text, "PR Description", max_chars=100)
        assert result.endswith("...")
        assert len(result) == 103  # 100 chars + "..."

    def test_returns_empty_when_section_missing(self) -> None:
        from owlmind.session import _extract_section

        text = "# Something\nContent\n"
        result = _extract_section(text, "NonExistent Section")
        assert result == ""


class TestBuildSessionContext:
    """Lines 611-635: build_session_context with completed runs."""

    def test_returns_empty_when_no_completed_runs(self, tmp_path: Path) -> None:
        from owlmind.session import build_session_context

        meta = SessionMeta(
            session_id="session-ctx1",
            created_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            status=SESSION_RUNNING,
            goals=[GoalSpec(id="G1", goal="Test")],
            runs=[],
        )
        result = build_session_context(meta, tmp_path / "runs")
        assert result == ""

    def test_returns_context_for_completed_runs(self, tmp_path: Path) -> None:
        from owlmind.session import GoalRunInfo, build_session_context

        runs_dir = tmp_path / "runs"
        run_id = "cycle-ctx1"
        (runs_dir / run_id).mkdir(parents=True)

        meta = SessionMeta(
            session_id="session-ctx2",
            created_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            status=SESSION_DONE,
            goals=[GoalSpec(id="G1", goal="Completed goal")],
            runs=[GoalRunInfo(goal_id="G1", run_id=run_id, status="done")],
        )
        result = build_session_context(meta, runs_dir)
        assert "Session Context" in result
        assert "G1" in result
        assert "Completed goal" in result

    def test_reads_pr_pack_for_context(self, tmp_path: Path) -> None:
        from owlmind.session import GoalRunInfo, build_session_context

        runs_dir = tmp_path / "runs"
        run_id = "cycle-ctx2"
        (runs_dir / run_id).mkdir(parents=True)
        pr_pack_content = "# PR Description\n\nSummary from pack.\n\n# Extra\nignoreme\n"
        (runs_dir / run_id / "pr_pack.md").write_text(pr_pack_content)

        meta = SessionMeta(
            session_id="session-ctx3",
            created_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            status=SESSION_DONE,
            goals=[GoalSpec(id="G1", goal="Goal with pack")],
            runs=[GoalRunInfo(goal_id="G1", run_id=run_id, status="done")],
        )
        result = build_session_context(meta, runs_dir)
        assert "Summary from pack." in result

    def test_respects_max_goals_limit(self, tmp_path: Path) -> None:
        from owlmind.session import GoalRunInfo, build_session_context

        runs_dir = tmp_path / "runs"
        runs = []
        goals = []
        for i in range(5):
            run_id = f"cycle-ctx-{i}"
            (runs_dir / run_id).mkdir(parents=True)
            runs.append(GoalRunInfo(goal_id=f"G{i}", run_id=run_id, status="done"))
            goals.append(GoalSpec(id=f"G{i}", goal=f"Goal {i}"))

        meta = SessionMeta(
            session_id="session-ctx4",
            created_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            status=SESSION_DONE,
            goals=goals,
            runs=runs,
        )
        result = build_session_context(meta, runs_dir, max_goals=2)
        # Only last 2 completed goals should appear
        assert "G3" in result
        assert "G4" in result
        assert "G0" not in result


class TestRenderProtocolDAGView:
    """Lines 448-455: DAG view is rendered when goals have dependencies."""

    def test_renders_dag_view_when_deps_present(self, tmp_path: Path) -> None:
        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"

        meta = SessionMeta(
            session_id="session-dag1",
            created_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            status=SESSION_RUNNING,
            goals=[
                GoalSpec(id="G1", goal="First goal"),
                GoalSpec(id="G2", goal="Depends on G1", depends_on=["G1"]),
            ],
            runs=[],
        )
        save_session(meta, sessions_dir)

        content = render_protocol(meta.session_id, sessions_dir, runs_dir)

        assert "DAG View" in content
        assert "G1" in content
        assert "G2" in content

    def test_no_dag_section_without_deps(self, tmp_path: Path) -> None:
        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"

        meta = SessionMeta(
            session_id="session-nodag1",
            created_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            status=SESSION_RUNNING,
            goals=[
                GoalSpec(id="G1", goal="Standalone goal"),
            ],
            runs=[],
        )
        save_session(meta, sessions_dir)

        content = render_protocol(meta.session_id, sessions_dir, runs_dir)

        assert "DAG View" not in content


class TestRenderProtocolConcurrencyInfo:
    """Lines 442-445: concurrency info is rendered when max_concurrency > 1."""

    def test_renders_max_concurrency(self, tmp_path: Path) -> None:
        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"

        meta = SessionMeta(
            session_id="session-concur1",
            created_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            status=SESSION_RUNNING,
            goals=[GoalSpec(id="G1", goal="Concurrent goal")],
            runs=[],
            max_concurrency=4,
            continue_on_fail=True,
        )
        save_session(meta, sessions_dir)

        content = render_protocol(meta.session_id, sessions_dir, runs_dir)

        assert "Max concurrency" in content and "4" in content
        assert "Continue on fail" in content and "yes" in content


class TestBuildSessionContextBadSummaryJson:
    """Lines 517-518: invalid JSON in summary.json → caught, pass."""

    def test_bad_summary_json_skipped(self, tmp_path: Path) -> None:
        from owlmind.session import GoalRunInfo, build_session_context

        runs_dir = tmp_path / "runs"
        run_id = "cycle-badsummary"
        run_dir = runs_dir / run_id
        run_dir.mkdir(parents=True)
        # Write invalid JSON to summary.json (no pr_pack.md → will try summary.json)
        (run_dir / "summary.json").write_text("NOT VALID JSON {{{")

        meta = SessionMeta(
            session_id="session-badsummary",
            created_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            status=SESSION_DONE,
            goals=[GoalSpec(id="G1", goal="Bad summary goal")],
            runs=[GoalRunInfo(goal_id="G1", run_id=run_id, status="done")],
        )
        # Should not raise despite bad JSON
        result = build_session_context(meta, runs_dir)
        assert "G1" in result
