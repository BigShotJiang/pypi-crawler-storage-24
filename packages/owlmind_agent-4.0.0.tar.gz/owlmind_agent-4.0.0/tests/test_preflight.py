"""Tests for preflight checks — unit tests only, no network."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any
from unittest.mock import patch

from owlmind.preflight import (
    PreflightConfig,
    PreflightReport,
    _redact_key,
    run_preflight,
)


class TestRedaction:
    def test_short_key_fully_redacted(self) -> None:
        assert _redact_key("abc") == "***"

    def test_long_key_partially_shown(self) -> None:
        result = _redact_key("sk-1234567890abcdef")
        assert result.startswith("sk-1")
        assert result.endswith("cdef")
        assert "..." in result

    def test_exactly_12_chars_redacted(self) -> None:
        assert _redact_key("123456789012") == "***"

    def test_13_chars_shows_partial(self) -> None:
        result = _redact_key("1234567890123")
        assert result == "1234...0123"


class TestPackageCheck:
    def test_package_structure_ok(self) -> None:
        config = PreflightConfig(use_llm="none")
        report = run_preflight(config)

        pkg_checks = [c for c in report.checks if c.name == "package_structure"]
        assert len(pkg_checks) == 1
        assert pkg_checks[0].ok is True
        assert "owlmind" in pkg_checks[0].details


class TestEnvVarDetection:
    def test_missing_openai_key_detected(self) -> None:
        env = {k: v for k, v in os.environ.items() if k != "OPENAI_API_KEY"}
        with patch.dict(os.environ, env, clear=True):
            config = PreflightConfig(use_llm="both", providers=["openai"])
            report = run_preflight(config)

        assert "OPENAI_API_KEY" in report.missing_env

    def test_present_openai_key(self) -> None:
        with patch.dict(os.environ, {"OPENAI_API_KEY": "sk-test1234567890abcdef"}):
            config = PreflightConfig(use_llm="both", providers=["openai"])
            report = run_preflight(config)

        env_checks = [c for c in report.checks if c.name == "env_openai"]
        assert len(env_checks) == 1
        assert env_checks[0].ok is True
        # Full key must NOT appear
        assert "sk-test1234567890abcdef" not in env_checks[0].details

    def test_missing_anthropic_key(self) -> None:
        env = {k: v for k, v in os.environ.items() if k != "ANTHROPIC_API_KEY"}
        with patch.dict(os.environ, env, clear=True):
            config = PreflightConfig(use_llm="planner", providers=["anthropic"])
            report = run_preflight(config)

        assert "ANTHROPIC_API_KEY" in report.missing_env

    def test_gemini_accepts_google_api_key(self) -> None:
        env = {k: v for k, v in os.environ.items() if k not in ("GEMINI_API_KEY", "GOOGLE_API_KEY")}
        env["GOOGLE_API_KEY"] = "AIzaSy-test1234567890"
        with patch.dict(os.environ, env, clear=True):
            config = PreflightConfig(use_llm="both", providers=["gemini"])
            report = run_preflight(config)

        env_checks = [c for c in report.checks if c.name == "env_gemini"]
        assert len(env_checks) == 1
        assert env_checks[0].ok is True

    def test_no_env_check_when_llm_none(self) -> None:
        config = PreflightConfig(use_llm="none")
        report = run_preflight(config)
        assert report.missing_env == []


class TestDepDetection:
    def test_missing_dep_detected(self) -> None:
        """Mock a missing import to trigger dep check."""
        import importlib

        original = importlib.import_module

        def fake_import(name: str) -> Any:
            if name == "openai":
                raise ImportError("No module named openai")
            return original(name)

        config = PreflightConfig(use_llm="both", providers=["openai"])
        with patch("importlib.import_module", side_effect=fake_import):
            report = run_preflight(config)

        assert "openai" in report.missing_deps
        assert any("owlmind[openai]" in r for r in report.recommended_installs)


class TestBinaryDetection:
    def test_claude_missing(self) -> None:
        with patch("shutil.which", return_value=None):
            config = PreflightConfig(use_worker="claude_cli")
            report = run_preflight(config)

        assert "claude" in report.missing_binaries
        assert report.ok is False

    def test_claude_present(self) -> None:
        with patch("shutil.which", return_value="/usr/local/bin/claude"):
            config = PreflightConfig(use_worker="claude_cli")
            report = run_preflight(config)

        assert "claude" not in report.missing_binaries
        bin_checks = [c for c in report.checks if c.name == "binary_claude"]
        assert len(bin_checks) == 1
        assert bin_checks[0].ok is True

    def test_git_checked_for_sandbox(self) -> None:
        with patch("shutil.which", return_value="/usr/bin/git"):
            config = PreflightConfig(sandbox=True)
            report = run_preflight(config)

        git_checks = [c for c in report.checks if c.name == "binary_git"]
        assert len(git_checks) == 1
        assert git_checks[0].ok is True


class TestWorkspaceCheck:
    def test_workspace_exists(self, tmp_path: Path) -> None:
        config = PreflightConfig(workspace=str(tmp_path))
        report = run_preflight(config)

        ws_checks = [c for c in report.checks if c.name == "workspace_exists"]
        assert len(ws_checks) == 1
        assert ws_checks[0].ok is True

    def test_workspace_missing(self, tmp_path: Path) -> None:
        config = PreflightConfig(workspace=str(tmp_path / "nonexistent"))
        report = run_preflight(config)

        ws_checks = [c for c in report.checks if c.name == "workspace"]
        assert len(ws_checks) == 1
        assert ws_checks[0].ok is False


class TestPreflightReport:
    def test_to_json_roundtrip(self) -> None:
        report = PreflightReport(ok=True)
        json_str = report.to_json()
        assert '"ok": true' in json_str

    def test_to_dict_structure(self) -> None:
        report = PreflightReport(ok=False, missing_env=["OPENAI_API_KEY"])
        d = report.to_dict()
        assert d["ok"] is False
        assert "OPENAI_API_KEY" in d["missing_env"]

    def test_overall_ok_when_no_issues(self, tmp_path: Path) -> None:
        config = PreflightConfig(use_llm="none", use_worker="none", workspace=str(tmp_path))
        report = run_preflight(config)
        assert report.ok is True


# ===========================================================================
# TestNeededProviders — lines 89-96
# ===========================================================================


class TestNeededProviders:
    def test_explicit_providers_returned_directly(self) -> None:
        """When config.providers is set, _needed_providers returns it verbatim (lines 85-86)."""
        from owlmind.preflight import _needed_providers

        config = PreflightConfig(use_llm="both", providers=["anthropic", "gemini"])
        result = _needed_providers(config)
        assert result == ["anthropic", "gemini"]

    def test_use_llm_none_returns_empty(self) -> None:
        """use_llm=='none' → _needed_providers returns [] without reading config (lines 82-83)."""
        from owlmind.preflight import _needed_providers

        config = PreflightConfig(use_llm="none")
        result = _needed_providers(config)
        assert result == []

    def test_falls_back_to_owlmind_config(self) -> None:
        """providers=None + use_llm!='none' → reads OwlMindConfig from env (lines 89-96)."""
        from owlmind.preflight import _needed_providers

        config = PreflightConfig(use_llm="both", providers=None)
        result = _needed_providers(config)
        assert isinstance(result, list)

    def test_judge_only_provider_appended(self) -> None:
        """Judge provider not in planner list gets appended (line 95)."""
        from unittest.mock import MagicMock

        from owlmind.preflight import _needed_providers

        mock_cfg = MagicMock()
        mock_cfg.router.planner_providers = ["openai"]
        mock_cfg.router.judge_providers = ["anthropic"]  # not in planner list

        config = PreflightConfig(use_llm="both", providers=None)
        with patch("owlmind.config.OwlMindConfig.from_env", return_value=mock_cfg):
            result = _needed_providers(config)

        assert "openai" in result
        assert "anthropic" in result
        assert result.index("openai") < result.index("anthropic")


# ===========================================================================
# TestCheckEnvVarsUnknownProvider — line 173
# ===========================================================================


class TestCheckEnvVarsUnknownProvider:
    def test_unknown_provider_silently_skipped(self) -> None:
        """Provider not in _ENV_MAP produces no checks or missing_env entries (line 173)."""
        from owlmind.preflight import _check_env_vars

        report = PreflightReport()
        _check_env_vars(report, ["ollama"])
        env_checks = [c for c in report.checks if "env_" in c.name]
        assert env_checks == []
        assert report.missing_env == []


# ===========================================================================
# TestCheckDepsUnknownProvider — line 213
# ===========================================================================


class TestCheckDepsUnknownProvider:
    def test_unknown_provider_dep_skipped(self) -> None:
        """Provider not in _DEP_MAP produces no dep checks (line 213)."""
        from owlmind.preflight import _check_deps

        report = PreflightReport()
        _check_deps(report, ["ollama"])
        dep_checks = [c for c in report.checks if "dep_" in c.name]
        assert dep_checks == []
        assert report.missing_deps == []


# ===========================================================================
# TestCheckBinariesGitMissing — lines 270-277
# ===========================================================================


class TestCheckBinariesGitMissing:
    def test_git_missing_when_sandbox_enabled(self) -> None:
        """binary_git FAIL check added when git not in PATH (lines 270-277)."""
        from owlmind.preflight import _check_binaries

        report = PreflightReport()
        config = PreflightConfig(sandbox=True, use_worker="none")
        with patch("shutil.which", return_value=None):
            _check_binaries(report, config)

        git_checks = [c for c in report.checks if c.name == "binary_git"]
        assert len(git_checks) == 1
        assert git_checks[0].ok is False
        assert "git" in report.missing_binaries

    def test_git_and_claude_both_missing(self) -> None:
        """Both binary_claude and binary_git fail when sandbox+claude_cli and nothing in PATH."""
        from owlmind.preflight import _check_binaries

        report = PreflightReport()
        config = PreflightConfig(sandbox=True, use_worker="claude_cli")
        with patch("shutil.which", return_value=None):
            _check_binaries(report, config)

        assert "claude" in report.missing_binaries
        assert "git" in report.missing_binaries


# ===========================================================================
# TestCheckWorkspaceSandboxGit — lines 324-340
# ===========================================================================


class TestCheckWorkspaceSandboxGit:
    def test_sandbox_git_repo_clean(self, tmp_path: Path) -> None:
        """workspace_git check reports 'clean' when git status is empty (lines 324-329)."""
        import subprocess

        from owlmind.preflight import _check_workspace

        (tmp_path / ".git").mkdir()
        report = PreflightReport()
        config = PreflightConfig(workspace=str(tmp_path), sandbox=True)

        clean = subprocess.CompletedProcess(
            args=["git", "status", "--porcelain"], returncode=0, stdout="", stderr=""
        )
        with patch("subprocess.run", return_value=clean):
            _check_workspace(report, config)

        git_checks = [c for c in report.checks if c.name == "workspace_git"]
        assert len(git_checks) == 1
        assert "clean" in git_checks[0].details

    def test_sandbox_git_repo_dirty(self, tmp_path: Path) -> None:
        """workspace_git check reports 'dirty' when git status has output (lines 316-321)."""
        import subprocess

        from owlmind.preflight import _check_workspace

        (tmp_path / ".git").mkdir()
        report = PreflightReport()
        config = PreflightConfig(workspace=str(tmp_path), sandbox=True)

        dirty = subprocess.CompletedProcess(
            args=["git", "status", "--porcelain"],
            returncode=0,
            stdout=" M modified.py\n",
            stderr="",
        )
        with patch("subprocess.run", return_value=dirty):
            _check_workspace(report, config)

        git_checks = [c for c in report.checks if c.name == "workspace_git"]
        assert len(git_checks) == 1
        assert "dirty" in git_checks[0].details

    def test_sandbox_git_status_timeout(self, tmp_path: Path) -> None:
        """TimeoutExpired during git status is handled gracefully (lines 331-337)."""
        import subprocess

        from owlmind.preflight import _check_workspace

        (tmp_path / ".git").mkdir()
        report = PreflightReport()
        config = PreflightConfig(workspace=str(tmp_path), sandbox=True)

        with patch(
            "subprocess.run",
            side_effect=subprocess.TimeoutExpired(cmd="git", timeout=10),
        ):
            _check_workspace(report, config)

        git_checks = [c for c in report.checks if c.name == "workspace_git"]
        assert len(git_checks) == 1
        assert git_checks[0].ok is True
        assert "failed" in git_checks[0].details.lower()

    def test_sandbox_git_status_file_not_found(self, tmp_path: Path) -> None:
        """FileNotFoundError (git missing) during git status handled gracefully."""
        from owlmind.preflight import _check_workspace

        (tmp_path / ".git").mkdir()
        report = PreflightReport()
        config = PreflightConfig(workspace=str(tmp_path), sandbox=True)

        with patch("subprocess.run", side_effect=FileNotFoundError("git not found")):
            _check_workspace(report, config)

        git_checks = [c for c in report.checks if c.name == "workspace_git"]
        assert len(git_checks) == 1
        assert git_checks[0].ok is True

    def test_sandbox_non_git_workspace(self, tmp_path: Path) -> None:
        """No .git dir with sandbox=True → 'plain copy' note (lines 340-345)."""
        from owlmind.preflight import _check_workspace

        report = PreflightReport()
        config = PreflightConfig(workspace=str(tmp_path), sandbox=True)
        _check_workspace(report, config)

        git_checks = [c for c in report.checks if c.name == "workspace_git"]
        assert len(git_checks) == 1
        assert "plain" in git_checks[0].details.lower()


# ===========================================================================
# TestCheckProviderStatus — lines 380-381
# ===========================================================================


class TestCheckPackageFailure:
    def test_package_structure_fail_when_no_version(self) -> None:
        """_check_package adds ok=False check when __init__.py lacks __version__ (line 152)."""
        from owlmind.preflight import _check_package

        report = PreflightReport()
        # Mock the init_path.exists() to True but content to lack __version__
        with (
            patch("pathlib.Path.exists", return_value=True),
            patch("pathlib.Path.read_text", return_value="# no version here\n"),
        ):
            _check_package(report)

        pkg_checks = [c for c in report.checks if c.name == "package_structure"]
        assert len(pkg_checks) == 1
        assert pkg_checks[0].ok is False
        assert "missing" in pkg_checks[0].details.lower() or "__version__" in pkg_checks[0].details


class TestCheckBudgetException:
    def test_budget_check_exception_falls_back(self) -> None:
        """_check_budget except branch fires when OwlMindConfig.from_env raises (lines 380-381)."""
        from owlmind.preflight import _check_budget

        report = PreflightReport()
        with patch(
            "owlmind.config.OwlMindConfig.from_env",
            side_effect=RuntimeError("config error"),
        ):
            _check_budget(report)

        budget_checks = [c for c in report.checks if c.name == "budget"]
        assert len(budget_checks) == 1
        assert budget_checks[0].ok is True
        assert "first run" in budget_checks[0].details.lower()


class TestCheckProviderStatus:
    def test_disabled_when_env_missing(self) -> None:
        """'disabled: API key not set' when env check fails but dep passes (lines 380-381)."""
        from owlmind.preflight import PreflightCheck, _check_provider_status

        report = PreflightReport()
        report.checks.append(
            PreflightCheck(name="env_openai", ok=False, details="OPENAI_API_KEY not set")
        )
        report.checks.append(
            PreflightCheck(name="dep_openai", ok=True, details="openai importable")
        )
        _check_provider_status(report, ["openai"])
        assert report.provider_status["openai"] == "disabled: API key not set"

    def test_enabled_when_both_ok(self) -> None:
        """'enabled' when both env and dep checks pass."""
        from owlmind.preflight import PreflightCheck, _check_provider_status

        report = PreflightReport()
        report.checks.append(
            PreflightCheck(name="env_openai", ok=True, details="OPENAI_API_KEY set")
        )
        report.checks.append(
            PreflightCheck(name="dep_openai", ok=True, details="openai importable")
        )
        _check_provider_status(report, ["openai"])
        assert report.provider_status["openai"] == "enabled"

    def test_disabled_when_dep_missing(self) -> None:
        """'disabled: SDK not installed' when dep check fails."""
        from owlmind.preflight import PreflightCheck, _check_provider_status

        report = PreflightReport()
        report.checks.append(
            PreflightCheck(name="dep_openai", ok=False, details="openai not installed")
        )
        _check_provider_status(report, ["openai"])
        assert report.provider_status["openai"] == "disabled: SDK not installed"
