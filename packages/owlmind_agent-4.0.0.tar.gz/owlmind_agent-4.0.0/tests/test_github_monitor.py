"""Tests for github_monitor module."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from owlmind.github_monitor import (
    CIFailure,
    _github_request,
    _scan_repo,
    format_fix_goal,
    scan_failed_checks,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_failure(
    repo: str = "owner/repo",
    pr_number: int = 1,
    check_name: str = "test-check",
    conclusion: str = "failure",
) -> CIFailure:
    return CIFailure(
        repo=repo,
        pr_number=pr_number,
        pr_title="Fix something",
        pr_branch="fix/something",
        check_name=check_name,
        conclusion=conclusion,
        html_url="https://github.com/owner/repo/actions/runs/123",
    )


def _make_pr(number: int = 1, sha: str = "abc123def456") -> dict:
    return {
        "number": number,
        "title": "Test PR",
        "head": {"ref": "fix/branch", "sha": sha},
    }


def _make_checks(*conclusions: str) -> dict:
    return {
        "check_runs": [
            {
                "name": f"check-{i}",
                "conclusion": conclusion,
                "html_url": f"https://github.com/run/{i}",
            }
            for i, conclusion in enumerate(conclusions)
        ]
    }


# ===========================================================================
# TestCIFailure
# ===========================================================================


class TestCIFailure:
    def test_can_create_ci_failure(self) -> None:
        f = _make_failure()
        assert f.repo == "owner/repo"
        assert f.pr_number == 1
        assert f.conclusion == "failure"

    def test_workspace_defaults_to_empty_string(self) -> None:
        f = _make_failure()
        assert f.workspace == ""


# ===========================================================================
# TestGithubRequest
# ===========================================================================


class TestGithubRequest:
    def test_returns_none_on_http_error(self) -> None:
        with patch("urllib.request.urlopen", side_effect=Exception("connection refused")):
            result = _github_request("https://api.github.com/test", "token123")
        assert result is None

    def test_returns_parsed_json_on_success(self) -> None:
        mock_response = MagicMock()
        mock_response.read.return_value = b'{"key": "value"}'
        mock_response.__enter__ = lambda s: s
        mock_response.__exit__ = MagicMock(return_value=False)
        with patch("urllib.request.urlopen", return_value=mock_response):
            result = _github_request("https://api.github.com/test", "token123")
        assert result == {"key": "value"}

    def test_returns_none_on_invalid_json(self) -> None:
        mock_response = MagicMock()
        mock_response.read.return_value = b"{invalid json"
        mock_response.__enter__ = lambda s: s
        mock_response.__exit__ = MagicMock(return_value=False)
        with patch("urllib.request.urlopen", return_value=mock_response):
            result = _github_request("https://api.github.com/test", "token123")
        assert result is None


# ===========================================================================
# TestScanRepo
# ===========================================================================


class TestScanRepo:
    def test_returns_empty_when_prs_api_fails(self) -> None:
        with patch("owlmind.github_monitor._github_request", return_value=None):
            result = _scan_repo("owner/repo", "token")
        assert result == []

    def test_returns_empty_when_no_prs(self) -> None:
        with patch("owlmind.github_monitor._github_request", return_value=[]):
            result = _scan_repo("owner/repo", "token")
        assert result == []

    def test_detects_failed_check(self) -> None:
        pr = _make_pr(number=42, sha="abc123")
        checks = _make_checks("failure")

        def mock_request(url: str, token: str):
            if "pulls" in url:
                return [pr]
            if "check-runs" in url:
                return checks
            return None

        with patch("owlmind.github_monitor._github_request", side_effect=mock_request):
            result = _scan_repo("owner/repo", "token")

        assert len(result) == 1
        assert result[0].pr_number == 42
        assert result[0].conclusion == "failure"

    def test_detects_timed_out_check(self) -> None:
        pr = _make_pr(sha="abc123")
        checks = _make_checks("timed_out")

        def mock_request(url: str, token: str):
            if "pulls" in url:
                return [pr]
            return checks

        with patch("owlmind.github_monitor._github_request", side_effect=mock_request):
            result = _scan_repo("owner/repo", "token")

        assert len(result) == 1
        assert result[0].conclusion == "timed_out"

    def test_skips_successful_checks(self) -> None:
        pr = _make_pr(sha="abc123")
        checks = _make_checks("success", "success")

        def mock_request(url: str, token: str):
            if "pulls" in url:
                return [pr]
            return checks

        with patch("owlmind.github_monitor._github_request", side_effect=mock_request):
            result = _scan_repo("owner/repo", "token")

        assert result == []

    def test_skips_pr_without_sha(self) -> None:
        pr = {"number": 1, "title": "PR", "head": {"ref": "branch", "sha": ""}}
        with patch("owlmind.github_monitor._github_request", return_value=[pr]):
            result = _scan_repo("owner/repo", "token")
        assert result == []

    def test_skips_checks_when_api_returns_non_dict(self) -> None:
        pr = _make_pr(sha="abc123")

        def mock_request(url: str, token: str):
            if "pulls" in url:
                return [pr]
            return None  # checks API fails

        with patch("owlmind.github_monitor._github_request", side_effect=mock_request):
            result = _scan_repo("owner/repo", "token")
        assert result == []

    def test_multiple_failed_checks_on_one_pr(self) -> None:
        pr = _make_pr(sha="abc123")
        checks = _make_checks("failure", "timed_out", "success")

        def mock_request(url: str, token: str):
            if "pulls" in url:
                return [pr]
            return checks

        with patch("owlmind.github_monitor._github_request", side_effect=mock_request):
            result = _scan_repo("owner/repo", "token")

        assert len(result) == 2


# ===========================================================================
# TestScanFailedChecks
# ===========================================================================


class TestScanFailedChecks:
    def test_empty_repos_returns_empty_list(self) -> None:
        result = scan_failed_checks([], "token")
        assert result == []

    def test_aggregates_results_from_multiple_repos(self) -> None:
        failure = _make_failure()

        with patch("owlmind.github_monitor._scan_repo", return_value=[failure]):
            result = scan_failed_checks(["owner/repo1", "owner/repo2"], "token")

        assert len(result) == 2

    def test_skips_repo_on_exception(self) -> None:
        def mock_scan(repo: str, token: str) -> list:
            if repo == "bad/repo":
                raise RuntimeError("network error")
            return [_make_failure(repo=repo)]

        with patch("owlmind.github_monitor._scan_repo", side_effect=mock_scan):
            result = scan_failed_checks(["good/repo", "bad/repo"], "token")

        assert len(result) == 1
        assert result[0].repo == "good/repo"

    def test_returns_ci_failure_objects(self) -> None:
        with patch("owlmind.github_monitor._scan_repo", return_value=[_make_failure()]):
            result = scan_failed_checks(["owner/repo"], "token")
        assert all(isinstance(f, CIFailure) for f in result)


# ===========================================================================
# TestFormatFixGoal
# ===========================================================================


class TestFormatFixGoal:
    def test_returns_non_empty_string(self) -> None:
        failure = _make_failure()
        goal = format_fix_goal(failure, workspace="/tmp/project")
        assert isinstance(goal, str)
        assert len(goal) > 0

    def test_contains_pr_number(self) -> None:
        failure = _make_failure(pr_number=99)
        goal = format_fix_goal(failure, workspace="/tmp")
        assert "99" in goal

    def test_contains_repo_name(self) -> None:
        failure = _make_failure(repo="myorg/myrepo")
        goal = format_fix_goal(failure, workspace="/tmp")
        assert "myorg/myrepo" in goal

    def test_contains_branch_name(self) -> None:
        failure = CIFailure(
            repo="org/repo",
            pr_number=1,
            pr_title="title",
            pr_branch="feat/my-branch",
            check_name="lint",
            conclusion="failure",
            html_url="https://example.com",
        )
        goal = format_fix_goal(failure, workspace="/tmp")
        assert "feat/my-branch" in goal

    def test_contains_check_name(self) -> None:
        failure = _make_failure(check_name="my-custom-check")
        goal = format_fix_goal(failure, workspace="/tmp")
        assert "my-custom-check" in goal

    def test_contains_html_url(self) -> None:
        failure = CIFailure(
            repo="org/repo",
            pr_number=1,
            pr_title="title",
            pr_branch="main",
            check_name="test",
            conclusion="failure",
            html_url="https://github.com/actions/runs/42",
        )
        goal = format_fix_goal(failure, workspace="/tmp")
        assert "https://github.com/actions/runs/42" in goal
