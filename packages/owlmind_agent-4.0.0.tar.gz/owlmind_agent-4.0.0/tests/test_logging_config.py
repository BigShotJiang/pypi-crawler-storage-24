"""Tests for owlmind.logging_config — structured logging with secret redaction."""

from __future__ import annotations

import io
import json
import logging
import os
from unittest.mock import patch

from owlmind.logging_config import (
    JsonFormatter,
    RedactedFormatter,
    _redact_secrets,
    setup_logging,
)


class TestRedactSecrets:
    def test_openai_key_redacted(self) -> None:
        text = "Using key sk-abcdefghijklmnopqrst for API"
        assert "sk-" not in _redact_secrets(text)
        assert "***" in _redact_secrets(text)

    def test_anthropic_key_redacted(self) -> None:
        text = "Key is sk-ant-abcdefghijklmnopqrst"
        assert "sk-ant-" not in _redact_secrets(text)
        assert "***" in _redact_secrets(text)

    def test_telegram_token_redacted(self) -> None:
        text = "Bot token: 123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZabcde"
        result = _redact_secrets(text)
        assert "ABCDEFGHIJ" not in result

    def test_normal_text_unchanged(self) -> None:
        text = "Hello world, no secrets here"
        assert _redact_secrets(text) == text

    def test_short_sk_prefix_not_redacted(self) -> None:
        text = "sk-short"
        assert _redact_secrets(text) == text


class TestJsonFormatter:
    def test_format_returns_valid_json(self) -> None:
        formatter = JsonFormatter()
        record = logging.LogRecord(
            name="owlmind.test",
            level=logging.INFO,
            pathname="",
            lineno=0,
            msg="hello",
            args=(),
            exc_info=None,
        )
        output = formatter.format(record)
        parsed = json.loads(output)
        assert parsed["msg"] == "hello"
        assert parsed["level"] == "INFO"

    def test_format_includes_standard_fields(self) -> None:
        formatter = JsonFormatter()
        record = logging.LogRecord(
            name="owlmind.cycle",
            level=logging.WARNING,
            pathname="",
            lineno=0,
            msg="test msg",
            args=(),
            exc_info=None,
        )
        output = json.loads(formatter.format(record))
        assert "ts" in output
        assert "level" in output
        assert "logger" in output
        assert "msg" in output

    def test_format_includes_extra_fields(self) -> None:
        formatter = JsonFormatter()
        record = logging.LogRecord(
            name="owlmind.test",
            level=logging.INFO,
            pathname="",
            lineno=0,
            msg="test",
            args=(),
            exc_info=None,
        )
        record.run_id = "run-123"  # type: ignore[attr-defined]
        record.stage = "planner"  # type: ignore[attr-defined]
        output = json.loads(formatter.format(record))
        assert output["run_id"] == "run-123"
        assert output["stage"] == "planner"

    def test_format_redacts_secrets(self) -> None:
        formatter = JsonFormatter()
        record = logging.LogRecord(
            name="owlmind.test",
            level=logging.INFO,
            pathname="",
            lineno=0,
            msg="Key is sk-abcdefghijklmnopqrst",
            args=(),
            exc_info=None,
        )
        output = json.loads(formatter.format(record))
        assert "sk-" not in output["msg"]

    def test_format_includes_exception(self) -> None:
        formatter = JsonFormatter()
        try:
            raise ValueError("test error")
        except ValueError:
            import sys

            record = logging.LogRecord(
                name="owlmind.test",
                level=logging.ERROR,
                pathname="",
                lineno=0,
                msg="failed",
                args=(),
                exc_info=sys.exc_info(),
            )
        output = json.loads(formatter.format(record))
        assert "exc" in output
        assert "ValueError" in output["exc"]


class TestRedactedFormatter:
    def test_format_redacts_secrets(self) -> None:
        formatter = RedactedFormatter(fmt="%(message)s")
        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="",
            lineno=0,
            msg="Key sk-abcdefghijklmnopqrst used",
            args=(),
            exc_info=None,
        )
        output = formatter.format(record)
        assert "sk-" not in output
        assert "***" in output

    def test_format_preserves_normal_text(self) -> None:
        formatter = RedactedFormatter(fmt="%(message)s")
        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname="",
            lineno=0,
            msg="normal text",
            args=(),
            exc_info=None,
        )
        assert formatter.format(record) == "normal text"


class TestSetupLogging:
    def _get_logger(self) -> logging.Logger:
        return logging.getLogger("owlmind")

    def test_default_level_is_warning(self) -> None:
        buf = io.StringIO()
        setup_logging(stream=buf)
        logger = self._get_logger()
        assert logger.level == logging.WARNING

    def test_debug_level(self) -> None:
        buf = io.StringIO()
        setup_logging(level="DEBUG", stream=buf)
        logger = self._get_logger()
        assert logger.level == logging.DEBUG

    def test_json_format_produces_json(self) -> None:
        buf = io.StringIO()
        setup_logging(level="DEBUG", json_format=True, stream=buf)
        logger = logging.getLogger("owlmind.test.json")
        logger.info("test message")
        output = buf.getvalue().strip()
        parsed = json.loads(output)
        assert parsed["msg"] == "test message"

    def test_text_format_includes_level(self) -> None:
        buf = io.StringIO()
        setup_logging(level="DEBUG", json_format=False, stream=buf)
        logger = logging.getLogger("owlmind.test.text")
        logger.warning("test warning")
        output = buf.getvalue()
        assert "WARNING" in output
        assert "test warning" in output

    def test_clears_previous_handlers(self) -> None:
        buf = io.StringIO()
        setup_logging(stream=buf)
        setup_logging(stream=buf)
        root = self._get_logger()
        assert len(root.handlers) == 1


class TestLogConfigFromEnv:
    def test_log_level_env(self) -> None:
        from owlmind.config import OwlMindConfig

        with patch.dict(os.environ, {"OWLMIND_LOG_LEVEL": "DEBUG"}, clear=True):
            cfg = OwlMindConfig.from_env()
        assert cfg.log.level == "DEBUG"

    def test_log_json_env(self) -> None:
        from owlmind.config import OwlMindConfig

        with patch.dict(os.environ, {"OWLMIND_LOG_FORMAT": "json"}, clear=True):
            cfg = OwlMindConfig.from_env()
        assert cfg.log.json_format is True

    def test_log_defaults(self) -> None:
        from owlmind.config import OwlMindConfig

        with patch.dict(os.environ, {}, clear=True):
            cfg = OwlMindConfig.from_env()
        assert cfg.log.level == "WARNING"
        assert cfg.log.json_format is False
