"""Tests for issue tracker integrations (Jira + Trello)."""

from __future__ import annotations

import asyncio
import json
import urllib.error
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from owlmind.config import OwlMindConfig, JiraConfig, TrelloConfig
from owlmind.integrations.issue_trackers import (
    IssueResult,
    IssueTracker,
    JiraTracker,
    TrelloTracker,
    create_issue_tracker,
)
from owlmind.integrations.issue_trackers.base import TrackerConfig

# ── Helpers ────────────────────────────────────────────────────────────────


def _run(coro: Any) -> Any:
    """Run an async coroutine synchronously."""
    return asyncio.run(coro)


def _mock_urlopen(response_json: dict, status: int = 200) -> MagicMock:
    """Create a mock for urllib.request.urlopen returning *response_json*."""
    mock_resp = MagicMock()
    mock_resp.read.return_value = json.dumps(response_json).encode()
    mock_resp.status = status
    mock_resp.__enter__ = lambda s: s
    mock_resp.__exit__ = MagicMock(return_value=False)
    return mock_resp


# ── Models / Base ──────────────────────────────────────────────────────────


class TestModels:
    """Test base models and dataclasses."""

    def test_issue_result_defaults(self) -> None:
        r = IssueResult(ok=True)
        assert r.ok is True
        assert r.issue_id == ""
        assert r.issue_key == ""
        assert r.url == ""
        assert r.detail == ""

    def test_issue_result_with_values(self) -> None:
        r = IssueResult(ok=True, issue_id="123", issue_key="DEV-1", url="https://jira/DEV-1")
        assert r.issue_key == "DEV-1"
        assert r.url == "https://jira/DEV-1"

    def test_issue_result_failure(self) -> None:
        r = IssueResult(ok=False, detail="Something went wrong")
        assert r.ok is False
        assert r.detail == "Something went wrong"

    def test_tracker_config_defaults(self) -> None:
        c = TrackerConfig(tracker_type="jira")
        assert c.tracker_type == "jira"
        assert c.timeout == 15

    def test_tracker_config_custom_timeout(self) -> None:
        c = TrackerConfig(tracker_type="trello", timeout=30)
        assert c.timeout == 30


class TestFormatDescription:
    """Test IssueTracker.format_description template rendering."""

    def test_simple_substitution(self) -> None:
        result = IssueTracker.format_description(
            "Bug in $module: $summary",
            {"module": "auth", "summary": "login fails"},
        )
        assert result == "Bug in auth: login fails"

    def test_missing_vars_left_as_is(self) -> None:
        result = IssueTracker.format_description(
            "Issue: $title ($unknown)",
            {"title": "Fix"},
        )
        assert result == "Issue: Fix ($unknown)"

    def test_braced_syntax(self) -> None:
        result = IssueTracker.format_description(
            "${project}-${num} ${desc}",
            {"project": "DEV", "num": "42", "desc": "Refactor"},
        )
        assert result == "DEV-42 Refactor"

    def test_empty_template(self) -> None:
        assert IssueTracker.format_description("", {}) == ""

    def test_no_placeholders(self) -> None:
        assert IssueTracker.format_description("plain text", {"x": "y"}) == "plain text"


# ── Factory ────────────────────────────────────────────────────────────────


class TestFactory:
    """Test create_issue_tracker factory."""

    def test_create_jira(self) -> None:
        t = create_issue_tracker(
            "jira",
            base_url="https://org.atlassian.net",
            email="user@org.com",
            api_token="tok",
        )
        assert isinstance(t, JiraTracker)
        assert t.tracker_type == "jira"

    def test_create_trello(self) -> None:
        t = create_issue_tracker("trello", api_key="key123", token="tok456")
        assert isinstance(t, TrelloTracker)
        assert t.tracker_type == "trello"

    def test_create_case_insensitive(self) -> None:
        t = create_issue_tracker("JIRA", base_url="u", email="e", api_token="t")
        assert isinstance(t, JiraTracker)

    def test_create_with_whitespace(self) -> None:
        t = create_issue_tracker("  trello  ", api_key="k", token="t")
        assert isinstance(t, TrelloTracker)

    def test_unsupported_type_raises(self) -> None:
        with pytest.raises(ValueError, match="Unsupported tracker type"):
            create_issue_tracker("github")

    def test_custom_timeout(self) -> None:
        t = create_issue_tracker(
            "jira",
            base_url="https://x.atlassian.net",
            email="e",
            api_token="t",
            timeout=30,
        )
        assert isinstance(t, JiraTracker)


# ── JiraTracker ────────────────────────────────────────────────────────────


class TestJiraTracker:
    """Test JiraTracker functionality."""

    def _make_tracker(self) -> JiraTracker:
        return JiraTracker(
            base_url="https://org.atlassian.net",
            email="user@org.com",
            api_token="tok123",
            timeout=10,
        )

    def test_tracker_type(self) -> None:
        assert self._make_tracker().tracker_type == "jira"

    def test_headers_contain_basic_auth(self) -> None:
        t = self._make_tracker()
        headers = t._headers()
        assert "Authorization" in headers
        assert headers["Authorization"].startswith("Basic ")
        assert headers["Content-Type"] == "application/json"

    def test_base_url_trailing_slash_stripped(self) -> None:
        t = JiraTracker(
            base_url="https://org.atlassian.net/",
            email="e",
            api_token="t",
        )
        assert t._base == "https://org.atlassian.net"

    @patch("owlmind.integrations.issue_trackers.jira.urllib.request.urlopen")
    def test_create_issue_success(self, mock_urlopen_fn: MagicMock) -> None:
        mock_urlopen_fn.return_value = _mock_urlopen({"id": "10001", "key": "DEV-42"})
        t = self._make_tracker()
        result = _run(
            t.create_issue(
                {
                    "project": "DEV",
                    "summary": "Fix login bug",
                    "description": "Users cannot log in",
                    "issuetype": "Bug",
                    "priority": "High",
                    "labels": ["backend"],
                }
            )
        )
        assert result.ok is True
        assert result.issue_key == "DEV-42"
        assert result.issue_id == "10001"
        assert "DEV-42" in result.url

    @patch("owlmind.integrations.issue_trackers.jira.urllib.request.urlopen")
    def test_create_issue_minimal(self, mock_urlopen_fn: MagicMock) -> None:
        mock_urlopen_fn.return_value = _mock_urlopen({"id": "1", "key": "P-1"})
        t = self._make_tracker()
        result = _run(t.create_issue({"project": "P", "summary": "Task"}))
        assert result.ok is True
        assert result.issue_key == "P-1"

    def test_create_issue_missing_project(self) -> None:
        t = self._make_tracker()
        result = _run(t.create_issue({"summary": "No project"}))
        assert result.ok is False
        assert "project" in result.detail.lower()

    def test_create_issue_missing_summary(self) -> None:
        t = self._make_tracker()
        result = _run(t.create_issue({"project": "DEV"}))
        assert result.ok is False
        assert "summary" in result.detail.lower()

    @patch("owlmind.integrations.issue_trackers.jira.urllib.request.urlopen")
    def test_create_issue_api_error(self, mock_urlopen_fn: MagicMock) -> None:
        err = urllib.error.HTTPError(
            "https://org.atlassian.net/rest/api/3/issue",
            400,
            "Bad Request",
            {},  # type: ignore[arg-type]
            MagicMock(read=lambda: b"bad request"),
        )
        mock_urlopen_fn.side_effect = err
        t = self._make_tracker()
        result = _run(t.create_issue({"project": "DEV", "summary": "Fail"}))
        assert result.ok is False

    @patch("owlmind.integrations.issue_trackers.jira.urllib.request.urlopen")
    def test_validate_config_ok(self, mock_urlopen_fn: MagicMock) -> None:
        mock_urlopen_fn.return_value = _mock_urlopen({"serverTitle": "Jira"})
        t = self._make_tracker()
        assert _run(t.validate_config()) is True

    @patch("owlmind.integrations.issue_trackers.jira.urllib.request.urlopen")
    def test_validate_config_fail(self, mock_urlopen_fn: MagicMock) -> None:
        err = urllib.error.HTTPError(
            "https://org.atlassian.net/rest/api/3/serverInfo",
            401,
            "Unauthorized",
            {},  # type: ignore[arg-type]
            MagicMock(read=lambda: b"unauthorized"),
        )
        mock_urlopen_fn.side_effect = err
        t = self._make_tracker()
        assert _run(t.validate_config()) is False

    @patch("owlmind.integrations.issue_trackers.jira.urllib.request.urlopen")
    def test_create_issue_with_adf_description(self, mock_urlopen_fn: MagicMock) -> None:
        """Verify description is sent in ADF format."""
        mock_urlopen_fn.return_value = _mock_urlopen({"id": "1", "key": "X-1"})
        t = self._make_tracker()
        _run(
            t.create_issue(
                {
                    "project": "X",
                    "summary": "ADF test",
                    "description": "Some text",
                }
            )
        )
        # Inspect the request body
        call_args = mock_urlopen_fn.call_args
        req = call_args[0][0]
        body = json.loads(req.data.decode())
        desc = body["fields"]["description"]
        assert desc["type"] == "doc"
        assert desc["version"] == 1
        assert desc["content"][0]["type"] == "paragraph"


# ── TrelloTracker ──────────────────────────────────────────────────────────


class TestTrelloTracker:
    """Test TrelloTracker functionality."""

    def _make_tracker(self) -> TrelloTracker:
        return TrelloTracker(api_key="key123", token="tok456", timeout=10)

    def test_tracker_type(self) -> None:
        assert self._make_tracker().tracker_type == "trello"

    def test_auth_params(self) -> None:
        t = self._make_tracker()
        params = t._auth_params()
        assert params["key"] == "key123"
        assert params["token"] == "tok456"

    @patch("owlmind.integrations.issue_trackers.trello.urllib.request.urlopen")
    def test_create_card_success(self, mock_urlopen_fn: MagicMock) -> None:
        mock_urlopen_fn.return_value = _mock_urlopen(
            {
                "id": "card123",
                "shortLink": "abc",
                "shortUrl": "https://trello.com/c/abc",
            }
        )
        t = self._make_tracker()
        result = _run(
            t.create_issue(
                {
                    "list_id": "list1",
                    "name": "Fix bug",
                    "desc": "Something is broken",
                    "pos": "top",
                }
            )
        )
        assert result.ok is True
        assert result.issue_id == "card123"
        assert result.issue_key == "abc"
        assert "trello.com" in result.url

    @patch("owlmind.integrations.issue_trackers.trello.urllib.request.urlopen")
    def test_create_card_minimal(self, mock_urlopen_fn: MagicMock) -> None:
        mock_urlopen_fn.return_value = _mock_urlopen(
            {
                "id": "c1",
                "shortLink": "x",
                "shortUrl": "https://trello.com/c/x",
            }
        )
        t = self._make_tracker()
        result = _run(t.create_issue({"list_id": "L", "name": "Task"}))
        assert result.ok is True

    def test_create_card_missing_list_id(self) -> None:
        t = self._make_tracker()
        result = _run(t.create_issue({"name": "No list"}))
        assert result.ok is False
        assert "list_id" in result.detail.lower()

    def test_create_card_missing_name(self) -> None:
        t = self._make_tracker()
        result = _run(t.create_issue({"list_id": "L"}))
        assert result.ok is False
        assert "name" in result.detail.lower()

    @patch("owlmind.integrations.issue_trackers.trello.urllib.request.urlopen")
    def test_create_card_api_error(self, mock_urlopen_fn: MagicMock) -> None:
        err = urllib.error.HTTPError(
            "https://api.trello.com/1/cards",
            401,
            "Unauthorized",
            {},  # type: ignore[arg-type]
            MagicMock(read=lambda: b"unauthorized"),
        )
        mock_urlopen_fn.side_effect = err
        t = self._make_tracker()
        result = _run(t.create_issue({"list_id": "L", "name": "Fail"}))
        assert result.ok is False

    @patch("owlmind.integrations.issue_trackers.trello.urllib.request.urlopen")
    def test_validate_config_ok(self, mock_urlopen_fn: MagicMock) -> None:
        mock_urlopen_fn.return_value = _mock_urlopen({"id": "me", "username": "user"})
        t = self._make_tracker()
        assert _run(t.validate_config()) is True

    @patch("owlmind.integrations.issue_trackers.trello.urllib.request.urlopen")
    def test_validate_config_fail(self, mock_urlopen_fn: MagicMock) -> None:
        err = urllib.error.HTTPError(
            "https://api.trello.com/1/members/me",
            401,
            "Unauthorized",
            {},  # type: ignore[arg-type]
            MagicMock(read=lambda: b"bad"),
        )
        mock_urlopen_fn.side_effect = err
        t = self._make_tracker()
        assert _run(t.validate_config()) is False

    @patch("owlmind.integrations.issue_trackers.trello.urllib.request.urlopen")
    def test_create_card_with_labels_and_members(self, mock_urlopen_fn: MagicMock) -> None:
        mock_urlopen_fn.return_value = _mock_urlopen(
            {
                "id": "c2",
                "shortLink": "y",
                "shortUrl": "https://trello.com/c/y",
            }
        )
        t = self._make_tracker()
        result = _run(
            t.create_issue(
                {
                    "list_id": "L",
                    "name": "Card with extras",
                    "idLabels": ["lbl1", "lbl2"],
                    "idMembers": ["m1"],
                }
            )
        )
        assert result.ok is True
        # Verify query params include labels
        call_args = mock_urlopen_fn.call_args
        req = call_args[0][0]
        # Comma is URL-encoded as %2C in query string
        assert "lbl1" in req.full_url
        assert "lbl2" in req.full_url
        assert "m1" in req.full_url


# ── Config ─────────────────────────────────────────────────────────────────


class TestConfig:
    """Test JiraConfig and TrelloConfig models."""

    def test_jira_config_defaults(self) -> None:
        c = JiraConfig()
        assert c.base_url == ""
        assert c.email == ""
        assert c.api_token == ""
        assert c.timeout == 15
        assert c.enabled is False

    def test_jira_config_enabled(self) -> None:
        c = JiraConfig(base_url="https://jira", email="e", api_token="t")
        assert c.enabled is True

    def test_jira_config_partially_set(self) -> None:
        c = JiraConfig(base_url="https://jira")
        assert c.enabled is False

    def test_trello_config_defaults(self) -> None:
        c = TrelloConfig()
        assert c.api_key == ""
        assert c.token == ""
        assert c.timeout == 15
        assert c.enabled is False

    def test_trello_config_enabled(self) -> None:
        c = TrelloConfig(api_key="k", token="t")
        assert c.enabled is True

    def test_trello_config_partially_set(self) -> None:
        c = TrelloConfig(api_key="k")
        assert c.enabled is False

    def test_owlmind_config_has_jira_trello(self) -> None:
        cfg = OwlMindConfig()
        assert isinstance(cfg.jira, JiraConfig)
        assert isinstance(cfg.trello, TrelloConfig)

    @patch.dict(
        "os.environ",
        {
            "OWLMIND_JIRA_BASE_URL": "https://acme.atlassian.net",
            "OWLMIND_JIRA_EMAIL": "dev@acme.com",
            "OWLMIND_JIRA_API_TOKEN": "jira-tok",
            "OWLMIND_JIRA_TIMEOUT": "20",
            "OWLMIND_TRELLO_API_KEY": "trello-key",
            "OWLMIND_TRELLO_TOKEN": "trello-tok",
            "OWLMIND_TRELLO_TIMEOUT": "25",
        },
        clear=True,
    )
    def test_from_env_loads_jira_trello(self) -> None:
        cfg = OwlMindConfig.from_env()
        assert cfg.jira.base_url == "https://acme.atlassian.net"
        assert cfg.jira.email == "dev@acme.com"
        assert cfg.jira.api_token == "jira-tok"
        assert cfg.jira.timeout == 20
        assert cfg.jira.enabled is True

        assert cfg.trello.api_key == "trello-key"
        assert cfg.trello.token == "trello-tok"
        assert cfg.trello.timeout == 25
        assert cfg.trello.enabled is True


# ── CLI ────────────────────────────────────────────────────────────────────


class TestCLI:
    """Test CLI commands are registered and work."""

    def test_jira_app_registered(self) -> None:
        from owlmind.cli import app

        names = [cmd.name for cmd in app.registered_groups]
        assert "jira" in names

    def test_trello_app_registered(self) -> None:
        from owlmind.cli import app

        names = [cmd.name for cmd in app.registered_groups]
        assert "trello" in names

    def test_jira_commands_exist(self) -> None:
        from owlmind.cli.jira_cmd import jira_app

        cmd_names = [c.name for c in jira_app.registered_commands]
        assert "create-issue" in cmd_names
        assert "validate" in cmd_names

    def test_trello_commands_exist(self) -> None:
        from owlmind.cli.trello_cmd import trello_app

        cmd_names = [c.name for c in trello_app.registered_commands]
        assert "create-card" in cmd_names
        assert "validate" in cmd_names


# ── CLI Helpers ───────────────────────────────────────────────────────────


class TestJiraConfigHelper:
    """Test _get_jira_config() helper."""

    @patch.dict(
        "os.environ",
        {
            "OWLMIND_JIRA_BASE_URL": "https://acme.atlassian.net",
            "OWLMIND_JIRA_EMAIL": "dev@acme.com",
            "OWLMIND_JIRA_API_TOKEN": "secret-tok",
        },
    )
    def test_full_config(self) -> None:
        from owlmind.cli.jira_cmd import _get_jira_config

        cfg = _get_jira_config()
        assert cfg["base_url"] == "https://acme.atlassian.net"
        assert cfg["email"] == "dev@acme.com"
        assert cfg["api_token"] == "secret-tok"

    @patch.dict("os.environ", {}, clear=True)
    def test_empty_config(self) -> None:
        from owlmind.cli.jira_cmd import _get_jira_config

        cfg = _get_jira_config()
        assert cfg["base_url"] == ""
        assert cfg["email"] == ""
        assert cfg["api_token"] == ""

    @patch.dict(
        "os.environ",
        {"OWLMIND_JIRA_BASE_URL": "https://jira"},
        clear=True,
    )
    def test_partial_config(self) -> None:
        from owlmind.cli.jira_cmd import _get_jira_config

        cfg = _get_jira_config()
        assert cfg["base_url"] == "https://jira"
        assert cfg["email"] == ""
        assert cfg["api_token"] == ""


class TestTrelloConfigHelper:
    """Test _get_trello_config() helper."""

    @patch.dict(
        "os.environ",
        {
            "OWLMIND_TRELLO_API_KEY": "mykey",
            "OWLMIND_TRELLO_TOKEN": "mytok",
        },
    )
    def test_full_config(self) -> None:
        from owlmind.cli.trello_cmd import _get_trello_config

        cfg = _get_trello_config()
        assert cfg["api_key"] == "mykey"
        assert cfg["token"] == "mytok"

    @patch.dict("os.environ", {}, clear=True)
    def test_empty_config(self) -> None:
        from owlmind.cli.trello_cmd import _get_trello_config

        cfg = _get_trello_config()
        assert cfg["api_key"] == ""
        assert cfg["token"] == ""


# ── CLI Command Flow (Jira) ──────────────────────────────────────────────


class TestJiraCLICommands:
    """Test jira CLI command invocation via Typer CliRunner."""

    def _invoke(self, args: list[str], env: dict[str, str] | None = None) -> Any:
        from typer.testing import CliRunner

        from owlmind.cli.jira_cmd import jira_app

        runner = CliRunner()
        return runner.invoke(jira_app, args, env=env)

    def test_create_issue_missing_config(self) -> None:
        result = self._invoke(
            ["create-issue", "--project", "DEV", "--summary", "Bug"],
            env={},
        )
        assert result.exit_code != 0
        assert "not configured" in result.output.lower() or "jira" in result.output.lower()

    @patch("owlmind.cli.jira_cmd.asyncio.run")
    @patch("owlmind.cli.jira_cmd._get_jira_config")
    def test_create_issue_success(
        self,
        mock_cfg: MagicMock,
        mock_run: MagicMock,
    ) -> None:
        mock_cfg.return_value = {
            "base_url": "https://jira.test",
            "email": "e@t.com",
            "api_token": "tok",
        }
        mock_run.return_value = IssueResult(
            ok=True,
            issue_id="100",
            issue_key="DEV-42",
            url="https://jira.test/browse/DEV-42",
        )
        result = self._invoke(["create-issue", "--project", "DEV", "--summary", "Fix bug"])
        assert result.exit_code == 0
        assert "DEV-42" in result.output
        assert "https://jira.test/browse/DEV-42" in result.output

    @patch("owlmind.cli.jira_cmd.asyncio.run")
    @patch("owlmind.cli.jira_cmd._get_jira_config")
    def test_create_issue_success_no_url(
        self,
        mock_cfg: MagicMock,
        mock_run: MagicMock,
    ) -> None:
        mock_cfg.return_value = {
            "base_url": "https://jira.test",
            "email": "e@t.com",
            "api_token": "tok",
        }
        mock_run.return_value = IssueResult(ok=True, issue_id="100", issue_key="DEV-1", url="")
        result = self._invoke(["create-issue", "--project", "DEV", "--summary", "Task"])
        assert result.exit_code == 0
        assert "DEV-1" in result.output
        assert "URL" not in result.output

    @patch("owlmind.cli.jira_cmd.asyncio.run")
    @patch("owlmind.cli.jira_cmd._get_jira_config")
    def test_create_issue_failure(
        self,
        mock_cfg: MagicMock,
        mock_run: MagicMock,
    ) -> None:
        mock_cfg.return_value = {
            "base_url": "https://jira.test",
            "email": "e@t.com",
            "api_token": "tok",
        }
        mock_run.return_value = IssueResult(ok=False, detail="Permission denied")
        result = self._invoke(["create-issue", "--project", "DEV", "--summary", "Bug"])
        assert result.exit_code != 0
        assert "Permission denied" in result.output

    @patch("owlmind.cli.jira_cmd.asyncio.run")
    @patch("owlmind.cli.jira_cmd._get_jira_config")
    def test_create_issue_with_optional_params(
        self,
        mock_cfg: MagicMock,
        mock_run: MagicMock,
    ) -> None:
        mock_cfg.return_value = {
            "base_url": "https://jira.test",
            "email": "e@t.com",
            "api_token": "tok",
        }
        mock_run.return_value = IssueResult(ok=True, issue_key="DEV-5")
        result = self._invoke(
            [
                "create-issue",
                "--project",
                "DEV",
                "--summary",
                "Add feature",
                "--desc",
                "Detailed description here",
                "--type",
                "Story",
                "--priority",
                "High",
            ]
        )
        assert result.exit_code == 0
        assert mock_run.called

    @patch("owlmind.cli.jira_cmd.asyncio.run")
    @patch("owlmind.cli.jira_cmd._get_jira_config")
    def test_create_issue_without_optional_params(
        self,
        mock_cfg: MagicMock,
        mock_run: MagicMock,
    ) -> None:
        mock_cfg.return_value = {
            "base_url": "https://jira.test",
            "email": "e@t.com",
            "api_token": "tok",
        }
        mock_run.return_value = IssueResult(ok=True, issue_key="DEV-6")
        result = self._invoke(["create-issue", "--project", "DEV", "--summary", "Task"])
        assert result.exit_code == 0
        assert mock_run.called

    def test_validate_missing_base_url(self) -> None:
        result = self._invoke(["validate"], env={})
        assert result.exit_code != 0
        assert "not set" in result.output.lower() or "jira" in result.output.lower()

    @patch("owlmind.cli.jira_cmd.asyncio.run")
    @patch("owlmind.cli.jira_cmd._get_jira_config")
    def test_validate_success(
        self,
        mock_cfg: MagicMock,
        mock_run: MagicMock,
    ) -> None:
        mock_cfg.return_value = {
            "base_url": "https://jira.test",
            "email": "e@t.com",
            "api_token": "tok",
        }
        mock_run.return_value = True
        result = self._invoke(["validate"])
        assert result.exit_code == 0
        assert "ok" in result.output.lower()

    @patch("owlmind.cli.jira_cmd.asyncio.run")
    @patch("owlmind.cli.jira_cmd._get_jira_config")
    def test_validate_failure(
        self,
        mock_cfg: MagicMock,
        mock_run: MagicMock,
    ) -> None:
        mock_cfg.return_value = {
            "base_url": "https://jira.test",
            "email": "e@t.com",
            "api_token": "tok",
        }
        mock_run.return_value = False
        result = self._invoke(["validate"])
        assert result.exit_code != 0
        assert "failed" in result.output.lower()


# ── CLI Command Flow (Trello) ────────────────────────────────────────────


class TestTrelloCLICommands:
    """Test trello CLI command invocation via Typer CliRunner."""

    def _invoke(self, args: list[str], env: dict[str, str] | None = None) -> Any:
        from typer.testing import CliRunner

        from owlmind.cli.trello_cmd import trello_app

        runner = CliRunner()
        return runner.invoke(trello_app, args, env=env)

    def test_create_card_missing_config(self) -> None:
        result = self._invoke(
            ["create-card", "--list", "L1", "--name", "Card"],
            env={},
        )
        assert result.exit_code != 0
        assert "not configured" in result.output.lower() or "trello" in result.output.lower()

    @patch("owlmind.cli.trello_cmd.asyncio.run")
    @patch("owlmind.cli.trello_cmd._get_trello_config")
    def test_create_card_success(
        self,
        mock_cfg: MagicMock,
        mock_run: MagicMock,
    ) -> None:
        mock_cfg.return_value = {"api_key": "k", "token": "t"}
        mock_run.return_value = IssueResult(
            ok=True,
            issue_id="card1",
            issue_key="abc",
            url="https://trello.com/c/abc",
        )
        result = self._invoke(["create-card", "--list", "L1", "--name", "Bug fix"])
        assert result.exit_code == 0
        assert "abc" in result.output
        assert "trello.com" in result.output

    @patch("owlmind.cli.trello_cmd.asyncio.run")
    @patch("owlmind.cli.trello_cmd._get_trello_config")
    def test_create_card_success_no_url(
        self,
        mock_cfg: MagicMock,
        mock_run: MagicMock,
    ) -> None:
        mock_cfg.return_value = {"api_key": "k", "token": "t"}
        mock_run.return_value = IssueResult(ok=True, issue_id="c1", issue_key="x", url="")
        result = self._invoke(["create-card", "--list", "L1", "--name", "Task"])
        assert result.exit_code == 0
        assert "x" in result.output
        assert "URL" not in result.output

    @patch("owlmind.cli.trello_cmd.asyncio.run")
    @patch("owlmind.cli.trello_cmd._get_trello_config")
    def test_create_card_failure(
        self,
        mock_cfg: MagicMock,
        mock_run: MagicMock,
    ) -> None:
        mock_cfg.return_value = {"api_key": "k", "token": "t"}
        mock_run.return_value = IssueResult(ok=False, detail="Board not found")
        result = self._invoke(["create-card", "--list", "L1", "--name", "Bug"])
        assert result.exit_code != 0
        assert "Board not found" in result.output

    @patch("owlmind.cli.trello_cmd.asyncio.run")
    @patch("owlmind.cli.trello_cmd._get_trello_config")
    def test_create_card_with_desc(
        self,
        mock_cfg: MagicMock,
        mock_run: MagicMock,
    ) -> None:
        mock_cfg.return_value = {"api_key": "k", "token": "t"}
        mock_run.return_value = IssueResult(ok=True, issue_key="z")
        result = self._invoke(
            [
                "create-card",
                "--list",
                "L1",
                "--name",
                "Feature",
                "--desc",
                "A detailed description",
                "--pos",
                "top",
            ]
        )
        assert result.exit_code == 0
        assert mock_run.called

    def test_validate_missing_api_key(self) -> None:
        result = self._invoke(["validate"], env={})
        assert result.exit_code != 0
        assert "not set" in result.output.lower() or "trello" in result.output.lower()

    @patch("owlmind.cli.trello_cmd.asyncio.run")
    @patch("owlmind.cli.trello_cmd._get_trello_config")
    def test_validate_success(
        self,
        mock_cfg: MagicMock,
        mock_run: MagicMock,
    ) -> None:
        mock_cfg.return_value = {"api_key": "k", "token": "t"}
        mock_run.return_value = True
        result = self._invoke(["validate"])
        assert result.exit_code == 0
        assert "ok" in result.output.lower()

    @patch("owlmind.cli.trello_cmd.asyncio.run")
    @patch("owlmind.cli.trello_cmd._get_trello_config")
    def test_validate_failure(
        self,
        mock_cfg: MagicMock,
        mock_run: MagicMock,
    ) -> None:
        mock_cfg.return_value = {"api_key": "k", "token": "t"}
        mock_run.return_value = False
        result = self._invoke(["validate"])
        assert result.exit_code != 0
        assert "failed" in result.output.lower()


# ── Tracker Error Handling ───────────────────────────────────────────────


class TestTrackerErrorHandling:
    """Test error handling edge cases in trackers."""

    @patch("owlmind.integrations.issue_trackers.jira.urllib.request.urlopen")
    def test_jira_network_error(self, mock_urlopen_fn: MagicMock) -> None:
        mock_urlopen_fn.side_effect = urllib.error.URLError("Connection refused")
        t = JiraTracker(base_url="https://jira.test", email="e", api_token="t")
        result = _run(t.create_issue({"project": "DEV", "summary": "Test"}))
        assert result.ok is False

    @patch("owlmind.integrations.issue_trackers.trello.urllib.request.urlopen")
    def test_trello_network_error(self, mock_urlopen_fn: MagicMock) -> None:
        mock_urlopen_fn.side_effect = urllib.error.URLError("Connection refused")
        t = TrelloTracker(api_key="k", token="t")
        result = _run(t.create_issue({"list_id": "L", "name": "Test"}))
        assert result.ok is False

    @patch("owlmind.integrations.issue_trackers.jira.urllib.request.urlopen")
    def test_jira_validate_network_error(self, mock_urlopen_fn: MagicMock) -> None:
        mock_urlopen_fn.side_effect = urllib.error.URLError("DNS failure")
        t = JiraTracker(base_url="https://jira.test", email="e", api_token="t")
        assert _run(t.validate_config()) is False

    @patch("owlmind.integrations.issue_trackers.trello.urllib.request.urlopen")
    def test_trello_validate_network_error(self, mock_urlopen_fn: MagicMock) -> None:
        mock_urlopen_fn.side_effect = urllib.error.URLError("DNS failure")
        t = TrelloTracker(api_key="k", token="t")
        assert _run(t.validate_config()) is False

    @patch("owlmind.integrations.issue_trackers.jira.urllib.request.urlopen")
    def test_jira_unicode_description(self, mock_urlopen_fn: MagicMock) -> None:
        mock_urlopen_fn.return_value = _mock_urlopen({"id": "1", "key": "U-1"})
        t = JiraTracker(base_url="https://jira.test", email="e", api_token="t")
        result = _run(
            t.create_issue(
                {
                    "project": "U",
                    "summary": "Юникод тест",
                    "description": "Описание на русском языке 🎉",
                }
            )
        )
        assert result.ok is True
        # Verify Unicode is preserved in request body
        call_args = mock_urlopen_fn.call_args
        req = call_args[0][0]
        body = json.loads(req.data.decode())
        desc_text = body["fields"]["description"]["content"][0]["content"][0]["text"]
        assert "русском" in desc_text

    @patch("owlmind.integrations.issue_trackers.trello.urllib.request.urlopen")
    def test_trello_unicode_name(self, mock_urlopen_fn: MagicMock) -> None:
        mock_urlopen_fn.return_value = _mock_urlopen(
            {"id": "c1", "shortLink": "u", "shortUrl": "https://trello.com/c/u"}
        )
        t = TrelloTracker(api_key="k", token="t")
        result = _run(t.create_issue({"list_id": "L", "name": "Задача на русском"}))
        assert result.ok is True
