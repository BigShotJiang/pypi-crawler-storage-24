"""Tests for owlmind up — one command operator pack."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

from typer.testing import CliRunner

from owlmind.cli import app

runner = CliRunner()


class TestUpCommand:
    def test_idempotent_run(self, tmp_path: Path) -> None:
        """owlmind up runs without error on fresh workspace."""
        result = runner.invoke(app, ["up", "--workspace", str(tmp_path)])
        # Should not crash
        assert result.exit_code == 0
        assert "OWLMIND" in result.output
        assert "Setup init" in result.output
        assert "Doctor fix" in result.output
        assert "Security scan" in result.output

    def test_second_run_idempotent(self, tmp_path: Path) -> None:
        """Running up twice is safe."""
        runner.invoke(app, ["up", "--workspace", str(tmp_path)])
        result = runner.invoke(app, ["up", "--workspace", str(tmp_path)])
        assert result.exit_code == 0

    def test_shows_next_steps(self, tmp_path: Path) -> None:
        """owlmind up shows recommended next commands."""
        result = runner.invoke(app, ["up", "--workspace", str(tmp_path)])
        assert "session start" in result.output
        assert "monitor digest" in result.output
        assert "goals templates" in result.output

    def test_no_token_leak(self, tmp_path: Path) -> None:
        """owlmind up never prints token values."""
        env = {"TELEGRAM_BOT_TOKEN": "secret123:ABCDEF", "OPENAI_API_KEY": "sk-secret"}
        with patch.dict("os.environ", env, clear=False):
            result = runner.invoke(app, ["up", "--workspace", str(tmp_path)])
        assert "secret123" not in result.output
        assert "sk-secret" not in result.output

    def test_telegram_flag_without_token(self, tmp_path: Path) -> None:
        """--telegram flag without token shows warning."""
        env = {"TELEGRAM_BOT_TOKEN": ""}
        with patch.dict("os.environ", env):
            result = runner.invoke(app, ["up", "--workspace", str(tmp_path), "--telegram"])
        assert "TELEGRAM_BOT_TOKEN not set" in result.output

    def test_failure_messaging(self, tmp_path: Path) -> None:
        """If setup fails, it suggests a fix command."""
        with patch("owlmind.setup.setup_init", side_effect=RuntimeError("boom")):
            result = runner.invoke(app, ["up", "--workspace", str(tmp_path)])
        assert "Setup init failed" in result.output
        assert "owlmind setup init" in result.output
