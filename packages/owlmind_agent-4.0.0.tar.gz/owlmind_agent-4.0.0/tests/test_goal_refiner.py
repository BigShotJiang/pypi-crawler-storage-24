"""Tests for FS55 — Goal Refiner."""

from __future__ import annotations

from owlmind.agent.goal_refiner import RefinedGoal, refine_goal

# ---------------------------------------------------------------------------
# RefinedGoal dataclass tests
# ---------------------------------------------------------------------------


def test_refined_goal_is_high_risk() -> None:
    rg = RefinedGoal(original="do X", refined="do X", risk_level="high")
    assert rg.is_high_risk is True


def test_refined_goal_not_high_risk_for_low() -> None:
    rg = RefinedGoal(original="do X", refined="do X", risk_level="low")
    assert rg.is_high_risk is False


def test_refined_goal_changed_when_different() -> None:
    rg = RefinedGoal(
        original="fix bug", refined="Fix the login bug in UserService", risk_level="low"
    )
    assert rg.changed is True


def test_refined_goal_not_changed_when_same() -> None:
    rg = RefinedGoal(original="fix bug", refined="fix bug", risk_level="low")
    assert rg.changed is False


# ---------------------------------------------------------------------------
# refine_goal() with no LLM driver
# ---------------------------------------------------------------------------


def test_refine_goal_no_driver_returns_passthrough() -> None:
    """refine_goal() with no driver returns RefinedGoal with original as refined."""
    result = refine_goal("Add tests", llm_driver=None)
    assert result.original == "Add tests"
    assert result.refined == "Add tests"
    assert result.risk_level == "unknown"
    assert result.warnings == []


def test_refine_goal_empty_goal() -> None:
    """refine_goal() with empty goal returns passthrough without calling LLM."""
    result = refine_goal("", llm_driver=None)
    assert result.refined == ""
    assert result.risk_level == "unknown"


# ---------------------------------------------------------------------------
# refine_goal() with mock LLM driver
# ---------------------------------------------------------------------------


def test_refine_goal_with_mock_llm_low_risk() -> None:
    """refine_goal() uses LLM response when driver is available."""
    mock_response = {
        "refined": "Add comprehensive unit tests for the UserAuthService",
        "risk_level": "low",
        "warnings": [],
    }
    mock_driver = _make_mock_driver(mock_response)

    result = refine_goal("Add tests", llm_driver=mock_driver)
    assert result.refined == "Add comprehensive unit tests for the UserAuthService"
    assert result.risk_level == "low"
    assert result.warnings == []
    assert result.changed is True


def test_refine_goal_with_mock_llm_high_risk() -> None:
    """refine_goal() preserves high risk_level from LLM."""
    mock_response = {
        "refined": "Delete all migration files and recreate the database",
        "risk_level": "high",
        "warnings": ["Irreversible operation", "Data loss possible"],
    }
    mock_driver = _make_mock_driver(mock_response)

    result = refine_goal("Clean up the database", llm_driver=mock_driver)
    assert result.risk_level == "high"
    assert len(result.warnings) == 2
    assert result.is_high_risk is True


def test_refine_goal_graceful_on_llm_failure() -> None:
    """refine_goal() returns passthrough if LLM call raises an exception."""

    class _FailDriver:
        def plan(self, *args, **kwargs):
            msg = "LLM unavailable"
            raise RuntimeError(msg)

    result = refine_goal("Fix bug", llm_driver=_FailDriver())
    assert result.refined == "Fix bug"
    assert result.risk_level == "unknown"


def test_refine_goal_invalid_risk_level_normalized() -> None:
    """refine_goal() normalizes invalid risk_level to 'unknown'."""
    mock_response = {
        "refined": "Do something",
        "risk_level": "extreme",  # invalid value
        "warnings": [],
    }
    mock_driver = _make_mock_driver(mock_response)
    result = refine_goal("Do something", llm_driver=mock_driver)
    assert result.risk_level == "unknown"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_mock_driver(response_dict: dict) -> object:
    """Create a mock LLM driver that returns a fixed response."""

    class _MockDriver:
        def plan(self, payload, schema):
            return response_dict, {"provider": "mock", "latency_ms": 0}

    return _MockDriver()
