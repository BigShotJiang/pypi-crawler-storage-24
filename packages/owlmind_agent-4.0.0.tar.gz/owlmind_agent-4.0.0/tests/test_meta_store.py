"""Tests for CycleMetaStore — cycle metadata I/O."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from owlmind.agent.meta_store import CycleMetaStore
from owlmind.agent.schemas import CycleRunMeta, CycleState
from owlmind.evidence import EvidenceStore


def _make_store(tmp_path: Path) -> CycleMetaStore:
    evidence = EvidenceStore(tmp_path / "runs")
    return CycleMetaStore(evidence)


def _create_run(store: CycleMetaStore, run_id: str, goal: str = "Test") -> CycleRunMeta:
    """Create a run directory and save initial meta."""
    store.evidence.create_run(run_id)
    run_dir = store.run_dir(run_id)
    (run_dir / "outbox").mkdir(exist_ok=True)
    (run_dir / "inbox").mkdir(exist_ok=True)
    meta = CycleRunMeta(run_id=run_id, goal=goal)
    store.save(meta)
    return meta


class TestRunDir:
    def test_returns_path(self, tmp_path: Path) -> None:
        store = _make_store(tmp_path)
        path = store.run_dir("cycle-abc123")
        assert path == tmp_path / "runs" / "cycle-abc123"

    def test_is_path_instance(self, tmp_path: Path) -> None:
        store = _make_store(tmp_path)
        assert isinstance(store.run_dir("x"), Path)


class TestLoadSave:
    def test_roundtrip(self, tmp_path: Path) -> None:
        store = _make_store(tmp_path)
        _create_run(store, "cycle-test-001", goal="Hello")

        loaded = store.load("cycle-test-001")
        assert loaded.run_id == "cycle-test-001"
        assert loaded.goal == "Hello"
        assert loaded.state == CycleState.STARTED_WAIT_PLANNER

    def test_save_updates_timestamp(self, tmp_path: Path) -> None:
        store = _make_store(tmp_path)
        meta = _create_run(store, "cycle-ts-test")
        old_updated = meta.updated_at

        # Modify and save again
        meta.state = CycleState.WAIT_WORKER
        store.save(meta)

        loaded = store.load("cycle-ts-test")
        assert loaded.state == CycleState.WAIT_WORKER
        assert loaded.updated_at >= old_updated

    def test_load_nonexistent_raises(self, tmp_path: Path) -> None:
        store = _make_store(tmp_path)
        with pytest.raises(FileNotFoundError):
            store.load("nonexistent-run")

    def test_save_preserves_extra(self, tmp_path: Path) -> None:
        store = _make_store(tmp_path)
        meta = _create_run(store, "cycle-extra")
        meta.extra["custom_key"] = "custom_value"
        store.save(meta)

        loaded = store.load("cycle-extra")
        assert loaded.extra["custom_key"] == "custom_value"


class TestInboxOutbox:
    def test_ensure_inbox_dir(self, tmp_path: Path) -> None:
        store = _make_store(tmp_path)
        _create_run(store, "cycle-inbox")
        inbox = store.ensure_inbox_dir("cycle-inbox")
        assert inbox.is_dir()
        assert inbox == store.run_dir("cycle-inbox") / "inbox"

    def test_inbox_file_exists_false(self, tmp_path: Path) -> None:
        store = _make_store(tmp_path)
        _create_run(store, "cycle-check")
        assert not store.inbox_file_exists("cycle-check", "planner_response.json")

    def test_inbox_file_exists_true(self, tmp_path: Path) -> None:
        store = _make_store(tmp_path)
        _create_run(store, "cycle-check2")
        inbox = store.ensure_inbox_dir("cycle-check2")
        (inbox / "planner_response.json").write_text("{}")
        assert store.inbox_file_exists("cycle-check2", "planner_response.json")

    def test_write_outbox(self, tmp_path: Path) -> None:
        store = _make_store(tmp_path)
        _create_run(store, "cycle-outbox")
        path = store.write_outbox("cycle-outbox", "planner_prompt.md", "# Prompt")
        assert path.exists()
        assert path.read_text() == "# Prompt"

    def test_read_inbox(self, tmp_path: Path) -> None:
        store = _make_store(tmp_path)
        _create_run(store, "cycle-read")
        inbox = store.ensure_inbox_dir("cycle-read")
        (inbox / "test.json").write_text('{"key": "value"}')
        content = store.read_inbox("cycle-read", "test.json")
        assert json.loads(content) == {"key": "value"}

    def test_read_inbox_missing_raises(self, tmp_path: Path) -> None:
        store = _make_store(tmp_path)
        _create_run(store, "cycle-missing")
        with pytest.raises(FileNotFoundError, match="Inbox file not found"):
            store.read_inbox("cycle-missing", "nonexistent.json")

    def test_read_inbox_file_override(self, tmp_path: Path) -> None:
        store = _make_store(tmp_path)
        _create_run(store, "cycle-override")
        override = tmp_path / "custom.json"
        override.write_text('{"custom": true}')
        content = store.read_inbox("cycle-override", "test.json", file_override=override)
        assert json.loads(content) == {"custom": True}


class TestEvidenceStoreListRuns:
    """evidence.py:289 — list_runs returns [] when base_dir does not exist."""

    def test_list_runs_missing_base_dir(self, tmp_path: Path) -> None:
        import shutil

        store = EvidenceStore(tmp_path / "runs2")
        # Remove the directory that __init__ created, so base_dir.exists() is False
        shutil.rmtree(tmp_path / "runs2")
        result = store.list_runs()
        assert result == []


class TestHasNpmScript:
    """profile.py:27, 32-33 — _has_npm_script edge cases."""

    def test_returns_false_when_package_json_missing(self, tmp_path: Path) -> None:
        from owlmind.agent.profile import _has_npm_script

        assert _has_npm_script(tmp_path, "test") is False

    def test_returns_false_on_invalid_json(self, tmp_path: Path) -> None:
        from owlmind.agent.profile import _has_npm_script

        (tmp_path / "package.json").write_text("INVALID {{{")
        assert _has_npm_script(tmp_path, "test") is False
