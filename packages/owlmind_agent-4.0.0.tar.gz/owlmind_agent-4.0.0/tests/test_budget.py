"""Tests for Budget Governor — enforces token/cost limits."""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path

from owlmind.budget import BudgetDecision, BudgetGovernor
from owlmind.config import BudgetConfig, PricingConfig
from owlmind.ledger import UsageEntry, UsageLedger


def _make_entry(
    run_id: str = "cycle-test",
    **overrides: object,
) -> UsageEntry:
    defaults = {
        "ts": datetime.now(tz=UTC).isoformat(),
        "run_id": run_id,
        "stage": "planner",
        "provider": "openai",
        "model": "gpt-4o",
        "input_tokens": 1000,
        "output_tokens": 500,
        "total_tokens": 1500,
        "estimated_usd": 0.0075,
        "latency_ms": 500,
        "price_per_1k_input": 0.0025,
        "price_per_1k_output": 0.01,
    }
    defaults.update(overrides)
    return UsageEntry(**defaults)  # type: ignore[arg-type]


def _make_governor(
    tmp_path: Path,
    *,
    max_tokens_per_run: int = 200_000,
    max_tokens_per_day: int = 500_000,
    max_usd_per_day: float = 10.0,
    max_llm_calls_per_hour: int = 20,
) -> tuple[BudgetGovernor, UsageLedger]:
    budget = BudgetConfig(
        max_tokens_per_run=max_tokens_per_run,
        max_tokens_per_day=max_tokens_per_day,
        max_usd_per_day=max_usd_per_day,
        max_llm_calls_per_hour=max_llm_calls_per_hour,
    )
    pricing = PricingConfig()
    ledger = UsageLedger(tmp_path / "ledger")
    return BudgetGovernor(budget, pricing, ledger), ledger


class TestBudgetDecision:
    def test_to_dict(self) -> None:
        d = BudgetDecision(
            allowed=True,
            reason="OK",
            remaining_tokens_today=1000,
            remaining_usd_today=5.0,
            remaining_tokens_run=500,
        )
        result = d.to_dict()
        assert result["allowed"] is True
        assert result["remaining_tokens_today"] == 1000


class TestBudgetGovernorAllowed:
    def test_allows_when_empty(self, tmp_path: Path) -> None:
        gov, _ = _make_governor(tmp_path)
        decision = gov.check("cycle-new")
        assert decision.allowed is True
        assert decision.reason == "Budget OK"

    def test_allows_under_limits(self, tmp_path: Path) -> None:
        gov, ledger = _make_governor(tmp_path, max_tokens_per_run=10000)
        ledger.record(_make_entry(total_tokens=1000))
        decision = gov.check("cycle-test")
        assert decision.allowed is True


class TestBudgetGovernorBlocked:
    def test_blocks_run_token_limit(self, tmp_path: Path) -> None:
        gov, ledger = _make_governor(tmp_path, max_tokens_per_run=2000)
        ledger.record(_make_entry(run_id="cycle-big", total_tokens=2500))
        decision = gov.check("cycle-big")
        assert decision.allowed is False
        assert "Run token limit" in decision.reason
        assert decision.remaining_tokens_run == 0

    def test_blocks_daily_token_limit(self, tmp_path: Path) -> None:
        gov, ledger = _make_governor(tmp_path, max_tokens_per_day=3000)
        ledger.record(_make_entry(run_id="run-1", total_tokens=2000))
        ledger.record(_make_entry(run_id="run-2", total_tokens=1500))
        decision = gov.check("run-3")
        assert decision.allowed is False
        assert "Daily token limit" in decision.reason

    def test_blocks_daily_usd_limit(self, tmp_path: Path) -> None:
        gov, ledger = _make_governor(tmp_path, max_usd_per_day=0.01)
        ledger.record(_make_entry(estimated_usd=0.012))
        decision = gov.check("cycle-test")
        assert decision.allowed is False
        assert "Daily USD limit" in decision.reason

    def test_blocks_hourly_calls_limit(self, tmp_path: Path) -> None:
        gov, ledger = _make_governor(tmp_path, max_llm_calls_per_hour=3)
        for i in range(4):
            ledger.record(_make_entry(run_id=f"run-{i}"))
        decision = gov.check("run-new")
        assert decision.allowed is False
        assert "Hourly call limit" in decision.reason


class TestBudgetGovernorEstimateCost:
    def test_estimate_cost(self, tmp_path: Path) -> None:
        gov, _ = _make_governor(tmp_path)
        cost = gov.estimate_cost(input_tokens=1000, output_tokens=500)
        # 1000/1000 * 0.0025 + 500/1000 * 0.01 = 0.0025 + 0.005 = 0.0075
        assert abs(cost - 0.0075) < 0.0001

    def test_estimate_cost_zero(self, tmp_path: Path) -> None:
        gov, _ = _make_governor(tmp_path)
        assert gov.estimate_cost(0, 0) == 0.0


class TestBudgetGovernorRemaining:
    def test_remaining_values(self, tmp_path: Path) -> None:
        gov, ledger = _make_governor(
            tmp_path,
            max_tokens_per_run=10000,
            max_tokens_per_day=50000,
            max_usd_per_day=5.0,
        )
        ledger.record(
            _make_entry(
                run_id="cycle-r1",
                total_tokens=3000,
                estimated_usd=0.50,
            )
        )
        decision = gov.check("cycle-r1")
        assert decision.allowed is True
        assert decision.remaining_tokens_run == 7000
        assert decision.remaining_tokens_today == 47000
        assert abs(decision.remaining_usd_today - 4.50) < 0.01
