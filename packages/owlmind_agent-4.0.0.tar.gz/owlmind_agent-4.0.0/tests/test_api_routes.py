"""Tests for the OWLMIND REST API routes.

Uses starlette.testclient.TestClient for synchronous testing
of the FastAPI application.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from unittest.mock import patch

import pytest
from starlette.testclient import TestClient

from owlmind.api.app import create_app

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def tmp_workspace(tmp_path: Path) -> dict[str, Path]:
    """Create a minimal workspace with runs/ledger/queue/policies dirs."""
    runs = tmp_path / "runs"
    runs.mkdir()
    ledger = tmp_path / "ledger"
    ledger.mkdir()
    queue = tmp_path / "queue"
    queue.mkdir()
    policies = tmp_path / "policies"
    policies.mkdir()
    sessions = tmp_path / "sessions"
    sessions.mkdir()
    return {
        "runs": runs,
        "ledger": ledger,
        "queue": queue,
        "policies": policies,
        "sessions": sessions,
    }


@pytest.fixture()
def app(tmp_workspace: dict[str, Path]) -> TestClient:
    """Create a test client with no API key requirement (dev mode)."""
    fastapi_app = create_app(
        runs_dir=tmp_workspace["runs"],
        ledger_dir=tmp_workspace["ledger"],
        queue_path=tmp_workspace["queue"],
        policies_dir=tmp_workspace["policies"],
    )
    return TestClient(fastapi_app)


@pytest.fixture()
def app_with_key(tmp_workspace: dict[str, Path]) -> TestClient:
    """Create a test client with API key auth enabled."""
    with patch.dict(os.environ, {"OWLMIND_API_KEY": "test-secret-key"}):
        fastapi_app = create_app(
            runs_dir=tmp_workspace["runs"],
            ledger_dir=tmp_workspace["ledger"],
            queue_path=tmp_workspace["queue"],
            policies_dir=tmp_workspace["policies"],
        )
        yield TestClient(fastapi_app)


def _create_run_dir(runs_dir: Path, run_id: str, meta: dict) -> Path:
    """Helper: create a fake run directory with cycle_meta.json."""
    run_path = runs_dir / run_id
    run_path.mkdir(parents=True, exist_ok=True)
    (run_path / "cycle_meta.json").write_text(json.dumps(meta, indent=2))
    return run_path


def _create_session_dir(sessions_dir: Path, session_id: str, meta: dict) -> Path:
    """Helper: create a fake session directory with session_meta.json."""
    session_path = sessions_dir / session_id
    session_path.mkdir(parents=True, exist_ok=True)
    (session_path / "session_meta.json").write_text(json.dumps(meta, indent=2))
    return session_path


def _create_ledger(ledger_dir: Path, entries: list[dict]) -> None:
    """Helper: write usage entries to usage.jsonl."""
    lines = [json.dumps(e) for e in entries]
    (ledger_dir / "usage.jsonl").write_text("\n".join(lines) + "\n")


# ===========================================================================
# Health endpoints
# ===========================================================================


class TestHealthEndpoints:
    """Tests for /health and /doctor endpoints."""

    def test_health_returns_ok(self, app: TestClient) -> None:
        resp = app.get("/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok"
        assert "version" in data

    def test_health_no_auth_required(self, app_with_key: TestClient) -> None:
        """Health endpoint should work without API key even when auth is configured."""
        resp = app_with_key.get("/health")
        assert resp.status_code == 200
        assert resp.json()["status"] == "ok"

    def test_doctor_returns_checks(self, app: TestClient) -> None:
        resp = app.get("/doctor")
        assert resp.status_code == 200
        data = resp.json()
        assert "checks" in data
        assert isinstance(data["checks"], list)
        assert len(data["checks"]) > 0
        assert "version" in data
        assert "python" in data

    def test_doctor_check_structure(self, app: TestClient) -> None:
        resp = app.get("/doctor")
        data = resp.json()
        for check in data["checks"]:
            assert "name" in check
            assert "ok" in check
            assert "detail" in check


# ===========================================================================
# Runs endpoints
# ===========================================================================


class TestRunsEndpoints:
    """Tests for /api/v1/runs endpoints."""

    def test_list_runs_empty(self, app: TestClient) -> None:
        resp = app.get("/api/v1/runs")
        assert resp.status_code == 200
        assert resp.json() == []

    def test_list_runs_with_data(
        self,
        app: TestClient,
        tmp_workspace: dict[str, Path],
    ) -> None:
        _create_run_dir(
            tmp_workspace["runs"],
            "cycle-abc123",
            {
                "run_id": "cycle-abc123",
                "state": "DONE",
                "goal": "Fix the bug",
                "iteration": 5,
                "created_at": "2025-01-01T00:00:00",
                "updated_at": "2025-01-01T01:00:00",
            },
        )
        _create_run_dir(
            tmp_workspace["runs"],
            "cycle-def456",
            {
                "run_id": "cycle-def456",
                "state": "RUNNING",
                "goal": "Add feature",
                "iteration": 2,
                "created_at": "2025-01-02T00:00:00",
                "updated_at": "2025-01-02T00:30:00",
            },
        )

        resp = app.get("/api/v1/runs")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 2
        run_ids = {r["run_id"] for r in data}
        assert "cycle-abc123" in run_ids
        assert "cycle-def456" in run_ids

    def test_get_run_found(
        self,
        app: TestClient,
        tmp_workspace: dict[str, Path],
    ) -> None:
        _create_run_dir(
            tmp_workspace["runs"],
            "cycle-found01",
            {
                "run_id": "cycle-found01",
                "state": "DONE",
                "goal": "Test goal",
                "workspace": "/tmp/ws",
                "iteration": 3,
                "max_steps": 200,
                "created_at": "2025-01-01T00:00:00",
                "updated_at": "2025-01-01T01:00:00",
            },
        )

        resp = app.get("/api/v1/runs/cycle-found01")
        assert resp.status_code == 200
        data = resp.json()
        assert data["run_id"] == "cycle-found01"
        assert data["state"] == "DONE"
        assert data["goal"] == "Test goal"
        assert data["workspace"] == "/tmp/ws"
        assert data["meta"]["run_id"] == "cycle-found01"

    def test_get_run_not_found(self, app: TestClient) -> None:
        resp = app.get("/api/v1/runs/nonexistent-run")
        assert resp.status_code == 404
        assert "not found" in resp.json()["detail"].lower()

    def test_cancel_run(
        self,
        app: TestClient,
        tmp_workspace: dict[str, Path],
    ) -> None:
        _create_run_dir(
            tmp_workspace["runs"],
            "cycle-cancel01",
            {
                "run_id": "cycle-cancel01",
                "state": "RUNNING",
                "goal": "Cancel me",
            },
        )

        resp = app.post("/api/v1/runs/cycle-cancel01/cancel")
        assert resp.status_code == 200
        data = resp.json()
        assert data["state"] == "CANCELLED"

        # Verify file was updated
        meta_path = tmp_workspace["runs"] / "cycle-cancel01" / "cycle_meta.json"
        saved = json.loads(meta_path.read_text())
        assert saved["state"] == "CANCELLED"

    def test_cancel_run_not_found(self, app: TestClient) -> None:
        resp = app.post("/api/v1/runs/nonexistent/cancel")
        assert resp.status_code == 404

    def test_list_runs_ignores_non_dirs(
        self,
        app: TestClient,
        tmp_workspace: dict[str, Path],
    ) -> None:
        """Files in runs_dir (not directories) should be skipped."""
        (tmp_workspace["runs"] / "stray_file.txt").write_text("not a run")
        _create_run_dir(
            tmp_workspace["runs"],
            "cycle-real01",
            {
                "run_id": "cycle-real01",
                "state": "DONE",
                "goal": "Real run",
            },
        )

        resp = app.get("/api/v1/runs")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 1
        assert data[0]["run_id"] == "cycle-real01"

    def test_list_runs_ignores_broken_meta(
        self,
        app: TestClient,
        tmp_workspace: dict[str, Path],
    ) -> None:
        """Directories with invalid JSON in cycle_meta.json should be skipped."""
        bad_dir = tmp_workspace["runs"] / "cycle-bad01"
        bad_dir.mkdir()
        (bad_dir / "cycle_meta.json").write_text("{invalid json!!!")

        resp = app.get("/api/v1/runs")
        assert resp.status_code == 200
        assert resp.json() == []


# ===========================================================================
# Sessions endpoints
# ===========================================================================


class TestSessionsEndpoints:
    """Tests for /api/v1/sessions endpoints."""

    def test_list_sessions_empty(self, app: TestClient) -> None:
        resp = app.get("/api/v1/sessions")
        assert resp.status_code == 200
        assert resp.json() == []

    def test_list_sessions_with_data(
        self,
        app: TestClient,
        tmp_workspace: dict[str, Path],
    ) -> None:
        _create_session_dir(
            tmp_workspace["sessions"],
            "session-aaa111",
            {
                "session_id": "session-aaa111",
                "status": "DONE",
                "created_at": "2025-01-01T00:00:00",
                "updated_at": "2025-01-01T02:00:00",
                "goals": [{"id": "G1", "goal": "First"}, {"id": "G2", "goal": "Second"}],
            },
        )

        resp = app.get("/api/v1/sessions")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 1
        assert data[0]["session_id"] == "session-aaa111"
        assert data[0]["status"] == "DONE"
        assert data[0]["goals_count"] == 2

    def test_get_session_found(
        self,
        app: TestClient,
        tmp_workspace: dict[str, Path],
    ) -> None:
        _create_session_dir(
            tmp_workspace["sessions"],
            "session-bbb222",
            {
                "session_id": "session-bbb222",
                "status": "RUNNING",
                "created_at": "2025-01-05T00:00:00",
                "updated_at": "2025-01-05T00:30:00",
                "current_goal_index": 1,
                "goals": [{"id": "G1", "goal": "Do X"}],
                "runs": [{"goal_id": "G1", "run_id": "cycle-xxx", "status": "running"}],
                "last_block_reason": "",
                "config": {"workspace": "/tmp"},
                "max_concurrency": 2,
                "continue_on_fail": True,
            },
        )

        resp = app.get("/api/v1/sessions/session-bbb222")
        assert resp.status_code == 200
        data = resp.json()
        assert data["session_id"] == "session-bbb222"
        assert data["status"] == "RUNNING"
        assert data["max_concurrency"] == 2
        assert data["continue_on_fail"] is True
        assert len(data["goals"]) == 1
        assert len(data["runs"]) == 1

    def test_get_session_not_found(self, app: TestClient) -> None:
        resp = app.get("/api/v1/sessions/nonexistent-session")
        assert resp.status_code == 404
        assert "not found" in resp.json()["detail"].lower()


# ===========================================================================
# Analytics endpoints
# ===========================================================================


class TestAnalyticsEndpoints:
    """Tests for /api/v1/analytics endpoints."""

    def test_cost_daily_empty(self, app: TestClient) -> None:
        resp = app.get("/api/v1/analytics/cost/daily")
        assert resp.status_code == 200
        data = resp.json()
        assert data["total_tokens"] == 0
        assert data["total_usd"] == 0.0

    def test_cost_daily_with_date(
        self,
        app: TestClient,
        tmp_workspace: dict[str, Path],
    ) -> None:
        _create_ledger(
            tmp_workspace["ledger"],
            [
                {
                    "ts": "2025-06-15T10:00:00",
                    "run_id": "cycle-x",
                    "stage": "planner",
                    "provider": "openai",
                    "model": "gpt-4o",
                    "input_tokens": 1000,
                    "output_tokens": 500,
                    "total_tokens": 1500,
                    "estimated_usd": 0.05,
                    "latency_ms": 200,
                    "price_per_1k_input": 0.0025,
                    "price_per_1k_output": 0.01,
                },
            ],
        )

        resp = app.get("/api/v1/analytics/cost/daily?date=2025-06-15")
        assert resp.status_code == 200
        data = resp.json()
        assert data["date"] == "2025-06-15"
        assert data["total_tokens"] == 1500
        assert data["total_usd"] == 0.05

    def test_cost_weekly(self, app: TestClient) -> None:
        resp = app.get("/api/v1/analytics/cost/weekly")
        assert resp.status_code == 200
        data = resp.json()
        assert "period" in data
        assert "days" in data
        assert "totals" in data
        assert len(data["days"]) == 7

    def test_cost_monthly(self, app: TestClient) -> None:
        resp = app.get("/api/v1/analytics/cost/monthly")
        assert resp.status_code == 200
        data = resp.json()
        assert "period" in data
        assert "total_tokens" in data
        assert "total_usd" in data

    def test_cost_breakdown_empty(self, app: TestClient) -> None:
        resp = app.get("/api/v1/analytics/cost/breakdown")
        assert resp.status_code == 200
        assert resp.json() == []

    def test_cost_breakdown_with_data(
        self,
        app: TestClient,
        tmp_workspace: dict[str, Path],
    ) -> None:
        _create_ledger(
            tmp_workspace["ledger"],
            [
                {
                    "ts": "2025-06-15T10:00:00",
                    "run_id": "cycle-x",
                    "stage": "planner",
                    "provider": "openai",
                    "model": "gpt-4o",
                    "input_tokens": 1000,
                    "output_tokens": 500,
                    "total_tokens": 1500,
                    "estimated_usd": 0.05,
                    "latency_ms": 200,
                    "price_per_1k_input": 0.0025,
                    "price_per_1k_output": 0.01,
                },
                {
                    "ts": "2025-06-15T11:00:00",
                    "run_id": "cycle-y",
                    "stage": "judge",
                    "provider": "anthropic",
                    "model": "claude-sonnet",
                    "input_tokens": 800,
                    "output_tokens": 400,
                    "total_tokens": 1200,
                    "estimated_usd": 0.03,
                    "latency_ms": 150,
                    "price_per_1k_input": 0.003,
                    "price_per_1k_output": 0.015,
                },
            ],
        )

        resp = app.get("/api/v1/analytics/cost/breakdown")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 2
        providers = {d["provider"] for d in data}
        assert "openai" in providers
        assert "anthropic" in providers


# ===========================================================================
# Auth tests
# ===========================================================================


class TestAuth:
    """Tests for API key authentication."""

    def test_no_key_dev_mode_allows_all(self, app: TestClient) -> None:
        """When OWLMIND_API_KEY is not set, all requests are allowed."""
        resp = app.get("/api/v1/runs")
        assert resp.status_code == 200

    def test_with_valid_key(self, app_with_key: TestClient) -> None:
        resp = app_with_key.get(
            "/api/v1/runs",
            headers={"X-API-Key": "test-secret-key"},
        )
        assert resp.status_code == 200

    def test_with_wrong_key(self, app_with_key: TestClient) -> None:
        resp = app_with_key.get(
            "/api/v1/runs",
            headers={"X-API-Key": "wrong-key"},
        )
        assert resp.status_code == 403

    def test_missing_key_when_required(self, app_with_key: TestClient) -> None:
        resp = app_with_key.get("/api/v1/runs")
        assert resp.status_code == 403

    def test_auth_not_required_for_health(self, app_with_key: TestClient) -> None:
        """Health endpoint should work without API key."""
        resp = app_with_key.get("/health")
        assert resp.status_code == 200

    def test_auth_required_for_doctor(self, app_with_key: TestClient) -> None:
        """Doctor endpoint should require API key when configured."""
        resp = app_with_key.get("/doctor")
        assert resp.status_code == 403

    def test_auth_required_for_sessions(self, app_with_key: TestClient) -> None:
        resp = app_with_key.get("/api/v1/sessions")
        assert resp.status_code == 403

    def test_auth_required_for_analytics(self, app_with_key: TestClient) -> None:
        resp = app_with_key.get("/api/v1/analytics/cost/daily")
        assert resp.status_code == 403


# ===========================================================================
# CORS
# ===========================================================================


class TestCORS:
    """Test CORS middleware configuration."""

    def test_cors_headers_present(self, app: TestClient) -> None:
        resp = app.options(
            "/health",
            headers={
                "Origin": "http://localhost:3000",
                "Access-Control-Request-Method": "GET",
            },
        )
        assert resp.status_code == 200
        assert "access-control-allow-origin" in resp.headers


# ===========================================================================
# Analytics exception handlers
# ===========================================================================


class TestAnalyticsExceptionHandlers:
    """Tests for 500 exception paths in analytics routes."""

    def test_cost_daily_exception_returns_500(self, app: TestClient) -> None:
        """daily_report raising → 500 with detail message."""
        with patch("owlmind.reports.daily_report", side_effect=RuntimeError("DB error")):
            resp = app.get("/api/v1/analytics/cost/daily")
        assert resp.status_code == 500
        assert "Report generation failed" in resp.json()["detail"]

    def test_cost_weekly_exception_returns_500(self, app: TestClient) -> None:
        """weekly_report raising → 500 with detail message."""
        with patch("owlmind.reports.weekly_report", side_effect=RuntimeError("timeout")):
            resp = app.get("/api/v1/analytics/cost/weekly")
        assert resp.status_code == 500
        assert "Report generation failed" in resp.json()["detail"]

    def test_cost_monthly_exception_returns_500(self, app: TestClient) -> None:
        """monthly_report raising → 500 with detail message."""
        with patch("owlmind.reports.monthly_report", side_effect=RuntimeError("disk full")):
            resp = app.get("/api/v1/analytics/cost/monthly")
        assert resp.status_code == 500
        assert "Report generation failed" in resp.json()["detail"]

    def test_cost_breakdown_exception_returns_500(self, app: TestClient) -> None:
        """provider_breakdown raising → 500 with detail message."""
        with patch("owlmind.reports.provider_breakdown", side_effect=RuntimeError("OOM")):
            resp = app.get("/api/v1/analytics/cost/breakdown")
        assert resp.status_code == 500
        assert "Report generation failed" in resp.json()["detail"]


# ===========================================================================
# Runs create and cancel
# ===========================================================================


class TestRunsCreateAndCancel:
    """Tests for POST /api/v1/runs/ and POST /api/v1/runs/{id}/cancel."""

    def test_create_run_returns_201(
        self,
        app: TestClient,
        tmp_workspace: dict[str, Path],
    ) -> None:
        """POST /api/v1/runs/ → 201 with run_id and state."""
        from unittest.mock import MagicMock

        with (
            patch("owlmind.agent.cycle.CycleManager") as MockMgr,
            patch("owlmind.policy.PolicyEngine"),
            patch("owlmind.evidence.EvidenceStore"),
        ):
            mock_meta = MagicMock()
            mock_meta.run_id = "new-run-001"
            mock_meta.state = "STARTED_WAIT_PLANNER"
            MockMgr.return_value.start.return_value = mock_meta

            resp = app.post("/api/v1/runs", json={"goal": "test goal"})

        assert resp.status_code == 201
        data = resp.json()
        assert data["run_id"] == "new-run-001"
        assert data["goal"] == "test goal"

    def test_create_run_exception_returns_500(self, app: TestClient) -> None:
        """create_run raises → 500 with detail message."""
        with (
            patch("owlmind.agent.cycle.CycleManager", side_effect=RuntimeError("broker down")),
            patch("owlmind.policy.PolicyEngine"),
            patch("owlmind.evidence.EvidenceStore"),
        ):
            resp = app.post("/api/v1/runs", json={"goal": "test goal"})
        assert resp.status_code == 500
        assert "Failed to create run" in resp.json()["detail"]

    def test_cancel_run_updates_state(
        self,
        app: TestClient,
        tmp_workspace: dict[str, Path],
    ) -> None:
        """POST /api/v1/runs/{id}/cancel → 200, state CANCELLED, file updated."""
        _create_run_dir(
            tmp_workspace["runs"],
            "run-to-cancel",
            {
                "run_id": "run-to-cancel",
                "state": "RUNNING",
            },
        )

        resp = app.post("/api/v1/runs/run-to-cancel/cancel")
        assert resp.status_code == 200
        data = resp.json()
        assert data["state"] == "CANCELLED"

        saved = json.loads(
            (tmp_workspace["runs"] / "run-to-cancel" / "cycle_meta.json").read_text()
        )
        assert saved["state"] == "CANCELLED"

    def test_cancel_run_not_found_returns_404(self, app: TestClient) -> None:
        """POST /api/v1/runs/{id}/cancel for missing run → 404."""
        resp = app.post("/api/v1/runs/no-such-run/cancel")
        assert resp.status_code == 404
        assert "not found" in resp.json()["detail"].lower()
