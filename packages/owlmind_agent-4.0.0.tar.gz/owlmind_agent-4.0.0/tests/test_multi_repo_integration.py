"""Integration tests for MultiRepoRunner with real git repositories.

Uses tmp_path to create small git repos and tests dependency detection
and execution ordering.
"""

from __future__ import annotations

import subprocess
from pathlib import Path

import pytest

from owlmind.multi_repo import (
    MultiRepoConfig,
    MultiRepoRunner,
    RepoConfig,
    _find_python_packages,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _init_git_repo(path: Path) -> None:
    """Initialize a minimal git repository at *path*."""
    path.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        ["git", "init"],
        cwd=str(path),
        capture_output=True,
        check=True,
    )
    subprocess.run(
        ["git", "config", "user.email", "test@test.com"],
        cwd=str(path),
        capture_output=True,
        check=True,
    )
    subprocess.run(
        ["git", "config", "user.name", "Test"],
        cwd=str(path),
        capture_output=True,
        check=True,
    )
    # Create an initial commit so the repo is valid
    readme = path / "README.md"
    readme.write_text("# test repo\n")
    subprocess.run(
        ["git", "add", "."],
        cwd=str(path),
        capture_output=True,
        check=True,
    )
    subprocess.run(
        ["git", "commit", "-m", "initial"],
        cwd=str(path),
        capture_output=True,
        check=True,
    )


def _make_python_package(repo: Path, pkg_name: str) -> None:
    """Create a src/<pkg_name>/__init__.py package structure."""
    pkg_dir = repo / "src" / pkg_name
    pkg_dir.mkdir(parents=True, exist_ok=True)
    (pkg_dir / "__init__.py").write_text(f'"""Package {pkg_name}."""\n')


# ---------------------------------------------------------------------------
# Tests: _find_python_packages
# ---------------------------------------------------------------------------


class TestFindPythonPackages:
    def test_finds_src_package(self, tmp_path: Path) -> None:
        repo = tmp_path / "myrepo"
        _make_python_package(repo, "mylib")

        packages = _find_python_packages(repo)
        assert "mylib" in packages

    def test_finds_root_package(self, tmp_path: Path) -> None:
        repo = tmp_path / "myrepo"
        repo.mkdir(parents=True)
        pkg = repo / "rootpkg"
        pkg.mkdir()
        (pkg / "__init__.py").write_text("")

        packages = _find_python_packages(repo)
        assert "rootpkg" in packages

    def test_ignores_dotdirs(self, tmp_path: Path) -> None:
        repo = tmp_path / "myrepo"
        repo.mkdir(parents=True)
        hidden = repo / ".hidden"
        hidden.mkdir()
        (hidden / "__init__.py").write_text("")

        packages = _find_python_packages(repo)
        assert ".hidden" not in packages


# ---------------------------------------------------------------------------
# Tests: detect_dependencies
# ---------------------------------------------------------------------------


class TestDetectDependencies:
    def test_detects_python_import_dependency(self, tmp_path: Path) -> None:
        """Repo B imports a package that lives in Repo A."""
        repo_a = tmp_path / "repo_a"
        repo_b = tmp_path / "repo_b"

        # Repo A exposes package 'alpha'
        _init_git_repo(repo_a)
        _make_python_package(repo_a, "alpha")

        # Repo B imports 'alpha'
        _init_git_repo(repo_b)
        repo_b_src = repo_b / "src" / "beta"
        repo_b_src.mkdir(parents=True)
        (repo_b_src / "__init__.py").write_text("")
        (repo_b_src / "main.py").write_text("from alpha import core\n")

        config = MultiRepoConfig(
            repos=[
                RepoConfig(path=str(repo_a)),
                RepoConfig(path=str(repo_b)),
            ],
        )
        runner = MultiRepoRunner(
            config,
            sessions_dir=tmp_path / "sessions",
            runs_dir=tmp_path / "runs",
            policies_dir=tmp_path / "policies",
            ledger_dir=tmp_path / "ledger",
        )

        deps = runner.detect_dependencies([str(repo_a), str(repo_b)])

        # Repo B should depend on Repo A (because it imports alpha)
        assert str(repo_a) in deps[str(repo_b)]
        # Repo A should not depend on Repo B
        assert str(repo_b) not in deps[str(repo_a)]

    def test_no_dependency_for_stdlib_imports(self, tmp_path: Path) -> None:
        """Standard-library imports should not create cross-repo dependencies."""
        repo_a = tmp_path / "repo_a"
        repo_b = tmp_path / "repo_b"

        _init_git_repo(repo_a)
        _make_python_package(repo_a, "mypkg")

        _init_git_repo(repo_b)
        repo_b.mkdir(parents=True, exist_ok=True)
        (repo_b / "app.py").write_text("import os\nimport json\nimport sys\n")

        config = MultiRepoConfig(
            repos=[
                RepoConfig(path=str(repo_a)),
                RepoConfig(path=str(repo_b)),
            ],
        )
        runner = MultiRepoRunner(
            config,
            sessions_dir=tmp_path / "sessions",
            runs_dir=tmp_path / "runs",
            policies_dir=tmp_path / "policies",
            ledger_dir=tmp_path / "ledger",
        )

        deps = runner.detect_dependencies([str(repo_a), str(repo_b)])

        # Neither repo should depend on the other (stdlib imports only)
        assert deps[str(repo_a)] == []
        assert deps[str(repo_b)] == []

    def test_detects_node_dependency(self, tmp_path: Path) -> None:
        """Repo B depends on a package declared in Repo A's package.json."""
        repo_a = tmp_path / "repo_a"
        repo_b = tmp_path / "repo_b"

        _init_git_repo(repo_a)
        (repo_a / "package.json").write_text(
            '{"name": "@myorg/shared-lib", "version": "1.0.0"}'
        )

        _init_git_repo(repo_b)
        (repo_b / "package.json").write_text(
            '{"name": "@myorg/app", "dependencies": {"@myorg/shared-lib": "^1.0.0"}}'
        )

        config = MultiRepoConfig(
            repos=[
                RepoConfig(path=str(repo_a)),
                RepoConfig(path=str(repo_b)),
            ],
        )
        runner = MultiRepoRunner(
            config,
            sessions_dir=tmp_path / "sessions",
            runs_dir=tmp_path / "runs",
            policies_dir=tmp_path / "policies",
            ledger_dir=tmp_path / "ledger",
        )

        deps = runner.detect_dependencies([str(repo_a), str(repo_b)])

        assert str(repo_a) in deps[str(repo_b)]
        assert str(repo_b) not in deps[str(repo_a)]


# ---------------------------------------------------------------------------
# Tests: run() execution order (mocked session runner)
# ---------------------------------------------------------------------------


class TestMultiRepoRunOrder:
    def test_run_respects_dependency_order(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        """Repos should be executed in topological order (dependencies first)."""
        repo_a = tmp_path / "repo_a"
        repo_b = tmp_path / "repo_b"

        _init_git_repo(repo_a)
        _init_git_repo(repo_b)

        config = MultiRepoConfig(
            repos=[
                RepoConfig(path=str(repo_a), goals=["goal A"]),
                RepoConfig(path=str(repo_b), goals=["goal B"]),
            ],
            dependency_graph={
                str(repo_a): [],
                str(repo_b): [str(repo_a)],
            },
        )

        runner = MultiRepoRunner(
            config,
            sessions_dir=tmp_path / "sessions",
            runs_dir=tmp_path / "runs",
            policies_dir=tmp_path / "policies",
            ledger_dir=tmp_path / "ledger",
        )

        # Track execution order
        execution_order: list[str] = []

        def fake_run_repo_session(repo_cfg: RepoConfig) -> object:
            execution_order.append(repo_cfg.path)
            # Return a fake SessionResult with status "done"
            from owlmind.session import SESSION_DONE

            class FakeResult:
                status = SESSION_DONE
                last_block_reason = ""

            return FakeResult()

        monkeypatch.setattr(runner, "_run_repo_session", fake_run_repo_session)

        result = runner.run()

        # Repo A must come before Repo B
        assert execution_order.index(str(repo_a)) < execution_order.index(str(repo_b))
        assert str(repo_a) in result.repos_completed
        assert str(repo_b) in result.repos_completed
        assert result.repos_failed == []

    def test_run_skips_repo_when_dependency_fails(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """If Repo A fails, Repo B (which depends on A) should be skipped."""
        repo_a = tmp_path / "repo_a"
        repo_b = tmp_path / "repo_b"

        _init_git_repo(repo_a)
        _init_git_repo(repo_b)

        config = MultiRepoConfig(
            repos=[
                RepoConfig(path=str(repo_a), goals=["goal A"]),
                RepoConfig(path=str(repo_b), goals=["goal B"]),
            ],
            dependency_graph={
                str(repo_a): [],
                str(repo_b): [str(repo_a)],
            },
        )

        runner = MultiRepoRunner(
            config,
            sessions_dir=tmp_path / "sessions",
            runs_dir=tmp_path / "runs",
            policies_dir=tmp_path / "policies",
            ledger_dir=tmp_path / "ledger",
        )

        def fake_run_repo_session(repo_cfg: RepoConfig) -> object:
            if repo_cfg.path == str(repo_a):
                raise RuntimeError("Repo A session exploded")
            # Should never reach here for repo_b
            from owlmind.session import SESSION_DONE

            class FakeResult:
                status = SESSION_DONE
                last_block_reason = ""

            return FakeResult()

        monkeypatch.setattr(runner, "_run_repo_session", fake_run_repo_session)

        result = runner.run()

        assert str(repo_a) in result.repos_failed
        assert str(repo_b) in result.repos_failed
        assert len(result.errors) >= 2  # error for A's failure + B skipped

    def test_run_with_invalid_dag_returns_error(self, tmp_path: Path) -> None:
        """A cyclic dependency graph should produce an error result, not crash."""
        repo_a = tmp_path / "repo_a"
        repo_b = tmp_path / "repo_b"

        _init_git_repo(repo_a)
        _init_git_repo(repo_b)

        config = MultiRepoConfig(
            repos=[
                RepoConfig(path=str(repo_a), goals=["goal A"]),
                RepoConfig(path=str(repo_b), goals=["goal B"]),
            ],
            dependency_graph={
                str(repo_a): [str(repo_b)],
                str(repo_b): [str(repo_a)],
            },
        )

        runner = MultiRepoRunner(
            config,
            sessions_dir=tmp_path / "sessions",
            runs_dir=tmp_path / "runs",
            policies_dir=tmp_path / "policies",
            ledger_dir=tmp_path / "ledger",
        )

        result = runner.run()

        # Should return an error about the invalid graph, not raise
        assert len(result.errors) >= 1
        assert any("invalid" in e.lower() or "cycle" in e.lower() for e in result.errors)

    def test_run_independent_repos_both_complete(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Repos with no dependencies should all complete."""
        repo_a = tmp_path / "repo_a"
        repo_b = tmp_path / "repo_b"

        _init_git_repo(repo_a)
        _init_git_repo(repo_b)

        config = MultiRepoConfig(
            repos=[
                RepoConfig(path=str(repo_a), goals=["goal A"]),
                RepoConfig(path=str(repo_b), goals=["goal B"]),
            ],
            dependency_graph={
                str(repo_a): [],
                str(repo_b): [],
            },
        )

        runner = MultiRepoRunner(
            config,
            sessions_dir=tmp_path / "sessions",
            runs_dir=tmp_path / "runs",
            policies_dir=tmp_path / "policies",
            ledger_dir=tmp_path / "ledger",
        )

        def fake_run_repo_session(repo_cfg: RepoConfig) -> object:
            from owlmind.session import SESSION_DONE

            class FakeResult:
                status = SESSION_DONE
                last_block_reason = ""

            return FakeResult()

        monkeypatch.setattr(runner, "_run_repo_session", fake_run_repo_session)

        result = runner.run()

        assert str(repo_a) in result.repos_completed
        assert str(repo_b) in result.repos_completed
        assert result.repos_failed == []
