"""Tests for rollback controller — approval gating, events, execution."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from owlmind.rollback import (
    create_rollback_request,
    execute_rollback,
    log_rollback_event,
)


class TestCreateRollbackRequest:
    def test_mode_none(self) -> None:
        req = create_rollback_request("G1", "cycle-1", "none")
        assert req.mode == "none"
        assert req.approved is True
        assert req.require_approval is False

    def test_worktree_reset_requires_approval(self) -> None:
        req = create_rollback_request("G1", "cycle-1", "worktree_reset")
        assert req.mode == "worktree_reset"
        assert req.require_approval is True
        assert req.approved is False
        assert len(req.approval_token) == 16

    def test_branch_delete_requires_approval(self) -> None:
        req = create_rollback_request("G1", "cycle-1", "branch_delete")
        assert req.mode == "branch_delete"
        assert req.require_approval is True
        assert req.approved is False

    def test_manual_has_instructions(self) -> None:
        req = create_rollback_request("G1", "cycle-1", "manual")
        assert req.mode == "manual"
        assert "manually" in req.instructions.lower()

    def test_no_approval_when_overridden(self) -> None:
        req = create_rollback_request(
            "G1",
            "cycle-1",
            "worktree_reset",
            require_approval=False,
        )
        assert req.require_approval is False
        assert req.approved is True


class TestExecuteRollback:
    def test_none_skipped(self, tmp_path: Path) -> None:
        req = create_rollback_request("G1", "cycle-1", "none")
        result = execute_rollback(req, tmp_path / "runs")
        assert result["status"] == "skipped"

    def test_manual_returns_instructions(self, tmp_path: Path) -> None:
        req = create_rollback_request(
            "G1",
            "cycle-1",
            "manual",
            require_approval=False,
        )
        result = execute_rollback(req, tmp_path / "runs")
        assert result["status"] == "instructions_provided"
        assert "instructions" in result

    def test_worktree_reset_removes_dir(self, tmp_path: Path) -> None:
        runs_dir = tmp_path / "runs"
        worktree = runs_dir / "cycle-1" / "worktree"
        worktree.mkdir(parents=True)
        (worktree / "file.txt").write_text("test")

        req = create_rollback_request(
            "G1",
            "cycle-1",
            "worktree_reset",
            require_approval=False,
        )
        result = execute_rollback(req, runs_dir)
        assert result["status"] == "executed"
        assert not worktree.exists()

    def test_worktree_reset_no_dir(self, tmp_path: Path) -> None:
        runs_dir = tmp_path / "runs"
        (runs_dir / "cycle-1").mkdir(parents=True)

        req = create_rollback_request(
            "G1",
            "cycle-1",
            "worktree_reset",
            require_approval=False,
        )
        result = execute_rollback(req, runs_dir)
        assert result["status"] == "no_worktree"

    def test_branch_delete_records(self, tmp_path: Path) -> None:
        req = create_rollback_request(
            "G1",
            "cycle-1",
            "branch_delete",
            require_approval=False,
        )
        result = execute_rollback(req, tmp_path / "runs")
        assert result["status"] == "recorded"
        assert "git branch -D" in result["instructions"]

    def test_approval_required_raises(self, tmp_path: Path) -> None:
        req = create_rollback_request("G1", "cycle-1", "worktree_reset")
        with pytest.raises(RuntimeError, match="requires approval"):
            execute_rollback(req, tmp_path / "runs")

    def test_approval_with_correct_token(self, tmp_path: Path) -> None:
        runs_dir = tmp_path / "runs"
        (runs_dir / "cycle-1").mkdir(parents=True)

        req = create_rollback_request("G1", "cycle-1", "worktree_reset")
        result = execute_rollback(
            req,
            runs_dir,
            approval_token=req.approval_token,
        )
        assert result["status"] == "no_worktree"
        assert req.approved is True

    def test_approval_wrong_token_raises(self, tmp_path: Path) -> None:
        req = create_rollback_request("G1", "cycle-1", "worktree_reset")
        with pytest.raises(RuntimeError, match="requires approval"):
            execute_rollback(
                req,
                tmp_path / "runs",
                approval_token="wrong-token",
            )


class TestLogRollbackEvent:
    def test_appends_event(self, tmp_path: Path) -> None:
        sessions_dir = tmp_path / "sessions"
        sid = "session-rb1"
        (sessions_dir / sid).mkdir(parents=True)

        log_rollback_event(
            sid,
            sessions_dir,
            "GOAL_ROLLBACK_REQUESTED",
            {
                "goal_id": "G1",
                "run_id": "cycle-1",
                "mode": "worktree_reset",
            },
        )

        log_path = sessions_dir / sid / "session.jsonl"
        lines = [ln for ln in log_path.read_text().splitlines() if ln.strip()]
        assert len(lines) == 1

        event = json.loads(lines[0])
        assert event["event"] == "GOAL_ROLLBACK_REQUESTED"
        assert event["goal_id"] == "G1"
        assert "timestamp" in event

    def test_multiple_events(self, tmp_path: Path) -> None:
        sessions_dir = tmp_path / "sessions"
        sid = "session-rb2"
        (sessions_dir / sid).mkdir(parents=True)

        log_rollback_event(sid, sessions_dir, "GOAL_ROLLBACK_REQUESTED", {"goal_id": "G1"})
        log_rollback_event(sid, sessions_dir, "GOAL_ROLLBACK_EXECUTED", {"goal_id": "G1"})

        log_path = sessions_dir / sid / "session.jsonl"
        lines = [ln for ln in log_path.read_text().splitlines() if ln.strip()]
        assert len(lines) == 2
        assert json.loads(lines[0])["event"] == "GOAL_ROLLBACK_REQUESTED"
        assert json.loads(lines[1])["event"] == "GOAL_ROLLBACK_EXECUTED"
