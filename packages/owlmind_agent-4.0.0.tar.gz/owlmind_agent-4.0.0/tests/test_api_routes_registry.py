"""Tests for registry API endpoints (with authentication)."""

from __future__ import annotations

import asyncio
import io
import json
import zipfile
from pathlib import Path
from typing import Any

import pytest
from fastapi import FastAPI
from starlette.testclient import TestClient

from owlmind.api.registry_auth import hash_api_key
from owlmind.api.routes.registry import make_registry_router
from owlmind.registry.models import PublishRequest
from owlmind.registry.public import SQLitePublicPackRegistry


def _make_zip(manifest: dict[str, Any]) -> bytes:
    """Create a minimal ZIP with manifest.json."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        zf.writestr("manifest.json", json.dumps(manifest))
    return buf.getvalue()


_ADMIN_KEY = "cwrk_test_admin_for_api_tests"


@pytest.fixture()
def setup(tmp_path: Path):
    """Create test app with registry router and pre-seeded admin."""
    db_path = tmp_path / "test.db"
    archive_dir = tmp_path / "archives"

    app = FastAPI()
    router = make_registry_router(registry_db=db_path, archive_dir=archive_dir)
    app.include_router(router)

    client = TestClient(app)
    registry = SQLitePublicPackRegistry(db_path)

    # Seed admin user for auth
    asyncio.run(
        registry.create_user(
            username="testadmin",
            email="admin@test.com",
            role="admin",
            api_key_hash=hash_api_key(_ADMIN_KEY),
        )
    )

    def publish_and_approve(
        pack_id: str = "test-pack", name: str = "Test Pack", version: str = "1.0.0"
    ) -> dict[str, Any]:
        req = PublishRequest(name=name, version=version, tags=["python"], author_name="tester")
        asyncio.run(registry.publish_pack(pack_id, req))
        asyncio.run(registry.approve_pack(pack_id))
        pack = asyncio.run(registry.get_pack(pack_id))
        return pack  # type: ignore[return-value]

    class Setup:
        pass

    s = Setup()
    s.client = client  # type: ignore[attr-defined]
    s.registry = registry  # type: ignore[attr-defined]
    s.tmp_path = tmp_path  # type: ignore[attr-defined]
    s.archive_dir = archive_dir  # type: ignore[attr-defined]
    s.publish_and_approve = publish_and_approve  # type: ignore[attr-defined]
    s.headers = {"X-Registry-Token": _ADMIN_KEY}  # type: ignore[attr-defined]
    return s


# ---------------------------------------------------------------------------
# Search API
# ---------------------------------------------------------------------------


class TestSearchAPI:
    def test_empty(self, setup) -> None:
        """Empty registry returns empty list."""
        resp = setup.client.get("/api/v1/registry/packs", headers=setup.headers)
        assert resp.status_code == 200
        assert resp.json() == []

    def test_returns_approved(self, setup) -> None:
        """Search returns only approved packs."""
        setup.publish_and_approve("pk-1", "Pack One")
        resp = setup.client.get("/api/v1/registry/packs", headers=setup.headers)
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 1
        assert data[0]["name"] == "Pack One"

    def test_query_filter(self, setup) -> None:
        """Search query filters by name."""
        setup.publish_and_approve("pk-1", "Code Review")
        setup.publish_and_approve("pk-2", "Test Writer")

        resp = setup.client.get(
            "/api/v1/registry/packs", params={"q": "Code"}, headers=setup.headers
        )
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 1
        assert data[0]["name"] == "Code Review"

    def test_tag_filter(self, setup) -> None:
        """Search filters by tag."""
        setup.publish_and_approve("pk-1")
        resp = setup.client.get(
            "/api/v1/registry/packs", params={"tag": "python"}, headers=setup.headers
        )
        assert resp.status_code == 200
        assert len(resp.json()) == 1


# ---------------------------------------------------------------------------
# Get pack details
# ---------------------------------------------------------------------------


class TestGetPackAPI:
    def test_existing(self, setup) -> None:
        """Get existing pack returns details with versions."""
        setup.publish_and_approve("pk-1", "My Pack")
        resp = setup.client.get("/api/v1/registry/packs/pk-1", headers=setup.headers)
        assert resp.status_code == 200
        data = resp.json()
        assert data["name"] == "My Pack"
        assert "versions" in data
        assert "reviews_summary" in data

    def test_not_found(self, setup) -> None:
        """Get nonexistent pack returns 404."""
        resp = setup.client.get("/api/v1/registry/packs/missing", headers=setup.headers)
        assert resp.status_code == 404


# ---------------------------------------------------------------------------
# Publish API
# ---------------------------------------------------------------------------


class TestPublishAPI:
    def test_creates_pending(self, setup) -> None:
        """Publishing creates pack with pending status."""
        manifest = {"id": "new-pack", "name": "New Pack", "version": "1.0.0"}
        archive = _make_zip(manifest)

        resp = setup.client.post(
            "/api/v1/registry/packs",
            files={"archive": ("pack.zip", archive, "application/zip")},
            data={"name": "New Pack", "version": "1.0.0", "tags": "[]"},
            headers=setup.headers,
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["status"] == "pending"
        assert data["pack_id"] == "new-pack"

    def test_validates_manifest(self, setup) -> None:
        """Publishing validates manifest.json presence."""
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as zf:
            zf.writestr("readme.txt", "hello")
        bad_zip = buf.getvalue()

        resp = setup.client.post(
            "/api/v1/registry/packs",
            files={"archive": ("pack.zip", bad_zip, "application/zip")},
            data={"name": "Bad", "version": "1.0.0", "tags": "[]"},
            headers=setup.headers,
        )
        assert resp.status_code == 400
        assert "manifest.json" in resp.json()["detail"]

    def test_validates_required_fields(self, setup) -> None:
        """Publishing validates required manifest fields."""
        manifest = {"name": "No ID"}
        archive = _make_zip(manifest)

        resp = setup.client.post(
            "/api/v1/registry/packs",
            files={"archive": ("pack.zip", archive, "application/zip")},
            data={"name": "No ID", "version": "1.0.0", "tags": "[]"},
            headers=setup.headers,
        )
        assert resp.status_code == 400
        assert "missing required field" in resp.json()["detail"]


# ---------------------------------------------------------------------------
# Download API
# ---------------------------------------------------------------------------


class TestDownloadAPI:
    def test_nonexistent_404(self, setup) -> None:
        """Downloading nonexistent version returns 404."""
        setup.publish_and_approve("pk-1")
        resp = setup.client.get("/api/v1/registry/packs/pk-1/download/9.9.9", headers=setup.headers)
        assert resp.status_code == 404

    def test_increments_counter(self, setup) -> None:
        """Downloading increments the download counter."""
        setup.publish_and_approve("pk-1", version="1.0.0")

        manifest = {"id": "pk-1", "name": "Test", "version": "1.0.0"}
        archive_data = _make_zip(manifest)
        archive_path = setup.archive_dir / "pk-1" / "1.0.0.zip"
        archive_path.parent.mkdir(parents=True, exist_ok=True)
        archive_path.write_bytes(archive_data)

        asyncio.run(setup.registry.add_version("pk-1", "1.0.0", archive_size=len(archive_data)))

        resp = setup.client.get("/api/v1/registry/packs/pk-1/download/1.0.0", headers=setup.headers)
        assert resp.status_code == 200

        pack = asyncio.run(setup.registry.get_pack("pk-1"))
        assert pack is not None
        assert pack["downloads"] >= 1


# ---------------------------------------------------------------------------
# Reviews API
# ---------------------------------------------------------------------------


class TestReviewAPI:
    def test_add_review(self, setup) -> None:
        """Adding a review returns it."""
        setup.publish_and_approve("pk-1")
        resp = setup.client.post(
            "/api/v1/registry/packs/pk-1/reviews",
            json={"rating": 5, "comment": "Excellent!", "author_name": "reviewer"},
            headers=setup.headers,
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["rating"] == 5
        assert data["comment"] == "Excellent!"

    def test_updates_rating(self, setup) -> None:
        """Adding reviews updates average rating."""
        setup.publish_and_approve("pk-1")
        setup.client.post(
            "/api/v1/registry/packs/pk-1/reviews",
            json={"rating": 5, "author_name": "user1"},
            headers=setup.headers,
        )
        setup.client.post(
            "/api/v1/registry/packs/pk-1/reviews",
            json={"rating": 3, "author_name": "user2"},
            headers=setup.headers,
        )

        resp = setup.client.get("/api/v1/registry/packs/pk-1", headers=setup.headers)
        data = resp.json()
        assert data["avg_rating"] == 4.0

    def test_list_reviews(self, setup) -> None:
        """Listing reviews returns all reviews."""
        setup.publish_and_approve("pk-1")
        setup.client.post(
            "/api/v1/registry/packs/pk-1/reviews",
            json={"rating": 4, "author_name": "user1", "comment": "Good"},
            headers=setup.headers,
        )

        resp = setup.client.get("/api/v1/registry/packs/pk-1/reviews", headers=setup.headers)
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 1
        assert data[0]["comment"] == "Good"

    def test_review_not_found(self, setup) -> None:
        """Adding review to nonexistent pack returns 404."""
        resp = setup.client.post(
            "/api/v1/registry/packs/missing/reviews",
            json={"rating": 5, "author_name": "user"},
            headers=setup.headers,
        )
        assert resp.status_code == 404


# ---------------------------------------------------------------------------
# Admin API
# ---------------------------------------------------------------------------


class TestAdminAPI:
    def test_approve(self, setup) -> None:
        """Admin approve endpoint works."""
        req = PublishRequest(name="Pack", version="1.0.0", author_name="tester")
        asyncio.run(setup.registry.publish_pack("pk-1", req))

        resp = setup.client.post("/api/v1/registry/admin/approve/pk-1", headers=setup.headers)
        assert resp.status_code == 200
        assert resp.json()["status"] == "approved"

    def test_reject(self, setup) -> None:
        """Admin reject endpoint works."""
        req = PublishRequest(name="Pack", version="1.0.0", author_name="tester")
        asyncio.run(setup.registry.publish_pack("pk-1", req))

        resp = setup.client.post("/api/v1/registry/admin/reject/pk-1", headers=setup.headers)
        assert resp.status_code == 200
        assert resp.json()["status"] == "rejected"

    def test_approve_not_found(self, setup) -> None:
        """Approving nonexistent pack returns 404."""
        resp = setup.client.post("/api/v1/registry/admin/approve/missing", headers=setup.headers)
        assert resp.status_code == 404
