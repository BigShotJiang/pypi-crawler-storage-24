"""Tests for FS82 — LiveDashboard data readers and lifecycle."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

from owlmind.tui.dashboard import LiveDashboard


class TestLiveDashboardInit:
    def test_defaults(self, tmp_path: Path) -> None:
        runs_dir = tmp_path / "runs"
        db = LiveDashboard(runs_dir=runs_dir)
        assert db.ledger_dir == tmp_path / "ledger"
        assert db.queue_dir == tmp_path / "queue"
        assert db.max_tokens == 500_000
        assert db.max_usd == 10.0
        assert db._running is False
        assert db._events == []

    def test_custom_params(self, tmp_path: Path) -> None:
        runs_dir = tmp_path / "runs"
        ledger_dir = tmp_path / "my_ledger"
        queue_dir = tmp_path / "my_queue"
        db = LiveDashboard(
            runs_dir=runs_dir,
            ledger_dir=ledger_dir,
            queue_dir=queue_dir,
            max_ticks=5,
            max_usd=42.0,
            max_tokens=999,
            refresh_interval=7,
        )
        assert db.ledger_dir == ledger_dir
        assert db.queue_dir == queue_dir
        assert db.max_ticks == 5
        assert db.max_usd == 42.0
        assert db.max_tokens == 999
        assert db.refresh_interval == 7


class TestReadRuns:
    def test_dir_not_exists(self, tmp_path: Path) -> None:
        db = LiveDashboard(runs_dir=tmp_path / "runs")
        assert db._read_runs() == []

    def test_empty_dir(self, tmp_path: Path) -> None:
        runs_dir = tmp_path / "runs"
        runs_dir.mkdir()
        db = LiveDashboard(runs_dir=runs_dir)
        assert db._read_runs() == []

    def test_valid_cycle_meta(self, tmp_path: Path) -> None:
        runs_dir = tmp_path / "runs"
        run_dir = runs_dir / "run-001"
        run_dir.mkdir(parents=True)
        meta = {"run_id": "r1", "state": "DONE"}
        (run_dir / "cycle_meta.json").write_text(json.dumps(meta))

        db = LiveDashboard(runs_dir=runs_dir)
        result = db._read_runs()
        assert result == [meta]

    def test_invalid_json_skipped(self, tmp_path: Path) -> None:
        runs_dir = tmp_path / "runs"
        # Valid run
        valid_dir = runs_dir / "run-001"
        valid_dir.mkdir(parents=True)
        (valid_dir / "cycle_meta.json").write_text(json.dumps({"run_id": "valid"}))
        # Invalid run
        bad_dir = runs_dir / "run-002"
        bad_dir.mkdir(parents=True)
        (bad_dir / "cycle_meta.json").write_text("not valid json {{{{")

        db = LiveDashboard(runs_dir=runs_dir)
        result = db._read_runs()
        assert len(result) == 1
        assert result[0]["run_id"] == "valid"


class TestReadBudget:
    def test_file_not_exists(self, tmp_path: Path) -> None:
        db = LiveDashboard(
            runs_dir=tmp_path / "runs",
            ledger_dir=tmp_path / "ledger",
        )
        result = db._read_budget()
        assert result == {
            "total_tokens": 0,
            "estimated_usd": 0.0,
            "max_tokens": 500_000,
            "max_usd": 10.0,
        }

    def test_accumulates_entries(self, tmp_path: Path) -> None:
        ledger_dir = tmp_path / "ledger"
        ledger_dir.mkdir()
        usage_path = ledger_dir / "usage.jsonl"
        lines = [
            json.dumps({"total_tokens": 100, "estimated_usd": 0.05}),
            json.dumps({"total_tokens": 200, "estimated_usd": 0.10}),
        ]
        usage_path.write_text("\n".join(lines) + "\n")

        db = LiveDashboard(runs_dir=tmp_path / "runs", ledger_dir=ledger_dir)
        result = db._read_budget()
        assert result["total_tokens"] == 300
        assert abs(result["estimated_usd"] - 0.15) < 1e-9

    def test_invalid_json_skipped(self, tmp_path: Path) -> None:
        ledger_dir = tmp_path / "ledger"
        ledger_dir.mkdir()
        usage_path = ledger_dir / "usage.jsonl"
        lines = [
            json.dumps({"total_tokens": 50, "estimated_usd": 0.02}),
            "bad json !!!",
            json.dumps({"total_tokens": 75, "estimated_usd": 0.03}),
        ]
        usage_path.write_text("\n".join(lines) + "\n")

        db = LiveDashboard(runs_dir=tmp_path / "runs", ledger_dir=ledger_dir)
        result = db._read_budget()
        assert result["total_tokens"] == 125
        assert abs(result["estimated_usd"] - 0.05) < 1e-9


class TestReadQueue:
    def test_valid_entries(self, tmp_path: Path) -> None:
        queue_dir = tmp_path / "queue"
        queue_dir.mkdir()
        items = [
            {"status": "PENDING", "goal": "task one"},
            {"status": "RUNNING", "goal": "task two"},
        ]
        (queue_dir / "queue.jsonl").write_text("\n".join(json.dumps(item) for item in items) + "\n")

        db = LiveDashboard(runs_dir=tmp_path / "runs", queue_dir=queue_dir)
        result = db._read_queue()
        assert len(result) == 2
        assert result[0] == items[0]
        assert result[1] == items[1]


class TestOnEvent:
    def test_appends_event(self, tmp_path: Path) -> None:
        db = LiveDashboard(runs_dir=tmp_path / "runs")
        db.on_event("started", {"run_id": "r1"})

        assert len(db._events) == 1
        evt = db._events[0]
        assert evt["event"] == "started"
        assert evt["run_id"] == "r1"
        assert "timestamp" in evt
        assert evt["timestamp"]  # not empty

    def test_trims_to_50(self, tmp_path: Path) -> None:
        db = LiveDashboard(runs_dir=tmp_path / "runs")
        for i in range(60):
            db.on_event("tick", {"run_id": f"r{i}"})

        assert len(db._events) == 50
        # Should keep the most recent 50
        assert db._events[-1]["run_id"] == "r59"
        assert db._events[0]["run_id"] == "r10"


class TestDashboardStart:
    def test_start_max_ticks_1(self, tmp_path: Path) -> None:
        with patch("owlmind.tui.dashboard.Live") as MockLive:
            mock_ctx = MagicMock()
            MockLive.return_value.__enter__ = MagicMock(return_value=mock_ctx)
            MockLive.return_value.__exit__ = MagicMock(return_value=False)
            with patch("owlmind.tui.dashboard.time.sleep"):
                db = LiveDashboard(
                    runs_dir=tmp_path / "runs",
                    max_ticks=1,
                    refresh_interval=0,
                )
                db.start()

        assert db._running is False
        assert mock_ctx.update.call_count >= 1


class TestReadBudgetEmptyLines:
    """Line 93: empty lines in usage.jsonl are skipped."""

    def test_blank_line_skipped(self, tmp_path: Path) -> None:
        ledger_dir = tmp_path / "ledger"
        ledger_dir.mkdir()
        (ledger_dir / "usage.jsonl").write_text(
            json.dumps({"total_tokens": 10, "estimated_usd": 0.01})
            + "\n\n"
            + json.dumps({"total_tokens": 20, "estimated_usd": 0.02})
            + "\n"
        )
        db = LiveDashboard(runs_dir=tmp_path / "runs", ledger_dir=ledger_dir)
        result = db._read_budget()
        assert result["total_tokens"] == 30


class TestReadQueueEmptyLines:
    """Line 110: empty lines in queue.jsonl are skipped."""

    def test_blank_line_skipped(self, tmp_path: Path) -> None:
        queue_dir = tmp_path / "queue"
        queue_dir.mkdir()
        (queue_dir / "queue.jsonl").write_text(
            json.dumps({"status": "PENDING", "goal": "task A"})
            + "\n\n"
            + json.dumps({"status": "RUNNING", "goal": "task B"})
            + "\n"
        )
        db = LiveDashboard(runs_dir=tmp_path / "runs", queue_dir=queue_dir)
        result = db._read_queue()
        assert len(result) == 2


class TestDashboardKeyboardInterrupt:
    """Lines 189-191: KeyboardInterrupt during start() is caught, _running → False."""

    def test_keyboard_interrupt_handled(self, tmp_path: Path) -> None:
        with patch("owlmind.tui.dashboard.Live") as MockLive:
            MockLive.return_value.__enter__ = MagicMock(side_effect=KeyboardInterrupt)
            MockLive.return_value.__exit__ = MagicMock(return_value=False)
            db = LiveDashboard(runs_dir=tmp_path / "runs", max_ticks=0, refresh_interval=0)
            db.start()
        assert db._running is False


class TestDashboardSleepCalled:
    """Line 189: time.sleep is called when loop iterates more than once (max_ticks >= 2)."""

    def test_sleep_called_between_ticks(self, tmp_path: Path) -> None:
        with patch("owlmind.tui.dashboard.Live") as MockLive:
            mock_ctx = MagicMock()
            MockLive.return_value.__enter__ = MagicMock(return_value=mock_ctx)
            MockLive.return_value.__exit__ = MagicMock(return_value=False)
            with patch("owlmind.tui.dashboard.time.sleep") as mock_sleep:
                db = LiveDashboard(
                    runs_dir=tmp_path / "runs",
                    max_ticks=2,
                    refresh_interval=0,
                )
                db.start()

        # sleep must have been called at least once (between tick 1 and tick 2)
        assert mock_sleep.call_count >= 1
        assert db._running is False


class TestDashboardStop:
    """Line 197: stop() sets _running=False."""

    def test_stop_sets_running_false(self, tmp_path: Path) -> None:
        db = LiveDashboard(runs_dir=tmp_path / "runs")
        db._running = True
        db.stop()
        assert db._running is False
