"""Tests for auto-advance — cycle next stops when waiting for inbox."""

from __future__ import annotations

import json
from pathlib import Path

from owlmind.agent.cycle import CycleManager
from owlmind.agent.schemas import CycleState
from owlmind.evidence import EvidenceStore
from owlmind.policy import PolicyEngine


def _make_manager(tmp_path: Path) -> CycleManager:
    policies_dir = tmp_path / "policies"
    policies_dir.mkdir()
    (policies_dir / "allowlist.yaml").write_text('allowed_commands:\n  - "^echo "\n  - "^pytest"\n')
    (policies_dir / "policy.yaml").write_text('forbidden_patterns:\n  - "rm -rf"\n')
    policy = PolicyEngine.from_directory(policies_dir)
    evidence = EvidenceStore(tmp_path / "runs")
    return CycleManager(evidence=evidence, policy=policy)


def _write_inbox(tmp_path: Path, run_id: str, filename: str, data: dict) -> None:  # type: ignore[type-arg]
    inbox = tmp_path / "runs" / run_id / "inbox"
    inbox.mkdir(parents=True, exist_ok=True)
    (inbox / filename).write_text(json.dumps(data))


class TestAutoAdvance:
    def test_stops_when_waiting_for_inbox(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Auto test", workspace=str(tmp_path))

        # No inbox file — should return "Waiting" message
        updated, msg = mgr.next(meta.run_id)
        assert updated.state == CycleState.STARTED_WAIT_PLANNER
        assert "Waiting" in msg

    def test_advances_through_planner(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Auto test", workspace=str(tmp_path))

        planner_resp = {
            "run_id": meta.run_id,
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        _write_inbox(tmp_path, meta.run_id, "planner_response.json", planner_resp)

        # First next() should advance
        updated, msg = mgr.next(meta.run_id)
        assert updated.state == CycleState.WAIT_WORKER
        assert "Planner response submitted" in msg

        # Second next() should be waiting
        updated2, msg2 = mgr.next(meta.run_id)
        assert updated2.state == CycleState.WAIT_WORKER
        assert "Waiting" in msg2

    def test_stops_on_done(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Full cycle", workspace=str(tmp_path))

        # Go through full cycle to DONE
        planner_resp = {
            "run_id": meta.run_id,
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        _write_inbox(tmp_path, meta.run_id, "planner_response.json", planner_resp)
        mgr.submit_planner(meta.run_id)

        worker_report = {
            "run_id": meta.run_id,
            "iteration": 1,
            "status": "READY_FOR_VERIFY",
            "done_summary": ["Done"],
            "questions": [],
            "commands_run": [],
        }
        _write_inbox(tmp_path, meta.run_id, "worker_report.json", worker_report)
        mgr.submit_worker(meta.run_id)

        judge_resp = {
            "run_id": meta.run_id,
            "iteration": 1,
            "verdict": "APPROVED",
            "notes": ["Good"],
            "next_worker_instructions": "",
            "evidence_chain_verified": True,
        }
        _write_inbox(tmp_path, meta.run_id, "judge_response.json", judge_resp)
        mgr.submit_judge(meta.run_id)

        # next() on DONE should return terminal message
        updated, msg = mgr.next(meta.run_id)
        assert updated.state == CycleState.DONE
        assert "complete" in msg.lower()

    def test_stops_on_wait_approval(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Approval test", workspace=str(tmp_path))

        from owlmind.approval import create_approval

        create_approval(mgr.meta_store, meta.run_id, "test reason")

        updated, msg = mgr.next(meta.run_id)
        assert updated.state == CycleState.WAIT_APPROVAL
        assert "approval" in msg.lower()
