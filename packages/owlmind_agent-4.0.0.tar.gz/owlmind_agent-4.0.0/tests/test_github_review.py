"""Tests for owlmind.github_review."""
from __future__ import annotations

import sys
from unittest.mock import MagicMock, patch

import pytest

from owlmind.github_review import PRReviewResult, get_pr_info, post_comment, review_pr


def test_pr_review_result_success() -> None:
    r = PRReviewResult(repo="owner/repo", pr_number=1, verdict="APPROVED")
    assert r.success is True

def test_pr_review_result_failure() -> None:
    r = PRReviewResult(repo="owner/repo", pr_number=1, verdict="REJECTED")
    assert r.success is False

def test_format_comment_approved() -> None:
    r = PRReviewResult(repo="owner/repo", pr_number=1, title="Fix bug",
                       goal="fix tests", verdict="APPROVED", review="Looks good")
    comment = r.format_comment()
    assert "APPROVED" in comment
    assert "Fix bug" in comment
    assert "Looks good" in comment
    assert "owlmind" in comment

def test_format_comment_error() -> None:
    r = PRReviewResult(repo="owner/repo", pr_number=1, error="LLM unavailable")
    comment = r.format_comment()
    assert "LLM unavailable" in comment

def test_get_pr_info_success() -> None:
    fake_httpx = MagicMock()
    fake_resp = MagicMock()
    fake_resp.status_code = 200
    fake_resp.json.return_value = {
        "title": "Fix test failures",
        "body": "This PR fixes the tests",
        "base": {"ref": "main"},
        "head": {"ref": "fix-tests"},
        "changed_files": 3,
        "additions": 20,
        "deletions": 5,
    }
    fake_httpx.get.return_value = fake_resp

    with patch.dict(sys.modules, {"httpx": fake_httpx}):
        result = get_pr_info("owner/repo", 42)

    assert result["title"] == "Fix test failures"
    assert result["changed_files"] == 3

def test_get_pr_info_no_httpx() -> None:
    with patch.dict(sys.modules, {"httpx": None}):
        result = get_pr_info("owner/repo", 42)
    assert result == {}

def test_get_pr_info_api_error() -> None:
    fake_httpx = MagicMock()
    fake_resp = MagicMock()
    fake_resp.status_code = 404
    fake_httpx.get.return_value = fake_resp

    with patch.dict(sys.modules, {"httpx": fake_httpx}):
        result = get_pr_info("owner/repo", 999)
    assert result == {}

def test_review_pr_no_llm() -> None:
    with patch("owlmind.github_review.get_pr_info", return_value={"title": "Test PR", "body": ""}), \
         patch("owlmind.github_review._build_llm_client", return_value=None):
        result = review_pr("owner/repo", 1, workspace=".")

    assert result.error == "No LLM configured"

def test_review_pr_success() -> None:
    mock_state = MagicMock()
    mock_state.final_verdict = "APPROVED"
    mock_state.review = "Code looks good"

    with patch("owlmind.github_review.get_pr_info", return_value={"title": "Fix bug", "body": ""}), \
         patch("owlmind.github_review._build_llm_client", return_value=MagicMock()), \
         patch("owlmind.github_review.GraphRunner") as mock_cls:
        mock_runner = MagicMock()
        mock_runner.run.return_value = mock_state
        mock_cls.return_value = mock_runner
        result = review_pr("owner/repo", 1, workspace=".")

    assert result.verdict == "APPROVED"
    assert result.review == "Code looks good"

def test_post_comment_success() -> None:
    fake_httpx = MagicMock()
    fake_resp = MagicMock()
    fake_resp.status_code = 201
    fake_httpx.post.return_value = fake_resp

    with patch.dict(sys.modules, {"httpx": fake_httpx}):
        ok = post_comment("owner/repo", 1, "test comment", token="ghp_test")

    assert ok is True

def test_post_comment_no_token(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("GITHUB_TOKEN", raising=False)
    fake_httpx = MagicMock()
    with patch.dict(sys.modules, {"httpx": fake_httpx}):
        ok = post_comment("owner/repo", 1, "test", token="")
    assert ok is False

def test_post_comment_no_httpx() -> None:
    with patch.dict(sys.modules, {"httpx": None}):
        ok = post_comment("owner/repo", 1, "test", token="ghp_test")
    assert ok is False
