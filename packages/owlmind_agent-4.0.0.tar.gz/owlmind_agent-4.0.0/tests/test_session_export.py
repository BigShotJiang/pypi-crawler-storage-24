"""Tests for session export — no network calls."""

from __future__ import annotations

import json
import zipfile
from pathlib import Path

from owlmind.session import (
    GoalRunInfo,
    GoalSpec,
    SessionMeta,
    save_session,
)
from owlmind.session_export import export_session


def _make_session(tmp_path: Path, *, with_runs: bool = False) -> SessionMeta:
    """Create a minimal session on disk."""
    sessions_dir = tmp_path / "sessions"
    runs_dir = tmp_path / "runs"

    runs: list[GoalRunInfo] = []
    if with_runs:
        runs = [
            GoalRunInfo(
                goal_id="G1",
                run_id="cycle-r1",
                status="done",
                started_at="2026-01-01T00:00:00Z",
                ended_at="2026-01-01T00:01:00Z",
            ),
            GoalRunInfo(
                goal_id="G2",
                run_id="cycle-r2",
                status="done",
                started_at="2026-01-01T00:01:00Z",
                ended_at="2026-01-01T00:02:00Z",
            ),
        ]

    meta = SessionMeta(
        session_id="session-export1",
        created_at="2026-01-01T00:00:00Z",
        updated_at="2026-01-01T00:00:00Z",
        status="DONE",
        goals=[
            GoalSpec(id="G1", goal="First goal"),
            GoalSpec(id="G2", goal="Second goal"),
        ],
        runs=runs,
    )

    save_session(meta, sessions_dir)

    # Create session.jsonl
    sdir = sessions_dir / meta.session_id
    (sdir / "session.jsonl").write_text("")
    (sdir / "goals_resolved.yaml").write_text("version: 1\ngoals: []\n")
    (sdir / "protocol.md").write_text("# Protocol\n")

    # Create run dirs with artifacts
    if with_runs:
        for run_info in runs:
            rdir = runs_dir / run_info.run_id
            rdir.mkdir(parents=True, exist_ok=True)
            (rdir / "cycle_meta.json").write_text(json.dumps({"run_id": run_info.run_id}))
            (rdir / "summary.json").write_text(json.dumps({"report": {"status": "PASS"}}))
            (rdir / "run.jsonl").write_text("")

        # Add pr_pack.md to first run only
        (runs_dir / "cycle-r1" / "pr_pack.md").write_text("# PR\nchanges here\n")

        # Add evidence manifest to second run
        evidence_dir = runs_dir / "cycle-r2" / "evidence"
        evidence_dir.mkdir(parents=True)
        (evidence_dir / "manifest.json").write_text(json.dumps({"files": ["test.py"]}))

    return meta


class TestExportSession:
    def test_creates_zip(self, tmp_path: Path) -> None:
        """Export creates a valid zip file."""
        meta = _make_session(tmp_path)
        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"

        result = export_session(meta.session_id, sessions_dir, runs_dir)

        assert result.exists()
        assert result.suffix == ".zip"
        assert zipfile.is_zipfile(result)

    def test_zip_contains_session_files(self, tmp_path: Path) -> None:
        """Zip should include session-level files."""
        meta = _make_session(tmp_path)
        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"

        result = export_session(meta.session_id, sessions_dir, runs_dir)

        with zipfile.ZipFile(result, "r") as zf:
            names = zf.namelist()

        sid = meta.session_id
        assert f"{sid}/session_meta.json" in names
        assert f"{sid}/session.jsonl" in names
        assert f"{sid}/goals_resolved.yaml" in names
        assert f"{sid}/protocol.md" in names

    def test_zip_contains_run_artifacts(self, tmp_path: Path) -> None:
        """Zip should include per-run artifacts."""
        meta = _make_session(tmp_path, with_runs=True)
        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"

        result = export_session(meta.session_id, sessions_dir, runs_dir)

        with zipfile.ZipFile(result, "r") as zf:
            names = zf.namelist()

        sid = meta.session_id
        # Run 1 artifacts
        assert f"{sid}/runs/cycle-r1/cycle_meta.json" in names
        assert f"{sid}/runs/cycle-r1/summary.json" in names
        assert f"{sid}/runs/cycle-r1/pr_pack.md" in names
        assert f"{sid}/runs/cycle-r1/run.jsonl" in names

        # Run 2 artifacts
        assert f"{sid}/runs/cycle-r2/cycle_meta.json" in names
        assert f"{sid}/runs/cycle-r2/summary.json" in names
        assert f"{sid}/runs/cycle-r2/run.jsonl" in names

    def test_zip_contains_evidence_manifest(self, tmp_path: Path) -> None:
        """Zip should include evidence manifest when present."""
        meta = _make_session(tmp_path, with_runs=True)
        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"

        result = export_session(meta.session_id, sessions_dir, runs_dir)

        with zipfile.ZipFile(result, "r") as zf:
            names = zf.namelist()

        sid = meta.session_id
        assert f"{sid}/runs/cycle-r2/evidence/manifest.json" in names

    def test_custom_output_path(self, tmp_path: Path) -> None:
        """Export to a custom output path (inside session exports dir)."""
        meta = _make_session(tmp_path)
        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"
        out = sessions_dir / meta.session_id / "exports" / "custom_export.zip"

        result = export_session(meta.session_id, sessions_dir, runs_dir, out_path=out)

        assert result == out
        assert result.exists()

    def test_records_event(self, tmp_path: Path) -> None:
        """Export should append SESSION_EXPORT_CREATED event."""
        meta = _make_session(tmp_path)
        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"

        export_session(meta.session_id, sessions_dir, runs_dir)

        # Read events
        log_path = sessions_dir / meta.session_id / "session.jsonl"
        lines = [ln for ln in log_path.read_text().splitlines() if ln.strip()]
        assert len(lines) >= 1

        last = json.loads(lines[-1])
        assert last["event"] == "SESSION_EXPORT_CREATED"
        assert "size_bytes" in last
        assert last["size_bytes"] > 0

    def test_missing_run_dir_skipped(self, tmp_path: Path) -> None:
        """Runs with missing directories should be gracefully skipped."""
        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"

        # Create session with run but NO run directory
        meta = SessionMeta(
            session_id="session-noruns",
            created_at="2026-01-01T00:00:00Z",
            updated_at="2026-01-01T00:00:00Z",
            status="DONE",
            goals=[GoalSpec(id="G1", goal="Test")],
            runs=[
                GoalRunInfo(
                    goal_id="G1",
                    run_id="cycle-missing",
                    status="done",
                ),
            ],
        )
        save_session(meta, sessions_dir)
        sdir = sessions_dir / meta.session_id
        (sdir / "session.jsonl").write_text("")

        result = export_session(meta.session_id, sessions_dir, runs_dir)

        assert result.exists()
        with zipfile.ZipFile(result, "r") as zf:
            names = zf.namelist()
        # Session file should be there, run artifacts should not
        assert f"{meta.session_id}/session_meta.json" in names
        assert not any("cycle-missing" in n for n in names)

    def test_empty_session_no_runs(self, tmp_path: Path) -> None:
        """Export works for a session with zero runs."""
        meta = _make_session(tmp_path, with_runs=False)
        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"

        result = export_session(meta.session_id, sessions_dir, runs_dir)

        assert result.exists()
        with zipfile.ZipFile(result, "r") as zf:
            names = zf.namelist()

        sid = meta.session_id
        assert f"{sid}/session_meta.json" in names
        # No run entries
        assert not any("/runs/" in n for n in names)

    def test_export_zip_in_run_dir_creates_export_ref(self, tmp_path: Path) -> None:
        """When a owlmind_export_*.zip exists in a run dir, writestr writes export_ref.txt (lines 87-91)."""

        meta = _make_session(tmp_path, with_runs=True)
        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"

        # Place a fake owlmind_export_*.zip in the first run dir
        run_dir = runs_dir / "cycle-r1"
        fake_export_zip = run_dir / "owlmind_export_20260101.zip"
        fake_export_zip.write_bytes(b"PK")  # minimal zip-like content

        result = export_session(meta.session_id, sessions_dir, runs_dir)

        # Verify the archive contains the export_ref.txt entry
        with zipfile.ZipFile(result, "r") as zf:
            names = zf.namelist()
            sid = meta.session_id
            ref_name = f"{sid}/runs/cycle-r1/export_ref.txt"
            assert ref_name in names, f"Expected '{ref_name}' in zip, got: {names}"

            ref_content = zf.read(ref_name).decode()
            assert "owlmind_export_20260101.zip" in ref_content
            assert "Run export available:" in ref_content

    def test_export_ref_not_present_without_zip(self, tmp_path: Path) -> None:
        """Without a owlmind_export_*.zip in run dir, export_ref.txt is absent."""
        meta = _make_session(tmp_path, with_runs=True)
        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"

        result = export_session(meta.session_id, sessions_dir, runs_dir)

        with zipfile.ZipFile(result, "r") as zf:
            names = zf.namelist()

        assert not any("export_ref.txt" in n for n in names)

    def test_out_path_outside_exports_raises(self, tmp_path: Path) -> None:
        """Export path outside sessions/<id>/exports must raise ValueError (lines 37-38)."""
        import pytest

        meta = _make_session(tmp_path)
        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"

        # Point to a path outside the allowed exports dir
        bad_out = tmp_path / "evil_export.zip"

        with pytest.raises(ValueError, match="Export path must be inside"):
            export_session(meta.session_id, sessions_dir, runs_dir, out_path=bad_out)
