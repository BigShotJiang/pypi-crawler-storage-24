"""Tests for the owlmind web dashboard."""
from __future__ import annotations

from fastapi.testclient import TestClient

from owlmind.web.app import app

client = TestClient(app)


def test_index_returns_html() -> None:
    r = client.get("/")
    assert r.status_code == 200
    assert "text/html" in r.headers["content-type"]
    assert "owlmind" in r.text.lower() or "runs" in r.text.lower()


def test_api_runs_empty() -> None:
    r = client.get("/api/runs")
    assert r.status_code == 200
    data = r.json()
    assert isinstance(data, list)


def test_api_runs_unknown_run() -> None:
    r = client.get("/api/runs/nonexistent-run-id")
    assert r.status_code in (200, 404)


def test_api_status() -> None:
    r = client.get("/api/status")
    assert r.status_code == 200
    data = r.json()
    assert "version" in data or "status" in data


def test_api_runs_limit() -> None:
    r = client.get("/api/runs?limit=10")
    assert r.status_code == 200
