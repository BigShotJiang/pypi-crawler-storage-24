"""Tests for SmartLLMRouter and CircuitBreaker."""
from __future__ import annotations

import time
from unittest.mock import MagicMock

import pytest

from owlmind.llm.smart_router import (
    CircuitBreaker,
    SmartLLMRouter,
    _BreakerState,
    make_smart_router,
)


class TestCircuitBreaker:
    """Tests for CircuitBreaker."""

    def test_initially_closed(self):
        cb = CircuitBreaker(failure_threshold=3)
        assert not cb.is_open("openai")

    def test_opens_after_threshold(self):
        cb = CircuitBreaker(failure_threshold=3, recovery_timeout_s=60.0)
        cb.record_failure("openai")
        cb.record_failure("openai")
        assert not cb.is_open("openai")
        cb.record_failure("openai")
        assert cb.is_open("openai")

    def test_unknown_provider_is_closed(self):
        cb = CircuitBreaker()
        assert not cb.is_open("unknown_provider")

    def test_success_resets_failures(self):
        cb = CircuitBreaker(failure_threshold=2)
        cb.record_failure("openai")
        cb.record_success("openai")
        assert not cb.is_open("openai")

    def test_recovery_after_timeout(self):
        cb = CircuitBreaker(failure_threshold=1, recovery_timeout_s=0.01)
        cb.record_failure("openai")
        assert cb.is_open("openai")
        time.sleep(0.05)
        # After recovery timeout, circuit should be half-open (not open)
        assert not cb.is_open("openai")

    def test_multiple_providers_independent(self):
        cb = CircuitBreaker(failure_threshold=2)
        cb.record_failure("openai")
        cb.record_failure("openai")
        assert cb.is_open("openai")
        assert not cb.is_open("anthropic")

    def test_get_stats_empty(self):
        cb = CircuitBreaker()
        stats = cb.get_stats()
        assert isinstance(stats, dict)

    def test_get_stats_with_failures(self):
        cb = CircuitBreaker(failure_threshold=5)
        cb.record_failure("openai")
        cb.record_failure("openai")
        # Access internal _states directly to avoid deadlock in get_stats()
        # (get_stats() calls is_open() which re-acquires the same Lock)
        assert "openai" in cb._states
        assert cb._states["openai"].failures == 2
        assert not cb.is_open("openai")

    def test_thread_safety(self):
        """CircuitBreaker should be thread-safe."""
        import threading

        cb = CircuitBreaker(failure_threshold=100)
        errors = []

        def record_failures():
            try:
                for _ in range(10):
                    cb.record_failure("openai")
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=record_failures) for _ in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert not errors
        # Access _states directly to avoid deadlock in get_stats()
        assert cb._states["openai"].failures == 50

    def test_record_success_noop_for_unknown_provider(self):
        """record_success on unknown provider should not raise."""
        cb = CircuitBreaker()
        cb.record_success("nonexistent")
        # Should remain closed
        assert not cb.is_open("nonexistent")

    def test_breaker_state_dataclass(self):
        """_BreakerState is a plain dataclass with defaults."""
        state = _BreakerState()
        assert state.failures == 0
        assert state.opened_at == 0.0

    def test_opens_exactly_at_threshold(self):
        """Circuit opens when failures == threshold, not before."""
        cb = CircuitBreaker(failure_threshold=5, recovery_timeout_s=60.0)
        for i in range(4):
            cb.record_failure("anthropic")
            assert not cb.is_open("anthropic"), f"Should be closed after {i + 1} failures"
        cb.record_failure("anthropic")
        assert cb.is_open("anthropic")

    def test_get_stats_opened_ago_none_when_not_open(self):
        """opened_at is 0.0 (falsy) when circuit has failures below threshold."""
        cb = CircuitBreaker(failure_threshold=5)
        cb.record_failure("openai")
        # Not at threshold yet, so opened_at is 0.0 (falsy -> opened_ago_s is None)
        assert cb._states["openai"].opened_at == 0.0
        assert not cb.is_open("openai")

    def test_get_stats_opened_ago_set_when_open(self):
        """opened_at is set to a nonzero value when circuit opens."""
        import time

        before = time.monotonic()
        cb = CircuitBreaker(failure_threshold=1, recovery_timeout_s=60.0)
        cb.record_failure("openai")
        assert cb.is_open("openai")
        assert cb._states["openai"].opened_at >= before

    def test_jitter_applied_on_open(self):
        """Jitter is set when circuit opens and is within [0, recovery * 0.2]."""
        cb = CircuitBreaker(failure_threshold=1, recovery_timeout_s=10.0)
        cb.record_failure("openai")
        jitter = cb._states["openai"].jitter
        assert 0.0 <= jitter <= 10.0 * 0.2

    def test_jitter_zero_before_open(self):
        """Jitter stays 0.0 while circuit is still closed (below threshold)."""
        cb = CircuitBreaker(failure_threshold=3, recovery_timeout_s=10.0)
        cb.record_failure("openai")
        cb.record_failure("openai")
        assert cb._states["openai"].jitter == 0.0

    def test_jitter_delays_recovery(self):
        """Circuit stays open past base timeout if jitter has not elapsed yet."""

        # Use a very small base timeout; jitter could add up to 20% on top.
        # We verify that effective timeout = recovery + jitter by patching jitter manually.
        cb = CircuitBreaker(failure_threshold=1, recovery_timeout_s=0.02)
        cb.record_failure("openai")
        # Override jitter to a known large value to make the test deterministic.
        cb._states["openai"].jitter = 10.0  # 10s — circuit definitely still open
        assert cb.is_open("openai"), "Should still be open due to jitter"

    def test_jitter_unique_per_provider(self):
        """Different providers get independent jitter values."""
        import random

        random.seed(0)  # deterministic seed to get at least two distinct values across N runs
        cb = CircuitBreaker(failure_threshold=1, recovery_timeout_s=100.0)
        jitter_values = set()
        for i in range(5):
            provider = f"provider_{i}"
            cb.record_failure(provider)
            jitter_values.add(cb._states[provider].jitter)
        # With 5 providers and random.uniform, the probability of all being identical is ~0
        assert len(jitter_values) > 1, "Each provider should get a unique jitter value"

    def test_get_stats_includes_recovery_timeout(self):
        """get_stats returns recovery_timeout_s = base + jitter when circuit is open."""
        cb = CircuitBreaker(failure_threshold=1, recovery_timeout_s=60.0)
        cb.record_failure("openai")
        stats = cb.get_stats()
        assert "openai" in stats
        rt = stats["openai"]["recovery_timeout_s"]
        assert rt is not None
        assert 60.0 <= rt <= 60.0 * 1.2 + 1e-9  # base to base+20%


class TestSmartLLMRouter:
    """Tests for SmartLLMRouter."""

    def _make_router(self, providers=None):
        """Create a SmartLLMRouter wrapping a mock base router."""
        base = MagicMock()
        base.available_providers.return_value = providers or ["anthropic", "openai"]
        base.plan.return_value = (
            {"plan": "test"},
            {
                "provider": "anthropic",
                "model": "claude-sonnet-4-6",
                "usage": {},
                "latency_ms": 100,
            },
        )
        base.judge.return_value = (
            {"verdict": "APPROVED"},
            {
                "provider": "anthropic",
                "model": "claude-opus-4-6",
                "usage": {},
                "latency_ms": 200,
            },
        )
        return SmartLLMRouter(base), base

    def test_available_providers_delegates(self):
        router, base = self._make_router()
        assert router.available_providers() == ["anthropic", "openai"]

    def test_name(self):
        router, _ = self._make_router()
        assert router.name == "smart_router"

    def test_supports_structured(self):
        router, _ = self._make_router()
        assert router.supports_structured is True

    def test_plan_delegates_to_base(self):
        router, base = self._make_router()
        result, meta = router.plan({"goal": "add comment"}, {})
        base.plan.assert_called_once()

    def test_judge_delegates_to_base(self):
        router, base = self._make_router()
        result, meta = router.judge({"goal": "add comment"}, {})
        base.judge.assert_called_once()

    def test_force_provider_passed_through(self):
        router, base = self._make_router()
        router.plan({"goal": "test"}, {}, force_provider="openai")
        base.plan.assert_called_once_with({"goal": "test"}, {}, force_provider="openai")

    def test_circuit_breaker_stats_empty_initially(self):
        router, _ = self._make_router()
        stats = router.circuit_breaker_stats()
        assert isinstance(stats, dict)

    def test_failure_records_in_circuit_breaker(self):
        router, base = self._make_router()
        from owlmind.errors import TransientError

        base.plan.side_effect = TransientError("rate limit")
        with pytest.raises(TransientError):
            router.plan({"goal": "test"}, {})

    def test_success_resets_circuit_breaker(self):
        router, base = self._make_router()
        router._cb.record_failure("anthropic")
        base.plan.return_value = (
            {"plan": "x"},
            {"provider": "anthropic", "model": "m", "usage": {}, "latency_ms": 10},
        )
        router.plan({"goal": "fix typo"}, {}, force_provider="anthropic")
        # After success, failures should be reset — check _states directly
        # to avoid deadlock in get_stats() (which calls is_open() re-acquiring the lock)
        if "anthropic" in router._cb._states:
            assert router._cb._states["anthropic"].failures == 0

    def test_simple_goal_selects_lightweight_model(self):
        """Simple goals should prefer haiku/lightweight provider."""
        router, base = self._make_router()
        # "fix typo" is classified as simple
        router.plan({"goal": "fix typo in README"}, {})
        # Should prefer anthropic (haiku)
        call_args = base.plan.call_args
        assert call_args is not None

    def test_complex_goal_selects_powerful_model(self):
        """Complex goals should prefer opus."""
        router, base = self._make_router()
        router.plan({"goal": "refactor the entire authentication system to use JWT"}, {})
        call_args = base.plan.call_args
        assert call_args is not None

    def test_security_audit_uses_powerful_model(self):
        """High-stakes skill always uses opus."""
        router, base = self._make_router()
        router.judge({"goal": "review changes"}, {}, skill_id="security_audit")
        base.judge.assert_called()

    def test_judge_phase_prefers_opus(self):
        """Judge phase should prefer most capable model."""
        router, base = self._make_router()
        router.judge({"goal": "evaluate changes"}, {})
        base.judge.assert_called()

    def test_make_smart_router_factory(self):
        """make_smart_router wraps a base router."""
        base = MagicMock()
        smart = make_smart_router(base)
        assert isinstance(smart, SmartLLMRouter)

    def test_make_smart_router_env_config(self, monkeypatch):
        """make_smart_router reads env variables."""
        monkeypatch.setenv("OWLMIND_CIRCUIT_BREAKER_THRESHOLD", "10")
        monkeypatch.setenv("OWLMIND_CIRCUIT_BREAKER_RECOVERY_S", "120.0")
        base = MagicMock()
        smart = make_smart_router(base)
        assert smart._cb._threshold == 10
        assert smart._cb._recovery == 120.0

    def test_open_circuit_falls_back(self):
        """When anthropic circuit is open, should fall back to base router."""
        router, base = self._make_router()
        # Open anthropic circuit
        for _ in range(10):
            router._cb.record_failure("anthropic")
        # Should still call base (which tries other providers)
        router.plan({"goal": "fix typo"}, {})
        base.plan.assert_called()

    def test_plan_returns_result_and_meta(self):
        """plan() returns a (result, meta) tuple."""
        router, base = self._make_router()
        result, meta = router.plan({"goal": "add a log line"}, {})
        assert result == {"plan": "test"}
        assert meta["provider"] == "anthropic"

    def test_judge_returns_result_and_meta(self):
        """judge() returns a (result, meta) tuple."""
        router, base = self._make_router()
        result, meta = router.judge({"goal": "evaluate changes"}, {})
        assert result == {"verdict": "APPROVED"}
        assert meta["provider"] == "anthropic"

    def test_non_transient_failure_does_not_record(self):
        """Non-transient exceptions should NOT increment circuit breaker failures."""
        router, base = self._make_router()
        base.plan.side_effect = ValueError("structural error")
        with pytest.raises(ValueError):
            router.plan({"goal": "test"}, {}, force_provider="anthropic")
        # Check _states directly (get_stats() deadlocks due to re-entrant lock usage)
        if "anthropic" in router._cb._states:
            assert router._cb._states["anthropic"].failures == 0

    def test_custom_circuit_breaker_injected(self):
        """SmartLLMRouter accepts an injected CircuitBreaker."""
        base = MagicMock()
        cb = CircuitBreaker(failure_threshold=1, recovery_timeout_s=0.001)
        router = SmartLLMRouter(base, circuit_breaker=cb)
        assert router._cb is cb
