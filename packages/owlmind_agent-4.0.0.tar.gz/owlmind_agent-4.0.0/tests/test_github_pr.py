"""Tests for github_pr module — unit tests with mocked subprocess."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

from owlmind.github_pr import (
    attach_evidence,
    create_pr,
    create_pr_from_run,
    create_pr_from_session,
    is_gh_available,
)

# ---------------------------------------------------------------------------
# is_gh_available
# ---------------------------------------------------------------------------


class TestIsGhAvailable:
    def test_not_installed(self) -> None:
        with patch("owlmind.github_pr.shutil.which", return_value=None):
            assert is_gh_available() is False

    def test_installed_and_authenticated(self) -> None:
        mock_result = MagicMock()
        mock_result.returncode = 0
        with (
            patch("owlmind.github_pr.shutil.which", return_value="/usr/bin/gh"),
            patch("owlmind.github_pr.subprocess.run", return_value=mock_result),
        ):
            assert is_gh_available() is True

    def test_installed_not_authenticated(self) -> None:
        mock_result = MagicMock()
        mock_result.returncode = 1
        with (
            patch("owlmind.github_pr.shutil.which", return_value="/usr/bin/gh"),
            patch("owlmind.github_pr.subprocess.run", return_value=mock_result),
        ):
            assert is_gh_available() is False

    def test_timeout(self) -> None:
        with (
            patch("owlmind.github_pr.shutil.which", return_value="/usr/bin/gh"),
            patch(
                "owlmind.github_pr.subprocess.run",
                side_effect=subprocess.TimeoutExpired("gh", 10),
            ),
        ):
            assert is_gh_available() is False

    def test_os_error(self) -> None:
        with (
            patch("owlmind.github_pr.shutil.which", return_value="/usr/bin/gh"),
            patch("owlmind.github_pr.subprocess.run", side_effect=OSError("fail")),
        ):
            assert is_gh_available() is False


# ---------------------------------------------------------------------------
# create_pr
# ---------------------------------------------------------------------------


class TestCreatePR:
    def test_success(self) -> None:
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "https://github.com/owner/repo/pull/42\n"

        with patch("owlmind.github_pr.subprocess.run", return_value=mock_result):
            result = create_pr("feature", "My PR", "body text")

        assert result["created"] is True
        assert result["number"] == 42
        assert "github.com" in result["url"]

    def test_success_with_draft(self) -> None:
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "https://github.com/owner/repo/pull/7\n"

        with patch("owlmind.github_pr.subprocess.run", return_value=mock_result) as mock_run:
            result = create_pr("feat", "Draft PR", "body", draft=True)

        assert result["created"] is True
        args = mock_run.call_args[0][0]
        assert "--draft" in args

    def test_custom_base(self) -> None:
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "https://github.com/owner/repo/pull/1\n"

        with patch("owlmind.github_pr.subprocess.run", return_value=mock_result) as mock_run:
            create_pr("feat", "Title", "body", base="develop")

        args = mock_run.call_args[0][0]
        base_idx = args.index("--base")
        assert args[base_idx + 1] == "develop"

    def test_failure(self) -> None:
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stderr = "auth required"

        with patch("owlmind.github_pr.subprocess.run", return_value=mock_result):
            result = create_pr("feat", "Title", "body")

        assert result["created"] is False
        assert "auth required" in result["error"]

    def test_timeout_error(self) -> None:
        with patch(
            "owlmind.github_pr.subprocess.run",
            side_effect=subprocess.TimeoutExpired("gh", 60),
        ):
            result = create_pr("feat", "Title", "body")

        assert result["created"] is False
        assert "error" in result

    def test_os_error(self) -> None:
        with patch(
            "owlmind.github_pr.subprocess.run",
            side_effect=OSError("no such file"),
        ):
            result = create_pr("feat", "Title", "body")

        assert result["created"] is False
        assert "error" in result

    def test_unparseable_pr_number(self) -> None:
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "some-unexpected-output\n"

        with patch("owlmind.github_pr.subprocess.run", return_value=mock_result):
            result = create_pr("feat", "Title", "body")

        assert result["created"] is True
        assert result["number"] == 0

    def test_secret_redaction_on_error(self) -> None:
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stderr = "token=sk-abcdefghijklmnopqrstuvwxyz1234567890"

        with patch("owlmind.github_pr.subprocess.run", return_value=mock_result):
            result = create_pr("feat", "Title", "body")

        assert result["created"] is False
        assert "sk-" not in result["error"]
        assert "[REDACTED]" in result["error"]


# ---------------------------------------------------------------------------
# create_pr_from_run
# ---------------------------------------------------------------------------


class TestCreatePRFromRun:
    def test_success(self, tmp_path: Path) -> None:
        run_dir = tmp_path / "run-abc123"
        run_dir.mkdir()

        meta = {"goal": "Fix the bug", "run_id": "run-abc123", "branch": "fix-bug"}
        (run_dir / "meta.json").write_text(json.dumps(meta))

        summary = {
            "report": {
                "status": "DONE",
                "steps_completed": ["A-001"],
                "steps_failed": [],
                "diff_summary": {"files_changed": 2, "insertions": 10, "deletions": 3},
            },
            "summary": {"state": "DONE"},
        }
        (run_dir / "summary.json").write_text(json.dumps(summary))

        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "https://github.com/owner/repo/pull/99\n"

        with patch("owlmind.github_pr.subprocess.run", return_value=mock_result) as mock_run:
            result = create_pr_from_run("run-abc123", runs_dir=tmp_path)

        assert result["created"] is True
        assert result["number"] == 99

        # Verify the PR title contains the goal
        args = mock_run.call_args[0][0]
        title_idx = args.index("--title")
        assert "Fix the bug" in args[title_idx + 1]

    def test_meta_not_found(self, tmp_path: Path) -> None:
        result = create_pr_from_run("nonexistent", runs_dir=tmp_path)
        assert result["created"] is False
        assert "meta.json not found" in result["error"]

    def test_invalid_meta_json(self, tmp_path: Path) -> None:
        run_dir = tmp_path / "run-bad"
        run_dir.mkdir()
        (run_dir / "meta.json").write_text("not json")

        result = create_pr_from_run("run-bad", runs_dir=tmp_path)
        assert result["created"] is False

    def test_no_summary_json(self, tmp_path: Path) -> None:
        run_dir = tmp_path / "run-nosummary"
        run_dir.mkdir()

        meta = {"goal": "Do something", "run_id": "run-nosummary", "branch": "do-something"}
        (run_dir / "meta.json").write_text(json.dumps(meta))

        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "https://github.com/owner/repo/pull/5\n"

        with patch("owlmind.github_pr.subprocess.run", return_value=mock_result):
            result = create_pr_from_run("run-nosummary", runs_dir=tmp_path)

        assert result["created"] is True

    def test_branch_from_meta(self, tmp_path: Path) -> None:
        run_dir = tmp_path / "run-branch"
        run_dir.mkdir()

        meta = {"goal": "Add feature", "run_id": "run-branch", "branch": "feat/custom"}
        (run_dir / "meta.json").write_text(json.dumps(meta))

        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "https://github.com/owner/repo/pull/10\n"

        with patch("owlmind.github_pr.subprocess.run", return_value=mock_result) as mock_run:
            create_pr_from_run("run-branch", runs_dir=tmp_path)

        args = mock_run.call_args[0][0]
        head_idx = args.index("--head")
        assert args[head_idx + 1] == "feat/custom"

    def test_long_title_truncated(self, tmp_path: Path) -> None:
        run_dir = tmp_path / "run-long"
        run_dir.mkdir()

        meta = {"goal": "A" * 200, "run_id": "run-long", "branch": "long"}
        (run_dir / "meta.json").write_text(json.dumps(meta))

        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "https://github.com/owner/repo/pull/1\n"

        with patch("owlmind.github_pr.subprocess.run", return_value=mock_result) as mock_run:
            create_pr_from_run("run-long", runs_dir=tmp_path)

        args = mock_run.call_args[0][0]
        title_idx = args.index("--title")
        assert len(args[title_idx + 1]) <= 120


# ---------------------------------------------------------------------------
# create_pr_from_session
# ---------------------------------------------------------------------------


class TestCreatePRFromSession:
    def test_success(self, tmp_path: Path) -> None:
        sess_dir = tmp_path / "session-xyz"
        sess_dir.mkdir()

        data = {
            "session_id": "session-xyz",
            "status": "DONE",
            "goals": [
                {"id": "G-1", "goal": "Implement auth"},
                {"id": "G-2", "goal": "Write tests"},
            ],
            "runs": [
                {"goal_id": "G-1", "run_id": "run-1", "status": "done"},
                {"goal_id": "G-2", "run_id": "run-2", "status": "done"},
            ],
        }
        (sess_dir / "session_meta.json").write_text(json.dumps(data))

        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "https://github.com/owner/repo/pull/50\n"

        with patch("owlmind.github_pr.subprocess.run", return_value=mock_result) as mock_run:
            result = create_pr_from_session("session-xyz", sessions_dir=tmp_path)

        assert result["created"] is True
        assert result["number"] == 50

        # Verify body contains completed goals
        args = mock_run.call_args[0][0]
        body_idx = args.index("--body")
        body = args[body_idx + 1]
        assert "Implement auth" in body
        assert "Write tests" in body

    def test_session_not_found(self, tmp_path: Path) -> None:
        result = create_pr_from_session("nonexistent", sessions_dir=tmp_path)
        assert result["created"] is False
        assert "session_meta.json not found" in result["error"]

    def test_invalid_session_json(self, tmp_path: Path) -> None:
        sess_dir = tmp_path / "session-bad"
        sess_dir.mkdir()
        (sess_dir / "session_meta.json").write_text("{bad json")

        result = create_pr_from_session("session-bad", sessions_dir=tmp_path)
        assert result["created"] is False

    def test_with_failed_goals(self, tmp_path: Path) -> None:
        sess_dir = tmp_path / "session-mixed"
        sess_dir.mkdir()

        data = {
            "session_id": "session-mixed",
            "status": "FAILED",
            "goals": [
                {"id": "G-1", "goal": "Good goal"},
                {"id": "G-2", "goal": "Bad goal"},
            ],
            "runs": [
                {"goal_id": "G-1", "run_id": "run-1", "status": "done"},
                {"goal_id": "G-2", "run_id": "run-2", "status": "failed"},
            ],
        }
        (sess_dir / "session_meta.json").write_text(json.dumps(data))

        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "https://github.com/owner/repo/pull/11\n"

        with patch("owlmind.github_pr.subprocess.run", return_value=mock_result) as mock_run:
            result = create_pr_from_session("session-mixed", sessions_dir=tmp_path)

        assert result["created"] is True
        args = mock_run.call_args[0][0]
        body_idx = args.index("--body")
        body = args[body_idx + 1]
        assert "Completed goals" in body
        assert "Failed goals" in body

    def test_empty_goals(self, tmp_path: Path) -> None:
        sess_dir = tmp_path / "session-empty"
        sess_dir.mkdir()

        data = {
            "session_id": "session-empty",
            "status": "DONE",
            "goals": [],
            "runs": [],
        }
        (sess_dir / "session_meta.json").write_text(json.dumps(data))

        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "https://github.com/owner/repo/pull/1\n"

        with patch("owlmind.github_pr.subprocess.run", return_value=mock_result):
            result = create_pr_from_session("session-empty", sessions_dir=tmp_path)

        assert result["created"] is True

    def test_long_session_title_truncated(self, tmp_path: Path) -> None:
        sess_dir = tmp_path / "session-long"
        sess_dir.mkdir()

        data = {
            "session_id": "session-long",
            "status": "DONE",
            "goals": [{"id": "G-1", "goal": "X" * 200}],
            "runs": [],
        }
        (sess_dir / "session_meta.json").write_text(json.dumps(data))

        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "https://github.com/owner/repo/pull/1\n"

        with patch("owlmind.github_pr.subprocess.run", return_value=mock_result) as mock_run:
            create_pr_from_session("session-long", sessions_dir=tmp_path)

        args = mock_run.call_args[0][0]
        title_idx = args.index("--title")
        assert len(args[title_idx + 1]) <= 120


# ---------------------------------------------------------------------------
# attach_evidence
# ---------------------------------------------------------------------------


class TestAttachEvidence:
    def test_success(self) -> None:
        mock_result = MagicMock()
        mock_result.returncode = 0

        with patch("owlmind.github_pr.subprocess.run", return_value=mock_result):
            result = attach_evidence(42, "Evidence comment")

        assert result["commented"] is True

    def test_failure(self) -> None:
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stderr = "not found"

        with patch("owlmind.github_pr.subprocess.run", return_value=mock_result):
            result = attach_evidence(999, "Comment")

        assert result["commented"] is False
        assert "not found" in result["error"]

    def test_timeout(self) -> None:
        with patch(
            "owlmind.github_pr.subprocess.run",
            side_effect=subprocess.TimeoutExpired("gh", 30),
        ):
            result = attach_evidence(1, "Comment")

        assert result["commented"] is False

    def test_os_error(self) -> None:
        with patch(
            "owlmind.github_pr.subprocess.run",
            side_effect=OSError("fail"),
        ):
            result = attach_evidence(1, "Comment")

        assert result["commented"] is False

    def test_secret_redaction(self) -> None:
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stderr = "token=ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890extra"

        with patch("owlmind.github_pr.subprocess.run", return_value=mock_result):
            result = attach_evidence(1, "Comment")

        assert result["commented"] is False
        assert "ghp_" not in result["error"]
        assert "[REDACTED]" in result["error"]

    def test_passes_correct_args(self) -> None:
        mock_result = MagicMock()
        mock_result.returncode = 0

        with patch("owlmind.github_pr.subprocess.run", return_value=mock_result) as mock_run:
            attach_evidence(55, "My evidence")

        args = mock_run.call_args[0][0]
        assert args == ["gh", "pr", "comment", "55", "--body", "My evidence"]


class TestCreatePrFromRunFailedSteps:
    """Line 152: steps_fail non-empty → body part appended."""

    def test_failed_steps_in_body(self, tmp_path: Path) -> None:
        run_dir = tmp_path / "run-fail"
        run_dir.mkdir()
        (run_dir / "meta.json").write_text(
            json.dumps({"goal": "Fix bug", "run_id": "run-fail", "branch": "fix-bug"})
        )
        (run_dir / "summary.json").write_text(
            json.dumps(
                {
                    "report": {
                        "status": "DONE",
                        "steps_completed": ["Step A"],
                        "steps_failed": ["Step B", "Step C"],
                    },
                }
            )
        )
        mock_result = MagicMock(returncode=0, stdout="https://github.com/org/repo/pull/10\n")
        with patch("owlmind.github_pr.subprocess.run", return_value=mock_result) as mock_run:
            result = create_pr_from_run("run-fail", runs_dir=tmp_path)
        assert result["created"] is True
        args = mock_run.call_args[0][0]
        body_idx = args.index("--body")
        assert "Steps failed" in args[body_idx + 1]


class TestCreatePrFromRunOsError:
    """Lines 161-162: JSONDecodeError reading summary.json → warning logged, PR still created."""

    def test_oserror_on_summary(self, tmp_path: Path) -> None:
        run_dir = tmp_path / "run-oserr"
        run_dir.mkdir()
        (run_dir / "meta.json").write_text(
            json.dumps({"goal": "Do something", "run_id": "run-oserr", "branch": "do-something"})
        )
        # Invalid JSON triggers JSONDecodeError (same except clause as OSError at line 161)
        (run_dir / "summary.json").write_text("{not valid json")
        mock_result = MagicMock(returncode=0, stdout="https://github.com/org/repo/pull/11\n")
        with patch("owlmind.github_pr.subprocess.run", return_value=mock_result):
            result = create_pr_from_run("run-oserr", runs_dir=tmp_path)
        assert result["created"] is True
