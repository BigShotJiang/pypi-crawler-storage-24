"""Tests for AutoPilot — full autonomous loop. NO network calls."""

from __future__ import annotations

import contextlib
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

from owlmind.agent.schemas import CycleState
from owlmind.autopilot import (
    AutoPilotConfig,
    AutoPilotResult,
    _emit,
    _try_judge,
    _try_planner,
    _try_worker,
    run,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _make_policies(tmp_path: Path) -> Path:
    """Create minimal policies directory."""
    policies_dir = tmp_path / "policies"
    policies_dir.mkdir(exist_ok=True)
    (policies_dir / "allowlist.yaml").write_text('allowed_commands:\n  - "^echo "\n  - "^pytest"\n')
    (policies_dir / "policy.yaml").write_text('forbidden_patterns:\n  - "rm -rf"\n')
    return policies_dir


def _make_config(
    tmp_path: Path,
    *,
    goal: str = "Test goal",
    use_llm: str = "none",
    use_worker: str = "none",
    max_steps: int = 10,
    run_id: str | None = None,
    auto_export: bool = False,
    interval: float = 0.01,
) -> AutoPilotConfig:
    """Create AutoPilotConfig for testing."""
    policies_dir = _make_policies(tmp_path)
    return AutoPilotConfig(
        goal=goal,
        workspace=str(tmp_path),
        use_llm=use_llm,
        use_worker=use_worker,
        max_steps=max_steps,
        interval=interval,
        auto_export=auto_export,
        run_id=run_id,
        policies_dir=policies_dir,
        runs_dir=tmp_path / "runs",
        ledger_dir=tmp_path / "ledger",
    )


class FakeLLMDriver:
    """Fake LLM driver that returns planner/judge responses."""

    def __init__(
        self,
        planner_response: dict[str, Any] | None = None,
        judge_response: dict[str, Any] | None = None,
    ) -> None:
        self._planner_response = planner_response or {}
        self._judge_response = judge_response or {}
        self.plan_calls: list[dict[str, Any]] = []
        self.judge_calls: list[dict[str, Any]] = []

    @property
    def name(self) -> str:
        return "fake"

    @property
    def supports_structured(self) -> bool:
        return True

    def plan(
        self,
        planner_request: dict[str, Any],
        schema: dict[str, Any],
        **kwargs: Any,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        self.plan_calls.append(planner_request)
        meta = {
            "provider": "fake",
            "model": "fake-model",
            "latency_ms": 10,
            "usage": {"input_tokens": 100, "output_tokens": 50, "total_tokens": 150},
        }
        return self._planner_response, meta

    def judge(
        self,
        judge_request: dict[str, Any],
        schema: dict[str, Any],
        **kwargs: Any,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        self.judge_calls.append(judge_request)
        meta = {
            "provider": "fake",
            "model": "fake-model",
            "latency_ms": 10,
            "usage": {"input_tokens": 100, "output_tokens": 50, "total_tokens": 150},
        }
        return self._judge_response, meta


# ---------------------------------------------------------------------------
# Tests: AutoPilotConfig / AutoPilotResult dataclasses
# ---------------------------------------------------------------------------


class TestAutoPilotConfig:
    def test_defaults(self) -> None:
        cfg = AutoPilotConfig()
        assert cfg.goal == ""
        assert cfg.use_llm == "both"
        assert cfg.use_worker == "claude_cli"
        assert cfg.max_steps == 50
        assert cfg.auto_export is True

    def test_custom_values(self) -> None:
        cfg = AutoPilotConfig(
            goal="My goal",
            use_llm="planner",
            max_steps=10,
            auto_export=False,
        )
        assert cfg.goal == "My goal"
        assert cfg.use_llm == "planner"
        assert cfg.max_steps == 10
        assert cfg.auto_export is False


class TestAutoPilotResult:
    def test_defaults(self) -> None:
        r = AutoPilotResult()
        assert r.run_id == ""
        assert r.final_state == ""
        assert r.steps == 0
        assert r.export_path is None
        assert r.events == []


# ---------------------------------------------------------------------------
# Tests: run() — happy path (no LLM, no worker)
# ---------------------------------------------------------------------------


class TestAutoRunNoLLM:
    """Test autopilot with use_llm=none and use_worker=none.

    The loop starts a cycle, then immediately hits 'Waiting' with no handler
    and stops.
    """

    def test_starts_and_blocks_on_planner_wait(self, tmp_path: Path) -> None:
        config = _make_config(tmp_path, use_llm="none", use_worker="none")
        result = run(config)

        assert result.run_id.startswith("cycle-")
        assert result.final_state == CycleState.STARTED_WAIT_PLANNER.value
        assert "waiting" in result.stop_reason.lower()
        assert result.steps >= 1

    def test_max_steps_respected(self, tmp_path: Path) -> None:
        config = _make_config(tmp_path, max_steps=1)
        result = run(config)
        assert result.steps <= 2  # may stop after step 1 or 2

    def test_on_event_callback_fires(self, tmp_path: Path) -> None:
        events_log: list[tuple[str, dict[str, Any]]] = []

        def on_event(name: str, data: dict[str, Any]) -> None:
            events_log.append((name, data))

        config = _make_config(tmp_path)
        config.on_event = on_event
        run(config)

        event_names = [e[0] for e in events_log]
        assert "started" in event_names
        assert "finished" in event_names


# ---------------------------------------------------------------------------
# Tests: run() — with LLM (mocked)
# ---------------------------------------------------------------------------


class TestAutoRunWithLLM:
    """Test autopilot with fake LLM that drives the full cycle."""

    def test_full_cycle_planner_judge(self, tmp_path: Path) -> None:
        """Run planner → submit → worker (manual fake) → judge → DONE."""
        from owlmind.agent.cycle import CycleManager
        from owlmind.budget import BudgetGovernor
        from owlmind.config import BudgetConfig, PricingConfig
        from owlmind.evidence import EvidenceStore
        from owlmind.ledger import UsageLedger
        from owlmind.policy import PolicyEngine

        policies_dir = _make_policies(tmp_path)
        policy = PolicyEngine.from_directory(policies_dir)
        evidence = EvidenceStore(tmp_path / "runs")
        ledger = UsageLedger(tmp_path / "ledger")
        governor = BudgetGovernor(BudgetConfig(), PricingConfig(), ledger)

        planner_resp = {
            "run_id": "x",
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Echo hello",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        judge_resp = {
            "run_id": "x",
            "iteration": 1,
            "verdict": "APPROVED",
            "findings": ["All good"],
            "score": 9,
            "next_worker_instructions": "",
        }

        fake_llm = FakeLLMDriver(
            planner_response=planner_resp,
            judge_response=judge_resp,
        )

        mgr = CycleManager(
            evidence=evidence,
            policy=policy,
            policies_dir=policies_dir,
            llm_driver=fake_llm,
            budget_governor=governor,
            ledger=ledger,
        )

        # Start cycle manually
        meta = mgr.start(goal="Full cycle test", workspace=str(tmp_path))
        run_id = meta.run_id

        # Fix run_id in responses
        planner_resp["run_id"] = run_id
        judge_resp["run_id"] = run_id

        # Run planner
        mgr.run_planner_llm(run_id)

        # Submit planner (auto-advance would do this via next())
        mgr.submit_planner(run_id)

        # Fake worker report
        import json

        inbox = tmp_path / "runs" / run_id / "inbox"
        worker_report = {
            "run_id": run_id,
            "iteration": 1,
            "done_summary": ["Echoed hello"],
            "files_changed": [],
            "commands_run": [{"cmd": "echo ok", "exit_code": 0, "output": "ok"}],
            "error": None,
        }
        (inbox / "worker_report.json").write_text(json.dumps(worker_report))

        # Submit worker
        mgr.submit_worker(run_id)

        # Run judge
        mgr.run_judge_llm(run_id)

        # Submit judge
        final_meta = mgr.submit_judge(run_id)

        assert final_meta.state == CycleState.DONE

    def test_planner_llm_called_in_autopilot(self, tmp_path: Path) -> None:
        """Verify that autopilot calls planner LLM when use_llm='planner'."""
        planner_resp = {
            "run_id": "x",
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Do something",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        fake_llm = FakeLLMDriver(planner_response=planner_resp)

        config = _make_config(
            tmp_path,
            use_llm="planner",
            use_worker="none",
            max_steps=5,
        )

        # Patch build_llm_router to return our fake
        with patch("owlmind.llm.factory.build_llm_router", return_value=fake_llm):
            result = run(config)

        # Planner should have been called at least once
        assert len(fake_llm.plan_calls) >= 1
        assert result.run_id.startswith("cycle-")


# ---------------------------------------------------------------------------
# Tests: run() — approval blocking
# ---------------------------------------------------------------------------


class TestAutoRunApprovalBlock:
    def test_blocks_on_approval(self, tmp_path: Path) -> None:
        """If a budget override triggers WAIT_APPROVAL, autopilot stops."""
        from owlmind.agent.cycle import CycleManager
        from owlmind.approval import create_approval
        from owlmind.budget import BudgetGovernor
        from owlmind.config import BudgetConfig, PricingConfig
        from owlmind.evidence import EvidenceStore
        from owlmind.ledger import UsageLedger
        from owlmind.policy import PolicyEngine

        policies_dir = _make_policies(tmp_path)
        policy = PolicyEngine.from_directory(policies_dir)
        evidence = EvidenceStore(tmp_path / "runs")
        ledger = UsageLedger(tmp_path / "ledger")
        governor = BudgetGovernor(BudgetConfig(), PricingConfig(), ledger)

        mgr = CycleManager(
            evidence=evidence,
            policy=policy,
            policies_dir=policies_dir,
            budget_governor=governor,
            ledger=ledger,
        )

        meta = mgr.start(goal="Approval test", workspace=str(tmp_path))
        run_id = meta.run_id

        # Force an approval state
        create_approval(mgr.meta_store, run_id, "Budget override test")

        # Now run autopilot with this run_id (resume mode)
        config = _make_config(
            tmp_path,
            run_id=run_id,
            use_llm="none",
            use_worker="none",
            max_steps=5,
        )
        # Point to the same runs dir
        config.runs_dir = tmp_path / "runs"
        config.policies_dir = policies_dir

        result = run(config)

        assert result.final_state == CycleState.WAIT_APPROVAL.value
        assert "blocked" in result.stop_reason.lower()


# ---------------------------------------------------------------------------
# Tests: run() — resume mode
# ---------------------------------------------------------------------------


class TestAutoRunResume:
    def test_resume_existing_run(self, tmp_path: Path) -> None:
        """Can resume an interrupted run by passing run_id."""
        from owlmind.agent.cycle import CycleManager
        from owlmind.budget import BudgetGovernor
        from owlmind.config import BudgetConfig, PricingConfig
        from owlmind.evidence import EvidenceStore
        from owlmind.ledger import UsageLedger
        from owlmind.policy import PolicyEngine

        policies_dir = _make_policies(tmp_path)
        policy = PolicyEngine.from_directory(policies_dir)
        evidence = EvidenceStore(tmp_path / "runs")
        ledger = UsageLedger(tmp_path / "ledger")
        governor = BudgetGovernor(BudgetConfig(), PricingConfig(), ledger)

        mgr = CycleManager(
            evidence=evidence,
            policy=policy,
            policies_dir=policies_dir,
            budget_governor=governor,
            ledger=ledger,
        )

        # Start a run manually
        meta = mgr.start(goal="Resume test", workspace=str(tmp_path))
        run_id = meta.run_id

        # Resume via autopilot
        config = _make_config(
            tmp_path,
            run_id=run_id,
            use_llm="none",
            use_worker="none",
            max_steps=3,
        )
        config.runs_dir = tmp_path / "runs"
        config.policies_dir = policies_dir

        result = run(config)

        assert result.run_id == run_id
        assert result.final_state == CycleState.STARTED_WAIT_PLANNER.value


# ---------------------------------------------------------------------------
# Tests: run() — auto-export on DONE
# ---------------------------------------------------------------------------


class TestAutoExport:
    def test_auto_export_on_done(self, tmp_path: Path) -> None:
        """When cycle reaches DONE and auto_export=True, a zip is created."""
        from owlmind.agent.cycle import CycleManager
        from owlmind.budget import BudgetGovernor
        from owlmind.config import BudgetConfig, PricingConfig
        from owlmind.evidence import EvidenceStore
        from owlmind.ledger import UsageLedger
        from owlmind.policy import PolicyEngine

        policies_dir = _make_policies(tmp_path)
        policy = PolicyEngine.from_directory(policies_dir)
        evidence = EvidenceStore(tmp_path / "runs")
        ledger = UsageLedger(tmp_path / "ledger")
        governor = BudgetGovernor(BudgetConfig(), PricingConfig(), ledger)

        planner_resp = {
            "run_id": "x",
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Echo hello",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        judge_resp = {
            "run_id": "x",
            "iteration": 1,
            "verdict": "APPROVED",
            "findings": ["All good"],
            "score": 9,
            "next_worker_instructions": "",
        }

        fake_llm = FakeLLMDriver(
            planner_response=planner_resp,
            judge_response=judge_resp,
        )

        mgr = CycleManager(
            evidence=evidence,
            policy=policy,
            policies_dir=policies_dir,
            llm_driver=fake_llm,
            budget_governor=governor,
            ledger=ledger,
        )

        # Drive to DONE manually
        import json

        meta = mgr.start(goal="Export test", workspace=str(tmp_path))
        run_id = meta.run_id
        planner_resp["run_id"] = run_id
        judge_resp["run_id"] = run_id

        mgr.run_planner_llm(run_id)
        mgr.submit_planner(run_id)

        inbox = tmp_path / "runs" / run_id / "inbox"
        worker_report = {
            "run_id": run_id,
            "iteration": 1,
            "done_summary": ["Done"],
            "files_changed": [],
            "commands_run": [{"cmd": "echo ok", "exit_code": 0, "output": "ok"}],
            "error": None,
        }
        (inbox / "worker_report.json").write_text(json.dumps(worker_report))
        mgr.submit_worker(run_id)
        mgr.run_judge_llm(run_id)
        mgr.submit_judge(run_id)

        # Verify DONE
        final_meta = mgr.status(run_id)
        assert final_meta.state == CycleState.DONE

        # Now test the export part directly
        export_dir = tmp_path / "exports"
        export_dir.mkdir()
        zip_path = mgr.export(run_id, out_path=export_dir / f"export_{run_id}.zip")
        assert zip_path.exists()
        assert zip_path.stat().st_size > 0


# ---------------------------------------------------------------------------
# Tests: event callback
# ---------------------------------------------------------------------------


class TestEventCallback:
    def test_callback_exception_does_not_crash(self, tmp_path: Path) -> None:
        """on_event callback raising should not crash autopilot."""

        def bad_callback(name: str, data: dict[str, Any]) -> None:
            msg = "Intentional error"
            raise RuntimeError(msg)

        config = _make_config(tmp_path, use_llm="none", use_worker="none")
        config.on_event = bad_callback

        # Should not raise
        result = run(config)
        assert result.run_id.startswith("cycle-")


# ---------------------------------------------------------------------------
# Helpers for mock-based tests
# ---------------------------------------------------------------------------


def _make_base_meta(state: CycleState = CycleState.DONE) -> MagicMock:
    """Create a mock CycleMeta with the given state."""
    m = MagicMock()
    m.run_id = "run-test"
    m.state = state
    m.iteration = 1
    m.hard_fail_reasons = []
    return m


def _make_mock_mgr(state: CycleState = CycleState.DONE) -> MagicMock:
    """Create a fully configured mock CycleManager."""
    mock_mgr = MagicMock()
    mock_mgr.start.return_value = _make_base_meta(state)
    mock_mgr.load.return_value = _make_base_meta(state)
    mock_mgr.next.return_value = (_make_base_meta(state), "Done!")
    mock_mgr.status.return_value = _make_base_meta(state)
    return mock_mgr


# ---------------------------------------------------------------------------
# Tests: _emit helper
# ---------------------------------------------------------------------------


class TestEmit:
    def test_emit_fires_callback(self) -> None:
        events: list[tuple[str, dict[str, Any]]] = []
        config = AutoPilotConfig(goal="test", on_event=lambda n, d: events.append((n, d)))
        _emit(config, "my_event", {"key": "value"})
        assert len(events) == 1
        assert events[0] == ("my_event", {"key": "value"})

    def test_emit_no_callback(self) -> None:
        config = AutoPilotConfig(goal="test", on_event=None)
        # Must not raise
        _emit(config, "my_event", {})

    def test_emit_swallows_callback_exception(self) -> None:
        def bad(name: str, data: dict[str, Any]) -> None:
            raise ValueError("boom")

        config = AutoPilotConfig(goal="test", on_event=bad)
        # Must not raise
        _emit(config, "my_event", {})


# ---------------------------------------------------------------------------
# Tests: _try_planner helper
# ---------------------------------------------------------------------------


class TestTryPlanner:
    def test_success_returns_true_and_emits_events(self) -> None:
        events: list[str] = []
        config = AutoPilotConfig(
            goal="test",
            on_event=lambda n, d: events.append(n),
        )
        mock_mgr = MagicMock()
        mock_mgr.run_planner_llm.return_value = None

        result = _try_planner(mock_mgr, "run-123", config, step=1)

        assert result is True
        mock_mgr.run_planner_llm.assert_called_once_with("run-123")
        assert "llm_planner_start" in events
        assert "llm_planner_done" in events

    def test_exception_returns_false_and_emits_error(self) -> None:
        events: list[str] = []
        config = AutoPilotConfig(
            goal="test",
            on_event=lambda n, d: events.append(n),
        )
        mock_mgr = MagicMock()
        mock_mgr.run_planner_llm.side_effect = RuntimeError("planner failed")

        result = _try_planner(mock_mgr, "run-123", config, step=2)

        assert result is False
        assert "llm_planner_start" in events
        assert "llm_planner_error" in events
        assert "llm_planner_done" not in events


# ---------------------------------------------------------------------------
# Tests: _try_judge helper
# ---------------------------------------------------------------------------


class TestTryJudge:
    def test_success_returns_true_and_emits_events(self) -> None:
        events: list[str] = []
        config = AutoPilotConfig(
            goal="test",
            on_event=lambda n, d: events.append(n),
        )
        mock_mgr = MagicMock()
        mock_mgr.run_judge_llm.return_value = None

        result = _try_judge(mock_mgr, "run-abc", config, step=3)

        assert result is True
        mock_mgr.run_judge_llm.assert_called_once_with("run-abc")
        assert "llm_judge_start" in events
        assert "llm_judge_done" in events

    def test_exception_returns_false_and_emits_error(self) -> None:
        events: list[str] = []
        config = AutoPilotConfig(
            goal="test",
            on_event=lambda n, d: events.append(n),
        )
        mock_mgr = MagicMock()
        mock_mgr.run_judge_llm.side_effect = RuntimeError("judge failed")

        result = _try_judge(mock_mgr, "run-abc", config, step=4)

        assert result is False
        assert "llm_judge_start" in events
        assert "llm_judge_error" in events
        assert "llm_judge_done" not in events


# ---------------------------------------------------------------------------
# Tests: _try_worker helper
# ---------------------------------------------------------------------------


class TestTryWorker:
    def test_worker_success_returns_true_false(self) -> None:
        events: list[str] = []
        config = AutoPilotConfig(
            goal="test",
            auto_approve=False,
            on_event=lambda n, d: events.append(n),
        )
        mock_mgr = MagicMock()
        worker_meta = _make_base_meta(CycleState.WAIT_JUDGE)
        mock_mgr.run_worker_cli.return_value = (worker_meta, "Worker done")

        ok, blocked = _try_worker(mock_mgr, "run-xyz", config, step=1)

        assert ok is True
        assert blocked is False
        assert "worker_start" in events
        assert "worker_done" in events

    def test_worker_wait_approval_no_auto_approve_returns_false_true(self) -> None:
        events: list[str] = []
        config = AutoPilotConfig(
            goal="test",
            auto_approve=False,
            on_event=lambda n, d: events.append(n),
        )
        mock_mgr = MagicMock()
        approval_meta = _make_base_meta(CycleState.WAIT_APPROVAL)
        mock_mgr.run_worker_cli.return_value = (approval_meta, "Needs approval")

        ok, blocked = _try_worker(mock_mgr, "run-xyz", config, step=2)

        assert ok is False
        assert blocked is True
        assert "worker_approval_needed" in events

    def test_worker_exception_returns_false_false(self) -> None:
        events: list[str] = []
        config = AutoPilotConfig(
            goal="test",
            auto_approve=False,
            on_event=lambda n, d: events.append(n),
        )
        mock_mgr = MagicMock()
        mock_mgr.run_worker_cli.side_effect = RuntimeError("worker crashed")

        ok, blocked = _try_worker(mock_mgr, "run-xyz", config, step=3)

        assert ok is False
        assert blocked is False
        assert "worker_start" in events
        assert "worker_error" in events


# ---------------------------------------------------------------------------
# Tests: run() with mocked CycleManager — covers uncovered scenarios
# ---------------------------------------------------------------------------


class TestRunWithMockedManager:
    """Tests that use patch() to fully mock CycleManager and related deps."""

    def _base_patches(self) -> contextlib.ExitStack:
        """Return an ExitStack with all standard patches applied."""
        stack = contextlib.ExitStack()
        stack.enter_context(patch("owlmind.config.OwlMindConfig"))
        stack.enter_context(patch("owlmind.policy.PolicyEngine"))
        stack.enter_context(patch("owlmind.evidence.EvidenceStore"))
        stack.enter_context(patch("owlmind.budget.BudgetGovernor"))
        stack.enter_context(patch("owlmind.ledger.UsageLedger"))
        stack.enter_context(patch("owlmind.memory.store.MemoryStore"))
        return stack

    def test_next_raises_exception_sets_stop_reason(self) -> None:
        mock_mgr = _make_mock_mgr(CycleState.DONE)
        mock_mgr.start.return_value = _make_base_meta(CycleState.DONE)
        mock_mgr.next.side_effect = RuntimeError("cycle exploded")

        with self._base_patches() as stack:
            stack.enter_context(patch("owlmind.agent.cycle.CycleManager", return_value=mock_mgr))
            config = AutoPilotConfig(
                goal="test",
                use_llm="none",
                use_worker="none",
                auto_export=False,
                enable_heartbeat=False,
                interval=0,
            )
            result = run(config)

        assert "next() error" in result.stop_reason
        assert "cycle exploded" in result.stop_reason

    def test_wait_approval_state_from_next_sets_blocked(self) -> None:
        mock_mgr = _make_mock_mgr()
        approval_meta = _make_base_meta(CycleState.WAIT_APPROVAL)
        mock_mgr.start.return_value = _make_base_meta(CycleState.WAIT_APPROVAL)
        mock_mgr.next.return_value = (approval_meta, "Approval required")
        mock_mgr.status.return_value = approval_meta

        with self._base_patches() as stack:
            stack.enter_context(patch("owlmind.agent.cycle.CycleManager", return_value=mock_mgr))
            config = AutoPilotConfig(
                goal="test",
                use_llm="none",
                use_worker="none",
                auto_export=False,
                enable_heartbeat=False,
                interval=0,
            )
            result = run(config)

        assert "blocked" in result.stop_reason
        assert result.final_state == CycleState.WAIT_APPROVAL.value

    def test_started_wait_planner_no_llm_handler_stops(self) -> None:
        mock_mgr = _make_mock_mgr()
        wait_meta = _make_base_meta(CycleState.STARTED_WAIT_PLANNER)
        mock_mgr.start.return_value = _make_base_meta(CycleState.STARTED_WAIT_PLANNER)
        mock_mgr.next.return_value = (wait_meta, "Waiting for planner")
        mock_mgr.status.return_value = wait_meta

        with self._base_patches() as stack:
            stack.enter_context(patch("owlmind.agent.cycle.CycleManager", return_value=mock_mgr))
            config = AutoPilotConfig(
                goal="test",
                use_llm="none",
                use_worker="none",
                auto_export=False,
                enable_heartbeat=False,
                interval=0,
            )
            result = run(config)

        assert "waiting" in result.stop_reason
        assert "no handler" in result.stop_reason

    def test_status_raises_in_finalize_falls_back_to_meta_state(self) -> None:
        mock_mgr = _make_mock_mgr()
        done_meta = _make_base_meta(CycleState.DONE)
        mock_mgr.start.return_value = _make_base_meta(CycleState.DONE)
        mock_mgr.next.return_value = (done_meta, "Done!")
        mock_mgr.status.side_effect = RuntimeError("status unavailable")

        with self._base_patches() as stack:
            stack.enter_context(patch("owlmind.agent.cycle.CycleManager", return_value=mock_mgr))
            config = AutoPilotConfig(
                goal="test",
                use_llm="none",
                use_worker="none",
                auto_export=False,
                enable_heartbeat=False,
                interval=0,
            )
            result = run(config)

        # Falls back to meta.state.value from the loop's last meta
        assert result.final_state == CycleState.DONE.value

    def test_export_raises_does_not_crash_and_export_path_none(self) -> None:
        mock_mgr = _make_mock_mgr()
        done_meta = _make_base_meta(CycleState.DONE)
        mock_mgr.start.return_value = _make_base_meta(CycleState.DONE)
        mock_mgr.next.return_value = (done_meta, "Done!")
        mock_mgr.status.return_value = done_meta
        mock_mgr.export.side_effect = RuntimeError("export failed")

        with self._base_patches() as stack:
            stack.enter_context(patch("owlmind.agent.cycle.CycleManager", return_value=mock_mgr))
            config = AutoPilotConfig(
                goal="test",
                use_llm="none",
                use_worker="none",
                auto_export=True,  # triggers export path
                enable_heartbeat=False,
                interval=0,
            )
            result = run(config)

        assert result.export_path is None

    def test_evidence_read_events_called_and_populates_result(self) -> None:
        mock_mgr = _make_mock_mgr()
        done_meta = _make_base_meta(CycleState.DONE)
        mock_mgr.start.return_value = _make_base_meta(CycleState.DONE)
        mock_mgr.next.return_value = (done_meta, "Done!")
        mock_mgr.status.return_value = done_meta

        mock_evidence = MagicMock()
        mock_evidence.read_events.return_value = [{"type": "step", "data": {}}]

        with self._base_patches() as stack:
            stack.enter_context(patch("owlmind.agent.cycle.CycleManager", return_value=mock_mgr))
            # Patch EvidenceStore to return our mock instance
            stack.enter_context(patch("owlmind.evidence.EvidenceStore", return_value=mock_evidence))
            config = AutoPilotConfig(
                goal="test",
                use_llm="none",
                use_worker="none",
                auto_export=False,
                enable_heartbeat=False,
                interval=0,
            )
            result = run(config)

        mock_evidence.read_events.assert_called_once()
        assert result.events == [{"type": "step", "data": {}}]

    def test_use_worker_claude_cli_instantiates_driver(self) -> None:
        mock_mgr = _make_mock_mgr()
        done_meta = _make_base_meta(CycleState.DONE)
        mock_mgr.start.return_value = _make_base_meta(CycleState.DONE)
        mock_mgr.next.return_value = (done_meta, "Done!")
        mock_mgr.status.return_value = done_meta
        mock_driver = MagicMock()

        with self._base_patches() as stack:
            stack.enter_context(patch("owlmind.agent.cycle.CycleManager", return_value=mock_mgr))
            mock_driver_cls = stack.enter_context(
                patch(
                    "owlmind.worker.claude_cli_driver.ClaudeCLIDriver",
                    return_value=mock_driver,
                )
            )
            config = AutoPilotConfig(
                goal="test",
                use_llm="none",
                use_worker="claude_cli",
                auto_export=False,
                enable_heartbeat=False,
                interval=0,
            )
            result = run(config)

        mock_driver_cls.assert_called_once()
        assert result.run_id != ""

    def test_enable_heartbeat_creates_engine_and_ticks(self) -> None:
        mock_mgr = _make_mock_mgr()
        done_meta = _make_base_meta(CycleState.DONE)
        mock_mgr.start.return_value = _make_base_meta(CycleState.DONE)
        mock_mgr.next.return_value = (done_meta, "Done!")
        mock_mgr.status.return_value = done_meta

        mock_hb_engine = MagicMock()
        mock_hb_engine.tick.return_value = []

        with self._base_patches() as stack:
            stack.enter_context(patch("owlmind.agent.cycle.CycleManager", return_value=mock_mgr))
            stack.enter_context(patch("owlmind.events.EventBus"))
            stack.enter_context(patch("owlmind.queue.TaskQueue"))
            mock_hb_cls = stack.enter_context(
                patch(
                    "owlmind.heartbeat.HeartbeatEngine",
                    return_value=mock_hb_engine,
                )
            )
            config = AutoPilotConfig(
                goal="test",
                use_llm="none",
                use_worker="none",
                auto_export=False,
                enable_heartbeat=True,
                interval=0,
            )
            result = run(config)

        mock_hb_cls.assert_called_once()
        mock_hb_engine.tick.assert_called()
        assert result.run_id != ""


# ---------------------------------------------------------------------------
# Tests: memory store unavailable (lines 142-143)
# ---------------------------------------------------------------------------


class TestMemoryStoreUnavailable:
    """Cover the except-block when MemoryStore import/init fails."""

    def test_memory_store_exception_logs_and_continues(self) -> None:
        mock_mgr = _make_mock_mgr()
        done_meta = _make_base_meta(CycleState.DONE)
        mock_mgr.start.return_value = _make_base_meta(CycleState.DONE)
        mock_mgr.next.return_value = (done_meta, "Done!")
        mock_mgr.status.return_value = done_meta

        with (
            patch("owlmind.config.OwlMindConfig"),
            patch("owlmind.policy.PolicyEngine"),
            patch("owlmind.evidence.EvidenceStore"),
            patch("owlmind.budget.BudgetGovernor"),
            patch("owlmind.ledger.UsageLedger"),
            # Force MemoryStore to raise so the except-block is hit
            patch("owlmind.memory.store.MemoryStore", side_effect=RuntimeError("db broken")),
            patch("owlmind.agent.cycle.CycleManager", return_value=mock_mgr),
        ):
            config = AutoPilotConfig(
                goal="test",
                use_llm="none",
                use_worker="none",
                auto_export=False,
                enable_heartbeat=False,
                interval=0,
            )
            # Should not raise even though MemoryStore is broken
            result = run(config)

        assert result.run_id != ""
        assert result.final_state == CycleState.DONE.value


# ---------------------------------------------------------------------------
# Tests: heartbeat engine unavailable (lines 160-161)
# ---------------------------------------------------------------------------


class TestHeartbeatEngineUnavailable:
    """Cover the except-block when HeartbeatEngine init fails."""

    def test_heartbeat_exception_logs_and_continues(self) -> None:
        mock_mgr = _make_mock_mgr()
        done_meta = _make_base_meta(CycleState.DONE)
        mock_mgr.start.return_value = _make_base_meta(CycleState.DONE)
        mock_mgr.next.return_value = (done_meta, "Done!")
        mock_mgr.status.return_value = done_meta

        with (
            patch("owlmind.config.OwlMindConfig"),
            patch("owlmind.policy.PolicyEngine"),
            patch("owlmind.evidence.EvidenceStore"),
            patch("owlmind.budget.BudgetGovernor"),
            patch("owlmind.ledger.UsageLedger"),
            patch("owlmind.memory.store.MemoryStore"),
            patch("owlmind.agent.cycle.CycleManager", return_value=mock_mgr),
            # Force HeartbeatEngine to raise so the except-block is hit
            patch("owlmind.heartbeat.HeartbeatEngine", side_effect=RuntimeError("hb broken")),
            patch("owlmind.events.EventBus"),
            patch("owlmind.queue.TaskQueue"),
        ):
            config = AutoPilotConfig(
                goal="test",
                use_llm="none",
                use_worker="none",
                auto_export=False,
                enable_heartbeat=True,
                interval=0,
            )
            result = run(config)

        # heartbeat_engine is None -> loop proceeds without ticking
        assert result.run_id != ""
        assert result.final_state == CycleState.DONE.value


# ---------------------------------------------------------------------------
# Tests: max_steps reached (lines 203-206)
# ---------------------------------------------------------------------------


class TestMaxStepsReached:
    """Cover the max_steps > 0 branch that breaks the loop."""

    def test_max_steps_triggers_break(self) -> None:
        """Loop breaks when step > max_steps.

        With max_steps=1: step=1 passes (1>1 is False), then next() returns a
        non-blocking non-terminal non-Waiting message so the loop continues.
        step=2 triggers (2>1 is True) and breaks.
        """
        mock_mgr = _make_mock_mgr()
        running_meta = _make_base_meta(CycleState.STARTED_WAIT_PLANNER)
        running_meta.hard_fail_reasons = []
        mock_mgr.start.return_value = _make_base_meta(CycleState.STARTED_WAIT_PLANNER)
        # No "Waiting" in message -> the no-handler branch is not triggered
        mock_mgr.next.return_value = (running_meta, "In progress, running planner")
        mock_mgr.status.return_value = running_meta

        with (
            patch("owlmind.config.OwlMindConfig"),
            patch("owlmind.policy.PolicyEngine"),
            patch("owlmind.evidence.EvidenceStore"),
            patch("owlmind.budget.BudgetGovernor"),
            patch("owlmind.ledger.UsageLedger"),
            patch("owlmind.memory.store.MemoryStore"),
            patch("owlmind.agent.cycle.CycleManager", return_value=mock_mgr),
        ):
            config = AutoPilotConfig(
                goal="test",
                use_llm="none",
                use_worker="none",
                auto_export=False,
                enable_heartbeat=False,
                max_steps=1,
                interval=0,
            )
            result = run(config)

        assert "max_steps" in result.stop_reason
        assert result.steps >= 2

    def test_max_steps_emits_event(self) -> None:
        emitted: list[str] = []
        mock_mgr = _make_mock_mgr()
        running_meta = _make_base_meta(CycleState.STARTED_WAIT_PLANNER)
        running_meta.hard_fail_reasons = []
        mock_mgr.start.return_value = _make_base_meta(CycleState.STARTED_WAIT_PLANNER)
        # No "Waiting" in message -> loop does not stop on no-handler
        mock_mgr.next.return_value = (running_meta, "Running planner now")
        mock_mgr.status.return_value = running_meta

        with (
            patch("owlmind.config.OwlMindConfig"),
            patch("owlmind.policy.PolicyEngine"),
            patch("owlmind.evidence.EvidenceStore"),
            patch("owlmind.budget.BudgetGovernor"),
            patch("owlmind.ledger.UsageLedger"),
            patch("owlmind.memory.store.MemoryStore"),
            patch("owlmind.agent.cycle.CycleManager", return_value=mock_mgr),
        ):
            config = AutoPilotConfig(
                goal="test",
                use_llm="none",
                use_worker="none",
                auto_export=False,
                enable_heartbeat=False,
                max_steps=1,
                interval=0,
                on_event=lambda n, d: emitted.append(n),
            )
            run(config)

        assert "max_steps" in emitted


# ---------------------------------------------------------------------------
# Tests: WAIT_JUDGE branch (line 257) and WAIT_WORKER with blocked (260-264)
# ---------------------------------------------------------------------------


class TestWaitJudgeAndWorkerBranches:
    """Cover the WAIT_JUDGE and WAIT_WORKER state branches inside the main loop."""

    def test_wait_judge_calls_try_judge(self) -> None:
        """When state is WAIT_JUDGE with 'Waiting' and use_llm includes judge,
        _try_judge is called."""
        emitted: list[str] = []
        mock_mgr = _make_mock_mgr()
        wait_judge_meta = _make_base_meta(CycleState.WAIT_JUDGE)
        done_meta = _make_base_meta(CycleState.DONE)

        # First next() returns WAIT_JUDGE, second returns DONE
        mock_mgr.start.return_value = _make_base_meta(CycleState.WAIT_JUDGE)
        mock_mgr.next.side_effect = [
            (wait_judge_meta, "Waiting for judge"),
            (done_meta, "Done!"),
        ]
        mock_mgr.status.return_value = done_meta

        with (
            patch("owlmind.config.OwlMindConfig"),
            patch("owlmind.policy.PolicyEngine"),
            patch("owlmind.evidence.EvidenceStore"),
            patch("owlmind.budget.BudgetGovernor"),
            patch("owlmind.ledger.UsageLedger"),
            patch("owlmind.memory.store.MemoryStore"),
            patch("owlmind.agent.cycle.CycleManager", return_value=mock_mgr),
            patch("owlmind.llm.factory.build_llm_router", return_value=MagicMock()),
        ):
            config = AutoPilotConfig(
                goal="test",
                use_llm="judge",
                use_worker="none",
                auto_export=False,
                enable_heartbeat=False,
                max_steps=5,
                interval=0,
                on_event=lambda n, d: emitted.append(n),
            )
            result = run(config)

        assert "llm_judge_start" in emitted
        assert result.final_state == CycleState.DONE.value

    def test_wait_worker_blocked_stops_loop(self) -> None:
        """When worker returns WAIT_APPROVAL (blocked), the loop stops."""
        emitted: list[str] = []
        mock_mgr = _make_mock_mgr()
        wait_worker_meta = _make_base_meta(CycleState.WAIT_WORKER)
        mock_mgr.start.return_value = _make_base_meta(CycleState.WAIT_WORKER)
        mock_mgr.next.return_value = (wait_worker_meta, "Waiting for worker")
        approval_meta = _make_base_meta(CycleState.WAIT_APPROVAL)
        mock_mgr.run_worker_cli.return_value = (approval_meta, "Needs approval")
        mock_mgr.status.return_value = wait_worker_meta

        with (
            patch("owlmind.config.OwlMindConfig"),
            patch("owlmind.policy.PolicyEngine"),
            patch("owlmind.evidence.EvidenceStore"),
            patch("owlmind.budget.BudgetGovernor"),
            patch("owlmind.ledger.UsageLedger"),
            patch("owlmind.memory.store.MemoryStore"),
            patch("owlmind.agent.cycle.CycleManager", return_value=mock_mgr),
        ):
            config = AutoPilotConfig(
                goal="test",
                use_llm="none",
                use_worker="claude_cli",
                auto_export=False,
                enable_heartbeat=False,
                max_steps=5,
                interval=0,
                auto_approve=False,
                on_event=lambda n, d: emitted.append(n),
            )
            result = run(config)

        assert "blocked" in result.stop_reason
        assert "worker_start" in emitted

    def test_wait_worker_success_sets_advanced(self) -> None:
        """When WAIT_WORKER and worker succeeds (not blocked), advanced=True and loop continues.

        This covers autopilot.py line 264: advanced = ok.
        """
        emitted: list[str] = []
        mock_mgr = _make_mock_mgr()
        wait_worker_meta = _make_base_meta(CycleState.WAIT_WORKER)
        done_meta = _make_base_meta(CycleState.DONE)

        # First next() returns WAIT_WORKER; worker call succeeds; second next() returns DONE
        mock_mgr.start.return_value = _make_base_meta(CycleState.WAIT_WORKER)
        mock_mgr.next.side_effect = [
            (wait_worker_meta, "Waiting for worker"),
            (done_meta, "Done!"),
        ]
        # Worker returns a non-approval state (success)
        success_meta = _make_base_meta(CycleState.WAIT_JUDGE)
        mock_mgr.run_worker_cli.return_value = (success_meta, "Worker done")
        mock_mgr.status.return_value = done_meta

        with (
            patch("owlmind.config.OwlMindConfig"),
            patch("owlmind.policy.PolicyEngine"),
            patch("owlmind.evidence.EvidenceStore"),
            patch("owlmind.budget.BudgetGovernor"),
            patch("owlmind.ledger.UsageLedger"),
            patch("owlmind.memory.store.MemoryStore"),
            patch("owlmind.agent.cycle.CycleManager", return_value=mock_mgr),
        ):
            config = AutoPilotConfig(
                goal="test",
                use_llm="none",
                use_worker="claude_cli",
                auto_export=False,
                enable_heartbeat=False,
                max_steps=5,
                interval=0,
                auto_approve=False,
                on_event=lambda n, d: emitted.append(n),
            )
            result = run(config)

        assert "worker_done" in emitted
        assert result.final_state == CycleState.DONE.value


# ---------------------------------------------------------------------------
# Tests: hard_fail_reasons (lines 274-276)
# ---------------------------------------------------------------------------


class TestHardFailReasons:
    """Cover the hard_fail_reasons check in the main loop."""

    def test_hard_fail_stops_loop(self) -> None:
        emitted: list[str] = []
        mock_mgr = _make_mock_mgr()
        hard_fail_meta = _make_base_meta(CycleState.STARTED_WAIT_PLANNER)
        hard_fail_meta.hard_fail_reasons = ["Budget exceeded"]
        mock_mgr.start.return_value = _make_base_meta(CycleState.STARTED_WAIT_PLANNER)
        mock_mgr.next.return_value = (hard_fail_meta, "Some progress")
        mock_mgr.status.return_value = hard_fail_meta

        with (
            patch("owlmind.config.OwlMindConfig"),
            patch("owlmind.policy.PolicyEngine"),
            patch("owlmind.evidence.EvidenceStore"),
            patch("owlmind.budget.BudgetGovernor"),
            patch("owlmind.ledger.UsageLedger"),
            patch("owlmind.memory.store.MemoryStore"),
            patch("owlmind.agent.cycle.CycleManager", return_value=mock_mgr),
        ):
            config = AutoPilotConfig(
                goal="test",
                use_llm="none",
                use_worker="none",
                auto_export=False,
                enable_heartbeat=False,
                max_steps=10,
                interval=0,
                on_event=lambda n, d: emitted.append(n),
            )
            result = run(config)

        assert "hard_fail" in result.stop_reason
        assert "hard_fail" in emitted


# ---------------------------------------------------------------------------
# Tests: auto_export with export_dir set (lines 296, 298-300)
# ---------------------------------------------------------------------------


class TestAutoExportWithDir:
    """Cover the export_dir branch and successful export path."""

    def test_auto_export_with_export_dir_sets_path(self) -> None:
        mock_mgr = _make_mock_mgr()
        done_meta = _make_base_meta(CycleState.DONE)
        mock_mgr.start.return_value = _make_base_meta(CycleState.DONE)
        mock_mgr.next.return_value = (done_meta, "Done!")
        mock_mgr.status.return_value = done_meta
        fake_zip = MagicMock()
        fake_zip.configure_mock(**{"__str__.return_value": "/tmp/export.zip"})
        mock_mgr.export.return_value = fake_zip
        emitted: list[str] = []

        with (
            patch("owlmind.config.OwlMindConfig"),
            patch("owlmind.policy.PolicyEngine"),
            patch("owlmind.evidence.EvidenceStore"),
            patch("owlmind.budget.BudgetGovernor"),
            patch("owlmind.ledger.UsageLedger"),
            patch("owlmind.memory.store.MemoryStore"),
            patch("owlmind.agent.cycle.CycleManager", return_value=mock_mgr),
        ):
            export_dir = MagicMock(spec=Path)
            config = AutoPilotConfig(
                goal="test",
                use_llm="none",
                use_worker="none",
                auto_export=True,
                export_dir=export_dir,
                enable_heartbeat=False,
                interval=0,
                on_event=lambda n, d: emitted.append(n),
            )
            result = run(config)

        assert result.export_path is not None
        assert "exported" in emitted

    def test_auto_export_no_export_dir_uses_none(self) -> None:
        """When export_dir is None, export is called with out_path=None."""
        mock_mgr = _make_mock_mgr()
        done_meta = _make_base_meta(CycleState.DONE)
        mock_mgr.start.return_value = _make_base_meta(CycleState.DONE)
        mock_mgr.next.return_value = (done_meta, "Done!")
        mock_mgr.status.return_value = done_meta
        fake_zip = MagicMock()
        fake_zip.configure_mock(**{"__str__.return_value": "/tmp/auto_export.zip"})
        mock_mgr.export.return_value = fake_zip

        with (
            patch("owlmind.config.OwlMindConfig"),
            patch("owlmind.policy.PolicyEngine"),
            patch("owlmind.evidence.EvidenceStore"),
            patch("owlmind.budget.BudgetGovernor"),
            patch("owlmind.ledger.UsageLedger"),
            patch("owlmind.memory.store.MemoryStore"),
            patch("owlmind.agent.cycle.CycleManager", return_value=mock_mgr),
        ):
            config = AutoPilotConfig(
                goal="test",
                use_llm="none",
                use_worker="none",
                auto_export=True,
                export_dir=None,
                enable_heartbeat=False,
                interval=0,
            )
            result = run(config)

        # export called with out_path=None
        mock_mgr.export.assert_called_once_with(result.run_id, out_path=None)
        assert result.export_path is not None


# ---------------------------------------------------------------------------
# Tests: _try_worker auto_approve path (lines 380-393)
# ---------------------------------------------------------------------------


class TestTryWorkerAutoApprove:
    """Cover the auto_approve branch in _try_worker."""

    def test_auto_approve_success_returns_true_false(self) -> None:
        """With auto_approve=True and valid token, approval is resolved and worker retried."""
        emitted: list[str] = []
        config = AutoPilotConfig(
            goal="test",
            auto_approve=True,
            on_event=lambda n, d: emitted.append(n),
        )
        mock_mgr = MagicMock()
        approval_meta = _make_base_meta(CycleState.WAIT_APPROVAL)
        approval_meta.extra = {"pending_approval": {"token": "tok-123"}}
        done_meta = _make_base_meta(CycleState.WAIT_JUDGE)

        # First call returns approval state, second returns done
        mock_mgr.run_worker_cli.side_effect = [
            (approval_meta, "Needs approval"),
            (done_meta, "Worker done"),
        ]

        with patch("owlmind.approval.resolve_approval") as mock_resolve:
            ok, blocked = _try_worker(mock_mgr, "run-auto", config, step=1)

        assert ok is True
        assert blocked is False
        mock_resolve.assert_called_once()
        assert "worker_auto_approved" in emitted
        assert "worker_done" in emitted

    def test_auto_approve_second_call_still_blocked(self) -> None:
        """With auto_approve=True, if second worker call also returns WAIT_APPROVAL -> blocked."""
        emitted: list[str] = []
        config = AutoPilotConfig(
            goal="test",
            auto_approve=True,
            on_event=lambda n, d: emitted.append(n),
        )
        mock_mgr = MagicMock()
        approval_meta = _make_base_meta(CycleState.WAIT_APPROVAL)
        approval_meta.extra = {"pending_approval": {"token": "tok-456"}}

        # Both calls return WAIT_APPROVAL
        mock_mgr.run_worker_cli.return_value = (approval_meta, "Still blocked")

        with patch("owlmind.approval.resolve_approval"):
            ok, blocked = _try_worker(mock_mgr, "run-auto2", config, step=2)

        assert ok is False
        assert blocked is True

    def test_auto_approve_no_token_falls_through_to_blocked(self) -> None:
        """With auto_approve=True but no token in pending_approval, falls through."""
        emitted: list[str] = []
        config = AutoPilotConfig(
            goal="test",
            auto_approve=True,
            on_event=lambda n, d: emitted.append(n),
        )
        mock_mgr = MagicMock()
        approval_meta = _make_base_meta(CycleState.WAIT_APPROVAL)
        # No token
        approval_meta.extra = {"pending_approval": {"token": ""}}
        mock_mgr.run_worker_cli.return_value = (approval_meta, "Needs approval")

        ok, blocked = _try_worker(mock_mgr, "run-no-token", config, step=3)

        # No token -> falls through to approval_needed path
        assert ok is False
        assert blocked is True
        assert "worker_approval_needed" in emitted
