"""Tests for owlmind.cli._helpers — print_totals, autopilot_event_printer,
print_session_result, session_exit_code, make_budget, make_worker_driver."""

from __future__ import annotations

from io import StringIO
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from rich.console import Console


def make_test_console() -> Console:
    """Return an in-memory Console for capturing output."""
    return Console(file=StringIO(), highlight=False)


# ===========================================================================
# print_totals
# ===========================================================================


class TestPrintTotals:
    def _make_totals(
        self,
        *,
        input_tokens: int = 1000,
        output_tokens: int = 500,
        total_tokens: int = 1500,
        estimated_usd: float = 0.0045,
        llm_calls: int = 3,
        models: dict | None = None,
    ) -> MagicMock:
        from owlmind.ledger import UsageTotals

        totals = MagicMock(spec=UsageTotals)
        totals.input_tokens = input_tokens
        totals.output_tokens = output_tokens
        totals.total_tokens = total_tokens
        totals.estimated_usd = estimated_usd
        totals.llm_calls = llm_calls
        totals.models = models if models is not None else {}
        return totals

    def test_print_totals_basic(self) -> None:
        """print_totals renders token counts and USD cost."""
        from owlmind.cli._helpers import print_totals

        totals = self._make_totals()

        # Redirect console inside the module
        captured = StringIO()
        test_console = Console(file=captured, highlight=False)

        with patch("owlmind.cli._helpers.console", test_console):
            print_totals("Usage Summary", totals)

        output = captured.getvalue()
        assert "1,000" in output  # input_tokens formatted
        assert "500" in output
        assert "1,500" in output
        assert "0.0045" in output
        assert "3" in output

    def test_print_totals_with_models(self) -> None:
        """print_totals renders a 'Models Used' table when models is non-empty."""
        from owlmind.cli._helpers import print_totals

        totals = self._make_totals(models={"gpt-4o": 2, "claude-3-opus": 1})

        captured = StringIO()
        test_console = Console(file=captured, highlight=False)

        with patch("owlmind.cli._helpers.console", test_console):
            print_totals("Run Totals", totals)

        output = captured.getvalue()
        assert "gpt-4o" in output
        assert "claude-3-opus" in output

    def test_print_totals_no_models(self) -> None:
        """print_totals with empty models dict skips the model table."""
        from owlmind.cli._helpers import print_totals

        totals = self._make_totals(models={})

        captured = StringIO()
        test_console = Console(file=captured, highlight=False)

        with patch("owlmind.cli._helpers.console", test_console):
            print_totals("Empty Models", totals)

        output = captured.getvalue()
        assert "Models Used" not in output

    def test_print_totals_title_shown(self) -> None:
        """print_totals uses the provided title string."""
        from owlmind.cli._helpers import print_totals

        totals = self._make_totals()

        captured = StringIO()
        test_console = Console(file=captured, highlight=False)

        with patch("owlmind.cli._helpers.console", test_console):
            print_totals("My Custom Title", totals)

        output = captured.getvalue()
        assert "My Custom Title" in output


# ===========================================================================
# autopilot_event_printer
# ===========================================================================


class TestAutopilotEventPrinter:
    """autopilot_event_printer is a direct function, not a factory.
    We call it with (name, data) and verify console output."""

    def _call(self, name: str, data: dict) -> str:
        from owlmind.cli._helpers import autopilot_event_printer

        captured = StringIO()
        test_console = Console(file=captured, highlight=False)

        with patch("owlmind.cli._helpers.console", test_console):
            autopilot_event_printer(name, data)

        return captured.getvalue()

    def test_started_event(self) -> None:
        """'started' event prints run_id."""
        output = self._call("started", {"run_id": "abc123"})
        assert "abc123" in output

    def test_resumed_event(self) -> None:
        """'resumed' event prints run_id and state."""
        output = self._call("resumed", {"run_id": "xyz", "state": "WAIT_WORKER"})
        assert "xyz" in output
        assert "WAIT_WORKER" in output

    def test_step_event(self) -> None:
        """'step' event prints step number and state."""
        output = self._call("step", {"step": 5, "state": "RUNNING", "message": "Checking policy"})
        assert "5" in output
        assert "RUNNING" in output

    def test_llm_planner_start_event(self) -> None:
        """'llm_planner_start' event prints planner indicator."""
        output = self._call("llm_planner_start", {})
        assert "planner" in output.lower()

    def test_llm_planner_done_event(self) -> None:
        """'llm_planner_done' event prints response generated message."""
        output = self._call("llm_planner_done", {})
        assert "Planner" in output

    def test_llm_planner_error_event(self) -> None:
        """'llm_planner_error' event prints the error message."""
        output = self._call("llm_planner_error", {"error": "Timeout after 30s"})
        assert "Timeout after 30s" in output

    def test_llm_judge_start_event(self) -> None:
        """'llm_judge_start' event prints judge indicator."""
        output = self._call("llm_judge_start", {})
        assert "judge" in output.lower()

    def test_llm_judge_done_event(self) -> None:
        """'llm_judge_done' event prints judge done message."""
        output = self._call("llm_judge_done", {})
        assert "Judge" in output

    def test_llm_judge_error_event(self) -> None:
        """'llm_judge_error' event prints the error message."""
        output = self._call("llm_judge_error", {"error": "Model unavailable"})
        assert "Model unavailable" in output

    def test_worker_start_event(self) -> None:
        """'worker_start' event prints worker indicator."""
        output = self._call("worker_start", {})
        assert "worker" in output.lower()

    def test_worker_done_event(self) -> None:
        """'worker_done' event prints worker done message."""
        output = self._call("worker_done", {})
        assert "Worker" in output

    def test_worker_error_event(self) -> None:
        """'worker_error' event prints the error."""
        output = self._call("worker_error", {"error": "Exit code 1"})
        assert "Exit code 1" in output

    def test_worker_approval_needed_event(self) -> None:
        """'worker_approval_needed' event prints message."""
        output = self._call("worker_approval_needed", {"message": "Awaiting operator"})
        assert "Awaiting operator" in output

    def test_blocked_event(self) -> None:
        """'blocked' event prints state."""
        output = self._call("blocked", {"state": "WAIT_APPROVAL"})
        assert "WAIT_APPROVAL" in output

    def test_terminal_event(self) -> None:
        """'terminal' event prints message field."""
        output = self._call("terminal", {"state": "DONE", "message": "All goals completed"})
        assert "All goals completed" in output

    def test_exported_event(self) -> None:
        """'exported' event prints path."""
        output = self._call("exported", {"path": "/tmp/report.json"})
        assert "/tmp/report.json" in output

    def test_error_event(self) -> None:
        """'error' event prints error message."""
        output = self._call("error", {"error": "Something failed catastrophically"})
        assert "Something failed catastrophically" in output

    def test_max_steps_event(self) -> None:
        """'max_steps' event prints step number."""
        output = self._call("max_steps", {"step": 100})
        assert "100" in output

    def test_finished_event(self) -> None:
        """'finished' event prints stop_reason."""
        output = self._call("finished", {"stop_reason": "max_steps"})
        assert "max_steps" in output

    def test_unknown_event_produces_no_output(self) -> None:
        """Unknown event name → nothing printed (no crash)."""
        output = self._call("totally_unknown_event", {"foo": "bar"})
        # No assertion on content — just ensure it doesn't raise
        assert isinstance(output, str)


# ===========================================================================
# print_session_result
# ===========================================================================


class TestPrintSessionResult:
    def _make_result(
        self,
        *,
        status: str = "DONE",
        session_id: str = "sess-001",
        goals_done: int = 5,
        goals_total: int = 5,
        goals_failed: int = 0,
        goals_blocked: int = 0,
        goals_skipped: int = 0,
        last_block_reason: str = "",
        next_commands: list[str] | None = None,
    ) -> MagicMock:
        r = MagicMock()
        r.status = status
        r.session_id = session_id
        r.goals_done = goals_done
        r.goals_total = goals_total
        r.goals_failed = goals_failed
        r.goals_blocked = goals_blocked
        r.goals_skipped = goals_skipped
        r.last_block_reason = last_block_reason
        r.next_commands = next_commands or []
        return r

    def _call(self, result: MagicMock) -> str:
        from owlmind.cli._helpers import print_session_result

        captured = StringIO()
        test_console = Console(file=captured, highlight=False)

        with patch("owlmind.cli._helpers.console", test_console):
            print_session_result(result)

        return captured.getvalue()

    def test_done_status(self) -> None:
        """DONE session → status and session_id printed."""
        output = self._call(self._make_result(status="DONE", session_id="abc"))
        assert "DONE" in output
        assert "abc" in output

    def test_failed_status(self) -> None:
        """FAILED session → FAILED in output."""
        output = self._call(self._make_result(status="FAILED", goals_failed=2))
        assert "FAILED" in output
        assert "2" in output

    def test_blocked_status_with_reason(self) -> None:
        """BLOCKED session → reason printed."""
        output = self._call(
            self._make_result(
                status="BLOCKED", goals_blocked=1, last_block_reason="Missing approval"
            )
        )
        assert "BLOCKED" in output
        assert "Missing approval" in output

    def test_goals_progress(self) -> None:
        """Session result shows goals done/total fraction."""
        output = self._call(self._make_result(goals_done=3, goals_total=7))
        assert "3" in output
        assert "7" in output

    def test_next_commands_printed(self) -> None:
        """Session result with next_commands → commands shown."""
        output = self._call(
            self._make_result(next_commands=["owlmind ci runs", "owlmind monitor digest"])
        )
        assert "owlmind ci runs" in output
        assert "owlmind monitor digest" in output

    def test_skipped_shown_when_nonzero(self) -> None:
        """Session result with goals_skipped → skipped count shown."""
        result = self._make_result(goals_skipped=2)
        output = self._call(result)
        assert "2" in output

    def test_no_block_reason_when_empty(self) -> None:
        """Session result without last_block_reason → no 'Reason' line."""
        output = self._call(self._make_result(last_block_reason=""))
        assert "Reason" not in output


# ===========================================================================
# session_exit_code
# ===========================================================================


class TestSessionExitCode:
    def test_done_returns_0(self) -> None:
        from owlmind.cli._helpers import session_exit_code

        assert session_exit_code("DONE") == 0

    def test_blocked_returns_2(self) -> None:
        from owlmind.cli._helpers import session_exit_code

        assert session_exit_code("BLOCKED") == 2

    def test_failed_returns_4(self) -> None:
        from owlmind.cli._helpers import session_exit_code

        assert session_exit_code("FAILED") == 4

    def test_stopped_returns_5(self) -> None:
        from owlmind.cli._helpers import session_exit_code

        assert session_exit_code("STOPPED") == 5

    def test_unknown_status_returns_1(self) -> None:
        from owlmind.cli._helpers import session_exit_code

        assert session_exit_code("RUNNING") == 1
        assert session_exit_code("UNKNOWN") == 1
        assert session_exit_code("") == 1


# ===========================================================================
# make_budget
# ===========================================================================


class TestMakeBudget:
    def test_make_budget_returns_governor_and_ledger(self, tmp_path: Path) -> None:
        """make_budget returns (BudgetGovernor, UsageLedger) tuple."""
        from owlmind.cli._helpers import make_budget

        mock_governor = MagicMock()
        mock_ledger = MagicMock()
        mock_cfg = MagicMock()
        mock_cfg.budget = MagicMock()
        mock_cfg.pricing = MagicMock()

        with (
            patch("owlmind.config.OwlMindConfig.from_env", return_value=mock_cfg),
            patch("owlmind.ledger.UsageLedger", return_value=mock_ledger),
            patch("owlmind.budget.BudgetGovernor", return_value=mock_governor),
        ):
            governor, ledger = make_budget(tmp_path)

        assert governor is mock_governor
        assert ledger is mock_ledger

    def test_make_budget_passes_ledger_dir(self, tmp_path: Path) -> None:
        """make_budget creates UsageLedger with the provided directory."""
        from owlmind.cli._helpers import make_budget

        mock_cfg = MagicMock()
        mock_cfg.budget = MagicMock()
        mock_cfg.pricing = MagicMock()

        with (
            patch("owlmind.config.OwlMindConfig.from_env", return_value=mock_cfg),
            patch("owlmind.ledger.UsageLedger") as mock_ledger_cls,
            patch("owlmind.budget.BudgetGovernor"),
        ):
            make_budget(tmp_path)

        mock_ledger_cls.assert_called_once_with(tmp_path)


# ===========================================================================
# make_worker_driver
# ===========================================================================


class TestMakeWorkerDriver:
    def test_claude_cli_mode_returns_driver(self) -> None:
        """make_worker_driver('claude_cli', ...) returns a ClaudeCLIDriver."""
        from owlmind.cli._helpers import make_worker_driver

        mock_policy = MagicMock()
        mock_cfg = MagicMock()
        mock_cfg.worker.claude_cli_continue = False
        mock_driver = MagicMock()

        with (
            patch("owlmind.config.OwlMindConfig.from_env", return_value=mock_cfg),
            patch("owlmind.worker.claude_cli_driver.ClaudeCLIDriver", return_value=mock_driver),
        ):
            driver = make_worker_driver("claude_cli", mock_policy)

        assert driver is mock_driver

    def test_unknown_mode_raises_value_error(self) -> None:
        """make_worker_driver with unknown mode raises ValueError."""
        from owlmind.cli._helpers import make_worker_driver

        mock_policy = MagicMock()

        with pytest.raises(ValueError, match="Unknown worker mode"):
            make_worker_driver("nonexistent_driver", mock_policy)

    def test_claude_cli_passes_policy(self) -> None:
        """make_worker_driver('claude_cli') passes policy to the driver."""
        from owlmind.cli._helpers import make_worker_driver

        mock_policy = MagicMock()
        mock_cfg = MagicMock()
        mock_cfg.worker.claude_cli_continue = True

        with (
            patch("owlmind.config.OwlMindConfig.from_env", return_value=mock_cfg),
            patch("owlmind.worker.claude_cli_driver.ClaudeCLIDriver") as mock_cls,
        ):
            make_worker_driver("claude_cli", mock_policy)

        call_kwargs = mock_cls.call_args.kwargs
        assert call_kwargs["policy"] == mock_policy
        assert call_kwargs["continue_mode"] is True
        assert call_kwargs["limits"].timeout_seconds == 600


# ===========================================================================
# make_llm_driver
# ===========================================================================


class TestMakeLlmDriver:
    def test_make_llm_driver_returns_router(self) -> None:
        """make_llm_driver returns the LLM router from build_llm_router."""
        from owlmind.cli._helpers import make_llm_driver

        mock_cfg = MagicMock()
        mock_router = MagicMock()

        with (
            patch("owlmind.config.OwlMindConfig.from_env", return_value=mock_cfg),
            patch("owlmind.llm.factory.build_llm_router", return_value=mock_router),
        ):
            router = make_llm_driver()

        assert router is mock_router

    def test_make_llm_driver_with_force_provider(self) -> None:
        """make_llm_driver passes force_provider to build_llm_router."""
        from owlmind.cli._helpers import make_llm_driver

        mock_cfg = MagicMock()
        mock_router = MagicMock()

        with (
            patch("owlmind.config.OwlMindConfig.from_env", return_value=mock_cfg),
            patch("owlmind.llm.factory.build_llm_router", return_value=mock_router) as mock_build,
        ):
            make_llm_driver(force_provider="openai")

        mock_build.assert_called_once_with(mock_cfg, force_planner="openai", force_judge="openai")

    def test_make_llm_driver_runtime_error_exits_1(self) -> None:
        """make_llm_driver when build_llm_router raises RuntimeError → typer.Exit(1)."""
        import typer

        from owlmind.cli._helpers import make_llm_driver

        mock_cfg = MagicMock()

        with (
            patch("owlmind.config.OwlMindConfig.from_env", return_value=mock_cfg),
            patch(
                "owlmind.llm.factory.build_llm_router",
                side_effect=RuntimeError("No API key configured"),
            ),
            pytest.raises(typer.Exit),
        ):
            make_llm_driver()


# ===========================================================================
# make_cycle_manager — with_llm, with_worker, with_budget, memory_db paths
# ===========================================================================


class TestMakeCycleManagerBranches:
    def test_make_cycle_manager_with_llm(self, tmp_path: Path) -> None:
        """make_cycle_manager with with_llm=True creates llm_driver and budget."""
        from owlmind.cli._helpers import make_cycle_manager

        mock_policy = MagicMock()
        mock_evidence = MagicMock()
        mock_mgr = MagicMock()
        mock_router = MagicMock()
        mock_governor = MagicMock()
        mock_ledger = MagicMock()

        with (
            patch(
                "owlmind.cli._helpers.PolicyEngine.from_directory",
                return_value=mock_policy,
            ),
            patch(
                "owlmind.cli._helpers.EvidenceStore",
                return_value=mock_evidence,
            ),
            patch("owlmind.cli._helpers.make_llm_driver", return_value=mock_router),
            patch(
                "owlmind.cli._helpers.make_budget",
                return_value=(mock_governor, mock_ledger),
            ),
            patch("owlmind.agent.cycle.CycleManager", return_value=mock_mgr),
        ):
            _policy, _evidence, mgr = make_cycle_manager(
                tmp_path / "policies",
                tmp_path / "runs",
                with_llm=True,
            )

        assert mgr is mock_mgr

    def test_make_cycle_manager_with_worker(self, tmp_path: Path) -> None:
        """make_cycle_manager with with_worker='claude_cli' creates worker_driver."""
        from owlmind.cli._helpers import make_cycle_manager

        mock_policy = MagicMock()
        mock_evidence = MagicMock()
        mock_mgr = MagicMock()
        mock_driver = MagicMock()

        with (
            patch(
                "owlmind.cli._helpers.PolicyEngine.from_directory",
                return_value=mock_policy,
            ),
            patch(
                "owlmind.cli._helpers.EvidenceStore",
                return_value=mock_evidence,
            ),
            patch("owlmind.cli._helpers.make_worker_driver", return_value=mock_driver),
            patch("owlmind.agent.cycle.CycleManager", return_value=mock_mgr),
        ):
            _policy, _evidence, mgr = make_cycle_manager(
                tmp_path / "policies",
                tmp_path / "runs",
                with_worker="claude_cli",
            )

        assert mgr is mock_mgr

    def test_make_cycle_manager_with_budget_only(self, tmp_path: Path) -> None:
        """make_cycle_manager with with_budget=True creates budget without LLM."""
        from owlmind.cli._helpers import make_cycle_manager

        mock_policy = MagicMock()
        mock_evidence = MagicMock()
        mock_mgr = MagicMock()
        mock_governor = MagicMock()
        mock_ledger = MagicMock()

        with (
            patch(
                "owlmind.cli._helpers.PolicyEngine.from_directory",
                return_value=mock_policy,
            ),
            patch(
                "owlmind.cli._helpers.EvidenceStore",
                return_value=mock_evidence,
            ),
            patch(
                "owlmind.cli._helpers.make_budget",
                return_value=(mock_governor, mock_ledger),
            ) as mock_budget_fn,
            patch("owlmind.agent.cycle.CycleManager", return_value=mock_mgr),
        ):
            make_cycle_manager(
                tmp_path / "policies",
                tmp_path / "runs",
                with_budget=True,
            )

        mock_budget_fn.assert_called_once()

    def test_make_cycle_manager_with_memory_db(self, tmp_path: Path) -> None:
        """make_cycle_manager with memory_db → MemoryStore created and passed to CycleManager."""
        from owlmind.cli._helpers import make_cycle_manager

        mock_policy = MagicMock()
        mock_evidence = MagicMock()
        mock_mgr = MagicMock()
        mock_mem_store = MagicMock()

        with (
            patch(
                "owlmind.cli._helpers.PolicyEngine.from_directory",
                return_value=mock_policy,
            ),
            patch(
                "owlmind.cli._helpers.EvidenceStore",
                return_value=mock_evidence,
            ),
            patch("owlmind.memory.store.MemoryStore", return_value=mock_mem_store),
            patch("owlmind.agent.cycle.CycleManager", return_value=mock_mgr) as mock_mgr_cls,
        ):
            make_cycle_manager(
                tmp_path / "policies",
                tmp_path / "runs",
                memory_db=tmp_path / "memory.db",
            )

        call_kwargs = mock_mgr_cls.call_args.kwargs
        assert call_kwargs["memory_store"] is mock_mem_store

    def test_make_cycle_manager_memory_db_exception_warns(self, tmp_path: Path) -> None:
        """make_cycle_manager with memory_db → MemoryStore raises → warning printed."""
        from io import StringIO

        from rich.console import Console

        from owlmind.cli._helpers import make_cycle_manager

        mock_policy = MagicMock()
        mock_evidence = MagicMock()
        mock_mgr = MagicMock()

        captured = StringIO()
        test_console = Console(file=captured, highlight=False)

        with (
            patch(
                "owlmind.cli._helpers.PolicyEngine.from_directory",
                return_value=mock_policy,
            ),
            patch(
                "owlmind.cli._helpers.EvidenceStore",
                return_value=mock_evidence,
            ),
            patch(
                "owlmind.memory.store.MemoryStore",
                side_effect=OSError("permission denied"),
            ),
            patch("owlmind.agent.cycle.CycleManager", return_value=mock_mgr),
            patch("owlmind.cli._helpers.console", test_console),
        ):
            make_cycle_manager(
                tmp_path / "policies",
                tmp_path / "runs",
                memory_db=tmp_path / "memory.db",
            )

        output = captured.getvalue()
        assert "Warning" in output
        assert "memory store" in output
