"""Tests for owlmind.graph.session_state."""
from __future__ import annotations

import time
from pathlib import Path

from owlmind.graph.session_state import PersistedState, SessionStateStore

# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _make_state(run_id: str = "abc123", status: str = "running", **kwargs) -> PersistedState:
    now = time.time()
    defaults = dict(
        run_id=run_id,
        goal="do something",
        workspace="/tmp/ws",
        iteration=0,
        plan="the plan",
        code_changes="some code",
        status=status,
        created_at=now,
        updated_at=now,
    )
    defaults.update(kwargs)
    return PersistedState(**defaults)


# ---------------------------------------------------------------------------
# save / load round-trip
# ---------------------------------------------------------------------------

def test_save_and_load_roundtrip(tmp_path: Path) -> None:
    store = SessionStateStore(base_dir=tmp_path)
    state = _make_state(run_id="r1", status="running")
    store.save(state)

    loaded = store.load("r1")
    assert loaded is not None
    assert loaded.run_id == "r1"
    assert loaded.goal == state.goal
    assert loaded.status == "running"
    assert loaded.plan == state.plan
    assert loaded.code_changes == state.code_changes


def test_load_returns_none_for_missing_run_id(tmp_path: Path) -> None:
    store = SessionStateStore(base_dir=tmp_path)
    result = store.load("does_not_exist")
    assert result is None


# ---------------------------------------------------------------------------
# list_sessions
# ---------------------------------------------------------------------------

def test_list_sessions_returns_all(tmp_path: Path) -> None:
    store = SessionStateStore(base_dir=tmp_path)
    for i in range(3):
        store.save(_make_state(run_id=f"run{i}"))
    sessions = store.list_sessions()
    assert len(sessions) == 3


def test_list_sessions_filters_by_status(tmp_path: Path) -> None:
    store = SessionStateStore(base_dir=tmp_path)
    store.save(_make_state(run_id="r1", status="running"))
    store.save(_make_state(run_id="r2", status="done"))
    store.save(_make_state(run_id="r3", status="done"))

    running = store.list_sessions(status="running")
    assert len(running) == 1
    assert running[0].run_id == "r1"

    done = store.list_sessions(status="done")
    assert len(done) == 2


def test_list_sessions_empty_when_no_sessions(tmp_path: Path) -> None:
    store = SessionStateStore(base_dir=tmp_path)
    assert store.list_sessions() == []


# ---------------------------------------------------------------------------
# delete
# ---------------------------------------------------------------------------

def test_delete_removes_file(tmp_path: Path) -> None:
    store = SessionStateStore(base_dir=tmp_path)
    store.save(_make_state(run_id="del1"))
    assert store.load("del1") is not None

    deleted = store.delete("del1")
    assert deleted is True
    assert store.load("del1") is None


def test_delete_returns_false_for_missing(tmp_path: Path) -> None:
    store = SessionStateStore(base_dir=tmp_path)
    assert store.delete("nonexistent") is False


# ---------------------------------------------------------------------------
# updated_at
# ---------------------------------------------------------------------------

def test_updated_at_is_set_on_save(tmp_path: Path) -> None:
    store = SessionStateStore(base_dir=tmp_path)
    state = _make_state(run_id="ts1")
    old_updated_at = state.updated_at

    # Small sleep to ensure time advances
    time.sleep(0.05)
    store.save(state)

    loaded = store.load("ts1")
    assert loaded is not None
    assert loaded.updated_at > old_updated_at


# ---------------------------------------------------------------------------
# multiple sessions sorted by mtime
# ---------------------------------------------------------------------------

def test_multiple_sessions_sorted_by_mtime(tmp_path: Path) -> None:
    store = SessionStateStore(base_dir=tmp_path)

    # Save sessions with a slight delay so mtime differs
    for run_id in ("first", "second", "third"):
        store.save(_make_state(run_id=run_id))
        time.sleep(0.05)

    sessions = store.list_sessions()
    run_ids = [s.run_id for s in sessions]
    # Most recently modified should be first
    assert run_ids[0] == "third"
    assert run_ids[-1] == "first"
