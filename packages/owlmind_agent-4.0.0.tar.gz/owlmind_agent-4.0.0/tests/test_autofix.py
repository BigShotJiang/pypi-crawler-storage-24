"""Tests for owlmind.autofix — auto-fix CI failures."""
from __future__ import annotations

import subprocess
from unittest.mock import MagicMock, patch

from owlmind.autofix import AutoFixResult, _git_commit, _git_push, run_autofix

# ---------------------------------------------------------------------------
# Helpers / shared fixtures
# ---------------------------------------------------------------------------

WORKSPACE = "/tmp/fake-repo"
BRANCH = "fix/ci"
PR_URL = "https://github.com/org/repo/pull/42"
GOAL = "Fix failing CI: mypy error in auth.py"


def _make_state(verdict: str = "APPROVED", code_changes: bool = True) -> MagicMock:
    state = MagicMock()
    state.final_verdict = verdict
    state.code_changes = code_changes
    return state


# ---------------------------------------------------------------------------
# 1. run_autofix returns AutoFixResult with success=False when no LLM
# ---------------------------------------------------------------------------

def test_run_autofix_no_llm_returns_failure():
    with (
        patch("owlmind.autofix._build_llm_client", return_value=None),
        patch("owlmind.autofix.GraphRunner"),
    ):
        # We need the import block to succeed; patch at module level
        with patch.dict("sys.modules", {}):
            result = run_autofix(
                goal=GOAL, workspace=WORKSPACE, branch=BRANCH, pr_url=PR_URL
            )
    assert isinstance(result, AutoFixResult)
    assert result.success is False
    assert result.verdict == "no_llm"
    assert result.error == "No LLM configured"


# ---------------------------------------------------------------------------
# 2. run_autofix returns AutoFixResult with verdict=APPROVED on success
# ---------------------------------------------------------------------------

def test_run_autofix_approved_on_success():
    mock_state = _make_state(verdict="APPROVED", code_changes=False)
    mock_runner = MagicMock()
    mock_runner.run.return_value = mock_state

    with (
        patch("owlmind.autofix._build_llm_client", return_value=MagicMock()),
        patch("owlmind.autofix.GraphRunner", return_value=mock_runner),
    ):
        result = run_autofix(
            goal=GOAL, workspace=WORKSPACE, branch=BRANCH, pr_url=PR_URL,
            auto_commit=False, auto_push=False,
        )

    assert result.success is True
    assert result.verdict == "APPROVED"
    assert result.error == ""


# ---------------------------------------------------------------------------
# 3. run_autofix with auto_commit=False does not call git
# ---------------------------------------------------------------------------

def test_run_autofix_no_commit_skips_git():
    mock_state = _make_state(verdict="APPROVED", code_changes=True)
    mock_runner = MagicMock()
    mock_runner.run.return_value = mock_state

    with (
        patch("owlmind.autofix._build_llm_client", return_value=MagicMock()),
        patch("owlmind.autofix.GraphRunner", return_value=mock_runner),
        patch("owlmind.autofix._git_commit") as mock_commit,
        patch("owlmind.autofix._git_push") as mock_push,
    ):
        result = run_autofix(
            goal=GOAL, workspace=WORKSPACE, branch=BRANCH, pr_url=PR_URL,
            auto_commit=False, auto_push=False,
        )

    mock_commit.assert_not_called()
    mock_push.assert_not_called()
    assert result.committed is False
    assert result.pushed is False


# ---------------------------------------------------------------------------
# 4. run_autofix with auto_push=True calls _git_push when committed
# ---------------------------------------------------------------------------

def test_run_autofix_auto_push_calls_git_push_when_committed():
    mock_state = _make_state(verdict="APPROVED", code_changes=True)
    mock_runner = MagicMock()
    mock_runner.run.return_value = mock_state

    with (
        patch("owlmind.autofix._build_llm_client", return_value=MagicMock()),
        patch("owlmind.autofix.GraphRunner", return_value=mock_runner),
        patch("owlmind.autofix._git_commit", return_value=True) as mock_commit,
        patch("owlmind.autofix._git_push", return_value=True) as mock_push,
    ):
        result = run_autofix(
            goal=GOAL, workspace=WORKSPACE, branch=BRANCH, pr_url=PR_URL,
            auto_commit=True, auto_push=True,
        )

    mock_commit.assert_called_once_with(WORKSPACE, GOAL)
    mock_push.assert_called_once_with(WORKSPACE, BRANCH)
    assert result.committed is True
    assert result.pushed is True


# ---------------------------------------------------------------------------
# 5. _git_commit runs git add and git commit
# ---------------------------------------------------------------------------

def test_git_commit_runs_add_and_commit():
    with patch("owlmind.autofix.subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0)
        result = _git_commit(WORKSPACE, GOAL)

    assert result is True
    assert mock_run.call_count == 2

    add_call = mock_run.call_args_list[0]
    assert add_call[0][0] == ["git", "add", "-A"]
    assert add_call[1]["cwd"] == WORKSPACE

    commit_call = mock_run.call_args_list[1]
    assert commit_call[0][0][0] == "git"
    assert commit_call[0][0][1] == "commit"
    assert "[owlmind autofix]" in commit_call[0][0][3]


# ---------------------------------------------------------------------------
# 6. _git_push calls git push origin branch
# ---------------------------------------------------------------------------

def test_git_push_calls_correct_command():
    with patch("owlmind.autofix.subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0)
        result = _git_push(WORKSPACE, BRANCH)

    assert result is True
    mock_run.assert_called_once()
    call_args = mock_run.call_args
    assert call_args[0][0] == ["git", "push", "origin", BRANCH]
    assert call_args[1]["cwd"] == WORKSPACE


# ---------------------------------------------------------------------------
# 7. run_autofix catches GraphRunner exception
# ---------------------------------------------------------------------------

def test_run_autofix_catches_graph_runner_exception():
    mock_runner = MagicMock()
    mock_runner.run.side_effect = RuntimeError("LLM timeout")

    with (
        patch("owlmind.autofix._build_llm_client", return_value=MagicMock()),
        patch("owlmind.autofix.GraphRunner", return_value=mock_runner),
    ):
        result = run_autofix(
            goal=GOAL, workspace=WORKSPACE, branch=BRANCH, pr_url=PR_URL
        )

    assert result.success is False
    assert result.verdict == "error"
    assert "LLM timeout" in result.error


# ---------------------------------------------------------------------------
# 8. AutoFixResult.success property reflects the success field correctly
# ---------------------------------------------------------------------------

def test_autofix_result_success_property():
    ok = AutoFixResult(success=True, verdict="APPROVED", branch=BRANCH, pr_url=PR_URL)
    assert ok.success is True

    fail = AutoFixResult(success=False, verdict="REJECTED", branch=BRANCH, pr_url=PR_URL)
    assert fail.success is False

    # Default values
    assert ok.error == ""
    assert ok.committed is False
    assert ok.pushed is False


# ---------------------------------------------------------------------------
# Extra: _git_commit returns False on CalledProcessError
# ---------------------------------------------------------------------------

def test_git_commit_returns_false_on_error():
    with patch("owlmind.autofix.subprocess.run") as mock_run:
        mock_run.side_effect = subprocess.CalledProcessError(1, "git")
        result = _git_commit(WORKSPACE, GOAL)
    assert result is False


# ---------------------------------------------------------------------------
# Extra: _git_push returns False on CalledProcessError
# ---------------------------------------------------------------------------

def test_git_push_returns_false_on_error():
    with patch("owlmind.autofix.subprocess.run") as mock_run:
        mock_run.side_effect = subprocess.CalledProcessError(1, "git")
        result = _git_push(WORKSPACE, BRANCH)
    assert result is False
