"""Tests for owlmind.tools.search_tools — SearchTools (Grep + Glob)."""

from __future__ import annotations

from pathlib import Path

import pytest

from owlmind.tools.search_tools import SearchTools


@pytest.fixture
def st(tmp_path: Path) -> SearchTools:
    # Seed workspace with some files
    (tmp_path / "src").mkdir()
    (tmp_path / "tests").mkdir()
    (tmp_path / "src" / "main.py").write_text("def add(a, b):\n    return a + b\n\nfoo = 'bar'\n")
    (tmp_path / "src" / "utils.py").write_text("def helper():\n    pass\n")
    (tmp_path / "tests" / "test_main.py").write_text("from src.main import add\n\ndef test_add():\n    assert add(1,2)==3\n")
    (tmp_path / "README.md").write_text("# Project\nThis is a test project.\n")
    return SearchTools(tmp_path)


# ---------------------------------------------------------------------------
# Grep
# ---------------------------------------------------------------------------


def test_grep_finds_match(st: SearchTools) -> None:
    result = st.grep("def add")
    assert result.total_matches >= 1
    assert any("main.py" in m.file for m in result.matches)


def test_grep_case_insensitive(st: SearchTools) -> None:
    result = st.grep("DEF ADD", case_sensitive=False)
    assert result.total_matches >= 1


def test_grep_no_match(st: SearchTools) -> None:
    result = st.grep("ZZZNOMATCH999")
    assert result.total_matches == 0


def test_grep_regex(st: SearchTools) -> None:
    result = st.grep(r"def \w+\(", use_regex=True)
    assert result.total_matches >= 2  # add + helper


def test_grep_fixed_string(st: SearchTools) -> None:
    result = st.grep("foo = 'bar'", use_regex=False)
    assert result.total_matches == 1


def test_grep_include_filter(st: SearchTools) -> None:
    result = st.grep("test", include="*.md")
    assert all(m.file.endswith(".md") for m in result.matches)


def test_grep_as_text_no_matches(st: SearchTools) -> None:
    result = st.grep("NOPE")
    text = result.as_text()
    assert "No matches" in text


def test_grep_as_text_with_matches(st: SearchTools) -> None:
    result = st.grep("def")
    text = result.as_text()
    assert "Found" in text
    assert ".py" in text


# ---------------------------------------------------------------------------
# Glob
# ---------------------------------------------------------------------------


def test_glob_star(st: SearchTools) -> None:
    result = st.glob("**/*.py")
    assert result.count >= 3  # main.py, utils.py, test_main.py
    assert all(f.endswith(".py") for f in result.files)


def test_glob_specific_dir(st: SearchTools) -> None:
    result = st.glob("*.py", path="src")
    assert result.count == 2
    assert all("src" in f for f in result.files)


def test_glob_no_match(st: SearchTools) -> None:
    result = st.glob("**/*.rs")
    assert result.count == 0


def test_glob_as_text(st: SearchTools) -> None:
    result = st.glob("**/*.py")
    text = result.as_text()
    assert "Found" in text


# ---------------------------------------------------------------------------
# find_files convenience
# ---------------------------------------------------------------------------


def test_find_files(st: SearchTools) -> None:
    result = st.find_files("test_*.py")
    assert result.count >= 1
    assert all("test_" in Path(f).name for f in result.files)


# ---------------------------------------------------------------------------
# find_by_content convenience
# ---------------------------------------------------------------------------


def test_find_by_content(st: SearchTools) -> None:
    result = st.find_by_content("return a + b")
    assert result.total_matches >= 1
    assert any("main.py" in m.file for m in result.matches)
