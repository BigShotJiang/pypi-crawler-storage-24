"""Tests for OWLMIND plugin system: registry, hooks, protocols."""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock, patch

from owlmind.plugins import PluginRegistry
from owlmind.plugins.base import (
    CustomToolProvider,
    OnErrorHook,
    OnRunDoneHook,
    OnRunStartHook,
    PluginBase,
)
from owlmind.plugins.hooks import (
    ALL_HOOKS,
    CALL_TOOL,
    GET_TOOLS,
    ON_ERROR,
    ON_RUN_DONE,
    ON_RUN_START,
    HookResult,
    plugin_has_hook,
)

# ---------------------------------------------------------------------------
# Helpers — concrete plugin classes for testing
# ---------------------------------------------------------------------------


class GoodPlugin:
    """A well-behaved plugin implementing all hooks."""

    name = "good-plugin"
    version = "1.0.0"

    def __init__(self) -> None:
        self.setup_called = False
        self.teardown_called = False
        self.run_started: list[str] = []
        self.run_done: list[str] = []
        self.errors: list[Exception] = []

    def setup(self, config: dict[str, Any]) -> None:
        self.setup_called = True
        self.config = config

    def teardown(self) -> None:
        self.teardown_called = True

    def on_run_start(self, *, run_id: str, goal: str, **kwargs: Any) -> None:
        self.run_started.append(run_id)

    def on_run_done(self, *, run_id: str, success: bool, summary: str, **kwargs: Any) -> None:
        self.run_done.append(run_id)

    def on_error(self, *, run_id: str, error: Exception, **kwargs: Any) -> None:
        self.errors.append(error)


class MinimalPlugin:
    """Plugin with only name/version and setup/teardown."""

    name = "minimal"
    version = "0.1.0"

    def setup(self, config: dict[str, Any]) -> None:
        pass

    def teardown(self) -> None:
        pass


class ExplodingSetupPlugin:
    """Plugin that raises during setup."""

    name = "exploding-setup"
    version = "0.0.1"

    def setup(self, config: dict[str, Any]) -> None:
        msg = "setup explosion"
        raise RuntimeError(msg)

    def teardown(self) -> None:
        pass


class ExplodingHookPlugin:
    """Plugin that raises during a hook call."""

    name = "exploding-hook"
    version = "0.0.2"

    def setup(self, config: dict[str, Any]) -> None:
        pass

    def teardown(self) -> None:
        pass

    def on_run_start(self, *, run_id: str, goal: str, **kwargs: Any) -> None:
        msg = "hook explosion"
        raise ValueError(msg)


class ToolPlugin:
    """Plugin that provides custom tools."""

    name = "tool-plugin"
    version = "2.0.0"

    def setup(self, config: dict[str, Any]) -> None:
        pass

    def teardown(self) -> None:
        pass

    def get_tools(self) -> list[dict[str, Any]]:
        return [
            {"name": "my_tool", "description": "A custom tool"},
        ]

    def call_tool(self, tool_name: str, arguments: dict[str, Any]) -> Any:
        if tool_name == "my_tool":
            return {"result": "ok"}
        return None


class ExplodingTeardownPlugin:
    """Plugin that raises during teardown."""

    name = "exploding-teardown"
    version = "0.0.3"

    def setup(self, config: dict[str, Any]) -> None:
        pass

    def teardown(self) -> None:
        msg = "teardown explosion"
        raise RuntimeError(msg)


# ---------------------------------------------------------------------------
# Helper to create a mock entry point
# ---------------------------------------------------------------------------


def _make_entry_point(name: str, plugin_cls: type) -> MagicMock:
    ep = MagicMock()
    ep.name = name
    ep.group = "owlmind.plugins"
    ep.load.return_value = plugin_cls
    return ep


# ---------------------------------------------------------------------------
# Tests: Discovery
# ---------------------------------------------------------------------------


class TestDiscovery:
    def test_discover_no_plugins(self) -> None:
        registry = PluginRegistry()
        with patch("owlmind.plugins.registry.importlib.metadata.entry_points", return_value={}):
            names = registry.discover()
        assert names == []

    def test_discover_finds_plugins(self) -> None:
        ep1 = _make_entry_point("alpha", GoodPlugin)
        ep2 = _make_entry_point("beta", MinimalPlugin)

        registry = PluginRegistry()
        with patch(
            "owlmind.plugins.registry.importlib.metadata.entry_points",
            return_value={"owlmind.plugins": [ep1, ep2]},
        ):
            names = registry.discover()

        assert sorted(names) == ["alpha", "beta"]

    def test_discover_returns_list_format(self) -> None:
        """entry_points() may return a SelectableGroups (dict-like) in Python 3.12+."""
        ep = _make_entry_point("gamma", GoodPlugin)
        registry = PluginRegistry()
        with patch(
            "owlmind.plugins.registry.importlib.metadata.entry_points",
            return_value={"owlmind.plugins": [ep]},
        ):
            names = registry.discover()
        assert isinstance(names, list)


# ---------------------------------------------------------------------------
# Tests: Loading
# ---------------------------------------------------------------------------


class TestLoading:
    def test_load_existing_plugin(self) -> None:
        ep = _make_entry_point("good", GoodPlugin)
        registry = PluginRegistry()
        with patch(
            "owlmind.plugins.registry.importlib.metadata.entry_points",
            return_value={"owlmind.plugins": [ep]},
        ):
            registry.discover()

        plugin = registry.load("good")
        assert plugin is not None
        assert plugin.name == "good-plugin"

    def test_load_non_existing_returns_none(self) -> None:
        registry = PluginRegistry()
        result = registry.load("nonexistent")
        assert result is None

    def test_load_all_with_mock_entry_points(self) -> None:
        ep1 = _make_entry_point("p1", GoodPlugin)
        ep2 = _make_entry_point("p2", MinimalPlugin)

        registry = PluginRegistry()
        with patch(
            "owlmind.plugins.registry.importlib.metadata.entry_points",
            return_value={"owlmind.plugins": [ep1, ep2]},
        ):
            loaded = registry.load_all()

        assert sorted(loaded) == ["p1", "p2"]

    def test_load_all_auto_discovers(self) -> None:
        """load_all should call discover() if not done yet."""
        ep = _make_entry_point("auto", MinimalPlugin)
        registry = PluginRegistry()
        with patch(
            "owlmind.plugins.registry.importlib.metadata.entry_points",
            return_value={"owlmind.plugins": [ep]},
        ):
            loaded = registry.load_all()
        assert loaded == ["auto"]

    def test_load_caches_instance(self) -> None:
        ep = _make_entry_point("cached", GoodPlugin)
        registry = PluginRegistry()
        with patch(
            "owlmind.plugins.registry.importlib.metadata.entry_points",
            return_value={"owlmind.plugins": [ep]},
        ):
            registry.discover()

        p1 = registry.load("cached")
        p2 = registry.load("cached")
        assert p1 is p2

    def test_load_failing_entry_point(self) -> None:
        """If ep.load() raises, load returns None gracefully."""
        ep = MagicMock()
        ep.name = "broken"
        ep.group = "owlmind.plugins"
        ep.load.side_effect = ImportError("no such module")

        registry = PluginRegistry()
        with patch(
            "owlmind.plugins.registry.importlib.metadata.entry_points",
            return_value={"owlmind.plugins": [ep]},
        ):
            registry.discover()
            result = registry.load("broken")

        assert result is None


# ---------------------------------------------------------------------------
# Tests: Access
# ---------------------------------------------------------------------------


class TestAccess:
    def test_get_existing_plugin(self) -> None:
        ep = _make_entry_point("x", GoodPlugin)
        registry = PluginRegistry()
        with patch(
            "owlmind.plugins.registry.importlib.metadata.entry_points",
            return_value={"owlmind.plugins": [ep]},
        ):
            registry.discover()
            registry.load("x")

        assert registry.get("x") is not None
        assert registry.get("x").name == "good-plugin"  # type: ignore[union-attr]

    def test_get_non_existing_returns_none(self) -> None:
        registry = PluginRegistry()
        assert registry.get("nope") is None

    def test_list_plugins_format(self) -> None:
        ep = _make_entry_point("fmt", GoodPlugin)
        registry = PluginRegistry()
        with patch(
            "owlmind.plugins.registry.importlib.metadata.entry_points",
            return_value={"owlmind.plugins": [ep]},
        ):
            registry.discover()
            registry.load("fmt")

        items = registry.list_plugins()
        assert len(items) == 1
        info = items[0]
        assert info["name"] == "fmt"
        assert info["version"] == "1.0.0"
        assert isinstance(info["hooks"], list)
        assert ON_RUN_START in info["hooks"]
        assert ON_RUN_DONE in info["hooks"]
        assert ON_ERROR in info["hooks"]

    def test_list_plugins_empty(self) -> None:
        registry = PluginRegistry()
        assert registry.list_plugins() == []


# ---------------------------------------------------------------------------
# Tests: Lifecycle (setup / teardown)
# ---------------------------------------------------------------------------


class TestLifecycle:
    def test_setup_all_calls_setup(self) -> None:
        ep = _make_entry_point("s", GoodPlugin)
        registry = PluginRegistry()
        with patch(
            "owlmind.plugins.registry.importlib.metadata.entry_points",
            return_value={"owlmind.plugins": [ep]},
        ):
            registry.discover()
            registry.load("s")

        registry.setup_all({"key": "value"})
        plugin = registry.get("s")
        assert plugin.setup_called is True  # type: ignore[union-attr]
        assert plugin.config == {"key": "value"}  # type: ignore[union-attr]

    def test_teardown_all_calls_teardown(self) -> None:
        ep = _make_entry_point("t", GoodPlugin)
        registry = PluginRegistry()
        with patch(
            "owlmind.plugins.registry.importlib.metadata.entry_points",
            return_value={"owlmind.plugins": [ep]},
        ):
            registry.discover()
            registry.load("t")

        registry.teardown_all()
        plugin = registry.get("t")
        assert plugin.teardown_called is True  # type: ignore[union-attr]

    def test_setup_all_graceful_on_error(self) -> None:
        """If a plugin raises in setup, other plugins still get set up."""
        ep1 = _make_entry_point("boom", ExplodingSetupPlugin)
        ep2 = _make_entry_point("ok", GoodPlugin)

        registry = PluginRegistry()
        with patch(
            "owlmind.plugins.registry.importlib.metadata.entry_points",
            return_value={"owlmind.plugins": [ep1, ep2]},
        ):
            registry.load_all()

        # Should not raise
        registry.setup_all({})
        # The good plugin should still have been set up
        ok_plugin = registry.get("ok")
        assert ok_plugin is not None
        assert ok_plugin.setup_called is True  # type: ignore[union-attr]

    def test_teardown_all_graceful_on_error(self) -> None:
        """If a plugin raises in teardown, others still get torn down."""
        ep1 = _make_entry_point("boom-td", ExplodingTeardownPlugin)
        ep2 = _make_entry_point("ok-td", GoodPlugin)

        registry = PluginRegistry()
        with patch(
            "owlmind.plugins.registry.importlib.metadata.entry_points",
            return_value={"owlmind.plugins": [ep1, ep2]},
        ):
            registry.load_all()

        # Should not raise
        registry.teardown_all()
        ok_plugin = registry.get("ok-td")
        assert ok_plugin is not None
        assert ok_plugin.teardown_called is True  # type: ignore[union-attr]

    def test_setup_all_with_none_config(self) -> None:
        ep = _make_entry_point("nc", GoodPlugin)
        registry = PluginRegistry()
        with patch(
            "owlmind.plugins.registry.importlib.metadata.entry_points",
            return_value={"owlmind.plugins": [ep]},
        ):
            registry.discover()
            registry.load("nc")

        registry.setup_all(None)
        plugin = registry.get("nc")
        assert plugin.setup_called is True  # type: ignore[union-attr]
        assert plugin.config == {}  # type: ignore[union-attr]


# ---------------------------------------------------------------------------
# Tests: Hook firing
# ---------------------------------------------------------------------------


class TestFireHook:
    def test_fire_hook_matching_plugins(self) -> None:
        ep = _make_entry_point("h", GoodPlugin)
        registry = PluginRegistry()
        with patch(
            "owlmind.plugins.registry.importlib.metadata.entry_points",
            return_value={"owlmind.plugins": [ep]},
        ):
            registry.discover()
            registry.load("h")

        result = registry.fire_hook(ON_RUN_START, run_id="r1", goal="test")
        assert result.ok
        assert result.total == 1
        plugin = registry.get("h")
        assert "r1" in plugin.run_started  # type: ignore[union-attr]

    def test_fire_hook_non_matching_plugins(self) -> None:
        ep = _make_entry_point("m", MinimalPlugin)
        registry = PluginRegistry()
        with patch(
            "owlmind.plugins.registry.importlib.metadata.entry_points",
            return_value={"owlmind.plugins": [ep]},
        ):
            registry.discover()
            registry.load("m")

        result = registry.fire_hook(ON_RUN_START, run_id="r2", goal="noop")
        assert result.ok
        assert result.total == 0

    def test_fire_hook_graceful_on_error(self) -> None:
        ep = _make_entry_point("ex", ExplodingHookPlugin)
        registry = PluginRegistry()
        with patch(
            "owlmind.plugins.registry.importlib.metadata.entry_points",
            return_value={"owlmind.plugins": [ep]},
        ):
            registry.discover()
            registry.load("ex")

        result = registry.fire_hook(ON_RUN_START, run_id="r3", goal="boom")
        assert not result.ok
        assert len(result.errors) == 1
        assert "hook explosion" in result.errors[0]["error"]

    def test_fire_hook_mixed_plugins(self) -> None:
        """One plugin succeeds, another explodes — both recorded."""
        ep_good = _make_entry_point("g", GoodPlugin)
        ep_bad = _make_entry_point("b", ExplodingHookPlugin)

        registry = PluginRegistry()
        with patch(
            "owlmind.plugins.registry.importlib.metadata.entry_points",
            return_value={"owlmind.plugins": [ep_good, ep_bad]},
        ):
            registry.load_all()

        result = registry.fire_hook(ON_RUN_START, run_id="r4", goal="mixed")
        assert result.total == 2
        assert len(result.results) == 1
        assert len(result.errors) == 1

    def test_fire_on_run_done(self) -> None:
        ep = _make_entry_point("d", GoodPlugin)
        registry = PluginRegistry()
        with patch(
            "owlmind.plugins.registry.importlib.metadata.entry_points",
            return_value={"owlmind.plugins": [ep]},
        ):
            registry.discover()
            registry.load("d")

        result = registry.fire_hook(ON_RUN_DONE, run_id="r5", success=True, summary="done")
        assert result.ok
        plugin = registry.get("d")
        assert "r5" in plugin.run_done  # type: ignore[union-attr]

    def test_fire_on_error(self) -> None:
        ep = _make_entry_point("e", GoodPlugin)
        registry = PluginRegistry()
        with patch(
            "owlmind.plugins.registry.importlib.metadata.entry_points",
            return_value={"owlmind.plugins": [ep]},
        ):
            registry.discover()
            registry.load("e")

        err = RuntimeError("test error")
        result = registry.fire_hook(ON_ERROR, run_id="r6", error=err)
        assert result.ok
        plugin = registry.get("e")
        assert err in plugin.errors  # type: ignore[union-attr]


# ---------------------------------------------------------------------------
# Tests: HookResult
# ---------------------------------------------------------------------------


class TestHookResult:
    def test_ok_when_no_errors(self) -> None:
        hr = HookResult(hook="test")
        assert hr.ok

    def test_not_ok_when_errors(self) -> None:
        hr = HookResult(hook="test", errors=[{"plugin": "x", "error": "boom"}])
        assert not hr.ok

    def test_total_count(self) -> None:
        hr = HookResult(
            hook="test",
            results=[{"plugin": "a", "return": None}],
            errors=[{"plugin": "b", "error": "err"}],
        )
        assert hr.total == 2

    def test_empty_result(self) -> None:
        hr = HookResult(hook="test")
        assert hr.total == 0
        assert hr.ok


# ---------------------------------------------------------------------------
# Tests: Hook helpers
# ---------------------------------------------------------------------------


class TestHookHelpers:
    def test_plugin_has_hook_true(self) -> None:
        plugin = GoodPlugin()
        assert plugin_has_hook(plugin, ON_RUN_START)
        assert plugin_has_hook(plugin, ON_RUN_DONE)
        assert plugin_has_hook(plugin, ON_ERROR)

    def test_plugin_has_hook_false(self) -> None:
        plugin = MinimalPlugin()
        assert not plugin_has_hook(plugin, ON_RUN_START)
        assert not plugin_has_hook(plugin, ON_RUN_DONE)

    def test_all_hooks_constant(self) -> None:
        assert ON_RUN_START in ALL_HOOKS
        assert ON_RUN_DONE in ALL_HOOKS
        assert ON_ERROR in ALL_HOOKS
        assert GET_TOOLS in ALL_HOOKS
        assert CALL_TOOL in ALL_HOOKS


# ---------------------------------------------------------------------------
# Tests: Protocol conformance
# ---------------------------------------------------------------------------


class TestProtocols:
    def test_good_plugin_is_plugin_base(self) -> None:
        plugin = GoodPlugin()
        assert isinstance(plugin, PluginBase)

    def test_good_plugin_is_on_run_start(self) -> None:
        plugin = GoodPlugin()
        assert isinstance(plugin, OnRunStartHook)

    def test_good_plugin_is_on_run_done(self) -> None:
        plugin = GoodPlugin()
        assert isinstance(plugin, OnRunDoneHook)

    def test_good_plugin_is_on_error(self) -> None:
        plugin = GoodPlugin()
        assert isinstance(plugin, OnErrorHook)

    def test_tool_plugin_is_custom_tool_provider(self) -> None:
        plugin = ToolPlugin()
        assert isinstance(plugin, CustomToolProvider)

    def test_tool_plugin_get_tools(self) -> None:
        plugin = ToolPlugin()
        tools = plugin.get_tools()
        assert len(tools) == 1
        assert tools[0]["name"] == "my_tool"

    def test_tool_plugin_call_tool(self) -> None:
        plugin = ToolPlugin()
        result = plugin.call_tool("my_tool", {})
        assert result == {"result": "ok"}

    def test_minimal_plugin_not_tool_provider(self) -> None:
        plugin = MinimalPlugin()
        assert not isinstance(plugin, CustomToolProvider)

    def test_fire_get_tools_hook(self) -> None:
        ep = _make_entry_point("tp", ToolPlugin)
        registry = PluginRegistry()
        with patch(
            "owlmind.plugins.registry.importlib.metadata.entry_points",
            return_value={"owlmind.plugins": [ep]},
        ):
            registry.discover()
            registry.load("tp")

        result = registry.fire_hook(GET_TOOLS)
        assert result.ok
        assert result.total == 1
        tools = result.results[0]["return"]
        assert len(tools) == 1
        assert tools[0]["name"] == "my_tool"
