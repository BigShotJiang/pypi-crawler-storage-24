"""Tests for owlmind.monitoring.structured_log module.

Covers both structlog-available and structlog-unavailable paths.
"""

from __future__ import annotations

import logging
import sys
import types
from io import StringIO
from unittest.mock import MagicMock, patch

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _reload_module():
    """Force reload of structured_log so HAS_STRUCTLOG is re-evaluated."""
    import importlib

    import owlmind.monitoring.structured_log as m

    importlib.reload(m)
    return m


# ---------------------------------------------------------------------------
# Tests: structlog NOT installed (fallback path)
# ---------------------------------------------------------------------------


class TestWithoutStructlog:
    """Verify behavior when structlog is not installed."""

    def test_has_structlog_false_when_missing(self, monkeypatch):
        """HAS_STRUCTLOG is False when structlog import fails."""
        monkeypatch.setitem(sys.modules, "structlog", None)
        mod = _reload_module()
        assert mod.HAS_STRUCTLOG is False

    def test_configure_falls_back_to_setup_logging(self, monkeypatch):
        """configure_structured_logging calls setup_logging() as fallback."""
        monkeypatch.setitem(sys.modules, "structlog", None)
        mod = _reload_module()

        called_with: dict = {}

        def fake_setup(level="WARNING", json_format=True, stream=None):
            called_with.update(level=level, json_format=json_format, stream=stream)

        with patch("owlmind.logging_config.setup_logging", fake_setup):
            buf = StringIO()
            mod.configure_structured_logging(level="DEBUG", json_format=False, stream=buf)

        assert called_with == {"level": "DEBUG", "json_format": False, "stream": buf}

    def test_configure_default_args(self, monkeypatch):
        """configure_structured_logging passes defaults to setup_logging."""
        monkeypatch.setitem(sys.modules, "structlog", None)
        mod = _reload_module()

        called_with: dict = {}

        def fake_setup(level="WARNING", json_format=True, stream=None):
            called_with.update(level=level, json_format=json_format, stream=stream)

        with patch("owlmind.logging_config.setup_logging", fake_setup):
            mod.configure_structured_logging()

        assert called_with["level"] == "WARNING"
        assert called_with["json_format"] is True
        assert called_with["stream"] is None

    def test_get_logger_returns_stdlib_logger(self, monkeypatch):
        """get_logger returns stdlib logger when structlog not installed."""
        monkeypatch.setitem(sys.modules, "structlog", None)
        mod = _reload_module()
        log = mod.get_logger("test.ns")
        assert isinstance(log, logging.Logger)
        assert log.name == "test.ns"


# ---------------------------------------------------------------------------
# Tests: structlog IS installed (full path with mocks)
# ---------------------------------------------------------------------------


def _make_fake_structlog():
    """Build a minimal fake structlog module that satisfies configure_structured_logging."""
    sl = types.ModuleType("structlog")

    # contextvars sub-module
    cv = types.ModuleType("structlog.contextvars")
    cv.merge_contextvars = MagicMock(name="merge_contextvars")
    sl.contextvars = cv

    # stdlib sub-module
    stdlib = types.ModuleType("structlog.stdlib")
    stdlib.add_log_level = MagicMock(name="add_log_level")
    stdlib.add_logger_name = MagicMock(name="add_logger_name")
    stdlib.LoggerFactory = MagicMock(name="LoggerFactory")
    stdlib.BoundLogger = MagicMock(name="BoundLogger")
    stdlib.ProcessorFormatter = MagicMock(name="ProcessorFormatter")
    stdlib.ProcessorFormatter.wrap_for_formatter = MagicMock()
    stdlib.ProcessorFormatter.remove_processors_meta = MagicMock()
    sl.stdlib = stdlib

    # processors sub-module
    proc = types.ModuleType("structlog.processors")
    proc.TimeStamper = MagicMock(return_value=MagicMock(name="timestamper"))
    proc.StackInfoRenderer = MagicMock(return_value=MagicMock(name="stack_info"))
    proc.UnicodeDecoder = MagicMock(return_value=MagicMock(name="unicode_decoder"))
    proc.JSONRenderer = MagicMock(return_value=MagicMock(name="json_renderer"))
    sl.processors = proc

    # dev sub-module
    dev = types.ModuleType("structlog.dev")
    dev.ConsoleRenderer = MagicMock(return_value=MagicMock(name="console_renderer"))
    sl.dev = dev

    # top-level functions
    sl.configure = MagicMock(name="structlog.configure")
    sl.get_logger = MagicMock(name="structlog.get_logger", return_value=MagicMock())

    return sl


class TestWithStructlog:
    """Verify behavior when structlog is installed (using a fake module)."""

    def setup_method(self):
        self.fake_sl = _make_fake_structlog()

    def _patch_structlog(self, monkeypatch):
        monkeypatch.setitem(sys.modules, "structlog", self.fake_sl)
        for attr in (
            "structlog.contextvars",
            "structlog.stdlib",
            "structlog.processors",
            "structlog.dev",
        ):
            monkeypatch.setitem(sys.modules, attr, getattr(self.fake_sl, attr.split(".")[-1]))
        return _reload_module()

    def test_has_structlog_true(self, monkeypatch):
        mod = self._patch_structlog(monkeypatch)
        assert mod.HAS_STRUCTLOG is True

    def test_configure_calls_structlog_configure(self, monkeypatch):
        mod = self._patch_structlog(monkeypatch)
        buf = StringIO()
        mod.configure_structured_logging(level="INFO", json_format=True, stream=buf)
        assert self.fake_sl.configure.called

    def test_configure_json_renderer(self, monkeypatch):
        mod = self._patch_structlog(monkeypatch)
        buf = StringIO()
        mod.configure_structured_logging(level="DEBUG", json_format=True, stream=buf)
        assert self.fake_sl.processors.JSONRenderer.called
        assert not self.fake_sl.dev.ConsoleRenderer.called

    def test_configure_console_renderer(self, monkeypatch):
        mod = self._patch_structlog(monkeypatch)
        buf = StringIO()
        mod.configure_structured_logging(level="DEBUG", json_format=False, stream=buf)
        assert self.fake_sl.dev.ConsoleRenderer.called
        assert not self.fake_sl.processors.JSONRenderer.called

    def test_configure_sets_log_level_on_owlmind_logger(self, monkeypatch):
        mod = self._patch_structlog(monkeypatch)
        buf = StringIO()
        mod.configure_structured_logging(level="ERROR", json_format=True, stream=buf)
        root = logging.getLogger("owlmind")
        assert root.level == logging.ERROR

    def test_configure_uses_stderr_by_default(self, monkeypatch):
        """When stream=None, sys.stderr is used (no error)."""
        mod = self._patch_structlog(monkeypatch)
        # Should not raise even without explicit stream
        mod.configure_structured_logging(level="WARNING", json_format=True)

    def test_get_logger_returns_structlog_logger(self, monkeypatch):
        mod = self._patch_structlog(monkeypatch)
        log = mod.get_logger("my.module")
        assert self.fake_sl.get_logger.called
        # Return value comes from fake structlog
        assert log is self.fake_sl.get_logger.return_value
