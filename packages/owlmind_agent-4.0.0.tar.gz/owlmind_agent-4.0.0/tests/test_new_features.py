"""Unit tests for recently added features in owlmind.

Covers:
- context_finder.find_relevant_files
- HITL CycleState and WorkerRequest.relevant_files
- cycle_worker._build_worker_prompt
- llm.complexity classify_goal / provider_for_complexity
- operator.RunInfo pr_url / cost_summary fields
- telegram.helpers._format_event_message
"""

from __future__ import annotations

import os

# ---------------------------------------------------------------------------
# 1. context_finder tests
# ---------------------------------------------------------------------------


def test_find_relevant_files_empty_goal():
    from owlmind.agent.context_finder import find_relevant_files

    result = find_relevant_files("", "/tmp")
    assert result == []


def test_find_relevant_files_bad_workspace():
    from owlmind.agent.context_finder import find_relevant_files

    result = find_relevant_files("fix ruff errors", "/nonexistent/path/xyz")
    assert result == []


def test_find_relevant_files_returns_list():
    from owlmind.agent.context_finder import find_relevant_files

    workspace = os.path.expanduser("~/charwiz/src")
    result = find_relevant_files("fix ruff linting errors", workspace, max_files=3)
    assert isinstance(result, list)
    for item in result:
        assert "path" in item
        assert "score" in item
        assert "snippet" in item
        assert item["score"] >= 1


# ---------------------------------------------------------------------------
# 2. HITL state and CycleState tests
# ---------------------------------------------------------------------------


def test_wait_hitl_approval_state_exists():
    from owlmind.agent.schemas import CycleState

    assert CycleState.WAIT_HITL_APPROVAL == "WAIT_HITL_APPROVAL"
    assert "WAIT_HITL_APPROVAL" in [s.value for s in CycleState]


def test_worker_request_has_relevant_files():
    from owlmind.agent.schemas import WorkerRequest

    req = WorkerRequest(
        run_id="test-123",
        iteration=1,
        worker_instructions="Do something",
        relevant_files=[{"path": "foo.py", "score": 2, "snippet": "hello"}],
    )
    assert len(req.relevant_files) == 1
    assert req.relevant_files[0]["path"] == "foo.py"


def test_worker_request_relevant_files_default_empty():
    from owlmind.agent.schemas import WorkerRequest

    req = WorkerRequest(run_id="x", iteration=1, worker_instructions="test")
    assert req.relevant_files == []


# ---------------------------------------------------------------------------
# 3. cycle_worker prompt tests
# ---------------------------------------------------------------------------


def test_worker_prompt_shows_relevant_files():
    from owlmind.agent.cycle_worker import _build_worker_prompt
    from owlmind.agent.schemas import WorkerRequest

    req = WorkerRequest(
        run_id="abc",
        iteration=2,
        worker_instructions="Fix bugs",
        relevant_files=[
            {"path": "src/foo.py", "score": 3, "snippet": "def foo(): pass"},
            {"path": "src/bar.py", "score": 1, "snippet": "x = 1"},
        ],
    )
    prompt = _build_worker_prompt(req)
    assert "Relevant Files" in prompt
    assert "src/foo.py" in prompt
    assert "score: 3" in prompt
    assert "def foo(): pass" in prompt


def test_worker_prompt_no_relevant_files_section_when_empty():
    from owlmind.agent.cycle_worker import _build_worker_prompt
    from owlmind.agent.schemas import WorkerRequest

    req = WorkerRequest(run_id="abc", iteration=1, worker_instructions="Do it")
    prompt = _build_worker_prompt(req)
    assert "Relevant Files" not in prompt


# ---------------------------------------------------------------------------
# 4. complexity classifier tests
# ---------------------------------------------------------------------------


def test_classify_simple_goal():
    from owlmind.llm.complexity import classify_goal

    assert classify_goal("fix typo in README") == "simple"
    assert classify_goal("add docstring to utils") == "simple"
    assert classify_goal("hi") == "simple"  # short


def test_classify_complex_goal():
    from owlmind.llm.complexity import classify_goal

    assert classify_goal("refactor the auth module") == "complex"
    assert classify_goal("migrate the database schema") == "complex"


def test_classify_medium_goal():
    from owlmind.llm.complexity import classify_goal

    result = classify_goal("add unit tests for the payment module")
    assert result in ("medium", "simple", "complex")  # just check it runs


def test_provider_for_complexity():
    from owlmind.llm.complexity import provider_for_complexity

    assert provider_for_complexity("medium") is None  # no routing for medium
    # simple and complex should return a string or None (not crash)
    result = provider_for_complexity("simple")
    assert result is None or isinstance(result, str)


# ---------------------------------------------------------------------------
# 5. RunInfo fields test
# ---------------------------------------------------------------------------


def test_run_info_has_pr_url_and_cost():
    from owlmind.operator import RunInfo

    info = RunInfo(run_id="abc", goal="test", workspace=".")
    assert hasattr(info, "pr_url")
    assert hasattr(info, "cost_summary")
    assert info.pr_url == ""
    assert info.cost_summary == ""


def test_run_info_with_values():
    from owlmind.operator import RunInfo

    info = RunInfo(
        run_id="abc",
        goal="test",
        workspace=".",
        pr_url="https://github.com/x/y/pull/1",
        cost_summary="5,000 tokens | ~$0.001",
    )
    assert info.pr_url == "https://github.com/x/y/pull/1"
    assert "5,000" in info.cost_summary


# ---------------------------------------------------------------------------
# 6. Event message formatter tests
# ---------------------------------------------------------------------------


def test_format_auto_committed_with_pr_url():
    from owlmind.telegram.helpers import _format_event_message

    msg = _format_event_message(
        "auto_committed",
        {
            "run_id": "abc123",
            "diff_stat": "file.py | 5 +++\n1 file changed",
            "pr_url": "https://github.com/x/y/pull/42",
        },
    )
    assert "запушены" in msg
    assert "PR: https://github.com/x/y/pull/42" in msg


def test_format_judge_done_approved():
    from owlmind.telegram.helpers import _format_event_message

    msg = _format_event_message(
        "llm_judge_done",
        {
            "run_id": "abc",
            "verdict": "APPROVED",
            "total_tokens": 8000,
        },
    )
    assert "APPROVED" in msg
    assert "8,000" in msg
    assert "✅" in msg


def test_format_judge_done_needs_fix():
    from owlmind.telegram.helpers import _format_event_message

    msg = _format_event_message(
        "llm_judge_done",
        {
            "run_id": "abc",
            "verdict": "NEEDS_FIX",
            "total_tokens": 3000,
        },
    )
    assert "NEEDS_FIX" in msg
    assert "🔄" in msg


# ---------------------------------------------------------------------------
# 7. task_splitter tests
# ---------------------------------------------------------------------------


def test_split_goal_empty_returns_empty():
    from owlmind.agent.task_splitter import split_goal

    assert split_goal("") == []
    assert split_goal("   ") == []


def test_split_goal_no_driver_returns_original():
    from owlmind.agent.task_splitter import split_goal

    result = split_goal("refactor the auth module")
    assert result == ["refactor the auth module"]


def test_split_goal_llm_driver_used():
    from owlmind.agent.task_splitter import split_goal

    class FakeDriver:
        def complete(self, system: str, user: str) -> str:
            return "1. Fix type hints in auth.py\n2. Add docstrings to auth.py\n3. Write tests"

    result = split_goal("improve the auth module", llm_driver=FakeDriver(), max_subtasks=4)
    assert len(result) == 3
    assert result[0] == "Fix type hints in auth.py"
    assert result[2] == "Write tests"


def test_split_goal_max_subtasks_respected():
    from owlmind.agent.task_splitter import split_goal

    class FakeDriver:
        def complete(self, system: str, user: str) -> str:
            return "1. Task A\n2. Task B\n3. Task C\n4. Task D\n5. Task E"

    result = split_goal("big goal", llm_driver=FakeDriver(), max_subtasks=2)
    assert len(result) == 2


def test_split_goal_llm_error_fallback():
    from owlmind.agent.task_splitter import split_goal

    class BrokenDriver:
        def complete(self, system: str, user: str) -> str:
            raise RuntimeError("API error")

    result = split_goal("some goal", llm_driver=BrokenDriver())
    assert result == ["some goal"]


def test_parse_numbered_list_formats():
    from owlmind.agent.task_splitter import _parse_numbered_list

    text = "1. First task\n2) Second task\n- Third task\n\n4. Fourth task"
    result = _parse_numbered_list(text)
    assert result == ["First task", "Second task", "Third task", "Fourth task"]


def test_parse_numbered_list_empty():
    from owlmind.agent.task_splitter import _parse_numbered_list

    assert _parse_numbered_list("") == []
    assert _parse_numbered_list("no list items here") == []


# ---------------------------------------------------------------------------
# 8. SWE-bench models and loader tests
# ---------------------------------------------------------------------------


def test_swe_instance_from_dict():
    from owlmind.bench.models import SWEInstance

    d = {
        "instance_id": "django__django-1234",
        "repo": "django/django",
        "base_commit": "abc123",
        "problem_statement": "Fix bug in ORM",
        "FAIL_TO_PASS": ["tests/test_orm.py::TestQuery::test_filter"],
        "PASS_TO_PASS": ["tests/test_orm.py::TestQuery::test_basic"],
    }
    inst = SWEInstance.from_dict(d)
    assert inst.instance_id == "django__django-1234"
    assert inst.repo == "django/django"
    assert inst.base_commit == "abc123"
    assert len(inst.fail_to_pass) == 1
    assert len(inst.pass_to_pass) == 1


def test_swe_instance_from_dict_defaults():
    from owlmind.bench.models import SWEInstance

    inst = SWEInstance.from_dict({"instance_id": "x", "repo": "a/b", "base_commit": "c", "problem_statement": "p"})
    assert inst.hints_text == ""
    assert inst.fail_to_pass == []
    assert inst.patch == ""


def test_bench_result_resolved():
    from owlmind.bench.models import BenchResult

    r = BenchResult(instance_id="x", repo="a/b", status="passed")
    assert r.resolved is True

    r2 = BenchResult(instance_id="x", repo="a/b", status="failed")
    assert r2.resolved is False


def test_bench_report_pass_at_1():
    from owlmind.bench.models import BenchReport, BenchResult

    report = BenchReport(
        results=[],
        total=10,
        passed=3,
        failed=5,
        errors=2,
    )
    assert abs(report.pass_at_1 - 0.3) < 0.001
    assert "3/10" in report.summary()
    assert "30.0%" in report.summary()


def test_bench_report_empty():
    from owlmind.bench.models import BenchReport

    report = BenchReport()
    assert report.pass_at_1 == 0.0


def test_load_instances_from_jsonl(tmp_path):
    import json
    from owlmind.bench.loader import load_instances

    instances_data = [
        {"instance_id": "repo__proj-1", "repo": "r/p", "base_commit": "aaa", "problem_statement": "Fix A"},
        {"instance_id": "repo__proj-2", "repo": "r/p", "base_commit": "bbb", "problem_statement": "Fix B"},
        {"instance_id": "repo__proj-3", "repo": "r/p", "base_commit": "ccc", "problem_statement": "Fix C"},
    ]
    f = tmp_path / "instances.jsonl"
    f.write_text("\n".join(json.dumps(d) for d in instances_data))

    result = load_instances(str(f))
    assert len(result) == 3
    assert result[0].instance_id == "repo__proj-1"


def test_load_instances_limit(tmp_path):
    import json
    from owlmind.bench.loader import load_instances

    data = [{"instance_id": f"x-{i}", "repo": "a/b", "base_commit": "c", "problem_statement": "p"} for i in range(5)]
    f = tmp_path / "instances.jsonl"
    f.write_text("\n".join(json.dumps(d) for d in data))

    result = load_instances(str(f), limit=2)
    assert len(result) == 2


def test_load_instances_filter_ids(tmp_path):
    import json
    from owlmind.bench.loader import load_instances

    data = [{"instance_id": f"proj-{i}", "repo": "a/b", "base_commit": "c", "problem_statement": "p"} for i in range(4)]
    f = tmp_path / "instances.jsonl"
    f.write_text("\n".join(json.dumps(d) for d in data))

    result = load_instances(str(f), instance_ids=["proj-1", "proj-3"])
    assert len(result) == 2
    assert {r.instance_id for r in result} == {"proj-1", "proj-3"}


def test_bench_harness_save_report(tmp_path):
    from owlmind.bench.harness import BenchHarness
    from owlmind.bench.models import BenchReport, BenchResult

    report = BenchReport(
        results=[
            BenchResult(instance_id="a-1", repo="a/b", status="passed", run_id="r1", duration_ms=500),
            BenchResult(instance_id="a-2", repo="a/b", status="failed", error="timeout"),
        ],
        total=2,
        passed=1,
        failed=1,
    )

    out = tmp_path / "report.json"
    BenchHarness.save_report(report, out)

    import json
    data = json.loads(out.read_text())
    assert data["total"] == 2
    assert data["passed"] == 1
    assert abs(data["pass_at_1"] - 0.5) < 0.001
    assert len(data["results"]) == 2
    assert data["results"][0]["instance_id"] == "a-1"


# ---------------------------------------------------------------------------
# 9. Web dashboard analytics and SSE tests
# ---------------------------------------------------------------------------


def test_analytics_costs_no_runs_dir(tmp_path):
    """GET /api/analytics/costs returns empty result when no runs dir."""
    from unittest.mock import patch
    import sys
    import importlib

    # Ensure the module is loaded
    mod = sys.modules.get("owlmind.web.app") or importlib.import_module("owlmind.web.app")
    from fastapi.testclient import TestClient

    runs_mod = sys.modules.get("owlmind.web.runs") or importlib.import_module("owlmind.web.runs")
    with patch.object(runs_mod, "_get_runs_dir", return_value=None):
        client = TestClient(mod.app)
        r = client.get("/api/analytics/costs")
        assert r.status_code == 200
        data = r.json()
        assert data["total_tokens"] == 0
        assert data["total_usd"] == 0.0
        assert data["daily"] == []


def test_analytics_costs_with_events(tmp_path):
    """GET /api/analytics/costs aggregates LLM_USAGE_RECORDED events."""
    import json
    import sys
    import importlib
    from datetime import UTC, datetime
    from unittest.mock import patch

    mod = sys.modules.get("owlmind.web.app") or importlib.import_module("owlmind.web.app")

    runs_dir = tmp_path / "runs"
    run_dir = runs_dir / "run-abc"
    run_dir.mkdir(parents=True)

    today = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%S+00:00")
    events = [
        {"event": "LLM_USAGE_RECORDED", "timestamp": today, "total_tokens": 1000, "estimated_usd": 0.002, "stage": "planner"},
        {"event": "LLM_USAGE_RECORDED", "timestamp": today, "total_tokens": 500, "estimated_usd": 0.001, "stage": "judge"},
        {"event": "SOME_OTHER_EVENT", "timestamp": today},
    ]
    (run_dir / "run.jsonl").write_text("\n".join(json.dumps(e) for e in events))

    from fastapi.testclient import TestClient
    runs_mod = sys.modules.get("owlmind.web.runs") or importlib.import_module("owlmind.web.runs")
    with patch.object(runs_mod, "_get_runs_dir", return_value=runs_dir):
        client = TestClient(mod.app)
        r = client.get("/api/analytics/costs?days=30")
        assert r.status_code == 200
        data = r.json()
        assert data["total_tokens"] == 1500
        assert abs(data["total_usd"] - 0.003) < 0.0001
        assert len(data["daily"]) == 1
        assert data["daily"][0]["tokens"] == 1500
        assert data["daily"][0]["calls"] == 2


def test_run_cost_endpoint(tmp_path):
    """GET /api/runs/{run_id}/cost returns per-stage breakdown."""
    import json
    import sys
    import importlib
    from datetime import UTC, datetime
    from unittest.mock import patch

    mod = sys.modules.get("owlmind.web.app") or importlib.import_module("owlmind.web.app")

    runs_dir = tmp_path / "runs"
    run_dir = runs_dir / "run-xyz"
    run_dir.mkdir(parents=True)

    today = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%S+00:00")
    events = [
        {"event": "LLM_USAGE_RECORDED", "timestamp": today, "total_tokens": 800, "estimated_usd": 0.0016, "stage": "planner"},
        {"event": "LLM_USAGE_RECORDED", "timestamp": today, "total_tokens": 400, "estimated_usd": 0.0008, "stage": "judge"},
    ]
    (run_dir / "run.jsonl").write_text("\n".join(json.dumps(e) for e in events))

    from fastapi.testclient import TestClient
    runs_mod = sys.modules.get("owlmind.web.runs") or importlib.import_module("owlmind.web.runs")
    with patch.object(runs_mod, "_get_runs_dir", return_value=runs_dir):
        client = TestClient(mod.app)
        r = client.get("/api/runs/run-xyz/cost")
        assert r.status_code == 200
        data = r.json()
        assert data["total_tokens"] == 1200
        assert data["llm_calls"] == 2
        assert "planner" in data["by_stage"]
        assert data["by_stage"]["planner"]["tokens"] == 800
        assert data["by_stage"]["judge"]["calls"] == 1


# ---------------------------------------------------------------------------
# 10. Web route tests — /health and /landing
# ---------------------------------------------------------------------------


def test_health_endpoint():
    """GET /health returns HTTP 200 and JSON body {"status": "ok"}."""
    import sys
    import importlib

    mod = sys.modules.get("owlmind.web.app") or importlib.import_module("owlmind.web.app")
    from fastapi.testclient import TestClient

    client = TestClient(mod.app)
    r = client.get("/health")
    assert r.status_code == 200
    data = r.json()
    assert data["status"] == "ok"


def test_landing_endpoint():
    """GET /landing returns HTTP 200 and HTML containing 'OwlMind'."""
    import sys
    import importlib

    mod = sys.modules.get("owlmind.web.app") or importlib.import_module("owlmind.web.app")
    from fastapi.testclient import TestClient

    client = TestClient(mod.app)
    r = client.get("/landing")
    assert r.status_code == 200
    assert "text/html" in r.headers.get("content-type", "")
    assert "OwlMind" in r.text
