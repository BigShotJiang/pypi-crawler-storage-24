"""Tests for LLM router state machine (provider health tracking)."""

from __future__ import annotations

import pytest


class _FakeDriver:
    """Minimal LLM driver stub."""

    def __init__(self, name: str, *, fail: bool = False, transient: bool = False):
        self._name = name
        self._fail = fail
        self._transient = transient

    @property
    def name(self) -> str:
        return self._name

    @property
    def supports_structured(self) -> bool:
        return True

    def plan(self, req: dict, schema: dict) -> tuple[dict, dict]:
        if self._fail:
            msg = "rate limit exceeded" if self._transient else "auth failed"
            raise RuntimeError(msg)
        return {"result": "ok"}, {"provider": self._name}

    def judge(self, req: dict, schema: dict) -> tuple[dict, dict]:
        return self.plan(req, schema)


class TestRouterStateMachine:
    def test_healthy_provider_used_first(self) -> None:
        from owlmind.llm.router import LLMRouter

        d1 = _FakeDriver("openai")
        d2 = _FakeDriver("anthropic")
        router = LLMRouter(
            drivers={"openai": d1, "anthropic": d2},
            planner_providers=["openai", "anthropic"],
            judge_providers=["openai"],
        )
        resp, meta = router.plan({}, {})
        assert resp["result"] == "ok"

    def test_fallback_on_transient_error(self) -> None:
        from owlmind.llm.router import LLMRouter

        d1 = _FakeDriver("openai", fail=True, transient=True)
        d2 = _FakeDriver("anthropic")
        router = LLMRouter(
            drivers={"openai": d1, "anthropic": d2},
            planner_providers=["openai", "anthropic"],
            judge_providers=["openai", "anthropic"],
        )
        resp, meta = router.plan({}, {})
        assert resp["result"] == "ok"
        assert any(a["provider"] == "openai" and a["status"] == "failed" for a in meta["attempts"])

    def test_all_providers_fail_raises(self) -> None:
        from owlmind.llm.router import LLMRouter

        d1 = _FakeDriver("openai", fail=True, transient=True)
        d2 = _FakeDriver("anthropic", fail=True, transient=True)
        router = LLMRouter(
            drivers={"openai": d1, "anthropic": d2},
            planner_providers=["openai", "anthropic"],
            judge_providers=["openai"],
        )
        with pytest.raises(RuntimeError, match="All providers failed"):
            router.plan({}, {})

    def test_provider_health_tracking(self) -> None:
        from owlmind.llm.router import LLMRouter

        d1 = _FakeDriver("openai", fail=True, transient=True)
        d2 = _FakeDriver("anthropic")
        router = LLMRouter(
            drivers={"openai": d1, "anthropic": d2},
            planner_providers=["openai", "anthropic"],
            judge_providers=["openai", "anthropic"],
        )
        router.plan({}, {})

        health = router.provider_health()
        assert "openai" in health
        assert "anthropic" in health
        # openai should have at least one failure
        assert health["openai"].total_failures >= 1

    def test_force_provider(self) -> None:
        from owlmind.llm.router import LLMRouter

        d1 = _FakeDriver("openai")
        d2 = _FakeDriver("anthropic")
        router = LLMRouter(
            drivers={"openai": d1, "anthropic": d2},
            planner_providers=["openai", "anthropic"],
            judge_providers=["openai"],
        )
        resp, meta = router.plan({}, {}, force_provider="anthropic")
        # Should use anthropic even though openai is first
        attempts = meta.get("attempts", [])
        success = [a for a in attempts if a["status"] == "success"]
        assert any(a["provider"] == "anthropic" for a in success)
