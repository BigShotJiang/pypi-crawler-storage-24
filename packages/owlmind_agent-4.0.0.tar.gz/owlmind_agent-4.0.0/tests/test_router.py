"""Tests for LLM Router — fallback logic, no network calls."""

from __future__ import annotations

from typing import Any

import pytest

from owlmind.llm.retry import is_transient
from owlmind.llm.router import LLMRouter


class FakeDriver:
    """Fake LLM driver for router tests."""

    def __init__(
        self,
        provider_name: str,
        *,
        plan_response: dict[str, Any] | None = None,
        judge_response: dict[str, Any] | None = None,
        error: Exception | None = None,
    ) -> None:
        self._name = provider_name
        self._plan_response = plan_response or {}
        self._judge_response = judge_response or {}
        self._error = error
        self.plan_calls: list[dict[str, Any]] = []
        self.judge_calls: list[dict[str, Any]] = []

    @property
    def name(self) -> str:
        return self._name

    @property
    def supports_structured(self) -> bool:
        return True

    def plan(
        self,
        planner_request: dict[str, Any],
        schema: dict[str, Any],
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        self.plan_calls.append(planner_request)
        if self._error:
            raise self._error
        meta = {"provider": self._name, "model": "test", "latency_ms": 50, "usage": {}}
        return self._plan_response, meta

    def judge(
        self,
        judge_request: dict[str, Any],
        schema: dict[str, Any],
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        self.judge_calls.append(judge_request)
        if self._error:
            raise self._error
        meta = {"provider": self._name, "model": "test", "latency_ms": 50, "usage": {}}
        return self._judge_response, meta


class TestIsTransient:
    def test_timeoutis_transient(self) -> None:
        assert is_transient(RuntimeError("Connection timeout"))

    def test_rate_limitis_transient(self) -> None:
        assert is_transient(RuntimeError("429 rate limit exceeded"))

    def test_server_erroris_transient(self) -> None:
        assert is_transient(RuntimeError("503 Service Unavailable"))

    def test_schema_error_not_transient(self) -> None:
        assert not is_transient(RuntimeError("Invalid JSON schema"))

    def test_auth_error_not_transient(self) -> None:
        assert not is_transient(RuntimeError("401 Unauthorized"))


class TestLLMRouterProperties:
    def test_name(self) -> None:
        router = LLMRouter({}, [], [])
        assert router.name == "router"

    def test_supports_structured(self) -> None:
        router = LLMRouter({}, [], [])
        assert router.supports_structured is True

    def test_available_providers(self) -> None:
        d1 = FakeDriver("openai")
        d2 = FakeDriver("anthropic")
        router = LLMRouter({"openai": d1, "anthropic": d2}, [], [])
        assert set(router.available_providers()) == {"openai", "anthropic"}


class TestLLMRouterPlan:
    def test_routes_to_first_provider(self) -> None:
        d1 = FakeDriver("openai", plan_response={"run_id": "x"})
        d2 = FakeDriver("anthropic", plan_response={"run_id": "y"})
        router = LLMRouter(
            {"openai": d1, "anthropic": d2},
            planner_providers=["openai", "anthropic"],
            judge_providers=["openai"],
        )

        result, meta = router.plan({"run_id": "x"}, {})
        assert result["run_id"] == "x"
        assert meta["provider"] == "openai"
        assert len(d1.plan_calls) == 1
        assert len(d2.plan_calls) == 0

    def test_fallback_on_transient_error(self) -> None:
        d1 = FakeDriver("openai", error=RuntimeError("Connection timeout"))
        d2 = FakeDriver("anthropic", plan_response={"run_id": "fallback"})
        router = LLMRouter(
            {"openai": d1, "anthropic": d2},
            planner_providers=["openai", "anthropic"],
            judge_providers=[],
        )

        result, meta = router.plan({"run_id": "test"}, {})
        assert result["run_id"] == "fallback"
        assert meta["provider"] == "anthropic"
        assert len(meta["attempts"]) == 2
        assert meta["attempts"][0]["status"] == "failed"
        assert meta["attempts"][0]["transient"] is True

    def test_no_fallback_on_non_transient_error(self) -> None:
        d1 = FakeDriver("openai", error=RuntimeError("Invalid schema violation"))
        d2 = FakeDriver("anthropic", plan_response={"run_id": "y"})
        router = LLMRouter(
            {"openai": d1, "anthropic": d2},
            planner_providers=["openai", "anthropic"],
            judge_providers=[],
        )

        with pytest.raises(RuntimeError, match="Invalid schema violation"):
            router.plan({"run_id": "test"}, {})

        # Anthropic should NOT have been called
        assert len(d2.plan_calls) == 0

    def test_skips_unavailable_provider(self) -> None:
        d2 = FakeDriver("anthropic", plan_response={"run_id": "only"})
        router = LLMRouter(
            {"anthropic": d2},
            planner_providers=["openai", "anthropic"],
            judge_providers=[],
        )

        result, meta = router.plan({"run_id": "test"}, {})
        assert result["run_id"] == "only"
        assert meta["provider"] == "anthropic"
        # Router should successfully route to the only available provider
        # openai has no driver, so it is skipped (may not appear in attempts
        # if anthropic succeeds first due to health-based sorting)
        assert any(a["status"] == "success" for a in meta["attempts"])

    def test_all_providers_fail(self) -> None:
        d1 = FakeDriver("openai", error=RuntimeError("timeout error"))
        d2 = FakeDriver("anthropic", error=RuntimeError("timeout error"))
        router = LLMRouter(
            {"openai": d1, "anthropic": d2},
            planner_providers=["openai", "anthropic"],
            judge_providers=[],
        )

        with pytest.raises(RuntimeError, match="All providers failed"):
            router.plan({"run_id": "test"}, {})

    def test_force_provider(self) -> None:
        d1 = FakeDriver("openai", plan_response={"run_id": "oai"})
        d2 = FakeDriver("anthropic", plan_response={"run_id": "ant"})
        router = LLMRouter(
            {"openai": d1, "anthropic": d2},
            planner_providers=["openai", "anthropic"],
            judge_providers=[],
        )

        # Force anthropic even though openai is first in order
        result, meta = router.plan({"run_id": "test"}, {}, force_provider="anthropic")
        assert result["run_id"] == "ant"
        assert meta["provider"] == "anthropic"
        assert len(d1.plan_calls) == 0


class TestLLMRouterJudge:
    def test_routes_judge_independently(self) -> None:
        d1 = FakeDriver("openai", judge_response={"verdict": "APPROVED"})
        d2 = FakeDriver("anthropic", judge_response={"verdict": "REJECTED"})
        router = LLMRouter(
            {"openai": d1, "anthropic": d2},
            planner_providers=["openai"],
            judge_providers=["anthropic", "openai"],
        )

        result, meta = router.judge({"run_id": "test"}, {})
        assert result["verdict"] == "REJECTED"
        assert meta["provider"] == "anthropic"
        assert len(d1.judge_calls) == 0
        assert len(d2.judge_calls) == 1

    def test_judge_fallback(self) -> None:
        d1 = FakeDriver("anthropic", error=RuntimeError("503 unavailable"))
        d2 = FakeDriver("openai", judge_response={"verdict": "APPROVED"})
        router = LLMRouter(
            {"openai": d2, "anthropic": d1},
            planner_providers=[],
            judge_providers=["anthropic", "openai"],
        )

        result, meta = router.judge({"run_id": "test"}, {})
        assert result["verdict"] == "APPROVED"
        assert meta["provider"] == "openai"
