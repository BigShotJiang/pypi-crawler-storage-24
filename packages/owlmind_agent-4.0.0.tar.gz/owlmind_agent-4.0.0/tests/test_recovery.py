"""Tests for owlmind.recovery — error classification and recovery plans."""

from __future__ import annotations

from owlmind.errors import StructuralError, TransientError
from owlmind.recovery import (
    RecoveryClass,
    RecoveryState,
    RecoveryStep,
    build_recovery_plan,
    classify_error,
)


class TestClassifyError:
    def test_transient_error_type(self) -> None:
        exc = TransientError("rate limit exceeded")
        assert classify_error(exc) == RecoveryClass.TRANSIENT

    def test_structural_error_type(self) -> None:
        exc = StructuralError("invalid JSON schema")
        assert classify_error(exc) == RecoveryClass.DETERMINISTIC

    def test_timeout_keyword(self) -> None:
        exc = RuntimeError("Request timed out after 60s")
        assert classify_error(exc) == RecoveryClass.TRANSIENT

    def test_rate_limit_keyword(self) -> None:
        exc = Exception("429 rate_limit exceeded")
        assert classify_error(exc) == RecoveryClass.TRANSIENT

    def test_connection_keyword(self) -> None:
        exc = ConnectionError("Connection refused")
        assert classify_error(exc) == RecoveryClass.TRANSIENT

    def test_unsafe_policy_keyword(self) -> None:
        exc = Exception("Policy blocked this action: forbidden pattern")
        assert classify_error(exc) == RecoveryClass.UNSAFE

    def test_unsafe_secret_keyword(self) -> None:
        exc = Exception("Secret leaked in output")
        assert classify_error(exc) == RecoveryClass.UNSAFE

    def test_unknown_error(self) -> None:
        exc = ValueError("Something unexpected happened")
        assert classify_error(exc) == RecoveryClass.UNKNOWN

    def test_timeout_exception_type(self) -> None:
        class TimeoutError(Exception):
            pass

        exc = TimeoutError("timeout")
        assert classify_error(exc) == RecoveryClass.TRANSIENT

    def test_503_error(self) -> None:
        exc = Exception("HTTP 503 Service Unavailable")
        assert classify_error(exc) == RecoveryClass.TRANSIENT


class TestRecoveryState:
    def test_initial_state(self) -> None:
        state = RecoveryState()
        assert state.can_retry_transient()
        assert state.can_recover()

    def test_transient_budget(self) -> None:
        state = RecoveryState(max_transient_retries=2)
        assert state.can_retry_transient()
        state.transient_retries = 2
        assert not state.can_retry_transient()

    def test_global_budget(self) -> None:
        state = RecoveryState(max_recoveries_per_goal=3)
        state.total_recoveries = 3
        assert not state.can_recover()

    def test_record_attempt(self) -> None:
        from owlmind.recovery import RecoveryPlan

        state = RecoveryState()
        plan = RecoveryPlan(
            classification=RecoveryClass.TRANSIENT,
            steps=[RecoveryStep.RETRY],
            reason="test",
        )
        state.record_attempt(plan)
        assert state.total_recoveries == 1
        assert state.transient_retries == 1
        assert len(state.history) == 1

    def test_history_records_details(self) -> None:
        from owlmind.recovery import RecoveryPlan

        state = RecoveryState()
        plan = RecoveryPlan(
            classification=RecoveryClass.DETERMINISTIC,
            steps=[RecoveryStep.REQUIRE_APPROVAL],
            reason="schema error",
        )
        state.record_attempt(plan)
        assert state.history[0]["classification"] == "DETERMINISTIC"
        assert state.history[0]["reason"] == "schema error"


class TestBuildRecoveryPlan:
    def test_unsafe_always_fails(self) -> None:
        state = RecoveryState()
        exc = Exception("Policy blocked: forbidden pattern detected")
        plan = build_recovery_plan(exc, state)
        assert plan.classification == RecoveryClass.UNSAFE
        assert RecoveryStep.FAIL in plan.steps

    def test_transient_retry(self) -> None:
        state = RecoveryState()
        exc = TransientError("timeout")
        plan = build_recovery_plan(exc, state, context={"stage": "planner"})
        assert plan.classification == RecoveryClass.TRANSIENT
        assert RecoveryStep.RETRY in plan.steps
        assert plan.delay_seconds > 0

    def test_transient_exponential_backoff(self) -> None:
        state = RecoveryState()
        state.transient_retries = 0
        plan1 = build_recovery_plan(TransientError("x"), state)
        state.transient_retries = 2
        plan2 = build_recovery_plan(TransientError("x"), state)
        assert plan2.delay_seconds > plan1.delay_seconds

    def test_transient_switch_provider(self) -> None:
        state = RecoveryState()
        state.transient_retries = 2
        exc = TransientError("timeout")
        plan = build_recovery_plan(exc, state, has_alternative_provider=True)
        assert RecoveryStep.SWITCH_PROVIDER in plan.steps

    def test_transient_retries_exhausted_fail(self) -> None:
        state = RecoveryState(max_transient_retries=2)
        state.transient_retries = 2
        exc = TransientError("timeout")
        plan = build_recovery_plan(exc, state, has_alternative_provider=False)
        assert RecoveryStep.FAIL in plan.steps

    def test_transient_retries_exhausted_switch(self) -> None:
        state = RecoveryState(max_transient_retries=2)
        state.transient_retries = 2
        exc = TransientError("timeout")
        plan = build_recovery_plan(exc, state, has_alternative_provider=True)
        assert RecoveryStep.SWITCH_PROVIDER in plan.steps

    def test_deterministic_worker_subgoal(self) -> None:
        state = RecoveryState()
        exc = StructuralError("Test failures detected")
        plan = build_recovery_plan(exc, state, context={"stage": "worker"})
        assert plan.classification == RecoveryClass.DETERMINISTIC
        assert RecoveryStep.OPEN_SUBGOAL in plan.steps

    def test_deterministic_planner_approval(self) -> None:
        state = RecoveryState()
        exc = StructuralError("Invalid planner schema")
        plan = build_recovery_plan(exc, state, context={"stage": "planner"})
        assert RecoveryStep.REQUIRE_APPROVAL in plan.steps

    def test_unknown_requires_approval(self) -> None:
        state = RecoveryState()
        exc = ValueError("Something weird")
        plan = build_recovery_plan(exc, state)
        assert RecoveryStep.REQUIRE_APPROVAL in plan.steps

    def test_global_budget_exhausted(self) -> None:
        state = RecoveryState(max_recoveries_per_goal=2)
        state.total_recoveries = 2
        exc = TransientError("timeout")
        plan = build_recovery_plan(exc, state)
        assert RecoveryStep.FAIL in plan.steps
        assert "exhausted" in plan.reason.lower()

    def test_delay_bounded(self) -> None:
        state = RecoveryState(max_transient_retries=10)
        state.transient_retries = 8
        exc = TransientError("timeout")
        plan = build_recovery_plan(exc, state)
        assert plan.delay_seconds <= 30.0


class TestClassifyErrorByTypeName:
    """Line 146: exception type name contains 'connection' → TRANSIENT."""

    def test_connection_in_type_name(self) -> None:
        class ConnectionRefusedError(Exception):
            pass

        exc = ConnectionRefusedError("refused")
        result = classify_error(exc)
        assert result == RecoveryClass.TRANSIENT
