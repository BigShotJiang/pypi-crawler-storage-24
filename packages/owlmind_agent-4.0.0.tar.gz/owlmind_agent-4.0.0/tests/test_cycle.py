"""Tests for CycleManager — manual inbox/outbox cycle."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from owlmind.agent.cycle import CycleManager
from owlmind.agent.schemas import CycleRunMeta, CycleState, PlannerResponse, WorkerReport
from owlmind.evidence import EvidenceStore
from owlmind.policy import PolicyEngine

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_manager(tmp_path: Path) -> CycleManager:
    """Create a CycleManager backed by tmp_path with real policies."""
    policies_dir = tmp_path / "policies"
    policies_dir.mkdir()

    # Minimal allowlist
    (policies_dir / "allowlist.yaml").write_text(
        "allowed_commands:\n"
        '  - "^echo "\n'
        '  - "^pytest"\n'
        '  - "^ruff check"\n'
        '  - "^mypy"\n'
        '  - "^git status"\n'
        '  - "^git diff"\n'
        '  - "^ls"\n'
    )
    (policies_dir / "policy.yaml").write_text(
        "forbidden_patterns:\n"
        '  - "rm -rf"\n'
        '  - "sudo"\n'
        '  - ";\\\\s"\n'
        '  - "&&"\n'
        '  - "\\\\|\\\\|"\n'
        "risk_behavior:\n"
        "  CRITICAL: BLOCK\n"
        "  HIGH: ALLOW_WITH_LOG\n"
    )

    policy = PolicyEngine.from_directory(policies_dir)
    evidence = EvidenceStore(tmp_path / "runs")
    return CycleManager(evidence=evidence, policy=policy)


def _write_inbox(tmp_path: Path, run_id: str, filename: str, data: dict) -> None:  # type: ignore[type-arg]
    """Write a JSON file to the inbox directory."""
    inbox = tmp_path / "runs" / run_id / "inbox"
    inbox.mkdir(parents=True, exist_ok=True)
    (inbox / filename).write_text(json.dumps(data))


# ---------------------------------------------------------------------------
# Tests — schemas
# ---------------------------------------------------------------------------


class TestCycleSchemas:
    def test_cycle_state_values(self) -> None:
        assert CycleState.STARTED_WAIT_PLANNER == "STARTED_WAIT_PLANNER"
        assert CycleState.WAIT_WORKER == "WAIT_WORKER"
        assert CycleState.WAIT_JUDGE == "WAIT_JUDGE"
        assert CycleState.DONE == "DONE"
        assert CycleState.FAILED == "FAILED"

    def test_planner_response_validation(self) -> None:
        resp = PlannerResponse(
            run_id="test-001",
            iteration=1,
            plan_summary=["Step 1"],
            worker_instructions="Do the thing",
            verify_commands=["pytest -q"],
        )
        assert resp.run_id == "test-001"
        assert resp.worker_instructions == "Do the thing"

    def test_worker_report_validation(self) -> None:
        report = WorkerReport(
            run_id="test-001",
            iteration=1,
            status="READY_FOR_VERIFY",
            done_summary=["Created file.py"],
        )
        assert report.status == "READY_FOR_VERIFY"

    def test_cycle_run_meta_defaults(self) -> None:
        meta = CycleRunMeta(run_id="test-001", goal="Test")
        assert meta.iteration == 1
        assert meta.state == CycleState.STARTED_WAIT_PLANNER
        assert meta.limits.max_iterations == 10


# ---------------------------------------------------------------------------
# Tests — CycleManager
# ---------------------------------------------------------------------------


class TestCycleManager:
    def test_start_creates_run(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Build a hello world app", workspace=str(tmp_path))

        assert meta.state == CycleState.STARTED_WAIT_PLANNER
        assert meta.goal == "Build a hello world app"
        assert meta.iteration == 1
        assert meta.run_id.startswith("cycle-")

        # Check outbox planner prompt exists
        outbox = tmp_path / "runs" / meta.run_id / "outbox"
        assert (outbox / "planner_prompt.md").exists()
        prompt_text = (outbox / "planner_prompt.md").read_text()
        assert "Planner Prompt" in prompt_text
        assert "Build a hello world app" in prompt_text

        # Check cycle_meta.json exists
        meta_path = tmp_path / "runs" / meta.run_id / "cycle_meta.json"
        assert meta_path.exists()

        # Check inbox dir created
        assert (tmp_path / "runs" / meta.run_id / "inbox").is_dir()

    def test_submit_planner_generates_worker_prompt(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Add feature", workspace=str(tmp_path))

        # Write valid planner response to inbox
        planner_resp = {
            "run_id": meta.run_id,
            "iteration": 1,
            "plan_summary": ["Step 1: Create module", "Step 2: Add tests"],
            "worker_instructions": "Create src/feature.py with hello() function",
            "verify_commands": ["pytest -q", "ruff check ."],
            "risk_notes": [],
        }
        _write_inbox(tmp_path, meta.run_id, "planner_response.json", planner_resp)

        updated = mgr.submit_planner(meta.run_id)

        assert updated.state == CycleState.WAIT_WORKER
        assert updated.planner_plan_summary == ["Step 1: Create module", "Step 2: Add tests"]
        assert updated.verify_commands == ["pytest -q", "ruff check ."]

        # Worker prompt should exist
        outbox = tmp_path / "runs" / meta.run_id / "outbox"
        assert (outbox / "worker_prompt.md").exists()
        worker_text = (outbox / "worker_prompt.md").read_text()
        assert "Worker Prompt" in worker_text

    def test_submit_planner_rejects_forbidden_commands(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Add feature", workspace=str(tmp_path))

        # Planner proposes a forbidden verify command
        planner_resp = {
            "run_id": meta.run_id,
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Do something",
            "verify_commands": ["rm -rf /tmp/test"],
            "risk_notes": [],
        }
        _write_inbox(tmp_path, meta.run_id, "planner_response.json", planner_resp)

        with pytest.raises(ValueError, match="non-allowlisted"):
            mgr.submit_planner(meta.run_id)

    def test_submit_planner_wrong_state(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Test", workspace=str(tmp_path))

        # Advance to WAIT_WORKER first
        planner_resp = {
            "run_id": meta.run_id,
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo done"],
            "risk_notes": [],
        }
        _write_inbox(tmp_path, meta.run_id, "planner_response.json", planner_resp)
        mgr.submit_planner(meta.run_id)

        # Now try submitting planner again — wrong state
        _write_inbox(tmp_path, meta.run_id, "planner_response.json", planner_resp)
        with pytest.raises(RuntimeError, match="Expected state"):
            mgr.submit_planner(meta.run_id)

    def test_submit_worker_runs_verify_and_generates_judge(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Test verify", workspace=str(tmp_path))

        # Phase 2: submit planner
        planner_resp = {
            "run_id": meta.run_id,
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Echo hello",
            "verify_commands": ["echo verify-ok"],
            "risk_notes": [],
        }
        _write_inbox(tmp_path, meta.run_id, "planner_response.json", planner_resp)
        mgr.submit_planner(meta.run_id)

        # Phase 3: submit worker
        worker_report = {
            "run_id": meta.run_id,
            "iteration": 1,
            "status": "READY_FOR_VERIFY",
            "done_summary": ["Created hello.py"],
            "questions": [],
            "commands_run": [{"cmd": "echo hello", "exit_code": 0, "summary": "ok"}],
        }
        _write_inbox(tmp_path, meta.run_id, "worker_report.json", worker_report)

        updated = mgr.submit_worker(meta.run_id)

        assert updated.state == CycleState.WAIT_JUDGE
        assert updated.worker_done_summary == ["Created hello.py"]

        # Judge prompt should exist
        outbox = tmp_path / "runs" / meta.run_id / "outbox"
        assert (outbox / "judge_prompt.md").exists()
        judge_text = (outbox / "judge_prompt.md").read_text()
        assert "Judge Prompt" in judge_text

    def test_submit_judge_approved(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Full cycle", workspace=str(tmp_path))

        # Phase 2
        planner_resp = {
            "run_id": meta.run_id,
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        _write_inbox(tmp_path, meta.run_id, "planner_response.json", planner_resp)
        mgr.submit_planner(meta.run_id)

        # Phase 3
        worker_report = {
            "run_id": meta.run_id,
            "iteration": 1,
            "status": "READY_FOR_VERIFY",
            "done_summary": ["Done"],
            "questions": [],
            "commands_run": [],
        }
        _write_inbox(tmp_path, meta.run_id, "worker_report.json", worker_report)
        mgr.submit_worker(meta.run_id)

        # Phase 4: judge approves
        judge_resp = {
            "run_id": meta.run_id,
            "iteration": 1,
            "verdict": "APPROVED",
            "notes": ["Good work"],
            "next_worker_instructions": "",
            "evidence_chain_verified": True,
        }
        _write_inbox(tmp_path, meta.run_id, "judge_response.json", judge_resp)

        final = mgr.submit_judge(meta.run_id)
        assert final.state == CycleState.DONE

        # Summary should be written
        summary = mgr.evidence.read_summary(meta.run_id)
        assert summary["state"] == "DONE"
        assert summary["verdict"] == "APPROVED"

    def test_submit_judge_needs_fix_iterates(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Fixable cycle", workspace=str(tmp_path))

        # Phase 2 + 3
        planner_resp = {
            "run_id": meta.run_id,
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        _write_inbox(tmp_path, meta.run_id, "planner_response.json", planner_resp)
        mgr.submit_planner(meta.run_id)

        worker_report = {
            "run_id": meta.run_id,
            "iteration": 1,
            "status": "READY_FOR_VERIFY",
            "done_summary": ["Done"],
            "questions": [],
            "commands_run": [],
        }
        _write_inbox(tmp_path, meta.run_id, "worker_report.json", worker_report)
        mgr.submit_worker(meta.run_id)

        # Phase 4: judge says NEEDS_FIX
        judge_resp = {
            "run_id": meta.run_id,
            "iteration": 1,
            "verdict": "NEEDS_FIX",
            "notes": ["Missing error handling"],
            "next_worker_instructions": "Add try/except around main()",
            "evidence_chain_verified": True,
        }
        _write_inbox(tmp_path, meta.run_id, "judge_response.json", judge_resp)

        updated = mgr.submit_judge(meta.run_id)
        assert updated.state == CycleState.WAIT_WORKER
        assert updated.iteration == 2

        # New worker prompt should be generated
        outbox = tmp_path / "runs" / meta.run_id / "outbox"
        worker_text = (outbox / "worker_prompt.md").read_text()
        assert "Add try/except" in worker_text

    def test_submit_judge_rejected(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Rejected cycle", workspace=str(tmp_path))

        # Phase 2 + 3
        planner_resp = {
            "run_id": meta.run_id,
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        _write_inbox(tmp_path, meta.run_id, "planner_response.json", planner_resp)
        mgr.submit_planner(meta.run_id)

        worker_report = {
            "run_id": meta.run_id,
            "iteration": 1,
            "status": "READY_FOR_VERIFY",
            "done_summary": ["Done"],
            "questions": [],
            "commands_run": [],
        }
        _write_inbox(tmp_path, meta.run_id, "worker_report.json", worker_report)
        mgr.submit_worker(meta.run_id)

        # Phase 4: judge rejects (evidence_chain_verified=True to test REJECTED path)
        judge_resp = {
            "run_id": meta.run_id,
            "iteration": 1,
            "verdict": "REJECTED",
            "notes": ["Security issue found"],
            "next_worker_instructions": "",
            "evidence_chain_verified": True,
        }
        _write_inbox(tmp_path, meta.run_id, "judge_response.json", judge_resp)

        final = mgr.submit_judge(meta.run_id)
        assert final.state == CycleState.FAILED

        summary = mgr.evidence.read_summary(meta.run_id)
        assert summary["verdict"] == "REJECTED"

    def test_max_iterations_reached(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Max iter test", workspace=str(tmp_path))

        # Force max_iterations = 1 in meta
        loaded_meta = mgr._load_meta(meta.run_id)
        loaded_meta.limits.max_iterations = 1
        mgr._save_meta(loaded_meta)

        # Phase 2 + 3
        planner_resp = {
            "run_id": meta.run_id,
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        _write_inbox(tmp_path, meta.run_id, "planner_response.json", planner_resp)
        mgr.submit_planner(meta.run_id)

        worker_report = {
            "run_id": meta.run_id,
            "iteration": 1,
            "status": "READY_FOR_VERIFY",
            "done_summary": ["Done"],
            "questions": [],
            "commands_run": [],
        }
        _write_inbox(tmp_path, meta.run_id, "worker_report.json", worker_report)
        mgr.submit_worker(meta.run_id)

        # NEEDS_FIX at max iteration -> FAILED
        judge_resp = {
            "run_id": meta.run_id,
            "iteration": 1,
            "verdict": "NEEDS_FIX",
            "notes": ["Still broken"],
            "next_worker_instructions": "Fix it again",
            "evidence_chain_verified": True,
        }
        _write_inbox(tmp_path, meta.run_id, "judge_response.json", judge_resp)

        final = mgr.submit_judge(meta.run_id)
        assert final.state == CycleState.FAILED

    def test_status_returns_meta(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Status test", workspace=str(tmp_path))

        loaded = mgr.status(meta.run_id)
        assert loaded.run_id == meta.run_id
        assert loaded.goal == "Status test"
        assert loaded.state == CycleState.STARTED_WAIT_PLANNER

    def test_next_inbox_hint(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Hint test", workspace=str(tmp_path))

        hint = mgr.next_inbox_hint(meta)
        assert "planner_response.json" in hint
        assert "submit-planner" in hint

    def test_file_override_for_inbox(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Override test", workspace=str(tmp_path))

        # Write planner response to a custom path (not inbox)
        custom_file = tmp_path / "custom_planner.json"
        planner_resp = {
            "run_id": meta.run_id,
            "iteration": 1,
            "plan_summary": ["Custom step"],
            "worker_instructions": "Custom instruction",
            "verify_commands": ["echo custom"],
            "risk_notes": [],
        }
        custom_file.write_text(json.dumps(planner_resp))

        updated = mgr.submit_planner(meta.run_id, file=custom_file)
        assert updated.state == CycleState.WAIT_WORKER
        assert updated.planner_plan_summary == ["Custom step"]

    def test_events_logged_throughout_cycle(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Events test", workspace=str(tmp_path))

        events = mgr.evidence.read_events(meta.run_id)
        assert len(events) >= 1
        event_names = [e["event"] for e in events]
        assert "cycle_start" in event_names


# ---------------------------------------------------------------------------
# New tests targeting previously uncovered lines
# ---------------------------------------------------------------------------


class TestOptionalImportFlags:
    """Lines 47-78: module-level _SKILLS_AVAILABLE / _MEMORY_RETRIEVAL_AVAILABLE /
    _GOAL_REFINER_AVAILABLE / _SMART_VERIFY_AVAILABLE / _COMPLEXITY_AVAILABLE flags."""

    def test_skills_available_flag_is_bool(self) -> None:
        from owlmind.agent import cycle

        assert isinstance(cycle._SKILLS_AVAILABLE, bool)

    def test_memory_retrieval_available_flag_is_bool(self) -> None:
        from owlmind.agent import cycle

        assert isinstance(cycle._MEMORY_RETRIEVAL_AVAILABLE, bool)

    def test_goal_refiner_available_flag_is_bool(self) -> None:
        from owlmind.agent import cycle

        assert isinstance(cycle._GOAL_REFINER_AVAILABLE, bool)

    def test_smart_verify_available_flag_is_bool(self) -> None:
        from owlmind.agent import cycle

        assert isinstance(cycle._SMART_VERIFY_AVAILABLE, bool)

    def test_complexity_available_flag_is_bool(self) -> None:
        from owlmind.agent import cycle

        assert isinstance(cycle._COMPLEXITY_AVAILABLE, bool)


class TestLLMDriverProperty:
    """Lines 147-153: llm_driver property getter/setter proxied to llm_runner."""

    def test_llm_driver_getter_initially_none(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        assert mgr.llm_driver is None

    def test_llm_driver_setter(self, tmp_path: Path) -> None:
        from unittest.mock import MagicMock

        mgr = _make_manager(tmp_path)
        fake_driver = MagicMock()
        mgr.llm_driver = fake_driver
        assert mgr.llm_driver is fake_driver


class TestCaptureGitEvidence:
    """Lines 174-201: _capture_git_evidence skips non-git workspaces."""

    def test_no_git_dir_returns_empty(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Git test", workspace=str(tmp_path))
        # tmp_path has no .git dir
        diff, numstat, files = mgr._capture_git_evidence(meta.run_id, str(tmp_path))
        assert diff == ""
        assert numstat == ""
        assert files == []


class TestStartWithForceComplexity:
    """Lines 221, 226-229: force_complexity sets complexity_routing=True."""

    def test_force_complexity_sets_routing_flag(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(
            goal="complex task",
            workspace=str(tmp_path),
            force_complexity="high",
        )
        assert meta.extra["complexity"] == "high"
        assert meta.extra["complexity_routing"] is True

    def test_no_force_complexity_routing_false(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="simple task", workspace=str(tmp_path))
        assert meta.extra["complexity_routing"] is False


class TestStartWithMemoryStore:
    """Lines 397-401: memory_store triggers memory context retrieval."""

    def test_memory_store_context_used(self, tmp_path: Path) -> None:
        from unittest.mock import MagicMock, patch

        mgr = _make_manager(tmp_path)
        fake_store = MagicMock()

        mgr.memory_store = fake_store

        with (
            patch("owlmind.agent.cycle_manager._MEMORY_RETRIEVAL_AVAILABLE", True),
            patch(
                "owlmind.agent.cycle_manager._build_memory_context", return_value="past experience"
            ) as mock_mem,
        ):
            meta = mgr.start(goal="remember me", workspace=str(tmp_path))

        mock_mem.assert_called_once_with(fake_store, "remember me")
        assert meta.run_id.startswith("cycle-")

    def test_memory_retrieval_exception_swallowed(self, tmp_path: Path) -> None:
        from unittest.mock import MagicMock, patch

        mgr = _make_manager(tmp_path)
        fake_store = MagicMock()
        mgr.memory_store = fake_store

        with (
            patch("owlmind.agent.cycle_manager._MEMORY_RETRIEVAL_AVAILABLE", True),
            patch("owlmind.agent.cycle_manager._build_memory_context", side_effect=RuntimeError("oops")),
        ):
            meta = mgr.start(goal="failing memory", workspace=str(tmp_path))

        # Must still produce a valid meta
        assert meta.state == CycleState.STARTED_WAIT_PLANNER


class TestStartSmartVerifyException:
    """Lines 331-334: _suggest_smart_verify raises → profile fallback used."""

    def test_smart_verify_exception_falls_back_to_profile(self, tmp_path: Path) -> None:
        from unittest.mock import patch

        mgr = _make_manager(tmp_path)

        with (
            patch("owlmind.agent.cycle_manager._SMART_VERIFY_AVAILABLE", True),
            patch(
                "owlmind.agent.cycle_manager._suggest_smart_verify",
                side_effect=RuntimeError("smart verify crashed"),
            ),
        ):
            meta = mgr.start(goal="Fix the tests", workspace=str(tmp_path))

        # Should not raise — exception is caught and fallback used
        assert meta.state == CycleState.STARTED_WAIT_PLANNER
        assert meta.run_id.startswith("cycle-")


class TestStartComplexityException:
    """Lines 346-347: _classify_goal raises → complexity stays at default 'medium'."""

    def test_complexity_exception_uses_default(self, tmp_path: Path) -> None:
        from unittest.mock import patch

        mgr = _make_manager(tmp_path)

        with (
            patch("owlmind.agent.cycle_manager._COMPLEXITY_AVAILABLE", True),
            patch(
                "owlmind.agent.cycle_manager._classify_goal",
                side_effect=ValueError("classification error"),
            ),
        ):
            meta = mgr.start(goal="Add logging", workspace=str(tmp_path))

        # Should not raise — exception caught, complexity defaults to 'medium'
        assert meta.state == CycleState.STARTED_WAIT_PLANNER
        assert meta.extra.get("complexity") == "medium"


class TestStartSmartVerifyUnavailable:
    """Lines 336-337: _SMART_VERIFY_AVAILABLE=False → profile fallback used directly (else branch)."""

    def test_smart_verify_unavailable_uses_profile_directly(self, tmp_path: Path) -> None:
        from unittest.mock import patch

        mgr = _make_manager(tmp_path)

        with patch("owlmind.agent.cycle_manager._SMART_VERIFY_AVAILABLE", False):
            meta = mgr.start(goal="Fix the tests", workspace=str(tmp_path))

        # Should succeed — else branch calls detect_profile directly
        assert meta.state == CycleState.STARTED_WAIT_PLANNER
        assert meta.run_id.startswith("cycle-")


class TestSubmitJudgeChainUnverified:
    """Lines 728-750: judge reports evidence_chain_verified=False -> FAILED."""

    def test_chain_unverified_fails_cycle(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Chain test", workspace=str(tmp_path))

        # Phase 2
        planner_resp = {
            "run_id": meta.run_id,
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        _write_inbox(tmp_path, meta.run_id, "planner_response.json", planner_resp)
        mgr.submit_planner(meta.run_id)

        # Phase 3
        worker_report = {
            "run_id": meta.run_id,
            "iteration": 1,
            "status": "READY_FOR_VERIFY",
            "done_summary": ["Done"],
            "questions": [],
            "commands_run": [],
        }
        _write_inbox(tmp_path, meta.run_id, "worker_report.json", worker_report)
        mgr.submit_worker(meta.run_id)

        # Phase 4: judge says chain not verified
        judge_resp = {
            "run_id": meta.run_id,
            "iteration": 1,
            "verdict": "APPROVED",
            "notes": ["evidence broken"],
            "next_worker_instructions": "",
            "evidence_chain_verified": False,
        }
        _write_inbox(tmp_path, meta.run_id, "judge_response.json", judge_resp)

        final = mgr.submit_judge(meta.run_id)
        assert final.state == CycleState.FAILED
        assert any("evidence_chain_verified" in r for r in final.hard_fail_reasons)


class TestSubmitJudgeUnknownVerdict:
    """Lines 857-859: unknown verdict raises ValueError."""

    def test_unknown_verdict_raises(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Verdict test", workspace=str(tmp_path))

        planner_resp = {
            "run_id": meta.run_id,
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        _write_inbox(tmp_path, meta.run_id, "planner_response.json", planner_resp)
        mgr.submit_planner(meta.run_id)

        worker_report = {
            "run_id": meta.run_id,
            "iteration": 1,
            "status": "READY_FOR_VERIFY",
            "done_summary": ["Done"],
            "questions": [],
            "commands_run": [],
        }
        _write_inbox(tmp_path, meta.run_id, "worker_report.json", worker_report)
        mgr.submit_worker(meta.run_id)

        judge_resp = {
            "run_id": meta.run_id,
            "iteration": 1,
            "verdict": "MAYBE",
            "notes": [],
            "next_worker_instructions": "",
            "evidence_chain_verified": True,
        }
        _write_inbox(tmp_path, meta.run_id, "judge_response.json", judge_resp)

        with pytest.raises(ValueError, match="Unknown verdict"):
            mgr.submit_judge(meta.run_id)


class TestSubmitJudgeWrongState:
    """Line 719-721: submit_judge raises RuntimeError when state != WAIT_JUDGE."""

    def test_wrong_state_raises(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="State check", workspace=str(tmp_path))

        # Still STARTED_WAIT_PLANNER — call submit_judge directly
        with pytest.raises(RuntimeError, match="Expected state WAIT_JUDGE"):
            mgr.submit_judge(meta.run_id)


class TestIngest:
    """Lines 867-903: ingest() routes to correct inbox file based on state."""

    def test_ingest_planner_response(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Ingest test", workspace=str(tmp_path))

        planner_data = {
            "run_id": meta.run_id,
            "iteration": 1,
            "plan_summary": ["Step X"],
            "worker_instructions": "Work",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        file = tmp_path / "planner.json"
        file.write_text(json.dumps(planner_data))

        loaded_meta, target_path = mgr.ingest(meta.run_id, file)
        assert loaded_meta.run_id == meta.run_id
        assert "planner_response.json" in target_path
        assert Path(target_path).exists()

    def test_ingest_invalid_state_raises(self, tmp_path: Path) -> None:
        """DONE state cannot receive ingested files."""
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Done ingest", workspace=str(tmp_path))

        # Force DONE state
        loaded = mgr._load_meta(meta.run_id)
        loaded.state = CycleState.DONE
        mgr._save_meta(loaded)

        file = tmp_path / "dummy.json"
        file.write_text("{}")

        with pytest.raises(RuntimeError, match="Cannot ingest in state"):
            mgr.ingest(meta.run_id, file)


class TestNext:
    """Lines 909-988: next() auto-advances based on inbox file presence."""

    def test_next_waiting_for_planner_no_file(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Next test", workspace=str(tmp_path))

        returned_meta, msg = mgr.next(meta.run_id)
        assert returned_meta.state == CycleState.STARTED_WAIT_PLANNER
        assert "planner_prompt.md" in msg

    def test_next_advances_planner_when_file_present(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Auto planner", workspace=str(tmp_path))

        planner_data = {
            "run_id": meta.run_id,
            "iteration": 1,
            "plan_summary": ["S1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo x"],
            "risk_notes": [],
        }
        _write_inbox(tmp_path, meta.run_id, "planner_response.json", planner_data)

        returned_meta, msg = mgr.next(meta.run_id)
        assert returned_meta.state == CycleState.WAIT_WORKER
        assert "WAIT_WORKER" in msg

    def test_next_waiting_for_worker_no_file(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Wait worker", workspace=str(tmp_path))

        planner_data = {
            "run_id": meta.run_id,
            "iteration": 1,
            "plan_summary": ["S1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo x"],
            "risk_notes": [],
        }
        _write_inbox(tmp_path, meta.run_id, "planner_response.json", planner_data)
        mgr.submit_planner(meta.run_id)

        returned_meta, msg = mgr.next(meta.run_id)
        assert returned_meta.state == CycleState.WAIT_WORKER
        assert "worker_prompt.md" in msg

    def test_next_done_state_returns_complete(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Done next", workspace=str(tmp_path))

        loaded = mgr._load_meta(meta.run_id)
        loaded.state = CycleState.DONE
        mgr._save_meta(loaded)
        mgr.evidence.write_summary(meta.run_id, {"state": "DONE", "verdict": "APPROVED"})

        returned_meta, msg = mgr.next(meta.run_id)
        assert returned_meta.state == CycleState.DONE
        assert "APPROVED" in msg

    def test_next_failed_state_returns_reason(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Failed next", workspace=str(tmp_path))

        loaded = mgr._load_meta(meta.run_id)
        loaded.state = CycleState.FAILED
        mgr._save_meta(loaded)
        mgr.evidence.write_summary(meta.run_id, {"state": "FAILED", "reason": "HARD_FAIL"})

        returned_meta, msg = mgr.next(meta.run_id)
        assert returned_meta.state == CycleState.FAILED
        assert "HARD_FAIL" in msg

    def test_next_wait_approval_state(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Approval next", workspace=str(tmp_path))

        loaded = mgr._load_meta(meta.run_id)
        loaded.state = CycleState.WAIT_APPROVAL
        loaded.extra["pending_approval"] = {"token": "tok-abc", "reason": "high risk"}
        mgr._save_meta(loaded)

        returned_meta, msg = mgr.next(meta.run_id)
        assert returned_meta.state == CycleState.WAIT_APPROVAL
        assert "tok-abc" in msg


class TestNextWorkerAdvancesOnFile:
    """Line 943: next() calls submit_worker and returns hard fail message if present."""

    def test_next_advances_worker_when_file_present(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Worker advance", workspace=str(tmp_path))

        planner_data = {
            "run_id": meta.run_id,
            "iteration": 1,
            "plan_summary": ["S1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        _write_inbox(tmp_path, meta.run_id, "planner_response.json", planner_data)
        mgr.submit_planner(meta.run_id)

        worker_data = {
            "run_id": meta.run_id,
            "iteration": 1,
            "status": "READY_FOR_VERIFY",
            "done_summary": ["Done"],
            "questions": [],
            "commands_run": [],
        }
        _write_inbox(tmp_path, meta.run_id, "worker_report.json", worker_data)

        returned_meta, msg = mgr.next(meta.run_id)
        # Should advance to WAIT_JUDGE
        assert returned_meta.state == CycleState.WAIT_JUDGE
        assert "WAIT_JUDGE" in msg


class TestNextJudgeAdvancesOnFile:
    """Line 954-957: next() calls submit_judge when judge_response.json present."""

    def test_next_advances_judge_when_file_present(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Judge advance", workspace=str(tmp_path))

        planner_data = {
            "run_id": meta.run_id,
            "iteration": 1,
            "plan_summary": ["S1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        _write_inbox(tmp_path, meta.run_id, "planner_response.json", planner_data)
        mgr.submit_planner(meta.run_id)

        worker_data = {
            "run_id": meta.run_id,
            "iteration": 1,
            "status": "READY_FOR_VERIFY",
            "done_summary": ["Done"],
            "questions": [],
            "commands_run": [],
        }
        _write_inbox(tmp_path, meta.run_id, "worker_report.json", worker_data)
        mgr.submit_worker(meta.run_id)

        judge_data = {
            "run_id": meta.run_id,
            "iteration": 1,
            "verdict": "APPROVED",
            "notes": [],
            "next_worker_instructions": "",
            "evidence_chain_verified": True,
        }
        _write_inbox(tmp_path, meta.run_id, "judge_response.json", judge_data)

        returned_meta, msg = mgr.next(meta.run_id)
        assert returned_meta.state == CycleState.DONE
        assert "DONE" in msg


class TestExport:
    """Lines 1235-1283: export() creates zip and logs event."""

    def test_export_creates_zip(self, tmp_path: Path) -> None:
        import zipfile

        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Export test", workspace=str(tmp_path))

        out_path = tmp_path / "export.zip"
        result_path = mgr.export(meta.run_id, out_path=out_path)

        assert result_path == out_path
        assert out_path.exists()
        assert zipfile.is_zipfile(out_path)

    def test_export_default_path(self, tmp_path: Path) -> None:
        import zipfile

        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Export default", workspace=str(tmp_path))

        result_path = mgr.export(meta.run_id)
        assert result_path.exists()
        assert zipfile.is_zipfile(result_path)
        assert meta.run_id in result_path.name

    def test_export_nonexistent_run_raises(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        with pytest.raises(FileNotFoundError, match="Run not found"):
            mgr.export("cycle-does-not-exist")

    def test_export_records_event(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Export event", workspace=str(tmp_path))

        mgr.export(meta.run_id)
        events = mgr.evidence.read_events(meta.run_id)
        event_names = [e["event"] for e in events]
        assert "EXPORT_CREATED" in event_names


class TestGeneratePrPack:
    """Lines 1320-1333: generate_pr_pack() is callable after start."""

    def test_generate_pr_pack_returns_string(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="PR pack test", workspace=str(tmp_path))

        content = mgr.generate_pr_pack(meta.run_id)
        assert isinstance(content, str)
        assert len(content) > 0

    def test_generate_pr_pack_with_manifest(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="PR manifest", workspace=str(tmp_path))

        # Write a fake manifest
        evidence_dir = tmp_path / "runs" / meta.run_id / "evidence"
        evidence_dir.mkdir(parents=True, exist_ok=True)
        manifest = {"manifest_sha256": "abc123", "files": []}
        (evidence_dir / "manifest.json").write_text(json.dumps(manifest))

        content = mgr.generate_pr_pack(meta.run_id)
        assert "abc123" in content


class TestLoad:
    """Lines 1343-1352: load() validates chain and adds warnings if broken."""

    def test_load_returns_meta(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Load test", workspace=str(tmp_path))

        loaded = mgr.load(meta.run_id)
        assert loaded.run_id == meta.run_id
        assert loaded.goal == "Load test"

    def test_load_adds_chain_warnings_on_broken_chain(self, tmp_path: Path) -> None:
        from unittest.mock import MagicMock, patch

        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Broken chain", workspace=str(tmp_path))

        # Simulate broken chain
        bad_result = MagicMock()
        bad_result.ok = False
        bad_result.errors = ["hash mismatch at event 2"]

        with patch.object(mgr.evidence, "verify_chain", return_value=bad_result):
            loaded = mgr.load(meta.run_id)

        assert "chain_warnings" in loaded.extra
        assert "hash mismatch" in loaded.extra["chain_warnings"][0]


class TestNextInboxHint:
    """Lines 1291, 1301, 1311, 1326-1327, 1350: next_inbox_hint() for various states."""

    def test_wait_worker_hint(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Hint worker", workspace=str(tmp_path))

        planner_data = {
            "run_id": meta.run_id,
            "iteration": 1,
            "plan_summary": ["S1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        _write_inbox(tmp_path, meta.run_id, "planner_response.json", planner_data)
        updated = mgr.submit_planner(meta.run_id)

        hint = mgr.next_inbox_hint(updated)
        assert "worker_report.json" in hint
        assert "submit-worker" in hint

    def test_wait_judge_hint(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Hint judge", workspace=str(tmp_path))

        planner_data = {
            "run_id": meta.run_id,
            "iteration": 1,
            "plan_summary": ["S1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        _write_inbox(tmp_path, meta.run_id, "planner_response.json", planner_data)
        mgr.submit_planner(meta.run_id)

        worker_data = {
            "run_id": meta.run_id,
            "iteration": 1,
            "status": "READY_FOR_VERIFY",
            "done_summary": ["Done"],
            "questions": [],
            "commands_run": [],
        }
        _write_inbox(tmp_path, meta.run_id, "worker_report.json", worker_data)
        updated = mgr.submit_worker(meta.run_id)

        hint = mgr.next_inbox_hint(updated)
        assert "judge_response.json" in hint
        assert "submit-judge" in hint

    def test_done_hint(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Done hint", workspace=str(tmp_path))
        loaded = mgr._load_meta(meta.run_id)
        loaded.state = CycleState.DONE
        mgr._save_meta(loaded)

        hint = mgr.next_inbox_hint(loaded)
        assert "complete" in hint.lower()

    def test_failed_hint(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Failed hint", workspace=str(tmp_path))
        loaded = mgr._load_meta(meta.run_id)
        loaded.state = CycleState.FAILED
        mgr._save_meta(loaded)

        hint = mgr.next_inbox_hint(loaded)
        assert "failed" in hint.lower()

    def test_wait_approval_hint(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Approval hint", workspace=str(tmp_path))
        loaded = mgr._load_meta(meta.run_id)
        loaded.state = CycleState.WAIT_APPROVAL
        mgr._save_meta(loaded)

        hint = mgr.next_inbox_hint(loaded)
        assert "approve" in hint.lower()


class TestSubmitBudgetExceeded:
    """Lines 550-615: submit_worker detects budget exceeded (total runtime)."""

    def test_budget_exceeded_total_runtime(self, tmp_path: Path) -> None:
        """Force BudgetExceeded by setting max_total_runtime_sec to 0."""
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Budget test", workspace=str(tmp_path))

        # Submit planner first
        planner_data = {
            "run_id": meta.run_id,
            "iteration": 1,
            "plan_summary": ["S1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        _write_inbox(tmp_path, meta.run_id, "planner_response.json", planner_data)
        mgr.submit_planner(meta.run_id)

        # Set max_total_runtime_sec to 0 so it's always exceeded
        loaded = mgr._load_meta(meta.run_id)
        loaded.limits.max_total_runtime_sec = 0
        mgr._save_meta(loaded)

        worker_data = {
            "run_id": meta.run_id,
            "iteration": 1,
            "status": "READY_FOR_VERIFY",
            "done_summary": ["Done"],
            "questions": [],
            "commands_run": [],
        }
        _write_inbox(tmp_path, meta.run_id, "worker_report.json", worker_data)
        result = mgr.submit_worker(meta.run_id)

        assert result.state == CycleState.FAILED
        assert any("BudgetExceeded" in r for r in result.hard_fail_reasons)


class TestJudgeApprovedWithMemoryStore:
    """Lines 776-789: approved verdict triggers memory ingest."""

    def test_approved_ingests_memory(self, tmp_path: Path) -> None:
        from unittest.mock import MagicMock

        mgr = _make_manager(tmp_path)
        fake_store = MagicMock()
        mgr.memory_store = fake_store

        meta = mgr.start(goal="Memory ingest test", workspace=str(tmp_path))

        planner_data = {
            "run_id": meta.run_id,
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        _write_inbox(tmp_path, meta.run_id, "planner_response.json", planner_data)
        mgr.submit_planner(meta.run_id)

        worker_data = {
            "run_id": meta.run_id,
            "iteration": 1,
            "status": "READY_FOR_VERIFY",
            "done_summary": ["completed"],
            "questions": [],
            "commands_run": [],
        }
        _write_inbox(tmp_path, meta.run_id, "worker_report.json", worker_data)
        mgr.submit_worker(meta.run_id)

        judge_data = {
            "run_id": meta.run_id,
            "iteration": 1,
            "verdict": "APPROVED",
            "notes": [],
            "next_worker_instructions": "",
            "evidence_chain_verified": True,
        }
        _write_inbox(tmp_path, meta.run_id, "judge_response.json", judge_data)
        final = mgr.submit_judge(meta.run_id)

        assert final.state == CycleState.DONE
        fake_store.ingest.assert_called_once()
        call_kwargs = fake_store.ingest.call_args.kwargs
        assert call_kwargs["kind"] == "run"


# ---------------------------------------------------------------------------
# Additional tests targeting previously uncovered lines
# ---------------------------------------------------------------------------


class TestStartWithSkillPacks:
    """Lines 429-449: skill_packs parameter in start() injects skill context."""

    def test_skill_packs_ignored_when_unavailable(self, tmp_path: Path) -> None:
        from unittest.mock import patch

        mgr = _make_manager(tmp_path)

        with patch("owlmind.agent.cycle_manager._SKILLS_AVAILABLE", False):
            meta = mgr.start(
                goal="task with skills",
                workspace=str(tmp_path),
                skill_packs=["my-pack"],
            )

        assert meta.state == CycleState.STARTED_WAIT_PLANNER

    def test_skill_packs_included_when_available(self, tmp_path: Path) -> None:
        from unittest.mock import patch

        mgr = _make_manager(tmp_path)

        with (
            patch("owlmind.agent.cycle_manager._SKILLS_AVAILABLE", True),
            patch(
                "owlmind.agent.cycle_manager.list_packs",
                return_value=[{"id": "mypk", "version": "1.0", "description": "A pack"}],
            ),
            patch(
                "owlmind.agent.cycle_manager.get_pack_context",
                return_value="Pack instructions here",
            ),
        ):
            meta = mgr.start(
                goal="task with skills",
                workspace=str(tmp_path),
                skill_packs=["mypk"],
            )

        outbox = tmp_path / "runs" / meta.run_id / "outbox"
        prompt = (outbox / "planner_prompt.md").read_text()
        assert "Pack instructions here" in prompt

    def test_skill_packs_list_packs_exception_swallowed(self, tmp_path: Path) -> None:
        from unittest.mock import patch

        mgr = _make_manager(tmp_path)

        with (
            patch("owlmind.agent.cycle_manager._SKILLS_AVAILABLE", True),
            patch(
                "owlmind.agent.cycle_manager.list_packs",
                side_effect=RuntimeError("registry unavailable"),
            ),
            patch(
                "owlmind.agent.cycle_manager.get_pack_context",
                return_value="Context here",
            ),
        ):
            # Should not raise — exception is swallowed
            meta = mgr.start(
                goal="skill list fails",
                workspace=str(tmp_path),
                skill_packs=["mypk"],
            )

        assert meta.state == CycleState.STARTED_WAIT_PLANNER

    def test_skill_packs_get_pack_context_exception_swallowed(self, tmp_path: Path) -> None:
        from unittest.mock import patch

        mgr = _make_manager(tmp_path)

        with (
            patch("owlmind.agent.cycle_manager._SKILLS_AVAILABLE", True),
            patch("owlmind.agent.cycle_manager.list_packs", return_value=[]),
            patch(
                "owlmind.agent.cycle_manager.get_pack_context",
                side_effect=RuntimeError("pack not found"),
            ),
        ):
            meta = mgr.start(
                goal="pack context fails",
                workspace=str(tmp_path),
                skill_packs=["broken-pack"],
            )

        assert meta.state == CycleState.STARTED_WAIT_PLANNER


class TestStartWithGoalRefine:
    """Lines 301-315: goal refinement path."""

    def test_refine_enabled_but_refiner_unavailable(self, tmp_path: Path) -> None:
        from unittest.mock import patch

        mgr = _make_manager(tmp_path)

        with patch("owlmind.agent.cycle_manager._GOAL_REFINER_AVAILABLE", False):
            meta = mgr.start(
                goal="original goal",
                workspace=str(tmp_path),
                refine=True,
            )

        # Goal unchanged when refiner unavailable
        assert meta.goal == "original goal"

    def test_refine_exception_falls_back_to_original(self, tmp_path: Path) -> None:
        from unittest.mock import patch

        mgr = _make_manager(tmp_path)

        with (
            patch("owlmind.agent.cycle_manager._GOAL_REFINER_AVAILABLE", True),
            patch(
                "owlmind.agent.cycle_manager._refine_goal",
                side_effect=RuntimeError("LLM timeout"),
            ),
        ):
            meta = mgr.start(
                goal="fallback goal",
                workspace=str(tmp_path),
                refine=True,
            )

        assert meta.goal == "fallback goal"

    def test_refine_success_sets_refined_goal(self, tmp_path: Path) -> None:
        from unittest.mock import MagicMock, patch

        mgr = _make_manager(tmp_path)

        refined = MagicMock()
        refined.refined = "Improved: fallback goal"
        refined.original = "fallback goal"
        refined.risk_level = "low"
        refined.warnings = []
        refined.changed = True

        with (
            patch("owlmind.agent.cycle_manager._GOAL_REFINER_AVAILABLE", True),
            patch("owlmind.agent.cycle_manager._refine_goal", return_value=refined),
        ):
            meta = mgr.start(
                goal="fallback goal",
                workspace=str(tmp_path),
                refine=True,
            )

        assert "Improved" in meta.goal
        assert "refined_goal" in meta.extra


class TestStartSmartVerify:
    """Lines 322-337: smart verify path."""

    def test_smart_verify_returns_empty_falls_back_to_profile(self, tmp_path: Path) -> None:
        from unittest.mock import patch

        mgr = _make_manager(tmp_path)

        with (
            patch("owlmind.agent.cycle_manager._SMART_VERIFY_AVAILABLE", True),
            patch("owlmind.agent.cycle_manager._suggest_smart_verify", return_value=[]),
        ):
            meta = mgr.start(goal="smart empty", workspace=str(tmp_path))

        assert meta.state == CycleState.STARTED_WAIT_PLANNER

    def test_smart_verify_exception_falls_back_to_profile(self, tmp_path: Path) -> None:
        from unittest.mock import patch

        mgr = _make_manager(tmp_path)

        with (
            patch("owlmind.agent.cycle_manager._SMART_VERIFY_AVAILABLE", True),
            patch(
                "owlmind.agent.cycle_manager._suggest_smart_verify",
                side_effect=Exception("git error"),
            ),
        ):
            meta = mgr.start(goal="smart fail", workspace=str(tmp_path))

        assert meta.state == CycleState.STARTED_WAIT_PLANNER

    def test_smart_verify_returns_commands_when_available(self, tmp_path: Path) -> None:
        from unittest.mock import patch

        mgr = _make_manager(tmp_path)

        with (
            patch("owlmind.agent.cycle_manager._SMART_VERIFY_AVAILABLE", True),
            patch(
                "owlmind.agent.cycle_manager._suggest_smart_verify",
                return_value=["pytest -q", "ruff check ."],
            ),
        ):
            meta = mgr.start(goal="smart success", workspace=str(tmp_path))

        profile_info = meta.extra.get("profile", {})
        assert "pytest -q" in profile_info.get("suggested_verify", [])

    def test_auto_verify_false_skips_detection(self, tmp_path: Path) -> None:
        from unittest.mock import patch

        mgr = _make_manager(tmp_path)

        with patch("owlmind.agent.cycle_manager._SMART_VERIFY_AVAILABLE", True):
            # With auto_verify=False, smart verify should not be called at all
            meta = mgr.start(goal="no verify", workspace=str(tmp_path), auto_verify=False)

        # profile/suggested_verify should still be populated via fallback
        assert meta.state == CycleState.STARTED_WAIT_PLANNER


class TestStartComplexityClassification:
    """Lines 343-347: complexity classification via LLM."""

    def test_complexity_classification_success(self, tmp_path: Path) -> None:
        from unittest.mock import patch

        mgr = _make_manager(tmp_path)

        with (
            patch("owlmind.agent.cycle_manager._COMPLEXITY_AVAILABLE", True),
            patch("owlmind.agent.cycle_manager._classify_goal", return_value="high"),
        ):
            meta = mgr.start(goal="complex task", workspace=str(tmp_path))

        assert meta.extra["complexity"] == "high"

    def test_complexity_classification_exception_uses_default(self, tmp_path: Path) -> None:
        from unittest.mock import patch

        mgr = _make_manager(tmp_path)

        with (
            patch("owlmind.agent.cycle_manager._COMPLEXITY_AVAILABLE", True),
            patch(
                "owlmind.agent.cycle_manager._classify_goal",
                side_effect=RuntimeError("LLM failed"),
            ),
        ):
            meta = mgr.start(goal="classification fails", workspace=str(tmp_path))

        assert meta.extra["complexity"] == "medium"


class TestSubmitWorkerWrongState:
    """Lines 549-551: submit_worker raises RuntimeError when state != WAIT_WORKER."""

    def test_wrong_state_raises(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="State test", workspace=str(tmp_path))

        # State is STARTED_WAIT_PLANNER — calling submit_worker directly raises
        with pytest.raises(RuntimeError, match="Expected state WAIT_WORKER"):
            mgr.submit_worker(meta.run_id)


class TestSubmitWorkerVerifyBudgetExceeded:
    """Lines 599-615: budget exceeded during verify runtime."""

    def test_verify_budget_exceeded_fails_cycle(self, tmp_path: Path) -> None:
        from unittest.mock import MagicMock, patch

        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Verify budget test", workspace=str(tmp_path))

        planner_data = {
            "run_id": meta.run_id,
            "iteration": 1,
            "plan_summary": ["S1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        _write_inbox(tmp_path, meta.run_id, "planner_response.json", planner_data)
        mgr.submit_planner(meta.run_id)

        # Keep total runtime large so it doesn't trip first, but set verify limit to 0
        loaded = mgr._load_meta(meta.run_id)
        loaded.limits.max_total_runtime_sec = 9999
        loaded.limits.max_verify_runtime_sec = 0
        mgr._save_meta(loaded)

        # Make the fake shell result report a large duration (> 0 limit)
        fake_result = MagicMock()
        fake_result.exit_code = 0
        fake_result.stdout = "ok"
        fake_result.stderr = ""
        fake_result.duration_ms = 1000  # 1 second > 0 limit

        worker_data = {
            "run_id": meta.run_id,
            "iteration": 1,
            "status": "READY_FOR_VERIFY",
            "done_summary": ["Done"],
            "questions": [],
            "commands_run": [],
        }
        _write_inbox(tmp_path, meta.run_id, "worker_report.json", worker_data)

        with patch("owlmind.tools.shell.ShellTool.run", return_value=fake_result):
            result = mgr.submit_worker(meta.run_id)

        assert result.state == CycleState.FAILED
        assert any("BudgetExceeded" in r for r in result.hard_fail_reasons)
        # The verify_runtime branch appends a reason containing "verify"
        assert any("verify" in r.lower() for r in result.hard_fail_reasons)


class TestSubmitWorkerHardFail:
    """Lines 629-661: hard fail path in submit_worker."""

    def test_hard_fail_fails_cycle(self, tmp_path: Path) -> None:
        from unittest.mock import MagicMock, patch

        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Hard fail test", workspace=str(tmp_path))

        planner_data = {
            "run_id": meta.run_id,
            "iteration": 1,
            "plan_summary": ["S1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        _write_inbox(tmp_path, meta.run_id, "planner_response.json", planner_data)
        mgr.submit_planner(meta.run_id)

        worker_data = {
            "run_id": meta.run_id,
            "iteration": 1,
            "status": "READY_FOR_VERIFY",
            "done_summary": ["Done"],
            "questions": [],
            "commands_run": [],
        }
        _write_inbox(tmp_path, meta.run_id, "worker_report.json", worker_data)

        # Mock checker to return a hard fail
        fake_check_result = MagicMock()
        fake_check_result.ok = False
        fake_check_result.reasons = ["Found forbidden pattern: rm -rf"]
        fake_check_result.risk_level = "CRITICAL"

        with patch.object(mgr.checker, "check_all", return_value=fake_check_result):
            result = mgr.submit_worker(meta.run_id)

        assert result.state == CycleState.FAILED
        assert any("forbidden pattern" in r for r in result.hard_fail_reasons)


class TestRunPlannerLLM:
    """Lines 994-1004: run_planner_llm uses complexity routing when forced."""

    def test_run_planner_llm_no_driver_raises(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="LLM planner test", workspace=str(tmp_path))

        # No LLM driver configured — should raise
        with pytest.raises((RuntimeError, ValueError, TypeError)):
            mgr.run_planner_llm(meta.run_id)

    def test_run_planner_llm_with_complexity_routing(self, tmp_path: Path) -> None:
        from unittest.mock import MagicMock, patch

        mgr = _make_manager(tmp_path)
        meta = mgr.start(
            goal="complex task",
            workspace=str(tmp_path),
            force_complexity="high",
        )

        fake_meta = MagicMock()
        fake_meta.state = CycleState.WAIT_WORKER

        with (
            patch("owlmind.agent.cycle_manager._COMPLEXITY_AVAILABLE", True),
            patch(
                "owlmind.llm.complexity.provider_for_complexity",
                return_value="gpt-4o",
            ),
            patch.object(mgr.llm_runner, "run_planner", return_value=fake_meta) as mock_run,
        ):
            result = mgr.run_planner_llm(meta.run_id)

        mock_run.assert_called_once_with(meta.run_id, force_provider="gpt-4o")
        assert result is fake_meta


class TestRunJudgeLLM:
    """Lines 1006-1016: run_judge_llm uses complexity routing when forced."""

    def test_run_judge_llm_with_complexity_routing(self, tmp_path: Path) -> None:
        from unittest.mock import MagicMock, patch

        mgr = _make_manager(tmp_path)
        meta = mgr.start(
            goal="complex judge task",
            workspace=str(tmp_path),
            force_complexity="low",
        )

        fake_meta = MagicMock()
        fake_meta.state = CycleState.DONE

        with (
            patch("owlmind.agent.cycle_manager._COMPLEXITY_AVAILABLE", True),
            patch(
                "owlmind.llm.complexity.provider_for_complexity",
                return_value="gpt-3.5",
            ),
            patch.object(mgr.llm_runner, "run_judge", return_value=fake_meta) as mock_run,
        ):
            result = mgr.run_judge_llm(meta.run_id)

        mock_run.assert_called_once_with(meta.run_id, force_provider="gpt-3.5")
        assert result is fake_meta

    def test_run_judge_llm_no_routing_when_not_forced(self, tmp_path: Path) -> None:
        from unittest.mock import MagicMock, patch

        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="no routing judge", workspace=str(tmp_path))

        fake_meta = MagicMock()

        with (
            patch("owlmind.agent.cycle_manager._COMPLEXITY_AVAILABLE", True),
            patch.object(mgr.llm_runner, "run_judge", return_value=fake_meta) as mock_run,
        ):
            mgr.run_judge_llm(meta.run_id)

        # force_provider should be None when no complexity routing
        mock_run.assert_called_once_with(meta.run_id, force_provider=None)


class TestSandboxOperations:
    """Lines 1289-1314: sandbox_create, sandbox_cleanup, sandbox_status delegates."""

    def test_sandbox_status_non_sandbox_run(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="No sandbox run", workspace=str(tmp_path))

        status = mgr.sandbox_status(meta.run_id)
        # Should return a SandboxInfo (enabled=False for non-sandbox run)
        from owlmind.agent.sandbox import SandboxInfo

        assert isinstance(status, SandboxInfo)
        assert status.enabled is False

    def test_sandbox_create_non_git_workspace(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Sandbox create test", workspace=str(tmp_path))

        info = mgr.sandbox_create(meta.run_id, str(tmp_path))
        from owlmind.agent.sandbox import SandboxInfo

        assert isinstance(info, SandboxInfo)
        # Non-git workspace creates a plain-dir sandbox (enabled=True, kind='plain-dir')
        assert info.enabled is True
        assert info.kind == "plain-dir"

    def test_sandbox_cleanup_non_existing(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Sandbox cleanup test", workspace=str(tmp_path))

        ok, msg = mgr.sandbox_cleanup(meta.run_id, str(tmp_path))
        assert isinstance(ok, bool)
        assert isinstance(msg, str)


class TestIngestWorkerAndJudge:
    """Lines 875-903: ingest() for WAIT_WORKER and WAIT_JUDGE states."""

    def test_ingest_worker_report(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Ingest worker test", workspace=str(tmp_path))

        # Advance to WAIT_WORKER
        planner_data = {
            "run_id": meta.run_id,
            "iteration": 1,
            "plan_summary": ["S1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        _write_inbox(tmp_path, meta.run_id, "planner_response.json", planner_data)
        mgr.submit_planner(meta.run_id)

        worker_data = {
            "run_id": meta.run_id,
            "iteration": 1,
            "status": "READY_FOR_VERIFY",
            "done_summary": ["Created file.py"],
            "questions": [],
            "commands_run": [],
        }
        file = tmp_path / "worker.json"
        file.write_text(json.dumps(worker_data))

        loaded_meta, target_path = mgr.ingest(meta.run_id, file)
        assert "worker_report.json" in target_path
        assert Path(target_path).exists()

    def test_ingest_judge_response(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Ingest judge test", workspace=str(tmp_path))

        # Advance to WAIT_JUDGE
        planner_data = {
            "run_id": meta.run_id,
            "iteration": 1,
            "plan_summary": ["S1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        _write_inbox(tmp_path, meta.run_id, "planner_response.json", planner_data)
        mgr.submit_planner(meta.run_id)

        worker_data = {
            "run_id": meta.run_id,
            "iteration": 1,
            "status": "READY_FOR_VERIFY",
            "done_summary": ["Done"],
            "questions": [],
            "commands_run": [],
        }
        _write_inbox(tmp_path, meta.run_id, "worker_report.json", worker_data)
        mgr.submit_worker(meta.run_id)

        judge_data = {
            "run_id": meta.run_id,
            "iteration": 1,
            "verdict": "APPROVED",
            "notes": [],
            "next_worker_instructions": "",
            "evidence_chain_verified": True,
        }
        file = tmp_path / "judge.json"
        file.write_text(json.dumps(judge_data))

        loaded_meta, target_path = mgr.ingest(meta.run_id, file)
        assert "judge_response.json" in target_path


class TestNextUnknownState:
    """Line 988: next() handles unknown state gracefully."""

    def test_next_unknown_state_returns_message(self, tmp_path: Path) -> None:
        from owlmind.agent.schemas import CycleState

        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Unknown state test", workspace=str(tmp_path))

        # There is no "WAIT_JUDGE" state without proper setup but we can inject an odd value
        # by patching the enum. Instead, force state to WAIT_JUDGE without going through
        # normal flow so inbox file doesn't exist — tests the "waiting" fallback
        loaded = mgr._load_meta(meta.run_id)
        loaded.state = CycleState.WAIT_JUDGE
        mgr._save_meta(loaded)

        returned_meta, msg = mgr.next(meta.run_id)
        # Should wait (no judge file in inbox)
        assert "judge" in msg.lower() or "WAIT_JUDGE" in msg


class TestNextWaitJudgeNoFile:
    """Lines 953-964: next() waits for judge when no file present."""

    def test_next_wait_judge_no_file(self, tmp_path: Path) -> None:
        mgr = _make_manager(tmp_path)
        meta = mgr.start(goal="Wait judge next", workspace=str(tmp_path))

        planner_data = {
            "run_id": meta.run_id,
            "iteration": 1,
            "plan_summary": ["S1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        _write_inbox(tmp_path, meta.run_id, "planner_response.json", planner_data)
        mgr.submit_planner(meta.run_id)

        worker_data = {
            "run_id": meta.run_id,
            "iteration": 1,
            "status": "READY_FOR_VERIFY",
            "done_summary": ["Done"],
            "questions": [],
            "commands_run": [],
        }
        _write_inbox(tmp_path, meta.run_id, "worker_report.json", worker_data)
        mgr.submit_worker(meta.run_id)

        returned_meta, msg = mgr.next(meta.run_id)
        assert returned_meta.state == CycleState.WAIT_JUDGE
        assert "judge_prompt.md" in msg
