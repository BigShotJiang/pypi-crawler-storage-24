"""Tests for dashboard REST endpoints (/, /api/v1/screen, /api/v1/health/full)."""

from __future__ import annotations

import base64
import json
import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from starlette.testclient import TestClient

from owlmind.api.app import create_app

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def tmp_dirs(tmp_path: Path) -> dict[str, Path]:
    dirs = {
        "runs": tmp_path / "runs",
        "ledger": tmp_path / "ledger",
        "queue": tmp_path / "queue",
        "policies": tmp_path / "policies",
        "memory_db": tmp_path / "memory" / "memory.db",
    }
    for key, d in dirs.items():
        if key == "memory_db":
            d.parent.mkdir(parents=True, exist_ok=True)
        else:
            d.mkdir(parents=True, exist_ok=True)
    return dirs


@pytest.fixture()
def client(tmp_dirs: dict[str, Path]) -> TestClient:
    app = create_app(
        runs_dir=tmp_dirs["runs"],
        ledger_dir=tmp_dirs["ledger"],
        queue_path=tmp_dirs["queue"],
        policies_dir=tmp_dirs["policies"],
        memory_db=tmp_dirs["memory_db"],
    )
    return TestClient(app)


@pytest.fixture(autouse=True)
def _no_auth(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("owlmind.api.auth.verify_api_key", lambda: None)


# ===========================================================================
# GET / — dashboard HTML
# ===========================================================================


class TestDashboardRoot:
    def test_returns_200(self, client: TestClient) -> None:
        resp = client.get("/")
        assert resp.status_code == 200

    def test_returns_html_content_type(self, client: TestClient) -> None:
        resp = client.get("/")
        assert "text/html" in resp.headers["content-type"]

    def test_fallback_html_contains_title(self, client: TestClient) -> None:
        """When no custom dashboard file exists, fallback HTML is served."""
        resp = client.get("/")
        assert "OWLMIND Dashboard" in resp.text

    def test_serves_custom_dashboard_when_file_exists(
        self, client: TestClient, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """When ~/owlmind_dashboard.html exists, its content is served."""
        custom_html = "<html><body>Custom Dashboard</body></html>"
        dashboard_file = tmp_path / "owlmind_dashboard.html"
        dashboard_file.write_text(custom_html)

        with patch("owlmind.api.routes.dashboard.Path.home", return_value=tmp_path):
            resp = client.get("/")

        assert resp.status_code == 200
        assert "Custom Dashboard" in resp.text

    def test_fallback_html_has_runs_api_link(self, client: TestClient, tmp_path: Path) -> None:
        """Fallback HTML contains the runs API link (when no custom file exists)."""
        # Patch Path.home() to point at tmp_path so no custom dashboard is found
        with patch("owlmind.api.routes.dashboard.Path.home", return_value=tmp_path):
            resp = client.get("/")
        assert "/api/v1/runs" in resp.text


# ===========================================================================
# GET /api/v1/screen — screen capture
# ===========================================================================


class TestScreenCapture:
    def _make_mock_result(self, returncode: int = 0) -> MagicMock:
        result = MagicMock()
        result.returncode = returncode
        result.stderr = b""
        return result

    def test_returns_200_on_success(self, client: TestClient, tmp_path: Path) -> None:
        fake_png = b"\x89PNG\r\n\x1a\n" + b"\x00" * 16
        mock_result = self._make_mock_result(returncode=0)

        with (
            patch("owlmind.api.routes.dashboard.subprocess.run", return_value=mock_result),
            patch("owlmind.api.routes.dashboard.Path.read_bytes", return_value=fake_png),
        ):
            resp = client.get("/api/v1/screen")

        assert resp.status_code == 200

    def test_success_response_has_format_field(self, client: TestClient) -> None:
        fake_png = b"\x89PNG" + b"\x00" * 16
        mock_result = self._make_mock_result(returncode=0)

        with (
            patch("owlmind.api.routes.dashboard.subprocess.run", return_value=mock_result),
            patch("owlmind.api.routes.dashboard.Path.read_bytes", return_value=fake_png),
        ):
            resp = client.get("/api/v1/screen")
            data = resp.json()

        assert data["format"] == "png"

    def test_success_response_has_base64_data(self, client: TestClient) -> None:
        fake_png = b"\x89PNG" + b"\x00" * 16
        mock_result = self._make_mock_result(returncode=0)

        with (
            patch("owlmind.api.routes.dashboard.subprocess.run", return_value=mock_result),
            patch("owlmind.api.routes.dashboard.Path.read_bytes", return_value=fake_png),
        ):
            resp = client.get("/api/v1/screen")
            data = resp.json()

        # Verify data field is valid base64
        decoded = base64.b64decode(data["data"])
        assert decoded == fake_png
        assert data["size_bytes"] == len(fake_png)

    def test_screencapture_failure_returns_error(self, client: TestClient) -> None:
        mock_result = self._make_mock_result(returncode=1)
        mock_result.stderr = b"permission denied"

        with patch("owlmind.api.routes.dashboard.subprocess.run", return_value=mock_result):
            resp = client.get("/api/v1/screen")
            data = resp.json()

        assert resp.status_code == 200
        assert data["error"] == "screencapture failed"
        assert "permission denied" in data["stderr"]

    def test_screencapture_not_found_returns_error(self, client: TestClient) -> None:
        with patch(
            "owlmind.api.routes.dashboard.subprocess.run",
            side_effect=FileNotFoundError,
        ):
            resp = client.get("/api/v1/screen")
            data = resp.json()

        assert resp.status_code == 200
        assert "screencapture not found" in data["error"]

    def test_screencapture_timeout_returns_error(self, client: TestClient) -> None:
        with patch(
            "owlmind.api.routes.dashboard.subprocess.run",
            side_effect=subprocess.TimeoutExpired(cmd="screencapture", timeout=10),
        ):
            resp = client.get("/api/v1/screen")
            data = resp.json()

        assert resp.status_code == 200
        assert "timed out" in data["error"]


# ===========================================================================
# GET /api/v1/health/full — extended health check
# ===========================================================================


class TestFullHealth:
    def _make_claude_result(self, returncode: int = 0, stdout: bytes = b"claude 1.0") -> MagicMock:
        result = MagicMock()
        result.returncode = returncode
        result.stdout = stdout
        result.stderr = b""
        return result

    def test_returns_200(self, client: TestClient) -> None:
        mock_result = self._make_claude_result()
        with patch("owlmind.api.routes.dashboard.subprocess.run", return_value=mock_result):
            resp = client.get("/api/v1/health/full")
        assert resp.status_code == 200

    def test_response_has_status_and_checks(self, client: TestClient) -> None:
        mock_result = self._make_claude_result()
        with patch("owlmind.api.routes.dashboard.subprocess.run", return_value=mock_result):
            resp = client.get("/api/v1/health/full")
            data = resp.json()

        assert "status" in data
        assert "checks" in data
        assert isinstance(data["checks"], list)

    def test_healthy_when_all_checks_pass(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        mock_result = self._make_claude_result(returncode=0, stdout=b"claude 1.2.3")
        with patch("owlmind.api.routes.dashboard.subprocess.run", return_value=mock_result):
            resp = client.get("/api/v1/health/full")
            data = resp.json()

        # All checks should have "ok" key
        for check in data["checks"]:
            assert "ok" in check
            assert "name" in check
            assert "detail" in check

    def test_claude_cli_not_found_marks_degraded(self, client: TestClient) -> None:
        with patch(
            "owlmind.api.routes.dashboard.subprocess.run",
            side_effect=FileNotFoundError,
        ):
            resp = client.get("/api/v1/health/full")
            data = resp.json()

        assert data["status"] == "degraded"
        claude_check = next(c for c in data["checks"] if c["name"] == "claude CLI")
        assert claude_check["ok"] is False
        assert "not found" in claude_check["detail"]

    def test_claude_cli_timeout_marks_degraded(self, client: TestClient) -> None:
        with patch(
            "owlmind.api.routes.dashboard.subprocess.run",
            side_effect=subprocess.TimeoutExpired(cmd="claude", timeout=5),
        ):
            resp = client.get("/api/v1/health/full")
            data = resp.json()

        assert data["status"] == "degraded"
        claude_check = next(c for c in data["checks"] if c["name"] == "claude CLI")
        assert claude_check["ok"] is False
        assert claude_check["detail"] == "timeout"

    def test_budget_check_no_ledger(self, client: TestClient, tmp_dirs: dict[str, Path]) -> None:
        mock_result = self._make_claude_result()
        with patch("owlmind.api.routes.dashboard.subprocess.run", return_value=mock_result):
            resp = client.get("/api/v1/health/full")
            data = resp.json()

        budget_check = next(c for c in data["checks"] if c["name"] == "Budget")
        assert budget_check["ok"] is True
        assert "no ledger" in budget_check["detail"]

    def test_budget_check_with_usage_file(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        usage_file = tmp_dirs["ledger"] / "usage.jsonl"
        usage_file.write_text(
            json.dumps({"cost_usd": 0.05}) + "\n" + json.dumps({"cost_usd": 0.10}) + "\n"
        )
        mock_result = self._make_claude_result()
        with patch("owlmind.api.routes.dashboard.subprocess.run", return_value=mock_result):
            resp = client.get("/api/v1/health/full")
            data = resp.json()

        budget_check = next(c for c in data["checks"] if c["name"] == "Budget")
        assert budget_check["ok"] is True
        assert "$0.1500" in budget_check["detail"]

    def test_runs_dir_check_exists(self, client: TestClient, tmp_dirs: dict[str, Path]) -> None:
        # Create some run subdirs
        (tmp_dirs["runs"] / "run-001").mkdir()
        (tmp_dirs["runs"] / "run-002").mkdir()
        mock_result = self._make_claude_result()
        with patch("owlmind.api.routes.dashboard.subprocess.run", return_value=mock_result):
            resp = client.get("/api/v1/health/full")
            data = resp.json()

        runs_check = next(c for c in data["checks"] if c["name"] == "Runs dir")
        assert runs_check["ok"] is True
        assert "2 runs" in runs_check["detail"]

    def test_runs_dir_check_missing(self, client: TestClient, tmp_dirs: dict[str, Path]) -> None:
        # Remove runs dir
        tmp_dirs["runs"].rmdir()
        mock_result = self._make_claude_result()
        with patch("owlmind.api.routes.dashboard.subprocess.run", return_value=mock_result):
            resp = client.get("/api/v1/health/full")
            data = resp.json()

        runs_check = next(c for c in data["checks"] if c["name"] == "Runs dir")
        assert runs_check["ok"] is False
        assert "not found" in runs_check["detail"]

    def test_budget_skips_malformed_lines(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        usage_file = tmp_dirs["ledger"] / "usage.jsonl"
        usage_file.write_text("not-json\n" + json.dumps({"cost_usd": 0.25}) + "\n" + "{broken\n")
        mock_result = self._make_claude_result()
        with patch("owlmind.api.routes.dashboard.subprocess.run", return_value=mock_result):
            resp = client.get("/api/v1/health/full")
            data = resp.json()

        budget_check = next(c for c in data["checks"] if c["name"] == "Budget")
        assert budget_check["ok"] is True
        assert "$0.2500" in budget_check["detail"]
