"""Tests for Langfuse tracing integration in monitoring/tracing.py."""
from __future__ import annotations

from unittest.mock import MagicMock

import pytest


def _reload_tracing():
    """Reimport tracing module to pick up HAS_LANGFUSE changes."""
    import importlib

    import owlmind.monitoring.tracing as mod

    importlib.reload(mod)
    return mod


def _patch_langfuse(monkeypatch, fake_mod):
    """Patch HAS_LANGFUSE=True and inject fake _langfuse_module.

    Because _langfuse_module is only defined in the module namespace when
    `import langfuse` succeeds (i.e. the package is installed), we must use
    raising=False so monkeypatch creates the attribute if absent.
    """
    monkeypatch.setattr("owlmind.monitoring.tracing.HAS_LANGFUSE", True)
    monkeypatch.setattr(
        "owlmind.monitoring.tracing._langfuse_module", fake_mod, raising=False
    )


class TestLangfuseClientSingleton:
    """Tests for _LangfuseClient lazy singleton."""

    def setup_method(self):
        """Reset singleton before each test."""
        from owlmind.monitoring.tracing import _LangfuseClient

        _LangfuseClient.reset()

    def test_get_returns_none_when_disabled(self, monkeypatch):
        monkeypatch.setattr("owlmind.monitoring.tracing.HAS_LANGFUSE", False)
        from owlmind.monitoring.tracing import get_langfuse

        assert get_langfuse() is None

    def test_get_returns_client_when_enabled(self, monkeypatch):
        fake_client = MagicMock()
        fake_langfuse_mod = MagicMock()
        fake_langfuse_mod.Langfuse.return_value = fake_client

        _patch_langfuse(monkeypatch, fake_langfuse_mod)

        from owlmind.monitoring.tracing import _LangfuseClient

        _LangfuseClient.reset()

        from owlmind.monitoring.tracing import get_langfuse

        client = get_langfuse()
        assert client is fake_client

    def test_singleton_returns_same_instance(self, monkeypatch):
        fake_client = MagicMock()
        fake_mod = MagicMock()
        fake_mod.Langfuse.return_value = fake_client

        _patch_langfuse(monkeypatch, fake_mod)

        from owlmind.monitoring.tracing import _LangfuseClient, get_langfuse

        _LangfuseClient.reset()

        c1 = get_langfuse()
        c2 = get_langfuse()
        assert c1 is c2
        assert fake_mod.Langfuse.call_count == 1

    def test_reset_clears_instance(self, monkeypatch):
        """reset() should clear the singleton so next get() creates a fresh instance."""
        fake_client_1 = MagicMock()
        fake_client_2 = MagicMock()
        fake_mod = MagicMock()
        fake_mod.Langfuse.side_effect = [fake_client_1, fake_client_2]

        _patch_langfuse(monkeypatch, fake_mod)

        from owlmind.monitoring.tracing import _LangfuseClient, get_langfuse

        _LangfuseClient.reset()
        c1 = get_langfuse()
        _LangfuseClient.reset()
        c2 = get_langfuse()
        assert c1 is fake_client_1
        assert c2 is fake_client_2


class TestLangfuseSpan:
    """Tests for langfuse_span context manager."""

    def setup_method(self):
        from owlmind.monitoring.tracing import _LangfuseClient

        _LangfuseClient.reset()

    def _make_fakes(self):
        fake_span = MagicMock()
        fake_trace = MagicMock()
        fake_trace.span.return_value = fake_span
        fake_client = MagicMock()
        fake_client.trace.return_value = fake_trace
        fake_mod = MagicMock()
        fake_mod.Langfuse.return_value = fake_client
        return fake_span, fake_trace, fake_client, fake_mod

    def test_noop_when_disabled(self, monkeypatch):
        monkeypatch.setattr("owlmind.monitoring.tracing.HAS_LANGFUSE", False)
        from owlmind.monitoring.tracing import _NoOpLangfuseSpan, langfuse_span

        with langfuse_span("run-123", "planner") as span:
            assert isinstance(span, _NoOpLangfuseSpan)

    def test_creates_trace_and_span_when_enabled(self, monkeypatch):
        fake_span, fake_trace, fake_client, fake_mod = self._make_fakes()

        _patch_langfuse(monkeypatch, fake_mod)
        from owlmind.monitoring.tracing import _LangfuseClient

        _LangfuseClient.reset()

        from owlmind.monitoring.tracing import langfuse_span

        with langfuse_span("run-123", "planner", input_data={"goal": "test"}) as span:
            assert span is fake_span

        fake_client.trace.assert_called_once_with(
            id="run-123", name="owlmind_planner", metadata={}
        )
        fake_trace.span.assert_called_once_with(name="planner", input={"goal": "test"})

    def test_span_end_called_on_success(self, monkeypatch):
        fake_span, fake_trace, fake_client, fake_mod = self._make_fakes()

        _patch_langfuse(monkeypatch, fake_mod)
        from owlmind.monitoring.tracing import _LangfuseClient

        _LangfuseClient.reset()

        from owlmind.monitoring.tracing import langfuse_span

        with langfuse_span("run-1", "judge") as span:
            span.end(output={"tokens": 100})

        fake_span.end.assert_called()

    def test_span_end_error_on_exception(self, monkeypatch):
        fake_span, fake_trace, fake_client, fake_mod = self._make_fakes()

        _patch_langfuse(monkeypatch, fake_mod)
        from owlmind.monitoring.tracing import _LangfuseClient

        _LangfuseClient.reset()

        from owlmind.monitoring.tracing import langfuse_span

        with pytest.raises(ValueError), langfuse_span("run-2", "planner"):
            raise ValueError("test error")

        fake_span.end.assert_called_once_with(level="ERROR", status_message="test error")

    def test_noop_span_end_does_nothing(self):
        from owlmind.monitoring.tracing import _NoOpLangfuseSpan

        span = _NoOpLangfuseSpan()
        # Should not raise
        span.end()
        span.end(output={"x": 1})
        span.end(level="ERROR", status_message="boom")

    def test_span_end_called_with_no_args_on_clean_exit(self, monkeypatch):
        """When exiting cleanly without explicit span.end(), the context manager calls span.end()."""
        fake_span, fake_trace, fake_client, fake_mod = self._make_fakes()

        _patch_langfuse(monkeypatch, fake_mod)
        from owlmind.monitoring.tracing import _LangfuseClient

        _LangfuseClient.reset()

        from owlmind.monitoring.tracing import langfuse_span

        with langfuse_span("run-3", "planner"):
            pass  # no explicit span.end()

        # The context manager's else: clause calls span.end()
        fake_span.end.assert_called_once_with()

    def test_metadata_passed_to_trace(self, monkeypatch):
        """metadata kwarg is forwarded to client.trace()."""
        fake_span, fake_trace, fake_client, fake_mod = self._make_fakes()

        _patch_langfuse(monkeypatch, fake_mod)
        from owlmind.monitoring.tracing import _LangfuseClient

        _LangfuseClient.reset()

        from owlmind.monitoring.tracing import langfuse_span

        meta = {"env": "test", "version": "1.0"}
        with langfuse_span("run-4", "planner", metadata=meta):
            pass

        fake_client.trace.assert_called_once_with(
            id="run-4", name="owlmind_planner", metadata=meta
        )

    def test_exception_propagated_after_span_end(self, monkeypatch):
        """Exception raised inside langfuse_span is re-raised after error span.end()."""
        fake_span, fake_trace, fake_client, fake_mod = self._make_fakes()

        _patch_langfuse(monkeypatch, fake_mod)
        from owlmind.monitoring.tracing import _LangfuseClient

        _LangfuseClient.reset()

        from owlmind.monitoring.tracing import langfuse_span

        with pytest.raises(RuntimeError, match="boom"), langfuse_span("run-5", "worker"):
            raise RuntimeError("boom")

        fake_span.end.assert_called_once_with(level="ERROR", status_message="boom")


class TestNoOpLangfuseSpan:
    """Tests for _NoOpLangfuseSpan."""

    def test_context_manager(self):
        from owlmind.monitoring.tracing import _NoOpLangfuseSpan

        with _NoOpLangfuseSpan() as s:
            assert isinstance(s, _NoOpLangfuseSpan)

    def test_end_accepts_kwargs(self):
        from owlmind.monitoring.tracing import _NoOpLangfuseSpan

        s = _NoOpLangfuseSpan()
        s.end(output={"tokens": 5}, level="DEFAULT", status_message="ok")

    def test_end_no_args(self):
        from owlmind.monitoring.tracing import _NoOpLangfuseSpan

        s = _NoOpLangfuseSpan()
        s.end()  # Should not raise

    def test_exit_ignores_exceptions(self):
        """__exit__ does not suppress exceptions."""
        from owlmind.monitoring.tracing import _NoOpLangfuseSpan

        with pytest.raises(KeyError), _NoOpLangfuseSpan():
            raise KeyError("test")
