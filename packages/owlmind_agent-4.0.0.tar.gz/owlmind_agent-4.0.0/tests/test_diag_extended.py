"""Tests for extended doctor diagnostics."""

from __future__ import annotations

from pathlib import Path


class TestExtendedDoctor:
    def test_run_extended_doctor_basic(self, tmp_path: Path) -> None:
        from owlmind.config import OwlMindConfig
        from owlmind.diag_extended import run_extended_doctor

        cfg = OwlMindConfig()
        policies_dir = tmp_path / "policies"
        policies_dir.mkdir()

        checks = run_extended_doctor(cfg, policies_dir)
        assert len(checks) > 0
        assert all(hasattr(c, "name") and hasattr(c, "ok") for c in checks)

    def test_check_categories(self, tmp_path: Path) -> None:
        from owlmind.config import OwlMindConfig
        from owlmind.diag_extended import run_extended_doctor

        cfg = OwlMindConfig()
        policies_dir = tmp_path / "policies"
        policies_dir.mkdir()

        checks = run_extended_doctor(cfg, policies_dir)
        categories = {c.category for c in checks}
        # Should have at least config and deps categories
        assert "config" in categories or "deps" in categories

    def test_diag_check_has_fix_hint(self, tmp_path: Path) -> None:
        from owlmind.config import OwlMindConfig
        from owlmind.diag_extended import run_extended_doctor

        cfg = OwlMindConfig()
        policies_dir = tmp_path / "policies"
        policies_dir.mkdir()

        checks = run_extended_doctor(cfg, policies_dir)
        # All checks should have a fix_hint (even if empty)
        assert all(hasattr(c, "fix_hint") for c in checks)
