"""Tests for session parallel execution — no network calls."""

from __future__ import annotations

from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import yaml

from owlmind.session import (
    SESSION_BLOCKED,
    SESSION_DONE,
    SESSION_FAILED,
    create_session,
)
from owlmind.session_runner import run_session


def _write_goals(
    tmp_path: Path,
    goals: list[dict[str, Any]],
    defaults: dict[str, Any] | None = None,
) -> Path:
    data: dict[str, Any] = {"version": 2, "goals": goals}
    if defaults:
        data["defaults"] = defaults
    path = tmp_path / "goals.yaml"
    path.write_text(yaml.dump(data))
    return path


def _make_policies(tmp_path: Path) -> Path:
    policies_dir = tmp_path / "policies"
    policies_dir.mkdir(exist_ok=True)
    (policies_dir / "allowlist.yaml").write_text('allowed_commands:\n  - "^echo "\n  - "^pytest"\n')
    (policies_dir / "policy.yaml").write_text('forbidden_patterns:\n  - "rm -rf"\n')
    return policies_dir


def _mock_result(run_id: str, state: str = "DONE") -> MagicMock:
    m = MagicMock()
    m.run_id = run_id
    m.final_state = state
    m.stop_reason = f"terminal state: {state}"
    m.export_path = None
    return m


class TestSequentialDag:
    def test_linear_dag_all_done(self, tmp_path: Path) -> None:
        """Linear DAG: G1 → G2 → G3, all DONE."""
        goals_path = _write_goals(
            tmp_path,
            [
                {"id": "G1", "goal": "First", "depends_on": []},
                {"id": "G2", "goal": "Second", "depends_on": ["G1"]},
                {"id": "G3", "goal": "Third", "depends_on": ["G2"]},
            ],
        )
        policies_dir = _make_policies(tmp_path)
        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"
        ledger_dir = tmp_path / "ledger"

        meta = create_session(
            goals_file=goals_path,
            workspace=str(tmp_path),
            sessions_dir=sessions_dir,
            policies_dir=str(policies_dir),
            runs_dir=str(runs_dir),
            ledger_dir=str(ledger_dir),
        )

        mocks = [
            _mock_result("cycle-1"),
            _mock_result("cycle-2"),
            _mock_result("cycle-3"),
        ]

        with patch("owlmind.autopilot.run", side_effect=mocks):
            result = run_session(
                meta.session_id,
                sessions_dir=sessions_dir,
                runs_dir=runs_dir,
                policies_dir=policies_dir,
                ledger_dir=ledger_dir,
            )

        assert result.status == SESSION_DONE
        assert result.goals_done == 3

    def test_diamond_dag_all_done(self, tmp_path: Path) -> None:
        """Diamond: G1 → G2+G3 → G4, all DONE (sequential, concurrency=1)."""
        goals_path = _write_goals(
            tmp_path,
            [
                {"id": "G1", "goal": "Base", "depends_on": []},
                {"id": "G2", "goal": "Left", "depends_on": ["G1"]},
                {"id": "G3", "goal": "Right", "depends_on": ["G1"]},
                {"id": "G4", "goal": "Merge", "depends_on": ["G2", "G3"]},
            ],
        )
        policies_dir = _make_policies(tmp_path)
        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"
        ledger_dir = tmp_path / "ledger"

        meta = create_session(
            goals_file=goals_path,
            workspace=str(tmp_path),
            sessions_dir=sessions_dir,
            policies_dir=str(policies_dir),
            runs_dir=str(runs_dir),
            ledger_dir=str(ledger_dir),
        )

        mocks = [_mock_result(f"cycle-{i}") for i in range(1, 5)]

        with patch("owlmind.autopilot.run", side_effect=mocks):
            result = run_session(
                meta.session_id,
                sessions_dir=sessions_dir,
                runs_dir=runs_dir,
                policies_dir=policies_dir,
                ledger_dir=ledger_dir,
            )

        assert result.status == SESSION_DONE
        assert result.goals_done == 4


class TestContinueOnFail:
    def test_stop_on_fail_default(self, tmp_path: Path) -> None:
        """Default: session fails when a goal fails."""
        goals_path = _write_goals(
            tmp_path,
            [
                {"id": "G1", "goal": "Pass", "depends_on": []},
                {"id": "G2", "goal": "Fail", "depends_on": ["G1"]},
                {"id": "G3", "goal": "Never", "depends_on": ["G2"]},
            ],
        )
        policies_dir = _make_policies(tmp_path)
        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"
        ledger_dir = tmp_path / "ledger"

        meta = create_session(
            goals_file=goals_path,
            workspace=str(tmp_path),
            sessions_dir=sessions_dir,
            policies_dir=str(policies_dir),
            runs_dir=str(runs_dir),
            ledger_dir=str(ledger_dir),
        )

        mocks = [
            _mock_result("cycle-1", "DONE"),
            _mock_result("cycle-2", "FAILED"),
        ]

        with patch("owlmind.autopilot.run", side_effect=mocks):
            result = run_session(
                meta.session_id,
                sessions_dir=sessions_dir,
                runs_dir=runs_dir,
                policies_dir=policies_dir,
                ledger_dir=ledger_dir,
            )

        assert result.status == SESSION_FAILED
        assert result.goals_done == 1
        assert result.goals_failed == 1

    def test_continue_on_fail_skips_dependent(self, tmp_path: Path) -> None:
        """With continue_on_fail: dependent goals are SKIPPED."""
        goals_path = _write_goals(
            tmp_path,
            [
                {"id": "G1", "goal": "Pass", "depends_on": []},
                {"id": "G2", "goal": "Fail", "depends_on": ["G1"]},
                {"id": "G3", "goal": "Skipped", "depends_on": ["G2"]},
            ],
        )
        policies_dir = _make_policies(tmp_path)
        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"
        ledger_dir = tmp_path / "ledger"

        meta = create_session(
            goals_file=goals_path,
            workspace=str(tmp_path),
            sessions_dir=sessions_dir,
            policies_dir=str(policies_dir),
            runs_dir=str(runs_dir),
            ledger_dir=str(ledger_dir),
            continue_on_fail=True,
        )

        mocks = [
            _mock_result("cycle-1", "DONE"),
            _mock_result("cycle-2", "FAILED"),
        ]

        with patch("owlmind.autopilot.run", side_effect=mocks):
            result = run_session(
                meta.session_id,
                sessions_dir=sessions_dir,
                runs_dir=runs_dir,
                policies_dir=policies_dir,
                ledger_dir=ledger_dir,
            )

        assert result.status == SESSION_DONE
        assert result.goals_done == 1
        assert result.goals_failed == 1
        assert result.goals_skipped == 1


class TestParallelExecution:
    def test_max_concurrency_parallel(self, tmp_path: Path) -> None:
        """max_concurrency=2: independent goals run in parallel."""
        goals_path = _write_goals(
            tmp_path,
            [
                {"id": "G1", "goal": "First", "depends_on": []},
                {"id": "G2", "goal": "Second", "depends_on": []},
            ],
        )
        policies_dir = _make_policies(tmp_path)
        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"
        ledger_dir = tmp_path / "ledger"

        meta = create_session(
            goals_file=goals_path,
            workspace=str(tmp_path),
            sessions_dir=sessions_dir,
            policies_dir=str(policies_dir),
            runs_dir=str(runs_dir),
            ledger_dir=str(ledger_dir),
            max_concurrency=2,
        )

        mocks = [
            _mock_result("cycle-1"),
            _mock_result("cycle-2"),
        ]

        with patch("owlmind.autopilot.run", side_effect=mocks):
            result = run_session(
                meta.session_id,
                sessions_dir=sessions_dir,
                runs_dir=runs_dir,
                policies_dir=policies_dir,
                ledger_dir=ledger_dir,
            )

        assert result.status == SESSION_DONE
        assert result.goals_done == 2

    def test_blocked_halts_parallel(self, tmp_path: Path) -> None:
        """When a goal blocks, session becomes BLOCKED."""
        goals_path = _write_goals(
            tmp_path,
            [
                {"id": "G1", "goal": "Blocks", "depends_on": []},
                {"id": "G2", "goal": "Also runs", "depends_on": []},
            ],
        )
        policies_dir = _make_policies(tmp_path)
        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"
        ledger_dir = tmp_path / "ledger"

        meta = create_session(
            goals_file=goals_path,
            workspace=str(tmp_path),
            sessions_dir=sessions_dir,
            policies_dir=str(policies_dir),
            runs_dir=str(runs_dir),
            ledger_dir=str(ledger_dir),
            max_concurrency=2,
        )

        mocks = [
            _mock_result("cycle-1", "WAIT_APPROVAL"),
            _mock_result("cycle-2"),
        ]

        with patch("owlmind.autopilot.run", side_effect=mocks):
            result = run_session(
                meta.session_id,
                sessions_dir=sessions_dir,
                runs_dir=runs_dir,
                policies_dir=policies_dir,
                ledger_dir=ledger_dir,
            )

        assert result.status == SESSION_BLOCKED
        assert result.goals_blocked >= 1


class TestDagBlocked:
    def test_blocks_on_planner_wait(self, tmp_path: Path) -> None:
        """Session blocks when autopilot returns a WAIT state."""
        goals_path = _write_goals(
            tmp_path,
            [{"id": "G1", "goal": "Test", "use_llm": "none", "use_worker": "none", "max_steps": 3}],
        )
        policies_dir = _make_policies(tmp_path)
        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"
        ledger_dir = tmp_path / "ledger"

        meta = create_session(
            goals_file=goals_path,
            workspace=str(tmp_path),
            sessions_dir=sessions_dir,
            policies_dir=str(policies_dir),
            runs_dir=str(runs_dir),
            ledger_dir=str(ledger_dir),
        )

        result = run_session(
            meta.session_id,
            sessions_dir=sessions_dir,
            runs_dir=runs_dir,
            policies_dir=policies_dir,
            ledger_dir=ledger_dir,
        )

        assert result.status == SESSION_BLOCKED
        assert result.goals_blocked >= 1
