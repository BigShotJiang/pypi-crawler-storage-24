"""Tests for Gemini LLM driver — NO network calls (fully mocked)."""

from __future__ import annotations

import json
from types import SimpleNamespace
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from owlmind.config import GeminiConfig
from owlmind.errors import StructuralError, TransientError
from owlmind.llm.gemini_driver import GeminiDriver, is_gemini_available


def _make_config(**overrides: Any) -> GeminiConfig:
    return GeminiConfig(
        api_key=overrides.get("api_key", "test-gemini-key"),
        model=overrides.get("model", "gemini-test"),
        max_output_tokens=overrides.get("max_output_tokens", 500),
        timeout_sec=overrides.get("timeout_sec", 10),
    )


def _mock_response(content_dict: dict[str, Any], *, with_usage: bool = True) -> SimpleNamespace:
    """Build a mock Gemini generate_content response."""
    resp = SimpleNamespace(text=json.dumps(content_dict))
    if with_usage:
        resp.usage_metadata = SimpleNamespace(
            prompt_token_count=80,
            candidates_token_count=40,
        )
    else:
        resp.usage_metadata = None
    return resp


_PLANNER_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "run_id": {"type": "string"},
        "iteration": {"type": "integer"},
        "plan_summary": {"type": "array", "items": {"type": "string"}},
        "worker_instructions": {"type": "string"},
        "verify_commands": {"type": "array", "items": {"type": "string"}},
        "risk_notes": {"type": "array", "items": {"type": "string"}},
    },
    "required": [
        "run_id",
        "iteration",
        "plan_summary",
        "worker_instructions",
        "verify_commands",
        "risk_notes",
    ],
    "additionalProperties": False,
}

_JUDGE_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "run_id": {"type": "string"},
        "iteration": {"type": "integer"},
        "verdict": {"type": "string", "enum": ["APPROVED", "NEEDS_FIX", "REJECTED"]},
        "notes": {"type": "array", "items": {"type": "string"}},
        "next_worker_instructions": {"type": "string"},
        "evidence_chain_verified": {"type": "boolean"},
    },
    "required": [
        "run_id",
        "iteration",
        "verdict",
        "notes",
        "next_worker_instructions",
        "evidence_chain_verified",
    ],
    "additionalProperties": False,
}


class TestIsGeminiAvailable:
    def test_returns_bool(self) -> None:
        result = is_gemini_available()
        assert isinstance(result, bool)


class TestGeminiDriverInit:
    @patch("owlmind.llm.gemini_driver._GEMINI_AVAILABLE", False)
    def test_no_client_without_sdk(self) -> None:
        config = _make_config()
        driver = GeminiDriver(config)
        assert driver._client is None

    def test_no_client_without_key(self) -> None:
        config = _make_config(api_key="")
        driver = GeminiDriver(config)
        assert driver._client is None

    def test_name(self) -> None:
        config = _make_config(api_key="")
        driver = GeminiDriver(config)
        assert driver.name == "gemini"

    def test_supports_structured(self) -> None:
        config = _make_config(api_key="")
        driver = GeminiDriver(config)
        assert driver.supports_structured is True


class TestGeminiDriverPlan:
    def test_plan_returns_valid_response(self) -> None:
        config = _make_config()
        driver = GeminiDriver(config)

        planner_response = {
            "run_id": "cycle-test",
            "iteration": 1,
            "plan_summary": ["Step 1: Do thing"],
            "worker_instructions": "Do the thing",
            "verify_commands": ["pytest -q"],
            "risk_notes": [],
        }
        mock_resp = _mock_response(planner_response)

        mock_client = MagicMock()
        mock_client.models.generate_content.return_value = mock_resp
        driver._client = mock_client

        request = {
            "run_id": "cycle-test",
            "iteration": 1,
            "goal": "Test goal",
            "repo_context": "Test repo",
            "constraints": ["Be safe"],
        }

        result, meta = driver.plan(request, _PLANNER_SCHEMA)

        assert result["run_id"] == "cycle-test"
        assert result["plan_summary"] == ["Step 1: Do thing"]
        assert meta["provider"] == "gemini"
        assert meta["model"] == "gemini-test"
        assert meta["usage"]["input_tokens"] == 80
        assert meta["usage"]["output_tokens"] == 40
        assert meta["usage"]["total_tokens"] == 120

    def test_plan_passes_response_schema(self) -> None:
        config = _make_config()
        driver = GeminiDriver(config)

        mock_client = MagicMock()
        mock_client.models.generate_content.return_value = _mock_response(
            {
                "run_id": "x",
                "iteration": 1,
                "plan_summary": [],
                "worker_instructions": "x",
                "verify_commands": [],
                "risk_notes": [],
            }
        )
        driver._client = mock_client

        driver.plan({"run_id": "x"}, _PLANNER_SCHEMA)

        call_kwargs = mock_client.models.generate_content.call_args.kwargs
        assert call_kwargs["config"]["response_mime_type"] == "application/json"
        assert call_kwargs["config"]["response_schema"] == _PLANNER_SCHEMA


class TestGeminiDriverJudge:
    def test_judge_returns_valid_response(self) -> None:
        config = _make_config()
        driver = GeminiDriver(config)

        judge_response = {
            "run_id": "cycle-test",
            "iteration": 1,
            "verdict": "APPROVED",
            "notes": ["Good"],
            "next_worker_instructions": "",
            "evidence_chain_verified": True,
        }
        mock_resp = _mock_response(judge_response)

        mock_client = MagicMock()
        mock_client.models.generate_content.return_value = mock_resp
        driver._client = mock_client

        request = {
            "run_id": "cycle-test",
            "iteration": 1,
            "goal": "Test goal",
            "planner_plan_summary": ["Step 1"],
            "worker_done_summary": ["Done"],
            "verify_results_summary": ["pytest: PASS"],
            "evidence_paths": [],
        }

        result, meta = driver.judge(request, _JUDGE_SCHEMA)
        assert result["verdict"] == "APPROVED"
        assert meta["provider"] == "gemini"


class TestGeminiDriverErrors:
    def test_raises_without_client(self) -> None:
        config = _make_config(api_key="")
        driver = GeminiDriver(config)

        with pytest.raises(RuntimeError, match="not initialized"):
            driver.plan({"run_id": "x"}, _PLANNER_SCHEMA)

    @patch("owlmind.llm.gemini_driver.time.sleep")
    def test_retries_on_transient_error(self, mock_sleep: MagicMock) -> None:
        config = _make_config()
        driver = GeminiDriver(config)

        mock_client = MagicMock()
        mock_client.models.generate_content.side_effect = [
            RuntimeError("503 Service Unavailable"),
            _mock_response(
                {
                    "run_id": "x",
                    "iteration": 1,
                    "plan_summary": [],
                    "worker_instructions": "x",
                    "verify_commands": [],
                    "risk_notes": [],
                }
            ),
        ]
        driver._client = mock_client

        result, _ = driver.plan({"run_id": "x"}, _PLANNER_SCHEMA)
        assert result["run_id"] == "x"
        assert mock_client.models.generate_content.call_count == 2

    @patch("owlmind.llm.retry.time.sleep")
    def test_fails_after_max_retries(self, mock_sleep: MagicMock) -> None:
        config = _make_config()
        driver = GeminiDriver(config)

        mock_client = MagicMock()
        mock_client.models.generate_content.side_effect = RuntimeError("Connection timeout")
        driver._client = mock_client

        with pytest.raises(TransientError, match="failed after 3 retries"):
            driver.plan({"run_id": "x"}, _PLANNER_SCHEMA)

    def test_json_decode_error_no_retry(self) -> None:
        config = _make_config()
        driver = GeminiDriver(config)

        bad_response = SimpleNamespace(text="not json!!!", usage_metadata=None)

        mock_client = MagicMock()
        mock_client.models.generate_content.return_value = bad_response
        driver._client = mock_client

        with pytest.raises(StructuralError, match="JSON decode error"):
            driver.plan({"run_id": "x"}, _PLANNER_SCHEMA)

        assert mock_client.models.generate_content.call_count == 1


class TestGeminiDriverUsageMissing:
    def test_handles_missing_usage(self) -> None:
        config = _make_config()
        driver = GeminiDriver(config)

        mock_resp = _mock_response(
            {
                "run_id": "x",
                "iteration": 1,
                "plan_summary": [],
                "worker_instructions": "x",
                "verify_commands": [],
                "risk_notes": [],
            },
            with_usage=False,
        )

        mock_client = MagicMock()
        mock_client.models.generate_content.return_value = mock_resp
        driver._client = mock_client

        _, meta = driver.plan({"run_id": "x"}, _PLANNER_SCHEMA)
        assert meta["usage"]["usage_missing"] is True
        assert meta["usage"]["total_tokens"] == 0
