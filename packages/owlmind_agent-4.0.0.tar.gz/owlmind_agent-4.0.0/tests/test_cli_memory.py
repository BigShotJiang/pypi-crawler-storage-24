"""Tests for FS70 — CLI memory commands (ingest, query, stats, purge)."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from owlmind.cli import app

runner = CliRunner()


def _mock_retrieval_result() -> MagicMock:
    """Build a mock RetrievalResult with all required attributes."""
    result = MagicMock()
    result.source = "README.md"
    result.score = 0.95
    result.snippet = "Test content"
    result.doc_id = "doc-001"
    result.chunk_id = "chunk-001"
    return result


class TestMemoryIngest:
    def test_ingest_ok(self, tmp_path: Path) -> None:
        """memory ingest with --paths → exit 0, 'Ingested' in output."""
        test_file = tmp_path / "README.md"
        test_file.write_text("# Test\nHello world")

        mock_store = MagicMock()

        with patch("owlmind.memory.store.MemoryStore", return_value=mock_store):
            result = runner.invoke(
                app,
                [
                    "memory",
                    "ingest",
                    "--workspace",
                    str(tmp_path),
                    "--paths",
                    str(test_file),
                ],
            )

        assert result.exit_code == 0, result.output
        assert "Ingested" in result.output


class TestMemoryQuery:
    def test_query_ok(self, tmp_path: Path) -> None:
        """memory query → exit 0, results rendered as table."""
        mock_result = _mock_retrieval_result()
        mock_store = MagicMock()

        with (
            patch("owlmind.memory.store.MemoryStore", return_value=mock_store),
            patch("owlmind.memory.retrieval.query", return_value=[mock_result]),
        ):
            result = runner.invoke(
                app,
                ["memory", "query", "test query", "--workspace", str(tmp_path)],
            )

        assert result.exit_code == 0, result.output

    def test_query_json_output(self, tmp_path: Path) -> None:
        """memory query --json → exit 0, JSON output."""
        mock_result = _mock_retrieval_result()
        mock_store = MagicMock()

        with (
            patch("owlmind.memory.store.MemoryStore", return_value=mock_store),
            patch("owlmind.memory.retrieval.query", return_value=[mock_result]),
        ):
            result = runner.invoke(
                app,
                ["memory", "query", "test query", "--workspace", str(tmp_path), "--json"],
            )

        assert result.exit_code == 0, result.output


class TestMemoryStats:
    def test_stats_no_db(self, tmp_path: Path) -> None:
        """memory stats without existing db → exit 0, 'No memory store' in output."""
        result = runner.invoke(
            app,
            ["memory", "stats", "--workspace", str(tmp_path)],
        )

        assert result.exit_code == 0
        assert "No memory store" in result.output


class TestMemoryPurge:
    def test_purge_with_yes(self, tmp_path: Path) -> None:
        """memory purge --yes with existing db → exit 0, 'Purged' in output."""
        db_path = tmp_path / "memory" / "owlmind_memory.db"
        db_path.parent.mkdir(parents=True)
        db_path.touch()

        mock_store = MagicMock()
        mock_store.purge.return_value = 5

        with patch("owlmind.memory.store.MemoryStore", return_value=mock_store):
            result = runner.invoke(
                app,
                ["memory", "purge", "--workspace", str(tmp_path), "--yes"],
            )

        assert result.exit_code == 0, result.output
        assert "Purged" in result.output
        mock_store.purge.assert_called_once()


class TestMemoryIngestExtended:
    def test_ingest_kind_runs(self, tmp_path: Path) -> None:
        """memory ingest --kind runs → ingests run cycle_meta.json files."""
        runs_dir = tmp_path / "runs" / "run-001"
        runs_dir.mkdir(parents=True)
        meta = runs_dir / "cycle_meta.json"
        meta.write_text('{"run_id": "run-001"}')

        mock_store = MagicMock()

        with patch("owlmind.memory.store.MemoryStore", return_value=mock_store):
            result = runner.invoke(
                app,
                [
                    "memory",
                    "ingest",
                    "--workspace",
                    str(tmp_path),
                    "--kind",
                    "runs",
                ],
            )

        assert result.exit_code == 0, result.output
        assert "Ingested" in result.output
        mock_store.ingest.assert_called_once_with("run", str(meta), '{"run_id": "run-001"}')

    def test_ingest_kind_sessions(self, tmp_path: Path) -> None:
        """memory ingest --kind sessions → ingests session_meta.json files."""
        sess_dir = tmp_path / "sessions" / "sess-001"
        sess_dir.mkdir(parents=True)
        meta = sess_dir / "session_meta.json"
        meta.write_text('{"session_id": "sess-001"}')

        mock_store = MagicMock()

        with patch("owlmind.memory.store.MemoryStore", return_value=mock_store):
            result = runner.invoke(
                app,
                [
                    "memory",
                    "ingest",
                    "--workspace",
                    str(tmp_path),
                    "--kind",
                    "sessions",
                ],
            )

        assert result.exit_code == 0, result.output
        assert "Ingested" in result.output
        mock_store.ingest.assert_called_once_with(
            "session", str(meta), '{"session_id": "sess-001"}'
        )

    def test_ingest_kind_docs(self, tmp_path: Path) -> None:
        """memory ingest --kind docs → ingests matching doc files."""
        doc = tmp_path / "README.md"
        doc.write_text("# Project Readme")

        mock_store = MagicMock()

        with patch("owlmind.memory.store.MemoryStore", return_value=mock_store):
            result = runner.invoke(
                app,
                [
                    "memory",
                    "ingest",
                    "--workspace",
                    str(tmp_path),
                    "--kind",
                    "docs",
                ],
            )

        assert result.exit_code == 0, result.output
        assert "Ingested" in result.output

    def test_ingest_kind_all(self, tmp_path: Path) -> None:
        """memory ingest --kind all → ingests runs, sessions, and docs."""
        runs_dir = tmp_path / "runs" / "run-all"
        runs_dir.mkdir(parents=True)
        (runs_dir / "cycle_meta.json").write_text('{"run_id": "all"}')

        sess_dir = tmp_path / "sessions" / "sess-all"
        sess_dir.mkdir(parents=True)
        (sess_dir / "session_meta.json").write_text('{"session_id": "all"}')

        doc = tmp_path / "notes.txt"
        doc.write_text("Some notes")

        mock_store = MagicMock()

        with patch("owlmind.memory.store.MemoryStore", return_value=mock_store):
            result = runner.invoke(
                app,
                [
                    "memory",
                    "ingest",
                    "--workspace",
                    str(tmp_path),
                    "--kind",
                    "all",
                ],
            )

        assert result.exit_code == 0, result.output
        assert "Ingested" in result.output
        assert mock_store.ingest.call_count >= 3

    def test_ingest_paths_nonexistent_file(self, tmp_path: Path) -> None:
        """memory ingest --paths with missing file → skipped, still exit 0."""
        missing = tmp_path / "does_not_exist.md"

        mock_store = MagicMock()

        with patch("owlmind.memory.store.MemoryStore", return_value=mock_store):
            result = runner.invoke(
                app,
                [
                    "memory",
                    "ingest",
                    "--workspace",
                    str(tmp_path),
                    "--paths",
                    str(missing),
                ],
            )

        assert result.exit_code == 0, result.output
        assert "Ingested 0 documents" in result.output
        mock_store.ingest.assert_not_called()

    def test_ingest_no_runs_dir(self, tmp_path: Path) -> None:
        """memory ingest --kind runs with missing runs dir → 0 ingested."""
        mock_store = MagicMock()

        with patch("owlmind.memory.store.MemoryStore", return_value=mock_store):
            result = runner.invoke(
                app,
                ["memory", "ingest", "--workspace", str(tmp_path), "--kind", "runs"],
            )

        assert result.exit_code == 0, result.output
        assert "Ingested 0 documents" in result.output


class TestMemoryQueryExtended:
    def test_query_no_results(self, tmp_path: Path) -> None:
        """memory query with no results → 'No matching memory found'."""
        mock_store = MagicMock()

        with (
            patch("owlmind.memory.store.MemoryStore", return_value=mock_store),
            patch("owlmind.memory.retrieval.query", return_value=[]),
        ):
            result = runner.invoke(
                app,
                ["memory", "query", "nonexistent topic", "--workspace", str(tmp_path)],
            )

        assert result.exit_code == 0, result.output
        assert "No matching memory" in result.output

    def test_query_json_empty(self, tmp_path: Path) -> None:
        """memory query --json with no results → empty JSON array."""
        mock_store = MagicMock()

        with (
            patch("owlmind.memory.store.MemoryStore", return_value=mock_store),
            patch("owlmind.memory.retrieval.query", return_value=[]),
        ):
            result = runner.invoke(
                app,
                [
                    "memory",
                    "query",
                    "nothing",
                    "--workspace",
                    str(tmp_path),
                    "--json",
                ],
            )

        assert result.exit_code == 0, result.output

    def test_query_top_k_passed(self, tmp_path: Path) -> None:
        """memory query --top-k 3 → query called with top_k=3."""
        mock_store = MagicMock()

        with (
            patch("owlmind.memory.store.MemoryStore", return_value=mock_store),
            patch("owlmind.memory.retrieval.query", return_value=[]) as mock_query,
        ):
            result = runner.invoke(
                app,
                [
                    "memory",
                    "query",
                    "search text",
                    "--workspace",
                    str(tmp_path),
                    "--top-k",
                    "3",
                ],
            )

        assert result.exit_code == 0, result.output
        mock_query.assert_called_once_with(mock_store, "search text", top_k=3)


class TestMemoryStatsExtended:
    def test_stats_with_db(self, tmp_path: Path) -> None:
        """memory stats with existing db → table printed."""
        db_path = tmp_path / "memory" / "owlmind_memory.db"
        db_path.parent.mkdir(parents=True)
        db_path.touch()

        mock_store = MagicMock()
        mock_store.stats.return_value = {
            "documents": 10,
            "chunks": 50,
            "signals": 5,
            "docs_by_kind": {"doc": 8, "run": 2},
        }

        with patch("owlmind.memory.store.MemoryStore", return_value=mock_store):
            result = runner.invoke(
                app,
                ["memory", "stats", "--workspace", str(tmp_path)],
            )

        assert result.exit_code == 0, result.output
        mock_store.stats.assert_called_once()
        mock_store.close.assert_called_once()

    def test_stats_with_empty_docs_by_kind(self, tmp_path: Path) -> None:
        """memory stats with empty docs_by_kind → still renders correctly."""
        db_path = tmp_path / "memory" / "owlmind_memory.db"
        db_path.parent.mkdir(parents=True)
        db_path.touch()

        mock_store = MagicMock()
        mock_store.stats.return_value = {
            "documents": 0,
            "chunks": 0,
            "signals": 0,
        }

        with patch("owlmind.memory.store.MemoryStore", return_value=mock_store):
            result = runner.invoke(
                app,
                ["memory", "stats", "--workspace", str(tmp_path)],
            )

        assert result.exit_code == 0, result.output


class TestMemoryPurgeExtended:
    def test_purge_no_db(self, tmp_path: Path) -> None:
        """memory purge without existing db → 'No memory store found'."""
        result = runner.invoke(
            app,
            ["memory", "purge", "--workspace", str(tmp_path), "--yes"],
        )

        assert result.exit_code == 0, result.output
        assert "No memory store found" in result.output

    def test_purge_aborted(self, tmp_path: Path) -> None:
        """memory purge without --yes and user says no → 'Aborted'."""
        db_path = tmp_path / "memory" / "owlmind_memory.db"
        db_path.parent.mkdir(parents=True)
        db_path.touch()

        result = runner.invoke(
            app,
            ["memory", "purge", "--workspace", str(tmp_path)],
            input="n\n",
        )

        assert result.exit_code == 0, result.output
        assert "Aborted" in result.output

    def test_purge_older_than(self, tmp_path: Path) -> None:
        """memory purge --older-than 30 --yes → purge called with older_than_days=30."""
        db_path = tmp_path / "memory" / "owlmind_memory.db"
        db_path.parent.mkdir(parents=True)
        db_path.touch()

        mock_store = MagicMock()
        mock_store.purge.return_value = 3

        with patch("owlmind.memory.store.MemoryStore", return_value=mock_store):
            result = runner.invoke(
                app,
                [
                    "memory",
                    "purge",
                    "--workspace",
                    str(tmp_path),
                    "--older-than",
                    "30",
                    "--yes",
                ],
            )

        assert result.exit_code == 0, result.output
        assert "Purged 3 documents" in result.output
        mock_store.purge.assert_called_once_with(older_than_days=30)

    def test_purge_confirmed(self, tmp_path: Path) -> None:
        """memory purge without --yes and user confirms → purge executed."""
        db_path = tmp_path / "memory" / "owlmind_memory.db"
        db_path.parent.mkdir(parents=True)
        db_path.touch()

        mock_store = MagicMock()
        mock_store.purge.return_value = 7

        with patch("owlmind.memory.store.MemoryStore", return_value=mock_store):
            result = runner.invoke(
                app,
                ["memory", "purge", "--workspace", str(tmp_path)],
                input="y\n",
            )

        assert result.exit_code == 0, result.output
        assert "Purged 7 documents" in result.output
