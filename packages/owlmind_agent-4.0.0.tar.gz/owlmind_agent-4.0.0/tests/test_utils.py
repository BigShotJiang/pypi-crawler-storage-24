"""Tests for owlmind.utils — hashing, redaction, truncation, fingerprint."""

from __future__ import annotations

import pytest

from owlmind.utils import (
    ToolLimits,
    add,
    divide,
    env_fingerprint,
    multiply,
    power,
    redact_secrets,
    sha256,
    subtract,
    truncate,
)


class TestAdd:
    def test_add(self) -> None:
        assert add(2, 3) == 5

    def test_add_negative(self) -> None:
        assert add(-1, 1) == 0


class TestMultiply:
    def test_multiply(self) -> None:
        assert multiply(2, 3) == 6

    def test_multiply_negative(self) -> None:
        assert multiply(-1, 5) == -5


class TestSubtract:
    def test_subtract(self) -> None:
        assert subtract(5, 3) == 2

    def test_subtract_negative_result(self) -> None:
        assert subtract(0, 5) == -5

    def test_subtract_negative_numbers(self) -> None:
        assert subtract(-3, -7) == 4

    def test_subtract_zero(self) -> None:
        assert subtract(10, 0) == 10


class TestPower:
    def test_power_basic(self) -> None:
        assert power(2, 3) == 8.0

    def test_power_zero_exponent(self) -> None:
        assert power(5, 0) == 1.0

    def test_power_negative_exponent(self) -> None:
        assert power(2, -1) == 0.5

    def test_power_one_exponent(self) -> None:
        assert power(7, 1) == 7.0

    def test_power_fractional_exponent(self) -> None:
        assert power(4, 0.5) == 2.0

    def test_power_integer_inputs(self) -> None:
        assert power(3, 4) == 81.0

    def test_power_zero_base(self) -> None:
        assert power(0, 5) == 0.0


class TestDivide:
    def test_divide_normal(self) -> None:
        assert divide(10, 2) == 5

    def test_divide_float(self) -> None:
        assert divide(7, 2) == 3.5

    def test_divide_by_zero(self) -> None:
        with pytest.raises(ValueError, match="Division by zero is not allowed"):
            divide(10, 0)

    def test_divide_negative(self) -> None:
        assert divide(-10, 2) == -5


class TestSha256:
    def test_string_input(self) -> None:
        result = sha256("hello")
        assert len(result) == 64
        assert result == "2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824"

    def test_bytes_input(self) -> None:
        result = sha256(b"hello")
        assert result == sha256("hello")

    def test_empty_string(self) -> None:
        result = sha256("")
        assert len(result) == 64

    def test_deterministic(self) -> None:
        assert sha256("test") == sha256("test")

    def test_different_inputs(self) -> None:
        assert sha256("a") != sha256("b")


class TestRedactSecrets:
    def test_no_secrets(self) -> None:
        assert redact_secrets("Hello world") == "Hello world"

    def test_api_key(self) -> None:
        text = "api_key = sk-12345"
        result = redact_secrets(text)
        assert "sk-12345" not in result
        assert "[REDACTED]" in result

    def test_password(self) -> None:
        text = "password: hunter2"
        result = redact_secrets(text)
        assert "hunter2" not in result

    def test_openai_sk_token(self) -> None:
        text = "Using sk-abcdefghijklmnopqrstuvwxyz1234567890"
        result = redact_secrets(text)
        assert "sk-abcdefghijklmnopqrst" not in result

    def test_github_token(self) -> None:
        text = "Token: ghp_" + "A" * 36
        result = redact_secrets(text)
        assert "ghp_" not in result

    def test_bearer_token(self) -> None:
        text = "bearer = eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkw"
        result = redact_secrets(text)
        assert "eyJhbGciOiJIUzI1NiJ9" not in result

    def test_preserves_safe_text(self) -> None:
        text = "Running pytest -q --tb=short"
        assert redact_secrets(text) == text


class TestTruncate:
    def test_short_text_not_truncated(self) -> None:
        text, was_truncated = truncate("hello", max_bytes=100)
        assert text == "hello"
        assert was_truncated is False

    def test_long_text_truncated(self) -> None:
        text, was_truncated = truncate("A" * 200, max_bytes=50)
        assert was_truncated is True
        assert len(text.encode()) <= 100  # truncated + marker
        assert "[TRUNCATED]" in text

    def test_empty_text(self) -> None:
        text, was_truncated = truncate("", max_bytes=10)
        assert text == ""
        assert was_truncated is False

    def test_exact_boundary(self) -> None:
        text, was_truncated = truncate("ABCD", max_bytes=4)
        assert text == "ABCD"
        assert was_truncated is False


class TestEnvFingerprint:
    def test_returns_hex_string(self) -> None:
        fp = env_fingerprint()
        assert len(fp) == 64
        assert all(c in "0123456789abcdef" for c in fp)

    def test_deterministic(self) -> None:
        assert env_fingerprint() == env_fingerprint()


class TestToolLimits:
    def test_defaults(self) -> None:
        limits = ToolLimits()
        assert limits.timeout_seconds == 300
        assert limits.max_output_bytes == 1_048_576
        assert limits.max_memory_mb == 512
        assert limits.max_concurrent_tools == 1

    def test_custom_values(self) -> None:
        limits = ToolLimits(timeout_seconds=60, max_concurrent_tools=4)
        assert limits.timeout_seconds == 60
        assert limits.max_concurrent_tools == 4
