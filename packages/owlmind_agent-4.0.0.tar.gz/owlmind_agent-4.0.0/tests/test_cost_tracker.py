"""Tests for owlmind.graph.cost_tracker."""
from __future__ import annotations

from owlmind.graph.cost_tracker import NodeCost, RunCost

# ---------------------------------------------------------------------------
# NodeCost.estimated_usd — known models
# ---------------------------------------------------------------------------

def test_node_cost_anthropic_known_model():
    nc = NodeCost(
        node="architect",
        input_tokens=1_000_000,
        output_tokens=0,
        model="claude-3-5-sonnet",
        provider="anthropic",
    )
    assert abs(nc.estimated_usd - 3.00) < 1e-6


def test_node_cost_anthropic_known_model_output():
    nc = NodeCost(
        node="coder",
        input_tokens=0,
        output_tokens=1_000_000,
        model="claude-3-5-sonnet",
        provider="anthropic",
    )
    assert abs(nc.estimated_usd - 15.00) < 1e-6


def test_node_cost_openai_gpt4o():
    nc = NodeCost(
        node="reviewer",
        input_tokens=1_000_000,
        output_tokens=1_000_000,
        model="gpt-4o",
        provider="openai",
    )
    # input: 2.50, output: 10.00 => 12.50
    assert abs(nc.estimated_usd - 12.50) < 1e-6


def test_node_cost_anthropic_haiku():
    nc = NodeCost(
        node="tester",
        input_tokens=500_000,
        output_tokens=500_000,
        model="claude-3-haiku",
        provider="anthropic",
    )
    # input: 0.25/M * 0.5M = 0.125, output: 1.25/M * 0.5M = 0.625 => 0.75
    assert abs(nc.estimated_usd - 0.75) < 1e-6


# ---------------------------------------------------------------------------
# NodeCost.estimated_usd — unknown model returns 0.0
# ---------------------------------------------------------------------------

def test_node_cost_unknown_model_returns_zero():
    nc = NodeCost(
        node="reviewer",
        input_tokens=10_000,
        output_tokens=5_000,
        model="some-unknown-model-xyz",
        provider="anthropic",
    )
    assert nc.estimated_usd == 0.0


def test_node_cost_unknown_provider_returns_zero():
    nc = NodeCost(
        node="reviewer",
        input_tokens=10_000,
        output_tokens=5_000,
        model="gpt-4o",
        provider="mystery-provider",
    )
    assert nc.estimated_usd == 0.0


# ---------------------------------------------------------------------------
# RunCost — totals
# ---------------------------------------------------------------------------

def test_run_cost_total_tokens_sums_correctly():
    rc = RunCost()
    rc.add(NodeCost(node="a", input_tokens=100, output_tokens=50))
    rc.add(NodeCost(node="b", input_tokens=200, output_tokens=75))
    assert rc.total_input_tokens == 300
    assert rc.total_output_tokens == 125
    assert rc.total_tokens == 425


def test_run_cost_total_usd_sums_correctly():
    rc = RunCost()
    rc.add(NodeCost(node="a", input_tokens=1_000_000, output_tokens=0, model="gpt-4o-mini", provider="openai"))
    rc.add(NodeCost(node="b", input_tokens=0, output_tokens=1_000_000, model="gpt-4o-mini", provider="openai"))
    # input: 0.15, output: 0.60 => 0.75
    assert abs(rc.total_usd - 0.75) < 1e-6


# ---------------------------------------------------------------------------
# RunCost.summary() format
# ---------------------------------------------------------------------------

def test_run_cost_summary_format():
    rc = RunCost()
    rc.add(NodeCost(node="architect", input_tokens=1000, output_tokens=500, model="claude-3-5-sonnet", provider="anthropic"))
    s = rc.summary()
    assert "Cost summary:" in s
    assert "tokens" in s
    assert "[architect]" in s
    assert "in=1000" in s
    assert "out=500" in s


# ---------------------------------------------------------------------------
# RunCost.as_dict() structure
# ---------------------------------------------------------------------------

def test_run_cost_as_dict_structure():
    rc = RunCost()
    rc.add(NodeCost(node="coder", input_tokens=200, output_tokens=100, model="gpt-4o", provider="openai"))
    d = rc.as_dict()
    assert "total_tokens" in d
    assert "total_input_tokens" in d
    assert "total_output_tokens" in d
    assert "total_usd" in d
    assert "nodes" in d
    assert len(d["nodes"]) == 1
    node_d = d["nodes"][0]
    assert node_d["node"] == "coder"
    assert node_d["input_tokens"] == 200
    assert node_d["output_tokens"] == 100
    assert node_d["model"] == "gpt-4o"
    assert node_d["provider"] == "openai"
    assert "estimated_usd" in node_d


# ---------------------------------------------------------------------------
# Fuzzy model name matching
# ---------------------------------------------------------------------------

def test_fuzzy_model_matching_full_versioned_name():
    """'claude-3-5-sonnet-20241022' should match 'claude-3-5-sonnet' key."""
    nc = NodeCost(
        node="architect",
        input_tokens=1_000_000,
        output_tokens=0,
        model="claude-3-5-sonnet-20241022",
        provider="anthropic",
    )
    assert abs(nc.estimated_usd - 3.00) < 1e-6


def test_fuzzy_model_matching_gpt4o_variants():
    """'gpt-4o-2024-08-06' should match 'gpt-4o' key."""
    nc = NodeCost(
        node="coder",
        input_tokens=1_000_000,
        output_tokens=0,
        model="gpt-4o-2024-08-06",
        provider="openai",
    )
    assert abs(nc.estimated_usd - 2.50) < 1e-6


# ---------------------------------------------------------------------------
# Zero tokens = zero cost
# ---------------------------------------------------------------------------

def test_zero_tokens_zero_cost():
    nc = NodeCost(node="tester", input_tokens=0, output_tokens=0, model="claude-3-5-sonnet", provider="anthropic")
    assert nc.estimated_usd == 0.0
    assert nc.total_tokens == 0


def test_empty_run_cost_is_zero():
    rc = RunCost()
    assert rc.total_tokens == 0
    assert rc.total_usd == 0.0
    assert rc.total_input_tokens == 0
    assert rc.total_output_tokens == 0
