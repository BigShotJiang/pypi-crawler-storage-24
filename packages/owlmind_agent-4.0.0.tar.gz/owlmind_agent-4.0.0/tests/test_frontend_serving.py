"""Tests for frontend static file serving via FastAPI."""

from __future__ import annotations

from pathlib import Path

import pytest
from starlette.testclient import TestClient


@pytest.fixture()
def frontend_dir(tmp_path: Path) -> Path:
    """Create a mock frontend build directory."""
    fe = tmp_path / "frontend"
    fe.mkdir()
    assets = fe / "assets"
    assets.mkdir()

    # index.html
    (fe / "index.html").write_text("<!doctype html><html><body><div id=root></div></body></html>")
    # JS asset
    (assets / "index-abc123.js").write_text("console.log('owlmind');")
    # CSS asset
    (assets / "index-abc123.css").write_text("body{margin:0}")
    # favicon
    (fe / "vite.svg").write_text("<svg></svg>")

    return fe


@pytest.fixture()
def app_with_frontend(tmp_path: Path, frontend_dir: Path):
    """Create a FastAPI app with frontend serving enabled."""
    from owlmind.api.app import create_app

    app = create_app(
        runs_dir=tmp_path / "runs",
        ledger_dir=tmp_path / "ledger",
        queue_path=tmp_path / "queue",
        policies_dir=tmp_path / "policies",
        frontend_dir=frontend_dir,
    )
    return app


@pytest.fixture()
def app_without_frontend(tmp_path: Path):
    """Create a FastAPI app without frontend."""
    from owlmind.api.app import create_app

    app = create_app(
        runs_dir=tmp_path / "runs",
        ledger_dir=tmp_path / "ledger",
        queue_path=tmp_path / "queue",
        policies_dir=tmp_path / "policies",
        frontend_dir=None,
    )
    return app


class TestFrontendServing:
    """Tests for SPA static file serving."""

    def test_index_html_at_root(self, app_with_frontend) -> None:
        """Root path serves index.html."""
        client = TestClient(app_with_frontend)
        resp = client.get("/")
        assert resp.status_code == 200
        # Could be either the dashboard HTML or frontend index.html
        assert "html" in resp.text.lower()

    def test_js_asset(self, app_with_frontend) -> None:
        """JS assets are served from /assets/."""
        client = TestClient(app_with_frontend)
        resp = client.get("/assets/index-abc123.js")
        assert resp.status_code == 200
        assert "owlmind" in resp.text

    def test_css_asset(self, app_with_frontend) -> None:
        """CSS assets are served from /assets/."""
        client = TestClient(app_with_frontend)
        resp = client.get("/assets/index-abc123.css")
        assert resp.status_code == 200
        assert "margin" in resp.text

    def test_static_file_in_root(self, app_with_frontend) -> None:
        """Static files in frontend root are served directly."""
        client = TestClient(app_with_frontend)
        resp = client.get("/vite.svg")
        assert resp.status_code == 200
        assert "svg" in resp.text

    def test_spa_fallback(self, app_with_frontend) -> None:
        """Unknown paths fall back to index.html for SPA routing."""
        client = TestClient(app_with_frontend)
        resp = client.get("/runs")
        assert resp.status_code == 200
        assert "root" in resp.text

    def test_nested_spa_route(self, app_with_frontend) -> None:
        """Nested SPA routes also fall back to index.html."""
        client = TestClient(app_with_frontend)
        resp = client.get("/runs/some-run-id")
        assert resp.status_code == 200
        assert "root" in resp.text

    def test_api_not_intercepted(self, app_with_frontend) -> None:
        """API routes are NOT intercepted by SPA fallback."""
        client = TestClient(app_with_frontend)
        resp = client.get("/health")
        assert resp.status_code == 200
        data = resp.json()
        assert "status" in data

    def test_api_v1_not_intercepted(self, app_with_frontend) -> None:
        """API v1 routes work normally."""
        client = TestClient(app_with_frontend)
        resp = client.get("/api/v1/runs")
        # May return 200 (empty list) or require auth, but not SPA HTML
        assert resp.headers.get("content-type", "").startswith("application/json")

    def test_docs_not_intercepted(self, app_with_frontend) -> None:
        """Swagger docs are NOT intercepted by SPA fallback."""
        client = TestClient(app_with_frontend)
        resp = client.get("/docs")
        assert resp.status_code == 200
        assert "swagger" in resp.text.lower() or "html" in resp.text.lower()


class TestWithoutFrontend:
    """Tests that the app works normally when no frontend is configured."""

    def test_root_serves_dashboard(self, app_without_frontend) -> None:
        """Without frontend, root serves the old dashboard HTML."""
        client = TestClient(app_without_frontend)
        resp = client.get("/")
        assert resp.status_code == 200
        assert "OWLMIND" in resp.text

    def test_api_works(self, app_without_frontend) -> None:
        """API endpoints work without frontend."""
        client = TestClient(app_without_frontend)
        resp = client.get("/health")
        assert resp.status_code == 200


class TestFrontendDirMissing:
    """Tests for when frontend_dir is provided but doesn't exist."""

    def test_nonexistent_dir(self, tmp_path: Path) -> None:
        """Non-existent frontend_dir is gracefully handled."""
        from owlmind.api.app import create_app

        app = create_app(
            runs_dir=tmp_path / "runs",
            ledger_dir=tmp_path / "ledger",
            queue_path=tmp_path / "queue",
            policies_dir=tmp_path / "policies",
            frontend_dir=tmp_path / "nonexistent",
        )
        client = TestClient(app)
        resp = client.get("/health")
        assert resp.status_code == 200

    def test_empty_dir(self, tmp_path: Path) -> None:
        """Empty frontend_dir (no index.html) is gracefully handled."""
        from owlmind.api.app import create_app

        empty_dir = tmp_path / "empty_frontend"
        empty_dir.mkdir()

        app = create_app(
            runs_dir=tmp_path / "runs",
            ledger_dir=tmp_path / "ledger",
            queue_path=tmp_path / "queue",
            policies_dir=tmp_path / "policies",
            frontend_dir=empty_dir,
        )
        client = TestClient(app)
        resp = client.get("/health")
        assert resp.status_code == 200
