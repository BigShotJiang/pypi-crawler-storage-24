"""Tests for RabbitMQ-backed QueueStorage with mocked aio-pika."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest

from owlmind.queue import QueueItem, QueueStatus

# ===================================================================
# Mock aio_pika module (not installed in dev env)
# ===================================================================

_mock_aio_pika = MagicMock()
_mock_aio_pika.DeliveryMode.PERSISTENT = 2
_mock_aio_pika.ExchangeType.DIRECT = "direct"
_mock_aio_pika.connect_robust = AsyncMock()

# Make Message return a MagicMock that stores kwargs
_orig_message_cls = MagicMock


def _make_message(**kwargs: Any) -> MagicMock:
    m = MagicMock()
    for k, v in kwargs.items():
        setattr(m, k, v)
    return m


_mock_aio_pika.Message = _make_message

sys.modules.setdefault("aio_pika", _mock_aio_pika)

from owlmind.storage.rabbitmq import RabbitMQQueueStorage  # noqa: E402, I001


# ===================================================================
# Helpers & Fixtures
# ===================================================================


def _make_mock_message(item: QueueItem, delivery_tag: int = 1) -> MagicMock:
    """Create a mock RabbitMQ message from a QueueItem."""
    msg = MagicMock()
    msg.body = json.dumps(item.to_dict()).encode()
    msg.delivery_tag = delivery_tag
    msg.ack = AsyncMock()
    msg.nack = AsyncMock()
    return msg


def _make_malformed_message(delivery_tag: int = 99) -> MagicMock:
    """Create a mock message with invalid body."""
    msg = MagicMock()
    msg.body = b"\xff\xfe not json"
    msg.delivery_tag = delivery_tag
    msg.ack = AsyncMock()
    return msg


@pytest.fixture()
def storage(tmp_path: Path) -> RabbitMQQueueStorage:
    """RabbitMQQueueStorage with real SQLite, no RabbitMQ connection."""
    s = RabbitMQQueueStorage(
        rabbitmq_url="amqp://guest:guest@localhost/",
        state_db_path=tmp_path / "state.db",
        queue_name="test.tasks",
        max_priority=10,
    )
    # Pre-set mock RabbitMQ objects so _ensure_connected() is a no-op
    s._connection = MagicMock(is_closed=False)
    s._channel = MagicMock(is_closed=False)
    s._channel.basic_ack = AsyncMock()
    s._channel.basic_nack = AsyncMock()
    s._exchange = AsyncMock()
    s._queue = AsyncMock()
    return s


# ===================================================================
# Priority mapping
# ===================================================================


class TestPriorityMapping:
    def test_normal_priority(self, storage: RabbitMQQueueStorage) -> None:
        assert storage._map_priority(5) == 5

    def test_zero_priority(self, storage: RabbitMQQueueStorage) -> None:
        assert storage._map_priority(0) == 0

    def test_max_priority(self, storage: RabbitMQQueueStorage) -> None:
        assert storage._map_priority(10) == 10

    def test_over_max_clamped(self, storage: RabbitMQQueueStorage) -> None:
        assert storage._map_priority(100) == 10

    def test_negative_clamped(self, storage: RabbitMQQueueStorage) -> None:
        assert storage._map_priority(-5) == 0


# ===================================================================
# add()
# ===================================================================


@pytest.mark.asyncio()
class TestAdd:
    async def test_add_inserts_to_sqlite_and_publishes(self, storage: RabbitMQQueueStorage) -> None:
        item = await storage.add("Build feature X", "/workspace", priority=3)

        assert item.goal == "Build feature X"
        assert item.workspace == "/workspace"
        assert item.priority == 3
        assert item.status == QueueStatus.PENDING
        assert item.id.startswith("task-")

        # Verify SQLite insert
        row = storage._db.execute("SELECT * FROM queue_items WHERE id = ?", (item.id,)).fetchone()
        assert row is not None
        assert row["goal"] == "Build feature X"
        assert row["status"] == QueueStatus.PENDING

        # Verify RabbitMQ publish
        storage._exchange.publish.assert_called_once()

    async def test_add_with_sandbox(self, storage: RabbitMQQueueStorage) -> None:
        item = await storage.add("Test goal", "/ws", sandbox=True)
        assert item.sandbox is True

        row = storage._db.execute(
            "SELECT sandbox FROM queue_items WHERE id = ?", (item.id,)
        ).fetchone()
        assert row["sandbox"] == 1

    async def test_add_publishes_with_correct_priority(self, storage: RabbitMQQueueStorage) -> None:
        await storage.add("Goal", "/ws", priority=7)

        # Verify exchange.publish was called
        storage._exchange.publish.assert_called_once()
        call_args = storage._exchange.publish.call_args
        # The message is the first positional arg
        msg = call_args.args[0] if call_args.args else call_args.kwargs.get("message")
        assert msg is not None
        assert msg.priority == 7


# ===================================================================
# list_items()
# ===================================================================


@pytest.mark.asyncio()
class TestListItems:
    async def test_list_items_empty(self, storage: RabbitMQQueueStorage) -> None:
        items = await storage.list_items()
        assert items == []

    async def test_list_items_returns_all(self, storage: RabbitMQQueueStorage) -> None:
        await storage.add("Goal 1", "/ws1")
        await storage.add("Goal 2", "/ws2")
        items = await storage.list_items()
        assert len(items) == 2

    async def test_list_items_filtered_by_status(self, storage: RabbitMQQueueStorage) -> None:
        item1 = await storage.add("Goal 1", "/ws1")
        await storage.add("Goal 2", "/ws2")
        await storage.mark_running(item1.id, "run-001")

        pending = await storage.list_items(status=QueueStatus.PENDING)
        assert len(pending) == 1
        assert pending[0].goal == "Goal 2"

        running = await storage.list_items(status=QueueStatus.RUNNING)
        assert len(running) == 1
        assert running[0].id == item1.id

    async def test_list_items_ordered_by_priority(self, storage: RabbitMQQueueStorage) -> None:
        await storage.add("Low", "/ws", priority=1)
        await storage.add("High", "/ws", priority=9)
        await storage.add("Medium", "/ws", priority=5)

        items = await storage.list_items()
        assert items[0].goal == "High"
        assert items[1].goal == "Medium"
        assert items[2].goal == "Low"


# ===================================================================
# next_pending()
# ===================================================================


@pytest.mark.asyncio()
class TestNextPending:
    async def test_returns_none_when_queue_empty(self, storage: RabbitMQQueueStorage) -> None:
        storage._queue.get = AsyncMock(return_value=None)
        result = await storage.next_pending()
        assert result is None

    async def test_consumes_message_and_stores_delivery_tag(
        self, storage: RabbitMQQueueStorage
    ) -> None:
        item = await storage.add("Do work", "/ws")
        msg = _make_mock_message(item, delivery_tag=42)
        storage._queue.get = AsyncMock(return_value=msg)

        result = await storage.next_pending()
        assert result is not None
        assert result.id == item.id
        assert result.goal == "Do work"

        # Verify delivery_tag stored in SQLite
        row = storage._db.execute(
            "SELECT delivery_tag FROM queue_items WHERE id = ?", (item.id,)
        ).fetchone()
        assert row["delivery_tag"] == 42

    async def test_deduplicates_running_items(self, storage: RabbitMQQueueStorage) -> None:
        item = await storage.add("Task", "/ws")
        await storage.mark_running(item.id, "run-001")

        msg = _make_mock_message(item, delivery_tag=10)
        # First call returns duplicate, second returns None (queue empty)
        storage._queue.get = AsyncMock(side_effect=[msg, None])

        result = await storage.next_pending()
        assert result is None
        msg.ack.assert_called_once()

    async def test_deduplicates_done_items(self, storage: RabbitMQQueueStorage) -> None:
        item = await storage.add("Task", "/ws")

        # Manually set status to DONE in SQLite
        storage._db.execute(
            "UPDATE queue_items SET status = ? WHERE id = ?",
            (QueueStatus.DONE, item.id),
        )
        storage._db.commit()

        msg = _make_mock_message(item, delivery_tag=20)
        storage._queue.get = AsyncMock(side_effect=[msg, None])

        result = await storage.next_pending()
        assert result is None
        msg.ack.assert_called_once()

    async def test_skips_malformed_messages(self, storage: RabbitMQQueueStorage) -> None:
        bad_msg = _make_malformed_message()
        storage._queue.get = AsyncMock(side_effect=[bad_msg, None])

        result = await storage.next_pending()
        assert result is None
        bad_msg.ack.assert_called_once()

    async def test_skips_orphan_messages(self, storage: RabbitMQQueueStorage) -> None:
        # Message with item_id not in SQLite
        orphan_item = QueueItem(
            id="task-orphan",
            goal="Ghost",
            workspace="/ws",
            status=QueueStatus.PENDING,
        )
        msg = _make_mock_message(orphan_item, delivery_tag=55)
        storage._queue.get = AsyncMock(side_effect=[msg, None])

        result = await storage.next_pending()
        assert result is None
        msg.ack.assert_called_once()


# ===================================================================
# mark_running()
# ===================================================================


@pytest.mark.asyncio()
class TestMarkRunning:
    async def test_updates_status_and_run_id(self, storage: RabbitMQQueueStorage) -> None:
        item = await storage.add("Task", "/ws")
        await storage.mark_running(item.id, "run-abc")

        row = storage._db.execute(
            "SELECT status, run_id FROM queue_items WHERE id = ?", (item.id,)
        ).fetchone()
        assert row["status"] == QueueStatus.RUNNING
        assert row["run_id"] == "run-abc"


# ===================================================================
# mark_done()
# ===================================================================


@pytest.mark.asyncio()
class TestMarkDone:
    async def test_acks_message_and_updates_sqlite(self, storage: RabbitMQQueueStorage) -> None:
        item = await storage.add("Task", "/ws")

        # Simulate delivery_tag stored during next_pending()
        storage._db.execute(
            "UPDATE queue_items SET delivery_tag = ? WHERE id = ?",
            (77, item.id),
        )
        storage._db.commit()

        await storage.mark_done(item.id)

        # Verify basic_ack called
        storage._channel.basic_ack.assert_called_once_with(77)

        # Verify SQLite updated
        row = storage._db.execute(
            "SELECT status FROM queue_items WHERE id = ?", (item.id,)
        ).fetchone()
        assert row["status"] == QueueStatus.DONE

    async def test_marks_done_even_if_ack_fails(self, storage: RabbitMQQueueStorage) -> None:
        item = await storage.add("Task", "/ws")
        storage._db.execute(
            "UPDATE queue_items SET delivery_tag = ? WHERE id = ?",
            (88, item.id),
        )
        storage._db.commit()

        storage._channel.basic_ack = AsyncMock(side_effect=Exception("connection lost"))
        await storage.mark_done(item.id)

        row = storage._db.execute(
            "SELECT status FROM queue_items WHERE id = ?", (item.id,)
        ).fetchone()
        assert row["status"] == QueueStatus.DONE

    async def test_marks_done_without_delivery_tag(self, storage: RabbitMQQueueStorage) -> None:
        item = await storage.add("Task", "/ws")
        # No delivery_tag set (e.g. never consumed via next_pending)
        await storage.mark_done(item.id)

        row = storage._db.execute(
            "SELECT status FROM queue_items WHERE id = ?", (item.id,)
        ).fetchone()
        assert row["status"] == QueueStatus.DONE
        storage._channel.basic_ack.assert_not_called()


# ===================================================================
# mark_failed()
# ===================================================================


@pytest.mark.asyncio()
class TestMarkFailed:
    async def test_nacks_message_and_updates_sqlite(self, storage: RabbitMQQueueStorage) -> None:
        item = await storage.add("Task", "/ws")
        storage._db.execute(
            "UPDATE queue_items SET delivery_tag = ? WHERE id = ?",
            (33, item.id),
        )
        storage._db.commit()

        await storage.mark_failed(item.id, error="timeout")

        storage._channel.basic_nack.assert_called_once_with(33, requeue=False)

        row = storage._db.execute(
            "SELECT status, error FROM queue_items WHERE id = ?", (item.id,)
        ).fetchone()
        assert row["status"] == QueueStatus.FAILED
        assert row["error"] == "timeout"

    async def test_marks_failed_even_if_nack_fails(self, storage: RabbitMQQueueStorage) -> None:
        item = await storage.add("Task", "/ws")
        storage._db.execute(
            "UPDATE queue_items SET delivery_tag = ? WHERE id = ?",
            (44, item.id),
        )
        storage._db.commit()

        storage._channel.basic_nack = AsyncMock(side_effect=Exception("broken"))
        await storage.mark_failed(item.id, error="crash")

        row = storage._db.execute(
            "SELECT status, error FROM queue_items WHERE id = ?", (item.id,)
        ).fetchone()
        assert row["status"] == QueueStatus.FAILED
        assert row["error"] == "crash"

    async def test_marks_failed_without_delivery_tag(self, storage: RabbitMQQueueStorage) -> None:
        item = await storage.add("Task", "/ws")
        await storage.mark_failed(item.id, error="no tag")

        row = storage._db.execute(
            "SELECT status, error FROM queue_items WHERE id = ?", (item.id,)
        ).fetchone()
        assert row["status"] == QueueStatus.FAILED
        storage._channel.basic_nack.assert_not_called()


# ===================================================================
# close()
# ===================================================================


@pytest.mark.asyncio()
class TestClose:
    async def test_closes_connection_and_sqlite(self, storage: RabbitMQQueueStorage) -> None:
        mock_conn = AsyncMock()
        mock_conn.is_closed = False
        storage._connection = mock_conn

        await storage.close()

        mock_conn.close.assert_called_once()
        assert storage._connection is None

    async def test_close_when_already_closed(self, storage: RabbitMQQueueStorage) -> None:
        mock_conn = MagicMock()
        mock_conn.is_closed = True
        storage._connection = mock_conn

        await storage.close()
        mock_conn.close.assert_not_called()


# ===================================================================
# Full lifecycle
# ===================================================================


@pytest.mark.asyncio()
class TestFullLifecycle:
    async def test_add_consume_run_done(self, storage: RabbitMQQueueStorage) -> None:
        # 1. Add task
        item = await storage.add("Fix bug", "/repo", priority=5)
        assert item.status == QueueStatus.PENDING

        # 2. Simulate consume via next_pending
        msg = _make_mock_message(item, delivery_tag=100)
        storage._queue.get = AsyncMock(return_value=msg)
        consumed = await storage.next_pending()
        assert consumed is not None
        assert consumed.id == item.id

        # 3. Mark running
        await storage.mark_running(item.id, "run-xyz")
        items = await storage.list_items(status=QueueStatus.RUNNING)
        assert len(items) == 1
        assert items[0].run_id == "run-xyz"

        # 4. Mark done
        await storage.mark_done(item.id)
        storage._channel.basic_ack.assert_called_once_with(100)
        items = await storage.list_items(status=QueueStatus.DONE)
        assert len(items) == 1

    async def test_add_consume_fail(self, storage: RabbitMQQueueStorage) -> None:
        item = await storage.add("Risky task", "/repo")
        msg = _make_mock_message(item, delivery_tag=200)
        storage._queue.get = AsyncMock(return_value=msg)

        consumed = await storage.next_pending()
        assert consumed is not None

        await storage.mark_running(item.id, "run-fail")
        await storage.mark_failed(item.id, error="OOM")

        storage._channel.basic_nack.assert_called_once_with(200, requeue=False)
        items = await storage.list_items(status=QueueStatus.FAILED)
        assert len(items) == 1
        assert items[0].error == "OOM"


# ===================================================================
# Factory integration
# ===================================================================


class TestFactory:
    def test_rabbitmq_backend_creates_storage(self, tmp_path: Path) -> None:
        from owlmind.storage import StorageBackend, create_storage

        sb = create_storage(
            backend="rabbitmq",
            rabbitmq_url="amqp://guest:guest@localhost/",
            rabbitmq_state_db=tmp_path / "state.db",
            runs_dir=tmp_path / "runs",
            ledger_dir=tmp_path / "ledger",
            sessions_dir=tmp_path / "sessions",
        )
        assert isinstance(sb, StorageBackend)
        assert isinstance(sb.queue, RabbitMQQueueStorage)

    def test_rabbitmq_backend_without_url_raises(self, tmp_path: Path) -> None:
        from owlmind.storage import create_storage

        with pytest.raises(ValueError, match="rabbitmq_url is required"):
            create_storage(
                backend="rabbitmq",
                runs_dir=tmp_path / "runs",
                ledger_dir=tmp_path / "ledger",
                sessions_dir=tmp_path / "sessions",
            )


# ===================================================================
# SQLite state initialization
# ===================================================================


class TestStateDB:
    def test_creates_db_and_tables(self, tmp_path: Path) -> None:
        s = RabbitMQQueueStorage(
            state_db_path=tmp_path / "sub" / "state.db",
        )
        # Directory created
        assert (tmp_path / "sub").is_dir()

        # Table exists
        row = s._db.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='queue_items'"
        ).fetchone()
        assert row is not None

    def test_index_created(self, tmp_path: Path) -> None:
        s = RabbitMQQueueStorage(
            state_db_path=tmp_path / "state.db",
        )
        row = s._db.execute(
            "SELECT name FROM sqlite_master WHERE type='index' AND name='idx_queue_status'"
        ).fetchone()
        assert row is not None
