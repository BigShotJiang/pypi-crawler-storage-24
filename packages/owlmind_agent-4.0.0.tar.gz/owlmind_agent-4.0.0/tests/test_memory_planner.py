"""Tests for FS54 — Memory-Planner integration."""

from __future__ import annotations

from pathlib import Path

from owlmind.agent.schemas import PlannerRequest

# ---------------------------------------------------------------------------
# PlannerRequest schema tests
# ---------------------------------------------------------------------------


def test_planner_request_has_memory_context_field() -> None:
    """PlannerRequest should accept memory_context field."""
    req = PlannerRequest(
        run_id="test-001",
        iteration=1,
        goal="Add tests",
        memory_context="## Past Experience\nPrevious run: added tests successfully.",
    )
    assert req.memory_context == "## Past Experience\nPrevious run: added tests successfully."


def test_planner_request_memory_context_default_empty() -> None:
    """PlannerRequest memory_context defaults to empty string."""
    req = PlannerRequest(run_id="test-002", iteration=1, goal="Fix bug")
    assert req.memory_context == ""


# ---------------------------------------------------------------------------
# _build_planner_prompt tests
# ---------------------------------------------------------------------------


def test_planner_prompt_includes_past_experience() -> None:
    """_build_planner_prompt injects Past Experience section when memory_context set."""
    from owlmind.agent.cycle import _build_planner_prompt

    req = PlannerRequest(
        run_id="test-003",
        iteration=1,
        goal="Refactor auth module",
        memory_context="Previous run solved this with strategy X.",
    )
    prompt = _build_planner_prompt(req)
    assert "Past Experience" in prompt
    assert "Previous run solved this with strategy X." in prompt


def test_planner_prompt_omits_past_experience_when_empty() -> None:
    """_build_planner_prompt omits Past Experience when memory_context is empty."""
    from owlmind.agent.cycle import _build_planner_prompt

    req = PlannerRequest(run_id="test-004", iteration=1, goal="Add feature", memory_context="")
    prompt = _build_planner_prompt(req)
    assert "Past Experience" not in prompt


# ---------------------------------------------------------------------------
# Memory ingest after APPROVED tests
# ---------------------------------------------------------------------------


def test_submit_judge_approved_ingests_to_memory(tmp_path: Path) -> None:
    """submit_judge() APPROVED verdict ingests run data into memory_store."""
    import json

    from owlmind.agent.cycle import CycleManager
    from owlmind.agent.schemas import CycleRunMeta, CycleState, JudgeResponse
    from owlmind.evidence import EvidenceStore
    from owlmind.memory.store import MemoryStore
    from owlmind.policy import PolicyEngine

    runs_dir = tmp_path / "runs"
    policies_dir = tmp_path / "policies"
    policies_dir.mkdir()
    mem_db = tmp_path / "memory.db"

    evidence = EvidenceStore(runs_dir)
    policy = PolicyEngine.from_directory(policies_dir)
    mem_store = MemoryStore(mem_db)

    try:
        mgr = CycleManager(
            evidence=evidence,
            policy=policy,
            policies_dir=policies_dir,
            memory_store=mem_store,
        )

        run_id = "mem-test-001"
        evidence.create_run(run_id)

        # Create meta directly in WAIT_JUDGE state (skipping the full cycle)
        meta = CycleRunMeta(
            run_id=run_id,
            goal="Add unit tests for auth module",
            iteration=1,
            state=CycleState.WAIT_JUDGE,
            workspace=str(tmp_path),
            planner_plan_summary=["Write tests", "Run pytest"],
            worker_done_summary=["Added 10 tests", "All pass"],
            verify_results=["pytest -q: PASS"],
        )
        mgr._save_meta(meta)

        # Submit APPROVED verdict directly
        judge_resp = JudgeResponse(
            run_id=run_id,
            iteration=1,
            verdict="APPROVED",
            notes=["Looks good"],
            evidence_chain_verified=True,
        )
        inbox_dir = runs_dir / run_id / "inbox"
        inbox_dir.mkdir(parents=True, exist_ok=True)
        (inbox_dir / "judge_response.json").write_text(json.dumps(judge_resp.model_dump()))
        mgr.submit_judge(run_id)

        # Verify memory was ingested
        stats = mem_store.stats()
        assert stats["documents"] > 0, "Memory store should have ingested run data"

    finally:
        mem_store.close()


# ---------------------------------------------------------------------------
# CycleManager memory_store init test
# ---------------------------------------------------------------------------


def test_cycle_manager_accepts_memory_store(tmp_path: Path) -> None:
    """CycleManager.__init__ accepts memory_store parameter."""
    from owlmind.agent.cycle import CycleManager
    from owlmind.evidence import EvidenceStore
    from owlmind.memory.store import MemoryStore
    from owlmind.policy import PolicyEngine

    policies_dir = tmp_path / "policies"
    policies_dir.mkdir()
    mem_store = MemoryStore(tmp_path / "mem.db")

    try:
        mgr = CycleManager(
            evidence=EvidenceStore(tmp_path / "runs"),
            policy=PolicyEngine.from_directory(policies_dir),
            memory_store=mem_store,
        )
        assert mgr.memory_store is mem_store
    finally:
        mem_store.close()


def test_cycle_manager_memory_store_defaults_none(tmp_path: Path) -> None:
    """CycleManager.memory_store defaults to None."""
    from owlmind.agent.cycle import CycleManager
    from owlmind.evidence import EvidenceStore
    from owlmind.policy import PolicyEngine

    policies_dir = tmp_path / "policies"
    policies_dir.mkdir()
    mgr = CycleManager(
        evidence=EvidenceStore(tmp_path / "runs"),
        policy=PolicyEngine.from_directory(policies_dir),
    )
    assert mgr.memory_store is None
