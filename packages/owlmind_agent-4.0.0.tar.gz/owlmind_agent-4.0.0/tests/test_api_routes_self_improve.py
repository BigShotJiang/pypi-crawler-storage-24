"""Tests for POST /api/v1/self-improve/analyze and GET /api/v1/self-improve/insights."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from starlette.testclient import TestClient

from owlmind.api.app import create_app

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def tmp_dirs(tmp_path: Path) -> dict[str, Path]:
    dirs = {
        "runs": tmp_path / "runs",
        "ledger": tmp_path / "ledger",
        "queue": tmp_path / "queue",
        "policies": tmp_path / "policies",
        "packs": tmp_path / "skill-packs",
        "memory": tmp_path / "memory",
    }
    for d in dirs.values():
        d.mkdir(parents=True, exist_ok=True)
    return dirs


@pytest.fixture()
def client(tmp_dirs: dict[str, Path]) -> TestClient:
    app = create_app(
        runs_dir=tmp_dirs["runs"],
        ledger_dir=tmp_dirs["ledger"],
        queue_path=tmp_dirs["queue"],
        policies_dir=tmp_dirs["policies"],
        packs_dir=tmp_dirs["packs"],
        memory_db=tmp_dirs["memory"] / "memory.db",
    )
    return TestClient(app)


@pytest.fixture(autouse=True)
def _no_auth(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("owlmind.api.auth.verify_api_key", lambda: None)


def _make_insight(category: str = "error", description: str = "desc") -> MagicMock:
    ins = MagicMock()
    ins.category = category
    ins.description = description
    ins.frequency = 2
    ins.examples = ["ex1", "ex2"]
    return ins


# ===========================================================================
# POST /api/v1/self-improve/analyze
# ===========================================================================


class TestAnalyzeRuns:
    def test_analyze_returns_insights(self, client: TestClient, tmp_dirs: dict[str, Path]) -> None:
        """Happy path: analyze returns structured insights dict."""
        insight = _make_insight("performance", "Slow response time")
        with (
            patch("owlmind.self_improve.load_recent_runs", return_value=["run1"]),
            patch("owlmind.self_improve.analyze_runs", return_value=[insight]),
            patch(
                "owlmind.self_improve.format_insights_markdown",
                return_value="# Insights\n- slow",
            ),
        ):
            resp = client.post(
                "/api/v1/self-improve/analyze",
                json={"runs_dir": str(tmp_dirs["runs"]), "days": 7},
            )
        assert resp.status_code == 200
        data = resp.json()
        assert data["runs_analyzed"] == 1
        assert data["insights_count"] == 1
        assert data["insights"][0]["category"] == "performance"
        assert "# Insights" in data["markdown"]

    def test_analyze_empty_runs(self, client: TestClient, tmp_dirs: dict[str, Path]) -> None:
        """Empty runs directory returns zero counts."""
        with (
            patch("owlmind.self_improve.load_recent_runs", return_value=[]),
            patch("owlmind.self_improve.analyze_runs", return_value=[]),
            patch("owlmind.self_improve.format_insights_markdown", return_value=""),
        ):
            resp = client.post(
                "/api/v1/self-improve/analyze",
                json={"runs_dir": str(tmp_dirs["runs"]), "days": 3},
            )
        assert resp.status_code == 200
        data = resp.json()
        assert data["runs_analyzed"] == 0
        assert data["insights_count"] == 0

    def test_analyze_load_runs_error(self, client: TestClient, tmp_dirs: dict[str, Path]) -> None:
        """If load_recent_runs raises, endpoint returns 500."""
        with patch(
            "owlmind.self_improve.load_recent_runs",
            side_effect=RuntimeError("disk error"),
        ):
            resp = client.post(
                "/api/v1/self-improve/analyze",
                json={"runs_dir": str(tmp_dirs["runs"]), "days": 7},
            )
        assert resp.status_code == 500
        assert "disk error" in resp.json()["detail"]

    def test_analyze_save_to_memory(self, client: TestClient, tmp_dirs: dict[str, Path]) -> None:
        """save_to_memory=True triggers save_insights_to_memory call."""
        insight = _make_insight()
        with (
            patch("owlmind.self_improve.load_recent_runs", return_value=["r1"]),
            patch("owlmind.self_improve.analyze_runs", return_value=[insight]),
            patch("owlmind.self_improve.format_insights_markdown", return_value="md"),
            patch("owlmind.self_improve.save_insights_to_memory") as mock_save,
        ):
            resp = client.post(
                "/api/v1/self-improve/analyze",
                json={
                    "runs_dir": str(tmp_dirs["runs"]),
                    "days": 7,
                    "save_to_memory": True,
                    "memory_db": str(tmp_dirs["memory"] / "memory.db"),
                },
            )
        assert resp.status_code == 200
        data = resp.json()
        assert data.get("saved_to_memory") is True
        mock_save.assert_called_once()

    def test_analyze_save_to_memory_error(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        """save_insights_to_memory failure is captured in save_error key."""
        insight = _make_insight()
        with (
            patch("owlmind.self_improve.load_recent_runs", return_value=["r1"]),
            patch("owlmind.self_improve.analyze_runs", return_value=[insight]),
            patch("owlmind.self_improve.format_insights_markdown", return_value="md"),
            patch(
                "owlmind.self_improve.save_insights_to_memory",
                side_effect=OSError("write failed"),
            ),
        ):
            resp = client.post(
                "/api/v1/self-improve/analyze",
                json={
                    "runs_dir": str(tmp_dirs["runs"]),
                    "days": 7,
                    "save_to_memory": True,
                },
            )
        assert resp.status_code == 200
        assert "save_error" in resp.json()

    def test_analyze_save_to_memory_no_insights(
        self, client: TestClient, tmp_dirs: dict[str, Path]
    ) -> None:
        """save_to_memory=True but no insights: save not called."""
        with (
            patch("owlmind.self_improve.load_recent_runs", return_value=["r1"]),
            patch("owlmind.self_improve.analyze_runs", return_value=[]),
            patch("owlmind.self_improve.format_insights_markdown", return_value=""),
            patch("owlmind.self_improve.save_insights_to_memory") as mock_save,
        ):
            resp = client.post(
                "/api/v1/self-improve/analyze",
                json={"save_to_memory": True},
            )
        assert resp.status_code == 200
        mock_save.assert_not_called()

    def test_analyze_default_runs_dir(self, client: TestClient) -> None:
        """When runs_dir is empty string, falls back to router's runs_dir."""
        with (
            patch("owlmind.self_improve.load_recent_runs", return_value=[]),
            patch("owlmind.self_improve.analyze_runs", return_value=[]),
            patch("owlmind.self_improve.format_insights_markdown", return_value=""),
        ):
            resp = client.post(
                "/api/v1/self-improve/analyze",
                json={"runs_dir": "", "days": 7},
            )
        assert resp.status_code == 200


# ===========================================================================
# GET /api/v1/self-improve/insights
# ===========================================================================


class TestGetInsights:
    def test_insights_returns_markdown(self, client: TestClient) -> None:
        """Happy path: /insights returns runs_analyzed, count, markdown."""
        insight = _make_insight("retry", "Too many retries")
        with (
            patch("owlmind.self_improve.load_recent_runs", return_value=["r1", "r2"]),
            patch("owlmind.self_improve.analyze_runs", return_value=[insight]),
            patch(
                "owlmind.self_improve.format_insights_markdown",
                return_value="# Insights",
            ),
        ):
            resp = client.get("/api/v1/self-improve/insights?days=14")
        assert resp.status_code == 200
        data = resp.json()
        assert data["runs_analyzed"] == 2
        assert data["insights_count"] == 1
        assert data["markdown"] == "# Insights"

    def test_insights_default_days(self, client: TestClient) -> None:
        """Default days=7 is used when not specified."""
        with (
            patch("owlmind.self_improve.load_recent_runs", return_value=[]) as mock_load,
            patch("owlmind.self_improve.analyze_runs", return_value=[]),
            patch("owlmind.self_improve.format_insights_markdown", return_value=""),
        ):
            resp = client.get("/api/v1/self-improve/insights")
        assert resp.status_code == 200
        mock_load.assert_called_once()
        call_kwargs = mock_load.call_args
        assert call_kwargs[1]["days"] == 7 or call_kwargs[0][1] == 7

    def test_insights_error(self, client: TestClient) -> None:
        """If load_recent_runs raises, /insights returns 500."""
        with patch(
            "owlmind.self_improve.load_recent_runs",
            side_effect=ValueError("bad runs"),
        ):
            resp = client.get("/api/v1/self-improve/insights")
        assert resp.status_code == 500
        assert "bad runs" in resp.json()["detail"]

    def test_insights_invalid_days_too_low(self, client: TestClient) -> None:
        """days < 1 is rejected with 422."""
        resp = client.get("/api/v1/self-improve/insights?days=0")
        assert resp.status_code == 422

    def test_insights_invalid_days_too_high(self, client: TestClient) -> None:
        """days > 365 is rejected with 422."""
        resp = client.get("/api/v1/self-improve/insights?days=999")
        assert resp.status_code == 422

    def test_analyze_import_error(self, client: TestClient, tmp_dirs: dict[str, Path]) -> None:
        """If owlmind.self_improve cannot be imported, returns 503."""
        import sys

        orig = sys.modules.pop("owlmind.self_improve", None)
        try:
            sys.modules["owlmind.self_improve"] = None  # type: ignore[assignment]
            resp = client.post(
                "/api/v1/self-improve/analyze",
                json={"runs_dir": str(tmp_dirs["runs"]), "days": 7},
            )
        finally:
            if orig is not None:
                sys.modules["owlmind.self_improve"] = orig
            else:
                sys.modules.pop("owlmind.self_improve", None)
        assert resp.status_code == 503


class TestGetInsightsImportError:
    def test_insights_import_error(self, client: TestClient) -> None:
        """If owlmind.self_improve cannot be imported, /insights returns 503."""
        import sys

        orig = sys.modules.pop("owlmind.self_improve", None)
        try:
            sys.modules["owlmind.self_improve"] = None  # type: ignore[assignment]
            resp = client.get("/api/v1/self-improve/insights")
        finally:
            if orig is not None:
                sys.modules["owlmind.self_improve"] = orig
            else:
                sys.modules.pop("owlmind.self_improve", None)
        assert resp.status_code == 503
