"""Tests for multi-repo orchestration."""

from __future__ import annotations

from pathlib import Path


class TestMultiRepoConfig:
    def test_create_config(self) -> None:
        from owlmind.multi_repo import MultiRepoConfig, RepoConfig

        config = MultiRepoConfig(
            repos=[
                RepoConfig(path="/tmp/repo1", branch="main", remote="origin", goals=["fix bug"]),
                RepoConfig(path="/tmp/repo2", branch="main", remote="origin", goals=["update deps"]),
            ],
            dependency_graph={"repo2": ["repo1"]},
            rollback_policy="none",
        )
        assert len(config.repos) == 2
        assert config.rollback_policy == "none"

    def test_integration_test_model(self) -> None:
        from owlmind.multi_repo import IntegrationTest

        test = IntegrationTest(
            name="e2e",
            command="pytest tests/e2e",
            working_dir="/tmp",
            depends_on=["repo1", "repo2"],
        )
        assert test.name == "e2e"


class TestPatternAnalyzer:
    def test_analyze_empty_runs(self, tmp_path: Path) -> None:
        from owlmind.self_improve.pattern_analyzer import PatternAnalyzer

        analyzer = PatternAnalyzer(tmp_path)
        patterns = analyzer.analyze_failures(days=7)
        assert patterns == []

    def test_generate_report_empty(self, tmp_path: Path) -> None:
        from owlmind.self_improve.pattern_analyzer import PatternAnalyzer

        analyzer = PatternAnalyzer(tmp_path)
        report = analyzer.generate_report(days=7)
        assert report.overall_success_rate == 0.0
        assert report.patterns == []


class TestMarketplaceRegistry:
    def test_create_registry(self, tmp_path: Path) -> None:
        from owlmind.marketplace.registry import PackageRegistry

        db_path = tmp_path / "registry.db"
        registry = PackageRegistry(db_path)
        assert registry is not None

    def test_list_empty(self, tmp_path: Path) -> None:
        from owlmind.marketplace.registry import PackageRegistry

        db_path = tmp_path / "registry.db"
        registry = PackageRegistry(db_path)
        available = registry.list_available()
        assert available == []

    def test_search_empty(self, tmp_path: Path) -> None:
        from owlmind.marketplace.registry import PackageRegistry

        db_path = tmp_path / "registry.db"
        registry = PackageRegistry(db_path)
        results = registry.search("test")
        assert results == []
