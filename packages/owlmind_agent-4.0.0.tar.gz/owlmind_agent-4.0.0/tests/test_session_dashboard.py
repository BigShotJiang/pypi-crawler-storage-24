"""Tests for session and run dashboard generators."""

from __future__ import annotations

import json
from pathlib import Path

from owlmind.run_dashboard import generate_run_dashboard
from owlmind.session_dashboard import generate_session_dashboard


def _make_session(tmp_path: Path, *, with_runs: bool = False) -> str:
    """Create a minimal session for testing. Returns session_id."""
    sessions_dir = tmp_path / "sessions"
    sid = "session-dash"
    sdir = sessions_dir / sid
    sdir.mkdir(parents=True)

    runs: list[dict[str, str]] = []
    if with_runs:
        runs = [
            {
                "goal_id": "G1",
                "run_id": "cycle-r1",
                "status": "done",
                "started_at": "2025-01-01T00:00:00",
                "ended_at": "2025-01-01T00:01:00",
            },
            {
                "goal_id": "G2",
                "run_id": "cycle-r2",
                "status": "failed",
                "started_at": "2025-01-01T00:01:00",
                "ended_at": "2025-01-01T00:02:00",
            },
        ]

    meta = {
        "session_id": sid,
        "created_at": "2025-01-01T00:00:00",
        "updated_at": "2025-01-01T00:02:00",
        "status": "DONE" if with_runs else "RUNNING",
        "current_goal_index": 0,
        "goals": [
            {
                "id": "G1",
                "goal": "Setup project",
                "workspace": ".",
                "sandbox": False,
                "use_llm": "none",
                "use_worker": "none",
                "max_steps": 5,
                "interval_sec": 1.0,
                "export_on_done": True,
                "stop_on_approval": True,
                "stop_on_blocked": True,
                "notes": "",
                "depends_on": [],
                "concurrency_group": "",
                "provider_planner": None,
                "provider_judge": None,
                "rollback": {"mode": "none", "require_approval": True},
            },
            {
                "id": "G2",
                "goal": "Build feature",
                "workspace": ".",
                "sandbox": False,
                "use_llm": "none",
                "use_worker": "none",
                "max_steps": 5,
                "interval_sec": 1.0,
                "export_on_done": True,
                "stop_on_approval": True,
                "stop_on_blocked": True,
                "notes": "",
                "depends_on": ["G1"],
                "concurrency_group": "",
                "provider_planner": None,
                "provider_judge": None,
                "rollback": {"mode": "none", "require_approval": True},
            },
        ],
        "runs": runs,
        "last_block_reason": "",
        "config": {},
        "max_concurrency": 2,
        "continue_on_fail": False,
    }
    (sdir / "session_meta.json").write_text(json.dumps(meta))
    return sid


class TestSessionDashboard:
    def test_generates_html(self, tmp_path: Path) -> None:
        sid = _make_session(tmp_path, with_runs=True)
        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"
        out = tmp_path / "out" / "dash.html"

        result = generate_session_dashboard(sid, sessions_dir, runs_dir, out)
        assert result == out
        assert result.exists()

        html = result.read_text()
        assert "Session Dashboard" in html
        assert sid in html
        assert "G1" in html
        assert "G2" in html

    def test_shows_goal_status(self, tmp_path: Path) -> None:
        sid = _make_session(tmp_path, with_runs=True)
        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"
        out = tmp_path / "dash.html"

        generate_session_dashboard(sid, sessions_dir, runs_dir, out)
        html = out.read_text()
        assert "done" in html
        assert "failed" in html

    def test_without_runs(self, tmp_path: Path) -> None:
        sid = _make_session(tmp_path, with_runs=False)
        sessions_dir = tmp_path / "sessions"
        runs_dir = tmp_path / "runs"
        out = tmp_path / "dash.html"

        result = generate_session_dashboard(sid, sessions_dir, runs_dir, out)
        assert result.exists()
        html = result.read_text()
        assert "pending" in html

    def test_with_cycle_meta(self, tmp_path: Path) -> None:
        """Dashboard should include run details from cycle_meta.json."""
        sid = _make_session(tmp_path, with_runs=True)
        runs_dir = tmp_path / "runs"
        rd = runs_dir / "cycle-r1"
        rd.mkdir(parents=True)
        (rd / "cycle_meta.json").write_text(
            json.dumps(
                {
                    "run_id": "cycle-r1",
                    "state": "DONE",
                    "iteration": 5,
                    "goal": "Setup project",
                }
            )
        )

        out = tmp_path / "dash.html"
        generate_session_dashboard(
            sid,
            tmp_path / "sessions",
            runs_dir,
            out,
        )
        html = out.read_text()
        assert "DONE" in html

    def test_session_not_found(self, tmp_path: Path) -> None:
        import pytest

        with pytest.raises(FileNotFoundError):
            generate_session_dashboard(
                "nonexistent",
                tmp_path / "sessions",
                tmp_path / "runs",
                tmp_path / "out.html",
            )


class TestRunDashboard:
    def test_generates_html(self, tmp_path: Path) -> None:
        runs_dir = tmp_path / "runs"
        run_id = "cycle-test"
        rd = runs_dir / run_id
        rd.mkdir(parents=True)
        (rd / "cycle_meta.json").write_text(
            json.dumps(
                {
                    "run_id": run_id,
                    "state": "DONE",
                    "iteration": 3,
                    "goal": "Test goal",
                    "workspace": "/tmp/test",
                }
            )
        )

        out = tmp_path / "run_dash.html"
        result = generate_run_dashboard(run_id, runs_dir, out)
        assert result == out
        assert result.exists()
        html = result.read_text()
        assert "Run Dashboard" in html
        assert "DONE" in html
        assert "Test goal" in html

    def test_with_evidence(self, tmp_path: Path) -> None:
        runs_dir = tmp_path / "runs"
        run_id = "cycle-ev"
        rd = runs_dir / run_id
        rd.mkdir(parents=True)
        (rd / "cycle_meta.json").write_text(
            json.dumps(
                {
                    "run_id": run_id,
                    "state": "DONE",
                    "iteration": 1,
                }
            )
        )
        ev_dir = rd / "evidence"
        ev_dir.mkdir()
        (ev_dir / "manifest.json").write_text(
            json.dumps(
                [
                    {"type": "test_output", "path": "tests/output.txt", "stage": "judge"},
                ]
            )
        )

        out = tmp_path / "dash.html"
        generate_run_dashboard(run_id, runs_dir, out)
        html = out.read_text()
        assert "test_output" in html
        assert "judge" in html

    def test_with_summary(self, tmp_path: Path) -> None:
        runs_dir = tmp_path / "runs"
        run_id = "cycle-sum"
        rd = runs_dir / run_id
        rd.mkdir(parents=True)
        (rd / "cycle_meta.json").write_text("{}")
        (rd / "summary.json").write_text(
            json.dumps(
                {
                    "total_cost": 0.42,
                    "files_changed": 5,
                }
            )
        )

        out = tmp_path / "dash.html"
        generate_run_dashboard(run_id, runs_dir, out)
        html = out.read_text()
        assert "total_cost" in html
        assert "0.42" in html

    def test_with_pr_pack(self, tmp_path: Path) -> None:
        runs_dir = tmp_path / "runs"
        run_id = "cycle-pr"
        rd = runs_dir / run_id
        rd.mkdir(parents=True)
        (rd / "cycle_meta.json").write_text("{}")
        (rd / "pr_pack.md").write_text("# PR Pack\n")

        out = tmp_path / "dash.html"
        generate_run_dashboard(run_id, runs_dir, out)
        html = out.read_text()
        assert "PR Pack: Yes" in html

    def test_run_not_found(self, tmp_path: Path) -> None:
        import pytest

        with pytest.raises(FileNotFoundError):
            generate_run_dashboard(
                "nonexistent",
                tmp_path / "runs",
                tmp_path / "out.html",
            )

    def test_empty_run_dir(self, tmp_path: Path) -> None:
        runs_dir = tmp_path / "runs"
        run_id = "cycle-empty"
        (runs_dir / run_id).mkdir(parents=True)

        out = tmp_path / "dash.html"
        result = generate_run_dashboard(run_id, runs_dir, out)
        assert result.exists()
        html = result.read_text()
        assert "Run Dashboard" in html

    def test_event_count(self, tmp_path: Path) -> None:
        runs_dir = tmp_path / "runs"
        run_id = "cycle-events"
        rd = runs_dir / run_id
        rd.mkdir(parents=True)
        (rd / "cycle_meta.json").write_text("{}")
        (rd / "run.jsonl").write_text('{"event":"a"}\n{"event":"b"}\n{"event":"c"}\n')

        out = tmp_path / "dash.html"
        generate_run_dashboard(run_id, runs_dir, out)
        html = out.read_text()
        assert "Events: 3" in html


class TestSessionDashboardBadCycleMeta:
    """Lines 58-59: bad JSON in cycle_meta.json is silently skipped."""

    def test_bad_cycle_meta_skipped(self, tmp_path: Path) -> None:
        sid = _make_session(tmp_path, with_runs=True)
        runs_dir = tmp_path / "runs"
        # Put corrupted cycle_meta.json in the run dir that IS listed in meta.runs
        bad_rd = runs_dir / "cycle-r1"
        bad_rd.mkdir(parents=True)
        (bad_rd / "cycle_meta.json").write_text("NOT VALID JSON {{{")
        out = tmp_path / "dash_bad.html"
        result = generate_session_dashboard(
            sid,
            tmp_path / "sessions",
            runs_dir,
            out,
        )
        assert result.exists()
        html = result.read_text()
        assert "Session Dashboard" in html


class TestStatusClass:
    """Line 74: _status_class 'blocked'/'BLOCKED' returns 'blocked'."""

    def test_blocked_status(self) -> None:
        from owlmind.session_dashboard import _status_class

        assert _status_class("blocked") == "blocked"
        assert _status_class("BLOCKED") == "blocked"

    def test_done_status(self) -> None:
        from owlmind.session_dashboard import _status_class

        assert _status_class("done") == "done"

    def test_failed_status(self) -> None:
        from owlmind.session_dashboard import _status_class

        assert _status_class("failed") == "failed"

    def test_unknown_returns_pending(self) -> None:
        from owlmind.session_dashboard import _status_class

        assert _status_class("running") == "pending"
