"""Tests for GitHub webhook endpoint."""
from __future__ import annotations

import hashlib
import hmac
import json

from fastapi import FastAPI
from starlette.testclient import TestClient

from owlmind.api.routes.github_webhook import make_github_webhook_router


def _make_app(queue_dir, secret=""):
    app = FastAPI()
    app.include_router(
        make_github_webhook_router(queue_dir=queue_dir, webhook_secret=secret)
    )
    return TestClient(app)


def _sign(secret: str, body: bytes) -> str:
    return "sha256=" + hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()


class TestGitHubWebhookEndpoint:
    """Tests for POST /api/v1/webhooks/github."""

    def test_ping_event_ignored(self, tmp_path):
        client = _make_app(tmp_path / "queue")
        body = json.dumps({"zen": "keep it simple"}).encode()
        resp = client.post(
            "/api/v1/webhooks/github",
            content=body,
            headers={"X-GitHub-Event": "ping", "Content-Type": "application/json"},
        )
        assert resp.status_code == 200
        assert resp.json()["ok"] is True

    def test_pr_opened_queues_review(self, tmp_path):
        client = _make_app(tmp_path / "queue")
        payload = {
            "action": "opened",
            "pull_request": {
                "number": 42,
                "title": "Add feature X",
                "html_url": "https://github.com/org/repo/pull/42",
                "user": {"login": "alice"},
                "base": {"ref": "main"},
                "head": {"ref": "feature-x"},
                "changed_files": 3,
                "additions": 50,
                "deletions": 10,
            },
            "repository": {"full_name": "org/repo"},
        }
        body = json.dumps(payload).encode()
        resp = client.post(
            "/api/v1/webhooks/github",
            content=body,
            headers={"X-GitHub-Event": "pull_request", "Content-Type": "application/json"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["action"] == "queued_review"
        assert "task_id" in data

    def test_pr_closed_action_ignored(self, tmp_path):
        client = _make_app(tmp_path / "queue")
        payload = {
            "action": "closed",
            "pull_request": {},
            "repository": {"full_name": "org/repo"},
        }
        body = json.dumps(payload).encode()
        resp = client.post(
            "/api/v1/webhooks/github",
            content=body,
            headers={"X-GitHub-Event": "pull_request", "Content-Type": "application/json"},
        )
        assert resp.status_code == 200
        assert resp.json()["action"] == "ignored"

    def test_check_run_failed_queues_fix(self, tmp_path):
        client = _make_app(tmp_path / "queue")
        payload = {
            "action": "completed",
            "check_run": {
                "name": "pytest",
                "conclusion": "failure",
                "html_url": "https://github.com/org/repo/actions/runs/1",
                "head_sha": "abc123def456",
            },
            "repository": {"full_name": "org/repo"},
        }
        body = json.dumps(payload).encode()
        resp = client.post(
            "/api/v1/webhooks/github",
            content=body,
            headers={"X-GitHub-Event": "check_run", "Content-Type": "application/json"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["action"] == "queued_ci_fix"

    def test_check_run_success_ignored(self, tmp_path):
        client = _make_app(tmp_path / "queue")
        payload = {
            "action": "completed",
            "check_run": {"name": "pytest", "conclusion": "success", "head_sha": "abc"},
            "repository": {"full_name": "org/repo"},
        }
        body = json.dumps(payload).encode()
        resp = client.post(
            "/api/v1/webhooks/github",
            content=body,
            headers={"X-GitHub-Event": "check_run", "Content-Type": "application/json"},
        )
        assert resp.status_code == 200
        assert resp.json()["action"] == "ignored"

    def test_signature_verification_valid(self, tmp_path):
        secret = "my-webhook-secret"
        client = _make_app(tmp_path / "queue", secret=secret)
        payload = json.dumps({"action": "ping"}).encode()
        sig = _sign(secret, payload)
        resp = client.post(
            "/api/v1/webhooks/github",
            content=payload,
            headers={
                "X-GitHub-Event": "ping",
                "X-Hub-Signature-256": sig,
                "Content-Type": "application/json",
            },
        )
        assert resp.status_code == 200

    def test_signature_verification_invalid(self, tmp_path):
        secret = "my-webhook-secret"
        client = _make_app(tmp_path / "queue", secret=secret)
        payload = json.dumps({"action": "ping"}).encode()
        resp = client.post(
            "/api/v1/webhooks/github",
            content=payload,
            headers={
                "X-GitHub-Event": "ping",
                "X-Hub-Signature-256": "sha256=badhash",
                "Content-Type": "application/json",
            },
        )
        assert resp.status_code == 403

    def test_missing_signature_when_secret_set(self, tmp_path):
        secret = "my-webhook-secret"
        client = _make_app(tmp_path / "queue", secret=secret)
        payload = json.dumps({"action": "ping"}).encode()
        resp = client.post(
            "/api/v1/webhooks/github",
            content=payload,
            headers={"X-GitHub-Event": "ping", "Content-Type": "application/json"},
        )
        assert resp.status_code == 400

    def test_pr_creates_queue_file(self, tmp_path):
        queue_dir = tmp_path / "queue"
        client = _make_app(queue_dir)
        payload = {
            "action": "opened",
            "pull_request": {
                "number": 1,
                "title": "Test PR",
                "html_url": "https://github.com/org/repo/pull/1",
                "user": {"login": "bob"},
                "base": {"ref": "main"},
                "head": {"ref": "feature"},
                "changed_files": 1,
                "additions": 5,
                "deletions": 2,
            },
            "repository": {"full_name": "org/repo"},
        }
        body = json.dumps(payload).encode()
        client.post(
            "/api/v1/webhooks/github",
            content=body,
            headers={"X-GitHub-Event": "pull_request", "Content-Type": "application/json"},
        )
        queue_file = queue_dir / "queue.jsonl"
        assert queue_file.exists()
        task = json.loads(queue_file.read_text().strip())
        assert "Review PR #1" in task["goal"]
        assert task["priority"] == 1

    def test_pr_synchronize_queues_review(self, tmp_path):
        client = _make_app(tmp_path / "queue")
        payload = {
            "action": "synchronize",
            "pull_request": {
                "number": 7,
                "title": "Update auth",
                "html_url": "https://github.com/org/repo/pull/7",
                "user": {"login": "carol"},
                "base": {"ref": "main"},
                "head": {"ref": "auth-update"},
                "changed_files": 2,
                "additions": 20,
                "deletions": 5,
            },
            "repository": {"full_name": "org/repo"},
        }
        body = json.dumps(payload).encode()
        resp = client.post(
            "/api/v1/webhooks/github",
            content=body,
            headers={"X-GitHub-Event": "pull_request", "Content-Type": "application/json"},
        )
        assert resp.status_code == 200
        assert resp.json()["action"] == "queued_review"

    def test_pr_reopened_queues_review(self, tmp_path):
        client = _make_app(tmp_path / "queue")
        payload = {
            "action": "reopened",
            "pull_request": {
                "number": 5,
                "title": "Reopened PR",
                "html_url": "https://github.com/org/repo/pull/5",
                "user": {"login": "dave"},
                "base": {"ref": "main"},
                "head": {"ref": "reopen-branch"},
                "changed_files": 0,
                "additions": 0,
                "deletions": 0,
            },
            "repository": {"full_name": "org/repo"},
        }
        body = json.dumps(payload).encode()
        resp = client.post(
            "/api/v1/webhooks/github",
            content=body,
            headers={"X-GitHub-Event": "pull_request", "Content-Type": "application/json"},
        )
        assert resp.status_code == 200
        assert resp.json()["action"] == "queued_review"

    def test_unknown_event_ignored(self, tmp_path):
        client = _make_app(tmp_path / "queue")
        body = json.dumps({"action": "created"}).encode()
        resp = client.post(
            "/api/v1/webhooks/github",
            content=body,
            headers={"X-GitHub-Event": "issues", "Content-Type": "application/json"},
        )
        assert resp.status_code == 200
        assert resp.json()["action"] == "ignored"

    def test_check_suite_failed_queues_fix(self, tmp_path):
        client = _make_app(tmp_path / "queue")
        payload = {
            "action": "completed",
            "check_suite": {
                "name": "CI Suite",
                "conclusion": "failure",
                "html_url": "https://github.com/org/repo/actions/runs/99",
                "head_sha": "deadbeef",
            },
            "repository": {"full_name": "org/repo"},
        }
        body = json.dumps(payload).encode()
        resp = client.post(
            "/api/v1/webhooks/github",
            content=body,
            headers={"X-GitHub-Event": "check_suite", "Content-Type": "application/json"},
        )
        assert resp.status_code == 200
        assert resp.json()["action"] == "queued_ci_fix"

    def test_check_run_timed_out_queues_fix(self, tmp_path):
        client = _make_app(tmp_path / "queue")
        payload = {
            "action": "completed",
            "check_run": {
                "name": "slow-test",
                "conclusion": "timed_out",
                "html_url": "https://github.com/org/repo/actions/runs/2",
                "head_sha": "cafe1234",
            },
            "repository": {"full_name": "org/repo"},
        }
        body = json.dumps(payload).encode()
        resp = client.post(
            "/api/v1/webhooks/github",
            content=body,
            headers={"X-GitHub-Event": "check_run", "Content-Type": "application/json"},
        )
        assert resp.status_code == 200
        assert resp.json()["action"] == "queued_ci_fix"

    def test_no_secret_signature_ignored(self, tmp_path):
        """When no secret configured, signature header is ignored."""
        client = _make_app(tmp_path / "queue", secret="")
        body = json.dumps({"zen": "test"}).encode()
        resp = client.post(
            "/api/v1/webhooks/github",
            content=body,
            headers={
                "X-GitHub-Event": "ping",
                "X-Hub-Signature-256": "sha256=anything",
                "Content-Type": "application/json",
            },
        )
        assert resp.status_code == 200

    def test_invalid_json_returns_400(self, tmp_path):
        client = _make_app(tmp_path / "queue")
        resp = client.post(
            "/api/v1/webhooks/github",
            content=b"not json",
            headers={"X-GitHub-Event": "ping", "Content-Type": "application/json"},
        )
        assert resp.status_code == 400

    def test_ci_fix_goal_contains_repo_name(self, tmp_path):
        """CI fix goal should mention the repo name."""
        queue_dir = tmp_path / "queue"
        client = _make_app(queue_dir)
        payload = {
            "action": "completed",
            "check_run": {
                "name": "unit-tests",
                "conclusion": "failure",
                "html_url": "https://github.com/myorg/myrepo/actions/runs/3",
                "head_sha": "abc123",
            },
            "repository": {"full_name": "myorg/myrepo"},
        }
        body = json.dumps(payload).encode()
        client.post(
            "/api/v1/webhooks/github",
            content=body,
            headers={"X-GitHub-Event": "check_run", "Content-Type": "application/json"},
        )
        queue_file = queue_dir / "queue.jsonl"
        task = json.loads(queue_file.read_text().strip())
        assert "myorg/myrepo" in task["goal"]
        assert task["priority"] == 2  # CI fix has higher priority than PR review
