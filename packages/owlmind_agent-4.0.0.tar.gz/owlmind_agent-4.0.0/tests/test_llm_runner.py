"""Tests for CycleLLMRunner — LLM-driven planner and judge operations."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest

from owlmind.agent.llm_runner import CycleLLMRunner
from owlmind.agent.meta_store import CycleMetaStore
from owlmind.agent.schemas import CycleRunMeta, CycleState
from owlmind.evidence import EvidenceStore


class FakeLLMDriver:
    """Fake LLM driver for tests — returns canned responses."""

    def __init__(
        self,
        planner_response: dict[str, Any] | None = None,
        judge_response: dict[str, Any] | None = None,
    ) -> None:
        self._planner_response = planner_response or {}
        self._judge_response = judge_response or {}
        self.plan_calls: list[dict[str, Any]] = []
        self.judge_calls: list[dict[str, Any]] = []

    @property
    def name(self) -> str:
        return "fake"

    def plan(
        self,
        planner_request: dict[str, Any],
        schema: dict[str, Any],
        **kwargs: Any,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        self.plan_calls.append(planner_request)
        meta = {
            "provider": "fake",
            "model": "fake-model",
            "response_id": "fake-resp-1",
            "latency_ms": 42,
            "usage": {"input_tokens": 10, "output_tokens": 20, "total_tokens": 30},
        }
        return self._planner_response, meta

    def judge(
        self,
        judge_request: dict[str, Any],
        schema: dict[str, Any],
        **kwargs: Any,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        self.judge_calls.append(judge_request)
        meta = {
            "provider": "fake",
            "model": "fake-model",
            "response_id": "fake-resp-2",
            "latency_ms": 55,
            "usage": {"input_tokens": 15, "output_tokens": 25, "total_tokens": 40},
        }
        return self._judge_response, meta


def _make_store(tmp_path: Path) -> CycleMetaStore:
    evidence = EvidenceStore(tmp_path / "runs")
    return CycleMetaStore(evidence)


def _make_runner(
    store: CycleMetaStore,
    driver: FakeLLMDriver | None = None,
) -> CycleLLMRunner:
    return CycleLLMRunner(store, llm_driver=driver)


def _create_run_at_state(
    tmp_path: Path,
    store: CycleMetaStore,
    state: CycleState,
    *,
    run_id: str = "cycle-test-001",
    goal: str = "Test goal",
) -> CycleRunMeta:
    """Create a run and set it to a specific state."""
    store.evidence.create_run(run_id)
    run_dir = store.run_dir(run_id)
    (run_dir / "outbox").mkdir(exist_ok=True)
    (run_dir / "inbox").mkdir(exist_ok=True)
    (run_dir / "artifacts").mkdir(exist_ok=True)
    meta = CycleRunMeta(
        run_id=run_id,
        goal=goal,
        state=state,
        workspace=str(tmp_path),
        planner_plan_summary=["Step 1"],
        worker_done_summary=["Done 1"],
        verify_results=["echo ok: PASS"],
    )
    store.save(meta)
    # Write a dummy outbox planner prompt so run_planner can read it
    (run_dir / "outbox" / "planner_prompt.md").write_text("# Test planner prompt")
    return meta


class TestRunPlanner:
    def test_writes_inbox_and_evidence(self, tmp_path: Path) -> None:
        store = _make_store(tmp_path)
        planner_resp = {
            "run_id": "cycle-test-001",
            "iteration": 1,
            "plan_summary": ["Step 1: Test thing"],
            "worker_instructions": "Do the test thing",
            "verify_commands": ["pytest -q"],
            "risk_notes": [],
        }
        driver = FakeLLMDriver(planner_response=planner_resp)
        runner = _make_runner(store, driver)

        _create_run_at_state(tmp_path, store, CycleState.STARTED_WAIT_PLANNER)

        runner.run_planner("cycle-test-001")

        # Inbox file written
        inbox_path = tmp_path / "runs" / "cycle-test-001" / "inbox" / "planner_response.json"
        assert inbox_path.exists()
        data = json.loads(inbox_path.read_text())
        assert data["worker_instructions"] == "Do the test thing"

        # Evidence artifacts written
        art_dir = tmp_path / "runs" / "cycle-test-001" / "artifacts"
        assert (art_dir / "openai_planner_request.json").exists()
        assert (art_dir / "openai_planner_response.json").exists()

        # LLM was called once
        assert len(driver.plan_calls) == 1

    def test_logs_chain_event(self, tmp_path: Path) -> None:
        store = _make_store(tmp_path)
        planner_resp = {
            "run_id": "cycle-evt-001",
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        driver = FakeLLMDriver(planner_response=planner_resp)
        runner = _make_runner(store, driver)
        _create_run_at_state(
            tmp_path,
            store,
            CycleState.STARTED_WAIT_PLANNER,
            run_id="cycle-evt-001",
        )

        runner.run_planner("cycle-evt-001")

        events = store.evidence.read_events("cycle-evt-001")
        llm_events = [e for e in events if e.get("event") == "LLM_PLANNER_CALLED"]
        assert len(llm_events) == 1
        assert llm_events[0]["provider"] == "fake"
        assert llm_events[0]["model"] == "fake-model"

    def test_rejects_wrong_state(self, tmp_path: Path) -> None:
        store = _make_store(tmp_path)
        driver = FakeLLMDriver()
        runner = _make_runner(store, driver)
        _create_run_at_state(
            tmp_path,
            store,
            CycleState.WAIT_WORKER,
            run_id="cycle-wrong-001",
        )

        with pytest.raises(RuntimeError, match="STARTED_WAIT_PLANNER"):
            runner.run_planner("cycle-wrong-001")

    def test_rejects_no_driver(self, tmp_path: Path) -> None:
        store = _make_store(tmp_path)
        runner = _make_runner(store, driver=None)
        _create_run_at_state(
            tmp_path,
            store,
            CycleState.STARTED_WAIT_PLANNER,
            run_id="cycle-nodrv-001",
        )

        with pytest.raises(RuntimeError, match="No LLM driver"):
            runner.run_planner("cycle-nodrv-001")


class TestRunJudge:
    def test_writes_inbox_and_evidence(self, tmp_path: Path) -> None:
        store = _make_store(tmp_path)
        judge_resp = {
            "run_id": "cycle-judge-001",
            "iteration": 1,
            "verdict": "APPROVED",
            "notes": ["All good"],
            "next_worker_instructions": "",
            "evidence_chain_verified": True,
        }
        driver = FakeLLMDriver(judge_response=judge_resp)
        runner = _make_runner(store, driver)
        _create_run_at_state(
            tmp_path,
            store,
            CycleState.WAIT_JUDGE,
            run_id="cycle-judge-001",
        )

        runner.run_judge("cycle-judge-001")

        # Inbox file written
        inbox_path = tmp_path / "runs" / "cycle-judge-001" / "inbox" / "judge_response.json"
        assert inbox_path.exists()
        data = json.loads(inbox_path.read_text())
        assert data["verdict"] == "APPROVED"

        # Evidence
        art_dir = tmp_path / "runs" / "cycle-judge-001" / "artifacts"
        assert (art_dir / "openai_judge_request.json").exists()
        assert (art_dir / "openai_judge_response.json").exists()

        assert len(driver.judge_calls) == 1

    def test_rejects_wrong_state(self, tmp_path: Path) -> None:
        store = _make_store(tmp_path)
        driver = FakeLLMDriver()
        runner = _make_runner(store, driver)
        _create_run_at_state(
            tmp_path,
            store,
            CycleState.STARTED_WAIT_PLANNER,
            run_id="cycle-jw-001",
        )

        with pytest.raises(RuntimeError, match="WAIT_JUDGE"):
            runner.run_judge("cycle-jw-001")

    def test_rejects_no_driver(self, tmp_path: Path) -> None:
        store = _make_store(tmp_path)
        runner = _make_runner(store, driver=None)
        _create_run_at_state(
            tmp_path,
            store,
            CycleState.WAIT_JUDGE,
            run_id="cycle-jnd-001",
        )

        with pytest.raises(RuntimeError, match="No LLM driver"):
            runner.run_judge("cycle-jnd-001")


class TestRunJudgeBudgetDenied:
    """Lines 212-222: budget_governor.check() returns allowed=False → approval created, returns early."""

    def test_budget_denied_creates_approval_and_returns_early(self, tmp_path: Path) -> None:
        from unittest.mock import MagicMock, patch

        store = _make_store(tmp_path)
        driver = FakeLLMDriver()

        # Build a mock budget decision with allowed=False
        mock_decision = MagicMock()
        mock_decision.allowed = False
        mock_decision.reason = "Monthly budget exceeded"
        mock_decision.to_dict.return_value = {"allowed": False, "reason": "Monthly budget exceeded"}

        mock_governor = MagicMock()
        mock_governor.check.return_value = mock_decision

        # Create runner with budget governor
        runner = CycleLLMRunner(store, llm_driver=driver, budget_governor=mock_governor)

        _create_run_at_state(
            tmp_path,
            store,
            CycleState.WAIT_JUDGE,
            run_id="cycle-budget-001",
        )

        with patch("owlmind.approval.create_approval") as mock_create_approval:
            result = runner.run_judge("cycle-budget-001")

        # Should have created an approval request
        mock_create_approval.assert_called_once()
        call_args = mock_create_approval.call_args
        assert "BUDGET_OVERRIDE" in call_args[0][2]

        # LLM driver should NOT have been called (returned early)
        assert len(driver.judge_calls) == 0

        # Should return meta
        assert result.run_id == "cycle-budget-001"


class TestRunPlannerForceProvider:
    """Line 120: force_provider branch sets plan_kwargs."""

    def test_force_provider_passed_to_driver(self, tmp_path: Path) -> None:
        store = _make_store(tmp_path)
        planner_resp = {
            "run_id": "cycle-fp-001",
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        driver = FakeLLMDriver(planner_response=planner_resp)
        runner = _make_runner(store, driver)
        _create_run_at_state(
            tmp_path,
            store,
            CycleState.STARTED_WAIT_PLANNER,
            run_id="cycle-fp-001",
        )

        # force_provider triggers line 120
        runner.run_planner("cycle-fp-001", force_provider="anthropic")

        assert len(driver.plan_calls) == 1


class TestRunJudgeForceProvider:
    """Line 255: force_provider branch sets judge_kwargs."""

    def test_force_provider_passed_to_driver(self, tmp_path: Path) -> None:
        store = _make_store(tmp_path)
        judge_resp = {
            "run_id": "cycle-jfp-001",
            "iteration": 1,
            "verdict": "APPROVED",
            "notes": [],
            "next_worker_instructions": "",
            "evidence_chain_verified": True,
        }
        driver = FakeLLMDriver(judge_response=judge_resp)
        runner = _make_runner(store, driver)
        _create_run_at_state(
            tmp_path,
            store,
            CycleState.WAIT_JUDGE,
            run_id="cycle-jfp-001",
        )

        # force_provider triggers line 255
        runner.run_judge("cycle-jfp-001", force_provider="anthropic")

        assert len(driver.judge_calls) == 1


class TestRecordLLMUsagePricing:
    """Lines 331-336: pricing fallback branches in _record_llm_usage."""

    def _make_planner_resp(self) -> dict[str, Any]:
        return {
            "run_id": "cycle-pr-001",
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }

    def test_pricing_without_price_for_provider(self, tmp_path: Path) -> None:
        """Lines 331-333: pricing exists but has no price_for_provider method."""
        from types import SimpleNamespace
        from unittest.mock import MagicMock

        store = _make_store(tmp_path)
        driver = FakeLLMDriver(planner_response=self._make_planner_resp())
        mock_ledger = MagicMock()
        # Pricing with simple attributes but no price_for_provider
        mock_governor = MagicMock()
        mock_governor.pricing = SimpleNamespace(
            openai_price_per_1k_input=0.001,
            openai_price_per_1k_output=0.002,
        )
        # Budget check must pass (allowed=True)
        mock_decision = MagicMock()
        mock_decision.allowed = True
        mock_decision.to_dict.return_value = {"allowed": True, "reason": ""}
        mock_governor.check.return_value = mock_decision

        runner = CycleLLMRunner(
            store,
            llm_driver=driver,
            budget_governor=mock_governor,
            ledger=mock_ledger,
        )
        _create_run_at_state(
            tmp_path,
            store,
            CycleState.STARTED_WAIT_PLANNER,
            run_id="cycle-pr-001",
        )

        runner.run_planner("cycle-pr-001")

        # Ledger.record was called once
        mock_ledger.record.assert_called_once()

    def test_no_pricing_uses_zero_rates(self, tmp_path: Path) -> None:
        """Lines 334-336: budget_governor=None → pricing=None → price_in/out = 0.0."""
        from unittest.mock import MagicMock

        store = _make_store(tmp_path)
        planner_resp = {
            "run_id": "cycle-np-001",
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        driver = FakeLLMDriver(planner_response=planner_resp)
        mock_ledger = MagicMock()

        # budget_governor=None → pricing=None → else branch
        runner = CycleLLMRunner(
            store,
            llm_driver=driver,
            budget_governor=None,
            ledger=mock_ledger,
        )
        _create_run_at_state(
            tmp_path,
            store,
            CycleState.STARTED_WAIT_PLANNER,
            run_id="cycle-np-001",
        )

        runner.run_planner("cycle-np-001")

        # Ledger.record was called once with estimated_usd=0.0
        mock_ledger.record.assert_called_once()
        entry = mock_ledger.record.call_args[0][0]
        assert entry.estimated_usd == 0.0
