"""Tests for file-based storage adapters."""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path

import pytest

from owlmind.storage import StorageBackend, create_storage
from owlmind.storage.file import (
    FileLedgerStorage,
    FileMemoryStorage,
    FileQueueStorage,
    FileRunStorage,
    FileSessionStorage,
)

# ===================================================================
# Factory
# ===================================================================


class TestCreateStorage:
    def test_file_backend(self, tmp_path: Path) -> None:
        sb = create_storage(
            runs_dir=tmp_path / "runs",
            ledger_dir=tmp_path / "ledger",
            queue_dir=tmp_path / "queue",
            sessions_dir=tmp_path / "sessions",
        )
        assert isinstance(sb, StorageBackend)
        assert isinstance(sb.runs, FileRunStorage)
        assert isinstance(sb.ledger, FileLedgerStorage)
        assert isinstance(sb.queue, FileQueueStorage)
        assert isinstance(sb.sessions, FileSessionStorage)
        assert sb.memory is None

    def test_file_backend_with_memory(self, tmp_path: Path) -> None:
        sb = create_storage(
            runs_dir=tmp_path / "runs",
            ledger_dir=tmp_path / "ledger",
            queue_dir=tmp_path / "queue",
            sessions_dir=tmp_path / "sessions",
            memory_db=tmp_path / "memory" / "memory.db",
        )
        assert isinstance(sb.memory, FileMemoryStorage)

    def test_unknown_backend_raises(self, tmp_path: Path) -> None:
        with pytest.raises(ValueError, match="Unknown storage backend"):
            create_storage(backend="redis")


# ===================================================================
# FileRunStorage
# ===================================================================


@pytest.mark.asyncio
class TestFileRunStorage:
    async def test_create_run(self, tmp_path: Path) -> None:
        store = FileRunStorage(tmp_path / "runs")
        await store.create_run("run-001")
        assert (tmp_path / "runs" / "run-001").is_dir()
        assert (tmp_path / "runs" / "run-001" / "artifacts").is_dir()

    async def test_append_and_read_events(self, tmp_path: Path) -> None:
        store = FileRunStorage(tmp_path / "runs")
        await store.create_run("run-002")

        h1 = await store.append_event("run-002", {"event": "START"})
        h2 = await store.append_event("run-002", {"event": "STOP"})

        assert isinstance(h1, str) and len(h1) == 64
        assert h1 != h2

        events = await store.read_events("run-002")
        assert len(events) == 2
        assert events[0]["event"] == "START"
        assert events[1]["event"] == "STOP"

    async def test_chain_tip(self, tmp_path: Path) -> None:
        store = FileRunStorage(tmp_path / "runs")
        await store.create_run("run-003")

        tip_hash, seq = await store.get_chain_tip("run-003")
        assert seq == 0

        await store.append_event("run-003", {"event": "A"})
        tip_hash, seq = await store.get_chain_tip("run-003")
        assert seq == 1
        assert len(tip_hash) == 64

    async def test_verify_chain(self, tmp_path: Path) -> None:
        store = FileRunStorage(tmp_path / "runs")
        await store.create_run("run-004")
        await store.append_event("run-004", {"event": "X"})
        await store.append_event("run-004", {"event": "Y"})

        result = await store.verify_chain("run-004")
        assert result.ok
        assert result.seq == 2

    async def test_meta_roundtrip(self, tmp_path: Path) -> None:
        store = FileRunStorage(tmp_path / "runs")
        await store.create_run("run-005")

        meta = {"goal": "test", "state": "RUNNING"}
        await store.write_meta("run-005", meta)
        loaded = await store.read_meta("run-005")
        assert loaded["goal"] == "test"

    async def test_summary_roundtrip(self, tmp_path: Path) -> None:
        store = FileRunStorage(tmp_path / "runs")
        await store.create_run("run-006")

        summary = {"verdict": "APPROVED", "score": 95}
        await store.write_summary("run-006", summary)
        loaded = await store.read_summary("run-006")
        assert loaded["verdict"] == "APPROVED"

    async def test_read_missing_returns_empty(self, tmp_path: Path) -> None:
        store = FileRunStorage(tmp_path / "runs")
        assert await store.read_meta("nonexistent") == {}
        assert await store.read_summary("nonexistent") == {}
        assert await store.read_events("nonexistent") == []

    async def test_list_runs(self, tmp_path: Path) -> None:
        store = FileRunStorage(tmp_path / "runs")
        await store.create_run("run-a")
        await store.append_event("run-a", {"event": "init"})
        await store.create_run("run-b")
        await store.append_event("run-b", {"event": "init"})

        runs = await store.list_runs()
        assert "run-a" in runs
        assert "run-b" in runs

    async def test_write_artifact(self, tmp_path: Path) -> None:
        store = FileRunStorage(tmp_path / "runs")
        await store.create_run("run-007")

        sha = await store.write_artifact("run-007", "diff.patch", "hello world")
        assert isinstance(sha, str) and len(sha) == 64
        assert (tmp_path / "runs" / "run-007" / "artifacts" / "diff.patch").exists()

    async def test_write_manifest(self, tmp_path: Path) -> None:
        store = FileRunStorage(tmp_path / "runs")
        await store.create_run("run-008")
        await store.write_artifact("run-008", "test.txt", "data")

        manifest = await store.write_manifest("run-008")
        assert manifest["artifact_count"] == 1
        assert manifest["artifacts"][0]["name"] == "test.txt"

    async def test_sync_property(self, tmp_path: Path) -> None:
        from owlmind.evidence import EvidenceStore

        store = FileRunStorage(tmp_path / "runs")
        assert isinstance(store.sync, EvidenceStore)
        assert store.base_dir == tmp_path / "runs"


# ===================================================================
# FileLedgerStorage
# ===================================================================


@pytest.mark.asyncio
class TestFileLedgerStorage:
    def _make_entry(self, run_id: str = "run-1") -> object:
        from owlmind.ledger import UsageEntry

        return UsageEntry(
            ts=datetime.now(tz=UTC).isoformat(),
            run_id=run_id,
            stage="planner",
            provider="openai",
            model="gpt-4o",
            input_tokens=100,
            output_tokens=50,
            total_tokens=150,
            estimated_usd=0.005,
            latency_ms=200,
            price_per_1k_input=0.0025,
            price_per_1k_output=0.01,
        )

    async def test_record_and_recent(self, tmp_path: Path) -> None:
        store = FileLedgerStorage(tmp_path / "ledger")
        await store.record(self._make_entry())
        await store.record(self._make_entry())

        recent = await store.recent(10)
        assert len(recent) == 2

    async def test_totals_for_day(self, tmp_path: Path) -> None:
        store = FileLedgerStorage(tmp_path / "ledger")
        await store.record(self._make_entry())

        totals = await store.totals_for_day()
        assert totals.llm_calls == 1
        assert totals.total_tokens == 150

    async def test_totals_for_run(self, tmp_path: Path) -> None:
        store = FileLedgerStorage(tmp_path / "ledger")
        await store.record(self._make_entry("run-x"))
        await store.record(self._make_entry("run-y"))

        totals = await store.totals_for_run("run-x")
        assert totals.llm_calls == 1

    async def test_entries_for_day(self, tmp_path: Path) -> None:
        store = FileLedgerStorage(tmp_path / "ledger")
        await store.record(self._make_entry())

        entries = await store.entries_for_day()
        assert len(entries) == 1

    async def test_calls_in_last_hour(self, tmp_path: Path) -> None:
        store = FileLedgerStorage(tmp_path / "ledger")
        await store.record(self._make_entry())

        count = await store.calls_in_last_hour()
        assert count == 1

    async def test_sync_property(self, tmp_path: Path) -> None:
        from owlmind.ledger import UsageLedger

        store = FileLedgerStorage(tmp_path / "ledger")
        assert isinstance(store.sync, UsageLedger)


# ===================================================================
# FileQueueStorage
# ===================================================================


@pytest.mark.asyncio
class TestFileQueueStorage:
    async def test_add_and_list(self, tmp_path: Path) -> None:
        store = FileQueueStorage(tmp_path / "queue")
        item = await store.add("build app", "/workspace")
        assert item.goal == "build app"
        assert item.id.startswith("task-")

        items = await store.list_items()
        assert len(items) == 1

    async def test_next_pending_priority(self, tmp_path: Path) -> None:
        store = FileQueueStorage(tmp_path / "queue")
        await store.add("low", "/ws", priority=1)
        await store.add("high", "/ws", priority=10)

        nxt = await store.next_pending()
        assert nxt is not None
        assert nxt.goal == "high"

    async def test_mark_lifecycle(self, tmp_path: Path) -> None:
        store = FileQueueStorage(tmp_path / "queue")
        item = await store.add("task", "/ws")

        await store.mark_running(item.id, "run-001")
        items = await store.list_items(status="RUNNING")
        assert len(items) == 1

        await store.mark_done(item.id)
        items = await store.list_items(status="DONE")
        assert len(items) == 1

    async def test_mark_failed(self, tmp_path: Path) -> None:
        store = FileQueueStorage(tmp_path / "queue")
        item = await store.add("fail-task", "/ws")

        await store.mark_failed(item.id, error="timeout")
        items = await store.list_items(status="FAILED")
        assert len(items) == 1
        assert items[0].error == "timeout"

    async def test_next_pending_empty(self, tmp_path: Path) -> None:
        store = FileQueueStorage(tmp_path / "queue")
        assert await store.next_pending() is None


# ===================================================================
# FileSessionStorage
# ===================================================================


@pytest.mark.asyncio
class TestFileSessionStorage:
    def _make_meta(self, session_id: str = "session-abc123") -> object:
        from owlmind.session import SessionMeta

        now = datetime.now(tz=UTC).isoformat()
        return SessionMeta(
            session_id=session_id,
            created_at=now,
            updated_at=now,
            status="RUNNING",
            goals=[],
            runs=[],
        )

    async def test_save_and_load(self, tmp_path: Path) -> None:
        store = FileSessionStorage(tmp_path / "sessions")
        meta = self._make_meta()
        await store.save_session(meta)

        loaded = await store.load_session("session-abc123")
        assert loaded.session_id == "session-abc123"
        assert loaded.status == "RUNNING"

    async def test_load_missing_raises(self, tmp_path: Path) -> None:
        store = FileSessionStorage(tmp_path / "sessions")
        with pytest.raises(FileNotFoundError):
            await store.load_session("nonexistent")

    async def test_append_and_read_events(self, tmp_path: Path) -> None:
        store = FileSessionStorage(tmp_path / "sessions")
        meta = self._make_meta()
        await store.save_session(meta)

        await store.append_event("session-abc123", {"event": "GOAL_STARTED"})
        await store.append_event("session-abc123", {"event": "GOAL_DONE"})

        events = await store.read_events("session-abc123")
        assert len(events) == 2

    async def test_list_sessions(self, tmp_path: Path) -> None:
        store = FileSessionStorage(tmp_path / "sessions")
        await store.save_session(self._make_meta("session-001"))
        await store.save_session(self._make_meta("session-002"))

        sessions = await store.list_sessions()
        assert len(sessions) == 2

    async def test_lock_acquire_release(self, tmp_path: Path) -> None:
        store = FileSessionStorage(tmp_path / "sessions")
        meta = self._make_meta()
        await store.save_session(meta)

        acquired = await store.acquire_lock("session-abc123")
        assert acquired

        await store.release_lock("session-abc123")

    async def test_lock_double_acquire(self, tmp_path: Path) -> None:
        store = FileSessionStorage(tmp_path / "sessions")
        meta = self._make_meta()
        await store.save_session(meta)

        assert await store.acquire_lock("session-abc123")
        # Second acquire from a different storage instance should fail
        store2 = FileSessionStorage(tmp_path / "sessions")
        acquired2 = await store2.acquire_lock("session-abc123")
        assert not acquired2

        await store.release_lock("session-abc123")


# ===================================================================
# FileMemoryStorage
# ===================================================================


@pytest.mark.asyncio
class TestFileMemoryStorage:
    async def test_ingest_and_query(self, tmp_path: Path) -> None:
        store = FileMemoryStorage(tmp_path / "memory.db")
        # TF-IDF needs 2+ docs so IDF > 0 (log(n/df) where n>1)
        doc_id = await store.ingest(
            "doc",
            "search.py",
            "python sorting algorithm binary search implementation",
        )
        await store.ingest(
            "doc",
            "unrelated.py",
            "javascript react component rendering with hooks and state",
        )
        assert doc_id.startswith("doc-")

        results = await store.query("python sorting algorithm", top_k=3)
        assert len(results) >= 1
        assert results[0]["source"] == "search.py"

        await store.close()

    async def test_signals(self, tmp_path: Path) -> None:
        store = FileMemoryStorage(tmp_path / "memory.db")
        sid = await store.add_signal("lesson", "Always test edge cases", run_id="r1")
        assert sid > 0

        signals = await store.get_signals("lesson")
        assert len(signals) == 1
        assert signals[0].summary == "Always test edge cases"

        await store.close()

    async def test_stats(self, tmp_path: Path) -> None:
        store = FileMemoryStorage(tmp_path / "memory.db")
        await store.ingest("doc", "a.py", "content A")
        await store.add_signal("error", "Something failed")

        st = await store.stats()
        assert st["documents"] == 1
        assert st["signals"] == 1

        await store.close()

    async def test_build_memory_context(self, tmp_path: Path) -> None:
        store = FileMemoryStorage(tmp_path / "memory.db")
        await store.ingest("doc", "api.py", "REST API endpoint for users")
        await store.add_signal("lesson", "Use pagination for large datasets")

        ctx = await store.build_memory_context("API endpoint", top_k=3)
        assert "Relevant Memory" in ctx or "Signals" in ctx

        await store.close()

    async def test_purge(self, tmp_path: Path) -> None:
        store = FileMemoryStorage(tmp_path / "memory.db")
        await store.ingest("doc", "old.py", "old content")

        count = await store.purge()
        assert count >= 1

        st = await store.stats()
        assert st["documents"] == 0

        await store.close()

    async def test_get_chunks(self, tmp_path: Path) -> None:
        store = FileMemoryStorage(tmp_path / "memory.db")
        doc_id = await store.ingest("doc", "big.py", "A" * 2000)

        chunks = await store.get_chunks(doc_id)
        assert len(chunks) >= 1

        await store.close()

    async def test_sync_property(self, tmp_path: Path) -> None:
        from owlmind.memory.store import MemoryStore

        store = FileMemoryStorage(tmp_path / "memory.db")
        assert isinstance(store.sync, MemoryStore)
        await store.close()


# ===================================================================
# Sync bridge
# ===================================================================


class TestRunSync:
    def test_run_sync_basic(self, tmp_path: Path) -> None:
        from owlmind.storage.sync import run_sync

        store = FileRunStorage(tmp_path / "runs")
        run_sync(store.create_run("run-sync-001"))

        meta = run_sync(store.read_meta("run-sync-001"))
        assert meta == {}

    def test_run_sync_with_return(self, tmp_path: Path) -> None:
        from owlmind.storage.sync import run_sync

        store = FileRunStorage(tmp_path / "runs")
        run_sync(store.create_run("run-sync-002"))
        h = run_sync(store.append_event("run-sync-002", {"event": "test"}))
        assert isinstance(h, str) and len(h) == 64
