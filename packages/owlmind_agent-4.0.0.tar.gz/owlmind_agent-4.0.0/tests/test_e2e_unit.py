"""Unit tests for E2E runner — no network calls."""

from __future__ import annotations

from pathlib import Path
from typing import Any
from unittest.mock import patch

from owlmind.e2e import (
    EXIT_BLOCKED,
    EXIT_FAILED,
    EXIT_OK,
    EXIT_PREFLIGHT_FAIL,
    E2EConfig,
    E2EResult,
    _find_approval_token,
    _write_e2e_report,
    run_e2e,
)


def _make_policies(tmp_path: Path) -> Path:
    """Create minimal policies directory."""
    policies_dir = tmp_path / "policies"
    policies_dir.mkdir(exist_ok=True)
    (policies_dir / "allowlist.yaml").write_text('allowed_commands:\n  - "^echo "\n  - "^pytest"\n')
    (policies_dir / "policy.yaml").write_text('forbidden_patterns:\n  - "rm -rf"\n')
    return policies_dir


class TestE2EConfigDefaults:
    def test_defaults(self) -> None:
        cfg = E2EConfig()
        assert cfg.use_llm == "both"
        assert cfg.use_worker == "none"
        assert cfg.sandbox is True
        assert cfg.max_steps == 200
        assert cfg.stop_on_approval is True
        assert cfg.export_on_done is True


class TestE2EResultDefaults:
    def test_defaults(self) -> None:
        r = E2EResult()
        assert r.exit_code == EXIT_FAILED
        assert r.preflight_ok is False
        assert r.next_commands == []


class TestFindApprovalToken:
    def test_finds_token_in_events(self) -> None:
        events = [
            {"event": "next_called"},
            {"event": "APPROVAL_CREATED", "token": "abc123"},
        ]
        assert _find_approval_token(events) == "abc123"

    def test_returns_empty_when_no_approval(self) -> None:
        events = [{"event": "next_called"}]
        assert _find_approval_token(events) == ""

    def test_returns_latest_token(self) -> None:
        events = [
            {"event": "APPROVAL_CREATED", "token": "old"},
            {"event": "APPROVAL_CREATED", "token": "new"},
        ]
        assert _find_approval_token(events) == "new"


class TestE2EPreflightFail:
    def test_fails_on_missing_deps(self, tmp_path: Path) -> None:
        """E2E should return PREFLIGHT_FAIL when required deps/keys missing."""
        import importlib

        original = importlib.import_module

        def fake_import(name: str) -> Any:
            if name == "openai":
                raise ImportError("nope")
            return original(name)

        import os

        env = {k: v for k, v in os.environ.items() if k != "OPENAI_API_KEY"}

        policies_dir = _make_policies(tmp_path)

        with (
            patch("importlib.import_module", side_effect=fake_import),
            patch.dict(os.environ, env, clear=True),
        ):
            config = E2EConfig(
                goal="test",
                workspace=str(tmp_path),
                sandbox=False,
                use_llm="both",
                policies_dir=policies_dir,
                runs_dir=tmp_path / "runs",
                ledger_dir=tmp_path / "ledger",
            )
            # Force providers via preflight override
            with patch("owlmind.preflight._needed_providers", return_value=["openai"]):
                result = run_e2e(config)

        assert result.exit_code == EXIT_PREFLIGHT_FAIL
        assert result.preflight_ok is False
        assert len(result.next_commands) > 0


class TestE2ENoLLM:
    def test_blocks_on_planner_wait(self, tmp_path: Path) -> None:
        """E2E with use_llm=none should BLOCK at planner wait."""
        policies_dir = _make_policies(tmp_path)

        config = E2EConfig(
            goal="E2E no-LLM test",
            workspace=str(tmp_path),
            sandbox=False,
            use_llm="none",
            use_worker="none",
            max_steps=5,
            interval_sec=0.01,
            policies_dir=policies_dir,
            runs_dir=tmp_path / "runs",
            ledger_dir=tmp_path / "ledger",
        )
        result = run_e2e(config)

        assert result.exit_code == EXIT_BLOCKED
        assert result.run_id.startswith("cycle-")
        assert result.final_state == "STARTED_WAIT_PLANNER"
        assert result.preflight_ok is True
        # Should have resume command
        assert any("--run-id" in cmd for cmd in result.next_commands)


class TestE2EApprovalBlock:
    def test_blocks_on_approval(self, tmp_path: Path) -> None:
        """E2E should BLOCK when approval is needed."""
        from owlmind.agent.cycle import CycleManager
        from owlmind.approval import create_approval
        from owlmind.budget import BudgetGovernor
        from owlmind.config import BudgetConfig, PricingConfig
        from owlmind.evidence import EvidenceStore
        from owlmind.ledger import UsageLedger
        from owlmind.policy import PolicyEngine

        policies_dir = _make_policies(tmp_path)
        policy = PolicyEngine.from_directory(policies_dir)
        evidence = EvidenceStore(tmp_path / "runs")
        ledger = UsageLedger(tmp_path / "ledger")
        governor = BudgetGovernor(BudgetConfig(), PricingConfig(), ledger)

        mgr = CycleManager(
            evidence=evidence,
            policy=policy,
            policies_dir=policies_dir,
            budget_governor=governor,
            ledger=ledger,
        )

        # Start + force approval
        meta = mgr.start(goal="Approval test", workspace=str(tmp_path))
        create_approval(mgr.meta_store, meta.run_id, "Test approval")

        config = E2EConfig(
            goal="",
            workspace=str(tmp_path),
            sandbox=False,
            use_llm="none",
            use_worker="none",
            max_steps=5,
            interval_sec=0.01,
            run_id=meta.run_id,
            policies_dir=policies_dir,
            runs_dir=tmp_path / "runs",
            ledger_dir=tmp_path / "ledger",
        )
        result = run_e2e(config)

        assert result.exit_code == EXIT_BLOCKED
        assert result.final_state == "WAIT_APPROVAL"
        assert any("approve" in cmd for cmd in result.next_commands)


class TestE2EReport:
    def test_report_written(self, tmp_path: Path) -> None:
        """E2E should write e2e_report.md."""
        policies_dir = _make_policies(tmp_path)

        config = E2EConfig(
            goal="Report test",
            workspace=str(tmp_path),
            sandbox=False,
            use_llm="none",
            use_worker="none",
            max_steps=3,
            interval_sec=0.01,
            policies_dir=policies_dir,
            runs_dir=tmp_path / "runs",
            ledger_dir=tmp_path / "ledger",
        )
        result = run_e2e(config)

        assert result.report_path != ""
        report_path = Path(result.report_path)
        assert report_path.exists()
        content = report_path.read_text()
        assert "E2E Report" in content
        assert "Preflight" in content

    def test_preflight_artifact_stored(self, tmp_path: Path) -> None:
        """Preflight report JSON should be stored as artifact."""
        policies_dir = _make_policies(tmp_path)

        config = E2EConfig(
            goal="Artifact test",
            workspace=str(tmp_path),
            sandbox=False,
            use_llm="none",
            use_worker="none",
            max_steps=3,
            interval_sec=0.01,
            policies_dir=policies_dir,
            runs_dir=tmp_path / "runs",
            ledger_dir=tmp_path / "ledger",
        )
        result = run_e2e(config)

        assert "preflight_report" in result.artifacts
        pf_path = Path(result.artifacts["preflight_report"])
        assert pf_path.exists()


class TestE2EEventCallback:
    def test_callback_fires(self, tmp_path: Path) -> None:
        events_log: list[tuple[str, dict[str, Any]]] = []

        def on_event(name: str, data: dict[str, Any]) -> None:
            events_log.append((name, data))

        policies_dir = _make_policies(tmp_path)

        config = E2EConfig(
            goal="Callback test",
            workspace=str(tmp_path),
            sandbox=False,
            use_llm="none",
            use_worker="none",
            max_steps=3,
            interval_sec=0.01,
            policies_dir=policies_dir,
            runs_dir=tmp_path / "runs",
            ledger_dir=tmp_path / "ledger",
            on_event=on_event,
        )
        run_e2e(config)

        event_names = [e[0] for e in events_log]
        assert "preflight_done" in event_names


# ===========================================================================
# TestE2EProviderDedup — lines 92-96
# run_preflight / autopilot_run are local imports inside run_e2e, so patch
# at their source module paths.
# ===========================================================================


def _make_passing_pf_report() -> Any:
    from owlmind.preflight import PreflightCheck, PreflightReport

    report = PreflightReport(ok=True)
    report.checks.append(PreflightCheck(name="package_structure", ok=True, details="ok"))
    return report


def _make_ap_result(final_state: str, run_id: str = "cycle-test") -> Any:
    return type(
        "AR",
        (),
        {
            "run_id": run_id,
            "final_state": final_state,
            "events": [],
            "export_path": "",
        },
    )()


class TestE2EProviderDedup:
    def test_same_provider_deduplicated(self, tmp_path: Path) -> None:
        """Same planner+judge provider appears only once in preflight providers (lines 92-96)."""
        captured: list[Any] = []

        def capture_pf(pf_config: Any) -> Any:
            captured.append(pf_config.providers)
            return _make_passing_pf_report()

        with (
            patch("owlmind.preflight.run_preflight", capture_pf),
            patch("owlmind.autopilot.run", return_value=_make_ap_result("STARTED_WAIT_PLANNER")),
        ):
            config = E2EConfig(
                goal="dedup",
                workspace=str(tmp_path),
                sandbox=False,
                use_llm="both",
                provider_planner="openai",
                provider_judge="openai",
                policies_dir=tmp_path / "policies",
                runs_dir=tmp_path / "runs",
                ledger_dir=tmp_path / "ledger",
            )
            run_e2e(config)

        assert captured, "preflight must be called"
        providers = captured[0]
        assert providers is not None
        assert providers.count("openai") == 1

    def test_different_providers_both_present(self, tmp_path: Path) -> None:
        """Different planner+judge providers both end up in the providers list (lines 92-96)."""
        captured: list[Any] = []

        def capture_pf(pf_config: Any) -> Any:
            captured.append(pf_config.providers)
            return _make_passing_pf_report()

        with (
            patch("owlmind.preflight.run_preflight", capture_pf),
            patch("owlmind.autopilot.run", return_value=_make_ap_result("STARTED_WAIT_PLANNER")),
        ):
            config = E2EConfig(
                goal="two providers",
                workspace=str(tmp_path),
                sandbox=False,
                use_llm="both",
                provider_planner="openai",
                provider_judge="anthropic",
                policies_dir=tmp_path / "policies",
                runs_dir=tmp_path / "runs",
                ledger_dir=tmp_path / "ledger",
            )
            run_e2e(config)

        providers = captured[0]
        assert providers is not None
        assert "openai" in providers
        assert "anthropic" in providers


# ===========================================================================
# TestE2EPreflightFailExtras — lines 116-122
# ===========================================================================


class TestE2EPreflightFailExtras:
    def test_missing_env_adds_export_commands(self, tmp_path: Path) -> None:
        """Preflight fail with missing_env appends 'export VAR=...' commands (line 120)."""
        from owlmind.preflight import PreflightCheck, PreflightReport

        pf_report = PreflightReport(ok=False)
        pf_report.checks.append(
            PreflightCheck(name="env_openai", ok=False, details="OPENAI_API_KEY not set")
        )
        pf_report.missing_env = ["OPENAI_API_KEY"]
        pf_report.missing_binaries = []
        pf_report.recommended_installs = []

        with patch("owlmind.preflight.run_preflight", return_value=pf_report):
            config = E2EConfig(
                goal="env test",
                workspace=str(tmp_path),
                sandbox=False,
                use_llm="both",
                provider_planner="openai",
                policies_dir=tmp_path / "policies",
                runs_dir=tmp_path / "runs",
                ledger_dir=tmp_path / "ledger",
            )
            result = run_e2e(config)

        assert result.exit_code == EXIT_PREFLIGHT_FAIL
        export_cmds = [c for c in result.next_commands if "OPENAI_API_KEY" in c]
        assert len(export_cmds) == 1

    def test_missing_binaries_adds_install_hint(self, tmp_path: Path) -> None:
        """Preflight fail with missing_binaries appends an install hint (lines 121-122)."""
        from owlmind.preflight import PreflightCheck, PreflightReport

        pf_report = PreflightReport(ok=False)
        pf_report.checks.append(
            PreflightCheck(name="binary_claude", ok=False, details="claude not found")
        )
        pf_report.missing_env = []
        pf_report.missing_binaries = ["claude"]
        pf_report.recommended_installs = []

        with patch("owlmind.preflight.run_preflight", return_value=pf_report):
            config = E2EConfig(
                goal="binary test",
                workspace=str(tmp_path),
                sandbox=False,
                use_llm="none",
                policies_dir=tmp_path / "policies",
                runs_dir=tmp_path / "runs",
                ledger_dir=tmp_path / "ledger",
            )
            result = run_e2e(config)

        assert result.exit_code == EXIT_PREFLIGHT_FAIL
        assert any("claude" in c for c in result.next_commands)


# ===========================================================================
# TestE2EDoneAndFailed — lines 175-178, 221-223
# ===========================================================================


class TestE2EDoneAndFailed:
    def test_exit_ok_when_done_with_export_artifact(self, tmp_path: Path) -> None:
        """EXIT_OK when final_state==DONE; export_path added to artifacts (lines 175-178)."""
        ap_result = _make_ap_result("DONE", run_id="cycle-done")
        ap_result.export_path = str(tmp_path / "export.zip")

        with (
            patch("owlmind.preflight.run_preflight", return_value=_make_passing_pf_report()),
            patch("owlmind.autopilot.run", return_value=ap_result),
            patch("owlmind.evidence.EvidenceStore"),
        ):
            config = E2EConfig(
                goal="done",
                workspace=str(tmp_path),
                sandbox=False,
                use_llm="none",
                policies_dir=tmp_path / "policies",
                runs_dir=tmp_path / "runs",
                ledger_dir=tmp_path / "ledger",
            )
            result = run_e2e(config)

        assert result.exit_code == EXIT_OK
        assert result.final_state == "DONE"
        assert "export" in result.artifacts

    def test_exit_failed_on_unknown_final_state(self, tmp_path: Path) -> None:
        """EXIT_FAILED for unknown/FAILED final states (lines 221-223)."""
        with (
            patch("owlmind.preflight.run_preflight", return_value=_make_passing_pf_report()),
            patch("owlmind.autopilot.run", return_value=_make_ap_result("FAILED", "cycle-fail")),
            patch("owlmind.evidence.EvidenceStore"),
        ):
            config = E2EConfig(
                goal="fail",
                workspace=str(tmp_path),
                sandbox=False,
                use_llm="none",
                policies_dir=tmp_path / "policies",
                runs_dir=tmp_path / "runs",
                ledger_dir=tmp_path / "ledger",
            )
            result = run_e2e(config)

        assert result.exit_code == EXIT_FAILED
        assert "Failed" in result.blocked_reason


# ===========================================================================
# TestE2EWriteReport — lines 292-293
# ===========================================================================


class TestE2EEvidenceSavingFailure:
    def test_evidence_exception_is_swallowed(self, tmp_path: Path) -> None:
        """When EvidenceStore.append_event raises, the except branch is hit (lines 170-171)."""
        from unittest.mock import MagicMock

        ap_result = _make_ap_result("STARTED_WAIT_PLANNER", run_id="cycle-ev")

        bad_evidence = MagicMock()
        bad_evidence.append_event.side_effect = OSError("disk full")

        with (
            patch("owlmind.preflight.run_preflight", return_value=_make_passing_pf_report()),
            patch("owlmind.autopilot.run", return_value=ap_result),
            patch("owlmind.evidence.EvidenceStore", return_value=bad_evidence),
        ):
            config = E2EConfig(
                goal="evidence fail",
                workspace=str(tmp_path),
                sandbox=False,
                use_llm="none",
                policies_dir=tmp_path / "policies",
                runs_dir=tmp_path / "runs",
                ledger_dir=tmp_path / "ledger",
            )
            result = run_e2e(config)

        # Run completes normally despite evidence failure
        assert result.exit_code == EXIT_BLOCKED
        assert "preflight_report" not in result.artifacts


class TestE2EWriteReport:
    def test_returns_empty_string_when_run_dir_unwritable(self) -> None:
        """_write_e2e_report returns '' when the run directory cannot be created (lines 292-293)."""
        from owlmind.preflight import PreflightReport

        result = E2EResult(run_id="run-bad", final_state="DONE", exit_code=EXIT_OK)
        config = E2EConfig(runs_dir=Path("/nonexistent/path/that/cannot/be/created"))
        pf_report = PreflightReport(ok=True)

        path = _write_e2e_report(config, result, pf_report)
        assert path == ""

    def test_includes_blocked_reason_in_report(self, tmp_path: Path) -> None:
        """_write_e2e_report includes blocked_reason when set."""
        from owlmind.preflight import PreflightReport

        result = E2EResult(
            run_id="run-blocked",
            final_state="WAIT_APPROVAL",
            exit_code=EXIT_BLOCKED,
            blocked_reason="Approval required",
        )
        config = E2EConfig(runs_dir=tmp_path / "runs")
        pf_report = PreflightReport(ok=True)

        path = _write_e2e_report(config, result, pf_report)
        assert path != ""
        assert "Approval required" in Path(path).read_text()

    def test_includes_artifacts_section(self, tmp_path: Path) -> None:
        """_write_e2e_report includes artifacts section when artifacts are present."""
        from owlmind.preflight import PreflightReport

        result = E2EResult(
            run_id="run-art",
            final_state="DONE",
            exit_code=EXIT_OK,
            artifacts={"export": "/tmp/export.zip"},
        )
        config = E2EConfig(runs_dir=tmp_path / "runs")
        pf_report = PreflightReport(ok=True)

        path = _write_e2e_report(config, result, pf_report)
        content = Path(path).read_text()
        assert "Artifacts" in content
        assert "export" in content
