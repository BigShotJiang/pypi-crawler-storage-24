"""Tests for FS67 — CLI diag report command."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

from typer.testing import CliRunner

from owlmind.cli import app

runner = CliRunner()


class TestDiagReport:
    def test_diag_report_ok(self, tmp_path: Path) -> None:
        """diag report → exit 0, 'Report saved to' in output."""
        report_path = str(tmp_path / "report.zip")

        with patch("owlmind.diag.build_diag_report", return_value=report_path) as mock_build:
            result = runner.invoke(app, ["diag", "report", "--workspace", str(tmp_path)])

        assert result.exit_code == 0, result.output
        mock_build.assert_called_once()
        assert "Report saved to" in result.output

    def test_diag_report_with_output_flag(self, tmp_path: Path) -> None:
        """diag report --out passes the path to build_diag_report as out_zip."""
        out_path = tmp_path / "custom_report.zip"
        report_path = str(out_path)

        with patch("owlmind.diag.build_diag_report", return_value=report_path) as mock_build:
            runner.invoke(
                app,
                ["diag", "report", "--workspace", str(tmp_path), "--out", str(out_path)],
            )

        mock_build.assert_called_once()
        call_kwargs = mock_build.call_args
        assert call_kwargs is not None
        # out_zip is passed as keyword argument
        assert call_kwargs.kwargs.get("out_zip") == out_path

    def test_diag_report_default_workspace(self) -> None:
        """diag report without --workspace uses Path('.') as default."""
        with patch("owlmind.diag.build_diag_report", return_value="/tmp/report.zip") as mock_build:
            result = runner.invoke(app, ["diag", "report"])

        assert result.exit_code == 0
        call_args = mock_build.call_args
        assert call_args is not None
        workspace_arg = call_args.args[0]
        assert str(workspace_arg) == "."
