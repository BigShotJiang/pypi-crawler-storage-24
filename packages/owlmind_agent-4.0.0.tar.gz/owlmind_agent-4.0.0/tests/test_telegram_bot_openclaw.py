"""Tests for OpenClaw-inspired telegram_bot commands: model, think, memory, verbose, heartbeat.

This module reuses the fake telegram/telegram.ext stubs from
test_telegram_bot_handlers.py by importing the already-patched module
reference (_tb) after the module-level monkeypatching has run in that
file.  Because pytest collects both files in the same process the stubs
are already present in sys.modules before this file is imported.

If the files happen to be collected in isolation we install the same
fakes here via the module-level setup below.
"""

from __future__ import annotations

import importlib
import json
import sys
from types import ModuleType
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# Ensure fake telegram modules are installed (idempotent)
# ---------------------------------------------------------------------------

_registered_handlers: dict[str, object] = {}


def _fake_command_handler(name: str, func: object) -> tuple[str, object]:
    """Capture handler registrations."""
    _registered_handlers[name] = func
    return (name, func)


# Module-level mock telegram objects so _build_bot can always reference them,
# even after other test modules' teardown_module restores the real PTB modules.
_mock_app_class: MagicMock = MagicMock(name="AppClass")
_mock_filters: MagicMock = MagicMock(name="filters")
_mock_message_handler: MagicMock = MagicMock(name="MessageHandler")
_mock_context_types: MagicMock = MagicMock(name="ContextTypes")


def _install_telegram_mocks() -> None:
    """Install complete telegram stubs so _PTB_AVAILABLE becomes True on reload.

    telegram_bot.py imports Update, Application, CommandHandler, ContextTypes,
    MessageHandler, and filters at the top level.  All six must be present in
    the fake modules before importlib.reload() is called, otherwise the
    try/except around those imports keeps _PTB_AVAILABLE = False and
    create_operator_bot() returns None without registering any handlers.
    """
    global _mock_app_class, _mock_filters, _mock_message_handler, _mock_context_types
    fake_telegram = ModuleType("telegram")
    fake_telegram.Update = MagicMock(name="Update")  # type: ignore[attr-defined]
    fake_telegram.InlineKeyboardButton = MagicMock(name="InlineKeyboardButton")  # type: ignore[attr-defined]
    fake_telegram.InlineKeyboardMarkup = MagicMock(name="InlineKeyboardMarkup")  # type: ignore[attr-defined]
    fake_telegram.BotCommand = MagicMock(name="BotCommand")  # type: ignore[attr-defined]

    fake_filters = MagicMock(name="filters")
    fake_filters.Mention = MagicMock()
    fake_filters.ChatType = MagicMock()
    fake_filters.ChatType.GROUPS = MagicMock()
    _mock_filters = fake_filters

    fake_ext = ModuleType("telegram.ext")
    mock_built_app = MagicMock()
    mock_builder = MagicMock()
    mock_builder.token.return_value = mock_builder
    mock_builder.build.return_value = mock_built_app
    app_class = MagicMock(name="AppClass")
    app_class.builder.return_value = mock_builder
    _mock_app_class = app_class
    mock_ctx = MagicMock(name="ContextTypes")
    mock_ctx.DEFAULT_TYPE = type
    _mock_context_types = mock_ctx
    mock_mh = MagicMock(name="MessageHandler")
    _mock_message_handler = mock_mh
    fake_ext.Application = app_class  # type: ignore[attr-defined]
    fake_ext.CommandHandler = _fake_command_handler  # type: ignore[attr-defined]
    fake_ext.ContextTypes = mock_ctx  # type: ignore[attr-defined]
    fake_ext.CallbackQueryHandler = MagicMock(name="CallbackQueryHandler")  # type: ignore[attr-defined]
    fake_ext.MessageHandler = mock_mh  # type: ignore[attr-defined]
    fake_ext.filters = fake_filters  # type: ignore[attr-defined]

    sys.modules["telegram"] = fake_telegram  # type: ignore[assignment]
    sys.modules["telegram.ext"] = fake_ext  # type: ignore[assignment]


_install_telegram_mocks()

import owlmind.telegram_bot as _tb  # noqa: E402

# Force reload so the module-level try/except picks up our complete fakes and
# sets _PTB_AVAILABLE = True.  The CommandHandler stub must be in place before
# reload so that handler registrations are captured in _registered_handlers.
importlib.reload(_tb)

# ---------------------------------------------------------------------------
# Helper factories (mirror test_telegram_bot_handlers.py)
# ---------------------------------------------------------------------------

_ALLOWED_CHAT = 100
_BLOCKED_CHAT = 999


def _make_update(chat_id: int = _ALLOWED_CHAT) -> MagicMock:
    update = MagicMock()
    update.message = MagicMock()
    update.message.chat_id = chat_id
    update.message.reply_text = AsyncMock()
    update.effective_chat = MagicMock()
    update.effective_chat.id = chat_id
    return update


def _make_context(args: list[str] | None = None) -> MagicMock:
    ctx = MagicMock()
    ctx.args = args or []
    return ctx


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _ensure_ptb_mocks_active() -> None:
    """Re-install mocks and reload if another test module tore them down."""
    if not _tb._PTB_AVAILABLE:
        _install_telegram_mocks()
        importlib.reload(_tb)


def _build_bot(*, allowed_chat_ids: list[int] | None = None) -> dict[str, object]:
    """Rebuild bot and return handler dict."""
    _ensure_ptb_mocks_active()
    # Ensure our CommandHandler stub is active (handlers test autouse may have
    # overwritten _tb.CommandHandler with its own version).
    _tb.CommandHandler = _fake_command_handler  # type: ignore[attr-defined]
    # Restore all telegram-related attributes to our mocks.  Other test
    # modules' teardown_module may restore sys.modules to real PTB, which
    # would cause real PTB Application/filters to leak into _tb.  We patch
    # _tb directly so create_operator_bot always uses our stubs.
    _tb.Application = _mock_app_class  # type: ignore[attr-defined]
    _tb.filters = _mock_filters  # type: ignore[attr-defined]
    _tb.MessageHandler = _mock_message_handler  # type: ignore[attr-defined]
    _tb.ContextTypes = _mock_context_types  # type: ignore[attr-defined]
    _registered_handlers.clear()
    op = MagicMock()
    op.default_workspace = "/workspace"
    op.is_workspace_allowed.return_value = True
    _tb.create_operator_bot(
        bot_token="fake-token",
        allowed_chat_ids=allowed_chat_ids if allowed_chat_ids is not None else [_ALLOWED_CHAT],
        operator=op,
    )
    return dict(_registered_handlers)


@pytest.fixture()
def handlers() -> dict[str, object]:
    """Standard bot fixture: allowed_chat_ids=[100]."""
    return _build_bot()


@pytest.fixture(autouse=True, scope="module")
def _neutralize_bot_state_file():  # type: ignore[return]
    """Prevent state-file writes from leaking across test modules.

    v3.8.0 _save_bot_state() writes to ~/.owlmind_bot_state.json.  Without
    this fixture, switching the model profile during a test permanently
    changes the file on disk, causing subsequently-created bots to start
    with a non-default profile and breaking test isolation.
    """
    import builtins
    import io
    import unittest.mock as _um

    original_open = builtins.open

    def _safe_open(path: object, mode: str = "r", **kw: object) -> object:
        if "owlmind_bot_state" in str(path):
            if "w" in mode:
                return io.StringIO()
            raise FileNotFoundError("state file neutralized by test fixture")
        return original_open(path, mode, **kw)  # type: ignore[arg-type]

    with _um.patch("builtins.open", side_effect=_safe_open):
        yield


# ---------------------------------------------------------------------------
# Helpers for memory-API mocking
# ---------------------------------------------------------------------------


def _mock_urlopen_json(payload: object):
    """Return a context manager that makes urlopen return JSON bytes."""
    mock_resp = MagicMock()
    mock_resp.read.return_value = json.dumps(payload).encode()
    mock_resp.__enter__ = lambda s: s
    mock_resp.__exit__ = MagicMock(return_value=False)
    return patch("urllib.request.urlopen", return_value=mock_resp)


def _mock_urlopen_raise(exc: Exception):
    """Return a context manager that makes urlopen raise *exc*."""
    return patch("urllib.request.urlopen", side_effect=exc)


# ===========================================================================
# TestCmdModel
# ===========================================================================


class TestCmdModel:
    @pytest.mark.asyncio()
    async def test_model_no_args_shows_current_profile(self, handlers: dict[str, object]) -> None:
        """No args: reply must contain current profile name 'balanced'."""
        handler = handlers["model"]
        update = _make_update()
        ctx = _make_context([])
        await handler(update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "balanced" in text

    @pytest.mark.asyncio()
    async def test_model_list_shows_all_profiles(self, handlers: dict[str, object]) -> None:
        """'list' sub-command: reply must contain fast, balanced, and powerful."""
        handler = handlers["model"]
        update = _make_update()
        ctx = _make_context(["list"])
        await handler(update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "fast" in text
        assert "balanced" in text
        assert "powerful" in text

    @pytest.mark.asyncio()
    async def test_model_switch_valid(self, handlers: dict[str, object]) -> None:
        """Switching to 'fast' profile: reply contains 'fast' or 'Haiku'."""
        handler = handlers["model"]
        update = _make_update()
        ctx = _make_context(["fast"])
        await handler(update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "fast" in text.lower() or "Haiku" in text

    @pytest.mark.asyncio()
    async def test_model_switch_invalid(self, handlers: dict[str, object]) -> None:
        """Unknown profile 'superfast': reply contains 'Unknown'."""
        handler = handlers["model"]
        update = _make_update()
        ctx = _make_context(["superfast"])
        await handler(update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "Unknown" in text

    @pytest.mark.asyncio()
    async def test_model_unauthorized(self) -> None:
        """Unauthorized chat_id: reply is 'Unauthorized.'."""
        h = _build_bot()
        handler = h["model"]
        update = _make_update(chat_id=_BLOCKED_CHAT)
        ctx = _make_context([])
        await handler(update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "Unauthorized" in text


# ===========================================================================
# TestCmdThink
# ===========================================================================


class TestCmdThink:
    @pytest.mark.asyncio()
    async def test_think_no_args_shows_current(self, handlers: dict[str, object]) -> None:
        """No args: reply contains current level 'medium' or its token count '8192'."""
        handler = handlers["think"]
        update = _make_update()
        ctx = _make_context([])
        await handler(update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "medium" in text or "8192" in text

    @pytest.mark.asyncio()
    async def test_think_set_valid(self, handlers: dict[str, object]) -> None:
        """Setting level to 'high': reply contains 'high' or '32768'."""
        handler = handlers["think"]
        update = _make_update()
        ctx = _make_context(["high"])
        await handler(update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "high" in text or "32768" in text

    @pytest.mark.asyncio()
    async def test_think_set_off(self, handlers: dict[str, object]) -> None:
        """Setting level to 'off': reply contains 'off' or '0'."""
        handler = handlers["think"]
        update = _make_update()
        ctx = _make_context(["off"])
        await handler(update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "off" in text.lower() or "0" in text

    @pytest.mark.asyncio()
    async def test_think_invalid_level(self, handlers: dict[str, object]) -> None:
        """Unknown level 'ultra': reply contains 'Unknown'."""
        handler = handlers["think"]
        update = _make_update()
        ctx = _make_context(["ultra"])
        await handler(update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "Unknown" in text

    @pytest.mark.asyncio()
    async def test_think_unauthorized(self) -> None:
        """Unauthorized chat_id: reply contains 'Unauthorized'."""
        h = _build_bot()
        handler = h["think"]
        update = _make_update(chat_id=_BLOCKED_CHAT)
        ctx = _make_context([])
        await handler(update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "Unauthorized" in text


# ===========================================================================
# TestCmdVerbose
# ===========================================================================


class TestCmdVerbose:
    @pytest.mark.asyncio()
    async def test_verbose_no_args_shows_state(self, handlers: dict[str, object]) -> None:
        """No args: reply contains current state ('off' by default)."""
        handler = handlers["verbose"]
        update = _make_update()
        ctx = _make_context([])
        await handler(update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "off" in text.lower()

    @pytest.mark.asyncio()
    async def test_verbose_on(self, handlers: dict[str, object]) -> None:
        """'on' arg: reply contains 'ON'."""
        handler = handlers["verbose"]
        update = _make_update()
        ctx = _make_context(["on"])
        await handler(update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "ON" in text

    @pytest.mark.asyncio()
    async def test_verbose_off_after_on(self, handlers: dict[str, object]) -> None:
        """Turn on, then off: second reply contains 'OFF'."""
        handler = handlers["verbose"]
        update = _make_update()

        # Turn on
        ctx_on = _make_context(["on"])
        await handler(update, ctx_on)

        # Turn off
        update.message.reply_text.reset_mock()
        ctx_off = _make_context(["off"])
        await handler(update, ctx_off)
        text = update.message.reply_text.call_args[0][0]
        assert "OFF" in text

    @pytest.mark.asyncio()
    async def test_verbose_invalid(self, handlers: dict[str, object]) -> None:
        """Invalid arg 'maybe': reply contains 'Usage:'."""
        handler = handlers["verbose"]
        update = _make_update()
        ctx = _make_context(["maybe"])
        await handler(update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "Usage:" in text

    @pytest.mark.asyncio()
    async def test_verbose_unauthorized(self) -> None:
        """Unauthorized chat_id: reply contains 'Unauthorized'."""
        h = _build_bot()
        handler = h["verbose"]
        update = _make_update(chat_id=_BLOCKED_CHAT)
        ctx = _make_context([])
        await handler(update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "Unauthorized" in text


# ===========================================================================
# TestCmdMemory
# ===========================================================================


class TestCmdMemory:
    @pytest.mark.asyncio()
    async def test_memory_stats_calls_api(self, handlers: dict[str, object]) -> None:
        """stats sub-command: mock urlopen to return document count, check '5' in reply."""
        handler = handlers["memory"]
        update = _make_update()
        ctx = _make_context([])  # default is "stats"

        payload = {"documents": 5, "chunks": 10, "signals": 3}
        with _mock_urlopen_json(payload):
            await handler(update, ctx)

        text = update.message.reply_text.call_args[0][0]
        assert "5" in text

    @pytest.mark.asyncio()
    async def test_memory_search_no_query(self, handlers: dict[str, object]) -> None:
        """'search' without query: reply contains 'Usage:'."""
        handler = handlers["memory"]
        update = _make_update()
        ctx = _make_context(["search"])  # no extra args
        await handler(update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "Usage:" in text

    @pytest.mark.asyncio()
    async def test_memory_signals_empty(self, handlers: dict[str, object]) -> None:
        """'signals' when API returns []: reply contains 'No signals'."""
        handler = handlers["memory"]
        update = _make_update()
        ctx = _make_context(["signals"])

        with _mock_urlopen_json([]):
            await handler(update, ctx)

        text = update.message.reply_text.call_args[0][0]
        assert "No signals" in text

    @pytest.mark.asyncio()
    async def test_memory_add_lesson(self, handlers: dict[str, object]) -> None:
        """'add lesson <text>': mock API returns signal_id=42, reply contains '42'."""
        handler = handlers["memory"]
        update = _make_update()
        ctx = _make_context(["add", "lesson", "Always", "test", "edge", "cases"])

        with _mock_urlopen_json({"signal_id": 42}):
            await handler(update, ctx)

        text = update.message.reply_text.call_args[0][0]
        assert "42" in text

    @pytest.mark.asyncio()
    async def test_memory_unknown_sub(self, handlers: dict[str, object]) -> None:
        """Unknown sub-command 'delete': reply contains 'Usage:'."""
        handler = handlers["memory"]
        update = _make_update()
        ctx = _make_context(["delete"])
        await handler(update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "Usage:" in text

    @pytest.mark.asyncio()
    async def test_memory_api_error(self, handlers: dict[str, object]) -> None:
        """When urlopen raises, reply contains 'error'."""
        handler = handlers["memory"]
        update = _make_update()
        ctx = _make_context([])  # stats

        with _mock_urlopen_raise(OSError("connection refused")):
            await handler(update, ctx)

        text = update.message.reply_text.call_args[0][0]
        assert "error" in text.lower()

    @pytest.mark.asyncio()
    async def test_memory_unauthorized(self) -> None:
        """Unauthorized chat_id: reply contains 'Unauthorized'."""
        h = _build_bot()
        handler = h["memory"]
        update = _make_update(chat_id=_BLOCKED_CHAT)
        ctx = _make_context([])
        await handler(update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "Unauthorized" in text


# ===========================================================================
# TestCmdHeartbeat
# ===========================================================================


class TestCmdHeartbeat:
    """Tests for /heartbeat command."""

    def _make_ctx_with_job_queue(self, args: list[str] | None = None) -> MagicMock:
        """Context mock with a functional job_queue stub."""
        ctx = _make_context(args)
        jq = MagicMock()
        jq.get_jobs_by_name.return_value = []  # no pre-existing jobs
        jq.run_repeating.return_value = MagicMock()
        ctx.job_queue = jq
        return ctx

    @pytest.mark.asyncio()
    async def test_heartbeat_off_disables(self, handlers: dict[str, object]) -> None:
        """'off' arg: reply contains 'disabled'."""
        handler = handlers["heartbeat"]
        update = _make_update()
        ctx = self._make_ctx_with_job_queue(["off"])
        await handler(update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "disabled" in text.lower()

    @pytest.mark.asyncio()
    async def test_heartbeat_on_schedules(self, handlers: dict[str, object]) -> None:
        """'on' arg: reply contains 'enabled' or '8h'."""
        handler = handlers["heartbeat"]
        update = _make_update()
        ctx = self._make_ctx_with_job_queue(["on"])
        await handler(update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "enabled" in text.lower() or "8h" in text

    @pytest.mark.asyncio()
    async def test_heartbeat_custom_interval(self, handlers: dict[str, object]) -> None:
        """'4h' arg: reply contains '4h'."""
        handler = handlers["heartbeat"]
        update = _make_update()
        ctx = self._make_ctx_with_job_queue(["4h"])
        await handler(update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "4h" in text

    @pytest.mark.asyncio()
    async def test_heartbeat_unauthorized(self) -> None:
        """Unauthorized chat_id: reply contains 'Unauthorized'."""
        h = _build_bot()
        handler = h["heartbeat"]
        update = _make_update(chat_id=_BLOCKED_CHAT)
        ctx = self._make_ctx_with_job_queue([])
        await handler(update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "Unauthorized" in text

    @pytest.mark.asyncio()
    async def test_heartbeat_no_job_queue(self, handlers: dict[str, object]) -> None:
        """When job_queue is None: reply contains 'not available'."""
        handler = handlers["heartbeat"]
        update = _make_update()
        ctx = _make_context(["on"])
        ctx.job_queue = None
        await handler(update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "not available" in text.lower()

    @pytest.mark.asyncio()
    async def test_heartbeat_no_args_disables(self, handlers: dict[str, object]) -> None:
        """No args: treated as 'off', reply contains 'disabled'."""
        handler = handlers["heartbeat"]
        update = _make_update()
        ctx = self._make_ctx_with_job_queue([])
        await handler(update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "disabled" in text.lower()


# ===========================================================================
# TestCmdScreenshot
# ===========================================================================


def _build_bot_capturing_mention(
    operator: object = None,
    allowed_chat_ids: list[int] | None = None,
) -> tuple[dict[str, object], object]:
    """Build bot patching _tb.MessageHandler to capture _group_mention closure."""
    _ensure_ptb_mocks_active()
    _tb.CommandHandler = _fake_command_handler  # type: ignore[attr-defined]
    _tb.Application = _mock_app_class  # type: ignore[attr-defined]
    _tb.filters = _mock_filters  # type: ignore[attr-defined]
    _tb.ContextTypes = _mock_context_types  # type: ignore[attr-defined]
    _registered_handlers.clear()

    captured_mention: list[object] = []

    def _fake_message_handler(filters: object, func: object) -> object:
        captured_mention.append(func)
        return MagicMock()

    # Patch the module-level MessageHandler binding directly
    original_mh = getattr(_tb, "MessageHandler", None)
    _tb.MessageHandler = _fake_message_handler  # type: ignore[attr-defined]

    try:
        _tb.create_operator_bot(
            bot_token="fake-token",
            allowed_chat_ids=allowed_chat_ids if allowed_chat_ids is not None else [_ALLOWED_CHAT],
            operator=operator,
        )
    finally:
        if original_mh is not None:
            _tb.MessageHandler = original_mh  # type: ignore[attr-defined]

    mention_handler = captured_mention[-1] if captured_mention else None
    return dict(_registered_handlers), mention_handler


class TestCmdScreenshot:
    @pytest.mark.asyncio()
    async def test_screenshot_success(self, handlers: dict[str, object]) -> None:
        """Successful screenshot: subprocess returns 0, send_photo is called."""
        handler = handlers["screenshot"]
        update = _make_update()
        ctx = _make_context([])
        ctx.bot = AsyncMock()
        ctx.bot.send_photo = AsyncMock()

        mock_result = MagicMock()
        mock_result.returncode = 0

        with (
            patch("subprocess.run", return_value=mock_result),
            patch(
                "builtins.open",
                MagicMock(
                    return_value=MagicMock(
                        __enter__=lambda s: MagicMock(), __exit__=MagicMock(return_value=False)
                    )
                ),
            ),
            patch("tempfile.NamedTemporaryFile") as mock_ntf,
            patch("os.unlink"),
        ):
            tmp_mock = MagicMock()
            tmp_mock.__enter__ = lambda s: s
            tmp_mock.__exit__ = MagicMock(return_value=False)
            tmp_mock.name = "/tmp/fake_screenshot.png"
            mock_ntf.return_value = tmp_mock

            await handler(update, ctx)

        ctx.bot.send_photo.assert_called_once()

    @pytest.mark.asyncio()
    async def test_screenshot_returncode_nonzero(self, handlers: dict[str, object]) -> None:
        """Non-zero returncode: reply_text 'Screenshot failed'."""
        handler = handlers["screenshot"]
        update = _make_update()
        ctx = _make_context([])
        ctx.bot = AsyncMock()

        mock_result = MagicMock()
        mock_result.returncode = 1

        with (
            patch("subprocess.run", return_value=mock_result),
            patch("tempfile.NamedTemporaryFile") as mock_ntf,
            patch("os.unlink"),
        ):
            tmp_mock = MagicMock()
            tmp_mock.__enter__ = lambda s: s
            tmp_mock.__exit__ = MagicMock(return_value=False)
            tmp_mock.name = "/tmp/fake_screenshot.png"
            mock_ntf.return_value = tmp_mock

            await handler(update, ctx)

        text = update.message.reply_text.call_args[0][0]
        assert "failed" in text.lower()

    @pytest.mark.asyncio()
    async def test_screenshot_file_not_found(self, handlers: dict[str, object]) -> None:
        """FileNotFoundError (screencapture not on PATH): reply contains 'not found'."""
        handler = handlers["screenshot"]
        update = _make_update()
        ctx = _make_context([])
        ctx.bot = AsyncMock()

        with (
            patch("subprocess.run", side_effect=FileNotFoundError("no screencapture")),
            patch("tempfile.NamedTemporaryFile") as mock_ntf,
            patch("os.unlink"),
        ):
            tmp_mock = MagicMock()
            tmp_mock.__enter__ = lambda s: s
            tmp_mock.__exit__ = MagicMock(return_value=False)
            tmp_mock.name = "/tmp/fake_screenshot.png"
            mock_ntf.return_value = tmp_mock

            await handler(update, ctx)

        text = update.message.reply_text.call_args[0][0]
        assert "not found" in text.lower()

    @pytest.mark.asyncio()
    async def test_screenshot_general_exception(self, handlers: dict[str, object]) -> None:
        """Generic exception: reply contains 'Screenshot error'."""
        handler = handlers["screenshot"]
        update = _make_update()
        ctx = _make_context([])
        ctx.bot = AsyncMock()

        with (
            patch("subprocess.run", side_effect=OSError("disk full")),
            patch("tempfile.NamedTemporaryFile") as mock_ntf,
            patch("os.unlink"),
        ):
            tmp_mock = MagicMock()
            tmp_mock.__enter__ = lambda s: s
            tmp_mock.__exit__ = MagicMock(return_value=False)
            tmp_mock.name = "/tmp/fake_screenshot.png"
            mock_ntf.return_value = tmp_mock

            await handler(update, ctx)

        text = update.message.reply_text.call_args[0][0]
        assert "Screenshot error" in text

    @pytest.mark.asyncio()
    async def test_screenshot_no_message(self, handlers: dict[str, object]) -> None:
        """update.message = None: handler returns early without crash."""
        handler = handlers["screenshot"]
        update = MagicMock()
        update.message = None
        ctx = _make_context([])
        await handler(update, ctx)  # should not raise

    @pytest.mark.asyncio()
    async def test_screenshot_unauthorized(self) -> None:
        """Unauthorized chat: reply contains 'Unauthorized'."""
        h = _build_bot()
        handler = h["screenshot"]
        update = _make_update(chat_id=_BLOCKED_CHAT)
        ctx = _make_context([])
        await handler(update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "Unauthorized" in text


# ===========================================================================
# TestCmdWatch
# ===========================================================================


class TestCmdWatch:
    @pytest.mark.asyncio()
    async def test_watch_add_run(self, handlers: dict[str, object]) -> None:
        """Providing a run_id: reply mentions the run_id."""
        handler = handlers["watch"]
        update = _make_update()
        ctx = _make_context(["run-abc"])
        await handler(update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "run-abc" in text

    @pytest.mark.asyncio()
    async def test_watch_no_args_empty(self, handlers: dict[str, object]) -> None:
        """No args, not watching anything: reply mentions 'Not watching'."""
        handler = handlers["watch"]
        update = _make_update()
        ctx = _make_context([])
        await handler(update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "Not watching" in text

    @pytest.mark.asyncio()
    async def test_watch_no_args_shows_watched(self, handlers: dict[str, object]) -> None:
        """After adding a run, no-arg /watch shows the watched run."""
        handler = handlers["watch"]
        update = _make_update()

        # First add a run to watch
        ctx_add = _make_context(["run-xyz"])
        await handler(update, ctx_add)

        # Now call with no args — should show run-xyz
        update.message.reply_text.reset_mock()
        ctx_empty = _make_context([])
        await handler(update, ctx_empty)
        text = update.message.reply_text.call_args[0][0]
        assert "run-xyz" in text

    @pytest.mark.asyncio()
    async def test_watch_stop(self, handlers: dict[str, object]) -> None:
        """'stop' arg: reply contains 'Stopped watching'."""
        handler = handlers["watch"]
        update = _make_update()

        # Add a run first
        ctx_add = _make_context(["run-1"])
        await handler(update, ctx_add)

        # Now stop
        update.message.reply_text.reset_mock()
        ctx_stop = _make_context(["stop"])
        await handler(update, ctx_stop)
        text = update.message.reply_text.call_args[0][0]
        assert "Stopped watching" in text

    @pytest.mark.asyncio()
    async def test_watch_no_message(self, handlers: dict[str, object]) -> None:
        """update.message = None: handler returns early without crash."""
        handler = handlers["watch"]
        update = MagicMock()
        update.message = None
        ctx = _make_context(["run-1"])
        await handler(update, ctx)  # should not raise

    @pytest.mark.asyncio()
    async def test_watch_unauthorized(self) -> None:
        """Unauthorized chat: reply contains 'Unauthorized'."""
        h = _build_bot()
        handler = h["watch"]
        update = _make_update(chat_id=_BLOCKED_CHAT)
        ctx = _make_context(["run-1"])
        await handler(update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "Unauthorized" in text


# ===========================================================================
# TestCmdQueue
# ===========================================================================


def _mock_urlopen_json_queue(payload: object):
    """Return a patch for urllib.request.urlopen returning JSON bytes."""
    mock_resp = MagicMock()
    mock_resp.read.return_value = json.dumps(payload).encode()
    mock_resp.__enter__ = lambda s: s
    mock_resp.__exit__ = MagicMock(return_value=False)
    return patch("urllib.request.urlopen", return_value=mock_resp)


class TestCmdQueue:
    @pytest.mark.asyncio()
    async def test_queue_no_args_list_empty(self, handlers: dict[str, object]) -> None:
        """Default (no args) list with empty queue: reply contains 'empty'."""
        handler = handlers["queue"]
        update = _make_update()
        ctx = _make_context([])

        with _mock_urlopen_json_queue({"items": []}):
            await handler(update, ctx)

        text = update.message.reply_text.call_args[0][0]
        assert "empty" in text.lower()

    @pytest.mark.asyncio()
    async def test_queue_list_with_items(self, handlers: dict[str, object]) -> None:
        """List subcommand with items: reply contains item count."""
        handler = handlers["queue"]
        update = _make_update()
        ctx = _make_context(["list"])

        items = [
            {"id": "item-001", "status": "PENDING", "goal": "fix the bug"},
            {"id": "item-002", "status": "RUNNING", "goal": "add tests"},
        ]
        with _mock_urlopen_json_queue({"items": items}):
            await handler(update, ctx)

        text = update.message.reply_text.call_args[0][0]
        assert "Queue" in text
        assert "2" in text

    @pytest.mark.asyncio()
    async def test_queue_list_api_error(self, handlers: dict[str, object]) -> None:
        """API returns error: reply contains 'Queue error'."""
        handler = handlers["queue"]
        update = _make_update()
        ctx = _make_context(["list"])

        with _mock_urlopen_json_queue({"error": "connection refused"}):
            await handler(update, ctx)

        text = update.message.reply_text.call_args[0][0]
        assert "Queue error" in text

    @pytest.mark.asyncio()
    async def test_queue_add_no_goal(self, handlers: dict[str, object]) -> None:
        """'/queue add' with no goal: reply contains 'Usage'."""
        handler = handlers["queue"]
        update = _make_update()
        ctx = _make_context(["add"])
        await handler(update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "Usage" in text

    @pytest.mark.asyncio()
    async def test_queue_add_success(self, handlers: dict[str, object]) -> None:
        """'/queue add some goal': API returns id, reply contains id."""
        handler = handlers["queue"]
        update = _make_update()
        ctx = _make_context(["add", "fix", "the", "login", "bug"])

        with _mock_urlopen_json_queue({"id": "task-999"}):
            await handler(update, ctx)

        text = update.message.reply_text.call_args[0][0]
        assert "task-999" in text

    @pytest.mark.asyncio()
    async def test_queue_add_api_error(self, handlers: dict[str, object]) -> None:
        """'/queue add' with API error: reply contains 'Error'."""
        handler = handlers["queue"]
        update = _make_update()
        ctx = _make_context(["add", "some", "goal"])

        with _mock_urlopen_json_queue({"error": "server down"}):
            await handler(update, ctx)

        text = update.message.reply_text.call_args[0][0]
        assert "Error" in text

    @pytest.mark.asyncio()
    async def test_queue_unknown_subcommand(self, handlers: dict[str, object]) -> None:
        """Unknown subcommand: reply contains 'Usage'."""
        handler = handlers["queue"]
        update = _make_update()
        ctx = _make_context(["delete"])
        await handler(update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "Usage" in text

    @pytest.mark.asyncio()
    async def test_queue_no_message(self, handlers: dict[str, object]) -> None:
        """update.message = None: handler returns early without crash."""
        handler = handlers["queue"]
        update = MagicMock()
        update.message = None
        ctx = _make_context([])
        await handler(update, ctx)  # should not raise

    @pytest.mark.asyncio()
    async def test_queue_unauthorized(self) -> None:
        """Unauthorized chat: reply contains 'Unauthorized'."""
        h = _build_bot()
        handler = h["queue"]
        update = _make_update(chat_id=_BLOCKED_CHAT)
        ctx = _make_context([])
        await handler(update, ctx)
        text = update.message.reply_text.call_args[0][0]
        assert "Unauthorized" in text


# ===========================================================================
# TestGroupMentionHandler
# ===========================================================================


class TestGroupMentionHandler:
    @pytest.mark.asyncio()
    async def test_mention_with_goal_success(self) -> None:
        """Bot mentioned with goal text: starts autopilot, reply contains run_id."""
        info = MagicMock()
        info.run_id = "run-mention-1"

        op = MagicMock()
        op.default_workspace = "/workspace"
        op.is_workspace_allowed.return_value = True
        op.start_autopilot_async = AsyncMock(return_value=info)

        _, fn = _build_bot_capturing_mention(operator=op)
        assert fn is not None, "_group_mention was not captured"

        update = _make_update()
        update.message.text = "@testbot fix the authentication bug"
        ctx = _make_context([])
        ctx.bot = MagicMock()
        ctx.bot.username = "testbot"

        await fn(update, ctx)  # type: ignore[operator]

        text = update.message.reply_text.call_args[0][0]
        assert "run-mention-1" in text

    @pytest.mark.asyncio()
    async def test_mention_no_goal(self) -> None:
        """Bot mentioned with only the mention (no goal text): reply asks for goal."""
        op = MagicMock()
        op.default_workspace = "/workspace"
        op.is_workspace_allowed.return_value = True

        _, fn = _build_bot_capturing_mention(operator=op)
        assert fn is not None

        update = _make_update()
        update.message.text = "@testbot"
        ctx = _make_context([])
        ctx.bot = MagicMock()
        ctx.bot.username = "testbot"

        await fn(update, ctx)  # type: ignore[operator]

        text = update.message.reply_text.call_args[0][0]
        assert "goal" in text.lower()

    @pytest.mark.asyncio()
    async def test_mention_no_operator(self) -> None:
        """Bot mentioned but operator is None: reply contains 'not configured'."""
        _, fn = _build_bot_capturing_mention(operator=None)
        assert fn is not None

        update = _make_update()
        update.message.text = "@testbot do something useful"
        ctx = _make_context([])
        ctx.bot = MagicMock()
        ctx.bot.username = "testbot"

        await fn(update, ctx)  # type: ignore[operator]

        text = update.message.reply_text.call_args[0][0]
        assert "not configured" in text.lower()

    @pytest.mark.asyncio()
    async def test_mention_no_message(self) -> None:
        """update.message = None: handler returns early without crash."""
        _, fn = _build_bot_capturing_mention(operator=None)
        assert fn is not None

        update = MagicMock()
        update.message = None
        ctx = _make_context([])
        ctx.bot = MagicMock()
        ctx.bot.username = "testbot"

        await fn(update, ctx)  # should not raise

    @pytest.mark.asyncio()
    async def test_mention_autopilot_error(self) -> None:
        """Autopilot raises: reply contains 'Error'."""
        op = MagicMock()
        op.default_workspace = "/workspace"
        op.start_autopilot_async = AsyncMock(side_effect=RuntimeError("boom"))

        _, fn = _build_bot_capturing_mention(operator=op)
        assert fn is not None

        update = _make_update()
        update.message.text = "@testbot fix the bug"
        ctx = _make_context([])
        ctx.bot = MagicMock()
        ctx.bot.username = "testbot"

        await fn(update, ctx)  # type: ignore[operator]

        text = update.message.reply_text.call_args[0][0]
        assert "Error" in text


# ---------------------------------------------------------------------------
# Cleanup
# ---------------------------------------------------------------------------


def teardown_module() -> None:
    """Reload telegram_bot to restore clean state after this test module."""
    importlib.reload(_tb)
