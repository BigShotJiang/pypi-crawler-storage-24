"""Tests for owlmind.diag — diagnostic report builder."""

from __future__ import annotations

import json
import os
import subprocess
import zipfile
from pathlib import Path
from unittest.mock import patch

from owlmind.diag import (
    _recent_runs,
    _recent_sessions,
    _run_doctor,
    _run_security_scan,
    _versions_text,
    build_diag_report,
)


class TestVersionsText:
    def test_contains_owlmind_version(self) -> None:
        text = _versions_text()
        assert "owlmind:" in text

    def test_contains_python_version(self) -> None:
        text = _versions_text()
        assert "python:" in text

    def test_contains_platform(self) -> None:
        text = _versions_text()
        assert "platform:" in text


class TestRecentRuns:
    def test_empty_dir(self, tmp_path: Path) -> None:
        runs_dir = tmp_path / "runs"
        runs_dir.mkdir()
        result = _recent_runs(runs_dir)
        assert result == []

    def test_missing_dir(self, tmp_path: Path) -> None:
        result = _recent_runs(tmp_path / "nonexistent")
        assert result == []

    def test_reads_run_meta(self, tmp_path: Path) -> None:
        runs_dir = tmp_path / "runs"
        run_dir = runs_dir / "cycle-test-001"
        run_dir.mkdir(parents=True)
        meta = {
            "run_id": "cycle-test-001",
            "state": "DONE",
            "goal": "Test goal",
            "iteration": 1,
            "updated_at": "2025-01-01T00:00:00",
        }
        (run_dir / "cycle_meta.json").write_text(json.dumps(meta))

        result = _recent_runs(runs_dir)
        assert len(result) == 1
        assert result[0]["run_id"] == "cycle-test-001"
        assert result[0]["state"] == "DONE"

    def test_limits_results(self, tmp_path: Path) -> None:
        runs_dir = tmp_path / "runs"
        for i in range(5):
            rd = runs_dir / f"cycle-{i:03d}"
            rd.mkdir(parents=True)
            (rd / "cycle_meta.json").write_text(
                json.dumps({"run_id": f"cycle-{i:03d}", "state": "DONE"})
            )
        result = _recent_runs(runs_dir, limit=3)
        assert len(result) == 3


class TestBuildDiagReport:
    def test_creates_zip(self, tmp_path: Path) -> None:
        out = tmp_path / "diag.zip"
        with patch.dict(os.environ, {}, clear=True):
            result = build_diag_report(tmp_path, out_zip=out)
        assert result == out
        assert out.exists()
        assert zipfile.is_zipfile(out)

    def test_zip_contains_expected_files(self, tmp_path: Path) -> None:
        out = tmp_path / "diag.zip"
        with patch.dict(os.environ, {}, clear=True):
            build_diag_report(tmp_path, out_zip=out)

        with zipfile.ZipFile(out) as zf:
            names = zf.namelist()
            assert "versions.txt" in names
            assert "config_resolved.json" in names
            assert "doctor.txt" in names
            assert "security_scan.txt" in names
            assert "recent_runs.json" in names
            assert "recent_sessions.json" in names
            assert "notes.md" in names

    def test_no_secrets_in_config(self, tmp_path: Path) -> None:
        out = tmp_path / "diag.zip"
        env = {
            "OPENAI_API_KEY": "sk-super-secret-key-12345",
            "ANTHROPIC_API_KEY": "sk-ant-secret-token",
            "TELEGRAM_BOT_TOKEN": "123456:ABCDEF-secret-bot",
        }
        with patch.dict(os.environ, env, clear=True):
            build_diag_report(tmp_path, out_zip=out)

        with zipfile.ZipFile(out) as zf:
            config_text = zf.read("config_resolved.json").decode()
            assert "sk-super-secret-key-12345" not in config_text
            assert "sk-ant-secret-token" not in config_text
            assert "123456:ABCDEF-secret-bot" not in config_text
            assert "***" in config_text

    def test_default_output_path(self, tmp_path: Path) -> None:
        with patch.dict(os.environ, {}, clear=True):
            result = build_diag_report(tmp_path)
        assert result.parent == tmp_path / "reports"
        assert result.name.startswith("owlmind_diag_")
        assert result.name.endswith(".zip")
        assert result.exists()

    def test_includes_run_data(self, tmp_path: Path) -> None:
        run_dir = tmp_path / "runs" / "cycle-diag-001"
        run_dir.mkdir(parents=True)
        (run_dir / "cycle_meta.json").write_text(
            json.dumps({"run_id": "cycle-diag-001", "state": "DONE", "goal": "Diag test"})
        )

        out = tmp_path / "diag.zip"
        with patch.dict(os.environ, {}, clear=True):
            build_diag_report(tmp_path, out_zip=out)

        with zipfile.ZipFile(out) as zf:
            runs_text = zf.read("recent_runs.json").decode()
            assert "cycle-diag-001" in runs_text


class TestRunDoctor:
    def test_timeout_returns_fallback(self) -> None:
        """Lines 42-43: TimeoutExpired → fallback string returned."""
        with patch(
            "owlmind.diag.subprocess.run",
            side_effect=subprocess.TimeoutExpired(cmd=["owlmind"], timeout=30),
        ):
            result = _run_doctor()
        assert "doctor command failed or timed out" in result

    def test_file_not_found_returns_fallback(self) -> None:
        """Lines 42-43: FileNotFoundError → fallback string returned."""
        with patch("owlmind.diag.subprocess.run", side_effect=FileNotFoundError):
            result = _run_doctor()
        assert "doctor command failed or timed out" in result

    def test_os_error_returns_fallback(self) -> None:
        """Lines 42-43: OSError → fallback string returned."""
        with patch("owlmind.diag.subprocess.run", side_effect=OSError("exec failed")):
            result = _run_doctor()
        assert "doctor command failed or timed out" in result

    def test_success_redacts_output(self) -> None:
        """Normal execution: output is processed through redact_secrets and returned."""
        mock_proc = subprocess.CompletedProcess(
            args=[], returncode=0, stdout="Doctor OK", stderr="no issues"
        )
        with patch("owlmind.diag.subprocess.run", return_value=mock_proc):
            result = _run_doctor()
        # Combined stdout+stderr should appear in result (possibly redacted)
        assert isinstance(result, str)
        assert len(result) > 0


class TestRunSecurityScan:
    def test_timeout_returns_fallback(self, tmp_path: Path) -> None:
        """Lines 57-58: TimeoutExpired → fallback string returned."""
        with patch(
            "owlmind.diag.subprocess.run",
            side_effect=subprocess.TimeoutExpired(cmd=["owlmind"], timeout=30),
        ):
            result = _run_security_scan(tmp_path)
        assert "security scan failed or timed out" in result

    def test_file_not_found_returns_fallback(self, tmp_path: Path) -> None:
        """Lines 57-58: FileNotFoundError → fallback string returned."""
        with patch("owlmind.diag.subprocess.run", side_effect=FileNotFoundError):
            result = _run_security_scan(tmp_path)
        assert "security scan failed or timed out" in result

    def test_os_error_returns_fallback(self, tmp_path: Path) -> None:
        """Lines 57-58: OSError → fallback string returned."""
        with patch("owlmind.diag.subprocess.run", side_effect=OSError("bad exec")):
            result = _run_security_scan(tmp_path)
        assert "security scan failed or timed out" in result


class TestRecentRunsUnreadable:
    def test_corrupt_json_returns_unreadable_entry(self, tmp_path: Path) -> None:
        """Lines 83-84: corrupt JSON → entry with state='unreadable'."""
        runs_dir = tmp_path / "runs"
        run_dir = runs_dir / "cycle-bad-001"
        run_dir.mkdir(parents=True)
        (run_dir / "cycle_meta.json").write_text("{ invalid json !!!}")

        result = _recent_runs(runs_dir)

        assert len(result) == 1
        assert result[0]["run_id"] == "cycle-bad-001"
        assert result[0]["state"] == "unreadable"

    def test_os_error_on_read_returns_unreadable_entry(self, tmp_path: Path) -> None:
        """Lines 83-84: OSError during read → entry with state='unreadable'."""
        runs_dir = tmp_path / "runs"
        run_dir = runs_dir / "cycle-oserr-001"
        run_dir.mkdir(parents=True)
        meta_path = run_dir / "cycle_meta.json"
        meta_path.write_text(json.dumps({"run_id": "cycle-oserr-001"}))

        with patch("owlmind.diag.json.loads", side_effect=OSError("read error")):
            result = _recent_runs(runs_dir)

        assert len(result) == 1
        assert result[0]["state"] == "unreadable"


class TestRecentSessions:
    def test_missing_dir_returns_empty(self, tmp_path: Path) -> None:
        """Lines 94-95: sessions_dir does not exist → empty list."""
        result = _recent_sessions(tmp_path / "nonexistent")
        assert result == []

    def test_empty_dir_returns_empty(self, tmp_path: Path) -> None:
        """Lines 94-95: sessions_dir exists but has no session dirs → empty list."""
        sessions_dir = tmp_path / "sessions"
        sessions_dir.mkdir()
        result = _recent_sessions(sessions_dir)
        assert result == []

    def test_reads_session_meta(self, tmp_path: Path) -> None:
        """Lines 97-107: valid session_meta.json → summary dict returned."""
        sessions_dir = tmp_path / "sessions"
        session_dir = sessions_dir / "ses-abc-001"
        session_dir.mkdir(parents=True)
        meta = {
            "session_id": "ses-abc-001",
            "status": "completed",
            "goals_total": 5,
            "goals_done": 5,
        }
        (session_dir / "session_meta.json").write_text(json.dumps(meta))

        result = _recent_sessions(sessions_dir)

        assert len(result) == 1
        assert result[0]["session_id"] == "ses-abc-001"
        assert result[0]["status"] == "completed"
        assert result[0]["goals_total"] == 5
        assert result[0]["goals_done"] == 5

    def test_corrupt_json_returns_unreadable_entry(self, tmp_path: Path) -> None:
        """Lines 108-109: corrupt session_meta.json → state='unreadable'."""
        sessions_dir = tmp_path / "sessions"
        session_dir = sessions_dir / "ses-bad-001"
        session_dir.mkdir(parents=True)
        (session_dir / "session_meta.json").write_text("{ bad json")

        result = _recent_sessions(sessions_dir)

        assert len(result) == 1
        assert result[0]["session_id"] == "ses-bad-001"
        assert result[0]["status"] == "unreadable"

    def test_limits_results(self, tmp_path: Path) -> None:
        """Lines 94-109: limit parameter respected."""
        sessions_dir = tmp_path / "sessions"
        for i in range(6):
            sd = sessions_dir / f"ses-{i:03d}"
            sd.mkdir(parents=True)
            (sd / "session_meta.json").write_text(
                json.dumps({"session_id": f"ses-{i:03d}", "status": "completed"})
            )

        result = _recent_sessions(sessions_dir, limit=3)
        assert len(result) == 3

    def test_no_meta_file_skipped(self, tmp_path: Path) -> None:
        """Lines 96-97: dir without session_meta.json → skipped, not included."""
        sessions_dir = tmp_path / "sessions"
        session_dir = sessions_dir / "ses-no-meta"
        session_dir.mkdir(parents=True)
        # No session_meta.json created

        result = _recent_sessions(sessions_dir)
        assert result == []

    def test_uses_dir_name_as_fallback_id(self, tmp_path: Path) -> None:
        """Lines 101-106: session_id missing from meta → dir name used."""
        sessions_dir = tmp_path / "sessions"
        session_dir = sessions_dir / "ses-fallback-id"
        session_dir.mkdir(parents=True)
        meta = {"status": "running", "goals_total": 3}
        (session_dir / "session_meta.json").write_text(json.dumps(meta))

        result = _recent_sessions(sessions_dir)

        assert len(result) == 1
        assert result[0]["session_id"] == "ses-fallback-id"

    def test_build_diag_report_includes_session_data(self, tmp_path: Path) -> None:
        """Lines 94-110: build_diag_report collects session data into zip."""
        session_dir = tmp_path / "sessions" / "ses-diag-001"
        session_dir.mkdir(parents=True)
        (session_dir / "session_meta.json").write_text(
            json.dumps(
                {
                    "session_id": "ses-diag-001",
                    "status": "completed",
                    "goals_total": 2,
                    "goals_done": 2,
                }
            )
        )

        out = tmp_path / "diag.zip"
        with patch.dict(os.environ, {}, clear=True):
            build_diag_report(tmp_path, out_zip=out)

        with zipfile.ZipFile(out) as zf:
            sessions_text = zf.read("recent_sessions.json").decode()
            assert "ses-diag-001" in sessions_text
            assert "completed" in sessions_text
