"""Tests for:
  - owlmind.tools.qdrant_store.QdrantStore (graceful ImportError when unavailable)
  - owlmind.tools.code_rag.CodeRAG.index_workspace() (with mocked QdrantStore)
  - CLI: owlmind ast index --workspace /tmp (everything mocked)
"""
from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from owlmind.cli.ast_cmd import ast_app

runner = CliRunner()


# ---------------------------------------------------------------------------
# QdrantStore — graceful ImportError when qdrant-client is not installed
# ---------------------------------------------------------------------------


class TestQdrantStoreImportGuard:
    def test_raises_import_error_when_qdrant_not_installed(self) -> None:
        """QdrantStore.__init__ raises ImportError when _QDRANT_OK is False."""
        import owlmind.tools.qdrant_store as qs_mod

        with patch.object(qs_mod, "_QDRANT_OK", False):
            with pytest.raises(ImportError, match="qdrant-client"):
                qs_mod.QdrantStore()

    def test_raises_import_error_message_includes_install_hint(self) -> None:
        """The ImportError message names the packages to install."""
        import owlmind.tools.qdrant_store as qs_mod

        with patch.object(qs_mod, "_QDRANT_OK", False):
            with pytest.raises(ImportError) as exc_info:
                qs_mod.QdrantStore()
        assert "qdrant-client" in str(exc_info.value)

    def test_qdrant_ok_flag_exists(self) -> None:
        """Module-level _QDRANT_OK flag is present."""
        import owlmind.tools.qdrant_store as qs_mod

        assert hasattr(qs_mod, "_QDRANT_OK")
        assert isinstance(qs_mod._QDRANT_OK, bool)

    def test_constants_defined(self) -> None:
        """COLLECTION and VECTOR_SIZE are module-level constants."""
        import owlmind.tools.qdrant_store as qs_mod

        assert qs_mod.COLLECTION == "owlmind_code"
        assert qs_mod.VECTOR_SIZE == 384

    def test_qdrant_store_upsert_search_count_methods_exist(self) -> None:
        """QdrantStore exposes upsert, search, count, search_text methods."""
        import owlmind.tools.qdrant_store as qs_mod

        for method in ("upsert", "search", "count", "search_text"):
            assert hasattr(qs_mod.QdrantStore, method), f"Missing method: {method}"


# ---------------------------------------------------------------------------
# QdrantStore — unit tests with mocked qdrant-client
# ---------------------------------------------------------------------------


class TestQdrantStoreMocked:
    """Test QdrantStore behaviour when qdrant-client IS available (mocked)."""

    def _make_store(self):
        """Return a QdrantStore with a fully mocked qdrant client."""
        import owlmind.tools.qdrant_store as qs_mod

        mock_client = MagicMock()
        mock_client.get_collections.return_value = MagicMock(collections=[])

        # Inject mock names directly into the module so they persist for the
        # lifetime of the returned store (not just within a `with` block).
        qs_mod._QDRANT_OK = True
        qs_mod.QdrantClient = MagicMock(return_value=mock_client)
        qs_mod.VectorParams = MagicMock(return_value=MagicMock())
        qs_mod.Distance = MagicMock()
        qs_mod.PointStruct = MagicMock(side_effect=lambda **kw: kw)

        store = qs_mod.QdrantStore(url="http://localhost:6333")
        store._client = mock_client
        # Reset call counts so tests start clean (init already called _ensure_collection)
        mock_client.reset_mock()
        return store, mock_client

    def test_ensure_collection_creates_when_missing(self) -> None:
        store, mock_client = self._make_store()
        mock_client.get_collections.return_value = MagicMock(collections=[])
        store._ensure_collection()
        mock_client.create_collection.assert_called_once()

    def test_ensure_collection_skips_when_exists(self) -> None:
        import owlmind.tools.qdrant_store as qs_mod

        mock_coll = MagicMock()
        mock_coll.name = qs_mod.COLLECTION
        store, mock_client = self._make_store()
        mock_client.get_collections.return_value = MagicMock(collections=[mock_coll])
        store._ensure_collection()
        mock_client.create_collection.assert_not_called()

    def test_upsert_calls_client(self) -> None:
        store, mock_client = self._make_store()
        points = [{"id": 0, "vector": [0.1] * 384, "payload": {"file": "a.py"}}]
        store.upsert(points)
        mock_client.upsert.assert_called_once()

    def test_search_returns_payload_list(self) -> None:

        store, mock_client = self._make_store()
        mock_hit = MagicMock()
        mock_hit.payload = {"file": "main.py", "start_line": 1, "end_line": 10}
        mock_hit.score = 0.95
        mock_client.search.return_value = [mock_hit]

        results = store.search([0.0] * 384, limit=3)
        assert len(results) == 1
        assert results[0]["file"] == "main.py"
        assert results[0]["score"] == 0.95

    def test_count_returns_int(self) -> None:
        store, mock_client = self._make_store()
        mock_info = MagicMock()
        mock_info.points_count = 42
        mock_client.get_collection.return_value = mock_info
        assert store.count() == 42


# ---------------------------------------------------------------------------
# CodeRAG.index_workspace — mocked QdrantStore
# ---------------------------------------------------------------------------


class TestCodeRAGIndexWorkspace:
    def test_index_workspace_returns_index_stats(self, tmp_path: Path) -> None:
        """index_workspace() returns IndexStats with qdrant backend when available."""
        (tmp_path / "hello.py").write_text(
            "def greet(name):\n    return f'hello {name}'\n" * 10
        )

        from owlmind.tools.code_rag import CodeRAG, IndexStats

        mock_store = MagicMock()
        mock_store.upsert = MagicMock()

        mock_model = MagicMock()
        # encode() returns a list-of-lists (no numpy dependency)
        mock_model.encode.side_effect = lambda texts, **kw: [[0.1] * 384 for _ in texts]

        mock_qs_mod = MagicMock()
        mock_qs_mod.QdrantStore.return_value = mock_store
        mock_qs_mod.VECTOR_SIZE = 384

        mock_st_mod = MagicMock()
        mock_st_mod.SentenceTransformer.return_value = mock_model

        with patch.dict("sys.modules", {
            "owlmind.tools.qdrant_store": mock_qs_mod,
            "sentence_transformers": mock_st_mod,
        }):
            rag = CodeRAG(workspace=tmp_path)
            stats = rag.index_workspace(tmp_path)

        assert isinstance(stats, IndexStats)
        # Either qdrant succeeded or fell back — both are valid
        assert stats.duration_ms >= 0

    def test_index_workspace_falls_back_when_sentence_transformers_missing(
        self, tmp_path: Path
    ) -> None:
        """index_workspace() falls back to index() if sentence-transformers is absent."""
        (tmp_path / "code.py").write_text("x = 1\n")

        from owlmind.tools.code_rag import CodeRAG

        rag = CodeRAG(workspace=tmp_path)

        # Simulate missing sentence_transformers by injecting a module whose
        # SentenceTransformer attribute raises ImportError on construction,
        # while making owlmind.tools.qdrant_store importable (with QdrantStore
        # that raises ImportError to trigger the fallback path).
        mock_qs_mod = MagicMock()
        mock_qs_mod.QdrantStore.side_effect = ImportError("qdrant-client not installed")
        mock_qs_mod.VECTOR_SIZE = 384

        with patch.dict("sys.modules", {
            "owlmind.tools.qdrant_store": mock_qs_mod,
        }), patch.object(rag, "index") as mock_index:
            mock_index.return_value = MagicMock(backend="tfidf", error="")
            rag.index_workspace(tmp_path)

        # index() was invoked as fallback because QdrantStore raised ImportError
        mock_index.assert_called_once()

    def test_index_workspace_with_mocked_qdrant_store(self, tmp_path: Path) -> None:
        """index_workspace() upserts chunks into QdrantStore."""
        # Write a couple of Python files
        (tmp_path / "alpha.py").write_text("def alpha(): pass\n" * 5)
        (tmp_path / "beta.py").write_text("def beta(): pass\n" * 5)

        from owlmind.tools.code_rag import CodeRAG, IndexStats

        mock_store = MagicMock()
        mock_store.upsert = MagicMock()

        mock_model = MagicMock()
        # encode() must return a sequence where each element is indexable to float
        # Use a simple list-of-lists — no numpy dependency needed.
        mock_model.encode.side_effect = (
            lambda texts, **kw: [[0.1] * 384 for _ in texts]
        )

        mock_qs_mod = MagicMock()
        mock_qs_mod.QdrantStore.return_value = mock_store
        mock_qs_mod.VECTOR_SIZE = 384

        mock_st_mod = MagicMock()
        mock_st_mod.SentenceTransformer.return_value = mock_model

        with patch.dict("sys.modules", {
            "owlmind.tools.qdrant_store": mock_qs_mod,
            "sentence_transformers": mock_st_mod,
        }):
            rag = CodeRAG(workspace=tmp_path)
            stats = rag.index_workspace(tmp_path)

        assert isinstance(stats, IndexStats)
        assert stats.duration_ms >= 0


# ---------------------------------------------------------------------------
# CLI: owlmind ast index --workspace /tmp (everything mocked)
# ---------------------------------------------------------------------------


class TestAstIndexCLI:
    def test_cli_index_success(self, tmp_path: Path) -> None:
        """'owlmind ast index --workspace <path>' exits 0 on success."""
        mock_rag = MagicMock()
        mock_stats = MagicMock()
        mock_stats.files_indexed = 7
        mock_stats.chunks_indexed = 42
        mock_stats.backend = "qdrant"
        mock_stats.duration_ms = 99
        mock_stats.error = ""
        mock_rag.index.return_value = mock_stats

        with patch("owlmind.cli.ast_cmd.CodeRAG", return_value=mock_rag):
            result = runner.invoke(ast_app, ["index", "--workspace", str(tmp_path)])

        assert result.exit_code == 0
        assert "7" in result.output
        assert "42" in result.output

    def test_cli_index_reports_error(self, tmp_path: Path) -> None:
        """'owlmind ast index' exits non-zero when indexing fails."""
        mock_rag = MagicMock()
        mock_stats = MagicMock()
        mock_stats.error = "Connection refused"
        mock_rag.index.return_value = mock_stats

        with patch("owlmind.cli.ast_cmd.CodeRAG", return_value=mock_rag):
            result = runner.invoke(ast_app, ["index", "--workspace", str(tmp_path)])

        assert result.exit_code != 0
        assert "Connection refused" in result.output

    def test_cli_index_default_workspace(self) -> None:
        """'owlmind ast index' (no --workspace) uses '.' as default."""
        mock_rag = MagicMock()
        mock_stats = MagicMock()
        mock_stats.files_indexed = 0
        mock_stats.chunks_indexed = 0
        mock_stats.backend = "tfidf"
        mock_stats.duration_ms = 1
        mock_stats.error = ""
        mock_rag.index.return_value = mock_stats

        with patch("owlmind.cli.ast_cmd.CodeRAG", return_value=mock_rag) as mock_cls:
            result = runner.invoke(ast_app, ["index"])

        assert result.exit_code == 0
        mock_cls.assert_called_once_with(workspace=".", **{})

    def test_cli_index_qdrant_url_option(self) -> None:
        """--qdrant-url is forwarded to CodeRAG constructor."""
        mock_rag = MagicMock()
        mock_stats = MagicMock()
        mock_stats.files_indexed = 1
        mock_stats.chunks_indexed = 3
        mock_stats.backend = "qdrant"
        mock_stats.duration_ms = 10
        mock_stats.error = ""
        mock_rag.index.return_value = mock_stats

        with patch("owlmind.cli.ast_cmd.CodeRAG", return_value=mock_rag) as mock_cls:
            result = runner.invoke(
                ast_app,
                ["index", "--workspace", "/tmp", "--qdrant-url", "http://myhost:6333"],
            )

        assert result.exit_code == 0
        mock_cls.assert_called_once_with(workspace="/tmp", qdrant_url="http://myhost:6333")

    def test_cli_index_with_force_flag(self) -> None:
        """--force is passed through to rag.index(force=True)."""
        mock_rag = MagicMock()
        mock_stats = MagicMock()
        mock_stats.files_indexed = 2
        mock_stats.chunks_indexed = 8
        mock_stats.backend = "qdrant"
        mock_stats.duration_ms = 5
        mock_stats.error = ""
        mock_rag.index.return_value = mock_stats

        with patch("owlmind.cli.ast_cmd.CodeRAG", return_value=mock_rag):
            result = runner.invoke(ast_app, ["index", "--workspace", "/tmp", "--force"])

        assert result.exit_code == 0
        mock_rag.index.assert_called_once_with(force=True)

    def test_cli_index_all_mocked(self) -> None:
        """Full integration mock: CodeRAG, QdrantStore, sentence-transformers all mocked."""
        mock_rag = MagicMock()
        mock_stats = MagicMock()
        mock_stats.files_indexed = 3
        mock_stats.chunks_indexed = 15
        mock_stats.backend = "qdrant"
        mock_stats.duration_ms = 20
        mock_stats.error = ""
        mock_rag.index.return_value = mock_stats

        with patch("owlmind.cli.ast_cmd.CodeRAG", return_value=mock_rag):
            with patch.dict("sys.modules", {
                "qdrant_client": MagicMock(),
                "sentence_transformers": MagicMock(),
            }):
                result = runner.invoke(ast_app, ["index", "--workspace", "/tmp"])

        assert result.exit_code == 0
        assert "3" in result.output
        assert "15" in result.output
