"""Tests for VCS integration: factory, GitLab, Bitbucket, webhooks, reporter."""

from __future__ import annotations

import hashlib
import hmac
import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from starlette.testclient import TestClient

from owlmind.integrations.vcs import create_vcs_client
from owlmind.integrations.vcs.base import (
    CommentResult,
    CommitStatus,
    MRInfo,
    StatusResult,
    VCSConfig,
    VCSProvider,
)
from owlmind.integrations.vcs.bitbucket import BitbucketVCS
from owlmind.integrations.vcs.gitlab import GitLabVCS
from owlmind.integrations.vcs.reporter import format_result_comment, report_to_vcs

# ---------------------------------------------------------------------------
# Factory tests
# ---------------------------------------------------------------------------


class TestCreateVCSClient:
    """Tests for create_vcs_client factory."""

    def test_create_gitlab(self) -> None:
        client = create_vcs_client("gitlab", "glpat-xxx")
        assert isinstance(client, GitLabVCS)
        assert client.vcs_type == "gitlab"

    def test_create_bitbucket(self) -> None:
        client = create_vcs_client("bitbucket", "bb-token")
        assert isinstance(client, BitbucketVCS)
        assert client.vcs_type == "bitbucket"

    def test_create_gitlab_custom_url(self) -> None:
        client = create_vcs_client("gitlab", "tok", base_url="https://gl.corp.com")
        assert isinstance(client, GitLabVCS)
        assert "gl.corp.com" in client._base

    def test_create_bitbucket_custom_url(self) -> None:
        client = create_vcs_client("bitbucket", "tok", base_url="https://bb.corp.com")
        assert isinstance(client, BitbucketVCS)
        assert "bb.corp.com" in client._base

    def test_unsupported_type_raises(self) -> None:
        with pytest.raises(ValueError, match="Unsupported VCS type"):
            create_vcs_client("github", "tok")

    def test_case_insensitive(self) -> None:
        client = create_vcs_client("GitLab", "tok")
        assert isinstance(client, GitLabVCS)

    def test_whitespace_stripped(self) -> None:
        client = create_vcs_client("  bitbucket  ", "tok")
        assert isinstance(client, BitbucketVCS)


# ---------------------------------------------------------------------------
# VCS models tests
# ---------------------------------------------------------------------------


class TestVCSModels:
    """Tests for VCS data models."""

    def test_commit_status_values(self) -> None:
        assert CommitStatus.pending == "pending"
        assert CommitStatus.success == "success"
        assert CommitStatus.failed == "failed"

    def test_mr_info_defaults(self) -> None:
        mr = MRInfo(id=1, title="test")
        assert mr.state == "open"
        assert mr.modified_files == []
        assert mr.sha == ""

    def test_vcs_config(self) -> None:
        cfg = VCSConfig(vcs_type="gitlab", token="t", base_url="https://gl.com")
        assert cfg.timeout == 15

    def test_status_result(self) -> None:
        r = StatusResult(ok=True)
        assert r.detail == ""

    def test_comment_result(self) -> None:
        r = CommentResult(ok=True, comment_id="123")
        assert r.comment_id == "123"


# ---------------------------------------------------------------------------
# GitLab VCS tests
# ---------------------------------------------------------------------------


class TestGitLabVCS:
    """Tests for GitLab VCS provider."""

    def _make_client(self) -> GitLabVCS:
        config = VCSConfig(
            vcs_type="gitlab", token="glpat-test", base_url="https://gitlab.example.com"
        )
        return GitLabVCS(config)

    def test_base_url(self) -> None:
        client = self._make_client()
        assert client._base == "https://gitlab.example.com/api/v4"

    def test_base_url_trailing_slash(self) -> None:
        config = VCSConfig(vcs_type="gitlab", token="t", base_url="https://gl.com/")
        client = GitLabVCS(config)
        assert client._base == "https://gl.com/api/v4"

    def test_headers(self) -> None:
        client = self._make_client()
        h = client._headers()
        assert h["PRIVATE-TOKEN"] == "glpat-test"
        assert h["Content-Type"] == "application/json"

    def test_project_id_encoding(self) -> None:
        client = self._make_client()
        assert client._project_id("user/repo") == "user%2Frepo"

    @pytest.mark.asyncio()
    async def test_get_merge_request(self) -> None:
        client = self._make_client()
        mr_data = {
            "iid": 42,
            "title": "Fix bug",
            "description": "Fixes #1",
            "state": "opened",
            "source_branch": "fix",
            "target_branch": "main",
            "author": {"username": "dev"},
            "web_url": "https://gl.com/mr/42",
            "sha": "abc123",
        }
        changes_data = {"changes": [{"new_path": "a.py"}, {"new_path": "b.py"}]}
        with patch.object(client, "_async_request", side_effect=[mr_data, changes_data]):
            mr = await client.get_merge_request("user/repo", 42)
        assert mr.id == 42
        assert mr.title == "Fix bug"
        assert mr.author == "dev"
        assert len(mr.modified_files) == 2

    @pytest.mark.asyncio()
    async def test_get_merge_request_not_found(self) -> None:
        client = self._make_client()
        with patch.object(client, "_async_request", return_value=None):
            mr = await client.get_merge_request("user/repo", 999)
        assert mr.title == ""
        assert mr.state == "unknown"

    @pytest.mark.asyncio()
    async def test_list_modified_files(self) -> None:
        client = self._make_client()
        data = {"changes": [{"new_path": "x.py"}, {"old_path": "deleted.py"}]}
        with patch.object(client, "_async_request", return_value=data):
            files = await client.list_modified_files("user/repo", 1)
        assert files == ["x.py", "deleted.py"]

    @pytest.mark.asyncio()
    async def test_list_modified_files_empty(self) -> None:
        client = self._make_client()
        with patch.object(client, "_async_request", return_value=None):
            files = await client.list_modified_files("user/repo", 1)
        assert files == []

    @pytest.mark.asyncio()
    async def test_post_comment(self) -> None:
        client = self._make_client()
        with patch.object(client, "_async_request", return_value={"id": 555}):
            result = await client.post_comment("user/repo", 1, "LGTM")
        assert result.ok is True
        assert result.comment_id == "555"

    @pytest.mark.asyncio()
    async def test_post_comment_failure(self) -> None:
        client = self._make_client()
        with patch.object(client, "_async_request", return_value=None):
            result = await client.post_comment("user/repo", 1, "text")
        assert result.ok is False

    @pytest.mark.asyncio()
    async def test_set_status(self) -> None:
        client = self._make_client()
        with patch.object(client, "_async_request", return_value={"id": 1}):
            result = await client.set_status(
                "user/repo", "abc123", CommitStatus.success, "All good"
            )
        assert result.ok is True

    @pytest.mark.asyncio()
    async def test_set_status_failure(self) -> None:
        client = self._make_client()
        with patch.object(client, "_async_request", return_value=None):
            result = await client.set_status("user/repo", "abc", CommitStatus.pending)
        assert result.ok is False

    @pytest.mark.asyncio()
    async def test_get_file_content(self) -> None:
        client = self._make_client()
        with patch.object(client, "_async_request", return_value="file content"):
            content = await client.get_file_content("user/repo", "README.md")
        assert content == "file content"

    @pytest.mark.asyncio()
    async def test_get_file_content_not_found(self) -> None:
        client = self._make_client()
        with patch.object(client, "_async_request", return_value=None):
            content = await client.get_file_content("user/repo", "missing.txt")
        assert content is None

    # -- _request / _async_request (HTTP layer) ----------------------------

    def test_request_success(self) -> None:
        """_request returns parsed JSON on HTTP 200."""
        import urllib.request

        client = self._make_client()
        response_body = json.dumps({"id": 1}).encode()

        fake_resp = MagicMock()
        fake_resp.__enter__ = MagicMock(return_value=fake_resp)
        fake_resp.__exit__ = MagicMock(return_value=False)
        fake_resp.read.return_value = response_body

        with patch.object(urllib.request, "urlopen", return_value=fake_resp):
            result = client._request("GET", "/projects/1/merge_requests/1")

        assert result == {"id": 1}

    def test_request_http_error_returns_none(self) -> None:
        """_request returns None and logs on HTTPError."""
        import urllib.error
        import urllib.request

        client = self._make_client()
        exc = urllib.error.HTTPError(
            url="http://x", code=404, msg="Not Found", hdrs=MagicMock(), fp=None
        )
        with patch.object(urllib.request, "urlopen", side_effect=exc):
            result = client._request("GET", "/projects/x/merge_requests/1")

        assert result is None

    def test_request_http_error_with_body_returns_none(self) -> None:
        """_request reads error body when fp is available."""
        import urllib.error
        import urllib.request

        client = self._make_client()
        fp = MagicMock()
        fp.read.return_value = b"Not found detail"
        exc = urllib.error.HTTPError(
            url="http://x", code=404, msg="Not Found", hdrs=MagicMock(), fp=fp
        )
        with patch.object(urllib.request, "urlopen", side_effect=exc):
            result = client._request("POST", "/bad/path", {"key": "val"})

        assert result is None

    @pytest.mark.asyncio()
    async def test_async_request_delegates_to_request(self) -> None:
        """_async_request calls _request via asyncio.to_thread."""
        client = self._make_client()
        with patch.object(client, "_request", return_value={"ok": True}) as mock_req:
            result = await client._async_request("GET", "/projects/1/merge_requests/1")

        mock_req.assert_called_once_with("GET", "/projects/1/merge_requests/1", None)
        assert result == {"ok": True}

    # -- set_status with target_url ----------------------------------------

    @pytest.mark.asyncio()
    async def test_set_status_with_target_url(self) -> None:
        """set_status includes target_url in payload when provided."""
        client = self._make_client()
        with patch.object(client, "_async_request", return_value={"id": 1}) as mock_req:
            result = await client.set_status(
                "user/repo",
                "sha123",
                CommitStatus.success,
                description="All green",
                target_url="https://ci.example.com/builds/1",
            )

        assert result.ok is True
        payload = mock_req.call_args[0][2]
        assert payload["target_url"] == "https://ci.example.com/builds/1"
        assert payload["description"] == "All green"

    @pytest.mark.asyncio()
    async def test_set_status_without_target_url(self) -> None:
        """set_status omits target_url key when not provided."""
        client = self._make_client()
        with patch.object(client, "_async_request", return_value={"id": 1}) as mock_req:
            await client.set_status("user/repo", "sha", CommitStatus.pending)

        payload = mock_req.call_args[0][2]
        assert "target_url" not in payload

    # -- get_file_content_raw ----------------------------------------------

    @pytest.mark.asyncio()
    async def test_get_file_content_raw_success(self) -> None:
        """get_file_content_raw returns raw text content."""
        import urllib.request

        client = self._make_client()
        fake_resp = MagicMock()
        fake_resp.__enter__ = MagicMock(return_value=fake_resp)
        fake_resp.__exit__ = MagicMock(return_value=False)
        fake_resp.read.return_value = b"raw file content"

        with patch.object(urllib.request, "urlopen", return_value=fake_resp):
            content = await client.get_file_content_raw("user/repo", "README.md", ref="main")

        assert content == "raw file content"

    @pytest.mark.asyncio()
    async def test_get_file_content_raw_http_error_returns_none(self) -> None:
        """get_file_content_raw returns None on HTTPError."""
        import urllib.error
        import urllib.request

        client = self._make_client()
        exc = urllib.error.HTTPError(
            url="http://x", code=404, msg="Not Found", hdrs=MagicMock(), fp=None
        )
        with patch.object(urllib.request, "urlopen", side_effect=exc):
            content = await client.get_file_content_raw("user/repo", "missing.txt")

        assert content is None

    @pytest.mark.asyncio()
    async def test_get_file_content_raw_url_encoding(self) -> None:
        """get_file_content_raw URL-encodes the file path."""
        import urllib.request

        client = self._make_client()
        fake_resp = MagicMock()
        fake_resp.__enter__ = MagicMock(return_value=fake_resp)
        fake_resp.__exit__ = MagicMock(return_value=False)
        fake_resp.read.return_value = b"content"

        with patch.object(urllib.request, "urlopen", return_value=fake_resp) as mock_open:
            await client.get_file_content_raw("user/repo", "src/deep/file.py")

        url = mock_open.call_args[0][0].full_url
        assert "src%2Fdeep%2Ffile.py" in url


# ---------------------------------------------------------------------------
# Bitbucket VCS tests
# ---------------------------------------------------------------------------


class TestBitbucketVCS:
    """Tests for Bitbucket VCS provider."""

    def _make_client(self) -> BitbucketVCS:
        config = VCSConfig(
            vcs_type="bitbucket", token="bb-tok", base_url="https://api.bitbucket.org/2.0"
        )
        return BitbucketVCS(config)

    def test_base_url(self) -> None:
        client = self._make_client()
        assert client._base == "https://api.bitbucket.org/2.0"

    def test_headers(self) -> None:
        client = self._make_client()
        h = client._headers()
        assert h["Authorization"] == "Bearer bb-tok"

    @pytest.mark.asyncio()
    async def test_get_merge_request(self) -> None:
        client = self._make_client()
        pr_data = {
            "id": 10,
            "title": "Add feature",
            "description": "New thing",
            "state": "OPEN",
            "source": {"branch": {"name": "feat"}, "commit": {"hash": "def456"}},
            "destination": {"branch": {"name": "main"}},
            "author": {"display_name": "Alice", "nickname": "alice"},
            "links": {"html": {"href": "https://bb.org/pr/10"}},
        }
        diffstat = {"values": [{"new": {"path": "c.py"}}, {"new": {"path": "d.py"}}]}
        with patch.object(client, "_async_request", side_effect=[pr_data, diffstat]):
            mr = await client.get_merge_request("team/repo", 10)
        assert mr.id == 10
        assert mr.source_branch == "feat"
        assert mr.author == "Alice"
        assert len(mr.modified_files) == 2

    @pytest.mark.asyncio()
    async def test_get_merge_request_not_found(self) -> None:
        client = self._make_client()
        with patch.object(client, "_async_request", return_value=None):
            mr = await client.get_merge_request("team/repo", 999)
        assert mr.state == "unknown"

    @pytest.mark.asyncio()
    async def test_list_modified_files(self) -> None:
        client = self._make_client()
        data = {"values": [{"new": {"path": "a.js"}}, {"old": {"path": "removed.js"}}]}
        with patch.object(client, "_async_request", return_value=data):
            files = await client.list_modified_files("team/repo", 5)
        assert "a.js" in files

    @pytest.mark.asyncio()
    async def test_post_comment(self) -> None:
        client = self._make_client()
        with patch.object(client, "_async_request", return_value={"id": 777}):
            result = await client.post_comment("team/repo", 5, "Nice work")
        assert result.ok is True
        assert result.comment_id == "777"

    @pytest.mark.asyncio()
    async def test_post_comment_failure(self) -> None:
        client = self._make_client()
        with patch.object(client, "_async_request", return_value=None):
            result = await client.post_comment("team/repo", 5, "text")
        assert result.ok is False

    @pytest.mark.asyncio()
    async def test_set_status(self) -> None:
        client = self._make_client()
        with patch.object(client, "_async_request", return_value={"state": "SUCCESSFUL"}):
            result = await client.set_status(
                "team/repo", "def456", CommitStatus.success, "2/2 passed"
            )
        assert result.ok is True

    @pytest.mark.asyncio()
    async def test_set_status_failure(self) -> None:
        client = self._make_client()
        with patch.object(client, "_async_request", return_value=None):
            result = await client.set_status("team/repo", "abc", CommitStatus.failed)
        assert result.ok is False

    @pytest.mark.asyncio()
    async def test_get_file_content(self) -> None:
        client = self._make_client()
        with patch.object(client, "_async_request", return_value="yaml content"):
            content = await client.get_file_content("team/repo", ".owlmind.yaml", "main")
        assert content == "yaml content"


# ---------------------------------------------------------------------------
# Reporter tests
# ---------------------------------------------------------------------------


class TestReporter:
    """Tests for the VCS result reporter."""

    def test_format_comment_success(self) -> None:
        goals = [
            {"goal": "Run tests", "status": "DONE"},
            {"goal": "Lint check", "status": "DONE"},
        ]
        md = format_result_comment("sess-001", goals, "DONE")
        assert "OWLMIND Review" in md
        assert "sess-001" in md
        assert "2/2" in md
        assert "Run tests" in md

    def test_format_comment_failure(self) -> None:
        goals = [
            {"goal": "Tests", "status": "DONE"},
            {"goal": "Security", "status": "FAILED"},
        ]
        md = format_result_comment("sess-002", goals, "FAILED")
        assert ":x:" in md
        assert "1/2" in md

    def test_format_comment_no_goals(self) -> None:
        md = format_result_comment("sess-003", [], "DONE")
        assert "No goals" in md

    @pytest.mark.asyncio()
    async def test_report_to_vcs(self) -> None:
        vcs = AsyncMock(spec=VCSProvider)
        vcs.post_comment.return_value = CommentResult(ok=True, comment_id="100")
        vcs.set_status.return_value = StatusResult(ok=True)

        goals = [{"goal": "Test", "status": "DONE"}]
        result = await report_to_vcs(vcs, "user/repo", 42, "sha123", "sess-1", goals, "DONE")
        assert result["comment_ok"] is True
        assert result["status_ok"] is True
        vcs.post_comment.assert_called_once()
        vcs.set_status.assert_called_once()

    @pytest.mark.asyncio()
    async def test_report_to_vcs_partial_failure(self) -> None:
        vcs = AsyncMock(spec=VCSProvider)
        vcs.post_comment.return_value = CommentResult(ok=True, comment_id="101")
        vcs.set_status.return_value = StatusResult(ok=False, detail="API error")

        result = await report_to_vcs(vcs, "user/repo", 42, "sha", "s-2", [], "FAILED")
        assert result["comment_ok"] is True
        assert result["status_ok"] is False
        assert "API error" in result["detail"]


# ---------------------------------------------------------------------------
# Webhook endpoint tests
# ---------------------------------------------------------------------------


@pytest.fixture()
def webhook_app(tmp_path: Path) -> TestClient:
    """Create a FastAPI app with webhook endpoints."""
    from owlmind.api.app import create_app

    app = create_app(
        runs_dir=tmp_path / "runs",
        ledger_dir=tmp_path / "ledger",
        queue_path=tmp_path / "queue",
        policies_dir=tmp_path / "policies",
        webhook_secret="test-secret",
    )
    return TestClient(app)


@pytest.fixture()
def webhook_app_no_secret(tmp_path: Path) -> TestClient:
    """Create a FastAPI app with webhook endpoints (no secret)."""
    from owlmind.api.app import create_app

    app = create_app(
        runs_dir=tmp_path / "runs",
        ledger_dir=tmp_path / "ledger",
        queue_path=tmp_path / "queue",
        policies_dir=tmp_path / "policies",
        webhook_secret="",
    )
    return TestClient(app)


class TestGitLabWebhook:
    """Tests for GitLab webhook endpoint."""

    def test_valid_mr_event(self, webhook_app_no_secret: TestClient) -> None:
        body = {
            "object_kind": "merge_request",
            "object_attributes": {
                "action": "open",
                "iid": 42,
                "title": "Fix bug",
                "source_branch": "fix-bug",
                "last_commit": {"id": "abc123"},
            },
            "project": {"path_with_namespace": "team/app"},
        }
        resp = webhook_app_no_secret.post("/api/v1/webhooks/gitlab", json=body)
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "accepted"
        assert data["vcs_type"] == "gitlab"
        assert data["mr_id"] == 42

    def test_ignored_event_type(self, webhook_app_no_secret: TestClient) -> None:
        body = {"object_kind": "push"}
        resp = webhook_app_no_secret.post("/api/v1/webhooks/gitlab", json=body)
        assert resp.status_code == 200
        assert resp.json()["status"] == "ignored"

    def test_ignored_action(self, webhook_app_no_secret: TestClient) -> None:
        body = {
            "object_kind": "merge_request",
            "object_attributes": {"action": "close"},
        }
        resp = webhook_app_no_secret.post("/api/v1/webhooks/gitlab", json=body)
        assert resp.status_code == 200
        assert resp.json()["status"] == "ignored"

    def test_valid_secret(self, webhook_app: TestClient) -> None:
        body = {
            "object_kind": "merge_request",
            "object_attributes": {
                "action": "update",
                "iid": 10,
                "title": "Update",
                "source_branch": "dev",
                "last_commit": {"id": "def456"},
            },
            "project": {"path_with_namespace": "org/repo"},
        }
        resp = webhook_app.post(
            "/api/v1/webhooks/gitlab",
            json=body,
            headers={"X-Gitlab-Token": "test-secret"},
        )
        assert resp.status_code == 200
        assert resp.json()["status"] == "accepted"

    def test_invalid_secret(self, webhook_app: TestClient) -> None:
        body = {"object_kind": "merge_request", "object_attributes": {"action": "open"}}
        resp = webhook_app.post(
            "/api/v1/webhooks/gitlab",
            json=body,
            headers={"X-Gitlab-Token": "wrong-secret"},
        )
        assert resp.status_code == 403

    def test_missing_secret(self, webhook_app: TestClient) -> None:
        body = {"object_kind": "merge_request", "object_attributes": {"action": "open"}}
        resp = webhook_app.post("/api/v1/webhooks/gitlab", json=body)
        assert resp.status_code == 403

    def test_reopen_action(self, webhook_app_no_secret: TestClient) -> None:
        body = {
            "object_kind": "merge_request",
            "object_attributes": {
                "action": "reopen",
                "iid": 5,
                "title": "Reopen",
                "source_branch": "fix",
                "last_commit": {"id": "sha5"},
            },
            "project": {"path_with_namespace": "a/b"},
        }
        resp = webhook_app_no_secret.post("/api/v1/webhooks/gitlab", json=body)
        assert resp.json()["action"] == "reopen"


class TestBitbucketWebhook:
    """Tests for Bitbucket webhook endpoint."""

    def test_valid_pr_created(self, webhook_app_no_secret: TestClient) -> None:
        body = {
            "pullrequest": {
                "id": 7,
                "title": "New feature",
                "source": {
                    "branch": {"name": "feat"},
                    "commit": {"hash": "aaa111"},
                },
            },
            "repository": {"full_name": "team/app"},
        }
        resp = webhook_app_no_secret.post(
            "/api/v1/webhooks/bitbucket",
            json=body,
            headers={"X-Event-Key": "pullrequest:created"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "accepted"
        assert data["vcs_type"] == "bitbucket"
        assert data["mr_id"] == 7

    def test_valid_pr_updated(self, webhook_app_no_secret: TestClient) -> None:
        body = {
            "pullrequest": {
                "id": 8,
                "title": "Updated",
                "source": {"branch": {"name": "dev"}, "commit": {"hash": "bbb222"}},
            },
            "repository": {"full_name": "team/lib"},
        }
        resp = webhook_app_no_secret.post(
            "/api/v1/webhooks/bitbucket",
            json=body,
            headers={"X-Event-Key": "pullrequest:updated"},
        )
        assert resp.json()["status"] == "accepted"

    def test_ignored_event(self, webhook_app_no_secret: TestClient) -> None:
        resp = webhook_app_no_secret.post(
            "/api/v1/webhooks/bitbucket",
            json={},
            headers={"X-Event-Key": "repo:push"},
        )
        assert resp.json()["status"] == "ignored"

    def test_ignored_pr_action(self, webhook_app_no_secret: TestClient) -> None:
        resp = webhook_app_no_secret.post(
            "/api/v1/webhooks/bitbucket",
            json={"pullrequest": {}},
            headers={"X-Event-Key": "pullrequest:rejected"},
        )
        assert resp.json()["status"] == "ignored"

    def test_valid_hmac_signature(self, webhook_app: TestClient) -> None:
        body = {
            "pullrequest": {
                "id": 9,
                "title": "Signed",
                "source": {"branch": {"name": "s"}, "commit": {"hash": "ccc"}},
            },
            "repository": {"full_name": "org/x"},
        }
        raw = json.dumps(body).encode()
        sig = "sha256=" + hmac.new(b"test-secret", raw, hashlib.sha256).hexdigest()
        resp = webhook_app.post(
            "/api/v1/webhooks/bitbucket",
            content=raw,
            headers={
                "X-Event-Key": "pullrequest:created",
                "X-Hub-Signature": sig,
                "Content-Type": "application/json",
            },
        )
        assert resp.status_code == 200
        assert resp.json()["status"] == "accepted"

    def test_invalid_hmac_signature(self, webhook_app: TestClient) -> None:
        body = {"pullrequest": {"id": 1}, "repository": {"full_name": "x/y"}}
        raw = json.dumps(body).encode()
        resp = webhook_app.post(
            "/api/v1/webhooks/bitbucket",
            content=raw,
            headers={
                "X-Event-Key": "pullrequest:created",
                "X-Hub-Signature": "sha256=invalid",
                "Content-Type": "application/json",
            },
        )
        assert resp.status_code == 403


# ---------------------------------------------------------------------------
# get_owlmind_config tests
# ---------------------------------------------------------------------------


class TestGetOwlMindConfig:
    """Tests for the get_owlmind_config convenience method."""

    @pytest.mark.asyncio()
    async def test_returns_parsed_yaml(self) -> None:
        client = create_vcs_client("gitlab", "tok")
        yaml_content = "goals:\n  - run tests\n  - lint\n"
        with patch.object(client, "get_file_content", return_value=yaml_content):
            config = await client.get_owlmind_config("user/repo", "main")
        assert config is not None
        assert config["goals"] == ["run tests", "lint"]

    @pytest.mark.asyncio()
    async def test_returns_none_when_missing(self) -> None:
        client = create_vcs_client("gitlab", "tok")
        with patch.object(client, "get_file_content", return_value=None):
            config = await client.get_owlmind_config("user/repo")
        assert config is None


# ---------------------------------------------------------------------------
# GitLab status mapping tests
# ---------------------------------------------------------------------------


class TestStatusMapping:
    """Tests for platform-specific status mappings."""

    def test_gitlab_status_map(self) -> None:
        from owlmind.integrations.vcs.gitlab import _GITLAB_STATUS_MAP

        assert _GITLAB_STATUS_MAP[CommitStatus.success] == "success"
        assert _GITLAB_STATUS_MAP[CommitStatus.cancelled] == "canceled"
        assert _GITLAB_STATUS_MAP[CommitStatus.running] == "running"

    def test_bitbucket_status_map(self) -> None:
        from owlmind.integrations.vcs.bitbucket import _BB_STATUS_MAP

        assert _BB_STATUS_MAP[CommitStatus.success] == "SUCCESSFUL"
        assert _BB_STATUS_MAP[CommitStatus.failed] == "FAILED"
        assert _BB_STATUS_MAP[CommitStatus.cancelled] == "STOPPED"
        assert _BB_STATUS_MAP[CommitStatus.pending] == "INPROGRESS"
