"""Tests for owlmind.graph — state, nodes, runner."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

from owlmind.graph.nodes import (
    ArchitectNode,
    CoderNode,
    ReviewerNode,
    TesterNode,
    _parse_file_blocks,
    _write_files_to_workspace,
)
from owlmind.graph.runner import GraphRunner
from owlmind.graph.state import GraphState, NodeResult, NodeStatus

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _mock_llm(text: str = "OK") -> MagicMock:
    """Return a mock OpenAI-compatible LLM client that always replies with *text*."""
    client = MagicMock()
    client.__class__.__module__ = "openai"
    choice = MagicMock()
    choice.message.content = text
    client.chat.completions.create.return_value = MagicMock(choices=[choice])
    client._owlmind_model = "test-model"
    return client


# ---------------------------------------------------------------------------
# GraphState
# ---------------------------------------------------------------------------


class TestGraphState:
    def test_defaults(self) -> None:
        state = GraphState(goal="test", workspace="/tmp")
        assert state.goal == "test"
        assert state.iteration == 0
        assert state.final_verdict == ""

    def test_add_result(self) -> None:
        state = GraphState(goal="g", workspace=".")
        result = NodeResult(node_name="n", status=NodeStatus.DONE, output="out")
        state.add_result(result)
        assert len(state.results) == 1
        assert state.get_last_result("n") is result

    def test_is_approved(self) -> None:
        state = GraphState(goal="g", workspace=".")
        state.final_verdict = "APPROVED"
        assert state.is_approved()

    def test_needs_fix(self) -> None:
        state = GraphState(goal="g", workspace=".")
        state.final_verdict = "NEEDS_FIX"
        assert state.needs_fix()

    def test_to_context_summary(self) -> None:
        state = GraphState(goal="do X", workspace=".")
        state.plan = "plan text"
        summary = state.to_context_summary()
        assert "do X" in summary
        assert "plan text" in summary


# ---------------------------------------------------------------------------
# NodeResult
# ---------------------------------------------------------------------------


class TestNodeResult:
    def test_done_status(self) -> None:
        r = NodeResult(node_name="arch", status=NodeStatus.DONE, output="plan")
        assert r.status == NodeStatus.DONE
        assert r.output == "plan"

    def test_failed_status(self) -> None:
        r = NodeResult(node_name="coder", status=NodeStatus.FAILED, error="boom")
        assert r.status == NodeStatus.FAILED
        assert r.error == "boom"


# ---------------------------------------------------------------------------
# _parse_file_blocks
# ---------------------------------------------------------------------------


class TestParseFileBlocks:
    def test_single_file(self) -> None:
        text = "## File: hello.py\n```python\nprint('hello')\n```\n"
        blocks = _parse_file_blocks(text)
        assert "hello.py" in blocks
        assert "print('hello')" in blocks["hello.py"]

    def test_multiple_files(self) -> None:
        text = (
            "## File: src/a.py\n```python\nx = 1\n```\n\n"
            "## File: tests/test_a.py\n```python\nassert True\n```\n"
        )
        blocks = _parse_file_blocks(text)
        assert len(blocks) == 2
        assert "src/a.py" in blocks
        assert "tests/test_a.py" in blocks

    def test_no_blocks(self) -> None:
        text = "Just some text with no file blocks."
        blocks = _parse_file_blocks(text)
        assert blocks == {}

    def test_extra_content_ignored(self) -> None:
        text = (
            "Here is my implementation:\n\n"
            "## File: main.py\n```python\ndef main(): pass\n```\n\n"
            "## Summary\nDone."
        )
        blocks = _parse_file_blocks(text)
        assert "main.py" in blocks
        assert "def main" in blocks["main.py"]


# ---------------------------------------------------------------------------
# _write_files_to_workspace
# ---------------------------------------------------------------------------


class TestWriteFilesToWorkspace:
    def test_writes_files(self, tmp_path: Path) -> None:
        files = {
            "src/hello.py": "def greet(): return 'hi'\n",
            "README.md": "# Hello\n",
        }
        written = _write_files_to_workspace(files, str(tmp_path))
        assert set(written) == {"src/hello.py", "README.md"}
        assert (tmp_path / "src" / "hello.py").read_text() == "def greet(): return 'hi'\n"

    def test_rejects_path_traversal(self, tmp_path: Path) -> None:
        files = {"../../etc/passwd": "evil"}
        written = _write_files_to_workspace(files, str(tmp_path))
        assert written == []  # silently skipped

    def test_creates_parent_dirs(self, tmp_path: Path) -> None:
        files = {"a/b/c/deep.py": "pass\n"}
        written = _write_files_to_workspace(files, str(tmp_path))
        assert "a/b/c/deep.py" in written
        assert (tmp_path / "a" / "b" / "c" / "deep.py").exists()


# ---------------------------------------------------------------------------
# ArchitectNode
# ---------------------------------------------------------------------------


class TestArchitectNode:
    def test_run_sets_plan(self) -> None:
        llm = _mock_llm("Step 1: Do X\nStep 2: Do Y")
        state = GraphState(goal="Build feature X", workspace=".")
        node = ArchitectNode("architect", llm)
        result = node.run(state)
        assert result.status == NodeStatus.DONE
        assert state.plan == "Step 1: Do X\nStep 2: Do Y"
        assert result.output == state.plan

    def test_run_fails_gracefully(self) -> None:
        llm = MagicMock()
        llm.__class__.__module__ = "openai"
        llm.chat.completions.create.side_effect = RuntimeError("API down")
        state = GraphState(goal="X", workspace=".")
        node = ArchitectNode("architect", llm)
        result = node.run(state)
        assert result.status == NodeStatus.FAILED
        assert result.error


# ---------------------------------------------------------------------------
# CoderNode
# ---------------------------------------------------------------------------


class TestCoderNode:
    def test_run_writes_files(self, tmp_path: Path) -> None:
        code_response = (
            "## File: hello.py\n```python\ndef greet():\n    return 'hi'\n```\n"
            "## Summary\nDone."
        )
        llm = _mock_llm(code_response)
        state = GraphState(goal="write hello.py", workspace=str(tmp_path))
        state.plan = "1. Write hello.py"
        node = CoderNode("coder", llm)
        # Force fallback to LLM path (no Claude CLI in unit tests)
        with patch("owlmind.worker.claude_cli_driver.ClaudeCLIDriver", side_effect=RuntimeError("no cli")):
            result = node.run(state)
        assert result.status == NodeStatus.DONE
        assert (tmp_path / "hello.py").exists()
        assert result.artifacts.get("file_count", 0) == 1

    def test_run_no_file_blocks(self, tmp_path: Path) -> None:
        llm = _mock_llm("I would change the code by doing X, Y, Z.")
        state = GraphState(goal="refactor", workspace=str(tmp_path))
        state.plan = "1. Refactor"
        node = CoderNode("coder", llm)
        with patch("owlmind.worker.claude_cli_driver.ClaudeCLIDriver", side_effect=RuntimeError("no cli")):
            result = node.run(state)
        assert result.status == NodeStatus.DONE
        assert result.artifacts.get("file_count", 0) == 0

    def test_run_fails_gracefully(self) -> None:
        llm = MagicMock()
        llm.__class__.__module__ = "openai"
        llm.chat.completions.create.side_effect = ValueError("bad")
        state = GraphState(goal="X", workspace=".")
        state.plan = "plan"
        node = CoderNode("coder", llm)
        with patch("owlmind.worker.claude_cli_driver.ClaudeCLIDriver", side_effect=RuntimeError("no cli")):
            result = node.run(state)
        assert result.status == NodeStatus.FAILED


# ---------------------------------------------------------------------------
# TesterNode
# ---------------------------------------------------------------------------


class TestTesterNode:
    def test_run_no_test_files(self, tmp_path: Path) -> None:
        llm = _mock_llm("## Test Summary\nPASS\n## Issues Found\nNone")
        state = GraphState(goal="g", workspace=str(tmp_path))
        state.code_changes = "wrote hello.py"
        node = TesterNode("tester", llm)
        result = node.run(state)
        assert result.status == NodeStatus.DONE
        test_out = result.artifacts.get("test_output", "")
        assert "No test files" in test_out or "pytest not found" in test_out or "not found" in test_out

    def test_run_with_passing_tests(self, tmp_path: Path) -> None:
        # Write a simple test that passes
        (tmp_path / "test_simple.py").write_text("def test_ok(): assert 1 + 1 == 2\n")
        llm = _mock_llm("## Test Summary\nPASS\n## Issues Found\nNone")
        state = GraphState(goal="g", workspace=str(tmp_path))
        state.code_changes = "wrote test_simple.py"
        node = TesterNode("tester", llm)
        result = node.run(state)
        assert result.status == NodeStatus.DONE
        # exit code 0 = all tests passed; 1/-1 = pytest not available in env
        assert result.artifacts.get("test_exit_code") in (0, 1, -1)

    def test_run_with_failing_tests(self, tmp_path: Path) -> None:
        (tmp_path / "test_fail.py").write_text("def test_bad(): assert 1 == 2\n")
        llm = _mock_llm("## Test Summary\nFAIL\n## Issues Found\nassert 1==2")
        state = GraphState(goal="g", workspace=str(tmp_path))
        state.code_changes = "wrote test_fail.py"
        node = TesterNode("tester", llm)
        result = node.run(state)
        assert result.status == NodeStatus.DONE
        # exit code 1 = tests failed; -1 = pytest not available
        assert result.artifacts.get("test_exit_code") in (1, -1)


# ---------------------------------------------------------------------------
# ReviewerNode
# ---------------------------------------------------------------------------


class TestReviewerNode:
    def test_approved_verdict(self) -> None:
        llm = _mock_llm("VERDICT: APPROVED\n\nREASON: Looks good.\n\nFIXES_NEEDED: N/A")
        state = GraphState(goal="g", workspace=".")
        state.plan = "plan"
        state.code_changes = "code"
        state.test_results = "PASS"
        node = ReviewerNode("reviewer", llm)
        result = node.run(state)
        assert result.status == NodeStatus.DONE
        assert state.final_verdict == "APPROVED"
        assert state.is_approved()

    def test_needs_fix_verdict(self) -> None:
        llm = _mock_llm("VERDICT: NEEDS_FIX\n\nREASON: Missing tests.\n\nFIXES_NEEDED: Add tests")
        state = GraphState(goal="g", workspace=".")
        state.plan = "plan"
        state.code_changes = "code"
        state.test_results = "FAIL"
        node = ReviewerNode("reviewer", llm)
        result = node.run(state)
        assert result.status == NodeStatus.DONE
        assert state.final_verdict == "NEEDS_FIX"
        assert state.needs_fix()

    def test_rejected_verdict(self) -> None:
        llm = _mock_llm("VERDICT: REJECTED\n\nREASON: Wrong approach.\n\nFIXES_NEEDED: Rethink")
        state = GraphState(goal="g", workspace=".")
        state.plan = "plan"
        state.code_changes = "code"
        state.test_results = ""
        node = ReviewerNode("reviewer", llm)
        node.run(state)
        assert state.final_verdict == "REJECTED"

    def test_unknown_verdict_defaults_to_needs_fix(self) -> None:
        llm = _mock_llm("The code is acceptable I think.")
        state = GraphState(goal="g", workspace=".")
        state.plan = "plan"
        state.code_changes = "code"
        state.test_results = ""
        node = ReviewerNode("reviewer", llm)
        node.run(state)
        assert state.final_verdict == "NEEDS_FIX"


# ---------------------------------------------------------------------------
# GraphRunner
# ---------------------------------------------------------------------------


class TestGraphRunner:
    def test_run_quick_returns_string(self, tmp_path: Path) -> None:
        plan_text = "1. Create hello.py"
        code_text = "## File: hello.py\n```python\nprint('hi')\n```\n"

        call_count = 0

        def side_effect(**kwargs: object) -> MagicMock:
            nonlocal call_count
            call_count += 1
            m = MagicMock()
            m.choices[0].message.content = plan_text if call_count == 1 else code_text
            return m

        llm = MagicMock()
        llm.__class__.__module__ = "openai"
        llm._owlmind_model = "test"
        llm.chat.completions.create.side_effect = side_effect

        runner = GraphRunner()
        runner._llm = llm
        out = runner.run_quick("create hello.py", workspace=str(tmp_path))
        assert out  # returns non-empty string

    def test_run_approved_on_first_iteration(self, tmp_path: Path) -> None:
        responses = [
            "Step 1: write hello.py",                        # architect
            "## File: hello.py\n```python\npass\n```\n",     # coder
            "## Test Summary\nPASS",                          # tester
            "VERDICT: APPROVED\n\nREASON: good.\n\nFIXES_NEEDED: N/A",  # reviewer
        ]
        call_count = 0

        def side_effect(**kwargs: object) -> MagicMock:
            nonlocal call_count
            resp = responses[min(call_count, len(responses) - 1)]
            call_count += 1
            m = MagicMock()
            m.choices[0].message.content = resp
            return m

        llm = MagicMock()
        llm.__class__.__module__ = "openai"
        llm._owlmind_model = "test"
        llm.chat.completions.create.side_effect = side_effect

        runner = GraphRunner()
        runner._llm = llm
        state = runner.run("write hello.py", workspace=str(tmp_path), max_iterations=3)
        assert state.final_verdict == "APPROVED"
        assert state.is_approved()
