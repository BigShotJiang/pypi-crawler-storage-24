"""Tests for owlmind.tools.code_rag."""
from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

from owlmind.tools.code_rag import CodeHit, CodeRAG, IndexStats

# ---------------------------------------------------------------------------
# CodeHit
# ---------------------------------------------------------------------------


class TestCodeHit:
    def test_fields(self) -> None:
        hit = CodeHit(
            file="src/foo.py",
            line_start=10,
            line_end=20,
            content="def foo(): pass",
            score=0.9,
            language="py",
            symbol="foo",
        )
        assert hit.file == "src/foo.py"
        assert hit.score == 0.9

    def test_defaults(self) -> None:
        hit = CodeHit(file="x.py", line_start=1, line_end=5, content="pass")
        assert hit.score == 0.0
        assert hit.language == ""
        assert hit.symbol == ""


# ---------------------------------------------------------------------------
# IndexStats
# ---------------------------------------------------------------------------


class TestIndexStats:
    def test_defaults(self) -> None:
        s = IndexStats()
        assert s.files_indexed == 0
        assert s.chunks_indexed == 0
        assert s.backend == "none"
        assert s.error == ""


# ---------------------------------------------------------------------------
# CodeRAG — index
# ---------------------------------------------------------------------------


class TestCodeRAGIndex:
    def test_index_tfidf_fallback(self, tmp_path: Path) -> None:
        """index() falls back to TF-IDF when Qdrant unavailable."""
        (tmp_path / "hello.py").write_text("def greet():\n    return 'hi'\n")
        rag = CodeRAG(workspace=tmp_path)

        # Patch _get_qdrant to return None (unavailable)
        with patch.object(rag, "_get_qdrant", return_value=None):
            stats = rag.index()

        assert stats.error == "" or stats.backend in ("tfidf", "none")
        assert stats.duration_ms >= 0

    def test_index_sets_indexed_flag(self, tmp_path: Path) -> None:
        """index() sets _indexed=True on success."""
        (tmp_path / "a.py").write_text("x = 1\n")
        rag = CodeRAG(workspace=tmp_path)
        with patch.object(rag, "_get_qdrant", return_value=None):
            rag.index()
        # Either indexed via TF-IDF or not, flag should reflect outcome
        assert isinstance(rag._indexed, bool)

    def test_index_qdrant_success(self, tmp_path: Path) -> None:
        """index() uses Qdrant when available."""
        mock_qdrant = MagicMock()
        mock_qdrant.index_workspace.return_value = {"files": 3, "chunks": 10}
        mock_qdrant.is_available.return_value = True

        rag = CodeRAG(workspace=tmp_path)
        with patch.object(rag, "_get_qdrant", return_value=mock_qdrant):
            stats = rag.index()

        assert stats.backend == "qdrant"
        assert stats.files_indexed == 3
        assert stats.chunks_indexed == 10

    def test_index_returns_error_stats_on_total_failure(self, tmp_path: Path) -> None:
        """index() returns IndexStats with error when everything fails."""
        rag = CodeRAG(workspace=tmp_path)
        with patch.object(rag, "_get_qdrant", return_value=None):
            with patch.object(rag, "_get_store", return_value=None):
                with patch.object(rag, "_build_chunks", side_effect=RuntimeError("boom")):
                    stats = rag.index()
        assert stats.error != "" or stats.backend == "none"


# ---------------------------------------------------------------------------
# CodeRAG — search
# ---------------------------------------------------------------------------


class TestCodeRAGSearch:
    def test_search_grep_fallback(self, tmp_path: Path) -> None:
        """search() falls back to grep when other backends unavailable."""
        (tmp_path / "main.py").write_text("def authenticate(user): pass\n")
        rag = CodeRAG(workspace=tmp_path)
        rag._indexed = True  # Skip auto-index

        with patch.object(rag, "_get_qdrant", return_value=None):
            with patch.object(rag, "_get_store", return_value=None):
                hits = rag.search("authenticate", top_k=5)

        assert isinstance(hits, list)
        if hits:
            assert isinstance(hits[0], CodeHit)
            assert hits[0].file.endswith(".py")

    def test_search_triggers_index_if_not_indexed(self, tmp_path: Path) -> None:
        """search() calls index() automatically on first call."""
        (tmp_path / "x.py").write_text("pass\n")
        rag = CodeRAG(workspace=tmp_path)
        assert not rag._indexed

        with patch.object(rag, "index", wraps=rag.index) as mock_index:
            with patch.object(rag, "_get_qdrant", return_value=None):
                with patch.object(rag, "_get_store", return_value=None):
                    rag.search("pass")
        mock_index.assert_called_once()

    def test_search_qdrant_success(self, tmp_path: Path) -> None:
        """search() returns CodeHit list from Qdrant results."""
        mock_qdrant = MagicMock()
        mock_qdrant.search.return_value = [
            {
                "file_path": "src/auth.py",
                "start_line": 5,
                "end_line": 15,
                "content": "def login(): ...",
                "score": 0.95,
                "language": "py",
                "symbol": "login",
            }
        ]

        rag = CodeRAG(workspace=tmp_path)
        rag._indexed = True
        with patch.object(rag, "_get_qdrant", return_value=mock_qdrant):
            hits = rag.search("login", top_k=3)

        assert len(hits) == 1
        assert hits[0].file == "src/auth.py"
        assert hits[0].score == 0.95
        assert hits[0].symbol == "login"

    def test_search_returns_empty_list_on_failure(self, tmp_path: Path) -> None:
        """search() returns [] when grep finds nothing."""
        (tmp_path / "empty.py").write_text("# nothing here\n")
        rag = CodeRAG(workspace=tmp_path)
        rag._indexed = True

        with patch.object(rag, "_get_qdrant", return_value=None):
            with patch.object(rag, "_get_store", return_value=None):
                hits = rag.search("xyzzy_not_found_anywhere_12345")

        assert hits == []


# ---------------------------------------------------------------------------
# CodeRAG — context_for / search_and_format
# ---------------------------------------------------------------------------


class TestCodeRAGFormatting:
    def test_context_for_empty(self) -> None:
        rag = CodeRAG()
        assert rag.context_for([]) == ""

    def test_context_for_formats_hits(self) -> None:
        rag = CodeRAG()
        hits = [
            CodeHit(
                file="foo.py",
                line_start=1,
                line_end=5,
                content="def foo(): pass",
                score=1.0,
                language="py",
                symbol="foo",
            )
        ]
        ctx = rag.context_for(hits)
        assert "foo.py" in ctx
        assert "foo" in ctx
        assert "def foo" in ctx

    def test_context_for_respects_max_chars(self) -> None:
        rag = CodeRAG()
        hits = [
            CodeHit(
                file=f"file{i}.py",
                line_start=1,
                line_end=10,
                content="x" * 500,
                score=1.0,
            )
            for i in range(20)
        ]
        ctx = rag.context_for(hits, max_chars=1000)
        assert len(ctx) <= 1100  # some slack for header

    def test_search_and_format_returns_string(self, tmp_path: Path) -> None:
        rag = CodeRAG(workspace=tmp_path)
        rag._indexed = True
        with patch.object(rag, "_get_qdrant", return_value=None):
            with patch.object(rag, "_get_store", return_value=None):
                result = rag.search_and_format("anything")
        assert isinstance(result, str)

    def test_is_available(self) -> None:
        rag = CodeRAG()
        assert rag.is_available() is True  # grep always available

    def test_backend_returns_string(self) -> None:
        rag = CodeRAG()
        with patch.object(rag, "_get_qdrant", return_value=None):
            with patch.object(rag, "_get_store", return_value=None):
                b = rag.backend()
        assert b == "grep"


# ---------------------------------------------------------------------------
# CodeRAG — _build_chunks
# ---------------------------------------------------------------------------


class TestCodeRAGBuildChunks:
    def test_chunks_py_file(self, tmp_path: Path) -> None:
        (tmp_path / "sample.py").write_text("def a(): pass\ndef b(): pass\n")
        rag = CodeRAG(workspace=tmp_path)
        with patch.object(rag, "_get_analyzer", return_value=None):
            chunks = rag._build_chunks()
        assert len(chunks) >= 1
        assert all("file" in c for c in chunks)
        assert all("text" in c for c in chunks)

    def test_skips_node_modules(self, tmp_path: Path) -> None:
        nm = tmp_path / "node_modules"
        nm.mkdir()
        (nm / "index.js").write_text("module.exports = {}")
        (tmp_path / "main.py").write_text("print('hi')")
        rag = CodeRAG(workspace=tmp_path)
        with patch.object(rag, "_get_analyzer", return_value=None):
            chunks = rag._build_chunks()
        files = {c["file"] for c in chunks}
        assert not any("node_modules" in f for f in files)

    def test_ignores_unknown_extensions(self, tmp_path: Path) -> None:
        (tmp_path / "data.csv").write_text("a,b,c")
        (tmp_path / "code.py").write_text("x = 1")
        rag = CodeRAG(workspace=tmp_path)
        with patch.object(rag, "_get_analyzer", return_value=None):
            chunks = rag._build_chunks()
        files = {c["file"] for c in chunks}
        assert not any(f.endswith(".csv") for f in files)
        assert any(f.endswith(".py") for f in files)
