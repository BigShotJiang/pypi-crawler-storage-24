"""Tests for task queue — add, list, run operations."""

from __future__ import annotations

from pathlib import Path

from owlmind.queue import QueueStatus, TaskQueue


class TestTaskQueue:
    def test_add_item(self, tmp_path: Path) -> None:
        q = TaskQueue(tmp_path / "queue")
        item = q.add(goal="Test goal", workspace="/tmp/ws")
        assert item.goal == "Test goal"
        assert item.workspace == "/tmp/ws"
        assert item.status == QueueStatus.PENDING
        assert item.id.startswith("task-")
        assert item.created_at != ""

    def test_list_items(self, tmp_path: Path) -> None:
        q = TaskQueue(tmp_path / "queue")
        q.add(goal="Task 1", workspace="/tmp")
        q.add(goal="Task 2", workspace="/tmp")
        items = q.list_items()
        assert len(items) == 2
        assert items[0].goal == "Task 1"
        assert items[1].goal == "Task 2"

    def test_list_items_filtered(self, tmp_path: Path) -> None:
        q = TaskQueue(tmp_path / "queue")
        item = q.add(goal="Task 1", workspace="/tmp")
        q.add(goal="Task 2", workspace="/tmp")
        q.mark_running(item.id, "run-123")

        pending = q.list_items(status=QueueStatus.PENDING)
        assert len(pending) == 1
        assert pending[0].goal == "Task 2"

        running = q.list_items(status=QueueStatus.RUNNING)
        assert len(running) == 1
        assert running[0].run_id == "run-123"

    def test_next_pending(self, tmp_path: Path) -> None:
        q = TaskQueue(tmp_path / "queue")
        assert q.next_pending() is None

        q.add(goal="First", workspace="/tmp")
        q.add(goal="Second", workspace="/tmp")

        item = q.next_pending()
        assert item is not None
        assert item.goal == "First"

    def test_mark_running(self, tmp_path: Path) -> None:
        q = TaskQueue(tmp_path / "queue")
        item = q.add(goal="Test", workspace="/tmp")
        q.mark_running(item.id, "run-abc")

        items = q.list_items()
        assert items[0].status == QueueStatus.RUNNING
        assert items[0].run_id == "run-abc"

    def test_mark_done(self, tmp_path: Path) -> None:
        q = TaskQueue(tmp_path / "queue")
        item = q.add(goal="Test", workspace="/tmp")
        q.mark_running(item.id, "run-abc")
        q.mark_done(item.id)

        items = q.list_items()
        assert items[0].status == QueueStatus.DONE

    def test_mark_failed(self, tmp_path: Path) -> None:
        q = TaskQueue(tmp_path / "queue")
        item = q.add(goal="Test", workspace="/tmp")
        q.mark_failed(item.id, "something broke")

        items = q.list_items()
        assert items[0].status == QueueStatus.FAILED
        assert items[0].error == "something broke"

    def test_sandbox_flag(self, tmp_path: Path) -> None:
        q = TaskQueue(tmp_path / "queue")
        item = q.add(goal="Test", workspace="/tmp", sandbox=True)
        assert item.sandbox is True

        items = q.list_items()
        assert items[0].sandbox is True

    def test_persistence(self, tmp_path: Path) -> None:
        queue_dir = tmp_path / "queue"
        q1 = TaskQueue(queue_dir)
        q1.add(goal="Persistent", workspace="/tmp")

        q2 = TaskQueue(queue_dir)
        items = q2.list_items()
        assert len(items) == 1
        assert items[0].goal == "Persistent"

    def test_empty_queue(self, tmp_path: Path) -> None:
        q = TaskQueue(tmp_path / "queue")
        assert q.list_items() == []
        assert q.next_pending() is None
