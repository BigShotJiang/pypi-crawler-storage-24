"""Tests for Goals Template Library."""

from __future__ import annotations

import pytest
import yaml

from owlmind.templates import get_template_info, list_templates, render_template


class TestListTemplates:
    def test_returns_sorted_names(self) -> None:
        names = list_templates()
        assert isinstance(names, list)
        assert len(names) >= 3
        assert names == sorted(names)

    def test_known_templates_present(self) -> None:
        names = list_templates()
        assert "pr_ci_release_dag" in names
        assert "hotfix_ci_dag" in names
        assert "docs_only_chain" in names


class TestGetTemplateInfo:
    def test_returns_description(self) -> None:
        desc = get_template_info("pr_ci_release_dag")
        assert "Plan" in desc
        assert "Release" in desc

    def test_unknown_raises(self) -> None:
        with pytest.raises(ValueError, match="Unknown template"):
            get_template_info("nonexistent_template")


class TestRenderTemplate:
    def test_renders_valid_yaml(self) -> None:
        result = render_template("pr_ci_release_dag")
        data = yaml.safe_load(result)
        assert data["version"] == 2
        assert "goals" in data
        assert "defaults" in data

    def test_custom_workspace(self) -> None:
        result = render_template("hotfix_ci_dag", workspace="/my/project")
        data = yaml.safe_load(result)
        assert data["defaults"]["workspace"] == "/my/project"

    def test_custom_defaults(self) -> None:
        result = render_template(
            "docs_only_chain",
            defaults={"max_steps": 50},
        )
        data = yaml.safe_load(result)
        assert data["defaults"]["max_steps"] == 50

    def test_goals_have_required_fields(self) -> None:
        for name in list_templates():
            result = render_template(name)
            data = yaml.safe_load(result)
            for goal in data["goals"]:
                assert "id" in goal
                assert "goal" in goal
                assert "depends_on" in goal

    def test_no_secrets_in_output(self) -> None:
        for name in list_templates():
            result = render_template(name)
            lower = result.lower()
            assert "api_key" not in lower
            assert "token" not in lower
            assert "secret" not in lower

    def test_unknown_template_raises(self) -> None:
        with pytest.raises(ValueError, match="Unknown template"):
            render_template("does_not_exist")

    def test_dag_dependencies_valid(self) -> None:
        """All depends_on references point to existing goal IDs."""
        for name in list_templates():
            result = render_template(name)
            data = yaml.safe_load(result)
            ids = {g["id"] for g in data["goals"]}
            for goal in data["goals"]:
                for dep in goal["depends_on"]:
                    assert dep in ids, f"{name}: {goal['id']} depends on unknown {dep}"
