"""Tests for /watch_start, /watch_stop, /watch_status Telegram handlers."""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch


def _make_update(chat_id: int = 123, args: list[str] | None = None) -> tuple[MagicMock, MagicMock]:
    update = MagicMock()
    context = MagicMock()
    update.message = MagicMock()
    update.message.chat_id = chat_id
    update.message.reply_text = AsyncMock()
    context.args = args or []
    return update, context


def _make_ctx(authorized: bool = True) -> MagicMock:
    ctx = MagicMock()
    ctx.check_auth.return_value = authorized
    ctx.workspace = "."
    return ctx


def _make_mock_scheduler() -> MagicMock:
    scheduler = MagicMock()
    scheduler.add_goal = MagicMock()
    scheduler.start = MagicMock()
    scheduler.stop = MagicMock()
    scheduler.status = MagicMock(return_value={
        "running": True,
        "queue_size": 1,
        "history_count": 2,
        "github_watchers": 0,
        "file_watchers": 0,
        "recent": [
            {"goal": "fix lint errors", "verdict": "APPROVED", "source": "telegram", "error": ""},
        ],
    })
    return scheduler


# ---------------------------------------------------------------------------
# /watch_start tests
# ---------------------------------------------------------------------------


def test_cmd_watch_start_basic() -> None:
    """watch_start with a valid goal creates scheduler and replies with confirmation."""
    from owlmind.telegram.handlers_graph import _schedulers, cmd_watch_start

    _schedulers.clear()
    update, context = _make_update(chat_id=123, args=["fix", "all", "lint", "errors"])
    ctx = _make_ctx(authorized=True)

    mock_scheduler = _make_mock_scheduler()

    with patch("owlmind.autonomous.AutonomousScheduler", return_value=mock_scheduler) as MockSched:
        asyncio.run(cmd_watch_start(ctx, update, context))

    MockSched.assert_called_once_with(workspace=".")
    mock_scheduler.add_goal.assert_called_once_with("fix all lint errors", source="telegram")
    mock_scheduler.start.assert_called_once_with(interval=300.0)
    assert _schedulers[123] is mock_scheduler

    reply_call = update.message.reply_text.call_args[0][0]
    assert "Scheduler started" in reply_call
    assert "fix all lint errors" in reply_call
    assert "300s" in reply_call

    _schedulers.clear()


def test_cmd_watch_start_with_interval_and_workspace() -> None:
    """watch_start respects --interval and --workspace flags."""
    from owlmind.telegram.handlers_graph import _schedulers, cmd_watch_start

    _schedulers.clear()
    update, context = _make_update(
        chat_id=200,
        args=["do", "something", "--interval", "60", "--workspace", "/tmp/proj"],
    )
    ctx = _make_ctx(authorized=True)

    mock_scheduler = _make_mock_scheduler()

    with patch("owlmind.autonomous.AutonomousScheduler", return_value=mock_scheduler) as MockSched:
        asyncio.run(cmd_watch_start(ctx, update, context))

    MockSched.assert_called_once_with(workspace="/tmp/proj")
    mock_scheduler.start.assert_called_once_with(interval=60.0)
    assert "60s" in update.message.reply_text.call_args[0][0]

    _schedulers.clear()


def test_cmd_watch_start_unauthorized() -> None:
    """watch_start rejects unauthorized users without creating a scheduler."""
    from owlmind.telegram.handlers_graph import _schedulers, cmd_watch_start

    _schedulers.clear()
    update, context = _make_update(chat_id=999, args=["some goal"])
    ctx = _make_ctx(authorized=False)

    with patch("owlmind.autonomous.AutonomousScheduler") as MockSched:
        asyncio.run(cmd_watch_start(ctx, update, context))

    MockSched.assert_not_called()
    reply = update.message.reply_text.call_args[0][0]
    assert "Not authorized" in reply or "authorized" in reply.lower()
    assert 999 not in _schedulers

    _schedulers.clear()


def test_cmd_watch_start_no_goal() -> None:
    """watch_start with no goal sends usage hint."""
    from owlmind.telegram.handlers_graph import _schedulers, cmd_watch_start

    _schedulers.clear()
    update, context = _make_update(chat_id=123, args=[])
    ctx = _make_ctx(authorized=True)

    with patch("owlmind.autonomous.AutonomousScheduler") as MockSched:
        asyncio.run(cmd_watch_start(ctx, update, context))

    MockSched.assert_not_called()
    reply = update.message.reply_text.call_args[0][0]
    assert "Usage" in reply

    _schedulers.clear()


def test_cmd_watch_start_stops_existing_scheduler() -> None:
    """watch_start stops an existing scheduler for the same chat_id before creating a new one."""
    from owlmind.telegram.handlers_graph import _schedulers, cmd_watch_start

    _schedulers.clear()
    old_scheduler = _make_mock_scheduler()
    _schedulers[123] = old_scheduler

    update, context = _make_update(chat_id=123, args=["new goal"])
    ctx = _make_ctx(authorized=True)

    new_scheduler = _make_mock_scheduler()

    with patch("owlmind.autonomous.AutonomousScheduler", return_value=new_scheduler):
        asyncio.run(cmd_watch_start(ctx, update, context))

    old_scheduler.stop.assert_called_once()
    assert _schedulers[123] is new_scheduler

    _schedulers.clear()


# ---------------------------------------------------------------------------
# /watch_stop tests
# ---------------------------------------------------------------------------


def test_cmd_watch_stop_running() -> None:
    """watch_stop stops an existing scheduler and removes it from the registry."""
    from owlmind.telegram.handlers_graph import _schedulers, cmd_watch_stop

    _schedulers.clear()
    mock_scheduler = _make_mock_scheduler()
    _schedulers[123] = mock_scheduler

    update, context = _make_update(chat_id=123)
    ctx = _make_ctx(authorized=True)

    asyncio.run(cmd_watch_stop(ctx, update, context))

    mock_scheduler.stop.assert_called_once()
    assert 123 not in _schedulers
    reply = update.message.reply_text.call_args[0][0]
    assert "stopped" in reply.lower()

    _schedulers.clear()


def test_cmd_watch_stop_none() -> None:
    """watch_stop when no scheduler exists replies with informative message."""
    from owlmind.telegram.handlers_graph import _schedulers, cmd_watch_stop

    _schedulers.clear()
    update, context = _make_update(chat_id=123)
    ctx = _make_ctx(authorized=True)

    asyncio.run(cmd_watch_stop(ctx, update, context))

    reply = update.message.reply_text.call_args[0][0]
    assert "No scheduler" in reply

    _schedulers.clear()


def test_cmd_watch_stop_unauthorized() -> None:
    """watch_stop rejects unauthorized users."""
    from owlmind.telegram.handlers_graph import _schedulers, cmd_watch_stop

    _schedulers.clear()
    mock_scheduler = _make_mock_scheduler()
    _schedulers[123] = mock_scheduler

    update, context = _make_update(chat_id=123)
    ctx = _make_ctx(authorized=False)

    asyncio.run(cmd_watch_stop(ctx, update, context))

    mock_scheduler.stop.assert_not_called()
    assert 123 in _schedulers  # scheduler remains
    reply = update.message.reply_text.call_args[0][0]
    assert "authorized" in reply.lower()

    _schedulers.clear()


# ---------------------------------------------------------------------------
# /watch_status tests
# ---------------------------------------------------------------------------


def test_cmd_watch_status() -> None:
    """watch_status formats and replies with scheduler status."""
    from owlmind.telegram.handlers_graph import _schedulers, cmd_watch_status

    _schedulers.clear()
    mock_scheduler = _make_mock_scheduler()
    _schedulers[123] = mock_scheduler

    update, context = _make_update(chat_id=123)
    ctx = _make_ctx(authorized=True)

    asyncio.run(cmd_watch_status(ctx, update, context))

    mock_scheduler.status.assert_called_once()
    reply = update.message.reply_text.call_args[0][0]
    assert "Running" in reply
    assert "Queue" in reply
    assert "History" in reply
    assert "fix lint errors" in reply
    assert "APPROVED" in reply

    _schedulers.clear()


def test_cmd_watch_status_no_scheduler() -> None:
    """watch_status when no scheduler exists replies with informative message."""
    from owlmind.telegram.handlers_graph import _schedulers, cmd_watch_status

    _schedulers.clear()
    update, context = _make_update(chat_id=123)
    ctx = _make_ctx(authorized=True)

    asyncio.run(cmd_watch_status(ctx, update, context))

    reply = update.message.reply_text.call_args[0][0]
    assert "No scheduler" in reply

    _schedulers.clear()


def test_cmd_watch_status_unauthorized() -> None:
    """watch_status rejects unauthorized users."""
    from owlmind.telegram.handlers_graph import _schedulers, cmd_watch_status

    _schedulers.clear()
    mock_scheduler = _make_mock_scheduler()
    _schedulers[123] = mock_scheduler

    update, context = _make_update(chat_id=123)
    ctx = _make_ctx(authorized=False)

    asyncio.run(cmd_watch_status(ctx, update, context))

    mock_scheduler.status.assert_not_called()
    reply = update.message.reply_text.call_args[0][0]
    assert "authorized" in reply.lower()

    _schedulers.clear()
