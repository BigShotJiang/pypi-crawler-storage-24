"""Integration tests for LLM router with CycleManager — NO network calls."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from owlmind.agent.cycle import CycleManager
from owlmind.budget import BudgetGovernor
from owlmind.config import BudgetConfig, PricingConfig
from owlmind.evidence import EvidenceStore
from owlmind.ledger import UsageLedger
from owlmind.llm.router import LLMRouter
from owlmind.policy import PolicyEngine


class FakeDriverForRouter:
    """Fake LLM driver that returns usage metadata — for router integration."""

    def __init__(self, provider_name: str, planner_response: dict[str, Any] | None = None) -> None:
        self._name = provider_name
        self._planner_response = planner_response or {}
        self.plan_calls: list[dict[str, Any]] = []

    @property
    def name(self) -> str:
        return self._name

    @property
    def supports_structured(self) -> bool:
        return True

    def plan(
        self,
        planner_request: dict[str, Any],
        schema: dict[str, Any],
        **kwargs: Any,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        self.plan_calls.append(planner_request)
        meta = {
            "provider": self._name,
            "model": f"{self._name}-model",
            "response_id": f"fake-{self._name}",
            "latency_ms": 100,
            "usage": {"input_tokens": 500, "output_tokens": 200, "total_tokens": 700},
        }
        return self._planner_response, meta

    def judge(
        self,
        judge_request: dict[str, Any],
        schema: dict[str, Any],
        **kwargs: Any,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        return {}, {
            "provider": self._name,
            "model": f"{self._name}-model",
            "latency_ms": 50,
            "usage": {},
        }


def _make_setup(
    tmp_path: Path,
    *,
    providers: list[str] | None = None,
    planner_resp: dict[str, Any] | None = None,
) -> tuple[CycleManager, dict[str, FakeDriverForRouter], UsageLedger]:
    policies_dir = tmp_path / "policies"
    policies_dir.mkdir()
    (policies_dir / "allowlist.yaml").write_text('allowed_commands:\n  - "^echo "\n  - "^pytest"\n')
    (policies_dir / "policy.yaml").write_text('forbidden_patterns:\n  - "rm -rf"\n')

    policy = PolicyEngine.from_directory(policies_dir)
    evidence = EvidenceStore(tmp_path / "runs")
    ledger = UsageLedger(tmp_path / "ledger")

    budget = BudgetConfig()
    pricing = PricingConfig()
    governor = BudgetGovernor(budget, pricing, ledger)

    provider_names = providers or ["openai", "anthropic"]
    drivers: dict[str, FakeDriverForRouter] = {}
    for p in provider_names:
        drivers[p] = FakeDriverForRouter(p, planner_response=planner_resp)

    router = LLMRouter(
        drivers=drivers,
        planner_providers=provider_names,
        judge_providers=provider_names,
    )

    mgr = CycleManager(
        evidence=evidence,
        policy=policy,
        policies_dir=policies_dir,
        llm_driver=router,
        budget_governor=governor,
        ledger=ledger,
    )
    return mgr, drivers, ledger


class TestRouterIntegrationPlanner:
    def test_routes_to_first_provider(self, tmp_path: Path) -> None:
        planner_resp = {
            "run_id": "x",
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        mgr, drivers, ledger = _make_setup(
            tmp_path,
            providers=["openai", "anthropic"],
            planner_resp=planner_resp,
        )

        meta = mgr.start(goal="Router test", workspace=str(tmp_path))
        planner_resp["run_id"] = meta.run_id
        for d in drivers.values():
            d._planner_response = planner_resp

        mgr.run_planner_llm(meta.run_id)

        # First provider (openai) should have been called
        assert len(drivers["openai"].plan_calls) == 1
        assert len(drivers["anthropic"].plan_calls) == 0

        # Ledger should record with correct provider
        entries = ledger._read_all()
        assert len(entries) == 1
        assert entries[0].provider == "openai"

    def test_records_usage_with_provider_pricing(self, tmp_path: Path) -> None:
        planner_resp = {
            "run_id": "x",
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        mgr, drivers, ledger = _make_setup(
            tmp_path,
            providers=["anthropic"],
            planner_resp=planner_resp,
        )

        meta = mgr.start(goal="Pricing test", workspace=str(tmp_path))
        planner_resp["run_id"] = meta.run_id
        drivers["anthropic"]._planner_response = planner_resp

        mgr.run_planner_llm(meta.run_id)

        entries = ledger._read_all()
        assert len(entries) == 1
        assert entries[0].provider == "anthropic"
        # Should have used anthropic pricing
        assert entries[0].price_per_1k_input == 0.003

    def test_fallback_records_correct_provider(self, tmp_path: Path) -> None:
        planner_resp = {
            "run_id": "x",
            "iteration": 1,
            "plan_summary": ["Step 1"],
            "worker_instructions": "Do it",
            "verify_commands": ["echo ok"],
            "risk_notes": [],
        }
        # Create drivers manually — openai fails, anthropic succeeds
        policies_dir = tmp_path / "policies"
        policies_dir.mkdir()
        (policies_dir / "allowlist.yaml").write_text(
            'allowed_commands:\n  - "^echo "\n  - "^pytest"\n'
        )
        (policies_dir / "policy.yaml").write_text('forbidden_patterns:\n  - "rm -rf"\n')

        policy = PolicyEngine.from_directory(policies_dir)
        evidence = EvidenceStore(tmp_path / "runs")
        ledger = UsageLedger(tmp_path / "ledger")
        governor = BudgetGovernor(BudgetConfig(), PricingConfig(), ledger)

        class FailingDriver:
            name = "openai"
            supports_structured = True

            def plan(self, req: Any, schema: Any) -> tuple[Any, Any]:
                raise RuntimeError("Connection timeout")

            def judge(self, req: Any, schema: Any) -> tuple[Any, Any]:
                raise RuntimeError("Connection timeout")

        ok_driver = FakeDriverForRouter("anthropic", planner_response=planner_resp)

        router = LLMRouter(
            drivers={"openai": FailingDriver(), "anthropic": ok_driver},
            planner_providers=["openai", "anthropic"],
            judge_providers=["openai", "anthropic"],
        )

        mgr = CycleManager(
            evidence=evidence,
            policy=policy,
            policies_dir=policies_dir,
            llm_driver=router,
            budget_governor=governor,
            ledger=ledger,
        )

        meta = mgr.start(goal="Fallback test", workspace=str(tmp_path))
        planner_resp["run_id"] = meta.run_id
        ok_driver._planner_response = planner_resp

        mgr.run_planner_llm(meta.run_id)

        # Should have fallen back to anthropic
        entries = ledger._read_all()
        assert len(entries) == 1
        assert entries[0].provider == "anthropic"

        # Evidence should show the routing
        events = evidence.read_events(meta.run_id)
        llm_events = [e for e in events if e.get("event") == "LLM_PLANNER_CALLED"]
        assert len(llm_events) == 1
