"""Tests for graceful degradation in QdrantMemoryStore and build_hybrid_memory_context.

Covers the case where Qdrant is unavailable (connection failure, runtime error,
missing dependencies) and ensures TF-IDF fallback is used and warnings are logged.
"""

from __future__ import annotations

import contextlib
import logging
import types
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from owlmind.memory.qdrant_retrieval import (
    QdrantMemoryStore,
    VectorSearchResult,
    build_hybrid_memory_context,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_store(**kwargs: Any) -> QdrantMemoryStore:
    """Create a QdrantMemoryStore without triggering real connections."""
    store = QdrantMemoryStore.__new__(QdrantMemoryStore)
    store._url = "http://localhost:6333"
    store._collection = "test_collection"
    store._api_key = ""
    store._client = None
    store._embedder = None
    store._available = None
    for k, v in kwargs.items():
        setattr(store, k, v)
    return store


def _inject_fake_qdrant_client(side_effect: Exception | None = None) -> MagicMock:
    """Return a mock QdrantClient class that raises side_effect on instantiation."""
    mock_cls = MagicMock()
    if side_effect is not None:
        mock_cls.side_effect = side_effect
    else:
        instance = MagicMock()
        instance.get_collections.return_value = MagicMock(collections=[])
        mock_cls.return_value = instance
    return mock_cls


def _patch_qdrant_client(
    mod: types.ModuleType,
    side_effect: Exception,
) -> tuple[Any, MagicMock]:
    """Temporarily inject a failing QdrantClient into module namespace.

    Returns (original_value_or_None, mock_cls).
    Caller is responsible for restoring the original via _restore_qdrant_client().
    """
    original = getattr(mod, "QdrantClient", None)
    mock_cls = _inject_fake_qdrant_client(side_effect=side_effect)
    mod.QdrantClient = mock_cls  # type: ignore[attr-defined]
    return original, mock_cls


def _restore_qdrant_client(mod: types.ModuleType, original: Any) -> None:
    """Restore QdrantClient on the module after a test."""
    if original is None:
        with contextlib.suppress(AttributeError):
            delattr(mod, "QdrantClient")
    else:
        mod.QdrantClient = original  # type: ignore[attr-defined]


# ---------------------------------------------------------------------------
# TestQdrantUnavailableOnConnect
# ---------------------------------------------------------------------------


class TestQdrantUnavailableOnConnect:
    """Qdrant fails during initial connection attempt."""

    def test_try_connect_connection_error_returns_false(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        """_try_connect returns False and logs warning when connection fails."""
        import owlmind.memory.qdrant_retrieval as _mod

        store = _make_store()
        error = ConnectionRefusedError("Connection refused")

        with patch("owlmind.memory.qdrant_retrieval.HAS_QDRANT", True):
            original, _ = _patch_qdrant_client(_mod, side_effect=error)
            try:
                with caplog.at_level(logging.WARNING, logger="owlmind.memory.qdrant_retrieval"):
                    result = store._try_connect()
            finally:
                _restore_qdrant_client(_mod, original)

        assert result is False
        assert store._client is None
        assert store._embedder is None
        assert any("Qdrant unavailable" in r.message for r in caplog.records)
        assert any("falling back to TF-IDF" in r.message for r in caplog.records)

    def test_try_connect_generic_exception_returns_false(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        """_try_connect returns False for any exception type."""
        import owlmind.memory.qdrant_retrieval as _mod

        store = _make_store()
        error = RuntimeError("Unexpected error")

        with patch("owlmind.memory.qdrant_retrieval.HAS_QDRANT", True):
            original, _ = _patch_qdrant_client(_mod, side_effect=error)
            try:
                with caplog.at_level(logging.WARNING, logger="owlmind.memory.qdrant_retrieval"):
                    result = store._try_connect()
            finally:
                _restore_qdrant_client(_mod, original)

        assert result is False

    def test_try_connect_no_qdrant_package_returns_false(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        """_try_connect returns False and warns when qdrant-client is not installed."""
        store = _make_store()

        with (
            patch("owlmind.memory.qdrant_retrieval.HAS_QDRANT", False),
            caplog.at_level(logging.WARNING, logger="owlmind.memory.qdrant_retrieval"),
        ):
            result = store._try_connect()

        assert result is False
        warning_messages = " ".join(r.message for r in caplog.records)
        assert "Qdrant unavailable" in warning_messages

    def test_available_property_caches_false_result(self, caplog: pytest.LogCaptureFixture) -> None:
        """available property caches False — _try_connect is NOT called twice."""
        store = _make_store()
        call_count = 0

        def _failing_connect() -> bool:
            nonlocal call_count
            call_count += 1
            return False

        store._try_connect = _failing_connect

        assert store.available is False
        assert store.available is False
        # _try_connect must be called exactly once (result is cached)
        assert call_count == 1


# ---------------------------------------------------------------------------
# TestQdrantSearchGracefulDegradation
# ---------------------------------------------------------------------------


class TestQdrantSearchGracefulDegradation:
    """search() returns [] and logs warning when Qdrant becomes unavailable at runtime."""

    def test_search_returns_empty_when_not_available(self) -> None:
        """search() returns [] when store.available is False."""
        store = _make_store(_available=False)
        results = store.search("test query")
        assert results == []

    def test_search_runtime_failure_returns_empty_and_warns(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        """search() catches runtime exception, logs warning, returns []."""
        store = _make_store(_available=True)
        store._embedder = MagicMock()
        store._embedder.embed.side_effect = RuntimeError("Qdrant connection lost")

        with caplog.at_level(logging.WARNING, logger="owlmind.memory.qdrant_retrieval"):
            results = store.search("test query")

        assert results == []
        assert any("Qdrant unavailable" in r.message for r in caplog.records)
        assert any("falling back to TF-IDF" in r.message for r in caplog.records)

    def test_search_runtime_failure_marks_store_unavailable(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        """After runtime search failure, store is marked unavailable for future calls."""
        store = _make_store(_available=True)
        store._embedder = MagicMock()
        store._embedder.embed.side_effect = OSError("network error")

        with caplog.at_level(logging.WARNING):
            store.search("query")

        # _available must be set to False so next call skips Qdrant
        assert store._available is False

    def test_search_client_search_failure_returns_empty(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        """search() handles failure in self._client.search()."""
        store = _make_store(_available=True)

        mock_embedder = MagicMock()
        mock_embedder.embed.return_value = iter([[0.1] * 384])
        store._embedder = mock_embedder

        mock_client = MagicMock()
        mock_client.search.side_effect = ConnectionError("Qdrant went down")
        store._client = mock_client

        with caplog.at_level(logging.WARNING, logger="owlmind.memory.qdrant_retrieval"):
            results = store.search("test query")

        assert results == []
        assert store._available is False
        assert any("falling back to TF-IDF" in r.message for r in caplog.records)

    def test_search_no_exception_when_available_is_false(self) -> None:
        """search() must never raise; always return [] when unavailable."""
        store = _make_store(_available=False)
        for _ in range(3):
            results = store.search("any query")
            assert results == []


# ---------------------------------------------------------------------------
# TestIndexTextGracefulDegradation
# ---------------------------------------------------------------------------


class TestIndexTextGracefulDegradation:
    """index_text() returns False and does not raise when Qdrant is unavailable."""

    def test_index_text_returns_false_when_unavailable(self) -> None:
        """index_text() returns False when store.available is False."""
        store = _make_store(_available=False)
        result = store.index_text("source.py", "def foo(): pass")
        assert result is False

    def test_index_text_runtime_failure_returns_false_and_warns(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        """index_text() catches runtime exception, logs warning, returns False."""
        store = _make_store(_available=True)
        store._embedder = MagicMock()
        store._embedder.embed.side_effect = RuntimeError("GPU out of memory")

        with caplog.at_level(logging.WARNING, logger="owlmind.memory.qdrant_retrieval"):
            result = store.index_text("file.py", "some code")

        assert result is False
        assert any(
            "index" in r.message.lower() or "qdrant" in r.message.lower() for r in caplog.records
        )

    def test_index_text_never_raises(self) -> None:
        """index_text() must never propagate exceptions."""
        store = _make_store(_available=True)
        store._embedder = MagicMock()
        store._embedder.embed.side_effect = MemoryError("OOM")
        result = store.index_text("crash.py", "content")
        assert result is False


# ---------------------------------------------------------------------------
# TestBuildHybridMemoryContextFallback
# ---------------------------------------------------------------------------


class TestBuildHybridMemoryContextFallback:
    """build_hybrid_memory_context() falls back to TF-IDF when Qdrant is unavailable."""

    def _make_tfidf_result(self, source: str, snippet: str, score: float) -> MagicMock:
        r: MagicMock = MagicMock()
        r.source = source
        r.snippet = snippet
        r.score = score
        return r

    def test_fallback_when_qdrant_store_is_none(self) -> None:
        """When qdrant_store=None, only TF-IDF results are used."""
        mock_store = MagicMock()
        tfidf_result = self._make_tfidf_result("doc.py", "def bar(): pass", 0.8)

        with patch("owlmind.memory.retrieval.query", return_value=[tfidf_result]):
            ctx = build_hybrid_memory_context(mock_store, "bar function", top_k=3)

        assert "doc.py" in ctx
        assert "Relevant project memory" in ctx

    def test_fallback_when_qdrant_not_available(self, caplog: pytest.LogCaptureFixture) -> None:
        """build_hybrid_memory_context logs warning and uses TF-IDF when Qdrant not available."""
        mock_store = MagicMock()
        qdrant_store = _make_store(_available=False)
        tfidf_result = self._make_tfidf_result("tfidf.py", "tfidf content", 0.7)

        with (
            patch("owlmind.memory.retrieval.query", return_value=[tfidf_result]),
            caplog.at_level(logging.WARNING, logger="owlmind.memory.qdrant_retrieval"),
        ):
            ctx = build_hybrid_memory_context(mock_store, "query", qdrant_store=qdrant_store)

        assert "tfidf.py" in ctx
        assert any("Qdrant unavailable" in r.message for r in caplog.records)
        assert any("falling back to TF-IDF" in r.message for r in caplog.records)

    def test_fallback_when_qdrant_search_raises_at_runtime(
        self, caplog: pytest.LogCaptureFixture
    ) -> None:
        """build_hybrid_memory_context handles exception from qdrant_store.search()."""
        mock_store = MagicMock()
        qdrant_store = _make_store(_available=True)
        qdrant_store._embedder = MagicMock()
        qdrant_store._embedder.embed.side_effect = OSError("Qdrant connection reset")

        tfidf_result = self._make_tfidf_result("fallback.py", "fallback code", 0.6)

        with (
            patch("owlmind.memory.retrieval.query", return_value=[tfidf_result]),
            caplog.at_level(logging.WARNING, logger="owlmind.memory.qdrant_retrieval"),
        ):
            ctx = build_hybrid_memory_context(mock_store, "query", qdrant_store=qdrant_store)

        assert "fallback.py" in ctx

    def test_returns_empty_string_when_both_fail(self) -> None:
        """build_hybrid_memory_context returns '' when TF-IDF and Qdrant both fail."""
        mock_store = MagicMock()
        qdrant_store = _make_store(_available=False)

        with patch("owlmind.memory.retrieval.query", return_value=[]):
            ctx = build_hybrid_memory_context(mock_store, "query", qdrant_store=qdrant_store)

        assert ctx == ""

    def test_hybrid_used_when_qdrant_available(self) -> None:
        """When Qdrant is available, hybrid results are used (not pure TF-IDF)."""
        mock_store = MagicMock()

        qdrant_result = VectorSearchResult(source="semantic.py", snippet="semantic code", score=0.9)
        tfidf_result = self._make_tfidf_result("keyword.py", "keyword content", 0.5)

        qdrant_store = _make_store(_available=True)
        qdrant_store.search = MagicMock(return_value=[qdrant_result])

        with patch("owlmind.memory.retrieval.query", return_value=[tfidf_result]):
            ctx = build_hybrid_memory_context(mock_store, "query", qdrant_store=qdrant_store)

        assert "semantic.py" in ctx
        assert "keyword.py" in ctx
