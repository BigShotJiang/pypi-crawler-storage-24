"""Tests for DAG utilities — cycle detection, topo sort, ready nodes."""

from __future__ import annotations

import pytest

from owlmind.dag import (
    CycleError,
    format_dag_summary,
    ready_goals,
    topological_layers,
    validate_dag,
)


class TestValidateDag:
    def test_valid_linear(self) -> None:
        goals = [
            {"id": "G1", "depends_on": []},
            {"id": "G2", "depends_on": ["G1"]},
            {"id": "G3", "depends_on": ["G2"]},
        ]
        validate_dag(goals)  # should not raise

    def test_valid_diamond(self) -> None:
        goals = [
            {"id": "G1", "depends_on": []},
            {"id": "G2", "depends_on": ["G1"]},
            {"id": "G3", "depends_on": ["G1"]},
            {"id": "G4", "depends_on": ["G2", "G3"]},
        ]
        validate_dag(goals)

    def test_valid_no_deps(self) -> None:
        goals = [
            {"id": "G1", "depends_on": []},
            {"id": "G2", "depends_on": []},
        ]
        validate_dag(goals)

    def test_cycle_two_nodes(self) -> None:
        goals = [
            {"id": "G1", "depends_on": ["G2"]},
            {"id": "G2", "depends_on": ["G1"]},
        ]
        with pytest.raises(CycleError, match="Cycle detected"):
            validate_dag(goals)

    def test_cycle_three_nodes(self) -> None:
        goals = [
            {"id": "G1", "depends_on": ["G3"]},
            {"id": "G2", "depends_on": ["G1"]},
            {"id": "G3", "depends_on": ["G2"]},
        ]
        with pytest.raises(CycleError, match="Cycle detected"):
            validate_dag(goals)

    def test_unknown_dependency(self) -> None:
        goals = [
            {"id": "G1", "depends_on": ["G99"]},
        ]
        with pytest.raises(ValueError, match="unknown goal G99"):
            validate_dag(goals)

    def test_self_cycle(self) -> None:
        goals = [
            {"id": "G1", "depends_on": ["G1"]},
        ]
        with pytest.raises(CycleError, match="Cycle detected"):
            validate_dag(goals)


class TestTopologicalLayers:
    def test_linear_chain(self) -> None:
        goals = [
            {"id": "G1", "depends_on": []},
            {"id": "G2", "depends_on": ["G1"]},
            {"id": "G3", "depends_on": ["G2"]},
        ]
        layers = topological_layers(goals)
        assert layers == [["G1"], ["G2"], ["G3"]]

    def test_diamond(self) -> None:
        goals = [
            {"id": "G1", "depends_on": []},
            {"id": "G2", "depends_on": ["G1"]},
            {"id": "G3", "depends_on": ["G1"]},
            {"id": "G4", "depends_on": ["G2", "G3"]},
        ]
        layers = topological_layers(goals)
        assert layers[0] == ["G1"]
        assert sorted(layers[1]) == ["G2", "G3"]
        assert layers[2] == ["G4"]

    def test_all_independent(self) -> None:
        goals = [
            {"id": "G1", "depends_on": []},
            {"id": "G2", "depends_on": []},
            {"id": "G3", "depends_on": []},
        ]
        layers = topological_layers(goals)
        assert len(layers) == 1
        assert sorted(layers[0]) == ["G1", "G2", "G3"]

    def test_single_goal(self) -> None:
        goals = [{"id": "G1", "depends_on": []}]
        layers = topological_layers(goals)
        assert layers == [["G1"]]

    def test_complex_dag(self) -> None:
        goals = [
            {"id": "A", "depends_on": []},
            {"id": "B", "depends_on": ["A"]},
            {"id": "C", "depends_on": ["A"]},
            {"id": "D", "depends_on": ["B"]},
            {"id": "E", "depends_on": ["C", "D"]},
        ]
        layers = topological_layers(goals)
        assert layers[0] == ["A"]
        assert sorted(layers[1]) == ["B", "C"]
        assert layers[2] == ["D"]
        assert layers[3] == ["E"]


class TestReadyGoals:
    def test_all_pending_no_deps(self) -> None:
        goals = [
            {"id": "G1", "depends_on": []},
            {"id": "G2", "depends_on": []},
        ]
        statuses: dict[str, str] = {"G1": "pending", "G2": "pending"}
        result = ready_goals(goals, statuses)
        assert result == ["G1", "G2"]

    def test_deps_not_done(self) -> None:
        goals = [
            {"id": "G1", "depends_on": []},
            {"id": "G2", "depends_on": ["G1"]},
        ]
        statuses = {"G1": "running", "G2": "pending"}
        result = ready_goals(goals, statuses)
        assert result == []

    def test_deps_done(self) -> None:
        goals = [
            {"id": "G1", "depends_on": []},
            {"id": "G2", "depends_on": ["G1"]},
        ]
        statuses = {"G1": "done", "G2": "pending"}
        result = ready_goals(goals, statuses)
        assert result == ["G2"]

    def test_already_running_excluded(self) -> None:
        goals = [
            {"id": "G1", "depends_on": []},
            {"id": "G2", "depends_on": []},
        ]
        statuses = {"G1": "running", "G2": "pending"}
        result = ready_goals(goals, statuses)
        assert result == ["G2"]

    def test_skipped_deps_allowed(self) -> None:
        goals = [
            {"id": "G1", "depends_on": []},
            {"id": "G2", "depends_on": ["G1"]},
        ]
        statuses = {"G1": "skipped", "G2": "pending"}
        result = ready_goals(goals, statuses, allow_skipped_deps=True)
        assert result == ["G2"]

    def test_skipped_deps_not_allowed(self) -> None:
        goals = [
            {"id": "G1", "depends_on": []},
            {"id": "G2", "depends_on": ["G1"]},
        ]
        statuses = {"G1": "skipped", "G2": "pending"}
        result = ready_goals(goals, statuses, allow_skipped_deps=False)
        assert result == []

    def test_diamond_partial(self) -> None:
        goals = [
            {"id": "G1", "depends_on": []},
            {"id": "G2", "depends_on": ["G1"]},
            {"id": "G3", "depends_on": ["G1"]},
            {"id": "G4", "depends_on": ["G2", "G3"]},
        ]
        statuses = {"G1": "done", "G2": "done", "G3": "pending", "G4": "pending"}
        result = ready_goals(goals, statuses)
        assert result == ["G3"]


class TestFormatDagSummary:
    def test_basic_format(self) -> None:
        goals = [
            {"id": "G1", "depends_on": [], "goal": "First"},
            {"id": "G2", "depends_on": ["G1"], "goal": "Second"},
        ]
        statuses = {"G1": "done", "G2": "pending"}
        summary = format_dag_summary(goals, statuses)
        assert "DAG Summary" in summary
        assert "G1" in summary
        assert "G2" in summary
        assert "done" in summary
        assert "pending" in summary

    def test_ready_shown(self) -> None:
        goals = [
            {"id": "G1", "depends_on": [], "goal": "First"},
            {"id": "G2", "depends_on": ["G1"], "goal": "Second"},
        ]
        statuses = {"G1": "done", "G2": "pending"}
        summary = format_dag_summary(goals, statuses)
        assert "Ready to run" in summary
        assert "G2" in summary


class TestNonListDeps:
    """Lines 33, 46, 85, 140, 168: scalar (non-list) depends_on handled gracefully."""

    def test_validate_dag_scalar_dep(self) -> None:
        goals = [
            {"id": "G1", "depends_on": []},
            {"id": "G2", "depends_on": "G1"},  # scalar, not list
        ]
        validate_dag(goals)  # must not raise

    def test_topological_layers_scalar_dep(self) -> None:
        goals = [
            {"id": "G1", "depends_on": []},
            {"id": "G2", "depends_on": "G1"},
        ]
        layers = topological_layers(goals)
        assert layers[0] == ["G1"]
        assert layers[1] == ["G2"]

    def test_ready_goals_scalar_dep(self) -> None:
        goals = [
            {"id": "G1", "depends_on": []},
            {"id": "G2", "depends_on": "G1"},
        ]
        statuses = {"G1": "done", "G2": "pending"}
        result = ready_goals(goals, statuses)
        assert result == ["G2"]

    def test_format_dag_summary_scalar_dep(self) -> None:
        goals = [
            {"id": "G1", "depends_on": [], "goal": "First"},
            {"id": "G2", "depends_on": "G1", "goal": "Second"},
        ]
        statuses = {"G1": "done", "G2": "pending"}
        summary = format_dag_summary(goals, statuses)
        assert "G1" in summary
        assert "G2" in summary
