"""Tests for public registry CLI commands."""

from __future__ import annotations

import asyncio
import io
import json
import zipfile
from pathlib import Path

from typer.testing import CliRunner

from owlmind.cli.registry_cmd import registry_app
from owlmind.registry.models import PublishRequest
from owlmind.registry.public import SQLitePublicPackRegistry

runner = CliRunner()


def _make_zip(manifest: dict) -> bytes:
    """Create a minimal ZIP with manifest.json."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        zf.writestr("manifest.json", json.dumps(manifest))
    return buf.getvalue()


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------


class TestSearch:
    def test_empty_result(self, tmp_path: Path) -> None:
        """Search with no packs shows 'No packs found'."""
        db = tmp_path / "reg.db"
        import typer

        app = typer.Typer()
        app.add_typer(registry_app, name="registry")

        result = runner.invoke(app, ["registry", "search", "--registry-db", str(db)])
        assert result.exit_code == 0
        assert "No packs found" in result.stdout

    def test_with_results(self, tmp_path: Path) -> None:
        """Search displays results in a table."""
        db = tmp_path / "reg.db"
        reg = SQLitePublicPackRegistry(db)
        req = PublishRequest(
            name="Code Review", version="1.0.0", tags=["python"], author_name="dev"
        )
        asyncio.run(reg.publish_pack("code-review", req))
        asyncio.run(reg.approve_pack("code-review"))

        import typer

        app = typer.Typer()
        app.add_typer(registry_app, name="registry")

        result = runner.invoke(app, ["registry", "search", "--registry-db", str(db)])
        assert result.exit_code == 0
        assert "Code Review" in result.stdout


# ---------------------------------------------------------------------------
# Install
# ---------------------------------------------------------------------------


class TestInstall:
    def test_validates_pack_id(self, tmp_path: Path) -> None:
        """Install fails gracefully for unknown pack."""
        db = tmp_path / "reg.db"
        SQLitePublicPackRegistry(db)  # init DB

        import typer

        app = typer.Typer()
        app.add_typer(registry_app, name="registry")

        result = runner.invoke(
            app,
            ["registry", "install", "nonexistent", "--registry-db", str(db)],
        )
        assert result.exit_code == 1

    def test_install_local(self, tmp_path: Path) -> None:
        """Install from local archive works."""
        db = tmp_path / "reg.db"
        reg = SQLitePublicPackRegistry(db)

        # Publish pack
        req = PublishRequest(name="My Pack", version="1.0.0", author_name="dev")
        asyncio.run(reg.publish_pack("my-pack", req))
        asyncio.run(reg.add_version("my-pack", "1.0.0"))

        # Create archive
        manifest = {"id": "my-pack", "name": "My Pack", "version": "1.0.0"}
        archive_dir = Path("registry_archives") / "my-pack"
        archive_dir.mkdir(parents=True, exist_ok=True)
        (archive_dir / "1.0.0.zip").write_bytes(_make_zip(manifest))

        import typer

        app = typer.Typer()
        app.add_typer(registry_app, name="registry")

        packs_dir = tmp_path / "installed"
        result = runner.invoke(
            app,
            [
                "registry",
                "install",
                "my-pack",
                "--registry-db",
                str(db),
                "--packs-dir",
                str(packs_dir),
            ],
        )

        # Clean up
        import shutil

        shutil.rmtree("registry_archives", ignore_errors=True)

        if result.exit_code == 0:
            assert "Installed" in result.stdout


# ---------------------------------------------------------------------------
# Publish
# ---------------------------------------------------------------------------


class TestPublish:
    def test_validates_manifest(self, tmp_path: Path) -> None:
        """Publish validates manifest.json in ZIP."""
        # Create ZIP without manifest
        bad_zip = tmp_path / "bad.zip"
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as zf:
            zf.writestr("readme.txt", "hello")
        bad_zip.write_bytes(buf.getvalue())

        import typer

        app = typer.Typer()
        app.add_typer(registry_app, name="registry")

        result = runner.invoke(app, ["registry", "publish", str(bad_zip)])
        assert result.exit_code == 1
        assert "manifest.json" in result.stdout

    def test_publish_local(self, tmp_path: Path) -> None:
        """Publish to local registry creates pack."""
        db = tmp_path / "reg.db"
        manifest = {"id": "pub-pack", "name": "Published", "version": "1.0.0"}
        zip_path = tmp_path / "pack.zip"
        zip_path.write_bytes(_make_zip(manifest))

        import typer

        app = typer.Typer()
        app.add_typer(registry_app, name="registry")

        result = runner.invoke(
            app,
            ["registry", "publish", str(zip_path), "--registry-db", str(db)],
        )

        # Clean up local archives
        import shutil

        shutil.rmtree("registry_archives", ignore_errors=True)

        assert result.exit_code == 0
        assert "Published" in result.stdout

        # Verify in DB
        reg = SQLitePublicPackRegistry(db)
        pack = asyncio.run(reg.get_pack("pub-pack"))
        assert pack is not None
        assert pack["name"] == "Published"
