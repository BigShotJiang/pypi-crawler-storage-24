"""Tests for EventBus and config."""

from __future__ import annotations

from owlmind.config import OwlMindConfig, TelegramConfig, parse_chat_ids
from owlmind.events import EventBus


class TestEventBus:
    def test_subscribe_and_publish(self) -> None:
        bus = EventBus()
        received: list[tuple[str, dict]] = []  # type: ignore[type-arg]

        def handler(event: str, data: dict) -> None:  # type: ignore[type-arg]
            received.append((event, data))

        bus.subscribe(handler)
        bus.publish("test_event", {"key": "value"})

        assert len(received) == 1
        assert received[0] == ("test_event", {"key": "value"})

    def test_multiple_subscribers(self) -> None:
        bus = EventBus()
        count = [0]

        def h1(event: str, data: dict) -> None:  # type: ignore[type-arg]
            count[0] += 1

        def h2(event: str, data: dict) -> None:  # type: ignore[type-arg]
            count[0] += 10

        bus.subscribe(h1)
        bus.subscribe(h2)
        bus.publish("event", {})

        assert count[0] == 11

    def test_unsubscribe(self) -> None:
        bus = EventBus()
        count = [0]

        def handler(event: str, data: dict) -> None:  # type: ignore[type-arg]
            count[0] += 1

        bus.subscribe(handler)
        bus.publish("e1", {})
        assert count[0] == 1

        bus.unsubscribe(handler)
        bus.publish("e2", {})
        assert count[0] == 1

    def test_publish_no_data(self) -> None:
        bus = EventBus()
        received: list[dict] = []  # type: ignore[type-arg]

        def handler(event: str, data: dict) -> None:  # type: ignore[type-arg]
            received.append(data)

        bus.subscribe(handler)
        bus.publish("empty")

        assert received == [{}]

    def test_subscriber_count(self) -> None:
        bus = EventBus()
        assert bus.subscriber_count == 0

        def h(e: str, d: dict) -> None:  # type: ignore[type-arg]
            pass

        bus.subscribe(h)
        assert bus.subscriber_count == 1


class TestConfig:
    def test_parse_chat_ids_empty(self) -> None:
        assert parse_chat_ids("") == []
        assert parse_chat_ids("  ") == []

    def test_parse_chat_ids(self) -> None:
        assert parse_chat_ids("123,456,789") == [123, 456, 789]
        assert parse_chat_ids("123, 456 , 789") == [123, 456, 789]

    def test_telegram_config_disabled(self) -> None:
        cfg = TelegramConfig()
        assert cfg.enabled is False

    def test_telegram_config_enabled(self) -> None:
        cfg = TelegramConfig(bot_token="test-token")
        assert cfg.enabled is True

    def test_owlmind_config_from_env(self, monkeypatch: object) -> None:
        import os

        # Use os.environ directly for monkeypatching
        env = os.environ
        orig_token = env.get("TELEGRAM_BOT_TOKEN")
        orig_ids = env.get("TELEGRAM_ALLOWED_CHAT_IDS")

        try:
            env["TELEGRAM_BOT_TOKEN"] = "test-token-123"
            env["TELEGRAM_ALLOWED_CHAT_IDS"] = "111,222"
            env["OWLMIND_NOTIFY_DEFAULT_CHAT_ID"] = "111"

            cfg = OwlMindConfig.from_env()
            assert cfg.telegram.bot_token == "test-token-123"
            assert cfg.telegram.allowed_chat_ids == [111, 222]
            assert cfg.telegram.default_chat_id == 111
        finally:
            if orig_token is None:
                env.pop("TELEGRAM_BOT_TOKEN", None)
            else:
                env["TELEGRAM_BOT_TOKEN"] = orig_token
            if orig_ids is None:
                env.pop("TELEGRAM_ALLOWED_CHAT_IDS", None)
            else:
                env["TELEGRAM_ALLOWED_CHAT_IDS"] = orig_ids
            env.pop("OWLMIND_NOTIFY_DEFAULT_CHAT_ID", None)
