"""Tests for FS73 — CLI small modules: evidence, mcp, plugin, webhook."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from owlmind.cli import app

runner = CliRunner()

# ---------------------------------------------------------------------------
# Evidence verify
# ---------------------------------------------------------------------------

_TIP_HASH = "a" * 32  # must be at least 16 chars ([:16] is used in output)


class TestEvidenceVerify:
    def test_verify_ok(self, tmp_path: Path) -> None:
        """evidence verify with valid chain → exit 0, 'Chain OK' in output."""
        mock_result = MagicMock()
        mock_result.ok = True
        mock_result.seq = 5
        mock_result.tip_hash = _TIP_HASH

        mock_store = MagicMock()
        mock_store.verify_chain.return_value = mock_result

        with patch("owlmind.evidence.EvidenceStore", return_value=mock_store):
            result = runner.invoke(
                app,
                ["evidence", "verify", "run-001", "--runs", str(tmp_path)],
            )

        assert result.exit_code == 0, result.output
        assert "Chain OK" in result.output

    def test_verify_fail(self, tmp_path: Path) -> None:
        """evidence verify with broken chain → exit 1, 'INVALID' in output."""
        mock_result = MagicMock()
        mock_result.ok = False
        mock_result.errors = ["Hash mismatch at seq 3"]

        mock_store = MagicMock()
        mock_store.verify_chain.return_value = mock_result

        with patch("owlmind.evidence.EvidenceStore", return_value=mock_store):
            result = runner.invoke(
                app,
                ["evidence", "verify", "run-broken", "--runs", str(tmp_path)],
            )

        assert result.exit_code == 1
        assert "INVALID" in result.output


# ---------------------------------------------------------------------------
# MCP tools
# ---------------------------------------------------------------------------

_MCP_TOOLS_MOCK = [
    {
        "name": "owlmind_run",
        "description": "Run a OWLMIND task cycle.",
        "inputSchema": {"properties": {}, "required": []},
    },
]


class TestMcpTools:
    def test_tools_listed(self) -> None:
        """mcp tools → exit 0, tool name in output."""
        with patch("owlmind.mcp.server.TOOLS", _MCP_TOOLS_MOCK):
            result = runner.invoke(app, ["mcp", "tools"])

        assert result.exit_code == 0, result.output
        assert "owlmind_run" in result.output


# ---------------------------------------------------------------------------
# Plugin list
# ---------------------------------------------------------------------------


class TestPluginList:
    def test_plugin_list_empty(self) -> None:
        """plugin list with no plugins → exit 0, 'No plugins' in output."""
        mock_registry = MagicMock()
        mock_registry.discover.return_value = []

        with patch("owlmind.plugins.PluginRegistry", return_value=mock_registry):
            result = runner.invoke(app, ["plugin", "list"])

        assert result.exit_code == 0
        assert "No plugins" in result.output

    def test_plugin_list_with_plugins(self) -> None:
        """plugin list with plugins → exit 0."""
        mock_plugin = MagicMock()
        mock_plugin.name = "test-plugin"
        mock_plugin.version = "1.0.0"
        mock_plugin.description = "A test plugin"

        mock_registry = MagicMock()
        mock_registry.discover.return_value = [mock_plugin]

        with patch("owlmind.plugins.PluginRegistry", return_value=mock_registry):
            result = runner.invoke(app, ["plugin", "list"])

        assert result.exit_code == 0, result.output


# ---------------------------------------------------------------------------
# Webhook status / preview
# ---------------------------------------------------------------------------


class TestWebhookStatus:
    def test_status_disabled(self) -> None:
        """webhook status with no config → exit 0, 'enabled' in output."""
        mock_cfg = MagicMock()
        mock_cfg.enabled = False
        mock_cfg.url = ""
        mock_cfg.allowlist_domains = []
        mock_cfg.timeout_sec = 10
        mock_cfg.max_retries = 3
        mock_cfg.secret = ""

        with patch("owlmind.cli.webhook_cmd.WebhookConfig", return_value=mock_cfg):
            result = runner.invoke(app, ["webhook", "status"])

        assert result.exit_code == 0
        assert "enabled" in result.output.lower()


class TestWebhookPreview:
    def test_preview_ok(self) -> None:
        """webhook preview → exit 0, JSON output."""
        mock_payload = {"event": "run_started", "data": {"run_id": "r-001"}}

        with (
            patch("owlmind.cli.webhook_cmd.WebhookConfig", return_value=MagicMock()),
            patch("owlmind.cli.webhook_cmd.build_payload", return_value=mock_payload),
        ):
            result = runner.invoke(app, ["webhook", "preview"])

        assert result.exit_code == 0, result.output


# ---------------------------------------------------------------------------
# MCP serve — KeyboardInterrupt stops server gracefully
# ---------------------------------------------------------------------------


class TestMcpServe:
    def test_serve_keyboard_interrupt_exits_cleanly(self) -> None:
        """mcp serve → KeyboardInterrupt → exit 0, 'stopped' in output."""
        mock_server = MagicMock()
        mock_server.serve_forever.side_effect = KeyboardInterrupt

        with patch("owlmind.mcp.server.MCPServer", return_value=mock_server):
            result = runner.invoke(app, ["mcp", "serve"])

        assert result.exit_code == 0, result.output
        assert "stopped" in result.output.lower()

    def test_serve_calls_serve_forever(self) -> None:
        """mcp serve → MCPServer.serve_forever() is called."""
        mock_server = MagicMock()
        mock_server.serve_forever.return_value = None

        with patch("owlmind.mcp.server.MCPServer", return_value=mock_server):
            runner.invoke(app, ["mcp", "serve"])

        mock_server.serve_forever.assert_called_once()


# ---------------------------------------------------------------------------
# MCP tools — tool with required params
# ---------------------------------------------------------------------------


_MCP_TOOLS_WITH_REQUIRED = [
    {
        "name": "owlmind_query",
        "description": "Query the memory store.",
        "inputSchema": {
            "properties": {
                "text": {"type": "string"},
                "top_k": {"type": "integer"},
            },
            "required": ["text"],
        },
    },
]


class TestMcpToolsRequired:
    def test_required_params_output(self) -> None:
        """mcp tools with required params → param names in output."""
        with patch("owlmind.mcp.server.TOOLS", _MCP_TOOLS_WITH_REQUIRED):
            result = runner.invoke(app, ["mcp", "tools"])

        assert result.exit_code == 0, result.output
        assert "owlmind_query" in result.output
        assert "text" in result.output
        assert "top_k" in result.output

    def test_tool_count_in_header(self) -> None:
        """mcp tools header shows correct count."""
        with patch("owlmind.mcp.server.TOOLS", _MCP_TOOLS_WITH_REQUIRED):
            result = runner.invoke(app, ["mcp", "tools"])

        assert "1 tools" in result.output or "(1" in result.output


# ---------------------------------------------------------------------------
# Webhook status — URL configured + allowlist
# ---------------------------------------------------------------------------


class TestWebhookStatusWithUrl:
    def test_status_with_url_shows_hostname(self) -> None:
        """webhook status when URL set → hostname shown."""
        mock_cfg = MagicMock()
        mock_cfg.enabled = True
        mock_cfg.url = "https://hooks.example.com/owlmind"
        mock_cfg.hostname = "hooks.example.com"
        mock_cfg.allowlist_domains = []
        mock_cfg.timeout_sec = 10
        mock_cfg.max_retries = 3
        mock_cfg.secret = "s3cr3t"

        with patch("owlmind.cli.webhook_cmd._load_webhook_config", return_value=mock_cfg):
            result = runner.invoke(app, ["webhook", "status"])

        assert result.exit_code == 0, result.output
        assert "hooks.example.com" in result.output

    def test_status_with_allowlist_shows_domains(self) -> None:
        """webhook status with allowlist → domain names in output."""
        mock_cfg = MagicMock()
        mock_cfg.enabled = True
        mock_cfg.url = "https://hooks.example.com/owlmind"
        mock_cfg.hostname = "hooks.example.com"
        mock_cfg.allowlist_domains = ["example.com", "trusted.io"]
        mock_cfg.timeout_sec = 30
        mock_cfg.max_retries = 5
        mock_cfg.secret = ""

        with patch("owlmind.cli.webhook_cmd._load_webhook_config", return_value=mock_cfg):
            result = runner.invoke(app, ["webhook", "status"])

        assert result.exit_code == 0, result.output
        assert "example.com" in result.output

    def test_status_hmac_yes_when_secret_set(self) -> None:
        """webhook status with secret → 'yes' for HMAC."""
        mock_cfg = MagicMock()
        mock_cfg.enabled = True
        mock_cfg.url = "https://example.com"
        mock_cfg.hostname = "example.com"
        mock_cfg.allowlist_domains = []
        mock_cfg.timeout_sec = 10
        mock_cfg.max_retries = 3
        mock_cfg.secret = "mysecret"

        with patch("owlmind.cli.webhook_cmd._load_webhook_config", return_value=mock_cfg):
            result = runner.invoke(app, ["webhook", "status"])

        assert "yes" in result.output.lower()


# ---------------------------------------------------------------------------
# Webhook test command
# ---------------------------------------------------------------------------


class TestWebhookTest:
    def test_test_not_configured_exits_1(self) -> None:
        """webhook test without config → exit 1, warning message."""
        mock_cfg = MagicMock()
        mock_cfg.enabled = False
        mock_cfg.url = ""

        with patch("owlmind.cli.webhook_cmd._load_webhook_config", return_value=mock_cfg):
            result = runner.invoke(app, ["webhook", "test"])

        assert result.exit_code == 1
        assert "OWLMIND_WEBHOOK" in result.output

    def test_test_success_prints_sent(self) -> None:
        """webhook test → notifier returns sent → exit 0, 'sent' in output."""
        mock_cfg = MagicMock()
        mock_cfg.enabled = True
        mock_cfg.url = "https://hooks.example.com/owlmind"

        mock_notifier = MagicMock()
        mock_notifier.send_event.return_value = {"sent": True, "status": 200}

        with (
            patch("owlmind.cli.webhook_cmd._load_webhook_config", return_value=mock_cfg),
            patch("owlmind.cli.webhook_cmd.WebhookNotifier", return_value=mock_notifier),
        ):
            result = runner.invoke(app, ["webhook", "test"])

        assert result.exit_code == 0, result.output
        assert "sent" in result.output.lower()

    def test_test_failure_exits_1(self) -> None:
        """webhook test → notifier returns not sent → exit 1."""
        mock_cfg = MagicMock()
        mock_cfg.enabled = True
        mock_cfg.url = "https://hooks.example.com/owlmind"

        mock_notifier = MagicMock()
        mock_notifier.send_event.return_value = {"sent": False, "reason": "connection refused"}

        with (
            patch("owlmind.cli.webhook_cmd._load_webhook_config", return_value=mock_cfg),
            patch("owlmind.cli.webhook_cmd.WebhookNotifier", return_value=mock_notifier),
        ):
            result = runner.invoke(app, ["webhook", "test"])

        assert result.exit_code == 1
        assert "connection refused" in result.output or "Failed" in result.output


# ---------------------------------------------------------------------------
# Plugin list — table rendered
# ---------------------------------------------------------------------------


class TestPluginListTable:
    def test_plugin_list_shows_name_in_table(self) -> None:
        """plugin list with plugins → plugin name appears in output table."""
        mock_plugin = MagicMock()

        mock_registry = MagicMock()
        mock_registry.discover.return_value = [mock_plugin]
        mock_registry.list_plugins.return_value = [
            {
                "name": "my-cool-plugin",
                "version": "2.0.0",
                "hooks": ["on_cycle_start", "on_cycle_end"],
                "description": "Does cool things",
            }
        ]

        with patch("owlmind.plugins.PluginRegistry", return_value=mock_registry):
            result = runner.invoke(app, ["plugin", "list"])

        assert result.exit_code == 0, result.output
        assert "my-cool-plugin" in result.output
        assert "2.0.0" in result.output

    def test_plugin_list_shows_hooks_in_table(self) -> None:
        """plugin list with hooks → hooks appear in table."""
        mock_plugin = MagicMock()

        mock_registry = MagicMock()
        mock_registry.discover.return_value = [mock_plugin]
        mock_registry.list_plugins.return_value = [
            {
                "name": "hook-plugin",
                "version": "1.0.0",
                "hooks": ["on_cycle_start"],
                "description": "",
            }
        ]

        with patch("owlmind.plugins.PluginRegistry", return_value=mock_registry):
            result = runner.invoke(app, ["plugin", "list"])

        assert result.exit_code == 0, result.output
        assert "on_cycle_start" in result.output

    def test_plugin_list_no_hooks_shows_dash(self) -> None:
        """plugin list with plugin having no hooks → '-' in table."""
        mock_plugin = MagicMock()

        mock_registry = MagicMock()
        mock_registry.discover.return_value = [mock_plugin]
        mock_registry.list_plugins.return_value = [
            {
                "name": "no-hook-plugin",
                "version": "0.1.0",
                "hooks": [],
                "description": "",
            }
        ]

        with patch("owlmind.plugins.PluginRegistry", return_value=mock_registry):
            result = runner.invoke(app, ["plugin", "list"])

        assert result.exit_code == 0, result.output
        assert "no-hook-plugin" in result.output


# ---------------------------------------------------------------------------
# Plugin info
# ---------------------------------------------------------------------------


class TestPluginInfo:
    def test_info_not_found_exits_1(self) -> None:
        """plugin info with unknown name → exit 1, 'not found' in output."""
        mock_registry = MagicMock()
        mock_registry.load.return_value = None

        with patch("owlmind.plugins.PluginRegistry", return_value=mock_registry):
            result = runner.invoke(app, ["plugin", "info", "nonexistent"])

        assert result.exit_code == 1
        assert "not found" in result.output.lower() or "nonexistent" in result.output

    def test_info_metadata_unavailable_exits_1(self) -> None:
        """plugin info loads but list_plugins returns no matching entry → exit 1."""
        mock_plugin = MagicMock()
        mock_registry = MagicMock()
        mock_registry.load.return_value = mock_plugin
        mock_registry.list_plugins.return_value = []  # no matching entry

        with patch("owlmind.plugins.PluginRegistry", return_value=mock_registry):
            result = runner.invoke(app, ["plugin", "info", "ghost-plugin"])

        assert result.exit_code == 1
        assert "unavailable" in result.output.lower() or "ghost-plugin" in result.output

    def test_info_shows_plugin_details(self) -> None:
        """plugin info with valid plugin → name, version, description printed."""
        mock_plugin = MagicMock()
        mock_registry = MagicMock()
        mock_registry.load.return_value = mock_plugin
        mock_registry.list_plugins.return_value = [
            {
                "name": "my-plugin",
                "version": "3.1.0",
                "description": "Does amazing things",
                "hooks": ["on_cycle_start"],
            }
        ]

        with patch("owlmind.plugins.PluginRegistry", return_value=mock_registry):
            result = runner.invoke(app, ["plugin", "info", "my-plugin"])

        assert result.exit_code == 0, result.output
        assert "my-plugin" in result.output
        assert "3.1.0" in result.output
        assert "Does amazing things" in result.output

    def test_info_shows_hooks(self) -> None:
        """plugin info with hooks → hooks listed in output."""
        mock_plugin = MagicMock()
        mock_registry = MagicMock()
        mock_registry.load.return_value = mock_plugin
        mock_registry.list_plugins.return_value = [
            {
                "name": "hooks-plugin",
                "version": "1.0.0",
                "description": "",
                "hooks": ["on_cycle_end", "on_run_complete"],
            }
        ]

        with patch("owlmind.plugins.PluginRegistry", return_value=mock_registry):
            result = runner.invoke(app, ["plugin", "info", "hooks-plugin"])

        assert result.exit_code == 0, result.output
        assert "on_cycle_end" in result.output
        assert "on_run_complete" in result.output

    def test_info_no_hooks_shows_none(self) -> None:
        """plugin info with no hooks → '(none)' in output."""
        mock_plugin = MagicMock()
        mock_registry = MagicMock()
        mock_registry.load.return_value = mock_plugin
        mock_registry.list_plugins.return_value = [
            {
                "name": "empty-plugin",
                "version": "1.0.0",
                "description": "No hooks here",
                "hooks": [],
            }
        ]

        with patch("owlmind.plugins.PluginRegistry", return_value=mock_registry):
            result = runner.invoke(app, ["plugin", "info", "empty-plugin"])

        assert result.exit_code == 0, result.output
        assert "(none)" in result.output

    def test_info_no_description_shows_none(self) -> None:
        """plugin info with empty description → '(none)' in output."""
        mock_plugin = MagicMock()
        mock_registry = MagicMock()
        mock_registry.load.return_value = mock_plugin
        mock_registry.list_plugins.return_value = [
            {
                "name": "nodesc-plugin",
                "version": "1.0.0",
                "description": "",
                "hooks": [],
            }
        ]

        with patch("owlmind.plugins.PluginRegistry", return_value=mock_registry):
            result = runner.invoke(app, ["plugin", "info", "nodesc-plugin"])

        assert result.exit_code == 0, result.output
        assert "(none)" in result.output
