"""Tests for web_dashboard module."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from owlmind.web_dashboard import (
    _read_json,
    _scan_queue,
    _scan_runs,
    _state_color,
    generate_html,
    update_dashboard,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_run(runs_dir: Path, run_id: str, state: str = "DONE", goal: str = "test") -> Path:
    run_dir = runs_dir / run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    meta = {
        "goal": goal,
        "state": state,
        "workspace": "/tmp/ws",
        "created_at": "2026-02-21T10:00:00",
    }
    (run_dir / "cycle_meta.json").write_text(json.dumps(meta))
    return run_dir


def _make_queue_file(queue_dir: Path, items: list[dict]) -> None:
    queue_dir.mkdir(parents=True, exist_ok=True)
    lines = [json.dumps(item) for item in items]
    (queue_dir / "queue.jsonl").write_text("\n".join(lines) + "\n")


# ===========================================================================
# TestReadJson
# ===========================================================================


class TestReadJson:
    def test_reads_valid_json(self, tmp_path: Path) -> None:
        f = tmp_path / "data.json"
        f.write_text('{"key": "value"}')
        result = _read_json(f)
        assert result == {"key": "value"}

    def test_returns_none_for_missing_file(self, tmp_path: Path) -> None:
        result = _read_json(tmp_path / "nonexistent.json")
        assert result is None

    def test_returns_none_for_invalid_json(self, tmp_path: Path) -> None:
        f = tmp_path / "bad.json"
        f.write_text("{invalid}")
        result = _read_json(f)
        assert result is None


# ===========================================================================
# TestStateColor
# ===========================================================================


class TestStateColor:
    def test_done_is_green(self) -> None:
        assert _state_color("DONE") == "#22c55e"

    def test_failed_is_red(self) -> None:
        assert _state_color("FAILED") == "#ef4444"

    def test_running_is_blue(self) -> None:
        assert _state_color("RUNNING") == "#3b82f6"

    def test_pending_is_amber(self) -> None:
        assert _state_color("PENDING") == "#f59e0b"

    def test_blocked_is_orange(self) -> None:
        assert _state_color("BLOCKED") == "#f97316"

    def test_unknown_returns_gray(self) -> None:
        assert _state_color("UNKNOWN") == "#94a3b8"

    def test_lowercase_accepted(self) -> None:
        assert _state_color("done") == "#22c55e"


# ===========================================================================
# TestScanRuns
# ===========================================================================


class TestScanRuns:
    def test_empty_dir_returns_empty_list(self, tmp_path: Path) -> None:
        runs = _scan_runs(tmp_path)
        assert runs == []

    def test_nonexistent_dir_returns_empty_list(self, tmp_path: Path) -> None:
        runs = _scan_runs(tmp_path / "missing")
        assert runs == []

    def test_returns_run_dicts(self, tmp_path: Path) -> None:
        _make_run(tmp_path, "run-001", "DONE")
        runs = _scan_runs(tmp_path)
        assert len(runs) == 1
        assert runs[0]["run_id"] == "run-001"
        assert runs[0]["state"] == "DONE"

    def test_skips_dirs_without_meta(self, tmp_path: Path) -> None:
        (tmp_path / "empty-run").mkdir()
        _make_run(tmp_path, "run-001", "DONE")
        runs = _scan_runs(tmp_path)
        assert len(runs) == 1

    def test_respects_limit(self, tmp_path: Path) -> None:
        for i in range(5):
            _make_run(tmp_path, f"run-{i:03d}", "DONE")
        runs = _scan_runs(tmp_path, limit=3)
        assert len(runs) <= 3

    def test_goal_truncated_to_80_chars(self, tmp_path: Path) -> None:
        _make_run(tmp_path, "run-001", "DONE", goal="x" * 200)
        runs = _scan_runs(tmp_path)
        assert len(runs[0]["goal"]) <= 80


# ===========================================================================
# TestScanQueue
# ===========================================================================


class TestScanQueue:
    def test_empty_queue_dir_returns_empty_list(self, tmp_path: Path) -> None:
        items = _scan_queue(tmp_path / "queue")
        assert items == []

    def test_reads_queue_items(self, tmp_path: Path) -> None:
        queue_dir = tmp_path / "queue"
        _make_queue_file(
            queue_dir,
            [
                {"id": "task-1", "goal": "do something", "status": "PENDING"},
            ],
        )
        items = _scan_queue(queue_dir)
        assert len(items) == 1
        assert items[0]["id"] == "task-1"

    def test_skips_blank_lines(self, tmp_path: Path) -> None:
        queue_dir = tmp_path / "queue"
        queue_dir.mkdir()
        (queue_dir / "queue.jsonl").write_text(
            '{"id": "t1", "goal": "g1", "status": "PENDING"}\n\n\n'
        )
        items = _scan_queue(queue_dir)
        assert len(items) == 1

    def test_multiple_items(self, tmp_path: Path) -> None:
        queue_dir = tmp_path / "queue"
        _make_queue_file(
            queue_dir,
            [
                {"id": "t1", "goal": "task 1", "status": "DONE"},
                {"id": "t2", "goal": "task 2", "status": "PENDING"},
            ],
        )
        items = _scan_queue(queue_dir)
        assert len(items) == 2


# ===========================================================================
# TestGenerateHtml
# ===========================================================================


class TestGenerateHtml:
    def test_returns_string(self, tmp_path: Path) -> None:
        runs_dir = tmp_path / "runs"
        runs_dir.mkdir()
        queue_dir = tmp_path / "queue"
        html = generate_html(runs_dir, queue_dir, tmp_path)
        assert isinstance(html, str)

    def test_contains_doctype(self, tmp_path: Path) -> None:
        html = generate_html(tmp_path / "runs", tmp_path / "queue", tmp_path)
        assert "<!DOCTYPE html>" in html

    def test_contains_owlmind_title(self, tmp_path: Path) -> None:
        html = generate_html(tmp_path / "runs", tmp_path / "queue", tmp_path)
        assert "OWLMIND" in html

    def test_contains_run_goal(self, tmp_path: Path) -> None:
        runs_dir = tmp_path / "runs"
        _make_run(runs_dir, "run-001", "DONE", goal="my unique task")
        html = generate_html(runs_dir, tmp_path / "queue", tmp_path)
        assert "my unique task" in html

    def test_contains_queue_item_goal(self, tmp_path: Path) -> None:
        runs_dir = tmp_path / "runs"
        runs_dir.mkdir()
        queue_dir = tmp_path / "queue"
        _make_queue_file(queue_dir, [{"id": "t1", "goal": "queue task xyz", "status": "PENDING"}])
        html = generate_html(runs_dir, queue_dir, tmp_path)
        assert "queue task xyz" in html

    def test_custom_title(self, tmp_path: Path) -> None:
        html = generate_html(tmp_path / "runs", tmp_path / "queue", tmp_path, title="My Dashboard")
        assert "My Dashboard" in html

    def test_auto_refresh_meta_tag(self, tmp_path: Path) -> None:
        html = generate_html(tmp_path / "runs", tmp_path / "queue", tmp_path)
        assert 'http-equiv="refresh"' in html

    def test_empty_runs_shows_placeholder(self, tmp_path: Path) -> None:
        html = generate_html(tmp_path / "runs", tmp_path / "queue", tmp_path)
        assert "Нет запусков" in html

    def test_empty_queue_shows_placeholder(self, tmp_path: Path) -> None:
        runs_dir = tmp_path / "runs"
        runs_dir.mkdir()
        html = generate_html(runs_dir, tmp_path / "queue", tmp_path)
        assert "Очередь пуста" in html

    def test_state_colors_embedded_in_html(self, tmp_path: Path) -> None:
        runs_dir = tmp_path / "runs"
        _make_run(runs_dir, "run-001", "DONE")
        html = generate_html(runs_dir, tmp_path / "queue", tmp_path)
        assert "#22c55e" in html  # DONE color


# ===========================================================================
# TestReadSchedules
# ===========================================================================


class TestReadSchedules:
    def test_returns_empty_when_missing(self, tmp_path: Path) -> None:
        from owlmind.web_dashboard import _read_schedules

        result = _read_schedules(tmp_path)
        assert result == []

    def test_reads_valid_schedules(self, tmp_path: Path) -> None:
        from owlmind.web_dashboard import _read_schedules

        schedules = [
            {"id": "s1", "type": "daily", "time": "08:00", "goal": "daily task"},
            {"id": "s2", "type": "weekly", "day": "Monday", "time": "10:00", "goal": "weekly"},
        ]
        (tmp_path / "schedules.json").write_text(json.dumps(schedules))
        result = _read_schedules(tmp_path)
        assert len(result) == 2
        assert result[0]["id"] == "s1"
        assert result[1]["day"] == "Monday"

    def test_returns_empty_on_invalid_json(self, tmp_path: Path) -> None:
        from owlmind.web_dashboard import _read_schedules

        (tmp_path / "schedules.json").write_text("{invalid json!!}")
        result = _read_schedules(tmp_path)
        assert result == []


# ===========================================================================
# TestScanRunsEdgeCases
# ===========================================================================


class TestScanRunsEdgeCases:
    def test_skips_non_directory_entries(self, tmp_path: Path) -> None:
        """_scan_runs must skip plain files in runs_dir (line 30)."""
        _make_run(tmp_path, "run-001", "DONE", "real task")
        (tmp_path / "README.txt").write_text("not a run")
        runs = _scan_runs(tmp_path)
        assert len(runs) == 1
        assert runs[0]["run_id"] == "run-001"


# ===========================================================================
# TestScanQueueErrorHandling
# ===========================================================================


class TestScanQueueErrorHandling:
    def test_handles_malformed_jsonl(self, tmp_path: Path) -> None:
        """_scan_queue exception handler fires on malformed JSONL (lines 60-61)."""
        queue_dir = tmp_path / "queue"
        queue_dir.mkdir()
        (queue_dir / "queue.jsonl").write_text("NOT_VALID_JSON\n")
        items = _scan_queue(queue_dir)
        assert isinstance(items, list)


# ===========================================================================
# TestGenerateHtmlScheduleRow
# ===========================================================================


class TestGenerateHtmlScheduleRow:
    def test_weekly_schedule_includes_day(self, tmp_path: Path) -> None:
        """sched_row for weekly type includes the day field (lines 127-128)."""
        schedules = [
            {
                "id": "sched-1",
                "type": "weekly",
                "day": "Friday",
                "time": "09:00",
                "goal": "weekly",
            }
        ]
        (tmp_path / "schedules.json").write_text(json.dumps(schedules))
        runs_dir = tmp_path / "runs"
        runs_dir.mkdir()
        html = generate_html(runs_dir, tmp_path / "queue", tmp_path)
        assert "Friday" in html

    def test_daily_schedule_no_day(self, tmp_path: Path) -> None:
        """sched_row for daily type does not include a day suffix."""
        schedules = [{"id": "sched-2", "type": "daily", "time": "07:00", "goal": "daily task"}]
        (tmp_path / "schedules.json").write_text(json.dumps(schedules))
        runs_dir = tmp_path / "runs"
        runs_dir.mkdir()
        html = generate_html(runs_dir, tmp_path / "queue", tmp_path)
        assert "daily task" in html
        assert "daily 07:00 UTC" in html

    def test_no_schedules_shows_placeholder(self, tmp_path: Path) -> None:
        """Empty schedules renders the 'Нет расписаний' placeholder."""
        runs_dir = tmp_path / "runs"
        runs_dir.mkdir()
        html = generate_html(runs_dir, tmp_path / "queue", tmp_path)
        assert "Нет расписаний" in html


# ===========================================================================
# TestUpdateDashboard
# ===========================================================================


class TestUpdateDashboard:
    def test_creates_html_file(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        # Redirect output to tmp_path instead of home dir
        output_path = tmp_path / "owlmind_dashboard.html"

        monkeypatch.setattr(
            "owlmind.web_dashboard.Path",
            lambda *args: output_path if args == ("~",) else Path(*args),
        )
        # Just test that generate_html runs and returns non-empty string
        runs_dir = tmp_path / "runs"
        runs_dir.mkdir()
        html = generate_html(runs_dir, tmp_path / "queue", tmp_path)
        assert len(html) > 100

    def test_update_dashboard_returns_path(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        import os

        monkeypatch.setattr(os.path, "expanduser", lambda _: str(tmp_path))
        runs_dir = tmp_path / "runs"
        runs_dir.mkdir()
        result = update_dashboard(runs_dir, tmp_path / "queue", tmp_path)
        assert result.exists()
        assert result.suffix == ".html"
