"""Integration tests for LLMRouter + LLMCache interaction.

Verifies that the router correctly uses the cache for hit/miss scenarios,
stores responses after successful provider calls, and skips provider calls
when a cached response is available.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest

from owlmind.llm.cache import LLMCache
from owlmind.llm.router import LLMRouter

# ---------------------------------------------------------------------------
# FakeDriver — same pattern as tests/test_router.py
# ---------------------------------------------------------------------------


class FakeDriver:
    """Fake LLM driver that records calls and returns canned responses."""

    def __init__(
        self,
        provider_name: str,
        *,
        plan_response: dict[str, Any] | None = None,
        judge_response: dict[str, Any] | None = None,
        error: Exception | None = None,
    ) -> None:
        self._name = provider_name
        self._plan_response = plan_response or {}
        self._judge_response = judge_response or {}
        self._error = error
        self.plan_calls: list[dict[str, Any]] = []
        self.judge_calls: list[dict[str, Any]] = []

    @property
    def name(self) -> str:
        return self._name

    @property
    def supports_structured(self) -> bool:
        return True

    def plan(
        self,
        planner_request: dict[str, Any],
        schema: dict[str, Any],
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        self.plan_calls.append(planner_request)
        if self._error:
            raise self._error
        meta = {"provider": self._name, "model": "test", "latency_ms": 50, "usage": {}}
        return self._plan_response, meta

    def judge(
        self,
        judge_request: dict[str, Any],
        schema: dict[str, Any],
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        self.judge_calls.append(judge_request)
        if self._error:
            raise self._error
        meta = {"provider": self._name, "model": "test", "latency_ms": 50, "usage": {}}
        return self._judge_response, meta


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def cache_dir(tmp_path: Path) -> Path:
    d = tmp_path / "llm_cache"
    d.mkdir()
    return d


@pytest.fixture
def cache(cache_dir: Path) -> LLMCache:
    return LLMCache(cache_dir, ttl_seconds=3600)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestRouterCacheMiss:
    """On cache miss the router should call the provider and store the result."""

    def test_plan_cache_miss_calls_provider(self, cache: LLMCache) -> None:
        driver = FakeDriver("openai", plan_response={"run_id": "abc"})
        router = LLMRouter(
            drivers={"openai": driver},
            planner_providers=["openai"],
            judge_providers=[],
            cache=cache,
        )

        result, meta = router.plan({"prompt": "hello"}, {"type": "object"})

        assert result["run_id"] == "abc"
        assert len(driver.plan_calls) == 1
        # Meta should NOT have cache_hit
        assert meta.get("cache_hit") is not True

    def test_plan_cache_miss_stores_response(self, cache: LLMCache) -> None:
        driver = FakeDriver("openai", plan_response={"run_id": "stored"})
        router = LLMRouter(
            drivers={"openai": driver},
            planner_providers=["openai"],
            judge_providers=[],
            cache=cache,
        )

        router.plan({"prompt": "store_me"}, {"type": "object"})

        # Verify the cache now contains the response
        key = cache.make_key({"prompt": "store_me"}, {"type": "object"})
        cached = cache.get(key)
        assert cached is not None
        resp, _meta = cached
        assert resp["run_id"] == "stored"

    def test_judge_cache_miss_calls_provider(self, cache: LLMCache) -> None:
        driver = FakeDriver("anthropic", judge_response={"verdict": "APPROVED"})
        router = LLMRouter(
            drivers={"anthropic": driver},
            planner_providers=[],
            judge_providers=["anthropic"],
            cache=cache,
        )

        result, meta = router.judge({"run_id": "j1"}, {"type": "object"})

        assert result["verdict"] == "APPROVED"
        assert len(driver.judge_calls) == 1


class TestRouterCacheHit:
    """On cache hit the router should return cached data and skip providers."""

    def test_plan_cache_hit_skips_provider(self, cache: LLMCache) -> None:
        driver = FakeDriver("openai", plan_response={"run_id": "fresh"})
        router = LLMRouter(
            drivers={"openai": driver},
            planner_providers=["openai"],
            judge_providers=[],
            cache=cache,
        )

        request = {"prompt": "cached_test"}
        schema = {"type": "object"}

        # First call: cache miss -- provider is called
        result1, meta1 = router.plan(request, schema)
        assert result1["run_id"] == "fresh"
        assert len(driver.plan_calls) == 1

        # Second call: same request -- should be a cache hit
        result2, meta2 = router.plan(request, schema)
        assert result2["run_id"] == "fresh"
        assert meta2.get("cache_hit") is True
        # Provider should NOT have been called again
        assert len(driver.plan_calls) == 1

    def test_judge_cache_hit_skips_provider(self, cache: LLMCache) -> None:
        driver = FakeDriver("anthropic", judge_response={"verdict": "REJECTED"})
        router = LLMRouter(
            drivers={"anthropic": driver},
            planner_providers=[],
            judge_providers=["anthropic"],
            cache=cache,
        )

        request = {"run_id": "judge_cache"}
        schema = {"type": "object"}

        # First call: miss
        router.judge(request, schema)
        assert len(driver.judge_calls) == 1

        # Second call: hit
        result, meta = router.judge(request, schema)
        assert result["verdict"] == "REJECTED"
        assert meta.get("cache_hit") is True
        assert len(driver.judge_calls) == 1

    def test_different_requests_are_separate_cache_entries(
        self, cache: LLMCache
    ) -> None:
        driver = FakeDriver("openai", plan_response={"run_id": "resp"})
        router = LLMRouter(
            drivers={"openai": driver},
            planner_providers=["openai"],
            judge_providers=[],
            cache=cache,
        )

        schema = {"type": "object"}

        router.plan({"prompt": "alpha"}, schema)
        router.plan({"prompt": "beta"}, schema)

        # Both should have hit the provider
        assert len(driver.plan_calls) == 2


class TestRouterCacheStats:
    """Cache statistics are updated correctly through router usage."""

    def test_stats_after_hit_and_miss(self, cache: LLMCache) -> None:
        driver = FakeDriver("openai", plan_response={"run_id": "x"})
        router = LLMRouter(
            drivers={"openai": driver},
            planner_providers=["openai"],
            judge_providers=[],
            cache=cache,
        )

        request = {"prompt": "stats_test"}
        schema = {}

        # Miss
        router.plan(request, schema)
        # Hit
        router.plan(request, schema)

        stats = cache.stats()
        assert stats["hits"] >= 1
        assert stats["misses"] >= 1
        assert stats["entries"] >= 1


class TestRouterWithoutCache:
    """Router without cache should work normally (no crash, no caching)."""

    def test_plan_no_cache(self) -> None:
        driver = FakeDriver("openai", plan_response={"run_id": "no_cache"})
        router = LLMRouter(
            drivers={"openai": driver},
            planner_providers=["openai"],
            judge_providers=[],
            cache=None,
        )

        assert router.cache_enabled is False

        result, meta = router.plan({"prompt": "test"}, {})
        assert result["run_id"] == "no_cache"
        assert len(driver.plan_calls) == 1

        # Second identical call should still call the provider
        router.plan({"prompt": "test"}, {})
        assert len(driver.plan_calls) == 2


class TestRouterCacheWithFallback:
    """Cache interacts correctly with provider fallback on errors."""

    def test_failed_provider_does_not_cache(self, cache: LLMCache) -> None:
        """When all providers fail, nothing should be cached."""
        driver = FakeDriver("openai", error=RuntimeError("Connection timeout"))
        router = LLMRouter(
            drivers={"openai": driver},
            planner_providers=["openai"],
            judge_providers=[],
            cache=cache,
        )

        with pytest.raises(RuntimeError, match="All providers failed"):
            router.plan({"prompt": "fail_test"}, {})

        # Cache should be empty
        key = cache.make_key({"prompt": "fail_test"}, {})
        assert cache.get(key) is None

    def test_fallback_provider_response_is_cached(self, cache: LLMCache) -> None:
        """When first provider fails but fallback succeeds, cache the fallback result."""
        d1 = FakeDriver("openai", error=RuntimeError("Connection timeout"))
        d2 = FakeDriver("anthropic", plan_response={"run_id": "fallback_cached"})
        router = LLMRouter(
            drivers={"openai": d1, "anthropic": d2},
            planner_providers=["openai", "anthropic"],
            judge_providers=[],
            cache=cache,
        )

        result, meta = router.plan({"prompt": "fallback_cache"}, {"type": "object"})
        assert result["run_id"] == "fallback_cached"
        assert meta["provider"] == "anthropic"

        # Verify the response is now cached
        key = cache.make_key({"prompt": "fallback_cache"}, {"type": "object"})
        cached = cache.get(key)
        assert cached is not None
        resp, _meta = cached
        assert resp["run_id"] == "fallback_cached"
