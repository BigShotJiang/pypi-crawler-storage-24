"""Tests for CI Evidence module."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

from owlmind.ci_evidence import build_ci_evidence


class TestBuildCIEvidence:
    def test_creates_json(self, tmp_path: Path) -> None:
        """Evidence file is created with valid JSON."""
        out = tmp_path / "evidence.json"
        result = build_ci_evidence(out)

        assert result == out
        assert out.exists()
        data = json.loads(out.read_text())
        assert "commit_sha" in data
        assert "timestamp" in data
        assert "checks_executed" in data
        assert "artifact_paths" in data

    def test_reads_github_env(self, tmp_path: Path) -> None:
        """Evidence reads GitHub Actions env vars."""
        env = {
            "GITHUB_SHA": "abc123",
            "GITHUB_WORKFLOW": "CI",
            "GITHUB_RUN_ID": "456",
            "GITHUB_RUN_NUMBER": "7",
            "GITHUB_REF": "refs/heads/main",
            "GITHUB_EVENT_NAME": "push",
        }
        out = tmp_path / "evidence.json"
        with patch.dict("os.environ", env, clear=False):
            build_ci_evidence(out)

        data = json.loads(out.read_text())
        assert data["commit_sha"] == "abc123"
        assert data["workflow_name"] == "CI"
        assert data["run_id"] == "456"
        assert data["ref"] == "refs/heads/main"

    def test_scans_reports_dir(self, tmp_path: Path) -> None:
        """Evidence lists artifact paths from reports dir."""
        reports = tmp_path / "reports"
        reports.mkdir()
        (reports / "junit.xml").write_text("<xml/>")
        (reports / "ruff.txt").write_text("ok")

        out = tmp_path / "evidence.json"
        build_ci_evidence(out, reports_dir=reports)

        data = json.loads(out.read_text())
        assert "junit.xml" in data["artifact_paths"]
        assert "ruff.txt" in data["artifact_paths"]

    def test_includes_checks(self, tmp_path: Path) -> None:
        """Evidence includes checks list."""
        out = tmp_path / "evidence.json"
        build_ci_evidence(out, checks=["ruff", "mypy", "pytest"])

        data = json.loads(out.read_text())
        assert data["checks_executed"] == ["ruff", "mypy", "pytest"]

    def test_missing_reports_dir(self, tmp_path: Path) -> None:
        """Evidence handles missing reports dir gracefully."""
        out = tmp_path / "evidence.json"
        build_ci_evidence(out, reports_dir=tmp_path / "nonexistent")

        data = json.loads(out.read_text())
        assert data["artifact_paths"] == []

    def test_creates_parent_dirs(self, tmp_path: Path) -> None:
        """Evidence creates parent directories."""
        out = tmp_path / "deep" / "nested" / "evidence.json"
        build_ci_evidence(out)
        assert out.exists()

    def test_no_env_vars(self, tmp_path: Path) -> None:
        """Evidence works without GitHub env vars."""
        env_keys = [
            "GITHUB_SHA",
            "GITHUB_WORKFLOW",
            "GITHUB_RUN_ID",
            "GITHUB_RUN_NUMBER",
            "GITHUB_REF",
            "GITHUB_EVENT_NAME",
        ]
        clean_env = {k: "" for k in env_keys}
        out = tmp_path / "evidence.json"
        with patch.dict("os.environ", clean_env):
            build_ci_evidence(out)

        data = json.loads(out.read_text())
        assert data["commit_sha"] == ""
