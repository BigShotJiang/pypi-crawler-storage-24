"""Session model — multi-goal chaining with audit log and protocol.

A session runs a sequence of goals (from goals.yaml) as individual
autopilot runs, producing a unified session protocol and export.
"""

from __future__ import annotations

import fcntl
import json
import logging
import uuid
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger(__name__)

# Session statuses
SESSION_RUNNING = "RUNNING"
SESSION_BLOCKED = "BLOCKED"
SESSION_DONE = "DONE"
SESSION_FAILED = "FAILED"
SESSION_STOPPED = "STOPPED"


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------


@dataclass
class RollbackPolicy:
    """Rollback policy for a single goal."""

    mode: str = "none"  # none | worktree_reset | branch_delete | manual
    require_approval: bool = True


@dataclass
class GoalSpec:
    """A single goal in a session."""

    id: str
    goal: str
    workspace: str = "."
    sandbox: bool = False
    use_llm: str = "both"
    use_worker: str = "none"
    provider_planner: str | None = None
    provider_judge: str | None = None
    max_steps: int = 200
    interval_sec: float = 1.0
    export_on_done: bool = True
    stop_on_approval: bool = True
    stop_on_blocked: bool = True
    notes: str = ""
    # DAG fields
    depends_on: list[str] = field(default_factory=list)
    concurrency_group: str = ""
    # Rollback
    rollback: RollbackPolicy = field(default_factory=RollbackPolicy)
    # Agent / skill pack assignment
    agent_id: str = ""
    skill_pack: str = ""


@dataclass
class GoalRunInfo:
    """Tracks which run corresponds to a goal."""

    goal_id: str
    run_id: str
    status: str = "pending"  # pending | running | blocked | done | failed
    started_at: str = ""
    ended_at: str = ""
    agent_id: str = ""


@dataclass
class SessionMeta:
    """Persistent session metadata."""

    session_id: str
    created_at: str
    updated_at: str
    status: str  # RUNNING | BLOCKED | DONE | FAILED | STOPPED
    current_goal_index: int = 0
    goals: list[GoalSpec] = field(default_factory=list)
    runs: list[GoalRunInfo] = field(default_factory=list)
    last_block_reason: str = ""
    config: dict[str, Any] = field(default_factory=dict)
    # DAG / concurrency settings
    max_concurrency: int = 1
    continue_on_fail: bool = False


# ---------------------------------------------------------------------------
# Session lock (fcntl.flock)
# ---------------------------------------------------------------------------


class SessionLock:
    """File-based session lock using fcntl.flock."""

    def __init__(self, lock_path: Path) -> None:
        self._path = lock_path
        self._file: Any = None

    def acquire(self) -> bool:
        """Try to acquire an exclusive non-blocking lock."""
        self._path.parent.mkdir(parents=True, exist_ok=True)
        try:
            self._file = self._path.open("w")
            fcntl.flock(self._file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            return True
        except OSError:
            if self._file:
                self._file.close()
                self._file = None
            return False

    def release(self) -> None:
        """Release the lock."""
        if self._file:
            try:
                fcntl.flock(self._file.fileno(), fcntl.LOCK_UN)
                self._file.close()
            except OSError:
                pass
            self._file = None

    def __enter__(self) -> SessionLock:
        if not self.acquire():
            msg = f"Could not acquire session lock: {self._path}"
            raise RuntimeError(msg)
        return self

    def __exit__(self, *args: object) -> None:
        self.release()


# ---------------------------------------------------------------------------
# Goals parsing
# ---------------------------------------------------------------------------


def parse_goals_file(path: Path) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Parse a goals.yaml file. Returns (defaults_dict, goals_list)."""
    content = yaml.safe_load(path.read_text()) or {}

    defaults = content.get("defaults", {})
    goals_raw = content.get("goals", [])

    if not goals_raw:
        msg = f"No goals found in {path}"
        raise ValueError(msg)

    return defaults, goals_raw


def resolve_goals(
    defaults: dict[str, Any],
    goals_raw: list[dict[str, Any]],
    base_workspace: str,
) -> list[GoalSpec]:
    """Merge defaults into each goal and resolve workspaces."""
    resolved: list[GoalSpec] = []

    for i, g in enumerate(goals_raw):
        merged = {**defaults, **g}

        goal_id = merged.get("id", f"G{i + 1}")
        goal_text = merged.get("goal", "")
        if not goal_text:
            msg = f"Goal {goal_id} has no 'goal' text"
            raise ValueError(msg)

        # Resolve workspace relative to base
        ws = merged.get("workspace", base_workspace)
        ws_path = Path(ws)
        if not ws_path.is_absolute():
            ws_path = Path(base_workspace).resolve() / ws_path
        ws = str(ws_path.resolve())

        # Parse rollback policy
        rollback_raw = merged.get("rollback", {})
        if isinstance(rollback_raw, dict):
            rb_mode = rollback_raw.get("mode", "none")
            rb_approval = rollback_raw.get(
                "require_approval",
                rb_mode != "none",
            )
            rollback = RollbackPolicy(mode=rb_mode, require_approval=rb_approval)
        else:
            rollback = RollbackPolicy()

        resolved.append(
            GoalSpec(
                id=goal_id,
                goal=goal_text,
                workspace=ws,
                sandbox=merged.get("sandbox", False),
                use_llm=merged.get("use_llm", "both"),
                use_worker=merged.get("use_worker", "none"),
                provider_planner=merged.get("provider_planner"),
                provider_judge=merged.get("provider_judge"),
                max_steps=merged.get("max_steps", 200),
                interval_sec=merged.get("interval_sec", 1.0),
                export_on_done=merged.get("export_on_done", True),
                stop_on_approval=merged.get("stop_on_approval", True),
                stop_on_blocked=merged.get("stop_on_blocked", True),
                notes=merged.get("notes", ""),
                depends_on=merged.get("depends_on", []),
                concurrency_group=merged.get("concurrency_group", ""),
                rollback=rollback,
                agent_id=merged.get("agent_id", ""),
                skill_pack=merged.get("skill_pack", ""),
            )
        )

    return resolved


# ---------------------------------------------------------------------------
# Session CRUD
# ---------------------------------------------------------------------------


def _now_iso() -> str:
    return datetime.now(UTC).isoformat()


def generate_session_id() -> str:
    """Generate a unique session ID."""
    return f"session-{uuid.uuid4().hex[:12]}"


def _session_dir(sessions_dir: Path, session_id: str) -> Path:
    return sessions_dir / session_id


def create_session(
    goals_file: Path,
    workspace: str,
    sessions_dir: Path,
    *,
    policies_dir: str = "policies",
    runs_dir: str = "runs",
    ledger_dir: str = "ledger",
    max_concurrency: int = 1,
    continue_on_fail: bool = False,
) -> SessionMeta:
    """Create a new session from a goals file."""
    defaults, goals_raw = parse_goals_file(goals_file)
    goals = resolve_goals(defaults, goals_raw, workspace)

    session_id = generate_session_id()
    now = _now_iso()

    meta = SessionMeta(
        session_id=session_id,
        created_at=now,
        updated_at=now,
        status=SESSION_RUNNING,
        current_goal_index=0,
        goals=goals,
        runs=[],
        max_concurrency=max_concurrency,
        continue_on_fail=continue_on_fail,
        config={
            "goals_file": str(goals_file),
            "workspace": workspace,
            "policies_dir": policies_dir,
            "runs_dir": runs_dir,
            "sessions_dir": str(sessions_dir),
            "ledger_dir": ledger_dir,
        },
    )

    # Write files
    sdir = _session_dir(sessions_dir, session_id)
    sdir.mkdir(parents=True, exist_ok=True)

    save_session(meta, sessions_dir)

    # Save resolved goals
    goals_data = {
        "version": 1,
        "defaults": defaults,
        "goals": [asdict(g) for g in goals],
    }
    (sdir / "goals_resolved.yaml").write_text(
        yaml.dump(goals_data, default_flow_style=False, allow_unicode=True),
    )

    # Initial event
    append_session_event(
        session_id,
        sessions_dir,
        {
            "event": "SESSION_CREATED",
            "session_id": session_id,
            "goals_count": len(goals),
        },
    )

    # Initial protocol
    render_protocol(session_id, sessions_dir, Path(runs_dir))

    return meta


def save_session(meta: SessionMeta, sessions_dir: Path) -> None:
    """Save session metadata to disk."""
    meta.updated_at = _now_iso()
    sdir = _session_dir(sessions_dir, meta.session_id)
    sdir.mkdir(parents=True, exist_ok=True)

    data = {
        "session_id": meta.session_id,
        "created_at": meta.created_at,
        "updated_at": meta.updated_at,
        "status": meta.status,
        "current_goal_index": meta.current_goal_index,
        "goals": [asdict(g) for g in meta.goals],
        "runs": [asdict(r) for r in meta.runs],
        "last_block_reason": meta.last_block_reason,
        "config": meta.config,
        "max_concurrency": meta.max_concurrency,
        "continue_on_fail": meta.continue_on_fail,
    }
    (sdir / "session_meta.json").write_text(json.dumps(data, indent=2))


def load_session(session_id: str, sessions_dir: Path) -> SessionMeta:
    """Load session metadata from disk."""
    sdir = _session_dir(sessions_dir, session_id)
    meta_path = sdir / "session_meta.json"

    if not meta_path.exists():
        msg = f"Session not found: {session_id}"
        raise FileNotFoundError(msg)

    data = json.loads(meta_path.read_text())

    goals = []
    for g_raw in data.get("goals", []):
        # Handle rollback dict → RollbackPolicy
        rb_raw = g_raw.pop("rollback", {})
        rb = RollbackPolicy(**rb_raw) if isinstance(rb_raw, dict) else RollbackPolicy()
        goals.append(GoalSpec(**g_raw, rollback=rb))

    runs = [GoalRunInfo(**r) for r in data.get("runs", [])]

    return SessionMeta(
        session_id=data["session_id"],
        created_at=data["created_at"],
        updated_at=data["updated_at"],
        status=data["status"],
        current_goal_index=data.get("current_goal_index", 0),
        goals=goals,
        runs=runs,
        last_block_reason=data.get("last_block_reason", ""),
        config=data.get("config", {}),
        max_concurrency=data.get("max_concurrency", 1),
        continue_on_fail=data.get("continue_on_fail", False),
    )


# ---------------------------------------------------------------------------
# Session event log (append-only JSONL)
# ---------------------------------------------------------------------------


def append_session_event(
    session_id: str,
    sessions_dir: Path,
    event: dict[str, Any],
) -> None:
    """Append an event to the session JSONL log with file locking."""
    sdir = _session_dir(sessions_dir, session_id)
    sdir.mkdir(parents=True, exist_ok=True)
    log_path = sdir / "session.jsonl"

    event["timestamp"] = _now_iso()

    line = json.dumps(event, default=str) + "\n"

    with log_path.open("a") as f:
        fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        try:
            f.write(line)
        finally:
            fcntl.flock(f.fileno(), fcntl.LOCK_UN)


def read_session_events(session_id: str, sessions_dir: Path) -> list[dict[str, Any]]:
    """Read all session events."""
    log_path = _session_dir(sessions_dir, session_id) / "session.jsonl"
    if not log_path.exists():
        return []
    events = []
    for line in log_path.read_text().splitlines():
        if line.strip():
            events.append(json.loads(line))
    return events


# ---------------------------------------------------------------------------
# Session protocol renderer
# ---------------------------------------------------------------------------


def render_protocol(
    session_id: str,
    sessions_dir: Path,
    runs_dir: Path,
) -> str:
    """Render protocol.md from session metadata and run artifacts.

    Returns the rendered content and writes it to sessions/<id>/protocol.md.
    """
    meta = load_session(session_id, sessions_dir)
    lines: list[str] = []

    # 1) Overview
    lines.extend(
        [
            f"# Session Protocol — {meta.session_id}",
            "",
            f"- **Created:** {meta.created_at}",
            f"- **Updated:** {meta.updated_at}",
            f"- **Status:** {meta.status}",
            f"- **Goals:** {len(meta.goals)}",
            f"- **Current index:** {meta.current_goal_index}",
        ]
    )

    if meta.config:
        ws = meta.config.get("workspace", "?")
        lines.append(f"- **Workspace:** {ws}")

    # Concurrency info
    if meta.max_concurrency > 1:
        lines.append(f"- **Max concurrency:** {meta.max_concurrency}")
    if meta.continue_on_fail:
        lines.append("- **Continue on fail:** yes")

    # 2) DAG view (if any goal has dependencies)
    has_deps = any(g.depends_on for g in meta.goals)
    if has_deps:
        lines.extend(["", "## DAG View"])
        for g in meta.goals:
            dep_str = f" ← {', '.join(g.depends_on)}" if g.depends_on else ""
            run = next((r for r in meta.runs if r.goal_id == g.id), None)
            status = run.status if run else "pending"
            lines.append(f"- {g.id} [{status}]{dep_str}")

    # 3) Goals table
    lines.extend(
        [
            "",
            "## Goals",
            "",
            "| # | ID | Goal | Deps | Run ID | Status |",
            "|---|-----|------|------|--------|--------|",
        ]
    )

    run_map = {r.goal_id: r for r in meta.runs}
    for i, g in enumerate(meta.goals):
        run = run_map.get(g.id)
        run_id = run.run_id if run else "-"
        status = run.status if run else "pending"
        goal_short = g.goal[:50] + ("..." if len(g.goal) > 50 else "")
        deps = ", ".join(g.depends_on) if g.depends_on else "-"
        lines.append(
            f"| {i} | {g.id} | {goal_short} | {deps} | {run_id} | {status} |",
        )

    # 3) Per-goal summaries
    lines.extend(["", "## Goal Summaries"])

    for g in meta.goals:
        run = run_map.get(g.id)
        lines.extend(["", f"### {g.id}: {g.goal[:80]}"])

        if g.notes:
            lines.append(f"*{g.notes}*")

        if not run:
            lines.append("Status: pending")
            continue

        lines.append(f"- Run: `{run.run_id}`")
        lines.append(f"- Status: {run.status}")

        if run.started_at:
            lines.append(f"- Started: {run.started_at}")
        if run.ended_at:
            lines.append(f"- Ended: {run.ended_at}")

        # Try to read pr_pack.md for summary
        pr_pack_path = runs_dir / run.run_id / "pr_pack.md"
        if pr_pack_path.exists():
            pr_content = pr_pack_path.read_text()
            # Extract PR Description section (compact)
            summary = _extract_section(pr_content, "PR Description", max_chars=500)
            if summary:
                lines.extend(["", "**Summary:**", summary])

        # Fallback: read summary.json
        summary_path = runs_dir / run.run_id / "summary.json"
        if not pr_pack_path.exists() and summary_path.exists():
            try:
                sdata = json.loads(summary_path.read_text())
                report = sdata.get("report", {})
                lines.append(f"- Verdict: {report.get('status', '?')}")
            except (json.JSONDecodeError, KeyError):
                pass

    # 4) Rollback policies (if any configured)
    rollback_goals = [g for g in meta.goals if g.rollback.mode != "none"]
    if rollback_goals:
        lines.extend(["", "## Rollback Policies"])
        for g in rollback_goals:
            run = run_map.get(g.id)
            status = run.status if run else "pending"
            approval = "yes" if g.rollback.require_approval else "no"
            lines.append(
                f"- {g.id}: mode={g.rollback.mode}, approval={approval}, status={status}",
            )

    # 5) Decisions & Blocks
    if meta.last_block_reason:
        lines.extend(["", "## Decisions & Blocks", f"- Last block: {meta.last_block_reason}"])

    # Add approval blocks from events
    events = read_session_events(session_id, sessions_dir)
    block_events = [e for e in events if e.get("event") in ("GOAL_BLOCKED", "SESSION_BLOCKED")]
    if block_events:
        if not meta.last_block_reason:
            lines.extend(["", "## Decisions & Blocks"])
        for be in block_events[-5:]:  # last 5
            reason = be.get("reason", "?")
            goal_id = be.get("goal_id", "")
            lines.append(f"- [{be.get('event')}] {goal_id}: {reason}")

    # 5) Next actions
    lines.extend(["", "## Next Actions"])
    if meta.status == SESSION_BLOCKED:
        lines.append(f"Session is blocked: {meta.last_block_reason}")
        # Check for approval commands in last blocked goal
        for run in reversed(meta.runs):
            if run.status == "blocked":
                lines.append(f"  owlmind cycle approve --run-id {run.run_id} --token <TOKEN>")
                break
        lines.append(f"  owlmind session resume --session-id {meta.session_id}")
    elif meta.status in (SESSION_RUNNING, SESSION_STOPPED):
        lines.append(f"  owlmind session resume --session-id {meta.session_id}")
    elif meta.status == SESSION_DONE:
        lines.append(f"  owlmind session export --session-id {meta.session_id}")
    elif meta.status == SESSION_FAILED:
        lines.append("Session failed. Review run logs for details.")
        lines.append(f"  owlmind session status --session-id {meta.session_id}")

    content = "\n".join(lines) + "\n"

    # Write protocol.md
    protocol_path = _session_dir(sessions_dir, session_id) / "protocol.md"
    protocol_path.write_text(content)

    return content


def _extract_section(text: str, heading: str, *, max_chars: int = 500) -> str:
    """Extract content under a markdown heading, truncated."""
    lines = text.splitlines()
    in_section = False
    section_lines: list[str] = []

    for line in lines:
        if line.strip().startswith("#") and heading.lower() in line.lower():
            in_section = True
            continue
        if in_section and line.strip().startswith("#"):
            break
        if in_section:
            section_lines.append(line)

    result = "\n".join(section_lines).strip()
    if len(result) > max_chars:
        result = result[:max_chars] + "..."
    return result


# ---------------------------------------------------------------------------
# Session context for planner (compact previous goal summaries)
# ---------------------------------------------------------------------------


def build_session_context(
    meta: SessionMeta,
    runs_dir: Path,
    *,
    max_goals: int = 3,
    max_chars: int = 500,
) -> str:
    """Build compact context from previous goals for planner injection.

    Returns a text block with last N goal summaries. No secrets or diffs.
    """
    completed_runs = [r for r in meta.runs if r.status == "done"]
    recent = completed_runs[-max_goals:]

    if not recent:
        return ""

    parts = ["## Session Context (previous goals)"]
    for run in recent:
        goal = next((g for g in meta.goals if g.id == run.goal_id), None)
        goal_text = goal.goal[:80] if goal else "?"

        parts.append(f"\n### {run.goal_id}: {goal_text}")
        parts.append(f"Run: {run.run_id} | Status: {run.status}")

        pr_pack_path = runs_dir / run.run_id / "pr_pack.md"
        if pr_pack_path.exists():
            summary = _extract_section(
                pr_pack_path.read_text(),
                "PR Description",
                max_chars=max_chars,
            )
            if summary:
                parts.append(summary)

    return "\n".join(parts)
