"""S3/MinIO-backed ArtifactStorage using aiobotocore.

Stores raw artifact bytes in an S3-compatible object store.
Metadata (sha256, size, key) stays in PostgreSQL.

Activate via::

    create_storage(backend="postgres", postgres_dsn="...", s3_bucket="my-bucket")

Requires: ``pip install 'owlmind[s3]'``
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any

logger = logging.getLogger(__name__)


class S3ArtifactStorage:
    """Async ``ArtifactStorage`` backed by S3-compatible object storage.

    The aiobotocore client is created lazily on first use
    (matching ``PostgresPool`` pattern).
    """

    def __init__(
        self,
        bucket: str,
        *,
        endpoint_url: str | None = None,
        region_name: str = "us-east-1",
        aws_access_key_id: str | None = None,
        aws_secret_access_key: str | None = None,
    ) -> None:
        self._bucket = bucket
        self._endpoint_url = endpoint_url
        self._region_name = region_name
        self._aws_access_key_id = aws_access_key_id
        self._aws_secret_access_key = aws_secret_access_key

        self._client: Any = None
        self._ctx: Any = None
        self._lock = asyncio.Lock()

    async def _ensure_client(self) -> Any:
        """Create the aiobotocore S3 client on first call."""
        if self._client is not None:
            return self._client
        async with self._lock:
            if self._client is not None:
                return self._client
            import aiobotocore.session

            session = aiobotocore.session.get_session()
            kwargs: dict[str, Any] = {
                "service_name": "s3",
                "region_name": self._region_name,
            }
            if self._endpoint_url:
                kwargs["endpoint_url"] = self._endpoint_url
            if self._aws_access_key_id:
                kwargs["aws_access_key_id"] = self._aws_access_key_id
                kwargs["aws_secret_access_key"] = self._aws_secret_access_key

            self._ctx = session.create_client(**kwargs)
            self._client = await self._ctx.__aenter__()
            logger.info(
                "S3 client initialised: bucket=%s endpoint=%s",
                self._bucket,
                self._endpoint_url or "AWS",
            )
            return self._client

    async def put(
        self,
        key: str,
        data: bytes,
        *,
        content_type: str = "application/octet-stream",
    ) -> None:
        """Upload artifact bytes."""
        client = await self._ensure_client()
        await client.put_object(
            Bucket=self._bucket,
            Key=key,
            Body=data,
            ContentType=content_type,
        )

    async def get(self, key: str) -> bytes:
        """Download artifact bytes. Raises ``KeyError`` if not found."""
        client = await self._ensure_client()
        try:
            resp = await client.get_object(Bucket=self._bucket, Key=key)
            async with resp["Body"] as stream:
                data: bytes = await stream.read()
                return data
        except client.exceptions.NoSuchKey:
            raise KeyError(key) from None

    async def delete(self, key: str) -> None:
        """Delete an artifact. No-op if key does not exist."""
        client = await self._ensure_client()
        await client.delete_object(Bucket=self._bucket, Key=key)

    async def close(self) -> None:
        """Close the aiobotocore client session."""
        if self._ctx is not None:
            await self._ctx.__aexit__(None, None, None)
            self._client = None
            self._ctx = None
