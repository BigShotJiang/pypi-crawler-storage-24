"""PostgreSQL-backed storage adapters for RunStorage, LedgerStorage, SessionStorage.

Uses ``asyncpg`` for async PostgreSQL communication with a shared
connection pool (lazy-initialized).

Activate via::

    create_storage(backend="postgres", postgres_dsn="postgresql://user:pass@host/db")

Requires: ``pip install 'owlmind[postgres]'``
"""

from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import asdict
from datetime import UTC, datetime
from datetime import date as date_type
from pathlib import Path
from typing import Any

from owlmind.evidence import (
    _CHAIN_FIELDS,
    _GENESIS_HASH,
    ChainVerifyResult,
    canonical_json,
)
from owlmind.ledger import UsageEntry, UsageTotals
from owlmind.session import GoalRunInfo, GoalSpec, RollbackPolicy, SessionMeta
from owlmind.utils import sha256

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Schema (applied lazily via CREATE TABLE IF NOT EXISTS)
# ---------------------------------------------------------------------------

_PG_SCHEMA = """\
-- Runs
CREATE TABLE IF NOT EXISTS runs (
    run_id      TEXT PRIMARY KEY,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS run_events (
    run_id      TEXT NOT NULL REFERENCES runs(run_id),
    seq         INTEGER NOT NULL,
    prev_hash   TEXT NOT NULL,
    hash        TEXT NOT NULL,
    payload     JSONB NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (run_id, seq)
);

CREATE TABLE IF NOT EXISTS run_artifacts (
    run_id      TEXT NOT NULL REFERENCES runs(run_id),
    filename    TEXT NOT NULL,
    content     BYTEA,
    storage_key TEXT,
    sha256      TEXT NOT NULL,
    size_bytes  BIGINT NOT NULL,
    kind        TEXT NOT NULL DEFAULT 'binary',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (run_id, filename)
);

CREATE TABLE IF NOT EXISTS run_meta (
    run_id      TEXT PRIMARY KEY REFERENCES runs(run_id),
    meta        JSONB NOT NULL DEFAULT '{}',
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS run_summaries (
    run_id      TEXT PRIMARY KEY REFERENCES runs(run_id),
    summary     JSONB NOT NULL DEFAULT '{}',
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Ledger
CREATE TABLE IF NOT EXISTS ledger_entries (
    id              BIGSERIAL PRIMARY KEY,
    ts              TIMESTAMPTZ NOT NULL,
    run_id          TEXT NOT NULL,
    stage           TEXT NOT NULL,
    provider        TEXT NOT NULL,
    model           TEXT NOT NULL,
    input_tokens    INTEGER NOT NULL DEFAULT 0,
    output_tokens   INTEGER NOT NULL DEFAULT 0,
    total_tokens    INTEGER NOT NULL DEFAULT 0,
    estimated_usd   DOUBLE PRECISION NOT NULL DEFAULT 0.0,
    latency_ms      INTEGER NOT NULL DEFAULT 0,
    price_per_1k_in DOUBLE PRECISION NOT NULL DEFAULT 0.0,
    price_per_1k_out DOUBLE PRECISION NOT NULL DEFAULT 0.0,
    currency        TEXT NOT NULL DEFAULT 'USD'
);
CREATE INDEX IF NOT EXISTS idx_ledger_ts ON ledger_entries(ts);
CREATE INDEX IF NOT EXISTS idx_ledger_run ON ledger_entries(run_id);

-- Sessions
CREATE TABLE IF NOT EXISTS sessions (
    session_id  TEXT PRIMARY KEY,
    meta        JSONB NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS session_events (
    id          BIGSERIAL PRIMARY KEY,
    session_id  TEXT NOT NULL REFERENCES sessions(session_id),
    event       JSONB NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_sess_events ON session_events(session_id);

-- Skill Packs
CREATE TABLE IF NOT EXISTS skill_packs (
    pack_id         TEXT PRIMARY KEY,
    name            TEXT NOT NULL,
    description     TEXT NOT NULL DEFAULT '',
    tags            JSONB NOT NULL DEFAULT '[]',
    latest_version  TEXT NOT NULL DEFAULT '',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS skill_pack_versions (
    pack_id         TEXT NOT NULL REFERENCES skill_packs(pack_id) ON DELETE CASCADE,
    version         TEXT NOT NULL,
    archive_key     TEXT NOT NULL DEFAULT '',
    sha256          TEXT NOT NULL DEFAULT '',
    changelog       TEXT NOT NULL DEFAULT '',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (pack_id, version)
);
CREATE INDEX IF NOT EXISTS idx_spv_pack ON skill_pack_versions(pack_id);

-- Agents
CREATE TABLE IF NOT EXISTS agents (
    agent_id        TEXT PRIMARY KEY,
    hostname        TEXT NOT NULL DEFAULT '',
    capabilities    JSONB NOT NULL DEFAULT '[]',
    max_concurrent  INTEGER NOT NULL DEFAULT 1,
    status          TEXT NOT NULL DEFAULT 'idle',
    current_tasks   INTEGER NOT NULL DEFAULT 0,
    last_heartbeat  TIMESTAMPTZ NOT NULL DEFAULT now(),
    registered_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    meta            JSONB NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_agents_status ON agents(status);
CREATE INDEX IF NOT EXISTS idx_agents_heartbeat ON agents(last_heartbeat);

-- Run extended metadata (self-improvement analytics)
CREATE TABLE IF NOT EXISTS run_extended (
    run_id          TEXT PRIMARY KEY REFERENCES runs(run_id),
    prompts_used    JSONB NOT NULL DEFAULT '[]',
    commands_executed JSONB NOT NULL DEFAULT '[]',
    judge_verdict   TEXT NOT NULL DEFAULT '',
    llm_usage       JSONB NOT NULL DEFAULT '{}',
    duration_ms     BIGINT NOT NULL DEFAULT 0,
    error_details   TEXT NOT NULL DEFAULT '',
    tags            JSONB NOT NULL DEFAULT '[]',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_run_extended_verdict ON run_extended(judge_verdict);
CREATE INDEX IF NOT EXISTS idx_run_extended_created ON run_extended(created_at);

-- Improvements
CREATE TABLE IF NOT EXISTS improvements (
    improvement_id  TEXT PRIMARY KEY,
    run_id          TEXT NOT NULL DEFAULT '',
    category        TEXT NOT NULL,
    title           TEXT NOT NULL,
    description     TEXT NOT NULL DEFAULT '',
    patch           TEXT NOT NULL DEFAULT '',
    target_file     TEXT NOT NULL DEFAULT '',
    status          TEXT NOT NULL DEFAULT 'proposed',
    confidence      DOUBLE PRECISION NOT NULL DEFAULT 0.0,
    ab_test_id      TEXT NOT NULL DEFAULT '',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    applied_at      TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_improvements_status ON improvements(status);
CREATE INDEX IF NOT EXISTS idx_improvements_category ON improvements(category);

-- A/B tests
CREATE TABLE IF NOT EXISTS ab_tests (
    test_id         TEXT PRIMARY KEY,
    improvement_id  TEXT NOT NULL DEFAULT '',
    variant_a       TEXT NOT NULL DEFAULT 'baseline',
    variant_b       TEXT NOT NULL DEFAULT 'improved',
    metric          TEXT NOT NULL DEFAULT 'success_rate',
    runs_a          INTEGER NOT NULL DEFAULT 0,
    runs_b          INTEGER NOT NULL DEFAULT 0,
    score_a         DOUBLE PRECISION NOT NULL DEFAULT 0.0,
    score_b         DOUBLE PRECISION NOT NULL DEFAULT 0.0,
    status          TEXT NOT NULL DEFAULT 'pending',
    winner          TEXT NOT NULL DEFAULT '',
    min_runs        INTEGER NOT NULL DEFAULT 10,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at    TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_ab_tests_status ON ab_tests(status);
"""

_TEXT_SUFFIXES = frozenset({".txt", ".md", ".json", ".yaml", ".yml", ".patch", ".py", ".sh"})


# ===================================================================
# PostgresPool — shared lazy-initialized connection pool
# ===================================================================


class PostgresPool:
    """Lazy-initialized asyncpg connection pool.

    The pool is created on first use because ``create_storage()`` is synchronous.
    All three storage classes share the same pool instance.
    """

    def __init__(self, dsn: str, *, min_size: int = 2, max_size: int = 10) -> None:
        self._dsn = dsn
        self._min_size = min_size
        self._max_size = max_size
        self._pool: Any = None
        self._lock = asyncio.Lock()
        self._schema_applied = False

    async def _ensure_pool(self) -> Any:
        """Create pool and apply schema on first call."""
        if self._pool is not None:
            return self._pool
        async with self._lock:
            if self._pool is not None:
                return self._pool
            import asyncpg

            self._pool = await asyncpg.create_pool(
                self._dsn,
                min_size=self._min_size,
                max_size=self._max_size,
            )
            if not self._schema_applied:
                async with self._pool.acquire() as conn:
                    await conn.execute(_PG_SCHEMA)
                    # Idempotent migration for existing databases
                    await conn.execute(
                        "ALTER TABLE run_artifacts ADD COLUMN IF NOT EXISTS storage_key TEXT"
                    )
                    await conn.execute(
                        "ALTER TABLE run_artifacts ALTER COLUMN content DROP NOT NULL"
                    )
                self._schema_applied = True
            logger.info("PostgreSQL pool created: %s", self._dsn)
            return self._pool

    async def execute(self, query: str, *args: Any) -> str:
        pool = await self._ensure_pool()
        result: str = await pool.execute(query, *args)
        return result

    async def fetch(self, query: str, *args: Any) -> list[Any]:
        pool = await self._ensure_pool()
        result: list[Any] = await pool.fetch(query, *args)
        return result

    async def fetchrow(self, query: str, *args: Any) -> Any | None:
        pool = await self._ensure_pool()
        return await pool.fetchrow(query, *args)

    async def fetchval(self, query: str, *args: Any) -> Any:
        pool = await self._ensure_pool()
        return await pool.fetchval(query, *args)

    async def acquire(self) -> Any:
        """Acquire a connection from the pool (for advisory locks)."""
        pool = await self._ensure_pool()
        return await pool.acquire()

    async def release(self, conn: Any) -> None:
        """Release a connection back to the pool."""
        pool = await self._ensure_pool()
        await pool.release(conn)

    async def close(self) -> None:
        if self._pool is not None:
            await self._pool.close()
            self._pool = None


# ===================================================================
# PostgresRunStorage — RunStorage Protocol
# ===================================================================


class PostgresRunStorage:
    """PostgreSQL-backed ``RunStorage`` with hash-chain integrity."""

    def __init__(self, pool: PostgresPool, artifact_storage: Any | None = None) -> None:
        self._pool = pool
        self._artifact_storage = artifact_storage

    @staticmethod
    def _s3_key(run_id: str, filename: str) -> str:
        """Build the S3 object key for an artifact."""
        return f"runs/{run_id}/artifacts/{filename}"

    async def create_run(self, run_id: str) -> None:
        await self._pool.execute(
            "INSERT INTO runs (run_id) VALUES ($1) ON CONFLICT DO NOTHING",
            run_id,
        )

    async def append_event(self, run_id: str, event: dict[str, Any]) -> str:
        pool = await self._pool._ensure_pool()
        async with pool.acquire() as conn, conn.transaction():
            # Lock per run_id to prevent concurrent appends
            await conn.execute("SELECT pg_advisory_xact_lock(hashtext($1))", run_id)

            # Get chain tip
            row = await conn.fetchrow(
                "SELECT hash, seq FROM run_events WHERE run_id = $1 ORDER BY seq DESC LIMIT 1",
                run_id,
            )
            if row:
                prev_hash = str(row["hash"])
                prev_seq = int(row["seq"])
            else:
                prev_hash = _GENESIS_HASH
                prev_seq = 0

            seq = prev_seq + 1

            # Build event payload (same logic as evidence.py:88-94)
            event_payload: dict[str, Any] = {
                "timestamp": datetime.now(tz=UTC).isoformat(),
                **{k: v for k, v in event.items() if k not in _CHAIN_FIELDS},
            }

            canon = canonical_json(event_payload)
            event_hash = sha256(prev_hash.encode() + b"\n" + canon)

            chained_event: dict[str, Any] = {
                **event_payload,
                "_seq": seq,
                "_prev_hash": prev_hash,
                "_hash": event_hash,
            }

            await conn.execute(
                "INSERT INTO run_events (run_id, seq, prev_hash, hash, payload) "
                "VALUES ($1, $2, $3, $4, $5::jsonb)",
                run_id,
                seq,
                prev_hash,
                event_hash,
                json.dumps(chained_event, default=str),
            )

            return event_hash

    async def get_chain_tip(self, run_id: str) -> tuple[str, int]:
        row = await self._pool.fetchrow(
            "SELECT hash, seq FROM run_events WHERE run_id = $1 ORDER BY seq DESC LIMIT 1",
            run_id,
        )
        if row:
            return str(row["hash"]), int(row["seq"])
        return _GENESIS_HASH, 0

    async def verify_chain(self, run_id: str) -> Any:
        rows = await self._pool.fetch(
            "SELECT payload FROM run_events WHERE run_id = $1 ORDER BY seq ASC",
            run_id,
        )
        if not rows:
            return ChainVerifyResult(ok=False, errors=["No events found"])

        errors: list[str] = []
        prev_hash = _GENESIS_HASH
        last_hash = _GENESIS_HASH
        last_seq = 0

        for i, row in enumerate(rows, 1):
            event: dict[str, Any] = (
                row["payload"] if isinstance(row["payload"], dict) else json.loads(row["payload"])
            )

            stored_hash = str(event.get("_hash", ""))
            stored_prev = str(event.get("_prev_hash", ""))
            stored_seq = int(event.get("_seq", 0))

            if not stored_hash:
                errors.append(f"Event {i}: missing _hash field")
                continue

            if stored_seq != last_seq + 1:
                errors.append(f"Event {i}: expected _seq={last_seq + 1}, got {stored_seq}")

            if stored_prev != prev_hash:
                errors.append(
                    f"Event {i}: _prev_hash mismatch "
                    f"(expected {prev_hash[:16]}..., got {stored_prev[:16]}...)"
                )

            payload = {k: v for k, v in event.items() if k not in _CHAIN_FIELDS}
            canon = canonical_json(payload)
            expected_hash = sha256(stored_prev.encode() + b"\n" + canon)

            if stored_hash != expected_hash:
                errors.append(
                    f"Event {i}: _hash mismatch "
                    f"(expected {expected_hash[:16]}..., got {stored_hash[:16]}...)"
                )

            prev_hash = stored_hash
            last_hash = stored_hash
            last_seq = stored_seq

        return ChainVerifyResult(
            ok=len(errors) == 0,
            errors=errors,
            tip_hash=last_hash,
            seq=last_seq,
        )

    async def write_artifact(self, run_id: str, filename: str, content: str | bytes) -> str:
        data = content.encode() if isinstance(content, str) else content
        content_hash = sha256(data)
        suffix = Path(filename).suffix.lower()
        kind = "text" if suffix in _TEXT_SUFFIXES else "binary"

        if self._artifact_storage is not None:
            # S3 path: data → S3, metadata → PG
            key = self._s3_key(run_id, filename)
            ct = "text/plain" if kind == "text" else "application/octet-stream"
            await self._artifact_storage.put(key, data, content_type=ct)
            await self._pool.execute(
                "INSERT INTO run_artifacts "
                "(run_id, filename, content, storage_key, sha256, size_bytes, kind) "
                "VALUES ($1, $2, NULL, $3, $4, $5, $6) "
                "ON CONFLICT (run_id, filename) DO UPDATE "
                "SET content = NULL, storage_key = $3, sha256 = $4, size_bytes = $5, kind = $6",
                run_id,
                filename,
                key,
                content_hash,
                len(data),
                kind,
            )
        else:
            # PG path: data → BYTEA (original behavior)
            await self._pool.execute(
                "INSERT INTO run_artifacts "
                "(run_id, filename, content, storage_key, sha256, size_bytes, kind) "
                "VALUES ($1, $2, $3, NULL, $4, $5, $6) "
                "ON CONFLICT (run_id, filename) DO UPDATE "
                "SET content = $3, storage_key = NULL, sha256 = $4, size_bytes = $5, kind = $6",
                run_id,
                filename,
                data,
                content_hash,
                len(data),
                kind,
            )

        return content_hash

    async def read_artifact(self, run_id: str, filename: str) -> bytes:
        """Read artifact content (transparently from S3 or BYTEA)."""
        row = await self._pool.fetchrow(
            "SELECT content, storage_key FROM run_artifacts WHERE run_id = $1 AND filename = $2",
            run_id,
            filename,
        )
        if row is None:
            msg = f"Artifact not found: {run_id}/{filename}"
            raise FileNotFoundError(msg)

        storage_key = row["storage_key"]
        if storage_key is not None:
            if self._artifact_storage is None:
                msg = (
                    f"Artifact {run_id}/{filename} stored in S3 "
                    f"(key={storage_key!r}) but no ArtifactStorage configured"
                )
                raise RuntimeError(msg)
            result: bytes = await self._artifact_storage.get(storage_key)
            return result

        pg_content = row["content"]
        if pg_content is not None:
            return bytes(pg_content)

        msg = f"Artifact {run_id}/{filename}: neither content nor storage_key"
        raise RuntimeError(msg)

    async def write_manifest(self, run_id: str) -> dict[str, Any]:
        rows = await self._pool.fetch(
            "SELECT filename, sha256, size_bytes, kind "
            "FROM run_artifacts WHERE run_id = $1 ORDER BY filename",
            run_id,
        )

        artifacts: list[dict[str, Any]] = [
            {
                "name": row["filename"],
                "path": f"artifacts/{row['filename']}",
                "sha256": row["sha256"],
                "bytes": row["size_bytes"],
                "kind": row["kind"],
            }
            for row in rows
        ]

        manifest_body: dict[str, Any] = {
            "run_id": run_id,
            "created_at": datetime.now(tz=UTC).isoformat(),
            "artifact_count": len(artifacts),
            "artifacts": artifacts,
        }

        manifest_hash = sha256(canonical_json(manifest_body))
        manifest_body["manifest_sha256"] = manifest_hash

        await self.append_event(
            run_id,
            {
                "event": "MANIFEST_WRITTEN",
                "manifest_sha256": manifest_hash,
                "artifact_count": len(artifacts),
            },
        )

        return manifest_body

    async def write_meta(self, run_id: str, meta: dict[str, Any]) -> None:
        await self._pool.execute(
            "INSERT INTO run_meta (run_id, meta, updated_at) VALUES ($1, $2::jsonb, now()) "
            "ON CONFLICT (run_id) DO UPDATE SET meta = $2::jsonb, updated_at = now()",
            run_id,
            json.dumps(meta, default=str),
        )

    async def write_summary(self, run_id: str, summary: dict[str, Any]) -> None:
        await self._pool.execute(
            "INSERT INTO run_summaries (run_id, summary, updated_at) VALUES ($1, $2::jsonb, now()) "
            "ON CONFLICT (run_id) DO UPDATE SET summary = $2::jsonb, updated_at = now()",
            run_id,
            json.dumps(summary, default=str),
        )

    async def read_events(self, run_id: str) -> list[dict[str, Any]]:
        rows = await self._pool.fetch(
            "SELECT payload FROM run_events WHERE run_id = $1 ORDER BY seq ASC",
            run_id,
        )
        return [
            row["payload"] if isinstance(row["payload"], dict) else json.loads(row["payload"])
            for row in rows
        ]

    async def read_meta(self, run_id: str) -> dict[str, Any]:
        row = await self._pool.fetchrow("SELECT meta FROM run_meta WHERE run_id = $1", run_id)
        if row is None:
            return {}
        meta = row["meta"]
        return meta if isinstance(meta, dict) else json.loads(meta)

    async def read_summary(self, run_id: str) -> dict[str, Any]:
        row = await self._pool.fetchrow(
            "SELECT summary FROM run_summaries WHERE run_id = $1", run_id
        )
        if row is None:
            return {}
        summary = row["summary"]
        return summary if isinstance(summary, dict) else json.loads(summary)

    async def list_runs(self) -> list[str]:
        rows = await self._pool.fetch("SELECT run_id FROM runs ORDER BY run_id")
        return [row["run_id"] for row in rows]


# ===================================================================
# PostgresLedgerStorage — LedgerStorage Protocol
# ===================================================================


class PostgresLedgerStorage:
    """PostgreSQL-backed ``LedgerStorage``."""

    def __init__(self, pool: PostgresPool) -> None:
        self._pool = pool

    def _row_to_entry(self, row: Any) -> UsageEntry:
        return UsageEntry(
            ts=row["ts"].isoformat() if hasattr(row["ts"], "isoformat") else str(row["ts"]),
            run_id=row["run_id"],
            stage=row["stage"],
            provider=row["provider"],
            model=row["model"],
            input_tokens=row["input_tokens"],
            output_tokens=row["output_tokens"],
            total_tokens=row["total_tokens"],
            estimated_usd=float(row["estimated_usd"]),
            latency_ms=row["latency_ms"],
            price_per_1k_input=float(row["price_per_1k_in"]),
            price_per_1k_output=float(row["price_per_1k_out"]),
            currency=row["currency"],
        )

    async def record(self, entry: Any) -> None:
        ts_str = entry.ts if isinstance(entry.ts, str) else str(entry.ts)
        await self._pool.execute(
            "INSERT INTO ledger_entries "
            "(ts, run_id, stage, provider, model, input_tokens, output_tokens, "
            "total_tokens, estimated_usd, latency_ms, price_per_1k_in, "
            "price_per_1k_out, currency) "
            "VALUES ($1::timestamptz, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)",
            ts_str,
            entry.run_id,
            entry.stage,
            entry.provider,
            entry.model,
            entry.input_tokens,
            entry.output_tokens,
            entry.total_tokens,
            float(entry.estimated_usd),
            entry.latency_ms,
            float(entry.price_per_1k_input),
            float(entry.price_per_1k_output),
            entry.currency,
        )

    async def _build_totals(self, where_clause: str, *args: Any) -> UsageTotals:
        """Build UsageTotals from a WHERE clause."""
        agg_row = await self._pool.fetchrow(
            f"SELECT COALESCE(SUM(input_tokens), 0) AS input_tokens, "  # noqa: S608
            f"COALESCE(SUM(output_tokens), 0) AS output_tokens, "
            f"COALESCE(SUM(total_tokens), 0) AS total_tokens, "
            f"COALESCE(SUM(estimated_usd), 0.0) AS estimated_usd, "
            f"COUNT(*) AS llm_calls "
            f"FROM ledger_entries {where_clause}",
            *args,
        )

        model_rows = await self._pool.fetch(
            f"SELECT model, COUNT(*) AS cnt "  # noqa: S608
            f"FROM ledger_entries {where_clause} GROUP BY model",
            *args,
        )

        models = {row["model"]: int(row["cnt"]) for row in model_rows}

        if agg_row is None:
            return UsageTotals(models=models)

        return UsageTotals(
            input_tokens=int(agg_row["input_tokens"]),
            output_tokens=int(agg_row["output_tokens"]),
            total_tokens=int(agg_row["total_tokens"]),
            estimated_usd=float(agg_row["estimated_usd"]),
            llm_calls=int(agg_row["llm_calls"]),
            models=models,
        )

    async def totals_for_day(self, day: date_type | None = None) -> Any:
        target = day or date_type.today()
        return await self._build_totals("WHERE ts::date = $1", target)

    async def totals_for_run(self, run_id: str) -> Any:
        return await self._build_totals("WHERE run_id = $1", run_id)

    async def recent(self, n: int = 20) -> list[Any]:
        rows = await self._pool.fetch("SELECT * FROM ledger_entries ORDER BY id DESC LIMIT $1", n)
        # Reverse to chronological order (matching file backend)
        return [self._row_to_entry(row) for row in reversed(rows)]

    async def entries_for_day(self, day: date_type | None = None) -> list[Any]:
        target = day or date_type.today()
        rows = await self._pool.fetch(
            "SELECT * FROM ledger_entries WHERE ts::date = $1 ORDER BY ts ASC",
            target,
        )
        return [self._row_to_entry(row) for row in rows]

    async def calls_in_last_hour(self) -> int:
        val = await self._pool.fetchval(
            "SELECT COUNT(*) FROM ledger_entries WHERE ts > (now() - interval '1 hour')"
        )
        return int(val) if val else 0


# ===================================================================
# PostgresSessionStorage — SessionStorage Protocol
# ===================================================================


class PostgresSessionStorage:
    """PostgreSQL-backed ``SessionStorage`` with advisory locks."""

    def __init__(self, pool: PostgresPool) -> None:
        self._pool = pool
        self._held_locks: dict[str, Any] = {}

    def _meta_to_json(self, meta: SessionMeta) -> str:
        """Serialize SessionMeta to JSON string."""
        data = {
            "session_id": meta.session_id,
            "created_at": meta.created_at,
            "updated_at": meta.updated_at,
            "status": meta.status,
            "current_goal_index": meta.current_goal_index,
            "goals": [asdict(g) for g in meta.goals],
            "runs": [asdict(r) for r in meta.runs],
            "last_block_reason": meta.last_block_reason,
            "config": meta.config,
            "max_concurrency": meta.max_concurrency,
            "continue_on_fail": meta.continue_on_fail,
        }
        return json.dumps(data, default=str)

    def _json_to_meta(self, data: dict[str, Any]) -> SessionMeta:
        """Deserialize JSON dict to SessionMeta."""
        goals: list[GoalSpec] = []
        for g_raw in data.get("goals", []):
            g_dict = dict(g_raw)
            rb_raw = g_dict.pop("rollback", {})
            rb = RollbackPolicy(**rb_raw) if isinstance(rb_raw, dict) else RollbackPolicy()
            goals.append(GoalSpec(**g_dict, rollback=rb))

        runs = [GoalRunInfo(**r) for r in data.get("runs", [])]

        return SessionMeta(
            session_id=data["session_id"],
            created_at=data["created_at"],
            updated_at=data["updated_at"],
            status=data["status"],
            current_goal_index=data.get("current_goal_index", 0),
            goals=goals,
            runs=runs,
            last_block_reason=data.get("last_block_reason", ""),
            config=data.get("config", {}),
            max_concurrency=data.get("max_concurrency", 1),
            continue_on_fail=data.get("continue_on_fail", False),
        )

    async def save_session(self, meta: Any) -> None:
        meta_json = self._meta_to_json(meta)
        await self._pool.execute(
            "INSERT INTO sessions (session_id, meta, updated_at) "
            "VALUES ($1, $2::jsonb, now()) "
            "ON CONFLICT (session_id) DO UPDATE SET meta = $2::jsonb, updated_at = now()",
            meta.session_id,
            meta_json,
        )

    async def load_session(self, session_id: str) -> Any:
        row = await self._pool.fetchrow(
            "SELECT meta FROM sessions WHERE session_id = $1", session_id
        )
        if row is None:
            msg = f"Session not found: {session_id}"
            raise FileNotFoundError(msg)

        data = row["meta"] if isinstance(row["meta"], dict) else json.loads(row["meta"])
        return self._json_to_meta(data)

    async def append_event(self, session_id: str, event: dict[str, Any]) -> None:
        event_with_ts = {**event, "timestamp": datetime.now(tz=UTC).isoformat()}
        await self._pool.execute(
            "INSERT INTO session_events (session_id, event) VALUES ($1, $2::jsonb)",
            session_id,
            json.dumps(event_with_ts, default=str),
        )

    async def read_events(self, session_id: str) -> list[dict[str, Any]]:
        rows = await self._pool.fetch(
            "SELECT event FROM session_events WHERE session_id = $1 ORDER BY id ASC",
            session_id,
        )
        return [
            row["event"] if isinstance(row["event"], dict) else json.loads(row["event"])
            for row in rows
        ]

    async def list_sessions(self, *, n: int = 20) -> list[str]:
        rows = await self._pool.fetch(
            "SELECT session_id FROM sessions ORDER BY updated_at DESC LIMIT $1",
            n,
        )
        return [row["session_id"] for row in rows]

    async def acquire_lock(self, session_id: str) -> bool:
        pool = await self._pool._ensure_pool()
        conn = await pool.acquire()
        try:
            acquired = await conn.fetchval("SELECT pg_try_advisory_lock(hashtext($1))", session_id)
            if acquired:
                self._held_locks[session_id] = conn
                return True
            await pool.release(conn)
            return False
        except Exception:
            await pool.release(conn)
            raise

    async def release_lock(self, session_id: str) -> None:
        conn = self._held_locks.pop(session_id, None)
        if conn is not None:
            try:
                await conn.execute("SELECT pg_advisory_unlock(hashtext($1))", session_id)
            finally:
                pool = await self._pool._ensure_pool()
                await pool.release(conn)
