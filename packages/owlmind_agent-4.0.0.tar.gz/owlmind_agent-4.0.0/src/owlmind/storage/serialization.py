"""Fast JSON serialization with optional orjson support.

Uses ``orjson`` (if installed) for faster serialization, with automatic
fallback to stdlib ``json``.  Drop-in replacement for ``json.dumps`` / ``json.loads``.

Usage::

    from owlmind.storage.serialization import json_dumps, json_loads

    data = json_loads(raw_bytes)
    raw = json_dumps(data)        # returns bytes
    text = json_dumps_str(data)   # returns str
"""

from __future__ import annotations

from typing import Any

try:
    import orjson

    HAS_ORJSON = True
except ImportError:
    HAS_ORJSON = False

import json as _json


def json_dumps(obj: Any) -> bytes:
    """Serialize *obj* to JSON bytes (orjson if available, else stdlib)."""
    if HAS_ORJSON:
        return bytes(orjson.dumps(obj))
    return _json.dumps(obj, default=str, separators=(",", ":")).encode("utf-8")


def json_dumps_str(obj: Any) -> str:
    """Serialize *obj* to JSON string."""
    if HAS_ORJSON:
        return str(orjson.dumps(obj).decode("utf-8"))
    return _json.dumps(obj, default=str, separators=(",", ":"))


def json_loads(data: bytes | str) -> Any:
    """Deserialize JSON bytes/str to Python object."""
    if HAS_ORJSON:
        return orjson.loads(data)
    return _json.loads(data)
