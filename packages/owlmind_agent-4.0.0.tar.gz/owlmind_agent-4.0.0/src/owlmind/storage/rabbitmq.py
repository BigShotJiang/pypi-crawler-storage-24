"""RabbitMQ-backed QueueStorage with SQLite state tracking.

Uses ``aio-pika`` for RabbitMQ communication and a local SQLite database
for status tracking, item listing, and delivery-tag mapping.

Activate via::

    create_storage(backend="rabbitmq", rabbitmq_url="amqp://guest:guest@localhost/")

Requires: ``pip install 'owlmind[rabbitmq]'``
"""

from __future__ import annotations

import json
import logging
import sqlite3
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from owlmind.queue import QueueItem, QueueStatus

logger = logging.getLogger(__name__)

# SQLite schema for state tracking
_STATE_SCHEMA = """\
CREATE TABLE IF NOT EXISTS queue_items (
    id           TEXT PRIMARY KEY,
    goal         TEXT NOT NULL,
    workspace    TEXT NOT NULL DEFAULT '',
    sandbox      INTEGER NOT NULL DEFAULT 0,
    priority     INTEGER NOT NULL DEFAULT 0,
    created_at   TEXT NOT NULL,
    status       TEXT NOT NULL DEFAULT 'PENDING',
    run_id       TEXT NOT NULL DEFAULT '',
    error        TEXT NOT NULL DEFAULT '',
    delivery_tag INTEGER,
    updated_at   TEXT NOT NULL,
    session_id   TEXT NOT NULL DEFAULT '',
    goal_id      TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_queue_status ON queue_items(status);
"""

_MIGRATION_ADD_SESSION_FIELDS = """\
ALTER TABLE queue_items ADD COLUMN session_id TEXT NOT NULL DEFAULT '';
ALTER TABLE queue_items ADD COLUMN goal_id TEXT NOT NULL DEFAULT '';
"""


class RabbitMQQueueStorage:
    """RabbitMQ-backed ``QueueStorage`` with SQLite state tracking.

    Message flow::

        add()          -> publish to RabbitMQ + INSERT into SQLite
        list_items()   -> SELECT from SQLite
        next_pending() -> basic_get from RabbitMQ + UPDATE SQLite
        mark_running() -> UPDATE SQLite (message stays unacked)
        mark_done()    -> basic_ack + UPDATE SQLite
        mark_failed()  -> basic_nack (-> DLX) + UPDATE SQLite
    """

    def __init__(
        self,
        rabbitmq_url: str = "amqp://guest:guest@localhost/",
        *,
        state_db_path: str | Path = "queue/rabbitmq_state.db",
        queue_name: str = "owlmind.tasks",
        exchange_name: str = "owlmind.exchange",
        dlx_exchange_name: str = "owlmind.dlx",
        dlq_name: str = "owlmind.tasks.dead",
        max_priority: int = 10,
        prefetch_count: int = 1,
    ) -> None:
        self._rabbitmq_url = rabbitmq_url
        self._state_db_path = Path(state_db_path)
        self._queue_name = queue_name
        self._exchange_name = exchange_name
        self._dlx_exchange_name = dlx_exchange_name
        self._dlq_name = dlq_name
        self._max_priority = max_priority
        self._prefetch_count = prefetch_count

        # RabbitMQ objects (initialized in connect())
        self._connection: Any = None
        self._channel: Any = None
        self._queue: Any = None
        self._exchange: Any = None

        # SQLite state store
        self._db = self._init_state_db()

    # ------------------------------------------------------------------
    # SQLite state store
    # ------------------------------------------------------------------

    def _init_state_db(self) -> sqlite3.Connection:
        """Initialize the SQLite state database."""
        self._state_db_path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(self._state_db_path), check_same_thread=False)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        conn.executescript(_STATE_SCHEMA)
        # Migrate existing databases: add session_id/goal_id columns
        import contextlib

        for stmt in _MIGRATION_ADD_SESSION_FIELDS.strip().splitlines():
            with contextlib.suppress(sqlite3.OperationalError):
                conn.execute(stmt)
        conn.row_factory = sqlite3.Row
        return conn

    def _item_from_row(self, row: sqlite3.Row) -> QueueItem:
        """Convert an SQLite row to a QueueItem."""
        return QueueItem(
            id=row["id"],
            goal=row["goal"],
            workspace=row["workspace"],
            sandbox=bool(row["sandbox"]),
            priority=row["priority"],
            created_at=row["created_at"],
            status=row["status"],
            run_id=row["run_id"],
            error=row["error"],
            session_id=row["session_id"],
            goal_id=row["goal_id"],
        )

    def _map_priority(self, owlmind_priority: int) -> int:
        """Map OWLMIND priority (unbounded int) to RabbitMQ (0..max_priority)."""
        return max(0, min(owlmind_priority, self._max_priority))

    # ------------------------------------------------------------------
    # Connection management
    # ------------------------------------------------------------------

    async def connect(self) -> None:
        """Establish RabbitMQ connection and declare topology."""
        import aio_pika

        self._connection = await aio_pika.connect_robust(self._rabbitmq_url)
        self._channel = await self._connection.channel()
        await self._channel.set_qos(prefetch_count=self._prefetch_count)

        # Dead letter exchange + queue
        dlx_exchange = await self._channel.declare_exchange(
            self._dlx_exchange_name,
            aio_pika.ExchangeType.DIRECT,
            durable=True,
        )
        dlq = await self._channel.declare_queue(self._dlq_name, durable=True)
        await dlq.bind(dlx_exchange, routing_key=self._queue_name)

        # Main exchange
        self._exchange = await self._channel.declare_exchange(
            self._exchange_name,
            aio_pika.ExchangeType.DIRECT,
            durable=True,
        )

        # Main task queue with priority + DLX
        self._queue = await self._channel.declare_queue(
            self._queue_name,
            durable=True,
            arguments={
                "x-max-priority": self._max_priority,
                "x-dead-letter-exchange": self._dlx_exchange_name,
                "x-dead-letter-routing-key": self._queue_name,
            },
        )
        await self._queue.bind(self._exchange, routing_key=self._queue_name)

        logger.info("RabbitMQ connected: %s (queue=%s)", self._rabbitmq_url, self._queue_name)

    async def _ensure_connected(self) -> None:
        """Reconnect if the connection is lost."""
        if self._connection is None or self._connection.is_closed:
            await self.connect()
        elif self._channel is None or self._channel.is_closed:
            self._channel = await self._connection.channel()
            await self._channel.set_qos(prefetch_count=self._prefetch_count)

    async def close(self) -> None:
        """Close RabbitMQ connection and SQLite."""
        if self._connection and not self._connection.is_closed:
            await self._connection.close()
            self._connection = None
        if self._db:
            self._db.close()

    # ------------------------------------------------------------------
    # QueueStorage protocol methods
    # ------------------------------------------------------------------

    async def add(
        self,
        goal: str,
        workspace: str,
        *,
        sandbox: bool = False,
        priority: int = 0,
        session_id: str = "",
        goal_id: str = "",
    ) -> QueueItem:
        """Publish message to RabbitMQ and insert into SQLite state."""
        import aio_pika

        item = QueueItem(
            id=f"task-{uuid.uuid4().hex[:8]}",
            goal=goal,
            workspace=workspace,
            sandbox=sandbox,
            priority=priority,
            created_at=datetime.now(tz=UTC).isoformat(),
            status=QueueStatus.PENDING,
            session_id=session_id,
            goal_id=goal_id,
        )

        now = datetime.now(tz=UTC).isoformat()

        # Insert into SQLite first (source of truth)
        self._db.execute(
            "INSERT INTO queue_items (id, goal, workspace, sandbox, priority, "
            "created_at, status, run_id, error, updated_at, session_id, goal_id) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                item.id,
                item.goal,
                item.workspace,
                int(item.sandbox),
                item.priority,
                item.created_at,
                item.status,
                item.run_id,
                item.error,
                now,
                item.session_id,
                item.goal_id,
            ),
        )
        self._db.commit()

        # Publish to RabbitMQ
        await self._ensure_connected()
        body = json.dumps(item.to_dict()).encode()
        message = aio_pika.Message(
            body=body,
            delivery_mode=aio_pika.DeliveryMode.PERSISTENT,
            message_id=item.id,
            priority=self._map_priority(priority),
        )
        await self._exchange.publish(message, routing_key=self._queue_name)

        logger.debug("Enqueued task %s (priority=%d)", item.id, priority)
        return item

    async def list_items(self, *, status: str | None = None) -> list[QueueItem]:
        """Query SQLite state store for items."""
        if status:
            cursor = self._db.execute(
                "SELECT * FROM queue_items WHERE status = ? ORDER BY priority DESC, created_at ASC",
                (status,),
            )
        else:
            cursor = self._db.execute(
                "SELECT * FROM queue_items ORDER BY priority DESC, created_at ASC"
            )
        return [self._item_from_row(row) for row in cursor.fetchall()]

    async def next_pending(self) -> QueueItem | None:
        """Consume the next message from RabbitMQ.

        After basic_get, the message stays unacked until ``mark_done()``
        or ``mark_failed()`` is called with the item_id.

        Handles deduplication: if a requeued message refers to an item
        already RUNNING or DONE in SQLite, it is silently acked and skipped.
        """
        await self._ensure_connected()

        # Try up to 10 times (to skip duplicates from requeue)
        for _ in range(10):
            message = await self._queue.get(fail=False)
            if message is None:
                return None

            try:
                data = json.loads(message.body.decode())
            except (json.JSONDecodeError, UnicodeDecodeError):
                logger.warning("Malformed message in queue, acking and skipping")
                await message.ack()
                continue

            item_id = data.get("id", "")

            # Check SQLite for current status (deduplication)
            row = self._db.execute(
                "SELECT status FROM queue_items WHERE id = ?", (item_id,)
            ).fetchone()

            if row and row["status"] in (QueueStatus.RUNNING, QueueStatus.DONE):
                # Duplicate from requeue — ack and skip
                logger.debug(
                    "Skipping duplicate message for %s (status=%s)", item_id, row["status"]
                )
                await message.ack()
                continue

            # Store delivery_tag for later ack/nack
            now = datetime.now(tz=UTC).isoformat()
            self._db.execute(
                "UPDATE queue_items SET delivery_tag = ?, updated_at = ? WHERE id = ?",
                (message.delivery_tag, now, item_id),
            )
            self._db.commit()

            # Return the item from SQLite (source of truth)
            row = self._db.execute("SELECT * FROM queue_items WHERE id = ?", (item_id,)).fetchone()

            if row is None:
                # Item exists in RabbitMQ but not in SQLite (edge case)
                logger.warning("Item %s not in state DB, acking orphan", item_id)
                await message.ack()
                continue

            return self._item_from_row(row)

        return None

    async def mark_running(self, item_id: str, run_id: str) -> None:
        """Update SQLite state to RUNNING. Message stays unacked in RabbitMQ."""
        now = datetime.now(tz=UTC).isoformat()
        self._db.execute(
            "UPDATE queue_items SET status = ?, run_id = ?, updated_at = ? WHERE id = ?",
            (QueueStatus.RUNNING, run_id, now, item_id),
        )
        self._db.commit()
        logger.debug("Marked %s as RUNNING (run_id=%s)", item_id, run_id)

    async def mark_done(self, item_id: str) -> None:
        """Ack the RabbitMQ message and update SQLite to DONE."""
        # Ack the message via stored delivery_tag
        row = self._db.execute(
            "SELECT delivery_tag FROM queue_items WHERE id = ?", (item_id,)
        ).fetchone()

        if row and row["delivery_tag"] is not None:
            try:
                await self._ensure_connected()
                await self._channel.basic_ack(row["delivery_tag"])
            except Exception as exc:
                logger.warning("RabbitMQ ack failed for %s: %s (marking DONE anyway)", item_id, exc)

        now = datetime.now(tz=UTC).isoformat()
        self._db.execute(
            "UPDATE queue_items SET status = ?, updated_at = ? WHERE id = ?",
            (QueueStatus.DONE, now, item_id),
        )
        self._db.commit()
        logger.debug("Marked %s as DONE", item_id)

    async def mark_failed(self, item_id: str, error: str = "") -> None:
        """Nack the RabbitMQ message (routes to DLX) and update SQLite to FAILED."""
        row = self._db.execute(
            "SELECT delivery_tag FROM queue_items WHERE id = ?", (item_id,)
        ).fetchone()

        if row and row["delivery_tag"] is not None:
            try:
                await self._ensure_connected()
                await self._channel.basic_nack(row["delivery_tag"], requeue=False)
            except Exception as exc:
                logger.warning("RabbitMQ nack failed for %s: %s", item_id, exc)

        now = datetime.now(tz=UTC).isoformat()
        self._db.execute(
            "UPDATE queue_items SET status = ?, error = ?, updated_at = ? WHERE id = ?",
            (QueueStatus.FAILED, error, now, item_id),
        )
        self._db.commit()
        logger.debug("Marked %s as FAILED: %s", item_id, error)
