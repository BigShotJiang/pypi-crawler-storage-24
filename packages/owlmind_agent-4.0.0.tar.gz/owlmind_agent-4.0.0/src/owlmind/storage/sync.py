"""Sync-to-async bridge for running storage coroutines from sync code.

Usage::

    from owlmind.storage.sync import run_sync

    result = run_sync(storage.runs.read_meta("run-001"))
"""

from __future__ import annotations

import asyncio
import concurrent.futures
from collections.abc import Coroutine
from typing import Any, TypeVar

T = TypeVar("T")


def run_sync(coro: Coroutine[Any, Any, T]) -> T:
    """Run an async coroutine from synchronous code.

    * If no event loop is running, creates one via ``asyncio.run()``.
    * If an event loop is already running (e.g. inside FastAPI / Telegram),
      executes the coroutine in a new thread to avoid deadlock.
    """
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop is not None and loop.is_running():
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(asyncio.run, coro)
            return future.result()

    return asyncio.run(coro)
