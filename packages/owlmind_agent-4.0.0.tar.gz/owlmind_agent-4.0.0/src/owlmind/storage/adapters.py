"""Sync adapters wrapping async storage interfaces.

These adapters let existing synchronous code (CycleManager, autopilot, etc.)
work with **any** ``StorageBackend`` — not just the file-based one.

Each adapter class exposes the same synchronous API as the original
implementation (``EvidenceStore``, ``UsageLedger``, etc.) by calling
``run_sync()`` on the underlying async storage methods.

Usage::

    from owlmind.storage.adapters import RunStorageSync

    sync_evidence = RunStorageSync(async_run_storage)
    sync_evidence.create_run("run-001")

Helper functions (``get_sync_*``) extract the most efficient sync object:
file-based backends return their ``.sync`` property (zero overhead), while
other backends get wrapped in an adapter.
"""

from __future__ import annotations

from datetime import date as date_type
from pathlib import Path
from typing import TYPE_CHECKING, Any

from owlmind.storage.sync import run_sync

if TYPE_CHECKING:
    from owlmind.storage.interface import (
        LedgerStorage,
        MemoryStorage,
        QueueStorage,
        RunStorage,
    )


# ===================================================================
# RunStorageSync — sync wrapper for RunStorage
# ===================================================================


class RunStorageSync:
    """Sync wrapper around an async ``RunStorage``."""

    def __init__(self, storage: RunStorage) -> None:
        self._storage = storage

    @property
    def base_dir(self) -> Path:
        """Proxy ``base_dir`` if the underlying storage exposes it."""
        return getattr(self._storage, "base_dir", Path("."))

    def create_run(self, run_id: str) -> None:
        run_sync(self._storage.create_run(run_id))

    def append_event(self, run_id: str, event: dict[str, Any]) -> str:
        return run_sync(self._storage.append_event(run_id, event))

    def get_chain_tip(self, run_id: str) -> tuple[str, int]:
        return run_sync(self._storage.get_chain_tip(run_id))

    def verify_chain(self, run_id: str) -> Any:
        return run_sync(self._storage.verify_chain(run_id))

    def write_artifact(self, run_id: str, filename: str, content: str | bytes) -> str:
        return run_sync(self._storage.write_artifact(run_id, filename, content))

    def write_manifest(self, run_id: str) -> dict[str, Any]:
        return run_sync(self._storage.write_manifest(run_id))

    def write_meta(self, run_id: str, meta: dict[str, Any]) -> None:
        run_sync(self._storage.write_meta(run_id, meta))

    def write_summary(self, run_id: str, summary: dict[str, Any]) -> None:
        run_sync(self._storage.write_summary(run_id, summary))

    def read_events(self, run_id: str) -> list[dict[str, Any]]:
        return run_sync(self._storage.read_events(run_id))

    def read_meta(self, run_id: str) -> dict[str, Any]:
        return run_sync(self._storage.read_meta(run_id))

    def read_summary(self, run_id: str) -> dict[str, Any]:
        return run_sync(self._storage.read_summary(run_id))

    def list_runs(self) -> list[str]:
        return run_sync(self._storage.list_runs())


# ===================================================================
# LedgerStorageSync — sync wrapper for LedgerStorage
# ===================================================================


class LedgerStorageSync:
    """Sync wrapper around an async ``LedgerStorage``."""

    def __init__(self, storage: LedgerStorage) -> None:
        self._storage = storage

    @property
    def ledger_dir(self) -> Path:
        """Proxy ``ledger_dir`` if the underlying storage exposes it."""
        return getattr(self._storage, "ledger_dir", Path("."))

    def record(self, entry: Any) -> None:
        run_sync(self._storage.record(entry))

    def totals_for_day(self, day: date_type | None = None) -> Any:
        return run_sync(self._storage.totals_for_day(day))

    def totals_for_run(self, run_id: str) -> Any:
        return run_sync(self._storage.totals_for_run(run_id))

    def recent(self, n: int = 20) -> list[Any]:
        return run_sync(self._storage.recent(n))

    def entries_for_day(self, day: date_type | None = None) -> list[Any]:
        return run_sync(self._storage.entries_for_day(day))

    def calls_in_last_hour(self) -> int:
        return run_sync(self._storage.calls_in_last_hour())


# ===================================================================
# QueueStorageSync — sync wrapper for QueueStorage
# ===================================================================


class QueueStorageSync:
    """Sync wrapper around an async ``QueueStorage``."""

    def __init__(self, storage: QueueStorage) -> None:
        self._storage = storage

    def add(
        self,
        goal: str,
        workspace: str,
        *,
        sandbox: bool = False,
        priority: int = 0,
    ) -> Any:
        return run_sync(self._storage.add(goal, workspace, sandbox=sandbox, priority=priority))

    def list_items(self, *, status: str | None = None) -> list[Any]:
        return run_sync(self._storage.list_items(status=status))

    def next_pending(self) -> Any | None:
        return run_sync(self._storage.next_pending())

    def mark_running(self, item_id: str, run_id: str) -> None:
        run_sync(self._storage.mark_running(item_id, run_id))

    def mark_done(self, item_id: str) -> None:
        run_sync(self._storage.mark_done(item_id))

    def mark_failed(self, item_id: str, error: str = "") -> None:
        run_sync(self._storage.mark_failed(item_id, error))


# ===================================================================
# MemoryStorageSync — sync wrapper for MemoryStorage
# ===================================================================


class MemoryStorageSync:
    """Sync wrapper around an async ``MemoryStorage``."""

    def __init__(self, storage: MemoryStorage) -> None:
        self._storage = storage

    def ingest(self, kind: str, source: str, content: str) -> str:
        return run_sync(self._storage.ingest(kind, source, content))

    def add_signal(
        self,
        kind: str,
        summary: str,
        *,
        run_id: str | None = None,
        detail: str | None = None,
    ) -> int:
        return run_sync(self._storage.add_signal(kind, summary, run_id=run_id, detail=detail))

    def get_chunks(self, doc_id: str) -> list[Any]:
        return run_sync(self._storage.get_chunks(doc_id))

    def get_signals(self, kind: str | None = None, limit: int = 50) -> list[Any]:
        return run_sync(self._storage.get_signals(kind, limit))

    def stats(self) -> dict[str, Any]:
        return run_sync(self._storage.stats())

    def purge(self, older_than_days: int | None = None) -> int:
        return run_sync(self._storage.purge(older_than_days))

    def query(self, text: str, *, top_k: int = 5) -> list[dict[str, Any]]:
        return run_sync(self._storage.query(text, top_k=top_k))

    def build_memory_context(self, goal: str, *, top_k: int = 5, max_chars: int = 2000) -> str:
        return run_sync(self._storage.build_memory_context(goal, top_k=top_k, max_chars=max_chars))

    def close(self) -> None:
        run_sync(self._storage.close())


# ===================================================================
# Helper functions — extract the most efficient sync object
# ===================================================================


def get_sync_run_storage(storage: Any) -> Any:
    """Get a sync EvidenceStore-compatible object from ``RunStorage``.

    If the storage has a ``.sync`` property (file-based adapters),
    returns the underlying ``EvidenceStore`` directly — zero overhead.
    Otherwise wraps it in ``RunStorageSync``.
    """
    if hasattr(storage, "sync"):
        return storage.sync
    return RunStorageSync(storage)


def get_sync_ledger(storage: Any) -> Any:
    """Get a sync UsageLedger-compatible object from ``LedgerStorage``."""
    if hasattr(storage, "sync"):
        return storage.sync
    return LedgerStorageSync(storage)


def get_sync_queue(storage: Any) -> Any:
    """Get a sync TaskQueue-compatible object from ``QueueStorage``."""
    if hasattr(storage, "sync"):
        return storage.sync
    return QueueStorageSync(storage)


def get_sync_memory(storage: Any) -> Any:
    """Get a sync MemoryStore-compatible object from ``MemoryStorage``."""
    if hasattr(storage, "sync"):
        return storage.sync
    return MemoryStorageSync(storage)
