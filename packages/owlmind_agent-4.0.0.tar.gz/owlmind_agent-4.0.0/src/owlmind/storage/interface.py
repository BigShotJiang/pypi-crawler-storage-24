"""Storage interfaces for OWLMIND distributed platform.

Defines async Protocol classes for all storage subsystems.
File-based adapters implement these protocols in ``file.py``;
future backends (PostgreSQL, S3, vector DBs) will add their own.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date as date_type
from typing import Any, Protocol, runtime_checkable

# ---------------------------------------------------------------------------
# RunStorage — hash-chained evidence + artifacts + metadata
# ---------------------------------------------------------------------------


@runtime_checkable
class RunStorage(Protocol):
    """Async interface for run evidence storage with hash-chain integrity.

    Each run has an append-only event log, metadata, summary, and artifacts.
    """

    async def create_run(self, run_id: str) -> None:
        """Create a new run (directory, tables, etc.)."""
        ...

    async def append_event(self, run_id: str, event: dict[str, Any]) -> str:
        """Append a hash-chained event. Returns the event hash."""
        ...

    async def get_chain_tip(self, run_id: str) -> tuple[str, int]:
        """Return ``(tip_hash, seq)`` of the last event, or genesis values."""
        ...

    async def verify_chain(self, run_id: str) -> Any:
        """Verify hash-chain integrity. Returns a ``ChainVerifyResult``."""
        ...

    async def write_artifact(self, run_id: str, filename: str, content: str | bytes) -> str:
        """Store an artifact. Returns its SHA-256 hash."""
        ...

    async def write_manifest(self, run_id: str) -> dict[str, Any]:
        """Generate and store an artifact manifest. Returns manifest body."""
        ...

    async def write_meta(self, run_id: str, meta: dict[str, Any]) -> None:
        """Write (overwrite) run metadata."""
        ...

    async def write_summary(self, run_id: str, summary: dict[str, Any]) -> None:
        """Write (overwrite) run summary."""
        ...

    async def read_events(self, run_id: str) -> list[dict[str, Any]]:
        """Read all events from the run log."""
        ...

    async def read_meta(self, run_id: str) -> dict[str, Any]:
        """Read run metadata. Returns ``{}`` if not found."""
        ...

    async def read_summary(self, run_id: str) -> dict[str, Any]:
        """Read run summary. Returns ``{}`` if not found."""
        ...

    async def list_runs(self) -> list[str]:
        """List all run IDs."""
        ...


# ---------------------------------------------------------------------------
# LedgerStorage — token / cost usage tracking
# ---------------------------------------------------------------------------


@runtime_checkable
class LedgerStorage(Protocol):
    """Async interface for token/cost usage tracking."""

    async def record(self, entry: Any) -> None:
        """Append a usage entry (``UsageEntry``)."""
        ...

    async def totals_for_day(self, day: date_type | None = None) -> Any:
        """Aggregated totals for a day. Returns ``UsageTotals``."""
        ...

    async def totals_for_run(self, run_id: str) -> Any:
        """Aggregated totals for a run. Returns ``UsageTotals``."""
        ...

    async def recent(self, n: int = 20) -> list[Any]:
        """Return the last *n* entries."""
        ...

    async def entries_for_day(self, day: date_type | None = None) -> list[Any]:
        """All entries for a specific day."""
        ...

    async def calls_in_last_hour(self) -> int:
        """Count LLM calls in the last 60 minutes."""
        ...


# ---------------------------------------------------------------------------
# QueueStorage — task queue
# ---------------------------------------------------------------------------


@runtime_checkable
class QueueStorage(Protocol):
    """Async interface for the task queue."""

    async def add(
        self,
        goal: str,
        workspace: str,
        *,
        sandbox: bool = False,
        priority: int = 0,
        session_id: str = "",
        goal_id: str = "",
    ) -> Any:
        """Add a task. Returns a ``QueueItem``."""
        ...

    async def list_items(self, *, status: str | None = None) -> list[Any]:
        """List items, optionally filtered by status."""
        ...

    async def next_pending(self) -> Any | None:
        """Return the highest-priority PENDING item, or ``None``."""
        ...

    async def mark_running(self, item_id: str, run_id: str) -> None:
        """Mark an item as RUNNING."""
        ...

    async def mark_done(self, item_id: str) -> None:
        """Mark an item as DONE."""
        ...

    async def mark_failed(self, item_id: str, error: str = "") -> None:
        """Mark an item as FAILED."""
        ...


# ---------------------------------------------------------------------------
# SessionStorage — session metadata + event log
# ---------------------------------------------------------------------------


@runtime_checkable
class SessionStorage(Protocol):
    """Async interface for session metadata and event storage."""

    async def save_session(self, meta: Any) -> None:
        """Persist session metadata (``SessionMeta``)."""
        ...

    async def load_session(self, session_id: str) -> Any:
        """Load session metadata. Returns ``SessionMeta``."""
        ...

    async def append_event(self, session_id: str, event: dict[str, Any]) -> None:
        """Append an event to the session log."""
        ...

    async def read_events(self, session_id: str) -> list[dict[str, Any]]:
        """Read all session events."""
        ...

    async def list_sessions(self, *, n: int = 20) -> list[str]:
        """List session IDs (most recent first)."""
        ...

    async def acquire_lock(self, session_id: str) -> bool:
        """Try to acquire an exclusive session lock (non-blocking)."""
        ...

    async def release_lock(self, session_id: str) -> None:
        """Release a previously acquired session lock."""
        ...


# ---------------------------------------------------------------------------
# MemoryStorage — cross-run knowledge store
# ---------------------------------------------------------------------------


@runtime_checkable
class MemoryStorage(Protocol):
    """Async interface for cross-run memory with retrieval."""

    async def ingest(self, kind: str, source: str, content: str) -> str:
        """Ingest a document. Returns doc_id."""
        ...

    async def add_signal(
        self,
        kind: str,
        summary: str,
        *,
        run_id: str | None = None,
        detail: str | None = None,
    ) -> int:
        """Record a signal (lesson, error, pattern). Returns signal_id."""
        ...

    async def get_chunks(self, doc_id: str) -> list[Any]:
        """Get all chunks for a document."""
        ...

    async def get_signals(self, kind: str | None = None, limit: int = 50) -> list[Any]:
        """Get signals, optionally filtered by kind."""
        ...

    async def stats(self) -> dict[str, Any]:
        """Return memory store statistics."""
        ...

    async def purge(self, older_than_days: int | None = None) -> int:
        """Delete old documents. Returns count deleted."""
        ...

    async def query(self, text: str, *, top_k: int = 5) -> list[dict[str, Any]]:
        """Search memory via TF-IDF / vector similarity."""
        ...

    async def build_memory_context(
        self, goal: str, *, top_k: int = 5, max_chars: int = 2000
    ) -> str:
        """Build a formatted context string for planner prompt injection."""
        ...

    async def close(self) -> None:
        """Release resources (connections, file handles)."""
        ...


# ---------------------------------------------------------------------------
# ArtifactStorage — blob / object storage for run artifacts
# ---------------------------------------------------------------------------


@runtime_checkable
class ArtifactStorage(Protocol):
    """Async interface for blob artifact storage (S3/MinIO/GCS).

    Stores raw artifact bytes externally; metadata (sha256, size, key)
    stays in the relational database.
    """

    async def put(
        self,
        key: str,
        data: bytes,
        *,
        content_type: str = "application/octet-stream",
    ) -> None:
        """Upload artifact bytes to the given key."""
        ...

    async def get(self, key: str) -> bytes:
        """Download artifact bytes by key. Raises ``KeyError`` if not found."""
        ...

    async def delete(self, key: str) -> None:
        """Delete artifact by key. No-op if key does not exist."""
        ...

    async def close(self) -> None:
        """Release underlying connections / sessions."""
        ...


# ---------------------------------------------------------------------------
# SkillPackRegistry — skill pack metadata + versions
# ---------------------------------------------------------------------------


@runtime_checkable
class SkillPackRegistry(Protocol):
    """Async interface for skill pack metadata and version management."""

    async def register_pack(
        self,
        pack_id: str,
        name: str,
        description: str = "",
        tags: list[str] | None = None,
    ) -> dict[str, Any]:
        """Register or update a skill pack. Returns pack metadata."""
        ...

    async def get_pack(self, pack_id: str) -> dict[str, Any] | None:
        """Get pack metadata by ID. Returns ``None`` if not found."""
        ...

    async def list_packs(self, *, tags: list[str] | None = None) -> list[dict[str, Any]]:
        """List registered packs, optionally filtered by tags."""
        ...

    async def publish_version(
        self,
        pack_id: str,
        version: str,
        archive_key: str = "",
        sha256: str = "",
        changelog: str = "",
    ) -> dict[str, Any]:
        """Publish a new version. Returns version metadata."""
        ...

    async def get_version(self, pack_id: str, version: str) -> dict[str, Any] | None:
        """Get a specific version. Returns ``None`` if not found."""
        ...

    async def list_versions(self, pack_id: str) -> list[dict[str, Any]]:
        """List all versions for a pack."""
        ...

    async def delete_pack(self, pack_id: str) -> bool:
        """Delete a pack and all versions. Returns True if deleted."""
        ...


# ---------------------------------------------------------------------------
# AgentRegistry — distributed worker instance tracking
# ---------------------------------------------------------------------------


@runtime_checkable
class AgentRegistry(Protocol):
    """Async interface for distributed agent instance management."""

    async def register_agent(
        self,
        agent_id: str,
        *,
        hostname: str = "",
        capabilities: list[str] | None = None,
        max_concurrent: int = 1,
        meta: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Register or update an agent. Returns agent metadata."""
        ...

    async def heartbeat(self, agent_id: str) -> None:
        """Update heartbeat timestamp for an agent."""
        ...

    async def deregister(self, agent_id: str) -> None:
        """Remove an agent from the registry."""
        ...

    async def get_agent(self, agent_id: str) -> dict[str, Any] | None:
        """Get agent metadata by ID. Returns ``None`` if not found."""
        ...

    async def list_agents(self, *, status: str | None = None) -> list[dict[str, Any]]:
        """List agents, optionally filtered by status."""
        ...

    async def set_status(self, agent_id: str, status: str, current_tasks: int = 0) -> None:
        """Update agent status and current task count."""
        ...


# ---------------------------------------------------------------------------
# StorageBackend — aggregated container
# ---------------------------------------------------------------------------


@dataclass
class StorageBackend:
    """Container holding all storage interfaces.

    Created by ``create_storage()`` factory in ``owlmind.storage``.
    """

    runs: RunStorage
    ledger: LedgerStorage
    queue: QueueStorage
    sessions: SessionStorage
    memory: MemoryStorage | None = field(default=None)
    artifact: ArtifactStorage | None = field(default=None)
    skill_pack_registry: SkillPackRegistry | None = field(default=None)
    agent_registry: AgentRegistry | None = field(default=None)
