"""Qdrant-backed MemoryStorage with vector similarity search.

Stores document chunks and signals as Qdrant points in a single
collection, using fastembed (or a custom function) for embeddings.

Activate via::

    create_storage(backend="file", qdrant_url="http://localhost:6333")

Requires: ``pip install 'owlmind[qdrant]'``
"""

from __future__ import annotations

import asyncio
import hashlib
import logging
import random
import time
import uuid
from collections import OrderedDict
from collections.abc import Callable
from typing import Any

from owlmind.memory.store import Chunk, Signal, _chunk_text, _sha256
from owlmind.utils import redact_secrets

logger = logging.getLogger(__name__)

# Default chunking parameters (same as FileMemoryStorage / MemoryStoreConfig)
_CHUNK_MAX_CHARS = 800
_CHUNK_OVERLAP = 100
_MAX_CHUNKS_PER_DOC = 50
_MAX_SNIPPET_CHARS = 400

# Embedding cache defaults
_EMBED_CACHE_MAXSIZE = 1024
_EMBED_CACHE_TTL = 3600  # seconds


class _EmbedCache:
    """Thread-safe LRU+TTL cache for embedding vectors.

    Avoids re-computing embeddings for identical text inputs.
    """

    def __init__(self, maxsize: int = _EMBED_CACHE_MAXSIZE, ttl: float = _EMBED_CACHE_TTL) -> None:
        self._maxsize = maxsize
        self._ttl = ttl
        self._cache: OrderedDict[str, tuple[list[float], float]] = OrderedDict()
        self.hits = 0
        self.misses = 0

    @staticmethod
    def _key(text: str) -> str:
        return hashlib.sha256(text.encode("utf-8")).hexdigest()

    def get(self, text: str) -> list[float] | None:
        """Return cached vector or None."""
        key = self._key(text)
        item = self._cache.get(key)
        if item is None:
            self.misses += 1
            return None
        vector, ts = item
        if time.monotonic() - ts > self._ttl:
            del self._cache[key]
            self.misses += 1
            return None
        self._cache.move_to_end(key)
        self.hits += 1
        return vector

    def put(self, text: str, vector: list[float]) -> None:
        """Store vector in cache, evicting oldest if full."""
        key = self._key(text)
        self._cache[key] = (vector, time.monotonic())
        self._cache.move_to_end(key)
        while len(self._cache) > self._maxsize:
            self._cache.popitem(last=False)

    def clear(self) -> None:
        self._cache.clear()
        self.hits = 0
        self.misses = 0


class QdrantMemoryStorage:
    """Qdrant-backed ``MemoryStorage`` with vector similarity search.

    The Qdrant client is created lazily on first use
    (matching ``PostgresPool`` and ``S3ArtifactStorage`` patterns).
    """

    def __init__(
        self,
        *,
        url: str = "",
        collection: str = "owlmind_memory",
        api_key: str = "",
        vector_size: int = 384,
        embed_fn: Callable[[list[str]], list[list[float]]] | None = None,
        embed_cache_maxsize: int = _EMBED_CACHE_MAXSIZE,
        embed_cache_ttl: float = _EMBED_CACHE_TTL,
        enable_embed_cache: bool = True,
    ) -> None:
        self._url = url
        self._collection = collection
        self._api_key = api_key
        self._vector_size = vector_size
        self._custom_embed_fn = embed_fn

        self._client: Any = None
        self._embedder: Any = None
        self._lock = asyncio.Lock()
        self._embed_cache: _EmbedCache | None = (
            _EmbedCache(maxsize=embed_cache_maxsize, ttl=embed_cache_ttl)
            if enable_embed_cache
            else None
        )

    # ------------------------------------------------------------------
    # Lazy initialization
    # ------------------------------------------------------------------

    async def _ensure_client(self) -> Any:
        """Create the QdrantClient and ensure collection exists."""
        if self._client is not None:
            return self._client
        async with self._lock:
            if self._client is not None:
                return self._client
            from qdrant_client import QdrantClient

            self._client = QdrantClient(
                url=self._url or None,
                api_key=self._api_key or None,
            )

            from qdrant_client.models import Distance, VectorParams

            collections = await asyncio.to_thread(self._client.get_collections)
            exists = any(c.name == self._collection for c in collections.collections)
            if not exists:
                await asyncio.to_thread(
                    self._client.create_collection,
                    collection_name=self._collection,
                    vectors_config=VectorParams(size=self._vector_size, distance=Distance.COSINE),
                )

            logger.info(
                "Qdrant client initialised: url=%s collection=%s",
                self._url or "local",
                self._collection,
            )
            return self._client

    async def _embed(self, texts: list[str]) -> list[list[float]]:
        """Embed texts using custom function or fastembed, with optional cache."""
        cache = self._embed_cache
        if cache is not None:
            # Check cache for each text
            results: list[list[float] | None] = [cache.get(t) for t in texts]
            missing_indices = [i for i, v in enumerate(results) if v is None]
            if not missing_indices:
                return results  # type: ignore[return-value]
            # Compute only missing embeddings
            missing_texts = [texts[i] for i in missing_indices]
            computed = await self._embed_raw(missing_texts)
            for idx, vec in zip(missing_indices, computed, strict=True):
                results[idx] = vec
                cache.put(texts[idx], vec)
            return results  # type: ignore[return-value]
        return await self._embed_raw(texts)

    async def _embed_raw(self, texts: list[str]) -> list[list[float]]:
        """Compute embeddings without cache."""
        if self._custom_embed_fn is not None:
            return await asyncio.to_thread(self._custom_embed_fn, texts)
        if self._embedder is None:
            from fastembed import TextEmbedding

            self._embedder = TextEmbedding(model_name="BAAI/bge-small-en-v1.5")
        raw = await asyncio.to_thread(lambda: list(self._embedder.embed(texts)))
        return [v.tolist() for v in raw]

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _point_id(prefix: str, key: str) -> str:
        """Deterministic UUID hex from a namespace prefix and key."""
        return uuid.uuid5(uuid.NAMESPACE_URL, f"{prefix}:{key}").hex

    async def _scroll_all(self, filt: Any, *, limit: int = 10000) -> list[Any]:
        """Scroll all matching points with filter."""
        client = await self._ensure_client()
        points, _ = await asyncio.to_thread(
            client.scroll,
            collection_name=self._collection,
            scroll_filter=filt,
            limit=limit,
            with_payload=True,
            with_vectors=False,
        )
        return list(points)

    def _make_filter(self, *conditions: Any) -> Any:
        """Build a Qdrant Filter from FieldConditions."""
        from qdrant_client.models import Filter

        return Filter(must=list(conditions))

    def _field_eq(self, key: str, value: Any) -> Any:
        """Build a FieldCondition for exact match."""
        from qdrant_client.models import FieldCondition, MatchValue

        return FieldCondition(key=key, match=MatchValue(value=value))

    # ------------------------------------------------------------------
    # MemoryStorage Protocol
    # ------------------------------------------------------------------

    async def ingest(self, kind: str, source: str, content: str) -> str:
        """Ingest a document. Returns doc_id."""
        content = redact_secrets(content)
        doc_hash = _sha256(content)
        doc_id = f"doc-{doc_hash[:16]}"

        # Dedup check: scroll for existing doc with same sha256
        filt = self._make_filter(
            self._field_eq("type", "chunk"),
            self._field_eq("sha256", doc_hash),
        )
        existing = await self._scroll_all(filt, limit=1)
        if existing:
            return doc_id

        # Chunk the content
        chunks = _chunk_text(content, _CHUNK_MAX_CHARS, _CHUNK_OVERLAP)
        chunks = chunks[:_MAX_CHUNKS_PER_DOC]

        # Embed all chunks in batch
        vectors = await self._embed(chunks)

        # Build points
        from qdrant_client.models import PointStruct

        now = time.time()
        points = []
        for seq, (chunk_text, vector) in enumerate(zip(chunks, vectors, strict=True)):
            chunk_hash = _sha256(chunk_text)
            chunk_id = f"chk-{chunk_hash[:16]}"
            point_id = self._point_id("chunk", f"{doc_id}:{seq}")
            points.append(
                PointStruct(
                    id=point_id,
                    vector=vector,
                    payload={
                        "type": "chunk",
                        "doc_id": doc_id,
                        "chunk_id": chunk_id,
                        "seq": seq,
                        "content": chunk_text,
                        "source": source,
                        "kind": kind,
                        "sha256": doc_hash,
                        "created": now,
                        "accessed": now,
                    },
                )
            )

        client = await self._ensure_client()
        await asyncio.to_thread(client.upsert, collection_name=self._collection, points=points)
        return doc_id

    async def add_signal(
        self,
        kind: str,
        summary: str,
        *,
        run_id: str | None = None,
        detail: str | None = None,
    ) -> int:
        """Record a signal (lesson, error, pattern). Returns signal_id."""
        summary = redact_secrets(summary)
        if detail:
            detail = redact_secrets(detail)

        signal_id = int(time.time() * 1_000_000) + random.randint(0, 9999)

        # Embed the summary (+ detail for richer semantic representation)
        embed_text = summary + (" " + detail if detail else "")
        vectors = await self._embed([embed_text])

        from qdrant_client.models import PointStruct

        now = time.time()
        point_id = self._point_id("signal", str(signal_id))
        point = PointStruct(
            id=point_id,
            vector=vectors[0],
            payload={
                "type": "signal",
                "signal_id": signal_id,
                "run_id": run_id,
                "kind": kind,
                "summary": summary,
                "detail": detail,
                "created": now,
            },
        )

        client = await self._ensure_client()
        await asyncio.to_thread(client.upsert, collection_name=self._collection, points=[point])
        return signal_id

    async def get_chunks(self, doc_id: str) -> list[Any]:
        """Get all chunks for a document."""
        filt = self._make_filter(
            self._field_eq("type", "chunk"),
            self._field_eq("doc_id", doc_id),
        )
        points = await self._scroll_all(filt)

        # Sort by seq and return Chunk dataclasses
        points.sort(key=lambda p: p.payload.get("seq", 0))
        return [
            Chunk(
                chunk_id=p.payload["chunk_id"],
                doc_id=p.payload["doc_id"],
                seq=p.payload["seq"],
                content=p.payload["content"],
                sha256=_sha256(p.payload["content"]),
            )
            for p in points
        ]

    async def get_signals(self, kind: str | None = None, limit: int = 50) -> list[Any]:
        """Get signals, optionally filtered by kind."""
        conditions = [self._field_eq("type", "signal")]
        if kind is not None:
            conditions.append(self._field_eq("kind", kind))
        filt = self._make_filter(*conditions)

        points = await self._scroll_all(filt, limit=limit)

        # Sort by created desc
        points.sort(key=lambda p: p.payload.get("created", 0), reverse=True)
        points = points[:limit]

        return [
            Signal(
                signal_id=p.payload.get("signal_id", 0),
                run_id=p.payload.get("run_id"),
                kind=p.payload.get("kind", ""),
                summary=p.payload.get("summary", ""),
                detail=p.payload.get("detail"),
                created=p.payload.get("created", 0.0),
            )
            for p in points
        ]

    async def stats(self) -> dict[str, Any]:
        """Return memory store statistics."""
        chunk_filter = self._make_filter(self._field_eq("type", "chunk"))
        signal_filter = self._make_filter(self._field_eq("type", "signal"))

        chunk_points = await self._scroll_all(chunk_filter)
        client = await self._ensure_client()
        signal_count_result = await asyncio.to_thread(
            client.count,
            collection_name=self._collection,
            count_filter=signal_filter,
            exact=True,
        )

        doc_ids: set[str] = set()
        docs_by_kind: dict[str, int] = {}
        for p in chunk_points:
            did = p.payload.get("doc_id", "")
            k = p.payload.get("kind", "unknown")
            if did not in doc_ids:
                doc_ids.add(did)
                docs_by_kind[k] = docs_by_kind.get(k, 0) + 1

        return {
            "documents": len(doc_ids),
            "chunks": len(chunk_points),
            "signals": signal_count_result.count,
            "docs_by_kind": docs_by_kind,
        }

    async def purge(self, older_than_days: int | None = None) -> int:
        """Delete old documents and their chunks. Returns count deleted."""
        client = await self._ensure_client()

        if older_than_days is None:
            # Delete everything: recreate collection
            from qdrant_client.models import Distance, VectorParams

            await asyncio.to_thread(client.delete_collection, collection_name=self._collection)
            await asyncio.to_thread(
                client.create_collection,
                collection_name=self._collection,
                vectors_config=VectorParams(size=self._vector_size, distance=Distance.COSINE),
            )
            return 0  # unknown count

        cutoff = time.time() - (older_than_days * 86400)

        from qdrant_client.models import (
            FieldCondition,
            Filter,
            FilterSelector,
            Range,
        )

        filt = Filter(must=[FieldCondition(key="created", range=Range(lt=cutoff))])

        # Count before delete for return value
        count_result = await asyncio.to_thread(
            client.count,
            collection_name=self._collection,
            count_filter=filt,
            exact=True,
        )

        await asyncio.to_thread(
            client.delete,
            collection_name=self._collection,
            points_selector=FilterSelector(filter=filt),
        )

        deleted: int = count_result.count
        return deleted

    async def query(self, text: str, *, top_k: int = 5) -> list[dict[str, Any]]:
        """Search memory via vector similarity."""
        vectors = await self._embed([text])
        query_vector = vectors[0]

        chunk_filter = self._make_filter(self._field_eq("type", "chunk"))

        client = await self._ensure_client()
        hits = await asyncio.to_thread(
            client.search,
            collection_name=self._collection,
            query_vector=query_vector,
            query_filter=chunk_filter,
            limit=top_k,
            with_payload=True,
        )

        results: list[dict[str, Any]] = []
        for hit in hits:
            payload = hit.payload
            content = payload.get("content", "")
            snippet = content[:_MAX_SNIPPET_CHARS]
            if len(content) > _MAX_SNIPPET_CHARS:
                snippet += "..."
            snippet = redact_secrets(snippet)

            results.append(
                {
                    "chunk_id": payload.get("chunk_id", ""),
                    "doc_id": payload.get("doc_id", ""),
                    "source": payload.get("source", ""),
                    "score": round(float(hit.score), 4),
                    "snippet": snippet,
                }
            )

        return results

    async def build_memory_context(
        self, goal: str, *, top_k: int = 5, max_chars: int = 2000
    ) -> str:
        """Build a formatted context string for planner prompt injection."""
        results = await self.query(goal, top_k=top_k)
        signals = await self.get_signals(limit=10)

        parts: list[str] = []
        chars_used = 0

        if results:
            parts.append("## Relevant Memory")
            chars_used += 20
            for r in results:
                entry = f"\n- [{r['source']}] (score={r['score']}): {r['snippet']}"
                entry = redact_secrets(entry)
                if chars_used + len(entry) > max_chars:
                    break
                parts.append(entry)
                chars_used += len(entry)

        if signals:
            header = "\n\n## Signals from Past Runs"
            if chars_used + len(header) < max_chars:
                parts.append(header)
                chars_used += len(header)
                for s in signals[:5]:
                    entry = f"\n- [{s.kind}] {s.summary}"
                    entry = redact_secrets(entry)
                    if chars_used + len(entry) > max_chars:
                        break
                    parts.append(entry)
                    chars_used += len(entry)

        return "".join(parts)

    async def close(self) -> None:
        """Close the Qdrant client."""
        if self._client is not None:
            await asyncio.to_thread(self._client.close)
            self._client = None
            self._embedder = None
