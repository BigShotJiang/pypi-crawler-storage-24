"""File-based storage adapters for OWLMIND.

Each adapter wraps the existing synchronous implementation and exposes
async methods via ``asyncio.to_thread``.  A ``.sync`` property gives
direct access to the underlying object for legacy callers that cannot
be made async yet.
"""

from __future__ import annotations

import asyncio
from datetime import date as date_type
from pathlib import Path
from typing import Any

# ===================================================================
# FileRunStorage
# ===================================================================


class FileRunStorage:
    """File-based ``RunStorage`` wrapping ``EvidenceStore``."""

    def __init__(self, base_dir: str | Path) -> None:
        from owlmind.evidence import EvidenceStore

        self._evidence = EvidenceStore(base_dir)

    # -- backward-compat helpers (NOT part of Protocol) -----------------

    @property
    def base_dir(self) -> Path:
        """Underlying directory (for legacy code that needs paths)."""
        return self._evidence.base_dir

    @property
    def sync(self) -> Any:
        """Direct access to the synchronous ``EvidenceStore``."""
        return self._evidence

    # -- async interface ------------------------------------------------

    async def create_run(self, run_id: str) -> None:
        await asyncio.to_thread(self._evidence.create_run, run_id)

    async def append_event(self, run_id: str, event: dict[str, Any]) -> str:
        return await asyncio.to_thread(self._evidence.append_event, run_id, event)

    async def get_chain_tip(self, run_id: str) -> tuple[str, int]:
        return await asyncio.to_thread(self._evidence.get_chain_tip, run_id)

    async def verify_chain(self, run_id: str) -> Any:
        return await asyncio.to_thread(self._evidence.verify_chain, run_id)

    async def write_artifact(self, run_id: str, filename: str, content: str | bytes) -> str:
        return await asyncio.to_thread(self._evidence.write_artifact, run_id, filename, content)

    async def write_manifest(self, run_id: str) -> dict[str, Any]:
        return await asyncio.to_thread(self._evidence.write_manifest, run_id)

    async def write_meta(self, run_id: str, meta: dict[str, Any]) -> None:
        await asyncio.to_thread(self._evidence.write_meta, run_id, meta)

    async def write_summary(self, run_id: str, summary: dict[str, Any]) -> None:
        await asyncio.to_thread(self._evidence.write_summary, run_id, summary)

    async def read_events(self, run_id: str) -> list[dict[str, Any]]:
        return await asyncio.to_thread(self._evidence.read_events, run_id)

    async def read_meta(self, run_id: str) -> dict[str, Any]:
        return await asyncio.to_thread(self._evidence.read_meta, run_id)

    async def read_summary(self, run_id: str) -> dict[str, Any]:
        return await asyncio.to_thread(self._evidence.read_summary, run_id)

    async def list_runs(self) -> list[str]:
        return await asyncio.to_thread(self._evidence.list_runs)


# ===================================================================
# FileLedgerStorage
# ===================================================================


class FileLedgerStorage:
    """File-based ``LedgerStorage`` wrapping ``UsageLedger``."""

    def __init__(self, ledger_dir: str | Path) -> None:
        from owlmind.ledger import UsageLedger

        self._ledger = UsageLedger(Path(ledger_dir))

    @property
    def ledger_dir(self) -> Path:
        return self._ledger.ledger_dir

    @property
    def sync(self) -> Any:
        return self._ledger

    async def record(self, entry: Any) -> None:
        await asyncio.to_thread(self._ledger.record, entry)

    async def totals_for_day(self, day: date_type | None = None) -> Any:
        return await asyncio.to_thread(self._ledger.totals_for_day, day)

    async def totals_for_run(self, run_id: str) -> Any:
        return await asyncio.to_thread(self._ledger.totals_for_run, run_id)

    async def recent(self, n: int = 20) -> list[Any]:
        return await asyncio.to_thread(self._ledger.recent, n)

    async def entries_for_day(self, day: date_type | None = None) -> list[Any]:
        return await asyncio.to_thread(self._ledger.entries_for_day, day)

    async def calls_in_last_hour(self) -> int:
        return await asyncio.to_thread(self._ledger.calls_in_last_hour)


# ===================================================================
# FileQueueStorage
# ===================================================================


class FileQueueStorage:
    """File-based ``QueueStorage`` wrapping ``TaskQueue``."""

    def __init__(self, queue_dir: str | Path) -> None:
        from owlmind.queue import TaskQueue

        self._queue = TaskQueue(queue_dir=Path(queue_dir))

    @property
    def sync(self) -> Any:
        return self._queue

    async def add(
        self,
        goal: str,
        workspace: str,
        *,
        sandbox: bool = False,
        priority: int = 0,
        session_id: str = "",
        goal_id: str = "",
    ) -> Any:
        return await asyncio.to_thread(
            self._queue.add,
            goal,
            workspace,
            sandbox=sandbox,
            priority=priority,
            session_id=session_id,
            goal_id=goal_id,
        )

    async def list_items(self, *, status: str | None = None) -> list[Any]:
        return await asyncio.to_thread(self._queue.list_items, status=status)

    async def next_pending(self) -> Any | None:
        return await asyncio.to_thread(self._queue.next_pending)

    async def mark_running(self, item_id: str, run_id: str) -> None:
        await asyncio.to_thread(self._queue.mark_running, item_id, run_id)

    async def mark_done(self, item_id: str) -> None:
        await asyncio.to_thread(self._queue.mark_done, item_id)

    async def mark_failed(self, item_id: str, error: str = "") -> None:
        await asyncio.to_thread(self._queue.mark_failed, item_id, error)


# ===================================================================
# FileSessionStorage
# ===================================================================


class FileSessionStorage:
    """File-based ``SessionStorage`` wrapping ``session.py`` functions."""

    def __init__(self, sessions_dir: str | Path) -> None:
        self._sessions_dir = Path(sessions_dir)
        self._sessions_dir.mkdir(parents=True, exist_ok=True)
        self._locks: dict[str, Any] = {}

    @property
    def sessions_dir(self) -> Path:
        return self._sessions_dir

    async def save_session(self, meta: Any) -> None:
        from owlmind.session import save_session

        await asyncio.to_thread(save_session, meta, self._sessions_dir)

    async def load_session(self, session_id: str) -> Any:
        from owlmind.session import load_session

        return await asyncio.to_thread(load_session, session_id, self._sessions_dir)

    async def append_event(self, session_id: str, event: dict[str, Any]) -> None:
        from owlmind.session import append_session_event

        await asyncio.to_thread(append_session_event, session_id, self._sessions_dir, event)

    async def read_events(self, session_id: str) -> list[dict[str, Any]]:
        from owlmind.session import read_session_events

        return await asyncio.to_thread(read_session_events, session_id, self._sessions_dir)

    async def list_sessions(self, *, n: int = 20) -> list[str]:
        def _list() -> list[str]:
            if not self._sessions_dir.exists():
                return []
            dirs = sorted(
                [
                    d
                    for d in self._sessions_dir.iterdir()
                    if d.is_dir() and (d / "session_meta.json").exists()
                ],
                key=lambda d: d.stat().st_mtime,
                reverse=True,
            )[:n]
            return [d.name for d in dirs]

        return await asyncio.to_thread(_list)

    async def acquire_lock(self, session_id: str) -> bool:
        from owlmind.session import SessionLock

        lock = SessionLock(self._sessions_dir / session_id / ".lock")
        acquired = await asyncio.to_thread(lock.acquire)
        if acquired:
            self._locks[session_id] = lock
        return acquired

    async def release_lock(self, session_id: str) -> None:
        lock = self._locks.pop(session_id, None)
        if lock:
            await asyncio.to_thread(lock.release)


# ===================================================================
# FileMemoryStorage
# ===================================================================


class FileMemoryStorage:
    """File-based ``MemoryStorage`` wrapping ``MemoryStore`` + ``retrieval.py``."""

    def __init__(self, db_path: str | Path, config: Any | None = None) -> None:
        import sqlite3 as _sqlite3

        from owlmind.memory.store import _SCHEMA, MemoryStore

        self._store = MemoryStore(Path(db_path), config)
        # Re-open the connection with check_same_thread=False so that
        # asyncio.to_thread() can use it from the executor thread.
        self._store._conn.close()
        self._store._conn = _sqlite3.connect(str(db_path), check_same_thread=False)
        self._store._conn.execute("PRAGMA journal_mode=WAL")
        self._store._conn.execute("PRAGMA foreign_keys=ON")
        self._store._conn.executescript(_SCHEMA)

    @property
    def sync(self) -> Any:
        return self._store

    async def ingest(self, kind: str, source: str, content: str) -> str:
        return await asyncio.to_thread(self._store.ingest, kind, source, content)

    async def add_signal(
        self,
        kind: str,
        summary: str,
        *,
        run_id: str | None = None,
        detail: str | None = None,
    ) -> int:
        return await asyncio.to_thread(
            self._store.add_signal, kind, summary, run_id=run_id, detail=detail
        )

    async def get_chunks(self, doc_id: str) -> list[Any]:
        return await asyncio.to_thread(self._store.get_chunks, doc_id)

    async def get_signals(self, kind: str | None = None, limit: int = 50) -> list[Any]:
        return await asyncio.to_thread(self._store.get_signals, kind, limit)

    async def stats(self) -> dict[str, Any]:
        return await asyncio.to_thread(self._store.stats)

    async def purge(self, older_than_days: int | None = None) -> int:
        return await asyncio.to_thread(self._store.purge, older_than_days)

    async def query(self, text: str, *, top_k: int = 5) -> list[dict[str, Any]]:
        from owlmind.memory.retrieval import query as mem_query

        results = await asyncio.to_thread(mem_query, self._store, text, top_k=top_k)
        return [
            {
                "chunk_id": r.chunk_id,
                "doc_id": r.doc_id,
                "source": r.source,
                "score": r.score,
                "snippet": r.snippet,
            }
            for r in results
        ]

    async def build_memory_context(
        self, goal: str, *, top_k: int = 5, max_chars: int = 2000
    ) -> str:
        from owlmind.memory.retrieval import build_memory_context

        return await asyncio.to_thread(
            build_memory_context, self._store, goal, top_k=top_k, max_chars=max_chars
        )

    async def close(self) -> None:
        await asyncio.to_thread(self._store.close)
