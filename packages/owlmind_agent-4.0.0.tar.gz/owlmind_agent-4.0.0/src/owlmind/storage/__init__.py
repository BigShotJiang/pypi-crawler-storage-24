"""OWLMIND storage abstraction layer.

Provides async Protocol interfaces and a factory for creating storage
backends.  Currently supports ``"file"`` backend (wrapping the existing
JSONL / SQLite implementations).  Future backends: ``"postgres"``,
``"s3"``, ``"qdrant"``, etc.

Quick start::

    from owlmind.storage import create_storage

    storage = create_storage(backend="file", runs_dir="runs")
    await storage.runs.create_run("run-001")
"""

from __future__ import annotations

from pathlib import Path

from owlmind.storage.interface import (
    AgentRegistry,
    ArtifactStorage,
    LedgerStorage,
    MemoryStorage,
    QueueStorage,
    RunStorage,
    SessionStorage,
    SkillPackRegistry,
    StorageBackend,
)

__all__ = [
    "AgentRegistry",
    "ArtifactStorage",
    "LedgerStorage",
    "MemoryStorage",
    "QueueStorage",
    "RunStorage",
    "SessionStorage",
    "SkillPackRegistry",
    "StorageBackend",
    "create_storage",
]


def create_storage(
    *,
    backend: str = "file",
    runs_dir: str | Path = "runs",
    ledger_dir: str | Path = "ledger",
    queue_dir: str | Path = "queue",
    sessions_dir: str | Path = "sessions",
    memory_db: str | Path | None = None,
    # RabbitMQ-specific options (used when backend="rabbitmq")
    rabbitmq_url: str = "",
    rabbitmq_queue_name: str = "owlmind.tasks",
    rabbitmq_max_priority: int = 10,
    rabbitmq_prefetch: int = 1,
    rabbitmq_state_db: str | Path = "queue/rabbitmq_state.db",
    # PostgreSQL-specific options (used when backend="postgres")
    postgres_dsn: str = "",
    postgres_pool_min: int = 2,
    postgres_pool_max: int = 10,
    # S3/MinIO-specific options (used with backend="postgres" when s3_bucket is set)
    s3_bucket: str = "",
    s3_endpoint_url: str = "",
    s3_region: str = "us-east-1",
    s3_access_key: str = "",
    s3_secret_key: str = "",
    # Qdrant-specific options (replaces FileMemoryStorage when qdrant_url is set)
    qdrant_url: str = "",
    qdrant_collection: str = "owlmind_memory",
    qdrant_api_key: str = "",
    qdrant_vector_size: int = 384,
    # Kafka-specific options (used when backend="kafka")
    kafka_bootstrap_servers: str = "",
    kafka_topic: str = "owlmind.tasks",
    kafka_group_id: str = "owlmind-workers",
    kafka_state_db: str | Path = "queue/kafka_state.db",
) -> StorageBackend:
    """Create a :class:`StorageBackend` from configuration.

    Args:
        backend: Storage backend type (``"file"``, ``"rabbitmq"``, or ``"postgres"``).
        runs_dir: Directory for run evidence.
        ledger_dir: Directory for usage ledger.
        queue_dir: Directory for task queue (file and postgres backends).
        sessions_dir: Directory for sessions.
        memory_db: Path to SQLite memory database (optional).
        rabbitmq_url: AMQP connection URL (required for rabbitmq backend).
        rabbitmq_queue_name: RabbitMQ queue name.
        rabbitmq_max_priority: Maximum priority level (0-255).
        rabbitmq_prefetch: Prefetch count for RabbitMQ consumer.
        rabbitmq_state_db: Path to SQLite state database for RabbitMQ.
        postgres_dsn: PostgreSQL connection string (required for postgres backend).
        postgres_pool_min: Minimum pool size for asyncpg.
        postgres_pool_max: Maximum pool size for asyncpg.
        s3_bucket: S3 bucket for artifact storage (optional, postgres backend only).
        s3_endpoint_url: S3/MinIO endpoint URL (empty = real AWS S3).
        s3_region: AWS region name.
        s3_access_key: AWS access key ID.
        s3_secret_key: AWS secret access key.
        qdrant_url: Qdrant server URL (replaces FileMemoryStorage when set).
        qdrant_collection: Qdrant collection name for memory.
        qdrant_api_key: Qdrant API key (optional, for Qdrant Cloud).
        qdrant_vector_size: Embedding vector dimension (default 384).
        kafka_bootstrap_servers: Kafka broker addresses (required for kafka backend).
        kafka_topic: Kafka topic for task queue.
        kafka_group_id: Consumer group ID for Kafka.
        kafka_state_db: Path to SQLite state database for Kafka.

    Returns:
        Fully constructed :class:`StorageBackend`.

    Raises:
        ValueError: If *backend* is not recognised or required params missing.
    """

    # Memory storage (independent of backend — Qdrant overrides FileMemory)
    def _make_memory() -> MemoryStorage | None:
        if qdrant_url:
            from owlmind.storage.qdrant import QdrantMemoryStorage

            return QdrantMemoryStorage(
                url=qdrant_url,
                collection=qdrant_collection,
                api_key=qdrant_api_key,
                vector_size=qdrant_vector_size,
            )
        if memory_db is not None:
            from owlmind.storage.file import FileMemoryStorage

            return FileMemoryStorage(memory_db)
        return None

    # Registry storage (file-based, independent of backend)
    def _make_registries(
        base: Path,
    ) -> tuple[SkillPackRegistry | None, AgentRegistry | None]:
        from owlmind.registry.agents import FileAgentRegistry
        from owlmind.registry.skill_packs import FileSkillPackRegistry

        sp_dir = base / "skill_pack_registry"
        ag_dir = base / "agent_registry"
        return FileSkillPackRegistry(sp_dir), FileAgentRegistry(ag_dir)

    if backend == "file":
        from owlmind.storage.file import (
            FileLedgerStorage,
            FileQueueStorage,
            FileRunStorage,
            FileSessionStorage,
        )

        sp_reg, ag_reg = _make_registries(Path(sessions_dir).parent)
        return StorageBackend(
            runs=FileRunStorage(runs_dir),
            ledger=FileLedgerStorage(ledger_dir),
            queue=FileQueueStorage(queue_dir),
            sessions=FileSessionStorage(sessions_dir),
            memory=_make_memory(),
            skill_pack_registry=sp_reg,
            agent_registry=ag_reg,
        )

    if backend == "rabbitmq":
        if not rabbitmq_url:
            msg = "rabbitmq_url is required for backend='rabbitmq'"
            raise ValueError(msg)

        from owlmind.storage.file import (
            FileLedgerStorage,
            FileRunStorage,
            FileSessionStorage,
        )
        from owlmind.storage.rabbitmq import RabbitMQQueueStorage

        sp_reg, ag_reg = _make_registries(Path(sessions_dir).parent)
        return StorageBackend(
            runs=FileRunStorage(runs_dir),
            ledger=FileLedgerStorage(ledger_dir),
            queue=RabbitMQQueueStorage(
                rabbitmq_url=rabbitmq_url,
                state_db_path=rabbitmq_state_db,
                queue_name=rabbitmq_queue_name,
                max_priority=rabbitmq_max_priority,
                prefetch_count=rabbitmq_prefetch,
            ),
            sessions=FileSessionStorage(sessions_dir),
            memory=_make_memory(),
            skill_pack_registry=sp_reg,
            agent_registry=ag_reg,
        )

    if backend == "postgres":
        if not postgres_dsn:
            msg = "postgres_dsn is required for backend='postgres'"
            raise ValueError(msg)

        from owlmind.storage.file import FileQueueStorage
        from owlmind.storage.postgres import (
            PostgresLedgerStorage,
            PostgresPool,
            PostgresRunStorage,
            PostgresSessionStorage,
        )

        pool = PostgresPool(
            postgres_dsn,
            min_size=postgres_pool_min,
            max_size=postgres_pool_max,
        )

        artifact_storage = None
        if s3_bucket:
            from owlmind.storage.s3 import S3ArtifactStorage

            artifact_storage = S3ArtifactStorage(
                bucket=s3_bucket,
                endpoint_url=s3_endpoint_url or None,
                region_name=s3_region,
                aws_access_key_id=s3_access_key or None,
                aws_secret_access_key=s3_secret_key or None,
            )

        sp_reg, ag_reg = _make_registries(Path(sessions_dir).parent)
        return StorageBackend(
            runs=PostgresRunStorage(pool, artifact_storage=artifact_storage),
            ledger=PostgresLedgerStorage(pool),
            queue=FileQueueStorage(queue_dir),
            sessions=PostgresSessionStorage(pool),
            memory=_make_memory(),
            artifact=artifact_storage,
            skill_pack_registry=sp_reg,
            agent_registry=ag_reg,
        )

    if backend == "kafka":
        if not kafka_bootstrap_servers:
            msg = "kafka_bootstrap_servers is required for backend='kafka'"
            raise ValueError(msg)

        from owlmind.storage.file import (
            FileLedgerStorage,
            FileRunStorage,
            FileSessionStorage,
        )
        from owlmind.storage.kafka import KafkaQueueStorage

        sp_reg, ag_reg = _make_registries(Path(sessions_dir).parent)
        return StorageBackend(
            runs=FileRunStorage(runs_dir),
            ledger=FileLedgerStorage(ledger_dir),
            queue=KafkaQueueStorage(
                bootstrap_servers=kafka_bootstrap_servers,
                topic=kafka_topic,
                group_id=kafka_group_id,
                state_db_path=kafka_state_db,
            ),
            sessions=FileSessionStorage(sessions_dir),
            memory=_make_memory(),
            skill_pack_registry=sp_reg,
            agent_registry=ag_reg,
        )

    msg = f"Unknown storage backend: {backend!r}"
    raise ValueError(msg)
