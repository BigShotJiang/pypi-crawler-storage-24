"""Kafka-backed QueueStorage using aiokafka.

Stores task queue items in a Kafka topic with consumer groups for
parallel processing.  Item state is tracked in a local SQLite database
(similar to RabbitMQ adapter).

Activate via::

    create_storage(backend="kafka", kafka_bootstrap_servers="localhost:9092")

Requires: ``pip install 'owlmind[kafka]'``
"""

from __future__ import annotations

import json
import logging
import sqlite3
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from owlmind.queue import QueueItem, QueueStatus

logger = logging.getLogger(__name__)

# SQLite schema for state tracking (same schema as RabbitMQ adapter)
_STATE_SCHEMA = """\
CREATE TABLE IF NOT EXISTS queue_items (
    id           TEXT PRIMARY KEY,
    goal         TEXT NOT NULL,
    workspace    TEXT NOT NULL DEFAULT '',
    sandbox      INTEGER NOT NULL DEFAULT 0,
    priority     INTEGER NOT NULL DEFAULT 0,
    created_at   TEXT NOT NULL,
    status       TEXT NOT NULL DEFAULT 'PENDING',
    run_id       TEXT NOT NULL DEFAULT '',
    error        TEXT NOT NULL DEFAULT '',
    kafka_offset INTEGER,
    updated_at   TEXT NOT NULL,
    session_id   TEXT NOT NULL DEFAULT '',
    goal_id      TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_queue_status ON queue_items(status);
"""


class KafkaQueueStorage:
    """Kafka-backed ``QueueStorage`` with SQLite state tracking.

    Message flow::

        add()          -> produce to Kafka topic + INSERT into SQLite
        list_items()   -> SELECT from SQLite
        next_pending() -> consume from Kafka + UPDATE SQLite
        mark_running() -> UPDATE SQLite
        mark_done()    -> commit offset + UPDATE SQLite
        mark_failed()  -> commit offset + UPDATE SQLite (log error)
    """

    def __init__(
        self,
        *,
        bootstrap_servers: str = "localhost:9092",
        topic: str = "owlmind.tasks",
        group_id: str = "owlmind-workers",
        state_db_path: str | Path = "queue/kafka_state.db",
        enable_auto_commit: bool = False,
        consumer_timeout_ms: int = 1000,
    ) -> None:
        self._bootstrap_servers = bootstrap_servers
        self._topic = topic
        self._group_id = group_id
        self._state_db_path = Path(state_db_path)
        self._enable_auto_commit = enable_auto_commit
        self._consumer_timeout_ms = consumer_timeout_ms

        # Kafka objects (initialized in connect())
        self._producer: Any = None
        self._consumer: Any = None

        # SQLite state store
        self._db = self._init_state_db()

    # ------------------------------------------------------------------
    # SQLite state store
    # ------------------------------------------------------------------

    def _init_state_db(self) -> sqlite3.Connection:
        """Initialize the SQLite state database."""
        self._state_db_path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(self._state_db_path), check_same_thread=False)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        conn.executescript(_STATE_SCHEMA)
        conn.row_factory = sqlite3.Row
        return conn

    def _item_from_row(self, row: sqlite3.Row) -> QueueItem:
        """Convert an SQLite row to a QueueItem."""
        return QueueItem(
            id=row["id"],
            goal=row["goal"],
            workspace=row["workspace"],
            sandbox=bool(row["sandbox"]),
            priority=row["priority"],
            created_at=row["created_at"],
            status=row["status"],
            run_id=row["run_id"],
            error=row["error"],
            session_id=row["session_id"],
            goal_id=row["goal_id"],
        )

    # ------------------------------------------------------------------
    # Connection management
    # ------------------------------------------------------------------

    async def connect(self) -> None:
        """Start Kafka producer and consumer."""
        from aiokafka import AIOKafkaConsumer, AIOKafkaProducer

        self._producer = AIOKafkaProducer(
            bootstrap_servers=self._bootstrap_servers,
            value_serializer=lambda v: json.dumps(v).encode("utf-8"),
            key_serializer=lambda k: k.encode("utf-8") if k else None,
        )
        await self._producer.start()

        self._consumer = AIOKafkaConsumer(
            self._topic,
            bootstrap_servers=self._bootstrap_servers,
            group_id=self._group_id,
            enable_auto_commit=self._enable_auto_commit,
            auto_offset_reset="earliest",
            value_deserializer=lambda v: json.loads(v.decode("utf-8")),
            consumer_timeout_ms=self._consumer_timeout_ms,
        )
        await self._consumer.start()

        logger.info(
            "Kafka connected: %s (topic=%s, group=%s)",
            self._bootstrap_servers,
            self._topic,
            self._group_id,
        )

    async def _ensure_connected(self) -> None:
        """Connect if not yet connected."""
        if self._producer is None or self._consumer is None:
            await self.connect()

    async def close(self) -> None:
        """Stop Kafka producer/consumer and close SQLite."""
        if self._producer is not None:
            await self._producer.stop()
            self._producer = None
        if self._consumer is not None:
            await self._consumer.stop()
            self._consumer = None
        if self._db:
            self._db.close()

    # ------------------------------------------------------------------
    # QueueStorage protocol methods
    # ------------------------------------------------------------------

    async def add(
        self,
        goal: str,
        workspace: str,
        *,
        sandbox: bool = False,
        priority: int = 0,
        session_id: str = "",
        goal_id: str = "",
    ) -> QueueItem:
        """Produce message to Kafka topic and insert into SQLite state."""
        item = QueueItem(
            id=f"task-{uuid.uuid4().hex[:8]}",
            goal=goal,
            workspace=workspace,
            sandbox=sandbox,
            priority=priority,
            created_at=datetime.now(tz=UTC).isoformat(),
            status=QueueStatus.PENDING,
            session_id=session_id,
            goal_id=goal_id,
        )

        now = datetime.now(tz=UTC).isoformat()

        # Insert into SQLite first (source of truth)
        self._db.execute(
            "INSERT INTO queue_items (id, goal, workspace, sandbox, priority, "
            "created_at, status, run_id, error, updated_at, session_id, goal_id) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                item.id,
                item.goal,
                item.workspace,
                int(item.sandbox),
                item.priority,
                item.created_at,
                item.status,
                item.run_id,
                item.error,
                now,
                item.session_id,
                item.goal_id,
            ),
        )
        self._db.commit()

        # Produce to Kafka
        await self._ensure_connected()
        await self._producer.send_and_wait(
            self._topic,
            value=item.to_dict(),
            key=item.id,
        )

        logger.debug("Enqueued task %s to Kafka (priority=%d)", item.id, priority)
        return item

    async def list_items(self, *, status: str | None = None) -> list[QueueItem]:
        """Query SQLite state store for items."""
        if status:
            cursor = self._db.execute(
                "SELECT * FROM queue_items WHERE status = ? ORDER BY priority DESC, created_at ASC",
                (status,),
            )
        else:
            cursor = self._db.execute(
                "SELECT * FROM queue_items ORDER BY priority DESC, created_at ASC"
            )
        return [self._item_from_row(row) for row in cursor.fetchall()]

    async def next_pending(self) -> QueueItem | None:
        """Consume the next message from Kafka.

        Returns the corresponding QueueItem from SQLite, or None if no
        messages are available.  Offset is committed only on mark_done()
        or mark_failed().
        """
        await self._ensure_connected()

        # Poll a single record
        result = await self._consumer.getone()
        if result is None:
            return None

        data = result.value
        item_id = data.get("id", "")

        # Check SQLite for current status (deduplication)
        row = self._db.execute("SELECT status FROM queue_items WHERE id = ?", (item_id,)).fetchone()

        if row and row["status"] in (QueueStatus.RUNNING, QueueStatus.DONE):
            # Duplicate — commit offset and skip
            logger.debug(
                "Skipping duplicate Kafka message for %s (status=%s)",
                item_id,
                row["status"],
            )
            await self._consumer.commit()
            return None

        # Store Kafka offset for tracking
        now = datetime.now(tz=UTC).isoformat()
        self._db.execute(
            "UPDATE queue_items SET kafka_offset = ?, updated_at = ? WHERE id = ?",
            (result.offset, now, item_id),
        )
        self._db.commit()

        # Return the item from SQLite
        row = self._db.execute("SELECT * FROM queue_items WHERE id = ?", (item_id,)).fetchone()

        if row is None:
            logger.warning("Item %s not in state DB, committing orphan", item_id)
            await self._consumer.commit()
            return None

        return self._item_from_row(row)

    async def mark_running(self, item_id: str, run_id: str) -> None:
        """Update SQLite state to RUNNING."""
        now = datetime.now(tz=UTC).isoformat()
        self._db.execute(
            "UPDATE queue_items SET status = ?, run_id = ?, updated_at = ? WHERE id = ?",
            (QueueStatus.RUNNING, run_id, now, item_id),
        )
        self._db.commit()
        logger.debug("Marked %s as RUNNING (run_id=%s)", item_id, run_id)

    async def mark_done(self, item_id: str) -> None:
        """Commit Kafka offset and update SQLite to DONE."""
        # Commit consumer offset
        if self._consumer is not None:
            try:
                await self._consumer.commit()
            except Exception as exc:
                logger.warning("Kafka commit failed for %s: %s", item_id, exc)

        now = datetime.now(tz=UTC).isoformat()
        self._db.execute(
            "UPDATE queue_items SET status = ?, updated_at = ? WHERE id = ?",
            (QueueStatus.DONE, now, item_id),
        )
        self._db.commit()
        logger.debug("Marked %s as DONE", item_id)

    async def mark_failed(self, item_id: str, error: str = "") -> None:
        """Commit Kafka offset and update SQLite to FAILED.

        In Kafka, failed messages are committed (not redelivered).
        Use a dead-letter topic or separate error handling for retries.
        """
        # Commit consumer offset (don't redeliver failed messages)
        if self._consumer is not None:
            try:
                await self._consumer.commit()
            except Exception as exc:
                logger.warning("Kafka commit failed for %s: %s", item_id, exc)

        now = datetime.now(tz=UTC).isoformat()
        self._db.execute(
            "UPDATE queue_items SET status = ?, error = ?, updated_at = ? WHERE id = ?",
            (QueueStatus.FAILED, error, now, item_id),
        )
        self._db.commit()
        logger.debug("Marked %s as FAILED: %s", item_id, error)
