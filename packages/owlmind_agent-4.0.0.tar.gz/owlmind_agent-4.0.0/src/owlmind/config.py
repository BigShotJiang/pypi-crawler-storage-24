"""OWLMIND configuration — pydantic-based settings with env var support."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field

# Fields whose values must be masked in output
_SECRET_FIELDS: frozenset[str] = frozenset({"api_key", "bot_token", "secret"})


def _redact(d: dict[str, Any]) -> dict[str, Any]:
    """Recursively redact secret fields in a dict."""
    out: dict[str, Any] = {}
    for k, v in d.items():
        if k in _SECRET_FIELDS:
            out[k] = "***" if v else ""
        elif isinstance(v, dict):
            out[k] = _redact(v)
        else:
            out[k] = v
    return out


# ── Sub-configs (pydantic BaseModel) ──


class TelegramConfig(BaseModel):
    """Telegram bot configuration (all from env vars)."""

    bot_token: str = ""
    allowed_chat_ids: list[int] = Field(default_factory=list)
    default_chat_id: int | None = None
    rate_limit_seconds: float = 2.0

    @property
    def enabled(self) -> bool:
        return bool(self.bot_token)


class OpenAIConfig(BaseModel):
    """OpenAI LLM configuration (all from env vars)."""

    api_key: str = ""
    base_url: str = ""  # Custom endpoint (e.g. DeepSeek, Azure). Empty = default OpenAI.
    planner_model: str = "gpt-4o-2024-08-06"
    judge_model: str = "gpt-4o-2024-08-06"
    max_output_tokens: int = 1200
    timeout_sec: int = 60

    @property
    def enabled(self) -> bool:
        return bool(self.api_key)

    @property
    def use_json_schema(self) -> bool:
        """True only for native OpenAI endpoint (supports structured outputs)."""
        return not self.base_url or "api.openai.com" in self.base_url


class AnthropicConfig(BaseModel):
    """Anthropic LLM configuration (all from env vars)."""

    api_key: str = ""
    model: str = "claude-sonnet-4-5-20250929"
    max_output_tokens: int = 1200
    timeout_sec: int = 60

    @property
    def enabled(self) -> bool:
        return bool(self.api_key)


class VisionConfig(BaseModel):
    """Claude Computer Use configuration."""

    api_key: str = ""
    model: str = "claude-sonnet-4-5-20250929"
    max_tokens: int = 4096
    timeout_sec: int = 120
    screen_width: int = 1280
    screen_height: int = 800
    enabled: bool = False

    @property
    def is_enabled(self) -> bool:
        return self.enabled and bool(self.api_key)


class GeminiConfig(BaseModel):
    """Google Gemini LLM configuration (all from env vars)."""

    api_key: str = ""
    model: str = "gemini-2.5-flash"
    max_output_tokens: int = 1200
    timeout_sec: int = 60

    @property
    def enabled(self) -> bool:
        return bool(self.api_key)


class OllamaConfig(BaseModel):
    """Ollama local LLM configuration."""

    base_url: str = "http://localhost:11434"
    model: str = "llama3"
    max_output_tokens: int = 1200
    timeout_sec: int = 120
    enabled: bool = False


class LLamaCppConfig(BaseModel):
    """llama.cpp server LLM configuration."""

    base_url: str = "http://localhost:8080"
    model: str = "default"
    max_output_tokens: int = 1200
    timeout_sec: int = 120
    enabled: bool = False


class RouterConfig(BaseModel):
    """LLM router configuration — provider preference order per stage."""

    planner_providers: list[str] = Field(default_factory=lambda: ["openai"])
    judge_providers: list[str] = Field(default_factory=lambda: ["openai"])


class WorkerConfig(BaseModel):
    """Worker automation configuration."""

    mode: str = "none"  # "none" | "claude_cli"
    claude_cli_continue: bool = False

    @property
    def enabled(self) -> bool:
        return self.mode != "none"


class HeartbeatConfig(BaseModel):
    """Heartbeat engine configuration."""

    interval_seconds: int = 10
    max_auto_starts_per_hour: int = 3
    notification_cooldown_seconds: int = 60
    stuck_threshold_seconds: int = 3600


class PricingConfig(BaseModel):
    """Token pricing for cost estimation."""

    openai_price_per_1k_input: float = 0.0025  # $2.50/1M input (gpt-4o)
    openai_price_per_1k_output: float = 0.01  # $10.00/1M output (gpt-4o)
    anthropic_price_per_1k_input: float = 0.003  # $3.00/1M input (sonnet)
    anthropic_price_per_1k_output: float = 0.015  # $15.00/1M output (sonnet)
    gemini_price_per_1k_input: float = 0.0  # pricing varies / free tier
    gemini_price_per_1k_output: float = 0.0
    currency: str = "USD"

    def price_for_provider(self, provider: str) -> tuple[float, float]:
        """Return (price_per_1k_input, price_per_1k_output) for a provider."""
        if provider == "anthropic":
            return self.anthropic_price_per_1k_input, self.anthropic_price_per_1k_output
        if provider == "gemini":
            return self.gemini_price_per_1k_input, self.gemini_price_per_1k_output
        if provider in ("ollama", "llamacpp"):
            return 0.0, 0.0
        return self.openai_price_per_1k_input, self.openai_price_per_1k_output


class BudgetConfig(BaseModel):
    """Budget limits for LLM usage governance."""

    max_tokens_per_run: int = 200_000
    max_tokens_per_day: int = 500_000
    max_usd_per_day: float = 10.0
    max_llm_calls_per_hour: int = 20


class WorkspaceConfig(BaseModel):
    """Workspace safety — allowed roots for Telegram operator."""

    default_workspace: str = "."
    allowed_workspaces: list[str] = Field(default_factory=list)


class MemoryConfig(BaseModel):
    """Persistent project memory configuration."""

    enabled: bool = False
    top_k: int = 5
    max_chars_in_prompt: int = 2000


class LogConfig(BaseModel):
    """Logging configuration."""

    level: str = "WARNING"
    json_format: bool = False


class JiraConfig(BaseModel):
    """Jira issue tracker configuration."""

    base_url: str = ""
    email: str = ""
    api_token: str = ""
    timeout: int = 15

    @property
    def enabled(self) -> bool:
        return bool(self.base_url and self.email and self.api_token)


class TrelloConfig(BaseModel):
    """Trello issue tracker configuration."""

    api_key: str = ""
    token: str = ""
    timeout: int = 15

    @property
    def enabled(self) -> bool:
        return bool(self.api_key and self.token)


class BrowserConfig(BaseModel):
    """Browser automation configuration."""

    headless: bool = True
    browser_type: str = "chromium"
    timeout_ms: int = 30000
    viewport_width: int = 1280
    viewport_height: int = 800
    enabled: bool = False


# ── Top-level settings ──


class OwlMindConfig(BaseModel):
    """Top-level configuration loaded from env vars.

    Uses pydantic BaseModel for validation, serialization, and redaction.
    Load via ``OwlMindConfig.from_env()`` which reads environment variables
    and an optional ``.env`` file.
    """

    telegram: TelegramConfig = Field(default_factory=TelegramConfig)
    heartbeat: HeartbeatConfig = Field(default_factory=HeartbeatConfig)
    openai: OpenAIConfig = Field(default_factory=OpenAIConfig)
    anthropic: AnthropicConfig = Field(default_factory=AnthropicConfig)
    vision: VisionConfig = Field(default_factory=VisionConfig)
    gemini: GeminiConfig = Field(default_factory=GeminiConfig)
    ollama: OllamaConfig = Field(default_factory=OllamaConfig)
    llamacpp: LLamaCppConfig = Field(default_factory=LLamaCppConfig)
    router: RouterConfig = Field(default_factory=RouterConfig)
    worker: WorkerConfig = Field(default_factory=WorkerConfig)
    pricing: PricingConfig = Field(default_factory=PricingConfig)
    budget: BudgetConfig = Field(default_factory=BudgetConfig)
    workspace: WorkspaceConfig = Field(default_factory=WorkspaceConfig)
    memory: MemoryConfig = Field(default_factory=MemoryConfig)
    log: LogConfig = Field(default_factory=LogConfig)
    jira: JiraConfig = Field(default_factory=JiraConfig)
    trello: TrelloConfig = Field(default_factory=TrelloConfig)
    browser: BrowserConfig = Field(default_factory=BrowserConfig)

    def redacted_dict(self) -> dict[str, Any]:
        """Return config as dict with secret fields masked."""
        return _redact(self.model_dump())

    def __repr__(self) -> str:
        return f"OwlMindConfig({self.redacted_dict()})"

    @classmethod
    def from_env(cls, *, env_file: str | Path | None = None) -> OwlMindConfig:
        """Load configuration from environment variables.

        If *env_file* is given (or a ``.env`` exists in cwd), it is loaded
        first so that file-based defaults fill in for missing env vars.
        """
        _load_dotenv(env_file)

        token = os.environ.get("TELEGRAM_BOT_TOKEN", "")
        allowed_ids_raw = os.environ.get("TELEGRAM_ALLOWED_CHAT_IDS", "")
        default_chat_raw = os.environ.get("OWLMIND_NOTIFY_DEFAULT_CHAT_ID", "")
        heartbeat_interval = os.environ.get("OWLMIND_HEARTBEAT_INTERVAL", "10")
        quota_raw = os.environ.get("OWLMIND_QUOTA_AUTO_STARTS_PER_HOUR", "3")

        worker_mode = os.environ.get("OWLMIND_WORKER_MODE", "none")
        claude_cli_continue = (
            os.environ.get("OWLMIND_CLAUDE_CLI_CONTINUE", "false").lower() == "true"
        )

        # Anthropic
        anthropic_key = os.environ.get("ANTHROPIC_API_KEY", "")
        anthropic_model = os.environ.get("OWLMIND_ANTHROPIC_MODEL", "claude-sonnet-4-5-20250929")
        anthropic_max_tokens = os.environ.get("OWLMIND_ANTHROPIC_MAX_OUTPUT_TOKENS", "1200")
        anthropic_timeout = os.environ.get("OWLMIND_ANTHROPIC_TIMEOUT_SEC", "60")

        # Vision / Computer Use
        vision_key = os.environ.get("ANTHROPIC_API_KEY", "")
        vision_model = os.environ.get(
            "OWLMIND_VISION_MODEL", "claude-sonnet-4-5-20250929"
        )
        vision_max_tokens = os.environ.get("OWLMIND_VISION_MAX_TOKENS", "4096")
        vision_timeout = os.environ.get("OWLMIND_VISION_TIMEOUT_SEC", "120")
        vision_enabled = (
            os.environ.get("OWLMIND_VISION_ENABLED", "false").lower() == "true"
        )
        vision_screen_width = os.environ.get("OWLMIND_SCREEN_WIDTH", "1280")
        vision_screen_height = os.environ.get("OWLMIND_SCREEN_HEIGHT", "800")

        # Gemini
        gemini_key = os.environ.get("GEMINI_API_KEY", "") or os.environ.get("GOOGLE_API_KEY", "")
        gemini_model = os.environ.get("OWLMIND_GEMINI_MODEL", "gemini-2.5-flash")
        gemini_max_tokens = os.environ.get("OWLMIND_GEMINI_MAX_OUTPUT_TOKENS", "1200")
        gemini_timeout = os.environ.get("OWLMIND_GEMINI_TIMEOUT_SEC", "60")

        # Ollama
        ollama_enabled = os.environ.get("OWLMIND_OLLAMA_ENABLED", "false").lower() == "true"
        ollama_base_url = os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434")
        ollama_model = os.environ.get("OLLAMA_MODEL", "llama3")
        ollama_max_tokens = os.environ.get("OWLMIND_OLLAMA_MAX_OUTPUT_TOKENS", "1200")
        ollama_timeout = os.environ.get("OWLMIND_OLLAMA_TIMEOUT_SEC", "120")

        # llama.cpp
        llamacpp_enabled = os.environ.get("OWLMIND_LLAMACPP_ENABLED", "false").lower() == "true"
        llamacpp_base_url = os.environ.get("LLAMACPP_BASE_URL", "http://localhost:8080")
        llamacpp_model = os.environ.get("LLAMACPP_MODEL", "default")
        llamacpp_max_tokens = os.environ.get("OWLMIND_LLAMACPP_MAX_OUTPUT_TOKENS", "1200")
        llamacpp_timeout = os.environ.get("OWLMIND_LLAMACPP_TIMEOUT_SEC", "120")

        # Router
        planner_providers_raw = os.environ.get("OWLMIND_PLANNER_PROVIDERS", "openai")
        judge_providers_raw = os.environ.get("OWLMIND_JUDGE_PROVIDERS", "openai")
        planner_providers = [p.strip() for p in planner_providers_raw.split(",") if p.strip()]
        judge_providers = [p.strip() for p in judge_providers_raw.split(",") if p.strip()]

        # Anthropic/Gemini pricing
        anthropic_price_in = os.environ.get("OWLMIND_ANTHROPIC_PRICE_PER_1K_INPUT", "0.003")
        anthropic_price_out = os.environ.get("OWLMIND_ANTHROPIC_PRICE_PER_1K_OUTPUT", "0.015")
        gemini_price_in = os.environ.get("OWLMIND_GEMINI_PRICE_PER_1K_INPUT", "0.0")
        gemini_price_out = os.environ.get("OWLMIND_GEMINI_PRICE_PER_1K_OUTPUT", "0.0")

        openai_key = os.environ.get("OPENAI_API_KEY", "")
        openai_base_url = os.environ.get("OPENAI_BASE_URL", "")
        openai_planner_model = os.environ.get("OWLMIND_OPENAI_PLANNER_MODEL", "gpt-4o-2024-08-06")
        openai_judge_model = os.environ.get("OWLMIND_OPENAI_JUDGE_MODEL", "gpt-4o-2024-08-06")
        openai_max_tokens = os.environ.get("OWLMIND_OPENAI_MAX_OUTPUT_TOKENS", "1200")
        openai_timeout = os.environ.get("OWLMIND_OPENAI_TIMEOUT_SEC", "60")

        allowed_ids: list[int] = []
        if allowed_ids_raw.strip():
            allowed_ids = [int(x.strip()) for x in allowed_ids_raw.split(",") if x.strip()]

        default_chat: int | None = None
        if default_chat_raw.strip():
            default_chat = int(default_chat_raw.strip())

        # Pricing
        price_in = os.environ.get("OWLMIND_OPENAI_PRICE_PER_1K_INPUT", "0.0025")
        price_out = os.environ.get("OWLMIND_OPENAI_PRICE_PER_1K_OUTPUT", "0.01")

        # Budget
        budget_run = os.environ.get("OWLMIND_BUDGET_MAX_TOKENS_PER_RUN", "200000")
        budget_day = os.environ.get("OWLMIND_BUDGET_MAX_TOKENS_PER_DAY", "500000")
        budget_usd = os.environ.get("OWLMIND_BUDGET_MAX_USD_PER_DAY", "10.0")
        budget_calls = os.environ.get("OWLMIND_BUDGET_MAX_LLM_CALLS_PER_HOUR", "20")

        # Workspace
        default_ws = os.environ.get("OWLMIND_DEFAULT_WORKSPACE", ".")
        allowed_ws_raw = os.environ.get("OWLMIND_ALLOWED_WORKSPACES", "")
        allowed_ws = (
            [p.strip() for p in allowed_ws_raw.split(",") if p.strip()]
            if allowed_ws_raw.strip()
            else []
        )

        # Memory
        memory_enabled = os.environ.get("OWLMIND_MEMORY_ENABLED", "false").lower() == "true"
        memory_top_k = os.environ.get("OWLMIND_MEMORY_TOP_K", "5")
        memory_max_chars = os.environ.get("OWLMIND_MEMORY_MAX_CHARS", "2000")

        # Logging
        log_level = os.environ.get("OWLMIND_LOG_LEVEL", "WARNING")
        log_json = os.environ.get("OWLMIND_LOG_FORMAT", "text").lower() == "json"

        # Jira
        jira_base_url = os.environ.get("OWLMIND_JIRA_BASE_URL", "")
        jira_email = os.environ.get("OWLMIND_JIRA_EMAIL", "")
        jira_token = os.environ.get("OWLMIND_JIRA_API_TOKEN", "")
        jira_timeout = os.environ.get("OWLMIND_JIRA_TIMEOUT", "15")

        # Trello
        trello_api_key = os.environ.get("OWLMIND_TRELLO_API_KEY", "")
        trello_token = os.environ.get("OWLMIND_TRELLO_TOKEN", "")
        trello_timeout = os.environ.get("OWLMIND_TRELLO_TIMEOUT", "15")

        # Browser
        browser_enabled = os.environ.get("OWLMIND_BROWSER_ENABLED", "false").lower() == "true"
        browser_headless = os.environ.get("OWLMIND_BROWSER_HEADLESS", "true").lower() != "false"
        browser_type = os.environ.get("OWLMIND_BROWSER_TYPE", "chromium")
        browser_timeout = os.environ.get("OWLMIND_BROWSER_TIMEOUT_MS", "30000")
        browser_width = os.environ.get("OWLMIND_BROWSER_VIEWPORT_WIDTH", "1280")
        browser_height = os.environ.get("OWLMIND_BROWSER_VIEWPORT_HEIGHT", "800")

        return cls(
            telegram=TelegramConfig(
                bot_token=token,
                allowed_chat_ids=allowed_ids,
                default_chat_id=default_chat,
            ),
            heartbeat=HeartbeatConfig(
                interval_seconds=int(heartbeat_interval),
                max_auto_starts_per_hour=int(quota_raw),
            ),
            openai=OpenAIConfig(
                api_key=openai_key,
                base_url=openai_base_url,
                planner_model=openai_planner_model,
                judge_model=openai_judge_model,
                max_output_tokens=int(openai_max_tokens),
                timeout_sec=int(openai_timeout),
            ),
            anthropic=AnthropicConfig(
                api_key=anthropic_key,
                model=anthropic_model,
                max_output_tokens=int(anthropic_max_tokens),
                timeout_sec=int(anthropic_timeout),
            ),
            vision=VisionConfig(
                api_key=vision_key,
                model=vision_model,
                max_tokens=int(vision_max_tokens),
                timeout_sec=int(vision_timeout),
                enabled=vision_enabled,
                screen_width=int(vision_screen_width),
                screen_height=int(vision_screen_height),
            ),
            gemini=GeminiConfig(
                api_key=gemini_key,
                model=gemini_model,
                max_output_tokens=int(gemini_max_tokens),
                timeout_sec=int(gemini_timeout),
            ),
            ollama=OllamaConfig(
                base_url=ollama_base_url,
                model=ollama_model,
                max_output_tokens=int(ollama_max_tokens),
                timeout_sec=int(ollama_timeout),
                enabled=ollama_enabled,
            ),
            llamacpp=LLamaCppConfig(
                base_url=llamacpp_base_url,
                model=llamacpp_model,
                max_output_tokens=int(llamacpp_max_tokens),
                timeout_sec=int(llamacpp_timeout),
                enabled=llamacpp_enabled,
            ),
            router=RouterConfig(
                planner_providers=planner_providers,
                judge_providers=judge_providers,
            ),
            worker=WorkerConfig(
                mode=worker_mode,
                claude_cli_continue=claude_cli_continue,
            ),
            pricing=PricingConfig(
                openai_price_per_1k_input=float(price_in),
                openai_price_per_1k_output=float(price_out),
                anthropic_price_per_1k_input=float(anthropic_price_in),
                anthropic_price_per_1k_output=float(anthropic_price_out),
                gemini_price_per_1k_input=float(gemini_price_in),
                gemini_price_per_1k_output=float(gemini_price_out),
            ),
            budget=BudgetConfig(
                max_tokens_per_run=int(budget_run),
                max_tokens_per_day=int(budget_day),
                max_usd_per_day=float(budget_usd),
                max_llm_calls_per_hour=int(budget_calls),
            ),
            workspace=WorkspaceConfig(
                default_workspace=default_ws,
                allowed_workspaces=allowed_ws,
            ),
            memory=MemoryConfig(
                enabled=memory_enabled,
                top_k=int(memory_top_k),
                max_chars_in_prompt=int(memory_max_chars),
            ),
            log=LogConfig(
                level=log_level,
                json_format=log_json,
            ),
            jira=JiraConfig(
                base_url=jira_base_url,
                email=jira_email,
                api_token=jira_token,
                timeout=int(jira_timeout),
            ),
            trello=TrelloConfig(
                api_key=trello_api_key,
                token=trello_token,
                timeout=int(trello_timeout),
            ),
            browser=BrowserConfig(
                enabled=browser_enabled,
                headless=browser_headless,
                browser_type=browser_type,
                timeout_ms=int(browser_timeout),
                viewport_width=int(browser_width),
                viewport_height=int(browser_height),
            ),
        )


# ── .env loader (optional pydantic-settings integration) ──


def _load_dotenv(env_file: str | Path | None = None) -> None:
    """Load .env file if available. Requires ``pydantic-settings[dotenv]``."""
    path = Path(env_file) if env_file else Path(".env")
    if not path.is_file():
        return
    try:
        from dotenv import load_dotenv

        load_dotenv(path, override=False)
    except ImportError:  # pragma: no cover
        # Best-effort: parse simple KEY=VALUE lines manually
        for line in path.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            key, value = key.strip(), value.strip().strip("'\"")
            if key not in os.environ:
                os.environ[key] = value


# ── Utilities ──


def parse_chat_ids(raw: str) -> list[int]:
    """Parse comma-separated chat IDs string."""
    if not raw.strip():
        return []
    return [int(x.strip()) for x in raw.split(",") if x.strip()]
