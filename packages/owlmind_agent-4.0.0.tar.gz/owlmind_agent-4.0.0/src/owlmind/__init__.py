"""OWLMIND — autonomous multi-agent code orchestrator."""

__version__ = "4.0.0"
