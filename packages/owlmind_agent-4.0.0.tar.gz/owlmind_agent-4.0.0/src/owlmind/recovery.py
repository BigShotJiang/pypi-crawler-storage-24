"""OWLMIND recovery — error classification and bounded auto-retry."""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


class RecoveryClass(Enum):
    """Classification of an error for recovery purposes."""

    TRANSIENT = "TRANSIENT"  # Timeout, rate limit, 5xx — safe to retry
    DETERMINISTIC = "DETERMINISTIC"  # Schema error, bad request — retry won't help
    UNSAFE = "UNSAFE"  # Secret leak, policy violation — hard fail
    UNKNOWN = "UNKNOWN"  # Unrecognized error


class RecoveryStep(Enum):
    """Possible recovery actions."""

    RETRY = "RETRY"
    SWITCH_PROVIDER = "SWITCH_PROVIDER"
    ROLLBACK_WORKTREE = "ROLLBACK_WORKTREE"
    OPEN_SUBGOAL = "OPEN_SUBGOAL"
    REQUIRE_APPROVAL = "REQUIRE_APPROVAL"
    FAIL = "FAIL"


@dataclass
class RecoveryPlan:
    """A recovery plan with ordered steps."""

    classification: RecoveryClass
    steps: list[RecoveryStep]
    reason: str
    delay_seconds: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class RecoveryState:
    """Bounded recovery counters for a goal/run."""

    max_transient_retries: int = 3
    max_recoveries_per_goal: int = 5
    transient_retries: int = 0
    total_recoveries: int = 0
    last_error_time: float = 0.0
    history: list[dict[str, Any]] = field(default_factory=list)

    def can_retry_transient(self) -> bool:
        return self.transient_retries < self.max_transient_retries

    def can_recover(self) -> bool:
        return self.total_recoveries < self.max_recoveries_per_goal

    def record_attempt(self, plan: RecoveryPlan) -> None:
        self.total_recoveries += 1
        if plan.classification == RecoveryClass.TRANSIENT:
            self.transient_retries += 1
        self.last_error_time = time.time()
        self.history.append(
            {
                "classification": plan.classification.value,
                "steps": [s.value for s in plan.steps],
                "reason": plan.reason,
                "timestamp": self.last_error_time,
            }
        )


# ── Error classification ──

_TRANSIENT_KEYWORDS = frozenset(
    {
        "timeout",
        "timed out",
        "rate_limit",
        "rate limit",
        "429",
        "503",
        "502",
        "504",
        "connection",
        "connect",
        "network",
        "temporarily",
        "retry",
        "overloaded",
        "capacity",
    }
)

_UNSAFE_KEYWORDS = frozenset(
    {
        "secret",
        "credential",
        "forbidden",
        "policy",
        "blocked",
        "rm -rf",
        "force push",
        "unauthorized",
        "leaked",
    }
)


def classify_error(exc: BaseException, context: dict[str, Any] | None = None) -> RecoveryClass:
    """Classify an exception for recovery purposes.

    Args:
        exc: The exception to classify.
        context: Optional context (stage, provider, etc.).

    Returns:
        A RecoveryClass indicating how to handle the error.
    """
    from owlmind.errors import StructuralError, TransientError

    if isinstance(exc, TransientError):
        return RecoveryClass.TRANSIENT
    if isinstance(exc, StructuralError):
        return RecoveryClass.DETERMINISTIC

    msg = str(exc).lower()

    # Check for unsafe patterns first
    for kw in _UNSAFE_KEYWORDS:
        if kw in msg:
            return RecoveryClass.UNSAFE

    # Check for transient patterns
    for kw in _TRANSIENT_KEYWORDS:
        if kw in msg:
            return RecoveryClass.TRANSIENT

    # Check by exception type
    exc_type = type(exc).__name__.lower()
    if "timeout" in exc_type or "connection" in exc_type:
        return RecoveryClass.TRANSIENT

    return RecoveryClass.UNKNOWN


def build_recovery_plan(
    exc: BaseException,
    state: RecoveryState,
    *,
    context: dict[str, Any] | None = None,
    has_alternative_provider: bool = False,
) -> RecoveryPlan:
    """Build a recovery plan for a classified error.

    Args:
        exc: The exception.
        state: Current recovery state with counters.
        context: Optional context (stage, provider).
        has_alternative_provider: Whether an alternative LLM provider is available.

    Returns:
        A RecoveryPlan with steps to execute.
    """
    classification = classify_error(exc, context)
    stage = (context or {}).get("stage", "unknown")
    logger.info(
        "Building recovery plan: class=%s stage=%s exc=%s", classification.value, stage, exc
    )

    # UNSAFE — hard fail, no recovery
    if classification == RecoveryClass.UNSAFE:
        logger.warning("Unsafe error detected in %s — hard fail", stage)
        return RecoveryPlan(
            classification=classification,
            steps=[RecoveryStep.FAIL],
            reason=f"Unsafe error in {stage}: {exc}",
        )

    # Check global recovery budget
    if not state.can_recover():
        logger.warning(
            "Recovery budget exhausted: %d/%d",
            state.total_recoveries,
            state.max_recoveries_per_goal,
        )
        return RecoveryPlan(
            classification=classification,
            steps=[RecoveryStep.FAIL],
            reason=f"Recovery budget exhausted ({state.total_recoveries}/{state.max_recoveries_per_goal})",
        )

    # TRANSIENT — retry with backoff, optionally switch provider
    if classification == RecoveryClass.TRANSIENT:
        if state.can_retry_transient():
            delay = min(2.0**state.transient_retries, 30.0)
            logger.debug(
                "Transient retry %d/%d, delay=%.1fs",
                state.transient_retries + 1,
                state.max_transient_retries,
                delay,
            )
            steps: list[RecoveryStep] = [RecoveryStep.RETRY]
            if has_alternative_provider and state.transient_retries >= 2:
                steps.insert(0, RecoveryStep.SWITCH_PROVIDER)
            return RecoveryPlan(
                classification=classification,
                steps=steps,
                reason=f"Transient error in {stage}: {exc}",
                delay_seconds=delay,
            )
        # Retries exhausted — try switching provider or fail
        if has_alternative_provider:
            return RecoveryPlan(
                classification=classification,
                steps=[RecoveryStep.SWITCH_PROVIDER, RecoveryStep.RETRY],
                reason="Transient retries exhausted, switching provider",
            )
        return RecoveryPlan(
            classification=classification,
            steps=[RecoveryStep.FAIL],
            reason=f"Transient retries exhausted ({state.transient_retries}/{state.max_transient_retries})",
        )

    # DETERMINISTIC — depends on stage
    if classification == RecoveryClass.DETERMINISTIC:
        if stage == "worker":
            return RecoveryPlan(
                classification=classification,
                steps=[RecoveryStep.OPEN_SUBGOAL],
                reason=f"Deterministic error in worker: {exc}",
                metadata={"subgoal": f"Fix: {exc}"},
            )
        return RecoveryPlan(
            classification=classification,
            steps=[RecoveryStep.REQUIRE_APPROVAL],
            reason=f"Deterministic error needs manual intervention: {exc}",
        )

    # UNKNOWN — conservative: require approval
    return RecoveryPlan(
        classification=classification,
        steps=[RecoveryStep.REQUIRE_APPROVAL],
        reason=f"Unknown error in {stage}: {exc}",
    )
