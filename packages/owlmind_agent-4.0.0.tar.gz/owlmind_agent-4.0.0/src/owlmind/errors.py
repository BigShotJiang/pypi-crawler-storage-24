"""OwlMind error hierarchy."""

from __future__ import annotations


class OwlMindError(Exception):
    """Base error for all owlmind exceptions."""


class TransientError(OwlMindError):
    """Retryable error — timeout, rate limit, 5xx, connection issues."""


class StructuralError(OwlMindError):
    """Non-retryable error — schema violation, auth failure, bad request."""
