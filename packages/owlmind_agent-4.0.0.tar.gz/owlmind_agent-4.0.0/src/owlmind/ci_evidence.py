"""CI Evidence — produce a JSON pack describing CI artifacts and checks."""

from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from pathlib import Path


@dataclass
class CIEvidence:
    """Evidence pack from a CI run."""

    commit_sha: str = ""
    workflow_name: str = ""
    run_id: str = ""
    run_number: str = ""
    ref: str = ""
    event: str = ""
    timestamp: str = ""
    checks_executed: list[str] = field(default_factory=list)
    artifact_paths: list[str] = field(default_factory=list)


def build_ci_evidence(
    out_path: Path,
    *,
    checks: list[str] | None = None,
    reports_dir: Path | None = None,
) -> Path:
    """Build CI evidence JSON from environment and reports directory.

    Reads GitHub Actions env vars if present, scans reports/ for artifacts.
    """
    evidence = CIEvidence(
        commit_sha=os.environ.get("GITHUB_SHA", ""),
        workflow_name=os.environ.get("GITHUB_WORKFLOW", ""),
        run_id=os.environ.get("GITHUB_RUN_ID", ""),
        run_number=os.environ.get("GITHUB_RUN_NUMBER", ""),
        ref=os.environ.get("GITHUB_REF", ""),
        event=os.environ.get("GITHUB_EVENT_NAME", ""),
        timestamp=datetime.now(tz=UTC).isoformat(),
        checks_executed=checks or [],
    )

    # Scan reports dir for artifact paths
    if reports_dir and reports_dir.exists():
        for p in sorted(reports_dir.rglob("*")):
            if p.is_file():
                evidence.artifact_paths.append(str(p.relative_to(reports_dir)))

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(asdict(evidence), indent=2) + "\n")
    return out_path
