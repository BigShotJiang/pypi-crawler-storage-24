"""SQLite-backed skill pack registry with user management.

Stores pack metadata, versions, reviews, and users in a single SQLite
database.  Suitable for single-node deployments; swap with PostgreSQL
implementation for multi-node production use.

Usage::

    from owlmind.registry.public import SQLitePublicPackRegistry

    registry = SQLitePublicPackRegistry("registry.db")
    await registry.publish_pack("my-pack", PublishRequest(...))
    packs = await registry.search_packs(q="code review")
"""

from __future__ import annotations

import asyncio
import json
import logging
import sqlite3
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from owlmind.registry.models import PackStatus, PublishRequest

logger = logging.getLogger(__name__)

_SCHEMA = """\
CREATE TABLE IF NOT EXISTS public_packs (
    pack_id        TEXT PRIMARY KEY,
    name           TEXT NOT NULL,
    description    TEXT DEFAULT '',
    tags           TEXT DEFAULT '[]',
    author_name    TEXT DEFAULT '',
    author_github  TEXT DEFAULT '',
    status         TEXT DEFAULT 'pending',
    downloads      INTEGER DEFAULT 0,
    avg_rating     REAL DEFAULT 0.0,
    rating_count   INTEGER DEFAULT 0,
    latest_version TEXT DEFAULT '',
    created_at     TEXT NOT NULL,
    updated_at     TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS public_pack_versions (
    pack_id              TEXT NOT NULL,
    version              TEXT NOT NULL,
    archive_sha256       TEXT DEFAULT '',
    archive_size         INTEGER DEFAULT 0,
    changelog            TEXT DEFAULT '',
    min_owlmind_version  TEXT DEFAULT '',
    created_at           TEXT NOT NULL,
    PRIMARY KEY (pack_id, version),
    FOREIGN KEY (pack_id) REFERENCES public_packs(pack_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS public_pack_reviews (
    review_id   TEXT PRIMARY KEY,
    pack_id     TEXT NOT NULL,
    author_name TEXT NOT NULL,
    rating      INTEGER NOT NULL CHECK(rating >= 1 AND rating <= 5),
    comment     TEXT DEFAULT '',
    created_at  TEXT NOT NULL,
    FOREIGN KEY (pack_id) REFERENCES public_packs(pack_id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_pub_packs_status ON public_packs(status);
CREATE INDEX IF NOT EXISTS idx_pub_packs_downloads ON public_packs(downloads DESC);
CREATE INDEX IF NOT EXISTS idx_pub_reviews_pack ON public_pack_reviews(pack_id);

CREATE TABLE IF NOT EXISTS registry_users (
    user_id      TEXT PRIMARY KEY,
    username     TEXT NOT NULL UNIQUE,
    email        TEXT NOT NULL DEFAULT '',
    role         TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('admin', 'user')),
    api_key_hash TEXT NOT NULL UNIQUE,
    created_at   TEXT NOT NULL,
    is_active    INTEGER NOT NULL DEFAULT 1
);

CREATE INDEX IF NOT EXISTS idx_reg_users_key ON registry_users(api_key_hash);
CREATE INDEX IF NOT EXISTS idx_reg_users_name ON registry_users(username);
"""


def _now_iso() -> str:
    return datetime.now(UTC).isoformat()


class SQLitePublicPackRegistry:
    """SQLite-backed public skill pack registry.

    All methods are async, using ``asyncio.to_thread`` for SQLite I/O.
    """

    def __init__(self, db_path: str | Path) -> None:
        self._db_path = Path(db_path)
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _init_db(self) -> None:
        conn = self._conn()
        conn.executescript(_SCHEMA)
        conn.close()

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self._db_path), check_same_thread=False)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        conn.row_factory = sqlite3.Row
        return conn

    @staticmethod
    def _pack_from_row(row: sqlite3.Row) -> dict[str, Any]:
        return {
            "pack_id": row["pack_id"],
            "name": row["name"],
            "description": row["description"],
            "tags": json.loads(row["tags"]),
            "author_name": row["author_name"],
            "author_github": row["author_github"],
            "status": row["status"],
            "downloads": row["downloads"],
            "avg_rating": round(float(row["avg_rating"]), 2),
            "rating_count": row["rating_count"],
            "latest_version": row["latest_version"],
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
        }

    @staticmethod
    def _version_from_row(row: sqlite3.Row) -> dict[str, Any]:
        return {
            "pack_id": row["pack_id"],
            "version": row["version"],
            "archive_sha256": row["archive_sha256"],
            "archive_size": row["archive_size"],
            "changelog": row["changelog"],
            "min_owlmind_version": row["min_owlmind_version"],
            "created_at": row["created_at"],
        }

    @staticmethod
    def _review_from_row(row: sqlite3.Row) -> dict[str, Any]:
        return {
            "review_id": row["review_id"],
            "pack_id": row["pack_id"],
            "author_name": row["author_name"],
            "rating": row["rating"],
            "comment": row["comment"],
            "created_at": row["created_at"],
        }

    @staticmethod
    def _user_from_row(row: sqlite3.Row) -> dict[str, Any]:
        return {
            "user_id": row["user_id"],
            "username": row["username"],
            "email": row["email"],
            "role": row["role"],
            "created_at": row["created_at"],
            "is_active": bool(row["is_active"]),
        }

    # ------------------------------------------------------------------
    # User management
    # ------------------------------------------------------------------

    async def create_user(
        self,
        username: str,
        email: str,
        role: str,
        api_key_hash: str,
    ) -> dict[str, Any]:
        """Create a new registry user. Returns user dict (without hash)."""

        def _create() -> dict[str, Any]:
            conn = self._conn()
            user_id = f"usr-{uuid.uuid4().hex[:12]}"
            now = _now_iso()
            conn.execute(
                "INSERT INTO registry_users "
                "(user_id, username, email, role, api_key_hash, created_at, is_active) "
                "VALUES (?, ?, ?, ?, ?, ?, 1)",
                (user_id, username, email, role, api_key_hash, now),
            )
            conn.commit()
            row = conn.execute(
                "SELECT * FROM registry_users WHERE user_id = ?", (user_id,)
            ).fetchone()
            conn.close()
            return self._user_from_row(row)

        return await asyncio.to_thread(_create)

    async def get_user_by_key_hash(self, api_key_hash: str) -> dict[str, Any] | None:
        """Look up user by SHA256 hash of their API key."""

        def _get() -> dict[str, Any] | None:
            conn = self._conn()
            row = conn.execute(
                "SELECT * FROM registry_users WHERE api_key_hash = ?",
                (api_key_hash,),
            ).fetchone()
            conn.close()
            return self._user_from_row(row) if row else None

        return await asyncio.to_thread(_get)

    async def get_user(self, user_id: str) -> dict[str, Any] | None:
        """Get user by user_id."""

        def _get() -> dict[str, Any] | None:
            conn = self._conn()
            row = conn.execute(
                "SELECT * FROM registry_users WHERE user_id = ?", (user_id,)
            ).fetchone()
            conn.close()
            return self._user_from_row(row) if row else None

        return await asyncio.to_thread(_get)

    async def list_users(self, include_inactive: bool = False) -> list[dict[str, Any]]:
        """List all registry users. Optionally include deactivated ones."""

        def _list() -> list[dict[str, Any]]:
            conn = self._conn()
            if include_inactive:
                rows = conn.execute("SELECT * FROM registry_users ORDER BY created_at").fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM registry_users WHERE is_active = 1 ORDER BY created_at"
                ).fetchall()
            conn.close()
            return [self._user_from_row(r) for r in rows]

        return await asyncio.to_thread(_list)

    async def deactivate_user(self, user_id: str) -> bool:
        """Set is_active=0 for a user. Returns True if user existed."""

        def _deactivate() -> bool:
            conn = self._conn()
            cursor = conn.execute(
                "UPDATE registry_users SET is_active = 0 WHERE user_id = ?",
                (user_id,),
            )
            conn.commit()
            changed = cursor.rowcount > 0
            conn.close()
            return changed

        return await asyncio.to_thread(_deactivate)

    # ------------------------------------------------------------------
    # Pack CRUD
    # ------------------------------------------------------------------

    async def publish_pack(self, pack_id: str, req: PublishRequest) -> dict[str, Any]:
        """Register a new pack with initial version. Status = pending."""

        def _publish() -> dict[str, Any]:
            conn = self._conn()
            now = _now_iso()

            # Upsert pack
            existing = conn.execute(
                "SELECT pack_id FROM public_packs WHERE pack_id = ?", (pack_id,)
            ).fetchone()

            if existing:
                conn.execute(
                    "UPDATE public_packs SET name=?, description=?, tags=?, "
                    "author_name=?, author_github=?, latest_version=?, updated_at=? "
                    "WHERE pack_id=?",
                    (
                        req.name,
                        req.description,
                        json.dumps(req.tags),
                        req.author_name,
                        req.author_github,
                        req.version,
                        now,
                        pack_id,
                    ),
                )
            else:
                conn.execute(
                    "INSERT INTO public_packs "
                    "(pack_id, name, description, tags, author_name, author_github, "
                    "status, downloads, avg_rating, rating_count, latest_version, "
                    "created_at, updated_at) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, 0, 0.0, 0, ?, ?, ?)",
                    (
                        pack_id,
                        req.name,
                        req.description,
                        json.dumps(req.tags),
                        req.author_name,
                        req.author_github,
                        PackStatus.pending.value,
                        req.version,
                        now,
                        now,
                    ),
                )

            # Insert version
            conn.execute(
                "INSERT OR REPLACE INTO public_pack_versions "
                "(pack_id, version, changelog, created_at) VALUES (?, ?, ?, ?)",
                (pack_id, req.version, req.changelog, now),
            )

            conn.commit()
            row = conn.execute(
                "SELECT * FROM public_packs WHERE pack_id = ?", (pack_id,)
            ).fetchone()
            conn.close()
            return self._pack_from_row(row)

        return await asyncio.to_thread(_publish)

    async def get_pack(self, pack_id: str) -> dict[str, Any] | None:
        """Get pack metadata by ID."""

        def _get() -> dict[str, Any] | None:
            conn = self._conn()
            row = conn.execute(
                "SELECT * FROM public_packs WHERE pack_id = ?", (pack_id,)
            ).fetchone()
            conn.close()
            return self._pack_from_row(row) if row else None

        return await asyncio.to_thread(_get)

    async def search_packs(
        self,
        q: str = "",
        tags: list[str] | None = None,
        sort: str = "downloads",
        limit: int = 20,
        offset: int = 0,
        status: str = "approved",
    ) -> list[dict[str, Any]]:
        """Search packs by name/description, filter by tags and status."""

        def _search() -> list[dict[str, Any]]:
            conn = self._conn()
            conditions = ["status = ?"]
            params: list[Any] = [status]

            if q:
                conditions.append("(name LIKE ? OR description LIKE ?)")
                params.extend([f"%{q}%", f"%{q}%"])

            if tags:
                # Filter packs whose tags JSON array contains any of the given tags
                tag_conditions = []
                for tag in tags:
                    tag_conditions.append(
                        "EXISTS (SELECT 1 FROM json_each(tags) WHERE json_each.value = ?)"
                    )
                    params.append(tag)
                conditions.append(f"({' OR '.join(tag_conditions)})")

            sort_map = {
                "downloads": "downloads DESC",
                "rating": "avg_rating DESC",
                "recent": "created_at DESC",
            }
            order = sort_map.get(sort, "downloads DESC")

            where_clause = " AND ".join(conditions)
            sql = (
                f"SELECT * FROM public_packs WHERE {where_clause} "  # noqa: S608
                f"ORDER BY {order} LIMIT ? OFFSET ?"
            )
            params.extend([limit, offset])

            rows = conn.execute(sql, params).fetchall()
            conn.close()
            return [self._pack_from_row(r) for r in rows]

        return await asyncio.to_thread(_search)

    async def approve_pack(self, pack_id: str) -> bool:
        """Set pack status to approved."""
        return await self._set_status(pack_id, PackStatus.approved.value)

    async def reject_pack(self, pack_id: str) -> bool:
        """Set pack status to rejected."""
        return await self._set_status(pack_id, PackStatus.rejected.value)

    async def _set_status(self, pack_id: str, status: str) -> bool:
        def _update() -> bool:
            conn = self._conn()
            cursor = conn.execute(
                "UPDATE public_packs SET status = ?, updated_at = ? WHERE pack_id = ?",
                (status, _now_iso(), pack_id),
            )
            conn.commit()
            changed = cursor.rowcount > 0
            conn.close()
            return changed

        return await asyncio.to_thread(_update)

    async def delete_pack(self, pack_id: str) -> bool:
        """Delete a pack and all its versions/reviews (CASCADE)."""

        def _delete() -> bool:
            conn = self._conn()
            cursor = conn.execute("DELETE FROM public_packs WHERE pack_id = ?", (pack_id,))
            conn.commit()
            changed = cursor.rowcount > 0
            conn.close()
            return changed

        return await asyncio.to_thread(_delete)

    # ------------------------------------------------------------------
    # Versions
    # ------------------------------------------------------------------

    async def add_version(
        self,
        pack_id: str,
        version: str,
        archive_sha256: str = "",
        archive_size: int = 0,
        changelog: str = "",
        min_owlmind_version: str = "",
    ) -> dict[str, Any]:
        """Add a new version to an existing pack."""

        def _add() -> dict[str, Any]:
            conn = self._conn()
            now = _now_iso()
            conn.execute(
                "INSERT OR REPLACE INTO public_pack_versions "
                "(pack_id, version, archive_sha256, archive_size, changelog, "
                "min_owlmind_version, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (
                    pack_id,
                    version,
                    archive_sha256,
                    archive_size,
                    changelog,
                    min_owlmind_version,
                    now,
                ),
            )
            conn.execute(
                "UPDATE public_packs SET latest_version = ?, updated_at = ? WHERE pack_id = ?",
                (version, now, pack_id),
            )
            conn.commit()
            row = conn.execute(
                "SELECT * FROM public_pack_versions WHERE pack_id = ? AND version = ?",
                (pack_id, version),
            ).fetchone()
            conn.close()
            return self._version_from_row(row)

        return await asyncio.to_thread(_add)

    async def list_versions(self, pack_id: str) -> list[dict[str, Any]]:
        """List all versions for a pack, newest first."""

        def _list() -> list[dict[str, Any]]:
            conn = self._conn()
            rows = conn.execute(
                "SELECT * FROM public_pack_versions WHERE pack_id = ? ORDER BY created_at DESC",
                (pack_id,),
            ).fetchall()
            conn.close()
            return [self._version_from_row(r) for r in rows]

        return await asyncio.to_thread(_list)

    async def get_version(self, pack_id: str, version: str) -> dict[str, Any] | None:
        """Get a specific version."""

        def _get() -> dict[str, Any] | None:
            conn = self._conn()
            row = conn.execute(
                "SELECT * FROM public_pack_versions WHERE pack_id = ? AND version = ?",
                (pack_id, version),
            ).fetchone()
            conn.close()
            return self._version_from_row(row) if row else None

        return await asyncio.to_thread(_get)

    # ------------------------------------------------------------------
    # Reviews
    # ------------------------------------------------------------------

    async def add_review(
        self,
        pack_id: str,
        author_name: str,
        rating: int,
        comment: str = "",
    ) -> dict[str, Any]:
        """Add a review and recalculate average rating."""

        def _add() -> dict[str, Any]:
            conn = self._conn()
            now = _now_iso()
            review_id = f"rev-{uuid.uuid4().hex[:8]}"

            conn.execute(
                "INSERT INTO public_pack_reviews "
                "(review_id, pack_id, author_name, rating, comment, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (review_id, pack_id, author_name, rating, comment, now),
            )

            # Recalculate average rating
            row = conn.execute(
                "SELECT AVG(rating) as avg_r, COUNT(*) as cnt "
                "FROM public_pack_reviews WHERE pack_id = ?",
                (pack_id,),
            ).fetchone()
            avg = round(float(row["avg_r"]), 2) if row["avg_r"] else 0.0
            cnt = row["cnt"] or 0

            conn.execute(
                "UPDATE public_packs SET avg_rating = ?, rating_count = ?, "
                "updated_at = ? WHERE pack_id = ?",
                (avg, cnt, now, pack_id),
            )
            conn.commit()

            review_row = conn.execute(
                "SELECT * FROM public_pack_reviews WHERE review_id = ?",
                (review_id,),
            ).fetchone()
            conn.close()
            return self._review_from_row(review_row)

        return await asyncio.to_thread(_add)

    async def list_reviews(self, pack_id: str) -> list[dict[str, Any]]:
        """List reviews for a pack, newest first."""

        def _list() -> list[dict[str, Any]]:
            conn = self._conn()
            rows = conn.execute(
                "SELECT * FROM public_pack_reviews WHERE pack_id = ? ORDER BY created_at DESC",
                (pack_id,),
            ).fetchall()
            conn.close()
            return [self._review_from_row(r) for r in rows]

        return await asyncio.to_thread(_list)

    # ------------------------------------------------------------------
    # Statistics
    # ------------------------------------------------------------------

    async def increment_downloads(self, pack_id: str) -> None:
        """Increment download counter for a pack."""

        def _inc() -> None:
            conn = self._conn()
            conn.execute(
                "UPDATE public_packs SET downloads = downloads + 1 WHERE pack_id = ?",
                (pack_id,),
            )
            conn.commit()
            conn.close()

        await asyncio.to_thread(_inc)
