"""Pydantic models for the skill pack registry.

Defines data models for packs, versions, reviews, users, and API
request/response schemas used by the registry API and CLI.
"""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, Field


class PackStatus(StrEnum):
    """Moderation status for a pack."""

    pending = "pending"
    approved = "approved"
    rejected = "rejected"


class UserRole(StrEnum):
    """Role for a registry user."""

    admin = "admin"
    user = "user"


# ---------------------------------------------------------------------------
# Core data models
# ---------------------------------------------------------------------------


class PublicPackMeta(BaseModel):
    """Public registry pack metadata."""

    pack_id: str
    name: str
    description: str = ""
    tags: list[str] = Field(default_factory=list)
    author_name: str = ""
    author_github: str = ""
    status: PackStatus = PackStatus.pending
    downloads: int = 0
    avg_rating: float = 0.0
    rating_count: int = 0
    latest_version: str = ""
    created_at: str = ""
    updated_at: str = ""


class PackVersionMeta(BaseModel):
    """Version metadata for a public pack."""

    pack_id: str
    version: str
    archive_sha256: str = ""
    archive_size: int = 0
    changelog: str = ""
    min_owlmind_version: str = ""
    created_at: str = ""


class Review(BaseModel):
    """User review of a pack."""

    review_id: str = ""
    pack_id: str
    author_name: str
    rating: int = Field(ge=1, le=5)
    comment: str = ""
    created_at: str = ""


# ---------------------------------------------------------------------------
# API request schemas
# ---------------------------------------------------------------------------


class PublishRequest(BaseModel):
    """Request body for POST /registry/packs."""

    name: str
    description: str = ""
    tags: list[str] = Field(default_factory=list)
    version: str
    changelog: str = ""
    author_name: str = ""
    author_github: str = ""


class ReviewRequest(BaseModel):
    """Request body for POST /registry/packs/{pack_id}/reviews."""

    rating: int = Field(ge=1, le=5)
    comment: str = ""
    author_name: str


# ---------------------------------------------------------------------------
# User management schemas
# ---------------------------------------------------------------------------


class RegistryUser(BaseModel):
    """A user registered in the private registry."""

    user_id: str
    username: str
    email: str = ""
    role: UserRole = UserRole.user
    created_at: str = ""
    is_active: bool = True


class CreateUserRequest(BaseModel):
    """Request body for POST /registry/admin/users."""

    username: str = Field(min_length=1, max_length=64)
    email: str = ""
    role: UserRole = UserRole.user


class CreateUserResponse(BaseModel):
    """Response for POST /registry/admin/users.

    Contains the plain API key (shown only once).
    """

    user: RegistryUser
    api_key: str
