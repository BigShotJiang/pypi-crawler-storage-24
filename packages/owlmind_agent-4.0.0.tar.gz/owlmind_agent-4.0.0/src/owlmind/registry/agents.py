"""Agent registry — tracks distributed worker instances.

Provides file-based and (future) PostgreSQL backed registry for
worker agents.  Each agent has an ID, capabilities, status, and
heartbeat timestamp.
"""

from __future__ import annotations

import asyncio
import json
import logging
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


def _now_iso() -> str:
    return datetime.now(UTC).isoformat()


# ===================================================================
# FileAgentRegistry — file-based AgentRegistry Protocol
# ===================================================================


class FileAgentRegistry:
    """File-based agent registry.

    Stores agent metadata in ``{base_dir}/{agent_id}.json``.
    """

    def __init__(self, base_dir: str | Path) -> None:
        self._base = Path(base_dir)
        self._base.mkdir(parents=True, exist_ok=True)

    def _agent_path(self, agent_id: str) -> Path:
        return self._base / f"{agent_id}.json"

    def _read_agent(self, agent_id: str) -> dict[str, Any] | None:
        path = self._agent_path(agent_id)
        if not path.exists():
            return None
        try:
            return json.loads(path.read_text())  # type: ignore[no-any-return]
        except (json.JSONDecodeError, OSError):
            return None

    def _write_agent(self, agent_id: str, data: dict[str, Any]) -> None:
        self._base.mkdir(parents=True, exist_ok=True)
        self._agent_path(agent_id).write_text(json.dumps(data, indent=2))

    # -- Protocol methods -----------------------------------------------

    async def register_agent(
        self,
        agent_id: str,
        *,
        hostname: str = "",
        capabilities: list[str] | None = None,
        max_concurrent: int = 1,
        meta: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Register a new agent or update existing."""

        def _register() -> dict[str, Any]:
            existing = self._read_agent(agent_id)
            now = _now_iso()
            data: dict[str, Any] = {
                "agent_id": agent_id,
                "hostname": hostname,
                "capabilities": capabilities or [],
                "max_concurrent": max_concurrent,
                "status": "idle",
                "current_tasks": 0,
                "last_heartbeat": now,
                "registered_at": existing.get("registered_at", now) if existing else now,
                "meta": meta or {},
            }
            self._write_agent(agent_id, data)
            return data

        return await asyncio.to_thread(_register)

    async def heartbeat(self, agent_id: str) -> None:
        """Update heartbeat timestamp for an agent."""

        def _heartbeat() -> None:
            data = self._read_agent(agent_id)
            if data is None:
                msg = f"Agent not found: {agent_id}"
                raise FileNotFoundError(msg)
            data["last_heartbeat"] = _now_iso()
            self._write_agent(agent_id, data)

        await asyncio.to_thread(_heartbeat)

    async def deregister(self, agent_id: str) -> None:
        """Remove an agent from the registry."""

        def _deregister() -> None:
            path = self._agent_path(agent_id)
            if path.exists():
                path.unlink()

        await asyncio.to_thread(_deregister)

    async def get_agent(self, agent_id: str) -> dict[str, Any] | None:
        """Get agent metadata by ID."""
        return await asyncio.to_thread(self._read_agent, agent_id)

    async def list_agents(self, *, status: str | None = None) -> list[dict[str, Any]]:
        """List all agents, optionally filtered by status."""

        def _list() -> list[dict[str, Any]]:
            if not self._base.is_dir():
                return []
            result: list[dict[str, Any]] = []
            for path in sorted(self._base.glob("*.json")):
                try:
                    data = json.loads(path.read_text())
                    if status and data.get("status") != status:
                        continue
                    result.append(data)
                except (json.JSONDecodeError, OSError):
                    continue
            return result

        return await asyncio.to_thread(_list)

    async def set_status(self, agent_id: str, status: str, current_tasks: int = 0) -> None:
        """Update agent status and current task count."""

        def _set_status() -> None:
            data = self._read_agent(agent_id)
            if data is None:
                msg = f"Agent not found: {agent_id}"
                raise FileNotFoundError(msg)
            data["status"] = status
            data["current_tasks"] = current_tasks
            data["last_heartbeat"] = _now_iso()
            self._write_agent(agent_id, data)

        await asyncio.to_thread(_set_status)
