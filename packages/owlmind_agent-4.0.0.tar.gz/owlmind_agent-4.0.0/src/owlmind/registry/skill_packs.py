"""Skill pack registry — distributed metadata and version management.

Provides file-based and (future) PostgreSQL + S3 backed registry for
skill packs.  File-based registry stores metadata as JSON files in a
directory.
"""

from __future__ import annotations

import asyncio
import json
import logging
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


def _now_iso() -> str:
    return datetime.now(UTC).isoformat()


# ===================================================================
# FileSkillPackRegistry — file-based SkillPackRegistry Protocol
# ===================================================================


class FileSkillPackRegistry:
    """File-based skill pack registry.

    Stores pack metadata in ``{base_dir}/{pack_id}/registry.json`` and
    version info in ``{base_dir}/{pack_id}/versions/{version}.json``.
    """

    def __init__(self, base_dir: str | Path) -> None:
        self._base = Path(base_dir)
        self._base.mkdir(parents=True, exist_ok=True)

    def _pack_dir(self, pack_id: str) -> Path:
        return self._base / pack_id

    def _meta_path(self, pack_id: str) -> Path:
        return self._pack_dir(pack_id) / "registry.json"

    def _versions_dir(self, pack_id: str) -> Path:
        return self._pack_dir(pack_id) / "versions"

    def _read_meta(self, pack_id: str) -> dict[str, Any] | None:
        path = self._meta_path(pack_id)
        if not path.exists():
            return None
        try:
            return json.loads(path.read_text())  # type: ignore[no-any-return]
        except (json.JSONDecodeError, OSError):
            return None

    def _write_meta(self, pack_id: str, data: dict[str, Any]) -> None:
        pdir = self._pack_dir(pack_id)
        pdir.mkdir(parents=True, exist_ok=True)
        self._meta_path(pack_id).write_text(json.dumps(data, indent=2))

    # -- Protocol methods -----------------------------------------------

    async def register_pack(
        self,
        pack_id: str,
        name: str,
        description: str = "",
        tags: list[str] | None = None,
    ) -> dict[str, Any]:
        """Register a new skill pack or update existing."""

        def _register() -> dict[str, Any]:
            existing = self._read_meta(pack_id)
            now = _now_iso()
            data: dict[str, Any] = {
                "pack_id": pack_id,
                "name": name,
                "description": description,
                "tags": tags or [],
                "latest_version": existing.get("latest_version", "") if existing else "",
                "created_at": existing.get("created_at", now) if existing else now,
                "updated_at": now,
            }
            self._write_meta(pack_id, data)
            return data

        return await asyncio.to_thread(_register)

    async def get_pack(self, pack_id: str) -> dict[str, Any] | None:
        """Get pack metadata by ID."""
        return await asyncio.to_thread(self._read_meta, pack_id)

    async def list_packs(self, *, tags: list[str] | None = None) -> list[dict[str, Any]]:
        """List all registered packs, optionally filtered by tags."""

        def _list() -> list[dict[str, Any]]:
            if not self._base.is_dir():
                return []
            result: list[dict[str, Any]] = []
            for pdir in sorted(self._base.iterdir()):
                if not pdir.is_dir():
                    continue
                meta = self._read_meta(pdir.name)
                if meta is None:
                    continue
                if tags:
                    pack_tags = set(meta.get("tags", []))
                    if not pack_tags.intersection(tags):
                        continue
                result.append(meta)
            return result

        return await asyncio.to_thread(_list)

    async def publish_version(
        self,
        pack_id: str,
        version: str,
        archive_key: str = "",
        sha256: str = "",
        changelog: str = "",
    ) -> dict[str, Any]:
        """Publish a new version for a skill pack."""

        def _publish() -> dict[str, Any]:
            meta = self._read_meta(pack_id)
            if meta is None:
                msg = f"Skill pack not found: {pack_id}"
                raise FileNotFoundError(msg)

            now = _now_iso()
            version_data: dict[str, Any] = {
                "pack_id": pack_id,
                "version": version,
                "archive_key": archive_key,
                "sha256": sha256,
                "changelog": changelog,
                "created_at": now,
            }

            vdir = self._versions_dir(pack_id)
            vdir.mkdir(parents=True, exist_ok=True)
            (vdir / f"{version}.json").write_text(json.dumps(version_data, indent=2))

            # Update latest_version
            meta["latest_version"] = version
            meta["updated_at"] = now
            self._write_meta(pack_id, meta)

            return version_data

        return await asyncio.to_thread(_publish)

    async def get_version(self, pack_id: str, version: str) -> dict[str, Any] | None:
        """Get a specific version."""

        def _get() -> dict[str, Any] | None:
            path = self._versions_dir(pack_id) / f"{version}.json"
            if not path.exists():
                return None
            try:
                return json.loads(path.read_text())  # type: ignore[no-any-return]
            except (json.JSONDecodeError, OSError):
                return None

        return await asyncio.to_thread(_get)

    async def list_versions(self, pack_id: str) -> list[dict[str, Any]]:
        """List all versions for a pack."""

        def _list() -> list[dict[str, Any]]:
            vdir = self._versions_dir(pack_id)
            if not vdir.is_dir():
                return []
            result: list[dict[str, Any]] = []
            for vfile in sorted(vdir.glob("*.json")):
                try:
                    data = json.loads(vfile.read_text())
                    result.append(data)
                except (json.JSONDecodeError, OSError):
                    continue
            return result

        return await asyncio.to_thread(_list)

    async def delete_pack(self, pack_id: str) -> bool:
        """Delete a skill pack and all its versions."""

        def _delete() -> bool:
            import shutil

            pdir = self._pack_dir(pack_id)
            if not pdir.exists():
                return False
            shutil.rmtree(pdir)
            return True

        return await asyncio.to_thread(_delete)
