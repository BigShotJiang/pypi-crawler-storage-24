"""Agent and Skill Pack registries for distributed OWLMIND platform."""

from __future__ import annotations

from owlmind.registry.agents import FileAgentRegistry
from owlmind.registry.skill_packs import FileSkillPackRegistry

__all__ = [
    "FileAgentRegistry",
    "FileSkillPackRegistry",
]
