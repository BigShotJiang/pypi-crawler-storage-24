"""Data models for SWE-bench evaluation."""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any


def _parse_list(value: Any) -> list[str]:
    """Parse a value that may be a JSON string or already a list."""
    if isinstance(value, list):
        return value
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
            return parsed if isinstance(parsed, list) else []
        except (json.JSONDecodeError, ValueError):
            return []
    return []


@dataclass
class SWEInstance:
    """One SWE-bench problem instance."""

    instance_id: str
    repo: str
    base_commit: str
    problem_statement: str
    hints_text: str = ""
    test_patch: str = ""
    patch: str = ""  # ground-truth patch (not used during eval)
    fail_to_pass: list[str] = field(default_factory=list)
    pass_to_pass: list[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> SWEInstance:
        return cls(
            instance_id=d.get("instance_id", ""),
            repo=d.get("repo", ""),
            base_commit=d.get("base_commit", ""),
            problem_statement=d.get("problem_statement", ""),
            hints_text=d.get("hints_text", ""),
            test_patch=d.get("test_patch", ""),
            patch=d.get("patch", ""),
            fail_to_pass=_parse_list(d.get("FAIL_TO_PASS", d.get("fail_to_pass", []))),
            pass_to_pass=_parse_list(d.get("PASS_TO_PASS", d.get("pass_to_pass", []))),
        )


@dataclass
class BenchResult:
    """Result of running OwlMind on one SWE-bench instance."""

    instance_id: str
    repo: str
    status: str = "pending"  # pending | running | passed | failed | error | skipped
    generated_patch: str = ""
    run_id: str = ""
    error: str = ""
    duration_ms: int = 0
    cost_summary: str = ""
    tests_passed: list[str] = field(default_factory=list)
    tests_failed: list[str] = field(default_factory=list)

    @property
    def resolved(self) -> bool:
        return self.status == "passed"


@dataclass
class BenchReport:
    """Aggregate report for a bench run."""

    results: list[BenchResult] = field(default_factory=list)
    total: int = 0
    passed: int = 0
    failed: int = 0
    errors: int = 0
    skipped: int = 0
    total_tokens: int = 0
    total_cost_usd: float = 0.0

    @property
    def pass_at_1(self) -> float:
        """pass@1 score (fraction of resolved instances)."""
        if self.total == 0:
            return 0.0
        return self.passed / self.total

    def summary(self) -> str:
        pct = self.pass_at_1 * 100
        cost_str = f" | {self.total_tokens:,} tokens | ~${self.total_cost_usd:.3f}" if self.total_tokens else ""
        return (
            f"SWE-bench Results: {self.passed}/{self.total} resolved "
            f"(pass@1={pct:.1f}%) | {self.errors} errors | {self.skipped} skipped"
            f"{cost_str}"
        )
