"""BenchHarness — run OwlMind on SWE-bench instances and produce a report."""
from __future__ import annotations

import json
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

from owlmind.bench.loader import load_instances
from owlmind.bench.models import BenchReport, BenchResult, SWEInstance
from owlmind.bench.runner import run_instance

logger = logging.getLogger(__name__)


class BenchHarness:
    """Run OwlMind on SWE-bench instances and collect results.

    Usage::

        harness = BenchHarness(operator=op, workspace_base=Path("/tmp/bench"))
        report = harness.run(
            source="princeton-nlp/SWE-bench_Lite",
            limit=10,
            max_workers=2,
        )
        print(report.summary())
        harness.save_report(report, Path("bench_report.json"))
    """

    def __init__(
        self,
        *,
        operator: Any,
        workspace_base: Path | None = None,
        verify: bool = False,
        timeout_sec: int = 600,
    ) -> None:
        self.operator = operator
        self.workspace_base = workspace_base or (Path.home() / ".owlmind" / "bench" / "workspaces")
        self.verify = verify
        self.timeout_sec = timeout_sec

    def run(
        self,
        source: str,
        *,
        limit: int | None = None,
        instance_ids: list[str] | None = None,
        max_workers: int = 1,
        on_result: Any = None,
        resume_from: Path | None = None,
    ) -> BenchReport:
        """Load instances and run OwlMind on each.

        Args:
            source: Path to .jsonl file or HuggingFace dataset name.
            limit: Max instances to evaluate.
            instance_ids: Subset of instance IDs to run.
            max_workers: Number of parallel workers (default 1 to avoid git conflicts).
            on_result: Optional callback(BenchResult) called after each instance.
            resume_from: Path to a previous report JSON — skip already-passed instances.

        Returns:
            BenchReport with all results and aggregate metrics.
        """
        instances = load_instances(source, limit=limit, instance_ids=instance_ids)
        if not instances:
            logger.warning("No instances loaded from %s", source)
            return BenchReport()

        # Resume: load previous results and skip already-passed instances
        prior_results: list[BenchResult] = []
        if resume_from and resume_from.exists():
            import json as _json
            prior_data = _json.loads(resume_from.read_text())
            passed_ids = {r["instance_id"] for r in prior_data.get("results", []) if r.get("status") == "passed"}
            prior_results = [
                BenchResult(
                    instance_id=r["instance_id"],
                    repo=r.get("repo", ""),
                    status=r["status"],
                    run_id=r.get("run_id", ""),
                    error=r.get("error", ""),
                    duration_ms=r.get("duration_ms", 0),
                    cost_summary=r.get("cost_summary", ""),
                    tests_passed=r.get("tests_passed", []),
                    tests_failed=r.get("tests_failed", []),
                )
                for r in prior_data.get("results", [])
                if r.get("status") == "passed"
            ]
            instances = [i for i in instances if i.instance_id not in passed_ids]
            logger.info("Resume: skipping %d passed instances, %d remaining", len(prior_results), len(instances))

        logger.info("Running bench on %d instances (workers=%d)", len(instances), max_workers)
        results = self._run_parallel(instances, max_workers=max_workers, on_result=on_result)
        return self._build_report(prior_results + results)

    def run_instance(self, instance: SWEInstance) -> BenchResult:
        """Run a single instance directly."""
        return run_instance(
            instance,
            operator=self.operator,
            workspace_base=self.workspace_base,
            verify=self.verify,
            timeout_sec=self.timeout_sec,
        )

    def _run_parallel(
        self,
        instances: list[SWEInstance],
        *,
        max_workers: int,
        on_result: Any,
    ) -> list[BenchResult]:
        results: list[BenchResult] = []

        if max_workers <= 1:
            for inst in instances:
                r = self.run_instance(inst)
                results.append(r)
                if on_result is not None:
                    on_result(r)
        else:
            with ThreadPoolExecutor(max_workers=max_workers) as pool:
                futures = {pool.submit(self.run_instance, inst): inst for inst in instances}
                for fut in as_completed(futures):
                    try:
                        r = fut.result()
                    except Exception as exc:
                        inst = futures[fut]
                        r = BenchResult(
                            instance_id=inst.instance_id,
                            repo=inst.repo,
                            status="error",
                            error=str(exc),
                        )
                    results.append(r)
                    if on_result is not None:
                        on_result(r)

        return results

    @staticmethod
    def _build_report(results: list[BenchResult]) -> BenchReport:
        import re
        report = BenchReport(results=results, total=len(results))
        for r in results:
            if r.status == "passed":
                report.passed += 1
            elif r.status in ("failed",):
                report.failed += 1
            elif r.status == "error":
                report.errors += 1
            elif r.status == "skipped":
                report.skipped += 1
            # Parse "1,234 tokens | ~$0.0123" cost_summary
            if r.cost_summary:
                m_tok = re.search(r"([\d,]+)\s*tokens", r.cost_summary)
                m_usd = re.search(r"\$([0-9.]+)", r.cost_summary)
                if m_tok:
                    report.total_tokens += int(m_tok.group(1).replace(",", ""))
                if m_usd:
                    report.total_cost_usd += float(m_usd.group(1))
        return report

    @staticmethod
    def save_report(report: BenchReport, path: Path) -> None:
        """Save report to a JSON file."""
        data = {
            "total": report.total,
            "passed": report.passed,
            "failed": report.failed,
            "errors": report.errors,
            "skipped": report.skipped,
            "pass_at_1": report.pass_at_1,
            "total_tokens": report.total_tokens,
            "total_cost_usd": round(report.total_cost_usd, 4),
            "avg_cost_usd": round(report.total_cost_usd / report.total, 4) if report.total else 0,
            "summary": report.summary(),
            "results": [
                {
                    "instance_id": r.instance_id,
                    "repo": r.repo,
                    "status": r.status,
                    "run_id": r.run_id,
                    "cost_summary": r.cost_summary,
                    "duration_ms": r.duration_ms,
                    "error": r.error,
                    "patch_lines": len(r.generated_patch.splitlines()),
                    "tests_passed": r.tests_passed,
                    "tests_failed": r.tests_failed,
                }
                for r in report.results
            ],
        }
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, indent=2, ensure_ascii=False))
        logger.info("Bench report saved to %s", path)
