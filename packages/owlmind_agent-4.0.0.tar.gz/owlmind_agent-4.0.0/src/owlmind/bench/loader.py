"""Load SWE-bench instances from JSONL/JSON files or HuggingFace."""
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from owlmind.bench.models import SWEInstance

logger = logging.getLogger(__name__)


def load_instances(
    source: str,
    *,
    limit: int | None = None,
    instance_ids: list[str] | None = None,
) -> list[SWEInstance]:
    """Load SWE-bench instances from a file path or HuggingFace dataset name.

    Args:
        source: File path (.json/.jsonl) or HuggingFace dataset name
                e.g. "princeton-nlp/SWE-bench_Lite"
        limit: Max number of instances to return.
        instance_ids: If set, only return instances with these IDs.

    Returns:
        List of SWEInstance objects.
    """
    path = Path(source)
    raw = _load_from_file(path) if path.exists() else _load_from_huggingface(source)

    instances = [SWEInstance.from_dict(d) for d in raw]

    if instance_ids:
        id_set = set(instance_ids)
        instances = [i for i in instances if i.instance_id in id_set]

    if limit:
        instances = instances[:limit]

    logger.info("Loaded %d SWE-bench instances from %s", len(instances), source)
    return instances


def _load_from_file(path: Path) -> list[dict[str, Any]]:
    """Load instances from a local .json or .jsonl file."""
    text = path.read_text(encoding="utf-8")
    if path.suffix == ".jsonl":
        return [json.loads(line) for line in text.splitlines() if line.strip()]
    data = json.loads(text)
    return data if isinstance(data, list) else [data]


def _load_from_huggingface(dataset_name: str) -> list[dict[str, Any]]:
    """Load instances from HuggingFace datasets library."""
    try:
        from datasets import load_dataset  # type: ignore[import]
    except ImportError as e:
        msg = (
            "HuggingFace 'datasets' package not installed. "
            "Run: pip install datasets\n"
            f"Or provide a local .jsonl file instead of '{dataset_name}'"
        )
        raise ImportError(msg) from e

    split = "test"
    ds = load_dataset(dataset_name, split=split)
    return [dict(row) for row in ds]
