"""Extended diagnostic checks for the doctor command.

Validates LLM provider reachability, policy YAML correctness, budget
sanity, disk space, optional dependencies, git availability, and .env
health.
"""

from __future__ import annotations

import importlib
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path

import yaml  # type: ignore[import-untyped]

from owlmind.config import OwlMindConfig

# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass
class DiagCheck:
    """A single diagnostic check result."""

    name: str
    category: str  # "config" | "provider" | "deps" | "policy" | "storage"
    ok: bool
    detail: str
    fix_hint: str = ""


# ---------------------------------------------------------------------------
# Extended doctor
# ---------------------------------------------------------------------------


def run_extended_doctor(
    cfg: OwlMindConfig,
    policies_dir: Path,
    *,
    runs_dir: Path | None = None,
    env_file: Path | None = None,
) -> list[DiagCheck]:
    """Run all extended diagnostic checks and return results."""
    checks: list[DiagCheck] = []

    checks.extend(_check_providers(cfg))
    checks.extend(_check_policies(policies_dir))
    checks.extend(_check_budget(cfg))
    checks.extend(_check_disk_space(runs_dir or Path("runs")))
    checks.extend(_check_optional_deps())
    checks.extend(_check_git())
    checks.extend(_check_env_file(env_file or Path(".env")))

    return checks


# ---------------------------------------------------------------------------
# Provider reachability
# ---------------------------------------------------------------------------


def _check_providers(cfg: OwlMindConfig) -> list[DiagCheck]:
    checks: list[DiagCheck] = []

    # OpenAI
    if cfg.openai.enabled:
        try:
            importlib.import_module("openai")
            checks.append(
                DiagCheck(
                    name="OpenAI SDK importable",
                    category="provider",
                    ok=True,
                    detail=f"openai package available (model={cfg.openai.planner_model})",
                )
            )
        except ImportError:
            checks.append(
                DiagCheck(
                    name="OpenAI SDK importable",
                    category="provider",
                    ok=False,
                    detail="openai package not installed",
                    fix_hint="pip install 'owlmind[openai]'",
                )
            )
    else:
        checks.append(
            DiagCheck(
                name="OpenAI provider",
                category="provider",
                ok=True,
                detail="Not configured (OPENAI_API_KEY empty)",
            )
        )

    # Anthropic
    if cfg.anthropic.enabled:
        try:
            importlib.import_module("anthropic")
            checks.append(
                DiagCheck(
                    name="Anthropic SDK importable",
                    category="provider",
                    ok=True,
                    detail=f"anthropic package available (model={cfg.anthropic.model})",
                )
            )
        except ImportError:
            checks.append(
                DiagCheck(
                    name="Anthropic SDK importable",
                    category="provider",
                    ok=False,
                    detail="anthropic package not installed",
                    fix_hint="pip install 'owlmind[anthropic]'",
                )
            )
    else:
        checks.append(
            DiagCheck(
                name="Anthropic provider",
                category="provider",
                ok=True,
                detail="Not configured (ANTHROPIC_API_KEY empty)",
            )
        )

    # Gemini
    if cfg.gemini.enabled:
        try:
            importlib.import_module("google.generativeai")
            checks.append(
                DiagCheck(
                    name="Gemini SDK importable",
                    category="provider",
                    ok=True,
                    detail=f"google-generativeai available (model={cfg.gemini.model})",
                )
            )
        except ImportError:
            checks.append(
                DiagCheck(
                    name="Gemini SDK importable",
                    category="provider",
                    ok=False,
                    detail="google-generativeai package not installed",
                    fix_hint="pip install 'owlmind[gemini]'",
                )
            )
    else:
        checks.append(
            DiagCheck(
                name="Gemini provider",
                category="provider",
                ok=True,
                detail="Not configured (GEMINI_API_KEY empty)",
            )
        )

    # Ollama
    if cfg.ollama.enabled:
        reachable = _http_reachable(cfg.ollama.base_url)
        checks.append(
            DiagCheck(
                name="Ollama reachable",
                category="provider",
                ok=reachable,
                detail=f"{cfg.ollama.base_url} ({'OK' if reachable else 'unreachable'})",
                fix_hint="" if reachable else "Ensure Ollama is running: ollama serve",
            )
        )

    # llama.cpp
    if cfg.llamacpp.enabled:
        reachable = _http_reachable(cfg.llamacpp.base_url)
        checks.append(
            DiagCheck(
                name="llama.cpp reachable",
                category="provider",
                ok=reachable,
                detail=f"{cfg.llamacpp.base_url} ({'OK' if reachable else 'unreachable'})",
                fix_hint="" if reachable else "Ensure llama.cpp server is running",
            )
        )

    return checks


# ---------------------------------------------------------------------------
# Policy YAML validation
# ---------------------------------------------------------------------------


def _check_policies(policies_dir: Path) -> list[DiagCheck]:
    checks: list[DiagCheck] = []

    if not policies_dir.is_dir():
        checks.append(
            DiagCheck(
                name="Policies directory",
                category="policy",
                ok=False,
                detail=f"Directory not found: {policies_dir}",
                fix_hint="Create the policies directory or run owlmind setup",
            )
        )
        return checks

    yaml_files = list(policies_dir.glob("*.yaml")) + list(policies_dir.glob("*.yml"))
    if not yaml_files:
        checks.append(
            DiagCheck(
                name="Policy YAML files",
                category="policy",
                ok=False,
                detail="No YAML files found in policies directory",
                fix_hint="Add policy.yaml and allowlist.yaml",
            )
        )
        return checks

    versions: list[str] = []
    for yf in yaml_files:
        try:
            data = yaml.safe_load(yf.read_text())
            checks.append(
                DiagCheck(
                    name=f"Parse {yf.name}",
                    category="policy",
                    ok=True,
                    detail="Valid YAML",
                )
            )
            if isinstance(data, dict) and "version" in data:
                versions.append(str(data["version"]))
        except yaml.YAMLError as exc:
            checks.append(
                DiagCheck(
                    name=f"Parse {yf.name}",
                    category="policy",
                    ok=False,
                    detail=f"YAML parse error: {exc}",
                    fix_hint=f"Fix syntax in {yf}",
                )
            )

    # Version consistency
    if len(set(versions)) > 1:
        checks.append(
            DiagCheck(
                name="Policy version consistency",
                category="policy",
                ok=False,
                detail=f"Multiple versions detected: {', '.join(sorted(set(versions)))}",
                fix_hint="Ensure all policy files use the same version",
            )
        )
    elif versions:
        checks.append(
            DiagCheck(
                name="Policy version consistency",
                category="policy",
                ok=True,
                detail=f"All policies at version {versions[0]}",
            )
        )

    return checks


# ---------------------------------------------------------------------------
# Budget config
# ---------------------------------------------------------------------------


def _check_budget(cfg: OwlMindConfig) -> list[DiagCheck]:
    checks: list[DiagCheck] = []
    b = cfg.budget

    sane = True
    issues: list[str] = []

    if b.max_tokens_per_run <= 0:
        sane = False
        issues.append("max_tokens_per_run <= 0")
    if b.max_tokens_per_day <= 0:
        sane = False
        issues.append("max_tokens_per_day <= 0")
    if b.max_usd_per_day <= 0:
        sane = False
        issues.append("max_usd_per_day <= 0")
    if b.max_llm_calls_per_hour <= 0:
        sane = False
        issues.append("max_llm_calls_per_hour <= 0")
    if b.max_tokens_per_run > b.max_tokens_per_day:
        issues.append("max_tokens_per_run > max_tokens_per_day (run limit exceeds daily)")

    checks.append(
        DiagCheck(
            name="Budget config sanity",
            category="config",
            ok=sane,
            detail="All limits > 0" if sane else f"Issues: {'; '.join(issues)}",
            fix_hint="Set positive budget limits in env vars" if not sane else "",
        )
    )

    if issues and sane:
        # Warnings (non-fatal)
        checks.append(
            DiagCheck(
                name="Budget config warnings",
                category="config",
                ok=True,
                detail=f"Warnings: {'; '.join(issues)}",
            )
        )

    return checks


# ---------------------------------------------------------------------------
# Disk space
# ---------------------------------------------------------------------------


def _check_disk_space(runs_dir: Path) -> list[DiagCheck]:
    checks: list[DiagCheck] = []
    target = runs_dir if runs_dir.exists() else runs_dir.parent
    if not target.exists():
        target = Path.home()

    try:
        usage = shutil.disk_usage(target)
        free_gb = usage.free / (1024 ** 3)
        ok = free_gb > 1.0
        checks.append(
            DiagCheck(
                name="Disk space for runs",
                category="storage",
                ok=ok,
                detail=f"{free_gb:.1f} GB free on {target}",
                fix_hint="Free up disk space" if not ok else "",
            )
        )
    except OSError as exc:
        checks.append(
            DiagCheck(
                name="Disk space for runs",
                category="storage",
                ok=False,
                detail=f"Could not check: {exc}",
            )
        )

    return checks


# ---------------------------------------------------------------------------
# Optional dependencies
# ---------------------------------------------------------------------------


_OPTIONAL_DEPS: list[tuple[str, str, str]] = [
    ("playwright", "browser", "pip install 'owlmind[browser]'"),
    ("anthropic", "vision", "pip install 'owlmind[anthropic]'"),
    ("owlmind.ast_parser", "ast", "Built-in module"),
    ("qdrant_client", "qdrant", "pip install qdrant-client"),
]


def _check_optional_deps() -> list[DiagCheck]:
    checks: list[DiagCheck] = []
    for module, label, hint in _OPTIONAL_DEPS:
        try:
            importlib.import_module(module)
            checks.append(
                DiagCheck(
                    name=f"Optional dep: {label}",
                    category="deps",
                    ok=True,
                    detail=f"{module} importable",
                )
            )
        except ImportError:
            checks.append(
                DiagCheck(
                    name=f"Optional dep: {label}",
                    category="deps",
                    ok=False,
                    detail=f"{module} not available",
                    fix_hint=hint,
                )
            )
    return checks


# ---------------------------------------------------------------------------
# Git
# ---------------------------------------------------------------------------


def _check_git() -> list[DiagCheck]:
    checks: list[DiagCheck] = []

    git_path = shutil.which("git")
    if not git_path:
        checks.append(
            DiagCheck(
                name="git available",
                category="deps",
                ok=False,
                detail="git binary not found in PATH",
                fix_hint="Install git: https://git-scm.com/",
            )
        )
        return checks

    try:
        result = subprocess.run(
            ["git", "--version"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        checks.append(
            DiagCheck(
                name="git available",
                category="deps",
                ok=True,
                detail=result.stdout.strip(),
            )
        )
    except Exception as exc:
        checks.append(
            DiagCheck(
                name="git available",
                category="deps",
                ok=False,
                detail=f"git error: {exc}",
                fix_hint="Ensure git is properly installed",
            )
        )

    # Check if cwd is a repo
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--is-inside-work-tree"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        is_repo = result.returncode == 0
        checks.append(
            DiagCheck(
                name="Workspace is git repo",
                category="deps",
                ok=is_repo,
                detail="Inside a git repository" if is_repo else "Not a git repository",
                fix_hint="" if is_repo else "Run 'git init' to initialize a repository",
            )
        )
    except Exception:
        pass

    return checks


# ---------------------------------------------------------------------------
# .env file
# ---------------------------------------------------------------------------


def _check_env_file(env_path: Path) -> list[DiagCheck]:
    checks: list[DiagCheck] = []

    if not env_path.exists():
        checks.append(
            DiagCheck(
                name=".env file",
                category="config",
                ok=True,
                detail="No .env file (using environment variables)",
            )
        )
        return checks

    try:
        content = env_path.read_text()
    except OSError as exc:
        checks.append(
            DiagCheck(
                name=".env file readable",
                category="config",
                ok=False,
                detail=f"Cannot read .env: {exc}",
            )
        )
        return checks

    issues: list[str] = []
    keys_seen: dict[str, int] = {}
    required_keys = {"OPENAI_API_KEY", "ANTHROPIC_API_KEY"}

    for lineno, line in enumerate(content.splitlines(), 1):
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if "=" not in stripped:
            issues.append(f"Line {lineno}: no '=' found (invalid syntax)")
            continue
        key, _, value = stripped.partition("=")
        key = key.strip()
        value = value.strip().strip("'\"")

        if key in keys_seen:
            issues.append(f"Line {lineno}: duplicate key '{key}' (first at line {keys_seen[key]})")
        keys_seen[key] = lineno

        if key in required_keys and not value:
            issues.append(f"Line {lineno}: required key '{key}' has empty value")

    if issues:
        checks.append(
            DiagCheck(
                name=".env file health",
                category="config",
                ok=False,
                detail=f"{len(issues)} issue(s): {'; '.join(issues[:3])}",
                fix_hint="Review and fix your .env file",
            )
        )
    else:
        checks.append(
            DiagCheck(
                name=".env file health",
                category="config",
                ok=True,
                detail=f"Parsed OK ({len(keys_seen)} keys)",
            )
        )

    return checks


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _http_reachable(url: str) -> bool:
    """Quick check if an HTTP endpoint is reachable (no auth)."""
    try:
        import urllib.request

        req = urllib.request.Request(url, method="HEAD")
        with urllib.request.urlopen(req, timeout=3):
            return True
    except Exception:
        return False
