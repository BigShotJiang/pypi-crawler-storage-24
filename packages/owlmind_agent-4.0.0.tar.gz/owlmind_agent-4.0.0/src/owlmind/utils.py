"""Utility functions: hashing, redaction, truncation, environment fingerprint."""

from __future__ import annotations

import hashlib
import os
import platform
import re
import sys
from dataclasses import dataclass


def sha256(data: str | bytes) -> str:
    """Return hex SHA-256 digest of *data*."""
    if isinstance(data, str):
        data = data.encode()
    return hashlib.sha256(data).hexdigest()


# ---------------------------------------------------------------------------
# Secret redaction
# ---------------------------------------------------------------------------

_SECRET_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"(?i)(api[_-]?key|apikey)\s*[=:]\s*\S+"),
    re.compile(r"(?i)(secret|password|passwd|pwd)\s*[=:]\s*\S+"),
    re.compile(r"(?i)(token|bearer)\s*[=:]\s*\S+"),
    re.compile(r"(?i)(access[_-]?key|private[_-]?key)\s*[=:]\s*\S+"),
    re.compile(r"sk-[A-Za-z0-9]{20,}"),
    re.compile(r"ghp_[A-Za-z0-9]{36,}"),
    re.compile(r"gho_[A-Za-z0-9]{36,}"),
    re.compile(r"xoxb-[A-Za-z0-9-]+"),
    re.compile(r"eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}"),
]


def redact_secrets(text: str) -> str:
    """Replace known secret patterns with ``[REDACTED]``."""
    result = text
    for pat in _SECRET_PATTERNS:
        result = pat.sub("[REDACTED]", result)
    return result


# ---------------------------------------------------------------------------
# Output truncation
# ---------------------------------------------------------------------------


def truncate(text: str, max_bytes: int = 1_048_576) -> tuple[str, bool]:
    """Truncate *text* to at most *max_bytes* UTF-8 bytes.

    Returns ``(text, was_truncated)``.
    """
    encoded = text.encode()
    if len(encoded) <= max_bytes:
        return text, False
    truncated = encoded[:max_bytes].decode(errors="ignore")
    return truncated + "\n... [TRUNCATED]", True


# ---------------------------------------------------------------------------
# Environment fingerprint
# ---------------------------------------------------------------------------


def env_fingerprint() -> str:
    """Return a hash summarising the current environment."""
    parts = [
        f"python={sys.version}",
        f"platform={platform.platform()}",
        f"PATH={os.environ.get('PATH', '')}",
        f"PYTHONPATH={os.environ.get('PYTHONPATH', '')}",
        f"cwd={os.getcwd()}",
    ]
    return sha256("\n".join(parts))


# ---------------------------------------------------------------------------
# ToolLimits
# ---------------------------------------------------------------------------


def add(a: int, b: int) -> int:
    """Return the sum of *a* and *b*."""
    return a + b


def multiply(a: int, b: int) -> int:
    """Return the product of *a* and *b*."""
    return a * b


def subtract(a: int, b: int) -> int:
    """Subtract b from a and return the result."""
    return a - b


def power(a: float, b: float) -> float:
    """Return *a* raised to the power of *b*.

    Examples:
        >>> power(2, 3)
        8.0
        >>> power(5, 0)
        1.0
        >>> power(2, -1)
        0.5
    """
    return float(a ** b)


def divide(a: float, b: float) -> float:
    """Return *a* divided by *b*.

    Raises ``ValueError`` if *b* is zero.
    """
    if b == 0:
        raise ValueError("Division by zero is not allowed")
    return a / b


@dataclass
class ToolLimits:
    """Hard limits enforced by ToolRunner."""

    timeout_seconds: int = 300
    max_output_bytes: int = 1_048_576  # 1 MB
    max_memory_mb: int = 512
    max_file_size_bytes: int = 10_485_760  # 10 MB
    max_concurrent_tools: int = 1
