"""GitHub CI monitor — poll GitHub API for failed checks and auto-fix via OWLMIND."""

from __future__ import annotations

import contextlib
import logging
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger(__name__)

_GITHUB_AVAILABLE = False
with contextlib.suppress(Exception):
    import importlib.util as _iutil

    _GITHUB_AVAILABLE = bool(_iutil.find_spec("urllib.request") and _iutil.find_spec("json"))


@dataclass
class CIFailure:
    """A failed CI check on a GitHub repository."""

    repo: str
    pr_number: int
    pr_title: str
    pr_branch: str
    check_name: str
    conclusion: str
    html_url: str
    workspace: str = ""


def _github_request(url: str, token: str) -> Any:
    """Make an authenticated GitHub API request."""
    import json
    import urllib.request

    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "OWLMIND-Monitor/1.0",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode())
    except Exception as exc:
        logger.debug("GitHub API error for %s: %s", url, exc)
        return None


def scan_failed_checks(repos: list[str], token: str) -> list[CIFailure]:
    """Scan GitHub repos for open PRs with failed CI checks.

    Args:
        repos: List of 'owner/repo' strings
        token: GitHub personal access token

    Returns:
        List of CIFailure objects for failed checks
    """
    failures = []
    for repo in repos:
        try:
            failures.extend(_scan_repo(repo, token))
        except Exception as exc:
            logger.debug("Error scanning repo %s: %s", repo, exc)
    return failures


def _scan_repo(repo: str, token: str) -> list[CIFailure]:
    """Scan a single repo for PR CI failures."""
    failures: list[CIFailure] = []
    # Get open PRs
    prs = _github_request(
        f"https://api.github.com/repos/{repo}/pulls?state=open&per_page=10", token
    )
    if not isinstance(prs, list):
        return failures

    for pr in prs[:5]:  # Limit to 5 PRs per repo
        pr_num = pr.get("number")
        pr_title = pr.get("title", "")[:80]
        pr_branch = pr.get("head", {}).get("ref", "")
        sha = pr.get("head", {}).get("sha", "")
        if not sha:
            continue

        # Get check runs for this commit
        checks = _github_request(
            f"https://api.github.com/repos/{repo}/commits/{sha}/check-runs?per_page=20",
            token,
        )
        if not isinstance(checks, dict):
            continue

        for check in checks.get("check_runs", []):
            conclusion = check.get("conclusion", "")
            if conclusion in ("failure", "timed_out", "startup_failure"):
                failures.append(
                    CIFailure(
                        repo=repo,
                        pr_number=pr_num,
                        pr_title=pr_title,
                        pr_branch=pr_branch,
                        check_name=check.get("name", "?"),
                        conclusion=conclusion,
                        html_url=check.get("html_url", ""),
                    )
                )
    return failures


def format_fix_goal(failure: CIFailure, workspace: str) -> str:
    """Create an autopilot goal for fixing a CI failure."""
    return (
        f"Fix CI failure on GitHub PR #{failure.pr_number} in repository {failure.repo}.\n\n"
        f"PR: {failure.pr_title}\n"
        f"Branch: {failure.pr_branch}\n"
        f"Failed check: {failure.check_name} ({failure.conclusion})\n"
        f"CI URL: {failure.html_url}\n\n"
        f"Steps:\n"
        f"1. Check out branch: git fetch origin {failure.pr_branch} && git checkout {failure.pr_branch}\n"
        f"2. Run the failing check locally to reproduce the error\n"
        f"3. Fix the root cause\n"
        f"4. Run tests to verify fix\n"
        f"5. Commit and push: git push origin {failure.pr_branch}\n"
    )
