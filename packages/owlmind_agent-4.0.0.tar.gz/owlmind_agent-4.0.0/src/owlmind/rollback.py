"""Rollback controller — safe rollback strategies for failed goals.

Supports: none, worktree_reset, branch_delete, manual.
Any git-mutating rollback requires approval before execution.
"""

from __future__ import annotations

import json
import logging
import shutil
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class RollbackRequest:
    """A pending rollback request."""

    goal_id: str
    run_id: str
    mode: str  # none | worktree_reset | branch_delete | manual
    require_approval: bool = True
    approval_token: str = ""
    approved: bool = False
    executed: bool = False
    instructions: str = ""


def create_rollback_request(
    goal_id: str,
    run_id: str,
    mode: str,
    *,
    require_approval: bool = True,
    runs_dir: Path | None = None,
) -> RollbackRequest:
    """Create a rollback request for a goal.

    If mode is 'none', returns a no-op request.
    If mode requires approval, generates an approval token.
    """
    if mode == "none":
        return RollbackRequest(
            goal_id=goal_id,
            run_id=run_id,
            mode="none",
            require_approval=False,
            approved=True,
        )

    import uuid

    token = uuid.uuid4().hex[:16] if require_approval else ""

    instructions = ""
    if mode == "manual":
        instructions = (
            f"Manual rollback required for goal {goal_id} "
            f"(run {run_id}). Review and revert changes manually."
        )
    elif mode == "worktree_reset":
        instructions = f"Will remove worktree for run {run_id} and recreate from base HEAD."
    elif mode == "branch_delete":
        instructions = f"Will delete branch owlmind/{run_id}."

    return RollbackRequest(
        goal_id=goal_id,
        run_id=run_id,
        mode=mode,
        require_approval=require_approval,
        approval_token=token,
        approved=not require_approval,
        instructions=instructions,
    )


def execute_rollback(
    request: RollbackRequest,
    runs_dir: Path,
    *,
    approval_token: str = "",
) -> dict[str, Any]:
    """Execute a rollback action.

    Returns a result dict with status and details.

    Raises RuntimeError if approval is required but token doesn't match.
    """
    if request.mode == "none":
        return {"status": "skipped", "reason": "mode=none"}

    if request.require_approval and not request.approved:
        if approval_token != request.approval_token:
            msg = (
                f"Rollback for {request.goal_id} requires approval. Token: {request.approval_token}"
            )
            raise RuntimeError(msg)
        request.approved = True

    now = datetime.now(UTC).isoformat()
    result: dict[str, Any] = {
        "goal_id": request.goal_id,
        "run_id": request.run_id,
        "mode": request.mode,
        "timestamp": now,
    }

    if request.mode == "manual":
        result["status"] = "instructions_provided"
        result["instructions"] = request.instructions
        request.executed = True
        return result

    if request.mode == "worktree_reset":
        run_dir = runs_dir / request.run_id
        worktree_dir = run_dir / "worktree"
        if worktree_dir.exists():
            shutil.rmtree(worktree_dir)
            result["status"] = "executed"
            result["action"] = f"Removed worktree: {worktree_dir}"
        else:
            result["status"] = "no_worktree"
            result["action"] = "No worktree found — nothing to reset"
        request.executed = True
        return result

    if request.mode == "branch_delete":
        # Record the intent — actual git branch deletion is delegated
        # to the user or CI (we don't run git in the orchestrator).
        result["status"] = "recorded"
        result["action"] = f"Branch owlmind/{request.run_id} marked for deletion"
        result["instructions"] = f"Run: git branch -D owlmind/{request.run_id}"
        request.executed = True
        return result

    result["status"] = "unknown_mode"
    return result


def log_rollback_event(
    session_id: str,
    sessions_dir: Path,
    event_type: str,
    data: dict[str, Any],
) -> None:
    """Append a rollback event to the session event log."""
    import fcntl

    sdir = sessions_dir / session_id
    sdir.mkdir(parents=True, exist_ok=True)
    log_path = sdir / "session.jsonl"

    event = {
        "event": event_type,
        "timestamp": datetime.now(UTC).isoformat(),
        **data,
    }

    line = json.dumps(event, default=str) + "\n"
    with log_path.open("a") as f:
        fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        try:
            f.write(line)
        finally:
            fcntl.flock(f.fileno(), fcntl.LOCK_UN)
