"""Ops Export — CSV/JSON export for ledger, sessions, runs."""

from __future__ import annotations

import contextlib
import csv
import io
import json
import zipfile
from pathlib import Path


def export_ledger_csv(ledger_dir: Path, out: Path) -> Path:
    """Export ledger usage entries to CSV."""
    from owlmind.ledger import UsageLedger

    ledger = UsageLedger(ledger_dir)
    entries = ledger._read_all()

    out.parent.mkdir(parents=True, exist_ok=True)
    buf = io.StringIO()
    if entries:
        fieldnames = list(entries[0].to_dict().keys())
        writer = csv.DictWriter(buf, fieldnames=fieldnames)
        writer.writeheader()
        for e in entries:
            writer.writerow(e.to_dict())
    else:
        buf.write(
            "ts,run_id,stage,provider,model,input_tokens,output_tokens,"
            "total_tokens,estimated_usd,latency_ms,"
            "price_per_1k_input,price_per_1k_output,currency\n"
        )

    out.write_text(buf.getvalue())
    return out


def export_sessions_csv(sessions_dir: Path, out: Path) -> Path:
    """Export session metadata to CSV."""
    rows: list[dict[str, str]] = []

    if sessions_dir.exists():
        for sess_dir in sorted(sessions_dir.iterdir()):
            if not sess_dir.is_dir():
                continue
            meta_path = sess_dir / "session_meta.json"
            if not meta_path.exists():
                continue
            with contextlib.suppress(json.JSONDecodeError, OSError):
                meta = json.loads(meta_path.read_text())
                rows.append(
                    {
                        "session_id": sess_dir.name,
                        "status": meta.get("status", ""),
                        "created_at": meta.get("created_at", ""),
                        "updated_at": meta.get("updated_at", ""),
                        "goals_count": str(len(meta.get("goals", []))),
                    }
                )

    out.parent.mkdir(parents=True, exist_ok=True)
    buf = io.StringIO()
    fieldnames = ["session_id", "status", "created_at", "updated_at", "goals_count"]
    writer = csv.DictWriter(buf, fieldnames=fieldnames)
    writer.writeheader()
    for row in rows:
        writer.writerow(row)

    out.write_text(buf.getvalue())
    return out


def export_runs_csv(runs_dir: Path, out: Path) -> Path:
    """Export run metadata to CSV."""
    rows: list[dict[str, str]] = []

    if runs_dir.exists():
        for run_dir in sorted(runs_dir.iterdir()):
            if not run_dir.is_dir():
                continue
            meta_path = run_dir / "cycle_meta.json"
            if not meta_path.exists():
                continue
            with contextlib.suppress(json.JSONDecodeError, OSError):
                meta = json.loads(meta_path.read_text())
                rows.append(
                    {
                        "run_id": run_dir.name,
                        "state": meta.get("state", ""),
                        "goal": meta.get("goal", ""),
                        "started_at": meta.get("started_at", ""),
                        "ended_at": meta.get("ended_at", ""),
                    }
                )

    out.parent.mkdir(parents=True, exist_ok=True)
    buf = io.StringIO()
    fieldnames = ["run_id", "state", "goal", "started_at", "ended_at"]
    writer = csv.DictWriter(buf, fieldnames=fieldnames)
    writer.writeheader()
    for row in rows:
        writer.writerow(row)

    out.write_text(buf.getvalue())
    return out


def export_all_zip(
    out_zip: Path,
    *,
    ledger_dir: Path,
    sessions_dir: Path,
    runs_dir: Path,
) -> Path:
    """Export all operational data into a single zip."""
    out_zip.parent.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as zf:
        # Ledger CSV
        buf = io.StringIO()
        _write_ledger_csv(ledger_dir, buf)
        zf.writestr("ledger.csv", buf.getvalue())

        # Sessions CSV
        buf = io.StringIO()
        _write_sessions_csv(sessions_dir, buf)
        zf.writestr("sessions.csv", buf.getvalue())

        # Runs CSV
        buf = io.StringIO()
        _write_runs_csv(runs_dir, buf)
        zf.writestr("runs.csv", buf.getvalue())

    return out_zip


def _write_ledger_csv(ledger_dir: Path, buf: io.StringIO) -> None:
    from owlmind.ledger import UsageLedger

    ledger = UsageLedger(ledger_dir)
    entries = ledger._read_all()
    if entries:
        fieldnames = list(entries[0].to_dict().keys())
        writer = csv.DictWriter(buf, fieldnames=fieldnames)
        writer.writeheader()
        for e in entries:
            writer.writerow(e.to_dict())
    else:
        buf.write(
            "ts,run_id,stage,provider,model,input_tokens,output_tokens,"
            "total_tokens,estimated_usd,latency_ms,"
            "price_per_1k_input,price_per_1k_output,currency\n"
        )


def _write_sessions_csv(sessions_dir: Path, buf: io.StringIO) -> None:
    fieldnames = ["session_id", "status", "created_at", "updated_at", "goals_count"]
    writer = csv.DictWriter(buf, fieldnames=fieldnames)
    writer.writeheader()
    if not sessions_dir.exists():
        return
    for sess_dir in sorted(sessions_dir.iterdir()):
        if not sess_dir.is_dir():
            continue
        meta_path = sess_dir / "session_meta.json"
        if not meta_path.exists():
            continue
        with contextlib.suppress(json.JSONDecodeError, OSError):
            meta = json.loads(meta_path.read_text())
            writer.writerow(
                {
                    "session_id": sess_dir.name,
                    "status": meta.get("status", ""),
                    "created_at": meta.get("created_at", ""),
                    "updated_at": meta.get("updated_at", ""),
                    "goals_count": str(len(meta.get("goals", []))),
                }
            )


def _write_runs_csv(runs_dir: Path, buf: io.StringIO) -> None:
    fieldnames = ["run_id", "state", "goal", "started_at", "ended_at"]
    writer = csv.DictWriter(buf, fieldnames=fieldnames)
    writer.writeheader()
    if not runs_dir.exists():
        return
    for run_dir in sorted(runs_dir.iterdir()):
        if not run_dir.is_dir():
            continue
        meta_path = run_dir / "cycle_meta.json"
        if not meta_path.exists():
            continue
        with contextlib.suppress(json.JSONDecodeError, OSError):
            meta = json.loads(meta_path.read_text())
            writer.writerow(
                {
                    "run_id": run_dir.name,
                    "state": meta.get("state", ""),
                    "goal": meta.get("goal", ""),
                    "started_at": meta.get("started_at", ""),
                    "ended_at": meta.get("ended_at", ""),
                }
            )
