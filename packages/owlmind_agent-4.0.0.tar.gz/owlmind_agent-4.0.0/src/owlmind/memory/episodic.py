"""Episodic memory -- remembers ALL past interactions with context.

Stores every interaction as an *episode*: goal, plan, actions taken, result,
user feedback, and timestamps.  Enables semantic search over past episodes so
the orchestrator can answer questions like:

* "What did I do last time I worked on X?"
* "How did I solve a similar problem before?"
* "Which approach worked best for Y-type tasks?"

Storage: SQLite (same DB as the core MemoryStore, separate tables).
Retrieval: TF-IDF over episode text fields (reuses retrieval helpers).
"""

from __future__ import annotations

import json
import math
import re
import sqlite3
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from owlmind.utils import redact_secrets

# ---------------------------------------------------------------------------
# Schema
# ---------------------------------------------------------------------------

_EPISODIC_SCHEMA = """
CREATE TABLE IF NOT EXISTS episodes (
    episode_id   TEXT PRIMARY KEY,
    run_id       TEXT,
    goal         TEXT NOT NULL,
    plan         TEXT NOT NULL DEFAULT '',
    actions      TEXT NOT NULL DEFAULT '[]',   -- JSON array
    result       TEXT NOT NULL DEFAULT '',
    verdict      TEXT NOT NULL DEFAULT '',     -- 'success' | 'partial' | 'failure'
    user_feedback TEXT NOT NULL DEFAULT '',
    error_summary TEXT NOT NULL DEFAULT '',
    tags         TEXT NOT NULL DEFAULT '[]',   -- JSON array
    duration_ms  INTEGER NOT NULL DEFAULT 0,
    token_usage  INTEGER NOT NULL DEFAULT 0,
    created      REAL NOT NULL,
    updated      REAL NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_episodes_goal ON episodes(goal);
CREATE INDEX IF NOT EXISTS idx_episodes_verdict ON episodes(verdict);
CREATE INDEX IF NOT EXISTS idx_episodes_created ON episodes(created);

CREATE TABLE IF NOT EXISTS episode_relations (
    parent_id  TEXT NOT NULL REFERENCES episodes(episode_id) ON DELETE CASCADE,
    child_id   TEXT NOT NULL REFERENCES episodes(episode_id) ON DELETE CASCADE,
    relation   TEXT NOT NULL DEFAULT 'follow_up',  -- 'follow_up' | 'retry' | 'subtask'
    PRIMARY KEY (parent_id, child_id)
);
"""

# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------


@dataclass
class Episode:
    """A single interaction episode."""

    episode_id: str = ""
    run_id: str = ""
    goal: str = ""
    plan: str = ""
    actions: list[dict[str, Any]] = field(default_factory=list)
    result: str = ""
    verdict: str = ""          # success | partial | failure
    user_feedback: str = ""
    error_summary: str = ""
    tags: list[str] = field(default_factory=list)
    duration_ms: int = 0
    token_usage: int = 0
    created: float = 0.0
    updated: float = 0.0

    def __post_init__(self) -> None:
        if not self.episode_id:
            self.episode_id = f"ep-{uuid.uuid4().hex[:12]}"
        if not self.created:
            self.created = time.time()
        if not self.updated:
            self.updated = self.created

    @property
    def searchable_text(self) -> str:
        """Concatenate all text fields for search indexing."""
        parts = [self.goal, self.plan, self.result, self.user_feedback, self.error_summary]
        for action in self.actions:
            parts.append(str(action.get("command", "")))
            parts.append(str(action.get("output", "")))
        parts.extend(self.tags)
        return " ".join(p for p in parts if p)


@dataclass
class EpisodeSearchResult:
    """A search hit from episodic memory."""

    episode: Episode
    score: float
    match_reason: str = ""  # brief explanation of why this matched


# ---------------------------------------------------------------------------
# Episodic Memory Store
# ---------------------------------------------------------------------------


class EpisodicMemory:
    """SQLite-backed store for interaction episodes.

    Can share the same SQLite file as :class:`MemoryStore` -- the tables are
    independent (``episodes``, ``episode_relations``).

    Usage::

        em = EpisodicMemory(Path("~/.owlmind/memory.db"))
        ep = Episode(goal="refactor auth module", plan="...", result="...", verdict="success")
        em.record(ep)
        results = em.search("auth refactor")
    """

    def __init__(self, db_path: Path) -> None:
        self.db_path = db_path
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(db_path))
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._conn.executescript(_EPISODIC_SCHEMA)

    def close(self) -> None:
        self._conn.close()

    # ------------------------------------------------------------------
    # Write API
    # ------------------------------------------------------------------

    def record(self, episode: Episode) -> str:
        """Persist an episode. Returns the episode_id."""
        now = time.time()
        episode.updated = now
        if not episode.created:
            episode.created = now

        # Redact sensitive content
        goal = redact_secrets(episode.goal)
        plan = redact_secrets(episode.plan)
        result = redact_secrets(episode.result)
        user_feedback = redact_secrets(episode.user_feedback)
        error_summary = redact_secrets(episode.error_summary)
        actions_json = json.dumps(episode.actions, default=str)
        tags_json = json.dumps(episode.tags)

        self._conn.execute(
            "INSERT OR REPLACE INTO episodes "
            "(episode_id, run_id, goal, plan, actions, result, verdict, "
            " user_feedback, error_summary, tags, duration_ms, token_usage, created, updated) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                episode.episode_id,
                episode.run_id,
                goal,
                plan,
                actions_json,
                result,
                episode.verdict,
                user_feedback,
                error_summary,
                tags_json,
                episode.duration_ms,
                episode.token_usage,
                episode.created,
                episode.updated,
            ),
        )
        self._conn.commit()
        return episode.episode_id

    def add_feedback(self, episode_id: str, feedback: str) -> bool:
        """Attach user feedback to an existing episode."""
        feedback = redact_secrets(feedback)
        cur = self._conn.execute(
            "UPDATE episodes SET user_feedback = ?, updated = ? WHERE episode_id = ?",
            (feedback, time.time(), episode_id),
        )
        self._conn.commit()
        return cur.rowcount > 0

    def link_episodes(self, parent_id: str, child_id: str, relation: str = "follow_up") -> None:
        """Create a relation between two episodes."""
        self._conn.execute(
            "INSERT OR IGNORE INTO episode_relations (parent_id, child_id, relation) "
            "VALUES (?, ?, ?)",
            (parent_id, child_id, relation),
        )
        self._conn.commit()

    # ------------------------------------------------------------------
    # Read API
    # ------------------------------------------------------------------

    def get(self, episode_id: str) -> Episode | None:
        """Retrieve a single episode by ID."""
        row = self._conn.execute(
            "SELECT episode_id, run_id, goal, plan, actions, result, verdict, "
            "user_feedback, error_summary, tags, duration_ms, token_usage, created, updated "
            "FROM episodes WHERE episode_id = ?",
            (episode_id,),
        ).fetchone()
        if not row:
            return None
        return self._row_to_episode(row)

    def recent(self, limit: int = 20, verdict: str | None = None) -> list[Episode]:
        """Return recent episodes, optionally filtered by verdict."""
        if verdict:
            rows = self._conn.execute(
                "SELECT episode_id, run_id, goal, plan, actions, result, verdict, "
                "user_feedback, error_summary, tags, duration_ms, token_usage, created, updated "
                "FROM episodes WHERE verdict = ? ORDER BY created DESC LIMIT ?",
                (verdict, limit),
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT episode_id, run_id, goal, plan, actions, result, verdict, "
                "user_feedback, error_summary, tags, duration_ms, token_usage, created, updated "
                "FROM episodes ORDER BY created DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [self._row_to_episode(r) for r in rows]

    def get_related(self, episode_id: str) -> list[tuple[Episode, str]]:
        """Get episodes related to the given episode, with relation type."""
        rows = self._conn.execute(
            "SELECT e.episode_id, e.run_id, e.goal, e.plan, e.actions, e.result, e.verdict, "
            "e.user_feedback, e.error_summary, e.tags, e.duration_ms, e.token_usage, "
            "e.created, e.updated, er.relation "
            "FROM episode_relations er "
            "JOIN episodes e ON e.episode_id = er.child_id "
            "WHERE er.parent_id = ? "
            "UNION ALL "
            "SELECT e.episode_id, e.run_id, e.goal, e.plan, e.actions, e.result, e.verdict, "
            "e.user_feedback, e.error_summary, e.tags, e.duration_ms, e.token_usage, "
            "e.created, e.updated, er.relation "
            "FROM episode_relations er "
            "JOIN episodes e ON e.episode_id = er.parent_id "
            "WHERE er.child_id = ?",
            (episode_id, episode_id),
        ).fetchall()
        result: list[tuple[Episode, str]] = []
        for r in rows:
            ep = self._row_to_episode(r[:14])
            relation = r[14]
            result.append((ep, relation))
        return result

    # ------------------------------------------------------------------
    # Search API (TF-IDF over episode text)
    # ------------------------------------------------------------------

    def search(
        self,
        query_text: str,
        *,
        top_k: int = 5,
        verdict_filter: str | None = None,
        max_age_days: int | None = None,
    ) -> list[EpisodeSearchResult]:
        """Semantic search over episodes using TF-IDF scoring.

        Args:
            query_text: Natural language query.
            top_k: Max results to return.
            verdict_filter: If set, only search episodes with this verdict.
            max_age_days: If set, only search episodes newer than this.

        Returns:
            List of EpisodeSearchResult sorted by score descending.
        """
        query_tokens = _tokenize(query_text)
        if not query_tokens:
            return []

        # Build filters
        conditions: list[str] = []
        params: list[Any] = []
        if verdict_filter:
            conditions.append("verdict = ?")
            params.append(verdict_filter)
        if max_age_days is not None:
            cutoff = time.time() - (max_age_days * 86400)
            conditions.append("created >= ?")
            params.append(cutoff)

        where = ""
        if conditions:
            where = "WHERE " + " AND ".join(conditions)

        rows = self._conn.execute(
            f"SELECT episode_id, run_id, goal, plan, actions, result, verdict, "  # noqa: S608
            f"user_feedback, error_summary, tags, duration_ms, token_usage, created, updated "
            f"FROM episodes {where} ORDER BY created DESC LIMIT 500",
            params,
        ).fetchall()

        if not rows:
            return []

        # Build TF-IDF index over episodes
        episodes_with_text: list[tuple[Episode, list[str]]] = []
        doc_freqs: dict[str, int] = {}

        for row in rows:
            ep = self._row_to_episode(row)
            tokens = _tokenize(ep.searchable_text)
            episodes_with_text.append((ep, tokens))
            seen: set[str] = set()
            for t in tokens:
                if t not in seen:
                    doc_freqs[t] = doc_freqs.get(t, 0) + 1
                    seen.add(t)

        total_docs = len(episodes_with_text)
        query_tf = _term_freq(query_tokens)

        scored: list[tuple[float, Episode, str]] = []
        for ep, tokens in episodes_with_text:
            chunk_tf = _term_freq(tokens)
            score = 0.0
            matching_terms: list[str] = []
            for term, q_weight in query_tf.items():
                tf = chunk_tf.get(term, 0.0)
                if tf > 0:
                    df = doc_freqs.get(term, 0)
                    # Use smoothed IDF: log((total+1)/(df+1)) + 1 to avoid zero scores
                    idf = math.log((total_docs + 1) / (df + 1)) + 1.0
                    score += q_weight * tf * idf
                    matching_terms.append(term)

            if score > 0:
                reason = f"matched: {', '.join(matching_terms[:5])}"
                scored.append((score, ep, reason))

        scored.sort(key=lambda x: -x[0])
        return [
            EpisodeSearchResult(episode=ep, score=round(sc, 4), match_reason=reason)
            for sc, ep, reason in scored[:top_k]
        ]

    def find_similar_goals(self, goal: str, *, top_k: int = 3) -> list[EpisodeSearchResult]:
        """Find past episodes with similar goals (convenience wrapper)."""
        return self.search(goal, top_k=top_k, verdict_filter=None)

    def find_successful_approaches(self, goal: str, *, top_k: int = 3) -> list[EpisodeSearchResult]:
        """Find past *successful* episodes matching this goal."""
        return self.search(goal, top_k=top_k, verdict_filter="success")

    # ------------------------------------------------------------------
    # Analytics
    # ------------------------------------------------------------------

    def stats(self) -> dict[str, Any]:
        """Return episodic memory statistics."""
        total = self._conn.execute("SELECT COUNT(*) FROM episodes").fetchone()[0]
        by_verdict = dict(
            self._conn.execute(
                "SELECT verdict, COUNT(*) FROM episodes GROUP BY verdict"
            ).fetchall()
        )
        avg_duration = self._conn.execute(
            "SELECT AVG(duration_ms) FROM episodes"
        ).fetchone()[0] or 0.0
        relations = self._conn.execute(
            "SELECT COUNT(*) FROM episode_relations"
        ).fetchone()[0]
        return {
            "total_episodes": total,
            "by_verdict": by_verdict,
            "avg_duration_ms": round(avg_duration, 1),
            "relations": relations,
        }

    def success_rate(self, last_n: int = 50) -> float:
        """Compute success rate over the last N episodes."""
        rows = self._conn.execute(
            "SELECT verdict FROM episodes ORDER BY created DESC LIMIT ?", (last_n,)
        ).fetchall()
        if not rows:
            return 0.0
        successes = sum(1 for (v,) in rows if v == "success")
        return successes / len(rows)

    # ------------------------------------------------------------------
    # Context building (for LLM prompt injection)
    # ------------------------------------------------------------------

    def build_context(self, goal: str, *, max_chars: int = 2000) -> str:
        """Build an episodic context string for injection into planner prompts.

        Searches for similar past episodes and formats them as a brief summary
        the LLM can use to avoid repeating mistakes and reuse successful strategies.
        """
        similar = self.search(goal, top_k=3)
        if not similar:
            return ""

        parts: list[str] = ["## Episodic Memory (past similar tasks)"]
        chars_used = len(parts[0])

        for hit in similar:
            ep = hit.episode
            verdict_icon = {"success": "OK", "partial": "PARTIAL", "failure": "FAIL"}.get(
                ep.verdict, ep.verdict.upper()
            )
            entry_lines = [
                f"\n### [{verdict_icon}] {ep.goal[:120]}",
                f"Plan: {ep.plan[:200]}" if ep.plan else "",
                f"Result: {ep.result[:200]}" if ep.result else "",
            ]
            if ep.error_summary:
                entry_lines.append(f"Error: {ep.error_summary[:150]}")
            if ep.user_feedback:
                entry_lines.append(f"Feedback: {ep.user_feedback[:150]}")

            entry = "\n".join(line for line in entry_lines if line)
            if chars_used + len(entry) > max_chars:
                break
            parts.append(entry)
            chars_used += len(entry)

        return "\n".join(parts)

    # ------------------------------------------------------------------
    # Maintenance
    # ------------------------------------------------------------------

    def purge(self, older_than_days: int | None = None) -> int:
        """Delete old episodes. Returns count deleted."""
        if older_than_days is not None:
            cutoff = time.time() - (older_than_days * 86400)
            cur = self._conn.execute("DELETE FROM episodes WHERE created < ?", (cutoff,))
        else:
            cur = self._conn.execute("DELETE FROM episodes")
        self._conn.commit()
        return cur.rowcount

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    @staticmethod
    def _row_to_episode(row: tuple[Any, ...]) -> Episode:
        """Convert a DB row tuple to an Episode dataclass."""
        (
            episode_id, run_id, goal, plan, actions_json, result, verdict,
            user_feedback, error_summary, tags_json, duration_ms, token_usage,
            created, updated,
        ) = row
        try:
            actions = json.loads(actions_json) if actions_json else []
        except (json.JSONDecodeError, TypeError):
            actions = []
        try:
            tags = json.loads(tags_json) if tags_json else []
        except (json.JSONDecodeError, TypeError):
            tags = []
        return Episode(
            episode_id=episode_id,
            run_id=run_id or "",
            goal=goal,
            plan=plan,
            actions=actions,
            result=result,
            verdict=verdict,
            user_feedback=user_feedback,
            error_summary=error_summary,
            tags=tags,
            duration_ms=duration_ms,
            token_usage=token_usage,
            created=created,
            updated=updated,
        )


# ---------------------------------------------------------------------------
# TF-IDF helpers (lightweight, no external deps)
# ---------------------------------------------------------------------------


def _tokenize(text: str) -> list[str]:
    return re.findall(r"[a-z0-9_]+", text.lower())


def _term_freq(tokens: list[str]) -> dict[str, float]:
    if not tokens:
        return {}
    counts: dict[str, int] = {}
    for t in tokens:
        counts[t] = counts.get(t, 0) + 1
    total = len(tokens)
    return {t: c / total for t, c in counts.items()}
