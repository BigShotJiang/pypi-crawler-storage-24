"""SQLite-backed memory store for OWLMIND cross-run knowledge."""

from __future__ import annotations

import hashlib
import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from owlmind.utils import redact_secrets

_SCHEMA = """
CREATE TABLE IF NOT EXISTS documents (
    doc_id   TEXT PRIMARY KEY,
    kind     TEXT NOT NULL,        -- 'run' | 'session' | 'doc' | 'signal'
    source   TEXT NOT NULL,        -- file path or run_id
    content  TEXT NOT NULL,
    sha256   TEXT NOT NULL,
    created  REAL NOT NULL,        -- epoch
    accessed REAL NOT NULL         -- last query hit
);

CREATE TABLE IF NOT EXISTS chunks (
    chunk_id  TEXT PRIMARY KEY,
    doc_id    TEXT NOT NULL REFERENCES documents(doc_id) ON DELETE CASCADE,
    seq       INTEGER NOT NULL,
    content   TEXT NOT NULL,
    sha256    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS signals (
    signal_id  INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id     TEXT,
    kind       TEXT NOT NULL,     -- 'error' | 'lesson' | 'pattern' | 'decision'
    summary    TEXT NOT NULL,
    detail     TEXT,
    created    REAL NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_chunks_doc ON chunks(doc_id);
CREATE INDEX IF NOT EXISTS idx_signals_kind ON signals(kind);
"""


@dataclass
class MemoryStoreConfig:
    """Configuration for the memory store."""

    max_docs: int = 500
    max_chunks_per_doc: int = 50
    chunk_max_chars: int = 800
    chunk_overlap: int = 100
    eviction_policy: str = "oldest"  # 'oldest' or 'least_used'


@dataclass
class Chunk:
    """A chunk of a document in memory."""

    chunk_id: str
    doc_id: str
    seq: int
    content: str
    sha256: str


@dataclass
class Signal:
    """A discrete signal (lesson, error, pattern) from a run."""

    signal_id: int
    run_id: str | None
    kind: str
    summary: str
    detail: str | None
    created: float


def _sha256(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()


def _chunk_text(text: str, max_chars: int, overlap: int) -> list[str]:
    """Split text into overlapping chunks."""
    if len(text) <= max_chars:
        return [text]
    chunks: list[str] = []
    start = 0
    while start < len(text):
        end = start + max_chars
        chunks.append(text[start:end])
        start = end - overlap
        if start >= len(text):
            break
    return chunks


class MemoryStore:
    """SQLite-backed persistent memory store."""

    def __init__(self, db_path: Path, config: MemoryStoreConfig | None = None) -> None:
        self.db_path = db_path
        self.config = config or MemoryStoreConfig()
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(db_path))
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._conn.executescript(_SCHEMA)

    def close(self) -> None:
        self._conn.close()

    def ingest(self, kind: str, source: str, content: str) -> str:
        """Ingest a document into memory. Returns doc_id.

        Content is redacted before storage. Duplicates (by sha256) are skipped.
        """
        content = redact_secrets(content)
        doc_hash = _sha256(content)

        # Check duplicate
        row = self._conn.execute(
            "SELECT doc_id FROM documents WHERE sha256 = ?", (doc_hash,)
        ).fetchone()
        if row:
            return str(row[0])

        doc_id = f"doc-{doc_hash[:16]}"
        now = time.time()

        # Evict if at capacity
        self._evict_if_needed()

        self._conn.execute(
            "INSERT INTO documents (doc_id, kind, source, content, sha256, created, accessed) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (doc_id, kind, source, content, doc_hash, now, now),
        )

        # Chunk the content
        chunks = _chunk_text(content, self.config.chunk_max_chars, self.config.chunk_overlap)
        for seq, chunk_text in enumerate(chunks[: self.config.max_chunks_per_doc]):
            chunk_hash = _sha256(chunk_text)
            chunk_id = f"chk-{chunk_hash[:16]}"
            self._conn.execute(
                "INSERT OR IGNORE INTO chunks (chunk_id, doc_id, seq, content, sha256) "
                "VALUES (?, ?, ?, ?, ?)",
                (chunk_id, doc_id, seq, chunk_text, chunk_hash),
            )

        self._conn.commit()
        return doc_id

    def add_signal(
        self, kind: str, summary: str, *, run_id: str | None = None, detail: str | None = None
    ) -> int:
        """Record a signal (lesson, error, pattern)."""
        summary = redact_secrets(summary)
        if detail:
            detail = redact_secrets(detail)
        now = time.time()
        cur = self._conn.execute(
            "INSERT INTO signals (run_id, kind, summary, detail, created) VALUES (?, ?, ?, ?, ?)",
            (run_id, kind, summary, detail, now),
        )
        self._conn.commit()
        return cur.lastrowid or 0

    def get_chunks(self, doc_id: str) -> list[Chunk]:
        """Get all chunks for a document."""
        rows = self._conn.execute(
            "SELECT chunk_id, doc_id, seq, content, sha256 FROM chunks "
            "WHERE doc_id = ? ORDER BY seq",
            (doc_id,),
        ).fetchall()
        return [Chunk(*r) for r in rows]

    def delete_signal(self, signal_id: int) -> bool:
        """Delete a signal by ID. Returns True if deleted, False if not found."""
        cur = self._conn.execute(
            "DELETE FROM signals WHERE signal_id = ?", (signal_id,)
        )
        self._conn.commit()
        return cur.rowcount > 0

    def get_signals(self, kind: str | None = None, limit: int = 50) -> list[Signal]:
        """Get signals, optionally filtered by kind."""
        if kind:
            rows = self._conn.execute(
                "SELECT signal_id, run_id, kind, summary, detail, created "
                "FROM signals WHERE kind = ? ORDER BY created DESC LIMIT ?",
                (kind, limit),
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT signal_id, run_id, kind, summary, detail, created "
                "FROM signals ORDER BY created DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [Signal(*r) for r in rows]

    def stats(self) -> dict[str, Any]:
        """Return memory store statistics."""
        doc_count = self._conn.execute("SELECT COUNT(*) FROM documents").fetchone()[0]
        chunk_count = self._conn.execute("SELECT COUNT(*) FROM chunks").fetchone()[0]
        signal_count = self._conn.execute("SELECT COUNT(*) FROM signals").fetchone()[0]
        kinds = self._conn.execute("SELECT kind, COUNT(*) FROM documents GROUP BY kind").fetchall()
        return {
            "documents": doc_count,
            "chunks": chunk_count,
            "signals": signal_count,
            "docs_by_kind": dict(kinds),
        }

    def purge(self, older_than_days: int | None = None) -> int:
        """Delete old documents and their chunks. Returns count deleted."""
        if older_than_days is not None:
            cutoff = time.time() - (older_than_days * 86400)
            cur = self._conn.execute("DELETE FROM documents WHERE created < ?", (cutoff,))
        else:
            cur = self._conn.execute("DELETE FROM documents")
        # Chunks cascade-deleted via FK
        self._conn.execute(
            "DELETE FROM signals WHERE created < ?", (cutoff,)
        ) if older_than_days else self._conn.execute("DELETE FROM signals")
        self._conn.commit()
        return cur.rowcount

    def _evict_if_needed(self) -> None:
        """Evict documents if at capacity."""
        count = self._conn.execute("SELECT COUNT(*) FROM documents").fetchone()[0]
        if count < self.config.max_docs:
            return

        to_remove = count - self.config.max_docs + 1
        order = "accessed ASC" if self.config.eviction_policy == "least_used" else "created ASC"

        ids = self._conn.execute(
            f"SELECT doc_id FROM documents ORDER BY {order} LIMIT ?",  # noqa: S608
            (to_remove,),
        ).fetchall()
        for (doc_id,) in ids:
            self._conn.execute("DELETE FROM documents WHERE doc_id = ?", (doc_id,))

    def touch_doc(self, doc_id: str) -> None:
        """Update last-accessed timestamp for a document."""
        self._conn.execute(
            "UPDATE documents SET accessed = ? WHERE doc_id = ?",
            (time.time(), doc_id),
        )
        self._conn.commit()
