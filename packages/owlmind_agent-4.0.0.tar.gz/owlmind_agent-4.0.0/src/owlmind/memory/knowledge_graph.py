"""Knowledge graph -- connects concepts, projects, files, and patterns.

Builds and queries a directed graph of relationships between entities in the
codebase and workflow:

* projects -> files -> functions -> patterns
* concepts -> related concepts
* tools -> use-cases

Enables queries like:
* "What functions use this pattern?"
* "What changed in this module recently?"
* "What concepts are related to X?"
* "Show me the dependency chain for Y"

Storage: SQLite (same DB as core MemoryStore, separate tables).
Graph is represented as (subject, predicate, object) triples with metadata.
"""

from __future__ import annotations

import hashlib
import json
import re
import sqlite3
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# Schema
# ---------------------------------------------------------------------------

_GRAPH_SCHEMA = """
CREATE TABLE IF NOT EXISTS kg_nodes (
    node_id     TEXT PRIMARY KEY,
    kind        TEXT NOT NULL,        -- 'project' | 'file' | 'function' | 'class' | 'pattern' | 'concept' | 'tool'
    name        TEXT NOT NULL,
    properties  TEXT NOT NULL DEFAULT '{}',  -- JSON
    created     REAL NOT NULL,
    updated     REAL NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_kg_nodes_kind ON kg_nodes(kind);
CREATE INDEX IF NOT EXISTS idx_kg_nodes_name ON kg_nodes(name);

CREATE TABLE IF NOT EXISTS kg_edges (
    edge_id     TEXT PRIMARY KEY,
    source_id   TEXT NOT NULL REFERENCES kg_nodes(node_id) ON DELETE CASCADE,
    target_id   TEXT NOT NULL REFERENCES kg_nodes(node_id) ON DELETE CASCADE,
    predicate   TEXT NOT NULL,        -- 'contains' | 'imports' | 'calls' | 'uses_pattern' | 'related_to' | 'depends_on' | 'modified_by'
    weight      REAL NOT NULL DEFAULT 1.0,
    properties  TEXT NOT NULL DEFAULT '{}',  -- JSON
    created     REAL NOT NULL,
    updated     REAL NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_kg_edges_source ON kg_edges(source_id);
CREATE INDEX IF NOT EXISTS idx_kg_edges_target ON kg_edges(target_id);
CREATE INDEX IF NOT EXISTS idx_kg_edges_predicate ON kg_edges(predicate);

CREATE UNIQUE INDEX IF NOT EXISTS idx_kg_edges_unique
    ON kg_edges(source_id, target_id, predicate);
"""

# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------

# Valid node kinds
NODE_KINDS = frozenset({
    "project", "file", "module", "function", "class",
    "pattern", "concept", "tool", "tag",
})

# Valid edge predicates
PREDICATES = frozenset({
    "contains",       # project contains file, file contains function
    "imports",        # file imports module
    "calls",          # function calls function
    "uses_pattern",   # function/file uses pattern
    "related_to",     # concept related to concept
    "depends_on",     # module depends on module
    "modified_by",    # file modified by run
    "tagged_with",    # entity tagged with tag
    "instance_of",    # entity is instance of concept/pattern
})


@dataclass
class KGNode:
    """A node in the knowledge graph."""

    node_id: str = ""
    kind: str = "concept"
    name: str = ""
    properties: dict[str, Any] = field(default_factory=dict)
    created: float = 0.0
    updated: float = 0.0

    def __post_init__(self) -> None:
        if not self.node_id:
            self.node_id = _make_node_id(self.kind, self.name)
        if not self.created:
            self.created = time.time()
        if not self.updated:
            self.updated = self.created


@dataclass
class KGEdge:
    """An edge (relationship) in the knowledge graph."""

    edge_id: str = ""
    source_id: str = ""
    target_id: str = ""
    predicate: str = "related_to"
    weight: float = 1.0
    properties: dict[str, Any] = field(default_factory=dict)
    created: float = 0.0
    updated: float = 0.0

    def __post_init__(self) -> None:
        if not self.edge_id:
            self.edge_id = f"edge-{uuid.uuid4().hex[:12]}"
        if not self.created:
            self.created = time.time()
        if not self.updated:
            self.updated = self.created


@dataclass
class GraphSearchResult:
    """Result from a graph traversal or search."""

    node: KGNode
    score: float = 0.0
    path: list[str] = field(default_factory=list)  # node_ids in traversal path
    depth: int = 0


# ---------------------------------------------------------------------------
# Knowledge Graph Store
# ---------------------------------------------------------------------------


class KnowledgeGraph:
    """SQLite-backed knowledge graph for connecting concepts and code entities.

    Usage::

        kg = KnowledgeGraph(Path("~/.owlmind/memory.db"))

        # Add nodes
        kg.add_node("project", "charwiz")
        kg.add_node("file", "src/memory/store.py")
        kg.add_node("function", "MemoryStore.ingest")

        # Add relationships
        kg.add_edge("charwiz", "src/memory/store.py", "contains", kind_hint=("project", "file"))
        kg.add_edge("src/memory/store.py", "MemoryStore.ingest", "contains", kind_hint=("file", "function"))

        # Query
        files = kg.get_neighbors("charwiz", predicate="contains")
        related = kg.find_related("memory", max_depth=2)
    """

    def __init__(self, db_path: Path) -> None:
        self.db_path = db_path
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(db_path))
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._conn.executescript(_GRAPH_SCHEMA)

    def close(self) -> None:
        self._conn.close()

    # ------------------------------------------------------------------
    # Node API
    # ------------------------------------------------------------------

    def add_node(
        self,
        kind: str,
        name: str,
        *,
        properties: dict[str, Any] | None = None,
        node_id: str = "",
    ) -> str:
        """Add or update a node. Returns the node_id.

        If a node with the same (kind, name) already exists, its properties
        are merged and updated timestamp is refreshed.
        """
        nid = node_id or _make_node_id(kind, name)
        now = time.time()
        props_json = json.dumps(properties or {}, default=str)

        existing = self._conn.execute(
            "SELECT properties FROM kg_nodes WHERE node_id = ?", (nid,)
        ).fetchone()

        if existing:
            # Merge properties
            try:
                old_props = json.loads(existing[0])
            except (json.JSONDecodeError, TypeError):
                old_props = {}
            if properties:
                old_props.update(properties)
            self._conn.execute(
                "UPDATE kg_nodes SET properties = ?, updated = ? WHERE node_id = ?",
                (json.dumps(old_props, default=str), now, nid),
            )
        else:
            self._conn.execute(
                "INSERT INTO kg_nodes (node_id, kind, name, properties, created, updated) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (nid, kind, name, props_json, now, now),
            )

        self._conn.commit()
        return nid

    def get_node(self, node_id: str) -> KGNode | None:
        """Get a node by ID."""
        row = self._conn.execute(
            "SELECT node_id, kind, name, properties, created, updated "
            "FROM kg_nodes WHERE node_id = ?",
            (node_id,),
        ).fetchone()
        if not row:
            return None
        return self._row_to_node(row)

    def find_nodes(
        self,
        *,
        kind: str | None = None,
        name_pattern: str | None = None,
        limit: int = 50,
    ) -> list[KGNode]:
        """Find nodes by kind and/or name pattern (SQL LIKE)."""
        conditions: list[str] = []
        params: list[Any] = []
        if kind:
            conditions.append("kind = ?")
            params.append(kind)
        if name_pattern:
            conditions.append("name LIKE ?")
            params.append(f"%{name_pattern}%")

        where = ""
        if conditions:
            where = "WHERE " + " AND ".join(conditions)

        rows = self._conn.execute(
            f"SELECT node_id, kind, name, properties, created, updated "  # noqa: S608
            f"FROM kg_nodes {where} ORDER BY updated DESC LIMIT ?",
            [*params, limit],
        ).fetchall()
        return [self._row_to_node(r) for r in rows]

    def delete_node(self, node_id: str) -> bool:
        """Delete a node and all its edges. Returns True if deleted."""
        cur = self._conn.execute("DELETE FROM kg_nodes WHERE node_id = ?", (node_id,))
        self._conn.commit()
        return cur.rowcount > 0

    # ------------------------------------------------------------------
    # Edge API
    # ------------------------------------------------------------------

    def add_edge(
        self,
        source_name: str,
        target_name: str,
        predicate: str,
        *,
        kind_hint: tuple[str, str] = ("concept", "concept"),
        weight: float = 1.0,
        properties: dict[str, Any] | None = None,
    ) -> str:
        """Add or update an edge between two nodes (creating nodes if needed).

        Args:
            source_name: Name of the source node.
            target_name: Name of the target node.
            predicate: Relationship type (e.g. 'contains', 'calls').
            kind_hint: (source_kind, target_kind) used if nodes must be created.
            weight: Edge weight (higher = stronger relationship).
            properties: Extra metadata for the edge.

        Returns:
            The edge_id.
        """
        source_kind, target_kind = kind_hint
        source_id = self.add_node(source_kind, source_name)
        target_id = self.add_node(target_kind, target_name)

        now = time.time()
        props_json = json.dumps(properties or {}, default=str)

        # Upsert edge (unique on source_id, target_id, predicate)
        existing = self._conn.execute(
            "SELECT edge_id, weight, properties FROM kg_edges "
            "WHERE source_id = ? AND target_id = ? AND predicate = ?",
            (source_id, target_id, predicate),
        ).fetchone()

        if existing:
            edge_id = existing[0]
            old_weight = existing[1]
            try:
                old_props = json.loads(existing[2])
            except (json.JSONDecodeError, TypeError):
                old_props = {}
            if properties:
                old_props.update(properties)
            # Reinforce: increment weight
            new_weight = old_weight + weight * 0.1
            self._conn.execute(
                "UPDATE kg_edges SET weight = ?, properties = ?, updated = ? WHERE edge_id = ?",
                (new_weight, json.dumps(old_props, default=str), now, edge_id),
            )
        else:
            edge_id = f"edge-{uuid.uuid4().hex[:12]}"
            self._conn.execute(
                "INSERT INTO kg_edges "
                "(edge_id, source_id, target_id, predicate, weight, properties, created, updated) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (edge_id, source_id, target_id, predicate, weight, props_json, now, now),
            )

        self._conn.commit()
        return edge_id

    def get_edges(
        self,
        node_id: str,
        *,
        direction: str = "outgoing",
        predicate: str | None = None,
    ) -> list[KGEdge]:
        """Get edges connected to a node.

        Args:
            node_id: The node to query.
            direction: 'outgoing', 'incoming', or 'both'.
            predicate: Filter by predicate type.
        """
        edges: list[KGEdge] = []
        conditions_out = ["source_id = ?"]
        conditions_in = ["target_id = ?"]
        if predicate:
            conditions_out.append("predicate = ?")
            conditions_in.append("predicate = ?")

        if direction in ("outgoing", "both"):
            where = " AND ".join(conditions_out)
            p = [node_id]
            if predicate:
                p.append(predicate)
            rows = self._conn.execute(
                f"SELECT edge_id, source_id, target_id, predicate, weight, properties, "  # noqa: S608
                f"created, updated FROM kg_edges WHERE {where}",
                p,
            ).fetchall()
            edges.extend(self._row_to_edge(r) for r in rows)

        if direction in ("incoming", "both"):
            where = " AND ".join(conditions_in)
            p = [node_id]
            if predicate:
                p.append(predicate)
            rows = self._conn.execute(
                f"SELECT edge_id, source_id, target_id, predicate, weight, properties, "  # noqa: S608
                f"created, updated FROM kg_edges WHERE {where}",
                p,
            ).fetchall()
            edges.extend(self._row_to_edge(r) for r in rows)

        return edges

    # ------------------------------------------------------------------
    # Traversal / Query API
    # ------------------------------------------------------------------

    def get_neighbors(
        self,
        name: str,
        *,
        kind: str = "concept",
        predicate: str | None = None,
        direction: str = "outgoing",
    ) -> list[KGNode]:
        """Get immediate neighbors of a node.

        Args:
            name: Node name to start from.
            kind: Node kind (used to resolve node_id).
            predicate: Filter edges by predicate.
            direction: 'outgoing', 'incoming', or 'both'.

        Returns:
            List of neighboring nodes.
        """
        node_id = _make_node_id(kind, name)
        edges = self.get_edges(node_id, direction=direction, predicate=predicate)

        neighbor_ids: set[str] = set()
        for edge in edges:
            if edge.source_id == node_id:
                neighbor_ids.add(edge.target_id)
            else:
                neighbor_ids.add(edge.source_id)

        neighbors: list[KGNode] = []
        for nid in neighbor_ids:
            node = self.get_node(nid)
            if node:
                neighbors.append(node)
        return neighbors

    def find_related(
        self,
        query: str,
        *,
        max_depth: int = 2,
        top_k: int = 10,
    ) -> list[GraphSearchResult]:
        """Find nodes related to a query using BFS traversal + text matching.

        Combines name matching with graph traversal to find relevant nodes.

        Args:
            query: Search query (matched against node names).
            max_depth: Maximum traversal depth from seed nodes.
            top_k: Maximum results to return.

        Returns:
            List of GraphSearchResult sorted by relevance score.
        """
        query_tokens = set(_tokenize(query))
        if not query_tokens:
            return []

        # Phase 1: Find seed nodes by name matching
        all_nodes = self._conn.execute(
            "SELECT node_id, kind, name, properties, created, updated FROM kg_nodes"
        ).fetchall()

        seed_scores: dict[str, float] = {}
        node_cache: dict[str, KGNode] = {}
        for row in all_nodes:
            node = self._row_to_node(row)
            node_cache[node.node_id] = node
            name_tokens = set(_tokenize(node.name))
            overlap = query_tokens & name_tokens
            if overlap:
                score = len(overlap) / max(len(query_tokens), 1)
                seed_scores[node.node_id] = score

        if not seed_scores:
            return []

        # Phase 2: BFS from seed nodes, decaying score by depth
        visited: dict[str, tuple[float, list[str], int]] = {}  # node_id -> (score, path, depth)

        # Initialize with seeds
        for nid, score in seed_scores.items():
            visited[nid] = (score, [nid], 0)

        frontier = list(seed_scores.keys())
        for depth in range(1, max_depth + 1):
            next_frontier: list[str] = []
            for nid in frontier:
                parent_score = visited[nid][0]
                parent_path = visited[nid][1]

                edges = self.get_edges(nid, direction="both")
                for edge in edges:
                    neighbor_id = edge.target_id if edge.source_id == nid else edge.source_id
                    # Score decays by depth, boosted by edge weight
                    neighbor_score = parent_score * 0.5 * min(edge.weight, 2.0)

                    if neighbor_id not in visited or visited[neighbor_id][0] < neighbor_score:
                        visited[neighbor_id] = (
                            neighbor_score,
                            parent_path + [neighbor_id],
                            depth,
                        )
                        next_frontier.append(neighbor_id)

            frontier = next_frontier

        # Build results
        results: list[GraphSearchResult] = []
        for nid, (score, path, depth) in visited.items():
            node = node_cache.get(nid)
            if node is None:
                node = self.get_node(nid)
            if node:
                results.append(GraphSearchResult(
                    node=node, score=round(score, 4), path=path, depth=depth,
                ))

        results.sort(key=lambda r: r.score, reverse=True)
        return results[:top_k]

    def find_path(
        self,
        source_name: str,
        target_name: str,
        *,
        source_kind: str = "concept",
        target_kind: str = "concept",
        max_depth: int = 5,
    ) -> list[KGNode] | None:
        """Find shortest path between two nodes using BFS.

        Returns:
            List of nodes in the path, or None if no path exists.
        """
        source_id = _make_node_id(source_kind, source_name)
        target_id = _make_node_id(target_kind, target_name)

        if source_id == target_id:
            node = self.get_node(source_id)
            return [node] if node else None

        # BFS
        visited: dict[str, str | None] = {source_id: None}  # node_id -> parent_id
        frontier = [source_id]

        for _ in range(max_depth):
            next_frontier: list[str] = []
            for nid in frontier:
                edges = self.get_edges(nid, direction="both")
                for edge in edges:
                    neighbor = edge.target_id if edge.source_id == nid else edge.source_id
                    if neighbor in visited:
                        continue
                    visited[neighbor] = nid
                    if neighbor == target_id:
                        # Reconstruct path
                        path_ids: list[str] = [target_id]
                        current = target_id
                        while visited[current] is not None:
                            current = visited[current]  # type: ignore[assignment]
                            path_ids.append(current)
                        path_ids.reverse()
                        return [
                            n for nid in path_ids
                            if (n := self.get_node(nid)) is not None
                        ]
                    next_frontier.append(neighbor)
            frontier = next_frontier
            if not frontier:
                break

        return None

    # ------------------------------------------------------------------
    # Bulk ingestion (code analysis)
    # ------------------------------------------------------------------

    def index_python_file(self, file_path: str, content: str, *, project: str = "") -> int:
        """Parse a Python file and add its structure to the knowledge graph.

        Extracts: module, classes, functions, imports, and their relationships.

        Args:
            file_path: Relative or absolute file path.
            content: File content as text.
            project: Optional project name for the top-level container.

        Returns:
            Number of edges created.
        """
        edges_created = 0

        # Add file node
        self.add_node("file", file_path, properties={"lines": content.count("\n") + 1})

        # Link to project if given
        if project:
            self.add_edge(project, file_path, "contains", kind_hint=("project", "file"))
            edges_created += 1

        # Extract imports
        import_pattern = re.compile(
            r"^(?:from\s+([\w.]+)\s+)?import\s+([\w.,\s]+)", re.MULTILINE
        )
        for match in import_pattern.finditer(content):
            from_module = match.group(1) or ""
            imports = match.group(2)
            for imp in imports.split(","):
                imp = imp.strip().split(" as ")[0].strip()
                full_import = f"{from_module}.{imp}" if from_module else imp
                if full_import:
                    self.add_edge(
                        file_path, full_import, "imports",
                        kind_hint=("file", "module"),
                    )
                    edges_created += 1

        # Extract class definitions
        class_pattern = re.compile(r"^class\s+(\w+)(?:\(([^)]*)\))?:", re.MULTILINE)
        for match in class_pattern.finditer(content):
            class_name = match.group(1)
            bases = match.group(2) or ""
            full_class = f"{file_path}::{class_name}"
            self.add_node("class", full_class, properties={
                "short_name": class_name,
                "bases": bases,
            })
            self.add_edge(
                file_path, full_class, "contains",
                kind_hint=("file", "class"),
            )
            edges_created += 1

            # Base classes
            for base in bases.split(","):
                base = base.strip()
                if base and base not in ("object",):
                    self.add_edge(
                        full_class, base, "depends_on",
                        kind_hint=("class", "class"),
                    )
                    edges_created += 1

        # Extract function/method definitions
        func_pattern = re.compile(
            r"^(\s*)def\s+(\w+)\s*\(([^)]*)\)", re.MULTILINE
        )
        for match in func_pattern.finditer(content):
            indent = match.group(1)
            func_name = match.group(2)
            params = match.group(3)

            # Determine if it's a method (indented) or top-level function
            if indent and len(indent) >= 4:
                # Try to find the enclosing class
                # Look backwards from match position for class definition
                preceding = content[:match.start()]
                class_matches = list(class_pattern.finditer(preceding))
                if class_matches:
                    enclosing_class = class_matches[-1].group(1)
                    full_func = f"{file_path}::{enclosing_class}.{func_name}"
                    container = f"{file_path}::{enclosing_class}"
                else:
                    full_func = f"{file_path}::{func_name}"
                    container = file_path
            else:
                full_func = f"{file_path}::{func_name}"
                container = file_path

            self.add_node("function", full_func, properties={
                "short_name": func_name,
                "params": params.strip(),
            })
            self.add_edge(
                container, full_func, "contains",
                kind_hint=("file", "function"),
            )
            edges_created += 1

        return edges_created

    def index_directory(self, directory: Path, *, project: str = "", extensions: frozenset[str] | None = None) -> dict[str, Any]:
        """Index all Python files in a directory tree.

        Args:
            directory: Root directory to scan.
            project: Project name for the top-level container.
            extensions: File extensions to index (default: .py only).

        Returns:
            Dict with counts of files and edges created.
        """
        if extensions is None:
            extensions = frozenset({".py"})

        skip_dirs = frozenset({
            "__pycache__", ".git", "node_modules", "venv", ".venv",
            "dist", "build", ".pytest_cache", ".eggs", ".tox",
        })

        files_indexed = 0
        total_edges = 0

        proj = project or directory.name
        self.add_node("project", proj, properties={"path": str(directory)})

        for path in directory.rglob("*"):
            if not path.is_file():
                continue
            parts = path.relative_to(directory).parts
            if any(p.startswith(".") or p in skip_dirs for p in parts):
                continue
            if path.suffix.lower() not in extensions:
                continue
            if path.stat().st_size > 500_000:
                continue
            try:
                content = path.read_text(errors="ignore")
            except Exception:
                continue

            rel_path = str(path.relative_to(directory))
            edges = self.index_python_file(rel_path, content, project=proj)
            total_edges += edges
            files_indexed += 1

        return {
            "project": proj,
            "files_indexed": files_indexed,
            "edges_created": total_edges,
        }

    # ------------------------------------------------------------------
    # Context building (for LLM prompt injection)
    # ------------------------------------------------------------------

    def build_context(self, query: str, *, max_chars: int = 1500) -> str:
        """Build a knowledge graph context string for injection into LLM prompts.

        Searches the graph for relevant nodes and formats their relationships.
        """
        results = self.find_related(query, max_depth=2, top_k=8)
        if not results:
            return ""

        parts: list[str] = ["## Knowledge Graph Context"]
        chars_used = len(parts[0])

        for hit in results:
            node = hit.node
            edges = self.get_edges(node.node_id, direction="both")

            entry_lines = [f"\n### {node.kind}: {node.name} (score={hit.score})"]

            # Show relationships
            rel_strs: list[str] = []
            for edge in edges[:5]:
                if edge.source_id == node.node_id:
                    target = self.get_node(edge.target_id)
                    if target:
                        rel_strs.append(f"  --[{edge.predicate}]--> {target.kind}:{target.name}")
                else:
                    source = self.get_node(edge.source_id)
                    if source:
                        rel_strs.append(f"  <--[{edge.predicate}]-- {source.kind}:{source.name}")

            if rel_strs:
                entry_lines.extend(rel_strs[:5])

            entry = "\n".join(entry_lines)
            if chars_used + len(entry) > max_chars:
                break
            parts.append(entry)
            chars_used += len(entry)

        return "\n".join(parts)

    # ------------------------------------------------------------------
    # Analytics
    # ------------------------------------------------------------------

    def stats(self) -> dict[str, Any]:
        """Return knowledge graph statistics."""
        nodes = self._conn.execute("SELECT COUNT(*) FROM kg_nodes").fetchone()[0]
        edges = self._conn.execute("SELECT COUNT(*) FROM kg_edges").fetchone()[0]
        by_kind = dict(
            self._conn.execute(
                "SELECT kind, COUNT(*) FROM kg_nodes GROUP BY kind"
            ).fetchall()
        )
        by_predicate = dict(
            self._conn.execute(
                "SELECT predicate, COUNT(*) FROM kg_edges GROUP BY predicate"
            ).fetchall()
        )
        return {
            "total_nodes": nodes,
            "total_edges": edges,
            "nodes_by_kind": by_kind,
            "edges_by_predicate": by_predicate,
        }

    # ------------------------------------------------------------------
    # Maintenance
    # ------------------------------------------------------------------

    def purge(self, *, kind: str | None = None) -> int:
        """Delete nodes (and cascading edges). Returns count deleted."""
        if kind:
            cur = self._conn.execute("DELETE FROM kg_nodes WHERE kind = ?", (kind,))
        else:
            cur = self._conn.execute("DELETE FROM kg_nodes")
        self._conn.commit()
        return cur.rowcount

    def prune_orphan_nodes(self) -> int:
        """Delete nodes with no edges (isolated nodes)."""
        cur = self._conn.execute(
            "DELETE FROM kg_nodes WHERE node_id NOT IN "
            "(SELECT source_id FROM kg_edges UNION SELECT target_id FROM kg_edges)"
        )
        self._conn.commit()
        return cur.rowcount

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    @staticmethod
    def _row_to_node(row: tuple[Any, ...]) -> KGNode:
        node_id, kind, name, props_json, created, updated = row
        try:
            props = json.loads(props_json) if props_json else {}
        except (json.JSONDecodeError, TypeError):
            props = {}
        return KGNode(
            node_id=node_id, kind=kind, name=name,
            properties=props, created=created, updated=updated,
        )

    @staticmethod
    def _row_to_edge(row: tuple[Any, ...]) -> KGEdge:
        edge_id, source_id, target_id, predicate, weight, props_json, created, updated = row
        try:
            props = json.loads(props_json) if props_json else {}
        except (json.JSONDecodeError, TypeError):
            props = {}
        return KGEdge(
            edge_id=edge_id, source_id=source_id, target_id=target_id,
            predicate=predicate, weight=weight, properties=props,
            created=created, updated=updated,
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_node_id(kind: str, name: str) -> str:
    """Generate a deterministic node ID from kind + name."""
    key = f"{kind}:{name}"
    h = hashlib.sha256(key.encode()).hexdigest()[:12]
    return f"{kind}-{h}"


def _tokenize(text: str) -> list[str]:
    return re.findall(r"[a-z0-9_]+", text.lower())
