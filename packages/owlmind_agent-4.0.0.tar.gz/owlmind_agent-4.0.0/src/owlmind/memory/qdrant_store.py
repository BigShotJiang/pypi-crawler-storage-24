"""Qdrant vector store for semantic code search (hybrid RAG).

Provides dense vector search alongside the existing TF-IDF sparse retrieval.
Used to give Planner relevant code context from the repository.

Enabled when:
    - OWLMIND_QDRANT_URL is set (e.g. http://localhost:6333)
    - qdrant-client and fastembed packages are installed

Usage::

    from owlmind.memory.qdrant_store import QdrantCodeStore

    store = QdrantCodeStore(url="http://localhost:6333", workspace="/path/to/repo")
    store.index_workspace()  # chunk + embed all .py files
    results = store.search("authentication middleware", top_k=5)
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_COLLECTION_PREFIX = "owlmind_code_"
_CHUNK_SIZE = 40          # lines per chunk
_CHUNK_OVERLAP = 5        # overlap lines between chunks
_DEFAULT_TOP_K = 5

# File extensions to index
_INDEXABLE_EXTENSIONS = frozenset(
    {".py", ".ts", ".tsx", ".js", ".jsx", ".go", ".rs", ".java", ".rb", ".md"}
)

# Directories to skip
_SKIP_DIRS = frozenset(
    {"__pycache__", ".git", "node_modules", "venv", ".venv", "dist", "build", ".pytest_cache"}
)


try:
    from qdrant_client import QdrantClient
    from qdrant_client.models import Distance, PointStruct, VectorParams

    HAS_QDRANT = True
except ImportError:
    HAS_QDRANT = False


try:
    from fastembed import TextEmbedding

    HAS_FASTEMBED = True
except ImportError:
    HAS_FASTEMBED = False


class QdrantCodeStore:
    """Manages a Qdrant collection for code chunks with fastembed embeddings.

    Args:
        url: Qdrant server URL (e.g. http://localhost:6333).
        workspace: Path to the repository root to index.
        collection_suffix: Appended to _COLLECTION_PREFIX (default: hash of workspace path).
    """

    def __init__(
        self,
        url: str = "",
        workspace: str | Path = ".",
        *,
        collection_suffix: str = "",
    ) -> None:
        self._url = url or os.environ.get("OWLMIND_QDRANT_URL", ":memory:")
        self._workspace = Path(workspace).resolve()
        self._suffix = collection_suffix or _workspace_suffix(self._workspace)
        self._collection = f"{_COLLECTION_PREFIX}{self._suffix}"
        self._client: Any = None
        self._embedder: Any = None

    def _ensure_client(self) -> bool:
        """Lazy-init Qdrant client. Returns False if unavailable."""
        if not HAS_QDRANT:
            logger.debug("qdrant-client not installed; vector search disabled")
            return False
        if self._client is None:
            try:
                if self._url == ":memory:":
                    self._client = QdrantClient(":memory:")
                else:
                    self._client = QdrantClient(url=self._url, timeout=10)
                    # Ping
                    self._client.get_collections()
            except Exception as exc:
                logger.warning("Qdrant unavailable at %s: %s", self._url, exc)
                self._client = None
                return False
        return True

    def _ensure_embedder(self) -> bool:
        """Lazy-init fastembed model. Returns False if unavailable."""
        if not HAS_FASTEMBED:
            logger.debug("fastembed not installed; vector search disabled")
            return False
        if self._embedder is None:
            try:
                self._embedder = TextEmbedding("BAAI/bge-small-en-v1.5")
            except Exception as exc:
                logger.warning("fastembed init failed: %s", exc)
                self._embedder = None
                return False
        return True

    def is_available(self) -> bool:
        """Return True if Qdrant and fastembed are both available."""
        return self._ensure_client() and self._ensure_embedder()

    def _embed(self, texts: list[str]) -> list[list[float]]:
        """Embed a list of texts. Returns list of float vectors."""
        embeddings = list(self._embedder.embed(texts))
        return [list(map(float, e)) for e in embeddings]

    def _vector_dim(self) -> int:
        """Return embedding dimension (384 for bge-small)."""
        return 384

    def _ensure_collection(self) -> None:
        """Create Qdrant collection if it doesn't exist."""
        existing = {c.name for c in self._client.get_collections().collections}
        if self._collection not in existing:
            self._client.create_collection(
                collection_name=self._collection,
                vectors_config=VectorParams(
                    size=self._vector_dim(),
                    distance=Distance.COSINE,
                ),
            )
            logger.info("Created Qdrant collection %r", self._collection)

    def index_workspace(self, *, force_reindex: bool = False) -> dict[str, Any]:
        """Chunk and index all code files in the workspace.

        Args:
            force_reindex: If True, delete and recreate the collection first.

        Returns:
            Dict with indexed file/chunk counts.
        """
        if not self.is_available():
            return {"status": "unavailable", "chunks": 0, "files": 0}

        if force_reindex:
            try:
                self._client.delete_collection(self._collection)
                logger.info("Deleted collection %r for reindex", self._collection)
            except Exception as exc:
                logger.debug("Could not delete collection %r: %s", self._collection, exc)

        self._ensure_collection()

        chunks = list(_iter_code_chunks(self._workspace))
        if not chunks:
            return {"status": "ok", "chunks": 0, "files": 0}

        # Embed in batches of 32
        batch_size = 32
        points: list[Any] = []
        for i in range(0, len(chunks), batch_size):
            batch = chunks[i : i + batch_size]
            texts = [c["text"] for c in batch]
            vectors = self._embed(texts)
            for j, (chunk, vector) in enumerate(zip(batch, vectors, strict=True)):
                points.append(
                    PointStruct(
                        id=i + j,
                        vector=vector,
                        payload={
                            "file": chunk["file"],
                            "start_line": chunk["start_line"],
                            "end_line": chunk["end_line"],
                            "text": chunk["text"][:2000],  # truncate payload
                        },
                    )
                )

        self._client.upsert(collection_name=self._collection, points=points)
        files_count = len({c["file"] for c in chunks})
        logger.info(
            "Indexed %d chunks from %d files into %r",
            len(chunks),
            files_count,
            self._collection,
        )
        return {"status": "ok", "chunks": len(chunks), "files": files_count}

    def search(self, query: str, top_k: int = _DEFAULT_TOP_K) -> list[dict[str, Any]]:
        """Search for relevant code chunks.

        Args:
            query: Natural language search query.
            top_k: Number of results to return.

        Returns:
            List of dicts with file, start_line, end_line, text, score.
        """
        if not self.is_available():
            return []

        try:
            self._ensure_collection()
            query_vector = self._embed([query])[0]
            # qdrant-client ≥1.7 uses query_points; fall back to search for older versions
            if hasattr(self._client, "query_points"):
                res = self._client.query_points(
                    collection_name=self._collection,
                    query=query_vector,
                    limit=top_k,
                    with_payload=True,
                )
                hits = res.points
            else:
                hits = self._client.search(
                    collection_name=self._collection,
                    query_vector=query_vector,
                    limit=top_k,
                    with_payload=True,
                )
            return [
                {
                    "file": hit.payload.get("file", ""),
                    "start_line": hit.payload.get("start_line", 0),
                    "end_line": hit.payload.get("end_line", 0),
                    "text": hit.payload.get("text", ""),
                    "score": round(hit.score, 4),
                    "source": "qdrant",
                }
                for hit in hits
            ]
        except Exception as exc:
            logger.warning("Qdrant search failed: %s", exc)
            return []

    def collection_info(self) -> dict[str, Any]:
        """Return collection stats."""
        if not self._ensure_client():
            return {"available": False}
        try:
            info = self._client.get_collection(self._collection)
            return {
                "available": True,
                "collection": self._collection,
                "vectors_count": info.vectors_count,
                "points_count": info.points_count,
            }
        except Exception as exc:
            return {"available": False, "error": str(exc)}


# ---------------------------------------------------------------------------
# Hybrid search: TF-IDF + Qdrant
# ---------------------------------------------------------------------------


def hybrid_search(
    query: str,
    workspace: str | Path,
    *,
    qdrant_url: str = "",
    top_k: int = _DEFAULT_TOP_K,
    tfidf_store: Any = None,
) -> list[dict[str, Any]]:
    """Run hybrid search: combine Qdrant dense + TF-IDF sparse results.

    Qdrant results are prioritized when available. Falls back to TF-IDF only.

    Args:
        query: Search query.
        workspace: Workspace path.
        qdrant_url: Qdrant server URL (falls back to OWLMIND_QDRANT_URL env var).
        top_k: Number of results per source before deduplication.
        tfidf_store: Existing MemoryStore instance (optional).

    Returns:
        Merged deduplicated list of results, sorted by score descending.
    """
    results: list[dict[str, Any]] = []

    # Dense search (Qdrant)
    qdrant = QdrantCodeStore(url=qdrant_url, workspace=workspace)
    qdrant_results = qdrant.search(query, top_k=top_k)
    results.extend(qdrant_results)

    # Sparse search (TF-IDF fallback or supplement)
    if tfidf_store is not None:
        try:
            from owlmind.memory.retrieval import query as tfidf_query

            tfidf_results = tfidf_query(tfidf_store, query, top_k=top_k)
            for r in tfidf_results:
                # Avoid duplicates (same file + line range)
                already_seen = any(
                    res.get("file") == r.source and res.get("start_line", 0) == 0
                    for res in results
                )
                if not already_seen:
                    results.append(
                        {
                            "file": r.source,
                            "start_line": 0,
                            "end_line": 0,
                            "text": r.snippet,
                            "score": r.score,
                            "source": "tfidf",
                        }
                    )
        except Exception as exc:
            logger.debug("TF-IDF search failed: %s", exc)

    # Sort by score descending
    results.sort(key=lambda x: x.get("score", 0.0), reverse=True)
    return results[:top_k]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _workspace_suffix(workspace: Path) -> str:
    """Generate a short stable suffix from workspace path."""
    import hashlib

    return hashlib.sha1(str(workspace).encode()).hexdigest()[:8]  # noqa: S324


def _iter_code_chunks(workspace: Path) -> list[dict[str, Any]]:
    """Yield code chunks from all indexable files in workspace."""
    chunks: list[dict[str, Any]] = []
    for path in workspace.rglob("*"):
        if not path.is_file():
            continue
        # Skip hidden dirs and blacklisted dirs
        parts = path.relative_to(workspace).parts
        if any(p.startswith(".") or p in _SKIP_DIRS for p in parts):
            continue
        if path.suffix.lower() not in _INDEXABLE_EXTENSIONS:
            continue
        if path.stat().st_size > 500_000:  # skip files > 500KB
            continue
        try:
            lines = path.read_text(errors="ignore").splitlines()
        except Exception as exc:
            logger.debug("Could not read %s: %s", path, exc)
            continue

        rel_path = str(path.relative_to(workspace))
        for start in range(0, len(lines), _CHUNK_SIZE - _CHUNK_OVERLAP):
            end = min(start + _CHUNK_SIZE, len(lines))
            chunk_lines = lines[start:end]
            text = "\n".join(chunk_lines).strip()
            if len(text) < 20:  # skip empty/trivial chunks
                continue
            chunks.append(
                {
                    "file": rel_path,
                    "start_line": start + 1,
                    "end_line": end,
                    "text": text,
                }
            )
    return chunks
