"""User profile -- understands the user's style, preferences, and habits.

Tracks observable patterns from interactions to build a behavioral profile:

* Preferred languages and frameworks
* Coding style preferences (naming, formatting, patterns)
* Common commands and workflows
* Work hours and activity patterns
* Response preferences (verbose vs. terse, explanation depth)
* Favorite tools and editors
* Frequently accessed projects and files

The profile adapts behavior automatically -- the orchestrator can query it
to tailor responses, prioritize tools, and anticipate needs.

Storage: SQLite (same DB as core MemoryStore, separate tables).
"""

from __future__ import annotations

import json
import sqlite3
import time
from collections import Counter
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# Schema
# ---------------------------------------------------------------------------

_PROFILE_SCHEMA = """
CREATE TABLE IF NOT EXISTS user_preferences (
    pref_key    TEXT PRIMARY KEY,
    pref_value  TEXT NOT NULL,
    confidence  REAL NOT NULL DEFAULT 0.5,   -- 0.0-1.0 how sure we are
    source      TEXT NOT NULL DEFAULT 'observed',  -- 'observed' | 'explicit' | 'inferred'
    updated     REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS user_interactions (
    interaction_id  INTEGER PRIMARY KEY AUTOINCREMENT,
    category        TEXT NOT NULL,    -- 'command' | 'language' | 'tool' | 'file' | 'project' | 'style'
    value           TEXT NOT NULL,    -- the observed value
    context         TEXT NOT NULL DEFAULT '',  -- extra context (e.g. project name)
    created         REAL NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_interactions_category ON user_interactions(category);
CREATE INDEX IF NOT EXISTS idx_interactions_created ON user_interactions(created);

CREATE TABLE IF NOT EXISTS user_feedback_log (
    feedback_id  INTEGER PRIMARY KEY AUTOINCREMENT,
    episode_id   TEXT NOT NULL DEFAULT '',
    sentiment    TEXT NOT NULL DEFAULT 'neutral',  -- 'positive' | 'negative' | 'neutral'
    content      TEXT NOT NULL DEFAULT '',
    created      REAL NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_feedback_sentiment ON user_feedback_log(sentiment);
"""

# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------


@dataclass
class UserPreference:
    """A single user preference."""

    key: str
    value: Any
    confidence: float = 0.5
    source: str = "observed"  # observed | explicit | inferred
    updated: float = 0.0


@dataclass
class UserProfile:
    """Aggregated view of the user's preferences and habits."""

    preferred_languages: list[str] = field(default_factory=list)
    preferred_frameworks: list[str] = field(default_factory=list)
    coding_style: dict[str, str] = field(default_factory=dict)
    common_commands: list[str] = field(default_factory=list)
    work_hours: dict[str, int] = field(default_factory=dict)  # hour -> count
    response_preferences: dict[str, str] = field(default_factory=dict)
    favorite_tools: list[str] = field(default_factory=list)
    active_projects: list[str] = field(default_factory=list)
    frequent_files: list[str] = field(default_factory=list)
    feedback_sentiment: dict[str, int] = field(default_factory=dict)
    custom_preferences: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "preferred_languages": self.preferred_languages,
            "preferred_frameworks": self.preferred_frameworks,
            "coding_style": self.coding_style,
            "common_commands": self.common_commands,
            "work_hours": self.work_hours,
            "response_preferences": self.response_preferences,
            "favorite_tools": self.favorite_tools,
            "active_projects": self.active_projects,
            "frequent_files": self.frequent_files,
            "feedback_sentiment": self.feedback_sentiment,
            "custom_preferences": self.custom_preferences,
        }


# ---------------------------------------------------------------------------
# User Profile Store
# ---------------------------------------------------------------------------


class UserProfileStore:
    """SQLite-backed user profile and preference tracker.

    Observes interactions passively and builds an evolving profile.
    Users can also set explicit preferences that override inferred ones.

    Usage::

        ups = UserProfileStore(Path("~/.owlmind/memory.db"))
        ups.observe("language", "python")
        ups.observe("command", "pytest -x")
        ups.set_preference("response_style", "concise")
        profile = ups.build_profile()
    """

    def __init__(self, db_path: Path) -> None:
        self.db_path = db_path
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(db_path))
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._conn.executescript(_PROFILE_SCHEMA)

    def close(self) -> None:
        self._conn.close()

    # ------------------------------------------------------------------
    # Observation API (passive tracking)
    # ------------------------------------------------------------------

    def observe(self, category: str, value: str, *, context: str = "") -> None:
        """Record an observed interaction.

        Categories:
            language   -- programming language used (e.g. "python", "typescript")
            framework  -- framework/library (e.g. "fastapi", "react")
            command    -- shell command executed
            tool       -- tool or editor used
            file       -- file accessed or modified
            project    -- project worked on
            style      -- coding style observation (e.g. "snake_case", "type_hints")
        """
        self._conn.execute(
            "INSERT INTO user_interactions (category, value, context, created) "
            "VALUES (?, ?, ?, ?)",
            (category, value, context, time.time()),
        )
        self._conn.commit()

    def observe_batch(self, observations: list[tuple[str, str, str]]) -> None:
        """Record multiple observations at once. Each tuple: (category, value, context)."""
        now = time.time()
        self._conn.executemany(
            "INSERT INTO user_interactions (category, value, context, created) "
            "VALUES (?, ?, ?, ?)",
            [(cat, val, ctx, now) for cat, val, ctx in observations],
        )
        self._conn.commit()

    def record_feedback(
        self, sentiment: str, content: str = "", episode_id: str = ""
    ) -> None:
        """Record user feedback sentiment.

        Args:
            sentiment: 'positive', 'negative', or 'neutral'.
            content: Optional feedback text.
            episode_id: Optional link to an episode.
        """
        self._conn.execute(
            "INSERT INTO user_feedback_log (episode_id, sentiment, content, created) "
            "VALUES (?, ?, ?, ?)",
            (episode_id, sentiment, content, time.time()),
        )
        self._conn.commit()

    # ------------------------------------------------------------------
    # Explicit preference API
    # ------------------------------------------------------------------

    def set_preference(self, key: str, value: Any, *, confidence: float = 1.0) -> None:
        """Set an explicit user preference (overrides observed/inferred)."""
        self._conn.execute(
            "INSERT OR REPLACE INTO user_preferences (pref_key, pref_value, confidence, source, updated) "
            "VALUES (?, ?, ?, 'explicit', ?)",
            (key, json.dumps(value, default=str), confidence, time.time()),
        )
        self._conn.commit()

    def get_preference(self, key: str, default: Any = None) -> Any:
        """Get a single preference value."""
        row = self._conn.execute(
            "SELECT pref_value FROM user_preferences WHERE pref_key = ?", (key,)
        ).fetchone()
        if row is None:
            return default
        try:
            return json.loads(row[0])
        except (json.JSONDecodeError, TypeError):
            return row[0]

    def all_preferences(self) -> list[UserPreference]:
        """Get all stored preferences."""
        rows = self._conn.execute(
            "SELECT pref_key, pref_value, confidence, source, updated "
            "FROM user_preferences ORDER BY updated DESC"
        ).fetchall()
        result: list[UserPreference] = []
        for key, value_json, confidence, source, updated in rows:
            try:
                value = json.loads(value_json)
            except (json.JSONDecodeError, TypeError):
                value = value_json
            result.append(UserPreference(
                key=key, value=value, confidence=confidence,
                source=source, updated=updated,
            ))
        return result

    # ------------------------------------------------------------------
    # Profile building
    # ------------------------------------------------------------------

    def build_profile(self, *, max_age_days: int = 90) -> UserProfile:
        """Aggregate all observations and preferences into a UserProfile.

        Args:
            max_age_days: Only consider interactions from this many days back.

        Returns:
            A UserProfile with ranked preferences derived from observation frequency.
        """
        cutoff = time.time() - (max_age_days * 86400)

        # Load all interactions within window
        rows = self._conn.execute(
            "SELECT category, value, context, created FROM user_interactions "
            "WHERE created >= ? ORDER BY created DESC",
            (cutoff,),
        ).fetchall()

        # Bucket by category
        by_category: dict[str, list[tuple[str, str, float]]] = {}
        for cat, val, ctx, created in rows:
            by_category.setdefault(cat, []).append((val, ctx, created))

        # Rank items by frequency with recency weighting
        def _ranked(items: list[tuple[str, str, float]], top_n: int = 10) -> list[str]:
            counter: Counter[str] = Counter()
            now = time.time()
            for val, _ctx, created in items:
                # Recency weight: more recent = higher weight
                age_days = (now - created) / 86400
                weight = max(0.1, 1.0 - (age_days / max_age_days))
                counter[val] += weight
            return [item for item, _ in counter.most_common(top_n)]

        profile = UserProfile(
            preferred_languages=_ranked(by_category.get("language", [])),
            preferred_frameworks=_ranked(by_category.get("framework", [])),
            common_commands=_ranked(by_category.get("command", []), top_n=15),
            favorite_tools=_ranked(by_category.get("tool", [])),
            active_projects=_ranked(by_category.get("project", [])),
            frequent_files=_ranked(by_category.get("file", []), top_n=20),
        )

        # Coding style from observations
        style_obs = by_category.get("style", [])
        if style_obs:
            style_counter: Counter[str] = Counter()
            for val, _ctx, _created in style_obs:
                style_counter[val] += 1
            profile.coding_style = {
                item: str(count) for item, count in style_counter.most_common(10)
            }

        # Work hours from all interactions
        hour_counter: Counter[int] = Counter()
        for cat_items in by_category.values():
            for _val, _ctx, created in cat_items:
                hour = datetime.fromtimestamp(created, tz=UTC).hour
                hour_counter[hour] += 1
        profile.work_hours = dict(hour_counter.most_common())

        # Feedback sentiment
        feedback_rows = self._conn.execute(
            "SELECT sentiment, COUNT(*) FROM user_feedback_log "
            "WHERE created >= ? GROUP BY sentiment",
            (cutoff,),
        ).fetchall()
        profile.feedback_sentiment = dict(feedback_rows)

        # Explicit preferences override inferred ones
        explicit = self.all_preferences()
        response_prefs: dict[str, str] = {}
        custom: dict[str, Any] = {}
        for pref in explicit:
            if pref.key.startswith("response_"):
                response_prefs[pref.key] = str(pref.value)
            else:
                custom[pref.key] = pref.value
        profile.response_preferences = response_prefs
        profile.custom_preferences = custom

        # Auto-infer and store some derived preferences
        self._infer_preferences(profile)

        return profile

    # ------------------------------------------------------------------
    # Context building (for LLM prompt injection)
    # ------------------------------------------------------------------

    def build_context(self, *, max_chars: int = 1200) -> str:
        """Build a user profile context string for injection into LLM prompts.

        Returns a formatted summary the LLM can use to adapt its behavior.
        """
        profile = self.build_profile()
        parts: list[str] = ["## User Profile"]
        chars_used = len(parts[0])

        def _add(label: str, items: list[str] | dict[str, Any]) -> None:
            nonlocal chars_used
            if not items:
                return
            if isinstance(items, dict):
                value = ", ".join(f"{k}={v}" for k, v in list(items.items())[:5])
            else:
                value = ", ".join(items[:8])
            line = f"\n- {label}: {value}"
            if chars_used + len(line) <= max_chars:
                parts.append(line)
                chars_used += len(line)

        _add("Languages", profile.preferred_languages)
        _add("Frameworks", profile.preferred_frameworks)
        _add("Tools", profile.favorite_tools)
        _add("Active projects", profile.active_projects)
        _add("Coding style", profile.coding_style)
        _add("Response prefs", profile.response_preferences)

        if profile.common_commands:
            _add("Common commands", profile.common_commands[:5])

        # Work hours summary
        if profile.work_hours:
            peak_hours = sorted(profile.work_hours, key=profile.work_hours.get, reverse=True)[:3]  # type: ignore[arg-type]
            _add("Peak hours (UTC)", [f"{h}:00" for h in peak_hours])

        return "\n".join(parts)

    # ------------------------------------------------------------------
    # Analytics
    # ------------------------------------------------------------------

    def stats(self) -> dict[str, Any]:
        """Return profile store statistics."""
        interactions = self._conn.execute(
            "SELECT COUNT(*) FROM user_interactions"
        ).fetchone()[0]
        preferences = self._conn.execute(
            "SELECT COUNT(*) FROM user_preferences"
        ).fetchone()[0]
        feedback = self._conn.execute(
            "SELECT COUNT(*) FROM user_feedback_log"
        ).fetchone()[0]
        categories = dict(
            self._conn.execute(
                "SELECT category, COUNT(*) FROM user_interactions GROUP BY category"
            ).fetchall()
        )
        return {
            "total_interactions": interactions,
            "total_preferences": preferences,
            "total_feedback": feedback,
            "interactions_by_category": categories,
        }

    # ------------------------------------------------------------------
    # Maintenance
    # ------------------------------------------------------------------

    def purge_interactions(self, older_than_days: int | None = None) -> int:
        """Delete old interaction records."""
        if older_than_days is not None:
            cutoff = time.time() - (older_than_days * 86400)
            cur = self._conn.execute(
                "DELETE FROM user_interactions WHERE created < ?", (cutoff,)
            )
        else:
            cur = self._conn.execute("DELETE FROM user_interactions")
        self._conn.commit()
        return cur.rowcount

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _infer_preferences(self, profile: UserProfile) -> None:
        """Infer high-level preferences from aggregated data and store them."""
        now = time.time()

        # Infer primary language
        if profile.preferred_languages:
            primary_lang = profile.preferred_languages[0]
            self._conn.execute(
                "INSERT OR REPLACE INTO user_preferences "
                "(pref_key, pref_value, confidence, source, updated) "
                "VALUES (?, ?, ?, 'inferred', ?)",
                ("primary_language", json.dumps(primary_lang), 0.8, now),
            )

        # Infer verbosity preference from feedback
        pos = profile.feedback_sentiment.get("positive", 0)
        neg = profile.feedback_sentiment.get("negative", 0)
        total_fb = pos + neg
        if total_fb >= 5:
            satisfaction = pos / total_fb
            self._conn.execute(
                "INSERT OR REPLACE INTO user_preferences "
                "(pref_key, pref_value, confidence, source, updated) "
                "VALUES (?, ?, ?, 'inferred', ?)",
                (
                    "satisfaction_rate",
                    json.dumps(round(satisfaction, 2)),
                    min(0.9, total_fb / 50),
                    now,
                ),
            )

        # Infer work schedule
        if profile.work_hours:
            peak = max(profile.work_hours, key=profile.work_hours.get)  # type: ignore[arg-type]
            self._conn.execute(
                "INSERT OR REPLACE INTO user_preferences "
                "(pref_key, pref_value, confidence, source, updated) "
                "VALUES (?, ?, ?, 'inferred', ?)",
                ("peak_work_hour", json.dumps(peak), 0.6, now),
            )

        self._conn.commit()
