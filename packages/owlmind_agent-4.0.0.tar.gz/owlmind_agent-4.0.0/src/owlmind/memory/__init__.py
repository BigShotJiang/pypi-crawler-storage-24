"""OWLMIND persistent project memory -- cross-run learning.

Modules:
    store            -- SQLite-backed document/chunk/signal store
    retrieval        -- TF-IDF lexical retrieval over stored chunks
    qdrant_store     -- Optional Qdrant vector search for code
    qdrant_retrieval -- Hybrid TF-IDF + Qdrant semantic search
    episodic         -- Episodic memory (full interaction history with search)
    user_profile     -- User profiling (preferences, habits, style tracking)
    knowledge_graph  -- Knowledge graph (concepts, code entities, relationships)
"""
