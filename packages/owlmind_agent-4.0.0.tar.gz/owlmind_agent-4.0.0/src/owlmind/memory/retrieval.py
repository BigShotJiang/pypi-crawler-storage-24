"""Lexical retrieval for OWLMIND memory — no heavy deps."""

from __future__ import annotations

import math
import re
from dataclasses import dataclass

from owlmind.utils import redact_secrets

from .store import MemoryStore


@dataclass
class RetrievalResult:
    """A single retrieval hit."""

    chunk_id: str
    doc_id: str
    source: str
    score: float
    snippet: str


def _tokenize(text: str) -> list[str]:
    """Simple word tokenization (lowercase, alphanumeric)."""
    return re.findall(r"[a-z0-9_]+", text.lower())


def _term_freq(tokens: list[str]) -> dict[str, float]:
    """Compute term frequency (normalized)."""
    if not tokens:
        return {}
    counts: dict[str, int] = {}
    for t in tokens:
        counts[t] = counts.get(t, 0) + 1
    total = len(tokens)
    return {t: c / total for t, c in counts.items()}


def _idf(term: str, doc_freqs: dict[str, int], total_docs: int) -> float:
    """Compute inverse document frequency."""
    df = doc_freqs.get(term, 0)
    if df == 0:
        return 0.0
    return math.log(total_docs / df)


def query(
    store: MemoryStore,
    text: str,
    *,
    top_k: int = 5,
    max_snippet_chars: int = 400,
) -> list[RetrievalResult]:
    """Query memory store using TF-IDF lexical scoring.

    Args:
        store: The memory store to query.
        text: Query text.
        top_k: Number of results to return.
        max_snippet_chars: Maximum snippet length.

    Returns:
        List of RetrievalResult sorted by score descending.
    """
    query_tokens = _tokenize(text)
    if not query_tokens:
        return []

    # Gather all chunks with doc metadata
    rows = store._conn.execute(
        "SELECT c.chunk_id, c.doc_id, c.content, d.source "
        "FROM chunks c JOIN documents d ON c.doc_id = d.doc_id"
    ).fetchall()

    if not rows:
        return []

    # Build document frequency for IDF
    total_docs = len(rows)
    doc_freqs: dict[str, int] = {}
    chunk_tokens_map: dict[str, list[str]] = {}

    for chunk_id, _, content, _ in rows:
        tokens = _tokenize(content)
        chunk_tokens_map[chunk_id] = tokens
        seen: set[str] = set()
        for t in tokens:
            if t not in seen:
                doc_freqs[t] = doc_freqs.get(t, 0) + 1
                seen.add(t)

    # Score each chunk
    query_tf = _term_freq(query_tokens)
    scored: list[tuple[float, str, str, str, str]] = []

    for chunk_id, doc_id, content, source in rows:
        tokens = chunk_tokens_map[chunk_id]
        chunk_tf = _term_freq(tokens)

        score = 0.0
        for term, q_weight in query_tf.items():
            tf = chunk_tf.get(term, 0.0)
            idf_val = _idf(term, doc_freqs, total_docs)
            score += q_weight * tf * idf_val

        if score > 0:
            scored.append((score, chunk_id, doc_id, content, source))

    # Sort by score desc, take top_k
    scored.sort(key=lambda x: -x[0])
    results: list[RetrievalResult] = []

    seen_docs: set[str] = set()
    for score, chunk_id, doc_id, content, source in scored:
        if len(results) >= top_k:
            break
        snippet = content[:max_snippet_chars]
        if len(content) > max_snippet_chars:
            snippet += "..."
        results.append(
            RetrievalResult(
                chunk_id=chunk_id,
                doc_id=doc_id,
                source=source,
                score=round(score, 4),
                snippet=redact_secrets(snippet),
            )
        )
        # Touch the doc for LRU tracking
        if doc_id not in seen_docs:
            store.touch_doc(doc_id)
            seen_docs.add(doc_id)

    return results


def build_memory_context(
    store: MemoryStore,
    goal: str,
    *,
    top_k: int = 5,
    max_chars: int = 2000,
) -> str:
    """Build a memory context string for planner prompt injection.

    Returns a formatted string with relevant snippets and signals,
    capped at max_chars. All content is re-redacted.
    """
    results = query(store, goal, top_k=top_k)
    signals = store.get_signals(limit=10)

    parts: list[str] = []
    chars_used = 0

    if results:
        parts.append("## Relevant Memory")
        chars_used += 20
        for r in results:
            entry = f"\n- [{r.source}] (score={r.score}): {r.snippet}"
            entry = redact_secrets(entry)
            if chars_used + len(entry) > max_chars:
                break
            parts.append(entry)
            chars_used += len(entry)

    if signals:
        header = "\n\n## Signals from Past Runs"
        if chars_used + len(header) < max_chars:
            parts.append(header)
            chars_used += len(header)
            for s in signals[:5]:
                entry = f"\n- [{s.kind}] {s.summary}"
                entry = redact_secrets(entry)
                if chars_used + len(entry) > max_chars:
                    break
                parts.append(entry)
                chars_used += len(entry)

    return "".join(parts)
