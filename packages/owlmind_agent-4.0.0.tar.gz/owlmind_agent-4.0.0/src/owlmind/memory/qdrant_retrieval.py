"""Qdrant-based vector retrieval for OWLMIND project memory.

Provides semantic search over code + documentation using dense embeddings.
Falls back gracefully to TF-IDF (memory.retrieval) when Qdrant is unavailable.

Usage::

    from owlmind.memory.qdrant_retrieval import QdrantMemoryStore, hybrid_query

    store = QdrantMemoryStore(url="http://localhost:6333", collection="my_project")
    store.index_text("source.py", "def foo(): pass", tags=["python", "function"])
    results = store.search("function definition", top_k=5)

Environment variables:
    OWLMIND_QDRANT_URL        — Qdrant URL (default: http://localhost:6333)
    OWLMIND_QDRANT_COLLECTION — Collection name (default: owlmind_memory)
    OWLMIND_QDRANT_API_KEY    — Optional API key for cloud Qdrant
"""

from __future__ import annotations

import hashlib
import logging
import os
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)

_QDRANT_URL = os.environ.get("OWLMIND_QDRANT_URL", "http://localhost:6333")
_QDRANT_COLLECTION = os.environ.get("OWLMIND_QDRANT_COLLECTION", "owlmind_memory")
_QDRANT_API_KEY = os.environ.get("OWLMIND_QDRANT_API_KEY", "")

try:
    from fastembed import TextEmbedding
    from qdrant_client import QdrantClient
    from qdrant_client.http import models as qdrant_models

    HAS_QDRANT = True
except ImportError:
    HAS_QDRANT = False


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------


@dataclass
class VectorSearchResult:
    """A single result from vector search."""

    source: str  # File path or identifier
    snippet: str  # Text content
    score: float  # Similarity score (0-1)
    tags: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# QdrantMemoryStore
# ---------------------------------------------------------------------------


class QdrantMemoryStore:
    """Manages a Qdrant collection for semantic code/doc search.

    Uses fastembed for local embedding (no API key needed).
    Falls back gracefully with empty results when Qdrant is unavailable.
    """

    EMBEDDING_MODEL = "BAAI/bge-small-en-v1.5"  # 384-dim, small and fast
    VECTOR_SIZE = 384

    def __init__(
        self,
        *,
        url: str = "",
        collection: str = "",
        api_key: str = "",
    ) -> None:
        self._url = url or _QDRANT_URL
        self._collection = collection or _QDRANT_COLLECTION
        self._api_key = api_key or _QDRANT_API_KEY
        self._client: Any = None
        self._embedder: Any = None
        self._available: bool | None = None

    @property
    def available(self) -> bool:
        """Return True if Qdrant client can connect."""
        if self._available is None:
            self._available = self._try_connect()
        return self._available

    def _try_connect(self) -> bool:
        if not HAS_QDRANT:
            logger.warning(
                "Qdrant unavailable: qdrant-client or fastembed not installed, falling back to TF-IDF"
            )
            return False
        try:
            kwargs: dict[str, Any] = {"url": self._url}
            if self._api_key:
                kwargs["api_key"] = self._api_key
            self._client = QdrantClient(**kwargs)
            self._embedder = TextEmbedding(self.EMBEDDING_MODEL)
            # Test connection
            self._client.get_collections()
            self._ensure_collection()
            logger.info("Qdrant connected: %s / collection=%s", self._url, self._collection)
            return True
        except Exception as exc:
            logger.warning("Qdrant unavailable, falling back to TF-IDF: %s", exc)
            self._client = None
            self._embedder = None
            return False

    def _ensure_collection(self) -> None:
        """Create collection if it doesn't exist."""
        existing = {c.name for c in self._client.get_collections().collections}
        if self._collection not in existing:
            self._client.create_collection(
                collection_name=self._collection,
                vectors_config=qdrant_models.VectorParams(
                    size=self.VECTOR_SIZE,
                    distance=qdrant_models.Distance.COSINE,
                ),
            )
            logger.info("Created Qdrant collection: %s", self._collection)

    def _embed(self, text: str) -> list[float]:
        """Generate embedding for text."""
        embeddings = list(self._embedder.embed([text]))
        return embeddings[0].tolist()

    def _doc_id(self, source: str, text: str) -> str:
        """Generate deterministic ID from source + content hash."""
        content_hash = hashlib.sha256(f"{source}:{text}".encode()).hexdigest()[:16]
        return content_hash

    def index_text(
        self,
        source: str,
        text: str,
        *,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> bool:
        """Index a text chunk into the Qdrant collection.

        Args:
            source: Source identifier (file path, URL, etc.)
            text: Text content to embed and store.
            tags: Optional tags for filtering.
            metadata: Additional metadata to store with the vector.

        Returns:
            True if indexed successfully, False if Qdrant unavailable.
        """
        if not self.available:
            return False
        try:
            vector = self._embed(text)
            doc_id = self._doc_id(source, text)
            # Use hash-based int ID (Qdrant requires int or UUID)
            point_id = int(doc_id[:8], 16)
            self._client.upsert(
                collection_name=self._collection,
                points=[
                    qdrant_models.PointStruct(
                        id=point_id,
                        vector=vector,
                        payload={
                            "source": source,
                            "text": text[:2000],  # truncate for storage
                            "tags": tags or [],
                            **(metadata or {}),
                        },
                    )
                ],
            )
            return True
        except Exception as exc:
            logger.warning("Failed to index %r in Qdrant: %s", source, exc)
            return False

    def search(
        self,
        query: str,
        *,
        top_k: int = 5,
        tags_filter: list[str] | None = None,
        score_threshold: float = 0.3,
    ) -> list[VectorSearchResult]:
        """Semantic search over indexed documents.

        Args:
            query: Natural language search query.
            top_k: Maximum number of results.
            tags_filter: If set, only return results with these tags.
            score_threshold: Minimum similarity score (0-1).

        Returns:
            List of VectorSearchResult sorted by score descending.
            Empty list when Qdrant is unavailable (use hybrid_query or
            build_hybrid_memory_context for automatic TF-IDF fallback).
        """
        if not self.available:
            return []
        try:
            query_vector = self._embed(query)

            search_filter = None
            if tags_filter:
                search_filter = qdrant_models.Filter(
                    must=[
                        qdrant_models.FieldCondition(
                            key="tags",
                            match=qdrant_models.MatchAny(any=tags_filter),
                        )
                    ]
                )

            hits = self._client.search(
                collection_name=self._collection,
                query_vector=query_vector,
                limit=top_k,
                query_filter=search_filter,
                score_threshold=score_threshold,
            )

            return [
                VectorSearchResult(
                    source=hit.payload.get("source", ""),
                    snippet=hit.payload.get("text", ""),
                    score=round(hit.score, 4),
                    tags=hit.payload.get("tags", []),
                    metadata={
                        k: v for k, v in hit.payload.items() if k not in ("source", "text", "tags")
                    },
                )
                for hit in hits
            ]
        except Exception as exc:
            logger.warning("Qdrant unavailable, falling back to TF-IDF: %s", exc)
            # Mark as unavailable so subsequent calls skip Qdrant immediately
            self._available = False
            return []

    def count(self) -> int:
        """Return number of indexed vectors."""
        if not self.available:
            return 0
        try:
            info = self._client.get_collection(self._collection)
            return info.vectors_count or 0
        except Exception:
            return 0


# ---------------------------------------------------------------------------
# Hybrid search (TF-IDF + Qdrant)
# ---------------------------------------------------------------------------


def hybrid_query(
    tfidf_results: list[Any],
    qdrant_results: list[VectorSearchResult],
    *,
    top_k: int = 5,
    qdrant_weight: float = 0.6,
    tfidf_weight: float = 0.4,
) -> list[Any]:
    """Merge TF-IDF and Qdrant results with weighted scoring.

    Args:
        tfidf_results: Results from owlmind.memory.retrieval.query() (have .score, .source, .snippet).
        qdrant_results: Results from QdrantMemoryStore.search().
        top_k: Max results to return.
        qdrant_weight: Weight for Qdrant (semantic) scores.
        tfidf_weight: Weight for TF-IDF (keyword) scores.

    Returns:
        Merged list of result objects sorted by combined score.
    """

    # Normalize scores to [0, 1]
    def _normalize(results: list[Any]) -> dict[str, tuple[Any, float]]:
        if not results:
            return {}
        scores = [r.score for r in results]
        max_s = max(scores) if scores else 1.0
        min_s = min(scores) if scores else 0.0
        rng = max_s - min_s or 1.0
        return {r.source: (r, (r.score - min_s) / rng) for r in results}

    tfidf_map = _normalize(tfidf_results)
    qdrant_map: dict[str, tuple[Any, float]] = {r.source: (r, r.score) for r in qdrant_results}

    # Collect all unique sources
    all_sources = set(tfidf_map) | set(qdrant_map)

    scored: list[tuple[float, Any]] = []
    for source in all_sources:
        combined = 0.0
        result_obj = None

        if source in tfidf_map:
            result_obj, norm_score = tfidf_map[source]
            combined += tfidf_weight * norm_score

        if source in qdrant_map:
            q_obj, q_score = qdrant_map[source]
            combined += qdrant_weight * q_score
            if result_obj is None:
                result_obj = q_obj

        if result_obj is not None:
            scored.append((combined, result_obj))

    scored.sort(key=lambda x: x[0], reverse=True)
    return [obj for _, obj in scored[:top_k]]


def build_hybrid_memory_context(
    store: Any,
    query: str,
    *,
    top_k: int = 5,
    qdrant_store: QdrantMemoryStore | None = None,
) -> str:
    """Build memory context using hybrid TF-IDF + Qdrant search.

    Drop-in replacement for owlmind.memory.retrieval.build_memory_context().

    Args:
        store: MemoryStore instance (TF-IDF backend).
        query: Search query.
        top_k: Number of results.
        qdrant_store: Optional QdrantMemoryStore for hybrid search.

    Returns:
        Formatted context string for injection into LLM prompt.
    """
    # TF-IDF results
    try:
        from owlmind.memory.retrieval import query as tfidf_query

        tfidf_results = tfidf_query(store, query, top_k=top_k)
    except Exception as exc:
        logger.warning("TF-IDF retrieval failed: %s", exc)
        tfidf_results = []

    # Qdrant results — gracefully degrade to TF-IDF only when unavailable
    qdrant_results: list[VectorSearchResult] = []
    if qdrant_store is not None:
        if qdrant_store.available:
            try:
                qdrant_results = qdrant_store.search(query, top_k=top_k)
            except Exception as exc:
                logger.warning("Qdrant unavailable, falling back to TF-IDF: %s", exc)
                qdrant_results = []
        else:
            logger.warning(
                "Qdrant unavailable, falling back to TF-IDF: store reported not available"
            )

    # Merge
    if qdrant_results:
        merged = hybrid_query(tfidf_results, qdrant_results, top_k=top_k)
    else:
        merged = tfidf_results[:top_k]

    if not merged:
        return ""

    lines = [f"## Relevant project memory ({len(merged)} snippets)\n"]
    for r in merged:
        source = getattr(r, "source", "unknown")
        snippet = getattr(r, "snippet", "")
        score = getattr(r, "score", 0.0)
        lines.append(f"### {source} (score={score:.3f})\n```\n{snippet}\n```\n")

    return "\n".join(lines)
