"""Task queue — JSONL-based append-only task queue with file locking."""

from __future__ import annotations

import fcntl
import json
import threading
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any


class QueueStatus:
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    DONE = "DONE"
    FAILED = "FAILED"


@dataclass
class QueueItem:
    """A single task in the queue."""

    id: str
    goal: str
    workspace: str
    sandbox: bool = False
    priority: int = 0
    created_at: str = ""
    status: str = QueueStatus.PENDING
    run_id: str = ""
    error: str = ""
    session_id: str = ""
    goal_id: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "goal": self.goal,
            "workspace": self.workspace,
            "sandbox": self.sandbox,
            "priority": self.priority,
            "created_at": self.created_at,
            "status": self.status,
            "run_id": self.run_id,
            "error": self.error,
            "session_id": self.session_id,
            "goal_id": self.goal_id,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> QueueItem:
        return cls(
            id=str(data["id"]),
            goal=str(data["goal"]),
            workspace=str(data["workspace"]),
            sandbox=bool(data.get("sandbox", False)),
            priority=int(data.get("priority", 0)),
            created_at=str(data.get("created_at", "")),
            status=str(data.get("status", QueueStatus.PENDING)),
            run_id=str(data.get("run_id", "")),
            error=str(data.get("error", "")),
            session_id=str(data.get("session_id", "")),
            goal_id=str(data.get("goal_id", "")),
        )


@dataclass
class TaskQueue:
    """JSONL-backed task queue with file locking."""

    queue_dir: Path
    _items: list[QueueItem] = field(default_factory=list, init=False, repr=False)

    def __post_init__(self) -> None:
        self.queue_dir = Path(self.queue_dir)
        self.queue_dir.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._load()

    @property
    def queue_path(self) -> Path:
        return self.queue_dir / "queue.jsonl"

    def _load(self) -> None:
        """Load all items from the queue file."""
        self._items = []
        if not self.queue_path.exists():
            return
        for line in self.queue_path.read_text().splitlines():
            line = line.strip()
            if line:
                self._items.append(QueueItem.from_dict(json.loads(line)))

    def _save(self) -> None:
        """Rewrite the entire queue file (under lock)."""
        self.queue_dir.mkdir(parents=True, exist_ok=True)
        lock_path = self.queue_dir / "queue.lock"
        with lock_path.open("w") as lock_fd:
            fcntl.flock(lock_fd, fcntl.LOCK_EX)
            try:
                lines = [json.dumps(item.to_dict(), default=str) for item in self._items]
                self.queue_path.write_text("\n".join(lines) + "\n" if lines else "")
            finally:
                fcntl.flock(lock_fd, fcntl.LOCK_UN)

    def add(
        self,
        goal: str,
        workspace: str,
        *,
        sandbox: bool = False,
        priority: int = 0,
        session_id: str = "",
        goal_id: str = "",
    ) -> QueueItem:
        """Add a new task to the queue."""
        with self._lock:
            self._load()
            item = QueueItem(
                id=f"task-{uuid.uuid4().hex[:8]}",
                goal=goal,
                workspace=workspace,
                sandbox=sandbox,
                priority=priority,
                created_at=datetime.now(tz=UTC).isoformat(),
                status=QueueStatus.PENDING,
                session_id=session_id,
                goal_id=goal_id,
            )
            self._items.append(item)
            self._save()
            return item

    def list_items(self, *, status: str | None = None) -> list[QueueItem]:
        """List queue items, optionally filtered by status."""
        with self._lock:
            self._load()
            if status:
                return [i for i in self._items if i.status == status]
            return list(self._items)

    def next_pending(self) -> QueueItem | None:
        """Return the next PENDING item, or None."""
        with self._lock:
            self._load()
            pending = [i for i in self._items if i.status == QueueStatus.PENDING]
            if not pending:
                return None
            pending.sort(key=lambda i: (-i.priority, i.created_at))
            return pending[0]

    def mark_running(self, item_id: str, run_id: str) -> None:
        """Mark an item as RUNNING with the given run_id."""
        with self._lock:
            self._load()
            for item in self._items:
                if item.id == item_id:
                    item.status = QueueStatus.RUNNING
                    item.run_id = run_id
                    break
            self._save()

    def mark_done(self, item_id: str) -> None:
        """Mark an item as DONE."""
        with self._lock:
            self._load()
            for item in self._items:
                if item.id == item_id:
                    item.status = QueueStatus.DONE
                    break
            self._save()

    def mark_failed(self, item_id: str, error: str = "") -> None:
        """Mark an item as FAILED."""
        with self._lock:
            self._load()
            for item in self._items:
                if item.id == item_id:
                    item.status = QueueStatus.FAILED
                    item.error = error
                    break
            self._save()
