"""QdrantStore — thin wrapper around qdrant-client for CodeRAG vector search.

Optional dependency: install with ``pip install owlmind[qdrant]``
or ``pip install qdrant-client sentence-transformers``.

When ``QDRANT_URL`` (or ``OWLMIND_QDRANT_URL``) env var is set and
qdrant-client is installed, CodeRAG uses this for semantic vector search.
Otherwise CodeRAG falls back to TF-IDF / grep.
"""

from __future__ import annotations

import logging
import os
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Optional imports
# ---------------------------------------------------------------------------

try:
    from qdrant_client import QdrantClient
    from qdrant_client.models import Distance, PointStruct, VectorParams

    _QDRANT_OK = True
except ImportError:
    _QDRANT_OK = False

try:
    from sentence_transformers import SentenceTransformer  # type: ignore[import]

    _ST_OK = True
except ImportError:
    _ST_OK = False

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

COLLECTION = "owlmind_code"
VECTOR_SIZE = 384  # all-MiniLM-L6-v2 output dimension
_MODEL_NAME = "all-MiniLM-L6-v2"

# ---------------------------------------------------------------------------
# QdrantStore
# ---------------------------------------------------------------------------


class QdrantStore:
    """Thin Qdrant wrapper for code-chunk vector storage and search.

    Args:
        url: Qdrant server URL. Reads ``QDRANT_URL`` or ``OWLMIND_QDRANT_URL``
             env vars when not supplied explicitly.

    Raises:
        ImportError: if qdrant-client or sentence-transformers are missing.
    """

    def __init__(self, url: str | None = None) -> None:
        url = url or os.environ.get("QDRANT_URL") or os.environ.get(
            "OWLMIND_QDRANT_URL", ":memory:"
        )
        if not _QDRANT_OK:
            raise ImportError(
                "pip install qdrant-client sentence-transformers"
            )
        self._url = url
        # ":memory:" uses in-process Qdrant (no server needed)
        if url == ":memory:":
            self._client: Any = QdrantClient(":memory:")
        else:
            self._client = QdrantClient(url=url)
        self._model: Any = None  # lazy-loaded SentenceTransformer
        self._ensure_collection()

    # ------------------------------------------------------------------
    # Collection management
    # ------------------------------------------------------------------

    def _ensure_collection(self) -> None:
        """Create the Qdrant collection if it does not already exist."""
        existing = {c.name for c in self._client.get_collections().collections}
        if COLLECTION not in existing:
            self._client.create_collection(
                collection_name=COLLECTION,
                vectors_config=VectorParams(
                    size=VECTOR_SIZE,
                    distance=Distance.COSINE,
                ),
            )
            logger.info("Created Qdrant collection %r", COLLECTION)

    # ------------------------------------------------------------------
    # Embedding
    # ------------------------------------------------------------------

    def _get_model(self) -> Any:
        """Lazy-load the sentence-transformers model."""
        if self._model is None:
            if not _ST_OK:
                raise ImportError(
                    "pip install sentence-transformers"
                )
            self._model = SentenceTransformer(_MODEL_NAME)
        return self._model

    def _embed(self, texts: list[str]) -> list[list[float]]:
        """Embed a list of texts and return float vectors."""
        model = self._get_model()
        embeddings = model.encode(texts, show_progress_bar=False)
        return [list(map(float, e)) for e in embeddings]

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def upsert(self, points: list[dict[str, Any]]) -> None:
        """Upsert points into the collection.

        Each *point* dict must contain:
            - ``id`` (int): unique point id
            - ``vector`` (list[float]): embedding vector of length VECTOR_SIZE
            - ``payload`` (dict): arbitrary metadata stored alongside the vector
        """
        structs = [
            PointStruct(
                id=p["id"],
                vector=p["vector"],
                payload=p.get("payload", {}),
            )
            for p in points
        ]
        self._client.upsert(collection_name=COLLECTION, points=structs)

    def search(self, query_vector: list[float], limit: int = 5) -> list[dict[str, Any]]:
        """Search the collection for the nearest neighbours.

        Args:
            query_vector: Float vector of length VECTOR_SIZE.
            limit: Number of results to return.

        Returns:
            List of payload dicts, each augmented with a ``score`` key.
        """
        hits = self._client.search(
            collection_name=COLLECTION,
            query_vector=query_vector,
            limit=limit,
            with_payload=True,
        )
        return [
            {**hit.payload, "score": round(hit.score, 4)}
            for hit in hits
        ]

    def count(self) -> int:
        """Return the number of vectors stored in the collection."""
        info = self._client.get_collection(COLLECTION)
        return int(info.points_count or 0)

    # ------------------------------------------------------------------
    # Convenience: embed-then-search
    # ------------------------------------------------------------------

    def search_text(self, query: str, limit: int = 5) -> list[dict[str, Any]]:
        """Embed *query* then search. Convenience wrapper."""
        vector = self._embed([query])[0]
        return self.search(vector, limit=limit)
