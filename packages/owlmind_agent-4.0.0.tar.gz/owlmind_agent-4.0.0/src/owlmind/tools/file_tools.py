"""File operation tools — safe read/write/edit/list within a workspace root."""

from __future__ import annotations

import difflib
from dataclasses import dataclass
from pathlib import Path


class WorkspaceError(Exception):
    """Raised when a path escapes the workspace root."""


@dataclass
class FileResult:
    """Result of a file operation."""

    path: str
    success: bool
    content: str = ""
    error: str = ""
    lines: int = 0
    bytes_written: int = 0
    diff: str = ""


class FileTools:
    """Safe file operations confined to a workspace directory.

    All paths are resolved relative to *workspace_root* and validated to
    prevent directory traversal.  Any path that would escape the root raises
    :class:`WorkspaceError`.
    """

    def __init__(self, workspace_root: str | Path = ".") -> None:
        self._root = Path(workspace_root).resolve()

    # ------------------------------------------------------------------
    # Path helpers
    # ------------------------------------------------------------------

    def _resolve(self, path: str | Path) -> Path:
        """Resolve *path* relative to workspace root; raise if it escapes."""
        resolved = (self._root / path).resolve()
        try:
            resolved.relative_to(self._root)
        except ValueError:
            msg = f"Path {path!r} escapes workspace root {self._root}"
            raise WorkspaceError(msg) from None
        return resolved

    def _rel(self, abs_path: Path) -> str:
        """Return path relative to workspace root as string."""
        try:
            return str(abs_path.relative_to(self._root))
        except ValueError:
            return str(abs_path)

    # ------------------------------------------------------------------
    # Read
    # ------------------------------------------------------------------

    def read(
        self,
        path: str,
        encoding: str = "utf-8",
        max_bytes: int = 1_000_000,
    ) -> FileResult:
        """Read a file and return its content."""
        try:
            resolved = self._resolve(path)
            if not resolved.exists():
                return FileResult(path=path, success=False, error=f"File not found: {path}")
            if not resolved.is_file():
                return FileResult(path=path, success=False, error=f"Not a file: {path}")
            size = resolved.stat().st_size
            if size > max_bytes:
                return FileResult(
                    path=path,
                    success=False,
                    error=f"File too large: {size} bytes (limit {max_bytes})",
                )
            content = resolved.read_text(encoding=encoding, errors="replace")
            return FileResult(
                path=path,
                success=True,
                content=content,
                lines=content.count("\n") + 1,
            )
        except WorkspaceError as e:
            return FileResult(path=path, success=False, error=str(e))
        except Exception as e:
            return FileResult(path=path, success=False, error=str(e))

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------

    def write(
        self,
        path: str,
        content: str,
        encoding: str = "utf-8",
        create_parents: bool = True,
    ) -> FileResult:
        """Write (overwrite) a file with *content*. Creates parent dirs if needed."""
        try:
            resolved = self._resolve(path)
            if create_parents:
                resolved.parent.mkdir(parents=True, exist_ok=True)
            data = content.encode(encoding)
            resolved.write_bytes(data)
            lines = content.count("\n") + 1
            return FileResult(
                path=path,
                success=True,
                content=content,
                lines=lines,
                bytes_written=len(data),
            )
        except WorkspaceError as e:
            return FileResult(path=path, success=False, error=str(e))
        except Exception as e:
            return FileResult(path=path, success=False, error=str(e))

    # ------------------------------------------------------------------
    # Edit (patch / replace lines)
    # ------------------------------------------------------------------

    def edit(
        self,
        path: str,
        old_content: str,
        new_content: str,
        encoding: str = "utf-8",
    ) -> FileResult:
        """Replace *old_content* with *new_content* inside an existing file.

        Raises an error if *old_content* is not found or is ambiguous.
        """
        read_result = self.read(path, encoding=encoding)
        if not read_result.success:
            return read_result

        original = read_result.content
        count = original.count(old_content)
        if count == 0:
            return FileResult(
                path=path,
                success=False,
                error="old_content not found in file",
            )
        if count > 1:
            return FileResult(
                path=path,
                success=False,
                error=f"old_content found {count} times — must be unique",
            )

        updated = original.replace(old_content, new_content, 1)

        # Compute unified diff for logging
        diff = "".join(
            difflib.unified_diff(
                original.splitlines(keepends=True),
                updated.splitlines(keepends=True),
                fromfile=f"a/{path}",
                tofile=f"b/{path}",
                n=3,
            )
        )

        write_result = self.write(path, updated, encoding=encoding)
        write_result.diff = diff
        return write_result

    def append(self, path: str, content: str, encoding: str = "utf-8") -> FileResult:
        """Append *content* to the end of a file (creates it if absent)."""
        try:
            resolved = self._resolve(path)
            resolved.parent.mkdir(parents=True, exist_ok=True)
            with resolved.open("a", encoding=encoding) as fh:
                fh.write(content)
            _ = resolved.stat().st_size
            return FileResult(
                path=path,
                success=True,
                bytes_written=len(content.encode(encoding)),
                lines=content.count("\n"),
            )
        except WorkspaceError as e:
            return FileResult(path=path, success=False, error=str(e))
        except Exception as e:
            return FileResult(path=path, success=False, error=str(e))

    # ------------------------------------------------------------------
    # Delete
    # ------------------------------------------------------------------

    def delete(self, path: str) -> FileResult:
        """Delete a file from the workspace."""
        try:
            resolved = self._resolve(path)
            if not resolved.exists():
                return FileResult(path=path, success=False, error=f"File not found: {path}")
            if not resolved.is_file():
                return FileResult(path=path, success=False, error=f"Not a file: {path}")
            resolved.unlink()
            return FileResult(path=path, success=True)
        except WorkspaceError as e:
            return FileResult(path=path, success=False, error=str(e))
        except Exception as e:
            return FileResult(path=path, success=False, error=str(e))

    # ------------------------------------------------------------------
    # Directory listing
    # ------------------------------------------------------------------

    def list_dir(
        self,
        path: str = ".",
        recursive: bool = False,
        include_hidden: bool = False,
        max_files: int = 500,
    ) -> list[dict[str, str]]:
        """List files and directories inside *path*.

        Returns a list of dicts with keys: path, type, size.
        """
        try:
            resolved = self._resolve(path)
            if not resolved.exists():
                return []
            if not resolved.is_dir():
                return []

            entries: list[dict[str, str]] = []
            iterator = resolved.rglob("*") if recursive else resolved.iterdir()

            for item in iterator:
                if not include_hidden and any(p.startswith(".") for p in item.parts):
                    continue
                if len(entries) >= max_files:
                    break
                rel = self._rel(item)
                try:
                    size = str(item.stat().st_size) if item.is_file() else ""
                    entries.append({
                        "path": rel,
                        "type": "file" if item.is_file() else "dir",
                        "size": size,
                    })
                except OSError:
                    continue

            return sorted(entries, key=lambda e: (e["type"] == "file", e["path"]))
        except WorkspaceError:
            return []

    def make_dir(self, path: str) -> FileResult:
        """Create a directory (and parents) in the workspace."""
        try:
            resolved = self._resolve(path)
            resolved.mkdir(parents=True, exist_ok=True)
            return FileResult(path=path, success=True)
        except WorkspaceError as e:
            return FileResult(path=path, success=False, error=str(e))
        except Exception as e:
            return FileResult(path=path, success=False, error=str(e))

    # ------------------------------------------------------------------
    # Batch write (from parsed code blocks)
    # ------------------------------------------------------------------

    def write_many(self, files: dict[str, str]) -> list[FileResult]:
        """Write multiple files at once. Keys are paths, values are content."""
        results = []
        for path, content in files.items():
            results.append(self.write(path, content))
        return results

    # ------------------------------------------------------------------
    # Convenience: check existence
    # ------------------------------------------------------------------

    def exists(self, path: str) -> bool:
        try:
            return self._resolve(path).exists()
        except WorkspaceError:
            return False

    def is_file(self, path: str) -> bool:
        try:
            return self._resolve(path).is_file()
        except WorkspaceError:
            return False

    def is_dir(self, path: str) -> bool:
        try:
            return self._resolve(path).is_dir()
        except WorkspaceError:
            return False
