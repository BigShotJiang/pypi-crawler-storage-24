"""Search tools — Grep and Glob within a workspace root."""

from __future__ import annotations

import fnmatch
import re
import subprocess
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class GrepMatch:
    """A single grep match."""

    file: str
    line_num: int
    line: str
    context_before: list[str] = field(default_factory=list)
    context_after: list[str] = field(default_factory=list)


@dataclass
class GrepResult:
    """Result of a grep search."""

    pattern: str
    matches: list[GrepMatch] = field(default_factory=list)
    files_searched: int = 0
    error: str = ""

    @property
    def total_matches(self) -> int:
        return len(self.matches)

    def as_text(self, max_matches: int = 50) -> str:
        """Format matches as human-readable text."""
        if self.error:
            return f"Error: {self.error}"
        if not self.matches:
            return f"No matches for '{self.pattern}'"
        lines = [f"Found {self.total_matches} match(es) for '{self.pattern}':\n"]
        for m in self.matches[:max_matches]:
            lines.append(f"  {m.file}:{m.line_num}: {m.line.rstrip()}")
        if self.total_matches > max_matches:
            lines.append(f"  ... and {self.total_matches - max_matches} more")
        return "\n".join(lines)


@dataclass
class GlobResult:
    """Result of a glob file search."""

    pattern: str
    files: list[str] = field(default_factory=list)
    error: str = ""

    @property
    def count(self) -> int:
        return len(self.files)

    def as_text(self) -> str:
        if self.error:
            return f"Error: {self.error}"
        if not self.files:
            return f"No files matching '{self.pattern}'"
        lines = [f"Found {self.count} file(s) matching '{self.pattern}':"]
        lines.extend(f"  {f}" for f in self.files[:100])
        if self.count > 100:
            lines.append(f"  ... and {self.count - 100} more")
        return "\n".join(lines)


class SearchTools:
    """Grep and Glob search tools confined to a workspace directory."""

    def __init__(self, workspace_root: str | Path = ".") -> None:
        self._root = Path(workspace_root).resolve()

    # ------------------------------------------------------------------
    # Grep
    # ------------------------------------------------------------------

    def grep(
        self,
        pattern: str,
        path: str = ".",
        *,
        case_sensitive: bool = True,
        include: str = "",
        exclude: str = "",
        context_lines: int = 0,
        max_matches: int = 200,
        use_regex: bool = True,
    ) -> GrepResult:
        """Search for *pattern* in files under *path*.

        Tries ``rg`` (ripgrep) first for speed, falls back to pure Python.
        """
        # Try ripgrep first
        rg_result = self._grep_rg(
            pattern, path,
            case_sensitive=case_sensitive,
            include=include,
            context_lines=context_lines,
            max_matches=max_matches,
            use_regex=use_regex,
        )
        if rg_result is not None:
            return rg_result

        # Fallback: pure Python
        return self._grep_python(
            pattern, path,
            case_sensitive=case_sensitive,
            include=include,
            exclude=exclude,
            context_lines=context_lines,
            max_matches=max_matches,
            use_regex=use_regex,
        )

    def _grep_rg(
        self,
        pattern: str,
        path: str,
        *,
        case_sensitive: bool,
        include: str,
        context_lines: int,
        max_matches: int,
        use_regex: bool,
    ) -> GrepResult | None:
        """Try ripgrep; return None if rg not available."""
        try:
            search_path = (self._root / path).resolve()
            args = ["rg", "--line-number", "--no-heading", "--color=never"]
            if not case_sensitive:
                args.append("--ignore-case")
            if not use_regex:
                args.append("--fixed-strings")
            if include:
                args.extend(["--glob", include])
            if context_lines:
                args.extend(["-C", str(context_lines)])
            args.extend(["--max-count", str(max_matches)])
            args.append(pattern)
            args.append(str(search_path))

            result = subprocess.run(
                args, capture_output=True, text=True, timeout=30
            )
            if result.returncode not in (0, 1):  # 1 = no matches
                return None

            matches: list[GrepMatch] = []
            files_seen: set[str] = set()
            for line in result.stdout.splitlines():
                parts = line.split(":", 2)
                if len(parts) >= 3:
                    try:
                        file_abs = parts[0]
                        line_num = int(parts[1])
                        text = parts[2]
                        try:
                            rel = str(Path(file_abs).relative_to(self._root))
                        except ValueError:
                            rel = file_abs
                        files_seen.add(rel)
                        matches.append(GrepMatch(file=rel, line_num=line_num, line=text))
                    except (ValueError, IndexError):
                        continue

            return GrepResult(
                pattern=pattern,
                matches=matches,
                files_searched=len(files_seen),
            )
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return None

    def _grep_python(
        self,
        pattern: str,
        path: str,
        *,
        case_sensitive: bool,
        include: str,
        exclude: str,
        context_lines: int,
        max_matches: int,
        use_regex: bool,
    ) -> GrepResult:
        """Pure-Python grep fallback."""
        search_path = (self._root / path).resolve()
        if not search_path.exists():
            return GrepResult(pattern=pattern, error=f"Path not found: {path}")

        flags = 0 if case_sensitive else re.IGNORECASE
        try:
            regex = re.compile(pattern if use_regex else re.escape(pattern), flags)
        except re.error as e:
            return GrepResult(pattern=pattern, error=f"Invalid regex: {e}")

        matches: list[GrepMatch] = []
        files_searched = 0
        candidates = search_path.rglob("*") if search_path.is_dir() else [search_path]

        for file_path in candidates:
            if not file_path.is_file():
                continue
            if include and not fnmatch.fnmatch(file_path.name, include):
                continue
            if exclude and fnmatch.fnmatch(file_path.name, exclude):
                continue
            # Skip binary-looking files
            try:
                content = file_path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue

            files_searched += 1
            file_lines = content.splitlines()

            for i, line in enumerate(file_lines):
                if regex.search(line):
                    rel = str(file_path.relative_to(self._root))
                    before = file_lines[max(0, i - context_lines):i] if context_lines else []
                    after = file_lines[i + 1:i + 1 + context_lines] if context_lines else []
                    matches.append(GrepMatch(
                        file=rel,
                        line_num=i + 1,
                        line=line,
                        context_before=before,
                        context_after=after,
                    ))
                    if len(matches) >= max_matches:
                        break
            if len(matches) >= max_matches:
                break

        return GrepResult(pattern=pattern, matches=matches, files_searched=files_searched)

    # ------------------------------------------------------------------
    # Glob
    # ------------------------------------------------------------------

    def glob(
        self,
        pattern: str,
        path: str = ".",
        *,
        include_dirs: bool = False,
        max_results: int = 500,
    ) -> GlobResult:
        """Find files matching glob *pattern* under *path*.

        Uses Python's pathlib.Path.rglob / glob.
        """
        try:
            base = (self._root / path).resolve()
            if not base.exists():
                return GlobResult(pattern=pattern, error=f"Path not found: {path}")

            results: list[str] = []
            # Support both relative patterns like "*.py" and "**/*.py"
            for match in sorted(base.glob(pattern)):
                if not include_dirs and match.is_dir():
                    continue
                try:
                    rel = str(match.relative_to(self._root))
                except ValueError:
                    rel = str(match)
                results.append(rel)
                if len(results) >= max_results:
                    break

            return GlobResult(pattern=pattern, files=results)
        except Exception as e:
            return GlobResult(pattern=pattern, error=str(e))

    def find_files(
        self,
        name_pattern: str,
        path: str = ".",
        max_results: int = 200,
    ) -> GlobResult:
        """Find files by name pattern (e.g. '*.py', 'test_*.py') anywhere under path."""
        return self.glob(f"**/{name_pattern}", path=path, max_results=max_results)

    def find_by_content(self, text: str, file_pattern: str = "*.py") -> GrepResult:
        """Convenience: search for literal text in files matching file_pattern."""
        return self.grep(
            text,
            include=file_pattern,
            use_regex=False,
        )
