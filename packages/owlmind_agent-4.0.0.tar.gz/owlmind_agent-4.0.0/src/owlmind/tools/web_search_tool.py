"""WebSearchTool — search the web via DuckDuckGo HTML (no API key needed).

Uses httpx for a direct HTTP fetch (no headless browser required).
Falls back to the owlmind BrowserDriver when httpx is unavailable.
"""

from __future__ import annotations

import logging
import re
import urllib.parse
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class WebResult:
    """A single web search result."""

    title: str
    url: str
    snippet: str = ""


@dataclass
class WebSearchResult:
    """Result of a web search query."""

    query: str
    results: list[WebResult] = field(default_factory=list)
    source: str = "duckduckgo"
    error: str = ""

    @property
    def count(self) -> int:
        return len(self.results)

    def as_text(self, max_results: int = 5) -> str:
        """Return search results as plain text for LLM context."""
        if self.error:
            return f"Search error: {self.error}"
        if not self.results:
            return f"No results found for: {self.query}"
        lines = [f"Web search results for '{self.query}':\n"]
        for i, r in enumerate(self.results[:max_results], 1):
            lines.append(f"{i}. {r.title}")
            lines.append(f"   {r.url}")
            if r.snippet:
                lines.append(f"   {r.snippet[:200]}")
            lines.append("")
        return "\n".join(lines)


class WebSearchTool:
    """Search the web and return structured results.

    Requires ``httpx`` (already in owlmind[api] extras).
    Falls back to :class:`~owlmind.browser.driver.BrowserDriver` if needed.
    """

    _DDG_URL = "https://html.duckduckgo.com/html/?q={query}"
    _HEADERS = {
        "User-Agent": (
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/120.0.0.0 Safari/537.36"
        ),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
    }

    def search(self, query: str, num_results: int = 5) -> WebSearchResult:
        """Search for *query* and return up to *num_results* results."""
        # Try httpx first (fast, no browser needed)
        results = self._search_httpx(query, num_results)
        if results is not None:
            return WebSearchResult(query=query, results=results)

        # Fallback: try BrowserDriver
        try:
            from owlmind.browser.driver import BrowserDriver, is_browser_available

            if is_browser_available():
                with BrowserDriver() as browser:
                    sr = browser.search_web(query, num_results=num_results)
                    web_results = [
                        WebResult(
                            title=r.get("title", ""),
                            url=r.get("url", ""),
                            snippet=r.get("snippet", ""),
                        )
                        for r in sr.results
                    ]
                    return WebSearchResult(
                        query=query, results=web_results, source="duckduckgo-browser"
                    )
        except Exception as e:
            logger.debug("Browser fallback failed: %s", e)

        return WebSearchResult(
            query=query,
            results=[],
            error="httpx and playwright not available",
        )

    def _search_httpx(self, query: str, num_results: int) -> list[WebResult] | None:
        """Fetch DDG HTML results via httpx. Returns None if httpx unavailable."""
        try:
            import httpx
        except ImportError:
            return None

        url = self._DDG_URL.format(query=urllib.parse.quote_plus(query))
        try:
            resp = httpx.get(
                url,
                headers=self._HEADERS,
                follow_redirects=True,
                timeout=5,
            )
            if resp.status_code == 202:
                logger.debug("DDG returned HTTP 202 (no results available) for query: %r", query)
                return []
            if resp.status_code != 200:
                logger.warning("DDG HTTP %d for query: %r", resp.status_code, query)
                return None
            return self._parse_ddg_html(resp.text, num_results)
        except Exception as e:
            logger.warning("DDG httpx fetch failed: %s", e)
            return None

    def _parse_ddg_html(self, html: str, num_results: int) -> list[WebResult]:
        """Extract results from DuckDuckGo HTML page."""
        results: list[WebResult] = []

        # Split by result container
        blocks = re.split(r'class="result results_links[^"]*"', html)

        link_re = re.compile(
            r'class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>',
            re.DOTALL,
        )
        snippet_re = re.compile(
            r'class="result__snippet"[^>]*>(.*?)</(?:a|span|div)>',
            re.DOTALL,
        )

        for block in blocks[1 : num_results * 3 + 1]:
            title_m = link_re.search(block)
            if not title_m:
                continue

            raw_href = title_m.group(1)
            # DDG redirect URL: extract uddg= param
            uddg_m = re.search(r"uddg=([^&]+)", raw_href)
            url = (
                urllib.parse.unquote(uddg_m.group(1))
                if uddg_m
                else urllib.parse.unquote(raw_href)
            )

            title = re.sub(r"<[^>]+>", "", title_m.group(2)).strip()
            snippet_m = snippet_re.search(block)
            snippet = (
                re.sub(r"<[^>]+>", "", snippet_m.group(1)).strip()
                if snippet_m
                else ""
            )

            if url.startswith("http") and title:
                results.append(WebResult(title=title, url=url, snippet=snippet))
                if len(results) >= num_results:
                    break

        return results

    def is_available(self) -> bool:
        """Return True if at least one search backend is available."""
        try:
            import httpx  # noqa: F401
            return True
        except ImportError:
            pass
        try:
            from owlmind.browser.driver import is_browser_available
            return is_browser_available()
        except Exception:
            return False


# ---------------------------------------------------------------------------
# Page fetcher (fetch text content of a URL for further research)
# ---------------------------------------------------------------------------


def fetch_page_text(url: str, max_chars: int = 4000) -> str:
    """Fetch the visible text content of a URL.

    Uses httpx for speed; falls back to BrowserDriver.
    """
    try:
        import httpx

        from owlmind.browser.driver import BrowserDriver

        # Try lightweight httpx GET + strip HTML
        headers = {
            "User-Agent": WebSearchTool._HEADERS["User-Agent"],
            "Accept": "text/html",
        }
        resp = httpx.get(url, headers=headers, follow_redirects=True, timeout=5)
        if resp.status_code == 200:
            text = re.sub(r"<[^>]+>", " ", resp.text)
            text = re.sub(r"\s+", " ", text).strip()
            return text[:max_chars]
    except Exception:
        pass

    try:
        from owlmind.browser.driver import BrowserDriver, is_browser_available
        if is_browser_available():
            with BrowserDriver() as b:
                return b.get_page_summary(url)
    except Exception:
        pass

    return f"Could not fetch: {url}"
