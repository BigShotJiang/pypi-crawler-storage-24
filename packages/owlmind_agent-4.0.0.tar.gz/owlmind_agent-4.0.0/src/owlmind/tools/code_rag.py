"""CodeRAG — semantic and lexical codebase search for agent context.

Connects:
  - owlmind.ast_parser.analyzer.CodeAnalyzer  (AST-based code chunking)
  - owlmind.memory.qdrant_store.QdrantCodeStore (vector search, optional)
  - owlmind.memory.retrieval.MemoryStore        (TF-IDF fallback, always available)

Usage::

    rag = CodeRAG(workspace="/path/to/repo")
    rag.index()                          # build index (fast, incremental)
    hits = rag.search("auth middleware") # returns list[CodeHit]
    context = rag.context_for(hits)      # format as LLM context string
"""

from __future__ import annotations

import logging
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------


@dataclass
class CodeHit:
    """A single relevant code chunk found by search."""

    file: str
    line_start: int
    line_end: int
    content: str
    score: float = 0.0
    language: str = ""
    symbol: str = ""          # function/class name if known


@dataclass
class IndexStats:
    """Statistics from a CodeRAG.index() run."""

    files_indexed: int = 0
    chunks_indexed: int = 0
    backend: str = "none"
    duration_ms: int = 0
    error: str = ""


# ---------------------------------------------------------------------------
# Main class
# ---------------------------------------------------------------------------


class CodeRAG:
    """Hybrid code search: vector (Qdrant) + TF-IDF (always available).

    Automatically detects which backends are available and uses the best one.
    """

    def __init__(
        self,
        workspace: str | Path = ".",
        qdrant_url: str = "",
    ) -> None:
        self._workspace = Path(workspace).resolve()
        self._qdrant_url = qdrant_url or os.environ.get(
            "OWLMIND_QDRANT_URL", ":memory:"
        )
        # Lazy-init backends
        self._qdrant: Any = None
        self._store: Any = None
        self._analyzer: Any = None
        self._indexed = False

    # ------------------------------------------------------------------
    # Index
    # ------------------------------------------------------------------

    def index(self, *, force: bool = False) -> IndexStats:
        """Build or refresh the code index for the workspace.

        Tries Qdrant first; falls back to in-memory TF-IDF store.
        """
        t0 = time.monotonic()

        # Try Qdrant + fastembed
        qdrant = self._get_qdrant()
        if qdrant is not None:
            try:
                result = qdrant.index_workspace(force_reindex=force)
                self._indexed = True
                return IndexStats(
                    files_indexed=result.get("files", 0),
                    chunks_indexed=result.get("chunks", 0),
                    backend="qdrant",
                    duration_ms=int((time.monotonic() - t0) * 1000),
                )
            except Exception as e:
                logger.warning("Qdrant indexing failed, falling back to TF-IDF: %s", e)

        # Fallback: in-memory TF-IDF via MemoryStore
        try:
            chunks = self._build_chunks()
            store = self._get_store()
            if store is not None:
                for chunk in chunks:
                    store.add(chunk["text"], metadata=chunk)
                self._indexed = True
                return IndexStats(
                    files_indexed=len({c["file"] for c in chunks}),
                    chunks_indexed=len(chunks),
                    backend="tfidf",
                    duration_ms=int((time.monotonic() - t0) * 1000),
                )
        except Exception as e:
            logger.warning("TF-IDF indexing failed: %s", e)
            return IndexStats(
                error=str(e),
                duration_ms=int((time.monotonic() - t0) * 1000),
            )

        return IndexStats(
            error="No indexing backend available",
            duration_ms=int((time.monotonic() - t0) * 1000),
        )

    # ------------------------------------------------------------------
    # Search
    # ------------------------------------------------------------------

    def search(self, query: str, top_k: int = 5) -> list[CodeHit]:
        """Search the code index for *query* and return top *top_k* hits.

        Automatically indexes on first call if not already done.
        """
        if not self._indexed:
            self.index()

        # Try Qdrant vector search
        qdrant = self._get_qdrant()
        if qdrant is not None:
            try:
                results = qdrant.search(query, top_k=top_k)
                return [
                    CodeHit(
                        file=r.get("file_path", r.get("file", "")),
                        line_start=r.get("start_line", 0),
                        line_end=r.get("end_line", 0),
                        content=r.get("content", r.get("text", "")),
                        score=r.get("score", 0.0),
                        language=r.get("language", ""),
                        symbol=r.get("symbol", ""),
                    )
                    for r in results
                ]
            except Exception as e:
                logger.debug("Qdrant search failed, falling back: %s", e)

        # Fallback: TF-IDF retrieval
        try:
            store = self._get_store()
            if store is not None:
                docs = store.retrieve(query, top_k=top_k)
                return [
                    CodeHit(
                        file=d.metadata.get("file", ""),
                        line_start=d.metadata.get("start_line", 0),
                        line_end=d.metadata.get("end_line", 0),
                        content=d.text,
                        score=d.score,
                        language=d.metadata.get("language", ""),
                    )
                    for d in docs
                ]
        except Exception as e:
            logger.debug("TF-IDF search failed: %s", e)

        # Last resort: grep-style search
        return self._grep_search(query, top_k)

    # ------------------------------------------------------------------
    # Formatting
    # ------------------------------------------------------------------

    def context_for(self, hits: list[CodeHit], max_chars: int = 3000) -> str:
        """Format *hits* as a code context string for LLM prompts."""
        if not hits:
            return ""
        lines = ["Relevant code from the repository:\n"]
        total = 0
        for hit in hits:
            header = f"# {hit.file}:{hit.line_start}-{hit.line_end}"
            if hit.symbol:
                header += f" ({hit.symbol})"
            block = f"{header}\n```{hit.language}\n{hit.content.strip()}\n```\n"
            if total + len(block) > max_chars:
                break
            lines.append(block)
            total += len(block)
        return "\n".join(lines)

    def search_and_format(self, query: str, top_k: int = 5, max_chars: int = 3000) -> str:
        """Search + format in one call — convenience for ArchitectNode."""
        hits = self.search(query, top_k=top_k)
        return self.context_for(hits, max_chars=max_chars)

    def is_available(self) -> bool:
        """Return True if any search backend is available."""
        return True  # grep fallback is always available

    def backend(self) -> str:
        """Return name of the active backend."""
        if self._get_qdrant() is not None:
            return "qdrant"
        if self._get_store() is not None:
            return "tfidf"
        return "grep"

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _get_qdrant(self) -> Any:
        if self._qdrant is not None:
            return self._qdrant
        try:
            from owlmind.memory.qdrant_store import QdrantCodeStore
            qs = QdrantCodeStore(url=self._qdrant_url, workspace=self._workspace)
            if qs.is_available():
                self._qdrant = qs
                return qs
        except Exception:
            pass
        return None

    def _get_store(self) -> Any:
        if self._store is not None:
            return self._store
        try:
            from owlmind.memory.store import MemoryStore
            self._store = MemoryStore()
            return self._store
        except Exception:
            return None

    def _get_analyzer(self) -> Any:
        if self._analyzer is not None:
            return self._analyzer
        try:
            from owlmind.ast_parser.analyzer import CodeAnalyzer
            self._analyzer = CodeAnalyzer()
        except Exception:
            self._analyzer = None
        return self._analyzer

    def _build_chunks(self) -> list[dict[str, Any]]:
        """Build code chunks from the workspace for TF-IDF indexing."""
        analyzer = self._get_analyzer()
        chunks: list[dict[str, Any]] = []

        extensions = {".py", ".ts", ".tsx", ".js", ".jsx", ".go", ".rs", ".java", ".md"}
        skip_dirs = {"__pycache__", ".git", "node_modules", ".venv", "venv", "dist", "build"}

        for file_path in self._workspace.rglob("*"):
            if not file_path.is_file():
                continue
            if any(part in skip_dirs for part in file_path.parts):
                continue
            if file_path.suffix not in extensions:
                continue

            rel = str(file_path.relative_to(self._workspace))
            try:
                if analyzer is not None:
                    analysis = analyzer.analyze_file(str(file_path))
                    for chunk in analysis.chunks:
                        chunks.append({
                            "text": chunk.content,
                            "file": rel,
                            "start_line": chunk.start_line,
                            "end_line": chunk.end_line,
                            "language": analysis.language or "",
                            "symbol": getattr(chunk, "symbol_name", ""),
                        })
                else:
                    # Simple line-based chunking
                    content = file_path.read_text(encoding="utf-8", errors="replace")
                    lines = content.splitlines()
                    chunk_size = 40
                    for i in range(0, len(lines), chunk_size):
                        chunk_content = "\n".join(lines[i : i + chunk_size])
                        chunks.append({
                            "text": chunk_content,
                            "file": rel,
                            "start_line": i + 1,
                            "end_line": min(i + chunk_size, len(lines)),
                            "language": file_path.suffix.lstrip("."),
                            "symbol": "",
                        })
            except Exception as e:
                logger.debug("Could not chunk %s: %s", rel, e)

        return chunks

    # ------------------------------------------------------------------
    # index_workspace — Qdrant-backed semantic indexing
    # ------------------------------------------------------------------

    def index_workspace(self, workspace: Path | None = None) -> IndexStats:
        """Walk *workspace*, chunk files, embed with all-MiniLM-L6-v2, upsert to Qdrant.

        Uses :class:`owlmind.tools.qdrant_store.QdrantStore` for vector storage
        and ``sentence-transformers`` for embeddings.  Falls back to the
        standard :meth:`index` if either dependency is missing or Qdrant is
        unreachable.

        Args:
            workspace: Directory to index. Defaults to ``self._workspace``.

        Returns:
            :class:`IndexStats` describing the outcome.
        """
        import time

        t0 = time.monotonic()
        root = Path(workspace).resolve() if workspace is not None else self._workspace

        # Prefer QdrantCodeStore (shares same instance as search via _get_qdrant)
        qdrant = self._get_qdrant()
        if qdrant is not None and hasattr(qdrant, "index_workspace"):
            try:
                result = qdrant.index_workspace()
                # QdrantCodeStore returns dict; IndexStats dataclass has different attr names
                if isinstance(result, dict):
                    files_indexed = result.get("files", result.get("files_indexed", 0))
                    chunks_indexed = result.get("chunks", result.get("chunks_indexed", 0))
                else:
                    files_indexed = getattr(result, "files_indexed", 0)
                    chunks_indexed = getattr(result, "chunks_indexed", 0)
                duration = int((time.monotonic() - t0) * 1000)
                return IndexStats(
                    files_indexed=files_indexed,
                    chunks_indexed=chunks_indexed,
                    backend="qdrant",
                    duration_ms=duration,
                )
            except Exception as exc:
                logger.warning("QdrantCodeStore.index_workspace failed: %s; trying fallback", exc)

        # Attempt Qdrant + sentence-transformers path (separate QdrantStore)
        try:
            from owlmind.tools.qdrant_store import VECTOR_SIZE, QdrantStore  # noqa: F401

            try:
                from sentence_transformers import SentenceTransformer  # type: ignore[import]
                _st_available = True
            except ImportError:
                _st_available = False

            if not _st_available:
                logger.warning(
                    "sentence-transformers not installed; falling back to standard index()"
                )
                return self.index()

            store = QdrantStore(url=self._qdrant_url or None)
            model = SentenceTransformer("all-MiniLM-L6-v2")

            extensions = {".py", ".ts", ".tsx", ".js", ".jsx", ".go", ".rs"}
            skip_dirs = {"__pycache__", ".git", "node_modules", ".venv", "venv", "dist", "build"}
            chunk_size = 50

            files: list[Path] = []
            for fp in root.rglob("*"):
                if not fp.is_file():
                    continue
                if any(part in skip_dirs for part in fp.parts):
                    continue
                if fp.suffix not in extensions:
                    continue
                files.append(fp)

            logger.info("Indexing %d files into Qdrant…", len(files))

            all_chunks: list[dict] = []
            for fp in files:
                rel = str(fp.relative_to(root))
                try:
                    lines = fp.read_text(encoding="utf-8", errors="replace").splitlines()
                except Exception as exc:
                    logger.debug("Cannot read %s: %s", rel, exc)
                    continue
                for i in range(0, len(lines), chunk_size):
                    chunk_text = "\n".join(lines[i : i + chunk_size]).strip()
                    if not chunk_text:
                        continue
                    all_chunks.append(
                        {
                            "file": rel,
                            "start_line": i + 1,
                            "end_line": min(i + chunk_size, len(lines)),
                            "text": chunk_text,
                        }
                    )

            # Embed in batches of 32 and upsert
            batch_size = 32
            for batch_start in range(0, len(all_chunks), batch_size):
                batch = all_chunks[batch_start : batch_start + batch_size]
                texts = [c["text"] for c in batch]
                vectors = model.encode(texts, show_progress_bar=False)
                points = [
                    {
                        "id": batch_start + j,
                        "vector": list(map(float, vectors[j])),
                        "payload": {
                            "file": batch[j]["file"],
                            "start_line": batch[j]["start_line"],
                            "end_line": batch[j]["end_line"],
                            "text": batch[j]["text"][:2000],
                        },
                    }
                    for j in range(len(batch))
                ]
                store.upsert(points)

            files_count = len({c["file"] for c in all_chunks})
            self._indexed = True
            return IndexStats(
                files_indexed=files_count,
                chunks_indexed=len(all_chunks),
                backend="qdrant",
                duration_ms=int((time.monotonic() - t0) * 1000),
            )

        except ImportError as exc:
            logger.warning("QdrantStore/sentence-transformers unavailable: %s; falling back", exc)
            return self.index()
        except Exception as exc:
            logger.warning("index_workspace failed: %s; falling back", exc)
            return self.index()

    def _grep_search(self, query: str, top_k: int) -> list[CodeHit]:
        """Last-resort grep-based search across the workspace."""
        import re
        hits: list[CodeHit] = []
        pattern = re.compile(re.escape(query), re.IGNORECASE)
        extensions = {".py", ".ts", ".js", ".go", ".rs", ".java", ".md"}
        skip_dirs = {"__pycache__", ".git", "node_modules", ".venv"}

        for file_path in self._workspace.rglob("*"):
            if not file_path.is_file():
                continue
            if any(part in skip_dirs for part in file_path.parts):
                continue
            if file_path.suffix not in extensions:
                continue
            try:
                content = file_path.read_text(encoding="utf-8", errors="replace")
                rel = str(file_path.relative_to(self._workspace))
                lines = content.splitlines()
                for i, line in enumerate(lines):
                    if pattern.search(line):
                        start = max(0, i - 3)
                        end = min(len(lines), i + 4)
                        hits.append(CodeHit(
                            file=rel,
                            line_start=start + 1,
                            line_end=end,
                            content="\n".join(lines[start:end]),
                            score=1.0,
                            language=file_path.suffix.lstrip("."),
                        ))
                        if len(hits) >= top_k:
                            return hits
            except Exception:
                continue

        return hits
