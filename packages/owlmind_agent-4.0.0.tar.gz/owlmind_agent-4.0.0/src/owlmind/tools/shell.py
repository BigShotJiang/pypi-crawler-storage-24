"""ShellTool — sandbox command execution with policy checks."""

from __future__ import annotations

import logging
import shlex
import subprocess
import time
from dataclasses import dataclass, field

from owlmind.policy import PolicyDecision, PolicyEngine, PolicyResult
from owlmind.utils import ToolLimits, env_fingerprint, redact_secrets, sha256, truncate

logger = logging.getLogger(__name__)


@dataclass
class ShellResult:
    """Structured result of a shell command execution."""

    command: str
    exit_code: int
    stdout: str
    stderr: str
    stdout_hash: str
    stderr_hash: str
    duration_ms: int
    env_fingerprint: str
    truncated: bool = False
    policy_result: PolicyResult | None = None


@dataclass
class ShellTool:
    """Execute shell commands with policy enforcement and sandboxing.

    Commands are split with :func:`shlex.split` and executed with ``shell=False``
    to prevent shell injection.

    When *sandbox=True* and :class:`~owlmind.tools.sandbox.E2BSandbox` is
    available (``e2b-code-interpreter`` installed + ``E2B_API_KEY`` set) the
    command is executed inside an E2B cloud sandbox instead of a local
    subprocess.  If E2B is requested but unavailable, a warning is logged and
    execution falls back to the local subprocess path.
    """

    policy: PolicyEngine
    limits: ToolLimits = field(default_factory=ToolLimits)
    cwd: str | None = None
    sandbox: bool = False

    def run(self, command: str) -> ShellResult:
        """Run *command* after policy check.

        Returns a :class:`ShellResult` with captured output, hashes, and timing.
        """
        # 1. Policy check
        policy_result = self.policy.evaluate(command)
        if policy_result.decision in (PolicyDecision.DENY, PolicyDecision.BLOCK):
            return ShellResult(
                command=command,
                exit_code=-1,
                stdout="",
                stderr=f"POLICY DENIED: {policy_result.reason}",
                stdout_hash=sha256(""),
                stderr_hash=sha256(f"POLICY DENIED: {policy_result.reason}"),
                duration_ms=0,
                env_fingerprint=env_fingerprint(),
                policy_result=policy_result,
            )

        # 2. Parse command safely (no shell=True)
        try:
            args = shlex.split(command)
        except ValueError as exc:
            err_msg = f"Invalid command syntax: {exc}"
            return ShellResult(
                command=command,
                exit_code=-3,
                stdout="",
                stderr=err_msg,
                stdout_hash=sha256(""),
                stderr_hash=sha256(err_msg),
                duration_ms=0,
                env_fingerprint=env_fingerprint(),
                policy_result=policy_result,
            )

        # 3. Execute — either in E2B cloud sandbox or local subprocess
        import os

        start = time.monotonic()
        stdout_raw: str = ""
        stderr_raw: str = ""
        exit_code: int = 0

        # Decide whether to use E2B
        use_e2b = False
        if self.sandbox:
            from owlmind.tools.sandbox import E2BSandbox

            if E2BSandbox.is_available():
                use_e2b = True
            else:
                logger.warning(
                    "ShellTool: sandbox=True but E2B not available "
                    "(install e2b-code-interpreter and set E2B_API_KEY). "
                    "Falling back to local execution."
                )

        if use_e2b:
            # --- E2B sandbox path ---
            from owlmind.tools.sandbox import E2BSandbox

            try:
                sbx = E2BSandbox()
                exit_code, stdout_raw, stderr_raw = sbx.run(
                    command, timeout=self.limits.timeout_seconds
                )
            except Exception as exc:
                elapsed = int((time.monotonic() - start) * 1000)
                err_msg = f"E2B sandbox error: {exc}"
                return ShellResult(
                    command=command,
                    exit_code=-5,
                    stdout="",
                    stderr=err_msg,
                    stdout_hash=sha256(""),
                    stderr_hash=sha256(err_msg),
                    duration_ms=elapsed,
                    env_fingerprint=env_fingerprint(),
                    policy_result=policy_result,
                )
        else:
            # --- Local subprocess path (shell=False) ---
            # Clean env to allow nested Claude CLI invocations
            clean_env = {k: v for k, v in os.environ.items() if not k.startswith("CLAUDECODE")}
            # Ensure Homebrew bin is in PATH (needed for claude, node, etc.)
            homebrew_bin = "/opt/homebrew/bin"
            path = clean_env.get("PATH", "")
            if homebrew_bin not in path:
                clean_env["PATH"] = homebrew_bin + ":" + path
            # Parse leading KEY=VALUE pairs from args into env vars.
            # e.g. ["PYTHONPATH=/foo", "pytest", "."] → env["PYTHONPATH"]="/foo", args=["pytest", "."]
            import re as _re
            _kv_re = _re.compile(r"^([A-Za-z_][A-Za-z0-9_]*)=(.*)$")
            while args and _kv_re.match(args[0]):
                m = _kv_re.match(args.pop(0))
                clean_env[m.group(1)] = m.group(2)
            if not args:
                return ShellResult(
                    command=command,
                    exit_code=-3,
                    stdout="",
                    stderr="Empty command after stripping env vars",
                    stdout_hash=sha256(""),
                    stderr_hash=sha256("Empty command after stripping env vars"),
                    duration_ms=0,
                    env_fingerprint=env_fingerprint(),
                    policy_result=policy_result,
                )
            try:
                proc = subprocess.run(
                    args,
                    capture_output=True,
                    text=True,
                    timeout=self.limits.timeout_seconds,
                    cwd=self.cwd,
                    env=clean_env,
                )
                stdout_raw = proc.stdout
                stderr_raw = proc.stderr
                exit_code = proc.returncode
            except subprocess.TimeoutExpired:
                elapsed = int((time.monotonic() - start) * 1000)
                return ShellResult(
                    command=command,
                    exit_code=-2,
                    stdout="",
                    stderr=f"TIMEOUT after {self.limits.timeout_seconds}s",
                    stdout_hash=sha256(""),
                    stderr_hash=sha256(f"TIMEOUT after {self.limits.timeout_seconds}s"),
                    duration_ms=elapsed,
                    env_fingerprint=env_fingerprint(),
                    policy_result=policy_result,
                )
            except FileNotFoundError:
                elapsed = int((time.monotonic() - start) * 1000)
                err_msg = f"Command not found: {args[0]}"
                return ShellResult(
                    command=command,
                    exit_code=-4,
                    stdout="",
                    stderr=err_msg,
                    stdout_hash=sha256(""),
                    stderr_hash=sha256(err_msg),
                    duration_ms=elapsed,
                    env_fingerprint=env_fingerprint(),
                    policy_result=policy_result,
                )

        elapsed = int((time.monotonic() - start) * 1000)

        # 4. Redact secrets
        stdout_clean = redact_secrets(stdout_raw)
        stderr_clean = redact_secrets(stderr_raw)

        # 5. Truncate
        stdout_final, stdout_truncated = truncate(stdout_clean, self.limits.max_output_bytes)
        stderr_final, stderr_truncated = truncate(stderr_clean, self.limits.max_output_bytes)

        return ShellResult(
            command=command,
            exit_code=exit_code,
            stdout=stdout_final,
            stderr=stderr_final,
            stdout_hash=sha256(stdout_final),
            stderr_hash=sha256(stderr_final),
            duration_ms=elapsed,
            env_fingerprint=env_fingerprint(),
            truncated=stdout_truncated or stderr_truncated,
            policy_result=policy_result,
        )
