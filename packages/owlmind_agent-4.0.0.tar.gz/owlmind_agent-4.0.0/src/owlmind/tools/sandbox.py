"""E2B Sandbox — safe code execution in isolated Firecracker containers.

Requires: pip install e2b-code-interpreter
API key: E2B_API_KEY env var

Falls back to local ShellTool if E2B not available or not configured.
"""
from __future__ import annotations

import contextlib
import logging
import os

logger = logging.getLogger(__name__)

try:
    from e2b_code_interpreter import Sandbox as _E2BSandboxCls
    _E2B_OK = True
except ImportError:
    _E2BSandboxCls = None  # type: ignore[assignment,misc]
    _E2B_OK = False


class E2BSandbox:
    """Isolated shell command execution via E2B cloud sandbox."""

    def __init__(self, api_key: str | None = None) -> None:
        self.api_key = api_key or os.environ.get("E2B_API_KEY", "")
        if not _E2B_OK:
            raise ImportError("pip install e2b-code-interpreter")
        if not self.api_key:
            raise ValueError("E2B_API_KEY not set")

    def run(self, command: str, timeout: int = 30) -> tuple[int, str, str]:
        """Run *command* in an E2B sandbox. Returns (exit_code, stdout, stderr)."""
        os.environ.setdefault("E2B_API_KEY", self.api_key)
        sb = _E2BSandboxCls.create(timeout=timeout)  # type: ignore[misc]
        try:
            result = sb.commands.run(command, timeout=timeout)
            return result.exit_code, result.stdout or "", result.stderr or ""
        finally:
            sb.kill()

    @staticmethod
    def is_available() -> bool:
        """Return True if e2b-code-interpreter is installed and E2B_API_KEY is set."""
        return _E2B_OK and bool(os.environ.get("E2B_API_KEY"))


def is_available() -> bool:
    """Return True if E2B is installed and API key is set."""
    if not os.environ.get("E2B_API_KEY", ""):
        return False
    try:
        import e2b_code_interpreter  # noqa: F401

        return True
    except ImportError:
        return False


class SandboxResult:
    """Result of a sandbox execution."""

    def __init__(
        self,
        stdout: str = "",
        stderr: str = "",
        exit_code: int = 0,
        error: str = "",
    ) -> None:
        self.stdout = stdout
        self.stderr = stderr
        self.exit_code = exit_code
        self.error = error

    @property
    def success(self) -> bool:
        return self.exit_code == 0 and not self.error

    def __str__(self) -> str:
        parts = []
        if self.stdout:
            parts.append(self.stdout)
        if self.stderr:
            parts.append(f"[stderr] {self.stderr}")
        if self.error:
            parts.append(f"[error] {self.error}")
        return "\n".join(parts)


def run_in_sandbox(
    code: str,
    *,
    language: str = "python",
    timeout: int = 30,
    api_key: str = "",
) -> SandboxResult:
    """Run code in E2B sandbox. Falls back to local exec if E2B unavailable."""
    key = api_key or os.environ.get("E2B_API_KEY", "")

    if not key:
        logger.debug("E2B_API_KEY not set — falling back to local execution")
        return _run_local(code, language=language, timeout=timeout)

    try:
        return _run_e2b(code, language=language, timeout=timeout, api_key=key)
    except Exception as e:
        logger.warning("E2B execution failed, falling back to local: %s", e)
        return _run_local(code, language=language, timeout=timeout)


def _run_e2b(code: str, *, language: str, timeout: int, api_key: str) -> SandboxResult:
    """Execute code via E2B cloud sandbox."""
    try:
        import e2b_code_interpreter
    except ImportError as err:
        raise RuntimeError("e2b-code-interpreter not installed") from err

    os.environ.setdefault("E2B_API_KEY", api_key)
    sbx = e2b_code_interpreter.Sandbox.create(timeout=timeout)
    try:
        execution = sbx.run_code(code)
    finally:
        sbx.kill()
    stdout = "".join(str(o) for o in (execution.logs.stdout or []))
    stderr = "".join(str(e) for e in (execution.logs.stderr or []))
    error = str(execution.error) if execution.error else ""
    exit_code = 1 if execution.error else 0
    return SandboxResult(stdout=stdout, stderr=stderr, exit_code=exit_code, error=error)


def _run_local(code: str, *, language: str, timeout: int) -> SandboxResult:
    """Fallback: run code locally via subprocess."""
    import subprocess
    import sys
    import tempfile

    ext = {"python": ".py", "bash": ".sh", "javascript": ".js"}.get(language, ".py")
    interpreter = {"python": sys.executable, "bash": "/bin/bash", "javascript": "node"}.get(
        language, sys.executable
    )

    fname: str | None = None
    try:
        with tempfile.NamedTemporaryFile(suffix=ext, mode="w", delete=False) as f:
            f.write(code)
            fname = f.name

        result = subprocess.run(
            [interpreter, fname],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return SandboxResult(
            stdout=result.stdout,
            stderr=result.stderr,
            exit_code=result.returncode,
        )
    except subprocess.TimeoutExpired:
        return SandboxResult(error=f"Timeout after {timeout}s", exit_code=1)
    except Exception as e:
        return SandboxResult(error=str(e), exit_code=1)
    finally:
        if fname is not None:
            with contextlib.suppress(Exception):
                os.unlink(fname)
