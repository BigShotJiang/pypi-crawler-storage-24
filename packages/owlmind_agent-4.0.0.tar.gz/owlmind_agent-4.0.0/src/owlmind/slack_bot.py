"""Slack Operator Bot — control owlmind from Slack.

Commands (slash commands or @mention):
  /cw_help          — Show commands
  /cw_graph <goal>  — Run graph pipeline
  /cw_status        — Show run status
  /cw_watch_start   — Start autonomous scheduler
  /cw_watch_stop    — Stop scheduler
  /cw_watch_status  — Scheduler status
  /cw_model         — Switch LLM profile
  /cw_queue         — Task queue

Requires: pip install 'owlmind[slack]'
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)

_BOLT_AVAILABLE = False
try:
    from slack_bolt.adapter.socket_mode.async_handler import (  # noqa: F401
        AsyncSocketModeHandler as SocketModeHandler,
    )
    from slack_bolt.async_app import AsyncApp as App

    _BOLT_AVAILABLE = True
except ImportError:
    pass


def is_slack_available() -> bool:
    """Check if slack-bolt is installed."""
    return _BOLT_AVAILABLE


def create_slack_bot(
    *,
    bot_token: str,
    app_token: str,
    allowed_user_ids: list[str] | None = None,
    operator: Any = None,
) -> Any:
    """Create the owlmind Slack bot application.

    Returns an AsyncApp instance or None if slack-bolt is not installed.
    """
    if not _BOLT_AVAILABLE or not bot_token:
        return None

    app: Any = App(token=bot_token)

    # ── BotContext ────────────────────────────────────────────────────────────
    from owlmind.slack.context import make_slack_context

    ctx = make_slack_context(
        app=app,
        operator=operator,
        allowed_user_ids=allowed_user_ids,
    )

    # ── Handlers ──────────────────────────────────────────────────────────────
    from owlmind.slack.handlers import (
        cmd_cw_graph,
        cmd_cw_help,
        cmd_cw_model,
        cmd_cw_queue,
        cmd_cw_status,
        cmd_cw_watch_start,
        cmd_cw_watch_status,
        cmd_cw_watch_stop,
    )

    def _bind(handler: Any) -> Any:
        """Bind ctx as a keyword argument, keeping ack/say/command positional."""
        from functools import wraps

        @wraps(handler)
        async def _wrapped(ack: Any, say: Any, command: Any) -> None:
            await handler(ack=ack, say=say, command=command, ctx=ctx)

        return _wrapped

    # Register slash commands
    app.command("/cw_help")(_bind(cmd_cw_help))
    app.command("/cw_graph")(_bind(cmd_cw_graph))
    app.command("/cw_status")(_bind(cmd_cw_status))
    app.command("/cw_watch_start")(_bind(cmd_cw_watch_start))
    app.command("/cw_watch_stop")(_bind(cmd_cw_watch_stop))
    app.command("/cw_watch_status")(_bind(cmd_cw_watch_status))
    app.command("/cw_model")(_bind(cmd_cw_model))
    app.command("/cw_queue")(_bind(cmd_cw_queue))

    return app
