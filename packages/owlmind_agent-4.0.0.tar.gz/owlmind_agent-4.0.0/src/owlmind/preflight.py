"""Preflight checks — validate environment before running LLM/worker pipelines.

Checks env vars, optional deps, binaries, workspace, and budget readiness
without making any network calls.
"""

from __future__ import annotations

import importlib
import json
import os
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class PreflightConfig:
    """What to check."""

    use_llm: str = "none"  # none | planner | judge | both
    use_worker: str = "none"  # none | claude_cli
    providers: list[str] | None = None  # explicit list, or None = router defaults
    workspace: str = "."
    sandbox: bool = False
    require_network: bool = False  # True for e2e preflight


@dataclass
class PreflightCheck:
    """Single check result."""

    name: str
    ok: bool
    details: str


@dataclass
class PreflightReport:
    """Full preflight report."""

    ok: bool = True
    checks: list[PreflightCheck] = field(default_factory=list)
    missing_env: list[str] = field(default_factory=list)
    missing_deps: list[str] = field(default_factory=list)
    missing_binaries: list[str] = field(default_factory=list)
    recommended_installs: list[str] = field(default_factory=list)
    provider_status: dict[str, str] = field(default_factory=dict)
    redactions_applied: bool = True
    budget_summary: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dict (for JSON output)."""
        return {
            "ok": self.ok,
            "checks": [{"name": c.name, "ok": c.ok, "details": c.details} for c in self.checks],
            "missing_env": self.missing_env,
            "missing_deps": self.missing_deps,
            "missing_binaries": self.missing_binaries,
            "recommended_installs": self.recommended_installs,
            "provider_status": self.provider_status,
            "redactions_applied": self.redactions_applied,
            "budget_summary": self.budget_summary,
        }

    def to_json(self) -> str:
        """Serialize to JSON string."""
        return json.dumps(self.to_dict(), indent=2)


def _redact_key(value: str) -> str:
    """Show only first 4 and last 4 chars of a key."""
    if len(value) <= 12:
        return "***"
    return f"{value[:4]}...{value[-4:]}"


def _needed_providers(config: PreflightConfig) -> list[str]:
    """Determine which providers to check."""
    if config.use_llm == "none":
        return []

    if config.providers:
        return list(config.providers)

    # Default: check from env
    from owlmind.config import OwlMindConfig

    cfg = OwlMindConfig.from_env()
    providers = list(cfg.router.planner_providers)
    for p in cfg.router.judge_providers:
        if p not in providers:
            providers.append(p)
    return providers


def run_preflight(config: PreflightConfig) -> PreflightReport:
    """Run all preflight checks. No network calls."""
    report = PreflightReport()

    # 1) Package structure
    _check_package(report)

    # 2) Env vars for needed providers
    providers = _needed_providers(config)
    _check_env_vars(report, providers)

    # 3) Optional deps
    _check_deps(report, providers)

    # 4) Binaries
    _check_binaries(report, config)

    # 5) Workspace / sandbox
    _check_workspace(report, config)

    # 6) Budget readiness
    _check_budget(report)

    # 7) Provider status summary
    _check_provider_status(report, providers)

    # Final ok = all checks passed
    report.ok = (
        all(c.ok for c in report.checks) and not report.missing_env and not report.missing_deps
    )
    if config.use_worker == "claude_cli" and report.missing_binaries:
        report.ok = False

    return report


def _check_package(report: PreflightReport) -> None:
    """Check that owlmind package is properly structured."""
    init_path = Path(__file__).parent / "__init__.py"
    if init_path.exists():
        content = init_path.read_text()
        if "__version__" in content:
            from owlmind import __version__

            report.checks.append(
                PreflightCheck(
                    name="package_structure",
                    ok=True,
                    details=f"owlmind v{__version__} (__init__.py present)",
                )
            )
            return

    report.checks.append(
        PreflightCheck(
            name="package_structure",
            ok=False,
            details="src/owlmind/__init__.py missing or lacks __version__",
        )
    )


_ENV_MAP: dict[str, list[str]] = {
    "openai": ["OPENAI_API_KEY"],
    "anthropic": ["ANTHROPIC_API_KEY"],
    "gemini": ["GEMINI_API_KEY", "GOOGLE_API_KEY"],
}


def _check_env_vars(report: PreflightReport, providers: list[str]) -> None:
    """Check that required env vars are present (values are redacted)."""
    for provider in providers:
        env_names = _ENV_MAP.get(provider, [])
        if not env_names:
            continue

        found = False
        for env_name in env_names:
            val = os.environ.get(env_name, "")
            if val:
                report.checks.append(
                    PreflightCheck(
                        name=f"env_{provider}",
                        ok=True,
                        details=f"{env_name} set ({_redact_key(val)})",
                    )
                )
                found = True
                break

        if not found:
            display_vars = " or ".join(env_names)
            report.checks.append(
                PreflightCheck(
                    name=f"env_{provider}",
                    ok=False,
                    details=f"{display_vars} not set",
                )
            )
            report.missing_env.append(display_vars)


_DEP_MAP: dict[str, tuple[str, str]] = {
    "openai": ("openai", "owlmind[openai]"),
    "anthropic": ("anthropic", "owlmind[anthropic]"),
    "gemini": ("google.genai", "owlmind[gemini]"),
}


def _check_deps(report: PreflightReport, providers: list[str]) -> None:
    """Check that optional SDK dependencies are importable."""
    for provider in providers:
        dep_info = _DEP_MAP.get(provider)
        if not dep_info:
            continue

        module_name, install_name = dep_info
        try:
            importlib.import_module(module_name)
            report.checks.append(
                PreflightCheck(
                    name=f"dep_{provider}",
                    ok=True,
                    details=f"{module_name} importable",
                )
            )
        except ImportError:
            report.checks.append(
                PreflightCheck(
                    name=f"dep_{provider}",
                    ok=False,
                    details=f"{module_name} not installed",
                )
            )
            report.missing_deps.append(module_name)
            report.recommended_installs.append(f"pip install '{install_name}'")


def _check_binaries(report: PreflightReport, config: PreflightConfig) -> None:
    """Check that required binaries are in PATH."""
    if config.use_worker == "claude_cli":
        claude_path = shutil.which("claude")
        if claude_path:
            report.checks.append(
                PreflightCheck(
                    name="binary_claude",
                    ok=True,
                    details=f"claude found at {claude_path}",
                )
            )
        else:
            report.checks.append(
                PreflightCheck(
                    name="binary_claude",
                    ok=False,
                    details="claude not found in PATH (needed for --use-worker claude_cli)",
                )
            )
            report.missing_binaries.append("claude")

    if config.sandbox:
        git_path = shutil.which("git")
        if git_path:
            report.checks.append(
                PreflightCheck(
                    name="binary_git",
                    ok=True,
                    details=f"git found at {git_path}",
                )
            )
        else:
            report.checks.append(
                PreflightCheck(
                    name="binary_git",
                    ok=False,
                    details="git not found in PATH (needed for --sandbox)",
                )
            )
            report.missing_binaries.append("git")


def _check_workspace(report: PreflightReport, config: PreflightConfig) -> None:
    """Check workspace conditions."""
    ws = Path(config.workspace)
    if not ws.exists():
        report.checks.append(
            PreflightCheck(
                name="workspace",
                ok=False,
                details=f"Workspace not found: {ws}",
            )
        )
        return

    report.checks.append(
        PreflightCheck(
            name="workspace_exists",
            ok=True,
            details=f"Workspace: {ws.resolve()}",
        )
    )

    if config.sandbox:
        git_dir = ws / ".git"
        is_git = git_dir.exists()
        if is_git:
            # Check if dirty
            try:
                result = subprocess.run(
                    ["git", "status", "--porcelain"],
                    capture_output=True,
                    text=True,
                    cwd=str(ws),
                    timeout=10,
                )
                dirty = bool(result.stdout.strip())
                if dirty:
                    report.checks.append(
                        PreflightCheck(
                            name="workspace_git",
                            ok=True,
                            details="Git repo (dirty — sandbox worktree will isolate)",
                        )
                    )
                else:
                    report.checks.append(
                        PreflightCheck(
                            name="workspace_git",
                            ok=True,
                            details="Git repo (clean)",
                        )
                    )
            except (subprocess.TimeoutExpired, FileNotFoundError):
                report.checks.append(
                    PreflightCheck(
                        name="workspace_git",
                        ok=True,
                        details="Git repo (status check failed, proceeding)",
                    )
                )
        else:
            report.checks.append(
                PreflightCheck(
                    name="workspace_git",
                    ok=True,
                    details="Not a git repo — sandbox will use plain copy",
                )
            )


def _check_budget(report: PreflightReport) -> None:
    """Show current budget caps and today's usage."""
    try:
        from owlmind.config import OwlMindConfig
        from owlmind.ledger import UsageLedger

        cfg = OwlMindConfig.from_env()
        ledger = UsageLedger(Path("ledger"))
        today = ledger.totals_for_day()

        report.budget_summary = {
            "max_tokens_per_run": cfg.budget.max_tokens_per_run,
            "max_tokens_per_day": cfg.budget.max_tokens_per_day,
            "max_usd_per_day": cfg.budget.max_usd_per_day,
            "max_llm_calls_per_hour": cfg.budget.max_llm_calls_per_hour,
            "today_tokens": today.total_tokens,
            "today_usd": round(today.estimated_usd, 4),
            "today_calls": today.llm_calls,
        }
        report.checks.append(
            PreflightCheck(
                name="budget",
                ok=True,
                details=(
                    f"Today: {today.total_tokens:,} tokens, "
                    f"${today.estimated_usd:.4f} "
                    f"(limit: {cfg.budget.max_tokens_per_day:,} tokens, "
                    f"${cfg.budget.max_usd_per_day:.2f})"
                ),
            )
        )
    except Exception:
        report.checks.append(
            PreflightCheck(
                name="budget",
                ok=True,
                details="Ledger not initialized (first run)",
            )
        )


def _check_provider_status(report: PreflightReport, providers: list[str]) -> None:
    """Build provider status summary."""
    for provider in providers:
        env_ok = not any(c.name == f"env_{provider}" and not c.ok for c in report.checks)
        dep_ok = not any(c.name == f"dep_{provider}" and not c.ok for c in report.checks)
        if env_ok and dep_ok:
            report.provider_status[provider] = "enabled"
        elif not dep_ok:
            report.provider_status[provider] = "disabled: SDK not installed"
        else:
            report.provider_status[provider] = "disabled: API key not set"
