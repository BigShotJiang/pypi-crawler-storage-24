"""OWLMIND REST API — FastAPI-based HTTP interface (optional dependency)."""

from __future__ import annotations

try:
    from owlmind.api.app import create_app

    __all__ = ["create_app"]
except ImportError:  # pragma: no cover
    __all__: list[str] = []  # type: ignore[no-redef]
