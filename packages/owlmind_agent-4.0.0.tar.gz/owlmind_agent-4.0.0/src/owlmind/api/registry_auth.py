"""Registry-specific authentication and RBAC.

Provides FastAPI dependencies for authenticating registry users by API key
(SHA256 hash lookup) and enforcing role-based access control.

This module is intentionally separate from ``owlmind.api.auth`` which handles
the global API key. The registry has its own user table with per-user keys.

Usage::

    from owlmind.api.registry_auth import make_registry_auth, hash_api_key

    get_current_user, require_admin = make_registry_auth(registry)
"""

from __future__ import annotations

import hashlib
from collections.abc import Callable, Coroutine
from typing import Any

from fastapi import Depends, HTTPException, Security, status
from fastapi.security import APIKeyHeader

from owlmind.registry.public import SQLitePublicPackRegistry

_HEADER = APIKeyHeader(name="X-Registry-Token", auto_error=False)

# Type alias for auth dependency functions
AuthDep = Callable[..., Coroutine[Any, Any, dict[str, Any]]]


def hash_api_key(key: str) -> str:
    """Hash an API key with SHA256. Safe for high-entropy tokens."""
    return hashlib.sha256(key.encode()).hexdigest()


def make_registry_auth(
    registry: SQLitePublicPackRegistry,
) -> tuple[AuthDep, AuthDep]:
    """Create registry auth dependencies bound to a specific registry instance.

    Returns:
        Tuple of ``(get_current_user, require_admin)`` dependency functions.
    """

    async def get_current_user(
        token: str | None = Security(_HEADER),
    ) -> dict[str, Any]:
        """Look up user by API key hash. Raises 401/403 on failure."""
        if not token:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Missing X-Registry-Token header",
            )
        key_hash = hash_api_key(token)
        user = await registry.get_user_by_key_hash(key_hash)
        if not user:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid registry token",
            )
        if not user["is_active"]:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="User account is deactivated",
            )
        return user

    async def require_admin(
        user: dict[str, Any] = Depends(get_current_user),
    ) -> dict[str, Any]:
        """Require the current user to have admin role."""
        if user["role"] != "admin":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Admin role required",
            )
        return user

    return get_current_user, require_admin
