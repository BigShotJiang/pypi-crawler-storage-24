"""OWLMIND FastAPI app factory."""

from __future__ import annotations

import os
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from owlmind import __version__
from owlmind.api.routes.analytics import make_analytics_router
from owlmind.api.routes.dashboard import make_dashboard_router
from owlmind.api.routes.github_webhook import make_github_webhook_router
from owlmind.api.routes.health import make_health_router
from owlmind.api.routes.memory import make_memory_router
from owlmind.api.routes.push import make_push_router
from owlmind.api.routes.queue import make_queue_router
from owlmind.api.routes.registry import make_registry_router
from owlmind.api.routes.runs import make_runs_router
from owlmind.api.routes.self_improve import make_self_improve_router
from owlmind.api.routes.sessions import make_sessions_router
from owlmind.api.routes.skills import make_skills_router
from owlmind.api.routes.slack import make_slack_router
from owlmind.api.routes.sofiya import make_sofiya_router
from owlmind.api.routes.streaming import make_streaming_router
from owlmind.api.routes.webhooks import make_webhooks_router
from owlmind.monitoring.middleware import add_metrics_middleware


def create_app(
    runs_dir: str | Path = "runs",
    ledger_dir: str | Path = "ledger",
    queue_path: str | Path = "queue",
    policies_dir: str | Path = "policies",
    packs_dir: str | Path | None = None,
    memory_db: str | Path | None = None,
    registry_db: str | Path | None = None,
    archive_dir: str | Path | None = None,
    storage: object | None = None,
    frontend_dir: str | Path | None = None,
    push_db: str | Path | None = None,
    webhook_secret: str = "",
    slack_signing_secret: str = "",
) -> FastAPI:
    """Create and configure the OWLMIND FastAPI application.

    Args:
        runs_dir: Directory containing run artifacts (cycle_meta.json, etc.).
        ledger_dir: Directory containing the usage ledger (usage.jsonl).
        queue_path: Directory containing the task queue.
        policies_dir: Directory containing policy YAML files.
        packs_dir: Directory containing skill packs (optional).
        memory_db: Path to the memory SQLite database (optional).
        registry_db: Path to the public registry SQLite database (optional).
        archive_dir: Directory for pack ZIP archives (optional).
        storage: Optional ``StorageBackend`` instance. If provided, stored on
            ``app.state.storage`` for future route migration.
        frontend_dir: Directory containing the built React frontend (optional).
            When provided, serves static assets and SPA fallback at ``/``.
        push_db: Path to SQLite database for push notification tokens (optional).
        webhook_secret: Shared secret for webhook signature verification (optional).
        slack_signing_secret: Slack app signing secret for slash command verification.

    Returns:
        Configured FastAPI instance.
    """
    from owlmind.security import check_master_password

    check_master_password()

    runs = Path(runs_dir)
    ledger = Path(ledger_dir)
    policies = Path(policies_dir)
    _packs_dir = Path(packs_dir) if packs_dir else None
    _memory_db = Path(memory_db) if memory_db else ledger.parent / "memory" / "memory.db"

    app = FastAPI(
        title="OWLMIND API",
        description="REST API for the OWLMIND autonomous multi-agent code orchestrator",
        version=__version__,
    )

    # Store queue path on app state for future use
    app.state.queue_path = Path(queue_path)

    # Store StorageBackend for future route migration (Этап 2+)
    app.state.storage = storage

    # CORS — permissive for dev; tighten via env vars in production
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Mount route groups
    app.include_router(make_dashboard_router(runs, ledger))
    app.include_router(make_health_router(runs, ledger, policies))
    app.include_router(make_runs_router(runs, policies))
    app.include_router(make_sessions_router(runs))
    app.include_router(make_streaming_router(runs))
    app.include_router(make_analytics_router(ledger))
    app.include_router(make_queue_router(runs))
    app.include_router(make_skills_router(_packs_dir))
    app.include_router(make_memory_router(_memory_db))
    app.include_router(make_self_improve_router(runs, _memory_db))
    app.include_router(make_registry_router(registry_db, archive_dir))
    app.include_router(make_push_router(push_db))
    app.include_router(make_webhooks_router(webhook_secret=webhook_secret))
    app.include_router(
        make_slack_router(
            queue_dir=Path(queue_path),
            signing_secret=slack_signing_secret,
        )
    )
    app.include_router(
        make_github_webhook_router(
            queue_dir=Path(queue_path),
            webhook_secret=os.environ.get("OWLMIND_GITHUB_WEBHOOK_SECRET", ""),
        )
    )
    app.include_router(make_sofiya_router(_memory_db))

    # Prometheus metrics middleware + /metrics endpoint
    add_metrics_middleware(app)

    # Serve React frontend if built directory exists.
    # Prefer an explicit frontend_dir argument; fall back to the bundled
    # static/ directory sitting next to this file (Vite outDir default).
    _fe = Path(frontend_dir) if frontend_dir else Path(__file__).parent / "static"
    if _fe.is_dir() and (_fe / "index.html").exists():
        # Serve static assets (JS, CSS, images) under /assets
        assets_dir = _fe / "assets"
        if assets_dir.is_dir():
            app.mount("/assets", StaticFiles(directory=str(assets_dir)), name="frontend-assets")

        @app.get("/{full_path:path}", include_in_schema=False)
        async def _spa_fallback(request: Request, full_path: str) -> FileResponse:
            """SPA fallback: serve index.html for non-API routes."""
            # Don't intercept API, docs, or metrics paths
            if full_path.startswith(
                ("api/", "docs", "redoc", "openapi", "health", "doctor", "metrics")
            ):
                from fastapi.responses import JSONResponse

                return JSONResponse({"detail": "Not Found"}, status_code=404)  # type: ignore[return-value]
            # Serve actual static file if it exists
            static_file = _fe / full_path  # type: ignore[operator]
            if full_path and static_file.is_file():
                return FileResponse(str(static_file))
            # SPA fallback
            return FileResponse(str(_fe / "index.html"))  # type: ignore[operator]

    return app
