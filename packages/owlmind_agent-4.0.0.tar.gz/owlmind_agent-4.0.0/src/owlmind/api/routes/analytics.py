"""Cost and usage analytics endpoints."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, status

from owlmind.api.auth import verify_api_key

logger = logging.getLogger(__name__)


def make_analytics_router(ledger_dir: Path) -> APIRouter:
    """Create analytics router with injected ledger directory."""
    router = APIRouter(
        prefix="/api/v1/analytics",
        tags=["analytics"],
        dependencies=[Depends(verify_api_key)],
    )

    @router.get("/cost/daily")
    async def cost_daily(
        date: str | None = Query(None, description="Date in YYYY-MM-DD format (default: today)"),
    ) -> dict[str, Any]:
        """Daily cost/usage report."""
        try:
            from owlmind.reports import daily_report

            return daily_report(ledger_dir, date=date)
        except Exception as exc:
            logger.exception("Failed to generate daily report")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Report generation failed: {exc}",
            ) from exc

    @router.get("/cost/weekly")
    async def cost_weekly() -> dict[str, Any]:
        """Weekly cost/usage report (last 7 days)."""
        try:
            from owlmind.reports import weekly_report

            return weekly_report(ledger_dir)
        except Exception as exc:
            logger.exception("Failed to generate weekly report")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Report generation failed: {exc}",
            ) from exc

    @router.get("/cost/monthly")
    async def cost_monthly() -> dict[str, Any]:
        """Monthly cost/usage report (current calendar month)."""
        try:
            from owlmind.reports import monthly_report

            return monthly_report(ledger_dir)
        except Exception as exc:
            logger.exception("Failed to generate monthly report")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Report generation failed: {exc}",
            ) from exc

    @router.get("/cost/breakdown")
    async def cost_breakdown() -> list[dict[str, Any]]:
        """Provider/model cost breakdown (all time)."""
        try:
            from owlmind.reports import provider_breakdown

            return provider_breakdown(ledger_dir)
        except Exception as exc:
            logger.exception("Failed to generate provider breakdown")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Report generation failed: {exc}",
            ) from exc

    return router
