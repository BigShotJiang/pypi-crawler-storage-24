"""Health and diagnostics endpoints."""

from __future__ import annotations

import platform
import sys
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends

from owlmind import __version__
from owlmind.api.auth import verify_api_key


def make_health_router(
    runs_dir: Path,
    ledger_dir: Path,
    policies_dir: Path,
) -> APIRouter:
    """Create health-check router with injected paths."""
    router = APIRouter(tags=["health"])

    @router.get("/health")
    async def health() -> dict[str, Any]:
        """Basic health check — no auth required."""
        return {
            "status": "ok",
            "version": __version__,
        }

    @router.get("/doctor", dependencies=[Depends(verify_api_key)])
    async def doctor() -> dict[str, Any]:
        """Run basic diagnostics and return structured results."""
        checks: list[dict[str, Any]] = []

        # Python version
        py_ok = sys.version_info >= (3, 11)
        checks.append(
            {
                "name": "Python >= 3.11",
                "ok": py_ok,
                "detail": f"{sys.version_info.major}.{sys.version_info.minor}",
            }
        )

        # Policies directory
        pol_ok = policies_dir.exists()
        checks.append(
            {
                "name": "Policies directory",
                "ok": pol_ok,
                "detail": str(policies_dir),
            }
        )

        # Key policy files
        for fname in ("allowlist.yaml", "policy.yaml", "judge_rules.yaml"):
            fpath = policies_dir / fname
            checks.append(
                {
                    "name": fname,
                    "ok": fpath.exists(),
                    "detail": str(fpath),
                }
            )

        # Runs directory
        runs_ok = runs_dir.exists()
        checks.append(
            {
                "name": "Runs directory",
                "ok": runs_ok,
                "detail": str(runs_dir),
            }
        )

        # Ledger directory
        ledger_ok = ledger_dir.exists()
        checks.append(
            {
                "name": "Ledger directory",
                "ok": ledger_ok,
                "detail": str(ledger_dir),
            }
        )

        all_ok = all(c["ok"] for c in checks)

        return {
            "status": "healthy" if all_ok else "degraded",
            "version": __version__,
            "python": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
            "platform": platform.platform(),
            "checks": checks,
        }

    return router
