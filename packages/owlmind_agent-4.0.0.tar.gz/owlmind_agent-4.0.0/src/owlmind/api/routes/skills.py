"""Skill pack REST endpoints."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status

from owlmind.api.auth import verify_api_key

logger = logging.getLogger(__name__)


def make_skills_router(packs_dir: Path | None = None) -> APIRouter:
    """Create skills router (GET /skills/packs, GET /skills/packs/{id})."""
    router = APIRouter(
        prefix="/api/v1/skills",
        tags=["skills"],
        dependencies=[Depends(verify_api_key)],
    )

    @router.get("/packs", response_model=list[dict[str, Any]])
    async def list_skill_packs() -> list[dict[str, Any]]:
        """List all available skill packs."""
        try:
            from owlmind.skills.registry import list_packs

            packs = list_packs(base_dir=packs_dir)
            return [
                {
                    "id": p["id"],
                    "name": p["name"],
                    "version": p["version"],
                    "description": p["description"],
                    "tags": p["tags"],
                }
                for p in packs
            ]
        except Exception as exc:
            logger.exception("Failed to list skill packs")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to list skill packs: {exc}",
            ) from exc

    @router.get("/packs/{pack_id}", response_model=dict[str, Any])
    async def get_skill_pack(pack_id: str) -> dict[str, Any]:
        """Get metadata and context for a specific skill pack."""
        try:
            from owlmind.skills.registry import get_pack_context, load_pack

            pack = load_pack(pack_id, base_dir=packs_dir)
            context = get_pack_context(pack_id, base_dir=packs_dir)
            return {
                "id": pack.get("id", pack_id),
                "name": pack.get("name", pack_id),
                "version": pack.get("version", "0.0.0"),
                "description": pack.get("description", ""),
                "tags": pack.get("tags", []),
                "workflows": pack.get("workflows", []),
                "knowledge_files": pack.get("knowledge_files", []),
                "context": context,
            }
        except FileNotFoundError as exc:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Skill pack '{pack_id}' not found",
            ) from exc
        except Exception as exc:
            logger.exception("Failed to load skill pack %s", pack_id)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to load skill pack: {exc}",
            ) from exc

    return router
