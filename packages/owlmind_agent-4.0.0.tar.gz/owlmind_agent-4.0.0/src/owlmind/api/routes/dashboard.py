"""Dashboard, screen capture, and extended health endpoints."""

from __future__ import annotations

import base64
import contextlib
import json
import logging
import subprocess
import tempfile
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends
from fastapi.responses import HTMLResponse

from owlmind.api.auth import verify_api_key

logger = logging.getLogger(__name__)


def make_dashboard_router(runs_dir: Path, ledger_dir: Path) -> APIRouter:
    """Create dashboard router with screen capture and extended health."""
    router = APIRouter(tags=["dashboard"])

    @router.get("/", response_class=HTMLResponse, include_in_schema=False)
    async def root() -> str:
        """Serve dashboard HTML. Falls back to built-in page."""
        dashboard_path = Path.home() / "owlmind_dashboard.html"
        if dashboard_path.exists():
            return dashboard_path.read_text()
        return _FALLBACK_HTML

    @router.get("/api/v1/screen", dependencies=[Depends(verify_api_key)])
    async def screen_capture() -> dict[str, Any]:
        """Capture the current screen (macOS screencapture). Returns base64 PNG."""
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
            tmp_path = Path(f.name)
        try:
            result = subprocess.run(
                ["screencapture", "-x", "-t", "png", str(tmp_path)],
                timeout=10,
                capture_output=True,
            )
            if result.returncode != 0:
                return {
                    "error": "screencapture failed",
                    "stderr": result.stderr.decode(errors="replace"),
                }
            data = tmp_path.read_bytes()
            return {
                "format": "png",
                "data": base64.b64encode(data).decode(),
                "size_bytes": len(data),
            }
        except FileNotFoundError:
            return {"error": "screencapture not found (macOS only)"}
        except subprocess.TimeoutExpired:
            return {"error": "screencapture timed out"}
        finally:
            with contextlib.suppress(OSError):
                tmp_path.unlink()

    @router.get("/api/v1/health/full", dependencies=[Depends(verify_api_key)])
    async def full_health() -> dict[str, Any]:
        """Extended health check: claude CLI availability, budget, runs directory."""
        checks: list[dict[str, Any]] = []

        # claude CLI availability
        try:
            r = subprocess.run(
                ["claude", "--version"],
                capture_output=True,
                timeout=5,
            )
            checks.append(
                {
                    "name": "claude CLI",
                    "ok": r.returncode == 0,
                    "detail": (
                        r.stdout.decode(errors="replace").strip()
                        or r.stderr.decode(errors="replace").strip()
                    ),
                }
            )
        except FileNotFoundError:
            checks.append({"name": "claude CLI", "ok": False, "detail": "not found in PATH"})
        except subprocess.TimeoutExpired:
            checks.append({"name": "claude CLI", "ok": False, "detail": "timeout"})

        # Budget from ledger
        usage_file = ledger_dir / "usage.jsonl"
        try:
            if usage_file.exists():
                total_usd = 0.0
                for raw in usage_file.read_text().splitlines():
                    with contextlib.suppress(json.JSONDecodeError, ValueError):
                        total_usd += float(json.loads(raw).get("cost_usd", 0))
                checks.append({"name": "Budget", "ok": True, "detail": f"${total_usd:.4f} total"})
            else:
                checks.append({"name": "Budget", "ok": True, "detail": "no ledger yet"})
        except OSError as exc:
            checks.append({"name": "Budget", "ok": False, "detail": str(exc)})

        # Runs directory
        try:
            if runs_dir.exists():
                run_count = sum(1 for d in runs_dir.iterdir() if d.is_dir())
                checks.append({"name": "Runs dir", "ok": True, "detail": f"{run_count} runs"})
            else:
                checks.append({"name": "Runs dir", "ok": False, "detail": "not found"})
        except OSError as exc:
            checks.append({"name": "Runs dir", "ok": False, "detail": str(exc)})

        return {
            "status": "healthy" if all(c["ok"] for c in checks) else "degraded",
            "checks": checks,
        }

    return router


_FALLBACK_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>OWLMIND Dashboard</title>
<style>
body{font-family:monospace;background:#0d1117;color:#c9d1d9;padding:24px;margin:0}
h1{color:#58a6ff}a{color:#58a6ff}
table{width:100%;border-collapse:collapse;background:#161b22;border-radius:6px}
th,td{padding:8px 12px;text-align:left;border-bottom:1px solid #21262d}
th{color:#58a6ff}.ok{color:#3fb950}.err{color:#f85149}.dim{color:#8b949e}
#status{padding:6px 0;color:#8b949e;font-size:.85em;margin-bottom:8px}
</style>
</head>
<body>
<h1>OWLMIND Dashboard</h1>
<p class="dim">
<a href="/api/v1/runs">Runs API</a> &bull;
<a href="/docs">Swagger UI</a> &bull;
<a href="/api/v1/health/full">Full health</a> &bull;
<a href="/api/v1/self-improve/insights">Insights</a></p>
<h2>Recent Runs</h2>
<div id="status">Connecting to live feed...</div>
<div id="runs-container">
<table><thead><tr><th>Run ID</th><th>State</th><th>Goal</th><th>Updated</th></tr></thead>
<tbody id="runs"><tr><td colspan="4">Loading...</td></tr></tbody></table>
</div>
<script>
const runsDiv = document.getElementById('runs');
const statusEl = document.getElementById('status');

async function loadRuns() {
  try {
    const r = await fetch('/api/v1/runs', {headers: {'X-API-Key': ''}});
    const data = await r.json();
    const runs = Array.isArray(data) ? data : (data.runs || []);
    runsDiv.innerHTML = runs.slice(0, 20).map(run =>
      `<tr><td>${(run.run_id||'?').slice(0,12)}</td><td>${run.state||run.status||'?'}</td><td>${(run.goal||'').slice(0,60)}</td><td>${run.updated_at||run.started_at||''}</td></tr>`
    ).join('') || '<tr><td colspan="4" class="dim">No runs found.</td></tr>';
  } catch(e) { runsDiv.innerHTML = '<tr><td colspan="4" class="err">Error loading runs.</td></tr>'; }
}
loadRuns();

try {
  const es = new EventSource('/api/v1/runs/live');
  es.onmessage = (e) => {
    try {
      const ev = JSON.parse(e.data);
      if (ev.event === 'stream_closed') return;
      statusEl.textContent = `Live ● ${ev.run_id ? ev.run_id.slice(0,8) : '?'} — ${ev.event||ev.type||'update'} at ${new Date().toLocaleTimeString()}`;
      if (['done','failed','started','worker_done','terminal'].includes(ev.event||ev.type||'')) loadRuns();
    } catch(_) {}
  };
  es.onerror = () => { statusEl.textContent = 'SSE disconnected — polling every 30s'; setTimeout(loadRuns, 30000); };
} catch(_) { setInterval(loadRuns, 30000); }
</script>
</body>
</html>"""
