"""GitHub webhook endpoint — receives PR events and queues OWLMIND review tasks.

Registers POST /api/v1/webhooks/github.

Supported events:
- pull_request (opened, reopened, synchronize) → queue code review goal
- check_run / check_suite (failed) → queue fix-CI goal

Configuration:
    OWLMIND_GITHUB_WEBHOOK_SECRET — HMAC-SHA256 secret for signature verification
    OWLMIND_QUEUE_DIR              — Queue directory path (default: ./queue)
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os
import uuid
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Header, HTTPException, Request, status
from fastapi.responses import JSONResponse

logger = logging.getLogger(__name__)


def make_github_webhook_router(
    queue_dir: str | Path | None = None,
    webhook_secret: str = "",
) -> APIRouter:
    """Create the GitHub webhook router.

    Args:
        queue_dir: Directory for the task queue.
        webhook_secret: HMAC secret for signature verification.
            Falls back to OWLMIND_GITHUB_WEBHOOK_SECRET env var.
    """
    router = APIRouter(prefix="/api/v1/webhooks", tags=["github"])

    _secret = webhook_secret or os.environ.get("OWLMIND_GITHUB_WEBHOOK_SECRET", "")
    _queue_dir = Path(queue_dir) if queue_dir else Path(
        os.environ.get("OWLMIND_QUEUE_DIR", "./queue")
    )

    @router.post("/github")
    async def github_webhook(
        request: Request,
        x_hub_signature_256: str | None = Header(None),
        x_github_event: str | None = Header(None),
        x_github_delivery: str | None = Header(None),
    ) -> JSONResponse:
        """Receive and process a GitHub webhook event."""
        raw_body = await request.body()

        # Verify signature when secret is configured
        if _secret:
            if not x_hub_signature_256:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Missing X-Hub-Signature-256 header",
                )
            _verify_github_signature(_secret, raw_body, x_hub_signature_256)

        # Parse JSON body
        try:
            payload: dict[str, Any] = json.loads(raw_body)
        except json.JSONDecodeError as exc:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid JSON: {exc}",
            ) from exc

        event_type = x_github_event or ""
        delivery_id = x_github_delivery or str(uuid.uuid4())

        logger.info("GitHub webhook: event=%s delivery=%s", event_type, delivery_id)

        result = _handle_event(event_type, payload, _queue_dir)
        return JSONResponse(content={"ok": True, "delivery_id": delivery_id, **result})

    return router


def _verify_github_signature(secret: str, body: bytes, signature: str) -> None:
    """Verify HMAC-SHA256 signature from GitHub."""
    expected = "sha256=" + hmac.new(
        secret.encode(),
        body,
        hashlib.sha256,
    ).hexdigest()
    if not hmac.compare_digest(expected, signature):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Invalid GitHub signature",
        )


def _handle_event(
    event_type: str,
    payload: dict[str, Any],
    queue_dir: Path,
) -> dict[str, Any]:
    """Route event to appropriate handler."""
    if event_type == "pull_request":
        return _handle_pr_event(payload, queue_dir)
    if event_type in ("check_run", "check_suite"):
        return _handle_ci_event(event_type, payload, queue_dir)
    return {"action": "ignored", "reason": f"event type '{event_type}' not handled"}


def _handle_pr_event(payload: dict[str, Any], queue_dir: Path) -> dict[str, Any]:
    """Queue a code review goal for PR opened/reopened/synchronize events."""
    action = payload.get("action", "")
    if action not in ("opened", "reopened", "synchronize"):
        return {"action": "ignored", "reason": f"PR action '{action}' not handled"}

    pr = payload.get("pull_request", {})
    repo = payload.get("repository", {})

    pr_number = pr.get("number", "?")
    pr_title = pr.get("title", "")
    pr_url = pr.get("html_url", "")
    repo_name = repo.get("full_name", "unknown/repo")
    author = pr.get("user", {}).get("login", "unknown")
    base_branch = pr.get("base", {}).get("ref", "main")
    head_branch = pr.get("head", {}).get("ref", "")
    changed_files = pr.get("changed_files", 0)
    additions = pr.get("additions", 0)
    deletions = pr.get("deletions", 0)

    goal = (
        f"Review PR #{pr_number} in {repo_name}: '{pr_title}'. "
        f"Author: {author}. Branch: {head_branch} -> {base_branch}. "
        f"Changes: +{additions}/-{deletions} in {changed_files} files. "
        f"PR URL: {pr_url}. "
        f"Check for: code quality, security issues, test coverage, style violations. "
        f"Output a concise review with actionable feedback."
    )

    try:
        task_id = _enqueue(goal, queue_dir, priority=1)
        logger.info("Queued PR review for %s#%s -> task %s", repo_name, pr_number, task_id)
        return {
            "action": "queued_review",
            "task_id": task_id,
            "pr": f"{repo_name}#{pr_number}",
        }
    except Exception as exc:
        logger.error("Failed to queue PR review: %s", exc)
        return {"action": "queue_failed", "error": str(exc)}


def _handle_ci_event(
    event_type: str, payload: dict[str, Any], queue_dir: Path
) -> dict[str, Any]:
    """Queue a fix-CI goal when a check fails."""
    action = payload.get("action", "")

    # Only handle completed failures
    if action != "completed":
        return {"action": "ignored", "reason": f"action '{action}' is not 'completed'"}

    conclusion = (
        payload.get("check_run", {}).get("conclusion")
        or payload.get("check_suite", {}).get("conclusion")
        or ""
    )
    if conclusion not in ("failure", "timed_out", "action_required"):
        return {"action": "ignored", "reason": f"conclusion '{conclusion}' is not a failure"}

    repo = payload.get("repository", {})
    repo_name = repo.get("full_name", "unknown/repo")

    check = payload.get("check_run") or payload.get("check_suite") or {}
    check_name = check.get("name", "CI check")
    check_url = check.get("html_url", "")
    head_sha = check.get("head_sha", "")

    goal = (
        f"Fix CI failure in {repo_name}: '{check_name}' failed (conclusion: {conclusion}). "
        f"Commit: {head_sha[:8] if head_sha else 'unknown'}. "
        f"Check URL: {check_url}. "
        f"Investigate the failure, identify root cause, and apply the minimal fix."
    )

    try:
        task_id = _enqueue(goal, queue_dir, priority=2)  # higher priority than PR reviews
        logger.info(
            "Queued CI fix for %s check '%s' -> task %s", repo_name, check_name, task_id
        )
        return {
            "action": "queued_ci_fix",
            "task_id": task_id,
            "check": check_name,
            "repo": repo_name,
        }
    except Exception as exc:
        logger.error("Failed to queue CI fix: %s", exc)
        return {"action": "queue_failed", "error": str(exc)}


def _enqueue(goal: str, queue_dir: Path, priority: int = 0) -> str:
    """Add task to the JSONL queue via TaskQueue (thread-safe). Returns task ID."""
    from owlmind.queue import TaskQueue

    resolved_queue = queue_dir.resolve()
    workspace = resolved_queue.parent.parent

    tq = TaskQueue(queue_dir=resolved_queue)
    item = tq.add(goal=goal, workspace=str(workspace), priority=priority)
    return item.id
