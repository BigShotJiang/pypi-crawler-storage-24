"""Slack slash command webhook endpoint.

Handles incoming ``/owlmind`` slash commands from Slack:

- Verifies the request signature (HMAC-SHA256 with the signing secret).
- Routes to the appropriate command handler (run / status / queue / help).
- Returns an immediate Slack-compatible JSON response.

Configuration via environment variables::

    OWLMIND_SLACK_SIGNING_SECRET   — required for signature verification
    OWLMIND_SLACK_BOT_TOKEN        — required for sending async notifications
"""

from __future__ import annotations

import contextlib
import logging
import os
import uuid
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Header, HTTPException, Request, status
from fastapi.responses import JSONResponse

from owlmind.integrations.slack.commands import (
    format_task_status,
    parse_payload,
    route_command,
)
from owlmind.integrations.slack.verifier import SlackSignatureError, verify_slack_signature

logger = logging.getLogger(__name__)


def make_slack_router(
    queue_dir: str | Path | None = None,
    signing_secret: str = "",
) -> APIRouter:
    """Create the Slack webhook router.

    Args:
        queue_dir: Path to the OWLMIND queue directory (for adding tasks).
        signing_secret: Slack app signing secret.  Falls back to the
            ``OWLMIND_SLACK_SIGNING_SECRET`` environment variable.
    """
    router = APIRouter(prefix="/api/v1/webhooks", tags=["slack"])

    _secret = signing_secret or os.environ.get("OWLMIND_SLACK_SIGNING_SECRET", "")
    _queue_dir = Path(queue_dir) if queue_dir else None

    @router.post("/slack")
    async def slack_slash_command(
        request: Request,
        x_slack_signature: str | None = Header(None),
        x_slack_request_timestamp: str | None = Header(None),
    ) -> JSONResponse:
        """Receive and handle a Slack slash command.

        Slack sends a URL-encoded ``application/x-www-form-urlencoded`` POST.
        This endpoint:

        1. Verifies the HMAC signature (if ``OWLMIND_SLACK_SIGNING_SECRET`` set).
        2. Parses the payload.
        3. Routes to the appropriate handler.
        4. Returns an immediate JSON response (Slack requires < 3s).
        """
        raw_body = await request.body()

        # Verify signature when secret is configured
        if _secret:
            if not x_slack_signature or not x_slack_request_timestamp:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Missing Slack signature headers",
                )
            try:
                verify_slack_signature(
                    signing_secret=_secret,
                    timestamp=x_slack_request_timestamp,
                    body=raw_body,
                    signature=x_slack_signature,
                )
            except SlackSignatureError as exc:
                logger.warning("Slack signature verification failed: %s", exc)
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Invalid Slack signature",
                ) from exc

        # Parse URL-encoded form body
        form_data = dict(
            pair.split("=", 1)
            for pair in raw_body.decode().split("&")
            if "=" in pair
        )
        # URL-decode values
        from urllib.parse import unquote_plus

        try:
            form_data = {k: unquote_plus(v) for k, v in form_data.items()}
        except ValueError:
            logger.debug("URL-decode failed, using raw form values")

        payload = parse_payload(form_data)

        logger.info(
            "Slack slash command: user=%s cmd=%s text=%r",
            payload.user_name,
            payload.command,
            payload.text,
        )

        response = route_command(payload)

        # Handle "run" command: actually insert into queue
        goal = response.pop("_goal", None)
        if goal and _queue_dir:
            try:
                task_id = _enqueue_task(goal, _queue_dir)
                response["text"] = (
                    f"⏳ *Task queued* by <@{payload.user_id}>\n"
                    f"*Goal:* {goal}\n"
                    f"*ID:* `{task_id}`\n"
                    f"You'll be notified when it completes."
                )
            except Exception as exc:
                logger.error("Failed to enqueue Slack task: %s", exc)
                response = {
                    "response_type": "ephemeral",
                    "text": f"❌ Failed to queue task: {exc}",
                }

        # Handle "status" command
        task_id_lookup = response.pop("_task_id", None)
        if task_id_lookup is not None:
            try:
                status_text = _get_task_status(task_id_lookup, _queue_dir)
                response["text"] = status_text
            except Exception as exc:
                response["text"] = f"❌ Could not retrieve status: {exc}"

        # Handle "queue" listing
        list_queue = response.pop("_list_queue", False)
        response.pop("_channel", None)
        if list_queue:
            try:
                queue_text = _list_queue_items(_queue_dir)
                response["text"] = queue_text
            except Exception as exc:
                response["text"] = f"❌ Could not list queue: {exc}"

        return JSONResponse(content=response)

    return router


# ---------------------------------------------------------------------------
# Internal helpers (queue I/O)
# ---------------------------------------------------------------------------


def _enqueue_task(goal: str, queue_dir: Path) -> str:
    """Append a PENDING task to the queue JSONL file. Returns task ID."""
    import json
    from datetime import UTC, datetime

    task_id = str(uuid.uuid4())
    item = {
        "id": task_id,
        "goal": goal,
        "workspace": str(queue_dir.parent),
        "sandbox": False,
        "priority": 0,
        "created_at": datetime.now(tz=UTC).isoformat(),
        "status": "PENDING",
        "run_id": "",
        "error": "",
        "session_id": "",
        "goal_id": "",
    }
    queue_dir.mkdir(parents=True, exist_ok=True)
    queue_file = queue_dir / "queue.jsonl"
    with queue_file.open("a") as f:
        f.write(json.dumps(item) + "\n")
    return task_id


def _get_task_status(task_id: str, queue_dir: Path | None) -> str:
    """Read queue and return formatted status for a task ID (or last task)."""
    import json

    if not queue_dir:
        return "⚠️ Queue directory not configured."

    queue_file = queue_dir / "queue.jsonl"
    if not queue_file.exists():
        return "📭 Queue is empty."

    tasks: list[dict[str, Any]] = []
    with queue_file.open() as f:
        for line in f:
            line = line.strip()
            if line:
                with contextlib.suppress(json.JSONDecodeError):
                    tasks.append(json.loads(line))

    if not tasks:
        return "📭 Queue is empty."

    if task_id:
        matches = [t for t in tasks if t.get("id", "").startswith(task_id)]
        if not matches:
            return f"❓ No task found with ID `{task_id}`"
        task = matches[-1]
    else:
        task = tasks[-1]

    return format_task_status(task)


def _list_queue_items(queue_dir: Path | None) -> str:
    """Return a formatted list of recent pending/running tasks."""
    import json

    if not queue_dir:
        return "⚠️ Queue directory not configured."

    queue_file = queue_dir / "queue.jsonl"
    if not queue_file.exists():
        return "📭 Queue is empty."

    tasks: list[dict[str, Any]] = []
    with queue_file.open() as f:
        for line in f:
            line = line.strip()
            if line:
                with contextlib.suppress(json.JSONDecodeError):
                    tasks.append(json.loads(line))

    if not tasks:
        return "📭 Queue is empty."

    # Show last 10 tasks, most recent first
    recent = tasks[-10:][::-1]
    lines = [f"*Recent tasks ({len(tasks)} total):*"]
    for t in recent:
        status_icon = {
            "PENDING": "⏳",
            "RUNNING": "🔄",
            "DONE": "✅",
            "FAILED": "❌",
        }.get(t.get("status", "").upper(), "❓")
        goal_short = (t.get("goal", "")[:60] + "…") if len(t.get("goal", "")) > 60 else t.get("goal", "")
        lines.append(f"{status_icon} `{t.get('id', '')[:8]}` {goal_short}")

    return "\n".join(lines)
