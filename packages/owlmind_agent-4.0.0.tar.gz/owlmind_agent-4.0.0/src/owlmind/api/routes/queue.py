"""Task queue REST endpoints."""

from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel

from owlmind.api.auth import verify_api_key

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Schemas
# ---------------------------------------------------------------------------


class QueueItemRequest(BaseModel):
    """Request body for adding a queue item."""

    goal: str
    workspace: str = ""
    priority: int = 0


class QueueItemResponse(BaseModel):
    """Response for a queue item."""

    id: str
    goal: str
    workspace: str
    status: str
    created_at: str = ""
    priority: int = 0


# ---------------------------------------------------------------------------
# Router factory
# ---------------------------------------------------------------------------


def make_queue_router(runs_dir: Path) -> APIRouter:
    """Create queue router (GET /queue/items, POST /queue/items, DELETE /queue/items/{id})."""
    router = APIRouter(
        prefix="/api/v1/queue",
        tags=["queue"],
        dependencies=[Depends(verify_api_key)],
    )
    queue_dir = runs_dir.parent / "queue"

    def _read_items() -> list[dict[str, Any]]:
        queue_file = queue_dir / "queue.jsonl"
        if not queue_file.exists():
            return []
        items: list[dict[str, Any]] = []
        for line in queue_file.read_text().splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                items.append(json.loads(line))
            except json.JSONDecodeError:
                continue
        return items

    @router.get("/items", response_model=list[QueueItemResponse])
    async def list_queue_items() -> list[dict[str, Any]]:
        """List all items in the task queue."""
        items = await asyncio.to_thread(_read_items)
        return [
            {
                "id": d.get("id", ""),
                "goal": d.get("goal", ""),
                "workspace": d.get("workspace", ""),
                "status": d.get("status", "pending"),
                "created_at": d.get("created_at", ""),
                "priority": d.get("priority", 0),
            }
            for d in items
        ]

    @router.post("/items", response_model=QueueItemResponse, status_code=status.HTTP_201_CREATED)
    async def add_queue_item(body: QueueItemRequest) -> dict[str, Any]:
        """Add a new task to the queue."""
        try:
            from owlmind.queue import TaskQueue

            def _do_add() -> dict[str, Any]:
                tq = TaskQueue(queue_dir=queue_dir)
                item = tq.add(goal=body.goal, workspace=body.workspace, priority=body.priority)
                return {
                    "id": item.id,
                    "goal": item.goal,
                    "workspace": item.workspace,
                    "status": item.status,
                    "created_at": getattr(item, "created_at", ""),
                    "priority": item.priority,
                }

            return await asyncio.to_thread(_do_add)
        except Exception as exc:
            logger.error("Failed to add queue item: %s", exc)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(exc)
            ) from exc

    @router.get("/items/{item_id}", response_model=QueueItemResponse)
    async def get_queue_item(item_id: str) -> dict[str, Any]:
        """Get details of a specific queue item by ID."""
        items = await asyncio.to_thread(_read_items)
        for d in items:
            if d.get("id") == item_id:
                return {
                    "id": d.get("id", ""),
                    "goal": d.get("goal", ""),
                    "workspace": d.get("workspace", ""),
                    "status": d.get("status", "pending"),
                    "created_at": d.get("created_at", ""),
                    "priority": d.get("priority", 0),
                }
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail=f"Item {item_id} not found"
        )

    @router.delete("/items/{item_id}", status_code=status.HTTP_200_OK)
    async def delete_queue_item(item_id: str) -> dict[str, str]:
        """Remove a pending item from the queue."""
        queue_file = queue_dir / "queue.jsonl"

        def _do_delete() -> dict[str, str]:
            if not queue_file.exists():
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND, detail="Queue is empty"
                )

            items = _read_items()
            new_items: list[dict[str, Any]] = []
            found = False
            for d in items:
                if d.get("id") == item_id:
                    current_status = d.get("status", "PENDING")
                    if current_status.upper() not in ("PENDING", "FAILED"):
                        raise HTTPException(
                            status_code=status.HTTP_409_CONFLICT,
                            detail=f"Item {item_id} has status '{current_status}' — cannot delete",
                        )
                    found = True
                    continue
                new_items.append(d)

            if not found:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND, detail=f"Item {item_id} not found"
                )

            queue_dir.mkdir(parents=True, exist_ok=True)
            queue_file.write_text(
                "\n".join(json.dumps(d, ensure_ascii=False) for d in new_items)
                + ("\n" if new_items else "")
            )
            logger.info("Deleted queue item %s", item_id)
            return {"id": item_id, "status": "deleted"}

        return await asyncio.to_thread(_do_delete)

    return router
