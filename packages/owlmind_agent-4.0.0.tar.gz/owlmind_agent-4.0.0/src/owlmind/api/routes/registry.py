"""Private skill pack registry REST endpoints.

All endpoints require authentication via ``X-Registry-Token`` header.
Admin endpoints (user management, moderation) require admin role.

Usage::

    from owlmind.api.routes.registry import make_registry_router

    router = make_registry_router(registry_db="registry.db", archive_dir="archives")
    app.include_router(router)
"""

from __future__ import annotations

import hashlib
import io
import json
import logging
import secrets
import zipfile
from pathlib import Path
from typing import Any

from fastapi import (
    APIRouter,
    Depends,
    File,
    Form,
    HTTPException,
    Query,
    UploadFile,
    status,
)
from fastapi.responses import FileResponse

from owlmind.api.registry_auth import hash_api_key, make_registry_auth
from owlmind.registry.models import (
    CreateUserRequest,
    CreateUserResponse,
    PublishRequest,
    RegistryUser,
    ReviewRequest,
)
from owlmind.registry.public import SQLitePublicPackRegistry

logger = logging.getLogger(__name__)

_MAX_ARCHIVE_SIZE = 10 * 1024 * 1024  # 10 MB


def _validate_manifest(data: bytes) -> dict[str, Any]:
    """Validate ZIP archive contains a valid manifest.json."""
    if len(data) > _MAX_ARCHIVE_SIZE:
        raise HTTPException(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail=f"Archive exceeds maximum size of {_MAX_ARCHIVE_SIZE // (1024 * 1024)} MB",
        )

    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid ZIP archive",
        ) from exc

    # Check for path traversal
    for name in zf.namelist():
        if ".." in name or name.startswith("/"):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Path traversal detected in archive: {name}",
            )

    # Find and parse manifest.json
    manifest_names = [n for n in zf.namelist() if n.endswith("manifest.json")]
    if not manifest_names:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Archive must contain manifest.json",
        )

    try:
        manifest = json.loads(zf.read(manifest_names[0]))
    except (json.JSONDecodeError, KeyError) as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid manifest.json",
        ) from exc

    for field in ("id", "name", "version"):
        if field not in manifest:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"manifest.json missing required field: {field}",
            )

    zf.close()
    return manifest


def make_registry_router(
    registry_db: str | Path | None = None,
    archive_dir: str | Path | None = None,
) -> APIRouter:
    """Create private registry router with authentication.

    Args:
        registry_db: Path to SQLite database for registry data.
        archive_dir: Directory for storing pack ZIP archives.

    Returns:
        Configured APIRouter with authenticated registry endpoints.
    """
    _db_path = Path(registry_db) if registry_db else Path("registry.db")
    _archive_dir = Path(archive_dir) if archive_dir else Path("registry_archives")
    _archive_dir.mkdir(parents=True, exist_ok=True)

    registry = SQLitePublicPackRegistry(_db_path)
    get_current_user, require_admin = make_registry_auth(registry)

    router = APIRouter(
        prefix="/api/v1/registry",
        tags=["registry"],
    )

    # ------------------------------------------------------------------
    # Authenticated endpoints (any user)
    # ------------------------------------------------------------------

    @router.get("/packs")
    async def search_packs(
        q: str = Query("", description="Search query"),
        tag: list[str] = Query([], description="Filter by tags"),
        sort: str = Query("downloads", description="Sort: downloads, rating, recent"),
        limit: int = Query(20, ge=1, le=100, description="Results per page"),
        offset: int = Query(0, ge=0, description="Pagination offset"),
    ) -> list[dict[str, Any]]:
        """Search and browse approved packs."""
        return await registry.search_packs(
            q=q, tags=tag or None, sort=sort, limit=limit, offset=offset
        )

    @router.get("/packs/{pack_id}")
    async def get_pack(
        pack_id: str,
        _user: dict[str, Any] = Depends(get_current_user),
    ) -> dict[str, Any]:
        """Get pack details with versions and review summary."""
        pack = await registry.get_pack(pack_id)
        if not pack:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Pack '{pack_id}' not found",
            )

        versions = await registry.list_versions(pack_id)
        reviews = await registry.list_reviews(pack_id)

        return {
            **pack,
            "versions": versions,
            "reviews_summary": {
                "count": len(reviews),
                "avg_rating": pack["avg_rating"],
                "recent_reviews": reviews[:5],
            },
        }

    @router.get("/packs/{pack_id}/versions")
    async def list_versions(
        pack_id: str,
        _user: dict[str, Any] = Depends(get_current_user),
    ) -> list[dict[str, Any]]:
        """List all versions of a pack."""
        pack = await registry.get_pack(pack_id)
        if not pack:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Pack '{pack_id}' not found",
            )
        return await registry.list_versions(pack_id)

    @router.get("/packs/{pack_id}/download/{version}")
    async def download_pack(
        pack_id: str,
        version: str,
        _user: dict[str, Any] = Depends(get_current_user),
    ) -> FileResponse:
        """Download a pack version ZIP archive."""
        ver = await registry.get_version(pack_id, version)
        if not ver:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Version '{version}' of pack '{pack_id}' not found",
            )

        archive_path = _archive_dir / pack_id / f"{version}.zip"
        if not archive_path.exists():
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Archive file not found on server",
            )

        await registry.increment_downloads(pack_id)
        return FileResponse(
            path=str(archive_path),
            filename=f"{pack_id}-{version}.zip",
            media_type="application/zip",
        )

    @router.get("/packs/{pack_id}/reviews")
    async def list_reviews(
        pack_id: str,
        _user: dict[str, Any] = Depends(get_current_user),
    ) -> list[dict[str, Any]]:
        """List reviews for a pack."""
        pack = await registry.get_pack(pack_id)
        if not pack:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Pack '{pack_id}' not found",
            )
        return await registry.list_reviews(pack_id)

    @router.post("/packs", status_code=status.HTTP_201_CREATED)
    async def publish_pack(
        archive: UploadFile = File(..., description="ZIP archive with manifest.json"),
        name: str = Form(""),
        description: str = Form(""),
        tags: str = Form("[]", description="JSON array of tags"),
        version: str = Form(""),
        changelog: str = Form(""),
        author_name: str = Form(""),
        author_github: str = Form(""),
        _user: dict[str, Any] = Depends(get_current_user),
    ) -> dict[str, Any]:
        """Publish a new pack or update existing. Status starts as pending."""
        data = await archive.read()
        manifest = _validate_manifest(data)

        pack_id = manifest["id"]
        pack_name = name or manifest.get("name", pack_id)
        pack_version = version or manifest.get("version", "0.1.0")

        try:
            tag_list = json.loads(tags) if tags else []
        except json.JSONDecodeError:
            tag_list = []

        req = PublishRequest(
            name=pack_name,
            description=description or manifest.get("description", ""),
            tags=tag_list or manifest.get("tags", []),
            version=pack_version,
            changelog=changelog,
            author_name=author_name or manifest.get("author", ""),
            author_github=author_github,
        )

        result = await registry.publish_pack(pack_id, req)

        # Store archive
        pack_archive_dir = _archive_dir / pack_id
        pack_archive_dir.mkdir(parents=True, exist_ok=True)
        archive_path = pack_archive_dir / f"{pack_version}.zip"
        archive_path.write_bytes(data)

        # Update version with SHA256 and size
        sha256 = hashlib.sha256(data).hexdigest()
        await registry.add_version(
            pack_id=pack_id,
            version=pack_version,
            archive_sha256=sha256,
            archive_size=len(data),
            changelog=changelog,
        )

        return result

    @router.post("/packs/{pack_id}/versions", status_code=status.HTTP_201_CREATED)
    async def add_version(
        pack_id: str,
        archive: UploadFile = File(..., description="ZIP archive"),
        version: str = Form(..., description="Version string"),
        changelog: str = Form(""),
        _user: dict[str, Any] = Depends(get_current_user),
    ) -> dict[str, Any]:
        """Add a new version to an existing pack."""
        pack = await registry.get_pack(pack_id)
        if not pack:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Pack '{pack_id}' not found",
            )

        data = await archive.read()
        _validate_manifest(data)

        # Store archive
        pack_archive_dir = _archive_dir / pack_id
        pack_archive_dir.mkdir(parents=True, exist_ok=True)
        archive_path = pack_archive_dir / f"{version}.zip"
        archive_path.write_bytes(data)

        sha256 = hashlib.sha256(data).hexdigest()
        return await registry.add_version(
            pack_id=pack_id,
            version=version,
            archive_sha256=sha256,
            archive_size=len(data),
            changelog=changelog,
        )

    @router.post("/packs/{pack_id}/reviews", status_code=status.HTTP_201_CREATED)
    async def add_review(
        pack_id: str,
        review: ReviewRequest,
        _user: dict[str, Any] = Depends(get_current_user),
    ) -> dict[str, Any]:
        """Add a review to a pack."""
        pack = await registry.get_pack(pack_id)
        if not pack:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Pack '{pack_id}' not found",
            )

        return await registry.add_review(
            pack_id=pack_id,
            author_name=review.author_name,
            rating=review.rating,
            comment=review.comment,
        )

    # ------------------------------------------------------------------
    # Admin endpoints
    # ------------------------------------------------------------------

    @router.post("/admin/approve/{pack_id}")
    async def approve_pack(
        pack_id: str,
        _admin: dict[str, Any] = Depends(require_admin),
    ) -> dict[str, str]:
        """Approve a pending pack (admin only)."""
        ok = await registry.approve_pack(pack_id)
        if not ok:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Pack '{pack_id}' not found",
            )
        return {"status": "approved", "pack_id": pack_id}

    @router.post("/admin/reject/{pack_id}")
    async def reject_pack(
        pack_id: str,
        _admin: dict[str, Any] = Depends(require_admin),
    ) -> dict[str, str]:
        """Reject a pending pack (admin only)."""
        ok = await registry.reject_pack(pack_id)
        if not ok:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Pack '{pack_id}' not found",
            )
        return {"status": "rejected", "pack_id": pack_id}

    # ------------------------------------------------------------------
    # Admin: user management
    # ------------------------------------------------------------------

    @router.post("/admin/users", status_code=status.HTTP_201_CREATED)
    async def create_user(
        req: CreateUserRequest,
        _admin: dict[str, Any] = Depends(require_admin),
    ) -> CreateUserResponse:
        """Create a new registry user. Returns the API key (shown only once)."""
        raw_key = "cwrk_" + secrets.token_urlsafe(32)
        key_hash = hash_api_key(raw_key)

        try:
            user_dict = await registry.create_user(
                username=req.username,
                email=req.email,
                role=req.role.value,
                api_key_hash=key_hash,
            )
        except Exception as exc:
            if "UNIQUE" in str(exc):
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail=f"Username '{req.username}' already exists",
                ) from exc
            raise

        return CreateUserResponse(
            user=RegistryUser(**user_dict),
            api_key=raw_key,
        )

    @router.get("/admin/users")
    async def list_users(
        include_inactive: bool = Query(False),
        _admin: dict[str, Any] = Depends(require_admin),
    ) -> list[dict[str, Any]]:
        """List all registry users (admin only)."""
        return await registry.list_users(include_inactive=include_inactive)

    @router.post("/admin/users/{user_id}/deactivate")
    async def deactivate_user(
        user_id: str,
        _admin: dict[str, Any] = Depends(require_admin),
    ) -> dict[str, str]:
        """Deactivate a registry user (admin only)."""
        ok = await registry.deactivate_user(user_id)
        if not ok:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"User '{user_id}' not found",
            )
        return {"status": "deactivated", "user_id": user_id}

    return router
