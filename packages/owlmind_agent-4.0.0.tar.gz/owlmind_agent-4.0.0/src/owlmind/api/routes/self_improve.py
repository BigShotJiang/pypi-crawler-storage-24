"""Self-improvement analysis API route."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel

from owlmind.api.auth import verify_api_key


class AnalyzeRequest(BaseModel):
    runs_dir: str = "runs"
    days: int = 7
    save_to_memory: bool = False
    memory_db: str | None = None


class ProposalRequest(BaseModel):
    max_proposals: int = 10


class ABTestCreateRequest(BaseModel):
    improvement_id: str
    metric: str = "success_rate"
    min_runs: int = 10


class ABTestRecordRequest(BaseModel):
    variant: str  # "a" or "b"
    success: bool


def make_self_improve_router(runs_dir: Path, memory_db: Path | None = None) -> APIRouter:
    router = APIRouter(prefix="/api/v1/self-improve", tags=["self-improve"])

    @router.post("/analyze", dependencies=[Depends(verify_api_key)])
    async def analyze_runs(req: AnalyzeRequest) -> dict[str, Any]:
        """Analyze recent runs and extract improvement insights."""
        try:
            from owlmind.self_improve import (
                analyze_runs as _analyze,
            )
            from owlmind.self_improve import (
                format_insights_markdown,
                load_recent_runs,
            )
        except ImportError as exc:
            raise HTTPException(
                status_code=503, detail=f"self_improve module unavailable: {exc}"
            ) from exc

        _runs_dir = Path(req.runs_dir) if req.runs_dir else runs_dir
        try:
            recent = load_recent_runs(_runs_dir, days=req.days)
            insights = _analyze(recent)
        except Exception as exc:
            raise HTTPException(status_code=500, detail=str(exc)) from exc

        result: dict[str, Any] = {
            "runs_analyzed": len(recent),
            "insights_count": len(insights),
            "insights": [
                {
                    "category": ins.category,
                    "description": ins.description,
                    "frequency": ins.frequency,
                    "examples": ins.examples,
                }
                for ins in insights
            ],
            "markdown": format_insights_markdown(insights, days=req.days),
        }

        if req.save_to_memory and insights:
            try:
                from owlmind.self_improve import save_insights_to_memory

                _mem_db = (
                    Path(req.memory_db)
                    if req.memory_db
                    else (memory_db or runs_dir.parent / "memory" / "memory.db")
                )
                save_insights_to_memory(insights, _mem_db)
                result["saved_to_memory"] = True
            except Exception as exc:
                result["save_error"] = str(exc)

        return result

    @router.get("/insights", dependencies=[Depends(verify_api_key)])
    async def get_recent_insights(days: int = Query(7, ge=1, le=365)) -> dict[str, Any]:
        """Quick analysis of recent runs — returns markdown summary."""
        try:
            from owlmind.self_improve import (
                analyze_runs as _analyze,
            )
            from owlmind.self_improve import (
                format_insights_markdown,
                load_recent_runs,
            )
        except ImportError as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc

        try:
            recent = load_recent_runs(runs_dir, days=days)
            insights = _analyze(recent)
            return {
                "runs_analyzed": len(recent),
                "insights_count": len(insights),
                "markdown": format_insights_markdown(insights, days=days),
            }
        except Exception as exc:
            raise HTTPException(status_code=500, detail=str(exc)) from exc

    # ------------------------------------------------------------------
    # Deep analysis with RunExtended
    # ------------------------------------------------------------------

    @router.get("/report", dependencies=[Depends(verify_api_key)])
    async def get_analysis_report() -> dict[str, Any]:
        """Deep analysis using RunExtended data."""
        try:
            from owlmind.self_improve.analyzer import analyze as deep_analyze
            from owlmind.self_improve.analyzer import collect_run_extended
        except ImportError as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc

        try:
            extended = collect_run_extended(runs_dir)
            report = deep_analyze(extended)
            return report.to_dict()
        except Exception as exc:
            raise HTTPException(status_code=500, detail=str(exc)) from exc

    # ------------------------------------------------------------------
    # Improvement proposals
    # ------------------------------------------------------------------

    @router.post("/proposals", dependencies=[Depends(verify_api_key)])
    async def generate_proposals(req: ProposalRequest) -> dict[str, Any]:
        """Generate improvement proposals from run analysis."""
        try:
            from owlmind.self_improve.analyzer import analyze as deep_analyze
            from owlmind.self_improve.analyzer import collect_run_extended
            from owlmind.self_improve.generator import generate_improvements
        except ImportError as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc

        try:
            extended = collect_run_extended(runs_dir)
            report = deep_analyze(extended)
            improvements = generate_improvements(report, max_proposals=req.max_proposals)
            return {
                "count": len(improvements),
                "proposals": [imp.to_dict() for imp in improvements],
            }
        except Exception as exc:
            raise HTTPException(status_code=500, detail=str(exc)) from exc

    # ------------------------------------------------------------------
    # A/B tests
    # ------------------------------------------------------------------

    @router.get("/ab-tests", dependencies=[Depends(verify_api_key)])
    async def list_ab_tests(
        status: str = Query("", description="Filter by status"),
    ) -> dict[str, Any]:
        """List A/B tests."""
        try:
            from owlmind.self_improve.ab_testing import ABTestScheduler
        except ImportError as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc

        ab_dir = runs_dir.parent / "ab_tests"
        scheduler = ABTestScheduler(ab_dir)
        tests = scheduler.list_tests(status=status or None)
        return {"count": len(tests), "tests": [t.to_dict() for t in tests]}

    @router.post("/ab-tests", dependencies=[Depends(verify_api_key)])
    async def create_ab_test(req: ABTestCreateRequest) -> dict[str, Any]:
        """Create a new A/B test."""
        try:
            from owlmind.self_improve.ab_testing import ABTestScheduler
        except ImportError as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc

        ab_dir = runs_dir.parent / "ab_tests"
        scheduler = ABTestScheduler(ab_dir)
        test = scheduler.create_test(req.improvement_id, metric=req.metric, min_runs=req.min_runs)
        return test.to_dict()

    @router.post("/ab-tests/{test_id}/record", dependencies=[Depends(verify_api_key)])
    async def record_ab_result(test_id: str, req: ABTestRecordRequest) -> dict[str, Any]:
        """Record a run result for an A/B test variant."""
        try:
            from owlmind.self_improve.ab_testing import ABTestScheduler
        except ImportError as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc

        ab_dir = runs_dir.parent / "ab_tests"
        scheduler = ABTestScheduler(ab_dir)
        test = scheduler.record_result(test_id, req.variant, success=req.success)
        if test is None:
            raise HTTPException(status_code=404, detail=f"Test not found or not running: {test_id}")
        return test.to_dict()

    return router
