"""Memory store REST endpoints."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from owlmind.memory.store import MemoryStore

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel

from owlmind.api.auth import verify_api_key

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Schemas
# ---------------------------------------------------------------------------


class IngestRequest(BaseModel):
    """Request body for ingesting a document into memory."""

    kind: str = "doc"
    source: str = ""
    content: str


class SignalRequest(BaseModel):
    """Request body for recording a signal."""

    kind: str  # 'error' | 'lesson' | 'pattern' | 'decision'
    summary: str
    detail: str = ""
    run_id: str = ""


# ---------------------------------------------------------------------------
# Router factory
# ---------------------------------------------------------------------------


def make_memory_router(memory_db: Path) -> APIRouter:
    """Create memory router (GET /memory/stats, GET /memory/signals, POST /memory/query, POST /memory/ingest)."""
    router = APIRouter(
        prefix="/api/v1/memory",
        tags=["memory"],
        dependencies=[Depends(verify_api_key)],
    )

    def _get_store() -> MemoryStore:
        from owlmind.memory.store import MemoryStore

        return MemoryStore(memory_db)

    @router.get("/stats")
    async def memory_stats() -> dict[str, Any]:
        """Return memory store statistics (document, chunk, signal counts)."""
        try:
            store = _get_store()
            stats = store.stats()
            store.close()
            return stats
        except Exception as exc:
            logger.exception("Failed to get memory stats")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Memory stats failed: {exc}",
            ) from exc

    @router.get("/signals")
    async def get_signals(
        kind: str | None = Query(
            None, description="Filter by kind: error, lesson, pattern, decision"
        ),
        limit: int = Query(50, ge=1, le=200),
    ) -> list[dict[str, Any]]:
        """Get signals from past runs (lessons, errors, patterns)."""
        try:
            store = _get_store()
            signals = store.get_signals(kind=kind or None, limit=limit)
            store.close()
            return [
                {
                    "signal_id": s.signal_id,
                    "run_id": s.run_id or "",
                    "kind": s.kind,
                    "summary": s.summary,
                    "detail": s.detail or "",
                    "created": s.created,
                }
                for s in signals
            ]
        except Exception as exc:
            logger.exception("Failed to get signals")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to retrieve signals: {exc}",
            ) from exc

    @router.post("/query")
    async def query_memory(
        text: str = Query(..., description="Search query text"),
        top_k: int = Query(5, ge=1, le=20),
    ) -> list[dict[str, Any]]:
        """Query memory store using TF-IDF lexical search."""
        try:
            from owlmind.memory.retrieval import query

            store = _get_store()
            results = query(store, text, top_k=top_k)
            store.close()
            return [
                {
                    "chunk_id": r.chunk_id,
                    "doc_id": r.doc_id,
                    "source": r.source,
                    "score": r.score,
                    "snippet": r.snippet,
                }
                for r in results
            ]
        except Exception as exc:
            logger.exception("Failed to query memory")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Memory query failed: {exc}",
            ) from exc

    @router.post("/ingest", status_code=status.HTTP_201_CREATED)
    async def ingest_document(body: IngestRequest) -> dict[str, str]:
        """Ingest a document into the memory store."""
        try:
            store = _get_store()
            doc_id = store.ingest(
                kind=body.kind,
                source=body.source or "api",
                content=body.content,
            )
            store.close()
            return {"doc_id": doc_id, "status": "ingested"}
        except Exception as exc:
            logger.exception("Failed to ingest document")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Ingest failed: {exc}",
            ) from exc

    @router.post("/signals", status_code=status.HTTP_201_CREATED)
    async def add_signal(body: SignalRequest) -> dict[str, Any]:
        """Record a signal (lesson, error, pattern, decision)."""
        try:
            store = _get_store()
            signal_id = store.add_signal(
                kind=body.kind,
                summary=body.summary,
                run_id=body.run_id or None,
                detail=body.detail or None,
            )
            store.close()
            return {"signal_id": signal_id, "status": "recorded"}
        except Exception as exc:
            logger.exception("Failed to add signal")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Signal recording failed: {exc}",
            ) from exc

    @router.delete("/signals/{signal_id}", status_code=status.HTTP_204_NO_CONTENT)
    async def delete_signal(signal_id: int) -> None:
        """Delete a memory signal by ID."""
        try:
            store = _get_store()
            deleted = store.delete_signal(signal_id)
            store.close()
        except Exception as exc:
            logger.exception("Failed to delete signal")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Signal deletion failed: {exc}",
            ) from exc
        if not deleted:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Signal {signal_id} not found",
            )

    return router
