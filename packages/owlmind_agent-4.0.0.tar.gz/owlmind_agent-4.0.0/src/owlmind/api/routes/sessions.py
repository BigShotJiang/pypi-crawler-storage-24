"""Session management endpoints."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field

from owlmind.api.auth import verify_api_key

logger = logging.getLogger(__name__)

# Default sessions dir relative to runs_dir parent
_SESSIONS_SUBDIR = "sessions"


# ---------------------------------------------------------------------------
# Request / Response schemas
# ---------------------------------------------------------------------------


class SessionCreateRequest(BaseModel):
    """Request body for creating a new session."""

    goals: list[dict[str, Any]] = Field(..., min_length=1)
    workspace: str = "."
    max_concurrency: int = 1
    continue_on_fail: bool = False
    scheduler: bool = False


class SessionSummary(BaseModel):
    """Compact session summary for list endpoints."""

    session_id: str
    status: str = "unknown"
    created_at: str = ""
    updated_at: str = ""
    goals_count: int = 0


class SessionDetail(BaseModel):
    """Full session detail."""

    session_id: str
    status: str = "unknown"
    created_at: str = ""
    updated_at: str = ""
    current_goal_index: int = 0
    goals: list[dict[str, Any]] = Field(default_factory=list)
    runs: list[dict[str, Any]] = Field(default_factory=list)
    last_block_reason: str = ""
    config: dict[str, Any] = Field(default_factory=dict)
    max_concurrency: int = 1
    continue_on_fail: bool = False


class GoalDetail(BaseModel):
    """Goal with status information."""

    id: str
    goal: str
    workspace: str = "."
    depends_on: list[str] = Field(default_factory=list)
    status: str = "pending"
    run_id: str = ""
    started_at: str = ""
    ended_at: str = ""


class SessionCreateResponse(BaseModel):
    """Response for session creation."""

    session_id: str
    status: str
    goals_count: int
    mode: str = "local"


# ---------------------------------------------------------------------------
# Router factory
# ---------------------------------------------------------------------------


def make_sessions_router(runs_dir: Path) -> APIRouter:
    """Create sessions router.

    Sessions are stored in a ``sessions/`` directory that is a sibling
    of ``runs_dir`` (i.e. ``runs_dir.parent / 'sessions'``).
    """
    router = APIRouter(
        prefix="/api/v1/sessions",
        tags=["sessions"],
        dependencies=[Depends(verify_api_key)],
    )

    sessions_dir = runs_dir.parent / _SESSIONS_SUBDIR

    def _read_session_meta(session_path: Path) -> dict[str, Any] | None:
        meta_path = session_path / "session_meta.json"
        if not meta_path.exists():
            return None
        try:
            return json.loads(meta_path.read_text())  # type: ignore[no-any-return]
        except (json.JSONDecodeError, OSError):
            return None

    def _read_session_events(session_path: Path) -> list[dict[str, Any]]:
        log_path = session_path / "session.jsonl"
        if not log_path.exists():
            return []
        events: list[dict[str, Any]] = []
        for line in log_path.read_text().splitlines():
            line = line.strip()
            if line:
                try:
                    events.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        return events

    # ------------------------------------------------------------------
    # GET /  — list all sessions
    # ------------------------------------------------------------------

    @router.get("", response_model=list[SessionSummary])
    async def list_sessions() -> list[dict[str, Any]]:
        """List all sessions."""
        if not sessions_dir.is_dir():
            return []

        results: list[dict[str, Any]] = []
        for sdir in sorted(sessions_dir.iterdir(), reverse=True):
            if not sdir.is_dir():
                continue
            meta = _read_session_meta(sdir)
            if meta is None:
                continue
            results.append(
                {
                    "session_id": meta.get("session_id", sdir.name),
                    "status": meta.get("status", "unknown"),
                    "created_at": meta.get("created_at", ""),
                    "updated_at": meta.get("updated_at", ""),
                    "goals_count": len(meta.get("goals", [])),
                }
            )

        return results

    # ------------------------------------------------------------------
    # POST /  — create a new session
    # ------------------------------------------------------------------

    @router.post("", response_model=SessionCreateResponse, status_code=201)
    async def create_session(body: SessionCreateRequest) -> dict[str, Any]:
        """Create a new session from a list of goals.

        If ``scheduler=true``, the session is created for distributed
        execution (the scheduler will dispatch goals). Otherwise the
        session is created but not started.
        """
        from owlmind.session import (
            SESSION_RUNNING,
            GoalSpec,
            SessionMeta,
            generate_session_id,
            save_session,
        )

        session_id = generate_session_id()

        from datetime import UTC, datetime

        now = datetime.now(UTC).isoformat()

        # Build GoalSpec list from request
        goals: list[GoalSpec] = []
        for i, g in enumerate(body.goals):
            goal_id = g.get("id", f"G{i + 1}")
            goal_text = g.get("goal", "")
            if not goal_text:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Goal {goal_id} has no 'goal' text",
                )
            ws = g.get("workspace", body.workspace)
            goals.append(
                GoalSpec(
                    id=goal_id,
                    goal=goal_text,
                    workspace=ws,
                    sandbox=g.get("sandbox", False),
                    depends_on=g.get("depends_on", []),
                    use_llm=g.get("use_llm", "both"),
                    use_worker=g.get("use_worker", "none"),
                    max_steps=g.get("max_steps", 200),
                )
            )

        meta = SessionMeta(
            session_id=session_id,
            created_at=now,
            updated_at=now,
            status=SESSION_RUNNING,
            goals=goals,
            runs=[],
            max_concurrency=body.max_concurrency,
            continue_on_fail=body.continue_on_fail,
        )

        sessions_dir.mkdir(parents=True, exist_ok=True)
        save_session(meta, sessions_dir)

        mode = "scheduler" if body.scheduler else "local"
        logger.info("Created session %s (mode=%s, goals=%d)", session_id, mode, len(goals))

        return {
            "session_id": session_id,
            "status": SESSION_RUNNING,
            "goals_count": len(goals),
            "mode": mode,
        }

    # ------------------------------------------------------------------
    # GET /{session_id}  — session detail
    # ------------------------------------------------------------------

    @router.get("/{session_id}", response_model=SessionDetail)
    async def get_session(session_id: str) -> dict[str, Any]:
        """Get detailed information about a single session."""
        session_path = sessions_dir / session_id
        meta = _read_session_meta(session_path)

        if meta is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Session not found: {session_id}",
            )

        return {
            "session_id": meta.get("session_id", session_id),
            "status": meta.get("status", "unknown"),
            "created_at": meta.get("created_at", ""),
            "updated_at": meta.get("updated_at", ""),
            "current_goal_index": meta.get("current_goal_index", 0),
            "goals": meta.get("goals", []),
            "runs": meta.get("runs", []),
            "last_block_reason": meta.get("last_block_reason", ""),
            "config": meta.get("config", {}),
            "max_concurrency": meta.get("max_concurrency", 1),
            "continue_on_fail": meta.get("continue_on_fail", False),
        }

    # ------------------------------------------------------------------
    # GET /{session_id}/goals  — goals with status
    # ------------------------------------------------------------------

    @router.get("/{session_id}/goals", response_model=list[GoalDetail])
    async def get_session_goals(session_id: str) -> list[dict[str, Any]]:
        """Get all goals for a session with their execution status."""
        session_path = sessions_dir / session_id
        meta = _read_session_meta(session_path)

        if meta is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Session not found: {session_id}",
            )

        # Build run lookup
        run_map: dict[str, dict[str, Any]] = {}
        for r in meta.get("runs", []):
            gid = r.get("goal_id", "")
            if gid:
                run_map[gid] = r

        result: list[dict[str, Any]] = []
        for g in meta.get("goals", []):
            gid = g.get("id", "")
            run = run_map.get(gid, {})
            result.append(
                {
                    "id": gid,
                    "goal": g.get("goal", ""),
                    "workspace": g.get("workspace", "."),
                    "depends_on": g.get("depends_on", []),
                    "status": run.get("status", "pending"),
                    "run_id": run.get("run_id", ""),
                    "started_at": run.get("started_at", ""),
                    "ended_at": run.get("ended_at", ""),
                }
            )

        return result

    # ------------------------------------------------------------------
    # GET /{session_id}/goals/{goal_id}/logs  — goal event logs
    # ------------------------------------------------------------------

    @router.get("/{session_id}/goals/{goal_id}/logs")
    async def get_goal_logs(
        session_id: str,
        goal_id: str,
        last_n: int = Query(50, alias="last", ge=1, le=500),
    ) -> dict[str, Any]:
        """Get event logs for a specific goal.

        Returns session events filtered by goal_id and run events
        if a run_id exists for this goal.
        """
        session_path = sessions_dir / goal_id  # placeholder; overwritten below
        session_path = sessions_dir / session_id
        meta = _read_session_meta(session_path)

        if meta is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Session not found: {session_id}",
            )

        # Check goal exists
        goal_ids = [g.get("id", "") for g in meta.get("goals", [])]
        if goal_id not in goal_ids:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Goal not found: {goal_id}",
            )

        # Session events filtered by goal_id
        all_events = _read_session_events(session_path)
        session_events = [
            e
            for e in all_events
            if e.get("goal_id") == goal_id or goal_id in str(e.get("event", ""))
        ][-last_n:]

        # Run events (if run exists)
        run_events: list[dict[str, Any]] = []
        run_id = ""
        for r in meta.get("runs", []):
            if r.get("goal_id") == goal_id:
                run_id = r.get("run_id", "")
                break

        if run_id:
            run_log_path = runs_dir / run_id / "run.jsonl"
            if run_log_path.exists():
                for line in run_log_path.read_text().splitlines()[-last_n:]:
                    line = line.strip()
                    if line:
                        try:
                            run_events.append(json.loads(line))
                        except json.JSONDecodeError:
                            continue

        return {
            "session_id": session_id,
            "goal_id": goal_id,
            "run_id": run_id,
            "session_events": session_events,
            "run_events": run_events,
        }

    return router
