"""Sofiya integration endpoint — Charwiz as brain for Sofiya bot."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from fastapi import APIRouter
from pydantic import BaseModel

logger = logging.getLogger(__name__)


class PlanRequest(BaseModel):
    boss_input: str
    employees: list[dict]  # [{name, id, status, tasks}]
    memory: str = ""
    team_status: str = ""


class AnalyzeRequest(BaseModel):
    text: str
    context: str = ""


class ChatRequest(BaseModel):
    employee_name: str
    message: str
    tasks_info: str = ""
    profile: str = ""
    history: list[dict] = []
    language: str = "ru"


class MemoryRequest(BaseModel):
    action: str  # save, search, profile
    content: str = ""
    category: str = "note"
    query: str = ""
    user_id: str = ""


class SofiyaResponse(BaseModel):
    success: bool
    data: Any = None
    error: str | None = None


def make_sofiya_router(memory_db: str | Path | None = None) -> APIRouter:
    router = APIRouter(prefix="/sofiya", tags=["sofiya"])

    @router.post("/plan", response_model=SofiyaResponse)
    async def create_plan(req: PlanRequest):
        """Generate a plan from boss input using Charwiz brain."""
        try:
            from owlmind.llm.router import get_provider

            provider = get_provider()
            employees_list = "\n".join(
                [f"- {e['name']}: {e.get('status', 'свободен')}" for e in req.employees]
            )

            prompt = f"""Ты — Charwiz, ИИ-директор. Построй план для команды.

СОТРУДНИКИ:
{employees_list}

СТАТУС КОМАНДЫ:
{req.team_status}

ПАМЯТЬ (прошлые указания):
{req.memory}

Разбей на конкретные задачи для каждого сотрудника.
Ответь JSON: {{"tasks": [{{"employee_name": "Имя", "title": "Задача", "description": "Описание", "priority": "high", "deadline_hours": 8}}], "goals_understood": "...", "boss_recommendations": "..."}}"""

            result = await provider.chat(
                messages=[
                    {"role": "system", "content": prompt},
                    {"role": "user", "content": req.boss_input},
                ],
                max_tokens=4000,
            )

            import json
            import re
            text = result.content if hasattr(result, 'content') else str(result)
            # Extract JSON
            match = re.search(r'\{.*\}', text, re.DOTALL)
            data = json.loads(match.group(0)) if match else {"tasks": []}

            return SofiyaResponse(success=True, data=data)
        except Exception as e:
            logger.error(f"Plan error: {e}")
            return SofiyaResponse(success=False, error=str(e))

    @router.post("/analyze", response_model=SofiyaResponse)
    async def analyze_document(req: AnalyzeRequest):
        """Analyze a document/text using Charwiz brain."""
        try:
            from owlmind.llm.router import get_provider

            provider = get_provider()
            result = await provider.chat(
                messages=[
                    {"role": "system", "content": "Ты — Charwiz. Проанализируй документ. Выдели цели, ключевые пункты, дедлайны. Ответь JSON."},
                    {"role": "user", "content": req.text[:15000]},
                ],
                max_tokens=2000,
            )
            text = result.content if hasattr(result, 'content') else str(result)

            import json
            import re
            match = re.search(r'\{.*\}', text, re.DOTALL)
            data = json.loads(match.group(0)) if match else {"summary": text}

            return SofiyaResponse(success=True, data=data)
        except Exception as e:
            return SofiyaResponse(success=False, error=str(e))

    @router.post("/chat", response_model=SofiyaResponse)
    async def smart_chat(req: ChatRequest):
        """Smart employee chat using Charwiz brain."""
        try:
            from owlmind.llm.router import get_provider

            provider = get_provider()

            lang_map = {"ru": "русском", "tj": "таджикском", "uz": "узбекском", "zh": "китайском", "en": "английском"}
            lang_instr = f"Отвечай на {lang_map.get(req.language, 'русском')} языке."

            system = f"""Ты — Charwiz, строгий ИИ-руководитель сотрудника {req.employee_name}.
ЗАДАЧИ: {req.tasks_info}
ПРОФИЛЬ: {req.profile}
{lang_instr}
Контролируй выполнение задач босса. Требуй доказательства. Не уходи от целей."""

            messages = [{"role": "system", "content": system}]
            messages.extend(req.history[-10:])
            messages.append({"role": "user", "content": req.message})

            result = await provider.chat(messages=messages, max_tokens=1000)
            text = result.content if hasattr(result, 'content') else str(result)

            return SofiyaResponse(success=True, data={"response": text})
        except Exception as e:
            return SofiyaResponse(success=False, error=str(e))

    @router.post("/memory", response_model=SofiyaResponse)
    async def memory_ops(req: MemoryRequest):
        """Memory operations via Charwiz brain."""
        try:
            if not memory_db:
                return SofiyaResponse(success=False, error="Memory not configured")

            from owlmind.memory import MemoryStore
            store = MemoryStore(str(memory_db))

            if req.action == "save":
                store.add(req.content, tags=[req.category])
                return SofiyaResponse(success=True, data={"saved": True})
            elif req.action == "search":
                results = store.search(req.query, top_k=5)
                return SofiyaResponse(success=True, data={"results": [r.text for r in results]})
            else:
                return SofiyaResponse(success=False, error=f"Unknown action: {req.action}")
        except Exception as e:
            return SofiyaResponse(success=False, error=str(e))

    @router.get("/health")
    async def sofiya_health():
        return {"status": "ok", "service": "charwiz-sofiya-bridge"}

    return router
