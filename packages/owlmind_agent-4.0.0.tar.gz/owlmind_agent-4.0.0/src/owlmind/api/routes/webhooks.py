"""Webhook endpoints for GitLab and Bitbucket MR events.

Receives webhook events, reads ``.owlmind.yaml`` from the repo,
and creates a OWLMIND session with the configured goals.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Header, HTTPException, Request, status

logger = logging.getLogger(__name__)


def make_webhooks_router(
    sessions_dir: str | Path | None = None,
    webhook_secret: str = "",
) -> APIRouter:
    """Create webhook router for VCS platforms.

    Args:
        sessions_dir: Directory for session storage (for creating sessions).
        webhook_secret: Optional secret for verifying webhook signatures.
    """
    router = APIRouter(prefix="/api/v1/webhooks", tags=["webhooks"])

    # ── GitLab webhook ──────────────────────────────────────────────

    @router.post("/gitlab")
    async def gitlab_webhook(
        request: Request,
        x_gitlab_token: str | None = Header(None),
        x_gitlab_event: str | None = Header(None),
    ) -> dict[str, Any]:
        """Receive GitLab webhook events (merge request events).

        Validates the secret token (if configured), extracts MR information,
        and queues a OWLMIND review session.
        """
        # Verify secret token
        if webhook_secret and x_gitlab_token != webhook_secret:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Invalid webhook token",
            )

        body = await request.json()
        event_type = body.get("object_kind", x_gitlab_event or "")

        if event_type != "merge_request":
            return {"status": "ignored", "reason": f"event type: {event_type}"}

        mr_attrs = body.get("object_attributes", {})
        action = mr_attrs.get("action", "")
        if action not in ("open", "reopen", "update"):
            return {"status": "ignored", "reason": f"action: {action}"}

        project = body.get("project", {})
        repo = project.get("path_with_namespace", "")
        mr_id = mr_attrs.get("iid", 0)
        mr_title = mr_attrs.get("title", "")
        source_branch = mr_attrs.get("source_branch", "")
        sha = mr_attrs.get("last_commit", {}).get("id", "")

        logger.info(
            "GitLab MR webhook: %s !%s (%s) — %s",
            repo,
            mr_id,
            action,
            mr_title,
        )

        return {
            "status": "accepted",
            "vcs_type": "gitlab",
            "repo": repo,
            "mr_id": mr_id,
            "mr_title": mr_title,
            "source_branch": source_branch,
            "sha": sha,
            "action": action,
        }

    # ── Bitbucket webhook ───────────────────────────────────────────

    @router.post("/bitbucket")
    async def bitbucket_webhook(
        request: Request,
        x_event_key: str | None = Header(None),
        x_hub_signature: str | None = Header(None),
    ) -> dict[str, Any]:
        """Receive Bitbucket webhook events (pull request events).

        Validates HMAC signature (if configured), extracts PR information,
        and queues a OWLMIND review session.
        """
        raw_body = await request.body()

        # Verify HMAC signature
        if webhook_secret and x_hub_signature:
            expected = (
                "sha256=" + hmac.new(webhook_secret.encode(), raw_body, hashlib.sha256).hexdigest()
            )
            if not hmac.compare_digest(expected, x_hub_signature):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Invalid webhook signature",
                )

        body = json.loads(raw_body)
        event_key = x_event_key or ""

        if not event_key.startswith("pullrequest:"):
            return {"status": "ignored", "reason": f"event: {event_key}"}

        action = event_key.split(":")[-1] if ":" in event_key else ""
        if action not in ("created", "updated"):
            return {"status": "ignored", "reason": f"action: {action}"}

        pr_data = body.get("pullrequest", {})
        repo_data = body.get("repository", {})
        repo = repo_data.get("full_name", "")
        mr_id = pr_data.get("id", 0)
        mr_title = pr_data.get("title", "")
        source_branch = pr_data.get("source", {}).get("branch", {}).get("name", "")
        sha = pr_data.get("source", {}).get("commit", {}).get("hash", "")

        logger.info(
            "Bitbucket PR webhook: %s #%s (%s) — %s",
            repo,
            mr_id,
            action,
            mr_title,
        )

        return {
            "status": "accepted",
            "vcs_type": "bitbucket",
            "repo": repo,
            "mr_id": mr_id,
            "mr_title": mr_title,
            "source_branch": source_branch,
            "sha": sha,
            "action": action,
        }

    return router
