"""Run management endpoints."""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from owlmind.api.auth import verify_api_key

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Request / Response schemas
# ---------------------------------------------------------------------------


class RunCreateRequest(BaseModel):
    """Request body for creating a new run."""

    goal: str = Field(..., min_length=1, description="The goal for this run")
    workspace: str = Field(default=".", description="Working directory")


class RunSummary(BaseModel):
    """Compact run summary returned in list endpoints."""

    run_id: str
    state: str = "unknown"
    goal: str = ""
    iteration: int | None = None
    created_at: str = ""
    updated_at: str = ""


class RunDetail(BaseModel):
    """Full run detail."""

    run_id: str
    state: str = "unknown"
    goal: str = ""
    workspace: str = ""
    iteration: int | None = None
    max_steps: int | None = None
    created_at: str = ""
    updated_at: str = ""
    meta: dict[str, Any] = Field(default_factory=dict)


class RunCreateResponse(BaseModel):
    """Response after creating a new run."""

    run_id: str
    state: str
    goal: str


class FileDiffResponse(BaseModel):
    """Single file diff in a diff-review response."""

    path: str
    diff_text: str
    risk_level: str = "low"


class DiffReviewResponse(BaseModel):
    """Response for the diff-review endpoint."""

    run_id: str
    diffs: list[FileDiffResponse]
    total_files: int = 0
    high_risk: int = 0
    medium_risk: int = 0
    low_risk: int = 0


class PartialApproveRequest(BaseModel):
    """Request body for partial approval."""

    approved_files: list[str] = Field(default_factory=list)
    rejected_files: list[str] = Field(default_factory=list)


class PartialApproveResponse(BaseModel):
    """Response for partial approval."""

    run_id: str
    applied_files: list[str] = Field(default_factory=list)
    rejected_files: list[str] = Field(default_factory=list)
    errors: list[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Router factory
# ---------------------------------------------------------------------------


def make_runs_router(runs_dir: Path, policies_dir: Path) -> APIRouter:
    """Create runs router with injected paths."""
    router = APIRouter(
        prefix="/api/v1/runs",
        tags=["runs"],
        dependencies=[Depends(verify_api_key)],
    )

    def _read_cycle_meta(run_path: Path) -> dict[str, Any] | None:
        """Read cycle_meta.json from a run directory."""
        meta_path = run_path / "cycle_meta.json"
        if not meta_path.exists():
            return None
        try:
            return json.loads(meta_path.read_text())  # type: ignore[no-any-return]
        except (json.JSONDecodeError, OSError):
            return None

    @router.get("", response_model=list[RunSummary])
    async def list_runs() -> list[dict[str, Any]]:
        """List all runs from the runs directory."""
        if not runs_dir.is_dir():
            return []

        results: list[dict[str, Any]] = []
        for run_path in sorted(runs_dir.iterdir(), reverse=True):
            if not run_path.is_dir():
                continue
            meta = _read_cycle_meta(run_path)
            if meta is None:
                continue
            results.append(
                {
                    "run_id": meta.get("run_id", run_path.name),
                    "state": meta.get("state", "unknown"),
                    "goal": meta.get("goal", ""),
                    "iteration": meta.get("iteration"),
                    "created_at": meta.get("created_at", ""),
                    "updated_at": meta.get("updated_at", ""),
                }
            )

        return results

    @router.get("/live")
    async def stream_all_runs_live() -> StreamingResponse:
        """SSE stream: broadcasts events for ALL runs (global dashboard feed)."""

        async def _generate() -> Any:
            positions: dict[str, int] = {}
            deadline = asyncio.get_event_loop().time() + 600  # 10 min max
            while asyncio.get_event_loop().time() < deadline:
                if runs_dir.exists():
                    for run_path in runs_dir.iterdir():
                        if not run_path.is_dir():
                            continue
                        log_path = run_path / "run.jsonl"
                        if not log_path.exists():
                            continue
                        run_id = run_path.name
                        with contextlib.suppress(OSError):
                            text = log_path.read_text()
                            pos = positions.get(run_id, 0)
                            new_text = text[pos:]
                            if new_text.strip():
                                positions[run_id] = len(text)
                                for line in new_text.splitlines():
                                    if line.strip():
                                        try:
                                            event = json.loads(line)
                                        except json.JSONDecodeError:
                                            event = {"raw": line}
                                        event["run_id"] = run_id
                                        yield f"data: {json.dumps(event)}\n\n"
                await asyncio.sleep(2)
            yield 'data: {"event": "stream_closed"}\n\n'

        return StreamingResponse(_generate(), media_type="text/event-stream")

    @router.get("/{run_id}", response_model=RunDetail)
    async def get_run(run_id: str) -> dict[str, Any]:
        """Get detailed information about a single run."""
        run_path = runs_dir / run_id
        meta = _read_cycle_meta(run_path)
        if meta is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Run not found: {run_id}",
            )
        return {
            "run_id": meta.get("run_id", run_id),
            "state": meta.get("state", "unknown"),
            "goal": meta.get("goal", ""),
            "workspace": meta.get("workspace", ""),
            "iteration": meta.get("iteration"),
            "max_steps": meta.get("max_steps"),
            "created_at": meta.get("created_at", ""),
            "updated_at": meta.get("updated_at", ""),
            "meta": meta,
        }

    @router.post("", response_model=RunCreateResponse, status_code=status.HTTP_201_CREATED)
    async def create_run(body: RunCreateRequest) -> dict[str, Any]:
        """Start a new run with the given goal and workspace.

        This uses CycleManager to initialise a run. The run itself is
        not executed synchronously — only the metadata is created.
        """
        try:
            from owlmind.agent.cycle import CycleManager
            from owlmind.evidence import EvidenceStore
            from owlmind.policy import PolicyEngine

            policy = PolicyEngine.from_directory(policies_dir)
            evidence = EvidenceStore(runs_dir)
            mgr = CycleManager(
                evidence=evidence,
                policy=policy,
                policies_dir=policies_dir,
            )
            meta = mgr.start(goal=body.goal, workspace=body.workspace)
            return {
                "run_id": meta.run_id,
                "state": meta.state,
                "goal": body.goal,
            }
        except Exception as exc:
            logger.exception("Failed to create run")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to create run: {exc}",
            ) from exc

    @router.post("/{run_id}/cancel")
    async def cancel_run(run_id: str) -> dict[str, str]:
        """Cancel (mark as CANCELLED) an existing run.

        Writes state=CANCELLED into cycle_meta.json.
        """
        run_path = runs_dir / run_id
        meta_path = run_path / "cycle_meta.json"

        if not meta_path.exists():
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Run not found: {run_id}",
            )

        try:
            meta = json.loads(meta_path.read_text())
            meta["state"] = "CANCELLED"
            meta_path.write_text(json.dumps(meta, indent=2))
        except (json.JSONDecodeError, OSError) as exc:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to cancel run: {exc}",
            ) from exc

        return {"run_id": run_id, "state": "CANCELLED"}

    @router.get("/{run_id}/log")
    async def get_run_log(run_id: str, lines: int = Query(50, ge=1, le=1000)) -> dict[str, Any]:
        log_path = runs_dir / run_id / "run.jsonl"
        if not log_path.exists():
            return {"run_id": run_id, "lines": []}
        try:
            all_lines = log_path.read_text().splitlines()
        except OSError:
            return {"run_id": run_id, "lines": []}
        return {"run_id": run_id, "lines": all_lines[-lines:]}

    @router.get("/{run_id}/events")
    async def stream_run_events(run_id: str) -> StreamingResponse:
        log_path = runs_dir / run_id / "run.jsonl"

        async def _generate() -> Any:
            pos = 0
            deadline = asyncio.get_event_loop().time() + 300  # 5 min max
            while asyncio.get_event_loop().time() < deadline:
                if log_path.exists():
                    with contextlib.suppress(OSError):
                        text = log_path.read_text()
                        new_text = text[pos:]
                        pos = len(text)
                        for line in new_text.splitlines():
                            if line.strip():
                                yield f"data: {line.strip()}\n\n"
                await asyncio.sleep(1)
            yield 'data: {"event": "stream_closed"}\n\n'

        return StreamingResponse(_generate(), media_type="text/event-stream")

    @router.post("/{run_id}/recover")
    async def recover_run(run_id: str) -> dict[str, Any]:
        meta_path = runs_dir / run_id / "cycle_meta.json"
        if not meta_path.exists():
            return {"run_id": run_id, "status": "not_found"}
        import json as _json

        try:
            meta = _json.loads(meta_path.read_text())
            meta["state"] = "CANCELLED"
            meta["stop_reason"] = "manual_recover"
            meta_path.write_text(_json.dumps(meta, indent=2))
        except (OSError, _json.JSONDecodeError) as exc:
            return {"run_id": run_id, "status": "error", "error": str(exc)}
        return {"run_id": run_id, "status": "cancelled"}

    # ------------------------------------------------------------------
    # POST /{run_id}/diff-review  — generate diff preview
    # ------------------------------------------------------------------

    @router.post("/{run_id}/diff-review", response_model=DiffReviewResponse)
    async def diff_review(run_id: str) -> dict[str, Any]:
        """Generate a diff preview for a run's workspace changes.

        Compares the pre-run snapshot against the current workspace state
        and classifies each changed file by risk level.
        """
        run_path = runs_dir / run_id
        meta = _read_cycle_meta(run_path)
        if meta is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Run not found: {run_id}",
            )

        workspace = meta.get("workspace", ".")

        try:
            from owlmind.agent.diff_review import DiffReview

            reviewer = DiffReview()
            diffs = reviewer.generate_diff(workspace=workspace, run_id=run_id)

            diff_responses = [
                {
                    "path": d.path,
                    "diff_text": d.diff_text,
                    "risk_level": d.risk_level,
                }
                for d in diffs
            ]

            high = sum(1 for d in diffs if d.risk_level == "high")
            medium = sum(1 for d in diffs if d.risk_level == "medium")
            low = sum(1 for d in diffs if d.risk_level == "low")

            return {
                "run_id": run_id,
                "diffs": diff_responses,
                "total_files": len(diffs),
                "high_risk": high,
                "medium_risk": medium,
                "low_risk": low,
            }
        except Exception as exc:
            logger.exception("Failed to generate diff review for run %s", run_id)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to generate diff review: {exc}",
            ) from exc

    # ------------------------------------------------------------------
    # POST /{run_id}/partial-approve  — apply partial approval
    # ------------------------------------------------------------------

    @router.post("/{run_id}/partial-approve", response_model=PartialApproveResponse)
    async def partial_approve(run_id: str, body: PartialApproveRequest) -> dict[str, Any]:
        """Apply partial approval: keep approved file changes, revert rejected ones.

        The caller provides two lists of relative file paths. Approved files
        are left as-is; rejected files are reverted to their pre-run state.
        """
        run_path = runs_dir / run_id
        meta = _read_cycle_meta(run_path)
        if meta is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Run not found: {run_id}",
            )

        workspace = meta.get("workspace", ".")

        try:
            from owlmind.agent.diff_review import DiffReview

            reviewer = DiffReview()
            result = reviewer.apply_partial(
                workspace=workspace,
                approved_files=body.approved_files,
                rejected_files=body.rejected_files,
                run_id=run_id,
            )
            return {
                "run_id": run_id,
                "applied_files": result.applied_files,
                "rejected_files": result.rejected_files,
                "errors": result.errors,
            }
        except Exception as exc:
            logger.exception("Failed to apply partial approval for run %s", run_id)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to apply partial approval: {exc}",
            ) from exc

    return router
