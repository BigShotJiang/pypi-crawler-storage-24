"""WebSocket streaming and SSE endpoints for real-time dashboard updates."""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------

_SESSIONS_SUBDIR = "sessions"


class StreamEvent(BaseModel):
    """A single streaming event sent over WebSocket or SSE."""

    event_type: str = Field(..., description="Type of event (e.g. 'log', 'state_change', 'heartbeat')")
    data: dict[str, Any] = Field(default_factory=dict, description="Event payload")
    timestamp: str = Field(
        default_factory=lambda: datetime.now(UTC).isoformat(),
        description="ISO-8601 timestamp",
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _read_jsonl_events(path: Path) -> list[dict[str, Any]]:
    """Read all JSON lines from a file, skipping invalid lines."""
    if not path.exists():
        return []
    events: list[dict[str, Any]] = []
    with contextlib.suppress(OSError):
        for line in path.read_text().splitlines():
            line = line.strip()
            if line:
                try:
                    events.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    return events


def _make_stream_event(event_type: str, data: dict[str, Any] | None = None) -> str:
    """Serialize a StreamEvent to JSON string."""
    evt = StreamEvent(
        event_type=event_type,
        data=data or {},
    )
    return evt.model_dump_json()


# ---------------------------------------------------------------------------
# Router factory
# ---------------------------------------------------------------------------


def make_streaming_router(runs_dir: Path) -> APIRouter:
    """Create the streaming router with WebSocket and SSE endpoints.

    Args:
        runs_dir: Directory containing run artifacts.

    Returns:
        Configured APIRouter with streaming endpoints.
    """
    router = APIRouter(tags=["streaming"])

    sessions_dir = runs_dir.parent / _SESSIONS_SUBDIR

    # ------------------------------------------------------------------
    # WS /api/v1/ws/runs/{run_id}  — real-time run event stream
    # ------------------------------------------------------------------

    @router.websocket("/api/v1/ws/runs/{run_id}")
    async def ws_run_events(websocket: WebSocket, run_id: str) -> None:
        """Stream run events over WebSocket.

        On connect:
        - Sends last 50 events as initial state.
        - Then polls ``run.jsonl`` every 0.5s for new lines.
        - Sends heartbeat pings every 10s.
        - Handles client disconnect gracefully.
        """
        await websocket.accept()

        log_path = runs_dir / run_id / "run.jsonl"

        try:
            # Send initial state (last 50 events)
            initial_events = _read_jsonl_events(log_path)[-50:]
            for evt in initial_events:
                msg = _make_stream_event("log", evt)
                await websocket.send_text(msg)

            # Track file position after initial send
            file_pos = 0
            if log_path.exists():
                with contextlib.suppress(OSError):
                    file_pos = len(log_path.read_text())

            last_heartbeat = time.monotonic()

            # Poll loop
            while True:
                # Check for new events
                if log_path.exists():
                    with contextlib.suppress(OSError):
                        text = log_path.read_text()
                        new_text = text[file_pos:]
                        if new_text.strip():
                            file_pos = len(text)
                            for line in new_text.splitlines():
                                line = line.strip()
                                if line:
                                    try:
                                        event_data = json.loads(line)
                                    except json.JSONDecodeError:
                                        event_data = {"raw": line}
                                    msg = _make_stream_event("log", event_data)
                                    await websocket.send_text(msg)

                # Heartbeat every 10s
                now = time.monotonic()
                if now - last_heartbeat >= 10.0:
                    last_heartbeat = now
                    hb = _make_stream_event("heartbeat", {"run_id": run_id})
                    await websocket.send_text(hb)

                await asyncio.sleep(0.5)

        except WebSocketDisconnect:
            logger.debug("WebSocket client disconnected for run %s", run_id)
        except Exception:
            logger.exception("WebSocket error for run %s", run_id)
            with contextlib.suppress(Exception):
                await websocket.close(code=1011)

    # ------------------------------------------------------------------
    # WS /api/v1/ws/sessions/{session_id}  — session progress stream
    # ------------------------------------------------------------------

    @router.websocket("/api/v1/ws/sessions/{session_id}")
    async def ws_session_progress(websocket: WebSocket, session_id: str) -> None:
        """Stream session progress updates over WebSocket.

        Tracks goal status changes and sends:
        - progress updates (done / total / failed counts)
        - individual goal status change events
        - heartbeat pings every 10s
        """
        await websocket.accept()

        session_path = sessions_dir / session_id
        meta_path = session_path / "session_meta.json"

        try:
            # Track previous goal statuses for change detection
            prev_statuses: dict[str, str] = {}
            last_heartbeat = time.monotonic()

            while True:
                # Read current session state
                if meta_path.exists():
                    with contextlib.suppress(OSError, json.JSONDecodeError):
                        meta = json.loads(meta_path.read_text())
                        goals = meta.get("goals", [])
                        runs = meta.get("runs", [])

                        # Build run status map
                        run_map: dict[str, str] = {}
                        for r in runs:
                            gid = r.get("goal_id", "")
                            if gid:
                                run_map[gid] = r.get("status", "pending")

                        # Compute progress
                        total = len(goals)
                        done = 0
                        failed = 0
                        current_statuses: dict[str, str] = {}

                        for g in goals:
                            gid = g.get("id", "")
                            goal_status = run_map.get(gid, "pending")
                            current_statuses[gid] = goal_status
                            if goal_status in ("done", "completed", "success"):
                                done += 1
                            elif goal_status in ("failed", "error", "cancelled"):
                                failed += 1

                        # Detect status changes
                        for gid, new_status in current_statuses.items():
                            old_status = prev_statuses.get(gid)
                            if old_status is not None and old_status != new_status:
                                change_msg = _make_stream_event(
                                    "goal_status_change",
                                    {
                                        "session_id": session_id,
                                        "goal_id": gid,
                                        "old_status": old_status,
                                        "new_status": new_status,
                                    },
                                )
                                await websocket.send_text(change_msg)

                        # Send progress update if statuses changed or first iteration
                        if current_statuses != prev_statuses:
                            progress_msg = _make_stream_event(
                                "progress",
                                {
                                    "session_id": session_id,
                                    "total": total,
                                    "done": done,
                                    "failed": failed,
                                    "pending": total - done - failed,
                                    "session_status": meta.get("status", "unknown"),
                                },
                            )
                            await websocket.send_text(progress_msg)

                        prev_statuses = current_statuses

                # Heartbeat every 10s
                now = time.monotonic()
                if now - last_heartbeat >= 10.0:
                    last_heartbeat = now
                    hb = _make_stream_event("heartbeat", {"session_id": session_id})
                    await websocket.send_text(hb)

                await asyncio.sleep(0.5)

        except WebSocketDisconnect:
            logger.debug("WebSocket client disconnected for session %s", session_id)
        except Exception:
            logger.exception("WebSocket error for session %s", session_id)
            with contextlib.suppress(Exception):
                await websocket.close(code=1011)

    # ------------------------------------------------------------------
    # GET /api/v1/runs/{run_id}/live  — SSE alternative
    # ------------------------------------------------------------------

    @router.get("/api/v1/runs/{run_id}/live", tags=["runs"])
    async def stream_run_live_sse(run_id: str) -> StreamingResponse:
        """Server-Sent Events stream for a single run.

        Alternative to the WebSocket endpoint for clients that prefer SSE.
        Polls ``run.jsonl`` every 0.5s and sends new events.
        Includes heartbeat comments every 10s to keep the connection alive.
        """
        log_path = runs_dir / run_id / "run.jsonl"

        async def _generate() -> Any:
            file_pos = 0

            # Send initial state (last 50 events)
            initial_events = _read_jsonl_events(log_path)[-50:]
            for evt in initial_events:
                msg = _make_stream_event("log", evt)
                yield f"data: {msg}\n\n"

            if log_path.exists():
                with contextlib.suppress(OSError):
                    file_pos = len(log_path.read_text())

            last_heartbeat = time.monotonic()
            deadline = asyncio.get_event_loop().time() + 600  # 10 min max

            while asyncio.get_event_loop().time() < deadline:
                if log_path.exists():
                    with contextlib.suppress(OSError):
                        text = log_path.read_text()
                        new_text = text[file_pos:]
                        if new_text.strip():
                            file_pos = len(text)
                            for line in new_text.splitlines():
                                line = line.strip()
                                if line:
                                    try:
                                        event_data = json.loads(line)
                                    except json.JSONDecodeError:
                                        event_data = {"raw": line}
                                    msg = _make_stream_event("log", event_data)
                                    yield f"data: {msg}\n\n"

                # Heartbeat every 10s (SSE comment to keep connection alive)
                now = time.monotonic()
                if now - last_heartbeat >= 10.0:
                    last_heartbeat = now
                    hb = _make_stream_event("heartbeat", {"run_id": run_id})
                    yield f"data: {hb}\n\n"

                await asyncio.sleep(0.5)

            yield f'data: {_make_stream_event("stream_closed", {"reason": "timeout"})}\n\n'

        return StreamingResponse(_generate(), media_type="text/event-stream")

    return router
