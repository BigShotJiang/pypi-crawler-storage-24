"""Push notification token registration and sending."""

from __future__ import annotations

import json
import logging
import sqlite3
import urllib.request
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from owlmind.api.auth import verify_api_key

logger = logging.getLogger(__name__)

_PUSH_SCHEMA = """\
CREATE TABLE IF NOT EXISTS push_tokens (
    id         TEXT PRIMARY KEY,
    token      TEXT NOT NULL UNIQUE,
    platform   TEXT NOT NULL DEFAULT 'unknown' CHECK(platform IN ('ios', 'android', 'unknown')),
    user_label TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_push_token ON push_tokens(token);
"""

EXPO_PUSH_URL = "https://exp.host/--/api/v2/push/send"


class RegisterTokenRequest(BaseModel):
    """Request to register a push notification token."""

    token: str = Field(min_length=1, description="Expo push token")
    platform: str = Field(default="unknown", pattern="^(ios|android|unknown)$")


class RegisterTokenResponse(BaseModel):
    """Response after registering a push token."""

    id: str
    token: str
    platform: str
    status: str = "registered"


class PushTokenStore:
    """SQLite-backed push token storage."""

    def __init__(self, db_path: str | Path) -> None:
        self._db_path = str(db_path)
        conn = sqlite3.connect(self._db_path)
        try:
            conn.executescript(_PUSH_SCHEMA)
            conn.commit()
        finally:
            conn.close()

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self._db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        return conn

    def register_token(self, token: str, platform: str, user_label: str = "") -> dict[str, Any]:
        """Register or update a push token. Returns token record."""
        conn = self._conn()
        try:
            # Upsert: if token exists, update platform/label
            existing = conn.execute(
                "SELECT id FROM push_tokens WHERE token = ?", (token,)
            ).fetchone()
            if existing:
                conn.execute(
                    "UPDATE push_tokens SET platform = ?, user_label = ? WHERE token = ?",
                    (platform, user_label, token),
                )
                conn.commit()
                row = conn.execute("SELECT * FROM push_tokens WHERE token = ?", (token,)).fetchone()
                return dict(row)

            token_id = uuid.uuid4().hex[:16]
            now = datetime.now(UTC).isoformat()
            conn.execute(
                "INSERT INTO push_tokens (id, token, platform, user_label, created_at) VALUES (?, ?, ?, ?, ?)",
                (token_id, token, platform, user_label, now),
            )
            conn.commit()
            return {
                "id": token_id,
                "token": token,
                "platform": platform,
                "user_label": user_label,
                "created_at": now,
            }
        finally:
            conn.close()

    def list_tokens(self) -> list[dict[str, Any]]:
        """List all registered push tokens."""
        conn = self._conn()
        try:
            rows = conn.execute("SELECT * FROM push_tokens ORDER BY created_at DESC").fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    def remove_token(self, token: str) -> bool:
        """Remove a push token. Returns True if removed."""
        conn = self._conn()
        try:
            cursor = conn.execute("DELETE FROM push_tokens WHERE token = ?", (token,))
            conn.commit()
            return cursor.rowcount > 0
        finally:
            conn.close()


def send_push_notifications(
    tokens: list[str],
    title: str,
    body: str,
    data: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    """Send push notifications via Expo Push API.

    Args:
        tokens: List of Expo push tokens.
        title: Notification title.
        body: Notification body text.
        data: Optional extra data payload.

    Returns:
        List of response tickets from Expo.
    """
    if not tokens:
        return []

    messages = [
        {
            "to": token,
            "title": title,
            "body": body,
            "sound": "default",
            **({"data": data} if data else {}),
        }
        for token in tokens
    ]

    payload = json.dumps(messages).encode("utf-8")
    req = urllib.request.Request(
        EXPO_PUSH_URL,
        data=payload,
        headers={
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            result = json.loads(resp.read().decode("utf-8"))
            return result.get("data", [])
    except Exception:
        logger.exception("Failed to send push notifications")
        return []


def notify_session_complete(store: PushTokenStore, session_id: str, session_status: str) -> int:
    """Send push notification about session completion to all registered devices.

    Returns:
        Number of notifications sent.
    """
    tokens_data = store.list_tokens()
    if not tokens_data:
        return 0

    tokens = [t["token"] for t in tokens_data]
    status_label = "completed" if session_status in ("DONE", "completed") else session_status
    title = "Session Complete"
    body = f"Session {session_id[:12]}... finished with status: {status_label}"

    results = send_push_notifications(
        tokens=tokens,
        title=title,
        body=body,
        data={"session_id": session_id, "status": session_status},
    )
    return len(results)


def make_push_router(push_db: str | Path | None = None) -> APIRouter:
    """Create push notification router.

    Args:
        push_db: Path to SQLite database for push tokens.
            Defaults to None (push endpoints disabled).
    """
    router = APIRouter(prefix="/api/v1", tags=["push"])

    if push_db is None:
        return router

    store = PushTokenStore(push_db)

    @router.post(
        "/push-token",
        response_model=RegisterTokenResponse,
        status_code=status.HTTP_201_CREATED,
        dependencies=[Depends(verify_api_key)],
    )
    async def register_push_token(req: RegisterTokenRequest) -> dict[str, Any]:
        """Register an Expo push notification token."""
        import asyncio

        result = await asyncio.to_thread(store.register_token, req.token, req.platform)
        return {**result, "status": "registered"}

    @router.get(
        "/push-tokens",
        dependencies=[Depends(verify_api_key)],
    )
    async def list_push_tokens() -> list[dict[str, Any]]:
        """List all registered push tokens (admin)."""
        import asyncio

        return await asyncio.to_thread(store.list_tokens)

    @router.delete(
        "/push-token/{token}",
        dependencies=[Depends(verify_api_key)],
    )
    async def delete_push_token(token: str) -> dict[str, str]:
        """Remove a push token."""
        import asyncio

        removed = await asyncio.to_thread(store.remove_token, token)
        if not removed:
            raise HTTPException(status_code=404, detail="Token not found")
        return {"status": "removed", "token": token}

    return router
