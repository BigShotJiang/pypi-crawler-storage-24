"""Simple API key authentication for the OWLMIND REST API."""

from __future__ import annotations

import os

from fastapi import Depends, HTTPException, Security, status
from fastapi.security import APIKeyHeader

_HEADER = APIKeyHeader(name="X-API-Key", auto_error=False)


def _get_configured_key() -> str | None:
    """Read OWLMIND_API_KEY from environment. Empty/missing means dev mode."""
    return os.environ.get("OWLMIND_API_KEY", "").strip() or None


async def verify_api_key(
    api_key: str | None = Security(_HEADER),
) -> str | None:
    """Dependency that enforces API key auth when OWLMIND_API_KEY is set.

    If no key is configured (dev mode), all requests are allowed.
    """
    configured = _get_configured_key()

    # Dev mode — no key required
    if configured is None:
        return None

    if not api_key or api_key != configured:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Invalid or missing API key",
        )
    return api_key


# Convenience dependency alias
require_auth = Depends(verify_api_key)
