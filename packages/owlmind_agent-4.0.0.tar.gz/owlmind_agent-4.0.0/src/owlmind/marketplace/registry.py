"""Package registry — publish, search, install, and rate skill packs.

Skill packs are directories with at least a ``prompts/`` subfolder and a
``config.yaml`` manifest.  The registry stores metadata in a local SQLite
database and archives packs as versioned ZIP files.
"""

from __future__ import annotations

import json
import shutil
import sqlite3
import zipfile
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import yaml  # type: ignore[import-untyped]

# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass
class PackageMeta:
    """Metadata for a published skill pack."""

    id: str
    name: str
    version: str
    author: str
    description: str = ""
    tags: list[str] = field(default_factory=list)
    downloads: int = 0
    rating: float = 0.0
    created_at: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "version": self.version,
            "author": self.author,
            "description": self.description,
            "tags": self.tags,
            "downloads": self.downloads,
            "rating": self.rating,
            "created_at": self.created_at,
        }

    @classmethod
    def from_row(cls, row: sqlite3.Row | tuple[Any, ...], *, columns: list[str] | None = None) -> PackageMeta:
        """Build from a sqlite3 row."""
        if columns:
            data = dict(zip(columns, row, strict=False))
        elif isinstance(row, sqlite3.Row):
            data = dict(row)
        else:
            # Fallback ordered columns
            cols = [
                "id", "name", "version", "author", "description",
                "tags", "downloads", "rating", "created_at",
            ]
            data = dict(zip(cols, row, strict=False))

        tags_raw = data.get("tags", "")
        if isinstance(tags_raw, str):
            try:
                tags = json.loads(tags_raw) if tags_raw else []
            except json.JSONDecodeError:
                tags = [t.strip() for t in tags_raw.split(",") if t.strip()]
        else:
            tags = list(tags_raw) if tags_raw else []

        return cls(
            id=str(data.get("id", "")),
            name=str(data.get("name", "")),
            version=str(data.get("version", "")),
            author=str(data.get("author", "")),
            description=str(data.get("description", "")),
            tags=tags,
            downloads=int(data.get("downloads", 0)),
            rating=float(data.get("rating", 0.0)),
            created_at=str(data.get("created_at", "")),
        )


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------


class PackageRegistry:
    """SQLite-backed skill pack registry."""

    def __init__(self, db_path: Path) -> None:
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._archives_dir = db_path.parent / "archives"
        self._archives_dir.mkdir(parents=True, exist_ok=True)
        self._ensure_schema()

    # ------------------------------------------------------------------
    # Schema
    # ------------------------------------------------------------------

    def _ensure_schema(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS packages (
                    id          TEXT NOT NULL,
                    name        TEXT NOT NULL,
                    version     TEXT NOT NULL,
                    author      TEXT NOT NULL DEFAULT '',
                    description TEXT NOT NULL DEFAULT '',
                    tags        TEXT NOT NULL DEFAULT '[]',
                    downloads   INTEGER NOT NULL DEFAULT 0,
                    rating      REAL NOT NULL DEFAULT 0.0,
                    created_at  TEXT NOT NULL DEFAULT '',
                    PRIMARY KEY (id, version)
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS ratings (
                    pack_id TEXT NOT NULL,
                    rating  INTEGER NOT NULL,
                    review  TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL DEFAULT '',
                    PRIMARY KEY (pack_id, created_at)
                )
                """
            )

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        return conn

    # ------------------------------------------------------------------
    # Publish
    # ------------------------------------------------------------------

    def publish(self, pack_dir: Path, version: str, author: str) -> PackageMeta:
        """Validate and publish a skill pack directory."""
        self._validate_pack(pack_dir)

        config_path = pack_dir / "config.yaml"
        config = yaml.safe_load(config_path.read_text()) or {}

        pack_id = config.get("id") or pack_dir.name
        name = config.get("name", pack_id)
        description = config.get("description", "")
        tags = config.get("tags", [])
        if isinstance(tags, str):
            tags = [t.strip() for t in tags.split(",") if t.strip()]

        now = datetime.now(tz=UTC).isoformat()

        # Create ZIP archive
        archive_name = f"{pack_id}-{version}.zip"
        archive_path = self._archives_dir / archive_name
        with zipfile.ZipFile(archive_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for file in pack_dir.rglob("*"):
                if file.is_file():
                    zf.write(file, file.relative_to(pack_dir))

        meta = PackageMeta(
            id=pack_id,
            name=name,
            version=version,
            author=author,
            description=description,
            tags=tags,
            downloads=0,
            rating=0.0,
            created_at=now,
        )

        with self._connect() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO packages
                    (id, name, version, author, description, tags, downloads, rating, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    meta.id, meta.name, meta.version, meta.author,
                    meta.description, json.dumps(meta.tags),
                    meta.downloads, meta.rating, meta.created_at,
                ),
            )

        return meta

    # ------------------------------------------------------------------
    # Search
    # ------------------------------------------------------------------

    def search(self, query: str, tags: list[str] | None = None) -> list[PackageMeta]:
        """Search packages by name/description and optional tags."""
        tags = tags or []
        with self._connect() as conn:
            sql = """
                SELECT id, name, version, author, description, tags,
                       downloads, rating, created_at
                FROM packages
                WHERE (name LIKE ? OR description LIKE ? OR id LIKE ?)
            """
            params: list[Any] = [f"%{query}%", f"%{query}%", f"%{query}%"]

            for tag in tags:
                sql += " AND tags LIKE ?"
                params.append(f"%{tag}%")

            sql += " ORDER BY downloads DESC, rating DESC"

            rows = conn.execute(sql, params).fetchall()

        cols = [
            "id", "name", "version", "author", "description",
            "tags", "downloads", "rating", "created_at",
        ]
        return [PackageMeta.from_row(row, columns=cols) for row in rows]

    # ------------------------------------------------------------------
    # Install / Uninstall
    # ------------------------------------------------------------------

    def install(
        self, pack_id: str, version: str = "latest", target_dir: Path | None = None
    ) -> Path:
        """Install a skill pack to *target_dir*."""
        target_dir = target_dir or Path("skill_packs")
        target_dir.mkdir(parents=True, exist_ok=True)

        # Resolve version
        if version == "latest":
            version = self._latest_version(pack_id)

        archive_path = self._archives_dir / f"{pack_id}-{version}.zip"
        if not archive_path.exists():
            msg = f"Archive not found: {archive_path}"
            raise FileNotFoundError(msg)

        dest = target_dir / pack_id
        if dest.exists():
            shutil.rmtree(dest)
        dest.mkdir(parents=True)

        with zipfile.ZipFile(archive_path, "r") as zf:
            zf.extractall(dest)

        # Bump download count
        with self._connect() as conn:
            conn.execute(
                "UPDATE packages SET downloads = downloads + 1 WHERE id = ? AND version = ?",
                (pack_id, version),
            )

        return dest

    def uninstall(self, pack_id: str, target_dir: Path | None = None) -> bool:
        """Remove an installed skill pack."""
        target_dir = target_dir or Path("skill_packs")
        dest = target_dir / pack_id
        if dest.exists():
            shutil.rmtree(dest)
            return True
        return False

    # ------------------------------------------------------------------
    # Listing
    # ------------------------------------------------------------------

    def list_installed(self, target_dir: Path | None = None) -> list[PackageMeta]:
        """List skill packs installed in *target_dir*."""
        target_dir = target_dir or Path("skill_packs")
        results: list[PackageMeta] = []
        if not target_dir.is_dir():
            return results

        for child in sorted(target_dir.iterdir()):
            if not child.is_dir():
                continue
            config_path = child / "config.yaml"
            if not config_path.exists():
                continue
            try:
                config = yaml.safe_load(config_path.read_text()) or {}
            except Exception:
                continue

            tags = config.get("tags", [])
            if isinstance(tags, str):
                tags = [t.strip() for t in tags.split(",") if t.strip()]

            results.append(
                PackageMeta(
                    id=config.get("id", child.name),
                    name=config.get("name", child.name),
                    version=config.get("version", "unknown"),
                    author=config.get("author", ""),
                    description=config.get("description", ""),
                    tags=tags,
                )
            )
        return results

    def list_available(self) -> list[PackageMeta]:
        """List all packages in the registry (latest version per id)."""
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT id, name, version, author, description, tags,
                       downloads, rating, created_at
                FROM packages
                ORDER BY downloads DESC, rating DESC
                """
            ).fetchall()

        cols = [
            "id", "name", "version", "author", "description",
            "tags", "downloads", "rating", "created_at",
        ]

        # Keep only latest version per id
        seen: set[str] = set()
        results: list[PackageMeta] = []
        for row in rows:
            meta = PackageMeta.from_row(row, columns=cols)
            if meta.id not in seen:
                seen.add(meta.id)
                results.append(meta)
        return results

    # ------------------------------------------------------------------
    # Rating
    # ------------------------------------------------------------------

    def rate(self, pack_id: str, rating: int, review: str = "") -> None:
        """Rate a skill pack (1-5)."""
        if rating < 1 or rating > 5:
            msg = "Rating must be between 1 and 5"
            raise ValueError(msg)

        now = datetime.now(tz=UTC).isoformat()
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO ratings (pack_id, rating, review, created_at) VALUES (?, ?, ?, ?)",
                (pack_id, rating, review, now),
            )
            # Recompute average
            row = conn.execute(
                "SELECT AVG(rating) FROM ratings WHERE pack_id = ?",
                (pack_id,),
            ).fetchone()
            avg = float(row[0]) if row and row[0] is not None else 0.0
            conn.execute(
                "UPDATE packages SET rating = ? WHERE id = ?",
                (round(avg, 2), pack_id),
            )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _validate_pack(pack_dir: Path) -> None:
        """Ensure pack has required structure."""
        if not pack_dir.is_dir():
            msg = f"Pack directory does not exist: {pack_dir}"
            raise FileNotFoundError(msg)
        if not (pack_dir / "prompts").is_dir():
            msg = f"Pack missing required 'prompts/' directory: {pack_dir}"
            raise ValueError(msg)
        if not (pack_dir / "config.yaml").is_file():
            msg = f"Pack missing required 'config.yaml': {pack_dir}"
            raise ValueError(msg)

    def _latest_version(self, pack_id: str) -> str:
        """Return the latest version string for a pack."""
        with self._connect() as conn:
            row = conn.execute(
                "SELECT version FROM packages WHERE id = ? ORDER BY created_at DESC LIMIT 1",
                (pack_id,),
            ).fetchone()
        if not row:
            msg = f"Pack not found: {pack_id}"
            raise FileNotFoundError(msg)
        return str(row[0])
