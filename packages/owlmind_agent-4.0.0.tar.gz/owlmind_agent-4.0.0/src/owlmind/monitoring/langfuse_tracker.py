"""Langfuse integration for LLM observability.

Tracks generations, scores, and traces in Langfuse for cost analysis,
prompt debugging, and quality evaluation.  Degrades to no-op when the
``langfuse`` package is not installed or credentials are missing.

Usage::

    from owlmind.monitoring.langfuse_tracker import LangfuseTracker

    tracker = LangfuseTracker()  # reads keys from env
    tracker.track_generation(
        run_id="run-123",
        stage="planner",
        provider="openai",
        model="gpt-4o",
        prompt={"role": "user", "content": "..."},
        response="...",
        tokens={"input": 500, "output": 200},
        cost=0.012,
        latency=1.34,
    )
    tracker.flush()
"""

from __future__ import annotations

import logging
import os
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Try importing Langfuse
# ---------------------------------------------------------------------------

try:
    from langfuse import Langfuse

    HAS_LANGFUSE = True
except ImportError:
    HAS_LANGFUSE = False


def is_langfuse_available() -> bool:
    """Return ``True`` if the langfuse package is installed and importable."""
    return HAS_LANGFUSE


class LangfuseTracker:
    """Thin wrapper around the Langfuse Python SDK.

    All methods are safe to call even when Langfuse is not installed —
    they silently do nothing.
    """

    def __init__(
        self,
        public_key: str = "",
        secret_key: str = "",
        host: str = "",
    ) -> None:
        self._client: Any = None

        if not HAS_LANGFUSE:
            logger.debug("langfuse not installed — tracking disabled")
            return

        pk = public_key or os.environ.get("LANGFUSE_PUBLIC_KEY", "")
        sk = secret_key or os.environ.get("LANGFUSE_SECRET_KEY", "")
        h = host or os.environ.get("LANGFUSE_HOST", "https://cloud.langfuse.com")

        if not pk or not sk:
            logger.debug("Langfuse keys not configured — tracking disabled")
            return

        try:
            self._client = Langfuse(public_key=pk, secret_key=sk, host=h)
            logger.info("Langfuse tracking enabled (host=%s)", h)
        except Exception:
            logger.warning("Failed to initialize Langfuse client", exc_info=True)
            self._client = None

    # ------------------------------------------------------------------
    # Tracking helpers
    # ------------------------------------------------------------------

    def track_generation(
        self,
        run_id: str,
        stage: str,
        provider: str,
        model: str,
        prompt: Any,
        response: Any,
        tokens: dict[str, int] | None = None,
        cost: float | None = None,
        latency: float | None = None,
    ) -> None:
        """Record an LLM generation event in Langfuse.

        Parameters
        ----------
        run_id:
            Unique identifier for the orchestration run.
        stage:
            Pipeline stage — ``"planner"``, ``"worker"``, or ``"judge"``.
        provider:
            LLM provider name (e.g. ``"openai"``).
        model:
            Model identifier (e.g. ``"gpt-4o"``).
        prompt:
            The prompt sent to the model (any serialisable type).
        response:
            The model response (any serialisable type).
        tokens:
            Dict with ``"input"`` and ``"output"`` token counts.
        cost:
            Estimated cost in USD.
        latency:
            Wall-clock latency in seconds.
        """
        if self._client is None:
            return

        try:
            trace = self._client.trace(
                id=run_id,
                name=f"owlmind.{stage}",
                metadata={"provider": provider, "stage": stage},
            )

            usage: dict[str, Any] | None = None
            if tokens:
                usage = {
                    "input": tokens.get("input", 0),
                    "output": tokens.get("output", 0),
                    "total": tokens.get("input", 0) + tokens.get("output", 0),
                }

            trace.generation(
                name=f"{stage}.{provider}.{model}",
                model=model,
                input=prompt,
                output=response,
                usage=usage,
                metadata={
                    "provider": provider,
                    "stage": stage,
                    "cost_usd": cost,
                    "latency_s": latency,
                },
            )
        except Exception:
            logger.warning("Failed to track generation in Langfuse", exc_info=True)

    def track_score(
        self,
        run_id: str,
        name: str,
        value: float,
        comment: str = "",
    ) -> None:
        """Record an evaluation score in Langfuse.

        Parameters
        ----------
        run_id:
            Trace ID to attach the score to.
        name:
            Score name (e.g. ``"judge_confidence"``).
        value:
            Numeric score value.
        comment:
            Optional human-readable comment.
        """
        if self._client is None:
            return

        try:
            self._client.score(
                trace_id=run_id,
                name=name,
                value=value,
                comment=comment or None,
            )
        except Exception:
            logger.warning("Failed to track score in Langfuse", exc_info=True)

    def flush(self) -> None:
        """Flush pending events to Langfuse."""
        if self._client is None:
            return

        try:
            self._client.flush()
        except Exception:
            logger.warning("Failed to flush Langfuse events", exc_info=True)
