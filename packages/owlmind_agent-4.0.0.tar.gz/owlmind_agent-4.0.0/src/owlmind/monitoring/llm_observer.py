"""Unified LLM observability — combines OpenTelemetry tracing and Langfuse tracking.

The :class:`LLMObserver` is designed to be injected into the
:class:`~owlmind.llm.router.LLMRouter` so every LLM call is automatically
instrumented without the router needing to know about tracing backends.

Usage::

    from owlmind.monitoring.llm_observer import LLMObserver

    observer = LLMObserver()
    observer.on_call_start("openai", "planner", request_dict)
    # ... perform LLM call ...
    observer.on_call_end("openai", "planner", response_dict, meta_dict)
"""

from __future__ import annotations

import logging
import time
from collections import defaultdict
from typing import Any

from owlmind.monitoring.langfuse_tracker import LangfuseTracker
from owlmind.monitoring.tracing import get_tracer, trace_llm_call

logger = logging.getLogger(__name__)


class LLMObserver:
    """Observability facade that dispatches to OTel and Langfuse.

    Keeps lightweight in-process aggregate stats so callers can query
    throughput / error rates without an external backend.
    """

    def __init__(
        self,
        *,
        langfuse_tracker: LangfuseTracker | None = None,
        run_id: str = "",
    ) -> None:
        self._langfuse = langfuse_tracker or LangfuseTracker()
        self._run_id = run_id
        self._tracer = get_tracer("owlmind.llm.observer")

        # In-process aggregate counters
        self._stats: dict[str, Any] = {
            "calls_total": 0,
            "calls_success": 0,
            "calls_failed": 0,
            "total_input_tokens": 0,
            "total_output_tokens": 0,
            "total_latency_s": 0.0,
            "by_provider": defaultdict(lambda: {
                "calls": 0,
                "success": 0,
                "failed": 0,
                "input_tokens": 0,
                "output_tokens": 0,
                "latency_s": 0.0,
            }),
            "by_stage": defaultdict(lambda: {
                "calls": 0,
                "success": 0,
                "failed": 0,
            }),
        }

        # Pending call start times keyed by (provider, stage)
        self._pending: dict[tuple[str, str], float] = {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def on_call_start(
        self,
        provider: str,
        stage: str,
        request: dict[str, Any],
    ) -> None:
        """Record the start of an LLM call.

        Parameters
        ----------
        provider:
            Provider name (e.g. ``"openai"``).
        stage:
            Pipeline stage — ``"planner"``, ``"worker"``, ``"judge"``.
        request:
            The request payload being sent to the LLM.
        """
        self._pending[(provider, stage)] = time.monotonic()
        self._stats["calls_total"] += 1
        self._stats["by_provider"][provider]["calls"] += 1
        self._stats["by_stage"][stage]["calls"] += 1

    def on_call_end(
        self,
        provider: str,
        stage: str,
        response: dict[str, Any] | None,
        meta: dict[str, Any],
        error: Exception | None = None,
    ) -> None:
        """Record the end of an LLM call.

        Parameters
        ----------
        provider:
            Provider name.
        stage:
            Pipeline stage.
        response:
            The parsed response dict (``None`` on failure).
        meta:
            Provider metadata dict (model, usage, etc.).
        error:
            Exception if the call failed, ``None`` on success.
        """
        start_time = self._pending.pop((provider, stage), None)
        latency = (time.monotonic() - start_time) if start_time is not None else 0.0

        success = error is None
        model = meta.get("model", "unknown")
        input_tokens = meta.get("input_tokens", 0) or meta.get("usage", {}).get("prompt_tokens", 0)
        output_tokens = meta.get("output_tokens", 0) or meta.get("usage", {}).get("completion_tokens", 0)

        # Update aggregate stats
        if success:
            self._stats["calls_success"] += 1
            self._stats["by_provider"][provider]["success"] += 1
            self._stats["by_stage"][stage]["success"] += 1
        else:
            self._stats["calls_failed"] += 1
            self._stats["by_provider"][provider]["failed"] += 1
            self._stats["by_stage"][stage]["failed"] += 1

        self._stats["total_input_tokens"] += input_tokens
        self._stats["total_output_tokens"] += output_tokens
        self._stats["total_latency_s"] += latency
        self._stats["by_provider"][provider]["input_tokens"] += input_tokens
        self._stats["by_provider"][provider]["output_tokens"] += output_tokens
        self._stats["by_provider"][provider]["latency_s"] += latency

        # --- OTel span ---
        trace_llm_call(
            provider=provider,
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            latency=latency,
            success=success,
            run_id=self._run_id,
            stage=stage,
        )

        # --- Langfuse generation ---
        if success:
            self._langfuse.track_generation(
                run_id=self._run_id or f"anon-{id(self)}",
                stage=stage,
                provider=provider,
                model=model,
                prompt=meta.get("prompt"),
                response=response,
                tokens={"input": input_tokens, "output": output_tokens},
                cost=meta.get("cost"),
                latency=latency,
            )

        if error is not None:
            logger.debug(
                "LLM call failed: provider=%s stage=%s error=%s",
                provider,
                stage,
                error,
            )

    def get_stats(self) -> dict[str, Any]:
        """Return aggregated in-process metrics.

        Returns a plain dict (JSON-serialisable) with counts and totals
        for calls, tokens, latency, broken down by provider and stage.
        """
        # Convert defaultdicts to regular dicts for serialisation
        return {
            "calls_total": self._stats["calls_total"],
            "calls_success": self._stats["calls_success"],
            "calls_failed": self._stats["calls_failed"],
            "total_input_tokens": self._stats["total_input_tokens"],
            "total_output_tokens": self._stats["total_output_tokens"],
            "total_latency_s": round(self._stats["total_latency_s"], 4),
            "by_provider": dict(self._stats["by_provider"]),
            "by_stage": dict(self._stats["by_stage"]),
        }

    def flush(self) -> None:
        """Flush any pending Langfuse events."""
        self._langfuse.flush()
