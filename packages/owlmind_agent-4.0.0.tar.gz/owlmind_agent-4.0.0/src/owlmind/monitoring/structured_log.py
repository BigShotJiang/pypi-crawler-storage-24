"""Structured logging configuration using structlog (optional).

Falls back to the existing ``owlmind.logging_config.JsonFormatter`` when
structlog is not installed, so all code paths work unconditionally.

Usage::

    from owlmind.monitoring.structured_log import configure_structured_logging

    configure_structured_logging(level="INFO", json_format=True)
"""

from __future__ import annotations

import logging
import sys
from typing import Any

try:
    import structlog

    HAS_STRUCTLOG = True
except ImportError:
    HAS_STRUCTLOG = False


def configure_structured_logging(
    *,
    level: str = "WARNING",
    json_format: bool = True,
    stream: Any = None,
) -> None:
    """Set up structured logging for the entire ``owlmind`` namespace.

    When *structlog* is installed:
        - Configures structlog processors (timestamper, log level, JSON renderer)
        - Bridges stdlib logging → structlog for consistent output

    When *structlog* is NOT installed:
        - Falls back to ``owlmind.logging_config.setup_logging()``
    """
    if not HAS_STRUCTLOG:
        from owlmind.logging_config import setup_logging

        setup_logging(level=level, json_format=json_format, stream=stream)
        return

    _stream = stream or sys.stderr
    log_level = getattr(logging, level.upper(), logging.WARNING)

    # Shared processors for both structlog and stdlib
    shared_processors: list[Any] = [
        structlog.contextvars.merge_contextvars,
        structlog.stdlib.add_log_level,
        structlog.stdlib.add_logger_name,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.UnicodeDecoder(),
    ]

    if json_format:
        renderer = structlog.processors.JSONRenderer()
    else:
        renderer = structlog.dev.ConsoleRenderer()

    structlog.configure(
        processors=[
            *shared_processors,
            structlog.stdlib.ProcessorFormatter.wrap_for_formatter,
        ],
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )

    # Configure stdlib handler for "owlmind" namespace
    formatter = structlog.stdlib.ProcessorFormatter(
        processors=[
            structlog.stdlib.ProcessorFormatter.remove_processors_meta,
            renderer,
        ],
    )

    handler = logging.StreamHandler(_stream)
    handler.setFormatter(formatter)

    root = logging.getLogger("owlmind")
    root.handlers.clear()
    root.addHandler(handler)
    root.setLevel(log_level)


def get_logger(name: str) -> Any:
    """Get a logger instance.

    Returns a structlog BoundLogger if structlog is available,
    otherwise a standard logging.Logger.
    """
    if HAS_STRUCTLOG:
        return structlog.get_logger(name)
    return logging.getLogger(name)
