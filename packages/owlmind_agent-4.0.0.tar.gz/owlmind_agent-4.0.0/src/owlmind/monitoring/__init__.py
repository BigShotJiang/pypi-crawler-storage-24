"""Monitoring and observability — Prometheus metrics, structured logging, tracing.

Modules:
    metrics         — Prometheus metric definitions and helpers
    structured_log  — structlog-based structured logging
    middleware      — FastAPI middleware for HTTP metrics
    tracing         — optional OpenTelemetry integration
"""

from __future__ import annotations

from owlmind.monitoring.metrics import (
    HAS_PROMETHEUS,
    api_metrics,
    integration_metrics,
    scheduler_metrics,
    setup_metrics,
    storage_metrics,
    telegram_metrics,
    worker_metrics,
)
from owlmind.monitoring.structured_log import configure_structured_logging

__all__ = [
    "HAS_PROMETHEUS",
    "api_metrics",
    "configure_structured_logging",
    "integration_metrics",
    "scheduler_metrics",
    "setup_metrics",
    "storage_metrics",
    "telegram_metrics",
    "worker_metrics",
]
