"""Optional OpenTelemetry tracing integration.

Enabled when ``OWLMIND_OTEL_ENABLED=true`` (or ``1``) is set AND the
``opentelemetry`` packages are installed.

Usage::

    from owlmind.monitoring.tracing import setup_tracing, get_tracer, traced

    setup_tracing(service_name="owlmind-scheduler")
    tracer = get_tracer("owlmind.scheduler")

    with tracer.start_as_current_span("tick"):
        ...

    @traced(name="compute_plan")
    def compute_plan(goal: str) -> Plan:
        ...
"""

from __future__ import annotations

import functools
import logging
import os
import threading
from collections.abc import Callable, Generator
from contextlib import contextmanager
from typing import Any, TypeVar, cast

logger = logging.getLogger(__name__)

F = TypeVar("F", bound=Callable[..., Any])

_OTEL_ENV = os.environ.get("OWLMIND_OTEL_ENABLED", "").strip().lower()
_OTEL_ENABLED = _OTEL_ENV in ("true", "1", "yes")

try:
    if not _OTEL_ENABLED:
        raise ImportError("Tracing disabled by env")

    from opentelemetry import trace
    from opentelemetry.sdk.resources import Resource
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import (
        BatchSpanProcessor,
        ConsoleSpanExporter,
    )

    HAS_OTEL = True
except ImportError:
    HAS_OTEL = False

try:
    from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import (
        OTLPSpanExporter,
    )

    HAS_OTLP = True
except ImportError:
    HAS_OTLP = False


# ---------------------------------------------------------------------------
# No-op tracer for when OTel is absent
# ---------------------------------------------------------------------------


class _NoOpSpan:
    """Stub span that does nothing."""

    def set_attribute(self, key: str, value: Any) -> None:
        pass

    def set_status(self, status: Any) -> None:
        pass

    def record_exception(self, exc: BaseException) -> None:
        pass

    def end(self) -> None:
        pass

    def __enter__(self) -> _NoOpSpan:
        return self

    def __exit__(self, *args: Any) -> None:
        pass


class _NoOpTracer:
    """Stub tracer that returns no-op spans."""

    @contextmanager
    def start_as_current_span(self, name: str, **kwargs: Any) -> Generator[_NoOpSpan, None, None]:
        yield _NoOpSpan()

    def start_span(self, name: str, **kwargs: Any) -> _NoOpSpan:
        return _NoOpSpan()


_NOOP_TRACER = _NoOpTracer()
_setup_done = False


# ---------------------------------------------------------------------------
# Langfuse optional integration
# ---------------------------------------------------------------------------

_LANGFUSE_ENV = os.environ.get("OWLMIND_LANGFUSE_ENABLED", "").strip().lower()
_LANGFUSE_ENABLED = _LANGFUSE_ENV in ("true", "1", "yes")

try:
    if not _LANGFUSE_ENABLED:
        raise ImportError("Langfuse disabled by env")
    import langfuse as _langfuse_module

    HAS_LANGFUSE = True
except ImportError:
    HAS_LANGFUSE = False


class _NoOpLangfuseSpan:
    """No-op span used when Langfuse is unavailable."""

    def end(self, *, output: Any = None, level: str = "DEFAULT", status_message: str = "") -> None:
        pass

    def __enter__(self) -> _NoOpLangfuseSpan:
        return self

    def __exit__(self, *args: Any) -> None:
        pass


class _LangfuseClient:
    """Lazy singleton wrapper for the Langfuse client."""

    _instance: Any = None
    _lock = threading.Lock()

    @classmethod
    def get(cls) -> Any:
        if not HAS_LANGFUSE:
            return None
        with cls._lock:
            if cls._instance is None:
                cls._instance = _langfuse_module.Langfuse()
            return cls._instance

    @classmethod
    def reset(cls) -> None:
        """Reset client for tests."""
        with cls._lock:
            cls._instance = None


def get_langfuse() -> Any:
    """Return Langfuse client if enabled, else None."""
    return _LangfuseClient.get()


@contextmanager
def langfuse_span(
    trace_id: str,
    name: str,
    *,
    input_data: dict[str, Any] | None = None,
    metadata: dict[str, Any] | None = None,
) -> Generator[Any, None, None]:
    """Context manager yielding a Langfuse span (or no-op if disabled).

    Usage::

        with langfuse_span(run_id, "planner", input_data={"goal": goal}) as span:
            result = do_work()
            span.end(output={"tokens": 42})

    Args:
        trace_id: Unique identifier for the parent trace (usually run_id).
        name: Span name (e.g. "planner", "judge").
        input_data: Dict to record as span input.
        metadata: Additional metadata dict.
    """
    client = get_langfuse()
    if client is None:
        yield _NoOpLangfuseSpan()
        return

    lf_trace = client.trace(id=trace_id, name=f"owlmind_{name}", metadata=metadata or {})
    span = lf_trace.span(name=name, input=input_data or {})
    try:
        yield span
    except Exception as exc:
        span.end(level="ERROR", status_message=str(exc))
        raise
    else:
        span.end()


# ---------------------------------------------------------------------------
# Setup & tracer retrieval
# ---------------------------------------------------------------------------


def setup_tracing(
    service_name: str = "owlmind",
    endpoint: str | None = None,
) -> bool:
    """Initialize OpenTelemetry tracing.

    * If *endpoint* is given and the OTLP exporter is installed, spans are
      sent via gRPC to that collector.
    * Otherwise a ``ConsoleSpanExporter`` is used as fallback.
    * If ``opentelemetry`` is not installed at all, this is a silent no-op.

    Safe to call multiple times -- subsequent calls are ignored.
    """
    global _setup_done

    if _setup_done:
        return True
    _setup_done = True

    if not HAS_OTEL:
        logger.debug("opentelemetry not installed or disabled — tracing off")
        return False

    resource = Resource.create({"service.name": service_name})
    provider = TracerProvider(resource=resource)

    otlp_endpoint = endpoint or os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT", "")

    if otlp_endpoint and HAS_OTLP:
        exporter = OTLPSpanExporter(endpoint=otlp_endpoint, insecure=True)
        provider.add_span_processor(BatchSpanProcessor(exporter))
        logger.info("OTel tracing enabled (OTLP -> %s)", otlp_endpoint)
    else:
        provider.add_span_processor(BatchSpanProcessor(ConsoleSpanExporter()))
        if otlp_endpoint and not HAS_OTLP:
            logger.warning(
                "OTLP exporter not installed — falling back to console exporter"
            )
        else:
            logger.info("OTel tracing enabled (console exporter)")

    trace.set_tracer_provider(provider)
    return True


def get_tracer(name: str = "owlmind") -> Any:
    """Get a tracer instance.

    Returns a real OTel tracer if tracing is set up, otherwise a no-op stub.
    """
    if HAS_OTEL:
        return trace.get_tracer(name)
    return _NOOP_TRACER


# ---------------------------------------------------------------------------
# @traced decorator
# ---------------------------------------------------------------------------


def traced(name: str | None = None) -> Callable[[F], F]:
    """Decorator that wraps a function in an OTel span.

    If *name* is ``None``, the fully-qualified function name is used.

    Example::

        @traced(name="compute_plan")
        def compute_plan(goal: str) -> Plan:
            ...
    """

    def decorator(fn: F) -> F:
        span_name = name or f"{fn.__module__}.{fn.__qualname__}"

        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            tracer = get_tracer(fn.__module__)
            with tracer.start_as_current_span(span_name):
                return fn(*args, **kwargs)

        return cast(F, wrapper)

    return decorator


# ---------------------------------------------------------------------------
# trace_llm_call — record a completed LLM call as a span
# ---------------------------------------------------------------------------


def trace_llm_call(
    provider: str,
    model: str,
    input_tokens: int,
    output_tokens: int,
    latency: float,
    success: bool,
    *,
    run_id: str = "",
    stage: str = "",
) -> None:
    """Record a single LLM call as an OTel span with standard attributes.

    Creates a span with ``owlmind.*`` attributes so traces can be filtered
    and aggregated by provider, model, stage, and run.
    """
    tracer = get_tracer("owlmind.llm")

    with tracer.start_as_current_span("llm.call") as span:
        span.set_attribute("owlmind.provider", provider)
        span.set_attribute("owlmind.model", model)
        span.set_attribute("owlmind.input_tokens", input_tokens)
        span.set_attribute("owlmind.output_tokens", output_tokens)
        span.set_attribute("owlmind.latency_s", latency)
        span.set_attribute("owlmind.success", success)

        if run_id:
            span.set_attribute("owlmind.run_id", run_id)
        if stage:
            span.set_attribute("owlmind.stage", stage)

        if not success and HAS_OTEL:
            from opentelemetry.trace import StatusCode

            span.set_status(StatusCode.ERROR, "LLM call failed")


# ---------------------------------------------------------------------------
# Reset — for tests only
# ---------------------------------------------------------------------------


def reset_tracing() -> None:
    """Reset tracing state — for tests only."""
    global _setup_done
    _setup_done = False
