"""Prometheus metric definitions for OWLMIND services.

All metrics are safe to import even when ``prometheus_client`` is not installed —
they degrade to no-op stubs so instrumented code works unconditionally.

Usage::

    from owlmind.monitoring.metrics import scheduler_metrics, setup_metrics

    setup_metrics()  # call once at startup
    scheduler_metrics.tick_duration.observe(0.42)
    scheduler_metrics.goals_dispatched.inc(3)
"""

from __future__ import annotations

import time
from collections.abc import Generator
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any

try:
    from prometheus_client import REGISTRY as DEFAULT_REGISTRY
    from prometheus_client import (
        Counter,
        Gauge,
        Histogram,
        generate_latest,
    )

    HAS_PROMETHEUS = True
except ImportError:
    HAS_PROMETHEUS = False


# ---------------------------------------------------------------------------
# No-op stubs for when prometheus_client is absent
# ---------------------------------------------------------------------------


class _NoOpMetric:
    """Stub that silently accepts any metric call."""

    def inc(self, amount: float = 1) -> None:
        pass

    def dec(self, amount: float = 1) -> None:
        pass

    def set(self, value: float) -> None:
        pass

    def observe(self, amount: float) -> None:
        pass

    def labels(self, *args: Any, **kwargs: Any) -> _NoOpMetric:
        return self

    @contextmanager
    def time(self) -> Generator[None, None, None]:
        yield


_NOOP = _NoOpMetric()


# ---------------------------------------------------------------------------
# Scheduler metrics
# ---------------------------------------------------------------------------


@dataclass
class SchedulerMetrics:
    """Prometheus metrics for the Scheduler service."""

    tick_duration: Any = field(default_factory=lambda: _NOOP)
    goals_dispatched: Any = field(default_factory=lambda: _NOOP)
    goals_completed: Any = field(default_factory=lambda: _NOOP)
    goals_failed: Any = field(default_factory=lambda: _NOOP)
    goals_stale_reset: Any = field(default_factory=lambda: _NOOP)
    sessions_scanned: Any = field(default_factory=lambda: _NOOP)
    active_sessions: Any = field(default_factory=lambda: _NOOP)
    tick_errors: Any = field(default_factory=lambda: _NOOP)


# ---------------------------------------------------------------------------
# Worker metrics
# ---------------------------------------------------------------------------


@dataclass
class WorkerMetrics:
    """Prometheus metrics for the Worker service."""

    task_duration: Any = field(default_factory=lambda: _NOOP)
    tasks_picked: Any = field(default_factory=lambda: _NOOP)
    tasks_completed: Any = field(default_factory=lambda: _NOOP)
    tasks_failed: Any = field(default_factory=lambda: _NOOP)
    active_tasks: Any = field(default_factory=lambda: _NOOP)
    ticks_total: Any = field(default_factory=lambda: _NOOP)


# ---------------------------------------------------------------------------
# API metrics
# ---------------------------------------------------------------------------


@dataclass
class APIMetrics:
    """Prometheus metrics for the FastAPI service."""

    requests_total: Any = field(default_factory=lambda: _NOOP)
    request_duration: Any = field(default_factory=lambda: _NOOP)
    requests_in_progress: Any = field(default_factory=lambda: _NOOP)


# ---------------------------------------------------------------------------
# Storage / performance metrics
# ---------------------------------------------------------------------------


@dataclass
class StoragePerformanceMetrics:
    """Prometheus metrics for storage operation performance profiling."""

    embedding_duration: Any = field(default_factory=lambda: _NOOP)
    postgres_query_duration: Any = field(default_factory=lambda: _NOOP)
    queue_op_duration: Any = field(default_factory=lambda: _NOOP)
    s3_op_duration: Any = field(default_factory=lambda: _NOOP)
    embedding_cache_hits: Any = field(default_factory=lambda: _NOOP)
    embedding_cache_misses: Any = field(default_factory=lambda: _NOOP)


# ---------------------------------------------------------------------------
# Telegram bot metrics
# ---------------------------------------------------------------------------


@dataclass
class TelegramMetrics:
    """Prometheus metrics for the Telegram bot."""

    commands_total: Any = field(default_factory=lambda: _NOOP)
    command_duration: Any = field(default_factory=lambda: _NOOP)
    errors_total: Any = field(default_factory=lambda: _NOOP)


# ---------------------------------------------------------------------------
# External integration metrics (Jira, Trello, VCS reporters)
# ---------------------------------------------------------------------------


@dataclass
class IntegrationMetrics:
    """Prometheus metrics for external integration API calls."""

    requests_total: Any = field(default_factory=lambda: _NOOP)
    request_duration: Any = field(default_factory=lambda: _NOOP)
    errors_total: Any = field(default_factory=lambda: _NOOP)


# ---------------------------------------------------------------------------
# Singleton instances (populated by setup_metrics())
# ---------------------------------------------------------------------------

scheduler_metrics = SchedulerMetrics()
worker_metrics = WorkerMetrics()
api_metrics = APIMetrics()
storage_metrics = StoragePerformanceMetrics()
telegram_metrics = TelegramMetrics()
integration_metrics = IntegrationMetrics()

_initialized = False


def setup_metrics(registry: Any = None) -> None:
    """Create real Prometheus metrics if the library is available.

    Safe to call multiple times — second+ calls are no-ops.
    Pass a custom *registry* for testing (avoids duplicate registration).
    """
    global _initialized

    if _initialized:
        return
    _initialized = True

    if not HAS_PROMETHEUS:
        return

    reg = registry or DEFAULT_REGISTRY

    # --- Scheduler -----------------------------------------------------------
    scheduler_metrics.tick_duration = Histogram(
        "owlmind_scheduler_tick_duration_seconds",
        "Time spent in one scheduler tick",
        registry=reg,
    )
    scheduler_metrics.goals_dispatched = Counter(
        "owlmind_scheduler_goals_dispatched_total",
        "Total goals dispatched to queue",
        registry=reg,
    )
    scheduler_metrics.goals_completed = Counter(
        "owlmind_scheduler_goals_completed_total",
        "Total goals completed",
        registry=reg,
    )
    scheduler_metrics.goals_failed = Counter(
        "owlmind_scheduler_goals_failed_total",
        "Total goals failed",
        registry=reg,
    )
    scheduler_metrics.goals_stale_reset = Counter(
        "owlmind_scheduler_goals_stale_reset_total",
        "Total stale goals reset to pending",
        registry=reg,
    )
    scheduler_metrics.sessions_scanned = Counter(
        "owlmind_scheduler_sessions_scanned_total",
        "Total sessions scanned",
        registry=reg,
    )
    scheduler_metrics.active_sessions = Gauge(
        "owlmind_scheduler_active_sessions",
        "Currently active RUNNING sessions",
        registry=reg,
    )
    scheduler_metrics.tick_errors = Counter(
        "owlmind_scheduler_tick_errors_total",
        "Total scheduler tick errors",
        registry=reg,
    )

    # --- Worker --------------------------------------------------------------
    worker_metrics.task_duration = Histogram(
        "owlmind_worker_task_duration_seconds",
        "Time spent executing a single task",
        buckets=(1, 5, 10, 30, 60, 120, 300, 600, 1800, 3600),
        registry=reg,
    )
    worker_metrics.tasks_picked = Counter(
        "owlmind_worker_tasks_picked_total",
        "Total tasks picked from queue",
        registry=reg,
    )
    worker_metrics.tasks_completed = Counter(
        "owlmind_worker_tasks_completed_total",
        "Total tasks completed successfully",
        registry=reg,
    )
    worker_metrics.tasks_failed = Counter(
        "owlmind_worker_tasks_failed_total",
        "Total tasks failed",
        registry=reg,
    )
    worker_metrics.active_tasks = Gauge(
        "owlmind_worker_active_tasks",
        "Currently active worker tasks",
        registry=reg,
    )
    worker_metrics.ticks_total = Counter(
        "owlmind_worker_ticks_total",
        "Total worker ticks",
        registry=reg,
    )

    # --- API -----------------------------------------------------------------
    api_metrics.requests_total = Counter(
        "owlmind_api_requests_total",
        "Total HTTP requests",
        ["method", "endpoint", "status_code"],
        registry=reg,
    )
    api_metrics.request_duration = Histogram(
        "owlmind_api_request_duration_seconds",
        "HTTP request duration",
        ["method", "endpoint"],
        registry=reg,
    )
    api_metrics.requests_in_progress = Gauge(
        "owlmind_api_requests_in_progress",
        "HTTP requests currently in progress",
        registry=reg,
    )

    # --- Storage performance -------------------------------------------------
    storage_metrics.embedding_duration = Histogram(
        "owlmind_storage_embedding_duration_seconds",
        "Time spent computing embeddings",
        registry=reg,
    )
    storage_metrics.postgres_query_duration = Histogram(
        "owlmind_storage_postgres_query_duration_seconds",
        "Time spent executing PostgreSQL queries",
        ["operation"],
        registry=reg,
    )
    storage_metrics.queue_op_duration = Histogram(
        "owlmind_storage_queue_op_duration_seconds",
        "Time spent on queue operations (add/get/ack)",
        ["operation", "backend"],
        registry=reg,
    )
    storage_metrics.s3_op_duration = Histogram(
        "owlmind_storage_s3_op_duration_seconds",
        "Time spent on S3 operations (put/get/delete)",
        ["operation"],
        registry=reg,
    )
    storage_metrics.embedding_cache_hits = Counter(
        "owlmind_storage_embedding_cache_hits_total",
        "Total embedding cache hits",
        registry=reg,
    )
    storage_metrics.embedding_cache_misses = Counter(
        "owlmind_storage_embedding_cache_misses_total",
        "Total embedding cache misses",
        registry=reg,
    )

    # --- Telegram bot --------------------------------------------------------
    telegram_metrics.commands_total = Counter(
        "owlmind_telegram_commands_total",
        "Total Telegram commands received",
        ["command", "status"],
        registry=reg,
    )
    telegram_metrics.command_duration = Histogram(
        "owlmind_telegram_command_duration_seconds",
        "Telegram command handler duration",
        ["command"],
        buckets=(0.1, 0.5, 1.0, 2.5, 5.0, 10.0, 30.0),
        registry=reg,
    )
    telegram_metrics.errors_total = Counter(
        "owlmind_telegram_errors_total",
        "Total unhandled Telegram command errors",
        ["command"],
        registry=reg,
    )

    # --- External integrations -----------------------------------------------
    integration_metrics.requests_total = Counter(
        "owlmind_integration_requests_total",
        "Total external integration API requests",
        ["integration", "operation", "status"],
        registry=reg,
    )
    integration_metrics.request_duration = Histogram(
        "owlmind_integration_request_duration_seconds",
        "External integration API request duration",
        ["integration", "operation"],
        buckets=(0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0),
        registry=reg,
    )
    integration_metrics.errors_total = Counter(
        "owlmind_integration_errors_total",
        "Total external integration API errors",
        ["integration", "operation"],
        registry=reg,
    )


def reset_metrics() -> None:
    """Reset singleton state — for tests only."""
    global _initialized
    _initialized = False

    for obj in (
        scheduler_metrics,
        worker_metrics,
        api_metrics,
        storage_metrics,
        telegram_metrics,
        integration_metrics,
    ):
        for fld in obj.__dataclass_fields__:
            setattr(obj, fld, _NOOP)


def get_metrics_text(registry: Any = None) -> str:
    """Return Prometheus text exposition.

    Returns empty string if prometheus_client is not available.
    """
    if not HAS_PROMETHEUS:
        return ""
    reg = registry or DEFAULT_REGISTRY
    return str(generate_latest(reg).decode("utf-8"))


@contextmanager
def track_time(histogram: Any) -> Generator[None, None, None]:
    """Context manager to observe duration on a histogram (works with stubs)."""
    start = time.monotonic()
    try:
        yield
    finally:
        elapsed = time.monotonic() - start
        histogram.observe(elapsed)


@contextmanager
def track_telegram_command(command: str) -> Generator[None, None, None]:
    """Record Telegram command invocation count, duration, and errors (no-op safe).

    Usage::

        async def cmd_help(ctx, update, context):
            with track_telegram_command("help"):
                await update.message.reply_text("Help text")
    """
    start = time.monotonic()
    status = "ok"
    try:
        yield
    except Exception:
        status = "error"
        telegram_metrics.errors_total.labels(command=command).inc()
        raise
    finally:
        elapsed = time.monotonic() - start
        telegram_metrics.commands_total.labels(command=command, status=status).inc()
        telegram_metrics.command_duration.labels(command=command).observe(elapsed)


@contextmanager
def track_integration_request(integration: str, operation: str) -> Generator[None, None, None]:
    """Record external integration API call count, duration, and errors (no-op safe).

    Usage::

        with track_integration_request("jira", "create_issue"):
            result = await self._async_request(...)
    """
    start = time.monotonic()
    status = "ok"
    try:
        yield
    except Exception:
        status = "error"
        integration_metrics.errors_total.labels(integration=integration, operation=operation).inc()
        raise
    finally:
        elapsed = time.monotonic() - start
        integration_metrics.requests_total.labels(
            integration=integration, operation=operation, status=status
        ).inc()
        integration_metrics.request_duration.labels(
            integration=integration, operation=operation
        ).observe(elapsed)
