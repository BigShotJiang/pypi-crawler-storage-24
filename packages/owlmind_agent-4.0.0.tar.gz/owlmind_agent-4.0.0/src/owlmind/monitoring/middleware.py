"""FastAPI middleware for Prometheus HTTP metrics and /metrics endpoint.

Usage::

    from owlmind.monitoring.middleware import add_metrics_middleware

    app = FastAPI()
    add_metrics_middleware(app)  # adds middleware + GET /metrics
"""

from __future__ import annotations

import time
from typing import Any

from owlmind.monitoring.metrics import (
    api_metrics,
    get_metrics_text,
    setup_metrics,
)


def add_metrics_middleware(app: Any, *, registry: Any = None) -> None:
    """Add Prometheus HTTP metrics middleware and ``/metrics`` endpoint.

    Works as no-op when ``prometheus_client`` is not installed (middleware
    still runs but records into no-op stubs, /metrics returns empty text).
    """
    from starlette.middleware.base import BaseHTTPMiddleware
    from starlette.requests import Request
    from starlette.responses import PlainTextResponse, Response

    setup_metrics(registry=registry)

    class PrometheusMiddleware(BaseHTTPMiddleware):
        """Record request count, duration, and in-progress gauge."""

        async def dispatch(self, request: Request, call_next: Any) -> Response:
            method = request.method
            # Normalize path to avoid cardinality explosion
            path = _normalize_path(request.url.path)

            api_metrics.requests_in_progress.inc()
            start = time.monotonic()

            try:
                response = await call_next(request)
            except Exception:
                api_metrics.requests_in_progress.dec()
                api_metrics.requests_total.labels(
                    method=method, endpoint=path, status_code="500"
                ).inc()
                raise

            elapsed = time.monotonic() - start
            status_code = str(response.status_code)

            api_metrics.request_duration.labels(method=method, endpoint=path).observe(elapsed)
            api_metrics.requests_total.labels(
                method=method, endpoint=path, status_code=status_code
            ).inc()
            api_metrics.requests_in_progress.dec()

            return response  # type: ignore[no-any-return]

    app.add_middleware(PrometheusMiddleware)

    @app.get("/metrics", include_in_schema=False)  # type: ignore[untyped-decorator]
    async def metrics_endpoint() -> PlainTextResponse:
        """Prometheus text exposition endpoint."""
        body = get_metrics_text(registry=registry)
        return PlainTextResponse(body, media_type="text/plain; version=0.0.4")


def _normalize_path(path: str) -> str:
    """Collapse variable path segments to reduce label cardinality.

    ``/api/v1/runs/run-abc123`` → ``/api/v1/runs/{id}``
    """
    parts = path.strip("/").split("/")
    normalized: list[str] = []
    for part in parts:
        if _is_variable_segment(part):
            normalized.append("{id}")
        else:
            normalized.append(part)
    return "/" + "/".join(normalized)


def _is_variable_segment(segment: str) -> bool:
    """Heuristic: treat segments that look like IDs as variable."""
    if not segment:
        return False
    # UUIDs, hex IDs, run-xxx, sess-xxx, etc.
    if len(segment) > 20:
        return True
    if segment.startswith(("run-", "sess-", "test-", "imp-", "item-")):
        return True
    # Pure hex/digits
    stripped = segment.replace("-", "")
    return stripped.isdigit() or (
        len(stripped) > 8 and all(c in "0123456789abcdef" for c in stripped)
    )
