"""GitHub PR operations via ``gh`` CLI — approval-gated.

All operations require explicit approval and workspace allowlist.
Designed for safe automation: no force-push, no destructive ops.
"""

from __future__ import annotations

import contextlib
import json
import logging
import shutil
import subprocess
import time
from collections.abc import Iterable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_GH = "gh"


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------


@dataclass
class GhConfig:
    """GitHub/CI operations configuration."""

    allowed_repos: frozenset[str] = field(default_factory=frozenset)
    dry_run: bool = False
    cooldown: float = 2.0


_config = GhConfig()
_last_gh_call: float = 0.0


def configure_gh(
    *,
    allowed_repos: Iterable[str] | None = None,
    dry_run: bool = False,
    cooldown: float = 2.0,
) -> None:
    """Set module-level configuration for gh operations."""
    global _config
    _config = GhConfig(
        allowed_repos=frozenset(allowed_repos) if allowed_repos else frozenset(),
        dry_run=dry_run,
        cooldown=cooldown,
    )


def check_repo_allowed(workspace: str | Path) -> bool:
    """Check if the repo at *workspace* is in the allowlist.

    Returns True if the allowlist is empty (allow all) or if
    the git remote origin URL contains any allowed repo string.
    """
    if not _config.allowed_repos:
        return True
    try:
        result = subprocess.run(
            ["git", "remote", "get-url", "origin"],
            cwd=str(workspace),
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode != 0:
            return False
        remote_url = result.stdout.strip()
        return any(repo in remote_url for repo in _config.allowed_repos)
    except (subprocess.TimeoutExpired, OSError):
        return False


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------


@dataclass
class PRInfo:
    """Pull request information."""

    number: int = 0
    title: str = ""
    state: str = ""
    url: str = ""
    head_branch: str = ""
    base_branch: str = ""
    body: str = ""
    mergeable: str = ""
    additions: int = 0
    deletions: int = 0


@dataclass
class PRCreateResult:
    """Result of PR creation."""

    ok: bool = False
    pr_number: int = 0
    url: str = ""
    error: str = ""


@dataclass
class PRMergeResult:
    """Result of PR merge."""

    ok: bool = False
    merged: bool = False
    error: str = ""


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def is_gh_available() -> bool:
    """Check if ``gh`` CLI is installed and authenticated."""
    if not shutil.which(_GH):
        return False
    try:
        result = subprocess.run(
            [_GH, "auth", "status"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, OSError):
        return False


def _run_gh(
    args: list[str],
    *,
    cwd: str | Path | None = None,
    timeout: int = 30,
) -> subprocess.CompletedProcess[str]:
    """Run gh command with dry-run and rate-limit support."""
    global _last_gh_call
    cmd = [_GH, *args]

    if _config.dry_run:
        logger.info("[DRY-RUN] %s", " ".join(cmd))
        return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")

    now = time.monotonic()
    wait = _config.cooldown - (now - _last_gh_call)
    if _last_gh_call and wait > 0:
        time.sleep(wait)

    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        cwd=cwd,
        timeout=timeout,
    )
    _last_gh_call = time.monotonic()
    return result


# ---------------------------------------------------------------------------
# PR operations
# ---------------------------------------------------------------------------


def pr_list(
    workspace: str,
    *,
    state: str = "open",
    limit: int = 10,
) -> list[dict[str, Any]]:
    """List PRs. Returns list of dicts."""
    result = _run_gh(
        [
            "pr",
            "list",
            "--state",
            state,
            "--limit",
            str(limit),
            "--json",
            "number,title,state,url,headRefName,baseRefName",
        ],
        cwd=workspace,
    )
    if result.returncode != 0:
        logger.warning("gh pr list failed: %s", result.stderr)
        return []
    try:
        prs: list[dict[str, Any]] = json.loads(result.stdout)
    except json.JSONDecodeError:
        return []
    return prs


def pr_view(
    workspace: str,
    pr_number: int,
) -> PRInfo:
    """View a single PR. Returns PRInfo."""
    result = _run_gh(
        [
            "pr",
            "view",
            str(pr_number),
            "--json",
            "number,title,state,url,headRefName,baseRefName,body,mergeable,additions,deletions",
        ],
        cwd=workspace,
    )
    if result.returncode != 0:
        msg = f"gh pr view failed: {result.stderr}"
        raise RuntimeError(msg)

    data = json.loads(result.stdout)
    return PRInfo(
        number=data.get("number", 0),
        title=data.get("title", ""),
        state=data.get("state", ""),
        url=data.get("url", ""),
        head_branch=data.get("headRefName", ""),
        base_branch=data.get("baseRefName", ""),
        body=data.get("body", ""),
        mergeable=data.get("mergeable", ""),
        additions=data.get("additions", 0),
        deletions=data.get("deletions", 0),
    )


def pr_create(
    workspace: str,
    *,
    title: str,
    body: str = "",
    base: str = "",
    head: str = "",
    draft: bool = False,
    approved: bool = False,
) -> PRCreateResult:
    """Create a PR. Requires approved=True for safety."""
    if not approved:
        return PRCreateResult(ok=False, error="PR creation requires explicit approval")
    if not check_repo_allowed(workspace):
        return PRCreateResult(ok=False, error="Repository not in allowlist")

    args = ["pr", "create", "--title", title]
    if body:
        args.extend(["--body", body])
    if base:
        args.extend(["--base", base])
    if head:
        args.extend(["--head", head])
    if draft:
        args.append("--draft")

    result = _run_gh(args, cwd=workspace, timeout=60)
    if result.returncode != 0:
        return PRCreateResult(ok=False, error=result.stderr.strip())

    # Parse URL from stdout
    url = result.stdout.strip()
    pr_number = 0
    if "/" in url:
        with contextlib.suppress(ValueError):
            pr_number = int(url.rstrip("/").split("/")[-1])

    return PRCreateResult(ok=True, pr_number=pr_number, url=url)


def pr_merge(
    workspace: str,
    pr_number: int,
    *,
    method: str = "squash",
    approved: bool = False,
) -> PRMergeResult:
    """Merge a PR. Requires approved=True for safety.

    method: merge | squash | rebase
    """
    if not approved:
        return PRMergeResult(ok=False, error="PR merge requires explicit approval")
    if not check_repo_allowed(workspace):
        return PRMergeResult(ok=False, error="Repository not in allowlist")

    valid_methods = {"merge", "squash", "rebase"}
    if method not in valid_methods:
        return PRMergeResult(ok=False, error=f"Invalid method: {method}")

    result = _run_gh(
        ["pr", "merge", str(pr_number), f"--{method}", "--auto"],
        cwd=workspace,
        timeout=60,
    )
    if result.returncode != 0:
        return PRMergeResult(ok=False, error=result.stderr.strip())

    return PRMergeResult(ok=True, merged=True)


def pr_diff(workspace: str, pr_number: int) -> str:
    """Get PR diff text."""
    result = _run_gh(
        ["pr", "diff", str(pr_number)],
        cwd=workspace,
        timeout=30,
    )
    if result.returncode != 0:
        msg = f"gh pr diff failed: {result.stderr}"
        raise RuntimeError(msg)
    return result.stdout


def pr_checks(workspace: str, pr_number: int) -> list[dict[str, str]]:
    """Get PR check statuses."""
    result = _run_gh(
        ["pr", "checks", str(pr_number), "--json", "name,state,conclusion"],
        cwd=workspace,
        timeout=30,
    )
    if result.returncode != 0:
        return []
    try:
        checks: list[dict[str, str]] = json.loads(result.stdout)
    except json.JSONDecodeError:
        return []
    return checks
