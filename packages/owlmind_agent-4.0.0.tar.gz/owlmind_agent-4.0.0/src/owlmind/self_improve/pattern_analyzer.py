"""Pattern-based failure analyzer for the self-improvement loop.

Reads run.jsonl history, groups failures by type, computes trends,
and suggests concrete prompt adjustments to reduce recurring failures.
"""

from __future__ import annotations

import json
import logging
import shutil
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------

FAILURE_TYPES = frozenset(
    {
        "timeout",
        "budget_exceeded",
        "judge_rejected",
        "policy_violation",
        "worker_error",
    }
)


@dataclass
class FailurePattern:
    """A recurring failure pattern extracted from run history."""

    type: str
    frequency: int
    trend: str  # "increasing" | "decreasing" | "stable"
    examples: list[dict[str, Any]] = field(default_factory=list)
    first_seen: str = ""
    last_seen: str = ""
    affected_goals: list[str] = field(default_factory=list)


@dataclass
class PromptAdjustment:
    """A suggested change to a prompt file."""

    target_stage: str  # e.g. "planner", "judge", "worker"
    adjustment_type: str  # e.g. "add_constraint", "refine_criteria", "add_example"
    description: str
    before_snippet: str = ""
    after_snippet: str = ""
    confidence: float = 0.0  # 0.0 – 1.0


@dataclass
class ApplyReport:
    """Result of applying prompt adjustments."""

    applied: list[str] = field(default_factory=list)
    skipped: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)


@dataclass
class SelfImproveReport:
    """Full self-improvement analysis report."""

    patterns: list[FailurePattern] = field(default_factory=list)
    adjustments: list[PromptAdjustment] = field(default_factory=list)
    overall_success_rate: float = 0.0
    trend: str = "stable"  # "improving" | "degrading" | "stable"


# ---------------------------------------------------------------------------
# Prompt adjustment mapping
# ---------------------------------------------------------------------------

_ADJUSTMENT_MAP: dict[str, list[PromptAdjustment]] = {
    "judge_rejected": [
        PromptAdjustment(
            target_stage="planner",
            adjustment_type="add_constraint",
            description="Add explicit acceptance criteria to planner prompt",
            before_snippet="# Plan the task",
            after_snippet=(
                "# Plan the task\n"
                "# IMPORTANT: Include explicit acceptance criteria for each step\n"
                "# so the judge can verify completion objectively."
            ),
            confidence=0.8,
        ),
        PromptAdjustment(
            target_stage="judge",
            adjustment_type="refine_criteria",
            description="Clarify judge rubric to reduce false rejections",
            before_snippet="# Evaluate the work",
            after_snippet=(
                "# Evaluate the work\n"
                "# Focus on functional correctness over stylistic preferences.\n"
                "# Only reject if acceptance criteria are clearly unmet."
            ),
            confidence=0.6,
        ),
    ],
    "timeout": [
        PromptAdjustment(
            target_stage="planner",
            adjustment_type="add_constraint",
            description="Instruct planner to break large goals into smaller subtasks",
            before_snippet="# Plan the task",
            after_snippet=(
                "# Plan the task\n"
                "# If the goal is complex, break it into subtasks that each\n"
                "# complete within a single iteration to avoid timeouts."
            ),
            confidence=0.7,
        ),
    ],
    "budget_exceeded": [
        PromptAdjustment(
            target_stage="planner",
            adjustment_type="add_constraint",
            description="Add token-awareness guidance to planner prompt",
            before_snippet="# Plan the task",
            after_snippet=(
                "# Plan the task\n"
                "# Be concise in tool calls and avoid redundant exploration.\n"
                "# Prefer targeted actions to reduce token consumption."
            ),
            confidence=0.7,
        ),
    ],
    "policy_violation": [
        PromptAdjustment(
            target_stage="worker",
            adjustment_type="add_constraint",
            description="Reinforce policy boundaries in worker prompt",
            before_snippet="# Execute the plan",
            after_snippet=(
                "# Execute the plan\n"
                "# CRITICAL: Never execute commands outside the allowed policy.\n"
                "# If a step would violate policy, skip it and report why."
            ),
            confidence=0.9,
        ),
    ],
    "worker_error": [
        PromptAdjustment(
            target_stage="worker",
            adjustment_type="add_example",
            description="Add error-handling guidance to worker prompt",
            before_snippet="# Execute the plan",
            after_snippet=(
                "# Execute the plan\n"
                "# If a command fails, diagnose the error before retrying.\n"
                "# Report the failure clearly instead of looping."
            ),
            confidence=0.6,
        ),
        PromptAdjustment(
            target_stage="planner",
            adjustment_type="add_constraint",
            description="Ask planner to include fallback steps",
            before_snippet="# Plan the task",
            after_snippet=(
                "# Plan the task\n"
                "# Include fallback strategies for steps that may fail."
            ),
            confidence=0.5,
        ),
    ],
}


# ---------------------------------------------------------------------------
# PatternAnalyzer
# ---------------------------------------------------------------------------


class PatternAnalyzer:
    """Analyze run history to find recurring failure patterns and suggest fixes."""

    def __init__(self, runs_dir: Path) -> None:
        self.runs_dir = runs_dir

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def analyze_failures(self, days: int = 30) -> list[FailurePattern]:
        """Read run.jsonl files and group failures by type."""
        records = self._load_records(days)
        if not records:
            return []

        datetime.now(tz=UTC) - timedelta(days=days)

        # Bucket failures by type
        buckets: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for rec in records:
            ftype = self._classify_failure(rec)
            if ftype:
                buckets[ftype].append(rec)

        patterns: list[FailurePattern] = []
        for ftype, examples in buckets.items():
            timestamps = self._extract_timestamps(examples)
            trend = self._compute_trend(timestamps, days)
            goals = list({e.get("goal", "")[:120] for e in examples if e.get("goal")})

            patterns.append(
                FailurePattern(
                    type=ftype,
                    frequency=len(examples),
                    trend=trend,
                    examples=examples[:5],
                    first_seen=min(timestamps).isoformat() if timestamps else "",
                    last_seen=max(timestamps).isoformat() if timestamps else "",
                    affected_goals=goals[:10],
                )
            )

        patterns.sort(key=lambda p: p.frequency, reverse=True)
        return patterns

    def suggest_prompt_adjustments(
        self, patterns: list[FailurePattern]
    ) -> list[PromptAdjustment]:
        """Map failure patterns to concrete prompt adjustments."""
        seen: set[str] = set()
        adjustments: list[PromptAdjustment] = []

        for pattern in patterns:
            candidates = _ADJUSTMENT_MAP.get(pattern.type, [])
            for adj in candidates:
                key = f"{adj.target_stage}:{adj.adjustment_type}:{adj.description}"
                if key in seen:
                    continue
                seen.add(key)

                # Scale confidence by trend
                scaled = adj.confidence
                if pattern.trend == "increasing":
                    scaled = min(1.0, adj.confidence + 0.1)
                elif pattern.trend == "decreasing":
                    scaled = max(0.0, adj.confidence - 0.15)

                adjustments.append(
                    PromptAdjustment(
                        target_stage=adj.target_stage,
                        adjustment_type=adj.adjustment_type,
                        description=adj.description,
                        before_snippet=adj.before_snippet,
                        after_snippet=adj.after_snippet,
                        confidence=round(scaled, 2),
                    )
                )

        adjustments.sort(key=lambda a: a.confidence, reverse=True)
        return adjustments

    def apply_adjustments(
        self, adjustments: list[PromptAdjustment], prompts_dir: Path
    ) -> ApplyReport:
        """Write adjusted prompts to *prompts_dir* with versioning.

        For each adjustment, looks for ``<target_stage>_prompt.md`` in
        *prompts_dir*, creates a versioned backup, and applies the change.
        """
        report = ApplyReport()
        prompts_dir.mkdir(parents=True, exist_ok=True)

        for adj in adjustments:
            prompt_file = prompts_dir / f"{adj.target_stage}_prompt.md"
            if not prompt_file.exists():
                report.skipped.append(
                    f"{prompt_file.name}: file not found"
                )
                continue

            if not adj.before_snippet or not adj.after_snippet:
                report.skipped.append(
                    f"{prompt_file.name}: empty before/after snippet"
                )
                continue

            try:
                content = prompt_file.read_text()
                if adj.before_snippet not in content:
                    report.skipped.append(
                        f"{prompt_file.name}: before_snippet not found in file"
                    )
                    continue

                # Create versioned backup
                ts = datetime.now(tz=UTC).strftime("%Y%m%d%H%M%S")
                backup = prompts_dir / f"{prompt_file.stem}_v{ts}{prompt_file.suffix}"
                shutil.copy2(prompt_file, backup)

                # Apply adjustment
                new_content = content.replace(adj.before_snippet, adj.after_snippet, 1)
                prompt_file.write_text(new_content)

                report.applied.append(
                    f"{prompt_file.name}: {adj.description}"
                )
            except Exception as exc:
                report.errors.append(f"{prompt_file.name}: {exc}")

        return report

    def generate_report(self, days: int = 30) -> SelfImproveReport:
        """Full analysis report with patterns, suggestions, and trends."""
        records = self._load_records(days)
        patterns = self.analyze_failures(days)
        adjustments = self.suggest_prompt_adjustments(patterns)

        # Overall success rate
        total = len(records)
        failures = sum(1 for r in records if self._classify_failure(r) is not None)
        success_rate = (total - failures) / total if total > 0 else 0.0

        # Overall trend: compare first-half vs second-half failure rate
        trend = "stable"
        if total >= 4:
            mid = total // 2
            first_half = records[:mid]
            second_half = records[mid:]
            f1 = sum(1 for r in first_half if self._classify_failure(r)) / len(first_half)
            f2 = sum(1 for r in second_half if self._classify_failure(r)) / len(second_half)
            if f2 < f1 - 0.1:
                trend = "improving"
            elif f2 > f1 + 0.1:
                trend = "degrading"

        return SelfImproveReport(
            patterns=patterns,
            adjustments=adjustments,
            overall_success_rate=round(success_rate, 4),
            trend=trend,
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _load_records(self, days: int) -> list[dict[str, Any]]:
        """Load run records from JSONL files within the time window."""
        cutoff = datetime.now(tz=UTC) - timedelta(days=days)
        records: list[dict[str, Any]] = []

        if not self.runs_dir.is_dir():
            return records

        # Check for top-level run_memory.jsonl (RunMemory format)
        memory_file = self.runs_dir / "run_memory.jsonl"
        if memory_file.exists():
            records.extend(self._parse_jsonl(memory_file, cutoff))

        # Also scan per-run directories for run.jsonl or events.jsonl
        for child in sorted(self.runs_dir.iterdir()):
            if not child.is_dir():
                continue
            for name in ("run.jsonl", "events.jsonl"):
                jf = child / name
                if jf.exists():
                    records.extend(self._parse_jsonl(jf, cutoff))

        return records

    def _parse_jsonl(
        self, path: Path, cutoff: datetime
    ) -> list[dict[str, Any]]:
        """Parse a JSONL file, filtering by timestamp."""
        results: list[dict[str, Any]] = []
        try:
            for line in path.read_text().strip().splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                except json.JSONDecodeError:
                    continue
                ts = self._parse_ts(rec.get("timestamp", ""))
                if ts and ts < cutoff:
                    continue
                results.append(rec)
        except Exception as exc:
            logger.debug("Error reading %s: %s", path, exc)
        return results

    @staticmethod
    def _classify_failure(rec: dict[str, Any]) -> str | None:
        """Classify a run record into a failure type, or None if success."""
        verdict = str(rec.get("verdict", rec.get("judge_verdict", ""))).upper()
        error = str(rec.get("error_details", rec.get("stop_reason", "")))
        event = str(rec.get("event", ""))

        # Explicit verdict checks
        if verdict in ("APPROVED", "DONE", "") and not error:
            return None

        error_lower = error.lower()
        event_lower = event.lower()

        if "timeout" in error_lower or "timed out" in error_lower:
            return "timeout"
        if "budget" in error_lower or "token limit" in error_lower or "budget_exceeded" in error_lower:
            return "budget_exceeded"
        if verdict in ("REJECTED",) or "judge_rejected" in error_lower:
            return "judge_rejected"
        if "policy" in error_lower or "forbidden" in error_lower or "policy_violation" in error_lower:
            return "policy_violation"
        if (
            "worker" in error_lower
            or "worker_error" in event_lower
            or verdict in ("FAILED", "HARD_FAIL")
        ):
            return "worker_error"

        # If there is an error but we could not classify it, call it worker_error
        if error:
            return "worker_error"

        return None

    @staticmethod
    def _parse_ts(raw: str) -> datetime | None:
        """Best-effort ISO timestamp parsing."""
        if not raw:
            return None
        try:
            # Handle both aware and naive ISO strings
            dt = datetime.fromisoformat(raw.replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=UTC)
            return dt
        except (ValueError, TypeError):
            return None

    def _extract_timestamps(self, records: list[dict[str, Any]]) -> list[datetime]:
        """Extract and parse timestamps from a list of records."""
        timestamps: list[datetime] = []
        for rec in records:
            ts = self._parse_ts(rec.get("timestamp", ""))
            if ts:
                timestamps.append(ts)
        timestamps.sort()
        return timestamps

    @staticmethod
    def _compute_trend(timestamps: list[datetime], days: int) -> str:
        """Determine whether failures are increasing, decreasing, or stable."""
        if len(timestamps) < 2:
            return "stable"

        mid = timestamps[0] + (timestamps[-1] - timestamps[0]) / 2
        first_half = sum(1 for t in timestamps if t <= mid)
        second_half = sum(1 for t in timestamps if t > mid)

        total = first_half + second_half
        if total == 0:
            return "stable"

        ratio = second_half / total
        if ratio > 0.65:
            return "increasing"
        if ratio < 0.35:
            return "decreasing"
        return "stable"
