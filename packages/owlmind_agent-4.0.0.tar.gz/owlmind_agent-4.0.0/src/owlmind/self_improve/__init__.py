"""Self-improvement subsystem — meta-agent for analyzing runs and applying improvements.

Modules:
    legacy      — original run analysis (RunSummary, ImprovementInsight, etc.)
    models      — new data models (RunExtended, AnalysisReport, Improvement, ABTest)
    analyzer    — analyze completed runs and produce AnalysisReport
    generator   — generate improvement proposals from analysis
    ab_testing  — A/B testing framework for validating improvements
    applicator  — apply approved improvements automatically
"""

from __future__ import annotations

# Re-export legacy API for backward compatibility
from owlmind.self_improve.legacy import (
    ImprovementInsight,
    RunSummary,
    analyze_runs,
    format_insights_markdown,
    load_recent_runs,
    save_insights_to_memory,
)

# New models
from owlmind.self_improve.models import (
    ABTest,
    ABTestStatus,
    AnalysisReport,
    Improvement,
    ImprovementStatus,
    RunExtended,
)

__all__ = [
    # Legacy
    "ImprovementInsight",
    "RunSummary",
    "analyze_runs",
    "format_insights_markdown",
    "load_recent_runs",
    "save_insights_to_memory",
    # New
    "ABTest",
    "ABTestStatus",
    "AnalysisReport",
    "Improvement",
    "ImprovementStatus",
    "RunExtended",
]
