"""Data models for the self-improvement subsystem."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

# ---------------------------------------------------------------------------
# RunExtended — enriched run telemetry
# ---------------------------------------------------------------------------


@dataclass
class RunExtended:
    """Extended run metadata for self-improvement analytics."""

    run_id: str
    prompts_used: list[str] = field(default_factory=list)
    commands_executed: list[dict[str, Any]] = field(default_factory=list)
    judge_verdict: str = ""
    llm_usage: dict[str, Any] = field(default_factory=dict)
    duration_ms: int = 0
    error_details: str = ""
    tags: list[str] = field(default_factory=list)
    created_at: str = ""
    updated_at: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "run_id": self.run_id,
            "prompts_used": self.prompts_used,
            "commands_executed": self.commands_executed,
            "judge_verdict": self.judge_verdict,
            "llm_usage": self.llm_usage,
            "duration_ms": self.duration_ms,
            "error_details": self.error_details,
            "tags": self.tags,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> RunExtended:
        return cls(
            run_id=str(data.get("run_id", "")),
            prompts_used=list(data.get("prompts_used", [])),
            commands_executed=list(data.get("commands_executed", [])),
            judge_verdict=str(data.get("judge_verdict", "")),
            llm_usage=dict(data.get("llm_usage", {})),
            duration_ms=int(data.get("duration_ms", 0)),
            error_details=str(data.get("error_details", "")),
            tags=list(data.get("tags", [])),
            created_at=str(data.get("created_at", "")),
            updated_at=str(data.get("updated_at", "")),
        )


# ---------------------------------------------------------------------------
# AnalysisReport — output of the analyzer
# ---------------------------------------------------------------------------


@dataclass
class AnalysisReport:
    """Report produced by analyzing a batch of runs."""

    report_id: str = ""
    runs_analyzed: int = 0
    success_rate: float = 0.0
    avg_duration_ms: float = 0.0
    avg_iterations: float = 0.0
    failure_patterns: list[dict[str, Any]] = field(default_factory=list)
    performance_issues: list[dict[str, Any]] = field(default_factory=list)
    recommendations: list[str] = field(default_factory=list)
    created_at: str = ""

    def __post_init__(self) -> None:
        if not self.report_id:
            self.report_id = f"report-{uuid.uuid4().hex[:8]}"
        if not self.created_at:
            self.created_at = datetime.now(tz=UTC).isoformat()

    def to_dict(self) -> dict[str, Any]:
        return {
            "report_id": self.report_id,
            "runs_analyzed": self.runs_analyzed,
            "success_rate": self.success_rate,
            "avg_duration_ms": self.avg_duration_ms,
            "avg_iterations": self.avg_iterations,
            "failure_patterns": self.failure_patterns,
            "performance_issues": self.performance_issues,
            "recommendations": self.recommendations,
            "created_at": self.created_at,
        }


# ---------------------------------------------------------------------------
# Improvement — a proposed change
# ---------------------------------------------------------------------------


class ImprovementStatus:
    PROPOSED = "proposed"
    TESTING = "testing"
    APPROVED = "approved"
    APPLIED = "applied"
    REJECTED = "rejected"


@dataclass
class Improvement:
    """An improvement proposal generated from analysis."""

    improvement_id: str = ""
    run_id: str = ""
    category: str = ""
    title: str = ""
    description: str = ""
    patch: str = ""
    target_file: str = ""
    status: str = ImprovementStatus.PROPOSED
    confidence: float = 0.0
    ab_test_id: str = ""
    created_at: str = ""
    applied_at: str = ""

    def __post_init__(self) -> None:
        if not self.improvement_id:
            self.improvement_id = f"imp-{uuid.uuid4().hex[:8]}"
        if not self.created_at:
            self.created_at = datetime.now(tz=UTC).isoformat()

    def to_dict(self) -> dict[str, Any]:
        return {
            "improvement_id": self.improvement_id,
            "run_id": self.run_id,
            "category": self.category,
            "title": self.title,
            "description": self.description,
            "patch": self.patch,
            "target_file": self.target_file,
            "status": self.status,
            "confidence": self.confidence,
            "ab_test_id": self.ab_test_id,
            "created_at": self.created_at,
            "applied_at": self.applied_at,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Improvement:
        return cls(
            improvement_id=str(data.get("improvement_id", "")),
            run_id=str(data.get("run_id", "")),
            category=str(data.get("category", "")),
            title=str(data.get("title", "")),
            description=str(data.get("description", "")),
            patch=str(data.get("patch", "")),
            target_file=str(data.get("target_file", "")),
            status=str(data.get("status", ImprovementStatus.PROPOSED)),
            confidence=float(data.get("confidence", 0.0)),
            ab_test_id=str(data.get("ab_test_id", "")),
            created_at=str(data.get("created_at", "")),
            applied_at=str(data.get("applied_at", "")),
        )


# ---------------------------------------------------------------------------
# ABTest — A/B test definition
# ---------------------------------------------------------------------------


class ABTestStatus:
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


@dataclass
class ABTest:
    """A/B test for validating an improvement."""

    test_id: str = ""
    improvement_id: str = ""
    variant_a: str = "baseline"
    variant_b: str = "improved"
    metric: str = "success_rate"
    runs_a: int = 0
    runs_b: int = 0
    score_a: float = 0.0
    score_b: float = 0.0
    status: str = ABTestStatus.PENDING
    winner: str = ""
    min_runs: int = 10
    created_at: str = ""
    completed_at: str = ""

    def __post_init__(self) -> None:
        if not self.test_id:
            self.test_id = f"ab-{uuid.uuid4().hex[:8]}"
        if not self.created_at:
            self.created_at = datetime.now(tz=UTC).isoformat()

    def to_dict(self) -> dict[str, Any]:
        return {
            "test_id": self.test_id,
            "improvement_id": self.improvement_id,
            "variant_a": self.variant_a,
            "variant_b": self.variant_b,
            "metric": self.metric,
            "runs_a": self.runs_a,
            "runs_b": self.runs_b,
            "score_a": self.score_a,
            "score_b": self.score_b,
            "status": self.status,
            "winner": self.winner,
            "min_runs": self.min_runs,
            "created_at": self.created_at,
            "completed_at": self.completed_at,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ABTest:
        return cls(
            test_id=str(data.get("test_id", "")),
            improvement_id=str(data.get("improvement_id", "")),
            variant_a=str(data.get("variant_a", "baseline")),
            variant_b=str(data.get("variant_b", "improved")),
            metric=str(data.get("metric", "success_rate")),
            runs_a=int(data.get("runs_a", 0)),
            runs_b=int(data.get("runs_b", 0)),
            score_a=float(data.get("score_a", 0.0)),
            score_b=float(data.get("score_b", 0.0)),
            status=str(data.get("status", ABTestStatus.PENDING)),
            winner=str(data.get("winner", "")),
            min_runs=int(data.get("min_runs", 10)),
            created_at=str(data.get("created_at", "")),
            completed_at=str(data.get("completed_at", "")),
        )
