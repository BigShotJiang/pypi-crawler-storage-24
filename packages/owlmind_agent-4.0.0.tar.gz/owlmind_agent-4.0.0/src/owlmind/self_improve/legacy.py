"""Self-improvement — analyze completed runs and extract learnings for memory."""

from __future__ import annotations

import contextlib
import json
import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class RunSummary:
    """Summary of a completed run."""

    run_id: str
    goal: str
    workspace: str
    state: str  # DONE, FAILED, BLOCKED
    stop_reason: str
    iterations: int
    steps: int
    created_at: str
    events: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class ImprovementInsight:
    """An extracted insight from run analysis."""

    category: str  # "success_pattern", "failure_pattern", "workspace_hint"
    description: str
    frequency: int = 1
    examples: list[str] = field(default_factory=list)


def load_recent_runs(runs_dir: Path, days: int = 7) -> list[RunSummary]:
    """Load metadata from recent completed runs."""
    summaries = []

    for run_dir in runs_dir.iterdir():
        if not run_dir.is_dir():
            continue
        meta_file = run_dir / "cycle_meta.json"
        if not meta_file.exists():
            continue
        try:
            meta = json.loads(meta_file.read_text())
            state = meta.get("state", "")
            if state not in ("DONE", "FAILED", "BLOCKED", "HARD_FAIL"):
                continue  # skip running/unknown
            # Load events
            events = []
            events_file = run_dir / "events.jsonl"
            if events_file.exists():
                for line in events_file.read_text().splitlines()[:20]:
                    with contextlib.suppress(Exception):
                        events.append(json.loads(line))

            summaries.append(
                RunSummary(
                    run_id=run_dir.name,
                    goal=meta.get("goal", "")[:200],
                    workspace=meta.get("workspace", ""),
                    state=state,
                    stop_reason=meta.get("stop_reason", ""),
                    iterations=meta.get("iteration", 0),
                    steps=meta.get("step", 0),
                    created_at=meta.get("created_at", ""),
                    events=events,
                )
            )
        except Exception as exc:
            logger.debug("Error loading run %s: %s", run_dir.name, exc)

    return sorted(summaries, key=lambda r: r.created_at, reverse=True)


def analyze_runs(runs: list[RunSummary]) -> list[ImprovementInsight]:
    """Analyze runs and extract improvement insights."""
    insights: list[ImprovementInsight] = []
    total = len(runs)
    if not total:
        return insights

    done = [r for r in runs if r.state == "DONE"]
    failed = [r for r in runs if r.state in ("FAILED", "HARD_FAIL")]
    blocked = [r for r in runs if r.state == "BLOCKED"]

    success_rate = len(done) / total * 100

    # Success rate insight
    insights.append(
        ImprovementInsight(
            category="stats",
            description=f"Последние {total} запусков: {len(done)} успешных ({success_rate:.0f}%), {len(failed)} ошибок, {len(blocked)} заблокировано",
            examples=[r.goal[:60] for r in done[:3]],
        )
    )

    # Common failure reasons
    if failed:
        fail_reasons: dict[str, int] = {}
        for r in failed:
            reason = r.stop_reason[:50] if r.stop_reason else "unknown"
            fail_reasons[reason] = fail_reasons.get(reason, 0) + 1
        top_failure = max(fail_reasons, key=lambda k: fail_reasons[k])
        insights.append(
            ImprovementInsight(
                category="failure_pattern",
                description=f"Частая причина ошибок: {top_failure} ({fail_reasons[top_failure]}x)",
                examples=[r.goal[:60] for r in failed[:3]],
            )
        )

    # High-iteration tasks (took many steps — potential optimization)
    if done:
        avg_iter = sum(r.iterations for r in done) / len(done)
        slow_runs = [r for r in done if r.iterations > avg_iter * 2]
        if slow_runs:
            insights.append(
                ImprovementInsight(
                    category="performance",
                    description=f"{len(slow_runs)} задач потребовали > {avg_iter * 2:.0f} итераций — рассмотри разбивку на подзадачи",
                    examples=[r.goal[:60] for r in slow_runs[:2]],
                )
            )

    # Workspace patterns
    workspace_stats: dict[str, dict[str, int]] = {}
    for r in runs:
        ws = r.workspace.split("/")[-1] if r.workspace else "unknown"
        if ws not in workspace_stats:
            workspace_stats[ws] = {"done": 0, "failed": 0}
        if r.state == "DONE":
            workspace_stats[ws]["done"] += 1
        elif r.state in ("FAILED", "HARD_FAIL"):
            workspace_stats[ws]["failed"] += 1

    for ws, stats in workspace_stats.items():
        total_ws = stats["done"] + stats["failed"]
        if total_ws >= 3 and stats["failed"] > stats["done"]:
            insights.append(
                ImprovementInsight(
                    category="workspace_hint",
                    description=f"Workspace '{ws}' имеет много ошибок ({stats['failed']}/{total_ws}) — проверь зависимости",
                    frequency=stats["failed"],
                )
            )

    return insights


def format_insights_markdown(insights: list[ImprovementInsight], days: int = 7) -> str:
    """Format insights as Telegram markdown."""
    if not insights:
        return f"Нет данных для анализа за последние {days} дней."

    lines = [f"Самообучение OWLMIND — анализ за {days} дней:\n"]
    for ins in insights:
        icon = {
            "stats": "📊",
            "success_pattern": "✅",
            "failure_pattern": "⚠️",
            "performance": "⚡",
            "workspace_hint": "📁",
        }.get(ins.category, "•")
        lines.append(f"{icon} {ins.description}")
        if ins.examples:
            for ex in ins.examples[:2]:
                lines.append(f"   → {ex}")

    return "\n".join(lines)


def save_insights_to_memory(insights: list[ImprovementInsight], memory_file: Path) -> None:
    """Append insights to a JSON memory file for cross-run learning."""
    existing = []
    if memory_file.exists():
        try:
            existing = json.loads(memory_file.read_text())
        except Exception:
            existing = []

    new_entries = [
        {
            "timestamp": datetime.now(UTC).isoformat(),
            "category": ins.category,
            "description": ins.description,
            "frequency": ins.frequency,
        }
        for ins in insights
    ]
    existing.extend(new_entries)
    # Keep only last 200 entries
    memory_file.write_text(json.dumps(existing[-200:], indent=2, ensure_ascii=False))
