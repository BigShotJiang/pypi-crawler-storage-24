"""Applicator — apply approved improvements automatically.

Supports:
1. File patch application (unified diff)
2. Policy file updates (append/replace)
3. Dry-run mode for preview
"""

from __future__ import annotations

import logging
import subprocess
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path

from owlmind.self_improve.models import Improvement, ImprovementStatus

logger = logging.getLogger(__name__)


@dataclass
class ApplyResult:
    """Result of applying an improvement."""

    improvement_id: str
    success: bool
    message: str = ""
    dry_run: bool = False
    files_modified: list[str] = field(default_factory=list)


def apply_improvement(
    improvement: Improvement,
    workspace: Path,
    *,
    dry_run: bool = False,
) -> ApplyResult:
    """Apply a single improvement to the workspace.

    If *dry_run* is True, validates the patch but does not write changes.
    """
    if improvement.status not in (ImprovementStatus.APPROVED, ImprovementStatus.TESTING):
        return ApplyResult(
            improvement_id=improvement.improvement_id,
            success=False,
            message=f"Cannot apply improvement with status '{improvement.status}'",
            dry_run=dry_run,
        )

    # If there's a patch, apply it
    if improvement.patch:
        return _apply_patch(improvement, workspace, dry_run=dry_run)

    # If there's a target file and description, create advisory note
    if improvement.target_file:
        return _apply_advisory(improvement, workspace, dry_run=dry_run)

    return ApplyResult(
        improvement_id=improvement.improvement_id,
        success=False,
        message="No patch or target file specified",
        dry_run=dry_run,
    )


def _apply_patch(
    improvement: Improvement,
    workspace: Path,
    *,
    dry_run: bool = False,
) -> ApplyResult:
    """Apply a unified diff patch."""
    patch_text = improvement.patch

    if dry_run:
        # Validate the patch can be applied
        try:
            result = subprocess.run(
                ["patch", "--dry-run", "-p1"],
                input=patch_text,
                capture_output=True,
                text=True,
                cwd=str(workspace),
                timeout=30,
            )
            success = result.returncode == 0
            return ApplyResult(
                improvement_id=improvement.improvement_id,
                success=success,
                message=result.stdout if success else result.stderr,
                dry_run=True,
                files_modified=[improvement.target_file] if improvement.target_file else [],
            )
        except (subprocess.TimeoutExpired, FileNotFoundError) as exc:
            return ApplyResult(
                improvement_id=improvement.improvement_id,
                success=False,
                message=f"Patch validation failed: {exc}",
                dry_run=True,
            )

    # Actually apply
    try:
        result = subprocess.run(
            ["patch", "-p1"],
            input=patch_text,
            capture_output=True,
            text=True,
            cwd=str(workspace),
            timeout=30,
        )
        success = result.returncode == 0
        return ApplyResult(
            improvement_id=improvement.improvement_id,
            success=success,
            message=result.stdout if success else result.stderr,
            dry_run=False,
            files_modified=[improvement.target_file] if improvement.target_file else [],
        )
    except (subprocess.TimeoutExpired, FileNotFoundError) as exc:
        return ApplyResult(
            improvement_id=improvement.improvement_id,
            success=False,
            message=f"Patch application failed: {exc}",
            dry_run=False,
        )


def _apply_advisory(
    improvement: Improvement,
    workspace: Path,
    *,
    dry_run: bool = False,
) -> ApplyResult:
    """Apply an advisory improvement by appending to the target file."""
    target = workspace / improvement.target_file
    advisory = (
        f"\n# Improvement: {improvement.title}\n"
        f"# {improvement.description}\n"
        f"# Applied: {datetime.now(tz=UTC).isoformat()}\n"
    )

    if dry_run:
        return ApplyResult(
            improvement_id=improvement.improvement_id,
            success=True,
            message=f"Would append advisory to {improvement.target_file}",
            dry_run=True,
            files_modified=[improvement.target_file],
        )

    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("a") as f:
            f.write(advisory)
        return ApplyResult(
            improvement_id=improvement.improvement_id,
            success=True,
            message=f"Appended advisory to {improvement.target_file}",
            dry_run=False,
            files_modified=[improvement.target_file],
        )
    except OSError as exc:
        return ApplyResult(
            improvement_id=improvement.improvement_id,
            success=False,
            message=f"Failed to write advisory: {exc}",
            dry_run=False,
        )


def apply_batch(
    improvements: list[Improvement],
    workspace: Path,
    *,
    dry_run: bool = False,
    stop_on_failure: bool = True,
) -> list[ApplyResult]:
    """Apply a batch of improvements in order."""
    results: list[ApplyResult] = []
    for imp in improvements:
        result = apply_improvement(imp, workspace, dry_run=dry_run)
        results.append(result)
        if not result.success and stop_on_failure and not dry_run:
            break
    return results
