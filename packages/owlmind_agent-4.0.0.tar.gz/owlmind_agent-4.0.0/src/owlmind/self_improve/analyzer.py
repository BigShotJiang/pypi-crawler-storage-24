"""Analyzer — analyze completed runs and produce AnalysisReport.

Reads run metadata (cycle_meta.json) and extended telemetry (run_extended.json)
to identify patterns, failures, and performance issues.
"""

from __future__ import annotations

import json
import logging
from collections import Counter
from pathlib import Path
from typing import Any

from owlmind.self_improve.models import AnalysisReport, RunExtended

logger = logging.getLogger(__name__)


def collect_run_extended(runs_dir: Path, run_ids: list[str] | None = None) -> list[RunExtended]:
    """Collect RunExtended data from the runs directory.

    If *run_ids* is ``None``, scans all subdirectories.
    """
    results: list[RunExtended] = []
    if run_ids is not None:
        dirs = [runs_dir / rid for rid in run_ids]
    else:
        dirs = sorted(runs_dir.iterdir()) if runs_dir.is_dir() else []

    for run_dir in dirs:
        if not run_dir.is_dir():
            continue
        ext_file = run_dir / "run_extended.json"
        meta_file = run_dir / "cycle_meta.json"

        ext_data: dict[str, Any] = {}
        if ext_file.exists():
            try:
                ext_data = json.loads(ext_file.read_text())
            except Exception as exc:
                logger.debug("Error reading run_extended for %s: %s", run_dir.name, exc)

        # Fallback: build RunExtended from cycle_meta.json
        if not ext_data and meta_file.exists():
            try:
                meta = json.loads(meta_file.read_text())
                ext_data = _run_extended_from_meta(run_dir.name, meta, run_dir)
            except Exception as exc:
                logger.debug("Error reading cycle_meta for %s: %s", run_dir.name, exc)
                continue

        if ext_data:
            ext_data.setdefault("run_id", run_dir.name)
            results.append(RunExtended.from_dict(ext_data))

    return results


def _run_extended_from_meta(run_id: str, meta: dict[str, Any], run_dir: Path) -> dict[str, Any]:
    """Build RunExtended dict from cycle_meta.json fields."""
    prompts: list[str] = []
    for name in ("planner_prompt.md", "worker_prompt.md", "judge_prompt.md"):
        p = run_dir / "outbox" / name
        if p.exists():
            prompts.append(name)

    commands: list[dict[str, Any]] = []
    inbox_worker = run_dir / "inbox" / "worker_report.json"
    if inbox_worker.exists():
        try:
            wr = json.loads(inbox_worker.read_text())
            for cmd in wr.get("commands_run", []):
                commands.append(
                    {
                        "cmd": cmd.get("cmd", ""),
                        "exit_code": cmd.get("exit_code", -1),
                    }
                )
        except Exception:
            logger.debug("Error parsing worker_report for %s", run_id)

    judge_verdict = ""
    inbox_judge = run_dir / "inbox" / "judge_response.json"
    if inbox_judge.exists():
        try:
            jr = json.loads(inbox_judge.read_text())
            judge_verdict = jr.get("verdict", "")
        except Exception:
            logger.debug("Error parsing judge_response for %s", run_id)

    return {
        "run_id": run_id,
        "prompts_used": prompts,
        "commands_executed": commands,
        "judge_verdict": judge_verdict or meta.get("state", ""),
        "llm_usage": {},
        "duration_ms": 0,
        "error_details": meta.get("stop_reason", "")
        if meta.get("state") in ("FAILED", "HARD_FAIL")
        else "",
        "tags": [],
        "created_at": str(meta.get("created_at", "")),
    }


def analyze(
    runs: list[RunExtended],
    *,
    min_runs: int = 1,
) -> AnalysisReport:
    """Analyze a batch of RunExtended records and produce an AnalysisReport."""
    report = AnalysisReport(runs_analyzed=len(runs))

    if len(runs) < min_runs:
        return report

    # Success rate
    verdicts = [r.judge_verdict.upper() for r in runs if r.judge_verdict]
    done_count = sum(1 for v in verdicts if v in ("APPROVED", "DONE"))
    failed_count = sum(1 for v in verdicts if v in ("REJECTED", "FAILED", "HARD_FAIL"))
    total_decided = done_count + failed_count
    if total_decided > 0:
        report.success_rate = done_count / total_decided

    # Average duration
    durations = [r.duration_ms for r in runs if r.duration_ms > 0]
    if durations:
        report.avg_duration_ms = sum(durations) / len(durations)

    # Failure patterns
    error_counter: Counter[str] = Counter()
    for r in runs:
        if r.error_details:
            # Normalize error to first 80 chars
            key = r.error_details[:80].strip()
            error_counter[key] += 1

    for error_text, count in error_counter.most_common(5):
        report.failure_patterns.append({"error": error_text, "count": count})

    # Performance issues — runs with 0 commands or excessive commands
    cmd_counts = [len(r.commands_executed) for r in runs]
    if cmd_counts:
        avg_cmds = sum(cmd_counts) / len(cmd_counts)
        heavy = [r for r in runs if len(r.commands_executed) > avg_cmds * 2.5 and avg_cmds > 0]
        if heavy:
            report.performance_issues.append(
                {
                    "issue": "excessive_commands",
                    "description": f"{len(heavy)} runs executed >2.5x average commands ({avg_cmds:.0f})",
                    "run_ids": [r.run_id for r in heavy[:5]],
                }
            )

    # Slow runs
    if durations:
        avg_dur = sum(durations) / len(durations)
        slow = [r for r in runs if r.duration_ms > avg_dur * 3 and avg_dur > 0]
        if slow:
            report.performance_issues.append(
                {
                    "issue": "slow_runs",
                    "description": f"{len(slow)} runs took >3x average duration ({avg_dur:.0f}ms)",
                    "run_ids": [r.run_id for r in slow[:5]],
                }
            )

    # Command failure patterns
    failed_cmds: Counter[str] = Counter()
    for r in runs:
        for cmd in r.commands_executed:
            if cmd.get("exit_code", 0) != 0:
                failed_cmds[cmd.get("cmd", "unknown")[:60]] += 1

    if failed_cmds:
        top_failed = failed_cmds.most_common(3)
        for cmd_text, count in top_failed:
            report.failure_patterns.append({"error": f"Command failed: {cmd_text}", "count": count})

    # Recommendations
    if report.success_rate < 0.5 and total_decided >= 3:
        report.recommendations.append(
            "Low success rate — consider improving planner prompts or adding constraints"
        )
    if failed_cmds:
        report.recommendations.append(
            f"Top failing command: {failed_cmds.most_common(1)[0][0]} — review workspace setup"
        )
    if report.performance_issues:
        report.recommendations.append(
            "Performance issues detected — consider breaking large goals into subgoals"
        )

    return report


def save_run_extended(runs_dir: Path, extended: RunExtended) -> None:
    """Persist RunExtended data to ``runs/<run_id>/run_extended.json``."""
    run_dir = runs_dir / extended.run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    out = run_dir / "run_extended.json"
    out.write_text(json.dumps(extended.to_dict(), indent=2, default=str))
