"""A/B testing framework for validating improvement proposals.

Manages test lifecycle: create → collect runs → evaluate → decide winner.
"""

from __future__ import annotations

import json
import logging
from datetime import UTC, datetime
from pathlib import Path

from owlmind.self_improve.models import ABTest, ABTestStatus

logger = logging.getLogger(__name__)


class ABTestScheduler:
    """Manages A/B tests for improvement validation.

    Each test compares a baseline (variant_a) against an improvement (variant_b)
    by tracking run outcomes for each variant.
    """

    def __init__(self, base_dir: Path) -> None:
        self._dir = Path(base_dir)
        self._dir.mkdir(parents=True, exist_ok=True)

    def create_test(
        self,
        improvement_id: str,
        *,
        metric: str = "success_rate",
        min_runs: int = 10,
    ) -> ABTest:
        """Create a new A/B test for an improvement."""
        test = ABTest(
            improvement_id=improvement_id,
            metric=metric,
            min_runs=min_runs,
            status=ABTestStatus.PENDING,
        )
        self._save(test)
        return test

    def start_test(self, test_id: str) -> ABTest | None:
        """Transition a test from PENDING to RUNNING."""
        test = self.get_test(test_id)
        if test is None or test.status != ABTestStatus.PENDING:
            return None
        test.status = ABTestStatus.RUNNING
        self._save(test)
        return test

    def record_result(
        self,
        test_id: str,
        variant: str,
        *,
        success: bool,
    ) -> ABTest | None:
        """Record a run result for a variant.

        Args:
            test_id: The A/B test ID.
            variant: ``"a"`` or ``"b"``.
            success: Whether the run succeeded.
        """
        test = self.get_test(test_id)
        if test is None or test.status != ABTestStatus.RUNNING:
            return None

        if variant == "a":
            test.runs_a += 1
            if success:
                test.score_a += 1.0
        elif variant == "b":
            test.runs_b += 1
            if success:
                test.score_b += 1.0
        else:
            logger.warning("Unknown variant %r for test %s", variant, test_id)
            return test

        # Auto-evaluate if min_runs reached
        if test.runs_a >= test.min_runs and test.runs_b >= test.min_runs:
            self._evaluate(test)

        self._save(test)
        return test

    def evaluate(self, test_id: str) -> ABTest | None:
        """Manually evaluate a test and determine the winner."""
        test = self.get_test(test_id)
        if test is None:
            return None
        self._evaluate(test)
        self._save(test)
        return test

    def cancel_test(self, test_id: str) -> ABTest | None:
        """Cancel a running test."""
        test = self.get_test(test_id)
        if test is None:
            return None
        test.status = ABTestStatus.CANCELLED
        self._save(test)
        return test

    def get_test(self, test_id: str) -> ABTest | None:
        """Load a test by ID."""
        path = self._dir / f"{test_id}.json"
        if not path.exists():
            return None
        try:
            data = json.loads(path.read_text())
            return ABTest.from_dict(data)
        except Exception as exc:
            logger.debug("Error loading test %s: %s", test_id, exc)
            return None

    def list_tests(self, *, status: str | None = None) -> list[ABTest]:
        """List all tests, optionally filtered by status."""
        results: list[ABTest] = []
        for f in sorted(self._dir.glob("ab-*.json")):
            try:
                data = json.loads(f.read_text())
                test = ABTest.from_dict(data)
                if status and test.status != status:
                    continue
                results.append(test)
            except Exception as exc:
                logger.debug("Error loading test %s: %s", f.name, exc)
        return results

    def _evaluate(self, test: ABTest) -> None:
        """Determine the winner based on collected scores."""
        rate_a = test.score_a / test.runs_a if test.runs_a > 0 else 0.0
        rate_b = test.score_b / test.runs_b if test.runs_b > 0 else 0.0

        # Require at least some margin (5%) to declare a winner
        margin = 0.05
        if rate_b > rate_a + margin:
            test.winner = "b"
        elif rate_a > rate_b + margin:
            test.winner = "a"
        else:
            test.winner = "tie"

        test.status = ABTestStatus.COMPLETED
        test.completed_at = datetime.now(tz=UTC).isoformat()

    def _save(self, test: ABTest) -> None:
        """Persist a test to disk."""
        path = self._dir / f"{test.test_id}.json"
        path.write_text(json.dumps(test.to_dict(), indent=2, default=str))
