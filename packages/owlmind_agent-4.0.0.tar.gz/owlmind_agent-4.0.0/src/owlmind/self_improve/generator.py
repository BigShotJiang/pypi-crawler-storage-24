"""Generator — produce improvement proposals from analysis reports.

Works in two modes:
1. **Rule-based** (default): pattern-matching on AnalysisReport fields
2. **LLM-assisted** (optional): sends report to LLM for creative proposals
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from owlmind.self_improve.models import (
    AnalysisReport,
    Improvement,
)

logger = logging.getLogger(__name__)


def generate_improvements(
    report: AnalysisReport,
    *,
    max_proposals: int = 10,
) -> list[Improvement]:
    """Generate improvement proposals from an analysis report (rule-based)."""
    proposals: list[Improvement] = []

    # 1. Low success rate → prompt improvement
    if report.success_rate < 0.5 and report.runs_analyzed >= 3:
        proposals.append(
            Improvement(
                category="prompt_tuning",
                title="Improve planner prompt for higher success rate",
                description=(
                    f"Success rate is {report.success_rate:.0%} across "
                    f"{report.runs_analyzed} runs. Consider adding more "
                    f"constraints or examples to the planner prompt."
                ),
                target_file="policies/planner_system.md",
                confidence=min(0.9, 0.5 + (1.0 - report.success_rate) * 0.5),
            )
        )

    # 2. Failure patterns → specific fixes
    for pattern in report.failure_patterns:
        error = pattern.get("error", "")
        count = pattern.get("count", 0)
        if count < 2:
            continue

        category = "error_handling"
        if "command failed" in error.lower():
            category = "workspace_setup"
        elif "timeout" in error.lower():
            category = "performance"

        proposals.append(
            Improvement(
                category=category,
                title=f"Fix recurring error: {error[:60]}",
                description=f"Error occurred {count} times: {error}",
                confidence=min(0.8, 0.3 + count * 0.1),
            )
        )

    # 3. Performance issues → optimization
    for issue in report.performance_issues:
        issue_type = issue.get("issue", "")
        desc = issue.get("description", "")

        if issue_type == "excessive_commands":
            proposals.append(
                Improvement(
                    category="performance",
                    title="Reduce excessive command execution",
                    description=desc,
                    target_file="policies/worker_system.md",
                    confidence=0.6,
                )
            )
        elif issue_type == "slow_runs":
            proposals.append(
                Improvement(
                    category="performance",
                    title="Optimize slow-running goals",
                    description=desc,
                    confidence=0.5,
                )
            )

    # 4. High avg iterations → goal decomposition hint
    if report.avg_iterations > 5 and report.runs_analyzed >= 3:
        proposals.append(
            Improvement(
                category="workflow",
                title="Enable automatic goal decomposition",
                description=(
                    f"Average iterations per run: {report.avg_iterations:.1f}. "
                    f"Consider breaking complex goals into subgoals."
                ),
                confidence=0.4,
            )
        )

    # Sort by confidence descending, limit
    proposals.sort(key=lambda p: -p.confidence)
    return proposals[:max_proposals]


def generate_with_llm(
    report: AnalysisReport,
    *,
    llm_fn: Any | None = None,
    max_proposals: int = 5,
) -> list[Improvement]:
    """Generate improvements using an LLM function.

    *llm_fn* should accept a prompt string and return a response string.
    If not provided, falls back to rule-based generation.
    """
    if llm_fn is None:
        return generate_improvements(report, max_proposals=max_proposals)

    prompt = _build_llm_prompt(report)
    try:
        response = llm_fn(prompt)
        return _parse_llm_response(response, max_proposals=max_proposals)
    except Exception as exc:
        logger.warning("LLM generation failed, falling back to rules: %s", exc)
        return generate_improvements(report, max_proposals=max_proposals)


def _build_llm_prompt(report: AnalysisReport) -> str:
    """Build a prompt for the LLM from an analysis report."""
    return (
        "You are a meta-agent analyzing CI/CD run data. "
        "Based on the following analysis report, suggest concrete improvements.\n\n"
        f"Runs analyzed: {report.runs_analyzed}\n"
        f"Success rate: {report.success_rate:.0%}\n"
        f"Average duration: {report.avg_duration_ms:.0f}ms\n"
        f"Average iterations: {report.avg_iterations:.1f}\n\n"
        f"Failure patterns:\n{json.dumps(report.failure_patterns, indent=2)}\n\n"
        f"Performance issues:\n{json.dumps(report.performance_issues, indent=2)}\n\n"
        "Respond with a JSON array of improvements. Each must have:\n"
        '  {"category": "...", "title": "...", "description": "...", '
        '"target_file": "...", "confidence": 0.0-1.0}\n'
    )


def _parse_llm_response(
    response: str,
    *,
    max_proposals: int = 5,
) -> list[Improvement]:
    """Parse LLM response into Improvement objects."""
    # Try to find JSON array in response
    start = response.find("[")
    end = response.rfind("]")
    if start == -1 or end == -1:
        logger.warning("No JSON array found in LLM response")
        return []

    try:
        items = json.loads(response[start : end + 1])
    except json.JSONDecodeError:
        logger.warning("Failed to parse LLM JSON response")
        return []

    proposals: list[Improvement] = []
    for item in items[:max_proposals]:
        if not isinstance(item, dict):
            continue
        proposals.append(
            Improvement(
                category=str(item.get("category", "llm_suggestion")),
                title=str(item.get("title", ""))[:200],
                description=str(item.get("description", "")),
                target_file=str(item.get("target_file", "")),
                confidence=min(1.0, max(0.0, float(item.get("confidence", 0.5)))),
            )
        )

    return proposals


# ---------------------------------------------------------------------------
# File-based persistence
# ---------------------------------------------------------------------------


class FileImprovementStore:
    """File-based store for improvement proposals."""

    def __init__(self, base_dir: Path) -> None:
        self._dir = Path(base_dir)
        self._dir.mkdir(parents=True, exist_ok=True)

    def save(self, improvement: Improvement) -> None:
        path = self._dir / f"{improvement.improvement_id}.json"
        path.write_text(json.dumps(improvement.to_dict(), indent=2, default=str))

    def load(self, improvement_id: str) -> Improvement | None:
        path = self._dir / f"{improvement_id}.json"
        if not path.exists():
            return None
        data = json.loads(path.read_text())
        return Improvement.from_dict(data)

    def list_improvements(self, *, status: str | None = None) -> list[Improvement]:
        results: list[Improvement] = []
        for f in sorted(self._dir.glob("imp-*.json")):
            try:
                data = json.loads(f.read_text())
                imp = Improvement.from_dict(data)
                if status and imp.status != status:
                    continue
                results.append(imp)
            except Exception as exc:
                logger.debug("Error loading improvement %s: %s", f.name, exc)
        return results

    def update_status(self, improvement_id: str, status: str) -> bool:
        imp = self.load(improvement_id)
        if imp is None:
            return False
        imp.status = status
        self.save(imp)
        return True
