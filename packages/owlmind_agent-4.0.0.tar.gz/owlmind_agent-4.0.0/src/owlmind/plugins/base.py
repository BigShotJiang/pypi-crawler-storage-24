"""Plugin base protocol and hook protocols for OWLMIND plugin system."""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

# ---------------------------------------------------------------------------
# Core plugin protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class PluginBase(Protocol):
    """Base protocol every OWLMIND plugin must satisfy."""

    name: str
    version: str

    def setup(self, config: dict[str, Any]) -> None:
        """Called once after loading. Receive merged config."""
        ...

    def teardown(self) -> None:
        """Called on shutdown. Release resources."""
        ...


# ---------------------------------------------------------------------------
# Hook protocols
# ---------------------------------------------------------------------------


@runtime_checkable
class OnRunStartHook(Protocol):
    """Called when an orchestrator run starts."""

    def on_run_start(self, *, run_id: str, goal: str, **kwargs: Any) -> None: ...


@runtime_checkable
class OnRunDoneHook(Protocol):
    """Called when an orchestrator run completes."""

    def on_run_done(self, *, run_id: str, success: bool, summary: str, **kwargs: Any) -> None: ...


@runtime_checkable
class OnErrorHook(Protocol):
    """Called on errors during orchestration."""

    def on_error(self, *, run_id: str, error: Exception, **kwargs: Any) -> None: ...


@runtime_checkable
class CustomToolProvider(Protocol):
    """Provides additional tools to the orchestrator."""

    def get_tools(self) -> list[dict[str, Any]]:
        """Return a list of tool definitions (MCP-style dicts)."""
        ...

    def call_tool(self, tool_name: str, arguments: dict[str, Any]) -> Any:
        """Execute a tool by name and return the result."""
        ...
