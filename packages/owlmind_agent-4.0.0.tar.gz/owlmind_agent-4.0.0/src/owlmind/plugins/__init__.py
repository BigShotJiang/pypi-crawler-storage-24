"""OWLMIND plugin system -- entry-point-based plugin discovery and lifecycle."""

from .base import (
    CustomToolProvider,
    OnErrorHook,
    OnRunDoneHook,
    OnRunStartHook,
    PluginBase,
)
from .hooks import (
    ALL_HOOKS,
    CALL_TOOL,
    GET_TOOLS,
    ON_ERROR,
    ON_RUN_DONE,
    ON_RUN_START,
    HookResult,
    plugin_has_hook,
)
from .registry import PluginRegistry

__all__ = [
    "ALL_HOOKS",
    "CALL_TOOL",
    "CustomToolProvider",
    "GET_TOOLS",
    "HookResult",
    "ON_ERROR",
    "ON_RUN_DONE",
    "ON_RUN_START",
    "OnErrorHook",
    "OnRunDoneHook",
    "OnRunStartHook",
    "PluginBase",
    "PluginRegistry",
    "plugin_has_hook",
]
