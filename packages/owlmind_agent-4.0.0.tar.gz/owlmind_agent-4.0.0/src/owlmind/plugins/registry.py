"""Plugin discovery, loading, and lifecycle management."""

from __future__ import annotations

import importlib.metadata
import logging
from typing import Any

from .base import PluginBase
from .hooks import ALL_HOOKS, HookResult, plugin_has_hook

logger = logging.getLogger("owlmind.plugins")

ENTRY_POINT_GROUP = "owlmind.plugins"


class PluginRegistry:
    """Discovers, loads, and manages OWLMIND plugins.

    Plugins are found via ``importlib.metadata.entry_points``
    using the group ``owlmind.plugins``.
    """

    def __init__(self) -> None:
        self._plugins: dict[str, PluginBase] = {}
        self._entry_points: dict[str, importlib.metadata.EntryPoint] = {}

    # ------------------------------------------------------------------
    # Discovery
    # ------------------------------------------------------------------

    def discover(self) -> list[str]:
        """Discover available plugins from installed entry points.

        Returns a list of discovered plugin names.
        """
        eps = importlib.metadata.entry_points()
        group_eps: list[importlib.metadata.EntryPoint] = (
            eps.get(ENTRY_POINT_GROUP, [])
            if isinstance(eps, dict)
            else [ep for ep in eps if ep.group == ENTRY_POINT_GROUP]
        )
        self._entry_points = {ep.name: ep for ep in group_eps}
        names = list(self._entry_points)
        logger.debug("Discovered %d plugin(s): %s", len(names), names)
        return names

    # ------------------------------------------------------------------
    # Loading
    # ------------------------------------------------------------------

    def load(self, name: str) -> PluginBase | None:
        """Load and instantiate a single plugin by name.

        Returns the plugin instance, or ``None`` if loading fails.
        """
        if name in self._plugins:
            return self._plugins[name]

        ep = self._entry_points.get(name)
        if ep is None:
            logger.warning("Plugin %r not found in discovered entry points.", name)
            return None

        try:
            plugin_cls = ep.load()
            instance = plugin_cls()
            self._plugins[name] = instance
            logger.info("Loaded plugin %r (%s)", name, getattr(instance, "version", "?"))
            return instance  # type: ignore[no-any-return]
        except Exception:
            logger.exception("Failed to load plugin %r.", name)
            return None

    def load_all(self) -> list[str]:
        """Load all discovered plugins. Returns names of successfully loaded ones."""
        if not self._entry_points:
            self.discover()
        loaded: list[str] = []
        for name in list(self._entry_points):
            if self.load(name) is not None:
                loaded.append(name)
        return loaded

    # ------------------------------------------------------------------
    # Access
    # ------------------------------------------------------------------

    def get(self, name: str) -> PluginBase | None:
        """Return a loaded plugin by name, or ``None``."""
        return self._plugins.get(name)

    def list_plugins(self) -> list[dict[str, Any]]:
        """Return a list of info dicts for all loaded plugins."""
        result: list[dict[str, Any]] = []
        for name, plugin in self._plugins.items():
            hooks = [h for h in ALL_HOOKS if plugin_has_hook(plugin, h)]
            result.append(
                {
                    "name": name,
                    "version": getattr(plugin, "version", "unknown"),
                    "description": getattr(plugin, "__doc__", "") or "",
                    "hooks": hooks,
                }
            )
        return result

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def setup_all(self, config: dict[str, Any] | None = None) -> None:
        """Call ``setup(config)`` on all loaded plugins."""
        cfg = config or {}
        for name, plugin in self._plugins.items():
            try:
                plugin.setup(cfg)
                logger.debug("Plugin %r setup complete.", name)
            except Exception:
                logger.exception("Plugin %r raised during setup.", name)

    def teardown_all(self) -> None:
        """Call ``teardown()`` on all loaded plugins (reverse order)."""
        for name in reversed(list(self._plugins)):
            plugin = self._plugins[name]
            try:
                plugin.teardown()
                logger.debug("Plugin %r teardown complete.", name)
            except Exception:
                logger.exception("Plugin %r raised during teardown.", name)

    # ------------------------------------------------------------------
    # Hook firing
    # ------------------------------------------------------------------

    def fire_hook(self, hook_name: str, **kwargs: Any) -> HookResult:
        """Fire a hook on all loaded plugins that implement it.

        Returns a :class:`HookResult` aggregating successes and errors.
        All plugin calls are wrapped in try/except — a misbehaving plugin
        never crashes the host.
        """
        result = HookResult(hook=hook_name)
        for name, plugin in self._plugins.items():
            if not plugin_has_hook(plugin, hook_name):
                continue
            try:
                method = getattr(plugin, hook_name)
                ret = method(**kwargs)
                result.results.append({"plugin": name, "return": ret})
            except Exception as exc:
                logger.exception(
                    "Plugin %r raised during hook %r.",
                    name,
                    hook_name,
                )
                result.errors.append({"plugin": name, "error": str(exc)})
        return result
