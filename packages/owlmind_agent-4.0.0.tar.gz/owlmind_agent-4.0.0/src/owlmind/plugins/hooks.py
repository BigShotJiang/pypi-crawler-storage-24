"""Hook point definitions for OWLMIND plugin system."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

# ---------------------------------------------------------------------------
# Hook name constants
# ---------------------------------------------------------------------------

ON_RUN_START = "on_run_start"
ON_RUN_DONE = "on_run_done"
ON_ERROR = "on_error"
GET_TOOLS = "get_tools"
CALL_TOOL = "call_tool"

ALL_HOOKS: tuple[str, ...] = (
    ON_RUN_START,
    ON_RUN_DONE,
    ON_ERROR,
    GET_TOOLS,
    CALL_TOOL,
)


# ---------------------------------------------------------------------------
# HookResult
# ---------------------------------------------------------------------------


@dataclass
class HookResult:
    """Aggregated result of firing a hook across all plugins."""

    hook: str
    results: list[dict[str, Any]] = field(default_factory=list)
    errors: list[dict[str, Any]] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        """True if no errors occurred."""
        return len(self.errors) == 0

    @property
    def total(self) -> int:
        """Total number of plugins that responded (success + error)."""
        return len(self.results) + len(self.errors)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def plugin_has_hook(plugin: object, hook_name: str) -> bool:
    """Check if *plugin* implements the given hook method."""
    method = getattr(plugin, hook_name, None)
    return callable(method)
