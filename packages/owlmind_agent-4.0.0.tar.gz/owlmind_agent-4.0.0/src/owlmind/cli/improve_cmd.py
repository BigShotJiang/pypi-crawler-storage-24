"""CLI command: owlmind improve — analyze SWE-bench failures and improve agent prompts."""

from __future__ import annotations

import json
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

improve_app = typer.Typer(
    name="improve",
    help="Analyze SWE-bench failures and suggest/apply improved agent system prompts.",
    no_args_is_help=True,
)

console = Console()

# Default locations produced by `owlmind bench run`
DEFAULT_BENCH_RESULTS_DIR = Path.home() / ".owlmind" / "bench_results"
DEFAULT_IMPROVEMENTS_FILE = Path.home() / ".owlmind" / "prompt_improvements.jsonl"
DEFAULT_PROMPTS_CONFIG = Path.home() / ".owlmind" / "prompt_overrides.json"


def _find_latest_report(bench_results_dir: Path) -> Path | None:
    """Return the most-recently modified JSON report in bench_results_dir."""
    candidates = sorted(
        bench_results_dir.glob("*.json"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    return candidates[0] if candidates else None


def _load_failed_tasks(report_path: Path) -> list[dict]:
    """Parse a bench JSON report and return only the failed/error entries."""
    data = json.loads(report_path.read_text())
    results = data.get("results", [])
    return [r for r in results if r.get("status") not in ("passed", "skipped")]


@improve_app.command("run")
def run(
    report: Path | None = typer.Option(
        None,
        "--report",
        "-r",
        help="Path to a bench_report.json file. "
        "Defaults to the latest report in ~/.owlmind/bench_results/.",
    ),
    bench_results_dir: Path = typer.Option(
        DEFAULT_BENCH_RESULTS_DIR,
        "--bench-dir",
        help="Directory containing bench JSON reports (used when --report is omitted).",
    ),
    dry_run: bool = typer.Option(
        True,
        "--dry-run/--apply",
        help="Dry-run: print suggestions without writing prompt_overrides.json.",
    ),
    improvements_file: Path = typer.Option(
        DEFAULT_IMPROVEMENTS_FILE,
        "--improvements-file",
        help="JSONL file where improvement records are appended.",
    ),
    prompts_config: Path = typer.Option(
        DEFAULT_PROMPTS_CONFIG,
        "--prompts-config",
        help="JSON file where prompt overrides are written (only in --apply mode).",
    ),
    min_failures: int = typer.Option(
        1,
        "--min-failures",
        help="Minimum number of failures required before suggesting improvements.",
    ),
) -> None:
    """Analyze the latest SWE-bench report and suggest (or apply) prompt improvements.

    Examples::

      # Dry-run with the latest bench report
      owlmind improve run

      # Analyze a specific report and apply improvements
      owlmind improve run --report bench_report.json --apply

      # Point to a different bench results directory
      owlmind improve run --bench-dir /tmp/my_bench_results --dry-run
    """
    from owlmind.agent.self_improver import FailedTask, SelfImprover

    # --- Resolve report path ---
    if report is None:
        if not bench_results_dir.is_dir():
            console.print(
                f"[yellow]Bench results directory not found: {bench_results_dir}[/yellow]\n"
                "Run [bold]owlmind bench run[/bold] first, or pass [bold]--report[/bold]."
            )
            raise typer.Exit(code=1)
        report = _find_latest_report(bench_results_dir)
        if report is None:
            console.print(
                f"[yellow]No JSON reports found in {bench_results_dir}[/yellow]\n"
                "Run [bold]owlmind bench run --output <file>[/bold] first."
            )
            raise typer.Exit(code=1)

    if not report.exists():
        console.print(f"[red]Report file not found: {report}[/red]")
        raise typer.Exit(code=1)

    console.print(f"[bold]Reading report:[/bold] {report}")

    # --- Load failures ---
    try:
        raw_failures = _load_failed_tasks(report)
    except (json.JSONDecodeError, KeyError) as exc:
        console.print(f"[red]Could not parse report: {exc}[/red]")
        raise typer.Exit(code=1) from None

    console.print(f"  Failed tasks found: [bold]{len(raw_failures)}[/bold]")

    if len(raw_failures) < min_failures:
        console.print(
            f"[green]Only {len(raw_failures)} failure(s) — below threshold "
            f"({min_failures}). Nothing to improve.[/green]"
        )
        return

    failed_tasks = [FailedTask.from_bench_result(r) for r in raw_failures]

    # --- Run analysis ---
    improver = SelfImprover(
        improvements_file=improvements_file,
        prompts_config=prompts_config,
    )

    mode_label = "[yellow]dry-run[/yellow]" if dry_run else "[green]apply[/green]"
    console.print(f"  Mode: {mode_label}")

    suggestions = improver.analyze(failed_tasks, dry_run=dry_run)

    # --- Display results ---
    if not suggestions:
        console.print("[green]No suggestions generated.[/green]")
        return

    table = Table(
        title="Prompt Improvement Suggestions",
        show_header=True,
        header_style="bold cyan",
    )
    table.add_column("Agent", style="bold", min_width=8)
    table.add_column("Pattern", min_width=20)
    table.add_column("Confidence", justify="right")
    table.add_column("Rationale")

    for s in suggestions:
        conf_color = "green" if s.confidence >= 0.7 else "yellow" if s.confidence >= 0.5 else "red"
        table.add_row(
            s.agent,
            s.pattern,
            f"[{conf_color}]{s.confidence:.0%}[/{conf_color}]",
            s.rationale[:80],
        )

    console.print(table)

    for i, s in enumerate(suggestions, 1):
        console.print(f"\n[bold cyan]Suggestion {i} — {s.agent} ({s.pattern})[/bold cyan]")
        console.print(s.suggested_addition)

    console.print(
        f"\n[dim]Improvement record appended to: {improvements_file}[/dim]"
    )

    if dry_run:
        console.print(
            "\n[yellow]Dry-run mode — prompts NOT updated.[/yellow] "
            "Re-run with [bold]--apply[/bold] to write changes."
        )
    else:
        console.print(
            f"\n[green]Prompt overrides written to:[/green] {prompts_config}"
        )


@improve_app.command("history")
def history(
    improvements_file: Path = typer.Option(
        DEFAULT_IMPROVEMENTS_FILE,
        "--improvements-file",
        help="JSONL file of improvement records.",
    ),
    limit: int = typer.Option(10, "--limit", "-n", help="Show last N records."),
) -> None:
    """Show the history of improvement sessions."""
    if not improvements_file.exists():
        console.print(f"[yellow]No improvement history found at {improvements_file}[/yellow]")
        return

    lines = improvements_file.read_text().strip().splitlines()
    records = []
    for line in lines:
        try:
            records.append(json.loads(line))
        except json.JSONDecodeError:
            continue

    records = records[-limit:]

    table = Table(title="Improvement History", show_header=True, header_style="bold cyan")
    table.add_column("Timestamp", min_width=25)
    table.add_column("Failures", justify="right")
    table.add_column("Suggestions", justify="right")
    table.add_column("Applied")
    table.add_column("Dry-run")

    for rec in records:
        applied = "[green]yes[/green]" if rec.get("applied") else "[dim]no[/dim]"
        dry = "[yellow]yes[/yellow]" if rec.get("dry_run") else "[green]no[/green]"
        table.add_row(
            rec.get("timestamp", "?"),
            str(rec.get("failures_analyzed", 0)),
            str(len(rec.get("suggestions", []))),
            applied,
            dry,
        )

    console.print(table)
