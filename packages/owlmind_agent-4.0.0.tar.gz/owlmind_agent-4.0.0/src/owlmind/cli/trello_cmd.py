"""CLI commands for Trello issue tracker integration."""

from __future__ import annotations

import asyncio
import os

import typer
from rich.console import Console

trello_app = typer.Typer(help="Trello issue tracker integration.")
console = Console()


def _get_trello_config() -> dict[str, str]:
    """Resolve Trello configuration from environment."""
    return {
        "api_key": os.environ.get("OWLMIND_TRELLO_API_KEY", ""),
        "token": os.environ.get("OWLMIND_TRELLO_TOKEN", ""),
    }


@trello_app.command("create-card")
def cmd_create_card(
    list_id: str = typer.Option(..., "--list", "-l", help="Trello list ID"),
    name: str = typer.Option(..., "--name", "-n", help="Card name"),
    desc: str = typer.Option("", "--desc", "-d", help="Card description"),
    pos: str = typer.Option("bottom", "--pos", help="Position (top, bottom)"),
) -> None:
    """Create a Trello card."""
    from owlmind.integrations.issue_trackers import create_issue_tracker

    cfg = _get_trello_config()
    if not cfg["api_key"] or not cfg["token"]:
        console.print(
            "[red]Trello not configured. Set OWLMIND_TRELLO_API_KEY and OWLMIND_TRELLO_TOKEN.[/red]"
        )
        raise typer.Exit(1)

    tracker = create_issue_tracker("trello", **cfg)
    params: dict = {
        "list_id": list_id,
        "name": name,
        "pos": pos,
    }
    if desc:
        params["desc"] = desc

    result = asyncio.run(tracker.create_issue(params))
    if result.ok:
        console.print(f"[green]Card created:[/green] {result.issue_key}")
        if result.url:
            console.print(f"  URL: {result.url}")
    else:
        console.print(f"[red]Failed:[/red] {result.detail}")
        raise typer.Exit(1)


@trello_app.command("validate")
def cmd_validate() -> None:
    """Validate Trello connection."""
    from owlmind.integrations.issue_trackers import create_issue_tracker

    cfg = _get_trello_config()
    if not cfg["api_key"]:
        console.print("[red]OWLMIND_TRELLO_API_KEY not set.[/red]")
        raise typer.Exit(1)

    tracker = create_issue_tracker("trello", **cfg)
    ok = asyncio.run(tracker.validate_config())
    if ok:
        console.print("[green]Trello connection OK[/green]")
    else:
        console.print("[red]Trello connection failed[/red]")
        raise typer.Exit(1)
