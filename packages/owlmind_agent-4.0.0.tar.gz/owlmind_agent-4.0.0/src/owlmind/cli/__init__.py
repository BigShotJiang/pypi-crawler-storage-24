"""OWLMIND CLI — Typer-based command-line interface."""

from __future__ import annotations

import typer

from .ab_cmd import ab_app
from .agent_cmd import agent_app
from .analytics import analytics_app, export_app, monitor_app
from .api_cmd import api_app
from .ast_cmd import ast_app
from .autofix_cmd import app as autofix_app
from .automation import e2e_app, llm_app, register_auto, telegram_app
from .bench_cmd import bench_app
from .config_cmd import config_app
from .core import register as register_core
from .cost_cmd import cost_app
from .cycle import cycle_app
from .diag_cmd import diag_app
from .evidence_cmd import evidence_app
from .graph_cmd import graph_app
from .improve_cmd import improve_app
from .integrations_cmd import integrations_app
from .jira_cmd import jira_app
from .marketplace_cmd import marketplace_app
from .mcp_cmd import mcp_app
from .memory_cmd import memory_app
from .multi_repo_cmd import multi_repo_app
from .ops import (
    ci_app,
    dashboard_app,
    github_app,
    goals_app,
    register_up,
    release_app,
    security_app,
    setup_app,
)
from .plugin_cmd import plugin_app
from .queue import queue_app
from .registry_cmd import registry_app
from .scheduler_cmd import scheduler_app
from .self_improve_cmd import self_improve_app
from .session import session_app
from .skillpack_cmd import skillpack_app
from .skills_cmd import skills_app
from .slack_cmd import app as slack_app
from .trello_cmd import trello_app
from .vcs_cmd import vcs_app
from .web_cmd import web_app
from .webhook_cmd import webhook_app
from .worker_cmd import worker_app

try:
    from owlmind.vision.cli import vision_app as _vision_app  # type: ignore[import]
    _vision_available = True
except Exception:
    _vision_available = False

try:
    from owlmind.browser.cli import browser_app as _browser_app  # type: ignore[import]
    _browser_available = True
except ImportError:
    _browser_available = False

app = typer.Typer(
    name="owlmind",
    help="OWLMIND — autonomous multi-agent code orchestrator",
    no_args_is_help=True,
)


@app.callback()
def _main_callback(
    log_level: str | None = typer.Option(
        None, "--log-level", help="Log level (DEBUG/INFO/WARNING/ERROR)"
    ),
    log_json: bool = typer.Option(False, "--log-json", help="JSON log output"),
) -> None:
    """Global logging configuration."""
    # Load .env from project root before password check
    try:
        from pathlib import Path as _Path

        from dotenv import load_dotenv
        _env = _Path(__file__).parent.parent.parent.parent / ".env"
        if _env.exists():
            load_dotenv(_env, override=False)
    except ImportError:
        pass

    from owlmind.security import check_master_password

    check_master_password()

    if log_level or log_json:
        from owlmind.logging_config import setup_logging

        setup_logging(level=log_level or "WARNING", json_format=log_json)


# Top-level commands (doctor, run, show, replay, heartbeat)
register_core(app)
# auto command
register_auto(app)
# up command
register_up(app)

# Sub-typer groups
app.add_typer(ab_app, name="ab")
app.add_typer(cycle_app, name="cycle")
app.add_typer(queue_app, name="queue")
app.add_typer(session_app, name="session")
app.add_typer(analytics_app, name="analytics")
app.add_typer(llm_app, name="llm")
app.add_typer(e2e_app, name="e2e")
app.add_typer(telegram_app, name="telegram")
app.add_typer(github_app, name="github")
app.add_typer(ci_app, name="ci")
app.add_typer(security_app, name="security")
app.add_typer(monitor_app, name="monitor")
app.add_typer(release_app, name="release")
app.add_typer(setup_app, name="setup")
app.add_typer(export_app, name="export")
app.add_typer(goals_app, name="goals")
app.add_typer(dashboard_app, name="dashboard")
app.add_typer(config_app, name="config")
app.add_typer(cost_app, name="cost")
app.add_typer(diag_app, name="diag")
app.add_typer(memory_app, name="memory")
app.add_typer(webhook_app, name="webhook")
app.add_typer(mcp_app, name="mcp")
app.add_typer(api_app, name="api")
app.add_typer(plugin_app, name="plugin")
app.add_typer(evidence_app, name="evidence")
app.add_typer(scheduler_app, name="scheduler")
app.add_typer(skills_app, name="skills")
app.add_typer(skillpack_app, name="skill-pack")
app.add_typer(agent_app, name="agent")
app.add_typer(graph_app, name="graph")
app.add_typer(web_app, name="web")
app.add_typer(worker_app, name="worker")
app.add_typer(self_improve_app, name="self-improve")
app.add_typer(bench_app, name="bench")
app.add_typer(improve_app, name="improve")
app.add_typer(registry_app, name="registry")
app.add_typer(vcs_app, name="vcs")
app.add_typer(integrations_app, name="integrations")
app.add_typer(jira_app, name="jira")
app.add_typer(trello_app, name="trello")
app.add_typer(ast_app, name="ast")
app.add_typer(autofix_app, name="autofix")
app.add_typer(slack_app, name="slack")
app.add_typer(marketplace_app, name="marketplace")
app.add_typer(multi_repo_app, name="multi-repo")

if _vision_available:
    app.add_typer(_vision_app, name="vision")  # type: ignore[arg-type]

if _browser_available:
    app.add_typer(_browser_app, name="browser")  # type: ignore[arg-type]

__all__ = ["app"]
