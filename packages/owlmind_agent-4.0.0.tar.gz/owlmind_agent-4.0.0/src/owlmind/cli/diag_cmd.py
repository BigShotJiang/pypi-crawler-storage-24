"""CLI commands: diag report."""

from __future__ import annotations

from pathlib import Path

import typer
from rich.console import Console

diag_app = typer.Typer(help="Diagnostics and debugging tools.")
console = Console()


@diag_app.command("report")
def diag_report(
    workspace: Path = typer.Option(".", "-w", "--workspace", help="Workspace root."),
    out: Path | None = typer.Option(None, "--out", "-o", help="Output zip path."),
) -> None:
    """Generate a redacted diagnostic zip report.

    Collects: versions, resolved config (redacted), doctor output,
    security scan, recent runs/sessions summaries.
    """
    from owlmind.diag import build_diag_report

    console.print("[cyan]Building diagnostic report...[/cyan]")
    result = build_diag_report(workspace, out_zip=out)
    console.print(f"[green]Report saved to: {result}[/green]")
    console.print("[dim]All secrets have been redacted. Safe to share.[/dim]")
