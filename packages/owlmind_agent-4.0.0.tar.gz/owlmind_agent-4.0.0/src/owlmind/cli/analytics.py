"""Analytics, monitoring, and export CLI subcommands."""

from __future__ import annotations

import os
from pathlib import Path

import typer
from rich.table import Table

from owlmind import __version__

from ._helpers import (
    DEFAULT_LEDGER,
    DEFAULT_RUNS,
    DEFAULT_SESSIONS,
    console,
    print_totals,
)

analytics_app = typer.Typer(
    name="analytics",
    help="Token usage analytics and cost reports",
    no_args_is_help=True,
)

monitor_app = typer.Typer(
    name="monitor",
    help="Operational monitoring — digest, stuck detection.",
    no_args_is_help=True,
)

export_app = typer.Typer(
    name="export",
    help="Export operational data — ledger, sessions, runs.",
    no_args_is_help=True,
)


# ===========================================================================
# Analytics
# ===========================================================================


@analytics_app.command("today")
def analytics_today(
    ledger_dir: Path = typer.Option(DEFAULT_LEDGER, "--ledger-dir", help="Ledger directory"),
) -> None:
    """Show token usage and costs for today."""
    from owlmind.ledger import UsageLedger

    console.print(f"[bold]OWLMIND v{__version__} — analytics today[/bold]\n")

    ledger = UsageLedger(ledger_dir)
    totals = ledger.totals_for_day()
    print_totals("Today's Usage", totals)


@analytics_app.command("day")
def analytics_day(
    date: str = typer.Option(..., "--date", "-d", help="Date (YYYY-MM-DD)"),
    ledger_dir: Path = typer.Option(DEFAULT_LEDGER, "--ledger-dir", help="Ledger directory"),
) -> None:
    """Show token usage and costs for a specific date."""
    from datetime import date as date_cls

    from owlmind.ledger import UsageLedger

    console.print(f"[bold]OWLMIND v{__version__} — analytics day[/bold]\n")

    day = date_cls.fromisoformat(date)
    ledger = UsageLedger(ledger_dir)
    totals = ledger.totals_for_day(day)
    print_totals(f"Usage for {date}", totals)


@analytics_app.command("run")
def analytics_run(
    run_id: str = typer.Option(..., "--run-id", help="Run ID"),
    ledger_dir: Path = typer.Option(DEFAULT_LEDGER, "--ledger-dir", help="Ledger directory"),
) -> None:
    """Show token usage and costs for a specific run."""
    from owlmind.ledger import UsageLedger

    console.print(f"[bold]OWLMIND v{__version__} — analytics run[/bold]\n")

    ledger = UsageLedger(ledger_dir)
    totals = ledger.totals_for_run(run_id)
    print_totals(f"Usage for {run_id}", totals)


@analytics_app.command("recent")
def analytics_recent(
    n: int = typer.Option(20, "--n", "-n", help="Number of recent entries"),
    ledger_dir: Path = typer.Option(DEFAULT_LEDGER, "--ledger-dir", help="Ledger directory"),
) -> None:
    """Show the most recent ledger entries."""
    from owlmind.ledger import UsageLedger

    console.print(f"[bold]OWLMIND v{__version__} — analytics recent[/bold]\n")

    ledger = UsageLedger(ledger_dir)
    entries = ledger.recent(n)

    if not entries:
        console.print("[dim]No usage entries found.[/dim]")
        return

    table = Table(title=f"Last {len(entries)} Entries")
    table.add_column("Time", style="dim")
    table.add_column("Run ID")
    table.add_column("Stage")
    table.add_column("Model")
    table.add_column("Tokens", justify="right")
    table.add_column("USD", justify="right")

    for entry in entries:
        ts_short = entry.ts[:19] if len(entry.ts) >= 19 else entry.ts
        table.add_row(
            ts_short,
            entry.run_id[:20],
            entry.stage,
            entry.model,
            f"{entry.total_tokens:,}",
            f"${entry.estimated_usd:.4f}",
        )

    console.print(table)


@analytics_app.command("dashboard")
def analytics_dashboard(
    out: Path = typer.Option(..., "--out", "-o", help="Output HTML file path"),
    ledger_dir: Path = typer.Option(DEFAULT_LEDGER, "--ledger-dir", help="Ledger directory"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
) -> None:
    """Generate a static HTML dashboard of usage analytics."""
    from owlmind.dashboard import generate_dashboard

    console.print(f"[bold]OWLMIND v{__version__} — analytics dashboard[/bold]\n")

    generate_dashboard(ledger_dir, runs_dir, out)
    console.print(f"[green]Dashboard written to: {out}[/green]")


@analytics_app.command("cost-report")
def analytics_cost_report(
    period: str = typer.Option("day", "--period", "-p", help="Period: day, week, or month"),
    date: str = typer.Option(None, "--date", "-d", help="Date for daily report (YYYY-MM-DD)"),
    fmt: str = typer.Option("text", "--format", "-f", help="Output format: text or json"),
    ledger_dir: Path = typer.Option(DEFAULT_LEDGER, "--ledger-dir", help="Ledger directory"),
) -> None:
    """Show cost report for a given period (day/week/month)."""
    from owlmind.reports import (
        daily_report,
        format_report_json,
        format_report_text,
        monthly_report,
        weekly_report,
    )

    console.print(f"[bold]OWLMIND v{__version__} — cost report ({period})[/bold]\n")

    if period == "day":
        report = daily_report(ledger_dir, date=date)
    elif period == "week":
        report = weekly_report(ledger_dir)
    elif period == "month":
        report = monthly_report(ledger_dir)
    else:
        console.print(f"[red]Unknown period: {period}. Use day, week, or month.[/red]")
        raise typer.Exit(code=1)

    if fmt == "json":
        console.print(format_report_json(report))
    else:
        console.print(format_report_text(report))


@analytics_app.command("provider-breakdown")
def analytics_provider_breakdown(
    fmt: str = typer.Option("text", "--format", "-f", help="Output format: text or json"),
    ledger_dir: Path = typer.Option(DEFAULT_LEDGER, "--ledger-dir", help="Ledger directory"),
) -> None:
    """Show per-provider/model cost breakdown sorted by total cost."""
    import json as json_mod

    from owlmind.reports import provider_breakdown

    console.print(f"[bold]OWLMIND v{__version__} — provider breakdown[/bold]\n")

    rows = provider_breakdown(ledger_dir)

    if not rows:
        console.print("[dim]No usage data found.[/dim]")
        return

    if fmt == "json":
        console.print(json_mod.dumps(rows, indent=2))
        return

    table = Table(title="Provider Breakdown (by cost)")
    table.add_column("Provider", style="bold")
    table.add_column("Model")
    table.add_column("Tokens", justify="right")
    table.add_column("USD", justify="right")
    table.add_column("Calls", justify="right")
    table.add_column("%", justify="right")

    for r in rows:
        table.add_row(
            r["provider"],
            r["model"],
            f"{r['tokens']:,}",
            f"${r['usd']:.4f}",
            str(r["calls"]),
            f"{r['pct']:.1f}%",
        )

    console.print(table)


# ===========================================================================
# Monitor
# ===========================================================================


@monitor_app.command("digest")
def monitor_digest(
    days: int = typer.Option(1, "--days", "-d", help="Number of days"),
    out: Path = typer.Option(None, "--out", "-o", help="Write markdown to file"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs-dir"),
    sessions_dir: Path = typer.Option(DEFAULT_SESSIONS, "--sessions-dir"),
    ledger_dir: Path = typer.Option(DEFAULT_LEDGER, "--ledger-dir"),
) -> None:
    """Generate daily digest — usage, runs, sessions, actions."""
    from owlmind.monitor import build_digest, format_digest_markdown

    report = build_digest(
        ledger_dir=ledger_dir,
        runs_dir=runs_dir,
        sessions_dir=sessions_dir,
        days=days,
    )
    md = format_digest_markdown(report)

    if out:
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(md)
        console.print(f"[green]Digest written to {out}[/green]")
    else:
        console.print(md)


@monitor_app.command("stuck")
def monitor_stuck(
    minutes: int = typer.Option(30, "--minutes", "-m", help="Threshold minutes"),
    sessions_dir: Path = typer.Option(DEFAULT_SESSIONS, "--sessions-dir"),
) -> None:
    """Detect stuck sessions (no progress beyond threshold)."""
    from owlmind.monitor import detect_stuck_sessions, format_stuck_text

    stuck = detect_stuck_sessions(sessions_dir, threshold_minutes=minutes)
    console.print(format_stuck_text(stuck))

    if stuck:
        raise typer.Exit(code=2)


@monitor_app.command("notify")
def monitor_notify(
    days: int = typer.Option(1, "--days", "-d", help="Number of days"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs-dir"),
    sessions_dir: Path = typer.Option(DEFAULT_SESSIONS, "--sessions-dir"),
    ledger_dir: Path = typer.Option(DEFAULT_LEDGER, "--ledger-dir"),
) -> None:
    """Send digest to Telegram (if configured). Otherwise print setup guide."""
    from owlmind.monitor import build_digest, format_digest_markdown

    report = build_digest(
        ledger_dir=ledger_dir,
        runs_dir=runs_dir,
        sessions_dir=sessions_dir,
        days=days,
    )
    md = format_digest_markdown(report)

    token = os.environ.get("TELEGRAM_BOT_TOKEN")
    chat_id = os.environ.get("OWLMIND_NOTIFY_DEFAULT_CHAT_ID")

    if not token or not chat_id:
        console.print("[yellow]Telegram not configured.[/yellow]")
        console.print("Set TELEGRAM_BOT_TOKEN and OWLMIND_NOTIFY_DEFAULT_CHAT_ID.")
        console.print("\nDigest preview:\n")
        console.print(md)
        return

    console.print("[dim]Telegram notification would be sent here.[/dim]")
    console.print(md)


# ===========================================================================
# Export
# ===========================================================================


@export_app.command("ledger")
def export_ledger_cmd(
    out: Path = typer.Option("ledger.csv", "--out", "-o", help="Output CSV path"),
    ledger_dir: Path = typer.Option(DEFAULT_LEDGER, "--ledger-dir"),
) -> None:
    """Export ledger usage entries to CSV."""
    from owlmind.exporters import export_ledger_csv

    path = export_ledger_csv(ledger_dir, out)
    console.print(f"[green]Ledger exported to {path}[/green]")


@export_app.command("sessions")
def export_sessions_cmd(
    out: Path = typer.Option("sessions.csv", "--out", "-o", help="Output CSV path"),
    sessions_dir: Path = typer.Option(DEFAULT_SESSIONS, "--sessions-dir"),
) -> None:
    """Export session metadata to CSV."""
    from owlmind.exporters import export_sessions_csv

    path = export_sessions_csv(sessions_dir, out)
    console.print(f"[green]Sessions exported to {path}[/green]")


@export_app.command("runs")
def export_runs_cmd(
    out: Path = typer.Option("runs.csv", "--out", "-o", help="Output CSV path"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs-dir"),
) -> None:
    """Export run metadata to CSV."""
    from owlmind.exporters import export_runs_csv

    path = export_runs_csv(runs_dir, out)
    console.print(f"[green]Runs exported to {path}[/green]")


@export_app.command("all")
def export_all_cmd(
    out: Path = typer.Option("ops_export.zip", "--out", "-o", help="Output zip path"),
    ledger_dir: Path = typer.Option(DEFAULT_LEDGER, "--ledger-dir"),
    sessions_dir: Path = typer.Option(DEFAULT_SESSIONS, "--sessions-dir"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs-dir"),
) -> None:
    """Export all operational data into a zip."""
    from owlmind.exporters import export_all_zip

    path = export_all_zip(
        out,
        ledger_dir=ledger_dir,
        sessions_dir=sessions_dir,
        runs_dir=runs_dir,
    )
    console.print(f"[green]All data exported to {path}[/green]")
