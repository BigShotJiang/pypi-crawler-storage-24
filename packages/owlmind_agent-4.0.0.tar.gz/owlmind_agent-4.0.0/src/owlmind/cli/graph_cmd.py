"""Graph multi-agent pipeline CLI commands."""
from __future__ import annotations

from typing import Annotated

import typer
from rich.console import Console
from rich.panel import Panel

graph_app = typer.Typer(name="graph", help="Multi-agent graph — Architect→Coder→Tester→Reviewer pipeline", no_args_is_help=True)
console = Console()


@graph_app.command("run")
def cmd_run(
    goal: Annotated[str, typer.Argument(help="Goal for the agent pipeline")],
    workspace: Annotated[str, typer.Option("--workspace", "-w")] = ".",
    max_iterations: Annotated[int, typer.Option("--iterations", "-n")] = 3,
    skip_tester: Annotated[bool, typer.Option("--skip-tester")] = False,
    verbose: Annotated[bool, typer.Option("--verbose", "-v")] = False,
) -> None:
    """Run the full Architect→Coder→Tester→Reviewer pipeline."""
    from owlmind.graph.runner import GraphRunner, _build_llm_client
    from owlmind.graph.state import NodeStatus

    if _build_llm_client() is None:
        console.print("[red]No LLM configured. Set OPENAI_API_KEY or ANTHROPIC_API_KEY in .env[/red]")
        raise typer.Exit(1) from None

    console.print(f"[bold]Graph Pipeline[/bold] — {goal[:80]}")
    console.print(f"Workspace: {workspace} | Iterations: {max_iterations}\n")

    _NODE_LABELS = {
        "architect": "Architect",
        "coder":     "Coder    ",
        "tester":    "Tester   ",
        "reviewer":  "Reviewer ",
    }

    def on_node(result):
        icon = "[green]✓[/green]" if result.status == NodeStatus.DONE else "[red]✗[/red]"
        console.print(f"  {icon} [{result.node_name}] {result.duration_ms}ms")
        if verbose and result.output:
            console.print(Panel(result.output[:400], title=result.node_name, border_style="dim"))

    def progress_callback(node_name: str, status: str, output_snippet: str) -> None:
        label = _NODE_LABELS.get(node_name, node_name.capitalize())
        if status == "done":
            # Pick a human-readable summary line based on node
            if node_name == "architect":
                detail = "Plan created"
            elif node_name == "coder":
                detail = "Files written"
            elif node_name == "tester":
                detail = "Tests passed" if "PASS" in output_snippet.upper() else "Tests evaluated"
            elif node_name == "reviewer":
                # Try to extract verdict from snippet
                for word in ("APPROVED", "NEEDS_FIX", "REJECTED"):
                    if word in output_snippet.upper():
                        detail = word
                        break
                else:
                    detail = "Review complete"
            else:
                detail = output_snippet[:60] or "Done"
            console.print(f"[{label}] [green]✓[/green] {detail}")
        else:
            console.print(f"[{label}] [red]✗[/red] {status}: {output_snippet[:60]}")

    runner = GraphRunner(on_node_complete=on_node)
    state = runner.run(
        goal,
        workspace=workspace,
        max_iterations=max_iterations,
        skip_tester=skip_tester,
        progress_callback=progress_callback,
    )

    verdict_color = {"APPROVED": "green", "NEEDS_FIX": "yellow", "REJECTED": "red"}.get(state.final_verdict, "white")
    console.print(f"\n[bold {verdict_color}]VERDICT: {state.final_verdict}[/bold {verdict_color}]")

    if state.review:
        console.print(Panel(state.review[:600], title="Reviewer", border_style=verdict_color))

    cost = state.cost
    console.print(
        f"Cost: {cost.total_tokens:,} tokens | ~${cost.total_usd:.4f}"
    )


@graph_app.command("watch")
def cmd_watch(
    goal: Annotated[str, typer.Argument(help="Goal to run autonomously (use quotes)")],
    workspace: Annotated[str, typer.Option("--workspace", "-w")] = ".",
    interval: Annotated[int, typer.Option("--interval", "-i", help="Seconds between runs")] = 300,
    max_iterations: Annotated[int, typer.Option("--iterations", "-n")] = 3,
    github_repo: Annotated[str, typer.Option("--github", help="Watch GitHub repo (owner/name)")] = "",
    github_event: Annotated[str, typer.Option("--github-event")] = "issues",
    github_label: Annotated[str, typer.Option("--github-label")] = "",
    watch_file: Annotated[str, typer.Option("--file", help="Watch file for changes")] = "",
    runs: Annotated[int, typer.Option("--runs", help="Max run cycles (0=infinite)")] = 0,
) -> None:
    """Run the pipeline autonomously on a schedule or trigger.

    Examples:

      owlmind graph watch "fix all mypy errors" --interval 600

      owlmind graph watch "triage new issues" --github owner/repo --github-label bug
    """
    from owlmind.autonomous import AutonomousScheduler

    sched = AutonomousScheduler(workspace=workspace, max_iterations=max_iterations)

    def on_complete(record: object) -> None:
        from owlmind.autonomous import RunRecord
        assert isinstance(record, RunRecord)
        color = "green" if record.success else ("red" if record.error else "yellow")
        console.print(
            f"  [{color}]{'✓' if record.success else '✗'}[/{color}] "
            f"[{record.source}] verdict={record.verdict or 'n/a'} "
            f"goal={record.goal[:60]!r}"
        )

    sched._on_run_complete = on_complete  # type: ignore[attr-defined]

    if github_repo:
        sched.watch_github(github_repo, event=github_event, label=github_label)
        console.print(f"[cyan]GitHub watcher:[/cyan] {github_repo} [{github_event}]")
    if watch_file:
        sched.watch_file(watch_file)
        console.print(f"[cyan]File watcher:[/cyan] {watch_file}")
    if goal:
        sched.add_goal(goal)

    console.print(
        f"[bold]AutonomousScheduler[/bold] — interval={interval}s "
        f"workspace={workspace} max_iterations={max_iterations}"
    )
    console.print("Press Ctrl+C to stop.\n")

    if runs > 0:
        for cycle in range(runs):
            console.print(f"[dim]Cycle {cycle + 1}/{runs}[/dim]")
            for watcher in sched._github_watchers:  # type: ignore[attr-defined]
                sched._poll_github(watcher)  # type: ignore[attr-defined]
            sched._poll_files()  # type: ignore[attr-defined]
            sched.run_once()
            if cycle < runs - 1:
                import time
                time.sleep(interval)
    else:
        sched.run_blocking(interval=interval)


@graph_app.command("parallel")
def cmd_parallel(
    goals: Annotated[str, typer.Argument(help="Comma-separated subtask goals (or use --file)")],
    workspace: Annotated[str, typer.Option("--workspace", "-w")] = ".",
    workers: Annotated[int, typer.Option("--workers", "-j", help="Parallel workers")] = 3,
    max_iterations: Annotated[int, typer.Option("--iterations", "-n")] = 3,
    goals_file: Annotated[str, typer.Option("--file", "-f", help="File with one goal per line")] = "",
    skip_tester: Annotated[bool, typer.Option("--skip-tester")] = False,
) -> None:
    """Run multiple subtask goals in parallel (multi-agent).

    Example:
      owlmind graph parallel "fix type errors,add docstrings,update README"
      owlmind graph parallel --file goals.txt --workers 4
    """
    from owlmind.graph.parallel_runner import ParallelGraphRunner
    from owlmind.graph.runner import _build_llm_client

    if _build_llm_client() is None:
        console.print("[red]No LLM configured. Set OPENAI_API_KEY or ANTHROPIC_API_KEY in .env[/red]")
        raise typer.Exit(1) from None

    if goals_file:
        from pathlib import Path
        subtasks = [line.strip() for line in Path(goals_file).read_text().splitlines() if line.strip()]
    else:
        subtasks = [g.strip() for g in goals.split(",") if g.strip()]

    if not subtasks:
        console.print("[red]No goals provided[/red]")
        raise typer.Exit(1) from None

    console.print(f"[bold]Parallel Graph[/bold] — {len(subtasks)} subtask(s), {workers} workers")
    for i, s in enumerate(subtasks, 1):
        console.print(f"  {i}. {s[:80]}")
    console.print()

    runner = ParallelGraphRunner(workers=workers, max_iterations=max_iterations)
    result = runner.run_parallel(subtasks, workspace=workspace, skip_tester=skip_tester)

    console.print(f"\n[bold]Results[/bold] ({result.total_ms}ms total):")
    for s in result.subtasks:
        color = "green" if s.success else ("yellow" if not s.error else "red")
        icon = "✓" if s.success else "✗"
        console.print(f"  [{color}]{icon}[/{color}] [{s.verdict or s.error or 'unknown'}] {s.goal[:60]}")

    summary_color = "green" if result.all_approved else "yellow"
    console.print(f"\n[bold {summary_color}]{result.approved_count}/{len(result.subtasks)} approved[/bold {summary_color}]")


@graph_app.command("run-parallel")
def cmd_run_parallel(
    goals: Annotated[list[str], typer.Option("--goals", help="Goals to run in parallel (repeat flag or space-separated)")],
    workspace: Annotated[str, typer.Option("--workspace", "-w")] = ".",
    max_workers: Annotated[int, typer.Option("--workers", "-j", help="Max parallel workers")] = 3,
) -> None:
    """Run multiple goals in parallel using ParallelGraphRunner.

    Example:
      owlmind graph run-parallel --goals "fix lint errors" --goals "add type hints" --goals "write docstrings" --workspace .
    """
    import asyncio

    from owlmind.graph.parallel_runner import ParallelGraphRunner, ParallelTask
    from owlmind.graph.runner import _build_llm_client

    if _build_llm_client() is None:
        console.print("[red]No LLM configured. Set OPENAI_API_KEY or ANTHROPIC_API_KEY in .env[/red]")
        raise typer.Exit(1) from None

    if not goals:
        console.print("[red]No goals provided. Use --goals 'goal text'[/red]")
        raise typer.Exit(1) from None

    tasks = [ParallelTask(goal=g, workspace=workspace) for g in goals]

    console.print(f"[bold]Parallel Graph (run-parallel)[/bold] — {len(tasks)} task(s), {max_workers} workers")
    for i, t in enumerate(tasks, 1):
        console.print(f"  {i}. {t.goal[:80]}")
    console.print()

    runner = ParallelGraphRunner(max_workers=max_workers)
    results = asyncio.run(runner.run_all(tasks))

    from rich.table import Table

    table = Table(title="Results")
    table.add_column("#", style="dim")
    table.add_column("Verdict")
    table.add_column("Goal")
    table.add_column("Summary / Error")

    for i, r in enumerate(results, 1):
        if r.verdict == "APPROVED":
            verdict_display = "[green]APPROVED[/green]"
        elif r.verdict == "ERROR":
            verdict_display = "[red]ERROR[/red]"
        else:
            verdict_display = f"[yellow]{r.verdict}[/yellow]"
        detail = (r.error or r.summary or "")[:60]
        table.add_row(str(i), verdict_display, r.task.goal[:50], detail)

    console.print(table)

    approved = sum(1 for r in results if r.verdict == "APPROVED")
    color = "green" if approved == len(results) else "yellow"
    console.print(f"\n[bold {color}]{approved}/{len(results)} approved[/bold {color}]")


@graph_app.command("plan")
def cmd_plan(
    goal: Annotated[str, typer.Argument(help="Goal to plan")],
    workspace: Annotated[str, typer.Option("--workspace", "-w")] = ".",
) -> None:
    """Run only the Architect node to generate a plan."""
    from owlmind.graph.nodes import ArchitectNode
    from owlmind.graph.runner import _build_llm_client
    from owlmind.graph.state import GraphState

    client = _build_llm_client()
    if client is None:
        console.print("[red]No LLM configured. Set OPENAI_API_KEY or ANTHROPIC_API_KEY in .env[/red]")
        raise typer.Exit(1) from None

    state = GraphState(goal=goal, workspace=workspace)
    node = ArchitectNode("architect", client)
    result = node.run(state)

    console.print(Panel(result.output, title="[bold]Implementation Plan[/bold]", border_style="cyan"))


@graph_app.command("resume")
def cmd_resume(
    run_id: Annotated[str, typer.Argument(help="Run ID to resume")],
    max_iterations: Annotated[int, typer.Option("--iterations", "-n")] = 3,
    skip_tester: Annotated[bool, typer.Option("--skip-tester")] = False,
    verbose: Annotated[bool, typer.Option("--verbose", "-v")] = False,
) -> None:
    """Resume a previously paused or interrupted run by its run ID."""
    from owlmind.graph.runner import GraphRunner, _build_llm_client
    from owlmind.graph.state import NodeStatus

    if _build_llm_client() is None:
        console.print("[red]No LLM configured. Set OPENAI_API_KEY or ANTHROPIC_API_KEY in .env[/red]")
        raise typer.Exit(1) from None

    console.print(f"[bold]Resuming run[/bold] {run_id}")

    def on_node(result):
        icon = "[green]✓[/green]" if result.status == NodeStatus.DONE else "[red]✗[/red]"
        console.print(f"  {icon} [{result.node_name}] {result.duration_ms}ms")
        if verbose and result.output:
            console.print(Panel(result.output[:400], title=result.node_name, border_style="dim"))

    runner = GraphRunner(on_node_complete=on_node)
    try:
        state = runner.resume(
            run_id,
            max_iterations=max_iterations,
            skip_tester=skip_tester,
        )
    except ValueError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1) from None

    verdict_color = {"APPROVED": "green", "NEEDS_FIX": "yellow", "REJECTED": "red"}.get(
        state.final_verdict, "white"
    )
    console.print(f"\n[bold {verdict_color}]VERDICT: {state.final_verdict}[/bold {verdict_color}]")
    if state.review:
        console.print(Panel(state.review[:600], title="Reviewer", border_style=verdict_color))


@graph_app.command("sessions")
def cmd_sessions(
    status: Annotated[str, typer.Option("--status", help="Filter by status: running|paused|done")] = "",
) -> None:
    """List persisted graph sessions."""
    import time as _time

    from owlmind.graph.session_state import SessionStateStore

    store = SessionStateStore()
    sessions = store.list_sessions(status=status or None)

    if not sessions:
        console.print("[dim]No sessions found.[/dim]")
        return

    console.print(f"[bold]Sessions[/bold] ({len(sessions)} found):\n")
    for s in sessions:
        age = int(_time.time() - s.updated_at)
        status_color = {"running": "yellow", "paused": "cyan", "done": "green"}.get(s.status, "white")
        console.print(
            f"  [{status_color}]{s.status:8}[/{status_color}] "
            f"[bold]{s.run_id}[/bold]  "
            f"iter={s.iteration}  "
            f"age={age}s  "
            f"{s.goal[:60]}"
        )
