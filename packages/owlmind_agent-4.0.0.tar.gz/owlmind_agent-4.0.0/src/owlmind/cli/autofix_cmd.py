"""CLI command for auto-fixing CI failures."""
from __future__ import annotations

import typer

app = typer.Typer(help="Auto-fix CI failures")


@app.command("run")
def autofix_run(
    goal: str = typer.Argument(..., help="What to fix"),
    workspace: str = typer.Option(".", "--workspace", "-w"),
    branch: str = typer.Option("", "--branch"),
    pr_url: str = typer.Option("", "--pr-url"),
    auto_commit: bool = typer.Option(False, "--commit/--no-commit"),
    auto_push: bool = typer.Option(False, "--push/--no-push"),
) -> None:
    """Run autofix for a CI failure."""
    from owlmind.autofix import run_autofix

    result = run_autofix(
        goal=goal,
        workspace=workspace,
        branch=branch,
        pr_url=pr_url,
        auto_commit=auto_commit,
        auto_push=auto_push,
    )
    icon = "✅" if result.success else "❌"
    typer.echo(f"{icon} Verdict: {result.verdict}")
    if result.committed:
        typer.echo("  📝 Changes committed")
    if result.pushed:
        typer.echo("  🚀 Changes pushed")
    if result.error:
        typer.echo(f"  Error: {result.error}")
