"""Queue CLI subcommands — task queue management."""

from __future__ import annotations

import time
from pathlib import Path

import typer
from rich.table import Table

from owlmind import __version__

from ._helpers import (
    DEFAULT_LEDGER,
    DEFAULT_POLICIES,
    DEFAULT_QUEUE,
    DEFAULT_RUNS,
    console,
    make_cycle_manager,
)

queue_app = typer.Typer(
    name="queue",
    help="Task queue — add, list, and run queued tasks",
    no_args_is_help=True,
)


@queue_app.command("add")
def queue_add(
    goal: str = typer.Option(..., "--goal", "-g", help="Goal for the task"),
    workspace: Path = typer.Option(Path("."), "--workspace", "-w", help="Project workspace"),
    sandbox: bool = typer.Option(False, "--sandbox/--no-sandbox", help="Enable sandbox"),
    queue_dir: Path = typer.Option(DEFAULT_QUEUE, "--queue-dir", help="Queue directory"),
) -> None:
    """Add a task to the queue."""
    from owlmind.queue import TaskQueue

    console.print(f"[bold]OWLMIND v{__version__} — queue add[/bold]\n")

    q = TaskQueue(queue_dir)
    item = q.add(goal=goal, workspace=str(workspace.resolve()), sandbox=sandbox)

    console.print("[green]Task added to queue![/green]")
    console.print(f"  ID:        {item.id}")
    console.print(f"  Goal:      {item.goal}")
    console.print(f"  Workspace: {item.workspace}")
    console.print(f"  Sandbox:   {item.sandbox}")


@queue_app.command("list")
def queue_list(
    status: str = typer.Option(None, "--status", "-s", help="Filter by status"),
    queue_dir: Path = typer.Option(DEFAULT_QUEUE, "--queue-dir", help="Queue directory"),
) -> None:
    """List tasks in the queue."""
    from owlmind.queue import TaskQueue

    console.print(f"[bold]OWLMIND v{__version__} — queue list[/bold]\n")

    q = TaskQueue(queue_dir)
    items = q.list_items(status=status)

    if not items:
        console.print("[dim]Queue is empty.[/dim]")
        return

    table = Table(title="Task Queue")
    table.add_column("ID", style="bold")
    table.add_column("Status")
    table.add_column("Goal")
    table.add_column("Run ID")

    for item in items:
        status_color = {
            "PENDING": "yellow",
            "RUNNING": "blue",
            "DONE": "green",
            "FAILED": "red",
        }.get(item.status, "white")
        table.add_row(
            item.id,
            f"[{status_color}]{item.status}[/{status_color}]",
            item.goal[:50],
            item.run_id or "-",
        )

    console.print(table)


@queue_app.command("run")
def queue_run(
    once: bool = typer.Option(False, "--once", help="Run one task and exit"),
    daemon: bool = typer.Option(False, "--daemon", help="Run as daemon (polling loop)"),
    interval: int = typer.Option(10, "--interval", "-i", help="Daemon polling interval (seconds)"),
    queue_dir: Path = typer.Option(DEFAULT_QUEUE, "--queue-dir", help="Queue directory"),
    policies_dir: Path = typer.Option(DEFAULT_POLICIES, "--policies", "-p"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
) -> None:
    """Pick next pending task from queue and start a cycle."""
    from owlmind.queue import TaskQueue

    console.print(f"[bold]OWLMIND v{__version__} — queue run[/bold]\n")

    q = TaskQueue(queue_dir)

    def _run_one() -> bool:
        item = q.next_pending()
        if not item:
            console.print("[dim]No pending tasks.[/dim]")
            return False

        console.print(f"Running: [bold]{item.goal}[/bold]")
        _, _, mgr = make_cycle_manager(policies_dir, runs_dir)

        try:
            meta = mgr.start(
                goal=item.goal,
                workspace=item.workspace,
                sandbox=item.sandbox,
            )
            q.mark_running(item.id, meta.run_id)
            console.print(f"  [green]Started run: {meta.run_id}[/green]")
            return True
        except Exception as exc:
            q.mark_failed(item.id, str(exc))
            console.print(f"  [red]Failed: {exc}[/red]")
            return False

    if once:
        _run_one()
        return

    if daemon:
        console.print(f"[dim]Daemon mode, polling every {interval}s[/dim]\n")
        while True:
            from owlmind.config import OwlMindConfig
            from owlmind.ledger import UsageLedger

            cfg = OwlMindConfig.from_env()
            _ledger = UsageLedger(DEFAULT_LEDGER)
            _day = _ledger.totals_for_day()
            if (
                _day.total_tokens >= cfg.budget.max_tokens_per_day
                or _day.estimated_usd >= cfg.budget.max_usd_per_day
            ):
                console.print("[yellow]Daily budget exceeded, skipping.[/yellow]")
            else:
                _run_one()
            time.sleep(interval)
    else:
        console.print("[yellow]Use --once or --daemon flag.[/yellow]")
        raise typer.Exit(code=1)
