"""owlmind web — dashboard server commands."""
from __future__ import annotations

from typing import Annotated

import typer
from rich.console import Console

web_app = typer.Typer(name="web", help="Web dashboard for owlmind runs", no_args_is_help=True)
console = Console()


@web_app.command("serve")
def cmd_serve(
    port: Annotated[int, typer.Option("--port", "-p", envvar="PORT")] = 8080,
    host: Annotated[str, typer.Option("--host", envvar="HOST")] = "0.0.0.0",  # noqa: S104
    reload: Annotated[bool, typer.Option("--reload")] = False,
) -> None:
    """Start the web dashboard server."""
    try:
        import uvicorn
    except ImportError:
        console.print("[red]uvicorn not installed. Run: pip install uvicorn[/red]")
        raise typer.Exit(1) from None
    console.print(f"[bold]OwlMind Dashboard[/bold] → http://{host}:{port}")
    uvicorn.run("owlmind.web.app:app", host=host, port=port, reload=reload)
