"""CLI commands: config show, paths, completions."""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path
from typing import Any

import typer
from rich.console import Console
from rich.table import Table

from ._helpers import (
    DEFAULT_LEDGER,
    DEFAULT_POLICIES,
    DEFAULT_QUEUE,
    DEFAULT_RUNS,
    DEFAULT_SESSIONS,
)

config_app = typer.Typer(help="Configuration inspection and shell completions.")
console = Console()

# Fields that contain secrets and must be redacted
_SECRET_FIELDS = frozenset({"api_key", "bot_token"})


def _redact_dict(d: dict[str, Any], *, parent_key: str = "") -> dict[str, Any]:
    """Recursively redact secret fields in a dict."""
    out: dict[str, Any] = {}
    for k, v in d.items():
        if k in _SECRET_FIELDS:
            out[k] = "***" if v else ""
        elif isinstance(v, dict):
            out[k] = _redact_dict(v, parent_key=k)
        else:
            out[k] = v
    return out


def _resolve_config() -> dict[str, Any]:
    """Load config from env and return as redacted dict."""
    from owlmind.config import OwlMindConfig

    cfg = OwlMindConfig.from_env()
    return cfg.redacted_dict()


@config_app.command("show")
def config_show(
    as_json: bool = typer.Option(False, "--json", help="Output as JSON instead of table."),
) -> None:
    """Print resolved configuration (secrets redacted)."""
    data = _resolve_config()

    if as_json:
        console.print_json(json.dumps(data, indent=2, default=str))
        return

    for section, values in data.items():
        if isinstance(values, dict):
            table = Table(title=f"[bold]{section}[/bold]", show_header=True)
            table.add_column("Key", style="cyan")
            table.add_column("Value")
            for k, v in values.items():
                table.add_row(k, str(v))
            console.print(table)
            console.print()
        else:
            console.print(f"[bold]{section}:[/bold] {values}")


@config_app.command("paths")
def config_paths(
    workspace: Path = typer.Option(".", "-w", "--workspace", help="Workspace root."),
) -> None:
    """Print key OWLMIND directory paths."""
    ws = workspace.resolve()
    paths = {
        "workspace": ws,
        "runs": ws / DEFAULT_RUNS,
        "sessions": ws / DEFAULT_SESSIONS,
        "ledger": ws / DEFAULT_LEDGER,
        "policies": ws / DEFAULT_POLICIES,
        "queue": ws / DEFAULT_QUEUE,
        "reports": ws / "reports",
    }

    table = Table(title="OWLMIND Paths")
    table.add_column("Name", style="bold cyan")
    table.add_column("Path")
    table.add_column("Exists", justify="center")

    for name, path in paths.items():
        exists = "[green]\u2713[/green]" if path.exists() else "[red]\u2717[/red]"
        table.add_row(name, str(path), exists)

    console.print(table)


@config_app.command("completions")
def config_completions(
    shell: str = typer.Argument(
        ...,
        help="Shell type: bash, zsh, or fish.",
    ),
) -> None:
    """Generate shell completions for owlmind CLI.

    Pipe output to a file or source it directly:
        owlmind config completions bash > ~/.owlmind-complete.bash
        source ~/.owlmind-complete.bash
    """
    shell_name = shell.lower()
    if shell_name not in ("bash", "zsh", "fish"):
        console.print(f"[red]Unsupported shell: {shell_name}. Use bash, zsh, or fish.[/red]")
        raise typer.Exit(code=1)

    # Use Typer/Click's built-in completion via env var
    env_var = f"_OWLMIND_COMPLETE={shell_name}_source"
    result = subprocess.run(
        [sys.executable, "-m", "owlmind"],
        capture_output=True,
        text=True,
        timeout=15,
        env={**__import__("os").environ, env_var: "1"},
    )
    if result.stdout.strip():
        sys.stdout.write(result.stdout)
        if not result.stdout.endswith("\n"):
            sys.stdout.write("\n")
    else:
        console.print(f"[yellow]No completion output for {shell_name}.[/yellow]")
        raise typer.Exit(code=1)
