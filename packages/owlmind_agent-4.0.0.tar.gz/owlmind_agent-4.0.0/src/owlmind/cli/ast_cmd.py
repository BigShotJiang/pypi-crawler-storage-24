"""AST index CLI — index codebase for CodeRAG semantic search."""
from __future__ import annotations

from typing import Annotated

import typer
from rich.console import Console

from owlmind.tools.code_rag import CodeRAG

ast_app = typer.Typer(name="ast", help="AST-based codebase indexing for CodeRAG", no_args_is_help=True)
console = Console()


@ast_app.command("index")
def cmd_index(
    workspace: Annotated[str, typer.Option("--workspace", "-w")] = ".",
    force: Annotated[bool, typer.Option("--force", "-f", help="Re-index even if up to date")] = False,
    qdrant_url: Annotated[str, typer.Option("--qdrant-url", help="Qdrant URL (overrides QDRANT_URL env)")] = "",
) -> None:
    """Index workspace codebase for semantic code search (CodeRAG)."""
    kwargs: dict[str, str] = {}
    if qdrant_url:
        kwargs["qdrant_url"] = qdrant_url
    rag = CodeRAG(workspace=workspace, **kwargs)  # type: ignore[arg-type]
    console.print(f"[bold]Indexing[/bold] workspace: [cyan]{workspace}[/cyan]")
    stats = rag.index(force=force)
    if stats.error:
        console.print(f"[red]Indexing error:[/red] {stats.error}")
        raise typer.Exit(1)
    console.print(
        f"[green]Indexed[/green] {stats.files_indexed} files, "
        f"{stats.chunks_indexed} chunks via [bold]{stats.backend}[/bold] "
        f"in {stats.duration_ms}ms"
    )


@ast_app.command("search")
def cmd_search(
    query: Annotated[str, typer.Argument(help="Search query")],
    workspace: Annotated[str, typer.Option("--workspace", "-w")] = ".",
    top_k: Annotated[int, typer.Option("--top-k", "-k")] = 5,
) -> None:
    """Search indexed codebase semantically."""
    rag = CodeRAG(workspace=workspace)
    hits = rag.search(query, top_k=top_k)
    if not hits:
        console.print("[yellow]No results found.[/yellow]")
        return
    for hit in hits:
        header = f"[cyan]{hit.file}[/cyan]:{hit.line_start}-{hit.line_end}"
        if hit.symbol:
            header += f" ([bold]{hit.symbol}[/bold])"
        header += f"  score={hit.score:.3f}"
        console.print(header)
        console.print(hit.content[:300])
        console.print()


@ast_app.command("status")
def cmd_status(
    workspace: Annotated[str, typer.Option("--workspace", "-w")] = ".",
) -> None:
    """Show index status and stats."""
    rag = CodeRAG(workspace=workspace)
    backend = rag.backend()
    available = rag.is_available()
    console.print("[bold]CodeRAG Status[/bold]")
    console.print(f"  Workspace : [cyan]{workspace}[/cyan]")
    console.print(f"  Backend   : [bold]{backend}[/bold]")
    console.print(f"  Available : {'[green]yes[/green]' if available else '[red]no[/red]'}")
