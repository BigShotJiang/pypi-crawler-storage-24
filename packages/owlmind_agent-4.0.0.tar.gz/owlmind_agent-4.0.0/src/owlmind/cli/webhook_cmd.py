"""CLI commands for webhook management."""

from __future__ import annotations

import os

import typer
from rich.console import Console

from owlmind.webhook import WebhookConfig, WebhookNotifier, build_payload

webhook_app = typer.Typer(help="Webhook event delivery.")
console = Console()


def _load_webhook_config() -> WebhookConfig:
    """Load webhook config from environment."""
    allowlist_raw = os.environ.get("OWLMIND_WEBHOOK_ALLOWLIST_DOMAINS", "")
    allowlist = (
        [d.strip() for d in allowlist_raw.split(",") if d.strip()] if allowlist_raw.strip() else []
    )
    return WebhookConfig(
        enabled=os.environ.get("OWLMIND_WEBHOOK_ENABLED", "false").lower() == "true",
        url=os.environ.get("OWLMIND_WEBHOOK_URL", ""),
        secret=os.environ.get("OWLMIND_WEBHOOK_SECRET", ""),
        timeout_sec=int(os.environ.get("OWLMIND_WEBHOOK_TIMEOUT_SEC", "10")),
        max_retries=int(os.environ.get("OWLMIND_WEBHOOK_MAX_RETRIES", "3")),
        backoff_base=float(os.environ.get("OWLMIND_WEBHOOK_BACKOFF_BASE", "1.0")),
        allowlist_domains=allowlist,
    )


@webhook_app.command("status")
def cmd_status() -> None:
    """Show webhook configuration status (redacted)."""
    cfg = _load_webhook_config()
    console.print(f"[bold]Webhook enabled:[/bold] {cfg.enabled}")
    if cfg.url:
        console.print(f"[bold]Target host:[/bold] {cfg.hostname}")
    else:
        console.print("[dim]No URL configured[/dim]")
    if cfg.allowlist_domains:
        console.print(f"[bold]Allowlist:[/bold] {', '.join(cfg.allowlist_domains)}")
    console.print(f"[bold]Timeout:[/bold] {cfg.timeout_sec}s")
    console.print(f"[bold]Max retries:[/bold] {cfg.max_retries}")
    console.print(f"[bold]HMAC signing:[/bold] {'yes' if cfg.secret else 'no'}")


@webhook_app.command("test")
def cmd_test() -> None:
    """Send a test webhook event."""
    cfg = _load_webhook_config()
    if not cfg.enabled or not cfg.url:
        console.print(
            "[yellow]Webhook not configured. Set OWLMIND_WEBHOOK_ENABLED=true and OWLMIND_WEBHOOK_URL.[/yellow]"
        )
        raise typer.Exit(1)

    notifier = WebhookNotifier(config=cfg)
    result = notifier.send_event(
        "run_started",
        {
            "run_id": "test-webhook-001",
            "goal": "Webhook connectivity test",
        },
    )

    if result.get("sent"):
        console.print(
            f"[green]Test event sent successfully[/green] (status {result.get('status')})"
        )
    else:
        console.print(f"[red]Failed:[/red] {result.get('reason', 'unknown')}")
        raise typer.Exit(1)


@webhook_app.command("preview")
def cmd_preview(
    event: str = typer.Argument("run_started", help="Event name to preview"),
) -> None:
    """Preview a webhook payload (no network call)."""
    import json

    sample_data = {
        "run_id": "example-run-001",
        "goal": "Fix authentication bug",
        "status": "started",
    }
    payload = build_payload(event, sample_data)
    console.print_json(json.dumps(payload, indent=2, default=str))
