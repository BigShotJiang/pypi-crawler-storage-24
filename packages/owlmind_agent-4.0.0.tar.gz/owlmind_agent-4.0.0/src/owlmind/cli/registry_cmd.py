"""CLI commands for the private skill pack registry.

Provides search, install, publish, and admin commands for working with
the centralized private registry. All remote operations require
authentication via ``--token`` or ``OWLMIND_REGISTRY_TOKEN`` env var.

Usage::

    owlmind registry search "code review" --tag python --token cwrk_xxx
    owlmind registry install my-pack --version 1.0.0 --token cwrk_xxx
    owlmind registry publish my-pack.zip --token cwrk_xxx
    owlmind registry admin bootstrap --registry-db registry.db
"""

from __future__ import annotations

import asyncio
import io
import json
import os
import shutil
import zipfile
from pathlib import Path

import typer
from rich.table import Table

from ._helpers import console

registry_app = typer.Typer(
    name="registry",
    help="Private skill pack registry (search, install, publish, admin).",
    no_args_is_help=True,
)

admin_app = typer.Typer(
    name="admin",
    help="Registry admin commands (bootstrap, user management).",
    no_args_is_help=True,
)
registry_app.add_typer(admin_app, name="admin")


def _resolve_token(token: str) -> str:
    """Resolve registry token from argument or env var."""
    resolved = token or os.environ.get("OWLMIND_REGISTRY_TOKEN", "")
    if not resolved:
        console.print(
            "[red]Registry token required. Use --token or set OWLMIND_REGISTRY_TOKEN[/red]"
        )
        raise typer.Exit(code=1)
    return resolved


def _auth_headers(token: str) -> dict[str, str]:
    """Build auth headers for HTTP requests."""
    return {"X-Registry-Token": token}


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------


@registry_app.command("search")
def search_packs(
    query: str = typer.Argument("", help="Search query"),
    tag: list[str] = typer.Option([], "--tag", help="Filter by tag"),
    sort: str = typer.Option("downloads", help="Sort: downloads, rating, recent"),
    limit: int = typer.Option(20, help="Max results"),
    token: str = typer.Option(
        "", "--token", envvar="OWLMIND_REGISTRY_TOKEN", help="Registry token"
    ),
    registry_url: str = typer.Option("", "--registry-url", help="Remote registry URL"),
    registry_db: str = typer.Option("registry.db", "--registry-db", help="Local DB path"),
) -> None:
    """Search skill packs in the registry."""
    if registry_url:
        resolved = _resolve_token(token)
        _search_remote(query, tag, sort, limit, registry_url, resolved)
    else:
        _search_local(query, tag, sort, limit, registry_db)


def _search_remote(
    query: str, tags: list[str], sort: str, limit: int, base_url: str, token: str
) -> None:
    """Search packs via remote HTTP API."""
    import httpx

    params: dict[str, str | int] = {"q": query, "sort": sort, "limit": limit}
    for t in tags:
        params["tag"] = t

    url = f"{base_url.rstrip('/')}/api/v1/registry/packs"
    try:
        resp = httpx.get(url, params=params, headers=_auth_headers(token), timeout=30)
        resp.raise_for_status()
        packs = resp.json()
    except Exception as exc:
        console.print(f"[red]Error contacting registry: {exc}[/red]")
        raise typer.Exit(code=1) from None

    _display_packs(packs)


def _search_local(query: str, tags: list[str], sort: str, limit: int, registry_db: str) -> None:
    """Search packs in local SQLite database."""
    from owlmind.registry.public import SQLitePublicPackRegistry

    reg = SQLitePublicPackRegistry(registry_db)
    packs = asyncio.run(reg.search_packs(q=query, tags=tags or None, sort=sort, limit=limit))
    _display_packs(packs)


def _display_packs(packs: list[dict]) -> None:
    """Render packs as a rich table."""
    if not packs:
        console.print("[yellow]No packs found[/yellow]")
        return

    table = Table(title="Skill Packs", show_header=True, header_style="bold cyan")
    table.add_column("ID", style="bold")
    table.add_column("Name")
    table.add_column("Version")
    table.add_column("Downloads", justify="right")
    table.add_column("Rating", justify="right")
    table.add_column("Tags")

    for p in packs:
        rating = p.get("avg_rating", 0)
        rating_str = f"{rating:.1f} ({p.get('rating_count', 0)})" if rating else "-"
        table.add_row(
            p.get("pack_id", ""),
            p.get("name", ""),
            p.get("latest_version", "-"),
            str(p.get("downloads", 0)),
            rating_str,
            ", ".join(p.get("tags", [])),
        )

    console.print(table)


# ---------------------------------------------------------------------------
# Install
# ---------------------------------------------------------------------------


@registry_app.command("install")
def install_pack(
    pack_id: str = typer.Argument(..., help="Pack ID to install"),
    version: str = typer.Option("", "--version", help="Specific version (default: latest)"),
    token: str = typer.Option(
        "", "--token", envvar="OWLMIND_REGISTRY_TOKEN", help="Registry token"
    ),
    registry_url: str = typer.Option("", "--registry-url", help="Remote registry URL"),
    registry_db: str = typer.Option("registry.db", "--registry-db", help="Local DB path"),
    packs_dir: str = typer.Option("skill-packs", "--packs-dir", help="Installation directory"),
) -> None:
    """Install a skill pack from the registry."""
    target = Path(packs_dir) / pack_id

    if registry_url:
        resolved = _resolve_token(token)
        _install_remote(pack_id, version, registry_url, target, resolved)
    else:
        _install_local(pack_id, version, registry_db, target)


def _install_remote(pack_id: str, version: str, base_url: str, target: Path, token: str) -> None:
    """Download and install from remote registry."""
    import httpx

    headers = _auth_headers(token)

    if not version:
        url = f"{base_url.rstrip('/')}/api/v1/registry/packs/{pack_id}"
        try:
            resp = httpx.get(url, headers=headers, timeout=30)
            resp.raise_for_status()
            pack = resp.json()
            version = pack.get("latest_version", "")
        except Exception as exc:
            console.print(f"[red]Failed to get pack info: {exc}[/red]")
            raise typer.Exit(code=1) from None

    if not version:
        console.print("[red]Could not determine latest version[/red]")
        raise typer.Exit(code=1)

    download_url = f"{base_url.rstrip('/')}/api/v1/registry/packs/{pack_id}/download/{version}"
    try:
        resp = httpx.get(download_url, headers=headers, timeout=60, follow_redirects=True)
        resp.raise_for_status()
    except Exception as exc:
        console.print(f"[red]Download failed: {exc}[/red]")
        raise typer.Exit(code=1) from None

    _extract_zip(resp.content, target, pack_id, version)


def _install_local(pack_id: str, version: str, registry_db: str, target: Path) -> None:
    """Install from local registry archives."""
    from owlmind.registry.public import SQLitePublicPackRegistry

    reg = SQLitePublicPackRegistry(registry_db)

    if not version:
        pack = asyncio.run(reg.get_pack(pack_id))
        if not pack:
            console.print(f"[red]Pack '{pack_id}' not found[/red]")
            raise typer.Exit(code=1)
        version = pack.get("latest_version", "")

    if not version:
        console.print("[red]Could not determine latest version[/red]")
        raise typer.Exit(code=1)

    archive_path = Path("registry_archives") / pack_id / f"{version}.zip"
    if not archive_path.exists():
        console.print(f"[red]Archive not found: {archive_path}[/red]")
        raise typer.Exit(code=1)

    _extract_zip(archive_path.read_bytes(), target, pack_id, version)
    asyncio.run(reg.increment_downloads(pack_id))


def _extract_zip(data: bytes, target: Path, pack_id: str, version: str) -> None:
    """Extract ZIP archive to target directory."""
    if target.exists():
        shutil.rmtree(target)

    target.mkdir(parents=True, exist_ok=True)

    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
        zf.extractall(target)
        zf.close()
    except zipfile.BadZipFile:
        console.print("[red]Invalid ZIP archive[/red]")
        raise typer.Exit(code=1) from None

    console.print(f"[green]Installed:[/green] {pack_id} v{version} → {target}")


# ---------------------------------------------------------------------------
# Publish
# ---------------------------------------------------------------------------


@registry_app.command("publish")
def publish_pack(
    zip_file: str = typer.Argument(..., help="Path to ZIP archive"),
    token: str = typer.Option(
        "", "--token", envvar="OWLMIND_REGISTRY_TOKEN", help="Registry token"
    ),
    registry_url: str = typer.Option("", "--registry-url", help="Remote registry URL"),
    registry_db: str = typer.Option("registry.db", "--registry-db", help="Local DB path"),
    changelog: str = typer.Option("", help="Version changelog"),
) -> None:
    """Publish a skill pack to the registry."""
    path = Path(zip_file)
    if not path.exists():
        console.print(f"[red]File not found: {path}[/red]")
        raise typer.Exit(code=1)

    data = path.read_bytes()

    # Validate manifest locally first
    try:
        zf = zipfile.ZipFile(path)
        manifest_names = [n for n in zf.namelist() if n.endswith("manifest.json")]
        if not manifest_names:
            console.print("[red]ZIP must contain manifest.json[/red]")
            raise typer.Exit(code=1)

        manifest = json.loads(zf.read(manifest_names[0]))
        zf.close()
    except (zipfile.BadZipFile, json.JSONDecodeError) as exc:
        console.print(f"[red]Invalid archive: {exc}[/red]")
        raise typer.Exit(code=1) from None

    for field in ("id", "name", "version"):
        if field not in manifest:
            console.print(f"[red]manifest.json missing field: {field}[/red]")
            raise typer.Exit(code=1)

    if registry_url:
        resolved = _resolve_token(token)
        _publish_remote(data, manifest, registry_url, resolved, changelog)
    else:
        _publish_local(data, manifest, registry_db, changelog)


def _publish_remote(
    data: bytes,
    manifest: dict,
    base_url: str,
    token: str,
    changelog: str,
) -> None:
    """Upload pack to remote registry."""
    import httpx

    url = f"{base_url.rstrip('/')}/api/v1/registry/packs"

    try:
        resp = httpx.post(
            url,
            files={"archive": ("pack.zip", data, "application/zip")},
            data={
                "name": manifest.get("name", ""),
                "description": manifest.get("description", ""),
                "tags": json.dumps(manifest.get("tags", [])),
                "version": manifest.get("version", ""),
                "changelog": changelog,
                "author_name": manifest.get("author", ""),
            },
            headers=_auth_headers(token),
            timeout=60,
        )
        resp.raise_for_status()
        result = resp.json()
    except Exception as exc:
        console.print(f"[red]Publish failed: {exc}[/red]")
        raise typer.Exit(code=1) from None

    console.print(
        f"[green]Published:[/green] {result.get('name', '')} "
        f"(status: {result.get('status', 'pending')})"
    )


def _publish_local(data: bytes, manifest: dict, registry_db: str, changelog: str) -> None:
    """Publish pack to local registry."""
    import hashlib

    from owlmind.registry.models import PublishRequest
    from owlmind.registry.public import SQLitePublicPackRegistry

    reg = SQLitePublicPackRegistry(registry_db)
    pack_id = manifest["id"]

    req = PublishRequest(
        name=manifest.get("name", pack_id),
        description=manifest.get("description", ""),
        tags=manifest.get("tags", []),
        version=manifest.get("version", "0.1.0"),
        changelog=changelog,
        author_name=manifest.get("author", ""),
    )

    result = asyncio.run(reg.publish_pack(pack_id, req))

    # Store archive locally
    archive_dir = Path("registry_archives") / pack_id
    archive_dir.mkdir(parents=True, exist_ok=True)
    archive_path = archive_dir / f"{req.version}.zip"
    archive_path.write_bytes(data)

    sha256 = hashlib.sha256(data).hexdigest()
    asyncio.run(
        reg.add_version(
            pack_id=pack_id,
            version=req.version,
            archive_sha256=sha256,
            archive_size=len(data),
            changelog=changelog,
        )
    )

    console.print(
        f"[green]Published:[/green] {result.get('name', '')} v{req.version} "
        f"(status: {result.get('status', 'pending')})"
    )


# ---------------------------------------------------------------------------
# Admin commands
# ---------------------------------------------------------------------------


@admin_app.command("bootstrap")
def admin_bootstrap(
    registry_db: str = typer.Option("registry.db", "--registry-db", help="Local DB path"),
    username: str = typer.Option("admin", "--username", help="Admin username"),
    email: str = typer.Option("", "--email", help="Admin email"),
) -> None:
    """Create the first admin user (only works if no users exist)."""
    import secrets

    from owlmind.api.registry_auth import hash_api_key
    from owlmind.registry.public import SQLitePublicPackRegistry

    reg = SQLitePublicPackRegistry(registry_db)
    users = asyncio.run(reg.list_users(include_inactive=True))
    if users:
        console.print("[yellow]Users already exist. Bootstrap skipped.[/yellow]")
        return

    raw_key = "cwrk_" + secrets.token_urlsafe(32)
    key_hash = hash_api_key(raw_key)

    user = asyncio.run(
        reg.create_user(username=username, email=email, role="admin", api_key_hash=key_hash)
    )

    console.print(f"[green]Admin created:[/green] {user['username']} ({user['user_id']})")
    console.print("[bold yellow]API Key (save it — shown only once):[/bold yellow]")
    console.print(f"  {raw_key}")


@admin_app.command("create-user")
def admin_create_user(
    username: str = typer.Argument(..., help="Username"),
    role: str = typer.Option("user", "--role", help="Role: user or admin"),
    email: str = typer.Option("", "--email", help="Email"),
    token: str = typer.Option("", "--token", envvar="OWLMIND_REGISTRY_TOKEN", help="Admin token"),
    registry_url: str = typer.Option("", "--registry-url", help="Remote registry URL"),
    registry_db: str = typer.Option("registry.db", "--registry-db", help="Local DB path"),
) -> None:
    """Create a new registry user (admin only)."""
    if registry_url:
        resolved = _resolve_token(token)
        _create_user_remote(username, role, email, registry_url, resolved)
    else:
        _create_user_local(username, role, email, registry_db)


def _create_user_remote(username: str, role: str, email: str, base_url: str, token: str) -> None:
    """Create user via remote API."""
    import httpx

    url = f"{base_url.rstrip('/')}/api/v1/registry/admin/users"
    try:
        resp = httpx.post(
            url,
            json={"username": username, "role": role, "email": email},
            headers=_auth_headers(token),
            timeout=30,
        )
        resp.raise_for_status()
        data = resp.json()
    except Exception as exc:
        console.print(f"[red]Failed to create user: {exc}[/red]")
        raise typer.Exit(code=1) from None

    console.print(f"[green]User created:[/green] {data['user']['username']}")
    console.print("[bold yellow]API Key (save it — shown only once):[/bold yellow]")
    console.print(f"  {data['api_key']}")


def _create_user_local(username: str, role: str, email: str, registry_db: str) -> None:
    """Create user directly in local DB."""
    import secrets

    from owlmind.api.registry_auth import hash_api_key
    from owlmind.registry.public import SQLitePublicPackRegistry

    reg = SQLitePublicPackRegistry(registry_db)
    raw_key = "cwrk_" + secrets.token_urlsafe(32)
    key_hash = hash_api_key(raw_key)

    try:
        user = asyncio.run(
            reg.create_user(username=username, email=email, role=role, api_key_hash=key_hash)
        )
    except Exception as exc:
        if "UNIQUE" in str(exc):
            console.print(f"[red]Username '{username}' already exists[/red]")
            raise typer.Exit(code=1) from None
        raise

    console.print(f"[green]User created:[/green] {user['username']} (role: {user['role']})")
    console.print("[bold yellow]API Key (save it — shown only once):[/bold yellow]")
    console.print(f"  {raw_key}")


@admin_app.command("list-users")
def admin_list_users(
    include_inactive: bool = typer.Option(
        False, "--include-inactive", help="Show deactivated users"
    ),
    token: str = typer.Option("", "--token", envvar="OWLMIND_REGISTRY_TOKEN", help="Admin token"),
    registry_url: str = typer.Option("", "--registry-url", help="Remote registry URL"),
    registry_db: str = typer.Option("registry.db", "--registry-db", help="Local DB path"),
) -> None:
    """List registry users (admin only)."""
    if registry_url:
        resolved = _resolve_token(token)
        _list_users_remote(include_inactive, registry_url, resolved)
    else:
        _list_users_local(include_inactive, registry_db)


def _list_users_remote(include_inactive: bool, base_url: str, token: str) -> None:
    """List users via remote API."""
    import httpx

    url = f"{base_url.rstrip('/')}/api/v1/registry/admin/users"
    params = {"include_inactive": str(include_inactive).lower()}
    try:
        resp = httpx.get(url, params=params, headers=_auth_headers(token), timeout=30)
        resp.raise_for_status()
        users = resp.json()
    except Exception as exc:
        console.print(f"[red]Failed to list users: {exc}[/red]")
        raise typer.Exit(code=1) from None

    _display_users(users)


def _list_users_local(include_inactive: bool, registry_db: str) -> None:
    """List users from local DB."""
    from owlmind.registry.public import SQLitePublicPackRegistry

    reg = SQLitePublicPackRegistry(registry_db)
    users = asyncio.run(reg.list_users(include_inactive=include_inactive))
    _display_users(users)


def _display_users(users: list[dict]) -> None:
    """Render users as a rich table."""
    if not users:
        console.print("[yellow]No users found[/yellow]")
        return

    table = Table(title="Registry Users", show_header=True, header_style="bold cyan")
    table.add_column("User ID", style="bold")
    table.add_column("Username")
    table.add_column("Email")
    table.add_column("Role")
    table.add_column("Active")
    table.add_column("Created")

    for u in users:
        active = "[green]yes[/green]" if u.get("is_active", True) else "[red]no[/red]"
        table.add_row(
            u.get("user_id", ""),
            u.get("username", ""),
            u.get("email", ""),
            u.get("role", ""),
            active,
            u.get("created_at", ""),
        )

    console.print(table)


@admin_app.command("deactivate-user")
def admin_deactivate_user(
    user_id: str = typer.Argument(..., help="User ID to deactivate"),
    token: str = typer.Option("", "--token", envvar="OWLMIND_REGISTRY_TOKEN", help="Admin token"),
    registry_url: str = typer.Option("", "--registry-url", help="Remote registry URL"),
    registry_db: str = typer.Option("registry.db", "--registry-db", help="Local DB path"),
) -> None:
    """Deactivate a registry user (admin only)."""
    if registry_url:
        resolved = _resolve_token(token)
        _deactivate_user_remote(user_id, registry_url, resolved)
    else:
        _deactivate_user_local(user_id, registry_db)


def _deactivate_user_remote(user_id: str, base_url: str, token: str) -> None:
    """Deactivate user via remote API."""
    import httpx

    url = f"{base_url.rstrip('/')}/api/v1/registry/admin/users/{user_id}/deactivate"
    try:
        resp = httpx.post(url, headers=_auth_headers(token), timeout=30)
        resp.raise_for_status()
    except Exception as exc:
        console.print(f"[red]Failed to deactivate user: {exc}[/red]")
        raise typer.Exit(code=1) from None

    console.print(f"[green]Deactivated:[/green] {user_id}")


def _deactivate_user_local(user_id: str, registry_db: str) -> None:
    """Deactivate user in local DB."""
    from owlmind.registry.public import SQLitePublicPackRegistry

    reg = SQLitePublicPackRegistry(registry_db)
    ok = asyncio.run(reg.deactivate_user(user_id))
    if not ok:
        console.print(f"[red]User '{user_id}' not found[/red]")
        raise typer.Exit(code=1)
    console.print(f"[green]Deactivated:[/green] {user_id}")
