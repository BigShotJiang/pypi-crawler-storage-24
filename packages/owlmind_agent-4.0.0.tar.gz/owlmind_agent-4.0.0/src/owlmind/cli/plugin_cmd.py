"""CLI commands for plugin management."""

from __future__ import annotations

import typer
from rich.console import Console
from rich.table import Table

plugin_app = typer.Typer(help="Plugin management commands.")
console = Console()


@plugin_app.command("list")
def plugin_list() -> None:
    """List installed OWLMIND plugins."""
    from owlmind.plugins import PluginRegistry

    registry = PluginRegistry()
    discovered = registry.discover()

    if not discovered:
        console.print("[dim]No plugins discovered.[/dim]")
        return

    # Load all to get full info
    registry.load_all()
    plugins = registry.list_plugins()

    table = Table(title="OWLMIND Plugins")
    table.add_column("Name", style="cyan")
    table.add_column("Version", style="green")
    table.add_column("Hooks", style="yellow")

    for p in plugins:
        hooks_str = ", ".join(p["hooks"]) if p["hooks"] else "-"
        table.add_row(p["name"], p["version"], hooks_str)

    console.print(table)


@plugin_app.command("info")
def plugin_info(
    name: str = typer.Argument(help="Plugin name to inspect."),
) -> None:
    """Show detailed information about a plugin."""
    from owlmind.plugins import PluginRegistry

    registry = PluginRegistry()
    registry.discover()

    plugin = registry.load(name)
    if plugin is None:
        console.print(f"[red]Plugin {name!r} not found or failed to load.[/red]")
        raise typer.Exit(code=1)

    info = registry.list_plugins()
    details = next((p for p in info if p["name"] == name), None)
    if details is None:
        console.print(f"[red]Plugin {name!r} metadata unavailable.[/red]")
        raise typer.Exit(code=1)

    console.print(f"[bold]Plugin:[/bold] [cyan]{details['name']}[/cyan]")
    console.print(f"[bold]Version:[/bold] {details['version']}")
    console.print(f"[bold]Description:[/bold] {details['description'] or '(none)'}")
    console.print("[bold]Hooks:[/bold]")
    if details["hooks"]:
        for hook in details["hooks"]:
            console.print(f"  - {hook}")
    else:
        console.print("  (none)")
