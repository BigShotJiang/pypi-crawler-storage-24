"""Skills CLI subcommands — list, show, and install skill packs."""

from __future__ import annotations

from pathlib import Path

import typer
from rich.table import Table

from owlmind.skills.registry import list_packs, load_pack

from ._helpers import DEFAULT_RUNS, console

skills_app = typer.Typer(
    name="skills",
    help="Manage skill packs (list, show, install).",
    no_args_is_help=True,
)

_DEFAULT_PACKS = Path("skill-packs")


@skills_app.command("list")
def skills_list(
    packs_dir: Path = typer.Option(_DEFAULT_PACKS, "--packs-dir", help="Skill packs directory"),
) -> None:
    """List all available skill packs."""
    packs = list_packs(packs_dir)
    if not packs:
        console.print("[yellow]No skill packs found in[/yellow] " + str(packs_dir))
        return

    table = Table(title="Skill Packs", show_header=True, header_style="bold cyan")
    table.add_column("ID", style="bold")
    table.add_column("Version")
    table.add_column("Name")
    table.add_column("Description")
    table.add_column("Tags")

    for pack in packs:
        table.add_row(
            pack["id"],
            pack["version"],
            pack["name"],
            pack["description"],
            ", ".join(pack.get("tags", [])),
        )

    console.print(table)


@skills_app.command("show")
def skills_show(
    pack_id: str = typer.Argument(..., help="Pack ID to show"),
    packs_dir: Path = typer.Option(_DEFAULT_PACKS, "--packs-dir", help="Skill packs directory"),
) -> None:
    """Show details for a skill pack."""
    try:
        pack = load_pack(pack_id, packs_dir)
    except FileNotFoundError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1) from None

    pack_dir: Path = pack["pack_dir"]

    console.print(f"\n[bold cyan]Skill Pack: {pack.get('name', pack_id)}[/bold cyan]")
    console.print(f"  ID:          {pack.get('id', pack_id)}")
    console.print(f"  Version:     {pack.get('version', '?')}")
    console.print(f"  Description: {pack.get('description', '')}")
    console.print(f"  Tags:        {', '.join(pack.get('tags', []))}")
    console.print(f"  Pack dir:    {pack_dir}")

    # List files
    console.print("\n[bold]Files:[/bold]")
    for fpath in sorted(pack_dir.rglob("*")):
        if fpath.is_file():
            rel = fpath.relative_to(pack_dir)
            console.print(f"  {rel}")

    knowledge_dir_rel: str = pack.get("knowledge_dir", f"knowledge/{pack_id}")
    repo_root = pack_dir.parent.parent
    knowledge_dir = repo_root / knowledge_dir_rel
    if knowledge_dir.is_dir():
        console.print(f"\n[bold]Knowledge ({knowledge_dir_rel}):[/bold]")
        for fpath in sorted(knowledge_dir.iterdir()):
            if fpath.is_file():
                console.print(f"  {fpath.name}")


@skills_app.command("install")
def skills_install(
    pack_id: str = typer.Argument(..., help="Pack ID to install"),
    workspace: Path = typer.Option(
        Path("."), "--workspace", "-w", help="Target workspace directory"
    ),
    packs_dir: Path = typer.Option(_DEFAULT_PACKS, "--packs-dir", help="Skill packs directory"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r", help="Runs directory for evidence"),
    memory_db: Path = typer.Option(
        Path("memory/memory.db"), "--memory-db", help="Memory store DB path"
    ),
    no_memory: bool = typer.Option(False, "--no-memory", help="Skip memory ingestion"),
) -> None:
    """Install a skill pack into workspace and ingest into memory."""
    from owlmind.evidence import EvidenceStore
    from owlmind.memory.store import MemoryStore
    from owlmind.skills.installer import install

    console.print(f"[bold]Installing skill pack:[/bold] {pack_id}")
    console.print(f"  Workspace:  {workspace.resolve()}")
    console.print(f"  Memory DB:  {memory_db}")

    mem_store: MemoryStore | None = None
    if not no_memory:
        try:
            mem_store = MemoryStore(memory_db)
        except Exception as exc:
            console.print(f"[yellow]Warning: could not open memory store: {exc}[/yellow]")

    evidence = EvidenceStore(runs_dir)
    import uuid

    run_id = f"skill-install-{uuid.uuid4().hex[:12]}"
    evidence.create_run(run_id)

    try:
        result = install(
            pack_id,
            workspace.resolve(),
            base_dir=packs_dir,
            memory_store=mem_store,
            evidence_store=evidence,
            run_id=run_id,
        )
    except FileNotFoundError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1) from None
    finally:
        if mem_store is not None:
            mem_store.close()

    console.print(f"\n[green]Installed:[/green] {result['pack_id']}")
    console.print(f"  Ingested docs: {result['ingested_docs']}")
    console.print(f"  Evidence run:  {run_id}")
    key_hashes = result.get("key_file_hashes") or {}
    if key_hashes and isinstance(key_hashes, dict):
        console.print("  Key file hashes:")
        for fname, fhash in key_hashes.items():
            console.print(f"    {fname}: {str(fhash)[:16]}...")
