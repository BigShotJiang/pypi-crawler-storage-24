"""Integrations CLI — manage and test external tool integrations."""
from __future__ import annotations

from typing import Annotated

import typer
from rich.console import Console
from rich.table import Table

integrations_app = typer.Typer(name="integrations", help="External integrations — Slack, Notion, Linear, and more", no_args_is_help=True)
console = Console()


@integrations_app.command("list")
def cmd_list(
    category: Annotated[str, typer.Option("--category", "-c")] = "",
    available: Annotated[bool, typer.Option("--available")] = False,
) -> None:
    """List all available integration tools."""
    from owlmind.integrations import register_all_tools
    reg = register_all_tools()

    tools = reg.list_tools(category=category or None, available_only=available)

    table = Table(title=f"Integration Tools ({len(tools)} total)", show_lines=False)
    table.add_column("Name", style="bold cyan")
    table.add_column("Category", style="dim")
    table.add_column("Available")
    table.add_column("Description")

    for tool in tools:
        avail = "[green]✓[/green]" if tool.is_available() else "[red]✗[/red]"
        table.add_row(tool.name, tool.category, avail, tool.description[:60])

    console.print(table)

    if not available:
        unavail = [t for t in tools if not t.is_available()]
        if unavail:
            console.print(f"\n[dim]{len(unavail)} tools unavailable — set required env vars to enable them[/dim]")


@integrations_app.command("call")
def cmd_call(
    tool_name: Annotated[str, typer.Argument(help="Tool name to call")],
    args_json: Annotated[str, typer.Option("--args", "-a", help="JSON arguments")] = "{}",
) -> None:
    """Call an integration tool directly."""
    import json

    from owlmind.integrations import register_all_tools

    reg = register_all_tools()
    try:
        args = json.loads(args_json)
    except json.JSONDecodeError as e:
        console.print(f"[red]Invalid JSON args: {e}[/red]")
        raise typer.Exit(1) from None

    console.print(f"Calling [cyan]{tool_name}[/cyan]...")
    result = reg.call(tool_name, **args)

    if "error" in result:
        console.print(f"[red]Error: {result['error']}[/red]")
        raise typer.Exit(1) from None

    import json as _json
    console.print_json(_json.dumps(result, default=str))


@integrations_app.command("slack-send")
def cmd_slack_send(
    channel: Annotated[str, typer.Argument(help="Channel name or ID")],
    message: Annotated[str, typer.Argument(help="Message text")],
) -> None:
    """Send a message to Slack."""
    from owlmind.integrations.slack_tools import slack_send_message
    result = slack_send_message(channel, message)
    console.print(f"[green]✓ Sent to {channel}[/green] (ts={result.get('ts', '?')})")


@integrations_app.command("notion-search")
def cmd_notion_search(
    query: Annotated[str, typer.Argument(help="Search query")],
) -> None:
    """Search Notion workspace."""
    from owlmind.integrations.notion_tools import notion_search
    result = notion_search(query)
    for item in result["results"]:
        console.print(f"  [{item['type']}] [bold]{item['title']}[/bold] — {item['url']}")
    console.print(f"\n[dim]{result['count']} results[/dim]")
