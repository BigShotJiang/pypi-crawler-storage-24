"""Core CLI commands — doctor, run, show, replay, heartbeat."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import typer
from rich.table import Table

from owlmind import __version__
from owlmind.contracts import TaskSpec
from owlmind.engine.orchestrator import Orchestrator
from owlmind.evidence import EvidenceStore
from owlmind.policy import PolicyEngine
from owlmind.utils import ToolLimits

from ._helpers import (
    DEFAULT_POLICIES,
    DEFAULT_QUEUE,
    DEFAULT_RUNS,
    console,
)


def register(app: typer.Typer) -> None:
    """Register core commands on the app."""

    @app.command()
    def doctor(
        policies_dir: Path = typer.Option(
            DEFAULT_POLICIES, "--policies", "-p", help="Policies dir"
        ),
        preflight: bool = typer.Option(
            False, "--preflight", help="Run preflight checks (deps/env/binaries)"
        ),
        extended: bool = typer.Option(
            False, "--extended", help="Run extended diagnostics (providers, policies, deps, .env)"
        ),
        fix: bool = typer.Option(
            False, "--fix", help="Auto-fix safe local issues (dirs, .env.example)"
        ),
        workspace: Path = typer.Option(".", "--workspace", "-w", help="Workspace for --fix"),
    ) -> None:
        """Check that all components are healthy."""
        console.print(f"[bold]OWLMIND v{__version__} — doctor[/bold]\n")

        checks: list[tuple[str, bool, str]] = []

        py_ok = sys.version_info >= (3, 11)
        checks.append(
            ("Python >= 3.11", py_ok, f"{sys.version_info.major}.{sys.version_info.minor}")
        )

        pol_ok = policies_dir.exists()
        checks.append(("Policies directory", pol_ok, str(policies_dir)))

        al_path = policies_dir / "allowlist.yaml"
        al_ok = al_path.exists()
        checks.append(("allowlist.yaml", al_ok, str(al_path)))

        po_path = policies_dir / "policy.yaml"
        po_ok = po_path.exists()
        checks.append(("policy.yaml", po_ok, str(po_path)))

        jr_path = policies_dir / "judge_rules.yaml"
        jr_ok = jr_path.exists()
        checks.append(("judge_rules.yaml", jr_ok, str(jr_path)))

        engine_ok = False
        engine_msg = ""
        if al_ok or po_ok:
            try:
                engine = PolicyEngine.from_directory(policies_dir)
                engine_ok = True
                engine_msg = (
                    f"{len(engine.allowed_patterns)} allowed, "
                    f"{len(engine.forbidden_patterns)} forbidden"
                )
            except Exception as exc:
                engine_msg = str(exc)
        checks.append(("PolicyEngine loads", engine_ok, engine_msg))

        table = Table(title="Health Check")
        table.add_column("Check", style="bold")
        table.add_column("Status")
        table.add_column("Details")

        all_ok = True
        for name, ok, detail in checks:
            status = "[green]OK[/green]" if ok else "[red]FAIL[/red]"
            if not ok:
                all_ok = False
            table.add_row(name, status, detail)

        console.print(table)

        if fix:
            _run_doctor_fix(workspace)

        if preflight:
            _run_doctor_preflight()

        if preflight and extended:
            _run_doctor_extended(policies_dir)

        if all_ok:
            console.print("\n[bold green]All checks passed![/bold green]")
        else:
            console.print("\n[bold red]Some checks failed.[/bold red]")
            raise typer.Exit(code=1)

    @app.command()
    def run(
        task_file: Path = typer.Argument(..., help="Path to task JSON file"),
        policies_dir: Path = typer.Option(DEFAULT_POLICIES, "--policies", "-p"),
        runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
        project_dir: Path = typer.Option(Path("."), "--project", "-d"),
    ) -> None:
        """Execute a task from a JSON file."""
        console.print(f"[bold]OWLMIND v{__version__} — run[/bold]\n")

        if not task_file.exists():
            console.print(f"[red]Task file not found: {task_file}[/red]")
            raise typer.Exit(code=1)

        task_data = json.loads(task_file.read_text())
        task = TaskSpec(**task_data)
        console.print(f"Task: [bold]{task.goal}[/bold]  ({len(task.actions)} actions)")

        policy = PolicyEngine.from_directory(policies_dir)
        evidence = EvidenceStore(runs_dir)
        limits = ToolLimits()

        orchestrator = Orchestrator(
            policy=policy,
            evidence=evidence,
            project_dir=project_dir,
            limits=limits,
        )

        console.print("\n[dim]Running...[/dim]\n")
        summary = orchestrator.run(task)

        state_color = "green" if summary.state.value == "DONE" else "red"
        console.print(f"\n[bold {state_color}]Result: {summary.state.value}[/bold {state_color}]")
        console.print(f"  Actions executed: {summary.actions_executed}")
        console.print(f"  Actions failed:   {summary.actions_failed}")
        console.print(f"  Run ID:           {orchestrator.run_id}")
        console.print(f"  Evidence dir:     {runs_dir / orchestrator.run_id}")

    @app.command()
    def show(
        run_id: str = typer.Argument(..., help="Run ID to inspect"),
        runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
    ) -> None:
        """Show details of a completed run."""
        console.print(f"[bold]OWLMIND v{__version__} — show[/bold]\n")

        evidence = EvidenceStore(runs_dir)
        meta = evidence.read_meta(run_id)
        if not meta:
            console.print(f"[red]Run not found: {run_id}[/red]")
            raise typer.Exit(code=1)

        console.print(f"[bold]Run:[/bold] {run_id}")
        console.print(f"[bold]Task:[/bold] {meta.get('task_id', '?')}")
        console.print(f"[bold]Goal:[/bold] {meta.get('goal', '?')}")
        console.print(f"[bold]Started:[/bold] {meta.get('started_at', '?')}")

        summary_data = evidence.read_summary(run_id)
        if summary_data:
            report = summary_data.get("report", {})
            console.print(f"\n[bold]Status:[/bold] {report.get('status', '?')}")
            for cmd in report.get("commands_run", []):
                exit_code = cmd.get("exit_code", "?")
                color = "green" if exit_code == 0 else "red"
                console.print(f"  [{color}]{cmd.get('cmd', '?')} -> exit {exit_code}[/{color}]")

        events = evidence.read_events(run_id)
        console.print(f"\n[dim]({len(events)} events in log)[/dim]")

    @app.command()
    def replay(
        run_id: str = typer.Argument(..., help="Run ID to replay"),
        runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
    ) -> None:
        """Replay events from a previous run (read-only)."""
        console.print(f"[bold]OWLMIND v{__version__} — replay[/bold]\n")

        evidence = EvidenceStore(runs_dir)
        events = evidence.read_events(run_id)

        if not events:
            console.print(f"[red]No events found for run: {run_id}[/red]")
            raise typer.Exit(code=1)

        for i, event in enumerate(events, 1):
            ts = event.get("timestamp", "?")
            evt_type = event.get("event", "unknown")
            details = {
                k: v
                for k, v in event.items()
                if k not in ("timestamp", "event", "_seq", "_prev_hash", "_hash")
            }
            console.print(f"[dim]{i:3d}[/dim] [{ts}] [bold]{evt_type}[/bold]")
            if details:
                for k, v in details.items():
                    console.print(f"      {k}: {v}")

    @app.command()
    def heartbeat(
        interval: int = typer.Option(10, "--interval", "-i", help="Seconds between checks"),
        once: bool = typer.Option(False, "--once", help="Run one tick and exit"),
        auto_queue: bool = typer.Option(
            False, "--auto-queue", help="Auto-start pending queue items"
        ),
        policies_dir: Path = typer.Option(DEFAULT_POLICIES, "--policies", "-p"),
        runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
        queue_dir: Path = typer.Option(DEFAULT_QUEUE, "--queue-dir", help="Queue directory"),
    ) -> None:
        """Run the heartbeat engine — monitors queue, stuck runs, approvals."""
        from owlmind.config import HeartbeatConfig
        from owlmind.events import EventBus
        from owlmind.heartbeat import HeartbeatEngine
        from owlmind.queue import TaskQueue

        console.print(f"[bold]OWLMIND v{__version__} — heartbeat[/bold]\n")

        config = HeartbeatConfig(interval_seconds=interval)
        q = TaskQueue(queue_dir)
        bus = EventBus()

        engine = HeartbeatEngine(
            config=config,
            queue=q,
            event_bus=bus,
            policies_dir=policies_dir,
            runs_dir=runs_dir,
        )

        if once:
            messages = engine.tick(auto_start=auto_queue)
            if messages:
                for msg in messages:
                    console.print(f"  {msg}")
            else:
                console.print("[dim]Nothing to report.[/dim]")
            return

        console.print(
            f"[dim]Running heartbeat (interval={interval}s, auto_queue={auto_queue})[/dim]\n"
        )
        try:
            engine.run_loop(auto_start=auto_queue)
        except KeyboardInterrupt:
            console.print("\n[yellow]Heartbeat stopped.[/yellow]")


def _run_doctor_fix(workspace: Path) -> None:
    """Apply safe auto-fixes and print results."""
    from owlmind.setup import doctor_fix

    console.print("\n[bold]Auto-fix (safe only)[/bold]\n")
    report = doctor_fix(workspace)

    for f in report.fixes:
        status = "[green]OK[/green]" if f.fixed else "[red]FAIL[/red]"
        console.print(f"  {status} {f.name}: {f.detail}")

    for w in report.warnings:
        console.print(f"  [yellow]WARN[/yellow] {w}")


def _run_doctor_preflight() -> None:
    """Run preflight in dry mode (no network) and print summary."""
    from owlmind.preflight import PreflightConfig, run_preflight

    console.print("\n[bold]Preflight Checks[/bold]\n")

    pf_config = PreflightConfig(
        use_llm="both",
        use_worker="claude_cli",
        workspace=".",
    )
    report = run_preflight(pf_config)

    pf_table = Table(title="Preflight")
    pf_table.add_column("Check", style="bold")
    pf_table.add_column("Status")
    pf_table.add_column("Details")

    for check in report.checks:
        status = "[green]OK[/green]" if check.ok else "[red]FAIL[/red]"
        pf_table.add_row(check.name, status, check.details)

    console.print(pf_table)

    if report.missing_env:
        console.print(f"\n[yellow]Missing env vars: {', '.join(report.missing_env)}[/yellow]")
    if report.missing_deps:
        console.print(f"[yellow]Missing deps: {', '.join(report.missing_deps)}[/yellow]")
    if report.recommended_installs:
        console.print("[dim]Recommended installs:[/dim]")
        for cmd in report.recommended_installs:
            console.print(f"  {cmd}")
    if report.missing_binaries:
        console.print(f"[yellow]Missing binaries: {', '.join(report.missing_binaries)}[/yellow]")


def _run_doctor_extended(policies_dir: Path) -> None:
    """Run extended diagnostics (providers, policies, budget, deps, .env)."""
    from owlmind.config import OwlMindConfig
    from owlmind.diag_extended import run_extended_doctor

    console.print("\n[bold]Extended Diagnostics[/bold]\n")

    cfg = OwlMindConfig.from_env()
    checks = run_extended_doctor(cfg, policies_dir)

    ext_table = Table(title="Extended Checks")
    ext_table.add_column("Check", style="bold")
    ext_table.add_column("Category", style="dim")
    ext_table.add_column("Status")
    ext_table.add_column("Details")
    ext_table.add_column("Fix Hint", style="dim")

    ext_all_ok = True
    for chk in checks:
        status = "[green]OK[/green]" if chk.ok else "[red]FAIL[/red]"
        if not chk.ok:
            ext_all_ok = False
        ext_table.add_row(chk.name, chk.category, status, chk.detail, chk.fix_hint)

    console.print(ext_table)

    if ext_all_ok:
        console.print("\n[bold green]All extended checks passed![/bold green]")
    else:
        console.print("\n[bold yellow]Some extended checks failed — see fix hints above.[/bold yellow]")
