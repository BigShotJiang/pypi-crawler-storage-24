"""CLI commands for VCS (GitLab/Bitbucket) integration."""

from __future__ import annotations

import asyncio
import os

import typer
from rich.console import Console
from rich.table import Table

vcs_app = typer.Typer(help="VCS integration (GitLab / Bitbucket).")
console = Console()


def _get_token(token: str) -> str:
    """Resolve VCS token from arg or environment."""
    if token:
        return token
    return os.environ.get("OWLMIND_VCS_TOKEN", "")


def _get_vcs_type(vcs_type: str) -> str:
    """Resolve VCS type from arg or environment."""
    if vcs_type:
        return vcs_type
    return os.environ.get("OWLMIND_VCS_TYPE", "gitlab")


def _get_base_url(base_url: str, vcs_type: str) -> str | None:
    """Resolve base URL from arg or environment."""
    if base_url:
        return base_url
    env = os.environ.get("OWLMIND_VCS_URL", "")
    return env or None


@vcs_app.command("check-mr")
def cmd_check_mr(
    repo: str = typer.Option(..., "--repo", "-r", help="Repository (owner/name)"),
    mr_id: int = typer.Option(..., "--mr", "-m", help="MR/PR number"),
    vcs_type: str = typer.Option(
        "", "--vcs", envvar="OWLMIND_VCS_TYPE", help="VCS type (gitlab/bitbucket)"
    ),
    token: str = typer.Option("", "--token", envvar="OWLMIND_VCS_TOKEN", help="VCS access token"),
    base_url: str = typer.Option("", "--url", envvar="OWLMIND_VCS_URL", help="VCS API base URL"),
) -> None:
    """Fetch and display merge/pull request information."""
    from owlmind.integrations.vcs import create_vcs_client

    resolved_token = _get_token(token)
    if not resolved_token:
        console.print("[red]No VCS token. Use --token or OWLMIND_VCS_TOKEN.[/red]")
        raise typer.Exit(1)

    resolved_vcs = _get_vcs_type(vcs_type)
    resolved_url = _get_base_url(base_url, resolved_vcs)

    try:
        client = create_vcs_client(resolved_vcs, resolved_token, resolved_url)
    except ValueError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(1) from exc

    mr = asyncio.run(client.get_merge_request(repo, mr_id))

    table = Table(title=f"MR !{mr.id} — {mr.title}")
    table.add_column("Field", style="bold")
    table.add_column("Value")
    table.add_row("State", mr.state)
    table.add_row("Author", mr.author)
    table.add_row("Source", mr.source_branch)
    table.add_row("Target", mr.target_branch)
    table.add_row("SHA", mr.sha[:12] if mr.sha else "—")
    table.add_row("URL", mr.url or "—")
    table.add_row("Files", str(len(mr.modified_files)))
    console.print(table)

    if mr.modified_files:
        console.print("\n[bold]Modified files:[/bold]")
        for f in mr.modified_files:
            console.print(f"  {f}")


@vcs_app.command("post-comment")
def cmd_post_comment(
    repo: str = typer.Option(..., "--repo", "-r", help="Repository (owner/name)"),
    mr_id: int = typer.Option(..., "--mr", "-m", help="MR/PR number"),
    body: str = typer.Option(..., "--body", "-b", help="Comment text (markdown)"),
    vcs_type: str = typer.Option("", "--vcs", envvar="OWLMIND_VCS_TYPE", help="VCS type"),
    token: str = typer.Option("", "--token", envvar="OWLMIND_VCS_TOKEN", help="VCS access token"),
    base_url: str = typer.Option("", "--url", envvar="OWLMIND_VCS_URL", help="VCS API base URL"),
) -> None:
    """Post a comment to a merge/pull request."""
    from owlmind.integrations.vcs import create_vcs_client

    resolved_token = _get_token(token)
    if not resolved_token:
        console.print("[red]No VCS token. Use --token or OWLMIND_VCS_TOKEN.[/red]")
        raise typer.Exit(1)

    resolved_vcs = _get_vcs_type(vcs_type)
    resolved_url = _get_base_url(base_url, resolved_vcs)
    client = create_vcs_client(resolved_vcs, resolved_token, resolved_url)

    result = asyncio.run(client.post_comment(repo, mr_id, body))
    if result.ok:
        console.print(f"[green]Comment posted[/green] (id: {result.comment_id})")
    else:
        console.print(f"[red]Failed:[/red] {result.detail}")
        raise typer.Exit(1)


@vcs_app.command("set-status")
def cmd_set_status(
    repo: str = typer.Option(..., "--repo", "-r", help="Repository (owner/name)"),
    sha: str = typer.Option(..., "--sha", "-s", help="Commit SHA"),
    state: str = typer.Option("pending", "--state", help="Status: pending/running/success/failed"),
    description: str = typer.Option("", "--desc", "-d", help="Status description"),
    context: str = typer.Option("owlmind", "--context", "-c", help="Status context name"),
    vcs_type: str = typer.Option("", "--vcs", envvar="OWLMIND_VCS_TYPE", help="VCS type"),
    token: str = typer.Option("", "--token", envvar="OWLMIND_VCS_TOKEN", help="VCS access token"),
    base_url: str = typer.Option("", "--url", envvar="OWLMIND_VCS_URL", help="VCS API base URL"),
) -> None:
    """Set a commit status on a VCS platform."""
    from owlmind.integrations.vcs import create_vcs_client
    from owlmind.integrations.vcs.base import CommitStatus

    resolved_token = _get_token(token)
    if not resolved_token:
        console.print("[red]No VCS token. Use --token or OWLMIND_VCS_TOKEN.[/red]")
        raise typer.Exit(1)

    resolved_vcs = _get_vcs_type(vcs_type)
    resolved_url = _get_base_url(base_url, resolved_vcs)
    client = create_vcs_client(resolved_vcs, resolved_token, resolved_url)

    try:
        commit_status = CommitStatus(state)
    except ValueError:
        console.print(
            f"[red]Invalid status: {state!r}. Use: pending, running, success, failed, cancelled[/red]"
        )
        raise typer.Exit(1)  # noqa: B904

    result = asyncio.run(client.set_status(repo, sha, commit_status, description, context))
    if result.ok:
        console.print(f"[green]Status set:[/green] {state}")
    else:
        console.print(f"[red]Failed:[/red] {result.detail}")
        raise typer.Exit(1)


@vcs_app.command("report")
def cmd_report(
    repo: str = typer.Option(..., "--repo", "-r", help="Repository (owner/name)"),
    mr_id: int = typer.Option(..., "--mr", "-m", help="MR/PR number"),
    sha: str = typer.Option(..., "--sha", "-s", help="Commit SHA"),
    session_id: str = typer.Option(..., "--session", help="OWLMIND session ID"),
    status: str = typer.Option("DONE", "--status", help="Overall session status"),
    vcs_type: str = typer.Option("", "--vcs", envvar="OWLMIND_VCS_TYPE", help="VCS type"),
    token: str = typer.Option("", "--token", envvar="OWLMIND_VCS_TOKEN", help="VCS access token"),
    base_url: str = typer.Option("", "--url", envvar="OWLMIND_VCS_URL", help="VCS API base URL"),
) -> None:
    """Post a full OWLMIND review report to a merge/pull request."""
    from owlmind.integrations.vcs import create_vcs_client
    from owlmind.integrations.vcs.reporter import report_to_vcs

    resolved_token = _get_token(token)
    if not resolved_token:
        console.print("[red]No VCS token. Use --token or OWLMIND_VCS_TOKEN.[/red]")
        raise typer.Exit(1)

    resolved_vcs = _get_vcs_type(vcs_type)
    resolved_url = _get_base_url(base_url, resolved_vcs)
    client = create_vcs_client(resolved_vcs, resolved_token, resolved_url)

    # Placeholder goals — in real usage these come from the session
    goals: list[dict] = []

    result = asyncio.run(report_to_vcs(client, repo, mr_id, sha, session_id, goals, status))
    if result["comment_ok"]:
        console.print("[green]Report posted to MR[/green]")
    else:
        console.print(f"[red]Comment failed:[/red] {result.get('detail', '')}")

    if result["status_ok"]:
        console.print("[green]Commit status set[/green]")
    else:
        console.print(f"[yellow]Status failed:[/yellow] {result.get('detail', '')}")
