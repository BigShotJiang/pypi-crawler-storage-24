"""Automation CLI — autopilot, e2e, telegram, LLM providers."""

from __future__ import annotations

from pathlib import Path

import typer
from rich.table import Table

from owlmind import __version__

from ._helpers import (
    DEFAULT_LEDGER,
    DEFAULT_POLICIES,
    DEFAULT_RUNS,
    autopilot_event_printer,
    console,
    make_cycle_manager,
)

llm_app = typer.Typer(
    name="llm",
    help="LLM provider management",
    no_args_is_help=True,
)

e2e_app = typer.Typer(
    name="e2e",
    help="End-to-end harness: preflight checks and smoke runs",
    no_args_is_help=True,
)

telegram_app = typer.Typer(
    name="telegram",
    help="Telegram operator bot — control and monitor from Telegram",
    no_args_is_help=True,
)


# ===========================================================================
# AUTO (autopilot) — registered directly on app in __init__.py
# ===========================================================================


def register_auto(app: typer.Typer) -> None:
    """Register the auto command on the main app."""

    @app.command("auto")
    def auto(
        goal: str = typer.Option("", "--goal", "-g", help="Goal for the cycle"),
        run_id: str = typer.Option(None, "--run-id", help="Resume existing run"),
        workspace: Path = typer.Option(Path("."), "--workspace", "-w", help="Project workspace"),
        sandbox: bool = typer.Option(
            False, "--sandbox/--no-sandbox", help="Enable git worktree sandbox"
        ),
        use_llm: str = typer.Option("both", "--use-llm", help="LLM mode: none|planner|judge|both"),
        use_worker: str = typer.Option(
            "claude_cli", "--use-worker", help="Worker mode: none|claude_cli"
        ),
        provider_planner: str = typer.Option(
            None, "--provider-planner", help="Force planner provider"
        ),
        provider_judge: str = typer.Option(None, "--provider-judge", help="Force judge provider"),
        max_steps: int = typer.Option(50, "--max-steps", "-n", help="Max loop steps (0=unlimited)"),
        interval: float = typer.Option(2.0, "--interval", "-i", help="Seconds between loop ticks"),
        export: bool = typer.Option(True, "--export/--no-export", help="Auto-export on DONE"),
        export_dir: Path = typer.Option(None, "--export-dir", help="Custom export directory"),
        policies_dir: Path = typer.Option(DEFAULT_POLICIES, "--policies", "-p"),
        runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
        ledger_dir: Path = typer.Option(DEFAULT_LEDGER, "--ledger-dir", help="Ledger directory"),
        auto_approve: bool = typer.Option(
            False, "--auto-approve", help="Skip worker approval gate"
        ),
    ) -> None:
        """Full autonomous loop: Planner -> Worker -> Judge in one command."""
        from owlmind.autopilot import AutoPilotConfig
        from owlmind.autopilot import run as autopilot_run

        if not goal and not run_id:
            console.print("[red]Provide --goal or --run-id to resume.[/red]")
            raise typer.Exit(code=1)

        console.print(f"[bold]OWLMIND v{__version__} — autopilot[/bold]\n")

        ap_config = AutoPilotConfig(
            goal=goal,
            workspace=str(workspace),
            sandbox=sandbox,
            use_llm=use_llm,
            use_worker=use_worker,
            provider_planner=provider_planner,
            provider_judge=provider_judge,
            max_steps=max_steps,
            interval=interval,
            auto_export=export,
            export_dir=export_dir,
            run_id=run_id,
            policies_dir=policies_dir,
            runs_dir=runs_dir,
            ledger_dir=ledger_dir,
            auto_approve=auto_approve,
            on_event=autopilot_event_printer,
        )

        console.print(f"  Goal:      {goal or '(resume)'}")
        console.print(f"  Workspace: {workspace}")
        console.print(f"  LLM:       {use_llm}")
        console.print(f"  Worker:    {use_worker}")
        console.print(f"  Max steps: {max_steps or 'unlimited'}")
        if run_id:
            console.print(f"  Resuming:  {run_id}")
        console.print()

        result = autopilot_run(ap_config)

        state_color = "green" if result.final_state == "DONE" else "red"
        if result.final_state == "WAIT_APPROVAL":
            state_color = "yellow"

        console.print(
            f"\n[bold {state_color}]Final state: {result.final_state}[/bold {state_color}]"
        )
        console.print(f"  Run ID:      {result.run_id}")
        console.print(f"  Steps:       {result.steps}")
        console.print(f"  Iterations:  {result.iterations}")
        console.print(f"  Stop reason: {result.stop_reason}")
        if result.export_path:
            console.print(f"  Export:      {result.export_path}")

        if result.final_state not in ("DONE",):
            raise typer.Exit(code=1)


# ===========================================================================
# LLM providers
# ===========================================================================


@llm_app.command("providers")
def llm_providers() -> None:
    """Show available LLM providers and their configuration."""
    from owlmind.config import OwlMindConfig

    console.print(f"[bold]OWLMIND v{__version__} — LLM providers[/bold]\n")

    cfg = OwlMindConfig.from_env()

    table = Table(title="LLM Providers")
    table.add_column("Provider", style="bold")
    table.add_column("Status")
    table.add_column("Model")
    table.add_column("SDK")

    from owlmind.llm.openai_driver import is_openai_available

    oai_sdk = "[green]installed[/green]" if is_openai_available() else "[red]missing[/red]"
    oai_status = "[green]enabled[/green]" if cfg.openai.enabled else "[dim]disabled[/dim]"
    table.add_row("openai", oai_status, cfg.openai.planner_model, oai_sdk)

    from owlmind.llm.anthropic_driver import is_anthropic_available

    ant_sdk = "[green]installed[/green]" if is_anthropic_available() else "[red]missing[/red]"
    ant_status = "[green]enabled[/green]" if cfg.anthropic.enabled else "[dim]disabled[/dim]"
    table.add_row("anthropic", ant_status, cfg.anthropic.model, ant_sdk)

    from owlmind.llm.gemini_driver import is_gemini_available

    gem_sdk = "[green]installed[/green]" if is_gemini_available() else "[red]missing[/red]"
    gem_status = "[green]enabled[/green]" if cfg.gemini.enabled else "[dim]disabled[/dim]"
    table.add_row("gemini", gem_status, cfg.gemini.model, gem_sdk)

    console.print(table)

    console.print(f"\n  Planner order: {cfg.router.planner_providers}")
    console.print(f"  Judge order:   {cfg.router.judge_providers}")


# ===========================================================================
# E2E
# ===========================================================================


@e2e_app.command("preflight")
def e2e_preflight(
    workspace: Path = typer.Option(Path("."), "--workspace", "-w", help="Project workspace"),
    sandbox: bool = typer.Option(False, "--sandbox/--no-sandbox", help="Check sandbox readiness"),
    use_llm: str = typer.Option("both", "--use-llm", help="LLM mode: none|planner|judge|both"),
    use_worker: str = typer.Option("none", "--use-worker", help="Worker mode: none|claude_cli"),
    providers: str = typer.Option(None, "--providers", help="Comma-separated provider list"),
    json_out: Path = typer.Option(None, "--json-out", help="Write JSON report to file"),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Only show pass/fail"),
) -> None:
    """Run preflight checks — validates env, deps, binaries, budget."""
    from owlmind.preflight import PreflightConfig, run_preflight

    console.print(f"[bold]OWLMIND v{__version__} — e2e preflight[/bold]\n")

    provider_list: list[str] | None = None
    if providers:
        provider_list = [p.strip() for p in providers.split(",") if p.strip()]

    pf_config = PreflightConfig(
        use_llm=use_llm,
        use_worker=use_worker,
        providers=provider_list,
        workspace=str(workspace),
        sandbox=sandbox,
    )

    report = run_preflight(pf_config)

    if not quiet:
        table = Table(title="Preflight Checks")
        table.add_column("Check", style="bold")
        table.add_column("Status")
        table.add_column("Details")

        for check in report.checks:
            status = "[green]OK[/green]" if check.ok else "[red]FAIL[/red]"
            table.add_row(check.name, status, check.details)

        console.print(table)

        if report.provider_status:
            console.print("\n[bold]Provider Status:[/bold]")
            for prov, st in report.provider_status.items():
                color = "green" if st == "enabled" else "yellow"
                console.print(f"  [{color}]{prov}: {st}[/{color}]")

        if report.budget_summary:
            console.print(f"\n[dim]Budget: {report.budget_summary}[/dim]")

        if report.recommended_installs:
            console.print("\n[bold]Recommended:[/bold]")
            for cmd in report.recommended_installs:
                console.print(f"  {cmd}")

    if json_out:
        json_out.parent.mkdir(parents=True, exist_ok=True)
        json_out.write_text(report.to_json())
        console.print(f"\n[dim]JSON report: {json_out}[/dim]")

    if report.ok:
        console.print("\n[bold green]Preflight PASSED[/bold green]")
    else:
        console.print("\n[bold red]Preflight FAILED[/bold red]")
        raise typer.Exit(code=3)


@e2e_app.command("smoke")
def e2e_smoke(
    goal: str = typer.Option("", "--goal", "-g", help="Goal for the cycle"),
    run_id: str = typer.Option(None, "--run-id", help="Resume existing run"),
    workspace: Path = typer.Option(Path("."), "--workspace", "-w", help="Project workspace"),
    sandbox: bool = typer.Option(False, "--sandbox/--no-sandbox", help="Enable sandbox"),
    use_llm: str = typer.Option("both", "--use-llm", help="LLM mode: none|planner|judge|both"),
    use_worker: str = typer.Option("none", "--use-worker", help="Worker mode: none|claude_cli"),
    provider_planner: str = typer.Option(None, "--provider-planner", help="Force planner provider"),
    provider_judge: str = typer.Option(None, "--provider-judge", help="Force judge provider"),
    max_steps: int = typer.Option(200, "--max-steps", "-n", help="Max loop steps"),
    interval: float = typer.Option(1.0, "--interval", "-i", help="Seconds between ticks"),
    export: bool = typer.Option(True, "--export/--no-export", help="Auto-export on DONE"),
    policies_dir: Path = typer.Option(DEFAULT_POLICIES, "--policies", "-p"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
    ledger_dir: Path = typer.Option(DEFAULT_LEDGER, "--ledger-dir"),
) -> None:
    """Run E2E smoke: preflight + autopilot loop."""
    from owlmind.e2e import E2EConfig, run_e2e

    if not goal and not run_id:
        console.print("[red]Provide --goal or --run-id to resume.[/red]")
        raise typer.Exit(code=1)

    console.print(f"[bold]OWLMIND v{__version__} — e2e smoke[/bold]\n")

    e2e_config = E2EConfig(
        goal=goal,
        workspace=str(workspace),
        sandbox=sandbox,
        use_llm=use_llm,
        use_worker=use_worker,
        provider_planner=provider_planner,
        provider_judge=provider_judge,
        max_steps=max_steps,
        interval_sec=interval,
        export_on_done=export,
        run_id=run_id,
        policies_dir=policies_dir,
        runs_dir=runs_dir,
        ledger_dir=ledger_dir,
        on_event=autopilot_event_printer,
    )

    console.print(f"  Goal:      {goal or '(resume)'}")
    console.print(f"  Workspace: {workspace}")
    console.print(f"  LLM:       {use_llm}")
    console.print(f"  Worker:    {use_worker}")
    if run_id:
        console.print(f"  Resuming:  {run_id}")
    console.print()

    result = run_e2e(e2e_config)

    state_color = "green" if result.exit_code == 0 else "red"
    if result.exit_code == 2:
        state_color = "yellow"

    console.print(f"\n[bold {state_color}]E2E Result: {result.final_state}[/bold {state_color}]")
    console.print(f"  Run ID:      {result.run_id}")
    console.print(f"  Exit code:   {result.exit_code}")
    if result.blocked_reason:
        console.print(f"  Blocked:     {result.blocked_reason}")
    if result.report_path:
        console.print(f"  Report:      {result.report_path}")

    if result.next_commands:
        console.print("\n[bold]Next commands:[/bold]")
        for cmd in result.next_commands:
            console.print(f"  {cmd}")

    raise typer.Exit(code=result.exit_code)


# ===========================================================================
# Telegram
# ===========================================================================


@telegram_app.command("run")
def telegram_run(
    policies_dir: Path = typer.Option(DEFAULT_POLICIES, "--policies", "-p"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
    ledger_dir: Path = typer.Option(DEFAULT_LEDGER, "--ledger-dir"),
) -> None:
    """Start the Telegram operator bot (long-running polling)."""
    from owlmind.config import OwlMindConfig
    from owlmind.operator import OperatorService
    from owlmind.telegram_bot import create_operator_bot, is_telegram_available

    if not is_telegram_available():
        console.print("[red]python-telegram-bot not installed.[/red]")
        console.print("  pip install 'owlmind[telegram]'")
        raise typer.Exit(code=1)

    cfg = OwlMindConfig.from_env()

    if not cfg.telegram.enabled:
        console.print("[red]TELEGRAM_BOT_TOKEN not set.[/red]")
        raise typer.Exit(code=1)

    console.print(f"[bold]OWLMIND v{__version__} — telegram operator[/bold]\n")

    operator = OperatorService(
        runs_dir=runs_dir,
        policies_dir=policies_dir,
        ledger_dir=ledger_dir,
        allowed_workspaces=cfg.workspace.allowed_workspaces,
        default_workspace=cfg.workspace.default_workspace,
    )

    recovered = operator.recover_runs_from_disk()
    if recovered:
        console.print(f"[yellow]Recovered {len(recovered)} orphaned run(s) from disk:[/yellow]")
        for r in recovered:
            console.print(f"  {r.run_id[:20]} [{r.final_state}] {r.goal[:50]}")

    orphaned_sessions = operator.recover_sessions_from_disk()
    if orphaned_sessions:
        console.print(f"[yellow]Found {len(orphaned_sessions)} orphaned session(s)[/yellow]")
        for s in orphaned_sessions:
            console.print(
                f"  {s['session_id'][:20]} [{s['status']}] {s['current_goal_index']}/{s['total_goals']} goals"
            )

    cycle_manager = None
    try:
        _, _, cycle_manager = make_cycle_manager(
            policies_dir,
            runs_dir,
            with_budget=True,
            ledger_dir=ledger_dir,
        )
    except Exception:
        console.print("[yellow]Cycle manager not available (approve/deny disabled).[/yellow]")

    bot = create_operator_bot(
        bot_token=cfg.telegram.bot_token,
        allowed_chat_ids=cfg.telegram.allowed_chat_ids or None,
        operator=operator,
        cycle_manager=cycle_manager,
    )

    if not bot:
        console.print("[red]Failed to create Telegram bot.[/red]")
        raise typer.Exit(code=1)

    console.print("  Allowed chats: " + (str(cfg.telegram.allowed_chat_ids) or "all"))
    console.print("  Default workspace: " + cfg.workspace.default_workspace)
    if cfg.workspace.allowed_workspaces:
        console.print("  Allowed workspaces: " + str(cfg.workspace.allowed_workspaces))
    console.print("\n[green]Bot started. Polling...[/green]\n")

    try:
        bot.run_polling(drop_pending_updates=False)
    except KeyboardInterrupt:
        console.print("\n[yellow]Telegram bot stopped.[/yellow]")


@telegram_app.command("dry-run")
def telegram_dry_run(
    policies_dir: Path = typer.Option(DEFAULT_POLICIES, "--policies", "-p"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
    ledger_dir: Path = typer.Option(DEFAULT_LEDGER, "--ledger-dir"),
) -> None:
    """Validate Telegram bot config without starting polling."""
    from owlmind.config import OwlMindConfig
    from owlmind.telegram_bot import is_telegram_available

    console.print(f"[bold]OWLMIND v{__version__} — telegram dry-run[/bold]\n")

    checks: list[tuple[str, bool, str]] = []

    ptb_ok = is_telegram_available()
    checks.append(("python-telegram-bot", ptb_ok, "installed" if ptb_ok else "missing"))

    cfg = OwlMindConfig.from_env()
    token_ok = cfg.telegram.enabled
    checks.append(("TELEGRAM_BOT_TOKEN", token_ok, "set" if token_ok else "not set"))

    chats_ok = bool(cfg.telegram.allowed_chat_ids)
    chats_info = str(cfg.telegram.allowed_chat_ids) if chats_ok else "(all allowed)"
    checks.append(("TELEGRAM_ALLOWED_CHAT_IDS", True, chats_info))

    ws_info = cfg.workspace.default_workspace
    checks.append(("Default workspace", True, ws_info))

    ws_allow = cfg.workspace.allowed_workspaces
    checks.append(("Workspace allowlist", True, str(ws_allow) if ws_allow else "(all allowed)"))

    pol_ok = policies_dir.exists()
    checks.append(("Policies dir", pol_ok, str(policies_dir)))

    table = Table(title="Telegram Operator Config")
    table.add_column("Check", style="bold")
    table.add_column("Status")
    table.add_column("Details")

    all_ok = True
    for name, ok, detail in checks:
        status = "[green]OK[/green]" if ok else "[red]FAIL[/red]"
        if not ok:
            all_ok = False
        table.add_row(name, status, detail)

    console.print(table)

    if all_ok:
        console.print("\n[bold green]Ready to run: owlmind telegram run[/bold green]")
    else:
        console.print("\n[bold red]Fix issues above before running.[/bold red]")
        raise typer.Exit(code=1)
