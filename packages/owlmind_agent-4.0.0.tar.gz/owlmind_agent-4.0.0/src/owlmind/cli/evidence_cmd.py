"""Evidence CLI — verify hash-chain integrity of run evidence."""

from __future__ import annotations

from pathlib import Path

import typer

from ._helpers import DEFAULT_RUNS, console

evidence_app = typer.Typer(
    name="evidence",
    help="Evidence management commands.",
    no_args_is_help=True,
)


@evidence_app.command("verify")
def evidence_verify(
    run_id: str = typer.Argument(..., help="Run ID to verify"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r", help="Runs directory"),
) -> None:
    """Verify hash-chain integrity of a run's evidence log."""
    from owlmind.evidence import EvidenceStore

    result = EvidenceStore(runs_dir).verify_chain(run_id)
    if result.ok:
        console.print(
            f"[green]✓ Chain OK[/green]  run={run_id}"
            f"  seq={result.seq}  tip={result.tip_hash[:16]}..."
        )
    else:
        console.print(f"[red]✗ Chain INVALID[/red]  run={run_id}")
        for err in result.errors:
            console.print(f"  [red]{err}[/red]")
        raise typer.Exit(code=1)
