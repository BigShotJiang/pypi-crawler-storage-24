"""CLI subcommands for the skill pack marketplace."""

from __future__ import annotations

from pathlib import Path

import typer
from rich.table import Table

from ._helpers import console

marketplace_app = typer.Typer(help="Skill pack marketplace.")

_DEFAULT_DB = Path.home() / ".owlmind" / "marketplace" / "registry.db"
_DEFAULT_PACKS = Path("skill_packs")


def _registry(db: Path | None = None) -> PackageRegistry:  # noqa: F821
    from owlmind.marketplace.registry import PackageRegistry

    return PackageRegistry(db or _DEFAULT_DB)


@marketplace_app.command("publish")
def publish(
    pack_dir: Path = typer.Option(..., "--dir", "-d", help="Path to skill pack directory"),
    version: str = typer.Option(..., "--version", "-v", help="Semantic version string"),
    author: str = typer.Option("", "--author", "-a", help="Author name"),
    db: Path = typer.Option(_DEFAULT_DB, "--db", help="Registry database path"),
) -> None:
    """Publish a skill pack to the local registry."""
    reg = _registry(db)
    try:
        meta = reg.publish(pack_dir, version=version, author=author)
        console.print(f"[green]Published[/green] {meta.name} v{meta.version} (id={meta.id})")
    except (FileNotFoundError, ValueError) as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from None


@marketplace_app.command("search")
def search(
    query: str = typer.Argument(..., help="Search query"),
    tag: list[str] = typer.Option([], "--tag", "-t", help="Filter by tag"),
    db: Path = typer.Option(_DEFAULT_DB, "--db", help="Registry database path"),
) -> None:
    """Search for skill packs in the registry."""
    reg = _registry(db)
    results = reg.search(query, tags=tag or [])
    if not results:
        console.print("[dim]No packs found.[/dim]")
        return

    table = Table(title=f"Search results for '{query}'")
    table.add_column("ID", style="bold")
    table.add_column("Name")
    table.add_column("Version")
    table.add_column("Author")
    table.add_column("Rating", justify="right")
    table.add_column("Downloads", justify="right")

    for m in results:
        table.add_row(
            m.id, m.name, m.version, m.author,
            f"{m.rating:.1f}", str(m.downloads),
        )
    console.print(table)


@marketplace_app.command("install")
def install(
    pack_id: str = typer.Argument(..., help="Skill pack ID"),
    version: str = typer.Option("latest", "--version", "-v", help="Version to install"),
    target: Path = typer.Option(_DEFAULT_PACKS, "--target", "-t", help="Installation directory"),
    db: Path = typer.Option(_DEFAULT_DB, "--db", help="Registry database path"),
) -> None:
    """Install a skill pack from the registry."""
    reg = _registry(db)
    try:
        dest = reg.install(pack_id, version=version, target_dir=target)
        console.print(f"[green]Installed[/green] {pack_id} to {dest}")
    except FileNotFoundError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from None


@marketplace_app.command("uninstall")
def uninstall(
    pack_id: str = typer.Argument(..., help="Skill pack ID"),
    target: Path = typer.Option(_DEFAULT_PACKS, "--target", "-t", help="Installation directory"),
) -> None:
    """Uninstall a skill pack."""
    from owlmind.marketplace.registry import PackageRegistry

    removed = PackageRegistry.__new__(PackageRegistry).uninstall(pack_id, target_dir=target)
    if removed:
        console.print(f"[green]Uninstalled[/green] {pack_id}")
    else:
        console.print(f"[yellow]Pack not found:[/yellow] {pack_id}")


@marketplace_app.command("list")
def list_installed(
    target: Path = typer.Option(_DEFAULT_PACKS, "--target", "-t", help="Installation directory"),
    db: Path = typer.Option(_DEFAULT_DB, "--db", help="Registry database path"),
) -> None:
    """List installed skill packs."""
    reg = _registry(db)
    packs = reg.list_installed(target_dir=target)
    if not packs:
        console.print("[dim]No packs installed.[/dim]")
        return

    table = Table(title="Installed Skill Packs")
    table.add_column("ID", style="bold")
    table.add_column("Name")
    table.add_column("Version")
    table.add_column("Author")

    for m in packs:
        table.add_row(m.id, m.name, m.version, m.author)
    console.print(table)


@marketplace_app.command("rate")
def rate(
    pack_id: str = typer.Argument(..., help="Skill pack ID"),
    rating: int = typer.Argument(..., help="Rating 1-5"),
    review: str = typer.Option("", "--review", "-r", help="Optional review text"),
    db: Path = typer.Option(_DEFAULT_DB, "--db", help="Registry database path"),
) -> None:
    """Rate a skill pack (1-5)."""
    reg = _registry(db)
    try:
        reg.rate(pack_id, rating, review=review)
        console.print(f"[green]Rated[/green] {pack_id}: {'*' * rating}")
    except ValueError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from None
