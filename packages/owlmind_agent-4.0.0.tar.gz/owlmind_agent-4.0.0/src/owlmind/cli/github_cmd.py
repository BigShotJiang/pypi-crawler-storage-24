"""owlmind github — GitHub integration commands."""
from __future__ import annotations

from typing import Annotated

import typer
from rich.console import Console

github_app = typer.Typer(name="github", help="GitHub integration — PR review and CI", no_args_is_help=True)
console = Console()


@github_app.command("review")
def cmd_review(
    repo: Annotated[str, typer.Option("--repo", "-r", help="GitHub repo (owner/name)")] = "",
    pr: Annotated[int, typer.Option("--pr", "-p", help="PR number")] = 0,
    workspace: Annotated[str, typer.Option("--workspace", "-w")] = ".",
    max_iterations: Annotated[int, typer.Option("--iterations", "-n")] = 2,
    post_comment: Annotated[bool, typer.Option("--post-comment", help="Post result as PR comment")] = False,
    token: Annotated[str, typer.Option("--token", help="GitHub token (or set GITHUB_TOKEN)")] = "",
) -> None:
    """Review a GitHub PR with the graph pipeline and optionally post result as comment."""
    from owlmind.github_review import post_comment as _post
    from owlmind.github_review import review_pr

    if not repo or not pr:
        console.print("[red]--repo and --pr are required[/red]")
        raise typer.Exit(1)

    console.print(f"[bold]OwlMind GitHub Review[/bold] — {repo}#{pr}")

    result = review_pr(repo=repo, pr_number=pr, workspace=workspace,
                       max_iterations=max_iterations, token=token)

    verdict_color = {"APPROVED": "green", "NEEDS_FIX": "yellow", "REJECTED": "red"}.get(result.verdict, "white")
    console.print(f"[bold {verdict_color}]VERDICT: {result.verdict or 'ERROR'}[/bold {verdict_color}]")

    if result.review:
        from rich.panel import Panel
        console.print(Panel(result.review[:600], title="Review", border_style=verdict_color))

    if result.error:
        console.print(f"[red]Error: {result.error}[/red]")

    if post_comment:
        ok = _post(repo=repo, pr_number=pr, body=result.format_comment(), token=token)
        if ok:
            console.print(f"[green]Comment posted on {repo}#{pr}[/green]")
        else:
            console.print("[yellow]Failed to post comment (check GITHUB_TOKEN)[/yellow]")
