"""CLI commands: memory ingest, query, stats, purge."""

from __future__ import annotations

import json
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

memory_app = typer.Typer(help="Persistent project memory — cross-run knowledge base.")
console = Console()


def _get_store(workspace: Path) -> object:
    """Create a MemoryStore for the workspace."""
    from owlmind.memory.store import MemoryStore

    db_path = workspace / "memory" / "owlmind_memory.db"
    return MemoryStore(db_path)


@memory_app.command("ingest")
def memory_ingest(
    workspace: Path = typer.Option(".", "-w", "--workspace", help="Workspace root."),
    kind: str = typer.Option(
        "all", "--kind", "-k", help="What to ingest: docs, runs, sessions, all."
    ),
    paths: list[Path] | None = typer.Option(
        None, "--paths", "-p", help="Specific file paths to ingest."
    ),
) -> None:
    """Ingest project files into memory store."""
    from owlmind.memory.store import MemoryStore

    store = MemoryStore(workspace / "memory" / "owlmind_memory.db")
    count = 0

    if paths:
        for p in paths:
            if p.is_file():
                try:
                    content = p.read_text(errors="replace")
                    store.ingest("doc", str(p), content)
                    count += 1
                except OSError as e:
                    console.print(f"[yellow]Skip {p}: {e}[/yellow]")
    else:
        if kind in ("runs", "all"):
            runs_dir = workspace / "runs"
            if runs_dir.is_dir():
                for rd in runs_dir.iterdir():
                    meta_path = rd / "cycle_meta.json"
                    if meta_path.exists():
                        try:
                            content = meta_path.read_text()
                            store.ingest("run", str(meta_path), content)
                            count += 1
                        except OSError:
                            pass

        if kind in ("sessions", "all"):
            sessions_dir = workspace / "sessions"
            if sessions_dir.is_dir():
                for sd in sessions_dir.iterdir():
                    meta_path = sd / "session_meta.json"
                    if meta_path.exists():
                        try:
                            content = meta_path.read_text()
                            store.ingest("session", str(meta_path), content)
                            count += 1
                        except OSError:
                            pass

        if kind in ("docs", "all"):
            for pattern in ["*.md", "*.txt", "*.yaml", "*.yml"]:
                for f in workspace.glob(pattern):
                    if f.is_file() and f.stat().st_size < 100_000:
                        try:
                            content = f.read_text(errors="replace")
                            store.ingest("doc", str(f), content)
                            count += 1
                        except OSError:
                            pass

    store.close()
    console.print(f"[green]Ingested {count} documents into memory.[/green]")


@memory_app.command("query")
def memory_query(
    text: str = typer.Argument(..., help="Query text to search memory."),
    workspace: Path = typer.Option(".", "-w", "--workspace", help="Workspace root."),
    top_k: int = typer.Option(5, "--top-k", "-n", help="Number of results."),
    as_json: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Query memory for relevant snippets."""
    from owlmind.memory.retrieval import query
    from owlmind.memory.store import MemoryStore

    store = MemoryStore(workspace / "memory" / "owlmind_memory.db")
    results = query(store, text, top_k=top_k)
    store.close()

    if as_json:
        data = [
            {
                "chunk_id": r.chunk_id,
                "doc_id": r.doc_id,
                "source": r.source,
                "score": r.score,
                "snippet": r.snippet,
            }
            for r in results
        ]
        console.print_json(json.dumps(data, indent=2))
        return

    if not results:
        console.print("[dim]No matching memory found.[/dim]")
        return

    table = Table(title=f"Memory Query: {text[:60]}")
    table.add_column("#", style="dim", width=3)
    table.add_column("Source", style="cyan")
    table.add_column("Score", justify="right")
    table.add_column("Snippet", max_width=60)

    for i, r in enumerate(results, 1):
        table.add_row(str(i), r.source[:40], f"{r.score:.4f}", r.snippet[:60])

    console.print(table)


@memory_app.command("stats")
def memory_stats(
    workspace: Path = typer.Option(".", "-w", "--workspace", help="Workspace root."),
) -> None:
    """Show memory store statistics."""
    from owlmind.memory.store import MemoryStore

    db_path = workspace / "memory" / "owlmind_memory.db"
    if not db_path.exists():
        console.print("[dim]No memory store found. Run: owlmind memory ingest[/dim]")
        return

    store = MemoryStore(db_path)
    s = store.stats()
    store.close()

    table = Table(title="Memory Store Statistics")
    table.add_column("Metric", style="bold")
    table.add_column("Value", justify="right")
    table.add_row("Documents", str(s["documents"]))
    table.add_row("Chunks", str(s["chunks"]))
    table.add_row("Signals", str(s["signals"]))
    for kind, count in s.get("docs_by_kind", {}).items():
        table.add_row(f"  {kind}", str(count))
    console.print(table)


@memory_app.command("purge")
def memory_purge(
    workspace: Path = typer.Option(".", "-w", "--workspace", help="Workspace root."),
    older_than: int | None = typer.Option(
        None, "--older-than", help="Delete docs older than N days."
    ),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation."),
) -> None:
    """Purge memory store entries."""
    from owlmind.memory.store import MemoryStore

    db_path = workspace / "memory" / "owlmind_memory.db"
    if not db_path.exists():
        console.print("[dim]No memory store found.[/dim]")
        return

    if not yes:
        msg = (
            "Purge ALL memory"
            if older_than is None
            else f"Purge entries older than {older_than} days"
        )
        confirm = typer.confirm(f"{msg}?")
        if not confirm:
            console.print("[dim]Aborted.[/dim]")
            return

    store = MemoryStore(db_path)
    deleted = store.purge(older_than_days=older_than)
    store.close()
    console.print(f"[green]Purged {deleted} documents.[/green]")
