"""CLI commands for pre-run cost estimation."""

from __future__ import annotations

from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from owlmind.config import OwlMindConfig
from owlmind.cost import estimate_goal, estimate_session

cost_app = typer.Typer(help="Pre-run cost estimation.")
console = Console()


@cost_app.command("estimate-goal")
def cmd_estimate_goal(
    goal: str = typer.Argument(..., help="Goal description text"),
    provider: str = typer.Option("openai", help="LLM provider (openai, anthropic, gemini)"),
    iterations: int = typer.Option(
        1, "--iterations", "-n", help="Expected planner/judge iterations"
    ),
) -> None:
    """Estimate cost for a single goal execution."""
    cfg = OwlMindConfig.from_env()

    est = estimate_goal(
        goal,
        provider,
        cfg.pricing,
        cfg.budget,
        iterations=iterations,
    )

    table = Table(title="Cost Estimate — Single Goal")
    table.add_column("Metric", style="cyan")
    table.add_column("Value", style="green")

    table.add_row("Provider", est.provider)
    table.add_row("Iterations", str(est.iterations))
    table.add_row("Complexity", str(est.details.get("complexity_multiplier", "?")))
    table.add_row("Input tokens", f"{est.estimated_input_tokens:,}")
    table.add_row("Output tokens", f"{est.estimated_output_tokens:,}")
    table.add_row("Total tokens", f"{est.estimated_total_tokens:,}")
    table.add_row("Estimated cost", est.display_range)
    table.add_row("Budget usage", f"{est.budget_pct:.1f}%")

    console.print(table)

    if est.budget_warning:
        console.print(
            "[bold yellow]WARNING:[/bold yellow] "
            f"Estimated cost exceeds 50% of daily budget "
            f"(${cfg.budget.max_usd_per_day:.2f}/day)",
        )


@cost_app.command("estimate-session")
def cmd_estimate_session(
    goals_file: Path = typer.Argument(..., help="Path to goals YAML file"),
    provider: str = typer.Option("openai", help="LLM provider"),
    iterations: int = typer.Option(1, "--iterations", "-n", help="Expected iterations per goal"),
) -> None:
    """Estimate total cost for a session (goals file)."""
    import yaml

    if not goals_file.exists():
        console.print(f"[red]Goals file not found:[/red] {goals_file}")
        raise typer.Exit(1)

    data = yaml.safe_load(goals_file.read_text())
    goals_list: list[str] = []

    if isinstance(data, dict):
        raw_goals = data.get("goals", [])
    elif isinstance(data, list):
        raw_goals = data
    else:
        console.print("[red]Invalid goals file format[/red]")
        raise typer.Exit(1)

    for g in raw_goals:
        if isinstance(g, str):
            goals_list.append(g)
        elif isinstance(g, dict):
            goals_list.append(g.get("goal", str(g)))

    if not goals_list:
        console.print("[yellow]No goals found in file[/yellow]")
        raise typer.Exit(0)

    cfg = OwlMindConfig.from_env()

    est = estimate_session(
        goals_list,
        provider,
        cfg.pricing,
        cfg.budget,
        iterations_per_goal=iterations,
    )

    table = Table(title=f"Cost Estimate — Session ({len(goals_list)} goals)")
    table.add_column("Metric", style="cyan")
    table.add_column("Value", style="green")

    table.add_row("Provider", est.provider)
    table.add_row("Goals", str(est.details.get("goal_count", 0)))
    table.add_row("Iterations/goal", str(est.iterations))
    table.add_row("Input tokens", f"{est.estimated_input_tokens:,}")
    table.add_row("Output tokens", f"{est.estimated_output_tokens:,}")
    table.add_row("Total tokens", f"{est.estimated_total_tokens:,}")
    table.add_row("Estimated cost", est.display_range)
    table.add_row("Budget usage", f"{est.budget_pct:.1f}%")

    console.print(table)

    # Show per-goal breakdown
    goal_details = est.details.get("goals", [])
    if goal_details:
        breakdown = Table(title="Per-Goal Breakdown")
        breakdown.add_column("#", style="dim")
        breakdown.add_column("Goal", style="white")
        breakdown.add_column("Cost Range", style="green")

        for i, gd in enumerate(goal_details, 1):
            breakdown.add_row(str(i), gd["goal"], gd["usd_range"])

        console.print(breakdown)

    if est.budget_warning:
        console.print(
            "[bold yellow]WARNING:[/bold yellow] "
            f"Estimated session cost exceeds 50% of daily budget "
            f"(${cfg.budget.max_usd_per_day:.2f}/day)",
        )
