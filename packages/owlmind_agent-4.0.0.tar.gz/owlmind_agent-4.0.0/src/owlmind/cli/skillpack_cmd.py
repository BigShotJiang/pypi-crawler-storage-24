"""CLI commands for distributed skill pack registry management."""

from __future__ import annotations

import asyncio

import typer
from rich.table import Table

from ._helpers import console

skillpack_app = typer.Typer(
    name="skill-pack",
    help="Distributed skill pack registry (register, publish, list).",
    no_args_is_help=True,
)


def _get_storage(
    backend: str,
    sessions_dir: str,
    runs_dir: str,
    ledger_dir: str,
    queue_dir: str,
    postgres_dsn: str,
) -> object:
    """Create storage backend."""
    from owlmind.storage import create_storage

    return create_storage(
        backend=backend,
        runs_dir=runs_dir,
        ledger_dir=ledger_dir,
        queue_dir=queue_dir,
        sessions_dir=sessions_dir,
        postgres_dsn=postgres_dsn,
    )


@skillpack_app.command("list")
def list_packs(
    backend: str = typer.Option("file", help="Storage backend"),
    sessions_dir: str = typer.Option("sessions", help="Sessions directory"),
    runs_dir: str = typer.Option("runs", help="Runs directory"),
    ledger_dir: str = typer.Option("ledger", help="Ledger directory"),
    queue_dir: str = typer.Option("queue", help="Queue directory"),
    postgres_dsn: str = typer.Option("", help="PostgreSQL DSN"),
    tag: list[str] = typer.Option([], "--tag", help="Filter by tag"),
) -> None:
    """List registered skill packs."""
    storage = _get_storage(backend, sessions_dir, runs_dir, ledger_dir, queue_dir, postgres_dsn)
    registry = getattr(storage, "skill_pack_registry", None)
    if registry is None:
        console.print("[red]Skill pack registry not available[/red]")
        raise typer.Exit(code=1)

    packs = asyncio.run(registry.list_packs(tags=tag or None))
    if not packs:
        console.print("[yellow]No skill packs registered[/yellow]")
        return

    table = Table(title="Registered Skill Packs", show_header=True, header_style="bold cyan")
    table.add_column("Pack ID", style="bold")
    table.add_column("Name")
    table.add_column("Version")
    table.add_column("Description")
    table.add_column("Tags")

    for pack in packs:
        table.add_row(
            pack.get("pack_id", ""),
            pack.get("name", ""),
            pack.get("latest_version", "-"),
            pack.get("description", ""),
            ", ".join(pack.get("tags", [])),
        )

    console.print(table)


@skillpack_app.command("register")
def register_pack(
    pack_id: str = typer.Argument(..., help="Skill pack ID"),
    name: str = typer.Option("", help="Pack display name"),
    description: str = typer.Option("", help="Pack description"),
    tag: list[str] = typer.Option([], "--tag", help="Tags"),
    backend: str = typer.Option("file", help="Storage backend"),
    sessions_dir: str = typer.Option("sessions", help="Sessions directory"),
    runs_dir: str = typer.Option("runs", help="Runs directory"),
    ledger_dir: str = typer.Option("ledger", help="Ledger directory"),
    queue_dir: str = typer.Option("queue", help="Queue directory"),
    postgres_dsn: str = typer.Option("", help="PostgreSQL DSN"),
) -> None:
    """Register a new skill pack."""
    storage = _get_storage(backend, sessions_dir, runs_dir, ledger_dir, queue_dir, postgres_dsn)
    registry = getattr(storage, "skill_pack_registry", None)
    if registry is None:
        console.print("[red]Skill pack registry not available[/red]")
        raise typer.Exit(code=1)

    result = asyncio.run(
        registry.register_pack(
            pack_id, name=name or pack_id, description=description, tags=tag or None
        )
    )
    console.print(f"[green]Registered:[/green] {result['pack_id']} ({result.get('name', '')})")


@skillpack_app.command("publish")
def publish_version(
    pack_id: str = typer.Argument(..., help="Skill pack ID"),
    version: str = typer.Argument(..., help="Version string (e.g. 1.0.0)"),
    archive_key: str = typer.Option("", help="S3 archive key"),
    sha256: str = typer.Option("", help="Archive SHA-256 hash"),
    changelog: str = typer.Option("", help="Version changelog"),
    backend: str = typer.Option("file", help="Storage backend"),
    sessions_dir: str = typer.Option("sessions", help="Sessions directory"),
    runs_dir: str = typer.Option("runs", help="Runs directory"),
    ledger_dir: str = typer.Option("ledger", help="Ledger directory"),
    queue_dir: str = typer.Option("queue", help="Queue directory"),
    postgres_dsn: str = typer.Option("", help="PostgreSQL DSN"),
) -> None:
    """Publish a new version for a skill pack."""
    storage = _get_storage(backend, sessions_dir, runs_dir, ledger_dir, queue_dir, postgres_dsn)
    registry = getattr(storage, "skill_pack_registry", None)
    if registry is None:
        console.print("[red]Skill pack registry not available[/red]")
        raise typer.Exit(code=1)

    try:
        result = asyncio.run(
            registry.publish_version(
                pack_id, version, archive_key=archive_key, sha256=sha256, changelog=changelog
            )
        )
    except FileNotFoundError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1) from None

    console.print(f"[green]Published:[/green] {pack_id} v{result['version']}")


@skillpack_app.command("info")
def pack_info(
    pack_id: str = typer.Argument(..., help="Skill pack ID"),
    backend: str = typer.Option("file", help="Storage backend"),
    sessions_dir: str = typer.Option("sessions", help="Sessions directory"),
    runs_dir: str = typer.Option("runs", help="Runs directory"),
    ledger_dir: str = typer.Option("ledger", help="Ledger directory"),
    queue_dir: str = typer.Option("queue", help="Queue directory"),
    postgres_dsn: str = typer.Option("", help="PostgreSQL DSN"),
) -> None:
    """Show info for a skill pack."""
    storage = _get_storage(backend, sessions_dir, runs_dir, ledger_dir, queue_dir, postgres_dsn)
    registry = getattr(storage, "skill_pack_registry", None)
    if registry is None:
        console.print("[red]Skill pack registry not available[/red]")
        raise typer.Exit(code=1)

    pack = asyncio.run(registry.get_pack(pack_id))
    if pack is None:
        console.print(f"[red]Skill pack not found: {pack_id}[/red]")
        raise typer.Exit(code=1)

    console.print(f"\n[bold cyan]Skill Pack: {pack.get('name', pack_id)}[/bold cyan]")
    console.print(f"  ID:          {pack.get('pack_id', '')}")
    console.print(f"  Version:     {pack.get('latest_version', '-')}")
    console.print(f"  Description: {pack.get('description', '')}")
    console.print(f"  Tags:        {', '.join(pack.get('tags', []))}")
    console.print(f"  Created:     {pack.get('created_at', '')}")
    console.print(f"  Updated:     {pack.get('updated_at', '')}")

    versions = asyncio.run(registry.list_versions(pack_id))
    if versions:
        console.print("\n[bold]Versions:[/bold]")
        for v in versions:
            console.print(f"  {v['version']} ({v.get('created_at', '')})")
            if v.get("changelog"):
                console.print(f"    {v['changelog']}")
