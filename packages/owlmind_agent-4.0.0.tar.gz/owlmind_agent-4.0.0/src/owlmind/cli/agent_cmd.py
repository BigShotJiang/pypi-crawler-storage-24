"""CLI commands for distributed agent registry management."""

from __future__ import annotations

import asyncio

import typer
from rich.table import Table

from ._helpers import console

agent_app = typer.Typer(
    name="agent",
    help="Distributed agent registry (register, list, heartbeat).",
    no_args_is_help=True,
)


def _get_storage(
    backend: str,
    sessions_dir: str,
    runs_dir: str,
    ledger_dir: str,
    queue_dir: str,
    postgres_dsn: str,
) -> object:
    """Create storage backend."""
    from owlmind.storage import create_storage

    return create_storage(
        backend=backend,
        runs_dir=runs_dir,
        ledger_dir=ledger_dir,
        queue_dir=queue_dir,
        sessions_dir=sessions_dir,
        postgres_dsn=postgres_dsn,
    )


@agent_app.command("list")
def list_agents(
    backend: str = typer.Option("file", help="Storage backend"),
    sessions_dir: str = typer.Option("sessions", help="Sessions directory"),
    runs_dir: str = typer.Option("runs", help="Runs directory"),
    ledger_dir: str = typer.Option("ledger", help="Ledger directory"),
    queue_dir: str = typer.Option("queue", help="Queue directory"),
    postgres_dsn: str = typer.Option("", help="PostgreSQL DSN"),
    status: str = typer.Option("", help="Filter by status"),
) -> None:
    """List registered agents."""
    storage = _get_storage(backend, sessions_dir, runs_dir, ledger_dir, queue_dir, postgres_dsn)
    registry = getattr(storage, "agent_registry", None)
    if registry is None:
        console.print("[red]Agent registry not available[/red]")
        raise typer.Exit(code=1)

    agents = asyncio.run(registry.list_agents(status=status or None))
    if not agents:
        console.print("[yellow]No agents registered[/yellow]")
        return

    table = Table(title="Registered Agents", show_header=True, header_style="bold cyan")
    table.add_column("Agent ID", style="bold")
    table.add_column("Hostname")
    table.add_column("Status")
    table.add_column("Tasks")
    table.add_column("Max")
    table.add_column("Capabilities")
    table.add_column("Last Heartbeat")

    for agent in agents:
        status_str = agent.get("status", "?")
        style = {"idle": "green", "busy": "yellow", "offline": "dim"}.get(status_str, "")
        table.add_row(
            agent.get("agent_id", ""),
            agent.get("hostname", ""),
            f"[{style}]{status_str}[/{style}]" if style else status_str,
            str(agent.get("current_tasks", 0)),
            str(agent.get("max_concurrent", 1)),
            ", ".join(agent.get("capabilities", [])),
            agent.get("last_heartbeat", ""),
        )

    console.print(table)


@agent_app.command("register")
def register_agent(
    agent_id: str = typer.Argument(..., help="Agent ID"),
    hostname: str = typer.Option("", help="Agent hostname"),
    max_concurrent: int = typer.Option(1, help="Max concurrent tasks"),
    capability: list[str] = typer.Option([], "--capability", help="Agent capabilities"),
    backend: str = typer.Option("file", help="Storage backend"),
    sessions_dir: str = typer.Option("sessions", help="Sessions directory"),
    runs_dir: str = typer.Option("runs", help="Runs directory"),
    ledger_dir: str = typer.Option("ledger", help="Ledger directory"),
    queue_dir: str = typer.Option("queue", help="Queue directory"),
    postgres_dsn: str = typer.Option("", help="PostgreSQL DSN"),
) -> None:
    """Register a new agent."""
    storage = _get_storage(backend, sessions_dir, runs_dir, ledger_dir, queue_dir, postgres_dsn)
    registry = getattr(storage, "agent_registry", None)
    if registry is None:
        console.print("[red]Agent registry not available[/red]")
        raise typer.Exit(code=1)

    result = asyncio.run(
        registry.register_agent(
            agent_id,
            hostname=hostname,
            capabilities=capability or None,
            max_concurrent=max_concurrent,
        )
    )
    console.print(f"[green]Registered agent:[/green] {result['agent_id']} ({hostname or 'local'})")


@agent_app.command("info")
def agent_info(
    agent_id: str = typer.Argument(..., help="Agent ID"),
    backend: str = typer.Option("file", help="Storage backend"),
    sessions_dir: str = typer.Option("sessions", help="Sessions directory"),
    runs_dir: str = typer.Option("runs", help="Runs directory"),
    ledger_dir: str = typer.Option("ledger", help="Ledger directory"),
    queue_dir: str = typer.Option("queue", help="Queue directory"),
    postgres_dsn: str = typer.Option("", help="PostgreSQL DSN"),
) -> None:
    """Show agent details."""
    storage = _get_storage(backend, sessions_dir, runs_dir, ledger_dir, queue_dir, postgres_dsn)
    registry = getattr(storage, "agent_registry", None)
    if registry is None:
        console.print("[red]Agent registry not available[/red]")
        raise typer.Exit(code=1)

    agent = asyncio.run(registry.get_agent(agent_id))
    if agent is None:
        console.print(f"[red]Agent not found: {agent_id}[/red]")
        raise typer.Exit(code=1)

    console.print(f"\n[bold cyan]Agent: {agent.get('agent_id', '')}[/bold cyan]")
    console.print(f"  Hostname:      {agent.get('hostname', '')}")
    console.print(f"  Status:        {agent.get('status', '')}")
    console.print(
        f"  Tasks:         {agent.get('current_tasks', 0)}/{agent.get('max_concurrent', 1)}"
    )
    console.print(f"  Capabilities:  {', '.join(agent.get('capabilities', []))}")
    console.print(f"  Last heartbeat: {agent.get('last_heartbeat', '')}")
    console.print(f"  Registered:    {agent.get('registered_at', '')}")


@agent_app.command("deregister")
def deregister_agent(
    agent_id: str = typer.Argument(..., help="Agent ID"),
    backend: str = typer.Option("file", help="Storage backend"),
    sessions_dir: str = typer.Option("sessions", help="Sessions directory"),
    runs_dir: str = typer.Option("runs", help="Runs directory"),
    ledger_dir: str = typer.Option("ledger", help="Ledger directory"),
    queue_dir: str = typer.Option("queue", help="Queue directory"),
    postgres_dsn: str = typer.Option("", help="PostgreSQL DSN"),
) -> None:
    """Remove an agent from the registry."""
    storage = _get_storage(backend, sessions_dir, runs_dir, ledger_dir, queue_dir, postgres_dsn)
    registry = getattr(storage, "agent_registry", None)
    if registry is None:
        console.print("[red]Agent registry not available[/red]")
        raise typer.Exit(code=1)

    asyncio.run(registry.deregister(agent_id))
    console.print(f"[green]Deregistered:[/green] {agent_id}")
