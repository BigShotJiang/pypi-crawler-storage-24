"""CLI command for starting the OWLMIND REST API server."""

from __future__ import annotations

from pathlib import Path

import typer

from ._helpers import DEFAULT_LEDGER, DEFAULT_POLICIES, DEFAULT_QUEUE, DEFAULT_RUNS, console

api_app = typer.Typer(
    name="api",
    help="OWLMIND REST API server (requires fastapi + uvicorn)",
    no_args_is_help=True,
)


@api_app.command()
def serve(
    host: str = typer.Option("127.0.0.1", "--host", "-h", help="Bind host"),
    port: int = typer.Option(8765, "--port", "-p", help="Bind port"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r", help="Runs directory"),
    ledger_dir: Path = typer.Option(DEFAULT_LEDGER, "--ledger", "-l", help="Ledger directory"),
    queue_dir: Path = typer.Option(DEFAULT_QUEUE, "--queue", "-q", help="Queue directory"),
    policies_dir: Path = typer.Option(DEFAULT_POLICIES, "--policies", help="Policies directory"),
    reload: bool = typer.Option(False, "--reload", help="Enable auto-reload (dev mode)"),
) -> None:
    """Start the OWLMIND REST API server via uvicorn."""
    try:
        import uvicorn
    except ImportError:
        console.print("[red]uvicorn is not installed. Run: pip install uvicorn[/red]")
        raise typer.Exit(code=1) from None

    try:
        from owlmind.api.app import create_app
    except ImportError:
        console.print("[red]fastapi is not installed. Run: pip install fastapi[/red]")
        raise typer.Exit(code=1) from None

    app = create_app(
        runs_dir=runs_dir,
        ledger_dir=ledger_dir,
        queue_path=queue_dir,
        policies_dir=policies_dir,
    )

    console.print(f"[bold]OWLMIND API server starting on {host}:{port}[/bold]")
    console.print(f"  Runs:     {runs_dir}")
    console.print(f"  Ledger:   {ledger_dir}")
    console.print(f"  Queue:    {queue_dir}")
    console.print(f"  Policies: {policies_dir}")
    console.print()

    uvicorn.run(app, host=host, port=port, reload=reload)
