"""CLI commands for SWE-bench evaluation: owlmind bench run / show."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

bench_app = typer.Typer(help="SWE-bench evaluation harness")
console = Console()


@bench_app.command("run")
def bench_run(
    source: str = typer.Argument(
        ...,
        help="Path to .jsonl file or HuggingFace dataset (e.g. princeton-nlp/SWE-bench_Lite)",
    ),
    limit: int | None = typer.Option(None, "--limit", "-n", help="Max instances to evaluate"),
    instance_ids: str | None = typer.Option(
        None,
        "--ids",
        help="Comma-separated instance IDs to run (e.g. django__django-1234,flask__flask-5678)",
    ),
    workspace: Path = typer.Option(
        Path.home() / ".owlmind" / "bench" / "workspaces",
        "--workspace",
        "-w",
        help="Base directory for cloned repos",
    ),
    output: Path = typer.Option(
        Path("bench_report.json"),
        "--output",
        "-o",
        help="Output JSON report file",
    ),
    workers: int = typer.Option(1, "--workers", "-j", help="Parallel workers (default 1)"),
    verify: bool = typer.Option(
        False, "--verify", help="Run tests to verify resolution (requires test env)"
    ),
    runs_dir: Path = typer.Option(
        Path.home() / ".owlmind" / "runs", "--runs-dir", help="OwlMind runs directory"
    ),
    policies_dir: Path = typer.Option(
        Path.home() / ".owlmind" / "policies", "--policies-dir", help="Policies directory"
    ),
    ledger_dir: Path = typer.Option(
        Path.home() / ".owlmind" / "ledger", "--ledger-dir", help="Ledger directory"
    ),
    resume: Path | None = typer.Option(
        None, "--resume", help="Resume from a previous report JSON — skip already-passed instances"
    ),
) -> None:
    """Run OwlMind on SWE-bench instances and produce a JSON report.

    Examples:

      # Run on 5 instances from a local file
      owlmind bench run instances.jsonl --limit 5

      # Run on HuggingFace SWE-bench Lite (requires: pip install datasets)
      owlmind bench run princeton-nlp/SWE-bench_Lite --limit 10 --workers 2

      # Run specific instances
      owlmind bench run instances.jsonl --ids django__django-1234,flask__flask-5678

      # Resume after a crash — skip already-passed instances
      owlmind bench run princeton-nlp/SWE-bench_Lite --resume bench_report_025.json
    """
    from owlmind.bench.harness import BenchHarness
    from owlmind.operator import OperatorService

    id_list = [i.strip() for i in instance_ids.split(",") if i.strip()] if instance_ids else None

    operator = OperatorService(
        runs_dir=runs_dir,
        policies_dir=policies_dir,
        ledger_dir=ledger_dir,
    )

    harness = BenchHarness(
        operator=operator,
        workspace_base=workspace,
        verify=verify,
    )

    completed = 0

    def _on_result(r: object) -> None:
        nonlocal completed
        completed += 1
        icon = "✅" if getattr(r, "status", "") == "passed" else "❌"
        iid = getattr(r, "instance_id", "?")
        status = getattr(r, "status", "?")
        dur = getattr(r, "duration_ms", 0)
        console.print(f"  {icon} [{completed}] {iid} → {status} ({dur}ms)")

    console.print(f"[bold]SWE-bench evaluation[/bold] — source: [cyan]{source}[/cyan]")
    if limit:
        console.print(f"  Limit: {limit} instances | Workers: {workers} | Verify: {verify}")

    report = harness.run(
        source,
        limit=limit,
        instance_ids=id_list,
        max_workers=workers,
        on_result=_on_result,
        resume_from=resume,
    )

    # Print summary table
    table = Table(title="Results")
    table.add_column("Metric", style="cyan")
    table.add_column("Value", style="bold")
    table.add_row("Total instances", str(report.total))
    table.add_row("Passed (resolved)", str(report.passed))
    table.add_row("Failed", str(report.failed))
    table.add_row("Errors", str(report.errors))
    table.add_row("pass@1", f"{report.pass_at_1 * 100:.1f}%")
    if report.total_tokens:
        table.add_row("Total tokens", f"{report.total_tokens:,}")
        table.add_row("Total cost", f"~${report.total_cost_usd:.3f}")
        if report.total:
            table.add_row("Avg cost/instance", f"~${report.total_cost_usd / report.total:.3f}")
    console.print(table)

    harness.save_report(report, output)
    console.print(f"\nReport saved to [green]{output}[/green]")

    if report.total > 0 and report.passed == 0:
        sys.exit(1)


@bench_app.command("show")
def bench_show(
    report_file: Path = typer.Argument(..., help="Path to bench_report.json"),
    failed_only: bool = typer.Option(False, "--failed", help="Show only failed instances"),
) -> None:
    """Show a previously saved bench report."""
    if not report_file.exists():
        console.print(f"[red]Report file not found: {report_file}[/red]")
        raise typer.Exit(1)

    data = json.loads(report_file.read_text())

    console.print(f"\n[bold]SWE-bench Report[/bold] — {report_file}\n")
    console.print(data.get("summary", ""))

    results = data.get("results", [])
    if failed_only:
        results = [r for r in results if r.get("status") != "passed"]

    table = Table()
    table.add_column("Instance ID", style="cyan")
    table.add_column("Status")
    table.add_column("Duration")
    table.add_column("Cost")
    table.add_column("Patch lines")
    table.add_column("Error")

    for r in results:
        status = r.get("status", "?")
        color = "green" if status == "passed" else "red" if status in ("failed", "error") else "yellow"
        table.add_row(
            r.get("instance_id", "?"),
            f"[{color}]{status}[/{color}]",
            f"{r.get('duration_ms', 0) // 1000}s",
            r.get("cost_summary", "—"),
            str(r.get("patch_lines", 0)),
            (r.get("error", "") or "")[:60],
        )

    console.print(table)
