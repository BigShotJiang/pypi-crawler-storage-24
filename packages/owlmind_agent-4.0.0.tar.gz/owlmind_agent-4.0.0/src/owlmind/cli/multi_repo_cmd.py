"""Multi-repo CLI subcommands — cross-repository orchestration.

YAML config format example::

    rollback_policy: branch_delete   # branch_delete | worktree_reset | manual | none
    repos:
      - path: /home/user/repo-a
        branch: main
        remote: origin
        goals:
          - "Refactor auth module"
          - "Add unit tests for auth"
      - path: /home/user/repo-b
        branch: develop
        remote: origin
        goals:
          - "Update API client for new auth"
    dependencies:
      /home/user/repo-b:
        - /home/user/repo-a
    integration_tests:
      - name: e2e-auth
        command: pytest tests/e2e/test_auth.py
        working_dir: /home/user/repo-b
        depends_on:
          - /home/user/repo-a
          - /home/user/repo-b
"""

from __future__ import annotations

from pathlib import Path

import typer
from rich.table import Table

from owlmind import __version__

from ._helpers import (
    DEFAULT_LEDGER,
    DEFAULT_POLICIES,
    DEFAULT_RUNS,
    DEFAULT_SESSIONS,
    console,
)

multi_repo_app = typer.Typer(
    name="multi-repo",
    help="Multi-repository orchestration.",
    no_args_is_help=True,
)


@multi_repo_app.command("run")
def multi_repo_run(
    config: Path = typer.Option(
        ..., "--config", "-c", help="YAML config file for multi-repo orchestration"
    ),
    sessions_dir: Path = typer.Option(DEFAULT_SESSIONS, "--sessions-dir"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
    policies_dir: Path = typer.Option(DEFAULT_POLICIES, "--policies", "-p"),
    ledger_dir: Path = typer.Option(DEFAULT_LEDGER, "--ledger-dir"),
) -> None:
    """Run multi-repo orchestration from a YAML config file.

    Creates a session per repository, runs them in dependency order,
    then executes integration tests.
    """
    from owlmind.multi_repo import MultiRepoRunner, load_multi_repo_config

    console.print(f"[bold]OWLMIND v{__version__} -- multi-repo run[/bold]\n")

    if not config.exists():
        console.print(f"[red]Config file not found: {config}[/red]")
        raise typer.Exit(code=1)

    try:
        mr_config = load_multi_repo_config(config)
    except Exception as exc:
        console.print(f"[red]Error loading config: {exc}[/red]")
        raise typer.Exit(code=1) from None

    console.print(f"  Repos:        {len(mr_config.repos)}")
    console.print(f"  Rollback:     {mr_config.rollback_policy}")
    console.print(f"  Int. tests:   {len(mr_config.integration_tests)}")
    console.print()

    for repo in mr_config.repos:
        dep_count = len(mr_config.dependency_graph.get(repo.path, []))
        console.print(
            f"  [bold]{repo.path}[/bold]  "
            f"branch={repo.branch}  goals={len(repo.goals)}  deps={dep_count}"
        )
    console.print()

    runner = MultiRepoRunner(
        config=mr_config,
        sessions_dir=sessions_dir,
        runs_dir=runs_dir,
        policies_dir=policies_dir,
        ledger_dir=ledger_dir,
    )

    result = runner.run()

    # Display results
    console.print("[bold]Results:[/bold]\n")

    if result.repos_completed:
        console.print(f"  [green]Completed:[/green] {', '.join(result.repos_completed)}")
    if result.repos_failed:
        console.print(f"  [red]Failed:[/red]    {', '.join(result.repos_failed)}")
    if result.integration_passed:
        console.print(
            f"  [green]Tests passed:[/green] {', '.join(result.integration_passed)}"
        )
    if result.integration_failed:
        console.print(
            f"  [red]Tests failed:[/red]  {', '.join(result.integration_failed)}"
        )

    if result.errors:
        console.print("\n[bold]Errors:[/bold]")
        for err in result.errors:
            console.print(f"  [red]- {err}[/red]")

    exit_code = 0 if not result.repos_failed and not result.integration_failed else 1
    raise typer.Exit(code=exit_code)


@multi_repo_app.command("scan")
def multi_repo_scan(
    repos: list[str] = typer.Option(
        ..., "--repos", "-R", help="Repository root paths to scan"
    ),
) -> None:
    """Detect cross-repo dependencies by scanning imports and package files.

    Scans Python imports and package.json dependencies to build a
    dependency graph across the specified repositories.
    """
    from owlmind.multi_repo import MultiRepoConfig, MultiRepoRunner

    console.print(f"[bold]OWLMIND v{__version__} -- multi-repo scan[/bold]\n")

    runner = MultiRepoRunner(config=MultiRepoConfig())
    dep_graph = runner.detect_dependencies(repos)

    has_deps = any(deps for deps in dep_graph.values())

    if not has_deps:
        console.print("[dim]No cross-repo dependencies detected.[/dim]")
        console.print("\nScanned repos:")
        for r in repos:
            console.print(f"  - {r}")
        return

    table = Table(title="Detected Dependencies")
    table.add_column("Repository", style="bold")
    table.add_column("Depends On")

    for repo_path, deps in sorted(dep_graph.items()):
        deps_str = ", ".join(deps) if deps else "[dim]-[/dim]"
        table.add_row(repo_path, deps_str)

    console.print(table)
    console.print(
        "\n[dim]Use these in the 'dependencies' section of your multi-repo YAML config.[/dim]"
    )


@multi_repo_app.command("status")
def multi_repo_status(
    session_id: str = typer.Option(
        ..., "--session-id", help="Multi-repo session ID or any repo session ID"
    ),
    sessions_dir: Path = typer.Option(DEFAULT_SESSIONS, "--sessions-dir"),
) -> None:
    """Show cross-repo orchestration status.

    Loads the session and displays its status. If the session directory
    contains multi-repo metadata, shows all linked repo sessions.
    """
    import json as json_mod

    from owlmind.session import load_session

    console.print(f"[bold]OWLMIND v{__version__} -- multi-repo status[/bold]\n")

    # Check for multi-repo metadata file
    multi_meta_path = sessions_dir / session_id / "multi_repo_meta.json"
    if multi_meta_path.exists():
        try:
            multi_data = json_mod.loads(multi_meta_path.read_text())
        except (json_mod.JSONDecodeError, OSError) as exc:
            console.print(f"[red]Error reading multi-repo metadata: {exc}[/red]")
            raise typer.Exit(code=1) from None

        console.print(f"  Multi-repo ID: [bold]{session_id}[/bold]")
        console.print(f"  Rollback:      {multi_data.get('rollback_policy', '?')}")
        console.print()

        table = Table(title="Repository Sessions")
        table.add_column("Repository", style="bold")
        table.add_column("Session ID")
        table.add_column("Status")
        table.add_column("Goals")

        for repo_path, sid in multi_data.get("repo_sessions", {}).items():
            try:
                meta = load_session(sid, sessions_dir)
                status_color = {
                    "DONE": "green",
                    "FAILED": "red",
                    "BLOCKED": "yellow",
                    "RUNNING": "blue",
                    "STOPPED": "dim",
                }.get(meta.status, "white")
                run_done = sum(1 for r in meta.runs if r.status == "done")
                goals_str = f"{run_done}/{len(meta.goals)}"
                table.add_row(
                    repo_path,
                    sid[:20],
                    f"[{status_color}]{meta.status}[/{status_color}]",
                    goals_str,
                )
            except FileNotFoundError:
                table.add_row(repo_path, sid[:20], "[dim]not found[/dim]", "?")

        console.print(table)
        return

    # Fallback: show single session status
    try:
        meta = load_session(session_id, sessions_dir)
    except FileNotFoundError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1) from None

    status_color = {
        "DONE": "green",
        "FAILED": "red",
        "BLOCKED": "yellow",
        "RUNNING": "blue",
        "STOPPED": "dim",
    }.get(meta.status, "white")

    console.print(f"  Session:  [bold]{meta.session_id}[/bold]")
    console.print(f"  Status:   [{status_color}]{meta.status}[/{status_color}]")
    console.print(f"  Goals:    {len(meta.goals)}")
    run_done = sum(1 for r in meta.runs if r.status == "done")
    run_failed = sum(1 for r in meta.runs if r.status == "failed")
    console.print(f"  Done:     {run_done}/{len(meta.goals)}")
    if run_failed:
        console.print(f"  Failed:   [red]{run_failed}[/red]")
    if meta.last_block_reason:
        console.print(f"  Blocked:  {meta.last_block_reason}")
