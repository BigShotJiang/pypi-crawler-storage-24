"""Shared helpers for CLI subcommands."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import typer
from rich.console import Console
from rich.table import Table

from owlmind.evidence import EvidenceStore
from owlmind.policy import PolicyEngine

console = Console()

# Default paths
DEFAULT_POLICIES = Path("policies")
DEFAULT_RUNS = Path("runs")
DEFAULT_QUEUE = Path("queue")
DEFAULT_LEDGER = Path("ledger")
DEFAULT_SESSIONS = Path("sessions")


def make_storage(
    *,
    runs_dir: Path = DEFAULT_RUNS,
    ledger_dir: Path = DEFAULT_LEDGER,
    queue_dir: Path = DEFAULT_QUEUE,
    sessions_dir: Path = DEFAULT_SESSIONS,
    memory_db: Path | None = None,
) -> Any:
    """Create a ``StorageBackend`` from default paths.

    Returns a :class:`~owlmind.storage.interface.StorageBackend` with
    file-based adapters for all subsystems.
    """
    from owlmind.storage import create_storage

    return create_storage(
        runs_dir=runs_dir,
        ledger_dir=ledger_dir,
        queue_dir=queue_dir,
        sessions_dir=sessions_dir,
        memory_db=memory_db,
    )


def make_cycle_manager(
    policies_dir: Path,
    runs_dir: Path,
    *,
    with_llm: bool = False,
    with_worker: str = "none",
    with_budget: bool = False,
    ledger_dir: Path = DEFAULT_LEDGER,
    force_provider: str | None = None,
    memory_db: Path | None = None,
) -> tuple:  # type: ignore[type-arg]
    """Create PolicyEngine, EvidenceStore, and CycleManager."""
    from owlmind.agent.cycle import CycleManager

    policy = PolicyEngine.from_directory(policies_dir)
    evidence = EvidenceStore(runs_dir)

    llm_driver = None
    if with_llm:
        llm_driver = make_llm_driver(force_provider=force_provider)

    worker_driver = None
    if with_worker != "none":
        worker_driver = make_worker_driver(with_worker, policy)

    budget_governor = None
    ledger = None
    if with_llm or with_budget:
        budget_governor, ledger = make_budget(ledger_dir)

    memory_store = None
    if memory_db is not None:
        try:
            from owlmind.memory.store import MemoryStore

            memory_store = MemoryStore(memory_db)
        except Exception as exc:
            console.print(f"[yellow]Warning: could not open memory store: {exc}[/yellow]")

    from owlmind.utils import ToolLimits as _TL

    mgr = CycleManager(
        evidence=evidence,
        policy=policy,
        policies_dir=policies_dir,
        llm_driver=llm_driver,
        worker_driver=worker_driver,
        budget_governor=budget_governor,
        ledger=ledger,
        memory_store=memory_store,
        limits=_TL(timeout_seconds=600),
    )
    return policy, evidence, mgr


def make_budget(ledger_dir: Path) -> tuple:  # type: ignore[type-arg]
    """Create BudgetGovernor and UsageLedger from environment config."""
    from owlmind.budget import BudgetGovernor
    from owlmind.config import OwlMindConfig
    from owlmind.ledger import UsageLedger

    cfg = OwlMindConfig.from_env()
    ledger = UsageLedger(ledger_dir)
    governor = BudgetGovernor(cfg.budget, cfg.pricing, ledger)
    return governor, ledger


def make_worker_driver(mode: str, policy: PolicyEngine) -> object:
    """Create a worker driver based on the selected mode."""
    if mode == "claude_cli":
        from owlmind.config import OwlMindConfig
        from owlmind.utils import ToolLimits
        from owlmind.worker.claude_cli_driver import ClaudeCLIDriver

        cfg = OwlMindConfig.from_env()
        return ClaudeCLIDriver(
            policy=policy,
            limits=ToolLimits(timeout_seconds=600),
            continue_mode=cfg.worker.claude_cli_continue,
        )

    msg = f"Unknown worker mode: {mode}"
    raise ValueError(msg)


def make_llm_driver(force_provider: str | None = None) -> object:
    """Create LLM router from environment config."""
    from owlmind.config import OwlMindConfig
    from owlmind.llm.factory import build_llm_router

    cfg = OwlMindConfig.from_env()
    try:
        return build_llm_router(cfg, force_planner=force_provider, force_judge=force_provider)
    except RuntimeError as exc:
        console.print(f"[red]{exc}[/red]")
        console.print("  pip install 'owlmind[openai]'   + OPENAI_API_KEY")
        console.print("  pip install 'owlmind[anthropic]' + ANTHROPIC_API_KEY")
        console.print("  pip install 'owlmind[gemini]'   + GEMINI_API_KEY")
        console.print("  OWLMIND_OLLAMA_ENABLED=true      (local Ollama)")
        console.print("  OWLMIND_LLAMACPP_ENABLED=true    (local llama.cpp)")
        raise typer.Exit(code=1) from None


def print_totals(title: str, totals: object) -> None:
    """Print a UsageTotals object as a rich table."""
    from owlmind.ledger import UsageTotals

    assert isinstance(totals, UsageTotals)

    table = Table(title=title)
    table.add_column("Metric", style="bold")
    table.add_column("Value", justify="right")

    table.add_row("Input tokens", f"{totals.input_tokens:,}")
    table.add_row("Output tokens", f"{totals.output_tokens:,}")
    table.add_row("Total tokens", f"{totals.total_tokens:,}")
    table.add_row("Estimated USD", f"${totals.estimated_usd:.4f}")
    table.add_row("LLM calls", str(totals.llm_calls))

    console.print(table)

    if totals.models:
        model_table = Table(title="Models Used")
        model_table.add_column("Model", style="bold")
        model_table.add_column("Calls", justify="right")
        for model, count in sorted(totals.models.items(), key=lambda x: -x[1]):
            model_table.add_row(model, str(count))
        console.print(model_table)


def autopilot_event_printer(name: str, data: dict[str, Any]) -> None:
    """Print autopilot events to the console."""
    if name == "started":
        console.print(f"[green]Run started: {data.get('run_id', '?')}[/green]")
    elif name == "resumed":
        console.print(
            f"[cyan]Resumed run: {data.get('run_id', '?')} (state={data.get('state', '?')})[/cyan]"
        )
    elif name == "step":
        step = data.get("step", "?")
        state = data.get("state", "?")
        msg = data.get("message", "")
        console.print(f"[dim]Step {step}:[/dim] {state} — {msg}")
    elif name == "llm_planner_start":
        console.print("[cyan]  → Calling LLM planner...[/cyan]")
    elif name == "llm_planner_done":
        console.print("[green]  → Planner response generated.[/green]")
    elif name == "llm_planner_error":
        console.print(f"[red]  → Planner error: {data.get('error', '?')}[/red]")
    elif name == "llm_judge_start":
        console.print("[cyan]  → Calling LLM judge...[/cyan]")
    elif name == "llm_judge_done":
        console.print("[green]  → Judge response generated.[/green]")
    elif name == "llm_judge_error":
        console.print(f"[red]  → Judge error: {data.get('error', '?')}[/red]")
    elif name == "worker_start":
        console.print("[cyan]  → Running worker...[/cyan]")
    elif name == "worker_done":
        console.print("[green]  → Worker done.[/green]")
    elif name == "worker_error":
        console.print(f"[red]  → Worker error: {data.get('error', '?')}[/red]")
    elif name == "worker_approval_needed":
        console.print(f"[yellow]  → Worker needs approval: {data.get('message', '?')}[/yellow]")
    elif name == "blocked":
        console.print(f"[yellow]Blocked: {data.get('state', '?')}[/yellow]")
    elif name == "terminal":
        console.print(f"[bold]{data.get('message', '?')}[/bold]")
    elif name == "exported":
        console.print(f"[green]Exported: {data.get('path', '?')}[/green]")
    elif name == "finished":
        console.print(f"[dim]Finished: {data.get('stop_reason', '?')}[/dim]")
    elif name == "error":
        console.print(f"[red]Error: {data.get('error', '?')}[/red]")
    elif name == "max_steps":
        console.print(f"[yellow]Max steps reached at step {data.get('step', '?')}[/yellow]")


def print_session_result(result: Any) -> None:
    """Print session result summary."""
    status_color = {
        "DONE": "green",
        "FAILED": "red",
        "BLOCKED": "yellow",
        "RUNNING": "blue",
        "STOPPED": "dim",
    }.get(result.status, "white")

    console.print(f"[bold {status_color}]Session: {result.status}[/bold {status_color}]")
    console.print(f"  Session ID:  {result.session_id}")
    console.print(f"  Goals:       {result.goals_done}/{result.goals_total} done")
    if result.goals_failed:
        console.print(f"  Failed:      {result.goals_failed}")
    if result.goals_blocked:
        console.print(f"  Blocked:     {result.goals_blocked}")
    if hasattr(result, "goals_skipped") and result.goals_skipped:
        console.print(f"  Skipped:     {result.goals_skipped}")
    if result.last_block_reason:
        console.print(f"  Reason:      {result.last_block_reason}")

    if result.next_commands:
        console.print("\n[bold]Next commands:[/bold]")
        for cmd in result.next_commands:
            console.print(f"  {cmd}")


def session_exit_code(status: str) -> int:
    """Map session status to CLI exit code."""
    if status == "DONE":
        return 0
    if status == "BLOCKED":
        return 2
    if status == "FAILED":
        return 4
    if status == "STOPPED":
        return 5
    return 1
