"""CLI commands for the distributed scheduler."""

from __future__ import annotations

import asyncio

import typer

scheduler_app = typer.Typer(help="Distributed scheduler for goal dispatch.")


@scheduler_app.command("start")
def start(
    backend: str = typer.Option("file", help="Storage backend (file/rabbitmq/kafka/postgres)"),
    poll_interval: float = typer.Option(5.0, help="Seconds between scheduler ticks"),
    stale_timeout: float = typer.Option(3600.0, help="Seconds before stale goal reset"),
    sessions_dir: str = typer.Option("sessions", help="Sessions directory"),
    runs_dir: str = typer.Option("runs", help="Runs directory"),
    ledger_dir: str = typer.Option("ledger", help="Ledger directory"),
    queue_dir: str = typer.Option("queue", help="Queue directory"),
    postgres_dsn: str = typer.Option("", help="PostgreSQL DSN"),
    rabbitmq_url: str = typer.Option("", help="RabbitMQ AMQP URL"),
    rabbitmq_queue_name: str = typer.Option("owlmind.tasks", help="RabbitMQ queue name"),
    kafka_bootstrap_servers: str = typer.Option(
        "", help="Kafka broker addresses (required for kafka backend)"
    ),
    kafka_topic: str = typer.Option("owlmind.tasks", help="Kafka topic name"),
    kafka_group_id: str = typer.Option("owlmind-workers", help="Kafka consumer group ID"),
    s3_bucket: str = typer.Option("", help="S3 bucket for artifacts"),
    s3_endpoint_url: str = typer.Option("", help="S3/MinIO endpoint URL"),
    qdrant_url: str = typer.Option("", help="Qdrant URL for memory"),
    memory_db: str = typer.Option("", help="SQLite memory database path"),
    log_level: str = typer.Option("INFO", help="Log level"),
) -> None:
    """Start the distributed scheduler service.

    The scheduler polls sessions with status RUNNING, computes ready
    goals via DAG topology, and enqueues them for workers to process.
    """
    import logging

    from owlmind.scheduler import Scheduler, SchedulerConfig
    from owlmind.storage import create_storage

    logging.basicConfig(level=getattr(logging, log_level.upper(), logging.INFO))

    storage = create_storage(
        backend=backend,
        runs_dir=runs_dir,
        ledger_dir=ledger_dir,
        queue_dir=queue_dir,
        sessions_dir=sessions_dir,
        postgres_dsn=postgres_dsn,
        rabbitmq_url=rabbitmq_url,
        rabbitmq_queue_name=rabbitmq_queue_name,
        kafka_bootstrap_servers=kafka_bootstrap_servers,
        kafka_topic=kafka_topic,
        kafka_group_id=kafka_group_id,
        s3_bucket=s3_bucket,
        s3_endpoint_url=s3_endpoint_url,
        qdrant_url=qdrant_url,
        memory_db=memory_db or None,
    )

    config = SchedulerConfig(
        poll_interval=poll_interval,
        stale_timeout=stale_timeout,
    )

    scheduler = Scheduler(storage, config)
    asyncio.run(scheduler.run())
