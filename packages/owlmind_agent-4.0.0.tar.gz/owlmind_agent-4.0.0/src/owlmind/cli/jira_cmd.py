"""CLI commands for Jira issue tracker integration."""

from __future__ import annotations

import asyncio
import os

import typer
from rich.console import Console

jira_app = typer.Typer(help="Jira issue tracker integration.")
console = Console()


def _get_jira_config() -> dict[str, str]:
    """Resolve Jira configuration from environment."""
    return {
        "base_url": os.environ.get("OWLMIND_JIRA_BASE_URL", ""),
        "email": os.environ.get("OWLMIND_JIRA_EMAIL", ""),
        "api_token": os.environ.get("OWLMIND_JIRA_API_TOKEN", ""),
    }


@jira_app.command("create-issue")
def cmd_create_issue(
    project: str = typer.Option(..., "--project", "-p", help="Jira project key (e.g. DEV)"),
    summary: str = typer.Option(..., "--summary", "-s", help="Issue summary"),
    description: str = typer.Option("", "--desc", "-d", help="Issue description"),
    issue_type: str = typer.Option("Task", "--type", "-t", help="Issue type (Task, Bug, Story)"),
    priority: str = typer.Option("", "--priority", help="Priority (High, Medium, Low)"),
) -> None:
    """Create a Jira issue."""
    from owlmind.integrations.issue_trackers import create_issue_tracker

    cfg = _get_jira_config()
    if not cfg["base_url"] or not cfg["email"] or not cfg["api_token"]:
        console.print(
            "[red]Jira not configured. Set OWLMIND_JIRA_BASE_URL, "
            "OWLMIND_JIRA_EMAIL, OWLMIND_JIRA_API_TOKEN.[/red]"
        )
        raise typer.Exit(1)

    tracker = create_issue_tracker("jira", **cfg)
    params: dict = {
        "project": project,
        "summary": summary,
        "issuetype": issue_type,
    }
    if description:
        params["description"] = description
    if priority:
        params["priority"] = priority

    result = asyncio.run(tracker.create_issue(params))
    if result.ok:
        console.print(f"[green]Issue created:[/green] {result.issue_key}")
        if result.url:
            console.print(f"  URL: {result.url}")
    else:
        console.print(f"[red]Failed:[/red] {result.detail}")
        raise typer.Exit(1)


@jira_app.command("validate")
def cmd_validate() -> None:
    """Validate Jira connection."""
    from owlmind.integrations.issue_trackers import create_issue_tracker

    cfg = _get_jira_config()
    if not cfg["base_url"]:
        console.print("[red]OWLMIND_JIRA_BASE_URL not set.[/red]")
        raise typer.Exit(1)

    tracker = create_issue_tracker("jira", **cfg)
    ok = asyncio.run(tracker.validate_config())
    if ok:
        console.print("[green]Jira connection OK[/green]")
    else:
        console.print("[red]Jira connection failed[/red]")
        raise typer.Exit(1)
