"""Cycle CLI subcommands — manual inbox/outbox cycle management."""

from __future__ import annotations

import json
import time
from pathlib import Path

import typer

from owlmind import __version__
from owlmind.agent.schemas import CycleState
from owlmind.evidence import EvidenceStore
from owlmind.operator import _auto_commit

from ._helpers import (
    DEFAULT_POLICIES,
    DEFAULT_RUNS,
    console,
    make_cycle_manager,
)

cycle_app = typer.Typer(
    name="cycle",
    help="Manual inbox/outbox cycle: Planner (ChatGPT) -> Worker (Claude) -> Judge (ChatGPT)",
    no_args_is_help=True,
)


@cycle_app.command("start")
def cycle_start(
    goal: str = typer.Option(..., "--goal", "-g", help="Goal for the cycle"),
    workspace: Path = typer.Option(Path("."), "--workspace", "-w", help="Project workspace"),
    policies_dir: Path = typer.Option(DEFAULT_POLICIES, "--policies", "-p"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
    sandbox: bool = typer.Option(
        False, "--sandbox/--no-sandbox", help="Enable git worktree sandbox"
    ),
    auto_verify: bool = typer.Option(
        True, "--auto-verify/--no-auto-verify", help="Auto-detect verify commands"
    ),
    skill_pack: list[str] = typer.Option(
        [], "--skill-pack", "-s", help="Skill pack ID(s) to activate (repeatable)"
    ),
    refine: bool = typer.Option(
        False, "--refine/--no-refine", help="Pre-validate goal via LLM (FS55)"
    ),
    force_complexity: str = typer.Option(
        "",
        "--force-complexity",
        help="Override complexity: simple | medium | complex (FS57)",
    ),
) -> None:
    """Start a new Planner/Worker/Judge cycle."""
    _, _, mgr = make_cycle_manager(policies_dir, runs_dir)

    console.print(f"[bold]OWLMIND v{__version__} — cycle start[/bold]\n")
    meta = mgr.start(
        goal=goal,
        workspace=str(workspace),
        sandbox=sandbox,
        auto_verify=auto_verify,
        skill_packs=skill_pack or None,
        refine=refine,
        force_complexity=force_complexity or None,
    )

    console.print("[green]Cycle started![/green]")
    console.print(f"  Run ID:    [bold]{meta.run_id}[/bold]")
    console.print(f"  Goal:      {meta.goal}")
    console.print(f"  State:     {meta.state.value}")
    console.print(f"  Iteration: {meta.iteration}")
    console.print(f"  Workspace: {meta.workspace}")
    if skill_pack:
        console.print(f"  Skills:    {', '.join(skill_pack)}")

    complexity_val = meta.extra.get("complexity", "medium")
    console.print(f"  Complexity: {complexity_val}")

    refined = meta.extra.get("refined_goal")
    if refined and refined.get("changed"):
        console.print(f"  Refined:   {refined['refined'][:80]}")
        console.print(f"  Risk:      {refined['risk_level']}")

    sandbox_info = meta.extra.get("sandbox", {})
    if sandbox_info.get("enabled"):
        console.print(f"  Sandbox:   {sandbox_info.get('kind', '?')}")
        if sandbox_info.get("branch_name"):
            console.print(f"  Branch:    {sandbox_info['branch_name']}")

    profile_info = meta.extra.get("profile", {})
    if profile_info.get("kind", "unknown") != "unknown":
        console.print(
            f"  Profile:   {profile_info['kind']} ({', '.join(profile_info.get('markers', []))})"
        )
        if profile_info.get("suggested_verify"):
            console.print(f"  Suggested: {profile_info['suggested_verify']}")

    console.print()
    console.print(mgr.next_inbox_hint(meta))


@cycle_app.command("submit-planner")
def cycle_submit_planner(
    run_id: str = typer.Option(..., "--run-id", help="Run ID"),
    file: Path = typer.Option(None, "--file", "-f", help="Override inbox file path"),
    policies_dir: Path = typer.Option(DEFAULT_POLICIES, "--policies", "-p"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
) -> None:
    """Submit planner response and generate worker prompt."""
    _, _, mgr = make_cycle_manager(policies_dir, runs_dir)

    console.print(f"[bold]OWLMIND v{__version__} — cycle submit-planner[/bold]\n")
    try:
        meta = mgr.submit_planner(run_id, file=file)
    except (ValueError, FileNotFoundError, RuntimeError) as exc:
        console.print(f"[red]Error: {exc}[/red]")
        raise typer.Exit(code=1) from None

    console.print("[green]Planner response accepted![/green]")
    console.print(f"  State:     {meta.state.value}")
    console.print(f"  Iteration: {meta.iteration}")
    console.print()
    console.print(mgr.next_inbox_hint(meta))


@cycle_app.command("submit-worker")
def cycle_submit_worker(
    run_id: str = typer.Option(..., "--run-id", help="Run ID"),
    file: Path = typer.Option(None, "--file", "-f", help="Override inbox file path"),
    policies_dir: Path = typer.Option(DEFAULT_POLICIES, "--policies", "-p"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
) -> None:
    """Submit worker report, run verify commands, generate judge prompt."""
    _, _, mgr = make_cycle_manager(policies_dir, runs_dir)

    console.print(f"[bold]OWLMIND v{__version__} — cycle submit-worker[/bold]\n")
    try:
        meta = mgr.submit_worker(run_id, file=file)
    except (ValueError, FileNotFoundError, RuntimeError) as exc:
        console.print(f"[red]Error: {exc}[/red]")
        raise typer.Exit(code=1) from None

    state_color = "green" if meta.state == CycleState.WAIT_JUDGE else "red"
    console.print(f"[{state_color}]Worker processed (state: {meta.state.value})[/{state_color}]")
    console.print(f"  Iteration: {meta.iteration}")
    if meta.hard_fail_reasons:
        console.print("[red]Hard fail reasons:[/red]")
        for r in meta.hard_fail_reasons:
            console.print(f"  - {r}")
    console.print()
    console.print(mgr.next_inbox_hint(meta))


@cycle_app.command("submit-judge")
def cycle_submit_judge(
    run_id: str = typer.Option(..., "--run-id", help="Run ID"),
    file: Path = typer.Option(None, "--file", "-f", help="Override inbox file path"),
    policies_dir: Path = typer.Option(DEFAULT_POLICIES, "--policies", "-p"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
) -> None:
    """Submit judge response and finalize or iterate."""
    _, _, mgr = make_cycle_manager(policies_dir, runs_dir)

    console.print(f"[bold]OWLMIND v{__version__} — cycle submit-judge[/bold]\n")
    try:
        meta = mgr.submit_judge(run_id, file=file)
    except (ValueError, FileNotFoundError, RuntimeError) as exc:
        console.print(f"[red]Error: {exc}[/red]")
        raise typer.Exit(code=1) from None

    state_color = "green" if meta.state == CycleState.DONE else "yellow"
    if meta.state == CycleState.FAILED:
        state_color = "red"

    console.print(f"[{state_color}]Judge verdict processed![/{state_color}]")
    console.print(f"  State:     {meta.state.value}")
    console.print(f"  Iteration: {meta.iteration}")
    console.print()
    console.print(mgr.next_inbox_hint(meta))


@cycle_app.command("status")
def cycle_status(
    run_id: str = typer.Option(..., "--run-id", help="Run ID"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
    policies_dir: Path = typer.Option(DEFAULT_POLICIES, "--policies", "-p"),
) -> None:
    """Show current cycle status and next required action."""
    _, evidence, mgr = make_cycle_manager(policies_dir, runs_dir)

    console.print(f"[bold]OWLMIND v{__version__} — cycle status[/bold]\n")
    try:
        meta = mgr.status(run_id)
    except (FileNotFoundError, Exception) as exc:
        console.print(f"[red]Error: {exc}[/red]")
        raise typer.Exit(code=1) from None

    console.print(f"  Run ID:    [bold]{meta.run_id}[/bold]")
    console.print(f"  Goal:      {meta.goal}")
    console.print(f"  State:     {meta.state.value}")
    console.print(f"  Iteration: {meta.iteration}/{meta.limits.max_iterations}")
    console.print(f"  Workspace: {meta.workspace}")

    sandbox_info = meta.extra.get("sandbox", {})
    if sandbox_info.get("enabled"):
        console.print(f"  Sandbox:   {sandbox_info.get('kind', '?')}")

    console.print()
    console.print(mgr.next_inbox_hint(meta))

    events = evidence.read_events(run_id)
    console.print(f"\n[dim]({len(events)} events in log)[/dim]")


@cycle_app.command("next")
def cycle_next(
    run_id: str = typer.Option(..., "--run-id", help="Run ID"),
    policies_dir: Path = typer.Option(DEFAULT_POLICIES, "--policies", "-p"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
) -> None:
    """Auto-advance the cycle if inbox file exists, or show next step."""
    _, _, mgr = make_cycle_manager(policies_dir, runs_dir)

    console.print(f"[bold]OWLMIND v{__version__} — cycle next[/bold]\n")
    try:
        meta, message = mgr.next(run_id)
    except (ValueError, FileNotFoundError, RuntimeError) as exc:
        console.print(f"[red]Error: {exc}[/red]")
        raise typer.Exit(code=1) from None

    state_color = "green"
    if meta.state == CycleState.FAILED:
        state_color = "red"
    elif meta.state == CycleState.DONE:
        state_color = "bold green"

    console.print(
        f"[{state_color}]State: {meta.state.value}[/{state_color}]  Iteration: {meta.iteration}"
    )
    console.print()
    console.print(message)


@cycle_app.command("plan")
def cycle_plan(
    run_id: str = typer.Option(..., "--run-id", help="Run ID"),
    provider: str = typer.Option(None, "--provider", help="Force specific provider"),
    policies_dir: Path = typer.Option(DEFAULT_POLICIES, "--policies", "-p"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
) -> None:
    """Call LLM to generate planner response (requires API key)."""
    _, _, mgr = make_cycle_manager(
        policies_dir,
        runs_dir,
        with_llm=True,
        force_provider=provider,
    )

    console.print(f"[bold]OWLMIND v{__version__} — cycle plan (LLM)[/bold]\n")

    try:
        meta = mgr.run_planner_llm(run_id)
    except (ValueError, FileNotFoundError, RuntimeError) as exc:
        console.print(f"[red]Error: {exc}[/red]")
        raise typer.Exit(code=1) from None

    console.print("[green]Planner response generated by LLM![/green]")
    console.print(f"  State:     {meta.state.value}")
    console.print(f"  Iteration: {meta.iteration}")
    console.print()
    console.print(f"Next: [bold]owlmind cycle submit-planner --run-id {run_id}[/bold]")


@cycle_app.command("judge")
def cycle_judge(
    run_id: str = typer.Option(..., "--run-id", help="Run ID"),
    provider: str = typer.Option(None, "--provider", help="Force specific provider"),
    policies_dir: Path = typer.Option(DEFAULT_POLICIES, "--policies", "-p"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
) -> None:
    """Call LLM to generate judge response (requires API key)."""
    _, _, mgr = make_cycle_manager(
        policies_dir,
        runs_dir,
        with_llm=True,
        force_provider=provider,
    )

    console.print(f"[bold]OWLMIND v{__version__} — cycle judge (LLM)[/bold]\n")

    try:
        meta = mgr.run_judge_llm(run_id)
    except (ValueError, FileNotFoundError, RuntimeError) as exc:
        console.print(f"[red]Error: {exc}[/red]")
        raise typer.Exit(code=1) from None

    console.print("[green]Judge response generated by LLM![/green]")
    console.print(f"  State:     {meta.state.value}")
    console.print(f"  Iteration: {meta.iteration}")
    console.print()
    console.print(f"Next: [bold]owlmind cycle submit-judge --run-id {run_id}[/bold]")


@cycle_app.command("work")
def cycle_work(
    run_id: str = typer.Option(..., "--run-id", help="Run ID"),
    use_worker: str = typer.Option("claude_cli", "--use-worker", help="Worker mode: claude_cli"),
    policies_dir: Path = typer.Option(DEFAULT_POLICIES, "--policies", "-p"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
) -> None:
    """Run worker via Claude CLI (requires approval). Creates approval if needed."""
    _, _, mgr = make_cycle_manager(
        policies_dir,
        runs_dir,
        with_worker=use_worker,
    )

    console.print(f"[bold]OWLMIND v{__version__} — cycle work[/bold]\n")

    try:
        meta, message = mgr.run_worker_cli(run_id)
    except (ValueError, FileNotFoundError, RuntimeError) as exc:
        console.print(f"[red]Error: {exc}[/red]")
        raise typer.Exit(code=1) from None

    state_color = "green" if meta.state == CycleState.WAIT_WORKER else "yellow"
    if meta.state == CycleState.WAIT_APPROVAL:
        state_color = "yellow"
    console.print(f"[{state_color}]State: {meta.state.value}[/{state_color}]")
    console.print(message)


@cycle_app.command("auto")
def cycle_auto(
    run_id: str = typer.Option(..., "--run-id", help="Run ID"),
    interval: int = typer.Option(2, "--interval", "-i", help="Seconds between checks"),
    max_steps: int = typer.Option(20, "--max-steps", "-n", help="Max advance steps (0=unlimited)"),
    use_llm: str = typer.Option("none", "--use-llm", help="LLM mode: none|planner|judge|both"),
    use_worker: str = typer.Option("none", "--use-worker", help="Worker mode: none|claude_cli"),
    auto_approve: bool = typer.Option(False, "--auto-approve", help="Auto-approve worker runs without prompting"),
    policies_dir: Path = typer.Option(DEFAULT_POLICIES, "--policies", "-p"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
) -> None:
    """Auto-advance cycle repeatedly until blocked, done, or failed."""
    need_llm = use_llm in ("planner", "judge", "both")
    _, _, mgr = make_cycle_manager(
        policies_dir,
        runs_dir,
        with_llm=need_llm,
        with_worker=use_worker,
    )

    llm_planner = use_llm in ("planner", "both")
    llm_judge = use_llm in ("judge", "both")
    worker_auto = use_worker != "none"

    console.print(f"[bold]OWLMIND v{__version__} — cycle auto[/bold]\n")
    console.print(f"  Run ID:     {run_id}")
    console.print(f"  Interval:   {interval}s")
    console.print(f"  Max steps:  {max_steps or 'unlimited'}")
    console.print(f"  LLM mode:   {use_llm}")
    console.print(f"  Worker:     {use_worker}")
    console.print()

    terminal_states = {CycleState.DONE, CycleState.FAILED}
    blocking_states = {CycleState.WAIT_APPROVAL}
    step = 0

    while True:
        step += 1
        if max_steps and step > max_steps:
            console.print(f"\n[yellow]Max steps ({max_steps}) reached.[/yellow]")
            break

        try:
            meta, message = mgr.next(run_id)
        except (ValueError, FileNotFoundError, RuntimeError) as exc:
            console.print(f"[red]Error: {exc}[/red]")
            break

        console.print(f"[dim]Step {step}:[/dim] {meta.state.value} (iter {meta.iteration})")

        if meta.state in terminal_states:
            if meta.state == CycleState.DONE:
                _auto_commit(workspace=meta.workspace, run_id=run_id)
            console.print(f"\n[bold]{message}[/bold]")
            break

        if meta.state in blocking_states:
            console.print(f"\n[yellow]{message}[/yellow]")
            break

        waiting_states = {
            CycleState.STARTED_WAIT_PLANNER,
            CycleState.WAIT_WORKER,
            CycleState.WAIT_JUDGE,
        }
        if meta.state in waiting_states and "Waiting" in message:
            llm_used = False

            if meta.state == CycleState.STARTED_WAIT_PLANNER and llm_planner:
                console.print("[cyan]  → Calling LLM planner...[/cyan]")
                try:
                    mgr.run_planner_llm(run_id)
                    console.print("[green]  → Planner response generated.[/green]")
                    llm_used = True
                except Exception as exc:
                    console.print(f"[red]  → LLM planner error: {exc}[/red]")

            elif meta.state == CycleState.WAIT_JUDGE and llm_judge:
                console.print("[cyan]  → Calling LLM judge...[/cyan]")
                try:
                    mgr.run_judge_llm(run_id)
                    console.print("[green]  → Judge response generated.[/green]")
                    llm_used = True
                except Exception as exc:
                    console.print(f"[red]  → LLM judge error: {exc}[/red]")

            elif meta.state == CycleState.WAIT_WORKER and worker_auto:
                console.print("[cyan]  → Running worker via CLI...[/cyan]")
                try:
                    w_meta, w_msg = mgr.run_worker_cli(run_id)
                    if w_meta.state == CycleState.WAIT_APPROVAL:
                        if auto_approve:
                            # Read token directly from metadata and auto-approve
                            pending = w_meta.extra.get("pending_approval", {})
                            token = pending.get("token", "")
                            if token:
                                from owlmind.approval import resolve_approval
                                resolve_approval(mgr.meta_store, run_id, token, approved=True)
                                console.print("[green]  → Auto-approved worker.[/green]")
                                llm_used = True
                            else:
                                console.print(f"[yellow]  → {w_msg}[/yellow]")
                                break
                        else:
                            console.print(f"[yellow]  → {w_msg}[/yellow]")
                            break
                    else:
                        console.print(f"[green]  → {w_msg}[/green]")
                        llm_used = True
                except Exception as exc:
                    console.print(f"[red]  → Worker error: {exc}[/red]")

            if not llm_used:
                console.print(f"\n[yellow]Blocked: {message.splitlines()[0]}[/yellow]")
                break

            time.sleep(0.1)
            continue

        if meta.hard_fail_reasons:
            console.print(f"\n[red]Hard fail: {meta.hard_fail_reasons}[/red]")
            break

        time.sleep(interval)

    console.print(f"\n[dim]Auto-advance finished after {step} step(s).[/dim]")


@cycle_app.command("approve")
def cycle_approve(
    run_id: str = typer.Option(..., "--run-id", help="Run ID"),
    token: str = typer.Option(..., "--token", "-t", help="Approval token"),
    policies_dir: Path = typer.Option(DEFAULT_POLICIES, "--policies", "-p"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
) -> None:
    """Approve a pending approval request."""
    _, _, mgr = make_cycle_manager(policies_dir, runs_dir)

    console.print(f"[bold]OWLMIND v{__version__} — cycle approve[/bold]\n")

    from owlmind.approval import resolve_approval

    ok, msg = resolve_approval(mgr.meta_store, run_id, token, approved=True)
    if ok:
        console.print(f"[green]{msg}[/green]")
    else:
        console.print(f"[red]{msg}[/red]")
        raise typer.Exit(code=1)


@cycle_app.command("deny")
def cycle_deny(
    run_id: str = typer.Option(..., "--run-id", help="Run ID"),
    token: str = typer.Option(..., "--token", "-t", help="Approval token"),
    policies_dir: Path = typer.Option(DEFAULT_POLICIES, "--policies", "-p"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
) -> None:
    """Deny a pending approval request."""
    _, _, mgr = make_cycle_manager(policies_dir, runs_dir)

    console.print(f"[bold]OWLMIND v{__version__} — cycle deny[/bold]\n")

    from owlmind.approval import resolve_approval

    ok, msg = resolve_approval(mgr.meta_store, run_id, token, approved=False)
    if ok:
        console.print(f"[green]{msg}[/green]")
    else:
        console.print(f"[red]{msg}[/red]")
        raise typer.Exit(code=1)


@cycle_app.command("approve-required")
def cycle_approve_required(
    run_id: str = typer.Option(..., "--run-id", help="Run ID"),
    reason: str = typer.Option("Manual test", "--reason", help="Reason for approval"),
    policies_dir: Path = typer.Option(DEFAULT_POLICIES, "--policies", "-p"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
) -> None:
    """Create an approval requirement on a run (for testing)."""
    _, _, mgr = make_cycle_manager(policies_dir, runs_dir)

    console.print(f"[bold]OWLMIND v{__version__} — cycle approve-required[/bold]\n")

    from owlmind.approval import create_approval

    approval = create_approval(mgr.meta_store, run_id, reason)
    console.print("[yellow]Approval required![/yellow]")
    console.print(f"  Token:   {approval.token}")
    console.print(f"  Reason:  {approval.reason}")
    console.print(f"  Expires: {int(approval.expires_at - approval.created_at)}s")
    console.print()
    console.print(f"  Approve: owlmind cycle approve --run-id {run_id} --token {approval.token}")
    console.print(f"  Deny:    owlmind cycle deny --run-id {run_id} --token {approval.token}")


@cycle_app.command("ingest")
def cycle_ingest(
    run_id: str = typer.Option(..., "--run-id", help="Run ID"),
    file: Path = typer.Option(..., "--file", "-f", help="JSON file to ingest"),
    policies_dir: Path = typer.Option(DEFAULT_POLICIES, "--policies", "-p"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
) -> None:
    """Ingest a JSON response file into the correct inbox based on cycle state."""
    _, _, mgr = make_cycle_manager(policies_dir, runs_dir)

    console.print(f"[bold]OWLMIND v{__version__} — cycle ingest[/bold]\n")

    if not file.exists():
        console.print(f"[red]File not found: {file}[/red]")
        raise typer.Exit(code=1)

    try:
        meta, target = mgr.ingest(run_id, file=file)
    except (ValueError, FileNotFoundError, RuntimeError, json.JSONDecodeError) as exc:
        console.print(f"[red]Error: {exc}[/red]")
        raise typer.Exit(code=1) from None

    console.print("[green]File ingested successfully![/green]")
    console.print(f"  Written to: {target}")
    console.print(f"  State:      {meta.state.value}")
    console.print()

    submit_cmds: dict[CycleState, str] = {
        CycleState.STARTED_WAIT_PLANNER: f"owlmind cycle submit-planner --run-id {run_id}",
        CycleState.WAIT_WORKER: f"owlmind cycle submit-worker --run-id {run_id}",
        CycleState.WAIT_JUDGE: f"owlmind cycle submit-judge --run-id {run_id}",
    }
    next_cmd = submit_cmds.get(meta.state, "")
    if next_cmd:
        console.print(f"Next: [bold]{next_cmd}[/bold]")


@cycle_app.command("pack")
def cycle_pack(
    run_id: str = typer.Option(..., "--run-id", help="Run ID"),
    policies_dir: Path = typer.Option(DEFAULT_POLICIES, "--policies", "-p"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
) -> None:
    """Generate or regenerate the PR pack for a run."""
    _, _, mgr = make_cycle_manager(policies_dir, runs_dir)

    console.print(f"[bold]OWLMIND v{__version__} — cycle pack[/bold]\n")
    try:
        content = mgr.generate_pr_pack(run_id)
    except (FileNotFoundError, Exception) as exc:
        console.print(f"[red]Error: {exc}[/red]")
        raise typer.Exit(code=1) from None

    pack_path = runs_dir / run_id / "pr_pack.md"
    console.print(f"[green]PR pack written to: {pack_path}[/green]")
    console.print(f"\n[dim]{content[:500]}...[/dim]" if len(content) > 500 else f"\n{content}")


@cycle_app.command("verify-chain")
def cycle_verify_chain(
    run_id: str = typer.Option(..., "--run-id", help="Run ID"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
) -> None:
    """Verify the evidence hash chain for a run."""
    evidence = EvidenceStore(runs_dir)

    console.print(f"[bold]OWLMIND v{__version__} — cycle verify-chain[/bold]\n")

    result = evidence.verify_chain(run_id)

    if result.ok:
        console.print("[green]Chain integrity: OK[/green]")
    else:
        console.print("[red]Chain integrity: FAILED[/red]")
        for err in result.errors:
            console.print(f"  - {err}")

    console.print(f"  Tip hash: {result.tip_hash[:32]}...")
    console.print(f"  Sequence: {result.seq}")

    if not result.ok:
        raise typer.Exit(code=1)


@cycle_app.command("export")
def cycle_export(
    run_id: str = typer.Option(..., "--run-id", help="Run ID"),
    out: Path = typer.Option(None, "--out", "-o", help="Output zip path"),
    policies_dir: Path = typer.Option(DEFAULT_POLICIES, "--policies", "-p"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
) -> None:
    """Export run evidence as a zip bundle."""
    _, _, mgr = make_cycle_manager(policies_dir, runs_dir)

    console.print(f"[bold]OWLMIND v{__version__} — cycle export[/bold]\n")
    try:
        zip_path = mgr.export(run_id, out_path=out)
    except (FileNotFoundError, Exception) as exc:
        console.print(f"[red]Error: {exc}[/red]")
        raise typer.Exit(code=1) from None

    console.print(f"[green]Export created: {zip_path}[/green]")
    console.print(f"  Size: {zip_path.stat().st_size} bytes")


@cycle_app.command("detect-profile")
def cycle_detect_profile(
    workspace: Path = typer.Option(Path("."), "--workspace", "-w", help="Project workspace"),
) -> None:
    """Detect project type and suggest verify commands."""
    from owlmind.agent.profile import detect_profile

    console.print(f"[bold]OWLMIND v{__version__} — cycle detect-profile[/bold]\n")

    profile = detect_profile(workspace)

    console.print(f"  Profile: [bold]{profile.kind}[/bold]")
    if profile.markers:
        console.print(f"  Markers: {', '.join(profile.markers)}")
    if profile.suggested_verify_commands:
        console.print("  Suggested verify commands:")
        for cmd in profile.suggested_verify_commands:
            console.print(f"    - {cmd}")
    else:
        console.print("  [dim]No verify commands suggested.[/dim]")


@cycle_app.command("sandbox")
def cycle_sandbox(
    run_id: str = typer.Option(..., "--run-id", help="Run ID"),
    action: str = typer.Argument("status", help="Action: status | cleanup"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Confirm cleanup"),
    policies_dir: Path = typer.Option(DEFAULT_POLICIES, "--policies", "-p"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
) -> None:
    """Manage sandbox worktree for a run."""
    _, _, mgr = make_cycle_manager(policies_dir, runs_dir)

    console.print(f"[bold]OWLMIND v{__version__} — cycle sandbox {action}[/bold]\n")

    if action == "status":
        info = mgr.sandbox_status(run_id)
        if not info.enabled:
            console.print("[dim]No sandbox found for this run.[/dim]")
            return
        console.print(f"  Kind:    {info.kind}")
        console.print(f"  Path:    {info.worktree_path}")
        if info.branch_name:
            console.print(f"  Branch:  {info.branch_name}")

    elif action == "cleanup":
        if not yes:
            console.print("[red]Cleanup requires --yes to confirm.[/red]")
            raise typer.Exit(code=1)

        meta = mgr.status(run_id)
        workspace = meta.extra.get("sandbox", {}).get("base_repo_path", meta.workspace)
        ok, message = mgr.sandbox_cleanup(run_id, workspace)
        if ok:
            console.print(f"[green]{message}[/green]")
        else:
            console.print(f"[red]{message}[/red]")
            raise typer.Exit(code=1)

    else:
        console.print(f"[red]Unknown action: {action}. Use 'status' or 'cleanup'.[/red]")
        raise typer.Exit(code=1)
