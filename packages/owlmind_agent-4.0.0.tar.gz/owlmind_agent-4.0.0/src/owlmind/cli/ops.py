"""Operational CLI — github, ci, security, release, setup, up, goals, dashboard."""

from __future__ import annotations

import os
import uuid
from pathlib import Path
from typing import Any

import typer
from rich.table import Table

from owlmind import __version__

from ._helpers import console

github_app = typer.Typer(
    name="github",
    help="GitHub PR operations via gh CLI (approval-gated)",
    no_args_is_help=True,
)

ci_app = typer.Typer(
    name="ci",
    help="CI operations — workflow status, logs, fix-session",
    no_args_is_help=True,
)

security_app = typer.Typer(
    name="security",
    help="Security tools — secret scanning, git hooks",
    no_args_is_help=True,
)

release_app = typer.Typer(
    name="release",
    help="Release tools — changelog, verify, bundle",
    no_args_is_help=True,
)

setup_app = typer.Typer(help="Zero-friction project setup.")

goals_app = typer.Typer(
    name="goals",
    help="Goals templates — list, render, and init goals files.",
    no_args_is_help=True,
)

dashboard_app = typer.Typer(
    name="dashboard",
    help="Dashboard index — link all dashboards and protocols.",
    no_args_is_help=True,
)


# ===========================================================================
# GitHub PR
# ===========================================================================


@github_app.command("pr-list")
def github_pr_list(
    workspace: Path = typer.Option(".", "--workspace", "-w", help="Git repo path"),
    state: str = typer.Option("open", "--state", "-s", help="PR state: open|closed|all"),
    limit: int = typer.Option(10, "--limit", "-n", help="Max PRs to list"),
) -> None:
    """List pull requests."""
    from owlmind.github import pr_list

    console.print(f"[bold]OWLMIND v{__version__} — PR list[/bold]\n")

    prs = pr_list(str(workspace), state=state, limit=limit)
    if not prs:
        console.print("[dim]No PRs found.[/dim]")
        return

    table = Table(title=f"Pull Requests ({state})")
    table.add_column("#", style="cyan")
    table.add_column("Title")
    table.add_column("Branch", style="green")
    table.add_column("State", style="yellow")

    for pr in prs:
        table.add_row(
            str(pr.get("number", "?")),
            str(pr.get("title", ""))[:50],
            str(pr.get("headRefName", "")),
            str(pr.get("state", "")),
        )
    console.print(table)


@github_app.command("pr-view")
def github_pr_view(
    pr_number: int = typer.Option(..., "--pr", "-p", help="PR number"),
    workspace: Path = typer.Option(".", "--workspace", "-w"),
) -> None:
    """View a pull request."""
    from owlmind.github import pr_view

    console.print(f"[bold]OWLMIND v{__version__} — PR view[/bold]\n")

    try:
        info = pr_view(str(workspace), pr_number)
        console.print(f"PR #{info.number}: {info.title}")
        console.print(f"  State: {info.state}")
        console.print(f"  Branch: {info.head_branch} → {info.base_branch}")
        console.print(f"  Changes: +{info.additions} -{info.deletions}")
        console.print(f"  Mergeable: {info.mergeable}")
        console.print(f"  URL: {info.url}")
    except RuntimeError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1) from None


@github_app.command("pr-create")
def github_pr_create(
    title: str = typer.Option(..., "--title", "-t", help="PR title"),
    body: str = typer.Option("", "--body", "-b", help="PR body"),
    base: str = typer.Option("", "--base", help="Base branch"),
    workspace: Path = typer.Option(".", "--workspace", "-w"),
    draft: bool = typer.Option(False, "--draft", help="Create as draft"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Approve creation"),
) -> None:
    """Create a pull request (requires --yes for approval)."""
    from owlmind.github import pr_create

    console.print(f"[bold]OWLMIND v{__version__} — PR create[/bold]\n")

    if not yes:
        console.print("[yellow]PR creation requires explicit approval. Add --yes.[/yellow]")
        raise typer.Exit(code=2)

    result = pr_create(
        str(workspace), title=title, body=body, base=base, draft=draft, approved=True
    )
    if result.ok:
        console.print(f"[green]PR created: #{result.pr_number}[/green]")
        console.print(f"  URL: {result.url}")
    else:
        console.print(f"[red]Failed: {result.error}[/red]")
        raise typer.Exit(code=1)


@github_app.command("create-pr")
def github_create_pr_from_result(
    run_id: str = typer.Option("", "--run-id", "-r", help="Run ID to create PR from"),
    session_id: str = typer.Option("", "--session-id", "-s", help="Session ID to create PR from"),
    base: str = typer.Option("main", "--base", help="Base branch"),
    draft: bool = typer.Option(False, "--draft", help="Create as draft PR"),
    runs_dir: Path = typer.Option("runs", "--runs-dir", help="Runs directory"),
    sessions_dir: Path = typer.Option("sessions", "--sessions-dir", help="Sessions directory"),
) -> None:
    """Create a PR from a OWLMIND run or session result."""
    from owlmind.github_pr import create_pr_from_run, create_pr_from_session

    console.print(f"[bold]OWLMIND v{__version__} — create PR from result[/bold]\n")

    if not run_id and not session_id:
        console.print("[red]Provide --run-id or --session-id.[/red]")
        raise typer.Exit(code=2)

    if run_id and session_id:
        console.print("[red]Provide only one of --run-id or --session-id.[/red]")
        raise typer.Exit(code=2)

    if run_id:
        result = create_pr_from_run(run_id, runs_dir=runs_dir, base=base, draft=draft)
    else:
        result = create_pr_from_session(
            session_id,
            sessions_dir=sessions_dir,
            base=base,
            draft=draft,
        )

    if result.get("created"):
        console.print(f"[green]PR created: #{result.get('number', '?')}[/green]")
        console.print(f"  URL: {result.get('url', '')}")
    else:
        console.print(f"[red]Failed: {result.get('error', 'unknown')}[/red]")
        raise typer.Exit(code=1)


@github_app.command("review")
def github_review(
    repo: str = typer.Option("", "--repo", "-r", help="GitHub repo (owner/name)"),
    pr: int = typer.Option(0, "--pr", "-p", help="PR number"),
    workspace: str = typer.Option(".", "--workspace", "-w"),
    max_iterations: int = typer.Option(2, "--iterations", "-n"),
    post_comment_flag: bool = typer.Option(False, "--post-comment", help="Post result as PR comment"),
    token: str = typer.Option("", "--token", help="GitHub token (or set GITHUB_TOKEN)"),
) -> None:
    """Review a GitHub PR with the graph pipeline and optionally post result as comment."""
    from rich.panel import Panel

    from owlmind.github_review import post_comment as _post
    from owlmind.github_review import review_pr

    if not repo or not pr:
        console.print("[red]--repo and --pr are required[/red]")
        raise typer.Exit(1)

    console.print(f"[bold]OwlMind GitHub Review[/bold] — {repo}#{pr}")

    result = review_pr(repo=repo, pr_number=pr, workspace=workspace,
                       max_iterations=max_iterations, token=token)

    verdict_color = {"APPROVED": "green", "NEEDS_FIX": "yellow", "REJECTED": "red"}.get(result.verdict, "white")
    console.print(f"[bold {verdict_color}]VERDICT: {result.verdict or 'ERROR'}[/bold {verdict_color}]")

    if result.review:
        console.print(Panel(result.review[:600], title="Review", border_style=verdict_color))

    if result.error:
        console.print(f"[red]Error: {result.error}[/red]")

    if post_comment_flag:
        ok = _post(repo=repo, pr_number=pr, body=result.format_comment(), token=token)
        if ok:
            console.print(f"[green]Comment posted on {repo}#{pr}[/green]")
        else:
            console.print("[yellow]Failed to post comment (check GITHUB_TOKEN)[/yellow]")


@github_app.command("pr-merge")
def github_pr_merge(
    pr_number: int = typer.Option(..., "--pr", "-p", help="PR number"),
    method: str = typer.Option("squash", "--method", "-m", help="merge|squash|rebase"),
    workspace: Path = typer.Option(".", "--workspace", "-w"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Approve merge"),
) -> None:
    """Merge a pull request (requires --yes for approval)."""
    from owlmind.github import pr_merge

    console.print(f"[bold]OWLMIND v{__version__} — PR merge[/bold]\n")

    if not yes:
        console.print("[yellow]PR merge requires explicit approval. Add --yes.[/yellow]")
        raise typer.Exit(code=2)

    result = pr_merge(str(workspace), pr_number, method=method, approved=True)
    if result.ok:
        console.print(f"[green]PR #{pr_number} merged.[/green]")
    else:
        console.print(f"[red]Failed: {result.error}[/red]")
        raise typer.Exit(code=1)


# ===========================================================================
# CI
# ===========================================================================


@ci_app.command("runs")
def ci_runs(
    workspace: Path = typer.Option(".", "--workspace", "-w"),
    limit: int = typer.Option(10, "--limit", "-n"),
    branch: str = typer.Option("", "--branch", "-b"),
) -> None:
    """List recent CI workflow runs."""
    from owlmind.ci import list_runs

    console.print(f"[bold]OWLMIND v{__version__} — CI runs[/bold]\n")

    runs = list_runs(str(workspace), limit=limit, branch=branch)
    if not runs:
        console.print("[dim]No runs found.[/dim]")
        return

    table = Table(title="CI Workflow Runs")
    table.add_column("ID", style="cyan")
    table.add_column("Name")
    table.add_column("Status", style="yellow")
    table.add_column("Conclusion")
    table.add_column("Branch", style="green")

    for r in runs:
        conclusion_style = (
            "green"
            if r.conclusion == "success"
            else ("red" if r.conclusion == "failure" else "dim")
        )
        table.add_row(
            str(r.id),
            r.name[:30],
            r.status,
            f"[{conclusion_style}]{r.conclusion}[/{conclusion_style}]",
            r.head_branch,
        )
    console.print(table)


@ci_app.command("status")
def ci_status(
    run_id: int = typer.Option(..., "--run-id", "-r", help="Workflow run ID"),
    workspace: Path = typer.Option(".", "--workspace", "-w"),
) -> None:
    """Show status of a workflow run."""
    from owlmind.ci import run_status

    console.print(f"[bold]OWLMIND v{__version__} — CI status[/bold]\n")

    try:
        data = run_status(str(workspace), run_id)
        console.print(f"Run: {data.get('name', '?')}")
        console.print(f"Status: {data.get('status', '?')}")
        console.print(f"Conclusion: {data.get('conclusion', '?')}")
        console.print(f"Branch: {data.get('headBranch', '?')}")

        for job in data.get("jobs", []):
            style = "green" if job.get("conclusion") == "success" else "red"
            console.print(
                f"  [{style}]{job.get('name', '?')}: {job.get('conclusion', '?')}[/{style}]"
            )
    except RuntimeError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1) from None


@ci_app.command("logs")
def ci_logs(
    run_id: int = typer.Option(..., "--run-id", "-r", help="Workflow run ID"),
    workspace: Path = typer.Option(".", "--workspace", "-w"),
    tail: int = typer.Option(50, "--tail", "-t", help="Last N lines"),
) -> None:
    """Show logs for a workflow run."""
    from owlmind.ci import run_logs

    console.print(f"[bold]OWLMIND v{__version__} — CI logs[/bold]\n")

    try:
        logs = run_logs(str(workspace), run_id)
        lines = logs.splitlines()
        if tail and len(lines) > tail:
            lines = lines[-tail:]
        for line in lines:
            console.print(line)
    except RuntimeError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1) from None


@ci_app.command("fix-session")
def ci_fix_session(
    run_id: int = typer.Option(..., "--run-id", "-r", help="Failed workflow run ID"),
    workspace: Path = typer.Option(".", "--workspace", "-w"),
    out: Path = typer.Option(None, "--out", "-o", help="Output goals file"),
) -> None:
    """Generate a goals.yaml from failed CI checks for automated fixing."""
    from owlmind.ci import generate_fix_goals

    console.print(f"[bold]OWLMIND v{__version__} — CI fix-session[/bold]\n")

    try:
        path = generate_fix_goals(str(workspace), run_id, out_path=out)
        console.print(f"[green]Fix goals written to: {path}[/green]")
        console.print("\nRun with:")
        console.print(f"  owlmind session start --goals-file {path}")
    except ValueError as exc:
        console.print(f"[yellow]{exc}[/yellow]")
        raise typer.Exit(code=1) from None
    except RuntimeError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1) from None


# ===========================================================================
# CI/CD integration — run sessions from pipelines
# ===========================================================================


@ci_app.command("run")
def ci_run(
    goal: str = typer.Option(..., "--goal", "-g", help="Goal to execute"),
    workspace: Path = typer.Option(".", "--workspace", "-w"),
    output_json: bool = typer.Option(False, "--json", help="Output result as JSON"),
    backend: str = typer.Option("file", "--backend", help="Storage backend"),
    runs_dir: str = typer.Option("runs", "--runs-dir"),
    ledger_dir: str = typer.Option("ledger", "--ledger-dir"),
    queue_dir: str = typer.Option("queue", "--queue-dir"),
    sessions_dir: str = typer.Option("sessions", "--sessions-dir"),
    timeout: int = typer.Option(0, "--timeout", help="Max wait seconds (0=unlimited)"),
) -> None:
    """Run a OWLMIND session and wait for completion. Returns non-zero on failure."""
    import asyncio
    import time as _time

    from owlmind.storage import create_storage

    storage = create_storage(
        backend=backend,
        runs_dir=runs_dir,
        ledger_dir=ledger_dir,
        queue_dir=queue_dir,
        sessions_dir=sessions_dir,
    )

    async def _run() -> dict[str, Any]:
        # Create a single-goal session
        from datetime import UTC, datetime

        from owlmind.session import SESSION_RUNNING, GoalSpec, SessionMeta

        session_id = f"ci-{uuid.uuid4().hex[:8]}"
        now = datetime.now(tz=UTC).isoformat()
        goals = [GoalSpec(id="goal-1", goal=goal, workspace=str(workspace.resolve()))]
        meta = SessionMeta(
            session_id=session_id,
            created_at=now,
            updated_at=now,
            status=SESSION_RUNNING,
            goals=goals,
        )
        await storage.sessions.save_session(meta)

        # Add to queue
        await storage.queue.add(
            goal=goal,
            workspace=str(workspace.resolve()),
            session_id=session_id,
            goal_id="goal-1",
        )

        # Poll for completion
        start = _time.monotonic()
        while True:
            loaded = await storage.sessions.load_session(session_id)
            if loaded.status in ("DONE", "FAILED", "STOPPED"):
                return {
                    "session_id": session_id,
                    "status": loaded.status,
                    "goals": len(loaded.goals),
                    "exit_code": 0 if loaded.status == "DONE" else 1,
                }
            if timeout > 0 and (_time.monotonic() - start) > timeout:
                return {
                    "session_id": session_id,
                    "status": "TIMEOUT",
                    "exit_code": 2,
                }
            await asyncio.sleep(5)

    try:
        result = asyncio.run(_run())
    except Exception as exc:
        result = {"error": str(exc), "exit_code": 1}

    if output_json:
        import json

        console.print(json.dumps(result, indent=2))
    else:
        status = result.get("status", "ERROR")
        sid = result.get("session_id", "?")
        style = "green" if status == "DONE" else "red"
        console.print(f"Session: {sid}")
        console.print(f"Status: [{style}]{status}[/{style}]")

    raise typer.Exit(code=result.get("exit_code", 1))


@ci_app.command("session-status")
def ci_session_status(
    session_id: str = typer.Option(..., "--session-id", "-s", help="Session ID"),
    output_json: bool = typer.Option(False, "--json", help="Output as JSON"),
    backend: str = typer.Option("file", "--backend"),
    sessions_dir: str = typer.Option("sessions", "--sessions-dir"),
    runs_dir: str = typer.Option("runs", "--runs-dir"),
    ledger_dir: str = typer.Option("ledger", "--ledger-dir"),
    queue_dir: str = typer.Option("queue", "--queue-dir"),
) -> None:
    """Check status of a OWLMIND session (for CI polling)."""
    import asyncio

    from owlmind.storage import create_storage

    storage = create_storage(
        backend=backend,
        runs_dir=runs_dir,
        ledger_dir=ledger_dir,
        queue_dir=queue_dir,
        sessions_dir=sessions_dir,
    )

    async def _status() -> dict[str, Any]:
        meta = await storage.sessions.load_session(session_id)
        goals_info = []
        for g in meta.goals:
            run_info = next((r for r in meta.runs if r.goal_id == g.id), None)
            goals_info.append(
                {
                    "id": g.id,
                    "goal": g.goal[:80],
                    "status": run_info.status if run_info else "pending",
                }
            )
        return {
            "session_id": session_id,
            "status": meta.status,
            "goals": goals_info,
            "exit_code": 0 if meta.status == "DONE" else 1,
        }

    try:
        result = asyncio.run(_status())
    except Exception as exc:
        result = {"session_id": session_id, "error": str(exc), "exit_code": 1}

    if output_json:
        import json

        console.print(json.dumps(result, indent=2))
    else:
        status = result.get("status", "ERROR")
        style = "green" if status == "DONE" else ("yellow" if status == "RUNNING" else "red")
        console.print(f"Session: {session_id}")
        console.print(f"Status: [{style}]{status}[/{style}]")
        for g in result.get("goals", []):
            console.print(f"  {g['id']}: {g['status']} — {g['goal']}")

    raise typer.Exit(code=result.get("exit_code", 1))


@ci_app.command("artifacts")
def ci_artifacts(
    session_id: str = typer.Option(..., "--session-id", "-s", help="Session ID"),
    output_dir: Path = typer.Option("ci-artifacts", "--output-dir", "-o"),
    backend: str = typer.Option("file", "--backend"),
    sessions_dir: str = typer.Option("sessions", "--sessions-dir"),
    runs_dir: str = typer.Option("runs", "--runs-dir"),
    ledger_dir: str = typer.Option("ledger", "--ledger-dir"),
    queue_dir: str = typer.Option("queue", "--queue-dir"),
) -> None:
    """Download session artifacts (diffs, reports) for CI publishing."""
    import asyncio
    import shutil

    from owlmind.storage import create_storage

    storage = create_storage(
        backend=backend,
        runs_dir=runs_dir,
        ledger_dir=ledger_dir,
        queue_dir=queue_dir,
        sessions_dir=sessions_dir,
    )

    async def _collect() -> int:
        meta = await storage.sessions.load_session(session_id)
        output_dir.mkdir(parents=True, exist_ok=True)
        count = 0

        for run_info in meta.runs:
            if not run_info.run_id:
                continue
            run_dir = Path(runs_dir) / run_info.run_id
            if not run_dir.exists():
                continue
            dest = output_dir / run_info.run_id
            dest.mkdir(parents=True, exist_ok=True)
            for f in run_dir.iterdir():
                if f.is_file():
                    shutil.copy2(f, dest / f.name)
                    count += 1
        return count

    try:
        count = asyncio.run(_collect())
        console.print(f"[green]Collected {count} artifact(s) to {output_dir}[/green]")
    except Exception as exc:
        console.print(f"[red]Error: {exc}[/red]")
        raise typer.Exit(code=1) from None


# ===========================================================================
# Security
# ===========================================================================


@security_app.command("scan")
def security_scan(
    path: Path = typer.Option(".", "--path", "-p", help="Directory to scan"),
    fail_on_findings: bool = typer.Option(
        False, "--fail-on-findings", help="Exit 1 if secrets found"
    ),
) -> None:
    """Scan a directory for potential secrets."""
    from owlmind.security import scan_secrets

    console.print(f"[bold]OWLMIND v{__version__} — secret scan[/bold]\n")
    console.print(f"Scanning: {path.resolve()}")

    result = scan_secrets(path)
    console.print(f"Files scanned: {result.files_scanned}")

    if result.ok:
        console.print("[green]No secrets found.[/green]")
        return

    console.print(f"[red]Found {len(result.findings)} potential secret(s):[/red]\n")
    table = Table(title="Findings")
    table.add_column("File", style="cyan")
    table.add_column("Line", style="magenta")
    table.add_column("Pattern", style="yellow")
    table.add_column("Snippet", style="dim")

    for f in result.findings:
        table.add_row(f.file, str(f.line), f.pattern_name, f.snippet[:60])

    console.print(table)

    if fail_on_findings:
        raise typer.Exit(code=1)


@security_app.command("install-hooks")
def security_install_hooks(
    repo: Path = typer.Option(".", "--repo", "-r", help="Git repository path"),
) -> None:
    """Install OWLMIND git hooks (pre-commit secret scan)."""
    from owlmind.security import install_hooks

    console.print(f"[bold]OWLMIND v{__version__} — install hooks[/bold]\n")

    try:
        installed = install_hooks(repo)
        for h in installed:
            console.print(f"[green]Installed: {h}[/green]")
    except FileNotFoundError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1) from None


# ===========================================================================
# Release
# ===========================================================================


@release_app.command("changelog")
def release_changelog(
    repo: Path = typer.Option(".", "--repo", "-r", help="Git repository path"),
    out: Path = typer.Option(None, "--out", "-o", help="Output file path"),
    since: str = typer.Option("", "--since", "-s", help="Since tag (e.g. v0.18.0)"),
) -> None:
    """Generate CHANGELOG.md from git history."""
    from owlmind.release import generate_changelog

    console.print(f"[bold]OWLMIND v{__version__} — changelog[/bold]\n")

    path = generate_changelog(repo, out_path=out, since_tag=since)
    console.print(f"[green]Changelog written to: {path}[/green]")


@release_app.command("verify")
def release_verify(
    repo: Path = typer.Option(".", "--repo", "-r", help="Git repository path"),
    skip_tests: bool = typer.Option(False, "--skip-tests", help="Skip test execution"),
    skip_lint: bool = typer.Option(False, "--skip-lint", help="Skip lint check"),
) -> None:
    """Verify release readiness — version, tests, lint, changelog."""
    from owlmind.release import verify_release

    console.print(f"[bold]OWLMIND v{__version__} — release verify[/bold]\n")

    report = verify_release(
        repo,
        run_tests=not skip_tests,
        run_lint=not skip_lint,
    )

    for check in report.checks:
        status = "[green]PASS[/green]" if check.ok else "[red]FAIL[/red]"
        console.print(f"  {status} {check.name}: {check.detail}")

    console.print()
    if report.ok:
        console.print(f"[green bold]Release v{report.version} is READY[/green bold]")
    else:
        console.print(f"[red bold]Release v{report.version} NOT ready[/red bold]")
        raise typer.Exit(code=1)


@release_app.command("bundle")
def release_bundle(
    repo: Path = typer.Option(".", "--repo", "-r", help="Git repository path"),
    out_dir: Path = typer.Option(None, "--out-dir", "-o", help="Output directory"),
) -> None:
    """Create a release bundle with changelog and report."""
    from owlmind.release import create_release_bundle

    console.print(f"[bold]OWLMIND v{__version__} — release bundle[/bold]\n")

    result = create_release_bundle(repo, out_dir=out_dir)
    console.print(f"Version: {result['version']}")
    console.print(f"Output: {result['out_dir']}")
    for name, path in result["artifacts"].items():
        console.print(f"  {name}: {path}")

    if result["ok"]:
        console.print("\n[green]Release bundle created successfully.[/green]")
    else:
        console.print("\n[yellow]Bundle created but some checks failed.[/yellow]")


# ===========================================================================
# Setup
# ===========================================================================


@setup_app.command("init")
def setup_init_cmd(
    workspace: Path = typer.Option(".", "--workspace", "-w", help="Workspace root"),
) -> None:
    """Initialize workspace — create dirs, .env.example, goals template."""
    from owlmind.setup import setup_init

    console.print(f"[bold]OWLMIND v{__version__} — setup init[/bold]\n")
    result = setup_init(workspace)

    for d in result.created_dirs:
        console.print(f"  [green]Created dir:[/green]  {d}")
    for f in result.created_files:
        console.print(f"  [green]Created file:[/green] {f}")
    for s in result.skipped:
        console.print(f"  [dim]Exists:[/dim]        {s}")

    console.print("\n[bold]Checklist:[/bold]")
    console.print("  1. Fill in .env.example → copy to .env")
    console.print('  2. pip install "owlmind[telegram,openai]"  (optional extras)')
    console.print("  3. owlmind doctor")
    console.print("  4. owlmind security scan --path .")


@setup_app.command("install-hooks")
def setup_hooks_cmd(
    repo: Path = typer.Option(".", "--repo", "-r", help="Git repository path"),
) -> None:
    """Install pre-commit hooks (alias for security install-hooks)."""
    from owlmind.security import install_hooks

    console.print(f"[bold]OWLMIND v{__version__} — setup install-hooks[/bold]\n")
    installed = install_hooks(repo)
    for h in installed:
        console.print(f"  [green]Installed:[/green] {h}")


@setup_app.command("doctor")
def setup_doctor_cmd(
    workspace: Path = typer.Option(".", "--workspace", "-w", help="Workspace root"),
) -> None:
    """Run doctor + security scan (no network)."""
    from owlmind.security import scan_secrets

    console.print(f"[bold]OWLMIND v{__version__} — setup doctor[/bold]\n")

    # Basic checks inline
    console.print("[bold]Health checks...[/bold]")

    console.print("\n[bold]Security Scan[/bold]\n")
    scan = scan_secrets(workspace)
    if scan.ok:
        console.print(f"  [green]Clean[/green] — {scan.files_scanned} files scanned")
    else:
        console.print(f"  [red]{len(scan.findings)} findings[/red] in {scan.files_scanned} files")
        for finding in scan.findings[:10]:
            console.print(f"    {finding.file}:{finding.line} — {finding.pattern_name}")


# ===========================================================================
# Goals
# ===========================================================================


@goals_app.command("templates")
def goals_templates_cmd() -> None:
    """List available built-in goal templates."""
    from owlmind.templates import get_template_info, list_templates

    console.print(f"[bold]OWLMIND v{__version__} — goals templates[/bold]\n")
    for name in list_templates():
        desc = get_template_info(name)
        console.print(f"  [green]{name}[/green] — {desc}")


@goals_app.command("init")
def goals_init_cmd(
    template: str = typer.Option(..., "--template", "-t", help="Template name"),
    out: Path = typer.Option("goals.yaml", "--out", "-o", help="Output file"),
    workspace: str = typer.Option(".", "--workspace", "-w", help="Workspace path"),
) -> None:
    """Generate a goals.yaml from a built-in template."""
    from owlmind.templates import render_template

    console.print(f"[bold]OWLMIND v{__version__} — goals init[/bold]\n")
    try:
        content = render_template(template, workspace=workspace)
    except ValueError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1) from None

    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(content)
    console.print(f"[green]Goals file written to {out}[/green]")


# ===========================================================================
# Dashboard index
# ===========================================================================


@dashboard_app.command("index")
def dashboard_index_cmd(
    out: Path = typer.Option(
        "dashboards/index.html",
        "--out",
        "-o",
        help="Output HTML path",
    ),
    workspace: Path = typer.Option(".", "--workspace", "-w", help="Workspace root"),
) -> None:
    """Generate an HTML index of all dashboards and protocols."""
    from owlmind.dashboard_index import build_index

    console.print(f"[bold]OWLMIND v{__version__} — dashboard index[/bold]\n")
    path = build_index(out, [workspace])
    console.print(f"[green]Index written to {path}[/green]")


@dashboard_app.command("live")
def dashboard_live_cmd(
    runs_dir: str = typer.Option("runs", "--runs-dir", "-r", help="Runs directory"),
    interval: int = typer.Option(2, "--interval", "-i", help="Refresh interval seconds"),
    max_ticks: int = typer.Option(0, "--max-ticks", help="Max refresh cycles (0=infinite)"),
) -> None:
    """Launch interactive TUI dashboard."""
    from owlmind.tui.dashboard import LiveDashboard

    console.print(f"[bold]OWLMIND v{__version__} — live dashboard[/bold]\n")

    dash = LiveDashboard(
        runs_dir=Path(runs_dir),
        refresh_interval=interval,
        max_ticks=max_ticks,
    )
    dash.start()


@dashboard_app.command("open")
def dashboard_open_cmd(
    path: Path = typer.Option(
        "dashboards/index.html",
        "--path",
        "-p",
        help="Dashboard path",
    ),
) -> None:
    """Show path to dashboard index (does not auto-open browser)."""
    if path.exists():
        console.print(f"Dashboard: {path.resolve()}")
        console.print(f"\nOpen with:\n  open {path.resolve()}")
    else:
        console.print(f"[yellow]Not found: {path}[/yellow]")
        console.print("Run: owlmind dashboard index")


# ===========================================================================
# owlmind up — one command operator pack
# ===========================================================================


def register_up(app: typer.Typer) -> None:
    """Register the ``up`` command on the main Typer app.

    The ``up`` command is the single-command startup entry-point for
    operators.  It chains setup init, doctor fix, and a security scan,
    then prints recommended next steps.  Optionally starts the Telegram
    operator bot when ``--telegram`` is passed.

    Args:
        app: The root Typer application to attach the ``up`` command to.
    """

    @app.command("up")
    def up_cmd(
        workspace: Path = typer.Option(".", "--workspace", "-w", help="Workspace root"),
        telegram: bool = typer.Option(False, "--telegram", help="Start Telegram bot after checks"),
    ) -> None:
        """One-command startup — init, doctor fix, security scan, next steps."""
        from owlmind.setup import doctor_fix, setup_init

        console.print(f"[bold]OWLMIND v{__version__} — up[/bold]\n")

        # 1. Setup init (idempotent)
        console.print("[bold]1. Setup init[/bold]")
        try:
            result = setup_init(workspace)
            for d in result.created_dirs:
                console.print(f"  [green]Created:[/green] {d}")
            for f in result.created_files:
                console.print(f"  [green]Created:[/green] {f}")
            if result.skipped and not result.created_dirs and not result.created_files:
                console.print("  [dim]Already initialized.[/dim]")
        except Exception as exc:
            console.print(f"  [red]Setup init failed: {exc}[/red]")
            console.print("  Fix: owlmind setup init --workspace .")

        # 2. Doctor fix (safe)
        console.print("\n[bold]2. Doctor fix[/bold]")
        try:
            fix_report = doctor_fix(workspace)
            for fix in fix_report.fixes:
                if fix.fixed:
                    console.print(f"  [green]Fixed:[/green] {fix.name} — {fix.detail}")
            for warn in fix_report.warnings:
                console.print(f"  [yellow]Warning:[/yellow] {warn}")
            if not fix_report.fixes and not fix_report.warnings:
                console.print("  [dim]All healthy.[/dim]")
        except Exception as exc:
            console.print(f"  [red]Doctor fix failed: {exc}[/red]")
            console.print("  Fix: owlmind doctor --fix --workspace .")

        # 3. Security scan
        console.print("\n[bold]3. Security scan[/bold]")
        try:
            from owlmind.security import scan_secrets

            scan = scan_secrets(workspace)
            if scan.ok:
                console.print(f"  [green]Clean[/green] — {scan.files_scanned} files scanned")
            else:
                console.print(f"  [red]{len(scan.findings)} findings[/red]")
                for finding in scan.findings[:5]:
                    console.print(f"    {finding.file}:{finding.line} — {finding.pattern_name}")
        except Exception as exc:
            console.print(f"  [red]Security scan failed: {exc}[/red]")
            console.print("  Fix: owlmind security scan --path .")

        # 4. Next steps
        console.print("\n[bold]Recommended next commands:[/bold]")
        console.print("  owlmind session start --goals-file goals.yaml")
        console.print("  owlmind monitor digest")
        console.print("  owlmind goals templates")

        if telegram:
            token = os.environ.get("TELEGRAM_BOT_TOKEN")
            if token:
                console.print("\n[bold]Starting Telegram bot...[/bold]")
                try:
                    from owlmind.operator import OperatorService
                    from owlmind.telegram_bot import create_operator_bot

                    _ws = str(workspace.resolve())
                    _op = OperatorService(
                        runs_dir=workspace / "runs",
                        policies_dir=workspace / "policies",
                        ledger_dir=workspace / "ledger",
                        default_workspace=_ws,
                        allowed_workspaces=[_ws],
                    )
                    bot_app = create_operator_bot(bot_token=token, operator=_op)
                    bot_app.run_polling()
                except ImportError:
                    console.print("[red]Telegram not installed.[/red]")
                    console.print('Fix: pip install "owlmind[telegram]"')
                except Exception as exc:
                    console.print(f"[red]Telegram bot failed: {exc}[/red]")
            else:
                console.print("\n[yellow]Telegram: TELEGRAM_BOT_TOKEN not set.[/yellow]")
                console.print("  Set it to start the operator bot.")
