"""Entry point for python -m owlmind.cli."""

from owlmind.cli import app

app()
