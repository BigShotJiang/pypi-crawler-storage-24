"""CLI commands for MCP server."""

from __future__ import annotations

import typer
from rich.console import Console

mcp_app = typer.Typer(help="MCP server for IDE integration.")
console = Console()


@mcp_app.command("serve")
def mcp_serve() -> None:
    """Start the MCP server (stdio transport)."""
    from owlmind.mcp.server import MCPServer

    server = MCPServer()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        console.print("[dim]MCP server stopped.[/dim]")


@mcp_app.command("tools")
def mcp_tools() -> None:
    """List available MCP tools."""
    from owlmind.mcp.server import TOOLS

    console.print(f"[bold]OWLMIND MCP Tools[/bold] ({len(TOOLS)} tools)\n")
    for tool in TOOLS:
        console.print(f"  [cyan]{tool['name']}[/cyan]")
        console.print(f"    {tool['description']}")
        props = tool.get("inputSchema", {}).get("properties", {})
        if props:
            required = set(tool.get("inputSchema", {}).get("required", []))
            for pname, pdef in props.items():
                req_marker = " [red]*[/red]" if pname in required else ""
                console.print(f"    [dim]{pname}[/dim]: {pdef.get('type', '?')}{req_marker}")
        console.print()
