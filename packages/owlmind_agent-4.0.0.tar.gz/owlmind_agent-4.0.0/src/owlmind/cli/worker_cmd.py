"""CLI commands for the distributed worker service."""

from __future__ import annotations

import asyncio

import typer

worker_app = typer.Typer(help="Distributed worker for goal execution.")


@worker_app.command("start")
def start(
    backend: str = typer.Option("file", help="Storage backend (file/rabbitmq/kafka/postgres)"),
    poll_interval: float = typer.Option(5.0, help="Seconds between queue polls"),
    max_concurrent: int = typer.Option(1, help="Maximum concurrent task executions"),
    auto_approve: bool = typer.Option(True, help="Auto-approve worker gates"),
    max_steps: int = typer.Option(200, help="Maximum autopilot steps per task"),
    use_llm: str = typer.Option("both", help="LLM routing (none/planner/judge/both)"),
    use_worker: str = typer.Option("claude_cli", help="Worker driver (none/claude_cli)"),
    enable_sandbox: bool = typer.Option(True, help="Enable sandbox for sandbox=True tasks"),
    sandbox_base: str = typer.Option("", help="Base directory for sandbox workspaces"),
    sessions_dir: str = typer.Option("sessions", help="Sessions directory"),
    runs_dir: str = typer.Option("runs", help="Runs directory"),
    ledger_dir: str = typer.Option("ledger", help="Ledger directory"),
    queue_dir: str = typer.Option("queue", help="Queue directory"),
    postgres_dsn: str = typer.Option("", help="PostgreSQL DSN"),
    rabbitmq_url: str = typer.Option("", help="RabbitMQ AMQP URL"),
    rabbitmq_queue_name: str = typer.Option("owlmind.tasks", help="RabbitMQ queue name"),
    kafka_bootstrap_servers: str = typer.Option(
        "", help="Kafka broker addresses (required for kafka backend)"
    ),
    kafka_topic: str = typer.Option("owlmind.tasks", help="Kafka topic name"),
    kafka_group_id: str = typer.Option("owlmind-workers", help="Kafka consumer group ID"),
    s3_bucket: str = typer.Option("", help="S3 bucket for artifacts"),
    s3_endpoint_url: str = typer.Option("", help="S3/MinIO endpoint URL"),
    qdrant_url: str = typer.Option("", help="Qdrant URL for memory"),
    memory_db: str = typer.Option("", help="SQLite memory database path"),
    log_level: str = typer.Option("INFO", help="Log level"),
) -> None:
    """Start the distributed worker service.

    The worker polls QueueStorage for PENDING tasks, executes each
    through the Planner → Worker → Judge autopilot cycle, and reports
    results back for the Scheduler to collect.
    """
    import logging

    from owlmind.storage import create_storage
    from owlmind.worker.worker import WorkerConfig, WorkerService

    logging.basicConfig(level=getattr(logging, log_level.upper(), logging.INFO))

    storage = create_storage(
        backend=backend,
        runs_dir=runs_dir,
        ledger_dir=ledger_dir,
        queue_dir=queue_dir,
        sessions_dir=sessions_dir,
        postgres_dsn=postgres_dsn,
        rabbitmq_url=rabbitmq_url,
        rabbitmq_queue_name=rabbitmq_queue_name,
        kafka_bootstrap_servers=kafka_bootstrap_servers,
        kafka_topic=kafka_topic,
        kafka_group_id=kafka_group_id,
        s3_bucket=s3_bucket,
        s3_endpoint_url=s3_endpoint_url,
        qdrant_url=qdrant_url,
        memory_db=memory_db or None,
    )

    config = WorkerConfig(
        poll_interval=poll_interval,
        max_concurrent=max_concurrent,
        auto_approve=auto_approve,
        max_steps=max_steps,
        use_llm=use_llm,
        use_worker=use_worker,
        enable_sandbox=enable_sandbox,
        sandbox_base=sandbox_base,
    )

    worker = WorkerService(storage, config)
    asyncio.run(worker.run())
