"""CLI commands for the self-improvement subsystem."""

from __future__ import annotations

from pathlib import Path

import typer
from rich.table import Table

from ._helpers import console

self_improve_app = typer.Typer(
    name="self-improve",
    help="Self-improvement: analyze runs, propose improvements, A/B test.",
    no_args_is_help=True,
)


@self_improve_app.command("analyze")
def analyze(
    runs_dir: str = typer.Option("runs", help="Runs directory"),
    days: int = typer.Option(7, help="Analyze runs from last N days"),
    save: bool = typer.Option(False, help="Save report to memory"),
    memory_file: str = typer.Option("", help="Memory file path for saving insights"),
) -> None:
    """Analyze recent runs and display an analysis report."""
    from owlmind.self_improve import analyze_runs, format_insights_markdown, load_recent_runs
    from owlmind.self_improve.analyzer import analyze as deep_analyze
    from owlmind.self_improve.analyzer import collect_run_extended

    runs_path = Path(runs_dir)
    if not runs_path.is_dir():
        console.print(f"[red]Runs directory not found: {runs_dir}[/red]")
        raise typer.Exit(code=1)

    # Quick legacy analysis
    recent = load_recent_runs(runs_path, days=days)
    insights = analyze_runs(recent)
    md = format_insights_markdown(insights, days=days)
    console.print(md)

    # Deep analysis with RunExtended
    extended = collect_run_extended(runs_path)
    if extended:
        report = deep_analyze(extended)
        console.print("\n[bold cyan]Deep Analysis Report[/bold cyan]")
        console.print(f"  Runs analyzed:   {report.runs_analyzed}")
        console.print(f"  Success rate:    {report.success_rate:.0%}")
        console.print(f"  Avg duration:    {report.avg_duration_ms:.0f}ms")
        if report.failure_patterns:
            console.print(f"  Failure patterns: {len(report.failure_patterns)}")
        if report.performance_issues:
            console.print(f"  Perf issues:     {len(report.performance_issues)}")
        if report.recommendations:
            console.print("\n[bold]Recommendations:[/bold]")
            for rec in report.recommendations:
                console.print(f"  • {rec}")

    if save and insights:
        from owlmind.self_improve import save_insights_to_memory

        mem_path = (
            Path(memory_file) if memory_file else runs_path.parent / "memory" / "insights.json"
        )
        save_insights_to_memory(insights, mem_path)
        console.print(f"\n[green]Insights saved to {mem_path}[/green]")


@self_improve_app.command("proposals")
def proposals(
    runs_dir: str = typer.Option("runs", help="Runs directory"),
    improvements_dir: str = typer.Option("improvements", help="Improvements store directory"),
    max_proposals: int = typer.Option(10, help="Max proposals to generate"),
    save: bool = typer.Option(False, help="Save proposals to store"),
) -> None:
    """Generate improvement proposals from run analysis."""
    from owlmind.self_improve.analyzer import analyze as deep_analyze
    from owlmind.self_improve.analyzer import collect_run_extended
    from owlmind.self_improve.generator import FileImprovementStore, generate_improvements

    runs_path = Path(runs_dir)
    extended = collect_run_extended(runs_path)
    if not extended:
        console.print("[yellow]No run data found for analysis[/yellow]")
        return

    report = deep_analyze(extended)
    improvements = generate_improvements(report, max_proposals=max_proposals)

    if not improvements:
        console.print("[yellow]No improvements suggested[/yellow]")
        return

    table = Table(title="Improvement Proposals", show_header=True, header_style="bold cyan")
    table.add_column("ID", style="bold")
    table.add_column("Category")
    table.add_column("Title")
    table.add_column("Confidence")
    table.add_column("Target")

    for imp in improvements:
        conf_style = (
            "green" if imp.confidence >= 0.7 else "yellow" if imp.confidence >= 0.4 else "red"
        )
        table.add_row(
            imp.improvement_id,
            imp.category,
            imp.title[:50],
            f"[{conf_style}]{imp.confidence:.0%}[/{conf_style}]",
            imp.target_file or "-",
        )

    console.print(table)

    if save:
        store = FileImprovementStore(Path(improvements_dir))
        for imp in improvements:
            store.save(imp)
        console.print(
            f"\n[green]Saved {len(improvements)} proposals to {improvements_dir}/[/green]"
        )


@self_improve_app.command("list")
def list_improvements(
    improvements_dir: str = typer.Option("improvements", help="Improvements store directory"),
    status: str = typer.Option("", help="Filter by status"),
) -> None:
    """List stored improvement proposals."""
    from owlmind.self_improve.generator import FileImprovementStore

    store = FileImprovementStore(Path(improvements_dir))
    improvements = store.list_improvements(status=status or None)

    if not improvements:
        console.print("[yellow]No improvements found[/yellow]")
        return

    table = Table(title="Stored Improvements", show_header=True, header_style="bold cyan")
    table.add_column("ID", style="bold")
    table.add_column("Category")
    table.add_column("Title")
    table.add_column("Status")
    table.add_column("Confidence")

    for imp in improvements:
        status_style = {
            "proposed": "yellow",
            "testing": "cyan",
            "approved": "green",
            "applied": "bold green",
            "rejected": "red",
        }.get(imp.status, "")
        table.add_row(
            imp.improvement_id,
            imp.category,
            imp.title[:50],
            f"[{status_style}]{imp.status}[/{status_style}]" if status_style else imp.status,
            f"{imp.confidence:.0%}",
        )

    console.print(table)


@self_improve_app.command("ab-test")
def ab_test(
    action: str = typer.Argument("list", help="Action: list, create, start, result, cancel"),
    test_id: str = typer.Option("", help="Test ID (for start/result/cancel)"),
    improvement_id: str = typer.Option("", help="Improvement ID (for create)"),
    min_runs: int = typer.Option(10, help="Minimum runs per variant (for create)"),
    ab_dir: str = typer.Option("ab_tests", help="A/B tests directory"),
) -> None:
    """Manage A/B tests for improvement validation."""
    from owlmind.self_improve.ab_testing import ABTestScheduler

    scheduler = ABTestScheduler(Path(ab_dir))

    if action == "list":
        tests = scheduler.list_tests()
        if not tests:
            console.print("[yellow]No A/B tests found[/yellow]")
            return

        table = Table(title="A/B Tests", show_header=True, header_style="bold cyan")
        table.add_column("Test ID", style="bold")
        table.add_column("Improvement")
        table.add_column("Status")
        table.add_column("Runs A")
        table.add_column("Runs B")
        table.add_column("Winner")

        for t in tests:
            table.add_row(
                t.test_id,
                t.improvement_id,
                t.status,
                str(t.runs_a),
                str(t.runs_b),
                t.winner or "-",
            )
        console.print(table)

    elif action == "create":
        if not improvement_id:
            console.print("[red]--improvement-id required for create[/red]")
            raise typer.Exit(code=1)
        test = scheduler.create_test(improvement_id, min_runs=min_runs)
        console.print(f"[green]Created A/B test:[/green] {test.test_id}")

    elif action == "start":
        if not test_id:
            console.print("[red]--test-id required for start[/red]")
            raise typer.Exit(code=1)
        started = scheduler.start_test(test_id)
        if started is None:
            console.print(f"[red]Test not found or not pending: {test_id}[/red]")
            raise typer.Exit(code=1)
        console.print(f"[green]Started test:[/green] {started.test_id}")

    elif action == "result":
        if not test_id:
            console.print("[red]--test-id required for result[/red]")
            raise typer.Exit(code=1)
        evaluated = scheduler.evaluate(test_id)
        if evaluated is None:
            console.print(f"[red]Test not found: {test_id}[/red]")
            raise typer.Exit(code=1)
        rate_a = evaluated.score_a / evaluated.runs_a if evaluated.runs_a else 0
        rate_b = evaluated.score_b / evaluated.runs_b if evaluated.runs_b else 0
        console.print(f"\n[bold cyan]Test: {evaluated.test_id}[/bold cyan]")
        console.print(f"  Variant A: {rate_a:.0%} ({evaluated.runs_a} runs)")
        console.print(f"  Variant B: {rate_b:.0%} ({evaluated.runs_b} runs)")
        console.print(f"  Winner:    {evaluated.winner or 'undecided'}")
        console.print(f"  Status:    {evaluated.status}")

    elif action == "cancel":
        if not test_id:
            console.print("[red]--test-id required for cancel[/red]")
            raise typer.Exit(code=1)
        cancelled = scheduler.cancel_test(test_id)
        if cancelled is None:
            console.print(f"[red]Test not found: {test_id}[/red]")
            raise typer.Exit(code=1)
        console.print(f"[green]Cancelled test:[/green] {cancelled.test_id}")

    else:
        console.print(f"[red]Unknown action: {action}[/red]")
        raise typer.Exit(code=1)


@self_improve_app.command("apply")
def apply_cmd(
    improvement_id: str = typer.Argument(..., help="Improvement ID to apply"),
    workspace: str = typer.Option(".", help="Workspace directory"),
    improvements_dir: str = typer.Option("improvements", help="Improvements store directory"),
    dry_run: bool = typer.Option(False, help="Validate without applying"),
) -> None:
    """Apply an approved improvement to the workspace."""
    from owlmind.self_improve.applicator import apply_improvement
    from owlmind.self_improve.generator import FileImprovementStore

    store = FileImprovementStore(Path(improvements_dir))
    imp = store.load(improvement_id)
    if imp is None:
        console.print(f"[red]Improvement not found: {improvement_id}[/red]")
        raise typer.Exit(code=1)

    result = apply_improvement(imp, Path(workspace), dry_run=dry_run)
    prefix = "[dry-run] " if result.dry_run else ""
    if result.success:
        console.print(f"[green]{prefix}Applied successfully:[/green] {result.message}")
        if result.files_modified:
            for f in result.files_modified:
                console.print(f"  Modified: {f}")
    else:
        console.print(f"[red]{prefix}Failed:[/red] {result.message}")
        raise typer.Exit(code=1)
