"""Slack bot CLI commands."""

from __future__ import annotations

import typer

app = typer.Typer(
    name="slack",
    help="Slack operator bot — control and monitor from Slack",
    no_args_is_help=True,
)


@app.command("serve")
def slack_serve(
    bot_token: str = typer.Option(..., envvar="SLACK_BOT_TOKEN", help="Slack bot token (xoxb-...)"),
    app_token: str = typer.Option(..., envvar="SLACK_APP_TOKEN", help="Slack app token (xapp-...)"),
    allowed_users: str = typer.Option(
        "",
        "--allowed-users",
        envvar="SLACK_ALLOWED_USERS",
        help="Comma-separated Slack user IDs allowed to use the bot (empty = all)",
    ),
    port: int = typer.Option(3000, help="Socket mode port (informational only)"),
) -> None:
    """Start the Slack bot in Socket Mode."""
    from owlmind.slack_bot import create_slack_bot, is_slack_available

    if not is_slack_available():
        typer.echo("slack-bolt not installed. Run: pip install 'owlmind[slack]'")
        raise typer.Exit(1)

    allowed_user_ids = [u.strip() for u in allowed_users.split(",") if u.strip()]

    bot = create_slack_bot(
        bot_token=bot_token,
        app_token=app_token,
        allowed_user_ids=allowed_user_ids or None,
    )
    if bot is None:
        typer.echo("Failed to create Slack bot. Check your bot token.")
        raise typer.Exit(1)

    import asyncio

    from slack_bolt.adapter.socket_mode.async_handler import AsyncSocketModeHandler

    async def _start() -> None:
        handler = AsyncSocketModeHandler(bot, app_token)
        typer.echo("Starting Slack bot (Socket Mode)...")
        await handler.start_async()

    asyncio.run(_start())
