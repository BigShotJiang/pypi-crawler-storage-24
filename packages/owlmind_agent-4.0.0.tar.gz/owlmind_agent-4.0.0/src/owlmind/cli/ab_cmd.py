"""CLI commands for Prompt A/B testing: owlmind ab run / history."""
from __future__ import annotations

from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

ab_app = typer.Typer(help="Prompt A/B testing — compare two system-prompt variants")
console = Console()


@ab_app.command("run")
def ab_run(
    goal: str = typer.Option(..., "--goal", "-g", help="Task goal to run both variants against"),
    agent: str = typer.Option(
        "planner",
        "--agent",
        "-a",
        help="Target agent role for the prompt addition (planner/worker/judge)",
    ),
    variant_a: str = typer.Option(
        ..., "--variant-a", help="Prompt addition text for variant A"
    ),
    variant_b: str = typer.Option(
        ..., "--variant-b", help="Prompt addition text for variant B"
    ),
    workspace: Path = typer.Option(
        Path("."), "--workspace", "-w", help="Workspace directory passed to GraphRunner"
    ),
    save: bool = typer.Option(True, "--save/--no-save", help="Persist result to history"),
) -> None:
    """Run the same goal under two prompt variants and report which wins.

    Example:

      owlmind ab run \\
        --goal "add a retry mechanism to the HTTP client" \\
        --agent planner \\
        --variant-a "Be concise. Prefer a decorator-based approach." \\
        --variant-b "Be thorough. Include exponential back-off with jitter."
    """
    from owlmind.agent.ab_tester import ABTester, PromptVariant

    va = PromptVariant(name="A", agent=agent, prompt_addition=variant_a)
    vb = PromptVariant(name="B", agent=agent, prompt_addition=variant_b)

    tester = ABTester()

    console.print(f"\n[bold]A/B Test[/bold] — agent: [cyan]{agent}[/cyan]")
    console.print(f"  Goal : [italic]{goal}[/italic]")
    console.print(f"  [A]  : {variant_a[:80]}")
    console.print(f"  [B]  : {variant_b[:80]}\n")

    with console.status("Running variant A…"):
        result = tester.run(goal, str(workspace), va, vb)

    # Display result table
    table = Table(title="A/B Result", show_lines=True)
    table.add_column("Variant", style="bold")
    table.add_column("Verdict")
    table.add_column("Score", justify="right")
    table.add_column("Prompt addition (truncated)")

    def _score_color(score: float) -> str:
        if score >= 1.0:
            return "green"
        if score >= 0.0:
            return "yellow"
        return "red"

    table.add_row(
        "A",
        f"[{_score_color(result.score_a)}]{result.verdict_a}[/{_score_color(result.score_a)}]",
        str(result.score_a),
        variant_a[:60],
    )
    table.add_row(
        "B",
        f"[{_score_color(result.score_b)}]{result.verdict_b}[/{_score_color(result.score_b)}]",
        str(result.score_b),
        variant_b[:60],
    )
    console.print(table)

    winner_color = {"A": "green", "B": "cyan", "TIE": "yellow"}.get(result.winner, "white")
    console.print(
        f"\n[bold]Winner:[/bold] [{winner_color}]{result.winner}[/{winner_color}]"
        + (" (tie — scores equal)" if result.winner == "TIE" else "")
    )

    if save:
        tester.save(result)
        console.print(f"[dim]Result saved to {tester._results_file}[/dim]")


@ab_app.command("history")
def ab_history(
    limit: int = typer.Option(20, "--limit", "-n", help="Maximum rows to display"),
    results_file: Path | None = typer.Option(
        None, "--file", "-f", help="Override default results JSONL path"
    ),
) -> None:
    """Show a table of past A/B prompt comparison runs."""
    from owlmind.agent.ab_tester import ABTester

    tester = ABTester(results_file=results_file)
    history = tester.load_history()

    if not history:
        console.print("[yellow]No A/B history found.[/yellow]")
        console.print(f"  Expected file: {tester._results_file}")
        raise typer.Exit(0)

    # Show most-recent rows first
    rows = list(reversed(history))[:limit]

    table = Table(title=f"A/B History (latest {len(rows)} of {len(history)})", show_lines=False)
    table.add_column("#", justify="right", style="dim")
    table.add_column("Timestamp", style="cyan")
    table.add_column("Agent")
    table.add_column("Goal (truncated)")
    table.add_column("Verdict A")
    table.add_column("Verdict B")
    table.add_column("Winner", style="bold")

    winner_styles = {"A": "green", "B": "cyan", "TIE": "yellow"}

    for idx, r in enumerate(rows, start=1):
        wstyle = winner_styles.get(r.winner, "white")
        table.add_row(
            str(idx),
            r.timestamp,
            r.variant_a.agent,
            r.goal[:50],
            r.verdict_a,
            r.verdict_b,
            f"[{wstyle}]{r.winner}[/{wstyle}]",
        )

    console.print(table)
