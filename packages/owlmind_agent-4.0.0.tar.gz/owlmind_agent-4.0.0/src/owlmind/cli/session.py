"""Session CLI subcommands — multi-goal session management."""

from __future__ import annotations

from pathlib import Path

import typer
from rich.table import Table

from owlmind import __version__

from ._helpers import (
    DEFAULT_LEDGER,
    DEFAULT_POLICIES,
    DEFAULT_RUNS,
    DEFAULT_SESSIONS,
    console,
    print_session_result,
    session_exit_code,
)

session_app = typer.Typer(
    name="session",
    help="Multi-goal session — chain goals from a YAML file",
    no_args_is_help=True,
)


@session_app.command("start")
def session_start(
    goals_file: Path = typer.Option(..., "--goals-file", "-f", help="Goals YAML file"),
    workspace: Path = typer.Option(Path("."), "--workspace", "-w", help="Base workspace"),
    policies_dir: Path = typer.Option(DEFAULT_POLICIES, "--policies", "-p"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
    sessions_dir: Path = typer.Option(DEFAULT_SESSIONS, "--sessions-dir"),
    ledger_dir: Path = typer.Option(DEFAULT_LEDGER, "--ledger-dir"),
    max_concurrency: int = typer.Option(1, "--max-concurrency", "-j", help="Max parallel goals"),
    continue_on_fail: bool = typer.Option(
        False, "--continue-on-fail", help="Continue past failed goals"
    ),
    stop_on_fail: bool = typer.Option(
        False, "--stop-on-fail", help="Stop on first goal failure (default)"
    ),
    scheduler: bool = typer.Option(
        False, "--scheduler", help="Distributed mode: create session for scheduler dispatch"
    ),
) -> None:
    """Start a new session from a goals file and run until blocked/done.

    With --scheduler, the session is created with RUNNING status but not
    executed locally. The distributed scheduler picks it up and dispatches
    goals to workers via the queue.
    """
    from owlmind.session import create_session

    if stop_on_fail:
        continue_on_fail = False

    console.print(f"[bold]OWLMIND v{__version__} — session start[/bold]\n")

    if not goals_file.exists():
        console.print(f"[red]Goals file not found: {goals_file}[/red]")
        raise typer.Exit(code=1)

    try:
        meta = create_session(
            goals_file=goals_file,
            workspace=str(workspace.resolve()),
            sessions_dir=sessions_dir,
            policies_dir=str(policies_dir),
            runs_dir=str(runs_dir),
            ledger_dir=str(ledger_dir),
            max_concurrency=max_concurrency,
            continue_on_fail=continue_on_fail,
        )
    except (ValueError, FileNotFoundError) as exc:
        console.print(f"[red]Error: {exc}[/red]")
        raise typer.Exit(code=1) from None

    console.print(f"  Session ID: [bold]{meta.session_id}[/bold]")
    console.print(f"  Goals:      {len(meta.goals)}")
    console.print(f"  Workspace:  {workspace.resolve()}")
    if scheduler:
        console.print("  Mode:       [cyan]distributed (scheduler)[/cyan]")
    console.print()

    for i, g in enumerate(meta.goals):
        deps = f" <- {', '.join(g.depends_on)}" if g.depends_on else ""
        console.print(f"  [{i}] {g.id}: {g.goal[:60]}{deps}")

    console.print()

    if scheduler:
        # Distributed mode: session is created with RUNNING status.
        # The scheduler will pick it up and dispatch goals to workers.
        console.print("[green]Session created for distributed execution.[/green]")
        console.print(f"  The scheduler will dispatch goals from session {meta.session_id}.")
        console.print()
        console.print("  Monitor progress:")
        console.print(f"    owlmind session status --session-id {meta.session_id}")
        console.print(f"    owlmind session logs --session-id {meta.session_id}")
        raise typer.Exit(code=0)

    # Local mode: run session directly
    from owlmind.session_runner import run_session

    result = run_session(
        meta.session_id,
        sessions_dir=sessions_dir,
        runs_dir=runs_dir,
        policies_dir=policies_dir,
        ledger_dir=ledger_dir,
        max_concurrency=max_concurrency,
        continue_on_fail=continue_on_fail,
    )

    print_session_result(result)
    raise typer.Exit(code=session_exit_code(result.status))


@session_app.command("resume")
def session_resume(
    session_id: str = typer.Option(..., "--session-id", help="Session ID"),
    sessions_dir: Path = typer.Option(DEFAULT_SESSIONS, "--sessions-dir"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
    policies_dir: Path = typer.Option(DEFAULT_POLICIES, "--policies", "-p"),
    ledger_dir: Path = typer.Option(DEFAULT_LEDGER, "--ledger-dir"),
    max_concurrency: int = typer.Option(
        0, "--max-concurrency", "-j", help="Override max parallel goals (0=use session setting)"
    ),
    continue_on_fail: bool = typer.Option(
        False, "--continue-on-fail", help="Override continue-on-fail"
    ),
) -> None:
    """Resume a session from the current goal index."""
    from owlmind.session_runner import run_session

    console.print(f"[bold]OWLMIND v{__version__} — session resume[/bold]\n")
    console.print(f"  Resuming: {session_id}\n")

    mc_override = max_concurrency if max_concurrency > 0 else None

    try:
        result = run_session(
            session_id,
            sessions_dir=sessions_dir,
            runs_dir=runs_dir,
            policies_dir=policies_dir,
            ledger_dir=ledger_dir,
            max_concurrency=mc_override,
            continue_on_fail=continue_on_fail if continue_on_fail else None,
        )
    except (FileNotFoundError, RuntimeError) as exc:
        console.print(f"[red]Error: {exc}[/red]")
        raise typer.Exit(code=1) from None

    print_session_result(result)
    raise typer.Exit(code=session_exit_code(result.status))


@session_app.command("status")
def session_status(
    session_id: str = typer.Option(..., "--session-id", help="Session ID"),
    sessions_dir: Path = typer.Option(DEFAULT_SESSIONS, "--sessions-dir"),
) -> None:
    """Show session status and goals table."""
    from owlmind.session import load_session

    console.print(f"[bold]OWLMIND v{__version__} — session status[/bold]\n")

    try:
        meta = load_session(session_id, sessions_dir)
    except FileNotFoundError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1) from None

    status_color = {
        "DONE": "green",
        "FAILED": "red",
        "BLOCKED": "yellow",
        "RUNNING": "blue",
        "STOPPED": "dim",
    }.get(meta.status, "white")

    console.print(f"  Session:  [bold]{meta.session_id}[/bold]")
    console.print(f"  Status:   [{status_color}]{meta.status}[/{status_color}]")
    console.print(f"  Created:  {meta.created_at}")
    console.print(f"  Goals:    {len(meta.goals)}")
    console.print(f"  Progress: {meta.current_goal_index}/{len(meta.goals)}")

    if meta.last_block_reason:
        console.print(f"  Blocked:  {meta.last_block_reason}")

    if meta.max_concurrency > 1:
        console.print(f"  Concurrency: {meta.max_concurrency}")
    if meta.continue_on_fail:
        console.print("  Continue on fail: yes")

    table = Table(title="Goals")
    table.add_column("#", justify="right")
    table.add_column("ID", style="bold")
    table.add_column("Goal")
    table.add_column("Deps")
    table.add_column("Run ID")
    table.add_column("Status")

    _status_colors = {
        "done": "green",
        "failed": "red",
        "blocked": "yellow",
        "running": "blue",
        "dispatched": "cyan",
        "skipped": "dim",
        "pending": "dim",
    }

    run_map = {r.goal_id: r for r in meta.runs}
    for i, g in enumerate(meta.goals):
        run = run_map.get(g.id)
        run_id = run.run_id[:20] if run else "-"
        goal_status = run.status if run else "pending"
        s_color = _status_colors.get(goal_status, "dim")
        deps = ", ".join(g.depends_on) if g.depends_on else "-"
        table.add_row(
            str(i),
            g.id,
            g.goal[:50],
            deps,
            run_id,
            f"[{s_color}]{goal_status}[/{s_color}]",
        )

    console.print()
    console.print(table)


@session_app.command("stop")
def session_stop(
    session_id: str = typer.Option(..., "--session-id", help="Session ID"),
    sessions_dir: Path = typer.Option(DEFAULT_SESSIONS, "--sessions-dir"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
) -> None:
    """Stop a running session."""
    from owlmind.session_runner import stop_session

    console.print(f"[bold]OWLMIND v{__version__} — session stop[/bold]\n")

    try:
        meta = stop_session(session_id, sessions_dir, runs_dir)
    except FileNotFoundError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1) from None

    console.print(f"[yellow]Session {session_id} stopped.[/yellow]")
    console.print(f"  Status: {meta.status}")
    console.print(f"  Resume: owlmind session resume --session-id {session_id}")


@session_app.command("export")
def session_export_cmd(
    session_id: str = typer.Option(..., "--session-id", help="Session ID"),
    out: Path = typer.Option(None, "--out", "-o", help="Output zip path"),
    sessions_dir: Path = typer.Option(DEFAULT_SESSIONS, "--sessions-dir"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
) -> None:
    """Export session as a zip bundle."""
    from owlmind.session_export import export_session

    console.print(f"[bold]OWLMIND v{__version__} — session export[/bold]\n")

    try:
        zip_path = export_session(
            session_id,
            sessions_dir=sessions_dir,
            runs_dir=runs_dir,
            out_path=out,
        )
    except FileNotFoundError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1) from None

    console.print(f"[green]Export created: {zip_path}[/green]")
    console.print(f"  Size: {zip_path.stat().st_size} bytes")


@session_app.command("render")
def session_render(
    session_id: str = typer.Option(..., "--session-id", help="Session ID"),
    sessions_dir: Path = typer.Option(DEFAULT_SESSIONS, "--sessions-dir"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
) -> None:
    """Rebuild protocol.md for a session."""
    from owlmind.session import render_protocol

    console.print(f"[bold]OWLMIND v{__version__} — session render[/bold]\n")

    try:
        content = render_protocol(session_id, sessions_dir, runs_dir)
    except FileNotFoundError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1) from None

    protocol_path = sessions_dir / session_id / "protocol.md"
    console.print(f"[green]Protocol written: {protocol_path}[/green]")
    console.print(f"\n{content[:500]}{'...' if len(content) > 500 else ''}")


@session_app.command("list")
def session_list(
    n: int = typer.Option(20, "--n", "-n", help="Number of sessions to show"),
    sessions_dir: Path = typer.Option(DEFAULT_SESSIONS, "--sessions-dir"),
) -> None:
    """List recent sessions (newest first)."""
    from owlmind.session import load_session

    console.print(f"[bold]OWLMIND v{__version__} — session list[/bold]\n")

    if not sessions_dir.exists():
        console.print("[dim]No sessions found.[/dim]")
        return

    session_dirs = sorted(
        [d for d in sessions_dir.iterdir() if d.is_dir() and (d / "session_meta.json").exists()],
        key=lambda d: d.stat().st_mtime,
        reverse=True,
    )[:n]

    if not session_dirs:
        console.print("[dim]No sessions found.[/dim]")
        return

    table = Table(title=f"Sessions (last {len(session_dirs)})")
    table.add_column("Session ID", style="bold")
    table.add_column("Status")
    table.add_column("Goals")
    table.add_column("Created")

    for d in session_dirs:
        sid = d.name
        try:
            meta = load_session(sid, sessions_dir)
            status_color = {
                "DONE": "green",
                "FAILED": "red",
                "BLOCKED": "yellow",
                "RUNNING": "blue",
                "STOPPED": "dim",
            }.get(meta.status, "white")
            table.add_row(
                sid,
                f"[{status_color}]{meta.status}[/{status_color}]",
                str(len(meta.goals)),
                meta.created_at[:19],
            )
        except Exception:
            table.add_row(sid, "[dim]?[/dim]", "?", "?")

    console.print(table)


@session_app.command("logs")
def session_logs(
    session_id: str = typer.Option(..., "--session-id", help="Session ID"),
    goal_id: str = typer.Option("", "--goal", "-g", help="Filter by goal ID"),
    last_n: int = typer.Option(50, "--last", "-n", help="Show last N events"),
    sessions_dir: Path = typer.Option(DEFAULT_SESSIONS, "--sessions-dir"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
) -> None:
    """Show session event logs, optionally filtered by goal.

    Displays events from the session log (session.jsonl). When --goal is
    specified, also shows run events for that goal's run_id.
    """
    import json as json_mod

    from owlmind.session import load_session, read_session_events

    console.print(f"[bold]OWLMIND v{__version__} — session logs[/bold]\n")

    try:
        meta = load_session(session_id, sessions_dir)
    except FileNotFoundError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1) from None

    events = read_session_events(session_id, sessions_dir)

    if goal_id:
        events = [
            e for e in events if e.get("goal_id") == goal_id or goal_id in str(e.get("event", ""))
        ]

    # Show last N events
    events = events[-last_n:]

    if not events:
        console.print("[dim]No events found.[/dim]")
    else:
        console.print(f"[bold]Session events ({len(events)}):[/bold]\n")
        for ev in events:
            ts = ev.get("timestamp", "")[:19]
            event_type = ev.get("event", ev.get("type", "?"))
            gid = ev.get("goal_id", "")

            # Color by event type
            color = "white"
            if "DONE" in str(event_type).upper():
                color = "green"
            elif "FAIL" in str(event_type).upper():
                color = "red"
            elif "BLOCK" in str(event_type).upper():
                color = "yellow"
            elif "DISPATCH" in str(event_type).upper():
                color = "cyan"

            gid_str = f" [{gid}]" if gid else ""
            detail_keys = {
                k: v for k, v in ev.items() if k not in ("timestamp", "event", "type", "goal_id")
            }
            detail_str = f"  {detail_keys}" if detail_keys else ""
            console.print(f"  {ts} [{color}]{event_type}[/{color}]{gid_str}{detail_str}")

    # If goal_id specified, also show run events
    if goal_id:
        run_info = next((r for r in meta.runs if r.goal_id == goal_id), None)
        if run_info and run_info.run_id:
            run_events_path = runs_dir / run_info.run_id / "run.jsonl"
            if run_events_path.exists():
                console.print(f"\n[bold]Run events for {goal_id} (run={run_info.run_id}):[/bold]\n")
                run_lines = run_events_path.read_text().splitlines()
                for line in run_lines[-last_n:]:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        rev = json_mod.loads(line)
                        ts = str(rev.get("timestamp", ""))[:19]
                        etype = rev.get("event", rev.get("type", "?"))
                        console.print(f"  {ts} {etype}")
                    except json_mod.JSONDecodeError:
                        console.print(f"  {line[:100]}")
            else:
                console.print(f"\n[dim]No run events found for {goal_id}.[/dim]")


@session_app.command("graph")
def session_graph(
    session_id: str = typer.Option(..., "--session-id", help="Session ID"),
    sessions_dir: Path = typer.Option(DEFAULT_SESSIONS, "--sessions-dir"),
) -> None:
    """Print DAG summary: layers, statuses, ready nodes."""
    from owlmind.dag import format_dag_summary
    from owlmind.session import load_session

    console.print(f"[bold]OWLMIND v{__version__} — session graph[/bold]\n")

    try:
        meta = load_session(session_id, sessions_dir)
    except FileNotFoundError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1) from None

    goal_dicts: list[dict[str, object]] = [
        {"id": g.id, "depends_on": g.depends_on, "goal": g.goal} for g in meta.goals
    ]
    run_map = {r.goal_id: r for r in meta.runs}
    statuses = {g.id: (run_map[g.id].status if g.id in run_map else "pending") for g in meta.goals}

    summary = format_dag_summary(goal_dicts, statuses)
    console.print(summary)


@session_app.command("dashboard")
def session_dashboard(
    session_id: str = typer.Option(..., "--session-id", help="Session ID"),
    sessions_dir: Path = typer.Option(DEFAULT_SESSIONS, "--sessions-dir"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
    out: Path = typer.Option(None, "--out", "-o", help="Output HTML file path"),
) -> None:
    """Generate a static HTML dashboard for a session."""
    from owlmind.session_dashboard import generate_session_dashboard

    console.print(f"[bold]OWLMIND v{__version__} — session dashboard[/bold]\n")

    if out is None:
        out = sessions_dir / session_id / "exports" / "dashboard.html"

    try:
        result = generate_session_dashboard(session_id, sessions_dir, runs_dir, out)
        console.print(f"[green]Dashboard written to: {result}[/green]")
    except FileNotFoundError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1) from None


@session_app.command("run-dashboard")
def run_dashboard(
    run_id: str = typer.Option(..., "--run-id", help="Run ID"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
    out: Path = typer.Option(None, "--out", "-o", help="Output HTML file path"),
) -> None:
    """Generate a static HTML dashboard for a single run."""
    from owlmind.run_dashboard import generate_run_dashboard

    console.print(f"[bold]OWLMIND v{__version__} — run dashboard[/bold]\n")

    if out is None:
        out = runs_dir / run_id / "dashboard.html"

    try:
        result = generate_run_dashboard(run_id, runs_dir, out)
        console.print(f"[green]Dashboard written to: {result}[/green]")
    except FileNotFoundError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1) from None


@session_app.command("rollback")
def session_rollback(
    session_id: str = typer.Option(..., "--session-id", help="Session ID"),
    goal_id: str = typer.Option(..., "--goal-id", "-g", help="Goal to rollback"),
    sessions_dir: Path = typer.Option(DEFAULT_SESSIONS, "--sessions-dir"),
    runs_dir: Path = typer.Option(DEFAULT_RUNS, "--runs", "-r"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip approval prompt"),
) -> None:
    """Rollback a failed goal using its configured rollback policy."""
    from owlmind.rollback import (
        create_rollback_request,
        execute_rollback,
        log_rollback_event,
    )
    from owlmind.session import load_session

    console.print(f"[bold]OWLMIND v{__version__} — session rollback[/bold]\n")

    try:
        meta = load_session(session_id, sessions_dir)
    except FileNotFoundError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1) from None

    goal = next((g for g in meta.goals if g.id == goal_id), None)
    if goal is None:
        console.print(f"[red]Goal {goal_id} not found in session[/red]")
        raise typer.Exit(code=1)

    run = next((r for r in meta.runs if r.goal_id == goal_id), None)
    run_id = run.run_id if run else f"unknown-{goal_id}"

    if goal.rollback.mode == "none":
        console.print(f"[yellow]Goal {goal_id} has rollback mode 'none' — nothing to do[/yellow]")
        raise typer.Exit(code=0)

    request = create_rollback_request(
        goal_id=goal_id,
        run_id=run_id,
        mode=goal.rollback.mode,
        require_approval=goal.rollback.require_approval and not yes,
        runs_dir=runs_dir,
    )

    log_rollback_event(
        session_id,
        sessions_dir,
        "GOAL_ROLLBACK_REQUESTED",
        {
            "goal_id": goal_id,
            "run_id": run_id,
            "mode": goal.rollback.mode,
        },
    )

    if request.require_approval and not request.approved:
        console.print("[yellow]Rollback requires approval.[/yellow]")
        console.print(f"  Token: {request.approval_token}")
        console.print(f"  Instructions: {request.instructions}")
        console.print("\nRe-run with --yes to execute, or approve manually.")
        raise typer.Exit(code=2)

    result = execute_rollback(request, runs_dir)

    log_rollback_event(
        session_id,
        sessions_dir,
        "GOAL_ROLLBACK_EXECUTED",
        {
            "goal_id": goal_id,
            "run_id": run_id,
            **result,
        },
    )

    console.print("[green]Rollback executed:[/green]")
    for k, v in result.items():
        console.print(f"  {k}: {v}")
