"""Entry point for python -m owlmind."""

from owlmind.cli import app

app()
