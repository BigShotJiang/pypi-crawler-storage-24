"""Pydantic data contracts for OWLMIND orchestration."""

from __future__ import annotations

import enum
from datetime import UTC, datetime
from typing import Any

from pydantic import BaseModel, Field, field_validator

# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class RiskLevel(enum.StrEnum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class ActionType(enum.StrEnum):
    RUN_COMMAND = "RUN_COMMAND"
    EDIT_FILE = "EDIT_FILE"
    CREATE_FILE = "CREATE_FILE"
    DELETE_FILE = "DELETE_FILE"
    GIT_COMMIT = "GIT_COMMIT"
    GIT_PUSH = "GIT_PUSH"


class Verdict(enum.StrEnum):
    APPROVED = "APPROVED"
    NEEDS_FIX = "NEEDS_FIX"
    REJECTED = "REJECTED"


class OrchestratorState(enum.StrEnum):
    INTAKE = "INTAKE"
    PLAN = "PLAN"
    EXECUTE = "EXECUTE"
    VERIFY = "VERIFY"
    REVIEW = "REVIEW"
    DONE = "DONE"
    FAILED = "FAILED"


# ---------------------------------------------------------------------------
# Action
# ---------------------------------------------------------------------------


class Action(BaseModel):
    """A single action the Worker wants to execute."""

    action_id: str
    type: ActionType
    payload: dict[str, Any] = Field(default_factory=dict)
    risk_level: RiskLevel = RiskLevel.LOW

    @field_validator("payload")
    @classmethod
    def cmd_must_be_single_line(cls, v: dict[str, Any]) -> dict[str, Any]:
        cmd = v.get("cmd")
        if cmd and "\n" in cmd:
            msg = "Command must be a single line"
            raise ValueError(msg)
        return v


# ---------------------------------------------------------------------------
# TaskSpec  (Planner -> Worker)
# ---------------------------------------------------------------------------


class PlanStep(BaseModel):
    id: str
    action: str
    checkpoint: bool = False


class TaskPlan(BaseModel):
    steps: list[PlanStep] = Field(default_factory=list)
    estimated_duration_minutes: int = 15
    risk_level: RiskLevel = RiskLevel.MEDIUM


class TaskSpec(BaseModel):
    """Contract: Planner -> Worker."""

    task_id: str
    goal: str
    definition_of_done: list[str] = Field(default_factory=list)
    allowed_commands: list[str] = Field(default_factory=list)
    plan: TaskPlan = Field(default_factory=TaskPlan)
    actions: list[Action] = Field(default_factory=list)
    constraints: dict[str, Any] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# ReportSpec  (Worker -> Judge)
# ---------------------------------------------------------------------------


class CommandRun(BaseModel):
    """Record of a single command execution."""

    cmd: str
    exit_code: int
    duration_s: float = 0.0
    summary: str = ""
    stdout_hash: str = ""
    stderr_hash: str = ""


class DiffSummary(BaseModel):
    files_changed: int = 0
    insertions: int = 0
    deletions: int = 0
    notes: str = ""


class ReportSpec(BaseModel):
    """Contract: Worker -> Judge."""

    task_id: str
    status: str = "READY_FOR_REVIEW"
    steps_completed: list[str] = Field(default_factory=list)
    steps_failed: list[str] = Field(default_factory=list)
    commands_run: list[CommandRun] = Field(default_factory=list)
    diff_summary: DiffSummary = Field(default_factory=DiffSummary)
    blockers: list[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Evidence
# ---------------------------------------------------------------------------


class EvidenceArtifact(BaseModel):
    """A single piece of evidence stored on disk."""

    filename: str
    sha256: str
    size_bytes: int = 0


# ---------------------------------------------------------------------------
# RunSummary
# ---------------------------------------------------------------------------


class RunSummary(BaseModel):
    """Metadata for a completed orchestrator run."""

    task_id: str
    state: OrchestratorState
    started_at: datetime = Field(default_factory=lambda: datetime.now(tz=UTC))
    finished_at: datetime | None = None
    actions_executed: int = 0
    actions_failed: int = 0
    evidence_artifacts: list[EvidenceArtifact] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# JudgeVerdict
# ---------------------------------------------------------------------------


class CheckItem(BaseModel):
    name: str
    passed: bool
    evidence: str = ""


class CheckCategory(BaseModel):
    passed: bool
    blocking: bool = False
    checks: list[CheckItem] = Field(default_factory=list)


class JudgeVerdict(BaseModel):
    """Contract: Judge -> Engine."""

    task_id: str
    verdict: Verdict
    score: int = Field(ge=1, le=10)
    confidence: float = Field(ge=0.0, le=1.0)
    checklist: dict[str, CheckCategory] = Field(default_factory=dict)
    blocking_rules_triggered: list[str] = Field(default_factory=list)
    feedback: dict[str, Any] = Field(default_factory=dict)
    evidence_chain_verified: bool = False
    decision: str = "COMMIT"
