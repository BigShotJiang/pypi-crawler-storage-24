"""Orchestrator — state machine that drives task execution."""

from __future__ import annotations

import json
import uuid
from datetime import UTC, datetime
from pathlib import Path

from owlmind.contracts import (
    ActionType,
    CommandRun,
    OrchestratorState,
    ReportSpec,
    RunSummary,
    TaskSpec,
)
from owlmind.evidence import EvidenceStore
from owlmind.policy import PolicyDecision, PolicyEngine
from owlmind.tools.shell import ShellTool
from owlmind.utils import ToolLimits

# State transitions
_TRANSITIONS: dict[OrchestratorState, list[OrchestratorState]] = {
    OrchestratorState.INTAKE: [OrchestratorState.PLAN],
    OrchestratorState.PLAN: [OrchestratorState.EXECUTE],
    OrchestratorState.EXECUTE: [OrchestratorState.VERIFY, OrchestratorState.FAILED],
    OrchestratorState.VERIFY: [OrchestratorState.DONE, OrchestratorState.FAILED],
    OrchestratorState.REVIEW: [OrchestratorState.DONE, OrchestratorState.FAILED],
    OrchestratorState.DONE: [],
    OrchestratorState.FAILED: [],
}


class Orchestrator:
    """Drives a task through the state machine: INTAKE -> PLAN -> EXECUTE -> VERIFY -> DONE."""

    def __init__(
        self,
        policy: PolicyEngine,
        evidence: EvidenceStore,
        *,
        project_dir: str | Path | None = None,
        limits: ToolLimits | None = None,
    ) -> None:
        self.policy = policy
        self.evidence = evidence
        self.project_dir = str(project_dir) if project_dir else None
        self.limits = limits or ToolLimits()
        self.state = OrchestratorState.INTAKE
        self.run_id: str = ""

    # ------------------------------------------------------------------
    # State machine
    # ------------------------------------------------------------------

    def _transition(self, new_state: OrchestratorState) -> None:
        allowed = _TRANSITIONS.get(self.state, [])
        if new_state not in allowed:
            msg = f"Invalid transition: {self.state.value} -> {new_state.value}"
            raise RuntimeError(msg)
        self.evidence.append_event(
            self.run_id,
            {
                "event": "state_transition",
                "from": self.state.value,
                "to": new_state.value,
            },
        )
        self.state = new_state

    # ------------------------------------------------------------------
    # Run
    # ------------------------------------------------------------------

    def run(self, task: TaskSpec) -> RunSummary:
        """Execute a task end-to-end and return a summary."""
        self.run_id = f"run-{uuid.uuid4().hex[:12]}"
        self.evidence.create_run(self.run_id)
        started_at = datetime.now(tz=UTC)

        # Persist task metadata
        self.evidence.write_meta(
            self.run_id,
            {
                "task_id": task.task_id,
                "goal": task.goal,
                "run_id": self.run_id,
                "started_at": started_at.isoformat(),
            },
        )

        # INTAKE -> PLAN
        self._transition(OrchestratorState.PLAN)
        self.evidence.append_event(
            self.run_id,
            {
                "event": "plan_loaded",
                "task_id": task.task_id,
                "num_actions": len(task.actions),
            },
        )

        # PLAN -> EXECUTE
        self._transition(OrchestratorState.EXECUTE)
        shell = ShellTool(policy=self.policy, limits=self.limits, cwd=self.project_dir)

        commands_run: list[CommandRun] = []
        actions_failed = 0

        for action in task.actions:
            self.evidence.append_event(
                self.run_id,
                {
                    "event": "action_start",
                    "action_id": action.action_id,
                    "type": action.type.value,
                    "payload": action.payload,
                },
            )

            if action.type == ActionType.RUN_COMMAND:
                cmd = action.payload.get("cmd", "")
                result = shell.run(cmd)

                cmd_run = CommandRun(
                    cmd=cmd,
                    exit_code=result.exit_code,
                    duration_s=result.duration_ms / 1000.0,
                    summary=result.stdout[:200] if result.exit_code == 0 else result.stderr[:200],
                    stdout_hash=result.stdout_hash,
                    stderr_hash=result.stderr_hash,
                )
                commands_run.append(cmd_run)

                # Store evidence artefact
                self.evidence.write_artifact(
                    self.run_id,
                    f"{action.action_id}_stdout.txt",
                    result.stdout,
                )
                self.evidence.write_artifact(
                    self.run_id,
                    f"{action.action_id}_stderr.txt",
                    result.stderr,
                )

                is_denied = result.policy_result is not None and result.policy_result.decision in (
                    PolicyDecision.DENY,
                    PolicyDecision.BLOCK,
                )

                self.evidence.append_event(
                    self.run_id,
                    {
                        "event": "action_done",
                        "action_id": action.action_id,
                        "exit_code": result.exit_code,
                        "duration_ms": result.duration_ms,
                        "policy_denied": is_denied,
                    },
                )

                if result.exit_code != 0:
                    actions_failed += 1
            else:
                self.evidence.append_event(
                    self.run_id,
                    {
                        "event": "action_skipped",
                        "action_id": action.action_id,
                        "reason": f"Action type {action.type.value} not yet implemented",
                    },
                )

        # EXECUTE -> VERIFY / FAILED
        if actions_failed > 0:
            self._transition(OrchestratorState.FAILED)
        else:
            self._transition(OrchestratorState.VERIFY)
            # Simple verify: all commands passed
            self._transition(OrchestratorState.DONE)

        finished_at = datetime.now(tz=UTC)

        # Build report
        report = ReportSpec(
            task_id=task.task_id,
            status="DONE" if self.state == OrchestratorState.DONE else "FAILED",
            steps_completed=[a.action_id for a in task.actions],
            commands_run=commands_run,
        )

        summary = RunSummary(
            task_id=task.task_id,
            state=self.state,
            started_at=started_at,
            finished_at=finished_at,
            actions_executed=len(task.actions),
            actions_failed=actions_failed,
        )

        # Persist
        self.evidence.write_summary(
            self.run_id,
            {
                "report": json.loads(report.model_dump_json()),
                "summary": json.loads(summary.model_dump_json()),
            },
        )

        return summary
