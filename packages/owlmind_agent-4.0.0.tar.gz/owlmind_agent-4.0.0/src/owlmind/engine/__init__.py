"""OWLMIND engine — orchestrator and state machine."""
