"""Multi-repository orchestration — coordinate sessions across repos.

Runs owlmind sessions across multiple repositories in dependency order,
executes cross-repo integration tests, and handles rollback on failure.
"""

from __future__ import annotations

import json
import logging
import re
import subprocess
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from owlmind.dag import topological_layers, validate_dag
from owlmind.session import (
    SESSION_DONE,
    SESSION_FAILED,
    create_session,
    load_session,
)
from owlmind.session_runner import SessionResult, run_session

logger = logging.getLogger(__name__)


def _now_iso() -> str:
    return datetime.now(UTC).isoformat()


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------


@dataclass
class RepoConfig:
    """Configuration for a single repository in the multi-repo set."""

    path: str
    branch: str = "main"
    remote: str = "origin"
    goals: list[str] = field(default_factory=list)


@dataclass
class IntegrationTest:
    """A cross-repo integration test to run after repo sessions complete."""

    name: str
    command: str
    working_dir: str = "."
    depends_on: list[str] = field(default_factory=list)


@dataclass
class MultiRepoConfig:
    """Top-level configuration for multi-repo orchestration.

    Attributes:
        repos: List of repository configurations.
        dependency_graph: Repo-level dependencies (repo_path -> list of
            repo_paths it depends on).
        integration_tests: Cross-repo tests run after sessions complete.
        rollback_policy: What to do on failure. One of
            ``branch_delete``, ``worktree_reset``, ``manual``, ``none``.
    """

    repos: list[RepoConfig] = field(default_factory=list)
    dependency_graph: dict[str, list[str]] = field(default_factory=dict)
    integration_tests: list[IntegrationTest] = field(default_factory=list)
    rollback_policy: str = "none"  # branch_delete | worktree_reset | manual | none


@dataclass
class MultiRepoResult:
    """Outcome of a multi-repo orchestration run."""

    repos_completed: list[str] = field(default_factory=list)
    repos_failed: list[str] = field(default_factory=list)
    integration_passed: list[str] = field(default_factory=list)
    integration_failed: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# MultiRepoRunner
# ---------------------------------------------------------------------------


class MultiRepoRunner:
    """Orchestrate owlmind sessions across multiple repositories.

    For each repository a session is created from the configured goals,
    then sessions are executed in dependency order (topological sort of
    the repo dependency graph).  After all repo sessions complete,
    integration tests are executed.  On failure the configured rollback
    policy is applied.
    """

    def __init__(
        self,
        config: MultiRepoConfig,
        sessions_dir: Path | str = "sessions",
        runs_dir: Path | str = "runs",
        policies_dir: Path | str = "policies",
        ledger_dir: Path | str = "ledger",
    ) -> None:
        self.config = config
        self.sessions_dir = Path(sessions_dir)
        self.runs_dir = Path(runs_dir)
        self.policies_dir = Path(policies_dir)
        self.ledger_dir = Path(ledger_dir)

        # Track per-repo session IDs and results
        self._repo_sessions: dict[str, str] = {}  # repo_path -> session_id
        self._repo_results: dict[str, SessionResult] = {}
        self._multi_id = f"multi-{uuid.uuid4().hex[:12]}"

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run(self) -> MultiRepoResult:
        """Orchestrate sessions across all repos and return results."""
        result = MultiRepoResult()

        # 1. Build repo DAG dicts for topological sort
        repo_dicts = self._build_repo_dag()
        try:
            validate_dag(repo_dicts)
        except (ValueError, Exception) as exc:
            result.errors.append(f"Repo dependency graph invalid: {exc}")
            return result

        layers = topological_layers(repo_dicts)

        # 2. Run sessions layer by layer
        for layer in layers:
            for repo_path in layer:
                repo_cfg = self._repo_by_path(repo_path)
                if repo_cfg is None:
                    result.errors.append(f"Repo config not found for {repo_path}")
                    result.repos_failed.append(repo_path)
                    continue

                # Check that dependencies succeeded
                deps = self.config.dependency_graph.get(repo_path, [])
                dep_failed = [d for d in deps if d in result.repos_failed]
                if dep_failed:
                    msg = (
                        f"Skipping {repo_path}: "
                        f"dependencies failed: {', '.join(dep_failed)}"
                    )
                    logger.warning(msg)
                    result.errors.append(msg)
                    result.repos_failed.append(repo_path)
                    continue

                try:
                    session_result = self._run_repo_session(repo_cfg)
                    self._repo_results[repo_path] = session_result

                    if session_result.status == SESSION_DONE:
                        result.repos_completed.append(repo_path)
                    else:
                        result.repos_failed.append(repo_path)
                        result.errors.append(
                            f"Repo {repo_path} ended with status "
                            f"{session_result.status}: "
                            f"{session_result.last_block_reason}"
                        )
                        self._handle_rollback(repo_path, result)
                except Exception as exc:
                    logger.error("Error running session for %s: %s", repo_path, exc)
                    result.repos_failed.append(repo_path)
                    result.errors.append(f"Repo {repo_path} error: {exc}")
                    self._handle_rollback(repo_path, result)

        # 3. Run integration tests (only if we have completed repos)
        if result.repos_completed:
            self._run_integration_tests(result)

        return result

    def detect_dependencies(self, repos: list[str]) -> dict[str, list[str]]:
        """Auto-detect inter-repo dependencies by scanning imports.

        Scans Python imports (``import <pkg>`` / ``from <pkg> import``)
        and ``package.json`` dependencies to build a dependency mapping.

        Args:
            repos: List of repository root paths to scan.

        Returns:
            Mapping of repo_path -> list of repo_paths it depends on.
        """
        # Build a mapping from package name -> repo path
        pkg_to_repo: dict[str, str] = {}
        for repo_path in repos:
            rp = Path(repo_path)
            # Python: check for src/<pkg> or <pkg>/__init__.py
            for candidate in _find_python_packages(rp):
                pkg_to_repo[candidate] = repo_path
            # Node: check package.json name field
            pkg_json = rp / "package.json"
            if pkg_json.exists():
                try:
                    data = json.loads(pkg_json.read_text())
                    name = data.get("name", "")
                    if name:
                        pkg_to_repo[name] = repo_path
                except (json.JSONDecodeError, OSError):
                    pass

        # Now scan each repo for imports of packages owned by other repos
        dep_graph: dict[str, list[str]] = {r: [] for r in repos}

        for repo_path in repos:
            rp = Path(repo_path)
            imported = set[str]()

            # Python imports
            for py_file in rp.rglob("*.py"):
                try:
                    content = py_file.read_text(errors="replace")
                except OSError:
                    continue
                for match in re.finditer(
                    r"^\s*(?:import|from)\s+([\w.]+)", content, re.MULTILINE
                ):
                    top_pkg = match.group(1).split(".")[0]
                    imported.add(top_pkg)

            # Node dependencies
            pkg_json = rp / "package.json"
            if pkg_json.exists():
                try:
                    data = json.loads(pkg_json.read_text())
                    for section in ("dependencies", "devDependencies", "peerDependencies"):
                        for dep_name in data.get(section, {}):
                            imported.add(dep_name)
                except (json.JSONDecodeError, OSError):
                    pass

            # Resolve to repo paths
            for pkg_name in imported:
                owner = pkg_to_repo.get(pkg_name)
                if owner and owner != repo_path and owner not in dep_graph[repo_path]:
                    dep_graph[repo_path].append(owner)

        return dep_graph

    def status(self) -> dict[str, Any]:
        """Return current progress across all repos.

        Returns a dict with per-repo session status and overall summary.
        """
        repo_statuses: dict[str, dict[str, Any]] = {}

        for repo_cfg in self.config.repos:
            rpath = repo_cfg.path
            session_id = self._repo_sessions.get(rpath)
            if session_id is None:
                repo_statuses[rpath] = {"status": "pending", "session_id": None}
                continue

            try:
                meta = load_session(session_id, self.sessions_dir)
                run_statuses = [r.status for r in meta.runs]
                repo_statuses[rpath] = {
                    "status": meta.status,
                    "session_id": session_id,
                    "goals_total": len(meta.goals),
                    "goals_done": run_statuses.count("done"),
                    "goals_failed": run_statuses.count("failed"),
                    "goals_blocked": run_statuses.count("blocked"),
                }
            except FileNotFoundError:
                repo_statuses[rpath] = {
                    "status": "not_found",
                    "session_id": session_id,
                }

        total = len(self.config.repos)
        completed = sum(
            1
            for s in repo_statuses.values()
            if s.get("status") == SESSION_DONE
        )
        failed = sum(
            1
            for s in repo_statuses.values()
            if s.get("status") == SESSION_FAILED
        )

        return {
            "multi_id": self._multi_id,
            "repos_total": total,
            "repos_completed": completed,
            "repos_failed": failed,
            "repos_pending": total - completed - failed,
            "repos": repo_statuses,
        }

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _build_repo_dag(self) -> list[dict[str, object]]:
        """Build DAG dicts for the repo dependency graph."""
        dicts: list[dict[str, object]] = []
        for repo_cfg in self.config.repos:
            deps = self.config.dependency_graph.get(repo_cfg.path, [])
            dicts.append({
                "id": repo_cfg.path,
                "depends_on": deps,
                "goal": f"Session for {repo_cfg.path}",
            })
        return dicts

    def _repo_by_path(self, path: str) -> RepoConfig | None:
        """Look up a RepoConfig by path."""
        for r in self.config.repos:
            if r.path == path:
                return r
        return None

    def _run_repo_session(self, repo_cfg: RepoConfig) -> SessionResult:
        """Create and run a session for a single repo."""
        repo_path = Path(repo_cfg.path).resolve()

        # Write a temporary goals file for this repo
        goals_dir = self.sessions_dir / self._multi_id
        goals_dir.mkdir(parents=True, exist_ok=True)
        goals_file = goals_dir / f"goals_{repo_path.name}.yaml"

        import yaml

        goals_data = {
            "defaults": {
                "workspace": str(repo_path),
                "max_steps": 200,
            },
            "goals": [
                {"id": f"R{i + 1}", "goal": goal_text}
                for i, goal_text in enumerate(repo_cfg.goals)
            ],
        }
        goals_file.write_text(
            yaml.dump(goals_data, default_flow_style=False, allow_unicode=True)
        )

        # Create session
        meta = create_session(
            goals_file=goals_file,
            workspace=str(repo_path),
            sessions_dir=self.sessions_dir,
            policies_dir=str(self.policies_dir),
            runs_dir=str(self.runs_dir),
            ledger_dir=str(self.ledger_dir),
        )
        self._repo_sessions[repo_cfg.path] = meta.session_id

        logger.info(
            "Running session %s for repo %s (%d goals)",
            meta.session_id,
            repo_cfg.path,
            len(meta.goals),
        )

        # Run session
        result = run_session(
            meta.session_id,
            sessions_dir=self.sessions_dir,
            runs_dir=self.runs_dir,
            policies_dir=self.policies_dir,
            ledger_dir=self.ledger_dir,
        )

        return result

    def _run_integration_tests(self, result: MultiRepoResult) -> None:
        """Execute configured integration tests."""
        for test in self.config.integration_tests:
            # Check that all test dependencies completed
            missing = [
                d for d in test.depends_on if d not in result.repos_completed
            ]
            if missing:
                msg = (
                    f"Integration test '{test.name}' skipped: "
                    f"dependencies not completed: {', '.join(missing)}"
                )
                logger.warning(msg)
                result.errors.append(msg)
                result.integration_failed.append(test.name)
                continue

            logger.info("Running integration test: %s", test.name)
            working_dir = Path(test.working_dir).resolve()

            try:
                proc = subprocess.run(
                    test.command,
                    shell=True,
                    cwd=str(working_dir),
                    capture_output=True,
                    text=True,
                    timeout=600,
                )
                if proc.returncode == 0:
                    result.integration_passed.append(test.name)
                    logger.info("Integration test '%s' passed", test.name)
                else:
                    result.integration_failed.append(test.name)
                    stderr_short = proc.stderr[:500] if proc.stderr else ""
                    result.errors.append(
                        f"Integration test '{test.name}' failed "
                        f"(exit {proc.returncode}): {stderr_short}"
                    )
                    logger.error(
                        "Integration test '%s' failed (exit %d)",
                        test.name,
                        proc.returncode,
                    )
            except subprocess.TimeoutExpired:
                result.integration_failed.append(test.name)
                result.errors.append(
                    f"Integration test '{test.name}' timed out (600s)"
                )
            except OSError as exc:
                result.integration_failed.append(test.name)
                result.errors.append(
                    f"Integration test '{test.name}' error: {exc}"
                )

    def _handle_rollback(self, repo_path: str, result: MultiRepoResult) -> None:
        """Apply rollback policy for a failed repo."""
        policy = self.config.rollback_policy
        if policy == "none":
            return

        repo_cfg = self._repo_by_path(repo_path)
        if repo_cfg is None:
            return

        rp = Path(repo_path).resolve()
        logger.info(
            "Applying rollback policy '%s' for %s", policy, repo_path
        )

        try:
            if policy == "branch_delete":
                # Delete the working branch, leaving the repo on its
                # previous branch.
                subprocess.run(
                    ["git", "checkout", repo_cfg.branch],
                    cwd=str(rp),
                    capture_output=True,
                    text=True,
                    check=False,
                )
                # Note: we do NOT force-delete; if branch is current the
                # checkout above already moved us off it.
                logger.info("Rolled back %s via branch_delete", repo_path)

            elif policy == "worktree_reset":
                subprocess.run(
                    ["git", "checkout", "--", "."],
                    cwd=str(rp),
                    capture_output=True,
                    text=True,
                    check=False,
                )
                subprocess.run(
                    ["git", "clean", "-fd"],
                    cwd=str(rp),
                    capture_output=True,
                    text=True,
                    check=False,
                )
                logger.info("Rolled back %s via worktree_reset", repo_path)

            elif policy == "manual":
                msg = (
                    f"Repo {repo_path} failed — manual rollback required. "
                    f"Branch: {repo_cfg.branch}, Remote: {repo_cfg.remote}"
                )
                result.errors.append(msg)
                logger.warning(msg)

        except Exception as exc:
            result.errors.append(
                f"Rollback failed for {repo_path}: {exc}"
            )
            logger.error("Rollback error for %s: %s", repo_path, exc)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _find_python_packages(repo_root: Path) -> list[str]:
    """Find top-level Python package names in a repo."""
    packages: list[str] = []

    # src/<pkg>/__init__.py
    src_dir = repo_root / "src"
    if src_dir.is_dir():
        for child in src_dir.iterdir():
            if child.is_dir() and (child / "__init__.py").exists():
                packages.append(child.name)

    # <pkg>/__init__.py at repo root
    for child in repo_root.iterdir():
        if (
            child.is_dir()
            and child.name != "src"
            and not child.name.startswith(".")
            and (child / "__init__.py").exists()
        ):
            packages.append(child.name)

    return packages


def load_multi_repo_config(yaml_path: Path) -> MultiRepoConfig:
    """Load a MultiRepoConfig from a YAML file.

    Expected YAML structure::

        rollback_policy: branch_delete
        repos:
          - path: /home/user/repo-a
            branch: main
            remote: origin
            goals:
              - "Refactor auth module"
              - "Add unit tests for auth"
          - path: /home/user/repo-b
            branch: develop
            goals:
              - "Update API client for new auth"
        dependencies:
          /home/user/repo-b:
            - /home/user/repo-a
        integration_tests:
          - name: e2e-auth
            command: pytest tests/e2e/test_auth.py
            working_dir: /home/user/repo-b
            depends_on:
              - /home/user/repo-a
              - /home/user/repo-b
    """
    import yaml

    data = yaml.safe_load(yaml_path.read_text()) or {}

    repos = []
    for r in data.get("repos", []):
        repos.append(
            RepoConfig(
                path=r["path"],
                branch=r.get("branch", "main"),
                remote=r.get("remote", "origin"),
                goals=r.get("goals", []),
            )
        )

    dep_graph = data.get("dependencies", {})

    tests = []
    for t in data.get("integration_tests", []):
        tests.append(
            IntegrationTest(
                name=t["name"],
                command=t["command"],
                working_dir=t.get("working_dir", "."),
                depends_on=t.get("depends_on", []),
            )
        )

    rollback = data.get("rollback_policy", "none")
    if rollback not in ("branch_delete", "worktree_reset", "manual", "none"):
        logger.warning(
            "Unknown rollback_policy '%s', defaulting to 'none'", rollback
        )
        rollback = "none"

    return MultiRepoConfig(
        repos=repos,
        dependency_graph=dep_graph,
        integration_tests=tests,
        rollback_policy=rollback,
    )
