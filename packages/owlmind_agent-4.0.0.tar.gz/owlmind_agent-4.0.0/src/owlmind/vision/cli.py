"""CLI commands for the Vision / Computer Use module."""

from __future__ import annotations

import base64
from pathlib import Path
from typing import TYPE_CHECKING, Annotated

if TYPE_CHECKING:
    from owlmind.vision.models import VisionStep
    from owlmind.vision.providers import VisionProvider

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

vision_app = typer.Typer(
    name="vision",
    help="Vision & Computer Use — see screen, control mouse/keyboard, automate apps",
    no_args_is_help=True,
)
console = Console()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _load_env() -> None:
    try:
        from dotenv import load_dotenv  # type: ignore[import-untyped]

        env_file = Path(__file__).parent.parent.parent.parent / ".env"
        if env_file.exists():
            load_dotenv(env_file, override=False)
    except ImportError:
        pass


def _get_provider() -> VisionProvider:
    _load_env()
    from owlmind.vision.providers import build_vision_provider

    p = build_vision_provider()
    if p is None:
        console.print(
            "[red]No vision provider available.[/red]\n"
            "Set one of these in [cyan]~/owlmind/.env[/cyan]:\n"
            "  [yellow]ANTHROPIC_API_KEY[/yellow] — Claude (best)\n"
            "  [yellow]QWEN_API_KEY[/yellow]       — Qwen-VL-Max (cheap)\n"
            "  [yellow]OPENAI_API_KEY[/yellow]     — GPT-4o (if not DeepSeek)"
        )
        raise typer.Exit(1) from None
    return p


def _get_smart_agent(freeform: bool = False) -> None:
    _load_env()
    from owlmind.vision.smart_driver import build_agent

    return build_agent()


# ---------------------------------------------------------------------------
# providers — list all configured vision providers
# ---------------------------------------------------------------------------


@vision_app.command("providers")
def cmd_providers() -> None:
    """List all configured vision providers and their status."""
    _load_env()
    from owlmind.vision.providers import list_providers

    rows = list_providers()

    table = Table(title="Vision Providers", show_header=True, header_style="bold cyan")
    table.add_column("Provider", style="bold")
    table.add_column("Model")
    table.add_column("Status")
    table.add_column("Features")
    table.add_column("Cost / MTok")

    for r in rows:
        status = r["status"]
        if status == "available":
            status_str = "[green]✓ available[/green]"
        elif "no key" in status:
            status_str = f"[yellow]{status}[/yellow]"
        else:
            status_str = f"[dim]{status}[/dim]"
        table.add_row(
            r["provider"],
            r["model"],
            status_str,
            r["features"],
            r["cost"],
        )

    console.print(table)
    console.print(
        "\n[dim]Configure providers in [cyan]~/owlmind/.env[/cyan][/dim]"
    )


# ---------------------------------------------------------------------------
# screenshot — capture and save
# ---------------------------------------------------------------------------


@vision_app.command("screenshot")
def cmd_screenshot(
    output: Annotated[str, typer.Option("--output", "-o")] = "screenshot.png",
    show: Annotated[bool, typer.Option("--show", help="Open in Preview after saving")] = False,
) -> None:
    """Capture a screenshot of the current screen."""
    from owlmind.vision.screenshot import capture_screenshot, is_screenshot_available

    if not is_screenshot_available():
        console.print(
            "[red]Screenshot requires Pillow or pyautogui.[/red]\n"
            "Install: [cyan]pip install 'owlmind[vision]'[/cyan]"
        )
        raise typer.Exit(1) from None

    console.print("Capturing screenshot...")
    result = capture_screenshot()
    img_bytes = base64.standard_b64decode(result.base64_image)
    Path(output).write_bytes(img_bytes)
    console.print(
        f"[green]✓ Saved[/green] {output} ({result.width}×{result.height})"
    )

    if show:
        import subprocess

        subprocess.run(["open", output], check=False)


# ---------------------------------------------------------------------------
# analyze — describe an image with vision model
# ---------------------------------------------------------------------------


@vision_app.command("analyze")
def cmd_analyze(
    image_path: Annotated[str, typer.Argument(help="Path to image file")],
    question: Annotated[str, typer.Option("--question", "-q")] = (
        "Describe what you see in detail. What applications are open? "
        "What text is visible? What should I click to accomplish a task?"
    ),
) -> None:
    """Analyze an image with the best available vision model."""
    if not Path(image_path).exists():
        console.print(f"[red]File not found: {image_path}[/red]")
        raise typer.Exit(1) from None

    provider = _get_provider()
    console.print(
        f"Analyzing [cyan]{image_path}[/cyan] with [bold]{provider.name}[/bold]..."
    )

    from owlmind.vision.screenshot import encode_image_file

    screenshot = encode_image_file(image_path)
    answer = provider.analyze(screenshot, question)
    console.print(Panel(answer, title=f"[bold]{provider.name}[/bold]", border_style="cyan"))


# ---------------------------------------------------------------------------
# run — smart computer agent
# ---------------------------------------------------------------------------


@vision_app.command("run")
def cmd_run(
    task: Annotated[str, typer.Argument(help="Task to perform (natural language)")],
    max_steps: Annotated[int, typer.Option("--max-steps", "-n")] = 40,
    freeform: Annotated[
        bool,
        typer.Option("--freeform", "-f", help="Skip planning, pure vision loop"),
    ] = False,
    no_verify: Annotated[
        bool,
        typer.Option("--no-verify", help="Disable screenshot verification after each action"),
    ] = False,
    verbose: Annotated[bool, typer.Option("--verbose", "-v")] = False,
) -> None:
    """Run a task using vision + computer control (click, type, scroll).

    Examples:
      owlmind vision run "открой Telegram, найди Масрура и напиши привет"
      owlmind vision run "find the top Hacker News story and summarize it"
      owlmind vision run "take a screenshot and open Safari" --freeform
    """
    from owlmind.vision.actions import is_actions_available
    from owlmind.vision.screenshot import is_screenshot_available
    from owlmind.vision.smart_driver import (
        AgentResult,
        AgentStep,
        AnthropicComputerAgent,
        SmartComputerAgent,
        build_agent,
    )

    _load_env()

    # Status header
    console.print(f"\n[bold]Vision Agent[/bold] — {task[:80]}")

    caps = []
    if is_screenshot_available():
        caps.append("[green]screenshot ✓[/green]")
    else:
        caps.append("[red]screenshot ✗[/red]")
    if is_actions_available():
        caps.append("[green]mouse/keyboard ✓[/green]")
    else:
        caps.append("[yellow]mouse/keyboard ✗ (install pyautogui)[/yellow]")
    console.print("  " + "  ".join(caps))

    # Build agent
    try:
        agent = build_agent()
    except RuntimeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1) from None

    console.print(f"  Provider: [cyan]{_agent_name(agent)}[/cyan]\n")

    # --- Anthropic native Computer Use ---
    if isinstance(agent, AnthropicComputerAgent):

        def on_cu_step(step: VisionStep) -> None:
            icon = "[green]✓[/green]" if step.is_final else "→"
            if step.action:
                astr = step.action.action_type
                if step.action.coordinate:
                    astr += f" @ {step.action.coordinate}"
                elif step.action.text:
                    astr += f" '{step.action.text[:30]}'"
                console.print(f"  [{step.step_num:02d}] {icon} {astr}")
            if verbose and step.claude_thinking:
                console.print(f"       [dim]{step.claude_thinking[:200]}[/dim]")
            if step.is_final:
                console.print(f"\n[green]Done:[/green] {step.final_message}")

        steps = agent.run(task, max_steps=max_steps, on_step=on_cu_step)
        console.print(f"\nCompleted in [bold]{len(steps)}[/bold] step(s)")
        return

    # --- SmartComputerAgent (multi-provider) ---
    assert isinstance(agent, SmartComputerAgent)
    if no_verify:
        agent._verify = False

    def on_step(step: AgentStep) -> None:
        icon = "[green]✓[/green]" if step.success else "[red]✗[/red]"
        retry_str = f" (retry {step.retries})" if step.retries else ""
        console.print(
            f"  [{step.step_num:02d}] {icon} {step.description[:60]}{retry_str}"
        )
        if step.action:
            astr = step.action.action_type
            if step.action.coordinate:
                astr += f" @ {step.action.coordinate}"
            elif step.action.text:
                astr += f" '{step.action.text[:30]}'"
            console.print(f"       → [dim]{astr}[/dim]")
        if verbose and step.thinking:
            console.print(f"       [dim italic]{step.thinking[:200]}[/dim italic]")
        if not step.success and step.result:
            console.print(f"       [red]Error: {step.result[:100]}[/red]")

    if freeform:
        result: AgentResult = agent.run_freeform(task, max_steps=max_steps, on_step=on_step)
    else:
        result = agent.run(task, max_steps=max_steps, on_step=on_step)

    # Summary
    color = "green" if result.success else "red"
    icon = "✓" if result.success else "✗"
    console.print(
        f"\n[bold {color}]{icon} {'SUCCESS' if result.success else 'FAILED'}[/bold {color}]  "
        f"{result.step_count} steps · "
        f"{result.successful_steps}/{result.step_count} succeeded · "
        f"{result.total_time_ms}ms"
    )
    if result.final_message:
        console.print(
            Panel(result.final_message[:500], title="Result", border_style=color)
        )


# ---------------------------------------------------------------------------
# telegram — quick Telegram shortcuts (no vision needed)
# ---------------------------------------------------------------------------


@vision_app.command("telegram")
def cmd_telegram(
    contact: Annotated[str, typer.Argument(help="Contact name to message")],
    message: Annotated[str, typer.Option("--msg", "-m", help="Message to send")] = "",
    open_only: Annotated[
        bool, typer.Option("--open", help="Just open the chat, don't send")
    ] = False,
) -> None:
    """Control Telegram via AppleScript (no API key needed).

    Examples:
      owlmind vision telegram "Масрур"
      owlmind vision telegram "Масрур" --msg "Привет! Как дела?"
    """
    from owlmind.vision.macos import telegram_open_chat, telegram_send_message

    if open_only or not message:
        console.print(f"Opening Telegram chat with [cyan]{contact}[/cyan]...")
        telegram_open_chat(contact)
        console.print("[green]✓ Chat opened[/green]")
    else:
        console.print(
            f"Sending message to [cyan]{contact}[/cyan]: [dim]{message[:60]}[/dim]"
        )
        telegram_send_message(contact, message)
        console.print("[green]✓ Message sent[/green]")


# ---------------------------------------------------------------------------
# apps — list running apps
# ---------------------------------------------------------------------------


@vision_app.command("apps")
def cmd_apps() -> None:
    """List currently running macOS applications."""
    from owlmind.vision.macos import get_frontmost_app, get_running_apps

    apps = get_running_apps()
    front = get_frontmost_app()

    console.print(f"[bold]Running apps[/bold] (active: [cyan]{front}[/cyan])\n")
    for app in sorted(apps):
        marker = " ◀ active" if app == front else ""
        console.print(f"  {app}{marker}")


# ---------------------------------------------------------------------------
# Utility
# ---------------------------------------------------------------------------


def _agent_name(agent: object) -> str:
    from owlmind.vision.smart_driver import AnthropicComputerAgent, SmartComputerAgent

    if isinstance(agent, AnthropicComputerAgent):
        return f"Anthropic Computer Use ({agent._model})"
    if isinstance(agent, SmartComputerAgent):
        return agent._provider.name
    return str(type(agent).__name__)
