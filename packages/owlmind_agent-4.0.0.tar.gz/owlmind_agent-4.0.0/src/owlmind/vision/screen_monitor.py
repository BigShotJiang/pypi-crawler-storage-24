"""Continuous screen monitoring — Charwiz sees what you see.

Captures screenshots periodically, detects meaningful changes between
frames, understands what the user is doing, and proactively offers help.

Usage::

    from owlmind.vision.screen_monitor import ScreenMonitor, MonitorConfig

    monitor = ScreenMonitor(MonitorConfig(
        capture_interval=5.0,
        on_insight=lambda insight: print(insight.summary),
    ))
    monitor.start()   # runs in background thread
    # ... later ...
    monitor.stop()

    # Or use the async API:
    await monitor.start_async()
"""

from __future__ import annotations

import base64
import contextlib
import hashlib
import io
import logging
import threading
import time
from collections import deque
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from owlmind.vision.models import ScreenshotResult
from owlmind.vision.providers import VisionProvider, build_vision_provider
from owlmind.vision.screenshot import capture_screenshot, is_screenshot_available

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Optional imports
# ---------------------------------------------------------------------------

_PIL_AVAILABLE = False
try:
    from PIL import Image, ImageChops, ImageStat

    _PIL_AVAILABLE = True
except ImportError:
    pass

_NUMPY_AVAILABLE = False
try:
    import numpy as np  # noqa: F401

    _NUMPY_AVAILABLE = True
except ImportError:
    pass


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------


@dataclass
class ScreenInsight:
    """A single observation from screen monitoring."""

    timestamp: float
    category: str  # "change_detected", "activity", "suggestion", "idle", "error_detected"
    summary: str
    detail: str = ""
    screenshot: ScreenshotResult | None = None
    change_score: float = 0.0  # 0.0 = no change, 1.0 = completely different
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class MonitorConfig:
    """Configuration for the screen monitor."""

    capture_interval: float = 5.0
    """Seconds between screenshot captures."""

    change_threshold: float = 0.05
    """Minimum change score (0-1) to trigger analysis. Lower = more sensitive."""

    analysis_cooldown: float = 15.0
    """Minimum seconds between vision LLM calls (to control cost)."""

    max_history: int = 50
    """Maximum number of insights to keep in memory."""

    idle_threshold: float = 60.0
    """Seconds of no change before reporting idle state."""

    detect_errors: bool = True
    """Look for error dialogs, stack traces, etc. on screen."""

    proactive_help: bool = True
    """Offer help suggestions based on detected activity."""

    # Callbacks
    on_insight: Callable[[ScreenInsight], None] | None = None
    """Called whenever a new insight is generated."""

    on_change: Callable[[float, ScreenshotResult], None] | None = None
    """Called when a screen change above threshold is detected."""


# ---------------------------------------------------------------------------
# Change detector
# ---------------------------------------------------------------------------


class ChangeDetector:
    """Detect and quantify differences between consecutive screenshots."""

    def __init__(self) -> None:
        self._prev_hash: str = ""
        self._prev_image_bytes: bytes = b""

    def compute_change(self, screenshot: ScreenshotResult) -> float:
        """Return a change score between 0.0 (identical) and 1.0 (completely different).

        Uses perceptual comparison when PIL is available, falls back to hash comparison.
        """
        current_bytes = base64.standard_b64decode(screenshot.base64_image)
        current_hash = hashlib.md5(current_bytes).hexdigest()  # noqa: S324

        if not self._prev_hash:
            # First frame — treat as full change
            self._prev_hash = current_hash
            self._prev_image_bytes = current_bytes
            return 1.0

        if current_hash == self._prev_hash:
            return 0.0  # bit-identical

        score = self._perceptual_diff(current_bytes)

        self._prev_hash = current_hash
        self._prev_image_bytes = current_bytes
        return score

    def _perceptual_diff(self, current_bytes: bytes) -> float:
        """Compute perceptual difference using PIL if available."""
        if not _PIL_AVAILABLE or not self._prev_image_bytes:
            return 0.5  # unknown — assume moderate change

        try:
            prev_img = Image.open(io.BytesIO(self._prev_image_bytes)).convert("L")
            curr_img = Image.open(io.BytesIO(current_bytes)).convert("L")

            # Resize both to same small size for fast comparison
            size = (160, 100)
            prev_small = prev_img.resize(size)
            curr_small = curr_img.resize(size)

            diff = ImageChops.difference(prev_small, curr_small)
            stat = ImageStat.Stat(diff)
            # mean difference normalized to 0-1
            mean_diff = stat.mean[0] / 255.0

            # Root-mean-square difference for better sensitivity
            rms = stat.rms[0] / 255.0

            # Combine mean and RMS (RMS is more sensitive to localized changes)
            return min(1.0, (mean_diff + rms) / 2.0 * 3.0)  # scale up for sensitivity
        except Exception:
            return 0.5


# ---------------------------------------------------------------------------
# Activity classifier
# ---------------------------------------------------------------------------

# Keywords that suggest specific activities (checked against LLM analysis)
_ACTIVITY_PATTERNS: dict[str, list[str]] = {
    "coding": ["code", "editor", "IDE", "terminal", "VSCode", "PyCharm", "Xcode", "vim", "emacs", "Cursor"],
    "browsing": ["browser", "Safari", "Chrome", "Firefox", "web page", "URL", "tab"],
    "communication": ["Slack", "Discord", "Telegram", "Messages", "email", "Mail", "Teams"],
    "writing": ["document", "Word", "Pages", "Notes", "writing", "Google Docs"],
    "design": ["Figma", "Sketch", "Photoshop", "design", "canvas"],
    "terminal": ["terminal", "command line", "shell", "bash", "zsh", "iTerm"],
}

_ERROR_KEYWORDS: list[str] = [
    "error", "exception", "traceback", "failed", "crash",
    "SIGABRT", "SIGSEGV", "panic", "fatal", "denied",
    "not found", "cannot", "unable", "refused",
]


def classify_activity(analysis_text: str) -> str:
    """Return the most likely activity category from LLM analysis text."""
    text_lower = analysis_text.lower()
    best_cat = "unknown"
    best_score = 0

    for category, keywords in _ACTIVITY_PATTERNS.items():
        score = sum(1 for kw in keywords if kw.lower() in text_lower)
        if score > best_score:
            best_score = score
            best_cat = category

    return best_cat


def detect_errors(analysis_text: str) -> list[str]:
    """Extract potential error messages from LLM analysis text."""
    text_lower = analysis_text.lower()
    found = []
    for kw in _ERROR_KEYWORDS:
        if kw in text_lower:
            # Extract the sentence containing the keyword
            for sentence in analysis_text.replace("\n", ". ").split(". "):
                if kw in sentence.lower():
                    found.append(sentence.strip())
                    break
    return found


# ---------------------------------------------------------------------------
# Screen monitor
# ---------------------------------------------------------------------------


class ScreenMonitor:
    """Continuously monitors the screen, detects changes, and generates insights.

    Runs in a background thread (or asyncio task) and calls configured
    callbacks when it has something to report.
    """

    def __init__(
        self,
        config: MonitorConfig | None = None,
        provider: VisionProvider | None = None,
    ) -> None:
        self._config = config or MonitorConfig()
        self._provider = provider
        self._provider_initialized = False
        self._detector = ChangeDetector()
        self._insights: deque[ScreenInsight] = deque(maxlen=self._config.max_history)
        self._running = False
        self._thread: threading.Thread | None = None
        self._lock = threading.Lock()

        # Timing state
        self._last_analysis_time: float = 0.0
        self._last_change_time: float = 0.0
        self._idle_reported: bool = False

    # ---- public API ----

    @property
    def is_running(self) -> bool:
        return self._running

    @property
    def insights(self) -> list[ScreenInsight]:
        """Return a copy of recent insights."""
        with self._lock:
            return list(self._insights)

    @property
    def latest(self) -> ScreenInsight | None:
        """Return the most recent insight, or None."""
        with self._lock:
            return self._insights[-1] if self._insights else None

    def start(self) -> None:
        """Start monitoring in a background daemon thread."""
        if self._running:
            logger.warning("ScreenMonitor already running")
            return

        if not is_screenshot_available():
            logger.error("Screenshot capture not available — cannot start monitor")
            return

        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True, name="screen-monitor")
        self._thread.start()
        logger.info("ScreenMonitor started (interval=%.1fs)", self._config.capture_interval)

    def stop(self) -> None:
        """Stop the monitor and wait for the thread to exit."""
        self._running = False
        if self._thread is not None:
            self._thread.join(timeout=10)
            self._thread = None
        logger.info("ScreenMonitor stopped")

    async def start_async(self) -> None:
        """Run the monitor loop in an asyncio-compatible way."""
        import asyncio

        if not is_screenshot_available():
            logger.error("Screenshot capture not available — cannot start monitor")
            return

        self._running = True
        logger.info("ScreenMonitor started async (interval=%.1fs)", self._config.capture_interval)

        try:
            while self._running:
                self._tick()
                await asyncio.sleep(self._config.capture_interval)
        finally:
            self._running = False
            logger.info("ScreenMonitor async stopped")

    # ---- internal loop ----

    def _loop(self) -> None:
        """Main monitoring loop (runs in background thread)."""
        self._ensure_provider()

        while self._running:
            try:
                self._tick()
            except Exception:
                logger.debug("ScreenMonitor tick error", exc_info=True)

            time.sleep(self._config.capture_interval)

    def _ensure_provider(self) -> None:
        """Lazy-init the vision provider."""
        if self._provider_initialized:
            return
        self._provider_initialized = True
        if self._provider is None:
            try:
                self._provider = build_vision_provider()
            except Exception:
                logger.debug("ScreenMonitor: no vision provider available")

    def _tick(self) -> None:
        """One monitoring cycle: capture, detect change, analyze if needed."""
        self._ensure_provider()

        try:
            screenshot = capture_screenshot()
        except Exception as exc:
            logger.debug("Screenshot capture failed: %s", exc)
            return

        now = time.time()
        change_score = self._detector.compute_change(screenshot)

        # Notify about change
        if change_score >= self._config.change_threshold:
            self._last_change_time = now
            self._idle_reported = False

            if self._config.on_change:
                with contextlib.suppress(Exception):
                    self._config.on_change(change_score, screenshot)

            # Analyze with vision LLM if cooldown has elapsed
            if (
                self._provider
                and now - self._last_analysis_time >= self._config.analysis_cooldown
            ):
                self._last_analysis_time = now
                self._analyze_screen(screenshot, change_score, now)

        # Idle detection
        elif (
            self._last_change_time > 0
            and now - self._last_change_time >= self._config.idle_threshold
            and not self._idle_reported
        ):
            self._idle_reported = True
            idle_duration = now - self._last_change_time
            insight = ScreenInsight(
                timestamp=now,
                category="idle",
                summary=f"Screen idle for {idle_duration:.0f}s",
                change_score=0.0,
            )
            self._add_insight(insight)

    def _analyze_screen(
        self,
        screenshot: ScreenshotResult,
        change_score: float,
        now: float,
    ) -> None:
        """Run vision LLM analysis on the current screen."""
        if self._provider is None:
            return

        try:
            # Basic screen description
            analysis = self._provider.analyze(
                screenshot,
                "Briefly describe what is currently shown on screen. "
                "Note the active application, any visible content, and what the user "
                "appears to be doing. If there are any errors or warnings visible, "
                "highlight them.",
            )

            activity = classify_activity(analysis)

            insight = ScreenInsight(
                timestamp=now,
                category="activity",
                summary=analysis[:500],
                detail=analysis,
                screenshot=screenshot,
                change_score=change_score,
                metadata={"activity_type": activity},
            )

            # Error detection
            if self._config.detect_errors:
                errors = detect_errors(analysis)
                if errors:
                    insight.category = "error_detected"
                    insight.metadata["errors"] = errors

                    # If errors found, do a focused error analysis
                    try:
                        error_analysis = self._provider.analyze(
                            screenshot,
                            "Focus on any errors, warnings, or problems visible on screen. "
                            "Explain what went wrong and suggest how to fix it. "
                            "If no errors are visible, say 'No errors detected.'",
                        )
                        if "no errors" not in error_analysis.lower():
                            insight.detail = error_analysis
                    except Exception:
                        pass

            # Proactive help suggestion
            if self._config.proactive_help and insight.category == "activity":
                self._maybe_suggest_help(insight, screenshot, activity)

            self._add_insight(insight)

        except Exception as exc:
            logger.debug("Screen analysis failed: %s", exc)
            # Still record a basic insight
            insight = ScreenInsight(
                timestamp=now,
                category="change_detected",
                summary=f"Screen changed (score={change_score:.2f}), analysis unavailable",
                change_score=change_score,
            )
            self._add_insight(insight)

    def _maybe_suggest_help(
        self,
        insight: ScreenInsight,
        screenshot: ScreenshotResult,
        activity: str,
    ) -> None:
        """Generate proactive help suggestions based on detected activity."""
        if self._provider is None:
            return

        # Only suggest for certain activities
        if activity not in ("coding", "terminal", "browsing"):
            return

        prompts = {
            "coding": (
                "The user is coding. Based on what's visible on screen, is there anything "
                "I could help with? For example: suggesting a better approach, pointing out "
                "a potential bug, or recommending a relevant tool/library. "
                "Be concise. If nothing to suggest, say 'No suggestions.'"
            ),
            "terminal": (
                "The user is in the terminal. Based on what's visible, is there a more "
                "efficient command or workflow they could use? "
                "Be concise. If nothing to suggest, say 'No suggestions.'"
            ),
            "browsing": (
                "The user is browsing the web. Based on what's visible, is there anything "
                "relevant I could help with? Be concise. If nothing to suggest, say 'No suggestions.'"
            ),
        }

        prompt = prompts.get(activity, "")
        if not prompt:
            return

        try:
            suggestion = self._provider.analyze(screenshot, prompt)
            if suggestion and "no suggestion" not in suggestion.lower():
                suggestion_insight = ScreenInsight(
                    timestamp=time.time(),
                    category="suggestion",
                    summary=suggestion[:500],
                    detail=suggestion,
                    change_score=0.0,
                    metadata={"activity_type": activity, "triggered_by": "proactive"},
                )
                self._add_insight(suggestion_insight)
        except Exception:
            pass

    def _add_insight(self, insight: ScreenInsight) -> None:
        """Store an insight and fire the callback."""
        with self._lock:
            self._insights.append(insight)

        if self._config.on_insight:
            try:
                self._config.on_insight(insight)
            except Exception:
                logger.debug("on_insight callback error", exc_info=True)

    # ---- query API ----

    def get_activity_summary(self, last_n: int = 10) -> str:
        """Return a text summary of recent screen activity."""
        with self._lock:
            recent = list(self._insights)[-last_n:]

        if not recent:
            return "No screen activity recorded yet."

        lines: list[str] = []
        for ins in recent:
            ts = time.strftime("%H:%M:%S", time.localtime(ins.timestamp))
            lines.append(f"[{ts}] ({ins.category}) {ins.summary[:120]}")

        return "\n".join(lines)

    def get_errors(self) -> list[ScreenInsight]:
        """Return all error insights from the history."""
        with self._lock:
            return [i for i in self._insights if i.category == "error_detected"]

    def get_suggestions(self) -> list[ScreenInsight]:
        """Return all proactive suggestions from the history."""
        with self._lock:
            return [i for i in self._insights if i.category == "suggestion"]
