"""Multimodal understanding — video, PDF, screenshots, any media.

Provides unified analysis for diverse media types using vision providers:
  - Video analysis: extract keyframes, analyze with vision LLM
  - PDF reading: extract text + images, analyze pages
  - Screenshot monitoring: periodic screen capture + analysis
  - Image understanding: any image -> description + actionable insights

Usage::

    from owlmind.vision.multimodal import MultimodalAnalyzer

    analyzer = MultimodalAnalyzer()
    result = analyzer.analyze_pdf("/path/to/doc.pdf")
    result = analyzer.analyze_image("/path/to/screenshot.png", "What app is open?")
    result = analyzer.analyze_video("/path/to/demo.mp4", "Summarize this demo")
"""

from __future__ import annotations

import base64
import io
import logging
import os
import subprocess
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from owlmind.vision.models import ScreenshotResult
from owlmind.vision.providers import VisionProvider, build_vision_provider
from owlmind.vision.screenshot import encode_image_file

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Optional imports
# ---------------------------------------------------------------------------

_PIL_AVAILABLE = False
try:
    from PIL import Image  # noqa: F401

    _PIL_AVAILABLE = True
except ImportError:
    pass

_PDFPLUMBER_AVAILABLE = False
try:
    import pdfplumber

    _PDFPLUMBER_AVAILABLE = True
except ImportError:
    pass

_PYPDF2_AVAILABLE = False
try:
    from PyPDF2 import PdfReader

    _PYPDF2_AVAILABLE = True
except ImportError:
    pass

_CV2_AVAILABLE = False
try:
    import cv2
    import numpy as np  # noqa: F401

    _CV2_AVAILABLE = True
except ImportError:
    pass


# ---------------------------------------------------------------------------
# Result models
# ---------------------------------------------------------------------------


@dataclass
class MediaAnalysisResult:
    """Result from analyzing any media type."""

    media_type: str  # "image", "pdf", "video", "screenshot"
    source_path: str = ""
    summary: str = ""
    details: list[str] = field(default_factory=list)
    page_analyses: list[PageAnalysis] = field(default_factory=list)
    frame_analyses: list[FrameAnalysis] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    processing_time: float = 0.0
    error: str = ""


@dataclass
class PageAnalysis:
    """Analysis result for a single PDF page."""

    page_num: int
    text: str = ""
    image_count: int = 0
    analysis: str = ""
    has_tables: bool = False
    table_data: list[list[list[str]]] = field(default_factory=list)


@dataclass
class FrameAnalysis:
    """Analysis result for a single video keyframe."""

    frame_index: int
    timestamp_sec: float = 0.0
    analysis: str = ""
    screenshot: ScreenshotResult | None = None


# ---------------------------------------------------------------------------
# PDF analyzer
# ---------------------------------------------------------------------------


class PDFAnalyzer:
    """Extract text, images, and tables from PDF documents."""

    def __init__(self, provider: VisionProvider | None = None) -> None:
        self._provider = provider

    def analyze(
        self,
        pdf_path: str,
        *,
        prompt: str = "Summarize the content of this page.",
        max_pages: int = 50,
        extract_tables: bool = True,
        analyze_images: bool = True,
    ) -> MediaAnalysisResult:
        """Analyze a PDF file — extract text, tables, and optionally analyze images."""
        start = time.time()
        result = MediaAnalysisResult(media_type="pdf", source_path=pdf_path)

        if not os.path.exists(pdf_path):
            result.error = f"File not found: {pdf_path}"
            return result

        if _PDFPLUMBER_AVAILABLE:
            result = self._analyze_pdfplumber(
                pdf_path, prompt, max_pages, extract_tables, analyze_images,
            )
        elif _PYPDF2_AVAILABLE:
            result = self._analyze_pypdf2(pdf_path, prompt, max_pages)
        else:
            result.error = (
                "No PDF library available. Install pdfplumber or PyPDF2: "
                "pip install pdfplumber  OR  pip install PyPDF2"
            )
            return result

        result.processing_time = time.time() - start
        return result

    def _analyze_pdfplumber(
        self,
        pdf_path: str,
        prompt: str,
        max_pages: int,
        extract_tables: bool,
        analyze_images: bool,
    ) -> MediaAnalysisResult:
        result = MediaAnalysisResult(media_type="pdf", source_path=pdf_path)

        try:
            with pdfplumber.open(pdf_path) as pdf:
                result.metadata = {
                    "page_count": len(pdf.pages),
                    "info": pdf.metadata or {},
                }

                pages_to_process = min(len(pdf.pages), max_pages)
                all_text_parts: list[str] = []

                for i in range(pages_to_process):
                    page = pdf.pages[i]
                    page_analysis = PageAnalysis(page_num=i + 1)

                    # Extract text
                    text = page.extract_text() or ""
                    page_analysis.text = text
                    if text.strip():
                        all_text_parts.append(f"--- Page {i + 1} ---\n{text}")

                    # Extract tables
                    if extract_tables:
                        tables = page.extract_tables()
                        if tables:
                            page_analysis.has_tables = True
                            page_analysis.table_data = [
                                [[cell or "" for cell in row] for row in table]
                                for table in tables
                            ]

                    # Count images
                    images = page.images
                    page_analysis.image_count = len(images) if images else 0

                    # Analyze page image with vision provider
                    if analyze_images and self._provider and _PIL_AVAILABLE:
                        try:
                            page_img = page.to_image(resolution=150)
                            buf = io.BytesIO()
                            page_img.save(buf, format="PNG")
                            b64 = base64.standard_b64encode(buf.getvalue()).decode()

                            screenshot = ScreenshotResult(
                                base64_image=b64,
                                width=int(page_img.original.width),
                                height=int(page_img.original.height),
                                timestamp=time.time(),
                                media_type="image/png",
                            )
                            page_analysis.analysis = self._provider.analyze(
                                screenshot, f"Page {i + 1} of a PDF. {prompt}"
                            )
                        except Exception as exc:
                            logger.debug("Vision analysis failed for page %d: %s", i + 1, exc)

                    result.page_analyses.append(page_analysis)

                # Generate overall summary
                full_text = "\n".join(all_text_parts)
                if self._provider and full_text.strip():
                    try:
                        summary_prompt = (
                            f"Summarize this PDF content ({pages_to_process} pages):\n\n"
                            f"{full_text[:8000]}"
                        )
                        result.summary = self._provider.think(summary_prompt)
                    except Exception:
                        result.summary = full_text[:2000]
                else:
                    result.summary = full_text[:2000] if full_text else "(no text extracted)"

        except Exception as exc:
            result.error = f"PDF processing error: {exc}"
            logger.error("PDF analysis failed: %s", exc)

        return result

    def _analyze_pypdf2(
        self,
        pdf_path: str,
        prompt: str,
        max_pages: int,
    ) -> MediaAnalysisResult:
        result = MediaAnalysisResult(media_type="pdf", source_path=pdf_path)

        try:
            reader = PdfReader(pdf_path)
            result.metadata = {
                "page_count": len(reader.pages),
                "info": dict(reader.metadata) if reader.metadata else {},
            }

            pages_to_process = min(len(reader.pages), max_pages)
            all_text_parts: list[str] = []

            for i in range(pages_to_process):
                page = reader.pages[i]
                text = page.extract_text() or ""
                page_analysis = PageAnalysis(page_num=i + 1, text=text)

                if text.strip():
                    all_text_parts.append(f"--- Page {i + 1} ---\n{text}")

                result.page_analyses.append(page_analysis)

            full_text = "\n".join(all_text_parts)
            if self._provider and full_text.strip():
                try:
                    summary_prompt = (
                        f"Summarize this PDF content ({pages_to_process} pages):\n\n"
                        f"{full_text[:8000]}"
                    )
                    result.summary = self._provider.think(summary_prompt)
                except Exception:
                    result.summary = full_text[:2000]
            else:
                result.summary = full_text[:2000] if full_text else "(no text extracted)"

        except Exception as exc:
            result.error = f"PDF processing error: {exc}"
            logger.error("PDF analysis failed: %s", exc)

        return result


# ---------------------------------------------------------------------------
# Video analyzer
# ---------------------------------------------------------------------------


class VideoAnalyzer:
    """Extract keyframes from video and analyze with vision LLM."""

    def __init__(self, provider: VisionProvider | None = None) -> None:
        self._provider = provider

    def analyze(
        self,
        video_path: str,
        *,
        prompt: str = "Describe what is happening in this frame.",
        max_keyframes: int = 10,
        keyframe_interval_sec: float = 0.0,
    ) -> MediaAnalysisResult:
        """Analyze a video by extracting and analyzing keyframes.

        Args:
            video_path: Path to video file.
            prompt: Question to ask about each frame.
            max_keyframes: Maximum number of frames to extract.
            keyframe_interval_sec: If >0, extract frames at this interval.
                If 0, use scene-change detection or uniform sampling.
        """
        start = time.time()
        result = MediaAnalysisResult(media_type="video", source_path=video_path)

        if not os.path.exists(video_path):
            result.error = f"File not found: {video_path}"
            return result

        if _CV2_AVAILABLE:
            result = self._analyze_cv2(video_path, prompt, max_keyframes, keyframe_interval_sec)
        elif self._has_ffmpeg():
            result = self._analyze_ffmpeg(video_path, prompt, max_keyframes, keyframe_interval_sec)
        else:
            result.error = (
                "No video processing backend available. Install opencv-python or ffmpeg: "
                "pip install opencv-python  OR  brew install ffmpeg"
            )
            return result

        result.processing_time = time.time() - start
        return result

    def _analyze_cv2(
        self,
        video_path: str,
        prompt: str,
        max_keyframes: int,
        interval_sec: float,
    ) -> MediaAnalysisResult:
        """Extract keyframes using OpenCV."""
        result = MediaAnalysisResult(media_type="video", source_path=video_path)

        try:
            cap = cv2.VideoCapture(video_path)
            if not cap.isOpened():
                result.error = f"Cannot open video: {video_path}"
                return result

            fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
            total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
            duration_sec = total_frames / fps if fps > 0 else 0

            result.metadata = {
                "fps": fps,
                "total_frames": total_frames,
                "duration_seconds": duration_sec,
                "width": int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)),
                "height": int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)),
            }

            # Determine which frames to extract
            if interval_sec > 0:
                frame_indices = []
                t = 0.0
                while t < duration_sec and len(frame_indices) < max_keyframes:
                    frame_indices.append(int(t * fps))
                    t += interval_sec
            else:
                # Uniform sampling
                if total_frames <= max_keyframes:
                    frame_indices = list(range(total_frames))
                else:
                    step = total_frames // max_keyframes
                    frame_indices = [i * step for i in range(max_keyframes)]

            # Extract and analyze frames
            prev_frame_gray = None
            for idx in frame_indices:
                cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
                ret, frame = cap.read()
                if not ret:
                    continue

                # Skip near-duplicate frames via simple histogram comparison
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                if prev_frame_gray is not None and interval_sec <= 0:
                    similarity = cv2.compareHist(
                        cv2.calcHist([prev_frame_gray], [0], None, [64], [0, 256]),
                        cv2.calcHist([gray], [0], None, [64], [0, 256]),
                        cv2.HISTCMP_CORREL,
                    )
                    if similarity > 0.98:  # near-identical
                        continue
                prev_frame_gray = gray

                # Encode frame as PNG
                _, buf = cv2.imencode(".png", frame)
                b64 = base64.standard_b64encode(buf.tobytes()).decode()

                timestamp = idx / fps if fps > 0 else 0.0
                screenshot = ScreenshotResult(
                    base64_image=b64,
                    width=frame.shape[1],
                    height=frame.shape[0],
                    timestamp=timestamp,
                    media_type="image/png",
                )

                analysis_text = ""
                if self._provider:
                    try:
                        analysis_text = self._provider.analyze(
                            screenshot,
                            f"Video frame at {timestamp:.1f}s. {prompt}",
                        )
                    except Exception as exc:
                        logger.debug("Frame analysis failed at %.1fs: %s", timestamp, exc)

                result.frame_analyses.append(FrameAnalysis(
                    frame_index=idx,
                    timestamp_sec=timestamp,
                    analysis=analysis_text,
                    screenshot=screenshot,
                ))

            cap.release()

            # Generate overall summary
            if self._provider and result.frame_analyses:
                frame_summaries = "\n".join(
                    f"- {fa.timestamp_sec:.1f}s: {fa.analysis[:200]}"
                    for fa in result.frame_analyses
                    if fa.analysis
                )
                if frame_summaries:
                    try:
                        result.summary = self._provider.think(
                            f"Summarize this video ({duration_sec:.0f}s) based on keyframe analyses:\n{frame_summaries}"
                        )
                    except Exception:
                        result.summary = frame_summaries
            elif result.frame_analyses:
                result.summary = f"Extracted {len(result.frame_analyses)} keyframes from {duration_sec:.0f}s video"

        except Exception as exc:
            result.error = f"Video processing error: {exc}"
            logger.error("Video analysis failed: %s", exc, exc_info=True)

        return result

    def _analyze_ffmpeg(
        self,
        video_path: str,
        prompt: str,
        max_keyframes: int,
        interval_sec: float,
    ) -> MediaAnalysisResult:
        """Extract keyframes using ffmpeg (fallback when OpenCV is not available)."""
        result = MediaAnalysisResult(media_type="video", source_path=video_path)

        with tempfile.TemporaryDirectory(prefix="owlmind_video_") as tmpdir:
            try:
                # Get video duration
                probe = subprocess.run(
                    [
                        "ffprobe", "-v", "error",
                        "-show_entries", "format=duration",
                        "-of", "csv=p=0",
                        video_path,
                    ],
                    capture_output=True, text=True, timeout=30,
                )
                duration = float(probe.stdout.strip()) if probe.stdout.strip() else 60.0
                result.metadata = {"duration_seconds": duration}

                # Calculate frame extraction rate
                if interval_sec > 0:
                    fps_filter = f"fps=1/{interval_sec}"
                else:
                    # Uniform sampling: extract max_keyframes across the duration
                    rate = max_keyframes / duration if duration > 0 else 1.0
                    fps_filter = f"fps={min(rate, 1.0)}"

                # Extract frames
                subprocess.run(
                    [
                        "ffmpeg", "-i", video_path,
                        "-vf", fps_filter,
                        "-frames:v", str(max_keyframes),
                        "-q:v", "2",
                        os.path.join(tmpdir, "frame_%04d.png"),
                    ],
                    capture_output=True, timeout=120,
                )

                # Analyze extracted frames
                frame_files = sorted(Path(tmpdir).glob("frame_*.png"))
                for i, frame_file in enumerate(frame_files[:max_keyframes]):
                    timestamp = (i * duration / len(frame_files)) if frame_files else 0.0

                    screenshot = encode_image_file(str(frame_file))

                    analysis_text = ""
                    if self._provider:
                        try:
                            analysis_text = self._provider.analyze(
                                screenshot,
                                f"Video frame at {timestamp:.1f}s. {prompt}",
                            )
                        except Exception as exc:
                            logger.debug("Frame analysis failed: %s", exc)

                    result.frame_analyses.append(FrameAnalysis(
                        frame_index=i,
                        timestamp_sec=timestamp,
                        analysis=analysis_text,
                        screenshot=screenshot,
                    ))

                # Summary
                if self._provider and result.frame_analyses:
                    frame_summaries = "\n".join(
                        f"- {fa.timestamp_sec:.1f}s: {fa.analysis[:200]}"
                        for fa in result.frame_analyses
                        if fa.analysis
                    )
                    if frame_summaries:
                        try:
                            result.summary = self._provider.think(
                                f"Summarize this video ({duration:.0f}s) based on keyframe analyses:\n{frame_summaries}"
                            )
                        except Exception:
                            result.summary = frame_summaries

            except Exception as exc:
                result.error = f"ffmpeg processing error: {exc}"
                logger.error("ffmpeg video analysis failed: %s", exc)

        return result

    @staticmethod
    def _has_ffmpeg() -> bool:
        try:
            subprocess.run(["ffmpeg", "-version"], capture_output=True, timeout=5)
            return True
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return False


# ---------------------------------------------------------------------------
# Image analyzer
# ---------------------------------------------------------------------------


class ImageAnalyzer:
    """Analyze any image file — generate description and actionable insights."""

    def __init__(self, provider: VisionProvider | None = None) -> None:
        self._provider = provider

    def analyze(
        self,
        image_path: str,
        *,
        prompt: str = "Describe this image in detail and provide any actionable insights.",
    ) -> MediaAnalysisResult:
        """Analyze a single image file."""
        start = time.time()
        result = MediaAnalysisResult(media_type="image", source_path=image_path)

        if not os.path.exists(image_path):
            result.error = f"File not found: {image_path}"
            return result

        try:
            screenshot = encode_image_file(image_path)
            result.metadata = {
                "width": screenshot.width,
                "height": screenshot.height,
                "format": screenshot.media_type,
                "file_size": os.path.getsize(image_path),
            }

            if self._provider:
                result.summary = self._provider.analyze(screenshot, prompt)

                # Extract actionable items
                try:
                    actions = self._provider.analyze(
                        screenshot,
                        "List any actionable items, errors, warnings, or things that need "
                        "attention in this image. Return a JSON array of strings. "
                        "If nothing actionable, return [].",
                    )
                    # Try to parse JSON from the response
                    import json
                    import re
                    json_match = re.search(r"\[.*?\]", actions, re.DOTALL)
                    if json_match:
                        items = json.loads(json_match.group())
                        result.details = [str(item) for item in items]
                except Exception:
                    pass
            else:
                result.summary = f"Image: {screenshot.width}x{screenshot.height} ({screenshot.media_type})"
                result.error = "No vision provider available for analysis"

        except Exception as exc:
            result.error = f"Image processing error: {exc}"
            logger.error("Image analysis failed: %s", exc)

        result.processing_time = time.time() - start
        return result


# ---------------------------------------------------------------------------
# Unified analyzer
# ---------------------------------------------------------------------------


class MultimodalAnalyzer:
    """Unified entry point for analyzing any media type.

    Auto-detects media type from file extension and delegates to
    the appropriate analyzer.
    """

    # Extension to media-type mapping
    _IMAGE_EXTS = frozenset({".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".tiff", ".tif"})
    _VIDEO_EXTS = frozenset({".mp4", ".mov", ".avi", ".mkv", ".webm", ".m4v", ".flv", ".wmv"})
    _PDF_EXTS = frozenset({".pdf"})

    def __init__(self, provider: VisionProvider | None = None) -> None:
        self._provider = provider or build_vision_provider()
        self._pdf = PDFAnalyzer(self._provider)
        self._video = VideoAnalyzer(self._provider)
        self._image = ImageAnalyzer(self._provider)

    def analyze(
        self,
        path: str,
        *,
        prompt: str = "",
        **kwargs: Any,
    ) -> MediaAnalysisResult:
        """Analyze any supported file type.

        Detects type from extension and delegates to the appropriate analyzer.
        """
        ext = Path(path).suffix.lower()

        if ext in self._PDF_EXTS:
            return self.analyze_pdf(path, prompt=prompt or "Summarize this document.", **kwargs)
        elif ext in self._VIDEO_EXTS:
            return self.analyze_video(path, prompt=prompt or "Describe what is happening.", **kwargs)
        elif ext in self._IMAGE_EXTS:
            return self.analyze_image(path, prompt=prompt or "Describe this image.", **kwargs)
        else:
            result = MediaAnalysisResult(media_type="unknown", source_path=path)
            result.error = f"Unsupported file type: {ext}"
            return result

    def analyze_pdf(self, path: str, *, prompt: str = "Summarize this page.", **kwargs: Any) -> MediaAnalysisResult:
        """Analyze a PDF document."""
        return self._pdf.analyze(path, prompt=prompt, **kwargs)

    def analyze_video(self, path: str, *, prompt: str = "Describe this frame.", **kwargs: Any) -> MediaAnalysisResult:
        """Analyze a video file."""
        return self._video.analyze(path, prompt=prompt, **kwargs)

    def analyze_image(self, path: str, *, prompt: str = "Describe this image.", **kwargs: Any) -> MediaAnalysisResult:
        """Analyze an image file."""
        return self._image.analyze(path, prompt=prompt, **kwargs)

    def analyze_screenshot(
        self,
        *,
        prompt: str = "Describe what is currently on screen.",
    ) -> MediaAnalysisResult:
        """Capture and analyze the current screen."""
        from owlmind.vision.screenshot import capture_screenshot, is_screenshot_available

        start = time.time()
        result = MediaAnalysisResult(media_type="screenshot")

        if not is_screenshot_available():
            result.error = "Screenshot capture not available (install pillow or pyautogui)"
            return result

        try:
            screenshot = capture_screenshot()
            result.metadata = {
                "width": screenshot.width,
                "height": screenshot.height,
            }

            if self._provider:
                result.summary = self._provider.analyze(screenshot, prompt)
            else:
                result.summary = f"Screenshot captured: {screenshot.width}x{screenshot.height}"
                result.error = "No vision provider available for analysis"

        except Exception as exc:
            result.error = f"Screenshot analysis error: {exc}"

        result.processing_time = time.time() - start
        return result


# ---------------------------------------------------------------------------
# Module-level convenience functions
# ---------------------------------------------------------------------------


def analyze_file(path: str, *, prompt: str = "", **kwargs: Any) -> MediaAnalysisResult:
    """Quick helper — analyze any file."""
    return MultimodalAnalyzer().analyze(path, prompt=prompt, **kwargs)


def analyze_pdf(path: str, **kwargs: Any) -> MediaAnalysisResult:
    """Quick helper — analyze a PDF."""
    return MultimodalAnalyzer().analyze_pdf(path, **kwargs)


def analyze_video(path: str, **kwargs: Any) -> MediaAnalysisResult:
    """Quick helper — analyze a video."""
    return MultimodalAnalyzer().analyze_video(path, **kwargs)


def analyze_image(path: str, **kwargs: Any) -> MediaAnalysisResult:
    """Quick helper — analyze an image."""
    return MultimodalAnalyzer().analyze_image(path, **kwargs)
