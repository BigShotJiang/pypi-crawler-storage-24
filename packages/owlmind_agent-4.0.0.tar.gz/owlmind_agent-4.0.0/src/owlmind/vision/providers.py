"""Vision provider abstractions — Anthropic, Qwen-VL, OpenAI GPT-4o.

Auto-detects the best available provider from environment variables:
  ANTHROPIC_API_KEY  → Claude (best, supports Computer Use)
  QWEN_API_KEY       → Qwen-VL-Max (cheap Chinese vision model)
  OPENAI_API_KEY     → GPT-4o vision (if OPENAI_BASE_URL is not DeepSeek)
"""

from __future__ import annotations

import logging
import os
from abc import ABC, abstractmethod
from typing import Any

from owlmind.vision.models import ScreenshotResult

logger = logging.getLogger(__name__)

# Tiny 1×1 transparent PNG — used for text-only calls to vision APIs
_BLANK_PNG_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=="
)
_BLANK_SCREENSHOT = ScreenshotResult(
    base64_image=_BLANK_PNG_B64,
    width=1,
    height=1,
    timestamp=0.0,
    media_type="image/png",
)


class VisionProvider(ABC):
    """Abstract base for a vision-capable LLM provider."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Provider identifier, e.g. 'anthropic/claude-sonnet-4-6'."""
        ...

    @abstractmethod
    def is_available(self) -> bool:
        """Return True if SDK installed and API key set."""
        ...

    @abstractmethod
    def analyze(
        self,
        screenshot: ScreenshotResult,
        prompt: str,
        *,
        system: str = "",
    ) -> str:
        """Send screenshot + prompt, return text response."""
        ...

    def think(self, prompt: str, *, system: str = "") -> str:
        """Text-only call (no real screenshot needed). Uses blank image fallback."""
        return self.analyze(_BLANK_SCREENSHOT, prompt, system=system)


# ---------------------------------------------------------------------------
# Anthropic
# ---------------------------------------------------------------------------


class AnthropicVisionProvider(VisionProvider):
    """Claude vision via the Anthropic SDK."""

    def __init__(self, api_key: str, model: str = "claude-sonnet-4-6") -> None:
        self._api_key = api_key
        self._model = model
        self._client: Any = None
        if api_key:
            try:
                import anthropic

                self._client = anthropic.Anthropic(api_key=api_key)
            except ImportError:
                logger.debug("anthropic SDK not installed")

    @property
    def name(self) -> str:
        return f"anthropic/{self._model}"

    def is_available(self) -> bool:
        return self._client is not None

    def analyze(
        self,
        screenshot: ScreenshotResult,
        prompt: str,
        *,
        system: str = "",
    ) -> str:
        if not self._client:
            raise RuntimeError("Anthropic client not initialized")

        content: list[Any] = []
        if screenshot.base64_image and screenshot.width > 1:
            content.append({
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": screenshot.media_type,
                    "data": screenshot.base64_image,
                },
            })
        content.append({"type": "text", "text": prompt})

        kwargs: dict[str, Any] = {
            "model": self._model,
            "max_tokens": 2048,
            "messages": [{"role": "user", "content": content}],
        }
        if system:
            kwargs["system"] = system

        response = self._client.messages.create(**kwargs)
        for block in response.content:
            if getattr(block, "type", "") == "text":
                return block.text
        return ""


# ---------------------------------------------------------------------------
# OpenAI-compatible (Qwen-VL-Max, GPT-4o, etc.)
# ---------------------------------------------------------------------------


class OpenAICompatibleVisionProvider(VisionProvider):
    """Vision via any OpenAI-compatible API (Qwen-VL, GPT-4o, etc.)."""

    def __init__(
        self,
        api_key: str,
        model: str,
        base_url: str = "",
        provider_name: str = "openai",
    ) -> None:
        self._model = model
        self._provider_name = provider_name
        self._client: Any = None
        if api_key:
            try:
                import openai

                kwargs: dict[str, Any] = {"api_key": api_key}
                if base_url:
                    kwargs["base_url"] = base_url
                self._client = openai.OpenAI(**kwargs)
            except ImportError:
                logger.debug("openai SDK not installed")

    @property
    def name(self) -> str:
        return f"{self._provider_name}/{self._model}"

    def is_available(self) -> bool:
        return self._client is not None

    def analyze(
        self,
        screenshot: ScreenshotResult,
        prompt: str,
        *,
        system: str = "",
    ) -> str:
        if not self._client:
            raise RuntimeError(f"{self._provider_name} client not initialized")

        messages: list[dict[str, Any]] = []
        if system:
            messages.append({"role": "system", "content": system})

        user_content: list[Any] = []
        if screenshot.base64_image:
            user_content.append({
                "type": "image_url",
                "image_url": {
                    "url": f"data:{screenshot.media_type};base64,{screenshot.base64_image}",
                },
            })
        user_content.append({"type": "text", "text": prompt})
        messages.append({"role": "user", "content": user_content})

        response = self._client.chat.completions.create(
            model=self._model,
            messages=messages,
            max_tokens=2048,
        )
        return response.choices[0].message.content or ""


# ---------------------------------------------------------------------------
# Auto-detection
# ---------------------------------------------------------------------------


def _load_env() -> None:
    """Load .env from owlmind project root if present."""
    try:
        from pathlib import Path

        from dotenv import load_dotenv

        env_file = Path(__file__).parent.parent.parent.parent / ".env"
        if env_file.exists():
            load_dotenv(env_file, override=False)
    except ImportError:
        pass


def build_vision_provider() -> VisionProvider | None:
    """Auto-detect and build the best available vision provider from env."""
    _load_env()

    # 1. Anthropic — best (supports Computer Use), expensive
    key = os.environ.get("ANTHROPIC_API_KEY", "")
    if key:
        model = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-4-6")
        p = AnthropicVisionProvider(api_key=key, model=model)
        if p.is_available():
            logger.info("Vision provider: %s", p.name)
            return p

    # 2. Qwen-VL-Max — cheap Chinese vision model (OpenAI-compatible)
    key = os.environ.get("QWEN_API_KEY", "") or os.environ.get("DASHSCOPE_API_KEY", "")
    if key:
        model = os.environ.get("QWEN_MODEL", "qwen-vl-max")
        p = OpenAICompatibleVisionProvider(
            api_key=key,
            model=model,
            base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
            provider_name="qwen",
        )
        if p.is_available():
            logger.info("Vision provider: %s", p.name)
            return p

    # 3. OpenAI GPT-4o — if OPENAI_BASE_URL is not DeepSeek (DeepSeek = text only)
    key = os.environ.get("OPENAI_API_KEY", "")
    base = os.environ.get("OPENAI_BASE_URL", "")
    if key and "deepseek" not in base.lower():
        model = os.environ.get("OPENAI_MODEL", "gpt-4o")
        p = OpenAICompatibleVisionProvider(
            api_key=key,
            model=model,
            base_url=base,
            provider_name="openai",
        )
        if p.is_available():
            logger.info("Vision provider: %s", p.name)
            return p

    logger.warning(
        "No vision provider available. "
        "Set ANTHROPIC_API_KEY, QWEN_API_KEY, or OPENAI_API_KEY (non-DeepSeek)."
    )
    return None


def list_providers() -> list[dict[str, str]]:
    """Return all provider configs with availability status."""
    _load_env()
    results = []

    # Anthropic
    key = os.environ.get("ANTHROPIC_API_KEY", "")
    model = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-4-6")
    sdk_ok = True
    try:
        import anthropic  # noqa: F401
    except ImportError:
        sdk_ok = False
    if key and sdk_ok:
        status = "available"
    elif not key:
        status = "no key (set ANTHROPIC_API_KEY)"
    else:
        status = "sdk missing (pip install anthropic)"
    results.append({
        "provider": "Anthropic Claude",
        "model": model,
        "status": status,
        "features": "vision + computer_use (click/type/scroll)",
        "cost": "$3/MTok input",
        "env_var": "ANTHROPIC_API_KEY",
    })

    # Qwen-VL
    key = os.environ.get("QWEN_API_KEY", "") or os.environ.get("DASHSCOPE_API_KEY", "")
    model = os.environ.get("QWEN_MODEL", "qwen-vl-max")
    results.append({
        "provider": "Qwen-VL-Max (Alibaba)",
        "model": model,
        "status": "available" if key else "no key (set QWEN_API_KEY)",
        "features": "vision (image understanding)",
        "cost": "~$0.003/image",
        "env_var": "QWEN_API_KEY",
    })

    # OpenAI / DeepSeek
    key = os.environ.get("OPENAI_API_KEY", "")
    base = os.environ.get("OPENAI_BASE_URL", "")
    model = os.environ.get("OPENAI_MODEL", "gpt-4o")
    is_deepseek = "deepseek" in base.lower()
    if is_deepseek:
        status = "text only (DeepSeek has no vision)"
        features = "text only"
        cost = "$0.55/MTok"
    elif key:
        status = "available"
        features = "vision"
        cost = "$2.5/MTok input"
    else:
        status = "no key"
        features = "vision"
        cost = "$2.5/MTok input"
    results.append({
        "provider": "OpenAI GPT-4o" if not is_deepseek else "DeepSeek (active, text only)",
        "model": model,
        "status": status,
        "features": features,
        "cost": cost,
        "env_var": "OPENAI_API_KEY",
    })

    return results
