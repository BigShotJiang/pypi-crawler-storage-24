"""Pydantic models for the Vision / Computer Use module."""

from __future__ import annotations

from pydantic import BaseModel


class VisionConfig(BaseModel):
    """Claude Computer Use configuration."""

    api_key: str = ""
    model: str = "claude-sonnet-4-5-20250929"
    max_tokens: int = 4096
    timeout_sec: int = 120
    screen_width: int = 1280
    screen_height: int = 800
    enabled: bool = False

    @property
    def is_enabled(self) -> bool:
        return self.enabled and bool(self.api_key)


class ScreenshotResult(BaseModel):
    """Captured screenshot encoded as base64 PNG."""

    base64_image: str
    width: int
    height: int
    timestamp: float
    media_type: str = "image/png"


class ComputerAction(BaseModel):
    """A single computer-control action requested by Claude."""

    action_type: str  # screenshot, left_click, right_click, double_click, triple_click, type, key, scroll, move, left_mouse_down, left_mouse_up, wait
    coordinate: list[int] | None = None
    text: str | None = None
    key: str | None = None
    scroll_direction: str | None = None  # up, down, left, right
    scroll_distance: int | None = None
    duration: int | None = None  # ms for wait


class VisionStep(BaseModel):
    """One iteration of the Computer Use feedback loop."""

    step_num: int
    screenshot: ScreenshotResult | None = None
    claude_thinking: str = ""
    action: ComputerAction | None = None
    action_result: str = ""
    is_final: bool = False
    final_message: str = ""
