"""macOS-specific automation via osascript, open(1), and system APIs.

Provides native app control without requiring screen coordinates —
use AppleScript for Telegram, Safari, Mail, and any macOS app.
"""

from __future__ import annotations

import logging
import subprocess

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Core osascript helpers
# ---------------------------------------------------------------------------


def run_applescript(script: str, timeout: int = 15) -> str:
    """Run an AppleScript snippet and return stdout. Empty string on error."""
    try:
        result = subprocess.run(
            ["osascript", "-e", script],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        if result.returncode != 0:
            logger.debug("AppleScript stderr: %s", result.stderr.strip())
        return result.stdout.strip()
    except subprocess.TimeoutExpired:
        logger.warning("AppleScript timed out after %ds", timeout)
        return ""
    except Exception as e:
        logger.warning("AppleScript failed: %s", e)
        return ""


def run_applescript_file(path: str, timeout: int = 30) -> str:
    """Run an AppleScript file (.scpt or .applescript)."""
    try:
        result = subprocess.run(
            ["osascript", path],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return result.stdout.strip()
    except Exception as e:
        logger.warning("AppleScript file failed: %s", e)
        return ""


# ---------------------------------------------------------------------------
# Application control
# ---------------------------------------------------------------------------


def activate_app(app_name: str) -> bool:
    """Bring an application to the foreground."""
    run_applescript(f'tell application "{app_name}" to activate')
    return True


def quit_app(app_name: str) -> bool:
    """Quit an application gracefully."""
    result = run_applescript(f'tell application "{app_name}" to quit')
    return result is not None


def open_app(app_name: str) -> bool:
    """Launch an application (or bring it to front if already running)."""
    try:
        subprocess.run(["open", "-a", app_name], timeout=5, check=False)
        return True
    except Exception as e:
        logger.warning("Failed to open %s: %s", app_name, e)
        return False


def is_app_running(app_name: str) -> bool:
    """Return True if the named application is currently running."""
    script = (
        f'tell application "System Events" to '
        f'(name of every process) contains "{app_name}"'
    )
    result = run_applescript(script)
    return result.lower() == "true"


def get_running_apps() -> list[str]:
    """Return names of all visible (non-background) running applications."""
    script = (
        'tell application "System Events" to '
        'get name of every process whose background only is false'
    )
    output = run_applescript(script)
    if output:
        return [a.strip() for a in output.split(",")]
    return []


def get_frontmost_app() -> str:
    """Return the name of the currently focused application."""
    return run_applescript(
        'tell application "System Events" to get name of first process '
        'whose frontmost is true'
    )


# ---------------------------------------------------------------------------
# Screen / display info
# ---------------------------------------------------------------------------


def get_screen_size() -> tuple[int, int]:
    """Return (width, height) of the primary display in logical pixels."""
    # Try pyautogui first (handles Retina scaling correctly)
    try:
        import pyautogui

        w, h = pyautogui.size()
        return int(w), int(h)
    except Exception:
        pass

    # Fallback via NSScreen through Swift one-liner
    try:
        result = subprocess.run(
            [
                "swift",
                "-e",
                'import Cocoa; let s=NSScreen.main!.frame; print("\\(Int(s.width))x\\(Int(s.height))")',
            ],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0 and "x" in result.stdout:
            w, h = result.stdout.strip().split("x")
            return int(w), int(h)
    except Exception:
        pass

    # Last resort: Finder desktop bounds
    output = run_applescript(
        'tell application "Finder" to get bounds of window of desktop'
    )
    if output:
        parts = [p.strip() for p in output.split(",")]
        if len(parts) == 4:
            return int(parts[2]), int(parts[3])

    return 1440, 900  # safe MacBook default


# ---------------------------------------------------------------------------
# Keyboard via System Events
# ---------------------------------------------------------------------------


def send_keystroke(keys: str, modifiers: list[str] | None = None) -> bool:
    """Send keystroke optionally with modifiers (command, option, shift, control)."""
    if modifiers:
        mod_str = " & ".join(f'"{m} down"' for m in modifiers)
        script = f'tell application "System Events" to keystroke "{keys}" using {{{mod_str}}}'
    else:
        script = f'tell application "System Events" to keystroke "{keys}"'
    run_applescript(script)
    return True


def send_key_code(code: int, modifiers: list[str] | None = None) -> bool:
    """Send a key by its macOS key code (e.g. 36=Return, 53=Escape)."""
    if modifiers:
        mod_str = " & ".join(f'"{m} down"' for m in modifiers)
        script = f'tell application "System Events" to key code {code} using {{{mod_str}}}'
    else:
        script = f'tell application "System Events" to key code {code}'
    run_applescript(script)
    return True


def press_return() -> bool:
    return send_key_code(36)


def press_escape() -> bool:
    return send_key_code(53)


def press_tab() -> bool:
    return send_key_code(48)


# ---------------------------------------------------------------------------
# Telegram-specific automation
# ---------------------------------------------------------------------------


def telegram_search_contact(query: str) -> bool:
    """Open Telegram search and type a contact/chat name."""
    script = f"""
tell application "Telegram" to activate
delay 0.5
tell application "System Events"
    tell process "Telegram"
        keystroke "k" using command down
        delay 0.4
        keystroke "{query}"
        delay 0.8
    end tell
end tell
"""
    run_applescript(script)
    return True


def telegram_open_chat(contact: str) -> bool:
    """Search for a contact in Telegram and open their chat."""
    script = f"""
tell application "Telegram" to activate
delay 0.5
tell application "System Events"
    tell process "Telegram"
        -- Cmd+K opens search
        keystroke "k" using command down
        delay 0.4
        -- Type contact name
        keystroke "{contact}"
        delay 1.0
        -- Press Enter to open first result
        key code 36
        delay 0.5
    end tell
end tell
"""
    run_applescript(script)
    return True


def telegram_send_message(contact: str, message: str) -> bool:
    """Open a Telegram chat and send a message.

    Opens Telegram, searches for the contact, selects the first result,
    types the message, and presses Enter to send.
    """
    # Escape double-quotes in the message for AppleScript safety
    safe_contact = contact.replace('"', '\\"')
    safe_message = message.replace('"', '\\"')

    script = f"""
tell application "Telegram" to activate
delay 0.6
tell application "System Events"
    tell process "Telegram"
        -- Open search (Cmd+K)
        keystroke "k" using command down
        delay 0.5
        -- Clear any existing text and type contact name
        key code 0 using command down  -- Cmd+A (select all)
        keystroke "{safe_contact}"
        delay 1.2
        -- Select first search result
        key code 36
        delay 0.6
        -- Type message
        keystroke "{safe_message}"
        delay 0.3
        -- Send (Enter)
        key code 36
    end tell
end tell
"""
    run_applescript(script)
    return True


def telegram_get_last_messages(n: int = 5) -> str:
    """Attempt to read the last N messages from the visible Telegram window (best effort)."""
    # Telegram doesn't expose text via accessibility in all versions,
    # so we fall back to a screenshot-based approach if this returns empty.
    script = f"""
tell application "System Events"
    tell process "Telegram"
        set allText to ""
        try
            set msgs to (every static text of window 1 whose value is not "")
            set cnt to 0
            repeat with m in msgs
                if cnt >= {n} then exit repeat
                set allText to allText & value of m & linefeed
                set cnt to cnt + 1
            end repeat
        end try
        return allText
    end tell
end tell
"""
    return run_applescript(script)


# ---------------------------------------------------------------------------
# Safari / browser helpers
# ---------------------------------------------------------------------------


def safari_open_url(url: str) -> bool:
    """Open a URL in Safari."""
    script = f"""
tell application "Safari"
    activate
    open location "{url}"
end tell
"""
    run_applescript(script)
    return True


def safari_get_page_text() -> str:
    """Extract visible text from the current Safari tab via JavaScript."""
    script = """
tell application "Safari"
    set t to do JavaScript "document.body ? document.body.innerText : ''" in current tab of window 1
    return t
end tell
"""
    return run_applescript(script)


def chrome_open_url(url: str) -> bool:
    """Open a URL in Google Chrome."""
    script = f"""
tell application "Google Chrome"
    activate
    open location "{url}"
end tell
"""
    run_applescript(script)
    return True


# ---------------------------------------------------------------------------
# Clipboard
# ---------------------------------------------------------------------------


def get_clipboard() -> str:
    """Return current clipboard contents as text."""
    try:
        result = subprocess.run(["pbpaste"], capture_output=True, text=True, timeout=5)
        return result.stdout
    except Exception:
        return ""


def set_clipboard(text: str) -> bool:
    """Put text on the clipboard."""
    try:
        subprocess.run(["pbcopy"], input=text, text=True, timeout=5, check=True)
        return True
    except Exception:
        return False


def paste_text(text: str) -> bool:
    """Put text on clipboard and paste it into the focused element (Cmd+V)."""
    set_clipboard(text)
    run_applescript(
        'tell application "System Events" to keystroke "v" using command down'
    )
    return True


# ---------------------------------------------------------------------------
# Notifications
# ---------------------------------------------------------------------------


def show_notification(title: str, message: str, sound: str = "default") -> None:
    """Show a macOS notification banner."""
    safe_title = title.replace('"', '\\"')
    safe_msg = message.replace('"', '\\"')
    run_applescript(
        f'display notification "{safe_msg}" with title "{safe_title}" sound name "{sound}"'
    )
