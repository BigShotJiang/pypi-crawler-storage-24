"""Computer action executor using pyautogui."""

from __future__ import annotations

import logging
import time

from owlmind.vision.models import ComputerAction

logger = logging.getLogger(__name__)

_PYAUTOGUI_AVAILABLE = False
try:
    import pyautogui

    pyautogui.FAILSAFE = True  # move to corner to abort
    pyautogui.PAUSE = 0.1
    _PYAUTOGUI_AVAILABLE = True
except ImportError:
    pass


def is_actions_available() -> bool:
    """Return True if pyautogui is installed and action execution is possible."""
    return _PYAUTOGUI_AVAILABLE


class ActionExecutor:
    """Executes computer control actions using pyautogui."""

    def __init__(self, pause_between: float = 0.1) -> None:
        self._pause = pause_between

    def execute(self, action: ComputerAction) -> str:
        """Execute a computer action and return a result description."""
        if not _PYAUTOGUI_AVAILABLE:
            msg = (
                "Computer actions require pyautogui. "
                "Install with: pip install 'owlmind[vision]'"
            )
            raise ImportError(msg)

        atype = action.action_type.lower()

        if atype == "screenshot":
            return "screenshot"

        elif atype == "left_click":
            if not action.coordinate:
                msg = "left_click requires coordinate"
                raise ValueError(msg)
            pyautogui.click(action.coordinate[0], action.coordinate[1])
            return f"clicked at {action.coordinate}"

        elif atype == "right_click":
            if not action.coordinate:
                msg = "right_click requires coordinate"
                raise ValueError(msg)
            pyautogui.rightClick(action.coordinate[0], action.coordinate[1])
            return f"right-clicked at {action.coordinate}"

        elif atype == "double_click":
            if not action.coordinate:
                msg = "double_click requires coordinate"
                raise ValueError(msg)
            pyautogui.doubleClick(action.coordinate[0], action.coordinate[1])
            return f"double-clicked at {action.coordinate}"

        elif atype == "triple_click":
            if not action.coordinate:
                msg = "triple_click requires coordinate"
                raise ValueError(msg)
            pyautogui.tripleClick(action.coordinate[0], action.coordinate[1])
            return f"triple-clicked at {action.coordinate}"

        elif atype == "move":
            if not action.coordinate:
                msg = "move requires coordinate"
                raise ValueError(msg)
            pyautogui.moveTo(action.coordinate[0], action.coordinate[1])
            return f"moved to {action.coordinate}"

        elif atype == "type":
            if not action.text:
                msg = "type requires text"
                raise ValueError(msg)
            pyautogui.write(action.text, interval=0.02)
            return f"typed: {action.text[:50]}..."

        elif atype == "key":
            if not action.key:
                msg = "key requires key name"
                raise ValueError(msg)
            pyautogui.hotkey(*action.key.split("+"))
            return f"pressed key: {action.key}"

        elif atype == "scroll":
            direction = action.scroll_direction or "down"
            distance = action.scroll_distance or 3
            coord = action.coordinate
            if direction == "down":
                pyautogui.scroll(
                    -distance,
                    x=coord[0] if coord else None,
                    y=coord[1] if coord else None,
                )
            elif direction == "up":
                pyautogui.scroll(
                    distance,
                    x=coord[0] if coord else None,
                    y=coord[1] if coord else None,
                )
            else:
                pyautogui.hscroll(-distance if direction == "right" else distance)
            return f"scrolled {direction} by {distance}"

        elif atype == "left_mouse_down":
            if action.coordinate:
                pyautogui.moveTo(action.coordinate[0], action.coordinate[1])
            pyautogui.mouseDown(button="left")
            return "mouse button down"

        elif atype == "left_mouse_up":
            if action.coordinate:
                pyautogui.moveTo(action.coordinate[0], action.coordinate[1])
            pyautogui.mouseUp(button="left")
            return "mouse button up"

        elif atype == "wait":
            duration_ms = action.duration or 1000
            time.sleep(duration_ms / 1000.0)
            return f"waited {duration_ms}ms"

        else:
            msg = f"Unknown action type: {atype}"
            raise ValueError(msg)
