"""Claude Computer Use driver — screenshot → Claude → action feedback loop."""

from __future__ import annotations

import logging
import time
from collections.abc import Callable
from typing import Any

from owlmind.vision.actions import ActionExecutor, is_actions_available
from owlmind.vision.models import ComputerAction, ScreenshotResult, VisionConfig, VisionStep
from owlmind.vision.screenshot import capture_screenshot, is_screenshot_available

logger = logging.getLogger(__name__)

_ANTHROPIC_AVAILABLE = False
try:
    import anthropic

    _ANTHROPIC_AVAILABLE = True
except ImportError:
    pass


def is_vision_driver_available() -> bool:
    """Return True if the anthropic SDK is installed."""
    return _ANTHROPIC_AVAILABLE


class ComputerUseDriver:
    """Runs a Computer Use feedback loop: screenshot → Claude → action → repeat."""

    COMPUTER_TOOL = {
        "type": "computer_20250124",
        "name": "computer",
    }

    def __init__(self, config: VisionConfig) -> None:
        self._config = config
        self._client: Any = None
        self._executor = ActionExecutor()

        if _ANTHROPIC_AVAILABLE and config.api_key:
            self._client = anthropic.Anthropic(
                api_key=config.api_key,
                timeout=config.timeout_sec,
            )

    @property
    def name(self) -> str:
        return "computer_use"

    def analyze_image(
        self,
        screenshot: ScreenshotResult,
        question: str = "Describe what you see.",
    ) -> str:
        """Send a screenshot to Claude and get a text description."""
        if self._client is None:
            msg = "Anthropic client not initialized. Set api_key in VisionConfig."
            raise RuntimeError(msg)

        response = self._client.messages.create(
            model=self._config.model,
            max_tokens=1024,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": screenshot.media_type,
                                "data": screenshot.base64_image,
                            },
                        },
                        {"type": "text", "text": question},
                    ],
                }
            ],
        )
        for block in response.content:
            if getattr(block, "type", "") == "text":
                return block.text
        return ""

    def run_task(
        self,
        task: str,
        max_steps: int = 20,
        on_step: Callable[[VisionStep], None] | None = None,
    ) -> list[VisionStep]:
        """Run a task using the Computer Use feedback loop.

        1. Take screenshot
        2. Send to Claude with computer tool
        3. If Claude calls computer tool → execute action → loop
        4. If Claude returns only text → done
        """
        if self._client is None:
            msg = "Anthropic client not initialized. Set api_key in VisionConfig."
            raise RuntimeError(msg)

        steps: list[VisionStep] = []
        messages: list[dict[str, Any]] = []

        # Initial user message
        messages.append({"role": "user", "content": task})

        for step_num in range(1, max_steps + 1):
            logger.debug("Computer Use step %d/%d", step_num, max_steps)

            # Take screenshot
            screenshot: ScreenshotResult | None = None
            if is_screenshot_available():
                try:
                    screenshot = capture_screenshot(
                        self._config.screen_width, self._config.screen_height
                    )
                except Exception as e:
                    logger.warning("Screenshot failed: %s", e)

            step = VisionStep(step_num=step_num, screenshot=screenshot)

            # After step 1, inject the new screenshot as a tool_result
            if screenshot and step_num > 1:
                prev_tool_use_id = steps[-1].action_result if steps else ""
                messages.append({
                    "role": "user",
                    "content": [
                        {
                            "type": "tool_result",
                            "tool_use_id": prev_tool_use_id,
                            "content": [
                                {
                                    "type": "image",
                                    "source": {
                                        "type": "base64",
                                        "media_type": screenshot.media_type,
                                        "data": screenshot.base64_image,
                                    },
                                }
                            ],
                        }
                    ],
                })

            # Build tool definition with current display dimensions
            tool_def = {
                **self.COMPUTER_TOOL,
                "display_width_px": self._config.screen_width,
                "display_height_px": self._config.screen_height,
            }

            response = self._client.beta.messages.create(
                model=self._config.model,
                max_tokens=self._config.max_tokens,
                tools=[tool_def],
                messages=messages,
                betas=["computer-use-2025-01-24"],
            )

            # Parse response blocks
            thinking = ""
            action: ComputerAction | None = None
            is_final = True
            tool_use_id = ""

            for block in response.content:
                btype = getattr(block, "type", "")
                if btype == "text":
                    thinking = block.text
                elif btype == "tool_use" and getattr(block, "name", "") == "computer":
                    is_final = False
                    tool_use_id = block.id
                    inp = block.input or {}
                    action = ComputerAction(
                        action_type=inp.get("action", "screenshot"),
                        coordinate=inp.get("coordinate"),
                        text=inp.get("text"),
                        key=inp.get("key"),
                        scroll_direction=inp.get("scroll_direction"),
                        scroll_distance=inp.get("scroll_distance"),
                        duration=inp.get("duration"),
                    )

            step.claude_thinking = thinking
            step.action = action
            step.is_final = is_final
            step.final_message = thinking if is_final else ""

            # Append assistant turn to conversation history
            messages.append({"role": "assistant", "content": response.content})

            # Execute the requested action
            action_result = ""
            if action and not is_final:
                if action.action_type == "screenshot":
                    # The next iteration will capture a fresh screenshot
                    action_result = "screenshot taken"
                elif is_actions_available():
                    try:
                        action_result = self._executor.execute(action)
                    except Exception as e:
                        action_result = f"action failed: {e}"
                        logger.warning("Action execution failed: %s", e)
                else:
                    action_result = (
                        f"action skipped (pyautogui not available): {action.action_type}"
                    )
                    logger.warning(
                        "pyautogui not available, skipping action: %s", action.action_type
                    )

            # Store tool_use_id in action_result so the next iteration can reference it
            step.action_result = action_result or tool_use_id

            steps.append(step)
            if on_step:
                on_step(step)

            if is_final:
                logger.debug("Computer Use task completed after %d steps", step_num)
                break

            # Brief pause between steps to let the UI settle
            time.sleep(0.5)

        return steps
