"""Screenshot capture utilities for the Vision module."""

from __future__ import annotations

import base64
import io
import logging
import time

from owlmind.vision.models import ScreenshotResult

logger = logging.getLogger(__name__)

_PIL_AVAILABLE = False
try:
    from PIL import Image, ImageGrab

    _PIL_AVAILABLE = True
except ImportError:
    pass

_PYAUTOGUI_AVAILABLE = False
try:
    import pyautogui

    _PYAUTOGUI_AVAILABLE = True
except ImportError:
    pass


def is_screenshot_available() -> bool:
    """Return True if at least one screenshot backend is installed."""
    return _PIL_AVAILABLE or _PYAUTOGUI_AVAILABLE


def capture_screenshot(width: int = 1280, height: int = 800) -> ScreenshotResult:
    """Capture a screenshot and return as base64 PNG."""
    if not (_PIL_AVAILABLE or _PYAUTOGUI_AVAILABLE):
        msg = (
            "Screenshot capture requires pillow or pyautogui. "
            "Install with: pip install 'owlmind[vision]'"
        )
        raise ImportError(msg)

    image_bytes = _capture_raw()
    b64 = base64.standard_b64encode(image_bytes).decode()

    # Try to get actual dimensions
    actual_width, actual_height = width, height
    if _PIL_AVAILABLE:
        try:
            img = Image.open(io.BytesIO(image_bytes))
            actual_width, actual_height = img.size
        except Exception:
            pass

    return ScreenshotResult(
        base64_image=b64,
        width=actual_width,
        height=actual_height,
        timestamp=time.time(),
        media_type="image/png",
    )


def _capture_raw() -> bytes:
    """Capture screenshot and return raw PNG bytes."""
    if _PIL_AVAILABLE:
        try:
            img = ImageGrab.grab()
            buf = io.BytesIO()
            img.save(buf, format="PNG")
            return buf.getvalue()
        except Exception as e:
            logger.warning("PIL ImageGrab failed: %s", e)

    if _PYAUTOGUI_AVAILABLE:
        try:
            img = pyautogui.screenshot()
            buf = io.BytesIO()
            img.save(buf, format="PNG")
            return buf.getvalue()
        except Exception as e:
            logger.warning("pyautogui screenshot failed: %s", e)

    msg = "All screenshot backends failed"
    raise RuntimeError(msg)


def encode_image_file(path: str) -> ScreenshotResult:
    """Load an image file and encode it as a ScreenshotResult."""
    import os

    if not os.path.exists(path):
        msg = f"Image file not found: {path}"
        raise FileNotFoundError(msg)

    with open(path, "rb") as f:
        image_bytes = f.read()

    b64 = base64.standard_b64encode(image_bytes).decode()

    # Detect media type from extension
    media_type = "image/png"
    if path.lower().endswith((".jpg", ".jpeg")):
        media_type = "image/jpeg"
    elif path.lower().endswith(".gif"):
        media_type = "image/gif"
    elif path.lower().endswith(".webp"):
        media_type = "image/webp"

    width, height = 1280, 800
    if _PIL_AVAILABLE:
        try:
            img = Image.open(io.BytesIO(image_bytes))
            width, height = img.size
        except Exception:
            pass

    return ScreenshotResult(
        base64_image=b64,
        width=width,
        height=height,
        timestamp=time.time(),
        media_type=media_type,
    )
