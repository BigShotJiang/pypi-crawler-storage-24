"""Vision / Computer Use module for OwlMind.

Provides:
  • Multi-provider vision (Anthropic, Qwen-VL-Max, OpenAI GPT-4o)
  • Smart agent with planning + verification loop
  • macOS-native automation (osascript, Telegram, Safari)
  • Screenshot capture and analysis
"""

from __future__ import annotations

from owlmind.vision.actions import ActionExecutor, is_actions_available
from owlmind.vision.driver import ComputerUseDriver
from owlmind.vision.macos import (
    activate_app,
    get_running_apps,
    get_screen_size,
    open_app,
    run_applescript,
    telegram_send_message,
)
from owlmind.vision.models import ComputerAction, ScreenshotResult, VisionConfig, VisionStep
from owlmind.vision.multimodal import (
    ImageAnalyzer,
    MediaAnalysisResult,
    MultimodalAnalyzer,
    PDFAnalyzer,
    VideoAnalyzer,
    analyze_file,
    analyze_image,
    analyze_pdf,
    analyze_video,
)
from owlmind.vision.providers import (
    AnthropicVisionProvider,
    OpenAICompatibleVisionProvider,
    VisionProvider,
    build_vision_provider,
    list_providers,
)
from owlmind.vision.screen_monitor import (
    MonitorConfig,
    ScreenInsight,
    ScreenMonitor,
)
from owlmind.vision.screenshot import capture_screenshot, is_screenshot_available
from owlmind.vision.smart_driver import (
    AgentResult,
    AgentStep,
    AnthropicComputerAgent,
    SmartComputerAgent,
    build_agent,
)


def is_vision_available() -> bool:
    """Return True if at least one vision provider is configured."""
    # Screenshot is always usable on macOS without any API key
    if is_screenshot_available():
        return True
    # Any vision provider SDK installed
    try:
        import anthropic  # type: ignore[import-untyped]  # noqa: F401
        return True
    except ImportError:
        pass
    try:
        import openai  # type: ignore[import-untyped]  # noqa: F401
        return True
    except ImportError:
        pass
    return False


__all__ = [
    # Original
    "ComputerUseDriver",
    "VisionConfig",
    "ScreenshotResult",
    "ComputerAction",
    "VisionStep",
    "capture_screenshot",
    "ActionExecutor",
    "is_vision_available",
    "is_screenshot_available",
    "is_actions_available",
    # New providers
    "VisionProvider",
    "AnthropicVisionProvider",
    "OpenAICompatibleVisionProvider",
    "build_vision_provider",
    "list_providers",
    # New smart agent
    "SmartComputerAgent",
    "AnthropicComputerAgent",
    "AgentStep",
    "AgentResult",
    "build_agent",
    # macOS helpers
    "run_applescript",
    "activate_app",
    "open_app",
    "get_running_apps",
    "get_screen_size",
    "telegram_send_message",
    # Multimodal
    "MultimodalAnalyzer",
    "PDFAnalyzer",
    "VideoAnalyzer",
    "ImageAnalyzer",
    "MediaAnalysisResult",
    "analyze_file",
    "analyze_pdf",
    "analyze_video",
    "analyze_image",
    # Screen monitor
    "ScreenMonitor",
    "MonitorConfig",
    "ScreenInsight",
]
