"""SmartComputerAgent — multi-provider vision agent with planning + verification.

Architecture:
  1. PLAN   — ask LLM to decompose the task into atomic steps
  2. EXECUTE — for each step: screenshot → vision model → action → execute
  3. VERIFY  — after each action check if screen changed (retry if not)
  4. RECOVER — if a step fails repeatedly, ask vision model for alternative approach
  5. CONFIRM — final screenshot + "is task complete?" check

Supports:
  • Anthropic Computer Use (best, click/type/scroll via tool API)
  • Qwen-VL-Max / GPT-4o (vision → JSON action → pyautogui)
  • macOS AppleScript (Telegram, Safari, etc. — no coordinates needed)
"""

from __future__ import annotations

import contextlib
import json
import logging
import re
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from owlmind.vision.actions import ActionExecutor, is_actions_available
from owlmind.vision.macos import (
    activate_app,
    get_running_apps,
    get_screen_size,
    open_app,
    show_notification,
)
from owlmind.vision.models import ComputerAction, ScreenshotResult, VisionStep
from owlmind.vision.providers import VisionProvider
from owlmind.vision.screenshot import capture_screenshot, is_screenshot_available

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------

_PLANNER_SYSTEM = """You are an expert macOS automation planner.
Given a user task, decompose it into minimal atomic steps.

Return ONLY a valid JSON array. Each step has:
  {
    "step": <int>,
    "description": "<what this step does>",
    "type": "<app|keyboard|vision|applescript>",
    "target": "<app name, key combo, or AppleScript snippet>",
    "optional": <true|false>
  }

Types:
  "app"          → open/activate an application (target = app name)
  "keyboard"     → send keyboard shortcut (target = "cmd+k")
  "applescript"  → run custom AppleScript (target = script text)
  "vision"       → take screenshot and decide action visually

Keep the plan minimal and concrete. Prefer "applescript" for Telegram, Mail,
Safari since it's more reliable than pixel clicking.
"""

_VISION_SYSTEM = """You are an expert macOS computer operator.
Analyze the screenshot and decide the single best next action.

Respond with ONLY a JSON object — no markdown, no explanation:
  {"action": "left_click",  "x": 123, "y": 456, "reason": "..."}
  {"action": "right_click", "x": 123, "y": 456, "reason": "..."}
  {"action": "double_click","x": 123, "y": 456, "reason": "..."}
  {"action": "type",        "text": "hello",     "reason": "..."}
  {"action": "key",         "key": "cmd+k",      "reason": "..."}
  {"action": "scroll",      "x": 640, "y": 400, "direction": "down", "amount": 3}
  {"action": "wait",        "ms": 800,           "reason": "..."}
  {"action": "done",        "result": "...",     "reason": "..."}
  {"action": "failed",      "reason": "..."}

Rules:
  - Coordinates are in logical pixels; origin is top-left (0,0).
  - Only output ONE action per response.
  - Use "done" when the task is fully complete.
  - Use "failed" only if genuinely impossible.
"""

_VERIFY_SYSTEM = """You compare two screenshots to determine if an action had the intended effect.
Respond with ONLY JSON: {"changed": true|false, "summary": "<one sentence>"}
"""

_CONFIRM_SYSTEM = """You verify whether a task has been completed successfully.
Respond with ONLY JSON: {"success": true|false, "message": "<explanation>"}
"""


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------


@dataclass
class AgentStep:
    step_num: int
    description: str
    step_type: str = "vision"
    action: ComputerAction | None = None
    screenshot_before: ScreenshotResult | None = None
    screenshot_after: ScreenshotResult | None = None
    thinking: str = ""
    result: str = ""
    success: bool = False
    retries: int = 0


@dataclass
class AgentResult:
    task: str
    steps: list[AgentStep] = field(default_factory=list)
    success: bool = False
    final_message: str = ""
    total_time_ms: int = 0
    provider_used: str = ""

    @property
    def step_count(self) -> int:
        return len(self.steps)

    @property
    def successful_steps(self) -> int:
        return sum(1 for s in self.steps if s.success)


# ---------------------------------------------------------------------------
# Main agent
# ---------------------------------------------------------------------------


class SmartComputerAgent:
    """Multi-provider vision agent: plan → execute → verify → recover → confirm."""

    def __init__(
        self,
        provider: VisionProvider,
        max_retries: int = 3,
        step_delay: float = 0.7,
        verify_actions: bool = True,
        use_applescript: bool = True,
    ) -> None:
        self._provider = provider
        self._max_retries = max_retries
        self._step_delay = step_delay
        self._verify = verify_actions
        self._use_as = use_applescript
        self._executor = ActionExecutor()
        self._screen_w, self._screen_h = get_screen_size()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run(
        self,
        task: str,
        max_steps: int = 40,
        on_step: Callable[[AgentStep], None] | None = None,
    ) -> AgentResult:
        """Full pipeline: plan → execute each step → confirm completion."""
        t0 = time.time()
        result = AgentResult(task=task, provider_used=self._provider.name)

        # 1. Plan
        plan = self._plan(task)
        logger.info("Plan generated: %d steps", len(plan))

        # 2. Execute
        for step_num, planned in enumerate(plan[:max_steps], start=1):
            step = AgentStep(
                step_num=step_num,
                description=planned.get("description", f"Step {step_num}"),
                step_type=planned.get("type", "vision"),
            )
            self._execute_step(step, planned, task)
            result.steps.append(step)

            if on_step:
                on_step(step)

            if not step.success:
                # Attempt vision-based recovery
                recovered = self._recover(step, task, result.steps)
                if not recovered and not planned.get("optional", False):
                    result.final_message = (
                        f"Failed at step {step_num}: {step.result}"
                    )
                    result.total_time_ms = int((time.time() - t0) * 1000)
                    return result

            time.sleep(self._step_delay)

        # 3. Confirm
        confirmation = self._confirm(task)
        result.success = confirmation.get("success", False)
        result.final_message = confirmation.get("message", "")
        result.total_time_ms = int((time.time() - t0) * 1000)

        if result.success:
            show_notification("OwlMind", f"Task done: {task[:60]}")

        return result

    def run_freeform(
        self,
        task: str,
        max_steps: int = 40,
        on_step: Callable[[AgentStep], None] | None = None,
    ) -> AgentResult:
        """Pure vision loop without pre-planning — faster for simple tasks."""
        t0 = time.time()
        result = AgentResult(task=task, provider_used=self._provider.name)

        context = (
            f"Task: {task}\n\n"
            "Analyze the screen and return the next JSON action."
        )

        for step_num in range(1, max_steps + 1):
            step = AgentStep(step_num=step_num, description=f"Step {step_num}")

            # Screenshot
            if is_screenshot_available():
                try:
                    step.screenshot_before = capture_screenshot(
                        self._screen_w, self._screen_h
                    )
                except Exception as e:
                    logger.warning("Screenshot failed: %s", e)

            # Ask vision model
            if step.screenshot_before:
                response = self._provider.analyze(
                    step.screenshot_before,
                    context,
                    system=_VISION_SYSTEM,
                )
            else:
                response = '{"action": "failed", "reason": "cannot take screenshot"}'

            step.thinking = response
            action_data = _parse_json_action(response)

            if not action_data:
                step.result = "Could not parse action"
                result.steps.append(step)
                if on_step:
                    on_step(step)
                continue

            action_type = action_data.get("action", "")

            if action_type == "done":
                step.success = True
                step.result = action_data.get("result", "Task completed")
                result.steps.append(step)
                result.success = True
                result.final_message = step.result
                if on_step:
                    on_step(step)
                break

            if action_type == "failed":
                step.result = action_data.get("reason", "Task failed")
                result.steps.append(step)
                result.final_message = step.result
                if on_step:
                    on_step(step)
                break

            # Execute action
            computer_action = _dict_to_action(action_data)
            if computer_action and is_actions_available():
                try:
                    action_result = self._executor.execute(computer_action)
                    step.action = computer_action
                    step.success = True
                    step.result = action_result
                except Exception as e:
                    step.result = f"Action failed: {e}"

            result.steps.append(step)
            if on_step:
                on_step(step)

            # Update context with what happened
            context = (
                f"Task: {task}\n"
                f"Steps completed: {step_num}\n"
                f"Last action: {action_type} → {step.result}\n"
                "Return next JSON action. Use 'done' when complete."
            )

            time.sleep(self._step_delay)

        result.total_time_ms = int((time.time() - t0) * 1000)
        return result

    # ------------------------------------------------------------------
    # Planning
    # ------------------------------------------------------------------

    def _plan(self, task: str) -> list[dict[str, Any]]:
        """Ask the vision model (with optional screenshot) to produce a step plan."""
        running = get_running_apps()[:12]

        # Check for known patterns and inject smart hints
        hints = _detect_task_hints(task)

        prompt = (
            f"Task: {task}\n\n"
            f"Currently running apps: {', '.join(running)}\n"
            f"{hints}"
            "Create a minimal step-by-step plan. Return JSON array only."
        )

        # Try to include a screenshot for better context
        screenshot = None
        if is_screenshot_available():
            with contextlib.suppress(Exception):
                screenshot = capture_screenshot(self._screen_w, self._screen_h)

        if screenshot:
            response = self._provider.analyze(screenshot, prompt, system=_PLANNER_SYSTEM)
        else:
            response = self._provider.think(prompt, system=_PLANNER_SYSTEM)

        # Extract JSON array
        try:
            match = re.search(r"\[.*?\]", response, re.DOTALL)
            if match:
                plan = json.loads(match.group())
                if isinstance(plan, list) and plan:
                    return plan
        except Exception as e:
            logger.debug("Plan parse error: %s — %s", e, response[:200])

        # Fallback: single vision step
        return [{"step": 1, "description": task, "type": "vision", "optional": False}]

    # ------------------------------------------------------------------
    # Step execution
    # ------------------------------------------------------------------

    def _execute_step(
        self,
        step: AgentStep,
        planned: dict[str, Any],
        task: str,
    ) -> None:
        """Execute one planned step, retrying on failure."""
        stype = planned.get("type", "vision")
        target = planned.get("target", "")

        # --- App activation ---
        if stype == "app":
            if target:
                if is_app_running(target):
                    activate_app(target)
                else:
                    open_app(target)
                time.sleep(0.5)
                step.success = True
                step.result = f"Activated {target}"
            else:
                step.result = "No app target specified"
            return

        # --- Keyboard shortcut ---
        if stype == "keyboard":
            if target and is_actions_available():
                import pyautogui

                keys = [k.strip() for k in target.replace("+", " ").split()]
                pyautogui.hotkey(*keys)
                step.success = True
                step.result = f"Pressed {target}"
            else:
                step.result = "keyboard action unavailable"
            return

        # --- AppleScript ---
        if stype == "applescript" and self._use_as:
            from owlmind.vision.macos import run_applescript

            out = run_applescript(target)
            step.success = True
            step.result = f"AppleScript OK: {out[:80]}"
            return

        # --- Vision-guided action (screenshot → ask → execute) ---
        for attempt in range(self._max_retries):
            step.retries = attempt
            success = self._vision_step(step, task, attempt)
            if success:
                return
            time.sleep(0.4)

        step.result = f"Failed after {self._max_retries} attempts: {step.description}"

    def _vision_step(self, step: AgentStep, task: str, attempt: int) -> bool:
        """Single vision iteration: screenshot → ask provider → execute → verify."""
        if not is_screenshot_available():
            step.result = "Screenshot not available"
            return False

        try:
            step.screenshot_before = capture_screenshot(self._screen_w, self._screen_h)
        except Exception as e:
            step.result = f"Screenshot failed: {e}"
            return False

        prompt = (
            f"Overall task: {task}\n"
            f"Current step ({attempt + 1}/{self._max_retries}): {step.description}\n\n"
            "What action should I take right now? Return ONE JSON action."
        )
        response = self._provider.analyze(
            step.screenshot_before, prompt, system=_VISION_SYSTEM
        )
        step.thinking = response

        action_data = _parse_json_action(response)
        if not action_data:
            step.result = "No parseable action in response"
            return False

        action_type = action_data.get("action", "")

        if action_type == "done":
            step.success = True
            step.result = action_data.get("result", "done")
            return True

        if action_type == "failed":
            step.result = action_data.get("reason", "model reported failure")
            return False

        computer_action = _dict_to_action(action_data)
        if not computer_action:
            step.result = "Could not build action object"
            return False

        step.action = computer_action

        if not is_actions_available():
            step.result = f"pyautogui not available, skipping: {action_type}"
            step.success = True  # soft success
            return True

        try:
            action_result = self._executor.execute(computer_action)
        except Exception as e:
            step.result = f"Execution error: {e}"
            return False

        # Verify the action had an effect
        if self._verify:
            time.sleep(0.5)
            try:
                step.screenshot_after = capture_screenshot(
                    self._screen_w, self._screen_h
                )
                if not _screenshots_differ(
                    step.screenshot_before, step.screenshot_after
                ):
                    logger.debug("Screen unchanged after %s — will retry", action_type)
                    step.result = "Screen unchanged"
                    return False
            except Exception:
                pass  # Can't verify — assume success

        step.success = True
        step.result = action_result
        return True

    # ------------------------------------------------------------------
    # Recovery & Confirmation
    # ------------------------------------------------------------------

    def _recover(self, failed_step: AgentStep, task: str, history: list[AgentStep]) -> bool:
        """Ask vision model for an alternative approach after repeated failure."""
        if not is_screenshot_available():
            return False
        try:
            screenshot = capture_screenshot(self._screen_w, self._screen_h)
        except Exception:
            return False

        recent = "; ".join(s.description for s in history[-4:])
        prompt = (
            f"Task: {task}\n"
            f"Failed step: {failed_step.description}\n"
            f"Error: {failed_step.result}\n"
            f"Previous steps: {recent}\n\n"
            "Suggest ONE alternative recovery action. Return JSON action."
        )
        response = self._provider.analyze(screenshot, prompt, system=_VISION_SYSTEM)
        action_data = _parse_json_action(response)

        if not action_data:
            return False

        atype = action_data.get("action", "")
        if atype in ("done", "failed"):
            return atype == "done"

        computer_action = _dict_to_action(action_data)
        if computer_action and is_actions_available():
            try:
                self._executor.execute(computer_action)
                failed_step.success = True
                failed_step.result = f"Recovered via: {atype}"
                return True
            except Exception:
                pass
        return False

    def _confirm(self, task: str) -> dict[str, Any]:
        """Take a final screenshot and ask whether the task succeeded."""
        if not is_screenshot_available():
            return {"success": True, "message": "Task execution finished"}
        try:
            screenshot = capture_screenshot(self._screen_w, self._screen_h)
        except Exception:
            return {"success": True, "message": "Task execution finished"}

        prompt = (
            f"The task was: {task}\n\n"
            "Looking at the current screen: is the task fully complete? "
            'Return ONLY JSON: {"success": true/false, "message": "..."}'
        )
        response = self._provider.analyze(screenshot, prompt, system=_CONFIRM_SYSTEM)
        try:
            match = re.search(r"\{.*?\}", response, re.DOTALL)
            if match:
                return json.loads(match.group())
        except Exception:
            pass
        # Fallback
        success_hint = any(
            w in response.lower() for w in ("success", "complete", "done", "yes")
        )
        return {"success": success_hint, "message": response[:200]}


# ---------------------------------------------------------------------------
# Anthropic Computer Use loop (native tool API — best quality)
# ---------------------------------------------------------------------------


class AnthropicComputerAgent:
    """Uses Claude's native Computer Use API (beta) for maximum accuracy.

    Falls back to SmartComputerAgent if Anthropic is unavailable.
    """

    COMPUTER_TOOL = {
        "type": "computer_20250124",
        "name": "computer",
    }

    def __init__(self, api_key: str, model: str = "claude-sonnet-4-6") -> None:
        self._api_key = api_key
        self._model = model
        self._client: Any = None
        self._executor = ActionExecutor()
        self._screen_w, self._screen_h = get_screen_size()

        try:
            import anthropic

            self._client = anthropic.Anthropic(api_key=api_key, timeout=120)
        except ImportError:
            logger.warning("anthropic SDK not installed; use SmartComputerAgent instead")

    def is_available(self) -> bool:
        return self._client is not None

    def run(
        self,
        task: str,
        max_steps: int = 40,
        on_step: Callable[[VisionStep], None] | None = None,
    ) -> list[VisionStep]:
        """Run task via Anthropic Computer Use tool loop."""
        if not self._client:
            raise RuntimeError("Anthropic client not initialized")

        steps: list[VisionStep] = []
        messages: list[dict[str, Any]] = [{"role": "user", "content": task}]

        for step_num in range(1, max_steps + 1):
            # Take screenshot
            screenshot: ScreenshotResult | None = None
            if is_screenshot_available():
                try:
                    screenshot = capture_screenshot(self._screen_w, self._screen_h)
                except Exception as e:
                    logger.warning("Screenshot failed: %s", e)

            step = VisionStep(step_num=step_num, screenshot=screenshot)

            # Inject screenshot as tool_result for steps after the first
            if screenshot and step_num > 1 and steps:
                prev_id = steps[-1].action_result or ""
                messages.append({
                    "role": "user",
                    "content": [{
                        "type": "tool_result",
                        "tool_use_id": prev_id,
                        "content": [{
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": screenshot.media_type,
                                "data": screenshot.base64_image,
                            },
                        }],
                    }],
                })

            tool_def = {
                **self.COMPUTER_TOOL,
                "display_width_px": self._screen_w,
                "display_height_px": self._screen_h,
            }

            response = self._client.beta.messages.create(
                model=self._model,
                max_tokens=4096,
                tools=[tool_def],
                messages=messages,
                betas=["computer-use-2025-01-24"],
            )

            thinking = ""
            action: ComputerAction | None = None
            is_final = True
            tool_use_id = ""

            for block in response.content:
                btype = getattr(block, "type", "")
                if btype == "text":
                    thinking = block.text
                elif btype == "tool_use" and getattr(block, "name", "") == "computer":
                    is_final = False
                    tool_use_id = block.id
                    inp = block.input or {}
                    action = ComputerAction(
                        action_type=inp.get("action", "screenshot"),
                        coordinate=inp.get("coordinate"),
                        text=inp.get("text"),
                        key=inp.get("key"),
                        scroll_direction=inp.get("scroll_direction"),
                        scroll_distance=inp.get("scroll_distance"),
                        duration=inp.get("duration"),
                    )

            step.claude_thinking = thinking
            step.action = action
            step.is_final = is_final
            step.final_message = thinking if is_final else ""

            messages.append({"role": "assistant", "content": response.content})

            action_result = ""
            if action and not is_final:
                if action.action_type == "screenshot":
                    action_result = "screenshot taken"
                elif is_actions_available():
                    try:
                        action_result = self._executor.execute(action)
                    except Exception as e:
                        action_result = f"action failed: {e}"
                else:
                    action_result = f"skipped (pyautogui unavailable): {action.action_type}"

            step.action_result = action_result or tool_use_id
            steps.append(step)

            if on_step:
                on_step(step)

            if is_final:
                break

            time.sleep(0.5)

        return steps


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _parse_json_action(text: str) -> dict[str, Any] | None:
    """Extract a JSON action dict from model output."""
    # Direct parse
    try:
        data = json.loads(text.strip())
        if isinstance(data, dict) and "action" in data:
            return data
    except Exception:
        pass

    # Find JSON block containing "action"
    try:
        match = re.search(r'\{[^{}]*"action"[^{}]*\}', text, re.DOTALL)
        if match:
            return json.loads(match.group())
    except Exception:
        pass

    # Extract coordinates from natural language ("click at 123, 456")
    coord = re.search(r"[Cc]lick.*?[(\[]?\s*(\d{2,4})\s*[,\s]\s*(\d{2,4})\s*[)\]]?", text)
    if coord:
        return {"action": "left_click", "x": int(coord.group(1)), "y": int(coord.group(2))}

    return None


def _dict_to_action(data: dict[str, Any]) -> ComputerAction | None:
    """Convert a parsed action dict to a ComputerAction model."""
    try:
        atype = data.get("action", "")
        coordinate = None
        if "x" in data and "y" in data:
            coordinate = [int(data["x"]), int(data["y"])]
        return ComputerAction(
            action_type=atype,
            coordinate=coordinate,
            text=data.get("text"),
            key=data.get("key"),
            scroll_direction=data.get("direction", data.get("scroll_direction")),
            scroll_distance=int(data.get("amount", data.get("scroll_distance") or 3)),
            duration=data.get("ms", data.get("duration")),
        )
    except Exception as e:
        logger.debug("dict_to_action failed: %s", e)
        return None


def _screenshots_differ(
    before: ScreenshotResult | None,
    after: ScreenshotResult | None,
    sample_len: int = 800,
) -> bool:
    """Return True if the two screenshots are visually different."""
    if not before or not after:
        return True
    # Compare a sample of base64 bytes — fast and good enough
    b1 = before.base64_image[100:100 + sample_len]
    b2 = after.base64_image[100:100 + sample_len]
    return b1 != b2


def _detect_task_hints(task: str) -> str:
    """Return extra plan hints based on known task patterns."""
    t = task.lower()
    hints: list[str] = []

    if "telegram" in t:
        hints.append(
            "HINT: For Telegram tasks use applescript type steps — "
            "more reliable than clicking. Telegram app name is 'Telegram'.\n"
        )
    if "safari" in t or "открой сайт" in t or "open url" in t:
        hints.append("HINT: Use applescript to open URLs in Safari.\n")
    if "copy" in t or "clipboard" in t or "скопир" in t:
        hints.append("HINT: Use applescript with 'set the clipboard to' for clipboard.\n")

    return "".join(hints)


def is_app_running(name: str) -> bool:
    """Quick check if an app is in the running apps list."""
    return name in get_running_apps()


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def build_agent(
    provider: VisionProvider | None = None,
    *,
    prefer_anthropic_native: bool = True,
) -> SmartComputerAgent | AnthropicComputerAgent:
    """Build the best available agent.

    If Anthropic is configured AND prefer_anthropic_native=True → AnthropicComputerAgent.
    Otherwise → SmartComputerAgent with the given provider.
    """
    import os

    if prefer_anthropic_native:
        key = os.environ.get("ANTHROPIC_API_KEY", "")
        if key:
            try:
                agent = AnthropicComputerAgent(api_key=key)
                if agent.is_available():
                    return agent
            except Exception:
                pass

    if provider is None:
        from owlmind.vision.providers import build_vision_provider

        provider = build_vision_provider()
        if provider is None:
            raise RuntimeError(
                "No vision provider available. "
                "Set ANTHROPIC_API_KEY, QWEN_API_KEY, or OPENAI_API_KEY."
            )

    return SmartComputerAgent(provider=provider)
