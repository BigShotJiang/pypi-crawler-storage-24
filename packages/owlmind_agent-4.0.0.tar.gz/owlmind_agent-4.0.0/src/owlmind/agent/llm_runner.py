"""CycleLLMRunner — LLM-driven planner and judge operations."""

from __future__ import annotations

import json
import logging
from datetime import UTC, datetime
from typing import Any

from owlmind.agent.meta_store import CycleMetaStore
from owlmind.agent.schemas import (
    CycleRunMeta,
    CycleState,
    JudgeResponse,
    PlannerResponse,
)

logger = logging.getLogger(__name__)


class CycleLLMRunner:
    """Runs LLM planner/judge calls and records usage.

    Extracted from CycleManager to keep LLM concerns separate
    from the core cycle state machine.
    """

    def __init__(
        self,
        meta_store: CycleMetaStore,
        *,
        llm_driver: Any | None = None,
        budget_governor: Any | None = None,
        ledger: Any | None = None,
    ) -> None:
        self.meta_store = meta_store
        self.llm_driver = llm_driver
        self.budget_governor = budget_governor
        self.ledger = ledger

    @property
    def evidence(self) -> Any:
        return self.meta_store.evidence

    # ------------------------------------------------------------------
    # Planner LLM
    # ------------------------------------------------------------------

    def run_planner(self, run_id: str, *, force_provider: str | None = None) -> CycleRunMeta:
        """Call LLM driver to generate planner response and write to inbox.

        Only allowed when state == STARTED_WAIT_PLANNER.
        """
        meta = self.meta_store.load(run_id)
        if meta.state != CycleState.STARTED_WAIT_PLANNER:
            msg = f"Expected state STARTED_WAIT_PLANNER, got {meta.state}"
            raise RuntimeError(msg)

        if self.llm_driver is None:
            msg = "No LLM driver configured"
            raise RuntimeError(msg)

        # Budget check
        if self.budget_governor is not None:
            decision = self.budget_governor.check(run_id)
            self.evidence.append_event(
                run_id,
                {
                    "event": "BUDGET_CHECK",
                    "stage": "planner",
                    "allowed": decision.allowed,
                    "reason": decision.reason,
                    **{
                        k: v
                        for k, v in decision.to_dict().items()
                        if k not in ("allowed", "reason")
                    },
                },
            )
            if not decision.allowed:
                from owlmind.approval import create_approval

                create_approval(
                    self.meta_store,
                    run_id,
                    f"BUDGET_OVERRIDE: {decision.reason}",
                    ttl_minutes=30,
                )
                meta = self.meta_store.load(run_id)
                return meta

        from owlmind.llm.openai_driver import PLANNER_RESPONSE_SCHEMA

        # Build planner request data
        outbox_path = self.meta_store.run_dir(run_id) / "outbox" / "planner_prompt.md"
        prompt_text = outbox_path.read_text() if outbox_path.exists() else ""

        planner_data: dict[str, Any] = {
            "run_id": run_id,
            "iteration": meta.iteration,
            "goal": meta.goal,
            "repo_context": prompt_text[:4000],
            "constraints": [
                "Only use allowlisted commands for verification",
                "No force push, no rm -rf, no curl|bash",
                "Return ONLY valid JSON matching PlannerResponse schema",
            ],
        }

        # Store request as evidence
        self.evidence.write_artifact(
            run_id,
            "openai_planner_request.json",
            json.dumps(planner_data, indent=2),
        )

        # Call LLM (with optional Langfuse tracing)
        from owlmind.monitoring.tracing import langfuse_span

        plan_kwargs: dict[str, Any] = {}
        if force_provider is not None:
            plan_kwargs["force_provider"] = force_provider
        with langfuse_span(
            run_id,
            "planner",
            input_data={"goal": meta.goal, "iteration": meta.iteration},
            metadata={"provider": force_provider},
        ) as _lf_span:
            response_json, call_meta = self.llm_driver.plan(
                planner_data,
                PLANNER_RESPONSE_SCHEMA,
                **plan_kwargs,
            )
            _lf_span.end(
                output={
                    "provider": call_meta.get("provider"),
                    "model": call_meta.get("model"),
                    "input_tokens": call_meta.get("usage", {}).get("input_tokens", 0),
                    "output_tokens": call_meta.get("usage", {}).get("output_tokens", 0),
                    "latency_ms": call_meta.get("latency_ms", 0),
                }
            )

        # Store response as evidence
        self.evidence.write_artifact(
            run_id,
            "openai_planner_response.json",
            json.dumps(response_json, indent=2),
        )

        # Validate via Pydantic
        PlannerResponse(**response_json)

        # Write to inbox
        inbox = self.meta_store.ensure_inbox_dir(run_id)
        inbox_path = inbox / "planner_response.json"
        inbox_path.write_text(json.dumps(response_json, indent=2))

        # Log chain event (no secrets in meta)
        safe_meta = {
            k: v
            for k, v in call_meta.items()
            if k in ("provider", "model", "response_id", "usage", "latency_ms")
        }
        self.evidence.append_event(
            run_id,
            {
                "event": "LLM_PLANNER_CALLED",
                "iteration": meta.iteration,
                **safe_meta,
            },
        )

        # Record in ledger
        if self.ledger is not None:
            usage = call_meta.get("usage", {})
            self._record_llm_usage(
                run_id=run_id,
                stage="planner",
                call_meta=call_meta,
                input_tokens=usage.get("input_tokens", 0),
                output_tokens=usage.get("output_tokens", 0),
            )

        logger.info(
            "LLM planner called for %s (model=%s, latency=%dms)",
            run_id,
            call_meta.get("model", "?"),
            call_meta.get("latency_ms", 0),
        )

        return meta

    # ------------------------------------------------------------------
    # Judge LLM
    # ------------------------------------------------------------------

    def run_judge(self, run_id: str, *, force_provider: str | None = None) -> CycleRunMeta:
        """Call LLM driver to generate judge response and write to inbox.

        Only allowed when state == WAIT_JUDGE.
        """
        meta = self.meta_store.load(run_id)
        if meta.state != CycleState.WAIT_JUDGE:
            msg = f"Expected state WAIT_JUDGE, got {meta.state}"
            raise RuntimeError(msg)

        if self.llm_driver is None:
            msg = "No LLM driver configured"
            raise RuntimeError(msg)

        # Budget check
        if self.budget_governor is not None:
            decision = self.budget_governor.check(run_id)
            self.evidence.append_event(
                run_id,
                {
                    "event": "BUDGET_CHECK",
                    "stage": "judge",
                    "allowed": decision.allowed,
                    "reason": decision.reason,
                    **{
                        k: v
                        for k, v in decision.to_dict().items()
                        if k not in ("allowed", "reason")
                    },
                },
            )
            if not decision.allowed:
                from owlmind.approval import create_approval

                create_approval(
                    self.meta_store,
                    run_id,
                    f"BUDGET_OVERRIDE: {decision.reason}",
                    ttl_minutes=30,
                )
                meta = self.meta_store.load(run_id)
                return meta

        from owlmind.llm.openai_driver import JUDGE_RESPONSE_SCHEMA

        # Build judge request data
        run_dir = self.meta_store.run_dir(run_id)
        evidence_dir = run_dir / "artifacts"
        evidence_paths = (
            [str(p.relative_to(run_dir)) for p in sorted(evidence_dir.iterdir()) if p.is_file()]
            if evidence_dir.exists()
            else []
        )

        judge_data: dict[str, Any] = {
            "run_id": run_id,
            "iteration": meta.iteration,
            "goal": meta.goal,
            "planner_plan_summary": meta.planner_plan_summary,
            "worker_done_summary": meta.worker_done_summary,
            "verify_results_summary": meta.verify_results,
            "evidence_paths": evidence_paths,
        }

        # Store request as evidence
        self.evidence.write_artifact(
            run_id,
            "openai_judge_request.json",
            json.dumps(judge_data, indent=2),
        )

        # Call LLM (with optional Langfuse tracing)
        from owlmind.monitoring.tracing import langfuse_span

        judge_kwargs: dict[str, Any] = {}
        if force_provider is not None:
            judge_kwargs["force_provider"] = force_provider
        with langfuse_span(
            run_id,
            "judge",
            input_data={"goal": meta.goal, "iteration": meta.iteration},
            metadata={"provider": force_provider},
        ) as _lf_span:
            response_json, call_meta = self.llm_driver.judge(
                judge_data,
                JUDGE_RESPONSE_SCHEMA,
                **judge_kwargs,
            )
            _lf_span.end(
                output={
                    "provider": call_meta.get("provider"),
                    "model": call_meta.get("model"),
                    "input_tokens": call_meta.get("usage", {}).get("input_tokens", 0),
                    "output_tokens": call_meta.get("usage", {}).get("output_tokens", 0),
                    "latency_ms": call_meta.get("latency_ms", 0),
                }
            )

        # Store response as evidence
        self.evidence.write_artifact(
            run_id,
            "openai_judge_response.json",
            json.dumps(response_json, indent=2),
        )

        # Validate via Pydantic
        JudgeResponse(**response_json)

        # Write to inbox
        inbox = self.meta_store.ensure_inbox_dir(run_id)
        inbox_path = inbox / "judge_response.json"
        inbox_path.write_text(json.dumps(response_json, indent=2))

        # Log chain event
        safe_meta = {
            k: v
            for k, v in call_meta.items()
            if k in ("provider", "model", "response_id", "usage", "latency_ms")
        }
        self.evidence.append_event(
            run_id,
            {
                "event": "LLM_JUDGE_CALLED",
                "iteration": meta.iteration,
                **safe_meta,
            },
        )

        # Record in ledger
        if self.ledger is not None:
            usage = call_meta.get("usage", {})
            self._record_llm_usage(
                run_id=run_id,
                stage="judge",
                call_meta=call_meta,
                input_tokens=usage.get("input_tokens", 0),
                output_tokens=usage.get("output_tokens", 0),
            )

        logger.info(
            "LLM judge called for %s (model=%s, latency=%dms)",
            run_id,
            call_meta.get("model", "?"),
            call_meta.get("latency_ms", 0),
        )

        return meta

    # ------------------------------------------------------------------
    # Usage recording
    # ------------------------------------------------------------------

    def _record_llm_usage(
        self,
        run_id: str,
        stage: str,
        call_meta: dict[str, Any],
        input_tokens: int,
        output_tokens: int,
    ) -> None:
        """Record LLM usage in the ledger and evidence chain."""
        from owlmind.ledger import UsageEntry

        pricing = getattr(self.budget_governor, "pricing", None)
        provider = call_meta.get("provider", "openai")
        if pricing and hasattr(pricing, "price_for_provider"):
            price_in, price_out = pricing.price_for_provider(provider)
        elif pricing:
            price_in = pricing.openai_price_per_1k_input
            price_out = pricing.openai_price_per_1k_output
        else:
            price_in = 0.0
            price_out = 0.0

        estimated_usd = (input_tokens / 1000) * price_in + (output_tokens / 1000) * price_out

        entry = UsageEntry(
            ts=datetime.now(tz=UTC).isoformat(),
            run_id=run_id,
            stage=stage,
            provider=call_meta.get("provider", "unknown"),
            model=call_meta.get("model", "unknown"),
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            total_tokens=input_tokens + output_tokens,
            estimated_usd=estimated_usd,
            latency_ms=call_meta.get("latency_ms", 0),
            price_per_1k_input=price_in,
            price_per_1k_output=price_out,
        )
        if self.ledger is not None:
            self.ledger.record(entry)

        self.evidence.append_event(
            run_id,
            {
                "event": "LLM_USAGE_RECORDED",
                "stage": stage,
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "total_tokens": input_tokens + output_tokens,
                "estimated_usd": round(estimated_usd, 6),
            },
        )
