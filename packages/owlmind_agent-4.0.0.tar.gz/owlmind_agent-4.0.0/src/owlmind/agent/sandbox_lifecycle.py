"""Sandbox lifecycle management (extracted from CycleManager)."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from owlmind.evidence import EvidenceStore
    from owlmind.policy import PolicyEngine
    from owlmind.utils import ToolLimits

from owlmind.agent.sandbox import (
    SandboxInfo,
    cleanup_sandbox,
    create_sandbox,
)
from owlmind.agent.sandbox import (
    sandbox_status as _sandbox_status,
)


class SandboxLifecycleMixin:
    """Mixin providing sandbox create/cleanup/status operations.

    Expects the host class to expose:
        - ``self.evidence: EvidenceStore``  (needs ``.base_dir``)
        - ``self.policy: PolicyEngine``
        - ``self.limits: ToolLimits``
    """

    evidence: EvidenceStore
    policy: PolicyEngine
    limits: ToolLimits

    def sandbox_create(self, run_id: str, workspace: str) -> SandboxInfo:
        """Create sandbox for an existing run."""
        return create_sandbox(
            run_id=run_id,
            workspace=workspace,
            runs_dir=self.evidence.base_dir,
            policy=self.policy,
            limits=self.limits,
        )

    def sandbox_cleanup(self, run_id: str, workspace: str) -> tuple[bool, str]:
        """Remove sandbox for a run."""
        return cleanup_sandbox(
            run_id=run_id,
            workspace=workspace,
            runs_dir=self.evidence.base_dir,
            policy=self.policy,
            limits=self.limits,
        )

    def sandbox_status(self, run_id: str) -> SandboxInfo:
        """Return sandbox status for a run."""
        return _sandbox_status(
            run_id=run_id,
            runs_dir=self.evidence.base_dir,
        )
