"""Task splitter — decompose a complex goal into independent sub-tasks via LLM."""
from __future__ import annotations

import logging
import re
from typing import Any

logger = logging.getLogger(__name__)

_SYSTEM_PROMPT = """You are a task decomposition expert. Given a complex software engineering goal,
split it into 2-4 small, independent, parallelizable sub-tasks that can each be completed by a
separate coding agent without depending on each other's results.

Rules:
- Each sub-task must be self-contained and independently executable
- Do NOT create sub-tasks that depend on each other's output
- Keep each sub-task focused (one file or one concern)
- If the goal is already simple/small, return it as a single task
- Return ONLY a numbered list, one task per line, nothing else

Example output:
1. Add type hints to src/owlmind/agent/schemas.py
2. Add docstrings to src/owlmind/agent/meta_store.py
3. Fix ruff warnings in src/owlmind/llm/openai_driver.py"""

_USER_TEMPLATE = "Goal: {goal}\n\nSplit into independent sub-tasks (2-4 max):"


def split_goal(
    goal: str,
    llm_driver: Any | None = None,
    max_subtasks: int = 4,
) -> list[str]:
    """Decompose a goal into independent sub-tasks.

    Uses LLM if available. Falls back to returning [goal] on any error.

    Args:
        goal: The goal string to decompose.
        llm_driver: Optional LLM driver with a .complete(system, user) -> str method.
        max_subtasks: Maximum number of subtasks to return.

    Returns:
        List of subtask strings. Always has at least one element (the original goal).
    """
    if not goal.strip():
        return []

    if llm_driver is None:
        return [goal]

    try:
        raw = llm_driver.complete(
            system=_SYSTEM_PROMPT,
            user=_USER_TEMPLATE.format(goal=goal),
        )
        subtasks = _parse_numbered_list(raw)
        if not subtasks:
            return [goal]
        return subtasks[:max_subtasks]
    except Exception:
        logger.debug("split_goal LLM call failed, returning original goal", exc_info=True)
        return [goal]


def _parse_numbered_list(text: str) -> list[str]:
    """Parse a numbered list like '1. task one\\n2. task two' into a list of strings."""
    lines = text.strip().splitlines()
    result: list[str] = []
    for line in lines:
        line = line.strip()
        if not line:
            continue
        # Match "1. task" or "1) task" or "- task"
        m = re.match(r"^(?:\d+[.)]\s*|-\s*)(.+)$", line)
        if m:
            task = m.group(1).strip()
            if task:
                result.append(task)
    return result
