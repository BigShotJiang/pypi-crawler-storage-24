"""Approval-gated worker automation flow (extracted from CycleManager)."""

from __future__ import annotations

import contextlib
import json
import logging
import threading
import time
from collections.abc import Generator
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from owlmind.agent.meta_store import CycleMetaStore
    from owlmind.agent.schemas import CycleRunMeta
    from owlmind.evidence import EvidenceStore

from owlmind.agent.schemas import CycleState, WorkerReport

logger = logging.getLogger(__name__)


class ApprovalFlowMixin:
    """Mixin providing approval-gated worker CLI automation.

    Expects the host class to expose:
        - ``self.evidence: EvidenceStore``
        - ``self.meta_store: CycleMetaStore``
        - ``self.worker_driver``
        - ``self._load_meta(run_id) -> CycleRunMeta``
        - ``self._save_meta(meta) -> None``
        - ``self._run_dir(run_id) -> Path``
    """

    # Declared for type-checkers; actual attrs live on the host class.
    evidence: EvidenceStore
    meta_store: CycleMetaStore
    worker_driver: Any

    # ------------------------------------------------------------------
    # Public entry-point
    # ------------------------------------------------------------------

    def run_worker_cli(self, run_id: str) -> tuple[CycleRunMeta, str]:
        """Run worker via Claude CLI driver with approval gating.

        Flow:
        1. If state is WAIT_WORKER and no approval exists -> create approval, return
        2. If state is WAIT_APPROVAL and approval granted -> run worker, write inbox
        3. Otherwise -> raise or return message

        Returns ``(meta, message)``.
        """
        meta = self._load_meta(run_id)  # type: ignore[attr-defined]

        # Case 1: WAIT_WORKER -- need approval first
        if meta.state == CycleState.WAIT_WORKER:
            pending = meta.extra.get("pending_approval")
            if pending:
                from owlmind.approval import ApprovalToken

                approval = ApprovalToken.from_dict(pending)
                if approval.resolved and approval.approved:
                    return self._execute_worker_cli(run_id, meta)

            from owlmind.approval import create_approval

            approval_token = create_approval(
                self.meta_store,
                run_id,
                "Worker automation via Claude CLI (high-risk action)",
            )
            meta = self._load_meta(run_id)  # type: ignore[attr-defined]
            return meta, (
                f"Approval required for worker automation.\n"
                f"  Token:   {approval_token.token}\n"
                f"  Approve: owlmind cycle approve --run-id {run_id} "
                f"--token {approval_token.token}\n"
                f"  Deny:    owlmind cycle deny --run-id {run_id} "
                f"--token {approval_token.token}"
            )

        # Case 2: WAIT_APPROVAL -- check if approved for worker
        if meta.state == CycleState.WAIT_APPROVAL:
            pending = meta.extra.get("pending_approval")
            pre_state = meta.extra.get("pre_approval_state", "")
            if pending and pre_state == CycleState.WAIT_WORKER.value:
                from owlmind.approval import ApprovalToken

                approval = ApprovalToken.from_dict(pending)
                if approval.resolved and approval.approved:
                    meta.state = CycleState.WAIT_WORKER
                    self._save_meta(meta)  # type: ignore[attr-defined]
                    return self._execute_worker_cli(run_id, meta)
                if not approval.resolved:
                    return meta, (
                        "Waiting for approval.\n"
                        f"  Token: {approval.token}\n"
                        f"  Approve: owlmind cycle approve --run-id {run_id} "
                        f"--token {approval.token}"
                    )
            return meta, f"Unexpected state for worker: {meta.state.value}"

        msg = f"Expected WAIT_WORKER or WAIT_APPROVAL, got {meta.state}"
        raise RuntimeError(msg)

    # ------------------------------------------------------------------
    # Progress ticker
    # ------------------------------------------------------------------

    @contextlib.contextmanager
    def _progress_ticker(self, run_id: str, interval: int = 30) -> Generator[None, None, None]:
        """Background thread: log elapsed time every *interval* seconds (FS58)."""
        stop_event = threading.Event()
        start_time = time.monotonic()

        def _tick() -> None:
            while not stop_event.wait(interval):
                elapsed = int(time.monotonic() - start_time)
                logger.info(
                    "Worker running... (%ds elapsed, run_id=%s)",
                    elapsed,
                    run_id,
                )
                with contextlib.suppress(Exception):
                    self.evidence.append_event(
                        run_id,
                        {
                            "event": "WORKER_PROGRESS",
                            "elapsed_sec": elapsed,
                        },
                    )

        t = threading.Thread(target=_tick, daemon=True)
        t.start()
        try:
            yield
        finally:
            stop_event.set()
            t.join(timeout=1)

    # ------------------------------------------------------------------
    # Internal: actually run the worker CLI
    # ------------------------------------------------------------------

    def _execute_worker_cli(
        self,
        run_id: str,
        meta: CycleRunMeta,
    ) -> tuple[CycleRunMeta, str]:
        """Actually run the Claude CLI worker and write inbox/evidence."""
        if self.worker_driver is None:
            msg = "No worker driver configured"
            raise RuntimeError(msg)

        from owlmind.worker.claude_cli_driver import WORKER_REPORT_SCHEMA

        # Build worker request from outbox
        outbox_path = self._run_dir(run_id) / "outbox" / "worker_prompt.md"  # type: ignore[attr-defined]
        prompt_text = outbox_path.read_text() if outbox_path.exists() else ""

        worker_data: dict[str, Any] = {
            "run_id": run_id,
            "iteration": meta.iteration,
            "worker_instructions": prompt_text[:8000],
            "constraints": [
                "Return ONLY valid JSON matching WorkerReport schema",
                "No force push, no destructive commands",
            ],
            "verify_commands": meta.verify_commands,
        }

        # Store prompt as evidence
        self.evidence.write_artifact(
            run_id,
            "claude_worker_prompt.txt",
            json.dumps(worker_data, indent=2),
        )

        workspace = Path(meta.workspace)

        try:
            with self._progress_ticker(run_id):
                report_json, call_meta = self.worker_driver.run(
                    worker_data,
                    WORKER_REPORT_SCHEMA,
                    workspace,
                )
        except RuntimeError as exc:
            self.evidence.append_event(
                run_id,
                {
                    "event": "WORKER_CLAUDE_CLI_CALLED",
                    "iteration": meta.iteration,
                    "provider": self.worker_driver.name,
                    "parsed_ok": False,
                    "error": str(exc)[:200],
                },
            )
            raise

        # Store raw output and parsed report
        raw_sha = call_meta.get("raw_output_sha256", "")
        self.evidence.write_artifact(
            run_id,
            "claude_worker_raw_output.txt",
            f"sha256={raw_sha}\nexit_code={call_meta.get('exit_code', '?')}\n"
            f"duration_ms={call_meta.get('duration_ms', '?')}",
        )
        self.evidence.write_artifact(
            run_id,
            "claude_worker_report.json",
            json.dumps(report_json, indent=2),
        )

        # Validate via Pydantic
        WorkerReport(**report_json)

        # Write to inbox
        inbox = self.meta_store.ensure_inbox_dir(run_id)
        inbox_path = inbox / "worker_report.json"
        inbox_path.write_text(json.dumps(report_json, indent=2))

        # Log chain events
        safe_meta = {
            k: v
            for k, v in call_meta.items()
            if k in ("provider", "exit_code", "duration_ms", "parsed_ok", "raw_output_sha256")
        }
        self.evidence.append_event(
            run_id,
            {
                "event": "WORKER_CLAUDE_CLI_CALLED",
                "iteration": meta.iteration,
                **safe_meta,
            },
        )
        self.evidence.append_event(
            run_id,
            {
                "event": "WORKER_CLAUDE_CLI_PARSED",
                "iteration": meta.iteration,
                "parsed_ok": call_meta.get("parsed_ok", False),
            },
        )

        logger.info(
            "Worker CLI completed for %s (exit=%d, duration=%dms)",
            run_id,
            call_meta.get("exit_code", -1),
            call_meta.get("duration_ms", 0),
        )

        return meta, "Worker report generated by Claude CLI. Written to inbox."
