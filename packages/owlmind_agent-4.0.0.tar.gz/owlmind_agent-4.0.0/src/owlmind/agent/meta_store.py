"""CycleMetaStore — read/write cycle metadata and run directory management."""

from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path

from owlmind.agent.schemas import CycleRunMeta
from owlmind.evidence import EvidenceStore


class CycleMetaStore:
    """Encapsulates all cycle metadata I/O.

    Provides load/save for ``CycleRunMeta`` and directory helpers
    for run directories, inbox, outbox, and artifacts.
    """

    def __init__(self, evidence: EvidenceStore) -> None:
        self.evidence = evidence

    # ------------------------------------------------------------------
    # Directory helpers
    # ------------------------------------------------------------------

    def run_dir(self, run_id: str) -> Path:
        """Return the root directory for a run."""
        return self.evidence.base_dir / run_id

    def ensure_inbox_dir(self, run_id: str) -> Path:
        """Create and return the inbox directory for a run."""
        inbox = self.run_dir(run_id) / "inbox"
        inbox.mkdir(parents=True, exist_ok=True)
        return inbox

    def inbox_file_exists(self, run_id: str, filename: str) -> bool:
        """Check if an inbox file exists."""
        return (self.run_dir(run_id) / "inbox" / filename).exists()

    # ------------------------------------------------------------------
    # Meta I/O
    # ------------------------------------------------------------------

    def load(self, run_id: str) -> CycleRunMeta:
        """Load cycle metadata from disk."""
        meta_path = self.run_dir(run_id) / "cycle_meta.json"
        return CycleRunMeta(**json.loads(meta_path.read_text()))

    def save(self, meta: CycleRunMeta) -> None:
        """Save cycle metadata to disk (updates timestamp and chain tip)."""
        meta.updated_at = datetime.now(tz=UTC)
        tip_hash, tip_seq = self.evidence.get_chain_tip(meta.run_id)
        meta.chain_tip_hash = tip_hash
        meta.chain_seq = tip_seq
        path = self.run_dir(meta.run_id) / "cycle_meta.json"
        path.write_text(meta.model_dump_json(indent=2))

    # ------------------------------------------------------------------
    # Outbox / inbox helpers
    # ------------------------------------------------------------------

    def write_outbox(self, run_id: str, filename: str, content: str) -> Path:
        """Write a file to the outbox directory and record as artifact."""
        outbox = self.run_dir(run_id) / "outbox"
        outbox.mkdir(parents=True, exist_ok=True)
        path = outbox / filename
        path.write_text(content)
        self.evidence.write_artifact(run_id, f"outbox_{filename}", content)
        return path

    def read_inbox(
        self,
        run_id: str,
        filename: str,
        file_override: Path | None = None,
        *,
        consume: bool = False,
    ) -> str:
        """Read an inbox file (or override file).

        When *consume* is True the inbox file is deleted after reading so that
        stale files cannot be picked up on the next iteration of the cycle.
        """
        if file_override and file_override.exists():
            return file_override.read_text()
        inbox_path = self.run_dir(run_id) / "inbox" / filename
        if not inbox_path.exists():
            msg = f"Inbox file not found: {inbox_path}"
            raise FileNotFoundError(msg)
        content = inbox_path.read_text()
        if consume:
            inbox_path.unlink(missing_ok=True)
        return content
