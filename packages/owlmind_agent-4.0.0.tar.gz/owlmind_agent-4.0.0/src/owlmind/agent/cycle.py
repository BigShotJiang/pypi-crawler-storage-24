"""CycleManager — manual inbox/outbox cycle for Planner/Worker/Judge.

Backward-compatibility shim: re-exports all public symbols from the decomposed modules.
New code should import directly from the sub-modules:
    from owlmind.agent.cycle_manager import CycleManager
    from owlmind.agent.cycle_planner import _build_planner_prompt
    from owlmind.agent.cycle_worker import _build_worker_prompt
    from owlmind.agent.cycle_judge import _build_judge_prompt
"""

from __future__ import annotations

from owlmind.agent.cycle_judge import _build_judge_prompt

# Re-export CycleManager (primary public API)
# Re-export module-level availability flags so that
#   from owlmind.agent import cycle; cycle._SKILLS_AVAILABLE
# continues to work as tested.
from owlmind.agent.cycle_manager import (
    _COMPLEXITY_AVAILABLE,
    _GOAL_REFINER_AVAILABLE,
    _MEMORY_RETRIEVAL_AVAILABLE,
    _SKILLS_AVAILABLE,
    _SMART_VERIFY_AVAILABLE,
    CycleManager,
)

# Re-export prompt builders (used directly in tests)
from owlmind.agent.cycle_planner import _build_planner_prompt
from owlmind.agent.cycle_worker import _build_worker_prompt

__all__ = [
    "CycleManager",
    "_build_planner_prompt",
    "_build_worker_prompt",
    "_build_judge_prompt",
    "_SKILLS_AVAILABLE",
    "_MEMORY_RETRIEVAL_AVAILABLE",
    "_GOAL_REFINER_AVAILABLE",
    "_SMART_VERIFY_AVAILABLE",
    "_COMPLEXITY_AVAILABLE",
]
