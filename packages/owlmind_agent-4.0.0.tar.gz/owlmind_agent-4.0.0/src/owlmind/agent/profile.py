"""Repo profile detection — auto-detect project type and suggest verify commands."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class RepoProfile:
    """Detected repository profile."""

    kind: str  # "python" | "node" | "mixed" | "unknown"
    markers: list[str] = field(default_factory=list)
    suggested_verify_commands: list[str] = field(default_factory=list)


_PYTHON_MARKERS = ("pyproject.toml", "requirements.txt", "setup.cfg", "setup.py")
_NODE_MARKERS = ("package.json",)


def _has_npm_script(workspace: Path, script_name: str) -> bool:
    """Check if package.json contains a specific script."""
    pkg_path = workspace / "package.json"
    if not pkg_path.exists():
        return False
    try:
        data = json.loads(pkg_path.read_text())
        scripts = data.get("scripts", {})
        return script_name in scripts
    except (json.JSONDecodeError, OSError):
        return False


def detect_profile(workspace: str | Path) -> RepoProfile:
    """Detect the project type from workspace markers.

    Returns a :class:`RepoProfile` with suggested verify commands
    that are safe and typically allowlisted.
    """
    workspace = Path(workspace)

    python_found: list[str] = []
    node_found: list[str] = []

    for marker in _PYTHON_MARKERS:
        if (workspace / marker).exists():
            python_found.append(marker)

    for marker in _NODE_MARKERS:
        if (workspace / marker).exists():
            node_found.append(marker)

    is_python = len(python_found) > 0
    is_node = len(node_found) > 0

    if is_python and is_node:
        kind = "mixed"
    elif is_python:
        kind = "python"
    elif is_node:
        kind = "node"
    else:
        kind = "unknown"

    markers = python_found + node_found
    commands: list[str] = []

    if is_python:
        commands.extend(["pytest -q --timeout=120 -x", "ruff check .", "mypy ."])

    if is_node:
        if _has_npm_script(workspace, "test"):
            commands.append("npm test")
        if _has_npm_script(workspace, "lint"):
            commands.append("npm run lint")
        if _has_npm_script(workspace, "build"):
            commands.append("npm run build")

    return RepoProfile(
        kind=kind,
        markers=markers,
        suggested_verify_commands=commands,
    )
