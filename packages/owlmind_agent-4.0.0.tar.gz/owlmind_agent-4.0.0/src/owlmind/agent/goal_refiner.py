"""Goal Refiner — pre-cycle LLM call to validate and clarify the goal (FS55)."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)

_REFINE_SYSTEM = """\
You are a senior software architect. Analyze the given goal and return a JSON object with:
- "refined": a clearer, more actionable version of the goal (or the original if it's fine)
- "risk_level": one of "low", "medium", "high"
- "warnings": list of strings with potential issues (empty list if none)

Risk levels:
- "low": safe, isolated, clearly scoped
- "medium": touches core logic, tests, or config
- "high": destructive, irreversible, security-sensitive, or underspecified

Return ONLY valid JSON, no markdown, no explanation.
"""

_REFINE_EXAMPLE = """\
{
  "refined": "Add unit tests for the UserAuthService class to cover login, logout, and token refresh",
  "risk_level": "low",
  "warnings": []
}
"""


@dataclass
class RefinedGoal:
    """Result of goal refinement."""

    original: str
    refined: str
    risk_level: str  # low | medium | high | unknown
    warnings: list[str] = field(default_factory=list)

    @property
    def is_high_risk(self) -> bool:
        return self.risk_level == "high"

    @property
    def changed(self) -> bool:
        return self.refined.strip() != self.original.strip()


def refine_goal(goal: str, llm_driver: Any, workspace: str = ".") -> RefinedGoal:
    """Call LLM to refine and validate a goal.

    If LLM is unavailable or fails, returns a passthrough RefinedGoal
    (refined == original, risk_level="unknown", no warnings).

    Args:
        goal: The raw user goal string.
        llm_driver: Any LLM driver with a ``plan()`` method or compatible API.
        workspace: Workspace path (for context only).

    Returns:
        RefinedGoal with original, refined, risk_level, and warnings.
    """
    if not goal.strip():
        return RefinedGoal(original=goal, refined=goal, risk_level="unknown")

    if llm_driver is None:
        logger.debug("Goal refiner: no LLM driver, skipping refinement")
        return RefinedGoal(original=goal, refined=goal, risk_level="unknown")

    payload: dict[str, Any] = {
        "system": _REFINE_SYSTEM,
        "goal": goal,
        "workspace": workspace,
        "example_output": _REFINE_EXAMPLE,
    }

    schema = {
        "type": "json_schema",
        "json_schema": {
            "name": "RefinedGoal",
            "strict": True,
            "schema": {
                "type": "object",
                "properties": {
                    "refined": {"type": "string"},
                    "risk_level": {
                        "type": "string",
                        "enum": ["low", "medium", "high"],
                    },
                    "warnings": {
                        "type": "array",
                        "items": {"type": "string"},
                    },
                },
                "required": ["refined", "risk_level", "warnings"],
                "additionalProperties": False,
            },
        },
    }

    try:
        response_json, _meta = llm_driver.plan(payload, schema)
        refined = str(response_json.get("refined", goal)).strip() or goal
        risk_level = str(response_json.get("risk_level", "unknown"))
        if risk_level not in ("low", "medium", "high"):
            risk_level = "unknown"
        warnings_raw = response_json.get("warnings", [])
        warnings = [str(w) for w in warnings_raw] if isinstance(warnings_raw, list) else []
        return RefinedGoal(
            original=goal,
            refined=refined,
            risk_level=risk_level,
            warnings=warnings,
        )
    except Exception:
        logger.warning("Goal refiner LLM call failed, using original goal", exc_info=True)
        return RefinedGoal(original=goal, refined=goal, risk_level="unknown")
