"""SelfImprover — analyze SWE-bench failures and suggest improved agent system prompts."""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# Where improvements are persisted
DEFAULT_IMPROVEMENTS_FILE = Path.home() / ".owlmind" / "prompt_improvements.jsonl"
# Where applied prompt overrides are written
DEFAULT_PROMPTS_CONFIG = Path.home() / ".owlmind" / "prompt_overrides.json"


@dataclass
class FailedTask:
    """A single failed SWE-bench task with its error context."""

    instance_id: str
    repo: str
    error: str
    status: str = "failed"
    cost_summary: str = ""
    tests_failed: list[str] = field(default_factory=list)

    @classmethod
    def from_bench_result(cls, result: Any) -> FailedTask:
        """Build from a BenchResult dataclass or dict."""
        if isinstance(result, dict):
            return cls(
                instance_id=result.get("instance_id", ""),
                repo=result.get("repo", ""),
                error=result.get("error", ""),
                status=result.get("status", "failed"),
                cost_summary=result.get("cost_summary", ""),
                tests_failed=result.get("tests_failed", []),
            )
        return cls(
            instance_id=getattr(result, "instance_id", ""),
            repo=getattr(result, "repo", ""),
            error=getattr(result, "error", ""),
            status=getattr(result, "status", "failed"),
            cost_summary=getattr(result, "cost_summary", ""),
            tests_failed=getattr(result, "tests_failed", []),
        )


@dataclass
class PromptSuggestion:
    """A suggested improvement for one agent's system prompt."""

    agent: str  # "planner" | "worker" | "judge"
    rationale: str
    suggested_addition: str  # text to prepend/append to the existing prompt
    confidence: float = 0.5
    pattern: str = ""  # the failure pattern this addresses

    def to_dict(self) -> dict[str, Any]:
        return {
            "agent": self.agent,
            "rationale": self.rationale,
            "suggested_addition": self.suggested_addition,
            "confidence": self.confidence,
            "pattern": self.pattern,
        }


@dataclass
class ImprovementRecord:
    """One improvement session written to the JSONL log."""

    timestamp: str
    failures_analyzed: int
    suggestions: list[PromptSuggestion]
    dry_run: bool
    applied: bool = False
    llm_response_raw: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "timestamp": self.timestamp,
            "failures_analyzed": self.failures_analyzed,
            "dry_run": self.dry_run,
            "applied": self.applied,
            "llm_response_raw": self.llm_response_raw,
            "suggestions": [s.to_dict() for s in self.suggestions],
        }


def load_prompt_overrides(
    prompts_config: Path = DEFAULT_PROMPTS_CONFIG,
) -> dict[str, str]:
    """Load prompt overrides from *prompts_config* and return them.

    Returns a dict like ``{"planner": "...", "worker": "...", "judge": "..."}``.
    If the file does not exist or cannot be parsed, an empty dict is returned
    so callers can treat this as a no-op.
    """
    if not prompts_config.exists():
        return {}
    try:
        data = json.loads(prompts_config.read_text())
        if not isinstance(data, dict):
            logger.warning("load_prompt_overrides: unexpected format in %s", prompts_config)
            return {}
        return {k: v for k, v in data.items() if isinstance(k, str) and isinstance(v, str) and v}
    except json.JSONDecodeError:
        logger.warning("load_prompt_overrides: could not parse %s", prompts_config)
        return {}


class SelfImprover:
    """Analyze SWE-bench failures and suggest improved Planner/Worker/Judge prompts.

    Usage::

        improver = SelfImprover()
        suggestions = improver.analyze(failed_tasks, dry_run=True)
        # inspect suggestions …
        improver.apply(suggestions)  # writes prompt_overrides.json
    """

    def __init__(
        self,
        improvements_file: Path = DEFAULT_IMPROVEMENTS_FILE,
        prompts_config: Path = DEFAULT_PROMPTS_CONFIG,
    ) -> None:
        self._improvements_file = improvements_file
        self._prompts_config = prompts_config

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def analyze(
        self,
        failed_tasks: list[FailedTask],
        *,
        dry_run: bool = True,
    ) -> list[PromptSuggestion]:
        """Analyze failures and return prompt suggestions.

        Parameters
        ----------
        failed_tasks:
            List of tasks that failed during the bench run.
        dry_run:
            If True, suggestions are logged but NOT written to the prompts
            config file.  The improvement record is always appended to the
            JSONL log.

        Returns
        -------
        list[PromptSuggestion]
            One suggestion per detected failure pattern / affected agent.
        """
        if not failed_tasks:
            logger.info("SelfImprover: no failures to analyze")
            return []

        patterns = self._detect_patterns(failed_tasks)
        suggestions = self._call_llm(patterns, failed_tasks)

        record = ImprovementRecord(
            timestamp=datetime.now(UTC).isoformat(),
            failures_analyzed=len(failed_tasks),
            suggestions=suggestions,
            dry_run=dry_run,
            applied=False,
        )
        self._append_record(record)

        if not dry_run:
            self.apply(suggestions)
            record.applied = True
            logger.info("SelfImprover: improvements applied to %s", self._prompts_config)
        else:
            logger.info(
                "SelfImprover: dry-run — %d suggestion(s) logged, not applied",
                len(suggestions),
            )

        return suggestions

    def apply(self, suggestions: list[PromptSuggestion]) -> None:
        """Write suggested prompt additions to the prompts config file.

        The file is a JSON object keyed by agent name, e.g.::

            {
              "planner": "...additional instructions...",
              "worker":  "...additional instructions..."
            }

        Existing entries are extended (not replaced) so multiple improvement
        rounds accumulate rather than overwrite each other.
        """
        self._prompts_config.parent.mkdir(parents=True, exist_ok=True)

        current: dict[str, str] = {}
        if self._prompts_config.exists():
            try:
                current = json.loads(self._prompts_config.read_text())
            except json.JSONDecodeError:
                logger.warning("Could not parse %s — starting fresh", self._prompts_config)

        for s in suggestions:
            existing = current.get(s.agent, "")
            separator = "\n\n" if existing else ""
            current[s.agent] = existing + separator + s.suggested_addition

        self._prompts_config.write_text(json.dumps(current, indent=2))
        logger.info("Prompts config written to %s", self._prompts_config)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _detect_patterns(self, failed_tasks: list[FailedTask]) -> dict[str, list[str]]:
        """Group failure errors into coarse pattern buckets.

        Returns a dict mapping pattern label → list of representative error
        snippets (up to 3 per pattern).
        """
        patterns: dict[str, list[str]] = {
            "timeout": [],
            "patch_invalid": [],
            "test_failure": [],
            "lm_output_unparseable": [],
            "unknown": [],
        }

        for task in failed_tasks:
            err = (task.error or "").lower()
            snippet = task.error[:200] if task.error else "(no error)"

            if "timeout" in err or "timed out" in err:
                patterns["timeout"].append(snippet)
            elif "patch" in err or "hunk" in err or "reject" in err:
                patterns["patch_invalid"].append(snippet)
            elif task.tests_failed or "assert" in err or "test" in err:
                patterns["test_failure"].append(snippet)
            elif "json" in err or "parse" in err or "invalid" in err:
                patterns["lm_output_unparseable"].append(snippet)
            else:
                patterns["unknown"].append(snippet)

        # Keep at most 3 examples per pattern to avoid huge prompts
        return {k: v[:3] for k, v in patterns.items() if v}

    def _call_llm(
        self,
        patterns: dict[str, list[str]],
        failed_tasks: list[FailedTask],
    ) -> list[PromptSuggestion]:
        """Ask the LLM to suggest prompt improvements for detected patterns.

        Falls back to rule-based suggestions when no LLM is available.
        """
        import os

        meta_prompt = self._build_meta_prompt(patterns, failed_tasks)

        # Try OpenAI-compatible (DeepSeek) first, then Anthropic
        openai_key = os.environ.get("OPENAI_API_KEY", "")
        if openai_key:
            try:
                from openai import OpenAI  # type: ignore[import-not-found]

                kwargs: dict[str, Any] = {"api_key": openai_key}
                base_url = os.environ.get("OPENAI_BASE_URL", "")
                if base_url:
                    kwargs["base_url"] = base_url
                client = OpenAI(**kwargs)
                model = os.environ.get("OWLMIND_OPENAI_PLANNER_MODEL", "deepseek-chat")
                resp = client.chat.completions.create(
                    model=model,
                    messages=[
                        {"role": "system", "content": self._SYSTEM_PROMPT},
                        {"role": "user", "content": meta_prompt},
                    ],
                    max_tokens=1024,
                )
                raw = resp.choices[0].message.content or ""
                suggestions = self._parse_llm_response(raw)
                if suggestions:
                    return suggestions
            except Exception:
                logger.debug("SelfImprover: OpenAI call failed, trying Anthropic", exc_info=True)

        anthropic_key = os.environ.get("ANTHROPIC_API_KEY", "")
        if anthropic_key:
            try:
                import anthropic  # type: ignore[import-not-found]

                client_a = anthropic.Anthropic(api_key=anthropic_key)
                model_a = os.environ.get("ANTHROPIC_MODEL", "claude-haiku-4-5-20251001")
                resp_a = client_a.messages.create(
                    model=model_a,
                    max_tokens=1024,
                    system=self._SYSTEM_PROMPT,
                    messages=[{"role": "user", "content": meta_prompt}],
                )
                raw = resp_a.content[0].text if resp_a.content else ""
                suggestions = self._parse_llm_response(raw)
                if suggestions:
                    return suggestions
            except Exception:
                logger.debug("SelfImprover: Anthropic call failed", exc_info=True)

        logger.info("SelfImprover: no LLM available, using heuristic fallback")
        return self._heuristic_suggestions(patterns, len(failed_tasks))

    _SYSTEM_PROMPT = (
        "You are an AI prompt-engineering expert. Given failure patterns from an "
        "autonomous coding agent (Planner→Worker→Judge pipeline), suggest concrete "
        "prompt additions for the planner, worker, or judge agents. "
        "Respond ONLY with a JSON array of objects, each having keys: "
        '"agent" (planner/worker/judge), "rationale", "suggested_addition", '
        '"confidence" (0-1), "pattern". No markdown fences.'
    )

    def _build_meta_prompt(
        self,
        patterns: dict[str, list[str]],
        failed_tasks: list[FailedTask],
    ) -> str:
        lines = [f"Total failures analyzed: {len(failed_tasks)}\n"]
        for pattern, examples in patterns.items():
            lines.append(f"## Pattern: {pattern} ({len(examples)} occurrences)")
            for ex in examples:
                lines.append(f"  - {ex}")
            lines.append("")
        return "\n".join(lines)

    def _parse_llm_response(self, raw: str) -> list[PromptSuggestion]:
        """Parse LLM JSON response into PromptSuggestion objects."""
        # Strip markdown fences if present
        text = raw.strip()
        if text.startswith("```"):
            text = text.split("\n", 1)[1] if "\n" in text else text[3:]
        if text.endswith("```"):
            text = text[:-3]
        text = text.strip()

        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            logger.warning("SelfImprover: could not parse LLM response as JSON")
            return []

        if not isinstance(data, list):
            return []

        suggestions: list[PromptSuggestion] = []
        for item in data:
            if not isinstance(item, dict):
                continue
            agent = item.get("agent", "")
            if agent not in ("planner", "worker", "judge"):
                continue
            suggestions.append(
                PromptSuggestion(
                    agent=agent,
                    rationale=str(item.get("rationale", "")),
                    suggested_addition=str(item.get("suggested_addition", "")),
                    confidence=float(item.get("confidence", 0.5)),
                    pattern=str(item.get("pattern", "")),
                )
            )
        return suggestions

    def _heuristic_suggestions(
        self,
        patterns: dict[str, list[str]],
        total_failures: int,
    ) -> list[PromptSuggestion]:
        """Rule-based fallback suggestions derived from detected failure patterns."""
        suggestions: list[PromptSuggestion] = []

        if "timeout" in patterns:
            suggestions.append(
                PromptSuggestion(
                    agent="planner",
                    pattern="timeout",
                    rationale=(
                        f"{len(patterns['timeout'])} task(s) timed out. "
                        "The planner may be generating overly complex plans."
                    ),
                    suggested_addition=(
                        "- Prefer minimal, targeted patches over large refactors.\n"
                        "- Limit verify_commands to at most 2 commands to reduce wall-clock time."
                    ),
                    confidence=0.7,
                )
            )

        if "patch_invalid" in patterns:
            suggestions.append(
                PromptSuggestion(
                    agent="worker",
                    pattern="patch_invalid",
                    rationale=(
                        f"{len(patterns['patch_invalid'])} task(s) produced invalid patches. "
                        "Ensure diffs are well-formed."
                    ),
                    suggested_addition=(
                        "- Always produce unified diffs with correct line numbers.\n"
                        "- Double-check that context lines in the diff match the actual file.\n"
                        "- Run `git diff --check` before submitting a patch."
                    ),
                    confidence=0.8,
                )
            )

        if "lm_output_unparseable" in patterns:
            suggestions.append(
                PromptSuggestion(
                    agent="planner",
                    pattern="lm_output_unparseable",
                    rationale=(
                        f"{len(patterns['lm_output_unparseable'])} response(s) could not be parsed. "
                        "Reinforce JSON-only output rule."
                    ),
                    suggested_addition=(
                        "- CRITICAL: Your entire response MUST be valid JSON. "
                        "No preamble, no trailing text, no markdown fences."
                    ),
                    confidence=0.9,
                )
            )

        if "test_failure" in patterns:
            suggestions.append(
                PromptSuggestion(
                    agent="worker",
                    pattern="test_failure",
                    rationale=(
                        f"{len(patterns['test_failure'])} task(s) failed tests. "
                        "Worker may not be running tests before submitting."
                    ),
                    suggested_addition=(
                        "- After applying changes, run the failing tests locally "
                        "and confirm they pass before finishing.\n"
                        "- Do not skip test verification steps."
                    ),
                    confidence=0.75,
                )
            )

        if not suggestions and total_failures > 0:
            # Generic catch-all
            suggestions.append(
                PromptSuggestion(
                    agent="planner",
                    pattern="unknown",
                    rationale=f"{total_failures} task(s) failed with unclassified errors.",
                    suggested_addition=(
                        "- When uncertain about the required change, prefer the smallest "
                        "plausible fix and rely on tests to validate."
                    ),
                    confidence=0.4,
                )
            )

        return suggestions

    def _append_record(self, record: ImprovementRecord) -> None:
        """Append an ImprovementRecord to the JSONL improvements log."""
        self._improvements_file.parent.mkdir(parents=True, exist_ok=True)
        line = json.dumps(record.to_dict())
        with self._improvements_file.open("a") as fh:
            fh.write(line + "\n")
        logger.debug("Improvement record appended to %s", self._improvements_file)
