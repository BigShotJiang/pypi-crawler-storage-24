"""Hard fail rules — automated pre-judge safety checks."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

import yaml

_DEFAULT_SECRET_PATTERNS: list[str] = [
    r"sk-[A-Za-z0-9]{20,}",
    r"(?i)api[_-]?key\s*[=:]\s*['\"]?\S{10,}",
    r"(?i)(secret|password|token)\s*[=:]\s*['\"]?\S{10,}",
    r"AKIA[0-9A-Z]{16}",
    r"-----BEGIN (RSA |EC |DSA |)PRIVATE KEY-----",
    r"(?i)bearer\s+[A-Za-z0-9._~+/=-]{20,}",
    r"ghp_[A-Za-z0-9]{36,}",
    r"gho_[A-Za-z0-9]{36,}",
]

_DEFAULT_FORBIDDEN_PATHS: list[str] = [
    ".github/workflows/",
    "deploy/",
    "infra/",
    "terraform/",
    "k8s/",
]

_DEFAULT_MAX_FILES_CHANGED = 20
_DEFAULT_MAX_INSERTIONS = 800
_DEFAULT_MAX_DELETIONS = 800


@dataclass
class HardFailResult:
    """Result of hard fail checks."""

    ok: bool
    reasons: list[str] = field(default_factory=list)
    risk_level: str = "LOW"


@dataclass
class JudgeRules:
    """Loaded judge rules from YAML config."""

    secret_patterns: list[re.Pattern[str]] = field(default_factory=list)
    forbidden_paths: list[str] = field(default_factory=list)
    max_files_changed: int = _DEFAULT_MAX_FILES_CHANGED
    max_insertions: int = _DEFAULT_MAX_INSERTIONS
    max_deletions: int = _DEFAULT_MAX_DELETIONS

    @classmethod
    def from_yaml(cls, path: Path) -> JudgeRules:
        """Load rules from a YAML file. Returns defaults if file is missing."""
        if not path.exists():
            return cls.defaults()
        data = yaml.safe_load(path.read_text()) or {}

        secret_pats = [re.compile(p) for p in data.get("secret_patterns", _DEFAULT_SECRET_PATTERNS)]
        forbidden = data.get("forbidden_paths", list(_DEFAULT_FORBIDDEN_PATHS))
        size = data.get("size_limits", {})

        return cls(
            secret_patterns=secret_pats,
            forbidden_paths=forbidden,
            max_files_changed=size.get("max_files_changed", _DEFAULT_MAX_FILES_CHANGED),
            max_insertions=size.get("max_insertions", _DEFAULT_MAX_INSERTIONS),
            max_deletions=size.get("max_deletions", _DEFAULT_MAX_DELETIONS),
        )

    @classmethod
    def defaults(cls) -> JudgeRules:
        """Return rules with compiled default patterns."""
        return cls(
            secret_patterns=[re.compile(p) for p in _DEFAULT_SECRET_PATTERNS],
            forbidden_paths=list(_DEFAULT_FORBIDDEN_PATHS),
        )


class HardFailChecker:
    """Automated pre-judge safety checks."""

    def __init__(self, rules: JudgeRules | None = None) -> None:
        self.rules = rules or JudgeRules.defaults()

    def check_secrets(self, content: str) -> list[str]:
        """Scan content for secret patterns."""
        findings: list[str] = []
        for pat in self.rules.secret_patterns:
            for match in pat.finditer(content):
                snippet = match.group()[:20] + "..."
                findings.append(f"Secret pattern matched: {snippet}")
        return findings

    def check_forbidden_paths(self, files_changed: list[str]) -> list[str]:
        """Check if any changed files are in forbidden paths."""
        findings: list[str] = []
        for fpath in files_changed:
            for forbidden in self.rules.forbidden_paths:
                if fpath.startswith(forbidden) or f"/{forbidden}" in fpath:
                    findings.append(f"Forbidden path touched: {fpath} (matches {forbidden})")
        return findings

    def check_size_limits(self, files_changed: int, insertions: int, deletions: int) -> list[str]:
        """Check diff size limits."""
        findings: list[str] = []
        if files_changed > self.rules.max_files_changed:
            findings.append(
                f"Too many files changed: {files_changed} > {self.rules.max_files_changed}"
            )
        if insertions > self.rules.max_insertions:
            findings.append(f"Too many insertions: {insertions} > {self.rules.max_insertions}")
        if deletions > self.rules.max_deletions:
            findings.append(f"Too many deletions: {deletions} > {self.rules.max_deletions}")
        return findings

    def check_all(
        self,
        *,
        diff_content: str = "",
        files_changed: list[str] | None = None,
        numstat: str = "",
        chain_ok: bool = True,
    ) -> HardFailResult:
        """Run all hard fail checks."""
        reasons: list[str] = []

        if diff_content:
            reasons.extend(self.check_secrets(diff_content))

        if files_changed:
            reasons.extend(self.check_forbidden_paths(files_changed))

        if numstat:
            total_files, total_ins, total_del = parse_numstat(numstat)
            reasons.extend(self.check_size_limits(total_files, total_ins, total_del))

        if not chain_ok:
            reasons.append("Evidence chain verification failed")

        risk = "LOW"
        if reasons:
            risk = "HIGH"
            for r in reasons:
                if "Secret" in r or "PRIVATE KEY" in r:
                    risk = "CRITICAL"
                    break

        return HardFailResult(ok=len(reasons) == 0, reasons=reasons, risk_level=risk)


def parse_numstat(numstat: str) -> tuple[int, int, int]:
    """Parse ``git diff --numstat`` output into ``(files, insertions, deletions)``."""
    files = 0
    insertions = 0
    deletions = 0
    for line in numstat.strip().splitlines():
        parts = line.split("\t")
        if len(parts) >= 3:
            files += 1
            try:
                insertions += int(parts[0]) if parts[0] != "-" else 0
                deletions += int(parts[1]) if parts[1] != "-" else 0
            except ValueError:
                continue
    return files, insertions, deletions
