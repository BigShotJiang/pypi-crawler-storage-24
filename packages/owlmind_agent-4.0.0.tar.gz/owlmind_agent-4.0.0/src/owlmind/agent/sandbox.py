"""Worktree sandbox — isolated workspace per run via git worktree."""

from __future__ import annotations

import shutil
from dataclasses import dataclass
from pathlib import Path

from owlmind.policy import PolicyEngine
from owlmind.tools.shell import ShellTool
from owlmind.utils import ToolLimits


@dataclass
class SandboxInfo:
    """Metadata about a sandbox workspace."""

    enabled: bool
    worktree_path: str = ""
    branch_name: str = ""
    base_head_sha: str = ""
    base_repo_path: str = ""
    kind: str = "none"  # "git-worktree" | "plain-dir" | "none"


def is_git_repo(workspace: str | Path) -> bool:
    """Check if *workspace* is inside a git repository."""
    git_dir = Path(workspace) / ".git"
    return git_dir.exists()


def create_sandbox(
    run_id: str,
    workspace: str,
    runs_dir: Path,
    policy: PolicyEngine,
    limits: ToolLimits | None = None,
) -> SandboxInfo:
    """Create an isolated sandbox for the given run.

    If *workspace* is a git repo, creates a git worktree.
    Otherwise, creates a plain directory.
    """
    limits = limits or ToolLimits()
    branch_name = f"owlmind/{run_id}"
    worktree_path = runs_dir / run_id / "worktree"

    if not is_git_repo(workspace):
        # Plain directory sandbox
        workdir = runs_dir / run_id / "workdir"
        workdir.mkdir(parents=True, exist_ok=True)
        return SandboxInfo(
            enabled=True,
            worktree_path=str(workdir),
            branch_name="",
            base_head_sha="",
            base_repo_path=str(workspace),
            kind="plain-dir",
        )

    shell = ShellTool(policy=policy, limits=limits, cwd=workspace)

    # Get current HEAD sha
    head_result = shell.run("git rev-parse HEAD")
    base_head_sha = head_result.stdout.strip() if head_result.exit_code == 0 else ""

    # Create worktree with new branch
    worktree_path.parent.mkdir(parents=True, exist_ok=True)
    wt_result = shell.run(f"git worktree add -b {branch_name} {worktree_path} HEAD")

    if wt_result.exit_code != 0:
        # Branch might already exist — try without -b
        wt_result = shell.run(f"git worktree add {worktree_path} {branch_name}")

    if wt_result.exit_code != 0:
        # Fallback to plain dir if worktree fails
        workdir = runs_dir / run_id / "workdir"
        workdir.mkdir(parents=True, exist_ok=True)
        return SandboxInfo(
            enabled=True,
            worktree_path=str(workdir),
            branch_name="",
            base_head_sha=base_head_sha,
            base_repo_path=str(workspace),
            kind="plain-dir",
        )

    return SandboxInfo(
        enabled=True,
        worktree_path=str(worktree_path),
        branch_name=branch_name,
        base_head_sha=base_head_sha,
        base_repo_path=str(workspace),
        kind="git-worktree",
    )


def cleanup_sandbox(
    run_id: str,
    workspace: str,
    runs_dir: Path,
    policy: PolicyEngine,
    limits: ToolLimits | None = None,
) -> tuple[bool, str]:
    """Remove sandbox worktree and branch. Returns ``(ok, message)``."""
    limits = limits or ToolLimits()
    worktree_path = runs_dir / run_id / "worktree"
    workdir_path = runs_dir / run_id / "workdir"
    branch_name = f"owlmind/{run_id}"

    if workdir_path.is_dir():
        shutil.rmtree(workdir_path, ignore_errors=True)
        return True, f"Removed plain directory: {workdir_path}"

    if not worktree_path.is_dir():
        return False, f"No sandbox found at {worktree_path}"

    if not is_git_repo(workspace):
        shutil.rmtree(worktree_path, ignore_errors=True)
        return True, f"Removed directory: {worktree_path}"

    shell = ShellTool(policy=policy, limits=limits, cwd=workspace)

    # Remove worktree
    result = shell.run(f"git worktree remove {worktree_path}")
    if result.exit_code != 0:
        # Force removal of directory if git command fails
        shutil.rmtree(worktree_path, ignore_errors=True)

    # Delete branch (best effort)
    shell.run(f"git branch -d {branch_name}")

    return True, f"Removed worktree: {worktree_path} (branch: {branch_name})"


def sandbox_status(
    run_id: str,
    runs_dir: Path,
) -> SandboxInfo:
    """Return sandbox status for a run without modifying anything."""
    worktree_path = runs_dir / run_id / "worktree"
    workdir_path = runs_dir / run_id / "workdir"
    branch_name = f"owlmind/{run_id}"

    if worktree_path.is_dir():
        return SandboxInfo(
            enabled=True,
            worktree_path=str(worktree_path),
            branch_name=branch_name,
            kind="git-worktree",
        )
    if workdir_path.is_dir():
        return SandboxInfo(
            enabled=True,
            worktree_path=str(workdir_path),
            kind="plain-dir",
        )
    return SandboxInfo(enabled=False, kind="none")
