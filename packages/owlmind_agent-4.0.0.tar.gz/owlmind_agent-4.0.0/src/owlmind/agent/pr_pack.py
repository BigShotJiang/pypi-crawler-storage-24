"""PR Pack builder — generates PR-ready markdown summary."""

from __future__ import annotations

from datetime import UTC, datetime


def build_pr_pack(
    *,
    run_id: str,
    goal: str,
    iteration: int,
    planner_plan_summary: list[str],
    worker_done_summary: list[str],
    verify_results: list[str],
    hard_fail_ok: bool = True,
    hard_fail_reasons: list[str] | None = None,
    diff_stat: str = "",
    files_changed: list[str] | None = None,
    risk_notes: list[str] | None = None,
    verify_commands: list[str] | None = None,
    manifest_sha256: str = "",
    chain_tip_hash: str = "",
    evidence_paths: list[str] | None = None,
) -> str:
    """Generate a PR-ready markdown pack."""
    now = datetime.now(tz=UTC).isoformat()

    lines: list[str] = [
        f"# PR Pack \u2014 {run_id}",
        "",
        f"Generated: {now}",
        f"Status: {'PASS' if hard_fail_ok else 'HARD FAIL'}",
        f"Iteration: {iteration}",
        "",
    ]

    # PR Description
    lines.append("## PR Description")
    lines.append("")
    lines.append(f"**Goal:** {goal}")
    lines.append("")
    if worker_done_summary:
        lines.append("**Changes:**")
        for item in worker_done_summary:
            lines.append(f"- {item}")
        lines.append("")

    # Plan
    if planner_plan_summary:
        lines.append("## Plan")
        for i, step in enumerate(planner_plan_summary, 1):
            lines.append(f"{i}. {step}")
        lines.append("")

    # Verification Results
    if verify_results:
        lines.append("## Verification Results")
        for vr in verify_results:
            icon = "+" if "PASS" in vr else "-"
            lines.append(f"  {icon} {vr}")
        lines.append("")

    # Hard Fail Status
    if not hard_fail_ok:
        lines.append("## Hard Fail (BLOCKED)")
        for reason in hard_fail_reasons or []:
            lines.append(f"- {reason}")
        lines.append("")

    # Diff Stats
    if diff_stat:
        lines.append("## Diff Stats")
        lines.append("```")
        lines.append(diff_stat.strip())
        lines.append("```")
        lines.append("")

    if files_changed:
        lines.append("## Files Changed")
        for f in files_changed:
            lines.append(f"- `{f}`")
        lines.append("")

    # Risk Notes
    if risk_notes:
        lines.append("## Risk Notes")
        for note in risk_notes:
            lines.append(f"- {note}")
        lines.append("")

    # How to Test
    lines.append("## How to Test")
    if verify_commands:
        lines.append("```bash")
        for cmd in verify_commands:
            lines.append(cmd)
        lines.append("```")
    else:
        lines.append("No verify commands specified.")
    lines.append("")

    # Evidence
    lines.append("## Evidence")
    if manifest_sha256:
        lines.append(f"- Manifest SHA-256: `{manifest_sha256}`")
    if chain_tip_hash:
        lines.append(f"- Chain tip hash: `{chain_tip_hash}`")
    if evidence_paths:
        lines.append("- Artifacts:")
        for ep in evidence_paths:
            lines.append(f"  - `{ep}`")
    lines.append("")

    return "\n".join(lines)
