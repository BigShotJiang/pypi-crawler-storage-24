"""CycleJudge — judge prompt builder for the OWLMIND Planner/Worker/Judge cycle."""

from __future__ import annotations

from owlmind.agent.schemas import JudgeRequest


def _build_judge_prompt(req: JudgeRequest) -> str:
    # Build grounded evidence section from full verify output
    grounded_section = ""
    if req.verify_details:
        lines = ["## Grounded Verify Evidence (actual command output)"]
        for d in req.verify_details:
            icon = "✅ PASS" if d.passed else "❌ FAIL"
            lines.append(f"\n### `{d.cmd}` — {icon} (exit {d.exit_code})")
            if d.stdout.strip():
                lines.append(f"**stdout:**\n```\n{d.stdout.strip()}\n```")
            if d.stderr.strip():
                lines.append(f"**stderr:**\n```\n{d.stderr.strip()}\n```")
            if not d.stdout.strip() and not d.stderr.strip():
                lines.append("_(no output)_")
        grounded_section = "\n".join(lines)

    diff_section = ""
    if req.git_diff_summary:
        diff_section = f"""## Grounded Git Diff (actual changes made)
```diff
{req.git_diff_summary}
```"""

    goal_section = f"**Goal:** {req.goal}"
    plan_section = ""
    if req.planner_plan_summary:
        plan_section = "**Plan:**\n" + "\n".join(f"- {s}" for s in req.planner_plan_summary)
    worker_section = ""
    if req.worker_done_summary:
        worker_section = "**Worker claims:**\n" + "\n".join(f"- {s}" for s in req.worker_done_summary)

    return f"""# OWLMIND — Judge Prompt

You are a strict code reviewer with access to GROUNDED EVIDENCE (actual command output and git diff).
Your verdict must be based on facts, not the Worker's claims.

## RULES
- Return ONLY valid JSON matching the **JudgeResponse** schema below.
- Do NOT include any text outside the JSON block.
- Trust ONLY the grounded evidence below, not the Worker's words.
- If ANY verify command FAILED → verdict MUST be "NEEDS_FIX".
- In next_worker_instructions: cite the EXACT error lines from the output above.
- If security issues found → verdict MUST be "REJECTED".
- **If ALL verify commands PASSED → verdict MUST be "APPROVED".** The passing tests ARE the ground truth. Do NOT second-guess the implementation approach if tests pass.
- Do NOT reject a fix because you disagree with the implementation style, return type, or approach — if tests pass, it is correct.

## JudgeResponse Schema
```json
{{
  "run_id": "{req.run_id}",
  "iteration": {req.iteration},
  "verdict": "APPROVED",
  "notes": ["Specific observation based on evidence..."],
  "next_worker_instructions": "Exact fix instructions citing specific errors from output above",
  "evidence_chain_verified": true
}}
```

verdict must be one of: "APPROVED", "NEEDS_FIX", "REJECTED"

---

## Task Context

{goal_section}

{plan_section}

{worker_section}

---

{grounded_section}

{diff_section}

---

Return ONLY the JSON response. No markdown, no explanation.
"""
