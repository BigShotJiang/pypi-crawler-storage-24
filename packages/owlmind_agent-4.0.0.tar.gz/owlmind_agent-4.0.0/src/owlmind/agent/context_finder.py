"""
context_finder.py
-----------------
Finds relevant files in a workspace based on keywords extracted from a goal string.

Standalone module — no owlmind imports required.
"""

from __future__ import annotations

import os
import re
import subprocess

__all__ = ["find_relevant_files"]

# ---------------------------------------------------------------------------
# Stop-word list
# ---------------------------------------------------------------------------
_STOP_WORDS: frozenset[str] = frozenset(
    {
        "the", "a", "an", "is", "are", "was", "were", "be", "to", "of",
        "in", "on", "at", "for", "with", "this", "that", "it", "as", "by",
        "or", "and", "not", "all", "any", "from", "but", "if", "do",
        "does", "did", "will", "would", "can", "could", "should", "have",
        "has", "had", "been", "also", "only", "each", "its", "use",
        "using", "run", "running", "make", "add", "fix", "more", "less",
        "than", "then", "when", "where", "how", "why", "what", "which",
        "who", "just", "new", "old", "up", "get", "set", "put", "let",
        "may", "might", "must", "shall",
    }
)

# ---------------------------------------------------------------------------
# Path fragments / patterns that indicate non-code files to exclude
# ---------------------------------------------------------------------------
_EXCLUDE_FRAGMENTS: tuple[str, ...] = (
    "__pycache__",
    ".git",
    ".venv",
    "node_modules",
    "logs/",
    ".egg-info",
)

_EXCLUDE_SUFFIXES: tuple[str, ...] = (
    ".pyc",
    ".log",
)


def _extract_keywords(goal: str) -> list[str]:
    """
    Split *goal* on whitespace, lower-case each token, strip non-alphanumeric
    characters, remove stop words, and keep only tokens with length >= 4.

    Returns a deduplicated list preserving first-seen order.
    """
    seen: set[str] = set()
    keywords: list[str] = []
    for raw_token in goal.split():
        token = re.sub(r"[^a-z0-9]", "", raw_token.lower())
        if len(token) >= 4 and token not in _STOP_WORDS and token not in seen:
            seen.add(token)
            keywords.append(token)
    return keywords


def _is_excluded(path: str) -> bool:
    """Return True if *path* matches any exclusion rule."""
    for fragment in _EXCLUDE_FRAGMENTS:
        if fragment in path:
            return True
    return any(path.endswith(suffix) for suffix in _EXCLUDE_SUFFIXES)


def _grep_files(keyword: str, workspace: str) -> list[str]:
    """
    Run ``grep -rl <keyword> <workspace>`` with a 5-second timeout.

    Returns the list of matching file paths, or [] on any error.
    """
    try:
        result = subprocess.run(
            ["grep", "-rl", keyword, workspace],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode not in (0, 1):
            # returncode 1 means no matches; anything else is an error
            return []
        lines = [line.strip() for line in result.stdout.splitlines() if line.strip()]
        return lines
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return []


def _read_snippet(path: str, length: int = 300) -> str:
    """
    Return the first *length* characters of the file at *path*.

    Returns an empty string if the file cannot be read.
    """
    try:
        with open(path, encoding="utf-8", errors="replace") as fh:
            return fh.read(length)
    except OSError:
        return ""


def find_relevant_files(
    goal: str,
    workspace: str,
    max_files: int = 5,
) -> list[dict]:
    """
    Find files in *workspace* that are relevant to *goal*.

    Steps
    -----
    1. Extract keywords from *goal* (stop-word filtered, len >= 4).
    2. For each keyword run ``grep -rl`` inside *workspace*.
    3. Score each file by the number of distinct keywords it matches.
    4. Exclude non-code paths (__pycache__, .git, .venv, node_modules, etc.).
    5. Return the top *max_files* results as::

           [{"path": str, "score": int, "snippet": str}, ...]

    Returns ``[]`` if *workspace* does not exist, grep is unavailable, or any
    unrecoverable error occurs.

    Parameters
    ----------
    goal:
        Natural-language description of what the agent is trying to do.
    workspace:
        Absolute (or relative) path to the directory tree to search.
    max_files:
        Maximum number of results to return (default 5).
    """
    try:
        # Guard: workspace must exist
        if not os.path.isdir(workspace):
            return []

        keywords = _extract_keywords(goal)
        if not keywords:
            return []

        # Map path -> set of keywords that matched it
        file_keyword_hits: dict[str, set[str]] = {}

        for keyword in keywords:
            matched_paths = _grep_files(keyword, workspace)
            for path in matched_paths:
                if _is_excluded(path):
                    continue
                file_keyword_hits.setdefault(path, set()).add(keyword)

        if not file_keyword_hits:
            return []

        # Sort by score descending, then by path for stable ordering
        ranked = sorted(
            file_keyword_hits.items(),
            key=lambda item: (-len(item[1]), item[0]),
        )

        results: list[dict] = []
        for path, hits in ranked[:max_files]:
            results.append(
                {
                    "path": path,
                    "score": len(hits),
                    "snippet": _read_snippet(path),
                }
            )

        return results

    except Exception:
        return []
