"""CycleWorker — worker prompt builder for the OWLMIND Planner/Worker/Judge cycle."""

from __future__ import annotations

from owlmind.agent.schemas import WorkerRequest


def _build_worker_prompt(req: WorkerRequest) -> str:
    req_json = req.model_dump_json(indent=2)

    repo_map_section = ""
    if req.repo_map:
        repo_map_section = f"""
## Codebase Structure (RepoMap)
Use this map to understand the codebase before making changes.

```
{req.repo_map}
```
"""

    relevant_files_section = ""
    if req.relevant_files:
        lines = ["## Relevant Files (auto-detected from goal)\n"]
        for f in req.relevant_files:
            path = f.get("path", "")
            snippet = f.get("snippet", "")
            score = f.get("score", 0)
            lines.append(f"### {path} (score: {score})\n```\n{snippet}\n```\n")
        relevant_files_section = "\n".join(lines)

    return f"""# OWLMIND \u2014 Worker Prompt (Claude Code)

You are a Worker. Execute the instructions below and return a structured report.

## RULES
- Return ONLY valid JSON matching the **WorkerReport** schema below.
- Do NOT include any text outside the JSON block.
- Do not force push, delete files without approval, or run destructive commands.
- Maximum 3 questions if blocked.

## WorkerReport Schema
```json
{{
  "run_id": "{req.run_id}",
  "iteration": {req.iteration},
  "status": "READY_FOR_VERIFY",
  "done_summary": ["What was done..."],
  "questions": [],
  "commands_run": [{{"cmd": "...", "exit_code": 0, "summary": "..."}}]
}}
```
{repo_map_section}
{relevant_files_section}
## Request
```json
{req_json}
```

Return ONLY the JSON response. No markdown, no explanation.
"""
