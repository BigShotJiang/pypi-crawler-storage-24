"""Evidence tracking helpers (extracted from CycleManager).

Provides git-evidence capture, PR-pack generation, and zip export as a mixin.
"""

from __future__ import annotations

import json
import logging
import zipfile
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from owlmind.agent.meta_store import CycleMetaStore
    from owlmind.agent.schemas import CycleRunMeta
    from owlmind.evidence import EvidenceStore
    from owlmind.policy import PolicyEngine
    from owlmind.utils import ToolLimits

from owlmind.agent.pr_pack import build_pr_pack
from owlmind.tools.shell import ShellTool
from owlmind.utils import sha256

logger = logging.getLogger(__name__)


class EvidenceTrackerMixin:
    """Mixin providing evidence capture, PR-pack generation, and export.

    Expects the host class to expose:
        - ``self.evidence: EvidenceStore``
        - ``self.meta_store: CycleMetaStore``
        - ``self.policy: PolicyEngine``
        - ``self.limits: ToolLimits``
        - ``self._run_dir(run_id) -> Path``
        - ``self._load_meta(run_id) -> CycleRunMeta``
    """

    evidence: EvidenceStore
    meta_store: CycleMetaStore
    policy: PolicyEngine
    limits: ToolLimits

    # ------------------------------------------------------------------
    # Git evidence capture
    # ------------------------------------------------------------------

    def _capture_git_evidence(self, run_id: str, workspace: str) -> tuple[str, str, list[str]]:
        """Capture git diff evidence. Returns ``(diff, numstat, files_changed)``."""
        git_dir = Path(workspace) / ".git"
        if not git_dir.is_dir():
            return "", "", []

        shell = ShellTool(policy=self.policy, limits=self.limits, cwd=workspace)

        head_result = shell.run("git rev-parse HEAD")
        if head_result.exit_code == 0:
            self.evidence.write_artifact(run_id, "git_head.txt", head_result.stdout.strip())

        stat_result = shell.run("git diff --stat")
        diff_stat = stat_result.stdout if stat_result.exit_code == 0 else ""
        if diff_stat:
            self.evidence.write_artifact(run_id, "git_diff_stat.txt", diff_stat)

        diff_result = shell.run("git diff")
        diff_content = diff_result.stdout if diff_result.exit_code == 0 else ""
        if diff_content:
            self.evidence.write_artifact(run_id, "git_diff.patch", diff_content)

        numstat_result = shell.run("git diff --numstat")
        numstat = numstat_result.stdout if numstat_result.exit_code == 0 else ""
        if numstat:
            self.evidence.write_artifact(run_id, "git_numstat.txt", numstat)

        files_changed: list[str] = []
        for line in numstat.strip().splitlines():
            parts = line.split("\t")
            if len(parts) >= 3:
                files_changed.append(parts[2])

        return diff_content, numstat, files_changed

    # ------------------------------------------------------------------
    # PR-pack generation
    # ------------------------------------------------------------------

    def _generate_pr_pack(
        self,
        meta: CycleRunMeta,
        verify_results: list[str],
        run_id: str,
        *,
        manifest_sha256: str = "",
    ) -> str:
        """Generate and write the PR pack markdown."""
        if not manifest_sha256:
            manifest_path = self._run_dir(run_id) / "evidence" / "manifest.json"  # type: ignore[attr-defined]
            if manifest_path.exists():
                manifest_data: dict[str, object] = json.loads(manifest_path.read_text())
                manifest_sha256 = str(manifest_data.get("manifest_sha256", ""))

        diff_stat = ""
        diff_stat_path = self._run_dir(run_id) / "artifacts" / "git_diff_stat.txt"  # type: ignore[attr-defined]
        if diff_stat_path.exists():
            diff_stat = diff_stat_path.read_text()

        files_changed: list[str] = []
        numstat_path = self._run_dir(run_id) / "artifacts" / "git_numstat.txt"  # type: ignore[attr-defined]
        if numstat_path.exists():
            for line in numstat_path.read_text().strip().splitlines():
                parts = line.split("\t")
                if len(parts) >= 3:
                    files_changed.append(parts[2])

        evidence_paths: list[str] = []
        art_dir = self._run_dir(run_id) / "artifacts"  # type: ignore[attr-defined]
        if art_dir.exists():
            evidence_paths = [
                f"artifacts/{p.name}" for p in sorted(art_dir.iterdir()) if p.is_file()
            ]

        content = build_pr_pack(
            run_id=run_id,
            goal=meta.goal,
            iteration=meta.iteration,
            planner_plan_summary=meta.planner_plan_summary,
            worker_done_summary=meta.worker_done_summary,
            verify_results=verify_results,
            hard_fail_ok=len(meta.hard_fail_reasons) == 0,
            hard_fail_reasons=meta.hard_fail_reasons,
            diff_stat=diff_stat,
            files_changed=files_changed,
            verify_commands=meta.verify_commands,
            manifest_sha256=manifest_sha256,
            chain_tip_hash=meta.chain_tip_hash,
            evidence_paths=evidence_paths,
        )

        pack_path = self._run_dir(run_id) / "pr_pack.md"  # type: ignore[attr-defined]
        pack_path.write_text(content)
        return content

    # ------------------------------------------------------------------
    # Zip export
    # ------------------------------------------------------------------

    def export(self, run_id: str, out_path: Path | None = None) -> Path:
        """Create a zip export of the run folder. Returns path to zip file."""
        run_dir = self._run_dir(run_id)  # type: ignore[attr-defined]
        if not run_dir.exists():
            msg = f"Run not found: {run_id}"
            raise FileNotFoundError(msg)

        if out_path is None:
            out_path = run_dir / f"owlmind_export_{run_id}.zip"

        out_path.parent.mkdir(parents=True, exist_ok=True)

        include_patterns = {
            "run.jsonl",
            "summary.json",
            "pr_pack.md",
            "cycle_meta.json",
        }
        include_dirs = {"evidence", "outbox", "inbox", "artifacts"}

        with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for item in sorted(run_dir.rglob("*")):
                if not item.is_file():
                    continue
                rel = item.relative_to(run_dir)
                parts = rel.parts
                if parts[0] in ("worktree", "workdir"):
                    continue
                if str(rel).endswith(".zip"):
                    continue
                if rel.name in include_patterns or (parts[0] in include_dirs):
                    zf.write(item, str(rel))

        # Record in evidence chain
        zip_data = out_path.read_bytes()
        zip_hash = sha256(zip_data)
        self.evidence.append_event(
            run_id,
            {
                "event": "EXPORT_CREATED",
                "path": str(out_path),
                "sha256": zip_hash,
                "bytes": len(zip_data),
            },
        )

        return out_path

    # ------------------------------------------------------------------
    # PR Pack (public, for CLI)
    # ------------------------------------------------------------------

    def generate_pr_pack(self, run_id: str) -> str:
        """Generate or regenerate PR pack for an existing run."""
        meta = self._load_meta(run_id)  # type: ignore[attr-defined]
        manifest_sha256 = ""
        manifest_path = self._run_dir(run_id) / "evidence" / "manifest.json"  # type: ignore[attr-defined]
        if manifest_path.exists():
            manifest_data: dict[str, object] = json.loads(manifest_path.read_text())
            manifest_sha256 = str(manifest_data.get("manifest_sha256", ""))
        return self._generate_pr_pack(
            meta,
            meta.verify_results,
            run_id,
            manifest_sha256=manifest_sha256,
        )
