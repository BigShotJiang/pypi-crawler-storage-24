"""Smart Verify — git-aware test selection for verify commands (FS56)."""

from __future__ import annotations

import logging
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)

# Files to always append after test commands
_ALWAYS_CMDS = ["ruff check .", "mypy ."]


def suggest_smart_verify(
    workspace: str | Path,
    *,
    max_files: int = 8,
) -> list[str]:
    """Suggest verify commands based on git-changed files.

    Logic:
    1. Run ``git diff --name-only HEAD`` to find changed files.
    2. If ≤ max_files Python source files changed → map each to a test file.
    3. If matching test files exist → run ``pytest <files> -q``.
    4. Otherwise → ``pytest -q`` (full suite).
    5. Always append ``ruff check .`` and ``mypy .``.

    Returns an empty list if workspace is not a git repo or git is unavailable
    (caller should fall back to profile-based suggestions).
    """
    workspace_path = Path(workspace).resolve()

    # --- Git diff — None means "not a git workspace / git unavailable" ---
    changed_py = _git_changed_py_files(workspace_path)
    if changed_py is None:
        return []

    reason = "full suite (no git diff)"
    pytest_cmd = "pytest -q"

    if changed_py and len(changed_py) <= max_files:
        test_files = _map_to_test_files(changed_py, workspace_path)
        if test_files:
            files_str = " ".join(sorted(test_files))
            pytest_cmd = f"pytest {files_str} -q"
            reason = (
                f"smart: {len(test_files)} test file(s) from {len(changed_py)} changed src file(s)"
            )
        else:
            reason = f"full suite ({len(changed_py)} changed files, no test matches)"
    elif changed_py:
        reason = f"full suite ({len(changed_py)} changed files > max_files={max_files})"

    logger.info("SmartVerify: %s → %s", reason, pytest_cmd)
    return [pytest_cmd, *_ALWAYS_CMDS]


def _git_changed_py_files(workspace: Path) -> list[str] | None:
    """Return list of changed .py files from ``git diff --name-only HEAD``.

    Returns:
        ``None`` if workspace is not a git repo or git is unavailable
        (signals caller to use a fallback strategy).
        ``[]`` if git is available but no Python files changed.
        ``[files...]`` if there are changed Python files.
    """
    git_dir = workspace / ".git"
    if not git_dir.is_dir():
        return None

    try:
        result = subprocess.run(
            ["git", "diff", "--name-only", "HEAD"],
            cwd=str(workspace),
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        logger.debug("SmartVerify: git diff failed, falling back to full suite")
        return None

    if result.returncode != 0:
        # Possibly no commits yet or git error → signal caller to fall back
        return None

    lines = [line.strip() for line in result.stdout.splitlines() if line.strip()]
    return [f for f in lines if f.endswith(".py")]


def _map_to_test_files(src_files: list[str], workspace: Path) -> list[str]:
    """Map source file paths to existing test file paths.

    Heuristic:
    - ``src/owlmind/foo/bar.py`` → ``tests/test_bar.py``
    - ``owlmind/foo/bar.py`` → ``tests/test_bar.py``
    - ``foo/bar.py`` → ``tests/test_bar.py``

    Only returns test files that actually exist.
    """
    found: set[str] = set()
    for src in src_files:
        stem = Path(src).stem  # e.g. "bar"
        candidate_name = f"test_{stem}.py"
        # Search in tests/ directory
        tests_dir = workspace / "tests"
        if tests_dir.is_dir():
            candidate = tests_dir / candidate_name
            if candidate.exists():
                found.add(f"tests/{candidate_name}")
                continue
            # Recursive search in tests/
            for match in tests_dir.rglob(candidate_name):
                rel = match.relative_to(workspace)
                found.add(str(rel))
                break
    return list(found)
