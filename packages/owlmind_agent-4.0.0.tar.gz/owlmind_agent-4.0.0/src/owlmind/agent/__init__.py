"""OWLMIND agent — manual inbox/outbox cycle integration."""
