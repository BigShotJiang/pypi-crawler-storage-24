"""Human-in-the-loop diff preview and partial approval for agent runs."""

from __future__ import annotations

import contextlib
import difflib
import logging
import os
import shutil
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

# File extensions considered high-risk (config, CI, security-related)
_HIGH_RISK_EXTENSIONS = frozenset({
    ".yml", ".yaml", ".toml", ".cfg", ".ini", ".env",
    ".json", ".lock", ".dockerfile", ".tf", ".hcl",
})

_HIGH_RISK_FILENAMES = frozenset({
    "Makefile", "Dockerfile", "docker-compose.yml",
    "pyproject.toml", "setup.py", "setup.cfg",
    ".gitignore", ".dockerignore", ".env", ".env.local", ".env.production",
    "requirements.txt", "Pipfile", "Pipfile.lock",
    "Cargo.toml", "Cargo.lock",
    "package.json", "package-lock.json",
})

# Large change threshold (lines changed)
_LARGE_CHANGE_THRESHOLD = 100


@dataclass
class FileDiff:
    """Represents the diff for a single file."""

    path: str
    old_content: str
    new_content: str
    diff_text: str
    risk_level: str = "low"  # low / medium / high


@dataclass
class ApplyResult:
    """Result of a partial approval operation."""

    applied_files: list[str] = field(default_factory=list)
    rejected_files: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Risk classification
# ---------------------------------------------------------------------------


def classify_risk(diff: FileDiff) -> str:
    """Auto-classify risk level based on file type and change size.

    Rules:
    - High: config files, CI files, security-sensitive files, or very large diffs
    - Medium: moderate-size diffs (> 20 lines) or test files
    - Low: everything else

    Args:
        diff: The file diff to classify.

    Returns:
        Risk level string: "low", "medium", or "high".
    """
    filename = Path(diff.path).name
    ext = Path(diff.path).suffix.lower()

    # Count changed lines
    changed_lines = sum(
        1 for line in diff.diff_text.splitlines()
        if line.startswith("+") or line.startswith("-")
    )

    # High risk: config/CI files or very large changes
    if ext in _HIGH_RISK_EXTENSIONS or filename in _HIGH_RISK_FILENAMES:
        return "high"
    if changed_lines >= _LARGE_CHANGE_THRESHOLD:
        return "high"

    # Medium risk: moderate changes or test files
    if changed_lines > 20:
        return "medium"
    if "test" in diff.path.lower() or "spec" in diff.path.lower():
        return "medium"

    return "low"


# ---------------------------------------------------------------------------
# DiffReview class
# ---------------------------------------------------------------------------


class DiffReview:
    """Generate diffs and apply partial approvals for agent workspaces.

    The workspace is a directory where the agent has made changes.
    The run directory contains a ``workspace_snapshot/`` subdirectory
    with the original file contents captured before the run started.
    """

    def generate_diff(self, workspace: str, run_id: str) -> list[FileDiff]:
        """Generate diffs between the workspace snapshot and current state.

        Compares files in ``{workspace}/.owlmind/snapshots/{run_id}/``
        (the pre-run snapshot) against the current workspace contents.

        Args:
            workspace: Path to the working directory.
            run_id: The run identifier (used to locate the snapshot).

        Returns:
            List of FileDiff objects, one per changed file.
        """
        ws = Path(workspace)
        snapshot_dir = ws / ".owlmind" / "snapshots" / run_id

        diffs: list[FileDiff] = []

        if not snapshot_dir.is_dir():
            # No snapshot — compare against empty for all tracked files
            logger.warning("No snapshot found at %s; generating diffs from scratch", snapshot_dir)
            return self._diff_from_scratch(ws, run_id)

        # Collect all file paths from both snapshot and workspace
        snapshot_files = self._collect_files(snapshot_dir)
        workspace_files = self._collect_files(ws, exclude_dirs={".owlmind", ".git", "__pycache__", "node_modules"})

        all_paths = sorted(set(snapshot_files) | set(workspace_files))

        for rel_path in all_paths:
            old_path = snapshot_dir / rel_path
            new_path = ws / rel_path

            old_content = ""
            new_content = ""

            if old_path.is_file():
                with contextlib.suppress(OSError):
                    old_content = old_path.read_text(errors="replace")

            if new_path.is_file():
                with contextlib.suppress(OSError):
                    new_content = new_path.read_text(errors="replace")

            # Skip unchanged files
            if old_content == new_content:
                continue

            diff_text = self._unified_diff(old_content, new_content, rel_path)
            fd = FileDiff(
                path=rel_path,
                old_content=old_content,
                new_content=new_content,
                diff_text=diff_text,
            )
            fd.risk_level = classify_risk(fd)
            diffs.append(fd)

        return diffs

    def apply_partial(
        self,
        workspace: str,
        approved_files: list[str],
        rejected_files: list[str],
        run_id: str = "",
    ) -> ApplyResult:
        """Apply partial approval: keep approved changes, revert rejected ones.

        For rejected files, restores content from the snapshot. If no snapshot
        exists for a rejected file (i.e. it was newly created), the file is
        deleted.

        Args:
            workspace: Path to the working directory.
            approved_files: Relative paths of files whose changes are accepted.
            rejected_files: Relative paths of files whose changes should be reverted.
            run_id: The run identifier (used to locate the snapshot).

        Returns:
            ApplyResult with lists of applied, rejected, and errored files.
        """
        ws = Path(workspace)
        snapshot_dir = ws / ".owlmind" / "snapshots" / run_id

        result = ApplyResult()

        # Approved files — no action needed, changes are already in place
        result.applied_files = list(approved_files)

        # Rejected files — revert to snapshot
        for rel_path in rejected_files:
            try:
                snapshot_file = snapshot_dir / rel_path
                target_file = ws / rel_path

                if snapshot_file.is_file():
                    # Restore original content
                    target_file.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(str(snapshot_file), str(target_file))
                    result.rejected_files.append(rel_path)
                elif target_file.is_file():
                    # File was newly created — delete it
                    target_file.unlink()
                    result.rejected_files.append(rel_path)
                else:
                    result.rejected_files.append(rel_path)
            except OSError as exc:
                error_msg = f"Failed to revert {rel_path}: {exc}"
                logger.error(error_msg)
                result.errors.append(error_msg)

        return result

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _diff_from_scratch(self, workspace: Path, run_id: str) -> list[FileDiff]:
        """Generate diffs when no snapshot exists (treat all files as new)."""
        diffs: list[FileDiff] = []
        files = self._collect_files(workspace, exclude_dirs={".owlmind", ".git", "__pycache__", "node_modules"})

        for rel_path in sorted(files):
            fpath = workspace / rel_path
            try:
                content = fpath.read_text(errors="replace")
            except OSError:
                continue

            diff_text = self._unified_diff("", content, rel_path)
            fd = FileDiff(
                path=rel_path,
                old_content="",
                new_content=content,
                diff_text=diff_text,
            )
            fd.risk_level = classify_risk(fd)
            diffs.append(fd)

        return diffs

    @staticmethod
    def _collect_files(
        directory: Path,
        exclude_dirs: set[str] | None = None,
    ) -> set[str]:
        """Collect relative file paths under a directory."""
        exclude = exclude_dirs or set()
        result: set[str] = set()

        if not directory.is_dir():
            return result

        for root, dirs, files in os.walk(directory):
            # Prune excluded directories
            dirs[:] = [d for d in dirs if d not in exclude]
            for f in files:
                full = Path(root) / f
                rel = str(full.relative_to(directory))
                result.add(rel)

        return result

    @staticmethod
    def _unified_diff(old: str, new: str, filename: str) -> str:
        """Generate unified diff text."""
        old_lines = old.splitlines(keepends=True)
        new_lines = new.splitlines(keepends=True)
        diff = difflib.unified_diff(
            old_lines,
            new_lines,
            fromfile=f"a/{filename}",
            tofile=f"b/{filename}",
        )
        return "".join(diff)
