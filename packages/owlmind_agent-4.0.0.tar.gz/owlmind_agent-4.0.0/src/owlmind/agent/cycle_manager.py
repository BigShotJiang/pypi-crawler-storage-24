"""CycleManager — orchestrator for the OWLMIND Planner/Worker/Judge cycle."""

from __future__ import annotations

import contextlib
import json
import logging
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from owlmind.memory.store import MemoryStore

from pydantic import BaseModel

from owlmind.agent.approval_flow import ApprovalFlowMixin
from owlmind.agent.cycle_judge import _build_judge_prompt
from owlmind.agent.cycle_planner import _build_planner_prompt
from owlmind.agent.cycle_worker import _build_worker_prompt
from owlmind.agent.evidence_tracker import EvidenceTrackerMixin
from owlmind.agent.llm_runner import CycleLLMRunner
from owlmind.agent.meta_store import CycleMetaStore
from owlmind.agent.profile import RepoProfile, detect_profile
from owlmind.agent.rules import HardFailChecker, JudgeRules
from owlmind.agent.sandbox import SandboxInfo, create_sandbox
from owlmind.agent.sandbox_lifecycle import SandboxLifecycleMixin
from owlmind.agent.schemas import (
    CycleLimits,
    CycleRunMeta,
    CycleState,
    JudgeRequest,
    JudgeResponse,
    PlannerRequest,
    PlannerResponse,
    VerifyCommandDetail,
    WorkerReport,
    WorkerRequest,
)
from owlmind.evidence import EvidenceStore
from owlmind.policy import PolicyDecision, PolicyEngine
from owlmind.tools.shell import ShellTool
from owlmind.utils import ToolLimits

try:
    from owlmind.skills.registry import get_pack_context, list_packs

    _SKILLS_AVAILABLE = True
except ImportError:
    _SKILLS_AVAILABLE = False

try:
    from owlmind.memory.retrieval import build_memory_context as _build_memory_context

    _MEMORY_RETRIEVAL_AVAILABLE = True
except ImportError:
    _MEMORY_RETRIEVAL_AVAILABLE = False

try:
    from owlmind.agent.goal_refiner import RefinedGoal
    from owlmind.agent.goal_refiner import refine_goal as _refine_goal

    _GOAL_REFINER_AVAILABLE = True
except ImportError:
    _GOAL_REFINER_AVAILABLE = False

try:
    from owlmind.agent.smart_verify import suggest_smart_verify as _suggest_smart_verify

    _SMART_VERIFY_AVAILABLE = True
except ImportError:
    _SMART_VERIFY_AVAILABLE = False

try:
    from owlmind.llm.complexity import classify_goal as _classify_goal

    _COMPLEXITY_AVAILABLE = True
except ImportError:
    _COMPLEXITY_AVAILABLE = False

try:
    from owlmind.ast_parser.analyzer import CodeAnalyzer as _CodeAnalyzer

    _REPO_MAP_AVAILABLE = True
except ImportError:
    _REPO_MAP_AVAILABLE = False

try:
    from owlmind.agent.context_finder import find_relevant_files as _find_relevant_files
    _CONTEXT_FINDER_AVAILABLE = True
except ImportError:
    _CONTEXT_FINDER_AVAILABLE = False

logger = logging.getLogger(__name__)


class CycleManager(
    ApprovalFlowMixin,
    EvidenceTrackerMixin,
    SandboxLifecycleMixin,
):
    """Drives the manual Planner -> Worker -> Judge cycle.

    Storage layout per run::

        runs/<run_id>/
            cycle_meta.json
            pr_pack.md
            outbox/
                planner_prompt.md
                worker_prompt.md
                judge_prompt.md
            inbox/
                planner_response.json
                worker_report.json
                judge_response.json
            artifacts/
            evidence/
                manifest.json
            worktree/           (if sandbox enabled + git repo)
            workdir/            (if sandbox enabled + no git)
            run.jsonl
            summary.json
    """

    def __init__(
        self,
        evidence: EvidenceStore,
        policy: PolicyEngine,
        *,
        limits: ToolLimits | None = None,
        policies_dir: Path | None = None,
        llm_driver: Any | None = None,
        worker_driver: Any | None = None,
        budget_governor: Any | None = None,
        ledger: Any | None = None,
        memory_store: MemoryStore | None = None,
    ) -> None:
        self.evidence = evidence
        self.policy = policy
        self.limits = limits or ToolLimits()
        self.worker_driver = worker_driver
        self.budget_governor = budget_governor
        self.ledger = ledger
        self.memory_store = memory_store

        # Composed components (FS33 decomposition)
        self.meta_store = CycleMetaStore(evidence)
        self.llm_runner = CycleLLMRunner(
            self.meta_store,
            llm_driver=llm_driver,
            budget_governor=budget_governor,
            ledger=ledger,
        )

        rules_path = (
            (policies_dir / "judge_rules.yaml")
            if policies_dir
            else Path("policies/judge_rules.yaml")
        )
        self.judge_rules = JudgeRules.from_yaml(rules_path)
        self.checker = HardFailChecker(self.judge_rules)

    @property
    def llm_driver(self) -> Any | None:
        """LLM driver (proxied to llm_runner)."""
        return self.llm_runner.llm_driver

    @llm_driver.setter
    def llm_driver(self, value: Any | None) -> None:
        self.llm_runner.llm_driver = value

    # ------------------------------------------------------------------
    # Helpers (delegate to meta_store)
    # ------------------------------------------------------------------

    def _run_dir(self, run_id: str) -> Path:
        return self.meta_store.run_dir(run_id)

    def _load_meta(self, run_id: str) -> CycleRunMeta:
        return self.meta_store.load(run_id)

    def _save_meta(self, meta: CycleRunMeta) -> None:
        self.meta_store.save(meta)

    # ------------------------------------------------------------------
    # Phase 1: START -> generate planner prompt
    # ------------------------------------------------------------------

    def start(
        self,
        goal: str,
        workspace: str = ".",
        *,
        sandbox: bool = False,
        auto_verify: bool = True,
        skill_packs: list[str] | None = None,
        refine: bool = False,
        force_complexity: str | None = None,
        max_iterations: int = 10,
    ) -> CycleRunMeta:
        """Start a new cycle: create run dirs and generate planner prompt."""
        run_id = f"cycle-{uuid.uuid4().hex[:12]}"
        self.evidence.create_run(run_id)

        run_dir = self._run_dir(run_id)
        (run_dir / "outbox").mkdir(exist_ok=True)
        (run_dir / "inbox").mkdir(exist_ok=True)
        (run_dir / "evidence").mkdir(exist_ok=True)

        effective_workspace = workspace

        # Sandbox setup
        sandbox_info = SandboxInfo(enabled=False)
        if sandbox:
            sandbox_info = create_sandbox(
                run_id=run_id,
                workspace=workspace,
                runs_dir=self.evidence.base_dir,
                policy=self.policy,
                limits=self.limits,
            )
            if sandbox_info.worktree_path:
                effective_workspace = sandbox_info.worktree_path

        # Goal refinement (FS55)
        effective_goal = goal
        refined_goal_data: dict[str, Any] | None = None
        if refine and _GOAL_REFINER_AVAILABLE:
            try:
                rg: RefinedGoal = _refine_goal(
                    goal, self.llm_runner.llm_driver, effective_workspace
                )
                effective_goal = rg.refined
                refined_goal_data = {
                    "original": rg.original,
                    "refined": rg.refined,
                    "risk_level": rg.risk_level,
                    "warnings": rg.warnings,
                    "changed": rg.changed,
                }
            except Exception:
                logger.warning("Goal refiner failed, using original goal", exc_info=True)

        # Profile detection
        profile: RepoProfile | None = None
        suggested_verify: list[str] = []
        if auto_verify:
            # Smart verify (FS56): prefer git-aware commands
            if _SMART_VERIFY_AVAILABLE:
                try:
                    smart_cmds = _suggest_smart_verify(effective_workspace)
                    if smart_cmds:
                        suggested_verify = smart_cmds
                    else:
                        # Fall back to profile detection
                        profile = detect_profile(effective_workspace)
                        suggested_verify = profile.suggested_verify_commands
                except Exception:
                    logger.debug("SmartVerify failed, falling back to profile", exc_info=True)
                    profile = detect_profile(effective_workspace)
                    suggested_verify = profile.suggested_verify_commands
            else:
                profile = detect_profile(effective_workspace)
                suggested_verify = profile.suggested_verify_commands
        if profile is None:
            profile = detect_profile(effective_workspace)

        # Complexity classification (FS57)
        complexity: str = force_complexity or "medium"
        if _COMPLEXITY_AVAILABLE and not force_complexity:
            try:
                complexity = _classify_goal(effective_goal)
            except Exception:
                logger.debug("Complexity classification failed", exc_info=True)

        meta = CycleRunMeta(
            run_id=run_id,
            goal=effective_goal,
            iteration=1,
            state=CycleState.STARTED_WAIT_PLANNER,
            workspace=effective_workspace,
            limits=CycleLimits(max_iterations=max_iterations),
            extra={
                "sandbox": {
                    "enabled": sandbox_info.enabled,
                    "kind": sandbox_info.kind,
                    "worktree_path": sandbox_info.worktree_path,
                    "branch_name": sandbox_info.branch_name,
                    "base_head_sha": sandbox_info.base_head_sha,
                    "base_repo_path": sandbox_info.base_repo_path,
                },
                "profile": {
                    "kind": profile.kind if profile else "unknown",
                    "markers": profile.markers if profile else [],
                    "suggested_verify": suggested_verify,
                },
                "complexity": complexity,
                # complexity_routing=True only when user explicitly set force_complexity
                "complexity_routing": force_complexity is not None,
                **({"refined_goal": refined_goal_data} if refined_goal_data else {}),
            },
        )
        self._save_meta(meta)

        # Evidence events for FS55/FS57
        if refined_goal_data:
            self.evidence.append_event(
                run_id,
                {
                    "event": "GOAL_REFINED",
                    **refined_goal_data,
                },
            )
        self.evidence.append_event(
            run_id,
            {
                "event": "COMPLEXITY_CLASSIFIED",
                "complexity": complexity,
                "forced": force_complexity is not None,
            },
        )

        # Memory query (FS54): inject past experience into planner prompt
        memory_context = ""
        if _MEMORY_RETRIEVAL_AVAILABLE and self.memory_store is not None:
            try:
                memory_context = _build_memory_context(self.memory_store, effective_goal)
            except Exception:
                logger.debug("Memory retrieval failed", exc_info=True)

        # RepoMap: inject codebase structure into worker context via Tree-sitter
        repo_map_text = ""
        if _REPO_MAP_AVAILABLE:
            try:
                analyzer = _CodeAnalyzer()
                repo_map_text = analyzer.generate_repo_map(effective_workspace, max_tokens=3000)
                logger.debug("RepoMap generated: %d chars", len(repo_map_text))
            except Exception:
                logger.debug("RepoMap generation failed", exc_info=True)

        # Inject repo structure and recent git history for better planner context
        _git_log = ""
        _ls_top = ""
        try:
            import subprocess as _sp
            _gl = _sp.run(
                ["git", "log", "--oneline", "-8"],
                cwd=effective_workspace, capture_output=True, text=True, timeout=5,
            )
            _git_log = _gl.stdout.strip()
            _ls = _sp.run(
                ["ls"],
                cwd=effective_workspace, capture_output=True, text=True, timeout=5,
            )
            _ls_top = _ls.stdout.strip()
        except Exception:
            pass

        repo_context = (
            f"Workspace: {effective_workspace}\n"
            f"Quality gates: pytest, ruff check, mypy\n"
            f"Policy: YAML allowlist, forbidden patterns enforced"
        )
        if _ls_top:
            repo_context += f"\nTop-level contents:\n{_ls_top}"
        if _git_log:
            repo_context += f"\nRecent commits:\n{_git_log}"
        if profile and profile.kind != "unknown":
            repo_context += f"\nDetected profile: {profile.kind} ({', '.join(profile.markers)})"
        if sandbox_info.enabled:
            repo_context += f"\nSandbox: {sandbox_info.kind}"
            if sandbox_info.branch_name:
                repo_context += f" (branch: {sandbox_info.branch_name})"

        constraints = [
            "Only use allowlisted commands for verification",
            "No force push, no rm -rf, no curl|bash",
            "Return ONLY valid JSON matching PlannerResponse schema",
        ]

        untrusted_context: list[str] = []
        if suggested_verify:
            untrusted_context.append(
                f"Auto-detected verify commands (override if needed): {suggested_verify}"
            )

        # Build skill pack context for planner prompt
        skill_pack_context = ""
        if _SKILLS_AVAILABLE and skill_packs:
            ctx_parts: list[str] = []
            # Available packs index
            try:
                all_packs = list_packs()
                if all_packs:
                    ctx_parts.append("## Available Skill Packs")
                    for p in all_packs:
                        ctx_parts.append(f"- **{p['id']}** v{p['version']}: {p['description']}")
                    ctx_parts.append("")
            except Exception:
                logger.debug("Could not list skill packs", exc_info=True)
            # Active pack(s) details
            for pack_id in skill_packs:
                try:
                    ctx_parts.append(f"## Active Skill Pack: {pack_id}")
                    ctx_parts.append(get_pack_context(pack_id))
                except Exception:
                    logger.warning("Could not load skill pack context: %s", pack_id, exc_info=True)
                    ctx_parts.append(f"## Skill Pack: {pack_id} (could not load)")
            skill_pack_context = "\n".join(ctx_parts)

        planner_req = PlannerRequest(
            run_id=run_id,
            iteration=1,
            goal=effective_goal,
            repo_context=repo_context,
            constraints=constraints,
            untrusted_context=untrusted_context,
            skill_pack_context=skill_pack_context,
            memory_context=memory_context,
        )

        prompt = _build_planner_prompt(planner_req)
        self.meta_store.write_outbox(run_id, "planner_prompt.md", prompt)

        meta.extra["repo_map"] = repo_map_text

        self.evidence.append_event(
            run_id,
            {
                "event": "cycle_start",
                "goal": effective_goal,
                "state": meta.state.value,
                "iteration": 1,
                "sandbox": sandbox_info.kind,
                "profile": profile.kind if profile else "unknown",
                "complexity": complexity,
                "memory_context_chars": len(memory_context),
                "repo_map_chars": len(repo_map_text),
            },
        )

        return meta

    # ------------------------------------------------------------------
    # Phase 2: submit planner response -> generate worker prompt
    # ------------------------------------------------------------------

    def submit_planner(self, run_id: str, *, file: Path | None = None) -> CycleRunMeta:
        """Validate planner response and generate worker prompt."""
        meta = self._load_meta(run_id)
        if meta.state != CycleState.STARTED_WAIT_PLANNER:
            msg = f"Expected state STARTED_WAIT_PLANNER, got {meta.state}"
            raise RuntimeError(msg)

        raw = self.meta_store.read_inbox(run_id, "planner_response.json", file, consume=True)
        resp = PlannerResponse(**json.loads(raw))
        self.evidence.write_artifact(run_id, "planner_response.json", raw)

        denied_cmds: list[str] = []
        for cmd in resp.verify_commands:
            result = self.policy.evaluate(cmd)
            if result.decision in (PolicyDecision.DENY, PolicyDecision.BLOCK):
                denied_cmds.append(f"{cmd} ({result.reason})")

        if denied_cmds:
            msg = (
                "Planner proposed non-allowlisted verify commands:\n"
                + "\n".join(f"  - {c}" for c in denied_cmds)
                + "\nAsk planner to revise. Only allowlisted commands are permitted."
            )
            raise ValueError(msg)

        # Relevant Files: find workspace files related to goal
        relevant_files: list[dict] = []
        if _CONTEXT_FINDER_AVAILABLE:
            try:
                relevant_files = _find_relevant_files(meta.goal, meta.workspace, max_files=5)
                logger.debug("ContextFinder: found %d relevant files", len(relevant_files))
            except Exception:
                logger.debug("ContextFinder failed", exc_info=True)

        worker_req = WorkerRequest(
            run_id=run_id,
            iteration=meta.iteration,
            worker_instructions=resp.worker_instructions,
            constraints=[
                "Return ONLY valid JSON matching WorkerReport schema",
                "No force push, no destructive commands",
            ],
            verify_commands=resp.verify_commands,
            repo_map=meta.extra.get("repo_map", ""),
            relevant_files=relevant_files,
        )

        import os as _os
        hitl_enabled = _os.environ.get("OWLMIND_HITL", "").strip() == "1"
        if hitl_enabled:
            meta.state = CycleState.WAIT_HITL_APPROVAL
            meta.extra["hitl_worker_req"] = worker_req.model_dump()
            meta.planner_plan_summary = resp.plan_summary
            meta.verify_commands = resp.verify_commands
            self._save_meta(meta)
            self.evidence.append_event(run_id, {"event": "hitl_requested", "iteration": meta.iteration})
            return meta

        prompt = _build_worker_prompt(worker_req)
        self.meta_store.write_outbox(run_id, "worker_prompt.md", prompt)
        self.meta_store.ensure_inbox_dir(run_id)

        meta.state = CycleState.WAIT_WORKER
        meta.planner_plan_summary = resp.plan_summary
        meta.verify_commands = resp.verify_commands
        self._save_meta(meta)

        self.evidence.append_event(
            run_id,
            {
                "event": "planner_submitted",
                "iteration": meta.iteration,
                "plan_summary": resp.plan_summary,
                "verify_commands": resp.verify_commands,
            },
        )

        return meta

    def approve_plan(self, run_id: str) -> CycleRunMeta:
        """HITL: approve the pending plan and generate worker prompt."""
        meta = self._load_meta(run_id)
        if meta.state != CycleState.WAIT_HITL_APPROVAL:
            msg = f"Expected state WAIT_HITL_APPROVAL, got {meta.state}"
            raise RuntimeError(msg)
        worker_req_data = meta.extra.get("hitl_worker_req")
        if not worker_req_data:
            msg = "No pending worker request found in meta.extra['hitl_worker_req']"
            raise RuntimeError(msg)
        worker_req = WorkerRequest(**worker_req_data)
        prompt = _build_worker_prompt(worker_req)
        self.meta_store.write_outbox(run_id, "worker_prompt.md", prompt)
        self.meta_store.ensure_inbox_dir(run_id)
        meta.state = CycleState.WAIT_WORKER
        self._save_meta(meta)
        self.evidence.append_event(run_id, {"event": "hitl_approved", "iteration": meta.iteration})
        return meta

    def reject_plan(self, run_id: str, feedback: str = "") -> CycleRunMeta:
        """HITL: reject the pending plan and return to STARTED_WAIT_PLANNER."""
        meta = self._load_meta(run_id)
        if meta.state != CycleState.WAIT_HITL_APPROVAL:
            msg = f"Expected state WAIT_HITL_APPROVAL, got {meta.state}"
            raise RuntimeError(msg)
        meta.extra.pop("hitl_worker_req", None)
        if feedback:
            meta.extra["hitl_rejection_feedback"] = feedback
        meta.state = CycleState.STARTED_WAIT_PLANNER
        self._save_meta(meta)
        self.evidence.append_event(run_id, {"event": "hitl_rejected", "feedback": feedback, "iteration": meta.iteration})
        return meta

    def resume_run(self, run_id: str) -> CycleRunMeta:
        """Resume a run by re-generating the appropriate prompt based on current state."""
        meta = self._load_meta(run_id)
        state = meta.state

        if state == CycleState.STARTED_WAIT_PLANNER:
            # Re-generate planner prompt from stored meta
            from owlmind.agent.cycle_planner import _build_planner_prompt
            from owlmind.agent.schemas import PlannerRequest
            planner_req = PlannerRequest(
                run_id=run_id,
                iteration=meta.iteration,
                goal=meta.goal,
                repo_context=f"Workspace: {meta.workspace}",
                constraints=["Return ONLY valid JSON matching PlannerResponse schema"],
            )
            prompt = _build_planner_prompt(planner_req)
            self.meta_store.write_outbox(run_id, "planner_prompt.md", prompt)
            self.evidence.append_event(run_id, {"event": "resume", "state": state.value})

        elif state in (CycleState.WAIT_WORKER, CycleState.WAIT_HITL_APPROVAL):
            # Re-generate worker prompt
            worker_req_data = meta.extra.get("hitl_worker_req")
            if worker_req_data:
                worker_req = WorkerRequest(**worker_req_data)
            else:
                raise RuntimeError(f"Cannot resume from {state}: no worker request stored")
            prompt = _build_worker_prompt(worker_req)
            self.meta_store.write_outbox(run_id, "worker_prompt.md", prompt)
            if state == CycleState.WAIT_HITL_APPROVAL:
                meta.state = CycleState.WAIT_WORKER
            self._save_meta(meta)
            self.evidence.append_event(run_id, {"event": "resume", "state": state.value})

        else:
            raise RuntimeError(f"Cannot resume from state {state}")

        return meta

    # ------------------------------------------------------------------
    # Phase 3: submit worker report -> verify -> hard fail -> judge
    # ------------------------------------------------------------------

    def submit_worker(self, run_id: str, *, file: Path | None = None) -> CycleRunMeta:
        """Validate worker report, run verify, check hard fails, generate judge prompt."""
        meta = self._load_meta(run_id)
        if meta.state != CycleState.WAIT_WORKER:
            msg = f"Expected state WAIT_WORKER, got {meta.state}"
            raise RuntimeError(msg)

        # Budget check: wall clock
        elapsed = (datetime.now(tz=UTC) - meta.created_at).total_seconds()
        if elapsed > meta.limits.max_total_runtime_sec:
            meta.state = CycleState.FAILED
            meta.hard_fail_reasons.append(
                f"BudgetExceeded: total runtime {elapsed:.0f}s > {meta.limits.max_total_runtime_sec}s"
            )
            self._save_meta(meta)
            self._generate_pr_pack(meta, [], run_id)
            self.evidence.append_event(
                run_id,
                {
                    "event": "budget_exceeded",
                    "reason": "total_runtime",
                },
            )
            return meta

        # Read worker report (consume=True removes the inbox file so stale reports
        # cannot be re-submitted on the next iteration without re-running the worker)
        raw = self.meta_store.read_inbox(run_id, "worker_report.json", file, consume=True)
        report = WorkerReport(**json.loads(raw))
        self.evidence.write_artifact(run_id, "worker_report.json", raw)

        # Run verify commands
        shell = ShellTool(policy=self.policy, limits=self.limits, cwd=meta.workspace)
        verify_results: list[str] = []
        verify_details: list[Any] = []
        verify_runtime = 0.0

        for cmd in meta.verify_commands:
            result = shell.run(cmd)
            passed = result.exit_code == 0
            status = "PASS" if passed else "FAIL"
            verify_results.append(f"{cmd}: {status} (exit {result.exit_code})")
            verify_runtime += result.duration_ms / 1000.0

            # Grounded Reflexion: collect full output for Judge
            verify_details.append({
                "cmd": cmd,
                "exit_code": result.exit_code,
                "stdout": result.stdout[:3000] if result.stdout else "",
                "stderr": result.stderr[:2000] if result.stderr else "",
                "passed": passed,
            })

            artifact_name = cmd.replace(" ", "_").replace("/", "_").replace(".", "_")[:80]
            self.evidence.write_artifact(
                run_id, f"verify_{artifact_name}_stdout.txt", result.stdout
            )
            self.evidence.write_artifact(
                run_id, f"verify_{artifact_name}_stderr.txt", result.stderr
            )

        meta.total_verify_runtime_sec += verify_runtime
        meta.verify_results = verify_results

        # Budget check: verify runtime
        if meta.total_verify_runtime_sec > meta.limits.max_verify_runtime_sec:
            meta.state = CycleState.FAILED
            meta.hard_fail_reasons.append(
                f"BudgetExceeded: verify runtime {meta.total_verify_runtime_sec:.0f}s "
                f"> {meta.limits.max_verify_runtime_sec}s"
            )
            meta.worker_done_summary = report.done_summary
            self._save_meta(meta)
            self._generate_pr_pack(meta, verify_results, run_id)
            self.evidence.append_event(
                run_id,
                {
                    "event": "budget_exceeded",
                    "reason": "verify_runtime",
                },
            )
            return meta

        # Capture git evidence
        diff_content, numstat, files_changed = self._capture_git_evidence(run_id, meta.workspace)

        # Hard fail checks
        chain_result = self.evidence.verify_chain(run_id)
        hard_fail = self.checker.check_all(
            diff_content=diff_content,
            files_changed=files_changed,
            numstat=numstat,
            chain_ok=chain_result.ok,
        )

        if not hard_fail.ok:
            meta.state = CycleState.FAILED
            meta.hard_fail_reasons = hard_fail.reasons
            meta.worker_done_summary = report.done_summary
            self._save_meta(meta)

            manifest = self.evidence.write_manifest(run_id)
            self._generate_pr_pack(
                meta,
                verify_results,
                run_id,
                manifest_sha256=str(manifest.get("manifest_sha256", "")),
            )
            self.evidence.write_summary(
                run_id,
                {
                    "state": "FAILED",
                    "reason": "HARD_FAIL",
                    "hard_fail_reasons": hard_fail.reasons,
                    "risk_level": hard_fail.risk_level,
                    "iteration": meta.iteration,
                    "goal": meta.goal,
                },
            )
            self.evidence.append_event(
                run_id,
                {
                    "event": "hard_fail",
                    "reasons": hard_fail.reasons,
                    "risk_level": hard_fail.risk_level,
                },
            )
            return meta

        # Write manifest
        manifest = self.evidence.write_manifest(run_id)

        # Collect evidence paths
        evidence_dir = self._run_dir(run_id) / "artifacts"
        evidence_paths = [
            str(p.relative_to(self._run_dir(run_id)))
            for p in sorted(evidence_dir.iterdir())
            if p.is_file()
        ]

        # Grounded Reflexion: git diff summary for Judge (truncated)
        git_diff_summary = ""
        if diff_content:
            git_diff_summary = diff_content[:4000]
            if len(diff_content) > 4000:
                git_diff_summary += f"\n... (truncated, {len(diff_content)} chars total)"

        # Build JudgeRequest with grounded evidence
        judge_req = JudgeRequest(
            run_id=run_id,
            iteration=meta.iteration,
            goal=meta.goal,
            planner_plan_summary=meta.planner_plan_summary,
            worker_done_summary=report.done_summary,
            verify_results_summary=verify_results,
            verify_details=[VerifyCommandDetail(**d) for d in verify_details],
            git_diff_summary=git_diff_summary,
            evidence_paths=evidence_paths,
        )

        prompt = _build_judge_prompt(judge_req)
        self.meta_store.write_outbox(run_id, "judge_prompt.md", prompt)
        self.meta_store.ensure_inbox_dir(run_id)

        meta.state = CycleState.WAIT_JUDGE
        meta.worker_done_summary = report.done_summary
        self._save_meta(meta)

        # Generate PR pack
        self._generate_pr_pack(
            meta,
            verify_results,
            run_id,
            manifest_sha256=str(manifest.get("manifest_sha256", "")),
        )

        self.evidence.append_event(
            run_id,
            {
                "event": "worker_submitted",
                "iteration": meta.iteration,
                "verify_results": verify_results,
            },
        )

        return meta

    # ------------------------------------------------------------------
    # Phase 4: submit judge response -> DONE / NEEDS_FIX / REJECTED
    # ------------------------------------------------------------------

    def submit_judge(self, run_id: str, *, file: Path | None = None) -> CycleRunMeta:
        """Validate judge response and transition state."""
        meta = self._load_meta(run_id)
        if meta.state != CycleState.WAIT_JUDGE:
            msg = f"Expected state WAIT_JUDGE, got {meta.state}"
            raise RuntimeError(msg)

        raw = self.meta_store.read_inbox(run_id, "judge_response.json", file, consume=True)
        resp = JudgeResponse(**json.loads(raw))
        self.evidence.write_artifact(run_id, "judge_response.json", raw)

        # Check evidence chain verification flag
        if not resp.evidence_chain_verified:
            meta.state = CycleState.FAILED
            meta.hard_fail_reasons.append("Judge reported evidence_chain_verified=false")
            self._save_meta(meta)
            self.evidence.write_summary(
                run_id,
                {
                    "state": "FAILED",
                    "reason": "EVIDENCE_CHAIN_UNVERIFIED",
                    "iteration": meta.iteration,
                    "goal": meta.goal,
                    "notes": resp.notes,
                },
            )
            self.evidence.append_event(
                run_id,
                {
                    "event": "judge_chain_unverified",
                    "iteration": meta.iteration,
                },
            )
            self._generate_pr_pack(meta, meta.verify_results, run_id)
            return meta

        verdict = resp.verdict.upper()

        if verdict == "APPROVED":
            meta.state = CycleState.DONE
            self._save_meta(meta)
            self.evidence.write_summary(
                run_id,
                {
                    "state": "DONE",
                    "verdict": "APPROVED",
                    "iteration": meta.iteration,
                    "goal": meta.goal,
                    "notes": resp.notes,
                },
            )
            self.evidence.append_event(
                run_id,
                {
                    "event": "judge_approved",
                    "iteration": meta.iteration,
                },
            )
            self._generate_pr_pack(meta, meta.verify_results, run_id)
            # Memory ingest (FS54): persist run knowledge for future cycles
            if self.memory_store is not None:
                with contextlib.suppress(Exception):
                    content = (
                        f"# Goal\n{meta.goal}\n\n"
                        f"# Plan\n"
                        + "\n".join(f"- {s}" for s in meta.planner_plan_summary)
                        + "\n\n"
                        "# Result\n" + "\n".join(f"- {s}" for s in meta.worker_done_summary)
                    )
                    self.memory_store.ingest(
                        kind="run",
                        source=f"run/{run_id}",
                        content=content,
                    )

        elif verdict == "NEEDS_FIX":
            if meta.iteration >= meta.limits.max_iterations:
                meta.state = CycleState.FAILED
                self._save_meta(meta)
                self.evidence.append_event(
                    run_id,
                    {
                        "event": "max_iterations_reached",
                        "iteration": meta.iteration,
                    },
                )
                self.evidence.write_summary(
                    run_id,
                    {
                        "state": "FAILED",
                        "reason": "MAX_ITERATIONS",
                        "iteration": meta.iteration,
                        "goal": meta.goal,
                    },
                )
                self._generate_pr_pack(meta, meta.verify_results, run_id)
            else:
                meta.iteration += 1
                meta.state = CycleState.WAIT_WORKER

                worker_req = WorkerRequest(
                    run_id=run_id,
                    iteration=meta.iteration,
                    worker_instructions=resp.next_worker_instructions,
                    constraints=["Fix issues noted by Judge", "Return valid JSON"],
                    verify_commands=meta.verify_commands,
                )
                prompt = _build_worker_prompt(worker_req)
                self.meta_store.write_outbox(run_id, "worker_prompt.md", prompt)
                self._save_meta(meta)

                self.evidence.append_event(
                    run_id,
                    {
                        "event": "judge_needs_fix",
                        "iteration": meta.iteration,
                        "notes": resp.notes,
                    },
                )

        elif verdict == "REJECTED":
            meta.state = CycleState.FAILED
            self._save_meta(meta)
            self.evidence.write_summary(
                run_id,
                {
                    "state": "FAILED",
                    "verdict": "REJECTED",
                    "iteration": meta.iteration,
                    "goal": meta.goal,
                    "notes": resp.notes,
                },
            )
            self.evidence.append_event(
                run_id,
                {
                    "event": "judge_rejected",
                    "iteration": meta.iteration,
                },
            )
            self._generate_pr_pack(meta, meta.verify_results, run_id)
        else:
            msg = f"Unknown verdict: {resp.verdict}"
            raise ValueError(msg)

        return meta

    # ------------------------------------------------------------------
    # Ingest
    # ------------------------------------------------------------------

    def ingest(self, run_id: str, file: Path) -> tuple[CycleRunMeta, str]:
        """Ingest a JSON response file based on current cycle state.

        Returns ``(meta, inbox_file_path)``.
        """
        meta = self._load_meta(run_id)
        content = file.read_text()

        state_map: dict[CycleState, tuple[str, type[BaseModel]]] = {
            CycleState.STARTED_WAIT_PLANNER: ("planner_response.json", PlannerResponse),
            CycleState.WAIT_WORKER: ("worker_report.json", WorkerReport),
            CycleState.WAIT_JUDGE: ("judge_response.json", JudgeResponse),
        }

        if meta.state not in state_map:
            msg = f"Cannot ingest in state {meta.state.value}"
            raise RuntimeError(msg)

        filename, schema_cls = state_map[meta.state]

        data = json.loads(content)
        schema_cls(**data)  # validate

        inbox = self.meta_store.ensure_inbox_dir(run_id)
        target = inbox / filename
        target.write_text(content)

        self.evidence.append_event(
            run_id,
            {
                "event": "file_ingested",
                "filename": filename,
                "state": meta.state.value,
            },
        )

        return meta, str(target)

    # ------------------------------------------------------------------
    # Next (auto-advance)
    # ------------------------------------------------------------------

    def next(self, run_id: str) -> tuple[CycleRunMeta, str]:
        """Auto-advance the cycle if the expected inbox file exists.

        Returns ``(meta, message)`` describing what happened.
        """
        meta = self._load_meta(run_id)

        self.evidence.append_event(
            run_id,
            {
                "event": "next_called",
                "state": meta.state.value,
                "iteration": meta.iteration,
            },
        )

        if meta.state == CycleState.STARTED_WAIT_PLANNER:
            if self.meta_store.inbox_file_exists(run_id, "planner_response.json"):
                updated = self.submit_planner(run_id)
                return updated, "Planner response submitted. State: WAIT_WORKER."
            outbox_path = self._run_dir(run_id) / "outbox" / "planner_prompt.md"
            return meta, (
                f"Waiting for planner response.\n"
                f"  1. Paste {outbox_path} into ChatGPT\n"
                f"  2. Save JSON response, then:\n"
                f"     owlmind cycle ingest --run-id {run_id} --file <path>"
            )

        if meta.state == CycleState.WAIT_WORKER:
            if self.meta_store.inbox_file_exists(run_id, "worker_report.json"):
                updated = self.submit_worker(run_id)
                state_str = updated.state.value
                msg = f"Worker report submitted. State: {state_str}."
                if updated.hard_fail_reasons:
                    msg += f"\nHard fail: {updated.hard_fail_reasons}"
                return updated, msg
            outbox_path = self._run_dir(run_id) / "outbox" / "worker_prompt.md"
            return meta, (
                f"Waiting for worker report.\n"
                f"  1. Paste {outbox_path} into Claude Code\n"
                f"  2. Save JSON response, then:\n"
                f"     owlmind cycle ingest --run-id {run_id} --file <path>"
            )

        if meta.state == CycleState.WAIT_JUDGE:
            if self.meta_store.inbox_file_exists(run_id, "judge_response.json"):
                updated = self.submit_judge(run_id)
                state_str = updated.state.value
                return updated, f"Judge response submitted. State: {state_str}."
            outbox_path = self._run_dir(run_id) / "outbox" / "judge_prompt.md"
            return meta, (
                f"Waiting for judge response.\n"
                f"  1. Paste {outbox_path} into ChatGPT\n"
                f"  2. Save JSON response, then:\n"
                f"     owlmind cycle ingest --run-id {run_id} --file <path>"
            )

        if meta.state == CycleState.WAIT_APPROVAL:
            approval = meta.extra.get("pending_approval", {})
            token = approval.get("token", "?")
            reason = approval.get("reason", "?")
            return meta, (
                f"Waiting for approval.\n"
                f"  Reason: {reason}\n"
                f"  Token:  {token}\n"
                f"  Approve: owlmind cycle approve --run-id {run_id} --token {token}\n"
                f"  Deny:    owlmind cycle deny --run-id {run_id} --token {token}"
            )

        if meta.state == CycleState.DONE:
            summary = self.evidence.read_summary(run_id)
            verdict = summary.get("verdict", "APPROVED")
            return meta, f"Cycle complete. Verdict: {verdict}."

        if meta.state == CycleState.FAILED:
            summary = self.evidence.read_summary(run_id)
            reason = summary.get("reason", "UNKNOWN")
            return meta, f"Cycle failed. Reason: {reason}."

        return meta, f"Unknown state: {meta.state.value}"

    # ------------------------------------------------------------------
    # LLM-driven Planner / Judge
    # ------------------------------------------------------------------

    def run_planner_llm(self, run_id: str) -> CycleRunMeta:
        """Call LLM driver to generate planner response and write to inbox."""
        force_provider: str | None = None
        if _COMPLEXITY_AVAILABLE:
            try:
                from owlmind.llm.complexity import provider_for_complexity
                meta = self._load_meta(run_id)
                complexity = meta.extra.get("complexity", "medium")
                # Apply model routing for simple tasks — always-on (saves cost)
                if not force_provider and complexity in ("simple",):
                    force_provider = provider_for_complexity(complexity)
            except Exception:
                logger.debug("Complexity routing failed", exc_info=True)
        return self.llm_runner.run_planner(run_id, force_provider=force_provider)

    def run_judge_llm(self, run_id: str) -> CycleRunMeta:
        """Call LLM driver to generate judge response and write to inbox."""
        force_provider: str | None = None
        if _COMPLEXITY_AVAILABLE:
            try:
                from owlmind.llm.complexity import provider_for_complexity
                meta = self._load_meta(run_id)
                complexity = meta.extra.get("complexity", "medium")
                # Apply model routing for simple tasks — always-on (saves cost)
                if not force_provider and complexity in ("simple",):
                    force_provider = provider_for_complexity(complexity)
            except Exception:
                logger.debug("Complexity routing failed", exc_info=True)
        return self.llm_runner.run_judge(run_id, force_provider=force_provider)

    # ------------------------------------------------------------------
    # Worker CLI automation (delegated to ApprovalFlowMixin)
    # ------------------------------------------------------------------
    # run_worker_cli, _execute_worker_cli, _progress_ticker
    # are inherited from ApprovalFlowMixin.

    # ------------------------------------------------------------------
    # Evidence / Export (delegated to EvidenceTrackerMixin)
    # ------------------------------------------------------------------
    # _capture_git_evidence, _generate_pr_pack, export, generate_pr_pack
    # are inherited from EvidenceTrackerMixin.

    # ------------------------------------------------------------------
    # Sandbox operations (delegated to SandboxLifecycleMixin)
    # ------------------------------------------------------------------
    # sandbox_create, sandbox_cleanup, sandbox_status
    # are inherited from SandboxLifecycleMixin.

    # ------------------------------------------------------------------
    # Status / Recovery
    # ------------------------------------------------------------------

    def status(self, run_id: str) -> CycleRunMeta:
        """Return current cycle metadata."""
        return self._load_meta(run_id)

    def load(self, run_id: str) -> CycleRunMeta:
        """Load and validate a cycle run from disk (recovery entrypoint)."""
        meta = self._load_meta(run_id)

        # Validate chain integrity
        chain_result = self.evidence.verify_chain(run_id)
        if not chain_result.ok:
            meta.extra["chain_warnings"] = chain_result.errors

        return meta

    def next_inbox_hint(self, meta: CycleRunMeta) -> str:
        """Return a hint about which inbox file is expected next."""
        hints: dict[CycleState, str] = {
            CycleState.STARTED_WAIT_PLANNER: (
                f"Save ChatGPT Planner response to:\n"
                f"  runs/{meta.run_id}/inbox/planner_response.json\n"
                f"Then run: owlmind cycle submit-planner --run-id {meta.run_id}"
            ),
            CycleState.WAIT_WORKER: (
                f"Save Claude Worker report to:\n"
                f"  runs/{meta.run_id}/inbox/worker_report.json\n"
                f"Then run: owlmind cycle submit-worker --run-id {meta.run_id}"
            ),
            CycleState.WAIT_JUDGE: (
                f"Save ChatGPT Judge response to:\n"
                f"  runs/{meta.run_id}/inbox/judge_response.json\n"
                f"Then run: owlmind cycle submit-judge --run-id {meta.run_id}"
            ),
            CycleState.WAIT_APPROVAL: (
                f"Waiting for approval.\n"
                f"  Use: owlmind cycle approve --run-id {meta.run_id} --token <TOKEN>\n"
                f"  Or:  owlmind cycle deny --run-id {meta.run_id} --token <TOKEN>"
            ),
            CycleState.DONE: "Cycle complete! No further action needed.",
            CycleState.FAILED: "Cycle failed. Start a new cycle if needed.",
        }
        return hints.get(meta.state, "Unknown state")
