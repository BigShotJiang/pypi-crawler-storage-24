"""Pydantic schemas for the manual Planner/Worker/Judge cycle."""

from __future__ import annotations

import enum
from datetime import UTC, datetime
from typing import Any

from pydantic import BaseModel, Field

# ---------------------------------------------------------------------------
# Cycle state
# ---------------------------------------------------------------------------


class CycleState(enum.StrEnum):
    STARTED_WAIT_PLANNER = "STARTED_WAIT_PLANNER"
    WAIT_WORKER = "WAIT_WORKER"
    WAIT_JUDGE = "WAIT_JUDGE"
    WAIT_APPROVAL = "WAIT_APPROVAL"
    WAIT_HITL_APPROVAL = "WAIT_HITL_APPROVAL"
    DONE = "DONE"
    FAILED = "FAILED"


# ---------------------------------------------------------------------------
# Planner
# ---------------------------------------------------------------------------


class PlannerRequest(BaseModel):
    """Prompt payload sent to ChatGPT Planner."""

    run_id: str
    iteration: int = 1
    goal: str
    repo_context: str = ""
    constraints: list[str] = Field(default_factory=list)
    untrusted_context: list[str] = Field(default_factory=list)
    skill_pack_context: str = ""
    memory_context: str = ""
    response_schema_hint: str = "PlannerResponse v1"


class PlannerResponse(BaseModel):
    """Expected JSON response from ChatGPT Planner."""

    run_id: str
    iteration: int = 1
    plan_summary: list[str] = Field(default_factory=list)
    worker_instructions: str
    verify_commands: list[str] = Field(default_factory=list)
    risk_notes: list[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Worker
# ---------------------------------------------------------------------------


class WorkerRequest(BaseModel):
    """Prompt payload sent to Claude Code Worker."""

    run_id: str
    iteration: int = 1
    worker_instructions: str
    constraints: list[str] = Field(default_factory=list)
    verify_commands: list[str] = Field(default_factory=list)
    # RepoMap: condensed codebase structure (symbols, files, imports)
    repo_map: str = ""
    relevant_files: list[dict] = Field(default_factory=list)
    report_schema_hint: str = "WorkerReport v1"


class WorkerCommandRun(BaseModel):
    cmd: str
    exit_code: int
    summary: str = ""


class WorkerReport(BaseModel):
    """Expected JSON response from Claude Code Worker."""

    run_id: str
    iteration: int = 1
    status: str = "READY_FOR_VERIFY"
    done_summary: list[str] = Field(default_factory=list)
    questions: list[str] = Field(default_factory=list, max_length=3)
    commands_run: list[WorkerCommandRun] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Judge
# ---------------------------------------------------------------------------


class VerifyCommandDetail(BaseModel):
    """Full output of a single verify command — used for Grounded Reflexion."""

    cmd: str
    exit_code: int
    stdout: str = ""
    stderr: str = ""
    passed: bool = True


class JudgeRequest(BaseModel):
    """Prompt payload sent to ChatGPT Judge."""

    run_id: str
    iteration: int = 1
    goal: str
    planner_plan_summary: list[str] = Field(default_factory=list)
    worker_done_summary: list[str] = Field(default_factory=list)
    verify_results_summary: list[str] = Field(default_factory=list)
    # Grounded Reflexion: full stdout/stderr for each verify command
    verify_details: list[VerifyCommandDetail] = Field(default_factory=list)
    # Grounded Reflexion: actual git diff (truncated to 4000 chars)
    git_diff_summary: str = ""
    evidence_paths: list[str] = Field(default_factory=list)
    response_schema_hint: str = "JudgeResponse v1"


class JudgeResponse(BaseModel):
    """Expected JSON response from ChatGPT Judge."""

    run_id: str
    iteration: int = 1
    verdict: str  # APPROVED | NEEDS_FIX | REJECTED
    notes: list[str] = Field(default_factory=list)
    next_worker_instructions: str | None = ""
    evidence_chain_verified: bool = True


# ---------------------------------------------------------------------------
# Budget / Limits
# ---------------------------------------------------------------------------


class CycleLimits(BaseModel):
    """Budget and limit configuration for a cycle run."""

    max_iterations: int = 10
    max_total_runtime_sec: int = 1800
    max_verify_runtime_sec: int = 1800
    max_actions_per_iteration: int = 20


# ---------------------------------------------------------------------------
# Cycle run metadata
# ---------------------------------------------------------------------------


class CycleRunMeta(BaseModel):
    """Persistent metadata for a cycle run."""

    run_id: str
    goal: str
    iteration: int = 1
    state: CycleState = CycleState.STARTED_WAIT_PLANNER
    workspace: str = "."
    created_at: datetime = Field(default_factory=lambda: datetime.now(tz=UTC))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(tz=UTC))
    limits: CycleLimits = Field(default_factory=CycleLimits)
    total_verify_runtime_sec: float = 0.0
    chain_tip_hash: str = ""
    chain_seq: int = 0
    planner_plan_summary: list[str] = Field(default_factory=list)
    verify_commands: list[str] = Field(default_factory=list)
    verify_results: list[str] = Field(default_factory=list)
    worker_done_summary: list[str] = Field(default_factory=list)
    hard_fail_reasons: list[str] = Field(default_factory=list)
    extra: dict[str, Any] = Field(default_factory=dict)
