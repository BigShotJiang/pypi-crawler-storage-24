"""Prompt A/B testing module — run two prompt variants, compare Judge scores, record winner."""
from __future__ import annotations

import contextlib
import json
import random
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

_RESULTS_FILE = Path.home() / ".owlmind" / "ab_results.jsonl"

# Score mapping for known verdict tokens
_VERDICT_SCORES: dict[str, float] = {
    "APPROVED": 1.0,
    "REJECTED": 0.0,
    "ERROR": -1.0,
}


@dataclass
class PromptVariant:
    """A named prompt variant targeting a specific agent role."""

    name: str
    agent: str  # planner / worker / judge
    prompt_addition: str


@dataclass
class ABResult:
    """Outcome of a single A/B prompt comparison run."""

    variant_a: PromptVariant
    variant_b: PromptVariant
    goal: str
    winner: str          # "A", "B", or "TIE"
    verdict_a: str
    verdict_b: str
    score_a: float
    score_b: float
    timestamp: str

    # Convenience helpers -------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> ABResult:
        d = dict(d)
        d["variant_a"] = PromptVariant(**d["variant_a"])
        d["variant_b"] = PromptVariant(**d["variant_b"])
        return cls(**d)


class ABTester:
    """Run two GraphRunner executions with different prompt overrides and compare results."""

    def __init__(self, results_file: Path | None = None) -> None:
        self._results_file = results_file or _RESULTS_FILE

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run(
        self,
        goal: str,
        workspace: str,
        variant_a: PromptVariant,
        variant_b: PromptVariant,
    ) -> ABResult:
        """Run both variants and return a populated ABResult.

        The real implementation should:
          1. Write each variant's `prompt_addition` to a temp override file.
          2. Instantiate GraphRunner with that override injected into the
             appropriate agent (planner / worker / judge).
          3. Collect `state.final_verdict` from each run.

        For now, a mock stub returns plausible random results so the CLI
        works end-to-end without a live LLM.
        """
        verdict_a = self._run_variant(goal, workspace, variant_a)
        verdict_b = self._run_variant(goal, workspace, variant_b)

        score_a = _VERDICT_SCORES.get(verdict_a.upper(), -1.0)
        score_b = _VERDICT_SCORES.get(verdict_b.upper(), -1.0)

        if score_a > score_b:
            winner = "A"
        elif score_b > score_a:
            winner = "B"
        else:
            winner = "TIE"

        return ABResult(
            variant_a=variant_a,
            variant_b=variant_b,
            goal=goal,
            winner=winner,
            verdict_a=verdict_a,
            verdict_b=verdict_b,
            score_a=score_a,
            score_b=score_b,
            timestamp=time.strftime("%Y-%m-%dT%H:%M:%S"),
        )

    def save(self, result: ABResult) -> None:
        """Append *result* to the JSONL history file."""
        self._results_file.parent.mkdir(parents=True, exist_ok=True)
        with self._results_file.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(result.to_dict()) + "\n")

    def load_history(self) -> list[ABResult]:
        """Return all previously saved ABResult objects (oldest first)."""
        if not self._results_file.exists():
            return []
        results: list[ABResult] = []
        for line in self._results_file.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            with contextlib.suppress(Exception):
                results.append(ABResult.from_dict(json.loads(line)))
        return results

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _run_variant(
        self,
        goal: str,
        workspace: str,
        variant: PromptVariant,
    ) -> str:
        """Execute the pipeline for one variant and return a verdict string.

        Writes the variant's prompt_addition to a temp override file, runs
        the GraphRunner with that override, and returns the final verdict.
        Falls back to random stub if GraphRunner is unavailable.
        """
        import json as _json
        import tempfile

        try:
            from owlmind.agent.self_improver import load_prompt_overrides
            from owlmind.graph.runner import GraphRunner

            # Save current overrides, inject variant's addition
            original = load_prompt_overrides()
            override = dict(original)
            existing = override.get(variant.agent, "")
            separator = "\n\n" if existing else ""
            override[variant.agent] = existing + separator + variant.prompt_addition

            # Write to a temp file so we don't clobber the real config
            with tempfile.NamedTemporaryFile(
                mode="w", suffix=".json", delete=False, prefix="owlmind_ab_"
            ) as tmp:
                _json.dump(override, tmp)
                tmp_name = tmp.name

            import os

            old_val = os.environ.get("OWLMIND_PROMPT_OVERRIDES_FILE", "")
            os.environ["OWLMIND_PROMPT_OVERRIDES_FILE"] = tmp_name
            try:
                runner = GraphRunner()
                state = runner.run(goal, workspace, max_iterations=1)
                verdict = getattr(state, "final_verdict", "") or "ERROR"
            finally:
                if old_val:
                    os.environ["OWLMIND_PROMPT_OVERRIDES_FILE"] = old_val
                else:
                    os.environ.pop("OWLMIND_PROMPT_OVERRIDES_FILE", None)
                os.unlink(tmp_name)

            return verdict.upper()
        except Exception:
            import logging

            logging.getLogger(__name__).debug(
                "ABTester: GraphRunner unavailable, using random stub", exc_info=True,
            )
            # Deterministic seed per variant name so results look stable in demos
            rng = random.Random(hash((goal, variant.name)) & 0xFFFF_FFFF)
            return rng.choice(["APPROVED", "APPROVED", "REJECTED"])
