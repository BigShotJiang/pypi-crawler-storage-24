"""Skill pack installer — ingest pack into workspace and memory store."""

from __future__ import annotations

import hashlib
import shutil
from pathlib import Path
from typing import TYPE_CHECKING, Any

from owlmind.skills.registry import _default_base, load_pack

if TYPE_CHECKING:
    from owlmind.evidence import EvidenceStore
    from owlmind.memory.store import MemoryStore


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    h.update(path.read_bytes())
    return h.hexdigest()


def install(
    pack_id: str,
    workspace: Path,
    *,
    base_dir: Path | None = None,
    memory_store: MemoryStore | None = None,
    evidence_store: EvidenceStore | None = None,
    run_id: str | None = None,
) -> dict[str, Any]:
    """Install a skill pack into *workspace* and ingest into memory.

    Steps:
    1. If workspace differs from the repo root, copy pack files into
       ``workspace/skill-packs/<pack_id>/``.
    2. Ingest all knowledge, prompts, and workflow files into *memory_store*
       (kind=``"skill_pack"``).
    3. Append a ``SKILL_PACK_INSTALLED`` evidence event with SHA-256 hashes
       of key files (if *evidence_store* and *run_id* are provided).

    Args:
        pack_id: Pack identifier (directory name under skill-packs/).
        workspace: Target workspace directory.
        base_dir: Directory containing skill pack subdirectories.
        memory_store: MemoryStore to ingest docs into.
        evidence_store: EvidenceStore to record audit event.
        run_id: Run ID for evidence event (required if evidence_store given).

    Returns:
        Dict with ``pack_id``, ``ingested_docs`` count, ``key_file_hashes``.
    """
    base = base_dir or _default_base()
    pack = load_pack(pack_id, base)
    pack_dir: Path = pack["pack_dir"]

    # Determine knowledge dir (relative to repo root)
    repo_root = base.parent
    knowledge_rel: str = pack.get("knowledge_dir", f"knowledge/{pack_id}")
    knowledge_dir = repo_root / knowledge_rel

    # Copy pack to workspace if workspace is outside the repo
    workspace = workspace.resolve()
    if workspace != repo_root.resolve():
        dest = workspace / "skill-packs" / pack_id
        if dest.exists():
            shutil.rmtree(dest)
        shutil.copytree(str(pack_dir), str(dest))

    # Collect files to ingest
    ingested = 0
    key_file_hashes: dict[str, str] = {}

    def _ingest_dir(directory: Path, label: str) -> None:
        nonlocal ingested
        if not directory.is_dir():
            return
        for fpath in sorted(directory.rglob("*")):
            if fpath.is_file() and fpath.suffix in (".md", ".yaml", ".yml", ".txt", ".json"):
                content = fpath.read_text(encoding="utf-8", errors="replace")
                source = str(fpath.relative_to(repo_root))
                if memory_store is not None:
                    memory_store.ingest(kind="skill_pack", source=source, content=content)
                ingested += 1

    # Ingest knowledge, prompts, workflows
    _ingest_dir(knowledge_dir, "knowledge")
    _ingest_dir(pack_dir / "prompts", "prompts")
    _ingest_dir(pack_dir / "workflows", "workflows")
    _ingest_dir(pack_dir / "policies", "policies")

    # Compute hashes of key files for evidence
    for rel in pack.get("required_files", []):
        fpath = pack_dir / rel
        if fpath.exists():
            key_file_hashes[rel] = _sha256_file(fpath)
    if knowledge_dir.exists():
        for fpath in sorted(knowledge_dir.glob("*.md")):
            key_file_hashes[f"knowledge/{fpath.name}"] = _sha256_file(fpath)

    # Write evidence event
    if evidence_store is not None and run_id is not None:
        evidence_store.append_event(
            run_id,
            {
                "event": "SKILL_PACK_INSTALLED",
                "pack_id": pack_id,
                "pack_version": pack.get("version", "?"),
                "ingested_docs": ingested,
                "key_file_hashes": key_file_hashes,
            },
        )

    return {
        "pack_id": pack_id,
        "ingested_docs": ingested,
        "key_file_hashes": key_file_hashes,
    }
