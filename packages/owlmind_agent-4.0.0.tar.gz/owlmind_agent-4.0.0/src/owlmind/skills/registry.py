"""Skill pack registry — discover and load packs from skill-packs/."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml


def _default_base() -> Path:
    """Return repo-relative skill-packs/ directory."""
    return Path(__file__).parent.parent.parent.parent / "skill-packs"


def list_packs(base_dir: Path | None = None) -> list[dict[str, Any]]:
    """Return metadata for every pack that has a pack.yaml.

    Args:
        base_dir: Directory containing skill pack subdirectories.
                  Defaults to ``<repo_root>/skill-packs/``.

    Returns:
        List of dicts with keys: id, name, version, description, tags, pack_dir.
    """
    base = base_dir or _default_base()
    packs: list[dict[str, Any]] = []
    if not base.is_dir():
        return packs
    for pack_dir in sorted(base.iterdir()):
        manifest = pack_dir / "pack.yaml"
        if pack_dir.is_dir() and manifest.exists():
            data = yaml.safe_load(manifest.read_text()) or {}
            packs.append(
                {
                    "id": data.get("id", pack_dir.name),
                    "name": data.get("name", pack_dir.name),
                    "version": data.get("version", "0.0.0"),
                    "description": data.get("description", ""),
                    "tags": data.get("tags", []),
                    "pack_dir": pack_dir,
                }
            )
    return packs


def load_pack(pack_id: str, base_dir: Path | None = None) -> dict[str, Any]:
    """Load full pack metadata for *pack_id*.

    Args:
        pack_id: Pack identifier (must match ``id`` in pack.yaml or directory name).
        base_dir: Directory containing skill pack subdirectories.

    Returns:
        Dict with all pack.yaml fields plus ``pack_dir`` (Path).

    Raises:
        FileNotFoundError: If pack or manifest not found.
    """
    base = base_dir or _default_base()
    pack_dir = base / pack_id
    manifest = pack_dir / "pack.yaml"
    if not manifest.exists():
        raise FileNotFoundError(f"Skill pack '{pack_id}' not found at {pack_dir}")
    data = yaml.safe_load(manifest.read_text()) or {}
    data["pack_dir"] = pack_dir
    return data


def get_pack_context(pack_id: str, base_dir: Path | None = None) -> str:
    """Build a concise context string for inclusion in the Planner prompt.

    Includes: system_prompt.md contents + rules summary + knowledge file index.
    Total length is kept short (≈800 tokens) — only index, not full file contents.

    Args:
        pack_id: Pack identifier.
        base_dir: Directory containing skill pack subdirectories.

    Returns:
        Formatted string ready to inject into a planner prompt.
    """
    pack = load_pack(pack_id, base_dir)
    pack_dir: Path = pack["pack_dir"]

    parts: list[str] = [
        f"### Skill Pack: {pack.get('name', pack_id)} (v{pack.get('version', '?')})",
        f"_{pack.get('description', '')}_",
        "",
    ]

    # system prompt
    system_prompt_path = pack_dir / "prompts" / "system_prompt.md"
    if system_prompt_path.exists():
        parts.append("#### Role & Guidelines")
        parts.append(system_prompt_path.read_text().strip())
        parts.append("")

    # rules summary (first 20 lines of education_rules.yaml)
    policies_dir = pack_dir / "policies"
    if policies_dir.is_dir():
        for rules_file in sorted(policies_dir.glob("*.yaml")):
            rules_text = rules_file.read_text().strip()
            lines = rules_text.splitlines()
            summary = "\n".join(lines[:20])
            if len(lines) > 20:
                summary += f"\n... ({len(lines) - 20} more lines)"
            parts.append(f"#### Policy: {rules_file.stem}")
            parts.append(f"```yaml\n{summary}\n```")
            parts.append("")

    # knowledge file index
    knowledge_files: list[str] = pack.get("knowledge_files", [])
    if knowledge_files:
        parts.append("#### Knowledge Files Available")
        for fname in knowledge_files:
            parts.append(f"- `{fname}`")
        parts.append("")

    # workflow index
    workflows_dir = pack_dir / "workflows"
    if workflows_dir.is_dir():
        wf_names = sorted(p.stem for p in workflows_dir.glob("*.yaml"))
        if wf_names:
            parts.append("#### Workflows")
            for wf in wf_names:
                parts.append(f"- `{wf}`")
            parts.append("")

    return "\n".join(parts)
