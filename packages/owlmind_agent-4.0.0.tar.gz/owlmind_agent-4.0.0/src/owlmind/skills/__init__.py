"""Skills system — registry and installer for OWLMIND skill packs."""

from __future__ import annotations

from owlmind.skills.installer import install
from owlmind.skills.registry import get_pack_context, list_packs, load_pack

__all__ = ["get_pack_context", "install", "list_packs", "load_pack"]
