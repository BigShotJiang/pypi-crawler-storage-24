"""Zero-friction setup — init workspace, doctor --fix, install hooks."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

_ENV_EXAMPLE = """\
# OWLMIND environment variables
# Copy to .env and fill in values (never commit real secrets)

# --- LLM Providers ---
OPENAI_API_KEY=
ANTHROPIC_API_KEY=
GEMINI_API_KEY=

# --- Telegram Bot (optional) ---
TELEGRAM_BOT_TOKEN=
TELEGRAM_ALLOWED_CHAT_IDS=
OWLMIND_NOTIFY_DEFAULT_CHAT_ID=

# --- Workspace safety ---
OWLMIND_DEFAULT_WORKSPACE=.
OWLMIND_ALLOWED_WORKSPACES=

# --- Budget ---
OWLMIND_BUDGET_MAX_USD_PER_DAY=10.00
OWLMIND_BUDGET_MAX_TOKENS_PER_DAY=500000
"""

_GOALS_TEMPLATE = """\
# OWLMIND goals template
# Copy, rename, and edit for your project.
version: 2

defaults:
  workspace: "."
  use_llm: "both"
  use_worker: "none"
  max_steps: 200

goals:
  - id: "G1"
    goal: "Describe the first goal here"
    depends_on: []

  - id: "G2"
    goal: "Describe the second goal here"
    depends_on: ["G1"]
"""

_REQUIRED_DIRS = ("runs", "sessions", "ledger")


@dataclass
class InitResult:
    """Result of setup init."""

    created_dirs: list[str] = field(default_factory=list)
    created_files: list[str] = field(default_factory=list)
    skipped: list[str] = field(default_factory=list)


def setup_init(workspace: Path) -> InitResult:
    """Create standard directories and example files.

    Safe and idempotent — never overwrites, never touches secrets.
    """
    result = InitResult()

    for dirname in _REQUIRED_DIRS:
        dirpath = workspace / dirname
        if dirpath.exists():
            result.skipped.append(str(dirpath))
        else:
            dirpath.mkdir(parents=True, exist_ok=True)
            result.created_dirs.append(str(dirpath))

    env_example = workspace / ".env.example"
    if env_example.exists():
        result.skipped.append(str(env_example))
    else:
        env_example.write_text(_ENV_EXAMPLE)
        result.created_files.append(str(env_example))

    examples_dir = workspace / "examples"
    template = examples_dir / "goals_template.yaml"
    if template.exists():
        result.skipped.append(str(template))
    else:
        examples_dir.mkdir(parents=True, exist_ok=True)
        template.write_text(_GOALS_TEMPLATE)
        result.created_files.append(str(template))

    return result


# ---------------------------------------------------------------------------
# Doctor --fix (safe only)
# ---------------------------------------------------------------------------


@dataclass
class DoctorFix:
    """A single fix applied by doctor --fix."""

    name: str
    fixed: bool
    detail: str


@dataclass
class DoctorFixReport:
    """Report of all fixes attempted."""

    fixes: list[DoctorFix] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return all(f.fixed for f in self.fixes) and not self.warnings


def doctor_fix(workspace: Path) -> DoctorFixReport:
    """Apply safe local fixes only.

    Safe fixes:
    - Create missing dirs (runs/sessions/ledger)
    - Create missing .env.example

    NOT done (only warned):
    - Install packages
    - Modify shell rc
    - Set environment variables
    - Modify git remotes
    """
    report = DoctorFixReport()

    for dirname in _REQUIRED_DIRS:
        dirpath = workspace / dirname
        if dirpath.exists():
            report.fixes.append(
                DoctorFix(
                    name=f"dir:{dirname}",
                    fixed=True,
                    detail="already exists",
                )
            )
        else:
            dirpath.mkdir(parents=True, exist_ok=True)
            report.fixes.append(
                DoctorFix(
                    name=f"dir:{dirname}",
                    fixed=True,
                    detail="created",
                )
            )

    env_example = workspace / ".env.example"
    if env_example.exists():
        report.fixes.append(
            DoctorFix(
                name=".env.example",
                fixed=True,
                detail="already exists",
            )
        )
    else:
        env_example.write_text(_ENV_EXAMPLE)
        report.fixes.append(
            DoctorFix(
                name=".env.example",
                fixed=True,
                detail="created",
            )
        )

    # Warn about env vars (never set them)
    import os

    for var in ("OPENAI_API_KEY", "ANTHROPIC_API_KEY", "TELEGRAM_BOT_TOKEN"):
        if not os.environ.get(var):
            report.warnings.append(f"env var {var} not set")

    return report
