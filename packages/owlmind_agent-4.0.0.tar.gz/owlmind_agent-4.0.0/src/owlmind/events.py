"""EventBus — simple publish/subscribe for cycle events."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

EventCallback = Callable[[str, dict[str, Any]], None]


@dataclass
class EventBus:
    """Minimal pub/sub event bus.

    Subscribers are callables ``(event_name: str, data: dict) -> None``.
    """

    _subscribers: list[EventCallback] = field(default_factory=list)

    def subscribe(self, callback: EventCallback) -> None:
        """Add a subscriber."""
        self._subscribers.append(callback)

    def unsubscribe(self, callback: EventCallback) -> None:
        """Remove a subscriber (silent if not found)."""
        self._subscribers = [s for s in self._subscribers if s is not callback]

    def publish(self, event_name: str, data: dict[str, Any] | None = None) -> None:
        """Publish an event to all subscribers."""
        payload = data or {}
        for subscriber in self._subscribers:
            subscriber(event_name, payload)

    @property
    def subscriber_count(self) -> int:
        return len(self._subscribers)
