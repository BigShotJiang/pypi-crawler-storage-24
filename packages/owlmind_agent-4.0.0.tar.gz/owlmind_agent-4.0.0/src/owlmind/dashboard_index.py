"""Dashboard Index — generate an HTML index of all dashboards and protocols."""

from __future__ import annotations

import html
from datetime import UTC, datetime
from pathlib import Path


def build_index(
    out_path: Path,
    root_dirs: list[Path],
) -> Path:
    """Build an HTML index of dashboards and protocols found in root_dirs.

    Scans for:
      - sessions/*/protocol.md
      - sessions/*/dashboard*.html / sessions/*/exports/dashboard*.html
      - runs/*/*.html

    Returns the path to the generated index file.
    """
    entries: list[dict[str, str]] = []

    for root in root_dirs:
        if not root.exists():
            continue
        # Session protocols
        for p in sorted(root.glob("sessions/*/protocol.md")):
            entries.append(_entry(p, "protocol", root))
        # Session dashboards
        for p in sorted(root.glob("sessions/**/dashboard*.html")):
            entries.append(_entry(p, "dashboard", root))
        # Run dashboards
        for p in sorted(root.glob("runs/*/*.html")):
            entries.append(_entry(p, "run-dashboard", root))

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(_render_html(entries))
    return out_path


def _entry(path: Path, kind: str, root: Path) -> dict[str, str]:
    """Create an index entry dict."""
    try:
        mtime = datetime.fromtimestamp(path.stat().st_mtime, tz=UTC).strftime(
            "%Y-%m-%d %H:%M",
        )
    except OSError:
        mtime = "?"
    rel = str(path.relative_to(root))
    return {"path": str(path), "rel": rel, "kind": kind, "mtime": mtime}


def _render_html(entries: list[dict[str, str]]) -> str:
    """Render index entries as a simple HTML page."""
    rows = ""
    for e in entries:
        safe_rel = html.escape(e["rel"])
        safe_path = html.escape(e["path"])
        safe_kind = html.escape(e["kind"])
        safe_mtime = html.escape(e["mtime"])
        rows += (
            f"<tr>"
            f'<td><a href="{safe_path}">{safe_rel}</a></td>'
            f"<td>{safe_kind}</td>"
            f"<td>{safe_mtime}</td>"
            f"</tr>\n"
        )

    if not rows:
        rows = '<tr><td colspan="3">No dashboards found.</td></tr>\n'

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>OWLMIND Dashboard Index</title>
<style>
  body {{ font-family: system-ui, sans-serif; margin: 2em; }}
  table {{ border-collapse: collapse; width: 100%; }}
  th, td {{ border: 1px solid #ccc; padding: 8px; text-align: left; }}
  th {{ background: #f5f5f5; }}
  a {{ color: #0366d6; }}
</style>
</head>
<body>
<h1>OWLMIND Dashboard Index</h1>
<p>Generated: {datetime.now(tz=UTC).strftime("%Y-%m-%d %H:%M UTC")}</p>
<table>
<tr><th>File</th><th>Kind</th><th>Modified</th></tr>
{rows}</table>
</body>
</html>
"""
