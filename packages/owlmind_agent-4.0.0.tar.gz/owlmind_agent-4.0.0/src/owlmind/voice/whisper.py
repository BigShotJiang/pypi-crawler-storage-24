"""Async voice transcription and TTS using OpenAI Whisper & TTS APIs.

This module provides *async* wrappers around the OpenAI audio APIs,
complementing the synchronous helpers in ``owlmind.voice.transcription``.

Requires: ``openai>=1.0.0`` (optional dependency: ``pip install owlmind[openai]``).

Usage::

    from owlmind.voice.whisper import transcribe, text_to_speech

    text = await transcribe("/path/to/audio.ogg")
    audio = await text_to_speech("Hello from Charwiz!")
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# Supported audio formats (same as transcription module)
SUPPORTED_FORMATS = {".ogg", ".mp3", ".wav", ".m4a", ".webm", ".flac", ".mp4", ".mpeg"}

# Available TTS voices
VOICES = ("alloy", "echo", "fable", "onyx", "nova", "shimmer")

# Guard optional import
_ASYNC_OPENAI_AVAILABLE = False
try:
    from openai import AsyncOpenAI  # noqa: F401

    _ASYNC_OPENAI_AVAILABLE = True
except ImportError:
    pass


def _get_client(api_key: str = "", base_url: str = "") -> Any:
    """Create an AsyncOpenAI client.

    Args:
        api_key: OpenAI API key. Falls back to OPENAI_API_KEY env var.
        base_url: Custom API base URL. Falls back to WHISPER_BASE_URL env var.

    Raises:
        RuntimeError: If the openai SDK is not installed or no API key is found.
    """
    if not _ASYNC_OPENAI_AVAILABLE:
        raise RuntimeError(
            "openai SDK not installed. Install with: pip install owlmind[openai]"
        )

    key = api_key or os.environ.get("WHISPER_API_KEY", "") or os.environ.get("OPENAI_API_KEY", "")
    if not key:
        raise RuntimeError(
            "No API key for Whisper/TTS. Set OPENAI_API_KEY in .env"
        )

    url = base_url or os.environ.get("WHISPER_BASE_URL", "")
    kwargs: dict[str, Any] = {"api_key": key}
    if url:
        kwargs["base_url"] = url

    from openai import AsyncOpenAI
    return AsyncOpenAI(**kwargs)


async def transcribe(
    file_path: str | Path,
    *,
    api_key: str = "",
    base_url: str = "",
    model: str = "whisper-1",
    language: str = "",
    prompt: str = "",
) -> str:
    """Transcribe an audio file to text via OpenAI Whisper API (async).

    Args:
        file_path: Path to the audio file.
        api_key: OpenAI API key. Falls back to OPENAI_API_KEY env var.
        base_url: Custom base URL for the API.
        model: Whisper model name (default ``whisper-1``).
        language: ISO-639-1 language code (e.g. ``"en"``, ``"ru"``). Empty = auto.
        prompt: Optional prompt to guide transcription style/vocabulary.

    Returns:
        Transcribed text.

    Raises:
        ValueError: If the file format is not supported.
        RuntimeError: If the SDK is unavailable or API call fails.
    """
    p = Path(file_path)
    if p.suffix.lower() not in SUPPORTED_FORMATS:
        raise ValueError(
            f"Unsupported audio format: {p.suffix}. "
            f"Supported: {', '.join(sorted(SUPPORTED_FORMATS))}"
        )

    client = _get_client(api_key, base_url)

    kwargs: dict[str, Any] = {"model": model}
    if language:
        kwargs["language"] = language
    if prompt:
        kwargs["prompt"] = prompt

    with open(p, "rb") as f:
        kwargs["file"] = f
        result = await client.audio.transcriptions.create(**kwargs)

    logger.info("Whisper async transcribed %s -> %d chars", p.name, len(result.text))
    return result.text


async def transcribe_bytes(
    data: bytes,
    *,
    filename: str = "audio.ogg",
    api_key: str = "",
    base_url: str = "",
    model: str = "whisper-1",
    language: str = "",
) -> str:
    """Transcribe raw audio bytes via Whisper API (async).

    Args:
        data: Raw audio bytes.
        filename: Filename hint (determines content-type).
        api_key: OpenAI API key.
        base_url: Custom base URL.
        model: Whisper model name.
        language: ISO-639-1 language code.

    Returns:
        Transcribed text.
    """
    client = _get_client(api_key, base_url)

    kwargs: dict[str, Any] = {
        "model": model,
        "file": (filename, data),
    }
    if language:
        kwargs["language"] = language

    result = await client.audio.transcriptions.create(**kwargs)
    logger.info("Whisper async transcribed %d bytes -> %d chars", len(data), len(result.text))
    return result.text


async def text_to_speech(
    text: str,
    *,
    api_key: str = "",
    base_url: str = "",
    model: str = "tts-1",
    voice: str = "alloy",
    response_format: str = "mp3",
    speed: float = 1.0,
) -> bytes:
    """Convert text to speech via OpenAI TTS API (async).

    Args:
        text: Text to synthesize.
        api_key: OpenAI API key.
        base_url: Custom base URL.
        model: TTS model (``tts-1`` or ``tts-1-hd``).
        voice: Voice name. One of: alloy, echo, fable, onyx, nova, shimmer.
        response_format: Audio format (``mp3``, ``opus``, ``aac``, ``flac``, ``wav``, ``pcm``).
        speed: Playback speed (0.25 to 4.0).

    Returns:
        Raw audio bytes in the requested format.

    Raises:
        ValueError: If voice is not valid.
        RuntimeError: If the SDK is unavailable or API call fails.
    """
    if voice not in VOICES:
        raise ValueError(f"Invalid voice '{voice}'. Choose from: {', '.join(VOICES)}")

    client = _get_client(api_key, base_url)

    response = await client.audio.speech.create(
        model=model,
        voice=voice,
        input=text,
        response_format=response_format,
        speed=speed,
    )

    audio_bytes = response.content
    logger.info(
        "TTS generated %d bytes (%s, voice=%s) for %d chars",
        len(audio_bytes), response_format, voice, len(text),
    )
    return audio_bytes


async def text_to_speech_stream(
    text: str,
    *,
    api_key: str = "",
    base_url: str = "",
    model: str = "tts-1",
    voice: str = "alloy",
    response_format: str = "mp3",
    speed: float = 1.0,
    chunk_size: int = 4096,
):
    """Stream TTS audio in chunks (async generator).

    Yields bytes chunks as they are received from the API, enabling
    low-latency playback.

    Args:
        text: Text to synthesize.
        api_key: OpenAI API key.
        base_url: Custom base URL.
        model: TTS model.
        voice: Voice name.
        response_format: Audio format.
        speed: Playback speed.
        chunk_size: Size of each yielded chunk in bytes.

    Yields:
        Audio bytes chunks.
    """
    if voice not in VOICES:
        raise ValueError(f"Invalid voice '{voice}'. Choose from: {', '.join(VOICES)}")

    client = _get_client(api_key, base_url)

    response = await client.audio.speech.create(
        model=model,
        voice=voice,
        input=text,
        response_format=response_format,
        speed=speed,
    )

    # Stream the content in chunks
    content = response.content
    for i in range(0, len(content), chunk_size):
        yield content[i : i + chunk_size]
