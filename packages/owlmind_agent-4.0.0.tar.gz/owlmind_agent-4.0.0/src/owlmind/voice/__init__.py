"""Voice sub-package — transcription, TTS, and real-time voice interaction.

Re-exports legacy helpers so that existing code like::

    from owlmind.voice import is_available, transcribe_telegram_voice

continues to work unchanged.

New modules:
    - ``owlmind.voice.whisper``   — async Whisper transcription & TTS
    - ``owlmind.voice.realtime``  — OpenAI Realtime API WebSocket client
    - ``owlmind.voice.agent``     — voice-controlled agent (graph integration)
"""

from __future__ import annotations

# Re-export everything from the legacy transcription module so that
# ``from owlmind.voice import is_available`` keeps working.
from owlmind.voice.transcription import (
    SUPPORTED_FORMATS,
    is_available,
    transcribe_bytes,
    transcribe_cli,
    transcribe_file,
    transcribe_telegram_voice,
    transcribe_telegram_voice_sync,
)

__all__ = [
    "SUPPORTED_FORMATS",
    "is_available",
    "transcribe_bytes",
    "transcribe_cli",
    "transcribe_file",
    "transcribe_telegram_voice",
    "transcribe_telegram_voice_sync",
]
