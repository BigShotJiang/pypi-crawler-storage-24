"""Voice agent — listens, understands, and executes commands via graph pipeline.

Integrates voice input with the OwlMind graph runner:

    Voice/Audio -> Transcribe (Whisper) -> Parse Intent -> Execute (GraphRunner) -> Respond (TTS)

Can operate in two modes:
1. **Batch mode**: transcribe a file, run as goal, return audio response.
2. **Realtime mode**: use OpenAI Realtime API for low-latency conversation
   with optional tool/graph execution.

Usage::

    from owlmind.voice.agent import VoiceAgent

    agent = VoiceAgent(workspace="/path/to/project")
    result = await agent.process_audio_file("command.ogg")
    print(result.text)

    # Or run interactively
    await agent.start_realtime_session()
"""

from __future__ import annotations

import asyncio
import logging
import os
from collections.abc import Awaitable, Callable
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass
class VoiceResult:
    """Result of a voice agent interaction."""

    transcription: str = ""
    intent: str = ""  # "goal" | "chat" | "command" | "unknown"
    goal: str = ""
    graph_output: str = ""
    response_text: str = ""
    response_audio: bytes = b""
    error: str = ""

    @property
    def success(self) -> bool:
        return not self.error


@dataclass
class VoiceAgentConfig:
    """Configuration for the voice agent."""

    workspace: str = "."
    max_graph_iterations: int = 3
    tts_voice: str = "alloy"
    tts_model: str = "tts-1"
    whisper_model: str = "whisper-1"
    language: str = ""  # auto-detect by default
    auto_execute: bool = True  # automatically run transcribed text as graph goal
    api_key: str = ""  # falls back to OPENAI_API_KEY env var

    @property
    def effective_api_key(self) -> str:
        return self.api_key or os.environ.get("OPENAI_API_KEY", "")


class VoiceAgent:
    """Voice-controlled agent that bridges audio I/O with the graph pipeline.

    Handles the full lifecycle:
    1. Accept audio input (file or stream)
    2. Transcribe to text via Whisper
    3. Classify intent (goal vs. chat vs. command)
    4. Execute via GraphRunner if it's a goal
    5. Generate audio response via TTS
    """

    # Simple intent keywords — goals contain action verbs
    _GOAL_KEYWORDS = frozenset({
        "create", "build", "fix", "add", "remove", "delete", "update",
        "refactor", "test", "deploy", "implement", "write", "run",
        "change", "modify", "optimize", "migrate", "install", "configure",
    })

    _COMMAND_KEYWORDS = frozenset({
        "status", "stop", "cancel", "pause", "resume", "help",
        "list", "show", "history",
    })

    def __init__(
        self,
        config: VoiceAgentConfig | None = None,
        *,
        workspace: str = ".",
        on_transcription: Callable[[str], Awaitable[None]] | None = None,
        on_response: Callable[[str], Awaitable[None]] | None = None,
    ) -> None:
        self.config = config or VoiceAgentConfig(workspace=workspace)
        self.on_transcription = on_transcription
        self.on_response = on_response
        self._executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix="voice-graph")

    async def process_audio_file(self, file_path: str | Path) -> VoiceResult:
        """Process an audio file: transcribe -> execute -> respond.

        Args:
            file_path: Path to audio file (ogg, mp3, wav, etc.)

        Returns:
            VoiceResult with transcription, graph output, and optional audio response.
        """
        result = VoiceResult()

        # Step 1: Transcribe
        try:
            from owlmind.voice.whisper import transcribe
            result.transcription = await transcribe(
                file_path,
                api_key=self.config.effective_api_key,
                model=self.config.whisper_model,
                language=self.config.language,
            )
            logger.info("Transcribed: %s", result.transcription[:100])
        except Exception as e:
            result.error = f"Transcription failed: {e}"
            logger.error(result.error)
            return result

        if self.on_transcription:
            await self.on_transcription(result.transcription)

        # Step 2: Process the transcribed text
        return await self._process_text(result)

    async def process_audio_bytes(
        self,
        data: bytes,
        filename: str = "audio.ogg",
    ) -> VoiceResult:
        """Process raw audio bytes: transcribe -> execute -> respond.

        Args:
            data: Raw audio bytes.
            filename: Filename hint for format detection.

        Returns:
            VoiceResult with transcription and execution results.
        """
        result = VoiceResult()

        try:
            from owlmind.voice.whisper import transcribe_bytes
            result.transcription = await transcribe_bytes(
                data,
                filename=filename,
                api_key=self.config.effective_api_key,
                model=self.config.whisper_model,
                language=self.config.language,
            )
            logger.info("Transcribed bytes: %s", result.transcription[:100])
        except Exception as e:
            result.error = f"Transcription failed: {e}"
            logger.error(result.error)
            return result

        if self.on_transcription:
            await self.on_transcription(result.transcription)

        return await self._process_text(result)

    async def process_text(self, text: str) -> VoiceResult:
        """Process a text command (skip transcription step).

        Args:
            text: User command/goal text.

        Returns:
            VoiceResult with execution results and optional audio response.
        """
        result = VoiceResult(transcription=text)
        return await self._process_text(result)

    async def _process_text(self, result: VoiceResult) -> VoiceResult:
        """Internal: classify intent and execute."""
        text = result.transcription.strip()
        if not text:
            result.error = "Empty transcription"
            return result

        # Step 2: Classify intent
        result.intent = self._classify_intent(text)
        logger.info("Intent: %s for '%s'", result.intent, text[:60])

        # Step 3: Execute based on intent
        if result.intent == "goal" and self.config.auto_execute:
            result.goal = text
            result.graph_output = await self._run_graph(text)
            result.response_text = (
                f"Executed: {text[:80]}\n\nResult:\n{result.graph_output}"
            )
        elif result.intent == "command":
            result.response_text = await self._handle_command(text)
        else:
            # Chat / unknown — just echo back
            result.response_text = f"I heard: {text}"

        # Step 4: Generate audio response (optional)
        if result.response_text:
            try:
                from owlmind.voice.whisper import text_to_speech
                result.response_audio = await text_to_speech(
                    result.response_text[:4096],  # TTS input limit
                    api_key=self.config.effective_api_key,
                    model=self.config.tts_model,
                    voice=self.config.tts_voice,
                )
            except Exception as e:
                logger.warning("TTS generation failed: %s", e)
                # Non-fatal — text response is still available

        if self.on_response:
            await self.on_response(result.response_text)

        return result

    def _classify_intent(self, text: str) -> str:
        """Classify user intent from transcribed text.

        Returns one of: ``"goal"``, ``"command"``, ``"chat"``, ``"unknown"``.
        """
        words = set(text.lower().split())

        if words & self._COMMAND_KEYWORDS:
            return "command"

        if words & self._GOAL_KEYWORDS:
            return "goal"

        # Short utterances are likely chat
        if len(text.split()) <= 3:
            return "chat"

        # Default: treat longer text as a goal
        return "goal"

    async def _run_graph(self, goal: str) -> str:
        """Run a goal through the GraphRunner in a thread.

        Args:
            goal: The user's goal/task description.

        Returns:
            Summary of the graph execution result.
        """
        def _execute() -> str:
            try:
                from owlmind.graph.runner import GraphRunner

                runner = GraphRunner()
                state = runner.run(
                    goal,
                    workspace=self.config.workspace,
                    max_iterations=self.config.max_graph_iterations,
                )
                verdict = getattr(state, "final_verdict", "UNKNOWN")
                review = getattr(state, "review", "") or ""
                return f"Verdict: {verdict}\n{review[:1000]}"
            except Exception as e:
                logger.error("Graph execution failed: %s", e)
                return f"Error: {e}"

        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(self._executor, _execute)

    async def _handle_command(self, text: str) -> str:
        """Handle a voice command (status, help, etc.)."""
        cmd = text.lower().strip()

        if "help" in cmd:
            return (
                "Available voice commands: "
                "status, help, stop, history. "
                "Or say a task like 'create a new module' to run it as a goal."
            )

        if "status" in cmd:
            return (
                f"Voice agent active. "
                f"Workspace: {self.config.workspace}. "
                f"Auto-execute: {'on' if self.config.auto_execute else 'off'}."
            )

        if "stop" in cmd or "cancel" in cmd:
            return "Stopping. No active tasks to cancel."

        return f"Unknown command: {text}"

    async def start_realtime_session(
        self,
        *,
        on_text: Callable[[str], Awaitable[None]] | None = None,
        on_audio: Callable[[bytes], Awaitable[None]] | None = None,
    ) -> None:
        """Start an interactive real-time voice session.

        Uses the OpenAI Realtime API for low-latency bidirectional voice.
        Blocks until the session is closed.

        Args:
            on_text: Callback for text response deltas.
            on_audio: Callback for audio response chunks.
        """
        from owlmind.voice.realtime import VoiceSession

        async with VoiceSession(
            api_key=self.config.effective_api_key,
            voice=self.config.tts_voice,
            instructions=(
                f"{VoiceSession.DEFAULT_INSTRUCTIONS} "
                f"Current workspace: {self.config.workspace}"
            ),
        ) as session:
            session.on_text = on_text
            session.on_audio = on_audio
            logger.info("Realtime voice session started")

            # Listen forever until cancelled
            await session.listen_forever()

    def close(self) -> None:
        """Clean up resources."""
        self._executor.shutdown(wait=False)
