"""Real-time voice interaction using OpenAI Realtime API.

Provides a WebSocket-based session for bidirectional audio/text streaming
with OpenAI's ``gpt-4o-realtime-preview`` model.

Requires: ``websockets>=12.0`` and ``openai>=1.0.0`` (optional deps).

Usage::

    from owlmind.voice.realtime import VoiceSession

    session = VoiceSession(api_key="sk-...")
    await session.connect()
    session.on_text = my_text_callback
    session.on_audio = my_audio_callback
    await session.send_text("Hello!")
    await session.listen()
    await session.close()
"""

from __future__ import annotations

import asyncio
import base64
import contextlib
import json
import logging
import os
from collections.abc import Awaitable, Callable
from typing import Any

logger = logging.getLogger(__name__)

# Guard optional imports
_WS_AVAILABLE = False
try:
    import websockets  # noqa: F401

    _WS_AVAILABLE = True
except ImportError:
    pass


def is_realtime_available() -> bool:
    """Return True if websockets is installed and an API key is set."""
    key = os.environ.get("OPENAI_API_KEY", "")
    return _WS_AVAILABLE and bool(key)


# Type aliases for callbacks
TextCallback = Callable[[str], Awaitable[None]]
AudioCallback = Callable[[bytes], Awaitable[None]]
EventCallback = Callable[[dict[str, Any]], Awaitable[None]]


class VoiceSession:
    """Manages a real-time voice session with OpenAI.

    Connects via WebSocket to the OpenAI Realtime API and supports:
    - Sending/receiving PCM16 audio
    - Sending/receiving text messages
    - Server-side voice activity detection (VAD)
    - Configurable voice, modalities, and instructions
    """

    # Default system instructions for the realtime session
    DEFAULT_INSTRUCTIONS = (
        "You are Charwiz, an autonomous AI agent built with OwlMind. "
        "Respond concisely and helpfully in the user's language. "
        "When asked to perform tasks, describe what you would do."
    )

    def __init__(
        self,
        api_key: str = "",
        *,
        model: str = "gpt-4o-realtime-preview",
        voice: str = "alloy",
        instructions: str = "",
        input_audio_format: str = "pcm16",
        output_audio_format: str = "pcm16",
        turn_detection: str = "server_vad",
    ) -> None:
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY", "")
        self.model = model
        self.voice = voice
        self.instructions = instructions or self.DEFAULT_INSTRUCTIONS
        self.input_audio_format = input_audio_format
        self.output_audio_format = output_audio_format
        self.turn_detection = turn_detection

        self.ws: Any = None
        self._connected = False
        self._listen_task: asyncio.Task[None] | None = None

        # User-supplied callbacks
        self.on_text: TextCallback | None = None
        self.on_audio: AudioCallback | None = None
        self.on_event: EventCallback | None = None
        self.on_transcript: TextCallback | None = None
        self.on_error: TextCallback | None = None

    @property
    def connected(self) -> bool:
        """Whether the WebSocket connection is active."""
        return self._connected and self.ws is not None

    async def connect(self) -> None:
        """Connect to OpenAI Realtime WebSocket.

        Raises:
            RuntimeError: If websockets is not installed or API key is missing.
        """
        if not _WS_AVAILABLE:
            raise RuntimeError(
                "websockets package not installed. "
                "Install with: pip install websockets>=12.0"
            )
        if not self.api_key:
            raise RuntimeError(
                "No API key for Realtime API. Set OPENAI_API_KEY in .env"
            )

        url = f"wss://api.openai.com/v1/realtime?model={self.model}"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "OpenAI-Beta": "realtime=v1",
        }

        import websockets as _ws

        self.ws = await _ws.connect(url, extra_headers=headers)
        self._connected = True
        logger.info("Connected to OpenAI Realtime API (model=%s)", self.model)

        # Configure session
        await self._send_event({
            "type": "session.update",
            "session": {
                "modalities": ["text", "audio"],
                "instructions": self.instructions,
                "voice": self.voice,
                "input_audio_format": self.input_audio_format,
                "output_audio_format": self.output_audio_format,
                "turn_detection": {"type": self.turn_detection},
            },
        })

    async def _send_event(self, event: dict[str, Any]) -> None:
        """Send a JSON event to the WebSocket."""
        if not self.ws:
            return
        await self.ws.send(json.dumps(event))

    async def send_audio(self, audio_bytes: bytes) -> None:
        """Send audio data (PCM16) to the session.

        Args:
            audio_bytes: Raw PCM16 audio bytes to stream.
        """
        if not self.connected:
            logger.warning("Cannot send audio: not connected")
            return
        b64 = base64.b64encode(audio_bytes).decode("ascii")
        await self._send_event({
            "type": "input_audio_buffer.append",
            "audio": b64,
        })

    async def commit_audio(self) -> None:
        """Commit the audio buffer (signals end of user speech).

        Only needed when turn_detection is disabled (manual mode).
        """
        if not self.connected:
            return
        await self._send_event({"type": "input_audio_buffer.commit"})

    async def send_text(self, text: str) -> None:
        """Send a text message and request a response.

        Args:
            text: User message text.
        """
        if not self.connected:
            logger.warning("Cannot send text: not connected")
            return
        await self._send_event({
            "type": "conversation.item.create",
            "item": {
                "type": "message",
                "role": "user",
                "content": [{"type": "input_text", "text": text}],
            },
        })
        await self._send_event({"type": "response.create"})

    async def listen(self) -> None:
        """Listen for server events and dispatch to callbacks.

        Runs until the WebSocket is closed or ``response.done`` is received.
        For continuous listening, call this in a loop or use ``listen_forever``.
        """
        if not self.ws:
            return

        try:
            async for msg in self.ws:
                event = json.loads(msg)
                event_type = event.get("type", "")

                # Forward raw event if callback is set
                if self.on_event:
                    await self.on_event(event)

                # Dispatch by event type
                if event_type == "response.text.delta" and self.on_text:
                    delta = event.get("delta", "")
                    if delta:
                        await self.on_text(delta)

                elif event_type == "response.audio.delta" and self.on_audio:
                    delta = event.get("delta", "")
                    if delta:
                        audio = base64.b64decode(delta)
                        await self.on_audio(audio)

                elif event_type == "response.audio_transcript.delta" and self.on_transcript:
                    delta = event.get("delta", "")
                    if delta:
                        await self.on_transcript(delta)

                elif event_type == "error":
                    error_msg = event.get("error", {}).get("message", str(event))
                    logger.error("Realtime API error: %s", error_msg)
                    if self.on_error:
                        await self.on_error(error_msg)

                elif event_type == "response.done":
                    logger.debug("Response complete")
                    break

        except Exception as e:
            logger.error("Realtime listen error: %s", e)
            self._connected = False
            raise

    async def listen_forever(self) -> None:
        """Listen continuously, processing multiple responses.

        Reconnects on transient errors. Cancel the task to stop.
        """
        while self._connected:
            try:
                await self.listen()
            except Exception:
                if not self._connected:
                    break
                logger.warning("Listen loop interrupted, continuing...")
                await asyncio.sleep(0.1)

    async def close(self) -> None:
        """Close the WebSocket connection."""
        self._connected = False
        if self._listen_task and not self._listen_task.done():
            self._listen_task.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await self._listen_task
        if self.ws:
            with contextlib.suppress(Exception):
                await self.ws.close()
            self.ws = None
        logger.info("Realtime session closed")

    async def __aenter__(self) -> VoiceSession:
        await self.connect()
        return self

    async def __aexit__(self, *exc: Any) -> None:
        await self.close()
