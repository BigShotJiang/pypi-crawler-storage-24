"""Voice transcription via OpenAI Whisper API.

Converts audio files (ogg, mp3, wav, m4a, webm) to text.
Works with any OpenAI-compatible endpoint that supports /v1/audio/transcriptions.

Usage::

    from owlmind.voice import transcribe_file, transcribe_bytes

    text = transcribe_file("/path/to/audio.ogg")
    text = transcribe_bytes(ogg_bytes, filename="voice.ogg")

Requires: httpx (already in owlmind deps)
Optional: openai SDK (faster, handles retries)
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# Supported audio formats for Whisper
SUPPORTED_FORMATS = {".ogg", ".mp3", ".wav", ".m4a", ".webm", ".flac", ".mp4", ".mpeg"}

# Default Whisper model
_DEFAULT_MODEL = "whisper-1"


# ---------------------------------------------------------------------------
# Core transcription functions
# ---------------------------------------------------------------------------


def transcribe_file(
    path: str | Path,
    *,
    language: str = "",
    model: str = _DEFAULT_MODEL,
    api_key: str = "",
    base_url: str = "",
) -> str:
    """Transcribe an audio file to text via Whisper API.

    Args:
        path: Path to the audio file.
        language: ISO-639-1 language code (e.g. "ru", "en"). Empty = auto-detect.
        model: Whisper model name (default: "whisper-1").
        api_key: OpenAI API key. Falls back to OPENAI_API_KEY env var.
        base_url: API base URL. Falls back to OPENAI_BASE_URL or OpenAI default.

    Returns:
        Transcribed text string.

    Raises:
        ValueError: If the file format is not supported.
        RuntimeError: If transcription fails.
    """
    p = Path(path)
    if p.suffix.lower() not in SUPPORTED_FORMATS:
        raise ValueError(
            f"Unsupported audio format: {p.suffix}. "
            f"Supported: {', '.join(sorted(SUPPORTED_FORMATS))}"
        )

    with open(p, "rb") as f:
        audio_bytes = f.read()

    return transcribe_bytes(
        audio_bytes,
        filename=p.name,
        language=language,
        model=model,
        api_key=api_key,
        base_url=base_url,
    )


def transcribe_bytes(
    data: bytes,
    filename: str = "audio.ogg",
    *,
    language: str = "",
    model: str = _DEFAULT_MODEL,
    api_key: str = "",
    base_url: str = "",
) -> str:
    """Transcribe audio bytes to text via Whisper API.

    Args:
        data: Raw audio bytes.
        filename: Filename hint (determines content-type). Should have correct extension.
        language: ISO-639-1 language code. Empty = auto-detect.
        model: Whisper model name.
        api_key: API key. Falls back to OPENAI_API_KEY.
        base_url: Base URL. Falls back to OPENAI_BASE_URL.

    Returns:
        Transcribed text string.
    """
    key = api_key or os.environ.get("WHISPER_API_KEY", "") or os.environ.get("OPENAI_API_KEY", "")
    # Whisper always uses api.openai.com regardless of OPENAI_BASE_URL
    url = base_url or os.environ.get("WHISPER_BASE_URL", "https://api.openai.com")
    url = url.rstrip("/")

    if not key:
        raise RuntimeError(
            "No API key for Whisper transcription. Set OPENAI_API_KEY in .env"
        )

    # Try openai SDK first (handles retries, streaming)
    result = _transcribe_openai_sdk(data, filename, model=model, language=language, api_key=key, base_url=url)
    if result is not None:
        return result

    # Fallback: raw httpx multipart POST
    return _transcribe_httpx(data, filename, model=model, language=language, api_key=key, base_url=url)


def is_available() -> bool:
    """Return True if Whisper transcription is likely available."""
    key = os.environ.get("WHISPER_API_KEY", "") or os.environ.get("OPENAI_API_KEY", "")
    if not key:
        return False
    try:
        import httpx  # noqa: F401
        return True
    except ImportError:
        pass
    try:
        import openai  # noqa: F401
        return True
    except ImportError:
        pass
    return False


# ---------------------------------------------------------------------------
# Telegram voice message helpers
# ---------------------------------------------------------------------------


async def transcribe_telegram_voice(
    file_bytes: bytes,
    *,
    language: str = "",
) -> str:
    """Transcribe a Telegram voice message (OGG/Opus format).

    Args:
        file_bytes: Raw OGG bytes downloaded from Telegram.
        language: ISO-639-1 language code. Empty = auto-detect.

    Returns:
        Transcribed text or empty string on failure.
    """
    try:
        text = transcribe_bytes(file_bytes, filename="voice.ogg", language=language)
        logger.info("Transcribed Telegram voice: %d chars", len(text))
        return text
    except Exception as e:
        logger.warning("Voice transcription failed: %s", e)
        return ""


def transcribe_telegram_voice_sync(
    file_bytes: bytes,
    *,
    language: str = "",
) -> str:
    """Synchronous version of transcribe_telegram_voice."""
    try:
        return transcribe_bytes(file_bytes, filename="voice.ogg", language=language)
    except Exception as e:
        logger.warning("Voice transcription failed: %s", e)
        return ""


# ---------------------------------------------------------------------------
# Backend implementations
# ---------------------------------------------------------------------------


def _transcribe_openai_sdk(
    data: bytes,
    filename: str,
    *,
    model: str,
    language: str,
    api_key: str,
    base_url: str,
) -> str | None:
    """Try transcription via openai SDK. Returns None if SDK not available."""
    try:
        import openai
    except ImportError:
        return None

    try:
        client = openai.OpenAI(api_key=api_key, base_url=base_url)

        kwargs: dict[str, Any] = {"model": model, "file": (filename, data)}
        if language:
            kwargs["language"] = language

        response = client.audio.transcriptions.create(**kwargs)
        return response.text
    except Exception as e:
        logger.debug("openai SDK transcription failed: %s", e)
        return None


def _transcribe_httpx(
    data: bytes,
    filename: str,
    *,
    model: str,
    language: str,
    api_key: str,
    base_url: str,
) -> str:
    """Transcribe via raw httpx multipart POST."""
    try:
        import httpx
    except ImportError as err:
        raise RuntimeError("httpx not installed — cannot transcribe audio") from err

    endpoint = f"{base_url}/v1/audio/transcriptions"
    headers = {"Authorization": f"Bearer {api_key}"}

    # Guess content type from extension
    ext = Path(filename).suffix.lower()
    content_type_map = {
        ".ogg": "audio/ogg",
        ".mp3": "audio/mpeg",
        ".wav": "audio/wav",
        ".m4a": "audio/mp4",
        ".webm": "audio/webm",
        ".flac": "audio/flac",
    }
    content_type = content_type_map.get(ext, "audio/ogg")

    files = {"file": (filename, data, content_type)}
    form_data: dict[str, str] = {"model": model}
    if language:
        form_data["language"] = language

    try:
        resp = httpx.post(
            endpoint,
            headers=headers,
            files=files,
            data=form_data,
            timeout=60,
        )
        resp.raise_for_status()
        result = resp.json()
        text = result.get("text", "")
        logger.info("Whisper transcribed %d bytes → %d chars", len(data), len(text))
        return text
    except Exception as e:
        raise RuntimeError(f"Whisper API error: {e}") from e


# ---------------------------------------------------------------------------
# CLI convenience
# ---------------------------------------------------------------------------


def transcribe_cli(path: str, language: str = "") -> None:
    """Print transcription of *path* to stdout (for CLI use)."""
    try:
        text = transcribe_file(path, language=language)
        print(text)
    except Exception as e:
        print(f"Error: {e}")
