"""Monitoring — daily digest, stuck detection, alerts."""

from __future__ import annotations

import contextlib
import json
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path


@dataclass
class DigestReport:
    """Daily digest summary."""

    days: int = 1
    total_tokens: int = 0
    estimated_usd: float = 0.0
    llm_calls: int = 0
    runs_done: int = 0
    runs_failed: int = 0
    runs_blocked: int = 0
    runs_other: int = 0
    sessions_done: int = 0
    sessions_failed: int = 0
    sessions_blocked: int = 0
    sessions_running: int = 0
    recent_failures: list[dict[str, str]] = field(default_factory=list)
    action_list: list[str] = field(default_factory=list)


@dataclass
class StuckSession:
    """A session that appears stuck."""

    session_id: str
    status: str
    updated_at: str
    minutes_since_update: int
    suggested_commands: list[str] = field(default_factory=list)


def build_digest(
    *,
    ledger_dir: Path,
    runs_dir: Path,
    sessions_dir: Path,
    days: int = 1,
) -> DigestReport:
    """Build a daily digest report.

    Reads ledger for usage, scans runs/ and sessions/ for state counts.
    """
    report = DigestReport(days=days)

    # --- Ledger usage ---
    from owlmind.ledger import UsageLedger

    ledger = UsageLedger(ledger_dir)
    totals = ledger.totals_for_day()
    report.total_tokens = totals.total_tokens
    report.estimated_usd = totals.estimated_usd
    report.llm_calls = totals.llm_calls

    # --- Runs by state ---
    if runs_dir.exists():
        for run_dir in runs_dir.iterdir():
            if not run_dir.is_dir():
                continue
            meta_path = run_dir / "cycle_meta.json"
            if not meta_path.exists():
                continue
            with contextlib.suppress(json.JSONDecodeError, OSError):
                meta = json.loads(meta_path.read_text())
                state = meta.get("state", "")
                if state == "DONE":
                    report.runs_done += 1
                elif state == "FAILED":
                    report.runs_failed += 1
                    report.recent_failures.append(
                        {
                            "type": "run",
                            "id": run_dir.name,
                            "state": state,
                        }
                    )
                elif state in ("BLOCKED", "WAIT_APPROVAL"):
                    report.runs_blocked += 1
                    report.action_list.append(
                        f"owlmind cycle status --run-id {run_dir.name}",
                    )
                else:
                    report.runs_other += 1

    # --- Sessions by state ---
    if sessions_dir.exists():
        for sess_dir in sessions_dir.iterdir():
            if not sess_dir.is_dir():
                continue
            meta_path = sess_dir / "session_meta.json"
            if not meta_path.exists():
                continue
            with contextlib.suppress(json.JSONDecodeError, OSError):
                meta = json.loads(meta_path.read_text())
                status = meta.get("status", "")
                if status == "DONE":
                    report.sessions_done += 1
                elif status == "FAILED":
                    report.sessions_failed += 1
                    report.recent_failures.append(
                        {
                            "type": "session",
                            "id": sess_dir.name,
                            "state": status,
                        }
                    )
                elif status == "BLOCKED":
                    report.sessions_blocked += 1
                    report.action_list.append(
                        f"owlmind session resume --session-id {sess_dir.name}",
                    )
                elif status == "RUNNING":
                    report.sessions_running += 1

    # Trim failures to 10
    report.recent_failures = report.recent_failures[:10]

    return report


def detect_stuck_sessions(
    sessions_dir: Path,
    *,
    threshold_minutes: int = 30,
) -> list[StuckSession]:
    """Detect sessions that appear stuck.

    Criteria: status RUNNING but updated_at older than threshold.
    """
    stuck: list[StuckSession] = []
    if not sessions_dir.exists():
        return stuck

    now = datetime.now(tz=UTC)

    for sess_dir in sessions_dir.iterdir():
        if not sess_dir.is_dir():
            continue
        meta_path = sess_dir / "session_meta.json"
        if not meta_path.exists():
            continue

        with contextlib.suppress(json.JSONDecodeError, OSError):
            meta = json.loads(meta_path.read_text())
            status = meta.get("status", "")
            if status != "RUNNING":
                continue

            updated_at = meta.get("updated_at", "")
            if not updated_at:
                continue

            updated_dt = datetime.fromisoformat(updated_at)
            delta = now - updated_dt
            minutes = int(delta.total_seconds() / 60)

            if minutes >= threshold_minutes:
                stuck.append(
                    StuckSession(
                        session_id=sess_dir.name,
                        status=status,
                        updated_at=updated_at,
                        minutes_since_update=minutes,
                        suggested_commands=[
                            f"owlmind session status --session-id {sess_dir.name}",
                            f"owlmind session resume --session-id {sess_dir.name}",
                        ],
                    )
                )

    return stuck


def format_digest_markdown(report: DigestReport) -> str:
    """Format digest as markdown text."""
    lines = [
        "# OWLMIND Daily Digest",
        "",
        f"**Period:** last {report.days} day(s)",
        "",
        "## Usage",
        f"- Tokens: {report.total_tokens:,}",
        f"- Cost: ${report.estimated_usd:.4f}",
        f"- LLM calls: {report.llm_calls}",
        "",
        "## Runs",
        f"- Done: {report.runs_done}",
        f"- Failed: {report.runs_failed}",
        f"- Blocked: {report.runs_blocked}",
        f"- Other: {report.runs_other}",
        "",
        "## Sessions",
        f"- Done: {report.sessions_done}",
        f"- Failed: {report.sessions_failed}",
        f"- Blocked: {report.sessions_blocked}",
        f"- Running: {report.sessions_running}",
    ]

    if report.recent_failures:
        lines.append("")
        lines.append("## Recent Failures")
        for f in report.recent_failures:
            lines.append(f"- [{f['type']}] {f['id']}: {f['state']}")

    if report.action_list:
        lines.append("")
        lines.append("## Actions Needed")
        for cmd in report.action_list:
            lines.append(f"- `{cmd}`")

    lines.append("")
    return "\n".join(lines)


def format_stuck_text(stuck: list[StuckSession]) -> str:
    """Format stuck sessions for display."""
    if not stuck:
        return "No stuck sessions found."

    lines = [f"Found {len(stuck)} stuck session(s):"]
    for s in stuck:
        lines.append(f"\n  {s.session_id} — {s.minutes_since_update}min since update")
        for cmd in s.suggested_commands:
            lines.append(f"    {cmd}")

    return "\n".join(lines)
