"""OWLMIND cost estimator — pre-run cost prediction."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from owlmind.config import BudgetConfig, PricingConfig

# ── Default token estimates per stage ──

_DEFAULT_TOKENS: dict[str, tuple[int, int]] = {
    # (input_tokens, output_tokens)
    "planner": (800, 500),
    "worker": (4000, 5000),
    "judge": (1200, 800),
}


@dataclass
class CostEstimate:
    """Estimated cost for a single run or session."""

    estimated_input_tokens: int = 0
    estimated_output_tokens: int = 0
    estimated_total_tokens: int = 0
    estimated_usd_low: float = 0.0
    estimated_usd_high: float = 0.0
    provider: str = ""
    iterations: int = 1
    budget_pct: float = 0.0
    budget_warning: bool = False
    details: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "estimated_input_tokens": self.estimated_input_tokens,
            "estimated_output_tokens": self.estimated_output_tokens,
            "estimated_total_tokens": self.estimated_total_tokens,
            "estimated_usd_low": round(self.estimated_usd_low, 4),
            "estimated_usd_high": round(self.estimated_usd_high, 4),
            "provider": self.provider,
            "iterations": self.iterations,
            "budget_pct": round(self.budget_pct, 1),
            "budget_warning": self.budget_warning,
            "details": self.details,
        }

    @property
    def display_range(self) -> str:
        """Human-friendly cost range string."""
        return f"${self.estimated_usd_low:.4f} – ${self.estimated_usd_high:.4f}"


def _goal_complexity(goal: str) -> float:
    """Estimate goal complexity as a multiplier (1.0 – 3.0).

    Heuristics:
      - Longer goals tend to be more complex.
      - Multiple sentences / bullet points suggest multi-step work.
    """
    word_count = len(goal.split())
    line_count = len(goal.strip().splitlines())

    multiplier = 1.0
    if word_count > 50:
        multiplier += 0.5
    if word_count > 100:
        multiplier += 0.5
    if line_count > 3:
        multiplier += 0.5
    if line_count > 7:
        multiplier += 0.5

    return min(multiplier, 3.0)


def estimate_goal(
    goal: str,
    provider: str,
    pricing: PricingConfig,
    budget: BudgetConfig,
    *,
    iterations: int = 1,
    remaining_usd: float | None = None,
) -> CostEstimate:
    """Estimate cost for a single goal execution.

    Args:
        goal: The goal description text.
        provider: LLM provider name (openai, anthropic, gemini).
        pricing: Pricing configuration.
        budget: Budget configuration.
        iterations: Expected number of planner/judge iterations.
        remaining_usd: Remaining daily budget (if known).

    Returns:
        A CostEstimate with predicted token counts and USD range.
    """
    complexity = _goal_complexity(goal)
    price_in, price_out = pricing.price_for_provider(provider)

    total_in = 0
    total_out = 0
    stage_details: dict[str, Any] = {}

    for stage, (base_in, base_out) in _DEFAULT_TOKENS.items():
        reps = iterations if stage in ("planner", "judge") else 1
        stage_in = int(base_in * complexity * reps)
        stage_out = int(base_out * complexity * reps)
        total_in += stage_in
        total_out += stage_out
        stage_details[stage] = {
            "input_tokens": stage_in,
            "output_tokens": stage_out,
            "repetitions": reps,
        }

    # Low estimate = 70% of prediction, high = 150%
    cost_base = (total_in / 1000) * price_in + (total_out / 1000) * price_out
    usd_low = cost_base * 0.7
    usd_high = cost_base * 1.5

    # Budget percentage
    daily_max = budget.max_usd_per_day
    effective_remaining = remaining_usd if remaining_usd is not None else daily_max
    budget_pct = (usd_high / effective_remaining * 100) if effective_remaining > 0 else 0.0
    budget_warning = budget_pct > 50.0

    return CostEstimate(
        estimated_input_tokens=total_in,
        estimated_output_tokens=total_out,
        estimated_total_tokens=total_in + total_out,
        estimated_usd_low=usd_low,
        estimated_usd_high=usd_high,
        provider=provider,
        iterations=iterations,
        budget_pct=budget_pct,
        budget_warning=budget_warning,
        details={
            "complexity_multiplier": round(complexity, 2),
            "stages": stage_details,
        },
    )


def estimate_session(
    goals: list[str],
    provider: str,
    pricing: PricingConfig,
    budget: BudgetConfig,
    *,
    iterations_per_goal: int = 1,
    remaining_usd: float | None = None,
) -> CostEstimate:
    """Estimate total cost for a session (multiple goals).

    Args:
        goals: List of goal description strings.
        provider: LLM provider name.
        pricing: Pricing configuration.
        budget: Budget configuration.
        iterations_per_goal: Expected iterations per goal.
        remaining_usd: Remaining daily budget.

    Returns:
        Aggregated CostEstimate for the entire session.
    """
    if not goals:
        return CostEstimate(provider=provider)

    total_in = 0
    total_out = 0
    total_low = 0.0
    total_high = 0.0
    goal_details: list[dict[str, Any]] = []

    for goal in goals:
        est = estimate_goal(
            goal,
            provider,
            pricing,
            budget,
            iterations=iterations_per_goal,
            remaining_usd=remaining_usd,
        )
        total_in += est.estimated_input_tokens
        total_out += est.estimated_output_tokens
        total_low += est.estimated_usd_low
        total_high += est.estimated_usd_high
        goal_details.append(
            {
                "goal": goal[:80] + ("..." if len(goal) > 80 else ""),
                "usd_range": est.display_range,
            }
        )

    daily_max = budget.max_usd_per_day
    effective_remaining = remaining_usd if remaining_usd is not None else daily_max
    budget_pct = (total_high / effective_remaining * 100) if effective_remaining > 0 else 0.0
    budget_warning = budget_pct > 50.0

    return CostEstimate(
        estimated_input_tokens=total_in,
        estimated_output_tokens=total_out,
        estimated_total_tokens=total_in + total_out,
        estimated_usd_low=total_low,
        estimated_usd_high=total_high,
        provider=provider,
        iterations=iterations_per_goal,
        budget_pct=budget_pct,
        budget_warning=budget_warning,
        details={
            "goal_count": len(goals),
            "goals": goal_details,
        },
    )
