"""Operator service -- manages autopilot/E2E runs with concurrency control.

Provides run registry, file locking (fcntl.flock), workspace allowlist,
and async lifecycle for Telegram operator mode.
"""

from __future__ import annotations

import asyncio
import json
import logging
import threading
import time
from pathlib import Path
from typing import Any

from owlmind.operator._git import _auto_commit
from owlmind.operator._models import (
    RunInfo,
    RunLock,
    _map_state_to_status,
    _session_result_to_dict,
)
from owlmind.operator._sessions import _SessionsMixin

logger = logging.getLogger(__name__)

__all__ = [
    "OperatorService",
    "RunInfo",
    "RunLock",
    "_auto_commit",
    "_map_state_to_status",
    "_session_result_to_dict",
]


class OperatorService(_SessionsMixin):
    """Manages autopilot/E2E runs with concurrency control and workspace safety."""

    def __init__(
        self,
        *,
        runs_dir: Path,
        policies_dir: Path,
        ledger_dir: Path,
        sessions_dir: Path | None = None,
        allowed_workspaces: list[str] | None = None,
        default_workspace: str = ".",
        max_concurrent_runs: int = 0,  # 0 = unlimited
        storage: Any | None = None,
    ) -> None:
        self.runs_dir = runs_dir
        self.policies_dir = policies_dir
        self.ledger_dir = ledger_dir
        self.sessions_dir = sessions_dir or (
            runs_dir.parent / "sessions" if runs_dir else Path("sessions")
        )
        self.allowed_workspaces = allowed_workspaces or []
        self.default_workspace = default_workspace
        self.max_concurrent_runs = max_concurrent_runs
        self._storage = storage
        self._semaphore: threading.Semaphore | None = (
            threading.Semaphore(max_concurrent_runs) if max_concurrent_runs > 0 else None
        )
        self._runs: dict[str, RunInfo] = {}
        self._locks: dict[str, RunLock] = {}
        self._llm_profile: str = "balanced"

    def is_workspace_allowed(self, workspace: str) -> bool:
        """Check if workspace is in the allowlist. Empty list = all allowed."""
        if not self.allowed_workspaces:
            return True
        ws = Path(workspace).resolve()
        return any(
            str(ws).startswith(str(Path(allowed).resolve())) for allowed in self.allowed_workspaces
        )

    def active_runs(self) -> list[RunInfo]:
        """Return list of currently running runs."""
        return [r for r in self._runs.values() if r.status == "running"]

    def all_runs(self) -> list[RunInfo]:
        """Return all tracked runs."""
        return list(self._runs.values())

    def get_run(self, run_id: str) -> RunInfo | None:
        """Get run info by ID."""
        return self._runs.get(run_id)

    def acquire_lock(self, run_id: str) -> bool:
        """Acquire file lock for a run. Returns True if acquired."""
        lock_path = self.runs_dir / run_id / ".lock"
        lock = RunLock(lock_path)
        if lock.acquire():
            self._locks[run_id] = lock
            return True
        return False

    def release_lock(self, run_id: str) -> None:
        """Release file lock for a run."""
        lock = self._locks.pop(run_id, None)
        if lock:
            lock.release()

    def start_autopilot(
        self,
        goal: str,
        workspace: str,
        *,
        use_llm: str = "both",
        use_worker: str = "none",
        max_steps: int = 200,
        max_iterations: int = 10,
        sandbox: bool = False,
        auto_approve: bool = False,
        on_event: Any = None,
    ) -> RunInfo:
        """Start a new autopilot run (blocking). Returns RunInfo."""
        from owlmind.autopilot import AutoPilotConfig
        from owlmind.autopilot import run as autopilot_run

        ap_config = AutoPilotConfig(
            goal=goal,
            workspace=workspace,
            sandbox=sandbox,
            use_llm=use_llm,
            use_worker=use_worker,
            max_steps=max_steps,
            max_iterations=max_iterations,
            auto_approve=auto_approve,
            policies_dir=self.policies_dir,
            runs_dir=self.runs_dir,
            ledger_dir=self.ledger_dir,
            on_event=on_event,
            storage=self._storage,
        )

        if self._semaphore is not None and not self._semaphore.acquire(blocking=False):
            msg = f"Max concurrent runs ({self.max_concurrent_runs}) reached"
            raise RuntimeError(msg)
        try:
            result = autopilot_run(ap_config)
        finally:
            if self._semaphore is not None:
                self._semaphore.release()

        if result.final_state == "DONE":
            pr_url = _auto_commit(workspace, result.run_id, on_event=on_event)
        else:
            pr_url = ""

        # Compute cost summary from ledger
        cost_summary = ""
        try:
            from owlmind.ledger import UsageLedger
            ledger = UsageLedger(self.ledger_dir)
            totals = ledger.totals_for_run(result.run_id)
            if totals.llm_calls > 0:
                cost_summary = f"{totals.total_tokens:,} tokens | ~${totals.estimated_usd:.4f}"
        except Exception:
            pass

        info = RunInfo(
            run_id=result.run_id,
            goal=goal,
            workspace=workspace,
            status=_map_state_to_status(result.final_state),
            final_state=result.final_state,
            stop_reason=result.stop_reason,
            cost_summary=cost_summary,
            pr_url=pr_url,
        )
        self._runs[result.run_id] = info
        return info

    async def start_autopilot_async(
        self,
        goal: str,
        workspace: str,
        *,
        use_llm: str = "both",
        use_worker: str = "none",
        max_steps: int = 200,
        sandbox: bool = False,
        auto_approve: bool = False,
        on_event: Any = None,
    ) -> RunInfo:
        """Start autopilot in a thread executor (non-blocking for asyncio)."""
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            None,
            lambda: self.start_autopilot(
                goal,
                workspace,
                use_llm=use_llm,
                use_worker=use_worker,
                max_steps=max_steps,
                sandbox=sandbox,
                auto_approve=auto_approve,
                on_event=on_event,
            ),
        )

    def run_parallel(
        self,
        goals: list[str],
        workspace: str,
        *,
        max_workers: int = 3,
        use_llm: str = "both",
        use_worker: str = "none",
        max_steps: int = 200,
        sandbox: bool = False,
        on_event: Any = None,
    ) -> list[RunInfo]:
        """Run multiple autopilot goals concurrently using a thread pool.

        Each goal gets its own full Planner->Worker->Judge cycle.
        Returns list of RunInfo in the same order as goals.
        """
        import concurrent.futures

        if not goals:
            return []

        def _run_one(goal: str) -> RunInfo:
            try:
                return self.start_autopilot(
                    goal,
                    workspace,
                    use_llm=use_llm,
                    use_worker=use_worker,
                    max_steps=max_steps,
                    sandbox=sandbox,
                    on_event=on_event,
                )
            except Exception as exc:
                logger.warning("Parallel subtask failed [%s]: %s", goal[:50], exc)
                import time
                return RunInfo(
                    run_id=f"parallel-err-{int(time.time())}",
                    goal=goal,
                    workspace=workspace,
                    status="failed",
                    stop_reason=str(exc),
                )

        workers = min(max_workers, len(goals))
        with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {pool.submit(_run_one, g): g for g in goals}
            results_map: dict[str, RunInfo] = {}
            for fut in concurrent.futures.as_completed(futures):
                goal = futures[fut]
                try:
                    results_map[goal] = fut.result()
                except Exception as exc:
                    logger.error("Parallel run error [%s]: %s", goal[:50], exc)

        # Return in original order
        return [results_map[g] for g in goals if g in results_map]

    def run_preflight(self, workspace: str, *, use_llm: str = "both") -> dict[str, Any]:
        """Run preflight checks. Returns summary dict."""
        from owlmind.preflight import PreflightConfig, run_preflight

        config = PreflightConfig(use_llm=use_llm, workspace=workspace)
        report = run_preflight(config)
        return {
            "ok": report.ok,
            "checks_total": len(report.checks),
            "checks_passed": sum(1 for c in report.checks if c.ok),
            "missing_env": report.missing_env,
            "missing_deps": report.missing_deps,
            "provider_status": report.provider_status,
        }

    def run_e2e_smoke(
        self,
        goal: str,
        workspace: str,
        *,
        use_llm: str = "both",
        use_worker: str = "none",
        max_steps: int = 200,
        on_event: Any = None,
    ) -> dict[str, Any]:
        """Run E2E smoke (blocking). Returns summary dict."""
        from owlmind.e2e import E2EConfig, run_e2e

        config = E2EConfig(
            goal=goal,
            workspace=workspace,
            sandbox=False,
            use_llm=use_llm,
            use_worker=use_worker,
            max_steps=max_steps,
            policies_dir=self.policies_dir,
            runs_dir=self.runs_dir,
            ledger_dir=self.ledger_dir,
            on_event=on_event,
        )
        result = run_e2e(config)

        info = RunInfo(
            run_id=result.run_id,
            goal=goal,
            workspace=workspace,
            status="done"
            if result.exit_code == 0
            else "blocked"
            if result.exit_code == 2
            else "failed",
            final_state=result.final_state,
            stop_reason=result.blocked_reason,
        )
        self._runs[result.run_id] = info

        return {
            "run_id": result.run_id,
            "exit_code": result.exit_code,
            "final_state": result.final_state,
            "preflight_ok": result.preflight_ok,
            "blocked_reason": result.blocked_reason,
            "next_commands": result.next_commands,
            "report_path": result.report_path,
        }

    def stop_run(self, run_id: str) -> bool:
        """Mark a run as stopped. Returns True if run was found."""
        info = self._runs.get(run_id)
        if not info:
            return False
        info.status = "stopped"
        info.stop_reason = "user_requested"
        self.release_lock(run_id)
        return True

    def recover_runs_from_disk(self) -> list[RunInfo]:
        """Scan runs directory and recover orphaned in-progress runs into memory."""
        if not self.runs_dir.exists():
            return []
        _ACTIVE_STATES = frozenset(
            {
                "RUNNING",
                "STARTED",
                "WAIT_APPROVAL",
                "STARTED_WAIT_PLANNER",
                "WAIT_WORKER",
                "WAIT_JUDGE",
            }
        )
        recovered: list[RunInfo] = []
        for run_path in self.runs_dir.iterdir():
            if not run_path.is_dir():
                continue
            meta_path = run_path / "cycle_meta.json"
            if not meta_path.exists():
                continue
            try:
                meta = json.loads(meta_path.read_text())
            except (json.JSONDecodeError, OSError):
                continue
            run_id = meta.get("run_id", run_path.name)
            if run_id in self._runs:
                continue
            state = meta.get("state", "")
            if state not in _ACTIVE_STATES:
                continue
            info = RunInfo(
                run_id=run_id,
                goal=meta.get("goal", ""),
                workspace=meta.get("workspace", "."),
                status="running",
                started_at=time.time(),
                final_state=state,
                stop_reason="recovered",
            )
            self._runs[run_id] = info
            recovered.append(info)
            logger.info("Recovered orphaned run: %s (state=%s)", run_id, state)
        return recovered

    def recover_sessions_from_disk(self) -> list[dict[str, Any]]:
        """Scan sessions directory and return info about orphaned RUNNING sessions.

        Sessions in RUNNING state that haven't been updated recently are
        considered orphaned after a process crash/restart.
        """
        from owlmind.session import load_session

        sessions_dir = self.runs_dir.parent / "sessions"
        if not sessions_dir.exists():
            return []

        _ACTIVE_STATES = frozenset({"RUNNING", "BLOCKED"})
        recovered: list[dict[str, Any]] = []

        for sdir in sessions_dir.iterdir():
            if not sdir.is_dir():
                continue
            session_id = sdir.name
            try:
                meta = load_session(session_id, sessions_dir)
            except (FileNotFoundError, Exception) as e:
                logger.debug("Skipping session %s: %s", session_id, e)
                continue

            if meta.status not in _ACTIVE_STATES:
                continue

            recovered.append(
                {
                    "session_id": session_id,
                    "status": meta.status,
                    "current_goal_index": meta.current_goal_index,
                    "total_goals": len(meta.goals),
                    "updated_at": meta.updated_at,
                }
            )
            logger.info(
                "Found orphaned session: %s (status=%s, goal %d/%d)",
                session_id,
                meta.status,
                meta.current_goal_index,
                len(meta.goals),
            )

        return recovered

    def update_model_config(self, profile: str) -> None:
        """Update the LLM profile for future autopilot runs.

        Sets OWLMIND_LLM_PROFILE and OWLMIND_LLM_MODEL env vars so that
        subprocess workers (claude CLI) inherit the updated model choice.
        Also sets provider-specific env vars that config.py reads at startup
        so that in-process LLM driver re-initialisation picks up the new model.
        """
        _LLM_PROFILE_MODELS = {
            "fast": "claude-3-haiku-20240307",
            "balanced": "claude-sonnet-4-6",
            "powerful": "claude-opus-4-6",
        }
        if profile not in _LLM_PROFILE_MODELS:
            raise ValueError(
                f"Unknown LLM profile: {profile!r}. Valid: {list(_LLM_PROFILE_MODELS)}"
            )
        model = _LLM_PROFILE_MODELS[profile]
        self._llm_profile = profile
        import os

        os.environ["OWLMIND_LLM_PROFILE"] = profile
        os.environ["OWLMIND_LLM_MODEL"] = model
        # Also set provider-specific env vars that config.py reads via from_env():
        #   AnthropicConfig: OWLMIND_ANTHROPIC_MODEL
        #   OpenAIConfig:    OWLMIND_OPENAI_PLANNER_MODEL, OWLMIND_OPENAI_JUDGE_MODEL
        #   GeminiConfig:    OWLMIND_GEMINI_MODEL
        os.environ["OWLMIND_ANTHROPIC_MODEL"] = model
        os.environ["OWLMIND_OPENAI_PLANNER_MODEL"] = model
        os.environ["OWLMIND_OPENAI_JUDGE_MODEL"] = model
        os.environ["OWLMIND_GEMINI_MODEL"] = model
        logger.info("LLM profile updated: %s (%s)", profile, model)

    @property
    def llm_profile(self) -> str:
        """Current LLM profile name."""
        return self._llm_profile
