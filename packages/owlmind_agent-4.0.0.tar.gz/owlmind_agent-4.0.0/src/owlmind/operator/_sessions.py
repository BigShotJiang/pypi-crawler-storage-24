"""Session management mixin for OperatorService."""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Any

from owlmind.operator._models import _session_result_to_dict

logger = logging.getLogger(__name__)


class _SessionsMixin:
    """Mixin providing all session-related methods for OperatorService."""

    # ------------------------------------------------------------------
    # Session APIs
    # ------------------------------------------------------------------

    def start_session(
        self,
        goals_file: str,
        workspace: str,
        *,
        max_concurrency: int = 1,
        continue_on_fail: bool = False,
        sandbox: bool = False,
        use_llm: str = "both",
        use_worker: str = "none",
        on_event: Any = None,
    ) -> dict[str, Any]:
        """Start a new session from a goals file (blocking). Returns result dict.

        Extra flags (sandbox, use_llm, use_worker) are stored in session
        config and applied as defaults for goals that don't override them.
        """
        from owlmind.session import create_session
        from owlmind.session_runner import run_session

        goals_path = Path(goals_file)
        if not goals_path.exists():
            msg = f"Goals file not found: {goals_file}"
            raise FileNotFoundError(msg)

        meta = create_session(
            goals_file=goals_path,
            workspace=workspace,
            sessions_dir=self.sessions_dir,
            policies_dir=str(self.policies_dir),
            runs_dir=str(self.runs_dir),
            ledger_dir=str(self.ledger_dir),
            max_concurrency=max_concurrency,
            continue_on_fail=continue_on_fail,
        )

        # Apply session-level overrides to all goals
        for g in meta.goals:
            if sandbox:
                g.sandbox = True
            if use_llm != "both":
                g.use_llm = use_llm
            if use_worker != "none":
                g.use_worker = use_worker

        # Persist overrides in config
        meta.config["sandbox"] = sandbox
        meta.config["use_llm"] = use_llm
        meta.config["use_worker"] = use_worker

        from owlmind.session import save_session

        save_session(meta, self.sessions_dir)

        result = run_session(
            meta.session_id,
            sessions_dir=self.sessions_dir,
            runs_dir=self.runs_dir,
            policies_dir=self.policies_dir,
            ledger_dir=self.ledger_dir,
            max_concurrency=max_concurrency,
            continue_on_fail=continue_on_fail,
            on_event=on_event,
        )

        return _session_result_to_dict(result)

    async def start_session_async(
        self,
        goals_file: str,
        workspace: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Start session in a thread executor (non-blocking for asyncio)."""
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            None,
            lambda: self.start_session(goals_file, workspace, **kwargs),
        )

    def resume_session(
        self,
        session_id: str,
        *,
        max_concurrency: int | None = None,
        continue_on_fail: bool | None = None,
        on_event: Any = None,
    ) -> dict[str, Any]:
        """Resume a session (blocking). Returns result dict."""
        from owlmind.session_runner import run_session

        result = run_session(
            session_id,
            sessions_dir=self.sessions_dir,
            runs_dir=self.runs_dir,
            policies_dir=self.policies_dir,
            ledger_dir=self.ledger_dir,
            max_concurrency=max_concurrency,
            continue_on_fail=continue_on_fail,
            on_event=on_event,
        )

        return _session_result_to_dict(result)

    async def resume_session_async(
        self,
        session_id: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Resume session in a thread executor."""
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            None,
            lambda: self.resume_session(session_id, **kwargs),
        )

    def get_session_status(self, session_id: str) -> dict[str, Any]:
        """Get session status. Returns summary dict."""
        from owlmind.session import load_session

        meta = load_session(session_id, self.sessions_dir)
        run_map = {r.goal_id: r for r in meta.runs}

        goals_info = []
        for g in meta.goals:
            run = run_map.get(g.id)
            goals_info.append(
                {
                    "id": g.id,
                    "goal": g.goal[:60],
                    "status": run.status if run else "pending",
                    "run_id": run.run_id if run else "",
                }
            )

        return {
            "session_id": meta.session_id,
            "status": meta.status,
            "created_at": meta.created_at,
            "goals_total": len(meta.goals),
            "max_concurrency": meta.max_concurrency,
            "continue_on_fail": meta.continue_on_fail,
            "last_block_reason": meta.last_block_reason,
            "goals": goals_info,
        }

    def stop_session(self, session_id: str) -> dict[str, Any]:
        """Stop a running session. Returns status dict."""
        from owlmind.session_runner import stop_session

        meta = stop_session(session_id, self.sessions_dir, self.runs_dir)
        return {
            "session_id": meta.session_id,
            "status": meta.status,
        }

    def get_session_graph(self, session_id: str) -> str:
        """Get DAG summary for a session."""
        from owlmind.dag import format_dag_summary
        from owlmind.session import load_session

        meta = load_session(session_id, self.sessions_dir)
        goal_dicts: list[dict[str, object]] = [
            {"id": g.id, "depends_on": g.depends_on, "goal": g.goal} for g in meta.goals
        ]
        run_map = {r.goal_id: r for r in meta.runs}
        statuses = {
            g.id: (run_map[g.id].status if g.id in run_map else "pending") for g in meta.goals
        }
        return format_dag_summary(goal_dicts, statuses)

    def export_session(
        self,
        session_id: str,
        *,
        out_path: Path | None = None,
    ) -> str:
        """Export session as zip. Returns path string."""
        from owlmind.session_export import export_session

        zip_path = export_session(
            session_id,
            sessions_dir=self.sessions_dir,
            runs_dir=self.runs_dir,
            out_path=out_path,
        )
        return str(zip_path)

    def rollback_session_goal(
        self,
        session_id: str,
        goal_id: str,
        *,
        yes: bool = False,
    ) -> dict[str, Any]:
        """Rollback a goal. Returns result dict."""
        from owlmind.rollback import (
            create_rollback_request,
            execute_rollback,
            log_rollback_event,
        )
        from owlmind.session import load_session

        meta = load_session(session_id, self.sessions_dir)
        goal = next((g for g in meta.goals if g.id == goal_id), None)
        if goal is None:
            msg = f"Goal {goal_id} not found in session {session_id}"
            raise ValueError(msg)

        run = next((r for r in meta.runs if r.goal_id == goal_id), None)
        run_id = run.run_id if run else f"unknown-{goal_id}"

        if goal.rollback.mode == "none":
            return {"status": "skipped", "reason": "rollback mode is none"}

        request = create_rollback_request(
            goal_id=goal_id,
            run_id=run_id,
            mode=goal.rollback.mode,
            require_approval=goal.rollback.require_approval and not yes,
            runs_dir=self.runs_dir,
        )

        log_rollback_event(
            session_id,
            self.sessions_dir,
            "GOAL_ROLLBACK_REQUESTED",
            {"goal_id": goal_id, "run_id": run_id, "mode": goal.rollback.mode},
        )

        if request.require_approval and not request.approved:
            return {
                "status": "approval_required",
                "token": request.approval_token,
                "instructions": request.instructions,
            }

        result = execute_rollback(request, self.runs_dir)

        log_rollback_event(
            session_id,
            self.sessions_dir,
            "GOAL_ROLLBACK_EXECUTED",
            {"goal_id": goal_id, "run_id": run_id, **result},
        )

        return result

    def list_sessions(self, *, n: int = 20) -> list[dict[str, Any]]:
        """List recent sessions (newest first)."""
        from owlmind.session import load_session

        if not self.sessions_dir.exists():
            return []

        session_dirs = sorted(
            [
                d
                for d in self.sessions_dir.iterdir()
                if d.is_dir() and (d / "session_meta.json").exists()
            ],
            key=lambda d: d.stat().st_mtime,
            reverse=True,
        )[:n]

        results = []
        for d in session_dirs:
            sid = d.name
            try:
                meta = load_session(sid, self.sessions_dir)
                results.append(
                    {
                        "session_id": meta.session_id,
                        "status": meta.status,
                        "goals_total": len(meta.goals),
                        "created_at": meta.created_at,
                    }
                )
            except Exception:
                results.append(
                    {
                        "session_id": sid,
                        "status": "?",
                        "goals_total": 0,
                        "created_at": "?",
                    }
                )
        return results
