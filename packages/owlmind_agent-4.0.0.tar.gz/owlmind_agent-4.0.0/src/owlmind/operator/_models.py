"""Data models and helpers for the operator package."""

from __future__ import annotations

import fcntl
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class RunInfo:
    """Information about a tracked autopilot/E2E run."""

    run_id: str
    goal: str
    workspace: str
    status: str = "running"  # running | blocked | done | failed | stopped
    started_at: float = field(default_factory=time.time)
    final_state: str = ""
    stop_reason: str = ""
    cost_summary: str = ""  # e.g. "12,450 tokens | ~$0.04"
    pr_url: str = ""  # GitHub PR URL after auto-commit


class RunLock:
    """File-based run lock using fcntl.flock (macOS/Linux)."""

    def __init__(self, lock_path: Path) -> None:
        self._path = lock_path
        self._file: Any = None

    def acquire(self) -> bool:
        """Try to acquire an exclusive non-blocking lock. Returns True on success."""
        self._path.parent.mkdir(parents=True, exist_ok=True)
        try:
            self._file = self._path.open("w")
            fcntl.flock(self._file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            return True
        except OSError:
            if self._file:
                self._file.close()
                self._file = None
            return False

    def release(self) -> None:
        """Release the lock."""
        if self._file:
            try:
                fcntl.flock(self._file.fileno(), fcntl.LOCK_UN)
                self._file.close()
            except OSError:
                pass
            self._file = None

    def __enter__(self) -> RunLock:
        if not self.acquire():
            msg = f"Could not acquire lock: {self._path}"
            raise RuntimeError(msg)
        return self

    def __exit__(self, *args: object) -> None:
        self.release()


def _map_state_to_status(state: str) -> str:
    """Map CycleState value to RunInfo status string."""
    if state == "DONE":
        return "done"
    if state == "FAILED":
        return "failed"
    if state in ("WAIT_APPROVAL", "STARTED_WAIT_PLANNER", "WAIT_WORKER", "WAIT_JUDGE"):
        return "blocked"
    return "running"


def _session_result_to_dict(result: Any) -> dict[str, Any]:
    """Convert SessionResult to a serializable dict."""
    return {
        "session_id": result.session_id,
        "status": result.status,
        "goals_total": result.goals_total,
        "goals_done": result.goals_done,
        "goals_failed": result.goals_failed,
        "goals_blocked": result.goals_blocked,
        "goals_skipped": result.goals_skipped,
        "last_block_reason": result.last_block_reason,
        "next_commands": result.next_commands,
    }
