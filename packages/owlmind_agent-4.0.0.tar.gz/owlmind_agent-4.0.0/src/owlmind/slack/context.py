"""SlackBotContext — shared state for all Slack bot handlers."""

from __future__ import annotations

import contextlib
import json
import os
from dataclasses import dataclass, field
from typing import Any


@dataclass
class SlackBotContext:
    """Shared state passed to all Slack slash-command handlers.

    Mirrors BotContext from owlmind.telegram.context but adapted for Slack.
    """

    app: Any
    operator: Any
    allowed_user_ids: list[str]
    llm_profiles: dict[str, dict[str, str]]
    state: dict[str, object]
    state_file: str
    api_port: int
    api_key: str
    api_base: str = field(init=False)

    def __post_init__(self) -> None:
        self.api_base = f"http://127.0.0.1:{self.api_port}"

    def check_auth(self, user_id: str) -> bool:
        """Return True if user_id is authorized (or no allowlist set)."""
        if not self.allowed_user_ids:
            return True
        return user_id in self.allowed_user_ids

    def load_bot_state(self) -> dict[str, object]:
        """Load persisted bot state from disk."""
        with contextlib.suppress(Exception), open(self.state_file) as f:
            data: dict[str, object] = json.loads(f.read())
            return data
        return {}

    def save_bot_state(self) -> None:
        """Persist current bot state to disk."""
        with contextlib.suppress(Exception), open(self.state_file, "w") as f:
            f.write(json.dumps(self.state, indent=2))


def make_slack_context(
    *,
    app: Any,
    operator: Any = None,
    allowed_user_ids: list[str] | None = None,
) -> SlackBotContext:
    """Factory to create SlackBotContext with sensible defaults."""
    state_file = os.path.join(os.path.expanduser("~"), ".owlmind_slack_bot_state.json")

    llm_profiles: dict[str, dict[str, str]] = {
        "fast": {"name": "Fast (Haiku)", "model": "claude-3-haiku-20240307"},
        "balanced": {"name": "Balanced (Sonnet)", "model": "claude-sonnet-4-6"},
        "powerful": {"name": "Powerful (Opus)", "model": "claude-opus-4-6"},
    }

    ctx = SlackBotContext(
        app=app,
        operator=operator,
        allowed_user_ids=allowed_user_ids or [],
        llm_profiles=llm_profiles,
        state={"llm_profile": "balanced"},
        state_file=state_file,
        api_port=int(os.environ.get("OWLMIND_API_PORT", "8765")),
        api_key=os.environ.get("OWLMIND_API_KEY", ""),
    )
    # Merge persisted state
    ctx.state.update(ctx.load_bot_state())
    return ctx
