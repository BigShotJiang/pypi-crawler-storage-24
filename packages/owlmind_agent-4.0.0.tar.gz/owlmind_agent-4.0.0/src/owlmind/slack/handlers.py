"""Slash command handlers for the OwlMind Slack bot.

Each handler follows the Slack Bolt async pattern:
    async def cmd_*(ack, say, command, ctx): ...

The ``ctx`` argument here is a SlackBotContext (not the Bolt context).
"""

from __future__ import annotations

import contextlib
import logging
from typing import Any

logger = logging.getLogger(__name__)

# Module-level scheduler registry keyed by channel_id
_schedulers: dict[str, Any] = {}


# ---------------------------------------------------------------------------
# /cw_help
# ---------------------------------------------------------------------------


async def cmd_cw_help(
    ack: Any,
    say: Any,
    command: dict[str, Any],
    ctx: Any,
) -> None:
    """/cw_help — show available Slack commands."""
    await ack()

    user_id = command.get("user_id", "")
    if not ctx.check_auth(user_id):
        await say("⛔ Not authorized.")
        return

    text = (
        "*OWLMIND Slack Bot*\n\n"
        "*Graph Pipeline:*\n"
        "`/cw_graph <goal>` — Run Architect→Coder→Tester→Reviewer pipeline\n"
        "`/cw_watch_start <goal> [--interval N]` — Start autonomous scheduler\n"
        "`/cw_watch_stop` — Stop autonomous scheduler\n"
        "`/cw_watch_status` — Show scheduler status\n\n"
        "*Monitoring:*\n"
        "`/cw_status [run_id]` — Show run status\n"
        "`/cw_queue` — Manage task queue\n\n"
        "*LLM:*\n"
        "`/cw_model [fast|balanced|powerful]` — Switch LLM profile\n\n"
        "`/cw_help` — This help"
    )
    await say(text)


# ---------------------------------------------------------------------------
# /cw_graph
# ---------------------------------------------------------------------------


async def cmd_cw_graph(
    ack: Any,
    say: Any,
    command: dict[str, Any],
    ctx: Any,
) -> None:
    """/cw_graph <goal> — run Architect→Coder→Tester→Reviewer pipeline."""
    await ack()

    user_id = command.get("user_id", "")
    if not ctx.check_auth(user_id):
        await say("⛔ Not authorized.")
        return

    goal = command.get("text", "").strip()
    if not goal:
        await say("Usage: `/cw_graph <goal>`\n\nExample: `/cw_graph fix all type errors`")
        return

    await say(f"🤖 Running graph pipeline...\nGoal: {goal[:200]}")

    import asyncio
    from concurrent.futures import ThreadPoolExecutor

    workspace = getattr(ctx, "workspace", ".")

    def _run() -> str:
        from owlmind.graph.runner import GraphRunner, _build_llm_client

        if _build_llm_client() is None:
            return "❌ No LLM configured. Set OPENAI_API_KEY or ANTHROPIC_API_KEY."

        runner = GraphRunner()
        state = runner.run(goal, workspace=workspace, max_iterations=3)
        verdict = state.final_verdict or "unknown"
        review = (state.review or "")[:500]
        return f"Verdict: {verdict}\n\n{review}".strip()

    try:
        loop = asyncio.get_event_loop()
        with ThreadPoolExecutor(max_workers=1) as pool:
            result = await loop.run_in_executor(pool, _run)
        icon = "✅" if "APPROVED" in result else "⚠️"
        await say(f"{icon} Graph done:\n\n{result}")
    except Exception as e:
        logger.error("cw_graph handler error: %s", e)
        await say(f"❌ Graph error: {e}")


# ---------------------------------------------------------------------------
# /cw_status
# ---------------------------------------------------------------------------


async def cmd_cw_status(
    ack: Any,
    say: Any,
    command: dict[str, Any],
    ctx: Any,
) -> None:
    """/cw_status [run_id] — show run status."""
    await ack()

    user_id = command.get("user_id", "")
    if not ctx.check_auth(user_id):
        await say("⛔ Not authorized.")
        return

    import json as _json
    import urllib.request

    args = (command.get("text") or "").strip().split()
    run_id = args[0] if args else None

    url = f"{ctx.api_base}/api/v1/runs"
    if run_id:
        url = f"{ctx.api_base}/api/v1/runs/{run_id}"

    try:
        req = urllib.request.Request(
            url,
            headers={"X-API-Key": ctx.api_key} if ctx.api_key else {},
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = _json.loads(resp.read())
    except Exception as e:
        await say(f"⚠️ Could not reach owlmind API: {e}")
        return

    if run_id:
        status = data.get("status", "unknown")
        run_goal = data.get("goal", "")
        await say(f"*Run {run_id}*\nStatus: `{status}`\nGoal: {run_goal}")
    else:
        runs = data.get("runs", [])
        if not runs:
            await say("No tracked runs.")
            return
        lines = ["*Recent runs:*"]
        for r in runs[:10]:
            lines.append(f"  `{r.get('id', '?')}` — {r.get('status', '?')} — {r.get('goal', '')[:60]}")
        await say("\n".join(lines))


# ---------------------------------------------------------------------------
# /cw_watch_start
# ---------------------------------------------------------------------------


async def cmd_cw_watch_start(
    ack: Any,
    say: Any,
    command: dict[str, Any],
    ctx: Any,
) -> None:
    """/cw_watch_start <goal> [--interval N] — start autonomous scheduler."""
    await ack()

    user_id = command.get("user_id", "")
    if not ctx.check_auth(user_id):
        await say("⛔ Not authorized.")
        return

    args = (command.get("text") or "").split()

    # Extract optional --interval flag (default 300)
    interval = 300
    if "--interval" in args:
        idx = args.index("--interval")
        if idx + 1 < len(args):
            with contextlib.suppress(ValueError):
                interval = int(args[idx + 1])
            del args[idx : idx + 2]

    # Extract optional --workspace flag
    workspace = getattr(ctx, "workspace", ".")
    if "--workspace" in args:
        idx = args.index("--workspace")
        if idx + 1 < len(args):
            workspace = args[idx + 1]
            del args[idx : idx + 2]

    goal = " ".join(args).strip()
    if not goal:
        await say(
            "Usage: `/cw_watch_start <goal> [--interval N] [--workspace PATH]`\n\n"
            "Example: `/cw_watch_start fix all lint errors --interval 600`"
        )
        return

    channel_id = command.get("channel_id", user_id)

    # Stop any existing scheduler for this channel
    if channel_id in _schedulers:
        with contextlib.suppress(Exception):
            _schedulers[channel_id].stop()

    from owlmind.autonomous import AutonomousScheduler

    scheduler = AutonomousScheduler(workspace=workspace)
    scheduler.add_goal(goal, source="slack")
    scheduler.start(interval=float(interval))
    _schedulers[channel_id] = scheduler

    await say(f"🔄 Scheduler started.\nGoal: {goal[:200]}\nInterval: {interval}s")


# ---------------------------------------------------------------------------
# /cw_watch_stop
# ---------------------------------------------------------------------------


async def cmd_cw_watch_stop(
    ack: Any,
    say: Any,
    command: dict[str, Any],
    ctx: Any,
) -> None:
    """/cw_watch_stop — stop the autonomous scheduler."""
    await ack()

    user_id = command.get("user_id", "")
    if not ctx.check_auth(user_id):
        await say("⛔ Not authorized.")
        return

    channel_id = command.get("channel_id", user_id)
    scheduler = _schedulers.get(channel_id)
    if scheduler is None:
        await say("No scheduler running.")
        return

    try:
        scheduler.stop()
    except Exception as e:
        logger.error("cw_watch_stop error: %s", e)
    del _schedulers[channel_id]
    await say("⏹ Scheduler stopped.")


# ---------------------------------------------------------------------------
# /cw_watch_status
# ---------------------------------------------------------------------------


async def cmd_cw_watch_status(
    ack: Any,
    say: Any,
    command: dict[str, Any],
    ctx: Any,
) -> None:
    """/cw_watch_status — show scheduler status."""
    await ack()

    user_id = command.get("user_id", "")
    if not ctx.check_auth(user_id):
        await say("⛔ Not authorized.")
        return

    channel_id = command.get("channel_id", user_id)
    scheduler = _schedulers.get(channel_id)
    if scheduler is None:
        await say("No scheduler running for this channel.")
        return

    try:
        st = scheduler.status()
    except Exception as e:
        logger.error("cw_watch_status error: %s", e)
        await say(f"❌ Status error: {e}")
        return

    running = "yes" if st.get("running") else "no"
    queue_size = st.get("queue_size", 0)
    history_count = st.get("history_count", 0)
    github_watchers = st.get("github_watchers", 0)
    file_watchers = st.get("file_watchers", 0)
    recent = st.get("recent", [])

    lines = [
        "*Scheduler status:*",
        f"  Running: {running}",
        f"  Queue size: {queue_size}",
        f"  History: {history_count} run(s)",
        f"  GitHub watchers: {github_watchers}",
        f"  File watchers: {file_watchers}",
    ]
    if recent:
        lines.append("*Recent runs:*")
        for r in recent:
            verdict = r.get("verdict") or "in progress"
            error = r.get("error", "")
            goal_text = r.get("goal", "")[:60]
            line = f"  `[{verdict}]` {goal_text}"
            if error:
                line += f" (err: {error[:60]})"
            lines.append(line)

    await say("\n".join(lines))


# ---------------------------------------------------------------------------
# /cw_model
# ---------------------------------------------------------------------------


async def cmd_cw_model(
    ack: Any,
    say: Any,
    command: dict[str, Any],
    ctx: Any,
) -> None:
    """/cw_model [fast|balanced|powerful] — switch LLM profile."""
    await ack()

    user_id = command.get("user_id", "")
    if not ctx.check_auth(user_id):
        await say("⛔ Not authorized.")
        return

    profile_name = (command.get("text") or "").strip().lower()
    if not profile_name:
        current = ctx.state.get("llm_profile", "balanced")
        profiles_list = ", ".join(ctx.llm_profiles.keys())
        await say(f"Current LLM profile: `{current}`\nAvailable: {profiles_list}")
        return

    if profile_name not in ctx.llm_profiles:
        profiles_list = ", ".join(ctx.llm_profiles.keys())
        await say(f"Unknown profile `{profile_name}`. Available: {profiles_list}")
        return

    ctx.state["llm_profile"] = profile_name
    ctx.save_bot_state()
    profile = ctx.llm_profiles[profile_name]
    await say(f"✅ LLM profile switched to *{profile['name']}* (`{profile['model']}`)")


# ---------------------------------------------------------------------------
# /cw_queue
# ---------------------------------------------------------------------------


async def cmd_cw_queue(
    ack: Any,
    say: Any,
    command: dict[str, Any],
    ctx: Any,
) -> None:
    """/cw_queue — manage task queue."""
    await ack()

    user_id = command.get("user_id", "")
    if not ctx.check_auth(user_id):
        await say("⛔ Not authorized.")
        return

    import json as _json
    import urllib.request

    try:
        req = urllib.request.Request(
            f"{ctx.api_base}/api/v1/queue",
            headers={"X-API-Key": ctx.api_key} if ctx.api_key else {},
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = _json.loads(resp.read())
    except Exception as e:
        await say(f"⚠️ Could not reach owlmind API: {e}")
        return

    items = data.get("items", [])
    if not items:
        await say("Task queue is empty.")
        return

    lines = [f"*Task queue ({len(items)} item(s)):*"]
    for item in items[:15]:
        lines.append(
            f"  `{item.get('id', '?')}` — {item.get('status', '?')} — {str(item.get('goal', ''))[:60]}"
        )
    await say("\n".join(lines))
