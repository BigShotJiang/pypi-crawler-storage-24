"""AutoPilot — full autonomous Planner → Worker → Judge loop in one call.

Usage::

    from owlmind.autopilot import AutoPilotConfig, run

    result = run(AutoPilotConfig(goal="Add tests", workspace="."))
"""

from __future__ import annotations

import logging
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from owlmind.agent.schemas import CycleState

logger = logging.getLogger(__name__)

# Terminal and blocking states
_TERMINAL: frozenset[CycleState] = frozenset({CycleState.DONE, CycleState.FAILED})
_BLOCKING: frozenset[CycleState] = frozenset({CycleState.WAIT_APPROVAL})


@dataclass
class AutoPilotConfig:
    """Configuration for a single autopilot run."""

    goal: str = ""
    workspace: str = "."
    sandbox: bool = False

    # LLM routing
    use_llm: str = "both"  # none | planner | judge | both
    use_worker: str = "claude_cli"  # none | claude_cli
    provider_planner: str | None = None  # force provider for planner
    provider_judge: str | None = None  # force provider for judge

    # Limits
    max_steps: int = 50  # 0 = unlimited
    max_iterations: int = 10  # max planner→worker→judge iterations per cycle
    interval: float = 2.0  # seconds between loop ticks

    # Export
    auto_export: bool = True
    export_dir: Path | None = None

    # Approval
    auto_approve: bool = False  # skip worker approval gate in autonomous mode

    # Resume
    run_id: str | None = None  # resume existing run if set

    # Paths
    policies_dir: Path = field(default_factory=lambda: Path("policies"))
    runs_dir: Path = field(default_factory=lambda: Path("runs"))
    ledger_dir: Path = field(default_factory=lambda: Path("ledger"))
    memory_db: Path = field(default_factory=lambda: Path("memory/memory.db"))

    # Goal refinement (FS55)
    refine_goal: bool = False

    # Heartbeat integration (FS61)
    enable_heartbeat: bool = False

    # Storage backend (optional — if set, overrides path-based construction)
    storage: Any = None  # StorageBackend | None

    # Callbacks
    on_event: Any = None  # optional callable(event_name, data)


@dataclass
class AutoPilotResult:
    """Result of an autopilot run."""

    run_id: str = ""
    final_state: str = ""
    iterations: int = 0
    steps: int = 0
    stop_reason: str = ""
    export_path: str | None = None
    events: list[dict[str, Any]] = field(default_factory=list)


def _emit(config: AutoPilotConfig, name: str, data: dict[str, Any]) -> None:
    """Fire on_event callback if configured."""
    if config.on_event is not None:
        try:
            config.on_event(name, data)
        except Exception:
            logger.debug("on_event callback error for %s", name)


def run(config: AutoPilotConfig) -> AutoPilotResult:
    """Execute the full autonomous loop.

    1. Start (or resume) a cycle
    2. Loop: advance state → call LLM / worker as needed
    3. On DONE → auto-export if enabled
    4. Return AutoPilotResult
    """
    from owlmind.agent.cycle import CycleManager
    from owlmind.budget import BudgetGovernor
    from owlmind.config import OwlMindConfig
    from owlmind.policy import PolicyEngine

    cfg = OwlMindConfig.from_env()

    # --- Build components (storage-aware) ---
    policy = PolicyEngine.from_directory(config.policies_dir)

    if config.storage is not None:
        from owlmind.storage.adapters import get_sync_ledger, get_sync_memory, get_sync_run_storage

        evidence = get_sync_run_storage(config.storage.runs)
        ledger = get_sync_ledger(config.storage.ledger)
        memory_store = get_sync_memory(config.storage.memory) if config.storage.memory else None
    else:
        from owlmind.evidence import EvidenceStore
        from owlmind.ledger import UsageLedger

        evidence = EvidenceStore(config.runs_dir)
        ledger = UsageLedger(config.ledger_dir)
        memory_store = None
        try:
            from owlmind.memory.store import MemoryStore

            memory_store = MemoryStore(config.memory_db)
        except Exception:
            logger.debug("AutoPilot: memory store unavailable, proceeding without it")

    llm_driver = None
    need_llm = config.use_llm in ("planner", "judge", "both")
    if need_llm:
        from owlmind.llm.factory import build_llm_router

        llm_driver = build_llm_router(
            cfg,
            force_planner=config.provider_planner,
            force_judge=config.provider_judge,
        )

    worker_driver = None
    if config.use_worker != "none":
        from owlmind.utils import ToolLimits
        from owlmind.worker.claude_cli_driver import ClaudeCLIDriver

        worker_timeout = int(os.environ.get("OWLMIND_WORKER_TIMEOUT_SECONDS", "300"))
        worker_driver = ClaudeCLIDriver(
            policy=policy,
            continue_mode=cfg.worker.claude_cli_continue,
            limits=ToolLimits(timeout_seconds=worker_timeout),
        )

    governor = BudgetGovernor(cfg.budget, cfg.pricing, ledger)

    heartbeat_engine = None
    if config.enable_heartbeat:
        try:
            from owlmind.events import EventBus
            from owlmind.heartbeat import HeartbeatEngine
            from owlmind.queue import TaskQueue

            heartbeat_engine = HeartbeatEngine(
                cfg.heartbeat,
                TaskQueue(config.runs_dir.parent / "queue"),
                EventBus(),
                policies_dir=config.policies_dir,
                runs_dir=config.runs_dir,
                ledger_dir=config.ledger_dir,
            )
        except Exception:
            logger.debug("AutoPilot: heartbeat unavailable, proceeding without it")

    mgr = CycleManager(
        evidence=evidence,
        policy=policy,
        policies_dir=config.policies_dir,
        llm_driver=llm_driver,
        worker_driver=worker_driver,
        budget_governor=governor,
        ledger=ledger,
        memory_store=memory_store,
    )

    result = AutoPilotResult()

    # --- Start or resume ---
    if config.run_id:
        meta = mgr.load(config.run_id)
        result.run_id = meta.run_id
        _emit(config, "resumed", {"run_id": meta.run_id, "state": meta.state.value})
        logger.info("Resumed run %s (state=%s)", meta.run_id, meta.state.value)
    else:
        meta = mgr.start(
            goal=config.goal,
            workspace=config.workspace,
            sandbox=config.sandbox,
            refine=config.refine_goal,
            max_iterations=config.max_iterations,
        )
        result.run_id = meta.run_id
        _emit(config, "started", {"run_id": meta.run_id, "goal": config.goal})
        logger.info("Started run %s", meta.run_id)

    llm_planner = config.use_llm in ("planner", "both")
    llm_judge = config.use_llm in ("judge", "both")
    worker_auto = config.use_worker != "none"

    step = 0

    # --- Main loop ---
    while True:
        step += 1
        if config.max_steps and step > config.max_steps:
            result.stop_reason = f"max_steps ({config.max_steps}) reached"
            _emit(config, "max_steps", {"step": step})
            logger.info("AutoPilot: max_steps reached at step %d", step)
            break

        # Heartbeat tick (FS61)
        if heartbeat_engine is not None:
            hb_msgs = heartbeat_engine.tick()
            if hb_msgs:
                _emit(config, "heartbeat", {"messages": hb_msgs})
                logger.debug("AutoPilot heartbeat: %s", hb_msgs)

        # Advance cycle
        try:
            meta, message = mgr.next(config.run_id or result.run_id)
        except Exception as exc:
            result.stop_reason = f"next() error: {exc}"
            _emit(config, "error", {"error": str(exc), "step": step})
            logger.error("AutoPilot next() error: %s", exc)
            break

        result.iterations = meta.iteration
        _emit(
            config,
            "step",
            {
                "step": step,
                "state": meta.state.value,
                "iteration": meta.iteration,
                "message": message.splitlines()[0] if message else "",
            },
        )

        # Terminal?
        if meta.state in _TERMINAL:
            result.stop_reason = f"terminal state: {meta.state.value}"
            _emit(config, "terminal", {"state": meta.state.value, "message": message})
            logger.info("AutoPilot: terminal state %s", meta.state.value)
            break

        # Blocked on approval?
        if meta.state in _BLOCKING:
            result.stop_reason = f"blocked: {meta.state.value}"
            _emit(config, "blocked", {"state": meta.state.value, "message": message})
            logger.info("AutoPilot: blocked on %s", meta.state.value)
            break

        # --- Try to advance waiting states ---
        advanced = False

        if meta.state == CycleState.STARTED_WAIT_PLANNER and "Waiting" in message and llm_planner:
            advanced = _try_planner(mgr, result.run_id, config, step)

        elif meta.state == CycleState.WAIT_JUDGE and "Waiting" in message and llm_judge:
            advanced = _try_judge(mgr, result.run_id, config, step)

        elif meta.state == CycleState.WAIT_WORKER and "Waiting" in message and worker_auto:
            ok, blocked = _try_worker(mgr, result.run_id, config, step)
            if blocked:
                result.stop_reason = "blocked: WAIT_APPROVAL (worker)"
                break
            advanced = ok

        if not advanced and "Waiting" in message:
            result.stop_reason = f"waiting: {meta.state.value} (no handler)"
            _emit(config, "waiting", {"state": meta.state.value})
            logger.info("AutoPilot: waiting on %s, no handler", meta.state.value)
            break

        # Hard fail?
        if meta.hard_fail_reasons:
            result.stop_reason = f"hard_fail: {meta.hard_fail_reasons}"
            _emit(config, "hard_fail", {"reasons": meta.hard_fail_reasons})
            break

        time.sleep(config.interval if not advanced else 0.1)

    # --- Finalize ---
    result.steps = step
    # Reload final state
    try:
        final_meta = mgr.status(result.run_id)
        result.final_state = final_meta.state.value
        result.iterations = final_meta.iteration
    except Exception:
        result.final_state = meta.state.value

    # Auto-export on DONE
    if config.auto_export and result.final_state == CycleState.DONE.value:
        try:
            out_path = config.export_dir or None
            export_file: Path | None = None
            if out_path is not None:
                export_file = out_path / f"owlmind_export_{result.run_id}.zip"
            zip_path = mgr.export(result.run_id, out_path=export_file)
            result.export_path = str(zip_path)
            _emit(config, "exported", {"path": str(zip_path)})
            logger.info("AutoPilot: exported to %s", zip_path)
        except Exception as exc:
            logger.warning("AutoPilot: export failed: %s", exc)

    # Collect events for result
    import contextlib

    with contextlib.suppress(Exception):
        result.events = evidence.read_events(result.run_id)

    _emit(
        config,
        "finished",
        {
            "run_id": result.run_id,
            "final_state": result.final_state,
            "steps": result.steps,
            "stop_reason": result.stop_reason,
        },
    )

    return result


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _try_planner(
    mgr: Any,
    run_id: str,
    config: AutoPilotConfig,
    step: int,
) -> bool:
    """Try to call LLM planner. Returns True if successful."""
    _emit(config, "llm_planner_start", {"step": step})
    try:
        mgr.run_planner_llm(run_id)
        _emit(config, "llm_planner_done", {"step": step})
        logger.info("AutoPilot step %d: planner LLM done", step)
        return True
    except Exception as exc:
        _emit(config, "llm_planner_error", {"step": step, "error": str(exc)})
        logger.warning("AutoPilot step %d: planner error: %s", step, exc)
        return False


def _try_judge(
    mgr: Any,
    run_id: str,
    config: AutoPilotConfig,
    step: int,
) -> bool:
    """Try to call LLM judge. Returns True if successful."""
    _emit(config, "llm_judge_start", {"step": step})
    try:
        mgr.run_judge_llm(run_id)
        _emit(config, "llm_judge_done", {"step": step})
        logger.info("AutoPilot step %d: judge LLM done", step)
        return True
    except Exception as exc:
        _emit(config, "llm_judge_error", {"step": step, "error": str(exc)})
        logger.warning("AutoPilot step %d: judge error: %s", step, exc)
        return False


def _try_worker(
    mgr: Any,
    run_id: str,
    config: AutoPilotConfig,
    step: int,
) -> tuple[bool, bool]:
    """Try to run worker. Returns (success, blocked_on_approval)."""
    _emit(config, "worker_start", {"step": step})
    try:
        w_meta, w_msg = mgr.run_worker_cli(run_id)
        if w_meta.state == CycleState.WAIT_APPROVAL:
            if config.auto_approve:
                # Auto-approve and retry immediately
                from owlmind.approval import resolve_approval

                pending = w_meta.extra.get("pending_approval", {})
                token = pending.get("token", "")
                if token:
                    resolve_approval(mgr.meta_store, run_id, token, approved=True)
                    logger.info("AutoPilot step %d: auto-approved worker", step)
                    _emit(config, "worker_auto_approved", {"step": step})
                    # Retry after approval
                    w_meta2, w_msg2 = mgr.run_worker_cli(run_id)
                    if w_meta2.state == CycleState.WAIT_APPROVAL:
                        return False, True
                    _emit(config, "worker_done", {"step": step, "message": w_msg2})
                    return True, False
            _emit(config, "worker_approval_needed", {"step": step, "message": w_msg})
            logger.info("AutoPilot step %d: worker needs approval", step)
            return False, True
        _emit(config, "worker_done", {"step": step, "message": w_msg})
        logger.info("AutoPilot step %d: worker done", step)
        return True, False
    except Exception as exc:
        _emit(config, "worker_error", {"step": step, "error": str(exc)})
        logger.warning("AutoPilot step %d: worker error: %s", step, exc)
        return False, False
