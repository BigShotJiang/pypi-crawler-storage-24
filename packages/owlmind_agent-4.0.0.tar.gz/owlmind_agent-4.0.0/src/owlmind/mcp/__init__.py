"""OWLMIND MCP server -- Model Context Protocol integration."""
