"""OWLMIND MCP server -- JSON-RPC over stdio (no external MCP SDK needed)."""

from __future__ import annotations

import json
import logging
import sys
import time
from typing import Any, TextIO

logger = logging.getLogger(__name__)
audit_logger = logging.getLogger("owlmind.mcp.audit")

# Tool definitions
TOOLS: list[dict[str, Any]] = [
    {
        "name": "owlmind_doctor",
        "description": "Run OWLMIND health check (doctor) for the workspace.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "workspace": {
                    "type": "string",
                    "description": "Path to the workspace directory.",
                },
            },
            "required": ["workspace"],
        },
    },
    {
        "name": "owlmind_cost_estimate",
        "description": "Estimate cost for a goal execution.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "goal": {
                    "type": "string",
                    "description": "Goal description.",
                },
                "provider": {
                    "type": "string",
                    "description": "LLM provider (openai/anthropic/gemini).",
                    "default": "openai",
                },
                "iterations": {
                    "type": "integer",
                    "description": "Number of iterations.",
                    "default": 1,
                },
            },
            "required": ["goal"],
        },
    },
    {
        "name": "owlmind_memory_query",
        "description": "Search project memory for relevant snippets.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Search query text.",
                },
                "workspace": {
                    "type": "string",
                    "description": "Path to the workspace directory.",
                },
                "top_k": {
                    "type": "integer",
                    "description": "Number of results.",
                    "default": 5,
                },
            },
            "required": ["query", "workspace"],
        },
    },
    {
        "name": "owlmind_run",
        "description": "Start a OWLMIND goal execution cycle.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "goal": {
                    "type": "string",
                    "description": "Goal description.",
                },
                "workspace": {
                    "type": "string",
                    "description": "Path to the workspace directory.",
                },
            },
            "required": ["goal", "workspace"],
        },
    },
    {
        "name": "owlmind_status",
        "description": "Get status of a OWLMIND run.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "run_id": {
                    "type": "string",
                    "description": "Run ID to check.",
                },
                "workspace": {
                    "type": "string",
                    "description": "Path to the workspace directory.",
                },
            },
            "required": ["run_id", "workspace"],
        },
    },
    {
        "name": "owlmind_events",
        "description": "Get recent evidence events for a OWLMIND run.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "run_id": {
                    "type": "string",
                    "description": "Run ID.",
                },
                "workspace": {
                    "type": "string",
                    "description": "Workspace path.",
                },
                "limit": {
                    "type": "integer",
                    "description": "Max events to return.",
                    "default": 20,
                },
            },
            "required": ["run_id", "workspace"],
        },
    },
    {
        "name": "owlmind_queue_add",
        "description": "Add a task goal to the OWLMIND queue for background execution.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "goal": {
                    "type": "string",
                    "description": "Task goal description.",
                },
                "workspace": {
                    "type": "string",
                    "description": "Path to the workspace directory.",
                },
                "priority": {
                    "type": "integer",
                    "description": "Priority level (higher = processed first). Default 0.",
                    "default": 0,
                },
                "sandbox": {
                    "type": "boolean",
                    "description": "Run in sandbox mode (git worktree).",
                    "default": False,
                },
            },
            "required": ["goal", "workspace"],
        },
    },
    {
        "name": "owlmind_session_start",
        "description": "Queue multiple goals as a session (they will be executed in order).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "goals": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of goal descriptions to execute in sequence.",
                },
                "workspace": {
                    "type": "string",
                    "description": "Path to the workspace directory.",
                },
                "session_name": {
                    "type": "string",
                    "description": "Optional session name for tracking.",
                    "default": "",
                },
            },
            "required": ["goals", "workspace"],
        },
    },
    {
        "name": "owlmind_skill_run",
        "description": "Run a OWLMIND skill pack on a goal (e.g. code_review, security_audit, test_writer).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "pack_id": {
                    "type": "string",
                    "description": "Skill pack ID (e.g. 'code_review', 'security_audit', 'test_writer', 'refactor').",
                },
                "goal": {
                    "type": "string",
                    "description": "Goal to run the skill pack on.",
                },
                "workspace": {
                    "type": "string",
                    "description": "Path to the workspace directory.",
                },
            },
            "required": ["pack_id", "goal", "workspace"],
        },
    },
    {
        "name": "owlmind_vision_screenshot",
        "description": "Capture a screenshot of the current screen. Returns base64-encoded PNG.",
        "inputSchema": {
            "type": "object",
            "properties": {},
            "required": [],
        },
    },
    {
        "name": "owlmind_vision_analyze",
        "description": "Analyze an image file or screenshot with Claude vision. Returns description.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "image_path": {"type": "string", "description": "Path to image file to analyze"},
                "question": {"type": "string", "description": "Question to ask about the image", "default": "Describe what you see."},
            },
            "required": ["image_path"],
        },
    },
    {
        "name": "owlmind_vision_run",
        "description": "Run a Computer Use task — Claude will take screenshots and control the computer to complete the task.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "task": {"type": "string", "description": "Task to perform using computer control"},
                "max_steps": {"type": "integer", "description": "Maximum steps", "default": 15},
            },
            "required": ["task"],
        },
    },
    {
        "name": "owlmind_browser_search",
        "description": "Search the web using DuckDuckGo and return results.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query"},
                "max_results": {"type": "integer", "description": "Number of results", "default": 5},
            },
            "required": ["query"],
        },
    },
    {
        "name": "owlmind_browser_fetch",
        "description": "Fetch and extract text content from a URL.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "URL to fetch"},
                "selector": {"type": "string", "description": "CSS selector to extract (default: body)", "default": "body"},
            },
            "required": ["url"],
        },
    },
    {
        "name": "owlmind_ast_map",
        "description": "Generate a repository map showing all functions and classes in a codebase. Useful for understanding project structure.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Path to analyze (file or directory)"},
                "max_tokens": {"type": "integer", "description": "Maximum tokens for the map", "default": 4000},
            },
            "required": ["path"],
        },
    },
    {
        "name": "owlmind_ast_analyze",
        "description": "Analyze a source code file or directory and return functions, classes, and imports.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File or directory path to analyze"},
            },
            "required": ["path"],
        },
    },
    {
        "name": "owlmind_self_improve_analyze",
        "description": "Analyze recent runs to find failure patterns and generate improvement suggestions.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "runs_dir": {"type": "string", "description": "Path to runs directory"},
                "days": {"type": "integer", "description": "Number of days to analyze", "default": 30},
            },
            "required": ["runs_dir"],
        },
    },
    {
        "name": "owlmind_multi_repo_scan",
        "description": "Scan multiple repositories and detect cross-repo dependencies.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "repos": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of repository paths to scan.",
                },
            },
            "required": ["repos"],
        },
    },
    {
        "name": "owlmind_diff_review",
        "description": "Generate diff preview with risk classification for a run's changes.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "workspace": {"type": "string", "description": "Workspace path"},
                "run_id": {"type": "string", "description": "Run ID to review"},
            },
            "required": ["workspace", "run_id"],
        },
    },
    {
        "name": "owlmind_provider_health",
        "description": "Check health status of all configured LLM providers.",
        "inputSchema": {
            "type": "object",
            "properties": {},
            "required": [],
        },
    },
    {
        "name": "owlmind_marketplace_search",
        "description": "Search the skill pack marketplace for available packs.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query"},
                "tags": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Filter by tags",
                    "default": [],
                },
            },
            "required": ["query"],
        },
    },
]


def _get_version() -> str:
    try:
        from owlmind import __version__

        return __version__
    except ImportError:
        return "unknown"


def _handle_initialize(params: dict[str, Any]) -> dict[str, Any]:
    """Handle MCP initialize request."""
    return {
        "protocolVersion": "2024-11-05",
        "capabilities": {
            "tools": {},
        },
        "serverInfo": {
            "name": "owlmind",
            "version": _get_version(),
        },
    }


def _handle_tools_list(params: dict[str, Any]) -> dict[str, Any]:
    """Handle tools/list request."""
    return {"tools": TOOLS}


def _handle_tools_call(params: dict[str, Any]) -> dict[str, Any]:
    """Handle tools/call request — dispatch to appropriate handler."""
    name = params.get("name", "")
    arguments = params.get("arguments", {})

    handlers: dict[str, Any] = {
        "owlmind_doctor": _tool_doctor,
        "owlmind_cost_estimate": _tool_cost_estimate,
        "owlmind_memory_query": _tool_memory_query,
        "owlmind_run": _tool_run,
        "owlmind_status": _tool_status,
        "owlmind_events": _tool_events,
        "owlmind_queue_add": _tool_queue_add,
        "owlmind_session_start": _tool_session_start,
        "owlmind_skill_run": _tool_skill_run,
        "owlmind_vision_screenshot": _tool_vision_screenshot,
        "owlmind_vision_analyze": _tool_vision_analyze,
        "owlmind_vision_run": _tool_vision_run,
        "owlmind_browser_search": _tool_browser_search,
        "owlmind_browser_fetch": _tool_browser_fetch,
        "owlmind_ast_map": _tool_ast_map,
        "owlmind_ast_analyze": _tool_ast_analyze,
        "owlmind_self_improve_analyze": _tool_self_improve_analyze,
        "owlmind_multi_repo_scan": _tool_multi_repo_scan,
        "owlmind_diff_review": _tool_diff_review,
        "owlmind_provider_health": _tool_provider_health,
        "owlmind_marketplace_search": _tool_marketplace_search,
    }

    handler = handlers.get(name)
    if handler is None:
        audit_logger.info(
            "%s",
            json.dumps(
                {
                    "ts": time.time(),
                    "tool": name,
                    "args_keys": list(arguments.keys()),
                    "success": False,
                    "error": "unknown_tool",
                }
            ),
        )
        return {
            "content": [{"type": "text", "text": f"Unknown tool: {name}"}],
            "isError": True,
        }

    logger.info("MCP tool called: %s, args: %s", name, arguments)
    try:
        result = handler(arguments)
        logger.info("MCP tool completed: %s", name)
        audit_logger.info(
            "%s",
            json.dumps(
                {
                    "ts": time.time(),
                    "tool": name,
                    "args_keys": list(arguments.keys()),
                    "success": True,
                }
            ),
        )
        return {
            "content": [{"type": "text", "text": json.dumps(result, indent=2, default=str)}],
        }
    except Exception as exc:
        logger.error("MCP tool failed: %s, error: %s", name, exc)
        logger.exception("MCP tool %s traceback", name)
        audit_logger.info(
            "%s",
            json.dumps(
                {
                    "ts": time.time(),
                    "tool": name,
                    "args_keys": list(arguments.keys()),
                    "success": False,
                    "error": str(exc),
                }
            ),
        )
        return {
            "content": [{"type": "text", "text": f"Error: {exc}"}],
            "isError": True,
        }


def _tool_doctor(args: dict[str, Any]) -> dict[str, Any]:
    """Run owlmind doctor."""
    from owlmind.diag import build_diag_report

    workspace = args.get("workspace", ".")
    report = build_diag_report(workspace)
    return {"status": "ok", "report_path": str(report)}


def _tool_cost_estimate(args: dict[str, Any]) -> dict[str, Any]:
    """Estimate cost for a goal."""
    from owlmind.config import OwlMindConfig
    from owlmind.cost import estimate_goal

    cfg = OwlMindConfig.from_env()
    goal = args["goal"]
    provider = args.get("provider", "openai")
    iterations = args.get("iterations", 1)

    estimate = estimate_goal(
        goal=goal,
        provider=provider,
        pricing=cfg.pricing,
        budget=cfg.budget,
        iterations=iterations,
    )
    return estimate.to_dict()


def _tool_memory_query(args: dict[str, Any]) -> dict[str, Any]:
    """Search project memory."""
    from pathlib import Path

    from owlmind.memory.retrieval import query
    from owlmind.memory.store import MemoryStore

    workspace = args["workspace"]
    query_text = args["query"]
    top_k = args.get("top_k", 5)

    db_path = Path(workspace) / ".owlmind" / "memory.db"
    if not db_path.exists():
        return {"results": [], "message": "No memory database found."}

    store = MemoryStore(db_path)
    results = query(store, query_text, top_k=top_k)
    return {
        "results": [
            {"source": r.source, "score": round(r.score, 3), "snippet": r.snippet} for r in results
        ],
    }


def _tool_run(args: dict[str, Any]) -> dict[str, Any]:
    """Start a OWLMIND cycle run."""
    from pathlib import Path

    from owlmind.agent.cycle import CycleManager
    from owlmind.evidence import EvidenceStore
    from owlmind.policy import PolicyEngine

    goal = args.get("goal", "")
    workspace = args.get("workspace", ".")
    if not goal:
        return {"error": "goal is required", "status": "failed"}

    runs_dir = Path(workspace) / "runs"
    policies_dir = Path(workspace) / "policies"
    try:
        evidence = EvidenceStore(runs_dir)
        policy = PolicyEngine.from_directory(policies_dir)
        mgr = CycleManager(evidence=evidence, policy=policy, policies_dir=policies_dir)
        meta = mgr.start(goal=goal, workspace=workspace)
        return {
            "status": "started",
            "run_id": meta.run_id,
            "state": meta.state.value,
            "goal": goal,
        }
    except Exception as exc:
        return {"error": str(exc), "status": "failed"}


def _tool_events(args: dict[str, Any]) -> dict[str, Any]:
    """Get recent evidence events for a run."""
    from pathlib import Path

    from owlmind.evidence import EvidenceStore

    run_id = args["run_id"]
    workspace = args["workspace"]
    limit = args.get("limit", 20)
    try:
        runs_dir = Path(workspace) / "runs"
        store = EvidenceStore(runs_dir)
        events = store.read_events(run_id)
        # read_events returns [] for both empty runs and missing runs;
        # only raise "not found" when the run directory itself is absent.
        if not events and not (runs_dir / run_id).exists():
            return {"error": f"Run {run_id} not found", "run_id": run_id}
        recent = events[-limit:]
        return {
            "run_id": run_id,
            "total_events": len(events),
            "events": [{k: v for k, v in e.items() if not k.startswith("_")} for e in recent],
        }
    except Exception as exc:
        return {"error": str(exc), "run_id": run_id}


def _tool_status(args: dict[str, Any]) -> dict[str, Any]:
    """Get run status."""
    from pathlib import Path

    run_id = args["run_id"]
    workspace = args["workspace"]
    meta_path = Path(workspace) / "runs" / run_id / "meta.json"

    if not meta_path.exists():
        return {"error": f"Run {run_id} not found"}

    meta: dict[str, Any] = json.loads(meta_path.read_text())
    return {
        "run_id": run_id,
        "state": meta.get("state", "unknown"),
        "goal": meta.get("goal", ""),
        "iteration": meta.get("iteration", 0),
    }


def _tool_queue_add(args: dict[str, Any]) -> dict[str, Any]:
    """Add a task to the OWLMIND queue."""
    from pathlib import Path

    from owlmind.queue import TaskQueue

    goal = args.get("goal", "")
    workspace = args.get("workspace", ".")
    priority = int(args.get("priority", 0))
    sandbox = bool(args.get("sandbox", False))

    if not goal:
        return {"error": "goal is required", "status": "failed"}

    queue_dir = Path(workspace) / ".owlmind" / "queue"
    try:
        q = TaskQueue(queue_dir)
        item = q.add(goal=goal, workspace=workspace, sandbox=sandbox, priority=priority)
        return {
            "status": "queued",
            "task_id": item.id,
            "goal": goal,
            "priority": priority,
            "queue_dir": str(queue_dir),
        }
    except Exception as exc:
        return {"error": str(exc), "status": "failed"}


def _tool_session_start(args: dict[str, Any]) -> dict[str, Any]:
    """Queue multiple goals as a session."""
    import uuid
    from pathlib import Path

    from owlmind.queue import TaskQueue

    goals: list[str] = args.get("goals", [])
    workspace = args.get("workspace", ".")
    session_name = args.get("session_name", "")

    if not goals:
        return {"error": "goals list is required and must be non-empty", "status": "failed"}

    session_id = session_name or f"session-{uuid.uuid4().hex[:8]}"
    queue_dir = Path(workspace) / ".owlmind" / "queue"

    try:
        q = TaskQueue(queue_dir)
        task_ids: list[str] = []
        for i, goal in enumerate(goals):
            item = q.add(
                goal=goal,
                workspace=workspace,
                priority=len(goals) - i,  # first goal gets highest priority
                session_id=session_id,
                goal_id=f"goal-{i + 1:03d}",
            )
            task_ids.append(item.id)
        return {
            "status": "session_queued",
            "session_id": session_id,
            "task_count": len(task_ids),
            "task_ids": task_ids,
            "workspace": workspace,
        }
    except Exception as exc:
        return {"error": str(exc), "status": "failed"}


def _tool_skill_run(args: dict[str, Any]) -> dict[str, Any]:
    """Queue a skill pack run."""
    from pathlib import Path

    from owlmind.queue import TaskQueue

    pack_id = args.get("pack_id", "")
    goal = args.get("goal", "")
    workspace = args.get("workspace", ".")

    if not pack_id or not goal:
        return {"error": "pack_id and goal are required", "status": "failed"}

    # Verify pack exists
    try:
        from owlmind.skills.registry import load_pack

        pack_info = load_pack(pack_id)
        pack_description = pack_info.get("description", "")
    except FileNotFoundError:
        return {"error": f"Skill pack '{pack_id}' not found", "status": "failed"}
    except Exception:
        pack_description = ""

    # Queue as a skill-annotated task
    skill_goal = f"[skill:{pack_id}] {goal}"
    queue_dir = Path(workspace) / ".owlmind" / "queue"
    try:
        q = TaskQueue(queue_dir)
        item = q.add(goal=skill_goal, workspace=workspace, priority=1)
        return {
            "status": "queued",
            "task_id": item.id,
            "pack_id": pack_id,
            "pack_description": pack_description,
            "goal": skill_goal,
        }
    except Exception as exc:
        return {"error": str(exc), "status": "failed"}


def _tool_vision_screenshot(args: dict[str, Any]) -> dict[str, Any]:
    """Capture a screenshot of the current screen."""
    from owlmind.vision.screenshot import capture_screenshot, is_screenshot_available

    if not is_screenshot_available():
        return {"error": "Screenshot not available. Install: pip install 'owlmind[vision]'"}
    result = capture_screenshot()
    return {
        "width": result.width,
        "height": result.height,
        "timestamp": result.timestamp,
        "base64_image": result.base64_image[:100] + "...",  # truncate for display
        "media_type": result.media_type,
    }


def _tool_vision_analyze(args: dict[str, Any]) -> dict[str, Any]:
    """Analyze an image file with Claude vision."""
    import os

    from owlmind.vision.driver import ComputerUseDriver
    from owlmind.vision.models import VisionConfig
    from owlmind.vision.screenshot import encode_image_file

    image_path = args.get("image_path", "")
    question = args.get("question", "Describe what you see.")
    api_key = os.environ.get("ANTHROPIC_API_KEY", "")

    screenshot = encode_image_file(image_path)
    config = VisionConfig(api_key=api_key, enabled=bool(api_key))
    driver = ComputerUseDriver(config)
    answer = driver.analyze_image(screenshot, question)
    return {"answer": answer}


def _tool_vision_run(args: dict[str, Any]) -> dict[str, Any]:
    """Run a Computer Use task."""
    import os

    from owlmind.vision.driver import ComputerUseDriver
    from owlmind.vision.models import VisionConfig

    task = args.get("task", "")
    max_steps = int(args.get("max_steps", 15))
    api_key = os.environ.get("ANTHROPIC_API_KEY", "")

    config = VisionConfig(api_key=api_key, enabled=bool(api_key))
    driver = ComputerUseDriver(config)
    steps = driver.run_task(task, max_steps=max_steps)

    final = next((s for s in reversed(steps) if s.is_final), steps[-1] if steps else None)
    return {
        "total_steps": len(steps),
        "final_message": final.final_message if final else "",
        "actions": [s.action.action_type if s.action else "none" for s in steps],
    }


def _tool_browser_search(args: dict[str, Any]) -> dict[str, Any]:
    """Search the web using DuckDuckGo."""
    from owlmind.browser.driver import BrowserDriver, is_browser_available
    from owlmind.browser.models import BrowserConfig

    if not is_browser_available():
        return {"error": "Browser not available. Install: pip install 'owlmind[browser]' && playwright install chromium"}

    query = args.get("query", "")
    max_results = int(args.get("max_results", 5))

    with BrowserDriver(BrowserConfig(headless=True)) as browser:
        result = browser.search_web(query, num_results=max_results)

    return {
        "query": query,
        "results": result.results,
        "source": result.source,
    }


def _tool_browser_fetch(args: dict[str, Any]) -> dict[str, Any]:
    """Fetch and extract text content from a URL."""
    from owlmind.browser.driver import BrowserDriver, is_browser_available
    from owlmind.browser.models import BrowserConfig

    if not is_browser_available():
        return {"error": "Browser not available. Install: pip install 'owlmind[browser]' && playwright install chromium"}

    url = args.get("url", "")
    selector = args.get("selector", "body")

    with BrowserDriver(BrowserConfig(headless=True)) as browser:
        page = browser.navigate(url)
        if page.error:
            return {"error": f"Failed to load {url}: {page.error}"}
        text = browser.extract_text(selector)

    return {
        "url": url,
        "title": page.title,
        "content": text[:3000],
        "truncated": len(text) > 3000,
    }


def _tool_ast_map(args: dict[str, Any]) -> dict[str, Any]:
    """Generate a repository map."""
    from owlmind.ast_parser.analyzer import CodeAnalyzer

    path = args.get("path", ".")
    max_tokens = int(args.get("max_tokens", 4000))

    analyzer = CodeAnalyzer()
    repo_map = analyzer.generate_repo_map(path, max_tokens=max_tokens)

    return {"repo_map": repo_map}


def _tool_ast_analyze(args: dict[str, Any]) -> dict[str, Any]:
    """Analyze a source code file or directory."""
    import os

    from owlmind.ast_parser.analyzer import CodeAnalyzer

    path = args.get("path", ".")
    analyzer = CodeAnalyzer()

    if os.path.isfile(path):
        analysis = analyzer.analyze_file(path)
        return {
            "file": path,
            "language": analysis.language,
            "total_lines": analysis.total_lines,
            "functions": [{"name": f.name, "line": f.start_line, "async": f.is_async} for f in analysis.functions],
            "classes": [{"name": c.name, "line": c.start_line, "methods": len(c.methods)} for c in analysis.classes],
            "imports": len(analysis.imports),
            "error": analysis.error,
        }
    else:
        repo_map = analyzer.analyze_directory(path, max_files=200)
        return {
            "root": path,
            "total_files": repo_map.total_files,
            "total_lines": repo_map.total_lines,
            "languages": repo_map.languages,
            "summary": repo_map.summary,
        }


def _tool_self_improve_analyze(args: dict[str, Any]) -> dict[str, Any]:
    """Analyze runs for failure patterns and improvement suggestions."""
    from pathlib import Path

    from owlmind.self_improve.pattern_analyzer import PatternAnalyzer

    runs_dir = Path(args.get("runs_dir", "runs"))
    days = int(args.get("days", 30))

    analyzer = PatternAnalyzer(runs_dir)
    report = analyzer.generate_report(days=days)

    return {
        "overall_success_rate": report.overall_success_rate,
        "patterns_count": len(report.patterns),
        "patterns": [
            {
                "type": p.type,
                "frequency": p.frequency,
                "trend": p.trend,
            }
            for p in report.patterns
        ],
        "adjustments_count": len(report.adjustments),
        "adjustments": [
            {
                "target_stage": a.target_stage,
                "description": a.description,
                "confidence": a.confidence,
            }
            for a in report.adjustments
        ],
    }


def _tool_multi_repo_scan(args: dict[str, Any]) -> dict[str, Any]:
    """Scan repositories and detect dependencies."""
    from owlmind.multi_repo import MultiRepoRunner

    repos = args.get("repos", [])
    if not repos:
        return {"error": "repos list is required"}

    try:
        deps = MultiRepoRunner.detect_dependencies(repos)
        return {
            "repos_scanned": len(repos),
            "dependencies": deps,
        }
    except Exception as exc:
        return {"error": str(exc)}


def _tool_diff_review(args: dict[str, Any]) -> dict[str, Any]:
    """Generate diff preview for a run."""
    from owlmind.agent.diff_review import DiffReview

    workspace = args.get("workspace", ".")
    run_id = args.get("run_id", "")

    review = DiffReview()
    try:
        diffs = review.generate_diff(workspace, run_id)
        return {
            "run_id": run_id,
            "total_files": len(diffs),
            "files": [
                {
                    "path": d.path,
                    "risk_level": d.risk_level,
                    "diff_preview": d.diff_text[:500],
                }
                for d in diffs
            ],
        }
    except Exception as exc:
        return {"error": str(exc), "run_id": run_id}


def _tool_provider_health(args: dict[str, Any]) -> dict[str, Any]:
    """Check LLM provider health."""
    try:
        from owlmind.config import OwlMindConfig
        from owlmind.llm.factory import build_llm_router

        cfg = OwlMindConfig.from_env()
        router = build_llm_router(cfg)

        health = router.provider_health()
        return {
            "providers": {
                name: {
                    "state": h.state.value,
                    "total_calls": h.total_calls,
                    "total_failures": h.total_failures,
                    "consecutive_failures": h.consecutive_failures,
                }
                for name, h in health.items()
            },
        }
    except Exception as exc:
        return {"error": str(exc)}


def _tool_marketplace_search(args: dict[str, Any]) -> dict[str, Any]:
    """Search the skill pack marketplace."""
    from pathlib import Path

    query = args.get("query", "")
    tags = args.get("tags", [])

    try:
        from owlmind.marketplace.registry import PackageRegistry

        db_path = Path.home() / ".owlmind" / "marketplace.db"
        registry = PackageRegistry(db_path)
        results = registry.search(query, tags=tags)
        return {
            "query": query,
            "results_count": len(results),
            "results": [
                {
                    "id": r.id,
                    "name": r.name,
                    "version": r.version,
                    "description": r.description,
                    "rating": r.rating,
                }
                for r in results
            ],
        }
    except Exception as exc:
        return {"error": str(exc), "query": query}


class MCPServer:
    """Lightweight MCP server over JSON-RPC 2.0 stdio transport."""

    def __init__(
        self,
        *,
        input_stream: TextIO | None = None,
        output_stream: TextIO | None = None,
    ) -> None:
        self._input = input_stream or sys.stdin
        self._output = output_stream or sys.stdout
        self._handlers: dict[str, Any] = {
            "initialize": _handle_initialize,
            "notifications/initialized": lambda p: None,
            "tools/list": _handle_tools_list,
            "tools/call": _handle_tools_call,
        }

    def _send(self, response: dict[str, Any]) -> None:
        """Write a JSON-RPC response to stdout."""
        line = json.dumps(response, default=str)
        self._output.write(line + "\n")
        self._output.flush()

    def _handle_request(self, request: dict[str, Any]) -> dict[str, Any] | None:
        """Process a single JSON-RPC request."""
        method = request.get("method", "")
        params = request.get("params", {})
        req_id = request.get("id")

        handler = self._handlers.get(method)

        # Notifications (no id) — don't respond
        if req_id is None:
            if handler:
                handler(params)
            return None

        if handler is None:
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "error": {"code": -32601, "message": f"Method not found: {method}"},
            }

        try:
            result = handler(params)
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": result,
            }
        except Exception as exc:
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "error": {"code": -32603, "message": str(exc)},
            }

    def serve_forever(self) -> None:
        """Read JSON-RPC requests from stdin, process, respond on stdout."""
        logger.info("OWLMIND MCP server started")
        for line in self._input:
            line = line.strip()
            if not line:
                continue
            try:
                request: dict[str, Any] = json.loads(line)
            except json.JSONDecodeError:
                self._send(
                    {
                        "jsonrpc": "2.0",
                        "id": None,
                        "error": {"code": -32700, "message": "Parse error"},
                    }
                )
                continue

            response = self._handle_request(request)
            if response is not None:
                self._send(response)

    def handle_one(self, request: dict[str, Any]) -> dict[str, Any] | None:
        """Process a single request dict (for testing)."""
        return self._handle_request(request)
