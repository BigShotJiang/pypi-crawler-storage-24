"""Browser automation module for OwlMind."""

from __future__ import annotations

from owlmind.browser.agent import BrowserAgent
from owlmind.browser.driver import BrowserDriver, is_browser_available
from owlmind.browser.models import BrowserAction, BrowserConfig, PageResult, SearchResult

__all__ = [
    "BrowserDriver",
    "BrowserAgent",
    "BrowserConfig",
    "PageResult",
    "SearchResult",
    "BrowserAction",
    "is_browser_available",
]
