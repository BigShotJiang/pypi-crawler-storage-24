"""Browser automation data models."""

from __future__ import annotations

from pydantic import BaseModel, Field


class BrowserConfig(BaseModel):
    """Configuration for the Playwright browser driver."""

    headless: bool = True
    browser_type: str = "chromium"  # chromium, firefox, webkit
    timeout_ms: int = 8000
    viewport_width: int = 1280
    viewport_height: int = 800
    user_agent: str = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    proxy: str = ""
    slow_mo: int = 0  # ms between actions (for debugging)


class PageResult(BaseModel):
    """Result of navigating to a web page."""

    url: str
    title: str = ""
    content: str = ""  # extracted text
    html: str = ""
    screenshot_base64: str = ""
    status_code: int = 200
    error: str = ""
    links: list[str] = Field(default_factory=list)


class SearchResult(BaseModel):
    """Result of a web search query."""

    query: str
    results: list[dict] = Field(default_factory=list)  # [{title, url, snippet}]
    source: str = "duckduckgo"


class BrowserAction(BaseModel):
    """A single browser action to perform."""

    action: str  # navigate, click, type, scroll, screenshot, extract, search, wait, fill_form
    url: str = ""
    selector: str = ""
    text: str = ""
    value: str = ""
    wait_ms: int = 500
    form_data: dict[str, str] = Field(default_factory=dict)
