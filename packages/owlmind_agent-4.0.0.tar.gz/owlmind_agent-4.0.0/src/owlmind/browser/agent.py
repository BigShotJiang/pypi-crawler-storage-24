"""AI-powered browser agent using Claude + BrowserDriver."""

from __future__ import annotations

import logging
from typing import Any

from owlmind.browser.driver import BrowserDriver
from owlmind.browser.models import BrowserConfig

logger = logging.getLogger(__name__)

_ANTHROPIC_AVAILABLE = False
try:
    import anthropic

    _ANTHROPIC_AVAILABLE = True
except ImportError:
    pass


class BrowserAgent:
    """Uses Claude + BrowserDriver to complete web tasks autonomously."""

    def __init__(
        self,
        browser_config: BrowserConfig | None = None,
        api_key: str = "",
        model: str = "claude-sonnet-4-6",
    ) -> None:
        self._browser_config = browser_config or BrowserConfig()
        self._api_key = api_key
        self._model = model
        self._client: Any = None

        if _ANTHROPIC_AVAILABLE and api_key:
            self._client = anthropic.Anthropic(api_key=api_key)

    def search_and_summarize(self, query: str, max_results: int = 3) -> str:
        """Search for a query and return a text summary of top results."""
        with BrowserDriver(self._browser_config) as browser:
            search = browser.search_web(query, num_results=max_results)

        if not search.results:
            return f"No results found for: {query}"

        # Build summary from results
        parts = [f"Search results for: {query}\n"]
        for i, r in enumerate(search.results, 1):
            parts.append(f"{i}. {r.get('title', 'No title')}")
            parts.append(f"   URL: {r.get('url', '')}")
            if r.get("snippet"):
                parts.append(f"   {r['snippet']}")
            parts.append("")

        summary = "\n".join(parts)

        # If Claude available, summarize with LLM
        if self._client:
            try:
                response = self._client.messages.create(
                    model=self._model,
                    max_tokens=1024,
                    messages=[{
                        "role": "user",
                        "content": f"Summarize these search results about '{query}':\n\n{summary}",
                    }],
                )
                for block in response.content:
                    if getattr(block, "type", "") == "text":
                        return block.text
            except Exception as e:
                logger.warning("LLM summarization failed: %s", e)

        return summary

    def extract_page_data(self, url: str, schema: dict[str, str]) -> dict[str, str]:
        """Extract structured data from a web page according to a CSS selector schema.

        Schema maps field names to CSS selectors.
        Example: {"title": "h1", "price": ".price", "description": "#desc"}
        """
        with BrowserDriver(self._browser_config) as browser:
            result = browser.navigate(url)
            if result.error:
                return {"error": result.error}

            data: dict[str, str] = {"url": url, "title": result.title}
            for field, selector in schema.items():
                try:
                    text = browser.extract_text(selector)
                    data[field] = text.strip()
                except Exception as e:
                    data[field] = f"extraction failed: {e}"

        return data

    def run_task(
        self,
        task: str,
        start_url: str = "",
        max_steps: int = 10,
    ) -> dict[str, Any]:
        """Run a web browsing task autonomously using Claude + browser.

        Returns dict with: steps, final_answer, urls_visited
        """
        if not self._client:
            msg = "BrowserAgent requires anthropic API key for autonomous task execution"
            raise RuntimeError(msg)

        with BrowserDriver(self._browser_config) as browser:
            if start_url:
                browser.navigate(start_url)

            steps: list[dict[str, Any]] = []
            urls_visited: list[str] = []
            final_answer = ""

            # Tool definitions for Claude
            tools = [
                {
                    "name": "navigate",
                    "description": "Navigate to a URL",
                    "input_schema": {
                        "type": "object",
                        "properties": {"url": {"type": "string", "description": "URL to navigate to"}},
                        "required": ["url"],
                    },
                },
                {
                    "name": "search",
                    "description": "Search the web with DuckDuckGo",
                    "input_schema": {
                        "type": "object",
                        "properties": {"query": {"type": "string", "description": "Search query"}},
                        "required": ["query"],
                    },
                },
                {
                    "name": "extract_text",
                    "description": "Extract text from current page or specific element",
                    "input_schema": {
                        "type": "object",
                        "properties": {
                            "selector": {"type": "string", "description": "CSS selector (default: body)"},
                        },
                    },
                },
                {
                    "name": "click",
                    "description": "Click an element on the page",
                    "input_schema": {
                        "type": "object",
                        "properties": {
                            "selector": {"type": "string", "description": "CSS selector to click"},
                        },
                        "required": ["selector"],
                    },
                },
                {
                    "name": "fill_and_submit",
                    "description": "Fill a form field and optionally submit",
                    "input_schema": {
                        "type": "object",
                        "properties": {
                            "selector": {"type": "string"},
                            "value": {"type": "string"},
                            "submit": {"type": "boolean", "default": False},
                        },
                        "required": ["selector", "value"],
                    },
                },
            ]

            messages: list[dict[str, Any]] = [
                {
                    "role": "user",
                    "content": (
                        f"Task: {task}\n\n"
                        f"Current URL: {browser.get_current_url() or 'about:blank'}"
                    ),
                }
            ]

            for step_num in range(max_steps):
                response = self._client.messages.create(
                    model=self._model,
                    max_tokens=2048,
                    tools=tools,
                    messages=messages,
                )

                messages.append({"role": "assistant", "content": response.content})

                tool_results: list[dict[str, Any]] = []
                has_tool_use = False

                for block in response.content:
                    btype = getattr(block, "type", "")
                    if btype == "text" and response.stop_reason == "end_turn":
                        final_answer = block.text

                    elif btype == "tool_use":
                        has_tool_use = True
                        tool_name = block.name
                        tool_input = block.input or {}

                        tool_result = ""
                        try:
                            if tool_name == "navigate":
                                url = tool_input["url"]
                                nav = browser.navigate(url)
                                urls_visited.append(url)
                                tool_result = (
                                    f"Navigated to {url}. Title: {nav.title}. "
                                    f"Content preview: {nav.content[:500]}"
                                )

                            elif tool_name == "search":
                                query = tool_input["query"]
                                search = browser.search_web(query, num_results=5)
                                parts = []
                                for r in search.results:
                                    parts.append(
                                        f"- {r.get('title')}: {r.get('url')} "
                                        f"— {r.get('snippet', '')[:100]}"
                                    )
                                tool_result = f"Search results for '{query}':\n" + "\n".join(parts)

                            elif tool_name == "extract_text":
                                selector = tool_input.get("selector", "body")
                                text = browser.extract_text(selector)
                                tool_result = text[:2000] if len(text) > 2000 else text

                            elif tool_name == "click":
                                ok = browser.click(tool_input["selector"])
                                tool_result = "clicked" if ok else "click failed"

                            elif tool_name == "fill_and_submit":
                                ok = browser.fill(tool_input["selector"], tool_input["value"])
                                if ok and tool_input.get("submit"):
                                    browser.press_key("Enter")
                                    tool_result = "filled and submitted"
                                else:
                                    tool_result = "filled" if ok else "fill failed"

                        except Exception as e:
                            tool_result = f"tool error: {e}"

                        steps.append({
                            "step": step_num + 1,
                            "tool": tool_name,
                            "input": tool_input,
                            "result": tool_result[:200],
                        })
                        tool_results.append({
                            "type": "tool_result",
                            "tool_use_id": block.id,
                            "content": tool_result,
                        })

                if tool_results:
                    messages.append({"role": "user", "content": tool_results})

                if not has_tool_use:
                    break  # Claude is done with tools

            return {
                "task": task,
                "final_answer": final_answer,
                "steps": steps,
                "urls_visited": urls_visited,
                "total_steps": len(steps),
            }
