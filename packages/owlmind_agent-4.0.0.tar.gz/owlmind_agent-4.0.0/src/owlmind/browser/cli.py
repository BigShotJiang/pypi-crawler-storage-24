"""CLI commands for browser automation."""

from __future__ import annotations

import os
from typing import Annotated

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

browser_app = typer.Typer(
    name="browser",
    help="Browser automation — navigate, search, extract",
    no_args_is_help=True,
)
console = Console()


def _get_driver():
    from owlmind.browser.driver import BrowserDriver, is_browser_available
    from owlmind.browser.models import BrowserConfig

    if not is_browser_available():
        console.print(
            "[red]Browser requires playwright. "
            "Install: pip install 'owlmind[browser]' && playwright install chromium[/red]"
        )
        raise typer.Exit(1)

    headless = os.environ.get("OWLMIND_BROWSER_HEADLESS", "true").lower() != "false"
    return BrowserDriver(BrowserConfig(headless=headless))


@browser_app.command("navigate")
def cmd_navigate(
    url: Annotated[str, typer.Argument(help="URL to navigate to")],
    screenshot: Annotated[bool, typer.Option("--screenshot", "-s")] = False,
    output: Annotated[str, typer.Option("--output", "-o")] = "",
) -> None:
    """Navigate to URL and show page content."""
    console.print(f"Navigating to [cyan]{url}[/cyan]...")
    with _get_driver() as browser:
        result = browser.navigate(url)

    if result.error:
        console.print(f"[red]Error: {result.error}[/red]")
        raise typer.Exit(1)

    console.print(Panel(
        f"[bold]{result.title}[/bold]\n[dim]{result.url}[/dim]\n\n{result.content[:1000]}",
        title="Page Content",
    ))


@browser_app.command("search")
def cmd_search(
    query: Annotated[str, typer.Argument(help="Search query")],
    max_results: Annotated[int, typer.Option("--max", "-n")] = 5,
) -> None:
    """Search the web and show results."""
    console.print(f"Searching for: [cyan]{query}[/cyan]")
    with _get_driver() as browser:
        result = browser.search_web(query, num_results=max_results)

    if not result.results:
        console.print("[yellow]No results found[/yellow]")
        return

    table = Table(title=f"Search Results: {query}", show_lines=True)
    table.add_column("#", width=3)
    table.add_column("Title", style="bold")
    table.add_column("URL", style="dim cyan")
    table.add_column("Snippet")

    for i, r in enumerate(result.results, 1):
        table.add_row(
            str(i),
            r.get("title", "")[:60],
            r.get("url", "")[:50],
            r.get("snippet", "")[:100],
        )

    console.print(table)


@browser_app.command("extract")
def cmd_extract(
    url: Annotated[str, typer.Argument(help="URL to extract from")],
    selector: Annotated[str, typer.Option("--selector", "-s")] = "body",
    output: Annotated[str, typer.Option("--output", "-o")] = "",
) -> None:
    """Extract text content from a URL."""
    console.print(f"Extracting from [cyan]{url}[/cyan] selector=[dim]{selector}[/dim]")
    with _get_driver() as browser:
        browser.navigate(url)
        text = browser.extract_text(selector)

    if output:
        from pathlib import Path

        Path(output).write_text(text, encoding="utf-8")
        console.print(f"[green]Saved to {output}[/green] ({len(text)} chars)")
    else:
        console.print(text[:3000])


@browser_app.command("run")
def cmd_run(
    task: Annotated[str, typer.Argument(help="Browser task to perform with AI")],
    url: Annotated[str, typer.Option("--url", "-u")] = "",
    max_steps: Annotated[int, typer.Option("--max-steps", "-n")] = 10,
) -> None:
    """Run an AI-powered browser task."""
    from owlmind.browser.agent import BrowserAgent
    from owlmind.browser.models import BrowserConfig

    api_key = os.environ.get("ANTHROPIC_API_KEY", "")
    if not api_key:
        console.print("[red]ANTHROPIC_API_KEY required for AI browser tasks[/red]")
        raise typer.Exit(1)

    console.print(f"Running browser task: [cyan]{task}[/cyan]")
    agent = BrowserAgent(BrowserConfig(), api_key=api_key)
    result = agent.run_task(task, start_url=url, max_steps=max_steps)

    console.print(f"\n[bold green]Result:[/bold green] {result['final_answer']}")
    console.print(f"Completed in {result['total_steps']} step(s)")
    if result["urls_visited"]:
        console.print(f"URLs visited: {', '.join(result['urls_visited'])}")
