"""Playwright-based browser automation driver (sync API)."""

from __future__ import annotations

import base64
import logging
import re
import urllib.parse
from typing import Any

from owlmind.browser.models import BrowserConfig, PageResult, SearchResult

logger = logging.getLogger(__name__)

_PLAYWRIGHT_AVAILABLE = False
try:
    from playwright.sync_api import Browser, BrowserContext, Page, sync_playwright

    _PLAYWRIGHT_AVAILABLE = True
except ImportError:
    pass


def is_browser_available() -> bool:
    """Return True if playwright is installed and importable."""
    return _PLAYWRIGHT_AVAILABLE


class BrowserDriver:
    """Playwright-based browser automation driver.

    Usage as context manager::

        with BrowserDriver(config) as browser:
            result = browser.navigate("https://example.com")
            text = browser.extract_text()
    """

    def __init__(self, config: BrowserConfig | None = None) -> None:
        self._config = config or BrowserConfig()
        self._playwright = None
        self._browser: Browser | None = None
        self._context: BrowserContext | None = None
        self._page: Page | None = None

    def __enter__(self) -> BrowserDriver:
        self._start()
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def _start(self) -> None:
        if not _PLAYWRIGHT_AVAILABLE:
            msg = (
                "Browser automation requires playwright. "
                "Install with: pip install 'owlmind[browser]' && playwright install chromium"
            )
            raise ImportError(msg)

        self._playwright = sync_playwright().start()
        browser_launcher = getattr(self._playwright, self._config.browser_type)

        launch_kwargs: dict[str, Any] = {
            "headless": self._config.headless,
            "slow_mo": self._config.slow_mo,
        }
        if self._config.proxy:
            launch_kwargs["proxy"] = {"server": self._config.proxy}

        self._browser = browser_launcher.launch(**launch_kwargs)

        context_kwargs: dict[str, Any] = {
            "viewport": {
                "width": self._config.viewport_width,
                "height": self._config.viewport_height,
            },
        }
        if self._config.user_agent:
            context_kwargs["user_agent"] = self._config.user_agent

        context_kwargs["extra_http_headers"] = {
            "Accept-Language": "en-US,en;q=0.9",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        }
        self._context = self._browser.new_context(**context_kwargs)
        self._page = self._context.new_page()
        self._page.set_default_timeout(self._config.timeout_ms)

    def _ensure_started(self) -> None:
        if self._page is None:
            self._start()

    @property
    def page(self) -> Page:
        self._ensure_started()
        return self._page  # type: ignore[return-value]

    def navigate(self, url: str, wait_until: str = "domcontentloaded") -> PageResult:
        """Navigate to URL and return page result."""
        self._ensure_started()
        try:
            response = self._page.goto(url, wait_until=wait_until, timeout=self._config.timeout_ms)
            status = response.status if response else 200
            title = self._page.title()
            content = self._extract_text_content()
            links = self._extract_links_from_page(url)
            return PageResult(
                url=self._page.url,
                title=title,
                content=content,
                status_code=status,
                links=links,
            )
        except Exception as e:
            logger.warning("Navigation failed for %s: %s", url, e)
            return PageResult(url=url, title="", content="", status_code=0, error=str(e))

    def click(self, selector: str, timeout_ms: int | None = None) -> bool:
        """Click element by CSS/XPath selector. Returns True on success."""
        self._ensure_started()
        try:
            self._page.click(selector, timeout=timeout_ms or self._config.timeout_ms)
            return True
        except Exception as e:
            logger.warning("Click failed on '%s': %s", selector, e)
            return False

    def type_text(self, selector: str, text: str, clear_first: bool = True) -> bool:
        """Type text into element."""
        self._ensure_started()
        try:
            if clear_first:
                self._page.fill(selector, "")
            self._page.type(selector, text)
            return True
        except Exception as e:
            logger.warning("Type failed on '%s': %s", selector, e)
            return False

    def fill(self, selector: str, value: str) -> bool:
        """Fill input field with value (faster than type_text)."""
        self._ensure_started()
        try:
            self._page.fill(selector, value)
            return True
        except Exception as e:
            logger.warning("Fill failed on '%s': %s", selector, e)
            return False

    def press_key(self, key: str) -> None:
        """Press a keyboard key (e.g., 'Enter', 'Tab', 'Escape')."""
        self._ensure_started()
        self._page.keyboard.press(key)

    def scroll(self, direction: str = "down", amount: int = 3) -> None:
        """Scroll the page."""
        self._ensure_started()
        delta = 300 * amount
        if direction == "down":
            self._page.evaluate(f"window.scrollBy(0, {delta})")
        elif direction == "up":
            self._page.evaluate(f"window.scrollBy(0, -{delta})")
        elif direction == "right":
            self._page.evaluate(f"window.scrollBy({delta}, 0)")
        elif direction == "left":
            self._page.evaluate(f"window.scrollBy(-{delta}, 0)")

    def screenshot(self, full_page: bool = False) -> str:
        """Take screenshot, return base64 PNG."""
        self._ensure_started()
        try:
            img_bytes = self._page.screenshot(full_page=full_page)
            return base64.standard_b64encode(img_bytes).decode()
        except Exception as e:
            logger.warning("Screenshot failed: %s", e)
            return ""

    def extract_text(self, selector: str = "body") -> str:
        """Extract visible text from element."""
        self._ensure_started()
        try:
            return self._page.locator(selector).inner_text(timeout=5000)
        except Exception:
            return self._extract_text_content()

    def extract_html(self, selector: str = "html") -> str:
        """Extract HTML from element."""
        self._ensure_started()
        try:
            return self._page.locator(selector).inner_html(timeout=5000)
        except Exception as e:
            logger.warning("HTML extraction failed: %s", e)
            return ""

    def extract_links(self, base_url: str = "") -> list[str]:
        """Extract all links from current page."""
        self._ensure_started()
        return self._extract_links_from_page(base_url or self._page.url)

    def wait_for_selector(self, selector: str, timeout_ms: int = 5000) -> bool:
        """Wait for selector to appear. Returns True if found."""
        self._ensure_started()
        try:
            self._page.wait_for_selector(selector, timeout=timeout_ms)
            return True
        except Exception:
            return False

    def wait(self, ms: int = 1000) -> None:
        """Wait for specified milliseconds."""
        self._ensure_started()
        self._page.wait_for_timeout(ms)

    def execute_javascript(self, script: str) -> Any:
        """Execute JavaScript and return result."""
        self._ensure_started()
        return self._page.evaluate(script)

    def fill_form(self, form_data: dict[str, str]) -> bool:
        """Fill form fields. Keys are CSS selectors, values are text."""
        self._ensure_started()
        success = True
        for selector, value in form_data.items():
            if not self.fill(selector, value):
                success = False
        return success

    def get_current_url(self) -> str:
        """Get current page URL."""
        self._ensure_started()
        return self._page.url

    def get_page_title(self) -> str:
        """Get current page title."""
        self._ensure_started()
        return self._page.title()

    def search_web(self, query: str, num_results: int = 5) -> SearchResult:
        """Search DuckDuckGo via direct HTTP (bypasses headless-browser blocks)."""
        results = self._search_via_httpx(query, num_results)
        if results:
            return SearchResult(query=query, results=results, source="duckduckgo")

        # Fallback: try with browser
        encoded = urllib.parse.quote_plus(query)
        url = f"https://html.duckduckgo.com/html/?q={encoded}"
        result = self.navigate(url)
        if result.error:
            return SearchResult(query=query, results=[], source="duckduckgo")
        results = self._parse_duckduckgo_results(num_results)
        return SearchResult(query=query, results=results, source="duckduckgo")

    def _search_via_httpx(self, query: str, num_results: int) -> list[dict[str, str]]:
        """Fetch DuckDuckGo HTML results directly via httpx (no headless browser)."""
        try:
            import httpx
        except ImportError:
            return []

        headers = {
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
        }
        encoded = urllib.parse.quote_plus(query)
        url = f"https://html.duckduckgo.com/html/?q={encoded}"
        try:
            resp = httpx.get(url, headers=headers, follow_redirects=True, timeout=15)
            if resp.status_code != 200:
                logger.warning("DDG HTTP %s", resp.status_code)
                return []
            return self._parse_ddg_html(resp.text, num_results)
        except Exception as e:
            logger.warning("DDG httpx fetch failed: %s", e)
            return []

    def _parse_ddg_html(self, html: str, num_results: int) -> list[dict[str, str]]:
        """Parse DuckDuckGo HTML search results with regex (no BS4 needed)."""
        results = []
        # Extract all result__a links with titles
        link_pattern = re.compile(
            r'class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>',
            re.DOTALL,
        )
        snippet_pattern = re.compile(
            r'class="result__snippet"[^>]*>(.*?)</(?:a|span|div)>',
            re.DOTALL,
        )
        # Split by the result container div
        blocks = re.split(r'class="result results_links[^"]*"', html)
        for block in blocks[1:num_results * 2 + 1]:
            title_m = link_pattern.search(block)
            if not title_m:
                continue
            raw_href = title_m.group(1)
            # Decode DDG redirect URL: extract uddg= param
            uddg_m = re.search(r"uddg=([^&]+)", raw_href)
            if uddg_m:
                url = urllib.parse.unquote(uddg_m.group(1))
            else:
                url = urllib.parse.unquote(raw_href)
            title = re.sub(r"<[^>]+>", "", title_m.group(2)).strip()
            snippet_m = snippet_pattern.search(block)
            snippet = re.sub(r"<[^>]+>", "", snippet_m.group(1)).strip() if snippet_m else ""
            if url.startswith("http") and title:
                results.append({"title": title, "url": url, "snippet": snippet})
                if len(results) >= num_results:
                    break
        return results

    def get_page_summary(self, url: str) -> str:
        """Navigate to URL and return main text content."""
        result = self.navigate(url)
        if result.error:
            return f"Error loading {url}: {result.error}"
        # Truncate to reasonable size
        return result.content[:4000] if len(result.content) > 4000 else result.content

    def close(self) -> None:
        """Close browser and cleanup."""
        try:
            if self._page:
                self._page.close()
                self._page = None
            if self._context:
                self._context.close()
                self._context = None
            if self._browser:
                self._browser.close()
                self._browser = None
            if self._playwright:
                self._playwright.stop()
                self._playwright = None
        except Exception as e:
            logger.warning("Browser close error: %s", e)

    def _extract_text_content(self) -> str:
        """Extract visible text from current page, removing scripts/styles."""
        try:
            return self._page.evaluate("""() => {
                const scripts = document.querySelectorAll('script, style, noscript');
                scripts.forEach(el => el.remove());
                return document.body ? document.body.innerText : document.documentElement.innerText;
            }""")
        except Exception as e:
            logger.warning("Text extraction failed: %s", e)
            return ""

    def _extract_links_from_page(self, base_url: str = "") -> list[str]:
        """Extract all href links from current page."""
        try:
            links = self._page.evaluate("""() => {
                return Array.from(document.querySelectorAll('a[href]'))
                    .map(a => a.href)
                    .filter(href => href.startsWith('http'));
            }""")
            return list(set(links))[:50]  # dedup, limit to 50
        except Exception:
            return []

    def _parse_duckduckgo_results(self, num_results: int) -> list[dict[str, str]]:
        """Parse DuckDuckGo HTML results."""
        results = []
        try:
            # DDG HTML version uses .result elements with .result__a links
            result_elements = self._page.locator(".result").all()
            for el in result_elements[:num_results * 2]:  # fetch more, filter bad ones
                try:
                    link_el = el.locator("a.result__a").first
                    if link_el.count() == 0:
                        link_el = el.locator(".result__title a").first
                    if link_el.count() == 0:
                        continue

                    title = link_el.inner_text(timeout=2000).strip()
                    url = link_el.get_attribute("href", timeout=2000) or ""

                    snippet_el = el.locator(".result__snippet").first
                    snippet = snippet_el.inner_text(timeout=2000).strip() if snippet_el.count() > 0 else ""

                    if title and url and url.startswith("http"):
                        results.append({"title": title, "url": url, "snippet": snippet})
                        if len(results) >= num_results:
                            break
                except Exception:
                    continue
        except Exception as e:
            logger.warning("DuckDuckGo parse failed: %s", e)
        return results
