"""Web dashboard — generate static HTML status page for OWLMIND."""

from __future__ import annotations

import json
import logging
import os
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, cast

logger = logging.getLogger(__name__)


def _read_json(path: Path) -> Any:
    """Read JSON file safely."""
    try:
        return json.loads(path.read_text())
    except Exception:
        return None


def _scan_runs(runs_dir: Path, limit: int = 20) -> list[dict[str, Any]]:
    """Scan runs directory and return recent run metadata."""
    runs: list[dict[str, Any]] = []
    if not runs_dir.exists():
        return runs
    for run_dir in sorted(runs_dir.iterdir(), reverse=True)[:limit]:
        if not run_dir.is_dir():
            continue
        meta_file = run_dir / "cycle_meta.json"
        meta = _read_json(meta_file)
        if not meta:
            continue
        runs.append(
            {
                "run_id": run_dir.name,
                "goal": meta.get("goal", "")[:80],
                "state": meta.get("state", "?"),
                "workspace": meta.get("workspace", "?"),
                "created_at": meta.get("created_at", "?"),
            }
        )
    return runs


def _scan_queue(queue_dir: Path) -> list[dict[str, Any]]:
    """Read task queue items."""
    items: list[dict[str, Any]] = []
    queue_file = queue_dir / "queue.jsonl"
    if not queue_file.exists():
        return items
    try:
        for line in queue_file.read_text().splitlines():
            line = line.strip()
            if not line:
                continue
            item = json.loads(line)
            items.append(item)
    except Exception as exc:
        logger.debug("Failed to read queue file: %s", exc)
    return items


def _read_schedules(base_dir: Path) -> list[dict[str, Any]]:
    """Read schedules.json."""
    f = base_dir / "schedules.json"
    if not f.exists():
        return []
    try:
        return cast(list[dict[str, Any]], json.loads(f.read_text()))
    except Exception:
        return []


def _state_color(state: str) -> str:
    colors = {
        "DONE": "#22c55e",
        "FAILED": "#ef4444",
        "RUNNING": "#3b82f6",
        "PENDING": "#f59e0b",
        "BLOCKED": "#f97316",
    }
    return colors.get(state.upper(), "#94a3b8")


def generate_html(
    runs_dir: Path,
    queue_dir: Path,
    base_dir: Path,
    title: str = "OWLMIND Dashboard",
) -> str:
    """Generate dashboard HTML."""
    runs = _scan_runs(runs_dir)
    queue_items = _scan_queue(queue_dir)
    schedules = _read_schedules(base_dir)
    now = datetime.now(UTC).strftime("%Y-%m-%d %H:%M UTC")

    # Queue stats
    pending = [i for i in queue_items if i.get("status") == "PENDING"]
    running = [i for i in queue_items if i.get("status") == "RUNNING"]
    done = [i for i in queue_items if i.get("status") == "DONE"]
    failed = [i for i in queue_items if i.get("status") == "FAILED"]

    def run_row(r: dict[str, Any]) -> str:
        color = _state_color(r["state"])
        return (
            f"<tr>"
            f'<td style="font-family:monospace;font-size:11px;color:#94a3b8">{r["run_id"][:20]}</td>'
            f"<td>{r['goal']}</td>"
            f'<td><span style="background:{color};color:white;padding:2px 8px;border-radius:4px;font-size:12px">{r["state"]}</span></td>'
            f'<td style="font-size:12px;color:#64748b">{r["created_at"][:16] if len(str(r["created_at"])) > 10 else r["created_at"]}</td>'
            f"</tr>"
        )

    def queue_row(i: dict[str, Any]) -> str:
        color = _state_color(i.get("status", "?"))
        return (
            f"<tr>"
            f'<td style="font-family:monospace;font-size:11px;color:#94a3b8">{i.get("id", "")[:16]}</td>'
            f"<td>{i.get('goal', '')[:80]}</td>"
            f'<td><span style="background:{color};color:white;padding:2px 8px;border-radius:4px;font-size:12px">{i.get("status", "?")}</span></td>'
            f"</tr>"
        )

    def sched_row(s: dict[str, Any]) -> str:
        day = f" {s.get('day', '')}" if s.get("type") == "weekly" else ""
        return (
            f"<tr>"
            f'<td style="font-family:monospace;font-size:11px;color:#94a3b8">{s.get("id", "")[:16]}</td>'
            f"<td>{s.get('type', 'daily')}{day} {s.get('time', '?')} UTC</td>"
            f"<td>{s.get('goal', '')[:60]}</td>"
            f"</tr>"
        )

    runs_html = (
        "".join(run_row(r) for r in runs)
        or '<tr><td colspan="4" style="text-align:center;color:#64748b">Нет запусков</td></tr>'
    )
    queue_html = (
        "".join(queue_row(i) for i in queue_items[-20:])
        or '<tr><td colspan="3" style="text-align:center;color:#64748b">Очередь пуста</td></tr>'
    )
    sched_html = (
        "".join(sched_row(s) for s in schedules)
        or '<tr><td colspan="3" style="text-align:center;color:#64748b">Нет расписаний</td></tr>'
    )

    return f"""<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="30">
<title>{title}</title>
<style>
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: #0f172a; color: #e2e8f0; padding: 24px; }}
  h1 {{ font-size: 24px; font-weight: 700; margin-bottom: 4px; color: #f8fafc; }}
  .subtitle {{ color: #64748b; font-size: 13px; margin-bottom: 24px; }}
  .grid {{ display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 24px; }}
  .card {{ background: #1e293b; border-radius: 12px; padding: 16px; }}
  .card-num {{ font-size: 32px; font-weight: 700; }}
  .card-label {{ font-size: 12px; color: #94a3b8; margin-top: 4px; }}
  .section {{ background: #1e293b; border-radius: 12px; padding: 20px; margin-bottom: 16px; }}
  .section-title {{ font-size: 16px; font-weight: 600; margin-bottom: 16px; color: #f8fafc; }}
  table {{ width: 100%; border-collapse: collapse; }}
  th {{ text-align: left; padding: 8px 12px; font-size: 12px; color: #64748b; border-bottom: 1px solid #334155; }}
  td {{ padding: 10px 12px; font-size: 14px; border-bottom: 1px solid #1e293b; }}
  tr:hover td {{ background: #0f172a; }}
  .refresh {{ font-size: 11px; color: #475569; }}
</style>
</head>
<body>
<h1>OWLMIND Dashboard</h1>
<div class="subtitle">Обновлено: {now} · Авто-обновление каждые 30 сек</div>

<div class="grid">
  <div class="card"><div class="card-num" style="color:#f59e0b">{len(pending)}</div><div class="card-label">В очереди</div></div>
  <div class="card"><div class="card-num" style="color:#3b82f6">{len(running)}</div><div class="card-label">Выполняются</div></div>
  <div class="card"><div class="card-num" style="color:#22c55e">{len(done)}</div><div class="card-label">Выполнено</div></div>
  <div class="card"><div class="card-num" style="color:#ef4444">{len(failed)}</div><div class="card-label">Ошибки</div></div>
</div>

<div class="section">
  <div class="section-title">Последние запуски ({len(runs)})</div>
  <table>
    <tr><th>Run ID</th><th>Задача</th><th>Статус</th><th>Время</th></tr>
    {runs_html}
  </table>
</div>

<div class="section">
  <div class="section-title">Очередь задач ({len(queue_items)})</div>
  <table>
    <tr><th>ID</th><th>Задача</th><th>Статус</th></tr>
    {queue_html}
  </table>
</div>

<div class="section">
  <div class="section-title">Расписание ({len(schedules)})</div>
  <table>
    <tr><th>ID</th><th>Время</th><th>Задача</th></tr>
    {sched_html}
  </table>
</div>
</body>
</html>"""


def update_dashboard(runs_dir: Path, queue_dir: Path, base_dir: Path) -> Path:
    """Generate and write dashboard HTML to ~/owlmind_dashboard.html."""
    html = generate_html(runs_dir, queue_dir, base_dir)
    output = Path(os.path.expanduser("~")) / "owlmind_dashboard.html"
    output.write_text(html, encoding="utf-8")
    return output
