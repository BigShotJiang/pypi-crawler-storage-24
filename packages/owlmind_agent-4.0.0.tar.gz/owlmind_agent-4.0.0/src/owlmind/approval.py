"""Approval token mechanism for high-risk actions."""

from __future__ import annotations

import secrets
import time
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from owlmind.agent.meta_store import CycleMetaStore


@dataclass
class ApprovalToken:
    """Short-lived approval token stored in run metadata."""

    token: str
    run_id: str
    reason: str
    created_at: float
    expires_at: float
    resolved: bool = False
    approved: bool | None = None

    def is_expired(self) -> bool:
        return time.time() > self.expires_at

    def to_dict(self) -> dict[str, Any]:
        return {
            "token": self.token,
            "run_id": self.run_id,
            "reason": self.reason,
            "created_at": self.created_at,
            "expires_at": self.expires_at,
            "resolved": self.resolved,
            "approved": self.approved,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ApprovalToken:
        return cls(
            token=str(data["token"]),
            run_id=str(data["run_id"]),
            reason=str(data.get("reason", "")),
            created_at=float(data["created_at"]),
            expires_at=float(data["expires_at"]),
            resolved=bool(data.get("resolved", False)),
            approved=data.get("approved"),
        )


def create_approval(
    store: CycleMetaStore,
    run_id: str,
    reason: str,
    *,
    ttl_minutes: int = 60,
) -> ApprovalToken:
    """Create an approval token and set run to WAIT_APPROVAL.

    Saves the token in meta.extra["pending_approval"] and logs an event.
    """
    from owlmind.agent.schemas import CycleState

    token = secrets.token_urlsafe(8)
    now = time.time()

    approval = ApprovalToken(
        token=token,
        run_id=run_id,
        reason=reason,
        created_at=now,
        expires_at=now + ttl_minutes * 60,
    )

    meta = store.load(run_id)
    previous_state = meta.state.value
    meta.state = CycleState.WAIT_APPROVAL
    meta.extra["pending_approval"] = approval.to_dict()
    meta.extra["pre_approval_state"] = previous_state
    store.save(meta)

    store.evidence.append_event(
        run_id,
        {
            "event": "APPROVAL_CREATED",
            "token": token,
            "reason": reason,
            "expires_at": approval.expires_at,
            "run_id": run_id,
        },
    )

    return approval


def resolve_approval(
    store: CycleMetaStore,
    run_id: str,
    token: str,
    *,
    approved: bool,
) -> tuple[bool, str]:
    """Resolve a pending approval. Returns ``(success, message)``."""
    from owlmind.agent.schemas import CycleState

    meta = store.load(run_id)

    pending = meta.extra.get("pending_approval")
    if not pending:
        return False, "No pending approval for this run."

    approval = ApprovalToken.from_dict(pending)

    if approval.resolved:
        return False, "Approval already resolved."

    if approval.token != token:
        return False, "Invalid approval token."

    if approval.is_expired():
        approval.resolved = True
        approval.approved = False
        meta.extra["pending_approval"] = approval.to_dict()
        meta.state = CycleState.FAILED
        meta.hard_fail_reasons.append("Approval expired")
        store.save(meta)
        store.evidence.append_event(
            run_id,
            {
                "event": "APPROVAL_EXPIRED",
                "token": token,
                "run_id": run_id,
            },
        )
        return False, "Approval token expired."

    approval.resolved = True
    approval.approved = approved
    meta.extra["pending_approval"] = approval.to_dict()

    event_name = "APPROVAL_GRANTED" if approved else "APPROVAL_DENIED"

    if approved:
        # Restore previous state
        prev_state = meta.extra.get("pre_approval_state", CycleState.STARTED_WAIT_PLANNER.value)
        meta.state = CycleState(prev_state)
    else:
        meta.state = CycleState.FAILED
        meta.hard_fail_reasons.append(f"Approval denied: {approval.reason}")

    store.save(meta)
    store.evidence.append_event(
        run_id,
        {
            "event": event_name,
            "token": token,
            "approved": approved,
            "run_id": run_id,
        },
    )

    action = "approved" if approved else "denied"
    return True, f"Approval {action} for run {run_id}."


def get_pending_approval(
    store: CycleMetaStore,
    run_id: str,
) -> ApprovalToken | None:
    """Get the pending approval for a run, or None."""
    meta = store.load(run_id)
    pending = meta.extra.get("pending_approval")
    if not pending:
        return None
    return ApprovalToken.from_dict(pending)
