"""Telegram channel — notifications, commands, and approval handling.

Uses python-telegram-bot (optional dependency).
If not installed, all operations gracefully degrade.
"""

from __future__ import annotations

import logging
import time
from typing import Any

from owlmind.config import TelegramConfig

logger = logging.getLogger(__name__)

# Attempt import of python-telegram-bot
_PTB_AVAILABLE = False
try:
    from telegram import Bot, Update
    from telegram.ext import (
        Application,
        CommandHandler,
        ContextTypes,
    )

    _PTB_AVAILABLE = True
except ImportError:
    pass


def is_telegram_available() -> bool:
    """Check if python-telegram-bot is installed."""
    return _PTB_AVAILABLE


class TelegramChannel:
    """Telegram notification channel with rate limiting and chat whitelist."""

    def __init__(self, config: TelegramConfig) -> None:
        self.config = config
        self._last_send: dict[int, float] = {}
        self._bot: Any = None

        if config.enabled and _PTB_AVAILABLE:
            self._bot = Bot(token=config.bot_token)

    @property
    def enabled(self) -> bool:
        return self.config.enabled and _PTB_AVAILABLE and self._bot is not None

    def is_chat_allowed(self, chat_id: int) -> bool:
        """Check if chat_id is in the whitelist (empty list = all allowed)."""
        if not self.config.allowed_chat_ids:
            return True
        return chat_id in self.config.allowed_chat_ids

    def _rate_limited(self, chat_id: int) -> bool:
        """Check if we should rate-limit a message to this chat."""
        now = time.monotonic()
        last = self._last_send.get(chat_id)
        if last is not None and now - last < self.config.rate_limit_seconds:
            return True
        self._last_send[chat_id] = now
        return False

    async def send_message(self, chat_id: int, text: str) -> bool:
        """Send a text message to a chat. Returns True on success."""
        if not self.enabled:
            logger.debug("Telegram not enabled, skipping message")
            return False

        if not self.is_chat_allowed(chat_id):
            logger.warning("Chat %d not in allowed list", chat_id)
            return False

        if self._rate_limited(chat_id):
            logger.debug("Rate limited for chat %d", chat_id)
            return False

        try:
            await self._bot.send_message(chat_id=chat_id, text=text)
            return True
        except Exception:
            logger.exception("Failed to send Telegram message to %d", chat_id)
            return False

    async def send_notification(self, text: str) -> bool:
        """Send a notification to the default chat."""
        if not self.config.default_chat_id:
            logger.debug("No default chat_id configured")
            return False
        return await self.send_message(self.config.default_chat_id, text)

    def make_event_subscriber(self) -> Any:
        """Return an EventBus subscriber that sends notifications.

        Returns a synchronous callback suitable for EventBus.subscribe().
        Notifications are fire-and-forget (logged on error).
        """
        import asyncio

        def _subscriber(event_name: str, data: dict[str, Any]) -> None:
            if not self.enabled or not self.config.default_chat_id:
                return

            # Format message based on event
            notifiable_events = {
                "cycle_start",
                "planner_submitted",
                "worker_submitted",
                "judge_approved",
                "judge_needs_fix",
                "judge_rejected",
                "hard_fail",
                "budget_exceeded",
                "EXPORT_CREATED",
                "APPROVAL_CREATED",
                "APPROVAL_GRANTED",
                "APPROVAL_DENIED",
            }

            if event_name not in notifiable_events:
                return

            run_id = data.get("run_id", "?")
            msg = f"[OWLMIND] {event_name}\nRun: {run_id}"

            if event_name == "cycle_start":
                msg += f"\nGoal: {data.get('goal', '?')}"
            elif event_name == "hard_fail":
                msg += f"\nReasons: {data.get('reasons', [])}"
            elif event_name == "APPROVAL_CREATED":
                msg += f"\nToken: {data.get('token', '?')}"
                msg += f"\nUse: /approve {run_id} {data.get('token', '?')}"

            try:
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    loop.create_task(self.send_notification(msg))
                else:
                    loop.run_until_complete(self.send_notification(msg))
            except RuntimeError:
                # No event loop available; skip notification
                logger.debug("No event loop for Telegram notification")

        return _subscriber


def create_polling_app(
    config: TelegramConfig,
    *,
    cycle_manager: Any = None,
) -> Any:
    """Create a Telegram polling Application with command handlers.

    Returns None if Telegram is not available.
    """
    if not _PTB_AVAILABLE or not config.enabled:
        return None

    app = Application.builder().token(config.bot_token).build()

    # Command handlers
    async def cmd_status(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if update.message is None:
            return
        chat_id = update.message.chat_id
        if config.allowed_chat_ids and chat_id not in config.allowed_chat_ids:
            await update.message.reply_text("Unauthorized.")
            return

        args = context.args or []
        if not args:
            await update.message.reply_text("Usage: /status <run_id>")
            return

        if cycle_manager is None:
            await update.message.reply_text("Cycle manager not configured.")
            return

        run_id = args[0]
        try:
            meta = cycle_manager.status(run_id)
            text = (
                f"Run: {meta.run_id}\n"
                f"State: {meta.state.value}\n"
                f"Iteration: {meta.iteration}/{meta.limits.max_iterations}\n"
                f"Goal: {meta.goal}"
            )
            await update.message.reply_text(text)
        except Exception as exc:
            await update.message.reply_text(f"Error: {exc}")

    async def cmd_approve(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if update.message is None:
            return
        chat_id = update.message.chat_id
        if config.allowed_chat_ids and chat_id not in config.allowed_chat_ids:
            await update.message.reply_text("Unauthorized.")
            return

        args = context.args or []
        if len(args) < 2:
            await update.message.reply_text("Usage: /approve <run_id> <token>")
            return

        if cycle_manager is None:
            await update.message.reply_text("Cycle manager not configured.")
            return

        run_id, token = args[0], args[1]
        try:
            from owlmind.approval import resolve_approval

            ok, msg = resolve_approval(cycle_manager.meta_store, run_id, token, approved=True)
            await update.message.reply_text(msg if ok else f"Failed: {msg}")
        except Exception as exc:
            await update.message.reply_text(f"Error: {exc}")

    async def cmd_deny(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if update.message is None:
            return
        chat_id = update.message.chat_id
        if config.allowed_chat_ids and chat_id not in config.allowed_chat_ids:
            await update.message.reply_text("Unauthorized.")
            return

        args = context.args or []
        if len(args) < 2:
            await update.message.reply_text("Usage: /deny <run_id> <token>")
            return

        if cycle_manager is None:
            await update.message.reply_text("Cycle manager not configured.")
            return

        run_id, token = args[0], args[1]
        try:
            from owlmind.approval import resolve_approval

            ok, msg = resolve_approval(cycle_manager.meta_store, run_id, token, approved=False)
            await update.message.reply_text(msg if ok else f"Failed: {msg}")
        except Exception as exc:
            await update.message.reply_text(f"Error: {exc}")

    async def cmd_next(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if update.message is None:
            return
        chat_id = update.message.chat_id
        if config.allowed_chat_ids and chat_id not in config.allowed_chat_ids:
            await update.message.reply_text("Unauthorized.")
            return

        args = context.args or []
        if not args:
            await update.message.reply_text("Usage: /next <run_id>")
            return

        if cycle_manager is None:
            await update.message.reply_text("Cycle manager not configured.")
            return

        run_id = args[0]
        try:
            meta, msg = cycle_manager.next(run_id)
            await update.message.reply_text(f"State: {meta.state.value}\n{msg}")
        except Exception as exc:
            await update.message.reply_text(f"Error: {exc}")

    async def cmd_export(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if update.message is None:
            return
        chat_id = update.message.chat_id
        if config.allowed_chat_ids and chat_id not in config.allowed_chat_ids:
            await update.message.reply_text("Unauthorized.")
            return

        args = context.args or []
        if not args:
            await update.message.reply_text("Usage: /export <run_id>")
            return

        if cycle_manager is None:
            await update.message.reply_text("Cycle manager not configured.")
            return

        run_id = args[0]
        try:
            zip_path = cycle_manager.export(run_id)
            await update.message.reply_text(f"Export: {zip_path} ({zip_path.stat().st_size} bytes)")
        except Exception as exc:
            await update.message.reply_text(f"Error: {exc}")

    app.add_handler(CommandHandler("status", cmd_status))
    app.add_handler(CommandHandler("approve", cmd_approve))
    app.add_handler(CommandHandler("deny", cmd_deny))
    app.add_handler(CommandHandler("next", cmd_next))
    app.add_handler(CommandHandler("export", cmd_export))

    return app
