"""Base interfaces for LLM drivers."""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class LLMDriver(Protocol):
    """Protocol for LLM backends (Planner + Judge).

    Each method returns ``(response_json, meta)`` where:
    - response_json: parsed JSON dict matching the expected schema
    - meta: provider metadata (model, usage, latency, etc.)
    """

    @property
    def name(self) -> str:
        """Provider name (e.g. 'openai')."""
        ...

    @property
    def supports_structured(self) -> bool:
        """Whether the driver supports strict JSON schema enforcement."""
        ...

    def plan(
        self,
        planner_request: dict[str, Any],
        schema: dict[str, Any],
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Call the LLM to generate a planner response.

        Args:
            planner_request: PlannerRequest data dict.
            schema: JSON schema for structured output enforcement.

        Returns:
            (response_json, meta) tuple.
        """
        ...

    def judge(
        self,
        judge_request: dict[str, Any],
        schema: dict[str, Any],
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Call the LLM to generate a judge response.

        Args:
            judge_request: JudgeRequest data dict.
            schema: JSON schema for structured output enforcement.

        Returns:
            (response_json, meta) tuple.
        """
        ...
