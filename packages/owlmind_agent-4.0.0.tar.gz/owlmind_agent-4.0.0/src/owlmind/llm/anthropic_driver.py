"""Anthropic LLM driver — uses the official Anthropic Python SDK.

Requires ``anthropic>=0.39.0`` (optional dependency: ``pip install owlmind[anthropic]``).
API key is read from the ``ANTHROPIC_API_KEY`` environment variable.
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any

from owlmind.config import AnthropicConfig
from owlmind.llm.prompts import build_judge_prompts, build_planner_prompts
from owlmind.llm.retry import with_retry

logger = logging.getLogger(__name__)

_ANTHROPIC_AVAILABLE = False
try:
    import anthropic

    _ANTHROPIC_AVAILABLE = True
except ImportError:
    pass


def is_anthropic_available() -> bool:
    """Check if the anthropic SDK is installed."""
    return _ANTHROPIC_AVAILABLE


class AnthropicDriver:
    """Anthropic-backed LLM driver for Planner and Judge roles.

    Uses messages.create with ``output_config`` for JSON schema enforcement.
    """

    def __init__(self, config: AnthropicConfig) -> None:
        self._config = config
        self._client: Any = None

        if _ANTHROPIC_AVAILABLE and config.enabled:
            self._client = anthropic.Anthropic(
                api_key=config.api_key,
                timeout=config.timeout_sec,
            )

    @property
    def name(self) -> str:
        return "anthropic"

    @property
    def supports_structured(self) -> bool:
        return True

    def _call(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
        schema: dict[str, Any],
        schema_name: str,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Make a single Anthropic messages.create call with structured output.

        Returns ``(parsed_json, meta_dict)``.
        """
        if self._client is None:
            msg = "Anthropic client not initialized (missing ANTHROPIC_API_KEY or anthropic SDK)"
            raise RuntimeError(msg)

        def _do_call() -> tuple[dict[str, Any], dict[str, Any]]:
            t0 = time.monotonic()
            response = self._client.messages.create(
                model=self._config.model,
                max_tokens=self._config.max_output_tokens,
                system=system_prompt,
                messages=[{"role": "user", "content": user_prompt}],
                output_config={
                    "format": {
                        "type": "json_schema",
                        "schema": schema,
                    },
                },
            )
            latency_ms = int((time.monotonic() - t0) * 1000)

            # Extract content — first text block
            content_text = ""
            for block in response.content:
                if getattr(block, "type", "") == "text":
                    content_text = block.text
                    break

            parsed: dict[str, Any] = json.loads(content_text)

            # Build meta with usage
            meta: dict[str, Any] = {
                "provider": "anthropic",
                "model": self._config.model,
                "response_id": getattr(response, "id", ""),
                "latency_ms": latency_ms,
            }

            usage = getattr(response, "usage", None)
            if usage:
                meta["usage"] = {
                    "input_tokens": getattr(usage, "input_tokens", 0),
                    "output_tokens": getattr(usage, "output_tokens", 0),
                    "total_tokens": (
                        getattr(usage, "input_tokens", 0) + getattr(usage, "output_tokens", 0)
                    ),
                }
            else:
                meta["usage"] = {
                    "input_tokens": 0,
                    "output_tokens": 0,
                    "total_tokens": 0,
                    "usage_missing": True,
                }

            return parsed, meta

        return with_retry(_do_call, provider="Anthropic")

    def plan(
        self,
        planner_request: dict[str, Any],
        schema: dict[str, Any],
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Call Anthropic to generate a planner response."""
        system_prompt, user_prompt = build_planner_prompts(planner_request)
        return self._call(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            schema=schema,
            schema_name="PlannerResponse",
        )

    def judge(
        self,
        judge_request: dict[str, Any],
        schema: dict[str, Any],
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Call Anthropic to generate a judge response."""
        system_prompt, user_prompt = build_judge_prompts(judge_request)
        return self._call(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            schema=schema,
            schema_name="JudgeResponse",
        )
