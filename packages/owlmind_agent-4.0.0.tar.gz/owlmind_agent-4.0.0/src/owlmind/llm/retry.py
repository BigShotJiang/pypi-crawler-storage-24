"""Unified retry logic for LLM drivers."""

from __future__ import annotations

import json
import logging
import random
import time
from collections.abc import Callable
from typing import TypeVar

from owlmind.errors import OwlMindError, StructuralError, TransientError

logger = logging.getLogger(__name__)

T = TypeVar("T")

_TRANSIENT_KEYWORDS = (
    "timeout",
    "timed out",
    "rate limit",
    "rate_limit",
    "429",
    "503",
    "502",
    "500",
    "connection",
    "retries",
    "unavailable",
    "overloaded",
)


def is_transient(exc: Exception) -> bool:
    """Check if an error is transient (should trigger retry/fallback)."""
    msg = str(exc).lower()
    return any(kw in msg for kw in _TRANSIENT_KEYWORDS)


def classify_error(exc: Exception, provider: str) -> OwlMindError:
    """Classify a raw exception into TransientError or StructuralError."""
    if isinstance(exc, OwlMindError):
        return exc
    if isinstance(exc, json.JSONDecodeError):
        return StructuralError(f"{provider} response JSON decode error: {exc}")
    if is_transient(exc):
        return TransientError(f"{provider} transient error: {exc}")
    return StructuralError(f"{provider} error: {exc}")


def with_retry(
    fn: Callable[..., T],
    *,
    provider: str,
    max_retries: int = 5,
    base_delay: float = 2.0,
) -> T:
    """Execute fn with retry on transient errors, fail fast on structural.

    Returns the result of fn() on success.
    Raises StructuralError immediately (no retry).
    Raises TransientError after all retries exhausted.
    """
    last_error: Exception | None = None

    for attempt in range(max_retries):
        try:
            return fn()
        except json.JSONDecodeError as exc:
            raise StructuralError(f"{provider} response JSON decode error: {exc}") from exc
        except StructuralError:
            raise
        except Exception as exc:
            last_error = exc
            if is_transient(exc):
                logger.warning(
                    "%s transient error (attempt %d/%d): %s",
                    provider,
                    attempt + 1,
                    max_retries,
                    exc,
                )
            else:
                raise StructuralError(f"{provider} error: {exc}") from exc

        if attempt < max_retries - 1:
            delay = base_delay * (2**attempt) * random.uniform(0.75, 1.25)
            time.sleep(delay)

    msg = f"{provider} call failed after {max_retries} retries: {last_error}"
    raise TransientError(msg) from last_error
