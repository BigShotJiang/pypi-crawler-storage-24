"""LLM driver layer — pluggable backends for Planner/Judge API calls."""
