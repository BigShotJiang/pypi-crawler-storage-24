"""Ollama LLM driver — uses the Ollama REST API (no external SDK).

Ollama runs locally and exposes ``POST /api/chat`` for chat completions.
Base URL defaults to ``http://localhost:11434`` (standard Ollama port).

Configuration via environment variables:
    OLLAMA_BASE_URL   — API base URL (default: http://localhost:11434)
    OLLAMA_MODEL      — model name (default: llama3)
"""

from __future__ import annotations

import json
import logging
import time
import urllib.error
import urllib.request
from typing import Any

from owlmind.llm.prompts import build_judge_prompts, build_planner_prompts
from owlmind.llm.retry import with_retry

logger = logging.getLogger(__name__)


def is_ollama_available(base_url: str = "http://localhost:11434") -> bool:
    """Check if an Ollama server is reachable (best-effort, non-blocking)."""
    try:
        req = urllib.request.Request(
            f"{base_url}/api/tags",
            method="GET",
        )
        with urllib.request.urlopen(req, timeout=2) as resp:
            return resp.status == 200  # type: ignore[union-attr]
    except Exception:
        return False


class OllamaDriver:
    """Ollama-backed LLM driver for Planner and Judge roles.

    Uses ``POST /api/chat`` with JSON format enforcement.
    Ollama does not support strict JSON schema enforcement like OpenAI,
    so we instruct the model to return JSON and validate the output.
    """

    def __init__(self, config: Any) -> None:
        self._config = config
        self._base = config.base_url.rstrip("/")

    @property
    def name(self) -> str:
        return "ollama"

    @property
    def supports_structured(self) -> bool:
        return False

    def _call(
        self,
        *,
        model: str,
        system_prompt: str,
        user_prompt: str,
        schema: dict[str, Any],
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Call Ollama /api/chat and return (parsed_json, meta)."""
        url = f"{self._base}/api/chat"

        # Instruct model to return valid JSON matching the schema
        schema_hint = json.dumps(schema, indent=2)
        augmented_system = (
            f"{system_prompt}\n\n"
            f"You MUST return a valid JSON object matching this schema:\n"
            f"```json\n{schema_hint}\n```\n"
            f"Return ONLY the JSON object, no extra text."
        )

        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": augmented_system},
                {"role": "user", "content": user_prompt},
            ],
            "stream": False,
            "format": "json",
            "options": {
                "num_predict": self._config.max_output_tokens,
            },
        }

        def _do_call() -> tuple[dict[str, Any], dict[str, Any]]:
            t0 = time.monotonic()
            body = json.dumps(payload).encode()
            req = urllib.request.Request(
                url,
                data=body,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=self._config.timeout_sec) as resp:
                raw = resp.read().decode()

            latency_ms = int((time.monotonic() - t0) * 1000)
            response = json.loads(raw)

            # Extract the message content
            content = response.get("message", {}).get("content", "")
            parsed = json.loads(content)

            # Build meta
            meta: dict[str, Any] = {
                "provider": "ollama",
                "model": response.get("model", model),
                "response_id": "",
                "latency_ms": latency_ms,
            }

            # Ollama provides token counts in response
            if "prompt_eval_count" in response or "eval_count" in response:
                meta["usage"] = {
                    "input_tokens": response.get("prompt_eval_count", 0),
                    "output_tokens": response.get("eval_count", 0),
                    "total_tokens": (
                        response.get("prompt_eval_count", 0) + response.get("eval_count", 0)
                    ),
                }

            return parsed, meta

        return with_retry(_do_call, provider="Ollama")

    def plan(
        self,
        planner_request: dict[str, Any],
        schema: dict[str, Any],
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Call Ollama to generate a planner response."""
        system_prompt, user_prompt = build_planner_prompts(planner_request)
        return self._call(
            model=self._config.model,
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            schema=schema,
        )

    def judge(
        self,
        judge_request: dict[str, Any],
        schema: dict[str, Any],
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Call Ollama to generate a judge response."""
        system_prompt, user_prompt = build_judge_prompts(judge_request)
        return self._call(
            model=self._config.model,
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            schema=schema,
        )
