"""Smart LLM Router — policy-based provider/model selection with circuit breaker.

Wraps LLMRouter and adds:
- CircuitBreaker: per-provider failure tracking (opens after threshold, auto-recovers)
- Phase-aware routing: judge phase → prefer powerful model, planner → balanced
- Complexity routing: simple goals → haiku/flash, complex → opus/gpt-4o
- Skill overrides: security_audit, refactor → always opus

Configuration via environment variables:
    OWLMIND_CIRCUIT_BREAKER_THRESHOLD  — int, default 5
    OWLMIND_CIRCUIT_BREAKER_RECOVERY_S — float, default 60.0
"""

from __future__ import annotations

import logging
import random
import threading
import time
from dataclasses import dataclass, field
from typing import Any, cast

from owlmind.llm.retry import is_transient

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Circuit Breaker
# ---------------------------------------------------------------------------


@dataclass
class _BreakerState:
    failures: int = 0
    opened_at: float = field(default=0.0)  # monotonic timestamp when circuit opened
    jitter: float = field(default=0.0)  # random offset added to recovery timeout


class CircuitBreaker:
    """Thread-safe per-provider circuit breaker.

    States:
        Closed  — normal operation, failures < threshold
        Open    — provider blocked, opened_at set
        Half-open — recovery_timeout elapsed, allow one probe request

    Args:
        failure_threshold: Number of consecutive failures to open circuit.
        recovery_timeout_s: Seconds after which an open circuit enters half-open.
    """

    def __init__(
        self,
        failure_threshold: int = 5,
        recovery_timeout_s: float = 60.0,
    ) -> None:
        self._threshold = failure_threshold
        self._recovery = recovery_timeout_s
        self._states: dict[str, _BreakerState] = {}
        self._lock = threading.Lock()

    def is_open(self, provider: str) -> bool:
        """Return True if the circuit is open (provider should be skipped)."""
        with self._lock:
            state = self._states.get(provider)
            if state is None or state.failures < self._threshold:
                return False
            # Check recovery timeout -> half-open.
            # Jitter spreads recovery across providers to avoid thundering herd.
            return (time.monotonic() - state.opened_at) < (self._recovery + state.jitter)

    def record_failure(self, provider: str) -> None:
        """Record a failure for provider; opens circuit at threshold."""
        with self._lock:
            state = self._states.setdefault(provider, _BreakerState())
            state.failures += 1
            if state.failures == self._threshold:
                state.opened_at = time.monotonic()
                # Jitter: spread recovery across providers to prevent thundering herd.
                # Each provider gets a unique random offset in [0, 20% of recovery_timeout].
                state.jitter = random.uniform(0, self._recovery * 0.2)
                logger.warning(
                    "Circuit breaker OPENED for provider %r after %d failures "
                    "(recovery in %.1f–%.1fs)",
                    provider,
                    self._threshold,
                    self._recovery,
                    self._recovery + state.jitter,
                )

    def record_success(self, provider: str) -> None:
        """Reset failure count on success (closes circuit)."""
        with self._lock:
            if provider in self._states and self._states[provider].failures > 0:
                logger.info("Circuit breaker CLOSED for provider %r", provider)
                self._states[provider] = _BreakerState()

    def get_stats(self) -> dict[str, dict[str, Any]]:
        """Return current state per provider (for diagnostics)."""
        now = time.monotonic()
        with self._lock:
            return {
                p: {
                    "failures": s.failures,
                    # Inline open check to avoid re-acquiring the same Lock.
                    # Effective recovery = base timeout + per-provider jitter.
                    "open": (
                        s.failures >= self._threshold
                        and (now - s.opened_at) < (self._recovery + s.jitter)
                    ),
                    "opened_ago_s": (
                        round(now - s.opened_at, 1) if s.opened_at else None
                    ),
                    "recovery_timeout_s": (
                        round(self._recovery + s.jitter, 3) if s.opened_at else None
                    ),
                }
                for p, s in self._states.items()
            }


# ---------------------------------------------------------------------------
# Routing rules
# ---------------------------------------------------------------------------

# Skill packs that require the most capable model
_HIGH_STAKES_SKILLS: frozenset[str] = frozenset(
    {"security_audit", "refactor", "migrate", "breaking_change"}
)

# Per-complexity provider + model preferences
# Format: (provider, model_hint)  — model_hint is passed to driver as override kwarg
_COMPLEXITY_ROUTES: dict[str, tuple[str, str]] = {
    "simple": ("anthropic", "claude-haiku-4-5-20251001"),
    "medium": ("anthropic", "claude-sonnet-4-6"),
    "complex": ("anthropic", "claude-opus-4-6"),
}

_JUDGE_PREFERRED = ("anthropic", "claude-opus-4-6")  # judge always gets powerful model


# ---------------------------------------------------------------------------
# SmartLLMRouter
# ---------------------------------------------------------------------------


class SmartLLMRouter:
    """Policy-based LLM router wrapping LLMRouter.

    Routing priority (highest wins):
    1. High-stakes skill override  -> opus
    2. Judge phase                 -> opus
    3. Complexity-based            -> haiku/sonnet/opus
    4. Fallback: delegate to wrapped LLMRouter
    """

    def __init__(
        self,
        base_router: Any,
        *,
        circuit_breaker: CircuitBreaker | None = None,
    ) -> None:
        self._base = base_router
        self._cb = circuit_breaker or CircuitBreaker()

    @property
    def name(self) -> str:
        return "smart_router"

    @property
    def supports_structured(self) -> bool:
        return True

    def available_providers(self) -> list[str]:
        return cast(list[str], self._base.available_providers())

    def circuit_breaker_stats(self) -> dict[str, dict[str, Any]]:
        """Return circuit breaker diagnostics."""
        return self._cb.get_stats()

    # ------------------------------------------------------------------
    # Provider selection helpers
    # ------------------------------------------------------------------

    def _select_provider(
        self,
        stage: str,
        goal: str,
        skill_id: str = "",
    ) -> str | None:
        """Return preferred provider name or None (fall back to base router).

        Args:
            stage: "planner" or "judge"
            goal: Goal text for complexity classification
            skill_id: Skill pack id (e.g. "security_audit")

        Returns:
            Provider name string, or None to use base router defaults.
        """
        try:
            from owlmind.llm.complexity import classify_goal

            complexity = classify_goal(goal)
        except Exception:
            complexity = "medium"

        # 1. High-stakes skill -> always opus
        if skill_id and any(s in skill_id.lower() for s in _HIGH_STAKES_SKILLS):
            provider, _ = _JUDGE_PREFERRED
            return provider if not self._cb.is_open(provider) else None

        # 2. Judge phase -> prefer opus
        if stage == "judge":
            provider, _ = _JUDGE_PREFERRED
            if not self._cb.is_open(provider):
                return provider

        # 3. Complexity routing
        if complexity in _COMPLEXITY_ROUTES:
            provider, _ = _COMPLEXITY_ROUTES[complexity]
            if not self._cb.is_open(provider):
                return provider

        return None

    # ------------------------------------------------------------------
    # Public API (same as LLMRouter)
    # ------------------------------------------------------------------

    def plan(
        self,
        planner_request: dict[str, Any],
        schema: dict[str, Any],
        *,
        force_provider: str | None = None,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Route a planner call with smart provider selection."""
        provider = force_provider or self._select_provider(
            "planner", planner_request.get("goal", "")
        )
        try:
            result = cast(
                tuple[dict[str, Any], dict[str, Any]],
                self._base.plan(planner_request, schema, force_provider=provider),
            )
            if provider:
                self._cb.record_success(provider)
            return result
        except Exception as exc:
            if provider and is_transient(exc):
                self._cb.record_failure(provider)
            raise

    def judge(
        self,
        judge_request: dict[str, Any],
        schema: dict[str, Any],
        *,
        force_provider: str | None = None,
        skill_id: str = "",
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Route a judge call with smart provider selection."""
        provider = force_provider or self._select_provider(
            "judge", judge_request.get("goal", ""), skill_id=skill_id
        )
        try:
            result = cast(
                tuple[dict[str, Any], dict[str, Any]],
                self._base.judge(judge_request, schema, force_provider=provider),
            )
            if provider:
                self._cb.record_success(provider)
            return result
        except Exception as exc:
            if provider and is_transient(exc):
                self._cb.record_failure(provider)
            raise


def make_smart_router(base_router: Any) -> SmartLLMRouter:
    """Factory: wrap any LLMRouter-compatible driver in SmartLLMRouter.

    Reads circuit breaker config from environment:
        OWLMIND_CIRCUIT_BREAKER_THRESHOLD  — int, default 5
        OWLMIND_CIRCUIT_BREAKER_RECOVERY_S — float, default 60.0
    """
    import os

    threshold = int(os.environ.get("OWLMIND_CIRCUIT_BREAKER_THRESHOLD", "5"))
    recovery = float(os.environ.get("OWLMIND_CIRCUIT_BREAKER_RECOVERY_S", "60.0"))
    cb = CircuitBreaker(failure_threshold=threshold, recovery_timeout_s=recovery)
    return SmartLLMRouter(base_router, circuit_breaker=cb)
