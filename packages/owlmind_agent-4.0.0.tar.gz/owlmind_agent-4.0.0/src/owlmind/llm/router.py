"""LLM Router — selects provider per stage with fallback on transient errors."""

from __future__ import annotations

import enum
import logging
import time
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from owlmind.llm.retry import is_transient

if TYPE_CHECKING:
    from owlmind.llm.cache import LLMCache
    from owlmind.monitoring.llm_observer import LLMObserver

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Provider health state machine
# ---------------------------------------------------------------------------


class ProviderState(enum.StrEnum):
    """Provider health states."""

    HEALTHY = "healthy"
    DEGRADED = "degraded"
    FAILED = "failed"
    COOLDOWN = "cooldown"


@dataclass
class ProviderHealth:
    """Tracks health of a single LLM provider."""

    state: ProviderState = ProviderState.HEALTHY
    consecutive_failures: int = 0
    last_failure_time: float = 0.0
    last_success_time: float = 0.0
    total_calls: int = 0
    total_failures: int = 0
    total_successes: int = 0

    # Thresholds
    degraded_threshold: int = 1
    failed_threshold: int = 3
    cooldown_seconds: float = 60.0

    def record_success(self) -> None:
        """Record a successful call — resets to HEALTHY."""
        self.total_calls += 1
        self.total_successes += 1
        self.consecutive_failures = 0
        self.last_success_time = time.time()
        old = self.state
        self.state = ProviderState.HEALTHY
        if old != ProviderState.HEALTHY:
            logger.info("Provider recovered: %s -> HEALTHY", old)

    def record_failure(self) -> None:
        """Record a failed call — transitions through state machine."""
        self.total_calls += 1
        self.total_failures += 1
        self.consecutive_failures += 1
        self.last_failure_time = time.time()
        old = self.state
        if self.consecutive_failures >= self.failed_threshold:
            self.state = ProviderState.FAILED
        elif self.consecutive_failures >= self.degraded_threshold:
            self.state = ProviderState.DEGRADED
        if old != self.state:
            logger.warning("Provider state change: %s -> %s", old, self.state)

    def is_available(self) -> bool:
        """Check if provider can accept calls right now."""
        if self.state in (ProviderState.HEALTHY, ProviderState.DEGRADED):
            return True
        if self.state == ProviderState.FAILED:
            # Check cooldown
            elapsed = time.time() - self.last_failure_time
            if elapsed >= self.cooldown_seconds:
                self.state = ProviderState.COOLDOWN
                logger.info("Provider entering COOLDOWN (will retry)")
                return True
            return False
        return self.state == ProviderState.COOLDOWN


# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------


class LLMRouter:
    """Routes LLM calls to providers with fallback on transient errors.

    Features:
    - Provider health state machine (HEALTHY → DEGRADED → FAILED → COOLDOWN)
    - Optional response caching via LLMCache
    - Optional observability via LLMObserver
    """

    def __init__(
        self,
        drivers: dict[str, Any],
        planner_providers: list[str],
        judge_providers: list[str],
        observer: LLMObserver | None = None,
        cache: LLMCache | None = None,
    ) -> None:
        self._drivers = drivers
        self._planner_providers = planner_providers
        self._judge_providers = judge_providers
        self._observer = observer
        self._cache = cache
        self._health: dict[str, ProviderHealth] = {
            name: ProviderHealth() for name in drivers
        }

    @property
    def name(self) -> str:
        return "router"

    @property
    def supports_structured(self) -> bool:
        return True

    @property
    def cache_enabled(self) -> bool:
        return self._cache is not None

    def available_providers(self) -> list[str]:
        """Return list of available (initialized) provider names."""
        return list(self._drivers.keys())

    def provider_health(self) -> dict[str, ProviderHealth]:
        """Return health status of all providers."""
        return dict(self._health)

    def _sorted_providers(self, providers: list[str]) -> list[str]:
        """Sort providers: HEALTHY first, then DEGRADED, then COOLDOWN."""
        def _sort_key(name: str) -> int:
            h = self._health.get(name)
            if h is None:
                return 99
            state_order = {
                ProviderState.HEALTHY: 0,
                ProviderState.DEGRADED: 1,
                ProviderState.COOLDOWN: 2,
                ProviderState.FAILED: 3,
            }
            return state_order.get(h.state, 99)

        return sorted(providers, key=_sort_key)

    def _route(
        self,
        stage: str,
        method_name: str,
        request: dict[str, Any],
        schema: dict[str, Any],
        *,
        force_provider: str | None = None,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Route a call to the appropriate provider with fallback."""
        # Check cache first
        if self._cache is not None:
            cache_key = self._cache.make_key(request, schema)
            cached = self._cache.get(cache_key)
            if cached is not None:
                resp, meta = cached
                meta["cache_hit"] = True
                return resp, meta

        if force_provider:
            providers = [force_provider]
        else:
            raw = self._planner_providers if stage == "planner" else self._judge_providers
            providers = self._sorted_providers(raw)

        attempts: list[dict[str, Any]] = []
        last_error: Exception | None = None

        for provider_name in providers:
            driver = self._drivers.get(provider_name)
            if driver is None:
                logger.debug("Provider %s not available, skipping", provider_name)
                attempts.append(
                    {
                        "provider": provider_name,
                        "status": "skipped",
                        "reason": "not available",
                    }
                )
                continue

            # Check health state
            health = self._health.get(provider_name)
            if health and not health.is_available():
                logger.debug("Provider %s is %s, skipping", provider_name, health.state)
                attempts.append(
                    {
                        "provider": provider_name,
                        "status": "skipped",
                        "reason": f"health={health.state}",
                    }
                )
                continue

            try:
                if self._observer:
                    self._observer.on_call_start(provider_name, stage, request)

                method = getattr(driver, method_name)
                response_json, meta = method(request, schema)

                # Record success
                if health:
                    health.record_success()

                # Enrich meta with routing info
                meta["routed_by"] = "router"
                meta["provider_state"] = health.state.value if health else "unknown"
                meta["attempts"] = attempts + [
                    {
                        "provider": provider_name,
                        "status": "success",
                    }
                ]

                if self._observer:
                    self._observer.on_call_end(provider_name, stage, response_json, meta)

                # Store in cache
                if self._cache is not None:
                    self._cache.put(cache_key, response_json, meta)

                return response_json, meta

            except Exception as exc:
                # Record failure
                if health:
                    health.record_failure()

                if self._observer:
                    self._observer.on_call_end(
                        provider_name, stage, None, {}, error=exc,
                    )

                attempts.append(
                    {
                        "provider": provider_name,
                        "status": "failed",
                        "error": str(exc)[:200],
                        "transient": is_transient(exc),
                    }
                )
                last_error = exc

                if is_transient(exc):
                    logger.warning(
                        "Transient error from %s for %s, trying next: %s",
                        provider_name,
                        stage,
                        exc,
                    )
                    continue

                # Non-transient (e.g. schema violation) — hard fail
                logger.error(
                    "Non-transient error from %s for %s: %s",
                    provider_name,
                    stage,
                    exc,
                )
                raise

        msg = (
            f"All providers failed for {stage}: "
            f"{[a['provider'] for a in attempts]}. Last error: {last_error}"
        )
        raise RuntimeError(msg)

    def plan(
        self,
        planner_request: dict[str, Any],
        schema: dict[str, Any],
        *,
        force_provider: str | None = None,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Route a planner call through the provider chain."""
        return self._route(
            "planner",
            "plan",
            planner_request,
            schema,
            force_provider=force_provider,
        )

    def judge(
        self,
        judge_request: dict[str, Any],
        schema: dict[str, Any],
        *,
        force_provider: str | None = None,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Route a judge call through the provider chain."""
        return self._route(
            "judge",
            "judge",
            judge_request,
            schema,
            force_provider=force_provider,
        )
