"""OpenAI LLM driver — uses the official OpenAI Python SDK.

Requires ``openai>=1.0.0`` (optional dependency: ``pip install owlmind[openai]``).
API key is read from the ``OPENAI_API_KEY`` environment variable.
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any

from owlmind.config import OpenAIConfig
from owlmind.llm.prompts import build_judge_prompts, build_planner_prompts
from owlmind.llm.retry import with_retry

logger = logging.getLogger(__name__)

# Attempt import of openai SDK
_OPENAI_AVAILABLE = False
try:
    from openai import OpenAI

    _OPENAI_AVAILABLE = True
except ImportError:
    pass


def is_openai_available() -> bool:
    """Check if the openai SDK is installed."""
    return _OPENAI_AVAILABLE


class OpenAIDriver:
    """OpenAI-backed LLM driver for Planner and Judge roles.

    Uses chat.completions with ``response_format`` for strict JSON schema
    enforcement (Structured Outputs).
    """

    def __init__(self, config: OpenAIConfig) -> None:
        self._config = config
        self._client: Any = None

        if _OPENAI_AVAILABLE and config.enabled:
            kwargs: dict[str, Any] = {"timeout": config.timeout_sec}
            if config.base_url:
                kwargs["base_url"] = config.base_url
            self._client = OpenAI(**kwargs)

    @property
    def name(self) -> str:
        return "openai"

    @property
    def supports_structured(self) -> bool:
        return True

    def _call(
        self,
        *,
        model: str,
        system_prompt: str,
        user_prompt: str,
        schema: dict[str, Any],
        schema_name: str,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Make a single OpenAI chat.completions call with structured output.

        Returns ``(parsed_json, meta_dict)``.
        """
        if self._client is None:
            msg = "OpenAI client not initialized (missing OPENAI_API_KEY or openai SDK)"
            raise RuntimeError(msg)

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

        if self._config.use_json_schema:
            response_format: dict[str, Any] = {
                "type": "json_schema",
                "json_schema": {
                    "name": schema_name,
                    "schema": schema,
                    "strict": True,
                },
            }
        else:
            # Compatible endpoints (DeepSeek, Azure, Ollama, etc.) — use json_object
            response_format = {"type": "json_object"}
            # Inject JSON instruction into system prompt
            messages[0]["content"] = (
                messages[0]["content"]
                + "\n\nRespond with valid JSON only. No markdown, no code fences."
            )

        def _do_call() -> tuple[dict[str, Any], dict[str, Any]]:
            t0 = time.monotonic()
            response = self._client.chat.completions.create(
                model=model,
                messages=messages,
                response_format=response_format,
                max_tokens=self._config.max_output_tokens,
            )
            latency_ms = int((time.monotonic() - t0) * 1000)

            content = response.choices[0].message.content
            parsed = json.loads(content)

            usage = response.usage
            meta: dict[str, Any] = {
                "provider": "openai",
                "model": model,
                "response_id": getattr(response, "id", ""),
                "latency_ms": latency_ms,
            }
            if usage:
                meta["usage"] = {
                    "input_tokens": usage.prompt_tokens,
                    "output_tokens": usage.completion_tokens,
                    "total_tokens": usage.total_tokens,
                }

            return parsed, meta

        return with_retry(_do_call, provider="OpenAI")

    def plan(
        self,
        planner_request: dict[str, Any],
        schema: dict[str, Any],
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Call OpenAI to generate a planner response."""
        system_prompt, user_prompt = build_planner_prompts(planner_request)
        return self._call(
            model=self._config.planner_model,
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            schema=schema,
            schema_name="PlannerResponse",
        )

    def judge(
        self,
        judge_request: dict[str, Any],
        schema: dict[str, Any],
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Call OpenAI to generate a judge response."""
        system_prompt, user_prompt = build_judge_prompts(judge_request)
        parsed, meta = self._call(
            model=self._config.judge_model,
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            schema=schema,
            schema_name="JudgeResponse",
        )
        # Inject fields that json_object mode may omit (non-OpenAI endpoints)
        if "run_id" not in parsed:
            parsed["run_id"] = judge_request.get("run_id", "")
        if "iteration" not in parsed:
            parsed["iteration"] = judge_request.get("iteration", 1)
        if not parsed.get("next_worker_instructions"):
            parsed["next_worker_instructions"] = ""
        if "evidence_chain_verified" not in parsed:
            parsed["evidence_chain_verified"] = True
        return parsed, meta


# JSON schemas for structured output enforcement
PLANNER_RESPONSE_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "run_id": {"type": "string"},
        "iteration": {"type": "integer"},
        "plan_summary": {"type": "array", "items": {"type": "string"}},
        "worker_instructions": {"type": "string"},
        "verify_commands": {"type": "array", "items": {"type": "string"}},
        "risk_notes": {"type": "array", "items": {"type": "string"}},
    },
    "required": [
        "run_id",
        "iteration",
        "plan_summary",
        "worker_instructions",
        "verify_commands",
        "risk_notes",
    ],
    "additionalProperties": False,
}

JUDGE_RESPONSE_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "run_id": {"type": "string"},
        "iteration": {"type": "integer"},
        "verdict": {"type": "string", "enum": ["APPROVED", "NEEDS_FIX", "REJECTED"]},
        "notes": {"type": "array", "items": {"type": "string"}},
        "next_worker_instructions": {"type": "string"},
        "evidence_chain_verified": {"type": "boolean"},
    },
    "required": [
        "run_id",
        "iteration",
        "verdict",
        "notes",
        "next_worker_instructions",
        "evidence_chain_verified",
    ],
    "additionalProperties": False,
}
