"""Gemini LLM driver — uses the Google GenAI Python SDK.

Requires ``google-genai>=1.0.0`` (optional dependency: ``pip install owlmind[gemini]``).
API key is read from ``GEMINI_API_KEY`` or ``GOOGLE_API_KEY`` environment variable.
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any

from owlmind.config import GeminiConfig
from owlmind.llm.prompts import build_judge_prompts, build_planner_prompts
from owlmind.llm.retry import with_retry

logger = logging.getLogger(__name__)

_GEMINI_AVAILABLE = False
try:
    from google import genai

    _GEMINI_AVAILABLE = True
except ImportError:
    pass


def is_gemini_available() -> bool:
    """Check if the google-genai SDK is installed."""
    return _GEMINI_AVAILABLE


class GeminiDriver:
    """Google Gemini-backed LLM driver for Planner and Judge roles.

    Uses GenerativeModel with response_schema for structured output.
    """

    def __init__(self, config: GeminiConfig) -> None:
        self._config = config
        self._client: Any = None

        if _GEMINI_AVAILABLE and config.enabled:
            self._client = genai.Client(api_key=config.api_key)

    @property
    def name(self) -> str:
        return "gemini"

    @property
    def supports_structured(self) -> bool:
        return True

    def _call(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
        schema: dict[str, Any],
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Make a single Gemini generate_content call with structured output.

        Returns ``(parsed_json, meta_dict)``.
        """
        if self._client is None:
            msg = "Gemini client not initialized (missing GEMINI_API_KEY or google-genai SDK)"
            raise RuntimeError(msg)

        def _do_call() -> tuple[dict[str, Any], dict[str, Any]]:
            t0 = time.monotonic()
            response = self._client.models.generate_content(
                model=self._config.model,
                contents=f"{system_prompt}\n\n{user_prompt}",
                config={
                    "response_mime_type": "application/json",
                    "response_schema": schema,
                    "max_output_tokens": self._config.max_output_tokens,
                },
            )
            latency_ms = int((time.monotonic() - t0) * 1000)

            content_text = response.text or ""
            parsed: dict[str, Any] = json.loads(content_text)

            meta: dict[str, Any] = {
                "provider": "gemini",
                "model": self._config.model,
                "response_id": "",
                "latency_ms": latency_ms,
            }

            usage_meta = getattr(response, "usage_metadata", None)
            if usage_meta:
                input_tokens = getattr(usage_meta, "prompt_token_count", 0) or 0
                output_tokens = getattr(usage_meta, "candidates_token_count", 0) or 0
                meta["usage"] = {
                    "input_tokens": input_tokens,
                    "output_tokens": output_tokens,
                    "total_tokens": input_tokens + output_tokens,
                }
            else:
                meta["usage"] = {
                    "input_tokens": 0,
                    "output_tokens": 0,
                    "total_tokens": 0,
                    "usage_missing": True,
                }

            return parsed, meta

        return with_retry(_do_call, provider="Gemini")

    def plan(
        self,
        planner_request: dict[str, Any],
        schema: dict[str, Any],
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Call Gemini to generate a planner response."""
        system_prompt, user_prompt = build_planner_prompts(planner_request)
        return self._call(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            schema=schema,
        )

    def judge(
        self,
        judge_request: dict[str, Any],
        schema: dict[str, Any],
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Call Gemini to generate a judge response."""
        system_prompt, user_prompt = build_judge_prompts(judge_request)
        return self._call(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            schema=schema,
        )
