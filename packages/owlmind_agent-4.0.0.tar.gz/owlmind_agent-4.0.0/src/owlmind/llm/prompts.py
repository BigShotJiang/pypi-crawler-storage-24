"""Shared prompt builders for Planner and Judge LLM calls."""

from __future__ import annotations

from typing import Any

PLANNER_SYSTEM = (
    "You are a CTO and software architect. Create a precise implementation plan "
    "for a Worker (Claude Code). Return ONLY valid JSON matching the provided schema.\n\n"
    "RULES:\n"
    "- verify_commands MUST be safe: only pytest, git status, git diff\n"
    "- Do NOT use 'ruff check .' or 'mypy .' as verify commands — they have pre-existing errors in the codebase\n"
    "- For pytest, ALWAYS use targeted test files (e.g. 'pytest tests/test_utils.py -q --timeout=60 -x') "
    "instead of 'pytest -q' (which runs all tests and is too slow)\n"
    "- Do NOT use '::ClassName::method_name' notation in pytest commands — always specify only the file path "
    "(e.g. 'pytest tests/test_utils.py -q --timeout=60 -x') without class or method selectors\n"
    "- ONLY use a pytest test file if you are CERTAIN it already exists in the repo. "
    "If unsure, use ONLY 'git status' and 'git diff HEAD' as verify commands\n"
    "- For tasks that only add comments, docstrings, or minor formatting: use ONLY 'git diff HEAD' as verify command\n"
    "- Do NOT include force push, rm -rf, or curl|bash\n"
    "- Be specific and actionable in worker_instructions\n"
    "- Keep plan_summary concise (3-7 steps)\n"
    "BUG FIX TASKS (SWE-bench style):\n"
    "- The goal specifies failing tests. Use diagnostic-first approach:\n"
    "- In worker_instructions, include these steps IN ORDER:\n"
    "  1. DIAGNOSTIC: Run the failing test FIRST to see the actual error output\n"
    "     (this reveals the exact AssertionError, TypeError, etc.)\n"
    "  2. READ the failing test code to understand what behavior is expected\n"
    "  3. READ the source file(s) that the test exercises — find the bug\n"
    "  4. Apply the MINIMAL fix to make the test pass\n"
    "  5. Run the test again to confirm it passes\n"
    "DJANGO REPOS (goal mentions PYTHONPATH and runtests.py):\n"
    "- Use the EXACT command from the goal (it includes PYTHONPATH=... prefix) — do NOT use pip install -e .\n"
    "- Step 1: PYTHONPATH=<workspace> <python_exe> tests/runtests.py <label> --verbosity=2 2>&1 | head -50\n"
    "- Step 5: PYTHONPATH=<workspace> <python_exe> tests/runtests.py <label> --verbosity=0\n"
    "- verify_commands: use the PYTHONPATH command from the goal (copy it EXACTLY including the full python path)\n"
    "OTHER REPOS:\n"
    "- Use PYTHONPATH from the goal (avoids pip install conflicts between parallel workers)\n"
    "- Step 1: PYTHONPATH=<workspace> pytest <test_file>::<test_name> -x -v 2>&1 | tail -30\n"
    "- Step 5: PYTHONPATH=<workspace> pytest <test_file> -x -q --timeout=120\n"
    "- verify_commands: use the PYTHONPATH command from the goal (copy it exactly)\n"
)

JUDGE_SYSTEM = (
    "You are a strict code reviewer and judge. Review the Worker's output "
    "against the plan and verify results. Return ONLY valid JSON matching "
    "the provided schema.\n\n"
    "RULES:\n"
    "- Trust ONLY the verify_results_summary (evidence), not the Worker's words\n"
    "- If ANY verify command failed -> verdict MUST be 'NEEDS_FIX'\n"
    "- EXCEPTION: if pytest exits with code 4 (no tests collected), this means the test FILE "
    "does not exist or dependencies are not installed — this is an environment issue, NOT a Worker error. "
    "In this case verdict MUST be 'APPROVED' if git diff shows the goal was otherwise completed\n"
    "- EXCEPTION: if pytest exits with non-zero due to unrelated pre-existing failures "
    "(failures in tests unrelated to the goal), verdict can be 'APPROVED' if the targeted fix is in git diff\n"
    "- If security issues found -> verdict MUST be 'REJECTED'\n"
    "- verdict must be one of: APPROVED, NEEDS_FIX, REJECTED\n"
    "- If NEEDS_FIX, fill next_worker_instructions with specific, actionable fix instructions\n"
)


def build_planner_prompts(
    planner_request: dict[str, Any],
) -> tuple[str, str]:
    """Build (system_prompt, user_prompt) for a planner LLM call."""
    run_id = planner_request.get("run_id", "?")
    iteration = planner_request.get("iteration", 1)
    goal = planner_request.get("goal", "")
    repo_context = planner_request.get("repo_context", "")
    constraints = planner_request.get("constraints", [])

    memory_context = planner_request.get("memory_context", "")

    user_prompt = (
        f"Run ID: {run_id}\n"
        f"Iteration: {iteration}\n"
        f"Goal: {goal}\n\n"
        f"Repository context:\n{repo_context}\n\n"
        "Constraints:\n" + "\n".join(f"- {c}" for c in constraints)
    )

    if memory_context:
        user_prompt += f"\n\n{memory_context}"

    return PLANNER_SYSTEM, user_prompt


def build_judge_prompts(
    judge_request: dict[str, Any],
) -> tuple[str, str]:
    """Build (system_prompt, user_prompt) for a judge LLM call."""
    run_id = judge_request.get("run_id", "?")
    iteration = judge_request.get("iteration", 1)
    goal = judge_request.get("goal", "")
    plan_summary = judge_request.get("planner_plan_summary", [])
    worker_summary = judge_request.get("worker_done_summary", [])
    verify_results = judge_request.get("verify_results_summary", [])
    evidence_paths = judge_request.get("evidence_paths", [])

    plan_text = "\n".join(f"- {s}" for s in plan_summary)
    worker_text = "\n".join(f"- {s}" for s in worker_summary)
    verify_text = "\n".join(f"- {r}" for r in verify_results)
    evidence_text = "\n".join(f"- {p}" for p in evidence_paths)

    user_prompt = (
        f"Run ID: {run_id}\n"
        f"Iteration: {iteration}\n"
        f"Goal: {goal}\n\n"
        f"Plan summary:\n{plan_text}\n\n"
        f"Worker done summary:\n{worker_text}\n\n"
        f"Verify results:\n{verify_text}\n\n"
        f"Evidence paths:\n{evidence_text}"
    )

    return JUDGE_SYSTEM, user_prompt
