"""Content-addressable LLM response cache with TTL expiration."""

from __future__ import annotations

import json
import logging
import time
from pathlib import Path
from typing import Any

from owlmind.utils import sha256

logger = logging.getLogger(__name__)


def _canonical_json(obj: dict[str, Any]) -> bytes:
    """Produce stable canonical JSON bytes for cache key computation."""
    return json.dumps(
        obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str
    ).encode()


class LLMCache:
    """Content-addressable LLM response cache.

    Each entry is a JSON file named by its SHA-256 key.
    Entries expire after ``ttl_seconds`` and are evicted lazily
    or via explicit ``evict_expired()`` calls.
    """

    def __init__(
        self,
        cache_dir: str | Path,
        ttl_seconds: int = 3600,
        max_entries: int = 1000,
    ) -> None:
        self._dir = Path(cache_dir)
        self._dir.mkdir(parents=True, exist_ok=True)
        self._ttl = ttl_seconds
        self._max_entries = max_entries
        self._hits = 0
        self._misses = 0

    def make_key(self, request: dict[str, Any], schema: dict[str, Any]) -> str:
        """Compute a cache key from request + schema."""
        payload = {"request": request, "schema": schema}
        return sha256(_canonical_json(payload))

    def get(self, key: str) -> tuple[dict[str, Any], dict[str, Any]] | None:
        """Retrieve a cached response. Returns ``(response_json, meta)`` or None."""
        path = self._dir / f"{key}.json"
        if not path.exists():
            self._misses += 1
            return None

        try:
            data: dict[str, Any] = json.loads(path.read_text())
        except (json.JSONDecodeError, OSError):
            self._misses += 1
            path.unlink(missing_ok=True)
            return None

        # Check TTL
        stored_at = data.get("_stored_at", 0)
        if time.time() - stored_at > self._ttl:
            self._misses += 1
            path.unlink(missing_ok=True)
            return None

        self._hits += 1
        return data.get("response", {}), data.get("meta", {})

    def put(
        self,
        key: str,
        response_json: dict[str, Any],
        meta: dict[str, Any],
    ) -> None:
        """Store a response in the cache."""
        # Enforce max entries (simple LRU: remove oldest)
        self._maybe_evict()

        entry = {
            "_stored_at": time.time(),
            "_key": key,
            "response": response_json,
            "meta": meta,
        }
        path = self._dir / f"{key}.json"
        try:
            path.write_text(json.dumps(entry, default=str))
        except OSError:
            logger.debug("Failed to write cache entry %s", key)

    def evict_expired(self) -> int:
        """Remove all expired entries. Returns count of evicted entries."""
        evicted = 0
        now = time.time()
        for path in self._dir.glob("*.json"):
            try:
                data = json.loads(path.read_text())
                stored_at = data.get("_stored_at", 0)
                if now - stored_at > self._ttl:
                    path.unlink()
                    evicted += 1
            except (json.JSONDecodeError, OSError):
                path.unlink(missing_ok=True)
                evicted += 1
        return evicted

    def stats(self) -> dict[str, Any]:
        """Return cache statistics."""
        entry_count = sum(1 for _ in self._dir.glob("*.json"))
        return {
            "hits": self._hits,
            "misses": self._misses,
            "hit_rate": (
                self._hits / (self._hits + self._misses)
                if (self._hits + self._misses) > 0
                else 0.0
            ),
            "entries": entry_count,
            "max_entries": self._max_entries,
            "ttl_seconds": self._ttl,
        }

    def _maybe_evict(self) -> None:
        """Evict oldest entries if at capacity."""
        entries = list(self._dir.glob("*.json"))
        if len(entries) < self._max_entries:
            return
        # Sort by modification time, remove oldest
        entries.sort(key=lambda p: p.stat().st_mtime)
        to_remove = len(entries) - self._max_entries + 1
        for path in entries[:to_remove]:
            path.unlink(missing_ok=True)
