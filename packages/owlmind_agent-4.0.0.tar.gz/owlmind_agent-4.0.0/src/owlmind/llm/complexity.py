"""Task Complexity Classifier — heuristic-based goal scoring (FS57)."""

from __future__ import annotations

from typing import Literal

# Keywords that strongly signal complexity level
_SIMPLE_KEYWORDS = frozenset(
    {
        "fix typo",
        "add comment",
        "rename",
        "update string",
        "change string",
        "fix comment",
        "update readme",
        "add docstring",
        "bump version",
        "add type hint",
        "add type hints",
        "fix lint",
        "fix linting",
        "remove unused",
        "format code",
        "fix formatting",
    }
)

_COMPLEX_KEYWORDS = frozenset(
    {
        "refactor",
        "migrate",
        "architect",
        "redesign",
        "security audit",
        "overhaul",
        "rewrite",
        "extract class",
        "extract module",
        "decompose",
        "large-scale",
        "breaking change",
        "add feature",
        "implement",
        "integrate",
        "create module",
        "create class",
        "add api",
        "add endpoint",
        "performance",
        "optimiz",
    }
)

# Provider preference lists per complexity
COMPLEXITY_PROVIDERS: dict[str, list[str]] = {
    "simple": ["anthropic"],
    "medium": ["anthropic", "openai"],
    "complex": ["openai", "anthropic"],
}

# Default model names per complexity level
# These can be overridden with env vars:
# OWLMIND_MODEL_SIMPLE, OWLMIND_MODEL_MEDIUM, OWLMIND_MODEL_COMPLEX
_DEFAULT_MODELS: dict[str, str] = {
    "simple": "deepseek-chat",   # cheap/fast for simple tasks
    "medium": "deepseek-chat",   # default
    "complex": "deepseek-chat",  # complex tasks (can override to gpt-4 etc)
}

Complexity = Literal["simple", "medium", "complex"]


def classify_goal(goal: str) -> Complexity:
    """Classify a goal as simple, medium, or complex using heuristics.

    Rules (in priority order):
    1. Contains complex keywords → "complex"
    2. Length ≥ 200 chars → "complex"
    3. Contains simple keywords → "simple"
    4. Length ≤ 50 chars → "simple"
    5. Everything else → "medium"

    Args:
        goal: Raw goal string from the user.

    Returns:
        One of ``"simple"``, ``"medium"``, ``"complex"``.
    """
    if not goal:
        return "simple"

    goal_lower = goal.lower()

    # Complex signals take highest priority
    for kw in _COMPLEX_KEYWORDS:
        if kw in goal_lower:
            return "complex"

    if len(goal) >= 200:
        return "complex"

    # Simple signals
    for kw in _SIMPLE_KEYWORDS:
        if kw in goal_lower:
            return "simple"

    if len(goal) <= 50:
        return "simple"

    return "medium"


def provider_for_complexity(complexity: Complexity) -> str | None:
    """Return the preferred provider for a given complexity level.

    Returns ``None`` for ``"medium"`` to avoid changing default routing.
    """
    if complexity == "medium":
        return None
    providers = COMPLEXITY_PROVIDERS.get(complexity, [])
    return providers[0] if providers else None


def model_for_complexity(complexity: Complexity) -> str | None:
    """Return the preferred model name for a given complexity level.

    Checks env vars OWLMIND_MODEL_SIMPLE/MEDIUM/COMPLEX first, then defaults.
    Returns None if the resolved model matches the current default (no routing needed).
    """
    import os
    env_key = f"OWLMIND_MODEL_{complexity.upper()}"
    model = os.environ.get(env_key, "").strip() or _DEFAULT_MODELS.get(complexity, "")
    return model or None
