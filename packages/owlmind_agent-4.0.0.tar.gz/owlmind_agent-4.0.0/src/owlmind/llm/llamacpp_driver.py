"""llama.cpp server LLM driver — uses the OpenAI-compatible HTTP API.

llama.cpp ``server`` exposes ``POST /v1/chat/completions`` with
OpenAI-compatible request/response format. No external SDK required.

Configuration via environment variables:
    LLAMACPP_BASE_URL  — API base URL (default: http://localhost:8080)
    LLAMACPP_MODEL     — model name sent in requests (default: default)
"""

from __future__ import annotations

import json
import logging
import time
import urllib.error
import urllib.request
from typing import Any

from owlmind.llm.prompts import build_judge_prompts, build_planner_prompts
from owlmind.llm.retry import with_retry

logger = logging.getLogger(__name__)


def is_llamacpp_available(base_url: str = "http://localhost:8080") -> bool:
    """Check if a llama.cpp server is reachable (best-effort)."""
    try:
        req = urllib.request.Request(
            f"{base_url}/health",
            method="GET",
        )
        with urllib.request.urlopen(req, timeout=2) as resp:
            return resp.status == 200  # type: ignore[union-attr]
    except Exception:
        return False


class LLamaCppDriver:
    """llama.cpp server LLM driver for Planner and Judge roles.

    Uses the OpenAI-compatible ``POST /v1/chat/completions`` endpoint.
    Supports ``response_format: {"type": "json_object"}`` for JSON mode.
    """

    def __init__(self, config: Any) -> None:
        self._config = config
        self._base = config.base_url.rstrip("/")

    @property
    def name(self) -> str:
        return "llamacpp"

    @property
    def supports_structured(self) -> bool:
        return False

    def _call(
        self,
        *,
        model: str,
        system_prompt: str,
        user_prompt: str,
        schema: dict[str, Any],
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Call llama.cpp /v1/chat/completions and return (parsed_json, meta)."""
        url = f"{self._base}/v1/chat/completions"

        # Instruct model to return valid JSON matching the schema
        schema_hint = json.dumps(schema, indent=2)
        augmented_system = (
            f"{system_prompt}\n\n"
            f"You MUST return a valid JSON object matching this schema:\n"
            f"```json\n{schema_hint}\n```\n"
            f"Return ONLY the JSON object, no extra text."
        )

        payload: dict[str, Any] = {
            "model": model,
            "messages": [
                {"role": "system", "content": augmented_system},
                {"role": "user", "content": user_prompt},
            ],
            "max_tokens": self._config.max_output_tokens,
            "response_format": {"type": "json_object"},
            "stream": False,
        }

        def _do_call() -> tuple[dict[str, Any], dict[str, Any]]:
            t0 = time.monotonic()
            body = json.dumps(payload).encode()
            req = urllib.request.Request(
                url,
                data=body,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=self._config.timeout_sec) as resp:
                raw = resp.read().decode()

            latency_ms = int((time.monotonic() - t0) * 1000)
            response = json.loads(raw)

            # OpenAI-compatible response format
            choices = response.get("choices", [])
            if not choices:
                msg = "llama.cpp returned no choices"
                raise RuntimeError(msg)

            content = choices[0].get("message", {}).get("content", "")
            parsed = json.loads(content)

            # Build meta
            meta: dict[str, Any] = {
                "provider": "llamacpp",
                "model": response.get("model", model),
                "response_id": response.get("id", ""),
                "latency_ms": latency_ms,
            }

            usage = response.get("usage")
            if usage:
                meta["usage"] = {
                    "input_tokens": usage.get("prompt_tokens", 0),
                    "output_tokens": usage.get("completion_tokens", 0),
                    "total_tokens": usage.get("total_tokens", 0),
                }

            return parsed, meta

        return with_retry(_do_call, provider="LLamaCpp")

    def plan(
        self,
        planner_request: dict[str, Any],
        schema: dict[str, Any],
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Call llama.cpp to generate a planner response."""
        system_prompt, user_prompt = build_planner_prompts(planner_request)
        return self._call(
            model=self._config.model,
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            schema=schema,
        )

    def judge(
        self,
        judge_request: dict[str, Any],
        schema: dict[str, Any],
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Call llama.cpp to generate a judge response."""
        system_prompt, user_prompt = build_judge_prompts(judge_request)
        return self._call(
            model=self._config.model,
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            schema=schema,
        )
