"""LLM driver factory — single place to build the LLMRouter from config."""

from __future__ import annotations

from typing import Any


def build_llm_router(
    cfg: Any,
    *,
    force_planner: str | None = None,
    force_judge: str | None = None,
) -> Any:
    """Build an LLMRouter from OwlMindConfig.

    Parameters
    ----------
    cfg:
        A OwlMindConfig instance (or duck-typed equivalent).
    force_planner:
        If set, only use this provider for planner calls.
    force_judge:
        If set, only use this provider for judge calls.

    Returns
    -------
    LLMRouter instance ready for plan()/judge() calls.

    Raises
    ------
    RuntimeError
        If no providers are available or a forced provider isn't available.
    """
    from owlmind.llm.router import LLMRouter

    drivers: dict[str, object] = {}

    from owlmind.llm.openai_driver import OpenAIDriver, is_openai_available

    if is_openai_available() and cfg.openai.enabled:
        drivers["openai"] = OpenAIDriver(cfg.openai)

    from owlmind.llm.anthropic_driver import AnthropicDriver, is_anthropic_available

    if is_anthropic_available() and cfg.anthropic.enabled:
        drivers["anthropic"] = AnthropicDriver(cfg.anthropic)

    from owlmind.llm.gemini_driver import GeminiDriver, is_gemini_available

    if is_gemini_available() and cfg.gemini.enabled:
        drivers["gemini"] = GeminiDriver(cfg.gemini)

    # Local LLM providers (no SDK import required)
    from owlmind.llm.ollama_driver import OllamaDriver

    if cfg.ollama.enabled:
        drivers["ollama"] = OllamaDriver(cfg.ollama)

    from owlmind.llm.llamacpp_driver import LLamaCppDriver

    if cfg.llamacpp.enabled:
        drivers["llamacpp"] = LLamaCppDriver(cfg.llamacpp)

    if not drivers:
        msg = "No LLM providers available. Set API key and install SDK."
        raise RuntimeError(msg)

    planner_providers = list(cfg.router.planner_providers)
    judge_providers = list(cfg.router.judge_providers)

    if force_planner:
        if force_planner not in drivers:
            msg = f"Planner provider '{force_planner}' not available. Available: {list(drivers.keys())}"
            raise RuntimeError(msg)
        planner_providers = [force_planner]

    if force_judge:
        if force_judge not in drivers:
            msg = f"Judge provider '{force_judge}' not available. Available: {list(drivers.keys())}"
            raise RuntimeError(msg)
        judge_providers = [force_judge]

    return LLMRouter(
        drivers=drivers,
        planner_providers=planner_providers,
        judge_providers=judge_providers,
    )
