"""OWLMIND diagnostics — build a redacted zip report for debugging."""

from __future__ import annotations

import json
import platform
import subprocess
import sys
import zipfile
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from owlmind import __version__
from owlmind.cli.config_cmd import _resolve_config
from owlmind.utils import redact_secrets


def _versions_text() -> str:
    """Gather environment version info."""
    lines = [
        f"owlmind:  {__version__}",
        f"python:   {sys.version}",
        f"platform: {platform.platform()}",
        f"os:       {platform.system()} {platform.release()}",
        f"arch:     {platform.machine()}",
        f"time:     {datetime.now(tz=UTC).isoformat()}",
    ]
    return "\n".join(lines)


def _run_doctor() -> str:
    """Run owlmind doctor and capture output (redacted)."""
    try:
        result = subprocess.run(
            [sys.executable, "-m", "owlmind", "doctor"],
            capture_output=True,
            text=True,
            timeout=30,
        )
        output = result.stdout + result.stderr
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        output = "(doctor command failed or timed out)"
    return redact_secrets(output)


def _run_security_scan(workspace: Path) -> str:
    """Run owlmind security scan and capture output (redacted)."""
    try:
        result = subprocess.run(
            [sys.executable, "-m", "owlmind", "security", "scan", "--path", str(workspace)],
            capture_output=True,
            text=True,
            timeout=30,
        )
        output = result.stdout + result.stderr
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        output = "(security scan failed or timed out)"
    return redact_secrets(output)


def _recent_runs(runs_dir: Path, limit: int = 10) -> list[dict[str, Any]]:
    """Collect summary metadata from recent runs (no full logs)."""
    summaries: list[dict[str, Any]] = []
    if not runs_dir.is_dir():
        return summaries

    run_dirs = sorted(runs_dir.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True)
    for rd in run_dirs[:limit]:
        meta_path = rd / "cycle_meta.json"
        if meta_path.exists():
            try:
                meta = json.loads(meta_path.read_text())
                summaries.append(
                    {
                        "run_id": meta.get("run_id", rd.name),
                        "state": meta.get("state", "?"),
                        "goal": meta.get("goal", "")[:120],
                        "iteration": meta.get("iteration"),
                        "updated_at": meta.get("updated_at", ""),
                    }
                )
            except (json.JSONDecodeError, OSError):
                summaries.append({"run_id": rd.name, "state": "unreadable"})
    return summaries


def _recent_sessions(sessions_dir: Path, limit: int = 10) -> list[dict[str, Any]]:
    """Collect summary metadata from recent sessions."""
    summaries: list[dict[str, Any]] = []
    if not sessions_dir.is_dir():
        return summaries

    session_dirs = sorted(sessions_dir.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True)
    for sd in session_dirs[:limit]:
        meta_path = sd / "session_meta.json"
        if meta_path.exists():
            try:
                meta = json.loads(meta_path.read_text())
                summaries.append(
                    {
                        "session_id": meta.get("session_id", sd.name),
                        "status": meta.get("status", "?"),
                        "goals_total": meta.get("goals_total"),
                        "goals_done": meta.get("goals_done"),
                    }
                )
            except (json.JSONDecodeError, OSError):
                summaries.append({"session_id": sd.name, "status": "unreadable"})
    return summaries


def build_diag_report(
    workspace: Path,
    *,
    out_zip: Path | None = None,
    include_recent: int = 10,
) -> Path:
    """Build a redacted diagnostic zip report.

    Args:
        workspace: Project workspace root.
        out_zip: Output zip path (default: reports/owlmind_diag_<ts>.zip).
        include_recent: Number of recent runs/sessions to include.

    Returns:
        Path to the created zip file.
    """
    if out_zip is None:
        ts = datetime.now(tz=UTC).strftime("%Y%m%dT%H%M%S")
        reports_dir = workspace / "reports"
        reports_dir.mkdir(parents=True, exist_ok=True)
        out_zip = reports_dir / f"owlmind_diag_{ts}.zip"
    else:
        out_zip.parent.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(out_zip, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        # 1. Versions
        zf.writestr("versions.txt", _versions_text())

        # 2. Resolved config (redacted)
        config_data = _resolve_config()
        zf.writestr("config_resolved.json", json.dumps(config_data, indent=2, default=str))

        # 3. Doctor output
        zf.writestr("doctor.txt", _run_doctor())

        # 4. Security scan
        zf.writestr("security_scan.txt", _run_security_scan(workspace))

        # 5. Recent runs
        runs_dir = workspace / "runs"
        runs = _recent_runs(runs_dir, limit=include_recent)
        zf.writestr("recent_runs.json", json.dumps(runs, indent=2))

        # 6. Recent sessions
        sessions_dir = workspace / "sessions"
        sessions = _recent_sessions(sessions_dir, limit=include_recent)
        zf.writestr("recent_sessions.json", json.dumps(sessions, indent=2))

        # 7. Notes
        notes = [
            "# OWLMIND Diagnostic Report",
            "",
            "This report was generated with `owlmind diag report`.",
            "All secrets have been redacted.",
            "",
            "## Next steps",
            "",
            "- Review doctor.txt for health check issues",
            "- Review security_scan.txt for security findings",
            "- Check config_resolved.json for misconfigurations",
            "- Share this zip when reporting issues",
        ]
        zf.writestr("notes.md", "\n".join(notes))

    return out_zip
