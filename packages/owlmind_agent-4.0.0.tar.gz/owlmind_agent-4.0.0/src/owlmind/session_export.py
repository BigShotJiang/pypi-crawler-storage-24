"""Session export — create a zip bundle of session + run artifacts."""

from __future__ import annotations

import zipfile
from pathlib import Path

from owlmind.session import (
    append_session_event,
    load_session,
)


def export_session(
    session_id: str,
    sessions_dir: Path,
    runs_dir: Path,
    *,
    out_path: Path | None = None,
) -> Path:
    """Export session as a zip bundle.

    Includes: session_meta.json, session.jsonl, goals_resolved.yaml,
    protocol.md, and per-run artifacts (cycle_meta.json, summary.json,
    pr_pack.md, run.jsonl, evidence manifest).
    """
    meta = load_session(session_id, sessions_dir)
    sdir = sessions_dir / session_id

    if out_path is None:
        out_path = sdir / "exports" / f"session_export_{session_id}.zip"

    # Safety: ensure export path stays within sessions/<id>/exports
    allowed_parent = sdir / "exports"
    resolved = out_path.resolve()
    if not str(resolved).startswith(str(allowed_parent.resolve())):
        msg = f"Export path must be inside {allowed_parent}, got: {out_path}"
        raise ValueError(msg)

    out_path.parent.mkdir(parents=True, exist_ok=True)

    # Session-level files to include
    session_files = [
        "session_meta.json",
        "session.jsonl",
        "goals_resolved.yaml",
        "protocol.md",
    ]

    # Per-run files to include
    run_files = [
        "cycle_meta.json",
        "summary.json",
        "pr_pack.md",
        "run.jsonl",
    ]

    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as zf:
        # Session files
        for fname in session_files:
            fpath = sdir / fname
            if fpath.exists():
                zf.write(fpath, f"{session_id}/{fname}")

        # Per-run artifacts
        for run_info in meta.runs:
            run_dir = runs_dir / run_info.run_id
            if not run_dir.exists():
                continue

            for fname in run_files:
                fpath = run_dir / fname
                if fpath.exists():
                    zf.write(fpath, f"{session_id}/runs/{run_info.run_id}/{fname}")

            # Evidence manifest
            manifest = run_dir / "evidence" / "manifest.json"
            if manifest.exists():
                zf.write(
                    manifest,
                    f"{session_id}/runs/{run_info.run_id}/evidence/manifest.json",
                )

            # Include existing export zip reference (not nested zip)
            # Just note its existence
            for export_zip in run_dir.glob("owlmind_export_*.zip"):
                zf.writestr(
                    f"{session_id}/runs/{run_info.run_id}/export_ref.txt",
                    f"Run export available: {export_zip}\n",
                )
                break

    # Record event
    append_session_event(
        session_id,
        sessions_dir,
        {
            "event": "SESSION_EXPORT_CREATED",
            "path": str(out_path),
            "size_bytes": out_path.stat().st_size,
        },
    )

    return out_path
