"""EvidenceStore — append-only evidence storage with SHA-256 hash chain."""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from owlmind.utils import sha256

_CHAIN_FIELDS = {"_hash", "_prev_hash", "_seq"}
_GENESIS_HASH = "0" * 64

EVIDENCE_SCHEMA_VERSION = "1"

_log = logging.getLogger(__name__)


def canonical_json(obj: dict[str, Any]) -> bytes:
    """Produce stable canonical JSON bytes for hashing."""
    return json.dumps(
        obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str
    ).encode()


@dataclass
class ChainVerifyResult:
    """Result of verifying an evidence chain."""

    ok: bool
    errors: list[str] = field(default_factory=list)
    tip_hash: str = ""
    seq: int = 0


class EvidenceStore:
    """Append-only evidence storage with hash-chain integrity.

    Each orchestrator run gets a directory under *base_dir*::

        runs/<run_id>/
            run.jsonl          # hash-chained event log (append-only)
            meta.json          # run metadata
            summary.json       # final summary
            artifacts/         # binary / text artefacts
            evidence/
                manifest.json  # artifact manifest with SHA-256 hashes
    """

    def __init__(self, base_dir: str | Path) -> None:
        self.base_dir = Path(base_dir)
        self.base_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Run lifecycle
    # ------------------------------------------------------------------

    def create_run(self, run_id: str) -> Path:
        """Create a new run directory and return its path."""
        run_dir = self.base_dir / run_id
        run_dir.mkdir(parents=True, exist_ok=True)
        (run_dir / "artifacts").mkdir(exist_ok=True)
        return run_dir

    def get_chain_tip(self, run_id: str) -> tuple[str, int]:
        """Return ``(tip_hash, seq)`` from the last event, or genesis values."""
        log_path = self.base_dir / run_id / "run.jsonl"
        if not log_path.exists():
            return _GENESIS_HASH, 0
        last_line = ""
        for line in log_path.read_text().splitlines():
            if line.strip():
                last_line = line
        if not last_line:
            return _GENESIS_HASH, 0
        last_event: dict[str, Any] = json.loads(last_line)
        return (
            str(last_event.get("_hash", _GENESIS_HASH)),
            int(last_event.get("_seq", 0)),
        )

    def append_event(self, run_id: str, event: dict[str, Any]) -> str:
        """Append a hash-chained JSON event to the run log. Returns event hash."""
        run_dir = self.base_dir / run_id
        run_dir.mkdir(parents=True, exist_ok=True)

        prev_hash, prev_seq = self.get_chain_tip(run_id)
        seq = prev_seq + 1

        event_payload: dict[str, Any] = {
            "_schema_version": EVIDENCE_SCHEMA_VERSION,
            "timestamp": datetime.now(tz=UTC).isoformat(),
            **{k: v for k, v in event.items() if k not in _CHAIN_FIELDS},
        }

        canon = canonical_json(event_payload)
        event_hash = sha256(prev_hash.encode() + b"\n" + canon)

        chained_event: dict[str, Any] = {
            **event_payload,
            "_seq": seq,
            "_prev_hash": prev_hash,
            "_hash": event_hash,
        }

        log_path = run_dir / "run.jsonl"
        with log_path.open("a") as f:
            f.write(json.dumps(chained_event, default=str) + "\n")

        return event_hash

    # ------------------------------------------------------------------
    # Artefacts
    # ------------------------------------------------------------------

    def write_artifact(self, run_id: str, filename: str, content: str | bytes) -> str:
        """Write an artefact file and return its SHA-256 hash."""
        run_dir = self.base_dir / run_id
        art_dir = run_dir / "artifacts"
        art_dir.mkdir(parents=True, exist_ok=True)

        data = content.encode() if isinstance(content, str) else content
        path = art_dir / filename
        path.write_bytes(data)
        return sha256(data)

    # ------------------------------------------------------------------
    # Evidence manifest
    # ------------------------------------------------------------------

    def write_manifest(self, run_id: str) -> dict[str, Any]:
        """Write ``evidence/manifest.json`` listing all artifacts with SHA-256 hashes."""
        run_dir = self.base_dir / run_id
        art_dir = run_dir / "artifacts"
        evidence_dir = run_dir / "evidence"
        evidence_dir.mkdir(parents=True, exist_ok=True)

        artifacts: list[dict[str, Any]] = []
        if art_dir.exists():
            for p in sorted(art_dir.iterdir()):
                if p.is_file():
                    data = p.read_bytes()
                    kind = (
                        "text"
                        if p.suffix in (".txt", ".md", ".json", ".yaml", ".patch")
                        else "binary"
                    )
                    artifacts.append(
                        {
                            "name": p.name,
                            "path": f"artifacts/{p.name}",
                            "sha256": sha256(data),
                            "bytes": len(data),
                            "kind": kind,
                        }
                    )

        manifest_body: dict[str, Any] = {
            "run_id": run_id,
            "created_at": datetime.now(tz=UTC).isoformat(),
            "artifact_count": len(artifacts),
            "artifacts": artifacts,
        }

        manifest_hash = sha256(canonical_json(manifest_body))
        manifest_body["manifest_sha256"] = manifest_hash

        manifest_path = evidence_dir / "manifest.json"
        manifest_path.write_text(json.dumps(manifest_body, indent=2, default=str))

        self.append_event(
            run_id,
            {
                "event": "MANIFEST_WRITTEN",
                "manifest_sha256": manifest_hash,
                "artifact_count": len(artifacts),
            },
        )

        return manifest_body

    # ------------------------------------------------------------------
    # Chain verification
    # ------------------------------------------------------------------

    def verify_chain(self, run_id: str) -> ChainVerifyResult:
        """Verify the hash chain integrity of ``run.jsonl``."""
        log_path = self.base_dir / run_id / "run.jsonl"
        if not log_path.exists():
            return ChainVerifyResult(ok=False, errors=["run.jsonl not found"])

        errors: list[str] = []
        prev_hash = _GENESIS_HASH
        last_hash = _GENESIS_HASH
        last_seq = 0

        for i, line in enumerate(log_path.read_text().splitlines(), 1):
            if not line.strip():
                continue
            try:
                event: dict[str, Any] = json.loads(line)
            except json.JSONDecodeError as exc:
                errors.append(f"Line {i}: invalid JSON: {exc}")
                continue

            stored_hash = str(event.get("_hash", ""))
            stored_prev = str(event.get("_prev_hash", ""))
            stored_seq = int(event.get("_seq", 0))
            stored_schema = event.get("_schema_version")

            if not stored_hash:
                errors.append(f"Line {i}: missing _hash field")
                continue

            if stored_seq != last_seq + 1:
                errors.append(f"Line {i}: expected _seq={last_seq + 1}, got {stored_seq}")

            if stored_prev != prev_hash:
                errors.append(
                    f"Line {i}: _prev_hash mismatch "
                    f"(expected {prev_hash[:16]}..., got {stored_prev[:16]}...)"
                )

            # Backward compat: skip hash re-computation for legacy events that
            # lack _schema_version or use an unknown schema version.
            if stored_schema != EVIDENCE_SCHEMA_VERSION:
                _log.warning(
                    "Line %d: _schema_version=%r does not match current %r — "
                    "skipping hash verification (legacy event)",
                    i,
                    stored_schema,
                    EVIDENCE_SCHEMA_VERSION,
                )
            else:
                payload = {k: v for k, v in event.items() if k not in _CHAIN_FIELDS}
                canon = canonical_json(payload)
                expected_hash = sha256(stored_prev.encode() + b"\n" + canon)

                if stored_hash != expected_hash:
                    errors.append(
                        f"Line {i}: _hash mismatch "
                        f"(expected {expected_hash[:16]}..., got {stored_hash[:16]}...)"
                    )

            prev_hash = stored_hash
            last_hash = stored_hash
            last_seq = stored_seq

        return ChainVerifyResult(
            ok=len(errors) == 0,
            errors=errors,
            tip_hash=last_hash,
            seq=last_seq,
        )

    # ------------------------------------------------------------------
    # Metadata
    # ------------------------------------------------------------------

    def write_meta(self, run_id: str, meta: dict[str, Any]) -> None:
        """Write run metadata (overwrite)."""
        run_dir = self.base_dir / run_id
        run_dir.mkdir(parents=True, exist_ok=True)
        (run_dir / "meta.json").write_text(json.dumps(meta, indent=2, default=str))

    def write_summary(self, run_id: str, summary: dict[str, Any]) -> None:
        """Write run summary (overwrite)."""
        run_dir = self.base_dir / run_id
        run_dir.mkdir(parents=True, exist_ok=True)
        (run_dir / "summary.json").write_text(json.dumps(summary, indent=2, default=str))

    # ------------------------------------------------------------------
    # Reading
    # ------------------------------------------------------------------

    def read_events(self, run_id: str) -> list[dict[str, Any]]:
        """Read all events from a run log."""
        log_path = self.base_dir / run_id / "run.jsonl"
        if not log_path.exists():
            return []
        events: list[dict[str, Any]] = []
        for line in log_path.read_text().splitlines():
            if line.strip():
                events.append(json.loads(line))
        return events

    def read_meta(self, run_id: str) -> dict[str, Any]:
        """Read run metadata."""
        meta_path = self.base_dir / run_id / "meta.json"
        if not meta_path.exists():
            return {}
        return json.loads(meta_path.read_text())  # type: ignore[no-any-return]

    def read_summary(self, run_id: str) -> dict[str, Any]:
        """Read run summary."""
        summary_path = self.base_dir / run_id / "summary.json"
        if not summary_path.exists():
            return {}
        return json.loads(summary_path.read_text())  # type: ignore[no-any-return]

    def list_runs(self) -> list[str]:
        """List all run IDs (directory names)."""
        if not self.base_dir.exists():
            return []
        return sorted(
            d.name for d in self.base_dir.iterdir() if d.is_dir() and (d / "run.jsonl").exists()
        )
