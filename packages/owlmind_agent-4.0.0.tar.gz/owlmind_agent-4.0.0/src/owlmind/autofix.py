"""AutoFix — automatically fix CI failures by running GraphRunner."""
from __future__ import annotations

import logging
import subprocess
from dataclasses import dataclass

logger = logging.getLogger(__name__)

try:
    from owlmind.graph.runner import GraphRunner, _build_llm_client
except Exception:
    GraphRunner = None  # type: ignore[assignment,misc]
    _build_llm_client = None  # type: ignore[assignment]


@dataclass
class AutoFixResult:
    success: bool
    verdict: str
    branch: str
    pr_url: str
    error: str = ""
    committed: bool = False
    pushed: bool = False


def run_autofix(
    *,
    goal: str,
    workspace: str,
    branch: str,
    pr_url: str,
    auto_commit: bool = True,
    auto_push: bool = False,  # False by default — don't push without explicit opt-in
) -> AutoFixResult:
    """Run GraphRunner to fix a CI failure, optionally commit and push.

    Args:
        goal: What to fix (e.g. "Fix failing CI: mypy error in auth.py")
        workspace: Path to the git repo
        branch: Branch name to commit on
        pr_url: PR URL for context
        auto_commit: Whether to git commit fixed files
        auto_push: Whether to git push (default False — safer)
    """
    if GraphRunner is None or _build_llm_client is None:
        return AutoFixResult(success=False, verdict="error", branch=branch,
                             pr_url=pr_url, error="Import error: owlmind.graph.runner unavailable")

    if _build_llm_client() is None:
        return AutoFixResult(success=False, verdict="no_llm", branch=branch,
                             pr_url=pr_url, error="No LLM configured")

    try:
        runner = GraphRunner()
        state = runner.run(goal, workspace=workspace, max_iterations=3)
        verdict = state.final_verdict or "unknown"
        committed = False
        pushed = False

        if auto_commit and state.code_changes:
            committed = _git_commit(workspace, goal)
        if auto_push and committed:
            pushed = _git_push(workspace, branch)

        return AutoFixResult(
            success=verdict == "APPROVED",
            verdict=verdict,
            branch=branch,
            pr_url=pr_url,
            committed=committed,
            pushed=pushed,
        )
    except Exception as e:
        logger.error("AutoFix failed: %s", e)
        return AutoFixResult(success=False, verdict="error", branch=branch,
                             pr_url=pr_url, error=str(e))


def _git_commit(workspace: str, goal: str) -> bool:
    """Stage all changes and commit with auto-fix message."""
    try:
        subprocess.run(["git", "add", "-A"], cwd=workspace, check=True, capture_output=True)
        msg = f"chore: auto-fix CI failure\n\nGoal: {goal[:200]}\n\n[owlmind autofix]"
        subprocess.run(["git", "commit", "-m", msg], cwd=workspace, check=True, capture_output=True)
        return True
    except subprocess.CalledProcessError:
        return False


def _git_push(workspace: str, branch: str) -> bool:
    """Push current branch to origin."""
    try:
        subprocess.run(["git", "push", "origin", branch], cwd=workspace,
                       check=True, capture_output=True)
        return True
    except subprocess.CalledProcessError:
        return False
