"""Cost/usage reports generated from the JSONL usage ledger."""

from __future__ import annotations

import json
import logging
from datetime import UTC, date, datetime, timedelta
from pathlib import Path
from typing import Any

from owlmind.ledger import UsageEntry, UsageLedger

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _today_str() -> str:
    """Return today's date as YYYY-MM-DD string (UTC)."""
    return datetime.now(tz=UTC).date().isoformat()


def _entries_for_date(ledger: UsageLedger, day_str: str) -> list[UsageEntry]:
    """Return entries whose timestamp starts with *day_str* (YYYY-MM-DD)."""
    return [e for e in ledger._read_all() if e.ts.startswith(day_str)]


def _entries_in_range(
    ledger: UsageLedger,
    start: date,
    end: date,
) -> list[UsageEntry]:
    """Return entries within [start, end] inclusive."""
    all_entries = ledger._read_all()
    start_str = start.isoformat()
    end_str = end.isoformat()
    return [e for e in all_entries if start_str <= e.ts[:10] <= end_str]


def _aggregate_entries(
    entries: list[UsageEntry],
) -> dict[str, Any]:
    """Aggregate entries into by_provider / by_model / totals."""
    total_tokens = 0
    total_usd = 0.0
    by_provider: dict[str, dict[str, Any]] = {}
    by_model: dict[str, dict[str, Any]] = {}

    for e in entries:
        total_tokens += e.total_tokens
        total_usd += e.estimated_usd

        # by provider
        prov = by_provider.setdefault(
            e.provider,
            {"tokens": 0, "usd": 0.0, "calls": 0},
        )
        prov["tokens"] += e.total_tokens
        prov["usd"] += e.estimated_usd
        prov["calls"] += 1

        # by model
        mdl = by_model.setdefault(
            e.model,
            {"tokens": 0, "usd": 0.0, "calls": 0},
        )
        mdl["tokens"] += e.total_tokens
        mdl["usd"] += e.estimated_usd
        mdl["calls"] += 1

    return {
        "total_tokens": total_tokens,
        "total_usd": round(total_usd, 6),
        "by_provider": by_provider,
        "by_model": by_model,
    }


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def daily_report(
    ledger_dir: Path,
    date: str | None = None,
) -> dict[str, Any]:
    """Return a cost/usage summary for a single day.

    Args:
        ledger_dir: Path to the directory containing ``usage.jsonl``.
        date: Optional date string (YYYY-MM-DD). Defaults to today (UTC).

    Returns:
        dict with keys: ``date``, ``total_tokens``, ``total_usd``,
        ``by_provider``, ``by_model``.
    """
    day_str = date or _today_str()
    ledger = UsageLedger(ledger_dir)
    entries = _entries_for_date(ledger, day_str)
    agg = _aggregate_entries(entries)

    logger.debug("daily_report: date=%s entries=%d", day_str, len(entries))

    return {
        "date": day_str,
        **agg,
    }


def weekly_report(ledger_dir: Path) -> dict[str, Any]:
    """Return a cost/usage summary for the last 7 days.

    Returns:
        dict with keys: ``period``, ``days`` (list of daily summaries),
        ``totals`` (aggregated).
    """
    today = datetime.now(tz=UTC).date()
    start = today - timedelta(days=6)
    ledger = UsageLedger(ledger_dir)
    all_entries = _entries_in_range(ledger, start, today)

    days: list[dict[str, Any]] = []
    for offset in range(7):
        day = start + timedelta(days=offset)
        day_str = day.isoformat()
        day_entries = [e for e in all_entries if e.ts.startswith(day_str)]
        day_agg = _aggregate_entries(day_entries)
        days.append({"date": day_str, **day_agg})

    totals = _aggregate_entries(all_entries)

    logger.debug(
        "weekly_report: %s..%s entries=%d",
        start.isoformat(),
        today.isoformat(),
        len(all_entries),
    )

    return {
        "period": f"{start.isoformat()} .. {today.isoformat()}",
        "days": days,
        "totals": totals,
    }


def monthly_report(ledger_dir: Path) -> dict[str, Any]:
    """Return a cost/usage summary for the current calendar month.

    Returns:
        dict with keys: ``period``, ``total_tokens``, ``total_usd``,
        ``by_provider``, ``by_day`` (date -> totals).
    """
    today = datetime.now(tz=UTC).date()
    month_start = today.replace(day=1)
    ledger = UsageLedger(ledger_dir)
    all_entries = _entries_in_range(ledger, month_start, today)

    agg = _aggregate_entries(all_entries)

    by_day: dict[str, dict[str, Any]] = {}
    for e in all_entries:
        day_str = e.ts[:10]
        day_agg = by_day.setdefault(
            day_str,
            {"total_tokens": 0, "total_usd": 0.0, "calls": 0},
        )
        day_agg["total_tokens"] += e.total_tokens
        day_agg["total_usd"] += e.estimated_usd
        day_agg["calls"] += 1

    # Round per-day USD
    for v in by_day.values():
        v["total_usd"] = round(v["total_usd"], 6)

    logger.debug(
        "monthly_report: %s..%s entries=%d",
        month_start.isoformat(),
        today.isoformat(),
        len(all_entries),
    )

    return {
        "period": f"{month_start.isoformat()} .. {today.isoformat()}",
        "total_tokens": agg["total_tokens"],
        "total_usd": agg["total_usd"],
        "by_provider": agg["by_provider"],
        "by_day": by_day,
    }


def provider_breakdown(ledger_dir: Path) -> list[dict[str, Any]]:
    """Return a sorted list of providers by total cost (descending).

    Each entry: ``{provider, model, tokens, usd, calls, pct}``.
    """
    ledger = UsageLedger(ledger_dir)
    all_entries = ledger._read_all()

    # Group by (provider, model)
    groups: dict[tuple[str, str], dict[str, Any]] = {}
    grand_total_usd = 0.0
    for e in all_entries:
        key = (e.provider, e.model)
        g = groups.setdefault(key, {"tokens": 0, "usd": 0.0, "calls": 0})
        g["tokens"] += e.total_tokens
        g["usd"] += e.estimated_usd
        g["calls"] += 1
        grand_total_usd += e.estimated_usd

    result: list[dict[str, Any]] = []
    for (provider, model), stats in groups.items():
        pct = (stats["usd"] / grand_total_usd * 100) if grand_total_usd > 0 else 0.0
        result.append(
            {
                "provider": provider,
                "model": model,
                "tokens": stats["tokens"],
                "usd": round(stats["usd"], 6),
                "calls": stats["calls"],
                "pct": round(pct, 1),
            }
        )

    result.sort(key=lambda r: r["usd"], reverse=True)

    logger.debug("provider_breakdown: %d groups from %d entries", len(result), len(all_entries))
    return result


# ---------------------------------------------------------------------------
# Formatters
# ---------------------------------------------------------------------------


def format_report_text(report: dict[str, Any]) -> str:
    """Format any report dict as human-readable plain text."""
    lines: list[str] = []

    # Header line — date or period
    if "date" in report:
        lines.append(f"=== Cost Report: {report['date']} ===")
    elif "period" in report:
        lines.append(f"=== Cost Report: {report['period']} ===")
    else:
        lines.append("=== Cost Report ===")

    # Top-level totals
    if "total_tokens" in report:
        lines.append(f"Total tokens: {report['total_tokens']:,}")
    if "total_usd" in report:
        lines.append(f"Total cost:   ${report['total_usd']:.4f}")

    # by_provider
    if "by_provider" in report:
        lines.append("")
        lines.append("By provider:")
        for prov, stats in report["by_provider"].items():
            lines.append(
                f"  {prov}: {stats['tokens']:,} tokens, ${stats['usd']:.4f}, {stats['calls']} calls"
            )

    # by_model
    if "by_model" in report:
        lines.append("")
        lines.append("By model:")
        for model, stats in report["by_model"].items():
            lines.append(
                f"  {model}: {stats['tokens']:,} tokens, "
                f"${stats['usd']:.4f}, {stats['calls']} calls"
            )

    # by_day (monthly)
    if "by_day" in report:
        lines.append("")
        lines.append("By day:")
        for day_str in sorted(report["by_day"]):
            d = report["by_day"][day_str]
            lines.append(
                f"  {day_str}: {d['total_tokens']:,} tokens, "
                f"${d['total_usd']:.4f}, {d['calls']} calls"
            )

    # days (weekly)
    if "days" in report:
        lines.append("")
        lines.append("Daily breakdown:")
        for day in report["days"]:
            lines.append(
                f"  {day['date']}: {day['total_tokens']:,} tokens, ${day['total_usd']:.4f}"
            )

    # totals block (weekly)
    if "totals" in report:
        t = report["totals"]
        lines.append("")
        lines.append(f"Week totals: {t['total_tokens']:,} tokens, ${t['total_usd']:.4f}")

    return "\n".join(lines)


def format_report_json(report: dict[str, Any]) -> str:
    """Format any report dict as a JSON string."""
    return json.dumps(report, indent=2, default=str)
