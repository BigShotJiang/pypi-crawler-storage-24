"""Web dashboard for owlmind runs.

Start with: owlmind web serve [--port 8080] [--host 0.0.0.0]
"""
from __future__ import annotations

import contextlib
import json
from pathlib import Path
from typing import Any

from fastapi import FastAPI
from fastapi.responses import JSONResponse

from owlmind.web.analytics import router as analytics_router
from owlmind.web.pages import router as pages_router

# Backward compat: tests patch owlmind.web.app._get_runs_dir
from owlmind.web.runs import _get_runs_dir
from owlmind.web.runs import router as runs_router

app = FastAPI(title="OwlMind Dashboard", version="1.0")

# -- Include routers ----------------------------------------------------------
app.include_router(runs_router)
app.include_router(analytics_router)
app.include_router(pages_router)


# -- Inline lightweight routes ------------------------------------------------

@app.get("/health")
def health() -> JSONResponse:
    """Health check endpoint for Railway and other uptime monitors."""
    return JSONResponse(content={"status": "ok", "version": "0.1.0"})


@app.get("/api/status")
def status() -> JSONResponse:
    """System status — version, config summary."""
    try:
        from owlmind import __version__
        version = __version__
    except Exception:
        version = "unknown"

    runs_dir = _get_runs_dir()
    run_count: int | None = None
    if runs_dir is not None:
        with contextlib.suppress(Exception):
            run_count = sum(1 for d in runs_dir.iterdir() if d.is_dir())

    schedule: dict[str, Any] | None = None
    schedule_file = Path.home() / "owlmind" / "schedule.json"
    if schedule_file.exists():
        with contextlib.suppress(Exception):
            schedule = json.loads(schedule_file.read_text())

    return JSONResponse(content={
        "status": "ok",
        "version": version,
        "runs_dir": str(runs_dir) if runs_dir else None,
        "total_runs": run_count,
        "schedule": schedule,
    })
