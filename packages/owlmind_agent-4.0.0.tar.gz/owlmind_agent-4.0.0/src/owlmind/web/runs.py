"""Run-related API routes for the OwlMind web dashboard."""
from __future__ import annotations

import asyncio
import contextlib
import json
import subprocess
from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException
from fastapi.responses import JSONResponse, StreamingResponse

router = APIRouter(tags=["runs"])


def _get_runs_dir() -> Path | None:
    """Return the runs directory path if it can be determined."""
    # Try standard owlmind data directories
    candidates = [
        Path.home() / "owlmind" / "runs",
        Path.home() / ".owlmind" / "runs",
        Path(".owlmind") / "runs",
        Path("runs"),
    ]
    for p in candidates:
        if p.exists() and p.is_dir():
            return p
    return None


def _read_meta(run_dir: Path) -> dict[str, Any]:
    """Read cycle_meta.json (or meta.json) for a run directory."""
    for name in ("cycle_meta.json", "meta.json"):
        meta_path = run_dir / name
        if meta_path.exists():
            try:
                return json.loads(meta_path.read_text())
            except Exception:
                pass
    return {}


def _read_events(run_dir: Path) -> list[dict[str, Any]]:
    """Read events from run.jsonl."""
    log_path = run_dir / "run.jsonl"
    if not log_path.exists():
        return []
    events: list[dict[str, Any]] = []
    try:
        for line in log_path.read_text().splitlines():
            line = line.strip()
            if line:
                with contextlib.suppress(Exception):
                    events.append(json.loads(line))
    except Exception:
        pass
    return events


def _run_summary(run_dir: Path) -> dict[str, Any]:
    """Build a summary dict for a run directory."""
    run_id = run_dir.name
    meta = _read_meta(run_dir)
    events = _read_events(run_dir)

    # Determine state from last event or meta
    state = meta.get("state") or meta.get("status") or "unknown"
    goal = meta.get("goal") or meta.get("objective") or ""
    started_at = meta.get("started_at") or meta.get("created_at") or ""

    # Extract additional fields
    cost_summary = meta.get("cost_summary", "") or meta.get("cost", "")
    pr_url = meta.get("pr_url", "")
    iterations = meta.get("iteration", meta.get("iterations", 0))

    # Try to get cost from LLM_USAGE_RECORDED events
    if not cost_summary:
        total_tokens = 0
        total_usd = 0.0
        for evt in events:
            if evt.get("event") == "LLM_USAGE_RECORDED":
                total_tokens += evt.get("total_tokens", 0)
                total_usd += evt.get("estimated_usd", 0.0)
        if total_tokens > 0:
            cost_summary = f"{total_tokens:,} tok | ~${total_usd:.4f}"

    # Infer state from events if not in meta
    if state == "unknown" and events:
        last_event = events[-1]
        evt_type = last_event.get("event", "")
        if "DONE" in evt_type or "COMPLETE" in evt_type or "FINISHED" in evt_type:
            state = "done"
        elif "FAIL" in evt_type or "ERROR" in evt_type:
            state = "failed"
        elif events:
            state = "running"

    # Infer started_at from first event timestamp
    if not started_at and events:
        started_at = events[0].get("timestamp", "")

    return {
        "run_id": run_id,
        "goal": goal,
        "state": state,
        "started_at": started_at,
        "event_count": len(events),
        "cost_summary": cost_summary,
        "pr_url": pr_url,
        "iterations": iterations,
    }


@router.get("/api/runs")
def list_runs(limit: int = 50) -> JSONResponse:
    """List recent runs with status, goal, timestamps."""
    runs_dir = _get_runs_dir()
    if runs_dir is None:
        return JSONResponse(content=[])

    try:
        run_dirs = sorted(
            [d for d in runs_dir.iterdir() if d.is_dir()],
            key=lambda d: d.stat().st_mtime,
            reverse=True,
        )[:limit]
    except Exception:
        return JSONResponse(content=[])

    results = [_run_summary(d) for d in run_dirs]
    return JSONResponse(content=results)


@router.get("/api/runs/{run_id}")
def get_run(run_id: str) -> JSONResponse:
    """Get details for a specific run including events."""
    runs_dir = _get_runs_dir()
    if runs_dir is None:
        raise HTTPException(status_code=404, detail=f"Run '{run_id}' not found")

    run_dir = runs_dir / run_id
    if not run_dir.exists() or not run_dir.is_dir():
        raise HTTPException(status_code=404, detail=f"Run '{run_id}' not found")

    summary = _run_summary(run_dir)
    events = _read_events(run_dir)
    meta = _read_meta(run_dir)

    return JSONResponse(content={
        **summary,
        "meta": meta,
        "events": events,
    })


@router.get("/api/runs/{run_id}/cost")
def run_cost(run_id: str) -> JSONResponse:
    """Return cost breakdown for a specific run from LLM_USAGE_RECORDED events."""
    runs_dir = _get_runs_dir()
    if runs_dir is None:
        return JSONResponse(content={"error": "runs directory not found"}, status_code=404)

    run_dir = runs_dir / run_id
    if not run_dir.exists():
        return JSONResponse(content={"error": "run not found"}, status_code=404)

    events = _read_events(run_dir)
    usage_events = [e for e in events if e.get("event") == "LLM_USAGE_RECORDED"]

    total_tokens = sum(e.get("total_tokens", 0) for e in usage_events)
    total_usd = sum(e.get("estimated_usd", 0.0) for e in usage_events)
    by_stage: dict[str, dict] = {}
    for e in usage_events:
        stage = e.get("stage", "unknown")
        if stage not in by_stage:
            by_stage[stage] = {"tokens": 0, "usd": 0.0, "calls": 0}
        by_stage[stage]["tokens"] += e.get("total_tokens", 0)
        by_stage[stage]["usd"] += e.get("estimated_usd", 0.0)
        by_stage[stage]["calls"] += 1

    return JSONResponse(content={
        "run_id": run_id,
        "total_tokens": total_tokens,
        "total_usd": round(total_usd, 6),
        "summary": f"{total_tokens:,} tokens | ~${total_usd:.4f}",
        "by_stage": by_stage,
        "llm_calls": len(usage_events),
    })


@router.post("/api/runs/{run_id}/merge")
def merge_run(run_id: str) -> JSONResponse:
    """Merge the PR for a owlmind run via gh pr merge --squash."""
    branch = f"owlmind/run-{run_id[:12]}"
    workspace = str(Path.home() / "owlmind")
    result = subprocess.run(
        ["/opt/homebrew/bin/gh", "pr", "merge", branch, "--squash", "--delete-branch"],
        cwd=workspace,
        capture_output=True,
        text=True,
    )
    if result.returncode == 0:
        return JSONResponse(content={"ok": True, "branch": branch})
    return JSONResponse(
        status_code=400,
        content={"ok": False, "error": result.stderr.strip() or "gh pr merge failed"},
    )


@router.get("/api/runs/{run_id}/stream")
async def stream_run_events(run_id: str) -> StreamingResponse:
    """Stream run events as Server-Sent Events (SSE).

    Sends all existing events immediately, then tails the file for new ones.
    Stops after 10 minutes or when the run reaches a terminal state.
    """
    runs_dir = _get_runs_dir()
    if runs_dir is None:
        async def _not_found():
            yield "data: {\"error\": \"runs directory not found\"}\n\n"
        return StreamingResponse(_not_found(), media_type="text/event-stream")

    run_dir = runs_dir / run_id
    log_path = run_dir / "run.jsonl"

    async def _event_generator():
        sent_lines = 0
        deadline = asyncio.get_event_loop().time() + 600  # 10 min max

        while asyncio.get_event_loop().time() < deadline:
            if log_path.exists():
                try:
                    lines = log_path.read_text().splitlines()
                except Exception:
                    lines = []

                # Send any new lines since last check
                for line in lines[sent_lines:]:
                    line = line.strip()
                    if line:
                        yield f"data: {line}\n\n"
                        sent_lines = len(lines)

                # Check if run is terminal
                meta = _read_meta(run_dir)
                state = (meta.get("state") or "").upper()
                if state in ("DONE", "FAILED", "APPROVED", "REJECTED"):
                    yield "data: {\"event\": \"__stream_end__\", \"state\": \"" + state + "\"}\n\n"
                    break

            await asyncio.sleep(2)

        yield "data: {\"event\": \"__stream_timeout__\"}\n\n"

    return StreamingResponse(
        _event_generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )
