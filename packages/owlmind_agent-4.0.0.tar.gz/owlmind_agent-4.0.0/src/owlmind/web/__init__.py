"""OwlMind web dashboard."""
from owlmind.web.app import app

__all__ = ["app"]
