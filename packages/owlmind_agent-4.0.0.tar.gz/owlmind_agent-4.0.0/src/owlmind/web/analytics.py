"""Analytics API routes for the OwlMind web dashboard."""
from __future__ import annotations

from fastapi import APIRouter
from fastapi.responses import JSONResponse

from owlmind.web import runs as _runs_mod

router = APIRouter(tags=["analytics"])


@router.get("/api/analytics/costs")
def analytics_costs(days: int = 30) -> JSONResponse:
    """Return daily token/USD aggregates for the past N days from all runs."""
    from collections import defaultdict
    from datetime import UTC, datetime, timedelta

    runs_dir = _runs_mod._get_runs_dir()
    if runs_dir is None:
        return JSONResponse(content={"daily": [], "total_tokens": 0, "total_usd": 0.0})

    cutoff = datetime.now(UTC) - timedelta(days=days)
    daily: dict[str, dict] = defaultdict(lambda: {"tokens": 0, "usd": 0.0, "calls": 0})
    total_tokens = 0
    total_usd = 0.0

    try:
        for run_dir in runs_dir.iterdir():
            if not run_dir.is_dir():
                continue
            for evt in _runs_mod._read_events(run_dir):
                if evt.get("event") != "LLM_USAGE_RECORDED":
                    continue
                ts_raw = evt.get("timestamp", "")
                try:
                    ts = datetime.fromisoformat(ts_raw.replace("Z", "+00:00"))
                    if ts < cutoff:
                        continue
                    day = ts.strftime("%Y-%m-%d")
                except Exception:
                    day = "unknown"
                tokens = evt.get("total_tokens", 0)
                usd = evt.get("estimated_usd", 0.0)
                daily[day]["tokens"] += tokens
                daily[day]["usd"] += usd
                daily[day]["calls"] += 1
                total_tokens += tokens
                total_usd += usd
    except Exception:
        pass

    sorted_days = sorted(daily.items())
    return JSONResponse(content={
        "daily": [
            {"date": d, "tokens": v["tokens"], "usd": round(v["usd"], 6), "calls": v["calls"]}
            for d, v in sorted_days
        ],
        "total_tokens": total_tokens,
        "total_usd": round(total_usd, 6),
        "days": days,
    })
