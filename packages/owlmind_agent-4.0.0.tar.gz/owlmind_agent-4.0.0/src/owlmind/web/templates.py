"""HTML templates for the OwlMind web dashboard."""

INDEX_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>OwlMind Dashboard</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
         background: #0f1117; color: #e2e8f0; min-height: 100vh; }
  header { background: #1a1d27; border-bottom: 1px solid #2d3148;
           padding: 16px 32px; display: flex; align-items: center; gap: 12px; }
  header h1 { font-size: 1.4rem; font-weight: 700; color: #7c8cf8; }
  header .sub { font-size: 0.85rem; color: #64748b; }
  .container { max-width: 1100px; margin: 0 auto; padding: 32px 16px; }
  .meta { display: flex; gap: 16px; margin-bottom: 24px; flex-wrap: wrap; }
  .badge { background: #1e2130; border: 1px solid #2d3148; border-radius: 6px;
           padding: 8px 14px; font-size: 0.82rem; color: #94a3b8; }
  .badge span { color: #7c8cf8; font-weight: 600; }
  h2 { font-size: 1.1rem; margin-bottom: 14px; color: #cbd5e1; }
  table { width: 100%; border-collapse: collapse; background: #1a1d27;
          border-radius: 8px; overflow: hidden; border: 1px solid #2d3148; }
  th { background: #12141f; color: #64748b; font-size: 0.78rem;
       text-transform: uppercase; letter-spacing: 0.05em;
       padding: 10px 16px; text-align: left; }
  td { padding: 12px 16px; font-size: 0.88rem; border-top: 1px solid #1e2130; }
  .btn-merge { background: #1e3a5f; color: #7dd3fc; border: 1px solid #2d5a8e;
               border-radius: 4px; padding: 3px 10px; font-size: 0.78rem;
               cursor: pointer; }
  .btn-merge:hover { background: #2d5a8e; }
  .btn-merge:disabled { opacity: 0.4; cursor: default; }
  tr:hover td { background: #1e2130; }
  .run-id { font-family: monospace; color: #7c8cf8; font-size: 0.8rem; }
  .goal { color: #e2e8f0; max-width: 320px; overflow: hidden;
          text-overflow: ellipsis; white-space: nowrap; }
  .state { padding: 2px 8px; border-radius: 4px; font-size: 0.78rem;
           font-weight: 600; display: inline-block; }
  .state-done    { background: #14532d; color: #86efac; }
  .state-running { background: #1e3a5f; color: #7dd3fc; }
  .state-failed  { background: #450a0a; color: #fca5a5; }
  .state-unknown { background: #1f2937; color: #9ca3af; }
  .ts { color: #64748b; font-family: monospace; font-size: 0.78rem; }
  .empty { text-align: center; padding: 48px; color: #64748b; }
  .refresh-info { font-size: 0.78rem; color: #475569; text-align: right;
                  margin-top: 12px; }
</style>
</head>
<body>
<header>
  <h1>OwlMind Dashboard</h1>
  <span class="sub">Run monitoring &amp; history</span>
</header>
<div class="container">
  <div class="meta" id="meta-badges">
    <div class="badge">Runs: <span id="run-count">—</span></div>
    <div class="badge">Status: <span id="sys-status">loading…</span></div>
    <div class="badge">Version: <span id="sys-version">—</span></div>
    <div class="badge" id="schedule-badge" style="display:none">📅 <span id="schedule-info">—</span></div>
  </div>
  <h2>Recent Runs</h2>
  <table id="runs-table">
    <thead>
      <tr>
        <th>Run ID</th>
        <th>Goal</th>
        <th>State</th>
        <th>Iter</th>
        <th>Cost</th>
        <th>Started At</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody id="runs-body">
      <tr><td colspan="4" class="empty">Loading…</td></tr>
    </tbody>
  </table>
  <p class="refresh-info">Auto-refreshes every 10 seconds</p>
</div>
<div class="container" style="margin-top:0;padding-top:0">
  <h2 style="margin-bottom:14px">Cost Over Time (30 days)</h2>
  <div style="background:#1a1d27;border:1px solid #2d3148;border-radius:8px;padding:20px">
    <canvas id="cost-chart" height="80"></canvas>
    <p id="cost-total" style="font-size:0.82rem;color:#64748b;margin-top:12px;text-align:right"></p>
  </div>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
function stateClass(s) {
  if (!s) return 'state-unknown';
  const sl = s.toLowerCase();
  if (sl === 'done' || sl === 'approved') return 'state-done';
  if (sl === 'running') return 'state-running';
  if (sl === 'failed' || sl === 'rejected') return 'state-failed';
  return 'state-unknown';
}

function truncate(s, n) {
  if (!s) return '—';
  return s.length > n ? s.slice(0, n) + '…' : s;
}

async function loadRuns() {
  try {
    const r = await fetch('/api/runs?limit=50');
    const runs = await r.json();
    document.getElementById('run-count').textContent = runs.length;
    const tbody = document.getElementById('runs-body');
    if (!runs.length) {
      tbody.innerHTML = '<tr><td colspan="4" class="empty">No runs yet.</td></tr>';
      return;
    }
    tbody.innerHTML = runs.map(run => {
      const state = run.state || run.status || 'unknown';
      const cls = stateClass(state);
      const isDone = state.toLowerCase() === 'done' || state.toLowerCase() === 'approved';
      const prLink = run.pr_url ? ' <a href="' + run.pr_url + '" target="_blank" style="color:#7dd3fc;font-size:0.78rem;text-decoration:none">🔗</a>' : '';
      const mergeBtn = isDone
        ? '<button class="btn-merge" onclick="mergeRun(this, \'' + (run.run_id || '') + '\')">Merge PR</button>' + prLink
        : '—';
      return '<tr>' +
        '<td><a class="run-id" href="/runs/' + (run.run_id || '') + '" style="color:#7c8cf8;text-decoration:none">' + (run.run_id || '—') + '</a></td>' +
        '<td><span class="goal" title="' + (run.goal || '') + '">' + truncate(run.goal, 60) + '</span></td>' +
        '<td><span class="state ' + cls + '">' + state + '</span></td>' +
        '<td style="color:#94a3b8;font-size:0.82rem">' + (run.iterations || '—') + '</td>' +
        '<td style="color:#94a3b8;font-size:0.78rem;font-family:monospace">' + (run.cost_summary || '—') + '</td>' +
        '<td><span class="ts">' + (run.started_at || run.created_at || '—') + '</span></td>' +
        '<td>' + mergeBtn + '</td>' +
        '</tr>';
    }).join('');
  } catch(e) {
    document.getElementById('runs-body').innerHTML =
      '<tr><td colspan="4" class="empty">Error loading runs: ' + e.message + '</td></tr>';
  }
}

async function loadStatus() {
  try {
    const r = await fetch('/api/status');
    const d = await r.json();
    document.getElementById('sys-status').textContent = d.status || 'ok';
    document.getElementById('sys-version').textContent = d.version || '—';
    if (d.schedule) {
      document.getElementById('schedule-info').textContent = d.schedule.time + ' UTC — ' + d.schedule.goal.slice(0, 40);
      document.getElementById('schedule-badge').style.display = '';
    }
  } catch(e) {
    document.getElementById('sys-status').textContent = 'error';
  }
}

async function mergeRun(btn, runId) {
  btn.disabled = true;
  btn.textContent = 'Merging…';
  try {
    const r = await fetch('/api/runs/' + runId + '/merge', {method: 'POST'});
    const d = await r.json();
    if (d.ok) {
      btn.textContent = '✅ Merged';
      btn.style.background = '#14532d';
    } else {
      btn.textContent = '❌ Failed';
      btn.style.background = '#450a0a';
      btn.disabled = false;
      alert('Merge failed: ' + (d.error || 'unknown error'));
    }
  } catch(e) {
    btn.textContent = '❌ Error';
    btn.disabled = false;
  }
}

let _costChart = null;
async function loadCostChart() {
  try {
    const r = await fetch('/api/analytics/costs?days=30');
    const d = await r.json();
    const labels = d.daily.map(x => x.date);
    const tokens = d.daily.map(x => x.tokens);
    const usd = d.daily.map(x => x.usd);
    document.getElementById('cost-total').textContent =
      `Total: ${(d.total_tokens || 0).toLocaleString()} tokens | ~$${(d.total_usd || 0).toFixed(4)}`;
    const ctx = document.getElementById('cost-chart');
    if (!ctx) return;
    if (_costChart) _costChart.destroy();
    _costChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels,
        datasets: [
          {
            label: 'Tokens',
            data: tokens,
            backgroundColor: 'rgba(124,140,248,0.5)',
            borderColor: '#7c8cf8',
            borderWidth: 1,
            yAxisID: 'y',
          },
          {
            label: 'USD',
            data: usd,
            type: 'line',
            borderColor: '#86efac',
            backgroundColor: 'rgba(134,239,172,0.1)',
            tension: 0.3,
            yAxisID: 'y1',
          },
        ],
      },
      options: {
        responsive: true,
        plugins: { legend: { labels: { color: '#94a3b8' } } },
        scales: {
          x: { ticks: { color: '#64748b' }, grid: { color: '#1e2130' } },
          y: { ticks: { color: '#94a3b8' }, grid: { color: '#1e2130' }, title: { display: true, text: 'Tokens', color: '#64748b' } },
          y1: { position: 'right', ticks: { color: '#86efac' }, grid: { drawOnChartArea: false }, title: { display: true, text: 'USD', color: '#86efac' } },
        },
      },
    });
  } catch(e) { /* chart unavailable */ }
}
function refresh() { loadRuns(); loadStatus(); loadCostChart(); }
refresh();
setInterval(refresh, 10000);
</script>
</body>
</html>
"""

LANDING_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>OwlMind — Autonomous Multi-Agent Coding Assistant</title>
<meta name="description" content="OwlMind is an autonomous multi-agent coding assistant that plans, executes, and judges code changes using a Planner-Worker-Judge cycle.">
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  :root {
    --bg:        #0b0d14;
    --surface:   #13161f;
    --surface2:  #1a1d2e;
    --border:    #252840;
    --accent:    #7c8cf8;
    --accent2:   #a78bfa;
    --green:     #34d399;
    --text:      #e2e8f0;
    --muted:     #94a3b8;
    --faint:     #475569;
  }
  html { scroll-behavior: smooth; }
  body {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    background: var(--bg);
    color: var(--text);
    min-height: 100vh;
    line-height: 1.6;
  }
  nav {
    position: sticky; top: 0; z-index: 100;
    background: rgba(11,13,20,0.88);
    backdrop-filter: blur(12px);
    border-bottom: 1px solid var(--border);
    padding: 0 32px;
    display: flex; align-items: center; justify-content: space-between;
    height: 60px;
  }
  .nav-logo { font-size: 1.1rem; font-weight: 800; color: var(--accent); letter-spacing: -0.02em; }
  .nav-links { display: flex; gap: 28px; list-style: none; }
  .nav-links a { color: var(--muted); text-decoration: none; font-size: 0.88rem; transition: color 0.15s; }
  .nav-links a:hover { color: var(--text); }
  .nav-cta {
    background: var(--accent); color: #fff;
    border: none; border-radius: 6px;
    padding: 7px 16px; font-size: 0.85rem; font-weight: 600;
    cursor: pointer; text-decoration: none; transition: opacity 0.15s;
  }
  .nav-cta:hover { opacity: 0.85; }
  .hero {
    max-width: 860px; margin: 0 auto;
    padding: 96px 24px 80px;
    text-align: center;
  }
  .hero-badge {
    display: inline-block;
    background: var(--surface2); border: 1px solid var(--border);
    color: var(--accent); border-radius: 20px;
    padding: 4px 14px; font-size: 0.78rem; font-weight: 600;
    letter-spacing: 0.04em; text-transform: uppercase;
    margin-bottom: 24px;
  }
  .hero h1 {
    font-size: clamp(2.2rem, 5vw, 3.6rem);
    font-weight: 800; letter-spacing: -0.03em;
    line-height: 1.15; margin-bottom: 20px;
  }
  .hero h1 .accent { color: var(--accent); }
  .hero p { font-size: 1.15rem; color: var(--muted); max-width: 580px; margin: 0 auto 36px; }
  .hero-buttons { display: flex; gap: 14px; justify-content: center; flex-wrap: wrap; }
  .btn-primary {
    background: var(--accent); color: #fff;
    border: none; border-radius: 8px;
    padding: 12px 28px; font-size: 0.95rem; font-weight: 700;
    cursor: pointer; text-decoration: none; transition: opacity 0.15s, transform 0.1s;
    display: inline-flex; align-items: center; gap: 8px;
  }
  .btn-primary:hover { opacity: 0.88; transform: translateY(-1px); }
  .btn-secondary {
    background: var(--surface2); color: var(--text);
    border: 1px solid var(--border); border-radius: 8px;
    padding: 12px 28px; font-size: 0.95rem; font-weight: 600;
    cursor: pointer; text-decoration: none; transition: border-color 0.15s, transform 0.1s;
    display: inline-flex; align-items: center; gap: 8px;
  }
  .btn-secondary:hover { border-color: var(--accent); transform: translateY(-1px); }
  .section { max-width: 1000px; margin: 0 auto; padding: 72px 24px; }
  .section-label {
    text-align: center; font-size: 0.78rem; font-weight: 700;
    text-transform: uppercase; letter-spacing: 0.1em;
    color: var(--accent); margin-bottom: 12px;
  }
  .section-title {
    text-align: center; font-size: clamp(1.5rem, 3vw, 2.1rem);
    font-weight: 800; letter-spacing: -0.02em; margin-bottom: 14px;
  }
  .section-sub {
    text-align: center; color: var(--muted);
    max-width: 560px; margin: 0 auto 52px; font-size: 0.97rem;
  }
  .cycle {
    display: flex; align-items: center; justify-content: center;
    gap: 0; flex-wrap: wrap;
  }
  .cycle-node {
    background: var(--surface2); border: 1px solid var(--border);
    border-radius: 12px; padding: 24px 28px;
    text-align: center; min-width: 170px;
  }
  .cycle-node .icon { font-size: 2rem; margin-bottom: 10px; }
  .cycle-node .name { font-weight: 700; font-size: 1.05rem; color: var(--text); margin-bottom: 4px; }
  .cycle-node .desc { font-size: 0.80rem; color: var(--muted); line-height: 1.4; }
  .cycle-node.planner { border-color: var(--accent); }
  .cycle-node.worker  { border-color: var(--green); }
  .cycle-node.judge   { border-color: var(--accent2); }
  .cycle-arrow { color: var(--faint); font-size: 1.6rem; padding: 0 10px; line-height: 1; user-select: none; }
  .features-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
    gap: 20px;
  }
  .feature-card {
    background: var(--surface); border: 1px solid var(--border);
    border-radius: 12px; padding: 24px;
    transition: border-color 0.2s, transform 0.15s;
  }
  .feature-card:hover { border-color: var(--accent); transform: translateY(-2px); }
  .feature-icon { font-size: 1.6rem; margin-bottom: 12px; }
  .feature-card h3 { font-size: 1rem; font-weight: 700; margin-bottom: 8px; }
  .feature-card p { font-size: 0.87rem; color: var(--muted); line-height: 1.55; }
  .metrics-row {
    display: flex; gap: 20px; flex-wrap: wrap; justify-content: center;
    margin-bottom: 32px;
  }
  .metric-card {
    background: var(--surface2); border: 1px solid var(--border);
    border-radius: 12px; padding: 24px 36px; text-align: center; min-width: 180px;
  }
  .metric-card .value { font-size: 2rem; font-weight: 800; color: var(--accent); }
  .metric-card .label { font-size: 0.82rem; color: var(--muted); margin-top: 4px; }
  .metrics-link-row { text-align: center; }
  .metrics-link {
    color: var(--accent); text-decoration: none; font-size: 0.88rem; font-weight: 600;
    border-bottom: 1px dashed var(--accent);
  }
  .metrics-link:hover { opacity: 0.8; }
  .steps { display: flex; flex-direction: column; gap: 20px; max-width: 700px; margin: 0 auto; }
  .step { display: flex; gap: 18px; align-items: flex-start; }
  .step-num {
    width: 32px; height: 32px; border-radius: 50%;
    background: var(--accent); color: #fff;
    font-weight: 800; font-size: 0.88rem;
    display: flex; align-items: center; justify-content: center;
    flex-shrink: 0; margin-top: 2px;
  }
  .step-content h4 { font-size: 0.95rem; font-weight: 700; margin-bottom: 6px; }
  .step-content p  { font-size: 0.87rem; color: var(--muted); margin-bottom: 8px; }
  code, pre {
    font-family: "JetBrains Mono", "Fira Code", "Cascadia Code", monospace;
    font-size: 0.85rem;
  }
  .code-block {
    background: var(--surface2); border: 1px solid var(--border);
    border-radius: 8px; padding: 14px 18px;
    color: #c4b5fd; overflow-x: auto; white-space: pre;
  }
  .env-block {
    background: var(--surface2); border: 1px solid var(--border);
    border-radius: 8px; padding: 14px 18px;
    font-family: "JetBrains Mono", monospace; font-size: 0.82rem;
    color: var(--muted); overflow-x: auto; white-space: pre;
  }
  .env-block .key { color: var(--accent); }
  .env-block .comment { color: var(--faint); }
  .divider { border: none; border-top: 1px solid var(--border); margin: 0 24px; }
  footer {
    border-top: 1px solid var(--border);
    padding: 32px 32px;
    display: flex; align-items: center; justify-content: space-between;
    flex-wrap: wrap; gap: 16px;
  }
  .footer-logo { font-size: 0.95rem; font-weight: 700; color: var(--accent); }
  .footer-copy { font-size: 0.80rem; color: var(--faint); }
  .footer-links { display: flex; gap: 20px; list-style: none; }
  .footer-links a { color: var(--muted); text-decoration: none; font-size: 0.82rem; transition: color 0.15s; }
  .footer-links a:hover { color: var(--text); }
  @media (max-width: 640px) {
    nav { padding: 0 16px; }
    .nav-links { display: none; }
    .hero { padding: 64px 16px 56px; }
    .cycle { flex-direction: column; }
    .cycle-arrow { transform: rotate(90deg); padding: 6px 0; }
    footer { flex-direction: column; text-align: center; }
  }
</style>
</head>
<body>

<nav>
  <span class="nav-logo">OwlMind</span>
  <ul class="nav-links">
    <li><a href="#how-it-works">How it works</a></li>
    <li><a href="#features">Features</a></li>
    <li><a href="#metrics">Metrics</a></li>
    <li><a href="#get-started">Get started</a></li>
  </ul>
  <a class="nav-cta" href="/">Live Demo</a>
</nav>

<section class="hero">
  <div class="hero-badge">Autonomous AI Agent</div>
  <h1>
    <span class="accent">OwlMind</span> &mdash; Autonomous<br>Multi-Agent Coding Assistant
  </h1>
  <p>
    Delegate coding tasks to a self-directed agent loop. OwlMind plans the work,
    writes the code, and critiques its own output &mdash; iterating until the task is done.
  </p>
  <div class="hero-buttons">
    <a class="btn-primary" href="/">&#9654; Live Demo</a>
    <a class="btn-secondary" href="https://github.com/MuraveyApp/charwiz" target="_blank" rel="noopener">GitHub</a>
  </div>
</section>

<hr class="divider">

<section class="section" id="how-it-works">
  <div class="section-label">Architecture</div>
  <h2 class="section-title">The Planner &rarr; Worker &rarr; Judge Cycle</h2>
  <p class="section-sub">
    Every task is routed through three specialised agents that collaborate in a tight
    feedback loop until a high-quality result is achieved.
  </p>
  <div class="cycle">
    <div class="cycle-node planner">
      <div class="icon">&#129302;</div>
      <div class="name">Planner</div>
      <div class="desc">Decomposes the goal into concrete sub-tasks and writes a step-by-step execution plan.</div>
    </div>
    <div class="cycle-arrow">&rarr;</div>
    <div class="cycle-node worker">
      <div class="icon">&#9881;&#65039;</div>
      <div class="name">Worker</div>
      <div class="desc">Executes sub-tasks in parallel: writes code, runs tests, reads files, and calls tools.</div>
    </div>
    <div class="cycle-arrow">&rarr;</div>
    <div class="cycle-node judge">
      <div class="icon">&#9878;&#65039;</div>
      <div class="name">Judge</div>
      <div class="desc">Reviews the output, scores quality, and either approves or sends it back for revision.</div>
    </div>
    <div class="cycle-arrow" style="transform:scaleX(-1)">&#8617;</div>
  </div>
</section>

<hr class="divider">

<section class="section" id="features">
  <div class="section-label">Key Features</div>
  <h2 class="section-title">Everything you need to ship faster</h2>
  <p class="section-sub">Built for real-world software engineering tasks out of the box.</p>
  <div class="features-grid">
    <div class="feature-card">
      <div class="feature-icon">&#9889;</div>
      <h3>Parallel Sub-Tasks</h3>
      <p>Worker agents run independent sub-tasks concurrently, slashing wall-clock time on multi-file changes.</p>
    </div>
    <div class="feature-card">
      <div class="feature-icon">&#128241;</div>
      <h3>Telegram Bot Interface</h3>
      <p>Kick off a task, receive progress updates, and approve or reject results directly from Telegram.</p>
    </div>
    <div class="feature-card">
      <div class="feature-icon">&#127959;</div>
      <h3>SWE-bench Ready</h3>
      <p>Evaluated on SWE-bench Verified tasks. Designed to handle real GitHub issues end-to-end.</p>
    </div>
    <div class="feature-card">
      <div class="feature-icon">&#128200;</div>
      <h3>Cost Tracking</h3>
      <p>Every LLM call is logged with token counts and USD estimates. Daily aggregates available via API.</p>
    </div>
    <div class="feature-card">
      <div class="feature-icon">&#128279;</div>
      <h3>Automatic PR Creation</h3>
      <p>On approval the agent opens a GitHub pull request, links it in the dashboard, and marks the run done.</p>
    </div>
    <div class="feature-card">
      <div class="feature-icon">&#128064;</div>
      <h3>Vision &amp; Browser Tools</h3>
      <p>Agents can capture screenshots, browse docs, and reason over visual content to solve UI-level issues.</p>
    </div>
  </div>
</section>

<hr class="divider">

<section class="section" id="metrics">
  <div class="section-label">Live Metrics</div>
  <h2 class="section-title">Usage at a glance</h2>
  <p class="section-sub">
    Real-time data pulled from this instance. Full breakdown available via the analytics API.
  </p>
  <div class="metrics-row">
    <div class="metric-card">
      <div class="value" id="m-runs">--</div>
      <div class="label">Total Runs</div>
    </div>
    <div class="metric-card">
      <div class="value" id="m-tokens">--</div>
      <div class="label">Tokens (30 days)</div>
    </div>
    <div class="metric-card">
      <div class="value" id="m-usd">--</div>
      <div class="label">Cost (30 days)</div>
    </div>
    <div class="metric-card">
      <div class="value" id="m-version">--</div>
      <div class="label">Version</div>
    </div>
  </div>
  <div class="metrics-link-row">
    <a class="metrics-link" href="/api/analytics/costs" target="_blank">View full cost analytics JSON &rarr;</a>
  </div>
</section>

<hr class="divider">

<section class="section" id="get-started">
  <div class="section-label">Getting Started</div>
  <h2 class="section-title">Up and running in minutes</h2>
  <p class="section-sub">Install from PyPI, set a couple of environment variables, and launch.</p>
  <div class="steps">
    <div class="step">
      <div class="step-num">1</div>
      <div class="step-content">
        <h4>Install OwlMind</h4>
        <p>Requires Python 3.11+. Install via pip:</p>
        <div class="code-block">pip install owlmind</div>
      </div>
    </div>
    <div class="step">
      <div class="step-num">2</div>
      <div class="step-content">
        <h4>Configure environment variables</h4>
        <p>Set your API keys and workspace path:</p>
        <div class="env-block"><span class="comment"># .env or shell profile</span>
<span class="key">ANTHROPIC_API_KEY</span>=sk-ant-...
<span class="key">GITHUB_TOKEN</span>=ghp_...
<span class="key">OWLMIND_WORKSPACE</span>=~/my-project
<span class="key">TELEGRAM_BOT_TOKEN</span>=...  <span class="comment"># optional</span></div>
      </div>
    </div>
    <div class="step">
      <div class="step-num">3</div>
      <div class="step-content">
        <h4>Launch the dashboard</h4>
        <p>Start the web UI to monitor and manage runs:</p>
        <div class="code-block">owlmind web serve --port 8080</div>
      </div>
    </div>
    <div class="step">
      <div class="step-num">4</div>
      <div class="step-content">
        <h4>Run your first task</h4>
        <p>Submit a coding goal from the CLI or Telegram:</p>
        <div class="code-block">owlmind run "Add rate limiting to the /api/runs endpoint"</div>
      </div>
    </div>
  </div>
</section>

<footer>
  <span class="footer-logo">OwlMind</span>
  <span class="footer-copy">&copy; 2026 MuraveyApp. MIT License.</span>
  <ul class="footer-links">
    <li><a href="https://github.com/MuraveyApp/charwiz" target="_blank" rel="noopener">GitHub</a></li>
    <li><a href="/">Dashboard</a></li>
    <li><a href="/api/status">API Status</a></li>
  </ul>
</footer>

<script>
(async function loadMetrics() {
  try {
    const [statusRes, costsRes] = await Promise.all([
      fetch('/api/status'),
      fetch('/api/analytics/costs?days=30'),
    ]);
    const status = await statusRes.json();
    const costs  = await costsRes.json();
    const el = (id) => document.getElementById(id);
    if (status.total_runs !== null && status.total_runs !== undefined) {
      el('m-runs').textContent = status.total_runs.toLocaleString();
    }
    if (status.version) {
      el('m-version').textContent = status.version;
    }
    if (costs.total_tokens !== undefined) {
      const t = costs.total_tokens;
      el('m-tokens').textContent = t >= 1e6
        ? (t / 1e6).toFixed(1) + 'M'
        : t >= 1e3 ? (t / 1e3).toFixed(1) + 'K' : String(t);
    }
    if (costs.total_usd !== undefined) {
      el('m-usd').textContent = '$' + costs.total_usd.toFixed(3);
    }
  } catch (_) { /* metrics unavailable in offline view */ }
})();
</script>
</body>
</html>
"""

RUN_DETAIL_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Run Detail — OwlMind</title>
<style>
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
         background: #0f1117; color: #e2e8f0; min-height: 100vh; }}
  header {{ background: #1a1d27; border-bottom: 1px solid #2d3148;
           padding: 16px 32px; display: flex; align-items: center; gap: 12px; }}
  header a {{ color: #7c8cf8; text-decoration: none; font-size: 0.9rem; }}
  header h1 {{ font-size: 1.2rem; font-weight: 700; color: #7c8cf8; }}
  .container {{ max-width: 900px; margin: 0 auto; padding: 32px 16px; }}
  .card {{ background: #1a1d27; border: 1px solid #2d3148; border-radius: 8px;
           padding: 20px; margin-bottom: 20px; }}
  .card h2 {{ font-size: 1rem; color: #94a3b8; margin-bottom: 14px;
              text-transform: uppercase; letter-spacing: 0.05em; font-size: 0.78rem; }}
  .field {{ display: flex; gap: 12px; margin-bottom: 8px; font-size: 0.88rem; }}
  .field .k {{ color: #64748b; min-width: 120px; }}
  .field .v {{ color: #e2e8f0; word-break: break-all; }}
  .state {{ padding: 2px 8px; border-radius: 4px; font-size: 0.78rem; font-weight: 600; }}
  .state-done    {{ background: #14532d; color: #86efac; }}
  .state-running {{ background: #1e3a5f; color: #7dd3fc; }}
  .state-failed  {{ background: #450a0a; color: #fca5a5; }}
  .state-unknown {{ background: #1f2937; color: #9ca3af; }}
  .events {{ list-style: none; font-size: 0.82rem; }}
  .events li {{ padding: 6px 0; border-top: 1px solid #1e2130; color: #94a3b8; }}
  .events li .evt {{ color: #7c8cf8; margin-right: 8px; }}
  .events li .ts {{ color: #475569; font-family: monospace; font-size: 0.75rem; margin-right: 8px; }}
  pre {{ background: #12141f; padding: 12px; border-radius: 6px; font-size: 0.78rem;
         overflow-x: auto; color: #94a3b8; white-space: pre-wrap; }}
</style>
</head>
<body>
<header>
  <a href="/">← Dashboard</a>
  <h1>Run Detail</h1>
</header>
<div class="container" id="main">
  <p style="color:#64748b">Loading…</p>
</div>
<script>
const runId = location.pathname.split('/').pop();

function stateClass(s) {{
  if (!s) return 'state-unknown';
  const sl = s.toLowerCase();
  if (sl === 'done' || sl === 'approved') return 'state-done';
  if (sl === 'running') return 'state-running';
  if (sl === 'failed' || sl === 'rejected') return 'state-failed';
  return 'state-unknown';
}}

async function load() {{
  const r = await fetch('/api/runs/' + runId);
  const d = await r.json();
  const state = d.state || d.status || 'unknown';
  const events = d.events || [];
  document.getElementById('main').innerHTML = `
    <div class="card">
      <h2>Run Info</h2>
      <div class="field"><span class="k">Run ID</span><span class="v" style="font-family:monospace">${{d.run_id || '—'}}</span></div>
      <div class="field"><span class="k">Goal</span><span class="v">${{d.goal || '—'}}</span></div>
      <div class="field"><span class="k">State</span><span class="v"><span class="state ${{stateClass(state)}}">${{state}}</span></span></div>
      <div class="field"><span class="k">Started At</span><span class="v">${{d.started_at || '—'}}</span></div>
      <div class="field"><span class="k">Iterations</span><span class="v">${{d.iterations || '—'}}</span></div>
      <div class="field"><span class="k">Cost</span><span class="v" style="font-family:monospace">${{d.cost_summary || '—'}}</span></div>
      ${{d.pr_url ? `<div class="field"><span class="k">PR</span><span class="v"><a href="${{d.pr_url}}" target="_blank" style="color:#7dd3fc">${{d.pr_url}}</a></span></div>` : ''}}
      <div class="field"><span class="k">Events</span><span class="v">${{d.event_count || 0}}</span></div>
    </div>
    <div class="card" id="live-log-card">
      <h2>Live Log <span id="stream-status" style="font-size:0.72rem;color:#475569;margin-left:8px">connecting…</span></h2>
      <ul class="events" id="live-log-list">
        ${{events.slice(-50).map(e => `<li>
          <span class="ts">${{(e.timestamp || '').slice(0,19)}}</span>
          <span class="evt">${{e.event || e.type || '?'}}</span>
          ${{(e.message || e.msg || JSON.stringify(e)).slice(0, 200)}}
        </li>`).join('') || '<li style="color:#475569">No events yet</li>'}}
      </ul>
    </div>
    ${{d.meta && Object.keys(d.meta).length ? `<div class="card"><h2>Meta</h2><pre>${{JSON.stringify(d.meta, null, 2)}}</pre></div>` : ''}}
  `;
  startStream();
}}

function startStream() {{
  const list = document.getElementById('live-log-list');
  const status = document.getElementById('stream-status');
  if (!list || !status) return;

  const es = new EventSource('/api/runs/' + runId + '/stream');
  status.textContent = '● live';
  status.style.color = '#86efac';

  es.onmessage = function(e) {{
    try {{
      const evt = JSON.parse(e.data);
      if (evt.event === '__stream_end__' || evt.event === '__stream_timeout__') {{
        es.close();
        status.textContent = '◉ ended';
        status.style.color = '#64748b';
        return;
      }}
      const li = document.createElement('li');
      const ts = (evt.timestamp || '').slice(0, 19);
      const name = evt.event || evt.type || '?';
      const msg = (evt.message || evt.msg || JSON.stringify(evt)).slice(0, 200);
      li.innerHTML = `<span class="ts">${{ts}}</span><span class="evt">${{name}}</span> ${{msg}}`;
      list.appendChild(li);
      li.scrollIntoView({{behavior: 'smooth', block: 'nearest'}});
    }} catch(_) {{}}
  }};

  es.onerror = function() {{
    status.textContent = '✕ disconnected';
    status.style.color = '#fca5a5';
    es.close();
  }};
}}

load();
</script>
</body>
</html>"""
