"""HTML page routes for the OwlMind web dashboard."""
from __future__ import annotations

from fastapi import APIRouter
from fastapi.responses import HTMLResponse

from owlmind.web.templates import INDEX_HTML, LANDING_HTML, RUN_DETAIL_HTML

router = APIRouter(tags=["pages"])


@router.get("/", response_class=HTMLResponse)
def index() -> str:
    """Dashboard home page — shows recent runs."""
    return INDEX_HTML


@router.get("/landing", response_class=HTMLResponse)
def landing() -> str:
    """Public landing page for OwlMind -- no auth required."""
    return LANDING_HTML


@router.get("/runs/{run_id}", response_class=HTMLResponse)
def run_detail(run_id: str) -> str:
    """Detail page for a specific run."""
    return RUN_DETAIL_HTML
