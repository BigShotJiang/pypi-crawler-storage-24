"""Abstract issue tracker interface and shared models."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from string import Template
from typing import Any


@dataclass
class TrackerConfig:
    """Common configuration for issue trackers."""

    tracker_type: str
    timeout: int = 15


@dataclass
class IssueResult:
    """Result of creating an issue/card."""

    ok: bool
    issue_id: str = ""
    issue_key: str = ""
    url: str = ""
    detail: str = ""


class IssueTracker(ABC):
    """Abstract base class for issue tracker integrations.

    Implementations provide methods for creating issues/cards,
    validating configuration, and formatting descriptions.
    """

    @property
    @abstractmethod
    def tracker_type(self) -> str:
        """Return tracker type name (e.g. 'jira', 'trello')."""

    @abstractmethod
    async def create_issue(self, params: dict[str, Any]) -> IssueResult:
        """Create an issue or card on the tracker.

        Args:
            params: Tracker-specific parameters (project, summary, etc.).

        Returns:
            :class:`IssueResult` with creation details.
        """

    @abstractmethod
    async def validate_config(self) -> bool:
        """Validate that the tracker configuration is correct.

        Returns:
            True if configuration is valid and connection works.
        """

    @staticmethod
    def format_description(
        template_str: str,
        context: dict[str, Any],
    ) -> str:
        """Safely render a description template with context variables.

        Uses ``string.Template`` for safe substitution (no code execution).

        Args:
            template_str: Template string with ``$var`` or ``${var}`` placeholders.
            context: Variable values for substitution.

        Returns:
            Rendered string (missing vars left as-is).
        """
        tpl = Template(template_str)
        return tpl.safe_substitute(context)
