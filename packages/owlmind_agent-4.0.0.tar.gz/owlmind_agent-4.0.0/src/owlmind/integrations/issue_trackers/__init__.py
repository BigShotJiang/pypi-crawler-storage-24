"""Issue tracker integrations: Jira and Trello.

Usage::

    from owlmind.integrations.issue_trackers import create_issue_tracker

    tracker = create_issue_tracker("jira", base_url="https://org.atlassian.net",
                                    email="user@org.com", api_token="tok")
    result = await tracker.create_issue({"project": "DEV", "summary": "Bug"})
"""

from __future__ import annotations

from typing import Any

from owlmind.integrations.issue_trackers.base import IssueResult, IssueTracker
from owlmind.integrations.issue_trackers.jira import JiraTracker
from owlmind.integrations.issue_trackers.trello import TrelloTracker


def create_issue_tracker(
    tracker_type: str,
    **kwargs: Any,
) -> IssueTracker:
    """Factory for issue tracker clients.

    Args:
        tracker_type: One of ``"jira"`` or ``"trello"``.
        **kwargs: Tracker-specific configuration.

    Returns:
        Configured :class:`IssueTracker` instance.

    Raises:
        ValueError: If *tracker_type* is not supported.
    """
    tracker_type = tracker_type.lower().strip()
    if tracker_type == "jira":
        return JiraTracker(
            base_url=kwargs.get("base_url", ""),
            email=kwargs.get("email", ""),
            api_token=kwargs.get("api_token", ""),
            timeout=kwargs.get("timeout", 15),
        )
    if tracker_type == "trello":
        return TrelloTracker(
            api_key=kwargs.get("api_key", ""),
            token=kwargs.get("token", ""),
            timeout=kwargs.get("timeout", 15),
        )
    msg = f"Unsupported tracker type: {tracker_type!r}. Use 'jira' or 'trello'."
    raise ValueError(msg)


__all__ = [
    "IssueResult",
    "IssueTracker",
    "JiraTracker",
    "TrelloTracker",
    "create_issue_tracker",
]
