"""Jira issue tracker — REST API v3 integration."""

from __future__ import annotations

import asyncio
import base64
import json
import logging
import urllib.error
import urllib.request
from typing import Any

from owlmind.integrations.issue_trackers.base import IssueResult, IssueTracker

logger = logging.getLogger(__name__)


class JiraTracker(IssueTracker):
    """Jira integration via REST API v3.

    Uses Basic Auth (email + API token) for Jira Cloud,
    or Bearer token for Jira Server/Data Center.
    """

    def __init__(
        self,
        base_url: str,
        email: str,
        api_token: str,
        timeout: int = 15,
    ) -> None:
        self._base = base_url.rstrip("/")
        self._email = email
        self._api_token = api_token
        self._timeout = timeout

    @property
    def tracker_type(self) -> str:
        return "jira"

    def _headers(self) -> dict[str, str]:
        creds = base64.b64encode(f"{self._email}:{self._api_token}".encode()).decode()
        return {
            "Authorization": f"Basic {creds}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    def _request(
        self,
        method: str,
        path: str,
        data: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        """Synchronous HTTP request to Jira API."""
        url = f"{self._base}/rest/api/3{path}"
        body = json.dumps(data).encode() if data else None
        req = urllib.request.Request(
            url,
            data=body,
            headers=self._headers(),
            method=method,
        )
        try:
            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                raw = resp.read().decode()
                return json.loads(raw) if raw else {}
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode(errors="replace") if exc.fp else ""
            logger.error("Jira API %s %s → %s: %s", method, path, exc.code, detail)
            return None
        except urllib.error.URLError as exc:
            logger.error("Jira API %s %s network error: %s", method, path, exc.reason)
            return None

    async def _async_request(
        self, method: str, path: str, data: dict[str, Any] | None = None
    ) -> dict[str, Any] | None:
        return await asyncio.to_thread(self._request, method, path, data)

    async def create_issue(self, params: dict[str, Any]) -> IssueResult:
        """Create a Jira issue.

        Expected params:
            project: Project key (e.g. "DEV")
            summary: Issue summary
            description: Issue description (optional)
            issuetype: Issue type name (default: "Task")
            priority: Priority name (optional, e.g. "High")
            labels: List of labels (optional)
        """
        from owlmind.monitoring.metrics import track_integration_request

        project = params.get("project", "")
        summary = params.get("summary", "")
        if not project or not summary:
            return IssueResult(ok=False, detail="Missing 'project' or 'summary'")

        issue_type = params.get("issuetype", "Task")
        description = params.get("description", "")
        priority = params.get("priority", "")
        labels = params.get("labels", [])

        fields: dict[str, Any] = {
            "project": {"key": project},
            "summary": summary,
            "issuetype": {"name": issue_type},
        }

        if description:
            # Jira Cloud ADF format (simple paragraph)
            fields["description"] = {
                "type": "doc",
                "version": 1,
                "content": [
                    {
                        "type": "paragraph",
                        "content": [{"type": "text", "text": description}],
                    }
                ],
            }

        if priority:
            fields["priority"] = {"name": priority}
        if labels:
            fields["labels"] = labels

        with track_integration_request("jira", "create_issue"):
            data = await self._async_request("POST", "/issue", {"fields": fields})
        if not data:
            return IssueResult(ok=False, detail="Failed to create Jira issue")

        issue_key = data.get("key", "")
        issue_id = data.get("id", "")
        url = f"{self._base}/browse/{issue_key}" if issue_key else ""

        return IssueResult(
            ok=True,
            issue_id=str(issue_id),
            issue_key=issue_key,
            url=url,
        )

    async def validate_config(self) -> bool:
        """Validate Jira connection by fetching server info."""
        data = await self._async_request("GET", "/serverInfo")
        return data is not None
