"""Trello issue tracker — REST API integration."""

from __future__ import annotations

import asyncio
import json
import logging
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

from owlmind.integrations.issue_trackers.base import IssueResult, IssueTracker

logger = logging.getLogger(__name__)


class TrelloTracker(IssueTracker):
    """Trello integration via REST API.

    Uses API key + token for authentication.
    """

    def __init__(
        self,
        api_key: str,
        token: str,
        timeout: int = 15,
    ) -> None:
        self._api_key = api_key
        self._token = token
        self._timeout = timeout
        self._base = "https://api.trello.com/1"

    @property
    def tracker_type(self) -> str:
        return "trello"

    def _auth_params(self) -> dict[str, str]:
        return {"key": self._api_key, "token": self._token}

    def _request(
        self,
        method: str,
        path: str,
        data: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        """Synchronous HTTP request to Trello API."""
        params = self._auth_params()
        if data:
            params.update({k: str(v) for k, v in data.items() if not isinstance(v, list)})
            # Handle list params (labels, members)
            for k, v in data.items():
                if isinstance(v, list):
                    params[k] = ",".join(str(i) for i in v)

        url = f"{self._base}{path}?{urllib.parse.urlencode(params)}"
        req = urllib.request.Request(url, method=method)
        # Trello POST uses query params, not body
        try:
            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                raw = resp.read().decode()
                return json.loads(raw) if raw else {}
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode(errors="replace") if exc.fp else ""
            logger.error("Trello API %s %s → %s: %s", method, path, exc.code, detail)
            return None
        except urllib.error.URLError as exc:
            logger.error("Trello API %s %s network error: %s", method, path, exc.reason)
            return None

    async def _async_request(
        self, method: str, path: str, data: dict[str, Any] | None = None
    ) -> dict[str, Any] | None:
        return await asyncio.to_thread(self._request, method, path, data)

    async def create_issue(self, params: dict[str, Any]) -> IssueResult:
        """Create a Trello card.

        Expected params:
            list_id: ID of the Trello list to add the card to
            name: Card name/title
            desc: Card description (optional)
            pos: Position — "top", "bottom", or a number (optional)
            idLabels: List of label IDs (optional)
            idMembers: List of member IDs (optional)
        """
        from owlmind.monitoring.metrics import track_integration_request

        list_id = params.get("list_id", "")
        name = params.get("name", "")
        if not list_id or not name:
            return IssueResult(ok=False, detail="Missing 'list_id' or 'name'")

        card_data: dict[str, Any] = {
            "idList": list_id,
            "name": name,
        }
        if desc := params.get("desc", ""):
            card_data["desc"] = desc
        if pos := params.get("pos", ""):
            card_data["pos"] = pos
        if labels := params.get("idLabels", []):
            card_data["idLabels"] = labels
        if members := params.get("idMembers", []):
            card_data["idMembers"] = members

        with track_integration_request("trello", "create_issue"):
            data = await self._async_request("POST", "/cards", card_data)
        if not data:
            return IssueResult(ok=False, detail="Failed to create Trello card")

        return IssueResult(
            ok=True,
            issue_id=data.get("id", ""),
            issue_key=data.get("shortLink", ""),
            url=data.get("shortUrl", ""),
        )

    async def validate_config(self) -> bool:
        """Validate Trello connection by fetching current member info."""
        data = await self._async_request("GET", "/members/me")
        return data is not None
