"""Linear integration tools — create/update issues, list projects."""
from __future__ import annotations

import logging
import os
from typing import Any

logger = logging.getLogger(__name__)

_REQUESTS_AVAILABLE = False
try:
    import requests
    _REQUESTS_AVAILABLE = True
except ImportError:
    pass

LINEAR_API = "https://api.linear.app/graphql"


def _linear_query(query: str, variables: dict[str, Any] | None = None) -> dict[str, Any]:
    """Execute a Linear GraphQL query."""
    if not _REQUESTS_AVAILABLE:
        msg = "requests required: pip install requests"
        raise ImportError(msg)
    api_key = os.environ.get("LINEAR_API_KEY", "")
    if not api_key:
        msg = "LINEAR_API_KEY env var not set"
        raise RuntimeError(msg)
    resp = requests.post(
        LINEAR_API,
        json={"query": query, "variables": variables or {}},
        headers={"Authorization": api_key, "Content-Type": "application/json"},
        timeout=15,
    )
    resp.raise_for_status()
    data = resp.json()
    if "errors" in data:
        msg = f"Linear API error: {data['errors']}"
        raise RuntimeError(msg)
    return data.get("data", {})


def linear_create_issue(team_id: str, title: str, description: str = "", priority: int = 0) -> dict[str, Any]:
    """Create a new Linear issue."""
    mutation = """
    mutation CreateIssue($teamId: String!, $title: String!, $description: String, $priority: Int) {
        issueCreate(input: {teamId: $teamId, title: $title, description: $description, priority: $priority}) {
            issue { id identifier title url }
        }
    }
    """
    result = _linear_query(mutation, {"teamId": team_id, "title": title, "description": description, "priority": priority})
    issue = result.get("issueCreate", {}).get("issue", {})
    return {"id": issue.get("id", ""), "identifier": issue.get("identifier", ""), "title": title, "url": issue.get("url", "")}


def linear_list_issues(team_id: str | None = None, limit: int = 10) -> dict[str, Any]:
    """List recent Linear issues."""
    query = """
    query ListIssues($first: Int) {
        issues(first: $first, orderBy: updatedAt) {
            nodes { id identifier title state { name } priority url }
        }
    }
    """
    result = _linear_query(query, {"first": limit})
    issues = [
        {
            "id": i["id"],
            "identifier": i["identifier"],
            "title": i["title"],
            "state": i.get("state", {}).get("name", ""),
            "priority": i.get("priority", 0),
            "url": i.get("url", ""),
        }
        for i in result.get("issues", {}).get("nodes", [])
    ]
    return {"issues": issues, "count": len(issues)}


def register_linear_tools(registry: Any) -> None:
    from owlmind.integrations.tools import IntegrationTool

    registry.register(IntegrationTool(
        name="linear_create_issue",
        description="Create a new issue in Linear project management.",
        category="linear",
        input_schema={
            "type": "object",
            "properties": {
                "team_id": {"type": "string", "description": "Linear team ID"},
                "title": {"type": "string", "description": "Issue title"},
                "description": {"type": "string", "description": "Issue description", "default": ""},
                "priority": {"type": "integer", "description": "Priority 0-4 (0=no, 1=urgent, 2=high, 3=medium, 4=low)", "default": 0},
            },
            "required": ["team_id", "title"],
        },
        handler=linear_create_issue,
        requires_env=["LINEAR_API_KEY"],
    ))

    registry.register(IntegrationTool(
        name="linear_list_issues",
        description="List recent Linear issues.",
        category="linear",
        input_schema={
            "type": "object",
            "properties": {
                "limit": {"type": "integer", "default": 10},
            },
        },
        handler=linear_list_issues,
        requires_env=["LINEAR_API_KEY"],
    ))
