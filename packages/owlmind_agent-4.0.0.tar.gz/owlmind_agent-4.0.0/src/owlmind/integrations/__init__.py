"""OWLMIND integrations — external service connectors."""
from __future__ import annotations

from owlmind.integrations.tools import IntegrationTool, ToolRegistry, registry


def register_all_tools() -> ToolRegistry:
    """Register all available integration tools in the global registry."""
    from owlmind.integrations.linear_tools import register_linear_tools
    from owlmind.integrations.notion_tools import register_notion_tools
    from owlmind.integrations.slack_tools import register_slack_tools

    register_slack_tools(registry)
    register_notion_tools(registry)
    register_linear_tools(registry)

    return registry


__all__ = ["IntegrationTool", "ToolRegistry", "registry", "register_all_tools"]
