"""Notion integration tools — read/write pages and databases."""
from __future__ import annotations

import logging
import os
from typing import Any

logger = logging.getLogger(__name__)

_REQUESTS_AVAILABLE = False
try:
    import requests
    _REQUESTS_AVAILABLE = True
except ImportError:
    pass

NOTION_API = "https://api.notion.com/v1"
NOTION_VERSION = "2022-06-28"


def _notion_headers() -> dict[str, str]:
    token = os.environ.get("NOTION_API_KEY", "")
    if not token:
        msg = "NOTION_API_KEY env var not set"
        raise RuntimeError(msg)
    return {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "Notion-Version": NOTION_VERSION,
    }


def notion_search(query: str, limit: int = 5) -> dict[str, Any]:
    """Search Notion workspace for pages and databases."""
    if not _REQUESTS_AVAILABLE:
        msg = "requests required: pip install requests"
        raise ImportError(msg)
    resp = requests.post(
        f"{NOTION_API}/search",
        json={"query": query, "page_size": limit},
        headers=_notion_headers(),
        timeout=15,
    )
    resp.raise_for_status()
    data = resp.json()
    results = []
    for item in data.get("results", []):
        obj_type = item.get("object", "")
        title = ""
        if obj_type == "page":
            props = item.get("properties", {})
            title_prop = props.get("title", props.get("Name", {}))
            title_list = title_prop.get("title", []) if isinstance(title_prop, dict) else []
            title = "".join(t.get("plain_text", "") for t in title_list)
        elif obj_type == "database":
            title_list = item.get("title", [])
            title = "".join(t.get("plain_text", "") for t in title_list)
        results.append({"id": item["id"], "type": obj_type, "title": title, "url": item.get("url", "")})
    return {"results": results, "count": len(results)}


def notion_get_page(page_id: str) -> dict[str, Any]:
    """Get a Notion page content."""
    if not _REQUESTS_AVAILABLE:
        msg = "requests required"
        raise ImportError(msg)
    # Get blocks (content)
    resp = requests.get(
        f"{NOTION_API}/blocks/{page_id}/children",
        headers=_notion_headers(),
        timeout=15,
    )
    resp.raise_for_status()
    blocks = resp.json().get("results", [])

    # Extract text from blocks
    text_parts = []
    for block in blocks:
        btype = block.get("type", "")
        block_data = block.get(btype, {})
        rich_text = block_data.get("rich_text", [])
        text = "".join(t.get("plain_text", "") for t in rich_text)
        if text:
            text_parts.append(text)

    return {"page_id": page_id, "content": "\n".join(text_parts), "blocks": len(blocks)}


def notion_create_page(parent_id: str, title: str, content: str = "") -> dict[str, Any]:
    """Create a new Notion page."""
    if not _REQUESTS_AVAILABLE:
        msg = "requests required"
        raise ImportError(msg)

    children = []
    if content:
        for paragraph in content.split("\n\n")[:20]:
            if paragraph.strip():
                children.append({
                    "object": "block",
                    "type": "paragraph",
                    "paragraph": {
                        "rich_text": [{"type": "text", "text": {"content": paragraph[:2000]}}]
                    },
                })

    payload = {
        "parent": {"page_id": parent_id},
        "properties": {
            "title": {"title": [{"type": "text", "text": {"content": title}}]}
        },
        "children": children,
    }
    resp = requests.post(f"{NOTION_API}/pages", json=payload, headers=_notion_headers(), timeout=15)
    resp.raise_for_status()
    data = resp.json()
    return {"page_id": data["id"], "url": data.get("url", ""), "title": title}


def register_notion_tools(registry: Any) -> None:
    from owlmind.integrations.tools import IntegrationTool

    registry.register(IntegrationTool(
        name="notion_search",
        description="Search Notion workspace for pages and databases.",
        category="notion",
        input_schema={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query"},
                "limit": {"type": "integer", "default": 5},
            },
            "required": ["query"],
        },
        handler=notion_search,
        requires_env=["NOTION_API_KEY"],
    ))

    registry.register(IntegrationTool(
        name="notion_get_page",
        description="Get content of a Notion page by ID.",
        category="notion",
        input_schema={
            "type": "object",
            "properties": {
                "page_id": {"type": "string", "description": "Notion page ID (UUID)"},
            },
            "required": ["page_id"],
        },
        handler=notion_get_page,
        requires_env=["NOTION_API_KEY"],
    ))

    registry.register(IntegrationTool(
        name="notion_create_page",
        description="Create a new page in Notion.",
        category="notion",
        input_schema={
            "type": "object",
            "properties": {
                "parent_id": {"type": "string", "description": "Parent page ID"},
                "title": {"type": "string", "description": "Page title"},
                "content": {"type": "string", "description": "Page content (markdown-like text)", "default": ""},
            },
            "required": ["parent_id", "title"],
        },
        handler=notion_create_page,
        requires_env=["NOTION_API_KEY"],
    ))
