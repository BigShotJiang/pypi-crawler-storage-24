"""Unified integration tools registry — Composio-style tool catalog for AI agents."""
from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)


class IntegrationTool:
    """A single callable integration tool."""

    def __init__(
        self,
        name: str,
        description: str,
        category: str,
        input_schema: dict[str, Any],
        handler: Any,  # callable
        requires_env: list[str] | None = None,
    ) -> None:
        self.name = name
        self.description = description
        self.category = category
        self.input_schema = input_schema
        self.handler = handler
        self.requires_env = requires_env or []

    def is_available(self) -> bool:
        """Check if required env vars are set."""
        import os
        return all(os.environ.get(k) for k in self.requires_env)

    def call(self, **kwargs: Any) -> dict[str, Any]:
        """Execute the tool and return result."""
        return self.handler(**kwargs)

    def to_claude_tool(self) -> dict[str, Any]:
        """Convert to Claude API tool definition format."""
        return {
            "name": self.name,
            "description": self.description,
            "input_schema": self.input_schema,
        }


class ToolRegistry:
    """Registry of all available integration tools."""

    def __init__(self) -> None:
        self._tools: dict[str, IntegrationTool] = {}

    def register(self, tool: IntegrationTool) -> None:
        self._tools[tool.name] = tool

    def get(self, name: str) -> IntegrationTool | None:
        return self._tools.get(name)

    def list_tools(self, category: str | None = None, available_only: bool = False) -> list[IntegrationTool]:
        tools = list(self._tools.values())
        if category:
            tools = [t for t in tools if t.category == category]
        if available_only:
            tools = [t for t in tools if t.is_available()]
        return tools

    def call(self, name: str, **kwargs: Any) -> dict[str, Any]:
        """Call a tool by name."""
        tool = self.get(name)
        if not tool:
            return {"error": f"Tool not found: {name}"}
        if not tool.is_available():
            missing = [k for k in tool.requires_env if not __import__("os").environ.get(k)]
            return {"error": f"Missing env vars: {missing}"}
        try:
            return tool.call(**kwargs)
        except Exception as e:
            logger.exception("Tool %s failed", name)
            return {"error": str(e)}

    def to_claude_tools(self, category: str | None = None) -> list[dict[str, Any]]:
        """Get all tools in Claude API format."""
        return [t.to_claude_tool() for t in self.list_tools(category=category)]


# Global registry instance
registry = ToolRegistry()
