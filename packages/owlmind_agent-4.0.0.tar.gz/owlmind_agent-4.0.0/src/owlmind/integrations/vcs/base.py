"""Abstract VCS provider interface and shared models."""

from __future__ import annotations

import enum
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


class CommitStatus(enum.StrEnum):
    """VCS commit/build status values."""

    pending = "pending"
    running = "running"
    success = "success"
    failed = "failed"
    cancelled = "cancelled"


@dataclass
class VCSConfig:
    """Common configuration for all VCS providers."""

    vcs_type: str
    token: str
    base_url: str
    timeout: int = 15


@dataclass
class MRInfo:
    """Merge/pull request information."""

    id: int
    title: str
    description: str = ""
    state: str = "open"
    source_branch: str = ""
    target_branch: str = ""
    author: str = ""
    url: str = ""
    sha: str = ""
    modified_files: list[str] = field(default_factory=list)


@dataclass
class StatusResult:
    """Result of setting a commit status."""

    ok: bool
    detail: str = ""


@dataclass
class CommentResult:
    """Result of posting a comment."""

    ok: bool
    comment_id: str = ""
    detail: str = ""


class VCSProvider(ABC):
    """Abstract base class for VCS platform integration.

    Implementations must provide methods for interacting with merge/pull
    requests, posting comments, and setting commit statuses.
    """

    def __init__(self, config: VCSConfig) -> None:
        self.config = config

    @property
    def vcs_type(self) -> str:
        return self.config.vcs_type

    @abstractmethod
    async def get_merge_request(self, repo: str, mr_id: int) -> MRInfo:
        """Fetch merge/pull request details.

        Args:
            repo: Repository in ``owner/name`` format.
            mr_id: Merge request ID or number.

        Returns:
            :class:`MRInfo` with request details.
        """

    @abstractmethod
    async def list_modified_files(self, repo: str, mr_id: int) -> list[str]:
        """List files modified in a merge/pull request.

        Args:
            repo: Repository in ``owner/name`` format.
            mr_id: Merge request ID or number.

        Returns:
            List of file paths relative to repository root.
        """

    @abstractmethod
    async def post_comment(self, repo: str, mr_id: int, body: str) -> CommentResult:
        """Post a comment on a merge/pull request.

        Args:
            repo: Repository in ``owner/name`` format.
            mr_id: Merge request ID or number.
            body: Markdown comment body.
        """

    @abstractmethod
    async def set_status(
        self,
        repo: str,
        sha: str,
        status: CommitStatus,
        description: str = "",
        context: str = "owlmind",
        target_url: str = "",
    ) -> StatusResult:
        """Set a commit status (build/pipeline status).

        Args:
            repo: Repository in ``owner/name`` format.
            sha: Commit SHA to set status on.
            status: One of :class:`CommitStatus` values.
            description: Short description shown in the VCS UI.
            context: Status context/name (e.g. ``"owlmind/review"``).
            target_url: Optional URL for details.
        """

    @abstractmethod
    async def get_file_content(self, repo: str, path: str, ref: str = "HEAD") -> str | None:
        """Fetch raw file content from a repository.

        Args:
            repo: Repository in ``owner/name`` format.
            path: File path relative to repository root.
            ref: Branch, tag, or commit SHA.

        Returns:
            File content as string, or ``None`` if not found.
        """

    async def get_owlmind_config(self, repo: str, ref: str = "HEAD") -> dict[str, Any] | None:
        """Fetch ``.owlmind.yaml`` configuration from a repository.

        Returns:
            Parsed YAML as dict, or ``None`` if not found.
        """
        import yaml

        content = await self.get_file_content(repo, ".owlmind.yaml", ref)
        if content is None:
            return None
        return yaml.safe_load(content)
