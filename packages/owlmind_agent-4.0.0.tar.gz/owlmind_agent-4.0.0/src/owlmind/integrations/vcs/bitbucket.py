"""Bitbucket VCS provider using REST API v2.0."""

from __future__ import annotations

import asyncio
import json
import logging
import urllib.request
from typing import Any

from owlmind.integrations.vcs.base import (
    CommentResult,
    CommitStatus,
    MRInfo,
    StatusResult,
    VCSConfig,
    VCSProvider,
)

logger = logging.getLogger(__name__)

# Bitbucket build status mapping
_BB_STATUS_MAP: dict[CommitStatus, str] = {
    CommitStatus.pending: "INPROGRESS",
    CommitStatus.running: "INPROGRESS",
    CommitStatus.success: "SUCCESSFUL",
    CommitStatus.failed: "FAILED",
    CommitStatus.cancelled: "STOPPED",
}


class BitbucketVCS(VCSProvider):
    """Bitbucket VCS integration via REST API v2.0.

    Uses HTTP Basic Auth with app password / personal access token.
    """

    def __init__(self, config: VCSConfig) -> None:
        super().__init__(config)
        self._base = config.base_url.rstrip("/")

    def _headers(self) -> dict[str, str]:
        # Bitbucket uses Bearer token or Basic auth
        # For app passwords, use Basic auth with username:password
        # For repository/project access tokens, use Bearer
        return {
            "Authorization": f"Bearer {self.config.token}",
            "Content-Type": "application/json",
        }

    def _request(
        self,
        method: str,
        url: str,
        data: dict[str, Any] | None = None,
    ) -> Any:
        """Synchronous HTTP request to Bitbucket API."""
        body = json.dumps(data).encode() if data else None
        req = urllib.request.Request(
            url,
            data=body,
            headers=self._headers(),
            method=method,
        )
        try:
            with urllib.request.urlopen(req, timeout=self.config.timeout) as resp:
                raw = resp.read().decode()
                if not raw:
                    return {}
                return json.loads(raw)
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode(errors="replace") if exc.fp else ""
            logger.error("Bitbucket API %s %s → %s: %s", method, url, exc.code, detail)
            return None

    async def _async_request(
        self, method: str, url: str, data: dict[str, Any] | None = None
    ) -> Any:
        return await asyncio.to_thread(self._request, method, url, data)

    # ── VCSProvider methods ──────────────────────────────────────────

    async def get_merge_request(self, repo: str, mr_id: int) -> MRInfo:
        url = f"{self._base}/repositories/{repo}/pullrequests/{mr_id}"
        data = await self._async_request("GET", url)
        if not data:
            return MRInfo(id=mr_id, title="", state="unknown")

        source = data.get("source", {})
        dest = data.get("destination", {})
        author = data.get("author", {})

        files = await self.list_modified_files(repo, mr_id)
        return MRInfo(
            id=data.get("id", mr_id),
            title=data.get("title", ""),
            description=data.get("description", ""),
            state=data.get("state", ""),
            source_branch=source.get("branch", {}).get("name", ""),
            target_branch=dest.get("branch", {}).get("name", ""),
            author=author.get("display_name", author.get("nickname", "")),
            url=data.get("links", {}).get("html", {}).get("href", ""),
            sha=source.get("commit", {}).get("hash", ""),
            modified_files=files,
        )

    async def list_modified_files(self, repo: str, mr_id: int) -> list[str]:
        url = f"{self._base}/repositories/{repo}/pullrequests/{mr_id}/diffstat"
        data = await self._async_request("GET", url)
        if not data or "values" not in data:
            return []
        return [
            entry.get("new", {}).get("path", entry.get("old", {}).get("path", ""))
            for entry in data["values"]
        ]

    async def post_comment(self, repo: str, mr_id: int, body: str) -> CommentResult:
        url = f"{self._base}/repositories/{repo}/pullrequests/{mr_id}/comments"
        data = await self._async_request("POST", url, {"content": {"raw": body}})
        if not data:
            return CommentResult(ok=False, detail="Failed to post comment")
        return CommentResult(ok=True, comment_id=str(data.get("id", "")))

    async def set_status(
        self,
        repo: str,
        sha: str,
        status: CommitStatus,
        description: str = "",
        context: str = "owlmind",
        target_url: str = "",
    ) -> StatusResult:
        url = f"{self._base}/repositories/{repo}/commit/{sha}/statuses/build"
        bb_state = _BB_STATUS_MAP.get(status, "INPROGRESS")
        payload: dict[str, Any] = {
            "state": bb_state,
            "key": context,
            "name": context,
        }
        if description:
            payload["description"] = description
        if target_url:
            payload["url"] = target_url

        data = await self._async_request("POST", url, payload)
        if not data:
            return StatusResult(ok=False, detail="Failed to set status")
        return StatusResult(ok=True)

    async def get_file_content(self, repo: str, path: str, ref: str = "HEAD") -> str | None:
        url = f"{self._base}/repositories/{repo}/src/{ref}/{path}"
        data = await self._async_request("GET", url)
        if data is None:
            return None
        # Bitbucket src endpoint returns raw content for files
        return str(data) if data else None
