"""VCS integration: abstract interface + GitLab/Bitbucket implementations.

Usage::

    from owlmind.integrations.vcs import create_vcs_client

    client = create_vcs_client("gitlab", token="glpat-...", base_url="https://gitlab.com")
    mr = await client.get_merge_request("user/repo", 42)
"""

from __future__ import annotations

from owlmind.integrations.vcs.base import MRInfo, VCSConfig, VCSProvider
from owlmind.integrations.vcs.bitbucket import BitbucketVCS
from owlmind.integrations.vcs.gitlab import GitLabVCS


def create_vcs_client(
    vcs_type: str,
    token: str,
    base_url: str | None = None,
) -> VCSProvider:
    """Factory for VCS clients.

    Args:
        vcs_type: One of ``"gitlab"`` or ``"bitbucket"``.
        token: Personal access token for the VCS platform.
        base_url: API base URL (optional; defaults to public SaaS URL).

    Returns:
        Configured :class:`VCSProvider` instance.

    Raises:
        ValueError: If *vcs_type* is not supported.
    """
    vcs_type = vcs_type.lower().strip()
    if vcs_type == "gitlab":
        config = VCSConfig(
            vcs_type="gitlab",
            token=token,
            base_url=base_url or "https://gitlab.com",
        )
        return GitLabVCS(config)
    if vcs_type == "bitbucket":
        config = VCSConfig(
            vcs_type="bitbucket",
            token=token,
            base_url=base_url or "https://api.bitbucket.org/2.0",
        )
        return BitbucketVCS(config)
    msg = f"Unsupported VCS type: {vcs_type!r}. Use 'gitlab' or 'bitbucket'."
    raise ValueError(msg)


__all__ = [
    "BitbucketVCS",
    "GitLabVCS",
    "MRInfo",
    "VCSConfig",
    "VCSProvider",
    "create_vcs_client",
]
