"""GitLab VCS provider using REST API v4."""

from __future__ import annotations

import asyncio
import json
import logging
import urllib.parse
import urllib.request
from typing import Any

from owlmind.integrations.vcs.base import (
    CommentResult,
    CommitStatus,
    MRInfo,
    StatusResult,
    VCSConfig,
    VCSProvider,
)

logger = logging.getLogger(__name__)

# GitLab commit status mapping
_GITLAB_STATUS_MAP: dict[CommitStatus, str] = {
    CommitStatus.pending: "pending",
    CommitStatus.running: "running",
    CommitStatus.success: "success",
    CommitStatus.failed: "failed",
    CommitStatus.cancelled: "canceled",
}


class GitLabVCS(VCSProvider):
    """GitLab VCS integration via REST API v4.

    Uses direct HTTP requests (stdlib urllib) — no external dependencies.
    """

    def __init__(self, config: VCSConfig) -> None:
        super().__init__(config)
        self._base = config.base_url.rstrip("/") + "/api/v4"

    def _headers(self) -> dict[str, str]:
        return {
            "PRIVATE-TOKEN": self.config.token,
            "Content-Type": "application/json",
        }

    def _project_id(self, repo: str) -> str:
        """URL-encode a ``owner/name`` project path for GitLab API."""
        return urllib.parse.quote(repo, safe="")

    def _request(
        self,
        method: str,
        path: str,
        data: dict[str, Any] | None = None,
    ) -> Any:
        """Synchronous HTTP request to GitLab API."""
        url = f"{self._base}{path}"
        body = json.dumps(data).encode() if data else None
        req = urllib.request.Request(
            url,
            data=body,
            headers=self._headers(),
            method=method,
        )
        try:
            with urllib.request.urlopen(req, timeout=self.config.timeout) as resp:
                return json.loads(resp.read().decode())
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode(errors="replace") if exc.fp else ""
            logger.error("GitLab API %s %s → %s: %s", method, path, exc.code, detail)
            return None

    async def _async_request(
        self, method: str, path: str, data: dict[str, Any] | None = None
    ) -> Any:
        return await asyncio.to_thread(self._request, method, path, data)

    # ── VCSProvider methods ──────────────────────────────────────────

    async def get_merge_request(self, repo: str, mr_id: int) -> MRInfo:
        pid = self._project_id(repo)
        data = await self._async_request("GET", f"/projects/{pid}/merge_requests/{mr_id}")
        if not data:
            return MRInfo(id=mr_id, title="", state="unknown")

        files = await self.list_modified_files(repo, mr_id)
        return MRInfo(
            id=data.get("iid", mr_id),
            title=data.get("title", ""),
            description=data.get("description", ""),
            state=data.get("state", ""),
            source_branch=data.get("source_branch", ""),
            target_branch=data.get("target_branch", ""),
            author=data.get("author", {}).get("username", ""),
            url=data.get("web_url", ""),
            sha=data.get("sha", ""),
            modified_files=files,
        )

    async def list_modified_files(self, repo: str, mr_id: int) -> list[str]:
        pid = self._project_id(repo)
        data = await self._async_request("GET", f"/projects/{pid}/merge_requests/{mr_id}/changes")
        if not data or "changes" not in data:
            return []
        return [change.get("new_path", change.get("old_path", "")) for change in data["changes"]]

    async def post_comment(self, repo: str, mr_id: int, body: str) -> CommentResult:
        pid = self._project_id(repo)
        data = await self._async_request(
            "POST",
            f"/projects/{pid}/merge_requests/{mr_id}/notes",
            {"body": body},
        )
        if not data:
            return CommentResult(ok=False, detail="Failed to post comment")
        return CommentResult(ok=True, comment_id=str(data.get("id", "")))

    async def set_status(
        self,
        repo: str,
        sha: str,
        status: CommitStatus,
        description: str = "",
        context: str = "owlmind",
        target_url: str = "",
    ) -> StatusResult:
        pid = self._project_id(repo)
        gl_status = _GITLAB_STATUS_MAP.get(status, "pending")
        payload: dict[str, Any] = {
            "state": gl_status,
            "name": context,
        }
        if description:
            payload["description"] = description
        if target_url:
            payload["target_url"] = target_url

        data = await self._async_request(
            "POST",
            f"/projects/{pid}/statuses/{sha}",
            payload,
        )
        if not data:
            return StatusResult(ok=False, detail="Failed to set status")
        return StatusResult(ok=True)

    async def get_file_content(self, repo: str, path: str, ref: str = "HEAD") -> str | None:
        pid = self._project_id(repo)
        encoded_path = urllib.parse.quote(path, safe="")
        data = await self._async_request(
            "GET",
            f"/projects/{pid}/repository/files/{encoded_path}/raw?ref={ref}",
        )
        if data is None:
            return None
        # Raw endpoint returns string content, but _request parses JSON
        # For raw content, need a direct approach
        return str(data) if data else None

    async def get_file_content_raw(self, repo: str, path: str, ref: str = "HEAD") -> str | None:
        """Fetch raw file content (bypasses JSON parsing)."""
        pid = self._project_id(repo)
        encoded_path = urllib.parse.quote(path, safe="")
        url = f"{self._base}/projects/{pid}/repository/files/{encoded_path}/raw?ref={ref}"
        req = urllib.request.Request(url, headers=self._headers(), method="GET")

        def _fetch() -> str | None:
            try:
                with urllib.request.urlopen(req, timeout=self.config.timeout) as resp:
                    return resp.read().decode()
            except urllib.error.HTTPError:
                return None

        return await asyncio.to_thread(_fetch)
