"""Slash command router for ``/owlmind`` Slack slash command.

Supported commands::

    /owlmind help                      — show available commands
    /owlmind run <goal>                — queue a task goal
    /owlmind status [<task_id>]        — show status of last task or specific ID
    /owlmind queue                     — show pending tasks
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class SlashCommandPayload:
    """Parsed Slack slash command payload."""

    command: str          # e.g. "/owlmind"
    text: str             # raw text after the command
    user_id: str          # Slack user ID (U…)
    user_name: str        # Slack username
    channel_id: str       # Channel where the command was issued
    team_id: str          # Slack workspace ID
    response_url: str     # URL for delayed responses
    trigger_id: str = ""  # For opening modals


def parse_payload(form_data: dict[str, Any]) -> SlashCommandPayload:
    """Parse URL-encoded Slack slash command form data into a dataclass.

    Args:
        form_data: Dict from the FastAPI Form or query string parsing.

    Returns:
        Populated :class:`SlashCommandPayload`.
    """
    return SlashCommandPayload(
        command=form_data.get("command", "/owlmind"),
        text=form_data.get("text", "").strip(),
        user_id=form_data.get("user_id", ""),
        user_name=form_data.get("user_name", ""),
        channel_id=form_data.get("channel_id", ""),
        team_id=form_data.get("team_id", ""),
        response_url=form_data.get("response_url", ""),
        trigger_id=form_data.get("trigger_id", ""),
    )


def route_command(payload: SlashCommandPayload) -> dict[str, Any]:
    """Route a slash command to the appropriate handler.

    Returns an immediate Slack response (≤ 3s). Long-running operations
    should use ``response_url`` for a follow-up message.

    Args:
        payload: Parsed slash command payload.

    Returns:
        Slack response dict with ``response_type`` and ``text`` / ``blocks``.
    """
    parts = payload.text.split(maxsplit=1) if payload.text else []
    sub_cmd = parts[0].lower() if parts else "help"
    args = parts[1] if len(parts) > 1 else ""

    if sub_cmd == "run":
        return _handle_run(payload, args)
    if sub_cmd in ("status", "st"):
        return _handle_status(payload, args)
    if sub_cmd == "queue":
        return _handle_queue(payload)
    # Default: help
    return _handle_help(payload)


def _handle_help(payload: SlashCommandPayload) -> dict[str, Any]:
    """Return help text."""
    text = (
        "*OWLMIND Slash Commands*\n"
        "`/owlmind run <goal>` — queue a new task\n"
        "`/owlmind status [id]` — show status of the last or specific task\n"
        "`/owlmind queue` — list pending tasks\n"
        "`/owlmind help` — show this message"
    )
    return {"response_type": "ephemeral", "text": text}


def _handle_run(payload: SlashCommandPayload, goal: str) -> dict[str, Any]:
    """Queue a new task goal. Returns acknowledgement with task ID."""
    if not goal.strip():
        return {
            "response_type": "ephemeral",
            "text": "❌ Please provide a goal. Usage: `/owlmind run <goal>`",
        }

    # Return an immediate ACK; the actual queue insertion happens in the
    # API route which calls queue.add() before returning this response.
    return {
        "response_type": "in_channel",
        "text": (
            f"⏳ *Task queued* by <@{payload.user_id}>\n"
            f"*Goal:* {goal}\n"
            f"You'll be notified when it completes."
        ),
        # Pass goal back to the route handler for queue insertion
        "_goal": goal,
        "_channel": payload.channel_id,
    }


def _handle_status(payload: SlashCommandPayload, task_id: str) -> dict[str, Any]:
    """Return status lookup request. Route fills in actual status."""
    return {
        "response_type": "ephemeral",
        "text": "🔍 Looking up task status…",
        # Pass task_id back for lookup; empty means "last task"
        "_task_id": task_id.strip() if task_id else "",
        "_channel": payload.channel_id,
    }


def _handle_queue(payload: SlashCommandPayload) -> dict[str, Any]:
    """Return queue listing request. Route fills in actual queue items."""
    return {
        "response_type": "ephemeral",
        "text": "📋 Fetching task queue…",
        "_list_queue": True,
        "_channel": payload.channel_id,
    }


def format_task_status(task: dict[str, Any]) -> str:
    """Format a queue item dict into a human-readable Slack message."""
    status = task.get("status", "UNKNOWN")
    icon = {
        "PENDING": "⏳",
        "RUNNING": "🔄",
        "DONE": "✅",
        "FAILED": "❌",
    }.get(status.upper(), "❓")

    goal = task.get("goal", "unknown")[:120]
    task_id = task.get("id", "")
    run_id = task.get("run_id", "")
    created = task.get("created_at", "")[:19]  # trim to YYYY-MM-DDTHH:MM:SS

    lines = [f"{icon} *{status}* — {goal}", f"ID: `{task_id}`"]
    if run_id:
        lines.append(f"Run ID: `{run_id}`")
    if created:
        lines.append(f"Queued: {created}")
    return "\n".join(lines)
