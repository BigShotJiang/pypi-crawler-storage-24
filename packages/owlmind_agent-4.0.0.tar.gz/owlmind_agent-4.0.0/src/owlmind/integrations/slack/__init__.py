"""Slack integration for OWLMIND.

Provides slash command handling (``/owlmind run|status|queue|help``),
signature verification, and a Slack API client for sending messages.

Usage::

    from owlmind.integrations.slack import SlackClient, verify_slack_signature

    client = SlackClient(bot_token="xoxb-...")
    await client.post_message(channel="C123", text="Hello from OWLMIND!")
"""

from __future__ import annotations

from owlmind.integrations.slack.client import SlackClient, SlackMessage
from owlmind.integrations.slack.verifier import (
    SlackSignatureError,
    verify_slack_signature,
)

__all__ = [
    "SlackClient",
    "SlackMessage",
    "SlackSignatureError",
    "verify_slack_signature",
]
