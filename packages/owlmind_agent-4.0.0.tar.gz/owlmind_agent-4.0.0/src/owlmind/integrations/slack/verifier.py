"""Slack request signature verification.

Slack signs every incoming request with HMAC-SHA256 using the app's
signing secret. See:
https://api.slack.com/authentication/verifying-requests-from-slack
"""

from __future__ import annotations

import hashlib
import hmac
import logging
import time

logger = logging.getLogger(__name__)

_MAX_AGE_SECONDS = 300  # 5 minutes — Slack's replay attack window


class SlackSignatureError(Exception):
    """Raised when a Slack request signature cannot be verified."""


def verify_slack_signature(
    *,
    signing_secret: str,
    timestamp: str,
    body: bytes,
    signature: str,
    max_age: int = _MAX_AGE_SECONDS,
) -> None:
    """Verify the X-Slack-Signature header from an incoming Slack request.

    Args:
        signing_secret: The app's signing secret from the Slack dashboard.
        timestamp: Value of the ``X-Slack-Request-Timestamp`` header.
        body: Raw request body bytes.
        signature: Value of the ``X-Slack-Signature`` header (``"v0=..."``).
        max_age: Maximum allowed age of the request in seconds (default 300).

    Raises:
        SlackSignatureError: If the signature is invalid or the request is stale.
    """
    try:
        req_ts = int(timestamp)
    except (ValueError, TypeError) as exc:
        raise SlackSignatureError("Invalid timestamp") from exc

    now = int(time.time())
    if abs(now - req_ts) > max_age:
        raise SlackSignatureError(
            f"Request timestamp too old: {abs(now - req_ts)}s (max {max_age}s)"
        )

    basestring = f"v0:{timestamp}:{body.decode('utf-8', errors='replace')}".encode()
    expected = "v0=" + hmac.new(signing_secret.encode(), basestring, hashlib.sha256).hexdigest()

    if not hmac.compare_digest(expected, signature):
        raise SlackSignatureError("Signature mismatch")
