"""Slack API client — sends messages using stdlib urllib (no external deps)."""

from __future__ import annotations

import asyncio
import json
import logging
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)

_SLACK_API_BASE = "https://slack.com/api"


@dataclass
class SlackMessage:
    """A Slack message payload."""

    channel: str
    text: str
    thread_ts: str = ""
    blocks: list[dict[str, Any]] = field(default_factory=list)
    attachments: list[dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {"channel": self.channel, "text": self.text}
        if self.thread_ts:
            payload["thread_ts"] = self.thread_ts
        if self.blocks:
            payload["blocks"] = self.blocks
        if self.attachments:
            payload["attachments"] = self.attachments
        return payload


class SlackClient:
    """Minimal async Slack API client.

    Uses ``urllib`` (stdlib only) so no extra dependencies are required.
    """

    def __init__(self, bot_token: str, timeout: int = 10) -> None:
        self._token = bot_token
        self._timeout = timeout

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self._token}",
            "Content-Type": "application/json; charset=utf-8",
        }

    def _post_sync(self, method: str, payload: dict[str, Any]) -> dict[str, Any]:
        """Synchronous POST to ``https://slack.com/api/<method>``."""
        url = f"{_SLACK_API_BASE}/{method}"
        body = json.dumps(payload).encode()
        req = urllib.request.Request(
            url,
            data=body,
            headers=self._headers(),
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                data: dict[str, Any] = json.loads(resp.read().decode())
                if not data.get("ok"):
                    logger.warning("Slack API %s error: %s", method, data.get("error", "unknown"))
                return data
        except urllib.error.HTTPError as exc:
            logger.error("Slack API HTTP %s for %s: %s", exc.code, method, exc)
            return {"ok": False, "error": str(exc)}
        except OSError as exc:
            logger.error("Slack API network error for %s: %s", method, exc)
            return {"ok": False, "error": str(exc)}

    async def post_message(
        self,
        channel: str,
        text: str,
        *,
        thread_ts: str = "",
        blocks: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        """Post a message to a Slack channel or DM.

        Args:
            channel: Channel ID (``C…``) or user ID (``U…``) for DMs.
            text: Plain-text fallback / message body.
            thread_ts: Reply to a thread (timestamp of parent message).
            blocks: Optional Block Kit blocks for rich formatting.

        Returns:
            Slack API response dict (contains ``ok`` bool and ``ts`` on success).
        """
        msg = SlackMessage(
            channel=channel,
            text=text,
            thread_ts=thread_ts,
            blocks=blocks or [],
        )
        return await asyncio.to_thread(self._post_sync, "chat.postMessage", msg.to_dict())

    async def respond_url(
        self,
        response_url: str,
        text: str,
        *,
        replace_original: bool = False,
    ) -> dict[str, Any]:
        """Post a delayed response using a slash command ``response_url``.

        This is used to respond after the initial 3-second window.

        Args:
            response_url: The ``response_url`` from the slash command payload.
            text: Response text.
            replace_original: Whether to replace the original ephemeral message.

        Returns:
            HTTP response data.
        """
        payload: dict[str, Any] = {
            "text": text,
            "response_type": "ephemeral",
            "replace_original": replace_original,
        }
        return await asyncio.to_thread(self._post_url_sync, response_url, payload)

    def _post_url_sync(self, url: str, payload: dict[str, Any]) -> dict[str, Any]:
        """POST to a raw URL (response_url)."""
        body = json.dumps(payload).encode()
        req = urllib.request.Request(
            url,
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                raw = resp.read().decode()
                return json.loads(raw) if raw.strip() else {"ok": True}
        except (urllib.error.HTTPError, OSError) as exc:
            logger.error("Slack respond_url error: %s", exc)
            return {"ok": False, "error": str(exc)}
