"""Slack integration tools — send messages, list channels, post to threads."""
from __future__ import annotations

import logging
import os
from typing import Any

logger = logging.getLogger(__name__)

_SLACK_AVAILABLE = False
try:
    import requests
    _SLACK_AVAILABLE = True
except ImportError:
    pass


def _slack_post(endpoint: str, payload: dict[str, Any]) -> dict[str, Any]:
    """Post to Slack API."""
    if not _SLACK_AVAILABLE:
        msg = "requests library required: pip install requests"
        raise ImportError(msg)
    token = os.environ.get("SLACK_BOT_TOKEN", "")
    if not token:
        msg = "SLACK_BOT_TOKEN env var not set"
        raise RuntimeError(msg)
    resp = requests.post(
        f"https://slack.com/api/{endpoint}",
        json=payload,
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        timeout=10,
    )
    data = resp.json()
    if not data.get("ok"):
        msg = f"Slack API error: {data.get('error', 'unknown')}"
        raise RuntimeError(msg)
    return data


def slack_send_message(channel: str, text: str, thread_ts: str = "") -> dict[str, Any]:
    """Send a message to a Slack channel."""
    payload: dict[str, Any] = {"channel": channel, "text": text}
    if thread_ts:
        payload["thread_ts"] = thread_ts
    result = _slack_post("chat.postMessage", payload)
    return {"ok": True, "ts": result.get("ts", ""), "channel": channel}


def slack_list_channels(limit: int = 20) -> dict[str, Any]:
    """List available Slack channels."""
    result = _slack_post("conversations.list", {"limit": limit, "types": "public_channel,private_channel"})
    channels = [
        {"id": c["id"], "name": c["name"], "is_private": c.get("is_private", False)}
        for c in result.get("channels", [])
    ]
    return {"channels": channels, "count": len(channels)}


def slack_get_messages(channel: str, limit: int = 10) -> dict[str, Any]:
    """Get recent messages from a Slack channel."""
    result = _slack_post("conversations.history", {"channel": channel, "limit": limit})
    messages = [
        {"ts": m.get("ts"), "user": m.get("user", "bot"), "text": m.get("text", "")}
        for m in result.get("messages", [])
    ]
    return {"messages": messages, "channel": channel}


def register_slack_tools(registry: Any) -> None:
    """Register Slack tools in the global registry."""
    from owlmind.integrations.tools import IntegrationTool

    registry.register(IntegrationTool(
        name="slack_send_message",
        description="Send a message to a Slack channel or thread.",
        category="slack",
        input_schema={
            "type": "object",
            "properties": {
                "channel": {"type": "string", "description": "Channel ID or name (e.g. #general)"},
                "text": {"type": "string", "description": "Message text"},
                "thread_ts": {"type": "string", "description": "Thread timestamp for replies", "default": ""},
            },
            "required": ["channel", "text"],
        },
        handler=slack_send_message,
        requires_env=["SLACK_BOT_TOKEN"],
    ))

    registry.register(IntegrationTool(
        name="slack_list_channels",
        description="List available Slack channels.",
        category="slack",
        input_schema={
            "type": "object",
            "properties": {
                "limit": {"type": "integer", "description": "Max channels to return", "default": 20},
            },
        },
        handler=slack_list_channels,
        requires_env=["SLACK_BOT_TOKEN"],
    ))

    registry.register(IntegrationTool(
        name="slack_get_messages",
        description="Get recent messages from a Slack channel.",
        category="slack",
        input_schema={
            "type": "object",
            "properties": {
                "channel": {"type": "string", "description": "Channel ID"},
                "limit": {"type": "integer", "default": 10},
            },
            "required": ["channel"],
        },
        handler=slack_get_messages,
        requires_env=["SLACK_BOT_TOKEN"],
    ))
