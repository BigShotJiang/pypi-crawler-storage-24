"""Workspace sandbox — isolated temporary workspace for goal execution.

Creates a temporary copy of the workspace directory for sandbox=True tasks,
ensuring the original workspace is not modified during execution.
Cleans up the temporary directory after execution completes.
"""

from __future__ import annotations

import logging
import shutil
import tempfile
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass
class SandboxConfig:
    """Sandbox configuration."""

    base_dir: str | None = None
    """Base directory for sandbox workspaces (None = system temp)."""

    cleanup_on_exit: bool = True
    """Whether to remove the sandbox directory on cleanup."""

    copy_workspace: bool = True
    """Whether to copy the original workspace into the sandbox."""


class Sandbox:
    """Isolated temporary workspace for safe goal execution.

    Creates a temporary directory, optionally copies the source workspace,
    and provides the sandbox path for execution. Cleanup removes the
    temporary directory.

    Usage::

        sandbox = Sandbox("/path/to/workspace", SandboxConfig())
        sandbox_path = sandbox.setup()
        # ... execute in sandbox_path ...
        sandbox.cleanup()

    Or as context manager::

        with Sandbox("/path/to/workspace") as sb:
            # sb.path is the sandbox workspace
            run_in(sb.path)
    """

    def __init__(
        self,
        source_workspace: str,
        config: SandboxConfig | None = None,
    ) -> None:
        self._source = Path(source_workspace)
        self._config = config or SandboxConfig()
        self._sandbox_dir: Path | None = None
        self._workspace_path: Path | None = None

    @property
    def path(self) -> Path:
        """Path to the sandbox workspace directory.

        Raises RuntimeError if sandbox has not been set up yet.
        """
        if self._workspace_path is None:
            msg = "Sandbox not set up. Call setup() first."
            raise RuntimeError(msg)
        return self._workspace_path

    def setup(self) -> Path:
        """Create the sandbox workspace.

        Returns the path to the sandbox workspace directory.
        """
        if self._sandbox_dir is not None:
            return self.path

        # Create temp directory
        base = self._config.base_dir
        if base:
            Path(base).mkdir(parents=True, exist_ok=True)

        self._sandbox_dir = Path(
            tempfile.mkdtemp(
                prefix="owlmind-sandbox-",
                dir=base,
            )
        )

        if self._config.copy_workspace and self._source.is_dir():
            # Copy workspace contents into sandbox
            workspace_name = self._source.name or "workspace"
            dest = self._sandbox_dir / workspace_name
            shutil.copytree(
                self._source,
                dest,
                symlinks=True,
                ignore=shutil.ignore_patterns(
                    ".git",
                    "__pycache__",
                    "*.pyc",
                    "node_modules",
                    ".venv",
                    "venv",
                ),
            )
            self._workspace_path = dest
        else:
            # Just use the empty temp dir as workspace
            self._workspace_path = self._sandbox_dir

        logger.info(
            "Sandbox created: %s → %s",
            self._source,
            self._workspace_path,
        )

        return self._workspace_path

    def cleanup(self) -> None:
        """Remove the sandbox directory."""
        if self._sandbox_dir is None:
            return

        if not self._config.cleanup_on_exit:
            logger.info("Sandbox retained (cleanup_on_exit=False): %s", self._sandbox_dir)
            return

        try:
            shutil.rmtree(self._sandbox_dir)
            logger.info("Sandbox cleaned up: %s", self._sandbox_dir)
        except OSError as exc:
            logger.warning("Sandbox cleanup failed: %s", exc)
        finally:
            self._sandbox_dir = None
            self._workspace_path = None

    def __enter__(self) -> Sandbox:
        self.setup()
        return self

    def __exit__(self, *args: object) -> None:
        self.cleanup()
