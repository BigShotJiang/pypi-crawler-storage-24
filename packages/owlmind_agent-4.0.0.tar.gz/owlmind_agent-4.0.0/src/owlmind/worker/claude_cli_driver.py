"""Claude Code CLI worker driver — runs ``claude -p`` to produce WorkerReport."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from owlmind.policy import PolicyEngine
from owlmind.tools.shell import ShellTool
from owlmind.utils import ToolLimits, sha256

logger = logging.getLogger(__name__)

# JSON schema for worker report structured output
WORKER_REPORT_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "run_id": {"type": "string"},
        "iteration": {"type": "integer"},
        "status": {"type": "string"},
        "done_summary": {"type": "array", "items": {"type": "string"}},
        "questions": {"type": "array", "items": {"type": "string"}},
        "commands_run": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "cmd": {"type": "string"},
                    "exit_code": {"type": "integer"},
                    "summary": {"type": "string"},
                },
                "required": ["cmd", "exit_code", "summary"],
            },
        },
    },
    "required": ["run_id", "iteration", "status", "done_summary", "questions", "commands_run"],
    "additionalProperties": False,
}


def _extract_json(text: str) -> dict[str, Any]:
    """Extract JSON object from text that may contain extra commentary.

    Finds the first ``{`` and last ``}`` and attempts ``json.loads``.
    """
    first_brace = text.find("{")
    last_brace = text.rfind("}")
    if first_brace == -1 or last_brace == -1 or last_brace <= first_brace:
        msg = "No JSON object found in output"
        raise ValueError(msg)
    result: dict[str, Any] = json.loads(text[first_brace : last_brace + 1])
    return result


class ClaudeCLIDriver:
    """Worker driver that uses the Claude Code CLI (``claude -p``)."""

    def __init__(
        self,
        policy: PolicyEngine,
        *,
        limits: ToolLimits | None = None,
        continue_mode: bool = False,
    ) -> None:
        self._policy = policy
        self._limits = limits or ToolLimits()
        self._continue_mode = continue_mode

    @property
    def name(self) -> str:
        return "claude_code_cli"

    def _build_prompt(self, worker_request: dict[str, Any]) -> str:
        """Build the prompt string sent to ``claude -p``."""
        req_json = json.dumps(worker_request, indent=2)
        return (
            "You are a Worker executing a OWLMIND cycle task. "
            "Execute the instructions below and return ONLY valid JSON "
            "matching the WorkerReport schema. "
            "Do NOT include any markdown, commentary, or text outside the JSON.\n\n"
            f"WorkerRequest:\n{req_json}\n\n"
            "Return JSON with these exact fields:\n"
            '{"run_id": "...", "iteration": N, "status": "READY_FOR_VERIFY", '
            '"done_summary": ["..."], "questions": [], '
            '"commands_run": [{"cmd": "...", "exit_code": 0, "summary": "..."}]}'
        )

    def run(
        self,
        worker_request: dict[str, Any],
        schema: dict[str, Any],
        cwd: Path,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Run Claude Code CLI and parse the output as WorkerReport."""
        prompt = self._build_prompt(worker_request)

        # Build claude command
        escaped_prompt = prompt.replace("'", "'\\''")
        if self._continue_mode:
            command = f"claude -c -p --dangerously-skip-permissions '{escaped_prompt}'"
        else:
            command = f"claude -p --dangerously-skip-permissions '{escaped_prompt}'"

        shell = ShellTool(policy=self._policy, limits=self._limits, cwd=str(cwd))
        result = shell.run(command)

        raw_output = result.stdout
        raw_sha = sha256(raw_output)

        meta: dict[str, Any] = {
            "provider": "claude_code_cli",
            "exit_code": result.exit_code,
            "duration_ms": result.duration_ms,
            "raw_output_sha256": raw_sha,
            "parsed_ok": False,
        }

        if result.exit_code != 0:
            logger.warning(
                "Claude CLI exited with code %d: %s",
                result.exit_code,
                result.stderr[:200],
            )
            meta["stderr"] = result.stderr[:500]
            msg = f"Claude CLI failed (exit {result.exit_code}): {result.stderr[:200]}"
            raise RuntimeError(msg)

        # Parse JSON from output
        try:
            parsed = _extract_json(raw_output)
            meta["parsed_ok"] = True
        except (ValueError, json.JSONDecodeError) as exc:
            logger.warning("Failed to parse Claude CLI output as JSON: %s", exc)
            msg = f"Failed to parse Claude CLI output: {exc}"
            raise RuntimeError(msg) from exc

        return parsed, meta
