"""Manual worker driver — no-op, returns instructions only."""

from __future__ import annotations

from pathlib import Path
from typing import Any


class ManualWorkerDriver:
    """No-op driver that returns instructions for manual worker execution."""

    @property
    def name(self) -> str:
        return "manual"

    def run(
        self,
        worker_request: dict[str, Any],
        schema: dict[str, Any],
        cwd: Path,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Always raises — manual workers must paste results into inbox."""
        msg = (
            "Manual worker mode: paste worker_prompt.md into Claude Code, "
            "then save worker_report.json to the inbox directory."
        )
        raise RuntimeError(msg)
