"""Distributed worker service — polls queue, executes goals via autopilot.

Consumes tasks dispatched by the Scheduler, runs each through the full
Planner → Worker → Judge cycle, and reports results back to QueueStorage.

Start via::

    owlmind worker start --backend file --max-concurrent 2

Requires: a running QueueStorage backend (file or RabbitMQ) and
RunStorage/LedgerStorage for autopilot execution.
"""

from __future__ import annotations

import asyncio
import logging
import signal
import uuid
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from owlmind.monitoring.metrics import worker_metrics
from owlmind.storage.interface import StorageBackend

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------


@dataclass
class WorkerConfig:
    """Worker service runtime configuration."""

    poll_interval: float = 5.0
    """Seconds between queue polls when idle."""

    max_concurrent: int = 1
    """Maximum number of tasks to execute in parallel."""

    auto_approve: bool = True
    """Auto-approve worker gates in autopilot (skip human approval)."""

    max_steps: int = 200
    """Maximum autopilot steps per task."""

    use_llm: str = "both"
    """LLM routing: none | planner | judge | both."""

    use_worker: str = "claude_cli"
    """Worker driver: none | claude_cli."""

    sandbox_base: str = ""
    """Base directory for sandbox workspaces (empty = system temp)."""

    enable_sandbox: bool = True
    """Create isolated workspace for sandbox=True tasks."""

    agent_id: str = ""
    """Agent ID for registry tracking (empty = anonymous worker)."""

    skill_packs_dir: str = ""
    """Directory containing local skill packs for context injection."""


@dataclass
class WorkerTickResult:
    """Statistics from one worker tick."""

    tasks_picked: int = 0
    tasks_completed: int = 0
    tasks_failed: int = 0
    tasks_skipped: int = 0


@dataclass
class WorkerStats:
    """Cumulative worker statistics."""

    total_picked: int = 0
    total_completed: int = 0
    total_failed: int = 0
    active_tasks: int = 0
    ticks: int = 0


# ---------------------------------------------------------------------------
# Worker service
# ---------------------------------------------------------------------------


class WorkerService:
    """Distributed worker that polls queue and executes goals.

    Picks PENDING items from QueueStorage, runs each through autopilot,
    and marks them DONE or FAILED for the Scheduler to collect.
    """

    def __init__(
        self,
        storage: StorageBackend,
        config: WorkerConfig | None = None,
        *,
        on_event: Callable[[dict[str, Any]], None] | None = None,
    ) -> None:
        self._storage = storage
        self._config = config or WorkerConfig()
        self._on_event = on_event
        self._shutdown = False
        self._semaphore = asyncio.Semaphore(self._config.max_concurrent)
        self._active_tasks: set[str] = set()
        self._stats = WorkerStats()
        self._running_tasks: set[asyncio.Task[None]] = set()

    @property
    def stats(self) -> WorkerStats:
        """Current cumulative statistics."""
        return self._stats

    # ------------------------------------------------------------------
    # Main loop
    # ------------------------------------------------------------------

    async def run(self) -> None:
        """Main worker loop. Runs until shutdown signal."""
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(sig, self._handle_signal)

        # Register agent if configured
        if self._config.agent_id and self._storage.agent_registry is not None:
            import socket

            await self._storage.agent_registry.register_agent(
                self._config.agent_id,
                hostname=socket.gethostname(),
                max_concurrent=self._config.max_concurrent,
            )

        logger.info(
            "Worker started (poll_interval=%.1fs, max_concurrent=%d, agent_id=%s)",
            self._config.poll_interval,
            self._config.max_concurrent,
            self._config.agent_id or "(anonymous)",
        )

        while not self._shutdown:
            try:
                result = await self._tick()
                self._stats.ticks += 1
                worker_metrics.ticks_total.inc()
                # Update metrics from tick result
                if result.tasks_picked:
                    worker_metrics.tasks_picked.inc(result.tasks_picked)
                if result.tasks_completed:
                    worker_metrics.tasks_completed.inc(result.tasks_completed)
                if result.tasks_failed:
                    worker_metrics.tasks_failed.inc(result.tasks_failed)
                worker_metrics.active_tasks.set(len(self._active_tasks))
                if result.tasks_picked or result.tasks_completed or result.tasks_failed:
                    logger.info(
                        "tick: picked=%d completed=%d failed=%d",
                        result.tasks_picked,
                        result.tasks_completed,
                        result.tasks_failed,
                    )
            except Exception:
                logger.exception("Worker tick error")

            await asyncio.sleep(self._config.poll_interval)

        # Wait for active tasks to finish
        if self._running_tasks:
            logger.info("Waiting for %d active task(s) to finish...", len(self._running_tasks))
            await asyncio.gather(*self._running_tasks, return_exceptions=True)

        # Deregister agent on shutdown
        if self._config.agent_id and self._storage.agent_registry is not None:
            try:
                await self._storage.agent_registry.set_status(
                    self._config.agent_id, "offline", current_tasks=0
                )
            except Exception:
                logger.debug("Could not update agent status on shutdown", exc_info=True)

        logger.info("Worker shut down")

    def _handle_signal(self) -> None:
        """Signal handler for graceful shutdown."""
        logger.info("Shutdown signal received")
        self._shutdown = True

    async def shutdown(self) -> None:
        """Programmatic graceful shutdown."""
        self._shutdown = True

    # ------------------------------------------------------------------
    # Tick — one polling cycle
    # ------------------------------------------------------------------

    async def _tick(self) -> WorkerTickResult:
        """One worker tick: pick pending tasks and start execution."""
        result = WorkerTickResult()

        # Clean up completed tasks
        done_tasks = {t for t in self._running_tasks if t.done()}
        for t in done_tasks:
            self._running_tasks.discard(t)
            # Propagate exceptions for logging
            if t.exception() is not None:
                logger.error("Background task error: %s", t.exception())

        # How many slots available?
        available = self._config.max_concurrent - len(self._active_tasks)
        if available <= 0:
            result.tasks_skipped = 1
            return result

        # Pick pending tasks up to available slots
        for _ in range(available):
            if self._shutdown:
                break

            item = await self._storage.queue.next_pending()
            if item is None:
                break

            item_id = getattr(item, "id", "")
            if not item_id:
                continue

            # Skip items already being processed
            if item_id in self._active_tasks:
                continue

            result.tasks_picked += 1
            self._stats.total_picked += 1
            self._active_tasks.add(item_id)
            self._stats.active_tasks = len(self._active_tasks)

            # Generate run_id for this execution
            run_id = f"run-{uuid.uuid4().hex[:12]}"

            # Mark as RUNNING in queue
            await self._storage.queue.mark_running(item_id, run_id)

            self._emit(
                {
                    "type": "task_picked",
                    "item_id": item_id,
                    "run_id": run_id,
                    "goal": getattr(item, "goal", ""),
                    "session_id": getattr(item, "session_id", ""),
                    "goal_id": getattr(item, "goal_id", ""),
                }
            )

            # Launch execution in background
            task = asyncio.create_task(
                self._execute_and_report(item, run_id),
                name=f"worker-{item_id}",
            )
            self._running_tasks.add(task)

        return result

    # ------------------------------------------------------------------
    # Task execution
    # ------------------------------------------------------------------

    async def _execute_and_report(self, item: Any, run_id: str) -> None:
        """Execute a queue item and report results back to queue."""
        import time as _time

        item_id = getattr(item, "id", "")
        goal = getattr(item, "goal", "")
        workspace = getattr(item, "workspace", ".")
        sandbox = getattr(item, "sandbox", False)
        session_id = getattr(item, "session_id", "")
        goal_id = getattr(item, "goal_id", "")

        # Resolve skill_pack from session goal if available
        skill_pack = await self._resolve_skill_pack(session_id, goal_id)

        _task_start = _time.monotonic()
        async with self._semaphore:
            # Update agent status
            if self._config.agent_id and self._storage.agent_registry is not None:
                try:
                    await self._storage.agent_registry.set_status(
                        self._config.agent_id,
                        "busy",
                        current_tasks=len(self._active_tasks),
                    )
                except Exception:
                    logger.debug("Could not update agent status", exc_info=True)

            try:
                logger.info(
                    "Executing task %s (run=%s, goal=%s)",
                    item_id,
                    run_id,
                    goal[:80],
                )

                # Run autopilot in thread (it's synchronous)
                ap_result = await asyncio.to_thread(
                    self._run_autopilot,
                    goal=goal,
                    workspace=workspace,
                    sandbox=sandbox,
                    run_id=run_id,
                    skill_pack=skill_pack,
                )

                final_state = ap_result.get("final_state", "")
                stop_reason = ap_result.get("stop_reason", "")

                if final_state == "DONE":
                    await self._storage.queue.mark_done(item_id)
                    self._stats.total_completed += 1
                    self._emit(
                        {
                            "type": "task_completed",
                            "item_id": item_id,
                            "run_id": run_id,
                            "session_id": session_id,
                            "goal_id": goal_id,
                            "final_state": final_state,
                        }
                    )
                    logger.info("Task %s completed (run=%s)", item_id, run_id)
                else:
                    error_msg = f"Autopilot ended with state={final_state}: {stop_reason}"
                    await self._storage.queue.mark_failed(item_id, error_msg)
                    self._stats.total_failed += 1
                    self._emit(
                        {
                            "type": "task_failed",
                            "item_id": item_id,
                            "run_id": run_id,
                            "session_id": session_id,
                            "goal_id": goal_id,
                            "final_state": final_state,
                            "error": error_msg,
                        }
                    )
                    logger.warning("Task %s failed: %s", item_id, error_msg)

            except Exception as exc:
                error_msg = f"Execution error: {exc}"
                await self._storage.queue.mark_failed(item_id, error_msg)
                self._stats.total_failed += 1
                self._emit(
                    {
                        "type": "task_error",
                        "item_id": item_id,
                        "run_id": run_id,
                        "session_id": session_id,
                        "goal_id": goal_id,
                        "error": error_msg,
                    }
                )
                logger.exception("Task %s execution error", item_id)

            finally:
                self._active_tasks.discard(item_id)
                self._stats.active_tasks = len(self._active_tasks)
                worker_metrics.active_tasks.set(len(self._active_tasks))
                worker_metrics.task_duration.observe(_time.monotonic() - _task_start)

                # Update agent status back to idle if no more tasks
                if self._config.agent_id and self._storage.agent_registry is not None:
                    try:
                        new_status = "busy" if self._active_tasks else "idle"
                        await self._storage.agent_registry.set_status(
                            self._config.agent_id,
                            new_status,
                            current_tasks=len(self._active_tasks),
                        )
                    except Exception:
                        logger.debug("Could not update agent status", exc_info=True)

    async def _resolve_skill_pack(self, session_id: str, goal_id: str) -> str:
        """Resolve skill_pack from session goal metadata.

        Returns skill pack ID or empty string.
        """
        if not session_id or not goal_id:
            return ""
        try:
            meta = await self._storage.sessions.load_session(session_id)
            for goal in meta.goals:
                if goal.id == goal_id:
                    return getattr(goal, "skill_pack", "")
        except Exception:
            logger.debug("Could not resolve skill_pack for %s/%s", session_id, goal_id)
        return ""

    def _load_skill_pack_context(self, skill_pack: str) -> str:
        """Load skill pack context for prompt injection.

        Returns context string or empty string if not available.
        """
        if not skill_pack:
            return ""
        if not self._config.skill_packs_dir:
            return ""
        try:
            from pathlib import Path

            from owlmind.skills.registry import get_pack_context

            return get_pack_context(skill_pack, Path(self._config.skill_packs_dir))
        except Exception:
            logger.debug("Could not load skill pack context for %s", skill_pack, exc_info=True)
            return ""

    def _run_autopilot(
        self,
        *,
        goal: str,
        workspace: str,
        sandbox: bool,
        run_id: str,
        skill_pack: str = "",
    ) -> dict[str, Any]:
        """Run autopilot synchronously (called from thread).

        Returns dict with: run_id, final_state, steps, stop_reason.
        """
        from owlmind.autopilot import AutoPilotConfig, AutoPilotResult

        sandbox_ctx = None
        effective_workspace = workspace

        # Setup sandbox if needed
        if sandbox and self._config.enable_sandbox:
            from owlmind.worker.sandbox import Sandbox, SandboxConfig

            sandbox_cfg = SandboxConfig(base_dir=self._config.sandbox_base or None)
            sandbox_ctx = Sandbox(workspace, sandbox_cfg)
            effective_workspace = str(sandbox_ctx.setup())

        # Load skill pack context if specified
        effective_goal = goal
        sp_context = self._load_skill_pack_context(skill_pack)
        if sp_context:
            effective_goal = f"{sp_context}\n\n---\n\n{goal}"

        try:
            config = AutoPilotConfig(
                goal=effective_goal,
                workspace=effective_workspace,
                sandbox=sandbox,
                use_llm=self._config.use_llm,
                use_worker=self._config.use_worker,
                auto_approve=self._config.auto_approve,
                max_steps=self._config.max_steps,
                storage=self._storage,
            )

            result: AutoPilotResult = _run_autopilot_safe(config)

            return {
                "run_id": result.run_id or run_id,
                "final_state": result.final_state,
                "steps": result.steps,
                "stop_reason": result.stop_reason,
            }

        finally:
            if sandbox_ctx is not None:
                sandbox_ctx.cleanup()

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _emit(self, event: dict[str, Any]) -> None:
        """Emit a worker event (if callback registered)."""
        if self._on_event is not None:
            try:
                self._on_event(event)
            except Exception:
                logger.debug("Event callback error", exc_info=True)


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------


def _now_iso() -> str:
    """Current UTC timestamp in ISO format."""
    return datetime.now(UTC).isoformat()


def _run_autopilot_safe(config: Any) -> Any:
    """Run autopilot.run() with exception handling.

    Returns AutoPilotResult. On exception, returns a result with FAILED state.
    """
    from owlmind.autopilot import AutoPilotResult, run

    try:
        return run(config)
    except Exception as exc:
        logger.exception("Autopilot run failed")
        result = AutoPilotResult()
        result.final_state = "FAILED"
        result.stop_reason = f"autopilot exception: {exc}"
        return result
