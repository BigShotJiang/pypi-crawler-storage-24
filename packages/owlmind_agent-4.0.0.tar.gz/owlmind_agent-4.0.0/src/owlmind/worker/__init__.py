"""Worker driver layer — pluggable backends for Worker automation."""
