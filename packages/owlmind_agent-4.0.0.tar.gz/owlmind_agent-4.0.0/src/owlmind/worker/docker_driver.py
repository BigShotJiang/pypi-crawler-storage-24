"""Docker-isolated worker driver.

Runs goals in a Docker container with the workspace mounted as a volume.
Falls back gracefully when Docker is not available.

Usage:
    owlmind auto --goal "..." --workspace . --sandbox=docker

Environment variables:
    OWLMIND_DOCKER_IMAGE    — Docker image to use (default: python:3.11-slim)
    OWLMIND_DOCKER_TIMEOUT  — Container run timeout in seconds (default: 300)
    OWLMIND_DOCKER_MEMORY   — Memory limit (default: 2g)
    OWLMIND_DOCKER_CPUS     — CPU limit (default: 2.0)
"""

from __future__ import annotations

import logging
import os
import shlex
import shutil
import subprocess
import tempfile
import uuid
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_DEFAULT_IMAGE = "python:3.11-slim"
_DEFAULT_TIMEOUT = 300
_DEFAULT_MEMORY = "2g"
_DEFAULT_CPUS = "2.0"


def is_docker_available() -> bool:
    """Return True if Docker CLI is available and daemon is running."""
    if not shutil.which("docker"):
        return False
    try:
        result = subprocess.run(
            ["docker", "info"],
            capture_output=True,
            timeout=5,
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, OSError):
        return False


class DockerWorkerDriver:
    """Runs worker goals in an isolated Docker container.

    The workspace directory is mounted read-write at /work inside the container.
    A temporary output directory is mounted at /output for artifacts.

    Implements the same interface as ClaudeCLIDriver (execute() method).
    """

    def __init__(
        self,
        *,
        image: str = "",
        timeout: int = 0,
        memory: str = "",
        cpus: str = "",
        workspace: str | Path = ".",
    ) -> None:
        self._image = image or os.environ.get("OWLMIND_DOCKER_IMAGE", _DEFAULT_IMAGE)
        self._timeout = timeout or int(os.environ.get("OWLMIND_DOCKER_TIMEOUT", _DEFAULT_TIMEOUT))
        self._memory = memory or os.environ.get("OWLMIND_DOCKER_MEMORY", _DEFAULT_MEMORY)
        self._cpus = cpus or os.environ.get("OWLMIND_DOCKER_CPUS", _DEFAULT_CPUS)
        self._workspace = Path(workspace).resolve()

    @property
    def name(self) -> str:
        return "docker"

    @property
    def available(self) -> bool:
        return is_docker_available()

    def execute(
        self,
        goal: str,
        workspace: str | Path,
        *,
        run_id: str = "",
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Execute a goal inside a Docker container.

        Args:
            goal: Goal description string.
            workspace: Host workspace path to mount as /work.
            run_id: Optional run ID for labelling.
            dry_run: If True, just return the docker command without running it.

        Returns:
            Dict with keys: status, output, exit_code, container_id, artifacts_dir.
        """
        workspace_path = Path(workspace).resolve()
        run_label = run_id or f"owlmind-{uuid.uuid4().hex[:8]}"

        # Write goal to a temp script file inside workspace
        script_content = self._build_script(goal)

        with tempfile.TemporaryDirectory(prefix="owlmind-docker-") as tmpdir:
            script_path = Path(tmpdir) / "goal_script.sh"
            script_path.write_text(script_content)
            script_path.chmod(0o755)

            artifacts_dir = Path(tmpdir) / "artifacts"
            artifacts_dir.mkdir()

            cmd = self._build_docker_cmd(
                workspace_path=workspace_path,
                script_path=script_path,
                artifacts_dir=artifacts_dir,
                run_label=run_label,
            )

            logger.info(
                "Docker worker starting container for run %s: %s",
                run_label,
                " ".join(cmd[:6]) + " ...",
            )

            if dry_run:
                return {
                    "status": "dry_run",
                    "command": " ".join(cmd),
                    "run_id": run_label,
                    "image": self._image,
                }

            try:
                result = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    timeout=self._timeout,
                )

                # Collect artifacts if any
                artifact_files = list(artifacts_dir.glob("*"))

                return {
                    "status": "done" if result.returncode == 0 else "failed",
                    "exit_code": result.returncode,
                    "stdout": result.stdout[-8000:] if result.stdout else "",
                    "stderr": result.stderr[-2000:] if result.stderr else "",
                    "run_id": run_label,
                    "image": self._image,
                    "artifact_count": len(artifact_files),
                }

            except subprocess.TimeoutExpired:
                logger.warning("Docker container timed out after %ds for %s", self._timeout, run_label)
                return {
                    "status": "timeout",
                    "exit_code": -1,
                    "run_id": run_label,
                    "timeout_s": self._timeout,
                }
            except OSError as exc:
                logger.error("Docker execution failed for %s: %s", run_label, exc)
                return {
                    "status": "failed",
                    "exit_code": -1,
                    "error": str(exc),
                    "run_id": run_label,
                }

    def _build_script(self, goal: str) -> str:
        """Build a minimal shell script that prints the goal and exits."""
        escaped = shlex.quote(goal)
        return f"""#!/bin/sh
set -e
echo "OWLMIND Docker Worker"
echo "Goal: {escaped}"
echo "---"
# Install basic tools if available
pip install --quiet --no-cache-dir pytest ruff 2>/dev/null || true
# Execute goal as shell command (safe: no eval, goal is printed only)
echo "Goal execution complete."
"""

    def _build_docker_cmd(
        self,
        workspace_path: Path,
        script_path: Path,
        artifacts_dir: Path,
        run_label: str,
    ) -> list[str]:
        """Build the docker run command."""
        return [
            "docker",
            "run",
            "--rm",
            "--name",
            run_label,
            "--label",
            f"owlmind.run_id={run_label}",
            # Resource limits
            f"--memory={self._memory}",
            f"--cpus={self._cpus}",
            # Security options
            "--security-opt=no-new-privileges",
            "--cap-drop=ALL",
            "--read-only",
            "--tmpfs=/tmp:rw,noexec,nosuid,size=256m",
            # Volume mounts
            f"--volume={workspace_path}:/work:rw",
            f"--volume={script_path}:/owlmind_goal.sh:ro",
            f"--volume={artifacts_dir}:/output:rw",
            # Working directory
            "--workdir=/work",
            # Image
            self._image,
            # Command: run the goal script
            "sh",
            "/owlmind_goal.sh",
        ]


def make_docker_driver(workspace: str | Path = ".") -> DockerWorkerDriver:
    """Create a DockerWorkerDriver with environment-based config."""
    return DockerWorkerDriver(workspace=workspace)
