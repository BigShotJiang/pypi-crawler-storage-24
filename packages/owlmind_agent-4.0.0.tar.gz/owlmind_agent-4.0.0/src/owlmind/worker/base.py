"""Base interface for Worker drivers."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class WorkerDriver(Protocol):
    """Protocol for Worker backends.

    Each method returns ``(worker_report_json, meta)`` where:
    - worker_report_json: parsed JSON dict matching WorkerReport schema
    - meta: provider metadata (exit_code, duration_ms, etc.)
    """

    @property
    def name(self) -> str:
        """Provider name (e.g. 'claude_code_cli', 'manual')."""
        ...

    def run(
        self,
        worker_request: dict[str, Any],
        schema: dict[str, Any],
        cwd: Path,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Execute worker task and return structured report.

        Args:
            worker_request: WorkerRequest data dict.
            schema: JSON schema for output validation.
            cwd: Working directory for command execution.

        Returns:
            (worker_report_json, meta) tuple.
        """
        ...
