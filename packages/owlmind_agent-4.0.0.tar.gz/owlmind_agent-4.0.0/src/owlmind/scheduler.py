"""Distributed scheduler — DAG-aware goal dispatcher for worker pools.

Polls sessions with status RUNNING, computes ready goals via DAG
topology, and enqueues them into QueueStorage for workers to process.
Monitors completion and advances session state.

Start via::

    owlmind scheduler start --backend postgres --postgres-dsn "..."

Requires: a running QueueStorage backend (file or RabbitMQ) and
SessionStorage backend (file or PostgreSQL).
"""

from __future__ import annotations

import asyncio
import logging
import signal
import time
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from owlmind.dag import ready_goals, validate_dag
from owlmind.monitoring.metrics import scheduler_metrics, track_time
from owlmind.session import (
    SESSION_DONE,
    SESSION_FAILED,
    SESSION_RUNNING,
    GoalRunInfo,
    GoalSpec,
    SessionMeta,
)
from owlmind.storage.interface import StorageBackend

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------


@dataclass
class SchedulerConfig:
    """Scheduler runtime configuration."""

    poll_interval: float = 5.0
    """Seconds between scheduler ticks."""

    max_sessions: int = 100
    """Maximum sessions to scan per tick."""

    stale_timeout: float = 3600.0
    """Seconds before a dispatched/running goal is considered stale."""


@dataclass
class SchedulerTickResult:
    """Statistics from one scheduler tick."""

    sessions_scanned: int = 0
    goals_dispatched: int = 0
    goals_completed: int = 0
    goals_failed: int = 0
    goals_stale_reset: int = 0
    errors: int = 0


# ---------------------------------------------------------------------------
# Scheduler
# ---------------------------------------------------------------------------


class Scheduler:
    """DAG-aware distributed scheduler.

    Polls sessions, dispatches ready goals to QueueStorage, monitors
    completion, and advances session state machines.
    """

    def __init__(
        self,
        storage: StorageBackend,
        config: SchedulerConfig | None = None,
        *,
        on_event: Callable[[dict[str, Any]], None] | None = None,
    ) -> None:
        self._storage = storage
        self._config = config or SchedulerConfig()
        self._on_event = on_event
        self._shutdown = False
        self._validated_sessions: set[str] = set()

    # ------------------------------------------------------------------
    # Main loop
    # ------------------------------------------------------------------

    async def run(self) -> None:
        """Main scheduler loop. Runs until shutdown signal."""
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(sig, self._handle_signal)

        logger.info(
            "Scheduler started (poll_interval=%.1fs, stale_timeout=%.0fs)",
            self._config.poll_interval,
            self._config.stale_timeout,
        )

        while not self._shutdown:
            try:
                with track_time(scheduler_metrics.tick_duration):
                    result = await self._tick()
                # Update metrics from tick result
                if result.goals_dispatched:
                    scheduler_metrics.goals_dispatched.inc(result.goals_dispatched)
                if result.goals_completed:
                    scheduler_metrics.goals_completed.inc(result.goals_completed)
                if result.goals_failed:
                    scheduler_metrics.goals_failed.inc(result.goals_failed)
                if result.goals_stale_reset:
                    scheduler_metrics.goals_stale_reset.inc(result.goals_stale_reset)
                if result.sessions_scanned:
                    scheduler_metrics.sessions_scanned.inc(result.sessions_scanned)
                if result.goals_dispatched or result.goals_completed or result.goals_failed:
                    logger.info(
                        "tick: scanned=%d dispatched=%d completed=%d failed=%d stale=%d",
                        result.sessions_scanned,
                        result.goals_dispatched,
                        result.goals_completed,
                        result.goals_failed,
                        result.goals_stale_reset,
                    )
            except Exception:
                scheduler_metrics.tick_errors.inc()
                logger.exception("Scheduler tick error")

            await asyncio.sleep(self._config.poll_interval)

        logger.info("Scheduler shut down")

    def _handle_signal(self) -> None:
        """Signal handler for graceful shutdown."""
        logger.info("Shutdown signal received")
        self._shutdown = True

    async def shutdown(self) -> None:
        """Programmatic graceful shutdown."""
        self._shutdown = True

    # ------------------------------------------------------------------
    # Tick — one scheduling cycle
    # ------------------------------------------------------------------

    async def _tick(self) -> SchedulerTickResult:
        """One scheduler tick: collect results, then dispatch ready goals."""
        result = SchedulerTickResult()

        # Phase 1: collect results from queue → update sessions
        completed, failed = await self._collect_results()
        result.goals_completed = completed
        result.goals_failed = failed

        # Phase 2: dispatch new ready goals
        scanned, dispatched, stale = await self._dispatch_all_sessions()
        result.sessions_scanned = scanned
        result.goals_dispatched = dispatched
        result.goals_stale_reset = stale

        return result

    # ------------------------------------------------------------------
    # Phase 1: Collect results
    # ------------------------------------------------------------------

    async def _collect_results(self) -> tuple[int, int]:
        """Check queue for completed items, update sessions.

        Returns (completed_count, failed_count).
        """
        completed = 0
        failed = 0

        # Build lookup: (session_id, goal_id) → QueueItem
        all_items = await self._storage.queue.list_items()
        item_lookup: dict[tuple[str, str], Any] = {}
        for item in all_items:
            sid = getattr(item, "session_id", "")
            gid = getattr(item, "goal_id", "")
            if sid and gid:
                item_lookup[(sid, gid)] = item

        if not item_lookup:
            return 0, 0

        # Find sessions that have dispatched/running goals
        session_ids = {sid for sid, _ in item_lookup}
        for sid in session_ids:
            try:
                meta = await self._storage.sessions.load_session(sid)
            except Exception:
                logger.debug("Cannot load session %s for result collection", sid)
                continue

            if meta.status not in (SESSION_RUNNING,):
                continue

            changed = False
            for run_info in meta.runs:
                if run_info.status not in ("dispatched", "running"):
                    continue

                item = item_lookup.get((sid, run_info.goal_id))
                if item is None:
                    continue

                item_status = getattr(item, "status", "")
                if item_status == "DONE":
                    run_info.status = "done"
                    run_info.run_id = getattr(item, "run_id", run_info.run_id)
                    run_info.ended_at = _now_iso()
                    completed += 1
                    changed = True
                    self._emit(
                        {"type": "goal_completed", "session_id": sid, "goal_id": run_info.goal_id}
                    )
                elif item_status == "FAILED":
                    run_info.status = "failed"
                    run_info.run_id = getattr(item, "run_id", run_info.run_id)
                    run_info.ended_at = _now_iso()
                    failed += 1
                    changed = True
                    self._emit(
                        {"type": "goal_failed", "session_id": sid, "goal_id": run_info.goal_id}
                    )
                elif item_status == "RUNNING" and run_info.status == "dispatched":
                    run_info.status = "running"
                    run_info.run_id = getattr(item, "run_id", "")
                    changed = True

            if changed:
                meta.updated_at = _now_iso()
                await self._storage.sessions.save_session(meta)
                await self._check_session_completion(meta)

        return completed, failed

    # ------------------------------------------------------------------
    # Phase 2: Dispatch ready goals
    # ------------------------------------------------------------------

    async def _dispatch_all_sessions(self) -> tuple[int, int, int]:
        """Scan RUNNING sessions, dispatch ready goals.

        Returns (sessions_scanned, goals_dispatched, goals_stale_reset).
        """
        session_ids = await self._storage.sessions.list_sessions(
            n=self._config.max_sessions,
        )

        scanned = 0
        dispatched = 0
        stale_reset = 0

        for sid in session_ids:
            try:
                meta = await self._storage.sessions.load_session(sid)
            except Exception:
                logger.debug("Cannot load session %s", sid)
                continue

            if meta.status != SESSION_RUNNING:
                continue

            scanned += 1

            # Try to acquire session lock (non-blocking)
            locked = await self._storage.sessions.acquire_lock(sid)
            if not locked:
                continue

            try:
                # Reload after acquiring lock
                meta = await self._storage.sessions.load_session(sid)
                if meta.status != SESSION_RUNNING:
                    continue

                # Recover stale goals
                stale_reset += await self._recover_stale(meta)

                # Dispatch ready goals
                dispatched += await self._process_session(meta)
            except Exception:
                logger.exception("Error processing session %s", sid)
            finally:
                await self._storage.sessions.release_lock(sid)

        return scanned, dispatched, stale_reset

    async def _process_session(self, meta: SessionMeta) -> int:
        """Dispatch ready goals for one session, respecting max_concurrency.

        Returns the number of goals dispatched.
        """
        # Validate DAG once per session
        if meta.session_id not in self._validated_sessions:
            goal_dicts = _goal_dicts(meta.goals)
            try:
                validate_dag(goal_dicts)
            except Exception as exc:
                meta.status = SESSION_FAILED
                meta.last_block_reason = f"DAG validation error: {exc}"
                meta.updated_at = _now_iso()
                await self._storage.sessions.save_session(meta)
                self._emit(
                    {
                        "type": "session_failed",
                        "session_id": meta.session_id,
                        "reason": meta.last_block_reason,
                    }
                )
                return 0
            self._validated_sessions.add(meta.session_id)

        # Build status map
        statuses = _status_map(meta)

        # Count active (dispatched + running) goals
        active = sum(1 for s in statuses.values() if s in ("dispatched", "running"))

        # How many more can we dispatch?
        slots = meta.max_concurrency - active
        if slots <= 0:
            return 0

        # Find ready goals
        goal_dicts = _goal_dicts(meta.goals)
        ready = ready_goals(goal_dicts, statuses, allow_skipped_deps=meta.continue_on_fail)

        if not ready:
            # Check for dead-end: no ready, no active, but not all done
            if active == 0:
                await self._check_session_completion(meta)
            return 0

        # Dispatch up to available slots
        goal_map = {g.id: g for g in meta.goals}
        count = 0
        for goal_id in ready[:slots]:
            goal = goal_map.get(goal_id)
            if goal is None:
                continue
            await self._dispatch_goal(meta, goal)
            count += 1

        return count

    async def _dispatch_goal(self, meta: SessionMeta, goal: GoalSpec) -> None:
        """Enqueue a single goal to QueueStorage and update session metadata."""
        await self._storage.queue.add(
            goal=goal.goal,
            workspace=goal.workspace,
            sandbox=goal.sandbox,
            priority=0,
            session_id=meta.session_id,
            goal_id=goal.id,
        )

        now = _now_iso()
        meta.runs.append(
            GoalRunInfo(
                goal_id=goal.id,
                run_id="",
                status="dispatched",
                started_at=now,
                ended_at="",
            )
        )
        meta.updated_at = now
        await self._storage.sessions.save_session(meta)

        await self._storage.sessions.append_event(
            meta.session_id,
            {"type": "goal_dispatched", "goal_id": goal.id, "timestamp": now},
        )

        self._emit({"type": "goal_dispatched", "session_id": meta.session_id, "goal_id": goal.id})

        logger.info("Dispatched goal %s for session %s", goal.id, meta.session_id)

    # ------------------------------------------------------------------
    # Session completion detection
    # ------------------------------------------------------------------

    async def _check_session_completion(self, meta: SessionMeta) -> None:
        """Detect if session is DONE/FAILED and update status."""
        statuses = _status_map(meta)

        all_done = all(s == "done" for s in statuses.values())
        if all_done and statuses:
            meta.status = SESSION_DONE
            meta.updated_at = _now_iso()
            await self._storage.sessions.save_session(meta)
            await self._storage.sessions.append_event(
                meta.session_id,
                {"type": "session_done", "timestamp": _now_iso()},
            )
            self._emit({"type": "session_done", "session_id": meta.session_id})
            logger.info("Session %s completed (all goals done)", meta.session_id)
            return

        # Check for failure
        any_failed = any(s == "failed" for s in statuses.values())
        if any_failed and not meta.continue_on_fail:
            failed_goals = [gid for gid, s in statuses.items() if s == "failed"]
            meta.status = SESSION_FAILED
            meta.last_block_reason = f"Goal(s) failed: {', '.join(failed_goals)}"
            meta.updated_at = _now_iso()
            await self._storage.sessions.save_session(meta)
            self._emit(
                {
                    "type": "session_failed",
                    "session_id": meta.session_id,
                    "reason": meta.last_block_reason,
                }
            )
            logger.info("Session %s failed: %s", meta.session_id, meta.last_block_reason)
            return

        # Check for dead-end: all remaining pending goals have unsatisfied deps
        active = any(s in ("dispatched", "running") for s in statuses.values())
        if not active:
            goal_dicts = _goal_dicts(meta.goals)
            ready = ready_goals(goal_dicts, statuses, allow_skipped_deps=meta.continue_on_fail)
            pending = [gid for gid, s in statuses.items() if s == "pending"]
            if pending and not ready:
                # Dead-end: pending goals but none can run
                if meta.continue_on_fail:
                    # Skip blocked goals and mark session done
                    for gid in pending:
                        _set_goal_status(meta, gid, "skipped")
                    meta.status = SESSION_DONE
                else:
                    meta.status = SESSION_FAILED
                    meta.last_block_reason = (
                        f"Dead-end: {len(pending)} pending goal(s) with unsatisfied dependencies"
                    )
                meta.updated_at = _now_iso()
                await self._storage.sessions.save_session(meta)
                self._emit(
                    {
                        "type": "session_done" if meta.status == SESSION_DONE else "session_failed",
                        "session_id": meta.session_id,
                    }
                )

    # ------------------------------------------------------------------
    # Stale goal recovery
    # ------------------------------------------------------------------

    async def _recover_stale(self, meta: SessionMeta) -> int:
        """Reset goals stuck in dispatched/running for too long.

        Returns the number of goals reset.
        """
        now = time.time()
        count = 0

        for run_info in meta.runs:
            if run_info.status not in ("dispatched", "running"):
                continue

            if not run_info.started_at:
                continue

            try:
                started = datetime.fromisoformat(run_info.started_at).timestamp()
            except (ValueError, OSError):
                continue

            elapsed = now - started
            if elapsed > self._config.stale_timeout:
                logger.warning(
                    "Stale goal %s in session %s (%.0fs): resetting to pending",
                    run_info.goal_id,
                    meta.session_id,
                    elapsed,
                )
                run_info.status = "pending"
                run_info.started_at = ""
                run_info.ended_at = ""
                run_info.run_id = ""
                count += 1

                await self._storage.sessions.append_event(
                    meta.session_id,
                    {
                        "type": "goal_stale_reset",
                        "goal_id": run_info.goal_id,
                        "elapsed_seconds": elapsed,
                        "timestamp": _now_iso(),
                    },
                )
                self._emit(
                    {
                        "type": "goal_stale_reset",
                        "session_id": meta.session_id,
                        "goal_id": run_info.goal_id,
                    }
                )

        if count:
            meta.updated_at = _now_iso()
            await self._storage.sessions.save_session(meta)

        return count

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _emit(self, event: dict[str, Any]) -> None:
        """Emit a scheduler event (if callback registered)."""
        if self._on_event is not None:
            try:
                self._on_event(event)
            except Exception:
                logger.debug("Event callback error", exc_info=True)


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------


def _now_iso() -> str:
    """Current UTC timestamp in ISO format."""
    return datetime.now(UTC).isoformat()


def _goal_dicts(goals: list[GoalSpec]) -> list[dict[str, object]]:
    """Convert GoalSpec list to dicts for DAG functions."""
    return [{"id": g.id, "depends_on": g.depends_on} for g in goals]


def _status_map(meta: SessionMeta) -> dict[str, str]:
    """Build goal_id → status mapping from session metadata."""
    run_map = {r.goal_id: r.status for r in meta.runs}
    return {g.id: run_map.get(g.id, "pending") for g in meta.goals}


def _set_goal_status(meta: SessionMeta, goal_id: str, status: str) -> None:
    """Set or create GoalRunInfo for a goal."""
    for run_info in meta.runs:
        if run_info.goal_id == goal_id:
            run_info.status = status
            return
    meta.runs.append(
        GoalRunInfo(
            goal_id=goal_id,
            run_id="",
            status=status,
            started_at=_now_iso(),
            ended_at=_now_iso() if status in ("done", "failed", "skipped") else "",
        )
    )
