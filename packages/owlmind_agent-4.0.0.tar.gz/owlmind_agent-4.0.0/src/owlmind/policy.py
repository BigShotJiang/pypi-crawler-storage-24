"""PolicyEngine — YAML-based command allowlist and risk evaluation (v1)."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any

import yaml

# ---------------------------------------------------------------------------
# Decision types
# ---------------------------------------------------------------------------


class PolicyDecision(Enum):
    ALLOW = "allow"
    DENY = "deny"
    ALLOW_WITH_LOG = "allow_with_log"
    BLOCK = "block"


@dataclass
class PolicyResult:
    decision: PolicyDecision
    reason: str = ""
    matched_pattern: str = ""
    policy_version: str = "unknown"


# ---------------------------------------------------------------------------
# PolicyEngine (YAML v1 backend)
# ---------------------------------------------------------------------------


@dataclass
class PolicyEngine:
    """YAML-based policy engine.

    Loads ``allowlist.yaml`` and ``policy.yaml`` from a policies directory.

    The ``policy.yaml`` file may declare a ``version`` field:

    .. code-block:: yaml

        version: "1"
        forbidden_patterns: [...]

    If the field is absent the engine stores ``"unknown"`` and includes that
    value in every :class:`PolicyResult` returned by :meth:`evaluate`.
    """

    allowed_patterns: list[re.Pattern[str]] = field(default_factory=list)
    forbidden_patterns: list[re.Pattern[str]] = field(default_factory=list)
    risk_behavior: dict[str, str] = field(default_factory=dict)
    risk_classification: dict[str, list[str]] = field(default_factory=dict)
    version: str = "unknown"

    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    @classmethod
    def from_directory(cls, policies_dir: str | Path) -> PolicyEngine:
        """Load policies from *policies_dir*."""
        policies_dir = Path(policies_dir)
        engine = cls()

        allowlist_path = policies_dir / "allowlist.yaml"
        if allowlist_path.exists():
            data: dict[str, Any] = yaml.safe_load(allowlist_path.read_text()) or {}
            for pattern_str in data.get("allowed_commands", []):
                engine.allowed_patterns.append(re.compile(pattern_str))

        policy_path = policies_dir / "policy.yaml"
        if policy_path.exists():
            data = yaml.safe_load(policy_path.read_text()) or {}
            engine.version = str(data.get("version", "unknown"))
            for pattern_str in data.get("forbidden_patterns", []):
                engine.forbidden_patterns.append(re.compile(pattern_str))
            engine.risk_behavior = data.get("risk_behavior", {})
            engine.risk_classification = data.get("risk_classification", {})

        return engine

    # ------------------------------------------------------------------
    # Evaluation
    # ------------------------------------------------------------------

    @staticmethod
    def _is_claude_cli(command: str) -> bool:
        """Return True if *command* is a ``claude -p`` invocation.

        Claude CLI prompts contain arbitrary text that should not be
        checked against shell-injection forbidden patterns.
        """
        stripped = command.lstrip()
        return stripped.startswith("claude -p ") or stripped.startswith("claude -c -p ")

    def evaluate(self, command: str) -> PolicyResult:
        """Evaluate *command* against loaded policies.

        Order of checks:
        1. Forbidden patterns -> DENY  (skipped for trusted claude CLI)
        2. Allowlist -> ALLOW / DENY
        3. Risk behaviour (if allowlisted)

        Every returned :class:`PolicyResult` carries ``policy_version`` so
        callers can trace which policy revision produced the decision.
        """
        # 1. Forbidden patterns always take priority
        #    Skip for claude -p commands — prompt text is not a shell command
        if not self._is_claude_cli(command):
            for pat in self.forbidden_patterns:
                if pat.search(command):
                    return PolicyResult(
                        decision=PolicyDecision.DENY,
                        reason=f"Matches forbidden pattern: {pat.pattern}",
                        matched_pattern=pat.pattern,
                        policy_version=self.version,
                    )

        # 2. Allowlist check
        allowed = False
        for pat in self.allowed_patterns:
            if pat.search(command):
                allowed = True
                break

        if not allowed:
            return PolicyResult(
                decision=PolicyDecision.DENY,
                reason="Command not in allowlist",
                policy_version=self.version,
            )

        # 3. Risk-based behaviour
        risk_level = self._classify_risk(command)
        behaviour = self.risk_behavior.get(risk_level, "ALLOW")

        if behaviour == "BLOCK":
            return PolicyResult(
                decision=PolicyDecision.BLOCK,
                reason=f"Risk level {risk_level} is blocked by policy",
                policy_version=self.version,
            )
        if behaviour == "ALLOW_WITH_LOG":
            return PolicyResult(
                decision=PolicyDecision.ALLOW_WITH_LOG,
                reason=f"Allowed with logging (risk={risk_level})",
                policy_version=self.version,
            )
        return PolicyResult(
            decision=PolicyDecision.ALLOW,
            reason="Allowed by policy",
            policy_version=self.version,
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _classify_risk(self, command: str) -> str:
        """Return the risk level string for *command*."""
        for level in ("CRITICAL", "HIGH", "MEDIUM", "LOW"):
            prefixes = self.risk_classification.get(level, [])
            for prefix in prefixes:
                if command.startswith(prefix):
                    return level
        return "LOW"
