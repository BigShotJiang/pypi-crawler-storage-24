"""Release tooling — changelog, bundle, verification.

Generates CHANGELOG.md from git history, creates release bundles,
and verifies release readiness.
"""

from __future__ import annotations

import subprocess
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from owlmind import __version__

# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------


@dataclass
class ChangelogEntry:
    """A single changelog entry."""

    hash: str = ""
    subject: str = ""
    date: str = ""
    author: str = ""


@dataclass
class ReleaseCheck:
    """A single release readiness check."""

    name: str = ""
    ok: bool = False
    detail: str = ""


@dataclass
class ReleaseReport:
    """Release readiness report."""

    version: str = ""
    checks: list[ReleaseCheck] = field(default_factory=list)
    ok: bool = False


# ---------------------------------------------------------------------------
# Changelog
# ---------------------------------------------------------------------------


def generate_changelog(
    repo_path: Path,
    *,
    out_path: Path | None = None,
    since_tag: str = "",
    max_entries: int = 200,
) -> Path:
    """Generate CHANGELOG.md from git log.

    If since_tag is provided, only includes commits since that tag.
    """
    if out_path is None:
        out_path = repo_path / "CHANGELOG.md"

    args = ["git", "log", f"--max-count={max_entries}", "--pretty=format:%H|%s|%ai|%an"]
    if since_tag:
        args.append(f"{since_tag}..HEAD")

    result = subprocess.run(
        args,
        capture_output=True,
        text=True,
        cwd=repo_path,
        timeout=30,
    )

    entries: list[ChangelogEntry] = []
    if result.returncode == 0:
        for line in result.stdout.strip().splitlines():
            parts = line.split("|", 3)
            if len(parts) >= 4:
                entries.append(
                    ChangelogEntry(
                        hash=parts[0][:8],
                        subject=parts[1],
                        date=parts[2][:10],
                        author=parts[3],
                    )
                )

    md = _render_changelog(entries)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(md)
    return out_path


def _render_changelog(entries: list[ChangelogEntry]) -> str:
    """Render changelog entries as markdown."""
    lines = [
        "# OWLMIND Changelog",
        "",
        f"Generated: {datetime.now(tz=UTC).isoformat()[:19]}Z",
        f"Version: {__version__}",
        "",
    ]

    if not entries:
        lines.append("_No commits found._")
        return "\n".join(lines)

    current_date = ""
    for entry in entries:
        if entry.date != current_date:
            current_date = entry.date
            lines.append(f"\n## {current_date}")
            lines.append("")
        lines.append(f"- `{entry.hash}` {entry.subject} ({entry.author})")

    lines.append("")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Release verification
# ---------------------------------------------------------------------------


def verify_release(
    repo_path: Path,
    *,
    run_tests: bool = True,
    run_lint: bool = True,
) -> ReleaseReport:
    """Verify release readiness — run checks and return report."""
    report = ReleaseReport(version=__version__)

    # Check 1: version consistency
    report.checks.append(_check_version_consistency(repo_path))

    # Check 2: git clean
    report.checks.append(_check_git_clean(repo_path))

    # Check 3: tests pass
    if run_tests:
        report.checks.append(_check_tests(repo_path))

    # Check 4: lint passes
    if run_lint:
        report.checks.append(_check_lint(repo_path))

    # Check 5: CHANGELOG exists
    report.checks.append(_check_changelog(repo_path))

    report.ok = all(c.ok for c in report.checks)
    return report


def _check_version_consistency(repo_path: Path) -> ReleaseCheck:
    """Check __init__.py and pyproject.toml have same version."""
    init_path = repo_path / "src" / "owlmind" / "__init__.py"
    pyproject_path = repo_path / "pyproject.toml"

    init_ver = ""
    if init_path.exists():
        for line in init_path.read_text().splitlines():
            if line.startswith("__version__"):
                init_ver = line.split("=")[1].strip().strip('"').strip("'")
                break

    pyproject_ver = ""
    if pyproject_path.exists():
        for line in pyproject_path.read_text().splitlines():
            if line.strip().startswith("version"):
                pyproject_ver = line.split("=")[1].strip().strip('"').strip("'")
                break

    ok = init_ver == pyproject_ver and init_ver != ""
    detail = f"init={init_ver}, pyproject={pyproject_ver}"
    return ReleaseCheck(name="version_consistency", ok=ok, detail=detail)


def _check_git_clean(repo_path: Path) -> ReleaseCheck:
    """Check for uncommitted changes."""
    result = subprocess.run(
        ["git", "status", "--porcelain"],
        capture_output=True,
        text=True,
        cwd=repo_path,
        timeout=10,
    )
    clean = result.returncode == 0 and result.stdout.strip() == ""
    detail = "clean" if clean else f"{len(result.stdout.splitlines())} uncommitted changes"
    return ReleaseCheck(name="git_clean", ok=clean, detail=detail)


def _check_tests(repo_path: Path) -> ReleaseCheck:
    """Run pytest and check result."""
    result = subprocess.run(
        ["python3", "-m", "pytest", "tests/", "-q", "--tb=no"],
        capture_output=True,
        text=True,
        cwd=repo_path,
        timeout=120,
    )
    ok = result.returncode == 0
    # Extract summary line
    lines = result.stdout.strip().splitlines()
    summary = lines[-1] if lines else "no output"
    return ReleaseCheck(name="tests", ok=ok, detail=summary)


def _check_lint(repo_path: Path) -> ReleaseCheck:
    """Run ruff and check result."""
    result = subprocess.run(
        ["python3", "-m", "ruff", "check", "src/", "tests/"],
        capture_output=True,
        text=True,
        cwd=repo_path,
        timeout=30,
    )
    ok = result.returncode == 0
    detail = "passed" if ok else result.stdout.strip()[:100]
    return ReleaseCheck(name="lint", ok=ok, detail=detail)


def _check_changelog(repo_path: Path) -> ReleaseCheck:
    """Check CHANGELOG.md exists."""
    path = repo_path / "CHANGELOG.md"
    ok = path.exists() and path.stat().st_size > 0
    detail = "exists" if ok else "missing or empty"
    return ReleaseCheck(name="changelog", ok=ok, detail=detail)


# ---------------------------------------------------------------------------
# Release bundle
# ---------------------------------------------------------------------------


def create_release_bundle(
    repo_path: Path,
    *,
    out_dir: Path | None = None,
) -> dict[str, Any]:
    """Create a release bundle with all artifacts.

    Returns dict with paths to generated files.
    """
    if out_dir is None:
        out_dir = repo_path / "release"

    out_dir.mkdir(parents=True, exist_ok=True)

    artifacts: dict[str, str] = {}

    # Generate changelog
    changelog_path = generate_changelog(repo_path, out_path=out_dir / "CHANGELOG.md")
    artifacts["changelog"] = str(changelog_path)

    # Verify release
    report = verify_release(repo_path, run_tests=False, run_lint=False)
    report_path = out_dir / "release_report.txt"
    report_lines = [
        f"OWLMIND Release Report v{report.version}",
        f"Date: {datetime.now(tz=UTC).isoformat()[:19]}Z",
        f"Overall: {'PASS' if report.ok else 'FAIL'}",
        "",
    ]
    for check in report.checks:
        status = "PASS" if check.ok else "FAIL"
        report_lines.append(f"  [{status}] {check.name}: {check.detail}")

    report_path.write_text("\n".join(report_lines) + "\n")
    artifacts["report"] = str(report_path)

    return {
        "version": __version__,
        "out_dir": str(out_dir),
        "artifacts": artifacts,
        "ok": report.ok,
    }
