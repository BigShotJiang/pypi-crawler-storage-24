"""OWLMIND webhook — signed HTTP event delivery to external systems."""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Any, Protocol
from urllib.parse import urlparse

from owlmind.utils import redact_secrets

logger = logging.getLogger(__name__)

# Events we relay to webhooks
RELAYED_EVENTS: frozenset[str] = frozenset(
    {
        "session_started",
        "session_done",
        "session_failed",
        "session_stopped",
        "goal_started",
        "goal_done",
        "goal_failed",
        "run_started",
        "run_done",
        "run_failed",
        "budget_exceeded",
        "budget_warning",
        "recovery_retry",
        "recovery_switch_provider",
        "recovery_failed",
    }
)


# ── Config ──


@dataclass
class WebhookConfig:
    """Webhook delivery configuration."""

    enabled: bool = False
    url: str = ""
    secret: str = ""
    timeout_sec: int = 10
    max_retries: int = 3
    backoff_base: float = 1.0
    allowlist_domains: list[str] = field(default_factory=list)

    @property
    def hostname(self) -> str:
        """Extract hostname from URL (for display, never the full URL)."""
        if not self.url:
            return ""
        return urlparse(self.url).hostname or ""

    def is_domain_allowed(self) -> bool:
        """Check if the configured URL domain is in the allowlist."""
        if not self.allowlist_domains:
            return True  # no allowlist = allow all
        return self.hostname in self.allowlist_domains


# ── HTTP client interface ──


class HttpClient(Protocol):
    """Injectable HTTP client for testability."""

    def post(self, url: str, body: bytes, headers: dict[str, str], timeout: int) -> int:
        """POST body to url. Returns HTTP status code."""
        ...


class UrllibClient:
    """Default HTTP client using stdlib urllib."""

    def post(self, url: str, body: bytes, headers: dict[str, str], timeout: int) -> int:
        req = urllib.request.Request(url, data=body, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return int(resp.status)
        except urllib.error.HTTPError as e:
            return int(e.code)


# ── Payload building ──


def build_payload(event_name: str, data: dict[str, Any]) -> dict[str, Any]:
    """Build a redacted webhook payload from an event.

    Includes: event type, timestamp, IDs, summary.
    Excludes: full prompts, secrets, raw LLM output.
    """
    safe_data: dict[str, Any] = {}
    for key, value in data.items():
        if isinstance(value, str):
            safe_data[key] = redact_secrets(value)
        elif isinstance(value, dict):
            safe_data[key] = {
                k: redact_secrets(str(v)) if isinstance(v, str) else v for k, v in value.items()
            }
        else:
            safe_data[key] = value

    return {
        "event": event_name,
        "timestamp": time.time(),
        "data": safe_data,
    }


def sign_payload_hmac(payload_bytes: bytes, secret: str) -> str:
    """Compute HMAC-SHA256 signature for payload verification.

    Returns hex digest string.
    """
    return hmac.new(
        secret.encode(),
        payload_bytes,
        hashlib.sha256,
    ).hexdigest()


# ── Delivery ──


@dataclass
class WebhookNotifier:
    """Sends signed event payloads to a webhook URL with retry and dedupe."""

    config: WebhookConfig
    http_client: HttpClient = field(default_factory=UrllibClient)
    _seen: dict[str, float] = field(default_factory=dict)
    _dedupe_window: float = 60.0

    def _dedupe_key(self, event_name: str, data: dict[str, Any]) -> str:
        """Build a dedupe key from event name and stable data fields."""
        parts = [event_name]
        for key in sorted(data.keys()):
            val = data[key]
            if isinstance(val, str | int | float | bool):
                parts.append(f"{key}={val}")
        return hashlib.md5("|".join(parts).encode()).hexdigest()  # noqa: S324

    def _is_duplicate(self, key: str) -> bool:
        now = time.time()
        # Clean old entries
        self._seen = {k: v for k, v in self._seen.items() if now - v < self._dedupe_window}
        if key in self._seen:
            return True
        self._seen[key] = now
        return False

    def send_event(self, event_name: str, data: dict[str, Any]) -> dict[str, Any]:
        """Send a webhook event with retry.

        Returns a result dict with status info. Never leaks secrets in errors.
        """
        if not self.config.enabled or not self.config.url:
            logger.debug("Webhook disabled, skipping event %s", event_name)
            return {"sent": False, "reason": "webhook disabled"}

        if event_name not in RELAYED_EVENTS:
            logger.debug("Event %s not in relay list, skipping", event_name)
            return {"sent": False, "reason": f"event {event_name} not relayed"}

        if not self.config.is_domain_allowed():
            logger.warning("Webhook domain %s not in allowlist", self.config.hostname)
            return {"sent": False, "reason": "domain not in allowlist"}

        dedupe_key = self._dedupe_key(event_name, data)
        if self._is_duplicate(dedupe_key):
            return {"sent": False, "reason": "duplicate event suppressed"}

        payload = build_payload(event_name, data)
        payload_bytes = json.dumps(payload, default=str).encode()

        headers: dict[str, str] = {
            "Content-Type": "application/json",
            "User-Agent": "owlmind-webhook/1.0",
            "X-OwlMind-Event": event_name,
        }

        if self.config.secret:
            sig = sign_payload_hmac(payload_bytes, self.config.secret)
            headers["X-OwlMind-Signature"] = f"sha256={sig}"

        last_error = ""
        for attempt in range(self.config.max_retries):
            try:
                status = self.http_client.post(
                    self.config.url,
                    payload_bytes,
                    headers,
                    self.config.timeout_sec,
                )
                if 200 <= status < 300:
                    logger.info(
                        "Webhook delivered: event=%s status=%d attempt=%d",
                        event_name,
                        status,
                        attempt + 1,
                    )
                    return {"sent": True, "status": status, "attempt": attempt + 1}
                last_error = f"HTTP {status}"
                logger.debug("Webhook attempt %d failed: %s", attempt + 1, last_error)
            except Exception as exc:
                # Never leak secrets from error messages
                last_error = redact_secrets(str(exc))
                logger.debug("Webhook attempt %d error: %s", attempt + 1, last_error)

            if attempt < self.config.max_retries - 1:
                delay = self.config.backoff_base * (2**attempt)
                time.sleep(delay)

        logger.warning(
            "Webhook delivery failed after %d retries: %s", self.config.max_retries, last_error
        )
        return {"sent": False, "reason": f"all retries failed: {last_error}"}

    def event_bus_handler(self, event_name: str, data: dict[str, Any]) -> None:
        """EventBus-compatible subscriber callback."""
        self.send_event(event_name, data)
