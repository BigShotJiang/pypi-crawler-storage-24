"""Usage Ledger — append-only JSONL token/cost tracking with file locking."""

from __future__ import annotations

import fcntl
import json
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from datetime import date as date_type
from pathlib import Path
from typing import Any


@dataclass
class UsageEntry:
    """Single usage record in the ledger."""

    ts: str
    run_id: str
    stage: str  # "planner" | "judge" | "worker"
    provider: str
    model: str
    input_tokens: int
    output_tokens: int
    total_tokens: int
    estimated_usd: float
    latency_ms: int
    price_per_1k_input: float
    price_per_1k_output: float
    currency: str = "USD"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> UsageEntry:
        return cls(
            ts=str(data.get("ts", "")),
            run_id=str(data.get("run_id", "")),
            stage=str(data.get("stage", "")),
            provider=str(data.get("provider", "")),
            model=str(data.get("model", "")),
            input_tokens=int(data.get("input_tokens", 0)),
            output_tokens=int(data.get("output_tokens", 0)),
            total_tokens=int(data.get("total_tokens", 0)),
            estimated_usd=float(data.get("estimated_usd", 0.0)),
            latency_ms=int(data.get("latency_ms", 0)),
            price_per_1k_input=float(data.get("price_per_1k_input", 0.0)),
            price_per_1k_output=float(data.get("price_per_1k_output", 0.0)),
            currency=str(data.get("currency", "USD")),
        )


@dataclass
class UsageTotals:
    """Aggregated usage totals."""

    input_tokens: int = 0
    output_tokens: int = 0
    total_tokens: int = 0
    estimated_usd: float = 0.0
    llm_calls: int = 0
    models: dict[str, int] = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        if self.models is None:
            self.models = {}

    def to_dict(self) -> dict[str, Any]:
        return {
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "total_tokens": self.total_tokens,
            "estimated_usd": self.estimated_usd,
            "llm_calls": self.llm_calls,
            "models": self.models,
        }


class UsageLedger:
    """Append-only JSONL ledger for token usage tracking."""

    def __init__(self, ledger_dir: Path) -> None:
        self.ledger_dir = Path(ledger_dir)
        self.ledger_dir.mkdir(parents=True, exist_ok=True)

    @property
    def ledger_path(self) -> Path:
        return self.ledger_dir / "usage.jsonl"

    def record(self, entry: UsageEntry) -> None:
        """Append a usage entry to the ledger (under file lock)."""
        lock_path = self.ledger_dir / "usage.lock"
        with lock_path.open("w") as lock_fd:
            fcntl.flock(lock_fd, fcntl.LOCK_EX)
            try:
                with self.ledger_path.open("a") as f:
                    f.write(json.dumps(entry.to_dict(), default=str) + "\n")
            finally:
                fcntl.flock(lock_fd, fcntl.LOCK_UN)

    def _read_all(self) -> list[UsageEntry]:
        """Read all entries from the ledger."""
        if not self.ledger_path.exists():
            return []
        entries: list[UsageEntry] = []
        for line in self.ledger_path.read_text().splitlines():
            line = line.strip()
            if line:
                entries.append(UsageEntry.from_dict(json.loads(line)))
        return entries

    def _aggregate(self, entries: list[UsageEntry]) -> UsageTotals:
        """Aggregate a list of entries into totals."""
        totals = UsageTotals()
        for e in entries:
            totals.input_tokens += e.input_tokens
            totals.output_tokens += e.output_tokens
            totals.total_tokens += e.total_tokens
            totals.estimated_usd += e.estimated_usd
            totals.llm_calls += 1
            totals.models[e.model] = totals.models.get(e.model, 0) + 1
        return totals

    def totals_for_day(self, day: date_type | None = None) -> UsageTotals:
        """Get aggregated totals for a specific day (defaults to today)."""
        if day is None:
            day = datetime.now(tz=UTC).date()
        day_str = day.isoformat()
        entries = [e for e in self._read_all() if e.ts.startswith(day_str)]
        return self._aggregate(entries)

    def totals_for_run(self, run_id: str) -> UsageTotals:
        """Get aggregated totals for a specific run."""
        entries = [e for e in self._read_all() if e.run_id == run_id]
        return self._aggregate(entries)

    def recent(self, n: int = 20) -> list[UsageEntry]:
        """Return the last n entries."""
        entries = self._read_all()
        return entries[-n:]

    def entries_for_day(self, day: date_type | None = None) -> list[UsageEntry]:
        """Get all entries for a specific day."""
        if day is None:
            day = datetime.now(tz=UTC).date()
        day_str = day.isoformat()
        return [e for e in self._read_all() if e.ts.startswith(day_str)]

    def calls_in_last_hour(self) -> int:
        """Count LLM calls made in the last hour."""
        cutoff = datetime.now(tz=UTC).timestamp() - 3600
        count = 0
        for e in self._read_all():
            try:
                entry_ts = datetime.fromisoformat(e.ts).timestamp()
                if entry_ts > cutoff:
                    count += 1
            except ValueError:
                continue
        return count
