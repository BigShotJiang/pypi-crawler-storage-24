"""Session runner — orchestrates multi-goal sessions via autopilot.

Supports DAG dependencies and parallel goal execution (max_concurrency).
Runs each goal as its own autopilot cycle, tracking progress in
session metadata and producing a unified protocol.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from owlmind.dag import topological_layers, validate_dag
from owlmind.session import (
    SESSION_BLOCKED,
    SESSION_DONE,
    SESSION_FAILED,
    SESSION_RUNNING,
    SESSION_STOPPED,
    GoalRunInfo,
    SessionLock,
    SessionMeta,
    append_session_event,
    load_session,
    render_protocol,
    save_session,
)

logger = logging.getLogger(__name__)


@dataclass
class SessionResult:
    """Result of a session run/resume."""

    session_id: str = ""
    status: str = ""
    goals_total: int = 0
    goals_done: int = 0
    goals_failed: int = 0
    goals_blocked: int = 0
    goals_skipped: int = 0
    current_goal_index: int = 0
    last_block_reason: str = ""
    next_commands: list[str] = field(default_factory=list)


def _now_iso() -> str:
    from datetime import UTC, datetime

    return datetime.now(UTC).isoformat()


def run_session(
    session_id: str,
    sessions_dir: Path,
    runs_dir: Path,
    policies_dir: Path,
    ledger_dir: Path,
    *,
    max_concurrency: int | None = None,
    continue_on_fail: bool | None = None,
    on_event: Any = None,
    memory_db: Path | None = None,
) -> SessionResult:
    """Run or resume a session using DAG-aware scheduling.

    Acquires session lock, schedules goals by dependency layers,
    runs up to max_concurrency goals in parallel.
    """
    lock_path = sessions_dir / session_id / ".lock"
    lock = SessionLock(lock_path)
    if not lock.acquire():
        msg = f"Session {session_id} is locked (another runner active)"
        raise RuntimeError(msg)

    try:
        return _run_session_inner(
            session_id,
            sessions_dir,
            runs_dir,
            policies_dir,
            ledger_dir,
            max_concurrency=max_concurrency,
            continue_on_fail=continue_on_fail,
            on_event=on_event,
            memory_db=memory_db,
        )
    finally:
        lock.release()


def _run_session_inner(
    session_id: str,
    sessions_dir: Path,
    runs_dir: Path,
    policies_dir: Path,
    ledger_dir: Path,
    *,
    max_concurrency: int | None = None,
    continue_on_fail: bool | None = None,
    on_event: Any = None,
    memory_db: Path | None = None,
) -> SessionResult:
    """Inner session runner (lock already held)."""
    from owlmind.autopilot import AutoPilotConfig
    from owlmind.autopilot import run as autopilot_run

    if memory_db is not None:
        _orig_run = autopilot_run

        def autopilot_run(ap_config: Any) -> Any:  # type: ignore[misc]
            """Wrapped autopilot run that records a self-eval memory signal."""
            result = _orig_run(ap_config)
            _status = _map_ap_state(result.final_state)
            try:
                from owlmind.memory.store import MemoryStore

                _store = MemoryStore(memory_db)
                _kind = "lesson" if _status == "done" else "pattern"
                _summary = f"Goal '{ap_config.goal[:80]}' \u2192 {_status}"
                _store.add_signal(_kind, _summary, run_id=result.run_id)
                _store.close()
            except Exception:
                logger.debug("memory signal write failed; continuing", exc_info=True)
            return result

    meta = load_session(session_id, sessions_dir)

    if meta.status in (SESSION_DONE, SESSION_FAILED):
        return _build_result(meta)

    # Apply overrides from CLI flags (if provided)
    if max_concurrency is not None:
        meta.max_concurrency = max_concurrency
    if continue_on_fail is not None:
        meta.continue_on_fail = continue_on_fail

    # Resume: reset status to RUNNING
    meta.status = SESSION_RUNNING
    meta.last_block_reason = ""
    save_session(meta, sessions_dir)

    # Build goal dicts for DAG operations
    goal_dicts: list[dict[str, object]] = [
        {"id": g.id, "depends_on": g.depends_on, "goal": g.goal} for g in meta.goals
    ]

    # Validate DAG
    try:
        validate_dag(goal_dicts)
    except (ValueError, Exception) as exc:
        meta.status = SESSION_FAILED
        meta.last_block_reason = f"DAG validation error: {exc}"
        save_session(meta, sessions_dir)
        render_protocol(session_id, sessions_dir, runs_dir)
        return _build_result(meta)

    # Build run map
    run_map = {r.goal_id: r for r in meta.runs}

    # Build status map
    def _status_map() -> dict[str, str]:
        smap: dict[str, str] = {}
        for g in meta.goals:
            run = run_map.get(g.id)
            smap[g.id] = run.status if run else "pending"
        return smap

    # Determine if parallel execution is needed
    use_parallel = meta.max_concurrency > 1

    if use_parallel:
        return _run_parallel(
            meta,
            session_id,
            sessions_dir,
            runs_dir,
            policies_dir,
            ledger_dir,
            goal_dicts,
            run_map,
            _status_map,
            autopilot_run,
            AutoPilotConfig,
            on_event,
        )

    # Sequential execution (max_concurrency=1): DAG-ordered
    return _run_sequential(
        meta,
        session_id,
        sessions_dir,
        runs_dir,
        policies_dir,
        ledger_dir,
        goal_dicts,
        run_map,
        _status_map,
        autopilot_run,
        AutoPilotConfig,
        on_event,
    )


def _run_sequential(
    meta: SessionMeta,
    session_id: str,
    sessions_dir: Path,
    runs_dir: Path,
    policies_dir: Path,
    ledger_dir: Path,
    goal_dicts: list[dict[str, object]],
    run_map: dict[str, GoalRunInfo],
    status_map_fn: Any,
    autopilot_run: Any,
    autopilot_config_cls: Any,
    on_event: Any,
) -> SessionResult:
    """Execute goals sequentially in topological order."""
    layers = topological_layers(goal_dicts)
    goal_map = {g.id: g for g in meta.goals}

    for layer in layers:
        for gid in layer:
            goal = goal_map[gid]
            statuses = status_map_fn()

            # Skip done/failed/skipped
            if statuses.get(gid) in ("done", "skipped"):
                continue
            if statuses.get(gid) == "failed":
                if not meta.continue_on_fail:
                    meta.status = SESSION_FAILED
                    meta.last_block_reason = f"Goal {gid} previously failed"
                    save_session(meta, sessions_dir)
                    render_protocol(session_id, sessions_dir, runs_dir)
                    return _build_result(meta)
                continue

            # Check deps
            deps_ok = all(
                statuses.get(d, "pending") in ("done", "skipped") for d in goal.depends_on
            )
            if not deps_ok:
                # Dep failed — skip or fail
                dep_failed = any(statuses.get(d) == "failed" for d in goal.depends_on)
                if dep_failed:
                    if meta.continue_on_fail:
                        _mark_skipped(meta, run_map, gid, session_id, sessions_dir)
                        continue
                    meta.status = SESSION_FAILED
                    failed_dep = next(d for d in goal.depends_on if statuses.get(d) == "failed")
                    meta.last_block_reason = f"Goal {gid}: dependency {failed_dep} failed"
                    save_session(meta, sessions_dir)
                    render_protocol(session_id, sessions_dir, runs_dir)
                    return _build_result(meta)
                # Dep blocked — skip this goal for now (shouldn't happen in sequential)
                continue

            result = _run_single_goal(
                meta,
                goal,
                session_id,
                sessions_dir,
                runs_dir,
                policies_dir,
                ledger_dir,
                run_map,
                autopilot_run,
                autopilot_config_cls,
                on_event,
            )
            if result is not None:
                return result

    # All goals processed
    meta.status = SESSION_DONE
    meta.current_goal_index = len(meta.goals)
    save_session(meta, sessions_dir)
    append_session_event(
        session_id,
        sessions_dir,
        {
            "event": "SESSION_DONE",
            "goals_total": len(meta.goals),
        },
    )
    render_protocol(session_id, sessions_dir, runs_dir)
    return _build_result(meta)


def _run_parallel(
    meta: SessionMeta,
    session_id: str,
    sessions_dir: Path,
    runs_dir: Path,
    policies_dir: Path,
    ledger_dir: Path,
    goal_dicts: list[dict[str, object]],
    run_map: dict[str, GoalRunInfo],
    status_map_fn: Any,
    autopilot_run: Any,
    autopilot_config_cls: Any,
    on_event: Any,
) -> SessionResult:
    """Execute goals with concurrency using asyncio."""
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(
            _run_parallel_async(
                meta,
                session_id,
                sessions_dir,
                runs_dir,
                policies_dir,
                ledger_dir,
                goal_dicts,
                run_map,
                status_map_fn,
                autopilot_run,
                autopilot_config_cls,
                on_event,
            ),
        )
    finally:
        loop.close()


async def _run_parallel_async(
    meta: SessionMeta,
    session_id: str,
    sessions_dir: Path,
    runs_dir: Path,
    policies_dir: Path,
    ledger_dir: Path,
    goal_dicts: list[dict[str, object]],
    run_map: dict[str, GoalRunInfo],
    status_map_fn: Any,
    autopilot_run: Any,
    autopilot_config_cls: Any,
    on_event: Any,
) -> SessionResult:
    """Async parallel execution loop."""
    goal_map = {g.id: g for g in meta.goals}
    semaphore = asyncio.Semaphore(meta.max_concurrency)
    session_blocked = False
    session_failed = False

    async def _run_goal_async(gid: str) -> tuple[str, str]:
        """Run a single goal under the semaphore. Returns (goal_id, status)."""
        async with semaphore:
            goal = goal_map[gid]
            loop = asyncio.get_event_loop()
            # Run blocking autopilot in executor
            ap_result = await loop.run_in_executor(
                None,
                lambda: _execute_autopilot(
                    goal,
                    meta,
                    run_map,
                    session_id,
                    sessions_dir,
                    runs_dir,
                    policies_dir,
                    ledger_dir,
                    autopilot_run,
                    autopilot_config_cls,
                    on_event,
                ),
            )
            return gid, ap_result

    # Process layers
    layers = topological_layers(goal_dicts)

    for layer in layers:
        if session_blocked or (session_failed and not meta.continue_on_fail):
            break

        statuses = status_map_fn()
        # Filter to goals that are actually ready
        to_run = [
            gid
            for gid in layer
            if statuses.get(gid, "pending") == "pending"
            and all(
                statuses.get(d, "pending") in ("done", "skipped") for d in goal_map[gid].depends_on
            )
        ]

        # Check for goals with failed deps
        for gid in layer:
            if statuses.get(gid, "pending") != "pending":
                continue
            dep_failed = any(statuses.get(d) == "failed" for d in goal_map[gid].depends_on)
            if dep_failed:
                if meta.continue_on_fail:
                    _mark_skipped(meta, run_map, gid, session_id, sessions_dir)
                else:
                    session_failed = True
                    failed_dep = next(
                        d for d in goal_map[gid].depends_on if statuses.get(d) == "failed"
                    )
                    meta.status = SESSION_FAILED
                    meta.last_block_reason = f"Goal {gid}: dependency {failed_dep} failed"
                    save_session(meta, sessions_dir)
                    break

        if session_failed and not meta.continue_on_fail:
            break

        if not to_run:
            continue

        # Launch all ready goals in parallel
        tasks = [asyncio.create_task(_run_goal_async(gid)) for gid in to_run]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        for r in results:
            if isinstance(r, BaseException):
                logger.error("Goal execution error: %s", r)
                continue
            gid, status = r
            if status == "blocked":
                session_blocked = True
            elif status == "failed" and not meta.continue_on_fail:
                session_failed = True

    # Final status
    if session_blocked:
        meta.status = SESSION_BLOCKED
        save_session(meta, sessions_dir)
        append_session_event(
            session_id,
            sessions_dir,
            {
                "event": "SESSION_BLOCKED",
                "reason": meta.last_block_reason,
            },
        )
    elif session_failed:
        if meta.status != SESSION_FAILED:
            meta.status = SESSION_FAILED
            save_session(meta, sessions_dir)
        append_session_event(
            session_id,
            sessions_dir,
            {
                "event": "SESSION_FAILED",
                "reason": meta.last_block_reason,
            },
        )
    else:
        meta.status = SESSION_DONE
        meta.current_goal_index = len(meta.goals)
        save_session(meta, sessions_dir)
        append_session_event(
            session_id,
            sessions_dir,
            {
                "event": "SESSION_DONE",
                "goals_total": len(meta.goals),
            },
        )

    render_protocol(session_id, sessions_dir, runs_dir)
    return _build_result(meta)


def _execute_autopilot(
    goal: Any,
    meta: SessionMeta,
    run_map: dict[str, GoalRunInfo],
    session_id: str,
    sessions_dir: Path,
    runs_dir: Path,
    policies_dir: Path,
    ledger_dir: Path,
    autopilot_run: Any,
    autopilot_config_cls: Any,
    on_event: Any,
) -> str:
    """Execute autopilot for a single goal. Returns status string."""
    existing_run = run_map.get(goal.id)
    run_id_to_resume: str | None = None

    if existing_run and existing_run.status in ("blocked", "running"):
        run_id_to_resume = existing_run.run_id
    elif existing_run and existing_run.status == "done":
        return "done"

    _emit(
        on_event,
        "session_goal_starting",
        {
            "session_id": session_id,
            "goal_id": goal.id,
        },
    )

    ap_config = autopilot_config_cls(
        goal=goal.goal,
        workspace=goal.workspace,
        sandbox=goal.sandbox,
        use_llm=goal.use_llm,
        use_worker=goal.use_worker,
        provider_planner=goal.provider_planner,
        provider_judge=goal.provider_judge,
        max_steps=goal.max_steps,
        interval=goal.interval_sec,
        auto_export=goal.export_on_done,
        run_id=run_id_to_resume,
        policies_dir=policies_dir,
        runs_dir=runs_dir,
        ledger_dir=ledger_dir,
        on_event=on_event,
    )

    ap_result = autopilot_run(ap_config)
    status = _map_ap_state(ap_result.final_state)
    now = _now_iso()

    if existing_run:
        existing_run.status = status
        existing_run.ended_at = now
    else:
        run_info = GoalRunInfo(
            goal_id=goal.id,
            run_id=ap_result.run_id,
            status=status,
            started_at=now,
            ended_at=now,
        )
        meta.runs.append(run_info)
        run_map[goal.id] = run_info

    save_session(meta, sessions_dir)

    if status == "done":
        append_session_event(
            session_id,
            sessions_dir,
            {
                "event": "GOAL_DONE",
                "goal_id": goal.id,
                "run_id": ap_result.run_id,
            },
        )
        _emit(
            on_event,
            "session_goal_done",
            {
                "session_id": session_id,
                "goal_id": goal.id,
            },
        )
    elif status == "failed":
        append_session_event(
            session_id,
            sessions_dir,
            {
                "event": "GOAL_FAILED",
                "goal_id": goal.id,
                "run_id": ap_result.run_id,
            },
        )
        meta.last_block_reason = f"Goal {goal.id} failed: {ap_result.stop_reason}"
        save_session(meta, sessions_dir)
    else:
        block_reason = f"Goal {goal.id}: {ap_result.final_state} ({ap_result.stop_reason})"
        append_session_event(
            session_id,
            sessions_dir,
            {
                "event": "GOAL_BLOCKED",
                "goal_id": goal.id,
                "run_id": ap_result.run_id,
                "reason": block_reason,
            },
        )
        meta.status = SESSION_BLOCKED
        meta.last_block_reason = block_reason
        save_session(meta, sessions_dir)

    return status


def _run_single_goal(
    meta: SessionMeta,
    goal: Any,
    session_id: str,
    sessions_dir: Path,
    runs_dir: Path,
    policies_dir: Path,
    ledger_dir: Path,
    run_map: dict[str, GoalRunInfo],
    autopilot_run: Any,
    autopilot_config_cls: Any,
    on_event: Any,
) -> SessionResult | None:
    """Run a single goal in sequential mode.

    Returns SessionResult if session should stop, None to continue.
    """
    status = _execute_autopilot(
        goal,
        meta,
        run_map,
        session_id,
        sessions_dir,
        runs_dir,
        policies_dir,
        ledger_dir,
        autopilot_run,
        autopilot_config_cls,
        on_event,
    )

    if status == "done":
        return None

    if status == "failed":
        if meta.continue_on_fail:
            return None
        meta.status = SESSION_FAILED
        save_session(meta, sessions_dir)
        append_session_event(
            session_id,
            sessions_dir,
            {
                "event": "SESSION_FAILED",
                "reason": meta.last_block_reason,
            },
        )
        render_protocol(session_id, sessions_dir, runs_dir)
        return _build_result(meta)

    # Blocked
    append_session_event(
        session_id,
        sessions_dir,
        {
            "event": "SESSION_BLOCKED",
            "reason": meta.last_block_reason,
        },
    )
    render_protocol(session_id, sessions_dir, runs_dir)
    return _build_result(meta)


def _mark_skipped(
    meta: SessionMeta,
    run_map: dict[str, GoalRunInfo],
    gid: str,
    session_id: str,
    sessions_dir: Path,
) -> None:
    """Mark a goal as skipped (dependency failed, continue_on_fail=true)."""
    now = _now_iso()
    existing = run_map.get(gid)
    if existing:
        existing.status = "skipped"
        existing.ended_at = now
    else:
        run_info = GoalRunInfo(
            goal_id=gid,
            run_id=f"skipped-{gid}",
            status="skipped",
            started_at=now,
            ended_at=now,
        )
        meta.runs.append(run_info)
        run_map[gid] = run_info

    append_session_event(
        session_id,
        sessions_dir,
        {
            "event": "GOAL_SKIPPED",
            "goal_id": gid,
            "reason": "dependency failed",
        },
    )
    save_session(meta, sessions_dir)


def stop_session(
    session_id: str,
    sessions_dir: Path,
    runs_dir: Path,
) -> SessionMeta:
    """Mark a session as STOPPED."""
    meta = load_session(session_id, sessions_dir)
    meta.status = SESSION_STOPPED
    meta.last_block_reason = "User requested stop"
    save_session(meta, sessions_dir)

    append_session_event(
        session_id,
        sessions_dir,
        {
            "event": "SESSION_STOPPED",
        },
    )
    render_protocol(session_id, sessions_dir, runs_dir)
    return meta


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _map_ap_state(state: str) -> str:
    """Map autopilot final state to goal run status."""
    if state == "DONE":
        return "done"
    if state == "FAILED":
        return "failed"
    return "blocked"


def _build_result(meta: SessionMeta) -> SessionResult:
    """Build a SessionResult from current metadata."""
    run_statuses = [r.status for r in meta.runs]
    return SessionResult(
        session_id=meta.session_id,
        status=meta.status,
        goals_total=len(meta.goals),
        goals_done=run_statuses.count("done"),
        goals_failed=run_statuses.count("failed"),
        goals_blocked=run_statuses.count("blocked"),
        goals_skipped=run_statuses.count("skipped"),
        current_goal_index=meta.current_goal_index,
        last_block_reason=meta.last_block_reason,
        next_commands=_build_next_commands(meta),
    )


def _build_next_commands(meta: SessionMeta) -> list[str]:
    """Generate suggested next CLI commands."""
    cmds: list[str] = []

    if meta.status == SESSION_BLOCKED:
        for run in reversed(meta.runs):
            if run.status == "blocked":
                cmds.append(
                    f"owlmind cycle approve --run-id {run.run_id} --token <TOKEN>",
                )
                break
        cmds.append(f"owlmind session resume --session-id {meta.session_id}")

    elif meta.status in (SESSION_RUNNING, SESSION_STOPPED):
        cmds.append(f"owlmind session resume --session-id {meta.session_id}")

    elif meta.status == SESSION_DONE:
        cmds.append(f"owlmind session export --session-id {meta.session_id}")

    elif meta.status == SESSION_FAILED:
        cmds.append(f"owlmind session status --session-id {meta.session_id}")

    return cmds


def _emit(on_event: Any, name: str, data: dict[str, Any]) -> None:
    """Fire on_event callback if configured."""
    if on_event is not None:
        try:
            on_event(name, data)
        except Exception:
            logger.debug("on_event callback error for %s", name)
