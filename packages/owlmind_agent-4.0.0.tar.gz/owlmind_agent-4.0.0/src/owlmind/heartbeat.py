"""Heartbeat engine — polling loop for queue, stuck runs, and notifications."""

from __future__ import annotations

import logging
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from owlmind.agent.schemas import CycleState
from owlmind.config import HeartbeatConfig
from owlmind.events import EventBus
from owlmind.queue import QueueStatus, TaskQueue

logger = logging.getLogger(__name__)


class HeartbeatEngine:
    """Polling engine that monitors queue, runs, and sends notifications."""

    def __init__(
        self,
        config: HeartbeatConfig,
        queue: TaskQueue,
        event_bus: EventBus,
        *,
        policies_dir: Path = Path("policies"),
        runs_dir: Path = Path("runs"),
        ledger_dir: Path = Path("ledger"),
    ) -> None:
        self.config = config
        self.queue = queue
        self.event_bus = event_bus
        self.policies_dir = policies_dir
        self.runs_dir = runs_dir
        self.ledger_dir = ledger_dir

        self._auto_starts_this_hour: list[float] = []
        self._notification_cooldown: dict[str, float] = {}
        self._budget_warned: bool = False

    def _prune_auto_starts(self) -> None:
        """Remove auto-start timestamps older than 1 hour."""
        cutoff = time.time() - 3600
        self._auto_starts_this_hour = [t for t in self._auto_starts_this_hour if t > cutoff]

    def _can_auto_start(self) -> bool:
        """Check if we haven't exceeded auto-start quota."""
        self._prune_auto_starts()
        return len(self._auto_starts_this_hour) < self.config.max_auto_starts_per_hour

    def _should_notify(self, run_id: str) -> bool:
        """Check if enough time has passed since last notification for this run."""
        now = time.time()
        last = self._notification_cooldown.get(run_id, 0.0)
        if now - last < self.config.notification_cooldown_seconds:
            return False
        self._notification_cooldown[run_id] = now
        return True

    def _make_cycle_manager(self) -> Any:
        """Lazy-create a CycleManager."""
        from owlmind.agent.cycle import CycleManager
        from owlmind.evidence import EvidenceStore
        from owlmind.policy import PolicyEngine

        policy = PolicyEngine.from_directory(self.policies_dir)
        evidence = EvidenceStore(self.runs_dir)
        return CycleManager(evidence=evidence, policy=policy, policies_dir=self.policies_dir)

    def _check_daily_budget(self) -> tuple[bool, str]:
        """Check if daily budget allows new work. Returns (ok, message)."""
        try:
            from owlmind.config import OwlMindConfig
            from owlmind.ledger import UsageLedger

            cfg = OwlMindConfig.from_env()
            ledger = UsageLedger(self.ledger_dir)
            day_totals = ledger.totals_for_day()

            if day_totals.total_tokens >= cfg.budget.max_tokens_per_day:
                return False, (
                    f"Daily token limit reached: {day_totals.total_tokens:,}"
                    f" / {cfg.budget.max_tokens_per_day:,}"
                )
            if day_totals.estimated_usd >= cfg.budget.max_usd_per_day:
                return False, (
                    f"Daily USD limit reached: ${day_totals.estimated_usd:.4f}"
                    f" / ${cfg.budget.max_usd_per_day:.2f}"
                )
            return True, "Budget OK"
        except Exception:
            return True, "Budget check skipped (no ledger)"

    def check_queue(self, *, auto_start: bool = False) -> list[str]:
        """Check queue for pending tasks. Returns list of messages."""
        messages: list[str] = []
        pending = self.queue.list_items(status=QueueStatus.PENDING)

        if not pending:
            return messages

        messages.append(f"Queue: {len(pending)} pending task(s)")

        # Check budget before auto-starting
        if auto_start:
            budget_ok, budget_msg = self._check_daily_budget()
            if not budget_ok:
                if not self._budget_warned:
                    messages.append(f"Budget limit: {budget_msg}")
                    self.event_bus.publish("budget_limit_reached", {"reason": budget_msg})
                    self._budget_warned = True
                return messages

        if auto_start and self._can_auto_start() and pending:
            item = pending[0]
            try:
                mgr = self._make_cycle_manager()
                meta = mgr.start(
                    goal=item.goal,
                    workspace=item.workspace,
                    sandbox=item.sandbox,
                )
                self.queue.mark_running(item.id, meta.run_id)
                self._auto_starts_this_hour.append(time.time())
                messages.append(f"Auto-started: {item.goal} -> {meta.run_id}")
                self.event_bus.publish(
                    "queue_auto_start",
                    {
                        "item_id": item.id,
                        "run_id": meta.run_id,
                        "goal": item.goal,
                    },
                )
            except Exception as exc:
                self.queue.mark_failed(item.id, str(exc))
                messages.append(f"Failed to auto-start {item.id}: {exc}")
                logger.exception("Auto-start failed for %s", item.id)

        return messages

    def check_stuck_runs(self) -> list[str]:
        """Check for runs stuck in WAIT_* states too long."""
        messages: list[str] = []

        meta_pattern = self.runs_dir / "cycle-*" / "cycle_meta.json"
        import glob
        import json

        for meta_path_str in glob.glob(str(meta_pattern)):
            meta_path = Path(meta_path_str)
            try:
                data = json.loads(meta_path.read_text())
                state = data.get("state", "")
                run_id = data.get("run_id", "")
                updated_at_str = data.get("updated_at", "")

                if state in (CycleState.DONE.value, CycleState.FAILED.value):
                    continue

                if not updated_at_str:
                    continue

                updated_at = datetime.fromisoformat(updated_at_str)
                elapsed = (datetime.now(tz=UTC) - updated_at).total_seconds()

                if elapsed > self.config.stuck_threshold_seconds and self._should_notify(run_id):
                    msg = f"Run {run_id} stuck in {state} for {elapsed:.0f}s"
                    messages.append(msg)
                    self.event_bus.publish(
                        "run_stuck",
                        {
                            "run_id": run_id,
                            "state": state,
                            "elapsed_seconds": elapsed,
                        },
                    )

                if state == CycleState.WAIT_APPROVAL.value:
                    approval = data.get("extra", {}).get("pending_approval", {})
                    token = approval.get("token", "")
                    if token and self._should_notify(f"{run_id}_approval"):
                        msg = f"Run {run_id} waiting approval. Token: {token}"
                        messages.append(msg)
                        self.event_bus.publish(
                            "approval_pending",
                            {
                                "run_id": run_id,
                                "token": token,
                            },
                        )

            except (json.JSONDecodeError, KeyError, ValueError):
                continue

        return messages

    def tick(self, *, auto_start: bool = False) -> list[str]:
        """Run one heartbeat cycle. Returns list of status messages."""
        messages: list[str] = []
        messages.extend(self.check_queue(auto_start=auto_start))
        messages.extend(self.check_stuck_runs())
        return messages

    def run_loop(
        self,
        *,
        auto_start: bool = False,
        max_ticks: int = 0,
    ) -> None:
        """Run the heartbeat loop. max_ticks=0 means infinite."""
        tick_count = 0
        logger.info(
            "Heartbeat started (interval=%ds, auto_start=%s)",
            self.config.interval_seconds,
            auto_start,
        )

        while True:
            tick_count += 1
            messages = self.tick(auto_start=auto_start)
            for msg in messages:
                logger.info("[heartbeat] %s", msg)

            if max_ticks and tick_count >= max_ticks:
                break

            time.sleep(self.config.interval_seconds)
