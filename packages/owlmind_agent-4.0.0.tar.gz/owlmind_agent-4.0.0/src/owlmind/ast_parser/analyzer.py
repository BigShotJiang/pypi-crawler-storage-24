from __future__ import annotations

import logging
import os
import re
from pathlib import Path
from typing import Any

from owlmind.ast_parser.languages import (
    EXTENSION_TO_LANGUAGE,
    SKIP_DIRS,
    detect_language,
    get_treesitter_parser,
)
from owlmind.ast_parser.models import (
    ClassInfo,
    CodeChunk,
    FileAnalysis,
    FunctionInfo,
    ImportInfo,
    RepositoryMap,
)

logger = logging.getLogger(__name__)

_TREESITTER_AVAILABLE = False
try:
    import tree_sitter  # noqa: F401
    _TREESITTER_AVAILABLE = True
except ImportError:
    pass


def is_treesitter_available() -> bool:
    return _TREESITTER_AVAILABLE


_CHUNK_MAX_CHARS = 800
_CHUNK_OVERLAP = 100
_MAX_CHUNKS_PER_FILE = 100


class CodeAnalyzer:
    """Analyzes source code using Tree-sitter for AST-based understanding.

    Falls back to regex-based analysis when Tree-sitter is unavailable.
    """

    def analyze_file(self, file_path: str) -> FileAnalysis:
        """Parse a source file and extract functions, classes, imports."""
        path = Path(file_path)
        if not path.exists():
            return FileAnalysis(file_path=file_path, error=f"File not found: {file_path}")

        try:
            content = path.read_text(encoding="utf-8", errors="replace")
        except Exception as e:
            return FileAnalysis(file_path=file_path, error=str(e))

        language = detect_language(file_path)
        lines = content.splitlines()
        total_lines = len(lines)

        analysis = FileAnalysis(
            file_path=file_path,
            language=language,
            total_lines=total_lines,
        )

        # Try Tree-sitter first for Python (most common)
        if language == "python":
            parser = get_treesitter_parser("python")
            if parser:
                try:
                    self._analyze_python_treesitter(parser, content, analysis)
                except Exception as e:
                    logger.debug("Tree-sitter Python analysis failed: %s", e)
                    self._analyze_python_regex(content, analysis)
            else:
                self._analyze_python_regex(content, analysis)
        elif language in ("javascript", "typescript", "tsx"):
            parser = get_treesitter_parser(language)
            if parser:
                try:
                    self._analyze_js_treesitter(parser, content, analysis)
                except Exception as e:
                    logger.debug("Tree-sitter JS/TS analysis failed: %s", e)
                    self._analyze_js_regex(content, analysis)
            else:
                self._analyze_js_regex(content, analysis)
        else:
            # Generic regex fallback for other languages
            self._analyze_generic_regex(content, language, analysis)

        # Generate chunks for RAG
        analysis.chunks = self.chunk_for_rag(analysis, content)
        return analysis

    def analyze_directory(
        self,
        root_path: str,
        include_patterns: list[str] | None = None,
        exclude_patterns: list[str] | None = None,
        max_files: int = 1000,
    ) -> RepositoryMap:
        """Analyze an entire directory and build a repository map."""
        root = Path(root_path)
        if not root.exists():
            msg = f"Directory not found: {root_path}"
            raise FileNotFoundError(msg)

        repo_map = RepositoryMap(root_path=str(root))
        files_processed = 0
        languages: dict[str, int] = {}

        for file_path in self._iter_code_files(root, max_files):
            rel_path = str(file_path.relative_to(root))

            if include_patterns:
                import fnmatch
                if not any(fnmatch.fnmatch(rel_path, p) for p in include_patterns):
                    continue

            if exclude_patterns:
                import fnmatch
                if any(fnmatch.fnmatch(rel_path, p) for p in exclude_patterns):
                    continue

            analysis = self.analyze_file(str(file_path))
            if not analysis.error:
                repo_map.files[rel_path] = analysis
                repo_map.total_lines += analysis.total_lines
                lang = analysis.language or "unknown"
                languages[lang] = languages.get(lang, 0) + 1
                files_processed += 1

        repo_map.total_files = files_processed
        repo_map.languages = languages
        repo_map.summary = self._build_summary(repo_map)
        return repo_map

    def generate_repo_map(self, root_path: str, max_tokens: int = 4000) -> str:
        """Generate a condensed repository map text for LLM context.

        Format similar to Aider's repo map — shows file structure with
        function/class signatures.
        """
        repo_map = self.analyze_directory(root_path)
        return self._render_repo_map(repo_map, max_tokens)

    def chunk_for_rag(self, analysis: FileAnalysis, content: str = "") -> list[CodeChunk]:
        """Split file into semantic chunks for embedding/RAG."""
        chunks: list[CodeChunk] = []
        lines = content.splitlines() if content else []

        # Chunk each function
        for func in analysis.functions:
            func_lines = lines[func.start_line - 1:func.end_line] if lines else []
            func_content = "\n".join(func_lines)
            if func_content.strip():
                chunks.append(CodeChunk(
                    file_path=analysis.file_path,
                    language=analysis.language,
                    content=func_content[:_CHUNK_MAX_CHARS],
                    start_line=func.start_line,
                    end_line=func.end_line,
                    chunk_type="function",
                    name=func.name,
                ))

        # Chunk each class (signatures only to keep size reasonable)
        for cls in analysis.classes:
            sig_lines = [f"class {cls.name}"]
            if cls.base_classes:
                sig_lines[0] += f"({', '.join(cls.base_classes)})"
            if cls.docstring:
                sig_lines.append(f'    """{cls.docstring[:100]}"""')
            for method in cls.methods[:20]:
                params = ", ".join(method.parameters) if method.parameters else "..."
                prefix = "async def" if method.is_async else "def"
                sig_lines.append(f"    {prefix} {method.name}({params})")

            cls_content = "\n".join(sig_lines)
            if cls_content.strip():
                chunks.append(CodeChunk(
                    file_path=analysis.file_path,
                    language=analysis.language,
                    content=cls_content[:_CHUNK_MAX_CHARS],
                    start_line=cls.start_line,
                    end_line=cls.end_line,
                    chunk_type="class",
                    name=cls.name,
                ))

        # Imports block
        if analysis.imports:
            import_lines = []
            for imp in analysis.imports[:30]:
                if imp.is_from_import:
                    names = ", ".join(imp.names)
                    import_lines.append(f"from {imp.module} import {names}")
                else:
                    alias = f" as {imp.alias}" if imp.alias else ""
                    import_lines.append(f"import {imp.module}{alias}")

            if import_lines:
                chunks.append(CodeChunk(
                    file_path=analysis.file_path,
                    language=analysis.language,
                    content="\n".join(import_lines)[:_CHUNK_MAX_CHARS],
                    start_line=1,
                    end_line=len(import_lines),
                    chunk_type="import_block",
                    name="imports",
                ))

        return chunks[:_MAX_CHUNKS_PER_FILE]

    # ── Python Tree-sitter analysis ──

    def _analyze_python_treesitter(self, parser: Any, content: str, analysis: FileAnalysis) -> None:
        """Extract Python code structure using Tree-sitter AST."""
        source_bytes = content.encode("utf-8")
        tree = parser.parse(source_bytes)
        root = tree.root_node

        for node in root.children:
            ntype = node.type
            if ntype == "function_definition":
                func = self._parse_python_function(node, source_bytes)
                if func:
                    analysis.functions.append(func)
            elif ntype == "decorated_definition":
                # Decorated function or class
                decorators = []
                for child in node.children:
                    if child.type == "decorator":
                        decorators.append(self._node_text(child, source_bytes).lstrip("@"))
                    elif child.type in ("function_definition", "async_function_definition"):
                        func = self._parse_python_function(child, source_bytes, decorators)
                        if func:
                            analysis.functions.append(func)
                    elif child.type == "class_definition":
                        cls = self._parse_python_class(child, source_bytes, decorators)
                        if cls:
                            analysis.classes.append(cls)
            elif ntype == "async_function_definition":
                func = self._parse_python_function(node, source_bytes, is_async=True)
                if func:
                    analysis.functions.append(func)
            elif ntype == "class_definition":
                cls = self._parse_python_class(node, source_bytes)
                if cls:
                    analysis.classes.append(cls)
            elif ntype in ("import_statement", "import_from_statement"):
                imp = self._parse_python_import(node, source_bytes)
                if imp:
                    analysis.imports.append(imp)

    def _parse_python_function(
        self,
        node: Any,
        source_bytes: bytes,
        decorators: list[str] | None = None,
        is_async: bool = False,
    ) -> FunctionInfo | None:
        name = ""
        params: list[str] = []
        return_type = ""
        docstring = ""

        for child in node.children:
            if child.type == "identifier":
                name = self._node_text(child, source_bytes)
            elif child.type == "parameters":
                params = self._extract_params(child, source_bytes)
            elif child.type == "type":
                return_type = self._node_text(child, source_bytes)
            elif child.type == "block":
                # Try to get docstring (first expression statement with string)
                for stmt in child.children:
                    if stmt.type == "expression_statement":
                        for s in stmt.children:
                            if s.type in ("string", "concatenated_string"):
                                docstring = self._node_text(s, source_bytes).strip("\"'")[:200]
                        break

        if not name:
            return None

        return FunctionInfo(
            name=name,
            start_line=node.start_point[0] + 1,
            end_line=node.end_point[0] + 1,
            parameters=params,
            return_type=return_type,
            is_async=is_async or node.type == "async_function_definition",
            decorators=decorators or [],
            docstring=docstring,
        )

    def _parse_python_class(
        self,
        node: Any,
        source_bytes: bytes,
        decorators: list[str] | None = None,
    ) -> ClassInfo | None:
        name = ""
        bases: list[str] = []
        methods: list[FunctionInfo] = []
        docstring = ""

        for child in node.children:
            if child.type == "identifier":
                name = self._node_text(child, source_bytes)
            elif child.type == "argument_list":
                bases = [self._node_text(c, source_bytes) for c in child.children if c.type not in (",", "(", ")")]
            elif child.type == "block":
                for stmt in child.children:
                    if stmt.type == "expression_statement":
                        for s in stmt.children:
                            if s.type in ("string",) and not docstring:
                                docstring = self._node_text(s, source_bytes).strip("\"'")[:200]
                    elif stmt.type in ("function_definition", "async_function_definition"):
                        meth = self._parse_python_function(stmt, source_bytes)
                        if meth:
                            methods.append(meth)
                    elif stmt.type == "decorated_definition":
                        decs = []
                        for c in stmt.children:
                            if c.type == "decorator":
                                decs.append(self._node_text(c, source_bytes).lstrip("@"))
                            elif c.type in ("function_definition", "async_function_definition"):
                                meth = self._parse_python_function(c, source_bytes, decs)
                                if meth:
                                    methods.append(meth)

        if not name:
            return None

        return ClassInfo(
            name=name,
            start_line=node.start_point[0] + 1,
            end_line=node.end_point[0] + 1,
            base_classes=bases,
            methods=methods,
            decorators=decorators or [],
            docstring=docstring,
        )

    def _parse_python_import(self, node: Any, source_bytes: bytes) -> ImportInfo | None:
        text = self._node_text(node, source_bytes)
        line = node.start_point[0] + 1

        if node.type == "import_from_statement":
            # from X import Y, Z
            parts = text.split("import", 1)
            module = parts[0].replace("from", "").strip()
            names_part = parts[1].strip() if len(parts) > 1 else ""
            names = [n.strip() for n in names_part.replace("(", "").replace(")", "").split(",")]
            return ImportInfo(module=module, names=[n for n in names if n], line=line, is_from_import=True)
        else:
            # import X [as Y]
            parts = text.replace("import", "").strip().split(" as ")
            module = parts[0].strip()
            alias = parts[1].strip() if len(parts) > 1 else ""
            return ImportInfo(module=module, alias=alias, line=line)

    def _node_text(self, node: Any, source_bytes: bytes) -> str:
        return source_bytes[node.start_byte:node.end_byte].decode("utf-8", errors="replace")

    def _extract_params(self, params_node: Any, source_bytes: bytes) -> list[str]:
        params = []
        for child in params_node.children:
            if child.type in ("identifier", "typed_parameter", "default_parameter",
                               "typed_default_parameter", "list_splat_pattern", "dictionary_splat_pattern"):
                text = self._node_text(child, source_bytes)
                params.append(text.split(":")[0].split("=")[0].strip().lstrip("*"))
        return [p for p in params if p and p != "self" and p != "cls"]

    # ── Python regex fallback ──

    def _analyze_python_regex(self, content: str, analysis: FileAnalysis) -> None:
        """Regex-based Python analysis fallback."""
        lines = content.splitlines()

        func_pattern = re.compile(r"^(\s*)(async\s+)?def\s+(\w+)\s*\(([^)]*)\)")
        class_pattern = re.compile(r"^(\s*)class\s+(\w+)\s*(?:\(([^)]*)\))?:")
        import_pattern = re.compile(r"^(?:from\s+([\w.]+)\s+import\s+([\w\s,*]+)|import\s+([\w.]+)(?:\s+as\s+(\w+))?)")

        for i, line in enumerate(lines, 1):
            m = func_pattern.match(line)
            if m:
                indent, async_kw, name, params_str = m.groups()
                if indent == "":  # module-level function
                    params = [p.strip().split(":")[0].split("=")[0].strip() for p in params_str.split(",") if p.strip()]
                    params = [p for p in params if p and p not in ("self", "cls")]
                    analysis.functions.append(FunctionInfo(
                        name=name,
                        start_line=i,
                        end_line=i,
                        parameters=params,
                        is_async=bool(async_kw),
                    ))
                continue

            m = class_pattern.match(line)
            if m:
                indent, name, bases_str = m.groups()
                if indent == "":
                    bases = [b.strip() for b in (bases_str or "").split(",") if b.strip()]
                    analysis.classes.append(ClassInfo(
                        name=name,
                        start_line=i,
                        end_line=i,
                        base_classes=bases,
                    ))
                continue

            m = import_pattern.match(line.strip())
            if m:
                from_module, from_names, imp_module, imp_alias = m.groups()
                if from_module:
                    names = [n.strip() for n in from_names.split(",") if n.strip()]
                    analysis.imports.append(ImportInfo(module=from_module, names=names, line=i, is_from_import=True))
                elif imp_module:
                    analysis.imports.append(ImportInfo(module=imp_module, alias=imp_alias or "", line=i))

    # ── JS/TS Tree-sitter analysis ──

    def _analyze_js_treesitter(self, parser: Any, content: str, analysis: FileAnalysis) -> None:
        source_bytes = content.encode("utf-8")
        tree = parser.parse(source_bytes)

        def walk(node: Any) -> None:
            ntype = node.type
            if ntype in ("function_declaration", "function_expression", "arrow_function",
                          "method_definition", "generator_function_declaration"):
                name = ""
                for child in node.children:
                    if child.type == "identifier":
                        name = self._node_text(child, source_bytes)
                        break
                if name:
                    analysis.functions.append(FunctionInfo(
                        name=name,
                        start_line=node.start_point[0] + 1,
                        end_line=node.end_point[0] + 1,
                    ))
            elif ntype == "class_declaration":
                name = ""
                for child in node.children:
                    if child.type == "identifier":
                        name = self._node_text(child, source_bytes)
                        break
                if name:
                    analysis.classes.append(ClassInfo(
                        name=name,
                        start_line=node.start_point[0] + 1,
                        end_line=node.end_point[0] + 1,
                    ))
            elif ntype in ("import_statement",):
                text = self._node_text(node, source_bytes)
                analysis.imports.append(ImportInfo(module=text, line=node.start_point[0] + 1, is_from_import=True))

            for child in node.children:
                walk(child)

        walk(tree.root_node)

    def _analyze_js_regex(self, content: str, analysis: FileAnalysis) -> None:
        """Regex-based JS/TS analysis fallback."""
        lines = content.splitlines()
        func_patterns = [
            re.compile(r"^(?:export\s+)?(?:async\s+)?function\s+(\w+)\s*\("),
            re.compile(r"^(?:export\s+)?const\s+(\w+)\s*=\s*(?:async\s+)?\("),
            re.compile(r"^\s+(?:async\s+)?(\w+)\s*\([^)]*\)\s*\{"),
        ]
        class_pattern = re.compile(r"^(?:export\s+)?class\s+(\w+)")

        for i, line in enumerate(lines, 1):
            for p in func_patterns:
                m = p.match(line)
                if m:
                    analysis.functions.append(FunctionInfo(name=m.group(1), start_line=i, end_line=i))
                    break
            m = class_pattern.match(line)
            if m:
                analysis.classes.append(ClassInfo(name=m.group(1), start_line=i, end_line=i))

    def _analyze_generic_regex(self, content: str, language: str, analysis: FileAnalysis) -> None:
        """Generic regex-based analysis for Go, Rust, Java, etc."""
        lines = content.splitlines()
        patterns: dict[str, list[re.Pattern]] = {
            "go": [re.compile(r"^func\s+(?:\(\w+\s+\*?\w+\)\s+)?(\w+)\s*\(")],
            "rust": [re.compile(r"^(?:pub\s+)?(?:async\s+)?fn\s+(\w+)\s*[<(]")],
            "java": [re.compile(r"^\s+(?:public|private|protected|static|\s)+[\w<>\[\]]+\s+(\w+)\s*\(")],
            "kotlin": [re.compile(r"^(?:fun|suspend fun)\s+(\w+)\s*\(")],
            "swift": [re.compile(r"^(?:func|override func|class func)\s+(\w+)\s*\(")],
        }
        class_patterns: dict[str, re.Pattern] = {
            "java": re.compile(r"^(?:public\s+)?(?:abstract\s+)?(?:class|interface|enum)\s+(\w+)"),
            "kotlin": re.compile(r"^(?:data\s+)?(?:class|object|interface)\s+(\w+)"),
            "rust": re.compile(r"^(?:pub\s+)?(?:struct|enum|trait|impl)\s+(\w+)"),
            "go": re.compile(r"^type\s+(\w+)\s+struct"),
            "swift": re.compile(r"^(?:class|struct|enum|protocol)\s+(\w+)"),
        }

        func_pats = patterns.get(language, [])
        cls_pat = class_patterns.get(language)

        for i, line in enumerate(lines, 1):
            for p in func_pats:
                m = p.match(line)
                if m:
                    analysis.functions.append(FunctionInfo(name=m.group(1), start_line=i, end_line=i))
                    break
            if cls_pat:
                m = cls_pat.match(line)
                if m:
                    analysis.classes.append(ClassInfo(name=m.group(1), start_line=i, end_line=i))

    # ── Repository helpers ──

    def _iter_code_files(self, root: Path, max_files: int):
        """Yield code files in directory, skipping common non-code dirs."""
        count = 0
        for dirpath, dirnames, filenames in os.walk(root):
            # Prune skip dirs in-place
            dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS and not d.endswith(".egg-info")]

            for fname in filenames:
                if count >= max_files:
                    return
                fpath = Path(dirpath) / fname
                if fpath.suffix.lower() in EXTENSION_TO_LANGUAGE:
                    yield fpath
                    count += 1

    def _build_summary(self, repo_map: RepositoryMap) -> str:
        lines = [
            f"Repository: {repo_map.root_path}",
            f"Files: {repo_map.total_files} | Lines: {repo_map.total_lines}",
            "Languages: " + ", ".join(f"{lang}:{count}" for lang, count in sorted(repo_map.languages.items(), key=lambda x: -x[1])[:10]),
        ]
        return "\n".join(lines)

    def _render_repo_map(self, repo_map: RepositoryMap, max_tokens: int) -> str:
        """Render repository map as text for LLM context injection."""
        # Rough: 1 token ≈ 4 chars
        max_chars = max_tokens * 4
        parts: list[str] = []

        # Sort files by relevance (files with more functions first)
        sorted_files = sorted(
            repo_map.files.items(),
            key=lambda x: len(x[1].functions) + len(x[1].classes),
            reverse=True,
        )

        for rel_path, analysis in sorted_files:
            if not analysis.functions and not analysis.classes:
                continue

            file_lines = [f"\n{rel_path}:"]

            for cls in analysis.classes:
                file_lines.append(f"  class {cls.name}:")
                for meth in cls.methods[:10]:
                    params = ", ".join(meth.parameters[:5]) if meth.parameters else ""
                    prefix = "async " if meth.is_async else ""
                    file_lines.append(f"    {prefix}{meth.name}({params})")

            for func in analysis.functions:
                params = ", ".join(func.parameters[:5]) if func.parameters else ""
                prefix = "async " if func.is_async else ""
                file_lines.append(f"  {prefix}def {func.name}({params})")

            chunk = "\n".join(file_lines)
            if sum(len(p) for p in parts) + len(chunk) > max_chars:
                parts.append(f"\n... ({len(sorted_files) - len(parts)} more files)")
                break
            parts.append(chunk)

        header = f"# Repository Map: {repo_map.root_path}\n# {repo_map.total_files} files, {repo_map.total_lines} lines\n"
        return header + "".join(parts)
