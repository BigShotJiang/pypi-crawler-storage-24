from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

ast_app = typer.Typer(name="ast", help="Code intelligence — analyze structure, generate repo map", no_args_is_help=True)
console = Console()


@ast_app.command("analyze")
def cmd_analyze(
    path: Annotated[str, typer.Argument(help="File or directory to analyze")],
    output_format: Annotated[str, typer.Option("--format", "-f")] = "table",
) -> None:
    """Analyze code structure and show functions/classes."""
    from owlmind.ast_parser.analyzer import CodeAnalyzer, is_treesitter_available

    console.print(f"Tree-sitter: {'[green]available[/green]' if is_treesitter_available() else '[yellow]not installed (using regex fallback)[/yellow]'}")

    analyzer = CodeAnalyzer()
    p = Path(path)

    if p.is_file():
        analysis = analyzer.analyze_file(path)
        analyses = {path: analysis}
    elif p.is_dir():
        repo_map = analyzer.analyze_directory(path, max_files=500)
        analyses = repo_map.files
        console.print(f"\n[bold]Repository:[/bold] {path} — {repo_map.total_files} files, {repo_map.total_lines:,} lines")
        console.print(f"Languages: {', '.join(f'{k}:{v}' for k, v in sorted(repo_map.languages.items(), key=lambda x: -x[1])[:8])}\n")
    else:
        console.print(f"[red]Path not found: {path}[/red]")
        raise typer.Exit(1)

    for file_path, analysis in list(analyses.items())[:20]:
        if analysis.error:
            continue
        if not analysis.functions and not analysis.classes:
            continue

        table = Table(title=file_path, show_lines=False)
        table.add_column("Type", width=8)
        table.add_column("Name", style="bold cyan")
        table.add_column("Line", width=6)
        table.add_column("Details")

        for cls in analysis.classes[:10]:
            table.add_row("class", cls.name, str(cls.start_line), f"{len(cls.methods)} methods")
        for func in analysis.functions[:20]:
            prefix = "async " if func.is_async else ""
            params = f"({', '.join(func.parameters[:5])})"
            table.add_row("func", f"{prefix}{func.name}", str(func.start_line), params)

        console.print(table)


@ast_app.command("map")
def cmd_map(
    path: Annotated[str, typer.Argument(help="Repository root path")] = ".",
    max_tokens: Annotated[int, typer.Option("--max-tokens", "-t")] = 4000,
    output: Annotated[str, typer.Option("--output", "-o")] = "",
) -> None:
    """Generate repository map for AI context injection."""
    from owlmind.ast_parser.analyzer import CodeAnalyzer

    console.print(f"Generating repo map for [cyan]{path}[/cyan]...")
    analyzer = CodeAnalyzer()
    repo_map_text = analyzer.generate_repo_map(path, max_tokens=max_tokens)

    if output:
        Path(output).write_text(repo_map_text, encoding="utf-8")
        console.print(f"[green]Repo map saved to {output}[/green]")
    else:
        console.print(Panel(repo_map_text, title="Repository Map", border_style="cyan"))


@ast_app.command("chunks")
def cmd_chunks(
    path: Annotated[str, typer.Argument(help="File to chunk")],
    output: Annotated[str, typer.Option("--output", "-o")] = "",
) -> None:
    """Split code into RAG chunks and optionally save as JSON."""
    from owlmind.ast_parser.analyzer import CodeAnalyzer

    analyzer = CodeAnalyzer()
    analysis = analyzer.analyze_file(path)

    if analysis.error:
        console.print(f"[red]Error: {analysis.error}[/red]")
        raise typer.Exit(1)

    console.print(f"[bold]{path}[/bold] — {len(analysis.chunks)} chunks")

    if output:
        data = [c.model_dump() for c in analysis.chunks]
        Path(output).write_text(json.dumps(data, indent=2), encoding="utf-8")
        console.print(f"[green]Saved to {output}[/green]")
    else:
        for chunk in analysis.chunks[:10]:
            console.print(Panel(
                chunk.content[:300],
                title=f"[{chunk.chunk_type}] {chunk.name} (lines {chunk.start_line}-{chunk.end_line})",
                border_style="dim",
            ))
        if len(analysis.chunks) > 10:
            console.print(f"[dim]... and {len(analysis.chunks) - 10} more chunks[/dim]")
