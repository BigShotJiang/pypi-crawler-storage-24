from __future__ import annotations

import uuid

from pydantic import BaseModel, Field


class FunctionInfo(BaseModel):
    name: str
    start_line: int
    end_line: int
    docstring: str = ""
    parameters: list[str] = Field(default_factory=list)
    return_type: str = ""
    is_async: bool = False
    decorators: list[str] = Field(default_factory=list)
    body_preview: str = ""


class ClassInfo(BaseModel):
    name: str
    start_line: int
    end_line: int
    docstring: str = ""
    base_classes: list[str] = Field(default_factory=list)
    methods: list[FunctionInfo] = Field(default_factory=list)
    decorators: list[str] = Field(default_factory=list)


class ImportInfo(BaseModel):
    module: str
    names: list[str] = Field(default_factory=list)
    alias: str = ""
    line: int = 0
    is_from_import: bool = False


class CodeChunk(BaseModel):
    chunk_id: str = Field(default_factory=lambda: str(uuid.uuid4())[:8])
    file_path: str
    language: str
    content: str
    start_line: int
    end_line: int
    chunk_type: str  # function, class, module_level, import_block
    name: str = ""
    embedding: list[float] = Field(default_factory=list)


class FileAnalysis(BaseModel):
    file_path: str
    language: str = ""
    total_lines: int = 0
    functions: list[FunctionInfo] = Field(default_factory=list)
    classes: list[ClassInfo] = Field(default_factory=list)
    imports: list[ImportInfo] = Field(default_factory=list)
    chunks: list[CodeChunk] = Field(default_factory=list)
    error: str = ""


class RepositoryMap(BaseModel):
    root_path: str
    total_files: int = 0
    total_lines: int = 0
    languages: dict[str, int] = Field(default_factory=dict)
    files: dict[str, FileAnalysis] = Field(default_factory=dict)
    summary: str = ""
