from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

EXTENSION_TO_LANGUAGE: dict[str, str] = {
    ".py": "python",
    ".js": "javascript",
    ".ts": "typescript",
    ".tsx": "tsx",
    ".jsx": "javascript",
    ".go": "go",
    ".rs": "rust",
    ".java": "java",
    ".c": "c",
    ".cpp": "cpp",
    ".cc": "cpp",
    ".cxx": "cpp",
    ".h": "c",
    ".hpp": "cpp",
    ".cs": "c_sharp",
    ".rb": "ruby",
    ".php": "php",
    ".swift": "swift",
    ".kt": "kotlin",
    ".scala": "scala",
    ".r": "r",
    ".sh": "bash",
    ".bash": "bash",
    ".yaml": "yaml",
    ".yml": "yaml",
    ".json": "json",
    ".toml": "toml",
    ".md": "markdown",
    ".sql": "sql",
    ".html": "html",
    ".htm": "html",
    ".css": "css",
    ".lua": "lua",
    ".ex": "elixir",
    ".exs": "elixir",
    ".hs": "haskell",
    ".ml": "ocaml",
    ".mli": "ocaml",
    ".vim": "vim",
    ".tf": "hcl",
    ".hcl": "hcl",
    ".proto": "proto",
    ".dockerfile": "dockerfile",
}

SKIP_DIRS = frozenset({
    ".git", "__pycache__", "node_modules", ".venv", "venv",
    "env", ".env", "dist", "build", ".mypy_cache", ".pytest_cache",
    ".ruff_cache", ".tox", ".eggs", "*.egg-info", ".idea", ".vscode",
    "coverage", ".coverage", "htmlcov",
})

_TREESITTER_LANGUAGES_AVAILABLE = False
try:
    import tree_sitter_languages  # noqa: F401
    _TREESITTER_LANGUAGES_AVAILABLE = True
except ImportError:
    pass

_TREESITTER_AVAILABLE = False
try:
    import tree_sitter  # noqa: F401
    _TREESITTER_AVAILABLE = True
except ImportError:
    pass


def detect_language(file_path: str) -> str:
    """Detect programming language from file extension."""
    from pathlib import Path
    suffix = Path(file_path).suffix.lower()
    name = Path(file_path).name.lower()

    # Special cases by filename
    if name == "dockerfile":
        return "dockerfile"
    if name == "makefile":
        return "make"
    if name == "jenkinsfile":
        return "groovy"

    return EXTENSION_TO_LANGUAGE.get(suffix, "")


def get_treesitter_parser(language: str):
    """Get Tree-sitter parser for a language. Returns None if unavailable."""
    if not _TREESITTER_AVAILABLE:
        return None

    # Try tree_sitter_languages (pre-compiled wheels for 100+ languages)
    if _TREESITTER_LANGUAGES_AVAILABLE:
        try:
            from tree_sitter_languages import get_parser
            return get_parser(language)
        except Exception as e:
            logger.debug("tree_sitter_languages failed for %s: %s", language, e)

    # Try individual tree-sitter-X packages
    try:
        import importlib
        lang_module = importlib.import_module(f"tree_sitter_{language}")
        if hasattr(lang_module, "language"):
            from tree_sitter import Language, Parser
            lang = Language(lang_module.language())
            parser = Parser()
            parser.set_language(lang)
            return parser
    except Exception as e:
        logger.debug("Individual tree-sitter package failed for %s: %s", language, e)

    return None
