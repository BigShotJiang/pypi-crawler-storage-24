"""GitHub PR integration — create PRs from OWLMIND run/session results.

Uses the ``gh`` CLI (subprocess) to create pull requests and attach
evidence comments.  All error messages are redacted via
:func:`owlmind.utils.redact_secrets`.
"""

from __future__ import annotations

import contextlib
import json
import logging
import shutil
import subprocess
from pathlib import Path
from typing import Any

from owlmind.utils import redact_secrets

logger = logging.getLogger(__name__)

_GH = "gh"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def is_gh_available() -> bool:
    """Check if ``gh`` CLI is installed and authenticated."""
    if not shutil.which(_GH):
        return False
    try:
        result = subprocess.run(
            [_GH, "auth", "status"],
            capture_output=True,
            text=True,
            check=False,
            timeout=10,
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, OSError):
        return False


# ---------------------------------------------------------------------------
# Core: create PR
# ---------------------------------------------------------------------------


def create_pr(
    branch: str,
    title: str,
    body: str,
    *,
    base: str = "main",
    draft: bool = False,
) -> dict[str, Any]:
    """Create a GitHub PR via ``gh pr create``.

    Returns ``{"url": "...", "number": N, "created": True}`` on success,
    or ``{"created": False, "error": "..."}`` on failure.
    """
    cmd: list[str] = [
        _GH,
        "pr",
        "create",
        "--head",
        branch,
        "--base",
        base,
        "--title",
        title,
        "--body",
        body,
    ]
    if draft:
        cmd.append("--draft")

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            check=False,
            timeout=60,
        )
    except (subprocess.TimeoutExpired, OSError) as exc:
        return {"created": False, "error": redact_secrets(str(exc))}

    if result.returncode != 0:
        return {"created": False, "error": redact_secrets(result.stderr.strip())}

    url = result.stdout.strip()
    pr_number = 0
    if "/" in url:
        with contextlib.suppress(ValueError):
            pr_number = int(url.rstrip("/").split("/")[-1])

    return {"url": url, "number": pr_number, "created": True}


# ---------------------------------------------------------------------------
# create_pr_from_run
# ---------------------------------------------------------------------------


def create_pr_from_run(
    run_id: str,
    *,
    runs_dir: Path = Path("runs"),
    base: str = "main",
    draft: bool = False,
) -> dict[str, Any]:
    """Create a PR from a OWLMIND run (reads meta.json + summary.json).

    Builds PR title from the run goal and body from the summary report.
    """
    run_path = runs_dir / run_id

    # --- read meta.json ---
    meta_path = run_path / "meta.json"
    if not meta_path.exists():
        return {"created": False, "error": f"meta.json not found for run {run_id}"}

    try:
        meta: dict[str, Any] = json.loads(meta_path.read_text())
    except (json.JSONDecodeError, OSError) as exc:
        return {"created": False, "error": redact_secrets(str(exc))}

    goal = meta.get("goal", run_id)
    branch = meta.get("branch", run_id)

    # --- read summary.json (optional) ---
    summary_path = run_path / "summary.json"
    body_parts: list[str] = [f"## OWLMIND run `{run_id}`\n"]
    body_parts.append(f"**Goal:** {goal}\n")

    if summary_path.exists():
        try:
            summary: dict[str, Any] = json.loads(summary_path.read_text())
            report = summary.get("report", {})
            state = report.get("status", summary.get("summary", {}).get("state", "?"))
            body_parts.append(f"**Status:** {state}\n")

            steps_done = report.get("steps_completed", [])
            steps_fail = report.get("steps_failed", [])
            if steps_done:
                body_parts.append(f"**Steps completed:** {len(steps_done)}\n")
            if steps_fail:
                body_parts.append(f"**Steps failed:** {len(steps_fail)}\n")

            diff_summary = report.get("diff_summary", {})
            if diff_summary:
                body_parts.append(
                    f"**Diff:** +{diff_summary.get('insertions', 0)} "
                    f"-{diff_summary.get('deletions', 0)} "
                    f"({diff_summary.get('files_changed', 0)} files)\n"
                )
        except (json.JSONDecodeError, OSError):
            logger.warning("Could not read summary.json for run %s", run_id)

    title = f"[OWLMIND] {goal}"
    if len(title) > 120:
        title = title[:117] + "..."

    body = "\n".join(body_parts)
    return create_pr(branch, title, body, base=base, draft=draft)


# ---------------------------------------------------------------------------
# create_pr_from_session
# ---------------------------------------------------------------------------


def create_pr_from_session(
    session_id: str,
    *,
    sessions_dir: Path = Path("sessions"),
    base: str = "main",
    draft: bool = False,
) -> dict[str, Any]:
    """Create a PR from a OWLMIND session (reads session_meta.json).

    Builds PR body with a list of completed goals.
    """
    sess_path = sessions_dir / session_id
    meta_path = sess_path / "session_meta.json"

    if not meta_path.exists():
        return {"created": False, "error": f"session_meta.json not found for session {session_id}"}

    try:
        data: dict[str, Any] = json.loads(meta_path.read_text())
    except (json.JSONDecodeError, OSError) as exc:
        return {"created": False, "error": redact_secrets(str(exc))}

    status = data.get("status", "?")
    goals: list[dict[str, Any]] = data.get("goals", [])
    runs: list[dict[str, Any]] = data.get("runs", [])

    # Build title from first goal or session_id
    first_goal = goals[0].get("goal", session_id) if goals else session_id
    title = f"[OWLMIND session] {first_goal}"
    if len(title) > 120:
        title = title[:117] + "..."

    # Build body
    body_parts: list[str] = [f"## OWLMIND session `{session_id}`\n"]
    body_parts.append(f"**Status:** {status}\n")
    body_parts.append(f"**Goals:** {len(goals)}\n")

    # List completed goals
    done_runs = [r for r in runs if r.get("status") == "done"]
    if done_runs:
        body_parts.append("### Completed goals\n")
        for r in done_runs:
            goal_id = r.get("goal_id", "?")
            # Find goal text
            goal_text = goal_id
            for g in goals:
                if g.get("id") == goal_id:
                    goal_text = g.get("goal", goal_id)
                    break
            body_parts.append(f"- **{goal_id}**: {goal_text}")

    failed_runs = [r for r in runs if r.get("status") == "failed"]
    if failed_runs:
        body_parts.append("\n### Failed goals\n")
        for r in failed_runs:
            body_parts.append(f"- **{r.get('goal_id', '?')}**: {r.get('status', '?')}")

    branch = session_id
    body = "\n".join(body_parts)
    return create_pr(branch, title, body, base=base, draft=draft)


# ---------------------------------------------------------------------------
# attach_evidence
# ---------------------------------------------------------------------------


def attach_evidence(pr_number: int, comment: str) -> dict[str, Any]:
    """Add a comment to an existing PR via ``gh pr comment``.

    Returns ``{"commented": True}`` or ``{"commented": False, "error": "..."}``.
    """
    cmd = [_GH, "pr", "comment", str(pr_number), "--body", comment]

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            check=False,
            timeout=30,
        )
    except (subprocess.TimeoutExpired, OSError) as exc:
        return {"commented": False, "error": redact_secrets(str(exc))}

    if result.returncode != 0:
        return {"commented": False, "error": redact_secrets(result.stderr.strip())}

    return {"commented": True}
