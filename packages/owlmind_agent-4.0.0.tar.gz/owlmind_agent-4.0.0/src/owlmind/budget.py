"""Budget Governor — enforces token/cost limits before LLM calls."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

from owlmind.config import BudgetConfig, PricingConfig
from owlmind.ledger import UsageLedger

logger = logging.getLogger(__name__)


@dataclass
class BudgetDecision:
    """Result of a budget check."""

    allowed: bool
    reason: str
    remaining_tokens_today: int
    remaining_usd_today: float
    remaining_tokens_run: int

    def to_dict(self) -> dict[str, Any]:
        return {
            "allowed": self.allowed,
            "reason": self.reason,
            "remaining_tokens_today": self.remaining_tokens_today,
            "remaining_usd_today": round(self.remaining_usd_today, 4),
            "remaining_tokens_run": self.remaining_tokens_run,
        }


class BudgetGovernor:
    """Checks budget limits before LLM calls using ledger data."""

    def __init__(
        self,
        budget: BudgetConfig,
        pricing: PricingConfig,
        ledger: UsageLedger,
    ) -> None:
        self.budget = budget
        self.pricing = pricing
        self.ledger = ledger

    def check(self, run_id: str) -> BudgetDecision:
        """Check all budget limits. Returns a BudgetDecision."""
        logger.debug("Budget check for run=%s", run_id)
        day_totals = self.ledger.totals_for_day()
        run_totals = self.ledger.totals_for_run(run_id)
        calls_hour = self.ledger.calls_in_last_hour()

        remaining_day = self.budget.max_tokens_per_day - day_totals.total_tokens
        remaining_usd = self.budget.max_usd_per_day - day_totals.estimated_usd
        remaining_run = self.budget.max_tokens_per_run - run_totals.total_tokens

        # Check per-run token limit
        if run_totals.total_tokens >= self.budget.max_tokens_per_run:
            logger.warning(
                "Run token limit exceeded: %d >= %d",
                run_totals.total_tokens,
                self.budget.max_tokens_per_run,
            )
            return BudgetDecision(
                allowed=False,
                reason=(
                    f"Run token limit exceeded: {run_totals.total_tokens}"
                    f" >= {self.budget.max_tokens_per_run}"
                ),
                remaining_tokens_today=max(0, remaining_day),
                remaining_usd_today=max(0.0, remaining_usd),
                remaining_tokens_run=0,
            )

        # Check daily token limit
        if day_totals.total_tokens >= self.budget.max_tokens_per_day:
            logger.warning(
                "Daily token limit exceeded: %d >= %d",
                day_totals.total_tokens,
                self.budget.max_tokens_per_day,
            )
            return BudgetDecision(
                allowed=False,
                reason=(
                    f"Daily token limit exceeded: {day_totals.total_tokens}"
                    f" >= {self.budget.max_tokens_per_day}"
                ),
                remaining_tokens_today=0,
                remaining_usd_today=max(0.0, remaining_usd),
                remaining_tokens_run=max(0, remaining_run),
            )

        # Check daily USD limit
        if day_totals.estimated_usd >= self.budget.max_usd_per_day:
            logger.warning(
                "Daily USD limit exceeded: $%.4f >= $%.2f",
                day_totals.estimated_usd,
                self.budget.max_usd_per_day,
            )
            return BudgetDecision(
                allowed=False,
                reason=(
                    f"Daily USD limit exceeded: ${day_totals.estimated_usd:.4f}"
                    f" >= ${self.budget.max_usd_per_day:.2f}"
                ),
                remaining_tokens_today=max(0, remaining_day),
                remaining_usd_today=0.0,
                remaining_tokens_run=max(0, remaining_run),
            )

        # Check calls per hour
        if calls_hour >= self.budget.max_llm_calls_per_hour:
            logger.warning(
                "Hourly call limit exceeded: %d >= %d",
                calls_hour,
                self.budget.max_llm_calls_per_hour,
            )
            return BudgetDecision(
                allowed=False,
                reason=(
                    f"Hourly call limit exceeded: {calls_hour}"
                    f" >= {self.budget.max_llm_calls_per_hour}"
                ),
                remaining_tokens_today=max(0, remaining_day),
                remaining_usd_today=max(0.0, remaining_usd),
                remaining_tokens_run=max(0, remaining_run),
            )

        return BudgetDecision(
            allowed=True,
            reason="Budget OK",
            remaining_tokens_today=max(0, remaining_day),
            remaining_usd_today=max(0.0, remaining_usd),
            remaining_tokens_run=max(0, remaining_run),
        )

    def estimate_cost(
        self,
        input_tokens: int,
        output_tokens: int,
    ) -> float:
        """Estimate USD cost for given token counts."""
        return (input_tokens / 1000) * self.pricing.openai_price_per_1k_input + (
            output_tokens / 1000
        ) * self.pricing.openai_price_per_1k_output
