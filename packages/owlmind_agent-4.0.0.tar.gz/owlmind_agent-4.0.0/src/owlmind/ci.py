"""CI operations via ``gh`` CLI — workflow status, logs, and fix-session.

Provides read-only CI inspection plus a fix-session helper that
creates a goals.yaml from failed CI checks for automated fixing.
"""

from __future__ import annotations

import contextlib
import json
import logging
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

import owlmind.github as _gh_mod

logger = logging.getLogger(__name__)

_last_ci_gh_call: float = 0.0


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------


@dataclass
class WorkflowRun:
    """A single CI workflow run."""

    id: int = 0
    name: str = ""
    status: str = ""
    conclusion: str = ""
    head_branch: str = ""
    url: str = ""
    event: str = ""
    created_at: str = ""


@dataclass
class WorkflowJob:
    """A single job in a workflow run."""

    id: int = 0
    name: str = ""
    status: str = ""
    conclusion: str = ""
    steps: list[dict[str, str]] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _run_gh(
    args: list[str],
    *,
    cwd: str | Path | None = None,
    timeout: int = 30,
) -> subprocess.CompletedProcess[str]:
    """Run gh command with dry-run and rate-limit from shared config."""
    global _last_ci_gh_call
    cmd = ["gh", *args]

    if _gh_mod._config.dry_run:
        logger.info("[DRY-RUN] %s", " ".join(cmd))
        return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")

    now = time.monotonic()
    wait = _gh_mod._config.cooldown - (now - _last_ci_gh_call)
    if _last_ci_gh_call and wait > 0:
        time.sleep(wait)

    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        cwd=cwd,
        timeout=timeout,
    )
    _last_ci_gh_call = time.monotonic()
    return result


# ---------------------------------------------------------------------------
# CI inspection
# ---------------------------------------------------------------------------


def list_runs(
    workspace: str,
    *,
    limit: int = 10,
    branch: str = "",
) -> list[WorkflowRun]:
    """List recent workflow runs."""
    args = [
        "run",
        "list",
        "--limit",
        str(limit),
        "--json",
        "databaseId,name,status,conclusion,headBranch,url,event,createdAt",
    ]
    if branch:
        args.extend(["--branch", branch])

    result = _run_gh(args, cwd=workspace)
    if result.returncode != 0:
        logger.warning("gh run list failed: %s", result.stderr)
        return []

    runs: list[WorkflowRun] = []
    with contextlib.suppress(json.JSONDecodeError):
        for item in json.loads(result.stdout):
            runs.append(
                WorkflowRun(
                    id=item.get("databaseId", 0),
                    name=item.get("name", ""),
                    status=item.get("status", ""),
                    conclusion=item.get("conclusion", ""),
                    head_branch=item.get("headBranch", ""),
                    url=item.get("url", ""),
                    event=item.get("event", ""),
                    created_at=item.get("createdAt", ""),
                )
            )
    return runs


def run_status(workspace: str, run_id: int) -> dict[str, Any]:
    """Get status of a specific workflow run."""
    result = _run_gh(
        [
            "run",
            "view",
            str(run_id),
            "--json",
            "databaseId,name,status,conclusion,headBranch,url,jobs",
        ],
        cwd=workspace,
    )
    if result.returncode != 0:
        msg = f"gh run view failed: {result.stderr}"
        raise RuntimeError(msg)

    data: dict[str, Any] = json.loads(result.stdout)
    return data


def run_logs(workspace: str, run_id: int) -> str:
    """Get logs for a workflow run (text output)."""
    result = _run_gh(
        ["run", "view", str(run_id), "--log"],
        cwd=workspace,
        timeout=60,
    )
    if result.returncode != 0:
        msg = f"gh run view --log failed: {result.stderr}"
        raise RuntimeError(msg)
    return result.stdout


def failed_jobs(workspace: str, run_id: int) -> list[WorkflowJob]:
    """Get failed jobs from a workflow run."""
    try:
        data = run_status(workspace, run_id)
    except RuntimeError:
        return []

    jobs: list[WorkflowJob] = []
    for job in data.get("jobs", []):
        if job.get("conclusion") == "failure":
            steps = []
            for step in job.get("steps", []):
                steps.append(
                    {
                        "name": step.get("name", ""),
                        "conclusion": step.get("conclusion", ""),
                    }
                )
            jobs.append(
                WorkflowJob(
                    id=job.get("databaseId", 0),
                    name=job.get("name", ""),
                    status=job.get("status", ""),
                    conclusion=job.get("conclusion", ""),
                    steps=steps,
                )
            )
    return jobs


# ---------------------------------------------------------------------------
# Fix-session: generate goals.yaml from failed CI
# ---------------------------------------------------------------------------


def generate_fix_goals(
    workspace: str,
    run_id: int,
    *,
    out_path: Path | None = None,
) -> Path:
    """Generate a goals.yaml to fix failed CI checks.

    Creates one goal per failed job, with the goal text describing
    what failed so the autopilot can attempt a fix.
    """
    jobs = failed_jobs(workspace, run_id)
    if not jobs:
        msg = f"No failed jobs found for run {run_id}"
        raise ValueError(msg)

    if out_path is None:
        out_path = Path(workspace) / f"fix_ci_{run_id}.yaml"

    goals = []
    for i, job in enumerate(jobs, 1):
        failed_steps = [s["name"] for s in job.steps if s.get("conclusion") == "failure"]
        step_text = ", ".join(failed_steps) if failed_steps else "unknown steps"

        goals.append(
            {
                "id": f"FIX-{i}",
                "goal": (
                    f"Fix CI failure in job '{job.name}': "
                    f"failed steps: {step_text}. "
                    f"Run tests locally and ensure they pass."
                ),
                "depends_on": [f"FIX-{i - 1}"] if i > 1 else [],
            }
        )

    data = {
        "version": 2,
        "metadata": {
            "source": "ci-fix",
            "ci_run_id": run_id,
        },
        "goals": goals,
    }

    out_path.write_text(yaml.dump(data, default_flow_style=False, sort_keys=False))
    return out_path
