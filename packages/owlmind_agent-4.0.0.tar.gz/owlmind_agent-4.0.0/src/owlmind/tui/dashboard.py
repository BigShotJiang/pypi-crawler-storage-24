"""LiveDashboard — interactive TUI dashboard using Rich Live."""

from __future__ import annotations

import contextlib
import json
import logging
import time
from pathlib import Path
from typing import Any

from rich.layout import Layout
from rich.live import Live

from owlmind.tui.widgets import budget_panel, event_log, queue_panel, runs_table

logger = logging.getLogger(__name__)


class LiveDashboard:
    """Interactive terminal dashboard powered by Rich Live.

    Reads run metadata, budget info, event logs, and queue state from
    the filesystem and renders them as a live-updating terminal UI.

    Parameters
    ----------
    runs_dir:
        Directory containing run subdirectories with ``cycle_meta.json``.
    ledger_dir:
        Directory containing ``usage.jsonl`` for budget tracking.
    queue_dir:
        Directory containing ``queue.jsonl`` for task queue.
    refresh_interval:
        Seconds between data refreshes (default 2).
    max_ticks:
        Maximum number of refresh cycles.  ``0`` means infinite.
    max_tokens:
        Token budget cap shown in the budget panel.
    max_usd:
        USD budget cap shown in the budget panel.
    """

    def __init__(
        self,
        *,
        runs_dir: Path = Path("runs"),
        ledger_dir: Path | None = None,
        queue_dir: Path | None = None,
        refresh_interval: int = 2,
        max_ticks: int = 0,
        max_tokens: int = 500_000,
        max_usd: float = 10.0,
    ) -> None:
        self.runs_dir = Path(runs_dir)
        self.ledger_dir = Path(ledger_dir) if ledger_dir else self.runs_dir.parent / "ledger"
        self.queue_dir = Path(queue_dir) if queue_dir else self.runs_dir.parent / "queue"
        self.refresh_interval = refresh_interval
        self.max_ticks = max_ticks
        self.max_tokens = max_tokens
        self.max_usd = max_usd
        self._events: list[dict[str, Any]] = []
        self._running = False

    # -- data readers ---------------------------------------------------------

    def _read_runs(self) -> list[dict[str, Any]]:
        """Read run metadata from cycle_meta.json files."""
        runs: list[dict[str, Any]] = []
        if not self.runs_dir.exists():
            return runs
        for meta_path in sorted(self.runs_dir.glob("*/cycle_meta.json"), reverse=True):
            with contextlib.suppress(json.JSONDecodeError, OSError):
                data = json.loads(meta_path.read_text())
                runs.append(data)
        return runs[:20]

    def _read_budget(self) -> dict[str, Any]:
        """Read aggregated budget totals from the usage ledger."""
        totals: dict[str, Any] = {
            "total_tokens": 0,
            "estimated_usd": 0.0,
            "max_tokens": self.max_tokens,
            "max_usd": self.max_usd,
        }
        ledger_path = self.ledger_dir / "usage.jsonl"
        if not ledger_path.exists():
            return totals
        with contextlib.suppress(OSError):
            for line in ledger_path.read_text().splitlines():
                line = line.strip()
                if not line:
                    continue
                with contextlib.suppress(json.JSONDecodeError):
                    entry = json.loads(line)
                    totals["total_tokens"] += int(entry.get("total_tokens", 0))
                    totals["estimated_usd"] += float(entry.get("estimated_usd", 0.0))
        return totals

    def _read_queue(self) -> list[dict[str, Any]]:
        """Read queue items from queue.jsonl."""
        items: list[dict[str, Any]] = []
        queue_path = self.queue_dir / "queue.jsonl"
        if not queue_path.exists():
            return items
        with contextlib.suppress(OSError):
            for line in queue_path.read_text().splitlines():
                line = line.strip()
                if not line:
                    continue
                with contextlib.suppress(json.JSONDecodeError):
                    items.append(json.loads(line))
        return items

    # -- event bus integration ------------------------------------------------

    def on_event(self, event_name: str, data: dict[str, Any]) -> None:
        """EventBus callback — stores events for display."""
        from datetime import UTC, datetime

        self._events.append(
            {
                "event": event_name,
                "timestamp": datetime.now(tz=UTC).strftime("%H:%M:%S"),
                "run_id": data.get("run_id", ""),
            }
        )
        # Keep only last 50 events in memory
        if len(self._events) > 50:
            self._events = self._events[-50:]

    # -- layout ---------------------------------------------------------------

    def _build_layout(self) -> Layout:
        """Build the Rich Layout structure."""
        layout = Layout()
        layout.split_column(
            Layout(name="top", ratio=3),
            Layout(name="bottom", ratio=2),
        )
        layout["top"].split_row(
            Layout(name="runs", ratio=3),
            Layout(name="budget", ratio=1),
        )
        layout["bottom"].split_row(
            Layout(name="events", ratio=1),
            Layout(name="queue", ratio=1),
        )
        return layout

    def _update_layout(self, layout: Layout) -> None:
        """Refresh all layout panels with current data."""
        runs = self._read_runs()
        budget = self._read_budget()
        queue_items = self._read_queue()

        layout["runs"].update(runs_table(runs))
        layout["budget"].update(budget_panel(budget))
        layout["events"].update(event_log(self._events))
        layout["queue"].update(queue_panel(queue_items))

    # -- lifecycle ------------------------------------------------------------

    def start(self) -> None:
        """Run the live dashboard loop.

        Blocks until ``max_ticks`` is reached (if > 0) or KeyboardInterrupt.
        """
        self._running = True
        layout = self._build_layout()
        self._update_layout(layout)

        tick = 0
        logger.info(
            "LiveDashboard started (runs_dir=%s, interval=%ds, max_ticks=%d)",
            self.runs_dir,
            self.refresh_interval,
            self.max_ticks,
        )

        try:
            with Live(layout, refresh_per_second=1, screen=False) as live:
                while self._running:
                    self._update_layout(layout)
                    live.update(layout)
                    tick += 1
                    if self.max_ticks and tick >= self.max_ticks:
                        break
                    time.sleep(self.refresh_interval)
        except KeyboardInterrupt:
            logger.info("LiveDashboard stopped by user")
        finally:
            self._running = False

    def stop(self) -> None:
        """Signal the live loop to stop."""
        self._running = False
