"""Interactive TUI dashboard for OWLMIND — Rich Live-based terminal UI."""

from __future__ import annotations

from owlmind.tui.dashboard import LiveDashboard

__all__ = ["LiveDashboard"]
