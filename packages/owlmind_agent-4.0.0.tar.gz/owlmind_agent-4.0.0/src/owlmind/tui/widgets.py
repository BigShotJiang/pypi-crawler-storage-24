"""Rich-based widgets for the OWLMIND TUI dashboard."""

from __future__ import annotations

from typing import Any

from rich.panel import Panel
from rich.table import Table
from rich.text import Text


def runs_table(runs: list[dict[str, Any]]) -> Table:
    """Create a table showing active/recent runs."""
    table = Table(title="Runs", expand=True)
    table.add_column("Run ID", style="cyan", no_wrap=True)
    table.add_column("State", style="bold")
    table.add_column("Goal", max_width=40)
    table.add_column("Iteration")
    table.add_column("Updated")
    for run in runs:
        state = run.get("state", "?")
        style = {"DONE": "green", "FAILED": "red", "PLANNING": "yellow"}.get(state, "")
        table.add_row(
            run.get("run_id", "?"),
            Text(state, style=style),
            run.get("goal", "?")[:40],
            str(run.get("iteration", "?")),
            run.get("updated_at", "?")[:19] if run.get("updated_at") else "?",
        )
    return table


def budget_panel(totals: dict[str, Any]) -> Panel:
    """Create a panel showing budget usage."""
    tokens = totals.get("total_tokens", 0)
    usd = totals.get("estimated_usd", 0.0)
    max_tokens = totals.get("max_tokens", 0)
    max_usd = totals.get("max_usd", 0.0)

    token_pct = (tokens / max_tokens * 100) if max_tokens else 0
    usd_pct = (usd / max_usd * 100) if max_usd else 0

    bar_len = 20
    token_fill = int(token_pct / 100 * bar_len)
    usd_fill = int(usd_pct / 100 * bar_len)

    token_bar = "\u2588" * token_fill + "\u2591" * (bar_len - token_fill)
    usd_bar = "\u2588" * usd_fill + "\u2591" * (bar_len - usd_fill)

    text = Text()
    text.append(f"Tokens: [{token_bar}] ")
    text.append(f"{tokens:,}/{max_tokens:,} ({token_pct:.0f}%)\n")
    text.append(f"   USD: [{usd_bar}] ")
    text.append(f"${usd:.4f}/${max_usd:.2f} ({usd_pct:.0f}%)")

    return Panel(text, title="Budget", border_style="blue")


def event_log(events: list[dict[str, Any]], max_items: int = 10) -> Panel:
    """Create a panel showing recent events."""
    text = Text()
    for evt in events[-max_items:]:
        name = evt.get("event", "?")
        ts = evt.get("timestamp", "?")
        run_id = evt.get("run_id", "")
        color = {
            "run_started": "green",
            "run_done": "green",
            "run_failed": "red",
            "budget_exceeded": "red",
            "budget_warning": "yellow",
        }.get(name, "white")
        text.append(f"[{ts}] ", style="dim")
        text.append(name, style=color)
        if run_id:
            text.append(f" ({run_id})")
        text.append("\n")
    if not events:
        text.append("No events yet.", style="dim")
    return Panel(text, title="Events", border_style="green")


def queue_panel(items: list[dict[str, Any]]) -> Panel:
    """Create a panel showing queue status."""
    text = Text()
    for item in items[:5]:
        status = item.get("status", "?")
        goal = item.get("goal", "?")[:50]
        style = {
            "PENDING": "yellow",
            "RUNNING": "cyan",
            "DONE": "green",
            "FAILED": "red",
        }.get(status, "")
        text.append(f"  [{status}] ", style=style)
        text.append(f"{goal}\n")
    if not items:
        text.append("Queue empty.", style="dim")
    return Panel(text, title=f"Queue ({len(items)})", border_style="yellow")
