"""AutonomousScheduler — runs GraphRunner on triggers: cron, GitHub, file watch.

Usage::

    sched = AutonomousScheduler(workspace=".")
    sched.add_goal("Add tests for all new files")
    sched.start(interval=300)            # every 5 minutes

    # or react to GitHub issues
    sched.watch_github(repo="owner/repo", event="issues")
    sched.start()

    # or one-shot from CLI:
    owlmind graph watch --goal "fix lint" --interval 60 --workspace .
"""

from __future__ import annotations

import contextlib
import logging
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# Optional imports — available when installed
try:
    import httpx
except ImportError:
    httpx = None  # type: ignore[assignment]

try:
    from owlmind.graph.runner import GraphRunner
except Exception:
    GraphRunner = None  # type: ignore[assignment,misc]


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------


@dataclass
class ScheduledGoal:
    """A goal queued for autonomous execution."""

    goal: str
    workspace: str = "."
    priority: int = 0
    created_at: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    source: str = "manual"  # manual | github | file | telegram


@dataclass
class RunRecord:
    """Record of one autonomous run."""

    goal: str
    workspace: str
    started_at: str
    ended_at: str = ""
    verdict: str = ""
    source: str = "manual"
    error: str = ""

    @property
    def success(self) -> bool:
        return self.verdict == "APPROVED"


# ---------------------------------------------------------------------------
# AutonomousScheduler
# ---------------------------------------------------------------------------


class AutonomousScheduler:
    """Periodically runs the GraphRunner pipeline on queued goals.

    Supports multiple trigger sources:
    - Manual: add_goal(...)
    - Interval: start(interval=N)  — repeats every N seconds
    - GitHub: watch_github(repo, event)  — polls GitHub REST API
    - File: watch_file(path)  — triggers when file changes
    """

    def __init__(
        self,
        workspace: str = ".",
        max_iterations: int = 3,
        *,
        on_run_complete: Callable[[RunRecord], None] | None = None,
    ) -> None:
        self._workspace = workspace
        self._max_iterations = max_iterations
        self._on_run_complete = on_run_complete
        self._queue: list[ScheduledGoal] = []
        self._history: list[RunRecord] = []
        self._lock = threading.Lock()
        self._stop_event = threading.Event()
        self._github_watchers: list[dict[str, Any]] = []
        self._file_watchers: list[dict[str, Any]] = []
        self._thread: threading.Thread | None = None

    # ------------------------------------------------------------------
    # Queue management
    # ------------------------------------------------------------------

    def add_goal(
        self,
        goal: str,
        workspace: str | None = None,
        *,
        source: str = "manual",
        priority: int = 0,
    ) -> ScheduledGoal:
        """Enqueue a goal for the next run cycle."""
        sg = ScheduledGoal(
            goal=goal,
            workspace=workspace or self._workspace,
            priority=priority,
            source=source,
        )
        with self._lock:
            self._queue.append(sg)
            self._queue.sort(key=lambda g: -g.priority)
        logger.info("Goal queued [%s]: %s", source, goal[:80])
        return sg

    def _pop_goal(self) -> ScheduledGoal | None:
        with self._lock:
            if self._queue:
                return self._queue.pop(0)
        return None

    # ------------------------------------------------------------------
    # GitHub watcher
    # ------------------------------------------------------------------

    def watch_github(
        self,
        repo: str,
        event: str = "issues",
        *,
        token: str = "",
        label: str = "",
        goal_template: str = "Fix GitHub issue #{number}: {title}",
    ) -> None:
        """Poll GitHub for new issues/PRs and enqueue goals.

        Args:
            repo: GitHub repo in "owner/name" format.
            event: "issues" or "pull_request".
            token: GitHub personal access token (or set GITHUB_TOKEN env).
            label: Only react to issues with this label.
            goal_template: Goal text template; supports {number}, {title}, {body}.
        """
        import os
        self._github_watchers.append({
            "repo": repo,
            "event": event,
            "token": token or os.environ.get("GITHUB_TOKEN", ""),
            "label": label,
            "goal_template": goal_template,
            "seen_ids": set(),
        })
        logger.info("GitHub watcher registered: %s [%s]", repo, event)

    def _poll_github(self, watcher: dict[str, Any]) -> None:
        """Check GitHub for new events and enqueue goals."""
        if httpx is None:
            logger.debug("httpx not installed — GitHub polling unavailable")
            return

        repo = watcher["repo"]
        event = watcher["event"]
        token = watcher["token"]
        label = watcher["label"]

        headers: dict[str, str] = {"Accept": "application/vnd.github+json"}
        if token:
            headers["Authorization"] = f"Bearer {token}"

        params: dict[str, str] = {"state": "open", "per_page": "20", "sort": "created"}
        if label:
            params["labels"] = label

        endpoint = "pulls" if event == "pull_request" else "issues"
        url = f"https://api.github.com/repos/{repo}/{endpoint}"

        try:
            resp = httpx.get(url, headers=headers, params=params, timeout=10)
            if resp.status_code != 200:
                logger.warning("GitHub API %d for %s", resp.status_code, url)
                return

            items = resp.json()
            seen = watcher["seen_ids"]

            for item in items:
                item_id = item.get("id", 0)
                if item_id in seen:
                    continue
                seen.add(item_id)

                # Skip if label required but missing
                if label:
                    labels = [lbl["name"] for lbl in item.get("labels", [])]
                    if label not in labels:
                        continue

                goal = watcher["goal_template"].format(
                    number=item.get("number", "?"),
                    title=item.get("title", ""),
                    body=(item.get("body") or "")[:300],
                )
                self.add_goal(goal, source=f"github:{repo}")

        except Exception as e:
            logger.warning("GitHub poll error for %s: %s", repo, e)

    # ------------------------------------------------------------------
    # File watcher
    # ------------------------------------------------------------------

    def watch_file(
        self,
        path: str,
        goal_template: str = "Process changes in {file}",
    ) -> None:
        """Enqueue a goal whenever *path* is modified."""
        p = Path(path)
        mtime = p.stat().st_mtime if p.exists() else 0
        self._file_watchers.append({
            "path": path,
            "goal_template": goal_template,
            "last_mtime": mtime,
        })
        logger.info("File watcher registered: %s", path)

    def _poll_files(self) -> None:
        for watcher in self._file_watchers:
            p = Path(watcher["path"])
            if not p.exists():
                continue
            mtime = p.stat().st_mtime
            if mtime > watcher["last_mtime"]:
                watcher["last_mtime"] = mtime
                goal = watcher["goal_template"].format(file=watcher["path"])
                self.add_goal(goal, source=f"file:{watcher['path']}")

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------

    def run_once(self) -> list[RunRecord]:
        """Process all currently queued goals. Returns list of RunRecords."""
        records: list[RunRecord] = []
        while True:
            sg = self._pop_goal()
            if sg is None:
                break
            record = self._execute(sg)
            records.append(record)
            with self._lock:
                self._history.append(record)
            if self._on_run_complete:
                with contextlib.suppress(Exception):
                    self._on_run_complete(record)
        return records

    def _execute(self, sg: ScheduledGoal) -> RunRecord:
        """Run GraphRunner for one goal."""
        started = datetime.now(UTC).isoformat()
        logger.info("AutonomousScheduler executing [%s]: %s", sg.source, sg.goal[:80])

        record = RunRecord(
            goal=sg.goal,
            workspace=sg.workspace,
            started_at=started,
            source=sg.source,
        )

        try:
            if GraphRunner is None:
                raise RuntimeError("owlmind.graph.runner not available")
            runner = GraphRunner()
            state = runner.run(
                sg.goal,
                workspace=sg.workspace,
                max_iterations=self._max_iterations,
            )
            record.verdict = state.final_verdict
            record.ended_at = datetime.now(UTC).isoformat()
            logger.info(
                "AutonomousScheduler done [%s]: verdict=%s",
                sg.source, record.verdict,
            )
        except Exception as e:
            record.error = str(e)
            record.ended_at = datetime.now(UTC).isoformat()
            logger.error("AutonomousScheduler error for goal %r: %s", sg.goal[:60], e)

        return record

    # ------------------------------------------------------------------
    # Background loop
    # ------------------------------------------------------------------

    def start(self, interval: float = 300.0, *, daemon: bool = True) -> None:
        """Start the scheduler loop in a background thread.

        Args:
            interval: Seconds between polling cycles.
            daemon: If True (default), thread exits when main program exits.
        """
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._loop,
            args=(interval,),
            daemon=daemon,
            name="AutonomousScheduler",
        )
        self._thread.start()
        logger.info("AutonomousScheduler started (interval=%.0fs)", interval)

    def stop(self) -> None:
        """Signal the background loop to stop and wait for it."""
        self._stop_event.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=10)
        logger.info("AutonomousScheduler stopped")

    def _loop(self, interval: float) -> None:
        """Main background loop."""
        while not self._stop_event.is_set():
            # Poll external sources
            for watcher in self._github_watchers:
                self._poll_github(watcher)
            self._poll_files()

            # Execute queued goals
            self.run_once()

            # Sleep in small increments so stop() is responsive
            deadline = time.monotonic() + interval
            while not self._stop_event.is_set() and time.monotonic() < deadline:
                time.sleep(min(1.0, deadline - time.monotonic()))

    def run_blocking(self, interval: float = 300.0) -> None:
        """Run the scheduler loop in the current thread (blocking).

        Handles KeyboardInterrupt gracefully.
        """
        logger.info("AutonomousScheduler running (interval=%.0fs, Ctrl+C to stop)", interval)
        try:
            while True:
                for watcher in self._github_watchers:
                    self._poll_github(watcher)
                self._poll_files()
                self.run_once()

                deadline = time.monotonic() + interval
                while time.monotonic() < deadline:
                    time.sleep(min(1.0, deadline - time.monotonic()))
        except KeyboardInterrupt:
            logger.info("AutonomousScheduler interrupted")

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------

    def status(self) -> dict[str, Any]:
        """Return current scheduler status."""
        with self._lock:
            queue_snapshot = list(self._queue)
            history_snapshot = list(self._history)

        return {
            "running": self._thread is not None and self._thread.is_alive(),
            "queue_size": len(queue_snapshot),
            "history_count": len(history_snapshot),
            "github_watchers": len(self._github_watchers),
            "file_watchers": len(self._file_watchers),
            "recent": [
                {
                    "goal": r.goal[:60],
                    "verdict": r.verdict,
                    "source": r.source,
                    "error": r.error[:100] if r.error else "",
                }
                for r in history_snapshot[-5:]
            ],
        }
