"""ParallelGraphRunner — run multiple graph pipeline subtasks concurrently.

Usage (legacy API)::

    runner = ParallelGraphRunner(workers=3)
    results = runner.run_parallel(
        subtasks=["fix type errors", "add docstrings", "update tests"],
        workspace=".",
    )
    for r in results:
        print(r.goal, r.verdict)

Usage (task-based API)::

    from owlmind.graph.parallel_runner import ParallelGraphRunner, ParallelTask

    runner = ParallelGraphRunner(max_workers=3)
    results = asyncio.run(runner.run_all([
        ParallelTask(goal="fix type errors", workspace="."),
        ParallelTask(goal="add docstrings", workspace="."),
    ]))
    for r in results:
        print(r.task.goal, r.verdict)
"""
from __future__ import annotations

import asyncio
import logging
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from datetime import UTC, datetime

# Module-level imports for testability (patchable via patch("owlmind.graph.parallel_runner.GraphRunner"))
try:
    from owlmind.graph.runner import GraphRunner, _build_llm_client
except Exception:
    GraphRunner = None  # type: ignore[assignment,misc]
    _build_llm_client = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Task-based API — ParallelTask / ParallelResult / ParallelGraphRunner.run_all
# ---------------------------------------------------------------------------


@dataclass
class ParallelTask:
    """Input descriptor for one parallel graph run."""

    goal: str
    workspace: str
    run_id: str | None = None


@dataclass
class ParallelResult:
    """Result of one parallel graph run (task-based API)."""

    task: ParallelTask
    verdict: str  # APPROVED / REJECTED / ERROR
    summary: str
    error: str | None = None


@dataclass
class SubtaskResult:
    """Result of one parallel subtask run."""
    goal: str
    workspace: str
    verdict: str = ""
    error: str = ""
    duration_ms: int = 0
    started_at: str = ""
    ended_at: str = ""

    @property
    def success(self) -> bool:
        return self.verdict == "APPROVED"


@dataclass
class ParallelRunResult:
    """Combined result of all parallel subtasks."""
    subtasks: list[SubtaskResult] = field(default_factory=list)
    total_ms: int = 0

    @property
    def approved_count(self) -> int:
        return sum(1 for s in self.subtasks if s.success)

    @property
    def failed_count(self) -> int:
        return sum(1 for s in self.subtasks if not s.success)

    @property
    def all_approved(self) -> bool:
        return bool(self.subtasks) and all(s.success for s in self.subtasks)

    def summary(self) -> str:
        lines = [f"Parallel run: {len(self.subtasks)} subtasks, {self.total_ms}ms"]
        for s in self.subtasks:
            icon = "✓" if s.success else "✗"
            lines.append(f"  {icon} [{s.verdict or 'error'}] {s.goal[:60]}")
        return "\n".join(lines)


class ParallelGraphRunner:
    """Run multiple GraphRunner instances concurrently using asyncio + ThreadPoolExecutor."""

    def __init__(
        self,
        workers: int = 3,
        max_iterations: int = 3,
        *,
        max_workers: int | None = None,
    ) -> None:
        # Accept max_workers as an alias for workers (task-based API)
        self._workers = max_workers if max_workers is not None else workers
        self._max_iterations = max_iterations

    # ------------------------------------------------------------------
    # Task-based API (ParallelTask / ParallelResult)
    # ------------------------------------------------------------------

    async def run_all(
        self,
        tasks: list[ParallelTask],
        task_timeout: float = 300.0,
    ) -> list[ParallelResult]:
        """Run all tasks concurrently, return results in same order.

        Args:
            tasks: List of tasks to run.
            task_timeout: Max seconds per task before cancellation (default 5 min).
        """
        if not tasks:
            return []

        semaphore = asyncio.Semaphore(self._workers)
        loop = asyncio.get_event_loop()

        async def run_one(task: ParallelTask) -> ParallelResult:
            async with semaphore:
                try:
                    if GraphRunner is None or _build_llm_client is None:
                        raise RuntimeError("owlmind.graph.runner could not be imported")
                    runner = GraphRunner()
                    import functools

                    state = await asyncio.wait_for(
                        loop.run_in_executor(
                            None,
                            functools.partial(
                                runner.run,
                                goal=task.goal,
                                workspace=task.workspace,
                            ),
                        ),
                        timeout=task_timeout,
                    )
                    return ParallelResult(
                        task=task,
                        verdict=state.final_verdict or "UNKNOWN",
                        summary=state.review or state.plan or "",
                    )
                except TimeoutError:
                    logger.warning(
                        "ParallelGraphRunner: task timed out after %.0fs [%s]",
                        task_timeout,
                        task.goal[:40],
                    )
                    return ParallelResult(
                        task=task,
                        verdict="ERROR",
                        summary="",
                        error=f"Timed out after {task_timeout:.0f}s",
                    )
                except Exception as e:
                    logger.error(
                        "ParallelGraphRunner.run_all task error [%s]: %s",
                        task.goal[:40],
                        e,
                    )
                    return ParallelResult(
                        task=task,
                        verdict="ERROR",
                        summary="",
                        error=str(e),
                    )

        return list(await asyncio.gather(*[run_one(t) for t in tasks]))

    def run_parallel(
        self,
        subtasks: list[str],
        workspace: str = ".",
        *,
        skip_tester: bool = False,
    ) -> ParallelRunResult:
        """Run all subtasks concurrently. Returns combined result."""
        return asyncio.run(
            self._run_async(subtasks, workspace, skip_tester=skip_tester)
        )

    async def _run_async(
        self,
        subtasks: list[str],
        workspace: str,
        *,
        skip_tester: bool = False,
    ) -> ParallelRunResult:
        import time
        start = time.monotonic()

        loop = asyncio.get_event_loop()
        with ThreadPoolExecutor(max_workers=self._workers) as pool:
            futures = [
                loop.run_in_executor(
                    pool,
                    self._run_one,
                    goal,
                    workspace,
                    skip_tester,
                )
                for goal in subtasks
            ]
            results = await asyncio.gather(*futures)

        total_ms = int((time.monotonic() - start) * 1000)
        return ParallelRunResult(subtasks=list(results), total_ms=total_ms)

    def _run_one(
        self,
        goal: str,
        workspace: str,
        skip_tester: bool,
    ) -> SubtaskResult:
        """Run one subtask synchronously (called in thread pool)."""
        import time

        started = datetime.now(UTC).isoformat()
        t0 = time.monotonic()

        result = SubtaskResult(goal=goal, workspace=workspace, started_at=started)

        try:
            if _build_llm_client() is None:
                result.error = "No LLM configured"
                return result

            runner = GraphRunner()
            state = runner.run(
                goal,
                workspace=workspace,
                max_iterations=self._max_iterations,
                skip_tester=skip_tester,
            )
            result.verdict = state.final_verdict or ""
        except Exception as e:
            result.error = str(e)
            logger.error("Parallel subtask error [%s]: %s", goal[:40], e)
        finally:
            result.duration_ms = int((time.monotonic() - t0) * 1000)
            result.ended_at = datetime.now(UTC).isoformat()

        return result
