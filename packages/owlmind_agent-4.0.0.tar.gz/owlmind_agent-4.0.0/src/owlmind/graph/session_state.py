"""Persist and resume GraphRunner state between interruptions."""
from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path


@dataclass
class PersistedState:
    run_id: str
    goal: str
    workspace: str
    iteration: int
    plan: str
    code_changes: str
    status: str  # 'running' | 'paused' | 'done'
    created_at: float
    updated_at: float


class SessionStateStore:
    """Store GraphRunner state in ~/.owlmind/sessions/{run_id}.json"""

    def __init__(self, base_dir: Path | None = None):
        self._dir = base_dir or Path.home() / ".owlmind" / "sessions"
        self._dir.mkdir(parents=True, exist_ok=True)

    def save(self, state: PersistedState) -> None:
        path = self._dir / f"{state.run_id}.json"
        state.updated_at = time.time()
        path.write_text(json.dumps(asdict(state), indent=2))

    def load(self, run_id: str) -> PersistedState | None:
        path = self._dir / f"{run_id}.json"
        if not path.exists():
            return None
        data = json.loads(path.read_text())
        return PersistedState(**data)

    def list_sessions(self, status: str | None = None) -> list[PersistedState]:
        sessions = []
        for f in sorted(self._dir.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
            try:
                data = json.loads(f.read_text())
                s = PersistedState(**data)
                if status is None or s.status == status:
                    sessions.append(s)
            except Exception:
                continue
        return sessions

    def delete(self, run_id: str) -> bool:
        path = self._dir / f"{run_id}.json"
        if path.exists():
            path.unlink()
            return True
        return False
