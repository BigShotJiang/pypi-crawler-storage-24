"""GraphRunner — orchestrates the Architect → Coder → Tester → Reviewer pipeline."""
from __future__ import annotations

import logging
import os
import time as _time
from collections.abc import Callable
from typing import Any

from owlmind.agent.self_improver import load_prompt_overrides
from owlmind.graph.nodes import ArchitectNode, CoderNode, ReviewerNode, TesterNode
from owlmind.graph.run_memory import RunMemory, RunRecord
from owlmind.graph.session_state import PersistedState, SessionStateStore
from owlmind.graph.state import GraphState, NodeResult, NodeStatus

logger = logging.getLogger(__name__)


def _build_llm_client() -> Any:
    """Build LLM client from environment — prefers OpenAI-compatible (DeepSeek), falls back to Anthropic."""
    # Load .env from owlmind project root if present
    try:
        from pathlib import Path

        from dotenv import load_dotenv
        env_file = Path(__file__).parent.parent.parent.parent / ".env"
        if env_file.exists():
            load_dotenv(env_file, override=False)
    except ImportError:
        pass

    # Allow forcing a specific provider via env var
    force_provider = os.environ.get("OWLMIND_LLM_PROVIDER", "").lower()

    anthropic_key = os.environ.get("ANTHROPIC_API_KEY", "")
    if force_provider == "anthropic" and anthropic_key:
        try:
            import anthropic
            model = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-4-6")
            client = anthropic.Anthropic(api_key=anthropic_key)
            client._owlmind_model = model  # type: ignore[attr-defined]
            logger.info("Graph using Anthropic (forced): %s", model)
            return client
        except ImportError:
            logger.warning("anthropic SDK not installed")

    openai_key = os.environ.get("OPENAI_API_KEY", "")
    openai_base = os.environ.get("OPENAI_BASE_URL", "")
    openai_model = os.environ.get("OPENAI_MODEL", "deepseek-reasoner")

    if openai_key and force_provider != "anthropic":
        try:
            import openai
            kwargs: dict[str, Any] = {"api_key": openai_key}
            if openai_base:
                kwargs["base_url"] = openai_base
            client = openai.OpenAI(**kwargs)
            client._owlmind_model = openai_model  # type: ignore[attr-defined]
            logger.info("Graph using OpenAI-compatible LLM: %s @ %s", openai_model, openai_base or "api.openai.com")
            return client
        except ImportError:
            logger.warning("openai SDK not installed, falling back to Anthropic")

    if anthropic_key:
        try:
            import anthropic
            model = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-4-6")
            client = anthropic.Anthropic(api_key=anthropic_key)
            client._owlmind_model = model  # type: ignore[attr-defined]
            logger.info("Graph using Anthropic: %s", model)
            return client
        except ImportError:
            logger.warning("anthropic SDK not installed")

    return None


class GraphRunner:
    """Runs the multi-agent graph: Architect → Coder → Tester → Reviewer."""

    def __init__(
        self,
        api_key: str = "",
        model: str = "",
        on_node_complete: Callable[[NodeResult], None] | None = None,
    ) -> None:
        self._on_node_complete = on_node_complete
        self._llm = _build_llm_client()
        self._session_store = SessionStateStore()

    def run(
        self,
        goal: str,
        workspace: str = ".",
        max_iterations: int = 3,
        context: dict[str, Any] | None = None,
        skip_tester: bool = False,
        progress_callback: Callable[[str, str, str], None] | None = None,
    ) -> GraphState:
        """Run the full agent pipeline and return final state."""
        # Load run memory context for the Architect
        memory = RunMemory()
        memory_context = memory.context_for(goal)

        state = GraphState(
            goal=goal,
            workspace=workspace,
            max_iterations=max_iterations,
            context=context or {},
        )
        if memory_context:
            state.memory_context = memory_context  # type: ignore[attr-defined]

        # Create initial persisted session
        now = _time.time()
        persisted = PersistedState(
            run_id=state.run_id,
            goal=goal,
            workspace=workspace,
            iteration=0,
            plan="",
            code_changes="",
            status="running",
            created_at=now,
            updated_at=now,
        )
        try:
            self._session_store.save(persisted)
        except Exception as e:
            logger.warning("Could not save initial session state: %s", e)

        # Load any accumulated prompt overrides from SelfImprover
        _overrides = load_prompt_overrides()
        _OVERRIDE_SEP = "\n\n# Learned improvements:\n"

        architect_node = ArchitectNode("architect", self._llm)
        coder_node = CoderNode("coder", self._llm)
        tester_node = TesterNode("tester", self._llm)
        reviewer_node = ReviewerNode("reviewer", self._llm)

        if _overrides.get("planner"):
            architect_node.SYSTEM = architect_node.SYSTEM + _OVERRIDE_SEP + _overrides["planner"]
        if _overrides.get("worker"):
            coder_node.SYSTEM = coder_node.SYSTEM + _OVERRIDE_SEP + _overrides["worker"]
        if _overrides.get("judge"):
            reviewer_node.SYSTEM = reviewer_node.SYSTEM + _OVERRIDE_SEP + _overrides["judge"]

        nodes = [
            architect_node,
            coder_node,
            *([] if skip_tester else [tester_node]),
            reviewer_node,
        ]

        for iteration in range(max_iterations):
            state.iteration = iteration
            logger.info("Graph iteration %d/%d", iteration + 1, max_iterations)

            for node in nodes:
                logger.debug("Running node: %s", node.name)
                result = node.run(state)
                state.add_result(result)

                if self._on_node_complete:
                    self._on_node_complete(result)

                if progress_callback:
                    status = result.status.value
                    output_snippet = (result.output or result.error or "")[:120]
                    progress_callback(result.node_name, status, output_snippet)

                if result.status == NodeStatus.FAILED:
                    logger.warning("Node %s failed: %s", node.name, result.error)

                # Persist checkpoint after each node
                try:
                    persisted.iteration = iteration
                    persisted.plan = state.plan
                    persisted.code_changes = state.code_changes
                    persisted.status = "running"
                    self._session_store.save(persisted)
                except Exception as e:
                    logger.warning("Could not checkpoint session state: %s", e)

            if state.is_approved():
                logger.info("Goal approved after %d iterations", iteration + 1)
                break
            elif state.final_verdict == "REJECTED":
                logger.warning("Goal rejected by reviewer")
                break
            elif iteration < max_iterations - 1 and state.needs_fix():
                logger.info("NEEDS_FIX — iterating again with reviewer feedback")
                state.context["previous_review"] = state.review
                state.context["previous_code"] = state.code_changes
                state.plan = ""
                state.code_changes = ""
                state.test_results = ""
                state.final_verdict = ""

        # Mark session as done
        try:
            persisted.status = "done"
            persisted.plan = state.plan
            persisted.code_changes = state.code_changes
            self._session_store.save(persisted)
        except Exception as e:
            logger.warning("Could not finalize session state: %s", e)

        # Save this run to memory
        summary = (state.review or state.test_results or state.plan or "")[:200]
        record = RunRecord(
            run_id=state.run_id,
            goal=goal,
            verdict=state.final_verdict or "UNKNOWN",
            workspace=workspace,
            summary=summary,
            timestamp=str(_time.time()),
            total_tokens=state.cost.total_tokens,
            total_usd=state.cost.total_usd,
        )
        try:
            memory.save(record)
        except Exception as e:
            logger.warning("Could not save run memory: %s", e)

        logger.info(state.cost.summary())
        return state

    def resume(
        self,
        run_id: str,
        max_iterations: int = 3,
        skip_tester: bool = False,
        progress_callback: Callable[[str, str, str], None] | None = None,
    ) -> GraphState:
        """Resume a previously persisted run from its last checkpoint."""
        persisted = self._session_store.load(run_id)
        if persisted is None:
            msg = f"No session found for run_id={run_id!r}"
            raise ValueError(msg)

        logger.info("Resuming run %s from iteration %d", run_id, persisted.iteration)
        return self.run(
            goal=persisted.goal,
            workspace=persisted.workspace,
            max_iterations=max_iterations,
            skip_tester=skip_tester,
            progress_callback=progress_callback,
        )

    def run_quick(self, goal: str, workspace: str = ".") -> str:
        """Quick run with just Architect + Coder (no testing/review)."""
        state = GraphState(goal=goal, workspace=workspace, max_iterations=1)
        architect = ArchitectNode("architect", self._llm)
        coder = CoderNode("coder", self._llm)
        ar = architect.run(state)
        state.add_result(ar)
        cr = coder.run(state)
        state.add_result(cr)
        return state.code_changes or state.plan
