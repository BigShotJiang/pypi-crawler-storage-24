"""Shared state for the agent graph — passed between all nodes."""
from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

from owlmind.graph.cost_tracker import RunCost


class NodeStatus(StrEnum):
    PENDING = "pending"
    RUNNING = "running"
    DONE = "done"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class NodeResult:
    node_name: str
    status: NodeStatus
    output: str = ""
    artifacts: dict[str, Any] = field(default_factory=dict)
    error: str = ""
    duration_ms: int = 0
    timestamp: str = field(default_factory=lambda: str(time.time()))


@dataclass
class GraphState:
    """Mutable shared state passed through all nodes."""

    # Input
    goal: str
    workspace: str = "."
    context: dict[str, Any] = field(default_factory=dict)

    # Execution tracking
    run_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    iteration: int = 0
    max_iterations: int = 3

    # Node results
    results: list[NodeResult] = field(default_factory=list)

    # Shared artifacts between nodes
    plan: str = ""           # Architect output
    code_changes: str = ""   # Coder output (diff/summary)
    test_results: str = ""   # Tester output
    review: str = ""         # Reviewer output
    final_verdict: str = ""  # APPROVED / NEEDS_FIX / REJECTED

    # Messages log
    messages: list[dict[str, str]] = field(default_factory=list)

    # Cost tracking
    cost: RunCost = field(default_factory=RunCost)

    def add_result(self, result: NodeResult) -> None:
        self.results.append(result)
        self.messages.append({
            "node": result.node_name,
            "status": result.status.value,
            "output": result.output[:500],
        })

    def get_last_result(self, node_name: str) -> NodeResult | None:
        for r in reversed(self.results):
            if r.node_name == node_name:
                return r
        return None

    def is_approved(self) -> bool:
        return self.final_verdict == "APPROVED"

    def needs_fix(self) -> bool:
        return self.final_verdict == "NEEDS_FIX"

    def to_context_summary(self) -> str:
        """Build a text summary of current state for LLM prompts."""
        parts = [f"Goal: {self.goal}", f"Iteration: {self.iteration}/{self.max_iterations}"]
        if self.plan:
            parts.append(f"\nPlan:\n{self.plan[:1000]}")
        if self.code_changes:
            parts.append(f"\nCode Changes:\n{self.code_changes[:800]}")
        if self.test_results:
            parts.append(f"\nTest Results:\n{self.test_results[:500]}")
        if self.review:
            parts.append(f"\nReview:\n{self.review[:500]}")
        return "\n".join(parts)
