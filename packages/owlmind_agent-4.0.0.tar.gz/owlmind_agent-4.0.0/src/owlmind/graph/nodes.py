"""Agent nodes — each node is a specialized AI agent with a specific role."""
from __future__ import annotations

import logging
import os
import re
import subprocess
import sys
import time
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

from owlmind.graph.cost_tracker import NodeCost
from owlmind.graph.state import GraphState, NodeResult, NodeStatus
from owlmind.graph.test_runner import run_tests
from owlmind.tools.shell import ShellTool

# ---------------------------------------------------------------------------
# Code-block parser — extracts files from LLM output
# ---------------------------------------------------------------------------

_FILE_HEADER_RE = re.compile(
    r"(?:^|\n)##\s+File:\s+([^\n]+)\n"   # ## File: path/to/file.py
    r"```[a-zA-Z0-9_-]*\n"               # ```python  (language tag optional)
    r"(.*?)"                              # file content
    r"```",                               # closing fence
    re.DOTALL,
)

_FENCED_BLOCK_RE = re.compile(
    r"```(?:[a-zA-Z0-9_-]+)?\n(.*?)```",
    re.DOTALL,
)


def _parse_file_blocks(text: str) -> dict[str, str]:
    """Extract ``## File: path`` + fenced code blocks from *text*.

    Returns a dict of {relative_path: file_content}.
    """
    files: dict[str, str] = {}
    for m in _FILE_HEADER_RE.finditer(text):
        path = m.group(1).strip()
        content = m.group(2)
        if path and content:
            files[path] = content
    return files


def _write_files_to_workspace(
    files: dict[str, str], workspace: str
) -> list[str]:
    """Write *files* dict to *workspace*. Returns list of written paths."""
    root = Path(workspace).resolve()
    written: list[str] = []
    for rel_path, content in files.items():
        # Safety: discard any paths trying to escape workspace
        target = (root / rel_path).resolve()
        try:
            target.relative_to(root)
        except ValueError:
            logger.warning("Skipping path outside workspace: %s", rel_path)
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        written.append(rel_path)
        logger.info("CoderNode wrote: %s (%d bytes)", rel_path, len(content))
    return written

logger = logging.getLogger(__name__)


class BaseNode(ABC):
    """Base class for all agent nodes in the graph."""

    def __init__(self, name: str, llm_client: Any = None) -> None:
        self.name = name
        self._llm = llm_client

    @abstractmethod
    def run(self, state: GraphState) -> NodeResult:
        """Execute this node and return a result."""

    def _call_llm(self, system: str, user: str, max_tokens: int = 2000) -> str:
        """Call the LLM and return text response (supports Anthropic and OpenAI-compatible)."""
        text, _cost = self._call_llm_with_cost(system, user, max_tokens)
        return text

    def _call_llm_with_cost(
        self, system: str, user: str, max_tokens: int = 2000
    ) -> tuple[str, NodeCost]:
        """Call the LLM and return (text, NodeCost) with token usage."""
        if self._llm is None:
            msg = f"Node {self.name}: LLM client not configured"
            raise RuntimeError(msg)
        try:
            client_type = type(self._llm).__module__.split(".")[0]
            if client_type == "openai":
                # OpenAI-compatible (DeepSeek, GPT, etc.)
                model = getattr(self._llm, "_owlmind_model", "deepseek-reasoner")
                response = self._llm.chat.completions.create(
                    model=model,
                    max_tokens=max_tokens,
                    messages=[
                        {"role": "system", "content": system},
                        {"role": "user", "content": user},
                    ],
                )
                text = response.choices[0].message.content or ""
                usage = getattr(response, "usage", None)
                if usage is not None:
                    _in = getattr(usage, "prompt_tokens", 0)
                    _out = getattr(usage, "completion_tokens", 0)
                    input_tokens = _in if isinstance(_in, int) else (len(system) + len(user)) // 4
                    output_tokens = _out if isinstance(_out, int) else len(text) // 4
                else:
                    # Best-effort estimate: ~4 chars per token
                    input_tokens = (len(system) + len(user)) // 4
                    output_tokens = len(text) // 4
                cost = NodeCost(
                    node=self.name,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    model=model,
                    provider="openai",
                )
                return text, cost
            else:
                # Anthropic
                model = getattr(self._llm, "_owlmind_model", "claude-sonnet-4-6")
                response = self._llm.messages.create(
                    model=model,
                    max_tokens=max_tokens,
                    system=system,
                    messages=[{"role": "user", "content": user}],
                )
                text = ""
                for block in response.content:
                    if getattr(block, "type", "") == "text":
                        text = block.text
                        break
                usage = getattr(response, "usage", None)
                if usage is not None:
                    input_tokens = getattr(usage, "input_tokens", 0) or 0
                    output_tokens = getattr(usage, "output_tokens", 0) or 0
                else:
                    input_tokens = (len(system) + len(user)) // 4
                    output_tokens = len(text) // 4
                cost = NodeCost(
                    node=self.name,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    model=model,
                    provider="anthropic",
                )
                return text, cost
        except Exception:
            logger.exception("LLM call failed in node %s", self.name)
            raise
        return "", NodeCost(node=self.name)


class ArchitectNode(BaseNode):
    """Architect agent — analyzes the goal and creates a detailed implementation plan."""

    SYSTEM = """You are a senior software architect. Your job is to:
1. Analyze the given goal carefully
2. Break it down into specific, actionable implementation steps
3. Identify which files need to be created or modified
4. Specify exact code changes needed
5. Consider edge cases and potential issues

Output a structured plan with:
- Summary (1-2 sentences)
- Steps (numbered list of specific actions)
- Files to modify (list with reasons)
- Risks (if any)

Be concise but precise."""

    def run(self, state: GraphState) -> NodeResult:
        t0 = time.monotonic()
        try:
            context = state.to_context_summary()

            # Include repo map if ast_parser available
            repo_context = ""
            try:
                from owlmind.ast_parser.analyzer import CodeAnalyzer
                if state.workspace and state.workspace != ".":
                    analyzer = CodeAnalyzer()
                    repo_context = analyzer.generate_repo_map(state.workspace, max_tokens=2000)
            except Exception:
                pass

            # CodeRAG: find relevant existing code
            rag_context = ""
            try:
                from owlmind.tools.code_rag import CodeRAG
                rag = CodeRAG(workspace=state.workspace or ".")
                rag_context = rag.search_and_format(state.goal, top_k=5, max_chars=2000)
            except Exception as e:
                logger.debug("CodeRAG unavailable: %s", e)

            # WebSearch: enrich context for unknown technologies
            web_context = ""
            try:
                from owlmind.tools.web_search_tool import WebSearchTool
                ws_tool = WebSearchTool()
                if not os.environ.get("OWLMIND_NO_WEB_SEARCH") and ws_tool.is_available():
                    web_result = ws_tool.search(state.goal, num_results=3)
                    if web_result.results:
                        snippets = "\n".join(
                            f"- {r.title}: {r.snippet}" for r in web_result.results[:3]
                        )
                        web_context = f"Web search results for context:\n{snippets}"
            except Exception as e:
                logger.debug("WebSearchTool unavailable: %s", e)

            mem_ctx = getattr(state, "memory_context", "")
            repo_section = ("Repository structure:\n" + repo_context) if repo_context else ""
            rag_section = ("Relevant existing code:\n" + rag_context) if rag_context else ""
            ctx_section = ("Previous context:\n" + context) if state.iteration > 0 else ""
            user_prompt = f"""Goal: {state.goal}

Workspace: {state.workspace}

{mem_ctx}
{repo_section}
{rag_section}
{web_context}
{ctx_section}

Create a detailed implementation plan."""

            plan, node_cost = self._call_llm_with_cost(self.SYSTEM, user_prompt, max_tokens=2000)
            state.plan = plan
            state.cost.add(node_cost)

            return NodeResult(
                node_name=self.name,
                status=NodeStatus.DONE,
                output=plan,
                duration_ms=int((time.monotonic() - t0) * 1000),
            )
        except Exception as e:
            return NodeResult(
                node_name=self.name,
                status=NodeStatus.FAILED,
                error=str(e),
                duration_ms=int((time.monotonic() - t0) * 1000),
            )


class CoderNode(BaseNode):
    """Coder agent — implements the plan by writing/modifying code."""

    SYSTEM = """You are an expert software engineer implementing a plan.

Your job is to write the actual, complete code for each file.

IMPORTANT — use this EXACT format for every file you create or modify:

## File: path/to/file.py
```python
# full file content here
```

## File: tests/test_something.py
```python
# full test content here
```

Rules:
1. Follow the architect's plan precisely
2. Write complete, production-quality code — no pseudocode, no placeholders
3. Include every file that needs to be created or changed
4. Each file block must have the ## File: header and a fenced code block
5. After the file blocks, add a brief ## Summary section

Be specific and complete."""

    def run(self, state: GraphState) -> NodeResult:
        t0 = time.monotonic()
        try:
            # Use Claude CLI worker if available
            try:
                from owlmind.policy import PolicyEngine
                from owlmind.worker.claude_cli_driver import ClaudeCLIDriver
                policies_dir = Path(state.workspace) / "policies"
                if policies_dir.exists():
                    policy = PolicyEngine.from_directory(policies_dir)
                else:
                    import re as _re
                    policy = PolicyEngine(
                        allowed_patterns=[_re.compile(r".*")],
                        forbidden_patterns=[],
                    )

                sandbox = os.environ.get("OWLMIND_SANDBOX", "0") == "1"
                ShellTool(cwd=state.workspace, sandbox=sandbox, policy=policy)

                driver = ClaudeCLIDriver(policy=policy)

                worker_prompt = f"""# Goal
{state.goal}

# Architect Plan
{state.plan}

# Instructions
Implement the plan above. Make the actual code changes using your file tools.
Report all changes made."""

                worker_request = {
                    "run_id": state.run_id,
                    "iteration": state.iteration,
                    "goal": state.goal,
                    "plan": state.plan,
                    "workspace": state.workspace,
                    "instructions": worker_prompt,
                }
                report, _meta = driver.run(
                    worker_request=worker_request,
                    schema={},
                    cwd=Path(state.workspace),
                )
                summary = "; ".join(report.get("done_summary", []))
                state.code_changes = summary

                return NodeResult(
                    node_name=self.name,
                    status=NodeStatus.DONE,
                    output=summary,
                    artifacts={"report": report},
                    duration_ms=int((time.monotonic() - t0) * 1000),
                )
            except Exception as e:
                logger.warning("Claude CLI driver failed, falling back to LLM-only: %s", e)

            # Fallback: LLM generates code → we parse and write the files
            user_prompt = f"""Plan to implement:
{state.plan}

Workspace: {state.workspace}
Goal: {state.goal}

Write complete code for all required files using the ## File: format.
Every file must have the ## File: header and a fenced code block with the full content."""

            response, node_cost = self._call_llm_with_cost(self.SYSTEM, user_prompt, max_tokens=4000)
            state.cost.add(node_cost)

            # Parse and write files to workspace
            file_blocks = _parse_file_blocks(response)
            written: list[str] = []
            if file_blocks and state.workspace:
                written = _write_files_to_workspace(file_blocks, state.workspace)

            summary = response
            if written:
                summary = f"Wrote {len(written)} file(s): {', '.join(written)}\n\n{response}"

            state.code_changes = summary
            state.context["files_written"] = written

            return NodeResult(
                node_name=self.name,
                status=NodeStatus.DONE,
                output=summary,
                artifacts={"files_written": written, "file_count": len(written)},
                duration_ms=int((time.monotonic() - t0) * 1000),
            )
        except Exception as e:
            return NodeResult(
                node_name=self.name,
                status=NodeStatus.FAILED,
                error=str(e),
                duration_ms=int((time.monotonic() - t0) * 1000),
            )


class TesterNode(BaseNode):
    """Tester agent — runs tests and verifies the implementation."""

    SYSTEM = """You are a QA engineer verifying an implementation.

Your job is to:
1. Review what was implemented
2. Check for correctness and completeness
3. Identify any issues, bugs, or missing pieces
4. Run verification commands if possible
5. Report test results

Output:
## Test Summary
PASS/FAIL/PARTIAL

## Issues Found
[list or "None"]

## Verification Commands Run
[commands and results]

Be honest about quality."""

    def run(self, state: GraphState) -> NodeResult:
        t0 = time.monotonic()
        try:
            test_output = ""
            test_exit_code = -1
            files_written: list[str] = state.context.get("files_written", [])

            # 1. Run the appropriate test suite for this workspace
            workspace = state.workspace or "."

            # Build a ShellTool respecting OWLMIND_SANDBOX env var
            import re as _re

            from owlmind.policy import PolicyEngine
            _policies_dir = Path(workspace) / "policies"
            if _policies_dir.exists():
                _policy = PolicyEngine.from_directory(_policies_dir)
            else:
                _policy = PolicyEngine(
                    allowed_patterns=[_re.compile(r".*")],
                    forbidden_patterns=[],
                )
            sandbox = os.environ.get("OWLMIND_SANDBOX", "0") == "1"
            ShellTool(cwd=workspace, sandbox=sandbox, policy=_policy)

            try:
                tr = run_tests(workspace)
                test_exit_code = tr.exit_code
                test_output = (tr.stdout + tr.stderr)[-3000:]
                logger.info(
                    "TesterNode: runner=%s exit_code=%d",
                    tr.runner, test_exit_code,
                )

                # 2. Also try importing any newly written Python files
                import_errors = []
                for rel_path in files_written:
                    if rel_path.endswith(".py") and not Path(rel_path).name.startswith("test_"):
                        syntax_cmd = "import ast; ast.parse(open(" + repr(rel_path) + ").read())"
                        check = subprocess.run(
                            [sys.executable, "-c", syntax_cmd],
                            cwd=workspace,
                            capture_output=True,
                            text=True,
                            timeout=10,
                        )
                        if check.returncode != 0:
                            import_errors.append(f"{rel_path}: {check.stderr.strip()[:200]}")
                if import_errors:
                    test_output += "\n\nSyntax errors:\n" + "\n".join(import_errors)

            except subprocess.TimeoutExpired:
                test_output = "Tests timed out after 120s"
            except Exception as e:
                test_output = f"Could not run tests: {e}"

            user_prompt = f"""Goal: {state.goal}

Files written: {', '.join(files_written) if files_written else 'unknown'}

Test execution output:
{test_output}

Implementation summary:
{state.code_changes[:1500]}

Evaluate correctness and completeness. Be precise about PASS/FAIL."""

            review, node_cost = self._call_llm_with_cost(self.SYSTEM, user_prompt, max_tokens=1500)
            state.test_results = review
            state.cost.add(node_cost)

            return NodeResult(
                node_name=self.name,
                status=NodeStatus.DONE,
                output=review,
                artifacts={
                    "test_output": test_output,
                    "test_exit_code": test_exit_code,
                    "files_tested": files_written,
                },
                duration_ms=int((time.monotonic() - t0) * 1000),
            )
        except Exception as e:
            return NodeResult(
                node_name=self.name,
                status=NodeStatus.FAILED,
                error=str(e),
                duration_ms=int((time.monotonic() - t0) * 1000),
            )


class ReviewerNode(BaseNode):
    """Reviewer agent — makes final approval decision."""

    SYSTEM = """You are a senior code reviewer making a final approval decision.

Based on the goal, implementation, and test results, decide:
- APPROVED: Implementation is complete and correct
- NEEDS_FIX: Good progress but specific issues need fixing (describe them)
- REJECTED: Fundamental problems, needs rethinking

Output exactly one of: APPROVED, NEEDS_FIX, REJECTED
Then explain your reasoning in 3-5 sentences.

Format:
VERDICT: [APPROVED/NEEDS_FIX/REJECTED]

REASON: [explanation]

FIXES_NEEDED: [if NEEDS_FIX, specific items to fix, else "N/A"]"""

    def run(self, state: GraphState) -> NodeResult:
        t0 = time.monotonic()
        try:
            user_prompt = f"""Goal: {state.goal}

Plan:
{state.plan[:800]}

Implementation:
{state.code_changes[:1000]}

Tests:
{state.test_results[:800]}

Make your final approval decision."""

            response, node_cost = self._call_llm_with_cost(self.SYSTEM, user_prompt, max_tokens=800)
            state.review = response
            state.cost.add(node_cost)

            # Parse verdict
            verdict = "NEEDS_FIX"
            for line in response.split("\n"):
                line = line.strip()
                if line.startswith("VERDICT:"):
                    v = line.split(":", 1)[1].strip().upper()
                    if v in ("APPROVED", "NEEDS_FIX", "REJECTED"):
                        verdict = v
                    break

            state.final_verdict = verdict

            return NodeResult(
                node_name=self.name,
                status=NodeStatus.DONE,
                output=response,
                artifacts={"verdict": verdict},
                duration_ms=int((time.monotonic() - t0) * 1000),
            )
        except Exception as e:
            return NodeResult(
                node_name=self.name,
                status=NodeStatus.FAILED,
                error=str(e),
                duration_ms=int((time.monotonic() - t0) * 1000),
            )
