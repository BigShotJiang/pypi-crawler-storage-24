"""Persist GraphRunner run history for context between runs."""
import json
from dataclasses import asdict, dataclass
from pathlib import Path


@dataclass
class RunRecord:
    run_id: str
    goal: str
    verdict: str
    workspace: str
    summary: str
    timestamp: str
    total_tokens: int = 0
    total_usd: float = 0.0


class RunMemory:
    """Stores recent run records in ~/.owlmind/run_memory.jsonl"""

    def __init__(self, path: Path | None = None):
        self._path = path or Path.home() / ".owlmind" / "run_memory.jsonl"
        self._path.parent.mkdir(parents=True, exist_ok=True)

    def save(self, record: RunRecord) -> None:
        with self._path.open("a") as f:
            f.write(json.dumps(asdict(record)) + "\n")

    def recent(self, n: int = 5) -> list[RunRecord]:
        if not self._path.exists():
            return []
        lines = self._path.read_text().strip().splitlines()
        return [RunRecord(**json.loads(line)) for line in lines[-n:]]

    def context_for(self, goal: str, n: int = 3) -> str:
        """Return recent runs as context string for ArchitectNode."""
        records = self.recent(n)
        if not records:
            return ""
        lines = ["Previous runs (most recent first):"]
        for r in reversed(records):
            lines.append(f"  [{r.verdict}] {r.goal[:80]} — {r.summary[:100]}")
        return "\n".join(lines)
