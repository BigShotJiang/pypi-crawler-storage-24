"""Token and cost tracking for GraphRunner runs."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

# Approximate cost per 1M tokens (input/output) by provider+model
_COST_TABLE: dict[str, dict[str, float]] = {
    "openai": {
        "gpt-4o": {"input": 2.50, "output": 10.00},
        "gpt-4o-mini": {"input": 0.15, "output": 0.60},
        "gpt-4-turbo": {"input": 10.00, "output": 30.00},
        "gpt-3.5-turbo": {"input": 0.50, "output": 1.50},
    },
    "anthropic": {
        "claude-opus-4": {"input": 15.00, "output": 75.00},
        "claude-sonnet-4": {"input": 3.00, "output": 15.00},
        "claude-haiku-4": {"input": 0.80, "output": 4.00},
        "claude-3-5-sonnet": {"input": 3.00, "output": 15.00},
        "claude-3-opus": {"input": 15.00, "output": 75.00},
        "claude-3-haiku": {"input": 0.25, "output": 1.25},
    },
    "gemini": {
        "gemini-1.5-pro": {"input": 1.25, "output": 5.00},
        "gemini-1.5-flash": {"input": 0.075, "output": 0.30},
    },
}


@dataclass
class NodeCost:
    node: str
    input_tokens: int = 0
    output_tokens: int = 0
    model: str = ""
    provider: str = ""

    @property
    def total_tokens(self) -> int:
        return self.input_tokens + self.output_tokens

    @property
    def estimated_usd(self) -> float:
        provider_table = _COST_TABLE.get(self.provider, {})
        # fuzzy match model name
        rates = None
        for key in sorted(provider_table, key=len, reverse=True):
            if key in self.model or self.model.startswith(key):
                rates = provider_table[key]
                break
        if rates is None:
            return 0.0
        return (
            self.input_tokens * rates["input"] / 1_000_000
            + self.output_tokens * rates["output"] / 1_000_000
        )


@dataclass
class RunCost:
    """Accumulated cost for a complete GraphRunner run."""
    nodes: list[NodeCost] = field(default_factory=list)

    def add(self, node: NodeCost) -> None:
        self.nodes.append(node)

    @property
    def total_input_tokens(self) -> int:
        return sum(n.input_tokens for n in self.nodes)

    @property
    def total_output_tokens(self) -> int:
        return sum(n.output_tokens for n in self.nodes)

    @property
    def total_tokens(self) -> int:
        return self.total_input_tokens + self.total_output_tokens

    @property
    def total_usd(self) -> float:
        return sum(n.estimated_usd for n in self.nodes)

    def summary(self) -> str:
        lines = [f"Cost summary: {self.total_tokens:,} tokens | ~${self.total_usd:.4f}"]
        for n in self.nodes:
            lines.append(
                f"  [{n.node}] in={n.input_tokens} out={n.output_tokens} ~${n.estimated_usd:.4f}"
            )
        return "\n".join(lines)

    def as_dict(self) -> dict[str, Any]:
        return {
            "total_tokens": self.total_tokens,
            "total_input_tokens": self.total_input_tokens,
            "total_output_tokens": self.total_output_tokens,
            "total_usd": self.total_usd,
            "nodes": [
                {
                    "node": n.node,
                    "input_tokens": n.input_tokens,
                    "output_tokens": n.output_tokens,
                    "model": n.model,
                    "provider": n.provider,
                    "estimated_usd": n.estimated_usd,
                }
                for n in self.nodes
            ],
        }
