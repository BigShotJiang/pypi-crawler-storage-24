"""Detect and run the appropriate test suite for a workspace."""
from __future__ import annotations

import subprocess
from dataclasses import dataclass
from pathlib import Path


@dataclass
class TestResult:
    runner: str
    exit_code: int
    stdout: str
    stderr: str
    passed: int = 0
    failed: int = 0
    errors: int = 0

    @property
    def success(self) -> bool:
        return self.exit_code == 0


def detect_runner(workspace: str) -> str:
    """Detect the test runner for a workspace.

    Returns: 'pytest' | 'jest' | 'cargo' | 'go' | 'maven' | 'unknown'
    """
    p = Path(workspace)
    if (p / "package.json").exists():
        return "jest"
    if (p / "Cargo.toml").exists():
        return "cargo"
    if (p / "go.mod").exists():
        return "go"
    if (p / "pom.xml").exists() or (p / "build.gradle").exists():
        return "maven"
    # Default Python
    return "pytest"


def run_tests(workspace: str, runner: str | None = None, timeout: int = 120) -> TestResult:
    """Run tests in workspace using detected or specified runner."""
    if runner is None:
        runner = detect_runner(workspace)

    cmd_map = {
        "pytest": ["python", "-m", "pytest", "--tb=short", "-q"],
        "jest": ["npx", "jest", "--no-coverage"],
        "cargo": ["cargo", "test"],
        "go": ["go", "test", "./..."],
        "maven": ["mvn", "test", "-q"],
    }

    cmd = cmd_map.get(runner, ["python", "-m", "pytest", "--tb=short", "-q"])

    try:
        result = subprocess.run(
            cmd,
            cwd=workspace,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return TestResult(
            runner=runner,
            exit_code=result.returncode,
            stdout=result.stdout,
            stderr=result.stderr,
        )
    except subprocess.TimeoutExpired:
        return TestResult(runner=runner, exit_code=1, stdout="", stderr="Test timeout")
    except FileNotFoundError:
        return TestResult(runner=runner, exit_code=1, stdout="", stderr=f"{runner} not found")
    except Exception as e:
        return TestResult(runner=runner, exit_code=1, stdout="", stderr=str(e))
