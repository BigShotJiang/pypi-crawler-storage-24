"""E2E Runner — end-to-end smoke test harness with preflight + autopilot.

Runs preflight checks, then drives the full Planner → Worker → Judge loop.
Stops cleanly on approval blocks, missing deps, or terminal states.
"""

from __future__ import annotations

import contextlib
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from owlmind.agent.schemas import CycleState

logger = logging.getLogger(__name__)

# Exit codes
EXIT_OK = 0
EXIT_BLOCKED = 2
EXIT_PREFLIGHT_FAIL = 3
EXIT_FAILED = 4


@dataclass
class E2EConfig:
    """Configuration for an E2E smoke run."""

    goal: str = ""
    workspace: str = "."
    sandbox: bool = True
    use_llm: str = "both"  # none | planner | judge | both
    use_worker: str = "none"  # none | claude_cli
    provider_planner: str | None = None
    provider_judge: str | None = None
    max_steps: int = 200
    interval_sec: float = 1.0
    export_on_done: bool = True
    stop_on_approval: bool = True
    run_id: str | None = None

    # Paths
    policies_dir: Path = field(default_factory=lambda: Path("policies"))
    runs_dir: Path = field(default_factory=lambda: Path("runs"))
    ledger_dir: Path = field(default_factory=lambda: Path("ledger"))

    # Callbacks
    on_event: Any = None


@dataclass
class E2EResult:
    """Result of an E2E smoke run."""

    run_id: str = ""
    final_state: str = ""
    exit_code: int = EXIT_FAILED
    blocked_reason: str = ""
    next_commands: list[str] = field(default_factory=list)
    artifacts: dict[str, str] = field(default_factory=dict)
    preflight_ok: bool = False
    report_path: str = ""


def _emit(config: E2EConfig, name: str, data: dict[str, Any]) -> None:
    """Fire on_event callback if configured."""
    if config.on_event is not None:
        with contextlib.suppress(Exception):
            config.on_event(name, data)


def run_e2e(config: E2EConfig) -> E2EResult:
    """Run E2E smoke: preflight → autopilot → report.

    Returns E2EResult with exit_code:
    - 0: DONE
    - 2: BLOCKED (approval needed or waiting for user)
    - 3: preflight failed
    - 4: FAILED
    """
    from owlmind.autopilot import AutoPilotConfig
    from owlmind.autopilot import run as autopilot_run
    from owlmind.evidence import EvidenceStore
    from owlmind.preflight import PreflightConfig, run_preflight

    result = E2EResult()

    # --- 1. Preflight ---
    providers: list[str] | None = None
    if config.provider_planner or config.provider_judge:
        providers = []
        if config.provider_planner:
            providers.append(config.provider_planner)
        if config.provider_judge and config.provider_judge not in providers:
            providers.append(config.provider_judge)

    pf_config = PreflightConfig(
        use_llm=config.use_llm,
        use_worker=config.use_worker,
        providers=providers,
        workspace=config.workspace,
        sandbox=config.sandbox,
        require_network=config.use_llm != "none",
    )

    pf_report = run_preflight(pf_config)
    result.preflight_ok = pf_report.ok

    _emit(config, "preflight_done", {"ok": pf_report.ok})

    if not pf_report.ok:
        result.exit_code = EXIT_PREFLIGHT_FAIL
        result.blocked_reason = "Preflight failed"
        result.next_commands = list(pf_report.recommended_installs)
        if pf_report.missing_env:
            for env_var in pf_report.missing_env:
                result.next_commands.append(f"export {env_var}=...")
        if pf_report.missing_binaries:
            result.next_commands.append(
                "Install missing binaries: " + ", ".join(pf_report.missing_binaries)
            )
        return result

    # --- 2. Run autopilot ---
    _emit(config, "e2e_starting", {"goal": config.goal})

    ap_config = AutoPilotConfig(
        goal=config.goal,
        workspace=config.workspace,
        sandbox=config.sandbox,
        use_llm=config.use_llm,
        use_worker=config.use_worker,
        provider_planner=config.provider_planner,
        provider_judge=config.provider_judge,
        max_steps=config.max_steps,
        interval=config.interval_sec,
        auto_export=config.export_on_done,
        run_id=config.run_id,
        policies_dir=config.policies_dir,
        runs_dir=config.runs_dir,
        ledger_dir=config.ledger_dir,
        on_event=config.on_event,
    )

    ap_result = autopilot_run(ap_config)
    result.run_id = ap_result.run_id
    result.final_state = ap_result.final_state

    # --- 3. Record preflight as evidence ---
    try:
        evidence = EvidenceStore(config.runs_dir)
        evidence.append_event(
            result.run_id,
            {
                "event": "PREFLIGHT_RUN",
                "ok": pf_report.ok,
                "checks_total": len(pf_report.checks),
                "checks_passed": sum(1 for c in pf_report.checks if c.ok),
            },
        )

        # Save preflight report JSON
        run_dir = config.runs_dir / result.run_id
        artifacts_dir = run_dir / "artifacts"
        artifacts_dir.mkdir(parents=True, exist_ok=True)
        pf_path = artifacts_dir / "preflight_report.json"
        pf_path.write_text(pf_report.to_json())
        result.artifacts["preflight_report"] = str(pf_path)
    except Exception:
        logger.debug("Could not save preflight evidence")

    # --- 4. Determine exit code and next commands ---
    if result.final_state == CycleState.DONE.value:
        result.exit_code = EXIT_OK
        if ap_result.export_path:
            result.artifacts["export"] = ap_result.export_path
        _emit(config, "e2e_done", {"run_id": result.run_id})

    elif result.final_state == CycleState.WAIT_APPROVAL.value:
        result.exit_code = EXIT_BLOCKED
        result.blocked_reason = "Approval required"
        # Extract approval token from events
        approval_token = _find_approval_token(ap_result.events)
        if approval_token:
            result.next_commands.append(
                f"owlmind cycle approve --run-id {result.run_id} --token {approval_token}"
            )
        result.next_commands.append(
            f"owlmind e2e smoke --run-id {result.run_id} --workspace {config.workspace}"
        )
        _emit(
            config,
            "e2e_blocked",
            {
                "run_id": result.run_id,
                "reason": "WAIT_APPROVAL",
            },
        )

    elif result.final_state in (
        CycleState.STARTED_WAIT_PLANNER.value,
        CycleState.WAIT_WORKER.value,
        CycleState.WAIT_JUDGE.value,
    ):
        result.exit_code = EXIT_BLOCKED
        result.blocked_reason = f"Waiting: {result.final_state}"
        result.next_commands.append(
            f"owlmind e2e smoke --run-id {result.run_id} --workspace {config.workspace}"
        )
        _emit(
            config,
            "e2e_blocked",
            {
                "run_id": result.run_id,
                "reason": result.final_state,
            },
        )

    else:
        result.exit_code = EXIT_FAILED
        result.blocked_reason = f"Failed: {result.final_state}"
        _emit(
            config,
            "e2e_failed",
            {
                "run_id": result.run_id,
                "state": result.final_state,
            },
        )

    # --- 5. Generate E2E report ---
    result.report_path = _write_e2e_report(config, result, pf_report)

    return result


def _find_approval_token(events: list[dict[str, Any]]) -> str:
    """Find the latest APPROVAL_CREATED token in events."""
    for event in reversed(events):
        if event.get("event") == "APPROVAL_CREATED":
            return str(event.get("token", ""))
    return ""


def _write_e2e_report(
    config: E2EConfig,
    result: E2EResult,
    pf_report: Any,
) -> str:
    """Write e2e_report.md to run directory. Returns path."""
    try:
        run_dir = config.runs_dir / result.run_id
        run_dir.mkdir(parents=True, exist_ok=True)

        lines = [
            f"# E2E Report — {result.run_id}",
            "",
            "## Preflight",
            f"- Status: {'PASS' if result.preflight_ok else 'FAIL'}",
        ]
        for check in pf_report.checks:
            icon = "+" if check.ok else "-"
            lines.append(f"  {icon} {check.name}: {check.details}")

        lines.extend(
            [
                "",
                "## AutoPilot",
                f"- Final state: {result.final_state}",
                f"- Exit code: {result.exit_code}",
            ]
        )

        if result.blocked_reason:
            lines.append(f"- Blocked: {result.blocked_reason}")

        if result.next_commands:
            lines.extend(["", "## Next Steps"])
            for cmd in result.next_commands:
                lines.append(f"  {cmd}")

        if result.artifacts:
            lines.extend(["", "## Artifacts"])
            for name, path in result.artifacts.items():
                lines.append(f"  - {name}: {path}")

        content = "\n".join(lines) + "\n"
        report_path = run_dir / "e2e_report.md"
        report_path.write_text(content)
        return str(report_path)
    except Exception:
        return ""
