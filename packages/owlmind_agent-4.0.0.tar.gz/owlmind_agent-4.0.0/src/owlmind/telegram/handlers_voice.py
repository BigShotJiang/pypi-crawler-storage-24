"""Telegram voice message handler — transcribes voice messages via Whisper.

Adds support for:
- Voice messages → transcribed text → processed as goal or chat message
- Audio files → same pipeline

When the bot receives a voice message it:
1. Downloads the OGG/Opus file from Telegram
2. Transcribes it with Whisper API
3. Shows the transcription to the user
4. Optionally runs it as a graph goal (if --auto-graph mode enabled)
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)


async def handle_voice_message(update: Any, context: Any, bot_ctx: Any) -> None:
    """Handle incoming Telegram voice message.

    Downloads voice → transcribes → echoes text → optionally runs as graph goal.

    Args:
        update: Telegram Update object.
        context: Telegram CallbackContext.
        bot_ctx: owlmind BotContext with config/state.
    """
    from owlmind.voice import is_available, transcribe_telegram_voice

    msg = update.message
    if msg is None:
        return

    # Check voice or audio
    voice = getattr(msg, "voice", None) or getattr(msg, "audio", None)
    if voice is None:
        return

    # Check permission
    user_id = msg.from_user.id if msg.from_user else 0
    allowed = getattr(bot_ctx, "allowed_ids", [])
    if allowed and user_id not in allowed:
        await msg.reply_text("⛔ Not authorized.")
        return

    if not is_available():
        await msg.reply_text(
            "🎙 Voice transcription unavailable.\n"
            "Set OPENAI_API_KEY in .env to enable Whisper."
        )
        return

    # Acknowledge
    await msg.reply_text("🎙 Transcribing voice message...")

    try:
        # Download file
        tg_file = await context.bot.get_file(voice.file_id)
        file_bytes = await tg_file.download_as_bytearray()

        # Transcribe
        text = await transcribe_telegram_voice(bytes(file_bytes))

        if not text:
            await msg.reply_text("❌ Could not transcribe voice message.")
            return

        # If auto-graph mode, combine acknowledgement + run notice
        auto_graph = getattr(bot_ctx, "auto_graph_voice", False)
        if auto_graph:
            await msg.reply_text(f"📝 Transcription: {text}\n🤖 Running graph...")
            await _run_as_graph_goal(msg, text, bot_ctx)
        else:
            await msg.reply_text(f"📝 Transcription:\n\n{text}")

    except Exception as e:
        logger.error("Voice handler error: %s", e)
        await msg.reply_text(f"❌ Transcription error: {e}")


async def _run_as_graph_goal(msg: Any, goal: str, bot_ctx: Any) -> None:
    """Run transcribed text as a graph pipeline goal."""
    import asyncio
    from concurrent.futures import ThreadPoolExecutor

    await msg.reply_text(f"🤖 Running as goal: {goal[:100]}...")

    def _run() -> str:
        from owlmind.graph.runner import GraphRunner
        workspace = getattr(bot_ctx, "workspace", ".")
        runner = GraphRunner()
        state = runner.run(goal, workspace=workspace, max_iterations=2)
        return f"Verdict: {state.final_verdict}\n\n{(state.review or '')[:500]}"

    try:
        loop = asyncio.get_event_loop()
        with ThreadPoolExecutor(max_workers=1) as pool:
            result = await loop.run_in_executor(pool, _run)
        await msg.reply_text(f"✅ Graph done:\n{result}")
    except Exception as e:
        await msg.reply_text(f"❌ Graph error: {e}")


async def cmd_voice_mode(ctx: Any, update: Any, context: Any) -> None:
    """Handle /voice_mode command — toggle auto-graph for voice messages.

    Usage:
        /voice_mode on   — enable auto-graph
        /voice_mode off  — transcribe only (default)
        /voice_mode      — show current mode
    """
    if update.message is None:
        return

    chat_id = update.effective_chat.id if update.effective_chat else 0
    allowed = getattr(ctx, "allowed", [])
    if allowed and chat_id not in allowed:
        await update.message.reply_text("⛔ Not authorized.")
        return

    args = context.args or []
    if not args:
        mode = "on" if getattr(ctx, "auto_graph_voice", False) else "off"
        await update.message.reply_text(f"🎙 Voice mode: {mode}\nUse /voice_mode on|off to change.")
        return

    sub = args[0].lower()
    if sub == "on":
        ctx.auto_graph_voice = True
        await update.message.reply_text("🤖 Voice mode ON — transcribed text will be run as a graph goal.")
    elif sub == "off":
        ctx.auto_graph_voice = False
        await update.message.reply_text("📝 Voice mode OFF — transcription only.")
    else:
        await update.message.reply_text("Usage: /voice_mode [on|off]")
