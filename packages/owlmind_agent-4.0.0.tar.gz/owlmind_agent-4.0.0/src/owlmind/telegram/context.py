"""BotContext — shared state for all Telegram bot handlers."""

from __future__ import annotations

import contextlib
import json
import os
from dataclasses import dataclass, field
from typing import Any


@dataclass
class BotContext:
    """Shared state passed to all handlers via functools.partial.

    Replaces the closure variables from the monolithic create_operator_bot().
    """

    app: Any
    operator: Any
    cycle_manager: Any
    allowed: list[int]
    last_event: dict[int, float]
    event_cooldown: float
    llm_profiles: dict[str, dict[str, str]]
    think_levels: dict[str, int]
    state: dict[str, object]
    state_file: str
    verbose_chats: set[int]
    heartbeat_job: list[Any]
    watched_runs: dict[int, set[str]]
    queue_job: list[object]
    api_port: int
    api_key: str
    auto_graph_voice: bool = False
    api_base: str = field(init=False)

    def __post_init__(self) -> None:
        self.api_base = f"http://127.0.0.1:{self.api_port}"

    def check_auth(self, chat_id: int) -> bool:
        """Return True if chat_id is authorized (or no allowlist set)."""
        if not self.allowed:
            return True
        return chat_id in self.allowed

    def load_bot_state(self) -> dict[str, object]:
        """Load persisted bot state from disk."""
        with contextlib.suppress(Exception), open(self.state_file) as f:
            data: dict[str, object] = json.loads(f.read())
            return data
        return {}

    def save_bot_state(self) -> None:
        """Persist current bot state to disk."""
        with contextlib.suppress(Exception), open(self.state_file, "w") as f:
            f.write(json.dumps(self.state, indent=2))


def make_bot_context(
    *,
    app: Any,
    operator: Any,
    cycle_manager: Any,
    allowed_chat_ids: list[int] | None = None,
) -> BotContext:
    """Factory to create BotContext with sensible defaults."""
    state_file = os.path.join(os.path.expanduser("~"), ".owlmind_bot_state.json")

    llm_profiles: dict[str, dict[str, str]] = {
        "fast": {"name": "Fast (Haiku)", "model": "claude-3-haiku-20240307"},
        "balanced": {"name": "Balanced (Sonnet)", "model": "claude-sonnet-4-6"},
        "powerful": {"name": "Powerful (Opus)", "model": "claude-opus-4-6"},
    }
    think_levels: dict[str, int] = {
        "off": 0,
        "minimal": 1024,
        "low": 2048,
        "medium": 8192,
        "high": 32768,
        "xhigh": 65536,
    }

    ctx = BotContext(
        app=app,
        operator=operator,
        cycle_manager=cycle_manager,
        allowed=allowed_chat_ids or [],
        last_event={},
        event_cooldown=60.0,
        llm_profiles=llm_profiles,
        think_levels=think_levels,
        state={"llm_profile": "balanced", "thinking_level": "medium"},
        state_file=state_file,
        verbose_chats=set(),
        heartbeat_job=[],
        watched_runs={},
        queue_job=[],
        api_port=int(os.environ.get("OWLMIND_API_PORT", "8765")),
        api_key=os.environ.get("OWLMIND_API_KEY", ""),
    )
    # Merge persisted state
    ctx.state.update(ctx.load_bot_state())
    return ctx
