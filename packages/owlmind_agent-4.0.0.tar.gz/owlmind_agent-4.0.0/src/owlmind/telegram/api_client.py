"""Thin async wrappers around the OWLMIND REST API (urllib-based)."""

from __future__ import annotations

import json
import socket
import urllib.error
import urllib.request
from typing import Any

from owlmind.telegram.context import BotContext


def is_api_error(response: dict[str, Any]) -> bool:
    """Return True if *response* contains an error key (any error type)."""
    return "error" in response


def _handle_http_error(exc: urllib.error.HTTPError) -> dict[str, Any]:
    """Convert an HTTPError into a typed error dict based on status code."""
    code = exc.code
    if code in (401, 403):
        return {"error": "auth_error", "status": code}
    if 400 <= code < 500:
        return {"error": "client_error", "status": code, "message": str(exc)}
    if 500 <= code < 600:
        return {"error": "server_error", "status": code, "message": str(exc)}
    return {"error": "http_error", "status": code, "message": str(exc)}


def _handle_url_error(exc: urllib.error.URLError) -> dict[str, Any]:
    """Convert a URLError into a typed error dict (network or timeout)."""
    reason = exc.reason
    if (
        isinstance(reason, socket.timeout)
        or isinstance(exc, urllib.error.URLError)
        and isinstance(reason, str)
        and "timed out" in reason.lower()
    ):
        return {"error": "timeout_error"}
    return {"error": "network_error", "message": str(reason)}


async def api_get(ctx: BotContext, path: str) -> Any:
    """GET request to the local OWLMIND API."""
    url = f"{ctx.api_base}{path}"
    req = urllib.request.Request(url, headers={"X-API-Key": ctx.api_key})
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as exc:
        return _handle_http_error(exc)
    except TimeoutError:
        return {"error": "timeout_error"}
    except urllib.error.URLError as exc:
        return _handle_url_error(exc)
    except (OSError, json.JSONDecodeError) as exc:
        return {"error": "network_error", "message": str(exc)}


async def api_post(ctx: BotContext, path: str, *, params: str = "", body: object = None) -> Any:
    """POST request to the local OWLMIND API."""
    url = f"{ctx.api_base}{path}"
    if params:
        url = f"{url}?{params}"
    data = json.dumps(body).encode() if body else b""
    req = urllib.request.Request(
        url,
        data=data,
        headers={"X-API-Key": ctx.api_key, "Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as exc:
        return _handle_http_error(exc)
    except TimeoutError:
        return {"error": "timeout_error"}
    except urllib.error.URLError as exc:
        return _handle_url_error(exc)
    except (OSError, json.JSONDecodeError) as exc:
        return {"error": "network_error", "message": str(exc)}


async def api_delete(ctx: BotContext, path: str) -> Any:
    """DELETE request to the local OWLMIND API."""
    url = f"{ctx.api_base}{path}"
    req = urllib.request.Request(
        url,
        headers={"X-API-Key": ctx.api_key},
        method="DELETE",
    )
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as exc:
        return _handle_http_error(exc)
    except TimeoutError:
        return {"error": "timeout_error"}
    except urllib.error.URLError as exc:
        return _handle_url_error(exc)
    except (OSError, json.JSONDecodeError) as exc:
        return {"error": "network_error", "message": str(exc)}
