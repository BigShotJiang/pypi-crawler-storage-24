"""Session command handlers — /session_start, /session_resume, etc."""

from __future__ import annotations

from typing import Any

from owlmind.telegram.context import BotContext
from owlmind.telegram.helpers import (
    _format_session_result,
    make_event_notifier,
    parse_session_resume_args,
    parse_session_start_args_full,
)


async def cmd_session_start(ctx: BotContext, update: Any, context: Any) -> None:
    if not update.message:
        return
    chat_id = update.message.chat_id
    if not ctx.check_auth(chat_id):
        await update.message.reply_text("Unauthorized.")
        return

    if not ctx.operator:
        await update.message.reply_text("Operator service not configured.")
        return

    args = context.args or []
    if not args:
        await update.message.reply_text(
            "Usage: /session_start <goals_file> [--workspace PATH] "
            "[--max-concurrency N] [--continue-on-fail]",
        )
        return

    sa = parse_session_start_args_full(args, ctx.operator.default_workspace)
    if not sa.goals_file:
        await update.message.reply_text("Usage: /session_start <goals_file>")
        return

    if not ctx.operator.is_workspace_allowed(sa.workspace):
        await update.message.reply_text(f"Workspace not allowed: {sa.workspace}")
        return

    await update.message.reply_text(
        f"Starting session...\nGoals: {sa.goals_file}\nWorkspace: {sa.workspace}",
    )

    try:
        result = await ctx.operator.start_session_async(
            sa.goals_file,
            sa.workspace,
            max_concurrency=sa.max_concurrency,
            continue_on_fail=sa.continue_on_fail,
            sandbox=sa.sandbox,
            use_llm=sa.use_llm,
            use_worker=sa.use_worker,
            auto_approve=True,
            on_event=make_event_notifier(
                ctx.app, chat_id, ctx.last_event, ctx.event_cooldown, ctx.verbose_chats
            ),
        )
        text = _format_session_result(result)
        await update.message.reply_text(text)
    except Exception as exc:
        await update.message.reply_text(f"Error: {exc}")


async def cmd_session_resume(ctx: BotContext, update: Any, context: Any) -> None:
    if not update.message:
        return
    chat_id = update.message.chat_id
    if not ctx.check_auth(chat_id):
        await update.message.reply_text("Unauthorized.")
        return

    if not ctx.operator:
        await update.message.reply_text("Operator service not configured.")
        return

    args = context.args or []
    if not args:
        await update.message.reply_text("Usage: /session_resume <session_id> [--max-concurrency N]")
        return

    session_id, max_conc, cont_fail = parse_session_resume_args(args)

    await update.message.reply_text(f"Resuming session: {session_id}")

    try:
        result = await ctx.operator.resume_session_async(
            session_id,
            max_concurrency=max_conc if max_conc > 0 else None,
            continue_on_fail=cont_fail,
            on_event=make_event_notifier(
                ctx.app, chat_id, ctx.last_event, ctx.event_cooldown, ctx.verbose_chats
            ),
        )
        text = _format_session_result(result)
        await update.message.reply_text(text)
    except Exception as exc:
        await update.message.reply_text(f"Error: {exc}")


async def cmd_session_stop(ctx: BotContext, update: Any, context: Any) -> None:
    if not update.message:
        return
    if not ctx.check_auth(update.message.chat_id):
        await update.message.reply_text("Unauthorized.")
        return

    if not ctx.operator:
        await update.message.reply_text("Operator service not configured.")
        return

    args = context.args or []
    if not args:
        await update.message.reply_text("Usage: /session_stop <session_id>")
        return

    try:
        result = ctx.operator.stop_session(args[0])
        await update.message.reply_text(
            f"Session stopped.\nID: {result['session_id']}\nStatus: {result['status']}",
        )
    except Exception as exc:
        await update.message.reply_text(f"Error: {exc}")


async def cmd_session_status(ctx: BotContext, update: Any, context: Any) -> None:
    if not update.message:
        return
    if not ctx.check_auth(update.message.chat_id):
        await update.message.reply_text("Unauthorized.")
        return

    if not ctx.operator:
        await update.message.reply_text("Operator service not configured.")
        return

    args = context.args or []
    if not args:
        await update.message.reply_text("Usage: /session_status <session_id>")
        return

    try:
        info = ctx.operator.get_session_status(args[0])
        lines = [
            f"Session: {info['session_id']}",
            f"Status: {info['status']}",
            f"Created: {info['created_at']}",
            f"Goals: {info['goals_total']}",
            f"Concurrency: {info['max_concurrency']}",
        ]
        if info["last_block_reason"]:
            lines.append(f"Blocked: {info['last_block_reason']}")
        lines.append("")
        for g in info["goals"]:
            lines.append(f"  {g['id']} [{g['status']}] {g['goal']}")
        await update.message.reply_text("\n".join(lines))
    except Exception as exc:
        await update.message.reply_text(f"Error: {exc}")


async def cmd_session_graph(ctx: BotContext, update: Any, context: Any) -> None:
    if not update.message:
        return
    if not ctx.check_auth(update.message.chat_id):
        await update.message.reply_text("Unauthorized.")
        return

    if not ctx.operator:
        await update.message.reply_text("Operator service not configured.")
        return

    args = context.args or []
    if not args:
        await update.message.reply_text("Usage: /session_graph <session_id>")
        return

    try:
        graph = ctx.operator.get_session_graph(args[0])
        await update.message.reply_text(graph or "No DAG info.")
    except Exception as exc:
        await update.message.reply_text(f"Error: {exc}")


async def cmd_session_export(ctx: BotContext, update: Any, context: Any) -> None:
    if not update.message:
        return
    if not ctx.check_auth(update.message.chat_id):
        await update.message.reply_text("Unauthorized.")
        return

    if not ctx.operator:
        await update.message.reply_text("Operator service not configured.")
        return

    args = context.args or []
    if not args:
        await update.message.reply_text("Usage: /session_export <session_id>")
        return

    try:
        zip_path = ctx.operator.export_session(args[0])
        try:
            with open(str(zip_path), "rb") as _zf:
                await context.bot.send_document(
                    chat_id=update.message.chat_id,
                    document=_zf,
                    filename=f"session_{args[0]}.zip",
                    caption=f"Session export: {args[0]}",
                )
        except Exception:
            await update.message.reply_text(f"Session exported: {zip_path}")
    except Exception as exc:
        await update.message.reply_text(f"Error: {exc}")


async def cmd_session_rollback(ctx: BotContext, update: Any, context: Any) -> None:
    if not update.message:
        return
    if not ctx.check_auth(update.message.chat_id):
        await update.message.reply_text("Unauthorized.")
        return

    if not ctx.operator:
        await update.message.reply_text("Operator service not configured.")
        return

    args = context.args or []
    if len(args) < 2:
        await update.message.reply_text(
            "Usage: /session_rollback <session_id> <goal_id> [--yes]",
        )
        return

    session_id = args[0]
    goal_id = args[1]
    yes = "--yes" in args[2:]

    try:
        result = ctx.operator.rollback_session_goal(session_id, goal_id, yes=yes)
        if result.get("status") == "approval_required":
            text = (
                "Rollback requires approval.\n"
                f"Token: {result.get('token', '?')}\n"
                f"Instructions: {result.get('instructions', '?')}\n"
                "\nRe-send with --yes to execute."
            )
        else:
            text = "Rollback result:\n" + "\n".join(f"  {k}: {v}" for k, v in result.items())
        await update.message.reply_text(text)
    except Exception as exc:
        await update.message.reply_text(f"Error: {exc}")


async def cmd_session_help(ctx: BotContext, update: Any, context: Any) -> None:
    if not update.message:
        return
    if not ctx.check_auth(update.message.chat_id):
        await update.message.reply_text("Unauthorized.")
        return

    text = (
        "Session Commands:\n\n"
        "/session_start <goals_file> [--workspace PATH] "
        "[--max-concurrency N] [--continue-on-fail]\n"
        "  Start a new session from goals YAML file.\n\n"
        "/session_resume <session_id> [--max-concurrency N] "
        "[--continue-on-fail]\n"
        "  Resume a blocked/stopped session.\n\n"
        "/session_stop <session_id>\n"
        "  Stop a running session.\n\n"
        "/session_status <session_id>\n"
        "  Show session status and goals.\n\n"
        "/session_graph <session_id>\n"
        "  Show DAG dependency graph.\n\n"
        "/session_export <session_id>\n"
        "  Export session as zip bundle.\n\n"
        "/session_rollback <session_id> <goal_id> [--yes]\n"
        "  Rollback a goal (--yes skips approval)."
    )
    await update.message.reply_text(text)
