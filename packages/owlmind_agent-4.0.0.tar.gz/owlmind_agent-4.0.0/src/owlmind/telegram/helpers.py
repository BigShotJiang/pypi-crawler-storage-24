"""Telegram bot helpers — parsers, formatters, event notifier."""

from __future__ import annotations

import asyncio
import contextlib
import logging
import time
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger(__name__)

_PTB_AVAILABLE = False
try:
    from telegram import InlineKeyboardButton, InlineKeyboardMarkup

    _PTB_AVAILABLE = True
except ImportError:
    pass


def parse_workspace_from_args(args: list[str], default: str) -> tuple[str, list[str]]:
    """Extract --workspace VALUE from args list.

    Returns (workspace, remaining_args).
    """
    workspace = default
    remaining: list[str] = []
    skip_next = False
    for i, arg in enumerate(args):
        if skip_next:
            skip_next = False
            continue
        if arg == "--workspace" and i + 1 < len(args):
            workspace = args[i + 1]
            skip_next = True
        else:
            remaining.append(arg)
    return workspace, remaining


@dataclass
class SessionStartArgs:
    """Parsed /session_start arguments."""

    goals_file: str = ""
    workspace: str = ""
    max_concurrency: int = 1
    continue_on_fail: bool = False
    sandbox: bool = False
    use_llm: str = "both"
    use_worker: str = "none"


def parse_session_start_args(
    args: list[str],
    default_workspace: str,
) -> tuple[str, str, int, bool]:
    """Parse /session_start args (backward-compat 4-tuple).

    Returns (goals_file, workspace, max_concurrency, continue_on_fail).
    """
    parsed = parse_session_start_args_full(args, default_workspace)
    return parsed.goals_file, parsed.workspace, parsed.max_concurrency, parsed.continue_on_fail


_VALID_LLM = frozenset({"both", "planner", "judge", "none"})
_VALID_WORKER = frozenset({"none", "claude_cli"})


def parse_session_start_args_full(
    args: list[str],
    default_workspace: str,
) -> SessionStartArgs:
    """Parse /session_start args with all flags.

    Handles: --workspace, --max-concurrency, --continue-on-fail,
             --sandbox on|off, --llm both|planner|judge|none,
             --worker none|claude_cli.
    """
    result = SessionStartArgs(workspace=default_workspace)
    remaining: list[str] = []
    skip_next = False

    for i, arg in enumerate(args):
        if skip_next:
            skip_next = False
            continue
        if arg == "--workspace" and i + 1 < len(args):
            result.workspace = args[i + 1]
            skip_next = True
        elif arg == "--max-concurrency" and i + 1 < len(args):
            with contextlib.suppress(ValueError):
                result.max_concurrency = int(args[i + 1])
            skip_next = True
        elif arg == "--sandbox" and i + 1 < len(args):
            result.sandbox = args[i + 1].lower() in ("on", "true", "1", "yes")
            skip_next = True
        elif arg == "--llm" and i + 1 < len(args):
            val = args[i + 1].lower()
            if val in _VALID_LLM:
                result.use_llm = val
            skip_next = True
        elif arg == "--worker" and i + 1 < len(args):
            val = args[i + 1].lower()
            if val in _VALID_WORKER:
                result.use_worker = val
            skip_next = True
        elif arg == "--continue-on-fail":
            result.continue_on_fail = True
        else:
            remaining.append(arg)

    result.goals_file = remaining[0] if remaining else ""
    return result


def parse_session_resume_args(args: list[str]) -> tuple[str, int, bool | None]:
    """Parse /session_resume args.

    Returns (session_id, max_concurrency, continue_on_fail).
    """
    max_concurrency = 0
    continue_on_fail: bool | None = None
    remaining: list[str] = []
    skip_next = False

    for i, arg in enumerate(args):
        if skip_next:
            skip_next = False
            continue
        if arg == "--max-concurrency" and i + 1 < len(args):
            with contextlib.suppress(ValueError):
                max_concurrency = int(args[i + 1])
            skip_next = True
        elif arg == "--continue-on-fail":
            continue_on_fail = True
        else:
            remaining.append(arg)

    session_id = remaining[0] if remaining else ""
    return session_id, max_concurrency, continue_on_fail


def _format_session_result(result: dict[str, Any]) -> str:
    """Format session result dict for Telegram message."""
    lines = [
        f"Session: {result.get('status', '?')}",
        f"ID: {result.get('session_id', '?')}",
        f"Goals: {result.get('goals_done', 0)}/{result.get('goals_total', 0)} done",
    ]
    if result.get("goals_failed"):
        lines.append(f"Failed: {result['goals_failed']}")
    if result.get("goals_blocked"):
        lines.append(f"Blocked: {result['goals_blocked']}")
    if result.get("goals_skipped"):
        lines.append(f"Skipped: {result['goals_skipped']}")
    if result.get("last_block_reason"):
        lines.append(f"Reason: {result['last_block_reason']}")
    if result.get("next_commands"):
        lines.append("\nNext:")
        for cmd in result["next_commands"]:
            lines.append(f"  {cmd}")
    return "\n".join(lines)


def make_event_notifier(
    bot_app: Any,
    chat_id: int,
    last_event: dict[int, float],
    cooldown: float,
    verbose_chats: set[int] | None = None,
) -> Any:
    """Create a synchronous on_event callback that sends Telegram notifications.

    Rate-limited: at most one message per `cooldown` seconds per chat.
    Deduplicates identical event+key combos within cooldown window.
    Fires for all events when chat_id is in verbose_chats, otherwise only notable ones.
    """

    _NOTABLE_EVENTS = frozenset(
        {
            "started",
            "resumed",
            "terminal",
            "blocked",
            "llm_planner_start",
            "llm_judge_start",
            "worker_start",
            "llm_planner_done",
            "llm_judge_done",
            "worker_done",
            "worker_approval_needed",
            "exported",
            "finished",
            "hard_fail",
            "error",
            "preflight_done",
            "e2e_done",
            "e2e_blocked",
            "e2e_failed",
            "auto_committed",
            # Session events
            "session_goal_starting",
            "session_goal_done",
            "session_started",
            "session_done",
            "session_blocked",
            "session_failed",
        }
    )

    _NO_COOLDOWN_EVENTS = frozenset({"llm_planner_start", "llm_judge_start", "worker_start"})

    _last_event_key: dict[int, str] = {}

    def _handler(event_name: str, data: dict[str, Any]) -> None:
        verbose = verbose_chats is not None and chat_id in verbose_chats
        if not verbose and event_name not in _NOTABLE_EVENTS:
            return

        now = time.monotonic()
        if event_name not in _NO_COOLDOWN_EVENTS and now - last_event.get(chat_id, 0.0) < cooldown:
            return

        # Dedupe: same event+session+goal within cooldown
        event_key = (
            f"{event_name}:{data.get('session_id', '')}:"
            f"{data.get('goal_id', '')}:{data.get('run_id', '')}"
        )
        if _last_event_key.get(chat_id) == event_key:
            return
        _last_event_key[chat_id] = event_key
        last_event[chat_id] = now

        msg = _format_event_message(event_name, data)

        reply_markup = None
        if event_name == "worker_approval_needed":
            _run_id = data.get("run_id", "")
            _token = data.get("token", "")
            if _run_id and _token and _PTB_AVAILABLE:
                reply_markup = InlineKeyboardMarkup(
                    [
                        [
                            InlineKeyboardButton(
                                "\u2705 Approve", callback_data=f"approve:{_run_id}:{_token}"
                            ),
                            InlineKeyboardButton(
                                "\u274c Deny", callback_data=f"deny:{_run_id}:{_token}"
                            ),
                        ]
                    ]
                )
                msg = msg.replace("/approve", "\u2193 Use buttons below:")

        try:
            loop = asyncio.get_running_loop()
            loop.create_task(
                bot_app.bot.send_message(chat_id=chat_id, text=msg, reply_markup=reply_markup)
            )
        except RuntimeError:
            logger.debug("No event loop for Telegram notification")

    return _handler


def _format_event_message(event_name: str, data: dict[str, Any]) -> str:
    """Format an event into a Telegram-friendly message."""
    run_id = data.get("run_id", "")
    msg = f"[OWLMIND] {event_name}"
    if run_id:
        msg += f"\nRun: {run_id}"

    # Autopilot events
    if event_name == "started":
        msg += f"\nGoal: {data.get('goal', '?')}"
    elif event_name in ("terminal", "blocked"):
        msg += f"\nState: {data.get('state', '?')}"
    elif event_name == "error":
        msg += f"\nError: {data.get('error', '?')}"
    elif event_name == "finished":
        msg += f"\nState: {data.get('final_state', '?')}"
        reason = data.get("stop_reason", "")
        if reason:
            msg += f"\nReason: {reason}"
        cost = data.get("cost_summary", "")
        if cost:
            msg += f"\n💰 Cost: {cost}"
    elif event_name == "worker_approval_needed":
        msg += f"\n{data.get('message', '?')}"
    elif event_name == "llm_planner_start":
        msg = f"⚙️ Planner думает...\nRun: {run_id}"
    elif event_name == "llm_planner_done":
        tokens = data.get("total_tokens", 0)
        latency = data.get("latency_ms", 0)
        msg = f"📋 План готов | {tokens:,} tok | {latency}ms\nRun: {run_id}"
    elif event_name == "llm_judge_start":
        msg = f"⚖️ Judge проверяет...\nRun: {run_id}"
    elif event_name == "llm_judge_done":
        verdict = data.get("verdict", "?")
        tokens = data.get("total_tokens", 0)
        icon = "✅" if verdict == "APPROVED" else "🔄" if verdict == "NEEDS_FIX" else "❌"
        msg = f"{icon} Judge: {verdict} | {tokens:,} tok\nRun: {run_id}"
    elif event_name == "worker_start":
        iteration = data.get("iteration", "")
        iter_str = f" (iter {iteration})" if iteration else ""
        msg = f"🔨 Worker пишет код{iter_str}...\nRun: {run_id}"
    elif event_name == "auto_committed":
        diff_stat = data.get("diff_stat", "")
        pr_url = data.get("pr_url", "")
        msg = "✅ Готово! Изменения запушены."
        if diff_stat:
            # Show only first 10 lines of diff stat
            lines = diff_stat.splitlines()
            short = "\n".join(lines[:10])
            if len(lines) > 10:
                short += f"\n… (+{len(lines) - 10} more files)"
            msg += f"\n```\n{short}\n```"
        if pr_url:
            msg += f"\n🔗 PR: {pr_url}"

    # Session events
    elif event_name == "session_goal_starting":
        sid = data.get("session_id", "?")
        gid = data.get("goal_id", "?")
        msg = f"[SESSION] Goal starting: {gid}\nSession: {sid}"
    elif event_name == "session_goal_done":
        sid = data.get("session_id", "?")
        gid = data.get("goal_id", "?")
        msg = f"[SESSION] Goal done: {gid}\nSession: {sid}"
    elif event_name == "session_started":
        sid = data.get("session_id", "?")
        msg = f"[SESSION] Started\nSession: {sid}"
    elif event_name == "session_done":
        sid = data.get("session_id", "?")
        msg = f"[SESSION] Complete\nSession: {sid}"
    elif event_name == "session_blocked":
        sid = data.get("session_id", "?")
        reason = data.get("reason", "?")
        msg = f"[SESSION] Blocked\nSession: {sid}\nReason: {reason}"
    elif event_name == "session_failed":
        sid = data.get("session_id", "?")
        reason = data.get("reason", "?")
        msg = f"[SESSION] Failed\nSession: {sid}\nReason: {reason}"

    return msg
