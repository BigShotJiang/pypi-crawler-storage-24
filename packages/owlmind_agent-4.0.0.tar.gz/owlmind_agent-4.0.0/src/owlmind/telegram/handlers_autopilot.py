"""Autopilot command handlers — /help, /auto_start, /auto_stop, etc."""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import os
import subprocess
import threading
import time
from pathlib import Path
from typing import Any

from owlmind.agent.task_splitter import split_goal
from owlmind.telegram.api_client import api_post
from owlmind.telegram.context import BotContext
from owlmind.telegram.helpers import make_event_notifier, parse_workspace_from_args

logger = logging.getLogger(__name__)

# File to persist scheduled nightly goals
_SCHEDULE_FILE = Path.home() / "owlmind" / "schedule.json"


class _SimpleLLMDriver:
    """Minimal LLM driver with a .complete(system, user) -> str interface.

    Used exclusively for task decomposition in /parallel_start.
    Tries OpenAI SDK first (also covers DeepSeek via OPENAI_BASE_URL),
    then falls back to Anthropic SDK.
    """

    def complete(self, system: str, user: str) -> str:
        openai_key = os.environ.get("OPENAI_API_KEY", "")
        if openai_key:
            try:
                from openai import OpenAI  # type: ignore[import]

                kwargs: dict[str, Any] = {}
                base_url = os.environ.get("OPENAI_BASE_URL", "")
                if base_url:
                    kwargs["base_url"] = base_url
                client = OpenAI(api_key=openai_key, **kwargs)
                model = os.environ.get(
                    "OWLMIND_OPENAI_PLANNER_MODEL",
                    "deepseek-chat" if base_url else "gpt-4o-mini",
                )
                resp = client.chat.completions.create(
                    model=model,
                    messages=[
                        {"role": "system", "content": system},
                        {"role": "user", "content": user},
                    ],
                    max_tokens=512,
                )
                return resp.choices[0].message.content or ""
            except Exception:
                logger.debug("_SimpleLLMDriver: OpenAI call failed", exc_info=True)

        anthropic_key = os.environ.get("ANTHROPIC_API_KEY", "")
        if anthropic_key:
            try:
                import anthropic as _anthropic  # type: ignore[import]

                client_a = _anthropic.Anthropic(api_key=anthropic_key)
                model_a = os.environ.get("OWLMIND_ANTHROPIC_MODEL", "claude-3-haiku-20240307")
                resp_a = client_a.messages.create(
                    model=model_a,
                    max_tokens=512,
                    system=system,
                    messages=[{"role": "user", "content": user}],
                )
                return resp_a.content[0].text if resp_a.content else ""
            except Exception:
                logger.debug("_SimpleLLMDriver: Anthropic call failed", exc_info=True)

        raise RuntimeError("No LLM available for task decomposition (set OPENAI_API_KEY or ANTHROPIC_API_KEY)")


def _make_split_driver() -> _SimpleLLMDriver | None:
    """Return a _SimpleLLMDriver if any LLM key is configured, else None."""
    if os.environ.get("OPENAI_API_KEY") or os.environ.get("ANTHROPIC_API_KEY"):
        return _SimpleLLMDriver()
    return None


async def cmd_help(ctx: BotContext, update: Any, context: Any) -> None:
    if not update.message:
        return
    if not ctx.check_auth(update.message.chat_id):
        await update.message.reply_text("Unauthorized.")
        return

    text = (
        "OWLMIND Operator Bot\n\n"
        "Autopilot:\n"
        "/auto_start <goal> [--workspace PATH] \u2014 Start autopilot\n"
        "/parallel_start <goal1> | <goal2> \u2014 Run goals in parallel\n"
        "/auto_stop <run_id> \u2014 Stop a run\n"
        "/e2e_preflight [workspace] \u2014 Preflight checks\n"
        "/e2e_smoke <goal> [--workspace PATH] \u2014 E2E smoke\n"
        "/approve <run_id> <token> \u2014 Approve\n"
        "/deny <run_id> <token> \u2014 Deny\n"
        "/resume <run_id> \u2014 Resume an interrupted run\n"
        "/hitl_approve <run_id> \u2014 Approve pending plan (HITL)\n"
        "/hitl_reject <run_id> [feedback] \u2014 Reject plan (HITL)\n"
        "/status [run_id] \u2014 Show status\n"
        "/runs \u2014 List tracked runs\n\n"
        "Sessions:\n"
        "/session_start <goals_file> [--workspace PATH] \u2014 Start session\n"
        "/session_resume <session_id> \u2014 Resume session\n"
        "/session_stop <session_id> \u2014 Stop session\n"
        "/session_status <session_id> \u2014 Session status\n"
        "/session_graph <session_id> \u2014 DAG view\n"
        "/session_export <session_id> \u2014 Export zip\n"
        "/session_rollback <session_id> <goal_id> [--yes] \u2014 Rollback\n"
        "/session_help \u2014 Session commands help\n\n"
        "LLM & AI:\n"
        "/model \u2014 Switch LLM profile (fast/balanced/powerful)\n"
        "/think \u2014 Set thinking depth (off/minimal/low/medium/high/xhigh)\n"
        "/memory \u2014 Access persistent memory\n\n"
        "Monitoring:\n"
        "/verbose \u2014 Toggle verbose event reporting\n"
        "/heartbeat \u2014 Enable/disable heartbeat check-ins\n"
        "/screenshot \u2014 Capture current screen\n"
        "/watch <run_id> \u2014 Watch run events live (30s updates)\n"
        "/queue \u2014 Manage task queue\n"
        "/digest [days] \u2014 Daily usage digest\n"
        "/stuck [minutes] \u2014 Detect stuck sessions\n"
        "/skillpack [id] \u2014 List or view skill packs\n\n"
        "Graph Pipeline:\n"
        "/graph <goal> [--workspace PATH] \u2014 Run Architect\u2192Coder\u2192Tester\u2192Reviewer\n"
        "/watch_start <goal> [--interval N] [--workspace PATH] \u2014 Start autonomous scheduler\n"
        "/watch_stop \u2014 Stop autonomous scheduler\n"
        "/watch_status \u2014 Show scheduler status\n"
        "(Voice messages also supported \u2014 transcribed via Whisper)\n\n"
        "/help \u2014 This help"
    )
    await update.message.reply_text(text)


async def cmd_auto_start(ctx: BotContext, update: Any, context: Any) -> None:
    if not update.message:
        return
    chat_id = update.message.chat_id
    if not ctx.check_auth(chat_id):
        await update.message.reply_text("Unauthorized.")
        return

    if not ctx.operator:
        await update.message.reply_text("Operator service not configured.")
        return

    args = context.args or []
    if not args:
        await update.message.reply_text("Usage: /auto_start <goal> [--workspace PATH] [--max-iter N]")
        return

    # Parse --max-iter N flag
    max_iter = 10
    filtered_args: list[str] = []
    i = 0
    while i < len(args):
        if args[i] == "--max-iter" and i + 1 < len(args):
            with contextlib.suppress(ValueError):
                max_iter = int(args[i + 1])
            i += 2
        else:
            filtered_args.append(args[i])
            i += 1

    workspace, remaining = parse_workspace_from_args(filtered_args, ctx.operator.default_workspace)
    goal = " ".join(remaining)

    if not goal:
        await update.message.reply_text("Usage: /auto_start <goal> [--workspace PATH] [--max-iter N]")
        return

    if not ctx.operator.is_workspace_allowed(workspace):
        await update.message.reply_text(f"Workspace not allowed: {workspace}")
        return

    # Защита от дублей — проверяем активные раны
    active = ctx.operator.active_runs()
    if active:
        run_ids = ", ".join(f"`{r.run_id[:12]}`" for r in active[:3])
        await update.message.reply_text(
            f"⚠️ Уже запущен цикл: {run_ids}\nПодожди завершения или останови через /auto_stop",
            parse_mode="Markdown",
        )
        return

    started = time.time()
    max_steps = max_iter * 20  # ~20 steps per iteration
    start_msg = await update.message.reply_text(
        f"⏳ Autopilot запущен\nGoal: {goal[:80]}\nMax iter: {max_iter}"
    )
    _progress_phase = ["🚀 Запуск..."]

    async def _live_progress() -> None:
        """Edit the start message every 30s with current phase and elapsed time."""
        import contextlib as _cl
        while True:
            await asyncio.sleep(30)
            elapsed = time.time() - started
            mins, secs = divmod(int(elapsed), 60)
            elapsed_str = f"{mins}m {secs}s" if mins else f"{secs}s"
            with _cl.suppress(Exception):
                await start_msg.edit_text(
                    f"⏳ {_progress_phase[0]}\nGoal: {goal[:80]}\nЭлапсед: {elapsed_str}"
                )

    _progress_task = asyncio.create_task(_live_progress())

    original_on_event = make_event_notifier(
        ctx.app, chat_id, ctx.last_event, ctx.event_cooldown, ctx.verbose_chats
    )

    def _tracking_on_event(event_name: str, data: dict) -> None:
        if event_name == "llm_planner_start":
            _progress_phase[0] = "⚙️ Planner думает..."
        elif event_name == "worker_start":
            iter_num = data.get("iteration", "")
            _progress_phase[0] = f"🔨 Worker пишет код (iter {iter_num})..."
        elif event_name == "llm_judge_start":
            _progress_phase[0] = "⚖️ Judge проверяет..."
        original_on_event(event_name, data)

    try:
        info = await ctx.operator.start_autopilot_async(
            goal=goal,
            workspace=workspace,
            use_llm="both",
            use_worker="claude_cli",
            auto_approve=True,
            max_steps=max_steps,
            on_event=_tracking_on_event,
        )
        _progress_task.cancel()
        elapsed = time.time() - started
        mins, secs = divmod(int(elapsed), 60)
        duration_str = f"{mins}m {secs}s" if mins else f"{secs}s"
        iters = getattr(info, "iterations", "?")
        cost = getattr(info, "cost_summary", "")

        state = info.final_state or info.status
        icon = "✅" if state in ("DONE", "done", "approved") else "❌"
        text = (
            f"{icon} Autopilot finished.\n"
            f"Run: `{info.run_id}`\n"
            f"State: {state}  |  Iter: {iters}  |  Time: {duration_str}"
        )
        if cost:
            text += f"\n💰 Cost: {cost}"
        pr_url = getattr(info, "pr_url", "")
        if pr_url:
            text += f"\n🔗 PR: {pr_url}"
        if info.stop_reason:
            text += f"\nReason: {info.stop_reason}"

        # Inline кнопки только когда DONE
        markup = None
        if state in ("DONE", "done"):
            try:
                from telegram import InlineKeyboardButton, InlineKeyboardMarkup

                run_short = info.run_id[:12]
                markup = InlineKeyboardMarkup([[
                    InlineKeyboardButton("🔀 Merge PR", callback_data=f"merge_run:{run_short}"),
                    InlineKeyboardButton("🔁 Ещё раз", callback_data=f"repeat_goal:{goal[:200]}"),
                ]])
            except Exception:
                pass

        await update.message.reply_text(text, parse_mode="Markdown", reply_markup=markup)
    except Exception as exc:
        await update.message.reply_text(f"Error: {exc}")


async def cmd_auto_stop(ctx: BotContext, update: Any, context: Any) -> None:
    if not update.message:
        return
    if not ctx.check_auth(update.message.chat_id):
        await update.message.reply_text("Unauthorized.")
        return

    if not ctx.operator:
        await update.message.reply_text("Operator service not configured.")
        return

    args = context.args or []
    if not args:
        await update.message.reply_text("Usage: /auto_stop <run_id>")
        return

    ok = ctx.operator.stop_run(args[0])
    if ok:
        await update.message.reply_text(f"Run {args[0]} stopped.")
    else:
        await update.message.reply_text(f"Run {args[0]} not found.")


async def cmd_e2e_preflight(ctx: BotContext, update: Any, context: Any) -> None:
    if not update.message:
        return
    if not ctx.check_auth(update.message.chat_id):
        await update.message.reply_text("Unauthorized.")
        return

    if not ctx.operator:
        await update.message.reply_text("Operator service not configured.")
        return

    args = context.args or []
    workspace = args[0] if args else ctx.operator.default_workspace

    if not ctx.operator.is_workspace_allowed(workspace):
        await update.message.reply_text(f"Workspace not allowed: {workspace}")
        return

    await update.message.reply_text(f"Running preflight for: {workspace}")

    try:
        result = ctx.operator.run_preflight(workspace)
        status = "PASS" if result["ok"] else "FAIL"
        text = f"Preflight: {status}\nChecks: {result['checks_passed']}/{result['checks_total']}"
        if result["missing_env"]:
            text += f"\nMissing env: {', '.join(result['missing_env'])}"
        if result["missing_deps"]:
            text += f"\nMissing deps: {', '.join(result['missing_deps'])}"
        if result["provider_status"]:
            for prov, st in result["provider_status"].items():
                text += f"\n  {prov}: {st}"
        await update.message.reply_text(text)
    except Exception as exc:
        await update.message.reply_text(f"Error: {exc}")


async def cmd_e2e_smoke(ctx: BotContext, update: Any, context: Any) -> None:
    if not update.message:
        return
    chat_id = update.message.chat_id
    if not ctx.check_auth(chat_id):
        await update.message.reply_text("Unauthorized.")
        return

    if not ctx.operator:
        await update.message.reply_text("Operator service not configured.")
        return

    args = context.args or []
    if not args:
        await update.message.reply_text("Usage: /e2e_smoke <goal> [--workspace PATH]")
        return

    workspace, remaining = parse_workspace_from_args(args, ctx.operator.default_workspace)
    goal = " ".join(remaining)

    if not goal:
        await update.message.reply_text("Usage: /e2e_smoke <goal>")
        return

    if not ctx.operator.is_workspace_allowed(workspace):
        await update.message.reply_text(f"Workspace not allowed: {workspace}")
        return

    await update.message.reply_text(f"Running E2E smoke...\nGoal: {goal}\nWorkspace: {workspace}")

    loop = asyncio.get_running_loop()
    try:
        result = await loop.run_in_executor(
            None,
            lambda: ctx.operator.run_e2e_smoke(
                goal,
                workspace,
                on_event=make_event_notifier(
                    ctx.app, chat_id, ctx.last_event, ctx.event_cooldown, ctx.verbose_chats
                ),
            ),
        )
        text = (
            f"E2E smoke finished.\n"
            f"Run: {result['run_id']}\n"
            f"Exit: {result['exit_code']}\n"
            f"State: {result['final_state']}\n"
            f"Preflight: {'PASS' if result['preflight_ok'] else 'FAIL'}"
        )
        if result["blocked_reason"]:
            text += f"\nBlocked: {result['blocked_reason']}"
        if result["next_commands"]:
            text += "\nNext:\n" + "\n".join(f"  {c}" for c in result["next_commands"])
        await update.message.reply_text(text)
    except Exception as exc:
        await update.message.reply_text(f"Error: {exc}")


async def cmd_approve(ctx: BotContext, update: Any, context: Any) -> None:
    if not update.message:
        return
    if not ctx.check_auth(update.message.chat_id):
        await update.message.reply_text("Unauthorized.")
        return

    args = context.args or []
    if len(args) < 2:
        await update.message.reply_text("Usage: /approve <run_id> <token>")
        return

    if not ctx.cycle_manager:
        await update.message.reply_text("Cycle manager not configured.")
        return

    run_id, token = args[0], args[1]
    try:
        from owlmind.approval import resolve_approval

        ok, msg = resolve_approval(ctx.cycle_manager.meta_store, run_id, token, approved=True)
        await update.message.reply_text(msg if ok else f"Failed: {msg}")
    except Exception as exc:
        await update.message.reply_text(f"Error: {exc}")


async def cmd_deny(ctx: BotContext, update: Any, context: Any) -> None:
    if not update.message:
        return
    if not ctx.check_auth(update.message.chat_id):
        await update.message.reply_text("Unauthorized.")
        return

    args = context.args or []
    if len(args) < 2:
        await update.message.reply_text("Usage: /deny <run_id> <token>")
        return

    if not ctx.cycle_manager:
        await update.message.reply_text("Cycle manager not configured.")
        return

    run_id, token = args[0], args[1]
    try:
        from owlmind.approval import resolve_approval

        ok, msg = resolve_approval(ctx.cycle_manager.meta_store, run_id, token, approved=False)
        await update.message.reply_text(msg if ok else f"Failed: {msg}")
    except Exception as exc:
        await update.message.reply_text(f"Error: {exc}")


async def handle_approval_callback(ctx: BotContext, update: Any, context: Any) -> None:
    """Handle inline keyboard button press for approve/deny."""
    query = update.callback_query
    if not query or not query.data:
        return
    chat_id = query.message.chat.id if query.message else 0
    if not ctx.check_auth(chat_id):
        await query.answer("Unauthorized.")
        return
    await query.answer()  # Acknowledge the button press

    parts = query.data.split(":", 2)
    if len(parts) != 3:
        await query.edit_message_text("Invalid callback data.")
        return
    action, run_id, token = parts

    if not ctx.cycle_manager:
        await query.edit_message_text("Cycle manager not configured.")
        return

    try:
        from owlmind.approval import resolve_approval

        approved = action == "approve"
        ok, msg = resolve_approval(ctx.cycle_manager.meta_store, run_id, token, approved=approved)
        status_icon = "\u2705" if approved else "\u274c"
        result_text = f"{status_icon} {'Approved' if approved else 'Denied'}: {run_id[:12]}\n{msg}"
        await query.edit_message_text(result_text)
    except Exception as exc:
        await query.edit_message_text(f"Error: {exc}")


async def handle_cc_callback(ctx: BotContext, update: Any, context: Any) -> None:
    """Handle [>> Delegate owlmind] / [X Skip] buttons from CC hook."""
    query = update.callback_query
    if not query or not query.data:
        return
    chat_id = query.message.chat.id if query.message else 0
    if not ctx.check_auth(chat_id):
        await query.answer("Unauthorized.")
        return
    await query.answer()

    if query.data == "cc_skip":
        await query.edit_message_text(
            "\u23ed \u0417\u0430\u0434\u0430\u0447\u0430 \u043f\u0440\u043e\u043f\u0443\u0449\u0435\u043d\u0430."
        )
        return

    if not query.data.startswith("cc_run:"):
        return

    task_id = query.data.split(":", 1)[1]
    tasks_dir = os.path.join(os.path.expanduser("~"), ".claude", "pending_tasks")
    task_file = os.path.join(tasks_dir, f"{task_id}.json")

    if not os.path.exists(task_file):
        await query.edit_message_text(
            "\u274c \u0417\u0430\u0434\u0430\u0447\u0430 \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d\u0430 (\u0438\u0441\u0442\u0451\u043a \u0441\u0440\u043e\u043a \u0445\u0440\u0430\u043d\u0435\u043d\u0438\u044f)."
        )
        return

    try:
        with open(task_file) as f:
            task_data = json.load(f)
        goal: str = task_data.get("prompt", "")
        workspace: str = task_data.get(
            "workspace",
            str(ctx.operator.default_workspace) if ctx.operator else ".",
        )
    except Exception as exc:
        await query.edit_message_text(
            f"\u274c \u041e\u0448\u0438\u0431\u043a\u0430 \u0447\u0442\u0435\u043d\u0438\u044f \u0437\u0430\u0434\u0430\u0447\u0438: {exc}"
        )
        return

    if not goal:
        await query.edit_message_text(
            "\u274c \u0417\u0430\u0434\u0430\u0447\u0430 \u043f\u0443\u0441\u0442\u0430\u044f."
        )
        return

    # Add to queue with high priority (5) so it runs next
    result = await api_post(
        ctx,
        "/api/v1/queue/items",
        body={"goal": goal, "workspace": workspace, "priority": 5},
    )
    if isinstance(result, dict) and "error" in result:
        await query.edit_message_text(
            f"\u274c \u041e\u0448\u0438\u0431\u043a\u0430 \u043e\u0447\u0435\u0440\u0435\u0434\u0438: {result['error']}"
        )
        return

    item_id = result.get("id", "?") if isinstance(result, dict) else "?"
    display = goal[:250] + "\u2026" if len(goal) > 250 else goal
    await query.edit_message_text(
        f"\u2705 *\u0417\u0430\u0434\u0430\u0447\u0430 \u043f\u0435\u0440\u0435\u0434\u0430\u043d\u0430 owlmind!*\n\n"
        f"\U0001f194 `{item_id}`\n"
        f"\U0001f4cb {display}\n\n"
        f"_\u0412\u044b\u043f\u043e\u043b\u043d\u0435\u043d\u0438\u0435 \u043d\u0430\u0447\u043d\u0451\u0442\u0441\u044f \u0430\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438._",
        parse_mode="Markdown",
    )

    # Clean up temp file
    with contextlib.suppress(Exception):
        os.unlink(task_file)


async def cmd_status(ctx: BotContext, update: Any, context: Any) -> None:
    if not update.message:
        return
    if not ctx.check_auth(update.message.chat_id):
        await update.message.reply_text("Unauthorized.")
        return

    args = context.args or []
    if not args:
        await update.message.reply_text("Usage: /status <run_id>")
        return

    run_id = args[0]

    # Check operator registry first
    if ctx.operator:
        info = ctx.operator.get_run(run_id)
        if info:
            text = (
                f"Run: {info.run_id}\n"
                f"Goal: {info.goal}\n"
                f"Workspace: {info.workspace}\n"
                f"Status: {info.status}\n"
                f"State: {info.final_state}"
            )
            if getattr(info, "cost_summary", ""):
                text += f"\nCost: {info.cost_summary}"
            await update.message.reply_text(text)
            return

    # Fall back to cycle manager
    if ctx.cycle_manager:
        try:
            meta = ctx.cycle_manager.status(run_id)
            text = (
                f"Run: {meta.run_id}\n"
                f"State: {meta.state.value}\n"
                f"Iteration: {meta.iteration}/{meta.limits.max_iterations}\n"
                f"Goal: {meta.goal}"
            )
            await update.message.reply_text(text)
            return
        except Exception as exc:
            await update.message.reply_text(f"Error: {exc}")
            return

    await update.message.reply_text("No operator or cycle manager configured.")


async def cmd_resume(ctx: BotContext, update: Any, context: Any) -> None:
    """Resume a paused or interrupted run by regenerating its current prompt."""
    if not update.message:
        return
    if not ctx.check_auth(update.message.chat_id):
        await update.message.reply_text("Unauthorized.")
        return

    if not ctx.cycle_manager:
        await update.message.reply_text("Cycle manager not configured.")
        return

    args = context.args or []
    if not args:
        await update.message.reply_text("Usage: /resume <run_id>")
        return

    run_id = args[0]
    try:
        meta = ctx.cycle_manager.resume_run(run_id)
        await update.message.reply_text(
            f"✅ Run `{run_id[:16]}` resumed.\n"
            f"State: {meta.state.value}\n"
            f"Iteration: {meta.iteration}",
            parse_mode="Markdown",
        )
    except Exception as exc:
        await update.message.reply_text(f"❌ Resume failed: {exc}")


async def cmd_hitl_approve(ctx: BotContext, update: Any, context: Any) -> None:
    """Approve a plan waiting for HITL approval: /hitl_approve <run_id>"""
    if not update.message:
        return
    if not ctx.check_auth(update.message.chat_id):
        await update.message.reply_text("Unauthorized.")
        return
    if not ctx.cycle_manager:
        await update.message.reply_text("Cycle manager not configured.")
        return
    args = context.args or []
    if not args:
        await update.message.reply_text("Usage: /hitl_approve <run_id>")
        return
    run_id = args[0]
    try:
        meta = ctx.cycle_manager.approve_plan(run_id)
        await update.message.reply_text(
            f"✅ Plan approved for `{run_id[:16]}`.\n"
            f"State: {meta.state.value} — Worker prompt ready.",
            parse_mode="Markdown",
        )
    except Exception as exc:
        await update.message.reply_text(f"❌ Approve failed: {exc}")


async def cmd_hitl_reject(ctx: BotContext, update: Any, context: Any) -> None:
    """Reject a plan and return to planning: /hitl_reject <run_id> [feedback]"""
    if not update.message:
        return
    if not ctx.check_auth(update.message.chat_id):
        await update.message.reply_text("Unauthorized.")
        return
    if not ctx.cycle_manager:
        await update.message.reply_text("Cycle manager not configured.")
        return
    args = context.args or []
    if not args:
        await update.message.reply_text("Usage: /hitl_reject <run_id> [feedback text]")
        return
    run_id = args[0]
    feedback = " ".join(args[1:]) if len(args) > 1 else ""
    try:
        meta = ctx.cycle_manager.reject_plan(run_id, feedback=feedback)
        await update.message.reply_text(
            f"❌ Plan rejected for `{run_id[:16]}`.\n"
            f"State: {meta.state.value} — Planner will retry.",
            parse_mode="Markdown",
        )
    except Exception as exc:
        await update.message.reply_text(f"❌ Reject failed: {exc}")


async def handle_hitl_callback(ctx: BotContext, update: Any, context: Any) -> None:
    """Handle [✅ Одобрить план] / [❌ Отклонить план] inline buttons."""
    query = update.callback_query
    if not query or not query.data:
        return
    chat_id = query.message.chat.id if query.message else 0
    if not ctx.check_auth(chat_id):
        await query.answer("Unauthorized.")
        return
    await query.answer()

    if not ctx.cycle_manager:
        await query.edit_message_text("Cycle manager not configured.")
        return

    parts = query.data.split(":", 1)
    action = parts[0]
    run_id = parts[1] if len(parts) > 1 else ""

    try:
        if action == "hitl_approve":
            meta = ctx.cycle_manager.approve_plan(run_id)
            await query.edit_message_text(
                f"✅ План одобрен для `{run_id[:16]}`.\n"
                f"State: {meta.state.value} — Worker prompt готов.",
                parse_mode="Markdown",
            )
        elif action == "hitl_reject":
            meta = ctx.cycle_manager.reject_plan(run_id)
            await query.edit_message_text(
                f"❌ План отклонён для `{run_id[:16]}`.\n"
                f"Planner получит задачу заново.",
                parse_mode="Markdown",
            )
        else:
            await query.edit_message_text("Unknown HITL action.")
    except Exception as exc:
        await query.edit_message_text(f"❌ Ошибка: {exc}")


async def cmd_runs(ctx: BotContext, update: Any, context: Any) -> None:
    if not update.message:
        return
    if not ctx.check_auth(update.message.chat_id):
        await update.message.reply_text("Unauthorized.")
        return

    if not ctx.operator:
        await update.message.reply_text("Operator service not configured.")
        return

    runs = ctx.operator.all_runs()
    if not runs:
        await update.message.reply_text("No tracked runs.")
        return

    lines = ["Tracked runs:"]
    for r in runs[-10:]:
        lines.append(f"  {r.run_id[:20]} [{r.status}] {r.goal[:40]}")
    await update.message.reply_text("\n".join(lines))


async def cmd_history(ctx: BotContext, update: Any, context: Any) -> None:
    """Show recent run history from disk with goal, state, iterations."""
    if not update.message:
        return
    if not ctx.check_auth(update.message.chat_id):
        await update.message.reply_text("Unauthorized.")
        return

    from pathlib import Path

    args = context.args or []
    n = 10
    with contextlib.suppress(ValueError, IndexError):
        n = int(args[0])

    runs_dir = Path.home() / "owlmind" / "runs"
    if not runs_dir.exists():
        await update.message.reply_text("No runs directory found.")
        return

    entries = []
    for run_dir in sorted(runs_dir.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True):
        if not run_dir.is_dir():
            continue
        meta: dict[str, Any] = {}
        for name in ("cycle_meta.json", "meta.json"):
            meta_path = run_dir / name
            if meta_path.exists():
                with contextlib.suppress(Exception):
                    meta = json.loads(meta_path.read_text())
                    break
        if not meta:
            continue
        entries.append(meta)
        if len(entries) >= n:
            break

    if not entries:
        await update.message.reply_text("No run history found.")
        return

    lines = [f"Last {len(entries)} runs:"]
    for m in entries:
        run_id = m.get("run_id", "?")[:16]
        goal = m.get("goal", "?")[:45]
        state = m.get("state", m.get("final_state", "?"))
        iteration = m.get("iteration", "?")
        status = m.get("status", "")
        tag = f"[{status}]" if status else ""
        lines.append(f"\n{run_id} {tag}\nGoal: {goal}\nState: {state}  iter:{iteration}")

    await update.message.reply_text("\n".join(lines))


async def cmd_merge(ctx: BotContext, update: Any, context: Any) -> None:
    """Merge the PR created by a owlmind run via `gh pr merge --squash`."""
    if not update.message:
        return
    if not ctx.check_auth(update.message.chat_id):
        await update.message.reply_text("Unauthorized.")
        return

    args = context.args or []
    if not args:
        await update.message.reply_text("Usage: /merge <run_id>")
        return

    import asyncio
    import subprocess

    run_id = args[0]
    branch = f"owlmind/run-{run_id[:12]}"

    workspace = os.path.expanduser("~/owlmind")
    if ctx.operator:
        info = ctx.operator.get_run(run_id)
        if info and info.workspace:
            workspace = info.workspace

    await update.message.reply_text(f"Merging PR for branch `{branch}`...")

    loop = asyncio.get_running_loop()

    def _do_merge() -> tuple[bool, str, str]:
        result = subprocess.run(
            ["/opt/homebrew/bin/gh", "pr", "merge", branch, "--squash", "--delete-branch"],
            cwd=workspace,
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            # Pull latest to get the squash commit, then show stat
            subprocess.run(["git", "pull", "--ff-only"], cwd=workspace, capture_output=True)
            stat = subprocess.run(
                ["git", "show", "--stat", "HEAD"],
                cwd=workspace,
                capture_output=True,
                text=True,
            )
            return True, result.stdout.strip() or "Merged successfully.", stat.stdout.strip()
        return False, result.stderr.strip() or "gh pr merge failed.", ""

    ok, msg, diff_stat = await loop.run_in_executor(None, _do_merge)
    if ok:
        text = f"✅ {msg}\nBranch `{branch}` deleted."
        if diff_stat:
            lines = diff_stat.splitlines()
            short = "\n".join(lines[:20])
            if len(lines) > 20:
                short += f"\n… (+{len(lines) - 20} lines)"
            text += f"\n\n```\n{short}\n```"
        text += "\n\nПерезапускаю бота..."
        await update.message.reply_text(text, parse_mode="Markdown")

        def _restart_bot() -> None:
            plist = os.path.expanduser("~/Library/LaunchAgents/com.owlmind.bot.plist")
            subprocess.run(["launchctl", "unload", plist], capture_output=True)
            import time
            time.sleep(3)
            subprocess.run(["launchctl", "load", plist], capture_output=True)

        loop.run_in_executor(None, _restart_bot)
    else:
        await update.message.reply_text(f"❌ Merge failed:\n{msg}")


# ---------------------------------------------------------------------------
# /goals — preset goal menu
# ---------------------------------------------------------------------------

_PRESET_GOALS = [
    ("🧪 Smoke tests", "Run all smoke tests and fix any failures"),
    ("📝 Docstrings", "Add missing docstrings to public functions in src/owlmind/"),
    ("🔍 Ruff fix", "Fix all ruff linting errors in src/owlmind/"),
    ("📊 Coverage", "Improve test coverage for the most untested modules"),
    ("🔧 Self-improve", "Review src/owlmind/ and suggest one concrete improvement, then implement it"),
    ("📦 Deps audit", "Check pyproject.toml for outdated or unused dependencies"),
]


async def cmd_goals(ctx: BotContext, update: Any, context: Any) -> None:
    """Show preset goal menu with inline keyboard."""
    if not update.message:
        return
    if not ctx.check_auth(update.message.chat_id):
        await update.message.reply_text("Unauthorized.")
        return

    try:
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup

        rows = [
            [InlineKeyboardButton(label, callback_data=f"quick_goal:{goal[:200]}")]
            for label, goal in _PRESET_GOALS
        ]
        markup = InlineKeyboardMarkup(rows)
        await update.message.reply_text("Выбери задачу для запуска:", reply_markup=markup)
    except Exception as exc:
        await update.message.reply_text(f"Error: {exc}")


# ---------------------------------------------------------------------------
# /schedule — ночной авто-цикл по расписанию
# ---------------------------------------------------------------------------


async def cmd_schedule(ctx: BotContext, update: Any, context: Any) -> None:
    """Set or clear a nightly scheduled goal.

    /schedule set HH:MM <goal>   — run goal daily at HH:MM
    /schedule clear              — remove scheduled goal
    /schedule status             — show current schedule
    """
    if not update.message:
        return
    if not ctx.check_auth(update.message.chat_id):
        await update.message.reply_text("Unauthorized.")
        return

    args = context.args or []
    sub = args[0].lower() if args else "status"

    if sub == "status":
        if _SCHEDULE_FILE.exists():
            with contextlib.suppress(Exception):
                data = json.loads(_SCHEDULE_FILE.read_text())
                await update.message.reply_text(
                    f"📅 Scheduled goal:\n"
                    f"Time: {data.get('time', '?')}\n"
                    f"Goal: {data.get('goal', '?')}"
                )
                return
        await update.message.reply_text("No schedule set. Use /schedule set HH:MM <goal>")
        return

    if sub == "clear":
        with contextlib.suppress(Exception):
            _SCHEDULE_FILE.unlink()
        # Remove existing scheduled job
        if context.job_queue:
            for job in context.job_queue.get_jobs_by_name("owlmind_nightly"):
                job.schedule_removal()
        await update.message.reply_text("✅ Schedule cleared.")
        return

    if sub == "set":
        if len(args) < 3:
            await update.message.reply_text("Usage: /schedule set HH:MM <goal>")
            return
        time_str = args[1]
        goal = " ".join(args[2:])
        try:
            import datetime
            h, m = map(int, time_str.split(":"))
            run_time = datetime.time(h, m, tzinfo=datetime.UTC)
        except Exception:
            await update.message.reply_text("Invalid time format. Use HH:MM (UTC), e.g. 01:00")
            return

        chat_id = update.message.chat_id
        data = {"time": time_str, "goal": goal, "chat_id": chat_id}
        _SCHEDULE_FILE.parent.mkdir(parents=True, exist_ok=True)
        _SCHEDULE_FILE.write_text(json.dumps(data, ensure_ascii=False))

        # Register daily job
        if context.job_queue:
            from functools import partial

            # Remove old job if any
            for job in context.job_queue.get_jobs_by_name("owlmind_nightly"):
                job.schedule_removal()

            context.job_queue.run_daily(
                partial(job_scheduled_run, ctx),
                time=run_time,
                name="owlmind_nightly",
                data={"goal": goal, "chat_id": chat_id},
            )

        await update.message.reply_text(
            f"✅ Scheduled!\nTime: {time_str} UTC\nGoal: {goal}"
        )
        return

    await update.message.reply_text("Usage: /schedule [set HH:MM <goal>|clear|status]")


async def job_scheduled_run(ctx: BotContext, context: Any) -> None:
    """Background job: run the scheduled nightly autopilot goal."""
    data = getattr(context.job, "data", None) if context.job else None
    if not isinstance(data, dict):
        # Try loading from file
        if not _SCHEDULE_FILE.exists():
            return
        with contextlib.suppress(Exception):
            data = json.loads(_SCHEDULE_FILE.read_text())
    if not data or not ctx.operator:
        return

    goal: str = data.get("goal", "")
    chat_id: int = data.get("chat_id", 0)
    if not goal:
        return

    workspace = str(ctx.operator.default_workspace)
    if chat_id:
        with contextlib.suppress(Exception):
            await context.bot.send_message(
                chat_id=chat_id,
                text=f"🌙 Запуск ночного цикла...\nGoal: {goal}",
            )

    started = time.time()
    try:
        info = await ctx.operator.start_autopilot_async(
            goal=goal,
            workspace=workspace,
            use_llm="both",
            use_worker="claude_cli",
            auto_approve=True,
        )
        elapsed = time.time() - started
        mins, secs = divmod(int(elapsed), 60)
        iters = getattr(info, "iterations", "?")
        state = info.final_state or info.status
        icon = "✅" if state in ("DONE", "done") else "❌"
        text = (
            f"{icon} Ночной цикл завершён.\n"
            f"Run: `{info.run_id}`\n"
            f"State: {state}  |  Iter: {iters}  |  Time: {mins}m {secs}s"
        )
        if chat_id:
            with contextlib.suppress(Exception):
                await context.bot.send_message(chat_id=chat_id, text=text, parse_mode="Markdown")
    except Exception as exc:
        if chat_id:
            with contextlib.suppress(Exception):
                await context.bot.send_message(chat_id=chat_id, text=f"❌ Ночной цикл упал: {exc}")


# ---------------------------------------------------------------------------
# Callback: inline кнопки [Merge PR] и [Ещё раз] после DONE
# ---------------------------------------------------------------------------


async def handle_run_action_callback(ctx: BotContext, update: Any, context: Any) -> None:
    """Handle [Merge PR] and [Ещё раз] inline buttons after autopilot DONE."""
    query = update.callback_query
    if not query or not query.data:
        return
    chat_id = query.message.chat.id if query.message else 0
    if not ctx.check_auth(chat_id):
        await query.answer("Unauthorized.")
        return
    await query.answer()

    if query.data.startswith("merge_run:"):
        run_id = query.data.split(":", 1)[1]
        branch = f"owlmind/run-{run_id}"
        workspace = os.path.expanduser("~/owlmind")
        await query.edit_message_text(
            query.message.text + f"\n\n⏳ Merging `{branch}`...",
            parse_mode="Markdown",
        )

        def _do_merge() -> tuple[bool, str]:
            subprocess.run(
                ["/opt/homebrew/bin/gh", "pr", "merge", branch, "--squash", "--delete-branch"],
                cwd=workspace,
                capture_output=True,
                text=True,
            )
            subprocess.run(["git", "pull", "--ff-only"], cwd=workspace, capture_output=True)
            stat = subprocess.run(
                ["git", "show", "--stat", "HEAD"],
                cwd=workspace, capture_output=True, text=True,
            )
            return True, stat.stdout.strip()

        loop = asyncio.get_running_loop()
        ok, stat = await loop.run_in_executor(None, _do_merge)
        suffix = f"\n\n✅ Merged `{branch}`!"
        if stat:
            lines = stat.splitlines()
            suffix += "\n```\n" + "\n".join(lines[:15]) + "\n```"
        with contextlib.suppress(Exception):
            await query.edit_message_text(
                query.message.text + suffix, parse_mode="Markdown"
            )

        def _restart() -> None:
            plist = os.path.expanduser("~/Library/LaunchAgents/com.owlmind.bot.plist")
            subprocess.run(["launchctl", "unload", plist], capture_output=True)
            time.sleep(3)
            subprocess.run(["launchctl", "load", plist], capture_output=True)

        loop.run_in_executor(None, _restart)

    elif query.data.startswith("repeat_goal:") or query.data.startswith("quick_goal:"):
        goal = query.data.split(":", 1)[1]
        is_repeat = query.data.startswith("repeat_goal:")
        if not ctx.operator:
            await query.edit_message_text("Operator not configured.")
            return
        workspace = str(ctx.operator.default_workspace)
        label = "🔁 Повторяю" if is_repeat else "🚀 Запускаю"
        with contextlib.suppress(Exception):
            if is_repeat:
                await query.edit_message_text(
                    query.message.text + f"\n\n{label}: {goal[:80]}..."
                )
            else:
                await query.edit_message_text(f"⏳ {label}: {goal[:80]}...")
        try:
            started = time.time()
            info = await ctx.operator.start_autopilot_async(
                goal=goal,
                workspace=workspace,
                use_llm="both",
                use_worker="claude_cli",
                auto_approve=True,
            )
            elapsed = time.time() - started
            mins, secs = divmod(int(elapsed), 60)
            state = info.final_state or info.status
            icon = "✅" if state in ("DONE", "done") else "❌"
            verb = "Повтор" if is_repeat else "Готово"

            # After done — show inline buttons again
            markup = None
            if state in ("DONE", "done"):
                try:
                    from telegram import InlineKeyboardButton, InlineKeyboardMarkup
                    run_short = info.run_id[:12]
                    markup = InlineKeyboardMarkup([[
                        InlineKeyboardButton("🔀 Merge PR", callback_data=f"merge_run:{run_short}"),
                        InlineKeyboardButton("🔁 Ещё раз", callback_data=f"repeat_goal:{goal[:200]}"),
                    ]])
                except Exception:
                    pass

            with contextlib.suppress(Exception):
                await context.bot.send_message(
                    chat_id=chat_id,
                    text=f"{icon} {verb} завершён.\nRun: `{info.run_id}`\nState: {state}  |  {mins}m {secs}s",
                    parse_mode="Markdown",
                    reply_markup=markup,
                )
        except Exception as exc:
            with contextlib.suppress(Exception):
                await context.bot.send_message(chat_id=chat_id, text=f"❌ Ошибка: {exc}")


# ---------------------------------------------------------------------------
# /ping — быстрая проверка бота
# ---------------------------------------------------------------------------

_BOT_START_TIME = time.time()


async def cmd_ping(ctx: BotContext, update: Any, context: Any) -> None:
    """Quick bot health check with uptime and active runs."""
    if not update.message:
        return
    if not ctx.check_auth(update.message.chat_id):
        await update.message.reply_text("Unauthorized.")
        return

    uptime_secs = int(time.time() - _BOT_START_TIME)
    hours, rem = divmod(uptime_secs, 3600)
    mins, secs = divmod(rem, 60)
    uptime_str = f"{hours}h {mins}m {secs}s" if hours else f"{mins}m {secs}s"

    active = ctx.operator.active_runs() if ctx.operator else []
    total = len(ctx.operator.all_runs()) if ctx.operator else 0

    sched_info = ""
    if _SCHEDULE_FILE.exists():
        with contextlib.suppress(Exception):
            data = json.loads(_SCHEDULE_FILE.read_text())
            sched_info = f"\n📅 Schedule: {data.get('time', '?')} UTC"

    lines = [
        "🤖 OwlMind бот жив!",
        f"⏱ Uptime: {uptime_str}",
        f"🔄 Active runs: {len(active)}",
        f"📊 Total runs: {total}",
    ]
    if active:
        lines.append("Running:")
        for r in active[:3]:
            lines.append(f"  `{r.run_id[:12]}` — {(r.goal or '')[:40]}")
    if sched_info:
        lines.append(sched_info)

    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


async def cmd_parallel_start(ctx: BotContext, update: Any, context: Any) -> None:
    """Run multiple goals in parallel: /parallel_start goal1 | goal2 | goal3

    Or provide a single complex goal and OwlMind will split it automatically.
    """
    if not update.message:
        return
    chat_id = update.message.chat_id
    if not ctx.check_auth(chat_id):
        await update.message.reply_text("Unauthorized.")
        return

    args = context.args or []
    raw = " ".join(args).strip()
    if not raw:
        await update.message.reply_text(
            "Usage: /parallel_start <goal1> | <goal2> | ...\n"
            "Or: /parallel_start <single complex goal> — OwlMind will split it"
        )
        return

    workspace, _ = parse_workspace_from_args(args, ctx.default_workspace)

    # Split on "|" if present (explicit multi-goal); otherwise use LLM to decompose.
    if "|" in raw:
        goals = [g.strip() for g in raw.split("|") if g.strip()]
    else:
        await update.message.reply_text(
            f"🔍 Decomposing goal with LLM:\n  {raw}"
        )
        driver = _make_split_driver()
        goals = split_goal(raw, driver)
        if len(goals) == 1 and goals[0] == raw:
            await update.message.reply_text(
                "ℹ️ Goal not decomposed (single task or no LLM available); running as-is."
            )

    if not goals:
        await update.message.reply_text("No goals found.")
        return

    if len(goals) > 5:
        await update.message.reply_text("Max 5 parallel goals at once.")
        return

    goal_list = "\n".join(f"  {i+1}. {g}" for i, g in enumerate(goals))
    await update.message.reply_text(
        f"🚀 Starting {len(goals)} parallel run(s):\n{goal_list}\n\nWorkspace: {workspace}"
    )

    operator = ctx.operator
    if operator is None:
        await update.message.reply_text("❌ Operator not configured.")
        return

    loop = asyncio.get_event_loop()
    bot_app = ctx.app
    _last_event: dict[int, float] = {}
    notifier = make_event_notifier(bot_app, chat_id, _last_event, cooldown=15.0)

    def _run_parallel() -> None:
        try:
            results = operator.run_parallel(
                goals,
                workspace,
                max_workers=3,
                on_event=notifier,
            )
            lines = [f"✅ Parallel run complete ({len(results)} tasks):"]
            for r in results:
                icon = "✅" if r.status == "done" else "❌"
                cost = f" | 💰 {r.cost_summary}" if r.cost_summary else ""
                pr = f"\n   🔗 {r.pr_url}" if r.pr_url else ""
                lines.append(f"{icon} {r.goal[:60]}{cost}{pr}")
            msg = "\n".join(lines)
        except Exception as exc:
            msg = f"❌ Parallel run failed: {exc}"
            logger.error("cmd_parallel_start error: %s", exc, exc_info=True)

        asyncio.run_coroutine_threadsafe(
            bot_app.bot.send_message(chat_id=chat_id, text=msg),
            loop,
        )

    thread = threading.Thread(target=_run_parallel, daemon=True)
    thread.start()
