"""Background jobs and miscellaneous handlers — /watch, /queue, screen monitor, etc."""

from __future__ import annotations

import contextlib
import logging
from typing import Any

from owlmind.telegram.api_client import api_delete, api_get, api_post
from owlmind.telegram.context import BotContext

logger = logging.getLogger(__name__)


async def job_screen_monitor(ctx: BotContext, context: Any) -> None:
    """Auto-send screenshot if there's an active run."""
    notify_id = getattr(context.job, "data", None) if context.job else None
    if notify_id is None:
        return
    runs_r = await api_get(ctx, "/api/v1/runs?status=running")
    if not isinstance(runs_r, dict) or not runs_r.get("runs"):
        return
    import subprocess
    import tempfile

    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
        tmp_path = f.name
    try:
        result = subprocess.run(
            ["screencapture", "-x", "-t", "png", tmp_path],
            capture_output=True,
            timeout=10,
        )
        if result.returncode == 0:
            with open(tmp_path, "rb") as img:
                await context.bot.send_photo(chat_id=notify_id, photo=img)
    except Exception:
        logger.debug("Screen monitor screenshot failed", exc_info=True)
    finally:
        import contextlib as _contextlib
        import os as _os

        with _contextlib.suppress(OSError):
            _os.unlink(tmp_path)


async def job_watch_run(ctx: BotContext, context: Any) -> None:
    """Poll a watched run and send latest log line to Telegram."""
    data = getattr(context.job, "data", None) if context.job else None
    if not isinstance(data, dict):
        return
    run_id: str = data.get("run_id", "")
    notify_id: int = data.get("chat_id", 0)
    if not run_id or not notify_id:
        return
    result = await api_get(ctx, f"/api/v1/runs/{run_id}/log?lines=1")
    if isinstance(result, dict) and "error" not in result:
        log_lines = result.get("lines", [])
        if log_lines:
            last = log_lines[-1] if isinstance(log_lines[-1], str) else str(log_lines[-1])
            with contextlib.suppress(Exception):
                await context.bot.send_message(
                    chat_id=notify_id, text=f"\U0001f441 [{run_id[:8]}] {last[:200]}"
                )
    # Stop job if run is done
    detail = await api_get(ctx, f"/api/v1/runs/{run_id}")
    if isinstance(detail, dict):
        state = detail.get("state", "")
        if state in ("DONE", "FAILED", "CANCELLED", "HARD_FAIL"):
            if context.job:
                context.job.schedule_removal()
            chat_runs = ctx.watched_runs.get(notify_id, set())
            chat_runs.discard(run_id)


async def cmd_watch(ctx: BotContext, update: Any, context: Any) -> None:
    if not update.message:
        return
    chat_id = update.message.chat_id
    if ctx.allowed and chat_id not in ctx.allowed:
        await update.message.reply_text("Unauthorized.")
        return
    args = context.args or []
    if not args:
        watched = ctx.watched_runs.get(chat_id, set())
        if watched:
            await update.message.reply_text(f"Watching: {', '.join(sorted(watched))}")
        else:
            await update.message.reply_text("Not watching any runs. Use /watch <run_id>")
        return
    run_id = args[0]
    if run_id == "stop":
        ctx.watched_runs.pop(chat_id, None)
        await update.message.reply_text("Stopped watching all runs.")
        return
    ctx.watched_runs.setdefault(chat_id, set()).add(run_id)
    if context.job_queue:
        from functools import partial

        context.job_queue.run_repeating(
            partial(job_watch_run, ctx),
            interval=30,
            first=5,
            data={"chat_id": chat_id, "run_id": run_id},
            name=f"watch_{run_id}",
        )
    await update.message.reply_text(f"Watching run '{run_id}'. You'll get live updates every 30s.")


async def cmd_queue(ctx: BotContext, update: Any, context: Any) -> None:
    if not update.message:
        return
    chat_id = update.message.chat_id
    if ctx.allowed and chat_id not in ctx.allowed:
        await update.message.reply_text("Unauthorized.")
        return
    args = context.args or []
    sub = args[0].lower() if args else "list"
    if sub == "list":
        result = await api_get(ctx, "/api/v1/queue/items")
        if isinstance(result, dict) and "error" in result:
            await update.message.reply_text(f"Queue error: {result['error']}")
            return
        items = result if isinstance(result, list) else result.get("items", [])
        if not items:
            await update.message.reply_text("Queue is empty.")
            return
        lines = [f"Queue ({len(items)} items):"]
        for item in items[:10]:
            lines.append(
                f"  [{item.get('status', '?')}] {item.get('id', '?')[:12]}"
                f" \u2014 {item.get('goal', '')[:50]}"
            )
        await update.message.reply_text("\n".join(lines))
    elif sub == "add":
        raw_args = args[1:]
        # Parse optional --priority N flag
        priority = 0
        filtered: list[str] = []
        i = 0
        while i < len(raw_args):
            if raw_args[i] == "--priority" and i + 1 < len(raw_args):
                try:
                    priority = int(raw_args[i + 1])
                except ValueError:
                    await update.message.reply_text(
                        "Usage: /queue add <goal> [--priority N]"
                    )
                    return
                i += 2
            else:
                filtered.append(raw_args[i])
                i += 1
        goal = " ".join(filtered)
        if not goal:
            await update.message.reply_text("Usage: /queue add <goal> [--priority N]")
            return
        workspace = ctx.operator.default_workspace if ctx.operator else "."
        result = await api_post(
            ctx,
            "/api/v1/queue/items",
            body={"goal": goal, "workspace": str(workspace), "priority": priority},
        )
        if isinstance(result, dict) and "error" in result:
            await update.message.reply_text(f"Error: {result['error']}")
        else:
            item_id = result.get("id", "?") if isinstance(result, dict) else "?"
            await update.message.reply_text(
                f"Task queued: {item_id}\nGoal: {goal[:80]}\nPriority: {priority}"
            )
    elif sub == "cancel":
        item_id = args[1] if len(args) > 1 else ""
        if not item_id:
            await update.message.reply_text("Usage: /queue cancel <item_id>")
            return
        result = await api_delete(ctx, f"/api/v1/queue/items/{item_id}")
        if isinstance(result, dict) and "error" in result:
            await update.message.reply_text(f"Error: {result['error']}")
        else:
            await update.message.reply_text(f"Item {item_id[:12]} cancelled.")
    elif sub == "details":
        item_id = args[1] if len(args) > 1 else ""
        if not item_id:
            await update.message.reply_text("Usage: /queue details <item_id>")
            return
        result = await api_get(ctx, f"/api/v1/queue/items/{item_id}")
        if isinstance(result, dict) and "error" in result:
            await update.message.reply_text(f"Error: {result['error']}")
        else:
            lines = ["Queue item details:"]
            for k, v in result.items() if isinstance(result, dict) else {}.items():
                lines.append(f"  {k}: {str(v)[:80]}")
            await update.message.reply_text("\n".join(lines))
    else:
        await update.message.reply_text(
            "Usage: /queue [list|add <goal> [--priority N]|cancel <id>|details <id>]"
        )


async def job_process_queue(ctx: BotContext, context: Any) -> None:
    """Background job: pick next PENDING task from queue and start it."""
    if ctx.operator is None:
        return
    result = await api_get(ctx, "/api/v1/queue?status=PENDING")
    if not isinstance(result, dict) or not result.get("items"):
        return
    items = result["items"]
    next_item = items[0]
    item_id = next_item.get("id")
    goal = next_item.get("goal", "")
    workspace = next_item.get("workspace", str(ctx.operator.default_workspace))
    if not item_id or not goal:
        return
    try:
        await ctx.operator.start_autopilot_async(goal=goal, workspace=workspace)
    except Exception as exc:
        logger.warning("Queue job failed to start task %s: %s", item_id, exc)


async def group_mention(ctx: BotContext, update: Any, context: Any) -> None:
    """Handle @mention in group chats — starts autopilot with the message text as goal."""
    if not update.message or not update.message.text:
        return
    chat_id = update.message.chat_id
    if ctx.allowed and chat_id not in ctx.allowed:
        await update.message.reply_text("Unauthorized.")
        return
    if ctx.operator is None:
        await update.message.reply_text("Operator not configured.")
        return
    raw_text = update.message.text
    bot_username = context.bot.username if context.bot else ""
    mention = f"@{bot_username}"
    goal = raw_text.replace(mention, "").strip()
    if not goal:
        await update.message.reply_text("Please provide a goal after mentioning me.")
        return
    if not ctx.operator.is_workspace_allowed(str(ctx.operator.default_workspace)):
        await update.message.reply_text("Default workspace not allowed.")
        return
    workspace = str(ctx.operator.default_workspace)
    await update.message.reply_text(f"Starting autopilot...\nGoal: {goal}\nWorkspace: {workspace}")
    try:
        from owlmind.telegram.helpers import make_event_notifier

        info = await ctx.operator.start_autopilot_async(
            goal=goal,
            workspace=workspace,
            on_event=make_event_notifier(
                ctx.app, chat_id, ctx.last_event, ctx.event_cooldown, ctx.verbose_chats
            ),
        )
        text = (
            f"Autopilot finished.\n"
            f"Run: {info.run_id}\n"
            f"Status: {info.status}\n"
            f"State: {info.final_state}\n"
            f"Reason: {info.stop_reason}"
        )
        await update.message.reply_text(text)
    except Exception as exc:
        await update.message.reply_text(f"Error: {exc}")
