"""Settings/monitoring command handlers — /model, /think, /memory, /verbose, etc."""

from __future__ import annotations

import contextlib
from typing import Any

from owlmind.telegram.api_client import api_get, api_post
from owlmind.telegram.context import BotContext


async def cmd_digest(ctx: BotContext, update: Any, context: Any) -> None:
    if update.effective_chat is None or update.message is None:
        return
    if not ctx.check_auth(update.effective_chat.id):
        await update.message.reply_text("Unauthorized.")
        return

    from owlmind.monitor import build_digest, format_digest_markdown

    args = context.args or []
    days = 1
    if args:
        with contextlib.suppress(ValueError):
            days = int(args[0])

    from pathlib import Path

    report = build_digest(
        ledger_dir=Path("ledger"),
        runs_dir=Path("runs"),
        sessions_dir=Path("sessions"),
        days=days,
    )
    md = format_digest_markdown(report)

    # Append cost summary from RunMemory
    try:
        from owlmind.graph.run_memory import RunMemory

        mem = RunMemory()
        records = mem.recent(n=days * 10)
        run_count = len(records)
        total_tokens = sum(r.total_tokens for r in records)
        total_usd = sum(r.total_usd for r in records)
        cost_block = (
            f"\n📊 Usage digest ({days} days):\n"
            f"  Runs: {run_count}\n"
            f"  Tokens: {total_tokens:,}\n"
            f"  Cost: ~${total_usd:.2f}"
        )
        md = md + cost_block
    except Exception:
        pass

    # Truncate for Telegram (4096 char limit)
    if len(md) > 4000:
        md = md[:4000] + "\n..."
    await update.message.reply_text(md)


async def cmd_stuck(ctx: BotContext, update: Any, context: Any) -> None:
    if update.effective_chat is None or update.message is None:
        return
    if not ctx.check_auth(update.effective_chat.id):
        await update.message.reply_text("Unauthorized.")
        return

    from owlmind.monitor import detect_stuck_sessions, format_stuck_text

    args = context.args or []
    minutes = 30
    if args:
        with contextlib.suppress(ValueError):
            minutes = int(args[0])

    from pathlib import Path

    stuck = detect_stuck_sessions(Path("sessions"), threshold_minutes=minutes)
    text = format_stuck_text(stuck)
    await update.message.reply_text(text)


async def cmd_skillpack(ctx: BotContext, update: Any, context: Any) -> None:
    """List or view skill packs."""
    if not update.message:
        return
    chat_id = update.effective_chat.id if update.effective_chat else 0
    if not ctx.check_auth(chat_id):
        await update.message.reply_text("Unauthorized.")
        return
    args = context.args or []
    if not args:
        result = await api_get(ctx, "/api/v1/skills/packs")
        if isinstance(result, dict) and "error" in result:
            await update.message.reply_text(f"Skills error: {result['error']}")
            return
        packs = result if isinstance(result, list) else result.get("packs", [])
        if not packs:
            await update.message.reply_text("No skill packs found.")
            return
        lines = ["\U0001f4e6 Skill Packs:"]
        for p in packs:
            pid = p.get("id", "?")
            name = p.get("name", pid)
            desc = p.get("description", "")[:60]
            lines.append(f"\u2022 {pid} \u2014 {name}: {desc}")
        await update.message.reply_text("\n".join(lines))
    else:
        pack_id = args[0]
        result = await api_get(ctx, f"/api/v1/skills/packs/{pack_id}")
        if isinstance(result, dict) and "error" in result:
            await update.message.reply_text(f"Pack not found: {result['error']}")
            return
        name = result.get("name", pack_id) if isinstance(result, dict) else str(result)
        desc = result.get("description", "") if isinstance(result, dict) else ""
        workflows = result.get("workflows", []) if isinstance(result, dict) else []
        text = f"\U0001f4e6 {name}\n{desc}\nWorkflows: {len(workflows)}"
        await update.message.reply_text(text)


async def cmd_model(ctx: BotContext, update: Any, context: Any) -> None:
    if not update.message:
        return
    if not ctx.check_auth(update.message.chat_id):
        await update.message.reply_text("Unauthorized.")
        return
    args = context.args or []
    if not args:
        profile = str(ctx.state["llm_profile"])
        info = ctx.llm_profiles[profile]
        await update.message.reply_text(
            f"Current model profile: {profile}\n  Name: {info['name']}\n  Model: {info['model']}"
        )
        return
    sub = args[0].lower()
    if sub == "list":
        lines = ["Available LLM profiles:"]
        for key, info in ctx.llm_profiles.items():
            marker = " \u25c0" if key == str(ctx.state["llm_profile"]) else ""
            lines.append(f"  {key}: {info['name']} ({info['model']}){marker}")
        await update.message.reply_text("\n".join(lines))
    elif sub in ctx.llm_profiles:
        ctx.state["llm_profile"] = sub
        ctx.save_bot_state()
        if ctx.operator is not None:
            ctx.operator.update_model_config(sub)
        await update.message.reply_text(
            f"Switched to '{sub}' profile ({ctx.llm_profiles[sub]['name']})."
        )
    else:
        await update.message.reply_text(
            f"Unknown profile '{sub}'. Available: {', '.join(ctx.llm_profiles)}"
        )


async def cmd_think(ctx: BotContext, update: Any, context: Any) -> None:
    if not update.message:
        return
    if not ctx.check_auth(update.message.chat_id):
        await update.message.reply_text("Unauthorized.")
        return
    args = context.args or []
    if not args:
        level = str(ctx.state["thinking_level"])
        tokens = ctx.think_levels[level]
        await update.message.reply_text(f"Thinking level: {level} ({tokens} tokens)")
        return
    level = args[0].lower()
    if level not in ctx.think_levels:
        await update.message.reply_text(
            f"Unknown level '{level}'. Available: {', '.join(ctx.think_levels)}"
        )
        return
    ctx.state["thinking_level"] = level
    ctx.save_bot_state()
    tokens = ctx.think_levels[level]
    await update.message.reply_text(f"Thinking set to '{level}' ({tokens} tokens).")


async def cmd_memory(ctx: BotContext, update: Any, context: Any) -> None:
    if not update.message:
        return
    chat_id = update.message.chat_id
    if ctx.allowed and chat_id not in ctx.allowed:
        await update.message.reply_text("Unauthorized.")
        return
    args = context.args or []
    sub = args[0].lower() if args else "stats"
    if sub == "stats":
        result = await api_get(ctx, "/api/v1/memory/stats")
        if isinstance(result, dict) and "error" in result:
            await update.message.reply_text(f"Memory API error: {result['error']}")
            return
        docs = result.get("documents", 0)
        chunks = result.get("chunks", 0)
        signals = result.get("signals", 0)
        await update.message.reply_text(
            f"Memory stats:\n  Documents: {docs}\n  Chunks: {chunks}\n  Signals: {signals}"
        )
    elif sub == "search":
        query = " ".join(args[1:])
        if not query:
            await update.message.reply_text("Usage: /memory search <query>")
            return
        result = await api_post(ctx, "/api/v1/memory/query", body={"query": query, "top_k": 5})
        if "error" in result:
            await update.message.reply_text(f"Search error: {result['error']}")
            return
        results = result.get("results", [])
        if not results:
            await update.message.reply_text("No results found.")
            return
        lines = [f"Search results for '{query}':"]
        for i, r in enumerate(results[:5], 1):
            snippet = str(r.get("content", ""))[:100]
            lines.append(f"{i}. {snippet}")
        await update.message.reply_text("\n".join(lines))
    elif sub == "signals":
        result = await api_get(ctx, "/api/v1/memory/signals?limit=5")
        if isinstance(result, dict) and "error" in result:
            await update.message.reply_text(f"Signals error: {result['error']}")
            return
        # API may return a list directly or a dict with "signals" key
        signals = (
            result
            if isinstance(result, list)
            else (result.get("signals", []) if isinstance(result, dict) else [])
        )
        if not signals:
            await update.message.reply_text("No signals found.")
            return
        lines = ["Recent signals:"]
        for s in signals[:5]:
            content = str(s.get("content", s) if isinstance(s, dict) else s)[:80]
            lines.append(f"\u2022 {content}")
        await update.message.reply_text("\n".join(lines))
    elif sub == "add" and len(args) > 2 and args[1].lower() == "lesson":
        lesson = " ".join(args[2:])
        result = await api_post(
            ctx,
            "/api/v1/memory/signal",
            body={"signal_type": "lesson", "content": lesson},
        )
        if isinstance(result, dict) and "error" in result:
            await update.message.reply_text(f"Error: {result['error']}")
        else:
            signal_id = result.get("signal_id", "") if isinstance(result, dict) else ""
            id_part = f" (id={signal_id})" if signal_id else ""
            await update.message.reply_text(f"Lesson added{id_part}: {lesson[:80]}")
    else:
        await update.message.reply_text(
            "Usage: /memory [stats|search <q>|signals|add lesson <text>]"
        )


async def cmd_verbose(ctx: BotContext, update: Any, context: Any) -> None:
    if not update.message:
        return
    chat_id = update.message.chat_id
    if ctx.allowed and chat_id not in ctx.allowed:
        await update.message.reply_text("Unauthorized.")
        return
    args = context.args or []
    mode = args[0].lower() if args else ""
    if mode == "on":
        ctx.verbose_chats.add(chat_id)
        await update.message.reply_text("Verbose mode ON \u2014 all events will be reported.")
    elif mode == "off" or not mode:
        ctx.verbose_chats.discard(chat_id)
        await update.message.reply_text("Verbose mode OFF \u2014 only key events reported.")
    else:
        await update.message.reply_text("Usage: /verbose [on|off]")


async def heartbeat_callback(ctx: BotContext, context: Any) -> None:
    """Background heartbeat job callback."""
    notify_id = getattr(context.job, "data", None) if context.job else None
    if notify_id is None:
        return
    result = await api_get(ctx, "/api/v1/health")
    status = result.get("status", "unknown") if isinstance(result, dict) else "unknown"
    queue_r = await api_get(ctx, "/api/v1/queue")
    pending = len(queue_r.get("items", [])) if isinstance(queue_r, dict) else "?"
    await context.bot.send_message(
        chat_id=notify_id,
        text=f"Heartbeat: health={status} | queue pending={pending}",
    )


async def cmd_heartbeat(ctx: BotContext, update: Any, context: Any) -> None:
    if not update.message:
        return
    chat_id = update.message.chat_id
    if ctx.allowed and chat_id not in ctx.allowed:
        await update.message.reply_text("Unauthorized.")
        return
    args = context.args or []
    mode = args[0].lower() if args else ""
    # Use context.job_queue (injectable in tests and available in PTB handlers)
    jq = getattr(context, "job_queue", None)
    if mode == "off" or not mode:
        for j in ctx.heartbeat_job:
            j.schedule_removal()
        ctx.heartbeat_job.clear()
        await update.message.reply_text("Heartbeat disabled.")
    elif mode == "on" or mode.endswith("h"):
        if ctx.heartbeat_job:
            for j in ctx.heartbeat_job:
                j.schedule_removal()
            ctx.heartbeat_job.clear()
        try:
            hours = float(mode.rstrip("h")) if mode.endswith("h") else 8.0
        except ValueError:
            hours = 8.0
        interval_secs = hours * 3600
        if jq is None:
            await update.message.reply_text("Job queue not available.")
            return
        from functools import partial

        job = jq.run_repeating(
            partial(heartbeat_callback, ctx),
            interval=interval_secs,
            first=interval_secs,
            data=chat_id,
            name="owlmind_heartbeat",
        )
        ctx.heartbeat_job.append(job)
        hours_str = f"{int(hours)}h" if hours == int(hours) else f"{hours}h"
        await update.message.reply_text(f"Heartbeat enabled every {hours_str}.")
    else:
        state = "ON" if ctx.heartbeat_job else "OFF"
        await update.message.reply_text(f"Heartbeat: {state}\nUse /heartbeat on|off|<N>h")


async def cmd_screenshot(ctx: BotContext, update: Any, context: Any) -> None:
    if not update.message:
        return
    chat_id = update.message.chat_id
    if ctx.allowed and chat_id not in ctx.allowed:
        await update.message.reply_text("Unauthorized.")
        return
    import subprocess
    import tempfile

    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
        tmp_path = f.name
    try:
        result = subprocess.run(
            ["screencapture", "-x", "-t", "png", tmp_path],
            capture_output=True,
            timeout=10,
        )
        if result.returncode != 0:
            await update.message.reply_text("Screenshot failed.")
            return
        with open(tmp_path, "rb") as img:
            await context.bot.send_photo(chat_id=chat_id, photo=img)
    except FileNotFoundError:
        await update.message.reply_text("screencapture not found (macOS only).")
    except Exception as exc:
        await update.message.reply_text(f"Screenshot error: {exc}")
    finally:
        import os as _os

        _os.unlink(tmp_path)
