"""Telegram /graph command — runs GraphRunner pipeline from chat.

Usage in Telegram:
  /graph Add tests for all new files
  /graph --workspace /path/to/project Fix all mypy errors
  /watch_start <goal> [--interval N] [--workspace PATH] — start autonomous scheduler
  /watch_stop — stop the autonomous scheduler for this chat
  /watch_status — show scheduler status
"""

from __future__ import annotations

import contextlib
import logging
from typing import Any

logger = logging.getLogger(__name__)

# Module-level scheduler registry keyed by chat_id
_schedulers: dict[int, Any] = {}


async def cmd_graph(ctx: Any, update: Any, context: Any) -> None:
    """/graph <goal> — run Architect→Coder→Tester→Reviewer pipeline."""
    msg = update.message
    if msg is None:
        return

    if not ctx.check_auth(msg.chat_id):
        await msg.reply_text("⛔ Not authorized.")
        return

    # Parse args
    raw = (context.args or [])
    args = list(raw)

    # Extract optional --workspace flag
    workspace = getattr(ctx, "workspace", ".")
    if "--workspace" in args:
        idx = args.index("--workspace")
        if idx + 1 < len(args):
            workspace = args[idx + 1]
            del args[idx : idx + 2]

    goal = " ".join(args).strip()
    if not goal:
        await msg.reply_text(
            "Usage: /graph <goal> [--workspace PATH]\n\n"
            "Example: /graph fix all type errors"
        )
        return

    await msg.reply_text(f"🤖 Running graph pipeline...\nGoal: {goal[:200]}")

    import asyncio
    from concurrent.futures import ThreadPoolExecutor

    def _run() -> str:
        from owlmind.graph.runner import GraphRunner, _build_llm_client

        if _build_llm_client() is None:
            return "❌ No LLM configured. Set OPENAI_API_KEY or ANTHROPIC_API_KEY."

        runner = GraphRunner()
        state = runner.run(goal, workspace=workspace, max_iterations=3)
        verdict = state.final_verdict or "unknown"
        review = (state.review or "")[:500]
        cost = state.cost
        cost_line = f"Cost: {cost.total_tokens:,} tokens | ~${cost.total_usd:.4f}"
        return f"Verdict: {verdict}\n\n{review}\n\n{cost_line}".strip()

    try:
        loop = asyncio.get_event_loop()
        with ThreadPoolExecutor(max_workers=1) as pool:
            result = await asyncio.wait_for(
                loop.run_in_executor(pool, _run),
                timeout=300.0,
            )
        icon = "✅" if "APPROVED" in result else "⚠️"
        text = f"{icon} Graph done:\n\n{result}"
        for attempt in range(5):
            try:
                await msg.reply_text(text)
                break
            except Exception as send_err:
                if attempt < 4:
                    await asyncio.sleep(5 * (attempt + 1))
                else:
                    logger.error("Graph handler: failed to send after 5 attempts: %s", send_err)
    except TimeoutError:
        logger.warning("Graph handler: task timed out after 300s")
        for _ in range(3):
            try:
                await msg.reply_text("⏱ Graph timed out after 5 minutes. Try a simpler goal.")
                break
            except Exception:
                await asyncio.sleep(5)
    except Exception as e:
        logger.error("Graph handler error: %s", e)
        for _ in range(3):
            try:
                await msg.reply_text(f"❌ Graph error: {e}")
                break
            except Exception:
                await asyncio.sleep(5)


async def cmd_graph_parallel(ctx: Any, update: Any, context: Any) -> None:
    """/graph_parallel <goal1> | <goal2> | ... — run multiple goals in parallel."""
    msg = update.message
    if msg is None:
        return

    if not ctx.check_auth(msg.chat_id):
        await msg.reply_text("⛔ Not authorized.")
        return

    raw = " ".join(context.args or []).strip()
    if not raw:
        await msg.reply_text(
            "Usage: /graph_parallel <goal1> | <goal2> | ...\n\n"
            "Example: /graph_parallel fix lint | add type hints | write docstrings"
        )
        return

    # Split goals by pipe separator
    goals = [g.strip() for g in raw.split("|") if g.strip()]
    if not goals:
        await msg.reply_text("No goals found. Separate goals with '|'.")
        return

    workspace = getattr(ctx, "workspace", ".")

    await msg.reply_text(
        f"🤖 Running {len(goals)} parallel graph tasks...\n"
        + "\n".join(f"  {i+1}. {g[:100]}" for i, g in enumerate(goals))
    )

    try:
        from owlmind.graph.parallel_runner import ParallelGraphRunner, ParallelTask
        from owlmind.graph.runner import _build_llm_client

        if _build_llm_client() is None:
            await msg.reply_text("❌ No LLM configured. Set OPENAI_API_KEY.")
            return

        tasks = [ParallelTask(goal=g, workspace=workspace) for g in goals]
        runner = ParallelGraphRunner(max_workers=3)
        results = await runner.run_all(tasks)

        lines = [f"Parallel results ({len(results)} tasks):"]
        for r in results:
            icon = "✅" if r.verdict == "APPROVED" else ("❌" if r.verdict == "ERROR" else "⚠️")
            detail = (r.error or r.summary or "")[:80]
            lines.append(f"{icon} [{r.verdict}] {r.task.goal[:60]}")
            if detail:
                lines.append(f"   {detail}")

        approved = sum(1 for r in results if r.verdict == "APPROVED")
        lines.append(f"\n{approved}/{len(results)} approved")
        text = "\n".join(lines)
        # Retry send up to 5 times on NetworkError
        import asyncio as _asyncio
        for attempt in range(5):
            try:
                await msg.reply_text(text)
                break
            except Exception as send_err:
                if attempt < 4:
                    await _asyncio.sleep(5 * (attempt + 1))
                else:
                    logger.error("graph_parallel: failed to send after 5 attempts: %s", send_err)
    except Exception as e:
        logger.error("graph_parallel error: %s", e, exc_info=True)
        for _ in range(3):
            try:
                await msg.reply_text(f"❌ Parallel graph error: {e}")
                break
            except Exception:
                import asyncio as _asyncio
                await _asyncio.sleep(5)


async def cmd_watch_start(ctx: Any, update: Any, context: Any) -> None:
    """/watch_start <goal> [--interval N] [--workspace PATH] — start autonomous scheduler."""
    msg = update.message
    if msg is None:
        return

    if not ctx.check_auth(msg.chat_id):
        await msg.reply_text("⛔ Not authorized.")
        return

    # Parse args
    args = list(context.args or [])

    # Extract optional --interval flag (default 300)
    interval = 300
    if "--interval" in args:
        idx = args.index("--interval")
        if idx + 1 < len(args):
            with contextlib.suppress(ValueError):
                interval = int(args[idx + 1])
            del args[idx : idx + 2]

    # Extract optional --workspace flag
    workspace = getattr(ctx, "workspace", ".")
    if "--workspace" in args:
        idx = args.index("--workspace")
        if idx + 1 < len(args):
            workspace = args[idx + 1]
            del args[idx : idx + 2]

    goal = " ".join(args).strip()
    if not goal:
        await msg.reply_text(
            "Usage: /watch_start <goal> [--interval N] [--workspace PATH]\n\n"
            "Example: /watch_start fix all lint errors --interval 600"
        )
        return

    chat_id = msg.chat_id

    # Stop existing scheduler for this chat if any
    if chat_id in _schedulers:
        with contextlib.suppress(Exception):
            _schedulers[chat_id].stop()

    # Lazily import to avoid circular imports
    from owlmind.autonomous import AutonomousScheduler

    scheduler = AutonomousScheduler(workspace=workspace)
    scheduler.add_goal(goal, source="telegram")
    scheduler.start(interval=float(interval))
    _schedulers[chat_id] = scheduler

    await msg.reply_text(
        f"🔄 Scheduler started. Goal: {goal[:200]} | Interval: {interval}s"
    )


async def cmd_watch_stop(ctx: Any, update: Any, context: Any) -> None:
    """/watch_stop — stop the autonomous scheduler for this chat."""
    msg = update.message
    if msg is None:
        return

    if not ctx.check_auth(msg.chat_id):
        await msg.reply_text("⛔ Not authorized.")
        return

    chat_id = msg.chat_id
    scheduler = _schedulers.get(chat_id)
    if scheduler is None:
        await msg.reply_text("No scheduler running.")
        return

    try:
        scheduler.stop()
    except Exception as e:
        logger.error("watch_stop error: %s", e)
    del _schedulers[chat_id]
    await msg.reply_text("⏹ Scheduler stopped.")


async def cmd_watch_status(ctx: Any, update: Any, context: Any) -> None:
    """/watch_status — show scheduler status."""
    msg = update.message
    if msg is None:
        return

    if not ctx.check_auth(msg.chat_id):
        await msg.reply_text("⛔ Not authorized.")
        return

    chat_id = msg.chat_id
    scheduler = _schedulers.get(chat_id)
    if scheduler is None:
        await msg.reply_text("No scheduler running for this chat.")
        return

    try:
        st = scheduler.status()
    except Exception as e:
        logger.error("watch_status error: %s", e)
        await msg.reply_text(f"❌ Status error: {e}")
        return

    running = "yes" if st.get("running") else "no"
    queue_size = st.get("queue_size", 0)
    history_count = st.get("history_count", 0)
    github_watchers = st.get("github_watchers", 0)
    file_watchers = st.get("file_watchers", 0)
    recent = st.get("recent", [])

    lines = [
        "Scheduler status:",
        f"  Running: {running}",
        f"  Queue size: {queue_size}",
        f"  History: {history_count} run(s)",
        f"  GitHub watchers: {github_watchers}",
        f"  File watchers: {file_watchers}",
    ]
    if recent:
        lines.append("Recent runs:")
        for r in recent:
            verdict = r.get("verdict") or "in progress"
            error = r.get("error", "")
            goal_text = r.get("goal", "")[:60]
            line = f"  [{verdict}] {goal_text}"
            if error:
                line += f" (err: {error[:60]})"
            lines.append(line)

    await msg.reply_text("\n".join(lines))
