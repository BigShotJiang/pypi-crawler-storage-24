"""DAG utilities — cycle detection, topological sort, ready-node selection.

Goals form a directed acyclic graph via `depends_on` links.
This module validates the graph and computes execution layers.
"""

from __future__ import annotations

from collections import defaultdict, deque


class CycleError(ValueError):
    """Raised when the goals graph contains a cycle."""


def validate_dag(
    goals: list[dict[str, object]],
) -> None:
    """Validate that goals form a valid DAG.

    Raises CycleError if a cycle is detected.
    Raises ValueError if a dependency references a non-existent goal.

    Each goal dict must have ``id`` (str) and ``depends_on`` (list[str]).
    """
    ids = {str(g["id"]) for g in goals}
    adj: dict[str, list[str]] = defaultdict(list)

    for g in goals:
        gid = str(g["id"])
        deps = g.get("depends_on") or []
        if not isinstance(deps, list):
            deps = [deps]
        for dep in deps:
            dep_s = str(dep)
            if dep_s not in ids:
                msg = f"Goal {gid} depends on unknown goal {dep_s}"
                raise ValueError(msg)
            adj[dep_s].append(gid)

    # Kahn's algorithm for cycle detection
    in_degree: dict[str, int] = {str(g["id"]): 0 for g in goals}
    for g in goals:
        deps = g.get("depends_on") or []
        if not isinstance(deps, list):
            deps = [deps]
        for _dep in deps:
            in_degree[str(g["id"])] += 1

    queue = deque(gid for gid, deg in in_degree.items() if deg == 0)
    visited = 0

    while queue:
        node = queue.popleft()
        visited += 1
        for child in adj[node]:
            in_degree[child] -= 1
            if in_degree[child] == 0:
                queue.append(child)

    if visited != len(ids):
        # Find cycle participants
        cycle_nodes = [gid for gid, deg in in_degree.items() if deg > 0]
        msg = f"Cycle detected among goals: {', '.join(sorted(cycle_nodes))}"
        raise CycleError(msg)


def topological_layers(
    goals: list[dict[str, object]],
) -> list[list[str]]:
    """Compute execution layers via topological sort (Kahn's algorithm).

    Returns a list of layers. Goals in the same layer have no dependencies
    on each other and can be executed in parallel.

    Assumes the DAG is valid (call ``validate_dag`` first).
    """
    adj: dict[str, list[str]] = defaultdict(list)
    in_degree: dict[str, int] = {str(g["id"]): 0 for g in goals}

    for g in goals:
        gid = str(g["id"])
        deps = g.get("depends_on") or []
        if not isinstance(deps, list):
            deps = [deps]
        for dep in deps:
            dep_s = str(dep)
            adj[dep_s].append(gid)
            in_degree[gid] += 1

    layers: list[list[str]] = []
    current = [gid for gid, deg in in_degree.items() if deg == 0]

    while current:
        # Sort for deterministic ordering
        current.sort()
        layers.append(current)

        next_layer: list[str] = []
        for node in current:
            for child in adj[node]:
                in_degree[child] -= 1
                if in_degree[child] == 0:
                    next_layer.append(child)
        current = next_layer

    return layers


def ready_goals(
    goals: list[dict[str, object]],
    statuses: dict[str, str],
    *,
    allow_skipped_deps: bool = False,
) -> list[str]:
    """Return goal IDs whose dependencies are all satisfied.

    A goal is "ready" when:
    - Its status is "pending" (not started).
    - All goals in its ``depends_on`` have status "done"
      (or "skipped" if ``allow_skipped_deps`` is True).

    Args:
        goals: List of goal dicts with ``id`` and ``depends_on``.
        statuses: Mapping of goal_id → current status string.
        allow_skipped_deps: If True, treat "skipped" deps as satisfied.
    """
    ok_statuses = {"done"}
    if allow_skipped_deps:
        ok_statuses.add("skipped")

    result: list[str] = []
    for g in goals:
        gid = str(g["id"])
        if statuses.get(gid, "pending") != "pending":
            continue

        deps = g.get("depends_on") or []
        if not isinstance(deps, list):
            deps = [deps]

        all_satisfied = all(statuses.get(str(d), "pending") in ok_statuses for d in deps)
        if all_satisfied:
            result.append(gid)

    return sorted(result)


def format_dag_summary(
    goals: list[dict[str, object]],
    statuses: dict[str, str],
) -> str:
    """Format a human-readable DAG summary.

    Shows layers, statuses, and dependencies.
    """
    layers = topological_layers(goals)
    goal_map = {str(g["id"]): g for g in goals}

    lines = ["## DAG Summary", ""]
    for i, layer in enumerate(layers):
        lines.append(f"**Layer {i}** (parallel):")
        for gid in layer:
            g = goal_map.get(gid, {})
            status = statuses.get(gid, "pending")
            deps = g.get("depends_on") or []
            if not isinstance(deps, list):
                deps = [deps]
            dep_str = f" ← {', '.join(str(d) for d in deps)}" if deps else ""
            goal_text = str(g.get("goal", ""))[:50]
            lines.append(f"  - {gid}: [{status}] {goal_text}{dep_str}")
        lines.append("")

    ready = ready_goals(goals, statuses)
    if ready:
        lines.append(f"**Ready to run:** {', '.join(ready)}")

    return "\n".join(lines)
