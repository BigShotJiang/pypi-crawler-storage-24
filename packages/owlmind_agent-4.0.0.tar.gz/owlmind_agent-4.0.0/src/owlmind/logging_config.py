"""OWLMIND structured logging -- JSON + text formatters with secret redaction."""

from __future__ import annotations

import json
import logging
import re
import sys
from typing import Any

# Secret patterns to redact from log messages
_SECRET_PATTERN = re.compile(
    r"(sk-[a-zA-Z0-9]{10,}|"  # OpenAI keys
    r"sk-ant-[a-zA-Z0-9]{10,}|"  # Anthropic keys
    r"\d+:[A-Za-z0-9_-]{30,})",  # Telegram bot tokens
)


def _redact_secrets(text: str) -> str:
    """Replace known secret patterns with ***."""
    return _SECRET_PATTERN.sub("***", text)


class JsonFormatter(logging.Formatter):
    """Emit log records as single-line JSON."""

    def format(self, record: logging.LogRecord) -> str:
        entry: dict[str, Any] = {
            "ts": self.formatTime(record, self.datefmt),
            "level": record.levelname,
            "logger": record.name,
            "msg": _redact_secrets(record.getMessage()),
        }
        if record.exc_info and record.exc_info[0] is not None:
            entry["exc"] = _redact_secrets(self.formatException(record.exc_info))
        # Include extra fields
        for key in ("run_id", "stage", "provider", "event"):
            val = getattr(record, key, None)
            if val is not None:
                entry[key] = val
        return json.dumps(entry, default=str)


class RedactedFormatter(logging.Formatter):
    """Text formatter that redacts secrets."""

    def format(self, record: logging.LogRecord) -> str:
        result = super().format(record)
        return _redact_secrets(result)


def setup_logging(
    *,
    level: str = "WARNING",
    json_format: bool = False,
    stream: Any = None,
) -> None:
    """Configure root logger for owlmind.

    Args:
        level: Log level (DEBUG, INFO, WARNING, ERROR).
        json_format: Use JSON formatter if True, text otherwise.
        stream: Output stream (default: sys.stderr).
    """
    root = logging.getLogger("owlmind")
    root.setLevel(getattr(logging, level.upper(), logging.WARNING))

    # Remove existing handlers
    root.handlers.clear()

    handler = logging.StreamHandler(stream or sys.stderr)
    if json_format:
        handler.setFormatter(JsonFormatter())
    else:
        handler.setFormatter(
            RedactedFormatter(
                fmt="%(asctime)s %(levelname)-8s [%(name)s] %(message)s",
                datefmt="%H:%M:%S",
            )
        )
    root.addHandler(handler)
