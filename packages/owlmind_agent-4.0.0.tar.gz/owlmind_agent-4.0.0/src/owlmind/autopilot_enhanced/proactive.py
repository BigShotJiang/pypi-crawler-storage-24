"""Proactive workspace analysis and improvement suggestions."""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


class ProactiveAnalyzer:
    """Uses a vision provider (if available) to suggest improvements."""

    def __init__(self, workspace: str) -> None:
        self._workspace = workspace
        self._provider: Any = None
        try:
            from owlmind.vision.providers import build_vision_provider

            self._provider = build_vision_provider()
        except Exception:
            logger.debug("ProactiveAnalyzer: vision provider unavailable")

    def analyze_workspace(self) -> list[dict[str, str]]:
        """Scan workspace and return improvement suggestions."""
        suggestions: list[dict[str, str]] = []

        # Check for common issues
        ws = Path(self._workspace)

        # Missing __init__.py in Python packages
        for py_dir in ws.rglob("*.py"):
            parent = py_dir.parent
            init = parent / "__init__.py"
            if not init.exists() and parent != ws and not any(
                p in str(parent) for p in ["__pycache__", ".git", "node_modules", ".venv"]
            ):
                suggestions.append({
                    "category": "structure",
                    "message": f"Missing __init__.py in {parent.relative_to(ws)}",
                })
                break  # only report once

        # Large files
        for f in ws.rglob("*"):
            if f.is_file() and f.stat().st_size > 5_000_000 and not any(p in str(f) for p in [".git", "node_modules", ".venv"]):
                    suggestions.append({
                        "category": "size",
                        "message": f"Large file ({f.stat().st_size // 1_000_000}MB): {f.relative_to(ws)}",
                    })

        # TODO/FIXME count
        todo_count = 0
        for py_file in ws.rglob("*.py"):
            if any(p in str(py_file) for p in ["__pycache__", ".git", ".venv"]):
                continue
            try:
                text = py_file.read_text(errors="ignore")
                todo_count += len(re.findall(r"\b(TODO|FIXME|HACK|XXX)\b", text))
            except Exception:
                continue
        if todo_count > 10:
            suggestions.append({
                "category": "debt",
                "message": f"{todo_count} TODO/FIXME/HACK comments found across the project",
            })

        # Use vision provider for deeper analysis if available
        if self._provider and suggestions:
            try:
                summary = "\n".join(f"- [{s['category']}] {s['message']}" for s in suggestions)
                prompt = (
                    f"Given these observations about a Python project, prioritize them "
                    f"and suggest the most impactful improvement:\n{summary}"
                )
                advice = self._provider.think(prompt)
                if advice:
                    suggestions.insert(0, {
                        "category": "ai_advice",
                        "message": advice,
                    })
            except Exception:
                logger.debug("ProactiveAnalyzer: vision provider call failed", exc_info=True)

        return suggestions
