"""Lightweight process monitoring."""

from __future__ import annotations

import os
import subprocess
from typing import Any


class ProcessMonitor:
    """Lightweight monitor for running processes matching configured commands."""

    def __init__(self, commands: list[str]) -> None:
        self._commands = commands
        self._known_pids: set[int] = set()

    def check(self) -> list[dict[str, Any]]:
        """Return events about new/disappeared processes."""
        events: list[dict[str, Any]] = []
        current_pids: set[int] = set()

        try:
            result = subprocess.run(
                ["ps", "aux"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            for line in result.stdout.splitlines()[1:]:
                parts = line.split(None, 10)
                if len(parts) < 11:
                    continue
                pid_str, cmd_full = parts[1], parts[10]
                cmd_base = os.path.basename(cmd_full.split()[0]) if cmd_full else ""
                if any(c in cmd_base or c in cmd_full for c in self._commands):
                    try:
                        pid = int(pid_str)
                        current_pids.add(pid)
                    except ValueError:
                        continue
        except Exception:
            return events

        # New processes
        new_pids = current_pids - self._known_pids
        gone_pids = self._known_pids - current_pids

        if new_pids:
            events.append({
                "type": "new_processes",
                "pids": sorted(new_pids),
                "count": len(new_pids),
            })

        if gone_pids:
            events.append({
                "type": "ended_processes",
                "pids": sorted(gone_pids),
                "count": len(gone_pids),
            })

        self._known_pids = current_pids
        return events
