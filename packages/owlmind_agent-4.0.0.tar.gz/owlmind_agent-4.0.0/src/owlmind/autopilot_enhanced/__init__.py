"""Enhanced autopilot with proactive monitoring, file watching, and git awareness.

Extends the base AutoPilot with:
  - Filesystem watching (watchdog) — detect changes and trigger actions
  - Git change detection — suggest fixes for new diffs
  - Scheduled / recurring tasks
  - Process monitoring
  - Proactive improvement suggestions via vision providers

Usage::

    from owlmind.autopilot_enhanced import EnhancedAutoPilot, EnhancedConfig

    pilot = EnhancedAutoPilot(EnhancedConfig(
        workspace="/path/to/project",
        watch_paths=["/path/to/project/src"],
        enable_git_watch=True,
        enable_process_monitor=True,
    ))
    pilot.start()   # blocking; Ctrl-C to stop
"""

from .config import EnhancedConfig, ScheduledTask
from .fs_watcher import _WATCHDOG_AVAILABLE, Observer, _FSEventHandler
from .git_watcher import GitWatcher
from .pilot import EnhancedAutoPilot, run_enhanced
from .proactive import ProactiveAnalyzer
from .process_monitor import ProcessMonitor

__all__ = [
    "EnhancedAutoPilot",
    "EnhancedConfig",
    "GitWatcher",
    "Observer",
    "ProcessMonitor",
    "ProactiveAnalyzer",
    "ScheduledTask",
    "run_enhanced",
    "_FSEventHandler",
    "_WATCHDOG_AVAILABLE",
]
