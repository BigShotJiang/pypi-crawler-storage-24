"""Git change detection for the enhanced autopilot."""

from __future__ import annotations

import logging
import subprocess
from typing import Any

from .config import EnhancedConfig

logger = logging.getLogger(__name__)


class GitWatcher:
    """Polls a workspace for git changes and surfaces actionable information."""

    def __init__(self, workspace: str, config: EnhancedConfig) -> None:
        self._workspace = workspace
        self._config = config
        self._last_diff_hash: str = ""

    # ---- public API ----

    def check(self) -> list[dict[str, Any]]:
        """Return a list of change-events since last check.

        Each event is ``{"type": ..., "files": [...], "detail": ...}``.
        """
        events: list[dict[str, Any]] = []

        diff_output = self._git("diff", "--stat")
        if not diff_output.strip():
            self._last_diff_hash = ""
            return events

        diff_hash = str(hash(diff_output))
        if diff_hash == self._last_diff_hash:
            return events  # nothing new
        self._last_diff_hash = diff_hash

        # Uncommitted changes
        changed_files = self._changed_files()
        if changed_files:
            events.append({
                "type": "uncommitted_changes",
                "files": changed_files,
                "detail": diff_output.strip(),
            })

        # Untracked files
        untracked = self._git("ls-files", "--others", "--exclude-standard").strip().splitlines()
        if untracked:
            events.append({
                "type": "untracked_files",
                "files": untracked,
                "detail": f"{len(untracked)} untracked file(s)",
            })

        # Lint / type-check suggestion
        if self._config.git_auto_suggest and changed_files:
            py_files = [f for f in changed_files if f.endswith(".py")]
            if py_files:
                lint_result = self._run_lint(py_files)
                if lint_result:
                    events.append({
                        "type": "lint_issues",
                        "files": py_files,
                        "detail": lint_result,
                    })

        return events

    # ---- internal ----

    def _git(self, *args: str) -> str:
        try:
            result = subprocess.run(
                ["git", *args],
                cwd=self._workspace,
                capture_output=True,
                text=True,
                timeout=15,
            )
            return result.stdout
        except Exception as exc:
            logger.debug("git %s failed: %s", args, exc)
            return ""

    def _changed_files(self) -> list[str]:
        output = self._git("diff", "--name-only")
        staged = self._git("diff", "--name-only", "--cached")
        files = set(output.strip().splitlines()) | set(staged.strip().splitlines())
        return sorted(f for f in files if f)

    def _run_lint(self, files: list[str]) -> str:
        """Run a quick lint pass on changed Python files."""
        try:
            result = subprocess.run(
                ["python", "-m", "py_compile", *files],
                cwd=self._workspace,
                capture_output=True,
                text=True,
                timeout=30,
            )
            if result.returncode != 0:
                return result.stderr.strip()
        except Exception:
            pass

        # Try ruff if available
        try:
            result = subprocess.run(
                ["ruff", "check", "--no-fix", "--quiet", *files],
                cwd=self._workspace,
                capture_output=True,
                text=True,
                timeout=30,
            )
            if result.stdout.strip():
                return result.stdout.strip()
        except FileNotFoundError:
            pass
        except Exception:
            pass

        return ""
