"""Enhanced AutoPilot class and convenience runner."""

from __future__ import annotations

import asyncio
import logging
import os
import signal
import threading
import time
from pathlib import Path
from typing import Any

from .config import EnhancedConfig
from .fs_watcher import _WATCHDOG_AVAILABLE, Observer, _FSEventHandler
from .git_watcher import GitWatcher
from .proactive import ProactiveAnalyzer
from .process_monitor import ProcessMonitor

logger = logging.getLogger(__name__)


class EnhancedAutoPilot:
    """Autonomous autopilot with filesystem watching, git awareness, and scheduling.

    Wraps the base ``autopilot.run()`` loop and adds proactive monitoring layers.
    """

    def __init__(self, config: EnhancedConfig) -> None:
        self._config = config
        self._shutdown = False
        self._observer: Any = None  # watchdog Observer
        self._fs_events: list[tuple[str, str]] = []
        self._fs_lock = threading.Lock()

        # Sub-components
        self._git_watcher: GitWatcher | None = None
        if config.enable_git_watch:
            self._git_watcher = GitWatcher(config.workspace, config)

        self._process_monitor: ProcessMonitor | None = None
        if config.enable_process_monitor:
            self._process_monitor = ProcessMonitor(config.monitored_commands)

        self._proactive: ProactiveAnalyzer | None = None
        if config.enable_proactive:
            self._proactive = ProactiveAnalyzer(config.workspace)

    # ---- public API ----

    def start(self) -> None:
        """Start the enhanced autopilot (blocking). Ctrl-C to stop."""
        signal.signal(signal.SIGINT, self._handle_signal)
        signal.signal(signal.SIGTERM, self._handle_signal)

        self._emit("starting", {"workspace": self._config.workspace})
        logger.info("EnhancedAutoPilot starting (workspace=%s)", self._config.workspace)

        # Start filesystem watcher
        if self._config.watch_paths and _WATCHDOG_AVAILABLE:
            self._start_watcher()

        try:
            self._main_loop()
        finally:
            self._stop_watcher()
            self._emit("stopped", {})
            logger.info("EnhancedAutoPilot stopped")

    async def start_async(self) -> None:
        """Async variant of start() for integration with asyncio event loops."""
        self._emit("starting", {"workspace": self._config.workspace})
        logger.info("EnhancedAutoPilot starting async (workspace=%s)", self._config.workspace)

        if self._config.watch_paths and _WATCHDOG_AVAILABLE:
            self._start_watcher()

        try:
            await self._main_loop_async()
        finally:
            self._stop_watcher()
            self._emit("stopped", {})

    def stop(self) -> None:
        """Signal the autopilot to stop gracefully."""
        self._shutdown = True

    # ---- main loop ----

    def _main_loop(self) -> None:
        """Synchronous main loop."""
        last_git_check = 0.0
        last_process_check = 0.0
        last_proactive_check = 0.0
        last_schedule_check = 0.0

        while not self._shutdown:
            now = time.time()

            # 1. Process filesystem events
            self._process_fs_events()

            # 2. Git watch
            if self._git_watcher and now - last_git_check >= self._config.git_poll_interval:
                last_git_check = now
                self._check_git()

            # 3. Process monitor
            if self._process_monitor and now - last_process_check >= self._config.process_poll_interval:
                last_process_check = now
                self._check_processes()

            # 4. Scheduled tasks
            if self._config.scheduled_tasks and now - last_schedule_check >= 1.0:
                last_schedule_check = now
                self._run_scheduled_tasks(now)

            # 5. Proactive analysis
            if self._proactive and now - last_proactive_check >= self._config.proactive_interval:
                last_proactive_check = now
                self._run_proactive()

            time.sleep(1.0)

    async def _main_loop_async(self) -> None:
        """Async main loop."""
        last_git_check = 0.0
        last_process_check = 0.0
        last_proactive_check = 0.0
        last_schedule_check = 0.0

        while not self._shutdown:
            now = time.time()

            self._process_fs_events()

            if self._git_watcher and now - last_git_check >= self._config.git_poll_interval:
                last_git_check = now
                self._check_git()

            if self._process_monitor and now - last_process_check >= self._config.process_poll_interval:
                last_process_check = now
                self._check_processes()

            if self._config.scheduled_tasks and now - last_schedule_check >= 1.0:
                last_schedule_check = now
                self._run_scheduled_tasks(now)

            if self._proactive and now - last_proactive_check >= self._config.proactive_interval:
                last_proactive_check = now
                self._run_proactive()

            await asyncio.sleep(1.0)

    # ---- filesystem watching ----

    def _start_watcher(self) -> None:
        """Start watchdog Observer on configured paths."""
        if not _WATCHDOG_AVAILABLE:
            logger.warning("watchdog not installed — filesystem watching disabled")
            return

        handler = _FSEventHandler(
            patterns=self._config.watch_patterns,
            ignore=self._config.watch_ignore,
            debounce_sec=self._config.watch_debounce_sec,
            callback=self._on_fs_event,
        )

        self._observer = Observer()
        for path_str in self._config.watch_paths:
            p = Path(path_str).resolve()
            if p.is_dir():
                self._observer.schedule(handler, str(p), recursive=True)
                logger.info("Watching: %s", p)
            else:
                logger.warning("Watch path not a directory, skipping: %s", p)

        self._observer.daemon = True
        self._observer.start()
        self._emit("watcher_started", {"paths": self._config.watch_paths})

    def _stop_watcher(self) -> None:
        if self._observer is not None:
            self._observer.stop()
            self._observer.join(timeout=5)
            self._observer = None

    def _on_fs_event(self, event_type: str, src_path: str) -> None:
        """Called from watchdog thread — queue the event for the main loop."""
        with self._fs_lock:
            self._fs_events.append((event_type, src_path))

    def _process_fs_events(self) -> None:
        """Process queued filesystem events on the main thread."""
        with self._fs_lock:
            events = list(self._fs_events)
            self._fs_events.clear()

        if not events:
            return

        for event_type, src_path in events:
            self._emit("fs_change", {"event": event_type, "path": src_path})
            logger.info("FS change: %s %s", event_type, src_path)

            if self._config.on_suggestion:
                rel = os.path.relpath(src_path, self._config.workspace)
                self._config.on_suggestion(
                    "file_changed",
                    f"File {event_type}: {rel}",
                )

    # ---- git ----

    def _check_git(self) -> None:
        if self._git_watcher is None:
            return

        events = self._git_watcher.check()
        for ev in events:
            self._emit(f"git_{ev['type']}", ev)
            logger.info("Git: %s (%d files)", ev["type"], len(ev.get("files", [])))

            if self._config.on_suggestion and ev["type"] == "lint_issues":
                self._config.on_suggestion("lint", ev["detail"])
            elif self._config.on_suggestion and ev["type"] == "uncommitted_changes":
                self._config.on_suggestion(
                    "git",
                    f"{len(ev['files'])} uncommitted file(s) — consider committing",
                )

    # ---- processes ----

    def _check_processes(self) -> None:
        if self._process_monitor is None:
            return

        events = self._process_monitor.check()
        for ev in events:
            self._emit(f"process_{ev['type']}", ev)
            if ev["type"] == "ended_processes" and self._config.on_suggestion:
                self._config.on_suggestion(
                    "process",
                    f"{ev['count']} monitored process(es) ended",
                )

    # ---- scheduled tasks ----

    def _run_scheduled_tasks(self, now: float) -> None:
        for task in self._config.scheduled_tasks:
            if not task.enabled:
                continue
            if now - task.last_run < task.interval_seconds:
                continue

            task.last_run = now
            task.run_count += 1

            self._emit("scheduled_task", {"name": task.name, "goal": task.goal, "run": task.run_count})
            logger.info("Running scheduled task: %s (run #%d)", task.name, task.run_count)

            # Run the task via base autopilot
            try:
                from owlmind.autopilot import AutoPilotConfig
                from owlmind.autopilot import run as run_autopilot

                result = run_autopilot(AutoPilotConfig(
                    goal=task.goal,
                    workspace=self._config.workspace,
                    use_llm=self._config.use_llm,
                    use_worker=self._config.use_worker,
                    max_steps=self._config.max_steps,
                    auto_approve=self._config.auto_approve,
                    sandbox=self._config.sandbox,
                ))
                self._emit("scheduled_task_done", {
                    "name": task.name,
                    "run_id": result.run_id,
                    "state": result.final_state,
                })
            except Exception as exc:
                self._emit("scheduled_task_error", {"name": task.name, "error": str(exc)})
                logger.warning("Scheduled task %s failed: %s", task.name, exc)

    # ---- proactive ----

    def _run_proactive(self) -> None:
        if self._proactive is None:
            return

        suggestions = self._proactive.analyze_workspace()
        if suggestions:
            self._emit("proactive_suggestions", {"count": len(suggestions), "items": suggestions})
            for s in suggestions:
                if self._config.on_suggestion:
                    self._config.on_suggestion(s["category"], s["message"])

    # ---- helpers ----

    def _emit(self, name: str, data: dict[str, Any]) -> None:
        if self._config.on_event is not None:
            try:
                self._config.on_event(name, data)
            except Exception:
                logger.debug("on_event callback error for %s", name)

    def _handle_signal(self, signum: int, frame: Any) -> None:
        logger.info("Signal %d received — shutting down", signum)
        self._shutdown = True


# ---------------------------------------------------------------------------
# Convenience runner
# ---------------------------------------------------------------------------


def run_enhanced(config: EnhancedConfig) -> None:
    """Create and start an EnhancedAutoPilot (blocking)."""
    pilot = EnhancedAutoPilot(config)
    pilot.start()
