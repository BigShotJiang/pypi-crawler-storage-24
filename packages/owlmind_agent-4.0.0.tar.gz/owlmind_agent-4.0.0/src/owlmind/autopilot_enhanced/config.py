"""Configuration dataclasses for the enhanced autopilot."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any


@dataclass
class ScheduledTask:
    """A recurring task that the enhanced autopilot can run."""

    name: str
    goal: str
    interval_seconds: float = 300.0
    """How often to run this task (default: 5 minutes)."""
    enabled: bool = True
    last_run: float = 0.0
    run_count: int = 0


@dataclass
class EnhancedConfig:
    """Configuration for the enhanced autopilot."""

    workspace: str = "."

    # --- File watching ---
    watch_paths: list[str] = field(default_factory=list)
    watch_patterns: list[str] = field(
        default_factory=lambda: ["*.py", "*.js", "*.ts", "*.yaml", "*.yml", "*.json"]
    )
    watch_ignore: list[str] = field(
        default_factory=lambda: [
            "__pycache__",
            ".git",
            "node_modules",
            ".mypy_cache",
            "*.pyc",
            ".DS_Store",
        ]
    )
    watch_debounce_sec: float = 2.0
    """Minimum seconds between reacting to filesystem events."""

    # --- Git watching ---
    enable_git_watch: bool = False
    git_poll_interval: float = 30.0
    """How often to check for uncommitted changes."""
    git_auto_suggest: bool = True
    """Automatically suggest fixes for lint/type errors in changed files."""

    # --- Process monitoring ---
    enable_process_monitor: bool = False
    monitored_commands: list[str] = field(
        default_factory=lambda: ["python", "node", "npm", "pytest", "make"]
    )
    process_poll_interval: float = 10.0

    # --- Scheduled tasks ---
    scheduled_tasks: list[ScheduledTask] = field(default_factory=list)

    # --- Proactive suggestions ---
    enable_proactive: bool = False
    proactive_interval: float = 120.0
    """Seconds between proactive analysis passes."""

    # --- Autopilot base settings ---
    use_llm: str = "both"
    use_worker: str = "claude_cli"
    max_steps: int = 50
    auto_approve: bool = False
    sandbox: bool = False

    # --- Callbacks ---
    on_event: Callable[[str, dict[str, Any]], None] | None = None
    on_suggestion: Callable[[str, str], None] | None = None
    """Called with (category, message) when the autopilot has a suggestion."""
