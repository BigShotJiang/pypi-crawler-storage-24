"""Filesystem watching via watchdog (optional dependency)."""

from __future__ import annotations

import fnmatch
import logging
import os
import threading
import time
from collections.abc import Callable

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Optional imports
# ---------------------------------------------------------------------------

_WATCHDOG_AVAILABLE = False
try:
    from watchdog.events import FileSystemEvent, FileSystemEventHandler
    from watchdog.observers import Observer

    _WATCHDOG_AVAILABLE = True
except ImportError:
    # Stubs so the code below can define the handler class unconditionally
    class FileSystemEventHandler:  # type: ignore[no-redef]
        pass

    class FileSystemEvent:  # type: ignore[no-redef]
        src_path: str = ""
        event_type: str = ""

    Observer = None  # type: ignore[assignment,misc]


# ---------------------------------------------------------------------------
# Event handler
# ---------------------------------------------------------------------------


class _FSEventHandler(FileSystemEventHandler):
    """Debounced filesystem event handler that queues change notifications."""

    def __init__(
        self,
        patterns: list[str],
        ignore: list[str],
        debounce_sec: float,
        callback: Callable[[str, str], None],
    ) -> None:
        super().__init__()
        self._patterns = patterns
        self._ignore = ignore
        self._debounce = debounce_sec
        self._callback = callback
        self._last_event_time: float = 0.0
        self._lock = threading.Lock()

    def on_any_event(self, event: FileSystemEvent) -> None:  # type: ignore[override]
        src = getattr(event, "src_path", "")
        if not src:
            return

        # Ignore directories
        if getattr(event, "is_directory", False):
            return

        # Check ignore patterns
        basename = os.path.basename(src)
        for ig in self._ignore:
            if ig in src or fnmatch.fnmatch(basename, ig):
                return

        # Check match patterns
        matched = not self._patterns  # match all if no patterns
        for pat in self._patterns:
            if fnmatch.fnmatch(basename, pat):
                matched = True
                break
        if not matched:
            return

        # Debounce
        now = time.time()
        with self._lock:
            if now - self._last_event_time < self._debounce:
                return
            self._last_event_time = now

        event_type = getattr(event, "event_type", "unknown")
        try:
            self._callback(event_type, src)
        except Exception:
            logger.debug("FS event callback error for %s", src, exc_info=True)
