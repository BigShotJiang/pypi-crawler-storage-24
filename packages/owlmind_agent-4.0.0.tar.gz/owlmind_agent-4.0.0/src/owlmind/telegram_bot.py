"""Telegram Operator Bot — control + monitor AutoPilot/E2E/Sessions from Telegram.

Extended command set:
  /help             — Show available commands
  /auto_start       — Start autopilot run
  /auto_stop        — Stop a run
  /e2e_preflight    — Run preflight checks
  /e2e_smoke        — Run E2E smoke test
  /approve          — Approve pending approval
  /deny             — Deny pending approval
  /status           — Show run status
  /runs             — List tracked runs
  /session_start    — Start session from goals file
  /session_resume   — Resume a session
  /session_stop     — Stop a session
  /session_status   — Show session status
  /session_graph    — Show session DAG
  /session_export   — Export session as zip
  /session_rollback — Rollback a session goal
  /session_help     — Session commands help
  /model            — Switch LLM profile (fast/balanced/powerful)
  /think            — Set thinking depth (off/low/medium/high)
  /memory           — Access persistent memory
  /verbose          — Toggle verbose event reporting
  /heartbeat        — Enable/disable heartbeat check-ins
  /screenshot       — Capture current screen
  /watch            — Watch run events live
  /queue            — Manage task queue
  /graph            — Run graph pipeline (Architect→Coder→Tester→Reviewer)
  Voice messages    — Transcribed via Whisper and optionally run as goal

Requires: pip install 'owlmind[telegram]'
"""

from __future__ import annotations

import contextlib
import logging
import urllib.request  # noqa: F401 — re-exported for test patching (_tb.urllib.request.urlopen)
from functools import partial
from typing import Any

logger = logging.getLogger(__name__)

_PTB_AVAILABLE = False
try:
    from telegram import BotCommand
    from telegram.ext import (
        Application,
        CallbackQueryHandler,
        CommandHandler,
        MessageHandler,
        filters,
    )

    _PTB_AVAILABLE = True
except ImportError:
    pass


def is_telegram_available() -> bool:
    """Check if python-telegram-bot is installed."""
    return _PTB_AVAILABLE


def create_operator_bot(
    *,
    bot_token: str,
    allowed_chat_ids: list[int] | None = None,
    operator: Any = None,
    cycle_manager: Any = None,
) -> Any:
    """Create operator Telegram bot with extended commands.

    Returns Application or None if telegram is not available.
    """
    if not _PTB_AVAILABLE or not bot_token:
        return None

    app: Any = Application.builder().token(bot_token).build()

    # ── BotContext: shared state for all handlers ────────────────────────────
    from owlmind.telegram.context import make_bot_context

    ctx = make_bot_context(
        app=app,
        operator=operator,
        cycle_manager=cycle_manager,
        allowed_chat_ids=allowed_chat_ids,
    )

    # Alias — used in job registration below
    _allowed = ctx.allowed

    # ── Metrics helper ───────────────────────────────────────────────────────
    from owlmind.monitoring.metrics import track_telegram_command

    def _wrap_cmd(name: str, handler: Any) -> Any:
        """Wrap an async Telegram command handler with Prometheus metrics."""
        from functools import wraps

        @wraps(handler)
        async def _instrumented(*args: Any, **kwargs: Any) -> None:
            with track_telegram_command(name):
                await handler(*args, **kwargs)

        return _instrumented

    # ── Autopilot handlers (extracted to telegram/handlers_autopilot.py) ──────
    from owlmind.telegram.handlers_autopilot import (
        cmd_approve,
        cmd_auto_start,
        cmd_auto_stop,
        cmd_deny,
        cmd_e2e_preflight,
        cmd_e2e_smoke,
        cmd_goals,
        cmd_help,
        cmd_history,
        cmd_merge,
        cmd_parallel_start,
        cmd_ping,
        cmd_runs,
        cmd_schedule,
        cmd_status,
        handle_approval_callback,
        handle_cc_callback,
        handle_run_action_callback,
    )

    # ── Graph handler (extracted to telegram/handlers_graph.py) ──────────────
    from owlmind.telegram.handlers_graph import (
        cmd_graph,
        cmd_graph_parallel,
        cmd_watch_start,
        cmd_watch_status,
        cmd_watch_stop,
    )

    # ── Jobs/queue/group handlers (extracted to telegram/handlers_jobs.py) ───
    from owlmind.telegram.handlers_jobs import (
        cmd_queue,
        cmd_watch,
        group_mention,
        job_process_queue,
        job_screen_monitor,
    )

    # ── Session handlers (extracted to telegram/handlers_session.py) ─────────
    from owlmind.telegram.handlers_session import (
        cmd_session_export,
        cmd_session_graph,
        cmd_session_help,
        cmd_session_resume,
        cmd_session_rollback,
        cmd_session_start,
        cmd_session_status,
        cmd_session_stop,
    )

    # ── Settings handlers (extracted to telegram/handlers_settings.py) ───────
    from owlmind.telegram.handlers_settings import (
        cmd_digest,
        cmd_heartbeat,
        cmd_memory,
        cmd_model,
        cmd_screenshot,
        cmd_skillpack,
        cmd_stuck,
        cmd_think,
        cmd_verbose,
    )

    # ── Voice handler (extracted to telegram/handlers_voice.py) ──────────────
    from owlmind.telegram.handlers_voice import cmd_voice_mode, handle_voice_message

    # ------------------------------------------------------------------
    # Register handlers
    # ------------------------------------------------------------------

    # Autopilot handlers — partial binds ctx, _wrap_cmd adds Prometheus metrics
    app.add_handler(CommandHandler("help", partial(_wrap_cmd("help", cmd_help), ctx)))
    app.add_handler(CommandHandler("start", partial(_wrap_cmd("start", cmd_help), ctx)))
    app.add_handler(
        CommandHandler("auto_start", partial(_wrap_cmd("auto_start", cmd_auto_start), ctx))
    )
    app.add_handler(
        CommandHandler("auto_stop", partial(_wrap_cmd("auto_stop", cmd_auto_stop), ctx))
    )
    app.add_handler(
        CommandHandler("e2e_preflight", partial(_wrap_cmd("e2e_preflight", cmd_e2e_preflight), ctx))
    )
    app.add_handler(
        CommandHandler("e2e_smoke", partial(_wrap_cmd("e2e_smoke", cmd_e2e_smoke), ctx))
    )
    app.add_handler(CommandHandler("approve", partial(_wrap_cmd("approve", cmd_approve), ctx)))
    app.add_handler(CommandHandler("deny", partial(_wrap_cmd("deny", cmd_deny), ctx)))
    app.add_handler(
        CallbackQueryHandler(partial(handle_approval_callback, ctx), pattern=r"^(approve|deny):")
    )
    app.add_handler(CallbackQueryHandler(partial(handle_cc_callback, ctx), pattern=r"^cc_"))
    app.add_handler(CommandHandler("status", partial(_wrap_cmd("status", cmd_status), ctx)))
    app.add_handler(CommandHandler("runs", partial(_wrap_cmd("runs", cmd_runs), ctx)))
    app.add_handler(CommandHandler("history", partial(_wrap_cmd("history", cmd_history), ctx)))
    app.add_handler(CommandHandler("merge", partial(_wrap_cmd("merge", cmd_merge), ctx)))
    app.add_handler(CommandHandler("schedule", partial(_wrap_cmd("schedule", cmd_schedule), ctx)))
    app.add_handler(CommandHandler("goals", partial(_wrap_cmd("goals", cmd_goals), ctx)))
    app.add_handler(CommandHandler("ping", partial(_wrap_cmd("ping", cmd_ping), ctx)))
    app.add_handler(
        CommandHandler(
            "parallel_start", partial(_wrap_cmd("parallel_start", cmd_parallel_start), ctx)
        )
    )
    app.add_handler(
        CallbackQueryHandler(partial(handle_run_action_callback, ctx), pattern=r"^(merge_run|repeat_goal):")
    )
    app.add_handler(
        CallbackQueryHandler(partial(handle_run_action_callback, ctx), pattern=r"^quick_goal:")
    )
    # Session handlers
    app.add_handler(
        CommandHandler("session_start", partial(_wrap_cmd("session_start", cmd_session_start), ctx))
    )
    app.add_handler(
        CommandHandler(
            "session_resume", partial(_wrap_cmd("session_resume", cmd_session_resume), ctx)
        )
    )
    app.add_handler(
        CommandHandler("session_stop", partial(_wrap_cmd("session_stop", cmd_session_stop), ctx))
    )
    app.add_handler(
        CommandHandler(
            "session_status", partial(_wrap_cmd("session_status", cmd_session_status), ctx)
        )
    )
    app.add_handler(
        CommandHandler("session_graph", partial(_wrap_cmd("session_graph", cmd_session_graph), ctx))
    )
    app.add_handler(
        CommandHandler(
            "session_export", partial(_wrap_cmd("session_export", cmd_session_export), ctx)
        )
    )
    app.add_handler(
        CommandHandler(
            "session_rollback", partial(_wrap_cmd("session_rollback", cmd_session_rollback), ctx)
        )
    )
    app.add_handler(
        CommandHandler("session_help", partial(_wrap_cmd("session_help", cmd_session_help), ctx))
    )
    # Settings/monitoring handlers
    app.add_handler(CommandHandler("digest", partial(_wrap_cmd("digest", cmd_digest), ctx)))
    app.add_handler(CommandHandler("stuck", partial(_wrap_cmd("stuck", cmd_stuck), ctx)))
    app.add_handler(
        CommandHandler("skillpack", partial(_wrap_cmd("skillpack", cmd_skillpack), ctx))
    )
    app.add_handler(CommandHandler("model", partial(_wrap_cmd("model", cmd_model), ctx)))
    app.add_handler(CommandHandler("think", partial(_wrap_cmd("think", cmd_think), ctx)))
    app.add_handler(CommandHandler("memory", partial(_wrap_cmd("memory", cmd_memory), ctx)))
    app.add_handler(CommandHandler("verbose", partial(_wrap_cmd("verbose", cmd_verbose), ctx)))
    app.add_handler(
        CommandHandler("heartbeat", partial(_wrap_cmd("heartbeat", cmd_heartbeat), ctx))
    )
    app.add_handler(
        CommandHandler("screenshot", partial(_wrap_cmd("screenshot", cmd_screenshot), ctx))
    )
    app.add_handler(CommandHandler("watch", partial(_wrap_cmd("watch", cmd_watch), ctx)))
    app.add_handler(CommandHandler("queue", partial(_wrap_cmd("queue", cmd_queue), ctx)))
    app.add_handler(CommandHandler("graph", partial(_wrap_cmd("graph", cmd_graph), ctx)))
    app.add_handler(
        CommandHandler(
            "graph_parallel",
            partial(_wrap_cmd("graph_parallel", cmd_graph_parallel), ctx),
        )
    )
    app.add_handler(
        CommandHandler("voice_mode", partial(_wrap_cmd("voice_mode", cmd_voice_mode), ctx))
    )
    app.add_handler(
        CommandHandler("watch_start", partial(_wrap_cmd("watch_start", cmd_watch_start), ctx))
    )
    app.add_handler(
        CommandHandler("watch_stop", partial(_wrap_cmd("watch_stop", cmd_watch_stop), ctx))
    )
    app.add_handler(
        CommandHandler(
            "watch_status", partial(_wrap_cmd("watch_status", cmd_watch_status), ctx)
        )
    )
    # Voice/audio messages → Whisper transcription
    if _PTB_AVAILABLE:
        app.add_handler(
            MessageHandler(
                filters.VOICE | filters.AUDIO,
                partial(handle_voice_message, bot_ctx=ctx),
            )
        )
    if _PTB_AVAILABLE:
        app.add_handler(
            MessageHandler(
                filters.Entity("mention") & filters.ChatType.GROUPS,
                partial(group_mention, ctx),
            )
        )
    _jq = app.job_queue
    _notify_chat = _allowed[0] if _allowed else None
    if _jq is not None:
        if _notify_chat is not None:
            _jq.run_repeating(
                partial(job_screen_monitor, ctx),
                interval=300,
                first=60,
                name="owlmind_screen_monitor",
                data=_notify_chat,
            )
        _jq.run_repeating(
            partial(job_process_queue, ctx),
            interval=120,
            first=10,
            name="owlmind_queue_processor",
        )

    async def _on_startup(application: Any) -> None:
        # Restore nightly schedule from file if exists
        with contextlib.suppress(Exception):
            import datetime
            import json as _json
            from functools import partial as _partial

            from owlmind.telegram.handlers_autopilot import _SCHEDULE_FILE, job_scheduled_run

            if _SCHEDULE_FILE.exists() and app.job_queue:
                data = _json.loads(_SCHEDULE_FILE.read_text())
                time_str = data.get("time", "")
                if time_str:
                    h, m = map(int, time_str.split(":"))
                    run_time = datetime.time(h, m, tzinfo=datetime.UTC)
                    app.job_queue.run_daily(
                        _partial(job_scheduled_run, ctx),
                        time=run_time,
                        name="owlmind_nightly",
                        data=data,
                    )

        with contextlib.suppress(Exception):
            await application.bot.set_my_commands(
                [
                    BotCommand("help", "Show available commands"),
                    BotCommand("auto_start", "Start autopilot run (goal)"),
                    BotCommand("auto_stop", "Stop a run"),
                    BotCommand("status", "Show run status"),
                    BotCommand("runs", "List recent runs"),
                    BotCommand("history", "Run history from disk: /history [N]"),
                    BotCommand("merge", "Merge PR for a run: /merge <run_id>"),
                    BotCommand("ping", "Bot health check: uptime, active runs"),
                    BotCommand("schedule", "Nightly auto-cycle: /schedule set HH:MM <goal>"),
                    BotCommand("approve", "Approve pending worker request"),
                    BotCommand("deny", "Deny pending worker request"),
                    BotCommand("session_start", "Start session from goals file"),
                    BotCommand("session_resume", "Resume a stopped session"),
                    BotCommand("session_stop", "Stop a session"),
                    BotCommand("session_status", "Show session status"),
                    BotCommand("session_graph", "Show session DAG"),
                    BotCommand("session_export", "Export session as zip"),
                    BotCommand("session_rollback", "Rollback a session goal"),
                    BotCommand("model", "LLM profile: fast/balanced/powerful"),
                    BotCommand("think", "Thinking depth: off/low/medium/high/xhigh"),
                    BotCommand("memory", "Memory: stats/search/signals/add lesson"),
                    BotCommand("verbose", "Toggle verbose event reporting"),
                    BotCommand("heartbeat", "Heartbeat check-ins: on/off/<N>h"),
                    BotCommand("screenshot", "Capture current screen"),
                    BotCommand("watch", "Watch run events live"),
                    BotCommand("queue", "Task queue: list/add/cancel/details"),
                    BotCommand("digest", "Usage digest for N days"),
                    BotCommand("stuck", "Detect stuck sessions"),
                    BotCommand("skillpack", "List or view skill packs"),
                    BotCommand("graph", "Run graph pipeline: /graph <goal>"),
                    BotCommand(
                        "graph_parallel",
                        "Run multiple goals in parallel: /graph_parallel g1 | g2 | g3",
                    ),
                    BotCommand(
                        "watch_start",
                        "Start autonomous scheduler: /watch_start <goal> [--interval N]",
                    ),
                    BotCommand("watch_stop", "Stop autonomous scheduler"),
                    BotCommand("watch_status", "Show autonomous scheduler status"),
                    BotCommand("voice_mode", "Toggle voice→graph auto mode: on/off"),
                    BotCommand("goals", "Quick goal menu with presets"),
                ]
            )

        # Send startup notification to all allowed chats
        with contextlib.suppress(Exception):
            import json as _json

            from owlmind import __version__ as _ver
            from owlmind.telegram.handlers_autopilot import _SCHEDULE_FILE

            sched_info = ""
            if _SCHEDULE_FILE.exists():
                with contextlib.suppress(Exception):
                    _d = _json.loads(_SCHEDULE_FILE.read_text())
                    sched_info = f"\n📅 Schedule: {_d.get('time', '?')} UTC — {_d.get('goal', '')[:50]}"

            startup_text = f"🤖 OwlMind бот запущен\nv{_ver}{sched_info}"
            for chat_id in (_allowed or []):
                with contextlib.suppress(Exception):
                    await application.bot.send_message(chat_id=chat_id, text=startup_text)

    app.post_init = _on_startup

    return app


# ---------------------------------------------------------------------------
# Helpers — re-exported from owlmind.telegram.helpers for backward compat
# ---------------------------------------------------------------------------

from owlmind.telegram.helpers import (  # noqa: E402, F401
    _VALID_LLM,
    _VALID_WORKER,
    SessionStartArgs,
    _format_event_message,
    _format_session_result,
    make_event_notifier,
    parse_session_resume_args,
    parse_session_start_args,
    parse_session_start_args_full,
    parse_workspace_from_args,
)
