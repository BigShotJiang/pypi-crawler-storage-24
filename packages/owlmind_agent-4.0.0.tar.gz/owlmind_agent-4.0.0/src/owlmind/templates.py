"""Goals Template Library — built-in templates for common DAG patterns."""

from __future__ import annotations

import yaml

_TEMPLATES: dict[str, dict[str, object]] = {
    "pr_ci_release_dag": {
        "description": "Plan -> Implement -> PR -> CI -> Release",
        "template": {
            "version": 2,
            "defaults": {
                "workspace": ".",
                "use_llm": "both",
                "use_worker": "none",
                "max_steps": 200,
            },
            "goals": [
                {
                    "id": "G1-PLAN",
                    "goal": "Create implementation plan and design document",
                    "depends_on": [],
                },
                {
                    "id": "G2-IMPLEMENT",
                    "goal": "Implement the planned changes with tests",
                    "depends_on": ["G1-PLAN"],
                },
                {
                    "id": "G3-PR",
                    "goal": "Create pull request with description",
                    "depends_on": ["G2-IMPLEMENT"],
                },
                {
                    "id": "G4-CI",
                    "goal": "Verify CI passes (lint, test, policy checks)",
                    "depends_on": ["G3-PR"],
                },
                {
                    "id": "G5-RELEASE",
                    "goal": "Prepare release (changelog, version bump, tag)",
                    "depends_on": ["G4-CI"],
                },
            ],
        },
    },
    "hotfix_ci_dag": {
        "description": "Hotfix -> Test -> PR -> CI",
        "template": {
            "version": 2,
            "defaults": {
                "workspace": ".",
                "use_llm": "both",
                "use_worker": "none",
                "max_steps": 100,
            },
            "goals": [
                {
                    "id": "G1-FIX",
                    "goal": "Identify and fix the bug",
                    "depends_on": [],
                },
                {
                    "id": "G2-TEST",
                    "goal": "Add regression test for the fix",
                    "depends_on": ["G1-FIX"],
                },
                {
                    "id": "G3-PR",
                    "goal": "Create hotfix PR",
                    "depends_on": ["G2-TEST"],
                },
                {
                    "id": "G4-CI",
                    "goal": "Verify CI passes",
                    "depends_on": ["G3-PR"],
                },
            ],
        },
    },
    "docs_only_chain": {
        "description": "Write docs -> Review -> Publish",
        "template": {
            "version": 2,
            "defaults": {
                "workspace": ".",
                "use_llm": "both",
                "use_worker": "none",
                "max_steps": 100,
            },
            "goals": [
                {
                    "id": "G1-WRITE",
                    "goal": "Write or update documentation",
                    "depends_on": [],
                },
                {
                    "id": "G2-REVIEW",
                    "goal": "Review documentation for accuracy and completeness",
                    "depends_on": ["G1-WRITE"],
                },
                {
                    "id": "G3-PUBLISH",
                    "goal": "Create PR and publish documentation",
                    "depends_on": ["G2-REVIEW"],
                },
            ],
        },
    },
}


def list_templates() -> list[str]:
    """Return names of all available templates."""
    return sorted(_TEMPLATES.keys())


def get_template_info(name: str) -> str:
    """Return template description."""
    tpl = _TEMPLATES.get(name)
    if not tpl:
        msg = f"Unknown template: {name}. Available: {', '.join(list_templates())}"
        raise ValueError(msg)
    return str(tpl["description"])


def render_template(
    name: str,
    workspace: str = ".",
    defaults: dict[str, object] | None = None,
) -> str:
    """Render a template to YAML string.

    Never includes secrets in output.
    """
    tpl = _TEMPLATES.get(name)
    if not tpl:
        msg = f"Unknown template: {name}. Available: {', '.join(list_templates())}"
        raise ValueError(msg)

    import copy

    data = copy.deepcopy(tpl["template"])
    if isinstance(data, dict) and "defaults" in data:
        data["defaults"]["workspace"] = workspace
        if defaults:
            data["defaults"].update(defaults)

    return yaml.dump(data, default_flow_style=False, sort_keys=False, allow_unicode=True)
