# OwlMind — Autonomous Multi-Agent Code Assistant

> Run AI-powered code pipelines from your terminal, Telegram, or Slack.

## What it does

OwlMind orchestrates a four-stage agent pipeline — **Architect → Coder → Tester → Reviewer** — where each stage is powered by an LLM of your choice (OpenAI-compatible, Anthropic, or Gemini). The Architect produces an implementation plan, the Coder writes or edits the code, the Tester validates it, and the Reviewer issues a final verdict of `APPROVED`, `NEEDS_FIX`, or `REJECTED`. When the Reviewer requests a fix, the pipeline automatically iterates (up to a configurable limit) incorporating the feedback until the goal is approved or the run concludes. You control the entire loop from your terminal, a Telegram bot, a Slack bot, or a live web dashboard.

---

## Quick Start

### Install

```bash
# Core + Telegram support
pip install -e ".[telegram]"

# Everything (Telegram, OpenAI, Anthropic, Gemini, vision, browser, AST, monitoring, Qdrant)
pip install -e ".[all]"

# Development extras
pip install -e ".[dev]"
```

### Configure (`.env`)

Create a `.env` file in the project root:

```dotenv
# LLM — OpenAI or any OpenAI-compatible provider (e.g. DeepSeek)
OPENAI_API_KEY=sk-...
OPENAI_BASE_URL=https://api.openai.com/v1   # optional; change for DeepSeek etc.
OPENAI_MODEL=deepseek-reasoner               # default model

# Anthropic (fallback when OPENAI_API_KEY is not set)
ANTHROPIC_API_KEY=sk-ant-...
ANTHROPIC_MODEL=claude-sonnet-4-6            # default

# Telegram bot
TELEGRAM_BOT_TOKEN=123456:ABC-...
TELEGRAM_ALLOWED_CHAT_IDS=111222333,444555666

# Voice transcription (optional)
WHISPER_API_KEY=sk-...

# Slack bot (optional)
SLACK_BOT_TOKEN=xoxb-...
SLACK_APP_TOKEN=xapp-...

# Security (optional master password for CLI)
OWLMIND_MASTER_PASSWORD=...
OWLMIND_SKIP_PASSWORD_CHECK=1   # set in Docker to bypass
```

### Run a graph pipeline

```bash
owlmind graph run "create hello.py with add(a,b) function" --workspace /tmp/test
```

### Start the Telegram bot

```bash
owlmind telegram run
```

### Start the web dashboard

```bash
owlmind web serve          # → http://localhost:8080
owlmind web serve --port 9090 --host 0.0.0.0
```

---

## CLI Commands

### Graph Pipeline

| Command | Description |
|---------|-------------|
| `owlmind graph run <goal>` | Run the full Architect→Coder→Tester→Reviewer pipeline |
| `owlmind graph plan <goal>` | Run only the Architect node and print the implementation plan |
| `owlmind graph parallel "t1,t2,t3"` | Run multiple subtasks in parallel (configurable workers) |
| `owlmind graph watch <goal>` | Run the pipeline autonomously on a schedule or GitHub trigger |
| `owlmind graph sessions` | List persisted graph sessions (filter by `--status`) |
| `owlmind graph resume <run-id>` | Resume an interrupted run from its last checkpoint |

Common flags for `graph run` / `graph resume`:

| Flag | Default | Description |
|------|---------|-------------|
| `--workspace`, `-w` | `.` | Directory for the agent to work in |
| `--iterations`, `-n` | `3` | Max review-fix cycles |
| `--skip-tester` | off | Skip the Tester node |
| `--verbose`, `-v` | off | Print node output panels |

### Telegram Bot Commands

| Command | Description |
|---------|-------------|
| `/help` | Show available commands |
| `/auto_start <goal>` | Start an autopilot run |
| `/auto_stop` | Stop a running autopilot run |
| `/status` | Show current run status |
| `/runs` | List recent runs |
| `/approve` | Approve a pending worker request |
| `/deny` | Deny a pending worker request |
| `/graph <goal>` | Run the graph pipeline (Architect→Coder→Tester→Reviewer) |
| `/watch_start <goal>` | Start autonomous scheduler (`--interval N` seconds) |
| `/watch_stop` | Stop the autonomous scheduler |
| `/watch_status` | Show autonomous scheduler status |
| `/session_start` | Start a session from a goals file |
| `/session_resume` | Resume a stopped session |
| `/session_stop` | Stop a session |
| `/session_status` | Show session status |
| `/session_graph` | Show session DAG |
| `/session_export` | Export session as a zip bundle |
| `/session_rollback` | Rollback a session goal |
| `/model fast\|balanced\|powerful` | Switch LLM profile |
| `/think off\|low\|medium\|high\|xhigh` | Set LLM thinking depth |
| `/memory` | Access persistent memory (stats/search/signals/add lesson) |
| `/verbose` | Toggle verbose event reporting |
| `/heartbeat on\|off\|<N>h` | Enable/disable heartbeat check-ins |
| `/screenshot` | Capture the current screen |
| `/watch` | Watch run events live |
| `/queue` | Task queue management (list/add/cancel/details) |
| `/digest <N>` | Usage digest for last N days |
| `/stuck` | Detect stuck sessions |
| `/skillpack` | List or view skill packs |
| `/e2e_preflight` | Run preflight checks |
| `/e2e_smoke` | Run E2E smoke test |
| Voice messages | Transcribed via Whisper and optionally run as a goal |

### Sessions (multi-goal)

Sessions chain multiple goals from a YAML file into a DAG with dependency tracking.

| Command | Description |
|---------|-------------|
| `owlmind session start -f goals.yaml` | Start a session from a goals file |
| `owlmind session resume --session-id <id>` | Resume a stopped session |
| `owlmind session status --session-id <id>` | Show session status and goals table |
| `owlmind session stop --session-id <id>` | Stop a running session |
| `owlmind session list` | List recent sessions |
| `owlmind session logs --session-id <id>` | Show session event log |
| `owlmind session graph --session-id <id>` | Print the DAG (layers, statuses, ready nodes) |
| `owlmind session export --session-id <id>` | Export session as a zip bundle |
| `owlmind session rollback --session-id <id> --goal-id <gid>` | Rollback a failed goal |
| `owlmind session dashboard --session-id <id>` | Generate a static HTML dashboard for a session |

### Autopilot & Heartbeat

| Command | Description |
|---------|-------------|
| `owlmind auto_start <goal>` | Start an autopilot run directly from the CLI |
| `owlmind auto_stop` | Stop a running autopilot run |
| `owlmind heartbeat` | Run the heartbeat engine (monitors queue, stuck runs, approvals) |
| `owlmind doctor` | Health check for policies, environment, and dependencies |
| `owlmind doctor --preflight` | Full preflight check (deps, env vars, binaries) |
| `owlmind doctor --fix` | Auto-fix safe local issues (directories, `.env.example`) |

### AST / CodeRAG

Semantic code search backed by tree-sitter and Qdrant (requires `pip install -e ".[ast,qdrant]"`).

| Command | Description |
|---------|-------------|
| `owlmind ast index` | Index the workspace for semantic code search |
| `owlmind ast search <query>` | Search the indexed codebase |
| `owlmind ast status` | Show index backend and stats |

### Autofix

| Command                      | Description                                                              |
|------------------------------|--------------------------------------------------------------------------|
| `owlmind autofix run <goal>` | Auto-fix CI failures; optionally commit (`--commit`) and push (`--push`) |

### Other Notable Commands

| Command | Description |
|---------|-------------|
| `owlmind web serve` | Start the web dashboard (FastAPI + uvicorn) |
| `owlmind slack serve` | Start the Slack bot |
| `owlmind run <task.json>` | Execute a task defined in a JSON file |
| `owlmind show <run-id>` | Inspect a completed run |
| `owlmind replay <run-id>` | Replay events from a previous run (read-only) |
| `owlmind github review <pr-url>` | AI-powered GitHub PR review |
| `owlmind queue` | Manage the task queue |
| `owlmind scheduler` | Distributed goal scheduler |
| `owlmind worker` | Distributed worker process |
| `owlmind memory` | Persistent agent memory management |
| `owlmind cost` | Token and cost reporting |
| `owlmind analytics` | Usage analytics |
| `owlmind monitor` | Live run monitoring |
| `owlmind vision` | Vision module (screen capture, OCR) — requires `[vision]` |
| `owlmind browser` | Browser automation — requires `[browser]` |

---

## Architecture

```
Voice/Text → Telegram Bot / Slack Bot / CLI
                        │
                   GraphRunner
          ┌─────┬──────┬───────┬──────────┐
      Architect  Coder  Tester  Reviewer
          └─────┴──────┴───────┴──────────┘
                        │
               APPROVED / NEEDS_FIX / REJECTED
                        │
              (iterate up to max_iterations)
                        │
              SessionStateStore  ←→  RunMemory
```

**Node responsibilities:**

- **Architect** — reads the goal and run-memory context, produces a structured implementation plan.
- **Coder** — implements the plan, writes or patches files inside the workspace.
- **Tester** — runs tests, linters, or any validation steps; reports pass/fail.
- **Reviewer** — evaluates code quality and test results; emits `APPROVED`, `NEEDS_FIX`, or `REJECTED`.

Each node checkpoint is persisted so interrupted runs can be resumed. All token usage and estimated cost are tracked per run.

**LLM selection** (in priority order):

1. `OPENAI_API_KEY` — uses the OpenAI SDK; supports any OpenAI-compatible provider (DeepSeek, local Ollama, etc.)
2. `ANTHROPIC_API_KEY` — falls back to Anthropic Claude.

---

## Docker Deployment

```bash
# 1. Copy and fill in your environment file
cp .env.example .env   # edit with your keys

# 2. Start both the Telegram bot and the web dashboard
docker compose up -d

# 3. Useful operations
docker compose logs -f        # stream logs
docker compose down           # stop all services
```

The `docker-compose.yml` defines two services:

| Service        | Port   | Description                                         |
|----------------|--------|-----------------------------------------------------|
| `telegram-bot` | —      | Runs `owlmind telegram run` with auto-restart       |
| `dashboard`    | `8080` | Runs `owlmind web serve` at `http://localhost:8080` |

Both services share a `owlmind-data` volume (`~/.owlmind`) and a `./workspace` bind mount.

---

## Configuration

| Variable                      | Required  | Default             | Description                                                   |
|-------------------------------|-----------|---------------------|---------------------------------------------------------------|
| `OPENAI_API_KEY`              | *         | —                   | OpenAI or compatible provider key                             |
| `OPENAI_BASE_URL`             | no        | `api.openai.com/v1` | Override for DeepSeek, local Ollama, etc.                     |
| `OPENAI_MODEL`                | no        | `deepseek-reasoner` | Model name for OpenAI-compatible providers                    |
| `ANTHROPIC_API_KEY`           | *         | —                   | Anthropic key (fallback when no OpenAI key)                   |
| `ANTHROPIC_MODEL`             | no        | `claude-sonnet-4-6` | Anthropic model name                                          |
| `TELEGRAM_BOT_TOKEN`          | for bot   | —                   | Token from @BotFather                                         |
| `TELEGRAM_ALLOWED_CHAT_IDS`   | for bot   | —                   | Comma-separated chat IDs allowed to control the bot           |
| `WHISPER_API_KEY`             | no        | —                   | API key for Whisper voice transcription                       |
| `SLACK_BOT_TOKEN`             | for Slack | —                   | `xoxb-...` bot token                                          |
| `SLACK_APP_TOKEN`             | for Slack | —                   | `xapp-...` socket-mode app token                              |
| `SLACK_ALLOWED_USER_IDS`      | no        | —                   | Comma-separated Slack user IDs that may issue commands        |
| `OWLMIND_MASTER_PASSWORD`     | no        | —                   | Master password for CLI security gate                         |
| `OWLMIND_SKIP_PASSWORD_CHECK` | no        | `0`                 | Set to `1` to bypass the password check (useful in Docker)    |
| `QDRANT_URL`                  | no        | —                   | Qdrant server URL for CodeRAG semantic search                 |

*At least one of `OPENAI_API_KEY` or `ANTHROPIC_API_KEY` is required to run the graph pipeline.

---

## Development

```bash
# Install with dev extras
pip install -e ".[dev]"

# One-shot setup (install + pre-commit hooks + create data dirs)
make setup

# Run tests
pytest tests/

# With coverage report
make cov

# Lint and type-check
make lint
make type

# Auto-format
make fmt

# Health check
owlmind doctor --preflight
```

Test suite requires Python 3.11+. Async tests run automatically via `pytest-asyncio`.

---

## Optional Extras

| Extra        | Installs                               | Enables                                  |
|--------------|----------------------------------------|------------------------------------------|
| `telegram`   | `python-telegram-bot>=21`              | Telegram bot                             |
| `openai`     | `openai>=1.0`                          | OpenAI, DeepSeek, and compatible LLMs   |
| `anthropic`  | `anthropic>=0.39`                      | Anthropic Claude                         |
| `gemini`     | `google-genai>=1.0`                    | Google Gemini                            |
| `api`        | `fastapi`, `uvicorn`, `httpx`          | Web dashboard + REST API                 |
| `vision`     | `pillow`, `pyautogui`, `anthropic`     | Screen capture and OCR                   |
| `browser`    | `playwright>=1.40`                     | Browser automation                       |
| `ast`        | `tree-sitter`, `tree-sitter-languages` | AST-based CodeRAG indexing               |
| `qdrant`     | `qdrant-client`, `fastembed`           | Vector search backend for CodeRAG        |
| `monitoring` | `prometheus-client`, `structlog`       | Prometheus metrics + structured logging  |
| `sandbox`    | `e2b-code-interpreter`                 | Secure E2B sandbox for code execution    |
| `rabbitmq`   | `aio-pika>=9`                          | RabbitMQ message broker                  |
| `postgres`   | `asyncpg>=0.29`                        | PostgreSQL persistence                   |
| `s3`         | `aiobotocore>=2.13`                    | S3-compatible object storage             |
| `kafka`      | `aiokafka>=0.8`                        | Kafka event streaming                    |
| `otel`       | `opentelemetry-*`                      | OpenTelemetry tracing                    |
| `langfuse`   | `langfuse>=2.0`                        | LLM observability via Langfuse           |
| `all`        | everything above                       | Full installation                        |

---

## License

MIT
