"""Bot strategy package."""

from game.bots.strategy import choose_bot_column

__all__ = ["choose_bot_column"]
