"""Game package for Connect 4 implementations."""
