from .RobotTrace import RobotTrace as robot_trace

__all__ = ["robot_trace"]
__version__ = "1.2.2"
