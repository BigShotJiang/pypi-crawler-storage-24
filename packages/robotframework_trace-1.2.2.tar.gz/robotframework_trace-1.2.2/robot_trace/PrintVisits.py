# Copyright (c) 2026 Jonathan Simmonds
#


class PrintVisits:
    ROBOT_LISTENER_API_VERSION = 3

    def __init__(self):
        print("__init__")

    def start_suite(self, suite, result):
        print(f"start_suite({suite}, {result})")

    def end_suite(self, suite, result):
        print(f"end_suite({suite}, {result})")

    def start_test(self, test, result):
        print(f"start_test: {test}, {result}")

    def end_test(self, test, result):
        print(f"end_test: {test}, {result}")

    def start_keyword(self, keyword, result):
        print(f"start_keyword({keyword}, {result})")

    def end_keyword(self, keyword, result):
        print(f"end_keyword({keyword}, {result})")

    def log_message(self, message):
        print(f"log_message({message})")

    def message(self, message):
        # print(f"message({message})")
        pass

    def start_error(self, data, result):
        print(f"start_error({data}, {result})")

    def end_error(self, data, result):
        print(f"end_error({data}, {result})")

    def close(self):
        print("close")
