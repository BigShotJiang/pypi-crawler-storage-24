"""
Test configuration and fixtures for the MCP-based architecture.
"""

import os
from typing import Any
from unittest.mock import MagicMock, patch

import numpy as np
import pytest

try:
    from dotenv import load_dotenv

    load_dotenv(override=True)
except ImportError:
    pass

from imas_codex.clusters.search import ClusterSearchResult
from imas_codex.embeddings.encoder import Encoder
from imas_codex.search.document_store import Document, DocumentMetadata, DocumentStore
from imas_codex.search.engines.base_engine import MockSearchEngine
from imas_codex.tools import Tools


def pytest_addoption(parser):
    parser.addoption(
        "--embedding-model",
        action="store",
        default=None,
        help="Embedding model to use for tests (default: from settings)",
    )


def pytest_configure(config):
    """Configure pytest."""
    pass


# ── Auto-skip graph/integration tests when Neo4j is unreachable ──────────
_neo4j_available: bool | None = None


def _check_neo4j() -> bool:
    """Quick probe to see if Neo4j is reachable (cached per session)."""
    global _neo4j_available
    if _neo4j_available is not None:
        return _neo4j_available
    try:
        from imas_codex.graph.client import GraphClient

        client = GraphClient()
        client.get_stats()
        client.close()
        _neo4j_available = True
    except Exception:
        _neo4j_available = False
    return _neo4j_available


def pytest_collection_modifyitems(config, items):  # noqa: ARG001
    """Auto-skip graph/integration-marked tests when Neo4j is unreachable."""
    if _check_neo4j():
        return
    skip_marker = pytest.mark.skip(reason="Neo4j not available")
    for item in items:
        if item.get_closest_marker("graph") or item.get_closest_marker("integration"):
            item.add_marker(skip_marker)


@pytest.fixture(scope="session")
def embedding_model_name(request):
    """Get the embedding model name from command line option."""
    return request.config.getoption("--embedding-model")


@pytest.fixture(scope="session", autouse=True)
def configure_embedding_model(embedding_model_name):
    """Configure the embedding model environment variable.

    Forces local backend with all-MiniLM-L6-v2 for all tests unless
    explicitly overridden via --embedding-model CLI option.

    Uses direct assignment (not setdefault) to ensure test values
    override any values loaded from .env by load_dotenv(override=True).
    """
    os.environ["IMAS_CODEX_EMBEDDING_LOCATION"] = "local"
    if embedding_model_name:
        os.environ["IMAS_CODEX_EMBEDDING_MODEL"] = embedding_model_name
    else:
        os.environ["IMAS_CODEX_EMBEDDING_MODEL"] = "all-MiniLM-L6-v2"


# Standard test IDS set for consistency across all tests
# This avoids re-embedding and ensures consistent performance
STANDARD_TEST_IDS_SET = {"equilibrium", "core_profiles"}


def create_mock_document(path_id: str, ids_name: str = "core_profiles") -> Document:
    """Create a mock document for testing."""
    metadata = DocumentMetadata(
        path_id=path_id,
        ids_name=ids_name,
        path_name=path_id.split("/")[-1],
        units="m",
        data_type="float",
        coordinates=("rho_tor_norm",),
        physics_domain="transport",
        physics_phenomena=("transport", "plasma"),
    )

    return Document(
        metadata=metadata,
        documentation=f"Mock documentation for {path_id}",
        relationships={},
        raw_data={"data_type": "float", "units": "m"},
    )


def create_mock_documents() -> list[Document]:
    """Create a set of mock documents for testing."""
    return [
        create_mock_document("core_profiles/profiles_1d/electrons/temperature"),
        create_mock_document("core_profiles/profiles_1d/electrons/density"),
        create_mock_document("equilibrium/time_slice/profiles_1d/psi", "equilibrium"),
        create_mock_document(
            "equilibrium/time_slice/profiles_2d/b_field_r", "equilibrium"
        ),
        create_mock_document("equilibrium/time_slice/boundary/psi", "equilibrium"),
        create_mock_document("equilibrium/time_slice/boundary/psi_norm", "equilibrium"),
        create_mock_document("equilibrium/time_slice/boundary/type", "equilibrium"),
    ]


def create_mock_clusters() -> list[dict]:
    """Create mock cluster data for testing."""
    return [
        {
            "id": 0,
            "label": "Electron Temperature Profiles",
            "description": "Temperature measurements for electrons",
            "is_cross_ids": False,
            "ids_names": ["core_profiles"],
            "paths": [
                "core_profiles/profiles_1d/electrons/temperature",
                "core_profiles/profiles_1d/electrons/temperature_fit",
            ],
            "similarity_score": 0.95,
            "cluster_similarity": 0.87,
        },
        {
            "id": 1,
            "label": "Magnetic Field Components",
            "description": "Magnetic field measurements and derived quantities",
            "is_cross_ids": True,
            "ids_names": ["equilibrium", "core_profiles"],
            "paths": [
                "equilibrium/time_slice/profiles_2d/b_field_r",
                "equilibrium/time_slice/profiles_2d/b_field_z",
            ],
            "similarity_score": 0.88,
            "cluster_similarity": 0.82,
        },
        {
            "id": 2,
            "label": "Boundary Conditions",
            "description": "Plasma boundary and separatrix data",
            "is_cross_ids": False,
            "ids_names": ["equilibrium"],
            "paths": [
                "equilibrium/time_slice/boundary/psi",
                "equilibrium/time_slice/boundary/psi_norm",
                "equilibrium/time_slice/boundary/type",
            ],
            "similarity_score": 0.92,
            "cluster_similarity": 0.79,
        },
    ]


def create_mock_cluster_search_results(query: str) -> list[ClusterSearchResult]:
    """Create mock cluster search results for testing."""
    mock_clusters = create_mock_clusters()
    return [
        ClusterSearchResult(
            cluster_id=c["id"],
            label=c["label"],
            description=c["description"],
            is_cross_ids=c["is_cross_ids"],
            ids_names=c["ids_names"],
            paths=c["paths"],
            similarity_score=c["similarity_score"],
            cluster_similarity=c["cluster_similarity"],
        )
        for c in mock_clusters[:2]  # Return first 2 clusters
    ]


@pytest.fixture(autouse=True)
def temporary_embedding_cache_dir(tmp_path_factory, monkeypatch):
    """Keep embedding cache files isolated per test."""
    temp_dir = tmp_path_factory.mktemp("embedding_cache")
    monkeypatch.setattr(
        Encoder,
        "_get_cache_directory",
        lambda self, _temp_dir=temp_dir: _temp_dir,
    )
    yield


@pytest.fixture(autouse=True)
def disable_caching():
    """Automatically disable caching for all tests by making cache always miss."""
    # Patch the cache get method to always return None (cache miss)
    with patch("imas_codex.search.decorators.cache._cache.get", return_value=None):
        # Also patch the set method to do nothing
        with patch("imas_codex.search.decorators.cache._cache.set"):
            yield


@pytest.fixture(scope="session", autouse=True)
def mock_heavy_operations():
    """Mock heavy operations that slow down tests.

    Mocks Encoder model loading, DocumentStore I/O, and search engines
    for tests that directly use those classes (not via the MCP server).
    """
    mock_documents = create_mock_documents()

    mock_st_cls = MagicMock()
    mock_st_model = MagicMock()
    mock_st_model.device = "cpu"
    mock_st_model.encode.return_value = np.zeros((len(mock_documents), 384))
    mock_st_cls.return_value = mock_st_model

    with (
        patch.object(
            Encoder, "_import_sentence_transformers", return_value=mock_st_cls
        ),
        patch.multiple(
            DocumentStore,
            _ensure_loaded=MagicMock(),
            _ensure_ids_loaded=MagicMock(),
            _load_ids_documents=MagicMock(),
            _load_identifier_catalog_documents=MagicMock(),
            load_all_documents=MagicMock(),
            _build_sqlite_fts_index=MagicMock(),
            _should_rebuild_fts_index=MagicMock(return_value=False),
            get_all_documents=MagicMock(return_value=mock_documents),
            get_document=MagicMock(
                side_effect=lambda path_id: next(
                    (doc for doc in mock_documents if doc.metadata.path_id == path_id),
                    None,
                )
            ),
            get_documents_by_ids=MagicMock(
                side_effect=lambda ids_name: [
                    doc for doc in mock_documents if doc.metadata.ids_name == ids_name
                ]
            ),
            get_available_ids=MagicMock(return_value=list(STANDARD_TEST_IDS_SET)),
            __len__=MagicMock(return_value=len(mock_documents)),
            search_full_text=MagicMock(return_value=mock_documents[:2]),
            search_by_keywords=MagicMock(return_value=mock_documents[:2]),
            search_by_physics_domain=MagicMock(return_value=mock_documents[:2]),
            search_by_units=MagicMock(return_value=mock_documents[:2]),
            get_statistics=MagicMock(
                return_value={
                    "total_documents": len(mock_documents),
                    "total_ids": len(STANDARD_TEST_IDS_SET),
                    "physics_domains": 2,
                    "unique_units": 1,
                    "coordinate_systems": 1,
                    "documentation_terms": 100,
                    "path_segments": 50,
                }
            ),
            get_identifier_schemas=MagicMock(return_value=[]),
            get_identifier_paths=MagicMock(return_value=[]),
            get_identifier_schema_by_name=MagicMock(return_value=None),
        ),
    ):
        mock_engine = MockSearchEngine()
        with (
            patch(
                "imas_codex.search.engines.semantic_engine.SemanticSearchEngine.search",
                side_effect=mock_engine.search,
            ),
            patch(
                "imas_codex.search.engines.lexical_engine.LexicalSearchEngine.search",
                side_effect=mock_engine.search,
            ),
            patch(
                "imas_codex.search.engines.hybrid_engine.HybridSearchEngine.search",
                side_effect=mock_engine.search,
            ),
        ):
            mock_clusters = create_mock_clusters()
            with patch("imas_codex.core.clusters.Clusters") as mock_clusters_class:
                mock_clusters_instance = MagicMock()
                mock_clusters_instance.is_available.return_value = True
                mock_clusters_instance.get_clusters.return_value = mock_clusters
                mock_clusters_class.return_value = mock_clusters_instance

                yield


def _create_mock_graph_client():
    """Create a mock GraphClient for test fixtures."""
    mock_gc = MagicMock()

    def _query(cypher, **kwargs):
        if "MATCH (i:IDS)" in cypher:
            return [
                {
                    "name": "equilibrium",
                    "description": "Equilibrium quantities",
                    "physics_domain": "magnetics",
                    "lifecycle_status": "active",
                    "path_count": 5,
                },
                {
                    "name": "core_profiles",
                    "description": "Core plasma profiles",
                    "physics_domain": "core_transport",
                    "lifecycle_status": "active",
                    "path_count": 4,
                },
            ]
        if "DDVersion" in cypher and "is_current" in cypher:
            if "AS version" in cypher:
                return [{"version": "4.0.0"}]
            return [{"v.id": "4.0.0"}]
        if "RETURN 1" in cypher:
            return [{"1": 1}]
        if "IMASNode" in cypher and "count" in cypher.lower():
            return [{"paths": 9, "ids_count": 2}]
        return []

    mock_gc.query = MagicMock(side_effect=_query)
    return mock_gc


@pytest.fixture(scope="session")
def tools() -> Tools:
    """Session-scoped tools fixture with mock GraphClient."""
    mock_gc = _create_mock_graph_client()
    return Tools(ids_set=STANDARD_TEST_IDS_SET, graph_client=mock_gc)


@pytest.fixture
def sample_search_results() -> dict[str, Any]:
    """Sample search results for testing."""
    return {
        "results": [
            {
                "path": "core_profiles/profiles_1d/electrons/temperature",
                "ids_name": "core_profiles",
                "score": 0.95,
                "documentation": "Electron temperature profile",
            },
            {
                "path": "equilibrium/time_slice/profiles_1d/psi",
                "ids_name": "equilibrium",
                "score": 0.88,
                "documentation": "Poloidal flux profile",
            },
        ],
        "total_results": 2,
    }


@pytest.fixture
def mcp_test_context():
    """Test context for MCP protocol testing."""
    return {
        "test_query": "plasma temperature",
        "test_ids": "core_profiles",
        "expected_tools": [
            "check_imas_paths",
            "fetch_imas_paths",
            "get_imas_overview",
            "get_imas_identifiers",
            "list_imas_paths",
            "search_imas_clusters",
            "search_imas_paths",
        ],
    }


@pytest.fixture
def workflow_test_data():
    """Test data for workflow testing."""
    return {
        "search_query": "core plasma transport",
        "analysis_target": "core_profiles",
        "export_domain": "transport",
        "concept_to_explain": "equilibrium",
    }
