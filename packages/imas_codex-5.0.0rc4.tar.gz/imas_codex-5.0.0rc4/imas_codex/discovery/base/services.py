"""Service health monitoring for discovery CLI tools.

Provides a composable ``ServiceMonitor`` that polls external dependencies
(Neo4j, embedding server, SSH/VPN connectivity) at low frequency and
exposes live status for progress displays plus a gate that workers can
``await`` before processing.

Design principles:
- **Composable**: Register only the checks a particular CLI needs.
- **Low overhead**: Polls at configurable intervals (default 15s).
- **Worker-friendly**: ``await_services_ready()`` blocks workers when
  services are unhealthy and unblocks automatically on recovery.
- **Display-friendly**: ``get_status()`` returns a snapshot for the
  SERVERS progress row without blocking.

Usage::

    monitor = ServiceMonitor()
    monitor.add_check("graph", neo4j_health_check)
    monitor.add_check("ssh", lambda: ssh_health_check("jt-60sa"),
                       auth_label="vpn")

    async with monitor:
        # Start workers that gate on monitor
        while not should_stop():
            await monitor.await_services_ready()
            do_work()

The monitor integrates with the existing ``EmbeddingResilience`` module
by replacing the embed-specific polling with a unified service monitor,
while keeping the embed status accessible for backwards compatibility.
"""

from __future__ import annotations

import asyncio
import logging
import subprocess
import threading
import time
from dataclasses import dataclass
from enum import StrEnum
from typing import Any

logger = logging.getLogger(__name__)


# =============================================================================
# Service Status
# =============================================================================


class ServiceState(StrEnum):
    """Health state of a monitored service."""

    unknown = "unknown"  # Not yet checked
    healthy = "healthy"  # Service is operational
    degraded = "degraded"  # Partial availability
    unhealthy = "unhealthy"  # Service is down
    recovering = "recovering"  # Was down, attempting reconnect


@dataclass
class ServiceStatus:
    """Current status snapshot for a single service."""

    name: str
    state: ServiceState = ServiceState.unknown
    auth_label: str | None = None  # e.g., "vpn", "tequila", "ssh"
    detail: str = ""  # Human-readable detail (e.g., "bolt://localhost:7687")
    healthy_detail: str = ""  # Detail to show when grayed (stored on first success)
    last_check: float = 0.0
    last_healthy: float = 0.0
    consecutive_failures: int = 0
    check_latency_ms: float = 0.0

    # Cumulative health stats (Phase 2.3)
    total_checks: int = 0
    total_failures: int = 0
    _latency_sum: float = 0.0
    _latency_count: int = 0

    @property
    def is_healthy(self) -> bool:
        return self.state in (ServiceState.healthy, ServiceState.unknown)

    @property
    def downtime_seconds(self) -> float:
        """Seconds since last healthy check, or 0 if currently healthy."""
        if self.is_healthy or self.last_healthy == 0:
            return 0.0
        return time.time() - self.last_healthy

    @property
    def avg_latency_ms(self) -> float:
        """Average check latency in milliseconds."""
        if self._latency_count == 0:
            return 0.0
        return self._latency_sum / self._latency_count

    @property
    def failure_ratio(self) -> str:
        """Failure ratio as "N/M" string (failures/total checks)."""
        if self.total_checks == 0:
            return "0/0"
        return f"{self.total_failures}/{self.total_checks}"

    def record_check(self, healthy: bool, latency_ms: float) -> None:
        """Record a health check result for cumulative stats."""
        self.total_checks += 1
        if not healthy:
            self.total_failures += 1
        if healthy and latency_ms > 0:
            self._latency_sum += latency_ms
            self._latency_count += 1

    def format_health_summary(self) -> str:
        """Format as compact health summary for display.

        Example: ``jet (avg 2.3s, fail 3/100)``
        """
        parts = [self.detail or self.name]
        if self._latency_count > 0:
            avg_s = self.avg_latency_ms / 1000
            parts.append(f"avg {avg_s:.1f}s")
        if self.total_failures > 0:
            parts.append(f"fail {self.failure_ratio}")
        return f" ({', '.join(parts[1:])})" if len(parts) > 1 else ""


# =============================================================================
# Health Check Functions
# =============================================================================


def _get_service_display_label(location: str) -> str:
    """Get the display label for a service at the given location.

    Resolves compute locations (e.g. ``"titan"``) to their display name
    directly.  The location string is already the label.
    """
    return location


def get_graph_display_label() -> str:
    """Get the display label for the graph service."""
    try:
        from imas_codex.graph.profiles import get_graph_location

        return _get_service_display_label(get_graph_location())
    except Exception:
        return "unknown"


def neo4j_health_check() -> tuple[bool, str]:
    """Check Neo4j connectivity via bolt protocol.

    Returns:
        (healthy, detail) tuple where detail shows location and scheduler
        context (e.g., ``"iter (slurm)"``).
    """
    try:
        from imas_codex.graph.client import GraphClient

        with GraphClient() as gc:
            result = gc.query("RETURN 1 AS ok")
            if result and result[0]["ok"] == 1:
                return True, get_graph_display_label()
        return False, "query returned unexpected result"
    except Exception as e:
        return False, str(e)[:100]


def ssh_health_check(ssh_host: str, timeout: int = 10) -> tuple[bool, str]:
    """Check SSH connectivity to a remote host.

    Delegates to :func:`~imas_codex.remote.executor.ssh_preflight` — the
    canonical SSH connectivity check that handles socket directory creation,
    stale socket cleanup, and retry logic.

    For VPN-gated hosts (like jt-60sa), this implicitly validates VPN
    status since SSH will fail if the VPN tunnel is down.

    Args:
        ssh_host: SSH host alias (from ~/.ssh/config)
        timeout: Connection timeout in seconds

    Returns:
        (healthy, detail) tuple
    """
    from imas_codex.remote.executor import ssh_preflight

    return ssh_preflight(ssh_host, timeout=timeout, retry=True)


def wiki_auth_check(
    url: str, ssh_host: str | None = None, timeout: int = 10
) -> tuple[bool, str]:
    """Check that a wiki URL is reachable.

    Tests HTTP access to the primary wiki page.  For tunnel/VPN sites
    this goes through the local port-forward; for SSH sites it curls
    via the remote host.

    Any HTTP response (including 401, 403, 404) is treated as healthy —
    it means the server is reachable and responding.  Only network-level
    failures (timeout, connection refused, DNS errors) are unhealthy.
    Workers handle authentication separately via session cookies / credentials.

    Args:
        url: Primary wiki URL to probe
        ssh_host: If set, fetch via ``ssh <host> curl``
        timeout: Connection timeout in seconds

    Returns:
        (healthy, detail) tuple
    """
    try:
        if ssh_host:
            cmd = f'curl -sk --noproxy "*" -o /dev/null -w "%{{http_code}}" "{url}" 2>/dev/null'
            result = subprocess.run(
                [
                    "ssh",
                    "-o",
                    f"ConnectTimeout={timeout}",
                    "-o",
                    "BatchMode=yes",
                    ssh_host,
                    cmd,
                ],
                capture_output=True,
                timeout=timeout + 15,
            )
            if result.returncode == 0:
                code = result.stdout.decode().strip()
                # Any HTTP response means the server is reachable
                if code.isdigit() and int(code) > 0:
                    return True, url
                return False, f"HTTP {code}"
            return False, "ssh+curl failed"
        else:
            import urllib.error
            import urllib.request

            req = urllib.request.Request(url, method="HEAD")
            try:
                with urllib.request.urlopen(req, timeout=timeout):
                    return True, url
            except urllib.error.HTTPError:
                # Any HTTP error (401, 403, 404, 500) = server is reachable
                return True, url
    except subprocess.TimeoutExpired:
        return False, f"timeout ({timeout}s)"
    except Exception as e:
        return False, str(e)[:80]


def embed_health_check() -> tuple[bool, str]:
    """Check embedding server health.

    Returns:
        (healthy, detail) tuple where detail is the location name
        (e.g. ``"titan"``) or ``"local"``.
    """
    try:
        from imas_codex.embeddings.client import RemoteEmbeddingClient
        from imas_codex.settings import (
            get_embed_remote_url,
            get_embedding_location,
        )

        location = get_embedding_location()

        url = get_embed_remote_url()
        if not url:
            return True, "local"

        label = _get_service_display_label(location)

        client = RemoteEmbeddingClient(url)
        try:
            if client.is_available(timeout=5.0):
                return True, label
            return False, "server unavailable"
        finally:
            client.close()
    except Exception as e:
        return False, str(e)[:100]


def llm_health_check(section: str = "language") -> tuple[bool, str]:
    """Check LLM provider health via the proxy's ``/health`` endpoint.

    When a LiteLLM proxy is configured (``[llm].location`` is set),
    probes ``GET /health`` with the master key.  This is lightweight
    (no token cost), fast, and returns healthy/unhealthy model counts.

    Falls back to a minimal ``litellm.completion()`` call when no
    proxy is configured (``location=local``).

    Args:
        section: Model section to check (language, vision, etc.)

    Returns:
        (healthy, detail) tuple where detail is the proxy location
    """
    import os

    from imas_codex.settings import get_llm_location

    llm_location = get_llm_location()

    # --- Proxy mode: lightweight HTTP probe ---
    if llm_location != "local" or os.getenv("LITELLM_PROXY_URL"):
        return _probe_litellm_proxy(llm_location)

    # --- Local mode: minimal completion call ---
    return _probe_litellm_local(section)


def _get_host_load() -> tuple[float, int] | None:
    """Read 1-minute load average and CPU count from ``/proc/loadavg``.

    Returns:
        (load_1min, ncpus) or None if unavailable.
    """
    import os

    try:
        with open("/proc/loadavg") as f:
            load_1min = float(f.read().split()[0])
        ncpus = os.cpu_count() or 1
        return load_1min, ncpus
    except (OSError, ValueError):
        return None


def _format_load_detail(location: str, suffix: str = "") -> str:
    """Append normalized load indicator to a location label.

    Shows ``location ↑0.62`` (load per-core, clamped to 0–1) when
    load per-core exceeds 0.5, otherwise returns the plain location
    (with optional suffix).
    """
    load_info = _get_host_load()
    detail = f"{location}{suffix}" if suffix else location
    if load_info is None:
        return detail
    load_1min, ncpus = load_info
    load_per_core = load_1min / ncpus
    if load_per_core >= 0.5:
        normalized = min(load_per_core, 1.0)
        return f"{detail} ↑{normalized:.0%}"
    return detail


def _probe_litellm_proxy(location: str) -> tuple[bool, str]:
    """Probe LiteLLM proxy via its ``/health`` endpoint."""
    import json
    import os
    import urllib.error
    import urllib.request

    from imas_codex.settings import get_llm_proxy_url

    proxy_url = get_llm_proxy_url()
    health_url = f"{proxy_url}/health"
    api_key = os.getenv("LITELLM_MASTER_KEY", "")

    try:
        req = urllib.request.Request(health_url)
        if api_key:
            req.add_header("Authorization", f"Bearer {api_key}")
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read())
            healthy_count = data.get("healthy_count", 0)
            unhealthy_count = data.get("unhealthy_count", 0)
            if healthy_count > 0 and unhealthy_count == 0:
                return True, _format_load_detail(location)
            if healthy_count > 0:
                # Check unhealthy reasons for budget/credit exhaustion
                reason = _classify_unhealthy_reason(data)
                suffix = (
                    f" ({unhealthy_count} {reason})"
                    if reason
                    else f" ({unhealthy_count} degraded)"
                )
                return True, _format_load_detail(location, suffix)
            # No healthy models — check if budget is the cause
            reason = _classify_unhealthy_reason(data)
            return False, reason or "no healthy models"
    except urllib.error.HTTPError as e:
        if e.code == 401:
            return False, "auth error (401)"
        return False, f"HTTP {e.code}"
    except urllib.error.URLError as e:
        reason = str(e.reason).lower()
        if "refused" in reason:
            return False, "proxy refused"
        if "timed out" in reason or "timeout" in reason:
            return False, "proxy timeout"
        return False, str(e.reason)[:60]
    except Exception as e:
        return False, str(e)[:80]


def _classify_unhealthy_reason(data: dict) -> str | None:
    """Extract a human-readable reason from proxy ``/health`` unhealthy endpoints.

    Checks ``unhealthy_endpoints`` for common error patterns (budget exhaustion,
    rate limiting, auth errors) and returns a concise label. Returns None if
    no specific reason can be identified.
    """
    unhealthy = data.get("unhealthy_endpoints") or []
    if not unhealthy:
        return None

    # Collect error messages from unhealthy endpoints
    errors = []
    for ep in unhealthy:
        error = ""
        if isinstance(ep, dict):
            error = str(ep.get("error", "") or ep.get("error_message", "")).lower()
        elif isinstance(ep, str):
            error = ep.lower()
        if error:
            errors.append(error)

    if not errors:
        return None

    # Check for budget/credit exhaustion (most actionable)
    budget_keywords = ("402", "credit", "budget", "quota", "payment required", "afford")
    if any(kw in err for err in errors for kw in budget_keywords):
        return "no credit"

    # Rate limiting
    if any("429" in err or "rate limit" in err for err in errors):
        return "rate limited"

    # Auth errors
    if any("401" in err or "auth" in err or "api_key" in err for err in errors):
        return "auth error"

    return None


def _probe_litellm_local(section: str) -> tuple[bool, str]:
    """Probe a local LLM via a minimal completion call."""
    try:
        from imas_codex.settings import get_model

        model = get_model(section)

        from imas_codex.discovery.base.llm import set_litellm_offline_env

        set_litellm_offline_env()
        import litellm

        litellm.drop_params = True
        response = litellm.completion(
            model=model,
            messages=[{"role": "user", "content": "ping"}],
            max_tokens=1,
            temperature=0,
            timeout=30,
        )
        if response and response.choices:
            return True, "local"
        return False, "no response"
    except Exception as e:
        err = str(e).lower()
        if "402" in err or "insufficient" in err or "budget" in err:
            return False, "no credit (402)"
        if "401" in err or "invalid api key" in err or "authentication" in err:
            return False, "auth error (401)"
        if "429" in err or "rate limit" in err:
            return False, "rate limited (429)"
        return False, str(e)[:80]


# =============================================================================
# Service Check Configuration
# =============================================================================


@dataclass
class ServiceCheck:
    """Configuration for a single service health check."""

    name: str
    check_fn: Any  # Callable[[], tuple[bool, str]]
    auth_label: str | None = None  # Display label: "vpn", "ssh", etc.
    poll_interval: float = 15.0  # Seconds between checks
    critical: bool = True  # If True, workers pause when unhealthy


# =============================================================================
# Service Monitor
# =============================================================================


class ServiceMonitor:
    """Async service health monitor with worker gating.

    Runs periodic health checks in the background and provides:
    - ``get_status()`` for progress display (non-blocking)
    - ``await_services_ready()`` for workers (blocks until all critical
      services are healthy)
    - ``paused`` property for quick boolean check

    Thread-safe: status is read from the display thread, written from
    the async polling loop.
    """

    def __init__(self, poll_interval: float = 15.0) -> None:
        self._checks: list[ServiceCheck] = []
        self._status: dict[str, ServiceStatus] = {}
        self._lock = threading.Lock()
        self._ready_event: asyncio.Event | None = None
        self._poll_task: asyncio.Task | None = None
        self._default_poll_interval = poll_interval
        self._stopped = False

    # ------------------------------------------------------------------
    # Configuration (before start)
    # ------------------------------------------------------------------

    def add_check(
        self,
        name: str,
        check_fn: Any,
        auth_label: str | None = None,
        poll_interval: float | None = None,
        critical: bool = True,
    ) -> None:
        """Register a service health check.

        Args:
            name: Service name (e.g., "graph", "embed", "ssh")
            check_fn: Callable returning (healthy: bool, detail: str)
            auth_label: Auth method label for display (e.g., "vpn")
            poll_interval: Override default poll interval for this check
            critical: If True, workers pause when this service is unhealthy
        """
        check = ServiceCheck(
            name=name,
            check_fn=check_fn,
            auth_label=auth_label,
            poll_interval=poll_interval or self._default_poll_interval,
            critical=critical,
        )
        self._checks.append(check)
        self._status[name] = ServiceStatus(
            name=name,
            auth_label=auth_label,
        )

    # ------------------------------------------------------------------
    # Status queries (thread-safe)
    # ------------------------------------------------------------------

    def get_status(self) -> list[ServiceStatus]:
        """Get current status of all monitored services.

        Thread-safe: can be called from the display thread.
        """
        with self._lock:
            return list(self._status.values())

    def get_service_status(self, name: str) -> ServiceStatus | None:
        """Get status for a specific service."""
        with self._lock:
            return self._status.get(name)

    @property
    def paused(self) -> bool:
        """True if any critical service is unhealthy."""
        with self._lock:
            return any(
                not status.is_healthy
                for check in self._checks
                if check.critical
                for status in [self._status.get(check.name)]
                if status is not None
            )

    @property
    def all_healthy(self) -> bool:
        """True if all services are healthy."""
        return not self.paused

    def is_service_healthy(self, *names: str) -> bool:
        """Check whether specific services are healthy.

        Workers that only depend on a subset of services can check
        just those instead of the global ``all_healthy``.

        Args:
            names: Service names to check (e.g., "ssh", "auth")

        Returns:
            True if ALL named services are currently healthy.
        """
        with self._lock:
            for name in names:
                status = self._status.get(name)
                if status is not None and not status.is_healthy:
                    return False
            return True

    # ------------------------------------------------------------------
    # Worker gating (async)
    # ------------------------------------------------------------------

    async def await_services_ready(self, timeout: float = 0) -> bool:
        """Block until all critical services are healthy.

        Args:
            timeout: Max seconds to wait (0 = wait indefinitely)

        Returns:
            True when services are ready, False if timeout exceeded
        """
        if self.all_healthy:
            return True

        if self._ready_event is None:
            return True  # Not started yet, don't block

        logger.info(
            "Services unhealthy, pausing workers: %s",
            ", ".join(
                s.name
                for s in self.get_status()
                if not s.is_healthy
                and any(c.critical for c in self._checks if c.name == s.name)
            ),
        )

        if timeout > 0:
            try:
                await asyncio.wait_for(self._wait_for_ready(), timeout=timeout)
                return True
            except TimeoutError:
                return False
        else:
            await self._wait_for_ready()
            return True

    async def _wait_for_ready(self) -> None:
        """Wait until the ready event is set."""
        while not self.all_healthy:
            if self._ready_event is not None:
                self._ready_event.clear()
                await self._ready_event.wait()
            else:
                await asyncio.sleep(1.0)

    # ------------------------------------------------------------------
    # Lifecycle (async context manager)
    # ------------------------------------------------------------------

    async def __aenter__(self) -> ServiceMonitor:
        """Start the background polling loop."""
        self._ready_event = asyncio.Event()
        self._ready_event.set()  # Start optimistic
        self._stopped = False

        # Run initial checks synchronously to get baseline
        await self._run_all_checks()

        # Start background polling
        self._poll_task = asyncio.create_task(self._poll_loop())
        return self

    async def __aexit__(self, *args) -> None:
        """Stop the background polling loop."""
        self._stopped = True
        if self._poll_task:
            self._poll_task.cancel()
            try:
                await self._poll_task
            except asyncio.CancelledError:
                pass

    # ------------------------------------------------------------------
    # Internal polling
    # ------------------------------------------------------------------

    async def _poll_loop(self) -> None:
        """Background polling loop with per-check intervals."""
        # Track last check time per service
        last_checked: dict[str, float] = {c.name: 0.0 for c in self._checks}

        while not self._stopped:
            try:
                now = time.time()
                tasks = []

                for check in self._checks:
                    # Check if it's time to poll this service
                    elapsed = now - last_checked[check.name]

                    # Poll more frequently when unhealthy (backoff: min 5s)
                    status = self._status.get(check.name)
                    interval = check.poll_interval
                    if status and not status.is_healthy:
                        interval = max(5.0, interval / 3)

                    if elapsed >= interval:
                        last_checked[check.name] = now
                        tasks.append(self._run_check(check))

                if tasks:
                    await asyncio.gather(*tasks, return_exceptions=True)

                    # Update ready event
                    if self.all_healthy:
                        if self._ready_event and not self._ready_event.is_set():
                            logger.info("All services healthy, resuming workers")
                            self._ready_event.set()
                    else:
                        if self._ready_event and self._ready_event.is_set():
                            self._ready_event.clear()

                await asyncio.sleep(1.0)  # Check schedule every second

            except asyncio.CancelledError:
                raise
            except Exception as e:
                logger.debug("Service monitor poll error: %s", e)
                await asyncio.sleep(5.0)

    async def _run_all_checks(self) -> None:
        """Run all checks once (used for initial baseline)."""
        tasks = [self._run_check(check) for check in self._checks]
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

    async def _run_check(self, check: ServiceCheck) -> None:
        """Run a single health check in a thread pool."""
        start = time.time()
        try:
            healthy, detail = await asyncio.to_thread(check.check_fn)
            latency_ms = (time.time() - start) * 1000

            with self._lock:
                status = self._status[check.name]
                status.last_check = time.time()
                status.check_latency_ms = latency_ms
                status.detail = detail
                status.record_check(healthy, latency_ms)

                if healthy:
                    if not status.is_healthy:
                        logger.info(
                            "Service %s recovered (was down for %.0fs)",
                            check.name,
                            status.downtime_seconds,
                        )
                    status.state = ServiceState.healthy
                    status.last_healthy = time.time()
                    status.consecutive_failures = 0
                    status.healthy_detail = detail  # Save for grayed display when down
                else:
                    status.consecutive_failures += 1
                    if status.state == ServiceState.healthy:
                        logger.warning(
                            "Service %s became unhealthy: %s",
                            check.name,
                            detail,
                        )
                    status.state = ServiceState.unhealthy

        except Exception as e:
            with self._lock:
                status = self._status[check.name]
                status.state = ServiceState.unhealthy
                status.detail = str(e)[:100]
                status.consecutive_failures += 1
                status.last_check = time.time()


# =============================================================================
# Factory for common configurations
# =============================================================================


def create_service_monitor(
    facility: str | None = None,
    ssh_host: str | None = None,
    access_method: str | None = None,
    auth_type: str | None = None,
    wiki_url: str | None = None,
    check_graph: bool = True,
    check_embed: bool = True,
    check_ssh: bool = True,
    check_auth: bool = True,
    check_model: bool = False,
    model_section: str = "language",
    poll_interval: float = 15.0,
) -> ServiceMonitor:
    """Create a ServiceMonitor with standard checks for discovery CLIs.

    Registers separate checks for each concern:

    - ``graph``: Neo4j connectivity
    - ``embed``: Embedding server health
    - ``llm``: LLM service health (LiteLLM proxy)
    - ``ssh``: SSH connectivity to remote host (critical — workers pause)
    - ``auth``: Wiki page reachability via HTTP (critical — workers pause)

    Args:
        facility: Facility ID (for loading config)
        ssh_host: SSH host alias for connectivity check
        access_method: Access method ("vpn", "tunnel", "direct", etc.)
        auth_type: Web auth type ("tequila", "keycloak", "basic", "vpn", etc.)
        wiki_url: Primary wiki URL for auth/reachability probing
        check_graph: Include Neo4j health check
        check_embed: Include embedding server health check
        check_ssh: Include SSH connectivity check
        check_auth: Include wiki auth/reachability check
        check_model: Include LLM provider health check
        model_section: Model section to monitor (default: "language")
        poll_interval: Default polling interval in seconds

    Returns:
        Configured (but not started) ServiceMonitor
    """
    monitor = ServiceMonitor(poll_interval=poll_interval)

    if check_graph:
        monitor.add_check(
            "graph",
            neo4j_health_check,
            poll_interval=30.0,  # Graph rarely goes down
            critical=True,
        )

    if check_embed:
        monitor.add_check(
            "embed",
            embed_health_check,
            poll_interval=20.0,
            critical=False,  # Ingest workers handle this via EmbeddingResilience
        )

    if check_model:
        monitor.add_check(
            "llm",
            lambda sec=model_section: llm_health_check(sec),
            poll_interval=60.0,  # LLM APIs are generally stable
            critical=False,  # Workers have their own retry logic
        )

    if check_ssh and ssh_host:
        monitor.add_check(
            "ssh",
            lambda host=ssh_host: ssh_health_check(host),
            poll_interval=poll_interval,
            critical=True,  # Workers need SSH to fetch content
        )

    if check_auth and wiki_url:
        # Determine effective auth label for display
        if access_method in ("vpn", "tunnel"):
            effective_auth = "vpn"
        elif auth_type and auth_type != "none":
            effective_auth = auth_type
        else:
            effective_auth = "http"

        # Determine whether wiki probe goes through SSH or direct HTTP.
        # Tunnel and VPN sites both curl via SSH (workers do the same),
        # so the auth check should validate the same path.
        if access_method in ("tunnel", "vpn") and ssh_host:
            _probe_ssh = ssh_host
        elif ssh_host and access_method not in ("direct",):
            _probe_ssh = ssh_host  # SSH-only sites curl via SSH
        else:
            _probe_ssh = None  # Direct HTTP sites

        def _auth_check(
            url: str = wiki_url,
            host: str | None = _probe_ssh,
            label: str = effective_auth,
        ) -> tuple[bool, str]:
            healthy, detail = wiki_auth_check(url, host)
            if healthy:
                return True, label  # Display label, not URL
            return False, detail

        monitor.add_check(
            "auth",
            _auth_check,
            auth_label=effective_auth,
            poll_interval=poll_interval,
            critical=True,  # Workers need wiki access
        )

    return monitor


# =============================================================================
# Display helpers
# =============================================================================


def build_servers_row(
    statuses: list[ServiceStatus],
    width: int = 80,
) -> str | None:
    """Build a SERVERS row string for progress displays.

    Returns None if no services are registered.

    Format:
      SERVERS  graph:healthy(bolt://localhost:7687)  embed:healthy(iter-login)  ssh:healthy(vpn)
    """
    if not statuses:
        return None

    parts: list[tuple[str, str]] = []  # (text, style)

    for s in statuses:
        # Build compact status string
        if s.state == ServiceState.healthy:
            style = "green"
            state_str = s.detail or "ok"
        elif s.state == ServiceState.unknown:
            style = "dim"
            state_str = "pending"
        elif s.state == ServiceState.recovering:
            style = "yellow"
            state_str = f"recovering ({int(s.downtime_seconds)}s)"
        else:
            # Unhealthy: show grayed version of healthy state, not red error
            style = "dim"
            if s.healthy_detail:
                state_str = s.healthy_detail
            elif s.auth_label:
                state_str = f"{s.auth_label}"
            else:
                state_str = "down"
            if s.downtime_seconds > 0:
                state_str += f" ({int(s.downtime_seconds)}s)"

        parts.append((f"{s.name}:{state_str}", style))

    return parts  # type: ignore[return-value]


__all__ = [
    "ServiceMonitor",
    "ServiceState",
    "ServiceStatus",
    "build_servers_row",
    "create_service_monitor",
    "embed_health_check",
    "get_graph_display_label",
    "llm_health_check",
    "neo4j_health_check",
    "ssh_health_check",
]
