"""Wiki ingestion pipeline using LlamaIndex.

Processes wiki pages and documents through a deterministic pipeline:
1. Scan: Discover pages/documents via link traversal (creates nodes with status='scanned')
2. Score: Agent evaluates score_composite (sets status='scored' or 'skipped')
3. Ingest: Fetch content, chunk, embed, and link to graph (sets status='ingested')

The pipeline is graph-driven and fully deterministic (no LLM calls during ingestion).
Entity extraction uses regex patterns for MDSplus paths, IMAS paths, units, conventions.

Example:
    # Step 1: Scan wiki (link extraction, no content fetch)
    # imas-codex wiki scan tcv

    # Step 2: Score pages with LLM agent
    # imas-codex wiki score tcv

    # Step 3: Ingest high-score pages (deterministic)
    pipeline = WikiIngestionPipeline(facility_id="tcv")
    stats = await pipeline.ingest_from_graph(min_score_composite=0.7)
    print(f"Created {stats['chunks']} chunks")
"""

from __future__ import annotations

import hashlib
import logging
import re
from collections.abc import Callable
from html.parser import HTMLParser
from typing import TYPE_CHECKING, Any, TypedDict

from imas_codex.graph import GraphClient
from imas_codex.ingestion.chunkers import chunk_text as _chunk_text
from imas_codex.settings import get_embedding_dimension

from .monitor import WikiProgressMonitor, set_current_monitor
from .scraper import WikiPage, fetch_wiki_page

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)

# Batch size for UNWIND operations
BATCH_SIZE = 50

# Progress callback type: (current, total, message) -> None
ProgressCallback = Callable[[int, int, str], None]


class PageIngestionStats(TypedDict):
    """Statistics from ingesting a single wiki page."""

    chunks: int
    data_nodes_linked: int
    imas_paths_linked: int
    conventions: int
    units: int
    content_preview: str
    mdsplus_paths: list[str]


# =============================================================================
# Graph Query Functions
# =============================================================================


def get_pending_wiki_pages(
    facility_id: str,
    limit: int | None = None,
    min_score_composite: float = 0.5,
) -> list[dict]:
    """Get wiki pages pending ingestion from the graph.

    Returns WikiPage nodes with status='scored' (passed agent evaluation),
    sorted by score_composite descending.

    Args:
        facility_id: Facility ID
        limit: Maximum pages to return (None for all)
        min_score_composite: Minimum interest score threshold

    Returns:
        List of page dicts with id, url, title, score_composite
    """
    # Build query with optional LIMIT clause
    query = """
        MATCH (wp:WikiPage {facility_id: $facility_id, status: 'scored'})
        WHERE wp.score_composite >= $min_score
        RETURN wp.id AS id, wp.url AS url, wp.title AS title,
               wp.score_composite AS score_composite
        ORDER BY wp.score_composite DESC, wp.discovered_at ASC
    """
    if limit is not None:
        query += f"LIMIT {limit}"

    with GraphClient() as gc:
        result = gc.query(
            query,
            facility_id=facility_id,
            min_score=min_score_composite,
        )
        return [dict(r) for r in result] if result else []


def get_wiki_queue_stats(facility_id: str) -> dict:
    """Get wiki page queue statistics by status.

    Args:
        facility_id: Facility ID

    Returns:
        Dict with status counts for pages and documents
    """
    with GraphClient() as gc:
        result = gc.query(
            """
            MATCH (wp:WikiPage {facility_id: $facility_id})
            RETURN wp.status AS status, count(*) AS count
            ORDER BY count DESC
            """,
            facility_id=facility_id,
        )

        # Initialize with zero counts for all expected statuses
        stats = {
            "scanned": 0,
            "scored": 0,
            "skipped": 0,
            "ingested": 0,
            "failed": 0,
            "stale": 0,
            "total": 0,
        }

        if result:
            for r in result:
                status = r["status"]
                count = r["count"]
                if status in stats:
                    stats[status] = count
                stats["total"] += count

        return stats


def get_pending_wiki_documents(
    facility_id: str,
    limit: int | None = None,
    min_score_composite: float = 0.5,
) -> list[dict]:
    """Get wiki documents pending ingestion from the graph.

    Returns Document nodes with status='scored' (passed agent evaluation),
    sorted by score_composite descending.

    Args:
        facility_id: Facility ID
        limit: Maximum documents to return (None for all)
        min_score_composite: Minimum interest score threshold

    Returns:
        List of document dicts with id, url, filename, document_type, score_composite
    """
    # Build query with optional LIMIT clause
    query = """
        MATCH (wa:Document {facility_id: $facility_id, status: 'scored'})
        WHERE wa.score_composite >= $min_score
        RETURN wa.id AS id, wa.url AS url, wa.filename AS filename,
               wa.document_type AS document_type,
               wa.score_composite AS score_composite
        ORDER BY wa.score_composite DESC
    """
    if limit is not None:
        query += f"LIMIT {limit}"

    with GraphClient() as gc:
        result = gc.query(
            query,
            facility_id=facility_id,
            min_score=min_score_composite,
        )
        return [dict(r) for r in result] if result else []


def mark_wiki_page_status(
    page_id: str,
    status: str,
    error: str | None = None,
) -> None:
    """Update the status of a wiki page.

    Args:
        page_id: WikiPage ID
        status: New status (scanned, scored, skipped, ingested, failed, stale)
        error: Error message if status is 'failed'
    """
    with GraphClient() as gc:
        gc.query(
            """
            MATCH (wp:WikiPage {id: $id})
            SET wp.status = $status,
                wp.error = $error
            """,
            id=page_id,
            status=status,
            error=error,
        )


def persist_chunks_batch(chunks: list[dict]) -> int:
    """Persist a batch of WikiChunk nodes using UNWIND for efficiency.

    Args:
        chunks: List of chunk dicts with required fields:
            - id, wiki_page_id, facility_id, content, embedding
            - mdsplus_paths, imas_paths, units, conventions (optional)

    Returns:
        Number of chunks persisted
    """
    if not chunks:
        return 0

    with GraphClient() as gc:
        gc.query(
            """
            UNWIND $chunks AS chunk
            MERGE (c:WikiChunk {id: chunk.id})
            SET c.wiki_page_id = chunk.wiki_page_id,
                c.facility_id = chunk.facility_id,
                c.text = chunk.text,
                c.embedding = chunk.embedding,
                c.mdsplus_paths_mentioned = chunk.mdsplus_paths,
                c.imas_paths_mentioned = chunk.imas_paths,
                c.units_mentioned = chunk.units,
                c.conventions_mentioned = chunk.conventions
            WITH c, chunk
            MATCH (p:WikiPage {id: chunk.wiki_page_id})
            MERGE (p)-[:HAS_CHUNK]->(c)
            WITH c, chunk
            MATCH (f:Facility {id: chunk.facility_id})
            MERGE (c)-[:AT_FACILITY]->(f)
            """,
            chunks=chunks,
        )
        return len(chunks)


def link_chunks_to_entities(facility_id: str) -> dict[str, int]:
    """Create DOCUMENTS and MENTIONS relationships from chunk metadata.

    Uses batched queries to link WikiChunks to graph entities based on
    the paths stored in chunk properties during ingestion:
    - MDSplus paths → SignalNode (DOCUMENTS relationship)
    - IMAS paths → IMASNode (MENTIONS_IMAS relationship)
    - PPF paths → FacilitySignal (DOCUMENTS relationship)

    Args:
        facility_id: Facility to process

    Returns:
        Dict with counts: {data_nodes_linked, imas_paths_linked, ppf_signals_linked}
    """
    stats = {"data_nodes_linked": 0, "imas_paths_linked": 0, "ppf_signals_linked": 0}

    with GraphClient() as gc:
        # Link to DataNodes via MDSplus paths
        result = gc.query(
            """
            MATCH (c:WikiChunk {facility_id: $facility_id})
            WHERE c.mdsplus_paths_mentioned IS NOT NULL
               AND size(c.mdsplus_paths_mentioned) > 0
            UNWIND c.mdsplus_paths_mentioned AS mds_path
            MATCH (t:SignalNode)
            WHERE t.path = mds_path
               OR t.path ENDS WITH replace(mds_path, '\\\\', '')
               OR t.canonical_path = toUpper(mds_path)
            MERGE (c)-[:DOCUMENTS]->(t)
            RETURN count(*) AS linked
            """,
            facility_id=facility_id,
        )
        if result:
            stats["data_nodes_linked"] = result[0]["linked"]

        # Link to IMASNode nodes via IMAS DD paths
        result = gc.query(
            """
            MATCH (c:WikiChunk {facility_id: $facility_id})
            WHERE c.imas_paths_mentioned IS NOT NULL
               AND size(c.imas_paths_mentioned) > 0
            UNWIND c.imas_paths_mentioned AS imas_path
            MATCH (ip:IMASNode)
            WHERE ip.id = imas_path
               OR ip.id STARTS WITH imas_path + '/'
            WITH c, ip
            LIMIT 1000
            MERGE (c)-[:MENTIONS_IMAS]->(ip)
            RETURN count(*) AS linked
            """,
            facility_id=facility_id,
        )
        if result:
            stats["imas_paths_linked"] = result[0]["linked"]

        # Link to FacilitySignal nodes via PPF paths (JET)
        result = gc.query(
            """
            MATCH (c:WikiChunk {facility_id: $facility_id})
            WHERE c.ppf_paths_mentioned IS NOT NULL
               AND size(c.ppf_paths_mentioned) > 0
            UNWIND c.ppf_paths_mentioned AS ppf_path
            MATCH (fs:FacilitySignal {facility_id: $facility_id})
            WHERE fs.id ENDS WITH ppf_path
               OR fs.name = ppf_path
            MERGE (c)-[:DOCUMENTS]->(fs)
            RETURN count(*) AS linked
            """,
            facility_id=facility_id,
        )
        if result:
            stats["ppf_signals_linked"] = result[0]["linked"]

    return stats


class MediaWikiExtractor(HTMLParser):
    """MediaWiki-aware HTML to text converter.

    Targets the main content area (mw-parser-output) and skips
    navigation, sidebar, and footer elements.
    """

    # Tags that should be completely skipped
    SKIP_TAGS = {"script", "style", "nav", "footer", "header", "noscript"}

    # CSS classes that indicate navigation/sidebar content to skip
    SKIP_CLASSES = {
        "mw-navigation",
        "mw-sidebar",
        "mw-footer",
        "printfooter",
        "catlinks",
        "mw-editsection",
        "noprint",
        "toc",
        "navbox",
        "metadata",
        "mw-jump-link",
        "portal",
        "portlet",
        "p-personal",
        "p-navigation",
        "p-search",
        "p-tb",
        "p-coll-print_export",
    }

    # CSS classes that indicate main content
    CONTENT_CLASSES = {"mw-parser-output", "mw-body-content", "mw-content-text"}

    def __init__(self):
        super().__init__()
        self.text_parts: list[str] = []
        self.current_section: str = ""
        self.sections: dict[str, str] = {}
        self._section_start: int = 0  # Index into text_parts for current section
        self._skip_depth = 0
        self._skip_inline: list[str] = []  # Non-div tags skipped by id/class
        self._content_depth = 0
        self._in_heading = False
        self._heading_text = ""
        self._in_table = False
        self._table_row: list[str] = []
        self._table_header_emitted = False
        self._current_row_is_header = False
        self._in_cell = False
        self._cell_text: list[str] = []
        self._in_pre = False
        self._skipping_div = 0  # Track divs we're skipping

    def _get_class(self, attrs: list[tuple[str, str | None]]) -> set[str]:
        """Extract CSS classes from tag attributes."""
        for name, value in attrs:
            if name == "class" and value:
                return set(value.split())
        return set()

    def _get_id(self, attrs: list[tuple[str, str | None]]) -> str | None:
        """Extract id from tag attributes."""
        for name, value in attrs:
            if name == "id":
                return value
        return None

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        classes = self._get_class(attrs)
        element_id = self._get_id(attrs)

        # Check if this element should be skipped
        if tag in self.SKIP_TAGS:
            self._skip_depth += 1
            return

        if classes & self.SKIP_CLASSES:
            self._skip_depth += 1
            if tag == "div":
                self._skipping_div += 1
            else:
                self._skip_inline.append(tag)
            return

        # Skip by ID patterns (common MediaWiki navigation)
        if element_id:
            # Skip navigation/sidebar divs by ID
            skip_ids = ("jump-to-nav", "siteSub", "contentSub")
            if element_id in skip_ids or element_id.startswith(
                ("mw-", "p-", "ca-", "n-")
            ):
                if element_id not in ("mw-content-text", "mw-body-content"):
                    self._skip_depth += 1
                    if tag == "div":
                        self._skipping_div += 1
                    else:
                        self._skip_inline.append(tag)
                    return

        # Track when we enter content area
        if classes & self.CONTENT_CLASSES:
            self._content_depth += 1

        # Handle specific content tags
        if tag in ("h1", "h2", "h3", "h4", "h5"):
            self._in_heading = True
            self._heading_text = ""
        elif tag == "table":
            self._in_table = True
            self._table_header_emitted = False
        elif tag == "tr":
            self._table_row = []
            self._current_row_is_header = False
        elif tag in ("td", "th"):
            self._in_cell = True
            self._cell_text = []
            if tag == "th":
                self._current_row_is_header = True
        elif tag == "pre":
            self._in_pre = True
            self.text_parts.append("\n```\n")

    def handle_endtag(self, tag: str) -> None:
        if tag in self.SKIP_TAGS:
            self._skip_depth = max(0, self._skip_depth - 1)
            return

        # Handle end of non-div tags that were skipped by id/class
        if self._skip_inline and tag == self._skip_inline[-1]:
            self._skip_inline.pop()
            self._skip_depth = max(0, self._skip_depth - 1)
            return

        # Track end of skipped divs
        if tag == "div" and self._skipping_div > 0:
            self._skipping_div -= 1
            self._skip_depth = max(0, self._skip_depth - 1)
            return

        # Check for skip class divs - we don't track which specific div
        # so we just decrement if we're in a skip state
        if tag == "div" and self._skip_depth > 0:
            self._skip_depth = max(0, self._skip_depth - 1)
            return

        if tag in ("h1", "h2", "h3", "h4", "h5"):
            self._in_heading = False
            if self._heading_text.strip():
                # Save previous section
                if self.current_section:
                    section_text = " ".join(self.text_parts[self._section_start :])
                    if section_text.strip():
                        self.sections[self.current_section] = section_text
                self.current_section = self._heading_text.strip()
                self._section_start = len(self.text_parts)
                self.text_parts.append(f"\n## {self._heading_text.strip()}\n")
        elif tag == "table":
            self._in_table = False
            self.text_parts.append("\n")
        elif tag == "tr":
            if self._table_row:
                row_text = "| " + " | ".join(self._table_row) + " |"
                self.text_parts.append(row_text + "\n")
                # Emit markdown separator after first header row
                if self._current_row_is_header and not self._table_header_emitted:
                    separator = "| " + " | ".join("---" for _ in self._table_row) + " |"
                    self.text_parts.append(separator + "\n")
                    self._table_header_emitted = True
            self._table_row = []
        elif tag in ("td", "th"):
            # Finalize cell text and add to row
            cell_content = " ".join(self._cell_text).strip()
            self._table_row.append(cell_content)
            self._in_cell = False
            self._cell_text = []
        elif tag in ("p", "div", "li"):
            self.text_parts.append("\n")
        elif tag == "br":
            self.text_parts.append("\n")
        elif tag == "pre":
            self._in_pre = False
            self.text_parts.append("\n```\n")

    def handle_data(self, data: str) -> None:
        # Skip if we're in a skipped section
        if self._skip_depth > 0 or self._skip_inline:
            return

        text = data.strip() if not self._in_pre else data

        if not text:
            return

        if self._in_heading:
            self._heading_text += text
        elif self._in_cell:
            # Collect cell text — only emitted when the cell/row closes
            self._cell_text.append(text)
        else:
            self.text_parts.append(text)

    def get_result(self) -> tuple[str, dict[str, str]]:
        """Get extracted text and sections dict."""
        # Save final section
        if self.current_section:
            section_text = " ".join(self.text_parts[self._section_start :])
            if section_text.strip():
                self.sections[self.current_section] = section_text

        full_text = " ".join(self.text_parts)
        # Clean up whitespace (but preserve code blocks)
        full_text = re.sub(r"[ \t]+", " ", full_text)
        full_text = re.sub(r"\n{3,}", "\n\n", full_text)
        return full_text.strip(), self.sections


def html_to_text(html: str) -> tuple[str, dict[str, str]]:
    """Convert wiki HTML to plain text with section extraction.

    Supports MediaWiki, TWiki, and static HTML page structures:
    - MediaWiki: bodyContent or mw-parser-output div
    - TWiki: patternTopic div (live TWiki rendered pages)
    - Fallback: full HTML with tag stripping

    Tables are converted to markdown format with proper column separation
    to preserve structured data (signal tables, diagnostic lists, etc.).

    Args:
        html: Raw HTML content from wiki page

    Returns:
        Tuple of (full_text, sections_dict)
    """
    content_html = html

    # Try TWiki structure first (class="patternTopic")
    twiki_match = re.search(
        r'class="patternTopic">(.*?)</div>\s*<!--\s*/patternTopic',
        html,
        re.DOTALL,
    )
    if twiki_match:
        content_html = twiki_match.group(1)
    else:
        # Try older MediaWiki structure first (id="bodyContent") - common on many wikis
        body_start = html.find('<div id="bodyContent">')
        if body_start >= 0:
            # End at printfooter (before footer/categories)
            footer_start = html.find('<div class="printfooter">', body_start)
            if footer_start > body_start:
                content_html = html[body_start:footer_start]
            else:
                content_html = html[body_start:]
        else:
            # Try modern MediaWiki structure (class="mw-parser-output")
            content_match = re.search(
                r'<div[^>]*class="[^"]*mw-parser-output[^"]*"[^>]*>(.*?)</div>\s*'
                r'(?:<div[^>]*class="[^"]*printfooter|$)',
                html,
                re.DOTALL | re.IGNORECASE,
            )
            if content_match:
                content_html = content_match.group(1)

    # Use MediaWikiExtractor for proper table-aware HTML parsing
    extractor = MediaWikiExtractor()
    try:
        extractor.feed(content_html)
    except Exception:
        # Fallback to simple tag stripping if parser fails on malformed HTML
        import html as html_module

        content_html = re.sub(
            r"<script[^>]*>.*?</script>",
            " ",
            content_html,
            flags=re.DOTALL | re.IGNORECASE,
        )
        content_html = re.sub(
            r"<style[^>]*>.*?</style>",
            " ",
            content_html,
            flags=re.DOTALL | re.IGNORECASE,
        )
        content_html = re.sub(r"<!--.*?-->", " ", content_html, flags=re.DOTALL)
        text = re.sub(r"<[^>]+>", " ", content_html)
        text = html_module.unescape(text)
        text = re.sub(r"[ \t]+", " ", text)
        text = re.sub(r"\n{3,}", "\n\n", text)
        return text.strip(), {}

    return extractor.get_result()


# META types that are pure metadata (not content) — always skipped
_META_SYSTEM_TYPES = frozenset(
    {
        "TOPICINFO",
        "TOPICPARENT",
        "TOPICMOVED",
        "FORM",
        "PREFERENCE",
        "FILEATTACHMENT",
        "REVINFO",
        "REVCOMMENT",
    }
)

# Regex to parse %META:FIELD{name="X" ...value="Y"...}%
_META_FIELD_RE = re.compile(r'^%META:FIELD\{.*?name="([^"]*)".*?value="([^"]*)".*?\}%$')


def _parse_meta_field(line: str) -> str:
    """Parse a %META:...% line, returning HTML for FIELD values.

    TWiki forms store user-entered data in %META:FIELD{name="X" value="Y"}%
    lines.  These contain real content (shot descriptions, experiment logs,
    dates, operator notes) that must be preserved for scoring and ingestion.

    System metadata (TOPICINFO, TOPICPARENT, FORM, etc.) is skipped.

    Args:
        line: A stripped line starting with ``%META:``.

    Returns:
        HTML fragment for FIELD values, or empty string for system metadata.
    """
    # Identify the META type: %META:TYPE{...}%
    type_match = re.match(r"^%META:(\w+)", line)
    if not type_match:
        return ""

    meta_type = type_match.group(1)

    # Skip system metadata
    if meta_type in _META_SYSTEM_TYPES:
        return ""

    # Parse FIELD type specifically
    if meta_type == "FIELD":
        m = _META_FIELD_RE.match(line)
        if m:
            name = m.group(1)
            value = m.group(2)

            # URL-decode the value (TWiki encodes Japanese text and newlines)
            from urllib.parse import unquote

            value = unquote(value)

            # Skip fields with empty or whitespace-only values
            if not value.strip():
                return ""

            # Convert literal \r\n / encoded newlines to <br> for readability
            value = value.replace("\r\n", "<br>")
            value = value.replace("\n", "<br>")

            return f"<p><b>{name}</b>: {value}</p>"

    return ""


def twiki_markup_to_html(markup: str) -> str:
    """Convert raw TWiki markup to minimal HTML for the ingestion pipeline.

    Handles common TWiki markup patterns:
    - %META:FIELD{...}% lines → rendered as content (form data)
    - %META:...% system lines (TOPICINFO, FORM, etc.) → stripped
    - ---+/---++/---+++ headings → <h1>/<h2>/<h3>
    - *bold*, _italic_ formatting
    - | table | cells | → <table> rows
    - Bullet lists (   * item) → <li>
    - <verbatim>...</verbatim> → <pre>
    - <literal>...</literal> → passed through (contains HTML)
    - %VARIABLE% → stripped (except %BR% → <br>)
    - Inline HTML tags preserved as-is

    Args:
        markup: Raw TWiki .txt file content

    Returns:
        Minimal HTML suitable for html_to_text() processing
    """
    lines = markup.split("\n")
    html_lines: list[str] = []
    title = ""
    in_verbatim = False
    in_literal = False

    for line in lines:
        stripped = line.strip()

        # Handle META lines — extract FIELD values, skip everything else
        if stripped.startswith("%META:"):
            field_html = _parse_meta_field(stripped)
            if field_html:
                html_lines.append(field_html)
            continue

        # Handle <verbatim> blocks → <pre>
        if "<verbatim>" in stripped and not in_verbatim:
            in_verbatim = True
            # Content may be on same line as tag
            content = stripped.split("<verbatim>", 1)[1]
            html_lines.append("<pre>")
            if content:
                html_lines.append(content)
            continue
        if "</verbatim>" in stripped and in_verbatim:
            content = stripped.split("</verbatim>", 1)[0]
            if content:
                html_lines.append(content)
            html_lines.append("</pre>")
            in_verbatim = False
            continue
        if in_verbatim:
            html_lines.append(line)
            continue

        # Handle <literal> blocks (pass through — they contain HTML)
        if "<literal>" in stripped:
            in_literal = True
            content = stripped.split("<literal>", 1)[1]
            if content:
                html_lines.append(content)
            continue
        if "</literal>" in stripped:
            content = stripped.split("</literal>", 1)[0]
            if content:
                html_lines.append(content)
            in_literal = False
            continue
        if in_literal:
            html_lines.append(line)
            continue

        # TWiki headings: ---+ to ---++++++ (h1 to h6)
        heading_match = re.match(r"^---(\++){1,6}\s*(.*)", stripped)
        if heading_match:
            level = len(heading_match.group(1))
            heading_text = heading_match.group(2).strip()
            # Strip TWiki formatting from heading text
            heading_text = _strip_twiki_formatting(heading_text)
            if not title and level <= 2:
                title = heading_text
            html_lines.append(f"<h{level}>{heading_text}</h{level}>")
            continue

        # TWiki tables: | cell | cell |
        if stripped.startswith("|") and stripped.endswith("|"):
            cells = [c.strip() for c in stripped.split("|")[1:-1]]
            row = "".join(f"<td>{_strip_twiki_formatting(c)}</td>" for c in cells)
            html_lines.append(f"<tr>{row}</tr>")
            continue

        # TWiki bullet lists: 3-space indent + *
        bullet_match = re.match(r"^(\s+)\*\s+(.*)", line)
        if bullet_match:
            content = _strip_twiki_formatting(bullet_match.group(2))
            html_lines.append(f"<li>{content}</li>")
            continue

        # TWiki numbered lists: 3-space indent + 1.
        num_match = re.match(r"^(\s+)\d+\.?\s+(.*)", line)
        if num_match:
            content = _strip_twiki_formatting(num_match.group(2))
            html_lines.append(f"<li>{content}</li>")
            continue

        # Regular text — apply TWiki variable and formatting cleanup
        processed = _strip_twiki_formatting(stripped)
        if processed:
            html_lines.append(f"<p>{processed}</p>")

    body = "\n".join(html_lines)
    if not title:
        title = "Untitled"

    return f"<html><head><title>{title}</title></head><body>{body}</body></html>"


def _strip_twiki_formatting(text: str) -> str:
    """Strip TWiki-specific formatting from text.

    Converts TWiki variables and formatting to plain text/HTML.
    """
    # %BR% → <br>
    text = text.replace("%BR%", "<br>")

    # Strip color formatting: %BLACK%, %RED%, %ENDCOLOR%, etc.
    text = re.sub(r"%[A-Z_]+%", "", text)

    # Strip %VARIABLE{...}% patterns (e.g., %USERSIG{...}%, %PARENTBC%)
    text = re.sub(r"%[A-Z_]+\{[^}]*\}%", "", text)

    # TWiki bold: *text* → <b>text</b> (but not ** or inside HTML)
    text = re.sub(r"(?<!\w)\*([^\*\n]+?)\*(?!\w)", r"<b>\1</b>", text)

    # TWiki italic: _text_ → <i>text</i> (but not __ or inside HTML)
    text = re.sub(r"(?<!\w)_([^_\n]+?)_(?!\w)", r"<i>\1</i>", text)

    # Strip remaining %PUBURLPATH% etc.
    text = re.sub(r"%[A-Z][A-Z0-9_]*%", "", text)

    # Clean up multiple spaces
    text = re.sub(r"  +", " ", text)

    return text.strip()


def get_embed_model():
    """Get embedding encoder respecting embedding-backend config (local/remote).

    Delegates to the canonical cached singleton in imas_codex.embeddings.
    """
    from imas_codex.embeddings import get_encoder

    return get_encoder()


class WikiIngestionPipeline:
    """Pipeline for ingesting wiki pages into the knowledge graph.

    Handles the full lifecycle: fetch → chunk → embed → link.
    Uses same embedding model as code examples for unified search.
    """

    def __init__(
        self,
        facility_id: str = "tcv",
        chunk_size: int = 512,
        chunk_overlap: int = 50,
        use_rich: bool = True,
    ):
        """Initialize the pipeline.

        Args:
            facility_id: Facility ID (e.g., "tcv")
            chunk_size: Target chunk size in characters
            chunk_overlap: Overlap between chunks
            use_rich: Use Rich progress display
        """
        self.facility_id = facility_id
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.use_rich = use_rich

        # Embedding model is loaded lazily
        self._embed_model = None

    @property
    def embed_model(self):
        """Lazy-load embedding model respecting embedding-backend config."""
        if self._embed_model is None:
            self._embed_model = get_embed_model()
        return self._embed_model

    def _generate_page_id(self, page_name: str) -> str:
        """Generate unique ID for a WikiPage using canonical format."""
        from .scraper import canonical_page_id

        return canonical_page_id(page_name, self.facility_id)

    def _generate_chunk_id(self, page_id: str, chunk_idx: int) -> str:
        """Generate unique ID for a WikiChunk."""
        return f"{page_id}:chunk_{chunk_idx}"

    async def ingest_page(
        self, page: WikiPage, *, page_id: str | None = None
    ) -> PageIngestionStats:
        """Ingest a single wiki page into the graph.

        Deterministic pipeline: fetch → extract → chunk → embed → persist.
        No LLM calls - all entity extraction uses regex patterns.

        IMPORTANT: Blocking I/O operations (embedding, Neo4j) are wrapped in
        asyncio.to_thread() to avoid blocking the event loop.

        Args:
            page: Scraped WikiPage instance
            page_id: Explicit page ID from the discovery phase. When provided,
                this is used instead of re-deriving the ID from the URL
                (which can produce mismatches for non-MediaWiki sites).

        Returns:
            Stats dict: {chunks, data_nodes_linked, imas_paths_linked, conventions,
                        content_preview, mdsplus_paths}
        """
        import asyncio

        from .entity_extraction import FacilityEntityExtractor

        # Build facility-aware extractor (loads config once, selects patterns
        # based on facility data_systems — MDSplus, PPF, IMAS, etc.)
        extractor = FacilityEntityExtractor(self.facility_id)

        stats: PageIngestionStats = {
            "chunks": 0,
            "data_nodes_linked": 0,
            "imas_paths_linked": 0,
            "conventions": 0,
            "units": 0,
            "content_preview": "",
            "mdsplus_paths": [],
        }

        if page_id is None:
            page_id = self._generate_page_id(page.page_name)

        # Extract text content (CPU-bound, fast)
        text_content, sections = html_to_text(page.content_html)
        if not text_content or len(text_content) < 50:
            logger.warning("Skipping %s: insufficient content", page.page_name)
            return stats

        # Add content preview and MDSplus paths for progress display
        stats["content_preview"] = text_content[:300]
        stats["mdsplus_paths"] = page.mdsplus_paths[:10] if page.mdsplus_paths else []

        # Split into chunks (CPU-bound, fast)
        text_chunks = _chunk_text(
            text_content,
            chunk_size=self.chunk_size,
            chunk_overlap=self.chunk_overlap,
        )
        stats["chunks"] = len(text_chunks)

        # Generate embeddings in batch - BLOCKING HTTP, run in thread pool
        chunk_texts = [chunk.text for chunk in text_chunks]
        embeddings_array = await asyncio.to_thread(
            self.embed_model.embed_texts, chunk_texts
        )
        embeddings = embeddings_array.tolist()

        # Prepare batch data with pre-computed embeddings
        chunk_batch: list[dict] = []
        all_mdsplus: set[str] = set()
        all_imas: set[str] = set()

        for i, chunk in enumerate(text_chunks):
            chunk_text_str: str = chunk.text

            # Extract entities using facility-aware extractor
            entities = extractor.extract(chunk_text_str)
            props = extractor.to_chunk_properties(entities)

            # Track for stats
            all_mdsplus.update(entities.mdsplus_paths)
            all_imas.update(entities.imas_paths)
            stats["units"] += len(entities.units)
            stats["conventions"] += len(entities.conventions)

            # Content hash for deduplication (first 16 hex chars of SHA-256)
            text_hash = hashlib.sha256(chunk_text_str.encode()).hexdigest()[:16]

            chunk_batch.append(
                {
                    "id": self._generate_chunk_id(page_id, i),
                    "wiki_page_id": page_id,
                    "facility_id": self.facility_id,
                    "chunk_index": i,
                    "text": chunk_text_str,
                    "embedding": embeddings[i],
                    "content_hash": text_hash,
                    **props,
                }
            )

        # Persist all chunks in batches
        with GraphClient() as gc:
            # Update WikiPage: MERGE on id to match discovery phase
            # Constraint is on (id, facility_id), so MERGE on id ensures we update
            # existing nodes rather than creating duplicates with title mismatches
            gc.query(
                """
                MERGE (p:WikiPage {id: $id})
                SET p.facility_id = $facility_id,
                    p.title = $title,
                    p.url = $url,
                    p.status = 'ingested',
                    p.content_hash = $hash,
                    p.last_scraped = datetime(),
                    p.ingested_at = datetime(),
                    p.claimed_at = null,
                    p.chunk_count = $chunk_count,
                    p.mdsplus_paths_found = $mdsplus_paths,
                    p.imas_paths_found = $imas_paths,
                    p.conventions_found = $conventions
                WITH p
                MATCH (f:Facility {id: $facility_id})
                MERGE (p)-[:AT_FACILITY]->(f)
                """,
                id=page_id,
                url=page.url,
                title=page.title,
                facility_id=self.facility_id,
                hash=page.content_hash,
                chunk_count=len(text_chunks),
                mdsplus_paths=len(page.mdsplus_paths) if page.mdsplus_paths else 0,
                imas_paths=len(page.imas_paths) if page.imas_paths else 0,
                conventions=len(page.conventions) if page.conventions else 0,
            )

            # Batch persist chunks using UNWIND
            for i in range(0, len(chunk_batch), BATCH_SIZE):
                batch = chunk_batch[i : i + BATCH_SIZE]
                gc.query(
                    """
                    UNWIND $chunks AS chunk
                    MERGE (c:WikiChunk {id: chunk.id})
                    SET c.wiki_page_id = chunk.wiki_page_id,
                        c.facility_id = chunk.facility_id,
                        c.chunk_index = chunk.chunk_index,
                        c.text = chunk.text,
                        c.embedding = chunk.embedding,
                        c.content_hash = chunk.content_hash,
                        c.mdsplus_paths_mentioned = chunk.mdsplus_paths,
                        c.imas_paths_mentioned = chunk.imas_paths,
                        c.ppf_paths_mentioned = chunk.ppf_paths,
                        c.units_mentioned = chunk.units,
                        c.conventions_mentioned = chunk.conventions,
                        c.tool_mentions = chunk.tool_mentions
                    WITH c, chunk
                    MATCH (p:WikiPage {id: chunk.wiki_page_id})
                    MERGE (p)-[:HAS_CHUNK]->(c)
                    WITH c, chunk
                    MATCH (f:Facility {id: chunk.facility_id})
                    MERGE (c)-[:AT_FACILITY]->(f)
                    """,
                    chunks=batch,
                )

            # Create NEXT_CHUNK relationships for sequential navigation
            # Best practice from neo4j-graphrag: linked list pattern for chunk traversal
            if len(chunk_batch) > 1:
                gc.query(
                    """
                    MATCH (p:WikiPage {id: $page_id})-[:HAS_CHUNK]->(c:WikiChunk)
                    WITH c ORDER BY c.chunk_index
                    WITH collect(c) AS chunks
                    UNWIND range(0, size(chunks) - 2) AS idx
                    WITH chunks[idx] AS current, chunks[idx + 1] AS next
                    MERGE (current)-[:NEXT_CHUNK]->(next)
                    """,
                    page_id=page_id,
                )

            # Batch link chunks to DataNodes
            if all_mdsplus:
                result = gc.query(
                    """
                    MATCH (c:WikiChunk {wiki_page_id: $page_id})
                    WHERE c.mdsplus_paths_mentioned IS NOT NULL
                    UNWIND c.mdsplus_paths_mentioned AS mds_path
                    MATCH (t:SignalNode)
                    WHERE t.path = mds_path
                       OR t.path ENDS WITH replace(mds_path, '\\\\', '')
                       OR t.canonical_path = toUpper(mds_path)
                    MERGE (c)-[:DOCUMENTS]->(t)
                    RETURN count(*) AS linked
                    """,
                    page_id=page_id,
                )
                if result and result[0]["linked"]:
                    stats["data_nodes_linked"] = result[0]["linked"]

            # Create SignConvention nodes from page conventions (batch)
            if page.conventions:
                conv_batch = []
                for conv in page.conventions:
                    conv_id = f"{self.facility_id}:{conv.get('type', 'unknown')}:{hashlib.md5(conv.get('name', '').encode()).hexdigest()[:8]}"
                    conv_batch.append(
                        {
                            "id": conv_id,
                            "facility_id": self.facility_id,
                            "type": conv.get("type", "sign"),
                            "name": conv.get("name", ""),
                            "context": conv.get("context", ""),
                            "url": page.url,
                            "cocos_index": conv.get("cocos_index"),
                        }
                    )

                gc.query(
                    """
                    UNWIND $convs AS conv
                    MERGE (sc:SignConvention {id: conv.id})
                    SET sc.facility_id = conv.facility_id,
                        sc.convention_type = conv.type,
                        sc.name = conv.name,
                        sc.description = conv.context,
                        sc.wiki_source = conv.url,
                        sc.cocos_index = conv.cocos_index
                    WITH sc, conv
                    MATCH (f:Facility {id: conv.facility_id})
                    MERGE (sc)-[:AT_FACILITY]->(f)
                    """,
                    convs=conv_batch,
                )

            # Update link counts on WikiPage
            gc.query(
                """
                MATCH (p:WikiPage {id: $page_id})
                SET p.link_count = $links
                """,
                page_id=page_id,
                links=stats["data_nodes_linked"] + stats["imas_paths_linked"],
            )

        return stats

    async def ingest_pages(
        self,
        page_names: list[str],
        progress_callback: ProgressCallback | None = None,
        rate_limit: float = 0.5,
    ) -> dict[str, int]:
        """Ingest multiple wiki pages by name (legacy method).

        For graph-driven workflow, use ingest_from_graph() instead.

        Args:
            page_names: List of wiki page names to ingest
            progress_callback: Optional callback for progress updates
            rate_limit: Minimum seconds between requests

        Returns:
            Aggregate stats dict
        """
        import asyncio

        total_stats = {
            "pages": 0,
            "pages_failed": 0,
            "chunks": 0,
            "data_nodes_linked": 0,
            "imas_paths_linked": 0,
            "conventions": 0,
            "units": 0,
        }

        # Set up progress monitoring
        monitor = WikiProgressMonitor(use_rich=self.use_rich)
        set_current_monitor(monitor)
        monitor.start(total_pages=len(page_names))

        def report(current: int, total: int, message: str) -> None:
            if progress_callback:
                progress_callback(current, total, message)

        try:
            for i, page_name in enumerate(page_names):
                report(i, len(page_names), f"Processing {page_name}")
                page_id = self._generate_page_id(page_name)

                try:
                    # Determine site type from facility config
                    from imas_codex.discovery.wiki.config import WikiConfig

                    wiki_config = WikiConfig.from_facility(self.facility_id)
                    site_type = wiki_config.site_type

                    # Fetch the page
                    page = fetch_wiki_page(
                        page_name,
                        facility=self.facility_id,
                        site_type=site_type,
                        auth_type=wiki_config.auth_type,
                        credential_service=wiki_config.credential_service,
                    )

                    # Check if fetch succeeded
                    if page is None:
                        raise ValueError(f"Failed to fetch page {page_name}")

                    # Ingest it
                    page_stats = await self.ingest_page(page)

                    # Aggregate stats
                    total_stats["pages"] += 1
                    total_stats["chunks"] += page_stats["chunks"]
                    total_stats["data_nodes_linked"] += page_stats["data_nodes_linked"]
                    total_stats["imas_paths_linked"] += page_stats["imas_paths_linked"]
                    total_stats["conventions"] += page_stats["conventions"]
                    total_stats["units"] += page_stats["units"]

                    # Update progress monitor with content preview
                    monitor.update_scrape(
                        page_name,
                        chunks=page_stats["chunks"],
                        data_nodes=page_stats["data_nodes_linked"],
                        imas_paths=page_stats["imas_paths_linked"],
                        conventions=page_stats["conventions"],
                        units=page_stats["units"],
                        content_preview=str(page_stats.get("content_preview", "")),
                        mdsplus_paths=page_stats.get("mdsplus_paths"),
                    )

                except Exception as e:
                    logger.error("Failed to ingest %s: %s", page_name, e)
                    total_stats["pages_failed"] += 1
                    monitor.update_scrape(page_name, failed=True)
                    # Mark as failed in graph
                    mark_wiki_page_status(page_id, "failed", str(e))

                # Rate limiting
                await asyncio.sleep(rate_limit)

        finally:
            monitor.finish()
            set_current_monitor(None)

        report(len(page_names), len(page_names), "Ingestion complete")
        return total_stats

    async def ingest_from_graph(
        self,
        limit: int | None = None,
        min_score_composite: float = 0.5,
        progress_callback: ProgressCallback | None = None,
        rate_limit: float = 0.5,
    ) -> dict[str, int]:
        """Ingest wiki pages from the graph queue (graph-driven workflow).

        Reads WikiPage nodes with status='scored', fetches content,
        generates embeddings, and creates chunks with graph links.

        This is the preferred method - discover creates the queue,
        ingest processes it.

        Args:
            limit: Maximum pages to process (None for all)
            min_score_composite: Minimum interest score threshold
            progress_callback: Optional callback for progress updates
            rate_limit: Minimum seconds between requests

        Returns:
            Aggregate stats dict
        """
        # Get pending pages from graph
        pending = get_pending_wiki_pages(
            self.facility_id,
            limit=limit,
            min_score_composite=min_score_composite,
        )

        if not pending:
            logger.info("No pending wiki pages for %s", self.facility_id)
            return {
                "pages": 0,
                "pages_failed": 0,
                "chunks": 0,
                "data_nodes_linked": 0,
                "imas_paths_linked": 0,
                "conventions": 0,
                "units": 0,
            }

        # Extract page identifiers from the graph results
        # For Confluence: use page ID (numeric)
        # For MediaWiki: use page title
        from imas_codex.discovery.wiki.config import WikiConfig

        wiki_config = WikiConfig.from_facility(self.facility_id)

        if wiki_config.site_type == "confluence":
            # Extract page ID from the full ID (format: "facility:page_id")
            page_names = [
                p["id"].split(":", 1)[1] if ":" in p["id"] else p["id"] for p in pending
            ]
        else:
            # Use title for MediaWiki
            page_names = [p["title"] for p in pending]

        logger.info(
            "Processing %d wiki pages from graph queue for %s",
            len(page_names),
            self.facility_id,
        )

        # Use the existing ingest_pages method
        return await self.ingest_pages(
            page_names,
            progress_callback=progress_callback,
            rate_limit=rate_limit,
        )


def ensure_wiki_vector_index() -> bool:
    """Ensure Neo4j vector index exists for WikiChunk embeddings.

    Creates the index if it doesn't exist. Safe to call multiple times.
    Dimension is determined by the configured embedding model.

    Returns:
        True if index was created, False if it already existed.
    """
    with GraphClient() as gc:
        # Check if index already exists
        existing = gc.query(
            "SHOW INDEXES YIELD name WHERE name = 'wiki_chunk_embedding' RETURN name"
        )
        if existing:
            logger.debug("wiki_chunk_embedding index already exists")
            return False

        # Get dimension from configured embedding model
        dim = get_embedding_dimension()
        gc.query(
            f"""
            CREATE VECTOR INDEX wiki_chunk_embedding IF NOT EXISTS
            FOR (c:WikiChunk) ON c.embedding
            OPTIONS {{
                indexConfig: {{
                    `vector.dimensions`: {dim},
                    `vector.similarity_function`: 'cosine'
                }}
            }}
            """
        )
        logger.info(f"Created wiki_chunk_embedding vector index ({dim} dims)")
        return True


def get_wiki_stats(facility_id: str) -> dict:
    """Get wiki ingestion statistics for a facility.

    Args:
        facility_id: Facility ID

    Returns:
        Stats dict with page/chunk counts and link statistics
    """
    with GraphClient() as gc:
        result = gc.query(
            """
            MATCH (wp:WikiPage {facility_id: $facility_id})
            OPTIONAL MATCH (wp)-[:HAS_CHUNK]->(wc:WikiChunk)
            OPTIONAL MATCH (wc)-[:DOCUMENTS]->(t:SignalNode)
            OPTIONAL MATCH (wc)-[:MENTIONS_IMAS]->(ip:IMASNode)
            WITH wp, count(DISTINCT wc) AS chunks,
                 count(DISTINCT t) AS data_nodes,
                 count(DISTINCT ip) AS imas_paths
            RETURN count(wp) AS pages,
                   sum(chunks) AS total_chunks,
                   sum(data_nodes) AS data_nodes_linked,
                   sum(imas_paths) AS imas_paths_linked
            """,
            facility_id=facility_id,
        )

        if result:
            return {
                "pages": result[0]["pages"],
                "chunks": result[0]["total_chunks"],
                "data_nodes_linked": result[0]["data_nodes_linked"],
                "imas_paths_linked": result[0]["imas_paths_linked"],
            }
        return {"pages": 0, "chunks": 0, "data_nodes_linked": 0, "imas_paths_linked": 0}


def clear_facility_wiki(facility: str, batch_size: int = 1000) -> dict:
    """Delete all wiki discovery nodes for a facility in batches.

    Always cascades: deletes WikiChunks and Documents along with WikiPages.
    Wiki chunks and documents are always dependent on their parent pages/facility,
    so cascade is the only sensible behaviour.

    Deletion order follows referential integrity:
    1. WikiChunks linked via HAS_CHUNK from WikiPages
    2. WikiChunks linked via HAS_CHUNK from Documents
    3. Any remaining orphaned WikiChunks by facility_id
    4. Documents by facility_id
    5. WikiPages by facility_id

    Args:
        facility: Facility ID
        batch_size: Nodes to delete per batch (default 1000)

    Returns:
        Dict with deletion counts: pages_deleted, chunks_deleted, documents_deleted
    """
    chunks_deleted = 0
    documents_deleted = 0
    pages_deleted = 0
    images_deleted = 0

    with GraphClient() as gc:
        # First delete WikiChunks linked to WikiPages
        while True:
            result = gc.query(
                """
                MATCH (wp:WikiPage {facility_id: $facility})
                      -[:HAS_CHUNK]->(wc:WikiChunk)
                WITH wc LIMIT $batch_size
                DETACH DELETE wc
                RETURN count(wc) AS deleted
                """,
                facility=facility,
                batch_size=batch_size,
            )
            deleted = result[0]["deleted"] if result else 0
            chunks_deleted += deleted
            if deleted < batch_size:
                break

        # Delete WikiChunks linked to Documents
        while True:
            result = gc.query(
                """
                MATCH (wa:Document {facility_id: $facility})
                      -[:HAS_CHUNK]->(wc:WikiChunk)
                WITH wc LIMIT $batch_size
                DETACH DELETE wc
                RETURN count(wc) AS deleted
                """,
                facility=facility,
                batch_size=batch_size,
            )
            deleted = result[0]["deleted"] if result else 0
            chunks_deleted += deleted
            if deleted < batch_size:
                break

        # Delete any remaining orphaned WikiChunks by facility_id
        while True:
            result = gc.query(
                """
                MATCH (wc:WikiChunk {facility_id: $facility})
                WITH wc LIMIT $batch_size
                DETACH DELETE wc
                RETURN count(wc) AS deleted
                """,
                facility=facility,
                batch_size=batch_size,
            )
            deleted = result[0]["deleted"] if result else 0
            chunks_deleted += deleted
            if deleted < batch_size:
                break

        # Delete Documents (uses facility_id to catch both linked and orphaned)
        while True:
            result = gc.query(
                """
                MATCH (wa:Document {facility_id: $facility})
                WITH wa LIMIT $batch_size
                DETACH DELETE wa
                RETURN count(wa) AS deleted
                """,
                facility=facility,
                batch_size=batch_size,
            )
            deleted = result[0]["deleted"] if result else 0
            documents_deleted += deleted
            if deleted < batch_size:
                break

        # Finally delete WikiPages
        while True:
            result = gc.query(
                """
                MATCH (wp:WikiPage {facility_id: $facility})
                WITH wp LIMIT $batch_size
                DETACH DELETE wp
                RETURN count(wp) AS deleted
                """,
                facility=facility,
                batch_size=batch_size,
            )
            deleted = result[0]["deleted"] if result else 0
            pages_deleted += deleted
            if deleted < batch_size:
                break

        # Delete orphaned Image nodes — only those with no remaining
        # HAS_IMAGE relationships from other domains (e.g. CodeFile).
        # Wiki nodes (WikiPage, Document) are already deleted above,
        # so any Image still linked via HAS_IMAGE belongs to another domain.
        while True:
            result = gc.query(
                """
                MATCH (img:Image {facility_id: $facility})
                WHERE NOT (img)<-[:HAS_IMAGE]-()
                WITH img LIMIT $batch_size
                DETACH DELETE img
                RETURN count(img) AS deleted
                """,
                facility=facility,
                batch_size=batch_size,
            )
            deleted = result[0]["deleted"] if result else 0
            images_deleted += deleted
            if deleted < batch_size:
                break

    return {
        "pages_deleted": pages_deleted,
        "chunks_deleted": chunks_deleted,
        "documents_deleted": documents_deleted,
        "images_deleted": images_deleted,
    }


# =============================================================================
# Document Ingestion
# =============================================================================


class DocumentIngestionStats(TypedDict):
    """Statistics from ingesting a single document."""

    chunks: int
    content_preview: str
    document_type: str


# Default size limits for document ingestion
DEFAULT_MAX_ARTIFACT_SIZE_MB = 5.0  # 5 MB default
MAX_ARTIFACT_SIZE_BYTES = int(DEFAULT_MAX_ARTIFACT_SIZE_MB * 1024 * 1024)


def _decode_url(url: str) -> str:
    """Decode URL-encoded path components.

    Wiki document URLs may have encoded slashes (%2F) that need decoding.
    """
    from urllib.parse import unquote

    return unquote(url)


def fetch_document_size(
    url: str,
    facility: str = "tcv",
    timeout: int = 30,
    session: Any = None,
) -> int | None:
    """Fetch document file size via HTTP HEAD request.

    Uses the transfer module for SSH-proxied or direct HTTP access.
    When a session is provided (e.g. Confluence auth), uses direct HTTP
    instead of SSH curl.

    Args:
        url: Full URL to document
        facility: SSH host alias (None for direct HTTP)
        timeout: Timeout in seconds
        session: Optional authenticated requests.Session (bypasses SSH)

    Returns:
        File size in bytes, or None if size cannot be determined
    """
    import asyncio

    from imas_codex.discovery.base.transfer import TransferClient

    async def _get_size():
        # Use the authenticated session directly — keeps connection pool
        # and TLS state intact for BigIP/load-balanced Confluence.
        ssh = None if session else facility
        async with TransferClient(ssh_host=ssh, session=session) as client:
            return await client.get_size(url, timeout=timeout)

    # Run async in sync context
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            # Already in async context - create a task
            import concurrent.futures

            with concurrent.futures.ThreadPoolExecutor() as pool:
                future = pool.submit(asyncio.run, _get_size())
                return future.result(timeout=timeout + 5)
        else:
            return asyncio.run(_get_size())
    except Exception as e:
        logger.debug("Error getting document size: %s", e)
        return None


async def fetch_document_content(
    url: str,
    facility: str = "tcv",
    timeout: int = 120,
    session: Any = None,
) -> tuple[str, bytes]:
    """Fetch document content with validation.

    Uses the transfer module for SSH-proxied or direct HTTP access.
    When a session is provided (e.g. Confluence auth), uses direct HTTP
    instead of SSH curl.

    Args:
        url: Full URL to document
        facility: SSH host alias (None for direct HTTP)
        timeout: Timeout in seconds
        session: Optional authenticated requests.Session (bypasses SSH)

    Returns:
        Tuple of (content_type, raw_bytes)

    Raises:
        RuntimeError: If download fails
        ValueError: If content doesn't match expected type
    """
    from imas_codex.discovery.base.transfer import TransferClient

    # Get expected type from URL extension
    ext = url.rsplit(".", 1)[-1].lower()

    # Use the authenticated session directly for downloads. Confluence's
    # /download/attachments/ endpoint serves binary content regardless of
    # Accept header (Accept: application/json only affects /rest/api/ endpoints).
    # Creating a new Session() would lose connection pool and TLS state needed
    # by load balancers like BigIP.
    ssh = None if session else facility
    async with TransferClient(ssh_host=ssh, session=session) as client:
        result = await client.download(url, timeout=timeout, expected_type=ext)

    if not result.success:
        raise RuntimeError(f"Failed to fetch {url}: {result.error}")

    return result.content_type or "application/octet-stream", result.content


def _extract_text_from_legacy_bytes(content_bytes: bytes) -> str:
    """Extract text from legacy binary document formats (.doc, .ppt, .txt).

    Tries UTF-8/Latin-1 decoding first (plain text files), then falls back to
    extracting ASCII-printable runs from binary OLE2 compound documents.
    Filters out very short runs (< 20 chars) to skip binary noise.
    """
    # Try plain text decoding first
    for encoding in ("utf-8", "latin-1"):
        try:
            text = content_bytes.decode(encoding)
            # Heuristic: if >80% printable, it's a text file
            printable = sum(1 for c in text[:1000] if c.isprintable() or c in "\n\r\t")
            if printable > len(text[:1000]) * 0.8:
                return text
        except (UnicodeDecodeError, ValueError):
            continue

    # Binary OLE2 file — extract printable ASCII runs
    import re

    # Find runs of printable ASCII characters (min 20 chars to skip noise)
    runs = re.findall(rb"[\x20-\x7E]{20,}", content_bytes)
    if runs:
        return "\n".join(r.decode("ascii", errors="ignore") for r in runs)

    return ""


class DocumentPipeline:
    """Pipeline for ingesting wiki documents (PDFs, presentations, etc.).

    Uses LlamaIndex readers for PDF extraction. Other document types
    are currently marked as deferred (require OCR or specialized parsers).

    Supported types:
    - PDF: Full text extraction via pypdf (up to max_size_mb limit)
    - Others: Deferred for future implementation

    Size limits:
    - Documents larger than max_size_mb are marked as 'deferred' with size_bytes stored
    - This prevents flooding the graph with oversized content
    - Deferred documents can still be searched via metadata (filename, linked pages)
    """

    def __init__(
        self,
        facility_id: str = "tcv",
        chunk_size: int = 512,
        chunk_overlap: int = 50,
        use_rich: bool = True,
        max_size_mb: float = DEFAULT_MAX_ARTIFACT_SIZE_MB,
    ):
        """Initialize the document pipeline.

        Args:
            facility_id: Facility ID
            chunk_size: Target chunk size in characters
            chunk_overlap: Overlap between chunks
            use_rich: Use Rich progress display
            max_size_mb: Maximum document size in MB (default 5.0)
        """
        self.facility_id = facility_id
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.use_rich = use_rich
        self.max_size_bytes = int(max_size_mb * 1024 * 1024)

        self._embed_model = None

    @property
    def embed_model(self):
        """Lazy-load embedding model respecting embedding-backend config."""
        if self._embed_model is None:
            self._embed_model = get_embed_model()
        return self._embed_model

    async def ingest_pdf(
        self,
        document_id: str,
        pdf_bytes: bytes,
    ) -> DocumentIngestionStats:
        """Ingest a PDF document.

        Args:
            document_id: Document node ID
            pdf_bytes: Raw PDF content

        Returns:
            Ingestion stats

        Raises:
            ValueError: If content is not a valid PDF (wrong magic bytes)
        """
        import io

        import pypdf

        stats: DocumentIngestionStats = {
            "chunks": 0,
            "content_preview": "",
            "document_type": "pdf",
        }

        # Validate PDF magic bytes before attempting to parse
        # Valid PDFs start with %PDF (possibly with leading whitespace/BOM)
        header = pdf_bytes[:1024] if len(pdf_bytes) > 1024 else pdf_bytes
        if b"%PDF" not in header:
            # Identify what the file actually is
            preview = pdf_bytes[:5].decode("latin-1", errors="replace")
            if pdf_bytes[:2] == b"PK":
                raise ValueError(
                    f"Content is a ZIP/Office file, not PDF (header: {preview!r})"
                )
            elif pdf_bytes[:5] == b"<!DOC" or pdf_bytes[:5] == b"<html":
                raise ValueError(f"Content is HTML, not PDF (header: {preview!r})")
            else:
                raise ValueError(f"Invalid PDF: missing %PDF header (got: {preview!r})")

        # Suppress pypdf's verbose warnings and errors.
        # pypdf._cmap uses logger_error() for benign "Advanced
        # encoding ... not implemented yet" messages, so ERROR
        # level doesn't suppress them — use CRITICAL.
        pypdf_logger = logging.getLogger("pypdf")
        original_level = pypdf_logger.level
        pypdf_logger.setLevel(logging.CRITICAL)

        try:
            reader = pypdf.PdfReader(io.BytesIO(pdf_bytes))
            text_parts = []
            for page in reader.pages:
                text = page.extract_text()
                if text:
                    text_parts.append(text)
        finally:
            pypdf_logger.setLevel(original_level)

        if not text_parts:
            logger.warning("No content extracted from PDF: %s", document_id)
            return stats

        full_text = "\n\n".join(text_parts)

        if not full_text.strip():
            logger.warning("No text content in PDF: %s", document_id)
            return stats

        stats["content_preview"] = full_text[:300]
        stats = await self._create_document_chunks(document_id, full_text, "pdf", stats)

        # Extract embedded images for VLM captioning pipeline
        try:
            images = self._extract_pdf_images(pdf_bytes, document_id)
            if images:
                stats["extracted_images"] = images
        except Exception as e:
            logger.debug("PDF image extraction failed for %s: %s", document_id, e)

        return stats

    def _extract_pdf_images(
        self,
        pdf_bytes: bytes,
        document_id: str,
        max_images: int = 20,
    ) -> list[dict[str, Any]]:
        """Extract embedded images from PDF for VLM processing.

        Uses pypdf's image extraction to find significant figures.
        Small decorative images are filtered out.

        Args:
            pdf_bytes: Raw PDF bytes
            document_id: Parent document ID for context
            max_images: Maximum images to extract per PDF

        Returns:
            List of dicts with image_bytes, page_num, width, height
        """
        import io
        import logging as _logging

        import pypdf

        pypdf_logger = _logging.getLogger("pypdf")
        original_level = pypdf_logger.level
        pypdf_logger.setLevel(_logging.CRITICAL)

        images: list[dict[str, Any]] = []
        try:
            reader = pypdf.PdfReader(io.BytesIO(pdf_bytes))
            for page_num, page in enumerate(reader.pages, 1):
                if len(images) >= max_images:
                    break
                try:
                    for img in page.images:
                        if len(images) >= max_images:
                            break
                        img_bytes = img.data
                        # Skip tiny images (likely icons/bullets)
                        if len(img_bytes) < 2048:
                            continue
                        images.append(
                            {
                                "image_bytes": img_bytes,
                                "page_num": page_num,
                                "name": getattr(img, "name", ""),
                            }
                        )
                except Exception:
                    # Some pages may have unsupported image formats
                    continue
        finally:
            pypdf_logger.setLevel(original_level)

        return images

    async def ingest_docx(
        self,
        document_id: str,
        content_bytes: bytes,
    ) -> DocumentIngestionStats:
        """Ingest a Word document (.docx) or legacy text document (.doc, .txt).

        Tries python-docx for modern OOXML format first. Falls back to plain
        text decoding for legacy .doc and .txt files that are not ZIP-based.

        Args:
            document_id: Document node ID
            content_bytes: Raw document content

        Returns:
            Ingestion stats
        """
        import io
        from zipfile import BadZipFile

        stats: DocumentIngestionStats = {
            "chunks": 0,
            "content_preview": "",
            "document_type": "docx",
        }

        full_text = ""
        try:
            from docx import Document as DocxDocument

            doc = DocxDocument(io.BytesIO(content_bytes))
            paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
            full_text = "\n\n".join(paragraphs)
        except BadZipFile:
            # Legacy .doc or plain .txt file — try text extraction
            full_text = _extract_text_from_legacy_bytes(content_bytes)
            if full_text:
                stats["document_type"] = "legacy_doc"
                logger.info(
                    "Extracted %d chars from legacy document: %s",
                    len(full_text),
                    document_id,
                )

        if not full_text.strip():
            logger.warning("No content extracted from document: %s", document_id)
            return stats

        stats["content_preview"] = full_text[:300]
        stats = await self._create_document_chunks(
            document_id, full_text, stats["document_type"], stats
        )
        return stats

    async def ingest_pptx(
        self,
        document_id: str,
        content_bytes: bytes,
    ) -> DocumentIngestionStats:
        """Ingest a PowerPoint document (.pptx) or legacy .ppt.

        Tries python-pptx for modern OOXML format first. Falls back to plain
        text extraction for legacy .ppt files that are not ZIP-based.

        Args:
            document_id: Document node ID
            content_bytes: Raw presentation content

        Returns:
            Ingestion stats
        """
        import io
        from zipfile import BadZipFile

        stats: DocumentIngestionStats = {
            "chunks": 0,
            "content_preview": "",
            "document_type": "pptx",
        }

        full_text = ""
        try:
            from pptx import Presentation

            prs = Presentation(io.BytesIO(content_bytes))
            text_parts = []

            for slide_num, slide in enumerate(prs.slides, 1):
                slide_text = []
                for shape in slide.shapes:
                    if hasattr(shape, "text") and shape.text.strip():
                        slide_text.append(shape.text.strip())
                if slide_text:
                    text_parts.append(f"[Slide {slide_num}]\n" + "\n".join(slide_text))

            full_text = "\n\n".join(text_parts)
        except BadZipFile:
            # Legacy .ppt file — try text extraction
            full_text = _extract_text_from_legacy_bytes(content_bytes)
            if full_text:
                stats["document_type"] = "legacy_ppt"
                logger.info(
                    "Extracted %d chars from legacy presentation: %s",
                    len(full_text),
                    document_id,
                )

        if not full_text.strip():
            logger.warning("No content extracted from presentation: %s", document_id)
            return stats

        stats["content_preview"] = full_text[:300]
        stats = await self._create_document_chunks(
            document_id, full_text, stats["document_type"], stats
        )

        # Extract embedded images from slides for VLM captioning
        try:
            images = self._extract_pptx_images(content_bytes, document_id)
            if images:
                stats["extracted_images"] = images
        except Exception as e:
            logger.debug("PPTX image extraction failed for %s: %s", document_id, e)

        return stats

    def _extract_pptx_images(
        self,
        content_bytes: bytes,
        document_id: str,
        max_images: int = 20,
    ) -> list[dict[str, Any]]:
        """Extract embedded images from PowerPoint for VLM processing.

        Uses python-pptx to find Picture shapes across slides.
        Small decorative images are filtered out.

        Args:
            content_bytes: Raw PPTX bytes
            document_id: Parent document ID for context
            max_images: Maximum images to extract

        Returns:
            List of dicts with image_bytes, slide_num, name
        """
        import io

        from pptx import Presentation
        from pptx.enum.shapes import MSO_SHAPE_TYPE

        images: list[dict[str, Any]] = []

        prs = Presentation(io.BytesIO(content_bytes))
        for slide_num, slide in enumerate(prs.slides, 1):
            if len(images) >= max_images:
                break
            for shape in slide.shapes:
                if len(images) >= max_images:
                    break
                if shape.shape_type == MSO_SHAPE_TYPE.PICTURE:
                    try:
                        img_bytes = shape.image.blob
                        if len(img_bytes) < 2048:
                            continue
                        images.append(
                            {
                                "image_bytes": img_bytes,
                                "slide_num": slide_num,
                                "name": getattr(shape, "name", ""),
                                "content_type": shape.image.content_type,
                            }
                        )
                    except Exception:
                        continue

        return images

    async def ingest_xlsx(
        self,
        document_id: str,
        content_bytes: bytes,
    ) -> DocumentIngestionStats:
        """Ingest an Excel document.

        Args:
            document_id: Document node ID
            content_bytes: Raw spreadsheet content

        Returns:
            Ingestion stats
        """
        stats: DocumentIngestionStats = {
            "chunks": 0,
            "content_preview": "",
            "document_type": "xlsx",
        }

        from imas_codex.discovery.wiki.excel import extract_excel_full

        full_text = extract_excel_full(content_bytes)

        if not full_text.strip():
            logger.warning("No content extracted from XLSX: %s", document_id)
            return stats

        stats["content_preview"] = full_text[:300]
        stats = await self._create_document_chunks(
            document_id, full_text, "xlsx", stats
        )
        return stats

    async def ingest_notebook(
        self,
        document_id: str,
        content_bytes: bytes,
    ) -> DocumentIngestionStats:
        """Ingest a Jupyter notebook document.

        Args:
            document_id: Document node ID
            content_bytes: Raw notebook content

        Returns:
            Ingestion stats
        """
        import json

        import nbformat

        stats: DocumentIngestionStats = {
            "chunks": 0,
            "content_preview": "",
            "document_type": "ipynb",
        }

        try:
            nb = nbformat.reads(content_bytes.decode("utf-8"), as_version=4)
        except (json.JSONDecodeError, nbformat.reader.NotJSONError) as e:
            logger.warning("Failed to parse notebook %s: %s", document_id, e)
            return stats

        text_parts = []
        for cell_num, cell in enumerate(nb.cells, 1):
            if cell.cell_type == "markdown":
                text_parts.append(f"[Cell {cell_num} - Markdown]\n{cell.source}")
            elif cell.cell_type == "code":
                text_parts.append(
                    f"[Cell {cell_num} - Code]\n```python\n{cell.source}\n```"
                )

        full_text = "\n\n".join(text_parts)

        if not full_text.strip():
            logger.warning("No content extracted from notebook: %s", document_id)
            return stats

        stats["content_preview"] = full_text[:300]
        stats = await self._create_document_chunks(
            document_id, full_text, "ipynb", stats
        )
        return stats

    async def ingest_json(
        self,
        document_id: str,
        content_bytes: bytes,
    ) -> DocumentIngestionStats:
        """Ingest a JSON document.

        Parses JSON content and converts to readable text for chunking.
        Handles both structured data and configuration-style JSON.

        Args:
            document_id: Document node ID
            content_bytes: Raw JSON content

        Returns:
            Ingestion stats
        """
        import json

        stats: DocumentIngestionStats = {
            "chunks": 0,
            "content_preview": "",
            "document_type": "json",
        }

        try:
            text = content_bytes.decode("utf-8", errors="replace")
            data = json.loads(text)
        except (json.JSONDecodeError, UnicodeDecodeError) as e:
            logger.warning("Failed to parse JSON %s: %s", document_id, e)
            return stats

        # Pretty-print for chunking (preserves structure for LLM understanding)
        full_text = json.dumps(data, indent=2, ensure_ascii=False, default=str)

        if not full_text.strip():
            logger.warning("No content extracted from JSON: %s", document_id)
            return stats

        stats["content_preview"] = full_text[:300]
        stats = await self._create_document_chunks(
            document_id, full_text, "json", stats
        )
        return stats

    async def ingest_document(
        self,
        document_id: str,
        content_bytes: bytes,
        document_type: str,
    ) -> DocumentIngestionStats:
        """Dispatch to appropriate extraction method based on document type.

        Uses semantic type names matching DocumentType enum values.

        Args:
            document_id: Document node ID
            content_bytes: Raw document content
            document_type: Semantic document type (pdf, document, presentation, etc.)

        Returns:
            Ingestion stats as dict

        Raises:
            ValueError: If document type is not supported
        """
        handlers = {
            "pdf": self.ingest_pdf,
            "text_document": self.ingest_docx,
            "presentation": self.ingest_pptx,
            "spreadsheet": self.ingest_xlsx,
            "notebook": self.ingest_notebook,
            "json": self.ingest_json,
        }

        handler = handlers.get(document_type.lower())
        if handler is None:
            raise ValueError(f"Unsupported document type: {document_type}")

        return await handler(document_id, content_bytes)

    async def _create_document_chunks(
        self,
        document_id: str,
        full_text: str,
        document_type: str,
        stats: DocumentIngestionStats,
    ) -> DocumentIngestionStats:
        """Create chunks from extracted text and persist to graph.

        Common implementation used by all document type extractors.
        Performs entity extraction including facility-aware tool mention
        matching from DataAccessPatternsConfig.

        IMPORTANT: Blocking I/O operations (embedding) are wrapped in
        asyncio.to_thread() to avoid blocking the event loop.
        """
        import asyncio

        from .entity_extraction import FacilityEntityExtractor

        # Build facility-aware extractor (loads config once, selects patterns
        # based on facility data_systems — MDSplus, PPF, IMAS, etc.)
        extractor = FacilityEntityExtractor(self.facility_id)

        # Split into chunks
        text_chunks = _chunk_text(
            full_text,
            chunk_size=self.chunk_size,
            chunk_overlap=self.chunk_overlap,
        )
        stats["chunks"] = len(text_chunks)

        if not text_chunks:
            return stats

        # Generate embeddings in batch - BLOCKING HTTP, run in thread pool
        chunk_texts = [chunk.text for chunk in text_chunks]
        embeddings_array = await asyncio.to_thread(
            self.embed_model.embed_texts, chunk_texts
        )
        embeddings = embeddings_array.tolist()

        # Prepare batch with pre-computed embeddings
        chunk_batch: list[dict] = []
        for i, chunk in enumerate(text_chunks):
            chunk_text_str: str = chunk.text

            # Extract entities using facility-aware extractor
            entities = extractor.extract(chunk_text_str)
            props = extractor.to_chunk_properties(entities)

            # Content hash for deduplication (first 16 hex chars of SHA-256)
            text_hash = hashlib.sha256(chunk_text_str.encode()).hexdigest()[:16]

            chunk_batch.append(
                {
                    "id": f"{document_id}:chunk_{i}",
                    "document_id": document_id,
                    "facility_id": self.facility_id,
                    "text": chunk_text_str,
                    "embedding": embeddings[i],
                    "content_hash": text_hash,
                    **props,
                }
            )

        # Persist chunks
        with GraphClient() as gc:
            # Update document status
            gc.query(
                """
                MATCH (wa:Document {id: $id})
                SET wa.status = 'ingested',
                    wa.chunk_count = $chunks,
                    wa.ingested_at = datetime(),
                    wa.claimed_at = null
                """,
                id=document_id,
                chunks=len(text_chunks),
            )

            # Batch persist chunks
            for i in range(0, len(chunk_batch), BATCH_SIZE):
                batch = chunk_batch[i : i + BATCH_SIZE]
                gc.query(
                    """
                    UNWIND $chunks AS chunk
                    MERGE (c:WikiChunk {id: chunk.id})
                    SET c.document_id = chunk.document_id,
                        c.facility_id = chunk.facility_id,
                        c.text = chunk.text,
                        c.embedding = chunk.embedding,
                        c.content_hash = chunk.content_hash,
                        c.mdsplus_paths_mentioned = chunk.mdsplus_paths,
                        c.imas_paths_mentioned = chunk.imas_paths,
                        c.ppf_paths_mentioned = chunk.ppf_paths,
                        c.units_mentioned = chunk.units,
                        c.conventions_mentioned = chunk.conventions,
                        c.tool_mentions = chunk.tool_mentions
                    WITH c, chunk
                    MATCH (wa:Document {id: chunk.document_id})
                    MERGE (wa)-[:HAS_CHUNK]->(c)
                    WITH c, chunk
                    MATCH (f:Facility {id: chunk.facility_id})
                    MERGE (c)-[:AT_FACILITY]->(f)
                    """,
                    chunks=batch,
                )

        return stats

    async def ingest_from_graph(
        self,
        limit: int | None = None,
        min_score_composite: float = 0.5,
    ) -> dict[str, int]:
        """Ingest documents from the graph queue.

        Pre-checks file size via HTTP HEAD before downloading. Documents
        exceeding max_size_bytes are marked as 'deferred' with size stored.
        Currently only processes PDFs. Other types are marked as deferred.

        Args:
            limit: Maximum documents to process (None for all)
            min_score_composite: Minimum score threshold

        Returns:
            Stats dict
        """
        total_stats = {
            "documents": 0,
            "documents_failed": 0,
            "documents_deferred": 0,
            "documents_oversized": 0,
            "chunks": 0,
        }

        pending = get_pending_wiki_documents(
            self.facility_id,
            limit=limit,
            min_score_composite=min_score_composite,
        )

        if not pending:
            logger.info("No pending documents for %s", self.facility_id)
            return total_stats

        for document in pending:
            document_id = document["id"]
            document_type = document.get("document_type", "unknown")
            url = document["url"]
            filename = document.get("filename", "unknown")

            try:
                # Check size before downloading
                size_bytes = fetch_document_size(url, facility=self.facility_id)

                if size_bytes is not None:
                    # Update size in graph
                    with GraphClient() as gc:
                        gc.query(
                            """
                            MATCH (wa:Document {id: $id})
                            SET wa.size_bytes = $size
                            """,
                            id=document_id,
                            size=size_bytes,
                        )

                    # Check against limit
                    if size_bytes > self.max_size_bytes:
                        size_mb = size_bytes / (1024 * 1024)
                        max_mb = self.max_size_bytes / (1024 * 1024)
                        defer_reason = (
                            f"File size {size_mb:.1f} MB exceeds limit {max_mb:.1f} MB"
                        )
                        logger.info(
                            "Deferring oversized document %s: %s",
                            filename,
                            defer_reason,
                        )
                        with GraphClient() as gc:
                            gc.query(
                                """
                                MATCH (wa:Document {id: $id})
                                SET wa.status = 'deferred',
                                    wa.defer_reason = $reason
                                """,
                                id=document_id,
                                reason=defer_reason,
                            )
                        total_stats["documents_deferred"] += 1
                        total_stats["documents_oversized"] += 1
                        continue

                if document_type == "pdf":
                    _, content = await fetch_document_content(
                        url, facility=self.facility_id
                    )
                    stats = await self.ingest_pdf(document_id, content)
                    total_stats["documents"] += 1
                    total_stats["chunks"] += stats["chunks"]
                else:
                    # Mark non-PDF as deferred
                    with GraphClient() as gc:
                        gc.query(
                            """
                            MATCH (wa:Document {id: $id})
                            SET wa.status = 'deferred',
                                wa.defer_reason = $reason
                            """,
                            id=document_id,
                            reason=f"Document type '{document_type}' not yet supported",
                        )
                    total_stats["documents_deferred"] += 1

            except Exception as e:
                logger.error("Failed to ingest document %s: %s", document_id, e)
                with GraphClient() as gc:
                    gc.query(
                        """
                        MATCH (wa:Document {id: $id})
                        SET wa.status = 'failed', wa.error = $error
                        """,
                        id=document_id,
                        error=str(e),
                    )
                total_stats["documents_failed"] += 1

        return total_stats


__all__ = [
    "DocumentIngestionStats",
    "DEFAULT_MAX_ARTIFACT_SIZE_MB",
    "ProgressCallback",
    "DocumentPipeline",
    "WikiIngestionPipeline",
    "clear_facility_wiki",
    "fetch_document_content",
    "fetch_document_size",
    "get_embed_model",
    "get_pending_wiki_documents",
    "get_pending_wiki_pages",
    "get_wiki_queue_stats",
    "get_wiki_stats",
    "html_to_text",
    "link_chunks_to_entities",
    "mark_wiki_page_status",
    "persist_chunks_batch",
]
