"""
Semantic search over clusters using centroid and label embeddings.

This module provides functionality to search clusters by comparing
a query embedding to cluster centroids or label embeddings.

Embeddings are loaded from a compressed .npz file (cluster_embeddings.npz)
for efficiency, rather than being stored in the JSON clusters file.

Supports hierarchical clusters (global/domain/IDS levels) with composite
ranking that blends semantic similarity with mapping relevance.
"""

import hashlib
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np

from .models import ClusterScope

logger = logging.getLogger(__name__)


@dataclass
class ClusterSearchResult:
    """Result from semantic cluster search."""

    cluster_id: str  # UUID
    similarity_score: float
    is_cross_ids: bool
    ids_names: list[str]
    paths: list[str]
    cluster_similarity: float  # Internal cluster similarity
    label: str = ""
    description: str = ""

    # Hierarchical scope (NEW)
    scope: ClusterScope = "global"
    scope_detail: str | None = None

    # Enrichment fields (NEW)
    physics_concepts: list[str] = field(default_factory=list)
    data_type: str | None = None
    tags: list[str] = field(default_factory=list)
    mapping_relevance: str = "medium"

    # Composite ranking score (NEW)
    relevance_score: float | None = None

    def compute_relevance_score(self, query_similarity: float | None = None) -> float:
        """Compute composite relevance score for ranking.

        Blends semantic similarity with mapping relevance, cluster type,
        and scope to produce a unified ranking score.

        Args:
            query_similarity: Override similarity score (uses self.similarity_score if None)

        Returns:
            Composite relevance score (0-1)
        """
        sim = (
            query_similarity if query_similarity is not None else self.similarity_score
        )

        # Base: semantic similarity (50% weight)
        score = sim * 0.5

        # Mapping relevance boost (up to 25%)
        relevance_weights = {"high": 0.25, "medium": 0.15, "low": 0.0}
        score += relevance_weights.get(self.mapping_relevance, 0.1)

        # Cross-IDS boost (10%) - broader applicability
        if self.is_cross_ids:
            score += 0.1

        # Scope boost - higher abstraction levels
        scope_weights: dict[str, float] = {"global": 0.1, "domain": 0.05, "ids": 0.0}
        score += scope_weights.get(self.scope, 0.0)

        # Internal coherence boost (5%)
        score += self.cluster_similarity * 0.05

        self.relevance_score = min(1.0, score)
        return self.relevance_score


@dataclass
class ClusterSearcher:
    """Searches clusters using embedding vectors and label embeddings for semantic similarity.

    Embeddings are loaded from a compressed .npz file for efficiency.
    The embeddings file must match the expected hash stored in clusters.json.

    The ``centroids`` attribute holds cluster-level embedding vectors (mean of
    member path embeddings). In the graph these are stored as the ``embedding``
    property on IMASSemanticCluster nodes.
    """

    clusters: list[dict[str, Any]]
    embeddings_file: Path | None = None
    expected_embeddings_hash: str | None = None
    centroids: np.ndarray | None = field(default=None, init=False)
    label_embeddings: np.ndarray | None = field(default=None, init=False)
    cluster_ids: list[str] = field(default_factory=list, init=False)  # UUIDs
    label_cluster_ids: list[str] = field(default_factory=list, init=False)  # UUIDs
    _indexes: dict[str, Any] = field(default_factory=dict, init=False)
    _embeddings_loaded: bool = field(default=False, init=False)

    def __post_init__(self):
        """Build indexes from clusters. Embeddings are loaded lazily."""
        self._build_indexes()

    def _load_embeddings(self) -> None:
        """Load embeddings from .npz file with hash validation."""
        if self._embeddings_loaded:
            return

        if self.embeddings_file is None or not self.embeddings_file.exists():
            logger.warning(
                f"Embeddings file not found: {self.embeddings_file}. "
                "Semantic search will be unavailable."
            )
            self._embeddings_loaded = True
            return

        # Validate hash if provided
        if self.expected_embeddings_hash:
            actual_hash = hashlib.sha256(self.embeddings_file.read_bytes()).hexdigest()[
                :16
            ]
            if actual_hash != self.expected_embeddings_hash:
                raise ValueError(
                    f"Embeddings file hash mismatch: expected {self.expected_embeddings_hash}, "
                    f"got {actual_hash}. Rebuild clusters to sync files."
                )

        # Load embeddings from .npz
        # allow_pickle=True is needed for string UUID cluster IDs
        try:
            data = np.load(self.embeddings_file, allow_pickle=True)

            # Load centroids
            if "centroids" in data and data["centroids"].size > 0:
                self.centroids = data["centroids"]
                self.cluster_ids = data["centroid_cluster_ids"].tolist()
                logger.debug(
                    f"Loaded centroids: {self.centroids.shape[0]} clusters, "
                    f"dim={self.centroids.shape[1]}"
                )
            else:
                logger.warning("No centroid embeddings found in .npz file")

            # Load label embeddings
            if "label_embeddings" in data and data["label_embeddings"].size > 0:
                self.label_embeddings = data["label_embeddings"]
                self.label_cluster_ids = data["label_cluster_ids"].tolist()
                logger.debug(
                    f"Loaded label embeddings: {self.label_embeddings.shape[0]} clusters"
                )
            else:
                logger.debug("No label embeddings found in .npz file")

        except Exception as e:
            logger.error(f"Failed to load embeddings from {self.embeddings_file}: {e}")
            raise

        self._embeddings_loaded = True

    def _build_indexes(self) -> None:
        """Build path and IDS indexes for fast lookup."""
        path_index: dict[str, list[int]] = {}
        ids_index: dict[str, list[int]] = {}

        for cluster in self.clusters:
            cluster_id = cluster["id"]

            # Path index
            for path in cluster.get("paths", []):
                if path not in path_index:
                    path_index[path] = []
                path_index[path].append(cluster_id)

            # IDS index
            ids_names = cluster.get("ids_names", cluster.get("ids", []))
            for ids_name in ids_names:
                if ids_name not in ids_index:
                    ids_index[ids_name] = []
                if cluster_id not in ids_index[ids_name]:
                    ids_index[ids_name].append(cluster_id)

        self._indexes = {
            "path": path_index,
            "ids": ids_index,
        }

    def search_by_path(self, path: str) -> list[ClusterSearchResult]:
        """Find clusters containing a specific path.

        Args:
            path: IMAS path to search for

        Returns:
            List of clusters containing this path
        """
        cluster_ids = self._indexes.get("path", {}).get(path, [])
        results = []
        for cluster_id in cluster_ids:
            cluster = self._get_cluster_by_id(cluster_id)
            if cluster:
                results.append(self._cluster_to_result(cluster, similarity_score=1.0))
        return results

    def get_cluster_labels_for_path(self, path: str) -> list[dict[str, str]]:
        """Get cluster labels and descriptions for a specific path.

        Args:
            path: IMAS path to look up

        Returns:
            List of dicts with 'label' and 'description' for each cluster
            containing this path. Empty list if path not in any cluster.
        """
        results = self.search_by_path(path)
        return [
            {"label": r.label, "description": r.description}
            for r in results
            if r.label  # Only include clusters with labels
        ]

    def search_by_ids(
        self, ids_name: str, cross_ids_only: bool = False
    ) -> list[ClusterSearchResult]:
        """Find clusters containing paths from a specific IDS.

        Args:
            ids_name: IDS name to search for
            cross_ids_only: Only return cross-IDS clusters

        Returns:
            List of clusters containing this IDS
        """
        cluster_ids = self._indexes.get("ids", {}).get(ids_name, [])
        results = []
        for cluster_id in cluster_ids:
            cluster = self._get_cluster_by_id(cluster_id)
            if cluster:
                is_cross = cluster.get(
                    "is_cross_ids", cluster.get("type") == "cross_ids"
                )
                if cross_ids_only and not is_cross:
                    continue
                results.append(self._cluster_to_result(cluster, similarity_score=1.0))
        return results

    def search(
        self,
        query_embedding: np.ndarray,
        top_k: int = 10,
        similarity_threshold: float = 0.3,
        cross_ids_only: bool = False,
        use_labels: bool = False,
        scope: ClusterScope | None = None,
        use_relevance_ranking: bool = True,
    ) -> list[ClusterSearchResult]:
        """Search for clusters most similar to the query embedding.

        Args:
            query_embedding: Query embedding vector (normalized)
            top_k: Maximum number of results to return
            similarity_threshold: Minimum similarity score to include
            cross_ids_only: If True, only return cross-IDS clusters
            use_labels: If True, search label embeddings instead of centroids
            scope: Filter by scope level ("global", "domain", "ids")
            use_relevance_ranking: If True, rank by composite relevance score

        Returns:
            List of ClusterSearchResult sorted by relevance or similarity
        """
        # Lazy-load embeddings on first semantic search
        self._load_embeddings()

        if use_labels:
            embeddings = self.label_embeddings
            cluster_ids = self.label_cluster_ids
        else:
            embeddings = self.centroids
            cluster_ids = self.cluster_ids

        if embeddings is None or len(embeddings) == 0:
            logger.warning("No embeddings available for search")
            return []

        # Ensure query is normalized
        query_norm = np.linalg.norm(query_embedding)
        if query_norm > 0:
            query_embedding = query_embedding / query_norm

        # Compute similarities via dot product (embeddings are normalized)
        similarities = np.dot(embeddings, query_embedding)

        # Build results
        results = []
        for i, sim in enumerate(similarities):
            if sim < similarity_threshold:
                continue

            cluster_id = cluster_ids[i]
            cluster = self._get_cluster_by_id(cluster_id)
            if cluster is None:
                continue

            is_cross = cluster.get("is_cross_ids", cluster.get("type") == "cross_ids")
            if cross_ids_only and not is_cross:
                continue

            # Filter by scope if specified
            if scope is not None and cluster.get("scope") != scope:
                continue

            results.append(self._cluster_to_result(cluster, float(sim)))

        # Sort by relevance score or similarity
        if use_relevance_ranking:
            results.sort(key=lambda r: r.relevance_score or 0, reverse=True)
        else:
            results.sort(key=lambda r: r.similarity_score, reverse=True)

        return results[:top_k]

    def search_by_text(
        self,
        query: str,
        encoder,
        top_k: int = 10,
        similarity_threshold: float = 0.3,
        cross_ids_only: bool = False,
        scope: ClusterScope | None = None,
    ) -> list[ClusterSearchResult]:
        """Search clusters using a text query.

        Automatically detects if query is a path (contains '/') or natural language.
        For paths, uses exact lookup. For natural language, searches both
        centroids and label embeddings with composite relevance ranking.

        Args:
            query: Text query to search for (path or natural language)
            encoder: Encoder instance to generate query embedding
            top_k: Maximum number of results
            similarity_threshold: Minimum similarity
            cross_ids_only: Only return cross-IDS clusters
            scope: Filter by scope level ("global", "domain", "ids")

        Returns:
            List of ClusterSearchResult sorted by relevance score
        """
        # Detect if query is a path
        if "/" in query and " " not in query:
            # Path lookup
            results = self.search_by_path(query)
            if cross_ids_only:
                results = [r for r in results if r.is_cross_ids]
            if scope is not None:
                results = [r for r in results if r.scope == scope]
            return results[:top_k]

        # Natural language query - search both centroids and labels
        query_embedding = encoder.embed_texts([query])[0]

        # Search centroids (physics concept similarity)
        centroid_results = self.search(
            query_embedding,
            top_k=top_k * 2,
            similarity_threshold=similarity_threshold,
            cross_ids_only=cross_ids_only,
            use_labels=False,
            scope=scope,
            use_relevance_ranking=True,
        )

        # Search label embeddings if available
        label_results = []
        if self.label_embeddings is not None:
            label_results = self.search(
                query_embedding,
                top_k=top_k * 2,
                similarity_threshold=similarity_threshold,
                cross_ids_only=cross_ids_only,
                use_labels=True,
                scope=scope,
                use_relevance_ranking=True,
            )

        # Merge and deduplicate results
        seen_ids: set[str] = set()
        merged = []

        # Interleave results, preferring higher relevance score
        all_results = centroid_results + label_results
        all_results.sort(key=lambda r: r.relevance_score or 0, reverse=True)

        for result in all_results:
            if result.cluster_id not in seen_ids:
                seen_ids.add(result.cluster_id)
                merged.append(result)
                if len(merged) >= top_k:
                    break

        return merged

    def _get_cluster_by_id(self, cluster_id: str) -> dict[str, Any] | None:
        """Get cluster by UUID."""
        for cluster in self.clusters:
            if cluster["id"] == cluster_id:
                return cluster
        return None

    def _cluster_to_result(
        self, cluster: dict[str, Any], similarity_score: float
    ) -> ClusterSearchResult:
        """Convert cluster dict to ClusterSearchResult."""
        is_cross = cluster.get("is_cross_ids", cluster.get("type") == "cross_ids")
        ids_names = cluster.get("ids_names", cluster.get("ids", []))
        cluster_sim = cluster.get("similarity_score", cluster.get("similarity", 0.0))

        result = ClusterSearchResult(
            cluster_id=cluster["id"],
            similarity_score=similarity_score,
            is_cross_ids=is_cross,
            ids_names=ids_names,
            paths=cluster.get("paths", []),
            cluster_similarity=cluster_sim,
            label=cluster.get("label", ""),
            description=cluster.get("description", ""),
            # Hierarchical scope
            scope=cluster.get("scope", "global"),
            scope_detail=cluster.get("scope_detail"),
            # Enrichment fields
            physics_concepts=cluster.get("physics_concepts", []),
            data_type=cluster.get("data_type"),
            tags=cluster.get("tags", []),
            mapping_relevance=cluster.get("mapping_relevance", "medium"),
        )

        # Compute composite relevance score
        result.compute_relevance_score()

        return result

    def get_similar_clusters(
        self,
        cluster_id: str,
        top_k: int = 5,
        similarity_threshold: float = 0.5,
    ) -> list[ClusterSearchResult]:
        """Find clusters similar to a given cluster.

        Args:
            cluster_id: UUID of the source cluster
            top_k: Maximum number of results
            similarity_threshold: Minimum similarity

        Returns:
            List of similar clusters (excluding the source)
        """
        # Load embeddings and look up centroid by cluster ID
        self._load_embeddings()

        if self.centroids is None or cluster_id not in self.cluster_ids:
            return []

        # Get centroid for the source cluster
        idx = self.cluster_ids.index(cluster_id)
        centroid = self.centroids[idx]

        results = self.search(
            centroid,
            top_k=top_k + 1,  # +1 to account for self
            similarity_threshold=similarity_threshold,
        )

        # Remove the source cluster from results
        return [r for r in results if r.cluster_id != cluster_id][:top_k]
