"""CLI interface for IMAS Codex Server.

Modular CLI structure with command groups split by functionality.
"""

# Warning filters are set in imas_codex/__init__.py at package import time
# to ensure they're applied before any aiohttp imports.

import logging

import click

from imas_codex import __version__

# Load environment variables from .env file
try:
    from dotenv import load_dotenv

    load_dotenv(override=True)
except ModuleNotFoundError:
    pass

# Configure logging
logger = logging.getLogger(__name__)


# Create the main CLI group
@click.group(invoke_without_command=True)
@click.option(
    "--version",
    is_flag=True,
    help="Show the imas-codex version and exit.",
)
@click.pass_context
def main(ctx: click.Context, version: bool) -> None:
    """IMAS Codex - AI-enhanced MCP servers for fusion data.

    Use subcommands to start servers or manage data:

    \b
      imas-codex serve              Start the MCP server
      imas-codex graph start        Start Neo4j graph database
      imas-codex embed start        Start GPU embedding server
      imas-codex llm start          Start LiteLLM proxy
      imas-codex tunnel start       Start SSH tunnels
      imas-codex config private     Manage private facility YAML
      imas-codex imas dd build       Build/update IMAS DD graph
      imas-codex facilities list    List configured facilities
    """
    if version:
        click.echo(__version__)
        ctx.exit()

    # If no subcommand, show help
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def register_commands() -> None:
    """Register all command groups with the main CLI."""
    from imas_codex.cli.compute import hpc
    from imas_codex.cli.config_cli import config
    from imas_codex.cli.credentials import credentials
    from imas_codex.cli.discover import discover
    from imas_codex.cli.embed import embed
    from imas_codex.cli.facilities import facilities
    from imas_codex.cli.graph import graph
    from imas_codex.cli.host import host
    from imas_codex.cli.imas_dd import imas
    from imas_codex.cli.llm_cli import llm
    from imas_codex.cli.release import release
    from imas_codex.cli.serve import serve
    from imas_codex.cli.tools import tools
    from imas_codex.cli.tunnel import tunnel

    main.add_command(serve)
    main.add_command(graph)
    main.add_command(llm)
    main.add_command(tunnel)
    main.add_command(config)
    main.add_command(hpc)
    main.add_command(discover)
    main.add_command(embed)
    main.add_command(imas)
    main.add_command(tools)
    main.add_command(host)
    main.add_command(facilities)
    main.add_command(release)
    main.add_command(credentials)


# Register commands at import time
register_commands()

__all__ = ["main"]
