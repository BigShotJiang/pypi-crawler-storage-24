"""Constants for IMAS Codex models.

This module contains all constant definitions used across search, response, and physics models.
"""

from enum import Enum, StrEnum

# ============================================================================
# SEARCH CONSTANTS
# ============================================================================


class SearchMode(Enum):
    """Enumeration of available search modes."""

    SEMANTIC = "semantic"  # AI-powered semantic search using sentence transformers
    LEXICAL = "lexical"  # Traditional full-text search using SQLite FTS5
    HYBRID = "hybrid"  # Combination of semantic and lexical search
    AUTO = "auto"  # Automatically choose best mode based on query


# Score thresholds for search confidence warnings
# Calibrated from empirical testing:
# - Good queries (Te, magnetic field, plasma current): scores >= 0.65
# - Marginal queries: scores 0.35-0.65
# - Poor/nonsense queries (xyzzy, qwertyuiop): scores < 0.35
LOW_CONFIDENCE_THRESHOLD = 0.35  # Warn user results may not be relevant
VERY_LOW_CONFIDENCE_THRESHOLD = 0.25  # Strongly warn - likely nonsense query


# ============================================================================
# RESPONSE CONSTANTS
# ============================================================================


class DetailLevel(StrEnum):
    """Detail levels for explanations."""

    BASIC = "basic"
    INTERMEDIATE = "intermediate"
    ADVANCED = "advanced"


class ResponseProfile(StrEnum):
    """Response formatting presets for search results."""

    MINIMAL = "minimal"  # Results only, no extras
    STANDARD = "standard"  # Results + physics context (default)
    DETAILED = "detailed"  # Results + full AI enhancement


class RelationshipType(StrEnum):
    """Types of relationships to explore."""

    ALL = "all"
    SEMANTIC = "semantic"
    STRUCTURAL = "structural"
    PHYSICS = "physics"
    MEASUREMENT = "measurement"


class IdentifierScope(StrEnum):
    """Scopes for identifier exploration."""

    ALL = "all"
    ENUMS = "enums"
    IDENTIFIERS = "identifiers"
    COORDINATES = "coordinates"
    CONSTANTS = "constants"


class OutputFormat(StrEnum):
    """Output formats for export tools."""

    STRUCTURED = "structured"
    JSON = "json"
    YAML = "yaml"
    MARKDOWN = "markdown"


class AnalysisDepth(StrEnum):
    """Analysis depth levels for exports."""

    OVERVIEW = "overview"
    FOCUSED = "focused"
    COMPREHENSIVE = "comprehensive"
    DETAILED = "detailed"


# ============================================================================
# PHYSICS CONSTANTS
# ============================================================================


class ConceptType(StrEnum):
    """Types of physics concepts that can be embedded."""

    DOMAIN = "domain"
    PHENOMENON = "phenomenon"
    UNIT = "unit"
    MEASUREMENT_METHOD = "measurement_method"


class ComplexityLevel(StrEnum):
    """Complexity levels for concept explanations."""

    BASIC = "basic"
    INTERMEDIATE = "intermediate"
    ADVANCED = "advanced"


class UnitCategory(StrEnum):
    """Categories for physics units."""

    MAGNETIC_FIELD = "magnetic_field"
    TEMPERATURE = "temperature"
    PRESSURE = "pressure"
    DENSITY = "density"
    ENERGY = "energy"
    TIME = "time"
    LENGTH = "length"
    VELOCITY = "velocity"
    CURRENT = "current"
    VOLTAGE = "voltage"
    FORCE = "force"
    POWER = "power"
    FREQUENCY = "frequency"
    ANGULAR_FREQUENCY = "angular_frequency"
    DIMENSIONLESS = "dimensionless"
    UNKNOWN = "unknown"
