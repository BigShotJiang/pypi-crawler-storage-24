"""Schema-driven graph ontology derived from LinkML.

This module provides runtime introspection of the LinkML schema
(schemas/facility.yaml) to derive Neo4j node labels, relationship types,
and constraints. This is the single source of truth for the graph structure.

Example:
    >>> from imas_codex.graph.schema import GraphSchema
    >>> schema = GraphSchema()
    >>> print(schema.node_labels)
    ['Facility', 'MDSplusServer', 'DataSource', ...]
    >>> print(schema.get_identifier("Facility"))
    'id'
    >>> print(schema.get_relationships("MDSplusServer"))
    [('MDSplusServer', 'facility_id', 'Facility'), ...]
"""

from dataclasses import dataclass
from enum import Enum
from functools import cached_property
from pathlib import Path
from typing import Any

from linkml_runtime.utils.schemaview import SchemaView


def _get_schema_path() -> Path:
    """Get the path to the LinkML schema file."""
    return Path(__file__).parent.parent / "schemas" / "facility.yaml"


@dataclass(frozen=True)
class Relationship:
    """A relationship derived from a LinkML slot with class range.

    Attributes:
        from_class: Source class name (Neo4j label)
        slot_name: LinkML slot name
        to_class: Target class name (Neo4j label)
        multivalued: Whether the slot is multivalued
        _cypher_type: Explicit Cypher relationship type override
    """

    from_class: str
    slot_name: str
    to_class: str
    multivalued: bool = False
    _cypher_type: str | None = None

    @property
    def cypher_type(self) -> str:
        """Convert to Neo4j relationship type (SCREAMING_SNAKE_CASE).

        Uses the ``relationship_type`` annotation from LinkML schema if
        present, otherwise falls back to uppercased slot name.
        """
        if self._cypher_type:
            return self._cypher_type
        # e.g., "writes_to" -> "WRITES_TO", "has_chunk" -> "HAS_CHUNK"
        return self.slot_name.upper()


class GraphSchema:
    """Schema-driven graph ontology derived from LinkML.

    This class provides runtime introspection of the LinkML schema to derive:
    - Node labels (class names)
    - Relationship types (slots with class ranges)
    - Identifier fields per class
    - Constraint definitions

    All information is derived from schemas/facility.yaml, making it the
    single source of truth for the graph structure.
    """

    def __init__(self, schema_path: Path | str | None = None) -> None:
        """Initialize from LinkML schema.

        Args:
            schema_path: Path to LinkML schema YAML. Defaults to schemas/facility.yaml.
        """
        self._schema_path = Path(schema_path) if schema_path else _get_schema_path()
        self._view = SchemaView(str(self._schema_path))

    @cached_property
    def node_labels(self) -> list[str]:
        """Get all node labels (non-abstract class names)."""
        return [
            name
            for name, cls in self._view.all_classes().items()
            if not getattr(cls, "abstract", False) and not name.startswith("_")
        ]

    @cached_property
    def abstract_classes(self) -> list[str]:
        """Get abstract class names (not instantiated as nodes)."""
        return [
            name
            for name, cls in self._view.all_classes().items()
            if getattr(cls, "abstract", False)
        ]

    @cached_property
    def relationships(self) -> list[Relationship]:
        """Get all relationships derived from slots with class ranges."""
        rels = []
        for class_name in self.node_labels:
            for slot in self._view.class_induced_slots(class_name):
                slot_range = slot.range
                # Check if range is a class (relationship) vs primitive type
                if slot_range and slot_range in self._view.all_classes():
                    # Check for explicit relationship_type annotation
                    # annotations can be dict, JsonObj, or None
                    annotations = getattr(slot, "annotations", None) or {}
                    # Handle both dict and JsonObj-style access
                    rel_type_ann = (
                        annotations.get("relationship_type")
                        if isinstance(annotations, dict)
                        else getattr(annotations, "relationship_type", None)
                    )
                    cypher_type = (
                        rel_type_ann.value
                        if rel_type_ann and hasattr(rel_type_ann, "value")
                        else None
                    )
                    rels.append(
                        Relationship(
                            from_class=class_name,
                            slot_name=slot.name,
                            to_class=slot_range,
                            multivalued=bool(slot.multivalued),
                            _cypher_type=cypher_type,
                        )
                    )
        return rels

    @cached_property
    def relationship_types(self) -> list[str]:
        """Get unique relationship type names (SCREAMING_SNAKE_CASE)."""
        return sorted({rel.cypher_type for rel in self.relationships})

    @cached_property
    def embeddable_labels(self) -> list[str]:
        """Get node labels that have an 'embedding' slot.

        Used in tests to verify embedding dimensions and quality.
        """
        return sorted(
            label
            for label in self.node_labels
            if "embedding" in self.get_all_slots(label)
        )

    @cached_property
    def description_embeddable_labels(self) -> list[str]:
        """Get node labels with both 'description' and 'embedding' slots.

        These are nodes where we embed their description text.
        Used to test description-to-embedding correlation.
        """
        return sorted(
            label
            for label in self.node_labels
            if "embedding" in self.get_all_slots(label)
            and "description" in self.get_all_slots(label)
        )

    @cached_property
    def text_embeddable_labels(self) -> list[str]:
        """Get node labels with 'text' and 'embedding' but no 'description'.

        These are chunk nodes (CodeChunk, WikiChunk) where we embed
        their text content rather than a description field.
        """
        return sorted(
            label
            for label in self.node_labels
            if "embedding" in self.get_all_slots(label)
            and "text" in self.get_all_slots(label)
            and "description" not in self.get_all_slots(label)
        )

    @cached_property
    def vector_indexes(self) -> list[tuple[str, str, str]]:
        """Derive vector indexes from schema based on embedding slots.

        Returns list of (index_name, node_label, property_name) tuples.

        Index naming:
        - Uses `vector_index_name` annotation if present on slot
        - Otherwise follows convention:
          - Classes with embedding + description: {label_snake}_desc_embedding
          - Classes with embedding only: {label_snake}_embedding
        """
        import re

        def to_snake(name: str) -> str:
            """Convert CamelCase to snake_case, handling acronyms."""
            # Handle IMAS specially - it's an acronym
            name = name.replace("IMAS", "Imas")
            # Insert underscore before uppercase letters, then lowercase
            s1 = re.sub(r"(.)([A-Z][a-z]+)", r"\1_\2", name)
            return re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", s1).lower()

        def get_vector_annotation(slot) -> str | None:
            """Get vector_index_name annotation if present."""
            annotations = getattr(slot, "annotations", None) or {}
            ann = (
                annotations.get("vector_index_name")
                if isinstance(annotations, dict)
                else getattr(annotations, "vector_index_name", None)
            )
            return ann.value if ann and hasattr(ann, "value") else None

        indexes = []
        for label in self.node_labels:
            label_snake = to_snake(label)

            for slot in self._view.class_induced_slots(label):
                slot_name = slot.name
                custom_name = get_vector_annotation(slot)

                # Process slots named "embedding" OR with explicit vector_index_name
                if slot_name != "embedding" and not custom_name:
                    continue

                if custom_name:
                    index_name = custom_name
                else:
                    slots = self.get_all_slots(label)
                    has_desc = "description" in slots
                    if has_desc:
                        index_name = f"{label_snake}_desc_embedding"
                    else:
                        index_name = f"{label_snake}_embedding"

                indexes.append((index_name, label, slot_name))

        return indexes

    @cached_property
    def fulltext_indexes(self) -> list[tuple[str, str, list[str]]]:
        """Derive fulltext indexes from class-level annotations.

        Returns list of (index_name, node_label, [property_names]) tuples.

        Annotation format on a class:
            fulltext_index:
              tag: fulltext_index
              value: "index_name:prop1,prop2"
        """
        indexes = []
        for label in self.node_labels:
            cls_def = self._view.get_class(label)
            annotations = getattr(cls_def, "annotations", None) or {}
            ann = (
                annotations.get("fulltext_index")
                if isinstance(annotations, dict)
                else getattr(annotations, "fulltext_index", None)
            )
            if not ann:
                continue
            value = ann.value if hasattr(ann, "value") else str(ann)
            # Parse "index_name:prop1,prop2"
            if ":" not in value:
                continue
            idx_name, props_str = value.split(":", 1)
            props = [p.strip() for p in props_str.split(",") if p.strip()]
            if idx_name and props:
                indexes.append((idx_name, label, props))
        return indexes

    def get_identifier(self, class_name: str) -> str | None:
        """Get the identifier field for a class.

        Args:
            class_name: Name of the class (node label)

        Returns:
            Name of the identifier slot, or None if not found.
        """
        for slot in self._view.class_induced_slots(class_name):
            if getattr(slot, "identifier", False):
                return slot.name
        return None

    def get_model(self, class_name: str) -> type:
        """Get the Pydantic model class for a node label.

        Args:
            class_name: Name of the class (node label)

        Returns:
            Pydantic model class

        Raises:
            ValueError: If class_name is not a valid node label
        """
        if class_name not in self.node_labels:
            msg = f"Unknown node type: {class_name}. Valid: {self.node_labels}"
            raise ValueError(msg)

        # Import models dynamically to avoid circular imports
        from imas_codex.graph import models

        model_class = getattr(models, class_name, None)
        if model_class is None:
            msg = f"Model class not found for {class_name}"
            raise ValueError(msg)
        return model_class

    def get_required_fields(self, class_name: str) -> list[str]:
        """Get required fields for a class.

        Args:
            class_name: Name of the class (node label)

        Returns:
            List of required slot names.
        """
        return [
            slot.name
            for slot in self._view.class_induced_slots(class_name)
            if getattr(slot, "required", False)
        ]

    def get_all_slots(self, class_name: str) -> dict[str, dict[str, Any]]:
        """Get all slots (properties) for a class with their metadata.

        Args:
            class_name: Name of the class (node label)

        Returns:
            Dict mapping slot name to metadata (type, required, identifier).
            Only includes truthy flags for compactness.
        """
        slots = {}
        for slot in self._view.class_induced_slots(class_name):
            # Convert LinkML types (extended_str, TypeDefinitionName) to plain strings
            slot_range = str(slot.range) if slot.range else "string"
            is_relationship = slot_range in self._view.all_classes()

            # Build compact representation (only truthy values)
            info: dict[str, Any] = {"type": slot_range}
            if getattr(slot, "required", False):
                info["required"] = True
            if getattr(slot, "identifier", False):
                info["identifier"] = True
            if getattr(slot, "multivalued", False):
                info["multivalued"] = True
            if is_relationship:
                info["relationship"] = True
            if slot.description:
                info["description"] = str(slot.description)

            # Lifecycle annotation: field only required after reaching a status
            annotations = getattr(slot, "annotations", {}) or {}
            if "required_after" in annotations:
                ann = annotations["required_after"]
                info["required_after"] = (
                    str(ann.value) if hasattr(ann, "value") else str(ann)
                )

            slots[slot.name] = info
        return slots

    def get_enums(self) -> dict[str, list[str]]:
        """Get all enums with their permissible values.

        Returns:
            Dict mapping enum name to list of permissible values.
        """
        enums = {}
        for name, enum_def in self._view.all_enums().items():
            if enum_def.permissible_values:
                enums[name] = list(enum_def.permissible_values.keys())
        return enums

    def get_enum_with_descriptions(self, enum_name: str) -> list[dict[str, str]] | None:
        """Get enum values with their descriptions.

        Args:
            enum_name: Name of the enum (e.g., "DiscoveryRootCategory")

        Returns:
            List of dicts with 'value' and 'description' keys, or None if not found.
        """
        enum_def = self._view.get_enum(enum_name)
        if not enum_def or not enum_def.permissible_values:
            return None

        result = []
        for value, pv in enum_def.permissible_values.items():
            desc = str(pv.description) if pv.description else ""
            result.append({"value": value, "description": desc})
        return result

    def get_class_description(self, class_name: str) -> str | None:
        """Get the description of a class.

        Args:
            class_name: Name of the class (node label)

        Returns:
            Description string or None.
        """
        cls = self._view.get_class(class_name)
        # Convert LinkML extended_str to plain string for JSON serialization
        return str(cls.description) if cls and cls.description else None

    def get_relationships_from(self, class_name: str) -> list[Relationship]:
        """Get relationships originating from a class.

        Args:
            class_name: Name of the source class

        Returns:
            List of relationships where this class is the source.
        """
        return [rel for rel in self.relationships if rel.from_class == class_name]

    def get_relationships_to(self, class_name: str) -> list[Relationship]:
        """Get relationships targeting a class.

        Args:
            class_name: Name of the target class

        Returns:
            List of relationships where this class is the target.
        """
        return [rel for rel in self.relationships if rel.to_class == class_name]

    def get_slot_info(self, class_name: str, slot_name: str) -> dict[str, Any]:
        """Get detailed information about a slot.

        Args:
            class_name: Name of the class
            slot_name: Name of the slot

        Returns:
            Dictionary with slot metadata.
        """
        for slot in self._view.class_induced_slots(class_name):
            if slot.name == slot_name:
                return {
                    "name": str(slot.name),
                    "range": str(slot.range) if slot.range else None,
                    "required": getattr(slot, "required", False),
                    "identifier": getattr(slot, "identifier", False),
                    "multivalued": getattr(slot, "multivalued", False),
                    "description": str(slot.description) if slot.description else None,
                }
        return {}

    def get_private_slots(self, class_name: str) -> list[str]:
        """Get slot names marked with is_private: true annotation.

        Private slots are stored in *_private.yaml files only,
        never written to the graph or included in OCI artifacts.

        Args:
            class_name: Name of the class (node label)

        Returns:
            List of private slot names.
        """
        private_slots = []
        for slot in self._view.class_induced_slots(class_name):
            if slot.annotations:
                # Use getattr for JsonObj - .get() doesn't work on LinkML JsonObj
                ann = getattr(slot.annotations, "is_private", None)
                if ann and str(ann.value).lower() == "true":
                    private_slots.append(slot.name)
        return private_slots

    def is_private_slot(self, class_name: str, slot_name: str) -> bool:
        """Check if a specific slot is marked is_private: true.

        Args:
            class_name: Name of the class (node label)
            slot_name: Name of the slot to check

        Returns:
            True if the slot is private.
        """
        for slot in self._view.class_induced_slots(class_name):
            if slot.name == slot_name and slot.annotations:
                # Use getattr for JsonObj - .get() doesn't work on LinkML JsonObj
                ann = getattr(slot.annotations, "is_private", None)
                return ann is not None and str(ann.value).lower() == "true"
        return False

    def get_public_slots(self, class_name: str) -> list[str]:
        """Get slot names that are NOT marked private.

        Public slots are safe for the graph and OCI artifacts.

        Args:
            class_name: Name of the class (node label)

        Returns:
            List of public slot names.
        """
        private_set = set(self.get_private_slots(class_name))
        return [
            slot.name
            for slot in self._view.class_induced_slots(class_name)
            if slot.name not in private_set
        ]

    # =========================================================================
    # Cypher Generation Helpers
    # =========================================================================

    def needs_composite_constraint(self, class_name: str) -> bool:
        """Check if a class needs a composite (identifier, facility_id) constraint.

        Classes that have both an identifier field AND a required facility_id
        field need composite uniqueness to support multi-facility graphs.

        Args:
            class_name: Name of the class (node label)

        Returns:
            True if the class needs a composite constraint.
        """
        id_field = self.get_identifier(class_name)
        required = self.get_required_fields(class_name)
        # Needs composite if has identifier, has required facility_id,
        # and identifier is not facility_id itself
        return (
            id_field is not None
            and "facility_id" in required
            and id_field != "facility_id"
        )

    def constraint_statements(self) -> list[str]:
        """Generate Neo4j constraint statements for all node types.

        For facility-owned nodes (those with required facility_id), creates
        composite uniqueness constraints on (identifier, facility_id) to
        support multi-facility graphs where the same logical entity can
        exist at different facilities.

        Returns:
            List of Cypher CREATE CONSTRAINT statements.
        """
        statements = []
        for label in self.node_labels:
            id_field = self.get_identifier(label)
            if not id_field:
                continue

            constraint_name = f"{label.lower()}_{id_field}"

            if self.needs_composite_constraint(label):
                # Composite constraint: (identifier, facility_id)
                # Allows same identifier at different facilities
                statements.append(
                    f"CREATE CONSTRAINT {constraint_name} IF NOT EXISTS "
                    f"FOR (n:{label}) REQUIRE (n.{id_field}, n.facility_id) IS UNIQUE"
                )
            else:
                # Simple constraint: just the identifier
                # For Facility, IMASNode, and 1:1 facility mappings
                statements.append(
                    f"CREATE CONSTRAINT {constraint_name} IF NOT EXISTS "
                    f"FOR (n:{label}) REQUIRE n.{id_field} IS UNIQUE"
                )
        return statements

    # Slot names that should be indexed on every class that has them.
    # These are pattern-based: if a class has a `status` slot, it gets
    # a status index automatically.  No need to add each class manually.
    AUTO_INDEX_SLOTS: frozenset[str] = frozenset(
        {
            "status",  # claim-loop status filter
            "claim_token",  # two-step claim verification
            "content_hash",  # dedup gate lookups
            "data_source_name",  # signal/epoch scoping
            "url",  # wiki page lookups
        }
    )

    def index_statements(
        self,
        indexes: dict[str, list[str]] | None = None,
    ) -> list[str]:
        """Generate Neo4j index statements.

        Creates indexes in three layers:
        1. **facility_id** on all facility-owned nodes (auto-derived from schema)
        2. **AUTO_INDEX_SLOTS** — any class that has a slot named in the
           set gets an index automatically (status, claim_token, etc.)
        3. **Extra per-label indexes** for class-specific lookup patterns
           that can't be derived from slot names alone.

        Args:
            indexes: Optional dict mapping label to list of extra fields
                     to index.  If not provided, uses built-in extra indexes.

        Returns:
            List of Cypher CREATE INDEX statements.
        """
        if indexes is None:
            # Class-specific indexes that can't be derived from slot names.
            # Only list properties NOT already covered by AUTO_INDEX_SLOTS
            # or the automatic id prefix index (Layer 1.5 below).
            indexes = {
                "Facility": ["ssh_host"],
                "FacilityPath": ["device_inode"],
                "MDSplusServer": ["role"],
                "SignalNode": ["node_type", "path"],
                "Diagnostic": ["category"],
                "AnalysisCode": ["code_type"],
                "Tool": ["category", "available"],
                "CodeChunk": ["code_example_id"],
                "CodeExample": ["source_file"],
                "FacilitySignal": ["diagnostic"],
                "WikiChunk": ["wiki_page_id"],
                "Document": ["document_type"],
                "IMASNode": ["ids"],
                "IMASMapping": ["ids_name"],
            }

        statements = []

        # Collect constraint names to detect backing-index collisions.
        # Composite uniqueness constraints create a backing index with the
        # same name (e.g. ``codechunk_id``); a single-property index needs
        # a different name so ``IF NOT EXISTS`` doesn't silently skip it.
        constraint_names: set[str] = set()
        for label in self.node_labels:
            id_field = self.get_identifier(label)
            if id_field:
                constraint_names.add(f"{label.lower()}_{id_field}")

        # --- Layer 1: facility_id on all facility-owned nodes ---
        for label in self.node_labels:
            if "facility_id" in self.get_required_fields(label):
                index_name = f"{label.lower()}_facility_id"
                statements.append(
                    f"CREATE INDEX {index_name} IF NOT EXISTS "
                    f"FOR (n:{label}) ON (n.facility_id)"
                )

        # --- Layer 1.5: single-property id index for composite constraints ---
        # Composite uniqueness constraints on (id, facility_id) do NOT
        # efficiently serve id-only lookups in Neo4j — measured at 4x
        # slower for single lookups and 370x slower for UNWIND batches.
        # Create a dedicated single-property index for every label that
        # has a composite constraint so that ``MATCH (n:Label {id: x})``
        # patterns always use an index.
        seen: set[tuple[str, str]] = set()
        for label in self.node_labels:
            if not self.needs_composite_constraint(label):
                continue
            id_field = self.get_identifier(label)
            if not id_field:
                continue
            key = (label, id_field)
            seen.add(key)
            index_name = f"{label.lower()}_{id_field}_idx"
            statements.append(
                f"CREATE INDEX {index_name} IF NOT EXISTS "
                f"FOR (n:{label}) ON (n.{id_field})"
            )

        # --- Layer 2: auto-index slots derived from schema ---
        # Any class that has a slot named in AUTO_INDEX_SLOTS gets an
        # index on that slot.  New classes automatically pick up indexes
        # by simply defining the slot — no manual registration needed.
        for label in self.node_labels:
            slots = self.get_all_slots(label)
            for slot_name in self.AUTO_INDEX_SLOTS:
                if slot_name in slots:
                    key = (label, slot_name)
                    if key not in seen:
                        seen.add(key)
                        index_name = f"{label.lower()}_{slot_name}"
                        statements.append(
                            f"CREATE INDEX {index_name} IF NOT EXISTS "
                            f"FOR (n:{label}) ON (n.{slot_name})"
                        )

        # --- Layer 3: extra per-label indexes ---
        for label, fields in indexes.items():
            if label in self.node_labels:
                for field_name in fields:
                    key = (label, field_name)
                    if key not in seen:
                        seen.add(key)
                        index_name = f"{label.lower()}_{field_name}"
                        if index_name in constraint_names:
                            index_name = f"{index_name}_idx"
                        statements.append(
                            f"CREATE INDEX {index_name} IF NOT EXISTS "
                            f"FOR (n:{label}) ON (n.{field_name})"
                        )
        return statements


# =============================================================================
# Utility Functions (migrated from cypher.py)
# =============================================================================


def to_cypher_props(obj: Any, exclude: set[str] | None = None) -> dict[str, Any]:
    """Convert an object to Neo4j-compatible properties dict.

    Args:
        obj: Object with attributes to convert (dataclass, Pydantic model, etc.)
        exclude: Set of attribute names to exclude

    Returns:
        Dictionary of non-None properties suitable for Cypher queries.
    """
    exclude = exclude or set()

    # Handle different object types
    if hasattr(obj, "model_dump"):
        # Pydantic v2 model
        props = obj.model_dump(exclude_none=True)
    elif hasattr(obj, "dict"):
        # Pydantic v1 model
        props = obj.dict(exclude_none=True)
    elif hasattr(obj, "__dict__"):
        # Regular object/dataclass
        props = {k: v for k, v in obj.__dict__.items() if v is not None}
    else:
        props = dict(obj)

    # Filter excluded and convert enums
    result = {}
    for key, value in props.items():
        if key.startswith("_") or key in exclude:
            continue
        if isinstance(value, Enum):
            result[key] = value.value
        elif isinstance(value, list):
            # Neo4j can store lists of primitives
            result[key] = [v.value if isinstance(v, Enum) else v for v in value]
        else:
            result[key] = value

    return result


def merge_node_query(label: str) -> str:
    """Generate a MERGE query template for a node.

    Args:
        label: Node label (class name)

    Returns:
        Cypher MERGE query template with $id and $props parameters.
    """
    return f"MERGE (n:{label} {{id: $id}}) SET n += $props"


def merge_relationship_query(
    from_label: str,
    to_label: str,
    rel_type: str,
) -> str:
    """Generate a MERGE query template for a relationship.

    Args:
        from_label: Source node label
        to_label: Target node label
        rel_type: Relationship type (SCREAMING_SNAKE_CASE)

    Returns:
        Cypher MERGE query template with $from_id and $to_id parameters.
    """
    return (
        f"MATCH (a:{from_label} {{id: $from_id}}), "
        f"(b:{to_label} {{id: $to_id}}) "
        f"MERGE (a)-[r:{rel_type}]->(b)"
    )


# =============================================================================
# Module-level singleton for convenience
# =============================================================================

_schema = GraphSchema()


def get_schema() -> GraphSchema:
    """Get the global GraphSchema instance."""
    return _schema
