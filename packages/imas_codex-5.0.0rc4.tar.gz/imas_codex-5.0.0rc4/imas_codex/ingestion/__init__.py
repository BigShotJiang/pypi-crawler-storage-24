"""Unified ingestion module for all content types.

Routes files to appropriate processors based on FileCategory:
- code: tree-sitter chunking (Python, Fortran, MATLAB, etc.)
- document: text extraction + sentence chunking (PDF, DOCX, PPTX, HTML)
- notebook: cell-aware chunking (Jupyter)
- data/config/other: metadata-only ingestion

All content types share:
- Embedding via Encoder (local/remote)
- Entity extraction (IDS references, MDSplus paths, units, conventions)
- Unified Chunk graph persistence with NEXT_CHUNK linked lists
- VLM captioning for embedded images

Graph-driven workflow:
1. discover code <facility> → scan + score → CodeFile nodes
2. ingest run <facility> → fetch + chunk + embed + link
"""

from .extractors.ids import extract_ids_references, get_known_ids
from .extractors.mdsplus import (
    MDSplusReference,
    extract_mdsplus_paths,
    normalize_mdsplus_path,
)
from .graph import link_chunks_to_data_nodes, link_chunks_to_imas_paths
from .pipeline import ingest_files
from .queue import (
    get_pending_files,
    get_queue_stats,
    queue_source_files,
    update_source_file_status,
)
from .readers.remote import (
    EXTENSION_TO_LANGUAGE,
    TEXT_SPLITTER_LANGUAGES,
    detect_language,
    fetch_remote_files,
)
from .search import ChunkSearchResult, search_code_chunks

__all__ = [
    "ChunkSearchResult",
    "EXTENSION_TO_LANGUAGE",
    "MDSplusReference",
    "TEXT_SPLITTER_LANGUAGES",
    "detect_language",
    "extract_ids_references",
    "extract_mdsplus_paths",
    "fetch_remote_files",
    "get_known_ids",
    "get_pending_files",
    "get_queue_stats",
    "ingest_files",
    "link_chunks_to_imas_paths",
    "link_chunks_to_data_nodes",
    "normalize_mdsplus_path",
    "queue_source_files",
    "search_code_chunks",
    "update_source_file_status",
]
