#!/usr/bin/env python3
"""Build Pydantic models from LinkML schemas.

Source: imas_codex/schemas/facility.yaml
Output: imas_codex/graph/models.py

To regenerate:
    uv run build-models --force
"""

import logging
import subprocess
import sys
from pathlib import Path

import click


def get_project_root() -> Path:
    """Get the project root directory."""
    return Path(__file__).parent.parent


def get_schemas_dir() -> Path:
    """Get the schemas directory containing LinkML schemas."""
    return get_project_root() / "imas_codex" / "schemas"


def get_graph_dir() -> Path:
    """Get the graph module directory."""
    return get_project_root() / "imas_codex" / "graph"


def get_core_dir() -> Path:
    """Get the core module directory."""
    return get_project_root() / "imas_codex" / "core"


def get_definitions_dir() -> Path:
    """Get the definitions directory."""
    return get_project_root() / "imas_codex" / "definitions"


def get_config_module_dir() -> Path:
    """Get the config module directory for generated models."""
    return get_project_root() / "imas_codex" / "config"


def _generate_physics_domain(
    logger: logging.Logger,
    force: bool,
    dry_run: bool,
) -> int:
    """Generate physics domain enum from LinkML schema.

    Returns:
        0 on success, non-zero on failure.
    """
    from scripts.gen_physics_domains import generate_enum_code

    definitions_dir = get_definitions_dir()
    core_dir = get_core_dir()

    schema_file = definitions_dir / "physics" / "domains.yaml"
    output_file = core_dir / "physics_domain.py"

    if not schema_file.exists():
        logger.error(f"Physics domain schema not found: {schema_file}")
        return 1

    # Check if output already exists and is up to date
    if output_file.exists() and not force:
        if schema_file.stat().st_mtime <= output_file.stat().st_mtime:
            logger.info(f"Physics domain up to date at {output_file}")
            return 0
        logger.info("Physics schema newer than enum, regenerating...")

    logger.info(f"Generating physics domain enum from {schema_file}")

    if dry_run:
        click.echo(f"Would generate: {output_file}")
        return 0

    try:
        code = generate_enum_code(schema_file)
        output_file.write_text(code, encoding="utf-8")
        logger.info(f"Generated physics domain written to {output_file}")
        click.echo(f"Generated: {output_file}")
        return 0
    except Exception as e:
        logger.error(f"Failed to generate physics domain: {e}")
        return 1


def _generate_schema_reference(
    logger: logging.Logger,
    force: bool,
    dry_run: bool,
) -> int:
    """Generate agents/schema-reference.md from LinkML schemas.

    Returns:
        0 on success, non-zero on failure.
    """
    from scripts.gen_schema_reference import generate_schema_reference

    root = get_project_root()
    output_file = root / "agents" / "schema-reference.md"
    schemas_dir = get_schemas_dir()

    # Check freshness
    if output_file.exists() and not force:
        output_mtime = output_file.stat().st_mtime
        schema_files = list(schemas_dir.glob("*.yaml"))
        if all(f.stat().st_mtime <= output_mtime for f in schema_files):
            logger.info(f"Schema reference up to date at {output_file}")
            return 0
        logger.info("Schema files newer than reference, regenerating...")

    if dry_run:
        click.echo(f"Would generate: {output_file}")
        return 0

    try:
        generate_schema_reference(force=True)
        logger.info(f"Generated schema reference at {output_file}")
        click.echo(f"Generated: {output_file}")
        return 0
    except Exception as e:
        logger.warning(f"Schema reference generation failed (non-fatal): {e}")
        return 0  # Non-fatal — models are the priority


def _generate_schema_context(
    logger: logging.Logger,
    force: bool,
    dry_run: bool,
) -> int:
    """Generate imas_codex/graph/schema_context_data.py from LinkML schemas.

    Returns:
        0 on success, non-zero on failure.
    """
    from scripts.gen_schema_context import generate_schema_context

    root = get_project_root()
    output_file = root / "imas_codex" / "graph" / "schema_context_data.py"
    schemas_dir = get_schemas_dir()

    # Check freshness
    if output_file.exists() and not force:
        output_mtime = output_file.stat().st_mtime
        schema_files = list(schemas_dir.glob("*.yaml"))
        if all(f.stat().st_mtime <= output_mtime for f in schema_files):
            logger.info(f"Schema context up to date at {output_file}")
            return 0
        logger.info("Schema files newer than context, regenerating...")

    if dry_run:
        click.echo(f"Would generate: {output_file}")
        return 0

    try:
        generate_schema_context(force=True)
        logger.info(f"Generated schema context at {output_file}")
        click.echo(f"Generated: {output_file}")
        return 0
    except Exception as e:
        logger.warning(f"Schema context generation failed (non-fatal): {e}")
        return 0  # Non-fatal — models are the priority


@click.command()
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose logging output")
@click.option("--quiet", "-q", is_flag=True, help="Suppress all logging except errors")
@click.option(
    "--force", "-f", is_flag=True, help="Force rebuild even if files already exist"
)
@click.option(
    "--dry-run",
    is_flag=True,
    help="Show what would be generated without writing files",
)
def build_models(
    verbose: bool,
    quiet: bool,
    force: bool,
    dry_run: bool,
) -> int:
    """Generate Pydantic models from LinkML schemas.

    This command generates:
    1. Physics domain enum from definitions/physics/domains.yaml
    2. Graph Pydantic models from schemas/facility.yaml
    3. IMAS DD models from schemas/imas_dd.yaml

    Examples:
        build-models              # Generate all models
        build-models -v           # Verbose output
        build-models --dry-run    # Preview without writing
        build-models -f           # Force regeneration
    """
    # Set up logging level
    if quiet:
        log_level = logging.ERROR
    elif verbose:
        log_level = logging.DEBUG
    else:
        log_level = logging.INFO

    logging.basicConfig(
        level=log_level, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )
    logger = logging.getLogger(__name__)

    try:
        # Generate physics domain enum first (required by other modules)
        physics_result = _generate_physics_domain(logger, force, dry_run)
        if physics_result != 0:
            return physics_result

        # Generate graph models
        schemas_dir = get_schemas_dir()
        graph_dir = get_graph_dir()

        # Ensure graph directory exists
        graph_dir.mkdir(parents=True, exist_ok=True)

        schema_file = schemas_dir / "facility.yaml"
        common_schema_file = schemas_dir / "common.yaml"
        output_file = graph_dir / "models.py"

        # Validate schema exists
        if not schema_file.exists():
            logger.error(f"Schema file not found: {schema_file}")
            click.echo(f"Error: Schema file not found: {schema_file}", err=True)
            return 1

        # Check if output already exists
        if output_file.exists() and not force:
            # Check if any schema (facility or common) is newer than output
            facility_mtime = schema_file.stat().st_mtime
            common_mtime = (
                common_schema_file.stat().st_mtime if common_schema_file.exists() else 0
            )
            output_mtime = output_file.stat().st_mtime
            if max(facility_mtime, common_mtime) <= output_mtime:
                logger.info(f"Models up to date at {output_file}")
                click.echo(f"Models up to date: {output_file}")
            else:
                logger.info("Schema newer than models, regenerating...")
                force = True  # Force regeneration for this file

        if not output_file.exists() or force:
            logger.info(f"Generating Pydantic models from {schema_file}")

            if not dry_run:
                # Run gen-pydantic
                cmd = ["gen-pydantic", str(schema_file)]

                logger.debug(f"Running command: {' '.join(cmd)}")

                result = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    check=False,
                    encoding="utf-8",
                    errors="replace",
                )

                if result.returncode != 0:
                    logger.error(f"gen-pydantic failed: {result.stderr}")
                    click.echo(
                        f"Error: gen-pydantic failed:\n{result.stderr}", err=True
                    )
                    return 1

                # Add header comment to generated code
                header = '''"""
Facility Knowledge Graph Pydantic Models.

AUTO-GENERATED from imas_codex/schemas/facility.yaml
DO NOT EDIT THIS FILE DIRECTLY - edit the LinkML schema instead.

To regenerate:
    uv run build-models --force
"""

'''
                generated_code = header + result.stdout

                # Write output
                output_file.write_text(generated_code, encoding="utf-8")
                logger.info(f"Generated models written to {output_file}")
                click.echo(f"Generated: {output_file}")
            else:
                click.echo(f"Would generate: {output_file}")

        # Generate IMAS DD models
        imas_schema_file = schemas_dir / "imas_dd.yaml"
        imas_output_file = graph_dir / "dd_models.py"

        # Also check common.yaml which is imported by both facility and imas_dd
        common_schema_file = schemas_dir / "common.yaml"

        if imas_schema_file.exists():
            needs_regen = not imas_output_file.exists() or force
            if imas_output_file.exists() and not force:
                # Check both imas_dd.yaml and common.yaml timestamps
                imas_mtime = imas_schema_file.stat().st_mtime
                common_mtime = (
                    common_schema_file.stat().st_mtime
                    if common_schema_file.exists()
                    else 0
                )
                output_mtime = imas_output_file.stat().st_mtime
                if max(imas_mtime, common_mtime) > output_mtime:
                    needs_regen = True
                    logger.info(
                        "IMAS DD or common schema newer than models, regenerating..."
                    )

            if needs_regen:
                logger.info(f"Generating IMAS DD models from {imas_schema_file}")

                if not dry_run:
                    cmd = ["gen-pydantic", str(imas_schema_file)]

                    logger.debug(f"Running command: {' '.join(cmd)}")

                    result = subprocess.run(
                        cmd,
                        capture_output=True,
                        text=True,
                        check=False,
                        encoding="utf-8",
                        errors="replace",
                    )

                    if result.returncode != 0:
                        logger.error(
                            f"gen-pydantic failed for imas_dd: {result.stderr}"
                        )
                        click.echo(
                            f"Error: gen-pydantic failed:\n{result.stderr}", err=True
                        )
                        return 1

                    header = '''"""
IMAS Data Dictionary Knowledge Graph Pydantic Models.

AUTO-GENERATED from imas_codex/schemas/imas_dd.yaml
DO NOT EDIT THIS FILE DIRECTLY - edit the LinkML schema instead.

To regenerate:
    uv run build-models --force
"""

'''
                    generated_code = header + result.stdout
                    imas_output_file.write_text(generated_code, encoding="utf-8")
                    logger.info(
                        f"Generated IMAS DD models written to {imas_output_file}"
                    )
                    click.echo(f"Generated: {imas_output_file}")
                else:
                    click.echo(f"Would generate: {imas_output_file}")
            else:
                logger.info(f"IMAS DD models up to date at {imas_output_file}")
                click.echo(f"IMAS DD models up to date: {imas_output_file}")
        else:
            logger.debug(f"IMAS DD schema not found: {imas_schema_file}")

        # Generate schema reference for agents
        _generate_schema_reference(logger, force, dry_run)

        # Generate schema context data for schema_for()
        _generate_schema_context(logger, force, dry_run)

        # Generate facility config models
        config_schema_file = schemas_dir / "facility_config.yaml"
        config_module_dir = get_config_module_dir()
        config_output_file = config_module_dir / "models.py"

        if config_schema_file.exists():
            needs_regen = not config_output_file.exists() or force
            if config_output_file.exists() and not force:
                config_mtime = config_schema_file.stat().st_mtime
                output_mtime = config_output_file.stat().st_mtime
                if config_mtime > output_mtime:
                    needs_regen = True
                    logger.info(
                        "Facility config schema newer than models, regenerating..."
                    )

            if needs_regen:
                logger.info(
                    f"Generating facility config models from {config_schema_file}"
                )

                if not dry_run:
                    cmd = ["gen-pydantic", str(config_schema_file)]

                    logger.debug(f"Running command: {' '.join(cmd)}")

                    result = subprocess.run(
                        cmd,
                        capture_output=True,
                        text=True,
                        check=False,
                        encoding="utf-8",
                        errors="replace",
                    )

                    if result.returncode != 0:
                        logger.error(
                            f"gen-pydantic failed for facility_config: {result.stderr}"
                        )
                        click.echo(
                            f"Error: gen-pydantic failed:\n{result.stderr}", err=True
                        )
                        return 1

                    header = '''"""
Facility Configuration Pydantic Models.

AUTO-GENERATED from imas_codex/schemas/facility_config.yaml
DO NOT EDIT THIS FILE DIRECTLY - edit the LinkML schema instead.

To regenerate:
    uv run build-models --force

Usage:
    from imas_codex.config.models import FacilityConfig
    config = FacilityConfig.model_validate(yaml_data)
"""

'''
                    generated_code = header + result.stdout
                    # Post-process: allow extra fields (YAML anchors, forward compat)
                    # Change from "forbid" to "ignore" so unknown keys don't fail
                    generated_code = generated_code.replace(
                        'extra = "forbid"', 'extra = "ignore"'
                    )
                    # Fix types for flexible fields that can be list, dict, or str
                    # These fields have complex union types in the actual configs
                    type_fixes = [
                        (
                            "data_systems: Optional[str]",
                            "data_systems: Optional[list | dict]",
                        ),
                        (
                            "discovery_roots: Optional[str]",
                            "discovery_roots: Optional[list]",
                        ),
                        ("nfs_mounts: Optional[str]", "nfs_mounts: Optional[list]"),
                        ("paths: Optional[str]", "paths: Optional[dict]"),
                        ("svn: Optional[str]", "svn: Optional[dict]"),
                        ("excludes: Optional[str]", "excludes: Optional[dict]"),
                        ("tools: Optional[str]", "tools: Optional[dict]"),
                        ("os_info: Optional[str]", "os_info: Optional[dict]"),
                        ("python_info: Optional[str]", "python_info: Optional[dict]"),
                        ("compilers: Optional[str]", "compilers: Optional[dict]"),
                        ("containers: Optional[str]", "containers: Optional[dict]"),
                        (
                            "compute_locations: Optional[str]",
                            "compute_locations: Optional[dict]",
                        ),
                    ]
                    # Fix class-ranged multivalued fields that gen-pydantic
                    # flattens to list[str] instead of list[ClassName]
                    class_range_fixes = [
                        (
                            "subsystems: Optional[list[str]]",
                            "subsystems: Optional[list[JPFSubsystem | str]]",
                        ),
                    ]
                    for old, new in type_fixes + class_range_fixes:
                        generated_code = generated_code.replace(old, new)
                    config_output_file.write_text(generated_code, encoding="utf-8")
                    logger.info(
                        f"Generated facility config models written to {config_output_file}"
                    )
                    click.echo(f"Generated: {config_output_file}")
                else:
                    click.echo(f"Would generate: {config_output_file}")
            else:
                logger.info(
                    f"Facility config models up to date at {config_output_file}"
                )
                click.echo(f"Facility config models up to date: {config_output_file}")
        else:
            logger.debug(f"Facility config schema not found: {config_schema_file}")

        return 0

    except Exception as e:
        logger.error(f"Error generating models: {e}")
        if verbose:
            logger.exception("Full traceback:")
        click.echo(f"Error: {e}", err=True)
        raise SystemExit(1) from e


if __name__ == "__main__":
    sys.exit(build_models())
