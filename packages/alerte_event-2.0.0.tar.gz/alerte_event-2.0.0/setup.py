from setuptools import setup, find_packages
from pathlib import Path

README = (Path(__file__).parent / "README.md").read_text(encoding="utf-8")

setup(
    name="alerte-event",
    version="2.0.0",
    author="Ton Nom",
    author_email="ton@email.com",
    description="CLI de rappels de notifications via Telegram, Gmail ou Discord",
    long_description=README,
    long_description_content_type="text/markdown",
    url="https://github.com/ton-user/alerte-event",
    packages=find_packages(),
    python_requires=">=3.10",
    install_requires=[
        "click>=8.1",
        "questionary>=2.0",
        "rich>=13.0",
        "requests>=2.31",
    ],
    entry_points={
        "console_scripts": [
            "alerte-event = alerte_sms.cli:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: Microsoft :: Windows",
        "Operating System :: OS Independent",
        "Environment :: Console",
    ],
)
