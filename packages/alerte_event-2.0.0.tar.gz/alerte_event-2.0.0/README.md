# 📱 alerte-sms — Rappels SMS intelligents

> Planifie des rappels SMS pour tes événements. Fonctionne sur Windows, Mac et Linux.

---

## ⚡ Installation en une ligne

### Depuis GitHub (recommandé pour partager avec des amis)
```bash
pip install git+https://github.com/ton-user/alerte-sms.git
```

### Depuis le dossier local (développement)
```bash
pip install .
```

### Depuis un dossier partagé / clé USB
```bash
pip install chemin\vers\alerte-sms\
```

---

## 🚀 Utilisation

Après l'installation, la commande `alerte-event` est disponible partout :

```bash
# Menu interactif (recommandé pour débuter)
alerte-event

# Configurer Twilio (à faire une seule fois)
alerte-event config

# Planifier un événement
alerte-event add

# Voir les événements planifiés
alerte-event list

# Supprimer un événement
alerte-event delete <ID>

# Tester l'envoi SMS
alerte-event test-sms

# Installer le scheduler en tâche de fond Windows
alerte-event install-task
```

---

## ⚙️ Configuration Twilio

1. Crée un compte sur [twilio.com](https://twilio.com) (gratuit)
2. Note ton **Account SID** et **Auth Token** (tableau de bord)
3. Achète un numéro Twilio (~1$/mois) ou utilise le numéro sandbox gratuit
4. Lance `alerte-event config` et entre tes identifiants

Les identifiants sont stockés dans `~/.config/alerte-sms/config.json`.

---

## 🔄 Tâche de fond Windows

Pour que les rappels s'envoient même quand le terminal est fermé :

```bash
# Installer (nécessite des droits Admin)
alerte-event install-task

# Lancer immédiatement
schtasks /Run /TN AlerteSMSScheduler

# Voir le statut
schtasks /Query /TN AlerteSMSScheduler

# Désinstaller
alerte-event remove-task
```

Le log du scheduler est dans `~/.config/alerte-sms/scheduler.log`.

---

## 📁 Données stockées

Tout est dans `~/.config/alerte-sms/` :

```
~/.config/alerte-sms/
├── config.json     ← Identifiants Twilio (chmod 600)
├── events.json     ← Événements planifiés
└── scheduler.log   ← Logs du démon
```

---

## 📦 Dépendances

| Package | Rôle |
|---------|------|
| `click` | Gestion des sous-commandes CLI |
| `questionary` | Interface interactive (menus, saisie) |
| `rich` | Affichage coloré et tableaux |
| `twilio` | API d'envoi de SMS |

---

## 🛠️ Développement

```bash
git clone https://github.com/ton-user/alerte-sms
cd alerte-sms
pip install -e .   # Installation en mode éditable
```
