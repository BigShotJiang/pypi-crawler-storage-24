"""
Envoi de SMS via l'API Twilio.
"""
from twilio.rest import Client
from twilio.base.exceptions import TwilioRestException


def send_sms(account_sid: str, auth_token: str, from_number: str,
             to_number: str, message: str) -> bool:
    """
    Envoie un SMS via Twilio.

    Returns:
        True si l'envoi a réussi, False sinon.
    """
    try:
        client = Client(account_sid, auth_token)
        msg = client.messages.create(
            body=message,
            from_=from_number,
            to=to_number,
        )
        return msg.status not in ("failed", "undelivered")
    except TwilioRestException as e:
        print(f"  ❌ Erreur Twilio ({to_number}): {e.msg}")
        return False
    except Exception as e:
        print(f"  ❌ Erreur inattendue ({to_number}): {e}")
        return False


def send_bulk_sms(account_sid: str, auth_token: str, from_number: str,
                  phone_numbers: list, message: str) -> dict:
    """
    Envoie un SMS à plusieurs destinataires.

    Returns:
        Dictionnaire {numéro: succès_bool}
    """
    results = {}
    for number in phone_numbers:
        results[number] = send_sms(
            account_sid, auth_token, from_number, number, message
        )
    return results
