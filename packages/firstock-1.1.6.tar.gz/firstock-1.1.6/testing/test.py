
from firstock import firstock

login = firstock.login(
    userId="NP2997",
    password="Skanda@2026",
    TOTP="1997",
    vendorCode="NP2997_API",
    apiKey="ccd7498417957016ad08f2af15507727",
  )

print(login)

# result = firstock.optionChainGreeks(
#     exchange="NFO",
#     symbol="NIFTY",
#     expiry="17MAR26",
#     count="10",
#     strikePrice="25500",
#     userId="NP2997"
# )
# print(result)

# result = firstock.modifyAMO(
#     orderNumber="26030400001234",
#     exchange="NSE",
#     tradingSymbol="IDEA-EQ",
#     quantity="50",
#     price="9.10",
#     priceType="LMT",
#     product="C",
#     transactionType="B",
#     retention="DAY",
#     triggerPrice="9.00",
#     userId="NP2997"
# )
# print(result)


# result = firstock.placeAMO(
#     exchange="NSE",
#     tradingSymbol="IDEA-EQ",
#     quantity="1",
#     price="8.90",
#     product="C",
#     transactionType="B",
#     priceType="LMT",
#     retention="DAY",
#     triggerPrice="0",
#     remarks="AMO Order",
#     userId="NP2997"
# )
# print(result)