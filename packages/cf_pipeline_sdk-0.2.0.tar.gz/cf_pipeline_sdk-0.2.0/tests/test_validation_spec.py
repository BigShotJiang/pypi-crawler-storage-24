from __future__ import annotations

import json
from pathlib import Path
import sys

import pytest
from rdflib import Dataset

from cogniflow_pipeline_sdk.validation import generate_validation_spec


REPO_ROOT = Path(__file__).resolve().parents[4]
CF_ONTOLOGY_SRC = REPO_ROOT / "sandcastle" / "cf_ontology" / "src"
if str(CF_ONTOLOGY_SRC) not in sys.path:
    sys.path.insert(0, str(CF_ONTOLOGY_SRC))

from cf_ontology.rdf_document import load_rdf_document_input

CF_NS = "https://cogniflow.odea-project.org/cf#"
XSD_NS = "http://www.w3.org/2001/XMLSchema#"
EX_NS = "http://example.org/"
_STRUCTURED_FORMAT = "json" + "-ld"


def _write_manifest(tmp_path: Path, document: dict) -> Path:
    dataset = Dataset()
    dataset.parse(data=json.dumps(document), format=_STRUCTURED_FORMAT)
    payload = dataset.serialize(format="nquads")
    path = tmp_path / "steps.nq"
    if isinstance(payload, bytes):
        payload = payload.decode("utf-8")
    path.write_text(payload, encoding="utf-8")
    return path


def _convert_manifest_to_nq(tmp_path: Path, source_path: Path) -> Path:
    document, _, _, _ = load_rdf_document_input(source_path, label="step manifest")
    return _write_manifest(tmp_path, document)


def test_generate_validation_spec_includes_value_contract_for_existing_manifest(tmp_path: Path) -> None:
    source_path = (
        REPO_ROOT
        / "sandcastle"
        / "cf_basic_steps"
        / "cf_basic_dev"
        / "src"
        / "cf_basic_dev"
        / "steps.nq"
    )
    manifest_path = _convert_manifest_to_nq(tmp_path, source_path)

    spec = generate_validation_spec(
        [str(manifest_path)],
        only_prefix="https://cogniflow.odea-project.org/cf#basic-dev/",
    )
    step = spec["steps"]["https://cogniflow.odea-project.org/cf#basic-dev/OpcuaPhSource"]
    port = next(
        item
        for item in step["outputs"]
        if item["id"] == "https://cogniflow.odea-project.org/cf#basic-dev/OpcuaPhSource_output_pH"
    )
    parameter = next(
        item
        for item in step["parameters"]
        if item["id"] == "https://cogniflow.odea-project.org/cf#basic-dev/OpcuaPhSource_param_endpoint"
    )

    assert port["types"] == [f"{XSD_NS}double"]
    assert port["value_contract"] == {
        "element_types": [f"{XSD_NS}double"],
        "shape_kind": f"{CF_NS}shape_single",
    }
    assert parameter["type"] == f"{XSD_NS}string"
    assert parameter["value_contract"] == {
        "element_types": [f"{XSD_NS}string"],
        "shape_kind": f"{CF_NS}shape_single",
    }


def test_generate_validation_spec_preserves_legacy_ports_without_value_contract(tmp_path: Path) -> None:
    manifest_path = _write_manifest(
        tmp_path,
        {
            "@context": {
                "cf": CF_NS,
                "ex": EX_NS,
                "xsd": XSD_NS,
            },
            "@graph": [
                {
                    "@id": "ex:LegacyStep",
                    "@type": "cf:ProcessingStep",
                    "cf:hasOutput": {"@id": "ex:legacy_output"},
                },
                {
                    "@id": "ex:legacy_output",
                    "@type": "cf:OutputPort",
                    "cf:portKey": {"@id": "cf:data"},
                    "cf:portName": "legacy",
                    "cf:portType": {"@id": "xsd:double"},
                },
            ],
        },
    )

    spec = generate_validation_spec([str(manifest_path)])
    port = spec["steps"][f"{EX_NS}LegacyStep"]["outputs"][0]

    assert port == {
        "id": f"{EX_NS}legacy_output",
        "key": f"{CF_NS}data",
        "types": [f"{XSD_NS}double"],
        "name": "legacy",
    }


def test_generate_validation_spec_includes_table_schema_when_declared(tmp_path: Path) -> None:
    manifest_path = _write_manifest(
        tmp_path,
        {
            "@context": {
                "cf": CF_NS,
                "ex": EX_NS,
                "xsd": XSD_NS,
            },
            "@graph": [
                {
                    "@id": "ex:TableStep",
                    "@type": "cf:ProcessingStep",
                    "cf:hasInput": {"@id": "ex:table_input"},
                },
                {
                    "@id": "ex:table_input",
                    "@type": "cf:InputPort",
                    "cf:portKey": {"@id": "cf:data"},
                    "cf:portName": "table",
                    "cf:valueContract": {"@id": "ex:table_contract"},
                },
                {
                    "@id": "ex:table_contract",
                    "@type": "cf:ValueContract",
                    "cf:elementType": {"@id": "xsd:double"},
                    "cf:shapeKind": {"@id": "cf:shape_table"},
                    "cf:tableSchema": {"@id": "ex:table_schema_v1"},
                },
                {
                    "@id": "ex:table_schema_v1",
                    "@type": "cf:TableSchema",
                    "cf:hasColumn": [
                        {"@id": "ex:table_column_ts"},
                        {"@id": "ex:table_column_value"},
                    ],
                },
                {
                    "@id": "ex:table_column_ts",
                    "@type": "cf:TableColumnSpec",
                    "cf:columnName": "ts",
                    "cf:columnElementType": {"@id": "xsd:string"},
                    "cf:columnNullable": {"@type": "xsd:boolean", "@value": False},
                },
                {
                    "@id": "ex:table_column_value",
                    "@type": "cf:TableColumnSpec",
                    "cf:columnName": "value",
                    "cf:columnElementType": {"@id": "xsd:double"},
                    "cf:columnNullable": {"@type": "xsd:boolean", "@value": True},
                },
            ],
        },
    )

    spec = generate_validation_spec([str(manifest_path)])
    port = spec["steps"][f"{EX_NS}TableStep"]["inputs"][0]

    assert port["value_contract"] == {
        "element_types": [f"{XSD_NS}double"],
        "shape_kind": f"{CF_NS}shape_table",
        "table_schema": {
            "columns": [
                {"name": "ts", "type": f"{XSD_NS}string", "nullable": False},
                {"name": "value", "type": f"{XSD_NS}double", "nullable": True},
            ]
        },
    }


def test_generate_validation_spec_rejects_port_contract_type_mismatch(tmp_path: Path) -> None:
    manifest_path = _write_manifest(
        tmp_path,
        {
            "@context": {
                "cf": CF_NS,
                "ex": EX_NS,
                "xsd": XSD_NS,
            },
            "@graph": [
                {
                    "@id": "ex:MismatchStep",
                    "@type": "cf:ProcessingStep",
                    "cf:hasOutput": {"@id": "ex:mismatch_output"},
                },
                {
                    "@id": "ex:mismatch_output",
                    "@type": "cf:OutputPort",
                    "cf:portKey": {"@id": "cf:data"},
                    "cf:portName": "mismatch",
                    "cf:portType": {"@id": "xsd:double"},
                    "cf:valueContract": {"@id": "ex:mismatch_contract"},
                },
                {
                    "@id": "ex:mismatch_contract",
                    "@type": "cf:ValueContract",
                    "cf:elementType": {"@id": "xsd:string"},
                    "cf:shapeKind": {"@id": "cf:shape_single"},
                },
            ],
        },
    )

    with pytest.raises(ValueError) as excinfo:
        generate_validation_spec([str(manifest_path)])

    message = str(excinfo.value)
    assert f"{EX_NS}MismatchStep" in message
    assert f"{EX_NS}mismatch_output" in message
    assert "cf:portType" in message
    assert "cf:valueContract/cf:elementType" in message
