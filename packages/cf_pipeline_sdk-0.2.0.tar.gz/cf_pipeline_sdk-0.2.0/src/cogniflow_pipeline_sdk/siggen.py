"""DuckDB-backed signature generator wrapper for step packages."""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Optional

try:
    from cf_ontology.signature import generate_signature_header
except ModuleNotFoundError:  # pragma: no cover - fallback for repo checkouts
    import sys

    here = Path(__file__).resolve()
    fallback = None
    for parent in here.parents:
        candidate = parent / "cf_ontology" / "src"
        if candidate.is_dir():
            fallback = candidate
            break
    if fallback:
        sys.path.insert(0, str(fallback))
    from cf_ontology.signature import generate_signature_header


def _parse_semantics_dir(value: Optional[str]) -> Optional[Path]:
    if not value:
        return None
    return Path(value).expanduser().resolve()


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate step signature header from DuckDB semantics.")
    parser.add_argument("--steps", action="append", required=True, help="Path to step RDF document (.nq, repeatable).")
    parser.add_argument("--out", required=True, help="Output header path.")
    parser.add_argument("--only", default=None, help="Only include step IRIs with this prefix.")
    parser.add_argument("--semantics-dir", default=None, help="Semantics directory override.")
    parser.add_argument(
        "--scratch",
        action="store_true",
        help="Use a temporary semantics directory (avoid writing global DBs).",
    )
    args = parser.parse_args()

    semantics_dir = _parse_semantics_dir(args.semantics_dir)
    documents = [Path(p) for p in args.steps]
    generate_signature_header(
        documents=documents,
        out_path=Path(args.out),
        only_prefix=args.only,
        semantics_dir=semantics_dir,
        scratch=bool(args.scratch),
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
