"""Test fixture loading and validation for the `pw test` command."""

from __future__ import annotations

from contextlib import contextmanager, nullcontext
from contextvars import ContextVar
import json
from datetime import datetime
import os
from pathlib import Path
import re
import socket
from concurrent.futures import ThreadPoolExecutor
import subprocess
import sys
import time
import urllib.error
from typing import Any
import uuid

import yaml

from pollyweb_cli.errors import UserFacingError
from pollyweb_cli.features.bind import (
    get_first_bind_for_domain,
    load_binds,
    serialize_public_key_value,
)
from pollyweb_cli.features.msg import (
    describe_message_network_error,
    parse_message_request,
)
from pollyweb_cli.tools.debug import (
    DEBUG_CONSOLE,
    parse_debug_payload,
)
from pollyweb_cli.tools.transport import send_wallet_message
from pollyweb_cli.tools.transport import rewrite_backend_validation_error


def describe_http_test_error(exc: urllib.error.HTTPError) -> str:
    """Build the user-facing HTTP failure message for `pw test`."""

    message = f"HTTP {exc.code} {exc.reason}."
    error_body = getattr(exc, "pollyweb_error_body", None)

    if not isinstance(error_body, str) or not error_body.strip():
        return message

    try:
        parsed_body = parse_debug_payload(error_body)
    except Exception:
        parsed_body = None

    if isinstance(parsed_body, dict):
        error_value = parsed_body.get("error")
        if isinstance(error_value, str) and error_value.strip():
            return (
                f"{message} "
                f"{rewrite_backend_validation_error(error_value)}"
            )

    return message

PLACEHOLDER_PATTERN = re.compile(r"^\{BindOf\(([^)]+)\)\}$")
PUBLIC_KEY_PLACEHOLDER = "<PublicKey>"
UUID_WILDCARD = "<uuid>"
STRING_WILDCARD = "<str>"
INTEGER_WILDCARD = "<int>"
TIMESTAMP_WILDCARD = "<timestamp>"
DEFAULT_TESTS_DIR = "pw-tests"
PARALLEL_FIXTURE_PREFIX_PATTERN = re.compile(r"^(\d+)-")
ACTIVE_TEST_SPINNER_COUNT: ContextVar[int] = ContextVar(
    "active_test_spinner_count",
    default = 0,
)

# ISO-8601 UTC timestamp ending in Z, matching the pollyweb Zulu timestamp format.
_Z_TIMESTAMP_RE = re.compile(
    r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{3})?Z$"
)


def format_test_success_message(
    fixture_name: str,
    *,
    total_seconds: float,
    network_seconds: float
) -> str:
    """Build the concise success line for one passing test fixture."""

    total_milliseconds = max(0, round(total_seconds * 1000))
    network_share = 0.0

    if total_seconds > 0:
        network_share = (network_seconds / total_seconds) * 100

    return (
        f"✅ Passed: {fixture_name} ({total_milliseconds} ms, "
        f"{network_share:.0f}% latency)"
    )


def format_test_spinner_message(
    fixture_name: str
) -> str:
    """Build the per-fixture spinner label for `pw test` sends."""

    return f"Testing message: {fixture_name}"


def format_test_group_spinner_message(
    group_name: str
) -> str:
    """Build the shared spinner label for one parallel test group."""

    return f"Testing message group: {group_name}"


@contextmanager
def test_spinner_status(
    message: str
):
    """Show one test spinner unless another test spinner is already active."""

    active_spinner_count = ACTIVE_TEST_SPINNER_COUNT.get()
    if active_spinner_count > 0:
        with nullcontext():
            yield
        return

    spinner_token = ACTIVE_TEST_SPINNER_COUNT.set(active_spinner_count + 1)
    try:
        with DEBUG_CONSOLE.status(message):
            yield
    finally:
        ACTIVE_TEST_SPINNER_COUNT.reset(spinner_token)


def get_test_fixture_display_name(
    fixture_path: Path
) -> str:
    """Build the user-facing fixture name for concise test output."""

    current_dir = Path.cwd()
    tests_dir = current_dir / DEFAULT_TESTS_DIR

    try:
        relative_path = fixture_path.relative_to(tests_dir)
    except ValueError:
        relative_path = None

    if relative_path is not None:
        display_path = relative_path
    else:
        try:
            workspace_relative_path = fixture_path.relative_to(current_dir)
        except ValueError:
            display_path = Path(fixture_path.stem)
        else:
            if len(workspace_relative_path.parts) > 1:
                display_path = workspace_relative_path
            else:
                display_path = Path(fixture_path.stem)

    return display_path.with_suffix("").as_posix()


def extract_test_response_total_seconds(
    response_payload: str
) -> float | None:
    """Read the wrapped response total-duration hint from one sync payload."""

    try:
        loaded_payload = json.loads(response_payload)
    except json.JSONDecodeError:
        return None

    if not isinstance(loaded_payload, dict):
        return None

    wrapped_response = loaded_payload.get("Response")
    if not isinstance(wrapped_response, dict):
        return None

    response_metadata = wrapped_response.get("Meta")
    if not isinstance(response_metadata, dict):
        return None

    total_milliseconds = response_metadata.get("TotalMs")
    if isinstance(total_milliseconds, bool) or not isinstance(total_milliseconds, int):
        return None

    if total_milliseconds < 0:
        return None

    return total_milliseconds / 1000


def extract_test_total_seconds(
    response_payload: str,
    *,
    measured_total_seconds: float
) -> float:
    """Choose the best total duration hint for `pw test` success output."""

    total_seconds = measured_total_seconds
    response_total_seconds = extract_test_response_total_seconds(response_payload)
    if response_total_seconds is None:
        return total_seconds

    # Treat the wrapped sync metadata as a timing hint so the concise success
    # line can reflect server-reported end-to-end duration when it is available
    # without undercutting a larger locally measured wall-clock duration.
    return max(total_seconds, response_total_seconds)


def extract_test_latency_seconds(
    response_payload: str,
    *,
    total_seconds: float,
    network_seconds: float
) -> float:
    """Choose the transport-latency share shown in `pw test` success output."""

    response_total_seconds = extract_test_response_total_seconds(response_payload)

    if response_total_seconds is None:
        return network_seconds

    # When the response reports its own end-to-end execution time, treat that
    # server-side total as part of the round trip before calculating the
    # remaining transport share for the concise success line.
    return max(0.0, total_seconds - response_total_seconds)


def resolve_bind_placeholder(
    value: str,
    binds_path: Path
) -> str:
    """Resolve one `{BindOf(domain)}` token from the stored binds file."""

    match = PLACEHOLDER_PATTERN.fullmatch(value.strip())
    if match is None:
        return value

    requested_domain = match.group(1).strip()
    if not requested_domain:
        raise UserFacingError(
            "Bind placeholder must include a non-empty domain."
        ) from None

    bind_value = get_first_bind_for_domain(
        requested_domain,
        load_binds(binds_path))
    if bind_value is None:
        raise UserFacingError(
            f"No bind stored for {requested_domain}. "
            f"Run `pw bind {requested_domain}` first."
        ) from None

    return bind_value


def resolve_public_key_placeholder(
    value: str,
    public_key_path: Path
) -> str:
    """Resolve the `"<PublicKey>"` token from the configured wallet key."""

    if value != PUBLIC_KEY_PLACEHOLDER:
        return value

    try:
        public_key_pem = public_key_path.read_text(encoding = "utf-8")
    except FileNotFoundError:
        raise UserFacingError(
            f"Missing PollyWeb public key in {public_key_path}. "
            "Run `pw config` first."
        ) from None

    return serialize_public_key_value(public_key_pem)


def resolve_fixture_placeholders(
    value: Any,
    *,
    binds_path: Path,
    public_key_path: Path
) -> Any:
    """Recursively replace supported fixture placeholders before sending."""

    if isinstance(value, dict):
        return {
            key: resolve_fixture_placeholders(
                nested_value,
                binds_path = binds_path,
                public_key_path = public_key_path)
            for key, nested_value in value.items()
        }

    if isinstance(value, list):
        return [
            resolve_fixture_placeholders(
                item,
                binds_path = binds_path,
                public_key_path = public_key_path)
            for item in value
        ]

    if isinstance(value, str):
        resolved_value = resolve_bind_placeholder(value, binds_path)
        return resolve_public_key_placeholder(
            resolved_value,
            public_key_path)

    return value


def load_message_test_fixture(
    path: Path,
    binds_path: Path,
    public_key_path: Path
) -> dict[str, Any]:
    """Load and validate a wrapped message test fixture from disk."""

    try:
        loaded = yaml.safe_load(path.read_text(encoding = "utf-8"))
    except FileNotFoundError:
        raise
    except Exception as exc:
        raise UserFacingError(
            f"Could not read test file {path}: {exc}"
        ) from None

    if not isinstance(loaded, dict):
        raise UserFacingError(
            f"Test file {path} must contain a YAML object."
        ) from None

    outbound = loaded.get("Outbound")
    if not isinstance(outbound, dict):
        raise UserFacingError(
            f"Test file {path} must define an `Outbound` object."
        ) from None

    inbound = loaded.get("Inbound")
    if inbound is not None and not isinstance(inbound, dict):
        raise UserFacingError(
            f"Test file {path} must define `Inbound` as an object when present."
        ) from None

    return resolve_fixture_placeholders(
        loaded,
        binds_path = binds_path,
        public_key_path = public_key_path)


def normalize_test_response(
    payload: str,
    source_name: str
) -> dict[str, Any]:
    """Parse the CLI response payload into a mapping used for subset assertions."""

    try:
        loaded = json.loads(payload)
    except json.JSONDecodeError as exc:
        raise UserFacingError(
            f"Response from {source_name} was not valid JSON: {exc.msg}."
        ) from None

    if not isinstance(loaded, dict):
        raise UserFacingError(
            f"Response from {source_name} must be a JSON object."
        ) from None

    # Some proxied domains return a plain JSON body inside the shared
    # `Proxy@Domain` envelope.  In that case, unwrap the nested response so
    # fixtures can assert against the actual service body instead of the
    # transport wrapper.
    if set(loaded.keys()) == {"Request", "Response"}:
        nested_response = loaded.get("Response")
        if (
            isinstance(nested_response, dict)
            and "Header" not in nested_response
            and "Body" not in nested_response
        ):
            loaded = dict(nested_response)

    # Mirror the simpler message-shaped fixtures by surfacing common header
    # values at the top level in addition to the raw Header object.
    header = loaded.get("Header")
    if isinstance(header, dict):
        for key in ("From", "To", "Subject", "Correlation", "Timestamp"):
            if key in header:
                loaded.setdefault(key, header[key])

    return loaded


def extract_test_failure(
    payload: str,
    source_name: str
) -> str | None:
    """Return a user-facing server failure summary when one is present."""

    normalized = normalize_test_response(
        payload,
        source_name)
    candidates: list[dict[str, Any]] = []

    if isinstance(normalized, dict):
        candidates.append(normalized)

        meta = normalized.get("Meta")
        if isinstance(meta, dict):
            candidates.append(meta)

        wrapped_response = normalized.get("Response")
        if isinstance(wrapped_response, dict):
            candidates.append(wrapped_response)

            wrapped_meta = wrapped_response.get("Meta")
            if isinstance(wrapped_meta, dict):
                candidates.append(wrapped_meta)

    for candidate in candidates:
        code = candidate.get("Code")
        if isinstance(code, bool) or not isinstance(code, int):
            continue

        if code < 500:
            continue

        failure_parts = [f"Response returned Code {code}"]
        message = candidate.get("Message")
        if isinstance(message, str) and message.strip():
            failure_parts.append(message.strip())

        details = candidate.get("Details")
        if isinstance(details, list):
            detail_values = [
                str(item).strip()
                for item in details
                if str(item).strip()
            ]
            if detail_values:
                failure_parts.append(f"Details: {' | '.join(detail_values)}")

        return ". ".join(failure_parts)

    return None


def assert_expected_subset(
    actual: Any,
    expected: Any,
    location: str
) -> None:
    """Assert that a response contains the expected fixture subset."""

    def contains_array_template_placeholder(value: Any) -> bool:
        """Return whether a list item includes a repeatable wildcard template."""

        if isinstance(value, dict):
            return any(
                contains_array_template_placeholder(nested_value)
                for nested_value in value.values()
            )

        if isinstance(value, list):
            return any(
                contains_array_template_placeholder(item)
                for item in value
            )

        return value in {
            UUID_WILDCARD,
            STRING_WILDCARD,
            INTEGER_WILDCARD,
        }

    def match_expected_list(
        actual_list: list[Any],
        expected_list: list[Any],
        list_location: str
    ) -> None:
        """Assert that a response list matches fixed items and an optional template."""

        template_items = [
            (index, item)
            for index, item in enumerate(expected_list)
            if contains_array_template_placeholder(item)
        ]
        fixed_items = [
            (index, item)
            for index, item in enumerate(expected_list)
            if not contains_array_template_placeholder(item)
        ]

        if not template_items:
            if len(actual_list) != len(expected_list):
                raise UserFacingError(
                    f"Expected {list_location} to contain {len(expected_list)} items, "
                    f"but got {len(actual_list)}."
                ) from None

            for index, expected_item in enumerate(expected_list):
                try:
                    assert_expected_subset(
                        actual_list[index],
                        expected_item,
                        f"{list_location}[{index}]")
                except UserFacingError as exc:
                    item_found_elsewhere = False

                    for candidate_item in actual_list:
                        try:
                            assert_expected_subset(
                                candidate_item,
                                expected_item,
                                f"{list_location}[{index}]")
                        except UserFacingError:
                            continue

                        item_found_elsewhere = True
                        break

                    if not item_found_elsewhere:
                        raise UserFacingError(
                            f"Expected item {expected_item!r} was not found in {list_location}."
                        ) from None

                    raise exc
            return

        unmatched_actual_indexes = list(range(len(actual_list)))

        for expected_index, expected_item in fixed_items:
            matched_index: int | None = None

            for actual_index in unmatched_actual_indexes:
                try:
                    assert_expected_subset(
                        actual_list[actual_index],
                        expected_item,
                        f"{list_location}[{expected_index}]")
                except UserFacingError:
                    continue

                matched_index = actual_index
                break

            if matched_index is None:
                if not actual_list:
                    raise UserFacingError(
                        f"Expected {list_location}[{expected_index}] to exist in the response."
                    ) from None

                raise UserFacingError(
                    f"Expected item {expected_item!r} was not found in {list_location}."
                ) from None

            unmatched_actual_indexes.remove(matched_index)

        for actual_index in unmatched_actual_indexes:
            template_matched = False

            for expected_index, template_item in template_items:
                try:
                    assert_expected_subset(
                        actual_list[actual_index],
                        template_item,
                        f"{list_location}[{expected_index}]")
                except UserFacingError:
                    continue

                template_matched = True
                break

            if not template_matched:
                assert_expected_subset(
                    actual_list[actual_index],
                    template_items[0][1],
                    f"{list_location}[{template_items[0][0]}]")

    def is_empty_value(value: Any) -> bool:
        """Return whether a fixture value should count as empty."""

        if value in ("", "''", None):
            return True

        if value == {}:
            return True

        return False

    if isinstance(expected, dict):
        if not isinstance(actual, dict):
            raise UserFacingError(
                f"Expected {location} to be an object, but got {actual!r}."
            ) from None

        for key, expected_value in expected.items():
            # Treat empty expected scalar values as optional-presence checks.
            # A fixture can still assert an explicit empty value when the
            # response includes it, but omission is also accepted so callers
            # can express "blank or absent" fields such as Header.Algorithm.
            if key not in actual and is_empty_value(expected_value):
                continue

            if key not in actual:
                raise UserFacingError(
                    f"Expected {location}.{key} to exist in the response."
                ) from None

            assert_expected_subset(
                actual[key],
                expected_value,
                f"{location}.{key}")
        return

    if isinstance(expected, list):
        if not isinstance(actual, list):
            raise UserFacingError(
                f"Expected {location} to be an array, but got {actual!r}."
            ) from None

        match_expected_list(actual, expected, location)
        return

    # Allow fixtures to require "some valid UUID here" without pinning an
    # exact bind or correlation value.
    if expected == UUID_WILDCARD:
        if not isinstance(actual, str):
            raise UserFacingError(
                f"Expected {location} to be a UUID string, but got {actual!r}."
            ) from None

        try:
            uuid.UUID(actual)
        except (AttributeError, TypeError, ValueError):
            raise UserFacingError(
                f"Expected {location} to be a valid UUID, but got {actual!r}."
            ) from None

        return

    # Allow fixtures to require "some non-empty string here" without pinning
    # the exact server-generated value.
    if expected == STRING_WILDCARD:
        if not isinstance(actual, str):
            raise UserFacingError(
                f"Expected {location} to be a string, but got {actual!r}."
            ) from None

        if not actual:
            raise UserFacingError(
                f"Expected {location} to be a non-empty string, but got {actual!r}."
            ) from None

        return

    # Allow fixtures to require "some integer here" without pinning the exact
    # server-generated numeric value.  Exclude booleans because Python treats
    # them as ints, but PollyWeb payloads should distinguish them clearly.
    if expected == INTEGER_WILDCARD:
        if isinstance(actual, bool) or not isinstance(actual, int):
            raise UserFacingError(
                f"Expected {location} to be an integer, but got {actual!r}."
            ) from None

        return

    # Allow fixtures to require "some valid Zulu timestamp here" without
    # pinning the exact server-generated value.  The accepted format mirrors
    # the pollyweb Msg.header.timestamp Zulu format exactly.
    if expected == TIMESTAMP_WILDCARD:
        if not isinstance(actual, str):
            raise UserFacingError(
                f"Expected {location} to be a timestamp string, but got {actual!r}."
            ) from None

        if not _Z_TIMESTAMP_RE.fullmatch(actual):
            raise UserFacingError(
                f"Expected {location} to be a Zulu timestamp "
                f"(e.g. 2024-01-02T03:04:05.678Z), but got {actual!r}."
            ) from None

        try:
            datetime.fromisoformat(actual.replace("Z", "+00:00"))
        except ValueError:
            raise UserFacingError(
                f"Expected {location} to be a valid Zulu timestamp, but got {actual!r}."
            ) from None

        return

    if is_empty_value(expected) and is_empty_value(actual):
        return

    if actual != expected:
        raise UserFacingError(
            f"Expected {location} to equal {expected!r}, but got {actual!r}."
        ) from None


def cmd_test(
    test_path: str | None,
    *,
    debug: bool,
    json_output: bool,
    config_dir: Path,
    binds_path: Path,
    unsigned: bool,
    anonymous: bool,
    require_configured_keys,
    load_signing_key_pair
) -> int:
    """Send one or more wrapped test fixtures and verify expected responses."""

    test_target_path = resolve_test_target_path(test_path)

    for output_line in run_test_target(
        test_target_path,
        debug = debug,
        json_output = json_output,
        config_dir = config_dir,
        binds_path = binds_path,
        unsigned = unsigned,
        anonymous = anonymous,
        require_configured_keys = require_configured_keys,
        load_signing_key_pair = load_signing_key_pair):
        print(output_line)

    return 0


def run_test_target(
    test_target_path: Path,
    *,
    debug: bool,
    json_output: bool,
    config_dir: Path,
    binds_path: Path,
    unsigned: bool,
    anonymous: bool,
    require_configured_keys,
    load_signing_key_pair
) -> list[str]:
    """Run one file or directory test target and return its output lines."""

    if not test_target_path.is_dir():
        fixture_name = get_test_fixture_display_name(test_target_path)
        try:
            return [
                run_message_test_fixture(
                    test_target_path,
                    fixture_name = fixture_name,
                    debug = debug,
                    json_output = json_output,
                    config_dir = config_dir,
                    binds_path = binds_path,
                    unsigned = unsigned,
                    anonymous = anonymous,
                    require_configured_keys = require_configured_keys,
                    load_signing_key_pair = load_signing_key_pair)
            ]
        except Exception:
            print(f"❌ Failed: {fixture_name}")
            raise

    target_runs = collect_test_target_runs(test_target_path)
    output_lines: list[str] = []

    for target_group in group_parallel_test_targets(
        target_runs,
        debug = debug):
        if len(target_group) == 1:
            target_run = target_group[0]
            output_lines.extend(
                run_test_target(
                    target_run["path"],
                    debug = debug,
                    json_output = json_output,
                    config_dir = config_dir,
                    binds_path = binds_path,
                    unsigned = unsigned,
                    anonymous = anonymous,
                    require_configured_keys = require_configured_keys,
                    load_signing_key_pair = load_signing_key_pair)
            )
            continue

        with test_spinner_status(
            format_test_group_spinner_message(
                get_parallel_test_group_name(target_group))
        ):
            with ThreadPoolExecutor(max_workers = len(target_group)) as executor:
                future_results = [
                    (
                        target_run,
                        executor.submit(
                            run_message_test_fixture_subprocess,
                            target_run["path"],
                            target_name = target_run["name"],
                            debug = debug,
                            json_output = json_output,
                            unsigned = unsigned,
                            anonymous = anonymous,
                        ),
                    )
                    for target_run in target_group
                ]

                for target_run, future in future_results:
                    try:
                        output_lines.extend(future.result())
                    except Exception:
                        print(f"❌ Failed: {target_run['name']}")
                        raise

    return output_lines


def run_message_test_fixture_subprocess(
    test_target_path: Path,
    *,
    target_name: str,
    debug: bool,
    json_output: bool,
    unsigned: bool,
    anonymous: bool
) -> list[str]:
    """Run one file or directory target in a child CLI process."""

    command = [
        sys.executable,
        "-c",
        (
            "import sys; "
            "from pollyweb_cli.cli import main_dev; "
            "raise SystemExit(main_dev(sys.argv[1:]))"
        ),
        "test",
        str(test_target_path),
    ]

    if debug:
        command.append("--debug")

    if json_output:
        command.append("--json")

    if unsigned:
        command.append("--unsigned")

    if anonymous:
        command.append("--anonymous")

    child_env = os.environ.copy()
    child_env["POLLYWEB_CLI_SKIP_UPGRADE_CHECK"] = "1"

    completed = subprocess.run(
        command,
        check = False,
        capture_output = True,
        text = True,
        cwd = str(Path.cwd()),
        env = child_env,
    )

    stdout_lines = [
        line
        for line in completed.stdout.splitlines()
        if line.strip()
    ]
    stderr = completed.stderr.strip()

    if completed.returncode != 0:
        if stderr:
            raise UserFacingError(stderr) from None

        raise UserFacingError(
            f"Parallel target {target_name} failed with exit code "
            f"{completed.returncode}."
        ) from None

    if stdout_lines:
        return stdout_lines

    raise UserFacingError(
        f"Parallel target {target_name} completed without output."
    ) from None


def collect_test_target_runs(
    target_dir: Path
) -> list[dict[str, Path | str]]:
    """Collect one directory's immediate runnable test targets."""

    target_runs: list[dict[str, Path | str]] = []

    for child_path in sorted(target_dir.iterdir()):
        if child_path.is_file() and child_path.suffix == ".yaml":
            target_runs.append(
                {
                    "path": child_path,
                    "name": get_test_fixture_display_name(child_path),
                }
            )
            continue

        if child_path.is_dir() and directory_contains_yaml_fixtures(child_path):
            target_runs.append(
                {
                    "path": child_path,
                    "name": get_test_fixture_display_name(child_path),
                }
            )

    if target_runs:
        return target_runs

    raise UserFacingError(
        f"No YAML test fixtures were found in {target_dir}."
    ) from None


def directory_contains_yaml_fixtures(
    target_dir: Path
) -> bool:
    """Return whether one directory contains any YAML fixtures recursively."""

    return any(target_dir.rglob("*.yaml"))


def resolve_test_target_path(
    test_path: str | None
) -> Path:
    """Resolve the explicit or default `pw test` target path."""

    if test_path is not None:
        fixture_path = Path(test_path)
        if fixture_path.exists():
            return fixture_path

        fallback_fixture_path = Path.cwd() / DEFAULT_TESTS_DIR / test_path
        if fallback_fixture_path.is_dir():
            return fallback_fixture_path

        return fixture_path

    tests_dir = Path.cwd() / DEFAULT_TESTS_DIR
    if not tests_dir.exists():
        raise UserFacingError(
            f"No test path was provided and {tests_dir} does not exist."
        ) from None

    if not tests_dir.is_dir():
        raise UserFacingError(
            f"No test path was provided and {tests_dir} is not a directory."
        ) from None

    return tests_dir


def group_parallel_test_targets(
    target_runs: list[dict[str, Path | str]],
    *,
    debug: bool
) -> list[list[dict[str, Path | str]]]:
    """Group sibling test targets that can share one parallel execution wave."""

    if debug:
        return [[target_run] for target_run in target_runs]

    grouped_runs: list[list[dict[str, Path | str]]] = []
    current_group: list[dict[str, Path | str]] = []
    current_parent: Path | None = None
    current_prefix: str | None = None

    for target_run in target_runs:
        target_path = target_run["path"]
        assert isinstance(target_path, Path)
        match = PARALLEL_FIXTURE_PREFIX_PATTERN.match(target_path.name)
        prefix = match.group(1) if match is not None else None

        if prefix is None:
            if current_group:
                grouped_runs.append(current_group)
                current_group = []
                current_parent = None
                current_prefix = None

            grouped_runs.append([target_run])
            continue

        if (
            current_group
            and target_path.parent == current_parent
            and prefix == current_prefix
        ):
            current_group.append(target_run)
            continue

        if current_group:
            grouped_runs.append(current_group)

        current_group = [target_run]
        current_parent = target_path.parent
        current_prefix = prefix

    if current_group:
        grouped_runs.append(current_group)

    return grouped_runs


def get_parallel_test_group_name(
    target_group: list[dict[str, Path | str]]
) -> str:
    """Return the shared user-facing label for one parallel target group."""

    first_target_name = str(target_group[0]["name"])
    first_target_path = Path(first_target_name)
    match = PARALLEL_FIXTURE_PREFIX_PATTERN.match(first_target_path.name)
    if match is None:
        return first_target_name

    grouped_name = Path(f"{match.group(1)}-*")
    if len(first_target_path.parts) > 1:
        grouped_name = Path(*first_target_path.parts[:-1]) / grouped_name

    return grouped_name.as_posix()


def get_test_fixture_paths(
    test_path: str | None
) -> list[Path]:
    """Resolve explicit or default `pw test` fixture paths."""

    test_target_path = resolve_test_target_path(test_path)
    if not test_target_path.is_dir():
        return [test_target_path]

    return sorted(test_target_path.rglob("*.yaml"))


def run_message_test_fixture(
    fixture_path: Path,
    *,
    fixture_name: str,
    debug: bool,
    json_output: bool,
    config_dir: Path,
    binds_path: Path,
    unsigned: bool,
    anonymous: bool,
    require_configured_keys,
    load_signing_key_pair
) -> str:
    """Send one wrapped test fixture and verify its expected inbound response."""

    started_at = time.perf_counter()
    timing: dict[str, float] = {}

    try:
        require_configured_keys()
        key_pair = load_signing_key_pair()
        fixture = load_message_test_fixture(
            fixture_path,
            binds_path,
            config_dir / "public.pem")

        request, _ = parse_message_request(
            [json.dumps(fixture["Outbound"])])

        with test_spinner_status(
            format_test_spinner_message(fixture_name)
        ):
            response_payload, _, _ = send_wallet_message(
                domain = str(request["To"]),
                subject = str(request["Subject"]),
                body = dict(request["Body"]),
                key_pair = key_pair,
                debug = debug,
                debug_json = json_output,
                from_value = request.get("From"),
                schema_value = request.get("Schema"),
                anonymous = anonymous,
                unsigned = unsigned,
                timing = timing,
            )
    except FileNotFoundError:
        if fixture_path.suffix in {".yaml", ".yml", ".json"}:
            raise UserFacingError(
                f"Test file not found: {fixture_path}"
            ) from None
        raise UserFacingError(
            f"Missing PollyWeb keys in {config_dir}. Run `pw config` first."
        ) from None
    except urllib.error.HTTPError as exc:
        raise UserFacingError(
            describe_http_test_error(exc)
        ) from None
    except urllib.error.URLError as exc:
        reason = describe_message_network_error(
            str(request["To"]),
            exc.reason)
        raise UserFacingError(reason) from None
    except OSError as exc:
        reason = describe_message_network_error(
            str(request["To"]),
            exc)
        raise UserFacingError(reason) from None

    actual_response = normalize_test_response(
        response_payload,
        fixture_name)

    failure_message = extract_test_failure(
        response_payload,
        fixture_name)
    if failure_message is not None:
        raise UserFacingError(
            failure_message
        ) from None

    expected_inbound = fixture.get("Inbound")
    if isinstance(expected_inbound, dict):

        assert_expected_subset(
            actual_response,
            expected_inbound,
            "response")

    total_seconds = time.perf_counter() - started_at
    total_seconds = extract_test_total_seconds(
        response_payload,
        measured_total_seconds = total_seconds)
    network_seconds = extract_test_latency_seconds(
        response_payload,
        total_seconds = total_seconds,
        network_seconds = timing.get("network_seconds", 0.0))
    return format_test_success_message(
        fixture_name,
        total_seconds = total_seconds,
        network_seconds = network_seconds)
