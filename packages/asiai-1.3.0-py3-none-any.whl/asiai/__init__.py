"""asiai — Multi-engine LLM benchmark & monitoring CLI for Apple Silicon."""

__version__ = "1.1.1"
