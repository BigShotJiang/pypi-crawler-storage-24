"""CLI display and formatting."""
