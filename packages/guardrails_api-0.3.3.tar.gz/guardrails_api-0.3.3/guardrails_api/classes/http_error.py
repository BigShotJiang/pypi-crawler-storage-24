from typing import Optional


class HttpError(Exception):
    def __init__(
        self,
        status: int,
        message: str,
        cause: Optional[str] = None,
        fields: Optional[dict] = None,
        context: Optional[str] = None,
    ):
        self.status = status
        self.status_code = status
        self.message = message
        self.cause = cause
        self.detail = f"{message} :: {cause}" if cause is not None else message
        self.fields = fields
        self.context = context

    def to_dict(self):
        response = {"status": self.status, "message": self.message}

        if self.cause is not None:
            response["cause"] = self.cause
        if self.fields is not None:
            response["fields"] = self.fields
        if self.context is not None:
            response["context"] = self.context

        return response
