# search-and-destroy

Build files be gone! search-and-destroy is a CLI tool to clean up build files from all types of tech stacks. It’s like a Roomba for your project directory, but instead of dust, it sucks up those pesky `node_modules/`, `build/`, and `*.egg-info/` folders.

## Requirements
- Python 3.8+

> **Caution:** It's strongly recommended to run `sad` with `--dry-run` first and add a `.sadignore` file to protect any files or folders you don't want removed.

## Quick start (developer)

```powershell
# install editable (recommended during development)
pip install -e .

# Run search-and-destroy to remove build files
py sad.py                    # run directly from source

# Examples
py sad.py list                # show project and build targets (no deletion)
py sad.py list node           # show only node targets
py sad.py --dry-run nuke node # find node targets recursively (dry-run)
py sad.py --all --yes node    # remove node project + build targets without prompting
py sad.py --dry-run python    # find python targets recursively (dry-run)
py sad.py --dry-run dotnet    # find dotnet targets recursively (dry-run)

# Automatic confirmation (skip prompts)
py sad.py --yes node
```

If the `sad` command is not found after installation, the installer likely wrote scripts to your user Scripts directory. On Windows add this to your PATH (PowerShell):

```powershell
$env:Path += ";$env:APPDATA\Python\Python<version>\Scripts"
# or permanently via System settings: add %APPDATA%\Python\Python<version>\Scripts to your user PATH
```

You can always run the CLI directly without installing:

```powershell
python -m sad
```

### Commands
- `list [type]` — Show project and build artifact names that would be removed for `type` (default: all).
- `nuke [type1 type2 ...]` — Recursively find and remove matching targets for the named project types (default: all). Use `--dry-run` to preview.
- `node`, `python`, `dotnet` etc. — Run the cleaner for a single project type.

Options (common): `--dry-run`, `--yes`, `--all`, `--force`, `--safe`.

Aliases available: `sad`, `search-and-destroy` (when installed as a console script)

### Packaging & publishing (brief)
- Remember to add a `MANIFEST.in` if you need additional files in source distributions.
- Update `setup.cfg` version.
- Update `PYPI_README.md` Changelog for new version.
- Build: `py -m build` (requires `build` package).
- Upload: `twine upload dist/*` (requires `twine`).
- The package exposes several console script aliases (see `setup.cfg` -> `options.entry_points.console_scripts`).

### Notes & Troubleshooting
- No platform-specific terminal dependencies are required.

### Ignoring paths with .sadignore

Create a file named `.sadignore` at the repository root to prevent `sad` from listing or removing matching paths. When the optional `pathspec` package is installed, `.sadignore` uses gitignore-style matching (recommended). Without `pathspec`, a fallback glob-and-negation matcher is used.

Patterns examples:

- Ignore any directory named `ignorethis` anywhere:

	ignorethis/
	somedir/ignorethis

- Ignore a specific file:

  node_modules
  package-lock.json

- Anchor to repo root (gitwildmatch via `pathspec`):

	/ignorethis/

- Allow a subfolder inside an ignored directory:

	ignorethis/
	!ignorethis/keep/

Use `py sad.py --dry-run` to preview removals; `.sadignore` entries are applied to the preview and actual deletes.

## Contributing
- Keep changes minimal and run `sad` locally to verify.

## License
- MIT

# Changelog
- See PYPI_README.md
