import unittest
import os
import yaml
from pywebwizard.core import PyWebWizard

class TestConfig(unittest.TestCase):
    def setUp(self):
        self.config_content = """
config:
  - browser: chrome
  - hidden: true
start:
  - action: navigate
    url: https://google.com
        """
        self.test_file = "test_spell.yaml"
        with open(self.test_file, 'w') as f:
            f.write(self.config_content)

    def tearDown(self):
        if os.path.exists(self.test_file):
            os.remove(self.test_file)

    def test_load_spell(self):
        # We don't want to start the driver for this test
        # So we mock things if necessary, but here we just check if it loads correctly
        from pywebwizard.utils.exceptions import BrowserError
        try:
            wizard = PyWebWizard(spell_file=self.test_file, destruct_on_finish=True)
        except Exception:
            # We expect it to fail if Chrome is not installed, but it should load the actions first
            pass

if __name__ == '__main__':
    unittest.main()
