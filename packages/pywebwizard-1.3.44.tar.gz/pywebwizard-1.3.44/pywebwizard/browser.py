import os
import time
import logging
import subprocess
from selenium import webdriver
import undetected_chromedriver as uc
from .utils.config import BROWSER_OPTIONS
from .utils.exceptions import BrowserError

class BrowserManager:
    """
    Handles browser driver initialization and setup.
    """
    
    @staticmethod
    def setup_driver(config, undetectable=False):
        """
        Sets up the browser driver based on the configuration settings.
        """
        _selected_browser = config.get('browser', 'chrome')
        if _selected_browser not in BROWSER_OPTIONS:
            logging.error(f"[DRIVER] Browser not supported: {_selected_browser}")
            raise BrowserError(f"Browser not supported: {_selected_browser}")

        _browser_options = BROWSER_OPTIONS.get(_selected_browser)
        _undetection_available = _browser_options.get('undetectable', False)
        _exec_path = _browser_options.get('exec_path')
        
        # Tor Global Configuration
        _use_tor = config.get('tor', False) or _selected_browser == 'tor'
        _tor_proxy = BROWSER_OPTIONS.get('tor', {}).get('proxy', {'socks': '127.0.0.1', 'port': 9050})
        
        if _use_tor:
            _tor_service_path = BROWSER_OPTIONS.get('tor', {}).get('service_path')
            if _tor_service_path and os.path.isfile(_tor_service_path):
                try:
                    # Iniciamos el proceso de tor en segundo plano si existe
                    subprocess.Popen([_tor_service_path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    logging.info("[TOR] Tor service started")
                    time.sleep(2) # Esperamos a que inicie
                except Exception as e:
                    logging.warning(f"[TOR] Error starting Tor service: {str(e)}")

        if undetectable and _undetection_available:
            options = uc.ChromeOptions()
            options.add_argument('--no-sandbox')
            options.add_argument('--disable-blink-features=AutomationControlled')
            options.add_argument('--disable-dev-shm-usage')
            options.add_argument('--disable-infobars')
            options.add_argument('--disable-speech-api')
            options.add_argument('--disable-features=VoiceInteraction')
            options.add_argument('--disable-background-networking')
            options.add_argument('--disable-default-apps')
            options.add_argument('--disable-extensions')
            
            if config.get("hidden", False):
                options.add_argument('--headless')
            
            if _use_tor:
                options.add_argument(f'--proxy-server=socks5://{_tor_proxy.get("socks")}:{_tor_proxy.get("port")}')
                logging.info(f"[TOR] Routing through Tor proxy: {_tor_proxy.get('socks')}:{_tor_proxy.get('port')}")

            if _exec_path and os.path.isfile(_exec_path):
                options.binary_location = _exec_path
            
            logging.info("[DRIVER] Starting in undetectable mode")
            try:
                # Force version 145 to match system's Chromium/Brave version
                return uc.Chrome(options=options, version_main=145)
            except Exception as e:
                logging.warning(f"[DRIVER] Error with version_main=145: {e}. Trying default...")
                return uc.Chrome(options=options)
            
        else:
            _webdriver = _browser_options.get('webdriver')
            _options = _browser_options.get('options')()
            _options.add_argument('--no-sandbox')
            
            if _webdriver == webdriver.Chrome:
                _options.add_argument('--disable-speech-api')
                _options.add_argument('--disable-features=VoiceInteraction')
                _options.add_argument('--disable-background-networking')
                _options.add_argument('--disable-default-apps')
                try:
                    _options.add_experimental_option('excludeSwitches', ['enable-logging'])
                except:
                    pass
                
                if _use_tor:
                    _options.add_argument(f'--proxy-server=socks5://{_tor_proxy.get("socks")}:{_tor_proxy.get("port")}')

            if config.get("hidden", False):
                _options.add_argument("--headless")
            
            if _exec_path and os.path.isfile(_exec_path):
                _options.binary_location = _exec_path

            _proxy = _browser_options.get('proxy', {}) if not _use_tor else _tor_proxy
            
            if _proxy and _webdriver == webdriver.Firefox:
                from selenium.webdriver.common.proxy import Proxy, ProxyType
                proxy = Proxy()
                proxy.proxy_type = ProxyType.MANUAL
                proxy.socks_proxy = f"{_proxy.get('socks')}:{_proxy.get('port')}"
                proxy.socks_version = 5
                _options.proxy = proxy
                logging.info(f"[PROXY] Routing through: {_proxy.get('socks')}:{_proxy.get('port')}")
            
            logging.info(f"[DRIVER] Starting {_selected_browser} in detectable mode")
            return _webdriver(options=_options)
