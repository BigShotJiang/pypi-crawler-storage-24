class DotDict(dict):
    def __getattr__(self, name):
        value = self.get(name)
        if isinstance(value, dict):
            return DotDict(value)
        elif isinstance(value, list):
            return [DotDict(v) if isinstance(v, dict) else v for v in value]
        return value

    def __setattr__(self, name, value):
        self[name] = value

    def __getitem__(self, key):
        value = super().__getitem__(key)
        if isinstance(value, dict):
            return DotDict(value)
        elif isinstance(value, list):
            return [DotDict(v) if isinstance(v, dict) else v for v in value]
        return value
