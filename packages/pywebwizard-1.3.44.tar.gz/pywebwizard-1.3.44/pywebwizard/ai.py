import logging
import time
from .utils.logger import logging as log_util
from .utils.exceptions import ActionError

class AIHandler:
    """
    Handles AI-powered automation logic.
    """
    
    def __init__(self, ai_controller):
        self.ai = ai_controller

    def invoke_ai(self, context, task_description, max_cycles=50, per_action_retries=2):
        """
        Executes a task description using the AI controller.
        """
        action_history = []
        error_history = []
        results = []
        ai_message = None
        cycle = 1
        consecutive_failures = 0
        max_consecutive_failures = 3

        while cycle <= max_cycles:
            logging.info(f"[AGENT] === Reasoning Cycle {cycle}/{max_cycles} ===")

            if not context._is_driver_alive():
                logging.warning("[AGENT] Driver not alive. Attempting reinitialization...")
                try:
                    context._driver_setup()
                    consecutive_failures = 0
                except Exception as e:
                    consecutive_failures += 1
                    logging.error(f"[AGENT] Driver reinitialization failed: {str(e)}")
                    if consecutive_failures >= max_consecutive_failures:
                        cycle += 1
                        consecutive_failures = 0
                    continue

            try:
                html_content = context._html({'action': 'html', 'response': 'page_html'})
                current_page_info = context._prepare_page_info(html_content)
                logging.info(f"[AGENT] Page info prepared: {len(str(current_page_info))} characters")
            except Exception as e:
                consecutive_failures += 1
                logging.error(f"[AGENT] Could not retrieve page info: {str(e)}")
                if consecutive_failures >= max_consecutive_failures:
                    cycle += 1
                    consecutive_failures = 0
                continue

            try:
                actions, ai_message = self.ai.analyze_task(
                    task_description=task_description,
                    current_page_info=current_page_info,
                    action_history=action_history,
                    error_history=error_history
                )
            except Exception as e:
                consecutive_failures += 1
                logging.error(f"[AGENT] AI analysis failed: {str(e)}")
                if consecutive_failures >= max_consecutive_failures:
                    cycle += 1
                    consecutive_failures = 0
                continue

            if not actions:
                logging.info("[AGENT] No further actions returned. Task complete.")
                if ai_message:
                    results.append({"action": "summary", "message": ai_message})
                return results, ai_message

            action_success = False
            for i, action in enumerate(actions, 1):
                if isinstance(action, str):
                    action = {'action': action}
                
                if action.get("action") in ["stop", "summary"]:
                    ai_message = action.get("reason") or action.get("message")
                    logging.info(f"[AGENT] AI requested {action.get('action')}. Message: {ai_message}")
                    if ai_message:
                        results.append({"action": "summary", "message": ai_message})
                    return results, ai_message

                for sub_attempt in range(1, per_action_retries + 1):
                    try:
                        logging.info(f"[AGENT] Executing action {i}/{len(actions)}: {action.get('action')} (Try {sub_attempt})")
                        res = context._execute_action(action)
                        action_history.append(action)
                        _action_result = action.copy()
                        _action_result['result'] = res
                        results.append(_action_result)
                        action_success = True
                        break
                    except Exception as e:
                        error_history.append(f"Action failed: {str(e)}")
                        if sub_attempt == per_action_retries:
                            consecutive_failures += 1
                            logging.error(f"[AGENT] Action failed after {per_action_retries} attempts")
                            break
            
            if action_success:
                cycle += 1
        
        return results, ai_message
