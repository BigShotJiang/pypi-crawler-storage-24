import time
from selenium.webdriver.common.by import By
from .utils.logger import logging

class CloudflareBypasser:
    def __init__(self, driver, max_retries=-1, log=True):
        self.driver = driver
        self.max_retries = max_retries
        self.log = log

    def _search_shadow_root_with_iframe(self, element):
        try:
            shadow_root = self.driver.execute_script("return arguments[0].shadowRoot", element)
            if shadow_root:
                iframe = shadow_root.find_element(By.TAG_NAME, "iframe")
                if iframe:
                    return iframe
            for child in element.find_elements(By.XPATH, "./*"):
                result = self._search_shadow_root_with_iframe(child)
                if result:
                    return result
        except:
            return None

    def _search_shadow_root_for_input(self, element):
        try:
            shadow_root = self.driver.execute_script("return arguments[0].shadowRoot", element)
            if shadow_root:
                input_element = shadow_root.find_element(By.TAG_NAME, "input")
                if input_element:
                    return input_element
            for child in element.find_elements(By.XPATH, "./*"):
                result = self._search_shadow_root_for_input(child)
                if result:
                    return result
        except:
            return None

    def locate_cf_button(self):
        try:
            # Buscar en iframes primero
            iframes = self.driver.find_elements(By.TAG_NAME, "iframe")
            for iframe in iframes:
                self.driver.switch_to.frame(iframe)
                body = self.driver.find_element(By.TAG_NAME, "body")
                button = self._search_shadow_root_for_input(body)
                if button:
                    return button
                self.driver.switch_to.default_content()

            # Buscar recursivamente en shadow roots
            body = self.driver.find_element(By.TAG_NAME, "body")
            iframe = self._search_shadow_root_with_iframe(body)
            if iframe:
                self.driver.switch_to.frame(iframe)
                button = self._search_shadow_root_for_input(
                    self.driver.find_element(By.TAG_NAME, "body")
                )
                self.driver.switch_to.default_content()
                return button
        except Exception as e:
            if self.log:
                logging.error(f"[CLOUDFLARE] Error locating button: {str(e)}")
        return None

    def is_challenge_present(self):
        try:
            return "just a moment" in self.driver.title.lower()
        except:
            return False

    def bypass(self):
        try_count = 0
        while self.is_challenge_present() and (self.max_retries < 0 or try_count < self.max_retries):
            try:
                button = self.locate_cf_button()
                if button:
                    button.click()
                    time.sleep(2)
                    if not self.is_challenge_present():
                        logging.info("[CLOUDFLARE] Bypass exitoso")
                        return True
                try_count += 1
            except Exception as e:
                logging.error(f"[CLOUDFLARE] Error en bypass: {str(e)}")
                time.sleep(2)
        return False
