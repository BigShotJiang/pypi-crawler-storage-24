import time
import json
import os
import base64
import requests
import pyotp
from copy import deepcopy
from selenium.common.exceptions import NoSuchElementException, WebDriverException, TimeoutException, \
    ElementNotInteractableException, ElementClickInterceptedException, StaleElementReferenceException
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait

from .utils.config import INTERFACES, DEFAULT_TIMEOUT, KEYBOARD
from .utils.functions import is_valid_url, action_name, required_fields
from .utils.logger import logging
from .utils.parsers import simplify_html
from .utils.exceptions import InterfaceError, LoopError, AttachError, NavigateError, ScreenshotError, ScrollError, ActionError

class ActionsMixin:
    """
    Mixin class containing all the action implementations for PyWebWizard.
    """

    @action_name('loop')
    @required_fields(['do'])
    def _loop(self, action: dict):
        if not any(action.get(_mode) for _mode in ['times', 'source', 'raw']):
            raise LoopError("Times, source or raw have to be defined in 'loop' action")
        
        if _do_times := action.get('times'):
            for _ in range(int(_do_times)):
                for _action in action.get('do', []):
                    self._execute_action(_action)
            return
            
        if action.get('source') and is_valid_url(action.get('source')):
            return self._loop_web_file(action)
        return self._loop_file(action)

    @action_name('wait')
    @required_fields(['interface', 'query'])
    def _wait_exists(self, action: dict):
        _interface, _query, _timeout, _index, _, _log = self._parse_action(action)
        self._log_action(action, _log)
        self._wait(_interface, _query, _index, _timeout)

    @action_name('click')
    @required_fields(['interface', 'query'])
    def _click(self, action: dict):
        _interface, _query, _timeout, _index, _, _log = self._parse_action(action)
        self._log_action(action, _log)
        _element = self._wait(_interface, _query, _index, _timeout)

        try:
            _element.click()
            return
        except (ElementClickInterceptedException, StaleElementReferenceException, ElementNotInteractableException):
            pass

        try:
            self.driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", _element)
            time.sleep(0.5)
            actions = ActionChains(self.driver)
            actions.move_to_element(_element).click().perform()
            return
        except Exception:
            pass

        try:
            self.driver.execute_script("arguments[0].click();", _element)
            return
        except Exception:
            pass
        
        raise ActionError(f"Could not click element: {_log}")

    @action_name('fill')
    @required_fields(['interface', 'query', 'content'])
    def _fill(self, action: dict):
        _interface, _query, _timeout, _index, _content, _log = self._parse_action(action)
        _field = self._wait(_interface, _query, _index, _timeout)
        self._log_action(action, _log)

        if _field.is_displayed() and _field.is_enabled():
            _field.send_keys(_content)
        else:
            raise ElementNotInteractableException(f"Element {_interface}='{_query}' is not interactable")

    @action_name('attach')
    @required_fields(['interface', 'query', 'file_path'])
    def _attach_file(self, action: dict):
        _file_path = action.get('file_path')
        if not _file_path:
            raise AttachError("Attach file needs a file path")
        _interface, _query, _timeout, _index, _, _log = self._parse_action(action)
        _field = self._wait(_interface, _query, _index, _timeout)
        self._log_action(action, _log)
        _field.send_keys(_file_path)

    @action_name('navigate')
    @required_fields(['url'])
    def _navigate(self, action: dict):
        _url = action.get('url')
        if not _url.startswith("https://") and not _url.startswith("http://"):
            raise NavigateError(f"{_url} needs to be http/s format")
        self._log_action(action, _url)
        if hasattr(self, 'cloudflare_enabled') and self.cloudflare_enabled:
            self._navigate_with_cf_bypass(_url)
        else:
            self.driver.get(_url)

    @action_name('sleep')
    @required_fields(['time'])
    def _sleep(self, action: dict):
        self._log_action(action, f"{action.get('time')} seconds")
        time.sleep(int(action.get('time')))

    @action_name('screenshot')
    @required_fields(['file_name'])
    def _screenshot(self, action: dict):
        _base_name = action.get('file_name')
        _timestamp = int(time.time())
        _file_name = f"{_base_name}_{_timestamp}.png"
        _photo_name = os.path.join(self.screenshots_dir, _file_name)
        
        if _styles := action.get('css'):
            for _element in _styles:
                if not _element.get('style'):
                    raise ScreenshotError("Style not defined in 'screenshot' css defined element")

                _element_instance = self._wait(_element.get('interface'), _element.get('query'))
                self.driver.execute_script("arguments[0].setAttribute('style', arguments[1]);", _element_instance,
                                 _element.get('style'))
            time.sleep(.2)
            
        self._log_action(action, _photo_name)
        self.driver.save_screenshot(_photo_name)
        with open(_photo_name, 'rb') as _photo:
            return base64.b64encode(_photo.read()).decode('utf-8')

    @action_name('scroll')
    @required_fields([])
    def _scroll(self, action: dict):
        _movement = (action.get('x'), action.get('y'))
        if all([m is None for m in _movement]):
            raise ScrollError("X or Y need to be defined in 'scroll' action")
        
        x = _movement[0] if _movement[0] is not None else 0
        y = _movement[1] if _movement[1] is not None else 0
        
        self._log_action(action, f"({x}, {y})")
        self.driver.execute_script(f"window.scrollBy({x}, {y});")

    @action_name('drag_drop')
    @required_fields(['drag', 'drop'])
    def _drag_drop(self, action: dict):
        _interface_drag, _query_drag, _timeout_drag, _index_drag, _, _log_drag = self._parse_action(action.get('drag'))
        _interface_drop, _query_drop, _timeout_drop, _index_drop, _, _log_drop = self._parse_action(action.get('drop'))
        
        _drag_element = self._wait(_interface_drag, _query_drag, _index_drag, _timeout_drag)
        _drop_on_element = self._wait(_interface_drop, _query_drop, _index_drop, _timeout_drop)
        
        self._log_action(action, f"{_log_drag} => {_log_drop}")
        _actions = ActionChains(self.driver)
        _actions.drag_and_drop(_drag_element, _drop_on_element).perform()

    @action_name('execute')
    @required_fields(['js'])
    def _execute_js_action(self, action: dict):
        if _js_action := action.get('js'):
            self._log_action(action, f"{_js_action}")
            return self.driver.execute_script(_js_action)

    @action_name('inspect')
    @required_fields([])
    def _inspect(self, action: dict):
        """
        Deeply inspect the page, including all iframes and shadow DOMs.
        Returns a structured list of interactive elements found.
        """
        self._log_action(action, "Deep inspection started...")
        _discovery_js = """
        function getInteractiveElements(root = document, path = []) {
            let elements = [];
            
            // Current root elements
            const selector = 'input, button, a, [role="button"], [onclick], select, textarea';
            const localElements = Array.from(root.querySelectorAll(selector)).map(el => {
                const rect = el.getBoundingClientRect();
                return {
                    tag: el.tagName.toLowerCase(),
                    id: el.id,
                    name: el.name || el.getAttribute('name'),
                    placeholder: el.placeholder || el.getAttribute('placeholder'),
                    text: el.innerText || el.textContent,
                    type: el.type || el.getAttribute('type'),
                    value: el.value,
                    path: path.join(' -> '),
                    visible: rect.width > 0 && rect.height > 0,
                    xpath: getXPath(el)
                };
            });
            elements.push(...localElements);

            // Shadow DOMs
            const allElements = root.querySelectorAll('*');
            for (const el of allElements) {
                if (el.shadowRoot) {
                    elements.push(...getInteractiveElements(el.shadowRoot, [...path, `ShadowRoot(${el.tagName})`]));
                }
            }

            // Iframes (Wait, JS cannot easily traverse cross-origin iframes, 
            // but we can list them to know they are there)
            if (root === document) {
                const frames = document.querySelectorAll('iframe, frame');
                frames.forEach((f, i) => {
                    elements.push({
                        tag: 'iframe',
                        id: f.id,
                        src: f.src,
                        path: path.join(' -> '),
                        type: 'frame_container'
                    });
                });
            }

            return elements;
        }

        function getXPath(element) {
            if (element.id !== '') return 'id("' + element.id + '")';
            if (element === document.body) return element.tagName;
            var ix = 0;
            var siblings = element.parentNode.childNodes;
            for (var i = 0; i < siblings.length; i++) {
                var sibling = siblings[i];
                if (sibling === element) return getXPath(element.parentNode) + '/' + element.tagName + '[' + (ix + 1) + ']';
                if (sibling.nodeType === 1 && sibling.tagName === element.tagName) ix++;
            }
        }

        return getInteractiveElements();
        """
        
        # We run it in the main frame. 
        # For cross-origin frames, we would need to switch manually in Python.
        # This will be handled by the orquestrator/core logic using this output.
        result = self.driver.execute_script(_discovery_js)
        
        if action.get('debug'):
            logging.info(f"[INSPECT] Found {len(result)} elements.")
            for el in result:
                 if el.get('visible') or el.get('tag') == 'iframe':
                    tag = el.get('tag', 'unknown')
                    el_id = el.get('id', 'None')
                    name = el.get('name', 'None')
                    text = el.get('text', '')[:30]
                    logging.info(f" - {tag}#{el_id} ({name}): {text}")
        
        return result

    @action_name('submit')
    @required_fields(['interface', 'query'])
    def _submit(self, action: dict):
        _interface, _query, _timeout, _index, _, _log = self._parse_action(action)
        self._log_action(action, f"{_log}")
        _form = self._wait(_interface, _query, _index, _timeout)
        _form.submit()

    @action_name('keyboard')
    @required_fields(['keys'])
    def _keyboard(self, action: dict):
        _interface, _query, _timeout, _index, _, _log = self._parse_action(action)
        _keys = action.get('keys', [])
        
        if not _keys:
            raise ValueError("The 'keys' field is required for keyboard actions.")

        self._log_action(action, f"{_log}")
        
        _processed_keys = self._process_keys(_keys)
        action_chain = ActionChains(self.driver)
        
        _do_times = int(action.get('times', 1))
        for _ in range(_do_times):
            logging.info(f"[KEYBOARD] {' + '.join([_k.capitalize() for _k in _keys])}")
            for key in _processed_keys:
                action_chain.key_down(key)
            for key in reversed(_processed_keys):
                action_chain.key_up(key)
            action_chain.perform()

    @action_name('write')
    @required_fields(['text'])
    def _write(self, action: dict):
        _interface, _query, _timeout, _index, _, _log = self._parse_action(action)
        _text = action.get('text', None)
        self._log_action(action, f"{_log}")

        _do_times = int(action.get('times', 1))
        for _ in range(_do_times):
            logging.info(f"[WRITE] {_text}")
            self.driver.switch_to.active_element.send_keys(_text)

    @action_name('type')
    @required_fields(['text'])
    def _type(self, action: dict):
        _interface, _query, _timeout, _index, _, _log = self._parse_action(action)
        _text = action.get('text', '')
        _delay = float(action.get('delay', 0.1))
        
        if _interface and _query:
            _field = self._wait(_interface, _query, _index, _timeout)
            self._log_action(action, f"Typing '{_text}' in {_log}")
            _field.click() # Ensure focus
        else:
            self._log_action(action, f"Typing '{_text}' in active element")
            _field = self.driver.switch_to.active_element

        for char in _text:
            _field.send_keys(char)
            time.sleep(_delay)

    @action_name('external')
    @required_fields(['function'])
    def _external_function(self, action: dict):
        _function_mapping_name = action.get('function')
        _function_args = action.get('args', {})
        _function_response_variable = action.get('response', [])

        if hasattr(self, 'external_functions_mapping') and self.external_functions_mapping:
            if _mapped_function := self.external_functions_mapping.get(_function_mapping_name):
                self._log_action(action, f"{_function_mapping_name}({_function_args})")
                _result = _mapped_function(**_function_args)

                if _function_response_variable:
                    with self._env_lock:
                        self.environment[_function_response_variable[0].strip()] = _result
                return _result

        logging.warning(f"[EXTERNAL] {_function_mapping_name} not defined in external_functions_mapping")

    @action_name('request')
    @required_fields(['method', 'url'])
    def _request(self, action: dict):
        _url = action.get('url')
        _method = action.get('method', 'get').lower()
        _json_data = json.loads(action.get('json', '{}'))
        _data = action.get('data')
        _params = json.loads(action.get('params', '{}'))
        _headers = json.loads(action.get('headers', '{}'))
        _auth_raw = action.get('auth')
        _timeout = action.get('timeout', DEFAULT_TIMEOUT)
        _debug = action.get('debug', False)
        _function_response_variable = action.get('response', [])
        _auth = tuple(_auth_raw.split(':', 1)) if _auth_raw and ':' in _auth_raw else None

        self._log_action(action, f"{_method.upper()} {_url}")
        
        _response = getattr(requests, _method)(
            _url,
            params=_params,
            json=_json_data,
            data=_data,
            headers=_headers,
            auth=_auth,
            timeout=_timeout,
        )

        if _response.status_code >= 400:
            result = _response.content.decode()
        else:
            try:
                result = _response.json()
            except Exception:
                result = _response.text

        for _new_var in _function_response_variable:
            with self._env_lock:
                self.environment[_new_var.strip()] = result

        if _debug:
            logging.info(f"[REQUEST] Result: {result}")
        return result

    @action_name('totp')
    @required_fields(['private_key'])
    def _totp(self, action: dict):
        _private_key = action.get('private_key')
        _response_variable = action.get('response')
        _response = str(pyotp.TOTP(_private_key).now())
        
        if _response_variable:
            with self._env_lock:
                self.environment[_response_variable.strip()] = _response
        return _response

    @action_name('html')
    @required_fields([])
    def _html(self, action: dict):
        _response_variable = action.get('response')
        _debug = action.get('debug', False)
        _simplified = action.get('simplified', True)
    
        html_source = self.driver.page_source
        if _simplified:
            html_source = simplify_html(html_source)
        
        self._log_action(action, f"HTML source retrieved ({len(html_source)} characters)")
        
        if _response_variable:
            with self._env_lock:
                self.environment[_response_variable.strip()] = html_source
            
        if _debug:
            preview = html_source[:500] + "..." if len(html_source) > 500 else html_source
            logging.info(f"[HTML] Preview: {preview}")
            
        return html_source

    # --- Helper methods ---

    def _parse_action(self, action: dict):
        _interface = action.get('interface')
        _query = action.get('query', '').replace('\n', '').strip()
        _timeout = action.get('timeout', DEFAULT_TIMEOUT)
        _index = action.get('index')
        if _index and _index < 1:
            _index = 1
        _content = action.get('content')
        _log = f"@body"
        if _interface and _query:
            _log = f"@{_interface}[query={_query}]{'' if not _index else '[' + str(_index) + ']'}"
        return _interface, _query, _timeout, _index, _content, _log

    def _is_valid_interface(self, interface: str):
        if interface not in INTERFACES:
            raise InterfaceError(f"Interface '{interface}' not supported")
        return INTERFACES.get(interface)

    def _process_keys(self, keys_list: list) -> list:
        keys_res = []
        for key in keys_list:
            _processed_key = KEYBOARD.get(key.lower())
            if _processed_key is None and len(key) == 1:
                _processed_key = key
            elif _processed_key is None:
                raise ValueError(f"Special key '{key}' not found in KEYBOARD configuration.")
            keys_res.append(_processed_key)
        return keys_res

    def _loop_file(self, action: dict):
        _do_source = action.get('source')
        _raw = action.get('raw')
        
        if _raw:
            try:
                _file_values = eval(_raw) if isinstance(_raw, str) else _raw
            except Exception:
                _file_values = _raw
        elif _do_source:
             if not os.path.isfile(_do_source):
                raise FileNotFoundError(f"File not found {_do_source}")
             _file_values = json.load(open(_do_source, 'r', encoding='utf-8'))
        else:
            raise ValueError("Loop action requires 'source', 'times' or 'raw'")

        self._do_file_actions(action, _file_values)

    def _loop_web_file(self, action: dict):
        try:
            response = requests.get(action.get('source'))
            response.raise_for_status()
            self._do_file_actions(action, response.json())
        except Exception as e:
            logging.error(f"[LOOP] Error retrieving web file: {str(e)}")

    def _do_file_actions(self, action: dict, file_data: list):
        for _file_entry in file_data:
            for _action in deepcopy(action.get('do', [])):
                for _action_key, _action_value in _action.items():
                    if isinstance(_action_value, str) and _action_value.startswith('do__'):
                        _key = _action_value.removeprefix('do__')
                        if _get_value := _file_entry.get(_key):
                            _action[_action_key] = _get_value
                self._execute_action(_action)
