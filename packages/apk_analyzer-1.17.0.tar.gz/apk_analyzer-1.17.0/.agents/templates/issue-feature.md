## Issue Type
- Epic / Feature / User Story

## Parent & Links
- Parent issue: #
- Related issues: #

## OpenSpec: Context
-

## OpenSpec: Scope
-

## OpenSpec: Constraints
-

## OpenSpec: Acceptance
- [ ]
- [ ]

## OpenSpec: Non-goals
-

## Sub-issues
- [ ] #<id> <title>
- [ ] #<id> <title>

## Rolling elaboration notes
- Current detailed slice:
- Next slices to elaborate later:
