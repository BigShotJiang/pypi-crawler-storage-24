## Linked Issues
- Closes #
- Refs #

## Workflow Type
- Feature / Bugfix / Refactor

## Background
- Why this change is needed:

## What Changed
- [ ] Change 1
- [ ] Change 2

## Validation
- ✅ Local: `command 1`
- ✅ Local: `command 2`
- ✅ CI: `<workflow name>`

## CI Fix Notes (if any)
- Failed checks:
- Fix applied:

## Risk
- Risk level: Low / Medium / High
- Impact scope:

## Rollback
- Revert commit:
- Restore config/flag:

## Release
- Release trigger: tag / workflow_dispatch
- Target version:

## Post-merge
- [ ] Update parent issue progress
- [ ] Close linked issue after CI+release confirmation
