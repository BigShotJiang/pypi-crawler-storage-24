## Usage
- 新需求开发：优先使用 `issue-feature.md`
- 修复缺陷：优先使用 `issue-bugfix.md`
- 重构代码：优先使用 `issue-refactor.md`
- 探索思路：优先使用 `issue-exploration.md`

## Generic Fields (fallback)
## Issue Type
- Epic / Feature / User Story / Bug / Refactor / Exploration

## Parent & Links
- Parent issue: #
- Related issues: #

## Problem / Context
-

## Goal
-

## Acceptance Criteria
- [ ]
- [ ]

## Rolling elaboration
- Detailed now:
- Detail later:
