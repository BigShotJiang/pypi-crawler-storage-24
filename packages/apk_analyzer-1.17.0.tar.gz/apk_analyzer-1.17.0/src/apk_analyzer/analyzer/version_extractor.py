"""Version extractor - merges BuildConfig + META-INF versions."""
import os
from apk_analyzer.models import DEXData


class VersionExtractor:
    def __init__(self, dex_data: DEXData, metainf: dict):
        self.dex = dex_data
        self.metainf = metainf

    def extract(self) -> dict:
        """Returns merged version dict: key is class/library name, value is version string."""
        versions = {}
        versions.update(self.metainf)
        versions.update(self.dex.buildconfig_versions)  # BuildConfig wins
        return versions
