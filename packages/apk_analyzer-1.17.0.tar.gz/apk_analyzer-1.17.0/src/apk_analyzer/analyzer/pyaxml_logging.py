"""Helpers for taming noisy pyaxmlparser warnings."""
from __future__ import annotations

import logging
from contextlib import contextmanager
from typing import Iterator


@contextmanager
def suppress_pyaxmlparser_warnings() -> Iterator[None]:
    """
    Temporarily silence pyaxmlparser warnings that are known to be non-fatal.

    Some APKs contain malformed string-pool entries and pyaxmlparser emits
    warning logs like "invalid decoded string length" while still returning
    usable parse results. We suppress those warning-level logs to keep CLI
    output clean, while still allowing ERROR/CRITICAL records through.
    """
    logger = logging.getLogger("pyaxmlparser")
    previous_level = logger.level
    try:
        logger.setLevel(logging.ERROR)
        yield
    finally:
        logger.setLevel(previous_level)
