"""Native library parser."""
import os
from apk_analyzer.models import NativeData


class NativeParser:
    def __init__(self, lib_names: list):
        self.lib_names = lib_names

    def parse(self) -> NativeData:
        nd = NativeData()
        nd.lib_names = self.lib_names
        return nd
