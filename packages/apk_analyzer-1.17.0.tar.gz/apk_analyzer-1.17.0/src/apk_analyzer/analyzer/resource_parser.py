"""
ResourceParser — zero-dependency resources.arsc string table resolver.

Parses just enough of the binary resources.arsc format to resolve a
resource ID (e.g. 0x7F0C0012) to its default-locale string value.

resources.arsc binary layout (simplified):
  RES_TABLE_TYPE         chunk header (type=0x0002)
    StringPool           global value string pool (type=0x0001)
    RES_TABLE_PACKAGE    one per package (type=0x0200)
      StringPool         type string pool
      StringPool         key string pool
      RES_TABLE_TYPE_TYPE  per-type entry table (type=0x0201)
        ...entries...

We only need:
  1. The global value StringPool to get all string values
  2. Each RES_TABLE_TYPE_TYPE chunk to map res_id -> string pool index
"""
from __future__ import annotations
import struct
from typing import Optional

_RES_STRING_POOL_TYPE   = 0x0001
_RES_TABLE_TYPE         = 0x0002
_RES_TABLE_PACKAGE_TYPE = 0x0200
_RES_TABLE_TYPE_TYPE    = 0x0201


def _u8(data: bytes, off: int) -> int:
    return data[off]

def _u16(data: bytes, off: int) -> int:
    return struct.unpack_from("<H", data, off)[0]

def _u32(data: bytes, off: int) -> int:
    return struct.unpack_from("<I", data, off)[0]


def _read_string_pool(data: bytes, base: int) -> list[str]:
    """Parse a RES_STRING_POOL chunk at `base`, return list of strings."""
    strings: list[str] = []
    try:
        header_size   = _u32(data, base + 4)
        string_count  = _u32(data, base + 12)
        flags         = _u32(data, base + 20)
        strings_start = _u32(data, base + 24)
        is_utf8 = bool(flags & (1 << 8))

        offsets_base  = base + header_size
        str_data_base = base + strings_start

        for i in range(string_count):
            off = offsets_base + i * 4
            if off + 4 > len(data):
                break
            str_off = _u32(data, off)
            pos = str_data_base + str_off
            if pos >= len(data):
                strings.append("")
                continue
            try:
                if is_utf8:
                    # skip char-length (1 or 2 bytes)
                    char_len = _u8(data, pos); pos += 1
                    if char_len & 0x80: pos += 1
                    # byte-length (1 or 2 bytes)
                    byte_len = _u8(data, pos); pos += 1
                    if byte_len & 0x80:
                        byte_len = ((byte_len & 0x7F) << 8) | _u8(data, pos); pos += 1
                    s = data[pos:pos + byte_len].decode("utf-8", errors="replace")
                else:
                    # UTF-16LE
                    char_len = _u16(data, pos); pos += 2
                    if char_len & 0x8000:
                        char_len = ((char_len & 0x7FFF) << 16) | _u16(data, pos); pos += 2
                    s = data[pos:pos + char_len * 2].decode("utf-16-le", errors="replace")
                strings.append(s)
            except Exception:
                strings.append("")
    except Exception:
        pass
    return strings


class ResourceParser:
    """
    Resolve a resource ID from raw `resources.arsc` bytes.

    Usage:
        parser = ResourceParser(arsc_bytes)
        name = parser.resolve(0x7F0C0012)  # -> "My App" or None
    """

    def __init__(self, arsc_bytes: bytes):
        self._data = arsc_bytes
        self._global_strings: list[str] = []
        self._res_map: dict[int, int] = {}   # res_id -> string pool index
        self._parsed = False

    def resolve(self, res_id: int) -> Optional[str]:
        """Return the default-locale string for `res_id`, or None."""
        if not self._parsed:
            self._parse()
        idx = self._res_map.get(res_id)
        if idx is None:
            return None
        if 0 <= idx < len(self._global_strings):
            val = self._global_strings[idx]
            return val if val else None
        return None

    def _parse(self):
        self._parsed = True
        data = self._data
        if len(data) < 12:
            return
        if _u16(data, 0) != _RES_TABLE_TYPE:
            return
        header_size = _u32(data, 4)
        pos = header_size
        while pos + 12 <= len(data):
            c_type = _u16(data, pos)
            c_size = _u32(data, pos + 8)
            if c_size == 0:
                break
            if c_type == _RES_STRING_POOL_TYPE and not self._global_strings:
                self._global_strings = _read_string_pool(data, pos)
            elif c_type == _RES_TABLE_PACKAGE_TYPE:
                self._parse_package(pos, pos + c_size)
            pos += c_size

    def _parse_package(self, base: int, end: int):
        data = self._data
        pkg_id          = _u32(data, base + 12)
        pkg_header_size = _u32(data, base + 4)
        pos = base + pkg_header_size
        while pos + 12 <= end and pos + 12 <= len(data):
            c_type = _u16(data, pos)
            c_size = _u32(data, pos + 8)
            if c_size == 0:
                break
            if c_type == _RES_TABLE_TYPE_TYPE:
                type_id = _u8(data, pos + 12)   # 1-based
                self._parse_type_chunk(pos, pkg_id, type_id)
            pos += c_size

    def _parse_type_chunk(self, base: int, pkg_id: int, type_id: int):
        data = self._data
        try:
            header_size  = _u32(data, base + 4)
            entry_count  = _u32(data, base + 16)
            entries_start = _u32(data, base + 20)

            offsets_base = base + header_size
            data_base    = base + entries_start

            for i in range(entry_count):
                op = offsets_base + i * 4
                if op + 4 > len(data):
                    break
                entry_off = _u32(data, op)
                if entry_off == 0xFFFFFFFF:
                    continue

                ep = data_base + entry_off
                if ep + 4 > len(data):
                    continue
                entry_flags = _u16(data, ep + 2)
                if entry_flags & 0x0001:        # complex/bag entry
                    continue

                val_off = ep + 4
                if val_off + 8 > len(data):
                    continue
                data_type = _u8(data, val_off + 3)
                val_data  = _u32(data, val_off + 4)

                if data_type == 0x03:           # TYPE_STRING
                    res_id = (pkg_id << 24) | (type_id << 16) | i
                    self._res_map[res_id] = val_data
        except Exception:
            pass
