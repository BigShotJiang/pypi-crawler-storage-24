# project_template

A project template for AI-driven GitHub development collaboration.

## Core lifecycle

For delivery tasks (feature / bugfix / refactor):
1. Create Issue(s)
2. Implement with PR
3. Pass CI gates
4. Fix CI until green
5. Trigger release
6. Close issue(s)

For exploration tasks:
- Create one exploration issue and keep a detailed investigation log.

## Workflow types
- New feature development
- Bug fixing
- Refactoring
- Idea exploration

## Directory layout

```text
.
├── AGENTS.md
└── .agents/
    ├── rules/      # global constraints and guardrails
    ├── workflows/  # step-by-step operating flows
    ├── skills/     # reusable capability manifests
    └── templates/  # issue/pr authoring templates
```

## Suggested usage

1. Read `AGENTS.md` first.
2. Pick a workflow from `.agents/workflows/`.
3. Apply a matching skill from `.agents/skills/`.
4. Produce issue/PR outputs with `.agents/templates/`.


## Branch naming
- Format: `<type>-<issue id>`
- Allowed type: `feature` / `bugfix` / `refactor` / `exploration` / `other`
- Examples: `feature-101`, `bugfix-202`
- Note: branch naming is for process management; tag bump automation is determined by commit keywords (for example `feat:`/`[minor]` or `fix:`/`[patch]`), not branch prefixes.
