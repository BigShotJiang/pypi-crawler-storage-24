from setuptools import setup, find_packages


setup(
    name='odapi.py',
    version='1.0.0',
    install_requires=[
        'aiohttp',
    ],
    packages=find_packages(exclude=["tests*", "tests.*"]),
    py_modules=['odapi'],
    url="https://github.com/75efb6/odpy-package",
    author="75efb6",
    description="A Python package for the osu!droid API (only v2.0 supported)",
)