from dataclasses import dataclass

@dataclass
class Stats:
    global_rank: int
    country_rank: int
    pp: float
    acc: float
    total_score: int
    total_playcount: int

@dataclass
class LeaderboardStats:
    rank: int
    pp: float
    acc: float
    total_playcount: int