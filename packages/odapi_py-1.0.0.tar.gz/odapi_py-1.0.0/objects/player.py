from dataclasses import dataclass

# Dependencies for Player class
from objects.score import Score
from objects.stats import Stats, LeaderboardStats

@dataclass
class Player:
    id: int
    name: str
    country: str
    registered: str
    last_login: str
    stats: Stats
    recent_scores: list[Score]
    top_scores: list[Score]

@dataclass
class LeaderboardPlayer:
    id: int
    name: str
    country: str
    stats: LeaderboardStats