from dataclasses import dataclass

@dataclass
class Score:
    score_id: int
    map_hash: str
    pp: float
    mods: str
    score: int
    grade: str
    acc: float
    combo: int
    h300: int
    h100: int
    h50: int
    misscount: int
    date: str