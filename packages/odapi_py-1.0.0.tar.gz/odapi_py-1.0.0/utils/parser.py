from objects.stats import Stats, LeaderboardStats
from objects.score import Score
from objects.player import Player, LeaderboardPlayer
from utils.helpers import ModHelper, AccuracyHelper

def score(score: dict) -> Score:
    acc_helper = AccuracyHelper(score.get("MapAccuracy"))
    score["MapAccuracy"] = acc_helper.normalize
    mod_parser = ModHelper(mods=score.get("Mods"))
    score["MapMods"] = mod_parser.parse

    return Score(
        score_id=score.get("ScoreId"),
        map_hash=score.get("MapHash"),
        pp=score.get("MapPP"),
        mods=score.get("MapMods"),
        score=score.get("MapScore"),
        grade=score.get("MapRank"),
        acc=score.get("MapAccuracy"),
        combo=score.get("MapCombo"),
        h300=score.get("MapPerfect"),
        h100=score.get("MapGood"),
        h50=score.get("MapBad"),
        misscount=score.get("MapMiss"),
        date=score.get("PlayedDate")
    )

def player(data: dict) -> Player:
    rscores = []
    tscores = []

    for s in data.get("Top50Plays"):
        parsed = score(s)
        tscores.append(parsed)

    for s in data.get("Last50Scores"):
        parsed = score(s)
        rscores.append(parsed)

    acc_helper = AccuracyHelper(data.get("OverallAccuracy"))
    data["OverallAccuracy"] = acc_helper.normalize

    stats = Stats(
        global_rank=data.get("GlobalRank"),
        country_rank=data.get("CountryRank"),
        pp=data.get("OverallPP"),
        acc=data.get("OverallAccuracy"),
        total_score=data.get("OverallScore"),
        total_playcount=data.get("OverallPlaycount")
    )
    
    player = Player(
        id=data.get("UserId"),
        name=data.get("Username"),
        country=data.get("Region"),
        registered=data.get("Registered"),
        last_login=data.get("LastLogin"),
        stats=stats,
        recent_scores=rscores,
        top_scores=tscores
    )

    return player

def leaderboard(data: list[dict], limit: int) -> list[LeaderboardPlayer]:
    lb = []

    rank = 0

    for player in data["Results"]:
        if data["CurrentPage"] >= 2:
            rank += 1 * (data["CurrentPage"] - 1)
        rank+=1

        acc_helper = AccuracyHelper(player.get("OverallAccuracy"))
        player["OverallAccuracy"] = acc_helper.normalize

        stats = LeaderboardStats(
            rank=rank,
            pp=player.get("OverallPP"),
            acc=player.get("OverallAccuracy"),
            total_playcount=player.get("OverallPlaycount")
        )
    
        player = LeaderboardPlayer(
            id=player.get("UserId"),
            name=player.get("Username"),
            country=player.get("Region"),
            stats=stats
        )

        lb.append(player)

    return lb