import json
from typing import Optional

class ModHelper:
    def __init__(self, mods: Optional[dict] = None):
        self.mods = mods
    
    @property
    def parse(self) -> str:
        if not self.mods:
            return "NM"

        parsed = []

        for mod in self.mods:
            if mod["acronym"] == "CS":
                mod = f"CS({mod['settings']['rateMultiplier']}x)"
            elif mod["acronym"] == "RE":
                mod = "REZ"
            elif mod["acronym"] == "DA":
                settings = []
                for setting, value in mod["settings"].items():
                    settings.append(f"{setting}: {value}")
                settings = ", ".join(settings)
                mod = f"DA({settings})"
            else:
                mod = mod["acronym"]

            parsed.append(mod)

        return "".join(parsed)

class AccuracyHelper:
    def __init__(self, acc: float):
        self.acc = acc
    
    @property
    def normalize(self) -> float:
        return round(self.acc*100, 2)
    
    @property
    def denormalize(self) -> float:
        return self.acc/100
    
def check_get_user_attrs(uid: int=None, username: str=None, from_username: bool=False):
        if from_username is not True or False:
            raise Exception("from_username must be True or False")
        if username is None and from_username is True:
            raise Exception("Username must not be empty if from_username is True.")
        elif isinstance(username, str) is not True and from_username is True:
            raise Exception("Username must be string.")
        if uid is None and from_username is False:
            raise Exception("UID must not be empty if from_username is False.")
        elif isinstance(uid, int) is not True and from_username is False:
            raise Exception("UID must be int.")