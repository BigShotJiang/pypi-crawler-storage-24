import utils.parser
import utils.helpers

from handlers.request import AsyncRequestHandler

from objects.player import Player, LeaderboardPlayer
from objects.score import Score

class DroidAPIClient:
    def __init__(self):
        self.v1 = AsyncRequestHandler(1)
        self.v2 = AsyncRequestHandler()

    async def get_user(self, uid: int=None, username: str=None, from_username: bool=False) -> Player:
        endpoint = f"/profile-username/{username}" if from_username is True else f"/profile-uid/{uid}"
        utils.helpers.check_get_user_attrs(uid=uid, username=username, from_username=from_username)
        
        data = await self.v2.get(endpoint)
        player = utils.parser.player(data)

        return player
    
    async def get_leaderboard(self, page: int=1, region: str="all", lbtype: str="pp", limit: int=50) -> list[LeaderboardPlayer]:
        endpoint = f"/leaderboard/type={lbtype}/region={region}/page={page}/limit={limit}"
        data = await self.v2.get(endpoint)
        lb = utils.parser.leaderboard(data=data, limit=limit)

        return lb
    
    async def get_recent(self, uid: int=None, username: str=None, from_username: bool=False) -> list[Score]:
        endpoint = f"/profile-username/{username}" if from_username is True else f"/profile-uid/{uid}"
        utils.helpers.check_get_user_attrs(uid=uid, username=username, from_username=from_username)

        data = await self.v2.get(endpoint)
        player = utils.parser.player(data)
        
        return player.recent_scores
    
    async def get_top(self, uid: int=None, username: str=None, from_username: bool=False) -> list[Score]:
        endpoint = f"/profile-username/{username}" if from_username is True else f"/profile-uid/{uid}"
        utils.helpers.check_get_user_attrs(uid=uid, username=username, from_username=from_username)
        data = await self.v2.get(endpoint)    
        player = utils.parser.player(data)

        return player.top_scores
