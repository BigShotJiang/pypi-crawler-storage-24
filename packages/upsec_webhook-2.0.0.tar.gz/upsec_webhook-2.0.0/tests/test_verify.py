import unittest
from upsec import verify_signature, sign_payload


class TestVerifySignature(unittest.TestCase):
    def setUp(self):
        self.secret = "whsec_test123"
        self.payload = b'{"event":"test"}'

    def test_valid_signature_with_prefix(self):
        sig = sign_payload(self.payload, self.secret)
        self.assertTrue(verify_signature(self.payload, self.secret, sig))

    def test_valid_signature_without_prefix(self):
        sig = sign_payload(self.payload, self.secret)
        hex_only = sig.split("=", 1)[1]
        self.assertTrue(verify_signature(self.payload, self.secret, hex_only))

    def test_invalid_signature(self):
        self.assertFalse(verify_signature(self.payload, self.secret, "sha256=invalid"))

    def test_empty_inputs(self):
        self.assertFalse(verify_signature(b"", self.secret, "abc"))
        self.assertFalse(verify_signature(self.payload, "", "abc"))
        self.assertFalse(verify_signature(self.payload, self.secret, ""))


if __name__ == "__main__":
    unittest.main()
