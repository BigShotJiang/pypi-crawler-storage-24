"""UpSec Webhook SDK for Python — signature verification & API client."""

from .verify import verify_signature, sign_payload
from .client import UpSec, UpSecApiError, UpSecEndpoint, UpSecEvent, UpSecDestination, UpSecDeliveryAttempt, UpSecProfile

__version__ = "2.0.0"
__all__ = [
    "verify_signature",
    "sign_payload",
    "UpSec",
    "UpSecApiError",
    "UpSecEndpoint",
    "UpSecEvent",
    "UpSecDestination",
    "UpSecDeliveryAttempt",
    "UpSecProfile",
]
