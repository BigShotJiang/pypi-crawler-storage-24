"""UpSec API Client — programmatic access to your UpSec dashboard data."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
from urllib.request import Request, urlopen
from urllib.error import HTTPError
from urllib.parse import urlencode

DEFAULT_BASE_URL = "https://cljesijjamqbpttfctee.supabase.co/functions/v1/api"


class UpSecApiError(Exception):
    """Raised when the UpSec API returns a non-2xx response."""

    def __init__(self, message: str, status: int, body: Any = None):
        super().__init__(message)
        self.status = status
        self.body = body


@dataclass
class UpSecEndpoint:
    id: str
    name: str
    target_url: str
    active: bool
    created_at: str
    workspace_id: Optional[str] = None


@dataclass
class UpSecEvent:
    id: str
    endpoint_id: str
    source: str
    status_code: int
    signature_valid: bool
    created_at: str
    payload_json: Dict[str, Any] = field(default_factory=dict)


@dataclass
class UpSecDestination:
    id: str
    name: str
    target_url: str
    active: bool
    endpoint_id: str
    created_at: str
    transform_rules: Dict[str, Any] = field(default_factory=dict)


@dataclass
class UpSecDeliveryAttempt:
    id: str
    event_id: str
    destination_id: str
    status_code: int
    attempt_number: int
    created_at: str
    error_message: Optional[str] = None
    response_body: Optional[str] = None
    next_retry_at: Optional[str] = None


@dataclass
class UpSecProfile:
    id: str
    full_name: Optional[str]
    company_name: Optional[str]
    subscription_status: str
    created_at: str


def _request(base_url: str, api_key: str, resource: str, params: Optional[Dict[str, str]] = None) -> Any:
    url = f"{base_url}/v1/{resource}"
    if params:
        filtered = {k: v for k, v in params.items() if v is not None}
        if filtered:
            url += "?" + urlencode(filtered)

    req = Request(url, method="GET", headers={
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    })

    try:
        with urlopen(req) as resp:
            return json.loads(resp.read().decode())
    except HTTPError as e:
        body = json.loads(e.read().decode()) if e.fp else None
        raise UpSecApiError(
            body.get("error", f"HTTP {e.code}") if body else f"HTTP {e.code}",
            e.code,
            body,
        ) from e


class _EndpointsResource:
    def __init__(self, base_url: str, api_key: str):
        self._base_url = base_url
        self._api_key = api_key

    def list(self) -> List[UpSecEndpoint]:
        """List all your endpoints."""
        res = _request(self._base_url, self._api_key, "endpoints")
        return [UpSecEndpoint(**e) for e in res["data"]]


class _EventsResource:
    def __init__(self, base_url: str, api_key: str):
        self._base_url = base_url
        self._api_key = api_key

    def list(
        self,
        endpoint_id: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> Dict[str, Any]:
        """List events with optional filtering. Returns { data, total }."""
        params: Dict[str, str] = {}
        if endpoint_id:
            params["endpoint_id"] = endpoint_id
        if limit is not None:
            params["limit"] = str(limit)
        if offset is not None:
            params["offset"] = str(offset)

        res = _request(self._base_url, self._api_key, "events", params)
        return {
            "data": [UpSecEvent(**e) for e in res["data"]],
            "total": res.get("total"),
        }


class _DestinationsResource:
    def __init__(self, base_url: str, api_key: str):
        self._base_url = base_url
        self._api_key = api_key

    def list(self) -> List[UpSecDestination]:
        """List all your destinations."""
        res = _request(self._base_url, self._api_key, "destinations")
        return [UpSecDestination(**d) for d in res["data"]]


class _DeliveryAttemptsResource:
    def __init__(self, base_url: str, api_key: str):
        self._base_url = base_url
        self._api_key = api_key

    def list(
        self,
        event_id: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> List[UpSecDeliveryAttempt]:
        """List delivery attempts, optionally filtered by event ID."""
        params: Dict[str, str] = {}
        if event_id:
            params["event_id"] = event_id
        if limit is not None:
            params["limit"] = str(limit)

        res = _request(self._base_url, self._api_key, "delivery-attempts", params)
        return [UpSecDeliveryAttempt(**d) for d in res["data"]]


class UpSec:
    """
    UpSec API Client.

    Provides typed access to UpSec resources: endpoints, events,
    destinations, delivery attempts, and your profile.

    Example::

        from upsec import UpSec

        client = UpSec(api_key="sk_live_...")
        endpoints = client.endpoints.list()
        events = client.events.list(endpoint_id=endpoints[0].id, limit=10)
        me = client.me()
    """

    def __init__(self, api_key: str, base_url: Optional[str] = None):
        if not api_key:
            raise ValueError("api_key is required")
        self._api_key = api_key
        self._base_url = base_url or DEFAULT_BASE_URL

        self.endpoints = _EndpointsResource(self._base_url, self._api_key)
        self.events = _EventsResource(self._base_url, self._api_key)
        self.destinations = _DestinationsResource(self._base_url, self._api_key)
        self.delivery_attempts = _DeliveryAttemptsResource(self._base_url, self._api_key)

    def me(self) -> UpSecProfile:
        """Get your UpSec profile."""
        res = _request(self._base_url, self._api_key, "me")
        return UpSecProfile(**res["data"])
