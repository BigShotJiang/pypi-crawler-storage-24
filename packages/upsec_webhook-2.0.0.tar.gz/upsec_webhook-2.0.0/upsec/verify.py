"""HMAC webhook signature verification."""

import hmac
import hashlib
from typing import Optional


def verify_signature(
    payload: bytes,
    secret: str,
    signature: str,
    algorithm: str = "sha256",
) -> bool:
    """
    Verify an HMAC webhook signature using constant-time comparison.

    Args:
        payload: Raw request body as bytes.
        secret: Your webhook signing secret.
        signature: The signature header value (with or without "sha256=" prefix).
        algorithm: Hash algorithm (default: "sha256").

    Returns:
        True if the signature is valid.

    Example::

        from upsec import verify_signature

        is_valid = verify_signature(
            payload=request.get_data(),
            secret=os.environ["WEBHOOK_SECRET"],
            signature=request.headers.get("X-Hub-Signature-256", ""),
        )
    """
    if not payload or not secret or not signature:
        return False

    hash_func = getattr(hashlib, algorithm, None)
    if hash_func is None:
        raise ValueError(f"Unsupported algorithm: {algorithm}")

    expected = hmac.new(
        secret.encode("utf-8"),
        payload if isinstance(payload, bytes) else payload.encode("utf-8"),
        hash_func,
    ).hexdigest()

    # Strip algorithm prefix if present
    prefix = f"{algorithm}="
    sig = signature[len(prefix):] if signature.startswith(prefix) else signature

    return hmac.compare_digest(expected, sig)


def sign_payload(
    payload: bytes,
    secret: str,
    algorithm: str = "sha256",
) -> str:
    """Compute a signed header value. Useful for testing."""
    hash_func = getattr(hashlib, algorithm)
    digest = hmac.new(
        secret.encode("utf-8"),
        payload if isinstance(payload, bytes) else payload.encode("utf-8"),
        hash_func,
    ).hexdigest()
    return f"{algorithm}={digest}"
