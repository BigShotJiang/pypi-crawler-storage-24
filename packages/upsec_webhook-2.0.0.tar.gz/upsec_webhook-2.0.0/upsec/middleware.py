"""Flask/Django middleware helpers."""

from functools import wraps
from .verify import verify_signature


def flask_webhook(secret: str, header: str = "X-Hub-Signature-256", algorithm: str = "sha256"):
    """
    Flask decorator for webhook signature verification.

    Example::

        from upsec.middleware import flask_webhook

        @app.route("/webhook", methods=["POST"])
        @flask_webhook(secret=os.environ["WEBHOOK_SECRET"])
        def handle_webhook():
            return {"ok": True}
    """
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            from flask import request, jsonify

            sig = request.headers.get(header, "")
            if not verify_signature(
                payload=request.get_data(),
                secret=secret,
                signature=sig,
                algorithm=algorithm,
            ):
                return jsonify({"error": "Invalid webhook signature"}), 401
            return f(*args, **kwargs)
        return wrapper
    return decorator
