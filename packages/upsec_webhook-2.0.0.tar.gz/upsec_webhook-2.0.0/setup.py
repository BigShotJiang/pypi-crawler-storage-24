from setuptools import setup, find_packages

setup(
    name="upsec-webhook",
    version="2.0.0",
    description="UpSec Webhook signature verification SDK for Python",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    python_requires=">=3.8",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Topic :: Security",
    ],
)
