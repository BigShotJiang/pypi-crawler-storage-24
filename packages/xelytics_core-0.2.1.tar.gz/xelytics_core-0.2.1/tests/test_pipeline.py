"""
Tests for xelytics pipeline module.
Covers: Pipeline, PipelineStep, normalize, pca, remove_outliers, correlation_analysis
"""

import pytest
import numpy as np
import pandas as pd


# ===========================================================================
# Fixtures
# ===========================================================================

@pytest.fixture
def numeric_df():
    """Simple numeric DataFrame."""
    np.random.seed(42)
    return pd.DataFrame({
        "a": np.random.randn(100),
        "b": np.random.randn(100) * 2 + 5,
        "c": np.random.randn(100) * 0.5 - 3,
    })


@pytest.fixture
def mixed_df(numeric_df):
    """Numeric + categorical columns."""
    df = numeric_df.copy()
    df["category"] = np.random.choice(["X", "Y", "Z"], size=len(df))
    return df


@pytest.fixture
def df_with_outliers():
    """DataFrame with obvious outliers for remove_outliers testing."""
    np.random.seed(0)
    data = np.random.randn(100)
    data[0] = 100.0   # extreme outlier
    data[1] = -100.0  # extreme outlier
    return pd.DataFrame({"x": data, "y": np.random.randn(100)})


@pytest.fixture
def correlated_df():
    """DataFrame with known correlations."""
    np.random.seed(7)
    x = np.random.randn(100)
    return pd.DataFrame({
        "x": x,
        "y": x * 2 + np.random.randn(100) * 0.1,  # highly correlated with x
        "z": np.random.randn(100),                  # uncorrelated
    })


# ===========================================================================
# PipelineStep Tests
# ===========================================================================

class TestPipelineStep:

    def test_basic_execute(self, numeric_df):
        from xelytics.pipeline import PipelineStep

        def add_column(df):
            df = df.copy()
            df["new"] = 1
            return df

        step = PipelineStep(name="add_col", func=add_column, inputs=["df"], outputs=["df"])
        ctx = {"df": numeric_df}
        result_ctx = step.execute(ctx)
        assert "new" in result_ctx["df"].columns

    def test_missing_input_raises(self, numeric_df):
        from xelytics.pipeline import PipelineStep

        def dummy(df):
            return df

        step = PipelineStep(name="dummy", func=dummy, inputs=["missing_key"], outputs=["df"])
        with pytest.raises(ValueError, match="not found in context"):
            step.execute({"df": numeric_df})

    def test_single_output_stored(self, numeric_df):
        from xelytics.pipeline import PipelineStep

        step = PipelineStep(
            name="identity",
            func=lambda df: df,
            inputs=["df"],
            outputs=["result"]
        )
        ctx = step.execute({"df": numeric_df})
        assert "result" in ctx

    def test_multiple_outputs_from_tuple(self, numeric_df):
        from xelytics.pipeline import PipelineStep

        def split(df):
            return df.iloc[:50], df.iloc[50:]

        step = PipelineStep(
            name="split",
            func=split,
            inputs=["df"],
            outputs=["train", "test"]
        )
        ctx = step.execute({"df": numeric_df})
        assert "train" in ctx
        assert "test" in ctx
        assert len(ctx["train"]) == 50
        assert len(ctx["test"]) == 50

    def test_kwargs_passed_to_func(self, numeric_df):
        from xelytics.pipeline import PipelineStep

        def multiply(df, factor=1):
            return df * factor

        step = PipelineStep(
            name="multiply",
            func=multiply,
            inputs=["df"],
            outputs=["df"],
            factor=3
        )
        ctx = step.execute({"df": numeric_df[["a"]]})
        expected = numeric_df[["a"]] * 3
        pd.testing.assert_frame_equal(ctx["df"], expected)

    def test_default_output_name_is_step_name(self, numeric_df):
        from xelytics.pipeline import PipelineStep

        step = PipelineStep(name="my_step", func=lambda df: df, inputs=["df"])
        ctx = step.execute({"df": numeric_df})
        assert "my_step" in ctx


# ===========================================================================
# Pipeline Tests
# ===========================================================================

class TestPipeline:

    def test_empty_pipeline_returns_context_unchanged(self, numeric_df):
        from xelytics.pipeline import Pipeline
        pipeline = Pipeline()
        ctx = pipeline.execute({"df": numeric_df})
        pd.testing.assert_frame_equal(ctx["df"], numeric_df)

    def test_add_step_with_callable(self, numeric_df):
        from xelytics.pipeline import Pipeline

        def tag(df):
            df = df.copy()
            df["tagged"] = True
            return df

        pipeline = Pipeline()
        pipeline.add_step(tag, name="tag", inputs=["df"], outputs=["df"])
        ctx = pipeline.execute({"df": numeric_df})
        assert "tagged" in ctx["df"].columns

    def test_add_step_with_pipeline_step_object(self, numeric_df):
        from xelytics.pipeline import Pipeline, PipelineStep

        step = PipelineStep("noop", lambda df: df, inputs=["df"], outputs=["df"])
        pipeline = Pipeline()
        pipeline.add_step(step)
        ctx = pipeline.execute({"df": numeric_df})
        assert "df" in ctx

    def test_chained_steps(self, numeric_df):
        from xelytics.pipeline import Pipeline

        def step1(df):
            df = df.copy(); df["s1"] = 1; return df

        def step2(df):
            df = df.copy(); df["s2"] = 2; return df

        pipeline = Pipeline()
        pipeline.add_step(step1, name="s1", inputs=["df"], outputs=["df"])
        pipeline.add_step(step2, name="s2", inputs=["df"], outputs=["df"])
        ctx = pipeline.execute({"df": numeric_df})
        assert "s1" in ctx["df"].columns
        assert "s2" in ctx["df"].columns

    def test_add_step_returns_pipeline_for_chaining(self, numeric_df):
        from xelytics.pipeline import Pipeline

        pipeline = Pipeline()
        result = pipeline.add_step(lambda df: df, name="noop", inputs=["df"], outputs=["df"])
        assert result is pipeline  # fluent interface

    def test_pipeline_name(self):
        from xelytics.pipeline import Pipeline
        p = Pipeline(name="my_pipeline")
        assert p.name == "my_pipeline"

    def test_pipeline_default_name(self):
        from xelytics.pipeline import Pipeline
        p = Pipeline()
        assert p.name == "custom_pipeline"

    def test_steps_list_grows(self, numeric_df):
        from xelytics.pipeline import Pipeline
        pipeline = Pipeline()
        assert len(pipeline.steps) == 0
        pipeline.add_step(lambda df: df, name="s1", inputs=["df"], outputs=["df"])
        assert len(pipeline.steps) == 1
        pipeline.add_step(lambda df: df, name="s2", inputs=["df"], outputs=["df"])
        assert len(pipeline.steps) == 2

    def test_initial_context_not_mutated(self, numeric_df):
        from xelytics.pipeline import Pipeline

        def add_col(df):
            df = df.copy(); df["new"] = 99; return df

        pipeline = Pipeline()
        pipeline.add_step(add_col, name="add", inputs=["df"], outputs=["df"])
        original = numeric_df.copy()
        pipeline.execute({"df": numeric_df})
        pd.testing.assert_frame_equal(numeric_df, original)

    def test_multi_key_context(self, numeric_df):
        from xelytics.pipeline import Pipeline

        def combine(df1, df2):
            return pd.concat([df1, df2], ignore_index=True)

        pipeline = Pipeline()
        pipeline.add_step(
            combine,
            name="combined",
            inputs=["df1", "df2"],
            outputs=["combined"]
        )
        half = numeric_df.iloc[:50].reset_index(drop=True)
        ctx = pipeline.execute({"df1": half, "df2": half})
        assert len(ctx["combined"]) == 100


# ===========================================================================
# normalize() Tests
# ===========================================================================

class TestNormalize:

    def test_zscore_zero_mean(self, numeric_df):
        from xelytics.pipeline import normalize
        result = normalize(numeric_df, method="zscore")
        for col in numeric_df.columns:
            assert abs(result[col].mean()) < 1e-9

    def test_zscore_unit_std(self, numeric_df):
        from xelytics.pipeline import normalize
        result = normalize(numeric_df, method="zscore")
        for col in numeric_df.columns:
            assert abs(result[col].std() - 1.0) < 1e-6

    def test_minmax_range(self, numeric_df):
        from xelytics.pipeline import normalize
        result = normalize(numeric_df, method="minmax")
        for col in numeric_df.columns:
            assert result[col].min() >= 0.0 - 1e-9
            assert result[col].max() <= 1.0 + 1e-9

    def test_robust_normalization(self, numeric_df):
        from xelytics.pipeline import normalize
        result = normalize(numeric_df, method="robust")
        # After robust scaling, median should be near 0
        for col in numeric_df.columns:
            assert abs(result[col].median()) < 1e-6

    def test_specific_columns_only(self, mixed_df):
        from xelytics.pipeline import normalize
        result = normalize(mixed_df, columns=["a"], method="zscore")
        assert abs(result["a"].mean()) < 1e-9
        # Other numeric columns should be untouched
        assert result["b"].equals(mixed_df["b"])
        # Categorical column untouched
        assert result["category"].equals(mixed_df["category"])

    def test_does_not_mutate_input(self, numeric_df):
        from xelytics.pipeline import normalize
        original = numeric_df.copy()
        normalize(numeric_df, method="zscore")
        pd.testing.assert_frame_equal(numeric_df, original)

    def test_auto_selects_numeric_columns(self, mixed_df):
        from xelytics.pipeline import normalize
        result = normalize(mixed_df, method="zscore")
        # Category column should still be object dtype
        assert result["category"].dtype == object


# ===========================================================================
# pca() Tests
# ===========================================================================

class TestPCA:

    def test_output_shape(self, numeric_df):
        from xelytics.pipeline import pca
        result = pca(numeric_df, n_components=2)
        assert result.shape == (len(numeric_df), 2)

    def test_column_names_pc(self, numeric_df):
        from xelytics.pipeline import pca
        result = pca(numeric_df, n_components=2)
        assert list(result.columns) == ["PC1", "PC2"]

    def test_n_components_1(self, numeric_df):
        from xelytics.pipeline import pca
        result = pca(numeric_df, n_components=1)
        assert "PC1" in result.columns
        assert result.shape[1] == 1

    def test_non_numeric_columns_preserved(self, mixed_df):
        from xelytics.pipeline import pca
        result = pca(mixed_df, n_components=2)
        assert "category" in result.columns
        assert "PC1" in result.columns

    def test_specific_columns(self, numeric_df):
        from xelytics.pipeline import pca
        result = pca(numeric_df, columns=["a", "b"], n_components=1)
        assert result.shape[1] == 1

    def test_no_numeric_raises(self):
        from xelytics.pipeline import pca
        df = pd.DataFrame({"cat": ["a", "b", "c"]})
        with pytest.raises(ValueError, match="No numeric columns"):
            pca(df)

    def test_index_preserved(self, numeric_df):
        from xelytics.pipeline import pca
        result = pca(numeric_df, n_components=2)
        assert list(result.index) == list(numeric_df.index)


# ===========================================================================
# remove_outliers() Tests
# ===========================================================================

class TestRemoveOutliers:

    def test_iqr_removes_extreme_values(self, df_with_outliers):
        from xelytics.pipeline import remove_outliers
        result = remove_outliers(df_with_outliers, method="iqr")
        assert len(result) < len(df_with_outliers)
        assert result["x"].max() < 100.0
        assert result["x"].min() > -100.0

    def test_zscore_removes_extreme_values(self, df_with_outliers):
        from xelytics.pipeline import remove_outliers
        result = remove_outliers(df_with_outliers, method="zscore", threshold=3.0)
        assert len(result) < len(df_with_outliers)

    def test_specific_columns(self, df_with_outliers):
        from xelytics.pipeline import remove_outliers
        result = remove_outliers(df_with_outliers, columns=["x"], method="iqr")
        # Only x outliers removed, y untouched in filtering
        assert len(result) < len(df_with_outliers)

    def test_does_not_mutate_input(self, df_with_outliers):
        from xelytics.pipeline import remove_outliers
        original_len = len(df_with_outliers)
        remove_outliers(df_with_outliers, method="iqr")
        assert len(df_with_outliers) == original_len

    def test_tight_threshold_removes_more(self, numeric_df):
        from xelytics.pipeline import remove_outliers
        loose = remove_outliers(numeric_df, method="iqr", threshold=3.0)
        tight = remove_outliers(numeric_df, method="iqr", threshold=1.0)
        assert len(tight) <= len(loose)

    def test_no_outliers_unchanged(self):
        from xelytics.pipeline import remove_outliers
        df = pd.DataFrame({"x": [1.0, 2.0, 3.0, 4.0, 5.0]})
        result = remove_outliers(df, method="iqr", threshold=10.0)
        assert len(result) == len(df)

    def test_auto_selects_numeric(self, mixed_df):
        from xelytics.pipeline import remove_outliers
        result = remove_outliers(mixed_df, method="iqr")
        assert "category" in result.columns


# ===========================================================================
# correlation_analysis() Tests
# ===========================================================================

class TestCorrelationAnalysis:

    def test_returns_dataframe(self, numeric_df):
        from xelytics.pipeline import correlation_analysis
        result = correlation_analysis(numeric_df)
        assert isinstance(result, pd.DataFrame)

    def test_square_matrix(self, numeric_df):
        from xelytics.pipeline import correlation_analysis
        result = correlation_analysis(numeric_df)
        assert result.shape == (3, 3)

    def test_diagonal_is_one(self, numeric_df):
        from xelytics.pipeline import correlation_analysis
        result = correlation_analysis(numeric_df)
        for col in result.columns:
            assert abs(result.loc[col, col] - 1.0) < 1e-9

    def test_symmetric(self, numeric_df):
        from xelytics.pipeline import correlation_analysis
        result = correlation_analysis(numeric_df)
        for i in result.columns:
            for j in result.columns:
                assert abs(result.loc[i, j] - result.loc[j, i]) < 1e-9

    def test_pearson_method(self, correlated_df):
        from xelytics.pipeline import correlation_analysis
        result = correlation_analysis(correlated_df, method="pearson")
        assert result.loc["x", "y"] > 0.95  # highly correlated

    def test_spearman_method(self, correlated_df):
        from xelytics.pipeline import correlation_analysis
        result = correlation_analysis(correlated_df, method="spearman")
        assert result.loc["x", "y"] > 0.90

    def test_kendall_method(self, correlated_df):
        from xelytics.pipeline import correlation_analysis
        result = correlation_analysis(correlated_df, method="kendall")
        assert result.loc["x", "y"] > 0.80

    def test_excludes_non_numeric(self, mixed_df):
        from xelytics.pipeline import correlation_analysis
        result = correlation_analysis(mixed_df)
        assert "category" not in result.columns

    def test_values_in_range(self, numeric_df):
        from xelytics.pipeline import correlation_analysis
        result = correlation_analysis(numeric_df)
        assert result.values.min() >= -1.0 - 1e-9
        assert result.values.max() <= 1.0 + 1e-9


# ===========================================================================
# Integration: Pipeline with predefined steps
# ===========================================================================

class TestPipelineIntegration:

    def test_normalize_then_pca(self, numeric_df):
        from xelytics.pipeline import Pipeline, normalize, pca

        pipeline = Pipeline(name="norm_pca")
        pipeline.add_step(normalize, name="normalize", inputs=["df"], outputs=["df"], method="zscore")
        pipeline.add_step(pca, name="pca", inputs=["df"], outputs=["df"], n_components=2)

        ctx = pipeline.execute({"df": numeric_df})
        assert ctx["df"].shape == (len(numeric_df), 2)
        assert "PC1" in ctx["df"].columns

    def test_remove_outliers_then_normalize(self, df_with_outliers):
        from xelytics.pipeline import Pipeline, normalize, remove_outliers

        pipeline = Pipeline()
        pipeline.add_step(remove_outliers, name="rm_outliers", inputs=["df"], outputs=["df"])
        pipeline.add_step(normalize, name="normalize", inputs=["df"], outputs=["df"])

        ctx = pipeline.execute({"df": df_with_outliers})
        result = ctx["df"]
        assert len(result) < len(df_with_outliers)
        for col in ["x", "y"]:
            assert abs(result[col].mean()) < 1e-9

    def test_correlation_stored_separately(self, numeric_df):
        from xelytics.pipeline import Pipeline, normalize, correlation_analysis

        pipeline = Pipeline()
        pipeline.add_step(normalize, name="normalize", inputs=["df"], outputs=["df"])
        pipeline.add_step(
            correlation_analysis,
            name="corr",
            inputs=["df"],
            outputs=["corr_matrix"]
        )

        ctx = pipeline.execute({"df": numeric_df})
        assert "corr_matrix" in ctx
        assert ctx["corr_matrix"].shape == (3, 3)
        assert "df" in ctx  # original still in context

    def test_full_pipeline_three_steps(self, df_with_outliers):
        from xelytics.pipeline import Pipeline, normalize, remove_outliers, pca

        pipeline = Pipeline(name="full")
        pipeline.add_step(remove_outliers, name="rm", inputs=["df"], outputs=["df"])
        pipeline.add_step(normalize, name="norm", inputs=["df"], outputs=["df"])
        pipeline.add_step(pca, name="pca", inputs=["df"], outputs=["df"], n_components=1)

        ctx = pipeline.execute({"df": df_with_outliers})
        assert "PC1" in ctx["df"].columns

    def test_missing_context_key_mid_pipeline(self, numeric_df):
        from xelytics.pipeline import Pipeline, PipelineStep

        step = PipelineStep("bad", lambda x: x, inputs=["nonexistent"], outputs=["out"])
        pipeline = Pipeline()
        pipeline.add_step(step)

        with pytest.raises(ValueError, match="not found in context"):
            pipeline.execute({"df": numeric_df})


# ===========================================================================
# Module-level imports
# ===========================================================================

class TestModuleImports:

    def test_all_exports_importable(self):
        from xelytics.pipeline import (
            Pipeline,
            PipelineStep,
            normalize,
            pca,
            remove_outliers,
            correlation_analysis,
        )
        assert Pipeline is not None
        assert PipelineStep is not None
        assert callable(normalize)
        assert callable(pca)
        assert callable(remove_outliers)
        assert callable(correlation_analysis)

    def test_version(self):
        from xelytics.pipeline import __version__
        assert __version__ == "0.2.0"