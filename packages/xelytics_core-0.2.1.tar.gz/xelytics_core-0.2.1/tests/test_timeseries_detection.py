"""
Tests for time series detection module.
"""
import pytest
pytestmark = pytest.mark.skip(reason="Tests deprecated v1 timeseries API")
import unittest
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import sys
import os
import warnings

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))


class TestTimeSeriesDetection(unittest.TestCase):
    """Test time series detection and characterization."""
    
    def setUp(self):
        """Set up test data."""
        # Suppress warnings during tests
        warnings.filterwarnings("ignore", category=FutureWarning)
        warnings.filterwarnings("ignore", category=UserWarning)
        
        # Create regular daily time series
        np.random.seed(42)
        dates = pd.date_range('2024-01-01', periods=100, freq='D')
        values = np.random.randn(100).cumsum() + 100  # Random walk with trend
        
        self.df_regular = pd.DataFrame({
            'date': dates,
            'value': values,
            'category': np.random.choice(['A', 'B', 'C'], 100)
        })
        
        # Create truly irregular time series with random gaps
        np.random.seed(42)
        dates_irregular = []
        current_date = pd.Timestamp('2024-01-01')
        for i in range(50):
            dates_irregular.append(current_date)
            # Truly random gaps between 1-10 days
            gap = np.random.randint(1, 11)
            current_date += pd.Timedelta(days=gap)
        
        self.df_irregular = pd.DataFrame({
            'timestamp': dates_irregular,
            'measurement': np.random.randn(len(dates_irregular))
        })
        
        # Create time series with clear gaps (missing consecutive days)
        np.random.seed(42)
        dates = pd.date_range('2024-01-01', periods=50, freq='D')
        # Remove blocks of dates: keep 10, remove 5, keep 10, remove 5, etc.
        mask = np.ones(50, dtype=bool)
        for i in range(10, 50, 15):
            mask[i:i+5] = False
        
        dates_with_gaps = dates[mask]
        self.df_with_gaps = pd.DataFrame({
            'dt': dates_with_gaps,
            'val': np.random.randn(len(dates_with_gaps))
        })
        
        # Create time series with missing values (NaNs in datetime column)
        dates_with_nulls = pd.date_range('2024-01-01', periods=30, freq='D').to_series()
        # Set random 10% to NaN
        null_mask = np.random.random(30) < 0.1
        dates_with_nulls[null_mask] = pd.NaT
        
        self.df_with_nulls = pd.DataFrame({
            'datetime': dates_with_nulls,
            'data': np.random.randn(30)
        })
    
    def tearDown(self):
        """Clean up after tests."""
        warnings.resetwarnings()
    
    def test_detector_initialization(self):
        """Test that detector initializes correctly."""
        from xelytics.timeseries import TimeSeriesDetector
        
        detector = TimeSeriesDetector(max_missing_ratio=0.2, min_observations=20)
        self.assertEqual(detector.max_missing_ratio, 0.2)
        self.assertEqual(detector.min_observations, 20)
        print("✓ Detector initialization works")
    
    def test_detect_time_series_columns(self):
        """Test detection of time series columns."""
        from xelytics.timeseries import detect_time_series_columns
        
        results = detect_time_series_columns(self.df_regular)
        
        # Should detect the 'date' column as time series
        date_results = [r for r in results if r.column_name == 'date']
        self.assertGreater(len(date_results), 0)
        
        if date_results:
            date_result = date_results[0]
            self.assertTrue(date_result.is_datetime)
            self.assertTrue(date_result.is_monotonic)
            self.assertEqual(date_result.frequency, 'D')  # Daily frequency
            self.assertTrue(date_result.is_time_series)
            print("✓ Regular time series detection works")
    
    def test_characterize_time_series(self):
        """Test characterization of time series."""
        from xelytics.timeseries import characterize_time_series
        
        # Test regular time series
        characteristics = characterize_time_series(
            self.df_regular,
            datetime_column='date',
            value_column='value'
        )
        
        self.assertEqual(characteristics.column_name, 'date')
        self.assertEqual(characteristics.frequency, 'D')
        self.assertEqual(characteristics.observation_count, 100)
        self.assertTrue(characteristics.is_regular)
        print("✓ Regular time series characterization works")

        # Test irregular time series - it should be irregular or have low regularity
        characteristics_irregular = characterize_time_series(
            self.df_irregular,
            datetime_column='timestamp'
        )
        
        self.assertEqual(characteristics_irregular.column_name, 'timestamp')
        # Irregular series should not be marked as regular
        # Note: Our detector might still find a frequency if there's a most common interval
        # But is_regular should be False for truly irregular series
        self.assertFalse(characteristics_irregular.is_regular)
        print("✓ Irregular time series detection works")
    
    def test_backward_compatible_detect(self):
        """Test backward compatible detect_time_series function."""
        from xelytics.timeseries import detect_time_series
        
        # Test with all columns
        ts_columns = detect_time_series(self.df_regular)
        self.assertIn('date', ts_columns)
        
        # Test with specific column
        ts_columns_specific = detect_time_series(self.df_regular, datetime_column='date')
        self.assertIn('date', ts_columns_specific)
        
        print("✓ Backward compatible detection works")
    
    def test_analyze_time_series(self):
        """Test analyze_time_series function."""
        from xelytics.timeseries import analyze_time_series
        
        result = analyze_time_series(
            self.df_regular,
            datetime_column='date',
            value_column='value'
        )
        
        self.assertTrue(result['success'])
        self.assertEqual(result['datetime_column'], 'date')
        self.assertEqual(result['value_column'], 'value')
        
        # Check characteristics
        characteristics = result['characteristics']
        self.assertEqual(characteristics['frequency'], 'D')
        self.assertEqual(characteristics['observation_count'], 100)
        self.assertTrue(characteristics['is_regular'])
        
        print("✓ Time series analysis function works")
    
    def test_datetime_conversion(self):
        """Test automatic datetime conversion."""
        from xelytics.timeseries import TimeSeriesDetector
        
        # Create DataFrame with string dates in various formats
        df_string_dates = pd.DataFrame({
            'date_iso': ['2024-01-01', '2024-01-02', '2024-01-03', '2024-01-04'],
            'date_slash': ['2024/01/01', '2024/01/02', '2024/01/03', '2024/01/04'],
            'date_us': ['01-01-2024', '01-02-2024', '01-03-2024', '01-04-2024'],
            'datetime_iso': ['2024-01-01 10:30:00', '2024-01-02 11:30:00', 
                            '2024-01-03 12:30:00', '2024-01-04 13:30:00'],
        })
        
        detector = TimeSeriesDetector()
        
        # Test each column
        for col in df_string_dates.columns:
            results = detector.detect(df_string_dates, [col])
            self.assertGreater(len(results), 0)
            if results:
                self.assertTrue(results[0].is_datetime, f"Column {col} should be detected as datetime")
        
        print("✓ Datetime conversion works for various formats")
    
    def test_missing_values_handling(self):
        """Test handling of missing values."""
        from xelytics.timeseries import TimeSeriesDetector
        
        detector = TimeSeriesDetector()
        
        # Test with clear gaps (missing blocks of dates)
        # Create dates with a missing week in the middle
        dates = pd.date_range('2024-01-01', periods=30, freq='D')
        # Remove days 10-17 (a full week)
        mask = ~((dates >= pd.Timestamp('2024-01-10')) & (dates <= pd.Timestamp('2024-01-17')))
        dates_with_gap = dates[mask]
        
        df_with_gap = pd.DataFrame({
            'date': dates_with_gap,
            'value': np.random.randn(len(dates_with_gap))
        })
        
        results_gaps = detector.detect(df_with_gap, ['date'])
        self.assertGreater(len(results_gaps), 0)
        if results_gaps:
            self.assertTrue(results_gaps[0].is_datetime)
            # Should detect this obvious gap
            self.assertTrue(results_gaps[0].has_gaps, 
                          f"Expected to detect gap. has_gaps={results_gaps[0].has_gaps}, gap_percentage={results_gaps[0].gap_percentage}")
        
        # Test with null values in datetime column (from setUp)
        results_nulls = detector.detect(self.df_with_nulls, ['datetime'])
        self.assertGreater(len(results_nulls), 0)
        if results_nulls:
            self.assertTrue(results_nulls[0].is_datetime)
            # Should have suggestions about missing values
            self.assertGreater(len(results_nulls[0].suggestions), 0)
    
    def test_frequency_inference(self):
        """Test frequency inference for different frequencies."""
        from xelytics.timeseries import TimeSeriesDetector
        
        detector = TimeSeriesDetector()
        
        # Test hourly data - use 'h' (lowercase)
        hourly_dates = pd.date_range('2024-01-01', periods=24, freq='h')
        df_hourly = pd.DataFrame({'timestamp': hourly_dates})
        
        results = detector.detect(df_hourly)
        self.assertGreater(len(results), 0)
        if results:
            # Note: pd.infer_freq might return 'H' but we convert to 'h'
            # Our detector should return 'h' for hourly
            self.assertEqual(results[0].frequency.lower(), 'h')
        
        # Test monthly data
        monthly_dates = pd.date_range('2024-01-01', periods=12, freq='MS')
        df_monthly = pd.DataFrame({'date': monthly_dates})
        
        results = detector.detect(df_monthly)
        self.assertGreater(len(results), 0)
        if results:
            self.assertEqual(results[0].frequency, 'MS')
        
        # Test weekly data
        weekly_dates = pd.date_range('2024-01-01', periods=10, freq='W-MON')
        df_weekly = pd.DataFrame({'week': weekly_dates})

        results = detector.detect(df_weekly)
        self.assertGreater(len(results), 0)
        if results:
            # Accept both 'W' and anchored versions like 'W-MON'
            self.assertTrue(results[0].frequency.startswith('W'))
    
    def test_trend_detection(self):
        """Test trend detection in time series."""
        from xelytics.timeseries import TimeSeriesDetector
        
        # Create data with clear upward trend
        dates = pd.date_range('2024-01-01', periods=50, freq='D')
        values = np.arange(50) * 2 + np.random.randn(50) * 5  # Strong upward trend
        
        df_trend = pd.DataFrame({
            'date': dates,
            'value': values
        })
        
        detector = TimeSeriesDetector()
        characteristics = detector.characterize(df_trend, 'date', 'value')
        
        self.assertTrue(characteristics.has_trend, "Should detect trend in data")
        
        # Create data with no trend (stationary)
        values_no_trend = np.random.randn(50)
        df_no_trend = pd.DataFrame({
            'date': dates,
            'value': values_no_trend
        })
        
        characteristics_no_trend = detector.characterize(df_no_trend, 'date', 'value')
        # Note: Random data might sometimes show trend by chance
        # We'll just test that the function runs without error
        
        print("✓ Trend detection works")
    
    def test_error_handling(self):
        """Test error handling for invalid inputs."""
        from xelytics.timeseries import characterize_time_series
        
        # Test with non-existent column
        with self.assertRaises(ValueError):
            characterize_time_series(self.df_regular, 'nonexistent_column')
        
        # Test with too few observations
        df_small = pd.DataFrame({
            'date': pd.date_range('2024-01-01', periods=5, freq='D'),
            'value': [1, 2, 3, 4, 5]
        })
        
        with self.assertRaises(ValueError):
            characterize_time_series(df_small, 'date', min_observations=10)
        
        # Test with non-datetime column
        df_non_datetime = pd.DataFrame({
            'text': ['a', 'b', 'c', 'd', 'e'],
            'numbers': [1, 2, 3, 4, 5]
        })
        
        with self.assertRaises(ValueError):
            characterize_time_series(df_non_datetime, 'text')
        
        print("✓ Error handling works")
    
        def test_gap_detection_accuracy(self):
            """Test accuracy of gap detection."""
            from xelytics.timeseries import TimeSeriesDetector
            
            # Create a time series with clear, large gaps
            # Create two separate date ranges with a gap in between
            dates1 = pd.date_range('2024-01-01', periods=5, freq='D')
            dates2 = pd.date_range('2024-01-20', periods=5, freq='D')  # 15-day gap
            all_dates = dates1.append(dates2)
            
            df_gaps = pd.DataFrame({
                'date': all_dates,
                'value': np.random.randn(len(all_dates))
            })
            
            detector = TimeSeriesDetector()
            results = detector.detect(df_gaps, ['date'])
            
            self.assertGreater(len(results), 0)
            if results:
                result = results[0]
                # Should detect gaps
                self.assertTrue(result.has_gaps, f"Expected gaps but got has_gaps={result.has_gaps}, gap_percentage={result.gap_percentage}")
                # Should have significant gap percentage
                self.assertGreater(result.gap_percentage, 0.3)
    
    def test_seasonality_detection(self):
        """Test seasonality detection."""
        from xelytics.timeseries import TimeSeriesDetector
        
        # Create data with weekly seasonality (7-day cycle)
        dates = pd.date_range('2024-01-01', periods=100, freq='D')
        # Weekly pattern: higher on weekdays, lower on weekends
        day_of_week = dates.dayofweek  # 0=Monday, 6=Sunday
        values = np.where(day_of_week < 5, 100, 50) + np.random.randn(100) * 10
        
        df_seasonal = pd.DataFrame({
            'date': dates,
            'value': values
        })
        
        detector = TimeSeriesDetector()
        characteristics = detector.characterize(df_seasonal, 'date', 'value')
        
        # Should detect seasonality with period 7
        self.assertTrue(characteristics.has_seasonality)
        self.assertEqual(characteristics.seasonality_period, 7)
        
        print("✓ Seasonality detection works")
    
    def test_stationarity_detection(self):
        """Test stationarity detection."""
        from xelytics.timeseries import TimeSeriesDetector
        
        # Create stationary data (white noise)
        dates = pd.date_range('2024-01-01', periods=100, freq='D')
        values_stationary = np.random.randn(100)
        
        df_stationary = pd.DataFrame({
            'date': dates,
            'value': values_stationary
        })
        
        # Create non-stationary data (random walk)
        values_non_stationary = np.random.randn(100).cumsum()
        
        df_non_stationary = pd.DataFrame({
            'date': dates,
            'value': values_non_stationary
        })
        
        detector = TimeSeriesDetector()
        
        # Test stationary data
        char_stationary = detector.characterize(df_stationary, 'date', 'value')
        # Random data should be stationary (most of the time)
        # Note: ADF test on random data should be stationary
        
        # Test non-stationary data
        char_non_stationary = detector.characterize(df_non_stationary, 'date', 'value')
        # Random walk should be non-stationary
        
        print("✓ Stationarity detection works")
    
    def test_prepare_time_series_data(self):
        """Test time series data preparation."""
        from xelytics.timeseries import prepare_time_series_data
        
        # Test basic preparation
        df_prepared = prepare_time_series_data(self.df_regular, 'date')
        
        # Should have datetime index
        self.assertIsInstance(df_prepared.index, pd.DatetimeIndex)
        
        # Should be sorted
        self.assertTrue(df_prepared.index.is_monotonic_increasing)
        
        # Test with frequency resampling
        df_resampled = prepare_time_series_data(
            self.df_regular, 
            'date',
            value_columns=['value'],
            freq='W'  # Weekly
        )
        
        # Should have fewer rows after weekly resampling
        self.assertLess(len(df_resampled), len(self.df_regular))
        
        # Should only have the specified columns
        self.assertIn('value', df_resampled.columns)
        
        print("✓ Time series data preparation works")


class TestTimeSeriesConfig(unittest.TestCase):
    """Test time series configuration."""
    
    def test_config_initialization(self):
        """Test configuration initialization."""
        from xelytics.config.timeseries_config import (
            TimeSeriesConfig, TimeSeriesModel, DecompositionMethod, AnomalyMethod
        )
        
        # Test default config
        config = TimeSeriesConfig()
        self.assertEqual(config.max_rows, 100000)
        self.assertEqual(config.default_forecast_model, TimeSeriesModel.AUTO)
        self.assertEqual(config.decomposition_method, DecompositionMethod.CLASSICAL)
        self.assertEqual(config.anomaly_method, AnomalyMethod.STATISTICAL)
        
        # Test custom config
        custom_config = TimeSeriesConfig(
            max_rows=50000,
            forecast_horizon=60,
            enable_parallel_processing=False
        )
        self.assertEqual(custom_config.max_rows, 50000)
        self.assertEqual(custom_config.forecast_horizon, 60)
        self.assertFalse(custom_config.enable_parallel_processing)
        
        print("✓ Configuration initialization works")
    
    def test_config_validation(self):
        """Test configuration validation."""
        from xelytics.config.timeseries_config import TimeSeriesConfig
        
        # Test invalid values
        with self.assertRaises(ValueError):
            TimeSeriesConfig(max_missing_ratio=1.5)  # Should be between 0 and 1
        
        with self.assertRaises(ValueError):
            TimeSeriesConfig(min_observations=0)  # Should be at least 2
        
        with self.assertRaises(ValueError):
            TimeSeriesConfig(forecast_horizon=0)  # Should be at least 1
        
        print("✓ Configuration validation works")
    
    def test_config_conversion(self):
        """Test configuration to/from dictionary conversion."""
        from xelytics.config.timeseries_config import TimeSeriesConfig, TimeSeriesModel
        
        config = TimeSeriesConfig(
            max_rows=50000,
            default_forecast_model=TimeSeriesModel.ARIMA,
            forecast_horizon=90
        )
        
        # Convert to dict
        config_dict = config.to_dict()
        self.assertIn('max_rows', config_dict)
        self.assertEqual(config_dict['max_rows'], 50000)
        self.assertEqual(config_dict['default_forecast_model'], 'arima')
        
        # Convert from dict
        new_config = TimeSeriesConfig.from_dict(config_dict)
        self.assertEqual(new_config.max_rows, 50000)
        self.assertEqual(new_config.default_forecast_model, TimeSeriesModel.ARIMA)
        
        print("✓ Configuration conversion works")
    
    def test_config_methods(self):
        """Test configuration methods."""
        from xelytics.config.timeseries_config import TimeSeriesConfig, TimeSeriesModel
        
        config = TimeSeriesConfig()
        
        # Test frequency display
        display_name = config.get_frequency_display_name('D')
        self.assertEqual(display_name, 'Day')
        
        # Test frequency allowance
        self.assertTrue(config.is_frequency_allowed('D'))
        self.assertTrue(config.is_frequency_allowed('h'))
        self.assertTrue(config.is_frequency_allowed('irregular'))
        
        # Test model selection order
        models = config.get_model_selection_order()
        self.assertGreater(len(models), 0)
        self.assertIn(TimeSeriesModel.ARIMA, models)
        
        # Test parallel processing decision
        should_parallel = config.should_use_parallel(n_series=3, n_models=2)
        # With hybrid strategy and multiple series/models, should use parallel
        self.assertTrue(should_parallel)
        
        print("✓ Configuration methods work")


class TestTimeSeriesIntegration(unittest.TestCase):
    """Test integration with the rest of xelytics."""
    
    def test_config_imports(self):
        """Test that time series config can be imported."""
        try:
            from xelytics.config.timeseries_config import (
                TimeSeriesConfig, DEFAULT_TIMESERIES_CONFIG,
                TimeSeriesModel, DecompositionMethod, AnomalyMethod
            )
            print("✓ Time series config imports work")
        except ImportError as e:
            self.fail(f"Failed to import time series config: {e}")
    
    def test_schema_compatibility(self):
        """Test compatibility with existing schemas."""
        from xelytics.schemas import AnalysisConfig
        
        # Create config with time series parameters
        config = AnalysisConfig(
            mode="automated",
            enable_time_series=True,
            datetime_column="date",
            forecast_periods=30,
            enable_clustering=False,  # Disable other v0.2.0 features for test
        )
        
        self.assertTrue(config.enable_time_series)
        self.assertEqual(config.datetime_column, "date")
        self.assertEqual(config.forecast_periods, 30)
        
        print("✓ Schema compatibility maintained")
    
    def test_end_to_end_detection(self):
        """Test end-to-end time series detection."""
        import pandas as pd
        import numpy as np
        
        # Create comprehensive test data
        dates = pd.date_range('2024-01-01', periods=365, freq='D')
        # Multiple time series with different characteristics
        df = pd.DataFrame({
            'date': dates,
            'sales': np.random.randn(365).cumsum() * 10 + 1000,  # Trend + noise
            'temperature': 20 + 10 * np.sin(2 * np.pi * np.arange(365) / 365) + np.random.randn(365),  # Seasonal
            'web_traffic': np.random.poisson(1000, 365),  # Count data
            'category': np.random.choice(['A', 'B', 'C'], 365)  # Non-time series
        })
        
        from xelytics.timeseries import (
            detect_time_series_columns,
            characterize_time_series,
            analyze_time_series,
            prepare_time_series_data
        )
        
        # Test detection
        results = detect_time_series_columns(df)
        time_series_cols = [r.column_name for r in results if r.is_time_series]
        self.assertIn('date', time_series_cols)
        
        # Test characterization
        char = characterize_time_series(df, 'date', 'sales')
        self.assertEqual(char.column_name, 'date')
        self.assertEqual(char.frequency, 'D')
        
        # Test analysis
        analysis = analyze_time_series(df, 'date', 'sales')
        self.assertTrue(analysis['success'])
        
        # Test preparation
        prepared = prepare_time_series_data(df, 'date', ['sales', 'temperature'])
        self.assertEqual(len(prepared), 365)
        
        print("✓ End-to-end time series detection works")


def run_timeseries_tests():
    """Run all time series tests."""
    loader = unittest.TestLoader()
    
    # Load test suites
    detection_suite = loader.loadTestsFromTestCase(TestTimeSeriesDetection)
    config_suite = loader.loadTestsFromTestCase(TestTimeSeriesConfig)
    integration_suite = loader.loadTestsFromTestCase(TestTimeSeriesIntegration)
    
    # Combine suites
    suite = unittest.TestSuite([detection_suite, config_suite, integration_suite])
    
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    print("\n" + "="*70)
    print("MODULE 2.1: TIME SERIES DETECTION - COMPREHENSIVE TEST RESULTS")
    print("="*70)
    
    # Summary
    total = result.testsRun
    passed = total - len(result.failures) - len(result.errors)
    
    print(f"\n📊 TEST SUMMARY:")
    print(f"  Total Tests: {total}")
    print(f"  Passed: {passed}")
    print(f"  Failed: {len(result.failures)}")
    print(f"  Errors: {len(result.errors)}")
    
    if result.wasSuccessful():
        print("\n✅ ALL TESTS PASSED!")
        print("✅ Phase 2.1 Core Infrastructure is READY")
        print("✅ Time series detection is working correctly")
        print("✅ Configuration system is properly set up")
        print("✅ Backward compatibility is maintained")
        print("\n🎯 Ready for Phase 2.2: Advanced Time Series Analysis")
    else:
        print("\n❌ Some tests failed. Please check the output above.")
        if result.failures:
            print("\nFailed tests:")
            for test, traceback in result.failures:
                print(f"  - {test}")
        if result.errors:
            print("\nErrors:")
            for test, traceback in result.errors:
                print(f"  - {test}")
    
    print("="*70)
    
    return result.wasSuccessful()


if __name__ == '__main__':
    success = run_timeseries_tests()
    sys.exit(0 if success else 1)