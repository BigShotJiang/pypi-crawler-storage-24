"""
Tests for xelytics clustering module.
Covers: kmeans, dbscan, hierarchical, profiler, analyze_clusters
"""

import pytest
import numpy as np
import pandas as pd
from sklearn.datasets import make_blobs, make_moons


# ===========================================================================
# Fixtures
# ===========================================================================

@pytest.fixture
def blobs_df():
    """Well-separated 3-cluster dataset — ideal for all algorithms."""
    X, _ = make_blobs(n_samples=150, centers=3, cluster_std=0.6, random_state=42)
    return pd.DataFrame(X, columns=["x", "y"])


@pytest.fixture
def blobs_df_large():
    """Larger well-separated dataset for performance/profiling tests."""
    X, _ = make_blobs(n_samples=300, centers=4, cluster_std=0.8, random_state=0)
    return pd.DataFrame(X, columns=["a", "b"])


@pytest.fixture
def df_with_nan(blobs_df):
    """Dataset with some NaN values."""
    df = blobs_df.copy()
    df.loc[[0, 5, 10], "x"] = np.nan
    return df


@pytest.fixture
def df_with_categoricals(blobs_df):
    """Dataset with a categorical column mixed in."""
    df = blobs_df.copy()
    df["category"] = np.random.choice(["A", "B", "C"], size=len(df))
    return df


@pytest.fixture
def tiny_df():
    """Minimal 3-row DataFrame — edge case."""
    return pd.DataFrame({"x": [1.0, 2.0, 3.0], "y": [1.0, 2.0, 3.0]})


@pytest.fixture
def single_row_df():
    """Single-row DataFrame — should raise."""
    return pd.DataFrame({"x": [1.0], "y": [2.0]})


# ===========================================================================
# K-Means Tests
# ===========================================================================

class TestKMeansClusterer:

    def test_basic_fit(self, blobs_df):
        from xelytics.clustering.kmeans import KMeansClusterer
        X = blobs_df.values
        clusterer = KMeansClusterer(max_clusters=6)
        result = clusterer.fit(X, n_clusters=3)

        assert result.n_clusters == 3
        assert len(result.labels) == len(blobs_df)
        assert result.silhouette_score > 0
        assert result.inertia > 0
        assert result.centroids.shape == (3, 2)

    def test_auto_k_selection_elbow(self, blobs_df):
        from xelytics.clustering.kmeans import KMeansClusterer
        X = blobs_df.values
        clusterer = KMeansClusterer(max_clusters=8)
        k = clusterer.find_optimal_k(X, method="elbow")
        assert 2 <= k <= 8

    def test_auto_k_selection_silhouette(self, blobs_df):
        from xelytics.clustering.kmeans import KMeansClusterer
        X = blobs_df.values
        clusterer = KMeansClusterer(max_clusters=6)
        k = clusterer.find_optimal_k(X, method="silhouette")
        assert 2 <= k <= 6

    def test_auto_k_selection_gap(self, blobs_df):
        from xelytics.clustering.kmeans import KMeansClusterer
        X = blobs_df.values
        clusterer = KMeansClusterer(max_clusters=5)
        k = clusterer.find_optimal_k(X, method="gap")
        assert 2 <= k <= 5

    def test_invalid_method_raises(self, blobs_df):
        from xelytics.clustering.kmeans import KMeansClusterer
        clusterer = KMeansClusterer()
        X = blobs_df.values
        with pytest.raises(ValueError, match="Unknown method"):
            clusterer.find_optimal_k(X, method="invalid_method")

    def test_single_sample_raises(self):
        from xelytics.clustering.kmeans import KMeansClusterer
        clusterer = KMeansClusterer()
        with pytest.raises(ValueError, match="at least 2 samples"):
            clusterer.fit(np.array([[1.0, 2.0]]))

    def test_fit_predict_returns_labels(self, blobs_df):
        from xelytics.clustering.kmeans import KMeansClusterer
        X = blobs_df.values
        clusterer = KMeansClusterer()
        labels = clusterer.fit_predict(X, n_clusters=3)
        assert labels.shape == (len(blobs_df),)
        assert len(np.unique(labels)) == 3

    def test_normalize_false(self, blobs_df):
        from xelytics.clustering.kmeans import KMeansClusterer
        X = blobs_df.values
        clusterer = KMeansClusterer(normalize=False)
        result = clusterer.fit(X, n_clusters=3)
        assert result.n_clusters == 3

    def test_cluster_sizes_sum_to_total(self, blobs_df):
        from xelytics.clustering.kmeans import KMeansClusterer
        X = blobs_df.values
        result = KMeansClusterer().fit(X, n_clusters=3)
        assert sum(result.cluster_sizes.values()) == len(blobs_df)

    def test_feature_names_assigned(self, blobs_df):
        from xelytics.clustering.kmeans import KMeansClusterer
        X = blobs_df.values
        result = KMeansClusterer().fit(X, n_clusters=3, feature_names=["x", "y"])
        assert result.feature_names == ["x", "y"]

    def test_default_feature_names(self, blobs_df):
        from xelytics.clustering.kmeans import KMeansClusterer
        X = blobs_df.values
        result = KMeansClusterer().fit(X, n_clusters=3)
        assert result.feature_names == ["feature_0", "feature_1"]


class TestClusterKmeans:

    def test_basic(self, blobs_df):
        from xelytics.clustering.kmeans import cluster_kmeans
        result, df_out = cluster_kmeans(blobs_df, n_clusters=3)
        assert result.n_clusters == 3
        assert "cluster" in df_out.columns
        assert len(df_out) == len(blobs_df)

    def test_auto_feature_selection(self, df_with_categoricals):
        from xelytics.clustering.kmeans import cluster_kmeans
        result, df_out = cluster_kmeans(df_with_categoricals, n_clusters=3)
        assert "cluster" in df_out.columns

    def test_explicit_feature_columns(self, blobs_df):
        from xelytics.clustering.kmeans import cluster_kmeans
        result, df_out = cluster_kmeans(blobs_df, feature_columns=["x"], n_clusters=2)
        assert result.n_clusters == 2

    def test_nan_rows_dropped(self, df_with_nan):
        from xelytics.clustering.kmeans import cluster_kmeans
        result, df_out = cluster_kmeans(df_with_nan, n_clusters=3)
        assert df_out["cluster"].isna().sum() == 0
        assert len(df_out) < len(df_with_nan)

    def test_no_numeric_raises(self):
        from xelytics.clustering.kmeans import cluster_kmeans
        df = pd.DataFrame({"cat": ["a", "b", "c"]})
        with pytest.raises(ValueError, match="No numeric features"):
            cluster_kmeans(df)

    def test_insufficient_samples_raises(self, single_row_df):
        from xelytics.clustering.kmeans import cluster_kmeans
        with pytest.raises(ValueError):
            cluster_kmeans(single_row_df)


# ===========================================================================
# DBSCAN Tests
# ===========================================================================

class TestDBSCANClusterer:

    def test_basic_fit(self, blobs_df):
        from xelytics.clustering.dbscan import DBSCANClusterer
        X = blobs_df.values
        clusterer = DBSCANClusterer(eps=0.8, min_samples=5)
        result = clusterer.fit(X)
        assert result.n_clusters >= 1
        assert len(result.labels) == len(blobs_df)
        assert 0.0 <= result.noise_ratio <= 1.0

    def test_auto_eps_estimation(self, blobs_df):
        from xelytics.clustering.dbscan import DBSCANClusterer
        X = blobs_df.values
        clusterer = DBSCANClusterer()
        eps = clusterer.estimate_eps(X)
        assert eps > 0

    def test_auto_min_samples_estimation(self, blobs_df):
        from xelytics.clustering.dbscan import DBSCANClusterer
        X = blobs_df.values
        clusterer = DBSCANClusterer()
        ms = clusterer._estimate_min_samples(X)
        assert ms >= 3

    def test_noise_points_labeled_minus_one(self, blobs_df):
        from xelytics.clustering.dbscan import DBSCANClusterer
        # Very tight eps forces many noise points
        X = blobs_df.values
        clusterer = DBSCANClusterer(eps=0.01, min_samples=10)
        result = clusterer.fit(X)
        assert -1 in result.labels or result.n_clusters >= 1

    def test_single_sample_raises(self):
        from xelytics.clustering.dbscan import DBSCANClusterer
        clusterer = DBSCANClusterer()
        with pytest.raises(ValueError, match="at least 2 samples"):
            clusterer.fit(np.array([[1.0, 2.0]]))

    def test_fit_predict_returns_labels(self, blobs_df):
        from xelytics.clustering.dbscan import DBSCANClusterer
        X = blobs_df.values
        labels = DBSCANClusterer(eps=0.8, min_samples=5).fit_predict(X)
        assert labels.shape == (len(blobs_df),)

    def test_cluster_sizes_consistent(self, blobs_df):
        from xelytics.clustering.dbscan import DBSCANClusterer
        X = blobs_df.values
        result = DBSCANClusterer(eps=0.8, min_samples=5).fit(X)
        total = sum(result.cluster_sizes.values())
        assert total == len(blobs_df)

    def test_silhouette_none_when_one_cluster(self):
        from xelytics.clustering.dbscan import DBSCANClusterer
        # Tight cluster → likely 1 cluster, silhouette undefined
        X = np.random.randn(50, 2) * 0.01  # very tight blob
        result = DBSCANClusterer(eps=1.0, min_samples=3).fit(X)
        # Either silhouette is None (1 cluster) or a valid float
        assert result.silhouette_score is None or isinstance(result.silhouette_score, float)


class TestClusterDbscan:

    def test_basic(self, blobs_df):
        from xelytics.clustering.dbscan import cluster_dbscan
        result, df_out = cluster_dbscan(blobs_df, eps=0.8, min_samples=5)
        assert "cluster" in df_out.columns
        assert "is_noise" in df_out.columns

    def test_nan_rows_dropped(self, df_with_nan):
        from xelytics.clustering.dbscan import cluster_dbscan
        result, df_out = cluster_dbscan(df_with_nan, eps=0.8, min_samples=5)
        assert len(df_out) < len(df_with_nan)

    def test_no_numeric_raises(self):
        from xelytics.clustering.dbscan import cluster_dbscan
        df = pd.DataFrame({"cat": ["a", "b", "c"]})
        with pytest.raises(ValueError, match="No numeric features"):
            cluster_dbscan(df)

    def test_is_noise_column_bool(self, blobs_df):
        from xelytics.clustering.dbscan import cluster_dbscan
        _, df_out = cluster_dbscan(blobs_df, eps=0.8, min_samples=5)
        assert df_out["is_noise"].dtype == bool


class TestFindOptimalDbscanParams:

    def test_returns_tuple(self, blobs_df):
        from xelytics.clustering.dbscan import find_optimal_dbscan_params
        X = blobs_df.values
        eps, min_s = find_optimal_dbscan_params(X)
        assert isinstance(eps, float)
        assert isinstance(min_s, int)
        assert eps > 0
        assert min_s >= 1

    def test_custom_ranges(self, blobs_df):
        from xelytics.clustering.dbscan import find_optimal_dbscan_params
        X = blobs_df.values
        eps, min_s = find_optimal_dbscan_params(
            X,
            eps_range=[0.3, 0.5, 0.8],
            min_samples_range=[3, 5]
        )
        assert eps in [0.3, 0.5, 0.8]
        assert min_s in [3, 5]


# ===========================================================================
# Hierarchical Tests
# ===========================================================================

class TestHierarchicalClusterer:

    def test_basic_fit(self, blobs_df):
        from xelytics.clustering.hierarchical import HierarchicalClusterer
        X = blobs_df.values
        result = HierarchicalClusterer(n_clusters=3).fit(X)
        assert result.n_clusters == 3
        assert len(result.labels) == len(blobs_df)
        assert result.silhouette_score > 0

    def test_auto_cluster_estimation(self, blobs_df):
        from xelytics.clustering.hierarchical import HierarchicalClusterer
        X = blobs_df.values
        clusterer = HierarchicalClusterer()
        linkage_matrix, _ = clusterer.compute_linkage(X)
        n = clusterer.estimate_n_clusters(linkage_matrix)
        assert n >= 2

    def test_estimate_n_clusters_distance_threshold(self, blobs_df):
        from xelytics.clustering.hierarchical import HierarchicalClusterer
        X = blobs_df.values
        clusterer = HierarchicalClusterer()
        linkage_matrix, _ = clusterer.compute_linkage(X)
        n = clusterer.estimate_n_clusters(linkage_matrix, method="distance_threshold")
        assert n >= 2

    def test_estimate_n_clusters_unknown_method(self, blobs_df):
        from xelytics.clustering.hierarchical import HierarchicalClusterer
        X = blobs_df.values
        clusterer = HierarchicalClusterer()
        linkage_matrix, _ = clusterer.compute_linkage(X)
        n = clusterer.estimate_n_clusters(linkage_matrix, method="unknown")
        assert n == 2  # fallback default

    def test_linkage_methods(self, blobs_df):
        from xelytics.clustering.hierarchical import HierarchicalClusterer
        X = blobs_df.values
        for method in ["ward", "complete", "average", "single"]:
            clusterer = HierarchicalClusterer(linkage_method=method, n_clusters=3)
            result = clusterer.fit(X)
            assert result.n_clusters == 3
            assert result.linkage_method == method

    def test_dendrogram_data_generated(self, blobs_df):
        from xelytics.clustering.hierarchical import HierarchicalClusterer
        X = blobs_df.values
        result = HierarchicalClusterer(n_clusters=3).fit(X, generate_dendrogram_data=True)
        assert result.dendrogram_data is not None
        assert "icoord" in result.dendrogram_data

    def test_dendrogram_data_none_by_default(self, blobs_df):
        from xelytics.clustering.hierarchical import HierarchicalClusterer
        X = blobs_df.values
        result = HierarchicalClusterer(n_clusters=3).fit(X)
        assert result.dendrogram_data is None

    def test_single_sample_raises(self):
        from xelytics.clustering.hierarchical import HierarchicalClusterer
        with pytest.raises(ValueError, match="at least 2 samples"):
            HierarchicalClusterer().fit(np.array([[1.0, 2.0]]))

    def test_fit_predict_returns_labels(self, blobs_df):
        from xelytics.clustering.hierarchical import HierarchicalClusterer
        X = blobs_df.values
        labels = HierarchicalClusterer(n_clusters=3).fit_predict(X)
        assert labels.shape == (len(blobs_df),)

    def test_cluster_sizes_sum(self, blobs_df):
        from xelytics.clustering.hierarchical import HierarchicalClusterer
        X = blobs_df.values
        result = HierarchicalClusterer(n_clusters=3).fit(X)
        assert sum(result.cluster_sizes.values()) == len(blobs_df)

    def test_normalize_false(self, blobs_df):
        from xelytics.clustering.hierarchical import HierarchicalClusterer
        X = blobs_df.values
        result = HierarchicalClusterer(n_clusters=3, normalize=False).fit(X)
        assert result.n_clusters == 3


class TestClusterHierarchical:

    def test_basic(self, blobs_df):
        from xelytics.clustering.hierarchical import cluster_hierarchical
        result, df_out = cluster_hierarchical(blobs_df, n_clusters=3)
        assert "cluster" in df_out.columns
        assert result.n_clusters == 3

    def test_nan_rows_dropped(self, df_with_nan):
        from xelytics.clustering.hierarchical import cluster_hierarchical
        result, df_out = cluster_hierarchical(df_with_nan, n_clusters=3)
        assert len(df_out) < len(df_with_nan)

    def test_no_numeric_raises(self):
        from xelytics.clustering.hierarchical import cluster_hierarchical
        df = pd.DataFrame({"cat": ["a", "b", "c"]})
        with pytest.raises(ValueError, match="No numeric features"):
            cluster_hierarchical(df)

    def test_with_dendrogram(self, blobs_df):
        from xelytics.clustering.hierarchical import cluster_hierarchical
        result, df_out = cluster_hierarchical(blobs_df, n_clusters=3, generate_dendrogram=True)
        assert result.dendrogram_data is not None


class TestPlotDendrogramSimple:

    def test_returns_dict(self, blobs_df):
        from xelytics.clustering.hierarchical import HierarchicalClusterer, plot_dendrogram_simple
        X = blobs_df.values
        clusterer = HierarchicalClusterer()
        linkage_matrix, _ = clusterer.compute_linkage(X)
        data = plot_dendrogram_simple(linkage_matrix)
        assert isinstance(data, dict)
        assert "icoord" in data


# ===========================================================================
# Profiler Tests
# ===========================================================================

class TestClusterProfiler:

    def _get_labeled_df(self, blobs_df):
        from xelytics.clustering.kmeans import cluster_kmeans
        result, df_out = cluster_kmeans(blobs_df, n_clusters=3)
        return df_out, result.labels

    def test_profile_single_cluster(self, blobs_df):
        from xelytics.clustering.profiler import ClusterProfiler
        df_out, labels = self._get_labeled_df(blobs_df)
        profiler = ClusterProfiler()
        profile = profiler.profile_cluster(df_out[["x", "y"]], labels, cluster_id=0)
        assert profile.cluster_id == 0
        assert profile.size > 0
        assert 0 < profile.percentage <= 100
        assert len(profile.feature_profiles) == 2

    def test_profile_all_clusters(self, blobs_df):
        from xelytics.clustering.profiler import ClusterProfiler
        df_out, labels = self._get_labeled_df(blobs_df)
        profiler = ClusterProfiler()
        profiles = profiler.profile_all_clusters(df_out[["x", "y"]], labels)
        assert len(profiles) == 3
        total = sum(p.size for p in profiles)
        assert total == len(df_out)

    def test_description_is_string(self, blobs_df):
        from xelytics.clustering.profiler import ClusterProfiler
        df_out, labels = self._get_labeled_df(blobs_df)
        profiler = ClusterProfiler()
        profile = profiler.profile_cluster(df_out[["x", "y"]], labels, cluster_id=0)
        assert isinstance(profile.description, str)
        assert "Cluster 0" in profile.description

    def test_distinguishing_features_returned(self, blobs_df):
        from xelytics.clustering.profiler import ClusterProfiler
        df_out, labels = self._get_labeled_df(blobs_df)
        profiler = ClusterProfiler(top_n_features=2)
        profile = profiler.profile_cluster(df_out[["x", "y"]], labels, cluster_id=0)
        assert len(profile.distinguishing_features) <= 2
        for feat, score in profile.distinguishing_features:
            assert isinstance(feat, str)
            assert isinstance(score, float)

    def test_empty_cluster_raises(self, blobs_df):
        from xelytics.clustering.profiler import ClusterProfiler
        labels = np.zeros(len(blobs_df), dtype=int)  # all in cluster 0
        profiler = ClusterProfiler()
        with pytest.raises(ValueError, match="has no samples"):
            profiler.profile_cluster(blobs_df, labels, cluster_id=99)

    def test_compare_clusters(self, blobs_df):
        from xelytics.clustering.profiler import ClusterProfiler
        df_out, labels = self._get_labeled_df(blobs_df)
        profiler = ClusterProfiler()
        profiles = profiler.profile_all_clusters(df_out[["x", "y"]], labels)
        comparison = profiler.compare_clusters(profiles)
        assert comparison["n_clusters"] == 3
        assert "size_stats" in comparison
        assert len(comparison["cluster_summaries"]) == 3

    def test_compare_clusters_single(self, blobs_df):
        from xelytics.clustering.profiler import ClusterProfiler
        df_out, labels = self._get_labeled_df(blobs_df)
        profiler = ClusterProfiler()
        profiles = profiler.profile_all_clusters(df_out[["x", "y"]], labels)
        result = profiler.compare_clusters(profiles[:1])
        assert "comparison" in result  # fallback message

    def test_noise_label_skipped(self, blobs_df):
        from xelytics.clustering.profiler import ClusterProfiler
        labels = np.array([-1] * 50 + [0] * 50 + [1] * 50)
        df = blobs_df.copy()
        profiler = ClusterProfiler()
        profiles = profiler.profile_all_clusters(df, labels)
        cluster_ids = [p.cluster_id for p in profiles]
        assert -1 not in cluster_ids

    def test_with_categorical_columns(self, df_with_categoricals):
        from xelytics.clustering.profiler import ClusterProfiler
        from xelytics.clustering.kmeans import cluster_kmeans
        _, df_out = cluster_kmeans(df_with_categoricals, feature_columns=["x", "y"], n_clusters=3)
        labels = df_out["cluster"].values
        profiler = ClusterProfiler()
        profiles = profiler.profile_all_clusters(df_out[["x", "y", "category"]], labels)
        assert len(profiles) == 3


class TestProfileClustersFunction:

    def test_high_level_profile(self, blobs_df):
        from xelytics.clustering.profiler import profile_clusters
        from xelytics.clustering.kmeans import cluster_kmeans
        _, df_out = cluster_kmeans(blobs_df, n_clusters=3)
        labels = df_out["cluster"].values
        profiles = profile_clusters(df_out[["x", "y"]], labels, top_n_features=2)
        assert len(profiles) == 3


# ===========================================================================
# analyze_clusters (Top-level __init__.py) Tests
# ===========================================================================

class TestAnalyzeClusters:

    def test_kmeans_algorithm(self, blobs_df):
        from xelytics.clustering import analyze_clusters
        results = analyze_clusters(blobs_df, algorithm="kmeans", max_clusters=5)
        assert len(results) > 0
        for r in results:
            assert r.algorithm.value == "kmeans"
            assert r.size > 0

    def test_dbscan_algorithm(self, blobs_df):
        from xelytics.clustering import analyze_clusters
        results = analyze_clusters(blobs_df, algorithm="dbscan")
        # DBSCAN may find 0 clusters on bad params, but should not crash
        assert isinstance(results, list)

    def test_hierarchical_algorithm(self, blobs_df):
        from xelytics.clustering import analyze_clusters
        results = analyze_clusters(blobs_df, algorithm="hierarchical", max_clusters=4)
        assert len(results) > 0
        for r in results:
            assert r.algorithm.value == "hierarchical"

    def test_auto_algorithm(self, blobs_df):
        from xelytics.clustering import analyze_clusters
        results = analyze_clusters(blobs_df, algorithm="auto", max_clusters=5)
        assert isinstance(results, list)
        if results:
            assert results[0].size > 0

    def test_invalid_algorithm_raises(self, blobs_df):
        from xelytics.clustering import analyze_clusters
        with pytest.raises(ValueError, match="Unknown clustering algorithm"):
            analyze_clusters(blobs_df, algorithm="banana")

    def test_cluster_result_fields(self, blobs_df):
        from xelytics.clustering import analyze_clusters
        results = analyze_clusters(blobs_df, algorithm="kmeans", max_clusters=4)
        for r in results:
            assert hasattr(r, "cluster_id")
            assert hasattr(r, "algorithm")
            assert hasattr(r, "size")
            assert hasattr(r, "centroid")
            assert hasattr(r, "profile")
            assert hasattr(r, "silhouette_score")
            assert hasattr(r, "members")

    def test_no_noise_in_results(self, blobs_df):
        from xelytics.clustering import analyze_clusters
        results = analyze_clusters(blobs_df, algorithm="kmeans", max_clusters=4)
        cluster_ids = [r.cluster_id for r in results]
        assert -1 not in cluster_ids

    def test_with_explicit_features(self, df_with_categoricals):
        from xelytics.clustering import analyze_clusters
        results = analyze_clusters(
            df_with_categoricals,
            algorithm="kmeans",
            features=["x", "y"],
            max_clusters=3
        )
        assert len(results) > 0

    def test_sizes_sum_to_dataset(self, blobs_df):
        from xelytics.clustering import analyze_clusters
        results = analyze_clusters(blobs_df, algorithm="kmeans", max_clusters=3)
        total = sum(r.size for r in results)
        assert total == len(blobs_df)

    def test_all_members_valid_indices(self, blobs_df):
        from xelytics.clustering import analyze_clusters
        results = analyze_clusters(blobs_df, algorithm="kmeans", max_clusters=3)
        all_members = [idx for r in results for idx in r.members]
        assert all(idx in blobs_df.index for idx in all_members)