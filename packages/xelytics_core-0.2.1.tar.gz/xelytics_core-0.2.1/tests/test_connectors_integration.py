"""Integration tests for all data connectors."""

import os
import pytest
import pandas as pd
from xelytics.connectors import connect_to_source


# Helper to check if a connector's module can be imported (i.e., dependencies installed)
def _check_dependency(source_type):
    """Raise SkipTest if required dependency is missing."""
    if source_type in ("postgresql", "postgres"):
        pytest.importorskip("sqlalchemy")
        pytest.importorskip("psycopg2")
    elif source_type in ("mysql", "mariadb"):
        pytest.importorskip("pymysql")
    elif source_type == "sqlite":
        pytest.importorskip("sqlalchemy")  # sqlite is built-in but sqlalchemy is needed
    elif source_type == "snowflake":
        pytest.importorskip("snowflake.connector")
    elif source_type == "bigquery":
        pytest.importorskip("google.cloud.bigquery")
    elif source_type in ("s3", "aws"):
        pytest.importorskip("boto3")
    elif source_type in ("azureblob", "azure_blob"):
        pytest.importorskip("azure.storage.blob")
    elif source_type in ("gcs", "google_cloud_storage"):
        pytest.importorskip("google.cloud.storage")
    # file connector has no extra dependencies


@pytest.mark.parametrize("source_type", [
    "postgresql", "mysql", "sqlite", "snowflake", "bigquery",
    "s3", "azureblob", "gcs", "file"
])
def test_connector_creation(source_type):
    """Test that each connector can be created via factory."""
    _check_dependency(source_type)  # skip if dependencies missing
    connector = connect_to_source(source_type, **{})
    assert connector is not None
    assert hasattr(connector, "connect")
    assert hasattr(connector, "disconnect")
    assert hasattr(connector, "query")


@pytest.mark.parametrize("source_type,env_prefix", [
    ("postgresql", "PG"),
    ("mysql", "MYSQL"),
    ("sqlite", "SQLITE"),
    ("snowflake", "SNOWFLAKE"),
    ("bigquery", "BQ"),
    ("s3", "S3"),
    ("azureblob", "AZURE"),
    ("gcs", "GCS"),
    ("file", "FILE"),
])
def test_live_connection(source_type, env_prefix):
    """
    Attempt a live connection using credentials from environment variables.
    If required env vars are missing, the test is skipped.
    """
    # Check dependencies first
    _check_dependency(source_type)

    # Build config dict from environment variables with prefix
    config = {}
    prefix = f"XELYTICS_TEST_{env_prefix}_"
    for key, value in os.environ.items():
        if key.startswith(prefix):
            config[key[len(prefix):].lower()] = value

    # Special handling for SQLite: database path
    if source_type == "sqlite":
        if "database" not in config:
            pytest.skip("SQLITE_DATABASE not set")
    elif source_type == "file":
        if "path" not in config:
            pytest.skip("FILE_PATH not set")
    else:
        # For others, require at least one config parameter
        if not config:
            pytest.skip(f"No {prefix}* environment variables set")

    # Create connector
    connector = connect_to_source(source_type, **config)

    # Connect
    assert connector.connect() is True
    assert connector.connected is True

    # Run a simple query
    if source_type in ("postgresql", "mysql", "sqlite", "snowflake", "bigquery"):
        # SQL databases
        df = connector.query("SELECT 1 as test")
        assert isinstance(df, pd.DataFrame)
        assert df.shape[0] == 1
    elif source_type in ("s3", "azureblob", "gcs"):
        # Cloud storage – query is file path
        # Expect a file path like "bucket/path/file.csv"
        if "test_file" in config:
            df = connector.query(config["test_file"])
            assert isinstance(df, pd.DataFrame)
    elif source_type == "file":
        # Local file
        df = connector.query(config["path"])
        assert isinstance(df, pd.DataFrame)

    # Disconnect
    assert connector.disconnect() is True
    assert connector.connected is False