"""Performance benchmarks for xelytics-core."""

import pytest
import pandas as pd
import numpy as np
from xelytics import analyze, AnalysisConfig


@pytest.fixture
def small_dataset():
    """10K rows, 10 columns (5 numeric, 5 categorical)."""
    np.random.seed(42)
    n = 10000
    df = pd.DataFrame({
        f"num_{i}": np.random.randn(n) for i in range(5)
    })
    for i in range(5):
        df[f"cat_{i}"] = np.random.choice(['A', 'B', 'C', 'D'], n)
    return df


@pytest.fixture
def medium_dataset():
    """100K rows, 15 columns (8 numeric, 7 categorical)."""
    np.random.seed(42)
    n = 100000
    df = pd.DataFrame({
        f"num_{i}": np.random.randn(n) for i in range(8)
    })
    for i in range(7):
        df[f"cat_{i}"] = np.random.choice(['A', 'B', 'C', 'D', 'E'], n)
    return df


@pytest.fixture
def large_dataset():
    """1M rows, 20 columns (12 numeric, 8 categorical)."""
    np.random.seed(42)
    n = 1_000_000
    df = pd.DataFrame({
        f"num_{i}": np.random.randn(n) for i in range(12)
    })
    for i in range(8):
        df[f"cat_{i}"] = np.random.choice(['A', 'B', 'C', 'D', 'E', 'F'], n)
    return df


def test_small_dataset_performance(benchmark, small_dataset):
    """Benchmark analysis on 10K rows."""
    config = AnalysisConfig(
        mode="automated",
        enable_llm_insights=False,
        max_visualizations=5,
    )
    result = benchmark(analyze, data=small_dataset, config=config)
    assert result is not None


def test_medium_dataset_performance(benchmark, medium_dataset):
    """Benchmark analysis on 100K rows."""
    config = AnalysisConfig(
        mode="automated",
        enable_llm_insights=False,
        max_visualizations=5,
    )
    result = benchmark(analyze, data=medium_dataset, config=config)
    assert result is not None


def test_large_dataset_sampled(benchmark, large_dataset):
    """Benchmark analysis on 1M rows with auto-sampling."""
    config = AnalysisConfig(
        mode="automated",
        enable_llm_insights=False,
        max_visualizations=5,
        sampling_strategy="auto",
        max_rows=50000,
    )
    result = benchmark(analyze, data=large_dataset, config=config)
    assert result is not None


@pytest.mark.skip(reason="Parallel vs sequential test postponed to next version")
def test_parallel_vs_sequential(benchmark, medium_dataset):
    """Compare parallel vs sequential execution."""
    config_seq = AnalysisConfig(
        mode="automated",
        enable_llm_insights=False,
        parallel_execution=False,
        enable_time_series=True,
        enable_clustering=True,
    )
    config_par = AnalysisConfig(
        mode="automated",
        enable_llm_insights=False,
        parallel_execution=True,
        max_workers=4,
        enable_time_series=True,
        enable_clustering=True,
    )

    result_seq = benchmark.pedantic(
        analyze,
        args=(medium_dataset,),
        kwargs={"config": config_seq},
        rounds=3,
        warmup_rounds=1,
    )

    result_par = benchmark.pedantic(
        analyze,
        args=(medium_dataset,),
        kwargs={"config": config_par},
        rounds=3,
        warmup_rounds=1,
    )

    assert result_seq is not None and result_par is not None