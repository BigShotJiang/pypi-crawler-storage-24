"""
Tests for time series forecasting module.
"""

import unittest
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import sys
import os
import warnings
import tempfile
import shutil

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))


class TestTimeSeriesForecasting(unittest.TestCase):
    """Test time series forecasting methods."""
    
    def setUp(self):
        """Set up test data."""
        warnings.filterwarnings("ignore", category=FutureWarning)
        warnings.filterwarnings("ignore", category=UserWarning)
        warnings.filterwarnings("ignore", category=RuntimeWarning)
        
        # Create test time series
        np.random.seed(42)
        dates = pd.date_range('2024-01-01', periods=100, freq='D')
        
        # Create synthetic data with trend and seasonality
        trend = np.linspace(0, 10, 100)
        seasonal = 5 * np.sin(2 * np.pi * np.arange(100) / 100 * 7)  # Weekly seasonality
        noise = np.random.normal(0, 1, 100)
        
        # Additive model
        self.additive_series = pd.Series(
            trend + seasonal + noise,
            index=dates,
            name='test_series'
        )
        
        # Multiplicative model (must be positive)
        multiplicative_series = trend * (1 + 0.2 * np.sin(2 * np.pi * np.arange(100) / 100 * 7)) * np.exp(noise * 0.1)
        multiplicative_series = np.abs(multiplicative_series) + 1
        
        self.multiplicative_series = pd.Series(
            multiplicative_series,
            index=dates,
            name='test_series'
        )
        
        # Simple linear trend
        self.linear_series = pd.Series(
            np.arange(100) * 0.5 + np.random.normal(0, 2, 100),
            index=dates,
            name='linear_series'
        )
        
        # Create temporary directory for cache testing
        self.temp_dir = tempfile.mkdtemp()
    
    def tearDown(self):
        """Clean up after tests."""
        warnings.resetwarnings()
        
        # Clean up temporary directory
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_forecaster_initialization(self):
        """Test that forecaster initializes correctly."""
        from xelytics.timeseries.forecasting import (
            TimeSeriesForecaster, ForecastModel
        )
        
        forecaster = TimeSeriesForecaster(
            model_type=ForecastModel.AUTO_ARIMA,
            seasonal_period=7,
            confidence_level=0.95,
            test_size=0.2,
            enable_caching=True,
            cache_dir=self.temp_dir
        )
        
        self.assertEqual(forecaster.model_type, ForecastModel.AUTO_ARIMA)
        self.assertEqual(forecaster.seasonal_period, 7)
        self.assertEqual(forecaster.confidence_level, 0.95)
        self.assertEqual(forecaster.test_size, 0.2)
        self.assertTrue(forecaster.enable_caching)
        
        print("✓ Forecaster initialization works")
    
    def test_forecast_result_structure(self):
        """Test forecast result structure."""
        from xelytics.timeseries.forecasting import (
            ForecastResult, ForecastModel
        )
        
        # Create a mock forecast result
        forecast_index = pd.date_range('2024-04-10', periods=10, freq='D')
        forecast_values = np.arange(10, 20)
        
        result = ForecastResult(
            model_name="Test Model",
            model_type=ForecastModel.ARIMA,
            forecast=pd.Series(forecast_values, index=forecast_index),
            confidence_intervals=pd.DataFrame({
                'lower': pd.Series(forecast_values - 1, index=forecast_index),
                'upper': pd.Series(forecast_values + 1, index=forecast_index)
            }),
            model_summary={'order': (1, 0, 1), 'aic': 100.5},
            training_metrics={'mae': 0.5, 'rmse': 0.7},
            metadata={'steps': 10, 'confidence_level': 0.95}
        )
        
        # Test to_dataframe method
        df = result.to_dataframe()
        self.assertIsInstance(df, pd.DataFrame)
        self.assertEqual(len(df), 10)
        self.assertIn('forecast', df.columns)
        self.assertIn('lower_bound', df.columns)
        self.assertIn('upper_bound', df.columns)
        
        # Test to_dict method
        result_dict = result.to_dict()
        self.assertIsInstance(result_dict, dict)
        self.assertEqual(result_dict['model_name'], "Test Model")
        self.assertEqual(result_dict['model_type'], 'arima')
        
        # Test from_dict method
        result_from_dict = ForecastResult.from_dict(result_dict)
        self.assertEqual(result_from_dict.model_name, "Test Model")
        self.assertEqual(result_from_dict.model_type, ForecastModel.ARIMA)
        
        print("✓ Forecast result structure works")
    
    def test_naive_forecasting(self):
        """Test naive forecasting model."""
        from xelytics.timeseries.forecasting import forecast_time_series
        
        # Test naive forecasting (should use last value)
        result = forecast_time_series(
            self.linear_series,
            steps=10,
            model_type='naive'
        )
        
        self.assertEqual(result.model_type.value, 'naive')
        self.assertEqual(len(result.forecast), 10)
        
        # All forecasts should be equal to last value (within floating point tolerance)
        last_value = self.linear_series.iloc[-1]
        self.assertTrue(np.allclose(result.forecast.values, last_value, rtol=1e-10))
        
        print("✓ Naive forecasting works")
    
    def test_seasonal_naive_forecasting(self):
        """Test seasonal naive forecasting model."""
        from xelytics.timeseries.forecasting import forecast_time_series
        
        # Test seasonal naive with period 7 (weekly)
        result = forecast_time_series(
            self.additive_series,
            steps=14,
            model_type='seasonal_naive',
            seasonal_period=7
        )
        
        self.assertEqual(result.model_type.value, 'seasonal_naive')
        self.assertEqual(len(result.forecast), 14)
        
        # Check that forecast repeats the seasonal pattern
        # First 7 values should match last 7 values of original series
        last_season = self.additive_series.iloc[-7:].values
        self.assertTrue(np.allclose(result.forecast.values[:7], last_season, rtol=1e-10))
        
        print("✓ Seasonal naive forecasting works")
    
    def test_drift_forecasting(self):
        """Test drift forecasting model."""
        from xelytics.timeseries.forecasting import forecast_time_series
        
        # Test drift model
        result = forecast_time_series(
            self.linear_series,
            steps=5,
            model_type='drift'
        )
        
        self.assertEqual(result.model_type.value, 'drift')
        self.assertEqual(len(result.forecast), 5)
        
        # Forecast should show linear drift
        forecast_diff = np.diff(result.forecast.values)
        self.assertTrue(np.allclose(forecast_diff, forecast_diff[0], rtol=1e-10))
        
        print("✓ Drift forecasting works")
    
    def test_linear_forecasting(self):
        """Test linear regression forecasting."""
        from xelytics.timeseries.forecasting import forecast_time_series
        
        # Test linear regression
        result = forecast_time_series(
            self.linear_series,
            steps=10,
            model_type='linear'
        )
        
        self.assertEqual(result.model_type.value, 'linear')
        self.assertEqual(len(result.forecast), 10)
        
        # Forecast should show linear trend
        # Check that forecast values are increasing (since our series has positive trend)
        forecast_diff = np.diff(result.forecast.values)
        self.assertTrue((forecast_diff > 0).all())
        
        print("✓ Linear forecasting works")
    
        def test_forecast_evaluation(self):
            """Test forecast evaluation metrics."""
            from xelytics.timeseries.forecasting import evaluate_forecast
            
            # Create actual and forecast series
            actual = pd.Series([1, 2, 3, 4, 5], index=range(5))
            forecast = pd.Series([1.1, 1.9, 3.2, 3.8, 5.1], index=range(5))
            
            # Calculate metrics
            metrics = evaluate_forecast(
                actual,
                forecast,
                metrics=['mae', 'mse', 'rmse', 'mape', 'smape', 'mase']
            )
            
            # Check that metrics are calculated
            self.assertIn('mae', metrics)
            self.assertIn('mse', metrics)
            self.assertIn('rmse', metrics)
            self.assertIn('mape', metrics)
            
            # MAE should be 0.14 (average error of 0.14)
            # Calculation: (0.1 + 0.1 + 0.2 + 0.2 + 0.1) / 5 = 0.14
            self.assertAlmostEqual(metrics['mae'], 0.14, places=2)
            
            # Also test other metrics for correctness
            self.assertAlmostEqual(metrics['mse'], 0.022, places=3)  # (0.01+0.01+0.04+0.04+0.01)/5 = 0.022
            self.assertAlmostEqual(metrics['rmse'], 0.1483, places=3)  # sqrt(0.022) = 0.1483
            self.assertAlmostEqual(metrics['mape'], 5.7333, places=2)  # (10% + 5% + 6.67% + 5% + 2%)/5 = 5.7333%
            
            print("✓ Forecast evaluation works with correct calculations")
    
    def test_cross_validation(self):
        """Test time series cross-validation."""
        from xelytics.timeseries.forecasting import cross_validate_forecast
        
        # Test cross-validation with naive model (fast)
        results = cross_validate_forecast(
            self.linear_series,
            model_type='naive',
            n_splits=3,
            test_size=0.2
        )
        
        self.assertIn('scores', results)
        self.assertIn('metrics', results)
        self.assertIn('models', results)
        
        # Should have results for each successful split
        self.assertGreater(len(results['scores']), 0)
        
        print("✓ Cross-validation works")
    
    def test_caching(self):
        """Test model caching functionality."""
        from xelytics.timeseries.forecasting import TimeSeriesForecaster, ForecastModel
        
        # Create forecaster with caching enabled
        forecaster = TimeSeriesForecaster(
            model_type=ForecastModel.NAIVE,
            enable_caching=True,
            cache_dir=self.temp_dir
        )
        
        # First forecast (should train and cache)
        result1 = forecaster.forecast(
            self.linear_series,
            steps=5,
            use_cached=False  # Force training
        )
        
        # Second forecast with same parameters (should use cache)
        result2 = forecaster.forecast(
            self.linear_series,
            steps=5,
            use_cached=True
        )
        
        # Both should have same forecast values
        self.assertTrue(np.allclose(result1.forecast.values, result2.forecast.values))
        
        print("✓ Model caching works")
    
    def test_short_series_handling(self):
        """Test forecasting with short time series."""
        from xelytics.timeseries.forecasting import forecast_time_series
        
        # Create very short series
        short_series = pd.Series([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
        
        # Should handle short series gracefully
        result = forecast_time_series(
            short_series,
            steps=3,
            model_type='naive'
        )
        
        self.assertEqual(len(result.forecast), 3)
        self.assertEqual(result.forecast.iloc[0], 10)  # Last value
        
        print("✓ Short series handling works")
    
    def test_missing_values_handling(self):
        """Test forecasting with missing values."""
        from xelytics.timeseries.forecasting import forecast_time_series
        
        # Create series with missing values
        series_with_nan = self.linear_series.copy()
        series_with_nan.iloc[10:15] = np.nan
        
        # Should handle NaN values
        result = forecast_time_series(
            series_with_nan,
            steps=5,
            model_type='naive'
        )
        
        self.assertEqual(len(result.forecast), 5)
        self.assertFalse(np.any(np.isnan(result.forecast.values)))
        
        print("✓ Missing values handling works")


def run_forecasting_tests():
    """Run all forecasting tests."""
    loader = unittest.TestLoader()
    suite = loader.loadTestsFromTestCase(TestTimeSeriesForecasting)
    
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    print("\n" + "="*70)
    print("MODULE 2.2.2: TIME SERIES FORECASTING - TEST RESULTS")
    print("="*70)
    
    total = result.testsRun
    passed = total - len(result.failures) - len(result.errors)
    
    print(f"\n📊 TEST SUMMARY:")
    print(f"  Total Tests: {total}")
    print(f"  Passed: {passed}")
    print(f"  Failed: {len(result.failures)}")
    print(f"  Errors: {len(result.errors)}")
    
    if result.wasSuccessful():
        print("\n✅ ALL FORECASTING TESTS PASSED!")
        print("✅ Phase 2.2.2: Forecasting Module is READY")
    else:
        print("\n❌ Some tests failed:")
        for test, traceback in result.failures:
            print(f"  - {test}")
    
    print("="*70)
    
    return result.wasSuccessful()


if __name__ == '__main__':
    success = run_forecasting_tests()
    sys.exit(0 if success else 1)