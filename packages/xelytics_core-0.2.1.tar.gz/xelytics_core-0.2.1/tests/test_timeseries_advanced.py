"""
Tests for advanced time series features (Module 2.3)
"""

import pandas as pd
import numpy as np
import pytest
from datetime import datetime, timedelta

# --- DYNAMIC IMPORTS TO PREVENT COLLECTION CRASHES ---

# 1. Anomaly Detection
try:
    from xelytics.timeseries.anomaly import TimeSeriesAnomalyDetector, AnomalyMethod, detect_anomalies, validate_anomalies
except ImportError:
    from xelytics.timeseries.detector import TimeSeriesAnomalyDetector, AnomalyMethod, detect_anomalies, validate_anomalies

# 2. Change Point Detection
try:
    from xelytics.timeseries.changepoint import ChangePointDetector, ChangePointMethod, ChangePointMetric, detect_change_points
except ImportError:
    try:
        from xelytics.timeseries.detector import ChangePointDetector, ChangePointMethod, ChangePointMetric, detect_change_points
    except ImportError:
        ChangePointDetector = ChangePointMethod = ChangePointMetric = detect_change_points = None

# 3. Model Evaluation
try:
    from xelytics.timeseries.evaluation import TimeSeriesEvaluator, ModelSelector, EvaluationMetric, ValidationMethod
except ImportError:
    TimeSeriesEvaluator = ModelSelector = EvaluationMetric = ValidationMethod = None

# 4. Utilities
try:
    from xelytics.timeseries.utils import preprocess_time_series, create_time_series_features, calculate_time_series_statistics
except ImportError:
    preprocess_time_series = create_time_series_features = calculate_time_series_statistics = None

# 5. Decomposition and Forecasting
try:
    from xelytics.timeseries.decomposition import decompose_time_series
except ImportError:
    decompose_time_series = None

try:
    from xelytics.timeseries.forecasting import forecast_time_series
except ImportError:
    forecast_time_series = None

class TestAnomalyDetection:
    """Test anomaly detection functionality."""
    
    def setup_method(self):
        """Create test time series."""
        np.random.seed(42)
        dates = pd.date_range('2023-01-01', periods=100, freq='D')
        values = np.random.normal(0, 1, 100)
        
        # Add some anomalies
        values[10] = 10  # High anomaly
        values[50] = -8  # Low anomaly
        
        self.test_series = pd.Series(values, index=dates, name='test_series')
    
    def test_z_score_detection(self):
        """Test Z-score anomaly detection."""
        detector = TimeSeriesAnomalyDetector(method=AnomalyMethod.Z_SCORE, threshold=3.0)
        result = detector.detect(self.test_series)
        
        assert result is not None
        assert result.method == AnomalyMethod.Z_SCORE
        assert result.anomalies.sum() > 0  # Should detect anomalies
    
    def test_iqr_detection(self):
        """Test IQR anomaly detection."""
        detector = TimeSeriesAnomalyDetector(method=AnomalyMethod.IQR)
        result = detector.detect(self.test_series)
        
        assert result is not None
        assert result.method == AnomalyMethod.IQR
    
    def test_detect_anomalies_convenience(self):
        """Test convenience function."""
        result = detect_anomalies(self.test_series, method='z_score', threshold=3.0)
        
        assert result is not None
        assert hasattr(result, 'anomalies')
        assert hasattr(result, 'scores')
    
    def test_validate_anomalies(self):
        """Test anomaly validation."""
        result = detect_anomalies(self.test_series, method='z_score')
        
        # Create ground truth (we know anomalies at indices 10 and 50)
        ground_truth = pd.Series(False, index=self.test_series.index)
        ground_truth.iloc[[10, 50]] = True
        
        validation = validate_anomalies(result, ground_truth)
        
        assert 'summary' in validation
        assert 'metrics' in validation
        assert 'validation' in validation


class TestChangePointDetection:
    """Test change point detection functionality."""
    
    def setup_method(self):
        """Create test time series with change points."""
        np.random.seed(42)
        dates = pd.date_range('2023-01-01', periods=200, freq='D')
        
        # Create series with change points at indices 50 and 150
        values = np.concatenate([
            np.random.normal(0, 1, 50),
            np.random.normal(5, 1, 50),
            np.random.normal(-3, 1, 100)
        ])
        
        self.test_series = pd.Series(values, index=dates, name='test_series')
    
    def test_pelt_detection(self):
        """Test PELT change point detection."""
        try:
            import ruptures
            
            from xelytics.timeseries import detect_change_points
            result = detect_change_points(
                self.test_series,
                method='pelt',
                metric='l2',
                min_segment_length=20
            )
            
            assert result is not None
            assert len(result.change_points) > 0
            assert len(result.segments) == len(result.change_points) + 1
            
        except ImportError:
            pytest.skip("ruptures package not installed")
        except Exception as e:
            # If ruptures is installed but there's another error, still run the test
            # but it might fail, which is okay for testing
            raise e
    
    def test_binseg_detection(self):
        """Test binary segmentation change point detection."""
        try:
            import ruptures
            
            from xelytics.timeseries import detect_change_points
            result = detect_change_points(
                self.test_series,
                method='binseg',
                metric='l2',
                n_change_points=2
            )
            
            assert result is not None
            assert len(result.change_points) <= 2
            
        except ImportError:
            pytest.skip("ruptures package not installed")
        except Exception as e:
            # If ruptures is installed but there's another error
            raise e


class TestModelEvaluation:
    """Test model evaluation functionality."""
    
    def setup_method(self):
        """Create test time series and forecast function."""
        np.random.seed(42)
        dates = pd.date_range('2023-01-01', periods=100, freq='D')
        values = np.random.normal(0, 1, 100)
        self.test_series = pd.Series(values, index=dates)
    
    def test_naive_forecast_fn(self):
        """Test naive forecast function."""
        def naive_forecast(train_series, steps, **kwargs):
            """Simple forecast function for testing."""
            last_value = train_series.iloc[-1]
            forecast_index = pd.date_range(
                start=train_series.index[-1] + pd.Timedelta(days=1),
                periods=steps,
                freq='D'
            )
            return pd.Series(last_value, index=forecast_index)
        
        # Test the forecast function
        test_series = pd.Series([1, 2, 3, 4, 5], 
                               index=pd.date_range('2023-01-01', periods=5, freq='D'))
        forecast = naive_forecast(test_series, steps=3)
        assert len(forecast) == 3
        assert forecast.iloc[0] == 5  # Last value of train_series
    
    def test_evaluator_initialization(self):
        """Test evaluator initialization."""
        evaluator = TimeSeriesEvaluator(
            validation_method=ValidationMethod.HOLD_OUT,
            test_size=0.2,
            metrics=['mae', 'rmse']
        )
        
        assert evaluator.validation_method == ValidationMethod.HOLD_OUT
        assert evaluator.test_size == 0.2
        assert len(evaluator.metrics) == 2
    
    def test_evaluate_model(self):
        """Test model evaluation."""
        evaluator = TimeSeriesEvaluator(
            validation_method=ValidationMethod.HOLD_OUT,
            test_size=0.2
        )
        
        # Simple forecast function that returns last value
        def simple_forecast(train_series, steps, **kwargs):
            last_value = train_series.iloc[-1]
            forecast_index = pd.date_range(
                start=train_series.index[-1] + pd.Timedelta(days=1),
                periods=steps,
                freq='D'
            )
            return pd.Series(last_value, index=forecast_index)
        
        result = evaluator.evaluate(
            series=self.test_series,
            forecast_fn=simple_forecast,
            model_name='TestModel',
            model_type='naive'
        )
        
        assert result is not None
        assert result.model_name == 'TestModel'
        assert 'mae' in result.metrics
        assert 'rmse' in result.metrics
    
    def test_model_selector(self):
        """Test model selector."""
        # Create simple forecast functions
        def forecast_fn_1(train_series, steps, **kwargs):
            return pd.Series(train_series.iloc[-1], index=range(steps))
        
        def forecast_fn_2(train_series, steps, **kwargs):
            return pd.Series(train_series.mean(), index=range(steps))
        
        models = {
            'Model1': forecast_fn_1,
            'Model2': forecast_fn_2
        }
        
        model_types = {
            'Model1': 'naive',
            'Model2': 'mean'
        }
        
        selector = ModelSelector(selection_criterion='rmse')
        
        # This might fail with small test data, but test initialization
        assert selector.evaluator is not None
        assert selector.selection_criterion == EvaluationMetric.RMSE


class TestUtilities:
    """Test utility functions."""
    
    def setup_method(self):
        """Create test time series."""
        np.random.seed(42)
        dates = pd.date_range('2023-01-01', periods=100, freq='D')
        values = np.random.normal(0, 1, 100)
        self.test_series = pd.Series(values, index=dates)
    
    def test_preprocess_time_series(self):
        """Test time series preprocessing."""
        # Add some outliers and missing values
        series_with_issues = self.test_series.copy()
        series_with_issues.iloc[10] = 100  # Outlier
        series_with_issues.iloc[20] = np.nan  # Missing
        
        preprocessed = preprocess_time_series(
            series_with_issues,
            handle_missing='ffill',
            handle_outliers='clip',
            outlier_threshold=3.0,
            normalize=True
        )
        
        assert preprocessed is not None
        assert len(preprocessed) == len(series_with_issues)
        assert preprocessed.isna().sum() == 0
    
    def test_create_time_series_features(self):
        """Test feature creation."""
        features = create_time_series_features(
            self.test_series,
            lag_features=[1, 2],
            rolling_features=[7],
            date_features=True
        )
        
        assert features is not None
        assert isinstance(features, pd.DataFrame)
        assert 'value' in features.columns
        assert 'lag_1' in features.columns
        assert 'rolling_mean_7' in features.columns
        
        if isinstance(self.test_series.index, pd.DatetimeIndex):
            assert 'year' in features.columns
            assert 'month' in features.columns
    
    def test_calculate_time_series_statistics(self):
        """Test statistics calculation."""
        stats = calculate_time_series_statistics(self.test_series)
        
        assert 'basic' in stats
        assert 'distribution' in stats
        assert 'time_series' in stats
        
        basic_stats = stats['basic']
        assert 'mean' in basic_stats
        assert 'std' in basic_stats
        assert 'count' in basic_stats
        
        assert isinstance(basic_stats['mean'], float)
        assert isinstance(basic_stats['std'], float)


# Run tests
if __name__ == "__main__":
    # Quick smoke test
    print("Running smoke tests for Module 2.3...")
    
    # Create test series
    dates = pd.date_range('2023-01-01', periods=50, freq='D')
    values = np.random.normal(0, 1, 50)
    test_series = pd.Series(values, index=dates)
    
    # Test preprocessing
    print("Testing preprocessing...")
    preprocessed = preprocess_time_series(test_series, normalize=True)
    print(f"  Original mean: {test_series.mean():.2f}")
    print(f"  Preprocessed mean: {preprocessed.mean():.2f}")
    
    # Test feature creation
    print("\nTesting feature creation...")
    features = create_time_series_features(test_series, lag_features=[1, 2])
    print(f"  Created {features.shape[1]} features")
    
    # Test statistics
    print("\nTesting statistics calculation...")
    stats = calculate_time_series_statistics(test_series)
    print(f"  Mean: {stats['basic']['mean']:.2f}")
    print(f"  Std: {stats['basic']['std']:.2f}")
    
    print("\n✅ All smoke tests passed!")