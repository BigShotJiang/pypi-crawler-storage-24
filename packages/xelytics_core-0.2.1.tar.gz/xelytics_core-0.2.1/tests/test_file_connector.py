from xelytics import analyze, AnalysisConfig
import logging
import tempfile
import os

logging.basicConfig(level=logging.INFO)

def test_file_connector():
    # Create a sample CSV file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
        f.write("id,name,value\n1,alice,10.5\n2,bob,20.3\n3,charlie,30.7")
        csv_path = f.name

    try:
        # Configure analysis with file connector
        config = AnalysisConfig(
            mode="automated",
            data_source_type="file", # BUG FIX: 'csv' changed to 'file'
            connector_config={"path": csv_path},
            enable_time_series=False,
            enable_clustering=False,
        )

        result = analyze(config=config)

        print(f"✅ Analysis complete: {result.metadata.row_count} rows analyzed")
        print(f"Insights: {len(result.insights)}")
        assert result.metadata.row_count == 3
        
    finally:
        # Clean up the temp file
        os.remove(csv_path)