import numpy as np
import pandas as pd
from xelytics import analyze, AnalysisConfig
from xelytics.export import generate_html_report

def test_full_analysis_and_report_generation(tmp_path):
    # =======================
    # 1. Generate Time Series Data
    # =======================
    dates = pd.date_range(start='2025-01-01', periods=365, freq='D')
    trend = np.linspace(100, 200, 365)
    seasonal = 10 * np.sin(2 * np.pi * dates.dayofyear / 365)
    noise = np.random.normal(0, 3, 365)
    values = trend + seasonal + noise

    ts_df = pd.DataFrame({
        'date': dates,
        'sales': values,
        'product': np.random.choice(['A', 'B', 'C'], 365),
        'store': np.random.choice(['NY', 'LA', 'CHI'], 365)
    })

    # =======================
    # 2. Generate Clustering Data
    # =======================
    np.random.seed(42)
    n_customers = 500
    cluster1 = np.random.multivariate_normal([30, 50000], [[5, 0], [0, 10000**2]], n_customers//3)
    cluster2 = np.random.multivariate_normal([45, 80000], [[4, 0], [0, 15000**2]], n_customers//3)
    cluster3 = np.random.multivariate_normal([25, 30000], [[3, 0], [0, 8000**2]], n_customers//3)
    cluster4 = np.random.multivariate_normal([50, 120000], [[6, 0], [0, 20000**2]], n_customers - 3*(n_customers//3))

    X = np.vstack([cluster1, cluster2, cluster3, cluster4])
    cluster_df = pd.DataFrame(X, columns=['age', 'income'])
    cluster_df['spending_score'] = (cluster_df['income'] / 1000) + np.random.normal(0, 5, n_customers)
    cluster_df['gender'] = np.random.choice(['M', 'F'], n_customers)

    # =======================
    # 3. Configure & Run TS
    # =======================
    config = AnalysisConfig(
        mode="automated",
        enable_time_series=True,
        datetime_column="date",
        forecast_periods=30,
        enable_clustering=True,
        clustering_algorithm="auto",
        max_clusters=5,
        enable_llm_insights=False,
        report_format="html",
        max_visualizations=20
    )
    ts_result = analyze(ts_df, config=config)

    # =======================
    # 4. Configure & Run Clustering
    # =======================
    config_cluster = AnalysisConfig(
        mode="automated",
        enable_time_series=False,
        enable_clustering=True,
        clustering_algorithm="auto",
        max_clusters=5,
        enable_llm_insights=False
    )
    cluster_result = analyze(cluster_df, config_cluster)

    # =======================
    # 5. Generate HTML Reports to tmp_path
    # =======================
    ts_report_path = tmp_path / "time_series_report.html"
    cluster_report_path = tmp_path / "clustering_report.html"

    ts_html = generate_html_report(
        ts_result, title="Time Series Analysis", author="Data Science Team", 
        theme="light", logo_text="XELYTICS", output_path=str(ts_report_path)
    )

    cluster_html = generate_html_report(
        cluster_result, title="Customer Segmentation Analysis", author="Marketing Analytics",
        theme="light", logo_text="XELYTICS", output_path=str(cluster_report_path)
    )

    assert ts_report_path.exists()
    assert cluster_report_path.exists()