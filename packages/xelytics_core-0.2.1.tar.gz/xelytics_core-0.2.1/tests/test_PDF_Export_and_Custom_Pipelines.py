"""
Test Week 5 features: PDF Export and Custom Pipelines.
"""

import tempfile
import pandas as pd
import numpy as np
from pathlib import Path

from xelytics import analyze, AnalysisConfig
from xelytics.export import generate_html_report, generate_pdf_report
from xelytics.pipeline import Pipeline, normalize, pca, remove_outliers, correlation_analysis


def test_pdf_export():
    """Generate a PDF report from an analysis result."""
    df = pd.DataFrame({
        'A': np.random.normal(0, 1, 100),
        'B': np.random.normal(10, 2, 100),
        'C': np.random.choice(['X', 'Y', 'Z'], 100)
    })

    config = AnalysisConfig(mode="automated", enable_llm_insights=False)
    result = analyze(df, config=config)

    # Generate PDF
    with tempfile.NamedTemporaryFile(suffix='.pdf', delete=False) as tmp:
        pdf_path = tmp.name

    pdf_bytes = generate_pdf_report(
        result,
        title="Test PDF Report",
        author="Tester",
        theme="light",
        logo_text="XELYTICS",
        output_path=pdf_path
    )

    # Verify file exists and is non-empty
    assert Path(pdf_path).exists()
    assert Path(pdf_path).stat().st_size > 0
    print(f"✅ PDF generated: {pdf_path}")

    # Clean up
    # Path(pdf_path).unlink()


def test_custom_pipeline():
    """Test custom pipeline execution via config."""
    df = pd.DataFrame({
        'age': np.random.randint(18, 70, 200),
        'income': np.random.normal(50000, 15000, 200),
        'spending': np.random.normal(1000, 300, 200),
        'gender': np.random.choice(['M', 'F'], 200)
    })

    config = AnalysisConfig(
        mode="automated",
        enable_llm_insights=False,
        run_pipeline=True,
        pipeline_steps=[
            {
                "function": "remove_outliers",
                "kwargs": {"columns": ["income"], "method": "iqr", "threshold": 1.5},
                "outputs": ["df"]          # overwrite df with cleaned data
            },
            {
                "function": "normalize",
                "kwargs": {"method": "zscore"},
                "inputs": ["df"],           # read from df
                "outputs": ["df"]            # overwrite with normalized data
            }
        ]
    )

    result = analyze(df, config=config)

    # The pipeline should have modified the data; we can't easily check internals,
    # but we can verify the analysis ran without errors.
    assert result.metadata.row_count > 0
    print("✅ Custom pipeline executed successfully")


def test_pipeline_api_direct():
    """Test the Pipeline API directly."""
    df = pd.DataFrame({
        'x': np.random.normal(0, 1, 50),
        'y': np.random.normal(5, 2, 50),
        'cat': np.random.choice(['A', 'B'], 50)
    })

    pipeline = Pipeline(name="test")
    # Step 1: Remove outliers (output overwrites df)
    pipeline.add_step(remove_outliers, inputs=["df"], threshold=2.0)
    # Step 2: Normalize (input df, output df – overwriting with normalized data)
    pipeline.add_step(normalize, inputs=["df"], method="minmax", outputs=["df"])
    # Step 3: PCA (input df, output pca_result)
    pipeline.add_step(pca, inputs=["df"], n_components=2, outputs=["pca_result"])

    context = pipeline.execute({"df": df})

    assert "df" in context          # normalized data
    assert "pca_result" in context  # PCA result
    # Check that PCA produced the expected number of components
    # (pca_result will contain PC1, PC2, and any non-numeric columns like 'cat')
    assert "PC2" in context["pca_result"].columns
    print("✅ Pipeline API direct test passed")


if __name__ == "__main__":
    print("Testing PDF export...")
    test_pdf_export()
    print("\nTesting custom pipeline via config...")
    test_custom_pipeline()
    print("\nTesting pipeline API directly...")
    test_pipeline_api_direct()
    print("\n🎉 Week 5 tests passed!")