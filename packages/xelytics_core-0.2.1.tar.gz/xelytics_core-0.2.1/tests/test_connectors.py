"""Tests for data connectors."""

import pytest
from xelytics.connectors import connect_to_source


@pytest.mark.parametrize("source_type", [
    "postgresql", "mysql", "sqlite", "snowflake", "bigquery",
    "s3", "azureblob", "gcs", "file"
])
def test_connector_creation(source_type):
    """Test that each connector can be created via factory."""
    connector = connect_to_source(source_type, **{})
    assert connector is not None
    assert hasattr(connector, "connect")
    assert hasattr(connector, "query")