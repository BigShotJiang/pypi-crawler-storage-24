"""
Backward compatibility tests for xelytics-core v0.2.0 - UPDATED VERSION
Tests schema compatibility without requiring full analyze function
"""

import unittest
import pandas as pd
import numpy as np
from datetime import datetime
import sys
import os
import json

# Add xelytics-core to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))


class TestBackwardCompatibility(unittest.TestCase):
    """Test that v0.2.0 maintains backward compatibility with v0.1.0"""
    
    @classmethod
    def setUpClass(cls):
        """Set up test data"""
        # Create sample dataset (v0.1.0 style)
        np.random.seed(42)
        cls.sample_data = pd.DataFrame({
            'numeric_1': np.random.randn(100),
            'numeric_2': np.random.randn(100),
            'categorical': np.random.choice(['A', 'B', 'C'], 100),
            'date': pd.date_range('2024-01-01', periods=100, freq='D'),
        })
        
        # Try to import schemas only (not analyze function)
        try:
            from xelytics.schemas import AnalysisConfig, AnalysisResult, DatasetSummary, RunMetadata
            from xelytics.schemas import StatisticalTestResult, VisualizationSpec, Insight
            from xelytics.schemas import TimeSeriesResult, ClusterResult
            cls.AnalysisConfig = AnalysisConfig
            cls.AnalysisResult = AnalysisResult
            cls.DatasetSummary = DatasetSummary
            cls.RunMetadata = RunMetadata
            cls.StatisticalTestResult = StatisticalTestResult
            cls.VisualizationSpec = VisualizationSpec
            cls.Insight = Insight
            cls.TimeSeriesResult = TimeSeriesResult
            cls.ClusterResult = ClusterResult
            cls.schemas_available = True
        except ImportError as e:
            cls.schemas_available = False
            print(f"Warning: Schemas not available for testing: {e}")
    
    def test_01_imports_still_work(self):
        """Test that all v0.1.0 schema imports still work"""
        if not self.schemas_available:
            self.skipTest("Schemas not available")
        
        try:
            # Test core schema imports
            from xelytics.schemas import (
                AnalysisConfig, DatasetInput, AnalysisResult,
                DecisionLog, DecisionLogEntry, DecisionType,
                DatasetSummary, RunMetadata, StatisticalTestResult,
                VisualizationSpec, Insight
            )
            
            # If we get here, imports work
            self.assertTrue(True, "All v0.1.0 schema imports work")
            print("✓ All v0.1.0 schema imports work")
        except ImportError as e:
            self.fail(f"v0.1.0 schema import failed: {e}")
    
    def test_02_v0_2_0_schema_imports_work(self):
        """Test that v0.2.0 schema imports work"""
        if not self.schemas_available:
            self.skipTest("Schemas not available")
        
        try:
            # Test v0.2.0 schema imports
            from xelytics.schemas import (
                TimeSeriesResult, ClusterResult,
                TimeSeriesType, ClusteringAlgorithm
            )
            
            # If we get here, imports work
            self.assertTrue(True, "All v0.2.0 schema imports work")
            print("✓ All v0.2.0 schema imports work")
        except ImportError as e:
            self.fail(f"v0.2.0 schema import failed: {e}")
    
    def test_03_analysis_config_backward_compatible(self):
        """Test that AnalysisConfig accepts old parameters and ignores new ones"""
        if not self.schemas_available:
            self.skipTest("Schemas not available")
        
        try:
            # Create config with ONLY v0.1.0 parameters
            config = self.AnalysisConfig(
                # v0.1.0 parameters only
                mode="automated",
                significance_level=0.05,
                enable_llm_insights=True,
                llm_provider="openai",
                max_visualizations=5,
                max_insights=10,
                
                # Do NOT set any v0.2.0 parameters
                # enable_time_series, datetime_column, etc. should default to safe values
            )
            
            # Should create successfully
            self.assertIsNotNone(config)
            self.assertEqual(config.mode, "automated")
            self.assertEqual(config.llm_provider, "openai")
            self.assertEqual(config.significance_level, 0.05)
            
            # v0.2.0 parameters should have safe defaults
            self.assertFalse(config.enable_time_series,
                           "enable_time_series should default to False")
            self.assertFalse(config.enable_clustering,
                           "enable_clustering should default to False")
            self.assertEqual(config.datetime_column, None,
                           "datetime_column should default to None")
            self.assertEqual(config.forecast_periods, 0,
                           "forecast_periods should default to 0")
            
            print("✓ v0.1.0 config parameters work correctly")
            print("✓ v0.2.0 parameters have safe defaults")
            
        except Exception as e:
            self.fail(f"v0.1.0 config creation failed: {e}")
    
    def test_04_analysis_config_v0_2_0_features(self):
        """Test that AnalysisConfig accepts v0.2.0 parameters"""
        if not self.schemas_available:
            self.skipTest("Schemas not available")
        
        try:
            # Create config with v0.2.0 parameters
            config = self.AnalysisConfig(
                # v0.1.0 parameters
                mode="automated",
                significance_level=0.05,
                
                # v0.2.0 parameters
                enable_time_series=True,
                datetime_column="date",
                forecast_periods=30,
                enable_clustering=True,
                clustering_algorithm="kmeans",
                max_clusters=5,
                enable_caching=True,
                parallel_execution=True,
                max_workers=4,
            )
            
            # Should create successfully
            self.assertIsNotNone(config)
            self.assertTrue(config.enable_time_series)
            self.assertEqual(config.datetime_column, "date")
            self.assertEqual(config.forecast_periods, 30)
            self.assertTrue(config.enable_clustering)
            self.assertEqual(config.clustering_algorithm, "kmeans")
            self.assertEqual(config.max_clusters, 5)
            self.assertTrue(config.enable_caching)
            self.assertTrue(config.parallel_execution)
            self.assertEqual(config.max_workers, 4)
            
            print("✓ v0.2.0 config parameters work correctly")
            
        except Exception as e:
            self.fail(f"v0.2.0 config creation failed: {e}")
    
    def test_05_analysis_result_structure(self):
        """Test that AnalysisResult has both v0.1.0 and v0.2.0 fields"""
        if not self.schemas_available:
            self.skipTest("Schemas not available")
        
        try:
            # Create v0.1.0 style result
            summary = self.DatasetSummary(row_count=100, column_count=4)
            metadata = self.RunMetadata(
                execution_time_ms=1000,
                package_version="0.2.0-dev",
                row_count=100,
                column_count=4,
                tests_executed=5,
                tests_skipped=2,
                visualizations_generated=3,
                insights_generated=8,
            )
            
            result = self.AnalysisResult(
                summary=summary,
                statistics=[],  # Empty for test
                visualizations=[],
                insights=[],
                metadata=metadata,
            )
            
            # Check v0.1.0 fields exist
            self.assertIsNotNone(result.summary)
            self.assertIsNotNone(result.statistics)
            self.assertIsNotNone(result.visualizations)
            self.assertIsNotNone(result.insights)
            self.assertIsNotNone(result.metadata)
            
            # Check v0.2.0 fields exist (should be empty by default)
            self.assertIsNotNone(result.time_series_analysis)
            self.assertIsNotNone(result.clusters)
            self.assertIsInstance(result.time_series_analysis, list)
            self.assertIsInstance(result.clusters, list)
            self.assertEqual(len(result.time_series_analysis), 0)
            self.assertEqual(len(result.clusters), 0)
            
            print("✓ AnalysisResult has both v0.1.0 and v0.2.0 fields")
            
        except Exception as e:
            self.fail(f"AnalysisResult structure test failed: {e}")
    
    def test_06_json_serialization_backward_compatible(self):
        """Test that JSON serialization/deserialization still works"""
        if not self.schemas_available:
            self.skipTest("Schemas not available")
        
        try:
            # Create a simple result
            summary = self.DatasetSummary(row_count=100, column_count=4)
            metadata = self.RunMetadata(
                execution_time_ms=1000,
                package_version="0.2.0-dev",
                row_count=100,
                column_count=4,
                tests_executed=5,
                tests_skipped=2,
                visualizations_generated=3,
                insights_generated=8,
            )
            
            result = self.AnalysisResult(
                summary=summary,
                statistics=[],
                visualizations=[],
                insights=[],
                metadata=metadata,
            )
            
            # Serialize to JSON
            json_str = result.to_json()
            self.assertIsInstance(json_str, str)
            self.assertTrue(len(json_str) > 100)
            
            # Check JSON structure
            json_dict = json.loads(json_str)
            
            # v0.1.0 fields must exist
            self.assertIn("summary", json_dict)
            self.assertIn("statistics", json_dict)
            self.assertIn("visualizations", json_dict)
            self.assertIn("insights", json_dict)
            self.assertIn("metadata", json_dict)
            
            # v0.2.0 fields may exist (they exist in our implementation)
            if "time_series_analysis" in json_dict:
                self.assertIsInstance(json_dict["time_series_analysis"], list)
            
            if "clusters" in json_dict:
                self.assertIsInstance(json_dict["clusters"], list)
            
            print("✓ JSON serialization works with backward compatibility")
            
        except Exception as e:
            self.fail(f"JSON serialization test failed: {e}")
    
    def test_07_new_features_disabled_by_default(self):
        """Test that new v0.2.0 features are disabled by default"""
        if not self.schemas_available:
            self.skipTest("Schemas not available")
        
        try:
            # Create config without enabling any v0.2.0 features
            config = self.AnalysisConfig(
                mode="automated",
                # Don't set enable_time_series, enable_clustering, etc.
            )
            
            # v0.2.0 parameters should be disabled by default
            self.assertFalse(config.enable_time_series,
                           "enable_time_series should default to False")
            self.assertFalse(config.enable_clustering,
                           "enable_clustering should default to False")
            self.assertFalse(config.datetime_column,
                           "datetime_column should default to None/False")
            self.assertEqual(config.forecast_periods, 0,
                           "forecast_periods should default to 0")
            
            print("✓ v0.2.0 features are disabled by default")
            
        except Exception as e:
            self.fail(f"Feature default test failed: {e}")
    
    def test_08_time_series_result_structure(self):
        """Test TimeSeriesResult schema"""
        if not self.schemas_available:
            self.skipTest("Schemas not available")
        
        try:
            from xelytics.schemas import TimeSeriesType
            
            # Create a time series result
            ts_result = self.TimeSeriesResult(
                column="sales",
                series_type=TimeSeriesType.SEASONAL,
                is_stationary=False,
                has_trend=True,
                has_seasonality=True,
                seasonal_period=12,
                trend_strength=0.8,
                seasonality_strength=0.6,
            )
            
            self.assertEqual(ts_result.column, "sales")
            self.assertEqual(ts_result.series_type, TimeSeriesType.SEASONAL)
            self.assertFalse(ts_result.is_stationary)
            self.assertTrue(ts_result.has_trend)
            self.assertTrue(ts_result.has_seasonality)
            self.assertEqual(ts_result.seasonal_period, 12)
            self.assertEqual(ts_result.trend_strength, 0.8)
            self.assertEqual(ts_result.seasonality_strength, 0.6)
            
            print("✓ TimeSeriesResult schema works correctly")
            
        except Exception as e:
            self.fail(f"TimeSeriesResult test failed: {e}")
    
    def test_09_cluster_result_structure(self):
        """Test ClusterResult schema"""
        if not self.schemas_available:
            self.skipTest("Schemas not available")
        
        try:
            from xelytics.schemas import ClusteringAlgorithm
            
            # Create a cluster result
            cluster_result = self.ClusterResult(
                cluster_id=1,
                algorithm=ClusteringAlgorithm.KMEANS,
                size=50,
                centroid={"feature1": 0.5, "feature2": 0.3},
                profile={"description": "High value customers"},
                silhouette_score=0.75,
                members=[1, 2, 3, 4, 5],
            )
            
            self.assertEqual(cluster_result.cluster_id, 1)
            self.assertEqual(cluster_result.algorithm, ClusteringAlgorithm.KMEANS)
            self.assertEqual(cluster_result.size, 50)
            self.assertEqual(cluster_result.silhouette_score, 0.75)
            self.assertEqual(len(cluster_result.members), 5)
            
            print("✓ ClusterResult schema works correctly")
            
        except Exception as e:
            self.fail(f"ClusterResult test failed: {e}")


class TestGradualAdoption(unittest.TestCase):
    """Test gradual adoption of v0.2.0 features"""
    
    @classmethod
    def setUpClass(cls):
        # Try to import schemas
        try:
            from xelytics.schemas import AnalysisConfig
            cls.AnalysisConfig = AnalysisConfig
            cls.schemas_available = True
        except ImportError:
            cls.schemas_available = False
    
    def test_enable_time_series_only(self):
        """Test enabling only time series feature"""
        if not self.schemas_available:
            self.skipTest("Schemas not available")
        
        try:
            config = self.AnalysisConfig(
                mode="automated",
                enable_time_series=True,  # Enable v0.2.0 feature
                datetime_column="timestamp",
                enable_clustering=False,  # Keep v0.2.0 feature disabled
                enable_llm_insights=True,  # v0.1.0 feature
            )
            
            # Check settings
            self.assertTrue(config.enable_time_series)
            self.assertEqual(config.datetime_column, "timestamp")
            self.assertFalse(config.enable_clustering)
            self.assertTrue(config.enable_llm_insights)
            
            print("✓ Can enable time series while keeping clustering disabled")
            
        except Exception as e:
            self.fail(f"Time series enable test failed: {e}")
    
    def test_enable_clustering_only(self):
        """Test enabling only clustering feature"""
        if not self.schemas_available:
            self.skipTest("Schemas not available")
        
        try:
            config = self.AnalysisConfig(
                mode="automated",
                enable_time_series=False,  # Keep disabled
                enable_clustering=True,    # Enable v0.2.0 feature
                clustering_algorithm="kmeans",
                max_clusters=3,
                enable_llm_insights=False,
            )
            
            # Check settings
            self.assertFalse(config.enable_time_series)
            self.assertTrue(config.enable_clustering)
            self.assertEqual(config.clustering_algorithm, "kmeans")
            self.assertEqual(config.max_clusters, 3)
            self.assertFalse(config.enable_llm_insights)
            
            print("✓ Can enable clustering while keeping time series disabled")
            
        except Exception as e:
            self.fail(f"Clustering enable test failed: {e}")
    
    def test_mixed_v1_v2_config(self):
        """Test mixing v0.1.0 and v0.2.0 parameters"""
        if not self.schemas_available:
            self.skipTest("Schemas not available")
        
        try:
            config = self.AnalysisConfig(
                # v0.1.0 parameters
                mode="semi-automated",
                significance_level=0.01,
                max_visualizations=5,
                include_assumptions=True,
                
                # v0.2.0 parameters
                enable_caching=True,
                parallel_execution=True,
                max_workers=2,
                enable_time_series=False,
                enable_clustering=False,
            )
            
            # v0.1.0 parameters
            self.assertEqual(config.mode, "semi-automated")
            self.assertEqual(config.significance_level, 0.01)
            self.assertEqual(config.max_visualizations, 5)
            self.assertTrue(config.include_assumptions)
            
            # v0.2.0 parameters
            self.assertTrue(config.enable_caching)
            self.assertTrue(config.parallel_execution)
            self.assertEqual(config.max_workers, 2)
            self.assertFalse(config.enable_time_series)
            self.assertFalse(config.enable_clustering)
            
            print("✓ Can mix v0.1.0 and v0.2.0 parameters")
            
        except Exception as e:
            self.fail(f"Mixed config test failed: {e}")


def run_backward_compatibility_tests():
    """Run all backward compatibility tests"""
    suite = unittest.TestLoader().loadTestsFromTestCase(TestBackwardCompatibility)
    suite.addTests(unittest.TestLoader().loadTestsFromTestCase(TestGradualAdoption))
    
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    return result.wasSuccessful()


if __name__ == '__main__':
    success = run_backward_compatibility_tests()
    sys.exit(0 if success else 1)