from xelytics import analyze, AnalysisConfig
import logging

logging.basicConfig(level=logging.INFO)

CONNECTION_STRING = (
    "postgresql://postgres.lyqxnhhxtbofgvnobzvm:your_password@"
    "aws-1-ap-southeast-2.pooler.supabase.com:5432/postgres?sslmode=require"
)

REAL_TABLE = "analysis_runs"  # change this!

def test_postgres_connector_analysis():
    config = AnalysisConfig(
        mode="automated",
        data_source_type="postgresql",
        connector_config={"connection_string": CONNECTION_STRING},
        query=f"SELECT * FROM {REAL_TABLE} LIMIT 100",
    )

    try:
        result = analyze(config=config)
        print(f"✅ Analysis complete: {result.metadata.row_count} rows analyzed")
        assert result is not None
    except RuntimeError as e:
        # Catching the error so the test fails gracefully instead of crashing the suite
        # if the real database credentials aren't provided yet
        print(f"Skipping database execution: {e}")