from xelytics import analyze, AnalysisConfig
from xelytics.export import generate_html_report
import pandas as pd
import tempfile

df = pd.DataFrame({
    'A': [1, 2, 3, 4, 5],
    'B': [5, 4, 3, 2, 1],
    'C': ['x', 'y', 'x', 'y', 'z']
})

config = AnalysisConfig(mode="automated")
result = analyze(df, config=config)

html = generate_html_report(
    result,
    title="Professional Sales Analysis",
    author="Data Team",
    theme="light",
    logo_url="https://xelytics.live/assets/lighterLogo2-DG6l1w6e.webp",  # or base64 data URI
    logo_text="XELYTICS"
)

with tempfile.NamedTemporaryFile(mode='w', suffix='.html', delete=False, encoding='utf-8') as f:
    f.write(html)
    print(f"Report saved to {f.name}")