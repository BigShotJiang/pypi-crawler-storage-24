"""Simple test to verify imports work."""

import unittest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))


class TestSimpleImports(unittest.TestCase):
    """Test that basic imports work."""
    
    def test_import_schemas(self):
        """Test that schema imports work."""
        try:
            from xelytics.schemas import AnalysisConfig, AnalysisResult
            print("✓ Successfully imported AnalysisConfig and AnalysisResult")
            self.assertTrue(True)
        except ImportError as e:
            self.fail(f"Import failed: {e}")
        except Exception as e:
            self.fail(f"Unexpected error: {e}")
    
    def test_create_config(self):
        """Test that we can create a config."""
        try:
            from xelytics.schemas import AnalysisConfig
            
            # Test v0.1.0 style config
            config_v1 = AnalysisConfig(
                mode="automated",
                enable_llm_insights=False,
            )
            self.assertEqual(config_v1.mode, "automated")
            print("✓ Created v0.1.0 style config")
            
            # Test v0.2.0 style config (with new parameters)
            config_v2 = AnalysisConfig(
                mode="automated",
                enable_time_series=True,
                enable_clustering=True,
            )
            self.assertTrue(config_v2.enable_time_series)
            self.assertTrue(config_v2.enable_clustering)
            print("✓ Created v0.2.0 style config")
            
        except Exception as e:
            self.fail(f"Config creation failed: {e}")
    
    def test_analysis_result_structure(self):
        """Test that AnalysisResult has the right structure."""
        try:
            from xelytics.schemas import (
                AnalysisResult, DatasetSummary, RunMetadata,
                StatisticalTestResult, VisualizationSpec, Insight
            )
            
            # Create a minimal result
            summary = DatasetSummary(row_count=100, column_count=5)
            metadata = RunMetadata(
                execution_time_ms=1000,
                package_version="0.2.0-dev",
                row_count=100,
                column_count=5,
                tests_executed=0,
                tests_skipped=0,
                visualizations_generated=0,
                insights_generated=0,
            )
            
            result = AnalysisResult(
                summary=summary,
                statistics=[],
                visualizations=[],
                insights=[],
                metadata=metadata,
            )
            
            # Check structure
            self.assertIsInstance(result.summary, DatasetSummary)
            self.assertIsInstance(result.metadata, RunMetadata)
            self.assertIsInstance(result.statistics, list)
            self.assertIsInstance(result.visualizations, list)
            self.assertIsInstance(result.insights, list)
            
            # Check v0.2.0 fields exist
            self.assertTrue(hasattr(result, 'time_series_analysis'))
            self.assertTrue(hasattr(result, 'clusters'))
            self.assertEqual(len(result.time_series_analysis), 0)
            self.assertEqual(len(result.clusters), 0)
            
            print("✓ Created AnalysisResult with correct structure")
            
        except Exception as e:
            self.fail(f"AnalysisResult test failed: {e}")


if __name__ == '__main__':
    unittest.main()