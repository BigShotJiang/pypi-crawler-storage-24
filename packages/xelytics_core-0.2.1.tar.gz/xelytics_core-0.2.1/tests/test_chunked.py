"""Tests for chunked/streaming processing for large datasets."""

import pytest
import pandas as pd
import numpy as np
import tempfile
from pathlib import Path

from xelytics.core.chunked import (
    chunked_dataframe_reader,
    compute_chunked_summary,
    ChunkedStats,
)
from xelytics.engine import analyze_large_dataset
from xelytics import AnalysisConfig


def test_chunked_stats_accumulator():
    """Test ChunkedStats update and finalize."""
    acc = ChunkedStats()
    series = pd.Series([1.0, 2.0, np.nan, 4.0, 5.0])
    acc.update(series)
    stats = acc.finalize()
    assert stats['count'] == 4
    assert stats['missing'] == 1
    assert stats['mean'] == (1+2+4+5)/4
    assert stats['min'] == 1
    assert stats['max'] == 5
    assert len(stats['top_values']) > 0


def test_chunked_dataframe_reader_dataframe():
    """Test chunked reader on DataFrame input."""
    df = pd.DataFrame({'a': range(1000), 'b': range(1000)})
    chunks = list(chunked_dataframe_reader(df, chunksize=300))
    assert len(chunks) == 4  # 1000/300 = 3.33 -> 4 chunks
    assert sum(len(chunk) for chunk in chunks) == 1000


def test_chunked_dataframe_reader_csv(tmp_path):
    """Test chunked reader on CSV file."""
    df = pd.DataFrame({'a': range(5000), 'b': range(5000)})
    csv_path = tmp_path / "test.csv"
    df.to_csv(csv_path, index=False)
    
    chunks = list(chunked_dataframe_reader(str(csv_path), chunksize=1000))
    assert len(chunks) == 5
    assert sum(len(chunk) for chunk in chunks) == 5000


def test_compute_chunked_summary(tmp_path):
    """Test computing summary from chunked CSV."""
    # Create a CSV with 5000 rows
    np.random.seed(42)
    df = pd.DataFrame({
        'num': np.random.randn(5000),
        'cat': np.random.choice(['A','B','C'], 5000),
        'mixed': [1,2,3,4,5]*1000,
    })
    csv_path = tmp_path / "data.csv"
    df.to_csv(csv_path, index=False)
    
    stats, total_rows = compute_chunked_summary(str(csv_path), chunksize=1000)
    assert total_rows == 5000
    assert 'num' in stats
    assert 'cat' in stats
    assert 'mixed' in stats
    
    # Check approximate correctness
    assert abs(stats['num']['mean'] - df['num'].mean()) < 0.1
    assert stats['cat']['top_values'][0][0] in ['A','B','C']


def test_analyze_large_dataset(tmp_path):
    """Test the high-level analyze_large_dataset function."""
    # Create a larger CSV
    n = 20000
    df = pd.DataFrame({
        'num1': np.random.randn(n),
        'num2': np.random.randn(n) * 10 + 5,
        'cat1': np.random.choice(['X','Y','Z'], n),
        'cat2': np.random.choice(['P','Q'], n),
    })
    csv_path = tmp_path / "large.csv"
    df.to_csv(csv_path, index=False)
    
    # Run chunked analysis
    result = analyze_large_dataset(str(csv_path), chunksize=5000)
    
    # Verify result structure
    assert result.summary.row_count == n
    assert result.summary.column_count == 4
    assert len(result.summary.column_profiles) == 4
    
    # Check numeric columns detected
    assert 'num1' in result.summary.numeric_columns
    assert 'num2' in result.summary.numeric_columns
    assert 'cat1' in result.summary.categorical_columns
    assert 'cat2' in result.summary.categorical_columns
    
    # Verify some stats
    for profile in result.summary.column_profiles:
        if profile.column_name == 'num1':
            assert abs(profile.mean - df['num1'].mean()) < 0.1
        elif profile.column_name == 'cat1':
            assert profile.mode in ['X','Y','Z']


def test_analyze_large_dataset_with_sample(tmp_path):
    """Test analyze_large_dataset with sampling (should use normal analyze)."""
    n = 20000
    df = pd.DataFrame({'num': np.random.randn(n), 'cat': np.random.choice(['A','B'], n)})
    csv_path = tmp_path / "sample_test.csv"
    df.to_csv(csv_path, index=False)
    
    # We'll just test that it runs without error when sample_size is set.
    # For a real test we'd mock, but here we just ensure it doesn't crash.
    config = AnalysisConfig(enable_time_series=False, enable_clustering=False)
    result = analyze_large_dataset(
        str(csv_path),
        sample_size=5000,  # take 5000 rows for full analysis
        config=config,
        chunksize=5000
    )
    # With sampling, it should produce a full result (with stats, etc.)
    assert result.metadata.tests_executed > 0 or result.metadata.visualizations_generated > 0