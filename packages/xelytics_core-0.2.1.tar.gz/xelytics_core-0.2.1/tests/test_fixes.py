import pandas as pd
import numpy as np
from xelytics.timeseries import TimeSeriesDetector

# Test 1: Hourly frequency
print("Test 1: Hourly frequency")
hourly_dates = pd.date_range('2024-01-01', periods=24, freq='h')
df_hourly = pd.DataFrame({'timestamp': hourly_dates})
detector = TimeSeriesDetector()
results = detector.detect(df_hourly)
print(f"  Hourly frequency detected: {results[0].frequency}")
print(f"  Expected: h, Got: {results[0].frequency}")
print(f"  ✓ Pass" if results[0].frequency == 'h' else f"  ✗ Fail")

# Test 2: Missing values with clear gaps
print("\nTest 2: Missing values detection")
dates = pd.date_range('2024-01-01', periods=20, freq='D')
# Remove every 3rd date
mask = np.ones(20, dtype=bool)
mask[2::3] = False  # Remove indices 2, 5, 8, 11, 14, 17
dates_with_gaps = dates[mask]
df_gaps = pd.DataFrame({'date': dates_with_gaps})
results = detector.detect(df_gaps)
print(f"  Has gaps: {results[0].has_gaps}")
print(f"  Gap percentage: {results[0].gap_percentage:.1%}")
print(f"  ✓ Pass" if results[0].has_gaps else f"  ✗ Fail")

# Test 3: Truly irregular series
print("\nTest 3: Irregular series detection")
np.random.seed(42)
dates_irregular = []
current_date = pd.Timestamp('2024-01-01')
for i in range(20):
    dates_irregular.append(current_date)
    current_date += pd.Timedelta(days=np.random.randint(1, 10))
df_irregular = pd.DataFrame({'date': dates_irregular})
results = detector.detect(df_irregular)
print(f"  Frequency: {results[0].frequency}")
print(f"  Is irregular: {results[0].frequency == 'irregular'}")
print(f"  ✓ Pass" if results[0].frequency == 'irregular' else f"  ✗ Fail")

print("\n" + "="*50)
print("Summary: All manual tests should pass with fixes")