"""Backward compatibility test for v0.2.0.

Ensures that v0.1.0 API still works correctly in v0.2.0.
"""

import pytest
import pandas as pd
import numpy as np


def test_v01_api_still_works():
    """Test that v0.1.0 analyze() call still works."""
    from xelytics import analyze, AnalysisConfig, AnalysisResult
    
    # Create sample data
    df = pd.DataFrame({
        'age': np.random.randint(20, 65, 100),
        'salary': np.random.normal(60000, 15000, 100),
        'department': np.random.choice(['Sales', 'Engineering', 'Marketing'], 100),
    })
    
    # v0.1.0 style call - should still work
    result = analyze(df, mode="automated")
    
    # Verify v0.1.0 fields exist
    assert hasattr(result, 'summary')
    assert hasattr(result, 'statistics')
    assert hasattr(result, 'visualizations')
    assert hasattr(result, 'insights')
    assert hasattr(result, 'metadata')
    
    # Verify basic functionality
    assert result.summary.row_count == 100
    assert result.summary.column_count == 3
    assert len(result.statistics) >= 0
    assert len(result.visualizations) >= 0
    assert len(result.insights) >= 0


def test_v01_config_still_works():
    """Test that v0.1.0 AnalysisConfig still works."""
    from xelytics import analyze, AnalysisConfig
    
    # Create sample data
    df = pd.DataFrame({
        'x': np.random.randn(50),
        'y': np.random.randn(50),
    })
    
    # v0.1.0 style config
    config = AnalysisConfig(
        mode="automated",
        significance_level=0.05,
        enable_llm_insights=False,
        max_visualizations=5,
    )
    
    result = analyze(df, config=config)
    
    # Should work without errors
    assert result is not None
    assert len(result.visualizations) <= 5


def test_v02_new_fields_are_optional():
    """Test that v0.2.0 new fields exist but are empty by default."""
    from xelytics import analyze
    
    df = pd.DataFrame({
        'value': np.random.randn(30),
    })
    
    result = analyze(df, mode="automated")
    
    # v0.2.0 fields should exist
    assert hasattr(result, 'time_series_analysis')
    assert hasattr(result, 'clusters')
    
    # But should be empty when not explicitly enabled
    assert isinstance(result.time_series_analysis, list)
    assert isinstance(result.clusters, list)
    assert len(result.time_series_analysis) == 0
    assert len(result.clusters) == 0


def test_v01_to_json_still_works():
    """Test that v0.1.0 to_json() method still works."""
    from xelytics import analyze
    import json
    
    df = pd.DataFrame({
        'value': np.random.randn(20),
    })
    
    result = analyze(df, mode="automated")
    
    # Should be able to serialize to JSON
    json_str = result.to_json()
    assert isinstance(json_str, str)
    
    # Should be valid JSON
    json_data = json.loads(json_str)
    assert 'summary' in json_data
    assert 'statistics' in json_data
    assert 'visualizations' in json_data
    assert 'insights' in json_data
    assert 'metadata' in json_data


def test_v01_to_dict_still_works():
    """Test that v0.1.0 to_dict() method still works."""
    from xelytics import analyze
    
    df = pd.DataFrame({
        'value': np.random.randn(20),
    })
    
    result = analyze(df, mode="automated")
    
    # Should be able to convert to dict
    result_dict = result.to_dict()
    assert isinstance(result_dict, dict)
    assert 'summary' in result_dict
    assert 'statistics' in result_dict


def test_v02_new_config_params_have_defaults():
    """Test that v0.2.0 config params have sensible defaults."""
    from xelytics import AnalysisConfig
    
    # Create config without new v0.2.0 params
    config = AnalysisConfig()
    
    # New v0.2.0 params should have defaults
    assert config.enable_time_series == False
    assert config.enable_clustering == False
    assert config.enable_caching == True
    assert config.parallel_execution == True
    assert config.max_workers == 4


def test_v02_time_series_can_be_enabled():
    """Test that v0.2.0 time series analysis can be enabled."""
    from xelytics import AnalysisConfig
    
    config = AnalysisConfig(
        enable_time_series=True,
        datetime_column='date',
        forecast_periods=10
    )
    
    assert config.enable_time_series == True
    assert config.datetime_column == 'date'
    assert config.forecast_periods == 10


def test_v02_clustering_can_be_enabled():
    """Test that v0.2.0 clustering can be enabled."""
    from xelytics import AnalysisConfig
    
    config = AnalysisConfig(
        enable_clustering=True,
        clustering_algorithm='kmeans',
        max_clusters=5
    )
    
    assert config.enable_clustering == True
    assert config.clustering_algorithm == 'kmeans'
    assert config.max_clusters == 5


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
