"""Tests for PowerPoint and Jupyter notebook export."""

import pytest
import pandas as pd
import numpy as np
from pathlib import Path
import tempfile
import json

from xelytics import analyze, AnalysisConfig
from xelytics.schemas.outputs import AnalysisResult, DatasetSummary, RunMetadata
from xelytics.export import generate_pptx_report, generate_notebook, export_to_format


# Skip tests if optional dependencies not installed
try:
    from pptx import Presentation
    PPTX_AVAILABLE = True
except ImportError:
    PPTX_AVAILABLE = False

try:
    import nbformat
    NOTEBOOK_AVAILABLE = True
except ImportError:
    NOTEBOOK_AVAILABLE = False


@pytest.fixture
def sample_result():
    """Create a minimal AnalysisResult for testing."""
    # Create a small dataframe and run analysis
    np.random.seed(42)
    df = pd.DataFrame({
        'num1': np.random.randn(100),
        'num2': np.random.randn(100),
        'cat1': np.random.choice(['A', 'B', 'C'], 100),
        'cat2': np.random.choice(['X', 'Y'], 100),
    })
    config = AnalysisConfig(
        mode="automated",
        enable_llm_insights=False,
        max_visualizations=2,
        enable_time_series=False,
        enable_clustering=True,
    )
    result = analyze(df, config=config)
    return result


@pytest.mark.skipif(not PPTX_AVAILABLE, reason="python-pptx not installed")
def test_pptx_export(sample_result, tmp_path):
    """Test PowerPoint export generates a valid .pptx file."""
    output_path = tmp_path / "test.pptx"
    
    # Generate to file
    generate_pptx_report(sample_result, output_path=str(output_path))
    assert output_path.exists()
    assert output_path.stat().st_size > 0
    
    # Generate to bytes
    pptx_bytes = generate_pptx_report(sample_result)
    assert isinstance(pptx_bytes, bytes)
    assert len(pptx_bytes) > 0
    
    # Verify it's a valid PPTX (basic check)
    with tempfile.NamedTemporaryFile(suffix=".pptx", delete=False) as tmp:
        tmp.write(pptx_bytes)
        tmp.flush()
        prs = Presentation(tmp.name)
        assert len(prs.slides) > 0


@pytest.mark.skipif(not NOTEBOOK_AVAILABLE, reason="nbformat not installed")
def test_notebook_export(sample_result, tmp_path):
    """Test Jupyter notebook export generates a valid .ipynb file."""
    output_path = tmp_path / "test.ipynb"
    
    # Generate to file
    generate_notebook(sample_result, output_path=str(output_path))
    assert output_path.exists()
    assert output_path.stat().st_size > 0
    
    # Generate to string
    notebook_str = generate_notebook(sample_result)
    assert isinstance(notebook_str, str)
    assert len(notebook_str) > 0
    
    # Verify valid notebook JSON
    nb = nbformat.reads(notebook_str, as_version=4)
    assert nb.cells
    assert nb.metadata


def test_export_to_format(sample_result, tmp_path):
    """Test the unified export_to_format function for all formats."""
    # Test HTML (should always work)
    html_bytes = export_to_format(sample_result, format_type="html")
    assert isinstance(html_bytes, bytes)
    assert b"<html" in html_bytes.lower()
    
    # Test JSON
    json_bytes = export_to_format(sample_result, format_type="json")
    assert isinstance(json_bytes, bytes)
    data = json.loads(json_bytes.decode('utf-8'))
    assert "summary" in data
    
    # Test PPTX if available
    if PPTX_AVAILABLE:
        pptx_bytes = export_to_format(sample_result, format_type="pptx")
        assert isinstance(pptx_bytes, bytes)
        assert len(pptx_bytes) > 0
    
    # Test notebook if available
    if NOTEBOOK_AVAILABLE:
        nb_bytes = export_to_format(sample_result, format_type="ipynb")
        assert isinstance(nb_bytes, bytes)
        nb = nbformat.reads(nb_bytes.decode('utf-8'), as_version=4)
        assert nb.cells


def test_pptx_with_real_data():
    """Test PowerPoint generation with a simple dataset (no dependencies needed for creation)."""
    if not PPTX_AVAILABLE:
        pytest.skip("python-pptx not installed")
    
    # Create a minimal result manually to avoid heavy analysis
    from xelytics.schemas.outputs import (
        AnalysisResult, DatasetSummary, ColumnProfile, StatisticalTestResult,
        VisualizationSpec, Insight, RunMetadata
    )
    from datetime import datetime
    
    summary = DatasetSummary(
        row_count=100,
        column_count=2,
        numeric_columns=['num1'],
        categorical_columns=['cat1'],
        datetime_columns=[],
        identifier_columns=[],
        column_profiles=[
            ColumnProfile(column_name='num1', data_type='numeric', role='measure',
                          missing_count=0, missing_percentage=0.0, unique_count=100,
                          cardinality_ratio=1.0, mean=0.5, std=1.2, min=-2.0, max=3.0,
                          median=0.6, mode=None, top_values=[]),
            ColumnProfile(column_name='cat1', data_type='categorical', role='dimension',
                          missing_count=0, missing_percentage=0.0, unique_count=3,
                          cardinality_ratio=0.03, mean=None, std=None, min=None, max=None,
                          median=None, mode='A', top_values=[('A',40),('B',30),('C',30)]),
        ],
        total_missing_cells=0,
        duplicate_row_count=0,
    )
    
    stats = [
        StatisticalTestResult(
            test_name="t-test",
            test_type="t_test_independent",
            statistic=2.5,
            p_value=0.015,
            significant=True,
            interpretation="Significant difference",
        )
    ]
    
    viz = [
        VisualizationSpec(
            chart_id="hist1",
            chart_type="histogram",
            title="Distribution of num1",
            plotly_spec={"data": [{"type": "histogram", "x": [1,2,3]}]}
        )
    ]
    
    insights = [
        Insight(
            insight_id="ins1",
            severity="info",
            title="Key finding",
            description="The data shows...",
            source="test",
        )
    ]
    
    metadata = RunMetadata(
        execution_time_ms=123,
        package_version="0.2.0",
        row_count=100,
        column_count=2,
        tests_executed=1,
        tests_skipped=0,
        visualizations_generated=1,
        insights_generated=1,
        mode="automated",
        llm_enabled=False,
    )
    
    result = AnalysisResult(
        summary=summary,
        statistics=stats,
        visualizations=viz,
        insights=insights,
        metadata=metadata,
        time_series_analysis=[],
        clusters=[],
    )
    
    pptx_bytes = generate_pptx_report(result)
    assert isinstance(pptx_bytes, bytes)
    assert len(pptx_bytes) > 0