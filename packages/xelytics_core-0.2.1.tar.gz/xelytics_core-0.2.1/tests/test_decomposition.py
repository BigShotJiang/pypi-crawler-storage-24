"""
Tests for time series decomposition module.
"""

import unittest
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import sys
import os
import warnings

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))


class TestTimeSeriesDecomposition(unittest.TestCase):
    """Test time series decomposition methods."""
    
    def setUp(self):
        """Set up test data."""
        warnings.filterwarnings("ignore", category=FutureWarning)
        warnings.filterwarnings("ignore", category=UserWarning)
        
        # Create test time series with trend and seasonality
        np.random.seed(42)
        dates = pd.date_range('2024-01-01', periods=365, freq='D')
        
        # Create synthetic data with trend and seasonality
        trend = np.linspace(0, 10, 365)
        seasonal = 5 * np.sin(2 * np.pi * np.arange(365) / 365 * 7)  # Weekly seasonality
        noise = np.random.normal(0, 1, 365)
        
        # Additive model
        additive_series = trend + seasonal + noise
        
        # Multiplicative model (must be positive)
        multiplicative_series = trend * (1 + 0.2 * np.sin(2 * np.pi * np.arange(365) / 365 * 7)) * np.exp(noise * 0.1)
        multiplicative_series = np.abs(multiplicative_series) + 1  # Ensure positivity
        
        self.additive_df = pd.DataFrame({
            'date': dates,
            'value': additive_series
        }).set_index('date')['value']
        
        self.multiplicative_df = pd.DataFrame({
            'date': dates,
            'value': multiplicative_series
        }).set_index('date')['value']
        
        # Short series for edge cases
        self.short_series = pd.Series(
            [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
            index=pd.date_range('2024-01-01', periods=10, freq='D')
        )
    
    def tearDown(self):
        """Clean up after tests."""
        warnings.resetwarnings()
    
    def test_decomposer_initialization(self):
        """Test that decomposer initializes correctly."""
        from xelytics.timeseries.decomposition import (
            TimeSeriesDecomposer, DecompositionMethod, ModelType
        )
        
        decomposer = TimeSeriesDecomposer(
            method=DecompositionMethod.STL,
            model_type=ModelType.ADDITIVE,
            period=7,
            robust=True
        )
        
        self.assertEqual(decomposer.method, DecompositionMethod.STL)
        self.assertEqual(decomposer.model_type, ModelType.ADDITIVE)
        self.assertEqual(decomposer.period, 7)
        self.assertTrue(decomposer.robust)
        
        print("✓ Decomposer initialization works")
    
    def test_stl_decomposition_additive(self):
        """Test STL decomposition with additive model."""
        from xelytics.timeseries.decomposition import decompose_time_series
        
        # Test additive series
        result = decompose_time_series(
            self.additive_df,
            method='stl',
            model_type='additive',
            period=7
        )
        
        self.assertEqual(result.method.value, 'stl')
        self.assertEqual(result.model_type.value, 'additive')
        self.assertEqual(result.period, 7)
        self.assertTrue(result.is_additive)
        
        # Check shapes
        self.assertEqual(len(result.original), len(self.additive_df))
        self.assertEqual(len(result.trend), len(self.additive_df))
        self.assertEqual(len(result.seasonal), len(self.additive_df))
        self.assertEqual(len(result.residual), len(self.additive_df))
        
        print("✓ STL additive decomposition works")
    
    def test_seasonal_decomposition_multiplicative(self):
        """Test seasonal decomposition with multiplicative model."""
        from xelytics.timeseries.decomposition import decompose_time_series
        
        # Test multiplicative series
        result = decompose_time_series(
            self.multiplicative_df,
            method='seasonal_decompose',
            model_type='multiplicative',
            period=7
        )
        
        self.assertEqual(result.method.value, 'seasonal_decompose')
        self.assertEqual(result.model_type.value, 'multiplicative')
        self.assertFalse(result.is_additive)
        
        # Check that components multiply back to original (approximately)
        reconstructed = result.trend * result.seasonal * result.residual
        reconstruction_error = (self.multiplicative_df - reconstructed).abs().mean()
        
        self.assertLess(reconstruction_error, 0.1)
        
        print("✓ Seasonal multiplicative decomposition works")
    
    def test_auto_model_type_detection(self):
        """Test automatic model type detection."""
        from xelytics.timeseries.decomposition import TimeSeriesDecomposer
        
        # Test additive series
        decomposer_add = TimeSeriesDecomposer(model_type='auto', period=7)
        result_add = decomposer_add.decompose(self.additive_df)
        
        # Should detect additive
        self.assertEqual(result_add.model_type.value, 'additive')
        
        # Test multiplicative series  
        decomposer_mult = TimeSeriesDecomposer(model_type='auto', period=7)
        result_mult = decomposer_mult.decompose(self.multiplicative_df)
        
        # May detect multiplicative (or additive if not clear)
        # Just ensure it runs without error
        self.assertIn(result_mult.model_type.value, ['additive', 'multiplicative'])
        
        print("✓ Auto model type detection works")

    def test_period_inference(self):
        """Test automatic period inference."""
        from xelytics.timeseries.decomposition import TimeSeriesDecomposer
        
        # Daily data should infer weekly period
        decomposer = TimeSeriesDecomposer(period=None)
        result = decomposer.decompose(self.additive_df)
        
        # Should infer period 7 for daily data
        self.assertIn(result.period, [1, 7])  # Could be 1 or 7
        
        print("✓ Period inference works")
    
    def test_decomposition_result_methods(self):
        """Test decomposition result methods."""
        from xelytics.timeseries.decomposition import decompose_time_series
        
        result = decompose_time_series(
            self.additive_df,
            method='seasonal_decompose',
            period=7
        )
        
        # Test to_dataframe
        df = result.to_dataframe()
        self.assertIsInstance(df, pd.DataFrame)
        self.assertEqual(len(df), len(self.additive_df))
        self.assertListEqual(list(df.columns), ['original', 'trend', 'seasonal', 'residual'])
        
        # Test summary
        summary = result.summary()
        self.assertIsInstance(summary, dict)
        self.assertIn('method', summary)
        self.assertIn('variance_explained', summary)
        self.assertIn('stats', summary)
        
        print("✓ Decomposition result methods work")
    
    def test_short_series_handling(self):
        """Test decomposition with short time series."""
        from xelytics.timeseries.decomposition import decompose_time_series
        
        # Should handle short series gracefully - use freq='D' to help with period inference
        result = decompose_time_series(self.short_series, freq='D', period=1)
        
        self.assertEqual(len(result.original), len(self.short_series))
        self.assertIsNotNone(result.trend)
        self.assertIsNotNone(result.seasonal)
        self.assertIsNotNone(result.residual)
        
        print("✓ Short series handling works")
    
    def test_convenience_function(self):
        """Test the convenience decompose_time_series function."""
        from xelytics.timeseries.decomposition import decompose_time_series
        
        result = decompose_time_series(
            self.additive_df,
            method='stl',
            model_type='additive',
            period=7,
            robust=True
        )
        
        self.assertEqual(result.method.value, 'stl')
        self.assertEqual(result.model_type.value, 'additive')
        
        print("✓ Convenience function works")
    
    def test_missing_values_handling(self):
        """Test decomposition with missing values."""
        from xelytics.timeseries.decomposition import decompose_time_series
        
        # Create series with missing values
        series_with_nan = self.additive_df.copy()
        series_with_nan.iloc[10:20] = np.nan  # Add missing values
        
        # Should handle NaN values
        result = decompose_time_series(series_with_nan, period=7)
        
        # Check that result has no NaN values (except maybe at edges)
        self.assertEqual(result.trend.isna().sum(), 0)
        self.assertEqual(result.seasonal.isna().sum(), 0)
        self.assertLess(result.residual.isna().sum(), 10)  # Allow some at edges
        
        print("✓ Missing values handling works")


def run_decomposition_tests():
    """Run all decomposition tests."""
    loader = unittest.TestLoader()
    suite = loader.loadTestsFromTestCase(TestTimeSeriesDecomposition)
    
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    print("\n" + "="*70)
    print("MODULE 2.2: TIME SERIES DECOMPOSITION - TEST RESULTS")
    print("="*70)
    
    total = result.testsRun
    passed = total - len(result.failures) - len(result.errors)
    
    print(f"\n📊 TEST SUMMARY:")
    print(f"  Total Tests: {total}")
    print(f"  Passed: {passed}")
    print(f"  Failed: {len(result.failures)}")
    print(f"  Errors: {len(result.errors)}")
    
    if result.wasSuccessful():
        print("\n✅ ALL DECOMPOSITION TESTS PASSED!")
        print("✅ Phase 2.2.1: Decomposition Module is READY")
    else:
        print("\n❌ Some tests failed:")
        for test, traceback in result.failures:
            print(f"  - {test}")
    
    print("="*70)
    
    return result.wasSuccessful()


if __name__ == '__main__':
    success = run_decomposition_tests()
    sys.exit(0 if success else 1)