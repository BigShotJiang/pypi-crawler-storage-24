"""
Test Redis caching functionality.
Requires a running Redis server (can be local or remote).
"""

import time
import pandas as pd
import numpy as np
from xelytics import analyze, AnalysisConfig
from xelytics.cache import get_cache, clear_cache

def test_caching_speedup():
    """Compare analysis time with and without caching."""
    
    # Create a moderately sized dataset
    np.random.seed(42)
    n_rows = 10000
    df = pd.DataFrame({
        'numeric1': np.random.normal(0, 1, n_rows),
        'numeric2': np.random.normal(10, 5, n_rows),
        'categorical1': np.random.choice(['A', 'B', 'C', 'D'], n_rows),
        'categorical2': np.random.choice(['X', 'Y', 'Z'], n_rows),
        'datetime': pd.date_range('2025-01-01', periods=n_rows, freq='T')
    })
    
    # Config with caching disabled
    config_no_cache = AnalysisConfig(
        mode="automated",
        enable_caching=False,
        enable_llm_insights=False
    )
    
    # Config with Redis caching
    config_redis = AnalysisConfig(
        mode="automated",
        enable_caching=True,
        cache_backend="redis",
        cache_config={
            "host": "localhost",  # change if needed
            "port": 6379,
            "db": 0,
            "ttl": 3600,
            "key_prefix": "xelytics_test:"
        },
        enable_llm_insights=False
    )
    
    # First run without cache
    print("Running without cache...")
    start = time.time()
    result1 = analyze(df, config=config_no_cache)
    time_no_cache = time.time() - start
    print(f"Without cache: {time_no_cache:.2f} seconds")
    
    # Clear any existing cache
    clear_cache()
    
    # First run with cache (populates cache)
    print("\nFirst run with cache (populating)...")
    start = time.time()
    result2 = analyze(df, config=config_redis)
    time_cache_first = time.time() - start
    print(f"First run with cache: {time_cache_first:.2f} seconds")
    
    # Second run with cache (should be faster)
    print("\nSecond run with cache (should be faster)...")
    start = time.time()
    result3 = analyze(df, config=config_redis)
    time_cache_second = time.time() - start
    print(f"Second run with cache: {time_cache_second:.2f} seconds")
    
    # Verify results are identical (ignoring execution time)
    assert result1.metadata.row_count == result2.metadata.row_count
    assert result1.metadata.row_count == result3.metadata.row_count
    
    print(f"\nSpeedup: {time_no_cache / time_cache_second:.2f}x faster")
    print("Caching test passed!")


def test_cache_invalidation():
    """Test that cache is invalidated when data changes."""
    
    df1 = pd.DataFrame({'A': [1, 2, 3], 'B': [4, 5, 6]})
    df2 = pd.DataFrame({'A': [1, 2, 3], 'B': [4, 5, 7]})  # one value different
    
    config = AnalysisConfig(
        mode="automated",
        enable_caching=True,
        cache_backend="redis",
        cache_config={"host": "localhost", "port": 6379, "db": 0, "ttl": 60},
        enable_llm_insights=False
    )
    
    # Clear cache
    clear_cache()
    
    # Analyze df1
    result1 = analyze(df1, config=config)
    
    # Analyze df2 (should not reuse cache from df1)
    result2 = analyze(df2, config=config)
    
    # Check that something changed (e.g., row count same but stats may differ)
    # We'll just ensure no error
    print("Cache invalidation test passed (no crash)")


if __name__ == "__main__":
    print("=== Testing Caching Speedup ===")
    test_caching_speedup()
    print("\n=== Testing Cache Invalidation ===")
    test_cache_invalidation()