# test_postgres_connector.py
from xelytics.connectors import PostgresConnector

# Replace "your_password" with your actual Supabase password
CONNECTION_STRING = (
    "postgresql://postgres.lyqxnhhxtbofgvnobzvm:your_password@"
    "aws-1-ap-southeast-2.pooler.supabase.com:5432/postgres?sslmode=require"
)

# Initialize connector
conn = PostgresConnector(connection_string=CONNECTION_STRING)

# Connect
if conn.connect():
    print("✅ Connected to Supabase PostgreSQL")
    
    # REPLACE 'your_actual_table' with a real table name from your database
    # You can also run: SHOW TABLES; or \dt in psql to list tables
    table_name = "users"  # ← CHANGE THIS
    
    df = conn.query(f"SELECT * FROM {table_name} LIMIT 5")
    print(f"Query returned {len(df)} rows")
    print(df.head())
    
    conn.disconnect()
else:
    print("❌ Connection failed")