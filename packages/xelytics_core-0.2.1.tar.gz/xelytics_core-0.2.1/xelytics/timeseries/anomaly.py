"""
Anomaly detection module for xelytics-core v0.2.0.
Implements statistical, machine learning, and decomposition-based anomaly detection.
"""

import pandas as pd
import numpy as np
from typing import Dict, Any, List, Optional, Tuple, Union
from dataclasses import dataclass, field
import warnings
from enum import Enum
from scipy import stats
from sklearn.ensemble import IsolationForest
from sklearn.neighbors import LocalOutlierFactor


class AnomalyMethod(str, Enum):
    """Available anomaly detection methods."""
    Z_SCORE = "z_score"
    IQR = "iqr"
    ISOLATION_FOREST = "isolation_forest"
    LOCAL_OUTLIER_FACTOR = "local_outlier_factor"
    STL_RESIDUALS = "stl_residuals"
    ROLLING_STATS = "rolling_stats"


@dataclass
class AnomalyResult:
    """Result of anomaly detection."""
    series: pd.Series
    anomalies: pd.Series  # Boolean series indicating anomalies
    scores: Optional[pd.Series] = None  # Anomaly scores
    method: AnomalyMethod = None
    threshold: Optional[float] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def summary(self) -> Dict[str, Any]:
        """Get summary statistics of anomalies."""
        anomaly_count = self.anomalies.sum()
        total_count = len(self.anomalies)
        
        return {
            'method': self.method.value if self.method else 'unknown',
            'anomaly_count': int(anomaly_count),
            'anomaly_percentage': float(anomaly_count / total_count * 100),
            'threshold': self.threshold,
            'total_points': total_count,
            'anomaly_indices': self.anomalies[self.anomalies].index.tolist(),
            'anomaly_values': self.series[self.anomalies].tolist() if self.scores is not None else None
        }
    
    def to_dataframe(self) -> pd.DataFrame:
        """Convert anomaly results to DataFrame."""
        df = pd.DataFrame({
            'value': self.series,
            'is_anomaly': self.anomalies
        })
        
        if self.scores is not None:
            df['anomaly_score'] = self.scores
            
        return df
    
    def plot(self, figsize: Tuple[int, int] = (12, 6), title: Optional[str] = None) -> Any:
        """Plot anomalies."""
        import matplotlib.pyplot as plt
        
        fig, ax = plt.subplots(figsize=figsize)
        
        # Plot time series
        ax.plot(self.series.index, self.series.values, 
                label='Time Series', color='black', linewidth=1.5)
        
        # Highlight anomalies
        anomaly_idx = self.series.index[self.anomalies]
        anomaly_vals = self.series[self.anomalies]
        
        if len(anomaly_idx) > 0:
            ax.scatter(anomaly_idx, anomaly_vals, 
                      color='red', s=100, zorder=5,
                      label=f'Anomalies ({len(anomaly_idx)} found)')
        
        # Title and labels
        if title:
            ax.set_title(title)
        else:
            method_name = self.method.value.replace('_', ' ').title() if self.method else 'Anomaly Detection'
            ax.set_title(f'{method_name} - {len(anomaly_idx)} anomalies detected')
        
        ax.set_xlabel('Time')
        ax.set_ylabel('Value')
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        return fig


class TimeSeriesAnomalyDetector:
    """
    Anomaly detection engine for time series.
    
    Supports multiple detection methods:
    - Statistical: Z-score, IQR
    - Machine Learning: Isolation Forest, Local Outlier Factor
    - Decomposition-based: STL residuals
    - Rolling statistics
    """
    
    def __init__(self, 
                 method: AnomalyMethod = AnomalyMethod.Z_SCORE,
                 contamination: float = 0.1,
                 window_size: int = 30,
                 threshold: float = 3.0,
                 seasonal_period: Optional[int] = None):
        """
        Initialize the anomaly detector.
        
        Args:
            method: Anomaly detection method
            contamination: Expected proportion of outliers (for ML methods)
            window_size: Window size for rolling statistics
            threshold: Threshold for statistical methods (e.g., z-score threshold)
            seasonal_period: Seasonal period for STL decomposition
        """
        self.method = method
        self.contamination = contamination
        self.window_size = window_size
        self.threshold = threshold
        self.seasonal_period = seasonal_period
        
    def detect(self, series: pd.Series, **kwargs) -> AnomalyResult:
        """
        Detect anomalies in time series.
        
        Args:
            series: Time series data
            **kwargs: Additional method-specific parameters
            
        Returns:
            AnomalyResult object
        """
        # Ensure series is sorted
        series = series.sort_index()
        
        # Handle NaN values
        if series.isna().any():
            series_clean = series.fillna(method='ffill').fillna(method='bfill')
            if series.isna().sum() > 0:
                warnings.warn(f"Found {series.isna().sum()} NaN values. Filled with forward/backward fill.")
        else:
            series_clean = series.copy()
        
        # Dispatch to appropriate detection method
        if self.method == AnomalyMethod.Z_SCORE:
            return self._detect_z_score(series_clean, **kwargs)
        elif self.method == AnomalyMethod.IQR:
            return self._detect_iqr(series_clean, **kwargs)
        elif self.method == AnomalyMethod.ISOLATION_FOREST:
            return self._detect_isolation_forest(series_clean, **kwargs)
        elif self.method == AnomalyMethod.LOCAL_OUTLIER_FACTOR:
            return self._detect_lof(series_clean, **kwargs)
        elif self.method == AnomalyMethod.STL_RESIDUALS:
            return self._detect_stl_residuals(series_clean, **kwargs)
        elif self.method == AnomalyMethod.ROLLING_STATS:
            return self._detect_rolling_stats(series_clean, **kwargs)
        else:
            raise ValueError(f"Unknown anomaly detection method: {self.method}")
    
    def _detect_z_score(self, series: pd.Series, 
                       threshold: Optional[float] = None) -> AnomalyResult:
        """Detect anomalies using Z-score method."""
        if threshold is None:
            threshold = self.threshold
        
        # Calculate z-scores
        mean = np.mean(series)
        std = np.std(series)
        
        if std == 0:
            # All values are the same, no anomalies
            scores = pd.Series(0, index=series.index)
            anomalies = pd.Series(False, index=series.index)
        else:
            z_scores = np.abs((series - mean) / std)
            scores = pd.Series(z_scores, index=series.index)
            anomalies = scores > threshold
        
        return AnomalyResult(
            series=series,
            anomalies=anomalies,
            scores=scores,
            method=AnomalyMethod.Z_SCORE,
            threshold=threshold,
            metadata={
                'mean': float(mean),
                'std': float(std),
                'threshold_used': float(threshold)
            }
        )
    
    def _detect_iqr(self, series: pd.Series, 
                   multiplier: float = 1.5) -> AnomalyResult:
        """Detect anomalies using IQR (Interquartile Range) method."""
        q1 = np.percentile(series, 25)
        q3 = np.percentile(series, 75)
        iqr = q3 - q1
        
        if iqr == 0:
            # Use median absolute deviation as fallback
            median = np.median(series)
            mad = np.median(np.abs(series - median))
            lower_bound = median - multiplier * mad
            upper_bound = median + multiplier * mad
        else:
            lower_bound = q1 - multiplier * iqr
            upper_bound = q3 + multiplier * iqr
        
        anomalies = (series < lower_bound) | (series > upper_bound)
        
        # Calculate anomaly scores (distance from bounds)
        below_lower = lower_bound - series[series < lower_bound]
        above_upper = series[series > upper_bound] - upper_bound
        scores = pd.Series(0.0, index=series.index)
        
        if not below_lower.empty:
            scores[below_lower.index] = below_lower / (lower_bound if lower_bound != 0 else 1)
        if not above_upper.empty:
            scores[above_upper.index] = above_upper / (upper_bound if upper_bound != 0 else 1)
        
        return AnomalyResult(
            series=series,
            anomalies=anomalies,
            scores=scores,
            method=AnomalyMethod.IQR,
            threshold=multiplier,
            metadata={
                'q1': float(q1),
                'q3': float(q3),
                'iqr': float(iqr),
                'lower_bound': float(lower_bound),
                'upper_bound': float(upper_bound)
            }
        )
    
    def _detect_isolation_forest(self, series: pd.Series,
                               contamination: Optional[float] = None,
                               random_state: int = 42) -> AnomalyResult:
        """Detect anomalies using Isolation Forest."""
        if contamination is None:
            contamination = self.contamination
        
        # Reshape for sklearn
        X = series.values.reshape(-1, 1)
        
        # Fit Isolation Forest
        iso_forest = IsolationForest(
            contamination=contamination,
            random_state=random_state,
            n_estimators=100
        )
        
        anomaly_labels = iso_forest.fit_predict(X)
        anomaly_scores = iso_forest.score_samples(X)
        
        # Convert to boolean (1 for normal, -1 for anomaly)
        anomalies = pd.Series(anomaly_labels == -1, index=series.index)
        scores = pd.Series(-anomaly_scores, index=series.index)  # Negative because lower scores = more anomalous
        
        return AnomalyResult(
            series=series,
            anomalies=anomalies,
            scores=scores,
            method=AnomalyMethod.ISOLATION_FOREST,
            threshold=contamination,
            metadata={
                'contamination': contamination,
                'random_state': random_state,
                'n_estimators': 100
            }
        )
    
    def _detect_lof(self, series: pd.Series,
                   contamination: Optional[float] = None,
                   n_neighbors: int = 20) -> AnomalyResult:
        """Detect anomalies using Local Outlier Factor."""
        if contamination is None:
            contamination = self.contamination
        
        # Reshape for sklearn
        X = series.values.reshape(-1, 1)
        
        # Fit LOF
        lof = LocalOutlierFactor(
            n_neighbors=n_neighbors,
            contamination=contamination
        )
        
        anomaly_labels = lof.fit_predict(X)
        anomaly_scores = lof.negative_outlier_factor_
        
        # Convert to boolean (1 for normal, -1 for anomaly)
        anomalies = pd.Series(anomaly_labels == -1, index=series.index)
        scores = pd.Series(-anomaly_scores, index=series.index)
        
        return AnomalyResult(
            series=series,
            anomalies=anomalies,
            scores=scores,
            method=AnomalyMethod.LOCAL_OUTLIER_FACTOR,
            threshold=contamination,
            metadata={
                'contamination': contamination,
                'n_neighbors': n_neighbors
            }
        )
    
    def _detect_stl_residuals(self, series: pd.Series,
                            period: Optional[int] = None,
                            threshold: float = 3.0) -> AnomalyResult:
        """Detect anomalies using STL decomposition residuals."""
        from .decomposition import decompose_time_series
        
        if period is None:
            period = self.seasonal_period or 7  # Default to weekly
        
        # Decompose time series
        decomposition = decompose_time_series(
            series,
            method='stl',
            period=period,
            model_type='additive'
        )
        
        # Use residuals for anomaly detection
        residuals = decomposition.residual
        
        # Detect anomalies in residuals using Z-score
        mean_resid = np.mean(residuals)
        std_resid = np.std(residuals)
        
        if std_resid == 0:
            z_scores = pd.Series(0, index=residuals.index)
        else:
            z_scores = np.abs((residuals - mean_resid) / std_resid)
        
        anomalies = z_scores > threshold
        
        return AnomalyResult(
            series=series,
            anomalies=anomalies,
            scores=pd.Series(z_scores, index=series.index),
            method=AnomalyMethod.STL_RESIDUALS,
            threshold=threshold,
            metadata={
                'period': period,
                'mean_residual': float(mean_resid),
                'std_residual': float(std_resid),
                'decomposition_method': 'stl'
            }
        )
    
    def _detect_rolling_stats(self, series: pd.Series,
                            window_size: Optional[int] = None,
                            threshold: float = 3.0) -> AnomalyResult:
        """Detect anomalies using rolling statistics."""
        if window_size is None:
            window_size = self.window_size
        
        # Calculate rolling statistics
        rolling_mean = series.rolling(window=window_size, center=True, min_periods=1).mean()
        rolling_std = series.rolling(window=window_size, center=True, min_periods=1).std()
        
        # Handle zero standard deviation
        rolling_std_adj = rolling_std.copy()
        rolling_std_adj[rolling_std_adj == 0] = 1e-10
        
        # Calculate z-scores based on rolling statistics
        z_scores = np.abs((series - rolling_mean) / rolling_std_adj)
        
        anomalies = z_scores > threshold
        
        return AnomalyResult(
            series=series,
            anomalies=anomalies,
            scores=pd.Series(z_scores, index=series.index),
            method=AnomalyMethod.ROLLING_STATS,
            threshold=threshold,
            metadata={
                'window_size': window_size,
                'rolling_mean_mean': float(rolling_mean.mean()),
                'rolling_std_mean': float(rolling_std.mean())
            }
        )


# Convenience functions
def detect_anomalies(series: pd.Series,
                    method: str = "z_score",
                    **kwargs) -> AnomalyResult:
    """
    Convenience function for anomaly detection.
    
    Args:
        series: Time series data
        method: Anomaly detection method
        **kwargs: Additional arguments for TimeSeriesAnomalyDetector
        
    Returns:
        AnomalyResult object
    """
    detector = TimeSeriesAnomalyDetector(
        method=AnomalyMethod(method),
        **kwargs
    )
    return detector.detect(series)


def validate_anomalies(result: AnomalyResult,
                      actual_anomalies: Optional[pd.Series] = None) -> Dict[str, Any]:
    """
    Validate anomaly detection results.
    
    Args:
        result: AnomalyResult object
        actual_anomalies: Optional ground truth anomalies
        
    Returns:
        Dictionary with validation metrics
    """
    validation = {
        'summary': result.summary(),
        'metrics': {},
        'validation': {}
    }
    
    # Calculate basic metrics
    anomaly_percentage = result.anomalies.mean() * 100
    
    validation['metrics']['anomaly_percentage'] = float(anomaly_percentage)
    validation['metrics']['anomaly_count'] = int(result.anomalies.sum())
    
    # If ground truth is provided, calculate classification metrics
    if actual_anomalies is not None:
        # Align indices
        common_idx = result.anomalies.index.intersection(actual_anomalies.index)
        if len(common_idx) > 0:
            pred = result.anomalies.loc[common_idx]
            actual = actual_anomalies.loc[common_idx]
            
            # Calculate confusion matrix
            tp = ((pred == True) & (actual == True)).sum()
            tn = ((pred == False) & (actual == False)).sum()
            fp = ((pred == True) & (actual == False)).sum()
            fn = ((pred == False) & (actual == True)).sum()
            
            # Calculate metrics
            precision = tp / (tp + fp) if (tp + fp) > 0 else 0
            recall = tp / (tp + fn) if (tp + fn) > 0 else 0
            f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0
            accuracy = (tp + tn) / (tp + tn + fp + fn) if (tp + tn + fp + fn) > 0 else 0
            
            validation['validation'] = {
                'true_positives': int(tp),
                'true_negatives': int(tn),
                'false_positives': int(fp),
                'false_negatives': int(fn),
                'precision': float(precision),
                'recall': float(recall),
                'f1_score': float(f1),
                'accuracy': float(accuracy)
            }
    
    return validation