"""
Time series detection module for xelytics-core v0.2.0
Detects datetime columns, infers frequency, and validates time series data.
"""

import pandas as pd
import numpy as np
from typing import List, Dict, Any, Optional, Tuple, Union
from datetime import datetime, timedelta
import warnings
from dataclasses import dataclass, field


@dataclass
class TimeSeriesDetectionResult:
    """Result of time series detection for a single column."""
    column_name: str
    is_time_series: bool
    is_datetime: bool
    is_monotonic: bool
    frequency: Optional[str] = None
    inferred_frequency: Optional[str] = None
    missing_timestamps: List[datetime] = field(default_factory=list)
    duplicate_timestamps: List[datetime] = field(default_factory=list)
    has_gaps: bool = False
    gap_percentage: float = 0.0
    sample_size: int = 0
    date_range: Tuple[Optional[datetime], Optional[datetime]] = (None, None)
    suggestions: List[str] = field(default_factory=list)


@dataclass
class TimeSeriesCharacteristics:
    """Characteristics of a detected time series."""
    column_name: str
    frequency: str
    observation_count: int
    date_range: Tuple[datetime, datetime]
    is_regular: bool
    is_complete: bool
    missing_ratio: float
    has_seasonality: bool = False
    seasonality_period: Optional[int] = None
    has_trend: bool = False
    is_stationary: bool = False


class TimeSeriesDetector:
    """Detects and characterizes time series data in DataFrames."""
    
    # Common datetime formats for parsing
    DATETIME_FORMATS = [
        '%Y-%m-%d', '%Y/%m/%d', '%d-%m-%Y', '%d/%m/%Y',
        '%Y-%m-%d %H:%M:%S', '%Y/%m/%d %H:%M:%S',
        '%Y-%m-%d %H:%M', '%Y/%m/%d %H:%M',
        '%d-%m-%Y %H:%M:%S', '%d/%m/%Y %H:%M:%S',
        '%Y%m%d', '%Y%m%d%H%M%S',
        '%b %d, %Y', '%B %d, %Y',
        '%d %b %Y', '%d %B %Y',
    ]
    
    # Common time series frequencies
    FREQUENCY_MAPPING = {
        'YS': 'year_start',
        'Y': 'year',
        'QS': 'quarter_start',
        'Q': 'quarter',
        'MS': 'month_start',
        'M': 'month',
        'W': 'week',
        'D': 'day',
        'h': 'hour', 
        'H': 'hour', 
        'T': 'minute',
        'min': 'minute', 
        'S': 'second',
        'L': 'millisecond',
        'U': 'microsecond',
        'irregular': 'irregular',
    }
    
    def __init__(self, max_missing_ratio: float = 0.3, min_observations: int = 10):
        """
        Initialize the time series detector.
        
        Args:
            max_missing_ratio: Maximum allowed ratio of missing timestamps
            min_observations: Minimum number of observations for a valid time series
        """
        self.max_missing_ratio = max_missing_ratio
        self.min_observations = min_observations
    
    def detect(self, df: pd.DataFrame, datetime_columns: Optional[List[str]] = None) -> List[TimeSeriesDetectionResult]:
        """
        Detect time series columns in a DataFrame.
        
        Args:
            df: Input DataFrame
            datetime_columns: Optional list of column names to check (if None, check all columns)
            
        Returns:
            List of detection results for each column
        """
        if datetime_columns is None:
            # Check all columns
            datetime_columns = df.columns.tolist()
        
        results = []
        
        for col in datetime_columns:
            if col not in df.columns:
                continue
            
            result = self._analyze_column(df[col], col)
            results.append(result)
        
        return results
    
    def _analyze_column(self, series: pd.Series, column_name: str) -> TimeSeriesDetectionResult:
        """Analyze a single column for time series characteristics."""
        
        # Initialize result
        result = TimeSeriesDetectionResult(
            column_name=column_name,
            is_time_series=False,
            is_datetime=False,
            is_monotonic=False,
            sample_size=len(series)
        )
        
        # Check if column is already datetime
        if pd.api.types.is_datetime64_any_dtype(series):
            result.is_datetime = True
            datetime_series = series
        else:
            # Try to convert to datetime
            datetime_series = self._try_convert_to_datetime(series)
            result.is_datetime = datetime_series is not None
        
        if not result.is_datetime:
            result.suggestions.append(f"Column '{column_name}' could not be parsed as datetime")
            return result
        
        # Now analyze the datetime series
        datetime_series = pd.to_datetime(datetime_series)
        
        # Check for monotonicity
        result.is_monotonic = self._is_monotonic(datetime_series)
        
        if not result.is_monotonic:
            result.suggestions.append(f"Column '{column_name}' is not monotonic (not strictly increasing/decreasing)")
        
        # Check for missing values
        missing_mask = datetime_series.isna()
        if missing_mask.any():
            result.suggestions.append(f"Column '{column_name}' has {missing_mask.sum()} missing values")
        
        # Remove missing values for further analysis
        clean_series = datetime_series.dropna()
        
        if len(clean_series) < self.min_observations:
            result.suggestions.append(
                f"Column '{column_name}' has only {len(clean_series)} valid observations "
                f"(minimum required: {self.min_observations})"
            )
            return result
        
        # Infer frequency
        frequency = self._infer_frequency(clean_series)
        result.frequency = frequency
        result.inferred_frequency = self.FREQUENCY_MAPPING.get(frequency, frequency)
        
        # Check for gaps
        gaps_result = self._check_for_gaps(clean_series, frequency)
        result.has_gaps = gaps_result['has_gaps']
        result.gap_percentage = gaps_result['gap_percentage']
        result.missing_timestamps = gaps_result['missing_timestamps']
        
        if result.has_gaps:
            result.suggestions.append(
                f"Column '{column_name}' has gaps ({result.gap_percentage:.1%} missing timestamps)"
            )
        
        # Check for duplicates
        duplicates = clean_series[clean_series.duplicated()].tolist()
        result.duplicate_timestamps = duplicates
        
        if duplicates:
            result.suggestions.append(
                f"Column '{column_name}' has {len(duplicates)} duplicate timestamps"
            )
        
        # Determine if it's a valid time series
        result.is_time_series = (
            result.is_datetime and
            result.is_monotonic and
            not result.has_gaps and
            len(duplicates) == 0 and
            result.gap_percentage <= self.max_missing_ratio
        )
        
        # Get date range
        if not clean_series.empty:
            result.date_range = (clean_series.min(), clean_series.max())
        
        return result
    
    def _try_convert_to_datetime(self, series: pd.Series) -> Optional[pd.Series]:
        """Try to convert a series to datetime using multiple formats."""
        # First try pandas automatic conversion
        try:
            return pd.to_datetime(series, errors='coerce')
        except:
            pass
        
        # Try common formats
        for fmt in self.DATETIME_FORMATS:
            try:
                return pd.to_datetime(series, format=fmt, errors='coerce')
            except:
                continue
        
        return None
    
    def _is_monotonic(self, series: pd.Series) -> bool:
        """Check if a datetime series is monotonic (strictly increasing or decreasing)."""
        if len(series) <= 1:
            return True
        
        # Remove NaN values for checking
        clean_series = series.dropna()
        
        if len(clean_series) <= 1:
            return True
        
        # Check for monotonic increase
        is_increasing = (clean_series.diff().dropna() >= pd.Timedelta(0)).all()
        is_decreasing = (clean_series.diff().dropna() <= pd.Timedelta(0)).all()
        
        return bool(is_increasing or is_decreasing)
    
    def _infer_frequency(self, datetime_series: pd.Series) -> str:
        """Infer the frequency of a datetime series."""
        if len(datetime_series) < 3:
            return 'irregular'
        
        # Sort the series first
        datetime_series = datetime_series.sort_values()
        
        # First try pandas inference
        try:
            inferred = pd.infer_freq(datetime_series)
            if inferred:
                # Normalize frequencies
                if inferred == 'H':
                    return 'h'
                elif inferred.startswith('W-'):
                    return 'W'  # Normalize weekly frequencies
                return inferred
        except Exception:
            pass
        
        # Calculate differences
        diffs = datetime_series.diff().dropna()
        if diffs.empty:
            return 'irregular'
        
        # For time series with gaps, we need to be smarter
        # Find the most common difference (mode)
        try:
            mode_diff = diffs.mode()
            if not mode_diff.empty:
                expected_diff = mode_diff.iloc[0]
                
                # Count how many differences are close to the expected difference
                # Allow 10% tolerance
                tolerance = expected_diff * 0.1
                close_count = ((diffs >= expected_diff - tolerance) & 
                            (diffs <= expected_diff + tolerance)).sum()
                
                # If at least 70% of differences are close to the mode, we have a regular frequency
                if close_count / len(diffs) >= 0.7:
                    # Map to frequency string
                    return self._map_diff_to_frequency(expected_diff)
        except Exception:
            pass
        
        # If we can't find a regular frequency, check if it's daily with gaps
        # Calculate mean difference in days
        mean_diff_days = diffs.mean().total_seconds() / (24 * 3600)
        
        # If mean is around 1 day, it's daily with some gaps
        if 0.9 <= mean_diff_days <= 1.1:
            return 'D'
        
        return 'irregular'

    def _map_diff_to_frequency(self, diff: pd.Timedelta) -> str:
        """Map a timedelta to a frequency string."""
        seconds = diff.total_seconds()
        
        # Map to frequency
        if seconds >= 365 * 24 * 3600:  # ~1 year
            return 'YS'
        elif seconds >= 90 * 24 * 3600:  # ~3 months
            return 'QS'
        elif seconds >= 28 * 24 * 3600:  # ~4 weeks
            return 'MS'
        elif seconds >= 7 * 24 * 3600:  # 1 week
            return 'W'
        elif seconds >= 24 * 3600:  # 1 day
            return 'D'
        elif seconds >= 3600:  # 1 hour
            return 'h'
        elif seconds >= 60:  # 1 minute
            return 'T'
        elif seconds >= 1:  # 1 second
            return 'S'
        elif seconds >= 0.001:  # 1 millisecond
            return 'L'
        else:
            return 'U'
        
    def _check_for_gaps(self, datetime_series: pd.Series, frequency: str) -> Dict[str, Any]:
        """Check for gaps in the time series with improved gap detection."""
        if frequency == 'irregular' or len(datetime_series) < 3:
            return {
                'has_gaps': False,
                'gap_percentage': 0.0,
                'missing_timestamps': []
            }
        
        try:
            # Sort the series
            datetime_series = datetime_series.sort_values()
            
            # For daily frequency, use simple approach
            if frequency == 'D':
                # Create date range from min to max
                min_date = datetime_series.min().date()
                max_date = datetime_series.max().date()
                
                # Generate all expected dates
                all_days = pd.date_range(start=min_date, end=max_date, freq='D')
                
                # Convert series to set of dates (date only, not time)
                series_dates = set(datetime_series.dt.date)
                expected_dates = set(all_days.date)
                
                # Find missing dates
                missing_dates = list(expected_dates - series_dates)
                
                if missing_dates:
                    # Convert back to datetime at midnight
                    missing_timestamps = [pd.Timestamp(date) for date in missing_dates]
                    gap_percentage = len(missing_dates) / len(expected_dates)
                    
                    return {
                        'has_gaps': gap_percentage > 0.05,  # 5% threshold
                        'gap_percentage': gap_percentage,
                        'missing_timestamps': missing_timestamps[:50]  # Limit output
                    }
            
            # For other regular frequencies
            elif frequency in ['W', 'MS', 'QS', 'YS']:
                min_date = datetime_series.min()
                max_date = datetime_series.max()
                
                # Generate all expected timestamps
                if frequency == 'W':
                    expected_ts = pd.date_range(start=min_date, end=max_date, freq='W')
                elif frequency == 'MS':
                    expected_ts = pd.date_range(start=min_date, end=max_date, freq='MS')
                elif frequency == 'QS':
                    expected_ts = pd.date_range(start=min_date, end=max_date, freq='QS')
                elif frequency == 'YS':
                    expected_ts = pd.date_range(start=min_date, end=max_date, freq='YS')
                else:
                    expected_ts = pd.date_range(start=min_date, end=max_date, freq='D')
                
                # Find missing timestamps
                series_set = set(datetime_series)
                missing_ts = [ts for ts in expected_ts if ts not in series_set]
                
                if missing_ts:
                    gap_percentage = len(missing_ts) / len(expected_ts)
                    return {
                        'has_gaps': gap_percentage > 0.05,
                        'gap_percentage': gap_percentage,
                        'missing_timestamps': missing_ts[:50]
                    }
            
            # For higher frequencies (hourly, minute, etc.) or if above methods fail
            # Use difference-based approach
            diffs = datetime_series.diff().dropna()
            
            if diffs.empty:
                return {
                    'has_gaps': False,
                    'gap_percentage': 0.0,
                    'missing_timestamps': []
                }
            
            # Try to find the most common interval (mode)
            try:
                mode_diff = diffs.mode()
                if not mode_diff.empty:
                    expected_diff = mode_diff.iloc[0]
                    
                    # Look for gaps where difference is > 1.5x expected
                    large_gaps = diffs[diffs > expected_diff * 1.5]
                    
                    if not large_gaps.empty:
                        total_expected_intervals = 0
                        missing_count = 0
                        missing_timestamps = []
                        
                        # Process each gap
                        for idx, gap_size in large_gaps.items():
                            # Find the two timestamps that bound the gap
                            prev_idx = datetime_series.index[datetime_series.index.get_loc(idx) - 1]
                            prev_time = datetime_series.loc[prev_idx]
                            
                            # Calculate how many periods are missing
                            n_missing = max(1, int(gap_size.total_seconds() / expected_diff.total_seconds()) - 1)
                            
                            if n_missing > 0:
                                # Generate missing timestamps
                                for i in range(1, n_missing + 1):
                                    missing_time = prev_time + expected_diff * i
                                    missing_timestamps.append(missing_time)
                                
                                missing_count += n_missing
                                total_expected_intervals += n_missing + 1
                            else:
                                total_expected_intervals += 1
                        
                        # Add regular intervals
                        regular_intervals = len(diffs) - len(large_gaps)
                        total_expected_intervals += regular_intervals
                        
                        gap_percentage = missing_count / total_expected_intervals if total_expected_intervals > 0 else 0.0
                        
                        return {
                            'has_gaps': gap_percentage > 0.05,
                            'gap_percentage': gap_percentage,
                            'missing_timestamps': missing_timestamps[:50]
                        }
            except Exception:
                pass
            
            return {
                'has_gaps': False,
                'gap_percentage': 0.0,
                'missing_timestamps': []
            }
            
        except Exception as e:
            # If anything goes wrong, return no gaps
            return {
                'has_gaps': False,
                'gap_percentage': 0.0,
                'missing_timestamps': []
            }
    
    def characterize(self, df: pd.DataFrame, datetime_column: str, 
                    value_column: Optional[str] = None) -> TimeSeriesCharacteristics:
        """
        Characterize a time series with basic statistics.
        
        Args:
            df: Input DataFrame
            datetime_column: Name of the datetime column
            value_column: Optional value column to analyze for trend/seasonality
            
        Returns:
            TimeSeriesCharacteristics object
        """
        if datetime_column not in df.columns:
            raise ValueError(f"Column '{datetime_column}' not found in DataFrame")
        
        # Ensure datetime column is properly typed
        datetime_series = pd.to_datetime(df[datetime_column])
        valid_mask = datetime_series.notna()
        datetime_series = datetime_series[valid_mask]
        
        if len(datetime_series) < self.min_observations:
            raise ValueError(
                f"Time series has only {len(datetime_series)} valid observations "
                f"(minimum required: {self.min_observations})"
            )
        
        # Get basic characteristics
        frequency = self._infer_frequency(datetime_series)
        
        # Check regularity
        is_regular = frequency != 'irregular'
        
        # Check completeness
        gaps_result = self._check_for_gaps(datetime_series, frequency)
        is_complete = not gaps_result['has_gaps']
        missing_ratio = gaps_result['gap_percentage']
        
        # Create characteristics object
        characteristics = TimeSeriesCharacteristics(
            column_name=datetime_column,
            frequency=frequency,
            observation_count=len(datetime_series),
            date_range=(datetime_series.min(), datetime_series.max()),
            is_regular=is_regular,
            is_complete=is_complete,
            missing_ratio=missing_ratio,
        )
        
        # If value column is provided, analyze for trend and seasonality
        if value_column and value_column in df.columns:
            value_series = df.loc[valid_mask, value_column]
            
            if len(value_series) >= 2 * (7 if frequency == 'D' else 24):  # Minimum for seasonality detection
                try:
                    # Basic trend detection
                    characteristics.has_trend = self._detect_trend(value_series)
                    
                    # Basic seasonality detection
                    if is_regular and len(value_series) >= 50:  # Enough data for seasonality
                        seasonality_result = self._detect_seasonality(value_series, frequency)
                        characteristics.has_seasonality = seasonality_result['has_seasonality']
                        characteristics.seasonality_period = seasonality_result['period']
                        
                    # Basic stationarity check
                    if len(value_series) >= 100:  # Enough for stationarity test
                        characteristics.is_stationary = self._check_stationarity(value_series)
                except Exception:
                    # If any analysis fails, continue without those characteristics
                    pass
        
        return characteristics
    
    def _detect_trend(self, series: pd.Series) -> bool:
        """Basic trend detection using linear regression."""
        try:
            from scipy import stats
            
            x = np.arange(len(series))
            y = series.values
            
            # Remove NaN values
            mask = ~np.isnan(y)
            x = x[mask]
            y = y[mask]
            
            if len(y) < 10:
                return False
            
            slope, intercept, r_value, p_value, std_err = stats.linregress(x, y)
            
            # Consider significant trend if p-value < 0.05
            return p_value < 0.05 and abs(slope) > 1e-10
            
        except Exception:
            return False
    
    def _detect_seasonality(self, series: pd.Series, frequency: str) -> Dict[str, Any]:
        """Basic seasonality detection using autocorrelation."""
        try:
            from statsmodels.tsa.stattools import acf
            
            # Determine expected seasonal period based on frequency
            if frequency == 'D':
                expected_periods = [7, 30]  # Weekly, monthly
            elif frequency == 'h':
                expected_periods = [24, 168]  # Daily, weekly
            elif frequency in ['MS', 'M']:
                expected_periods = [12]  # Yearly
            elif frequency in ['QS', 'Q']:
                expected_periods = [4]  # Yearly
            else:
                return {'has_seasonality': False, 'period': None}
            
            # Calculate autocorrelation
            nlags = min(100, len(series) // 2)
            if nlags < max(expected_periods):
                return {'has_seasonality': False, 'period': None}
            
            acf_values = acf(series.dropna(), nlags=nlags, fft=True)
            
            # Check for peaks at expected periods
            has_seasonality = False
            detected_period = None
            
            for period in expected_periods:
                if period < len(acf_values):
                    # Look for peak around the period
                    window_start = max(1, period - 2)
                    window_end = min(len(acf_values) - 1, period + 2)
                    
                    if window_start < window_end:
                        window_peak = np.max(acf_values[window_start:window_end])
                        if window_peak > 0.3:  # Threshold for seasonality
                            has_seasonality = True
                            detected_period = period
                            break
            
            return {
                'has_seasonality': has_seasonality,
                'period': detected_period
            }
            
        except Exception:
            return {'has_seasonality': False, 'period': None}
    
    def _check_stationarity(self, series: pd.Series) -> bool:
        """Basic stationarity check using augmented Dickey-Fuller test."""
        try:
            from statsmodels.tsa.stattools import adfuller
            
            # Remove NaN values
            clean_series = series.dropna()
            
            if len(clean_series) < 50:
                return False
            
            # Perform ADF test
            result = adfuller(clean_series, autolag='AIC')
            p_value = result[1]
            
            # p-value < 0.05 indicates stationarity
            return p_value < 0.05
            
        except Exception:
            return False


# Convenience functions
def detect_time_series_columns(df: pd.DataFrame, datetime_columns: Optional[List[str]] = None, **kwargs) -> List[TimeSeriesDetectionResult]:
    """Convenience function to detect time series columns."""
    detector = TimeSeriesDetector(**kwargs)
    return detector.detect(df, datetime_columns=datetime_columns)


def characterize_time_series(df: pd.DataFrame, datetime_column: str, 
                           value_column: Optional[str] = None, **kwargs) -> TimeSeriesCharacteristics:
    """Convenience function to characterize a time series."""
    detector = TimeSeriesDetector(**kwargs)
    return detector.characterize(df, datetime_column, value_column)


# Backward compatibility functions for v0.1.0
def detect_time_series(df: pd.DataFrame, datetime_column: Optional[str] = None, **kwargs) -> List[str]:
    """
    Backward compatible function to detect time series columns.
    
    Args:
        df: Input DataFrame
        datetime_column: Optional specific column to check
        **kwargs: Additional arguments for TimeSeriesDetector
        
    Returns:
        List of column names that are valid time series
    """
    detector = TimeSeriesDetector(**kwargs)
    
    if datetime_column:
        # Check specific column
        results = detector.detect(df, [datetime_column])
    else:
        # Check all columns
        results = detector.detect(df)
    
    # Return column names of valid time series
    return [r.column_name for r in results if r.is_time_series]


def analyze_time_series(df: pd.DataFrame, datetime_column: str, 
                       value_column: Optional[str] = None, **kwargs) -> Dict[str, Any]:
    """
    Backward compatible function to analyze time series.
    
    Args:
        df: Input DataFrame
        datetime_column: Name of datetime column
        value_column: Optional value column
        **kwargs: Additional arguments
        
    Returns:
        Dictionary with analysis results
    """
    detector = TimeSeriesDetector(**kwargs)
    
    try:
        # Detect time series
        detection_results = detector.detect(df, [datetime_column])
        if not detection_results:
            return {'success': False, 'error': f"Column '{datetime_column}' is not a valid time series"}
        
        detection = detection_results[0]
        
        # Characterize if value column provided
        if value_column and value_column in df.columns:
            characteristics = detector.characterize(df, datetime_column, value_column)
            char_dict = {
                'frequency': characteristics.frequency,
                'observation_count': characteristics.observation_count,
                'is_regular': characteristics.is_regular,
                'is_complete': characteristics.is_complete,
                'missing_ratio': characteristics.missing_ratio,
                'has_trend': characteristics.has_trend,
                'has_seasonality': characteristics.has_seasonality,
                'seasonality_period': characteristics.seasonality_period,
                'is_stationary': characteristics.is_stationary,
            }
        else:
            char_dict = {}
        
        return {
            'success': True,
            'datetime_column': datetime_column,
            'value_column': value_column,
            'detection': {
                'is_time_series': detection.is_time_series,
                'frequency': detection.frequency,
                'has_gaps': detection.has_gaps,
                'gap_percentage': detection.gap_percentage,
                'suggestions': detection.suggestions,
            },
            'characteristics': char_dict,
        }
        
    except Exception as e:
        return {'success': False, 'error': str(e)}


def prepare_time_series_data(df: pd.DataFrame, datetime_column: str,
                            value_columns: Optional[List[str]] = None,
                            freq: Optional[str] = None) -> pd.DataFrame:
    """
    Prepare time series data for analysis.
    
    Args:
        df: Input DataFrame
        datetime_column: Name of datetime column
        value_columns: List of value columns to include
        freq: Optional frequency for resampling
        
    Returns:
        Prepared DataFrame with datetime index
    """
    # Make a copy
    result = df.copy()
    
    # Convert datetime column
    result[datetime_column] = pd.to_datetime(result[datetime_column])
    
    # Set as index
    result = result.set_index(datetime_column)
    
    # Sort by index
    result = result.sort_index()
    
    # Select only specified columns
    if value_columns:
        result = result[value_columns]
    
    # Resample if frequency specified
    if freq:
        # For numeric columns, use mean; for others, use first
        numeric_cols = result.select_dtypes(include=[np.number]).columns
        if len(numeric_cols) > 0:
            result = result.resample(freq).mean()
        else:
            result = result.resample(freq).first()
    
    return result