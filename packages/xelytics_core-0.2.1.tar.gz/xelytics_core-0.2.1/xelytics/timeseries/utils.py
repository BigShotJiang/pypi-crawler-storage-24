"""
Utilities module for xelytics-core v0.2.0.
Time series preprocessing, feature engineering, and visualization helpers.
"""

import pandas as pd
import numpy as np
from typing import Dict, Any, List, Optional, Tuple, Union, Callable
import warnings
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
import plotly.graph_objects as go
from plotly.subplots import make_subplots


def preprocess_time_series(series: pd.Series,
                          handle_missing: str = 'ffill',
                          handle_outliers: Optional[str] = None,
                          outlier_threshold: float = 3.0,
                          normalize: bool = False,
                          detrend: bool = False,
                          deseasonalize: bool = False,
                          seasonal_period: Optional[int] = None) -> pd.Series:
    """
    Preprocess time series data.
    
    Args:
        series: Time series data
        handle_missing: Method for handling missing values ('ffill', 'bfill', 'interpolate', 'drop')
        handle_outliers: Method for handling outliers ('clip', 'remove', None)
        outlier_threshold: Z-score threshold for outlier detection
        normalize: Whether to normalize the series (z-score)
        detrend: Whether to remove trend
        deseasonalize: Whether to remove seasonality
        seasonal_period: Seasonal period for deseasonalization
        
    Returns:
        Preprocessed time series
    """
    # Make a copy
    result = series.copy()
    
    # 1. Handle missing values
    if handle_missing == 'ffill':
        result = result.ffill().bfill()
    elif handle_missing == 'bfill':
        result = result.fillna(method='bfill').fillna(method='ffill')
    elif handle_missing == 'interpolate':
        result = result.interpolate(method='linear')
    elif handle_missing == 'drop':
        result = result.dropna()
    else:
        raise ValueError(f"Unknown missing value handling method: {handle_missing}")
    
    # 2. Handle outliers
    if handle_outliers is not None:
        if handle_outliers == 'clip':
            # Clip outliers to threshold * std
            mean = result.mean()
            std = result.std()
            lower = mean - outlier_threshold * std
            upper = mean + outlier_threshold * std
            result = result.clip(lower, upper)
        elif handle_outliers == 'remove':
            # Remove outliers
            z_scores = np.abs((result - result.mean()) / result.std())
            result = result[z_scores <= outlier_threshold]
    
    # 3. Detrend
    if detrend:
        try:
            from .decomposition import decompose_time_series
            decomposition = decompose_time_series(
                result,
                method='stl',
                period=seasonal_period or 7,
                model_type='additive'
            )
            result = decomposition.seasonal + decomposition.residual
        except Exception as e:
            warnings.warn(f"Detrending failed: {str(e)}")
    
    # 4. Deseasonalize
    if deseasonalize and seasonal_period:
        try:
            from .decomposition import decompose_time_series
            decomposition = decompose_time_series(
                result,
                method='stl',
                period=seasonal_period,
                model_type='additive'
            )
            result = decomposition.trend + decomposition.residual
        except Exception as e:
            warnings.warn(f"Deseasonalization failed: {str(e)}")
    
    # 5. Normalize
    if normalize:
        mean = result.mean()
        std = result.std()
        if std != 0:
            result = (result - mean) / std
    
    return result


def create_time_series_features(series: pd.Series,
                               lag_features: List[int] = [1, 7, 30],
                               rolling_features: List[int] = [7, 30],
                               date_features: bool = True) -> pd.DataFrame:
    """
    Create features from time series.
    
    Args:
        series: Time series data
        lag_features: List of lag periods
        rolling_features: List of rolling window sizes
        date_features: Whether to extract date-based features
        
    Returns:
        DataFrame with features
    """
    features = pd.DataFrame(index=series.index)
    
    # Original series
    features['value'] = series
    
    # Lag features
    for lag in lag_features:
        if lag > 0:
            features[f'lag_{lag}'] = series.shift(lag)
    
    # Rolling statistics
    for window in rolling_features:
        if window > 0:
            features[f'rolling_mean_{window}'] = series.rolling(window=window, center=True, min_periods=1).mean()
            features[f'rolling_std_{window}'] = series.rolling(window=window, center=True, min_periods=1).std()
            features[f'rolling_min_{window}'] = series.rolling(window=window, center=True, min_periods=1).min()
            features[f'rolling_max_{window}'] = series.rolling(window=window, center=True, min_periods=1).max()
    
    # Date features (if DatetimeIndex)
    if date_features and isinstance(series.index, pd.DatetimeIndex):
        features['year'] = series.index.year
        features['month'] = series.index.month
        features['day'] = series.index.day
        features['dayofweek'] = series.index.dayofweek
        features['dayofyear'] = series.index.dayofyear
        features['week'] = series.index.isocalendar().week
        features['quarter'] = series.index.quarter
        features['is_weekend'] = (series.index.dayofweek >= 5).astype(int)
        features['is_month_start'] = series.index.is_month_start.astype(int)
        features['is_month_end'] = series.index.is_month_end.astype(int)
        features['is_quarter_start'] = series.index.is_quarter_start.astype(int)
        features['is_quarter_end'] = series.index.is_quarter_end.astype(int)
        features['is_year_start'] = series.index.is_year_start.astype(int)
        features['is_year_end'] = series.index.is_year_end.astype(int)
    
    # Difference features
    features['diff_1'] = series.diff()
    features['pct_change'] = series.pct_change()
    
    # Exponential weighted moving average
    features['ewm_alpha_0.5'] = series.ewm(alpha=0.5).mean()
    features['ewm_alpha_0.3'] = series.ewm(alpha=0.3).mean()
    
    return features


def split_time_series(series: pd.Series,
                     test_size: float = 0.2,
                     validation_size: float = 0.1,
                     time_based: bool = True) -> Tuple[pd.Series, Optional[pd.Series], pd.Series]:
    """
    Split time series into train, validation, and test sets.
    
    Args:
        series: Time series data
        test_size: Proportion of data for test set
        validation_size: Proportion of data for validation set
        time_based: Whether to split based on time (not random)
        
    Returns:
        Tuple of (train, validation, test) series
    """
    n = len(series)
    
    if time_based:
        # Time-based split (chronological)
        test_split = int(n * (1 - test_size))
        val_split = int(test_split * (1 - validation_size))
        
        train = series.iloc[:val_split]
        val = series.iloc[val_split:test_split] if validation_size > 0 else None
        test = series.iloc[test_split:]
    else:
        # Random split (for non-time series or shuffled data)
        indices = np.random.permutation(n)
        test_split = int(n * (1 - test_size))
        val_split = int(test_split * (1 - validation_size))
        
        train_idx = indices[:val_split]
        val_idx = indices[val_split:test_split] if validation_size > 0 else []
        test_idx = indices[test_split:]
        
        train = series.iloc[train_idx]
        val = series.iloc[val_idx] if len(val_idx) > 0 else None
        test = series.iloc[test_idx]
    
    return train, val, test


def create_time_series_cv_splits(series: pd.Series,
                                n_splits: int = 5,
                                test_size: float = 0.2,
                                gap: int = 0) -> List[Tuple[pd.Series, pd.Series]]:
    """
    Create time series cross-validation splits.
    
    Args:
        series: Time series data
        n_splits: Number of splits
        test_size: Proportion of data for test set in each split
        gap: Gap between train and test sets
        
    Returns:
        List of (train, test) splits
    """
    splits = []
    n = len(series)
    
    for i in range(n_splits):
        test_end = n - int(n * test_size * i / n_splits)
        test_start = test_end - int(n * test_size)
        train_end = test_start - gap
        
        if train_end > 0 and test_start < n and test_start < test_end:
            train = series.iloc[:train_end]
            test = series.iloc[test_start:test_end]
            splits.append((train, test))
    
    return splits


def calculate_time_series_statistics(series: pd.Series) -> Dict[str, Any]:
    """
    Calculate comprehensive time series statistics.
    
    Args:
        series: Time series data
        
    Returns:
        Dictionary of statistics
    """
    stats = {
        'basic': {
            'count': len(series),
            'mean': float(series.mean()),
            'std': float(series.std()),
            'min': float(series.min()),
            'max': float(series.max()),
            'median': float(series.median()),
            'q1': float(series.quantile(0.25)),
            'q3': float(series.quantile(0.75)),
            'iqr': float(series.quantile(0.75) - series.quantile(0.25))
        },
        'distribution': {
            'skewness': float(series.skew()),
            'kurtosis': float(series.kurtosis()),
            'jarque_bera': _jarque_bera_test(series),
            'normality': _normality_test(series)
        },
        'time_series': {
            'autocorrelation': _autocorrelation_stats(series),
            'partial_autocorrelation': _partial_autocorrelation_stats(series),
            'stationarity': _stationarity_tests(series)
        }
    }
    
    return stats


def _jarque_bera_test(series: pd.Series) -> Dict[str, Any]:
    """Perform Jarque-Bera test for normality."""
    try:
        from scipy import stats
        
        if len(series) < 20:
            return {'test': 'jarque_bera', 'p_value': None, 'normal': None, 'reason': 'insufficient_data'}
        
        stat, p_value = stats.jarque_bera(series.dropna())
        
        return {
            'test': 'jarque_bera',
            'statistic': float(stat),
            'p_value': float(p_value),
            'normal': p_value > 0.05
        }
    except Exception:
        return {'test': 'jarque_bera', 'p_value': None, 'normal': None, 'reason': 'test_failed'}


def _normality_test(series: pd.Series) -> Dict[str, Any]:
    """Perform normality test."""
    try:
        from scipy import stats
        
        if len(series) < 20:
            return {'test': 'shapiro', 'p_value': None, 'normal': None, 'reason': 'insufficient_data'}
        
        # Shapiro-Wilk test for smaller samples, Kolmogorov-Smirnov for larger
        if len(series) < 5000:
            stat, p_value = stats.shapiro(series.dropna())
            test_name = 'shapiro'
        else:
            stat, p_value = stats.kstest(series.dropna(), 'norm')
            test_name = 'ks'
        
        return {
            'test': test_name,
            'statistic': float(stat),
            'p_value': float(p_value),
            'normal': p_value > 0.05
        }
    except Exception:
        return {'test': 'normality', 'p_value': None, 'normal': None, 'reason': 'test_failed'}


def _autocorrelation_stats(series: pd.Series, lags: int = 20) -> Dict[str, Any]:
    """Calculate autocorrelation statistics."""
    try:
        from statsmodels.tsa.stattools import acf
        
        if len(series) < lags * 2:
            return {'lags': lags, 'autocorrelation': [], 'reason': 'insufficient_data'}
        
        acf_values = acf(series.dropna(), nlags=lags, fft=True)
        
        return {
            'lags': lags,
            'autocorrelation': [float(val) for val in acf_values],
            'significant_lags': [i for i, val in enumerate(acf_values) if abs(val) > 1.96 / np.sqrt(len(series))],
            'mean_autocorrelation': float(np.mean(np.abs(acf_values[1:])))  # Exclude lag 0
        }
    except Exception:
        return {'lags': lags, 'autocorrelation': [], 'reason': 'calculation_failed'}


def _partial_autocorrelation_stats(series: pd.Series, lags: int = 10) -> Dict[str, Any]:
    """Calculate partial autocorrelation statistics."""
    try:
        from statsmodels.tsa.stattools import pacf
        
        if len(series) < lags * 2:
            return {'lags': lags, 'partial_autocorrelation': [], 'reason': 'insufficient_data'}
        
        pacf_values = pacf(series.dropna(), nlags=lags)
        
        return {
            'lags': lags,
            'partial_autocorrelation': [float(val) for val in pacf_values],
            'significant_lags': [i for i, val in enumerate(pacf_values) if abs(val) > 1.96 / np.sqrt(len(series))]
        }
    except Exception:
        return {'lags': lags, 'partial_autocorrelation': [], 'reason': 'calculation_failed'}


def _stationarity_tests(series: pd.Series) -> Dict[str, Any]:
    """Perform stationarity tests."""
    tests = {}
    
    # ADF test
    try:
        from statsmodels.tsa.stattools import adfuller
        
        if len(series) > 20:
            result = adfuller(series.dropna())
            tests['adf'] = {
                'test_statistic': float(result[0]),
                'p_value': float(result[1]),
                'stationary': result[1] < 0.05,
                'critical_values': {key: float(val) for key, val in result[4].items()}
            }
    except Exception:
        tests['adf'] = {'error': 'test_failed'}
    
    # KPSS test
    try:
        from statsmodels.tsa.stattools import kpss
        
        if len(series) > 20:
            result = kpss(series.dropna(), regression='c')
            tests['kpss'] = {
                'test_statistic': float(result[0]),
                'p_value': float(result[1]),
                'stationary': result[1] > 0.05,  # KPSS null hypothesis is stationarity
                'critical_values': {key: float(val) for key, val in result[3].items()}
            }
    except Exception:
        tests['kpss'] = {'error': 'test_failed'}
    
    # Overall stationarity assessment
    if 'adf' in tests and 'kpss' in tests:
        adf_stationary = tests['adf'].get('stationary', False)
        kpss_stationary = tests['kpss'].get('stationary', False)
        
        if adf_stationary and kpss_stationary:
            tests['overall'] = 'stationary'
        elif not adf_stationary and not kpss_stationary:
            tests['overall'] = 'non_stationary'
        else:
            tests['overall'] = 'trend_stationary'  # Only one test indicates stationarity
    else:
        tests['overall'] = 'inconclusive'
    
    return tests


def plot_time_series_analysis(series: pd.Series,
                             figsize: Tuple[int, int] = (15, 10),
                             title: str = "Time Series Analysis") -> plt.Figure:
    """
    Create comprehensive time series analysis plot.
    
    Args:
        series: Time series data
        figsize: Figure size
        title: Plot title
        
    Returns:
        Matplotlib Figure object
    """
    fig = plt.figure(figsize=figsize)
    gs = GridSpec(3, 3, figure=fig, hspace=0.4, wspace=0.3)
    
    # 1. Time series plot
    ax1 = fig.add_subplot(gs[0, :])
    ax1.plot(series, color='black', linewidth=1.5)
    ax1.set_title('Time Series')
    ax1.set_xlabel('Time')
    ax1.set_ylabel('Value')
    ax1.grid(True, alpha=0.3)
    
    # 2. Histogram and density
    ax2 = fig.add_subplot(gs[1, 0])
    ax2.hist(series.dropna(), bins=30, density=True, alpha=0.7, color='skyblue', edgecolor='black')
    ax2.set_title('Distribution')
    ax2.set_xlabel('Value')
    ax2.set_ylabel('Density')
    ax2.grid(True, alpha=0.3)
    
    # Add kernel density estimate
    try:
        from scipy import stats
        kde = stats.gaussian_kde(series.dropna())
        x_range = np.linspace(series.min(), series.max(), 100)
        ax2.plot(x_range, kde(x_range), color='red', linewidth=2)
    except Exception:
        pass
    
    # 3. QQ plot
    ax3 = fig.add_subplot(gs[1, 1])
    try:
        from scipy import stats
        stats.probplot(series.dropna(), dist="norm", plot=ax3)
        ax3.set_title('Q-Q Plot')
        ax3.grid(True, alpha=0.3)
    except Exception:
        ax3.text(0.5, 0.5, 'Q-Q plot not available', ha='center', va='center')
        ax3.set_title('Q-Q Plot')
    
    # 4. ACF plot
    ax4 = fig.add_subplot(gs[1, 2])
    try:
        from statsmodels.graphics.tsaplots import plot_acf
        plot_acf(series.dropna(), ax=ax4, lags=min(20, len(series) // 4))
        ax4.set_title('Autocorrelation')
        ax4.grid(True, alpha=0.3)
    except Exception:
        ax4.text(0.5, 0.5, 'ACF not available', ha='center', va='center')
        ax4.set_title('Autocorrelation')
    
    # 5. Rolling statistics
    ax5 = fig.add_subplot(gs[2, 0])
    rolling_window = min(30, len(series) // 10)
    if rolling_window > 0:
        rolling_mean = series.rolling(window=rolling_window, center=True).mean()
        rolling_std = series.rolling(window=rolling_window, center=True).std()
        
        ax5.plot(series, color='black', alpha=0.5, linewidth=1, label='Original')
        ax5.plot(rolling_mean, color='blue', linewidth=2, label=f'Rolling Mean ({rolling_window})')
        ax5.fill_between(series.index,
                        rolling_mean - rolling_std,
                        rolling_mean + rolling_std,
                        color='blue', alpha=0.2, label=f'Rolling Std ({rolling_window})')
        ax5.set_title('Rolling Statistics')
        ax5.set_xlabel('Time')
        ax5.set_ylabel('Value')
        ax5.legend()
        ax5.grid(True, alpha=0.3)
    else:
        ax5.text(0.5, 0.5, 'Insufficient data for rolling stats', ha='center', va='center')
        ax5.set_title('Rolling Statistics')
    
    # 6. Seasonal plot (if enough data)
    ax6 = fig.add_subplot(gs[2, 1])
    if isinstance(series.index, pd.DatetimeIndex) and len(series) > 365:
        try:
            # Create seasonal plot
            series_df = pd.DataFrame({'value': series})
            series_df['year'] = series_df.index.year
            series_df['dayofyear'] = series_df.index.dayofyear
            
            # Plot each year
            years = series_df['year'].unique()
            for year in years[-5:]:  # Last 5 years
                year_data = series_df[series_df['year'] == year]
                ax6.plot(year_data['dayofyear'], year_data['value'], 
                        label=str(year), alpha=0.7, linewidth=1)
            
            ax6.set_title('Seasonal Plot (Last 5 Years)')
            ax6.set_xlabel('Day of Year')
            ax6.set_ylabel('Value')
            ax6.legend()
            ax6.grid(True, alpha=0.3)
        except Exception:
            ax6.text(0.5, 0.5, 'Seasonal plot not available', ha='center', va='center')
            ax6.set_title('Seasonal Plot')
    else:
        ax6.text(0.5, 0.5, 'No seasonal plot (non-datetime or insufficient data)', 
                ha='center', va='center')
        ax6.set_title('Seasonal Plot')
    
    # 7. PACF plot
    ax7 = fig.add_subplot(gs[2, 2])
    try:
        from statsmodels.graphics.tsaplots import plot_pacf
        plot_pacf(series.dropna(), ax=ax7, lags=min(10, len(series) // 4))
        ax7.set_title('Partial Autocorrelation')
        ax7.grid(True, alpha=0.3)
    except Exception:
        ax7.text(0.5, 0.5, 'PACF not available', ha='center', va='center')
        ax7.set_title('Partial Autocorrelation')
    
    plt.suptitle(title, fontsize=16, y=0.98)
    plt.tight_layout()
    
    return fig


def create_interactive_time_series_plot(series: pd.Series,
                                       title: str = "Time Series Analysis") -> go.Figure:
    """
    Create interactive time series plot using Plotly.
    
    Args:
        series: Time series data
        title: Plot title
        
    Returns:
        Plotly Figure object
    """
    # Create subplots
    fig = make_subplots(
        rows=2, cols=3,
        subplot_titles=('Time Series', 'Distribution', 'Autocorrelation',
                       'Rolling Statistics', 'Seasonal Plot', 'Partial Autocorrelation'),
        vertical_spacing=0.15,
        horizontal_spacing=0.1
    )
    
    # 1. Time series plot
    fig.add_trace(
        go.Scatter(
            x=series.index,
            y=series.values,
            mode='lines',
            name='Original',
            line=dict(color='black', width=1),
            opacity=0.5
        ),
        row=2, col=1
)
    
    # 2. Histogram
    fig.add_trace(
        go.Histogram(
            x=series.dropna(),
            nbinsx=30,
            name='Distribution',
            marker_color='skyblue',
            opacity=0.7
        ),
        row=1, col=2
    )
    
    # 3. ACF plot
    try:
        from statsmodels.tsa.stattools import acf
        lags = min(20, len(series) // 4)
        acf_values = acf(series.dropna(), nlags=lags, fft=True)
        
        fig.add_trace(
            go.Bar(
                x=list(range(lags + 1)),
                y=acf_values,
                name='ACF',
                marker_color='lightgreen'
            ),
            row=1, col=3
        )
        
        # Add confidence intervals
        conf_int = 1.96 / np.sqrt(len(series))
        fig.add_hline(y=conf_int, line_dash="dash", line_color="gray", row=1, col=3)
        fig.add_hline(y=-conf_int, line_dash="dash", line_color="gray", row=1, col=3)
    except Exception:
        pass
    
    # 4. Rolling statistics
    rolling_window = min(30, len(series) // 10)
    if rolling_window > 0:
        rolling_mean = series.rolling(window=rolling_window, center=True).mean()
        rolling_std = series.rolling(window=rolling_window, center=True).std()
        
        fig.add_trace(
            go.Scatter(
                x=series.index,
                y=series.values,
                mode='lines',
                name='Original',
                line=dict(color='black', width=1, opacity=0.5)
            ),
            row=2, col=1
        )
        
        fig.add_trace(
            go.Scatter(
                x=series.index,
                y=rolling_mean,
                mode='lines',
                name=f'Rolling Mean ({rolling_window})',
                line=dict(color='blue', width=2)
            ),
            row=2, col=1
        )
        
        # Add confidence band
        fig.add_trace(
            go.Scatter(
                x=np.concatenate([series.index, series.index[::-1]]),
                y=np.concatenate([rolling_mean - rolling_std, (rolling_mean + rolling_std)[::-1]]),
                fill='toself',
                fillcolor='rgba(0, 100, 255, 0.2)',
                line=dict(color='rgba(255,255,255,0)'),
                name=f'±1 Std Dev'
            ),
            row=2, col=1
        )
    
    # 5. Seasonal plot (if datetime index)
    if isinstance(series.index, pd.DatetimeIndex) and len(series) > 365:
        try:
            series_df = pd.DataFrame({'value': series})
            series_df['year'] = series_df.index.year
            series_df['dayofyear'] = series_df.index.dayofyear
            
            years = series_df['year'].unique()[-5:]  # Last 5 years
            
            for year in years:
                year_data = series_df[series_df['year'] == year]
                fig.add_trace(
                    go.Scatter(
                        x=year_data['dayofyear'],
                        y=year_data['value'],
                        mode='lines',
                        name=str(year),
                        opacity=0.7
                    ),
                    row=2, col=2
                )
        except Exception:
            pass
    
    # 6. PACF plot
    try:
        from statsmodels.tsa.stattools import pacf
        lags = min(10, len(series) // 4)
        pacf_values = pacf(series.dropna(), nlags=lags)
        
        fig.add_trace(
            go.Bar(
                x=list(range(lags + 1)),
                y=pacf_values,
                name='PACF',
                marker_color='lightcoral'
            ),
            row=2, col=3
        )
        
        # Add confidence intervals
        conf_int = 1.96 / np.sqrt(len(series))
        fig.add_hline(y=conf_int, line_dash="dash", line_color="gray", row=2, col=3)
        fig.add_hline(y=-conf_int, line_dash="dash", line_color="gray", row=2, col=3)
    except Exception:
        pass
    
    # Update layout
    fig.update_layout(
        title_text=title,
        height=800,
        showlegend=True,
        hovermode='x unified'
    )
    
    # Update axes
    fig.update_xaxes(title_text="Time", row=1, col=1)
    fig.update_yaxes(title_text="Value", row=1, col=1)
    
    fig.update_xaxes(title_text="Value", row=1, col=2)
    fig.update_yaxes(title_text="Count", row=1, col=2)
    
    fig.update_xaxes(title_text="Lag", row=1, col=3)
    fig.update_yaxes(title_text="ACF", row=1, col=3)
    
    fig.update_xaxes(title_text="Time", row=2, col=1)
    fig.update_yaxes(title_text="Value", row=2, col=1)
    
    fig.update_xaxes(title_text="Day of Year", row=2, col=2)
    fig.update_yaxes(title_text="Value", row=2, col=2)
    
    fig.update_xaxes(title_text="Lag", row=2, col=3)
    fig.update_yaxes(title_text="PACF", row=2, col=3)
    
    return fig


def export_time_series_analysis(series: pd.Series,
                               output_file: str,
                               format: str = 'html') -> None:
    """
    Export time series analysis to file.
    
    Args:
        series: Time series data
        output_file: Output file path
        format: Output format ('html', 'json', 'csv')
    """
    # Calculate statistics
    stats = calculate_time_series_statistics(series)
    
    if format == 'html':
        # Create HTML report
        html_template = """
        <!DOCTYPE html>
        <html>
        <head>
            <title>Time Series Analysis Report</title>
            <style>
                body { font-family: Arial, Helvetica, sans-serif; margin: 40px; }
                h1 { color: #333333; }
                h2 { color: #555555; margin-top: 30px; }
                table { border-collapse: collapse; width: 100%; margin-bottom: 20px; }
                th, td { border: 1px solid #dddddd; padding: 8px; text-align: left; }
                th { background-color: #f2f2f2; }
                .summary { background-color: #f9f9f9; padding: 15px; border-radius: 5px; }
</style>
        </head>
        <body>
            <h1>Time Series Analysis Report</h1>
            
            <div class="summary">
                <h2>Basic Information</h2>
                <p><strong>Series Name:</strong> {series_name}</p>
                <p><strong>Data Points:</strong> {count}</p>
                <p><strong>Date Range:</strong> {start_date} to {end_date}</p>
                <p><strong>Frequency:</strong> {frequency}</p>
            </div>
            
            <h2>Basic Statistics</h2>
            <table>
                <tr><th>Statistic</th><th>Value</th></tr>
                {basic_stats}
            </table>
            
            <h2>Distribution Statistics</h2>
            <table>
                <tr><th>Statistic</th><th>Value</th></tr>
                {distribution_stats}
            </table>
            
            <h2>Time Series Statistics</h2>
            <table>
                <tr><th>Test</th><th>Result</th><th>Value</th></tr>
                {time_series_stats}
            </table>
        </body>
        </html>
        """
        
        # Format basic stats
        basic_stats_html = ""
        for key, value in stats['basic'].items():
            basic_stats_html += f"<tr><td>{key.title()}</td><td>{value:.4f}</td></tr>"
        
        # Format distribution stats
        distribution_stats_html = ""
        for key, value in stats['distribution'].items():
            if isinstance(value, dict):
                distribution_stats_html += f"<tr><td>{key.title()}</td><td>{value.get('test', 'N/A')}</td></tr>"
            else:
                distribution_stats_html += f"<tr><td>{key.title()}</td><td>{value:.4f}</td></tr>"
        
        # Format time series stats
        time_series_stats_html = ""
        for category, tests in stats['time_series'].items():
            if isinstance(tests, dict):
                for test_name, test_result in tests.items():
                    if isinstance(test_result, dict):
                        time_series_stats_html += f"<tr><td>{test_name.upper()}</td><td>{test_result.get('overall', 'N/A')}</td><td>{test_result.get('p_value', 'N/A')}</td></tr>"
        
        # Fill template
        html_content = html_template.format(
            series_name=series.name if series.name else 'Unknown',
            count=stats['basic']['count'],
            start_date=series.index.min() if len(series) > 0 else 'N/A',
            end_date=series.index.max() if len(series) > 0 else 'N/A',
            frequency=pd.infer_freq(series.index) if isinstance(series.index, pd.DatetimeIndex) else 'N/A',
            basic_stats=basic_stats_html,
            distribution_stats=distribution_stats_html,
            time_series_stats=time_series_stats_html
        )
        
        # Write to file
        with open(output_file, 'w') as f:
            f.write(html_content)
    
    elif format == 'json':
        # Export as JSON
        import json
        
        output_data = {
            'series_info': {
                'name': series.name if series.name else 'Unknown',
                'count': len(series),
                'start_date': str(series.index.min()) if len(series) > 0 else None,
                'end_date': str(series.index.max()) if len(series) > 0 else None,
                'frequency': pd.infer_freq(series.index) if isinstance(series.index, pd.DatetimeIndex) else None
            },
            'statistics': stats
        }
        
        with open(output_file, 'w') as f:
            json.dump(output_data, f, indent=2, default=str)
    
    elif format == 'csv':
        # Export statistics as CSV
        import csv
        
        # Flatten the stats dictionary
        flat_stats = {}
        
        def flatten_dict(d, prefix=''):
            for key, value in d.items():
                if isinstance(value, dict):
                    flatten_dict(value, f"{prefix}{key}.")
                else:
                    flat_stats[f"{prefix}{key}"] = value
        
        flatten_dict(stats)
        
        with open(output_file, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['Statistic', 'Value'])
            for key, value in flat_stats.items():
                writer.writerow([key, value])
    
    else:
        raise ValueError(f"Unsupported format: {format}. Use 'html', 'json', or 'csv'.")


