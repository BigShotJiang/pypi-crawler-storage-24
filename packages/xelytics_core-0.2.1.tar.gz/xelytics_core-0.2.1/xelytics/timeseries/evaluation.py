"""
Model evaluation and selection module for xelytics-core v0.2.0.
Implements comprehensive model comparison, backtesting, and performance metrics.
"""

import pandas as pd
import numpy as np
from typing import Dict, Any, List, Optional, Tuple, Union
from dataclasses import dataclass, field
import warnings
from enum import Enum
from collections import defaultdict
import itertools
from scipy import stats
import json


class EvaluationMetric(str, Enum):
    """Available evaluation metrics."""
    MAE = "mae"              # Mean Absolute Error
    MSE = "mse"              # Mean Squared Error
    RMSE = "rmse"            # Root Mean Squared Error
    MAPE = "mape"            # Mean Absolute Percentage Error
    SMAPE = "smape"          # Symmetric Mean Absolute Percentage Error
    MASE = "mase"            # Mean Absolute Scaled Error
    R2 = "r2"                # R-squared
    AIC = "aic"              # Akaike Information Criterion
    BIC = "bic"              # Bayesian Information Criterion
    LOG_LOSS = "log_loss"    # Log Loss
    ACCURACY = "accuracy"    # Classification Accuracy
    F1 = "f1"                # F1 Score
    PRECISION = "precision"  # Precision
    RECALL = "recall"        # Recall


class ValidationMethod(str, Enum):
    """Available validation methods."""
    HOLD_OUT = "hold_out"          # Simple train-test split
    K_FOLD = "k_fold"              # K-fold cross-validation
    TIME_SERIES_CV = "time_series_cv"  # Time series cross-validation
    WALK_FORWARD = "walk_forward"  # Walk-forward validation
    BOOTSTRAP = "bootstrap"        # Bootstrap validation


@dataclass
class ModelEvaluationResult:
    """Result of model evaluation."""
    model_name: str
    model_type: str
    metrics: Dict[str, float]
    predictions: Optional[pd.Series] = None
    actual_values: Optional[pd.Series] = None
    residuals: Optional[pd.Series] = None
    confidence_intervals: Optional[pd.DataFrame] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def summary(self) -> Dict[str, Any]:
        """Get summary of evaluation results."""
        return {
            'model_name': self.model_name,
            'model_type': self.model_type,
            'metrics': self.metrics,
            'best_metric': min(self.metrics.values()) if self.metrics else None,
            'worst_metric': max(self.metrics.values()) if self.metrics else None
        }
    
    def compare(self, other: 'ModelEvaluationResult') -> Dict[str, Any]:
        """Compare with another model evaluation result."""
        comparison = {
            'model_a': self.model_name,
            'model_b': other.model_name,
            'metric_comparison': {},
            'better_model': None,
            'improvement': {}
        }
        
        # Compare common metrics
        common_metrics = set(self.metrics.keys()) & set(other.metrics.keys())
        
        for metric in common_metrics:
            val_a = self.metrics[metric]
            val_b = other.metrics[metric]
            
            # Determine if lower or higher is better
            # For error metrics (MAE, MSE, RMSE, MAPE), lower is better
            # For accuracy metrics (R2, accuracy, F1), higher is better
            if metric in ['mae', 'mse', 'rmse', 'mape', 'smape', 'mase', 'aic', 'bic', 'log_loss']:
                better = val_a < val_b
                improvement = (val_b - val_a) / val_b * 100 if val_b != 0 else 0
            else:  # r2, accuracy, f1, precision, recall
                better = val_a > val_b
                improvement = (val_a - val_b) / val_b * 100 if val_b != 0 else 0
            
            comparison['metric_comparison'][metric] = {
                'model_a': val_a,
                'model_b': val_b,
                'difference': val_a - val_b,
                'improvement_pct': improvement,
                'better': 'model_a' if better else 'model_b'
            }
        
        return comparison


@dataclass
class ModelSelectionResult:
    """Result of model selection/comparison."""
    models: List[ModelEvaluationResult]
    best_model: ModelEvaluationResult
    ranking: List[Dict[str, Any]]
    comparison_matrix: pd.DataFrame
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def summary(self) -> Dict[str, Any]:
        """Get summary of model selection results."""
        return {
            'n_models': len(self.models),
            'best_model': self.best_model.model_name,
            'best_metrics': self.best_model.metrics,
            'ranking': self.ranking,
            'top_3_models': [m.model_name for m in self.models[:3]]
        }


class TimeSeriesEvaluator:
    """
    Time series model evaluation engine.
    
    Supports comprehensive model evaluation, comparison, and selection.
    """
    
    def __init__(self, 
                 validation_method: ValidationMethod = ValidationMethod.TIME_SERIES_CV,
                 test_size: float = 0.2,
                 n_folds: int = 5,
                 metrics: List[str] = ['mae', 'rmse', 'mape'],
                 confidence_level: float = 0.95):
        """
        Initialize the time series evaluator.
        
        Args:
            validation_method: Validation method to use
            test_size: Proportion of data for testing (for hold-out)
            n_folds: Number of folds for cross-validation
            metrics: List of metrics to calculate
            confidence_level: Confidence level for statistical tests
        """
        self.validation_method = validation_method
        self.test_size = test_size
        self.n_folds = n_folds
        self.metrics = [EvaluationMetric(m) for m in metrics]
        self.confidence_level = confidence_level
        
    def evaluate(self, 
                 series: pd.Series,
                 forecast_fn: callable,
                 model_name: str,
                 model_type: str,
                 **kwargs) -> ModelEvaluationResult:
        """
        Evaluate a time series forecasting model.
        
        Args:
            series: Time series data
            forecast_fn: Function that takes training data and returns forecast
            model_name: Name of the model
            model_type: Type of the model
            **kwargs: Additional arguments for forecast_fn
            
        Returns:
            ModelEvaluationResult object
        """
        # Validate input
        if len(series) < 20:
            raise ValueError("Time series must have at least 20 observations for evaluation")
        
        # Ensure series is sorted
        series = series.sort_index()
        
        # Handle NaN values
        if series.isna().any():
            series = series.fillna(method='ffill').fillna(method='bfill')
            warnings.warn(f"Found {series.isna().sum()} NaN values. Filled with forward/backward fill.")
        
        # Perform validation based on method
        if self.validation_method == ValidationMethod.HOLD_OUT:
            results = self._hold_out_validation(series, forecast_fn, **kwargs)
        elif self.validation_method == ValidationMethod.K_FOLD:
            results = self._k_fold_validation(series, forecast_fn, **kwargs)
        elif self.validation_method == ValidationMethod.TIME_SERIES_CV:
            results = self._time_series_cv(series, forecast_fn, **kwargs)
        elif self.validation_method == ValidationMethod.WALK_FORWARD:
            results = self._walk_forward_validation(series, forecast_fn, **kwargs)
        elif self.validation_method == ValidationMethod.BOOTSTRAP:
            results = self._bootstrap_validation(series, forecast_fn, **kwargs)
        else:
            raise ValueError(f"Unknown validation method: {self.validation_method}")
        
        # Calculate metrics
        metrics_dict = self._calculate_metrics(results['actual'], results['predictions'])
        
        # Calculate residuals
        residuals = None
        if results['actual'] is not None and results['predictions'] is not None:
            residuals = results['actual'] - results['predictions']
        
        return ModelEvaluationResult(
            model_name=model_name,
            model_type=model_type,
            metrics=metrics_dict,
            predictions=results['predictions'],
            actual_values=results['actual'],
            residuals=residuals,
            confidence_intervals=results.get('confidence_intervals'),
            metadata={
                'validation_method': self.validation_method.value,
                'test_size': self.test_size,
                'n_folds': self.n_folds,
                'series_length': len(series)
            }
        )
    
    def _hold_out_validation(self, series: pd.Series, forecast_fn: callable, **kwargs) -> Dict[str, Any]:
        """Perform hold-out validation."""
        n = len(series)
        split_idx = int(n * (1 - self.test_size))
        
        train_series = series.iloc[:split_idx]
        test_series = series.iloc[split_idx:]
        
        # Generate forecast
        forecast_result = forecast_fn(train_series, steps=len(test_series), **kwargs)
        
        # Extract forecast and actual values
        if hasattr(forecast_result, 'forecast'):
            predictions = forecast_result.forecast
        elif isinstance(forecast_result, pd.Series):
            predictions = forecast_result
        else:
            predictions = pd.Series(forecast_result, index=test_series.index[:len(forecast_result)])
        
        # Align indices
        common_idx = test_series.index.intersection(predictions.index)
        predictions_aligned = predictions.loc[common_idx]
        actual_aligned = test_series.loc[common_idx]
        
        return {
            'actual': actual_aligned,
            'predictions': predictions_aligned,
            'train_size': len(train_series),
            'test_size': len(test_series)
        }
    
    def _k_fold_validation(self, series: pd.Series, forecast_fn: callable, **kwargs) -> Dict[str, Any]:
        """Perform K-fold cross-validation."""
        n = len(series)
        fold_size = n // self.n_folds
        
        all_predictions = []
        all_actual = []
        
        for i in range(self.n_folds):
            test_start = i * fold_size
            test_end = (i + 1) * fold_size if i < self.n_folds - 1 else n
            
            test_series = series.iloc[test_start:test_end]
            train_series = pd.concat([series.iloc[:test_start], series.iloc[test_end:]])
            
            if len(train_series) > 0 and len(test_series) > 0:
                # Generate forecast
                forecast_result = forecast_fn(train_series, steps=len(test_series), **kwargs)
                
                # Extract predictions
                if hasattr(forecast_result, 'forecast'):
                    predictions = forecast_result.forecast
                elif isinstance(forecast_result, pd.Series):
                    predictions = forecast_result
                else:
                    predictions = pd.Series(forecast_result, index=test_series.index[:len(forecast_result)])
                
                # Align indices
                common_idx = test_series.index.intersection(predictions.index)
                if len(common_idx) > 0:
                    all_predictions.append(predictions.loc[common_idx])
                    all_actual.append(test_series.loc[common_idx])
        
        # Combine all predictions and actual values
        if all_predictions:
            predictions_combined = pd.concat(all_predictions).sort_index()
            actual_combined = pd.concat(all_actual).sort_index()
        else:
            predictions_combined = pd.Series(dtype=float)
            actual_combined = pd.Series(dtype=float)
        
        return {
            'actual': actual_combined,
            'predictions': predictions_combined,
            'n_folds': self.n_folds,
            'fold_size': fold_size
        }
    
    def _time_series_cv(self, series: pd.Series, forecast_fn: callable, **kwargs) -> Dict[str, Any]:
        """Perform time series cross-validation."""
        n = len(series)
        min_train_size = max(10, int(n * 0.2))
        
        all_predictions = []
        all_actual = []
        
        for i in range(self.n_folds):
            test_start = int(n * (1 - self.test_size * (i + 1) / self.n_folds))
            train_end = test_start - 1
            
            if train_end < min_train_size:
                continue
            
            train_series = series.iloc[:train_end]
            test_series = series.iloc[test_start:]
            
            if len(test_series) < 1:
                continue
            
            # Generate forecast
            forecast_result = forecast_fn(train_series, steps=len(test_series), **kwargs)
            
            # Extract predictions
            if hasattr(forecast_result, 'forecast'):
                predictions = forecast_result.forecast
            elif isinstance(forecast_result, pd.Series):
                predictions = forecast_result
            else:
                predictions = pd.Series(forecast_result, index=test_series.index[:len(forecast_result)])
            
            # Align indices
            common_idx = test_series.index.intersection(predictions.index)
            if len(common_idx) > 0:
                all_predictions.append(predictions.loc[common_idx])
                all_actual.append(test_series.loc[common_idx])
        
        # Combine all predictions and actual values
        if all_predictions:
            predictions_combined = pd.concat(all_predictions).sort_index()
            actual_combined = pd.concat(all_actual).sort_index()
        else:
            predictions_combined = pd.Series(dtype=float)
            actual_combined = pd.Series(dtype=float)
        
        return {
            'actual': actual_combined,
            'predictions': predictions_combined,
            'n_folds': self.n_folds,
            'test_size': self.test_size
        }
    
    def _walk_forward_validation(self, series: pd.Series, forecast_fn: callable, **kwargs) -> Dict[str, Any]:
        """Perform walk-forward validation."""
        n = len(series)
        window_size = max(10, int(n * 0.2))
        step_size = max(1, int(window_size * 0.2))
        
        all_predictions = []
        all_actual = []
        
        for start in range(0, n - window_size, step_size):
            train_end = start + window_size
            test_end = min(train_end + step_size, n)
            
            train_series = series.iloc[start:train_end]
            test_series = series.iloc[train_end:test_end]
            
            if len(test_series) < 1:
                continue
            
            # Generate forecast
            forecast_result = forecast_fn(train_series, steps=len(test_series), **kwargs)
            
            # Extract predictions
            if hasattr(forecast_result, 'forecast'):
                predictions = forecast_result.forecast
            elif isinstance(forecast_result, pd.Series):
                predictions = forecast_result
            else:
                predictions = pd.Series(forecast_result, index=test_series.index[:len(forecast_result)])
            
            # Align indices
            common_idx = test_series.index.intersection(predictions.index)
            if len(common_idx) > 0:
                all_predictions.append(predictions.loc[common_idx])
                all_actual.append(test_series.loc[common_idx])
        
        # Combine all predictions and actual values
        if all_predictions:
            predictions_combined = pd.concat(all_predictions).sort_index()
            actual_combined = pd.concat(all_actual).sort_index()
        else:
            predictions_combined = pd.Series(dtype=float)
            actual_combined = pd.Series(dtype=float)
        
        return {
            'actual': actual_combined,
            'predictions': predictions_combined,
            'window_size': window_size,
            'step_size': step_size
        }
    
    def _bootstrap_validation(self, series: pd.Series, forecast_fn: callable, **kwargs) -> Dict[str, Any]:
        """Perform bootstrap validation."""
        n = len(series)
        n_bootstrap = self.n_folds
        
        all_predictions = []
        all_actual = []
        
        for i in range(n_bootstrap):
            # Create bootstrap sample (with replacement)
            bootstrap_indices = np.random.choice(n, size=n, replace=True)
            train_series = series.iloc[bootstrap_indices].sort_index()
            
            # Use out-of-bag samples as test set
            oob_indices = list(set(range(n)) - set(bootstrap_indices))
            if len(oob_indices) > 0:
                test_series = series.iloc[oob_indices].sort_index()
                
                # Generate forecast
                forecast_result = forecast_fn(train_series, steps=len(test_series), **kwargs)
                
                # Extract predictions
                if hasattr(forecast_result, 'forecast'):
                    predictions = forecast_result.forecast
                elif isinstance(forecast_result, pd.Series):
                    predictions = forecast_result
                else:
                    predictions = pd.Series(forecast_result, index=test_series.index[:len(forecast_result)])
                
                # Align indices
                common_idx = test_series.index.intersection(predictions.index)
                if len(common_idx) > 0:
                    all_predictions.append(predictions.loc[common_idx])
                    all_actual.append(test_series.loc[common_idx])
        
        # Combine all predictions and actual values
        if all_predictions:
            predictions_combined = pd.concat(all_predictions).sort_index()
            actual_combined = pd.concat(all_actual).sort_index()
        else:
            predictions_combined = pd.Series(dtype=float)
            actual_combined = pd.Series(dtype=float)
        
        return {
            'actual': actual_combined,
            'predictions': predictions_combined,
            'n_bootstrap': n_bootstrap
        }
    
    def _calculate_metrics(self, actual: pd.Series, predictions: pd.Series) -> Dict[str, float]:
        """Calculate evaluation metrics."""
        if actual is None or predictions is None:
            return {}
        
        # Align indices
        common_idx = actual.index.intersection(predictions.index)
        if len(common_idx) == 0:
            return {}
        
        actual_aligned = actual.loc[common_idx]
        predictions_aligned = predictions.loc[common_idx]
        
        metrics = {}
        
        for metric in self.metrics:
            if metric == EvaluationMetric.MAE:
                metrics['mae'] = float(np.mean(np.abs(actual_aligned - predictions_aligned)))
            
            elif metric == EvaluationMetric.MSE:
                metrics['mse'] = float(np.mean((actual_aligned - predictions_aligned) ** 2))
            
            elif metric == EvaluationMetric.RMSE:
                mse = np.mean((actual_aligned - predictions_aligned) ** 2)
                metrics['rmse'] = float(np.sqrt(mse))
            
            elif metric == EvaluationMetric.MAPE:
                # Avoid division by zero
                mask = actual_aligned != 0
                if mask.any():
                    mape = np.mean(np.abs((actual_aligned[mask] - predictions_aligned[mask]) / actual_aligned[mask])) * 100
                    metrics['mape'] = float(mape)
            
            elif metric == EvaluationMetric.SMAPE:
                denominator = np.abs(actual_aligned) + np.abs(predictions_aligned)
                mask = denominator != 0
                if mask.any():
                    smape = 200 * np.mean(np.abs(predictions_aligned[mask] - actual_aligned[mask]) / denominator[mask])
                    metrics['smape'] = float(smape)
            
            elif metric == EvaluationMetric.MASE:
                # Use naive forecast as baseline
                if len(actual_aligned) > 1:
                    naive_forecast = actual_aligned.shift(1).dropna()
                    naive_error = np.mean(np.abs(actual_aligned.iloc[1:] - naive_forecast))
                    if naive_error != 0:
                        mase = np.mean(np.abs(actual_aligned - predictions_aligned)) / naive_error
                        metrics['mase'] = float(mase)
            
            elif metric == EvaluationMetric.R2:
                ss_res = np.sum((actual_aligned - predictions_aligned) ** 2)
                ss_tot = np.sum((actual_aligned - np.mean(actual_aligned)) ** 2)
                if ss_tot != 0:
                    r2 = 1 - (ss_res / ss_tot)
                    metrics['r2'] = float(r2)
        
        return metrics


class ModelSelector:
    """
    Model selection engine for time series forecasting.
    
    Supports comprehensive model comparison and selection.
    """
    
    def __init__(self, 
                 evaluator: Optional[TimeSeriesEvaluator] = None,
                 selection_criterion: str = 'rmse',
                 statistical_test: bool = True,
                 confidence_level: float = 0.95):
        """
        Initialize the model selector.
        
        Args:
            evaluator: TimeSeriesEvaluator instance (if None, creates default)
            selection_criterion: Metric to use for model selection
            statistical_test: Whether to perform statistical tests
            confidence_level: Confidence level for statistical tests
        """
        self.evaluator = evaluator or TimeSeriesEvaluator()
        self.selection_criterion = EvaluationMetric(selection_criterion)
        self.statistical_test = statistical_test
        self.confidence_level = confidence_level
    
    def select_best(self, 
                   series: pd.Series,
                   models: Dict[str, callable],
                   model_types: Optional[Dict[str, str]] = None) -> ModelSelectionResult:
        """
        Select the best model from a set of candidates.
        
        Args:
            series: Time series data
            models: Dictionary of model_name: forecast_function pairs
            model_types: Dictionary of model_name: model_type pairs
            
        Returns:
            ModelSelectionResult object
        """
        if model_types is None:
            model_types = {name: 'unknown' for name in models.keys()}
        
        # Evaluate all models
        evaluation_results = []
        
        for model_name, forecast_fn in models.items():
            try:
                result = self.evaluator.evaluate(
                    series=series,
                    forecast_fn=forecast_fn,
                    model_name=model_name,
                    model_type=model_types.get(model_name, 'unknown')
                )
                evaluation_results.append(result)
            except Exception as e:
                warnings.warn(f"Model '{model_name}' evaluation failed: {str(e)}")
        
        # Rank models by selection criterion
        ranked_results = self._rank_models(evaluation_results)
        
        # Get best model
        best_model = ranked_results[0] if ranked_results else None
        
        # Create comparison matrix
        comparison_matrix = self._create_comparison_matrix(evaluation_results)
        
        # Perform statistical tests if requested
        statistical_comparison = None
        if self.statistical_test and len(evaluation_results) > 1:
            statistical_comparison = self._statistical_comparison(evaluation_results)
        
        return ModelSelectionResult(
            models=ranked_results,
            best_model=best_model,
            ranking=self._create_ranking(ranked_results),
            comparison_matrix=comparison_matrix,
            metadata={
                'selection_criterion': self.selection_criterion.value,
                'statistical_test': self.statistical_test,
                'confidence_level': self.confidence_level,
                'statistical_comparison': statistical_comparison
            }
        )
    
    def _rank_models(self, results: List[ModelEvaluationResult]) -> List[ModelEvaluationResult]:
        """Rank models based on selection criterion."""
        if not results:
            return []
        
        # Filter models with the required metric
        valid_results = []
        for result in results:
            if self.selection_criterion.value in result.metrics:
                valid_results.append(result)
        
        # Determine if lower or higher is better for this metric
        if self.selection_criterion.value in ['mae', 'mse', 'rmse', 'mape', 'smape', 'mase', 'aic', 'bic', 'log_loss']:
            # Lower is better
            valid_results.sort(key=lambda x: x.metrics.get(self.selection_criterion.value, float('inf')))
        else:
            # Higher is better (r2, accuracy, f1, precision, recall)
            valid_results.sort(key=lambda x: x.metrics.get(self.selection_criterion.value, float('-inf')), reverse=True)
        
        return valid_results
    
    def _create_ranking(self, results: List[ModelEvaluationResult]) -> List[Dict[str, Any]]:
        """Create ranking dictionary."""
        ranking = []
        
        for i, result in enumerate(results):
            ranking.append({
                'rank': i + 1,
                'model_name': result.model_name,
                'model_type': result.model_type,
                'metric_value': result.metrics.get(self.selection_criterion.value),
                'all_metrics': result.metrics
            })
        
        return ranking
    
    def _create_comparison_matrix(self, results: List[ModelEvaluationResult]) -> pd.DataFrame:
        """Create comparison matrix of metrics across models."""
        if not results:
            return pd.DataFrame()
        
        # Get all metrics
        all_metrics = set()
        for result in results:
            all_metrics.update(result.metrics.keys())
        
        # Create comparison matrix
        data = {}
        for result in results:
            data[result.model_name] = {
                metric: result.metrics.get(metric, np.nan)
                for metric in all_metrics
            }
        
        return pd.DataFrame(data).T
    
    def _statistical_comparison(self, results: List[ModelEvaluationResult]) -> Dict[str, Any]:
        """Perform statistical comparison of models."""
        if len(results) < 2:
            return {}
        
        comparison = {
            'pairwise_tests': {},
            'friedman_test': None,
            'post_hoc_tests': None
        }
        
        # Pairwise t-tests for each metric
        for metric in self._get_common_metrics(results):
            values = []
            model_names = []
            
            for result in results:
                if metric in result.metrics:
                    values.append(result.metrics[metric])
                    model_names.append(result.model_name)
            
            if len(values) >= 2:
                # Perform pairwise comparisons
                pairwise = {}
                for i, j in itertools.combinations(range(len(values)), 2):
                    t_stat, p_value = stats.ttest_rel([values[i]], [values[j]])
                    pairwise[f"{model_names[i]}_vs_{model_names[j]}"] = {
                        't_statistic': float(t_stat),
                        'p_value': float(p_value),
                        'significant': p_value < (1 - self.confidence_level)
                    }
                
                comparison['pairwise_tests'][metric] = pairwise
        
        # Friedman test for multiple comparisons (if enough models)
        if len(results) >= 3:
            try:
                # Prepare data for Friedman test
                metric_data = []
                for metric in self._get_common_metrics(results):
                    metric_values = []
                    for result in results:
                        metric_values.append(result.metrics.get(metric, np.nan))
                    metric_data.append(metric_values)
                
                if metric_data and len(metric_data[0]) >= 3:
                    # Note: This is simplified - in practice you'd need proper Friedman test
                    comparison['friedman_test'] = {
                        'n_models': len(results),
                        'n_metrics': len(metric_data)
                    }
            except Exception as e:
                warnings.warn(f"Friedman test failed: {str(e)}")
        
        return comparison
    
    def _get_common_metrics(self, results: List[ModelEvaluationResult]) -> List[str]:
        """Get metrics common to all results."""
        if not results:
            return []
        
        common_metrics = set(results[0].metrics.keys())
        for result in results[1:]:
            common_metrics.intersection_update(result.metrics.keys())
        
        return list(common_metrics)


# Convenience functions
def evaluate_model(series: pd.Series,
                  forecast_fn: callable,
                  model_name: str = "Model",
                  model_type: str = "unknown",
                  validation_method: str = "time_series_cv",
                  **kwargs) -> ModelEvaluationResult:
    """
    Convenience function for model evaluation.
    
    Args:
        series: Time series data
        forecast_fn: Function that takes training data and returns forecast
        model_name: Name of the model
        model_type: Type of the model
        validation_method: Validation method to use
        **kwargs: Additional arguments for TimeSeriesEvaluator
        
    Returns:
        ModelEvaluationResult object
    """
    evaluator = TimeSeriesEvaluator(
        validation_method=ValidationMethod(validation_method),
        **kwargs
    )
    return evaluator.evaluate(series, forecast_fn, model_name, model_type)


def select_best_model(series: pd.Series,
                     models: Dict[str, callable],
                     model_types: Optional[Dict[str, str]] = None,
                     selection_criterion: str = 'rmse',
                     **kwargs) -> ModelSelectionResult:
    """
    Convenience function for model selection.
    
    Args:
        series: Time series data
        models: Dictionary of model_name: forecast_function pairs
        model_types: Dictionary of model_name: model_type pairs
        selection_criterion: Metric to use for model selection
        **kwargs: Additional arguments for ModelSelector
        
    Returns:
        ModelSelectionResult object
    """
    selector = ModelSelector(
        selection_criterion=selection_criterion,
        **kwargs
    )
    return selector.select_best(series, models, model_types)


def create_model_report(result: ModelEvaluationResult,
                       include_plots: bool = False) -> Dict[str, Any]:
    """
    Create comprehensive model evaluation report.
    
    Args:
        result: ModelEvaluationResult object
        include_plots: Whether to include plot data
        
    Returns:
        Dictionary with report
    """
    report = {
        'model_info': {
            'name': result.model_name,
            'type': result.model_type
        },
        'performance_metrics': result.metrics,
        'validation_summary': {
            'method': result.metadata.get('validation_method', 'unknown'),
            'series_length': result.metadata.get('series_length', 0)
        }
    }
    
    # Add residual analysis
    if result.residuals is not None:
        residuals = result.residuals.dropna()
        if len(residuals) > 0:
            report['residual_analysis'] = {
                'mean': float(residuals.mean()),
                'std': float(residuals.std()),
                'skewness': float(residuals.skew()),
                'kurtosis': float(residuals.kurtosis()),
                'normality_test': _test_normality(residuals),
                'autocorrelation': _calculate_autocorrelation(residuals)
            }
    
    # Add plot data if requested
    if include_plots and result.predictions is not None and result.actual_values is not None:
        report['plot_data'] = {
            'actual': result.actual_values.tolist(),
            'predictions': result.predictions.tolist(),
            'dates': result.actual_values.index.tolist()
        }
    
    return report


def _test_normality(residuals: pd.Series) -> Dict[str, Any]:
    """Test normality of residuals."""
    try:
        from scipy import stats
        
        if len(residuals) < 20:
            return {'test': 'shapiro', 'p_value': None, 'normal': None, 'reason': 'insufficient_data'}
        
        # Shapiro-Wilk test for normality
        stat, p_value = stats.shapiro(residuals)
        
        return {
            'test': 'shapiro',
            'statistic': float(stat),
            'p_value': float(p_value),
            'normal': p_value > 0.05
        }
    except Exception:
        return {'test': 'shapiro', 'p_value': None, 'normal': None, 'reason': 'test_failed'}


def _calculate_autocorrelation(residuals: pd.Series, lags: int = 10) -> Dict[str, Any]:
    """Calculate autocorrelation of residuals."""
    try:
        from statsmodels.tsa.stattools import acf
        
        if len(residuals) < lags * 2:
            return {'lags': lags, 'autocorrelation': [], 'reason': 'insufficient_data'}
        
        acf_values = acf(residuals, nlags=lags, fft=True)
        
        return {
            'lags': lags,
            'autocorrelation': [float(val) for val in acf_values],
            'significant_lags': [i for i, val in enumerate(acf_values) if abs(val) > 1.96 / np.sqrt(len(residuals))]
        }
    except Exception:
        return {'lags': lags, 'autocorrelation': [], 'reason': 'calculation_failed'}