"""
Time series decomposition module for xelytics-core v0.2.0.
Implements STL, classical, and seasonal decomposition methods.
"""

import pandas as pd
import numpy as np
from typing import Dict, Any, Optional, Tuple, List, Union
from dataclasses import dataclass, field
import warnings
from enum import Enum

class DecompositionMethod(str, Enum):
    """Available decomposition methods."""
    STL = "stl"
    CLASSICAL = "classical"
    SEASONAL_DECOMPOSE = "seasonal_decompose"
    # X11 = "x11"  # Requires additional dependencies


class ModelType(str, Enum):
    """Decomposition model types."""
    ADDITIVE = "additive"
    MULTIPLICATIVE = "multiplicative"
    AUTO = "auto"


@dataclass
class DecompositionResult:
    """Result of time series decomposition."""
    original: pd.Series
    trend: pd.Series
    seasonal: pd.Series
    residual: pd.Series
    method: DecompositionMethod
    model_type: ModelType
    period: int
    is_additive: bool
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dataframe(self) -> pd.DataFrame:
        """Convert decomposition results to DataFrame."""
        df = pd.DataFrame({
            'original': self.original,
            'trend': self.trend,
            'seasonal': self.seasonal,
            'residual': self.residual
        })
        return df
    
    def summary(self) -> Dict[str, Any]:
        """Get summary statistics of decomposition."""
        return {
            'method': self.method.value,
            'model_type': self.model_type.value,
            'period': self.period,
            'is_additive': self.is_additive,
            'variance_explained': {
                'trend': self._calculate_variance_explained(self.trend),
                'seasonal': self._calculate_variance_explained(self.seasonal),
                'residual': self._calculate_variance_explained(self.residual)
            },
            'stats': {
                'original': self._series_stats(self.original),
                'trend': self._series_stats(self.trend),
                'seasonal': self._series_stats(self.seasonal),
                'residual': self._series_stats(self.residual)
            }
        }
    
    def _calculate_variance_explained(self, component: pd.Series) -> float:
        """Calculate percentage of variance explained by component."""
        total_variance = self.original.var()
        if total_variance == 0:
            return 0.0
        component_variance = component.var()
        return component_variance / total_variance * 100
    
    def _series_stats(self, series: pd.Series) -> Dict[str, float]:
        """Calculate basic statistics for a series."""
        return {
            'mean': float(series.mean()),
            'std': float(series.std()),
            'min': float(series.min()),
            'max': float(series.max()),
            'skew': float(series.skew()),
            'kurtosis': float(series.kurtosis())
        }


class TimeSeriesDecomposer:
    """
    Time series decomposition engine.
    
    Supports multiple decomposition methods:
    - STL (Seasonal-Trend decomposition using LOESS)
    - Classical decomposition (additive/multiplicative)
    - Seasonal decomposition
    
    All methods handle missing values and irregular frequencies appropriately.
    """
    
    def __init__(self, method: DecompositionMethod = DecompositionMethod.STL,
                 model_type: ModelType = ModelType.AUTO,
                 period: Optional[int] = None,
                 robust: bool = False,
                 seasonal_smoother: int = 7,
                 trend_smoother: int = 13):
        """
        Initialize the time series decomposer.
        
        Args:
            method: Decomposition method (STL, CLASSICAL, SEASONAL_DECOMPOSE)
            model_type: Model type (ADDITIVE, MULTIPLICATIVE, AUTO)
            period: Seasonal period (if None, will be inferred)
            robust: Whether to use robust decomposition (for STL)
            seasonal_smoother: Seasonal smoother span for STL
            trend_smoother: Trend smoother span for STL
        """
        self.method = method
        self.model_type = model_type
        self.period = period
        self.robust = robust
        self.seasonal_smoother = seasonal_smoother
        self.trend_smoother = trend_smoother
        
        # Check dependencies
        self._check_dependencies()
    
    def _check_dependencies(self):
        """Check if required packages are installed."""
        if self.method == DecompositionMethod.STL:
            try:
                from statsmodels.tsa.seasonal import STL
                self._stl_available = True
            except ImportError:
                self._stl_available = False
                warnings.warn(
                    "STL decomposition requires statsmodels >= 0.12.0. "
                    "Falling back to seasonal_decompose."
                )
                self.method = DecompositionMethod.SEASONAL_DECOMPOSE
        
        if self.method == DecompositionMethod.SEASONAL_DECOMPOSE:
            try:
                from statsmodels.tsa.seasonal import seasonal_decompose
                self._seasonal_decompose_available = True
            except ImportError:
                raise ImportError(
                    "statsmodels is required for seasonal decomposition. "
                    "Install with: pip install statsmodels"
                )
    
    def decompose(self, series: pd.Series, 
              freq: Optional[str] = None,
              period: Optional[int] = None) -> DecompositionResult:
        """
        Decompose a time series into trend, seasonal, and residual components.
        
        Args:
            series: Time series data (must have DatetimeIndex or be regular)
            freq: Frequency string (e.g., 'D', 'W', 'MS'). If None, will try to infer.
            period: Seasonal period (overrides constructor period if provided)
            
        Returns:
            DecompositionResult object with components.
            
        Raises:
            ValueError: If series is too short or cannot be decomposed.
            ImportError: If required dependencies are missing.
        """
        # Use provided period if given, otherwise use constructor period
        effective_period = period if period is not None else self.period
        
        # Validate input
        if len(series) < 10:
            raise ValueError("Time series must have at least 10 observations for decomposition")
        
        # Ensure series is sorted and handle missing values
        series = series.sort_index()
        
        # Handle NaN values - forward fill then backward fill
        if series.isna().any():
            original_has_nan = True
            series = series.fillna(method='ffill').fillna(method='bfill')
            warnings.warn(f"Found {series.isna().sum()} NaN values. Filled with forward/backward fill.")
        else:
            original_has_nan = False
        
        # Determine period
        determined_period = self._determine_period(series, freq, effective_period)
        
        # Determine model type if AUTO
        model_type = self._determine_model_type(series, determined_period)
        
        # Perform decomposition based on method
        if self.method == DecompositionMethod.STL:
            result = self._stl_decompose(series, determined_period, model_type)
        elif self.method == DecompositionMethod.CLASSICAL:
            result = self._classical_decompose(series, determined_period, model_type)
        else:  # SEASONAL_DECOMPOSE
            result = self._seasonal_decompose(series, determined_period, model_type)
        
        # Add metadata
        result.metadata.update({
            'original_has_nan': original_has_nan,
            'series_length': len(series),
            'freq': freq,
            'period_detected': determined_period
        })
        
        return result
    
    def _determine_period(self, series: pd.Series, freq: Optional[str], 
                     period: Optional[int]) -> int:
        """Determine the seasonal period for decomposition."""
        # Use provided period if available
        if period is not None:
            if period < 1:
                raise ValueError(f"Period must be at least 1, got {period}")
            if period > len(series) // 2:
                warnings.warn(
                    f"Period {period} is too large for series of length {len(series)}. "
                    f"Maximum allowed is {len(series) // 2}. Using {len(series) // 2} instead."
                )
                period = len(series) // 2
            return period
        
        # Try to infer from frequency
        if freq:
            inferred_period = self._period_from_frequency(freq)
            if inferred_period:
                return inferred_period
        
        # Try to infer from index if it's DatetimeIndex
        if isinstance(series.index, pd.DatetimeIndex):
            inferred_period = self._infer_period_from_datetime(series.index)
            if inferred_period:
                return inferred_period
        
        # Default based on series length
        series_len = len(series)
        if series_len >= 30:
            # Try to find seasonality using autocorrelation
            try:
                inferred_period = self._find_seasonal_period(series)
                if inferred_period:
                    return inferred_period
            except Exception:
                pass
        
        # Default to no seasonality (period=1)
        warnings.warn(
            "Could not determine seasonal period. Defaulting to period=1 "
            "(no seasonality). Consider providing period parameter."
        )
        return 1
    
    def _period_from_frequency(self, freq: str) -> Optional[int]:
        """Get period from frequency string."""
        freq_map = {
            'H': 24,        # Daily seasonality in hourly data
            'h': 24,        # Daily seasonality in hourly data
            'D': 7,         # Weekly seasonality in daily data
            'W': 52,        # Yearly seasonality in weekly data
            'MS': 12,       # Yearly seasonality in monthly data
            'M': 12,        # Yearly seasonality in monthly data
            'QS': 4,        # Quarterly data
            'Q': 4,         # Quarterly data
            'YS': 1,        # No seasonality
            'Y': 1,         # No seasonality
            'T': 60,        # Hourly seasonality in minute data
            'min': 60,      # Hourly seasonality in minute data
            'S': 3600,      # Hourly seasonality in second data
        }
        return freq_map.get(freq, None)
    
    def _infer_period_from_datetime(self, index: pd.DatetimeIndex) -> Optional[int]:
        """Infer period from datetime index."""
        if len(index) < 10:
            return None
        
        # Check for daily data
        diffs = index.to_series().diff().dropna()
        if diffs.mean() <= pd.Timedelta(days=1):
            # Likely daily data - check for weekly pattern
            day_counts = index.dayofweek.value_counts()
            if len(day_counts) == 7:
                return 7
        
        # Check for monthly data
        if diffs.mean() >= pd.Timedelta(days=28):
            month_counts = index.month.value_counts()
            if len(month_counts) == 12:
                return 12
        
        return None
    
    def _find_seasonal_period(self, series: pd.Series, max_period: int = 100) -> Optional[int]:
        """Find seasonal period using autocorrelation."""
        try:
            from statsmodels.tsa.stattools import acf
            
            nlags = min(100, len(series) // 2)
            acf_values = acf(series.dropna(), nlags=nlags, fft=True)
            
            # Find peaks after lag 0
            peaks = []
            for i in range(1, len(acf_values) - 1):
                if acf_values[i] > acf_values[i-1] and acf_values[i] > acf_values[i+1]:
                    peaks.append((i, acf_values[i]))
            
            # Sort by ACF value
            peaks.sort(key=lambda x: x[1], reverse=True)
            
            # Return the first significant peak
            for lag, acf_val in peaks:
                if acf_val > 0.3 and lag <= max_period:
                    return lag
            
            return None
        except Exception:
            return None
    
    def _determine_model_type(self, series: pd.Series, period: int) -> ModelType:
        """Determine if series should use additive or multiplicative decomposition."""
        if self.model_type != ModelType.AUTO:
            return self.model_type
        
        # Simple heuristic for choosing model type
        # If series has increasing variance with level, use multiplicative
        
        # Check for negative values
        if (series <= 0).any():
            return ModelType.ADDITIVE
        
        # Split series into segments and check variance
        if len(series) >= 20:
            n_segments = min(5, len(series) // 4)
            segment_length = len(series) // n_segments
            
            means = []
            stds = []
            
            for i in range(n_segments):
                start = i * segment_length
                end = start + segment_length
                segment = series.iloc[start:end]
                if len(segment) > 1:
                    means.append(segment.mean())
                    stds.append(segment.std())
            
            # Check correlation between means and stds
            if len(means) >= 3:
                correlation = np.corrcoef(means, stds)[0, 1]
                if correlation > 0.5:  # Strong positive correlation
                    return ModelType.MULTIPLICATIVE
        
        return ModelType.ADDITIVE
    
    def _stl_decompose(self, series: pd.Series, period: int, 
                      model_type: ModelType) -> DecompositionResult:
        """Perform STL decomposition."""
        if not self._stl_available:
            warnings.warn("STL not available, falling back to seasonal_decompose")
            return self._seasonal_decompose(series, period, model_type)
        
        try:
            from statsmodels.tsa.seasonal import STL
            
            # STL only supports additive model
            # For multiplicative, we need to transform the data
            is_additive = (model_type == ModelType.ADDITIVE)
            
            if model_type == ModelType.MULTIPLICATIVE:
                # Multiplicative model: transform with log
                if (series <= 0).any():
                    warnings.warn(
                        "Cannot use multiplicative decomposition with non-positive values. "
                        "Switching to additive."
                    )
                    is_additive = True
                    transformed_series = series.copy()
                else:
                    transformed_series = np.log(series)
            else:
                transformed_series = series.copy()
            
            # Ensure period is at least 2 for STL
            stl_period = max(2, period)
            
            # Perform STL decomposition
            stl = STL(
                transformed_series,
                period=stl_period,
                seasonal=self.seasonal_smoother,
                trend=self.trend_smoother,
                robust=self.robust
            )
            stl_result = stl.fit()
            
            # Extract components
            if model_type == ModelType.MULTIPLICATIVE and not is_additive:
                # Transform back from log space
                trend = np.exp(stl_result.trend)
                seasonal = np.exp(stl_result.seasonal)
                residual = series / (trend * seasonal)
            else:
                trend = stl_result.trend
                seasonal = stl_result.seasonal
                residual = stl_result.resid
            
            return DecompositionResult(
                original=series,
                trend=pd.Series(trend, index=series.index),
                seasonal=pd.Series(seasonal, index=series.index),
                residual=pd.Series(residual, index=series.index),
                method=DecompositionMethod.STL,
                model_type=model_type,
                period=stl_period,
                is_additive=is_additive,
                metadata={
                    'seasonal_smoother': self.seasonal_smoother,
                    'trend_smoother': self.trend_smoother,
                    'robust': self.robust
                }
            )
            
        except Exception as e:
            warnings.warn(f"STL decomposition failed: {str(e)}. Falling back to seasonal_decompose.")
            return self._seasonal_decompose(series, period, model_type)
    
    def _seasonal_decompose(self, series: pd.Series, period: int,
                           model_type: ModelType) -> DecompositionResult:
        """Perform seasonal decomposition using statsmodels."""
        try:
            from statsmodels.tsa.seasonal import seasonal_decompose
            
            # Ensure period is valid
            decompose_period = max(2, period)
            
            # For very short series, adjust period
            if decompose_period >= len(series):
                decompose_period = len(series) - 1 if len(series) > 2 else 1
            
            if decompose_period <= 1:
                # No seasonality - just extract trend
                return self._trend_only_decompose(series, model_type)
            
            # Perform decomposition
            model = 'additive' if model_type == ModelType.ADDITIVE else 'multiplicative'
            result = seasonal_decompose(
                series,
                model=model,
                period=decompose_period,
                extrapolate_trend='freq'
            )
            
            return DecompositionResult(
                original=pd.Series(result.observed, index=series.index),
                trend=pd.Series(result.trend, index=series.index),
                seasonal=pd.Series(result.seasonal, index=series.index),
                residual=pd.Series(result.resid, index=series.index),
                method=DecompositionMethod.SEASONAL_DECOMPOSE,
                model_type=model_type,
                period=decompose_period,
                is_additive=(model_type == ModelType.ADDITIVE)
            )
            
        except Exception as e:
            warnings.warn(f"Seasonal decomposition failed: {str(e)}")
            # Fall back to simple moving average
            return self._simple_decompose(series, period, model_type)
    
    def _classical_decompose(self, series: pd.Series, period: int,
                            model_type: ModelType) -> DecompositionResult:
        """Perform classical time series decomposition."""
        # Classical decomposition is similar to seasonal_decompose
        # We'll use the same implementation for now
        return self._seasonal_decompose(series, period, model_type)
    
    def _simple_decompose(self, series: pd.Series, period: int,
                         model_type: ModelType) -> DecompositionResult:
        """Simple decomposition using moving averages (fallback method)."""
        if len(series) < 5:
            # Too short for decomposition
            return DecompositionResult(
                original=series,
                trend=series.copy(),
                seasonal=pd.Series(0, index=series.index),
                residual=pd.Series(0, index=series.index),
                method=DecompositionMethod.CLASSICAL,
                model_type=model_type,
                period=1,
                is_additive=True
            )
        
        # Calculate trend using moving average
        window = min(5, len(series) // 2)
        if window % 2 == 0:
            window += 1  # Make window odd for centered moving average
        
        trend = series.rolling(window=window, center=True, min_periods=1).mean()
        
        # Detrend the series
        if model_type == ModelType.MULTIPLICATIVE:
            detrended = series / trend
        else:
            detrended = series - trend
        
        # Calculate seasonal component
        if period > 1 and len(detrended) >= period * 2:
            seasonal = self._calculate_seasonal_component(detrended, period, model_type)
        else:
            seasonal = pd.Series(0, index=series.index)
        
        # Calculate residual
        if model_type == ModelType.MULTIPLICATIVE:
            residual = series / (trend * seasonal)
        else:
            residual = series - (trend + seasonal)
        
        return DecompositionResult(
            original=series,
            trend=trend,
            seasonal=seasonal,
            residual=residual,
            method=DecompositionMethod.CLASSICAL,
            model_type=model_type,
            period=period,
            is_additive=(model_type == ModelType.ADDITIVE)
        )
    
    def _calculate_seasonal_component(self, detrended: pd.Series, period: int,
                                     model_type: ModelType) -> pd.Series:
        """Calculate seasonal component from detrended series."""
        seasonal = pd.Series(index=detrended.index, dtype=float)
        
        for i in range(period):
            # Get all values at this seasonal position
            indices = detrended.index[i::period]
            values = detrended.loc[indices]
            
            if len(values) > 0:
                if model_type == ModelType.MULTIPLICATIVE:
                    seasonal_value = values.mean()
                else:
                    seasonal_value = values.mean()
                
                seasonal.loc[indices] = seasonal_value
        
        # Normalize seasonal component
        if model_type == ModelType.ADDITIVE:
            seasonal = seasonal - seasonal.mean()
        else:
            seasonal = seasonal / seasonal.mean()
        
        return seasonal
    
    def _trend_only_decompose(self, series: pd.Series,
                             model_type: ModelType) -> DecompositionResult:
        """Decomposition when no seasonality is present."""
        # Simple trend extraction
        window = min(5, len(series) // 2)
        if window % 2 == 0:
            window += 1
        
        trend = series.rolling(window=window, center=True, min_periods=1).mean()
        
        return DecompositionResult(
            original=series,
            trend=trend,
            seasonal=pd.Series(0, index=series.index),
            residual=series - trend,
            method=DecompositionMethod.CLASSICAL,
            model_type=model_type,
            period=1,
            is_additive=True
        )


# Convenience functions
def decompose_time_series(series: pd.Series, 
                         method: str = "stl",
                         model_type: str = "auto",
                         freq: Optional[str] = None,
                         period: Optional[int] = None,
                         **kwargs) -> DecompositionResult:
    """
    Convenience function for time series decomposition.
    
    Args:
        series: Time series data
        method: Decomposition method ('stl', 'classical', 'seasonal_decompose')
        model_type: Model type ('additive', 'multiplicative', 'auto')
        freq: Frequency string (e.g., 'D', 'W', 'MS')
        period: Seasonal period (if None, will be inferred)
        **kwargs: Additional arguments for TimeSeriesDecomposer
        
    Returns:
        DecompositionResult object
    """
    decomposer = TimeSeriesDecomposer(
        method=DecompositionMethod(method),
        model_type=ModelType(model_type),
        period=period,
        **kwargs
    )
    return decomposer.decompose(series, freq=freq, period=period)


def plot_decomposition(result: DecompositionResult, 
                      figsize: Tuple[int, int] = (12, 8),
                      title: str = "Time Series Decomposition") -> None:
    """
    Plot decomposition results.
    
    Args:
        result: DecompositionResult object
        figsize: Figure size
        title: Plot title
    """
    import matplotlib.pyplot as plt
    from matplotlib.gridspec import GridSpec
    
    fig = plt.figure(figsize=figsize)
    gs = GridSpec(4, 1, figure=fig, hspace=0.3)
    
    # Original series
    ax1 = fig.add_subplot(gs[0])
    ax1.plot(result.original, label='Original', color='black', linewidth=1.5)
    ax1.set_title(f'{title} - {result.method.value.upper()} ({result.model_type.value})')
    ax1.legend(loc='upper left')
    ax1.grid(True, alpha=0.3)
    
    # Trend component
    ax2 = fig.add_subplot(gs[1], sharex=ax1)
    ax2.plot(result.trend, label='Trend', color='blue', linewidth=2)
    ax2.legend(loc='upper left')
    ax2.grid(True, alpha=0.3)
    
    # Seasonal component
    ax3 = fig.add_subplot(gs[2], sharex=ax1)
    ax3.plot(result.seasonal, label='Seasonal', color='green', linewidth=1)
    ax3.legend(loc='upper left')
    ax3.grid(True, alpha=0.3)
    
    # Residual component
    ax4 = fig.add_subplot(gs[3], sharex=ax1)
    ax4.plot(result.residual, label='Residual', color='red', linewidth=0.5)
    ax4.axhline(y=0, color='black', linestyle='--', alpha=0.5)
    ax4.legend(loc='upper left')
    ax4.grid(True, alpha=0.3)
    ax4.set_xlabel('Time')
    
    plt.tight_layout()
    return fig


def validate_decomposition(result: DecompositionResult) -> Dict[str, Any]:
    """
    Validate decomposition results.
    
    Args:
        result: DecompositionResult object
        
    Returns:
        Dictionary with validation metrics
    """
    validation = {
        'is_valid': True,
        'warnings': [],
        'errors': [],
        'metrics': {}
    }
    
    # Check for NaN values
    for name, series in [('trend', result.trend), 
                         ('seasonal', result.seasonal), 
                         ('residual', result.residual)]:
        nan_count = series.isna().sum()
        if nan_count > 0:
            validation['warnings'].append(f"{name} has {nan_count} NaN values")
            validation['is_valid'] = False
    
    # Check reconstruction error
    if result.is_additive:
        reconstructed = result.trend + result.seasonal + result.residual
        reconstruction_error = result.original - reconstructed
    else:
        reconstructed = result.trend * result.seasonal * result.residual
        reconstruction_error = (result.original - reconstructed) / result.original
    
    mae = reconstruction_error.abs().mean()
    mse = (reconstruction_error ** 2).mean()
    
    validation['metrics']['reconstruction_error'] = {
        'mae': float(mae),
        'mse': float(mse),
        'rmse': float(np.sqrt(mse))
    }
    
    if mae > 0.1 * result.original.abs().mean():
        validation['warnings'].append(f"High reconstruction error: MAE = {mae:.4f}")
    
    # Check residual properties
    residual_mean = result.residual.mean()
    residual_std = result.residual.std()
    
    validation['metrics']['residual_stats'] = {
        'mean': float(residual_mean),
        'std': float(residual_std),
        'skew': float(result.residual.skew()),
        'kurtosis': float(result.residual.kurtosis())
    }
    
    # Residuals should have mean close to 0
    if abs(residual_mean) > 0.1 * residual_std:
        validation['warnings'].append(f"Residual mean ({residual_mean:.4f}) is not close to zero")
    
    return validation