"""
Time series forecasting module for xelytics-core v0.2.0.
Implements ARIMA, SARIMA, and auto-model selection.
"""

import pandas as pd
import numpy as np
from typing import Dict, Any, Optional, Tuple, List, Union, Callable
from dataclasses import dataclass, field
import warnings
from enum import Enum
import pickle
import json
from datetime import datetime, timedelta
import hashlib


class ForecastModel(str, Enum):
    """Available forecasting models."""
    ARIMA = "arima"
    SARIMA = "sarima"
    AUTO_ARIMA = "auto_arima"
    LINEAR = "linear"
    EXPONENTIAL_SMOOTHING = "exponential_smoothing"
    NAIVE = "naive"
    SEASONAL_NAIVE = "seasonal_naive"
    DRIFT = "drift"


class ForecastMetric(str, Enum):
    """Forecast evaluation metrics."""
    MAE = "mae"  # Mean Absolute Error
    MSE = "mse"  # Mean Squared Error
    RMSE = "rmse"  # Root Mean Squared Error
    MAPE = "mape"  # Mean Absolute Percentage Error
    SMAPE = "smape"  # Symmetric Mean Absolute Percentage Error
    MASE = "mase"  # Mean Absolute Scaled Error
    AIC = "aic"  # Akaike Information Criterion
    BIC = "bic"  # Bayesian Information Criterion


@dataclass
class ForecastResult:
    """Result of time series forecasting."""
    model_name: str
    model_type: ForecastModel
    forecast: pd.Series
    confidence_intervals: pd.DataFrame
    model_summary: Dict[str, Any]
    training_metrics: Dict[str, float]
    forecast_metrics: Optional[Dict[str, float]] = None
    model_object: Any = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dataframe(self) -> pd.DataFrame:
        """Convert forecast results to DataFrame."""
        df = pd.DataFrame({
            'forecast': self.forecast,
            'lower_bound': self.confidence_intervals.get('lower', pd.Series(index=self.forecast.index)),
            'upper_bound': self.confidence_intervals.get('upper', pd.Series(index=self.forecast.index))
        })
        return df
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert forecast results to dictionary (serializable)."""
        return {
            'model_name': self.model_name,
            'model_type': self.model_type.value,
            'forecast': self.forecast.to_dict(),
            'confidence_intervals': {
                col: series.to_dict() 
                for col, series in self.confidence_intervals.items()
            },
            'model_summary': self.model_summary,
            'training_metrics': self.training_metrics,
            'forecast_metrics': self.forecast_metrics,
            'metadata': self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ForecastResult':
        """Create ForecastResult from dictionary."""
        forecast = pd.Series(data['forecast'])
        confidence_intervals = pd.DataFrame({
            col: pd.Series(series_dict) 
            for col, series_dict in data['confidence_intervals'].items()
        })
        
        return cls(
            model_name=data['model_name'],
            model_type=ForecastModel(data['model_type']),
            forecast=forecast,
            confidence_intervals=confidence_intervals,
            model_summary=data['model_summary'],
            training_metrics=data['training_metrics'],
            forecast_metrics=data.get('forecast_metrics'),
            metadata=data.get('metadata', {})
        )
    
    def plot(self, actual: Optional[pd.Series] = None, 
             figsize: Tuple[int, int] = (12, 6),
             title: Optional[str] = None) -> Any:
        """Plot forecast results."""
        import matplotlib.pyplot as plt
        
        fig, ax = plt.subplots(figsize=figsize)
        
        # Plot actual data if provided
        if actual is not None:
            ax.plot(actual, label='Actual', color='black', linewidth=1.5)
        
        # Plot forecast
        ax.plot(self.forecast, label='Forecast', color='blue', linewidth=2)
        
        # Plot confidence intervals
        if 'lower' in self.confidence_intervals.columns and 'upper' in self.confidence_intervals.columns:
            ax.fill_between(
                self.forecast.index,
                self.confidence_intervals['lower'],
                self.confidence_intervals['upper'],
                color='blue',
                alpha=0.2,
                label=f'{self.metadata.get("confidence_level", 95)}% CI'
            )
        
        # Title and labels
        if title:
            ax.set_title(title)
        else:
            ax.set_title(f'{self.model_name} Forecast')
        
        ax.set_xlabel('Time')
        ax.set_ylabel('Value')
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        return fig


class TimeSeriesForecaster:
    """
    Time series forecasting engine.
    
    Supports multiple forecasting models:
    - ARIMA/SARIMA (auto and manual parameter selection)
    - Linear regression
    - Exponential smoothing (Holt-Winters)
    - Naive methods (naive, seasonal naive, drift)
    """
    
    def __init__(self, 
                 model_type: ForecastModel = ForecastModel.AUTO_ARIMA,
                 seasonal_period: Optional[int] = None,
                 confidence_level: float = 0.95,
                 test_size: float = 0.2,
                 enable_caching: bool = True,
                 cache_dir: Optional[str] = None):
        """
        Initialize the time series forecaster.
        
        Args:
            model_type: Forecasting model type
            seasonal_period: Seasonal period for seasonal models
            confidence_level: Confidence level for prediction intervals (0-1)
            test_size: Proportion of data to use for testing (0-1)
            enable_caching: Whether to cache trained models
            cache_dir: Directory for model caching
        """
        self.model_type = model_type
        self.seasonal_period = seasonal_period
        self.confidence_level = confidence_level
        self.test_size = test_size
        self.enable_caching = enable_caching
        self.cache_dir = cache_dir
        
        # Initialize cache
        self._cache = {}
        
        # Check dependencies
        self._check_dependencies()
    
    def _check_dependencies(self):
        """Check if required packages are installed."""
        # Statsmodels is required for most models
        try:
            import statsmodels.api as sm
            self._statsmodels_available = True
        except ImportError:
            self._statsmodels_available = False
            warnings.warn(
                "statsmodels is required for forecasting. "
                "Install with: pip install statsmodels"
            )
        
        # pmdarima is required for auto-ARIMA
        if self.model_type in [ForecastModel.AUTO_ARIMA, ForecastModel.ARIMA, ForecastModel.SARIMA]:
            try:
                import pmdarima as pm
                self._pmdarima_available = True
            except ImportError:
                self._pmdarima_available = False
                warnings.warn(
                    "pmdarima is required for auto-ARIMA. "
                    "Install with: pip install pmdarima or using auto_arima_fallback"
                )
    
    def _get_cache_key(self, series: pd.Series, model_params: Dict[str, Any]) -> str:
        """Generate cache key for model."""
        # Create a hash from series data and model parameters
        data_hash = hashlib.md5(
            series.values.tobytes() + 
            json.dumps(model_params, sort_keys=True).encode()
        ).hexdigest()
        
        return f"{self.model_type.value}_{data_hash}"
    
    def _load_from_cache(self, cache_key: str) -> Optional[Any]:
        """Load model from cache."""
        if not self.enable_caching:
            return None
        
        if cache_key in self._cache:
            return self._cache[cache_key]
        
        # Try to load from disk cache
        if self.cache_dir:
            import os
            cache_file = os.path.join(self.cache_dir, f"{cache_key}.pkl")
            if os.path.exists(cache_file):
                try:
                    with open(cache_file, 'rb') as f:
                        return pickle.load(f)
                except Exception:
                    pass
        
        return None
    
    def _save_to_cache(self, cache_key: str, model: Any):
        """Save model to cache."""
        if not self.enable_caching:
            return
        
        # Save to memory cache
        self._cache[cache_key] = model
        
        # Save to disk cache
        if self.cache_dir:
            import os
            os.makedirs(self.cache_dir, exist_ok=True)
            cache_file = os.path.join(self.cache_dir, f"{cache_key}.pkl")
            try:
                with open(cache_file, 'wb') as f:
                    pickle.dump(model, f)
            except Exception:
                pass
    
    def forecast(self, 
                 series: pd.Series,
                 steps: int = 30,
                 exog: Optional[pd.DataFrame] = None,
                 model_params: Optional[Dict[str, Any]] = None,
                 use_cached: bool = True) -> ForecastResult:
        """
        Forecast future values of a time series.
        
        Args:
            series: Time series data (must be regular)
            steps: Number of steps to forecast
            exog: Exogenous variables (optional)
            model_params: Additional model parameters
            use_cached: Whether to use cached model if available
            
        Returns:
            ForecastResult object with forecast and metrics
            
        Raises:
            ValueError: If series is too short or irregular
            ImportError: If required dependencies are missing
        """
        # Validate input
        if len(series) < 10:
            raise ValueError("Time series must have at least 10 observations for forecasting")
        
        if steps < 1:
            raise ValueError("Steps must be at least 1")
        
        # Ensure series is sorted
        series = series.sort_index()
        
        # Handle NaN values
        if series.isna().any():
            series = series.fillna(method='ffill').fillna(method='bfill')
            warnings.warn(f"Found {series.isna().sum()} NaN values. Filled with forward/backward fill.")
        
        # Prepare model parameters
        model_params = model_params or {}
        seasonal_period = model_params.get('seasonal_period', self.seasonal_period)
        
        # Check if we can use cached model
        cache_key = None
        if use_cached and self.enable_caching:
            cache_key = self._get_cache_key(series, {
                'model_type': self.model_type.value,
                'seasonal_period': seasonal_period,
                **model_params
            })
            cached_model = self._load_from_cache(cache_key)
            if cached_model:
                return self._forecast_with_model(series, steps, exog, cached_model)
        
        # Train model based on type
        if self.model_type == ForecastModel.AUTO_ARIMA:
            model = self._train_auto_arima(series, exog, seasonal_period, model_params)
        elif self.model_type == ForecastModel.ARIMA:
            model = self._train_arima(series, exog, False, model_params)
        elif self.model_type == ForecastModel.SARIMA:
            model = self._train_arima(series, exog, True, model_params)
        elif self.model_type == ForecastModel.LINEAR:
            model = self._train_linear(series, exog, model_params)
        elif self.model_type == ForecastModel.EXPONENTIAL_SMOOTHING:
            model = self._train_exponential_smoothing(series, seasonal_period, model_params)
        elif self.model_type == ForecastModel.NAIVE:
            model = self._train_naive(series, model_params)
        elif self.model_type == ForecastModel.SEASONAL_NAIVE:
            model = self._train_seasonal_naive(series, seasonal_period, model_params)
        elif self.model_type == ForecastModel.DRIFT:
            model = self._train_drift(series, model_params)
        else:
            raise ValueError(f"Unknown model type: {self.model_type}")
        
        # Save to cache
        if cache_key:
            self._save_to_cache(cache_key, model)
        
        # Generate forecast
        return self._forecast_with_model(series, steps, exog, model)
    
    def _forecast_with_model(self, 
                            series: pd.Series,
                            steps: int,
                            exog: Optional[pd.DataFrame],
                            model: Any) -> ForecastResult:
        """Generate forecast using trained model."""
        model_name = model.get('name', str(self.model_type))
        model_type = model.get('type', self.model_type)
        forecast_fn = model.get('forecast_fn')
        summary = model.get('summary', {})
        training_metrics = model.get('training_metrics', {})
        
        if not forecast_fn:
            raise ValueError("Model does not have forecast function")
        
        # Generate forecast
        forecast_result = forecast_fn(steps, exog)
        
        # Extract forecast and confidence intervals
        if isinstance(forecast_result, tuple) and len(forecast_result) >= 2:
            forecast_series = forecast_result[0]
            conf_int = forecast_result[1]
        else:
            forecast_series = forecast_result
            conf_int = None
        
        # Create confidence intervals DataFrame
        if conf_int is not None and hasattr(conf_int, '__len__') and len(conf_int) == 2:
            confidence_intervals = pd.DataFrame({
                'lower': pd.Series(conf_int[0], index=forecast_series.index),
                'upper': pd.Series(conf_int[1], index=forecast_series.index)
            })
        else:
            # Generate dummy confidence intervals
            forecast_index = self._generate_forecast_index(series.index, steps)
            confidence_intervals = pd.DataFrame(
                index=forecast_index,
                columns=['lower', 'upper']
            )
        
        # Calculate training metrics if not already calculated
        if not training_metrics:
            training_metrics = self._calculate_training_metrics(series, model)
        
        return ForecastResult(
            model_name=model_name,
            model_type=model_type,
            forecast=forecast_series,
            confidence_intervals=confidence_intervals,
            model_summary=summary,
            training_metrics=training_metrics,
            metadata={
                'confidence_level': self.confidence_level,
                'steps': steps,
                'series_length': len(series),
                'seasonal_period': self.seasonal_period
            }
        )
    
    def _generate_forecast_index(self, 
                                current_index: pd.Index, 
                                steps: int) -> pd.DatetimeIndex:
        """Generate index for forecast period."""
        if isinstance(current_index, pd.DatetimeIndex):
            # Infer frequency
            freq = pd.infer_freq(current_index)
            if freq:
                return pd.date_range(
                    start=current_index[-1],
                    periods=steps + 1,
                    freq=freq
                )[1:]  # Skip the first (last actual value)
            
            # If no frequency, assume daily
            last_date = current_index[-1]
            return pd.date_range(
                start=last_date + pd.Timedelta(days=1),
                periods=steps,
                freq='D'
            )
        else:
            # Numeric index
            last_idx = current_index[-1]
            return pd.RangeIndex(
                start=last_idx + 1,
                stop=last_idx + steps + 1
            )
    
    def _train_auto_arima(self, 
                         series: pd.Series,
                         exog: Optional[pd.DataFrame],
                         seasonal_period: Optional[int],
                         model_params: Dict[str, Any]) -> Dict[str, Any]:
        """Train auto-ARIMA model."""
        if not self._pmdarima_available:
            warnings.warn("pmdarima not available, falling back to simple ARIMA")
            return self._train_simple_arima(series, exog, seasonal_period, model_params)
        
        try:
            import pmdarima as pm
            
            # Default parameters
            default_params = {
                'start_p': 0,
                'd': None,  # Auto-detect
                'start_q': 0,
                'max_p': 5,
                'max_d': 2,
                'max_q': 5,
                'start_P': 0,
                'D': None,  # Auto-detect
                'start_Q': 0,
                'max_P': 2,
                'max_D': 1,
                'max_Q': 2,
                'max_order': 10,
                'm': seasonal_period or 1,
                'seasonal': seasonal_period is not None,
                'stepwise': True,
                'trace': False,
                'error_action': 'ignore',
                'suppress_warnings': True,
                'random_state': 42,
                'n_fits': 50,
                'out_of_sample_size': max(5, int(len(series) * self.test_size))
            }
            
            # Update with user parameters
            params = {**default_params, **model_params}
            
            # Train model
            model = pm.auto_arima(
                series,
                X=exog,
                **params
            )
            
            # Get model summary
            summary = {
                'order': model.order,
                'seasonal_order': model.seasonal_order if hasattr(model, 'seasonal_order') else (0, 0, 0, 0),
                'aic': float(model.aic()) if hasattr(model, 'aic') else None,
                'bic': float(model.bic()) if hasattr(model, 'bic') else None,
                'aicc': float(model.aicc()) if hasattr(model, 'aicc') else None,
                'params': model.params().tolist() if hasattr(model, 'params') else [],
            }
            
            # Calculate training metrics
            training_metrics = self._calculate_arima_metrics(series, model)
            
            # Define forecast function
            def forecast_fn(steps: int, exog_forecast: Optional[pd.DataFrame]):
                forecast, conf_int = model.predict(
                    n_periods=steps,
                    X=exog_forecast,
                    return_conf_int=True,
                    alpha=1 - self.confidence_level
                )
                
                # Convert to Series with proper index
                forecast_index = self._generate_forecast_index(series.index, steps)
                forecast_series = pd.Series(forecast, index=forecast_index)
                
                return forecast_series, conf_int
            
            return {
                'name': f'Auto-ARIMA{seasonal_period if seasonal_period else ""}',
                'type': ForecastModel.AUTO_ARIMA,
                'model': model,
                'forecast_fn': forecast_fn,
                'summary': summary,
                'training_metrics': training_metrics
            }
            
        except Exception as e:
            warnings.warn(f"Auto-ARIMA failed: {str(e)}. Falling back to simple ARIMA.")
            return self._train_simple_arima(series, exog, seasonal_period, model_params)
    
    def _train_simple_arima(self,
                           series: pd.Series,
                           exog: Optional[pd.DataFrame],
                           seasonal_period: Optional[int],
                           model_params: Dict[str, Any]) -> Dict[str, Any]:
        """Train simple ARIMA model (fallback)."""
        if not self._statsmodels_available:
            raise ImportError("statsmodels is required for ARIMA modeling")
        
        try:
            from statsmodels.tsa.arima.model import ARIMA
            
            # Default parameters
            default_order = (1, 0, 1)
            default_seasonal_order = (0, 0, 0, 0)
            
            if seasonal_period and seasonal_period > 1:
                default_seasonal_order = (1, 0, 1, seasonal_period)
            
            order = model_params.get('order', default_order)
            seasonal_order = model_params.get('seasonal_order', default_seasonal_order)
            
            # Train model
            model = ARIMA(
                series,
                exog=exog,
                order=order,
                seasonal_order=seasonal_order if seasonal_period else (0, 0, 0, 0)
            ).fit()
            
            # Get model summary
            summary = {
                'order': order,
                'seasonal_order': seasonal_order,
                'aic': float(model.aic),
                'bic': float(model.bic),
                'params': model.params.tolist(),
                'pvalues': model.pvalues.tolist() if hasattr(model, 'pvalues') else [],
            }
            
            # Calculate training metrics
            training_metrics = self._calculate_arima_metrics(series, model)
            
            # Define forecast function
            def forecast_fn(steps: int, exog_forecast: Optional[pd.DataFrame]):
                forecast_result = model.get_forecast(steps=steps, exog=exog_forecast)
                forecast = forecast_result.predicted_mean
                conf_int = forecast_result.conf_int(alpha=1 - self.confidence_level)
                
                # Convert to Series with proper index
                forecast_index = self._generate_forecast_index(series.index, steps)
                forecast_series = pd.Series(forecast, index=forecast_index)
                
                return forecast_series, conf_int
            
            return {
                'name': f'ARIMA{order}{f"(seasonal {seasonal_order})" if seasonal_period else ""}',
                'type': ForecastModel.ARIMA if not seasonal_period else ForecastModel.SARIMA,
                'model': model,
                'forecast_fn': forecast_fn,
                'summary': summary,
                'training_metrics': training_metrics
            }
            
        except Exception as e:
            warnings.warn(f"ARIMA failed: {str(e)}. Falling back to linear model.")
            return self._train_linear(series, exog, model_params)
    
    def _train_linear(self,
                     series: pd.Series,
                     exog: Optional[pd.DataFrame],
                     model_params: Dict[str, Any]) -> Dict[str, Any]:
        """Train linear regression model."""
        if not self._statsmodels_available:
            raise ImportError("statsmodels is required for linear regression")
        
        try:
            import statsmodels.api as sm
            
            # Prepare features
            X = np.arange(len(series)).reshape(-1, 1)
            if exog is not None:
                X = np.hstack([X, exog.values])
            
            X = sm.add_constant(X)
            y = series.values
            
            # Train model
            model = sm.OLS(y, X).fit()
            
            # Get model summary
            summary = {
                'r_squared': float(model.rsquared),
                'adj_r_squared': float(model.rsquared_adj),
                'f_statistic': float(model.fvalue),
                'f_pvalue': float(model.f_pvalue),
                'params': model.params.tolist(),
                'pvalues': model.pvalues.tolist(),
            }
            
            # Calculate training metrics
            training_metrics = self._calculate_linear_metrics(series, model)
            
            # Define forecast function
            def forecast_fn(steps: int, exog_forecast: Optional[pd.DataFrame]):
                # Prepare future X
                n_future = len(series) + np.arange(1, steps + 1)
                X_future = n_future.reshape(-1, 1)
                
                if exog is not None and exog_forecast is not None:
                    X_future = np.hstack([X_future, exog_forecast.values])
                
                X_future = sm.add_constant(X_future)
                
                # Generate forecast
                forecast = model.predict(X_future)
                
                # Generate confidence intervals (simplified)
                forecast_se = np.sqrt(model.mse_resid) * np.sqrt(1 + np.diag(X_future @ model.cov_params() @ X_future.T))
                t_critical = 1.96  # Approximate for 95% CI
                
                lower = forecast - t_critical * forecast_se
                upper = forecast + t_critical * forecast_se
                
                # Convert to Series with proper index
                forecast_index = self._generate_forecast_index(series.index, steps)
                forecast_series = pd.Series(forecast, index=forecast_index)
                conf_int = (lower, upper)
                
                return forecast_series, conf_int
            
            return {
                'name': 'Linear Regression',
                'type': ForecastModel.LINEAR,
                'model': model,
                'forecast_fn': forecast_fn,
                'summary': summary,
                'training_metrics': training_metrics
            }
            
        except Exception as e:
            warnings.warn(f"Linear regression failed: {str(e)}. Falling back to naive forecast.")
            return self._train_naive(series, model_params)
    
    def _train_exponential_smoothing(self,
                                    series: pd.Series,
                                    seasonal_period: Optional[int],
                                    model_params: Dict[str, Any]) -> Dict[str, Any]:
        """Train exponential smoothing (Holt-Winters) model."""
        if not self._statsmodels_available:
            raise ImportError("statsmodels is required for exponential smoothing")
        
        try:
            from statsmodels.tsa.holtwinters import ExponentialSmoothing
            
            # Default parameters
            trend_type = model_params.get('trend', 'add')
            seasonal_type = model_params.get('seasonal', 'add' if seasonal_period else None)
            
            # Train model
            model = ExponentialSmoothing(
                series,
                trend=trend_type,
                seasonal=seasonal_type,
                seasonal_periods=seasonal_period
            ).fit()
            
            # Get model summary
            summary = {
                'sse': float(model.sse),
                'aic': float(model.aic),
                'bic': float(model.bic),
                'smoothing_level': float(model.params['smoothing_level']),
                'smoothing_trend': float(model.params.get('smoothing_trend', 0)),
                'smoothing_seasonal': float(model.params.get('smoothing_seasonal', 0)),
            }
            
            # Calculate training metrics
            training_metrics = self._calculate_smoothing_metrics(series, model)
            
            # Define forecast function
            def forecast_fn(steps: int, exog_forecast: Optional[pd.DataFrame]):
                forecast_result = model.forecast(steps)
                
                # Generate confidence intervals (simplified)
                # Note: ExponentialSmoothing doesn't provide confidence intervals directly
                forecast_se = np.sqrt(model.sse / len(series))
                t_critical = 1.96
                
                lower = forecast_result - t_critical * forecast_se
                upper = forecast_result + t_critical * forecast_se
                
                # Convert to Series with proper index
                forecast_index = self._generate_forecast_index(series.index, steps)
                forecast_series = pd.Series(forecast_result, index=forecast_index)
                conf_int = (lower, upper)
                
                return forecast_series, conf_int
            
            return {
                'name': f'Exponential Smoothing ({trend_type} trend, {seasonal_type} seasonal)' if seasonal_type else f'Exponential Smoothing ({trend_type} trend)',
                'type': ForecastModel.EXPONENTIAL_SMOOTHING,
                'model': model,
                'forecast_fn': forecast_fn,
                'summary': summary,
                'training_metrics': training_metrics
            }
            
        except Exception as e:
            warnings.warn(f"Exponential smoothing failed: {str(e)}. Falling back to naive forecast.")
            return self._train_naive(series, model_params)
    
    def _train_naive(self, series: pd.Series, model_params: Dict[str, Any]) -> Dict[str, Any]:
        """Train naive forecasting model."""
        # Simple model: forecast = last observed value
        last_value = series.iloc[-1]
        
        def forecast_fn(steps: int, exog_forecast: Optional[pd.DataFrame]):
            forecast_index = self._generate_forecast_index(series.index, steps)
            forecast_series = pd.Series(last_value, index=forecast_index)
            
            # No confidence intervals for naive model
            return forecast_series, None
        
        # Calculate training metrics
        training_metrics = self._calculate_naive_metrics(series)
        
        return {
            'name': 'Naive',
            'type': ForecastModel.NAIVE,
            'model': None,
            'forecast_fn': forecast_fn,
            'summary': {'method': 'last_value', 'last_value': float(last_value)},
            'training_metrics': training_metrics
        }
    
    def _train_seasonal_naive(self, 
                             series: pd.Series,
                             seasonal_period: Optional[int],
                             model_params: Dict[str, Any]) -> Dict[str, Any]:
        """Train seasonal naive forecasting model."""
        if seasonal_period is None or seasonal_period <= 1:
            warnings.warn("Seasonal naive requires seasonal period > 1. Falling back to naive.")
            return self._train_naive(series, model_params)
        
        # Use the value from the same season in the previous cycle
        if len(series) < seasonal_period:
            warnings.warn("Series too short for seasonal naive. Falling back to naive.")
            return self._train_naive(series, model_params)
        
        seasonal_values = series.iloc[-seasonal_period:].values
        
        def forecast_fn(steps: int, exog_forecast: Optional[pd.DataFrame]):
            forecast_index = self._generate_forecast_index(series.index, steps)
            
            # Repeat seasonal pattern
            n_repeats = (steps + seasonal_period - 1) // seasonal_period
            forecast_values = np.tile(seasonal_values, n_repeats)[:steps]
            
            forecast_series = pd.Series(forecast_values, index=forecast_index)
            return forecast_series, None
        
        # Calculate training metrics
        training_metrics = self._calculate_seasonal_naive_metrics(series, seasonal_period)
        
        return {
            'name': f'Seasonal Naive (period={seasonal_period})',
            'type': ForecastModel.SEASONAL_NAIVE,
            'model': None,
            'forecast_fn': forecast_fn,
            'summary': {
                'method': 'seasonal_naive',
                'seasonal_period': seasonal_period,
                'seasonal_pattern': seasonal_values.tolist()
            },
            'training_metrics': training_metrics
        }
    
    def _train_drift(self, series: pd.Series, model_params: Dict[str, Any]) -> Dict[str, Any]:
        """Train drift forecasting model."""
        if len(series) < 2:
            warnings.warn("Drift model requires at least 2 observations. Falling back to naive.")
            return self._train_naive(series, model_params)
        
        # Calculate drift (average change)
        changes = series.diff().dropna()
        drift = changes.mean()
        last_value = series.iloc[-1]
        
        def forecast_fn(steps: int, exog_forecast: Optional[pd.DataFrame]):
            forecast_index = self._generate_forecast_index(series.index, steps)
            
            # Forecast with drift
            forecast_values = last_value + drift * np.arange(1, steps + 1)
            forecast_series = pd.Series(forecast_values, index=forecast_index)
            
            return forecast_series, None
        
        # Calculate training metrics
        training_metrics = self._calculate_drift_metrics(series)
        
        return {
            'name': 'Drift',
            'type': ForecastModel.DRIFT,
            'model': None,
            'forecast_fn': forecast_fn,
            'summary': {
                'method': 'drift',
                'last_value': float(last_value),
                'drift': float(drift)
            },
            'training_metrics': training_metrics
        }
    
    def _calculate_training_metrics(self, series: pd.Series, model: Dict[str, Any]) -> Dict[str, float]:
        """Calculate training metrics for any model."""
        # This is a generic method that calls specific metric calculators
        model_type = model.get('type')
        
        if model_type == ForecastModel.ARIMA or model_type == ForecastModel.SARIMA or model_type == ForecastModel.AUTO_ARIMA:
            return self._calculate_arima_metrics(series, model.get('model'))
        elif model_type == ForecastModel.LINEAR:
            return self._calculate_linear_metrics(series, model.get('model'))
        elif model_type == ForecastModel.EXPONENTIAL_SMOOTHING:
            return self._calculate_smoothing_metrics(series, model.get('model'))
        elif model_type == ForecastModel.NAIVE:
            return self._calculate_naive_metrics(series)
        elif model_type == ForecastModel.SEASONAL_NAIVE:
            seasonal_period = model.get('summary', {}).get('seasonal_period', 1)
            return self._calculate_seasonal_naive_metrics(series, seasonal_period)
        elif model_type == ForecastModel.DRIFT:
            return self._calculate_drift_metrics(series)
        else:
            return self._calculate_generic_metrics(series, model.get('model'))
    
    def _calculate_arima_metrics(self, series: pd.Series, model: Any) -> Dict[str, float]:
        """Calculate metrics for ARIMA models."""
        try:
            # Get fitted values
            if hasattr(model, 'fittedvalues'):
                fitted = model.fittedvalues
            else:
                fitted = series.copy()  # Fallback
            
            # Calculate residuals
            residuals = series - fitted
            
            # Calculate metrics
            metrics = {
                'mae': float(np.mean(np.abs(residuals))),
                'mse': float(np.mean(residuals ** 2)),
                'rmse': float(np.sqrt(np.mean(residuals ** 2))),
                'mape': float(np.mean(np.abs(residuals / series)) * 100),
            }
            
            # Add model-specific metrics if available
            if hasattr(model, 'aic'):
                metrics['aic'] = float(model.aic)
            if hasattr(model, 'bic'):
                metrics['bic'] = float(model.bic)
            
            return metrics
            
        except Exception:
            return self._calculate_generic_metrics(series, model)
    
    def _calculate_linear_metrics(self, series: pd.Series, model: Any) -> Dict[str, float]:
        """Calculate metrics for linear models."""
        try:
            # Get fitted values
            fitted = model.fittedvalues
            
            # Calculate residuals
            residuals = series - fitted
            
            # Calculate metrics
            metrics = {
                'mae': float(np.mean(np.abs(residuals))),
                'mse': float(np.mean(residuals ** 2)),
                'rmse': float(np.sqrt(np.mean(residuals ** 2))),
                'mape': float(np.mean(np.abs(residuals / series)) * 100),
                'r_squared': float(model.rsquared),
                'adj_r_squared': float(model.rsquared_adj),
            }
            
            return metrics
            
        except Exception:
            return self._calculate_generic_metrics(series, model)
    
    def _calculate_smoothing_metrics(self, series: pd.Series, model: Any) -> Dict[str, float]:
        """Calculate metrics for exponential smoothing models."""
        try:
            # Get fitted values
            fitted = model.fittedvalues
            
            # Calculate residuals
            residuals = series - fitted
            
            # Calculate metrics
            metrics = {
                'mae': float(np.mean(np.abs(residuals))),
                'mse': float(np.mean(residuals ** 2)),
                'rmse': float(np.sqrt(np.mean(residuals ** 2))),
                'mape': float(np.mean(np.abs(residuals / series)) * 100),
                'sse': float(model.sse),
                'aic': float(model.aic),
                'bic': float(model.bic),
            }
            
            return metrics
            
        except Exception:
            return self._calculate_generic_metrics(series, model)
    
    def _calculate_naive_metrics(self, series: pd.Series) -> Dict[str, float]:
        """Calculate metrics for naive model."""
        # Naive model: use previous value as forecast
        forecast = series.shift(1)
        residuals = series - forecast
        
        # Remove first NaN
        residuals = residuals.dropna()
        
        metrics = {
            'mae': float(np.mean(np.abs(residuals))),
            'mse': float(np.mean(residuals ** 2)),
            'rmse': float(np.sqrt(np.mean(residuals ** 2))),
            'mape': float(np.mean(np.abs(residuals / series.iloc[1:])) * 100),
        }
        
        return metrics
    
    def _calculate_seasonal_naive_metrics(self, series: pd.Series, seasonal_period: int) -> Dict[str, float]:
        """Calculate metrics for seasonal naive model."""
        if len(series) <= seasonal_period:
            return self._calculate_naive_metrics(series)
        
        # Seasonal naive: use value from same season in previous cycle
        forecast = series.shift(seasonal_period)
        residuals = series - forecast
        
        # Remove first seasonal_period NaN values
        residuals = residuals.dropna()
        
        metrics = {
            'mae': float(np.mean(np.abs(residuals))),
            'mse': float(np.mean(residuals ** 2)),
            'rmse': float(np.sqrt(np.mean(residuals ** 2))),
            'mape': float(np.mean(np.abs(residuals / series.iloc[seasonal_period:])) * 100),
        }
        
        return metrics
    
    def _calculate_drift_metrics(self, series: pd.Series) -> Dict[str, float]:
        """Calculate metrics for drift model."""
        if len(series) < 2:
            return self._calculate_naive_metrics(series)
        
        # Calculate drift for each point
        drift = series.diff().mean()
        forecast = series.shift(1) + drift
        residuals = series - forecast
        
        # Remove first NaN
        residuals = residuals.dropna()
        
        metrics = {
            'mae': float(np.mean(np.abs(residuals))),
            'mse': float(np.mean(residuals ** 2)),
            'rmse': float(np.sqrt(np.mean(residuals ** 2))),
            'mape': float(np.mean(np.abs(residuals / series.iloc[1:])) * 100),
            'drift': float(drift),
        }
        
        return metrics
    
    def _calculate_generic_metrics(self, series: pd.Series, model: Any) -> Dict[str, float]:
        """Calculate generic metrics as fallback."""
        # Simple metrics based on series variability
        metrics = {
            'series_mean': float(series.mean()),
            'series_std': float(series.std()),
            'series_variance': float(series.var()),
        }
        
        return metrics


# Convenience functions
def forecast_time_series(series: pd.Series,
                        steps: int = 30,
                        model_type: str = "auto_arima",
                        seasonal_period: Optional[int] = None,
                        confidence_level: float = 0.95,
                        **kwargs) -> ForecastResult:
    """
    Convenience function for time series forecasting.
    
    Args:
        series: Time series data
        steps: Number of steps to forecast
        model_type: Forecasting model type
        seasonal_period: Seasonal period for seasonal models
        confidence_level: Confidence level for prediction intervals
        **kwargs: Additional arguments for TimeSeriesForecaster
        
    Returns:
        ForecastResult object
    """
    forecaster = TimeSeriesForecaster(
        model_type=ForecastModel(model_type),
        seasonal_period=seasonal_period,
        confidence_level=confidence_level,
        **kwargs
    )
    return forecaster.forecast(series, steps=steps)


def evaluate_forecast(actual: pd.Series,
                     forecast: pd.Series,
                     metrics: List[str] = ['mae', 'mse', 'rmse', 'mape']) -> Dict[str, float]:
    """
    Evaluate forecast accuracy.
    
    Args:
        actual: Actual values
        forecast: Forecasted values
        metrics: List of metrics to calculate
        
    Returns:
        Dictionary of metric values
    """
    # Align indices
    common_idx = actual.index.intersection(forecast.index)
    if len(common_idx) == 0:
        raise ValueError("Actual and forecast must have overlapping indices")
    
    actual_aligned = actual.loc[common_idx]
    forecast_aligned = forecast.loc[common_idx]
    
    results = {}
    
    for metric in metrics:
        metric_lower = metric.lower()
        
        if metric_lower == 'mae':
            # Mean Absolute Error
            results['mae'] = float(np.mean(np.abs(actual_aligned - forecast_aligned)))
        
        elif metric_lower == 'mse':
            # Mean Squared Error
            results['mse'] = float(np.mean((actual_aligned - forecast_aligned) ** 2))
        
        elif metric_lower == 'rmse':
            # Root Mean Squared Error
            mse = np.mean((actual_aligned - forecast_aligned) ** 2)
            results['rmse'] = float(np.sqrt(mse))
        
        elif metric_lower == 'mape':
            # Mean Absolute Percentage Error
            # Avoid division by zero
            mask = actual_aligned != 0
            if mask.any():
                mape = np.mean(np.abs((actual_aligned[mask] - forecast_aligned[mask]) / actual_aligned[mask])) * 100
                results['mape'] = float(mape)
            else:
                results['mape'] = float('inf')
        
        elif metric_lower == 'smape':
            # Symmetric Mean Absolute Percentage Error
            denominator = np.abs(actual_aligned) + np.abs(forecast_aligned)
            mask = denominator != 0
            if mask.any():
                smape = 200 * np.mean(np.abs(forecast_aligned[mask] - actual_aligned[mask]) / denominator[mask])
                results['smape'] = float(smape)
            else:
                results['smape'] = float('inf')
        
        elif metric_lower == 'mase':
            # Mean Absolute Scaled Error
            # Use naive forecast as baseline
            if len(actual_aligned) > 1:
                naive_forecast = actual_aligned.shift(1).dropna()
                naive_error = np.mean(np.abs(actual_aligned.iloc[1:] - naive_forecast))
                if naive_error != 0:
                    mase = np.mean(np.abs(actual_aligned - forecast_aligned)) / naive_error
                    results['mase'] = float(mase)
                else:
                    results['mase'] = float('inf')
            else:
                results['mase'] = float('inf')
    
    return results


def cross_validate_forecast(series: pd.Series,
                           model_type: str = "auto_arima",
                           n_splits: int = 5,
                           test_size: float = 0.2,
                           **kwargs) -> Dict[str, Any]:
    """
    Perform time series cross-validation.
    
    Args:
        series: Time series data
        model_type: Forecasting model type
        n_splits: Number of cross-validation splits
        test_size: Proportion of data to use for testing in each split
        **kwargs: Additional arguments for forecasting
        
    Returns:
        Dictionary with cross-validation results
    """
    results = {
        'scores': [],
        'metrics': {},
        'models': []
    }
    
    n = len(series)
    min_train_size = max(10, int(n * 0.2))  # At least 20% for training
    
    for i in range(n_splits):
        # Calculate train/test split
        test_start = int(n * (1 - test_size * (i + 1) / n_splits))
        train_end = test_start - 1
        
        if train_end < min_train_size:
            warnings.warn(f"Split {i+1}: Training set too small, skipping.")
            continue
        
        train_series = series.iloc[:train_end]
        test_series = series.iloc[test_start:]
        
        if len(test_series) < 1:
            warnings.warn(f"Split {i+1}: Test set too small, skipping.")
            continue
        
        try:
            # Train model
            forecaster = TimeSeriesForecaster(
                model_type=ForecastModel(model_type),
                **kwargs
            )
            
            # Forecast
            forecast_result = forecaster.forecast(
                train_series,
                steps=len(test_series)
            )
            
            # Evaluate
            metrics = evaluate_forecast(
                test_series,
                forecast_result.forecast,
                metrics=['mae', 'mse', 'rmse', 'mape']
            )
            
            results['scores'].append(metrics)
            results['models'].append({
                'split': i,
                'train_size': len(train_series),
                'test_size': len(test_series),
                'model_summary': forecast_result.model_summary
            })
            
        except Exception as e:
            warnings.warn(f"Split {i+1} failed: {str(e)}")
    
    # Calculate average metrics
    if results['scores']:
        all_metrics = {}
        for metric in results['scores'][0].keys():
            values = [score[metric] for score in results['scores'] if metric in score]
            if values:
                all_metrics[f'mean_{metric}'] = float(np.mean(values))
                all_metrics[f'std_{metric}'] = float(np.std(values))
        
        results['metrics'] = all_metrics
    
    return results