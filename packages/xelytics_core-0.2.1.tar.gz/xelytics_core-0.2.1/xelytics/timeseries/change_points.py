"""
Change point detection module for xelytics-core v0.2.0.
Implements PELT, binary segmentation, and window-based change point detection.
"""

import pandas as pd
import numpy as np
from typing import Dict, Any, List, Optional, Tuple, Union
from dataclasses import dataclass, field
import warnings
from enum import Enum
from collections import defaultdict
import ruptures as rpt


class ChangePointMethod(str, Enum):
    """Available change point detection methods."""
    PELT = "pelt"            # Pruned Exact Linear Time
    BINSEG = "binseg"        # Binary Segmentation
    WINDOW = "window"        # Window-based
    DYNAMIC_PROGRAMMING = "dynp"  # Dynamic Programming
    KERNEL_CPD = "kernel"    # Kernel Change Point Detection


class ChangePointMetric(str, Enum):
    """Cost functions for change point detection."""
    L2 = "l2"                # L2 norm (mean change)
    L1 = "l1"                # L1 norm (median change)
    RBF = "rbf"              # Radial Basis Function (kernel)
    NORMAL = "normal"        # Normal distribution
    RANK = "rank"            # Rank-based


@dataclass
class ChangePointResult:
    """Result of change point detection."""
    series: pd.Series
    change_points: List[int]  # Indices of change points
    change_dates: List[pd.Timestamp]  # Dates of change points
    segments: List[pd.Series]  # Series segments between change points
    method: ChangePointMethod
    metric: ChangePointMetric
    scores: Optional[List[float]] = None  # Change point scores
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def summary(self) -> Dict[str, Any]:
        """Get summary statistics of change points."""
        n_segments = len(self.segments)
        
        segment_stats = []
        for i, segment in enumerate(self.segments):
            segment_stats.append({
                'segment_id': i,
                'start_date': segment.index[0],
                'end_date': segment.index[-1],
                'length': len(segment),
                'mean': float(segment.mean()),
                'std': float(segment.std()),
                'trend': self._calculate_segment_trend(segment)
            })
        
        return {
            'method': self.method.value,
            'metric': self.metric.value,
            'n_change_points': len(self.change_points),
            'n_segments': n_segments,
            'change_point_indices': self.change_points,
            'change_point_dates': [d.isoformat() for d in self.change_dates],
            'segment_stats': segment_stats,
            'average_segment_length': np.mean([len(s) for s in self.segments]) if self.segments else 0
        }
    
    def _calculate_segment_trend(self, segment: pd.Series) -> float:
        """Calculate trend of a segment using linear regression."""
        if len(segment) < 2:
            return 0.0
        
        x = np.arange(len(segment))
        y = segment.values
        slope = np.polyfit(x, y, 1)[0]
        return float(slope)
    
    def to_dataframe(self) -> pd.DataFrame:
        """Convert change point results to DataFrame."""
        data = []
        
        for i, segment in enumerate(self.segments):
            data.append({
                'segment_id': i,
                'start_date': segment.index[0],
                'end_date': segment.index[-1],
                'length': len(segment),
                'mean': segment.mean(),
                'std': segment.std(),
                'min': segment.min(),
                'max': segment.max()
            })
        
        return pd.DataFrame(data)
    
    def plot(self, figsize: Tuple[int, int] = (12, 6), title: Optional[str] = None) -> Any:
        """Plot change points."""
        import matplotlib.pyplot as plt
        
        fig, ax = plt.subplots(figsize=figsize)
        
        # Plot time series
        ax.plot(self.series.index, self.series.values, 
                label='Time Series', color='black', linewidth=1.5)
        
        # Plot change points
        for i, (idx, date) in enumerate(zip(self.change_points, self.change_dates)):
            if idx < len(self.series):
                ax.axvline(x=date, color='red', linestyle='--', 
                          alpha=0.7, label='Change Point' if i == 0 else None)
                # Add text label
                ax.text(date, self.series.max() * 0.95, f'CP{i+1}', 
                       rotation=90, verticalalignment='top', fontsize=10)
        
        # Highlight segments with different colors
        colors = plt.cm.tab10(np.linspace(0, 1, len(self.segments)))
        current_idx = 0
        
        for i, segment in enumerate(self.segments):
            if len(segment) > 0:
                segment_idx = np.arange(current_idx, current_idx + len(segment))
                ax.fill_between(self.series.index[segment_idx], 
                               self.series.values[segment_idx] * 0.95,
                               self.series.values[segment_idx] * 1.05,
                               color=colors[i % len(colors)], alpha=0.2)
                current_idx += len(segment)
        
        # Title and labels
        if title:
            ax.set_title(title)
        else:
            method_name = self.method.value.upper()
            ax.set_title(f'{method_name} Change Point Detection - {len(self.change_points)} change points')
        
        ax.set_xlabel('Time')
        ax.set_ylabel('Value')
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        return fig


class ChangePointDetector:
    """
    Change point detection engine for time series.
    
    Supports multiple detection methods:
    - PELT (Pruned Exact Linear Time)
    - Binary Segmentation
    - Window-based detection
    - Dynamic Programming
    - Kernel Change Point Detection
    """
    
    def __init__(self, 
                 method: ChangePointMethod = ChangePointMethod.PELT,
                 metric: ChangePointMetric = ChangePointMetric.L2,
                 min_segment_length: int = 10,
                 penalty: float = 2.0,
                 n_change_points: Optional[int] = None):
        """
        Initialize the change point detector.
        
        Args:
            method: Change point detection method
            metric: Cost function/metric for change point detection
            min_segment_length: Minimum length of segments
            penalty: Penalty for adding change points
            n_change_points: Number of change points to detect (if None, automatic)
        """
        self.method = method
        self.metric = metric
        self.min_segment_length = min_segment_length
        self.penalty = penalty
        self.n_change_points = n_change_points
        
        # Check dependencies
        self._check_dependencies()
    
    def _check_dependencies(self):
        """Check if required packages are installed."""
        try:
            import ruptures
            self._ruptures_available = True
        except ImportError:
            self._ruptures_available = False
            warnings.warn(
                "ruptures package is required for change point detection. "
                "Install with: pip install ruptures"
            )
    
    def detect(self, series: pd.Series, **kwargs) -> ChangePointResult:
        """
        Detect change points in time series.
        
        Args:
            series: Time series data
            **kwargs: Additional method-specific parameters
            
        Returns:
            ChangePointResult object
            
        Raises:
            ImportError: If ruptures is not installed
        """
        if not self._ruptures_available:
            raise ImportError(
                "ruptures package is required for change point detection. "
                "Install with: pip install ruptures"
            )
        
        # Ensure series is sorted
        series = series.sort_index()
        
        # Handle NaN values
        if series.isna().any():
            series_clean = series.fillna(method='ffill').fillna(method='bfill')
            if series.isna().sum() > 0:
                warnings.warn(f"Found {series.isna().sum()} NaN values. Filled with forward/backward fill.")
        else:
            series_clean = series.copy()
        
        # Convert to numpy array for ruptures
        signal = series_clean.values.reshape(-1, 1)
        
        # Dispatch to appropriate detection method
        try:
            if self.method == ChangePointMethod.PELT:
                change_points = self._detect_pelt(signal, **kwargs)
            elif self.method == ChangePointMethod.BINSEG:
                change_points = self._detect_binseg(signal, **kwargs)
            elif self.method == ChangePointMethod.WINDOW:
                change_points = self._detect_window(signal, **kwargs)
            elif self.method == ChangePointMethod.DYNAMIC_PROGRAMMING:
                change_points = self._detect_dynp(signal, **kwargs)
            elif self.method == ChangePointMethod.KERNEL_CPD:
                change_points = self._detect_kernel(signal, **kwargs)
            else:
                raise ValueError(f"Unknown change point detection method: {self.method}")
        except Exception as e:
            warnings.warn(f"Change point detection failed: {str(e)}. Falling back to simple detection.")
            change_points = self._detect_simple(signal)
        
        # Convert indices to proper format (exclude last index)
        change_points = [cp for cp in change_points if cp > 0 and cp < len(series_clean)]
        
        # Create segments
        segments = self._create_segments(series_clean, change_points)
        
        # Get change point dates
        change_dates = [series_clean.index[cp] for cp in change_points]
        
        # Calculate scores (optional)
        scores = self._calculate_change_scores(series_clean, change_points)
        
        return ChangePointResult(
            series=series_clean,
            change_points=change_points,
            change_dates=change_dates,
            segments=segments,
            method=self.method,
            metric=self.metric,
            scores=scores,
            metadata={
                'method': self.method.value,
                'metric': self.metric.value,
                'min_segment_length': self.min_segment_length,
                'penalty': self.penalty,
                'n_change_points': self.n_change_points
            }
        )
    
    def _detect_pelt(self, signal: np.ndarray, **kwargs) -> List[int]:
        """Detect change points using PELT algorithm."""
        penalty = kwargs.get('penalty', self.penalty)
        min_size = kwargs.get('min_size', self.min_segment_length)
        
        # Choose model based on metric
        if self.metric == ChangePointMetric.L2:
            model = "l2"
        elif self.metric == ChangePointMetric.L1:
            model = "l1"
        elif self.metric == ChangePointMetric.RBF:
            model = "rbf"
        else:
            model = "l2"  # Default
        
        algo = rpt.Pelt(model=model, min_size=min_size).fit(signal)
        result = algo.predict(pen=penalty)
        
        return result[:-1]  # Exclude last index
    
    def _detect_binseg(self, signal: np.ndarray, **kwargs) -> List[int]:
        """Detect change points using Binary Segmentation."""
        n_bkps = kwargs.get('n_bkps', self.n_change_points)
        if n_bkps is None:
            n_bkps = max(1, len(signal) // (self.min_segment_length * 2))
        
        model = self._get_ruptures_model()
        algo = rpt.Binseg(model=model).fit(signal)
        result = algo.predict(n_bkps=n_bkps)
        
        return result[:-1]  # Exclude last index
    
    def _detect_window(self, signal: np.ndarray, **kwargs) -> List[int]:
        """Detect change points using Window-based method."""
        width = kwargs.get('width', min(100, len(signal) // 4))
        n_bkps = kwargs.get('n_bkps', self.n_change_points)
        
        if n_bkps is None:
            n_bkps = max(1, len(signal) // (self.min_segment_length * 2))
        
        model = self._get_ruptures_model()
        algo = rpt.Window(width=width, model=model).fit(signal)
        result = algo.predict(n_bkps=n_bkps)
        
        return result[:-1]  # Exclude last index
    
    def _detect_dynp(self, signal: np.ndarray, **kwargs) -> List[int]:
        """Detect change points using Dynamic Programming."""
        n_bkps = kwargs.get('n_bkps', self.n_change_points)
        if n_bkps is None:
            n_bkps = max(1, len(signal) // (self.min_segment_length * 2))
        
        model = self._get_ruptures_model()
        algo = rpt.Dynp(model=model, min_size=self.min_segment_length).fit(signal)
        result = algo.predict(n_bkps=n_bkps)
        
        return result[:-1]  # Exclude last index
    
    def _detect_kernel(self, signal: np.ndarray, **kwargs) -> List[int]:
        """Detect change points using Kernel Change Point Detection."""
        n_bkps = kwargs.get('n_bkps', self.n_change_points)
        if n_bkps is None:
            n_bkps = max(1, len(signal) // (self.min_segment_length * 2))
        
        # For kernel, we need to use a different approach
        kernel = kwargs.get('kernel', "linear")
        gamma = kwargs.get('gamma', None)
        
        from ruptures import KernelCPD
        algo = KernelCPD(kernel=kernel, min_size=self.min_segment_length).fit(signal)
        result = algo.predict(n_bkps=n_bkps)
        
        return result[:-1]  # Exclude last index
    
    def _detect_simple(self, signal: np.ndarray) -> List[int]:
        """Simple change point detection as fallback."""
        n_points = len(signal)
        
        # Simple approach: detect changes in mean
        window_size = max(self.min_segment_length, n_points // 10)
        change_points = []
        
        for i in range(window_size, n_points - window_size, window_size):
            left_mean = np.mean(signal[i-window_size:i])
            right_mean = np.mean(signal[i:i+window_size])
            
            # Simple threshold for change
            if abs(right_mean - left_mean) > np.std(signal) * 0.5:
                change_points.append(i)
        
        return change_points
    
    def _get_ruptures_model(self) -> str:
        """Get ruptures model string based on metric."""
        model_map = {
            ChangePointMetric.L2: "l2",
            ChangePointMetric.L1: "l1",
            ChangePointMetric.RBF: "rbf",
            ChangePointMetric.NORMAL: "normal",
            ChangePointMetric.RANK: "rank"
        }
        return model_map.get(self.metric, "l2")
    
    def _create_segments(self, series: pd.Series, change_points: List[int]) -> List[pd.Series]:
        """Create segments from change points."""
        if not change_points:
            return [series]
        
        segments = []
        start_idx = 0
        
        for cp in change_points:
            if cp > start_idx and cp <= len(series):
                segments.append(series.iloc[start_idx:cp])
                start_idx = cp
        
        # Add final segment
        if start_idx < len(series):
            segments.append(series.iloc[start_idx:])
        
        return segments
    
    def _calculate_change_scores(self, series: pd.Series, change_points: List[int]) -> List[float]:
        """Calculate scores for each change point."""
        if not change_points:
            return []
        
        scores = []
        
        for cp in change_points:
            if cp > 0 and cp < len(series):
                # Calculate how significant the change is
                left_segment = series.iloc[max(0, cp-10):cp]
                right_segment = series.iloc[cp:min(len(series), cp+10)]
                
                if len(left_segment) > 0 and len(right_segment) > 0:
                    # Score based on difference in means
                    left_mean = left_segment.mean()
                    right_mean = right_segment.mean()
                    pooled_std = np.sqrt((left_segment.var() + right_segment.var()) / 2)
                    
                    if pooled_std > 0:
                        score = abs(right_mean - left_mean) / pooled_std
                    else:
                        score = abs(right_mean - left_mean)
                    
                    scores.append(float(score))
                else:
                    scores.append(0.0)
        
        return scores


# Convenience functions
def detect_change_points(series: pd.Series,
                        method: str = "pelt",
                        metric: str = "l2",
                        **kwargs) -> ChangePointResult:
    """
    Convenience function for change point detection.
    
    Args:
        series: Time series data
        method: Change point detection method
        metric: Cost function/metric
        **kwargs: Additional arguments for ChangePointDetector
        
    Returns:
        ChangePointResult object
    """
    detector = ChangePointDetector(
        method=ChangePointMethod(method),
        metric=ChangePointMetric(metric),
        **kwargs
    )
    return detector.detect(series)


def analyze_change_points(result: ChangePointResult) -> Dict[str, Any]:
    """
    Analyze change point detection results.
    
    Args:
        result: ChangePointResult object
        
    Returns:
        Dictionary with detailed analysis
    """
    analysis = {
        'summary': result.summary(),
        'segment_analysis': [],
        'change_point_analysis': []
    }
    
    # Analyze each segment
    for i, segment in enumerate(result.segments):
        if len(segment) > 1:
            segment_analysis = {
                'segment_id': i,
                'length': len(segment),
                'statistics': {
                    'mean': float(segment.mean()),
                    'std': float(segment.std()),
                    'min': float(segment.min()),
                    'max': float(segment.max()),
                    'trend': float(np.polyfit(np.arange(len(segment)), segment.values, 1)[0])
                },
                'stationarity': _check_segment_stationarity(segment)
            }
            analysis['segment_analysis'].append(segment_analysis)
    
    # Analyze each change point
    for i, (cp_idx, cp_date) in enumerate(zip(result.change_points, result.change_dates)):
        if cp_idx > 0 and cp_idx < len(result.series):
            before_mean = result.series.iloc[max(0, cp_idx-10):cp_idx].mean()
            after_mean = result.series.iloc[cp_idx:min(len(result.series), cp_idx+10)].mean()
            
            change_analysis = {
                'change_point_id': i,
                'index': cp_idx,
                'date': cp_date.isoformat(),
                'value_at_cp': float(result.series.iloc[cp_idx]),
                'mean_change': float(after_mean - before_mean),
                'change_magnitude': float(abs(after_mean - before_mean)),
                'score': result.scores[i] if result.scores and i < len(result.scores) else None
            }
            analysis['change_point_analysis'].append(change_analysis)
    
    return analysis


def _check_segment_stationarity(segment: pd.Series) -> Dict[str, Any]:
    """Check stationarity of a segment."""
    try:
        from statsmodels.tsa.stattools import adfuller
        
        if len(segment) < 20:
            return {'is_stationary': False, 'p_value': None, 'reason': 'too_short'}
        
        result = adfuller(segment.dropna())
        p_value = result[1]
        
        return {
            'is_stationary': p_value < 0.05,
            'p_value': float(p_value),
            'test_statistic': float(result[0]),
            'critical_values': {key: float(val) for key, val in result[4].items()}
        }
    except Exception:
        return {'is_stationary': None, 'p_value': None, 'reason': 'test_failed'}