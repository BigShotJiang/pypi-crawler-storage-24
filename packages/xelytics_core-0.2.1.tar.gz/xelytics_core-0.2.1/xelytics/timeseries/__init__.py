from typing import List, Optional
import pandas as pd
from xelytics.schemas.outputs import TimeSeriesResult, TimeSeriesType
from xelytics.timeseries.detector import TimeSeriesDetector
from xelytics.timeseries.decomposition import decompose_time_series

try:
    from xelytics.timeseries.anomaly import TimeSeriesAnomalyDetector, AnomalyMethod, detect_anomalies, validate_anomalies
except ImportError:
    try:
        # Fallback if it's stored in detector.py
        from xelytics.timeseries.detector import TimeSeriesAnomalyDetector, AnomalyMethod, detect_anomalies, validate_anomalies
    except ImportError:
        pass

try:
    from xelytics.timeseries.changepoint import ChangePointDetector
except ImportError:
    try:
        # Fallback if it's stored in detector.py
        from xelytics.timeseries.detector import ChangePointDetector
    except ImportError:
        pass 

def analyze_time_series(
    df: pd.DataFrame,
    datetime_column: Optional[str] = None,
    forecast_periods: int = 0,
    config: Optional[dict] = None,
) -> List[TimeSeriesResult]:
    """
    Detect all time series columns and return a list of TimeSeriesResult.
    If datetime_column is given, only analyze that column; otherwise auto-detect.
    """
    detector = TimeSeriesDetector()
    if datetime_column:
        results = detector.detect(df, [datetime_column])
    else:
        results = detector.detect(df)

    ts_results = []
    for detection in results:
        if not detection.is_time_series:
            continue

        # Get characteristics (includes trend/seasonality flags)
        try:
            char = detector.characterize(df, detection.column_name)
        except Exception:
            # Fallback if characterization fails
            char = None

        ts_result = TimeSeriesResult(
            column=detection.column_name,
            series_type=TimeSeriesType.TREND_SEASONAL if (char and char.has_trend and char.has_seasonality) else
                        TimeSeriesType.TREND if (char and char.has_trend) else
                        TimeSeriesType.SEASONAL if (char and char.has_seasonality) else
                        TimeSeriesType.RANDOM,
            is_stationary=char.is_stationary if char else False,
            has_trend=char.has_trend if char else False,
            has_seasonality=char.has_seasonality if char else False,
            seasonal_period=char.seasonality_period if char else None,
            trend_strength=None,
            seasonality_strength=None,
        )
        ts_results.append(ts_result)

    return ts_results