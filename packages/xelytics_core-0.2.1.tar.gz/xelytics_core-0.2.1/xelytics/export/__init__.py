"""Export and report generation module."""

from .html_report import HTMLReportGenerator, generate_html_report
from .pdf import html_to_pdf, generate_pdf_report
from .pptx import generate_pptx_report
from .notebook import generate_notebook

__all__ = [
    "HTMLReportGenerator",
    "generate_html_report",
    "html_to_pdf",
    "generate_pdf_report",
    "generate_pptx_report",
    "generate_notebook",
    "export_to_format",
]

def export_to_format(
    analysis_result,
    format_type: str = "html",
    **kwargs
) -> bytes:
    """Export analysis results to specified format."""
    if format_type == "html":
        html_content = generate_html_report(analysis_result, **kwargs)
        return html_content.encode('utf-8')
    elif format_type == "pdf":
        return generate_pdf_report(analysis_result, **kwargs)
    elif format_type == "json":
        import json
        if hasattr(analysis_result, 'model_dump'):
            data = analysis_result.model_dump()
        elif hasattr(analysis_result, 'dict'):
            data = analysis_result.dict()
        else:
            data = analysis_result.__dict__
        return json.dumps(data, indent=2, default=str).encode('utf-8')
    elif format_type == "pptx":
        return generate_pptx_report(analysis_result, **kwargs)
    elif format_type == "ipynb":
        notebook_str = generate_notebook(analysis_result, **kwargs)
        return notebook_str.encode('utf-8')
    else:
        raise ValueError(f"Unsupported export format: {format_type}")