"""
HTML report generator for xelytics-core v0.2.0.
Produces standalone interactive reports with embedded Plotly charts.
Now supports static image output for PDF generation.
"""

import json
import base64
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any, List, Union
import logging

import pandas as pd
from jinja2 import Environment, FileSystemLoader, Template
import plotly.io as pio
import plotly.graph_objects as go

from xelytics import __version__
from xelytics.schemas.outputs import AnalysisResult, VisualizationSpec

logger = logging.getLogger(__name__)

# Try to import kaleido for image export (optional)
try:
    import kaleido  # noqa
    KALEIDO_AVAILABLE = True
except ImportError:
    KALEIDO_AVAILABLE = False
    logger.warning("kaleido not installed; PDF charts will fall back to text.")


class HTMLReportGenerator:
    """
    Generate interactive HTML reports from AnalysisResult.
    
    Uses Jinja2 templates and embeds Plotly charts as HTML or static images.
    Supports theming and custom branding.
    """
    
    def __init__(
        self,
        template_dir: Optional[Union[str, Path]] = None,
        theme: str = "light",
        logo_url: Optional[str] = None,
        logo_text: Optional[str] = None,
        custom_css: Optional[str] = None,
    ):
        """
        Initialize the report generator.
        
        Args:
            template_dir: Custom template directory. If None, uses default templates.
            theme: "light" or "dark".
            logo_url: URL to logo image (optional).
            logo_text: Text to display next to logo (e.g., company name).
            custom_css: Additional CSS to inject.
        """
        if template_dir is None:
            # Use default templates inside package
            default_dir = Path(__file__).parent / "templates"
            if not default_dir.exists():
                raise RuntimeError(f"Default template directory not found: {default_dir}")
            template_dir = default_dir
        
        self.env = Environment(
            loader=FileSystemLoader(str(template_dir)),
            autoescape=True
        )
        self.theme = theme
        self.logo_url = logo_url
        self.logo_text = logo_text
        self.custom_css = custom_css
    
    def generate(
        self,
        result: AnalysisResult,
        title: str = "Xelytics Analysis Report",
        author: Optional[str] = None,
        summary_text: Optional[str] = None,
        format: str = "html",  # new parameter: 'html' or 'pdf'
        **kwargs
    ) -> str:
        """
        Generate HTML report from analysis result.
        
        Args:
            result: AnalysisResult object.
            title: Report title.
            author: Report author.
            summary_text: Optional custom summary text.
            format: Output format – 'html' (interactive) or 'pdf' (static images).
            **kwargs: Additional template variables.
        
        Returns:
            HTML string.
        """
        # Prepare template variables
        template_vars = {
            "title": title,
            "author": author,
            "generation_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "package_version": __version__,
            "theme": self.theme,
            "logo_url": self.logo_url,
            "logo_text": self.logo_text,
            "custom_css": self.custom_css,
            "summary_text": summary_text or "Analysis completed successfully.",
            "summary": result.summary,
            "statistics": self._prepare_statistics(result.statistics),
            "visualizations": self._prepare_visualizations(result.visualizations, format),
            "insights": result.insights,
            "metadata": result.metadata,
        }
        
        # Add v0.2.0 specific fields if present
        if hasattr(result, 'time_series_analysis') and result.time_series_analysis:
            template_vars["time_series_results"] = result.time_series_analysis
        if hasattr(result, 'clusters') and result.clusters:
            template_vars["clustering_results"] = {
                "algorithm": getattr(result.clusters, 'algorithm', 'unknown'),
                "n_clusters": len(result.clusters) if result.clusters else 0,
                "silhouette_score": getattr(result.clusters, 'silhouette_score', None),
                "clusters": result.clusters,
            }
        
        # Merge any additional kwargs
        template_vars.update(kwargs)
        
        # Load and render template
        template = self.env.get_template("report_base.html")
        html = template.render(**template_vars)
        return html
    
    def _prepare_statistics(self, statistics: List[Any]) -> List[Dict]:
        """Format statistical test results for template."""
        prepared = []
        for test in statistics:
            # Format effect size nicely if present
            effect_size_display = None
            if test.effect_size:
                if hasattr(test.effect_size, 'value') and hasattr(test.effect_size, 'interpretation'):
                    effect_size_display = {
                        'value': test.effect_size.value,
                        'interpretation': test.effect_size.interpretation,
                        'measure_type': getattr(test.effect_size, 'measure_type', 'effect size')
                    }
                else:
                    effect_size_display = str(test.effect_size)
            
            description = getattr(test, 'description', 
                         getattr(test, 'interpretation', 
                         getattr(test, 'summary', '')))
            
            prepared.append({
                'test_name': test.test_name,
                'p_value': test.p_value,
                'significant': test.significant,
                'effect_size': effect_size_display,
                'description': description,
            })
        return prepared
    
    def _prepare_visualizations(self, visualizations: List[Any], format: str = "html") -> List[Dict]:
        """
        Convert visualization objects to dict with HTML representation.
        
        Args:
            visualizations: List of visualization objects.
            format: 'html' for interactive Plotly, 'pdf' for static images.
        
        Returns:
            List of dicts with 'title' and 'html' keys.
        """
        prepared = []
        for viz in visualizations:
            title = getattr(viz, 'title', 'Visualization')
            html_content = None
            
            # For PDF format, try to generate static image
            if format == "pdf" and KALEIDO_AVAILABLE:
                try:
                    # Convert to Plotly figure if it's a VisualizationSpec
                    if isinstance(viz, VisualizationSpec) and hasattr(viz, 'plotly_spec'):
                        fig = go.Figure(data=viz.plotly_spec.get('data', []),
                                        layout=viz.plotly_spec.get('layout', {}))
                    elif hasattr(viz, 'to_dict'):
                        fig = viz  # assume it's already a plotly figure
                    else:
                        fig = None
                    
                    if fig is not None:
                        # Export as PNG base64
                        img_bytes = pio.to_image(fig, format='png', width=800, height=500)
                        img_base64 = base64.b64encode(img_bytes).decode('utf-8')
                        html_content = f'<img src="data:image/png;base64,{img_base64}" style="max-width:100%; height:auto;"/>'
                except Exception as e:
                    logger.warning(f"Failed to convert visualization '{title}' to image: {e}")
                    html_content = f"<pre>{viz}</pre>"
            
            # If not PDF or conversion failed, use interactive HTML or fallback
            if html_content is None:
                if hasattr(viz, 'to_html'):
                    html_content = viz.to_html(include_plotlyjs='cdn', full_html=False)
                elif isinstance(viz, VisualizationSpec) and hasattr(viz, 'plotly_spec'):
                    try:
                        fig = go.Figure(data=viz.plotly_spec.get('data', []),
                                        layout=viz.plotly_spec.get('layout', {}))
                        html_content = pio.to_html(fig, include_plotlyjs='cdn', full_html=False)
                    except:
                        html_content = f"<pre>{viz}</pre>"
                else:
                    html_content = f"<pre>{viz}</pre>"
            
            prepared.append({
                "title": title,
                "html": html_content
            })
        return prepared


# Convenience function
def generate_html_report(
    result: AnalysisResult,
    title: str = "Xelytics Analysis Report",
    author: Optional[str] = None,
    theme: str = "light",
    logo_url: Optional[str] = None,
    logo_text: Optional[str] = None,
    output_path: Optional[Union[str, Path]] = None,
    format: str = "html",  # new parameter
    **kwargs
) -> str:
    """
    Generate an HTML report and optionally save to file.
    
    Args:
        result: AnalysisResult object.
        title: Report title.
        author: Report author.
        theme: "light" or "dark".
        logo_url: URL to logo image (optional).
        logo_text: Text to display next to logo (e.g., company name).
        output_path: If provided, save HTML to this file.
        format: 'html' (interactive) or 'pdf' (static images for PDF conversion).
        **kwargs: Additional arguments passed to HTMLReportGenerator.
    
    Returns:
        HTML string.
    """
    generator = HTMLReportGenerator(theme=theme, logo_url=logo_url, logo_text=logo_text)
    html = generator.generate(result, title=title, author=author, format=format, **kwargs)
    
    if output_path:
        output_path = Path(output_path)
        output_path.write_text(html, encoding='utf-8')
        logger.info(f"HTML saved to {output_path}")
    
    return html