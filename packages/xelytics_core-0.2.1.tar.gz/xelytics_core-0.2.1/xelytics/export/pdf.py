"""
PDF export module for xelytics-core.
Converts HTML reports to PDF using WeasyPrint.
"""

import logging
from pathlib import Path
from typing import Optional, Union


logger = logging.getLogger(__name__)


def html_to_pdf(
    html_content: str,
    output_path: Optional[Union[str, Path]] = None,
    **kwargs,
) -> bytes:
    """
    Convert HTML string to PDF bytes or save to file.

    Args:
        html_content: HTML string.
        output_path: If provided, save PDF to this file.
        **kwargs: Additional arguments to weasyprint.HTML (e.g., base_url).

    Returns:
        PDF as bytes (if output_path is None) or empty bytes after saving.
    """
    from weasyprint import HTML
    try:
        html = HTML(string=html_content, **kwargs)
        pdf_bytes = html.write_pdf()

        if output_path:
            output_path = Path(output_path)
            output_path.write_bytes(pdf_bytes)
            logger.info(f"PDF saved to {output_path}")
            return b""

        return pdf_bytes
    except Exception as e:
        logger.error(f"PDF generation failed: {e}")
        raise


def generate_pdf_report(
    result,
    title: str = "Xelytics Analysis Report",
    author: Optional[str] = None,
    theme: str = "light",
    logo_url: Optional[str] = None,
    logo_text: Optional[str] = None,
    output_path: Optional[Union[str, Path]] = None,
    **kwargs,
) -> bytes:
    """
    Generate a PDF report from an AnalysisResult.
    First generates HTML (with static images), then converts to PDF.
    """
    from .html_report import generate_html_report
    from weasyprint import HTML
    html = generate_html_report(
        result,
        title=title,
        author=author,
        theme=theme,
        logo_url=logo_url,
        logo_text=logo_text,
        format="pdf",  # <-- critical: request static images
        **kwargs
    )

    return html_to_pdf(html, output_path=output_path)