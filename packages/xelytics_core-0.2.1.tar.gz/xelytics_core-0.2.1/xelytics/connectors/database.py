"""Base class for SQL database connectors using SQLAlchemy."""

from abc import abstractmethod
from typing import Optional, Dict, Any
import pandas as pd
from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine

from .base import BaseConnector


class SQLDatabaseConnector(BaseConnector):
    """Base for SQL databases using SQLAlchemy."""

    def __init__(self, **config):
        super().__init__()
        self.engine = None
        self.connection = None
        self.config = config  

    def connect(self, **kwargs) -> bool:
        """Create SQLAlchemy engine and connect."""
        try:
            # merge stored config + runtime overrides
            final_config = {**self.config, **kwargs}

            self.engine = self._create_engine(**final_config)
            self.connection = self.engine.connect()
            self.connected = True
            return True
        except Exception as e:
            self.connected = False
            raise ConnectionError(f"Failed to connect: {e}")

    @abstractmethod
    def _create_engine(self, **kwargs) -> Engine:
        """Create SQLAlchemy engine with driver-specific URL."""
        pass

    def disconnect(self) -> bool:
        """Close connection and dispose engine."""
        if self.connection:
            self.connection.close()
            self.connection = None
        if self.engine:
            self.engine.dispose()
            self.engine = None
        self.connected = False
        return True

    def query(self, query: str, **kwargs) -> pd.DataFrame:
        """Execute SQL query and return DataFrame."""
        if not self.connected:
            raise RuntimeError("Not connected. Call connect() first.")
        try:
            return pd.read_sql(text(query), self.connection, **kwargs)
        except Exception as e:
            raise RuntimeError(f"Query failed: {e}")

    def get_schema(self) -> Dict[str, Any]:
        """Return basic schema information (table names, etc.)."""
        if not self.connected:
            return {}
        try:
            import sqlalchemy
            inspector = sqlalchemy.inspect(self.engine)
            return {
                "tables": inspector.get_table_names(),
                "views": inspector.get_view_names(),
            }
        except:
            return {}