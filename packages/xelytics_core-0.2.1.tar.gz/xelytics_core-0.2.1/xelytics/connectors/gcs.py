"""Google Cloud Storage connector."""

import logging
import pandas as pd
from google.cloud import storage
from io import BytesIO
from .cloud import CloudStorageConnector

logger = logging.getLogger(__name__)


class GCSConnector(CloudStorageConnector):
    """Read files from Google Cloud Storage."""

    def connect(self, **kwargs) -> bool:
        """Create GCS client."""
        try:
            self.client = storage.Client(
                project=kwargs.get('project'),
                credentials=kwargs.get('credentials'),
            )
            self.connected = True
            logger.info("Connected to Google Cloud Storage")
            return True
        except Exception as e:
            raise ConnectionError(f"GCS connection failed: {e}")

    def read_file(self, bucket: str, blob: str, file_type: str = "csv", **kwargs) -> pd.DataFrame:
        """Read blob from bucket."""
        if not self.connected:
            raise RuntimeError("Not connected.")
        try:
            bucket_obj = self.client.bucket(bucket)
            blob_obj = bucket_obj.blob(blob)
            stream = BytesIO()
            blob_obj.download_to_file(stream)
            stream.seek(0)
            if file_type == "csv":
                return pd.read_csv(stream, **kwargs)
            elif file_type == "parquet":
                return pd.read_parquet(stream, **kwargs)
            elif file_type == "json":
                return pd.read_json(stream, **kwargs)
            else:
                raise ValueError(f"Unsupported file type: {file_type}")
        except Exception as e:
            raise RuntimeError(f"GCS read failed: {e}")