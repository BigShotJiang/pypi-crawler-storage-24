"""PostgreSQL connector for xelytics-core v0.2.0
Supports connection pooling, SSL, and pandas DataFrame output.
"""

import logging
from typing import Optional, Dict, Any, Union

import pandas as pd
from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine
from sqlalchemy.pool import QueuePool

from .base import DataConnector

logger = logging.getLogger(__name__)


class PostgresConnector(DataConnector):
    """PostgreSQL database connector with connection pooling."""

    def __init__(
        self,
        connection_string: Optional[str] = None,
        *,
        host: Optional[str] = None,
        port: int = 5432,
        database: Optional[str] = None,
        user: Optional[str] = None,
        password: Optional[str] = None,
        sslmode: str = "require",
        pool_size: int = 5,
        max_overflow: int = 10,
        pool_timeout: float = 30.0,
        **kwargs
    ):
        """
        Initialize connector with either connection_string or component parameters.
        Actual connection is established in connect().
        """
        self.connection_string = connection_string
        self.host = host
        self.port = port
        self.database = database
        self.user = user
        self.password = password
        self.sslmode = sslmode
        self.pool_size = pool_size
        self.max_overflow = max_overflow
        self.pool_timeout = pool_timeout
        self.engine_kwargs = kwargs
        self.engine: Optional[Engine] = None
        self.connected = False

    def connect(self) -> bool:
        """Establish connection pool to PostgreSQL."""
        # Validate parameters now
        if self.connection_string is None:
            if not all([self.host, self.database, self.user, self.password]):
                raise ValueError(
                    "Either connection_string or all of host, database, user, password must be provided"
                )
            # Construct connection string
            self.connection_string = (
                f"postgresql://{self.user}:{self.password}@{self.host}:{self.port}/{self.database}"
                f"?sslmode={self.sslmode}"
            )

        try:
            self.engine = create_engine(
                self.connection_string,
                poolclass=QueuePool,
                pool_size=self.pool_size,
                max_overflow=self.max_overflow,
                pool_timeout=self.pool_timeout,
                echo=False,
                **self.engine_kwargs
            )
            # Test connection
            with self.engine.connect() as conn:
                conn.execute(text("SELECT 1"))

            self.connected = True
            logger.info(f"Connected to PostgreSQL database: {self.connection_string.split('@')[-1]}")
            return True

        except Exception as e:
            logger.error(f"Failed to connect to PostgreSQL: {e}")
            self.connected = False
            return False

    def disconnect(self) -> bool:
        """Dispose the connection pool."""
        if self.engine:
            self.engine.dispose()
            self.engine = None
        self.connected = False
        logger.info("Disconnected from PostgreSQL")
        return True

    def query(self, sql: str) -> pd.DataFrame:
        """Execute SQL query and return results as a pandas DataFrame."""
        if not self.connected or self.engine is None:
            raise ConnectionError("Not connected to database. Call connect() first.")

        try:
            df = pd.read_sql_query(sql, self.engine)
            logger.info(f"Query executed successfully, returned {len(df)} rows")
            return df
        except Exception as e:
            logger.error(f"Query execution failed: {e}")
            raise

    def test_connection(self) -> bool:
        """Verify connection is alive by running a simple query."""
        if not self.connected or self.engine is None:
            return False
        try:
            with self.engine.connect() as conn:
                conn.execute(text("SELECT 1"))
            return True
        except:
            return False