"""Base connector interface for xelytics."""

from abc import ABC, abstractmethod
from typing import Optional, Any
import pandas as pd


class BaseConnector(ABC):
    """Abstract base class for all data connectors."""

    def __init__(self):
        self.connected = False

    @abstractmethod
    def connect(self, **kwargs) -> bool:
        """Establish connection to the data source."""
        pass

    @abstractmethod
    def disconnect(self) -> bool:
        """Close the connection."""
        pass

    @abstractmethod
    def query(self, query: str, **kwargs) -> pd.DataFrame:
        """Execute a query and return results as DataFrame."""
        pass

    def get_schema(self) -> dict:
        """Return schema information (optional)."""
        return {}


# For backward compatibility with existing code that expects DataConnector
DataConnector = BaseConnector