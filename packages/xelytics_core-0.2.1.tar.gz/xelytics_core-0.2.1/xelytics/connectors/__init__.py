"""Data connectors module for xelytics with lazy imports."""

from typing import Optional

# Base classes (always available)
from .base import BaseConnector, DataConnector
from .database import SQLDatabaseConnector
from .cloud import CloudStorageConnector


__all__ = [
    "BaseConnector",
    "DataConnector",
    "SQLDatabaseConnector",
    "CloudStorageConnector",
    "PostgresConnector",
    "MySQLConnector",
    "SQLiteConnector",
    "SnowflakeConnector",
    "BigQueryConnector",
    "S3Connector",
    "AzureBlobConnector",
    "GCSConnector",
    "FileConnector",
    "connect_to_source",
]


def _lazy_import(module_name: str, class_name: str):
    """Import a class lazily."""
    import importlib
    module = importlib.import_module(f".{module_name}", package=__package__)
    return getattr(module, class_name)


def connect_to_source(source_type: str, **kwargs) -> Optional[BaseConnector]:
    """
    Factory function to create the appropriate connector.

    NOTE:
    - This function ONLY creates the connector.
    - It does NOT call connect().
    - Call connector.connect(**config) explicitly when needed.
    """
    source_type = source_type.lower()

    try:
        if source_type in ("postgresql", "postgres"):
            PostgresConnector = _lazy_import("postgres", "PostgresConnector")
            return PostgresConnector()

        elif source_type in ("mysql", "mariadb"):
            MySQLConnector = _lazy_import("mysql", "MySQLConnector")
            return MySQLConnector(**kwargs)

        elif source_type == "sqlite":
            SQLiteConnector = _lazy_import("sqlite", "SQLiteConnector")
            return SQLiteConnector()

        elif source_type == "snowflake":
            SnowflakeConnector = _lazy_import("snowflake", "SnowflakeConnector")
            return SnowflakeConnector()

        elif source_type == "bigquery":
            BigQueryConnector = _lazy_import("bigquery", "BigQueryConnector")
            return BigQueryConnector()

        elif source_type in ("s3", "aws"):
            S3Connector = _lazy_import("s3", "S3Connector")
            return S3Connector()

        elif source_type in ("azureblob", "azure_blob"):
            AzureBlobConnector = _lazy_import("azure_blob", "AzureBlobConnector")
            return AzureBlobConnector()

        elif source_type in ("gcs", "google_cloud_storage"):
            GCSConnector = _lazy_import("gcs", "GCSConnector")
            return GCSConnector()

        elif source_type == "file":
            FileConnector = _lazy_import("file", "FileConnector")
            return FileConnector(**kwargs)

        else:
            raise ValueError(f"Unsupported source type: {source_type}")

    except ImportError as e:
        raise ImportError(
            f"The connector for '{source_type}' requires additional dependencies. "
            f"Install them with: pip install 'xelytics-core[connectors]'"
        ) from e
    
# --- Add this at the bottom of the file ---

def __getattr__(name: str):
    """Dynamically handle lazy imports at the module level (PEP 562)."""
    mapping = {
        "PostgresConnector": "postgres",
        "MySQLConnector": "mysql",
        "SQLiteConnector": "sqlite",
        "SnowflakeConnector": "snowflake",
        "BigQueryConnector": "bigquery",
        "S3Connector": "s3",
        "AzureBlobConnector": "azure_blob",
        "GCSConnector": "gcs",
        "FileConnector": "file",
    }
    if name in mapping:
        return _lazy_import(mapping[name], name)
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")