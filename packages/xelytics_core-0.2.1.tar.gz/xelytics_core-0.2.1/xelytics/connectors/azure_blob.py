"""Azure Blob Storage connector."""

import logging
import pandas as pd
from azure.storage.blob import BlobServiceClient
from io import BytesIO
from .cloud import CloudStorageConnector

logger = logging.getLogger(__name__)


class AzureBlobConnector(CloudStorageConnector):
    """Read files from Azure Blob Storage."""

    def connect(self, **kwargs) -> bool:
        """Create BlobServiceClient."""
        try:
            conn_str = kwargs.get('connection_string')
            if conn_str:
                self.client = BlobServiceClient.from_connection_string(conn_str)
            else:
                self.client = BlobServiceClient(
                    account_url=kwargs.get('account_url'),
                    credential=kwargs.get('credential'),
                )
            self.connected = True
            logger.info("Connected to Azure Blob Storage")
            return True
        except Exception as e:
            raise ConnectionError(f"Azure Blob connection failed: {e}")

    def read_file(self, container: str, blob: str, file_type: str = "csv", **kwargs) -> pd.DataFrame:
        """Read blob from container."""
        if not self.connected:
            raise RuntimeError("Not connected.")
        try:
            blob_client = self.client.get_blob_client(container=container, blob=blob)
            stream = BytesIO()
            blob_client.download_blob().readinto(stream)
            stream.seek(0)
            if file_type == "csv":
                return pd.read_csv(stream, **kwargs)
            elif file_type == "parquet":
                return pd.read_parquet(stream, **kwargs)
            elif file_type == "json":
                return pd.read_json(stream, **kwargs)
            else:
                raise ValueError(f"Unsupported file type: {file_type}")
        except Exception as e:
            raise RuntimeError(f"Azure Blob read failed: {e}")