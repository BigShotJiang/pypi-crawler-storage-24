import os
import logging
import pandas as pd
from .base import BaseConnector

logger = logging.getLogger(__name__)

class FileConnector(BaseConnector):
    """Read local files (CSV, Excel, Parquet, JSON)."""

    def __init__(self, path: str = None, **kwargs):
        super().__init__()
        self.file_path = path

    def connect(self, **kwargs) -> bool:
        # Allow path to be passed in connect()
        self.file_path = self.file_path or kwargs.get("path")

        if not self.file_path:
            raise ValueError("File path must be provided as 'path'")
        if not os.path.exists(self.file_path):
            raise FileNotFoundError(f"File not found: {self.file_path}")

        self.connected = True
        return True

    def disconnect(self) -> bool:
        self.connected = False
        return True

    def query(self, query: str = None, **kwargs) -> pd.DataFrame:
        if not self.connected:
            raise RuntimeError("Not connected")

        ext = os.path.splitext(self.file_path)[1].lower()

        if ext == ".csv":
            df = pd.read_csv(self.file_path, **kwargs)
        elif ext in (".xls", ".xlsx"):
            df = pd.read_excel(self.file_path, **kwargs)
        elif ext == ".parquet":
            df = pd.read_parquet(self.file_path, **kwargs)
        elif ext == ".json":
            df = pd.read_json(self.file_path, **kwargs)
        else:
            raise ValueError(f"Unsupported file extension: {ext}")

        # Column filtering ONLY if query is not a file path
        if query and not os.path.exists(query):
            columns = [c.strip() for c in query.split(",")]
            df = df[columns]

        return df