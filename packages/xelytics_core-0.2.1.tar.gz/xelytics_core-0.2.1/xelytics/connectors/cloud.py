"""Base class for cloud storage connectors."""

from abc import abstractmethod
from typing import Optional
import pandas as pd
from .base import BaseConnector


class CloudStorageConnector(BaseConnector):
    """Base for cloud storage (S3, Azure, GCS)."""

    def __init__(self):
        super().__init__()
        self.client = None

    @abstractmethod
    def connect(self, **kwargs) -> bool:
        """Initialize cloud client."""
        pass

    def disconnect(self) -> bool:
        self.client = None
        self.connected = False
        return True

    @abstractmethod
    def read_file(self, bucket: str, key: str, file_type: str = "csv", **kwargs) -> pd.DataFrame:
        """Read a file from cloud storage into DataFrame."""
        pass

    def query(self, query: str, **kwargs) -> pd.DataFrame:
        """
        For cloud storage, 'query' is interpreted as a file path.
        Expected format: bucket/path/file.ext
        """
        parts = query.split('/', 1)
        if len(parts) != 2:
            raise ValueError("Cloud storage query must be in format: bucket/path")
        bucket, key = parts
        file_type = key.split('.')[-1] if '.' in key else 'csv'
        return self.read_file(bucket, key, file_type=file_type, **kwargs)