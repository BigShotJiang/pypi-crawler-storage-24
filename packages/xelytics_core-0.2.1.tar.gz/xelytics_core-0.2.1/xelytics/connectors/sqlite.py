from sqlalchemy import create_engine
from .database import SQLDatabaseConnector


class SQLiteConnector(SQLDatabaseConnector):
    """SQLite connector (file-based)."""

    def __init__(self, database: str = None, **kwargs):
        # SQLite uses file path instead of host/db/port
        self.database = database or ":memory:"
        super().__init__(**kwargs)

    def _create_engine(self, **kwargs):
        """Create SQLite engine."""
        url = f"sqlite:///{self.database}"
        return create_engine(url, **kwargs.get("engine_options", {}))