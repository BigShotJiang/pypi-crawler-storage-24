"""AWS S3 connector."""

import logging
import pandas as pd
import boto3
from io import BytesIO
from .cloud import CloudStorageConnector

logger = logging.getLogger(__name__)


class S3Connector(CloudStorageConnector):
    """Read files from S3."""

    def connect(self, **kwargs) -> bool:
        """Create S3 client."""
        try:
            self.client = boto3.client(
                's3',
                aws_access_key_id=kwargs.get('aws_access_key_id'),
                aws_secret_access_key=kwargs.get('aws_secret_access_key'),
                region_name=kwargs.get('region_name'),
            )
            self.connected = True
            logger.info("Connected to S3")
            return True
        except Exception as e:
            raise ConnectionError(f"S3 connection failed: {e}")

    def read_file(self, bucket: str, key: str, file_type: str = "csv", **kwargs) -> pd.DataFrame:
        """Read file from S3."""
        if not self.connected:
            raise RuntimeError("Not connected.")
        try:
            response = self.client.get_object(Bucket=bucket, Key=key)
            body = response['Body'].read()
            if file_type == "csv":
                return pd.read_csv(BytesIO(body), **kwargs)
            elif file_type == "parquet":
                return pd.read_parquet(BytesIO(body), **kwargs)
            elif file_type == "json":
                return pd.read_json(BytesIO(body), **kwargs)
            else:
                raise ValueError(f"Unsupported file type: {file_type}")
        except Exception as e:
            raise RuntimeError(f"S3 read failed: {e}")