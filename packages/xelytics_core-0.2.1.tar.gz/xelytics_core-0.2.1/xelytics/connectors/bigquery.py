"""Google BigQuery connector."""

import logging
import pandas as pd
from typing import Optional
from .base import BaseConnector

logger = logging.getLogger(__name__)


class BigQueryConnector(BaseConnector):
    """BigQuery connector using pandas-gbq."""

    def __init__(self):
        super().__init__()
        self.project_id = None
        self.credentials = None

    def connect(self, **kwargs) -> bool:
        """Set up BigQuery connection parameters."""
        self.project_id = kwargs.get("project_id")
        self.credentials = kwargs.get("credentials")  # path to service account JSON or credentials object
        self.connected = True
        logger.info(f"Connected to BigQuery project: {self.project_id}")
        return True

    def disconnect(self) -> bool:
        """Disconnect (no persistent connection)."""
        self.connected = False
        return True

    def query(self, query: str, **kwargs) -> pd.DataFrame:
        """Run a BigQuery SQL query."""
        if not self.connected:
            raise RuntimeError("Not connected.")
        try:
            import pandas_gbq
            df = pandas_gbq.read_gbq(
                query,
                project_id=self.project_id,
                credentials=self.credentials,
                **kwargs
            )
            logger.info(f"BigQuery query executed, returned {len(df)} rows")
            return df
        except Exception as e:
            raise RuntimeError(f"BigQuery query failed: {e}")