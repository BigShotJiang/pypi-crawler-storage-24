from sqlalchemy import create_engine
from .database import SQLDatabaseConnector


class MySQLConnector(SQLDatabaseConnector):
    def _create_engine(self, **kwargs):
        host = kwargs.get("host", "localhost")
        port = int(kwargs.get("port", 3306))
        database = kwargs.get("database")
        user = kwargs.get("user")
        password = kwargs.get("password")
        charset = kwargs.get("charset", "utf8mb4")

        url = (
            f"mysql+pymysql://{user}:{password}"
            f"@{host}:{port}/{database}?charset={charset}"
        )
        return create_engine(url)