"""Snowflake database connector."""

from sqlalchemy import create_engine
from .database import SQLDatabaseConnector


class SnowflakeConnector(SQLDatabaseConnector):
    """Snowflake connector using snowflake-sqlalchemy."""

    def _create_engine(self, **kwargs) -> create_engine:
        """Create Snowflake engine."""
        account = kwargs.get("account")
        user = kwargs.get("user")
        password = kwargs.get("password")
        warehouse = kwargs.get("warehouse")
        database = kwargs.get("database")
        schema_ = kwargs.get("schema")
        role = kwargs.get("role")

        url = f"snowflake://{user}:{password}@{account}/{database}/{schema_}?warehouse={warehouse}&role={role}"
        return create_engine(url, **kwargs.get("engine_options", {}))