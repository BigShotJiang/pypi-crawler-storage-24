"""
Environment configuration loader for xelytics-core v0.2.0
"""

import os
import logging
from typing import Dict, Any, Optional
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)


@dataclass
class EnvironmentConfig:
    """Environment configuration for xelytics-core v0.2.0"""
    
    # Core settings
    env: str = "development"
    debug: bool = True
    app_version: str = "0.2.0-dev"
    
    # Paths
    base_dir: Path = field(default_factory=lambda: Path.cwd())
    cache_dir: Path = field(default_factory=lambda: Path("cache"))
    logs_dir: Path = field(default_factory=lambda: Path("logs"))
    
    # Performance settings
    enable_cache: bool = True
    cache_type: str = "memory"
    parallel_workers: int = 4
    chunk_size: int = 10000
    max_dataset_rows: int = 1000000
    
    # Feature flags for v0.2.0
    enable_timeseries: bool = True
    enable_clustering: bool = True
    enable_connectors: bool = True
    enable_html_reports: bool = True
    enable_custom_pipelines: bool = True
    
    # Database connections (for connectors)
    database_connections: Dict[str, str] = field(default_factory=dict)
    
    # LLM providers
    llm_providers: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    
    @classmethod
    def load_from_env(cls) -> "EnvironmentConfig":
        """Load configuration from environment variables"""
        
        # Try to load from .env file
        try:
            from dotenv import load_dotenv
            # Look for .env file in parent directories
            current_dir = Path.cwd()
            for dir_path in [current_dir, current_dir.parent, current_dir.parent.parent]:
                env_file = dir_path / ".env"
                if env_file.exists():
                    load_dotenv(env_file)
                    logger.info(f"Loaded environment from {env_file}")
                    break
        except ImportError:
            logger.warning("python-dotenv not installed, skipping .env file loading")
        
        # Core settings
        env = os.getenv("XELYTICS_ENV", "development")
        debug = os.getenv("XELYTICS_DEBUG", "true").lower() == "true"
        
        # Feature flags
        enable_timeseries = os.getenv("ENABLE_TIMESERIES", "true").lower() == "true"
        enable_clustering = os.getenv("ENABLE_CLUSTERING", "true").lower() == "true"
        enable_connectors = os.getenv("ENABLE_CONNECTORS", "true").lower() == "true"
        enable_html_reports = os.getenv("ENABLE_HTML_REPORTS", "true").lower() == "true"
        
        # Performance settings
        enable_cache = os.getenv("ENABLE_CACHE", "true").lower() == "true"
        parallel_workers = int(os.getenv("PARALLEL_WORKERS", "4"))
        
        # Database connections
        database_connections = {}
        if os.getenv("POSTGRES_DSN"):
            database_connections["postgresql"] = os.getenv("POSTGRES_DSN")
        if os.getenv("MYSQL_DSN"):
            database_connections["mysql"] = os.getenv("MYSQL_DSN")
        
        # LLM providers
        llm_providers = {}
        if os.getenv("GROQ_API_KEY"):
            llm_providers["groq"] = {
                "api_key": os.getenv("GROQ_API_KEY"),
                "model": os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile"),
                "base_url": os.getenv("GROQ_BASE_URL", "https://api.groq.com/openai/v1"),
            }
        
        # Create cache and logs directories
        cache_dir = Path(os.getenv("CACHE_DIR", "cache"))
        logs_dir = Path(os.getenv("LOGS_DIR", "logs"))
        cache_dir.mkdir(exist_ok=True)
        logs_dir.mkdir(exist_ok=True)
        
        return cls(
            env=env,
            debug=debug,
            enable_timeseries=enable_timeseries,
            enable_clustering=enable_clustering,
            enable_connectors=enable_connectors,
            enable_html_reports=enable_html_reports,
            enable_cache=enable_cache,
            parallel_workers=parallel_workers,
            cache_dir=cache_dir,
            logs_dir=logs_dir,
            database_connections=database_connections,
            llm_providers=llm_providers,
        )
    
    def is_feature_enabled(self, feature: str) -> bool:
        """Check if a feature is enabled"""
        feature_map = {
            "timeseries": self.enable_timeseries,
            "clustering": self.enable_clustering,
            "connectors": self.enable_connectors,
            "html_reports": self.enable_html_reports,
            "cache": self.enable_cache,
            "custom_pipelines": self.enable_custom_pipelines,
        }
        
        return feature_map.get(feature, False)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for logging"""
        return {
            "env": self.env,
            "debug": self.debug,
            "features": {
                "timeseries": self.enable_timeseries,
                "clustering": self.enable_clustering,
                "connectors": self.enable_connectors,
                "html_reports": self.enable_html_reports,
            },
            "performance": {
                "parallel_workers": self.parallel_workers,
                "chunk_size": self.chunk_size,
            },
        }


# Global configuration instance
config = EnvironmentConfig.load_from_env()