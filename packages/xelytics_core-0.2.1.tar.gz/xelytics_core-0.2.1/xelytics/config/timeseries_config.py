"""
Time series specific configuration for xelytics-core v0.2.0.
"""

from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List, Union
from enum import Enum


class TimeSeriesModel(str, Enum):
    """Available time series models."""
    AUTO = "auto"
    ARIMA = "arima"
    SARIMA = "sarima"
    PROPHET = "prophet"
    ETS = "ets"
    LINEAR = "linear"
    NAIVE = "naive"
    SEASONAL_NAIVE = "seasonal_naive"


class DecompositionMethod(str, Enum):
    """Time series decomposition methods."""
    STL = "stl"
    CLASSICAL = "classical"
    X11 = "x11"
    SEASONAL_DECOMPOSE = "seasonal_decompose"


class AnomalyMethod(str, Enum):
    """Anomaly detection methods."""
    STATISTICAL = "statistical"
    ISOLATION_FOREST = "isolation_forest"
    LOF = "lof"
    STL_RESIDUALS = "stl_residuals"
    AUTOENCODER = "autoencoder"


@dataclass
class TimeSeriesConfig:
    """Configuration for time series analysis."""
    
    # ========== DETECTION SETTINGS ==========
    max_missing_ratio: float = 0.3
    min_observations: int = 10
    auto_detect: bool = True
    require_monotonic: bool = True
    
    # ========== FREQUENCY SETTINGS ==========
    default_frequency: Optional[str] = None  # 'D', 'h', 'MS', etc.
    allowed_frequencies: List[str] = field(default_factory=lambda: [
        'YS', 'Y', 'QS', 'Q', 'MS', 'M', 'W', 'D', 'h', 'T', 'S', 'L', 'U'
    ])
    
    # ========== ANALYSIS SETTINGS ==========
    enable_trend_detection: bool = True
    enable_seasonality_detection: bool = True
    enable_stationarity_test: bool = True
    enable_decomposition: bool = True
    enable_forecasting: bool = True
    enable_anomaly_detection: bool = True
    
    # ========== DECOMPOSITION SETTINGS ==========
    decomposition_method: DecompositionMethod = DecompositionMethod.CLASSICAL
    
    # ========== FORECASTING SETTINGS ==========
    default_forecast_model: TimeSeriesModel = TimeSeriesModel.AUTO
    forecast_horizon: int = 30
    confidence_level: float = 0.95
    
    # ========== ANOMALY DETECTION SETTINGS ==========
    anomaly_method: AnomalyMethod = AnomalyMethod.STATISTICAL
    anomaly_contamination: float = 0.1
    
    # ========== PERFORMANCE SETTINGS ==========
    max_rows: int = 100000  # Your specified limit (1 lakh rows)
    enable_caching: bool = True
    enable_parallel_processing: bool = True
    max_parallel_workers: int = 4
    
    # ========== OTHER SETTINGS ==========
    train_test_split: float = 0.8
    
    # ========== FREQUENCY DISPLAY NAMES (after all fields) ==========
    frequency_display_names: Dict[str, str] = field(default_factory=lambda: {
        'YS': 'Year Start',
        'Y': 'Year',
        'QS': 'Quarter Start',
        'Q': 'Quarter',
        'MS': 'Month Start',
        'M': 'Month',
        'W': 'Week',
        'D': 'Day',
        'h': 'Hour',
        'H': 'Hour',
        'T': 'Minute',
        'min': 'Minute',
        'S': 'Second',
        'L': 'Millisecond',
        'U': 'Microsecond',
        'irregular': 'Irregular',
    })
    
    def __post_init__(self):
        """Validate after initialization."""
        self._validate()
    
    def _validate(self):
        """Validate configuration values."""
        if not 0 <= self.max_missing_ratio <= 1:
            raise ValueError("max_missing_ratio must be between 0 and 1")
        
        if self.min_observations < 2:
            raise ValueError("min_observations must be at least 2")
        
        if self.forecast_horizon < 1:
            raise ValueError("forecast_horizon must be at least 1")
        
        if not 0 < self.confidence_level < 1:
            raise ValueError("confidence_level must be between 0 and 1")
        
        if self.max_rows < 100:
            raise ValueError("max_rows must be at least 100")
        
        if self.max_parallel_workers < 1:
            raise ValueError("max_parallel_workers must be at least 1")
        
        if not 0 <= self.anomaly_contamination <= 1:
            raise ValueError("anomaly_contamination must be between 0 and 1")
        
        if not 0 < self.train_test_split < 1:
            raise ValueError("train_test_split must be between 0 and 1")
    
    
    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> "TimeSeriesConfig":
        """Create config from dictionary."""
        return cls(**config_dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        result = {}
        for key, value in self.__dict__.items():
            if isinstance(value, Enum):
                result[key] = value.value
            elif hasattr(value, '__dict__'):
                # Handle nested objects
                result[key] = value.__dict__
            else:
                result[key] = value
        return result
    
    def get_frequency_display_name(self, frequency: str) -> str:
        """Get display name for a frequency code."""
        return self.frequency_display_names.get(frequency, frequency)
    
    def is_frequency_allowed(self, frequency: str) -> bool:
        """Check if a frequency is allowed."""
        if frequency == 'irregular':
            return True
        return frequency in self.allowed_frequencies
    
    def get_model_selection_order(self) -> List[TimeSeriesModel]:
        """Get model selection order based on configuration."""
        if self.default_forecast_model == TimeSeriesModel.AUTO:
            return [
                TimeSeriesModel.ARIMA,
                TimeSeriesModel.PROPHET,
                TimeSeriesModel.ETS,
                TimeSeriesModel.LINEAR,
                TimeSeriesModel.SEASONAL_NAIVE,
                TimeSeriesModel.NAIVE,
            ]
        else:
            return [self.default_forecast_model]
    
    def should_use_parallel(self, n_series: int, n_models: int = 1) -> bool:
        """Determine if parallel processing should be used."""
        if not self.enable_parallel_processing:
            return False
        return n_series > 1 or n_models > 1


# Default configuration
DEFAULT_TIMESERIES_CONFIG = TimeSeriesConfig()