"""
File-based cache backend for xelytics-core.
"""

import hashlib
import pickle
import time
from pathlib import Path
from typing import Any, Optional, Dict


class FileCache:
    """Simple file-based cache implementation."""
    
    def __init__(self, cache_dir: Optional[str] = None, ttl: int = 3600):
        self.cache_dir = Path(cache_dir or "cache")
        self.cache_dir.mkdir(exist_ok=True)
        self.ttl = ttl  # Time to live in seconds
        self._cache: Dict[str, Dict[str, Any]] = {}
        self.enabled = True
    
    def _get_cache_key(self, *args, **kwargs) -> str:
        """Generate cache key from function arguments."""
        key_str = str(args) + str(sorted(kwargs.items()))
        return hashlib.md5(key_str.encode()).hexdigest()
    
    def get(self, key: str) -> Optional[Any]:
        """Get value from cache."""
        cache_file = self.cache_dir / f"{key}.pkl"
        
        if cache_file.exists():
            # Check if cache is expired
            mtime = cache_file.stat().st_mtime
            if time.time() - mtime < self.ttl:
                try:
                    with open(cache_file, 'rb') as f:
                        return pickle.load(f)
                except:
                    pass
        
        return None
    
    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> bool:
        """Set value in cache."""
        cache_file = self.cache_dir / f"{key}.pkl"
        try:
            with open(cache_file, 'wb') as f:
                pickle.dump(value, f)
            return True
        except:
            return False
    
    def delete(self, key: str) -> bool:
        """Delete a key from cache."""
        cache_file = self.cache_dir / f"{key}.pkl"
        try:
            if cache_file.exists():
                cache_file.unlink()
                return True
            return False
        except:
            return False
    
    def clear(self, pattern: Optional[str] = None) -> int:
        """Clear all cached items (pattern ignored for file cache)."""
        count = 0
        for cache_file in self.cache_dir.glob("*.pkl"):
            try:
                cache_file.unlink()
                count += 1
            except:
                pass
        return count
    
    def cached(self, ttl: Optional[int] = None):
        """Decorator to cache function results."""
        def decorator(func):
            def wrapper(*args, **kwargs):
                if not self.enabled:
                    return func(*args, **kwargs)
                
                key = self._get_cache_key(func.__name__, *args, **kwargs)
                cached_result = self.get(key)
                if cached_result is not None:
                    return cached_result
                
                result = func(*args, **kwargs)
                self.set(key, result, ttl)
                return result
            return wrapper
        return decorator