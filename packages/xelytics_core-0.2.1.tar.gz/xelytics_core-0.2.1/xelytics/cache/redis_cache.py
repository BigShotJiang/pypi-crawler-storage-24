"""
Redis-based cache implementation for xelytics-core.
"""

import json
import pickle
import logging
from typing import Any, Optional, Dict
import hashlib

import redis

logger = logging.getLogger(__name__)


class RedisCache:
    """
    Cache backend using Redis.
    
    Supports both pickle and JSON serialization.
    Configurable expiration (TTL).
    """
    
    def __init__(
        self,
        host: str = "localhost",
        port: int = 6379,
        db: int = 0,
        password: Optional[str] = None,
        ssl: bool = False,
        default_ttl: int = 3600,  # 1 hour
        key_prefix: str = "xelytics:",
        serializer: str = "pickle",  # or "json"
        **kwargs
    ):
        """
        Initialize Redis connection.
        
        Args:
            host: Redis host.
            port: Redis port.
            db: Redis database number.
            password: Redis password (if any).
            ssl: Use SSL connection.
            default_ttl: Default time-to-live in seconds.
            key_prefix: Prefix for all keys to avoid collisions.
            serializer: 'pickle' or 'json'. Pickle supports complex objects.
            **kwargs: Additional redis.Redis arguments (e.g., socket_timeout).
        """
        # Store cache‑specific parameters
        self.default_ttl = default_ttl
        self.key_prefix = key_prefix
        self.serializer = serializer
        
        # Prepare arguments for redis.Redis (exclude our own parameters)
        redis_kwargs = {
            'host': host,
            'port': port,
            'db': db,
            'password': password,
            'ssl': ssl,
            'decode_responses': False,  # Keep binary for pickle
        }
        redis_kwargs.update(kwargs)  # Any additional redis args
        
        self.redis_client = redis.Redis(**redis_kwargs)
        self.enabled = True
        
        # Test connection
        try:
            self.redis_client.ping()
            logger.info(f"Connected to Redis at {host}:{port}")
        except redis.ConnectionError as e:
            logger.error(f"Redis connection failed: {e}")
            self.enabled = False
    
    def _make_key(self, *args, **kwargs) -> str:
        """Generate a cache key from arguments."""
        key_str = str(args) + str(sorted(kwargs.items()))
        hash_digest = hashlib.md5(key_str.encode()).hexdigest()
        return f"{self.key_prefix}{hash_digest}"
    
    def _serialize(self, value: Any) -> bytes:
        """Serialize value for storage."""
        if self.serializer == "pickle":
            return pickle.dumps(value)
        elif self.serializer == "json":
            # JSON cannot handle complex objects; fallback to pickle with warning
            try:
                return json.dumps(value, default=str).encode('utf-8')
            except TypeError:
                logger.warning("JSON serialization failed, falling back to pickle")
                return pickle.dumps(value)
        else:
            raise ValueError(f"Unsupported serializer: {self.serializer}")
    
    def _deserialize(self, data: bytes) -> Any:
        """Deserialize value from storage."""
        if self.serializer == "pickle":
            return pickle.loads(data)
        else:
            try:
                return json.loads(data.decode('utf-8'))
            except:
                # Maybe it was pickled due to fallback
                try:
                    return pickle.loads(data)
                except:
                    raise
    
    def get(self, key: str) -> Optional[Any]:
        """Retrieve value from cache."""
        if not self.enabled:
            return None
        try:
            data = self.redis_client.get(key)
            if data is None:
                return None
            return self._deserialize(data)
        except Exception as e:
            logger.error(f"Redis get failed for key {key}: {e}")
            return None
    
    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> bool:
        """Store value in cache with optional TTL."""
        if not self.enabled:
            return False
        try:
            data = self._serialize(value)
            ttl = ttl if ttl is not None else self.default_ttl
            return self.redis_client.setex(key, ttl, data)
        except Exception as e:
            logger.error(f"Redis set failed for key {key}: {e}")
            return False
    
    def delete(self, key: str) -> bool:
        """Delete a key from cache."""
        if not self.enabled:
            return False
        try:
            return bool(self.redis_client.delete(key))
        except Exception as e:
            logger.error(f"Redis delete failed for key {key}: {e}")
            return False
    
    def clear(self, pattern: Optional[str] = None) -> int:
        """
        Clear all keys matching pattern, or all prefixed keys.
        Returns number of keys deleted.
        """
        if not self.enabled:
            return 0
        try:
            if pattern is None:
                pattern = f"{self.key_prefix}*"
            keys = self.redis_client.keys(pattern)
            if keys:
                return self.redis_client.delete(*keys)
            return 0
        except Exception as e:
            logger.error(f"Redis clear failed: {e}")
            return 0
    
    def cached(self, ttl: Optional[int] = None):
        """
        Decorator to cache function results.
        
        Args:
            ttl: Specific TTL for this function.
        
        Example:
            @cache.cached(ttl=300)
            def expensive_function(arg1, arg2):
                ...
        """
        def decorator(func):
            def wrapper(*args, **kwargs):
                if not self.enabled:
                    return func(*args, **kwargs)
                
                key = self._make_key(func.__name__, *args, **kwargs)
                cached_result = self.get(key)
                if cached_result is not None:
                    logger.debug(f"Cache hit for {func.__name__}")
                    return cached_result
                
                logger.debug(f"Cache miss for {func.__name__}")
                result = func(*args, **kwargs)
                self.set(key, result, ttl)
                return result
            return wrapper
        return decorator