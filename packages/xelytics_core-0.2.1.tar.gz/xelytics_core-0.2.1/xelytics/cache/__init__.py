"""
Caching module for xelytics-core v0.2.0

Provides pluggable cache backends (file, redis).
"""

from typing import Optional, Dict, Any, Union
import logging
from pathlib import Path

from .file_cache import FileCache
from .redis_cache import RedisCache

logger = logging.getLogger(__name__)

# Global cache instance
_cache_instance = None


class Cache:
    """Unified cache interface supporting multiple backends."""
    
    def __init__(self, backend: str = "file", **kwargs):
        """
        Initialize cache with specified backend.
        
        Args:
            backend: 'file' or 'redis'
            **kwargs: Backend-specific parameters.
        """
        self.backend_name = backend
        self.enabled = True
        
        if backend == "file":
            cache_dir = kwargs.get("cache_dir", "cache")
            ttl = kwargs.get("ttl", 3600)
            self._backend = FileCache(cache_dir=cache_dir, ttl=ttl)
        elif backend == "redis":
            # Map common 'ttl' to Redis's 'default_ttl'
            if 'ttl' in kwargs and 'default_ttl' not in kwargs:
                kwargs['default_ttl'] = kwargs.pop('ttl')
            self._backend = RedisCache(**kwargs)
            # RedisCache has its own enabled flag
            self.enabled = self._backend.enabled
        else:
            raise ValueError(f"Unsupported cache backend: {backend}")
    
    def get(self, key: str) -> Optional[Any]:
        """Get value from cache."""
        if not self.enabled:
            return None
        return self._backend.get(key)
    
    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> bool:
        """Set value in cache."""
        if not self.enabled:
            return False
        return self._backend.set(key, value, ttl)
    
    def delete(self, key: str) -> bool:
        """Delete key from cache."""
        if not self.enabled:
            return False
        return self._backend.delete(key)
    
    def clear(self, pattern: Optional[str] = None) -> int:
        """Clear cache."""
        if not self.enabled:
            return 0
        return self._backend.clear(pattern)
    
    def cached(self, ttl: Optional[int] = None):
        """Decorator to cache function results."""
        def decorator(func):
            def wrapper(*args, **kwargs):
                if not self.enabled:
                    return func(*args, **kwargs)
                return self._backend.cached(ttl)(func)(*args, **kwargs)
            return wrapper
        return decorator


def get_cache(backend: str = "file", **kwargs) -> Cache:
    """
    Get or create global cache instance.
    
    Args:
        backend: 'file' or 'redis'
        **kwargs: Backend configuration.
    
    Returns:
        Cache instance.
    """
    global _cache_instance
    if _cache_instance is None or _cache_instance.backend_name != backend:
        _cache_instance = Cache(backend=backend, **kwargs)
    return _cache_instance


def clear_cache(pattern: Optional[str] = None) -> int:
    """Clear the global cache."""
    global _cache_instance
    if _cache_instance:
        return _cache_instance.clear(pattern)
    return 0