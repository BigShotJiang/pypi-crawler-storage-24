"""Main analysis engine with performance optimizations.

Supports parallel execution, sampling, progress callbacks, and memory checks.
Integrates time series and clustering (v0.2.0 features).
"""

import time
import hashlib
import logging
import warnings
from typing import Literal, Optional, Union, Callable, Dict, Any, List
from concurrent.futures import ThreadPoolExecutor, as_completed
from functools import partial

import pandas as pd

from xelytics.__version__ import __version__
from xelytics.schemas.config import AnalysisConfig
from xelytics.schemas.outputs import (
    AnalysisResult,
    DatasetSummary,
    RunMetadata,
    TimeSeriesResult,
    ClusterResult,
)
from xelytics.core.ingestion import DataIngestion
from xelytics.core.profiler import DataProfiler
from xelytics.core.features import FeatureDetector
from xelytics.stats.engine import StatisticalEngine
from xelytics.viz.generator import VisualizationGenerator
from xelytics.insights.rules import InsightGenerator

# Import connectors and cache
from xelytics.connectors import connect_to_source
from xelytics.cache import get_cache

# Import pipeline if needed
from xelytics.pipeline import Pipeline, normalize, pca, remove_outliers, correlation_analysis

from typing import Union
from xelytics.core.chunked import compute_chunked_summary
from xelytics.schemas.outputs import ColumnProfile, DatasetSummary

logger = logging.getLogger(__name__)


# =============================================================================
# Module‑level task functions (picklable for parallel execution)
# =============================================================================

def analyze_large_dataset(
    source: Union[str, pd.DataFrame],
    chunksize: int = 10000,
    sample_size: Optional[int] = None,
    config: Optional[AnalysisConfig] = None,
    **kwargs
) -> AnalysisResult:
    """
    Analyze a large dataset.

    If sample_size is provided, a random sample of that size is taken and
    full analysis (including tests and visualizations) is performed.
    Otherwise, only summary statistics are computed via chunked processing.
    """

    import time
    start_time = time.time()
    
    from xelytics.engine import analyze as full_analyze  # avoid circular import

    if sample_size is not None:
        # Sample the dataset
        if isinstance(source, pd.DataFrame):
            df_sample = source.sample(n=min(sample_size, len(source)), random_state=42)
        else:
            # Read the whole file (for simplicity – user requested sample)
            # For huge files, consider chunked sampling, but this is acceptable for now.
            df = pd.read_csv(source, **kwargs)
            df_sample = df.sample(n=min(sample_size, len(df)), random_state=42)

        # Run full analysis
        if config is None:
            config = AnalysisConfig()
        return full_analyze(data=df_sample, config=config)

    else:
        # Chunked summary only
        column_stats, total_rows = compute_chunked_summary(source, chunksize=chunksize, **kwargs)

        # Build column profiles
        profiles = []
        for col, stats in column_stats.items():
            profile = ColumnProfile(
                column_name=col,
                data_type=stats['dtype'],
                role='unknown',
                missing_count=stats['missing'],
                missing_percentage=(stats['missing'] / total_rows * 100) if total_rows else 0.0,
                unique_count=len(stats.get('top_values', [])),
                cardinality_ratio=0.0,
                mean=stats.get('mean'),
                std=stats.get('std'),
                min=stats.get('min'),
                max=stats.get('max'),
                median=None,
                mode=stats['top_values'][0][0] if stats.get('top_values') else None,
                top_values=stats.get('top_values', []),
            )
            profiles.append(profile)

        summary = DatasetSummary(
            row_count=total_rows,
            column_count=len(profiles),
            numeric_columns=[c for c, s in column_stats.items() if s['dtype'].startswith(('float', 'int'))],
            categorical_columns=[c for c, s in column_stats.items() if s['dtype'] == 'object'],
            datetime_columns=[],
            identifier_columns=[],
            column_profiles=profiles,
            total_missing_cells=sum(s['missing'] for s in column_stats.values()),
            duplicate_row_count=0,
        )

        metadata = RunMetadata(
            execution_time_ms=int((time.time() - start_time) * 1000),
            package_version=__version__,
            row_count=total_rows,
            column_count=len(profiles),
            tests_executed=0,
            tests_skipped=0,
            visualizations_generated=0,
            insights_generated=0,
            mode='chunked',
            llm_enabled=False,
        )

        return AnalysisResult(
            summary=summary,
            statistics=[],
            visualizations=[],
            insights=[],
            metadata=metadata,
        )

def _run_stats_task(df, features, significance_level, mode, cache, data_hash):
    """Standalone task for statistical analysis."""
    from xelytics.stats.engine import StatisticalEngine
    if cache and data_hash:
        stat_params = f"{significance_level}:{mode}"
        cache_key = f"stats:{data_hash}:{stat_params}"
        stats_result = cache.get(cache_key)
        if stats_result is not None:
            return stats_result
    stats_engine = StatisticalEngine(alpha=significance_level)
    stats_result = stats_engine.execute(df, features)
    if cache and data_hash:
        cache.set(cache_key, stats_result)
    return stats_result


def _run_ts_task(df, datetime_column, forecast_periods, time_series_config, cache, data_hash):
    """Standalone task for time series analysis."""
    from xelytics.timeseries import analyze_time_series
    if cache and data_hash:
        ts_params = f"{datetime_column}:{forecast_periods}"
        cache_key = f"timeseries:{data_hash}:{ts_params}"
        ts_result = cache.get(cache_key)
        if ts_result is not None:
            return ts_result
    ts_result = analyze_time_series(
        df,
        datetime_column=datetime_column,
        forecast_periods=forecast_periods,
        config=time_series_config,
    )
    if cache and data_hash:
        cache.set(cache_key, ts_result)
    return ts_result


def _run_clust_task(df, clustering_algorithm, max_clusters, clustering_features, cache, data_hash):
    """Standalone task for clustering analysis."""
    from xelytics.clustering import analyze_clusters
    if cache and data_hash:
        clust_params = f"{clustering_algorithm}:{max_clusters}"
        cache_key = f"clustering:{data_hash}:{clust_params}"
        clust_result = cache.get(cache_key)
        if clust_result is not None:
            return clust_result
    clust_result = analyze_clusters(
        df,
        algorithm=clustering_algorithm,
        max_clusters=max_clusters,
        features=clustering_features,
    )
    if cache and data_hash:
        cache.set(cache_key, clust_result)
    return clust_result


# =============================================================================
# Helper functions
# =============================================================================

def _get_data_hash(df: pd.DataFrame) -> str:
    """Create a stable hash of the dataframe content for cache keys."""
    return hashlib.md5(
        pd.util.hash_pandas_object(df).values.tobytes()
    ).hexdigest()


def _check_memory_usage(df: pd.DataFrame, threshold_gb: float = 1.0) -> None:
    """Warn if DataFrame memory usage exceeds threshold (GB)."""
    mem_bytes = df.memory_usage(deep=True).sum()
    mem_gb = mem_bytes / (1024 ** 3)
    if mem_gb > threshold_gb:
        warnings.warn(
            f"DataFrame memory usage is {mem_gb:.2f} GB. "
            "Consider enabling sampling or using chunked processing.",
            UserWarning,
        )


def _apply_sampling(
    df: pd.DataFrame,
    config: AnalysisConfig,
) -> tuple[pd.DataFrame, Optional[Dict[str, Any]]]:
    """
    Apply sampling strategy based on config.
    Returns (sampled_df, sampling_info) or (df, None) if no sampling.
    """
    if config.sampling_strategy is None:
        return df, None

    n_rows = len(df)
    max_rows = config.max_rows
    sampling_info = {"original_rows": n_rows, "strategy": config.sampling_strategy}

    # Auto: sample if rows > max_rows
    if config.sampling_strategy == "auto":
        if n_rows <= max_rows:
            sampling_info["applied"] = False
            return df, sampling_info
        # Default to random sampling
        frac = max_rows / n_rows
        df = df.sample(frac=frac, random_state=42)
        sampling_info.update({"applied": True, "sampled_rows": len(df), "frac": frac})
        return df, sampling_info

    # Stratified sampling
    if config.sampling_strategy == "stratified":
        if n_rows <= max_rows:
            sampling_info["applied"] = False
            return df, sampling_info

        # Find a good categorical column for stratification
        cat_cols = df.select_dtypes(include=["object", "category"]).columns
        if config.target_column and config.target_column in cat_cols:
            strat_col = config.target_column
        elif len(cat_cols) > 0:
            # Use the categorical with moderate cardinality
            best_col = None
            best_size = None
            for col in cat_cols:
                unique = df[col].nunique()
                if 2 <= unique <= 100:
                    if best_size is None or unique > best_size:
                        best_size = unique
                        best_col = col
            strat_col = best_col
        else:
            strat_col = None

        if strat_col is None:
            # Fallback to random
            warnings.warn("No suitable column for stratified sampling, using random.")
            frac = max_rows / n_rows
            df = df.sample(frac=frac, random_state=42)
            sampling_info.update({"applied": True, "sampled_rows": len(df), "frac": frac, "fallback": "random"})
        else:
            # Perform stratified sampling
            try:
                # Compute per-stratum fractions
                strata_counts = df[strat_col].value_counts()
                # If any stratum is too small, fallback to random
                if (strata_counts < 2).any():
                    warnings.warn("Some strata have <2 samples, using random instead of stratified.")
                    frac = max_rows / n_rows
                    df = df.sample(frac=frac, random_state=42)
                    sampling_info.update({"applied": True, "sampled_rows": len(df), "frac": frac, "fallback": "random"})
                else:
                    df = df.groupby(strat_col, group_keys=False).apply(
                        lambda x: x.sample(frac=max_rows / n_rows, random_state=42)
                    )
                    sampling_info.update({"applied": True, "sampled_rows": len(df), "frac": max_rows / n_rows, "stratified_column": strat_col})
            except Exception as e:
                warnings.warn(f"Stratified sampling failed: {e}, using random.")
                frac = max_rows / n_rows
                df = df.sample(frac=frac, random_state=42)
                sampling_info.update({"applied": True, "sampled_rows": len(df), "frac": frac, "fallback": "random"})
        return df, sampling_info

    # Full (no sampling)
    if config.sampling_strategy == "full":
        sampling_info["applied"] = False
        return df, sampling_info

    # Unknown strategy
    raise ValueError(f"Unknown sampling strategy: {config.sampling_strategy}")


# =============================================================================
# Public API
# =============================================================================

def analyze(
    data: Optional[pd.DataFrame] = None,
    mode: Literal["automated", "semi-automated"] = "automated",
    config: Optional[AnalysisConfig] = None,
    progress_callback: Optional[Callable[[str, float], None]] = None,
) -> AnalysisResult:
    """
    Analyze a dataset with optional progress callbacks and performance optimizations.

    Args:
        data: Input DataFrame (if using direct DataFrame source)
        mode: Analysis mode
        config: Analysis configuration
        progress_callback: Optional function called with (step_name, progress [0-1])
    """
    start_time = time.time()

    if config is None:
        config = AnalysisConfig(mode=mode)
    else:
        config.mode = mode

    # ------------------------------------------------------------------
    # Data Acquisition
    # ------------------------------------------------------------------
    if progress_callback:
        progress_callback("data_acquisition", 0.0)

    df = None
    if config.data_source_type == "dataframe":
        if data is None:
            raise ValueError("When data_source_type='dataframe', a DataFrame must be provided.")
        df = data
    else:
        if not config.connector_config:
            raise ValueError("connector_config must be provided when using a data connector.")
        connector = None
        try:
            connector = connect_to_source(config.data_source_type, **config.connector_config)
            connected = connector.connect()  # BUG FIX: .connect() was missing in original
            if not connected or not connector.connected:
                raise ConnectionError(f"Could not connect to {config.data_source_type} source.")
            logger.info(f"Executing query on {config.data_source_type}...")
            df = connector.query(config.query)
            logger.info(f"Query returned {len(df)} rows.")
            # Convert dict columns to strings
            for col in df.columns:
                if df[col].dtype == 'object' and df[col].apply(lambda x: isinstance(x, dict)).any():
                    df[col] = df[col].astype(str)
        except Exception as e:
            raise RuntimeError(f"Data acquisition failed: {e}") from e
        finally:
            if connector:
                connector.disconnect()

    if progress_callback:
        progress_callback("data_acquisition", 1.0)

    # ------------------------------------------------------------------
    # Memory Check
    # ------------------------------------------------------------------
    _check_memory_usage(df, threshold_gb=1.0)

    # ------------------------------------------------------------------
    # Custom Pipeline (if configured)
    # ------------------------------------------------------------------
    if config.run_pipeline and config.pipeline_steps:
        pipeline = Pipeline(name="custom")
        step_functions = {
            "normalize": normalize,
            "pca": pca,
            "correlation_analysis": correlation_analysis,
            "remove_outliers": remove_outliers,
        }

        for step_config in config.pipeline_steps:
            func_name = step_config.get("function")
            if func_name not in step_functions:
                raise ValueError(f"Unknown pipeline function: {func_name}")

            func = step_functions[func_name]
            inputs = step_config.get("inputs", ["df"])
            outputs = step_config.get("outputs", [func_name + "_result"])
            kwargs = step_config.get("kwargs", {})

            pipeline.add_step(
                func,
                name=step_config.get("name", func_name),
                inputs=inputs,
                outputs=outputs,
                **kwargs,
            )

        context = pipeline.execute({"df": df})
        if "df" in context:
            df = context["df"]
        logger.info("Custom pipeline executed successfully")

    # ------------------------------------------------------------------
    # Filter columns
    # ------------------------------------------------------------------
    if config.include_columns:
        df = df[[c for c in config.include_columns if c in df.columns]]
    if config.exclude_columns:
        df = df.drop(columns=[c for c in config.exclude_columns if c in df.columns])

    # ------------------------------------------------------------------
    # Ingestion & Validation
    # ------------------------------------------------------------------
    if progress_callback:
        progress_callback("ingestion", 0.0)

    ingestion = DataIngestion()
    ingestion_result = ingestion.ingest(df)
    df = ingestion_result.data

    if progress_callback:
        progress_callback("ingestion", 1.0)

    # ------------------------------------------------------------------
    # Sampling
    # ------------------------------------------------------------------
    if progress_callback:
        progress_callback("sampling", 0.0)

    df, sampling_info = _apply_sampling(df, config)

    if progress_callback:
        progress_callback("sampling", 1.0)

    # ------------------------------------------------------------------
    # Cache initialization
    # ------------------------------------------------------------------
    cache = None
    data_hash = None
    if config.enable_caching:
        cache = get_cache(backend=config.cache_backend, **config.cache_config)
        if cache and cache.enabled:
            data_hash = _get_data_hash(df)
            logger.debug(f"Cache enabled, data hash: {data_hash[:8]}...")

    # ------------------------------------------------------------------
    # Feature Detection (cached)
    # ------------------------------------------------------------------
    if progress_callback:
        progress_callback("feature_detection", 0.0)

    if cache and data_hash:
        cache_key = f"features:{data_hash}:{config.mode}"
        features = cache.get(cache_key)
        if features is not None:
            logger.info("Using cached feature detection")
        else:
            logger.debug("Cache miss for feature detection")
            feature_detector = FeatureDetector()
            features = feature_detector.detect(df)
            cache.set(cache_key, features)
    else:
        feature_detector = FeatureDetector()
        features = feature_detector.detect(df)

    if progress_callback:
        progress_callback("feature_detection", 1.0)

    # ------------------------------------------------------------------
    # Data Profiling (cached)
    # ------------------------------------------------------------------
    if progress_callback:
        progress_callback("profiling", 0.0)

    if cache and data_hash:
        cache_key = f"profile:{data_hash}"
        profile = cache.get(cache_key)
        if profile is not None:
            logger.info("Using cached data profiling")
        else:
            logger.debug("Cache miss for data profiling")
            profiler = DataProfiler()
            profile = profiler.profile(df, features.column_roles)
            cache.set(cache_key, profile)
    else:
        profiler = DataProfiler()
        profile = profiler.profile(df, features.column_roles)

    if progress_callback:
        progress_callback("profiling", 1.0)

    # ------------------------------------------------------------------
    # Prepare parallel tasks (statistics, time series, clustering)
    # ------------------------------------------------------------------
    tasks = []

    # Statistics task
    tasks.append(("statistics", partial(
        _run_stats_task,
        df, features, config.significance_level, config.mode, cache, data_hash
    )))

    # Time series task (if enabled)
    if config.enable_time_series:
        tasks.append(("time_series", partial(
            _run_ts_task,
            df, config.datetime_column, config.forecast_periods,
            config.time_series_config, cache, data_hash
        )))

    # Clustering task (if enabled)
    if config.enable_clustering:
        tasks.append(("clustering", partial(
            _run_clust_task,
            df, config.clustering_algorithm, config.max_clusters,
            config.clustering_features, cache, data_hash
        )))

    # ------------------------------------------------------------------
    # Execute tasks in parallel or sequentially
    # ------------------------------------------------------------------
    results = {}
    workers_used = 1

    if config.parallel_execution and len(tasks) > 1:
        if progress_callback:
            progress_callback("parallel_tasks", 0.0)

        with ThreadPoolExecutor(max_workers=config.max_workers) as executor:
            future_to_name = {}
            for name, func in tasks:
                future = executor.submit(func)
                future_to_name[future] = name

            for future in as_completed(future_to_name):
                name = future_to_name[future]
                try:
                    results[name] = future.result()
                except Exception as e:
                    logger.error(f"Task {name} failed: {e}")
                    results[name] = None

            workers_used = len(tasks)

        if progress_callback:
            progress_callback("parallel_tasks", 1.0)
    else:
        # Sequential execution
        for name, func in tasks:
            if progress_callback:
                progress_callback(name, 0.0)
            results[name] = func()
            if progress_callback:
                progress_callback(name, 1.0)

    # Extract results with defaults
    stats_result = results.get("statistics")
    if stats_result is None:
        # If stats failed, we can't proceed meaningfully
        raise RuntimeError("Statistical analysis failed.")

    time_series_results = results.get("time_series", [])
    clustering_results = results.get("clustering", [])

    # ------------------------------------------------------------------
    # Visualization Generation
    # ------------------------------------------------------------------
    if progress_callback:
        progress_callback("visualization", 0.0)

    viz_generator = VisualizationGenerator()
    visualizations = viz_generator.generate(
        df,
        features,
        stats_result.results,
        max_visualizations=config.max_visualizations,
    )

    if progress_callback:
        progress_callback("visualization", 1.0)

    # ------------------------------------------------------------------
    # Build Dataset Summary
    # ------------------------------------------------------------------
    summary = DatasetSummary(
        row_count=len(df),
        column_count=len(df.columns),
        numeric_columns=features.numeric_columns,
        categorical_columns=features.categorical_columns,
        datetime_columns=features.datetime_columns,
        identifier_columns=features.identifier_columns,
        column_profiles=profile.column_profiles,
        total_missing_cells=profile.total_missing_cells,
        duplicate_row_count=profile.duplicate_row_count,
    )

    # ------------------------------------------------------------------
    # Generate Insights (rule-based)
    # ------------------------------------------------------------------
    if progress_callback:
        progress_callback("insights", 0.0)

    insight_generator = InsightGenerator()
    insights = insight_generator.generate(
        summary,
        profile,
        stats_result.results,
        max_insights=config.max_insights,
    )

    if progress_callback:
        progress_callback("insights", 1.0)

    # ------------------------------------------------------------------
    # Build Metadata
    # ------------------------------------------------------------------
    execution_time_ms = int((time.time() - start_time) * 1000)

    metadata = RunMetadata(
        execution_time_ms=execution_time_ms,
        package_version=__version__,
        row_count=len(df),
        column_count=len(df.columns),
        tests_executed=stats_result.tests_executed,
        tests_skipped=stats_result.tests_failed,
        visualizations_generated=len(visualizations),
        insights_generated=len(insights),
        mode=config.mode,
        llm_enabled=config.enable_llm_insights,
        sampling_info=sampling_info,
        parallel_execution=config.parallel_execution,
        workers_used=workers_used,
    )

    # ------------------------------------------------------------------
    # Assemble Final Result
    # ------------------------------------------------------------------
    return AnalysisResult(
        summary=summary,
        statistics=stats_result.results,
        visualizations=visualizations,
        insights=insights,
        metadata=metadata,
        time_series_analysis=time_series_results,
        clusters=clustering_results,
    )