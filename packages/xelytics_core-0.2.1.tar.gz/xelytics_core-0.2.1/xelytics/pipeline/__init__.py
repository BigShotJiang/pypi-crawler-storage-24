"""
Custom pipeline module for xelytics-core v0.2.0

This module allows users to define custom analysis workflows.
Now includes predefined steps: normalize, pca, remove_outliers, correlation_analysis.
"""

from typing import List, Dict, Any, Optional, Callable, Union
from dataclasses import dataclass, field
import pandas as pd
import logging

logger = logging.getLogger(__name__)

__version__ = "0.2.0"
__all__ = [
    "Pipeline",
    "PipelineStep",
    "normalize",
    "pca",
    "remove_outliers",
    "correlation_analysis",
]


class PipelineStep:
    """A single step in an analysis pipeline."""

    def __init__(
        self,
        name: str,
        func: Callable,
        inputs: Optional[List[str]] = None,
        outputs: Optional[List[str]] = None,
        **kwargs,
    ):
        self.name = name
        self.func = func
        self.inputs = inputs or []
        self.outputs = outputs or [name]
        self.kwargs = kwargs

    def execute(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the step with given context."""
        # Gather input data from context
        input_data = {}
        for inp in self.inputs:
            if inp not in context:
                raise ValueError(f"Required input '{inp}' not found in context")
            input_data[inp] = context[inp]

        # Execute function
        result = self.func(**input_data, **self.kwargs)

        # Update context with outputs
        if len(self.outputs) == 1:
            context[self.outputs[0]] = result
        else:
            for i, output_name in enumerate(self.outputs):
                if isinstance(result, (tuple, list)) and i < len(result):
                    context[output_name] = result[i]
                else:
                    # If result is single but multiple outputs, assign same to all
                    context[output_name] = result

        return context


class Pipeline:
    """Custom analysis pipeline."""

    def __init__(self, name: str = "custom_pipeline"):
        self.name = name
        self.steps: List[PipelineStep] = []

    def add_step(
        self,
        step: Union[PipelineStep, Callable],
        name: Optional[str] = None,
        inputs: Optional[List[str]] = None,
        outputs: Optional[List[str]] = None,
        **kwargs,
    ) -> "Pipeline":
        """Add a step to the pipeline."""
        if isinstance(step, PipelineStep):
            self.steps.append(step)
        else:
            # Create step from function
            step_name = name or step.__name__
            self.steps.append(
                PipelineStep(step_name, step, inputs, outputs, **kwargs)
            )
        return self

    def execute(self, initial_context: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the pipeline."""
        context = initial_context.copy()
        for step in self.steps:
            logger.info(f"Executing pipeline step: {step.name}")
            context = step.execute(context)
        return context


# ==================== Predefined Steps ====================


def normalize(
    df: pd.DataFrame,
    columns: Optional[List[str]] = None,
    method: str = "zscore",
) -> pd.DataFrame:
    """
    Normalize specified columns.
    Methods: zscore, minmax, robust.
    """
    df = df.copy()
    cols = columns or df.select_dtypes(include="number").columns.tolist()

    for col in cols:
        if method == "zscore":
            mean = df[col].mean()
            std = df[col].std()
            df[col] = (df[col] - mean) / std
        elif method == "minmax":
            min_val = df[col].min()
            max_val = df[col].max()
            df[col] = (df[col] - min_val) / (max_val - min_val)
        elif method == "robust":
            median = df[col].median()
            q1 = df[col].quantile(0.25)
            q3 = df[col].quantile(0.75)
            iqr = q3 - q1
            df[col] = (df[col] - median) / iqr
    return df


def pca(
    df: pd.DataFrame,
    columns: Optional[List[str]] = None,
    n_components: int = 2,
) -> pd.DataFrame:
    """
    Perform PCA on numeric columns and return transformed DataFrame.
    """
    from sklearn.decomposition import PCA
    from sklearn.preprocessing import StandardScaler

    cols = columns or df.select_dtypes(include="number").columns.tolist()
    if not cols:
        raise ValueError("No numeric columns for PCA")

    # Standardize
    scaler = StandardScaler()
    scaled = scaler.fit_transform(df[cols])

    # PCA
    pca = PCA(n_components=n_components)
    components = pca.fit_transform(scaled)

    # Create new DataFrame
    pca_df = pd.DataFrame(
        components,
        columns=[f"PC{i+1}" for i in range(n_components)],
        index=df.index,
    )
    # Add non-numeric columns back
    non_numeric = df.select_dtypes(exclude="number").columns
    for col in non_numeric:
        pca_df[col] = df[col].values

    return pca_df


def remove_outliers(
    df: pd.DataFrame,
    columns: Optional[List[str]] = None,
    method: str = "iqr",
    threshold: float = 1.5,
) -> pd.DataFrame:
    """Remove outliers from DataFrame."""
    df = df.copy()
    cols = columns or df.select_dtypes(include="number").columns.tolist()

    for col in cols:
        if method == "iqr":
            q1 = df[col].quantile(0.25)
            q3 = df[col].quantile(0.75)
            iqr = q3 - q1
            lower = q1 - threshold * iqr
            upper = q3 + threshold * iqr
            df = df[(df[col] >= lower) & (df[col] <= upper)]
        elif method == "zscore":
            mean = df[col].mean()
            std = df[col].std()
            df = df[abs(df[col] - mean) <= threshold * std]

    return df


def correlation_analysis(
    df: pd.DataFrame,
    method: str = "pearson",
) -> pd.DataFrame:
    """Return correlation matrix."""
    return df.select_dtypes(include="number").corr(method=method)