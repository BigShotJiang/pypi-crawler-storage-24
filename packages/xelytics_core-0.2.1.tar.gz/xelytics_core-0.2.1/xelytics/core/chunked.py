"""Chunked data processing for large datasets."""

import pandas as pd
import numpy as np
from typing import Iterator, Tuple, Optional, Any, Dict, List
from dataclasses import dataclass, field
import warnings


@dataclass
class ChunkedStats:
    """Accumulated statistics from chunked processing."""
    count: int = 0
    sum: float = 0.0
    sum_sq: float = 0.0
    min: float = np.inf
    max: float = -np.inf
    missing: int = 0
    value_counts: dict = field(default_factory=dict)

    def update(self, chunk: pd.Series):
        """Update with a chunk of data."""
        missing_mask = chunk.isna()
        self.missing += missing_mask.sum()
        chunk_clean = chunk.dropna()
        n = len(chunk_clean)
        if n == 0:
            return
        self.count += n
        if pd.api.types.is_numeric_dtype(chunk):
            self.sum += chunk_clean.sum()
            self.sum_sq += (chunk_clean ** 2).sum()
            self.min = min(self.min, chunk_clean.min())
            self.max = max(self.max, chunk_clean.max())
        # Always count value frequencies for any type
        counts = chunk_clean.value_counts()
        for val, cnt in counts.items():
            self.value_counts[val] = self.value_counts.get(val, 0) + cnt

    def finalize(self) -> dict:
        """Return final statistics."""
        stats = {
            "count": self.count,
            "missing": self.missing,
            "mean": self.sum / self.count if self.count > 0 else np.nan,
            "std": np.sqrt((self.sum_sq - self.sum**2 / self.count) / (self.count - 1)) if self.count > 1 else np.nan,
            "min": self.min if self.count > 0 else np.nan,
            "max": self.max if self.count > 0 else np.nan,
        }
        # Top values
        top = sorted(self.value_counts.items(), key=lambda x: x[1], reverse=True)[:5]
        stats["top_values"] = [(str(k), v) for k, v in top]
        return stats


def chunked_dataframe_reader(
    source: Any,
    chunksize: int = 10000,
    **kwargs
) -> Iterator[pd.DataFrame]:
    """
    Iterate over a data source in chunks.
    Supports file paths (CSV, Parquet) and SQL queries via chunksize.
    """
    if isinstance(source, str):
        # File path
        if source.endswith('.csv'):
            yield from pd.read_csv(source, chunksize=chunksize, **kwargs)
        elif source.endswith('.parquet'):
            # Parquet doesn't support chunking natively; read whole with warning
            warnings.warn("Parquet doesn't support chunking; loading entire file.")
            yield pd.read_parquet(source, **kwargs)
        else:
            raise ValueError(f"Unsupported file type: {source}")
    elif hasattr(source, 'read') and hasattr(source, 'seek'):
        # File-like object (e.g., from requests)
        yield from pd.read_csv(source, chunksize=chunksize, **kwargs)
    elif isinstance(source, pd.DataFrame):
        # DataFrame – split into chunks
        n = len(source)
        for start in range(0, n, chunksize):
            yield source.iloc[start:start+chunksize]
    else:
        raise TypeError(f"Unsupported source type: {type(source)}")


def compute_chunked_summary(
    source,
    chunksize: int = 10000,
    **kwargs
) -> tuple[Dict[str, dict], int]:
    """
    Compute column-wise summary statistics from a chunked data source.
    Returns (column_stats, total_rows) where column_stats maps column name to stats dict.
    """
    accumulators: Dict[str, ChunkedStats] = {}
    total_rows = 0
    first_chunk = True
    dtypes = {}

    for chunk in chunked_dataframe_reader(source, chunksize, **kwargs):
        total_rows += len(chunk)
        for col in chunk.columns:
            if col not in accumulators:
                accumulators[col] = ChunkedStats()
                dtypes[col] = str(chunk[col].dtype)
            accumulators[col].update(chunk[col])

    final_stats = {}
    for col, acc in accumulators.items():
        stats = acc.finalize()
        stats['dtype'] = dtypes.get(col, 'unknown')
        final_stats[col] = stats

    return final_stats, total_rows