"""Output schemas for analysis results v0.2.0 - MINIMAL VERSION"""

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Tuple
from enum import Enum
import json
from datetime import datetime


class TestType(str, Enum):
    """Types of statistical tests."""
    ANOVA_ONE_WAY = "anova_one_way"
    ANOVA_TWO_WAY = "anova_two_way"
    T_TEST_INDEPENDENT = "t_test_independent"
    T_TEST_PAIRED = "t_test_paired"
    CHI_SQUARE = "chi_square"
    CORRELATION_PEARSON = "correlation_pearson"
    CORRELATION_SPEARMAN = "correlation_spearman"
    REGRESSION_LINEAR = "regression_linear"
    MANN_WHITNEY = "mann_whitney"
    KRUSKAL_WALLIS = "kruskal_wallis"
    NORMALITY_SHAPIRO = "normality_shapiro"
    NORMALITY_KS = "normality_ks"


class InsightSeverity(str, Enum):
    """Severity levels for insights."""
    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"


@dataclass
class EffectSize:
    """Effect size measurement."""
    measure_type: str
    value: float
    interpretation: str
    confidence_interval: Optional[Tuple[float, float]] = None


@dataclass
class AssumptionCheck:
    """Result of a statistical assumption check."""
    assumption_name: str
    is_met: bool
    test_statistic: Optional[float] = None
    p_value: Optional[float] = None
    interpretation: str = ""
    recommendation: str = ""


@dataclass
class StatisticalTestResult:
    """Result of a single statistical test."""
    test_name: str
    test_type: TestType
    statistic: float
    p_value: float
    significant: bool
    interpretation: str
    effect_size: Optional[EffectSize] = None
    confidence_interval: Optional[Tuple[float, float]] = None
    assumptions: List[AssumptionCheck] = field(default_factory=list)
    columns: List[str] = field(default_factory=list)
    decision_reason: str = ""
    fallback_from: Optional[str] = None


@dataclass
class VisualizationSpec:
    """Specification for a visualization."""
    chart_id: str
    chart_type: str
    title: str
    plotly_spec: Dict[str, Any] = field(default_factory=dict)
    x_column: Optional[str] = None
    y_column: Optional[str] = None
    color_column: Optional[str] = None
    related_test_name: Optional[str] = None
    spec_version: str = "1.0"


@dataclass
class Insight:
    """A single insight from the analysis."""
    insight_id: str
    severity: InsightSeverity
    title: str
    description: str
    source: str
    related_columns: List[str] = field(default_factory=list)
    related_test_name: Optional[str] = None
    supporting_statistics: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ColumnProfile:
    """Profile of a single column."""
    column_name: str
    data_type: str
    role: str
    missing_count: int = 0
    missing_percentage: float = 0.0
    unique_count: int = 0
    cardinality_ratio: float = 0.0
    mean: Optional[float] = None
    std: Optional[float] = None
    min: Optional[float] = None
    max: Optional[float] = None
    median: Optional[float] = None
    mode: Optional[str] = None
    top_values: List[Tuple[str, int]] = field(default_factory=list)


@dataclass
class DatasetSummary:
    """Summary of the input dataset."""
    row_count: int
    column_count: int
    numeric_columns: List[str] = field(default_factory=list)
    categorical_columns: List[str] = field(default_factory=list)
    datetime_columns: List[str] = field(default_factory=list)
    identifier_columns: List[str] = field(default_factory=list)
    column_profiles: List[ColumnProfile] = field(default_factory=list)
    total_missing_cells: int = 0
    duplicate_row_count: int = 0


@dataclass
class RunMetadata:
    """Metadata about the analysis run."""
    execution_time_ms: int
    package_version: str
    row_count: int
    column_count: int
    tests_executed: int
    tests_skipped: int
    visualizations_generated: int
    insights_generated: int
    started_at: str = ""
    completed_at: str = ""
    mode: str = "automated"
    llm_enabled: bool = True
    sampling_info: Optional[Dict[str, Any]] = None      
    parallel_execution: bool = False                    
    workers_used: int = 1  


# ===== v0.2.0 EXTENSIONS - MINIMAL =====

class TimeSeriesType(str, Enum):
    """Types of time series detected."""
    LINEAR = "linear"
    SEASONAL = "seasonal"
    TREND_SEASONAL = "trend_seasonal"
    RANDOM = "random"


class ClusteringAlgorithm(str, Enum):
    """Types of clustering algorithms."""
    KMEANS = "kmeans"
    DBSCAN = "dbscan"
    HIERARCHICAL = "hierarchical"


@dataclass
class TimeSeriesResult:
    """Result of time series analysis (v0.2.0)."""
    column: str
    series_type: TimeSeriesType
    is_stationary: bool
    has_trend: bool
    has_seasonality: bool
    seasonal_period: Optional[int] = None
    trend_strength: Optional[float] = None
    seasonality_strength: Optional[float] = None


@dataclass
class ClusterResult:
    """Result of clustering analysis (v0.2.0)."""
    cluster_id: int
    algorithm: ClusteringAlgorithm
    size: int
    centroid: Dict[str, float]
    profile: Dict[str, Any]
    silhouette_score: float
    members: List[int]


@dataclass
class AnalysisResult:
    """Complete analysis result - extended for v0.2.0."""
    
    # v0.1.0 fields
    summary: DatasetSummary
    statistics: List[StatisticalTestResult]
    visualizations: List[VisualizationSpec]
    insights: List[Insight]
    metadata: RunMetadata
    
    # v0.2.0 fields (optional, empty by default)
    time_series_analysis: List[TimeSeriesResult] = field(default_factory=list)
    clusters: List[ClusterResult] = field(default_factory=list)
    
    # Version tracking
    schema_version: str = "1.0"
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary with backward compatibility."""
        result = {
            "schema_version": self.schema_version,
            "summary": asdict(self.summary),
            "statistics": [asdict(s) for s in self.statistics],
            "visualizations": [asdict(v) for v in self.visualizations],
            "insights": [asdict(i) for i in self.insights],
            "metadata": asdict(self.metadata),
        }
        
        # Add v0.2.0 fields only if present
        if self.time_series_analysis:
            result["time_series_analysis"] = [asdict(ts) for ts in self.time_series_analysis]
        
        if self.clusters:
            result["clusters"] = [asdict(c) for c in self.clusters]
        
        return result
    
    def to_json(self) -> str:
        """Serialize to JSON string."""
        return json.dumps(self.to_dict(), indent=2, default=str)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AnalysisResult":
        """Deserialize from dictionary."""
        # This is a simplified version - in reality you'd need full deserialization
        return cls(
            summary=DatasetSummary(**data["summary"]),
            statistics=[StatisticalTestResult(**s) for s in data.get("statistics", [])],
            visualizations=[VisualizationSpec(**v) for v in data.get("visualizations", [])],
            insights=[Insight(**i) for i in data.get("insights", [])],
            metadata=RunMetadata(**data["metadata"]),
        )