"""
Xelytics schemas module - v0.2.0 compatible
"""

# Core schemas
from .config import AnalysisConfig
from .inputs import DatasetInput
from .metadata import DecisionLog, DecisionLogEntry, DecisionType
from .outputs import (
    AnalysisResult,
    DatasetSummary,
    StatisticalTestResult,
    VisualizationSpec,
    Insight,
    RunMetadata,
    # v0.2.0 extensions
    TimeSeriesResult,
    ClusterResult,
    TimeSeriesType,
    ClusteringAlgorithm,
)

__all__ = [
    "AnalysisConfig",
    "DatasetInput",
    "DecisionLog",
    "DecisionLogEntry",
    "DecisionType",
    "AnalysisResult",
    "DatasetSummary",
    "StatisticalTestResult",
    "VisualizationSpec",
    "Insight",
    "RunMetadata",
    # v0.2.0
    "TimeSeriesResult",
    "ClusterResult",
    "TimeSeriesType",
    "ClusteringAlgorithm",
]