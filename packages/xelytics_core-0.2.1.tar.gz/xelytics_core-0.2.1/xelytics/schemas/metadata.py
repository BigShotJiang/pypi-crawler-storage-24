"""Metadata schemas for run tracking v0.2.0.

Extended with new decision types for v0.2.0 features.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
from enum import Enum
from datetime import datetime
import datetime
timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

class DecisionType(str, Enum):
    """Types of decisions made during analysis."""
    # v0.1.0 decision types
    TEST_SELECTED = "test_selected"
    TEST_SKIPPED = "test_skipped"
    FALLBACK_USED = "fallback_used"
    ASSUMPTION_CHECKED = "assumption_checked"
    VISUALIZATION_GENERATED = "visualization_generated"
    INSIGHT_GENERATED = "insight_generated"
    
    # v0.2.0 new decision types
    TIME_SERIES_DETECTED = "time_series_detected"
    TIME_SERIES_ANALYZED = "time_series_analyzed"
    CLUSTERING_SELECTED = "clustering_selected"
    CLUSTERING_COMPLETED = "clustering_completed"
    CACHE_HIT = "cache_hit"
    CACHE_MISS = "cache_miss"
    PARALLEL_TASK_SPAWNED = "parallel_task_spawned"
    REPORT_GENERATED = "report_generated"
    DATA_CONNECTOR_USED = "data_connector_used"
    PERFORMANCE_OPTIMIZATION = "performance_optimization"


@dataclass
class DecisionLogEntry:
    """A single decision made during analysis.
    
    Extended for v0.2.0 with new context fields.
    """
    
    decision_type: DecisionType
    description: str
    reason: str
    affected_columns: List[str] = field(default_factory=list)
    test_name: Optional[str] = None
    original_test: Optional[str] = None
    context: Dict[str, Any] = field(default_factory=dict)
    
    # v0.2.0 extensions
    timestamp: str = field(default_factory=lambda: datetime.datetime.now().isoformat())
    module: Optional[str] = None  # "timeseries", "clustering", "cache", etc.
    performance_impact_ms: Optional[int] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "decision_type": self.decision_type.value,
            "description": self.description,
            "reason": self.reason,
            "affected_columns": self.affected_columns,
            "test_name": self.test_name,
            "original_test": self.original_test,
            "context": self.context,
            "timestamp": self.timestamp,
            "module": self.module,
            "performance_impact_ms": self.performance_impact_ms,
        }


@dataclass
class DecisionLog:
    """Machine-readable decision log - extended for v0.2.0."""
    
    entries: List[DecisionLogEntry] = field(default_factory=list)
    
    # v0.2.0 performance tracking
    execution_start_time: Optional[str] = None
    execution_end_time: Optional[str] = None
    total_decisions: int = 0
    
    def add_decision(self, entry: DecisionLogEntry) -> None:
        """Add a decision entry."""
        self.entries.append(entry)
        self.total_decisions += 1
    
    # v0.1.0 methods (preserved)
    def add_test_selected(
        self,
        test_name: str,
        columns: List[str],
        reason: str,
        context: Optional[Dict[str, Any]] = None
    ) -> None:
        """Log a test selection decision."""
        self.add_decision(DecisionLogEntry(
            decision_type=DecisionType.TEST_SELECTED,
            description=f"Selected {test_name} for columns {columns}",
            reason=reason,
            affected_columns=columns,
            test_name=test_name,
            context=context or {},
        ))
    
    def add_test_skipped(
        self,
        test_name: str,
        columns: List[str],
        reason: str,
        context: Optional[Dict[str, Any]] = None
    ) -> None:
        """Log a test skip decision."""
        self.add_decision(DecisionLogEntry(
            decision_type=DecisionType.TEST_SKIPPED,
            description=f"Skipped {test_name} for columns {columns}",
            reason=reason,
            affected_columns=columns,
            test_name=test_name,
            context=context or {},
        ))
    
    # v0.2.0 new methods
    def add_time_series_detected(
        self,
        column: str,
        series_type: str,
        reason: str,
        context: Optional[Dict[str, Any]] = None
    ) -> None:
        """Log time series detection."""
        self.add_decision(DecisionLogEntry(
            decision_type=DecisionType.TIME_SERIES_DETECTED,
            description=f"Detected {series_type} time series in column {column}",
            reason=reason,
            affected_columns=[column],
            module="timeseries",
            context=context or {},
        ))
    
    def add_clustering_completed(
        self,
        algorithm: str,
        n_clusters: int,
        columns: List[str],
        reason: str,
        context: Optional[Dict[str, Any]] = None
    ) -> None:
        """Log clustering completion."""
        self.add_decision(DecisionLogEntry(
            decision_type=DecisionType.CLUSTERING_COMPLETED,
            description=f"Completed {algorithm} clustering with {n_clusters} clusters on columns {columns}",
            reason=reason,
            affected_columns=columns,
            module="clustering",
            context=context or {},
        ))
    
    def add_cache_hit(
        self,
        cache_key: str,
        time_saved_ms: int,
        context: Optional[Dict[str, Any]] = None
    ) -> None:
        """Log cache hit."""
        self.add_decision(DecisionLogEntry(
            decision_type=DecisionType.CACHE_HIT,
            description=f"Cache hit for key {cache_key}, saved {time_saved_ms}ms",
            reason="Cached result reused",
            module="cache",
            performance_impact_ms=time_saved_ms,
            context=context or {"cache_key": cache_key},
        ))
    
    def add_report_generated(
        self,
        report_type: str,
        file_size_bytes: int,
        context: Optional[Dict[str, Any]] = None
    ) -> None:
        """Log report generation."""
        self.add_decision(DecisionLogEntry(
            decision_type=DecisionType.REPORT_GENERATED,
            description=f"Generated {report_type} report ({file_size_bytes} bytes)",
            reason="Report generation requested",
            module="export",
            context=context or {"report_type": report_type, "file_size_bytes": file_size_bytes},
        ))
    
    def start_execution(self):
        """Mark execution start."""
        self.execution_start_time = datetime.now().isoformat()
    
    def end_execution(self):
        """Mark execution end."""
        self.execution_end_time = datetime.now().isoformat()
    
    def to_list(self) -> List[Dict[str, Any]]:
        """Convert all entries to list of dictionaries."""
        return [e.to_dict() for e in self.entries]
    
    def get_by_type(self, decision_type: DecisionType) -> List[DecisionLogEntry]:
        """Get all entries of a specific type."""
        return [e for e in self.entries if e.decision_type == decision_type]
    
    def get_by_module(self, module: str) -> List[DecisionLogEntry]:
        """Get all entries for a specific module."""
        return [e for e in self.entries if e.module == module]