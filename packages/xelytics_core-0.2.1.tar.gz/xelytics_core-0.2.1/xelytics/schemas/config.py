"""
Analysis configuration schema v0.2.0 - Extended for new features

This extends v0.1.0 schema with new optional parameters for v0.2.0 features.
All new parameters have default values for backward compatibility.
"""

from dataclasses import dataclass, field
from typing import Literal, Optional, List, Dict, Any
from datetime import datetime


@dataclass
class AnalysisConfig:
    """Configuration for analysis execution.
    
    Extended for v0.2.0 with new features.
    All new parameters are optional with defaults that maintain v0.1.0 behavior.
    """
    
    # === v0.1.0 Parameters (Existing - DO NOT CHANGE) ===
    mode: Literal["automated", "semi-automated"] = "automated"
    significance_level: float = 0.05
    enable_llm_insights: bool = True
    llm_provider: Literal["grok", "openai"] = "openai"
    max_visualizations: int = 10
    max_insights: int = 20
    include_assumptions: bool = True
    include_effect_sizes: bool = True
    include_confidence_intervals: bool = True
    include_columns: Optional[List[str]] = None
    exclude_columns: Optional[List[str]] = None
    target_column: Optional[str] = None
    
    # === v0.2.0 New Parameters (Optional with defaults) ===
    # Time Series Analysis
    enable_time_series: bool = False
    datetime_column: Optional[str] = None
    forecast_periods: int = 0
    time_series_config: Dict[str, Any] = field(default_factory=lambda: {
        "trend_detection": True,
        "seasonality_detection": True,
        "anomaly_detection": False,
    })
    
    # Clustering
    enable_clustering: bool = False
    clustering_algorithm: Literal["auto", "kmeans", "dbscan", "hierarchical"] = "auto"
    max_clusters: int = 10
    clustering_features: Optional[List[str]] = None
    
    # Performance Optimization
    enable_caching: bool = True
    parallel_execution: bool = True
    max_workers: int = 4
    chunk_size: int = 10000
    sampling_strategy: Optional[Literal["auto", "full", "stratified"]] = None
    max_rows: int = 1000000
    
    # Report Generation
    report_format: Optional[Literal["html", "json", "pdf"]] = None
    report_title: Optional[str] = None
    report_author: Optional[str] = None
    enable_interactive_report: bool = False
    
    # Data Connectors (v0.2.0 - Phase 2)
    data_source_type: Optional[Literal["dataframe", "postgresql", "mysql", "bigquery", "csv", "s3"]] = "dataframe"
    connector_config: Optional[Dict[str, Any]] = None
    query: Optional[str] = None

    # === Caching Configuration ===
    enable_caching: bool = True
    cache_backend: Literal["file", "redis"] = "file"
    cache_config: Dict[str, Any] = field(default_factory=lambda: {
        "ttl": 3600,
        "cache_dir": "cache",
        # Redis specific
        "host": "localhost",
        "port": 6379,
        "db": 0,
        "password": None,
        "ssl": False,
        "key_prefix": "xelytics:",
    })
    
    # LLM v0.2.0 - Multi-provider support
    llm_provider_v2: Optional[str] = None  # For backward compatibility
    llm_config: Dict[str, Any] = field(default_factory=lambda: {
        "model": None,
        "temperature": 0.1,
        "max_tokens": 4096,
        "stream": False,
    })
    
    # Custom Analysis Pipeline
    run_pipeline: bool = False
    pipeline_steps: Optional[List[Dict[str, Any]]] = None
    
    def __post_init__(self):
        """Validate configuration values with backward compatibility."""
        # v0.1.0 validations
        if not 0 < self.significance_level < 1:
            raise ValueError("significance_level must be between 0 and 1")
        if self.max_visualizations < 0:
            raise ValueError("max_visualizations must be non-negative")
        if self.max_insights < 0:
            raise ValueError("max_insights must be non-negative")
        
        # v0.2.0 new validations
        if self.forecast_periods < 0:
            raise ValueError("forecast_periods must be non-negative")
        if self.max_clusters < 2:
            raise ValueError("max_clusters must be at least 2")
        if self.max_workers < 1:
            raise ValueError("max_workers must be at least 1")
        if self.chunk_size < 1:
            raise ValueError("chunk_size must be at least 1")
        if self.max_rows < 100:
            raise ValueError("max_rows must be at least 100")
        
        # Backward compatibility: Map grok to groq if needed
        if self.llm_provider == "grok":
            self.llm_provider = "openai"  # Default fallback
            self.llm_config["provider"] = "groq"  # Store actual provider in config


@dataclass
class EnvironmentConfig:
    """Environment configuration loaded from .env file"""
    # Core
    env: str = "development"
    debug: bool = True
    
    # Performance
    enable_cache: bool = True
    cache_type: str = "memory"
    parallel_workers: int = 4
    
    # Feature flags
    enable_timeseries: bool = True
    enable_clustering: bool = True
    enable_connectors: bool = True
    enable_html_reports: bool = True
    
    @classmethod
    def from_env(cls):
        """Load from environment variables"""
        import os
        return cls(
            env=os.getenv("XELYTICS_ENV", "development"),
            debug=os.getenv("XELYTICS_DEBUG", "true").lower() == "true",
            enable_cache=os.getenv("ENABLE_CACHE", "true").lower() == "true",
            parallel_workers=int(os.getenv("PARALLEL_WORKERS", "4")),
            enable_timeseries=os.getenv("ENABLE_TIMESERIES", "true").lower() == "true",
            enable_clustering=os.getenv("ENABLE_CLUSTERING", "true").lower() == "true",
            enable_connectors=os.getenv("ENABLE_CONNECTORS", "true").lower() == "true",
            enable_html_reports=os.getenv("ENABLE_HTML_REPORTS", "true").lower() == "true",
        )