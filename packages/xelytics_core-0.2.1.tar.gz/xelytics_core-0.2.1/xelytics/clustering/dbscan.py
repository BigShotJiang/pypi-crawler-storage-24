"""DBSCAN clustering implementation.

This module provides DBSCAN (Density-Based Spatial Clustering
of Applications with Noise) with automatic parameter tuning.
"""

from typing import Optional, List, Dict, Any, Tuple
import pandas as pd
import numpy as np
from dataclasses import dataclass
from sklearn.cluster import DBSCAN as SKLearnDBSCAN
from sklearn.neighbors import NearestNeighbors
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler


@dataclass
class DBSCANResult:
    """Result of DBSCAN clustering."""
    labels: np.ndarray
    n_clusters: int
    n_noise: int
    eps: float
    min_samples: int
    core_sample_indices: np.ndarray
    silhouette_score: Optional[float]
    feature_names: List[str]
    cluster_sizes: Dict[int, int]
    noise_ratio: float


class DBSCANClusterer:
    """DBSCAN clustering with automatic parameter selection."""
    
    def __init__(
        self,
        eps: Optional[float] = None,
        min_samples: Optional[int] = None,
        normalize: bool = True,
        random_state: int = 42
    ):
        """Initialize DBSCAN clusterer.
        
        Args:
            eps: Maximum distance between two samples (auto if None)
            min_samples: Minimum samples in neighborhood (auto if None)
            normalize: Whether to normalize features
            random_state: Random seed
        """
        self.eps = eps
        self.min_samples = min_samples
        self.normalize = normalize
        self.random_state = random_state
        self.scaler = StandardScaler() if normalize else None
    
    def estimate_eps(self, X: np.ndarray, k: Optional[int] = None) -> float:
        """Estimate optimal eps using k-distance graph.
        
        Args:
            X: Feature matrix
            k: Number of neighbors (defaults to min_samples)
            
        Returns:
            Estimated eps value
        """
        if k is None:
            k = self._estimate_min_samples(X)
        
        # Find k-nearest neighbors
        neighbors = NearestNeighbors(n_neighbors=k)
        neighbors.fit(X)
        distances, indices = neighbors.kneighbors(X)
        
        # Get k-th nearest neighbor distances (sorted)
        k_distances = np.sort(distances[:, -1])
        
        # Find elbow point in k-distance plot
        # Use gradient method
        if len(k_distances) < 3:
            return float(np.median(k_distances))
        
        # Calculate gradients
        gradients = np.diff(k_distances)
        
        # Find maximum gradient (elbow)
        max_gradient_idx = np.argmax(gradients)
        
        # Return distance at elbow point
        eps = k_distances[max_gradient_idx]
        
        # Ensure reasonable value
        eps = max(eps, np.percentile(k_distances, 5))
        
        return float(eps)
    
    def _estimate_min_samples(self, X: np.ndarray) -> int:
        """Estimate min_samples parameter.
        
        Rule of thumb: min_samples >= D + 1, where D is dimensionality
        
        Args:
            X: Feature matrix
            
        Returns:
            Estimated min_samples
        """
        n_features = X.shape[1]
        # Common heuristic: 2 * dimensions
        min_samples = max(3, min(2 * n_features, int(np.log(X.shape[0])) + 1))
        return min_samples
    
    def fit(
        self,
        X: np.ndarray,
        eps: Optional[float] = None,
        min_samples: Optional[int] = None,
        feature_names: Optional[List[str]] = None
    ) -> DBSCANResult:
        """Fit DBSCAN clustering.
        
        Args:
            X: Feature matrix (n_samples, n_features)
            eps: Maximum distance (estimated if None)
            min_samples: Minimum samples (estimated if None)
            feature_names: Names of features
            
        Returns:
            DBSCANResult object
        """
        if X.shape[0] < 2:
            raise ValueError("Need at least 2 samples for clustering")
        
        # Normalize if requested
        if self.normalize and self.scaler:
            X_scaled = self.scaler.fit_transform(X)
        else:
            X_scaled = X
        
        # Determine parameters
        if eps is None:
            eps = self.eps if self.eps is not None else self.estimate_eps(X_scaled)
        
        if min_samples is None:
            min_samples = self.min_samples if self.min_samples is not None else self._estimate_min_samples(X_scaled)
        
        # Fit DBSCAN
        dbscan = SKLearnDBSCAN(eps=eps, min_samples=min_samples)
        labels = dbscan.fit_predict(X_scaled)
        
        # Calculate metrics
        n_clusters = len(set(labels)) - (1 if -1 in labels else 0)
        n_noise = list(labels).count(-1)
        noise_ratio = n_noise / len(labels) if len(labels) > 0 else 0.0
        
        # Silhouette score (only if we have clusters)
        sil_score = None
        if n_clusters > 1 and n_noise < len(labels):
            # Silhouette score doesn't include noise points
            mask = labels != -1
            if mask.sum() > 1:
                try:
                    sil_score = silhouette_score(X_scaled[mask], labels[mask])
                except:
                    sil_score = None
        
        # Calculate cluster sizes
        unique, counts = np.unique(labels, return_counts=True)
        cluster_sizes = dict(zip(unique.tolist(), counts.tolist()))
        
        # Get core sample indices
        core_samples = dbscan.core_sample_indices_
        
        # Set feature names
        if feature_names is None:
            feature_names = [f"feature_{i}" for i in range(X.shape[1])]
        
        return DBSCANResult(
            labels=labels,
            n_clusters=n_clusters,
            n_noise=n_noise,
            eps=eps,
            min_samples=min_samples,
            core_sample_indices=core_samples,
            silhouette_score=sil_score,
            feature_names=feature_names,
            cluster_sizes=cluster_sizes,
            noise_ratio=noise_ratio
        )
    
    def fit_predict(
        self,
        X: np.ndarray,
        eps: Optional[float] = None,
        min_samples: Optional[int] = None
    ) -> np.ndarray:
        """Fit DBSCAN and return cluster labels.
        
        Args:
            X: Feature matrix
            eps: Maximum distance
            min_samples: Minimum samples
            
        Returns:
            Cluster labels (-1 for noise)
        """
        result = self.fit(X, eps, min_samples)
        return result.labels


def cluster_dbscan(
    df: pd.DataFrame,
    feature_columns: Optional[List[str]] = None,
    eps: Optional[float] = None,
    min_samples: Optional[int] = None,
    normalize: bool = True
) -> Tuple[DBSCANResult, pd.DataFrame]:
    """High-level function to perform DBSCAN clustering.
    
    Args:
        df: Input DataFrame
        feature_columns: Columns to use for clustering (numeric only if None)
        eps: Maximum distance between samples
        min_samples: Minimum samples in neighborhood
        normalize: Whether to normalize features
        
    Returns:
        Tuple of (DBSCANResult, DataFrame with cluster labels)
    """
    # Select features
    if feature_columns is None:
        feature_columns = df.select_dtypes(include=[np.number]).columns.tolist()
    
    if not feature_columns:
        raise ValueError("No numeric features found for clustering")
    
    # Extract feature matrix
    X = df[feature_columns].values
    
    # Remove rows with NaN
    mask = ~np.isnan(X).any(axis=1)
    X_clean = X[mask]
    
    if X_clean.shape[0] < 2:
        raise ValueError("Not enough valid samples for clustering")
    
    # Perform clustering
    clusterer = DBSCANClusterer(eps=eps, min_samples=min_samples, normalize=normalize)
    result = clusterer.fit(X_clean, feature_names=feature_columns)
    
    # Add cluster labels to dataframe
    df_result = df[mask].copy()
    df_result['cluster'] = result.labels
    df_result['is_noise'] = result.labels == -1
    
    return result, df_result


def find_optimal_dbscan_params(
    X: np.ndarray,
    eps_range: Optional[List[float]] = None,
    min_samples_range: Optional[List[int]] = None
) -> Tuple[float, int]:
    """Find optimal DBSCAN parameters by grid search.
    
    Args:
        X: Feature matrix
        eps_range: Range of eps values to try
        min_samples_range: Range of min_samples values to try
        
    Returns:
        Tuple of (optimal_eps, optimal_min_samples)
    """
    if eps_range is None:
        # Auto-generate eps range
        clusterer = DBSCANClusterer()
        estimated_eps = clusterer.estimate_eps(X)
        eps_range = [estimated_eps * 0.5, estimated_eps * 0.75, estimated_eps, estimated_eps * 1.25, estimated_eps * 1.5]
    
    if min_samples_range is None:
        n_features = X.shape[1]
        min_samples_range = [max(2, n_features), 2 * n_features, 3 * n_features]
    
    best_score = -1
    best_eps = eps_range[0]
    best_min_samples = min_samples_range[0]
    
    for eps in eps_range:
        for min_samples in min_samples_range:
            try:
                clusterer = DBSCANClusterer(eps=eps, min_samples=min_samples)
                result = clusterer.fit(X)
                
                # Score based on: number of clusters, noise ratio, silhouette
                if result.n_clusters > 0 and result.silhouette_score is not None:
                    # Penalize high noise ratio
                    score = result.silhouette_score * (1 - result.noise_ratio * 0.5)
                    
                    if score > best_score:
                        best_score = score
                        best_eps = eps
                        best_min_samples = min_samples
            except:
                continue
    
    return best_eps, best_min_samples
