"""K-Means clustering implementation.

This module provides K-Means clustering with automatic
optimal cluster selection using the elbow method.
"""

from typing import Optional, List, Dict, Any, Tuple
import pandas as pd
import numpy as np
from dataclasses import dataclass
from sklearn.cluster import KMeans as SKLearnKMeans
from sklearn.metrics import silhouette_score, calinski_harabasz_score, davies_bouldin_score
from sklearn.preprocessing import StandardScaler


@dataclass
class KMeansResult:
    """Result of K-Means clustering."""
    labels: np.ndarray
    n_clusters: int
    centroids: np.ndarray
    inertia: float
    silhouette_score: float
    calinski_harabasz_score: float
    davies_bouldin_score: float
    feature_names: List[str]
    cluster_sizes: Dict[int, int]


class KMeansClusterer:
    """K-Means clustering with automatic K selection."""
    
    def __init__(
        self,
        max_clusters: int = 10,
        random_state: int = 42,
        normalize: bool = True
    ):
        """Initialize K-Means clusterer.
        
        Args:
            max_clusters: Maximum number of clusters to try
            random_state: Random seed for reproducibility
            normalize: Whether to normalize features
        """
        self.max_clusters = max_clusters
        self.random_state = random_state
        self.normalize = normalize
        self.scaler = StandardScaler() if normalize else None
    
    def find_optimal_k(
        self,
        X: np.ndarray,
        min_clusters: int = 2,
        method: str = "elbow"
    ) -> int:
        """Find optimal number of clusters.
        
        Args:
            X: Feature matrix
            min_clusters: Minimum number of clusters
            method: Method for selection ('elbow', 'silhouette', 'gap')
            
        Returns:
            Optimal number of clusters
        """
        n_samples = X.shape[0]
        max_k = min(self.max_clusters, n_samples - 1)
        
        if max_k < min_clusters:
            return min_clusters
        
        if method == "elbow":
            return self._elbow_method(X, min_clusters, max_k)
        elif method == "silhouette":
            return self._silhouette_method(X, min_clusters, max_k)
        elif method == "gap":
            return self._gap_statistic_method(X, min_clusters, max_k)
        else:
            raise ValueError(f"Unknown method: {method}")
    
    def _elbow_method(self, X: np.ndarray, min_k: int, max_k: int) -> int:
        """Find optimal K using elbow method.
        
        Args:
            X: Feature matrix
            min_k: Minimum K
            max_k: Maximum K
            
        Returns:
            Optimal K
        """
        inertias = []
        k_range = range(min_k, max_k + 1)
        
        for k in k_range:
            kmeans = SKLearnKMeans(n_clusters=k, random_state=self.random_state, n_init=10)
            kmeans.fit(X)
            inertias.append(kmeans.inertia_)
        
        # Find elbow point using rate of change
        if len(inertias) < 3:
            return min_k
        
        # Calculate second derivative
        deltas = np.diff(inertias)
        second_deltas = np.diff(deltas)
        
        # Find maximum curvature
        if len(second_deltas) > 0:
            elbow_idx = np.argmax(second_deltas) + 1
            optimal_k = list(k_range)[elbow_idx]
        else:
            optimal_k = min_k
        
        return optimal_k
    
    def _silhouette_method(self, X: np.ndarray, min_k: int, max_k: int) -> int:
        """Find optimal K using silhouette score.
        
        Args:
            X: Feature matrix
            min_k: Minimum K
            max_k: Maximum K
            
        Returns:
            Optimal K
        """
        best_score = -1
        best_k = min_k
        
        for k in range(min_k, max_k + 1):
            kmeans = SKLearnKMeans(n_clusters=k, random_state=self.random_state, n_init=10)
            labels = kmeans.fit_predict(X)
            score = silhouette_score(X, labels)
            
            if score > best_score:
                best_score = score
                best_k = k
        
        return best_k
    
    def _gap_statistic_method(self, X: np.ndarray, min_k: int, max_k: int, n_refs: int = 10) -> int:
        """Find optimal K using gap statistic.
        
        Args:
            X: Feature matrix
            min_k: Minimum K
            max_k: Maximum K
            n_refs: Number of reference datasets
            
        Returns:
            Optimal K
        """
        gaps = []
        
        for k in range(min_k, max_k + 1):
            # Cluster original data
            kmeans = SKLearnKMeans(n_clusters=k, random_state=self.random_state, n_init=10)
            kmeans.fit(X)
            log_wk = np.log(kmeans.inertia_)
            
            # Generate reference datasets and cluster them
            ref_log_wks = []
            for _ in range(n_refs):
                # Generate random reference data
                random_data = np.random.uniform(X.min(axis=0), X.max(axis=0), size=X.shape)
                kmeans_ref = SKLearnKMeans(n_clusters=k, random_state=self.random_state, n_init=10)
                kmeans_ref.fit(random_data)
                ref_log_wks.append(np.log(kmeans_ref.inertia_))
            
            # Calculate gap
            gap = np.mean(ref_log_wks) - log_wk
            gaps.append(gap)
        
        # Find first K where gap(K) >= gap(K+1) - std(K+1)
        if len(gaps) < 2:
            return min_k
        
        for i in range(len(gaps) - 1):
            if gaps[i] >= gaps[i + 1]:
                return min_k + i
        
        # If no clear gap found, return K with maximum gap
        return min_k + np.argmax(gaps)
    
    def fit(
        self,
        X: np.ndarray,
        n_clusters: Optional[int] = None,
        feature_names: Optional[List[str]] = None
    ) -> KMeansResult:
        """Fit K-Means clustering.
        
        Args:
            X: Feature matrix (n_samples, n_features)
            n_clusters: Number of clusters (auto-detected if None)
            feature_names: Names of features
            
        Returns:
            KMeansResult object
        """
        if X.shape[0] < 2:
            raise ValueError("Need at least 2 samples for clustering")
        
        # Normalize if requested
        if self.normalize and self.scaler:
            X_scaled = self.scaler.fit_transform(X)
        else:
            X_scaled = X
        
        # Determine number of clusters
        if n_clusters is None:
            n_clusters = self.find_optimal_k(X_scaled)
        
        # Ensure valid number of clusters
        n_clusters = max(2, min(n_clusters, X.shape[0] - 1))
        
        # Fit K-Means
        kmeans = SKLearnKMeans(
            n_clusters=n_clusters,
            random_state=self.random_state,
            n_init=10
        )
        labels = kmeans.fit_predict(X_scaled)
        
        # Calculate metrics
        sil_score = silhouette_score(X_scaled, labels) if n_clusters > 1 else 0.0
        ch_score = calinski_harabasz_score(X_scaled, labels) if n_clusters > 1 else 0.0
        db_score = davies_bouldin_score(X_scaled, labels) if n_clusters > 1 else 0.0
        
        # Calculate cluster sizes
        unique, counts = np.unique(labels, return_counts=True)
        cluster_sizes = dict(zip(unique.tolist(), counts.tolist()))
        
        # Get centroids in original scale
        if self.normalize and self.scaler:
            centroids = self.scaler.inverse_transform(kmeans.cluster_centers_)
        else:
            centroids = kmeans.cluster_centers_
        
        # Set feature names
        if feature_names is None:
            feature_names = [f"feature_{i}" for i in range(X.shape[1])]
        
        return KMeansResult(
            labels=labels,
            n_clusters=n_clusters,
            centroids=centroids,
            inertia=kmeans.inertia_,
            silhouette_score=sil_score,
            calinski_harabasz_score=ch_score,
            davies_bouldin_score=db_score,
            feature_names=feature_names,
            cluster_sizes=cluster_sizes
        )
    
    def fit_predict(
        self,
        X: np.ndarray,
        n_clusters: Optional[int] = None
    ) -> np.ndarray:
        """Fit K-Means and return cluster labels.
        
        Args:
            X: Feature matrix
            n_clusters: Number of clusters
            
        Returns:
            Cluster labels
        """
        result = self.fit(X, n_clusters)
        return result.labels


def cluster_kmeans(
    df: pd.DataFrame,
    feature_columns: Optional[List[str]] = None,
    n_clusters: Optional[int] = None,
    max_clusters: int = 10,
    normalize: bool = True
) -> Tuple[KMeansResult, pd.DataFrame]:
    """High-level function to perform K-Means clustering.
    
    Args:
        df: Input DataFrame
        feature_columns: Columns to use for clustering (numeric only if None)
        n_clusters: Number of clusters (auto if None)
        max_clusters: Maximum clusters to try
        normalize: Whether to normalize features
        
    Returns:
        Tuple of (KMeansResult, DataFrame with cluster labels)
    """
    # Select features
    if feature_columns is None:
        feature_columns = df.select_dtypes(include=[np.number]).columns.tolist()
    
    if not feature_columns:
        raise ValueError("No numeric features found for clustering")
    
    # Extract feature matrix
    X = df[feature_columns].values
    
    # Remove rows with NaN
    mask = ~np.isnan(X).any(axis=1)
    X_clean = X[mask]
    
    if X_clean.shape[0] < 2:
        raise ValueError("Not enough valid samples for clustering")
    
    # Perform clustering
    clusterer = KMeansClusterer(max_clusters=max_clusters, normalize=normalize)
    result = clusterer.fit(X_clean, n_clusters=n_clusters, feature_names=feature_columns)
    
    # Add cluster labels to dataframe
    df_result = df[mask].copy()
    df_result['cluster'] = result.labels
    
    return result, df_result
