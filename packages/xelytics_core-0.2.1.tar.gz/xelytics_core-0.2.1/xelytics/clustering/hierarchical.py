"""Hierarchical clustering implementation.

This module provides agglomerative hierarchical clustering
with dendrogram support.
"""

from typing import Optional, List, Dict, Any, Tuple
import pandas as pd
import numpy as np
from dataclasses import dataclass
from sklearn.cluster import AgglomerativeClustering
from sklearn.metrics import silhouette_score, calinski_harabasz_score
from sklearn.preprocessing import StandardScaler
from scipy.cluster.hierarchy import dendrogram, linkage
from scipy.spatial.distance import pdist


@dataclass
class HierarchicalResult:
    """Result of hierarchical clustering."""
    labels: np.ndarray
    n_clusters: int
    linkage_matrix: np.ndarray
    distances: np.ndarray
    silhouette_score: float
    calinski_harabasz_score: float
    linkage_method: str
    distance_metric: str
    feature_names: List[str]
    cluster_sizes: Dict[int, int]
    dendrogram_data: Optional[Dict[str, Any]] = None


class HierarchicalClusterer:
    """Hierarchical clustering with dendrogram generation."""
    
    def __init__(
        self,
        n_clusters: Optional[int] = None,
        linkage_method: str = "ward",
        distance_metric: str = "euclidean",
        normalize: bool = True,
        random_state: int = 42
    ):
        """Initialize hierarchical clusterer.
        
        Args:
            n_clusters: Number of clusters (auto if None)
            linkage_method: Linkage method ('ward', 'complete', 'average', 'single')
            distance_metric: Distance metric ('euclidean', 'manhattan', 'cosine')
            normalize: Whether to normalize features
            random_state: Random seed
        """
        self.n_clusters = n_clusters
        self.linkage_method = linkage_method
        self.distance_metric = distance_metric
        self.normalize = normalize
        self.random_state = random_state
        self.scaler = StandardScaler() if normalize else None
    
    def estimate_n_clusters(
        self,
        linkage_matrix: np.ndarray,
        method: str = "elbow",
        max_clusters: int = 10
    ) -> int:
        """Estimate optimal number of clusters from dendrogram.
        
        Args:
            linkage_matrix: Linkage matrix from hierarchical clustering
            method: Method for estimation ('elbow' or 'distance_threshold')
            max_clusters: Maximum number of clusters
            
        Returns:
            Estimated number of clusters
        """
        if method == "elbow":
            # Use distances to find elbow
            distances = linkage_matrix[:, 2]
            
            if len(distances) < 2:
                return 2
            
            # Calculate acceleration (second derivative)
            diffs = np.diff(distances)
            if len(diffs) < 2:
                return 2
            
            accel = np.diff(diffs)
            
            # Find maximum acceleration (elbow point)
            elbow_idx = np.argmax(accel)
            
            # Number of clusters is based on where we cut
            n_clusters = min(len(linkage_matrix) - elbow_idx + 1, max_clusters)
            n_clusters = max(2, n_clusters)
            
            return n_clusters
        
        elif method == "distance_threshold":
            # Find significant jump in distances
            distances = linkage_matrix[:, 2]
            
            if len(distances) < 2:
                return 2
            
            # Calculate relative distance increases
            rel_increases = np.diff(distances) / distances[:-1]
            
            # Find first significant increase (>50%)
            significant = np.where(rel_increases > 0.5)[0]
            
            if len(significant) > 0:
                cut_idx = significant[0]
                n_clusters = len(linkage_matrix) - cut_idx + 1
                n_clusters = min(n_clusters, max_clusters)
                n_clusters = max(2, n_clusters)
                return n_clusters
            
            return 2
        
        else:
            return 2
    
    def compute_linkage(
        self,
        X: np.ndarray
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Compute linkage matrix and distances.
        
        Args:
            X: Feature matrix
            
        Returns:
            Tuple of (linkage_matrix, distances)
        """
        # Compute pairwise distances
        if self.linkage_method == "ward":
            # Ward requires euclidean distance
            distances = pdist(X, metric='euclidean')
        else:
            distances = pdist(X, metric=self.distance_metric)
        
        # Compute linkage matrix
        linkage_matrix = linkage(distances, method=self.linkage_method)
        
        return linkage_matrix, distances
    
    def generate_dendrogram(
        self,
        linkage_matrix: np.ndarray,
        labels: Optional[List[str]] = None,
        truncate_mode: Optional[str] = None,
        p: int = 30
    ) -> Dict[str, Any]:
        """Generate dendrogram data.
        
        Args:
            linkage_matrix: Linkage matrix
            labels: Sample labels
            truncate_mode: Truncation mode ('lastp', 'level', None)
            p: Number of nodes to show (for lastp mode)
            
        Returns:
            Dictionary with dendrogram data
        """
        dendro_data = dendrogram(
            linkage_matrix,
            labels=labels,
            truncate_mode=truncate_mode,
            p=p,
            no_plot=True  # Don't plot, just return data
        )
        
        return dendro_data
    
    def fit(
        self,
        X: np.ndarray,
        n_clusters: Optional[int] = None,
        feature_names: Optional[List[str]] = None,
        generate_dendrogram_data: bool = False
    ) -> HierarchicalResult:
        """Fit hierarchical clustering.
        
        Args:
            X: Feature matrix (n_samples, n_features)
            n_clusters: Number of clusters (estimated if None)
            feature_names: Names of features
            generate_dendrogram_data: Whether to generate dendrogram data
            
        Returns:
            HierarchicalResult object
        """
        if X.shape[0] < 2:
            raise ValueError("Need at least 2 samples for clustering")
        
        # Normalize if requested
        if self.normalize and self.scaler:
            X_scaled = self.scaler.fit_transform(X)
        else:
            X_scaled = X
        
        # Compute linkage matrix
        linkage_matrix, distances = self.compute_linkage(X_scaled)
        
        # Determine number of clusters
        if n_clusters is None:
            n_clusters = self.n_clusters if self.n_clusters is not None else self.estimate_n_clusters(linkage_matrix)
        
        # Ensure valid number of clusters
        n_clusters = max(2, min(n_clusters, X.shape[0]))
        
        # Fit agglomerative clustering
        clusterer = AgglomerativeClustering(
            n_clusters=n_clusters,
            linkage=self.linkage_method,
            metric=self.distance_metric if self.linkage_method != "ward" else "euclidean"
        )
        labels = clusterer.fit_predict(X_scaled)
        
        # Calculate metrics
        sil_score = silhouette_score(X_scaled, labels) if n_clusters > 1 else 0.0
        ch_score = calinski_harabasz_score(X_scaled, labels) if n_clusters > 1 else 0.0
        
        # Calculate cluster sizes
        unique, counts = np.unique(labels, return_counts=True)
        cluster_sizes = dict(zip(unique.tolist(), counts.tolist()))
        
        # Set feature names
        if feature_names is None:
            feature_names = [f"feature_{i}" for i in range(X.shape[1])]
        
        # Generate dendrogram data if requested
        dendro_data = None
        if generate_dendrogram_data:
            dendro_data = self.generate_dendrogram(linkage_matrix)
        
        return HierarchicalResult(
            labels=labels,
            n_clusters=n_clusters,
            linkage_matrix=linkage_matrix,
            distances=distances,
            silhouette_score=sil_score,
            calinski_harabasz_score=ch_score,
            linkage_method=self.linkage_method,
            distance_metric=self.distance_metric if self.linkage_method != "ward" else "euclidean",
            feature_names=feature_names,
            cluster_sizes=cluster_sizes,
            dendrogram_data=dendro_data
        )
    
    def fit_predict(
        self,
        X: np.ndarray,
        n_clusters: Optional[int] = None
    ) -> np.ndarray:
        """Fit hierarchical clustering and return labels.
        
        Args:
            X: Feature matrix
            n_clusters: Number of clusters
            
        Returns:
            Cluster labels
        """
        result = self.fit(X, n_clusters)
        return result.labels


def cluster_hierarchical(
    df: pd.DataFrame,
    feature_columns: Optional[List[str]] = None,
    n_clusters: Optional[int] = None,
    linkage_method: str = "ward",
    distance_metric: str = "euclidean",
    normalize: bool = True,
    generate_dendrogram: bool = False
) -> Tuple[HierarchicalResult, pd.DataFrame]:
    """High-level function to perform hierarchical clustering.
    
    Args:
        df: Input DataFrame
        feature_columns: Columns to use for clustering (numeric only if None)
        n_clusters: Number of clusters (auto if None)
        linkage_method: Linkage method ('ward', 'complete', 'average', 'single')
        distance_metric: Distance metric
        normalize: Whether to normalize features
        generate_dendrogram: Whether to generate dendrogram data
        
    Returns:
        Tuple of (HierarchicalResult, DataFrame with cluster labels)
    """
    # Select features
    if feature_columns is None:
        feature_columns = df.select_dtypes(include=[np.number]).columns.tolist()
    
    if not feature_columns:
        raise ValueError("No numeric features found for clustering")
    
    # Extract feature matrix
    X = df[feature_columns].values
    
    # Remove rows with NaN
    mask = ~np.isnan(X).any(axis=1)
    X_clean = X[mask]
    
    if X_clean.shape[0] < 2:
        raise ValueError("Not enough valid samples for clustering")
    
    # Perform clustering
    clusterer = HierarchicalClusterer(
        n_clusters=n_clusters,
        linkage_method=linkage_method,
        distance_metric=distance_metric,
        normalize=normalize
    )
    result = clusterer.fit(
        X_clean,
        feature_names=feature_columns,
        generate_dendrogram_data=generate_dendrogram
    )
    
    # Add cluster labels to dataframe
    df_result = df[mask].copy()
    df_result['cluster'] = result.labels
    
    return result, df_result


def plot_dendrogram_simple(
    linkage_matrix: np.ndarray,
    truncate_mode: Optional[str] = "lastp",
    p: int = 30
) -> Dict[str, Any]:
    """Generate dendrogram data for plotting.
    
    Args:
        linkage_matrix: Linkage matrix from hierarchical clustering
        truncate_mode: Truncation mode
        p: Number of nodes to show
        
    Returns:
        Dictionary with dendrogram plotting data
    """
    return dendrogram(
        linkage_matrix,
        truncate_mode=truncate_mode,
        p=p,
        no_plot=True
    )
