"""Cluster profiling and characterization module.

This module provides tools to profile and interpret clusters,
generating human-readable descriptions of cluster characteristics.
"""

from typing import List, Dict, Any, Optional, Tuple
import pandas as pd
import numpy as np
from dataclasses import dataclass, field
from scipy import stats


@dataclass
class FeatureProfile:
    """Profile of a feature within a cluster."""
    feature_name: str
    mean: float
    median: float
    std: float
    min: float
    max: float
    percentile_25: float
    percentile_75: float
    distinct_count: Optional[int] = None
    mode: Optional[Any] = None


@dataclass
class ClusterProfile:
    """Comprehensive profile of a cluster."""
    cluster_id: int
    size: int
    percentage: float
    feature_profiles: List[FeatureProfile]
    distinguishing_features: List[Tuple[str, float]]  # (feature, importance)
    summary_statistics: Dict[str, Any]
    description: str


class ClusterProfiler:
    """Profiler for generating cluster characterizations."""
    
    def __init__(self, top_n_features: int = 5):
        """Initialize cluster profiler.
        
        Args:
            top_n_features: Number of top distinguishing features to identify
        """
        self.top_n_features = top_n_features
    
    def profile_cluster(
        self,
        df: pd.DataFrame,
        cluster_labels: np.ndarray,
        cluster_id: int,
        feature_columns: Optional[List[str]] = None
    ) -> ClusterProfile:
        """Profile a single cluster.
        
        Args:
            df: Input DataFrame
            cluster_labels: Cluster labels array
            cluster_id: ID of cluster to profile
            feature_columns: Features to profile (all numeric if None)
            
        Returns:
            ClusterProfile object
        """
        # Select features
        if feature_columns is None:
            feature_columns = df.select_dtypes(include=[np.number]).columns.tolist()
        
        # Get cluster mask
        cluster_mask = cluster_labels == cluster_id
        cluster_data = df[cluster_mask]
        
        if len(cluster_data) == 0:
            raise ValueError(f"Cluster {cluster_id} has no samples")
        
        # Calculate size and percentage
        size = len(cluster_data)
        percentage = (size / len(df)) * 100 if len(df) > 0 else 0.0
        
        # Profile each feature
        feature_profiles = []
        for col in feature_columns:
            if col in cluster_data.columns:
                profile = self._profile_feature(cluster_data[col], col)
                feature_profiles.append(profile)
        
        # Find distinguishing features
        distinguishing_features = self._find_distinguishing_features(
            df, cluster_labels, cluster_id, feature_columns
        )
        
        # Generate summary statistics
        summary_stats = self._calculate_summary_statistics(cluster_data, feature_columns)
        
        # Generate description
        description = self._generate_description(
            cluster_id, size, percentage, distinguishing_features, feature_profiles
        )
        
        return ClusterProfile(
            cluster_id=cluster_id,
            size=size,
            percentage=percentage,
            feature_profiles=feature_profiles,
            distinguishing_features=distinguishing_features,
            summary_statistics=summary_stats,
            description=description
        )
    
    def _profile_feature(self, series: pd.Series, feature_name: str) -> FeatureProfile:
        """Profile a single feature.
        
        Args:
            series: Feature series
            feature_name: Name of the feature
            
        Returns:
            FeatureProfile object
        """
        series_clean = series.dropna()
        
        if len(series_clean) == 0:
            return FeatureProfile(
                feature_name=feature_name,
                mean=0.0, median=0.0, std=0.0,
                min=0.0, max=0.0,
                percentile_25=0.0, percentile_75=0.0
            )
        
        # Check if numeric
        if pd.api.types.is_numeric_dtype(series_clean):
            return FeatureProfile(
                feature_name=feature_name,
                mean=float(series_clean.mean()),
                median=float(series_clean.median()),
                std=float(series_clean.std()),
                min=float(series_clean.min()),
                max=float(series_clean.max()),
                percentile_25=float(series_clean.quantile(0.25)),
                percentile_75=float(series_clean.quantile(0.75)),
                distinct_count=int(series_clean.nunique())
            )
        else:
            # Categorical feature
            mode_val = series_clean.mode()[0] if len(series_clean.mode()) > 0 else None
            return FeatureProfile(
                feature_name=feature_name,
                mean=0.0, median=0.0, std=0.0,
                min=0.0, max=0.0,
                percentile_25=0.0, percentile_75=0.0,
                distinct_count=int(series_clean.nunique()),
                mode=mode_val
            )
    
    def _find_distinguishing_features(
        self,
        df: pd.DataFrame,
        cluster_labels: np.ndarray,
        cluster_id: int,
        feature_columns: List[str]
    ) -> List[Tuple[str, float]]:
        """Find features that distinguish this cluster from others.
        
        Uses variance ratio and mean difference to identify distinguishing features.
        
        Args:
            df: Full DataFrame
            cluster_labels: Cluster labels
            cluster_id: Target cluster ID
            feature_columns: Features to analyze
            
        Returns:
            List of (feature_name, importance_score) tuples
        """
        cluster_mask = cluster_labels == cluster_id
        cluster_data = df[cluster_mask]
        other_data = df[~cluster_mask]
        
        if len(other_data) == 0:
            return []
        
        feature_scores = []
        
        for col in feature_columns:
            if col not in df.columns:
                continue
            
            # Only analyze numeric features
            if not pd.api.types.is_numeric_dtype(df[col]):
                continue
            
            cluster_values = cluster_data[col].dropna()
            other_values = other_data[col].dropna()
            
            if len(cluster_values) < 2 or len(other_values) < 2:
                continue
            
            # Calculate t-test to measure difference
            try:
                t_stat, p_value = stats.ttest_ind(cluster_values, other_values)
                
                # Calculate effect size (Cohen's d)
                mean_diff = abs(cluster_values.mean() - other_values.mean())
                pooled_std = np.sqrt((cluster_values.std()**2 + other_values.std()**2) / 2)
                
                if pooled_std > 0:
                    cohens_d = mean_diff / pooled_std
                else:
                    cohens_d = 0.0
                
                # Importance score combines statistical significance and effect size
                importance = cohens_d * (1 - min(p_value, 1.0))
                
                feature_scores.append((col, float(importance)))
            except:
                continue
        
        # Sort by importance and return top N
        feature_scores.sort(key=lambda x: x[1], reverse=True)
        return feature_scores[:self.top_n_features]
    
    def _calculate_summary_statistics(
        self,
        cluster_data: pd.DataFrame,
        feature_columns: List[str]
    ) -> Dict[str, Any]:
        """Calculate summary statistics for a cluster.
        
        Args:
            cluster_data: Cluster data
            feature_columns: Features to summarize
            
        Returns:
            Dictionary of summary statistics
        """
        stats_dict = {
            'size': len(cluster_data),
            'n_features': len(feature_columns),
        }
        
        # Add per-feature stats
        for col in feature_columns:
            if col in cluster_data.columns and pd.api.types.is_numeric_dtype(cluster_data[col]):
                col_clean = cluster_data[col].dropna()
                if len(col_clean) > 0:
                    stats_dict[f'{col}_mean'] = float(col_clean.mean())
                    stats_dict[f'{col}_std'] = float(col_clean.std())
        
        return stats_dict
    
    def _generate_description(
        self,
        cluster_id: int,
        size: int,
        percentage: float,
        distinguishing_features: List[Tuple[str, float]],
        feature_profiles: List[FeatureProfile]
    ) -> str:
        """Generate human-readable description of cluster.
        
        Args:
            cluster_id: Cluster ID
            size: Number of samples
            percentage: Percentage of total
            distinguishing_features: Top distinguishing features
            feature_profiles: Feature profiles
            
        Returns:
            Description string
        """
        desc_parts = [
            f"Cluster {cluster_id} contains {size} samples ({percentage:.1f}% of total)."
        ]
        
        if distinguishing_features:
            desc_parts.append("\nDistinguishing characteristics:")
            for feature, importance in distinguishing_features[:3]:
                # Find the feature profile
                profile = next((fp for fp in feature_profiles if fp.feature_name == feature), None)
                if profile:
                    desc_parts.append(
                        f"  - {feature}: mean={profile.mean:.2f}, std={profile.std:.2f}"
                    )
        
        return " ".join(desc_parts)
    
    def profile_all_clusters(
        self,
        df: pd.DataFrame,
        cluster_labels: np.ndarray,
        feature_columns: Optional[List[str]] = None
    ) -> List[ClusterProfile]:
        """Profile all clusters.
        
        Args:
            df: Input DataFrame
            cluster_labels: Cluster labels array
            feature_columns: Features to profile
            
        Returns:
            List of ClusterProfile objects
        """
        unique_clusters = np.unique(cluster_labels)
        
        # Filter out noise cluster (-1) if present
        unique_clusters = [c for c in unique_clusters if c != -1]
        
        profiles = []
        for cluster_id in unique_clusters:
            try:
                profile = self.profile_cluster(df, cluster_labels, cluster_id, feature_columns)
                profiles.append(profile)
            except Exception as e:
                # Skip clusters that fail profiling
                continue
        
        return profiles
    
    def compare_clusters(
        self,
        profiles: List[ClusterProfile]
    ) -> Dict[str, Any]:
        """Compare clusters and identify key differences.
        
        Args:
            profiles: List of cluster profiles
            
        Returns:
            Dictionary with comparison results
        """
        if len(profiles) < 2:
            return {'comparison': 'Not enough clusters to compare'}
        
        comparison = {
            'n_clusters': len(profiles),
            'size_stats': {
                'min': min(p.size for p in profiles),
                'max': max(p.size for p in profiles),
                'mean': np.mean([p.size for p in profiles]),
                'std': np.std([p.size for p in profiles])
            },
            'cluster_summaries': []
        }
        
        for profile in profiles:
            comparison['cluster_summaries'].append({
                'cluster_id': profile.cluster_id,
                'size': profile.size,
                'percentage': profile.percentage,
                'top_features': [f[0] for f in profile.distinguishing_features[:3]]
            })
        
        return comparison


def profile_clusters(
    df: pd.DataFrame,
    cluster_labels: np.ndarray,
    feature_columns: Optional[List[str]] = None,
    top_n_features: int = 5
) -> List[ClusterProfile]:
    """High-level function to profile all clusters.
    
    Args:
        df: Input DataFrame
        cluster_labels: Cluster labels array
        feature_columns: Features to profile (all numeric if None)
        top_n_features: Number of top distinguishing features
        
    Returns:
        List of ClusterProfile objects
    """
    profiler = ClusterProfiler(top_n_features=top_n_features)
    profiles = profiler.profile_all_clusters(df, cluster_labels, feature_columns)
    return profiles
