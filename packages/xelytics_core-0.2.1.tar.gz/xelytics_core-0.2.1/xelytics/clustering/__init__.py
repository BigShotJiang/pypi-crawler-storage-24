from typing import List, Optional
import pandas as pd
from xelytics.schemas.outputs import ClusterResult, ClusteringAlgorithm
from xelytics.clustering.kmeans import cluster_kmeans
from xelytics.clustering.dbscan import cluster_dbscan
from xelytics.clustering.hierarchical import cluster_hierarchical
from xelytics.clustering.profiler import ClusterProfiler

def analyze_clusters(
    df: pd.DataFrame,
    algorithm: str = "auto",
    max_clusters: int = 10,
    features: Optional[List[str]] = None,
    **kwargs
) -> List[ClusterResult]:
    """
    High-level clustering function that returns a list of ClusterResult.
    algorithm: 'kmeans', 'dbscan', 'hierarchical', or 'auto' (tries all and picks best).
    """
    results = []

    # Determine algorithm
    if algorithm == "auto":
        # Try all and pick based on silhouette score
        best_score = -1
        best_result = None
        for algo in ["kmeans", "dbscan", "hierarchical"]:
            try:
                if algo == "kmeans":
                    res, df_res = cluster_kmeans(df, feature_columns=features, n_clusters=max_clusters)
                elif algo == "dbscan":
                    res, df_res = cluster_dbscan(df, feature_columns=features, eps=None, min_samples=None)
                else:  # hierarchical
                    res, df_res = cluster_hierarchical(df, feature_columns=features, n_clusters=max_clusters)

                if res.silhouette_score and res.silhouette_score > best_score:
                    best_score = res.silhouette_score
                    best_result = (algo, res, df_res)
            except Exception:
                continue

        if best_result is None:
            return []
        algorithm, result, df_clustered = best_result
    else:
        # Use specified algorithm
        if algorithm == "kmeans":
            result, df_clustered = cluster_kmeans(df, feature_columns=features, n_clusters=max_clusters)
        elif algorithm == "dbscan":
            result, df_clustered = cluster_dbscan(df, feature_columns=features, eps=None, min_samples=None)
        elif algorithm == "hierarchical":
            result, df_clustered = cluster_hierarchical(df, feature_columns=features, n_clusters=max_clusters)
        else:
            raise ValueError(f"Unknown clustering algorithm: {algorithm}")

    # Use ClusterProfiler to generate profiles for each cluster
    profiler = ClusterProfiler()
    profiles_list = profiler.profile_all_clusters(df_clustered, result.labels, feature_columns=features)
        
        # Convert the list of objects into a dictionary mapped by cluster_id
    cluster_profiles = {p.cluster_id: p for p in profiles_list}

        # Convert to ClusterResult list
    cluster_results = []
    for cluster_id in sorted(set(result.labels)):
        if cluster_id == -1:
            continue  # skip noise in DBSCAN
        members = df_clustered[df_clustered['cluster'] == cluster_id].index.tolist()
        profile = cluster_profiles.get(cluster_id, {})
        centroid = result.centroids[cluster_id] if hasattr(result, 'centroids') else {}
        cluster_results.append(ClusterResult(
            cluster_id=cluster_id,
            algorithm=ClusteringAlgorithm(algorithm),
            size=result.cluster_sizes.get(cluster_id, 0),
            centroid=centroid,
            profile=profile,
            silhouette_score=result.silhouette_score or 0.0,
            members=members
        ))

    return cluster_results