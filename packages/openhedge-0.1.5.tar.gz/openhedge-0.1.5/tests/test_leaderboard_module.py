"""Tests for the LeaderboardModule."""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest

from openhedge.exceptions import ServerError
from openhedge.models.leaderboard import LeaderboardEntry
from tests.conftest import make_api_response


class TestLeaderboardGet:
    async def test_get_leaderboard(self, agent):
        response_data = {
            "segment": "all",
            "sortBy": "aum",
            "season": {"startTs": 1000, "endTs": 2000},
            "total": 2,
            "page": 1,
            "pageSize": 20,
            "dataSource": "subgraph",
            "vaults": [
                {
                    "vaultAddress": "0x" + "11" * 20,
                    "vaultName": "Alpha",
                    "managerAddress": "0x" + "22" * 20,
                    "managerType": "ai",
                    "verificationTier": "verified",
                    "totalReturnBps": 500,
                    "sharpeRatio": 1.5,
                    "aumRaw": "5000000",
                    "navPerShare": "1050000",
                    "depositCount": 10,
                    "withdrawalCount": 2,
                    "tradeCount": 50,
                    "rank": 1,
                    "seasonRank": 1,
                },
                {
                    "vaultAddress": "0x" + "33" * 20,
                    "vaultName": "Beta",
                    "managerAddress": "0x" + "44" * 20,
                    "managerType": "human",
                    "verificationTier": "unverified",
                    "totalReturnBps": -200,
                    "sharpeRatio": 0.3,
                    "aumRaw": "3000000",
                    "navPerShare": "980000",
                    "depositCount": 5,
                    "withdrawalCount": 1,
                    "tradeCount": 20,
                    "rank": 2,
                    "seasonRank": 2,
                },
            ],
        }
        with patch.object(
            agent._http,
            "get",
            new_callable=AsyncMock,
            return_value=make_api_response(response_data),
        ):
            lb = await agent.leaderboard.get(segment="all", sort="aum")

        assert isinstance(lb, LeaderboardEntry)
        assert lb.segment == "all"
        assert lb.total == 2
        assert len(lb.vaults) == 2
        assert lb.vaults[0].rank == 1

    async def test_get_leaderboard_server_error(self, agent):
        with patch.object(
            agent._http,
            "get",
            new_callable=AsyncMock,
            return_value=make_api_response({"error": "internal"}, 500),
        ):
            with pytest.raises(ServerError):
                await agent.leaderboard.get()
