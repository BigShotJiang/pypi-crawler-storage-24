"""LeaderboardModule — fetch vault rankings from the leaderboard worker."""

from __future__ import annotations

from openhedge.models.leaderboard import LeaderboardEntry, VaultRanking
from openhedge.modules.base import BaseModule


class LeaderboardModule(BaseModule):
    """REST-backed leaderboard queries."""

    async def get(
        self,
        *,
        segment: str = "all",
        sort: str = "aum",
        page: int = 1,
        page_size: int = 20,
    ) -> LeaderboardEntry:
        """Fetch the leaderboard from the leaderboard worker.

        Parameters
        ----------
        segment:
            ``'all'``, ``'human'``, or ``'ai'``.
        sort:
            ``'totalReturn'``, ``'sharpeRatio'``, or ``'aum'``.
        page:
            Page number (1-based).
        page_size:
            Number of vaults per page (max 100).

        Returns
        -------
        A :class:`LeaderboardEntry` containing ranked vaults.
        """
        data = await self._api_get(
            "/leaderboard",
            segment=segment,
            sort=sort,
            page=page,
            pageSize=page_size,
        )

        vaults = [VaultRanking(**v) for v in data.get("vaults", [])]
        return LeaderboardEntry(
            segment=data.get("segment", segment),
            sort_by=data.get("sortBy", sort),
            total=data.get("total", len(vaults)),
            page=data.get("page", page),
            page_size=data.get("pageSize", page_size),
            data_source=data.get("dataSource"),
            vaults=vaults,
        )
