"""Vault-related data models."""

from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field


class Guardrails(BaseModel):
    """Risk guardrails for a TraderVault, stored in basis points."""

    max_leverage_bps: int = Field(
        ..., ge=0, le=1500000, description="Max leverage in bps (e.g. 30000 = 3x, 150000 = 15x)"
    )
    max_drawdown_bps: int = Field(
        ..., ge=0, le=10000, description="Max drawdown as bps (e.g. 2000 = 20%)"
    )
    max_position_bps: int = Field(
        ..., ge=0, le=10000, description="Max single-position size as bps of AUM"
    )


class VaultConfig(BaseModel):
    """Parameters required to deploy a new vault via VaultFactory."""

    name: str = Field(..., min_length=1, max_length=64)
    asset: str = Field(
        default="USDC",
        description="Underlying asset symbol or address (default USDC)",
    )
    guardrails: Guardrails
    salt: Optional[str] = Field(
        None,
        description="32-byte hex salt for CREATE2; auto-generated if omitted",
    )


class VaultNav(BaseModel):
    """Compact NAV snapshot for a vault, matching the TypeScript SDK's VaultNav type."""

    address: str = Field(..., description="Vault contract address")
    share_price: int = Field(..., description="NAV per share (raw uint256)")
    total_assets: int = Field(..., description="Total assets under management")
    total_supply: int = Field(..., description="Total shares outstanding")


class Vault(BaseModel):
    """On-chain state snapshot of a TraderVault."""

    address: str
    name: str
    symbol: str
    asset: str = Field(..., description="Underlying ERC-20 address")
    trader: str = Field(..., description="Trader/manager address")
    owner: str
    total_assets: int = Field(..., description="Total AUM in asset units")
    total_supply: int = Field(..., description="Outstanding vault shares")
    share_price: int = Field(..., description="NAV per share (raw uint256)")
    high_water_mark: int = 0
    guardrails: Optional[Guardrails] = None
    decimals: int = 6
