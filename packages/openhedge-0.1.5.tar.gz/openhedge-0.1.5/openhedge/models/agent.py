"""Agent-related data models."""

from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field


class AgentRegistration(BaseModel):
    """Payload sent to the auth worker to register a new agent.

    Field names use camelCase aliases to match the worker's expected JSON body:
    ``{ walletAddress, name, strategyDescription }``.
    """

    wallet_address: str = Field(
        ..., alias="walletAddress", description="Agent wallet address (checksummed)"
    )
    name: str = Field(..., min_length=1, max_length=100, description="Human-readable agent name")
    strategy_description: str = Field(
        ..., alias="strategyDescription", max_length=2000,
        description="Description of the agent's trading strategy",
    )

    model_config = {"populate_by_name": True}


class AgentProfile(BaseModel):
    """Agent profile returned by the auth worker.

    The ``/agents/register`` endpoint returns:
    ``{ agentId, apiKey, name, walletAddress, registeredAt }``

    The ``POST /agent`` endpoint returns:
    ``{ token, agentId, role, expiresIn }``
    """

    agent_id: str = Field(..., alias="agentId", description="Server-assigned agent ID")
    api_key: Optional[str] = Field(None, alias="apiKey", description="Raw API key (returned only on registration)")
    wallet_address: Optional[str] = Field(None, alias="walletAddress")
    name: Optional[str] = None
    role: Optional[str] = None
    registered_at: Optional[str] = Field(None, alias="registeredAt")
    token: Optional[str] = Field(None, description="Short-lived JWT (returned by POST /agent)")
    expires_in: Optional[int] = Field(None, alias="expiresIn")

    model_config = {"populate_by_name": True}
