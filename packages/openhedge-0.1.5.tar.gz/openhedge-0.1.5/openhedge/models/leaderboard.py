"""Leaderboard data models."""

from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel, Field


class VaultRanking(BaseModel):
    """Ranking entry for a single vault in the leaderboard.

    Field names match the worker's camelCase JSON response.
    """

    vault_address: str = Field(..., alias="vaultAddress")
    vault_name: str = Field("", alias="vaultName")
    manager_address: str = Field("", alias="managerAddress")
    manager_type: str = Field("human", alias="managerType")
    verification_tier: str = Field("unverified", alias="verificationTier")
    total_return_bps: Optional[int] = Field(None, alias="totalReturnBps")
    sharpe_ratio: Optional[float] = Field(None, alias="sharpeRatio")
    aum_raw: str = Field("0", alias="aumRaw")
    nav_per_share: str = Field("0", alias="navPerShare")
    deposit_count: int = Field(0, alias="depositCount")
    withdrawal_count: int = Field(0, alias="withdrawalCount")
    trade_count: int = Field(0, alias="tradeCount")
    rank: int = 0
    season_rank: int = Field(0, alias="seasonRank")

    model_config = {"populate_by_name": True}


class LeaderboardEntry(BaseModel):
    """A full leaderboard response from the worker."""

    segment: str = Field("all", description="'all' | 'human' | 'ai'")
    sort_by: str = Field("aum", alias="sortBy")
    total: int = 0
    page: int = 1
    page_size: int = Field(20, alias="pageSize")
    data_source: Optional[str] = Field(None, alias="dataSource")
    vaults: List[VaultRanking] = Field(default_factory=list)

    model_config = {"populate_by_name": True}
