please i have currently a ui for the chrome extension but i don't like it at all and want to make it polished. remove the current text input with a chat input with rounded corners auto resize and a send button. another thing is empty state should show the reverse-api-engineer logo on the center and then revamp the header part to make it more modern and stylish and polished while getting a minimalist design

now please create or explain the system to save the capture scripts (like the api_client.py) somewhere because otherwise we need to explore the hidden .reverse-api folder and it's annoying (also saved under id), so we need to thing about where to save generated scripts via chrome extension


 please create a file called setup_sprite.py, it will do the following: install uv if not available    
  in the sandbox, do create a folder reverse-api-engineer, enter it, uv init && uv add (the deps        
  needed) and then download the agent_script in the sandbox.  