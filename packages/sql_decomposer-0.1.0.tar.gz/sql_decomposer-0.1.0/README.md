# sql_decomposer

`sql_decomposer` extracts repeated SQL subqueries into temporary tables.
It can help reduce duplication in large analytical queries and produce a more readable SQL script.

## Features

- Parses SQL safely with `sqlglot`.
- Detects repeated `SELECT` subqueries.
- Rewrites repeated blocks to `SELECT * FROM <temp_table>`.
- Provides a Python API and a CLI.

## Installation

From source:

```bash
pip install .
```

From PyPI (after release):

```bash
pip install sql-decomposer
```

## CLI usage

```bash
python -m sql_decomposer input.sql output.sql --min-count 2 --temp-prefix __temp
```

Or with console script:

```bash
sql-decomposer input.sql output.sql
```

Options:

- `--dialect`: optional sqlglot dialect (`postgres`, `mysql`, etc.)
- `--min-count`: minimum repetition count to extract (default: `2`)
- `--temp-prefix`: generated temp table prefix (default: `__temp`)

## Python API

```python
from sql_decomposer import decompose_sql

sql = "SELECT * FROM (SELECT id FROM users) t1 JOIN (SELECT id FROM users) t2 ON t1.id=t2.id"
result = decompose_sql(sql, min_count=2, temp_prefix="tmp")
print(result)
```

## Development

Install dev dependencies:

```bash
pip install -e ".[dev]"
```

Run tests:

```bash
pytest
```

Build artifacts:

```bash
python -m build
```

Validate package metadata:

```bash
twine check dist/*
```

## GitHub and PyPI release checklist

1. Create repository named `sql_decomposer` on GitHub.
2. Push code and enable Actions.
3. Create a PyPI project `sql-decomposer`.
4. Add `PYPI_API_TOKEN` as a GitHub Actions secret.
5. Tag a release (`v0.1.0`) to trigger publish workflow.

## License

MIT License. See `LICENSE`.
