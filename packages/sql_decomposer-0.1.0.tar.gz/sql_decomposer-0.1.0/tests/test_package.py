from pathlib import Path

import pytest

from sql_decomposer import decompose_sql


PROJECT_ROOT = Path(__file__).resolve().parent.parent


def _read(rel_path: str) -> str:
    return (PROJECT_ROOT / rel_path).read_text(encoding="utf-8").strip()


@pytest.mark.parametrize(
    ("input_fixture", "expected_fixture"),
    [
        (
            "tests/sql_big_analytics_query.sql",
            "decomposed_sql/sql_big_analytics_query.sql",
        ),
        (
            "tests/sql_complex_hr_query.sql",
            "decomposed_sql/sql_complex_hr_query.sql",
        ),
        (
            "tests/sql_financial_report_four_repeats.sql",
            "decomposed_sql/sql_financial_report_four_repeats.sql",
        ),
        (
            "tests/sql_flat_query_no_subqueries.sql",
            "decomposed_sql/sql_flat_query_no_subqueries.sql",
        ),
        ("tests/sql_min_count_one.sql", "decomposed_sql/sql_min_count_one.sql"),
        (
            "tests/sql_nested_repeated_subqueries.sql",
            "decomposed_sql/sql_nested_repeated_subqueries.sql",
        ),
        ("tests/sql_no_repetition.sql", "decomposed_sql/sql_no_repetition.sql"),
        (
            "tests/sql_simple_two_identical_subqueries.sql",
            "decomposed_sql/sql_simple_two_identical_subqueries.sql",
        ),
        (
            "tests/sql_triple_repeated_subquery.sql",
            "decomposed_sql/sql_triple_repeated_subquery.sql",
        ),
        (
            "tests/sql_two_different_repeated_subqueries.sql",
            "decomposed_sql/sql_two_different_repeated_subqueries.sql",
        ),
    ],
)
def test_decompose_sql_matches_expected_fixtures(
    input_fixture: str, expected_fixture: str
) -> None:
    sql = _read(input_fixture)
    expected = _read(expected_fixture)
    assert decompose_sql(sql) == expected


def test_decompose_sql_does_not_replace_string_literals() -> None:
    sql = """
        SELECT
            'SELECT id FROM users WHERE active = 1' AS query_text,
            a.id
        FROM (
            SELECT id FROM users WHERE active = 1
        ) AS a
        JOIN (
            SELECT id FROM users WHERE active = 1
        ) AS b ON a.id = b.id
    """
    result = decompose_sql(sql)

    assert (
        "CREATE TEMPORARY TABLE __temp_1 AS SELECT id FROM users WHERE active = 1"
        in result
    )
    assert "'SELECT id FROM users WHERE active = 1' AS query_text" in result
    assert "(SELECT * FROM __temp_1) AS a" in result
    assert "(SELECT * FROM __temp_1) AS b" in result
