import argparse
from pathlib import Path

from sql_decomposer.decomposer import decompose_sql


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="sql_decomposer",
        description="Decompose repeated SQL subqueries and save result to file.",
    )
    parser.add_argument("input", type=Path, help="Path to input .sql file")
    parser.add_argument("output", type=Path, help="Path to output .sql file")
    parser.add_argument(
        "--dialect",
        default=None,
        help='Optional sqlglot dialect (e.g. "postgres", "mysql")',
    )
    parser.add_argument(
        "--min-count",
        type=int,
        default=2,
        help="Minimum repetition count for extraction (default: 2)",
    )
    parser.add_argument(
        "--temp-prefix",
        default="__temp",
        help='Prefix for generated temp tables (default: "__temp")',
    )
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    if not args.input.exists():
        parser.error(f"Input file does not exist: {args.input}")
    if not args.input.is_file():
        parser.error(f"Input path is not a file: {args.input}")

    sql_text = args.input.read_text(encoding="utf-8")
    decomposed = decompose_sql(
        sql=sql_text,
        dialect=args.dialect,
        min_count=args.min_count,
        temp_prefix=args.temp_prefix,
    )

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(decomposed, encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
