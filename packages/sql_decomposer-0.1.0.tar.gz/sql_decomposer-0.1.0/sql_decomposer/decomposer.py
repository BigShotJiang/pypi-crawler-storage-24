"""
SQL Decomposer — extracts repeated subqueries from a SQL statement
into temporary tables, reducing duplication.
"""

import sqlglot
from sqlglot import exp
from typing import Optional


def _collect_sql_frequencies(
    ast: exp.Expression, dialect: Optional[str]
) -> tuple[dict[str, int], set[str]]:
    """Collect SQL string frequencies and SELECT-only SQL strings."""
    sql_counter: dict[str, int] = {}
    select_sqls: set[str] = set()

    for walked in ast.walk():
        node = walked[0] if isinstance(walked, tuple) else walked
        node_sql = node.sql(dialect=dialect)
        if not node_sql:
            continue

        sql_counter[node_sql] = sql_counter.get(node_sql, 0) + 1
        if isinstance(node, exp.Select):
            select_sqls.add(node_sql)

    return sql_counter, select_sqls


def _build_temp_table_map(
    sql_counter: dict[str, int],
    select_sqls: set[str],
    root_sql: str,
    min_count: int,
    temp_prefix: str,
) -> dict[str, str]:
    """
    Build stable mapping: repeated SELECT SQL -> temp table name.

    Ordering is deterministic:
      1) higher repetition count first
      2) longer SQL first (helps nested/repeated patterns)
    """
    sorted_items = sorted(
        sql_counter.items(),
        key=lambda item: (item[1], len(item[0])),
        reverse=True,
    )

    ordered_candidates = [
        sql_key
        for sql_key, count in sorted_items
        if count >= min_count and sql_key != root_sql and sql_key in select_sqls
    ]

    temp_table_map: dict[str, str] = {}
    working_sql = root_sql

    # Keep legacy "longer-first replacement" semantics for candidate filtering:
    # once a larger repeated SELECT is selected, nested candidates it contains
    # may disappear and therefore should not be extracted separately.
    for sql_key in ordered_candidates:
        if sql_key not in working_sql:
            continue

        temp_name = f"{temp_prefix}_{len(temp_table_map) + 1}"
        temp_table_map[sql_key] = temp_name
        working_sql = working_sql.replace(sql_key, f"SELECT * FROM {temp_name}")

    return temp_table_map


def _rewrite_selects_with_temp_tables(
    ast: exp.Expression, dialect: Optional[str], temp_table_map: dict[str, str]
) -> exp.Expression:
    """Replace repeated SELECT nodes with SELECT * FROM <temp_table>."""
    if not temp_table_map:
        return ast

    def _replace(node: exp.Expression) -> exp.Expression:
        if isinstance(node, exp.Select):
            node_sql = node.sql(dialect=dialect)
            temp_name = temp_table_map.get(node_sql)
            if temp_name:
                return exp.select("*").from_(temp_name)
        return node

    return ast.transform(_replace)


def decompose_sql(
    sql: str,
    dialect: Optional[str] = None,
    min_count: int = 2,
    temp_prefix: str = "__temp",
) -> str:
    """
    Decompose a SQL query by extracting repeated sub-SELECT expressions
    into CREATE TEMPORARY TABLE statements.

    Algorithm:
      1. Parse *sql* into an AST via sqlglot.
      2. Walk every node; convert each node back to a SQL string and
         count occurrences in a dictionary.
      3. Regenerate the full SQL from the AST.
      4. Sort the dictionary by count DESC, then by SQL length DESC
         (longer expressions first — avoids partial-substring collisions).
      5-6. For each entry that qualifies (is a SELECT, appears ≥ *min_count*
         times, is not the root query), create a temp-table definition and
         replace the subquery text in the working SQL string.
      7. Append the (possibly rewritten) final SQL.
      8. Return the ordered list of statements.

    Args:
        sql:         Source SQL string.
        dialect:     sqlglot dialect name (e.g. "postgres", "mysql").
        min_count:   Minimum number of occurrences for extraction (default 2).
        temp_prefix: Naming prefix for generated temp tables.

    Returns:
        SQL script as a single string: zero or more CREATE TEMPORARY TABLE
        statements followed by the final (rewritten) query.
    """
    # ── Step 1: parse ────────────────────────────────────────────────
    ast = sqlglot.parse_one(sql, dialect=dialect)

    # ── Step 2: walk all nodes, count SQL representations ────────────
    sql_counter, select_sqls = _collect_sql_frequencies(ast, dialect)

    # ── Step 3: full SQL from AST ────────────────────────────────────
    result_sql = ast.sql(dialect=dialect)

    # ── Step 4: build SELECT->temp table mapping ─────────────────────
    temp_table_map = _build_temp_table_map(
        sql_counter=sql_counter,
        select_sqls=select_sqls,
        root_sql=result_sql,
        min_count=min_count,
        temp_prefix=temp_prefix,
    )

    # ── Steps 5-6: create temp tables and rewrite AST ────────────────
    statements: list[str] = []

    for sql_key, temp_name in temp_table_map.items():
        statements.append(f"CREATE TEMPORARY TABLE {temp_name} AS {sql_key}")

    rewritten_ast = _rewrite_selects_with_temp_tables(ast, dialect, temp_table_map)
    result_sql = rewritten_ast.sql(dialect=dialect)

    # ── Step 7: append final rewritten query ─────────────────────────
    statements.append(result_sql)

    # ── Step 8 ───────────────────────────────────────────────────────
    return "\n".join(statements)
