from sql_decomposer.decomposer import decompose_sql

__version__ = "0.1.0"
__all__ = ["decompose_sql"]
