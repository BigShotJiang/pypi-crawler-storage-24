"""
PyLocket CLI configuration management.

Handles credential storage, loading, and token refresh logic.
Credentials are stored in ~/.pylocket/credentials as a JSON file.
"""
from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
PYLOCKET_DIR = Path.home() / ".pylocket"
CREDENTIALS_FILE = PYLOCKET_DIR / "credentials"
DEFAULT_API_URL = "https://api.pylocket.com"

# Access tokens are refreshed when less than this many seconds remain.
TOKEN_REFRESH_THRESHOLD_SECONDS = 120


# ---------------------------------------------------------------------------
# Credential data
# ---------------------------------------------------------------------------
@dataclass
class Credentials:
    """In-memory representation of stored credentials."""

    access_token: str = ""
    refresh_token: str = ""
    expires_at: float = 0.0  # Unix timestamp
    api_url: str = DEFAULT_API_URL
    email: str = ""

    # ---- helpers ----------------------------------------------------------

    @property
    def is_authenticated(self) -> bool:
        return bool(self.access_token)

    @property
    def is_expired(self) -> bool:
        if not self.access_token:
            return True
        return time.time() >= self.expires_at

    @property
    def needs_refresh(self) -> bool:
        if not self.access_token:
            return True
        return time.time() >= (self.expires_at - TOKEN_REFRESH_THRESHOLD_SECONDS)

    def to_dict(self) -> dict:
        return {
            "access_token": self.access_token,
            "refresh_token": self.refresh_token,
            "expires_at": self.expires_at,
            "api_url": self.api_url,
            "email": self.email,
        }

    @classmethod
    def from_dict(cls, data: dict) -> Credentials:
        return cls(
            access_token=data.get("access_token", ""),
            refresh_token=data.get("refresh_token", ""),
            expires_at=data.get("expires_at", 0.0),
            api_url=data.get("api_url", DEFAULT_API_URL),
            email=data.get("email", ""),
        )


# ---------------------------------------------------------------------------
# Persistence helpers
# ---------------------------------------------------------------------------
def _ensure_config_dir() -> None:
    """Create ~/.pylocket/ with restrictive permissions if it does not exist."""
    PYLOCKET_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)


def save_credentials(creds: Credentials) -> None:
    """Persist credentials to ~/.pylocket/credentials."""
    _ensure_config_dir()
    CREDENTIALS_FILE.write_text(json.dumps(creds.to_dict(), indent=2))
    # Restrict file permissions (owner-only read/write).
    os.chmod(CREDENTIALS_FILE, 0o600)


def load_credentials() -> Credentials:
    """Load credentials from disk. Returns empty Credentials if file missing."""
    if not CREDENTIALS_FILE.exists():
        return Credentials()
    try:
        data = json.loads(CREDENTIALS_FILE.read_text())
        return Credentials.from_dict(data)
    except (json.JSONDecodeError, KeyError, TypeError):
        return Credentials()


def clear_credentials() -> None:
    """Remove stored credentials."""
    if CREDENTIALS_FILE.exists():
        CREDENTIALS_FILE.unlink()


# ---------------------------------------------------------------------------
# API URL resolution
# ---------------------------------------------------------------------------
def resolve_api_url(cli_override: Optional[str] = None) -> str:
    """
    Determine the API URL to use.

    Priority:
      1. Explicit CLI flag (--api-url)
      2. PYLOCKET_API_URL environment variable
      3. Value saved in credentials file
      4. Default (http://localhost:8000)
    """
    if cli_override:
        return cli_override.rstrip("/")

    env_url = os.environ.get("PYLOCKET_API_URL")
    if env_url:
        return env_url.rstrip("/")

    creds = load_credentials()
    if creds.api_url:
        return creds.api_url.rstrip("/")

    return DEFAULT_API_URL


# ---------------------------------------------------------------------------
# Token update helper
# ---------------------------------------------------------------------------
def update_tokens(
    access_token: str,
    refresh_token: str,
    expires_in: int,
    api_url: Optional[str] = None,
    email: Optional[str] = None,
) -> Credentials:
    """
    Update stored credentials with new tokens from the API.

    Parameters
    ----------
    access_token : str
        New JWT access token.
    refresh_token : str
        New refresh token.
    expires_in : int
        Token lifetime in seconds (from API response).
    api_url : str, optional
        Override the stored API URL.
    email : str, optional
        Developer email address.

    Returns
    -------
    Credentials
        The updated credentials object.
    """
    creds = load_credentials()
    creds.access_token = access_token
    creds.refresh_token = refresh_token
    creds.expires_at = time.time() + expires_in
    if api_url:
        creds.api_url = api_url
    if email:
        creds.email = email
    save_credentials(creds)
    return creds
