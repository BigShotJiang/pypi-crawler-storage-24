"""
Direct distribution command for the PyLocket CLI.

    pylocket distribute --app <APP_ID>
"""
from __future__ import annotations

import asyncio
import functools
import sys
from typing import Any, Callable

import click
from rich.console import Console
from rich.panel import Panel

from cli.client import AuthenticationError, PyLocketAPIError, PyLocketClient
from cli.config import resolve_api_url

console = Console()
err_console = Console(stderr=True)


def _async(fn: Callable[..., Any]) -> Callable[..., Any]:
    @functools.wraps(fn)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        return asyncio.run(fn(*args, **kwargs))
    return wrapper


def _handle_error(exc: Exception, api_url: str) -> None:
    if isinstance(exc, AuthenticationError):
        err_console.print(
            Panel(
                "[red]You are not authenticated.[/red]\n"
                "Run [bold cyan]pylocket login[/bold cyan] first.",
                title="[bold red]Authentication Required[/bold red]",
                border_style="red",
            )
        )
        sys.exit(1)
    elif isinstance(exc, PyLocketAPIError):
        err_console.print(
            Panel(
                f"[red]{exc.message}[/red]",
                title=f"[bold red]API Error ({exc.status_code})[/bold red]",
                border_style="red",
            )
        )
        sys.exit(1)
    else:
        err_console.print(
            Panel(
                f"[red]Could not connect to {api_url}:[/red]\n{exc}",
                title="[bold red]Connection Error[/bold red]",
                border_style="red",
            )
        )
        sys.exit(1)


@click.command()
@click.option("--app", "app_id", required=True, help="Application ID.")
@click.pass_context
@_async
async def distribute(ctx: click.Context, app_id: str) -> None:
    """Generate a one-time direct download link for your app.

    The link can be shared with an end user. When they visit the link,
    they fill in their details, download the app, and receive an
    auto-generated license.
    """
    api_url = resolve_api_url(ctx.obj.get("api_url") if ctx.obj else None)
    token = ctx.obj.get("token") if ctx.obj else None

    try:
        async with PyLocketClient(api_url=api_url, token=token) as client:
            with console.status("[bold cyan]Generating download link...[/bold cyan]", spinner="dots"):
                result = await client.create_direct_link(app_id)
    except Exception as exc:
        _handle_error(exc, api_url)
        return

    url = result.get("download_url", result.get("url", ""))
    expires = result.get("expires_at", "")
    if isinstance(expires, str) and "T" in expires:
        expires = expires.split("T")[0]

    console.print()
    console.print(
        Panel(
            f"[green]Download link created![/green]\n\n"
            f"  [bold]URL:[/bold]      [cyan]{url}[/cyan]\n"
            f"  [bold]Expires:[/bold]  {expires or '30 days'}\n\n"
            f"[dim]Share this link with your end user. It is single-use.[/dim]",
            title="[bold green]Direct Distribution[/bold green]",
            border_style="green",
        )
    )
