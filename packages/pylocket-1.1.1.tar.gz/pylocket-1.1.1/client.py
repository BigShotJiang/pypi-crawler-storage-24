"""
PyLocket HTTP client wrapper.

Provides ``PyLocketClient`` -- a thin async wrapper around ``httpx.AsyncClient``
with automatic auth-header injection, exponential-backoff retries, multipart
file uploads, and user-friendly error handling.
"""
from __future__ import annotations

import asyncio
import sys
import time
from pathlib import Path
from typing import Any, Dict, Optional, Sequence

import httpx
from rich.console import Console

from cli.config import (
    Credentials,
    load_credentials,
    resolve_api_url,
    save_credentials,
    update_tokens,
)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
_MAX_RETRIES = 3
_BACKOFF_BASE = 1.0  # seconds
_BACKOFF_FACTOR = 2.0
_RETRYABLE_STATUS_CODES = frozenset({429, 502, 503, 504})
_UPLOAD_CHUNK_SIZE = 8 * 1024 * 1024  # 8 MiB
_DEFAULT_TIMEOUT = httpx.Timeout(30.0, connect=10.0, read=120.0, write=120.0)

console = Console(stderr=True)


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------
class PyLocketAPIError(Exception):
    """Raised when the PyLocket API returns an error response."""

    def __init__(
        self,
        status_code: int,
        code: str = "unknown",
        message: str = "An unknown error occurred.",
        request_id: Optional[str] = None,
    ) -> None:
        self.status_code = status_code
        self.code = code
        self.message = message
        self.request_id = request_id
        super().__init__(f"[{status_code}] {code}: {message}")


class AuthenticationError(PyLocketAPIError):
    """Raised on 401/403 -- the user needs to (re-)authenticate."""


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------
class PyLocketClient:
    """Async HTTP client for the PyLocket API.

    Usage::

        async with PyLocketClient(api_url="https://api.pylocket.dev") as client:
            apps = await client.list_apps()
    """

    def __init__(
        self,
        api_url: Optional[str] = None,
        token: Optional[str] = None,
    ) -> None:
        self._api_url = resolve_api_url(api_url)
        self._explicit_token = token
        self._creds: Optional[Credentials] = None
        self._http: Optional[httpx.AsyncClient] = None

    # -- lifecycle ----------------------------------------------------------

    async def __aenter__(self) -> "PyLocketClient":
        self._http = httpx.AsyncClient(
            base_url=self._api_url,
            timeout=_DEFAULT_TIMEOUT,
            follow_redirects=True,
        )
        self._creds = load_credentials()
        return self

    async def __aexit__(self, *exc: object) -> None:
        if self._http:
            await self._http.aclose()

    # -- auth ---------------------------------------------------------------

    def _auth_headers(self) -> Dict[str, str]:
        """Build the Authorization header from the best available token."""
        token = self._explicit_token
        if not token and self._creds and self._creds.access_token:
            token = self._creds.access_token
        if token:
            return {"Authorization": f"Bearer {token}"}
        return {}

    async def _maybe_refresh_token(self) -> None:
        """Transparently refresh the access token if it is close to expiry."""
        if self._explicit_token:
            return  # User supplied a token explicitly; skip auto-refresh.
        if self._creds is None:
            self._creds = load_credentials()
        if not self._creds.needs_refresh:
            return
        if not self._creds.refresh_token:
            return
        try:
            resp = await self._raw_request(
                "POST",
                "/v1/auth/refresh",
                json={"refresh_token": self._creds.refresh_token},
                _skip_auth=True,
            )
            data = resp.json()
            self._creds = update_tokens(
                access_token=data["access_token"],
                refresh_token=data["refresh_token"],
                expires_in=data["expires_in"],
            )
        except Exception:
            # If refresh fails silently, the next real request will 401 and
            # the user will be asked to log in again.
            pass

    # -- low-level request --------------------------------------------------

    async def _raw_request(
        self,
        method: str,
        path: str,
        *,
        json: Any = None,
        data: Any = None,
        files: Any = None,
        params: Any = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: Optional[httpx.Timeout] = None,
        _skip_auth: bool = False,
    ) -> httpx.Response:
        """Execute a single HTTP request (no retries)."""
        assert self._http is not None, "Client not initialised. Use `async with`."
        merged_headers = {} if _skip_auth else self._auth_headers()
        if headers:
            merged_headers.update(headers)
        return await self._http.request(
            method,
            path,
            json=json,
            data=data,
            files=files,
            params=params,
            headers=merged_headers,
            timeout=timeout or _DEFAULT_TIMEOUT,
        )

    # -- retrying request ---------------------------------------------------

    async def _request(
        self,
        method: str,
        path: str,
        *,
        json: Any = None,
        data: Any = None,
        files: Any = None,
        params: Any = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: Optional[httpx.Timeout] = None,
    ) -> httpx.Response:
        """Execute an HTTP request with automatic retry and error handling."""
        await self._maybe_refresh_token()

        last_exc: Optional[Exception] = None
        for attempt in range(_MAX_RETRIES):
            try:
                resp = await self._raw_request(
                    method,
                    path,
                    json=json,
                    data=data,
                    files=files,
                    params=params,
                    headers=headers,
                    timeout=timeout,
                )
                if resp.status_code < 400:
                    return resp

                # Decide whether to retry or raise immediately.
                if resp.status_code in _RETRYABLE_STATUS_CODES and attempt < _MAX_RETRIES - 1:
                    delay = _BACKOFF_BASE * (_BACKOFF_FACTOR ** attempt)
                    await asyncio.sleep(delay)
                    continue

                # Parse error body
                self._raise_for_status(resp)

            except httpx.TimeoutException as exc:
                last_exc = exc
                if attempt < _MAX_RETRIES - 1:
                    delay = _BACKOFF_BASE * (_BACKOFF_FACTOR ** attempt)
                    await asyncio.sleep(delay)
                    continue
            except httpx.ConnectError as exc:
                last_exc = exc
                if attempt < _MAX_RETRIES - 1:
                    delay = _BACKOFF_BASE * (_BACKOFF_FACTOR ** attempt)
                    await asyncio.sleep(delay)
                    continue

        # All retries exhausted
        if last_exc:
            raise PyLocketAPIError(
                status_code=0,
                code="connection_error",
                message=f"Could not connect to {self._api_url}: {last_exc}",
            )
        # Should never reach here, but satisfy the type checker.
        raise PyLocketAPIError(status_code=0, code="unknown", message="Request failed.")

    @staticmethod
    def _raise_for_status(resp: httpx.Response) -> None:
        """Parse an error response body and raise the appropriate exception."""
        try:
            body = resp.json()
        except Exception:
            body = {}

        error = body.get("error", {})
        code = error.get("code", "api_error")
        message = error.get("message", resp.text or "Unknown error")
        request_id = body.get("request_id")

        if resp.status_code in (401, 403):
            raise AuthenticationError(
                status_code=resp.status_code,
                code=code,
                message=message,
                request_id=request_id,
            )
        raise PyLocketAPIError(
            status_code=resp.status_code,
            code=code,
            message=message,
            request_id=request_id,
        )

    # ======================================================================
    # Public API methods
    # ======================================================================

    # -- Auth --------------------------------------------------------------

    async def login(self, email: str, password: str) -> Dict[str, Any]:
        """Authenticate and return the token payload."""
        resp = await self._raw_request(
            "POST",
            "/v1/auth/login",
            json={"email": email, "password": password},
            _skip_auth=True,
        )
        if resp.status_code >= 400:
            self._raise_for_status(resp)
        return resp.json()

    async def refresh_token(self, refresh_token: str) -> Dict[str, Any]:
        resp = await self._raw_request(
            "POST",
            "/v1/auth/refresh",
            json={"refresh_token": refresh_token},
            _skip_auth=True,
        )
        if resp.status_code >= 400:
            self._raise_for_status(resp)
        return resp.json()

    async def get_profile(self) -> Dict[str, Any]:
        resp = await self._request("GET", "/v1/auth/me")
        return resp.json()

    # -- Apps --------------------------------------------------------------

    async def list_apps(
        self, page: int = 1, page_size: int = 20
    ) -> Dict[str, Any]:
        resp = await self._request(
            "GET",
            "/v1/apps",
            params={"page": page, "page_size": page_size},
        )
        return resp.json()

    async def create_app(
        self,
        name: str,
        platform: str = "python",
        description: Optional[str] = None,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"name": name, "platform": platform}
        if description:
            payload["description"] = description
        resp = await self._request("POST", "/v1/apps", json=payload)
        return resp.json()

    async def get_app(self, app_id: str) -> Dict[str, Any]:
        resp = await self._request("GET", f"/v1/apps/{app_id}")
        return resp.json()

    # -- Builds ------------------------------------------------------------

    async def create_build(
        self,
        app_id: str,
        version: str = "1.0.0",
        python_version: Optional[str] = None,
        platform: Optional[str] = None,
        artifact_type: Optional[str] = None,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"version": version}
        if python_version:
            payload["python_version"] = python_version
        if platform:
            payload["platform"] = platform
        if artifact_type:
            payload["artifact_type"] = artifact_type
        resp = await self._request(
            "POST", f"/v1/apps/{app_id}/builds", json=payload
        )
        return resp.json()

    async def get_build(self, build_id: str, app_id: Optional[str] = None) -> Dict[str, Any]:
        if app_id:
            resp = await self._request("GET", f"/v1/apps/{app_id}/builds/{build_id}")
        else:
            resp = await self._request("GET", f"/v1/builds/{build_id}")
        return resp.json()

    async def list_builds(
        self, app_id: str, page: int = 1, page_size: int = 20
    ) -> Dict[str, Any]:
        resp = await self._request(
            "GET",
            f"/v1/apps/{app_id}/builds",
            params={"page": page, "page_size": page_size},
        )
        return resp.json()

    async def upload_artifact_direct(
        self,
        upload_url: str,
        build_id: str,
        file_path: Path,
        *,
        app_id: str = "",
        on_progress: Any = None,
    ) -> Dict[str, Any]:
        """Upload a source artifact using a presigned S3 URL, then confirm.

        Parameters
        ----------
        upload_url : str
            Presigned S3 upload URL (from create_build response).
        build_id : str
            UUID of the build.
        file_path : Path
            Local path to the file to upload.
        app_id : str
            Application UUID (needed for confirm endpoint).
        on_progress : callable, optional
            Called with ``(bytes_sent, total_bytes)`` during upload.

        Returns
        -------
        dict
            API response body from confirm.
        """
        total = file_path.stat().st_size

        # PUT file directly to S3 via presigned URL
        async with httpx.AsyncClient(
            timeout=httpx.Timeout(30.0, connect=10.0, read=600.0, write=600.0)
        ) as s3_client:
            resp = await s3_client.put(
                upload_url,
                content=file_path.read_bytes(),
                headers={"Content-Type": "application/octet-stream"},
            )
            resp.raise_for_status()

        if on_progress:
            on_progress(total, total)

        # Confirm upload
        confirm_resp = await self._request(
            "POST",
            f"/v1/apps/{app_id}/builds/{build_id}/confirm",
        )
        return confirm_resp.json()

    async def download_artifact(self, build_id: str, app_id: Optional[str] = None) -> Dict[str, Any]:
        """Get a pre-signed download URL for the protected artifact."""
        if app_id:
            resp = await self._request("GET", f"/v1/apps/{app_id}/builds/{build_id}/download")
        else:
            resp = await self._request("GET", f"/v1/builds/{build_id}/download")
        return resp.json()

    async def download_file(
        self,
        url: str,
        dest: Path,
        *,
        on_progress: Any = None,
    ) -> Path:
        """Stream-download a file from *url* to *dest*.

        Parameters
        ----------
        url : str
            Fully-qualified download URL (e.g. a pre-signed S3 URL).
        dest : Path
            Destination file path.
        on_progress : callable, optional
            Called with ``(bytes_downloaded, total_bytes)`` during download.

        Returns
        -------
        Path
            The path to the downloaded file.
        """
        assert self._http is not None
        async with self._http.stream("GET", url, follow_redirects=True) as resp:
            resp.raise_for_status()
            total = int(resp.headers.get("content-length", 0))
            downloaded = 0
            dest.parent.mkdir(parents=True, exist_ok=True)
            with open(dest, "wb") as fh:
                async for chunk in resp.aiter_bytes(chunk_size=_UPLOAD_CHUNK_SIZE):
                    fh.write(chunk)
                    downloaded += len(chunk)
                    if on_progress:
                        on_progress(downloaded, total)
        return dest

    # -- Apps (extended) ---------------------------------------------------

    async def update_app(
        self,
        app_id: str,
        *,
        name: Optional[str] = None,
        platform: Optional[str] = None,
        offline_grace_hours: Optional[int] = None,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {}
        if name is not None:
            payload["name"] = name
        if platform is not None:
            payload["platform"] = platform
        if offline_grace_hours is not None:
            payload["offline_grace_hours"] = offline_grace_hours
        resp = await self._request("PUT", f"/v1/apps/{app_id}", json=payload)
        return resp.json()

    async def delete_app(self, app_id: str) -> Dict[str, Any]:
        resp = await self._request("DELETE", f"/v1/apps/{app_id}")
        if resp.status_code == 204:
            return {"deleted": True}
        return resp.json()

    # -- Licenses ----------------------------------------------------------

    async def list_licenses(
        self, app_id: str, *, status: Optional[str] = None, page: int = 1, page_size: int = 20
    ) -> Dict[str, Any]:
        params: Dict[str, Any] = {"page": page, "page_size": page_size}
        if status:
            params["status"] = status
        resp = await self._request(
            "GET",
            f"/v1/apps/{app_id}/licenses",
            params=params,
        )
        return resp.json()

    async def create_license(
        self,
        app_id: str,
        *,
        email: Optional[str] = None,
        device_limit: int = 2,
        expires: Optional[str] = None,
        license_type: str = "standard",
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "device_limit": device_limit,
            "license_type": license_type,
        }
        if email:
            payload["email"] = email
        if expires:
            payload["expires_at"] = expires
        resp = await self._request("POST", f"/v1/apps/{app_id}/licenses", json=payload)
        return resp.json()

    async def get_license(self, license_key: str) -> Dict[str, Any]:
        resp = await self._request("GET", f"/v1/licenses/{license_key}")
        return resp.json()

    async def revoke_license(self, license_key: str) -> Dict[str, Any]:
        resp = await self._request("POST", f"/v1/licenses/{license_key}/revoke")
        return resp.json()

    async def reset_license_devices(self, license_key: str) -> Dict[str, Any]:
        resp = await self._request("POST", f"/v1/licenses/{license_key}/reset-devices")
        return resp.json()

    async def extend_license(self, license_key: str, expires: str) -> Dict[str, Any]:
        resp = await self._request(
            "PATCH", f"/v1/licenses/{license_key}", json={"expires_at": expires}
        )
        return resp.json()

    # -- Auth (extended) ---------------------------------------------------

    async def rotate_api_key(self) -> Dict[str, Any]:
        resp = await self._request("POST", "/v1/auth/api-keys/rotate")
        return resp.json()

    async def setup_2fa(self) -> Dict[str, Any]:
        resp = await self._request("POST", "/v1/auth/2fa/setup")
        return resp.json()

    async def confirm_2fa(self, code: str) -> Dict[str, Any]:
        resp = await self._request("POST", "/v1/auth/2fa/confirm", json={"code": code})
        return resp.json()

    async def get_2fa_status(self) -> Dict[str, Any]:
        resp = await self._request("GET", "/v1/auth/2fa/status")
        return resp.json()

    async def disable_2fa(self, code: str) -> Dict[str, Any]:
        resp = await self._request("POST", "/v1/auth/2fa/disable", json={"code": code})
        return resp.json()

    # -- Direct Distribution -----------------------------------------------

    async def create_direct_link(self, app_id: str) -> Dict[str, Any]:
        resp = await self._request("POST", f"/v1/apps/{app_id}/direct-links")
        return resp.json()

    # -- Builds (latest) ---------------------------------------------------

    async def get_latest_build(self, app_id: str) -> Dict[str, Any]:
        resp = await self._request(
            "GET", f"/v1/apps/{app_id}/builds", params={"page": 1, "page_size": 1}
        )
        data = resp.json()
        items = data.get("data", data.get("items", []))
        if not items:
            raise PyLocketAPIError(404, "not_found", "No builds found for this app.")
        return items[0]

    # -- Health ------------------------------------------------------------

    async def health(self) -> Dict[str, Any]:
        resp = await self._raw_request("GET", "/v1/health", _skip_auth=True)
        if resp.status_code >= 400:
            self._raise_for_status(resp)
        return resp.json()
