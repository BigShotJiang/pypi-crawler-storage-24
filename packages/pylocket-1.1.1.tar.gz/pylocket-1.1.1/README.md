# PyLocket CLI v1.1.1

Protect and distribute Python applications from the command line.

## Installation

```bash
pip install pylocket
```

Or download platform-specific binaries from your [Developer Portal](https://portal.pylocket.com/cli).

## Supported Python Versions

- Python 3.12
- Python 3.13
- Python 3.14

## Quick Start

```bash
# Authenticate with your PyLocket account
pylocket login

# List your apps
pylocket apps list

# Protect a PyInstaller executable
pylocket protect --app <APP_ID> --artifact dist/myapp.exe

# Check build status
pylocket status --build <BUILD_ID>

# Download the protected artifact
pylocket fetch --build <BUILD_ID> --out ./protected/
```

## Commands

| Command | Description |
|---------|-------------|
| `pylocket login` | Authenticate with your PyLocket account |
| `pylocket apps list` | List all your applications |
| `pylocket apps create` | Create a new application |
| `pylocket protect` | Upload and protect an artifact |
| `pylocket status` | Check build protection status |
| `pylocket fetch` | Download a protected artifact |

## Protection Flow

The CLI uses a **two-step upload** architecture when protecting an artifact:

1. **Create Build** — `POST /v1/apps/{app_id}/builds` sends build metadata and receives a presigned S3 upload URL.
2. **Upload to S3** — The artifact bytes are `PUT` directly to the presigned S3 URL (bypasses the API server).
3. **Confirm Build** — `POST /v1/apps/{app_id}/builds/{build_id}/confirm` tells the backend the upload is complete and triggers the protection pipeline.
4. **Poll Status** — `GET /v1/apps/{app_id}/builds/{build_id}` is polled until the build reaches `ready` or `failed` status. The response includes `progress_percent` and `progress_message` fields computed server-side.
5. **Download** — `GET /v1/apps/{app_id}/builds/{build_id}/download` returns a JSON body with a `download_url` pointing to S3. The CLI then fetches the protected artifact from that URL.

**Key details:**
- Build routes are nested under apps: `/v1/apps/{app_id}/builds/{build_id}` (NOT `/v1/builds/`)
- Login returns `access_token` (not `token`); app listings use a `data` key (not `apps`)
- The S3 presigned URL upload is a raw `PUT` without the API authorization header

## What's New in v1.1.1

- **Real-time progress bar** — the `protect` command now displays a live progress bar with server-computed `progress_percent` and `progress_message` showing each pipeline stage (downloading, scanning, protecting, uploading)
- **Malware rejection handling** — builds flagged by security scanning now display a clear "Build Rejected" message instead of a generic failure
- **API compatibility fixes** — corrected response model alignment with backend (two-step upload flow, presigned S3 URLs, nested build routes)

## Documentation

Full documentation: [docs.pylocket.com](https://docs.pylocket.com)

## Support

- Documentation: https://docs.pylocket.com
- Developer Portal: https://portal.pylocket.com
- Email: support@pylocket.com
