# Copyright (c) 2026 Elmadani SALKA
# Licensed under BSL-1.1. See LICENSE file.
# Commercial use requires a license — contact@halyn.dev

