# Copyright (c) 2026 Elmadani SALKA
# Licensed under BSL-1.1. See LICENSE file.
# Commercial use requires a license — contact@halyn.dev

"""
Halyn Dashboard — Built-in web UI for the MCP Server.

When running halyn-mcp, opening http://localhost:7420 shows this dashboard.
Real-time device status, shield rules, audit chain — all visual.
"""

DASHBOARD_HTML = '''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Halyn Dashboard</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--bg:#0b0d10;--bg2:#13161b;--fg:#e1e4ea;--fg2:#8b919e;--fg3:#5c6370;--accent:#0a6e3f;--accent2:#3ddc84;--red:#ef4444;--border:#1e2330;--font:system-ui,sans-serif;--mono:'Courier New',monospace}
body{background:var(--bg);color:var(--fg);font-family:var(--font);min-height:100vh}
.top{background:var(--bg2);border-bottom:1px solid var(--border);padding:.75rem 1.5rem;display:flex;justify-content:space-between;align-items:center}
.top h1{font-size:1rem;font-weight:600;display:flex;align-items:center;gap:.5rem}
.top h1 span{color:var(--accent2)}
.top .status{font-size:.75rem;color:var(--accent2);font-family:var(--mono);display:flex;align-items:center;gap:.4rem}
.top .dot{width:8px;height:8px;border-radius:50%;background:var(--accent2);animation:pulse 2s infinite}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.3}}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:1px;background:var(--border);margin:0;height:calc(100vh - 49px)}
.panel{background:var(--bg);padding:1rem;overflow-y:auto}
.panel h2{font-size:.8rem;font-weight:600;color:var(--fg2);text-transform:uppercase;letter-spacing:1px;margin-bottom:.75rem;display:flex;align-items:center;gap:.5rem}
.panel h2 .count{background:var(--bg2);color:var(--fg3);font-size:.65rem;padding:2px 6px;border-radius:8px}

/* Chat / Command */
.chat{display:flex;flex-direction:column;height:100%}
.messages{flex:1;overflow-y:auto;padding-bottom:.5rem}
.msg{margin-bottom:.5rem;padding:.5rem .75rem;border-radius:8px;font-size:.82rem;line-height:1.5;max-width:90%}
.msg.user{background:var(--accent);color:#fff;margin-left:auto;border-bottom-right-radius:2px}
.msg.sys{background:var(--bg2);color:var(--fg2);border-bottom-left-radius:2px}
.msg.blocked{background:#2a1215;color:var(--red);border:1px solid #4a1c20}
.msg.ok{background:#0f2318;color:var(--accent2);border:1px solid #1a3a28}
.input-row{display:flex;gap:.5rem;padding-top:.5rem;border-top:1px solid var(--border)}
.input-row input{flex:1;background:var(--bg2);border:1px solid var(--border);color:var(--fg);padding:.6rem .75rem;border-radius:6px;font-size:.82rem;font-family:var(--font);outline:none}
.input-row input:focus{border-color:var(--accent)}
.input-row button{background:var(--accent);color:#fff;border:none;padding:.6rem 1rem;border-radius:6px;font-size:.82rem;cursor:pointer;font-weight:500}
.input-row button:hover{background:var(--accent2);color:#000}

/* Shields */
.shield{background:var(--bg2);border:1px solid var(--border);border-radius:6px;padding:.5rem .75rem;margin-bottom:.4rem;font-family:var(--mono);font-size:.75rem;color:var(--fg2);display:flex;align-items:center;gap:.5rem}
.shield::before{content:"🛡️";font-size:.9rem}

/* Audit */
.audit-entry{display:grid;grid-template-columns:auto 1fr auto auto;gap:.5rem;padding:.4rem 0;border-bottom:1px solid var(--border);font-size:.72rem;font-family:var(--mono);align-items:center}
.audit-entry .time{color:var(--fg3)}
.audit-entry .tool{color:var(--fg)}
.audit-entry .hash{color:var(--fg3);font-size:.65rem}
.audit-entry .badge{padding:1px 6px;border-radius:4px;font-size:.6rem;font-weight:600}
.badge.ok{background:#0f2318;color:var(--accent2)}
.badge.blocked{background:#2a1215;color:var(--red)}

/* Stats */
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:.5rem;margin-bottom:1rem}
.stat{background:var(--bg2);border:1px solid var(--border);border-radius:6px;padding:.75rem;text-align:center}
.stat .v{font-family:var(--mono);font-size:1.5rem;font-weight:700;color:var(--accent2)}
.stat .l{font-size:.65rem;color:var(--fg3);margin-top:.2rem}

@media(max-width:768px){.grid{grid-template-columns:1fr;height:auto}.panel{min-height:50vh}.stats{grid-template-columns:repeat(2,1fr)}}
</style>
</head>
<body>
<div class="top">
  <h1>⬡ <span>Halyn</span> Dashboard</h1>
  <div class="status"><div class="dot"></div> <span id="uptime">connecting...</span></div>
</div>
<div class="grid">
  <!-- LEFT: Chat + Command -->
  <div class="panel">
    <div class="chat">
      <div class="messages" id="msgs">
        <div class="msg sys">Welcome to Halyn. Type a command or talk naturally.<br><br>Try: <code>observe all</code> · <code>shield deny * delete *</code> · <code>status</code> · <code>audit</code></div>
      </div>
      <div class="input-row">
        <input type="text" id="cmd" placeholder="Type a command... (e.g. 'restart nginx on server-01')" autofocus>
        <button onclick="send()">Send</button>
      </div>
    </div>
  </div>
  <!-- RIGHT: Status + Shields + Audit -->
  <div class="panel">
    <div class="stats" id="stats">
      <div class="stat"><div class="v" id="s-nodes">0</div><div class="l">Nodes</div></div>
      <div class="stat"><div class="v" id="s-shields">0</div><div class="l">Shields</div></div>
      <div class="stat"><div class="v" id="s-audit">0</div><div class="l">Audit</div></div>
      <div class="stat"><div class="v" id="s-uptime">0s</div><div class="l">Uptime</div></div>
    </div>
    <h2>🛡️ Shield Rules <span class="count" id="shield-count">0</span></h2>
    <div id="shields"></div>
    <h2 style="margin-top:1rem">📜 Audit Chain <span class="count" id="audit-count">0</span></h2>
    <div id="audit"></div>
  </div>
</div>
<script>
const $ = s => document.getElementById(s);

async function mcp(name, args={}) {
  const r = await fetch('/mcp', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({jsonrpc:'2.0',id:Date.now(),method:'tools/call',params:{name,arguments:args}})
  });
  const d = await r.json();
  return JSON.parse(d.result.content[0].text);
}

function addMsg(text, cls='sys') {
  const d = document.createElement('div');
  d.className = 'msg ' + cls;
  d.innerHTML = text;
  $('msgs').appendChild(d);
  $('msgs').scrollTop = $('msgs').scrollHeight;
}

async function refresh() {
  try {
    const s = await mcp('halyn_status');
    $('s-nodes').textContent = s.nodes;
    $('s-shields').textContent = s.shields;
    $('s-audit').textContent = s.audit_entries;
    $('s-uptime').textContent = s.uptime_seconds + 's';
    $('uptime').textContent = 'v' + s.version + ' · ' + s.uptime_seconds + 's uptime';

    const sh = await mcp('halyn_shield_list');
    $('shield-count').textContent = sh.count;
    $('shields').innerHTML = sh.shields.map(r => '<div class="shield">' + r + '</div>').join('');

    const au = await mcp('halyn_audit', {limit: 20});
    $('audit-count').textContent = au.total;
    $('audit').innerHTML = au.entries.reverse().map(e => {
      const badge = e.result_ok ? '<span class="badge ok">OK</span>' : '<span class="badge blocked">BLOCKED</span>';
      return '<div class="audit-entry"><span class="time">' + e.timestamp.split('T')[1].replace('Z','') + '</span><span class="tool">' + e.tool + '</span>' + badge + '<span class="hash">' + e.hash + '</span></div>';
    }).join('');
  } catch(e) {}
}

async function send() {
  const input = $('cmd');
  const cmd = input.value.trim();
  if (!cmd) return;
  input.value = '';

  addMsg(cmd, 'user');

  const lower = cmd.toLowerCase();

  try {
    if (lower === 'status' || lower === 'state') {
      const s = await mcp('halyn_status');
      addMsg('Nodes: ' + s.nodes + ' · Shields: ' + s.shields + ' · Audit: ' + s.audit_entries + ' · Uptime: ' + s.uptime_seconds + 's', 'ok');
    } else if (lower.startsWith('shield ') || lower.startsWith('deny ') || lower.startsWith('limit ')) {
      const rule = lower.startsWith('shield ') ? cmd.slice(7) : cmd;
      const r = await mcp('halyn_shield_add', {rule});
      if (r.error) { addMsg('Error: ' + r.error, 'blocked'); }
      else { addMsg('Shield added: ' + r.added + ' (total: ' + r.total_shields + ')', 'ok'); }
    } else if (lower === 'shields' || lower === 'rules') {
      const r = await mcp('halyn_shield_list');
      addMsg(r.shields.length ? r.shields.map(s => '🛡️ ' + s).join('<br>') : 'No shields active.', 'sys');
    } else if (lower === 'audit' || lower === 'log' || lower === 'history') {
      const r = await mcp('halyn_audit', {limit: 10});
      const lines = r.entries.map(e => {
        const s = e.result_ok ? '✓' : '✗';
        return s + ' ' + e.timestamp.split('T')[1].replace('Z','') + ' ' + e.tool;
      });
      addMsg(lines.join('<br>') || 'No audit entries yet.', 'sys');
    } else if (lower.startsWith('observe') || lower.startsWith('watch') || lower.startsWith('read')) {
      const node = cmd.split(' ').slice(1).join(' ') || 'all';
      const r = await mcp('halyn_observe', {node});
      addMsg('<pre>' + JSON.stringify(r, null, 2) + '</pre>', 'sys');
    } else if (lower === 'stop' || lower === 'emergency') {
      const r = await mcp('halyn_emergency_stop');
      addMsg('⚠️ ' + r.status, 'blocked');
    } else if (lower === 'nodes' || lower === 'devices') {
      const r = await mcp('halyn_nodes');
      addMsg('<pre>' + JSON.stringify(r, null, 2) + '</pre>', 'sys');
    } else if (lower === 'help') {
      addMsg('Commands:<br>• <b>status</b> — system overview<br>• <b>observe [node]</b> — read device state<br>• <b>shield deny * delete *</b> — add safety rule<br>• <b>shields</b> — list active rules<br>• <b>audit</b> — view action log<br>• <b>nodes</b> — list devices<br>• <b>stop</b> — emergency stop<br>• Or type any action: <i>restart nginx on server-01</i>', 'sys');
    } else {
      // Treat as action on default node
      const parts = cmd.match(/(.+?)\\s+on\\s+(.+)/i);
      const node = parts ? parts[2] : 'default';
      const command = parts ? parts[1] : cmd;
      const r = await mcp('halyn_act', {node, command});
      if (r.blocked) {
        addMsg('🛡️ BLOCKED: ' + r.reason, 'blocked');
      } else {
        addMsg('✓ Executed: ' + command + (node !== 'default' ? ' on ' + node : ''), 'ok');
      }
    }
  } catch(e) {
    addMsg('Error: ' + e.message, 'blocked');
  }

  refresh();
}

$('cmd').addEventListener('keydown', e => { if (e.key === 'Enter') send(); });
refresh();
setInterval(refresh, 5000);
</script>
</body>
</html>'''
