"""
Example FastAPI application instrumented with asgi-runway.

Run:
    uvicorn examples.app:app --reload

Then scrape metrics:
    curl http://localhost:8000/metrics | grep runway

The key metric for autoscaling:
    runway_requests_in_flight — how many requests are actively being processed.
"""

import asyncio

from fastapi import FastAPI

from asgi_runway import setup

app = FastAPI(title="asgi-runway example")

# One-line setup: attaches middleware + /metrics endpoint.
# Use route_groups to get per-workload granularity.
setup(
    app,
    metrics_port=9091,
    include_metrics_route=False,
    route_groups=[
        (r"^/api/infer", "inference"),   # heavy GPU work
        (r"^/api/embed", "embedding"),   # lighter CPU work
    ],
)


@app.get("/api/infer")
async def infer(delay: float = 0.5):
    """Simulate a slow inference request."""
    await asyncio.sleep(delay)
    return {"result": "inference done"}


@app.get("/api/embed")
async def embed(delay: float = 0.05):
    """Simulate a fast embedding request."""
    await asyncio.sleep(delay)
    return {"result": "embedding done"}


@app.get("/healthz")
async def health():
    """Health check — excluded from metrics by default."""
    return {"status": "ok"}
