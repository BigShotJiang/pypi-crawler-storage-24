"""
Locust load test for the asgi-runway example app.

Prerequisites:
    pip install locust

Run (web UI at http://localhost:8089):
    uvicorn examples.app:app --port 8000
    locust -f examples/locustfile.py --host http://localhost:8000

Run headless (50 users, ramp 5/s, run 60s):
    locust -f examples/locustfile.py --host http://localhost:8000 \
        --headless -u 50 -r 5 -t 60s

Watch the metric while the test runs:
    watch -n1 'curl -s localhost:8000/metrics | grep "^runway_requests_in_flight "'
"""

from locust import HttpUser, between, task


class InferenceUser(HttpUser):
    """
    Heavy user — hits the slow inference endpoint.
    Simulates a GPU-bound workload where each request takes ~1s.
    These pile up fast and drive runway_requests_in_flight high.
    """

    weight = 3  # 3x more inference users than embedding users
    wait_time = between(0, 0.2)  # minimal think time = maximum pressure

    @task
    def infer(self):
        self.client.get("/api/infer?delay=1.0", name="/api/infer")


class EmbeddingUser(HttpUser):
    """
    Light user — hits the faster embedding endpoint.
    Simulates a CPU-bound workload that resolves quickly.
    """

    weight = 1
    wait_time = between(0, 0.1)

    @task
    def embed(self):
        self.client.get("/api/embed?delay=0.1", name="/api/embed")
