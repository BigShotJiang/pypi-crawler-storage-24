"""
FastAPI router that exposes the Prometheus /metrics endpoint.
"""

from prometheus_client import CONTENT_TYPE_LATEST, generate_latest

from asgi_runway._metrics import _make_registry

try:
    from fastapi import APIRouter
    from fastapi.responses import Response

    metrics_router = APIRouter(tags=["metrics"])

    @metrics_router.get(
        "/metrics",
        response_class=Response,
        summary="Prometheus metrics",
        description=(
            "Exposes Prometheus metrics. Mount this router on your FastAPI app "
            "to allow Prometheus (or KEDA) to scrape `runway_requests_in_flight` "
            "for pod autoscaling."
        ),
        include_in_schema=False,
    )
    async def get_metrics() -> Response:
        registry = _make_registry()
        data = generate_latest(registry)
        return Response(content=data, media_type=CONTENT_TYPE_LATEST)

except ImportError:  # FastAPI not installed — middleware still works standalone
    metrics_router = None  # type: ignore[assignment]
