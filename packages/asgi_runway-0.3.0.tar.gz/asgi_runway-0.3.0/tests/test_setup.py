"""
Tests for the setup() convenience helper.
"""

from fastapi import FastAPI
from fastapi.testclient import TestClient

from asgi_runway import setup


def test_setup_default_path():
    app = FastAPI()
    setup(app)

    @app.get("/hello")
    def hello():
        return {}

    with TestClient(app) as c:
        c.get("/hello")
        resp = c.get("/metrics")
        assert resp.status_code == 200
        assert "runway_requests_in_flight" in resp.text


def test_setup_custom_path():
    app = FastAPI()
    setup(app, metrics_path="/custom-metrics")

    with TestClient(app) as c:
        resp = c.get("/custom-metrics")
        assert resp.status_code == 200
        assert "runway_requests_in_flight" in resp.text

    # default /metrics should NOT exist
    with TestClient(app) as c:
        resp = c.get("/metrics")
        assert resp.status_code == 404


def test_setup_passes_middleware_kwargs():
    app = FastAPI()
    setup(app, exclude_paths=["/skip"])

    @app.get("/skip")
    def skip():
        return {}

    from asgi_runway import REQUESTS_TOTAL

    from asgi_runway._metrics import APP_NAME

    with TestClient(app) as c:
        before = REQUESTS_TOTAL.labels(app_name=APP_NAME, method="GET", status="200")._value.get()
        c.get("/skip")
        assert REQUESTS_TOTAL.labels(app_name=APP_NAME, method="GET", status="200")._value.get() == before
