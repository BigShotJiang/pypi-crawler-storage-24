"""
Shared test fixtures.

We reset the Prometheus registry's state between tests so metric values
don't bleed across test cases.
"""

import asyncio

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from asgi_runway import RunwayMiddleware, metrics_router


@pytest.fixture()
def app() -> FastAPI:
    """A minimal FastAPI app with asgi-runway instrumentation."""
    _app = FastAPI()
    _app.add_middleware(RunwayMiddleware)
    _app.include_router(metrics_router)

    @_app.get("/hello")
    async def hello():
        return {"message": "hello"}

    @_app.get("/slow")
    async def slow():
        await asyncio.sleep(0.05)
        return {"message": "slow"}

    @_app.get("/error")
    async def error():
        raise RuntimeError("boom")

    return _app


@pytest.fixture()
def client(app: FastAPI) -> TestClient:
    with TestClient(app, raise_server_exceptions=False) as c:
        yield c
