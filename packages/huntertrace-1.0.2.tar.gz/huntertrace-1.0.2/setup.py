from setuptools import setup, find_packages

setup(
    name="huntertrace",
    version="1.0.2",  # Incremented version
    author="Your Name",
    author_email="your.email@example.com",
    description="A forensic analysis system for email threat detection and geolocation.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/huntertrace",  # Repository URL
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
    install_requires=[
        "requests",
        "geoip2",
        "networkx",
        "dnspython",
    ],
    entry_points={
        "console_scripts": [
            "huntertrace=huntertrace.hunterTraceV3:main",
        ],
    },
)