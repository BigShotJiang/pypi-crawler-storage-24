<table>
  <tr>
    <td><img src="assets/hunterTraceLogo.png" alt="HunterTrace Logo" width="120" /></td>
    <td>
      <h1>Geo Location Analyzer and Attacker Identification System</h1>
    </td>
  </tr>
</table>

![Python](https://img.shields.io/badge/Python-3.8+-blue?logo=python&logoColor=white)
![License](https://img.shields.io/badge/License-MIT-green)
![Security](https://img.shields.io/badge/Security-Forensics-red)
![Threat Intel](https://img.shields.io/badge/Threat-Intelligence-orange)
![OSINT](https://img.shields.io/badge/OSINT-Tool-purple)

# HunterTrace

HunterTrace is a forensic analysis system designed to identify attackers and analyze email threats. It provides capabilities for tracing real attacker IPs, detecting VPN/proxy obfuscation, correlating campaigns, and generating detailed reports. The system integrates geolocation enrichment and threat intelligence to provide actionable insights for cybersecurity professionals.

## Features
- Accurate identification of real attacker IPs.
- Geolocation enrichment using GeoIP2.
- Campaign correlation to uncover larger attack patterns.
- Detailed reports in JSON, HTML, and GraphML formats.

## Installation

You can install HunterTrace via pip:
```bash
pip install huntertrace
```

## Usage

To run HunterTrace in batch mode:
```bash
huntertrace --mode batch --input /path/to/emails --output /path/to/reports
```

### Example
```bash
huntertrace --mode batch --input ./mails/emails50 --output ./reports/emailpypireport
```

## Requirements
- Python 3.7+
- Dependencies listed in `requirements.txt`.

## Development

To set up the development environment:
```bash
# Clone the repository
https://github.com/yourusername/huntertrace.git

# Navigate to the project directory
cd huntertrace

# Install dependencies
pip install -r requirements.txt
```

## License

This project is licensed under the MIT License. See the LICENSE file for details.
