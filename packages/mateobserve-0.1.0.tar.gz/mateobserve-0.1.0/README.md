# MateObserve SDK 🧉

Simple API observability middleware for FastAPI / Starlette.

## Install

```bash
pip install mateobserve
```

## Quick Start

```python
from fastapi import FastAPI
from mateobserve import ObserveMiddleware

app = FastAPI()
app.add_middleware(ObserveMiddleware)
```

That's it — your API is now sending latency, error, and traffic metrics to MateObserve.

## Configuration

All settings are optional. By default, the SDK sends metrics to `http://localhost:8001`.

| Variable | Default | Description |
|----------|---------|-------------|
| `MATEOBSERVE_SERVICE_NAME` | auto-detected | Name of your service |
| `MATEOBSERVE_COLLECTOR_URL` | `http://localhost:8001` | Collector URL |
| `MATEOBSERVE_API_KEY` | *(empty)* | API key for authentication |
| `MATEOBSERVE_ENABLED` | `true` | Enable/disable collection |

## CLI

The package includes a CLI to manage the observability stack:

```bash
mateobserve up       # Start the stack (Docker Compose)
mateobserve down     # Stop the stack
mateobserve status   # Show running containers
mateobserve doctor   # Check environment readiness
```

## Links

- [Documentation](https://github.com/TobiasVeiga00/mateobserve)
- [Source](https://github.com/TobiasVeiga00/mateobserve)
- [Issues](https://github.com/TobiasVeiga00/mateobserve/issues)
