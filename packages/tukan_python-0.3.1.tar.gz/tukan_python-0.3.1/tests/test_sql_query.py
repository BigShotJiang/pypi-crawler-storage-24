import base64

import pandas as pd
import pytest
from unittest.mock import patch, MagicMock

from tukan_python.query import SQLQuery
from tukan_python.tukan import Tukan


# --- Initialization ---


@patch.object(Tukan, "__init__", return_value=None)
def test_sql_query_init_with_sql(mock_init):
    sq = SQLQuery(sql="SELECT 1")
    assert sq.sql == "SELECT 1"


@patch.object(Tukan, "__init__", return_value=None)
def test_sql_query_init_without_sql(mock_init):
    sq = SQLQuery()
    assert sq.sql is None


@patch.object(Tukan, "__init__", return_value=None)
def test_set_sql(mock_init):
    sq = SQLQuery()
    sq.set_sql("SELECT * FROM table")
    assert sq.sql == "SELECT * FROM table"


# --- Base64 encoding ---


@patch.object(Tukan, "__init__", return_value=None)
def test_encode_sql(mock_init):
    sq = SQLQuery(sql="SELECT 1")
    encoded = sq._encode_sql()
    decoded = base64.b64decode(encoded).decode("utf-8")
    assert decoded == "SELECT 1"


@patch.object(Tukan, "__init__", return_value=None)
def test_encode_sql_unicode(mock_init):
    sq = SQLQuery(sql="SELECT * FROM tabla WHERE nombre = 'México'")
    encoded = sq._encode_sql()
    decoded = base64.b64decode(encoded).decode("utf-8")
    assert "México" in decoded


@patch.object(Tukan, "__init__", return_value=None)
def test_encode_sql_raises_when_no_sql(mock_init):
    sq = SQLQuery()
    with pytest.raises(ValueError, match="SQL query not set"):
        sq._encode_sql()


# --- Payload ---


@patch.object(Tukan, "__init__", return_value=None)
def test_build_payload_no_offset(mock_init):
    sq = SQLQuery(sql="SELECT 1")
    payload = sq._build_payload()
    assert "raw_sql" in payload
    assert "offset" not in payload
    assert base64.b64decode(payload["raw_sql"]).decode("utf-8") == "SELECT 1"


@patch.object(Tukan, "__init__", return_value=None)
def test_build_payload_with_offset(mock_init):
    sq = SQLQuery(sql="SELECT 1")
    payload = sq._build_payload(offset=100)
    assert payload["offset"] == 100
    assert "raw_sql" in payload


# --- Execution (mocked) ---


@patch.object(Tukan, "__init__", return_value=None)
@patch.object(Tukan, "execute_post_operation")
def test_execute_single_page(mock_post, mock_init):
    mock_post.return_value = {
        "data": [{"col1": "a", "col2": 1}, {"col1": "b", "col2": 2}],
        "has_more_data": False,
    }

    sq = SQLQuery(sql="SELECT col1, col2 FROM table")
    result = sq.execute()

    assert isinstance(result["df"], pd.DataFrame)
    assert len(result["df"]) == 2
    assert len(result["data"]) == 2
    assert result["data"][0]["col1"] == "a"


@patch.object(Tukan, "__init__", return_value=None)
@patch.object(Tukan, "execute_post_operation")
def test_execute_with_pagination(mock_post, mock_init):
    mock_post.side_effect = [
        {"data": [{"id": 1}, {"id": 2}], "has_more_data": True},
        {"data": [{"id": 3}], "has_more_data": False},
    ]

    sq = SQLQuery(sql="SELECT id FROM table")
    result = sq.execute()

    assert len(result["df"]) == 3
    assert len(result["data"]) == 3
    assert mock_post.call_count == 2
    # Verify offset was passed in the second call
    second_call_payload = mock_post.call_args_list[1][0][0]
    assert second_call_payload["offset"] == 2


@patch.object(Tukan, "__init__", return_value=None)
@patch.object(Tukan, "execute_post_operation")
def test_execute_empty_result(mock_post, mock_init):
    mock_post.return_value = {"data": [], "has_more_data": False}

    sq = SQLQuery(sql="SELECT 1 WHERE 1=0")
    result = sq.execute()

    assert len(result["df"]) == 0
    assert result["data"] == []


# --- API validation errors ---


@patch.object(Tukan, "__init__", return_value=None)
@patch.object(Tukan, "execute_post_operation")
def test_execute_raises_on_validation_error(mock_post, mock_init):
    mock_post.return_value = {
        "detail": "Raw SQL validation failed: Query must start with SELECT or WITH (for CTEs)"
    }

    sq = SQLQuery(sql="DROP TABLE users")
    with pytest.raises(ValueError, match="Raw SQL validation failed"):
        sq.execute()


@patch.object(Tukan, "__init__", return_value=None)
@patch.object(Tukan, "execute_post_operation")
def test_execute_raises_on_pagination_error(mock_post, mock_init):
    mock_post.side_effect = [
        {"data": [{"id": 1}], "has_more_data": True},
        {"detail": "Some server error"},
    ]

    sq = SQLQuery(sql="SELECT id FROM table")
    with pytest.raises(ValueError, match="Some server error"):
        sq.execute()


# --- String representation ---


@patch.object(Tukan, "__init__", return_value=None)
def test_str(mock_init):
    sq = SQLQuery(sql="SELECT 1")
    assert "SELECT 1" in str(sq)
    assert "SELECT 1" in repr(sq)


# --- Tukan.sql() convenience ---


@patch.object(Tukan, "execute_post_operation")
def test_tukan_sql_convenience(mock_post):
    mock_post.return_value = {"data": [{"x": 1}], "has_more_data": False}

    t = Tukan.__new__(Tukan)
    t.token = "test_token"
    t.env = "https://client.tukanmx.com/"
    result = t.sql("SELECT x FROM table")

    assert isinstance(result["df"], pd.DataFrame)
    assert len(result["data"]) == 1
    # Verify the endpoint used
    call_args = mock_post.call_args
    assert call_args[0][1] == "data/retrieve/?engine=blizzard"


# --- Endpoint ---


def test_endpoint_includes_engine_param():
    assert SQLQuery.ENDPOINT == "data/retrieve/?engine=blizzard"


# --- _from_tukan classmethod ---


def test_from_tukan():
    t = Tukan.__new__(Tukan)
    t.token = "test"
    t.env = "https://client.tukanmx.com/"

    sq = SQLQuery._from_tukan(t, "SELECT 1")
    assert sq.tukan is t
    assert sq.sql == "SELECT 1"
