"""TUI widgets."""
