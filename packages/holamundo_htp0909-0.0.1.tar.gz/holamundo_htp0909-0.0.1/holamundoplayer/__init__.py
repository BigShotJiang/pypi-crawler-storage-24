"""Doc String
Esta es la documentación del paquete
"""
