import os

import pytest

from vcti.path.file_id_utils import FileId


class TestFileIdIsValid:
    """Tests for FileId.is_valid."""

    def test_simple_filename(self):
        assert FileId.is_valid("file.txt") is True

    def test_nested_path(self):
        assert FileId.is_valid("scripts/setup.sh") is True

    def test_deeply_nested(self):
        assert FileId.is_valid("a/b/c/d.txt") is True

    def test_empty_string_invalid(self):
        assert FileId.is_valid("") is False

    def test_whitespace_only_invalid(self):
        assert FileId.is_valid("   ") is False

    def test_absolute_path_invalid(self):
        assert FileId.is_valid("/absolute/path") is False

    def test_dot_slash_prefix_invalid(self):
        assert FileId.is_valid("./relative") is False

    def test_dotdot_slash_prefix_invalid(self):
        assert FileId.is_valid("../parent") is False

    def test_trailing_slash_valid(self):
        assert FileId.is_valid("folder/") is True

    def test_name_with_illegal_chars_invalid(self):
        assert FileId.is_valid("bad|name") is False

    def test_name_with_colon_invalid(self):
        assert FileId.is_valid("bad:name") is False

    def test_backslash_path_invalid(self):
        assert FileId.is_valid("folder\\file.txt") is False

    @pytest.mark.parametrize("invalid_input", [None, 123, b"bytes", ["list"]])
    def test_non_string_raises_type_error(self, invalid_input):
        with pytest.raises(TypeError, match="file_id must be a str"):
            FileId.is_valid(invalid_input)


class TestFileIdValidate:
    """Tests for FileId.validate."""

    def test_valid_raises_nothing(self):
        FileId.validate("scripts/run.sh")  # Should not raise

    def test_invalid_raises_value_error(self):
        with pytest.raises(ValueError, match="Invalid file ID"):
            FileId.validate("/absolute")

    def test_empty_raises_value_error(self):
        with pytest.raises(ValueError):
            FileId.validate("")


class TestFileIdResolvePath:
    """Tests for FileId.resolve_path."""

    def test_none_returns_base_dir(self, tmp_path):
        result = FileId.resolve_path(None, tmp_path)
        assert result == tmp_path

    def test_empty_string_returns_base_dir(self, tmp_path):
        result = FileId.resolve_path("", tmp_path)
        assert result == tmp_path

    def test_resolves_relative_id(self, tmp_path):
        result = FileId.resolve_path("subdir/file.txt", tmp_path)
        assert result == tmp_path / "subdir" / "file.txt"

    def test_must_exist_raises_if_missing(self, tmp_path):
        with pytest.raises(FileNotFoundError):
            FileId.resolve_path("nonexistent.txt", tmp_path, must_exist=True)

    def test_must_exist_passes_if_file_exists(self, tmp_path):
        f = tmp_path / "real.txt"
        f.write_text("data")
        result = FileId.resolve_path("real.txt", tmp_path, must_exist=True)
        assert result == f

    def test_must_be_file_raises_for_dir(self, tmp_path):
        d = tmp_path / "mydir"
        d.mkdir()
        with pytest.raises(IsADirectoryError):
            FileId.resolve_path("mydir", tmp_path, must_be_file=True)

    def test_must_be_dir_raises_for_file(self, tmp_path):
        f = tmp_path / "file.txt"
        f.write_text("data")
        with pytest.raises(NotADirectoryError):
            FileId.resolve_path("file.txt", tmp_path, must_be_dir=True)

    def test_invalid_file_id_raises_value_error(self, tmp_path):
        with pytest.raises(ValueError):
            FileId.resolve_path("/absolute", tmp_path)

    # Note: Windows junctions/reparse points are not tested
    @pytest.mark.skipif(os.name != "posix", reason="POSIX symlinks only")
    def test_symlink_raises_runtime_error(self, tmp_path):
        target = tmp_path / "real.txt"
        target.write_text("data")
        link = tmp_path / "link.txt"
        link.symlink_to(target)
        with pytest.raises(RuntimeError, match="Symbolic links are not supported"):
            FileId.resolve_path("link.txt", tmp_path)


class TestFileIdGetFileId:
    """Tests for FileId.get_file_id."""

    def test_file_returns_posix_id(self, tmp_path):
        f = tmp_path / "data.txt"
        f.write_text("x")
        result = FileId.get_file_id(f, tmp_path)
        assert result == "data.txt"

    def test_nested_file_returns_posix_id(self, tmp_path):
        sub = tmp_path / "sub"
        sub.mkdir()
        f = sub / "file.txt"
        f.write_text("x")
        result = FileId.get_file_id(f, tmp_path)
        assert result == "sub/file.txt"

    def test_directory_returns_trailing_slash(self, tmp_path):
        d = tmp_path / "mydir"
        d.mkdir()
        result = FileId.get_file_id(d, tmp_path)
        assert result == "mydir/"

    def test_base_dir_itself_returns_empty(self, tmp_path):
        result = FileId.get_file_id(tmp_path, tmp_path)
        assert result == ""

    def test_outside_base_dir_raises(self, tmp_path):
        outside = tmp_path.parent / "other.txt"
        with pytest.raises(ValueError, match="not under base directory"):
            FileId.get_file_id(outside, tmp_path)

    def test_non_path_file_path_raises_type_error(self, tmp_path):
        with pytest.raises(TypeError, match="file_path must be a Path"):
            FileId.get_file_id("string/path", tmp_path)

    def test_non_path_base_dir_raises_type_error(self, tmp_path):
        with pytest.raises(TypeError, match="base_dir must be a Path"):
            FileId.get_file_id(tmp_path, "/string/base")
