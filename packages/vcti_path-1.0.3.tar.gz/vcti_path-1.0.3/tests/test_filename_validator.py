import re

import pytest

import vcti.path
from vcti.path.filename_validator import FileNameValidator


class TestVersion:
    """Tests for package version metadata."""

    def test_version_exists(self):
        assert hasattr(vcti.path, "__version__")

    def test_version_is_valid_semver(self):
        assert re.match(r"^\d+\.\d+\.\d+", vcti.path.__version__)


class TestPublicAPI:
    """Tests that all public symbols are re-exported from vcti.path."""

    @pytest.mark.parametrize(
        "symbol",
        [
            "FileNameValidator",
            "FileId",
            "abs_path",
            "validate_file_access",
            "validate_folder_access",
            "resolve_path",
        ],
    )
    def test_public_symbol_exported(self, symbol):
        assert hasattr(vcti.path, symbol)
        assert symbol in vcti.path.__all__


class TestFileNameValidatorIsValid:
    """Tests for FileNameValidator.is_valid."""

    def test_valid_simple_name(self):
        assert FileNameValidator.is_valid("file.txt") is True

    def test_valid_name_no_extension(self):
        assert FileNameValidator.is_valid("myfile") is True

    def test_valid_name_with_spaces(self):
        assert FileNameValidator.is_valid("my file.txt") is True

    def test_valid_name_with_underscores_dashes(self):
        assert FileNameValidator.is_valid("my-file_name.txt") is True

    def test_empty_string_invalid(self):
        assert FileNameValidator.is_valid("") is False

    def test_whitespace_only_invalid(self):
        assert FileNameValidator.is_valid("   ") is False

    def test_dot_reserved_invalid(self):
        assert FileNameValidator.is_valid(".") is False

    def test_dotdot_reserved_invalid(self):
        assert FileNameValidator.is_valid("..") is False

    @pytest.mark.parametrize("char", ["/", "\\", ":", "*", "?", '"', "<", ">", "|"])
    def test_illegal_characters_invalid(self, char):
        assert FileNameValidator.is_valid(f"file{char}name") is False

    def test_valid_hidden_file_unix(self):
        assert FileNameValidator.is_valid(".hidden") is True

    def test_valid_numeric_name(self):
        assert FileNameValidator.is_valid("12345") is True

    @pytest.mark.parametrize("invalid_input", [None, 123, b"bytes", ["list"]])
    def test_non_string_raises_type_error(self, invalid_input):
        with pytest.raises(TypeError, match="name must be a str"):
            FileNameValidator.is_valid(invalid_input)


class TestFileNameValidatorValidate:
    """Tests for FileNameValidator.validate."""

    def test_valid_name_no_exception(self):
        FileNameValidator.validate("data.json")  # Should not raise

    def test_empty_raises_value_error(self):
        with pytest.raises(ValueError, match="Invalid file or directory name"):
            FileNameValidator.validate("")

    def test_dot_raises_value_error(self):
        with pytest.raises(ValueError):
            FileNameValidator.validate(".")

    def test_illegal_char_raises_value_error(self):
        with pytest.raises(ValueError):
            FileNameValidator.validate("bad/name")

    def test_dotdot_raises_value_error(self):
        with pytest.raises(ValueError):
            FileNameValidator.validate("..")
