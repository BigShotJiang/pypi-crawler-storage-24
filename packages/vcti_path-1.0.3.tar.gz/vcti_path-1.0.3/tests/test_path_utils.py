import os
from pathlib import Path
from unittest.mock import patch

import pytest

from vcti.path.path_utils import (
    abs_path,
    resolve_path,
    validate_file_access,
    validate_folder_access,
)


class TestPathUtils:
    """Test cases for path utility functions."""

    @pytest.fixture(autouse=True)
    def setup_teardown(self, tmp_path):
        """Create temporary files and directories for testing."""
        self.test_dir = tmp_path / "test_directory"
        self.test_dir.mkdir()

        self.test_file = tmp_path / "test_file.txt"
        self.test_file.write_text("Sample content")

        self.non_existent_path = tmp_path / "non_existent.txt"
        self.subdir = self.test_dir / "subdir"
        self.subdir.mkdir()

        # Store original permissions to restore later
        self.original_mode = self.test_file.stat().st_mode
        yield  # This is where the testing happens

        # Restore original permissions (in case they were modified)
        self.test_file.chmod(self.original_mode)

    def test_abs_path_with_str(self):
        """Test absolute path resolution with string input."""
        relative_path = str(self.test_file)
        result = abs_path(relative_path)
        assert result == Path(relative_path).resolve()
        assert isinstance(result, Path)

    def test_abs_path_with_path(self):
        """Test absolute path resolution with Path object input."""
        result = abs_path(self.test_file)
        assert result == self.test_file.resolve()
        assert isinstance(result, Path)

    def test_validate_file_access_valid(self):
        """Test validate_file_access with valid file."""
        validate_file_access(self.test_file)  # Should not raise

    def test_validate_file_access_non_existent(self):
        """Test validate_file_access with non-existent file."""
        with pytest.raises(FileNotFoundError):
            validate_file_access(self.non_existent_path)

    def test_validate_file_access_is_directory(self):
        """Test validate_file_access with directory."""
        with pytest.raises(IsADirectoryError):
            validate_file_access(self.test_dir)

    # Note: Windows ACL-based permission testing is beyond scope
    @pytest.mark.skipif(os.name != "posix", reason="POSIX permissions only")
    def test_validate_file_access_no_permission(self):
        """Test validate_file_access with unreadable file (POSIX only)."""
        self.test_file.chmod(0o000)  # Remove all permissions
        with pytest.raises(PermissionError):
            validate_file_access(self.test_file)

    def test_validate_folder_access_valid(self):
        """Test validate_folder_access with valid directory."""
        validate_folder_access(self.test_dir)  # Should not raise

    def test_validate_folder_access_non_existent(self):
        """Test validate_folder_access with non-existent directory."""
        with pytest.raises(FileNotFoundError):
            validate_folder_access(self.non_existent_path)

    def test_validate_folder_access_not_directory(self):
        """Test validate_folder_access with file."""
        with pytest.raises(NotADirectoryError):
            validate_folder_access(self.test_file)

    @pytest.mark.parametrize(
        "path_input",
        [
            b"bytes_path",  # bytes input
            123,  # integer input
        ],
    )
    def test_abs_path_with_wrong_types(self, path_input):
        """Test abs_path with unusual input types."""
        with pytest.raises(TypeError):
            abs_path(path_input)

    @patch("pathlib.Path.exists", return_value=True)
    @patch("pathlib.Path.is_file", return_value=True)
    @patch("vcti.path.path_utils.os.access")
    def test_validate_file_access_mocked(self, mock_access, mock_is_file, mock_exists):
        """Test validate_file_access with mocked permissions."""
        mock_access.return_value = True  # Readable
        validate_file_access("any_path")  # Should pass with mocked permissions

        mock_access.return_value = False  # Not readable
        with pytest.raises(PermissionError):
            validate_file_access("any_path")

    # Note: Windows junctions/reparse points are not tested
    @pytest.mark.skipif(os.name != "posix", reason="POSIX symlinks only")
    def test_symlink_valid_target(self):
        """Test validate_file_access follows symlink to valid target."""
        symlink_path = self.test_dir / "symlink.txt"
        symlink_path.symlink_to(self.test_file)
        validate_file_access(symlink_path)

    @pytest.mark.skipif(os.name != "posix", reason="POSIX symlinks only")
    def test_symlink_broken_raises_file_not_found(self):
        """Test validate_file_access raises for broken symlink."""
        broken_symlink = self.test_dir / "broken_symlink"
        broken_symlink.symlink_to("nonexistent_target")
        with pytest.raises(FileNotFoundError):
            validate_file_access(broken_symlink)

    def test_resolve_path_absolute(self, tmp_path):
        """Test resolve_path with absolute path input."""
        abs_test_file = self.test_file.resolve()
        result = resolve_path(abs_test_file, tmp_path)
        assert result == abs_test_file

    def test_resolve_path_relative(self, tmp_path):
        """Test resolve_path with relative path input."""
        rel_path = "test_directory/subdir"
        result = resolve_path(rel_path, tmp_path)
        expected = (tmp_path / rel_path).resolve()
        assert result == expected

    def test_resolve_path_with_str_input(self, tmp_path):
        """Test resolve_path with string inputs."""
        result = resolve_path("test_file.txt", str(tmp_path))
        expected = (tmp_path / "test_file.txt").resolve()
        assert result == expected

    def test_resolve_path_invalid_base(self):
        """Test resolve_path with non-existent base path."""
        with pytest.raises(FileNotFoundError):
            resolve_path("any_path", "/non/existent/base")

    def test_resolve_path_base_not_dir(self, tmp_path):
        """Test resolve_path when base path is not a directory."""
        with pytest.raises(NotADirectoryError):
            resolve_path("any_path", self.test_file)

    def test_resolve_path_dot_dot(self, tmp_path):
        """Test resolve_path with parent directory references."""
        result = resolve_path("../test_file.txt", self.subdir)
        expected = (self.test_dir / "test_file.txt").resolve()
        assert result == expected

    def test_resolve_path_empty_path(self, tmp_path):
        """Test resolve_path with empty path string."""
        result = resolve_path("", tmp_path)
        assert result == tmp_path.resolve()

    def test_resolve_path_dot(self, tmp_path):
        """Test resolve_path with '.' path."""
        result = resolve_path(".", tmp_path)
        assert result == tmp_path.resolve()

    def test_resolve_path_relative_to_cwd(self, tmp_path, monkeypatch):
        """Test that relative paths without base_path use cwd."""
        monkeypatch.chdir(tmp_path)
        rel_path = "test_file.txt"
        result = resolve_path(rel_path, ".")
        expected = (tmp_path / rel_path).resolve()
        assert result == expected

    @pytest.mark.parametrize(
        "invalid_input",
        [
            None,
            123,
            b"bytes_path",
        ],
    )
    def test_resolve_path_invalid_types(self, invalid_input, tmp_path):
        """Test resolve_path with invalid input types."""
        with pytest.raises(TypeError):
            resolve_path(invalid_input, tmp_path)
        with pytest.raises(TypeError):
            resolve_path("valid_path", invalid_input)
