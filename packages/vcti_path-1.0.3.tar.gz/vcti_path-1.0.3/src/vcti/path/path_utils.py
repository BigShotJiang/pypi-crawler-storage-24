# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Utility functions for handling file and folder paths."""

import errno
import os
from pathlib import Path


def abs_path(fp: Path | str) -> Path:
    """
    Converts a given file path to an absolute, resolved `Path` object.

    Args:
        fp: The input file path.

    Returns:
        Path: The absolute resolved file path.
    """
    return Path(fp).resolve()


def validate_file_access(fp: Path | str) -> None:
    """
    Validates that the specified file path exists and is a readable file.

    Args:
        fp: The file path to validate.

    Raises:
        FileNotFoundError: If the file does not exist.
        IsADirectoryError: If the path points to a directory instead of a file.
        PermissionError: If the file exists but is not readable.
    """
    path = Path(fp)

    if not path.exists():
        raise FileNotFoundError(errno.ENOENT, os.strerror(errno.ENOENT), str(path))

    if path.is_dir():
        raise IsADirectoryError(errno.EISDIR, os.strerror(errno.EISDIR), str(path))

    if not path.is_file():
        raise FileNotFoundError(errno.ENOENT, os.strerror(errno.ENOENT), str(path))

    if not os.access(path, os.R_OK):
        raise PermissionError(errno.EACCES, os.strerror(errno.EACCES), str(path))


def validate_folder_access(fp: Path | str) -> None:
    """
    Validates that the specified folder path exists and is a directory.

    Args:
        fp: The folder path to validate.

    Raises:
        FileNotFoundError: If the directory does not exist.
        NotADirectoryError: If the path is not a directory.
    """
    path = Path(fp)

    if not path.exists():
        raise FileNotFoundError(errno.ENOENT, os.strerror(errno.ENOENT), str(path))

    if not path.is_dir():
        raise NotADirectoryError(errno.ENOTDIR, os.strerror(errno.ENOTDIR), str(path))


def resolve_path(path: Path | str, base_dir: Path | str) -> Path:
    """
    Resolves a path relative to a base directory, handling both absolute and relative paths.

    Args:
        path: The path to resolve (absolute or relative)
        base_dir: The base directory for relative path resolution

    Returns:
        Path: The fully resolved absolute path

    Raises:
        FileNotFoundError: If the base_dir does not exist
        NotADirectoryError: If base_dir is not a directory

    Note:
        This function does not prevent directory traversal via ``..``.
        For untrusted input that must stay within a base directory, use
        ``FileId.resolve_path`` which validates the path format first.
    """
    if not isinstance(path, (str, Path)):
        raise TypeError(f"path must be a str or Path, got {type(path).__name__}")
    if not isinstance(base_dir, (str, Path)):
        raise TypeError(f"base_dir must be a str or Path, got {type(base_dir).__name__}")

    path = Path(path) if isinstance(path, str) else path
    base_dir = Path(base_dir) if isinstance(base_dir, str) else base_dir

    # Resolve the path
    if not path.is_absolute():
        validate_folder_access(base_dir)
        path = base_dir / path

    return path.resolve()


__all__ = [
    "abs_path",
    "validate_file_access",
    "validate_folder_access",
    "resolve_path",
]
