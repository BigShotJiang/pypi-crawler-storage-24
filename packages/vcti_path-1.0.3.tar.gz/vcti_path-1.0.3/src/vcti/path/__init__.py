# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Safe path handling for VCollab applications.

Provides filename validation, file identity (POSIX-style relative paths
as stable IDs), and path resolution with access validation.
"""

from importlib.metadata import version

from .file_id_utils import FileId
from .filename_validator import FileNameValidator
from .path_utils import abs_path, resolve_path, validate_file_access, validate_folder_access

__version__ = version("vcti-path")

__all__ = [
    "__version__",
    "FileNameValidator",
    "FileId",
    "abs_path",
    "validate_file_access",
    "validate_folder_access",
    "resolve_path",
]
