# Contributing

Thank you for your interest in contributing to belt-tensioning-opencv!

## Getting Started

1. Fork and clone the repository
2. Install [mise](https://mise.jdx.dev/) if you don't have it
3. Run setup:

```bash
mise install
```

Or manually without mise:

```bash
uv sync --all-extras
uv run pre-commit install --install-hooks
uv run pre-commit install --hook-type commit-msg
```

## Development Workflow

### Branching

- Create feature branches from `main`
- Use descriptive branch names: `feat/roi-autodetect`, `fix/fft-window`

### Commits

This project enforces [Conventional Commits](https://www.conventionalcommits.org/):

```text
feat(cv): add ROI auto-detection
fix(capture): handle camera timeout gracefully
docs: update calibration instructions
```

Types: `feat`, `fix`, `docs`, `chore`, `refactor`, `test`, `style`, `ci`, `perf`

### Signed-off-by (DCO)

All commits **must** include a `Signed-off-by` trailer to certify the
[Developer Certificate of Origin](https://developercertificate.org/). Use the `-s` flag:

```bash
git commit -s -m "feat(cv): add ROI auto-detection"
```

This adds a line like:

```text
Signed-off-by: Your Name <your.email@example.com>
```

To configure git to sign off automatically, add a `prepare-commit-msg` hook or use `-s` on every commit.

### Signed Commits (Optional, Preferred)

Cryptographic commit signing (GPG or SSH) is optional but preferred:

```bash
# GPG signing
git config --global commit.gpgsign true
git config --global user.signingkey <YOUR_GPG_KEY_ID>

# Or SSH signing
git config --global gpg.format ssh
git config --global user.signingkey ~/.ssh/id_ed25519.pub
git config --global commit.gpgsign true
```

### Running Checks Locally

```bash
# Lint and format
uv run ruff check .
uv run ruff format .

# Type check
uv run mypy src/

# Tests
uv run pytest

# Run all pre-commit hooks
uv run pre-commit run --all-files
```

### Pull Requests

- Title: conventional commit format
- Body sections: `### Summary`, `### Changes`, `### Testing`
- PRs must pass all CI checks (pre-commit, lint, type-check, test)
- All commits must have `Signed-off-by` trailers (enforced by CI)
- Target the `main` branch

## Coding Standards

See [CODING_STANDARDS.md](CODING_STANDARDS.md) for full details on types, docstrings,
comments, linting, and testing conventions.

## Releases

Releases are automated via [python-semantic-release](https://python-semantic-release.readthedocs.io/).
Merging to `main` triggers automatic version bumps based on conventional commit types:

- `fix:` -> patch (0.0.x)
- `feat:` -> minor (0.x.0)
- `feat!:` or `BREAKING CHANGE:` -> major (x.0.0)
