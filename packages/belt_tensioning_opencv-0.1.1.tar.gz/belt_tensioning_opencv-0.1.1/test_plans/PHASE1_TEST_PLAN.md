# Phase 1 Test Plan — `belt_cv_capture.py`

## Scope

Validate the camera capture and FFT frequency detection pipeline in isolation.
No Klipper, no stepper excitation, no strobe. Belt plucked manually.
Ground truth provided by a phone belt tension app (Smart Tension or equivalent).

## Target Hardware

> **Before running any test, confirm your target machine:**
>
> ```shell
> read -p "Target machine hostname or IP (e.g. voron.local): " TARGET
> ssh pi@$TARGET "uname -a && python3 --version && ls /dev/video*"
> ```
>
> All commands below assume you are SSH'd into the Pi or running directly on it.
> Record the machine name in results — exposure values are environment-specific
> and will differ between machines and enclosure lighting conditions.

---

## Camera Configuration

`belt_cv_capture.py` must expose all camera tuning values as CLI flags
with fallback to a config file. No camera parameters are hardcoded.

### Required Flags

| Flag | Default | Description |
|---|---|---|
| `--device` | `/dev/video0` | V4L2 device path |
| `--fps` | `120` | Target framerate |
| `--frames` | `120` | Frames to capture per measurement |
| `--width` | `1280` | Capture width (pixels) |
| `--height` | `720` | Capture height (pixels) |
| `--auto-exposure` | `1` | `CAP_PROP_AUTO_EXPOSURE` value (`1`=manual, `3`=auto on V4L2) |
| `--exposure` | `-6` | `CAP_PROP_EXPOSURE` value (log2 seconds, V4L2 range typically -13 to -1) |
| `--belt` | required | `A` or `B` |
| `--roi` | `0,0,0,0` | `x1,y1,x2,y2` pixels (`0,0,0,0` = full frame) |
| `--verbose` | off | Print debug info to stderr |
| `--dump-intensities` | off | Write intensity time series to named CSV file |

### Config File

Flags can also be set in `~/.belt_tension_cv.conf` or
`./belt_tension_cv.conf` (project dir takes precedence):

```ini
# belt_tension_cv.conf
device = /dev/video0
fps = 120
frames = 120
auto_exposure = 1
exposure = -6
```

CLI flags override config file values. This allows per-machine tuning
without modifying code or re-running calibration from scratch.

### Exposure Notes

`CAP_PROP_AUTO_EXPOSURE` behaviour is V4L2-driver-specific:

- `1` = manual on most UVC drivers
- `3` = aperture-priority auto on some drivers

Verify the actual effect on your Pi with:

```shell
v4l2-ctl -d /dev/video0 --list-ctrls | grep -i exposure
```

`CAP_PROP_EXPOSURE` is in log2(seconds) units on V4L2 — `-6` = 1/64s.
Start at `-6` and adjust based on T3 results.
Record the working value in your machine's config file, not in code.

---

## Prerequisites

```shell
# On the Pi:
sudo apt install v4l-utils python3-opencv python3-numpy

# Verify camera connected
v4l2-ctl --list-devices

# Verify Python packages
python3 -c "import cv2, numpy; print(cv2.__version__, numpy.__version__)"

# Ground truth app on phone
# iOS: Sound Spectrum Analysis, GyroCam, or Spectroid
# Android: Physics Toolbox, Spectroid
```

---

## Tests

### T1 — Camera Enumeration

**Goal:** Camera detected, reports expected capabilities.

```shell
v4l2-ctl --list-devices
v4l2-ctl -d /dev/video0 --list-formats-ext | grep -A5 "MJPG"
```

**Pass:**

- `/dev/video0` (or similar) present
- MJPEG format available at 1280×720 @ 120fps

**Fail signals:**

- No `/dev/video*` — camera not detected; check USB, try `dmesg | tail -20`
- Only 30fps listed — driver not exposing high-speed modes;
  try `--width 1280 --height 720` explicitly in capture

**Record:** Actual device path (may not be `/dev/video0` if other cameras present).

---

### T2 — Frame Capture and Actual FPS

**Goal:** Camera delivers close to claimed framerate.

```shell
python3 belt_cv_capture.py \
  --device /dev/video0 \
  --fps 120 \
  --frames 120 \
  --belt A \
  --verbose
```

**Pass:** `fps_actual` in JSON output is 114–122 (within 5% of 120).

**Fail signals:**

- `fps_actual` ~30 — camera defaulted to 30fps YUYV instead of MJPEG;
  add explicit format forcing via V4L2 backend:

  ```python
  cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG'))
  ```

- `fps_actual` ~60 — USB 2.0 bandwidth limit at full resolution;
  try `--width 640 --height 480` which allows higher fps on USB 2.0

**Record:** `fps_actual` value for this machine.

---

### T3 — Auto-Exposure Disabled (Stable Intensity)

**Goal:** Intensity signal is flat with belt stationary.
Auto-exposure fluctuation corrupts the FFT signal.

```shell
python3 belt_cv_capture.py \
  --device /dev/video0 \
  --fps 120 \
  --frames 120 \
  --belt A \
  --auto-exposure 1 \
  --exposure -6 \
  --dump-intensities stationary.csv \
  --verbose
```

Inspect the output:

```shell
python3 - << 'EOF'
import csv, statistics
with open('stationary.csv') as f:
    vals = [float(r[0]) for r in csv.reader(f)]
print(f"mean={statistics.mean(vals):.2f}  stdev={statistics.stdev(vals):.4f}  "
      f"range={max(vals)-min(vals):.4f}")
EOF
```

**Pass:** `stdev` < 1.0 across all frames.

**Fail signals:**

- Intensity slowly drifting over time — auto-exposure still active;
  try `--auto-exposure 3` (some V4L2 drivers invert the value meaning);
  verify with `v4l2-ctl -d /dev/video0 --get-ctrl=auto_exposure`
- Large spikes at regular intervals — electrical interference or LED flicker
  at mains frequency (50 Hz in EU); note this for T4

**Record:** Working `--auto-exposure` and `--exposure` values for this machine.
Write them to `~/.belt_tension_cv.conf` once confirmed.

---

### T4 — FFT Noise Floor (No Motion)

**Goal:** No spurious frequency peak with belt stationary.

```shell
python3 belt_cv_capture.py \
  --device /dev/video0 \
  --fps 120 \
  --frames 120 \
  --belt A \
  --roi 200,100,600,400
```

**Pass:** `confidence` < 0.2.

**Fail signals:**

- Peak near 50 Hz — mains LED flicker in ROI;
  reposition camera or change lighting; add notch filter at 50 Hz as fallback
- Peak near 25 Hz — second harmonic of mains flicker
- Consistent spurious peak — something else moving in ROI (fan, enclosure door);
  tighten ROI or exclude that region

**Record:** Any persistent noise frequencies to exclude or filter.

---

### T5 — Known Frequency Detection (Core Validation)

**Goal:** FFT output matches phone app ground truth within tolerance.

**Setup:**

1. Open phone belt tension app
2. Position phone microphone near belt
3. Pluck belt firmly
4. Note frequency reading from phone app — this is ground truth
5. Immediately run capture while belt is still ringing

```shell
python3 belt_cv_capture.py \
  --device /dev/video0 \
  --fps 120 \
  --frames 120 \
  --belt A \
  --roi 200,100,600,400
```

**Repeat 5 times.** Record each result:

| Run | Phone (Hz) | Script (Hz) | Delta | Confidence | Pass? |
|-----|-----------|-------------|-------|------------|-------|
| 1   |           |             |       |            |       |
| 2   |           |             |       |            |       |
| 3   |           |             |       |            |       |
| 4   |           |             |       |            |       |
| 5   |           |             |       |            |       |

**Pass per run:** `frequency_hz` within ±3 Hz of phone reading, `confidence` > 0.6.
**Pass overall:** At least 4 of 5 runs pass, std dev of script readings < 2 Hz.

**Fail signals:**

- Returns ~half the expected frequency → only detecting 2nd harmonic;
  add a low-frequency floor filter (ignore peaks below 50 Hz)
- Returns ~double → FFT picking harmonic over fundamental;
  take lowest significant peak above noise floor rather than highest amplitude peak
- Confidence always low despite visible belt motion →
  ROI doesn't contain enough of the belt; widen ROI
- Results inconsistent run to run → belt damping too fast;
  increase `--frames` to 240 to capture more of the ring-down

**Record:** Mean delta vs phone, std dev, working ROI coordinates.

---

### T6 — ROI vs Full Frame

**Goal:** Confirm tight ROI improves signal quality over full frame.
Informational — does not block Phase 1 completion.

Run the same pluck twice in quick succession:

```shell
# Full frame
python3 belt_cv_capture.py --device /dev/video0 --fps 120 --frames 120 --belt A

# Tight ROI
python3 belt_cv_capture.py --device /dev/video0 --fps 120 --frames 120 \
  --belt A --roi 200,100,600,400
```

| Mode | frequency_hz | confidence |
|------|-------------|------------|
| Full frame | | |
| ROI | | |

**Expected:** ROI version has equal or higher confidence.
**Note:** If full frame performs equally, ROI is still preferred — lower CPU cost
on Pi 5 means faster iteration in Phase 3 when stepper excitation is running concurrently.

---

### T7 — Frequency Range Coverage

**Goal:** Detection works across the expected tuning range.

> **Note on Nyquist:** At 120fps, the Nyquist limit is 60 Hz. Belt frequencies
> of 110–140 Hz exceed this. Direct detection at these frequencies **requires
> the strobe to be active** (Phase 4) — the camera sees the aliased apparent
> frequency `|f_belt - f_strobe|` which falls in the low-Hz range.
>
> For Phase 1 (no strobe), test at frequencies the camera can detect directly:
> use a longer belt span or lower tension to bring the resonant frequency
> below 60 Hz. Alternatively, test with a guitar string where tension is
> adjustable across a wider range.
>
> Record these results as a baseline. Revisit at full target range in Phase 4.

| Tension state | Span (mm) | Expected Hz | Detected Hz | Delta | Pass? |
|---|---|---|---|---|---|
| Very loose | 150 | ~30–50 Hz | | | |
| Medium | 150 | ~50–60 Hz | | | |
| Note: above 60 Hz requires strobe — Phase 4 | | | | | |

**Pass:** Detected within ±5 Hz across tested range.

**Record:** Lowest reliable detection frequency. Any aliasing artefacts observed.

---

### T8 — JSON Output Schema

**Goal:** Output is valid JSON matching the expected contract.

```shell
python3 belt_cv_capture.py \
  --device /dev/video0 --fps 120 --frames 120 --belt A \
  | python3 - << 'EOF'
import json, sys
d = json.load(sys.stdin)
required = ['belt', 'frequency_hz', 'amplitude', 'confidence',
            'fps_actual', 'frames_captured']
missing = [k for k in required if k not in d]
if missing:
    print(f"FAIL — missing keys: {missing}")
    sys.exit(1)
assert isinstance(d['frequency_hz'], float), "frequency_hz must be float"
assert 0.0 <= d['confidence'] <= 1.0, "confidence must be 0.0–1.0"
assert d['frames_captured'] > 0, "frames_captured must be positive"
print("PASS — schema valid")
print(json.dumps(d, indent=2))
EOF
```

**Pass:** Prints `PASS — schema valid`, no assertion errors.

---

### T9 — Error Handling

**Goal:** Graceful failure with correct exit codes and human-readable errors.

```shell
# Wrong device
python3 belt_cv_capture.py --device /dev/video99 --fps 120 --frames 120 --belt A
echo "Exit code: $?"
# Expected: exit 1, stderr message mentioning device, no Python traceback

# ROI outside frame bounds
python3 belt_cv_capture.py --device /dev/video0 --fps 120 --frames 10 \
  --belt A --roi 9000,9000,9999,9999
echo "Exit code: $?"
# Expected: exit 2, stderr message mentioning ROI bounds

# Invalid belt name
python3 belt_cv_capture.py --device /dev/video0 --fps 120 --frames 10 --belt C
echo "Exit code: $?"
# Expected: exit 1, stderr message mentioning valid values A/B
```

**Pass:** Non-zero exit codes, human-readable message on stderr, no raw Python
tracebacks visible to the caller (wrap in `try/except` at top level).

---

## Pass Criteria — Phase 1 Complete

| Test | Required | Notes |
|------|----------|-------|
| T1 | ✓ Must pass | Camera must be functional |
| T2 | ✓ Must pass | fps_actual within 5% |
| T3 | ✓ Must pass | Stable intensity; working exposure values recorded to config |
| T4 | ✓ Must pass | No spurious peaks |
| T5 | ✓ Must pass | ≥4/5 runs within ±3 Hz of ground truth |
| T6 | — Informational | Record results |
| T7 | — Informational | Record results; full range tested in Phase 4 |
| T8 | ✓ Must pass | Schema contract must be stable before Klipper integration |
| T9 | ✓ Must pass | Required for safe subprocess invocation from Klipper extra |

---

## Results Record

```text
Date:
Machine (hostname/IP):
OS:
Python version:
OpenCV version:
Camera device path:
Working --auto-exposure value:
Working --exposure value:
Config written to:
fps_actual achieved:
T5 mean delta vs phone (Hz):
T5 std dev (Hz):
Working ROI coordinates:
Notes:
```

Save completed results as `PHASE1_RESULTS_<hostname>.md` in the repo.
These feed directly into the default config values for Phase 2.
