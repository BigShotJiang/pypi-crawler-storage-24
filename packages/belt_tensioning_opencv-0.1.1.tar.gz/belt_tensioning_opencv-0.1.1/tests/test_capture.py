"""Tests for the CLI capture entry point."""

from __future__ import annotations

import json
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from belt_tensioning_opencv.capture import build_parser, parse_roi, run


class TestParseRoi:
    def test_valid_roi(self) -> None:
        assert parse_roi("200,100,600,400") == (200, 100, 600, 400)

    def test_zero_roi(self) -> None:
        assert parse_roi("0,0,0,0") == (0, 0, 0, 0)

    def test_strips_whitespace(self) -> None:
        assert parse_roi("10, 20, 30, 40") == (10, 20, 30, 40)

    def test_rejects_wrong_count(self) -> None:
        with pytest.raises(Exception, match="4 values"):
            parse_roi("1,2,3")

    def test_rejects_non_integer(self) -> None:
        with pytest.raises(Exception, match="integers"):
            parse_roi("1.5,2,3,4")


class TestBuildParser:
    def test_defaults(self) -> None:
        parser = build_parser()
        args = parser.parse_args([])
        assert args.device == "/dev/video0"
        assert args.fps == 120
        assert args.frames == 120
        assert args.belt == "A"
        assert args.roi == (0, 0, 0, 0)

    def test_custom_args(self) -> None:
        parser = build_parser()
        args = parser.parse_args(
            [
                "--device",
                "/dev/video1",
                "--fps",
                "60",
                "--frames",
                "240",
                "--belt",
                "B",
                "--roi",
                "10,20,30,40",
            ]
        )
        assert args.device == "/dev/video1"
        assert args.fps == 60
        assert args.frames == 240
        assert args.belt == "B"
        assert args.roi == (10, 20, 30, 40)


class TestRun:
    @patch("belt_tensioning_opencv.capture.open_camera")
    @patch("belt_tensioning_opencv.capture.capture_intensities")
    @patch("belt_tensioning_opencv.capture.find_peak_frequency")
    def test_produces_valid_result(self, mock_fft: Any, mock_capture: Any, mock_open: Any) -> None:
        mock_cap = MagicMock()
        mock_open.return_value = mock_cap
        mock_capture.return_value = ([100.0] * 120, 119.5)
        mock_fft.return_value = (120.3, 0.55, 0.9)

        parser = build_parser()
        args = parser.parse_args(["--belt", "A"])
        result = run(args)

        assert result.belt == "A"
        assert result.frequency_hz == 120.3
        assert result.confidence == 0.9
        assert result.fps_actual == 119.5
        assert result.frames_captured == 120
        mock_cap.release.assert_called_once()

    @patch("belt_tensioning_opencv.capture.open_camera")
    @patch("belt_tensioning_opencv.capture.capture_intensities")
    def test_releases_camera_on_capture_error(self, mock_capture: Any, mock_open: Any) -> None:
        mock_cap = MagicMock()
        mock_open.return_value = mock_cap
        mock_capture.side_effect = Exception("test error")

        parser = build_parser()
        args = parser.parse_args([])

        with pytest.raises(Exception, match="test error"):
            run(args)
        mock_cap.release.assert_called_once()

    @patch("belt_tensioning_opencv.capture.open_camera")
    @patch("belt_tensioning_opencv.capture.capture_intensities")
    @patch("belt_tensioning_opencv.capture.find_peak_frequency")
    def test_result_is_valid_json(self, mock_fft: Any, mock_capture: Any, mock_open: Any) -> None:
        mock_open.return_value = MagicMock()
        mock_capture.return_value = ([100.0] * 60, 60.0)
        mock_fft.return_value = (94.2, 0.42, 0.87)

        parser = build_parser()
        args = parser.parse_args(["--frames", "60", "--belt", "B"])
        result = run(args)

        parsed = json.loads(result.to_json())
        assert parsed["belt"] == "B"
        assert parsed["frequency_hz"] == 94.2
