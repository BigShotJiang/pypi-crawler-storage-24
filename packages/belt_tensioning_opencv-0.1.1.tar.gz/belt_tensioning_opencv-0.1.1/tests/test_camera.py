"""Tests for camera module using mocked OpenCV."""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock, patch

import numpy as np
import pytest

from belt_tensioning_opencv.camera import capture_intensities, open_camera
from belt_tensioning_opencv.errors import CameraError


class TestOpenCamera:
    @patch("belt_tensioning_opencv.camera.cv2")
    def test_opens_device_successfully(self, mock_cv2: Any) -> None:
        mock_cap = MagicMock()
        mock_cap.isOpened.return_value = True
        mock_cap.get.return_value = 120.0
        mock_cv2.VideoCapture.return_value = mock_cap
        mock_cv2.CAP_V4L2 = 200

        cap = open_camera("/dev/video0", fps=120)

        mock_cv2.VideoCapture.assert_called_once_with("/dev/video0", 200)
        assert cap is mock_cap

    @patch("belt_tensioning_opencv.camera.cv2")
    def test_raises_on_failed_open(self, mock_cv2: Any) -> None:
        mock_cap = MagicMock()
        mock_cap.isOpened.return_value = False
        mock_cv2.VideoCapture.return_value = mock_cap
        mock_cv2.CAP_V4L2 = 200

        with pytest.raises(CameraError, match="Cannot open camera"):
            open_camera("/dev/video99", fps=120)

    @patch("belt_tensioning_opencv.camera.cv2")
    def test_sets_manual_exposure(self, mock_cv2: Any) -> None:
        mock_cap = MagicMock()
        mock_cap.isOpened.return_value = True
        mock_cap.get.return_value = 120.0
        mock_cv2.VideoCapture.return_value = mock_cap
        mock_cv2.CAP_V4L2 = 200
        mock_cv2.CAP_PROP_AUTO_EXPOSURE = 21
        mock_cv2.CAP_PROP_EXPOSURE = 15
        mock_cv2.CAP_PROP_FRAME_WIDTH = 3
        mock_cv2.CAP_PROP_FRAME_HEIGHT = 4
        mock_cv2.CAP_PROP_FPS = 5

        open_camera("/dev/video0", fps=120, exposure=-4)

        # Verify manual exposure was set (value 1 for V4L2 manual mode)
        mock_cap.set.assert_any_call(21, 1)
        mock_cap.set.assert_any_call(15, -4)


class TestCaptureIntensities:
    def _make_mock_cap(self, n_frames: int, frame_value: int = 128) -> MagicMock:
        """Create a mock VideoCapture that returns constant grayscale frames."""
        mock_cap = MagicMock()
        frame = np.full((720, 1280, 3), frame_value, dtype=np.uint8)
        mock_cap.read.return_value = (True, frame)
        return mock_cap

    @patch("belt_tensioning_opencv.camera.cv2")
    def test_captures_correct_number_of_frames(self, mock_cv2: Any) -> None:
        mock_cv2.COLOR_BGR2GRAY = 6
        mock_cv2.cvtColor.side_effect = lambda f, _: f[:, :, 0]

        mock_cap = self._make_mock_cap(10, frame_value=100)
        intensities, fps = capture_intensities(mock_cap, roi=(0, 0, 0, 0), n_frames=10)

        assert len(intensities) == 10
        assert fps > 0

    @patch("belt_tensioning_opencv.camera.cv2")
    def test_extracts_roi_region(self, mock_cv2: Any) -> None:
        mock_cv2.COLOR_BGR2GRAY = 6

        frame = np.zeros((720, 1280, 3), dtype=np.uint8)
        frame[100:400, 200:600, :] = 200  # bright region in ROI

        mock_cap = MagicMock()
        mock_cap.read.return_value = (True, frame)
        mock_cv2.cvtColor.side_effect = lambda f, _: f[:, :, 0]

        intensities, _ = capture_intensities(mock_cap, roi=(200, 100, 600, 400), n_frames=1)
        assert intensities[0] == pytest.approx(200.0)

    @patch("belt_tensioning_opencv.camera.cv2")
    def test_raises_on_capture_failure(self, mock_cv2: Any) -> None:
        mock_cap = MagicMock()
        mock_cap.read.return_value = (False, None)

        with pytest.raises(CameraError, match="Frame capture failed"):
            capture_intensities(mock_cap, roi=(0, 0, 0, 0), n_frames=5)
