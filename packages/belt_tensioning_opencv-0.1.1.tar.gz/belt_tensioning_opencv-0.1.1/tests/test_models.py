"""Tests for measurement result models."""

from __future__ import annotations

import json

from belt_tensioning_opencv.models import MeasurementResult


class TestMeasurementResult:
    def test_to_dict(self) -> None:
        result = MeasurementResult(
            belt="A",
            frequency_hz=94.2,
            amplitude=0.42,
            confidence=0.87,
            fps_actual=119.6,
            frames_captured=120,
        )
        d = result.to_dict()
        assert d["belt"] == "A"
        assert d["frequency_hz"] == 94.2
        assert d["amplitude"] == 0.42
        assert d["confidence"] == 0.87
        assert d["fps_actual"] == 119.6
        assert d["frames_captured"] == 120

    def test_to_json(self) -> None:
        result = MeasurementResult(
            belt="B",
            frequency_hz=121.4,
            amplitude=0.55,
            confidence=0.92,
            fps_actual=120.0,
            frames_captured=240,
        )
        parsed = json.loads(result.to_json())
        assert parsed["belt"] == "B"
        assert parsed["frequency_hz"] == 121.4
        assert parsed["frames_captured"] == 240

    def test_json_roundtrip_fields(self) -> None:
        result = MeasurementResult(
            belt="A",
            frequency_hz=110.0,
            amplitude=1.0,
            confidence=0.5,
            fps_actual=119.0,
            frames_captured=100,
        )
        parsed = json.loads(result.to_json())
        expected_keys = {"belt", "frequency_hz", "amplitude", "confidence", "fps_actual", "frames_captured"}
        assert set(parsed.keys()) == expected_keys
