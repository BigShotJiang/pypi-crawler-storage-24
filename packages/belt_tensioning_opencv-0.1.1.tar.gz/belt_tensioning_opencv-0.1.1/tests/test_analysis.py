"""Tests for FFT-based frequency analysis."""

from __future__ import annotations

import math

import numpy as np
import pytest

from belt_tensioning_opencv.analysis import find_peak_frequency
from belt_tensioning_opencv.errors import AnalysisError


def _generate_sine_signal(freq_hz: float, fps: float, n_frames: int, noise_std: float = 0.0) -> list[float]:
    """Generate a synthetic sine wave intensity signal."""
    t = np.arange(n_frames) / fps
    signal = np.sin(2 * np.pi * freq_hz * t)
    if noise_std > 0:
        rng = np.random.default_rng(42)
        signal = signal + rng.normal(0, noise_std, n_frames)
    return list(signal.tolist())


class TestFindPeakFrequency:
    def test_detects_known_frequency(self) -> None:
        signal = _generate_sine_signal(freq_hz=120.0, fps=500.0, n_frames=500)
        freq, _amp, _confidence = find_peak_frequency(signal, fps=500.0)
        assert abs(freq - 120.0) < 2.0

    def test_detects_low_frequency(self) -> None:
        signal = _generate_sine_signal(freq_hz=30.0, fps=120.0, n_frames=240)
        freq, _, _ = find_peak_frequency(signal, fps=120.0)
        assert abs(freq - 30.0) < 1.0

    def test_high_confidence_for_clean_signal(self) -> None:
        signal = _generate_sine_signal(freq_hz=100.0, fps=500.0, n_frames=500)
        _, _, confidence = find_peak_frequency(signal, fps=500.0)
        assert confidence > 0.5

    def test_lower_confidence_with_noise(self) -> None:
        clean = _generate_sine_signal(freq_hz=100.0, fps=500.0, n_frames=500)
        noisy = _generate_sine_signal(freq_hz=100.0, fps=500.0, n_frames=500, noise_std=2.0)
        _, _, conf_clean = find_peak_frequency(clean, fps=500.0)
        _, _, conf_noisy = find_peak_frequency(noisy, fps=500.0)
        assert conf_clean > conf_noisy

    def test_still_detects_frequency_with_moderate_noise(self) -> None:
        signal = _generate_sine_signal(freq_hz=110.0, fps=500.0, n_frames=500, noise_std=0.5)
        freq, _, _ = find_peak_frequency(signal, fps=500.0)
        assert abs(freq - 110.0) < 3.0

    def test_rejects_too_few_samples(self) -> None:
        with pytest.raises(AnalysisError, match="Too few samples"):
            find_peak_frequency([1.0, 2.0, 3.0], fps=120.0)

    def test_different_sample_rates(self) -> None:
        for fps in [60.0, 120.0, 240.0]:
            signal = _generate_sine_signal(freq_hz=25.0, fps=fps, n_frames=int(fps * 2))
            freq, _, _ = find_peak_frequency(signal, fps=fps)
            assert abs(freq - 25.0) < 2.0

    def test_returns_positive_amplitude(self) -> None:
        signal = _generate_sine_signal(freq_hz=80.0, fps=500.0, n_frames=500)
        _, amp, _ = find_peak_frequency(signal, fps=500.0)
        assert amp > 0

    def test_frequency_resolution_improves_with_more_frames(self) -> None:
        freq_target = 115.0
        fps = 500.0

        short_signal = _generate_sine_signal(freq_hz=freq_target, fps=fps, n_frames=100)
        long_signal = _generate_sine_signal(freq_hz=freq_target, fps=fps, n_frames=1000)

        freq_short, _, _ = find_peak_frequency(short_signal, fps=fps)
        freq_long, _, _ = find_peak_frequency(long_signal, fps=fps)

        error_short = abs(freq_short - freq_target)
        error_long = abs(freq_long - freq_target)
        assert error_long <= error_short + 0.1

    def test_detects_frequency_near_nyquist(self) -> None:
        fps = 120.0
        freq_target = 55.0  # well below Nyquist (60 Hz) but high relative to fps
        signal = _generate_sine_signal(freq_hz=freq_target, fps=fps, n_frames=480)
        freq, _, _ = find_peak_frequency(signal, fps=fps)
        assert abs(freq - freq_target) < 2.0

    def test_dc_offset_does_not_affect_result(self) -> None:
        fps = 500.0
        t = np.arange(500) / fps
        signal_no_offset: list[float] = np.sin(2 * np.pi * 100.0 * t).tolist()
        signal_with_offset: list[float] = (np.sin(2 * np.pi * 100.0 * t) + 500.0).tolist()

        freq1, _, _ = find_peak_frequency(signal_no_offset, fps=fps)
        freq2, _, _ = find_peak_frequency(signal_with_offset, fps=fps)
        assert abs(freq1 - freq2) < 0.1


class TestEdgeCases:
    def test_constant_signal(self) -> None:
        signal = [128.0] * 64
        _freq, amp, confidence = find_peak_frequency(signal, fps=120.0)
        assert amp < 1e-6 or confidence < 0.1

    def test_minimum_valid_samples(self) -> None:
        signal = _generate_sine_signal(freq_hz=10.0, fps=120.0, n_frames=8)
        freq, _, _ = find_peak_frequency(signal, fps=120.0)
        assert isinstance(freq, float)
        assert math.isfinite(freq)
