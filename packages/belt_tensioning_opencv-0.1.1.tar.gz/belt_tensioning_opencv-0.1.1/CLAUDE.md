# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

**Read `CODING_STANDARDS.md` at session start.**

## Project Overview

Klipper extra for automated CoreXY belt tension measurement using a USB camera
(InnoMaker OV9281) and OpenCV. Uses pixel-intensity FFT on belt ROI to determine
resonant frequency, then computes tension adjustment instructions.
See `specs/BELT_TENSION_CV_SPEC.md` for the full specification.

## Commands

```bash
# Setup (first time)
mise install

# Lint
uv run ruff check .
uv run ruff format --check .

# Lint with auto-fix
uv run ruff check --fix .
uv run ruff format .

# Type check
uv run mypy src/

# Tests
uv run pytest
uv run pytest tests/test_foo.py::test_bar    # single test
uv run pytest --cov=src --cov-report=term-missing  # with coverage

# All pre-commit hooks
uv run pre-commit run --all-files
```

## Architecture

Two-process design: a Klipper extra running inside klippy, and a standalone CV capture script invoked as a subprocess.

- **`src/belt_tensioning_opencv/`** — Python package (camera capture, FFT analysis, result types)
- **`tests/`** — pytest tests
- **`specs/BELT_TENSION_CV_SPEC.md`** — full implementation spec
  (physics, hardware, CV pipeline, Klipper integration, phased plan)

The eventual deployment target is a Raspberry Pi running Klipper. The Klipper extra
(`belt_tension_cv.py`) registers a `BELT_TENSION_ADJUST` gcode macro, positions the
toolhead, drives stepper excitation, controls LED strobe, and spawns the CV capture
script. The capture script opens the camera via OpenCV, captures frames, runs FFT,
and returns JSON results on stdout.

## Git Conventions

- **Conventional Commits** enforced by pre-commit hook: `feat(scope): description`
- All commits must include `Signed-off-by` trailer (`git commit -s`), enforced by CI
- Cryptographic signing (GPG/SSH) is optional but preferred
- Use MermaidJS diagrams in `.md` files that render on GitHub (e.g., ` ```mermaid `), NOT ASCII art
- Semantic-release on `main` for automated versioning
- PR titles: conventional commit format; body uses `###` headings (`Summary`, `Changes`, `Testing`)
