# CHANGELOG

<!-- version list -->

## v0.1.1 (2026-03-20)

### Bug Fixes

- **plugin**: Change entry point group from klippy.extras to kalico.plugins
  ([`ba514bf`](https://github.com/bassco/belt-tensioning-opencv/commit/ba514bf8945f828ecf269a23dcb5f52913a1b6ca))

### Chores

- Exclude machine-generated CHANGELOG.md from markdownlint
  ([`b62a93b`](https://github.com/bassco/belt-tensioning-opencv/commit/b62a93b5451dfd8833d6387783920502132d4d66))

- Fix markdownlint trailing blank line in CHANGELOG
  ([`46e50ae`](https://github.com/bassco/belt-tensioning-opencv/commit/46e50aecae2baab4a1654e185c02239a46b53d75))

### Continuous Integration

- Bump actions to Node.js 24-compatible versions
  ([`aeabf5e`](https://github.com/bassco/belt-tensioning-opencv/commit/aeabf5e4b177add4ae54479d208150cbe1dadbef))

### Documentation

- **spec**: Add plugin metadata spec and update entry point references
  ([`2b209ce`](https://github.com/bassco/belt-tensioning-opencv/commit/2b209ce349045252a3de812ee2c67f4125843156))

- **spec**: Update architecture for dual-venv isolation
  ([`ecb8a50`](https://github.com/bassco/belt-tensioning-opencv/commit/ecb8a50a924fe401840d9622f0d0b54d719e4aef))


## v0.1.0 (2026-03-20)

### Bug Fixes

- Use GH_TOKEN secret for release workflow
  ([#1](https://github.com/bassco/belt_tensioning_opencv/pull/1),
  [`1eee16b`](https://github.com/bassco/belt_tensioning_opencv/commit/1eee16b22e409fc511da3e6354065dbaed682f12))

- Use GitHub App token for release workflow
  ([#1](https://github.com/bassco/belt_tensioning_opencv/pull/1),
  [`1eee16b`](https://github.com/bassco/belt_tensioning_opencv/commit/1eee16b22e409fc511da3e6354065dbaed682f12))

### Chores

- Add markdownlint pre-commit hook and fix all markdown files
  ([#1](https://github.com/bassco/belt_tensioning_opencv/pull/1),
  [`1eee16b`](https://github.com/bassco/belt_tensioning_opencv/commit/1eee16b22e409fc511da3e6354065dbaed682f12))

- Add uv to release workflow and simplify publish workflow
  ([#1](https://github.com/bassco/belt_tensioning_opencv/pull/1),
  [`1eee16b`](https://github.com/bassco/belt_tensioning_opencv/commit/1eee16b22e409fc511da3e6354065dbaed682f12))

- Remove rename plan ([#1](https://github.com/bassco/belt_tensioning_opencv/pull/1),
  [`1eee16b`](https://github.com/bassco/belt_tensioning_opencv/commit/1eee16b22e409fc511da3e6354065dbaed682f12))

- Rename package from opencv-belt-tensioning to belt-tensioning-opencv
  ([#1](https://github.com/bassco/belt_tensioning_opencv/pull/1),
  [`1eee16b`](https://github.com/bassco/belt_tensioning_opencv/commit/1eee16b22e409fc511da3e6354065dbaed682f12))

- Set version to 0.0.1 for initial release bump to v0.1.0
  ([#1](https://github.com/bassco/belt_tensioning_opencv/pull/1),
  [`1eee16b`](https://github.com/bassco/belt_tensioning_opencv/commit/1eee16b22e409fc511da3e6354065dbaed682f12))

- Standardize CI on astral-sh/setup-uv with caching
  ([#1](https://github.com/bassco/belt_tensioning_opencv/pull/1),
  [`1eee16b`](https://github.com/bassco/belt_tensioning_opencv/commit/1eee16b22e409fc511da3e6354065dbaed682f12))

- Use astral-sh/setup-uv in release workflow
  ([#1](https://github.com/bassco/belt_tensioning_opencv/pull/1),
  [`1eee16b`](https://github.com/bassco/belt_tensioning_opencv/commit/1eee16b22e409fc511da3e6354065dbaed682f12))

- Use uv build for semantic-release ([#1](https://github.com/bassco/belt_tensioning_opencv/pull/1),
  [`1eee16b`](https://github.com/bassco/belt_tensioning_opencv/commit/1eee16b22e409fc511da3e6354065dbaed682f12))

### Continuous Integration

- Configure PSR release and PyPI publish workflows
  ([`32c900f`](https://github.com/bassco/belt_tensioning_opencv/commit/32c900f3eb6bf8f4dbfcbbc016b3c0970fec03e1))

### Documentation

- Add kalico plugin spec ([#1](https://github.com/bassco/belt_tensioning_opencv/pull/1),
  [`1eee16b`](https://github.com/bassco/belt_tensioning_opencv/commit/1eee16b22e409fc511da3e6354065dbaed682f12))

- Convert ASCII diagrams to MermaidJS for GitHub rendering
  ([#1](https://github.com/bassco/belt_tensioning_opencv/pull/1),
  [`1eee16b`](https://github.com/bassco/belt_tensioning_opencv/commit/1eee16b22e409fc511da3e6354065dbaed682f12))

- Create a specs folder ([#1](https://github.com/bassco/belt_tensioning_opencv/pull/1),
  [`1eee16b`](https://github.com/bassco/belt_tensioning_opencv/commit/1eee16b22e409fc511da3e6354065dbaed682f12))

### Features

- Add Kalico plugin boilerplate ([#1](https://github.com/bassco/belt_tensioning_opencv/pull/1),
  [`1eee16b`](https://github.com/bassco/belt_tensioning_opencv/commit/1eee16b22e409fc511da3e6354065dbaed682f12))

- **cv**: Implement phase 1 camera capture and FFT analysis
  ([#1](https://github.com/bassco/belt_tensioning_opencv/pull/1),
  [`1eee16b`](https://github.com/bassco/belt_tensioning_opencv/commit/1eee16b22e409fc511da3e6354065dbaed682f12))

- **cv**: Implement phase 1 camera capture and FFT frequency analysis
  ([#1](https://github.com/bassco/belt_tensioning_opencv/pull/1),
  [`1eee16b`](https://github.com/bassco/belt_tensioning_opencv/commit/1eee16b22e409fc511da3e6354065dbaed682f12))

### Testing

- **cv**: Add phase 1 hardware test plan for camera and FFT validation
  ([#1](https://github.com/bassco/belt_tensioning_opencv/pull/1),
  [`1eee16b`](https://github.com/bassco/belt_tensioning_opencv/commit/1eee16b22e409fc511da3e6354065dbaed682f12))

## v1.0.0 (2026-03-19)

## v0.0.1 (2026-03-19)

- Initial Release
