# Coding Standards

## Python Version

Target **Python 3.9** for Raspberry Pi OS compatibility. Do not use syntax or
stdlib features introduced after 3.9 (e.g. `match`, `type` aliases, `X | Y` unions).

## Type Annotations

All code must be fully typed:

- Function signatures (all parameters and return types)
- Variables where the type is not obvious from assignment
- Use `from __future__ import annotations` for modern union syntax in 3.9

Enforced by mypy with `disallow_untyped_defs`.

## Docstrings

Use **Google style** docstrings on all public functions and classes. Docstrings should
be descriptive, with argument descriptions and expected values.

```python
def measure_belt_frequency(
    cap: cv2.VideoCapture,
    roi: tuple[int, int, int, int],
    n_frames: int,
    fps: float,
) -> tuple[float, float, float]:
    """Measure belt resonant frequency via FFT of pixel intensity.

    Samples mean pixel intensity in the belt ROI over n_frames, then
    performs FFT to find the dominant frequency.

    Args:
        cap: OpenCV video capture device.
        roi: Region of interest as (x1, y1, x2, y2) in pixels.
        n_frames: Number of frames to capture.
        fps: Camera framerate in Hz, used for FFT frequency bins.

    Returns:
        Tuple of (frequency_hz, amplitude, confidence) where confidence
        is normalised to 0.0–1.0.

    Raises:
        CameraError: If a frame capture fails.
    """
```

For simple functions, a one-liner is fine:

```python
def hz_to_tension(frequency: float, span: float, mu: float) -> float:
    """Convert resonant frequency to belt tension in Newtons."""
```

## Inline Comments

Keep inline comments to a minimum. Code should be self-documenting through
clear naming, types, and docstrings. Only add comments for:

- Non-trivial maths or physics: `# Nyquist: max detectable freq = fps/2`
- Timing constraints or hardware quirks: `# V4L2: 1 = manual exposure mode`
- Counter-intuitive logic that can't be made obvious through naming

Do not add comments that restate the code:

```python
# Bad
# loop over frames
for i in range(n_frames):

# Bad
# open camera
cap = cv2.VideoCapture(device)
```

No speculative comments (`TODO: maybe`, `could be improved`).

## Linting and Formatting

- **Ruff** handles both linting and formatting
- Line length: **120 characters**
- Import sorting: isort via ruff, first-party package is `belt_tensioning_opencv`
- Docstring convention enforced by ruff pydocstyle rules (Google)
- Security checks via flake8-bandit rules

Run locally:

```bash
uv run ruff check .         # lint
uv run ruff check --fix .   # lint with auto-fix
uv run ruff format .        # format
uv run mypy src/            # type check
```

## Testing

- pytest with `--strict-markers`
- Tests in `tests/` directory
- Docstring rules are relaxed in tests (`D` rules ignored)
- `assert` is allowed in tests (`S101` ignored)
