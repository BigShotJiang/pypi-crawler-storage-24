"""Allow running as ``python -m belt_tensioning_opencv``."""

from belt_tensioning_opencv.capture import main

main()
