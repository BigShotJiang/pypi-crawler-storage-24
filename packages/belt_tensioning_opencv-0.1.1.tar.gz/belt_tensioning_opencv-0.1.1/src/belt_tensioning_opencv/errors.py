"""Custom exception types for belt tension CV measurement."""

from __future__ import annotations


class CameraError(Exception):
    """Raised when camera initialization or frame capture fails."""


class AnalysisError(Exception):
    """Raised when frequency analysis fails to produce a valid result."""
