"""Camera initialization and frame capture for belt tension measurement."""

from __future__ import annotations

import logging
import time

import cv2

from belt_tensioning_opencv.errors import CameraError

logger = logging.getLogger(__name__)

# V4L2 manual exposure mode constant
_V4L2_MANUAL_EXPOSURE = 1
_DEFAULT_EXPOSURE = -6


def open_camera(
    device: str,
    fps: int,
    width: int = 1280,
    height: int = 720,
    exposure: int | None = None,
) -> cv2.VideoCapture:
    """Open and configure a USB camera for belt tension measurement.

    Configures the camera with fixed exposure (auto-exposure disabled) to ensure
    consistent pixel intensity sampling required for accurate FFT analysis.

    Args:
        device: V4L2 device path (e.g. "/dev/video0").
        fps: Target framerate in Hz.
        width: Frame width in pixels.
        height: Frame height in pixels.
        exposure: Manual exposure value. Defaults to -6 if not specified.

    Returns:
        Configured OpenCV VideoCapture instance.

    Raises:
        CameraError: If the camera cannot be opened.
    """
    if exposure is None:
        exposure = _DEFAULT_EXPOSURE

    cap = cv2.VideoCapture(device, cv2.CAP_V4L2)
    if not cap.isOpened():
        raise CameraError(f"Cannot open camera: {device}")

    cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
    cap.set(cv2.CAP_PROP_FPS, fps)
    # V4L2: 1 = manual exposure mode
    cap.set(cv2.CAP_PROP_AUTO_EXPOSURE, _V4L2_MANUAL_EXPOSURE)
    cap.set(cv2.CAP_PROP_EXPOSURE, exposure)

    actual_w = cap.get(cv2.CAP_PROP_FRAME_WIDTH)
    actual_h = cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
    actual_fps = cap.get(cv2.CAP_PROP_FPS)
    logger.info(
        "Camera opened: %.0fx%.0f @ %.1f fps (requested %dx%d @ %d fps)",
        actual_w,
        actual_h,
        actual_fps,
        width,
        height,
        fps,
    )

    return cap


def capture_intensities(
    cap: cv2.VideoCapture,
    roi: tuple[int, int, int, int],
    n_frames: int,
) -> tuple[list[float], float]:
    """Capture frames and extract mean pixel intensity from the belt ROI.

    Args:
        cap: Open OpenCV VideoCapture instance.
        roi: Region of interest as (x1, y1, x2, y2) in pixels. Use (0, 0, 0, 0) for full frame.
        n_frames: Number of frames to capture.

    Returns:
        Tuple of (intensities, fps_actual) where intensities is a list of mean
        grayscale values per frame and fps_actual is the measured framerate.

    Raises:
        CameraError: If a frame capture fails.
    """
    x1, y1, x2, y2 = roi
    use_full_frame = x1 == 0 and y1 == 0 and x2 == 0 and y2 == 0

    intensities: list[float] = []
    t_start = time.monotonic()

    for i in range(n_frames):
        ret, frame = cap.read()
        if not ret:
            raise CameraError(f"Frame capture failed at frame {i}/{n_frames}")

        roi_frame = frame if use_full_frame else frame[y1:y2, x1:x2]  # type: ignore[index]
        gray = cv2.cvtColor(roi_frame, cv2.COLOR_BGR2GRAY)
        intensities.append(float(gray.mean()))

    t_elapsed = time.monotonic() - t_start
    fps_actual = n_frames / t_elapsed if t_elapsed > 0 else 0.0

    logger.info("Captured %d frames in %.2f s (%.1f fps actual)", n_frames, t_elapsed, fps_actual)

    return intensities, fps_actual
