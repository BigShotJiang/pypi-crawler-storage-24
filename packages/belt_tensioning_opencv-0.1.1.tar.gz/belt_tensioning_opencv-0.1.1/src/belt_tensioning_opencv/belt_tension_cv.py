"""Belt tension CV — Kalico klippy extra for automated belt tension measurement.

Loads via pip entry_point as [belt_tension_cv] in printer.cfg.
"""

from __future__ import annotations

import json
import logging
import subprocess
from typing import Any

from belt_tensioning_opencv.version_check import require_kalico

logger = logging.getLogger(__name__)

_MIN_KALICO = "2025.3.0"
_MAX_KALICO: str | None = None


class BeltTensionCV:
    """Klipper extra that measures CoreXY belt resonant frequency via OpenCV FFT."""

    def __init__(self, config: Any) -> None:
        self.printer = _get_printer(config)
        self.device = _get_str(config, "camera_device", "/dev/video0")
        self.fps = _get_int(config, "camera_fps", 120)
        self.frames = _get_int(config, "capture_frames", 120)
        self.roi = _get_str(config, "roi", "0,0,0,0")
        self.script_path = _get_str(config, "capture_script", "")

        self.printer.register_event_handler("klippy:shutdown", self._on_shutdown)

        self._last_result: dict[str, Any] | None = None

    def _on_shutdown(self) -> None:
        logger.info("BeltTensionCV shutting down")

    def _run_capture(self, belt: str) -> dict[str, Any]:
        cmd = [
            "python",
            "-m",
            "belt_tensioning_opencv",
            "--device",
            self.device,
            "--fps",
            str(self.fps),
            "--frames",
            str(self.frames),
            "--belt",
            belt,
            "--roi",
            self.roi,
        ]
        logger.info("Running: %s", " ".join(cmd))
        result = subprocess.run(  # noqa: S603
            cmd,
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode != 0:
            raise RuntimeError(f"capture failed: {result.stderr.strip()}")
        return json.loads(result.stdout.strip())  # type: ignore[no-any-return]

    # Klipper gcode command handlers are conventionally named cmd_* (not snake_case)
    def cmd_BELT_TENSION_ADJUST(self, _params: dict[str, Any]) -> None:  # noqa: N802
        """Measure belt tension and print adjustment instructions.

        Usage: BELT_TENSION_ADJUST BELT=[A|B]
        """
        try:
            data = self._run_capture("A")
        except Exception as e:
            logger.error("Measurement failed: %s", e)
            self.printer.set_move_category_error(
                "Core XY",
                f"Belt tension measurement failed: {e}",
            )
            return

        freq = data.get("frequency_hz", 0)
        confidence = data.get("confidence", 0)

        self._last_result = data

        self.printer.set_move_category_error(
            "Core XY",
            f"Belt tension: {freq} Hz (confidence={confidence:.0%})",
        )

        logger.info(
            "Measurement result: freq=%.1f Hz, confidence=%.2f",
            freq,
            confidence,
        )


def _get_printer(config: Any) -> Any:
    return getattr(config, "get_printer", lambda: None)()


def _get_str(config: Any, key: str, default: str) -> str:
    if hasattr(config, "get"):
        return config.get(key, default)  # type: ignore[no-any-return]
    return default


def _get_int(config: Any, key: str, default: int) -> int:
    if hasattr(config, "getint"):
        return config.getint(key, default)  # type: ignore[no-any-return]
    return default


def load_config(config: Any) -> BeltTensionCV:
    """Load the belt_tension_cv Klipper extra from printer.cfg."""
    require_kalico(_MIN_KALICO, _MAX_KALICO)
    return BeltTensionCV(config)
