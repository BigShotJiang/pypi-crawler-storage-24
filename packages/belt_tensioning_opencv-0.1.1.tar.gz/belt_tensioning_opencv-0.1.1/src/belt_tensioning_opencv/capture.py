"""CLI entry point for belt tension CV capture and frequency measurement."""

from __future__ import annotations

import argparse
import logging
import sys

from belt_tensioning_opencv.analysis import find_peak_frequency
from belt_tensioning_opencv.camera import capture_intensities, open_camera
from belt_tensioning_opencv.errors import AnalysisError, CameraError
from belt_tensioning_opencv.models import MeasurementResult

logger = logging.getLogger(__name__)


def parse_roi(roi_str: str) -> tuple[int, int, int, int]:
    """Parse a comma-separated ROI string into a (x1, y1, x2, y2) tuple.

    Args:
        roi_str: ROI as "x1,y1,x2,y2" (e.g. "200,100,600,400" or "0,0,0,0").

    Returns:
        Tuple of four integers (x1, y1, x2, y2).

    Raises:
        argparse.ArgumentTypeError: If the format is invalid.
    """
    parts = roi_str.split(",")
    if len(parts) != 4:
        raise argparse.ArgumentTypeError(f"ROI must have 4 values (x1,y1,x2,y2), got {len(parts)}")
    try:
        values = tuple(int(p.strip()) for p in parts)
    except ValueError as e:
        raise argparse.ArgumentTypeError(f"ROI values must be integers: {e}") from e
    return values[0], values[1], values[2], values[3]


def build_parser() -> argparse.ArgumentParser:
    """Build the CLI argument parser.

    Returns:
        Configured ArgumentParser instance.
    """
    parser = argparse.ArgumentParser(
        description="Capture belt vibration frames and measure resonant frequency via FFT.",
    )
    parser.add_argument("--device", default="/dev/video0", help="V4L2 camera device path (default: /dev/video0)")
    parser.add_argument("--fps", type=int, default=120, help="Camera framerate in Hz (default: 120)")
    parser.add_argument("--frames", type=int, default=120, help="Number of frames to capture (default: 120)")
    parser.add_argument("--belt", choices=["A", "B"], default="A", help="Belt identifier (default: A)")
    parser.add_argument(
        "--roi",
        type=parse_roi,
        default=(0, 0, 0, 0),
        help="ROI as x1,y1,x2,y2 (default: 0,0,0,0 = full frame)",
    )
    parser.add_argument("--verbose", action="store_true", help="Enable debug logging on stderr")
    return parser


def run(args: argparse.Namespace) -> MeasurementResult:
    """Execute belt frequency measurement.

    Args:
        args: Parsed CLI arguments.

    Returns:
        MeasurementResult with detected frequency and metadata.

    Raises:
        CameraError: If camera initialization or capture fails.
        AnalysisError: If FFT analysis fails.
    """
    cap = open_camera(args.device, args.fps)
    try:
        intensities, fps_actual = capture_intensities(cap, args.roi, args.frames)
    finally:
        cap.release()

    freq, amp, confidence = find_peak_frequency(intensities, fps_actual)

    return MeasurementResult(
        belt=args.belt,
        frequency_hz=round(freq, 1),
        amplitude=round(amp, 2),
        confidence=round(confidence, 2),
        fps_actual=round(fps_actual, 1),
        frames_captured=args.frames,
    )


def main() -> None:
    """CLI entry point for belt_cv_capture."""
    parser = build_parser()
    args = parser.parse_args()

    log_level = logging.DEBUG if args.verbose else logging.WARNING
    logging.basicConfig(level=log_level, stream=sys.stderr, format="%(levelname)s: %(message)s")

    try:
        result = run(args)
    except CameraError as e:
        logger.error("Camera error: %s", e)
        sys.exit(1)
    except AnalysisError as e:
        logger.error("Analysis error: %s", e)
        sys.exit(2)

    sys.stdout.write(result.to_json() + "\n")
