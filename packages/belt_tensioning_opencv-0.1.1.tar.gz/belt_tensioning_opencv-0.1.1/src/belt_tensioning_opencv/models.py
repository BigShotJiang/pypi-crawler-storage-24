"""Data models for belt tension measurement results."""

from __future__ import annotations

import dataclasses
import json
from typing import Any


@dataclasses.dataclass
class MeasurementResult:
    """Result of a single belt frequency measurement.

    Attributes:
        belt: Belt identifier ("A" or "B").
        frequency_hz: Detected resonant frequency in Hz.
        amplitude: FFT peak amplitude (arbitrary units).
        confidence: Measurement confidence normalised to 0.0-1.0.
        fps_actual: Actual framerate achieved during capture.
        frames_captured: Number of frames successfully captured.
    """

    belt: str
    frequency_hz: float
    amplitude: float
    confidence: float
    fps_actual: float
    frames_captured: int

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a JSON-compatible dictionary."""
        return dataclasses.asdict(self)

    def to_json(self) -> str:
        """Serialize to a JSON string."""
        return json.dumps(self.to_dict(), indent=2)
