"""FFT-based frequency analysis for belt tension measurement."""

from __future__ import annotations

import logging

import numpy as np

from belt_tensioning_opencv.errors import AnalysisError

logger = logging.getLogger(__name__)

# Minimum number of samples for meaningful FFT
_MIN_SAMPLES = 8

# Confidence normalisation divisor — empirically tuned so a clean signal yields ~1.0
_CONFIDENCE_SCALE = 10.0


def find_peak_frequency(
    intensities: list[float],
    fps: float,
) -> tuple[float, float, float]:
    """Find the dominant frequency in a pixel intensity time series via FFT.

    Applies a Hanning window to reduce spectral leakage, computes the real FFT,
    and locates the peak frequency (excluding DC).

    Args:
        intensities: Mean pixel intensity values, one per frame.
        fps: Actual capture framerate in Hz, used to compute frequency bins.

    Returns:
        Tuple of (frequency_hz, amplitude, confidence) where confidence is
        normalised to 0.0-1.0 based on peak-to-RMS ratio of the spectrum.

    Raises:
        AnalysisError: If too few samples or no valid peak is found.
    """
    n = len(intensities)
    if n < _MIN_SAMPLES:
        raise AnalysisError(f"Too few samples for FFT: {n} (minimum {_MIN_SAMPLES})")

    arr = np.array(intensities, dtype=np.float64)
    arr -= arr.mean()  # remove DC offset

    window = np.hanning(n)
    arr_windowed = arr * window

    fft_mag = np.abs(np.fft.rfft(arr_windowed))
    freqs = np.fft.rfftfreq(n, d=1.0 / fps)

    if len(fft_mag) < 2:
        raise AnalysisError("FFT produced insufficient frequency bins")

    # Skip DC bin (index 0) when finding peak
    peak_idx = int(np.argmax(fft_mag[1:])) + 1
    peak_freq = float(freqs[peak_idx])
    peak_amp = float(fft_mag[peak_idx])

    # Confidence: peak-to-RMS ratio of the rest of the spectrum
    rest = np.delete(fft_mag, peak_idx)
    rms_rest = float(np.sqrt(np.mean(rest**2)))
    confidence = peak_amp / (rms_rest + 1e-9)
    confidence = min(confidence / _CONFIDENCE_SCALE, 1.0)

    # Nyquist: max detectable freq = fps/2
    nyquist = fps / 2.0
    logger.info(
        "FFT peak: %.2f Hz (amplitude=%.2f, confidence=%.3f, nyquist=%.1f Hz)",
        peak_freq,
        peak_amp,
        confidence,
        nyquist,
    )

    return peak_freq, peak_amp, confidence
