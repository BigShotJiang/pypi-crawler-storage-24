"""Kalico version guard for belt_tensioning_opencv plugin.

Gracefully skips if Kalico is not pip-installed (e.g. git-clone install).
"""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version


def require_kalico(min_ver: str, max_ver: str | None = None) -> None:
    """Raise RuntimeError if installed Kalico is outside supported version range.

    Silently passes if Kalico is not pip-installed (git-clone install).
    """
    try:
        v_str = version("kalico")
    except PackageNotFoundError:
        return

    v = tuple(int(x) for x in v_str.split("."))
    min_t = tuple(int(x) for x in min_ver.split("."))

    if v < min_t:
        raise RuntimeError(f"kalico {'.'.join(str(x) for x in v)} is too old; this plugin requires >={min_ver}")

    if max_ver:
        max_t = tuple(int(x) for x in max_ver.split("."))
        if v >= max_t:
            raise RuntimeError(
                f"kalico {'.'.join(str(x) for x in v)} is not supported; this plugin requires <{max_ver}"
            )
