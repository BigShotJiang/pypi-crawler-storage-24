# belt-tensioning-opencv

Klipper extra for automated CoreXY belt tension measurement using a USB camera and OpenCV.

See [BELT_TENSION_CV_SPEC.md](specs/BELT_TENSION_CV_SPEC.md) for the full specification.

## Quick Start

```bash
mise install
uv sync --all-extras
uv run pre-commit install --install-hooks
uv run pre-commit install --hook-type commit-msg
```

## License

[MIT](LICENSE)
