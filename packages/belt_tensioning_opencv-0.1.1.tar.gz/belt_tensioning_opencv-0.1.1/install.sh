#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
KLIPPER_PATH="${1:-${HOME}/klipper}"
KLIPPY_EXTRAS="${KLIPPER_PATH}/klippy/extras"
VENV="${KLIPPER_PATH}/../klippy-env"

if [[ ! -d "${KLIPPY_EXTRAS}" ]]; then
    echo "ERROR: Cannot find klippy/extras in ${KLIPPER_PATH}" >&2
    echo "Usage: $0 [/path/to/klipper]" >&2
    exit 1
fi

echo "Installing belt_tension_cv into ${KLIPPY_EXTRAS} ..."
cp "${SCRIPT_DIR}/src/belt_tensioning_opencv/belt_tension_cv.py" "${KLIPPY_EXTRAS}/belt_tension_cv.py"
echo "Done."

if [[ -x "${VENV}/bin/pip" ]]; then
    echo "Installing Python dependencies into ${VENV} ..."
    "${VENV}/bin/pip" install numpy opencv-python-headless
fi

echo ""
echo "Add the following to your printer.cfg and restart Klipper:"
echo ""
echo "  [belt_tension_cv]"
echo "  camera_device: /dev/video0"
echo "  camera_fps: 120"
echo "  capture_frames: 120"
echo "  roi: 0,0,0,0"
echo ""
echo "Then run BELT_TENSION_ADJUST from the console."
echo ""
echo "Restart Klipper:"
echo "  sudo systemctl restart klipper"
