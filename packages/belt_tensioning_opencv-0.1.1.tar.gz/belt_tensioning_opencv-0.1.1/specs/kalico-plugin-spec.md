# Kalico Klipper Plugin — Development & Publishing Specification

> **Audience:** Claude CLI / Claude Code agent executing this spec.
> All file paths are relative to the repo root unless stated otherwise.
> Placeholder values are in `<ANGLE_BRACKETS>` — resolve from context or ask.

---

## Table of Contents

1. [Background & Findings](#1-background--findings)
2. [Repository Layout](#2-repository-layout)
3. [Plugin Module Interface](#3-plugin-module-interface)
4. [pyproject.toml](#4-pyprojecttoml)
5. [Version Strategy — CalVer + python-semantic-release](#5-version-strategy--calver--python-semantic-release)
6. [GitHub Actions — Release & Publish Pipeline](#6-github-actions--release--publish-pipeline)
7. [One-time Setup Checklist](#7-one-time-setup-checklist)
8. [Klipper/Kalico User Install Procedure](#8-klipperkalico-user-install-procedure)
9. [Moonraker Update Manager Config](#9-moonraker-update-manager-config)
10. [References](#10-references)

---

## 1. Background & Findings

### 1.1 How Kalico Loads Pip Plugins

Kalico extends stock Klipper's extras system by scanning Python
`entry_points` at startup. On launch, `klippy.py` calls:

```python
from importlib.metadata import entry_points
plugins = entry_points(group="klippy.extras")
```

Each discovered entry point maps a **config section name** (e.g. `my_extra`)
to a **Python module** (e.g. `my_package.my_extra`). The module must expose
the same interface as a standard Klipper extra (`load_config` /
`load_config_prefix` functions).

A user activates the plugin by adding the matching section to `printer.cfg`:

```ini
[my_extra]
# plugin-specific config keys here
```

Then installing the package into Kalico's virtualenv:

```shell
~/klippy-env/bin/pip install <pypi-package-name>
```

Kalico must be restarted after install for the plugin to load.

**Key difference from stock Klipper:** Stock Klipper has no plugin mechanism;
third-party extras must be placed manually in `~/klipper/klippy/extras/`,
which dirtifies the git tree and breaks updates. The Kalico pip approach keeps
the Kalico install untouched — plugins are managed entirely by pip.

Setting `allow_plugin_override: True` under `[danger_options]` in
`printer.cfg` allows a pip plugin to shadow a built-in extra of the same name.

### 1.2 CalVer in Kalico

Kalico uses **CalVer** format: `YYYY.MM.PATCH` — e.g. `2025.3.0`, `2025.3.1`.

- `YYYY` = full year
- `MM` = short month (no zero-padding)
- `PATCH` = incremental hotfix counter, resets each month

Hotfix releases within the same month increment `PATCH`:
`2025.3.0` → `2025.3.1` → `2025.3.2`.

PEP 440 version comparison works correctly with this scheme because segments
are compared numerically left-to-right.

### 1.3 Plugin Compatibility Declaration

Since Kalico is not yet published to PyPI as an installable package,
the `dependencies` field in `pyproject.toml` cannot enforce the Kalico
version at install time. Compatibility is declared for documentation and
tooling purposes, and enforced at **plugin load time** via a runtime check:

```python
# src/<package>/version_check.py
from importlib.metadata import version, PackageNotFoundError

def require_kalico(min_ver: str, max_ver: str | None = None) -> None:
    """Raise ConfigError if installed Kalico is outside supported range."""
    try:
        v = tuple(int(x) for x in version("kalico").split("."))
    except PackageNotFoundError:
        return  # Kalico not pip-installed; skip check
    min_t = tuple(int(x) for x in min_ver.split("."))
    if v < min_t:
        raise RuntimeError(
            f"kalico {'.'.join(str(x) for x in v)} is too old; "
            f"this plugin requires >={min_ver}"
        )
    if max_ver:
        max_t = tuple(int(x) for x in max_ver.split("."))
        if v >= max_t:
            raise RuntimeError(
                f"kalico {'.'.join(str(x) for x in v)} is not supported; "
                f"this plugin requires <{max_ver}"
            )
```

Call `require_kalico` at the top of `load_config`:

```python
def load_config(config):
    require_kalico("2025.3.0", "2025.4.0")
    return MyExtra(config)
```

### 1.4 No Real-World Reference Implementations Yet

As of March 2026, **no published PyPI packages** use the `kalico.plugins`
entry_point mechanism for Kalico. The canonical specification comes from
[Klipper PR #6849](https://github.com/Klipper3d/klipper/pull/6849), which
proposed this mechanism (rejected by mainline Klipper, adopted by Kalico).
The plugin structure described here is based on that PR plus Kalico's own
documentation at <https://docs.kalico.gg/Kalico_Additions.html#plugins>.

---

## 2. Repository Layout

```mermaid
graph TD
    root["<repo-root>/"]

    root --> github[".github/"]
    github --> workflows["workflows/"]
    workflows --> release["release.yml<br># python-semantic-release"]
    workflows --> publish["publish.yml<br># PyPI publish"]

    root --> src["src/"]
    src --> pkg["<package_name>/"]
    pkg --> init["__init__.py"]
    pkg --> extra["<extra_name>.py"]
    pkg --> version["version_check.py"]

    root --> install["install.sh"]
    root --> changelog["CHANGELOG.md"]
    root --> pyproject["pyproject.toml"]
    root --> readme["README.md"]
```

> **Naming convention:** PyPI package name `kalico-<extra_name>`,
> Python import package `<package_name>` (underscores).
> The entry point `name` (= config section) must match exactly what users
> put in `printer.cfg`, so keep it short and snake_case.

---

## 3. Plugin Module Interface

`src/<package_name>/<extra_name>.py` must follow the standard Klipper extras
contract. Minimal scaffold:

```python
"""
<extra_name> — <short description>
Kalico klippy extra, loadable via pip entry_point.
"""
import logging
from .version_check import require_kalico

logger = logging.getLogger(__name__)

# Supported Kalico version range — update when plugin release changes API usage
_MIN_KALICO = "2025.3.0"
_MAX_KALICO = None  # set to "YYYY.MM.0" to cap at a specific month


class <ExtraClass>:
    def __init__(self, config):
        self.printer = config.get_printer()
        # … parse config keys …

    # Register Klipper event handlers, GCode commands, etc. here


def load_config(config):
    require_kalico(_MIN_KALICO, _MAX_KALICO)
    return <ExtraClass>(config)


# For named sections like [my_extra toolname]:
# def load_config_prefix(config):
#     require_kalico(_MIN_KALICO, _MAX_KALICO)
#     return <ExtraClass>(config)
```

---

## 4. pyproject.toml

```toml
[project]
name = "kalico-<extra_name>"
dynamic = ["version"]
description = "<One-line description>"
readme = "README.md"
license = { file = "LICENSE" }
requires-python = ">=3.9"
keywords = ["klipper", "kalico", "3d-printing"]
classifiers = [
  "Programming Language :: Python :: 3",
  "License :: OSI Approved :: GNU General Public License v3 (GPLv3)",
  "Topic :: Other/Nonlisted Topic",
]
# Runtime deps for the extra go here:
dependencies = []

[project.entry-points."kalico.plugins"]
# key   = config section name users put in printer.cfg
# value = dotted module path inside the installed package
<extra_name> = "<package_name>.<extra_name>"

[project.urls]
Homepage = "https://github.com/<owner>/<repo>"
Issues = "https://github.com/<owner>/<repo>/issues"
Changelog = "https://github.com/<owner>/<repo>/blob/main/CHANGELOG.md"

# ── Build ──────────────────────────────────────────────────────────────────

[build-system]
requires = ["hatchling", "hatch-vcs"]
build-backend = "hatchling.build"

[tool.hatch.version]
source = "vcs"                      # reads version from git tag
fallback-version = "0.0.0"

[tool.hatch.build.targets.wheel]
packages = ["src/<package_name>"]

# ── python-semantic-release ────────────────────────────────────────────────

[tool.semantic_release]
version_toml = ["pyproject.toml:project.version"]
# CalVer: treat YYYY as major, MM as minor, PATCH as patch
# PSR's default semver bump maps:  fix→patch  feat→minor  BREAKING→major
# For CalVer the "minor" bump is the calendar month — PSR handles the
# number correctly as long as you don't mix semver and calver bumps
# in the same month. Use commit type "fix:" for patch bumps within a month.
branch = "main"
build_command = "pip install hatch hatch-vcs && python -m build"
upload_to_pypi = false              # PyPI publish is handled separately
upload_to_release = true            # attach dist assets to the GH release
changelog_file = "CHANGELOG.md"
commit_message = "chore(release): {version} [skip ci]"

[tool.semantic_release.commit_parser_options]
allowed_tags = ["feat", "fix", "perf", "refactor", "style", "test", "docs", "chore"]
minor_tags = ["feat"]
patch_tags = ["fix", "perf"]
```

> **Note on CalVer + PSR:** PSR increments version numbers numerically.
> The initial version tag must be created manually: `git tag v2025.3.0`.
> After that, `fix:` commits increment the patch (`2025.3.1`),
> `feat:` commits increment the minor (`2025.4.0`), and a manual tag or
> `BREAKING CHANGE` increments the major (`2026.1.0`).
> PSR does not understand calendar semantics — if you want the month segment
> to reflect the actual release month after a gap, bump the tag manually
> before merging.

---

## 5. Version Strategy — CalVer + python-semantic-release

| Scenario | Commit type | Version change | Example |
|---|---|---|---|
| Bug fix within same month | `fix:` | patch +1 | `2025.3.0` → `2025.3.1` |
| New feature | `feat:` | minor +1 | `2025.3.1` → `2025.4.0` |
| Breaking API change | `BREAKING CHANGE:` footer | major +1 | `2025.4.0` → `2026.1.0` |
| New calendar month (manual) | Create tag manually | manual | `2025.3.x` → `2025.4.0` |

Initial tag must be created manually before the first PSR run:

```shell
git tag v2025.3.0
git push origin v2025.3.0
```

---

## 6. GitHub Actions — Release & Publish Pipeline

### Architecture

```text
push to main
    └── release.yml  (python-semantic-release)
            ├── bumps version, commits, creates git tag
            └── creates GitHub Release  ──→  release:published event
                                                    └── publish.yml
                                                            ├── builds dist/
                                                            └── pypa/gh-action-pypi-publish
                                                                    └── PyPI (OIDC / Trusted Publisher)
```

> **Critical:** PSR must use a **non-`GITHUB_TOKEN`** credential when
> creating the GitHub Release, otherwise the `release:published` event will
> not trigger `publish.yml`. Use a GitHub App installation token or a PAT
> stored as a secret (`GH_TOKEN`).
>
> Reference: <https://github.com/semantic-release/semantic-release/discussions/1906>

---

### `.github/workflows/release.yml`

```yaml
name: Release

on:
  push:
    branches: [main]

permissions:
  contents: read

jobs:
  release:
    runs-on: ubuntu-latest
    concurrency:
      group: ${{ github.workflow }}-release-${{ github.ref_name }}
      cancel-in-progress: false
    permissions:
      contents: write   # create tags + GH release
      id-token: write   # for attestations if needed

    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0
          # Use a PAT or GitHub App token so the release event
          # can trigger the publish workflow (GITHUB_TOKEN cannot).
          token: ${{ secrets.GH_TOKEN }}

      - uses: actions/setup-python@v5
        with:
          python-version: "3.11"

      - name: Install python-semantic-release
        run: pip install python-semantic-release

      - name: Run semantic-release
        run: semantic-release version --push
        env:
          GH_TOKEN: ${{ secrets.GH_TOKEN }}
```

---

### `.github/workflows/publish.yml`

```yaml
name: Publish to PyPI

on:
  release:
    types: [published]  # triggered when release.yml creates a GH release

permissions:
  contents: read

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          # fetch all tags so hatch-vcs can read the version
          fetch-depth: 0

      - uses: actions/setup-python@v5
        with:
          python-version: "3.11"

      - name: Install build tools
        run: pip install build hatch hatch-vcs

      - name: Build distributions
        run: python -m build

      - name: Upload dist artifacts
        uses: actions/upload-artifact@v4
        with:
          name: dist
          path: dist/

  publish:
    needs: build
    runs-on: ubuntu-latest
    environment:
      name: pypi
      url: https://pypi.org/p/kalico-<extra_name>
    permissions:
      id-token: write   # mandatory for OIDC / Trusted Publishing

    steps:
      - name: Download dist artifacts
        uses: actions/download-artifact@v4
        with:
          name: dist
          path: dist/

      - name: Publish to PyPI
        uses: pypa/gh-action-pypi-publish@release/v1
```

---

## 7. One-time Setup Checklist

Complete these steps once before the first release. Items marked **[manual]**
cannot be automated.

### 7.1 PyPI Project & Trusted Publisher

1. **[manual]** Create a PyPI account at <https://pypi.org/account/register/>.
   Enable 2FA.

2. **[manual]** Register a **Pending Trusted Publisher** at
   <https://pypi.org/manage/account/publishing/> with:
   - PyPI project name: `kalico-<extra_name>`
   - GitHub owner: `<owner>`
   - GitHub repo: `<repo>`
   - Workflow filename: `publish.yml`
   - Environment: `pypi`

   This creates the project on first publish without needing an API token.
   Reference: <https://docs.pypi.org/trusted-publishers/creating-a-project-through-oidc/>

### 7.2 GitHub Repository Configuration

1. **[manual]** Create a GitHub Environment named `pypi`:
   - `Settings → Environments → New environment → pypi`
   - Add protection rule: **Required reviewers** (optional but recommended
     for a production package).

2. **[manual]** Create a GitHub PAT (classic) or GitHub App with `contents:write`
   permission, store it as a repository secret named `GH_TOKEN`.
   This is required so PSR's GitHub Release creation triggers `publish.yml`.

   OR: Create a GitHub App, store the App ID as `GH_APP_ID` and private key
   as `GH_APP_PRIVATE_KEY`, and generate an installation token in the workflow
   step instead.

3. **[auto]** Commit the two workflow files and `pyproject.toml` to `main`.

### 7.3 Initial Version Tag

1. **[manual]** Create the first CalVer tag manually:

   ```shell
   git tag v2025.3.0
   git push origin v2025.3.0
   ```

   PSR will take over from this tag onwards.

### 7.4 Verify

1. Push a `fix: some change` commit to `main` and verify:
   - `release.yml` runs, bumps version to `2025.3.1`, creates a GH Release
   - `publish.yml` is triggered by the `release:published` event
   - Package appears on PyPI at `https://pypi.org/project/kalico-<extra_name>/`

---

## 8. Klipper/Kalico User Install Procedure

This section documents the **traditional git-clone + `install.sh`** workflow
for users who prefer it over `pip install`, and for Klipper (non-Kalico) users
who cannot use entry_points.

> **Klipper vs Kalico:**
>
> - **Kalico users** → prefer `pip install` (§8.1). The entry_points mechanism
>   means no git-tree pollution and Moonraker can manage updates.
> - **Klipper users** → must use the git-clone method (§8.2) because stock
>   Klipper has no entry_points discovery.

---

### 8.1 Kalico Users — pip install (recommended)

```shell
# Install into Kalico's virtualenv
~/klippy-env/bin/pip install kalico-<extra_name>

# Add to printer.cfg:
#   [<extra_name>]
#   # ... config options ...

# Restart Klipper
sudo systemctl restart klipper
```

To upgrade:

```shell
~/klippy-env/bin/pip install --upgrade kalico-<extra_name>
sudo systemctl restart klipper
```

To uninstall:

```shell
~/klippy-env/bin/pip uninstall kalico-<extra_name>
# Remove [<extra_name>] section from printer.cfg
sudo systemctl restart klipper
```

---

### 8.2 Klipper / Kalico Users — git clone + install.sh

`install.sh` copies the extra module directly into `klippy/extras/`.
This approach works on both Klipper and Kalico; on Kalico it bypasses the
pip mechanism but is fully functional.

#### `install.sh`

```bash
#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
KLIPPER_PATH="${1:-${HOME}/klipper}"
KLIPPY_EXTRAS="${KLIPPER_PATH}/klippy/extras"
VENV="${KLIPPER_PATH}/../klippy-env"

# Validate target
if [[ ! -d "${KLIPPY_EXTRAS}" ]]; then
  echo "ERROR: Cannot find klippy/extras in ${KLIPPER_PATH}" >&2
  echo "Usage: $0 [/path/to/klipper]" >&2
  exit 1
fi

echo "Installing <extra_name> into ${KLIPPY_EXTRAS} ..."
cp "${SCRIPT_DIR}/src/<package_name>/<extra_name>.py" "${KLIPPY_EXTRAS}/<extra_name>.py"
echo "Done."

# Install Python dependencies into the klippy venv (if any)
# if [[ -x "${VENV}/bin/pip" ]]; then
#   "${VENV}/bin/pip" install some-dep
# fi

echo ""
echo "Add the following to your printer.cfg and restart Klipper:"
echo ""
echo "  [<extra_name>]"
echo "  # config options here"
echo ""
echo "Then restart Klipper:"
echo "  sudo systemctl restart klipper"
```

#### User instructions

```shell
cd ~
git clone https://github.com/<owner>/<repo>.git
cd <repo>
chmod +x install.sh
./install.sh                          # auto-detects ~/klipper
# OR: ./install.sh /path/to/klipper  # custom path
```

Add to `printer.cfg`:

```ini
[<extra_name>]
# ... configuration options ...
```

Restart Klipper:

```shell
sudo systemctl restart klipper
```

#### Updating

```shell
cd ~/<repo>
git pull
./install.sh
sudo systemctl restart klipper
```

---

## 9. Moonraker Update Manager Config

Users can configure Moonraker to track and update the plugin.

### Kalico pip-installed

```ini
# moonraker.conf
[update_manager kalico-<extra_name>]
type: python
channel: stable
pip_environment: ~/klippy-env
primary_branch: main
origin: https://github.com/<owner>/<repo>.git
is_system_service: False
managed_services: klipper
```

### git-clone install

```ini
# moonraker.conf
[update_manager <extra_name>]
type: git_repo
channel: dev
path: ~/<repo>
origin: https://github.com/<owner>/<repo>.git
install_script: install.sh
is_system_service: False
managed_services: klipper
```

---

## 10. References

| Source | URL | Notes |
|---|---|---|
| Kalico plugin docs | <https://docs.kalico.gg/Kalico_Additions.html#plugins> | Official docs, minimal detail |
| Kalico config reference | <https://docs.kalico.gg/Config_Reference.html> | `[danger_options]` / `allow_plugin_override` |
| Klipper PR #6849 | <https://github.com/Klipper3d/klipper/pull/6849> | Canonical entry_points proposal; minimal pyproject.toml example |
| PyPI Trusted Publishing | <https://docs.pypi.org/trusted-publishers/> | OIDC / tokenless publishing setup |
| Pending Trusted Publisher | <https://docs.pypi.org/trusted-publishers/creating-a-project-through-oidc/> | Create project on first publish |
| `pypa/gh-action-pypi-publish` | <https://github.com/pypa/gh-action-pypi-publish> | Official publish action |
| PSR GitHub Actions docs | <https://python-semantic-release.readthedocs.io/en/latest/configuration/automatic-releases/github-actions.html> | PSR workflow examples |
| PSR + downstream trigger | <https://github.com/semantic-release/semantic-release/discussions/1906> | Why GITHUB_TOKEN cannot trigger downstream workflows |
| PyPI OIDC (GitHub Docs) | <https://docs.github.com/actions/deployment/security-hardening-your-deployments/configuring-openid-connect-in-pypi> | GitHub-side OIDC config |
| Klipper extras intro | <https://3dcoded.github.io/DynamicMacros/extras/extras-intro/> | How klippy extras work |
| hatch-vcs | <https://github.com/ofek/hatch-vcs> | VCS-based versioning for hatch |
| CalVer spec | <https://calver.org/> | CalVer naming conventions |
