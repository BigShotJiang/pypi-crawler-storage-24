# Belt Tension CV System — Implementation Spec

## Overview

A Klipper extra that automates CoreXY belt tension measurement and adjustment feedback
using a USB camera and OpenCV. Analogous to `SCREWS_TILT_ADJUST` — runs a macro,
measures both belts, and tells the user how much to turn each tensioner.

**Status:** Spec only. Hardware (InnoMaker OV9281 USB camera) on order.
**Target printer:** Voron 2.4 300mm, Klipper/Kalico, Beacon RevH, XOL2 toolhead,
neopixel LED strips (already configured).

---

## Background

### Physics

A belt under tension vibrates at a resonant frequency determined by:

```text
f = (n / 2L) * sqrt(T / μ)
```

- `f` = frequency (Hz)
- `L` = free span length (m)
- `T` = tension (N)
- `μ` = belt mass per unit length (kg/m)
- `n` = harmonic (1 = fundamental)

For a Voron 2.4 with a 150mm test span, target frequency is ~110–140 Hz.
A and B belts must match to within ~2 Hz.

### Stroboscopic Method

The stepper motor drives the belt at a swept or known frequency while a strobe
(neopixel LEDs) flashes at the same frequency. At resonance, the belt appears
frozen or oscillates with maximum amplitude. The camera captures this.

### CV Approach

Rather than requiring exact strobe sync, the primary method uses pixel-intensity
FFT on a belt ROI:

1. Drive stepper in 45° diagonal (isolates one belt in CoreXY kinematics)
2. Sample pixel intensity at belt midpoint over N frames
3. FFT of intensity time series → peak frequency = belt resonant frequency
4. Compare to target → compute adjustment

This is sensor-agnostic: works with or without hardware trigger sync.
Hardware trigger on InnoMaker OV9281 enables enhanced mode (strobe-locked frames).

---

## Hardware

### Camera

**InnoMaker U20CAM-9281M**

| Property | Value |
|---|---|
| Sensor | OmniVision OV9281, 1MP, 1/4" |
| Shutter | Global (all pixels exposed simultaneously) |
| Resolution | 1280×720 @ 120fps |
| Interface | USB 2.0, UVC (no driver needed) |
| Special | Hardware trigger input + strobe output pins (2.0mm header) |
| FOV | 148° M12 lens |
| Size | 32×32mm board |

**Why global shutter matters:** Rolling shutter cameras introduce per-row timing
skew at high framerates, creating banding artefacts under strobe that corrupt the
FFT signal. Global shutter exposes all pixels simultaneously — essential for
stroboscopic analysis.

### Mount

Camera mounts to the frame interior, aimed at the A belt free span when the
gantry is positioned at the calibration point (150mm from front idlers).
Mount to be 3D-printed; position TBD during hardware setup.

### Strobe Source

Existing neopixel LED strips on the Voron 2.4 frame, already configured in
Klipper. No additional hardware required. Controlled via existing
`[neopixel]` config or `SET_LED` gcode.

---

## Architecture

The system uses a **two-process, two-venv** design to avoid dependency conflicts.
The klippy extra is a thin shim with **zero external dependencies** that runs
inside klippy's own venv. The CV capture script runs in its own isolated venv
with numpy and opencv-python-headless.

| Component | Role | Venv | Dependencies |
|---|---|---|---|
| `belt_tension_cv.py` (klippy extra shim) | Registers GCode, positions toolhead, spawns CV subprocess | **klippy's venv** (`~/klippy-env/`) | None beyond klippy itself |
| `belt-tensioning-opencv` package (CV capture + FFT) | Camera capture, FFT analysis, returns JSON on stdout | **Its own venv** (`~/belt-tension-env/`) | numpy, opencv-python-headless |

**Why two venvs:** Installing numpy and opencv-python-headless into klippy's venv
could clobber klippy's pinned dependencies and break the printer firmware. The
klippy extra shim imports nothing outside the standard library and klippy's own
modules, so it is safe to symlink into `klippy/plugins/`.

```mermaid
flowchart TB
    subgraph KlippyVenv["klippy venv (~~/klippy-env/)"]
        extra["belt_tension_cv.py<br/>(klippy extra shim)"]
        extra --> |registers| macro["BELT_TENSION_ADJUST gcode"]
        extra --> |controls| toolhead["Toolhead positioning<br/>via toolhead.manual_move()"]
        extra --> |drives| stepper["Stepper excitation<br/>via diagonal moves"]
        extra --> |controls| strobe["Neopixel strobe via SET_LED"]
        extra --> |event| events["klippy:connect / klippy:ready<br/>event handlers"]
        extra --> |exposes| status["get_status() for Moonraker"]
    end

    extra --> |subprocess.Popen| cv_bin

    subgraph CVVenv["belt-tension venv (~~/belt-tension-env/)"]
        cv_bin["belt-tensioning-opencv<br/>(console_scripts entry point)"]
        cv_bin --> capture["CameraCapture"]
        cv_bin --> opencv["OpenCV"]
        cv_bin --> analyser["FrequencyAnalyser"]
        capture --> |/dev/video0| cam["OV9281 USB Camera"]
        analyser --> |stdout| output["JSON result"]
    end
```

### Component Responsibilities

**`belt_tension_cv.py`** — Klipper extra shim (symlinked into `klippy/plugins/`)

- Registers `BELT_TENSION_ADJUST` macro via `gcode.register_command()`
- Registers `klippy:connect` event handler for deferred hardware validation
- Handles all gcode movement (home, position toolhead at calibration point)
- Drives stepper excitation via `toolhead.manual_move()` diagonal oscillation
- Controls LED strobe via `SET_LED`
- Spawns CV capture subprocess using `subprocess.Popen()` with reactor-based
  non-blocking I/O (see [Subprocess Spawning](#subprocess-spawning))
- Receives frequency results as JSON on stdout
- Computes tension delta and adjustment turns
- Responds to user via `gcmd.respond_info()` (same pattern as `SCREWS_TILT_ADJUST`)
- Exposes `get_status()` for Moonraker/dashboard integration
- **Zero external dependencies** — imports only stdlib + klippy modules

**`belt-tensioning-opencv` package** — standalone CV capture (called as subprocess)

- Installed as a pip package with a `console_scripts` entry point
- Invoked as `~/belt-tension-env/bin/belt-tensioning-opencv`
- Opens `/dev/video0` via OpenCV
- Captures N frames at configured fps
- Computes per-belt frequency via FFT
- Returns JSON result to stdout, logs to stderr

### Plugin Discovery

Kalico discovers extras via `pkgutil.iter_modules()` scanning two filesystem
directories:

- `klippy/extras/` — built-in extras
- `klippy/plugins/` — third-party plugins

**Entry points are NOT a runtime discovery mechanism.** The
`[project.entry-points."klippy.extras"]` declaration in `pyproject.toml` is a
PyPI metadata convention for discoverability and install-script consumption.
Kalico's `printer.py` never reads `importlib.metadata` or `pkg_resources`.

The klippy extra shim must be **symlinked** into `klippy/plugins/` for Kalico
to find it. See [Installation](#installation).

---

## File Layout

```text
~/kalico/klippy/plugins/
└── belt_tension_cv.py          # Symlink → installed package's shim module

~/belt-tension-env/              # Isolated venv for CV dependencies
├── bin/
│   ├── python3
│   ├── pip
│   └── belt-tensioning-opencv   # console_scripts entry point
└── lib/python3.9/site-packages/
    └── belt_tensioning_opencv/  # Installed package
        ├── __init__.py
        ├── belt_tension_cv.py   # Klippy extra shim (symlink source)
        ├── capture.py           # Camera capture module
        ├── analysis.py          # FFT analysis module
        └── types.py             # Result dataclasses

~/printer_data/config/
├── belt_tension_cv.cfg          # [belt_tension_cv] config block
└── macros/
    └── belt_tension.cfg         # Optional: wrapper macro with RESPOND messages
```

---

## Installation

### Install the CV package

```shell
# Create isolated venv (Python 3.9+ for RPi compatibility)
python3 -m venv ~/belt-tension-env

# Install the belt-tensioning-opencv package
~/belt-tension-env/bin/pip install belt-tensioning-opencv
```

### Symlink the klippy extra into plugins

```shell
# For Kalico:
ln -sf ~/belt-tension-env/lib/python3.9/site-packages/belt_tensioning_opencv/belt_tension_cv.py \
       ~/kalico/klippy/plugins/belt_tension_cv.py

# For vanilla Klipper:
ln -sf ~/belt-tension-env/lib/python3.9/site-packages/belt_tensioning_opencv/belt_tension_cv.py \
       ~/klipper/klippy/extras/belt_tension_cv.py
```

### System dependencies (Raspberry Pi)

```shell
sudo apt install v4l-utils
# Verify camera visible:
v4l2-ctl --list-devices
v4l2-ctl -d /dev/video0 --list-formats-ext
```

### Configure printer.cfg

```ini
[include belt_tension_cv.cfg]
```

Add the `cv_venv_path` to the config so the shim knows where to find the CV
binary (see [Config Schema](#config-schema)).

### Install script (future)

An `install.sh` will automate the above steps, including:

1. Creating `~/belt-tension-env` venv
2. `pip install belt-tensioning-opencv`
3. Detecting Kalico vs vanilla Klipper (presence of `danger_options.py`)
4. Symlinking into the correct directory (`klippy/plugins/` or `klippy/extras/`)
5. Restarting klippy service

---

## Klipper Extra — `belt_tension_cv.py`

### Config Schema

```ini
[belt_tension_cv]

# Path to the belt-tension CV venv
# The shim spawns {cv_venv_path}/bin/belt-tensioning-opencv as a subprocess
cv_venv_path: ~/belt-tension-env

# USB camera device
camera_device: /dev/video0

# Camera framerate — must match OV9281 configured rate
camera_fps: 120

# Number of frames to capture per measurement
capture_frames: 120

# Belt span length at calibration position (mm)
# Voron 2.4: position gantry so XY idler centres are 150mm from front idlers
belt_span_mm: 150

# Target resonant frequency (Hz)
# Voron 2.4 300mm: 110–140 Hz recommended, 120 is a good default
target_frequency: 120.0

# Acceptable tolerance (Hz) — within this = OK, no adjustment needed
frequency_tolerance: 2.0

# Stepper drive frequency for excitation (Hz)
# Should match or sweep around target_frequency
excitation_frequency: 120.0

# Excitation amplitude (mm) — small back-and-forth move
excitation_amplitude: 1.0

# Neopixel name for strobe (must match [neopixel] config)
strobe_led: neopixel:chamber_leds

# Strobe colour when active (R G B, 0.0–1.0)
strobe_color: 1.0 1.0 1.0

# Calibration position — toolhead X,Y when measuring
# For Voron 2.4 300mm: centre of gantry, 150mm from front
calibration_x: 150
calibration_y: 150

# Z height during calibration
calibration_z: 20

# Belt span ROI in camera frame (pixels: x1,y1,x2,y2)
# Calibrated during initial setup — leave 0,0,0,0 for auto-detect
belt_a_roi: 0, 0, 0, 0
belt_b_roi: 0, 0, 0, 0

# Belt mass per unit length (kg/m) — Gates GT2 6mm open belt
# Default: 0.008 kg/m (standard value for Gates GT2 6mm)
belt_mu: 0.008
```

### Klippy Extra Skeleton

```python
class BeltTensionCV:
    """Klippy extra for automated belt tension measurement.

    Thin shim with zero external dependencies. Spawns the CV capture
    subprocess in an isolated venv to avoid dependency conflicts.
    """

    def __init__(self, config):
        self.printer = config.get_printer()
        self.gcode = self.printer.lookup_object("gcode")
        self.reactor = self.printer.get_reactor()
        self.name = config.get_name()

        # Config
        self.cv_venv_path = os.path.expanduser(
            config.get("cv_venv_path", "~/belt-tension-env")
        )
        self.camera_device = config.get("camera_device", "/dev/video0")
        self.camera_fps = config.getint("camera_fps", 120)
        self.capture_frames = config.getint("capture_frames", 120)
        self.target_frequency = config.getfloat("target_frequency", 120.0)
        self.frequency_tolerance = config.getfloat("frequency_tolerance", 2.0)
        self.excitation_frequency = config.getfloat("excitation_frequency", 120.0)
        self.excitation_amplitude = config.getfloat("excitation_amplitude", 1.0)
        self.calibration_x = config.getfloat("calibration_x")
        self.calibration_y = config.getfloat("calibration_y")
        self.calibration_z = config.getfloat("calibration_z")

        # State
        self.last_results = {}

        # Register command and events
        self.gcode.register_command(
            "BELT_TENSION_ADJUST",
            self.cmd_BELT_TENSION_ADJUST,
            desc=self.cmd_BELT_TENSION_ADJUST_help,
        )
        self.printer.register_event_handler("klippy:connect", self._handle_connect)

    cmd_BELT_TENSION_ADJUST_help = "Measure belt tension and report adjustment instructions"

    def _handle_connect(self):
        """Validate hardware availability at connect time.

        Runs after all config is parsed but before printing starts.
        Checks that the CV venv binary exists and camera device is present.
        """
        cv_binary = os.path.join(self.cv_venv_path, "bin", "belt-tensioning-opencv")
        if not os.path.isfile(cv_binary):
            raise self.printer.config_error(
                "belt_tension_cv: CV binary not found at '%s'. "
                "Install with: %s/bin/pip install belt-tensioning-opencv"
                % (cv_binary, self.cv_venv_path)
            )

    def get_status(self, eventtime):
        """Expose state to Moonraker and display clients.

        Returns:
            dict: Last measurement results including frequencies,
            deltas, and adjustment instructions.
        """
        return {
            "last_results": self.last_results,
        }

    def cmd_BELT_TENSION_ADJUST(self, gcmd):
        """Execute belt tension measurement sequence."""
        # ... implementation in Phase 2
        pass


def load_config(config):
    """Klippy module entry point."""
    return BeltTensionCV(config)
```

### Macro Interface

```gcode
BELT_TENSION_ADJUST
```

Optional parameters:

```gcode
BELT_TENSION_ADJUST BELT=A          # measure single belt
BELT_TENSION_ADJUST EXCITE=120      # override excitation frequency
BELT_TENSION_ADJUST FRAMES=240      # override frame count
BELT_TENSION_ADJUST CALIBRATE_ROI=1 # interactive ROI setup mode
```

### Expected Output (mirrors SCREWS_TILT_ADJUST style)

```text
// Belt Tension Calibration
// Positioning toolhead to calibration point...
// Measuring Belt A (45° diagonal move)...
// Measuring Belt B (45° diagonal move)...
//
// Belt A: 94.2 Hz  →  TIGHTEN  ~1.8 turns  (target: 120 Hz, delta: -25.8 Hz)
// Belt B: 121.4 Hz →  OK       (target: 120 Hz, delta: +1.4 Hz)
//
// Adjust Belt A and run BELT_TENSION_ADJUST again to verify.
```

If within tolerance:

```text
// Belt A: 119.1 Hz →  OK
// Belt B: 120.8 Hz →  OK
// Belts are within tolerance (±2.0 Hz). Tension is good.
```

### Turns Calculation

Approximation based on empirical relationship between tensioner screw turns
and frequency change. Configurable coefficient; default derived from common
Voron tensioner geometry (~5 Hz per quarter turn as starting estimate).

```python
TURNS_PER_HZ = 0.05   # configurable, empirically tuned per printer
delta_hz = target - measured
turns = abs(delta_hz) * TURNS_PER_HZ
direction = "TIGHTEN" if delta_hz > 0 else "LOOSEN"
```

This coefficient should be exposed as a config option and refined after
first real-world use.

---

## Subprocess Spawning

The klippy extra spawns the CV capture script as a subprocess using the
**belt-tension venv's entry point**. This must be done without blocking
the klippy reactor thread.

### Pattern (based on `gcode_shell_command.py`)

```python
def _run_cv_capture(self, gcmd, belt, roi):
    """Spawn CV capture subprocess with reactor-safe I/O.

    Uses subprocess.Popen with reactor.register_fd() for non-blocking
    stdout reading, and reactor.pause() polling loop with timeout.
    Never uses subprocess.run() or time.sleep().

    Args:
        gcmd: GCode command context for respond_info output.
        belt: Belt identifier ("A" or "B").
        roi: ROI tuple (x1, y1, x2, y2).

    Returns:
        dict: Parsed JSON result from CV capture.

    Raises:
        gcmd.error: On subprocess timeout or non-zero exit.
    """
    cv_binary = os.path.join(self.cv_venv_path, "bin", "belt-tensioning-opencv")
    cmd = [
        cv_binary,
        "--device", self.camera_device,
        "--fps", str(self.camera_fps),
        "--frames", str(self.capture_frames),
        "--belt", belt,
        "--roi", "%d,%d,%d,%d" % roi,
    ]

    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
    except Exception:
        raise gcmd.error("Failed to start CV capture: %s" % cv_binary)

    # Non-blocking reactor polling (never use time.sleep!)
    timeout = self.capture_frames / self.camera_fps + 30.0  # generous timeout
    eventtime = self.reactor.monotonic()
    endtime = eventtime + timeout
    while eventtime < endtime:
        eventtime = self.reactor.pause(eventtime + 0.05)
        if proc.poll() is not None:
            break
    else:
        proc.terminate()
        raise gcmd.error("CV capture timed out after %.0fs" % timeout)

    if proc.returncode != 0:
        stderr_out = proc.stderr.read().decode("utf-8", errors="replace")
        raise gcmd.error("CV capture failed (exit %d): %s"
                         % (proc.returncode, stderr_out[:200]))

    stdout_data = proc.stdout.read().decode("utf-8")
    return json.loads(stdout_data)
```

### Key constraints

- **Never use `subprocess.run()`** — it blocks the reactor thread.
- **Never use `time.sleep()`** — use `reactor.pause(reactor.monotonic() + delay)`
  instead. Klippy is single-threaded with a reactor event loop; blocking calls
  freeze all printer operations.
- **Use `reactor.register_fd()`** for verbose/streaming output (optional, shown
  in `gcode_shell_command.py` for live output forwarding).

---

## Camera/CV Script — `belt-tensioning-opencv`

### Interface

```shell
~/belt-tension-env/bin/belt-tensioning-opencv \
  --device /dev/video0 \
  --fps 120 \
  --frames 120 \
  --belt A \
  --roi 200,100,600,400    # x1,y1,x2,y2 pixels, 0,0,0,0 = full frame
```

stdout: JSON result

```json
{
  "belt": "A",
  "frequency_hz": 94.2,
  "amplitude": 0.42,
  "confidence": 0.87,
  "fps_actual": 119.6,
  "frames_captured": 120
}
```

stderr: debug/log output (ignored by caller unless `--verbose`)

Exit codes: `0` = success, `1` = camera error, `2` = analysis error

### CV Pipeline

```python
def measure_belt_frequency(cap, roi, n_frames, fps):
    """Sample mean pixel intensity in belt ROI over n_frames.

    FFT the intensity time series to find dominant frequency.

    Args:
        cap: OpenCV VideoCapture object.
        roi: Tuple of (x1, y1, x2, y2) pixel coordinates.
        n_frames: Number of frames to capture.
        fps: Expected camera framerate for frequency calculation.

    Returns:
        Tuple of (frequency_hz, amplitude, confidence).

    Raises:
        CameraError: If frame capture fails.
    """
    intensities = []
    t_start = time.monotonic()

    for _ in range(n_frames):
        ret, frame = cap.read()
        if not ret:
            raise CameraError("Frame capture failed")
        x1, y1, x2, y2 = roi
        roi_frame = frame[y1:y2, x1:x2]
        gray = cv2.cvtColor(roi_frame, cv2.COLOR_BGR2GRAY)
        intensities.append(float(gray.mean()))

    t_elapsed = time.monotonic() - t_start
    fps_actual = n_frames / t_elapsed

    # FFT
    arr = np.array(intensities)
    arr -= arr.mean()                          # remove DC
    window = np.hanning(len(arr))
    arr_w = arr * window
    fft = np.abs(np.fft.rfft(arr_w))
    freqs = np.fft.rfftfreq(len(arr), d=1/fps_actual)

    # Find peak (skip DC bin 0)
    peak_idx = np.argmax(fft[1:]) + 1
    peak_freq = freqs[peak_idx]
    peak_amp = fft[peak_idx]

    # Confidence: ratio of peak to RMS of rest of spectrum
    rest = np.delete(fft, peak_idx)
    confidence = float(peak_amp / (np.sqrt(np.mean(rest**2)) + 1e-9))
    confidence = min(confidence / 10.0, 1.0)   # normalise to 0–1

    return peak_freq, float(peak_amp), confidence
```

### ROI Auto-Detection (future / `CALIBRATE_ROI=1` mode)

When ROI is `0,0,0,0`, attempt to auto-detect belt:

1. Capture reference frame with belt stationary
2. Capture frame with belt vibrating
3. Frame-difference → high-motion region = belt span
4. Bounding box of high-motion region → suggested ROI
5. Print ROI coords to user for manual confirmation and config update

### Camera Initialisation

```python
def open_camera(device, fps, width=1280, height=720):
    """Open and configure the USB camera for belt measurement.

    Args:
        device: V4L2 device path (e.g., /dev/video0).
        fps: Target framerate.
        width: Frame width in pixels.
        height: Frame height in pixels.

    Returns:
        cv2.VideoCapture: Configured capture object.

    Raises:
        CameraError: If camera cannot be opened.
    """
    cap = cv2.VideoCapture(device, cv2.CAP_V4L2)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
    cap.set(cv2.CAP_PROP_FPS, fps)
    # Disable auto-exposure — critical for consistent intensity sampling
    cap.set(cv2.CAP_PROP_AUTO_EXPOSURE, 1)   # 1 = manual on V4L2
    cap.set(cv2.CAP_PROP_EXPOSURE, -6)        # starting value, tune per environment
    if not cap.isOpened():
        raise CameraError(f"Cannot open camera: {device}")
    return cap
```

**Critical:** Auto-exposure must be disabled. If the camera auto-adjusts exposure
while the belt is vibrating under strobe, the intensity signal is corrupted.

---

## Stepper Excitation

CoreXY belt isolation via 45° diagonal moves:

```text
Belt A only: move in direction (+X+Y) / (-X-Y)  →  only motor A active
Belt B only: move in direction (+X-Y) / (-X+Y)  →  only motor B active
```

The klippy extra uses `toolhead.manual_move()` for diagonal oscillation at the
excitation frequency. This is the same approach used by `resonance_tester.py`
for vibration generation.

```python
def _excite_belt(self, gcmd, belt, cycles=10):
    """Oscillate the toolhead diagonally to excite a single belt.

    Uses toolhead.manual_move() to generate small diagonal moves that
    isolate one belt in CoreXY kinematics. Timing uses reactor.pause()
    to avoid blocking the reactor thread.

    Args:
        gcmd: GCode command context.
        belt: Belt identifier ("A" or "B").
        cycles: Number of oscillation cycles.
    """
    toolhead = self.printer.lookup_object("toolhead")
    pos = toolhead.get_position()
    amp = self.excitation_amplitude
    period = 1.0 / self.excitation_frequency
    half_period = period / 2.0

    # Direction multiplier: A = (+X+Y), B = (+X-Y)
    y_sign = 1.0 if belt == "A" else -1.0
    speed = amp * 4.0 * self.excitation_frequency  # feedrate for oscillation

    for _ in range(cycles):
        target_fwd = [pos[0] + amp, pos[1] + amp * y_sign, pos[2], pos[3]]
        toolhead.manual_move(target_fwd, speed)
        eventtime = self.reactor.pause(
            self.reactor.monotonic() + half_period
        )
        target_back = [pos[0] - amp, pos[1] - amp * y_sign, pos[2], pos[3]]
        toolhead.manual_move(target_back, speed)
        eventtime = self.reactor.pause(
            self.reactor.monotonic() + half_period
        )

    # Return to centre
    toolhead.manual_move(pos, speed)
    toolhead.wait_moves()
```

**Note:** Do NOT use `FORCE_MOVE` for excitation. `toolhead.manual_move()` is the
correct API for controlled motion that respects kinematics and limits. Study
`resonance_tester.py`'s vibration generation for the reference pattern.

---

## LED Strobe

```python
def set_strobe(self, frequency_hz, enabled):
    """Flash neopixels at frequency_hz via Klipper SET_LED + reactor timer.

    Args:
        frequency_hz: Strobe frequency in Hz.
        enabled: Whether to enable or disable the strobe.
    """
    if not enabled:
        self.gcode.run_script_from_command(
            "SET_LED LED=%s RED=0 GREEN=0 BLUE=0" % self.strobe_led
        )
        return
    # Strobe implemented as rapid SET_LED on/off via reactor timer
    # Period = 1/frequency_hz, 50% duty cycle
    period = 1.0 / frequency_hz
    self._strobe_active = True
    self._strobe_timer = self.reactor.register_timer(
        self._strobe_callback, self.reactor.monotonic()
    )

def _strobe_callback(self, eventtime):
    """Reactor timer callback for strobe toggling.

    Args:
        eventtime: Current reactor event time.

    Returns:
        float: Next callback time, or NEVER to stop.
    """
    if not self._strobe_active:
        return self.reactor.NEVER
    half_period = 0.5 / self._strobe_frequency
    r, g, b = self.strobe_color
    # Toggle based on current state
    if self._strobe_on:
        self.gcode.run_script_from_command(
            "SET_LED LED=%s RED=0 GREEN=0 BLUE=0 SYNC=0" % self.strobe_led
        )
        self._strobe_on = False
    else:
        self.gcode.run_script_from_command(
            "SET_LED LED=%s RED=%.2f GREEN=%.2f BLUE=%.2f SYNC=0"
            % (self.strobe_led, r, g, b)
        )
        self._strobe_on = True
    return eventtime + half_period
```

**Note:** Klipper's `SET_LED` with `SYNC=0` is non-blocking. The strobe uses a
reactor timer callback instead of a background thread, keeping all execution
on the reactor thread. Hardware trigger on OV9281 pins is the path to precise
sync, implemented as a future enhancement.

---

## Dependencies

### Raspberry Pi (system)

```shell
sudo apt install v4l-utils
# Verify camera visible:
v4l2-ctl --list-devices
v4l2-ctl -d /dev/video0 --list-formats-ext
```

### Belt-tension venv (`~/belt-tension-env/`)

```text
# Installed via pip install belt-tensioning-opencv
opencv-python-headless>=4.8.0
numpy>=1.24.0
```

### Klippy extra shim

No additional dependencies. Uses only Python stdlib and klippy's own modules.
The shim must NOT import numpy, opencv, or any package not available in
klippy's venv.

---

## Configuration in `printer.cfg`

```ini
[include belt_tension_cv.cfg]
```

```ini
# belt_tension_cv.cfg
[belt_tension_cv]
cv_venv_path: ~/belt-tension-env
camera_device: /dev/video0
camera_fps: 120
capture_frames: 120
belt_span_mm: 150
target_frequency: 120.0
frequency_tolerance: 2.0
excitation_frequency: 120.0
excitation_amplitude: 1.0
strobe_led: chamber_leds
strobe_color: 1.0 1.0 1.0
calibration_x: 150
calibration_y: 150
calibration_z: 20
belt_a_roi: 0, 0, 0, 0
belt_b_roi: 0, 0, 0, 0
belt_mu: 0.008
```

---

## Implementation Phases

### Phase 1 — Camera + CV script (no printer needed)

Implement and validate `belt_cv_capture.py` in isolation:

- Open OV9281, verify 120fps, verify global shutter
- Disable auto-exposure
- Capture frames of a vibrating belt (plucked manually)
- Validate FFT correctly identifies pluck frequency vs phone app reading
- Tune ROI, frame count, windowing

**Deliverable:** `belt_cv_capture.py` that correctly identifies frequency of a
manually plucked belt within ±2 Hz of a phone app reading.

### Phase 2 — Klipper extra skeleton

Implement `belt_tension_cv.py` Klipper extra shim:

- Config parsing (including `cv_venv_path`)
- `BELT_TENSION_ADJUST` macro registration
- `klippy:connect` event handler for hardware validation
- `get_status()` method for Moonraker integration
- Toolhead positioning via `toolhead.manual_move()`
- Subprocess invocation of `belt-tensioning-opencv` via `Popen` + reactor polling
- Result parsing + `gcmd.respond_info()` output
- No stepper excitation yet — measure manually plucked belts

**Deliverable:** `BELT_TENSION_ADJUST` runs, positions toolhead, user plucks belt,
frequency reported and adjustment instructions given.

### Phase 3 — Stepper excitation

Add automatic belt excitation via stepper moves:

- 45° diagonal oscillation via `toolhead.manual_move()` to isolate A/B belts
- Frequency sweep if excitation_frequency not known
- Validate excitation actually produces measurable signal in camera

**Deliverable:** Fully automated — no manual plucking needed.

### Phase 4 — Strobe integration

Add LED strobe synchronised to excitation:

- Neopixel strobe at excitation frequency via reactor timer
- Validate stroboscopic standing wave visible in camera
- Potentially switch CV method to amplitude-peak detection
  rather than FFT (simpler under strobe conditions)

### Phase 5 — Hardware trigger (stretch)

Use OV9281 hardware trigger input pin to sync camera frames to strobe:

- Requires physical wire from Pi GPIO → camera trigger header
- Eliminates software timing jitter
- Enables sub-millisecond frame sync

---

## Open Questions / Calibration TODOs

1. **`TURNS_PER_HZ` coefficient** — needs empirical calibration on actual printer.
   Start with 0.05 (5% turn per Hz), adjust after first real measurement session.

2. **Camera mount position** — exact frame position TBD once hardware arrives.
   Must be fixed relative to the 150mm test span belt segment.

3. **Exposure value** — `-6` is a starting point for enclosed printer with strobe.
   Will need tuning per ambient light conditions.

4. **ROI calibration** — run `BELT_TENSION_ADJUST CALIBRATE_ROI=1` after mounting
   camera to auto-detect belt region and populate `belt_a_roi` / `belt_b_roi`.

5. **Excitation feedrate** — the speed value for the 45° oscillation moves needs
   tuning to produce clean resonance without inducing ringing elsewhere in the frame.

6. **Kalico vs vanilla Klipper compatibility** — the install script should detect
   which firmware is running (presence of `danger_options.py`) and symlink into
   the correct directory accordingly.

---

## Reference

- Voron belt tensioning docs: target 110–140 Hz at 150mm span
- Gates GT2 6mm belt: μ ≈ 0.008 kg/m
- OV9281 datasheet: global shutter, 1MP, max 120fps at 1280×720
- Klipper extras API: `klippy/extras/screws_tilt_adjust.py` — reference implementation
- Klipper extras API: `klippy/extras/resonance_tester.py` — vibration generation, event handlers, `get_status()`
- Klipper extras API: `klippy/extras/gcode_shell_command.py` — subprocess spawning with reactor
- InnoMaker OV9281 trigger/strobe pins: 2.0mm header, TTL level
- Kalico plugin discovery: `klippy/printer.py:182-199` — `pkgutil.iter_modules()` on `extras/` and `plugins/`
