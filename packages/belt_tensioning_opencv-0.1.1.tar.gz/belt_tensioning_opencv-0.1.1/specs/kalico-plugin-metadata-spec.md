# Kalico Plugin Metadata Specification

**Status**: Draft
**Date**: 2026-03-20
**Depends on**: [Kalico PR #705](https://github.com/KalicoCrew/kalico/pull/705)
**Companion to**: `specs/kalico-plugin-spec.md`

## Summary

This spec defines a declarative metadata convention for Kalico plugins
distributed via PyPI. It enables Kalico to check plugin compatibility
**before loading**, complementing the existing `require_kalico()` runtime
check defined in `kalico-plugin-spec.md` section 1.3.

## Scope

This spec covers Kalico only. Klipper does not have a plugin auto-loading
system and is supported via the legacy `install.sh` symlink/copy mechanism
described in `kalico-plugin-spec.md` section 8.2. The metadata entry point
is ignored by Klipper — it simply doesn't read it.

## Kalico CalVer

Kalico uses CalVer: `YYYY.MM.PATCH`

- `YYYY` = full year
- `MM` = short month (no zero-padding)
- `PATCH` = incremental hotfix counter, resets each month

Examples: `2025.3.0`, `2025.3.1`, `2026.1.0`

PEP 440 comparison works correctly — segments are compared numerically
left-to-right. A simple tuple comparison is sufficient:

```python
tuple(int(x) for x in "2025.3.1".split("."))  # (2025, 3, 1)
```

## Two Complementary Compatibility Mechanisms

### 1. Runtime Check (Plugin-Side) — Existing

Defined in `kalico-plugin-spec.md` section 1.3. The plugin calls
`require_kalico()` inside `load_config()`. This is controlled by the plugin
author, works without any Kalico-side support, and raises a `RuntimeError`
if the version is out of range.

```python
def load_config(config):
    require_kalico("2025.3.0")
    return MyPlugin(config)
```

**Pros**: Works today, no Kalico changes needed.
**Cons**: Only checked after module import; error appears as a load failure
rather than a clear compatibility message.

### 2. Declarative Metadata (Host-Side) — This Spec

The plugin declares version bounds via a `kalico.plugin_metadata` entry point.
Kalico reads this **before** importing the plugin module. This allows Kalico to
provide clear error messages, skip loading entirely, and report compatibility
in diagnostic tools like the proposed `KALICO_PLUGINS` GCode command.

**Pros**: Checked before import; Kalico controls the UX; enables tooling.
**Cons**: Requires Kalico-side support (proposed in the plugin safety
enhancements RFC, additive to PR #705).

### Recommendation

Use **both**. The declarative metadata provides better UX when Kalico supports
it. The runtime `require_kalico()` check is a safety net that works everywhere,
including on Kalico versions that predate metadata support.

## Entry Point Convention

### `kalico.plugins` (Module Registration)

This is defined by PR #705. Plugin modules are registered here:

```toml
[project.entry-points."kalico.plugins"]
belt_tension_cv = "belt_tensioning_opencv.belt_tension_cv"
```

### `kalico.plugin_metadata` (Version Metadata)

Plugin metadata is registered as a separate entry point that resolves to a
dict object. The entry point name **must match** the corresponding
`kalico.plugins` entry point name:

```toml
[project.entry-points."kalico.plugin_metadata"]
belt_tension_cv = "belt_tensioning_opencv:PLUGIN_METADATA"
```

Note the `:` syntax — this points to an **attribute** (`PLUGIN_METADATA`)
on the module, not the module itself.

## Metadata Dict

The metadata is a plain dict defined in the plugin package's `__init__.py`
(or any module — the entry point controls the location):

```python
# src/belt_tensioning_opencv/__init__.py

PLUGIN_METADATA = {
    # Required: minimum Kalico CalVer version
    "min_kalico_version": "2025.3.0",

    # Optional: maximum Kalico CalVer version (exclusive upper bound)
    # None = no upper bound
    "max_kalico_version": None,

    # Optional: CalVer series explicitly tested against
    # Format: "YYYY.MM" (no patch — matches any patch in that month)
    "supported_versions": ["2025.3", "2025.4", "2026.1"],
}
```

### Field Definitions

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `min_kalico_version` | `str` | Yes | Minimum CalVer version (inclusive). Format: `"YYYY.MM.PATCH"`. Plugin will not load on older Kalico. |
| `max_kalico_version` | `str \| None` | No | Maximum CalVer version (exclusive). `None` = no upper bound. Use when a known breaking change makes the plugin incompatible. |
| `supported_versions` | `list[str]` | No | CalVer series explicitly tested. Format: `"YYYY.MM"` (matches any patch). If present and the running Kalico series is not listed, Kalico logs a warning but still loads the plugin. |

### Behavior Matrix

| Condition | Action |
|-----------|--------|
| Kalico >= `min_kalico_version` AND series in `supported_versions` | Load normally |
| Kalico >= `min_kalico_version` AND series NOT in `supported_versions` | Load with warning: "Plugin untested on Kalico YYYY.MM" |
| Kalico < `min_kalico_version` | **Block load**, log error: "requires Kalico >= YYYY.MM.PATCH" |
| Kalico >= `max_kalico_version` | **Block load**, log error: "does not support Kalico >= YYYY.MM.PATCH" |
| No `kalico.plugin_metadata` entry point | Load unconditionally (backward compat) |
| Metadata entry point exists but fails to load | Load with warning: "metadata failed to load" |

## Full pyproject.toml Example

```toml
[project]
name = "belt-tensioning-opencv"
version = "0.1.0"
description = "Kalico extra for automated CoreXY belt tension measurement using OpenCV"
readme = "README.md"
license = { text = "MIT" }
requires-python = ">=3.9"
dependencies = [
    "numpy>=1.24.0",
    "opencv-python-headless>=4.8.0",
]

# Kalico plugin registration (PR #705)
[project.entry-points."kalico.plugins"]
belt_tension_cv = "belt_tensioning_opencv.belt_tension_cv"

# Kalico plugin metadata (this spec)
[project.entry-points."kalico.plugin_metadata"]
belt_tension_cv = "belt_tensioning_opencv:PLUGIN_METADATA"

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["src/belt_tensioning_opencv"]
```

## Version Comparison Implementation

No external dependencies. CalVer tuple comparison is sufficient:

```python
def _parse_calver(version_string: str) -> tuple[int, ...]:
    """Parse a CalVer string like '2025.3.1' into a comparable tuple."""
    return tuple(int(x) for x in version_string.strip().split("."))

def _calver_series(version_string: str) -> str:
    """Extract the YYYY.MM series from a full CalVer version."""
    parts = version_string.strip().split(".")
    return f"{parts[0]}.{parts[1]}"
```

This is identical to the approach used in the existing `require_kalico()`
runtime check — no `packaging` library needed.

## Klipper Compatibility

This metadata system is **Kalico-only**. Klipper does not:

- Read `kalico.plugins` entry points
- Read `kalico.plugin_metadata` entry points
- Have any plugin auto-loading system

Klipper users install plugins via the legacy `install.sh` script that copies
the module file into `klippy/extras/` (see `kalico-plugin-spec.md` section
8.2). The `PLUGIN_METADATA` dict and entry points are simply ignored — they
are inert Python objects that have no effect when the module is loaded via
the symlink/copy path.

The `require_kalico()` runtime check also gracefully handles Klipper:

```python
try:
    v = tuple(int(x) for x in version("kalico").split("."))
except PackageNotFoundError:
    return  # Kalico not pip-installed (Klipper); skip check
```

## Relationship to Kalico Plugin Safety Enhancements RFC

This spec defines the **plugin-side convention**. The Kalico-side
implementation that reads and acts on this metadata is proposed in the
[Plugin Safety Enhancements RFC](../../docs/design/pip-plugin-autoload.md)
(Enhancement 1: CalVer Version Compatibility), which is additive to PR #705.

Until that Kalico-side implementation lands:

- The `kalico.plugin_metadata` entry point is registered but not read
- The `PLUGIN_METADATA` dict exists but is inert
- The `require_kalico()` runtime check is the active safety mechanism

Once both sides are implemented, plugins get two layers of protection:

1. Kalico checks metadata before import (clear UX, diagnostic tooling)
2. Plugin checks version after import (safety net, works everywhere)

## References

| Source | URL |
|--------|-----|
| Kalico PR #705 | <https://github.com/KalicoCrew/kalico/pull/705> |
| Kalico CalVer | `kalico-plugin-spec.md` section 1.2 |
| Runtime version check | `kalico-plugin-spec.md` section 1.3 |
| Klipper legacy install | `kalico-plugin-spec.md` section 8.2 |
| Python entry points | <https://setuptools.pypa.io/en/latest/userguide/entry_point.html> |
| Plugin Safety RFC | `docs/design/pip-plugin-autoload.md` (in kalico repo) |
