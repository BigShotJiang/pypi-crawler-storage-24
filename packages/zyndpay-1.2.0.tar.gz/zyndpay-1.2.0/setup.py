from setuptools import setup, find_packages

setup(
    name="zyndpay",
    version="1.2.0",
    description="Official ZyndPay Python SDK — accept USDT payments with a few lines of code",
    long_description=open("README.md").read() if __import__("os").path.exists("README.md") else "",
    long_description_content_type="text/markdown",
    author="ZyndPay",
    author_email="dev@zyndpay.io",
    url="https://github.com/zyndpay/zyndpay-python",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    python_requires=">=3.8",
    install_requires=["requests>=2.28.0"],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    keywords=["zyndpay", "crypto", "usdt", "trc20", "payment-gateway"],
)
