"""
FastMCP Server for CodeSecure Scanner.

Exposes security scanning capabilities via MCP protocol.

Implements:
- SS-001: Orchestrates security tool execution via MCP
- SS-013: MCP server with all tools for IDE integration
- SS-007: Async job management with progress tracking
"""

import asyncio
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastmcp import FastMCP, Context

from codesecure.common.logging import get_logger, audit_logger
from codesecure.common.models import JobStatus, ScanMode
from codesecure.common.cloud_provider import CloudProvider
from codesecure.jobs.manager import get_job_manager
from codesecure.scanners.engine import get_scanner_engine
from codesecure.ai_providers.manager import get_ai_manager
from codesecure.reports.generator import get_report_generator
from codesecure.common.models import Finding
from codesecure.common.models import ScanResult
from codesecure.common.config_manager import load_config
from codesecure.common.config_manager import load_config


logger = get_logger(__name__)

# Create FastMCP server
server = FastMCP("CodeSecure Scanner")


async def create_scan_job(
    path: str,
    scanners: Optional[List[str]] = None,
    mode: str = "local",
    cloud_provider: str = "none",
    ctx_logger: Any = None,
) -> Dict[str, str]:
    """Core logic to create a scan job."""
    scan_path = Path(path).resolve()
    if not scan_path.exists():
        raise ValueError(f"Path does not exist: {path}")
    
    # Parse enums
    try:
        scan_mode = ScanMode(mode.lower())
    except ValueError:
        scan_mode = ScanMode.LOCAL
        
    try:
        provider = CloudProvider(cloud_provider.lower())
    except ValueError:
        provider = CloudProvider.NONE
    
    job_manager = get_job_manager()
    
    # define container for job_id
    job_id_box = {"id": None}
    
    async def scan_task():
        # Wait briefly for ID to be populated
        for _ in range(50):
            if job_id_box["id"]:
                break
            await asyncio.sleep(0.01)
            
        job_id = job_id_box["id"]
        scanner_engine = get_scanner_engine()
        
        if not job_id:
            logger.error("Failed to acquire job ID for progress tracking")
            return await scanner_engine.run_scan(scan_path, scanners, scan_mode)

        async def progress_cb(pct, msg):
            await job_manager.update_job(job_id, pct, status=JobStatus.RUNNING)
            # Log specific progress points
            if pct % 10 == 0:
                logger.debug(f"Job {job_id} progress {pct}%: {msg}")
        
        try:
            # Run scan
            result = await scanner_engine.run_scan_with_progress(
                scan_path, 
                job_id, 
                scanners, 
                scan_mode, 
                timeout=480, 
                progress_callback=progress_cb,
                cloud_provider=provider
            )
            
            return result
            
        except Exception as e:
            logger.error(f"Scan job {job_id} failed: {e}")
            raise

    # Create the job with the task
    scan_job_id = await job_manager.create_job("scan", scan_task())
    
    # Populate the box so the task can use it
    job_id_box["id"] = scan_job_id
    
    if ctx_logger:
        res = ctx_logger(f"Started scan job: {scan_job_id}")
        if asyncio.iscoroutine(res):
            await res
        
    return {
        "job_id": scan_job_id,
        "status": "pending",
        "message": "Scan job created successfully"
    }


@server.tool()
async def run_scan_local(
    path: str,
    scanners: Optional[List[str]] = None,
    mode: str = "local",
    cloud_provider: str = "none",
    ctx: Context = None,
) -> Dict[str, str]:
    """
    Start a security scan on a local path.
    
    Returns a job_id immediately for progress tracking.
    
    Args:
        path: Absolute path to the directory to scan
        scanners: Optional list of specific scanners to run (default: all)
        mode: Execution mode ("local" or "container")
        cloud_provider: Cloud provider for AI analysis ("google", "aws", "azure", "none")
    
    Returns:
        Dictionary containing job_id and status
    """
    return await create_scan_job(
        path, scanners, mode, cloud_provider, 
        ctx_logger=ctx.info if ctx else None
    )


@server.tool()
async def get_scan_status(
    job_id: str,
) -> Dict[str, Any]:
    """
    Get the status of a running scan job.
    
    Args:
        job_id: The job ID returned by run_scan_local
        
    Returns:
        Status dictionary with progress, state, and errors
    """
    return await fetch_scan_status(job_id)

@server.tool()
async def enrich_findings(
    findings: List[Dict[str, Any]],
    ai_provider: str = "none",
    api_key: Optional[str] = None
) -> List[Dict[str, Any]]:
    """
    Enrich findings with centralized AI analysis (including False Positive evaluation).

    Args:
        findings: Array of finding dict objects from a scan result.
        ai_provider: Provider name ('google', 'openai', 'anthropic', or 'none').
        api_key: Optional API key override for the chosen provider.
        
    Returns:
        Array of enriched finding objects.
    """
    if not findings or ai_provider.lower() == "none":
         return findings
         
    manager = get_ai_manager(
        ai_provider_override=ai_provider,
        api_key_override=api_key
    )
    
    if not manager._primary_provider or not manager._primary_provider.is_available:
         logger.warning(f"AI Provider {ai_provider} unavailable for enrichment.")
         return findings

    try:
        # Convert dicts back to Finding models for the Core Engine
        finding_models = []
        for f in findings:
             # Use the basic fields to reconstruct.
             model = Finding(
                 id=f.get('id', ''),
                 scanner=f.get('scanner', ''),
                 title=f.get('title', ''),
                 description=f.get('description', ''),
                 severity=f.get('severity', 'info'),  # String severity works generally in parser
                 file_path=f.get('filePath', ''),
                 line_start=f.get('line', 0),
                 line_end=f.get('endLine', 0),
                 code_snippet=f.get('codeSnippet', ''),
             )
             finding_models.append(model)
             
        # Call the Core Manager (batch size and FP thresholds are central)
        enhanced_models = await manager.enrich_findings(finding_models, is_workspace_scan=True)
        
        # Merge back to raw dicts for transport
        enhanced_dict = {em.id: em for em in enhanced_models}
        
        results = []
        for raw in findings:
            fid = raw.get('id')
            if fid in enhanced_dict:
                em = enhanced_dict[fid]
                
                # Expand standard raw with enriched fields
                # Filter out anything flagged > 90% confidence as False Positive
                if em.is_false_positive and (em.false_positive_confidence or 0.0) >= 0.90:
                    continue # Exclude from returned list natively
                    
                raw["remediationCode"] = em.remediation_code
                raw["remediationDescription"] = em.remediation_guidance
                raw["isFalsePositive"] = em.is_false_positive
                raw["falsePositiveConfidence"] = em.false_positive_confidence
                raw["falsePositiveReason"] = em.fp_explanation
                results.append(raw)
            else:
                results.append(raw)
                
        return results
        
    except Exception as e:
        logger.error(f"Enrichment failed in MCP: {e}")
        return findings


async def fetch_scan_status(job_id: str) -> Dict[str, Any]:
    """Core logic to fetch scan status."""
    job_manager = get_job_manager()
    status_data = await job_manager.get_status(job_id)
    
    if not status_data:
        return {"error": "Job not found", "jobId": job_id, "status": "failed"}
        
    # Map to VS Code ScanStatusResponse interface
    return {
        "jobId": job_id,
        "status": status_data.get("state", "PENDING").lower(),
        "progress": status_data.get("progress", 0),
        "message": status_data.get("error", ""),
        "error": status_data.get("error")
    }


@server.tool()
async def get_scan_result(
    job_id: str,
) -> Dict[str, Any]:
    """
    Get the final results of a completed scan.
    
    Args:
        job_id: The job ID
        
    Returns:
        Scan result dictionary containing findings or error details
    """
    return await fetch_scan_result(job_id)


@server.tool()
async def list_scanners(
    mode: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """
    List available security scanners.
    
    Args:
        mode: Optional mode to filter by ("local" or "container")
    """
    engine = get_scanner_engine()
    scan_mode = None
    if mode:
        try:
            scan_mode = ScanMode(mode.lower())
        except ValueError:
            pass
            
    return engine.get_scanners_metadata(scan_mode)


@server.tool()
async def generate_report(
    job_id: str,
    formats: List[str] = ["html"],
    output_dir: str = "./codesecure_reports"
) -> Dict[str, str]:
    """
    Generate reports from a completed scan job.
    
    Args:
        job_id: The ID of the completed scan job
        formats: List of formats to generate ("html", "json", "sarif", "markdown")
        output_dir: Output directory relative to workspace or absolute path
        
    Returns:
        Dictionary mapping format to generated file path
    """
    job_manager = get_job_manager()
    result = await job_manager.get_result(job_id)
    
    if result is None:
        return {"error": f"Job {job_id} not found or not completed."}
        
    # Rehydrate if it's a dict
    if isinstance(result, dict):
        try:
            result = ScanResult.model_validate(result)
        except Exception as e:
            return {"error": f"Failed to parse result model: {e}"}
            
    try:
        generator = get_report_generator()
        out_path = Path(output_dir).resolve()
        
        generated_files = {}
        for fmt in formats:
            try:
                path = generator.generate(result, fmt, out_path)
                generated_files[fmt] = str(path)
            except Exception as e:
                generated_files[fmt] = f"Error: {str(e)}"
                
        return generated_files
    except Exception as e:
        logger.error(f"Report generation failed: {e}")
        return {"error": str(e)}


async def fetch_scan_result(job_id: str) -> Dict[str, Any]:
    """Core logic to fetch scan result and transform for VS Code (CamelCase)."""
    job_manager = get_job_manager()
    result = await job_manager.get_result(job_id)
    
    if result is None:
        status_data = await job_manager.get_status(job_id)
        if status_data:
            return {"status": status_data["state"].lower(), "message": "Result not available yet"}
        return {"error": "Job not found"}
        
    # If it's already an error dict, return it
    if isinstance(result, dict) and "error" in result:
        return result

    # Convert Pydantic/Dataclass model to dict if needed
    data = result.model_dump() if hasattr(result, "model_dump") else result
    if hasattr(result, "__dict__") and not isinstance(result, dict):
        data = result.__dict__
    
    raw_findings = data.get("findings", [])
    logger.info("Found %d findings in job %s", len(raw_findings), job_id)
    
    # 1. Map findings to CamelCase for VS Code
    findings = []
    for f in raw_findings:
        # Handle both dict and object finding representation
        f_id = f.get("id") if isinstance(f, dict) else getattr(f, "id", "")
        f_scanner = f.get("scanner") if isinstance(f, dict) else getattr(f, "scanner", "")
        f_title = f.get("title") if isinstance(f, dict) else getattr(f, "title", "")
        f_desc = f.get("description") if isinstance(f, dict) else getattr(f, "description", "")
        
        # Severity might be an enum
        f_sev = f.get("severity") if isinstance(f, dict) else getattr(f, "severity", "")
        if hasattr(f_sev, "value"):
            f_sev = f_sev.value

        f_path = f.get("file_path") if isinstance(f, dict) else getattr(f, "file_path", "")
        f_line = f.get("line_start") if isinstance(f, dict) else getattr(f, "line_start", 0)
        f_end = f.get("line_end") if isinstance(f, dict) else getattr(f, "line_end", 0)
        
        f_rem_code = f.get("remediation_code") if isinstance(f, dict) else getattr(f, "remediation_code", "")
        f_rem_desc = f.get("remediation_guidance") if isinstance(f, dict) else getattr(f, "remediation_guidance", "")
        f_cwe = f.get("cwe_ids") if isinstance(f, dict) else getattr(f, "cwe_ids", [])
        f_code_snippet = f.get("code_snippet") if isinstance(f, dict) else getattr(f, "code_snippet", "")
        
        findings.append({
            "id": f_id,
            "ruleId": f_id, # Fallback ruleId to ID
            "scanner": f_scanner,
            "title": f_title,
            "description": f_desc,
            "severity": f_sev,
            "filePath": f_path,
            "line": f_line,
            "column": 0,
            "endLine": f_end,
            "codeSnippet": f_code_snippet,
            "remediationCode": f_rem_code,
            "remediationDescription": f_rem_desc,
            "cweIds": f_cwe,
        })

    # 2. Build scanSummary block (required by TS interface)
    counts = {}
    for f in findings:
        sev = str(f["severity"]).lower()
        counts[sev] = counts.get(sev, 0) + 1

    summary = {
        "totalFindings": len(findings),
        "critical": counts.get("critical", 0),
        "high": counts.get("high", 0),
        "medium": counts.get("medium", 0),
        "low": counts.get("low", 0),
        "info": counts.get("info", 0),
        "scannersRun": data.get("scanners_run", []) if isinstance(data, dict) else getattr(result, "scanners_run", []),
        "scannersFailed": data.get("errors", []) if isinstance(data, dict) else getattr(result, "errors", []),
        "durationSeconds": data.get("duration_seconds", 0) if isinstance(data, dict) else getattr(result, "duration_seconds", 0)
    }

    # 3. Final TS-compatible structure
    return {
        "jobId": job_id,
        "findings": findings,
        "scanSummary": summary,
        "success": data.get("success", True) if isinstance(data, dict) else getattr(result, "success", True)
    }


@server.tool()
async def get_configuration(
    directory: str
) -> Dict[str, Any]:
    """
    Fetch the centralized .codesecure.yml configuration for a given directory.
    
    Args:
        directory: Path to the workspace or project directory
        
    Returns:
        JSON representation of the parsed CodeSecureConfig
    """
    try:
        config = load_config(directory)
        return config.model_dump()
    except Exception as e:
        logger.error(f"Failed to load configuration for {directory}: {e}")
        return {}


def main():
    """Entry point for the FastMCP server."""
    import sys
    print("CodeSecure MCP Server: Starting initialization...", file=sys.stderr)
    from codesecure.common.config import ensure_storage_dirs
    ensure_storage_dirs()
    print("CodeSecure MCP Server: Storage verified. Starting FastMCP...", file=sys.stderr)
    server.run()

if __name__ == "__main__":
    main()
