"""Main module for numeral system conversions.

This module provides the ``swopy()`` method which serves as the primary interface
for converting numbers between different numeral systems (Roman, Egyptian, Arabic, etc.)
It handles bidirectional conversions by delegating to the appropriate system
implementations.
"""
# Ignore ambiguous unicode character strings in numerals (e.g., 'I' vs 'Ⅰ').
# ruff: noqa: RUF002 RUF003

from inspect import getmembers, isclass
from typing import Any, Literal

from . import systems
from .system import Denotation, Numeral, System


def swop[
    TFromNumeral: Numeral,
    TFromDenotation: Denotation,
    TToNumeral: Numeral,
    TToDenotation: Denotation,
](
    numeral: TFromNumeral,
    from_system: type[System[TFromNumeral, TFromDenotation]],
    to_system: type[System[TToNumeral, TToDenotation]],
    encode: Literal["utf8", "ascii"] = "utf8",
) -> TToNumeral:
    """Universal converter for numeral system transformations.

    Provides a simple interface to convert numbers between different numeral
    systems. Validates input against both source and target system constraints,
    then performs the conversion via python-native numbers.


    Type Parameters:
        TFromNumeral: The representation of the numeral in the system being converted
            from
        TFromDenotation: The denotation being represented in the system being converted
            from
        TToNumeral: The representation of the numeral in the system being converted to
        TToDenotation: The denotation being represented in the system being converted to

    Args:
        numeral: The numeral to convert, in whatever format the source system accepts
        from_system: The source numeral system
        to_system: The target numeral system

    Returns:
        The numeral in the target system in an appropriate type based on the system's
            implementation

    Raises:
        ValueError: If the denotation is outside the valid range for either system
        ValueError: If the numeral representation is invalid in either system
        TypeError: If there are no overlapping numeral and/or denotation types between
            the systems

    Examples:
        >>> swop(10, systems.hindu_arabic.Arabic, systems.egyptian.Egyptian)
        '\U00013386'
        >>> swop('Ⅹ', systems.roman.Standard, systems.egyptian.Egyptian)
        '\U00013386'
        >>> swop('Ⅹ', systems.roman.Standard, systems.roman.Standard)
        'Ⅹ'
    """

    intermediate: TFromDenotation = from_system.from_numeral_trusted(numeral)

    if to_system.is_valid_denotation(intermediate):
        return to_system.to_numeral_trusted(intermediate, encode=encode)

    raise TypeError(
        f"{intermediate} of type {type(intermediate).__name__} cannot be represented in {to_system.__name__}."  # noqa: E501
    )


def get_all_systems() -> dict[str, type[System[Any, Any]]]:
    """Discovers and returns all available numeral systems

    Provides easy discovery of all supported numeral systems without
    requiring knowledge of the systems module structure.

    Returns:
        A dictionary mapping system names to their corresponding System classes.
            Keys are of the form ``module.class`` and values are the System subclass
            objects, e.g.

            {'roman.Standard': <class 'swopy.systems.roman.Standard',
             'aramaic.Hatran': <class 'swopy.systems.aramaic.Hatran',
             }
    Examples:
        >>> all_systems = get_all_systems()
        >>> 'roman.Standard' in all_systems
        True
        >>> 'hindu_arabic.Arabic' in all_systems
        True

        Get system properties:
        >>> all_systems = get_all_systems()
        >>> roman = all_systems['roman.Early']
        >>> roman.minimum
        1
        >>> roman.maximum
        899
    """
    result: dict[str, type[System[Any, Any]]] = {}

    for module_name in getattr(systems, "__all__", []):
        module = getattr(systems, module_name)

        for _, obj in getmembers(module):
            if isclass(obj) and issubclass(obj, System):
                if obj.__name__ == "System":
                    continue
                result[f"{obj.__module__.split('.')[-1]}.{obj.__name__}"] = obj

    return result
