"""Brahmi-Tai script family numeral system converters.

This module implements numeral systems from scripts derived from Brahmi and
used in Tai-language contexts.
Currently supports:

    Ahom  U+11700-U+1174F

Ahom uses ten positional decimal digit glyphs (0-9) identical in structure to
the Arabic base-10 system. Numbers are encoded as a sequence of digit glyphs
representing the decimal expansion, most-significant digit first. The block
also contains dedicated signs for ten (U+1173A) and twenty (U+1173B) used in
manuscript contexts; these are accepted as input but the positional decimal
encoding is used for output.
"""

from collections.abc import Mapping
from fractions import Fraction
from math import inf
from typing import ClassVar

from ..system import Encodings, System
from ._algorithms import positional_to_numeral


class Ahom(System[str, int]):
    """Implements bidirectional conversion between non-negative integers and Ahom
    numerals.

    - Uses Unicode block U+11730-U+11739 (digit glyphs 0-9) within block U+11700-U+1174F
    - The system is positional in base 10, written most-significant digit first
    - Dedicated signs for ten (U+1173A) and twenty (U+1173B) are accepted as input
      but not emitted

    Attributes:
        minimum: Minimum valid value (0)
        maximum: Maximum valid value (+infinity)
        maximum_is_many: False - no natural bound exists
        encodings: UTF-8 only
    """

    minimum: ClassVar[int | float | Fraction] = 0
    maximum: ClassVar[int | float | Fraction] = inf
    maximum_is_many: ClassVar[bool] = False
    encodings: ClassVar[Encodings] = {"utf8"}

    _to_numeral_map: Mapping[int, str] = {i: chr(0x11730 + i) for i in range(10)}

    _from_numeral_map: Mapping[str, int] = {
        **{chr(0x11730 + i): i for i in range(10)},
        "\U0001173a": 10,  # 𑜺 AHOM NUMBER TEN
        "\U0001173b": 20,  # 𑜻 AHOM NUMBER TWENTY
    }

    @classmethod
    def _to_numeral(cls, denotation: int) -> str:
        """Convert a non-negative integer to Ahom numerals.

        Encodes ``denotation`` as a sequence of Ahom digit glyphs representing its
        decimal expansion, most-significant digit first. Zero is represented
        by the single zero glyph.

        Examples:
            >>> Ahom._to_numeral(0)
            '\U00011730'
            >>> Ahom._to_numeral(1)
            '\U00011731'
            >>> Ahom._to_numeral(9)
            '\U00011739'
            >>> Ahom._to_numeral(10)
            '\U00011731\U00011730'
            >>> Ahom._to_numeral(42)
            '\U00011734\U00011732'
            >>> Ahom._to_numeral(100)
            '\U00011731\U00011730\U00011730'
        """
        return positional_to_numeral(denotation, cls._to_numeral_map, 10)

    @classmethod
    def _from_numeral(cls, numeral: str) -> int:
        """Convert an Ahom numeral to an integer.

        Scans each character left-to-right. Positional digit glyphs (U+11730-
        U+11739) accumulate using ``total = total * 10 + digit``. The dedicated
        ten (U+1173A) and twenty (U+1173B) signs are treated as additive
        contributions of 10 and 20.

        Examples:
            >>> Ahom._from_numeral('\U00011730')
            0
            >>> Ahom._from_numeral('\U00011731')
            1
            >>> Ahom._from_numeral('\U00011739')
            9
            >>> Ahom._from_numeral('\U00011731\U00011730')
            10
            >>> Ahom._from_numeral('\U00011734\U00011732')
            42
            >>> Ahom._from_numeral('\U0001173a')
            10
            >>> Ahom._from_numeral('\U0001173b')
            20
            >>> Ahom._from_numeral('?')
            Traceback (most recent call last):
                ...
            ValueError: Invalid Ahom character: '?'
        """
        _digit_base = 0x11730
        total = 0
        for char in numeral:
            if char not in cls._from_numeral_map:
                raise ValueError(f"Invalid Ahom character: {char!r}")
            cp = ord(char)
            if _digit_base <= cp <= _digit_base + 9:
                total = total * 10 + (cp - _digit_base)
            else:
                total += cls._from_numeral_map[char]
        return total
