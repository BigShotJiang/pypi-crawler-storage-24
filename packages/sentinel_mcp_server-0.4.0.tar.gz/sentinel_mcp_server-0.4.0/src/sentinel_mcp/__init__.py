"""Sentinel MCP Server — Expose Sentinel prediction market API as MCP tools."""

__version__ = "0.3.0"
