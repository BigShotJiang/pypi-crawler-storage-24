from bclearer_core.bie.domain.bie_domain_objects import (
    BieDomainObjects,
)
from bclearer_core.bie.top.bie_base_identities import (
    BieBaseIdentities,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.common_knowledge.bie_domain_types import (
    BieDomainTypes,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.objects.bie_ids import (
    BieIds,
)


class SumObjects(BieDomainObjects):
    def __init__(
        self,
        direction_type: BieDomainTypes,
        bie_summed_type: BieDomainTypes,
        member_bie_ids: tuple[BieIds, ...],
        bie_base_identity: BieBaseIdentities,
    ):
        self.direction_type = (
            direction_type
        )

        self.bie_summed_type = (
            bie_summed_type
        )

        self.member_bie_ids = tuple(
            member_bie_ids
        )

        super().__init__(
            bie_base_identity=bie_base_identity,
        )
