# from abc import ABC
#
# from bclearer_orchestration_services.identification_services.b_identity_ecosystem.bie_id_creation_module.identity_vectors import (
#     BieIdentityVectorBase,
# )
# from bclearer_orchestration_services.snapshot_universe_service.objects.snapshots import (
#     Snapshots,
# )
#
#
# class SnapshotsFusions(
#     Snapshots,
#     ABC,
# ):
#     pass
