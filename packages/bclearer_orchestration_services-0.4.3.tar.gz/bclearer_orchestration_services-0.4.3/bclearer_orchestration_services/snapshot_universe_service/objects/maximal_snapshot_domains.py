from typing import TYPE_CHECKING

from bclearer_core.bie.top.bie_base_identities import (
    BieBaseIdentities,
)
from bclearer_orchestration_services.snapshot_universe_service.objects.snapshot_domains import (
    SnapshotDomains,
)

if TYPE_CHECKING:
    from bclearer_core.infrastructure.session.app_run_session.app_run_session_objects import (
        AppRunSessionObjects,
    )


class MaximalSnapshotDomains(
    SnapshotDomains,
):
    def __init__(
        self,
        *,
        app_run_session_object: "AppRunSessionObjects",
        bie_base_identity: BieBaseIdentities,
    ):
        self._app_run_session_object = (
            app_run_session_object
        )

        super().__init__(
            bie_base_identity=bie_base_identity,
        )
