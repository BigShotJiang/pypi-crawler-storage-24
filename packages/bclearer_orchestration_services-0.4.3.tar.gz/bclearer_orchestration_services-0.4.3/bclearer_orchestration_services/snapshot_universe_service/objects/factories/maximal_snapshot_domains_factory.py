from typing import TYPE_CHECKING

from bclearer_core.bie.top.bie_base_identities import (
    BieBaseIdentities,
    create_bie_base_identity_from_bie_identity_vector,
)
from bclearer_core.infrastructure.session.bie_id_registerers.bie_id_registerer import (
    BieIdRegisterer,
)
from bclearer_orchestration_services.file_system_snapshot_service.universe.bie.bie_id_creators.file_system_snapshot_identity_vectors import (
    MaximalSnapshotDomainIdentityVector,
    MaximalSnapshotDomainIdentityVectorPlaces,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.common_knowledge.bie_core_relation_types import (
    BieCoreRelationTypes,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.objects.bie_ids import (
    BieIds,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.registrations.helpers.registerers.bie_id_issue_requests import (
    RelationBieIdRequest,
)
from bclearer_orchestration_services.identification_services.naming_service.b_sequence_names import (
    BSequenceNames,
)
from bclearer_orchestration_services.snapshot_universe_service.objects.maximal_snapshot_domains import (
    MaximalSnapshotDomains,
)

if TYPE_CHECKING:
    from bclearer_core.infrastructure.session.app_run_session.app_run_session_objects import (
        AppRunSessionObjects,
    )


def create_maximal_snapshot_domains(
    *,
    app_run_session_object: "AppRunSessionObjects",
    snapshot_universe_bie_id: BieIds,
    bie_id_registerer: BieIdRegisterer,
) -> MaximalSnapshotDomains:
    bie_base_identity = _create_maximal_snapshot_domain_bie_base_identity(
        app_run_session_object=app_run_session_object,
    )
    maximal_snapshot_domains = MaximalSnapshotDomains(
        app_run_session_object=app_run_session_object,
        bie_base_identity=bie_base_identity,
    )
    bie_id_registerer.register_bie_id(
        bie_base_identity=bie_base_identity,
    )
    bie_id_registerer.issue_and_register_bie_id(
        request=RelationBieIdRequest(
            bie_place_1_id=maximal_snapshot_domains.bie_id,
            bie_place_2_id=snapshot_universe_bie_id,
            bie_relation_type_id=BieCoreRelationTypes.BIE_COUPLES.item_bie_identity,
            b_sequence_name=BSequenceNames(
                initial_b_sequence_name_list=[
                    "maximal_snapshot_domain_couples"
                ]
            ),
        )
    )
    return maximal_snapshot_domains


def _create_maximal_snapshot_domain_bie_base_identity(
    *,
    app_run_session_object: "AppRunSessionObjects",
) -> BieBaseIdentities:
    places = MaximalSnapshotDomainIdentityVectorPlaces(
        app_run_session_bie_id=app_run_session_object.bie_id,
    )
    return create_bie_base_identity_from_bie_identity_vector(
        identity_vector=MaximalSnapshotDomainIdentityVector(
            places=places,
        )
    )
