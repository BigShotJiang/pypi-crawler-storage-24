from bclearer_core.bie.top.bie_base_identities import (
    BieBaseIdentities,
    create_bie_base_identity_from_bie_identity_vector,
)
from bclearer_core.infrastructure.session.bie_id_registerers.bie_id_registerer import (
    BieIdRegisterer,
)
from bclearer_interop_services.file_system_service.objects.files import (
    Files,
)
from bclearer_orchestration_services.file_system_snapshot_service.universe.bie.bie_id_creators.file_system_snapshot_identity_vectors import (
    FileByteContentIdentityVector,
    FileByteContentIdentityVectorPlaces,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.bie_id_creation_module.bie_id_creation_facade import (
    BieIdCreationFacade,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.bie_id_creation_module.identity_vectors.standard_identity_vectors import (
    EmptyUntypedIdentityVector,
)
from bclearer_orchestration_services.snapshot_universe_service.objects.file_file_byte_contents import (
    FileFileByteContents,
)


def create_file_file_byte_contents(
    *,
    file: Files,
    bie_id_registerer: BieIdRegisterer,
) -> FileFileByteContents:
    bie_base_identity, content_bie_id = _create_file_file_byte_content_bie_base_identity(
        file=file,
    )
    file_file_byte_contents = FileFileByteContents(
        file=file,
        content_bie_id=content_bie_id,
        bie_base_identity=bie_base_identity,
    )
    bie_id_registerer.register_bie_id(
        bie_base_identity=bie_base_identity,
    )
    return file_file_byte_contents


def _create_file_file_byte_content_bie_base_identity(
    *,
    file: Files,
) -> tuple[BieBaseIdentities, object]:
    with open(
        file.absolute_path_string,
        mode="rb",
    ) as python_native_file:
        file_content_as_bytes = python_native_file.read()

    content_bie_id = BieIdCreationFacade.create_bie_id_for_single_object(
        input_object=file_content_as_bytes,
    )

    if content_bie_id.is_empty:
        bie_base_identity = create_bie_base_identity_from_bie_identity_vector(
            identity_vector=EmptyUntypedIdentityVector(),
        )
    else:
        places = FileByteContentIdentityVectorPlaces(
            content_bie_id=content_bie_id,
        )
        bie_base_identity = create_bie_base_identity_from_bie_identity_vector(
            identity_vector=FileByteContentIdentityVector(
                bie_hr_name=file.base_name,
                places=places,
            )
        )

    return bie_base_identity, content_bie_id
