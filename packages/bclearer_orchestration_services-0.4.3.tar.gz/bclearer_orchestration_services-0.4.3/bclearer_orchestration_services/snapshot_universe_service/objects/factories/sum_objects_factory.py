from bclearer_core.bie.top.bie_base_identities import (
    create_bie_base_identity_from_bie_identity_vector,
)
from bclearer_orchestration_services.file_system_snapshot_service.universe.bie.bie_id_creators.file_system_snapshot_identity_vectors import (
    SumObjectIdentityVector,
    SumObjectIdentityVectorPlaces,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.common_knowledge.bie_domain_types import (
    BieDomainTypes,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.objects.bie_ids import (
    BieIds,
)
from bclearer_orchestration_services.snapshot_universe_service.common_knowledge.bie_snapshot_sum_domain_types import (
    BieSnapshotSumDomainTypes,
)
from bclearer_orchestration_services.snapshot_universe_service.common_knowledge.snapshot_domain_literals import (
    SnapshotDomainLiterals,
)
from bclearer_orchestration_services.snapshot_universe_service.objects.sum_objects import (
    SumObjects,
)


def create_sum_object(
    *,
    direction_type: BieDomainTypes,
    bie_summed_type: BieDomainTypes,
    member_bie_ids: tuple[BieIds, ...],
) -> SumObjects:
    places = SumObjectIdentityVectorPlaces(
        direction_type=direction_type,
        bie_summed_type=bie_summed_type,
        member_bie_ids=tuple(member_bie_ids),
    )
    bie_base_identity = create_bie_base_identity_from_bie_identity_vector(
        identity_vector=SumObjectIdentityVector(
            bie_type=BieSnapshotSumDomainTypes.SUM_OBJECTS,
            bie_hr_name=SnapshotDomainLiterals.sum_object,
            places=places,
        )
    )
    return SumObjects(
        direction_type=direction_type,
        bie_summed_type=bie_summed_type,
        member_bie_ids=member_bie_ids,
        bie_base_identity=bie_base_identity,
    )
