from bclearer_core.bie.top.bie_base_identities import (
    BieBaseIdentities,
    create_bie_base_identity_from_bie_identity_vector,
)
from bclearer_core.infrastructure.session.bie_id_registerers.bie_id_registerer import (
    BieIdRegisterer,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.bie_id_creation_module.identity_vectors.standard_identity_vectors import (
    EmptyUntypedIdentityVector,
)
from bclearer_orchestration_services.snapshot_universe_service.objects.folder_file_byte_contents import (
    FolderFileByteContents,
)


def create_folder_file_byte_contents(
    *,
    bie_id_registerer: BieIdRegisterer,
) -> FolderFileByteContents:
    bie_base_identity = _create_folder_file_byte_content_bie_base_identity()
    folder_file_byte_contents = FolderFileByteContents(
        bie_base_identity=bie_base_identity,
    )
    bie_id_registerer.register_bie_id(
        bie_base_identity=bie_base_identity,
    )
    return folder_file_byte_contents


def _create_folder_file_byte_content_bie_base_identity() -> BieBaseIdentities:
    return create_bie_base_identity_from_bie_identity_vector(
        identity_vector=EmptyUntypedIdentityVector(),
    )
