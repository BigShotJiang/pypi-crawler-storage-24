from abc import ABC

from bclearer_orchestration_services.snapshot_universe_service.objects.object_contents import (
    ObjectContents,
)


class AlgorithmicContents(
    ObjectContents,
    ABC,
):
    pass
