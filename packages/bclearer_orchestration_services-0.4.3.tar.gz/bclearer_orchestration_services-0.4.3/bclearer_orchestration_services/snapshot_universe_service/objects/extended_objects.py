from abc import ABC
from typing import Optional

from bclearer_core.bie.domain.bie_domain_objects import (
    BieDomainObjects,
)
from bclearer_core.bie.top.bie_base_identities import (
    BieBaseIdentities,
)


class ExtendedObjects(
    BieDomainObjects,
    ABC,
):
    def __init__(
        self,
        bie_base_identity: BieBaseIdentities,
    ):
        super().__init__(
            bie_base_identity=bie_base_identity,
        )

        from bclearer_orchestration_services.snapshot_universe_service.objects.snapshots import (
            Snapshots,
        )

        self.snapshot: Optional[Snapshots] = None

    def set_snapshot(
        self, snapshot: "Snapshots"
    ):
        from bclearer_orchestration_services.snapshot_universe_service.objects.snapshots import (
            Snapshots,
        )

        if not isinstance(
            snapshot, Snapshots
        ):
            raise TypeError

        self.snapshot = snapshot
