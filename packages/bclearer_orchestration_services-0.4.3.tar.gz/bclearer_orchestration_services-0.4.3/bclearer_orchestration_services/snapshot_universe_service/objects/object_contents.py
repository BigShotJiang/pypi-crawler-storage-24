from abc import ABC

from bclearer_orchestration_services.snapshot_universe_service.objects.extended_objects import (
    ExtendedObjects,
)


class ObjectContents(
    ExtendedObjects,
    ABC,
):
    pass
