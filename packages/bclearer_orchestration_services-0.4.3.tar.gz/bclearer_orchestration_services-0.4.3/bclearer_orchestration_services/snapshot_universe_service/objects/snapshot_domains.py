from abc import ABC

from bclearer_core.bie.top.bie_base_identities import (
    BieBaseIdentities,
)
from bclearer_orchestration_services.snapshot_universe_service.objects.snapshots import (
    Snapshots,
)


class SnapshotDomains(
    Snapshots,
    ABC,
):
    def __init__(
        self,
        bie_base_identity: BieBaseIdentities,
    ):
        super().__init__(
            bie_base_identity=bie_base_identity,
        )
