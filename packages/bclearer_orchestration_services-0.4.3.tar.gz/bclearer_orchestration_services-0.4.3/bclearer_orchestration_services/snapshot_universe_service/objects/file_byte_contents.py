from abc import ABC

from bclearer_core.bie.top.bie_base_identities import (
    BieBaseIdentities,
)
from bclearer_orchestration_services.file_system_snapshot_service.universe.common_knowledge.bie_file_system_snapshot_domain_types import (
    BieFileSystemSnapshotDomainTypes,
)
from bclearer_orchestration_services.snapshot_universe_service.objects.algorithmic_contents import (
    AlgorithmicContents,
)
from bclearer_orchestration_services.snapshot_universe_service.common_knowledge.snapshot_domain_literals import (
    SnapshotDomainLiterals,
)


class FileByteContents(
    AlgorithmicContents,
    ABC,
):
    def __init__(
        self,
        bie_base_identity: BieBaseIdentities,
    ):
        super().__init__(
            bie_base_identity=bie_base_identity,
        )

        # File byte contents can legitimately have an empty bie_id, but they still
        # need a stable domain type so snapshot dictionaries key them correctly.
        self.base_hr_name = (
            SnapshotDomainLiterals.file_byte_content
        )

        self.bie_type = (
            BieFileSystemSnapshotDomainTypes.BIE_FILE_BYTE_CONTENTS
        )
