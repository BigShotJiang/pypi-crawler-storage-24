# from abc import ABC
#
# from bclearer_orchestration_services.snapshot_universe_service.objects.snapshots import (
#     Snapshots,
# )
#
#
# class IndividualSnapshots(
#     Snapshots,
#     ABC,
# ):
#     pass
