from bclearer_interop_services.file_system_service.objects.files import (
    Files,
)
from bclearer_core.bie.top.bie_base_identities import (
    BieBaseIdentities,
)
from bclearer_orchestration_services.snapshot_universe_service.objects.file_byte_contents import (
    FileByteContents,
)


class FileFileByteContents(
    FileByteContents
):
    def __init__(
        self,
        file: Files,
        content_bie_id,
        bie_base_identity: BieBaseIdentities,
    ):
        self.file = file

        self.content_bie_id = (
            content_bie_id
        )

        super().__init__(
            bie_base_identity=bie_base_identity,
        )
