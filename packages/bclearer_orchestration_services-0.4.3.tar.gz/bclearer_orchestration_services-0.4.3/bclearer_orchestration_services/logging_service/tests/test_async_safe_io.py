import logging
import queue
import threading
import time
from logging.handlers import (
    QueueHandler,
    QueueListener,
)
from unittest.mock import Mock, patch

import pytest
from bclearer_core.configurations.b_configurations.b_logging_configurations import (
    BLoggingConfigurations,
)
from bclearer_orchestration_services.logging_service.log_shutdown import (
    shutdown_logging,
)
from bclearer_orchestration_services.logging_service.logging_library_extentions.standard_logging.level.handlers.log_queue_handlers import (
    build_queue_listener,
)
from bclearer_orchestration_services.logging_service.logging_library_extentions.standard_logging.level.loggers import (
    standard_logging_process_loggers,
)
from bclearer_orchestration_services.logging_service.logging_library_extentions.standard_logging.level.loggers.standard_logging_process_loggers import (
    StandardLoggingProcessLoggers,
)
from bclearer_orchestration_services.reporting_service.reporters.log_file import (
    LogFiles,
)
from bclearer_orchestration_services.reporting_service.reporters.websocket_log_publisher import (
    WebSocketLogPublisher,
)


class RecordingHandler(logging.Handler):
    def __init__(self):
        super().__init__()
        self.records = []
        self.event = threading.Event()

    def emit(self, record):
        self.records.append(record)
        self.event.set()


@pytest.fixture(autouse=True)
def reset_async_logging_state():
    shutdown_logging()
    BLoggingConfigurations.reset_to_defaults()
    LogFiles.reset()
    WebSocketLogPublisher._socket = None
    WebSocketLogPublisher._connected = (
        False
    )
    WebSocketLogPublisher._host = None
    WebSocketLogPublisher._port = None
    WebSocketLogPublisher._path = None
    WebSocketLogPublisher._enabled = (
        BLoggingConfigurations.ENABLE_SOCKET_LOGGING
    )
    WebSocketLogPublisher._ws_queue = (
        queue.Queue()
    )
    WebSocketLogPublisher._ws_thread = (
        None
    )
    StandardLoggingProcessLoggers._active_queue_listeners.clear()
    yield
    shutdown_logging()
    BLoggingConfigurations.reset_to_defaults()
    LogFiles.reset()
    WebSocketLogPublisher._ws_queue = (
        queue.Queue()
    )
    StandardLoggingProcessLoggers._active_queue_listeners.clear()


def test_build_queue_listener_routes_records():
    target_handler = RecordingHandler()
    queue_handler, queue_listener = (
        build_queue_listener(
            [target_handler],
        )
    )
    logger = logging.getLogger(
        "queue-test",
    )
    logger.handlers = [queue_handler]
    logger.setLevel(logging.INFO)
    logger.propagate = False

    try:
        queue_listener.start()
        logger.info("queued")
        assert (
            target_handler.event.wait(1)
        )
        assert target_handler.records[
            0
        ].getMessage() == ("queued")
        assert isinstance(
            queue_handler, QueueHandler,
        )
        assert isinstance(
            queue_listener,
            QueueListener,
        )
    finally:
        queue_listener.stop()
        logger.handlers.clear()


def test_standard_logging_process_logger_uses_queue(
    monkeypatch: pytest.MonkeyPatch,
):
    file_handler = RecordingHandler()
    sqlite_handler = RecordingHandler()
    monkeypatch.setattr(
        standard_logging_process_loggers,
        (
            "set_standard_logging_process_"
            "logging_levels"
        ),
        lambda standard_logging_process_logger: (
            standard_logging_process_logger.setLevel(
                logging.INFO,
            )
        ),
    )
    monkeypatch.setattr(
        standard_logging_process_loggers,
        (
            "set_standard_logging_process_"
            "console_handler"
        ),
        lambda standard_logging_process_logger: None,
    )
    monkeypatch.setattr(
        standard_logging_process_loggers,
        "get_process_file_handler",
        lambda: file_handler,
    )
    monkeypatch.setattr(
        standard_logging_process_loggers,
        "get_process_sqlite_handler",
        lambda: sqlite_handler,
    )

    logger = (
        StandardLoggingProcessLoggers(
            "async-process-logger",
        )
    )
    logger.info("queued message")

    assert (
        logger._queue_listener
        is not None
    )
    assert file_handler.event.wait(1)
    assert file_handler.records[
        0
    ].getMessage() == ("queued message")


def test_send_log_returns_without_socket_io(
    monkeypatch: pytest.MonkeyPatch,
):
    BLoggingConfigurations.ENABLE_SOCKET_LOGGING = (
        True
    )
    WebSocketLogPublisher._enabled = (
        True
    )
    monkeypatch.setattr(
        WebSocketLogPublisher,
        "_ensure_worker",
        lambda: None,
    )

    start_time = time.monotonic()
    with patch(
        
            "bclearer_orchestration_services."
            "reporting_service.reporters."
            "websocket_log_publisher.socket.socket",
        
    ) as socket_factory:
        WebSocketLogPublisher.send_log(
            "message",
        )
    elapsed = (
        time.monotonic() - start_time
    )

    assert elapsed < 0.1
    socket_factory.assert_not_called()


def test_shutdown_logging_is_idempotent():
    listener = Mock()
    StandardLoggingProcessLoggers._active_queue_listeners = [
        listener,
    ]

    shutdown_logging()
    shutdown_logging()

    listener.stop.assert_called_once()
