import atexit

from bclearer_orchestration_services.logging_service.logging_library_extentions.standard_logging.level.loggers.standard_logging_process_loggers import (
    StandardLoggingProcessLoggers,
)
from bclearer_orchestration_services.reporting_service.reporters.log_file import (
    LogFiles,
)
from bclearer_orchestration_services.reporting_service.reporters.websocket_log_publisher import (
    WebSocketLogPublisher,
)

_WEBSOCKET_JOIN_TIMEOUT_SECONDS = 0.5


def _stop_queue_listeners() -> None:
    listeners = list(
        StandardLoggingProcessLoggers._active_queue_listeners,
    )
    StandardLoggingProcessLoggers._active_queue_listeners.clear()
    for listener in listeners:
        listener.stop()


def _join_websocket_thread() -> None:
    WebSocketLogPublisher.request_shutdown()
    if (
        WebSocketLogPublisher._ws_thread
        is None
    ):
        return
    WebSocketLogPublisher._ws_thread.join(
        timeout=_WEBSOCKET_JOIN_TIMEOUT_SECONDS,
    )
    if (
        not WebSocketLogPublisher._ws_thread.is_alive()
    ):
        WebSocketLogPublisher._ws_thread = (
            None
        )


def shutdown_logging() -> None:
    _stop_queue_listeners()
    _join_websocket_thread()
    LogFiles.close_log_file()


atexit.register(shutdown_logging)
