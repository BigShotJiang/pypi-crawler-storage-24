import pytest
from bclearer_orchestration_services.logging_service.configuration.process_logging_levels import (
    ProcessLoggingLevels,
)


@pytest.mark.parametrize(
    ("level_name", "expected_level"),
    [
        (
            "DEBUG",
            ProcessLoggingLevels.PROCESS_LEVEL_10,
        ),
        (
            "INFO",
            ProcessLoggingLevels.PROCESS_LEVEL_7,
        ),
        (
            "WARNING",
            ProcessLoggingLevels.PROCESS_LEVEL_5,
        ),
        (
            "ERROR",
            ProcessLoggingLevels.PROCESS_LEVEL_3,
        ),
        (
            "CRITICAL",
            ProcessLoggingLevels.PROCESS_LEVEL_1,
        ),
    ],
)
def test_from_standard_level_returns_expected_member(
    level_name: str,
    expected_level: ProcessLoggingLevels,
):
    assert (
        ProcessLoggingLevels.from_standard_level(
            level_name,
        )
        is expected_level
    )


def test_from_standard_level_rejects_unknown_level():
    with pytest.raises(
        ValueError,
        match="Unknown standard logging level: TRACE",
    ):
        ProcessLoggingLevels.from_standard_level(
            "TRACE",
        )
