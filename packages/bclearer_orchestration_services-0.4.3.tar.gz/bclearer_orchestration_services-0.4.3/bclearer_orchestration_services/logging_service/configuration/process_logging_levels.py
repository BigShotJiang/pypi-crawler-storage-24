from enum import Enum


class ProcessLoggingLevels(Enum):
    PROCESS_LEVEL_NOT_GIVEN = 9999

    PROCESS_LEVEL_1 = 1000

    PROCESS_LEVEL_2 = 990

    PROCESS_LEVEL_3 = 980

    PROCESS_LEVEL_4 = 970

    PROCESS_LEVEL_5 = 960

    PROCESS_LEVEL_6 = 950

    PROCESS_LEVEL_7 = 940

    PROCESS_LEVEL_8 = 930

    PROCESS_LEVEL_9 = 920

    PROCESS_LEVEL_10 = 910

    @classmethod
    def from_standard_level(
        cls,
        level_str: str,
    ) -> "ProcessLoggingLevels":
        level_map = {
            "DEBUG": cls.PROCESS_LEVEL_10,
            "INFO": cls.PROCESS_LEVEL_7,
            "WARNING": cls.PROCESS_LEVEL_5,
            "ERROR": cls.PROCESS_LEVEL_3,
            "CRITICAL": cls.PROCESS_LEVEL_1,
        }

        try:
            return level_map[level_str]
        except KeyError as error:
            raise ValueError(
                f"Unknown standard logging level: {level_str}",
            ) from error
