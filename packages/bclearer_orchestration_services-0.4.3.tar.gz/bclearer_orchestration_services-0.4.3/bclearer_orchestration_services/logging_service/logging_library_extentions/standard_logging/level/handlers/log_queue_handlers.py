import logging
from logging.handlers import (
    QueueHandler,
    QueueListener,
)
from queue import Queue


def build_queue_listener(
    handlers: list[logging.Handler],
) -> tuple[
    QueueHandler,
    QueueListener,
]:
    record_queue: Queue = Queue()
    queue_handler = QueueHandler(
        record_queue,
    )
    queue_listener = QueueListener(
        record_queue,
        *handlers,
        respect_handler_level=True,
    )
    return queue_handler, queue_listener
