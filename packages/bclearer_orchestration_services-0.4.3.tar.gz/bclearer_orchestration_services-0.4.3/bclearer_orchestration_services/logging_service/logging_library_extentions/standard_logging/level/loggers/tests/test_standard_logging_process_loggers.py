import logging
from logging.handlers import (
    MemoryHandler,
)

import pytest
from bclearer_orchestration_services.logging_service.logging_library_extentions.standard_logging.level.loggers import (
    standard_logging_process_loggers,
)
from bclearer_orchestration_services.logging_service.logging_library_extentions.standard_logging.level.loggers.standard_logging_process_loggers import (
    StandardLoggingProcessLoggers,
)


def _raise_value_error() -> None:
    raise ValueError("boom")


@pytest.fixture
def logger_and_handler(
    monkeypatch: pytest.MonkeyPatch,
):
    monkeypatch.setattr(
        standard_logging_process_loggers,
        (
            "set_standard_logging_process_"
            "logging_levels"
        ),
        lambda standard_logging_process_logger: (
            standard_logging_process_logger.setLevel(
                logging.DEBUG,
            )
        ),
    )
    monkeypatch.setattr(
        standard_logging_process_loggers,
        (
            "set_standard_logging_process_"
            "console_handler"
        ),
        lambda standard_logging_process_logger: None,
    )
    monkeypatch.setattr(
        standard_logging_process_loggers,
        "get_process_file_handler",
        logging.NullHandler,
    )
    monkeypatch.setattr(
        standard_logging_process_loggers,
        "get_process_sqlite_handler",
        logging.NullHandler,
    )

    logger = (
        StandardLoggingProcessLoggers(
            "test-process-logger",
        )
    )
    handler = MemoryHandler(capacity=10)
    logger.propagate = False
    logger.addHandler(handler)
    yield logger, handler
    logger.handlers.clear()


@pytest.mark.parametrize(
    ("method_name", "level"),
    [
        ("debug", logging.DEBUG),
        ("info", logging.INFO),
        ("warning", logging.WARNING),
        ("error", logging.ERROR),
        ("critical", logging.CRITICAL),
    ],
)
def test_methods_emit_records(
    logger_and_handler,
    method_name: str,
    level: int,
):
    logger, handler = logger_and_handler

    getattr(logger, method_name)(
        method_name,
    )

    assert len(handler.buffer) == 1
    assert (
        handler.buffer[0].levelno
        == level
    )
    assert (
        handler.buffer[0].getMessage()
        == method_name
    )


def test_exc_info_passes_through(
    logger_and_handler,
):
    logger, handler = logger_and_handler

    try:
        _raise_value_error()
    except ValueError:
        logger.exception("failed")

    record = handler.buffer[0]
    assert record.exc_info is not None
    assert (
        record.exc_info[0] is ValueError
    )
