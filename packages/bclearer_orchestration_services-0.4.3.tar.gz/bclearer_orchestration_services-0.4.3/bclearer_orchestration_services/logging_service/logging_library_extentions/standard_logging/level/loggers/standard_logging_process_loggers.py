import logging

from bclearer_orchestration_services.logging_service.logging_library_extentions.standard_logging.level.handlers.log_queue_handlers import (
    build_queue_listener,
)
from bclearer_orchestration_services.logging_service.logging_library_extentions.standard_logging.level.loggers.helpers.standard_logging_process_console_handler_setter import (
    set_standard_logging_process_console_handler,
)
from bclearer_orchestration_services.logging_service.logging_library_extentions.standard_logging.level.loggers.helpers.standard_logging_process_file_handler_setter import (
    __get_standard_logging_process_file_handler as get_process_file_handler,
)
from bclearer_orchestration_services.logging_service.logging_library_extentions.standard_logging.level.loggers.helpers.standard_logging_process_logging_levels_setter import (
    set_standard_logging_process_logging_levels,
)
from bclearer_orchestration_services.logging_service.logging_library_extentions.standard_logging.level.loggers.helpers.standard_logging_process_sqlite_handler_setter import (
    __get_standard_logging_process_sqlite_handler as get_process_sqlite_handler,
)


class StandardLoggingProcessLoggers(
    logging.Logger,
):
    _active_queue_listeners = []

    def __init__(self, name):
        super().__init__(name)
        self._queue_listener = None
        set_standard_logging_process_logging_levels(
            standard_logging_process_logger=self,
        )

        set_standard_logging_process_console_handler(
            standard_logging_process_logger=self,
        )

        self._attach_async_handlers()

    def _attach_async_handlers(
        self,
    ) -> None:
        (
            queue_handler,
            queue_listener,
        ) = build_queue_listener(
            [
                get_process_file_handler(),
                get_process_sqlite_handler(),
            ],
        )
        self.addHandler(queue_handler)
        queue_listener.start()
        self._queue_listener = (
            queue_listener
        )
        self.__class__._active_queue_listeners.append(
            queue_listener,
        )

    def debug(
        self, msg, *args, **kwargs,
    ):
        super().debug(
            msg, *args, **kwargs,
        )

    def info(
        self, msg, *args, **kwargs,
    ):
        super().info(
            msg, *args, **kwargs,
        )

    def warning(
        self, msg, *args, **kwargs,
    ):
        super().warning(
            msg, *args, **kwargs,
        )

    def error(
        self, msg, *args, **kwargs,
    ):
        super().error(
            msg, *args, **kwargs,
        )

    def critical(
        self, msg, *args, **kwargs,
    ):
        super().critical(
            msg, *args, **kwargs,
        )
