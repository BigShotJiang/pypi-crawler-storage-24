from bclearer_core.constants.standard_constants import (
    UTF_8_ENCODING_NAME,
)

# Kafka support has been removed from the bclearer PDK logging path.


class NfKafkaProducers:
    __kafka_producer = None

    __topic_name = None

    __key = None

    @staticmethod
    def log_to_kafka_producer(
        message: str,
    ):
        pass

    @staticmethod
    def set_kafka_producer(
        list_of_kafka_broker_servers_with_ports: list,
        topic_name: str,
        key: str,
    ):
        pass

    @staticmethod
    def close_kafka_producer():
        pass
