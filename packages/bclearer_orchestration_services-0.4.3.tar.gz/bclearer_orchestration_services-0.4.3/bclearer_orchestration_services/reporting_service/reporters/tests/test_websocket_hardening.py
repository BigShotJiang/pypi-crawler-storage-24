from unittest.mock import Mock, patch

import pytest
from bclearer_core.configurations.b_configurations.b_logging_configurations import (
    BLoggingConfigurations,
)
from bclearer_orchestration_services.reporting_service.reporters.websocket_log_publisher import (
    WebSocketLogPublisher,
    publish_log_to_socket,
)


@pytest.fixture(autouse=True)
def reset_websocket_state():
    BLoggingConfigurations.reset_to_defaults()
    WebSocketLogPublisher._socket = None
    WebSocketLogPublisher._connected = (
        False
    )
    WebSocketLogPublisher._host = None
    WebSocketLogPublisher._port = None
    WebSocketLogPublisher._path = None
    WebSocketLogPublisher._enabled = (
        BLoggingConfigurations.ENABLE_SOCKET_LOGGING
    )
    yield
    BLoggingConfigurations.reset_to_defaults()
    WebSocketLogPublisher._socket = None
    WebSocketLogPublisher._connected = (
        False
    )
    WebSocketLogPublisher._host = None
    WebSocketLogPublisher._port = None
    WebSocketLogPublisher._path = None
    WebSocketLogPublisher._enabled = (
        BLoggingConfigurations.ENABLE_SOCKET_LOGGING
    )


def test_socket_logging_disabled_by_default():
    assert (
        BLoggingConfigurations.ENABLE_SOCKET_LOGGING
        is False
    )


def test_publish_log_to_socket_noops_when_disabled():
    with patch(
        
            "bclearer_orchestration_services."
            "reporting_service.reporters."
            "websocket_log_publisher.socket.socket",
        
    ) as socket_factory:
        publish_log_to_socket("message")

    socket_factory.assert_not_called()


def test_connect_uses_configured_timeout():
    BLoggingConfigurations.ENABLE_SOCKET_LOGGING = (
        True
    )
    WebSocketLogPublisher._enabled = (
        True
    )
    socket_instance = Mock()
    socket_instance.recv.return_value = b"HTTP/1.1 101 Switching Protocols\r\n\r\n"

    with patch(
        (
            "bclearer_orchestration_services."
            "reporting_service.reporters."
            "websocket_log_publisher.socket.socket"
        ),
        return_value=socket_instance,
    ):
        assert (
            WebSocketLogPublisher._connect()
            is True
        )

    socket_instance.settimeout.assert_called_once_with(
        BLoggingConfigurations.SOCKET_LOGGING_TIMEOUT_SECONDS,
    )
