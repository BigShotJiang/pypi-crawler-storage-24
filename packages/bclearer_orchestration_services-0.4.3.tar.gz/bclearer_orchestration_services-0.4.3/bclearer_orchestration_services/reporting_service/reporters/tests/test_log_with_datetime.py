from pathlib import Path

import pytest
from bclearer_orchestration_services.reporting_service.reporters import (
    log_with_datetime,
)
from bclearer_orchestration_services.reporting_service.reporters.log_file import (
    LogFiles,
)
from bclearer_orchestration_services.reporting_service.reporters.log_with_datetime import (
    log_message,
)


def _raise_runtime_error() -> None:
    raise RuntimeError("boom")


def _fallback_reset() -> None:
    LogFiles.close_log_file()
    LogFiles.folder_path = None
    LogFiles.first_open_time = None


@pytest.fixture(autouse=True)
def open_test_log_file(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
):
    monkeypatch.setattr(
        log_with_datetime,
        "publish_log_to_socket",
        lambda **_: None,
    )
    if not hasattr(LogFiles, "reset"):
        monkeypatch.setattr(
            LogFiles,
            "reset",
            classmethod(
                lambda cls: _fallback_reset(),
            ),
            raising=False,
        )
    LogFiles.open_log_file(tmp_path)
    yield
    LogFiles.reset()


def test_include_exc_info_appends_traceback():
    try:
        _raise_runtime_error()
    except RuntimeError:
        log_message(
            "failed",
            include_exc_info=True,
        )

    log_contents = Path(
        LogFiles.log_file.name,
    ).read_text()
    assert "Traceback" in log_contents
    assert (
        "RuntimeError: boom"
        in log_contents
    )


def test_include_exc_info_ignores_sentinel():
    log_message(
        "plain",
        include_exc_info=True,
    )

    log_contents = Path(
        LogFiles.log_file.name,
    ).read_text()
    assert "plain" in log_contents
    assert (
        "NoneType: None"
        not in log_contents
    )


def test_log_message_default_argument_still_works():
    log_message("legacy")

    log_contents = Path(
        LogFiles.log_file.name,
    ).read_text()
    assert "legacy" in log_contents
