from pathlib import Path

import pytest
from bclearer_core.configurations.b_configurations.b_logging_configurations import (
    BLoggingConfigurations,
)
from bclearer_orchestration_services.reporting_service.reporters.log_file import (
    LogFiles,
)


def _raise_open_context_error(
    tmp_path: Path,
) -> None:
    with LogFiles.open_as_context(
        tmp_path,
    ):
        assert (
            LogFiles.log_file
            is not None
        )
        raise RuntimeError("boom")


@pytest.fixture(autouse=True)
def reset_logging_state():
    LogFiles.reset()
    BLoggingConfigurations.reset_to_defaults()
    yield
    LogFiles.reset()
    BLoggingConfigurations.reset_to_defaults()


def test_log_files_reset_clears_state(
    tmp_path: Path,
):
    LogFiles.open_log_file(tmp_path)

    LogFiles.reset()

    assert LogFiles.log_file is None
    assert LogFiles.folder_path is None
    assert (
        LogFiles.first_open_time is None
    )


def test_open_as_context_resets_on_exit(
    tmp_path: Path,
):
    with LogFiles.open_as_context(
        tmp_path,
    ):
        assert (
            LogFiles.log_file
            is not None
        )

    assert LogFiles.log_file is None


def test_open_as_context_resets_on_exception(
    tmp_path: Path,
):
    with pytest.raises(RuntimeError):
        _raise_open_context_error(
            tmp_path,
        )

    assert LogFiles.log_file is None


def test_reset_to_defaults_restores_values():
    BLoggingConfigurations.LOG_PROCESS_MESSAGES_FLAG = (
        False
    )

    BLoggingConfigurations.reset_to_defaults()

    assert (
        BLoggingConfigurations.LOG_PROCESS_MESSAGES_FLAG
        is True
    )
