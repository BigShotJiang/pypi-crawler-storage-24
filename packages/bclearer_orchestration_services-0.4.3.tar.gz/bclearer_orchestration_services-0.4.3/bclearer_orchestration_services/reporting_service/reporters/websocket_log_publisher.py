"""WebSocket log publisher for sending logs to the reporting backend
"""

import json
import queue
import socket
import threading
from datetime import UTC, datetime
from typing import Optional

from bclearer_core.configurations.b_configurations.b_logging_configurations import (
    BLoggingConfigurations,
)
from bclearer_core.configurations.datastructure.logging_inspection_level_b_enums import (
    LoggingInspectionLevelBEnums,
)


class WebSocketLogPublisher:
    """Simple WebSocket client for sending logs asynchronously"""

    _socket = None
    _connected = False
    _host = None
    _port = None
    _path = None
    _enabled = (
        BLoggingConfigurations.ENABLE_SOCKET_LOGGING
    )
    _ws_queue: queue.Queue = (
        queue.Queue()
    )
    _ws_thread = None
    _ws_stop_signal = object()

    @classmethod
    def _socket_logging_enabled(
        cls,
    ) -> bool:
        cls._enabled = (
            BLoggingConfigurations.ENABLE_SOCKET_LOGGING
        )
        return cls._enabled

    @classmethod
    def _ensure_worker(
        cls,
    ) -> None:
        if (
            cls._ws_thread is not None
            and cls._ws_thread.is_alive()
        ):
            return
        cls._ws_thread = threading.Thread(
            target=cls._drain_queue,
            daemon=True,
            name="bclearer-ws-log-publisher",
        )
        cls._ws_thread.start()

    @classmethod
    def _drain_queue(
        cls,
    ) -> None:
        while True:
            payload = (
                cls._ws_queue.get()
            )
            if (
                payload
                is cls._ws_stop_signal
            ):
                break
            cls._publish_payload(
                payload,
            )
        cls._close_socket()

    @classmethod
    def _publish_payload(
        cls,
        log_data: dict,
    ) -> None:
        try:
            payload = json.dumps(
                log_data,
            )
            if (
                not cls._connected
                and not cls._connect()
            ):
                return
            if not cls._send_frame(
                payload,
            ):
                if cls._connect():
                    cls._send_frame(
                        payload,
                    )
        except Exception:
            pass

    @classmethod
    def _close_socket(
        cls,
    ) -> None:
        if cls._socket:
            cls._socket.close()
            cls._socket = None
        cls._connected = False

    @classmethod
    def request_shutdown(
        cls,
    ) -> None:
        if (
            cls._ws_thread is not None
            and cls._ws_thread.is_alive()
        ):
            cls._ws_queue.put(
                cls._ws_stop_signal,
            )

    @classmethod
    def _parse_url(cls):
        """Parse the WebSocket URL to extract host, port, and path"""
        if cls._host is not None:
            return

        url = (
            BLoggingConfigurations.SOCKET_LOGGING_URL
        )
        # Remove ws:// or wss://
        url = url.replace(
            "ws://",
            "",
        ).replace("wss://", "")

        # Split host:port/path
        if "/" in url:
            host_port, path = url.split(
                "/",
                1,
            )
            cls._path = "/" + path
        else:
            host_port = url
            cls._path = "/"

        # Split host and port
        if ":" in host_port:
            cls._host, port_str = (
                host_port.split(":", 1)
            )
            cls._port = int(port_str)
        else:
            cls._host = host_port
            cls._port = 80

    @classmethod
    def _connect(cls):
        """Establish WebSocket connection"""
        if (
            not cls._socket_logging_enabled()
        ):
            return False

        try:
            cls._parse_url()

            # Create socket connection
            cls._socket = socket.socket(
                socket.AF_INET,
                socket.SOCK_STREAM,
            )
            cls._socket.settimeout(
                BLoggingConfigurations.SOCKET_LOGGING_TIMEOUT_SECONDS,
            )
            cls._socket.connect(
                (cls._host, cls._port),
            )

            # Send WebSocket handshake
            handshake = (
                f"GET {cls._path} HTTP/1.1\r\n"
                f"Host: {cls._host}:{cls._port}\r\n"
                "Upgrade: websocket\r\n"
                "Connection: Upgrade\r\n"
                "Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==\r\n"
                "Sec-WebSocket-Version: 13\r\n"
                "\r\n"
            )
            cls._socket.sendall(
                handshake.encode(),
            )

            # Read handshake response
            response = cls._socket.recv(
                1024,
            ).decode()
            if (
                "101"
                in response.split(
                    "\r\n",
                )[0]
            ):
                cls._connected = True
                return True
            else:
                cls._close_socket()
                return False

        except Exception:
            cls._close_socket()
            return False

    @classmethod
    def _send_frame(cls, data: str):
        """Send a WebSocket text frame"""
        if (
            not cls._connected
            or not cls._socket
        ):
            return False

        try:
            # Encode data
            message = data.encode(
                "utf-8",
            )
            message_length = len(
                message,
            )

            # Create WebSocket frame
            frame = bytearray()
            frame.append(
                0x81,
            )  # FIN + Text frame

            # Add length
            if message_length <= 125:
                frame.append(
                    0x80
                    | message_length,
                )  # Masked + length
            elif (
                message_length <= 65535
            ):
                frame.append(0x80 | 126)
                frame.extend(
                    message_length.to_bytes(
                        2,
                        "big",
                    ),
                )
            else:
                frame.append(0x80 | 127)
                frame.extend(
                    message_length.to_bytes(
                        8,
                        "big",
                    ),
                )

            # Masking key (required for client-to-server)
            mask = bytes(
                [
                    0x00,
                    0x00,
                    0x00,
                    0x00,
                ],
            )
            frame.extend(mask)

            # Add masked payload
            frame.extend(message)

            cls._socket.sendall(frame)
            return True

        except Exception:
            cls._close_socket()
            return False

    @classmethod
    def send_log(
        cls,
        message: str,
        level: str = "INFO",
        source: str = "pipeline",
        timestamp: str | None = None,
    ):
        """Send a log message through WebSocket

        Args:
            message: The log message
            level: Log level (INFO, DEBUG, WARNING, ERROR)
            source: Source identifier
            timestamp: ISO format timestamp (auto-generated if not provided)

        """
        if (
            not cls._socket_logging_enabled()
        ):
            return

        if timestamp is None:
            timestamp = datetime.now(
                UTC,
            ).isoformat()

        log_data = {
            "type": "log",
            "level": level,
            "message": message,
            "timestamp": timestamp,
            "source": source,
        }
        cls._ensure_worker()
        cls._ws_queue.put(log_data)


def publish_log_to_socket(
    message: str,
    logging_inspection_level_b_enum: (
        LoggingInspectionLevelBEnums
        | None
    ) = None,
    source: str = "pipeline",
    level: str = "INFO",
):
    """Convenience function to publish a log to the WebSocket endpoint

    Args:
        message: The log message
        logging_inspection_level_b_enum: Logging level enum (maps to level string)
        source: Source identifier
        level: Direct level string (used if enum not provided)

    """
    if (
        not BLoggingConfigurations.ENABLE_SOCKET_LOGGING
    ):
        return

    # Map enum to level string
    if (
        logging_inspection_level_b_enum
        is not None
    ):
        level_name = (
            logging_inspection_level_b_enum.name
        )
        # Extract level from enum name (e.g., "WARNING" from enum)
        if (
            "ERROR" in level_name
            or "CRITICAL" in level_name
        ):
            level = "ERROR"
        elif "WARNING" in level_name:
            level = "WARNING"
        elif "DEBUG" in level_name:
            level = "DEBUG"
        else:
            level = "INFO"

    WebSocketLogPublisher.send_log(
        message=message,
        level=level,
        source=source,
        timestamp=datetime.now(
            UTC,
        ).isoformat(),
    )
