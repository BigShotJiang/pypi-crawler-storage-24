from typing import NamedTuple, Optional

from bclearer_orchestration_services.identification_services.b_identity_ecosystem.bie_id_creation_module.common_knowledge.types.bie_vector_structure_types import (
    BieVectorStructureTypes,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.bie_id_creation_module.identity_vectors.bie_identity_vector_base import (
    BieIdentityVectorBase,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.common_knowledge.bie_enums import (
    BieEnums,
)


class CommonIdentityVector(
    BieIdentityVectorBase,
):
    def __init__(
        self,
        *,
        bie_domain_type: Optional[BieEnums],
        bie_hr_name: Optional[str],
        places: NamedTuple,
        bie_vector_structure_type: BieVectorStructureTypes,
    ) -> None:
        _validate_places(
            places=places,
            vector_name=type(self).__name__,
        )

        self._places = places

        self._bie_vector_structure_type = (
            bie_vector_structure_type
        )

        self._bie_domain_type = (
            bie_domain_type
        )

        self._bie_hr_name = bie_hr_name

    @property
    def bie_domain_type(
        self,
    ) -> Optional[BieEnums]:
        return self._bie_domain_type

    @property
    def bie_vector_structure_type(
        self,
    ) -> BieVectorStructureTypes:
        return self._bie_vector_structure_type

    @property
    def bie_hr_name(
        self,
    ) -> Optional[str]:
        return self._bie_hr_name

    def input_objects(
        self,
    ) -> list:
        return list(self._places)


def _validate_places(
    places: NamedTuple,
    vector_name: str,
) -> None:
    if not isinstance(places, tuple) or not hasattr(
        places, "_fields"
    ):
        raise TypeError(
            f"{vector_name} places must be a NamedTuple instance"
        )

    if any(
        place is None for place in places
    ):
        raise ValueError(
            f"{vector_name} places must not contain None"
        )
