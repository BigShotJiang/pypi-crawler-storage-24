from bclearer_orchestration_services.identification_services.b_identity_ecosystem.bie_id_creation_module.common_knowledge.types.bie_vector_structure_types import (
    BieVectorStructureTypes,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.bie_id_creation_module.general_objects.bie_id_from_type_and_vector_creator import (
    create_bie_id_from_type_and_vector,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.bie_id_creation_module.identity_vectors.bie_identity_vector_base import (
    BieIdentityVectorBase,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.objects.bie_ids import (
    BieIds,
)


def create_bie_id_from_identity_vector(
    vector: BieIdentityVectorBase,
) -> BieIds:
    return _create_bie_id_from_identity_vector(
        vector=vector,
    )


def _create_bie_id_from_identity_vector(
    vector: BieIdentityVectorBase,
) -> BieIds:
    if not isinstance(
        vector,
        BieIdentityVectorBase,
    ):
        raise TypeError(
            "vector must inherit BieIdentityVectorBase"
        )

    if (
        vector.bie_vector_structure_type
        == BieVectorStructureTypes.ZERO_DIMENSIONAL
    ):
        _validate_zero_dimensional_vector(
            vector=vector,
        )

        return BieIds(int_value=0)

    normalized_input_objects = (
        _normalize_identity_input_objects(
            input_objects=vector.input_objects(),
        )
    )

    return create_bie_id_from_type_and_vector(
        input_objects_vector=normalized_input_objects,
        bie_vector_structure_type=vector.bie_vector_structure_type,
        bie_domain_type=vector.bie_domain_type,
    )


def _validate_zero_dimensional_vector(
    vector: BieIdentityVectorBase,
) -> None:
    if vector.bie_domain_type is not None:
        raise ValueError(
            "Zero-dimensional vector must not set bie_domain_type"
        )

    if vector.input_objects():
        raise ValueError(
            "Zero-dimensional vector must not include input objects"
        )


def _normalize_identity_input_objects(
    input_objects: list,
) -> list:
    normalized_input_objects = list()

    for input_object in input_objects:
        normalized_input_objects.extend(
            _flatten_identity_input_object(
                input_object=input_object,
            )
        )

    return normalized_input_objects


def _flatten_identity_input_object(
    input_object: object,
) -> list:
    if isinstance(
        input_object,
        (tuple, list),
    ):
        flattened_input_objects = list()

        for nested_input_object in input_object:
            flattened_input_objects.extend(
                _flatten_identity_input_object(
                    input_object=nested_input_object,
                )
            )

        return flattened_input_objects

    return [input_object]
