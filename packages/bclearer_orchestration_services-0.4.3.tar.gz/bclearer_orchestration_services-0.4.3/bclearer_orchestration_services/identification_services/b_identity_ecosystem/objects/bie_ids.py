from bclearer_orchestration_services.identification_services.b_identity_ecosystem.converters.int_to_base32_converter import (
    convert_int_to_base32,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.converters.base32_to_int_converter import (
    convert_base32_to_int,
)


class _CallableBool:
    """Backward-compatible bool proxy for legacy `is_empty` access patterns."""

    def __init__(self, value: bool):
        self._value = value

    def __bool__(self) -> bool:
        return self._value

    def __call__(self) -> bool:
        return self._value

    def __repr__(self) -> str:
        return repr(self._value)

    def __str__(self) -> str:
        return str(self._value)


class BieIds:
    def __init__(self, int_value: int):
        self.int_value = int_value

    @staticmethod
    def from_base32(base32_value: str) -> "BieIds":
        return BieIds(
            int_value=convert_base32_to_int(
                base32_value
            )
        )

    def __str__(self):
        return convert_int_to_base32(
            int_value=self.int_value,
        )

    def __eq__(self, other):
        if not isinstance(
            other,
            BieIds,
        ):
            return NotImplemented

        return (
            self.int_value
            == other.int_value
        )

    def __lt__(self, other):
        if not isinstance(
            other,
            BieIds,
        ):
            return NotImplemented

        return (
            self.int_value
            < other.int_value
        )

    def __hash__(self):
        return hash(self.int_value)

    def __repr__(self):
        return convert_int_to_base32(
            int_value=self.int_value,
        )

    @property
    def is_empty(self) -> _CallableBool:
        """Support both `bie_id.is_empty` and `bie_id.is_empty()`."""
        return _CallableBool(
            self.int_value == 0
        )
