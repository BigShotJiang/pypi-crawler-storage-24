from bclearer_orchestration_services.file_system_snapshot_service.universe.processors.populators.sum_objects.bie_id_to_sum_adder import (
    add_bie_id_to_sum,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.objects.bie_ids import (
    BieIds,
)
from bclearer_orchestration_services.snapshot_universe_service.objects.factories.sum_objects_factory import (
    create_sum_object,
)
from bclearer_orchestration_services.snapshot_universe_service.objects.sum_objects import (
    SumObjects,
)


def add_bie_id_to_sum_dictionary(
    sum_objects_dictionary,
    bie_id: BieIds,
    bie_id_type,
    direction,
) -> None:
    if bie_id.is_empty:
        return

    if (
        bie_id_type
        in sum_objects_dictionary
    ):
        sum_object = add_bie_id_to_sum(
            sum_object=sum_objects_dictionary[
                bie_id_type
            ],
            bie_id=bie_id,
        )

    else:
        sum_object = create_sum_object(
            direction_type=direction,
            bie_summed_type=bie_id_type,
            member_bie_ids=(bie_id,),
        )

    sum_objects_dictionary[
        bie_id_type
    ] = sum_object
