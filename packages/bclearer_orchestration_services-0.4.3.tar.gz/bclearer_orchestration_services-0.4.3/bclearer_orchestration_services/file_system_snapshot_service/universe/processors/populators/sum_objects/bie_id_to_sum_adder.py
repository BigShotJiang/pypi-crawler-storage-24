from bclearer_orchestration_services.identification_services.b_identity_ecosystem.objects.bie_ids import (
    BieIds,
)
from bclearer_orchestration_services.snapshot_universe_service.objects.factories.sum_objects_factory import (
    create_sum_object,
)
from bclearer_orchestration_services.snapshot_universe_service.objects.sum_objects import (
    SumObjects,
)


def add_bie_id_to_sum(
    bie_id: BieIds,
    sum_object: SumObjects,
) -> SumObjects:
    sum_object = create_sum_object(
        direction_type=sum_object.direction_type,
        bie_summed_type=sum_object.bie_summed_type,
        member_bie_ids=sum_object.member_bie_ids
        + (bie_id,),
    )
    return sum_object
