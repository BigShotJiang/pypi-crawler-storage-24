from bclearer_core.infrastructure.session.bie_id_registerers.bie_id_registerer import (
    NoOpBieIdRegisterer,
)
from bclearer_core.infrastructure.session.operating_system.factories.operating_system_objects_factory import (
    create_operating_system_objects,
)
from bclearer_interop_services.file_system_service.objects.file_system_objects import (
    FileSystemObjects,
)
from bclearer_orchestration_services.file_system_snapshot_service.universe.bie.bie_id_creators.file_system_snapshot_identity_vectors import (
    FileReferenceNumberExtendedObjectIdentityVector,
    FileReferenceNumberExtendedObjectIdentityVectorPlaces,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.bie_id_creation_module.bie_id_creation_facade import (
    BieIdCreationFacade,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.objects.bie_ids import (
    BieIds,
)


def create_file_reference_number_extended_object_bie_id(
    file_system_object: FileSystemObjects,
    file_reference_number: str,
) -> BieIds:
    return calculate_file_reference_number_extended_object_bie_id(
        file_system_object=file_system_object,
        file_reference_number=file_reference_number,
    )


def calculate_file_reference_number_extended_object_bie_id(
    file_system_object: FileSystemObjects,
    file_reference_number: str,
) -> BieIds:
    operating_system_object = (
        create_operating_system_objects(
            bie_id_registerer=NoOpBieIdRegisterer()
        )
    )

    file_reference_number_identity_vector = (
        __get_file_reference_number_identity_vector(
            file_system_object=file_system_object,
            file_reference_number=file_reference_number,
            operating_system_object=operating_system_object,
        )
    )

    return BieIdCreationFacade.create_bie_id_from_identity_vector(
        vector=file_reference_number_identity_vector,
    )


def __get_file_reference_number_identity_vector(
    file_system_object: FileSystemObjects,
    file_reference_number: str,
    operating_system_object: OperatingSystemObjects,
) -> FileReferenceNumberExtendedObjectIdentityVector:
    file_reference_number_identity_vector = (
        FileReferenceNumberExtendedObjectIdentityVector(
            bie_hr_name=str(file_reference_number),
            places=FileReferenceNumberExtendedObjectIdentityVectorPlaces(
                operating_system_bie_id=operating_system_object.bie_id,
                drive=file_system_object.drive,
                file_reference_number=file_reference_number,
            ),
        )
    )

    return file_reference_number_identity_vector
