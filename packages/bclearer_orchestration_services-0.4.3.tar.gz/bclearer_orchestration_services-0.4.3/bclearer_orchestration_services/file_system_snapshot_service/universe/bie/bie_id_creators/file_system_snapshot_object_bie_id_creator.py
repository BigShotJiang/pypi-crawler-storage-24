from bclearer_orchestration_services.file_system_snapshot_service.universe.common_knowledge.bie_file_system_snapshot_domain_types import (
    BieFileSystemSnapshotDomainTypes,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.bie_id_creation_module.bie_id_creation_facade import (
    BieIdCreationFacade,
)
from bclearer_orchestration_services.file_system_snapshot_service.universe.bie.bie_id_creators.file_system_snapshot_identity_vectors import (
    FileSystemSnapshotObjectIdentityVector,
    FileSystemSnapshotObjectIdentityVectorPlaces,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.common_knowledge.bie_types import (
    BieTypes,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.objects.bie_ids import (
    BieIds,
)
from bclearer_orchestration_services.snapshot_universe_service.objects.snapshot_domains import (
    SnapshotDomains,
)


def create_file_system_snapshot_object_bie_id(
    base_system_object_bie_id: BieIds,
    owning_snapshot_domain: SnapshotDomains,
) -> BieIds:
    return calculate_file_system_snapshot_object_bie_id(
        base_system_object_bie_id=base_system_object_bie_id,
        owning_snapshot_domain=owning_snapshot_domain,
    )


def calculate_file_system_snapshot_object_bie_id(
    base_system_object_bie_id: BieIds,
    owning_snapshot_domain: SnapshotDomains,
) -> BieIds:
    file_system_snapshot_object_identity_vector_places = (
        __get_file_system_snapshot_object_identity_vector_places(
            base_system_object_bie_id=base_system_object_bie_id,
            owning_snapshot_domain=owning_snapshot_domain,
        )
    )

    standard_bie_id_type = (
        BieFileSystemSnapshotDomainTypes.BIE_FILE_SYSTEM_SNAPSHOT_BASE_SNAPSHOT_BIE_IDS
    )

    bie_hr_name = "file_system_snapshot_object_bie_id"

    file_system_snapshot_object_identity_vector = (
        __get_file_system_snapshot_object_identity_vector(
            bie_type=standard_bie_id_type,
            bie_hr_name=bie_hr_name,
            file_system_snapshot_object_identity_vector_places=file_system_snapshot_object_identity_vector_places,
        )
    )

    return BieIdCreationFacade.create_bie_id_from_identity_vector(
        vector=file_system_snapshot_object_identity_vector,
    )


def __get_file_system_snapshot_object_identity_vector(
    bie_type: BieTypes,
    bie_hr_name: str,
    file_system_snapshot_object_identity_vector_places: FileSystemSnapshotObjectIdentityVectorPlaces,
) -> FileSystemSnapshotObjectIdentityVector:
    file_system_snapshot_object_identity_vector = (
        FileSystemSnapshotObjectIdentityVector(
            bie_type=bie_type,
            bie_hr_name=bie_hr_name,
            places=file_system_snapshot_object_identity_vector_places,
        )
    )

    return file_system_snapshot_object_identity_vector


def __get_file_system_snapshot_object_identity_vector_places(
    base_system_object_bie_id: BieIds,
    owning_snapshot_domain: SnapshotDomains,
) -> FileSystemSnapshotObjectIdentityVectorPlaces:
    file_system_snapshot_object_identity_vector_places = (
        FileSystemSnapshotObjectIdentityVectorPlaces(
            owning_snapshot_domain_bie_id=owning_snapshot_domain.bie_id,
            base_system_object_bie_id=base_system_object_bie_id,
        )
    )

    return file_system_snapshot_object_identity_vector_places
