# from pathlib import Path
# from bclearer_orchestration_services.identification_services.b_identity_ecosystem.bie_id_creation_module.bie_id_creation_facade import (
#     BieIdCreationFacade,
# )
# from bclearer_orchestration_services.file_system_snapshot_service.universe.bie.bie_id_creators.file_system_snapshot_identity_vectors import (
#     RelativePathObjectIdentityVector,
#     RelativePathExtendedObjectIdentityVectorPlaces,
# )
# from bclearer_orchestration_services.identification_services.b_identity_ecosystem.objects.bie_ids import (
#     BieIds,
# )
#
#
# def create_relative_path_extended_object_bie_id(
#     relative_path: Path,
# ) -> BieIds:
#     relative_path_identity_vector = (
#         RelativePathObjectIdentityVector(
#             bie_hr_name=str(relative_path),
#             places=RelativePathExtendedObjectIdentityVectorPlaces(
#                 relative_path=relative_path,
#             ),
#         )
#     )
#
#     relative_path_extended_object_bie_id = (
#         BieIdCreationFacade.create_bie_id_from_identity_vector(
#             vector=relative_path_identity_vector,
#         )
#     )
#
#     return relative_path_extended_object_bie_id
