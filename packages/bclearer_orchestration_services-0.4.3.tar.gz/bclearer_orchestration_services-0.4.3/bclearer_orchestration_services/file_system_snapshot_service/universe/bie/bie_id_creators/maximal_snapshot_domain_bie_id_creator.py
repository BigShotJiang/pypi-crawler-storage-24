from bclearer_core.infrastructure.session.app_run_session.app_run_session_objects import (
    AppRunSessionObjects,
)
from bclearer_orchestration_services.file_system_snapshot_service.universe.bie.bie_id_creators.file_system_snapshot_identity_vectors import (
    MaximalSnapshotDomainIdentityVector,
    MaximalSnapshotDomainIdentityVectorPlaces,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.bie_id_creation_module.bie_id_creation_facade import (
    BieIdCreationFacade,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.objects.bie_ids import (
    BieIds,
)


def create_maximal_snapshot_domain_bie_id(
    app_run_session_object: AppRunSessionObjects,
) -> BieIds:
    return calculate_maximal_snapshot_domain_bie_id(
        app_run_session_object=app_run_session_object,
    )


def calculate_maximal_snapshot_domain_bie_id(
    app_run_session_object: AppRunSessionObjects,
) -> BieIds:
    return BieIdCreationFacade.create_bie_id_from_identity_vector(
        vector=MaximalSnapshotDomainIdentityVector(
            places=MaximalSnapshotDomainIdentityVectorPlaces(
                app_run_session_bie_id=app_run_session_object.bie_id,
            ),
        ),
    )
