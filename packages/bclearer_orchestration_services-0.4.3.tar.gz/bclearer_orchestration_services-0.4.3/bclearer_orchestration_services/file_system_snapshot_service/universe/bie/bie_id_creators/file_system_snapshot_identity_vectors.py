from pathlib import Path
from typing import NamedTuple

from bclearer_orchestration_services.file_system_snapshot_service.universe.common_knowledge.bie_file_system_snapshot_domain_types import (
    BieFileSystemSnapshotDomainTypes,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.bie_id_creation_module.common_knowledge.types.bie_vector_structure_types import (
    BieVectorStructureTypes,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.bie_id_creation_module.identity_vectors import (
    CommonIdentityVector,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.common_knowledge.bie_domain_types import (
    BieDomainTypes,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.common_knowledge.bie_types import (
    BieTypes,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.objects.bie_ids import (
    BieIds,
)
from bclearer_orchestration_services.snapshot_universe_service.common_knowledge.bie_snapshot_domain_types import (
    BieSnapshotDomainTypes,
)


# --- Relative Path ---


class RelativePathExtendedObjectIdentityVectorPlaces(
    NamedTuple,
):
    relative_path: Path


class RelativePathObjectIdentityVector(
    CommonIdentityVector,
):
    def __init__(
        self,
        *,
        bie_hr_name: str,
        places: RelativePathExtendedObjectIdentityVectorPlaces,
    ) -> None:
        super().__init__(
            bie_domain_type=BieFileSystemSnapshotDomainTypes.BIE_RELATIVE_PATHS,
            bie_hr_name=bie_hr_name,
            places=places,
            bie_vector_structure_type=BieVectorStructureTypes.SINGLE_DIMENSIONAL,
        )


# --- File Reference Number ---


class FileReferenceNumberExtendedObjectIdentityVectorPlaces(
    NamedTuple,
):
    operating_system_bie_id: BieIds
    drive: str
    file_reference_number: str


class FileReferenceNumberExtendedObjectIdentityVector(
    CommonIdentityVector,
):
    def __init__(
        self,
        *,
        bie_hr_name: str,
        places: FileReferenceNumberExtendedObjectIdentityVectorPlaces,
    ) -> None:
        super().__init__(
            bie_domain_type=BieFileSystemSnapshotDomainTypes.BIE_FILE_REFERENCE_NUMBERS,
            bie_hr_name=bie_hr_name,
            places=places,
            bie_vector_structure_type=BieVectorStructureTypes.MULTI_DIMENSIONAL_ORDER_SENSITIVE,
        )


# --- File System Snapshot ---


class FileSystemSnapshotObjectIdentityVectorPlaces(
    NamedTuple,
):
    owning_snapshot_domain_bie_id: BieIds
    base_system_object_bie_id: BieIds


class FileSystemSnapshotObjectIdentityVector(
    CommonIdentityVector,
):
    def __init__(
        self,
        *,
        bie_type: BieTypes,
        bie_hr_name: str,
        places: FileSystemSnapshotObjectIdentityVectorPlaces,
    ) -> None:
        super().__init__(
            bie_domain_type=bie_type,
            bie_hr_name=bie_hr_name,
            places=places,
            bie_vector_structure_type=BieVectorStructureTypes.MULTI_DIMENSIONAL_ORDER_SENSITIVE,
        )


# --- Maximal Snapshot Domain ---


class MaximalSnapshotDomainIdentityVectorPlaces(
    NamedTuple,
):
    app_run_session_bie_id: BieIds


class MaximalSnapshotDomainIdentityVector(
    CommonIdentityVector,
):
    def __init__(
        self,
        *,
        places: MaximalSnapshotDomainIdentityVectorPlaces,
    ) -> None:
        super().__init__(
            bie_domain_type=BieSnapshotDomainTypes.MAXIMAL_SNAPSHOT_DOMAINS,
            bie_hr_name=BieSnapshotDomainTypes.MAXIMAL_SNAPSHOT_DOMAINS.b_enum_item_name,
            places=places,
            bie_vector_structure_type=BieVectorStructureTypes.MULTI_DIMENSIONAL_ORDER_SENSITIVE,
        )


# --- File Byte Content ---


class FileByteContentIdentityVectorPlaces(
    NamedTuple,
):
    content_bie_id: BieIds


class FileByteContentIdentityVector(
    CommonIdentityVector,
):
    def __init__(
        self,
        *,
        bie_hr_name: str,
        places: FileByteContentIdentityVectorPlaces,
    ) -> None:
        super().__init__(
            bie_domain_type=BieFileSystemSnapshotDomainTypes.BIE_FILE_BYTE_CONTENTS,
            bie_hr_name=bie_hr_name,
            places=places,
            bie_vector_structure_type=BieVectorStructureTypes.MULTI_DIMENSIONAL_ORDER_SENSITIVE,
        )


# --- Sum Object ---


class SumObjectIdentityVectorPlaces(
    NamedTuple,
):
    direction_type: BieDomainTypes
    bie_summed_type: BieDomainTypes
    member_bie_ids: tuple[BieIds, ...]


class SumObjectIdentityVector(
    CommonIdentityVector,
):
    def __init__(
        self,
        *,
        bie_type: BieTypes,
        bie_hr_name: str,
        places: SumObjectIdentityVectorPlaces,
    ) -> None:
        _validate_sum_object_places(
            places=places,
        )

        super().__init__(
            bie_domain_type=bie_type,
            bie_hr_name=bie_hr_name,
            places=places,
            bie_vector_structure_type=BieVectorStructureTypes.MULTI_DIMENSIONAL_ORDER_INSENSITIVE,
        )


def _validate_sum_object_places(
    places: SumObjectIdentityVectorPlaces,
) -> None:
    if not isinstance(
        places, SumObjectIdentityVectorPlaces
    ):
        raise TypeError(
            "SumObjectIdentityVector places must be SumObjectIdentityVectorPlaces"
        )

    if not places.member_bie_ids:
        raise ValueError(
            "SumObjectIdentityVector member_bie_ids must not be empty"
        )

    if (
        places.direction_type is None
        or places.bie_summed_type is None
    ):
        raise ValueError(
            "SumObjectIdentityVector direction_type and bie_summed_type must not be None"
        )

    if any(
        member_bie_id is None
        for member_bie_id in places.member_bie_ids
    ):
        raise ValueError(
            "SumObjectIdentityVector member_bie_ids must not contain None"
        )
