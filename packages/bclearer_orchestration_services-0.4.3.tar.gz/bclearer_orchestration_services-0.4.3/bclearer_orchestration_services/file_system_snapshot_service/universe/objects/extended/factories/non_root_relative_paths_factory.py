from pathlib import Path

from bclearer_core.bie.top.bie_base_identities import (
    BieBaseIdentities,
    create_bie_base_identity_from_bie_identity_vector,
)
from bclearer_core.infrastructure.session.bie_id_registerers.bie_id_registerer import (
    BieIdRegisterer,
)
from bclearer_orchestration_services.file_system_snapshot_service.universe.bie.bie_id_creators.file_system_snapshot_identity_vectors import (
    RelativePathExtendedObjectIdentityVectorPlaces,
    RelativePathObjectIdentityVector,
)
from bclearer_orchestration_services.file_system_snapshot_service.universe.objects.extended.non_root_relative_paths import (
    NonRootRelativePaths,
)
from bclearer_orchestration_services.file_system_snapshot_service.universe.objects.extended.relative_paths import (
    RelativePaths,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.common_knowledge.bie_core_relation_types import (
    BieCoreRelationTypes,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.registrations.helpers.registerers.bie_id_issue_requests import (
    RelationBieIdRequest,
)
from bclearer_orchestration_services.identification_services.naming_service.b_sequence_names import (
    BSequenceNames,
)


def create_non_root_relative_paths(
    *,
    relative_path: Path,
    relative_path_parent: RelativePaths,
    bie_id_registerer: BieIdRegisterer,
) -> NonRootRelativePaths:
    bie_base_identity = _create_non_root_relative_path_bie_base_identity(
        relative_path=relative_path,
    )
    non_root_relative_paths = NonRootRelativePaths(
        relative_path=relative_path,
        relative_path_parent=relative_path_parent,
        bie_base_identity=bie_base_identity,
    )
    bie_id_registerer.register_bie_id(
        bie_base_identity=bie_base_identity,
    )
    bie_id_registerer.issue_and_register_bie_id(
        request=RelationBieIdRequest(
            bie_place_1_id=non_root_relative_paths.bie_id,
            bie_place_2_id=relative_path_parent.bie_id,
            bie_relation_type_id=BieCoreRelationTypes.BIE_WHOLES_PARTS.item_bie_identity,
            b_sequence_name=BSequenceNames(
                initial_b_sequence_name_list=[
                    "snapshot_whole_part"
                ]
            ),
        )
    )
    return non_root_relative_paths


def _create_non_root_relative_path_bie_base_identity(
    *,
    relative_path: Path,
) -> BieBaseIdentities:
    places = RelativePathExtendedObjectIdentityVectorPlaces(
        relative_path=relative_path,
    )
    return create_bie_base_identity_from_bie_identity_vector(
        identity_vector=RelativePathObjectIdentityVector(
            bie_hr_name=str(relative_path),
            places=places,
        )
    )
