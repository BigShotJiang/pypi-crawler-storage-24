from bclearer_core.bie.top.bie_base_identities import (
    BieBaseIdentities,
    create_bie_base_identity_from_bie_identity_vector,
)
from bclearer_core.infrastructure.session.operating_system.factories.operating_system_objects_factory import (
    create_operating_system_objects,
)
from bclearer_core.infrastructure.session.bie_id_registerers.bie_id_registerer import (
    BieIdRegisterer,
)
from bclearer_interop_services.file_system_service.objects.file_system_objects import (
    FileSystemObjects,
)
from bclearer_orchestration_services.file_system_snapshot_service.universe.bie.bie_id_creators.file_system_snapshot_identity_vectors import (
    FileReferenceNumberExtendedObjectIdentityVector,
    FileReferenceNumberExtendedObjectIdentityVectorPlaces,
)
from bclearer_orchestration_services.file_system_snapshot_service.universe.objects.extended.file_reference_numbers import (
    FileReferenceNumbers,
)
from bclearer_orchestration_services.file_system_snapshot_service.universe.processors.os_functions.file_reference_number_getter import (
    get_file_reference_number,
)
from bclearer_orchestration_services.snapshot_universe_service.objects.snapshot_domains import (
    SnapshotDomains,
)


def create_file_reference_numbers(
    *,
    file_system_object: FileSystemObjects,
    owning_snapshot_domain: SnapshotDomains,
    bie_id_registerer: BieIdRegisterer,
) -> FileReferenceNumbers:
    bie_base_identity, file_reference_number, owning_operating_system_object = _create_file_reference_number_bie_base_identity(
        file_system_object=file_system_object,
        bie_id_registerer=bie_id_registerer,
    )
    file_reference_numbers = FileReferenceNumbers(
        file_system_object=file_system_object,
        owning_snapshot_domain=owning_snapshot_domain,
        file_reference_number=file_reference_number,
        owning_operating_system_object=owning_operating_system_object,
        bie_base_identity=bie_base_identity,
    )
    bie_id_registerer.register_bie_id(
        bie_base_identity=bie_base_identity,
    )
    return file_reference_numbers


def _create_file_reference_number_bie_base_identity(
    *,
    file_system_object: FileSystemObjects,
    bie_id_registerer: BieIdRegisterer,
) -> tuple[BieBaseIdentities, str, object]:
    file_reference_number = get_file_reference_number(
        file_path_as_string=file_system_object.absolute_path_string,
    ).__str__()
    owning_operating_system_object = create_operating_system_objects(
        bie_id_registerer=bie_id_registerer,
    )
    places = FileReferenceNumberExtendedObjectIdentityVectorPlaces(
        operating_system_bie_id=owning_operating_system_object.bie_id,
        drive=file_system_object.drive,
        file_reference_number=file_reference_number,
    )
    bie_base_identity = create_bie_base_identity_from_bie_identity_vector(
        identity_vector=FileReferenceNumberExtendedObjectIdentityVector(
            bie_hr_name=file_reference_number,
            places=places,
        )
    )
    return bie_base_identity, file_reference_number, owning_operating_system_object
