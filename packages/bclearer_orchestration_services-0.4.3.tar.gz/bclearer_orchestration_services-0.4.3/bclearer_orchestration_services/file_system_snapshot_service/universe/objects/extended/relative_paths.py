from abc import ABC
from pathlib import Path

from bclearer_core.bie.top.bie_base_identities import (
    BieBaseIdentities,
)
from bclearer_orchestration_services.snapshot_universe_service.objects.extended_objects import (
    ExtendedObjects,
)


class RelativePaths(
    ExtendedObjects,
    ABC,
):
    def __init__(
        self,
        base_hr_name: str,
        relative_path: Path,
        bie_base_identity: BieBaseIdentities,
    ):
        self._base_hr_name = base_hr_name

        self.relative_path_children = set()

        self.relative_path = relative_path

        super().__init__(
            bie_base_identity=bie_base_identity,
        )

    def add_relative_path_child(
        self,
        relative_path_child: "RelativePaths",
    ):
        self.relative_path_children.add(
            relative_path_child
        )
