from pathlib import Path

from bclearer_core.bie.top.bie_base_identities import (
    BieBaseIdentities,
    create_bie_base_identity_from_bie_identity_vector,
)
from bclearer_core.infrastructure.session.bie_id_registerers.bie_id_registerer import (
    BieIdRegisterer,
)
from bclearer_orchestration_services.file_system_snapshot_service.universe.bie.bie_id_creators.file_system_snapshot_identity_vectors import (
    RelativePathExtendedObjectIdentityVectorPlaces,
    RelativePathObjectIdentityVector,
)
from bclearer_orchestration_services.file_system_snapshot_service.universe.common_knowledge.file_system_snapshot_domain_literals import (
    FileSystemSnapshotDomainLiterals,
)
from bclearer_orchestration_services.file_system_snapshot_service.universe.objects.extended.root_relative_paths import (
    RootRelativePaths,
)


def create_root_relative_paths(
    *,
    bie_id_registerer: BieIdRegisterer,
) -> RootRelativePaths:
    bie_base_identity = _create_root_relative_path_bie_base_identity()
    root_relative_paths = RootRelativePaths(
        bie_base_identity=bie_base_identity,
    )
    bie_id_registerer.register_bie_id(
        bie_base_identity=bie_base_identity,
    )
    return root_relative_paths


def _create_root_relative_path_bie_base_identity() -> BieBaseIdentities:
    relative_path = Path(str())
    places = RelativePathExtendedObjectIdentityVectorPlaces(
        relative_path=relative_path,
    )
    return create_bie_base_identity_from_bie_identity_vector(
        identity_vector=RelativePathObjectIdentityVector(
            bie_hr_name=FileSystemSnapshotDomainLiterals.root_relative_path,
            places=places,
        )
    )
