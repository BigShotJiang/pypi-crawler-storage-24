from bclearer_core.bie.top.bie_base_identities import (
    BieBaseIdentities,
)
from bclearer_interop_services.file_system_service.objects.file_system_objects import (
    FileSystemObjects,
)
from bclearer_orchestration_services.snapshot_universe_service.objects.extended_objects import (
    ExtendedObjects,
)
from bclearer_orchestration_services.snapshot_universe_service.objects.snapshot_domains import (
    SnapshotDomains,
)


class FileReferenceNumbers(
    ExtendedObjects,
):
    def __init__(
        self,
        file_system_object: FileSystemObjects,
        owning_snapshot_domain: SnapshotDomains,
        file_reference_number: str,
        owning_operating_system_object,
        bie_base_identity: BieBaseIdentities,
    ):
        self.file_system_object = (
            file_system_object
        )

        self.owning_snapshot_domain = (
            owning_snapshot_domain
        )

        self.file_reference_number = file_reference_number

        self.owning_operating_system_object = (
            owning_operating_system_object
        )

        super().__init__(
            bie_base_identity=bie_base_identity,
        )
