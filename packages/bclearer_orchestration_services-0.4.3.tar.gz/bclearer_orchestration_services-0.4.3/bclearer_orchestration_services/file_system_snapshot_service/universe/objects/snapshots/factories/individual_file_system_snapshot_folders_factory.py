from bclearer_core.bie.top.bie_base_identities import (
    BieBaseIdentities,
    create_bie_base_identity_from_bie_identity_vector,
)
from bclearer_core.infrastructure.session.bie_id_registerers.bie_id_registerer import (
    BieIdRegisterer,
)
from bclearer_interop_services.file_system_service.objects.folders import (
    Folders,
)
from bclearer_orchestration_services.file_system_snapshot_service.universe.bie.bie_id_creators.file_system_snapshot_identity_vectors import (
    FileSystemSnapshotObjectIdentityVector,
    FileSystemSnapshotObjectIdentityVectorPlaces,
)
from bclearer_orchestration_services.file_system_snapshot_service.universe.common_knowledge.bie_file_system_snapshot_domain_types import (
    BieFileSystemSnapshotDomainTypes,
)
from bclearer_orchestration_services.file_system_snapshot_service.universe.objects.extended.factories.file_reference_numbers_factory import (
    create_file_reference_numbers,
)
from bclearer_orchestration_services.file_system_snapshot_service.universe.objects.extended.relative_paths import (
    RelativePaths,
)
from bclearer_orchestration_services.file_system_snapshot_service.universe.objects.snapshots.individual_file_system_snapshot_folders import (
    IndividualFileSystemSnapshotFolders,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.common_knowledge.bie_core_relation_types import (
    BieCoreRelationTypes,
)
from bclearer_orchestration_services.identification_services.b_identity_ecosystem.registrations.helpers.registerers.bie_id_issue_requests import (
    RelationBieIdRequest,
)
from bclearer_orchestration_services.identification_services.naming_service.b_sequence_names import (
    BSequenceNames,
)
from bclearer_orchestration_services.snapshot_universe_service.objects.factories.folder_file_byte_contents_factory import (
    create_folder_file_byte_contents,
)
from bclearer_orchestration_services.snapshot_universe_service.objects.snapshot_domains import (
    SnapshotDomains,
)


def create_individual_file_system_snapshot_folders(
    *,
    folder: Folders,
    owning_snapshot_domain: SnapshotDomains,
    relative_path: RelativePaths,
    bie_id_registerer: BieIdRegisterer,
) -> IndividualFileSystemSnapshotFolders:
    file_reference_number = create_file_reference_numbers(
        file_system_object=folder,
        owning_snapshot_domain=owning_snapshot_domain,
        bie_id_registerer=bie_id_registerer,
    )
    file_byte_content = create_folder_file_byte_contents(
        bie_id_registerer=bie_id_registerer,
    )
    bie_base_identity = _create_individual_file_system_snapshot_folder_bie_base_identity(
        folder=folder,
        owning_snapshot_domain=owning_snapshot_domain,
        file_reference_number_bie_id=file_reference_number.bie_id,
    )
    individual_file_system_snapshot_folders = IndividualFileSystemSnapshotFolders(
        folder=folder,
        owning_snapshot_domain=owning_snapshot_domain,
        relative_path=relative_path,
        file_reference_number=file_reference_number,
        file_byte_content=file_byte_content,
        bie_base_identity=bie_base_identity,
    )
    _register_individual_file_system_snapshot_folder_object(
        individual_file_system_snapshot_folders=individual_file_system_snapshot_folders,
        owning_snapshot_domain=owning_snapshot_domain,
        bie_base_identity=bie_base_identity,
        bie_id_registerer=bie_id_registerer,
    )
    return individual_file_system_snapshot_folders


def _create_individual_file_system_snapshot_folder_bie_base_identity(
    *,
    folder: Folders,
    owning_snapshot_domain: SnapshotDomains,
    file_reference_number_bie_id,
) -> BieBaseIdentities:
    places = FileSystemSnapshotObjectIdentityVectorPlaces(
        owning_snapshot_domain_bie_id=owning_snapshot_domain.bie_id,
        base_system_object_bie_id=file_reference_number_bie_id,
    )
    return create_bie_base_identity_from_bie_identity_vector(
        identity_vector=FileSystemSnapshotObjectIdentityVector(
            bie_type=BieFileSystemSnapshotDomainTypes.BIE_INDIVIDUAL_FILE_SYSTEM_SNAPSHOT_FOLDERS,
            bie_hr_name=folder.base_name,
            places=places,
        )
    )


def _register_individual_file_system_snapshot_folder_object(
    *,
    individual_file_system_snapshot_folders: IndividualFileSystemSnapshotFolders,
    owning_snapshot_domain: SnapshotDomains,
    bie_base_identity: BieBaseIdentities,
    bie_id_registerer: BieIdRegisterer,
) -> None:
    bie_id_registerer.register_bie_id(
        bie_base_identity=bie_base_identity,
    )
    bie_id_registerer.issue_and_register_bie_id(
        request=RelationBieIdRequest(
            bie_place_1_id=individual_file_system_snapshot_folders.bie_id,
            bie_place_2_id=owning_snapshot_domain.bie_id,
            bie_relation_type_id=BieCoreRelationTypes.BIE_WHOLES_PARTS.item_bie_identity,
            b_sequence_name=BSequenceNames(
                initial_b_sequence_name_list=[
                    "snapshot_whole_part"
                ]
            ),
        )
    )
    for _, extended_object in individual_file_system_snapshot_folders.extended_objects.items():
        bie_id_registerer.issue_and_register_bie_id(
            request=RelationBieIdRequest(
                bie_place_1_id=individual_file_system_snapshot_folders.bie_id,
                bie_place_2_id=extended_object.bie_id,
                bie_relation_type_id=BieCoreRelationTypes.BIE_WHOLES_PARTS.item_bie_identity,
                b_sequence_name=BSequenceNames(
                    initial_b_sequence_name_list=[
                        "snapshot_whole_part"
                    ]
                ),
            )
        )
