from abc import ABC

from bclearer_core.bie.top.bie_base_identities import (
    BieBaseIdentities,
)
from bclearer_interop_services.file_system_service.objects.file_system_objects import (
    FileSystemObjects,
)
from bclearer_interop_services.file_system_service.objects.path_properties import (
    PathProperties,
)
from bclearer_orchestration_services.file_system_snapshot_service.universe.common_knowledge.bie_file_system_snapshot_domain_types import (
    BieFileSystemSnapshotDomainTypes,
)
from bclearer_orchestration_services.file_system_snapshot_service.universe.objects.extended.file_reference_numbers import (
    FileReferenceNumbers,
)
from bclearer_orchestration_services.snapshot_universe_service.objects.object_contents import (
    ObjectContents,
)
from bclearer_orchestration_services.file_system_snapshot_service.universe.objects.extended.relative_paths import (
    RelativePaths,
)
from bclearer_orchestration_services.file_system_snapshot_service.universe.objects.snapshots.file_system_snapshot_objects import (
    FileSystemSnapshotObjects,
)
from bclearer_orchestration_services.snapshot_universe_service.objects.snapshot_domains import (
    SnapshotDomains,
)


class IndividualFileSystemSnapshotObjects(
    FileSystemSnapshotObjects,
    ABC,
):
    def __init__(
        self,
        bie_domain_type: BieFileSystemSnapshotDomainTypes,
        file_system_object: FileSystemObjects,
        owning_snapshot_domain: SnapshotDomains,
        relative_path: RelativePaths,
        file_reference_number: FileReferenceNumbers,
        object_content: ObjectContents,
        bie_base_identity: BieBaseIdentities,
    ):
        self._bie_domain_type = (
            bie_domain_type
        )

        self._file_system_object = (
            file_system_object
        )

        self.owning_snapshot_domain = (
            owning_snapshot_domain
        )

        self.file_reference_number = (
            file_reference_number
        )

        if (
            file_system_object.absolute_path.exists()
        ):
            self.file_system_object_properties = PathProperties(
                input_file_system_object_path=file_system_object.absolute_path_string,
            )

        super().__init__(
            owning_snapshot_domain=owning_snapshot_domain,
            relative_path=relative_path,
            file_reference_number=self.file_reference_number,
            object_content=object_content,
            bie_base_identity=bie_base_identity,
        )

    def get_file_system_object(
        self,
    ) -> FileSystemObjects:
        return self._file_system_object
