from bclearer_core.infrastructure.session.app_run_session.factories.app_run_session_objects_factory import (
    create_app_run_session_objects,
)
from bclearer_core.infrastructure.session.bie_id_registerers.bie_id_registerer import (
    BieIdRegisterer,
)
from bclearer_interop_services.file_system_service.objects.file_system_objects import (
    FileSystemObjects,
)
from bclearer_orchestration_services.file_system_snapshot_service.universe.bie.bie_file_system_snapshot_universes import (
    BieFileSystemSnapshotUniverses,
)
from bclearer_orchestration_services.file_system_snapshot_service.universe.bie.bie_ids_registerers.file_system_snapshot_universe_bie_ids_registerer import (
    register_file_system_snapshot_universe_bie_ids,
)
from bclearer_orchestration_services.file_system_snapshot_service.universe.bie.bie_ids_registerers.snapshot_bie_ids_registerer import (
    register_snapshot_bie_ids,
)
from bclearer_orchestration_services.file_system_snapshot_service.universe.common_knowledge.file_system_snapshot_app_run_session_types import (
    FileSystemSnapshotAppRunSessionTypes,
)
from bclearer_orchestration_services.file_system_snapshot_service.universe.objects.verses.file_system_snapshot_universes import (
    FileSystemSnapshotUniverses,
)


def create_file_system_snapshot_universes(
    *,
    parallel_bie_universe: BieFileSystemSnapshotUniverses,
    root_file_system_object: FileSystemObjects,
) -> FileSystemSnapshotUniverses:
    bie_id_registerer = BieIdRegisterer(
        bie_infrastructure_registry=parallel_bie_universe.bie_infrastructure_registry,
    )
    app_run_session_object = create_app_run_session_objects(
        bie_app_run_session_type=FileSystemSnapshotAppRunSessionTypes.FILE_SYSTEM_SNAPSHOT_APP_RUN_SESSION,
        bie_id_registerer=bie_id_registerer,
    )
    file_system_snapshot_universes = FileSystemSnapshotUniverses(
        parallel_bie_universe=parallel_bie_universe,
        app_run_session_object=app_run_session_object,
        root_file_system_object=root_file_system_object,
    )
    register_file_system_snapshot_universe_bie_ids(
        bie_infrastructure_registry=parallel_bie_universe.bie_infrastructure_registry,
        file_system_snapshot_universe_registry=file_system_snapshot_universes.file_system_snapshot_universe_registry,
    )
    register_snapshot_bie_ids(
        bie_infrastructure_registry=parallel_bie_universe.bie_infrastructure_registry,
        file_system_snapshot_universe_registry=file_system_snapshot_universes.file_system_snapshot_universe_registry,
    )
    return file_system_snapshot_universes
