# Changelog

All notable changes to the bclearer-orchestration-services package will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.4.3] - 2026-03-19

### Fixed
- Removed `shutdown_logging` re-export from `logging_service/__init__.py` which caused
  a circular import: `b_logging_configurations` → `logging_service` → `log_shutdown` →
  `StandardLoggingProcessLoggers` → `standard_logging_process_console_handler_setter` →
  `b_logging_configurations`. Import `shutdown_logging` directly from
  `bclearer_orchestration_services.logging_service.log_shutdown` if needed explicitly;
  it is also registered automatically via `atexit` on first import of `log_shutdown`.

## [0.4.2] - 2026-03-19

### Added
- `ProcessLoggingLevels.from_standard_level(level_str)` classmethod mapping standard
  Python level names (`DEBUG`, `INFO`, `WARNING`, `ERROR`, `CRITICAL`) to the
  corresponding `ProcessLoggingLevels` enum value. Raises `ValueError` for unknown strings.
- `LogFiles.reset()` classmethod to close the log file and clear all class-level state
  (`log_file`, `folder_path`, `first_open_time`), enabling clean test isolation.
- `LogFiles.open_as_context(folder_path)` static context manager that opens a log file on
  entry and calls `reset()` in a `finally` block on exit, guaranteeing teardown.
- `log_queue_handlers.build_queue_listener(handlers)` helper (stdlib-only) that creates a
  `QueueHandler` + `QueueListener` pair for off-thread log delivery.
- `log_shutdown.shutdown_logging()` function for graceful teardown: stops the
  `QueueListener`, joins the WebSocket daemon thread, and closes log file handles.
  Registered automatically with `atexit`; safe to call multiple times.
- `shutdown_logging` exported from `logging_service.__init__`.
- `log_message()` `include_exc_info` keyword-only parameter (`bool`, default `False`).
  When `True` and an active exception exists, appends the full traceback to the log output.
  Suppressed silently when no exception is active.
- 8 new unit test modules covering all phases of the logging improvements (26 tests).

### Changed
- `StandardLoggingProcessLoggers.debug/info/warning/error/critical` now delegate to
  `super()` instead of silently discarding log records with `pass`.
- `StandardLoggingProcessLoggers.__init__` now wraps file and SQLite handlers behind a
  `QueueHandler`/`QueueListener` (background daemon thread), making log calls from async
  contexts non-blocking. The console handler remains direct.
- `WebSocketLogPublisher.send_log()` is now fire-and-forget: the payload is queued and
  delivered by a daemon thread, so call-site coroutines are never blocked by socket I/O.
- `WebSocketLogPublisher._connect()` reads the connection timeout from
  `BLoggingConfigurations.SOCKET_LOGGING_TIMEOUT_SECONDS` instead of a hard-coded `2.0`.

### Removed
- Kafka import block and `NfKafkaProducers` calls removed from `log_with_datetime.py`,
  `standard_logging_flat_loggers.py`, and `picologging_flat_loggers.py`.
  `NfKafkaProducers` class is retained as a no-op stub for backwards compatibility.

### Notes
- `ENABLE_SOCKET_LOGGING` now defaults to `False` (changed in `bclearer-core 0.3.2`).
  Downstream projects that relied on automatic WebSocket publishing must set
  `BLoggingConfigurations.ENABLE_SOCKET_LOGGING = True` explicitly.
- Async-safe I/O (Phase 6) uses stdlib only (`logging.handlers.QueueHandler`,
  `QueueListener`, `threading.Thread`) — no new dependencies introduced.
- Existing synchronous pipeline code using `run_b_application` and
  `@run_and_log_function` is unaffected.

## [0.4.1] - Previous Release

### Previous Changes
- File system snapshot service and BIE identity improvements.

## [0.4.0] - Previous Release

### Previous Changes
- Initial structured release of bclearer-orchestration-services.
