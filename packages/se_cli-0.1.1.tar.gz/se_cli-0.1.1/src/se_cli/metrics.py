"""Metric calculations for segmentation evaluation.

Optimized to use cKDTree instead of cdist for memory efficiency.
Memory usage: O(n+m) instead of O(n*m) for distance calculations.
"""

import numpy as np
from scipy import ndimage
from scipy.spatial import cKDTree
from typing import Dict, Any, List, Union


def _get_surface_points(arr: np.ndarray) -> np.ndarray:
    """
    Extract surface points from a binary array.

    Args:
        arr: Binary array (1 for foreground, 0 for background).

    Returns:
        Array of surface point coordinates.
    """
    if np.sum(arr) == 0:
        return np.array([])

    # Use binary erosion to find surface
    eroded = ndimage.binary_erosion(arr)
    surface = arr.astype(bool) & ~eroded

    # Get coordinates of surface points
    points = np.array(np.where(surface)).T
    return points


def _is_empty(arr: np.ndarray) -> bool:
    """Check if array is empty (all zeros)."""
    return np.sum(arr) == 0


def _compute_min_distances(points_a: np.ndarray, points_b: np.ndarray) -> np.ndarray:
    """
    Compute minimum distances from each point in A to nearest point in B.

    Uses cKDTree for memory efficiency - O(n+m) instead of O(n*m).

    Args:
        points_a: Array of points (N x D).
        points_b: Array of points (M x D).

    Returns:
        Array of minimum distances (length N).
    """
    if len(points_a) == 0 or len(points_b) == 0:
        return np.array([])

    # Build KDTree from points_b
    tree = cKDTree(points_b)

    # Query nearest neighbor for each point in points_a
    # k=1 returns distance to nearest neighbor
    distances, _ = tree.query(points_a, k=1)

    return distances


def calculate_dsc(seg: np.ndarray, label: np.ndarray) -> float:
    """
    Calculate Dice Similarity Coefficient.

    Args:
        seg: Segmentation result (binary or label array).
        label: Ground truth label (binary or label array).

    Returns:
        DSC value in [0, 1], or NaN if one is empty.
    """
    seg_bool = seg.astype(bool)
    label_bool = label.astype(bool)

    seg_sum = np.sum(seg_bool)
    label_sum = np.sum(label_bool)

    # Both empty -> perfect match
    if seg_sum == 0 and label_sum == 0:
        return 1.0

    # One empty -> undefined
    if seg_sum == 0 or label_sum == 0:
        return np.nan

    intersection = np.sum(seg_bool & label_bool)
    return 2.0 * intersection / (seg_sum + label_sum)


def calculate_hd95(seg: np.ndarray, label: np.ndarray) -> float:
    """
    Calculate Hausdorff Distance 95th percentile.

    Uses cKDTree for memory-efficient nearest neighbor queries.

    Args:
        seg: Segmentation result.
        label: Ground truth label.

    Returns:
        HD95 value, or NaN if one is empty.
    """
    seg_surface = _get_surface_points(seg)
    label_surface = _get_surface_points(label)

    if len(seg_surface) == 0 or len(label_surface) == 0:
        return np.nan

    # Compute minimum distances using cKDTree (memory efficient)
    min_seg_to_label = _compute_min_distances(seg_surface, label_surface)
    min_label_to_seg = _compute_min_distances(label_surface, seg_surface)

    # Combine and get 95th percentile
    all_distances = np.concatenate([min_seg_to_label, min_label_to_seg])
    return float(np.percentile(all_distances, 95))


def calculate_acd(seg: np.ndarray, label: np.ndarray) -> float:
    """
    Calculate Average Contour Distance (Average Surface Distance).

    Uses cKDTree for memory-efficient nearest neighbor queries.

    Args:
        seg: Segmentation result.
        label: Ground truth label.

    Returns:
        ACD value, or NaN if one is empty.
    """
    seg_surface = _get_surface_points(seg)
    label_surface = _get_surface_points(label)

    if len(seg_surface) == 0 or len(label_surface) == 0:
        return np.nan

    # Compute minimum distances using cKDTree (memory efficient)
    min_seg_to_label = _compute_min_distances(seg_surface, label_surface)
    min_label_to_seg = _compute_min_distances(label_surface, seg_surface)

    # Average of minimum distances
    avg_seg_to_label = np.mean(min_seg_to_label)
    avg_label_to_seg = np.mean(min_label_to_seg)

    return float((avg_seg_to_label + avg_label_to_seg) / 2.0)


def calculate_mcd(seg: np.ndarray, label: np.ndarray) -> float:
    """
    Calculate Mean Centerline Distance.

    Uses skeletonization to extract centerlines and computes average distance.
    Uses cKDTree for memory-efficient nearest neighbor queries.

    Args:
        seg: Segmentation result.
        label: Ground truth label.

    Returns:
        MCD value, or NaN if one is empty.
    """
    if _is_empty(seg) or _is_empty(label):
        return np.nan

    try:
        # Skeletonize to get centerline
        seg_skeleton = ndimage.skeletonize(seg.astype(bool))
        label_skeleton = ndimage.skeletonize(label.astype(bool))
    except Exception:
        # Fallback to surface distance if skeletonization fails
        return calculate_acd(seg, label)

    seg_points = np.array(np.where(seg_skeleton)).T
    label_points = np.array(np.where(label_skeleton)).T

    if len(seg_points) == 0 or len(label_points) == 0:
        return np.nan

    # Compute minimum distances using cKDTree (memory efficient)
    min_distances = _compute_min_distances(seg_points, label_points)

    return float(np.mean(min_distances))


def _calculate_class_metrics(
    seg: np.ndarray, label: np.ndarray, class_id: int
) -> Dict[str, float]:
    """Calculate all metrics for a specific class."""
    seg_binary = (seg == class_id).astype(np.int32)
    label_binary = (label == class_id).astype(np.int32)

    return {
        "dsc": calculate_dsc(seg_binary, label_binary),
        "mcd": calculate_mcd(seg_binary, label_binary),
        "hd95": calculate_hd95(seg_binary, label_binary),
        "acd": calculate_acd(seg_binary, label_binary),
    }


def calculate_all_metrics(
    seg: np.ndarray, label: np.ndarray, class_num: int
) -> Dict[str, Union[float, List[Dict[str, float]]]]:
    """
    Calculate all metrics for binary or multi-label segmentation.

    Args:
        seg: Segmentation result.
        label: Ground truth label.
        class_num: Number of classes (2 for binary).

    Returns:
        Dictionary with metric values:
        - Binary: {"dsc": float, "mcd": float, ...}
        - Multi-label: {"dsc": [{"0": float}, {"1": float}, {"avg": float}], ...}
    """
    if class_num == 2:
        # Binary case: compare class 1 only (class 0 is background)
        seg_binary = (seg > 0).astype(np.int32)
        label_binary = (label > 0).astype(np.int32)

        return {
            "dsc": calculate_dsc(seg_binary, label_binary),
            "mcd": calculate_mcd(seg_binary, label_binary),
            "hd95": calculate_hd95(seg_binary, label_binary),
            "acd": calculate_acd(seg_binary, label_binary),
        }

    # Multi-label case
    result: Dict[str, List[Dict[str, float]]] = {
        "dsc": [],
        "mcd": [],
        "hd95": [],
        "acd": [],
    }

    metric_names = ["dsc", "mcd", "hd95", "acd"]
    class_metrics_list = []

    # Calculate for each class (skip background class 0 for average)
    for class_id in range(1, class_num):
        class_metrics = _calculate_class_metrics(seg, label, class_id)
        class_metrics_list.append(class_metrics)

        for metric_name in metric_names:
            result[metric_name].append({str(class_id): class_metrics[metric_name]})

    # Calculate average (excluding NaN values)
    for metric_name in metric_names:
        values = [
            cm[metric_name]
            for cm in class_metrics_list
            if not np.isnan(cm[metric_name])
        ]
        if values:
            avg_value = float(np.mean(values))
        else:
            avg_value = np.nan
        result[metric_name].append({"avg": avg_value})

    return result
