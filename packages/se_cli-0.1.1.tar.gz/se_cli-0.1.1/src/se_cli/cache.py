"""Memory cache manager matching NRDP pattern."""

from __future__ import annotations

import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path
from threading import Lock
from typing import Any, Callable

import numpy as np

from .io_utils import load_nrrd


@dataclass(slots=True)
class PreloadedCase:
    """A preloaded case with segmentation and label data."""
    patient_id: str
    seg_path: Path
    label_path: Path
    seg_array: np.ndarray
    seg_header: dict[str, Any]
    label_array: np.ndarray
    label_header: dict[str, Any]


class CaseCache:
    """Memory cache for preloaded cases, matching NRDP's CommandCache pattern."""

    def __init__(self) -> None:
        self._cases: dict[str, PreloadedCase] = {}
        self._lock = Lock()

    def get(self, patient_id: str) -> PreloadedCase | None:
        with self._lock:
            return self._cases.get(patient_id)

    def put(self, case: PreloadedCase) -> None:
        with self._lock:
            self._cases[case.patient_id] = case

    def contains(self, patient_id: str) -> bool:
        with self._lock:
            return patient_id in self._cases


def _load_single_case(
    patient_id: str,
    seg_path: Path,
    label_path: Path,
) -> PreloadedCase:
    """Load a single case (seg + label)."""
    seg_array, seg_header = load_nrrd(seg_path)
    label_array, label_header = load_nrrd(label_path)
    return PreloadedCase(
        patient_id=patient_id,
        seg_path=seg_path,
        label_path=label_path,
        seg_array=seg_array,
        seg_header=seg_header,
        label_array=label_array,
        label_header=label_header,
    )


def preload_case_batch(
    *,
    cache: CaseCache,
    case_pairs: list[tuple[str, Path, Path]],
    on_loaded: Callable[[PreloadedCase], None] | None = None,
) -> None:
    """
    Preload cases into cache with parallel loading.

    Args:
        cache: CaseCache instance.
        case_pairs: List of (patient_id, seg_path, label_path) tuples.
        on_loaded: Optional callback when each case is loaded.
    """
    pending = [
        (patient_id, seg_path, label_path)
        for patient_id, seg_path, label_path in case_pairs
        if not cache.contains(patient_id)
    ]
    if not pending:
        return

    max_workers = min(8, os.cpu_count() or 4, len(pending))
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [
            executor.submit(_load_single_case, patient_id, seg_path, label_path)
            for patient_id, seg_path, label_path in pending
        ]
        for future in as_completed(futures):
            case = future.result()
            cache.put(case)
            if on_loaded is not None:
                on_loaded(case)
