"""Exam command implementation."""

import os
from pathlib import Path
from typing import Dict, Any, List, Optional
import math
import json

import pandas as pd
import numpy as np
from tqdm import tqdm

from .cache import CaseCache, PreloadedCase, preload_case_batch
from .config import Config
from .io_utils import load_nrrd, discover_patients, resolve_path_pattern, load_jsonc
from .metrics import calculate_all_metrics


class ExamRunner:
    """Runner for segmentation evaluation."""

    def __init__(self, config_dict: Dict[str, Any]):
        """
        Initialize ExamRunner.

        Args:
            config_dict: Configuration dictionary from JSONC file.
        """
        self.config = Config.model_validate(config_dict)
        self.results: List[Dict[str, Any]] = []
        self.skipped_count = 0
        self.skip_reasons: List[str] = []

        # Initialize cache if enabled
        cache_config = self.config.exam.output.cache
        if cache_config.enable_cache:
            self._cache = CaseCache()
        else:
            self._cache = None

    def _discover_cases(self) -> List[str]:
        """Discover patient IDs from the cases directory."""
        root_dir = self.config.exam.case.case_root_dir
        case_data_pattern = self.config.exam.case.case_data_dir

        # Find the directory containing patient folders
        if "{PATIENT_ID}" in case_data_pattern:
            # Extract parent directory of {PATIENT_ID}
            parts = case_data_pattern.split("{PATIENT_ID}")
            # Get the part before {PATIENT_ID} and clean it up
            prefix = parts[0].rstrip("/")
            # Remove any filename part after the last /
            if "/" in prefix:
                parent_dir = os.path.dirname(prefix)
            else:
                parent_dir = prefix
            full_path = os.path.join(root_dir, parent_dir)
            return discover_patients(full_path)
        return []

    def _preload_all_cases(self) -> None:
        """Preload all case files into memory cache."""
        if not self._cache:
            return

        patients = self._discover_cases()
        root_dir = self.config.exam.case.case_root_dir

        # Collect case pairs (patient_id, seg_path, label_path)
        case_pairs = []
        for patient_id in patients:
            seg_path = Path(resolve_path_pattern(
                self.config.exam.case.case_seg_dir, patient_id, root_dir
            ))
            label_path = Path(resolve_path_pattern(
                self.config.exam.case.case_label_dir, patient_id, root_dir
            ))
            # Only add if both files exist
            if seg_path.exists() and label_path.exists():
                case_pairs.append((patient_id, seg_path, label_path))

        if not case_pairs:
            return

        # Preload with callback for progress
        if self.config.exam.output.status:
            print(f"Preloading {len(case_pairs)} cases into memory...")
            loaded_count = 0

            def on_case_loaded(case: PreloadedCase) -> None:
                nonlocal loaded_count
                loaded_count += 1
                print(f"  Loaded {loaded_count}/{len(case_pairs)}: {case.patient_id}")

            preload_case_batch(
                cache=self._cache,
                case_pairs=case_pairs,
                on_loaded=on_case_loaded,
            )
            print(f"Cache ready: {loaded_count} cases loaded")
        else:
            preload_case_batch(
                cache=self._cache,
                case_pairs=case_pairs,
            )

    def _load_case(self, patient_id: str) -> Optional[tuple]:
        """
        Load segmentation and label for a case.

        Args:
            patient_id: Patient identifier.

        Returns:
            Tuple of (seg_array, label_array) or None if loading fails.
        """
        root_dir = self.config.exam.case.case_root_dir

        seg_path = resolve_path_pattern(
            self.config.exam.case.case_seg_dir, patient_id, root_dir
        )
        label_path = resolve_path_pattern(
            self.config.exam.case.case_label_dir, patient_id, root_dir
        )

        try:
            # Try to get from cache first
            if self._cache:
                case = self._cache.get(patient_id)
                if case is not None:
                    return case.seg_array, case.label_array

                # Load and cache if not found
                seg, seg_header = load_nrrd(seg_path)
                label, label_header = load_nrrd(label_path)

                preloaded = PreloadedCase(
                    patient_id=patient_id,
                    seg_path=Path(seg_path),
                    label_path=Path(label_path),
                    seg_array=seg,
                    seg_header=seg_header,
                    label_array=label,
                    label_header=label_header,
                )
                self._cache.put(preloaded)
                return seg, label
            else:
                seg, seg_header = load_nrrd(seg_path)
                label, label_header = load_nrrd(label_path)

            return seg, label
        except FileNotFoundError as e:
            self.skip_reasons.append(f"{patient_id}: {str(e)}")
            return None

    def _format_metric_value(
        self, value: Any, is_multiclass: bool
    ) -> Any:
        """Format metric value for CSV output."""
        if isinstance(value, list):
            # Multi-label format
            return json.dumps(value)
        return value

    def run(self) -> List[Dict[str, Any]]:
        """
        Run the evaluation.

        Returns:
            List of result dictionaries.
        """
        patients = self._discover_cases()

        # Preload files if cache is enabled
        cache_config = self.config.exam.output.cache
        if cache_config.enable_cache and cache_config.preload_all and self._cache:
            self._preload_all_cases()

        info_config = self.config.exam.output.info
        class_num = self.config.data.class_num

        iterator = patients
        if self.config.exam.output.status:
            iterator = tqdm(patients, desc="Processing cases", unit="case")

        for patient_id in iterator:
            case_data = self._load_case(patient_id)
            if case_data is None:
                self.skipped_count += 1
                continue

            seg, label = case_data

            # Check for empty segmentation
            if np.sum(seg) == 0:
                self.skipped_count += 1
                self.skip_reasons.append(f"{patient_id}: empty segmentation")
                result = {"patient_id": patient_id}
                if info_config.dsc:
                    result["dsc"] = np.nan
                if info_config.mcd:
                    result["mcd"] = np.nan
                if info_config.hd95:
                    result["hd95"] = np.nan
                if info_config.acd:
                    result["acd"] = np.nan
                self.results.append(result)
                continue

            # Calculate metrics
            metrics = calculate_all_metrics(seg, label, class_num)

            result: Dict[str, Any] = {"patient_id": patient_id}
            is_multiclass = class_num > 2

            if info_config.dsc:
                result["dsc"] = self._format_metric_value(
                    metrics["dsc"], is_multiclass
                )
            if info_config.mcd:
                result["mcd"] = self._format_metric_value(
                    metrics["mcd"], is_multiclass
                )
            if info_config.hd95:
                result["hd95"] = self._format_metric_value(
                    metrics["hd95"], is_multiclass
                )
            if info_config.acd:
                result["acd"] = self._format_metric_value(
                    metrics["acd"], is_multiclass
                )

            self.results.append(result)

        return self.results

    def save_csv(self) -> str:
        """
        Save results to CSV file.

        Returns:
            Path to the saved CSV file.
        """
        if not self.results:
            return ""

        output_dir = Path(self.config.exam.output.dir.output_root_dir)
        csv_subdir = Path(self.config.exam.output.dir.csv_dir)
        csv_path = output_dir / csv_subdir / "exam_result.csv"

        # Create directory if needed
        csv_path.parent.mkdir(parents=True, exist_ok=True)

        df = pd.DataFrame(self.results)
        df.to_csv(csv_path, index=False)

        return str(csv_path)

    def print_summary(self) -> None:
        """Print summary of evaluation."""
        completed = len(self.results) - sum(1 for r in self.results if any(
            isinstance(v, float) and math.isnan(v) for v in r.values() if v != r.get("patient_id")
        ))
        skipped = self.skipped_count

        print(f"\n✓ Completed: {completed} cases")
        if skipped > 0:
            print(f"⚠ Skipped: {skipped} cases")


def run_exam(config_path: str) -> None:
    """
    Run exam command from config file.

    Args:
        config_path: Path to JSONC configuration file.
    """
    from .io_utils import load_jsonc

    config_dict = load_jsonc(config_path)
    runner = ExamRunner(config_dict)
    runner.run()

    if runner.config.exam.output.csv:
        csv_path = runner.save_csv()
        print(f"\nResults saved to: {csv_path}")

    if runner.config.exam.output.status:
        runner.print_summary()


def generate_example_config() -> str:
    """
    Generate example configuration file content.

    Returns:
        Example JSONC content string.
    """
    return '''{
  "data": {
    "class_num": 2,
    "class_info": {
      "0": "background",
      "1": "tumor"
    }
  },
  "exam": {
    "case": {
      "case_root_dir": "data/nrdp-2",
      "case_data_dir": "cases/{PATIENT_ID}/input/{PATIENT_ID}.image.nrrd",
      "case_seg_dir": "cases/{PATIENT_ID}/segmentation/{PATIENT_ID}.seg.nrrd",
      "case_label_dir": "label/{PATIENT_ID}.label.nrrd"
    },
    "output": {
      "csv": true,
      "status": true,  // Show progress bar
      "info": {
        "dsc": true,   // Dice Similarity Coefficient
        "mcd": true,   // Mean Centerline Distance
        "hd95": true,  // Hausdorff Distance 95%
        "acd": true    // Average Contour Distance
      },
      "dir": {
        "output_root_dir": "output",
        "csv_dir": "./"
      },
      "cache": {
        "enable_cache": true,      // Enable memory caching
        "preload_all": true        // Preload all files into memory at startup
      }
    }
  }
}'''
