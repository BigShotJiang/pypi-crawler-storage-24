"""Main CLI entry point for se-cli."""

import os
from pathlib import Path
from typing import Optional

import typer
from . import __version__
from .exam import run_exam, generate_example_config

app = typer.Typer(
    name="se",
    help="SE-CLI: Medical image segmentation evaluation tool",
    add_completion=False,
)

# Create exam subcommand group
exam_app = typer.Typer(
    name="exam",
    help="Segmentation evaluation commands",
)
app.add_typer(exam_app, name="exam")


def version_callback(value: bool) -> None:
    """Print version and exit."""
    if value:
        print(f"se-cli version: {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(
        False,
        "--version",
        "-v",
        help="Show version and exit",
        callback=version_callback,
        is_eager=True,
    ),
) -> None:
    """SE-CLI: Medical image segmentation evaluation tool."""
    pass


@exam_app.callback(invoke_without_command=True)
def exam_main(
    ctx: typer.Context,
    input: Optional[Path] = typer.Option(
        None,
        "--input",
        "-i",
        help="Path to JSONC configuration file",
    ),
) -> None:
    """
    Run segmentation evaluation.

    Use 'se exam --input config.jsonc' to run evaluation.
    Use 'se exam get' to generate example configuration.
    """
    if ctx.invoked_subcommand is not None:
        return

    if input is None:
        print("Error: --input is required when no subcommand is specified.")
        print("Use 'se exam get' to generate an example configuration.")
        raise typer.Exit(1)

    if not input.exists():
        print(f"Error: Configuration file not found: {input}")
        raise typer.Exit(1)

    run_exam(str(input))


@exam_app.command("get")
def get_example() -> None:
    """Generate example configuration file in current directory."""
    output_path = Path.cwd() / "data.jsonc"

    if output_path.exists():
        overwrite = typer.confirm(
            f"{output_path} already exists. Overwrite?",
            default=False,
        )
        if not overwrite:
            print("Cancelled.")
            raise typer.Exit()

    content = generate_example_config()
    output_path.write_text(content, encoding="utf-8")
    print(f"Example configuration saved to: {output_path}")
