"""SE-CLI: Medical image segmentation evaluation CLI."""

__version__ = "0.1.1"
