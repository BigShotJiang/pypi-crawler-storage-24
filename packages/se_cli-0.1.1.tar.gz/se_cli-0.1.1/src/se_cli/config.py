"""Pydantic configuration models for se-cli."""

from pydantic import BaseModel, Field
from typing import Dict, Optional


class DirConfig(BaseModel):
    """Directory configuration for output."""

    output_root_dir: str = Field(default="output", description="Output root directory")
    csv_dir: str = Field(default="./", description="CSV subdirectory")


class InfoConfig(BaseModel):
    """Metric toggle configuration."""

    dsc: bool = Field(default=True, description="Calculate Dice coefficient")
    mcd: bool = Field(default=True, description="Calculate Mean Centerline Distance")
    hd95: bool = Field(default=True, description="Calculate Hausdorff Distance 95%")
    acd: bool = Field(default=True, description="Calculate Average Contour Distance")


class CacheConfig(BaseModel):
    """Memory cache configuration."""

    enable_cache: bool = Field(default=True, description="Enable memory cache")
    preload_all: bool = Field(default=True, description="Preload all files into memory at startup")


class OutputConfig(BaseModel):
    """Output configuration."""

    csv: bool = Field(default=True, description="Enable CSV output")
    status: bool = Field(default=True, description="Show progress bar")
    info: InfoConfig = Field(default_factory=InfoConfig)
    dir: DirConfig = Field(default_factory=DirConfig)
    cache: CacheConfig = Field(default_factory=CacheConfig)


class CaseConfig(BaseModel):
    """Case path configuration."""

    case_root_dir: str = Field(description="Root directory for dataset")
    case_data_dir: str = Field(description="Path pattern for input images")
    case_seg_dir: str = Field(description="Path pattern for segmentation results")
    case_label_dir: str = Field(description="Path pattern for ground truth labels")


class ExamConfig(BaseModel):
    """Exam command configuration."""

    case: CaseConfig
    output: OutputConfig = Field(default_factory=OutputConfig)


class DataConfig(BaseModel):
    """Data configuration for class information."""

    class_num: int = Field(default=2, ge=2, description="Number of classes")
    class_info: Dict[str, str] = Field(
        default_factory=lambda: {"0": "background", "1": "foreground"},
        description="Class label descriptions"
    )


class Config(BaseModel):
    """Root configuration model."""

    data: DataConfig = Field(default_factory=DataConfig)
    exam: ExamConfig
