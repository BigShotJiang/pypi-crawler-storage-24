"""File I/O utilities for se-cli."""

import os
from pathlib import Path
from typing import Tuple, List, Any, Dict

import commentjson
import nrrd
import numpy as np


def load_jsonc(file_path: str) -> Dict[str, Any]:
    """
    Load a JSONC file (JSON with comments).

    Args:
        file_path: Path to the JSONC file.

    Returns:
        Parsed dictionary.

    Raises:
        FileNotFoundError: If file doesn't exist.
        ValueError: If JSONC parsing fails.
    """
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"Configuration file not found: {file_path}")

    try:
        with open(path, "r", encoding="utf-8") as f:
            return commentjson.load(f)
    except commentjson.JSONLibraryException as e:
        raise ValueError(f"Failed to parse JSONC file {file_path}: {e}")


def load_nrrd(file_path: str) -> Tuple[np.ndarray, Dict[str, Any]]:
    """
    Load a NRRD file.

    Args:
        file_path: Path to the NRRD file.

    Returns:
        Tuple of (data array, header dict).

    Raises:
        FileNotFoundError: If file doesn't exist.
    """
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"NRRD file not found: {file_path}")

    data, header = nrrd.read(str(path))
    return data, header


def discover_patients(cases_dir: str) -> List[str]:
    """
    Discover patient IDs from the cases directory.

    Args:
        cases_dir: Path to the cases directory.

    Returns:
        List of patient IDs (directory names).
    """
    path = Path(cases_dir)
    if not path.exists():
        return []

    return [
        d.name
        for d in path.iterdir()
        if d.is_dir() and not d.name.startswith(".")
    ]


def resolve_path_pattern(pattern: str, patient_id: str, root_dir: str) -> str:
    """
    Resolve a path pattern with patient ID placeholder.

    Args:
        pattern: Path pattern containing {PATIENT_ID}.
        patient_id: The patient ID to substitute.
        root_dir: Root directory to prepend.

    Returns:
        Resolved absolute path.
    """
    resolved = pattern.replace("{PATIENT_ID}", patient_id)
    return os.path.join(root_dir, resolved)
