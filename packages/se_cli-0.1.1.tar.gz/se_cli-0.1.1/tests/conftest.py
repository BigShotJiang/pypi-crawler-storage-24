"""Pytest configuration and fixtures."""

import pytest
import numpy as np
import tempfile
import os


@pytest.fixture
def temp_dir():
    """Create a temporary directory for tests."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield tmpdir


@pytest.fixture
def sample_binary_seg():
    """Create a sample binary segmentation array (10x10x10)."""
    arr = np.zeros((10, 10, 10), dtype=np.int32)
    arr[2:8, 2:8, 2:8] = 1
    return arr


@pytest.fixture
def sample_binary_label():
    """Create a sample binary ground truth array (10x10x10) with slight offset."""
    arr = np.zeros((10, 10, 10), dtype=np.int32)
    arr[3:9, 3:9, 3:9] = 1
    return arr


@pytest.fixture
def sample_multiclass_seg():
    """Create a sample multi-label segmentation array."""
    arr = np.zeros((10, 10, 10), dtype=np.int32)
    arr[2:5, 2:5, 2:5] = 1
    arr[6:9, 6:9, 6:9] = 2
    return arr


@pytest.fixture
def sample_multiclass_label():
    """Create a sample multi-label ground truth array."""
    arr = np.zeros((10, 10, 10), dtype=np.int32)
    arr[2:5, 2:5, 2:5] = 1
    arr[5:8, 5:8, 5:8] = 2
    return arr
