"""Tests for se-cli."""
