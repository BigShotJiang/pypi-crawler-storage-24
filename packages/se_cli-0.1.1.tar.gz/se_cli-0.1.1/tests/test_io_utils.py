"""Tests for I/O utilities."""

import pytest
import os
import nrrd
import numpy as np
from se_cli.io_utils import load_jsonc, load_nrrd, discover_patients


def test_load_jsonc(temp_dir):
    """Test loading JSONC file with comments."""
    jsonc_content = '''
    {
        // This is a comment
        "key": "value",
        "number": 42
    }
    '''
    jsonc_path = os.path.join(temp_dir, "test.jsonc")
    with open(jsonc_path, "w") as f:
        f.write(jsonc_content)

    result = load_jsonc(jsonc_path)
    assert result["key"] == "value"
    assert result["number"] == 42


def test_load_jsonc_file_not_found():
    """Test error handling for missing file."""
    with pytest.raises(FileNotFoundError):
        load_jsonc("/nonexistent/path.jsonc")


def test_load_nrrd(temp_dir, sample_binary_seg):
    """Test loading NRRD file."""
    nrrd_path = os.path.join(temp_dir, "test.nrrd")
    nrrd.write(nrrd_path, sample_binary_seg)

    data, header = load_nrrd(nrrd_path)
    assert data.shape == (10, 10, 10)
    assert np.sum(data) > 0


def test_load_nrrd_file_not_found():
    """Test error handling for missing NRRD file."""
    with pytest.raises(FileNotFoundError):
        load_nrrd("/nonexistent/path.nrrd")


def test_discover_patients(temp_dir):
    """Test patient ID discovery from directory structure."""
    # Create mock directory structure
    cases_dir = os.path.join(temp_dir, "cases")
    os.makedirs(cases_dir)

    for patient_id in ["MR001", "MR002", "UMR003"]:
        os.makedirs(os.path.join(cases_dir, patient_id))

    patients = discover_patients(cases_dir)
    assert len(patients) == 3
    assert "MR001" in patients
    assert "UMR003" in patients


def test_discover_patients_empty_dir(temp_dir):
    """Test patient discovery with empty directory."""
    cases_dir = os.path.join(temp_dir, "empty")
    os.makedirs(cases_dir)

    patients = discover_patients(cases_dir)
    assert patients == []
