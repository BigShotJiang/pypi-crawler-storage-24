"""Tests for metric calculations."""

import pytest
import numpy as np
from se_cli.metrics import (
    calculate_dsc,
    calculate_mcd,
    calculate_hd95,
    calculate_acd,
    calculate_all_metrics,
)


class TestDSC:
    """Tests for Dice Similarity Coefficient."""

    def test_dsc_perfect_match(self, sample_binary_seg):
        """DSC should be 1.0 for identical arrays."""
        dsc = calculate_dsc(sample_binary_seg, sample_binary_seg)
        assert dsc == 1.0

    def test_dsc_partial_overlap(self, sample_binary_seg, sample_binary_label):
        """DSC should be between 0 and 1 for partial overlap."""
        dsc = calculate_dsc(sample_binary_seg, sample_binary_label)
        assert 0 < dsc < 1

    def test_dsc_no_overlap(self, sample_binary_seg):
        """DSC should be 0 for no overlap."""
        empty = np.zeros_like(sample_binary_seg)
        dsc = calculate_dsc(sample_binary_seg, empty)
        assert np.isnan(dsc)

    def test_dsc_both_empty(self):
        """DSC should be 1.0 when both are empty (by convention)."""
        empty1 = np.zeros((10, 10, 10))
        empty2 = np.zeros((10, 10, 10))
        dsc = calculate_dsc(empty1, empty2)
        assert dsc == 1.0

    def test_dsc_seg_empty(self, sample_binary_seg):
        """DSC should be NaN when segmentation is empty."""
        empty = np.zeros_like(sample_binary_seg)
        dsc = calculate_dsc(empty, sample_binary_seg)
        assert np.isnan(dsc)

    def test_dsc_label_empty(self, sample_binary_seg):
        """DSC should be NaN when label is empty."""
        empty = np.zeros_like(sample_binary_seg)
        dsc = calculate_dsc(sample_binary_seg, empty)
        assert np.isnan(dsc)


class TestHD95:
    """Tests for Hausdorff Distance 95%."""

    def test_hd95_perfect_match(self, sample_binary_seg):
        """HD95 should be 0 for identical arrays."""
        hd95 = calculate_hd95(sample_binary_seg, sample_binary_seg)
        assert hd95 == 0.0

    def test_hd95_partial_overlap(self, sample_binary_seg, sample_binary_label):
        """HD95 should be positive for different arrays."""
        hd95 = calculate_hd95(sample_binary_seg, sample_binary_label)
        assert hd95 > 0

    def test_hd95_seg_empty(self, sample_binary_seg):
        """HD95 should be NaN when segmentation is empty."""
        empty = np.zeros_like(sample_binary_seg)
        hd95 = calculate_hd95(empty, sample_binary_seg)
        assert np.isnan(hd95)


class TestACD:
    """Tests for Average Contour Distance."""

    def test_acd_perfect_match(self, sample_binary_seg):
        """ACD should be 0 for identical arrays."""
        acd = calculate_acd(sample_binary_seg, sample_binary_seg)
        assert acd == 0.0

    def test_acd_partial_overlap(self, sample_binary_seg, sample_binary_label):
        """ACD should be positive for different arrays."""
        acd = calculate_acd(sample_binary_seg, sample_binary_label)
        assert acd > 0


class TestMCD:
    """Tests for Mean Centerline Distance."""

    def test_mcd_perfect_match(self, sample_binary_seg):
        """MCD should be 0 for identical arrays."""
        mcd = calculate_mcd(sample_binary_seg, sample_binary_seg)
        assert mcd == 0.0

    def test_mcd_partial_overlap(self, sample_binary_seg, sample_binary_label):
        """MCD should be positive for different arrays."""
        mcd = calculate_mcd(sample_binary_seg, sample_binary_label)
        assert mcd > 0


class TestCalculateAllMetrics:
    """Tests for batch metric calculation."""

    def test_calculate_all_binary(self, sample_binary_seg, sample_binary_label):
        """Test calculating all metrics for binary segmentation."""
        metrics = calculate_all_metrics(sample_binary_seg, sample_binary_label, class_num=2)

        assert "dsc" in metrics
        assert "mcd" in metrics
        assert "hd95" in metrics
        assert "acd" in metrics
        assert isinstance(metrics["dsc"], float)

    def test_calculate_all_multiclass(self, sample_multiclass_seg, sample_multiclass_label):
        """Test calculating all metrics for multi-label segmentation."""
        metrics = calculate_all_metrics(
            sample_multiclass_seg, sample_multiclass_label, class_num=3
        )

        assert isinstance(metrics["dsc"], list)
        assert len(metrics["dsc"]) == 3  # class 1, 2, and avg
