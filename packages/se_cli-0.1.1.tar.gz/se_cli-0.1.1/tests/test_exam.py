"""Tests for exam command."""

import pytest
import os
import nrrd
import numpy as np
from se_cli.exam import ExamRunner


class TestExamRunner:
    """Tests for ExamRunner class."""

    def test_init_with_config(self, temp_dir):
        """Test ExamRunner initialization with config dict."""
        config_dict = {
            "data": {"class_num": 2, "class_info": {"0": "bg", "1": "fg"}},
            "exam": {
                "case": {
                    "case_root_dir": temp_dir,
                    "case_data_dir": "input.nrrd",
                    "case_seg_dir": "seg.nrrd",
                    "case_label_dir": "label.nrrd",
                },
                "output": {
                    "csv": True,
                    "status": False,
                    "info": {"dsc": True, "mcd": True, "hd95": True, "acd": True},
                    "dir": {"output_root_dir": temp_dir, "csv_dir": "./"},
                },
            },
        }
        runner = ExamRunner(config_dict)
        assert runner.config.data.class_num == 2

    def test_run_single_case(self, temp_dir, sample_binary_seg, sample_binary_label):
        """Test running evaluation on a single case."""
        # Setup directory structure
        case_dir = os.path.join(temp_dir, "cases", "MR001")
        os.makedirs(case_dir, exist_ok=True)

        seg_path = os.path.join(case_dir, "seg.nrrd")
        label_path = os.path.join(temp_dir, "label", "MR001.label.nrrd")
        os.makedirs(os.path.dirname(label_path), exist_ok=True)

        nrrd.write(seg_path, sample_binary_seg)
        nrrd.write(label_path, sample_binary_label)

        config_dict = {
            "data": {"class_num": 2, "class_info": {"0": "bg", "1": "fg"}},
            "exam": {
                "case": {
                    "case_root_dir": temp_dir,
                    "case_data_dir": "cases/{PATIENT_ID}/input.nrrd",
                    "case_seg_dir": "cases/{PATIENT_ID}/seg.nrrd",
                    "case_label_dir": "label/{PATIENT_ID}.label.nrrd",
                },
                "output": {
                    "csv": True,
                    "status": False,
                    "info": {"dsc": True, "mcd": True, "hd95": True, "acd": True},
                    "dir": {"output_root_dir": temp_dir, "csv_dir": "./"},
                },
            },
        }

        runner = ExamRunner(config_dict)
        results = runner.run()

        assert len(results) == 1
        assert results[0]["patient_id"] == "MR001"
        assert "dsc" in results[0]
        assert 0 <= results[0]["dsc"] <= 1

    def test_run_multiple_cases(self, temp_dir, sample_binary_seg, sample_binary_label):
        """Test running evaluation on multiple cases."""
        # Setup directory structure for multiple cases
        for patient_id in ["MR001", "MR002", "MR003"]:
            case_dir = os.path.join(temp_dir, "cases", patient_id)
            os.makedirs(case_dir, exist_ok=True)

            seg_path = os.path.join(case_dir, "seg.nrrd")
            nrrd.write(seg_path, sample_binary_seg)

        label_dir = os.path.join(temp_dir, "label")
        os.makedirs(label_dir, exist_ok=True)
        for patient_id in ["MR001", "MR002", "MR003"]:
            label_path = os.path.join(label_dir, f"{patient_id}.label.nrrd")
            nrrd.write(label_path, sample_binary_label)

        config_dict = {
            "data": {"class_num": 2, "class_info": {"0": "bg", "1": "fg"}},
            "exam": {
                "case": {
                    "case_root_dir": temp_dir,
                    "case_data_dir": "cases/{PATIENT_ID}/input.nrrd",
                    "case_seg_dir": "cases/{PATIENT_ID}/seg.nrrd",
                    "case_label_dir": "label/{PATIENT_ID}.label.nrrd",
                },
                "output": {
                    "csv": True,
                    "status": False,
                    "info": {"dsc": True, "mcd": True, "hd95": True, "acd": True},
                    "dir": {"output_root_dir": temp_dir, "csv_dir": "./"},
                },
            },
        }

        runner = ExamRunner(config_dict)
        results = runner.run()

        assert len(results) == 3
        patient_ids = [r["patient_id"] for r in results]
        assert "MR001" in patient_ids
        assert "MR002" in patient_ids
        assert "MR003" in patient_ids

    def test_save_csv(self, temp_dir, sample_binary_seg, sample_binary_label):
        """Test CSV output generation."""
        # Setup
        case_dir = os.path.join(temp_dir, "cases", "MR001")
        os.makedirs(case_dir, exist_ok=True)
        seg_path = os.path.join(case_dir, "seg.nrrd")
        nrrd.write(seg_path, sample_binary_seg)

        label_dir = os.path.join(temp_dir, "label")
        os.makedirs(label_dir, exist_ok=True)
        label_path = os.path.join(label_dir, "MR001.label.nrrd")
        nrrd.write(label_path, sample_binary_label)

        config_dict = {
            "data": {"class_num": 2, "class_info": {"0": "bg", "1": "fg"}},
            "exam": {
                "case": {
                    "case_root_dir": temp_dir,
                    "case_data_dir": "cases/{PATIENT_ID}/input.nrrd",
                    "case_seg_dir": "cases/{PATIENT_ID}/seg.nrrd",
                    "case_label_dir": "label/{PATIENT_ID}.label.nrrd",
                },
                "output": {
                    "csv": True,
                    "status": False,
                    "info": {"dsc": True, "mcd": True, "hd95": True, "acd": True},
                    "dir": {"output_root_dir": temp_dir, "csv_dir": "./"},
                },
            },
        }

        runner = ExamRunner(config_dict)
        runner.run()
        csv_path = runner.save_csv()

        assert os.path.exists(csv_path)
        assert csv_path.endswith("exam_result.csv")
