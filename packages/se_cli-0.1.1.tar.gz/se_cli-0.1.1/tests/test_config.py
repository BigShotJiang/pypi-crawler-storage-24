"""Tests for configuration models."""

import pytest
from se_cli.config import ExamConfig, OutputConfig, CaseConfig, DataConfig, Config


def test_case_config_defaults():
    """Test CaseConfig with default values."""
    config = CaseConfig(
        case_root_dir="data/test",
        case_data_dir="cases/{PATIENT_ID}/input.nrrd",
        case_seg_dir="cases/{PATIENT_ID}/seg.nrrd",
        case_label_dir="label/{PATIENT_ID}.nrrd",
    )
    assert config.case_root_dir == "data/test"
    assert "{PATIENT_ID}" in config.case_data_dir


def test_output_config_defaults():
    """Test OutputConfig with default values."""
    config = OutputConfig()
    assert config.csv is True
    assert config.status is True
    assert config.info.dsc is True
    assert config.info.mcd is True


def test_info_config():
    """Test InfoConfig for metric toggles."""
    from se_cli.config import InfoConfig
    config = InfoConfig(dsc=True, mcd=False, hd95=True, acd=False)
    assert config.dsc is True
    assert config.mcd is False


def test_data_config():
    """Test DataConfig for class information."""
    config = DataConfig(
        class_num=2,
        class_info={"0": "background", "1": "tumor"}
    )
    assert config.class_num == 2
    assert config.class_info["1"] == "tumor"


def test_full_config():
    """Test full Config model composition."""
    config = Config(
        data=DataConfig(class_num=2, class_info={"0": "bg", "1": "fg"}),
        exam=ExamConfig(
            case=CaseConfig(
                case_root_dir="data",
                case_data_dir="input.nrrd",
                case_seg_dir="seg.nrrd",
                case_label_dir="label.nrrd",
            ),
            output=OutputConfig(),
        )
    )
    assert config.data.class_num == 2
    assert config.exam.output.csv is True
