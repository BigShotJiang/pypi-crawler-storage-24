# SE-CLI

Medical image segmentation evaluation CLI tool.

## Installation

```bash
pip install se-cli
```

## Usage

```bash
# Show version
se --version

# Run evaluation
se exam --input config.jsonc

# Generate example config
se exam get
```

## License

MIT
