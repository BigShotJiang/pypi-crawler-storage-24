"""EVREN Python SDK — nesne tespiti ve goruntu cikarim istemcisi."""

from .client import AsyncEvrenClient, EvrenClient
from .exceptions import (
    AuthenticationError,
    EvrenError,
    InferenceError,
    NotFoundError,
    RateLimitError,
    ValidationError,
)
from .models import (
    BatchResult,
    ClassInfo,
    ModelClasses,
    ModelInfo,
    ModelVersion,
    Prediction,
    PredictResult,
)

__version__ = "0.3.0"

__all__ = [
    "EvrenClient",
    "AsyncEvrenClient",
    "EvrenError",
    "AuthenticationError",
    "NotFoundError",
    "RateLimitError",
    "InferenceError",
    "ValidationError",
    "Prediction",
    "PredictResult",
    "BatchResult",
    "ClassInfo",
    "ModelClasses",
    "ModelInfo",
    "ModelVersion",
]
