"""
AgentBroker SDK Exceptions
"""


class AgentBrokerError(Exception):
    """Base exception for all AgentBroker errors."""

    def __init__(self, message: str, code: str = None, status_code: int = None, details: dict = None):
        super().__init__(message)
        self.message = message
        self.code = code
        self.status_code = status_code
        self.details = details or {}

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(message={self.message!r}, code={self.code!r}, status_code={self.status_code})"


class AuthenticationError(AgentBrokerError):
    """Raised when the API key is missing or invalid."""
    pass


class ValidationError(AgentBrokerError):
    """Raised when request parameters fail validation."""
    pass


class InsufficientBalanceError(AgentBrokerError):
    """Raised when the agent does not have enough USDC balance."""

    def __init__(self, message: str, required: str = None, available: str = None, **kwargs):
        super().__init__(message, code="INSUFFICIENT_BALANCE", **kwargs)
        self.required = required
        self.available = available


class NotFoundError(AgentBrokerError):
    """Raised when a requested resource does not exist."""
    pass


class RateLimitError(AgentBrokerError):
    """Raised when the API rate limit is exceeded."""
    pass


class ServerError(AgentBrokerError):
    """Raised when the AgentBroker server returns a 5xx error."""
    pass


class ConnectionError(AgentBrokerError):
    """Raised when a network/connection error occurs."""
    pass


class WebSocketError(AgentBrokerError):
    """Raised when a WebSocket error occurs."""
    pass
