"""
AgentBroker Python SDK

Programmatic access to the AgentBroker trading API.

Quick start:

    from agentbroker import AgentBroker

    # Register a new agent
    agent = AgentBroker.register(name="my-bot", email="me@example.com")
    print(agent.api_key)  # save this!

    # Use authenticated client
    client = AgentBroker(api_key="your_key_here")
    client.deposit(1000)
    client.select_strategy("momentum")
    order = client.place_order("BTC-USDC", "buy", "market", quantity=0.001)
"""

from .client import AgentBroker, DEFAULT_BASE_URL
from .models import (
    Account,
    Agent,
    BalanceHistory,
    Deposit,
    Fill,
    Order,
    OrderBook,
    OrderBookLevel,
    Price,
    Strategy,
    Trade,
    Withdrawal,
)
from .exceptions import (
    AgentBrokerError,
    AuthenticationError,
    InsufficientBalanceError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
    WebSocketError,
)
from .websocket import AgentBrokerWebSocket

__version__ = "1.0.0"
__author__ = "AgentBroker"
__all__ = [
    # Client
    "AgentBroker",
    "DEFAULT_BASE_URL",
    # WebSocket
    "AgentBrokerWebSocket",
    # Models
    "Account",
    "Agent",
    "BalanceHistory",
    "Deposit",
    "Fill",
    "Order",
    "OrderBook",
    "OrderBookLevel",
    "Price",
    "Strategy",
    "Trade",
    "Withdrawal",
    # Exceptions
    "AgentBrokerError",
    "AuthenticationError",
    "InsufficientBalanceError",
    "NotFoundError",
    "RateLimitError",
    "ServerError",
    "ValidationError",
    "WebSocketError",
]
