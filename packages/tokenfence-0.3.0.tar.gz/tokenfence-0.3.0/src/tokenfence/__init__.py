"""TokenFence — cost circuit breaker & runtime guardrails for AI agents."""

from .exceptions import BudgetExceeded, TokenFenceError
from .guard import guard
from .async_guard import async_guard
from .policy import Policy, PolicyResult, Decision, ToolDenied, AuditEntry

__all__ = [
    "guard",
    "async_guard",
    "TokenFenceError",
    "BudgetExceeded",
    # AgentGuard Policy engine
    "Policy",
    "PolicyResult",
    "Decision",
    "ToolDenied",
    "AuditEntry",
]
__version__ = "0.3.0"
