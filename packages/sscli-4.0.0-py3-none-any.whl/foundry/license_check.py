"""License verification against auth.seedsource.dev.

Provides verify_license() — must be called at the start of every template pull,
before any file operations.  Uses the same requests + CREDENTIALS_FILE pattern
as foundry/auth.py.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict

import requests
import typer

from foundry.auth import CREDENTIALS_FILE
from foundry.constants import API_BASE_URL, console


def _get_token() -> str | None:
    """Read stored token from credentials file or SSCLI_TOKEN env var.

    Env var takes precedence (supports CI/CD pipelines and test overrides).
    Falls back to the credentials file written by ``sscli auth login``.
    """
    if token := os.getenv("SSCLI_TOKEN"):
        return token
    try:
        with open(CREDENTIALS_FILE, "r") as f:
            data = json.load(f)
        return data.get("access_token")
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return None


def verify_license(required_tier: str = "alpha") -> Dict[str, Any]:
    """Verify the license against the license server.

    Must be called at the start of every template pull, before any file
    operations.  Exits the CLI with a user-friendly message on any failure.

    Args:
        required_tier: Minimum tier required — reserved for future per-tier
            enforcement; the current gate is authenticated membership.

    Returns:
        User/membership dict returned by the server on success.

    Raises:
        typer.Exit(1): on any failure (missing token, invalid/expired token,
            timeout, or server error).
    """
    from foundry.utils import is_internal_dev

    # Internal development shortcut — mirrors check_tier_access behaviour.
    if is_internal_dev():
        return {"tier": "internal", "authorized": True}

    token = _get_token()

    if not token:
        console.print(
            "[red]✗ No license token found.[/red]\n"
            "  Run [bold]sscli auth login[/bold] to authenticate, "
            "or set [bold]SSCLI_TOKEN[/bold] env var."
        )
        raise typer.Exit(1)

    validate_url = f"{API_BASE_URL}/v1/auth/validate"

    try:
        response = requests.get(
            validate_url,
            headers={"Authorization": f"Bearer {token}"},
            timeout=10.0,
            verify=True,
            allow_redirects=False,
        )
    except requests.exceptions.Timeout:
        console.print(
            "[red]✗ License server timeout.[/red]\n"
            "  Check your internet connection or try again later."
        )
        raise typer.Exit(1)
    except requests.exceptions.ConnectionError as exc:
        console.print(f"[red]✗ Cannot reach license server: {exc}[/red]")
        raise typer.Exit(1)
    except requests.exceptions.RequestException as exc:
        console.print(f"[red]✗ License check failed: {exc}[/red]")
        raise typer.Exit(1)

    if response.status_code == 401:
        console.print(
            "[red]✗ License token is invalid or expired.[/red]\n"
            "  Run [bold]sscli auth login[/bold] to re-authenticate."
        )
        raise typer.Exit(1)

    if response.status_code == 403:
        console.print(
            "[red]✗ Access denied.[/red]\n"
            "  Your account does not have access to this template.\n"
            "  Visit [link=https://account.seedsource.dev]account.seedsource.dev[/link] to upgrade."
        )
        raise typer.Exit(1)

    if not response.ok:
        console.print(
            f"[red]✗ License check failed (HTTP {response.status_code}).[/red]\n"
            "  Visit [link=https://account.seedsource.dev]account.seedsource.dev[/link] or try again later."
        )
        raise typer.Exit(1)

    try:
        return response.json()
    except ValueError:
        console.print("[red]✗ Invalid response from license server.[/red]")
        raise typer.Exit(1)
