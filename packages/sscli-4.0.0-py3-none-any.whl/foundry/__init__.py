try:
    from importlib.metadata import version as _pkg_version

    __version__ = _pkg_version("sscli")
except Exception:
    __version__ = "unknown"
