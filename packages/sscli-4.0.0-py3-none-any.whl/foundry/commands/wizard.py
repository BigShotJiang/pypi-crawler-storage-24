"""SSA: sscli setup — interactive first-run wizard."""
from __future__ import annotations

import os

import typer

app = typer.Typer(help="Interactive first-run setup wizard.")

TEMPLATES = {
    "1": ("python-saas", "Python FastAPI SaaS (hexagonal architecture)"),
    "2": ("rails-api", "Ruby on Rails API (convention over config)"),
    "3": ("react-client", "React + Vite frontend client"),
    "4": ("static-landing", "Astro static landing page"),
}


@app.callback(invoke_without_command=True)
def setup() -> None:
    """Interactive first-run setup wizard for Seed & Source."""
    typer.echo("\n🌱 Welcome to Seed & Source — Click-to-Ship SaaS Templates\n")

    # Check for token
    token = os.environ.get("SSCLI_TOKEN", "")
    if not token:
        typer.echo("❌ No SSCLI_TOKEN found in environment.")
        typer.echo("   Please run: sscli login")
        typer.echo("   Then re-run: sscli setup\n")
        raise typer.Exit(code=1)

    typer.echo(f"✅ Token found (ends: ...{token[-4:]})\n")

    # Choose template
    typer.echo("Which template would you like to clone?\n")
    for key, (slug, desc) in TEMPLATES.items():
        typer.echo(f"  [{key}] {slug} — {desc}")

    choice = typer.prompt("\nEnter number", default="1")
    if choice not in TEMPLATES:
        typer.echo(f"❌ Invalid choice: {choice}")
        raise typer.Exit(code=1)

    template_slug, template_desc = TEMPLATES[choice]
    typer.echo(f"\n✅ Selected: {template_desc}")

    # Project name
    project_name = typer.prompt(
        "Project name (kebab-case)",
        default=f"my-{template_slug}-app",
    )
    project_name = project_name.lower().replace(" ", "-").replace("_", "-")

    # Confirm
    typer.echo(f"\nAbout to clone '{template_slug}' → ./{project_name}/")
    confirmed = typer.confirm("Proceed?", default=True)
    if not confirmed:
        typer.echo("Cancelled.")
        raise typer.Exit(code=0)

    # Clone
    typer.echo(f"\n⏳ Cloning {template_slug}...")
    try:
        from foundry.commands.clone import clone_template  # type: ignore[import]
        clone_template(template=template_slug, destination=project_name)
    except ImportError:
        # Fallback: print sscli clone command
        typer.echo(f"   Run: sscli clone {template_slug} {project_name}")

    typer.echo(f"\n✅ Your project is ready!")
    typer.echo(f"   cd {project_name}")
    typer.echo("   docker compose up\n")
    typer.echo("📚 Docs: https://docs.seedsource.dev")
