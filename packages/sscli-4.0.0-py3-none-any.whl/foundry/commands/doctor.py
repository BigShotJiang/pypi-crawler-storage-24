"""SSA: sscli doctor — comprehensive project health check."""
from __future__ import annotations

import json
import subprocess
import sys
from typing import Optional
import urllib.request
import urllib.error

import typer

app = typer.Typer(help="Run comprehensive health checks on your sscli environment.")

# Result constants
PASS = "✅ PASS"
WARN = "⚠️  WARN"
FAIL = "❌ FAIL"


def _check_token() -> tuple[str, str]:
    import os
    token = os.environ.get("SSCLI_TOKEN", "")
    if token and len(token) > 8:
        return PASS, "SSCLI_TOKEN is set"
    return FAIL, "SSCLI_TOKEN not set — run: sscli login"


def _check_python() -> tuple[str, str]:
    version = sys.version_info
    if version >= (3, 11):
        return PASS, f"Python {version.major}.{version.minor}.{version.micro}"
    return FAIL, f"Python {version.major}.{version.minor} detected — requires ≥3.11"


def _check_git() -> tuple[str, str]:
    try:
        result = subprocess.run(["git", "--version"], capture_output=True, text=True, timeout=5)
        if result.returncode == 0:
            return PASS, result.stdout.strip()
        return FAIL, "git not found in PATH"
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return FAIL, "git not found in PATH"


def _check_docker() -> tuple[str, str]:
    try:
        result = subprocess.run(["docker", "info"], capture_output=True, text=True, timeout=10)
        if result.returncode == 0:
            return PASS, "Docker daemon is running"
        return WARN, "Docker installed but daemon not running"
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return WARN, "Docker not found — container-first dev requires Docker"


def _check_license_server() -> tuple[str, str]:
    import os
    url = os.environ.get("SSCLI_LICENSE_URL", "https://auth.seedsource.dev")
    health_url = url.rstrip("/") + "/health"
    try:
        req = urllib.request.Request(health_url, method="GET")  # noqa: S310
        with urllib.request.urlopen(req, timeout=5) as resp:  # noqa: S310
            if resp.status == 200:
                return PASS, f"License server reachable at {url}"
            return WARN, f"License server responded {resp.status}"
    except urllib.error.URLError as exc:
        return WARN, f"License server unreachable ({exc}) — check network or SSCLI_LICENSE_URL"
    except Exception as exc:  # noqa: BLE001
        return WARN, f"License server check failed: {exc}"


def _check_compliance(path: str = ".") -> tuple[str, str]:
    """Quick compliance check for current project directory."""
    from pathlib import Path
    project = Path(path)
    issues = []
    if not (project / "Dockerfile").exists():
        issues.append("Dockerfile missing")
    if not (project / ".gitignore").exists():
        issues.append(".gitignore missing")
    if issues:
        return WARN, f"Compliance gaps: {', '.join(issues)}"
    return PASS, "Project structure looks compliant"


def _run_checks(path: str = ".", output_json: bool = False) -> list[dict]:
    checks = [
        ("SSCLI Token", _check_token),
        ("Python Version", _check_python),
        ("Git", _check_git),
        ("Docker", _check_docker),
        ("License Server", _check_license_server),
        ("Project Compliance", lambda: _check_compliance(path)),
    ]

    results = []
    for name, fn in checks:
        status, message = fn()
        results.append({"check": name, "status": status, "message": message})

    return results


@app.callback(invoke_without_command=True)
def doctor(
    path: str = typer.Option(".", "--path", help="Project path for compliance check"),
    fix: bool = typer.Option(False, "--fix", help="Print fix instructions for failures"),
    output_json: bool = typer.Option(False, "--json", help="Output results as JSON"),
) -> None:
    """Run all health checks and report status."""
    results = _run_checks(path)

    if output_json:
        typer.echo(json.dumps(results, indent=2))
        failed = any(FAIL in r["status"] for r in results)
        raise typer.Exit(code=1 if failed else 0)

    typer.echo("\n🩺  sscli doctor — Health Report\n" + "=" * 40)
    failed_items = []
    for r in results:
        typer.echo(f"  {r['status']}  {r['check']}: {r['message']}")
        if FAIL in r["status"]:
            failed_items.append(r)

    typer.echo("=" * 40)

    if failed_items:
        typer.echo(f"\n⚠️  {len(failed_items)} check(s) failed.")
        if fix:
            typer.echo("\n📋 Fix instructions:")
            for r in failed_items:
                typer.echo(f"\n  [{r['check']}]")
                if "SSCLI_TOKEN" in r["message"]:
                    typer.echo("    Run: sscli login")
                elif "Python" in r["check"]:
                    typer.echo("    Install Python 3.11+: https://python.org/downloads")
                elif "git" in r["check"].lower():
                    typer.echo("    Install git: https://git-scm.com/downloads")
                elif "Docker" in r["check"]:
                    typer.echo("    Install Docker Desktop: https://docs.docker.com/get-docker/")
        raise typer.Exit(code=1)
    else:
        typer.echo("\n✅ All checks passed!")
