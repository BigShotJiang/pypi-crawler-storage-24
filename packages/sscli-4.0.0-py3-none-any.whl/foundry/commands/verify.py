"""
Cross-platform environment preflight checks — SSA-14.

Pure Python replacement for any PowerShell verification scripts.
Checks that all prerequisites are satisfied before using sscli.
"""
from __future__ import annotations

import os
import shutil
import socket
import subprocess
import sys
from dataclasses import dataclass
from typing import Optional

from rich.console import Console

console = Console()

PASS = "PASS"
FAIL = "FAIL"


@dataclass
class CheckResult:
    name: str
    status: str  # "PASS" | "FAIL"
    reason: str
    fix: Optional[str] = None


def check_token() -> CheckResult:
    """Verify SSCLI_TOKEN environment variable is set and non-empty."""
    token = os.environ.get("SSCLI_TOKEN", "").strip()
    if token:
        return CheckResult("SSCLI_TOKEN", PASS, "Token is set")
    return CheckResult(
        "SSCLI_TOKEN",
        FAIL,
        "SSCLI_TOKEN environment variable is not set or empty",
        fix="Run 'sscli login' or set SSCLI_TOKEN=<your-token> in your shell profile.",
    )


def check_python_version() -> CheckResult:
    """Verify that the running Python interpreter is >= 3.11."""
    major, minor, micro = sys.version_info[:3]
    version_str = f"{major}.{minor}.{micro}"
    if (major, minor) >= (3, 11):
        return CheckResult("python_version", PASS, f"Python {version_str}")
    return CheckResult(
        "python_version",
        FAIL,
        f"Python {version_str} — requires ≥ 3.11",
        fix="Install Python 3.11 or later from https://python.org/downloads",
    )


def check_git() -> CheckResult:
    """Verify that git is available on PATH."""
    if shutil.which("git"):
        return CheckResult("git", PASS, "git found in PATH")
    return CheckResult(
        "git",
        FAIL,
        "git not found in PATH",
        fix="Install git from https://git-scm.com/downloads",
    )


def check_docker() -> CheckResult:
    """Verify that Docker is installed and the daemon is running."""
    if not shutil.which("docker"):
        return CheckResult(
            "docker",
            FAIL,
            "docker not found in PATH",
            fix="Install Docker Desktop from https://docs.docker.com/get-docker/",
        )
    result = subprocess.run(
        ["docker", "info"],
        capture_output=True,
        timeout=10,
        check=False,
    )
    if result.returncode == 0:
        return CheckResult("docker", PASS, "Docker is installed and running")
    return CheckResult(
        "docker",
        FAIL,
        "Docker is installed but not running (docker info returned non-zero)",
        fix="Start Docker Desktop or run 'sudo systemctl start docker' on Linux.",
    )


def check_connectivity(host: str, port: int = 443, label: str = "") -> CheckResult:
    """Check TCP connectivity to a host:port (no network import at module load)."""
    name = label or host
    try:
        sock = socket.create_connection((host, port), timeout=5)
        sock.close()
        return CheckResult(name, PASS, f"Connected to {host}:{port}")
    except OSError as exc:
        return CheckResult(
            name,
            FAIL,
            f"Cannot reach {host}:{port} — {exc}",
            fix=f"Check your internet connection or firewall rules for {host}.",
        )


def run_env_checks() -> dict[str, CheckResult]:
    """Run all cross-platform environment checks and return a result dict."""
    checks: list[CheckResult] = [
        check_token(),
        check_python_version(),
        check_git(),
        check_docker(),
        check_connectivity("api.github.com", label="github_connectivity"),
        check_connectivity("pypi.org", label="pypi_connectivity"),
    ]
    return {c.name: c for c in checks}


def print_results(results: dict[str, CheckResult], fix: bool = False) -> None:
    """Render check results to the console, optionally printing fix hints."""
    passed = sum(1 for r in results.values() if r.status == PASS)
    total = len(results)

    for r in results.values():
        if r.status == PASS:
            console.print(f"[green]✓ PASS[/green]  {r.name}: {r.reason}")
        else:
            console.print(f"[red]✗ FAIL[/red]  {r.name}: {r.reason}")
            if fix and r.fix:
                console.print(f"  [yellow]→ Fix:[/yellow] {r.fix}")

    console.print()
    color = "green" if passed == total else "red"
    console.print(f"[{color}]{passed}/{total} checks passed[/{color}]")
