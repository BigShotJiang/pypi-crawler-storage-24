"""
AI Infrastructure Advisor — rule-based project health checker.
Analyzes project structure and emits recommendations.
"""
from __future__ import annotations

from pathlib import Path
from typing import NamedTuple

from rich.console import Console
from rich.table import Table

console = Console()

SEVERITY = {"critical": "🔴", "warning": "🟡", "info": "🟢"}


class Finding(NamedTuple):
    severity: str        # critical | warning | info
    category: str        # security | docker | ci | deps
    title: str
    recommendation: str


def check_dockerfile(project_root: Path) -> list[Finding]:
    findings = []
    df = project_root / "Dockerfile"
    if not df.exists():
        findings.append(Finding(
            "critical", "docker", "No Dockerfile found",
            "Add a Dockerfile. All services must be containerized.",
        ))
        return findings
    content = df.read_text()
    if "HEALTHCHECK" not in content:
        findings.append(Finding(
            "warning", "docker", "No HEALTHCHECK in Dockerfile",
            "Add HEALTHCHECK instruction for production readiness.",
        ))
    if "USER " not in content:
        findings.append(Finding(
            "warning", "security", "Running as root in container",
            "Add 'USER appuser' to run as non-root.",
        ))
    if ":latest" in content:
        findings.append(Finding(
            "warning", "docker", "Using :latest tag",
            "Pin base images to exact versions (e.g. python:3.12.3-slim).",
        ))
    return findings


def check_env_files(project_root: Path) -> list[Finding]:
    findings = []
    env = project_root / ".env"
    env_example = project_root / ".env.example"
    if env.exists() and not env_example.exists():
        findings.append(Finding(
            "warning", "security", ".env without .env.example",
            "Add .env.example to document required env vars.",
        ))
    gitignore = project_root / ".gitignore"
    if gitignore.exists() and env.exists():
        if ".env" not in gitignore.read_text():
            findings.append(Finding(
                "critical", "security", ".env not in .gitignore",
                "Add '.env' to .gitignore immediately to prevent secret exposure.",
            ))
    return findings


def check_docker_compose(project_root: Path) -> list[Finding]:
    findings = []
    dc = project_root / "docker-compose.yml"
    if not dc.exists():
        findings.append(Finding(
            "info", "docker", "No docker-compose.yml",
            "Consider adding docker-compose.yml for local development.",
        ))
        return findings
    content = dc.read_text()
    if "healthcheck:" not in content:
        findings.append(Finding(
            "warning", "docker", "No healthcheck in compose",
            "Add healthcheck: to each service for better orchestration.",
        ))
    return findings


def check_ci(project_root: Path) -> list[Finding]:
    findings = []
    github_ci = project_root / ".github" / "workflows"
    if not github_ci.exists():
        findings.append(Finding(
            "warning", "ci", "No GitHub Actions CI found",
            "Add .github/workflows/ci.yml for automated testing.",
        ))
    return findings


CHECKERS = [check_dockerfile, check_env_files, check_docker_compose, check_ci]


def analyze_project(project_root: Path) -> list[Finding]:
    all_findings: list[Finding] = []
    for checker in CHECKERS:
        all_findings.extend(checker(project_root))
    return all_findings


def render_findings(findings: list[Finding]) -> None:
    if not findings:
        console.print("\n  [green]✓ No issues found! Your project looks great.[/green]\n")
        return

    table = Table(show_header=True, header_style="bold")
    table.add_column("Sev", width=4)
    table.add_column("Category", width=10)
    table.add_column("Issue")
    table.add_column("Recommendation")

    severity_order = ["critical", "warning", "info"]
    for f in sorted(findings, key=lambda x: severity_order.index(x.severity)):
        icon = SEVERITY.get(f.severity, "?")
        table.add_row(icon, f.category, f.title, f.recommendation)

    console.print(f"\n  Found {len(findings)} issue(s):\n")
    console.print(table)
    console.print()
