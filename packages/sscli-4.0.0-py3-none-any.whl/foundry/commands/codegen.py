"""SSA-16: sscli generate — Jinja2-based code generator."""
from __future__ import annotations

import re
import secrets
from pathlib import Path
from typing import Optional

import typer

app = typer.Typer(help="Generate boilerplate files from templates.")

TEMPLATE_DIR = Path(__file__).parent.parent / "codegen_templates"


def _render_template(template_name: str, context: dict) -> str:
    """Render a Jinja2 template from the codegen_templates directory."""
    try:
        from jinja2 import Environment, FileSystemLoader, select_autoescape
    except ImportError:
        typer.echo("❌ Jinja2 is required. Install it: pip install jinja2", err=True)
        raise typer.Exit(code=1)

    env = Environment(
        loader=FileSystemLoader(str(TEMPLATE_DIR)),
        autoescape=False,
    )
    template = env.get_template(template_name)
    return template.render(**context)


def _write_file(path: Path, content: str, dry_run: bool) -> None:
    if dry_run:
        typer.echo(f"[dry-run] Would write: {path}")
        typer.echo("---")
        typer.echo(content[:500] + ("..." if len(content) > 500 else ""))
        typer.echo("---")
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)
    typer.echo(f"✅ Generated: {path}")


@app.command("endpoint")
def generate_endpoint(
    resource: str = typer.Argument(..., help="Resource name (e.g. 'user', 'order')"),
    template: str = typer.Option("python-saas", help="Template type: python-saas"),
    methods: str = typer.Option("index,show,create", help="Comma-separated CRUD methods"),
    output_dir: str = typer.Option(".", help="Output directory"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview without writing"),
) -> None:
    """Generate a REST endpoint scaffold."""
    resource = resource.lower().replace("-", "_")
    method_list = [m.strip() for m in methods.split(",")]

    if template == "python-saas":
        content = _render_template(
            "python_endpoint.j2",
            {"resource_name": resource, "methods": method_list},
        )
        out_path = Path(output_dir) / "src" / "routes" / f"{resource}s_router.py"
    else:
        typer.echo(f"❌ Unknown template: {template}. Supported: python-saas", err=True)
        raise typer.Exit(code=1)

    _write_file(out_path, content, dry_run)


@app.command("component")
def generate_component(
    name: str = typer.Argument(..., help="Component name (PascalCase, e.g. 'UserCard')"),
    template: str = typer.Option("react-client", help="Template type: react-client"),
    output_dir: str = typer.Option("src/components", help="Output directory"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview without writing"),
) -> None:
    """Generate a React component scaffold."""
    if template == "react-client":
        content = _render_template("react_component.j2", {"component_name": name})
        out_path = Path(output_dir) / f"{name}.tsx"
    else:
        typer.echo(f"❌ Unknown template: {template}. Supported: react-client", err=True)
        raise typer.Exit(code=1)

    _write_file(out_path, content, dry_run)


@app.command("use-case")
def generate_use_case(
    name: str = typer.Argument(..., help="Use case name (snake_case, e.g. 'create_order')"),
    template: str = typer.Option("python-saas", help="Template type: python-saas"),
    output_dir: str = typer.Option("src/domain/use_cases", help="Output directory"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview without writing"),
) -> None:
    """Generate a hexagonal use case scaffold."""
    name = name.lower().replace("-", "_")

    if template == "python-saas":
        content = _render_template("python_use_case.j2", {"use_case_name": name})
        out_path = Path(output_dir) / f"{name}_use_case.py"
    else:
        typer.echo(f"❌ Unknown template: {template}. Supported: python-saas", err=True)
        raise typer.Exit(code=1)

    _write_file(out_path, content, dry_run)


@app.command("migration")
def generate_migration(
    name: str = typer.Argument(..., help="Migration name (snake_case, e.g. 'create_orders')"),
    template: str = typer.Option("python-saas", help="Template type: python-saas or rails-api"),
    action: str = typer.Option("create_table", help="Action: create_table, add_column"),
    table: Optional[str] = typer.Option(None, "--table", help="Table name (inferred from name if omitted)"),
    output_dir: str = typer.Option(".", help="Output directory (migrations/ for python, db/migrate/ for rails)"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview without writing"),
) -> None:
    """Generate a database migration scaffold."""
    name = name.lower().replace("-", "_")
    # Infer table from name if not provided (e.g. create_orders -> orders)
    table_name = table or re.sub(r"^(create|add_to|remove_from)_", "", name)

    if template == "python-saas":
        revision_id = secrets.token_hex(6)
        content = _render_template(
            "python_migration.j2",
            {"migration_name": name, "revision_id": revision_id, "action": action, "table_name": table_name},
        )
        out_path = Path(output_dir) / "migrations" / f"{revision_id}_{name}.py"
    elif template == "rails-api":
        import datetime
        timestamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
        # Convert snake_case to CamelCase for class name
        migration_class = "".join(w.title() for w in name.split("_"))
        content = _render_template(
            "rails_migration.j2",
            {"migration_class": migration_class, "action": action, "table_name": table_name, "column_name": "new_column", "column_type": "string"},
        )
        out_path = Path(output_dir) / "db" / "migrate" / f"{timestamp}_{name}.rb"
    else:
        typer.echo(f"❌ Unknown template: {template}. Supported: python-saas, rails-api", err=True)
        raise typer.Exit(code=1)

    _write_file(out_path, content, dry_run)


@app.command("spec")
def generate_spec(
    resource: str = typer.Argument(..., help="Resource name (e.g. 'order')"),
    template: str = typer.Option("rails-api", help="Template type: rails-api"),
    spec_type: str = typer.Option("request", help="Spec type: request"),
    output_dir: str = typer.Option("spec", help="Output directory"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview without writing"),
) -> None:
    """Generate an RSpec test scaffold."""
    resource = resource.lower().replace("-", "_")

    if template == "rails-api" and spec_type == "request":
        content = _render_template("rspec_request.j2", {"resource_name": resource})
        out_path = Path(output_dir) / "requests" / f"{resource}s_spec.rb"
    else:
        typer.echo(f"❌ Unsupported combination: {template}/{spec_type}", err=True)
        raise typer.Exit(code=1)

    _write_file(out_path, content, dry_run)
