from pathlib import Path
from typing import Optional

import typer
from rich.panel import Panel

from foundry.actions.internals import generate_internals_report
from foundry.constants import console


internals_app = typer.Typer(help="Internal-projects execution and failure annotation tools")


@internals_app.command("annotate")
def annotate(
    workspace_root: Path = typer.Option(
        Path("."),
        "--workspace-root",
        help="Repository/workspace root that contains internal-projects/",
    ),
    session_log: Optional[Path] = typer.Option(
        None,
        "--session-log",
        help="Explicit session log path (defaults to internal-projects/.session.log)",
    ),
    output_dir: Optional[Path] = typer.Option(
        None,
        "--output-dir",
        help="Directory for generated JSON/Markdown reports",
    ),
    strict: bool = typer.Option(
        False,
        "--strict",
        help="Exit with code 1 when failure events are present",
    ),
):
    """Generate structured failure annotations from internal-projects execution logs."""

    workspace_root = _normalize_path(workspace_root, default=Path(".")).resolve()
    session_log = _normalize_optional_path(session_log)
    output_dir = _normalize_optional_path(output_dir)
    if session_log is not None:
        resolved_log = _resolve_within_root(session_log, workspace_root, "--session-log")
        if not resolved_log.exists():
            raise typer.BadParameter(
                f"Session log not found: {resolved_log}",
                param_hint="--session-log",
            )
    else:
        resolved_log = _resolve_session_log(workspace_root, None)

    resolved_output_dir = (
        _resolve_within_root(output_dir, workspace_root, "--output-dir")
        if output_dir
        else (workspace_root / "internal-projects" / "reports" / "internals")
    )

    result = generate_internals_report(resolved_log, resolved_output_dir)
    report = result["report"]
    summary = report["summary"]
    json_path = result["json_path"]
    markdown_path = result["markdown_path"]

    console.print(
        Panel(
            "\n".join(
                [
                    "[bold green]Internal-projects annotation report generated[/bold green]",
                    f"Events: [bold]{summary.get('total_events', 0)}[/bold]",
                    f"Failures: [bold]{summary.get('failure_events', 0)}[/bold]",
                    f"JSON: {json_path}",
                    f"Markdown: {markdown_path}",
                ]
            ),
            title="sscli internals annotate",
            border_style="green",
        )
    )

    if strict and summary.get("failure_events", 0) > 0:
        raise typer.Exit(code=1)


def _resolve_session_log(workspace_root: Path, explicit_log: Optional[Path]) -> Path:
    if explicit_log is not None:
        candidate = _resolve_within_root(explicit_log, workspace_root, "--session-log")
        if not candidate.exists():
            console.print(f"[bold red]✗ Session log not found:[/bold red] {candidate}")
            raise typer.Exit(code=1)
        return candidate

    default_candidates = [
        workspace_root / "internal-projects" / ".session.log",
        workspace_root / ".session.log",
    ]
    for candidate in default_candidates:
        if candidate.exists():
            return candidate

    console.print("[bold red]✗ Could not locate a session log.[/bold red]")
    console.print(
        "Checked: "
        + ", ".join(str(path) for path in default_candidates)
    )
    console.print("Provide one explicitly with [cyan]--session-log[/cyan].")
    raise typer.Exit(code=1)


def _resolve_within_root(path_value: Path, workspace_root: Path, option_name: str) -> Path:
    resolved = path_value.resolve()
    root = workspace_root.resolve()
    if not resolved.is_relative_to(root):
        raise typer.BadParameter(
            f"Path must be within workspace root {root}: {resolved}",
            param_hint=option_name,
        )
    return resolved


def _normalize_optional_path(value: Optional[Path]) -> Optional[Path]:
    if value is None or isinstance(value, Path):
        return value
    if hasattr(value, "default"):
        default_value = getattr(value, "default")
        if default_value in (None, ...):
            return None
        if isinstance(default_value, Path):
            return default_value
        return Path(default_value)
    return Path(value)


def _normalize_path(value: Optional[Path], default: Path) -> Path:
    normalized = _normalize_optional_path(value)
    return normalized if normalized is not None else default


__all__ = ["internals_app"]
