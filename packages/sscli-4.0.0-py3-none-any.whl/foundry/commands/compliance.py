"""
Stack compliance checker — SSA-17.

Validates that a project directory meets Seed & Source architectural requirements:
Dockerfile, docker-compose.yml, README, no live secrets, no hardcoded localhost,
license presence, and .gitignore covering .env files.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from rich.console import Console

console = Console()

Status = Literal["PASS", "FAIL", "WARN"]

_SECRET_PATTERNS = re.compile(
    r"(sk_live_[A-Za-z0-9]+|ghp_[A-Za-z0-9]+|AKIA[0-9A-Z]{16}|sk-[A-Za-z0-9]{20,})"
)
_LOCALHOST_PATTERN = re.compile(r"http://localhost")
_SOURCE_SUFFIXES = {".py", ".rb", ".js", ".ts", ".jsx", ".tsx", ".go"}
_TEST_DIR_NAMES = {"tests", "test", "spec", "__tests__"}


@dataclass
class ComplianceResult:
    name: str
    status: Status
    reason: str


def _check_dockerfile(root: Path) -> ComplianceResult:
    if (root / "Dockerfile").exists():
        return ComplianceResult("dockerfile", "PASS", "Dockerfile found at root")
    sub = list(root.rglob("Dockerfile"))
    if sub:
        return ComplianceResult(
            "dockerfile", "PASS", f"Dockerfile found at {sub[0].relative_to(root)}"
        )
    return ComplianceResult(
        "dockerfile", "FAIL", "No Dockerfile found — all services must be containerized"
    )


def _check_compose(root: Path) -> ComplianceResult:
    if (root / "docker-compose.yml").exists():
        return ComplianceResult("docker_compose", "PASS", "docker-compose.yml found at root")
    return ComplianceResult(
        "docker_compose", "FAIL", "docker-compose.yml missing at root"
    )


def _check_readme(root: Path) -> ComplianceResult:
    if (root / "README.md").exists():
        return ComplianceResult("readme", "PASS", "README.md found at root")
    return ComplianceResult("readme", "FAIL", "README.md missing at root")


def _check_no_secrets(root: Path) -> ComplianceResult:
    hits: list[str] = []
    for env_file in root.rglob(".env"):
        try:
            text = env_file.read_text(errors="replace")
        except OSError:
            continue
        for line in text.splitlines():
            if _SECRET_PATTERNS.search(line):
                hits.append(str(env_file.relative_to(root)))
                break
    if hits:
        return ComplianceResult(
            "no_secrets",
            "WARN",
            f"Possible live secrets found in: {', '.join(hits)}",
        )
    return ComplianceResult(
        "no_secrets", "PASS", "No known secret patterns detected in .env files"
    )


def _check_no_hardcoded_localhost(root: Path) -> ComplianceResult:
    search_dirs = [root / "src", root / "app"]
    hits: list[str] = []
    for search_dir in search_dirs:
        if not search_dir.is_dir():
            continue
        for f in search_dir.rglob("*"):
            if not f.is_file():
                continue
            if any(part in _TEST_DIR_NAMES for part in f.parts):
                continue
            if f.suffix not in _SOURCE_SUFFIXES:
                continue
            try:
                text = f.read_text(errors="replace")
            except OSError:
                continue
            if _LOCALHOST_PATTERN.search(text):
                hits.append(str(f.relative_to(root)))
    if hits:
        sample = hits[:3]
        suffix = "..." if len(hits) > 3 else ""
        return ComplianceResult(
            "no_hardcoded_localhost",
            "WARN",
            f"http://localhost in non-test source files: {', '.join(sample)}{suffix}",
        )
    return ComplianceResult(
        "no_hardcoded_localhost",
        "PASS",
        "No hardcoded localhost URLs in source files",
    )


def _check_license(root: Path) -> ComplianceResult:
    if (root / "LICENSE").exists() or (root / "LICENSE.md").exists():
        return ComplianceResult("license", "PASS", "LICENSE file found at root")
    for suffix in (".py", ".rb", ".js"):
        for src in list(root.rglob(f"*{suffix}"))[:20]:
            try:
                header = src.read_text(errors="replace")[:500].lower()
            except OSError:
                continue
            if "license" in header or "copyright" in header or "spdx" in header:
                return ComplianceResult(
                    "license",
                    "PASS",
                    f"License header found in {src.relative_to(root)}",
                )
    return ComplianceResult(
        "license",
        "WARN",
        "No LICENSE file or license header found in source files",
    )


def _check_gitignore_env(root: Path) -> ComplianceResult:
    gitignore = root / ".gitignore"
    if not gitignore.exists():
        return ComplianceResult(
            "gitignore_env",
            "WARN",
            ".gitignore not found — .env files may be committed accidentally",
        )
    text = gitignore.read_text(errors="replace")
    if ".env" in text:
        return ComplianceResult("gitignore_env", "PASS", ".gitignore contains .env entry")
    return ComplianceResult(
        "gitignore_env",
        "WARN",
        ".gitignore does not contain .env — secrets may be exposed if committed",
    )


def run_compliance_checks(path: Path) -> dict[str, ComplianceResult]:
    """Run all compliance checks against a target project directory."""
    checks = [
        _check_dockerfile(path),
        _check_compose(path),
        _check_readme(path),
        _check_no_secrets(path),
        _check_no_hardcoded_localhost(path),
        _check_license(path),
        _check_gitignore_env(path),
    ]
    return {c.name: c for c in checks}


def print_compliance_results(results: dict[str, ComplianceResult]) -> None:
    """Render compliance results with colored PASS/WARN/FAIL indicators."""
    passed = 0
    warned = 0
    failed = 0
    for r in results.values():
        if r.status == "PASS":
            console.print(f"[green]✓ PASS[/green]  {r.name}: {r.reason}")
            passed += 1
        elif r.status == "WARN":
            console.print(f"[yellow]⚠ WARN[/yellow]  {r.name}: {r.reason}")
            warned += 1
        else:
            console.print(f"[red]✗ FAIL[/red]  {r.name}: {r.reason}")
            failed += 1

    console.print()
    color = "green" if failed == 0 else "red"
    console.print(f"[{color}]{passed} passed, {warned} warned, {failed} failed[/{color}]")
