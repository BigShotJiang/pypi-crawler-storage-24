"""
Error reporting command for sscli.

Allows users to easily submit error logs and system info to help us improve.
- Reads from ~/.sscli/session.log
- Redacts sensitive information (API keys, tokens, passwords)
- Shows preview before sending
- Asks for optional email for follow-up
"""

import typer
import json
from pathlib import Path
from datetime import datetime
from typing import Optional
from unittest.mock import patch

from foundry.constants import console
from foundry.telemetry import log_event
from rich.prompt import Prompt, Confirm
from rich.panel import Panel
from rich.table import Table
from rich.markdown import Markdown
import re

report_app = typer.Typer(help="Report errors and submit system diagnostics.")

# Regex for detecting sensitive information
_SECRET_RE = re.compile(
    r"(?i)(api[_-]?key|secret|token|password|passwd|authorization|bearer)\s*[:=]\s*[^\s,;\n]+"
)


def _redact_text(value: str) -> str:
    """Redact sensitive information from text."""
    if not value:
        return value
    return _SECRET_RE.sub("REDACTED", value)


def _get_log_file_path() -> Path:
    """Get the path to the session log file."""
    import os

    log_dir_env = os.environ.get("SSCLI_LOG_DIR")
    if log_dir_env:
        log_dir = Path(log_dir_env)
    else:
        log_dir = Path.home() / ".sscli"

    return log_dir / ".session.log"


def _read_last_logs(num_lines: int = 100) -> list[str]:
    """Read the last N lines from the session log file."""
    log_file = _get_log_file_path()

    if not log_file.exists():
        return ["(No session log found — this is the first CLI session)"]

    try:
        with open(log_file, "r", encoding="utf-8") as f:
            lines = f.readlines()
            # Get the last num_lines, without empty lines
            lines = [line.rstrip("\n") for line in lines if line.strip()]
            return lines[-num_lines:] if lines else ["(Empty log file)"]
    except Exception as e:
        return [f"(Error reading log: {e})"]


def _format_log_preview(lines: list[str]) -> str:
    """Format log lines with redaction for display."""
    redacted_lines = [_redact_text(line) for line in lines]
    return "\n".join(redacted_lines)


def _validate_email(email: str) -> bool:
    """Basic email validation."""
    if not email:
        return True  # optional field
    email_pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
    return bool(re.match(email_pattern, email))


def _save_report_locally(report_data: dict) -> Path:
    """Save report to local file for offline collection."""
    report_dir = Path.home() / ".sscli" / "reports"
    report_dir.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    report_file = report_dir / f"report_{timestamp}.json"

    with open(report_file, "w", encoding="utf-8") as f:
        json.dump(report_data, f, indent=2)

    return report_file


def _submit_report(report_data: dict) -> dict:
    """Submit report to backend endpoint (mocked for now)."""
    # In production, this would POST to a real endpoint
    # For WAVE 1, we just save locally and return success metadata
    report_file = _save_report_locally(report_data)

    return {
        "status": "success",
        "message": f"Report saved locally to {report_file}",
        "file": str(report_file),
    }


@report_app.callback(invoke_without_command=True)
def report_main(ctx: typer.Context):
    """Report errors and system diagnostics to help improve Seed & Source."""
    if ctx.invoked_subcommand is None:
        display_report_instructions()


@report_app.command("submit")
def submit_report(
    email: Optional[str] = typer.Option(
        None, "--email", "-e", help="Your email for follow-up (optional)"
    ),
    include_logs: bool = typer.Option(
        True, "--include-logs/--no-logs", help="Include last 100 log lines (default: yes)"
    ),
    include_system: bool = typer.Option(
        True, "--include-system/--no-system", help="Include system info (default: yes)"
    ),
):
    """Submit an error report with system diagnostics."""
    import platform
    import sys

    # Read logs
    log_lines = _read_last_logs(100) if include_logs else []

    # Prepare report
    report_data = {
        "type": "error_report",
        "timestamp": datetime.utcnow().isoformat(),
        "email": email if _validate_email(email) else None,
    }

    if include_logs:
        report_data["logs"] = log_lines

    if include_system:
        report_data["system"] = {
            "os": platform.system(),
            "python_version": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        }

    # Show preview
    console.print("\n[bold cyan]📋 Report Preview[/bold cyan]")
    console.print("[dim]" + ("=" * 60) + "[/dim]")

    preview_text = json.dumps(report_data, indent=2)
    console.print(preview_text)

    console.print("[dim]" + ("=" * 60) + "[/dim]")

    # Ask for confirmation
    if not Confirm.ask("[bold]Submit this report?[/bold]", default=True):
        console.print("[yellow]Report cancelled.[/yellow]")
        log_event("REPORT_CANCELLED", "user_declined")
        raise typer.Exit(code=0)

    # Submit
    result = _submit_report(report_data)
    console.print(f"\n[green]✓ {result['message']}[/green]")
    console.print("[cyan]Thank you for helping us improve![/cyan]")

    log_event("REPORT_SUBMITTED", f"email={email or 'none'} logs={include_logs}")


@report_app.command("view")
def view_logs(num_lines: int = typer.Option(50, "--lines", "-n", help="Number of recent log lines to display")):
    """View recent CLI session logs."""
    if num_lines < 1 or num_lines > 500:
        console.print("[red]Error: --lines must be between 1 and 500[/red]")
        raise typer.Exit(code=1)

    log_lines = _read_last_logs(num_lines)
    formatted = _format_log_preview(log_lines)

    console.print("\n[bold cyan]📊 Recent Session Log (last {} lines)[/bold cyan]".format(num_lines))
    console.print("[dim]" + ("=" * 60) + "[/dim]")
    console.print(formatted)
    console.print("[dim]" + ("=" * 60) + "[/dim]")

    log_event("REPORT_VIEW", f"lines={num_lines}")


def display_report_instructions():
    """Display help for the report command."""
    instructions = """
## Error Reporting

Submit error logs and diagnostics to help us improve Seed & Source.

**Submit a report** (with interactive preview):
   `sscli report submit [--email your@email.com]`

**View recent logs** (preview before submitting):
   `sscli report view --lines 50`

**Options:**
   `--include-logs`      Include last 100 CLI log lines (default: yes)
   `--include-system`    Include OS and Python version (default: yes)
   `--email`             Your email for follow-up (optional)

**What gets sent:**
- Last 100 log lines (errors, warnings, events)
- Your OS and Python version
- Your email (optional, for follow-up)

**What does NOT get sent:**
- Your project code or file contents
- Authentication tokens or API keys (automatically redacted)
- Personal information (user_id, org name)

All reports are reviewed weekly to help us identify and fix issues faster.
    """
    console.print(Markdown(instructions))
