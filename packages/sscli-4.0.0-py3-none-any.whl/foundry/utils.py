from pathlib import Path
import os
from typing import Any, Dict, List

from foundry.constants import TEMPLATE_REGISTRY, TEMPLATES_DIR, FOUNDRY_ROOT


def is_valid_template(path: Path) -> bool:
    """Check if a local directory is a valid template."""
    if not path.is_dir() or path.name.startswith("."):
        return False

    # Exclude internal monorepo directories that aren't templates
    # This prevents 'scripts', 'stack-cli', etc from showing up in the inventory
    internal_dirs = {
        "stack-cli", 
        "scripts", 
        "ops", 
        "docs", 
        "bin", 
        "alpha-packages", 
        "tmp", 
        "tracking", 
        "Users", 
        "sscli",
        "services",
        "services-core",
        ".github",
        "venv",
        "node_modules",
        "foundry"
    }
    if path.name in internal_dirs:
        return False

    # Check if it's in our registry
    if path.name in TEMPLATE_REGISTRY:
        return True

    # Check for legacy project markers (fallback)
    markers = [
        "Dockerfile",
        "package.json",
        "main.tf",
        "pyproject.toml",
        "Gemfile",
        "build.gradle.kts",
        "StackApp",
    ]

    return any((path / marker).exists() for marker in markers)


def is_internal_dev() -> bool:
    """
    Check if the CLI is running in the internal development mono-repo context.
    Requires explicit opt-in via FOUNDRY_INTERNAL_DEV=1 AND the presence of
    internal directory markers (.github, docs/, tooling/, wiring/) at FOUNDRY_ROOT.
    Any other value (including unset) returns False immediately.
    """
    # Explicit opt-in only: FOUNDRY_INTERNAL_DEV must be exactly "1".
    # No directory-marker fallthrough — env var is the sole gate.
    if os.getenv("FOUNDRY_INTERNAL_DEV") != "1":
        return False
    return True


def get_templates() -> List[Path]:
    """
    Get list of templates.
    In development mode, returns local directories.
    In PyPI mode, returns virtual paths based on registry.
    """
    # 1. Try local scanning (Development/Monorepo mode)
    if TEMPLATES_DIR.exists():
        local_templates = [d for d in TEMPLATES_DIR.iterdir() if is_valid_template(d)]
        if local_templates:
            return sorted(local_templates, key=lambda x: x.name)

    # 2. Fallback to Registry (PyPI mode)
    # We return dummy Path objects where the name corresponds to the registry key
    return [Path(name) for name in TEMPLATE_REGISTRY.keys()]


def get_template_info(template_name: str) -> Dict[str, Any]:
    """Get metadata for a specific template."""
    return TEMPLATE_REGISTRY.get(
        template_name,
        {"name": template_name, "description": "Custom Template", "tier": "free"},
    )
