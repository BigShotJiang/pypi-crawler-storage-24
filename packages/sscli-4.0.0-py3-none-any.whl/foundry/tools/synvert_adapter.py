"""
Synvert Adapter - Python bridge to Synvert Ruby AST transformations

This module provides a bridge between Python stack-cli and Synvert Ruby rewriters.
Synvert is an AST-aware code transformation tool for Ruby, providing robust
alternatives to fragile string-based code injection.

References:
- Synvert: https://synvert.net/
- Repo: https://github.com/synvert-hq/synvert-core-ruby
"""

import re
import subprocess
import tempfile
from pathlib import Path
from typing import Dict, List, Optional, Any
from foundry.constants import console

# C-15: pinned version for reproducibility — prevents supply-chain attack via RubyGems
_SYNVERT_CORE_VERSION = "1.23.0"

# C-1: allowlist regex for all values interpolated into Synvert/Ruby snippet strings
# '#' is allowed for Rails route controller notation ('controller#action');
# injection risk from '#{expr}' is prevented by blocking '{' and '}' via fullmatch.
_SAFE_SNIPPET_RE = re.compile(r'^[a-zA-Z0-9_\-./: #\t]{1,500}$')
_SYNVERT_GEM_LINE_RE = re.compile(r"\bsynvert-core\s*\(([^)]*)\)")


def _safe_synvert_input(value: str, label: str = "input") -> str:
    """Validate that a value is safe to interpolate into a Synvert Ruby snippet.

    Raises ValueError if the value contains characters outside the strict
    allowlist, preventing Ruby code injection via f-string interpolation.
    """
    if not _SAFE_SNIPPET_RE.fullmatch(str(value)):
        raise ValueError(
            f"Unsafe synvert input for {label!r}: {str(value)[:60]!r} "
            "\u2014 only alphanumeric, _, -, ., /, :, space, tab allowed"
        )
    return value


class SynvertAdapter:
    """
    Bridge between Python stack-cli and Synvert Ruby rewriters.
    
    Handles:
    - Ruby environment checking
    - Synvert gem installation verification
    - Inline rewriter execution
    - Output parsing and validation
    """
    
    def __init__(self, project_path: Path):
        """
        Initialize Synvert adapter for a Rails project.
        
        Args:
            project_path: Path to Rails project root
            
        Raises:
            RuntimeError: If Ruby 3.0+ or synvert-core gem not available
        """
        self.project_path = project_path
        self.ruby_version = self._check_ruby()
        self._verify_synvert_gem()
    
    def _check_ruby(self) -> str:
        """
        Check Ruby version and return version string.
        
        Returns:
            Ruby version string (e.g., "ruby 3.2.0")
            
        Raises:
            RuntimeError: If Ruby not installed or too old
        """
        try:
            result = subprocess.run(
                ["ruby", "-v"],
                capture_output=True,
                text=True,
                timeout=5
            )
            if result.returncode != 0:
                raise RuntimeError("Ruby not installed or not in PATH")
            
            version_str = result.stdout.strip()
            # Parse version: "ruby 3.2.0 (2022-12-25 revision abc123)"
            parts = version_str.split()
            if len(parts) >= 2:
                version_num = parts[1]
                major = int(version_num.split(".")[0])
                if major < 3:
                    raise RuntimeError(
                        f"Ruby 3.0+ required, found {version_num}"
                    )
            
            return version_str
        except FileNotFoundError:
            raise RuntimeError(
                "Ruby not found. Please install Ruby 3.0 or later."
            )
        except Exception as e:
            raise RuntimeError(f"Ruby check failed: {str(e)}")
    
    def _verify_synvert_gem(self) -> None:
        """
        Verify synvert-core gem is installed.
        
        Raises:
            RuntimeError: If gem not installed
        """
        try:
            result = subprocess.run(
                ["gem", "list", "^synvert-core$"],
                capture_output=True,
                text=True,
                timeout=5
            )

            if result.returncode != 0:
                raise RuntimeError(
                    f"Failed to query synvert-core gem: {result.stderr.strip()}"
                )

            installed_versions = self._parse_synvert_versions(result.stdout)
            if _SYNVERT_CORE_VERSION not in installed_versions:
                console.print(
                    "[yellow]Warning: synvert-core pinned version "
                    f"{_SYNVERT_CORE_VERSION} not found. Installing...[/yellow]"
                )
                # Try to install it — pinned version to prevent supply-chain attack (C-15)
                install_result = subprocess.run(
                    [
                        "gem", "install", "synvert-core",
                        "--version", _SYNVERT_CORE_VERSION,
                        "--no-document",
                    ],
                    capture_output=True,
                    text=True,
                    timeout=60
                )
                
                if install_result.returncode != 0:
                    raise RuntimeError(
                        f"Failed to install synvert-core: "
                        f"{install_result.stderr}"
                    )

                verify_result = subprocess.run(
                    ["gem", "list", "^synvert-core$"],
                    capture_output=True,
                    text=True,
                    timeout=5,
                )
                verified_versions = self._parse_synvert_versions(verify_result.stdout)
                if _SYNVERT_CORE_VERSION not in verified_versions:
                    raise RuntimeError(
                        "synvert-core installation did not expose the required "
                        f"version {_SYNVERT_CORE_VERSION}"
                    )
        except Exception as e:
            raise RuntimeError(f"Synvert gem verification failed: {str(e)}")

    @staticmethod
    def _parse_synvert_versions(gem_list_output: str) -> List[str]:
        """Extract installed synvert-core versions from `gem list` output."""
        match = _SYNVERT_GEM_LINE_RE.search(gem_list_output or "")
        if not match:
            return []
        return [v.strip() for v in match.group(1).split(",") if v.strip()]
    
    def inline_rewrite(
        self,
        rewriter_code: str,
        file_pattern: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Execute inline Synvert rewriter code against project.
        
        Args:
            rewriter_code: Ruby code defining a Synvert::Rewriter class
            file_pattern: Optional file glob pattern to limit scope
                         (e.g., "routes.rb", "models/*.rb")
        
        Returns:
            Dict with keys:
            - success: bool - Whether transformation succeeded
            - stdout: str - Synvert output
            - stderr: str - Error output if any
            - changed_files: List[str] - Files modified
            - error_message: Optional[str] - Human-readable error
        """
        temp_rewriter_path: Optional[Path] = None
        
        try:
            # Secure temp file creation avoids fixed-name clobber/symlink attacks.
            with tempfile.NamedTemporaryFile(
                mode="w",
                suffix=".rb",
                prefix=".synvert_tmp_rewriter_",
                dir=str(self.project_path),
                delete=False,
                encoding="utf-8",
            ) as rewriter_file:
                rewriter_file.write(rewriter_code)
                temp_rewriter_path = Path(rewriter_file.name)
            
            # Build synvert command
            cmd = ["synvert", "--run", str(temp_rewriter_path), "."]
            
            # Execute synvert in project directory
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                cwd=str(self.project_path),
                timeout=30
            )
            
            success = result.returncode == 0
            changed_files = self._parse_changed_files(
                result.stdout,
                success
            )
            
            return {
                "success": success,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "changed_files": changed_files,
                "error_message": None if success else result.stderr,
                "rewriter_code": rewriter_code  # Add this for transparency/testing
            }
        
        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "stdout": "",
                "stderr": "Synvert execution timed out (>30s)",
                "changed_files": [],
                "error_message": "Synvert execution timed out",
                "rewriter_code": rewriter_code
            }
        
        except Exception as e:
            return {
                "success": False,
                "stdout": "",
                "stderr": str(e),
                "changed_files": [],
                "error_message": f"Synvert execution failed: {str(e)}",
                "rewriter_code": rewriter_code
            }
        
        finally:
            # Clean up temp file
            if temp_rewriter_path and temp_rewriter_path.exists():
                try:
                    temp_rewriter_path.unlink()
                except Exception:
                    pass
    
    def _parse_changed_files(self, output: str, success: bool) -> List[str]:
        """
        Parse synvert output to extract changed file paths.
        
        Args:
            output: Synvert stdout/stderr output
            success: Whether synvert execution succeeded
            
        Returns:
            List of file paths that were modified
        """
        changed = []
        
        if not output or not success:
            return changed
        
        # Synvert output patterns:
        # "modify" or "modified" lines typically contain file paths
        for line in output.split("\n"):
            line_lower = line.lower()
            
            # Look for lines with file modifications
            if ("modify" in line_lower or "modified" in line_lower or
                "changed" in line_lower):
                # Extract filename from line
                # Typical formats:
                # "  modify: config/routes.rb"
                # "modify app/models/user.rb"
                parts = line.split()
                for part in parts:
                    if part.endswith(".rb"):
                        changed.append(part.strip())
                        break
        
        return changed
    
    def add_webhook_routes(
        self,
        namespace: str = "webhooks",
        route_specs: Optional[List[tuple]] = None
    ) -> Dict[str, Any]:
        """
        Add webhook namespace to config/routes.rb using Synvert.
        
        Args:
            namespace: Namespace name (e.g., 'webhooks', 'api/v1/webhooks')
            route_specs: List of (method, path, controller) tuples
                        Default: [('post', 'shopify', 'webhooks/shopify#handle')]
        
        Returns:
            Result dict from inline_rewrite()
        """
        if route_specs is None:
            route_specs = [("post", "shopify", "webhooks/shopify#handle")]
        
        # C-1: sanitize namespace before any interpolation
        safe_ns = _safe_synvert_input(namespace, "namespace")

        # Build routes body — sanitize each per-route field
        routes_lines = []
        for method, path, controller in route_specs:
            s_method = _safe_synvert_input(str(method), "route.method")
            s_path = _safe_synvert_input(str(path), "route.path")
            s_controller = _safe_synvert_input(str(controller), "route.controller")
            routes_lines.append(
                f"    {s_method} '{s_path}', to: '{s_controller}'"
            )

        routes_body = "\n".join(routes_lines)

        # Build Synvert rewriter
        rewriter = f'''
Synvert::Rewriter.new 'rails', 'add_{safe_ns.replace("/", "_")}_routes' do
  configure parser: Synvert::RUBY_PARSER

  within_files 'config/routes.rb' do
    unless_exist_node '.send [message=namespace] [arguments.first.value={safe_ns}]' do
      append %{{
  namespace :{safe_ns} do
{routes_body}
  end
}}
    end
  end
end
'''.strip()
        
        return self.inline_rewrite(rewriter)
    
    def add_model_association(
        self,
        model_name: str,
        association_type: str,
        target: str,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Add association to Rails model using Synvert.
        
        Args:
            model_name: Model class name (e.g., 'Order', 'User')
            association_type: 'has_many', 'belongs_to', 'has_one'
            target: Target association name (e.g., 'items', 'tenant')
            **kwargs: Additional association options
                     (class_name, dependent, foreign_key, etc.)
        
        Returns:
            Result dict from inline_rewrite()
        """
        # C-1: sanitize all user-supplied inputs before interpolation
        safe_model_name = _safe_synvert_input(model_name, "model_name")
        safe_assoc_type = _safe_synvert_input(association_type, "association_type")
        safe_target = _safe_synvert_input(target, "target")
        model_file = safe_model_name[0].lower() + safe_model_name[1:]

        # Build association arguments — sanitize kwarg keys and string values
        assoc_args_parts = []
        for key, value in kwargs.items():
            safe_key = _safe_synvert_input(str(key), "kwarg.key")
            if value is True:
                assoc_args_parts.append(f"{safe_key}: true")
            elif value is False:
                assoc_args_parts.append(f"{safe_key}: false")
            elif isinstance(value, str):
                safe_val = _safe_synvert_input(value, f"kwarg.{safe_key}")
                assoc_args_parts.append(f"{safe_key}: '{safe_val}'")
            else:
                assoc_args_parts.append(f"{safe_key}: {value}")

        assoc_args = ", " + ", ".join(assoc_args_parts) if assoc_args_parts else ""

        rewriter = f'''
Synvert::Rewriter.new 'rails', 'add_{safe_assoc_type}_association' do
  configure parser: Synvert::RUBY_PARSER

  within_files 'app/models/{model_file}.rb' do
    with_node '.class [name={safe_model_name}]' do
      unless_exist_node '.send [message={safe_assoc_type}] [arguments.first.value=:{safe_target}]' do
        append %{{  {safe_assoc_type} :{safe_target}{assoc_args}}}
      end
    end
  end
end
'''.strip()
        
        return self.inline_rewrite(rewriter)
    
    def validate_ruby_syntax(self, file_path: Path) -> Dict[str, Any]:
        """
        Validate Ruby file syntax after transformation.
        
        Args:
            file_path: Path to Ruby file to validate
            
        Returns:
            Dict with:
            - valid: bool - Syntax is valid
            - error: str - Error message if invalid
        """
        try:
            result = subprocess.run(
                ["ruby", "-c", str(file_path)],
                capture_output=True,
                text=True,
                timeout=5,
                cwd=str(self.project_path)
            )
            
            return {
                "valid": result.returncode == 0,
                "error": result.stderr if result.returncode != 0 else None
            }
        except Exception as e:
            return {
                "valid": False,
                "error": str(e)
            }
