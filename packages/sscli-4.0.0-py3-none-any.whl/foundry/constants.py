from pathlib import Path
import os

from rich.console import Console

# Base directory navigation
# In a pipx/PyPI install, code is isolated. We need to find the actual monorepo.
def _get_foundry_root() -> Path:
    # 1. Allow explicit override only when it matches code-derived root.
    # This prevents arbitrary env redirection to attacker-controlled trees.
    env_root = os.getenv("FOUNDRY_ROOT")
    if env_root:
        _code_root = Path(__file__).resolve().parent.parent.parent.parent
        candidate = Path(env_root).expanduser().resolve()
        if candidate == _code_root:
            return candidate
        # Reject mismatched FOUNDRY_ROOT — log a warning and fall through to auto-detection.
        import warnings
        warnings.warn(
            f"FOUNDRY_ROOT override rejected: {env_root!r} does not match code-derived root "
            f"{_code_root!r}. Using auto-detected root.",
            stacklevel=2,
        )
    
    # 2. Check if we are running from within the monorepo (CWD has .github, tooling, templates, etc)
    cwd = Path.cwd()
    if (cwd / ".github").exists() and (cwd / "tooling").exists():
        return cwd
    
    # 3. If one level deep (e.g. in tooling/ or templates/), go up one
    if (cwd.parent / ".github").exists() and (cwd.parent / "tooling").exists():
        return cwd.parent
    
    # 4. If two levels deep (e.g. in tooling/stack-cli/), go up two
    if (cwd.parent.parent / ".github").exists() and (cwd.parent.parent / "tooling").exists():
        return cwd.parent.parent

    # 5. Walk up from the source file location (supports editable pip install in monorepo)
    #    constants.py lives at: foundry-meta/tooling/stack-cli/foundry/constants.py
    #    → .parent.parent.parent.parent == foundry-meta/
    _code_root = Path(__file__).resolve().parent.parent.parent.parent
    if (_code_root / ".github").exists() and (_code_root / "tooling").exists():
        return _code_root
        
    # 6. Fallback to where the code is installed (Legacy behavior)
    return Path(__file__).resolve().parent.parent.parent

FOUNDRY_ROOT = _get_foundry_root()
TEMPLATES_DIR = FOUNDRY_ROOT / "templates"

# Production License Server (Hardcoded for security)
SEED_SOURCE_PRODUCTION_API = "https://auth.seedsource.dev/api"

# Development Override
# Only enabled if FOUNDRY_INTERNAL_DEV is explicitly set AND we are in a dev mono-repo
def _get_api_url() -> str:
    # Check for developer override via environment variable
    env_url = os.getenv("LICENSE_SERVER_URL")
    if env_url:
        from urllib.parse import urlparse
        import warnings
        _parsed = urlparse(env_url)
        _ALLOWED_API_HOSTS = {"auth.seedsource.dev", "localhost", "127.0.0.1"}
        if _parsed.scheme not in ("https", "http") or _parsed.hostname not in _ALLOWED_API_HOSTS:
            warnings.warn(
                f"LICENSE_SERVER_URL override rejected: not in allowlist. "
                f"Got: {env_url!r}. Using default production URL.",
                stacklevel=2,
            )
        else:
            return env_url

    # If running locally in the mono-repo, default to production unless specified
    return SEED_SOURCE_PRODUCTION_API

API_BASE_URL = _get_api_url()

# Domain configuration (defaults to seedsource.dev, override via environment variables)
import re as _re
_DOMAIN_RE = _re.compile(r'^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z]{2,})+$')
_raw_domain = os.getenv("SEED_SOURCE_DOMAIN", "seedsource.dev")
if not _DOMAIN_RE.fullmatch(_raw_domain):
    raise ValueError(f"Invalid SEED_SOURCE_DOMAIN: {_raw_domain!r}. Must be a valid hostname.")
SEED_SOURCE_DOMAIN = _raw_domain
SEED_SOURCE_AUTH_URL = os.getenv("SEED_SOURCE_AUTH_URL", f"https://auth.{SEED_SOURCE_DOMAIN}")
SEED_SOURCE_LANDING_URL = os.getenv("SEED_SOURCE_LANDING_URL", f"https://{SEED_SOURCE_DOMAIN}")
FORMS_BASE_URL = os.getenv("FORMS_BASE_URL", f"https://forms.{SEED_SOURCE_DOMAIN}")

# Marketing URLs (always configured)
PRICING_URL = os.getenv("PRICING_URL", f"https://{SEED_SOURCE_DOMAIN}/pricing")
SALES_EMAIL = os.getenv("SALES_EMAIL", f"sales@{SEED_SOURCE_DOMAIN}")
ALPHA_SUPPORT_EMAIL = os.getenv("ALPHA_SUPPORT_EMAIL", f"support@{SEED_SOURCE_DOMAIN}")
ALPHA_FEEDBACK_FORM = os.getenv("ALPHA_FEEDBACK_FORM", f"{FORMS_BASE_URL}/alpha")
ALPHA_FEEDBACK_FORM_ENABLED = (
    os.getenv("ALPHA_FEEDBACK_FORM_ENABLED", "0").strip().lower() in {"1", "true", "yes", "on"}
)

# Metadata-based template registry for PyPI distribution
# This allows the CLI to know about templates without them being on disk
TEMPLATE_REGISTRY = {
    "python-saas": {
        "name": "Python SaaS Boilerplate",
        "description": "FastAPI + NiceGUI hexagonal SaaS — async SQLAlchemy, Alembic, Celery workers, Ruff + mypy strict linting, full Docker Compose dev environment.",
        "tier": "alpha",
        "repo": "https://github.com/seed-source/python-saas.git",
    },
    "python-worker-service": {
        "name": "Python Worker Service",
        "description": "Headless FastAPI worker — multipart POST endpoints, async task processing, no UI layer. Ideal for audio/ML workloads (e.g. Demucs).",
        "tier": "alpha",
        "repo": "https://github.com/seed-source/python-worker-service.git",
    },
    "rails-api": {
        "name": "Rails API Suite",
        "description": "JSON API with Devise, RSpec, and Docker",
        "tier": "free",
        "base": "rails-hexagonal-base",
        "repo": "https://github.com/seed-source/rails-api.git",
    },
    "rails-fullstack": {
        "name": "Rails Fullstack (Hotwire)",
        "description": "Hexagonal Rails 8 with Turbo, Stimulus, Tailwind, and session auth",
        "tier": "pro",
        "base": "rails-hexagonal-base",
        "repo": "https://github.com/seed-source/rails-fullstack.git",
    },
    "react-client": {
        "name": "React Vite Client",
        "description": "Modern frontend with Tailwind and React Query",
        "tier": "alpha",
        "repo": "https://github.com/seed-source/react-client.git",
    },
    "rails-ui-kit": {
        "name": "Rails UI Kit",
        "description": "Full-stack Rails with ViewComponent and Tailwind",
        "tier": "alpha",
        "repo": "https://github.com/seed-source/rails-ui-kit.git",
    },
    "data-pipeline": {
        "name": "Data Pipeline (dbt)",
        "description": "Modern data stack with dbt and Python",
        "tier": "alpha",
        "repo": "https://github.com/seed-source/data-pipeline.git",
    },
    "mobile-android": {
        "name": "Mobile Android",
        "description": "Kotlin-based Android application",
        "tier": "alpha",
        "repo": "https://github.com/seed-source/mobile-android-private.git",
    },
    "mobile-ios": {
        "name": "Mobile iOS",
        "description": "SwiftUI-based iOS application",
        "tier": "alpha",
        "repo": "https://github.com/seed-source/mobile-ios-private.git",
    },
    "terraform-infra": {
        "name": "Terraform Infrastructure",
        "description": "Multi-cloud IaC modules",
        "tier": "alpha",
        "repo": "https://github.com/seed-source/terraform-infra-private.git",
    },
    "wiring": {
        "name": "Docker Wiring",
        "description": "Orchestration for multi-service stacks",
        "tier": "alpha",
        "repo": "https://github.com/seed-source/wiring-private.git",
    },
    "static-landing": {
        "name": "Astro Static Landing",
        "description": "Astro static site generator for marketing/landing pages",
        "tier": "free",
        "repo": "https://github.com/seed-source/static-landing.git",
    },
    "feedback-forms": {
        "name": "Feedback Forms",
        "description": "GitHub-authenticated feedback form portal with Vite, Docker, and Playwright E2E",
        "tier": "alpha",
        "repo": "https://github.com/seed-source/feedback-forms.git",
    },
    "docs-site": {
        "name": "Astro Docs Site",
        "description": "Starlight-powered documentation site with auto-generated CLI/API reference",
        "tier": "free",
        "repo": "https://github.com/seed-source/docs-site.git",
        "new": True,
    },
}

# If a local `static-landing` directory exists in the mono-repo and is a git
# repository (for example as a submodule), prefer that local path so the CLI
# can operate on the on-disk template during development.
# M-10: Only activate the file:// URI when FOUNDRY_INTERNAL_DEV is explicitly "1"
# to prevent env-var path injection in production installs.
try:
    _local_static = Path(TEMPLATES_DIR) / "static-landing"
    if (
        os.getenv("FOUNDRY_INTERNAL_DEV") == "1"
        and _local_static.exists()
        and (_local_static / ".git").exists()
    ):
        TEMPLATE_REGISTRY["static-landing"]["repo"] = f"file://{_local_static.resolve()}"
except Exception:
    # Non-fatal: if anything goes wrong, keep the registry as-is.
    pass

try:
    _local_docs = Path(TEMPLATES_DIR) / "docs-site"
    if (
        os.getenv("FOUNDRY_INTERNAL_DEV") == "1"
        and _local_docs.exists()
        and (_local_docs / ".git").exists()
    ):
        TEMPLATE_REGISTRY["docs-site"]["repo"] = f"file://{_local_docs.resolve()}"
except Exception:
    pass

AVAILABLE_EXTENSIONS = {
    "commerce": {
        "name": "Commerce (Shopify/Stripe)",
        "tier": "pro",
        "description": "Injects Shopify/Commerce adapters and webhooks.",
    },
    "tunnel": {
        "name": "Local Tunneling (ngrok)",
        "tier": "pro",
        "description": "Configures the project for ngrok/local tunneling.",
    },
    "admin": {
        "name": "NiceGUI Admin",
        "tier": "pro",
        "description": "Standalone NiceGUI-based admin panel.",
    },
    "sqlite": {
        "name": "SQLite Local",
        "tier": "alpha",
        "description": "Local persistence with SQLAlchemy + Alembic.",
    },
    "ingestor": {
        "name": "Data Ingestor",
        "tier": "pro",
        "description": "Adapter pattern for raw data normalization.",
    },
    "payment": {
        "name": "Stripe Payment (Paid-Once Unlock)",
        "tier": "paid-once",
        "description": "Injects Stripe Checkout + webhook scaffold for subscription billing and one-time payments. Requires payment_feature_unlocked=true on your license.",
    },
    "seo-analyzer": {
        "name": "SEO Analyzer",
        "tier": "alpha",
        "description": "Injects an automated Lighthouse SEO scorer with CI-friendly threshold checks.",
    },
    "merchant-dashboard": {
        "name": "Merchant Dashboard",
        "tier": "pro",
        "description": "Full merchant management UI for react-client. Requires --with-commerce.",
    },
    "sidekiq": {
        "name": "Sidekiq Background Jobs",
        "tier": "alpha",
        "description": "Swaps ActiveJob queue adapter to Sidekiq with Procfile, job_queue.rb, and Redis config.",
    },
    "ui-lib": {
        "name": "UI Library",
        "tier": "alpha",
        "description": "Injects a UI component library into your React client: shadcn/ui, chakra-ui, MUI, Ant Design, or Tailwind-only.",
    },
    "sandbox": {
        "name": "Sandbox Mode",
        "tier": "free",
        "description": "Injects a sandbox policy and environment toggles for safe local experimentation.",
    },
    "shopify-embedded": {
        "name": "Shopify Embedded App",
        "tier": "pro",
        "description": (
            "Shopify App Bridge embedded app support (App Bridge 3.x, Polaris, session tokens). "
            "PRO-tier only."
        ),
    },
}

# Single source of truth for temporarily disabled feature injections.
# All 5 features (auth, admin, tunnel, ingestor, merchant_dashboard) are now ENABLED.
DISABLED_FEATURES_POLICY: dict = {}

# Feature registry with detailed descriptions and usage examples
FEATURES_REGISTRY = {
    "commerce": {
        "name": "Commerce Integration",
        "tier": "pro",
        "description": "Full Shopify/Stripe webhook integration with PII scrubbing, webhook deduplication, and secure payment processing.",
        "templates": ["python-saas", "react-client"],
        "example_base": "# Base template: API with basic CRUD operations\napp = FastAPI()\n\n@app.get(\"/items\")\nasync def get_items():\n    return await Item.all()",
        "example_with_feature": "# With Commerce: Shopify webhook handler + payment processor\nfrom foundry_commerce import init_commerce\n\ninit_commerce(app)\n\n@app.post(\"/webhooks/shopify/products.update\")\nasync def on_product_update(request: Request):\n    payload = await request.json()\n    await process_product_webhook(payload)"
    },
    "auth": {
        "name": "Authentication & Authorization",
        "tier": "pro",
        "description": "User authentication with JWT, role-based access control (RBAC), session management, and OAuth2 integration.",
        "templates": ["python-saas", "react-client", "rails-api"],
        "example_base": "# Base template: Open endpoints\napp = FastAPI()\n\n@app.get(\"/public/data\")\nasync def get_public_data():\n    return {\"status\": \"ok\"}",
        "example_with_feature": "# With Auth: Protected endpoints with user context\nfrom foundry_auth import AuthManager, require_auth\n\nauth = AuthManager(app)\n\n@app.get(\"/api/profile\")\n@require_auth()\nasync def get_profile(user: User = Depends(get_current_user)):\n    return {\"user_id\": user.id, \"email\": user.email}"
    },
    "admin": {
        "name": "Admin Dashboard",
        "tier": "pro",
        "description": "Interactive NiceGUI-based admin panel for managing users, content, and system configuration.",
        "templates": ["python-saas"],
        "example_base": "# Base template: CLI or basic management\nif __name__ == \"__main__\":\n    app = FastAPI()\n    uvicorn.run(app, host=\"0.0.0.0\")",
        "example_with_feature": "# With Admin: Interactive dashboard\nfrom nicegui_admin import AdminPanel\n\nui = ni.ui()\nadmin = AdminPanel(ui)\n\n@admin.register_resource(\"users\")\nclass UserAdmin:\n    async def list_users(self):\n        return await User.all()\n    \n    async def create_user(self, data):\n        return await User.create(**data)"
    },
    "tunnel": {
        "name": "Local Tunneling",
        "tier": "pro",
        "description": "ngrok integration for exposing local development server to the internet (useful for webhook testing).",
        "templates": ["python-saas", "react-client", "rails-api"],
        "example_base": "# Base template: Local development only\nuvicorn.run(app, host=\"127.0.0.1\", port=8000)",
        "example_with_feature": "# With Tunnel: Publicly accessible during development\nfrom foundry_tunnel import setup_tunnel\n\nconfig = setup_tunnel(app, subdomain=\"my-dev-project\")\nprint(f\"Public URL: {config.public_url}\")\nuvicorn.run(app, host=\"0.0.0.0\", port=8000)"
    },
    "payment": {
        "name": "Stripe Payment Integration",
        "tier": "paid-once",
        "description": "Stripe Checkout + webhook scaffold. Injects payment gateway port, Stripe adapter, and secure webhook handler. Requires $49 one-time unlock (valid for all templates, all time).",
        "templates": ["python-saas", "react-client", "rails-api", "rails-fullstack"],
        "example_base": "# Base template: No payment processing\n@app.get(\"/plans\")\nasync def get_plans():\n    return [{\"name\": \"Pro\", \"price\": 39}]",
        "example_with_feature": "# With Payment: Stripe Checkout session\nfrom src.infrastructure.payment.stripe_payment_adapter import StripePaymentAdapter\n\n@app.post(\"/payments/checkout\")\nasync def create_checkout(plan_id: str):\n    adapter = StripePaymentAdapter()\n    session = await adapter.create_checkout_session(plan_id)\n    return {\"checkout_url\": session.url}"
    },
    "seo_analyzer": {
        "name": "SEO Analyzer",
        "tier": "alpha",
        "description": "Automated Lighthouse SEO score checker for static-landing with configurable URL and pass threshold.",
        "templates": ["static-landing"],
        "example_base": "// Base template: standard Astro scripts\n\"scripts\": {\n  \"dev\": \"astro dev\",\n  \"build\": \"astro build\"\n}",
        "example_with_feature": "// With SEO Analyzer\n\"scripts\": {\n  \"seo:score\": \"node ./bin/seo-analyzer.mjs\"\n}\n// Run: SEO_URL=http://localhost:3000 SEO_MIN_SCORE=90 npm run seo:score"
    },
    "sidekiq": {
        "name": "Sidekiq Background Jobs",
        "tier": "alpha",
        "description": "Swaps Rails ActiveJob queue adapter to Sidekiq with Procfile, job_queue.rb, and Redis config for production-ready async processing.",
        "templates": ["rails-api", "rails-fullstack"],
        "example_base": "# Rails default: in-process async adapter\nconfig.active_job.queue_adapter = :async",
        "example_with_feature": "# With Sidekiq: production background jobs\nconfig.active_job.queue_adapter = :sidekiq\n# + Procfile with web and worker processes\n# + config/sidekiq.yml + Redis URL env var"
    },
    "ui_lib": {
        "name": "UI Library",
        "tier": "alpha",
        "description": "Injects a UI component library into your React client: shadcn/ui, chakra-ui, MUI, Ant Design, or Tailwind-only.",
        "templates": ["react-client"],
        "example_base": "// Base template: vanilla Tailwind classes\nexport function Button({ children }) {\n  return <button className=\"px-4 py-2 bg-blue-500 text-white rounded\">{children}</button>\n}",
        "example_with_feature": "// With shadcn/ui: design system ready to go\nimport { Button } from '@/components/ui/button'\nimport { Card, CardContent } from '@/components/ui/card'\n\nexport function Dashboard() {\n  return (\n    <Card><CardContent><Button>Get Started</Button></CardContent></Card>\n  )\n}"
    },
    "merchant_dashboard": {
        "name": "Merchant Dashboard",
        "tier": "alpha",
        "description": "Full merchant management UI injected into react-client. Requires --with-commerce to be active.",
        "templates": ["react-client"],
        "example_base": "// Base react-client: standard App.jsx\nexport function App() {\n  return <div>My App</div>\n}",
        "example_with_feature": "// With Merchant Dashboard: full order/product management\nimport { MerchantDashboard } from './features/merchant'\n\nexport function App() {\n  return <MerchantDashboard />\n}"
    },
    "sandbox": {
        "name": "Sandbox Mode",
        "tier": "free",
        "description": "Injects a sandbox policy file and local env toggles to separate public read access from authenticated write operations.",
        "templates": ["python-saas", "rails-api", "rails-fullstack", "react-client", "static-landing", "docs-site"],
        "example_base": "# Base environment\nAPP_ENV=production",
        "example_with_feature": "# With Sandbox Mode\nSS_SANDBOX_MODE=1\nSS_SANDBOX_READ_PUBLIC=1\nSS_SANDBOX_WRITE_AUTH_REQUIRED=1"
    },
    "shopify_embedded": {
        "name": "Shopify Embedded App",
        "tier": "pro",
        "description": (
            "Shopify App Bridge embedded app support (App Bridge 3.x, Polaris, session tokens). "
            "Injects AppBridgeProvider, session-token auth hooks, and Polaris theme wrapper into "
            "react-client."
        ),
        "templates": ["react-client"],
        "example_base": "// Base react-client: standalone React app\nexport function App() {\n  return <div>My App</div>\n}",
        "example_with_feature": (
            "// With Shopify Embedded: wrapped in AppBridgeProvider\n"
            "import { AppBridgeProvider } from './providers/AppBridgeProvider'\n"
            "import { AppProvider } from '@shopify/polaris'\n\n"
            "export function App() {\n"
            "  return (\n"
            "    <AppBridgeProvider>\n"
            "      <AppProvider><YourApp /></AppProvider>\n"
            "    </AppBridgeProvider>\n"
            "  )\n"
            "}"
        ),
    },
}

TIER_HIERARCHY = {"free": 0, "alpha": 1, "pro": 2, "enterprise": 3, "admin": 10}

console = Console()


# Menu configuration
ANIMATED_MENU_ITEMS = [
    "Explore Templates",
    "Generate Project",
    "Manage Config",
    "System Validation",
    "View Docs",
    "Exit",
]

# Apply questionary patching for description styling
from foundry.patch import apply_description_patch
apply_description_patch()

# Shared Questionary styling - consistent across all menus
QUESTIONARY_STYLE = [
    ("qmark", "fg:#673ab7 bold"),       # purple
    ("question", "bold"),               # bold question
    ("answer", "fg:#f44336 bold"),     # red answer
    ("pointer", "fg:#673ab7 bold"),    # purple pointer
    ("highlighted", "fg:#673ab7 bold"),# purple highlighted item (selected)
    ("selected", "fg:#cc5454"),        # selected item
    ("text", "fg:#ffffff"),            # white for unselected items
    ("description", "fg:#888888"),     # gray for descriptions (via patch)
    ("instruction", "fg:#888888 italic"),# gray italic for hints
    ("purple", "fg:#673ab7"),          # purple for categories
    ("yellow", "fg:#f4bf75"),          # yellow for others
    ("cyan", "fg:#66d9ef"),            # cyan for template names
    ("red", "fg:#f92672"),             # red for locked
    ("magenta", "fg:#ae81ff"),         # magenta for pro
    ("green", "fg:#a6e22e"),           # green for free/alpha
]
