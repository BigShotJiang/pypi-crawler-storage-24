"""Structured CLI event logging."""
import json
import logging
import sys
from datetime import datetime, timezone


class StructuredLogger:
    """Wrapper for emitting structured log events from the CLI."""

    def __init__(self, service: str = "sscli"):
        self._logger = logging.getLogger(service)

    def failure(self, event: str, message: str, **kwargs) -> None:
        self._logger.error(json.dumps({
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "level": "ERROR",
            "service": "sscli",
            "event": event,
            "message": message,
            **kwargs,
        }))

    def info(self, event: str, message: str, **kwargs) -> None:
        self._logger.info(json.dumps({
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "level": "INFO",
            "service": "sscli",
            "event": event,
            "message": message,
            **kwargs,
        }))


logger = StructuredLogger()
