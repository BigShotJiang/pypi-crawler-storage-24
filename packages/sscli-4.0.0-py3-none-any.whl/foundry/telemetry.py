"""
Telemetry module for sscli — local session log with security guardrails.

Security properties enforced:
  M-1  — newline / log-injection sanitization: raw \\n and \\r stripped from details
  M-2a — log directory created with mode 0o700 (user-only access)
  M-2b — log file size cap at 5 MB; oversized file is truncated before append

Structured opt-in event telemetry:
  record_event() writes JSONL to ~/.config/sscli/telemetry.jsonl (local only).
  Disabled entirely when SSCLI_NO_TELEMETRY=1.  No network calls.
"""

from __future__ import annotations

import datetime
import json
import os
from datetime import timezone
from pathlib import Path

from foundry.constants import ALPHA_FEEDBACK_FORM

_LOG_FILE_NAME = ".session.log"
_MAX_LOG_SIZE = 5 * 1024 * 1024  # 5 MB


def _get_log_file() -> Path:
    """Return the log file path, creating the log directory with mode 0o700."""
    log_dir_env = os.environ.get("SSCLI_LOG_DIR")
    if log_dir_env:
        log_dir = Path(log_dir_env)
    else:
        log_dir = Path.home() / ".sscli"

    log_dir.mkdir(parents=True, exist_ok=True)
    os.chmod(log_dir, 0o700)

    return log_dir / _LOG_FILE_NAME


try:
    LOG_FILE: Path = _get_log_file()
except Exception:
    LOG_FILE = Path(".session.log")


def log_event(event_type: str, details: str = "") -> None:
    """Log an event to the local session log.

    M-1: raw newline / carriage-return characters in *details* are replaced with
    spaces so that a single event always occupies exactly one log line.

    M-2b: if the log file exceeds _MAX_LOG_SIZE it is truncated before appending.
    """
    # M-1: strip log-injection vectors
    safe_event_type = (
        event_type.replace("\r\n", " ").replace("\r", " ").replace("\n", " ")
    )
    safe_details = (
        details.replace("\r\n", " ").replace("\r", " ").replace("\n", " ")
    )

    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_entry = f"[{timestamp}] {safe_event_type.upper()}: {safe_details}\n"

    try:
        # M-2b: rotate (truncate) oversized log before appending
        if LOG_FILE.exists() and LOG_FILE.stat().st_size > _MAX_LOG_SIZE:
            LOG_FILE.write_bytes(b"")

        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(log_entry)
    except Exception:
        pass  # silent failure — never break the CLI experience


def get_feedback_link() -> str:
    """Return the alpha feedback form URL."""
    return ALPHA_FEEDBACK_FORM


# ============================================================================
# STRUCTURED OPT-IN EVENT TELEMETRY
# ============================================================================

STRUCTURED_TELEMETRY_FILE = Path.home() / ".config" / "sscli" / "telemetry.jsonl"


def record_event(event_type: str, properties: dict | None = None) -> None:
    """Record a CLI usage event to local structured telemetry file.

    Writes one JSON line per event to ~/.config/sscli/telemetry.jsonl.
    No network calls are made — file is local only.
    Silently disabled when SSCLI_NO_TELEMETRY env var is set to any value.
    Always non-fatal: any I/O error is swallowed.
    """
    if os.getenv("SSCLI_NO_TELEMETRY"):
        return
    try:
        STRUCTURED_TELEMETRY_FILE.parent.mkdir(parents=True, exist_ok=True)
        entry = {
            "event": event_type,
            "timestamp": datetime.datetime.now(tz=timezone.utc).isoformat(),
            "properties": properties or {},
        }
        with STRUCTURED_TELEMETRY_FILE.open("a") as f:
            f.write(json.dumps(entry) + "\n")
    except Exception:
        pass  # Telemetry is non-fatal


# ============================================================================
# SSA-71: OPT-IN NETWORK TELEMETRY (injection events)
# ============================================================================

import time  # noqa: E402
import urllib.request  # noqa: E402
from typing import Any  # noqa: E402

_NET_TELEMETRY_ENABLED = os.environ.get("SSCLI_TELEMETRY", "0") == "1"
_NET_TELEMETRY_ENDPOINT = os.environ.get(
    "SSCLI_TELEMETRY_URL", "https://auth.seedsource.dev/api/v1/telemetry"
)


def track(event: str, properties: dict[str, Any] | None = None) -> None:
    """Send an event to the network telemetry endpoint (opt-in only).

    No-op when SSCLI_TELEMETRY != 1 or if the endpoint is unreachable.
    No PII, file contents, or secrets are included.
    """
    if not _NET_TELEMETRY_ENABLED:
        return

    payload = {
        "event": event,
        "timestamp": int(time.time()),
        "properties": properties or {},
    }

    try:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            _NET_TELEMETRY_ENDPOINT,
            data=data,
            headers={"Content-Type": "application/json", "X-Telemetry": "1"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=2) as _:  # noqa: S310
            pass
    except Exception:  # noqa: BLE001
        pass  # Telemetry failures are always silent


def track_injection(feature: str, template: str, success: bool) -> None:
    """Track a feature injection event (SSA-71)."""
    track(
        "feature_injected",
        {
            "feature": feature,
            "template": template,
            "success": success,
        },
    )
