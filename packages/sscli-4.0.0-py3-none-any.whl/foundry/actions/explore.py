from foundry.constants import console, TIER_HIERARCHY, QUESTIONARY_STYLE, TEMPLATE_REGISTRY, FEATURES_REGISTRY
from foundry.utils import get_templates, get_template_info
from foundry.auth import get_current_license_info
from rich.panel import Panel
from rich.tree import Tree
from rich.syntax import Syntax
from rich.style import Style
import json as json_module
import questionary
from questionary import Choice
import re


def _get_template_tech(name):
    """Get technology stack for a template by name."""
    # Map template names to tech descriptions with emoji icons
    tech_map = {
        "python-saas": "🐍 Python (NiceGUI UI + FastAPI/SQLAlchemy)",
        "python-worker-service": "🐍 Python (headless FastAPI worker)",
        "rails-api": "💎 Ruby on Rails",
        "react-client": "⚛️ React/Vite",
        "rails-ui-kit": "🎨 Rails + ViewComponent",
        "static-landing": "🚀 Astro (Static Site)",
        "docs-site": "🌟 Astro Starlight (Documentation)",
        "mobile-android": "🤖 Android (Kotlin/Compose)",
        "mobile-ios": "🍎 iOS (Swift/SwiftUI)",
        "data-pipeline": "📊 Data Stack (dbt + Python)",
        "terraform-infra": "🏗️ Terraform (Multi-cloud)",
        "wiring": "🐳 Docker Orchestration",
    }
    return tech_map.get(name, "📦 Multi-tech Stack")


def _strip_markup(text):
    """Remove Rich markup tags from text."""
    return re.sub(r'\[/?[^\]]+\]', '', text)


def _render_templates_tree(buckets):
    """Render a tree view with all categories expanded showing available templates."""
    tree = Tree("[bold green]Seed & Source Inventory[/bold green]")

    for category, items in buckets.items():
        if not items:
            continue

        count = len(items)
        cat_node = tree.add(f"[bold yellow]▼ {category} ({count})[/bold yellow]")
        
        for item in items:
            node = cat_node.add(f"[bold cyan]{item['name']}[/bold cyan]")
            # Show tier badge in tree
            if item['tier'] != "free":
                tier_display = f"(🔐 {item['tier'].upper()})" if item['locked'] else f"(✅ {item['tier'].upper()})"
                node.add(f"[yellow]{tier_display}[/yellow]")
            # Show tech
            tech = _get_template_tech(item['name'])
            node.add(f"[dim]{tech}[/dim]")

    console.print(Panel(tree, title="Available Templates", border_style="green"))


def _show_template_info(name, locked=False):
    """Show detailed information about a template with features and examples."""
    info = get_template_info(name)
    tech = _get_template_tech(name)
    user_tier = TIER_HIERARCHY.get(info.get('tier', 'free').lower(), 0)
    
    content = f"[bold cyan]Name:[/bold cyan] {name}\n"
    content += f"[bold cyan]Tech:[/bold cyan] {tech}\n"
    content += f"[bold cyan]Tier:[/bold cyan] {info.get('tier', 'free').upper()}\n"
    
    # Hide repo URL when template is locked
    if not locked:
        content += f"[bold cyan]Repo:[/bold cyan] {info.get('repo', 'N/A')}\n"
    else:
        content += "[bold cyan]Access:[/bold cyan] [red]🔒 Locked for your membership tier[/red]\n"
    
    content += f"\n[italic]{info.get('description', 'No detailed description available.')}[/italic]"
    
    # Show available features for this template
    available_features = []
    for feature_key, feature_data in FEATURES_REGISTRY.items():
        if name in feature_data.get("templates", []):
            available_features.append((feature_key, feature_data))
    
    if available_features:
        content += "\n\n[bold yellow]Available Features:[/bold yellow]"
        
        for feature_key, feature_data in available_features:
            feature_tier = feature_data.get("tier", "free")
            tier_indicator = "[magenta](PRO)[/magenta]" if feature_tier == "pro" else "[green](ALPHA)[/green]"
            
            # Show feature with tier lock status
            if feature_tier == "pro" and user_tier < TIER_HIERARCHY.get("pro", 0):
                status = "[red]🔒 LOCKED[/red]"
            else:
                status = "[green]✓ Available[/green]"
            
            content += f"\n  {tier_indicator} [bold cyan]{feature_data['name']}[/bold cyan] {status}"
            content += f"\n     {feature_data['description']}"
    
    cyan_style = Style(color="cyan")
    console.print(Panel(content, title=f"Template Details: {name}", border_style=cyan_style, expand=False, padding=(1, 2)))
    
    # Show code examples separately for available features
    if available_features:
        for feature_key, feature_data in available_features:
            feature_tier = feature_data.get("tier", "free")
            
            # Show code examples only if feature is available
            if not (feature_tier == "pro" and user_tier < TIER_HIERARCHY.get("pro", 0)):
                console.print(f"\n[bold cyan]{feature_data['name']} - Examples[/bold cyan]")
                
                console.print("\n[dim]Base template example:[/dim]")
                example_base = Syntax(
                    feature_data.get("example_base", "# No example available"),
                    "python",
                    theme="monokai",
                    line_numbers=False,
                    word_wrap=True
                )
                console.print(example_base)
                
                console.print("\n[dim]With feature example:[/dim]")
                example_feature = Syntax(
                    feature_data.get("example_with_feature", "# No example available"),
                    "python",
                    theme="monokai",
                    line_numbers=False,
                    word_wrap=True
                )
                console.print(example_feature)
    
    questionary.press_any_key_to_continue().ask()


def run_explore():
    """Interactive template explorer with collapsible tree and selectable templates."""
    # Get user info for tier checking
    user_info = get_current_license_info()
    user_tier = user_info.get("tier", "free")
    user_rank = TIER_HIERARCHY.get(user_tier, 0)

    # Group templates by category
    buckets = {
        "Backend Services": [],
        "Frontend & UI": [],
        "Mobile App": [],
        "Data Engineering": [],
        "Infrastructure": [],
        "Other": [],
    }
    
    # Track locked status for each template
    template_locked_status = {}

    templates = get_templates()

    for tmpl in templates:
        name = tmpl.name
        # Fetch metadata to get the tier
        info = get_template_info(name)
        tmpl_tier = info.get("tier", "free").lower()
        tmpl_rank = TIER_HIERARCHY.get(tmpl_tier, 0)

        # Check if locked
        locked = tmpl_rank > user_rank
        template_locked_status[name] = locked
        
        # Store template data for processing
        tmpl_data = {
            "name": name,
            "tier": tmpl_tier,
            "locked": locked,
            "new": info.get("new", False),
        }

        if name in ["python-saas", "rails-api"]:
            buckets["Backend Services"].append(tmpl_data)
        elif name in ["react-client", "rails-ui-kit", "static-landing", "docs-site"]:
            buckets["Frontend & UI"].append(tmpl_data)
        elif name.startswith("mobile-"):
            buckets["Mobile App"].append(tmpl_data)
        elif name == "data-pipeline":
            buckets["Data Engineering"].append(tmpl_data)
        elif name == "terraform-infra":
            buckets["Infrastructure"].append(tmpl_data)
        else:
            buckets["Other"].append(tmpl_data)

    # Remove empty categories
    buckets = {k: v for k, v in buckets.items() if v}
    
    # State for collapsible sections - start collapsed as requested
    expanded_categories = set()
    last_selected_val = None
    
    while True:
        console.clear()
        # Green frame that encompasses the header and instructions
        console.print(Panel(
            "[bold green]Seed & Source Inventory[/bold green]\n"
            "[dim]Navigate with arrows. Use [bold]Enter[/bold] to expand/collapse groups or view template details.[/dim]",
            border_style="green",
            padding=(1, 2)
        ))
        
        # Build display menu and choices list with proper ordering
        choices = []
        
        # Map values to their index for default selection preservation
        default_choice = None

        for category, items in buckets.items():
            is_expanded = category in expanded_categories
            # Using characters like symbols 
            symbol = "▼" if is_expanded else "▶"
            count = len(items)
            # Section/Category - plain text
            cat_display = f"{symbol} {category} ({count})"
            
            value = f"toggle:{category}"
            if value == last_selected_val:
                default_choice = value

            choices.append(Choice(
                title=cat_display,
                value=value
            ))
            
            if is_expanded:
                for i, item in enumerate(items):
                    is_last = (i == len(items) - 1)
                    connector = "    " # indent
                    sub_symbol = "  └─ " if is_last else "  ├─ "
                    
                    # Icons 
                    status_icon = "🔐" if item['locked'] else "✅"
                    
                    # Item display - plain text
                    new_badge = " [NEW]" if item.get("new") else ""
                    item_display = f"{connector}{sub_symbol}{item['name']}{new_badge} {status_icon}"
                    
                    # Tier label
                    if item['locked']:
                        item_display += " LOCKED"
                    else:
                        tier = item['tier'].upper()
                        item_display += f" {tier}"

                    
                    # Tech description
                    tech = _get_template_tech(item['name'])
                    
                    value = f"tmpl:{item['name']}"
                    if value == last_selected_val:
                        default_choice = value

                    # Include tech info in title
                    display_with_tech = f"{item_display} ({tech})"

                    choices.append(Choice(
                        title=display_with_tech,
                        value=value
                    ))
        
        choices.append(Choice("← Back to Main Menu", value="back"))
        
        selected = questionary.select(
            "Select a template to view details:",
            choices=choices,
            style=questionary.Style(QUESTIONARY_STYLE),
            use_indicator=True,
            default=default_choice
        ).ask()

        if selected is None or selected == "back":
            break
            
        last_selected_val = selected

        if selected.startswith("toggle:"):
            cat = selected.split(":", 1)[1]
            if cat in expanded_categories:
                expanded_categories.remove(cat)
            else:
                expanded_categories.add(cat)
            continue
            
        if selected.startswith("tmpl:"):
            tmpl_name = selected.split(":", 1)[1]
            locked = template_locked_status.get(tmpl_name, False)
            _show_template_info(tmpl_name, locked=locked)


def run_explore_list():
    """Non-interactive plain-text listing of all templates.

    Safe to pipe to files/scripts.  Does NOT require a TTY.
    """
    user_info = get_current_license_info()
    user_tier = user_info.get("tier", "free")
    user_rank = TIER_HIERARCHY.get(user_tier, 0)

    for name, meta in TEMPLATE_REGISTRY.items():
        tier = meta.get("tier", "free")
        rank = TIER_HIERARCHY.get(tier, 0)
        locked = rank > user_rank
        status = "LOCKED" if locked else "available"
        tech = _get_template_tech(name)
        print(f"{name}\t{tier}\t{status}\t{tech}\t{meta.get('description', '')}")


def run_explore_json():
    """Non-interactive JSON catalog of all templates.

    Safe to pipe to files/scripts.  Does NOT require a TTY.
    Output goes to stdout as pure JSON (no Rich markup).
    """
    import sys
    user_info = get_current_license_info()
    user_tier = user_info.get("tier", "free")
    user_rank = TIER_HIERARCHY.get(user_tier, 0)

    catalog = []
    for name, meta in TEMPLATE_REGISTRY.items():
        tier = meta.get("tier", "free")
        rank = TIER_HIERARCHY.get(tier, 0)
        locked = rank > user_rank
        features = [
            {
                "key": k,
                "name": v["name"],
                "tier": v["tier"],
                "available": TIER_HIERARCHY.get(v["tier"], 0) <= user_rank,
                "description": v.get("description", ""),
            }
            for k, v in FEATURES_REGISTRY.items()
            if name in v.get("templates", [])
        ]
        catalog.append({
            "name": name,
            "display_name": meta.get("name", name),
            "tier": tier,
            "locked": locked,
            "description": meta.get("description", ""),
            "tech": _get_template_tech(name),
            "features": features,
        })

    sys.stdout.write(json_module.dumps(catalog, indent=2) + "\n")

