import shutil
import json as json_module
from pathlib import Path

import questionary
from foundry.constants import (
    ALPHA_FEEDBACK_FORM_ENABLED,
    DISABLED_FEATURES_POLICY,
    console,
)
from foundry.telemetry import get_feedback_link
from foundry.utils import get_template_info
from foundry.actions.generation_utils import (
    inject_metadata,
    disable_linters,
    validate_and_fix_pyproject,
    check_tier_access,
    check_feature_tier_access,
    regenerate_poetry_lock,
    apply_landing_blueprint,
    inject_sidekiq,
    inject_ui_lib,
)
from foundry.metadata.metadata_tracker import MetadataTracker
from foundry.actions.features import setup_secrets, inject_features
from foundry.license_check import verify_license
from .interactive_config import get_interactive_config
from .repo_utils import download_template, initialize_github_repo


def log_event(*_args, **_kwargs):
    """Compatibility shim for tests and optional telemetry hooks."""
    return


def _guard_disabled_features(
    *,
    with_auth: bool,
    with_admin: bool,
    with_tunnel: bool,
    with_ingestor: bool,
    with_merchant_dashboard: bool,
) -> bool:
    disabled_flags = {
        "auth": with_auth,
        "admin": with_admin,
        "tunnel": with_tunnel,
        "ingestor": with_ingestor,
        "merchant_dashboard": with_merchant_dashboard,
    }
    for key, enabled in disabled_flags.items():
        if enabled and key in DISABLED_FEATURES_POLICY:
            cfg = DISABLED_FEATURES_POLICY[key]
            console.print(f"[red]❌ Error: {cfg['flag']} is coming soon.[/red]")
            console.print(f"[yellow]{cfg['message']}[/yellow]")
            return False
    return True


def run_generator(
    template_name: str = None,
    app_name: str = None,
    target_dir_name: str = None,
    use_linters: bool = True,
    with_commerce: bool = False,
    with_payment: bool = False,
    with_tunnel: bool = False,
    with_landing: bool = False,
    with_admin: bool = False,
    with_sqlite: bool = False,
    with_ingestor: bool = False,
    with_auth: bool = False,
    with_seo_analyzer: bool = False,
    with_merchant_dashboard: bool = False,
    with_sidekiq: bool = False,
    with_sandbox: bool = False,
    with_ui_lib: str = None,
    interactive: bool = False,
    use_ast_injection: bool = False,
    secrets_strategy: str = "Dotenv (Standard .env files)",
    github_config: dict = None,
    content_path: str = None,
    theme: str = None,
    dry_run: bool = False,
    only_safe: bool = False,
    force: bool = False,
    json_output: bool = False,
    stats_only: bool = False,
    output_file: str = None,
):

    if interactive:
        config = get_interactive_config(template_name)
        if not config: return
        
        template_name = config["template_name"]
        app_name = config["app_name"]
        with_commerce = config["with_commerce"]
        with_tunnel = config["with_tunnel"]
        with_landing = config["with_landing"]
        with_admin = config.get("with_admin", False)
        with_sqlite = config.get("with_sqlite", False)
        with_ingestor = config.get("with_ingestor", False)
        with_auth = config.get("with_auth", False)
        with_seo_analyzer = config.get("with_seo_analyzer", False)
        with_merchant_dashboard = config.get("with_merchant_dashboard", False)
        use_linters = config["use_linters"]
        use_ast_injection = config.get("use_ast_injection", False)
        secrets_strategy = config["secrets_strategy"]
        github_config = config.get("github_config")
    else:
        secrets_strategy = secrets_strategy or "Dotenv (Standard .env files)"

    # License gate — verify against the license server before any processing.
    verify_license()

    if not _guard_disabled_features(
        with_auth=with_auth,
        with_admin=with_admin,
        with_tunnel=with_tunnel,
        with_ingestor=with_ingestor,
        with_merchant_dashboard=with_merchant_dashboard,
    ):
        return

    # Tier Enforcement Check
    template_info = get_template_info(template_name)
    if not check_tier_access(template_name, template_info.get("tier", "free")):
        return

    # Feature Tier Enforcement — check PRO features before doing any work
    pro_features_requested = {
        "auth": with_auth,
        "commerce": with_commerce,
        "admin": with_admin,
        "tunnel": with_tunnel,
    }
    for feature_key, requested in pro_features_requested.items():
        if requested and not check_feature_tier_access(feature_key):
            return

    # Determine destination path
    if interactive:
        target_path_input = questionary.text(
            "Where would you like to install the repository?", default=str(Path.cwd())
        ).ask()
        if not target_path_input:
            console.print("[red]Error: Installation path required.[/red]")
            return
        target_path = Path(target_path_input)
    else:
        if not target_dir_name and not app_name:
            target_path = Path.cwd()
        else:
            target_path = Path(target_dir_name) if target_dir_name else (Path.cwd() / app_name)

    if target_dir_name:
        cwd_root = Path.cwd().resolve()
        resolved_target = target_path.resolve()
        if not resolved_target.is_relative_to(cwd_root):
            console.print(
                f"[red]Error: target_dir_name must resolve within current directory ({cwd_root}). Got: {resolved_target}[/red]"
            )
            return

    if not template_name:
        console.print("[red]Error: Template name required.[/red]")
        return

    # Preflight summary is always computed first to keep generation dry-first.
    preview_features = []
    if with_commerce:
        preview_features.append("commerce")
    if with_payment:
        preview_features.append("payment")
    if with_tunnel:
        preview_features.append("tunnel")
    if with_landing:
        preview_features.append("landing")
    if with_admin:
        preview_features.append("admin")
    if with_sqlite:
        preview_features.append("sqlite")
    if with_ingestor:
        preview_features.append("ingestor")
    if with_auth:
        preview_features.append("auth")
    if with_seo_analyzer:
        preview_features.append("seo-analyzer")
    if with_merchant_dashboard:
        preview_features.append("merchant-dashboard")
    if with_sandbox:
        preview_features.append("sandbox")

    if not dry_run:
        console.print("[cyan]Preflight (dry-first):[/cyan]")
        console.print(f"  Template: {template_name}")
        console.print(f"  App Name: {app_name}")
        console.print(f"  Target Path: {target_path}")
        console.print(f"  Features: {', '.join(preview_features) if preview_features else 'none'}")

    if only_safe and force:
        console.print("[red]Error:[/red] --only-safe cannot be combined with --force")
        return

    # Dry-run mode: show what would be generated
    if dry_run:
        log_event("GENERATE_DRY_RUN", f"Template: {template_name}, App: {app_name}")
        # Build the configuration summary dict (used for both display and JSON output)
        features_applied = preview_features

        # Collect file tree statistics from the local template if available
        template_info_for_scan = get_template_info(template_name)
        local_template_path = None
        try:
            from foundry.constants import TEMPLATES_DIR
            from foundry.utils import is_internal_dev
            candidate = TEMPLATES_DIR / template_name
            if is_internal_dev() and candidate.exists():
                local_template_path = candidate
        except Exception:
            pass

        file_stats = {"total_files": 0, "by_extension": {}, "test_files": 0, "dirs": 0}
        if local_template_path is None:
            file_stats["note"] = (
                "stats unavailable — template tree not present locally "
                "(PyPI install). Run with FOUNDRY_INTERNAL_DEV=1 for accurate counts."
            )
        file_tree: list = []
        if local_template_path:
            for fp in sorted(local_template_path.rglob("*")):
                if fp.is_dir():
                    file_stats["dirs"] += 1
                    continue
                rel = str(fp.relative_to(local_template_path))
                file_tree.append(rel)
                file_stats["total_files"] += 1
                ext = fp.suffix.lower() or "(no ext)"
                file_stats["by_extension"][ext] = file_stats["by_extension"].get(ext, 0) + 1
                if "test" in rel.lower() or "spec" in rel.lower():
                    file_stats["test_files"] += 1

        # Assemble the dry-run result object
        dry_run_result = {
            "dry_run": True,
            "template": template_name,
            "app_name": app_name,
            "target_path": str(target_path),
            "features": features_applied,
            "linters": use_linters,
            "secrets_strategy": secrets_strategy,
            "stats": file_stats,
            "file_tree": file_tree,
        }

        if stats_only:
            # Show only statistics summary
            console.print(f"[bold yellow]📊 DRY-RUN STATS:[/bold yellow] {template_name}")
            console.print(f"  Total files : [cyan]{file_stats['total_files']}[/cyan]")
            console.print(f"  Directories : [cyan]{file_stats['dirs']}[/cyan]")
            console.print(f"  Test files  : [cyan]{file_stats['test_files']}[/cyan]")
            if file_stats.get("note"):
                console.print(f"  [yellow]Note:[/yellow] {file_stats['note']}")
            if file_stats["by_extension"]:
                console.print("  By extension:")
                for ext, count in sorted(file_stats["by_extension"].items(), key=lambda x: -x[1]):
                    console.print(f"    [dim]{ext}[/dim]: {count}")
        elif json_output:
            import sys
            output_str = json_module.dumps(dry_run_result, indent=2)
            if output_file:
                out_path = Path(output_file)
                out_path.parent.mkdir(parents=True, exist_ok=True)
                out_path.write_text(output_str, encoding="utf-8")
                console.print(f"[green]✓[/green] Dry-run JSON written to [cyan]{output_file}[/cyan]")
            else:
                # Print JSON to stdout (no Rich formatting so it's parseable by scripts)
                sys.stdout.write(output_str + "\n")
        else:
            # Human-readable preview (default)
            console.print(f"[yellow]🔍 DRY-RUN:[/yellow] Previewing {template_name} generation...")
            console.print(f"[cyan]Template:[/cyan] {template_name}")
            console.print(f"[cyan]App Name:[/cyan] {app_name}")
            console.print(f"[cyan]Target Path:[/cyan] {target_path}")

            # Show configuration summary
            config_items = []
            if with_commerce:
                config_items.append("✓ Commerce (Shopify/Stripe)")
            if with_payment:
                config_items.append("✓ Payment (Stripe Checkout — Paid-Once Unlock)")
            if with_tunnel:
                config_items.append("✓ Tunneling (ngrok)")
            if with_landing:
                config_items.append("✓ Landing Page (Astro)")
            if with_admin:
                config_items.append("✓ Admin Panel (NiceGUI)")
            if with_sqlite:
                config_items.append("✓ SQLite + Alembic")
            if with_ingestor:
                config_items.append("✓ Data Ingestor")
            if with_auth:
                config_items.append("✓ Authentication")
            if with_seo_analyzer:
                config_items.append("✓ SEO Analyzer")
            if with_merchant_dashboard:
                config_items.append("✓ Merchant Dashboard")
            if with_sandbox:
                config_items.append("✓ Sandbox Mode")
            if use_linters:
                config_items.append("✓ Linters Enabled")

            if config_items:
                console.print("[cyan]Configuration:[/cyan]")
                for item in config_items:
                    console.print(f"  {item}")

            console.print(f"[cyan]Secrets Strategy:[/cyan] {secrets_strategy}")

            if file_stats["total_files"] > 0:
                console.print(f"[cyan]Files would be created:[/cyan] {file_stats['total_files']} files in {file_stats['dirs']} directories")

            # Write output file if requested
            if output_file:
                out_path = Path(output_file)
                out_path.parent.mkdir(parents=True, exist_ok=True)
                out_path.write_text(
                    json_module.dumps(dry_run_result, indent=2), encoding="utf-8"
                )
                console.print(f"[green]✓[/green] Preview written to [cyan]{output_file}[/cyan]")

            console.print("\n[green]✓[/green] Dry-run preview complete (no changes applied)")

        return

    console.print(f"\n[bold green]Deploying {template_name} to {target_path.name}...[/bold green]")

    try:
        if target_path.exists():
            target_entries = list(target_path.iterdir()) if target_path.is_dir() else []

            if only_safe:
                console.print(
                    f"[red]Error:[/red] --only-safe requires a new directory. Found existing path: {target_path}"
                )
                return

            if target_entries:
                if not force:
                    console.print(f"[red]Error: {target_path.name} already exists and is not empty![/red]")
                    console.print("[yellow]Tip:[/yellow] Re-run with --force to replace it.")
                    return

                console.print(f"[yellow]⚠️  --force enabled: replacing existing directory {target_path}[/yellow]")
                shutil.rmtree(target_path)
                target_path.mkdir(parents=True, exist_ok=True)

        if not download_template(template_name, template_info, target_path):
            return

        # Post-download processing
        inject_metadata(target_path, template_name, app_name or target_path.name)
        validate_and_fix_pyproject(target_path)

        if not use_linters:
            disable_linters(target_path)

        if template_name == "static-landing":
            apply_landing_blueprint(target_path, content_path, theme)

        setup_secrets(target_path, secrets_strategy)
        inject_features(
            target_path, 
            template_name, 
            with_commerce, 
            with_tunnel, 
            with_landing,
            with_admin,
            with_sqlite,
            with_ingestor,
            with_auth,
            with_merchant_dashboard,
            sandbox=with_sandbox,
            payment=with_payment,
            use_ast_injection=use_ast_injection,
            seo_analyzer=with_seo_analyzer,
        )

        # Optional Sidekiq swap (rails-api only)
        if with_sidekiq and template_name in ("rails-api", "rails-fullstack"):
            inject_sidekiq(target_path)

        # Optional UI library injection (react-client only)
        if with_ui_lib and template_name == "react-client":
            from foundry.actions.generation_utils import VALID_UI_LIBS
            if with_ui_lib.lower() not in VALID_UI_LIBS:
                console.print(f"[red]❌ Unknown UI library '{with_ui_lib}'. Valid options: {', '.join(sorted(VALID_UI_LIBS))}[/red]")
                raise SystemExit(1)
            inject_ui_lib(target_path, with_ui_lib)

        regenerate_poetry_lock(target_path)

        # Write project metadata to track generation state and injected features
        # Phase 3 Metadata tracking
        features_injected = []
        if with_commerce: features_injected.append("commerce")
        if with_payment: features_injected.append("payment")
        if with_tunnel: features_injected.append("tunnel")
        if with_landing: features_injected.append("landing")
        if with_admin: features_injected.append("nicegui-admin")
        if with_sqlite: features_injected.append("sqlite-local")
        if with_ingestor: features_injected.append("data-ingestor")
        if with_auth: features_injected.append("auth")
        if with_seo_analyzer: features_injected.append("seo-analyzer")
        if with_merchant_dashboard: features_injected.append("merchant-dashboard")
        if with_sandbox: features_injected.append("sandbox")
        if with_ui_lib: features_injected.append(f"ui-lib:{with_ui_lib}")

        tracker = MetadataTracker(project_path=target_path)
        tracker.init_project(
            template_name=template_name,
            version="1.0.0",  # Default for new installs
            features=features_injected,
            project_name=app_name or target_path.name
        )

        # Cleanup
        if template_name != "python-saas":
            features_dir = target_path / "features"
            if features_dir.exists():
                shutil.rmtree(features_dir)

        # GitHub Repo Initialization
        if github_config:
            initialize_github_repo(target_path, github_config)

        console.print(f"[bold green]Success! Project created at {target_path}[/bold green]")
        if ALPHA_FEEDBACK_FORM_ENABLED:
            feedback_url = get_feedback_link()
            if feedback_url:
                console.print(
                    f"\n[bold blue]💬 Share feedback[/bold blue] to help us improve → [link={feedback_url}]"
                    f"Rate Your Experience[/link]"
                )

    except Exception as e:
        log_event("GENERATE_ERROR", str(e))
        console.print(f"[bold red]Deployment failed:[/bold red] {e}")
