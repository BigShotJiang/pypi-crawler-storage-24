"""
Project Validator - Validates user-generated projects, not template sources.

Checks:
- Dependencies installed (pip, npm, bundle)
- Docker buildable
- Environment variables configured
- Feature injections valid
- Database setup
- Third-party integrations
"""

import subprocess
import json
from pathlib import Path
from typing import List
from dataclasses import dataclass
from enum import Enum

from rich.console import Console
from rich.panel import Panel

console = Console()


class CheckStatus(Enum):
    """Status of a validation check."""
    PASS = "✓"
    FAIL = "✗"
    WARN = "⚠"
    SKIP = "○"


@dataclass
class ValidationResult:
    """Result of a single validation check."""
    name: str
    status: CheckStatus
    message: str = ""
    
    def __str__(self) -> str:
        color_map = {
            CheckStatus.PASS: "green",
            CheckStatus.FAIL: "red",
            CheckStatus.WARN: "yellow",
            CheckStatus.SKIP: "dim",
        }
        color = color_map[self.status]
        return f"[{color}]{self.status.value}[/{color}] {self.name}"


class ProjectValidator:
    """Validates a user-generated project for readiness."""

    def __init__(self, project_path: Path = None):
        """Initialize validator for the given project path or current directory."""
        self.project_path = project_path or Path.cwd()
        self.results: List[ValidationResult] = []
        self.template_type = self._detect_template_type()

    def _detect_template_type(self) -> str:
        """Detect which template was used to generate this project."""
        # Look for signature files that indicate template type
        if (self.project_path / "pyproject.toml").exists():
            return "python-saas"
        elif (self.project_path / "package.json").exists():
            with open(self.project_path / "package.json") as f:
                config = json.load(f)
                if "next" in config.get("dependencies", {}):
                    return "next-js"
                return "react-client"
        elif (self.project_path / "Gemfile").exists():
            return "rails-api"
        return "unknown"

    def validate_all(self) -> bool:
        """Run all validation checks. Returns True if project is ready."""
        console.print(
            Panel(
                f"[bold cyan]Project Validation[/bold cyan]\n"
                f"[dim]Project: {self.project_path.name}[/dim]\n"
                f"[dim]Template: {self.template_type}[/dim]",
                style="cyan"
            )
        )
        console.print()

        # Run checks based on template type
        self._check_directory_structure()
        self._check_dependencies()
        self._check_docker()
        self._check_environment()
        self._check_features()
        
        # Print results
        self._print_results()
        
        # Return True if no failures
        return not any(r.status == CheckStatus.FAIL for r in self.results)

    def _check_directory_structure(self):
        """Validate basic project structure."""
        console.print("[bold]Project Structure[/bold]")
        
        # Must have Dockerfile
        if (self.project_path / "Dockerfile").exists():
            self.results.append(ValidationResult("Dockerfile", CheckStatus.PASS))
        else:
            self.results.append(ValidationResult("Dockerfile", CheckStatus.FAIL, "Missing Dockerfile"))

        # Must have .gitignore
        if (self.project_path / ".gitignore").exists():
            self.results.append(ValidationResult(".gitignore", CheckStatus.PASS))
        else:
            self.results.append(ValidationResult(".gitignore", CheckStatus.FAIL, "Missing .gitignore"))

        # Check for README
        if (self.project_path / "README.md").exists():
            self.results.append(ValidationResult("README.md", CheckStatus.PASS))
        else:
            self.results.append(ValidationResult("README.md", CheckStatus.WARN, "Missing README.md"))

    def _check_dependencies(self):
        """Check if dependencies are installed."""
        console.print("[bold]Dependencies[/bold]")
        
        if self.template_type == "python-saas":
            self._check_python_deps()
        elif self.template_type == "rails-api":
            self._check_ruby_deps()
        elif self.template_type in ["react-client", "next-js"]:
            self._check_node_deps()

    def _check_python_deps(self):
        """Check if Python dependencies are installed."""
        try:
            result = subprocess.run(
                ["pip", "list"],
                cwd=self.project_path,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            if result.returncode == 0:
                output = result.stdout.lower()
                has_fastapi = "fastapi" in output
                has_sqlalchemy = "sqlalchemy" in output
                
                if has_fastapi and has_sqlalchemy:
                    self.results.append(ValidationResult(
                        "pip dependencies installed",
                        CheckStatus.PASS
                    ))
                else:
                    self.results.append(ValidationResult(
                        "pip dependencies installed",
                        CheckStatus.FAIL,
                        "Missing core dependencies (fastapi, sqlalchemy)"
                    ))
            else:
                # H-16: non-zero returncode is a real failure, not a skip
                self.results.append(ValidationResult(
                    "pip dependencies installed",
                    CheckStatus.FAIL,
                    "pip command failed"
                ))
        except Exception as e:
            self.results.append(ValidationResult(
                "pip dependencies installed",
                CheckStatus.FAIL,
                str(e)
            ))

    def _check_ruby_deps(self):
        """Check if Ruby gems are installed."""
        try:
            result = subprocess.run(
                ["bundle", "check"],
                cwd=self.project_path,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            if result.returncode == 0:
                self.results.append(ValidationResult(
                    "bundle dependencies installed",
                    CheckStatus.PASS
                ))
            else:
                self.results.append(ValidationResult(
                    "bundle dependencies installed",
                    CheckStatus.WARN,
                    "Run: bundle install"
                ))
        except Exception as e:
            self.results.append(ValidationResult(
                "bundle dependencies installed",
                CheckStatus.FAIL,
                str(e)
            ))

    def _check_node_deps(self):
        """Check if npm/yarn dependencies are installed."""
        try:
            node_modules = self.project_path / "node_modules"
            
            if node_modules.exists():
                self.results.append(ValidationResult(
                    "npm dependencies installed",
                    CheckStatus.PASS
                ))
            else:
                self.results.append(ValidationResult(
                    "npm dependencies installed",
                    CheckStatus.WARN,
                    "Run: npm install"
                ))
        except Exception as e:
            self.results.append(ValidationResult(
                "npm dependencies installed",
                CheckStatus.FAIL,
                str(e)
            ))

    def _check_docker(self):
        """Check if Docker is configured and can build."""
        console.print("[bold]Docker[/bold]")
        
        dockerfile = self.project_path / "Dockerfile"
        if not dockerfile.exists():
            self.results.append(ValidationResult(
                "Docker build",
                CheckStatus.SKIP,
                "No Dockerfile"
            ))
            return

        try:
            result = subprocess.run(
                ["docker", "build", "--check", "."],
                cwd=self.project_path,
                capture_output=True,
                text=True,
                timeout=120
            )
            
            if result.returncode == 0:
                self.results.append(ValidationResult(
                    "Docker build",
                    CheckStatus.PASS
                ))
            else:
                error_line = result.stderr.strip().split("\n")[-1] if result.stderr else "Unknown error"
                self.results.append(ValidationResult(
                    "Docker build",
                    CheckStatus.FAIL,
                    error_line[:80]  # Truncate long error messages
                ))
        except subprocess.TimeoutExpired:
            self.results.append(ValidationResult(
                "Docker build",
                CheckStatus.FAIL,
                "Timeout (>5 minutes)"
            ))
        except Exception as e:
            self.results.append(ValidationResult(
                "Docker build",
                CheckStatus.FAIL,
                str(e)
            ))

    def _check_environment(self):
        """Check if environment variables are configured."""
        console.print("[bold]Environment[/bold]")
        
        env_file = self.project_path / ".env"
        env_example = self.project_path / ".env.example"
        
        if env_file.exists():
            self.results.append(ValidationResult(
                ".env file",
                CheckStatus.PASS
            ))
            
            # Check if it has required variables
            try:
                with open(env_file) as f:
                    content = f.read()
                
                required_vars = self._get_required_vars()
                missing_vars = [v for v in required_vars if f"{v}=" not in content]
                
                if missing_vars:
                    self.results.append(ValidationResult(
                        "All required env vars",
                        CheckStatus.WARN,
                        f"Missing: {', '.join(missing_vars)}"
                    ))
                else:
                    self.results.append(ValidationResult(
                        "All required env vars",
                        CheckStatus.PASS
                    ))
            except Exception as e:
                self.results.append(ValidationResult(
                    "Environment variables",
                    CheckStatus.FAIL,
                    str(e)
                ))
        elif env_example.exists():
            self.results.append(ValidationResult(
                ".env file",
                CheckStatus.WARN,
                "Run: cp .env.example .env and configure"
            ))
        else:
            self.results.append(ValidationResult(
                ".env file",
                CheckStatus.SKIP,
                "No .env or .env.example"
            ))

    def _get_required_vars(self) -> List[str]:
        """Get list of required environment variables based on template."""
        base_vars = ["DATABASE_URL", "PROJECT_NAME"]
        
        # Check what features are injected
        features_path = self.project_path / "features"
        if features_path.exists():
            if (features_path / "commerce").exists():
                base_vars.extend(["STRIPE_API_KEY", "SHOPIFY_WEBHOOK_SECRET"])
            if (features_path / "auth").exists():
                base_vars.extend(["JWT_SECRET", "OAUTH_CLIENT_ID"])
        
        return base_vars

    def _check_features(self):
        """Check if injected features are valid."""
        console.print("[bold]Features[/bold]")
        
        features_path = self.project_path / "features"
        
        if not features_path.exists():
            self.results.append(ValidationResult(
                "Feature injection directory",
                CheckStatus.SKIP,
                "No features/ directory (base template)"
            ))
            return

        injected = []
        
        if (features_path / "commerce").exists():
            injected.append("Commerce")
        if (features_path / "auth").exists():
            injected.append("Auth")
        if (features_path / "admin").exists():
            injected.append("Admin")
        if (features_path / "tunnel").exists():
            injected.append("Tunnel")
        
        if injected:
            self.results.append(ValidationResult(
                "Features injected",
                CheckStatus.PASS,
                ", ".join(injected)
            ))
        else:
            self.results.append(ValidationResult(
                "Features directory",
                CheckStatus.WARN,
                "Empty features/ directory"
            ))

    def _print_results(self):
        """Print validation results in a table."""
        console.print("[bold]Validation Results[/bold]")
        console.print()
        
        # Print each result
        for result in self.results:
            console.print(f"  {result}")
        
        console.print()
        
        # Summary
        passes = sum(1 for r in self.results if r.status == CheckStatus.PASS)
        fails = sum(1 for r in self.results if r.status == CheckStatus.FAIL)
        warns = sum(1 for r in self.results if r.status == CheckStatus.WARN)
        
        if fails == 0:
            status_color = "green"
            status_msg = "✓ Ready to run"
        else:
            status_color = "red"
            status_msg = f"✗ {fails} issue(s) to fix"
        
        summary = f"[{status_color}]{status_msg}[/{status_color}]"
        if warns > 0:
            summary += f" ([yellow]{warns} warning(s)[/yellow])"
        
        console.print(f"  {summary}")
        console.print()
        
        if fails == 0:
            console.print("  [green]To get started:[/green]")
            console.print("  $ sscli dev")
        else:
            console.print("  [red]Issues to fix before running:[/red]")
            for result in self.results:
                if result.status == CheckStatus.FAIL and result.message:
                    console.print(f"  • {result.name}: {result.message}")
