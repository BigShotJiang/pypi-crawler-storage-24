from pathlib import Path
import json
import re
import subprocess
from rich.panel import Panel
from foundry.constants import console, TIER_HIERARCHY, PRICING_URL
from foundry.auth import get_current_license_info
from foundry.codemods.toml_codemods import RemoveToolSectionsCM, RemovePythonDependencyCM
from foundry.telemetry import log_event


def check_feature_tier_access(feature_key: str) -> bool:
    """Check if the user has the required tier to use a specific injectable feature.

    Shows a clear upgrade prompt if the feature requires a higher tier.
    Returns True if access is granted, False otherwise.
    """
    from foundry.utils import is_internal_dev
    from foundry.constants import FEATURES_REGISTRY, PRICING_URL
    if is_internal_dev():
        return True

    feature_meta = FEATURES_REGISTRY.get(feature_key)
    if not feature_meta:
        # Unknown feature — allow (will fail at injection time)
        return True

    required_tier = feature_meta.get("tier", "free")
    user_info = get_current_license_info(verify=True)
    user_tier = user_info.get("tier", "free")

    if TIER_HIERARCHY.get(user_tier, 0) < TIER_HIERARCHY.get(required_tier.lower(), 0):
        feature_name = feature_meta.get("name", feature_key)
        console.print(
            Panel(
                f"[bold red]Feature Locked[/bold red]\n\n"
                f"The [cyan]--with-{feature_key}[/cyan] flag ([bold]{feature_name}[/bold]) requires a "
                f"[bold yellow]{required_tier.upper()}[/bold yellow] license.\n"
                f"Your current tier is: [bold white]{user_tier.upper()}[/bold white].\n\n"
                f"[dim]ALPHA tier can access templates but not injectable PRO features "
                f"(auth, commerce, admin, tunnel).[/dim]\n\n"
                f"Upgrade at: [link={PRICING_URL}]{PRICING_URL}[/link]",
                title="PRO Feature Required",
                border_style="yellow",
            )
        )
        return False
    return True


def check_tier_access(template_name: str, required_tier: str) -> bool:
    """Check if the user has the required tier for a template.
    
    For ALPHA users, also checks per-template access grants.
    """
    from foundry.utils import is_internal_dev
    if is_internal_dev():
        return True

    # verify=True: live check against license server so tier upgrades take effect
    # immediately without requiring logout/login. Falls back to cache if server unreachable.
    user_info = get_current_license_info(verify=True)
    user_tier = user_info.get("tier", "free")
    user_id = user_info.get("user_id")

    # Check tier hierarchy first
    if TIER_HIERARCHY.get(user_tier, 0) < TIER_HIERARCHY.get(required_tier.lower(), 0):
        console.print(
            Panel(
                f"[bold red]Access Denied[/bold red]\n\n"
                f"The template [cyan]{template_name}[/cyan] requires a [bold yellow]{required_tier.upper()}[/bold yellow] license.\n"
                f"Your current tier is: [bold white]{user_tier.upper()}[/bold white].\n\n"
                f"Upgrade your license at: [link={PRICING_URL}]{PRICING_URL}[/link]",
                title="License Requirement",
                border_style="red",
            )
        )
        log_event("GENERATE_FORBIDDEN", f"tier_check template={template_name} user_tier={user_tier} required={required_tier}")
        return False
    return True


def check_payment_entitlement() -> bool:
    """Check if the user has the payment feature unlocked (paid-once $49 unlock).
    
    This is separate from tier checks — free users CAN have this unlocked.
    """
    from foundry.utils import is_internal_dev
    from foundry.constants import PRICING_URL
    if is_internal_dev():
        return True

    user_info = get_current_license_info(verify=True)
    unlocked = user_info.get("payment_feature_unlocked", False)

    if not unlocked:
        unlock_url = f"{PRICING_URL}#payment-unlock"
        console.print(
            Panel(
                "[bold red]Payment Feature Not Unlocked[/bold red]\n\n"
                "The [cyan]--with-payment[/cyan] flag requires a [bold yellow]$49 one-time unlock[/bold yellow].\n"
                "This is a separate purchase from your subscription — unlock once, inject anytime.\n\n"
                f"Unlock at: [link={unlock_url}]{unlock_url}[/link]",
                title="Payment Feature Gate",
                border_style="red",
            )
        )
        log_event("PAYMENT_FEATURE_FORBIDDEN", "payment_unlock_required")
        return False
    return True


def apply_landing_blueprint(path: Path, content_path: str = None, theme: str = None):
    """Apply blueprint configuration to static-landing template."""
    blueprint_file = path / "blueprint.json"
    if not blueprint_file.exists():
        return

    try:
        blueprint_data = json.loads(blueprint_file.read_text(encoding="utf-8"))
        
        # Override with custom content if provided
        if content_path:
            custom_content_file = Path(content_path).resolve()
            project_resolved = Path(path).resolve()
            # Only allow files within the project directory
            if not custom_content_file.is_relative_to(project_resolved):
                raise ValueError(
                    f"content_path must be within the project directory. Got: {content_path!r}"
                )
            if custom_content_file.is_symlink():
                raise ValueError("content_path must not be a symlink")
            if custom_content_file.exists():
                custom_data = json.loads(custom_content_file.read_text(encoding="utf-8"))
                blueprint_data.update(custom_data)
                console.print(f"   - Applied custom content blueprint from {content_path}")
            else:
                console.print(f"   [yellow]⚠️  Custom content file {content_path} not found.[/yellow]")

        # Override theme if provided
        if theme:
            blueprint_data["theme"] = theme
            console.print(f"   - Applied theme: {theme}")

        blueprint_file.write_text(json.dumps(blueprint_data, indent=2), encoding="utf-8")
        
    except Exception as e:
        console.print(f"   [yellow]⚠️  Failed to apply landing blueprint: {e}[/yellow]")


_APP_NAME_RE = re.compile(r'^[a-zA-Z0-9][a-zA-Z0-9_\-]{0,63}$')


def inject_metadata(path: Path, template: str, app_name: str):
    """
    Inject project name into configuration files.
    
    This is the first step of project initialization, renaming template placeholders.
    """
    if not _APP_NAME_RE.match(app_name):
        raise ValueError(
            f"Invalid app_name {app_name!r}: must match ^[a-zA-Z0-9][a-zA-Z0-9_\\-]{{0,63}}$"
        )
    console.print(f"   - Injecting name '{app_name}' into configuration...")
    files_to_touch = [
        path / "package.json",
        path / "pyproject.toml",
        path / "Gemfile",
        path / "README.md",
        path / ".env.example",
        path / "astro.config.mjs",
    ]
    for f in files_to_touch:
        if f.exists():
            try:
                content = f.read_text(encoding="utf-8")
                new_content = content.replace(f"{template}", app_name)
                # Capitalized version for internal class names or readmes
                new_content = new_content.replace("StackApp", app_name.capitalize())
                f.write_text(new_content, encoding="utf-8")
            except Exception as e:
                console.print(f"   [yellow]⚠️  Failed to inject metadata into {f.name}: {e}[/yellow]")


def disable_linters(path: Path):
    """Remove linter tools and dependencies from the project."""
    pyproject = path / "pyproject.toml"
    if pyproject.exists():
        console.print("   - Removing Ruff/MyPy configurations...")
        try:
            # Use toml-based codemod for clean removal (formatting-aware)
            codemod = RemoveToolSectionsCM(sections=["ruff", "mypy"])
            codemod.apply(pyproject)
            
            # Also remove dependencies
            dep_codemod = RemovePythonDependencyCM(dependencies=["ruff", "mypy"])
            dep_codemod.execute(pyproject)
        except Exception as e:
            console.print(f"   [yellow]⚠️  Failed to disable linters in pyproject.toml: {e}[/yellow]")

    gemfile = path / "Gemfile"
    if gemfile.exists():
        try:
            content = gemfile.read_text(encoding="utf-8")
            new_content = content.replace("gem 'rubocop'", "# gem 'rubocop'").replace("gem 'rubocop-rails'", "# gem 'rubocop-rails'")
            gemfile.write_text(new_content, encoding="utf-8")
            console.print("   - Commented out Rubocop in Gemfile")
        except Exception as e:
            console.print(f"   [yellow]⚠️  Failed to disable linters in Gemfile: {e}[/yellow]")


def regenerate_poetry_lock(path: Path):
    """Regenerate poetry.lock to reflect any manual file changes (like dependency removal)."""
    if not (path / "pyproject.toml").exists() or not (path / "poetry.lock").exists():
        return
        
    console.print("   - Regenerating poetry.lock...")
    try:
        # Check if poetry is available
        subprocess.run(["poetry", "--version"], capture_output=True, check=True)
        
        result = subprocess.run(
            ["poetry", "lock", "--no-update"], 
            cwd=str(path), 
            capture_output=True, 
            text=True, 
            timeout=120
        )
        if result.returncode == 0:
            console.print("   - poetry.lock regenerated successfully")
        else:
            console.print(f"   [yellow]⚠️  Poetry lock failed: {result.stderr.strip()}[/yellow]")
    except (subprocess.CalledProcessError, FileNotFoundError):
        console.print("   [yellow]⚠️  Poetry not found, skipping lock regeneration.[/yellow]")
    except Exception as e:
        console.print(f"   [yellow]⚠️  Unexpected error regenerating poetry.lock: {str(e)}[/yellow]")


def validate_and_fix_pyproject(path: Path):
    """Validate pyproject.toml and fix common formatting issues manually."""
    pyproject = path / "pyproject.toml"
    if not pyproject.exists():
        return
        
    try:
        # Fallback to simple correction if tomlkit fails or for non-standard repairs
        content = pyproject.read_text(encoding="utf-8")
        fixed_lines = []
        in_tool_poetry = False
        in_dependencies_section = False
        has_version = False
        
        for line in content.splitlines():
            stripped = line.strip()
            
            # Detect sections
            if stripped.startswith("[tool.poetry]"):
                in_tool_poetry = True
                in_dependencies_section = False
            elif stripped.startswith("[tool.poetry.dependencies]"):
                in_tool_poetry = False
                in_dependencies_section = True
            elif stripped.startswith("["):
                in_tool_poetry = False
                in_dependencies_section = False

            # Check for version in [tool.poetry]
            if in_tool_poetry and stripped.startswith("version ="):
                has_version = True
                if "=" in stripped:
                    key, val = stripped.split("=", 1)
                    val_clean = val.strip().strip('"').strip("'")
                    if not val_clean:
                        line = 'version = "0.1.0"'
            
            if in_dependencies_section and " = " in line and not stripped.startswith("#"):
                key, value = line.split(" = ", 1)
                key, value = key.strip(), value.strip()
                if value and not value.startswith(('"', "'", "{", "[")):
                    if value[0].isnumeric() or value[0] in "^~<>=!":
                        value = f'"{value}"'
                        line = f"{key} = {value}"
            fixed_lines.append(line)
        
        # Ensure version exists in [tool.poetry] if it was missing entirely
        if in_tool_poetry and not has_version:
            for idx, line in enumerate(fixed_lines):
                if line.strip() == "[tool.poetry]":
                    fixed_lines.insert(idx + 1, 'version = "0.1.0"')
                    break

        fixed_content = "\n".join(fixed_lines) + "\n"
        pyproject.write_text(fixed_content, encoding="utf-8")
        console.print("   - Validated pyproject.toml structure & versioning")
    except Exception as e:
        console.print(f"   [yellow]⚠️  Could not validate pyproject.toml: {e}[/yellow]")


SIDEKIQ_YML = """\
:concurrency: 5
:queues:
  - [critical, 3]
  - [default, 2]
  - [low, 1]
:max_retries: 3
"""

PROCFILE_DEV = """\
web: bin/rails s -p 3000
worker: bundle exec sidekiq -c 5
"""

JOB_QUEUE_RB = """\
# frozen_string_literal: true

module Ports
  # JobQueue defines the interface for enqueuing background jobs.
  # Infrastructure adapters (e.g. SidekiqAdapter) implement this interface;
  # domain use-cases depend only on this port, never on Sidekiq directly.
  module JobQueue
    # Enqueue a job to run as soon as possible.
    #
    # @param job_class [Class] The Sidekiq worker class
    # @param args [Array]     Arguments forwarded to #perform
    # @return [void]
    def self.enqueue(job_class, *args)
      raise NotImplementedError, "#{self} must implement .enqueue(job_class, *args)"
    end

    # Enqueue a job to run at a specific time.
    #
    # @param job_class   [Class] The Sidekiq worker class
    # @param perform_at  [Time]  Scheduled execution time
    # @param args        [Array] Arguments forwarded to #perform
    # @return [void]
    def self.enqueue_at(job_class, perform_at, *args)
      raise NotImplementedError, "#{self} must implement .enqueue_at(job_class, perform_at, *args)"
    end
  end
end
"""


def inject_sidekiq(project_path: Path) -> None:
    """Swap solid_queue for Sidekiq in a Rails project generated from rails-api/rails-fullstack.

    Changes applied:
      - Replaces ``gem 'solid_queue'`` with ``gem 'sidekiq'`` in Gemfile
      - Creates ``config/sidekiq.yml`` with sensible defaults
      - Creates ``Procfile.dev`` for local dev (web + worker)
    """
    gemfile = project_path / "Gemfile"
    if not gemfile.exists():
        # Try one level deeper (template archives put code in a subdirectory)
        candidates = list(project_path.glob("*/Gemfile"))
        if candidates:
            gemfile = candidates[0]
            project_path = gemfile.parent

    if gemfile.exists():
        content = gemfile.read_text(encoding="utf-8")
        if "solid_queue" in content:
            content = content.replace("gem 'solid_queue'", "gem 'sidekiq', '~> 7.0'")
            gemfile.write_text(content, encoding="utf-8")
            console.print("   - [green]✓[/green] Swapped solid_queue → sidekiq in Gemfile")
        elif "sidekiq" not in content:
            # Append sidekiq if neither gem is present
            with open(gemfile, "a", encoding="utf-8") as f:
                f.write("\ngem 'sidekiq', '~> 7.0'\n")
            console.print("   - [green]✓[/green] Added sidekiq to Gemfile")
        else:
            console.print("   - [dim]sidekiq already present in Gemfile, no change needed[/dim]")

        # Add sidekiq-cron if not already present
        content = gemfile.read_text(encoding="utf-8")
        if "sidekiq-cron" not in content:
            with open(gemfile, "a", encoding="utf-8") as f:
                f.write("gem 'sidekiq-cron', '~> 2.0'\n")
            console.print("   - [green]✓[/green] Added sidekiq-cron to Gemfile")
        else:
            console.print("   - [dim]sidekiq-cron already present in Gemfile[/dim]")

    # Inject config.active_job.queue_adapter = :sidekiq into config/application.rb
    app_rb = project_path / "config" / "application.rb"
    if app_rb.exists():
        app_content = app_rb.read_text(encoding="utf-8")
        adapter_line = "    config.active_job.queue_adapter = :sidekiq"
        if adapter_line not in app_content:
            import re as _re
            # Insert after the first line inside class Application < Rails::Application
            pattern = r"(class Application < Rails::Application\n)"
            replacement = r"\1" + adapter_line + "\n"
            new_content = _re.sub(pattern, replacement, app_content, count=1)
            if new_content != app_content:
                app_rb.write_text(new_content, encoding="utf-8")
                console.print("   - [green]✓[/green] Set config.active_job.queue_adapter = :sidekiq in config/application.rb")
            else:
                console.print("   - [yellow]⚠[/yellow] Could not locate Application class block in config/application.rb")
        else:
            console.print("   - [dim]queue_adapter already set in config/application.rb[/dim]")
    else:
        console.print("   - [dim]config/application.rb not found, skipping queue_adapter injection[/dim]")

    # Write config/sidekiq.yml
    config_dir = project_path / "config"
    config_dir.mkdir(parents=True, exist_ok=True)
    sidekiq_yml = config_dir / "sidekiq.yml"
    sidekiq_yml.write_text(SIDEKIQ_YML, encoding="utf-8")
    console.print("   - [green]✓[/green] Created config/sidekiq.yml")

    # Write / patch Procfile.dev — always ensure both web: and worker: entries exist
    procfile = project_path / "Procfile.dev"
    if not procfile.exists():
        procfile.write_text(PROCFILE_DEV, encoding="utf-8")
        console.print("   - [green]✓[/green] Created Procfile.dev")
    else:
        existing = procfile.read_text(encoding="utf-8")
        patched = existing
        changed = False
        if "web:" not in existing:
            patched = "web: bin/rails s -p 3000\n" + patched
            changed = True
        if "worker:" not in existing:
            patched = patched.rstrip("\n") + "\nworker: bundle exec sidekiq -c 5\n"
            changed = True
        if changed:
            procfile.write_text(patched, encoding="utf-8")
            console.print("   - [green]✓[/green] Patched Procfile.dev (added missing web:/worker: entries)")
        else:
            console.print("   - [dim]Procfile.dev already has web: and worker: entries[/dim]")

    # Create app/domain/ports/job_queue.rb (Ports::JobQueue interface)
    ports_dir = project_path / "app" / "domain" / "ports"
    ports_dir.mkdir(parents=True, exist_ok=True)
    job_queue_rb = ports_dir / "job_queue.rb"
    if not job_queue_rb.exists():
        job_queue_rb.write_text(JOB_QUEUE_RB, encoding="utf-8")
        console.print("   - [green]✓[/green] Created app/domain/ports/job_queue.rb")
    else:
        console.print("   - [dim]app/domain/ports/job_queue.rb already exists[/dim]")



# ---------------------------------------------------------------------------
# UI Library injection (react-client only)
# ---------------------------------------------------------------------------

VALID_UI_LIBS = {"shadcn", "chakra", "mui", "antd", "tailwind"}

_SHADCN_COMPONENTS_JSON = """{
  "$schema": "https://ui.shadcn.com/schema.json",
  "style": "default",
  "rsc": false,
  "tsx": true,
  "tailwind": {
    "config": "tailwind.config.js",
    "css": "src/index.css",
    "baseColor": "slate",
    "cssVariables": true
  },
  "aliases": {
    "components": "@/components",
    "utils": "@/lib/utils"
  }
}
"""

_SHADCN_UTILS_TS = """import { clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: Parameters<typeof clsx>) {
  return twMerge(clsx(inputs));
}
"""

_SHADCN_BUTTON_TSX = """import * as React from "react";
import { cn } from "@/lib/utils";

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "default" | "outline" | "ghost";
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = "default", ...props }, ref) => {
    const base =
      "inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none disabled:pointer-events-none disabled:opacity-50 px-4 py-2";
    const variants = {
      default: "bg-primary text-primary-foreground hover:bg-primary/90",
      outline: "border border-input bg-background hover:bg-accent",
      ghost: "hover:bg-accent hover:text-accent-foreground",
    };
    return (
      <button
        ref={ref}
        className={cn(base, variants[variant], className)}
        {...props}
      />
    );
  }
);
Button.displayName = "Button";
export { Button };
"""


def _patch_package_json(project_path: Path, add_deps: dict, remove_deps: list = None) -> None:
    """Add/remove entries in package.json dependencies. Creates the file if missing."""
    import json as _json
    pkg = project_path / "package.json"
    if not pkg.exists():
        # Try one level deeper (archive layout)
        candidates = list(project_path.glob("*/package.json"))
        if candidates:
            pkg = candidates[0]
    if not pkg.exists():
        console.print("   - [yellow]⚠[/yellow] package.json not found — skipping dependency update")
        return
    data = _json.loads(pkg.read_text(encoding="utf-8"))
    deps = data.setdefault("dependencies", {})
    deps.update(add_deps)
    if remove_deps:
        for key in remove_deps:
            deps.pop(key, None)
    pkg.write_text(_json.dumps(data, indent=2) + "\n", encoding="utf-8")


def _inject_shadcn(project_path: Path) -> None:
    # 1. Add packages to package.json
    _patch_package_json(project_path, {
        "clsx": "^2.1.1",
        "tailwind-merge": "^2.3.0",
        "class-variance-authority": "^0.7.0",
        "@radix-ui/react-slot": "^1.0.2",
    })
    console.print("   - [green]✓[/green] Added shadcn/ui packages to package.json")

    # 2. components.json at project root
    components_json = project_path / "components.json"
    if not components_json.exists():
        components_json.write_text(_SHADCN_COMPONENTS_JSON, encoding="utf-8")
        console.print("   - [green]✓[/green] Created components.json")
    else:
        console.print("   - [dim]components.json already exists[/dim]")

    # 3. src/lib/utils.ts
    lib_dir = project_path / "src" / "lib"
    lib_dir.mkdir(parents=True, exist_ok=True)
    utils_ts = lib_dir / "utils.ts"
    if not utils_ts.exists():
        utils_ts.write_text(_SHADCN_UTILS_TS, encoding="utf-8")
        console.print("   - [green]✓[/green] Created src/lib/utils.ts (cn helper)")
    else:
        console.print("   - [dim]src/lib/utils.ts already exists[/dim]")

    # 4. src/components/ui/button.tsx
    ui_dir = project_path / "src" / "components" / "ui"
    ui_dir.mkdir(parents=True, exist_ok=True)
    button_tsx = ui_dir / "button.tsx"
    if not button_tsx.exists():
        button_tsx.write_text(_SHADCN_BUTTON_TSX, encoding="utf-8")
        console.print("   - [green]✓[/green] Created src/components/ui/button.tsx")
    else:
        console.print("   - [dim]src/components/ui/button.tsx already exists[/dim]")


def _inject_chakra(project_path: Path) -> None:
    _patch_package_json(project_path, {
        "@chakra-ui/react": "^3.3.1",
        "@emotion/react": "^11.13.5",
    })
    console.print("   - [green]✓[/green] Added Chakra UI packages to package.json")

    main_jsx = project_path / "src" / "main.jsx"
    if main_jsx.exists():
        content = main_jsx.read_text(encoding="utf-8")
        if "ChakraProvider" not in content:
            content = 'import { ChakraProvider } from "@chakra-ui/react"\n' + content
            content = content.replace(
                "<App />",
                "<ChakraProvider><App /></ChakraProvider>",
            )
            main_jsx.write_text(content, encoding="utf-8")
            console.print("   - [green]✓[/green] Wrapped app with ChakraProvider in src/main.jsx")
        else:
            console.print("   - [dim]ChakraProvider already in src/main.jsx[/dim]")
    else:
        console.print("   - [yellow]⚠[/yellow] src/main.jsx not found — skipping provider wrap")


def _inject_mui(project_path: Path) -> None:
    _patch_package_json(project_path, {
        "@mui/material": "^6.4.7",
        "@emotion/react": "^11.13.5",
        "@emotion/styled": "^11.13.5",
        "@mui/icons-material": "^6.4.7",
    })
    console.print("   - [green]✓[/green] Added MUI packages to package.json")

    main_jsx = project_path / "src" / "main.jsx"
    if main_jsx.exists():
        content = main_jsx.read_text(encoding="utf-8")
        if "ThemeProvider" not in content:
            content = (
                'import { ThemeProvider, createTheme, CssBaseline } from "@mui/material"\n'
                + content
            )
            content = content.replace(
                "<App />",
                '<ThemeProvider theme={createTheme()}><CssBaseline /><App /></ThemeProvider>',
            )
            main_jsx.write_text(content, encoding="utf-8")
            console.print("   - [green]✓[/green] Wrapped app with MUI ThemeProvider in src/main.jsx")
        else:
            console.print("   - [dim]ThemeProvider already in src/main.jsx[/dim]")
    else:
        console.print("   - [yellow]⚠[/yellow] src/main.jsx not found — skipping provider wrap")


def _inject_antd(project_path: Path) -> None:
    _patch_package_json(project_path, {"antd": "^5.24.3"})
    console.print("   - [green]✓[/green] Added Ant Design to package.json")

    main_jsx = project_path / "src" / "main.jsx"
    if main_jsx.exists():
        content = main_jsx.read_text(encoding="utf-8")
        if "antd" not in content:
            content = '// antd: import components from "antd" — no global provider required\n' + content
            main_jsx.write_text(content, encoding="utf-8")
            console.print("   - [green]✓[/green] Added antd usage note to src/main.jsx")
        else:
            console.print("   - [dim]antd already referenced in src/main.jsx[/dim]")
    else:
        console.print("   - [yellow]⚠[/yellow] src/main.jsx not found — skipping antd note")


def inject_ui_lib(project_path: Path, lib: str) -> None:
    """Inject a UI component library into a react-client project.

    Supported values: shadcn | chakra | mui | antd | tailwind (no-op baseline)
    """
    lib = lib.strip().lower()
    if lib not in VALID_UI_LIBS:
        raise ValueError(
            f"Unknown UI library '{lib}'. Valid options: {', '.join(sorted(VALID_UI_LIBS))}"
        )
    if lib == "tailwind":
        console.print("   - [dim]tailwind is the default baseline — no additional setup needed[/dim]")
        return

    console.print(f"\n[bold]Injecting UI library:[/bold] {lib}")

    dispatchers = {
        "shadcn": _inject_shadcn,
        "chakra": _inject_chakra,
        "mui": _inject_mui,
        "antd": _inject_antd,
    }
    dispatchers[lib](project_path)
