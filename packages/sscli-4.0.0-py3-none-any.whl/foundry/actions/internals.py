import datetime
import json
import re
from pathlib import Path
from typing import Any
from rich.markup import escape


SESSION_LINE_RE = re.compile(
    r"^\[(?P<timestamp>[^\]]+)\]\s+(?P<event>[A-Z0-9_]+):\s*(?P<details>.*)$"
)
TEMPLATE_RE = re.compile(r"Template:\s*([^,]+)")
APP_RE = re.compile(r"App:\s*([^,]+)")


def parse_session_log(log_path: Path) -> list[dict[str, Any]]:
    if not log_path.exists():
        raise FileNotFoundError(f"Session log not found: {log_path}")

    events: list[dict[str, Any]] = []
    for raw_line in log_path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw_line.strip()
        if not line:
            continue

        match = SESSION_LINE_RE.match(line)
        if not match:
            events.append(
                {
                    "timestamp": None,
                    "event": "UNPARSED",
                    "details": line,
                    "template": None,
                    "app": None,
                    "is_failure": False,
                }
            )
            continue

        details = match.group("details")
        event = match.group("event")
        template_match = TEMPLATE_RE.search(details)
        app_match = APP_RE.search(details)

        events.append(
            {
                "timestamp": match.group("timestamp"),
                "event": event,
                "details": details,
                "template": template_match.group(1).strip() if template_match else None,
                "app": app_match.group(1).strip() if app_match else None,
                "is_failure": _is_failure_event(event),
            }
        )

    return events


def build_internals_report(events: list[dict[str, Any]], source_log: Path) -> dict[str, Any]:
    now = datetime.datetime.now(datetime.UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")

    total_events = len(events)
    failure_events = [event for event in events if event.get("is_failure")]
    generate_start = _count_events(events, "GENERATE_START")
    generate_success = _count_events(events, "GENERATE_SUCCESS")
    generate_errors = _count_events(events, "GENERATE_ERROR") + _count_events(events, "GENERATE_FAIL")

    by_template: dict[str, dict[str, int]] = {}
    for event in events:
        template = event.get("template") or "unknown"
        template_bucket = by_template.setdefault(
            template,
            {
                "total": 0,
                "starts": 0,
                "successes": 0,
                "failures": 0,
            },
        )
        template_bucket["total"] += 1
        if event.get("event") == "GENERATE_START":
            template_bucket["starts"] += 1
        elif event.get("event") == "GENERATE_SUCCESS":
            template_bucket["successes"] += 1
        if event.get("is_failure"):
            template_bucket["failures"] += 1

    return {
        "generated_at": now,
        "source_log": str(source_log),
        "summary": {
            "total_events": total_events,
            "failure_events": len(failure_events),
            "generate_start": generate_start,
            "generate_success": generate_success,
            "generate_errors": generate_errors,
        },
        "by_template": by_template,
        "failures": failure_events,
        "timeline": events,
    }


def write_internals_report(
    report: dict[str, Any],
    output_dir: Path,
    report_name: str = "internal-projects-failure-report",
) -> tuple[Path, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    json_path = output_dir / f"{report_name}.json"
    md_path = output_dir / f"{report_name}.md"

    json_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    md_path.write_text(_to_markdown(report), encoding="utf-8")
    return json_path, md_path


def generate_internals_report(session_log_path: Path, output_dir: Path) -> dict[str, Any]:
    events = parse_session_log(session_log_path)
    report = build_internals_report(events, session_log_path)
    json_path, md_path = write_internals_report(report, output_dir)
    return {
        "report": report,
        "json_path": json_path,
        "markdown_path": md_path,
    }


def _count_events(events: list[dict[str, Any]], event_name: str) -> int:
    return sum(1 for event in events if event.get("event") == event_name)


def _is_failure_event(event_name: str) -> bool:
    return "ERROR" in event_name or "FAIL" in event_name


def _to_markdown(report: dict[str, Any]) -> str:
    summary = report.get("summary", {})
    failures = report.get("failures", [])
    by_template = report.get("by_template", {})

    lines = [
        "# Internal-projects Failure Report",
        "",
        f"- Generated: {escape(str(report.get('generated_at')))}",
        f"- Source Log: {escape(str(report.get('source_log')))}",
        "",
        "## Summary",
        "",
        f"- Total events: {summary.get('total_events', 0)}",
        f"- Failure events: {summary.get('failure_events', 0)}",
        f"- Generate starts: {summary.get('generate_start', 0)}",
        f"- Generate successes: {summary.get('generate_success', 0)}",
        f"- Generate errors: {summary.get('generate_errors', 0)}",
        "",
        "## Template Breakdown",
        "",
        "| Template | Total | Starts | Successes | Failures |",
        "|---|---:|---:|---:|---:|",
    ]

    for template, stats in sorted(by_template.items()):
        lines.append(
            f"| {escape(str(template))} | {stats.get('total', 0)} | {stats.get('starts', 0)} | {stats.get('successes', 0)} | {stats.get('failures', 0)} |"
        )

    lines.extend(["", "## Failure Events", ""])
    if not failures:
        lines.append("- No failure events captured in the session log.")
    else:
        for failure in failures:
            lines.append(
                f"- [{escape(str(failure.get('timestamp')))}] `{escape(str(failure.get('event')))} ` - {escape(str(failure.get('details')))}"
            )

    lines.append("")
    return "\n".join(lines)
