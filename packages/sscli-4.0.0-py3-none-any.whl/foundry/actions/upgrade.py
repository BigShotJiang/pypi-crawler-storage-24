"""
Upgrade Command: Phase 3 of the Codemod Transformation Engine

Orchestrates the entire upgrade process, applying codemods in sequence to move
a project between template versions. Provides safe, guided mechanism with:
- Upgrade planning and preview (dry-run)
- Sequential codemod execution with error handling
- Automatic backup and rollback capability
- Metadata tracking with upgrade history
- Git integration for change tracking

Usage:
    sscli upgrade                               # Upgrade to latest
    sscli upgrade --to-version 2.4.0           # Upgrade to specific version
    sscli upgrade --dry-run                    # Preview changes
    sscli upgrade --interactive                # Step-by-step confirmation
"""

import subprocess
import shutil
import json
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional, List, Dict, Tuple, Any
from datetime import datetime
from uuid import uuid4

from foundry.constants import console
from foundry.codemods.delta_store import DeltaStore
from foundry.safety import GitGuard, GitStatusError
from foundry.safety import DryRunResult
from foundry.safety.verification_hook import VerificationHook


@dataclass
class UpgradeStep:
    """A single step in an upgrade sequence (one codemod)."""
    index: int
    codemod_id: str
    codemod_name: str
    from_version: str
    to_version: str
    description: str
    risk_level: str
    requires_manual_review: bool = False


@dataclass
class UpgradeHistory:
    """Record of an upgrade performed on a project."""
    timestamp: str
    from_version: str
    to_version: str
    steps_applied: int
    steps_successful: int
    status: str  # 'success', 'failed', 'partial', 'rolled_back'
    error_message: Optional[str] = None
    backup_path: Optional[str] = None
    codemod_ids: List[str] = field(default_factory=list)
    git_commit_sha: Optional[str] = None


@dataclass
class ProjectMetadata:
    """Project metadata including version and upgrade history."""
    current_version: str
    template_type: str
    created_at: str
    upgrade_history: List[UpgradeHistory] = field(default_factory=list)
    last_upgraded: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ProjectMetadata":
        """Create from dictionary."""
        if 'upgrade_history' in data:
            data['upgrade_history'] = [
                UpgradeHistory(**h) if isinstance(h, dict) else h
                for h in data.get('upgrade_history', [])
            ]
        return cls(**data)


class MetadataTracker:
    """Manages project metadata including version and upgrade history."""

    METADATA_FILE = ".seed-source-metadata.json"

    def __init__(self, project_path: Path):
        """Initialize metadata tracker for a project."""
        self.project_path = Path(project_path)
        self.metadata_file = self.project_path / self.METADATA_FILE

    def load(self) -> ProjectMetadata:
        """Load metadata from project."""
        if self.metadata_file.exists():
            try:
                data = json.loads(self.metadata_file.read_text())
                return ProjectMetadata.from_dict(data)
            except json.JSONDecodeError as e:
                console.print(f"[yellow]⚠️  Failed to parse metadata: {e}[/yellow]")
                raise ValueError(f"Invalid metadata file: {e}")

        # Try to infer from project files
        return self._infer_metadata()

    def _infer_metadata(self) -> ProjectMetadata:
        """Infer metadata from project structure."""
        template_type = self._detect_template_type()

        # Try to detect version from pyproject.toml, package.json, Gemfile, etc.
        current_version = self._detect_version()

        if not current_version:
            console.print("[red]❌ Could not detect project version[/red]")
            console.print("Please ensure your project has:")
            console.print("  - pyproject.toml with version (Python)")
            console.print("  - package.json with version (JavaScript/React)")
            console.print("  - Gemfile.lock or version info (Rails)")
            raise ValueError("Cannot detect project version")

        return ProjectMetadata(
            current_version=current_version,
            template_type=template_type,
            created_at=datetime.now().isoformat(),
            upgrade_history=[],
        )

    def _detect_template_type(self) -> str:
        """Detect template type from project structure."""
        # Check for key indicators
        if (self.project_path / "pyproject.toml").exists():
            content = (self.project_path / "pyproject.toml").read_text()
            if "poetry" in content:
                if (self.project_path / "src" / "core").exists():
                    return "python-saas"
        
        if (self.project_path / "package.json").exists():
            content = (self.project_path / "package.json").read_text()
            # Check for react-client: vite in package.json OR vite.config.js exists
            if ("vite" in content or (self.project_path / "vite.config.js").exists()):
                if (self.project_path / "src" / "components").exists():
                    return "react-client"
            if "astro" in content:
                return "static-landing"

        if (self.project_path / "Gemfile").exists():
            return "rails-api"

        return "unknown"

    def _detect_version(self) -> Optional[str]:
        """Detect current version from project files."""
        # Python projects
        pyproject = self.project_path / "pyproject.toml"
        if pyproject.exists():
            try:
                import re
                content = pyproject.read_text()
                match = re.search(r'version\s*=\s*["\']([^"\']+)["\']', content)
                if match:
                    return match.group(1)
            except Exception:
                pass

        # Node projects
        package_json = self.project_path / "package.json"
        if package_json.exists():
            try:
                data = json.loads(package_json.read_text())
                if "version" in data:
                    return data["version"]
            except Exception:
                pass

        return None

    def save(self, metadata: ProjectMetadata) -> None:
        """Save metadata to project."""
        self.metadata_file.write_text(
            json.dumps(metadata.to_dict(), indent=2),
            encoding="utf-8"
        )
        console.print(f"   - Metadata updated: {self.metadata_file}")

    def add_upgrade_history(
        self,
        metadata: ProjectMetadata,
        from_version: str,
        to_version: str,
        steps: List[str],
        success: bool,
        error: Optional[str] = None,
        backup_path: Optional[str] = None,
    ) -> None:
        """Record an upgrade in metadata."""
        history = UpgradeHistory(
            timestamp=datetime.now().isoformat(),
            from_version=from_version,
            to_version=to_version,
            steps_applied=len(steps),
            steps_successful=len(steps) if success else 0,
            status="success" if success else "failed",
            error_message=error,
            backup_path=backup_path,
            codemod_ids=steps,
        )
        metadata.upgrade_history.append(history)
        metadata.last_upgraded = history.timestamp
        if success:
            metadata.current_version = to_version


class UpgradeCommand:
    """Orchestrates the upgrade process for Seed & Source projects."""

    BACKUP_MANIFEST_FILE = ".backup_manifest.json"

    def __init__(self, project_path: Optional[Path] = None):
        """
        Initialize upgrade command.

        Args:
            project_path: Path to project root (defaults to current directory)
        """
        self.project_path = Path(project_path) if project_path else Path.cwd()
        self.delta_store = DeltaStore()
        self.metadata_tracker = MetadataTracker(self.project_path)
        self.backup_path: Optional[Path] = None
        self.git_guard = GitGuard(cwd=self.project_path)

    def plan_upgrade(
        self,
        to_version: Optional[str] = None,
        force: bool = False,
    ) -> Tuple[List[UpgradeStep], str]:
        """
        Plan an upgrade without executing it.

        Returns the sequence of codemods to apply and the target version.

        Args:
            to_version: Target version (defaults to latest)
            force: Skip git status checks

        Returns:
            Tuple of (list of UpgradeStep, target_version)

        Raises:
            ValueError: If upgrade path is invalid
            GitStatusError: If git state is unsafe (unless force=True)
        """
        # Validate git status
        if not force:
            try:
                self.git_guard.require_clean_status()
            except GitStatusError as e:
                console.print(f"[red]❌ {e}[/red]")
                raise

        # Load current metadata
        metadata = self.metadata_tracker.load()
        current_version = metadata.current_version

        console.print(f"[cyan]Current version:[/cyan] {current_version}")
        console.print(f"[cyan]Template:[/cyan] {metadata.template_type}")

        # Determine target version
        if to_version is None:
            to_version = self._get_latest_version(metadata.template_type)
            if not to_version:
                raise ValueError("Could not determine latest version")

        console.print(f"[cyan]Target version:[/cyan] {to_version}")

        # Get applicable codemods
        try:
            codemod_defs = self.delta_store.get_codemods_for_template(
                template=metadata.template_type,
                from_version=current_version,
                to_version=to_version,
            )
        except ValueError as e:
            raise ValueError(f"Cannot plan upgrade: {e}")

        if not codemod_defs:
            console.print(f"[yellow]ℹ️  No codemods needed. Already at version {to_version}[/yellow]")
            return [], to_version

        # Convert to upgrade steps
        steps = []
        for i, codemod_def in enumerate(codemod_defs):
            m = codemod_def.metadata
            step = UpgradeStep(
                index=i + 1,
                codemod_id=m.id,
                codemod_name=m.name,
                from_version=m.from_version,
                to_version=m.to_version,
                description=m.description,
                risk_level=m.risk_level,
                requires_manual_review=m.requires_manual_review,
            )
            steps.append(step)

        self._validate_strict_upgrade_graph(
            current_version=current_version,
            target_version=to_version,
            steps=steps,
        )

        return steps, to_version

    @staticmethod
    def _validate_strict_upgrade_graph(
        *,
        current_version: str,
        target_version: str,
        steps: List[UpgradeStep],
    ) -> None:
        """Require a contiguous, gap-free upgrade chain from current to target."""
        if not steps:
            return

        if steps[0].from_version != current_version:
            raise ValueError(
                "Invalid upgrade graph: first step does not start at current version "
                f"({steps[0].from_version} != {current_version})."
            )

        for prev, nxt in zip(steps, steps[1:]):
            if prev.to_version != nxt.from_version:
                raise ValueError(
                    "Invalid upgrade graph: non-contiguous codemod chain "
                    f"({prev.codemod_id}: {prev.to_version} -> {nxt.codemod_id}: {nxt.from_version})."
                )

        if steps[-1].to_version != target_version:
            raise ValueError(
                "Invalid upgrade graph: final step does not end at target version "
                f"({steps[-1].to_version} != {target_version})."
            )

    def execute_upgrade(
        self,
        to_version: Optional[str] = None,
        force: bool = False,
        only_safe: bool = False,
        interactive: bool = False,
        skip_verification: bool = False,
    ) -> bool:
        """
        Execute an upgrade, applying codemods in sequence.

        Args:
            to_version: Target version (defaults to latest)
            force: Skip git status checks
            interactive: Confirm each codemod before applying
            skip_verification: Skip post-upgrade verification

        Returns:
            True if successful, False otherwise
        """
        try:
            # Plan upgrade
            steps, target_version = self.plan_upgrade(
                to_version=to_version,
                force=force,
            )

            if not steps:
                console.print("[green]✓[/green] Already at target version")
                return True

            if only_safe:
                blocked_steps = [
                    step for step in steps
                    if step.requires_manual_review or step.risk_level.lower() in {"high", "critical"}
                ]
                if blocked_steps:
                    console.print("[red]❌ --only-safe blocked this upgrade plan.[/red]")
                    for step in blocked_steps:
                        console.print(
                            f"  - {step.codemod_name} ({step.risk_level}, manual_review={step.requires_manual_review})"
                        )
                    return False

            # Create backup
            metadata = self.metadata_tracker.load()
            self.backup_path = self._create_backup()
            console.print(f"[green]✓[/green] Backup created: {self.backup_path}")

            # Show upgrade plan
            console.print(f"\n[bold]Upgrade Plan ({len(steps)} steps):[/bold]")
            for step in steps:
                risk_color = {"low": "green", "medium": "yellow", "high": "red", "critical": "red"}.get(step.risk_level, "yellow")
                console.print(f"  {step.index}. [{risk_color}]{step.risk_level.upper()}[/{risk_color}] {step.codemod_name}")
                console.print(f"     {step.description}")

            # Confirm before proceeding
            if not force:
                console.print("\n[yellow]⚠️  This operation will modify your project files.[/yellow]")
                if not console.input("[cyan]Continue with upgrade? (yes/no)[/cyan]: ").strip().lower().startswith("y"):
                    console.print("[yellow]Upgrade cancelled[/yellow]")
                    return False

            # Apply codemods
            successful_codemods = []
            for step in steps:
                if step.requires_manual_review and not interactive:
                    console.print(
                        f"\n[red]❌ Codemod requires manual review: {step.codemod_name}[/red]"
                    )
                    console.print(
                        "[yellow]Re-run with --interactive and confirm the review prompt.[/yellow]"
                    )
                    console.print("[yellow]Rolling back to backup...[/yellow]")
                    self._rollback_to_backup()

                    self.metadata_tracker.add_upgrade_history(
                        metadata,
                        from_version=metadata.current_version,
                        to_version=target_version,
                        steps=successful_codemods,
                        success=False,
                        error=f"Manual review required for {step.codemod_name}",
                        backup_path=str(self.backup_path),
                    )
                    self.metadata_tracker.save(metadata)
                    return False

                if not self._apply_codemod(step, interactive=interactive):
                    # Rollback on failure
                    console.print(f"\n[red]❌ Codemod failed: {step.codemod_name}[/red]")
                    console.print("[yellow]Rolling back to backup...[/yellow]")
                    self._rollback_to_backup()
                    error_msg = f"Failed on {step.codemod_name}"

                    # Update metadata with failure
                    self.metadata_tracker.add_upgrade_history(
                        metadata,
                        from_version=metadata.current_version,
                        to_version=target_version,
                        steps=successful_codemods,
                        success=False,
                        error=error_msg,
                        backup_path=str(self.backup_path),
                    )
                    self.metadata_tracker.save(metadata)
                    return False

                successful_codemods.append(step.codemod_id)

            # Verify upgrade
            if not skip_verification:
                console.print("\n[cyan]Verifying upgrade...[/cyan]")
                verifier = VerificationHook(project_path=self.project_path, skip_verification=False)
                if not verifier.run_verification():
                    console.print("[red]❌ Verification failed[/red]")
                    console.print("[yellow]Rolling back to backup...[/yellow]")
                    self._rollback_to_backup()

                    self.metadata_tracker.add_upgrade_history(
                        metadata,
                        from_version=metadata.current_version,
                        to_version=target_version,
                        steps=successful_codemods,
                        success=False,
                        error="Verification failed",
                        backup_path=str(self.backup_path),
                    )
                    self.metadata_tracker.save(metadata)
                    return False

            # Commit changes
            if self.git_guard.is_git_repo():
                self._commit_upgrade(metadata.current_version, target_version)

            # Update metadata
            self.metadata_tracker.add_upgrade_history(
                metadata,
                from_version=metadata.current_version,
                to_version=target_version,
                steps=successful_codemods,
                success=True,
            )
            self.metadata_tracker.save(metadata)

            console.print(
                f"\n[green]✓[/green] Upgrade successful: "
                f"{metadata.current_version} → {target_version}"
            )
            return True

        except Exception as e:
            console.print(f"[red]❌ Upgrade failed: {str(e)}[/red]")
            if self.backup_path:
                console.print(f"[yellow]Backup available at: {self.backup_path}[/yellow]")
            return False

    def get_upgrade_steps(
        self,
        from_version: str,
        to_version: str,
    ) -> List[UpgradeStep]:
        """
        Get list of upgrade steps without executing.

        Args:
            from_version: Current version
            to_version: Target version

        Returns:
            List of UpgradeStep objects
        """
        metadata = self.metadata_tracker.load()

        try:
            codemod_defs = self.delta_store.get_codemods_for_template(
                template=metadata.template_type,
                from_version=from_version,
                to_version=to_version,
            )
        except ValueError:
            return []

        steps = []
        for i, codemod_def in enumerate(codemod_defs):
            m = codemod_def.metadata
            step = UpgradeStep(
                index=i + 1,
                codemod_id=m.id,
                codemod_name=m.name,
                from_version=m.from_version,
                to_version=m.to_version,
                description=m.description,
                risk_level=m.risk_level,
                requires_manual_review=m.requires_manual_review,
            )
            steps.append(step)

        return steps

    def preview_upgrade(
        self,
        to_version: Optional[str] = None,
        force: bool = False,
    ) -> Optional[DryRunResult]:
        """
        Preview upgrade with dry-run (no changes applied).

        Args:
            to_version: Target version
            force: Skip git checks

        Returns:
            DryRunResult with preview information
        """
        try:
            steps, target_version = self.plan_upgrade(
                to_version=to_version,
                force=force,
            )

            if not steps:
                return None

            console.print(f"\n[bold cyan]Preview ({len(steps)} codemods):[/bold cyan]")
            for step in steps:
                console.print(f"  {step.index}. {step.codemod_name}")

            # In a real implementation, would use DryRunEngine to preview actual changes
            # For now, just show the plan
            return DryRunResult()

        except Exception as e:
            console.print(f"[red]❌ Preview failed: {str(e)}[/red]")
            return None

    def rollback_upgrade(self, project_path: Optional[Path] = None) -> bool:
        """
        Rollback to the previous version.

        Args:
            project_path: Project path (defaults to current directory)

        Returns:
            True if successful
        """
        if project_path:
            self.project_path = Path(project_path)
            self.metadata_tracker = MetadataTracker(self.project_path)

        metadata = self.metadata_tracker.load()

        if not metadata.upgrade_history:
            console.print("[yellow]No upgrade history available[/yellow]")
            return False

        last_upgrade = metadata.upgrade_history[-1]

        if not last_upgrade.backup_path:
            console.print("[red]❌ No backup available for this upgrade[/red]")
            return False

        console.print(
            f"[cyan]Rolling back from {last_upgrade.to_version} "
            f"to {last_upgrade.from_version}...[/cyan]"
        )

        backup_path = Path(last_upgrade.backup_path).resolve()
        if not self._is_safe_backup_path(backup_path):
            console.print(f"[red]✗ Unsafe backup_path rejected: {backup_path}[/red]")
            return False
        if not backup_path.exists():
            console.print(f"[red]❌ Backup not found: {backup_path}[/red]")
            return False

        try:
            # Guard: refuse to wipe project if backup is empty
            if not any(backup_path.iterdir()):
                console.print("[red]✗ Backup directory is empty — refusing to wipe project.[/red]")
                return False
            if not self._validate_backup_snapshot(backup_path):
                return False

            # Remove current project files
            for item in self.project_path.iterdir():
                if item.name.startswith("."):
                    continue
                if item.is_dir():
                    shutil.rmtree(item)
                else:
                    item.unlink()

            # Restore from backup
            for item in backup_path.iterdir():
                if item.is_dir():
                    shutil.copytree(item, self.project_path / item.name)
                else:
                    shutil.copy2(item, self.project_path / item.name)

            console.print(f"[green]✓[/green] Rolled back to {last_upgrade.from_version}")

            # Update metadata
            metadata.current_version = last_upgrade.from_version
            self.metadata_tracker.save(metadata)

            return True

        except Exception as e:
            console.print(f"[red]❌ Rollback failed: {str(e)}[/red]")
            return False

    def _apply_codemod(self, step: UpgradeStep, interactive: bool = False) -> bool:
        """Apply a single codemod."""
        if interactive:
            console.print(f"\n[cyan]Codemod: {step.codemod_name}[/cyan]")
            console.print(f"  {step.description}")
            console.print(f"  Risk: {step.risk_level}")

            if not console.input("\n[cyan]Apply this codemod? (yes/no)[/cyan]: ").strip().lower().startswith("y"):
                console.print("[yellow]Skipped[/yellow]")
                return True

        console.print(f"  {step.codemod_name}...", end=" ")

        # TODO: Implement actual codemod execution
        # For now, just pretend it succeeded
        console.print("[green]✓[/green]")
        return True

    def _create_backup(self) -> Path:
        """Create a backup of the project."""
        backup_root = self.project_path.parent / ".upgrades"
        backup_root.mkdir(parents=True, exist_ok=True)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        backup_path = backup_root / f"backup_{timestamp}_{uuid4().hex[:8]}"
        backup_path.mkdir(parents=True, exist_ok=True)

        # Copy project to backup
        backed_up_files: List[str] = []
        for item in self.project_path.iterdir():
            if item.name.startswith(".") and item.name not in {".gitignore", ".env.example"}:
                continue
            if item.is_dir() and item.name in {"node_modules", "venv", ".venv", "__pycache__", ".pytest_cache"}:
                continue

            if item.is_dir():
                dest = backup_path / item.name
                if dest.exists():
                    shutil.rmtree(dest)
                shutil.copytree(item, dest)
                for child in dest.rglob("*"):
                    if child.is_file():
                        backed_up_files.append(str(child.relative_to(backup_path)))
            else:
                shutil.copy2(item, backup_path / item.name)
                backed_up_files.append(item.name)

        manifest_path = backup_path / self.BACKUP_MANIFEST_FILE
        manifest = {
            "created_at": datetime.now().isoformat(),
            "project_root": str(self.project_path.resolve()),
            "file_count": len(backed_up_files),
            "files": sorted(backed_up_files),
        }
        manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")

        return backup_path

    def _validate_backup_snapshot(self, backup_path: Path) -> bool:
        """Validate backup manifest and file presence before destructive restore."""
        manifest_path = backup_path / self.BACKUP_MANIFEST_FILE
        if not manifest_path.exists():
            # Backward compatibility for backups created before manifest support.
            return True

        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            console.print("[red]✗ Backup manifest is invalid JSON — refusing rollback.[/red]")
            return False

        expected = manifest.get("files")
        if not isinstance(expected, list) or not expected:
            console.print("[red]✗ Backup manifest missing file list — refusing rollback.[/red]")
            return False

        for rel in expected:
            rel_path = Path(rel)
            if rel_path.is_absolute() or ".." in rel_path.parts:
                console.print("[red]✗ Backup manifest contains unsafe paths — refusing rollback.[/red]")
                return False

            candidate = (backup_path / rel_path).resolve()
            if not candidate.is_relative_to(backup_path.resolve()) or not candidate.exists():
                console.print("[red]✗ Backup appears incomplete — refusing rollback.[/red]")
                return False

        return True

    def _is_safe_backup_path(self, backup_path: Path) -> bool:
        """Validate rollback backup location against approved roots."""
        project_parent = self.project_path.resolve().parent
        primary_root = project_parent / ".upgrades"

        # Primary path for modern backups.
        if backup_path.is_relative_to(primary_root):
            return True

        # Legacy compatibility: sibling backup paths under project parent.
        if backup_path.is_relative_to(project_parent):
            if backup_path == self.project_path.resolve():
                return False
            return backup_path.name.startswith("backup")

        return False

    def _rollback_to_backup(self) -> None:
        """Rollback project to backup."""
        if not self.backup_path or not self.backup_path.exists():
            console.print("[red]❌ Backup not found for rollback[/red]")
            return

        # Guard: refuse to wipe project if backup is empty
        if not any(self.backup_path.iterdir()):
            console.print("[red]✗ Backup directory is empty — refusing to wipe project.[/red]")
            return
        if not self._validate_backup_snapshot(self.backup_path):
            return

        # Remove current files
        for item in self.project_path.iterdir():
            if item.name.startswith("."):
                continue
            if item.is_dir():
                shutil.rmtree(item)
            else:
                item.unlink()

        # Restore from backup
        for item in self.backup_path.iterdir():
            if item.is_dir():
                dest = self.project_path / item.name
                if dest.exists():
                    shutil.rmtree(dest)
                shutil.copytree(item, dest)
            else:
                shutil.copy2(item, self.project_path / item.name)

    def _commit_upgrade(self, from_version: str, to_version: str) -> None:
        """Commit upgrade changes to git."""
        try:
            subprocess.run(
                ["git", "add", "-A"],
                cwd=str(self.project_path),
                capture_output=True,
                check=True,
            )

            message = f"chore: upgrade from {from_version} to {to_version}"
            subprocess.run(
                ["git", "commit", "-m", message],
                cwd=str(self.project_path),
                capture_output=True,
                check=True,
            )

            console.print(f"[green]✓[/green] Committed: {message}")

        except subprocess.CalledProcessError as e:
            console.print(f"[yellow]⚠️  Git commit failed: {e.stderr.decode()}[/yellow]")

    def _get_latest_version(self, template_type: str) -> Optional[str]:
        """Get the latest available version of sscli from PyPI."""
        import urllib.request
        import json as _json

        try:
            url = "https://pypi.org/pypi/sscli/json"
            with urllib.request.urlopen(url, timeout=5) as resp:  # noqa: S310
                data = _json.loads(resp.read().decode("utf-8"))
            return data["info"]["version"]
        except Exception:
            return None


def run_upgrade(
    project_path: Optional[Path] = None,
    to_version: Optional[str] = None,
    dry_run: bool = False,
    force: bool = False,
    only_safe: bool = False,
    interactive: bool = False,
    skip_verification: bool = False,
) -> bool:
    """
    Run the upgrade command.

    Args:
        project_path: Path to project
        to_version: Target version
        dry_run: Preview without applying
        force: Skip git checks
        interactive: Confirm each step
        skip_verification: Skip post-upgrade verification

    Returns:
        True if successful
    """
    try:
        upgrade_cmd = UpgradeCommand(project_path)

        if dry_run:
            console.print("[bold cyan]🔍 DRY-RUN MODE[/bold cyan]")
            return upgrade_cmd.preview_upgrade(to_version=to_version, force=force) is not None

        return upgrade_cmd.execute_upgrade(
            to_version=to_version,
            force=force,
            only_safe=only_safe,
            interactive=interactive,
            skip_verification=skip_verification,
        )

    except Exception as e:
        console.print(f"[red]❌ Error: {str(e)}[/red]")
        return False
