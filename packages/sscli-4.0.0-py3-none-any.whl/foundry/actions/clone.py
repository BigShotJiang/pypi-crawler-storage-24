"""Template repository cloning via authenticated git."""
from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path
from typing import Optional

from rich.console import Console

console = Console()

# Slug-based registry — maps CLI template names to GitHub org/repo slugs.
# Kept separate from constants.TEMPLATE_REGISTRY (which carries tier/tier/desc metadata)
# so this module has a single, auditable responsibility.
TEMPLATE_REGISTRY: dict[str, str] = {
    "python-saas": "seed-source/python-saas",
    "react-client": "seed-source/react-client",
    "rails-api": "seed-source/rails-api",
    "static-landing": "seed-source/static-landing",
}


def _build_clone_url(repo_slug: str, token: Optional[str] = None) -> str:
    """Build an authenticated HTTPS clone URL. Falls back to SSH if no token."""
    org = os.getenv("SSCLI_TEMPLATE_ORG", "seed-source")
    if "/" not in repo_slug:
        repo_slug = f"{org}/{repo_slug}"
    if token:
        return f"https://{token}@github.com/{repo_slug}.git"
    return f"git@github.com:{repo_slug}.git"


def clone_template(
    template_name: str,
    destination: Path,
    token: Optional[str] = None,
    branch: str = "main",
) -> Path:
    """Clone a private template repo into *destination*. Strips .git after clone.

    Token resolution order:
      1. Explicit ``token`` argument
      2. ``GITHUB_TOKEN`` env var
      3. ``SSCLI_TOKEN`` env var
      4. SSH fallback (no token)

    Security:
      - Tokens are never written to disk or logs.
      - If clone fails and the token appears in stderr, it is replaced with
        ``[REDACTED]`` before raising.

    Args:
        template_name: Key into ``TEMPLATE_REGISTRY``.
        destination: Directory to clone into (created if absent).
        token: Optional GitHub PAT for HTTPS auth.
        branch: Branch to clone. Defaults to ``"main"``.

    Returns:
        Resolved ``destination`` path.

    Raises:
        ValueError: Unknown template name.
        RuntimeError: git clone subprocess failed.
    """
    if template_name not in TEMPLATE_REGISTRY:
        available = ", ".join(sorted(TEMPLATE_REGISTRY.keys()))
        raise ValueError(f"Unknown template '{template_name}'. Available: {available}")

    token = token or os.getenv("GITHUB_TOKEN") or os.getenv("SSCLI_TOKEN")
    clone_url = _build_clone_url(TEMPLATE_REGISTRY[template_name], token)
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=True)

    console.print(f"  Cloning [cyan]{template_name}[/cyan]...")
    result = subprocess.run(
        ["git", "clone", "--depth", "1", "--branch", branch, clone_url, str(destination)],
        capture_output=True,
        text=True,
        timeout=120,
    )

    if result.returncode != 0:
        err = result.stderr
        # Security: scrub token from error output before surfacing to caller.
        if token and token in err:
            err = err.replace(token, "[REDACTED]")
        raise RuntimeError(f"Clone failed: {err}")

    # Strip .git — the user starts with a clean working tree, not a fork.
    git_dir = destination / ".git"
    if git_dir.exists():
        shutil.rmtree(git_dir)

    console.print(f"  [green]✓ Ready at {destination}[/green]")
    return destination
