import re
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import get_args

from rich import print
from rich.console import Console
from rich.table import Table

from cognite_toolkit._cdf_tk.client import ToolkitClient
from cognite_toolkit._cdf_tk.client.http_client import (
    HTTPClient,
    ItemsFailedRequest,
    ItemsFailedResponse,
    ItemsSuccessResponse,
)
from cognite_toolkit._cdf_tk.commands._base import ToolkitCommand
from cognite_toolkit._cdf_tk.commands._migrate.creators import MigrationCreator
from cognite_toolkit._cdf_tk.commands._migrate.data_mapper import DataMapper
from cognite_toolkit._cdf_tk.commands.deploy import DeployCommand
from cognite_toolkit._cdf_tk.constants import DMS_INSTANCE_LIMIT_MARGIN
from cognite_toolkit._cdf_tk.cruds import ResourceWorker
from cognite_toolkit._cdf_tk.data_classes import DeployResults
from cognite_toolkit._cdf_tk.exceptions import (
    ToolkitMigrationError,
    ToolkitValueError,
)
from cognite_toolkit._cdf_tk.storageio import (
    Bookmark,
    ChartIO,
    Page,
    T_DataRequest,
    T_DataResponse,
    T_Selector,
    UploadableStorageIO,
    UploadItem,
)
from cognite_toolkit._cdf_tk.storageio.logger import FileDataLogger, OperationStatus
from cognite_toolkit._cdf_tk.storageio.progress import CDFProgressYAML, FileProgressYAML, Progress
from cognite_toolkit._cdf_tk.utils import humanize_collection, safe_write, sanitize_filename
from cognite_toolkit._cdf_tk.utils.file import yaml_safe_dump
from cognite_toolkit._cdf_tk.utils.fileio import NDJsonWriter, Uncompressed
from cognite_toolkit._cdf_tk.utils.producer_worker import ProducerWorkerExecutor

from .data_model import INSTANCE_SOURCE_VIEW_ID, MODEL_ID, RESOURCE_VIEW_MAPPING_VIEW_ID
from .issues import WriteIssue


@dataclass
class OperationIssue:
    message: str
    count: int


@dataclass
class MigrationStatusResult:
    status: OperationStatus
    issues: list[OperationIssue]
    count: int


class MigrationCommand(ToolkitCommand):
    def migrate(
        self,
        selectors: Sequence[T_Selector],
        data: UploadableStorageIO[T_Selector, T_DataResponse, T_DataRequest],
        mapper: DataMapper[T_Selector, T_DataResponse, T_DataRequest],
        log_dir: Path,
        dry_run: bool = False,
        verbose: bool = False,
        user_log_filestem: str | None = None,
    ) -> dict[str, list[MigrationStatusResult]]:
        self.validate_migration_model_available(data.client)

        log_dir.mkdir(parents=True, exist_ok=True)
        log_filestem = self._create_logfile_stem(log_dir, user_log_filestem, data.KIND)

        console = data.client.console
        counts_by_selector, total_all_items = self._print_overview(data, selectors, console)

        if total_all_items and not isinstance(data, ChartIO):
            # Chart are not creating any new nodes.
            self.validate_available_capacity(data.client, total_all_items)

        results_by_selector: dict[str, list[MigrationStatusResult]] = {}
        with (
            NDJsonWriter(
                log_dir, kind="MigrationIssues", default_filestem=log_filestem, compression=Uncompressed
            ) as log_file,
            HTTPClient(config=data.client.config) as write_client,
        ):
            logger = FileDataLogger(log_file)
            data.logger = logger
            mapper.logger = logger
            for selected in selectors:
                logger.tracker.reset()

                mapper.prepare(selected)

                iteration_count: int | None = None
                total_items = counts_by_selector[selected]
                if total_items is not None:
                    iteration_count = (total_items // data.CHUNK_SIZE) + (1 if total_items % data.CHUNK_SIZE > 0 else 0)

                init_bookmark: Bookmark | None = None
                progress = Progress.try_load(log_dir, filestem=str(selected))
                if progress is not None:
                    if isinstance(progress, CDFProgressYAML) and len(progress.cursors) == 1:
                        init_cursor = next(iter(progress.cursors.values()))
                        init_bookmark = Bookmark(cursor=init_cursor)
                        console.print(f"Resuming migration for {selected.display_name} from cursor {init_cursor!r}.")
                    elif isinstance(progress, FileProgressYAML) and len(progress.locations) == 1:
                        init_file_location = next(iter(progress.locations.values()))
                        init_bookmark = Bookmark(file_location=init_file_location)
                        console.print(
                            f"Resuming migration for {selected.display_name} from"
                            f" lineno {init_file_location.lineno:,} in {init_file_location.filepath.as_posix()!r}."
                        )
                    else:
                        console.print(
                            f"Found progress file but failed to load cursor for {selected.display_name}. Starting migration from the beginning."
                        )

                executor = ProducerWorkerExecutor[Page[T_DataResponse], Page[UploadItem[T_DataRequest]]](
                    download_iterable=data.stream_data(selected, bookmark=init_bookmark),
                    process=self._convert(mapper, data),
                    write=self._upload(selected, write_client, data, dry_run, log_dir),
                    iteration_count=iteration_count,
                    max_queue_size=10,
                    download_description=f"Downloading {selected.display_name}",
                    process_description="Converting",
                    write_description="Uploading",
                    console=console,
                    verbose=verbose,
                )

                executor.run()
                total = executor.total_items

                results = self._create_status_summary(logger)
                results_by_selector[str(selected)] = results

                self._print_rich_tables(results, console)
                self._print_txt(results, log_dir, f"{selected!s}Items", console)
                progress = Progress.try_load(log_dir, filestem=str(selected))
                if progress is not None:
                    progress.status = executor.result
                    progress.dump_to_file(log_dir, filestem=str(selected))
                executor.raise_on_error()

                action = "Would migrate" if dry_run else "Migrating"
                console.print(f"{action} {total:,} {selected.display_name} to instances.")

        return results_by_selector

    def _print_overview(
        self,
        data: UploadableStorageIO[T_Selector, T_DataResponse, T_DataRequest],
        selectors: Sequence[T_Selector],
        console: Console,
    ) -> tuple[dict[T_Selector, int | None], int]:
        counts_by_selector: dict[T_Selector, int | None] = {}
        total_all_items = 0
        table = Table(title="Planned Migrations")
        table.add_column("Data Type", style="cyan")
        table.add_column("Item Count", justify="right", style="green")
        for selected in selectors:
            total_items = data.count(selected)
            total_all_items += total_items if total_items is not None else 0
            counts_by_selector[selected] = total_items
            item_count = str(total_items) if total_items is not None else "Unknown"
            table.add_row(str(selected), item_count)
        console.print(table)
        return counts_by_selector, total_all_items

    @staticmethod
    def _create_logfile_stem(log_dir: Path, user_log_filestem: str | None, data_kind: str) -> str:
        """Create a filestem for the log file that does not conflict with existing files in the log directory."""
        base_logstem = user_log_filestem or data_kind
        if not base_logstem.endswith("-"):
            base_logstem += "-"

        existing_files = list(log_dir.glob(f"{base_logstem}*"))
        if not existing_files:
            return base_logstem

        run_pattern = re.compile(re.escape(base_logstem) + r"run(\d+)-")
        max_run = 0
        for f in existing_files:
            match = run_pattern.match(f.name)
            if match:
                max_run = max(max_run, int(match.group(1)))

        # If max_run is 0, it means files with base_logstem exist, but none have 'runX'.
        next_run = max(2, max_run + 1)

        return f"{base_logstem}run{next_run}-"

    # Todo: Move to the logger module
    @classmethod
    def _create_status_summary(cls, logger: FileDataLogger) -> list[MigrationStatusResult]:
        results: list[MigrationStatusResult] = []
        status_counts = logger.tracker.get_status_counts()
        for status in get_args(OperationStatus):
            issue_counts = logger.tracker.get_issue_counts(status)
            issues = [OperationIssue(message=issue, count=count) for issue, count in issue_counts.items()]
            result = MigrationStatusResult(
                status=status,
                issues=issues,
                count=status_counts.get(status, 0),
            )
            results.append(result)
        return results

    def _print_rich_tables(self, results: list[MigrationStatusResult], console: Console) -> None:
        table = Table(title="Migration Summary", show_lines=True)
        table.add_column("Status", style="bold")
        table.add_column("Count", justify="right", style="bold")
        table.add_column("Issues", style="bold")
        for result in results:
            issues_str = "\n".join(f"{issue.message}: {issue.count}" for issue in result.issues) or ""
            table.add_row(result.status, str(result.count), issues_str)
        console.print(table)

    def _print_txt(self, results: list[MigrationStatusResult], log_dir: Path, filestem: str, console: Console) -> None:
        summary_file = log_dir / f"{filestem}_migration_summary.txt"
        with summary_file.open("w", encoding="utf-8") as f:
            f.write("Migration Summary\n")
            f.write("=================\n\n")
            for result in results:
                f.write(f"Status: {result.status}\n")
                f.write(f"Count: {result.count}\n")
                f.write("Issues:\n")
                if result.issues:
                    for issue in result.issues:
                        f.write(f"  - {issue.message}: {issue.count}\n")
                else:
                    f.write("  None\n")
                f.write("\n")
        console.print(f"Summary written to {log_dir}")

    @staticmethod
    def _convert(
        mapper: DataMapper[T_Selector, T_DataResponse, T_DataRequest],
        data: UploadableStorageIO[T_Selector, T_DataResponse, T_DataRequest],
    ) -> Callable[[Page[T_DataResponse]], Page[UploadItem[T_DataRequest]]]:
        def track_mapping(source: Page[T_DataResponse]) -> Page[UploadItem[T_DataRequest]]:
            mapped = mapper.map(source.items)
            return Page(
                worker_id=source.worker_id,
                items=[
                    UploadItem(source_id=data.as_id(item), item=target)
                    for target, item in zip(mapped, source.items)
                    if target is not None
                ],
                bookmark=source.bookmark,
            )

        return track_mapping

    def _upload(
        self,
        selected: T_Selector,
        write_client: HTTPClient,
        target: UploadableStorageIO[T_Selector, T_DataResponse, T_DataRequest],
        dry_run: bool,
        log_dir: Path,
    ) -> Callable[[Page[UploadItem[T_DataRequest]]], None]:
        def upload_items(page: Page[UploadItem[T_DataRequest]]) -> None:
            if not page:
                return None
            if dry_run:
                target.logger.tracker.finalize_item([item.source_id for item in page.items], "pending")
                return None

            responses = target.upload_items(data_chunk=page.items, http_client=write_client, selector=selected)

            # Todo: Move logging into the UploadableStorageIO class
            issues: list[WriteIssue] = []
            for item in responses:
                if isinstance(item, ItemsSuccessResponse):
                    target.logger.tracker.finalize_item(item.ids, "success")
                    continue
                if isinstance(item, ItemsFailedResponse):
                    error = item.error
                    for id_ in item.ids:
                        issue = WriteIssue(id=str(id_), status_code=error.code, message=error.message)
                        issues.append(issue)
                elif isinstance(item, ItemsFailedRequest):
                    for id_ in item.ids:
                        issue = WriteIssue(id=str(id_), status_code=0, message=item.error_message)
                        issues.append(issue)

                if isinstance(item, ItemsFailedResponse | ItemsFailedRequest):
                    target.logger.tracker.finalize_item(item.ids, "failure")
            if issues:
                target.logger.log(issues)

            # Remove false check, when feature is ready.
            if False and page.bookmark.cursor is not None:
                CDFProgressYAML(
                    status="in-progress",
                    cursors={page.worker_id: page.bookmark.cursor},
                ).dump_to_file(log_dir, filestem=str(selected))
            if False and page.bookmark.file_location is not None:
                FileProgressYAML(
                    status="in-progress",
                    locations={page.worker_id: page.bookmark.file_location},
                ).dump_to_file(log_dir, filestem=str(selected))
            return None

        return upload_items

    @staticmethod
    def validate_migration_model_available(client: ToolkitClient) -> None:
        models = client.tool.data_models.retrieve([MODEL_ID], inline_views=False)
        if not models:
            raise ToolkitMigrationError(
                f"The migration data model {MODEL_ID!r} does not exist. "
                "Please run the `cdf migrate prepare` command to deploy the migration data model."
            )
        elif len(models) > 1:
            raise ToolkitMigrationError(
                f"Multiple migration models {MODEL_ID!r}. "
                "Please delete the duplicate models before proceeding with the migration."
            )
        model = models[0]
        missing_views = {INSTANCE_SOURCE_VIEW_ID, RESOURCE_VIEW_MAPPING_VIEW_ID} - set(model.views or [])
        if missing_views:
            raise ToolkitMigrationError(
                f"Invalid migration model. Missing views {humanize_collection(missing_views)}. "
                f"Please run the `cdf migrate prepare` command to deploy the migration data model."
            )

    def validate_available_capacity(self, client: ToolkitClient, instance_count: int) -> None:
        """Validate that the project has enough capacity to accommodate the migration."""

        stats = client.data_modeling.statistics.project()

        available_capacity = stats.instances.instances_limit - stats.instances.instances
        available_capacity_after = available_capacity - instance_count

        if available_capacity_after < DMS_INSTANCE_LIMIT_MARGIN:
            raise ToolkitValueError(
                "Cannot proceed with migration, not enough instance capacity available. Total capacity after migration"
                f" would be {available_capacity_after:,} instances, which is less than the required margin of"
                f" {DMS_INSTANCE_LIMIT_MARGIN:,} instances. Please increase the instance capacity in your CDF project"
                f" or delete some existing instances before proceeding with the migration of {instance_count:,} assets."
            )
        total_instances = stats.instances.instances + instance_count
        self.console(
            f"Project has enough capacity for migration. Total instances after migration: {total_instances:,}."
        )

    def create(
        self,
        client: ToolkitClient,
        creator: MigrationCreator,
        dry_run: bool,
        output_dir: Path,
        deploy: bool = True,
        verbose: bool = False,
    ) -> DeployResults:
        """This method is used to create migration resource in CDF."""
        self.validate_migration_model_available(client)

        deploy_cmd = DeployCommand(self.print_warning, silent=self.silent)
        deploy_cmd.tracker = self.tracker
        # crud_cls = creator.CRUD
        # resource_list = creator.create_resources()
        results = DeployResults([], "deploy", dry_run=dry_run)
        for to_create in creator.create_resources():
            crud_cls = to_create.crud_cls
            if deploy:
                crud = crud_cls.create_loader(client)
                worker = ResourceWorker(crud, "deploy")
                local_by_id = {
                    crud.get_id(item.resource): (item.resource.dump(), item.resource) for item in to_create.resources
                }
                worker.validate_access(local_by_id, is_dry_run=dry_run)
                cdf_resources = crud.retrieve(list(local_by_id.keys()))
                resources = worker.categorize_resources(local_by_id, cdf_resources, False, verbose)

                if dry_run:
                    result = deploy_cmd.dry_run_deploy(resources, crud, False, False)
                else:
                    result = deploy_cmd.actual_deploy(resources, crud)
                    if result.calculated_total > 0 and to_create.store_linage is not None:
                        store_count = to_create.store_linage()
                        self.console(f"Stored lineage for {store_count:,} {to_create.display_name}.")

                verb = "Would deploy" if dry_run else "Deploying"
                self.console(f"{verb} {to_create.display_name} to CDF.")

                if result:
                    results[result.name] = result

                if results.has_counts:
                    print(results.counts_table())

            for item in to_create.resources:
                if item.config_data and item.filestem:
                    filepath = (
                        output_dir / crud_cls.folder_name / f"{sanitize_filename(item.filestem)}.{crud_cls.kind}.yaml"
                    )
                    filepath.parent.mkdir(parents=True, exist_ok=True)
                    safe_write(filepath, yaml_safe_dump(item.config_data))
            self.console(
                f"{len(to_create.resources)} {crud_cls.kind} resource configurations written to {(output_dir / crud_cls.folder_name).as_posix()!r}"
            )
            self.console("It is recommended to add these files to a Toolkit governed module.")

        return results
