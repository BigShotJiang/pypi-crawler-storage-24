from typing import Annotated, Any, Literal

from pydantic import BeforeValidator, ConfigDict, Field

from cognite_toolkit._cdf_tk.client._resource_base import BaseModelObject, RequestResource, ResponseResource
from cognite_toolkit._cdf_tk.client.identifiers import ExternalId
from cognite_toolkit._cdf_tk.utils._auxiliary import get_concrete_subclasses


class AgentObject(BaseModelObject):
    model_config = ConfigDict(extra="allow")


class AgentToolDefinition(AgentObject):
    model_config = ConfigDict(extra="allow")

    type: str
    name: str
    description: str


class AnalyzeImage(AgentToolDefinition):
    type: Literal["analyzeImage"] = "analyzeImage"


class AnalyzeTimeSeries(AgentToolDefinition):
    type: Literal["analyzeTimeSeries"] = "analyzeTimeSeries"


class AskDocument(AgentToolDefinition):
    type: Literal["askDocument"] = "askDocument"


class CallFunctionConfig(AgentObject):
    external_id: str
    max_polling_time: int = 540
    schema_: dict[str, Any] | None = Field(None, alias="schema")


class CallFunction(AgentToolDefinition):
    type: Literal["callFunction"] = "callFunction"
    configuration: CallFunctionConfig


class CallRestApi(AgentToolDefinition):
    type: Literal["callRestApi"] = "callRestApi"


class ExamineDataSemantically(AgentToolDefinition):
    type: Literal["examineDataSemantically"] = "examineDataSemantically"


class AgentDataModel(AgentObject):
    space: str
    external_id: str
    version: str
    view_external_ids: list[str] | None = None


class AgentInstanceSpacesDefinition(AgentObject):
    type: str


class AllInstanceSpaces(AgentInstanceSpacesDefinition):
    type: Literal["all"] = "all"


class ManualInstanceSpaces(AgentInstanceSpacesDefinition):
    type: Literal["manual"] = "manual"
    spaces: list[str]


class UnknownInstanceSpaces(AgentInstanceSpacesDefinition): ...


_KNOWN_INSTANCE_SPACES = {
    cls_.model_fields["type"].default: cls_
    for cls_ in get_concrete_subclasses(AgentInstanceSpacesDefinition)
    if cls_ is not UnknownInstanceSpaces
}


def _handle_unknown_instance_spaces(value: Any) -> Any:
    if isinstance(value, dict):
        type_ = value.get("type")
        if type_ not in _KNOWN_INSTANCE_SPACES:
            return UnknownInstanceSpaces(**value)
        else:
            return _KNOWN_INSTANCE_SPACES[type_].model_validate(value)
    return value


AgentInstanceSpaces = Annotated[
    AllInstanceSpaces | ManualInstanceSpaces | UnknownInstanceSpaces,
    BeforeValidator(_handle_unknown_instance_spaces),
]


class QueryKnowledgeGraphConfig(AgentObject):
    data_models: list[AgentDataModel]
    instance_spaces: AgentInstanceSpaces | None = None
    # This is deviating from the API documentation, but the Atlas team has confirmed that "v2" is the default
    version: Literal["v1", "v2"] = "v2"


class QueryKnowledgeGraph(AgentToolDefinition):
    type: Literal["queryKnowledgeGraph"] = "queryKnowledgeGraph"
    configuration: QueryKnowledgeGraphConfig


class QueryTimeSeriesDatapoints(AgentToolDefinition):
    type: Literal["queryTimeSeriesDatapoints"] = "queryTimeSeriesDatapoints"


class RunPythonCode(AgentToolDefinition):
    type: Literal["runPythonCode"] = "runPythonCode"


class SummarizeDocument(AgentToolDefinition):
    type: Literal["summarizeDocument"] = "summarizeDocument"


class TimeSeriesAnalysis(AgentToolDefinition):
    type: Literal["timeSeriesAnalysis"] = "timeSeriesAnalysis"


class UnknownAgentTool(AgentToolDefinition):
    """Fallback for unknown tool types."""

    ...


KNOWN_TOOLS: dict[str, type[AgentToolDefinition]] = {
    "analyzeImage": AnalyzeImage,
    "analyzeTimeSeries": AnalyzeTimeSeries,
    "askDocument": AskDocument,
    "callFunction": CallFunction,
    "callRestApi": CallRestApi,
    "examineDataSemantically": ExamineDataSemantically,
    "queryKnowledgeGraph": QueryKnowledgeGraph,
    "queryTimeSeriesDatapoints": QueryTimeSeriesDatapoints,
    "runPythonCode": RunPythonCode,
    "summarizeDocument": SummarizeDocument,
    "timeSeriesAnalysis": TimeSeriesAnalysis,
}


def _handle_unknown_tool(value: Any) -> Any:
    if isinstance(value, dict):
        tool_type = value.get("type")
        if tool_type not in KNOWN_TOOLS:
            return UnknownAgentTool(**value)
        else:
            return KNOWN_TOOLS[tool_type].model_validate(value)
    return value


AgentTool = Annotated[
    AnalyzeImage
    | AnalyzeTimeSeries
    | AskDocument
    | CallFunction
    | CallRestApi
    | ExamineDataSemantically
    | QueryKnowledgeGraph
    | QueryTimeSeriesDatapoints
    | RunPythonCode
    | SummarizeDocument
    | TimeSeriesAnalysis
    | UnknownAgentTool,
    BeforeValidator(_handle_unknown_tool),
]


class Agent(AgentObject):
    external_id: str
    name: str
    description: str | None = None
    instructions: str | None = None
    model: str | None = None
    tools: list[AgentTool] | None = None
    labels: list[str] | None = None

    def as_id(self) -> ExternalId:
        return ExternalId(external_id=self.external_id)


class AgentRequest(Agent, RequestResource):
    model_config = ConfigDict(extra="allow")
    runtime_version: str | None = None


class AgentResponse(Agent, ResponseResource[AgentRequest]):
    model_config = ConfigDict(extra="allow")
    created_time: int
    last_updated_time: int
    owner_id: str
    runtime_version: str

    @classmethod
    def request_cls(cls) -> type[AgentRequest]:
        return AgentRequest
