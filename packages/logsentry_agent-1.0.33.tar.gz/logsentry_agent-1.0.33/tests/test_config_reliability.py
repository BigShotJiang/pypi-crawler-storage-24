from pathlib import Path

from logsentry_agent.config import load_config


def test_reliability_stop_sending_after_fail_seconds_from_file(tmp_path: Path):
    config_path = tmp_path / "agent.yml"
    config_path.write_text(
        """
agent_id: "agent"
shared_secret: "secret"
endpoint: "http://localhost:8002/v1/ingest"
reliability:
  stop_sending_after_fail_seconds: 120
""".strip(),
        encoding="utf-8",
    )

    config = load_config(config_path)
    assert config.reliability is not None
    assert config.reliability.stop_sending_after_fail_seconds == 120


def test_reliability_stop_sending_after_fail_seconds_env_overrides(tmp_path: Path, monkeypatch):
    monkeypatch.setenv("LOGSENTRY_STOP_SENDING_AFTER_FAIL_SECONDS", "45")
    config_path = tmp_path / "agent.yml"
    config_path.write_text(
        """
agent_id: "agent"
shared_secret: "secret"
endpoint: "http://localhost:8002/v1/ingest"
reliability:
  stop_sending_after_fail_seconds: 120
""".strip(),
        encoding="utf-8",
    )

    config = load_config(config_path)
    assert config.reliability is not None
    assert config.reliability.stop_sending_after_fail_seconds == 45
