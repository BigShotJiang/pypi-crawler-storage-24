import logging, jsonpickle
from http import HTTPMethod
from fmconsult.utils.url import UrlUtil
from feriados.api import FeriadosApi
from feriados.dtos.feriado import FeriadoResponse

class Feriados(FeriadosApi):

    def __init__(self):
        super().__init__()

    def get_nacionais(self):
        try:
            logging.info('listing Feriados Nacionais...')
            self.endpoint_url = UrlUtil().make_url(self.base_url, ['feriados', 'nacionais'])
            res = self.call_request(
                http_method=HTTPMethod.GET,
                request_url=self.endpoint_url,
                params={
                    'ano': self.ano_referencia
                }
            )
            res = jsonpickle.decode(res)
            return FeriadoResponse(**res)
        except:
            raise
    
    def get_estaduais_by_uf(self, uf):
        try:
            logging.info('listing Feriados Estaduais by UF...')
            self.endpoint_url = UrlUtil().make_url(self.base_url, ['feriados', 'estado', uf])
            res = self.call_request(
                http_method=HTTPMethod.GET,
                request_url=self.endpoint_url,
                params={
                    'ano': self.ano_referencia
                }
            )
            res = jsonpickle.decode(res)
            return FeriadoResponse(**res)
        except:
            raise
    
    def get_municipais_by_cidade(self, codigo_ibge_municipio):
        try:
            logging.info('listing Feriados Municipais by Cidade...')
            self.endpoint_url = UrlUtil().make_url(self.base_url, ['feriados', 'cidade', codigo_ibge_municipio])
            res = self.call_request(
                http_method=HTTPMethod.GET,
                request_url=self.endpoint_url,
                params={
                    'ano': self.ano_referencia
                }
            )
            res = jsonpickle.decode(res)
            return FeriadoResponse(**res)
        except:
            raise