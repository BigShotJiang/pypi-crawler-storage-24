import os
from fmconsult.http.api import ApiBase

class FeriadosApi(ApiBase):
    def __init__(self):
        try:
            self.api_token = os.environ['feriados.api.token']
            self.base_url = 'https://feriadosapi.com/api/v1'
            self.headers = {
                'Authorization': f'Bearer {self.api_token}'
            }
        except:
            raise
    
    def set_ano_referencia(self, ano_referencia):
        self.ano_referencia = ano_referencia