from dataclasses import dataclass, asdict
from typing import List, Optional

from fmconsult.utils.enum import CustomEnum
from fmconsult.utils.object import CustomObject

class FeriadoType(CustomEnum):
    NACIONAL = 'NACIONAL'
    ESTADUAL = 'ESTADUAL'
    MUNICIPAL = 'MUNICIPAL'
    BANCARIO = 'BANCARIO'

@dataclass
class Cidade(CustomObject):
    ibge: int
    nome: str
    uf: str

@dataclass
class FeriadoMeta(CustomObject):
    total: int
    page: int
    per_page: int
    total_pages: int

@dataclass
class Feriado(CustomObject):
    id: str
    data: str
    nome: str
    tipo: FeriadoType
    bancario: Optional[bool]

@dataclass
class FeriadoResponse(CustomObject):
    tipo: FeriadoType
    ano: str
    feriados: List[Feriado]
    meta: FeriadoMeta
    uf: Optional[str]
    cidade: Optional[Cidade]