"""SkillBench — The development workbench for Agent Skills."""

__version__ = "0.1.0"
