"""SQLite-based history store for persisting run results."""

from __future__ import annotations

import json
from pathlib import Path

import aiosqlite

DEFAULT_DB_PATH = Path.home() / ".skillbench" / "history.db"

_SCHEMA = """
CREATE TABLE IF NOT EXISTS runs (
    run_id TEXT PRIMARY KEY,
    skill_name TEXT NOT NULL,
    skill_hash TEXT NOT NULL,
    source_repo TEXT,
    timestamp TEXT NOT NULL,
    adapters TEXT NOT NULL,
    summary TEXT NOT NULL,
    full_report TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_runs_skill ON runs(skill_name);
CREATE INDEX IF NOT EXISTS idx_runs_timestamp ON runs(timestamp);
"""


class HistoryStore:
    """Persistent storage for evaluation run history."""

    def __init__(self, db_path: Path | None = None):
        self._db_path = db_path or DEFAULT_DB_PATH
        self._db_path.parent.mkdir(parents=True, exist_ok=True)

    async def _get_db(self) -> aiosqlite.Connection:
        db = await aiosqlite.connect(str(self._db_path))
        await db.executescript(_SCHEMA)
        return db

    async def save_run(
        self,
        run_id: str,
        skill_name: str,
        skill_hash: str,
        source_repo: str | None,
        timestamp: str,
        adapters: list[str],
        summary: dict,
        full_report: dict,
    ) -> None:
        db = await self._get_db()
        try:
            await db.execute(
                "INSERT OR REPLACE INTO runs"
                " (run_id, skill_name, skill_hash, source_repo,"
                " timestamp, adapters, summary, full_report)"
                " VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    run_id,
                    skill_name,
                    skill_hash,
                    source_repo,
                    timestamp,
                    json.dumps(adapters),
                    json.dumps(summary),
                    json.dumps(full_report),
                ),
            )
            await db.commit()
        finally:
            await db.close()

    async def get_run(self, run_id: str) -> dict | None:
        db = await self._get_db()
        try:
            cursor = await db.execute("SELECT * FROM runs WHERE run_id = ?", (run_id,))
            row = await cursor.fetchone()
            if row is None:
                return None
            return _row_to_dict(row)
        finally:
            await db.close()

    async def list_runs(
        self,
        skill_name: str | None = None,
        limit: int = 50,
    ) -> list[dict]:
        db = await self._get_db()
        try:
            if skill_name:
                cursor = await db.execute(
                    "SELECT * FROM runs WHERE skill_name = ? ORDER BY timestamp DESC LIMIT ?",
                    (skill_name, limit),
                )
            else:
                cursor = await db.execute(
                    "SELECT * FROM runs ORDER BY timestamp DESC LIMIT ?",
                    (limit,),
                )
            rows = await cursor.fetchall()
            return [_row_to_dict(row) for row in rows]
        finally:
            await db.close()

    async def delete_run(self, run_id: str) -> bool:
        db = await self._get_db()
        try:
            cursor = await db.execute("DELETE FROM runs WHERE run_id = ?", (run_id,))
            await db.commit()
            return cursor.rowcount > 0
        finally:
            await db.close()


def _row_to_dict(row: tuple) -> dict:
    return {
        "run_id": row[0],
        "skill_name": row[1],
        "skill_hash": row[2],
        "source_repo": row[3],
        "timestamp": row[4],
        "adapters": json.loads(row[5]),
        "summary": json.loads(row[6]),
        "full_report": json.loads(row[7]),
    }
