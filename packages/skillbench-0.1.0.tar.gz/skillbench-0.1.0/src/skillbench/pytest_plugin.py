"""Pytest plugin for running skill scenarios as test cases."""

from __future__ import annotations

import asyncio
from pathlib import Path

import pytest

from skillbench.core.evaluator import evaluate_run
from skillbench.core.scenario import load_scenarios
from skillbench.core.skill import load_skill


def _create_adapter(name: str):
    """Create an adapter instance by name."""
    from skillbench.adapters.aider import AiderAdapter
    from skillbench.adapters.claude_api import ClaudeAdapter
    from skillbench.adapters.claude_code import ClaudeCodeAdapter
    from skillbench.adapters.codex import CodexAdapter
    from skillbench.adapters.cursor import CursorAdapter
    from skillbench.adapters.openai_api import OpenAIAdapter
    from skillbench.adapters.opencode import OpenCodeAdapter

    adapters = {
        "claude": ClaudeAdapter,
        "openai": OpenAIAdapter,
        "azure": lambda: OpenAIAdapter(provider="azure"),
        "claude-code": ClaudeCodeAdapter,
        "cursor": CursorAdapter,
        "codex": CodexAdapter,
        "aider": AiderAdapter,
        "opencode": OpenCodeAdapter,
    }
    factory = adapters.get(name, ClaudeAdapter)
    return factory()


def pytest_addoption(parser):
    group = parser.getgroup("skillbench", "Agent Skill testing")
    group.addoption(
        "--skill-path",
        action="store",
        default=None,
        help="Path to the skill directory to test",
    )
    group.addoption(
        "--adapter",
        action="store",
        default="claude",
        help=(
            "Adapter: claude, openai, azure, claude-code,"
            " cursor, codex, aider, opencode (default: claude)"
        ),
    )
    group.addoption(
        "--skill-tags",
        action="store",
        default=None,
        help="Comma-separated tags to filter scenarios",
    )


def pytest_collect_file(parent, file_path):
    if file_path.name in ("scenarios.yaml", "scenarios.yml"):
        return SkillScenarioFile.from_parent(parent, path=file_path)
    return None


class SkillScenarioFile(pytest.File):
    def collect(self):
        try:
            suite = load_scenarios(self.path)
        except Exception as e:
            raise pytest.UsageError(f"Failed to load scenarios from {self.path}: {e}")

        skill_dir = self.path.parent
        if skill_dir.name == "scenarios":
            skill_dir = skill_dir.parent

        for scenario in suite.scenarios:
            yield SkillScenarioItem.from_parent(
                self,
                name=scenario.name,
                scenario=scenario,
                skill_dir=skill_dir,
                suite=suite,
            )


class SkillScenarioItem(pytest.Item):
    def __init__(self, name, parent, scenario, skill_dir, suite, **kwargs):
        super().__init__(name, parent, **kwargs)
        self.scenario = scenario
        self.skill_dir = skill_dir
        self.suite = suite

    def runtest(self):
        skill = load_skill(self.skill_dir)

        adapter_name = self.config.getoption("--adapter", "claude")
        adapter = _create_adapter(adapter_name)

        if not adapter.is_available():
            pytest.skip(f"{adapter.name} adapter is not available (missing API key)")

        import tempfile

        workspace = Path(tempfile.mkdtemp(prefix="skillbench_test_"))

        loop = asyncio.new_event_loop()
        try:
            run_result = loop.run_until_complete(
                adapter.run_scenario(skill, self.scenario, workspace)
            )

            if not run_result.success:
                raise SkillTestError(
                    f"Scenario execution failed: {run_result.error}"
                )

            eval_result = loop.run_until_complete(
                evaluate_run(self.scenario, run_result)
            )

            if not eval_result.overall_pass:
                failures = [
                    f"  [{ar.assertion.type}] {ar.message}"
                    for ar in eval_result.assertion_results
                    if not ar.passed
                ]
                raise SkillTestError(
                    "Assertions failed:\n" + "\n".join(failures)
                )
        finally:
            loop.close()
            import shutil
            shutil.rmtree(workspace, ignore_errors=True)

    def repr_failure(self, excinfo):
        if isinstance(excinfo.value, SkillTestError):
            return str(excinfo.value)
        return super().repr_failure(excinfo)

    def reportinfo(self):
        return self.path, None, f"skill:{self.suite.skill}::{self.scenario.name}"


class SkillTestError(Exception):
    pass
