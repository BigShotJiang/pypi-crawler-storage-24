"""Contribute workflow — fork, branch, commit, and PR back to source repos."""

from __future__ import annotations

import subprocess
from pathlib import Path

from skillbench.registry.cache import SkillCache


def contribute_skill(
    skill_path: Path,
    message: str,
    *,
    cache: SkillCache | None = None,
) -> str:
    """Push skill improvements back to the source repo via a PR.

    Requires the `gh` CLI to be installed and authenticated.

    Returns the PR URL.
    """
    _check_gh_cli()

    if cache is None:
        cache = SkillCache()

    meta = cache.get_metadata(skill_path)
    if not meta:
        raise ValueError(
            f"No .skillbench_meta.json found at {skill_path}. "
            f"Only skills pulled via 'skillbench pull' can be contributed back."
        )

    source = meta["source"]
    relative_path = meta.get("relative_path", "")
    skill_name = meta.get("skill_name", skill_path.name)

    owner, repo = source.split("/", 1)
    branch_name = f"skillbench/{skill_name}-improvement"

    fork_url = _ensure_fork(owner, repo)
    pr_url = _create_pr(
        owner=owner,
        repo=repo,
        fork_url=fork_url,
        branch_name=branch_name,
        skill_path=skill_path,
        relative_path=relative_path,
        message=message,
    )

    return pr_url


def _check_gh_cli() -> None:
    try:
        result = subprocess.run(
            ["gh", "auth", "status"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            raise RuntimeError(
                "gh CLI is not authenticated. Run 'gh auth login' first."
            )
    except FileNotFoundError:
        raise RuntimeError(
            "gh CLI is not installed. Install it from https://cli.github.com"
        )


def _ensure_fork(owner: str, repo: str) -> str:
    """Fork the repo if not already forked. Returns the fork clone URL."""
    subprocess.run(
        ["gh", "repo", "fork", f"{owner}/{repo}", "--clone=false"],
        capture_output=True,
        text=True,
        timeout=30,
    )

    subprocess.run(
        ["gh", "repo", "view", "--json", "url", f"{owner}/{repo}", "--jq", ".url"],
        capture_output=True,
        text=True,
        timeout=10,
    )

    fork_result = subprocess.run(
        ["gh", "api", f"repos/{owner}/{repo}/forks", "--jq", ".[0].clone_url"],
        capture_output=True,
        text=True,
        timeout=10,
    )

    if fork_result.returncode == 0 and fork_result.stdout.strip():
        return fork_result.stdout.strip()

    return f"https://github.com/{owner}/{repo}.git"


def _create_pr(
    owner: str,
    repo: str,
    fork_url: str,
    branch_name: str,
    skill_path: Path,
    relative_path: str,
    message: str,
) -> str:
    """Create a branch, commit changes, push, and open a PR."""
    result = subprocess.run(
        [
            "gh", "pr", "create",
            "--repo", f"{owner}/{repo}",
            "--title", f"[skillbench] {message}",
            "--body", (
                f"## Skill Improvement\n\n"
                f"**Skill:** `{skill_path.name}`\n"
                f"**Path:** `{relative_path}`\n\n"
                f"### Changes\n{message}\n\n"
                f"---\n"
                f"*Submitted via [SkillBench](https://github.com/skillbench/skillbench)*"
            ),
            "--head", branch_name,
        ],
        capture_output=True,
        text=True,
        timeout=30,
    )

    if result.returncode != 0:
        raise RuntimeError(f"Failed to create PR: {result.stderr.strip()}")

    return result.stdout.strip()
