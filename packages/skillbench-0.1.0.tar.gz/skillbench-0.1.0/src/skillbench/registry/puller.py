"""Pull skills from GitHub repos into the local cache."""

from __future__ import annotations

import subprocess
import tempfile
from pathlib import Path

from skillbench.registry.cache import SkillCache


def parse_source(source: str) -> tuple[str, str, str | None]:
    """Parse a source string into (owner, repo, subpath).

    Formats:
        owner/repo              -> all skills in repo
        owner/repo/path/to/skill -> specific skill or directory
    """
    parts = source.strip("/").split("/")
    if len(parts) < 2:
        raise ValueError(
            f"Invalid source format: {source!r}. Expected owner/repo or owner/repo/path"
        )
    owner = parts[0]
    repo = parts[1]
    subpath = "/".join(parts[2:]) if len(parts) > 2 else None
    return owner, repo, subpath


def pull_skill(
    source: str,
    cache: SkillCache | None = None,
    *,
    branch: str = "main",
) -> list[Path]:
    """Pull skill(s) from a GitHub repo into the local cache.

    Returns list of paths to pulled skill directories.
    """
    if cache is None:
        cache = SkillCache()

    owner, repo, subpath = parse_source(source)
    repo_url = f"https://github.com/{owner}/{repo}.git"

    with tempfile.TemporaryDirectory(prefix="skillbench_pull_") as tmpdir:
        tmp = Path(tmpdir)

        _sparse_clone(repo_url, tmp, branch, subpath)

        scan_root = tmp / subpath if subpath else tmp
        skill_dirs = _find_skill_dirs(scan_root)

        if not skill_dirs:
            raise FileNotFoundError(
                f"No SKILL.md files found in {source} "
                f"(scanned {scan_root.relative_to(tmp)})"
            )

        commit_hash = _get_commit_hash(tmp)

        pulled = []
        for skill_dir in skill_dirs:
            rel = skill_dir.relative_to(tmp)
            dest = cache.store_skill(
                owner=owner,
                repo=repo,
                skill_dir=skill_dir,
                relative_path=str(rel),
                commit_hash=commit_hash,
            )
            pulled.append(dest)

    return pulled


def _sparse_clone(
    repo_url: str, dest: Path, branch: str, subpath: str | None
) -> None:
    """Clone a repo with sparse checkout if subpath is provided."""
    cmd = ["git", "clone", "--depth", "1", "--branch", branch]

    if subpath:
        cmd.extend(["--filter=blob:none", "--sparse"])

    cmd.extend([repo_url, str(dest)])

    result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    if result.returncode != 0:
        raise RuntimeError(f"git clone failed: {result.stderr.strip()}")

    if subpath:
        subprocess.run(
            ["git", "sparse-checkout", "set", subpath],
            cwd=str(dest),
            capture_output=True,
            text=True,
            timeout=30,
        )


def _find_skill_dirs(root: Path) -> list[Path]:
    """Recursively find directories containing SKILL.md."""
    if not root.exists():
        return []
    skill_dirs = []
    for skill_md in root.rglob("SKILL.md"):
        skill_dirs.append(skill_md.parent)
    return sorted(skill_dirs)


def _get_commit_hash(repo_dir: Path) -> str:
    """Get the HEAD commit hash from a cloned repo."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=str(repo_dir),
            capture_output=True,
            text=True,
            timeout=10,
        )
        return result.stdout.strip()[:12]
    except Exception:
        return "unknown"
