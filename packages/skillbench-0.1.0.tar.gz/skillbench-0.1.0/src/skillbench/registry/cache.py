"""Local skill cache at ~/.skillbench/skills/."""

from __future__ import annotations

import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

DEFAULT_CACHE_DIR = Path.home() / ".skillbench" / "skills"


class SkillCache:
    """Manages the local cache of pulled skills."""

    def __init__(self, cache_dir: Path | None = None):
        self._cache_dir = cache_dir or DEFAULT_CACHE_DIR
        self._cache_dir.mkdir(parents=True, exist_ok=True)

    @property
    def cache_dir(self) -> Path:
        return self._cache_dir

    def store_skill(
        self,
        owner: str,
        repo: str,
        skill_dir: Path,
        relative_path: str,
        commit_hash: str,
    ) -> Path:
        """Copy a skill directory into the cache and write metadata."""
        skill_name = skill_dir.name
        dest = self._cache_dir / owner / repo / skill_name

        if dest.exists():
            shutil.rmtree(dest)
        shutil.copytree(skill_dir, dest)

        meta = {
            "source": f"{owner}/{repo}",
            "relative_path": relative_path,
            "commit_hash": commit_hash,
            "pulled_at": datetime.now(timezone.utc).isoformat(),
            "skill_name": skill_name,
        }
        (dest / ".skillbench_meta.json").write_text(
            json.dumps(meta, indent=2), encoding="utf-8"
        )

        return dest

    def get_skill_path(self, owner: str, repo: str, skill_name: str) -> Path | None:
        """Get the path to a cached skill, or None if not cached."""
        path = self._cache_dir / owner / repo / skill_name
        if path.exists() and (path / "SKILL.md").exists():
            return path
        return None

    def get_metadata(self, skill_path: Path) -> dict | None:
        """Read the .skillbench_meta.json for a cached skill."""
        meta_file = skill_path / ".skillbench_meta.json"
        if meta_file.exists():
            return json.loads(meta_file.read_text(encoding="utf-8"))
        return None

    def list_skills(self) -> list[dict]:
        """List all cached skills with their metadata."""
        skills = []
        for skill_md in self._cache_dir.rglob("SKILL.md"):
            skill_dir = skill_md.parent
            meta = self.get_metadata(skill_dir)
            skills.append(
                {
                    "path": str(skill_dir),
                    "name": skill_dir.name,
                    **(meta or {}),
                }
            )
        return sorted(skills, key=lambda s: s.get("name", ""))

    def remove_skill(self, owner: str, repo: str, skill_name: str) -> bool:
        """Remove a skill from the cache."""
        path = self._cache_dir / owner / repo / skill_name
        if path.exists():
            shutil.rmtree(path)
            return True
        return False
