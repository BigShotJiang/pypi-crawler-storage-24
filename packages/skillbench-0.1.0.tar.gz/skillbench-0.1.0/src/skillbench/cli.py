"""SkillBench CLI — the development workbench for Agent Skills."""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console

app = typer.Typer(
    name="skillbench",
    help=(
        "The development workbench for Agent Skills"
        " — develop, test, and evaluate skills across agent frameworks."
    ),
    no_args_is_help=True,
)
console = Console()


def _run_async(coro):
    """Run an async coroutine from sync context."""
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop and loop.is_running():
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor() as pool:
            return pool.submit(asyncio.run, coro).result()
    return asyncio.run(coro)


# ─── init ────────────────────────────────────────────────────────────────────


@app.command()
def init(
    name: str = typer.Argument(..., help="Name for the new skill (kebab-case)"),
    path: Optional[Path] = typer.Option(None, help="Parent directory (default: current dir)"),
):
    """Scaffold a new skill directory with SKILL.md template and scenarios/."""
    parent = path or Path.cwd()
    skill_dir = parent / name
    if skill_dir.exists():
        console.print(f"[red]Directory already exists: {skill_dir}[/red]")
        raise typer.Exit(1)

    skill_dir.mkdir(parents=True)
    (skill_dir / "scripts").mkdir()
    (skill_dir / "references").mkdir()
    (skill_dir / "assets").mkdir()
    (skill_dir / "scenarios").mkdir()

    skill_md = f"""---
name: {name}
description: "<TODO: Describe what this skill does and when to use it>"
---

# {name.replace('-', ' ').title()}

## When to use this skill

<TODO: Describe when an agent should activate this skill>

## Instructions

<TODO: Step-by-step instructions for the agent>

## Examples

<TODO: Input/output examples>

## Edge Cases

<TODO: Document edge cases and error handling>
"""
    (skill_dir / "SKILL.md").write_text(skill_md, encoding="utf-8")

    scenarios_yaml = f"""skill: {name}
environment:
  os: any
  tools: [Bash, Read, Write]

scenarios:
  - name: basic-usage
    description: "Basic usage of the skill"
    prompt: "<TODO: What would a user say?>"
    assertions:
      - type: llm_judge
        criteria: "<TODO: What should the agent do correctly?>"
    tags: [core]
"""
    (skill_dir / "scenarios" / "scenarios.yaml").write_text(
        scenarios_yaml, encoding="utf-8"
    )

    console.print(f"[green]Created skill scaffold at {skill_dir}[/green]")
    console.print("  SKILL.md          — edit your skill instructions")
    console.print("  scenarios/        — define test scenarios")
    console.print("  scripts/          — add executable scripts")
    console.print("  references/       — add reference docs")


# ─── validate ────────────────────────────────────────────────────────────────


@app.command()
def validate(
    path: Path = typer.Argument(..., help="Path to skill directory or SKILL.md"),
):
    """Validate a SKILL.md against the Agent Skills specification."""
    from skillbench.core.skill import validate_skill

    issues = validate_skill(path)

    if not issues:
        console.print("[green]Valid! No issues found.[/green]")
        raise typer.Exit(0)

    errors = [i for i in issues if i.level == "error"]
    warnings = [i for i in issues if i.level == "warning"]

    for issue in errors:
        field_str = f" ({issue.field})" if issue.field else ""
        console.print(f"  [red]ERROR{field_str}:[/red] {issue.message}")

    for issue in warnings:
        field_str = f" ({issue.field})" if issue.field else ""
        console.print(f"  [yellow]WARN{field_str}:[/yellow] {issue.message}")

    console.print(f"\n{len(errors)} error(s), {len(warnings)} warning(s)")
    if errors:
        raise typer.Exit(1)


# ─── pull ────────────────────────────────────────────────────────────────────


@app.command()
def pull(
    source: str = typer.Argument(
        ..., help="Source: owner/repo or owner/repo/path/to/skill"
    ),
    branch: str = typer.Option("main", help="Git branch to pull from"),
):
    """Fetch skill(s) from a GitHub repo into the local cache."""
    from skillbench.registry.puller import pull_skill

    console.print(f"Pulling from [cyan]{source}[/cyan] (branch: {branch})...")
    try:
        paths = pull_skill(source, branch=branch)
        for p in paths:
            console.print(f"  [green]Cached:[/green] {p}")
        console.print(f"\n[green]Pulled {len(paths)} skill(s)[/green]")
    except Exception as e:
        console.print(f"[red]Pull failed:[/red] {e}")
        raise typer.Exit(1)


# ─── generate-scenarios ─────────────────────────────────────────────────────


@app.command("generate-scenarios")
def generate_scenarios(
    path: Path = typer.Argument(..., help="Path to skill directory"),
    output: Optional[Path] = typer.Option(
        None, help="Output path (default: <skill>/scenarios/scenarios.yaml)"
    ),
    model: str = typer.Option(
        "claude-sonnet-4-20250514", help="Model to use for generation"
    ),
):
    """AI-generate evaluation scenarios from an existing SKILL.md."""
    from skillbench.core.scenario_gen import generate_scenarios as gen
    from skillbench.core.skill import load_skill

    skill = load_skill(path)
    out_path = output or (path / "scenarios" / "scenarios.yaml")

    console.print(f"Generating scenarios for [cyan]{skill.name}[/cyan]...")

    async def _gen():
        return await gen(skill, model=model, output_path=out_path)

    yaml_content = _run_async(_gen())
    console.print(f"[green]Generated scenarios written to {out_path}[/green]")
    console.print(f"\nPreview:\n{yaml_content[:500]}...")


# ─── test ────────────────────────────────────────────────────────────────────


@app.command()
def test(
    path: Path = typer.Argument(..., help="Path to skill directory"),
    adapter: str = typer.Option(
        "claude",
        help="Adapter: claude, openai, azure, claude-code, cursor, codex, aider, opencode",
    ),
    model: Optional[str] = typer.Option(
        None, help="Model/deployment name (overrides adapter default)"
    ),
    tags: Optional[str] = typer.Option(None, help="Comma-separated tags to filter"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="JSON output path"),
):
    """Run scenarios for a skill and evaluate results."""
    from skillbench.core.runner import run_suite
    from skillbench.core.scenario import load_scenarios
    from skillbench.core.skill import load_skill
    from skillbench.reports.generator import export_json, print_report

    skill = load_skill(path)
    suite = load_scenarios(path)

    adapter_map = _get_adapter_map()
    if adapter not in adapter_map:
        console.print(f"[red]Unknown adapter: {adapter}[/red]")
        console.print(f"Available: {', '.join(adapter_map.keys())}")
        raise typer.Exit(1)
    instance = adapter_map[adapter]()
    if model:
        instance._model = model
    adapters = [instance]

    tag_list = tags.split(",") if tags else None

    console.print(
        f"Testing [cyan]{skill.name}[/cyan] "
        f"({suite.scenario_count} scenarios, adapter: {adapter})...\n"
    )

    report = _run_async(run_suite(skill, suite, adapters, tags=tag_list))
    print_report(report, console)

    if output:
        export_json(report, output)
        console.print(f"\n[dim]JSON report written to {output}[/dim]")

    _run_async(_save_to_history(report, skill))

    if report.failed > 0:
        raise typer.Exit(1)


# ─── eval ────────────────────────────────────────────────────────────────────


@app.command("eval")
def eval_cmd(
    path: Path = typer.Argument(..., help="Path to skill directory"),
    frameworks: str = typer.Option(
        "claude",
        help=(
            "Comma-separated adapters:"
            " claude,openai,azure,claude-code,cursor,codex,aider,opencode"
        ),
    ),
    model: Optional[str] = typer.Option(
        None, help="Model/deployment name (overrides adapter default)"
    ),
    tags: Optional[str] = typer.Option(None, help="Comma-separated tags to filter"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="JSON output path"),
):
    """Evaluate a skill across multiple frameworks."""
    from skillbench.core.runner import run_suite
    from skillbench.core.scenario import load_scenarios
    from skillbench.core.skill import load_skill
    from skillbench.reports.generator import export_json, print_report

    skill = load_skill(path)
    suite = load_scenarios(path)

    all_adapters = _get_adapter_map()

    adapters = []
    for name in frameworks.split(","):
        name = name.strip()
        if name not in all_adapters:
            console.print(f"[red]Unknown adapter: {name}[/red]")
            console.print(f"Available: {', '.join(all_adapters.keys())}")
            raise typer.Exit(1)
        instance = all_adapters[name]()
        if model:
            instance._model = model
        adapters.append(instance)

    unavailable = [a for a in adapters if not a.is_available()]
    if unavailable:
        for a in unavailable:
            console.print(f"[yellow]Warning: {a.name} is not available (missing API key)[/yellow]")

    tag_list = tags.split(",") if tags else None

    console.print(
        f"Evaluating [cyan]{skill.name}[/cyan] "
        f"({suite.scenario_count} scenarios, {len(adapters)} adapters)...\n"
    )

    report = _run_async(run_suite(skill, suite, adapters, tags=tag_list))
    print_report(report, console)

    if output:
        export_json(report, output)
        console.print(f"\n[dim]JSON report written to {output}[/dim]")

    _run_async(_save_to_history(report, skill))

    if report.failed > 0:
        raise typer.Exit(1)


# ─── report ──────────────────────────────────────────────────────────────────


@app.command()
def report(
    run_id: str = typer.Argument(..., help="Run ID to display"),
):
    """Display a report for a previous run."""
    from skillbench.store.history import HistoryStore

    store = HistoryStore()

    async def _get():
        return await store.get_run(run_id)

    run = _run_async(_get())
    if run is None:
        console.print(f"[red]Run {run_id} not found[/red]")
        raise typer.Exit(1)

    import json
    console.print_json(json.dumps(run, indent=2))


# ─── history ─────────────────────────────────────────────────────────────────


@app.command()
def history(
    skill: Optional[str] = typer.Option(None, help="Filter by skill name"),
    limit: int = typer.Option(20, help="Number of runs to show"),
):
    """View run history."""
    from rich.table import Table

    from skillbench.store.history import HistoryStore

    store = HistoryStore()

    async def _list():
        return await store.list_runs(skill_name=skill, limit=limit)

    runs = _run_async(_list())

    if not runs:
        console.print("[dim]No runs found.[/dim]")
        return

    table = Table(title="Run History")
    table.add_column("Run ID", style="cyan")
    table.add_column("Skill", style="bold")
    table.add_column("Time")
    table.add_column("Adapters")
    table.add_column("Result", justify="center")

    for run in runs:
        summary = run.get("summary", {})
        passed = summary.get("passed", 0)
        total = summary.get("total_evals", 0)
        failed = total - passed

        if failed == 0 and total > 0:
            result = f"[green]{passed}/{total} PASS[/green]"
        elif total > 0:
            result = f"[red]{passed}/{total} ({failed} FAIL)[/red]"
        else:
            result = "[dim]N/A[/dim]"

        table.add_row(
            run["run_id"],
            run["skill_name"],
            run["timestamp"][:19],
            ", ".join(run.get("adapters", [])),
            result,
        )

    console.print(table)


# ─── contribute ──────────────────────────────────────────────────────────────


@app.command()
def contribute(
    path: Path = typer.Argument(..., help="Path to the improved skill directory"),
    message: str = typer.Option("", "--message", "-m", help="Description of improvements"),
):
    """Fork, branch, and PR improvements back to the source repo."""
    console.print(
        "[yellow]The contribute command is coming in v0.2.[/yellow]\n\n"
        "It will let you fork the source repo, create a branch with your skill improvements, "
        "and open a PR — all from the CLI.\n\n"
        "For now, you can manually push your changes and open a PR on GitHub."
    )


# ─── benchmark (subcommand group) ───────────────────────────────────────────

benchmark_app = typer.Typer(help="Run the top-100 benchmark suite.")
app.add_typer(benchmark_app, name="benchmark")


@benchmark_app.command("pull")
def benchmark_pull():
    """Pull all skills listed in the benchmark manifest."""
    import yaml

    from skillbench.registry.puller import pull_skill

    manifest_path = Path.cwd() / "benchmarks" / "manifest.yaml"
    if not manifest_path.exists():
        try:
            manifest_path = Path(__file__).parent.parent.parent / "benchmarks" / "manifest.yaml"
        except Exception:
            pass
    if not manifest_path.exists():
        console.print(f"[red]Benchmark manifest not found at {manifest_path}[/red]")
        raise typer.Exit(1)

    manifest = yaml.safe_load(manifest_path.read_text(encoding="utf-8"))
    skills = manifest.get("skills", [])
    console.print(f"Pulling {len(skills)} benchmark skills...\n")

    success = 0
    for entry in skills:
        source = entry["source"]
        try:
            pull_skill(source)
            console.print(f"  [green]OK[/green] {entry['name']} ({source})")
            success += 1
        except Exception as e:
            console.print(f"  [red]FAIL[/red] {entry['name']}: {e}")

    console.print(f"\n[green]Pulled {success}/{len(skills)} skills[/green]")


@benchmark_app.command("run")
def benchmark_run(
    frameworks: str = typer.Option("claude", help="Comma-separated adapters"),
    output: Optional[Path] = typer.Option(None, "-o", help="Output directory for results"),
):
    """Run evaluations on all benchmark skills."""
    console.print(
        "[yellow]Benchmark run is a long operation"
        " — use 'skillbench eval' for individual skills.[/yellow]"
    )
    console.print("Full benchmark runner coming in a future release.")


@benchmark_app.command("report")
def benchmark_report():
    """Generate the ecosystem scorecard from benchmark results."""
    console.print("[yellow]Benchmark reporting coming in a future release.[/yellow]")


# ─── adapter registry ────────────────────────────────────────────────────────


def _get_adapter_map() -> dict:
    """Return a mapping of adapter name -> factory callable."""
    from skillbench.adapters.aider import AiderAdapter
    from skillbench.adapters.claude_api import ClaudeAdapter
    from skillbench.adapters.claude_code import ClaudeCodeAdapter
    from skillbench.adapters.codex import CodexAdapter
    from skillbench.adapters.cursor import CursorAdapter
    from skillbench.adapters.openai_api import OpenAIAdapter
    from skillbench.adapters.opencode import OpenCodeAdapter

    return {
        "claude": ClaudeAdapter,
        "openai": OpenAIAdapter,
        "azure": lambda: OpenAIAdapter(provider="azure"),
        "claude-code": ClaudeCodeAdapter,
        "cursor": CursorAdapter,
        "codex": CodexAdapter,
        "aider": AiderAdapter,
        "opencode": OpenCodeAdapter,
    }


# ─── helpers ─────────────────────────────────────────────────────────────────


async def _save_to_history(report, skill) -> None:
    try:
        from skillbench.store.history import HistoryStore

        store = HistoryStore()
        await store.save_run(
            run_id=report.run_id,
            skill_name=report.skill_name,
            skill_hash=report.skill_hash,
            source_repo=skill.source_repo,
            timestamp=report.timestamp,
            adapters=report.adapters_used,
            summary=report.summary(),
            full_report={"adapters": report.adapters_used},
        )
    except Exception as e:
        import warnings

        warnings.warn(f"Could not save run to history: {e}", stacklevel=1)
