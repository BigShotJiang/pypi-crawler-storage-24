"""Report generation — terminal output (Rich) and JSON export."""

from __future__ import annotations

import json
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from skillbench.core.runner import SuiteRunReport


def print_report(report: SuiteRunReport, console: Console | None = None) -> None:
    """Print a rich terminal report for a suite run."""
    if console is None:
        console = Console()

    summary = report.summary()

    header = Text()
    header.append("SkillBench Eval Report\n", style="bold cyan")
    header.append(f"Skill: {report.skill_name}  ", style="bold")
    header.append(f"Run: {report.run_id}\n", style="dim")
    header.append(f"Adapters: {', '.join(report.adapters_used)}\n")
    header.append(f"Time: {report.timestamp}")
    console.print(Panel(header, border_style="cyan"))

    table = Table(title="Scenario Results", show_lines=True)
    table.add_column("Scenario", style="bold")
    for adapter in report.adapters_used:
        table.add_column(adapter, justify="center")

    for sr in report.scenario_reports:
        row = [sr.scenario.name]
        for adapter in report.adapters_used:
            eval_result = sr.evals.get(adapter)
            if eval_result is None:
                row.append("[dim]N/A[/dim]")
            elif not eval_result.run_success:
                row.append(f"[red]ERROR[/red]\n{eval_result.error or ''}")
            elif eval_result.overall_pass:
                row.append(f"[green]PASS[/green] ({eval_result.overall_score:.0%})")
            else:
                row.append(f"[red]FAIL[/red] ({eval_result.overall_score:.0%})")

        table.add_row(*row)

    console.print(table)

    # Assertion details for failures
    for sr in report.scenario_reports:
        for adapter_name, eval_result in sr.evals.items():
            if eval_result.run_success and not eval_result.overall_pass:
                console.print(
                    f"\n[yellow]Failures in {sr.scenario.name} ({adapter_name}):[/yellow]"
                )
                for ar in eval_result.assertion_results:
                    if not ar.passed:
                        console.print(
                            f"  [red]FAIL[/red] [{ar.assertion.type}] {ar.message}"
                        )

    # Summary
    total = summary["total_evals"]
    passed = summary["passed"]
    failed = summary["failed"]
    rate = (passed / total * 100) if total > 0 else 0

    style = "green" if failed == 0 else "yellow" if rate >= 50 else "red"
    console.print(
        f"\n[{style}]Results: {passed}/{total} passed ({rate:.0f}%)[/{style}]"
    )


def export_json(report: SuiteRunReport, path: Path | None = None) -> str:
    """Export a suite run report as JSON."""
    data = {
        "run_id": report.run_id,
        "skill_name": report.skill_name,
        "skill_hash": report.skill_hash,
        "timestamp": report.timestamp,
        "adapters": report.adapters_used,
        "summary": report.summary(),
        "scenarios": [],
    }

    for sr in report.scenario_reports:
        scenario_data = {
            "name": sr.scenario.name,
            "description": sr.scenario.description,
            "prompt": sr.scenario.prompt,
            "tags": sr.scenario.tags,
            "results": {},
        }

        for adapter_name, eval_result in sr.evals.items():
            run_result = sr.results.get(adapter_name)
            adapter_data = {
                "run_success": eval_result.run_success,
                "overall_pass": eval_result.overall_pass,
                "overall_score": eval_result.overall_score,
                "error": eval_result.error,
                "assertions": [],
            }

            for ar in eval_result.assertion_results:
                adapter_data["assertions"].append(
                    {
                        "type": ar.assertion.type,
                        "passed": ar.passed,
                        "score": ar.score,
                        "message": ar.message,
                    }
                )

            if run_result:
                adapter_data["tokens_in"] = run_result.tokens_in
                adapter_data["tokens_out"] = run_result.tokens_out
                adapter_data["latency_ms"] = run_result.latency_ms
                adapter_data["tool_calls"] = [
                    {"name": tc.name, "arguments": tc.arguments}
                    for tc in run_result.tool_calls
                ]

            scenario_data["results"][adapter_name] = adapter_data

        data["scenarios"].append(scenario_data)

    json_str = json.dumps(data, indent=2)

    if path:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json_str, encoding="utf-8")

    return json_str
