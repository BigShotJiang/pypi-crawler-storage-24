"""Allow running skillbench as `python -m skillbench`."""

from skillbench.cli import app

app()
