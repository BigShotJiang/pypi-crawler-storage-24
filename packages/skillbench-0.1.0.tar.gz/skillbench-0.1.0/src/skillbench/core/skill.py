"""SKILL.md parser, loader, and validator per the Agent Skills specification."""

from __future__ import annotations

import hashlib
import re
from pathlib import Path
from typing import Any

import frontmatter
from pydantic import BaseModel, Field, field_validator

_NAME_PATTERN = re.compile(r"^[a-z0-9]([a-z0-9-]*[a-z0-9])?$")
_CONSECUTIVE_HYPHENS = re.compile(r"--")


class SkillMetadata(BaseModel):
    """Parsed YAML frontmatter from a SKILL.md file."""

    name: str
    description: str
    license: str | None = None
    compatibility: str | None = None
    metadata: dict[str, str] = Field(default_factory=dict)
    allowed_tools: list[str] = Field(default_factory=list)

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        if not v:
            raise ValueError("name must not be empty")
        if len(v) > 64:
            raise ValueError(f"name must be <= 64 characters, got {len(v)}")
        if not _NAME_PATTERN.match(v):
            raise ValueError(
                f"name must contain only lowercase alphanumeric and hyphens, "
                f"and must not start/end with a hyphen: {v!r}"
            )
        if _CONSECUTIVE_HYPHENS.search(v):
            raise ValueError(f"name must not contain consecutive hyphens: {v!r}")
        return v

    @field_validator("description")
    @classmethod
    def validate_description(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("description must not be empty")
        if len(v) > 1024:
            raise ValueError(f"description must be <= 1024 characters, got {len(v)}")
        return v


class ValidationIssue(BaseModel):
    """A single validation issue found in a skill."""

    level: str  # "error" or "warning"
    message: str
    field: str | None = None


class Skill(BaseModel):
    """A fully loaded Agent Skill."""

    metadata: SkillMetadata
    body: str
    location: Path
    source_repo: str | None = None
    content_hash: str = ""

    model_config = {"arbitrary_types_allowed": True}

    @property
    def name(self) -> str:
        return self.metadata.name

    @property
    def description(self) -> str:
        return self.metadata.description

    @property
    def skill_dir(self) -> Path:
        return self.location.parent

    def resource_paths(self) -> list[Path]:
        """List bundled resources (scripts/, references/, assets/)."""
        resources = []
        for subdir in ("scripts", "references", "assets"):
            d = self.skill_dir / subdir
            if d.is_dir():
                resources.extend(sorted(d.rglob("*")))
        return [p for p in resources if p.is_file()]


def _compute_hash(content: str) -> str:
    return hashlib.sha256(content.encode()).hexdigest()[:16]


def _parse_allowed_tools(raw: Any) -> list[str]:
    if isinstance(raw, str):
        return raw.split()
    if isinstance(raw, list):
        return [str(t) for t in raw]
    return []


def load_skill(path: Path, *, source_repo: str | None = None) -> Skill:
    """Load and parse a SKILL.md file into a Skill object.

    Args:
        path: Path to a SKILL.md file or the directory containing it.
        source_repo: Optional source repo identifier (owner/repo).

    Raises:
        FileNotFoundError: If no SKILL.md is found.
        ValueError: If the frontmatter is unparseable or missing required fields.
    """
    if path.is_dir():
        path = path / "SKILL.md"
    if not path.exists():
        raise FileNotFoundError(f"No SKILL.md found at {path}")

    raw = path.read_text(encoding="utf-8")
    post = frontmatter.loads(raw)

    fm: dict[str, Any] = dict(post.metadata)
    if "name" not in fm:
        raise ValueError(f"SKILL.md missing required 'name' field: {path}")
    if "description" not in fm:
        raise ValueError(f"SKILL.md missing required 'description' field: {path}")

    allowed_tools = _parse_allowed_tools(fm.pop("allowed-tools", fm.pop("allowed_tools", [])))

    meta = SkillMetadata(
        name=fm["name"],
        description=fm["description"],
        license=fm.get("license"),
        compatibility=fm.get("compatibility"),
        metadata=fm.get("metadata", {}),
        allowed_tools=allowed_tools,
    )

    return Skill(
        metadata=meta,
        body=post.content,
        location=path.resolve(),
        source_repo=source_repo,
        content_hash=_compute_hash(raw),
    )


def validate_skill(path: Path) -> list[ValidationIssue]:
    """Validate a skill directory against the Agent Skills spec.

    Returns a list of issues (errors and warnings). An empty list means valid.
    """
    issues: list[ValidationIssue] = []

    if path.is_dir():
        skill_md = path / "SKILL.md"
    else:
        skill_md = path
        path = path.parent

    if not skill_md.exists():
        issues.append(ValidationIssue(level="error", message="SKILL.md not found", field="file"))
        return issues

    raw = skill_md.read_text(encoding="utf-8")

    try:
        post = frontmatter.loads(raw)
    except Exception as e:
        issues.append(
            ValidationIssue(level="error", message=f"YAML frontmatter parse error: {e}")
        )
        return issues

    fm: dict[str, Any] = dict(post.metadata)

    if "name" not in fm:
        issues.append(
            ValidationIssue(level="error", message="Missing required field 'name'", field="name")
        )
    else:
        name = fm["name"]
        if len(name) > 64:
            issues.append(
                ValidationIssue(
                    level="warning",
                    message=f"name exceeds 64 chars ({len(name)})",
                    field="name",
                )
            )
        if not _NAME_PATTERN.match(name):
            issues.append(
                ValidationIssue(
                    level="warning",
                    message=f"name has invalid characters: {name!r}",
                    field="name",
                )
            )
        if _CONSECUTIVE_HYPHENS.search(name):
            issues.append(
                ValidationIssue(
                    level="warning",
                    message="name contains consecutive hyphens",
                    field="name",
                )
            )
        expected_dir_name = name
        if path.name != expected_dir_name:
            issues.append(
                ValidationIssue(
                    level="warning",
                    message=f"Directory name '{path.name}' does not match skill name '{name}'",
                    field="name",
                )
            )

    if "description" not in fm:
        issues.append(
            ValidationIssue(
                level="error", message="Missing required field 'description'", field="description"
            )
        )
    elif not fm["description"] or not str(fm["description"]).strip():
        issues.append(
            ValidationIssue(level="error", message="description is empty", field="description")
        )
    elif len(str(fm["description"])) > 1024:
        issues.append(
            ValidationIssue(
                level="warning",
                message=f"description exceeds 1024 chars ({len(fm['description'])})",
                field="description",
            )
        )

    if not post.content or not post.content.strip():
        issues.append(
            ValidationIssue(
                level="warning",
                message="SKILL.md body is empty — skills should include instructions",
            )
        )

    body_lines = post.content.strip().splitlines() if post.content else []
    if len(body_lines) > 500:
        issues.append(
            ValidationIssue(
                level="warning",
                message=f"SKILL.md body has {len(body_lines)} lines (recommended < 500)",
            )
        )

    return issues
