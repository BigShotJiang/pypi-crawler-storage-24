"""AI-assisted scenario generation from SKILL.md content."""

from __future__ import annotations

import os
from pathlib import Path

from skillbench.core.skill import Skill

_GENERATION_PROMPT = """\
You are an expert at writing evaluation scenarios for Agent Skills.

Given a SKILL.md file, generate a comprehensive set of test scenarios in YAML format.

## Rules
1. Generate 3-8 scenarios covering:
   - Happy-path scenarios for each documented capability
   - Edge-case scenarios for error conditions and boundary cases
   - At least one scenario testing the skill's description accuracy
2. Each scenario needs:
   - A clear `name` (kebab-case)
   - A `description` of what is being tested
   - A realistic `prompt` (what a user would actually say)
   - `assertions` with mix of deterministic checks and `llm_judge` criteria
   - Relevant `tags` (e.g., core, edge-case, error-handling)
3. Assertions should be specific and testable
4. Prompts should be natural language, not overly technical

## Output Format
Return ONLY valid YAML (no markdown code fences). The format must be:

skill: <skill-name>
environment:
  os: any
  tools: [Bash, Read, Write]
scenarios:
  - name: scenario-name
    description: "What this tests"
    prompt: "What the user says"
    assertions:
      - type: llm_judge
        criteria: "Specific criteria to evaluate"
    tags: [tag1, tag2]

## SKILL.md Content

Name: {name}
Description: {description}

---

{body}
"""


async def generate_scenarios(
    skill: Skill,
    *,
    model: str = "claude-sonnet-4-20250514",
    output_path: Path | None = None,
) -> str:
    """Generate evaluation scenarios for a skill using an LLM.

    Args:
        skill: The loaded skill to generate scenarios for.
        model: The model to use for generation.
        output_path: If provided, write the YAML to this path.

    Returns:
        The generated YAML string.
    """
    if not os.environ.get("ANTHROPIC_API_KEY"):
        raise RuntimeError("ANTHROPIC_API_KEY required for scenario generation")

    import anthropic

    client = anthropic.AsyncAnthropic()

    prompt = _GENERATION_PROMPT.format(
        name=skill.name,
        description=skill.description,
        body=skill.body[:8000],
    )

    response = await client.messages.create(
        model=model,
        max_tokens=4096,
        messages=[{"role": "user", "content": prompt}],
    )

    yaml_content = response.content[0].text

    if yaml_content.startswith("```"):
        lines = yaml_content.split("\n")
        yaml_content = "\n".join(
            lines[1:-1] if lines[-1].strip() == "```" else lines[1:]
        )

    if output_path:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(yaml_content, encoding="utf-8")

    return yaml_content
