"""Scenario runner — orchestrates scenario execution across framework adapters."""

from __future__ import annotations

import asyncio
import shutil
import tempfile
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from skillbench.adapters.base import FrameworkAdapter, RunResult
from skillbench.core.evaluator import EvalResult, evaluate_run
from skillbench.core.scenario import Scenario, ScenarioSuite
from skillbench.core.skill import Skill


@dataclass
class ScenarioRunReport:
    """Results of running a single scenario across adapters."""

    scenario: Scenario
    results: dict[str, RunResult] = field(default_factory=dict)
    evals: dict[str, EvalResult] = field(default_factory=dict)


@dataclass
class SuiteRunReport:
    """Full results of running an entire scenario suite."""

    run_id: str
    skill_name: str
    skill_hash: str
    timestamp: str
    adapters_used: list[str]
    scenario_reports: list[ScenarioRunReport] = field(default_factory=list)

    @property
    def total_scenarios(self) -> int:
        return len(self.scenario_reports)

    @property
    def passed(self) -> int:
        count = 0
        for report in self.scenario_reports:
            for eval_result in report.evals.values():
                if eval_result.overall_pass:
                    count += 1
        return count

    @property
    def failed(self) -> int:
        count = 0
        for report in self.scenario_reports:
            for eval_result in report.evals.values():
                if not eval_result.overall_pass:
                    count += 1
        return count

    def summary(self) -> dict:
        return {
            "run_id": self.run_id,
            "skill": self.skill_name,
            "timestamp": self.timestamp,
            "total_scenarios": self.total_scenarios,
            "total_evals": self.passed + self.failed,
            "passed": self.passed,
            "failed": self.failed,
        }


async def run_suite(
    skill: Skill,
    suite: ScenarioSuite,
    adapters: list[FrameworkAdapter],
    *,
    tags: list[str] | None = None,
    llm_judge_model: str = "claude-sonnet-4-20250514",
) -> SuiteRunReport:
    """Run all scenarios in a suite across all adapters and evaluate results."""
    run_id = uuid.uuid4().hex[:12]
    scenarios = suite.filter_by_tags(tags) if tags else suite.scenarios

    report = SuiteRunReport(
        run_id=run_id,
        skill_name=skill.name,
        skill_hash=skill.content_hash,
        timestamp=datetime.now(timezone.utc).isoformat(),
        adapters_used=[a.name for a in adapters],
    )

    for scenario in scenarios:
        scenario_report = ScenarioRunReport(scenario=scenario)

        tasks = []
        for adapter in adapters:
            tasks.append(_run_and_eval(skill, scenario, adapter, llm_judge_model))

        results = await asyncio.gather(*tasks, return_exceptions=True)

        for adapter, result in zip(adapters, results):
            if isinstance(result, Exception):
                scenario_report.results[adapter.name] = RunResult(
                    scenario_name=scenario.name,
                    adapter_name=adapter.name,
                    success=False,
                    error=str(result),
                )
                scenario_report.evals[adapter.name] = EvalResult(
                    scenario_name=scenario.name,
                    adapter_name=adapter.name,
                    run_success=False,
                    error=str(result),
                )
            else:
                run_result, eval_result = result
                scenario_report.results[adapter.name] = run_result
                scenario_report.evals[adapter.name] = eval_result

        report.scenario_reports.append(scenario_report)

    return report


async def _run_and_eval(
    skill: Skill,
    scenario: Scenario,
    adapter: FrameworkAdapter,
    llm_judge_model: str,
) -> tuple[RunResult, EvalResult]:
    """Run a scenario and evaluate the result."""
    workspace = Path(tempfile.mkdtemp(prefix="skillbench_"))
    try:
        _setup_workspace(workspace, scenario)
        run_result = await adapter.run_scenario(skill, scenario, workspace)
        eval_result = await evaluate_run(scenario, run_result, llm_judge_model=llm_judge_model)
        return run_result, eval_result
    finally:
        shutil.rmtree(workspace, ignore_errors=True)


def _setup_workspace(workspace: Path, scenario: Scenario) -> None:
    """Create any fixture files in the workspace before running."""
    for setup_file in scenario.setup.files:
        target = workspace / setup_file.path
        target.parent.mkdir(parents=True, exist_ok=True)
        if setup_file.content:
            target.write_text(setup_file.content, encoding="utf-8")
        elif setup_file.fixture:
            fixture_path = Path(setup_file.fixture)
            if fixture_path.exists():
                shutil.copy2(fixture_path, target)
            else:
                raise FileNotFoundError(
                    f"Fixture file not found: {setup_file.fixture} "
                    f"(referenced by scenario setup for '{setup_file.path}')"
                )
