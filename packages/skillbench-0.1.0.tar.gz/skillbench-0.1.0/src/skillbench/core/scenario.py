"""Scenario data models and YAML loader for skill evaluation."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Literal

import yaml
from pydantic import BaseModel, Field


class SetupFile(BaseModel):
    """A file to create in the workspace before running a scenario."""

    path: str
    content: str | None = None
    fixture: str | None = None


class ScenarioSetup(BaseModel):
    """Pre-scenario workspace setup."""

    files: list[SetupFile] = Field(default_factory=list)
    env: dict[str, str] = Field(default_factory=dict)


class Assertion(BaseModel):
    """A single assertion to evaluate against a scenario run result."""

    type: Literal["tool_called", "file_created", "output_contains", "llm_judge"]
    tool: str | None = None
    args_contain: str | None = None
    path: str | None = None
    content: str | None = None
    value: str | None = None
    criteria: str | None = None

    def get_content(self) -> str | None:
        """Return content for output_contains — accepts either 'content' or 'value'."""
        return self.content or self.value


class Scenario(BaseModel):
    """A single test scenario for a skill."""

    name: str
    description: str
    prompt: str
    setup: ScenarioSetup = Field(default_factory=ScenarioSetup)
    assertions: list[Assertion] = Field(default_factory=list)
    tags: list[str] = Field(default_factory=list)
    expected_tools: list[str] = Field(default_factory=list)
    timeout: int = 60


class EnvironmentSpec(BaseModel):
    """Environment requirements for running scenarios."""

    os: str = "any"
    tools: list[str] = Field(default_factory=list)
    python_version: str | None = None


class ScenarioSuite(BaseModel):
    """A collection of scenarios for a skill."""

    skill: str
    environment: EnvironmentSpec = Field(default_factory=EnvironmentSpec)
    scenarios: list[Scenario] = Field(default_factory=list)

    @property
    def scenario_count(self) -> int:
        return len(self.scenarios)

    def filter_by_tags(self, tags: list[str]) -> list[Scenario]:
        if not tags:
            return self.scenarios
        tag_set = set(tags)
        return [s for s in self.scenarios if tag_set & set(s.tags)]


def load_scenarios(path: Path) -> ScenarioSuite:
    """Load scenarios from a YAML file.

    Args:
        path: Path to a scenarios YAML file, or a directory containing
              scenarios/scenarios.yaml.

    Raises:
        FileNotFoundError: If no scenario file is found.
    """
    if path.is_dir():
        candidates = [
            path / "scenarios" / "scenarios.yaml",
            path / "scenarios" / "scenarios.yml",
            path / "scenarios.yaml",
            path / "scenarios.yml",
        ]
        for candidate in candidates:
            if candidate.exists():
                path = candidate
                break
        else:
            raise FileNotFoundError(f"No scenarios file found in {path}")

    raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        raise ValueError(f"Expected a YAML mapping at top level, got {type(raw).__name__}")

    return _parse_suite(raw)


def _parse_suite(data: dict[str, Any]) -> ScenarioSuite:
    env_data = data.get("environment", {})
    environment = EnvironmentSpec(**env_data) if env_data else EnvironmentSpec()

    scenarios = []
    for s in data.get("scenarios", []):
        setup_data = s.get("setup", {})
        setup = ScenarioSetup(**setup_data) if setup_data else ScenarioSetup()

        assertions = [Assertion(**a) for a in s.get("assertions", [])]

        scenarios.append(
            Scenario(
                name=s["name"],
                description=s.get("description", ""),
                prompt=s["prompt"],
                setup=setup,
                assertions=assertions,
                tags=s.get("tags", []),
                expected_tools=s.get("expected_tools", []),
                timeout=s.get("timeout", 60),
            )
        )

    return ScenarioSuite(
        skill=data.get("skill", "unknown"),
        environment=environment,
        scenarios=scenarios,
    )


def scenarios_to_yaml(suite: ScenarioSuite) -> str:
    """Serialize a ScenarioSuite back to YAML."""
    data = {
        "skill": suite.skill,
        "environment": suite.environment.model_dump(exclude_defaults=True),
        "scenarios": [],
    }
    for s in suite.scenarios:
        scenario_data: dict[str, Any] = {
            "name": s.name,
            "description": s.description,
            "prompt": s.prompt,
        }
        if s.setup.files or s.setup.env:
            scenario_data["setup"] = s.setup.model_dump(exclude_defaults=True)
        if s.assertions:
            scenario_data["assertions"] = [
                a.model_dump(exclude_none=True) for a in s.assertions
            ]
        if s.tags:
            scenario_data["tags"] = s.tags
        if s.expected_tools:
            scenario_data["expected_tools"] = s.expected_tools
        data["scenarios"].append(scenario_data)

    return yaml.dump(data, default_flow_style=False, sort_keys=False, allow_unicode=True)
