"""Evaluator — scores RunResults against scenario assertions."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

from skillbench.adapters.base import RunResult
from skillbench.core.scenario import Assertion, Scenario


@dataclass
class AssertionResult:
    """Result of evaluating a single assertion."""

    assertion: Assertion
    passed: bool
    message: str
    score: float = 0.0  # 0.0-1.0 for graded assertions


@dataclass
class EvalResult:
    """Full evaluation result for one scenario run."""

    scenario_name: str
    adapter_name: str
    run_success: bool
    assertion_results: list[AssertionResult] = field(default_factory=list)
    overall_pass: bool = False
    overall_score: float = 0.0
    error: str | None = None

    def __post_init__(self):
        if self.assertion_results:
            self.overall_pass = all(r.passed for r in self.assertion_results)
            self.overall_score = (
                sum(r.score for r in self.assertion_results) / len(self.assertion_results)
            )


async def evaluate_run(
    scenario: Scenario,
    result: RunResult,
    *,
    llm_judge_model: str = "claude-sonnet-4-20250514",
) -> EvalResult:
    """Evaluate a RunResult against a scenario's assertions.

    Supports deterministic checks (tool_called, file_created, output_contains)
    and LLM-based judging (llm_judge).
    """
    if not result.success:
        return EvalResult(
            scenario_name=scenario.name,
            adapter_name=result.adapter_name,
            run_success=False,
            error=result.error,
        )

    assertion_results = []
    for assertion in scenario.assertions:
        ar = await _evaluate_assertion(assertion, result, llm_judge_model)
        assertion_results.append(ar)

    eval_result = EvalResult(
        scenario_name=scenario.name,
        adapter_name=result.adapter_name,
        run_success=True,
        assertion_results=assertion_results,
    )
    eval_result.__post_init__()
    return eval_result


async def _evaluate_assertion(
    assertion: Assertion,
    result: RunResult,
    llm_judge_model: str,
) -> AssertionResult:
    if assertion.type == "tool_called":
        return _check_tool_called(assertion, result)
    elif assertion.type == "file_created":
        return _check_file_created(assertion, result)
    elif assertion.type == "output_contains":
        return _check_output_contains(assertion, result)
    elif assertion.type == "llm_judge":
        return await _check_llm_judge(assertion, result, llm_judge_model)
    else:
        return AssertionResult(
            assertion=assertion,
            passed=False,
            message=f"Unknown assertion type: {assertion.type}",
        )


def _check_tool_called(assertion: Assertion, result: RunResult) -> AssertionResult:
    tool_name = assertion.tool
    if not tool_name:
        return AssertionResult(
            assertion=assertion, passed=False, message="No tool name specified in assertion"
        )

    matching_calls = [tc for tc in result.tool_calls if tc.name == tool_name]

    if not matching_calls:
        return AssertionResult(
            assertion=assertion,
            passed=False,
            message=(
                f"Tool '{tool_name}' was not called."
                f" Called: {[tc.name for tc in result.tool_calls]}"
            ),
        )

    if assertion.args_contain:
        for tc in matching_calls:
            args_str = str(tc.arguments)
            if assertion.args_contain in args_str:
                return AssertionResult(
                    assertion=assertion,
                    passed=True,
                    message=(
                        f"Tool '{tool_name}' called with args"
                        f" containing '{assertion.args_contain}'"
                    ),
                    score=1.0,
                )
        return AssertionResult(
            assertion=assertion,
            passed=False,
            message=(
                f"Tool '{tool_name}' was called but args"
                f" did not contain '{assertion.args_contain}'"
            ),
        )

    return AssertionResult(
        assertion=assertion,
        passed=True,
        message=f"Tool '{tool_name}' was called",
        score=1.0,
    )


def _check_file_created(assertion: Assertion, result: RunResult) -> AssertionResult:
    if not assertion.path:
        return AssertionResult(
            assertion=assertion, passed=False, message="No path specified in assertion"
        )

    if assertion.path in result.files_created:
        return AssertionResult(
            assertion=assertion,
            passed=True,
            message=f"File '{assertion.path}' was created",
            score=1.0,
        )
    return AssertionResult(
        assertion=assertion,
        passed=False,
        message=f"File '{assertion.path}' was not created. Created: {result.files_created}",
    )


def _check_output_contains(assertion: Assertion, result: RunResult) -> AssertionResult:
    content = assertion.get_content()
    if not content:
        return AssertionResult(
            assertion=assertion, passed=False, message="No content specified in assertion"
        )

    if content.lower() in result.response.lower():
        return AssertionResult(
            assertion=assertion,
            passed=True,
            message=f"Output contains '{content}'",
            score=1.0,
        )
    return AssertionResult(
        assertion=assertion,
        passed=False,
        message=f"Output does not contain '{content}'",
    )


def _build_judge_prompt(assertion: Assertion, result: RunResult) -> str:
    tools_summary = "\n".join(
        f"- {tc.name}({tc.arguments}) -> {(tc.result or '')[:200]}"
        for tc in result.tool_calls
    )

    return (
        f"You are an evaluation judge. Assess whether the agent's behavior meets the criteria.\n\n"
        f"## Criteria\n{assertion.criteria}\n\n"
        f"## Agent's final response\n{result.response[:2000]}\n\n"
        f"## Tools called\n{tools_summary or 'None'}\n\n"
        f"## Files created\n{', '.join(result.files_created) or 'None'}\n\n"
        f'Respond with a JSON object: {{"pass": true/false, "score": 0.0-1.0, "reason": "..."}}'
    )


def _detect_judge_backend() -> str:
    """Detect which LLM backend is available for judging.

    Returns 'anthropic', 'azure', 'openai', or 'none'.
    Derives AZURE_OPENAI_ENDPOINT from Codex config if not explicitly set.
    """
    if os.environ.get("ANTHROPIC_API_KEY"):
        return "anthropic"
    if os.environ.get("AZURE_OPENAI_API_KEY"):
        if not os.environ.get("AZURE_OPENAI_ENDPOINT"):
            _try_derive_azure_endpoint()
        if os.environ.get("AZURE_OPENAI_ENDPOINT"):
            return "azure"
    if os.environ.get("OPENAI_API_KEY"):
        return "openai"
    return "none"


def _try_derive_azure_endpoint() -> None:
    """Try to derive AZURE_OPENAI_ENDPOINT from the Codex CLI config.toml."""
    config_path = Path.home() / ".codex" / "config.toml"
    if not config_path.exists():
        return
    try:
        text = config_path.read_text()
        for line in text.splitlines():
            line = line.strip()
            if line.startswith("base_url"):
                url = line.split("=", 1)[1].strip().strip('"').strip("'")
                # base_url looks like "https://RESOURCE.openai.azure.com/openai/v1"
                # Strip the /openai/v1 suffix to get the endpoint
                for suffix in ("/openai/v1", "/openai"):
                    if url.endswith(suffix):
                        url = url[: -len(suffix)]
                        break
                os.environ["AZURE_OPENAI_ENDPOINT"] = url
                return
    except Exception:
        pass


def _parse_judge_verdict(judge_text: str, assertion: Assertion) -> AssertionResult:
    import json
    import re

    judge_text = (judge_text or "").strip()
    if not judge_text:
        return AssertionResult(
            assertion=assertion,
            passed=False,
            message="LLM judge returned empty response",
        )

    verdict = None
    try:
        start = judge_text.index("{")
        end = judge_text.rindex("}") + 1
        verdict = json.loads(judge_text[start:end])
    except (ValueError, json.JSONDecodeError):
        pass

    if verdict is None:
        # Fallback: extract pass/score/reason from truncated or malformed JSON
        pass_m = re.search(r'"pass"\s*:\s*(true|false)', judge_text, re.I)
        score_m = re.search(r'"score"\s*:\s*([\d.]+)', judge_text)
        reason_m = re.search(r'"reason"\s*:\s*"([^"]*?)(?:"|$)', judge_text)
        verdict = {
            "pass": pass_m.group(1).lower() == "true" if pass_m else False,
            "score": float(score_m.group(1)) if score_m else 0.0,
            "reason": (reason_m.group(1) or "Response truncated or malformed")[:500],
        }

    return AssertionResult(
        assertion=assertion,
        passed=verdict.get("pass", False),
        message=str(verdict.get("reason", "No reason given"))[:500],
        score=float(verdict.get("score", 0.0)),
    )


async def _judge_with_anthropic(
    prompt: str, model: str, assertion: Assertion
) -> AssertionResult:
    import anthropic

    client = anthropic.AsyncAnthropic()
    try:
        response = await client.messages.create(
            model=model,
            max_tokens=500,
            messages=[{"role": "user", "content": prompt}],
        )
        return _parse_judge_verdict(response.content[0].text, assertion)
    finally:
        await client.close()


async def _judge_with_openai(
    prompt: str, model: str, assertion: Assertion, *, provider: str = "openai"
) -> AssertionResult:
    if provider == "azure":
        from openai import AsyncAzureOpenAI

        endpoint = os.environ["AZURE_OPENAI_ENDPOINT"]
        api_version = os.environ.get("AZURE_OPENAI_API_VERSION", "2025-04-01-preview")
        client = AsyncAzureOpenAI(
            api_key=os.environ.get("AZURE_OPENAI_API_KEY"),
            azure_endpoint=endpoint,
            api_version=api_version,
        )
    else:
        from openai import AsyncOpenAI

        client = AsyncOpenAI()

    try:
        return await _try_judge_openai(client, model, prompt, assertion)
    finally:
        await client.close()


async def _try_judge_openai(client, model: str, prompt: str, assertion: Assertion) -> AssertionResult:
    """Try chat completions first, fall back to responses API for Codex models."""
    try:
        response = await client.chat.completions.create(
            model=model,
            max_completion_tokens=800,
            messages=[
                {
                    "role": "system",
                    "content": "You are an evaluation judge. Always respond with valid JSON.",
                },
                {"role": "user", "content": prompt},
            ],
        )
        judge_text = response.choices[0].message.content or ""
        return _parse_judge_verdict(judge_text, assertion)
    except Exception as chat_err:
        err_str = str(chat_err)
        if "DeploymentNotFound" not in err_str and "404" not in err_str:
            raise
    response = await client.responses.create(
        model=model,
        instructions="You are an evaluation judge. Always respond with valid JSON.",
        input=prompt,
    )
    judge_text = response.output_text or ""
    return _parse_judge_verdict(judge_text, assertion)


async def _check_llm_judge(
    assertion: Assertion,
    result: RunResult,
    model: str,
) -> AssertionResult:
    """Use an LLM to judge whether the result meets the criteria.

    Auto-detects available backend: Anthropic, Azure OpenAI, or OpenAI.
    The judge model can be overridden via SKILLBENCH_JUDGE_MODEL env var.

    For Azure, defaults to 'gpt-4o' deployment if SKILLBENCH_JUDGE_MODEL is not set,
    rather than using the test model which may not be a valid deployment name.
    """
    if not assertion.criteria:
        return AssertionResult(
            assertion=assertion, passed=False, message="No criteria specified for LLM judge"
        )

    backend = _detect_judge_backend()
    if backend == "none":
        return AssertionResult(
            assertion=assertion,
            passed=False,
            message=(
                "No LLM API key set for judge"
                " — set ANTHROPIC_API_KEY, OPENAI_API_KEY, or AZURE_OPENAI_API_KEY"
            ),
            score=0.0,
        )

    prompt = _build_judge_prompt(assertion, result)

    try:
        if backend == "anthropic":
            judge_model = os.environ.get("SKILLBENCH_JUDGE_MODEL", model)
            return await _judge_with_anthropic(prompt, judge_model, assertion)
        elif backend == "azure":
            # For Azure, default to 'gpt-4o' since test model names may not be valid deployments
            azure_model = os.environ.get("SKILLBENCH_JUDGE_MODEL", "gpt-4o")
            return await _judge_with_openai(prompt, azure_model, assertion, provider="azure")
        else:
            openai_model = os.environ.get("SKILLBENCH_JUDGE_MODEL", "gpt-4o")
            return await _judge_with_openai(prompt, openai_model, assertion, provider="openai")

    except Exception as e:
        return AssertionResult(
            assertion=assertion,
            passed=False,
            message=f"LLM judge error ({backend}): {e}",
        )
