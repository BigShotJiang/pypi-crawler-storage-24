"""OpenAI-compatible API adapter — runs scenarios via OpenAI, Azure OpenAI, or any
OpenAI-compatible endpoint (Vertex AI, Together, Groq, local vLLM, etc.)."""

from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Literal

from skillbench.adapters.base import RunResult, ToolCall
from skillbench.core.scenario import Scenario
from skillbench.core.skill import Skill

_SIMULATED_TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "Bash",
            "description": "Execute a bash command in the workspace.",
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {"type": "string", "description": "The command to run."}
                },
                "required": ["command"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "Read",
            "description": "Read a file from the workspace.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Path to the file."}
                },
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "Write",
            "description": "Write content to a file in the workspace.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Path to the file."},
                    "content": {"type": "string", "description": "Content to write."},
                },
                "required": ["path", "content"],
            },
        },
    },
]


def _build_system_prompt(skill: Skill, workspace: Path) -> str:
    return (
        f"You are an AI agent with access to tools. Your workspace is: {workspace}\n\n"
        f"You have the following skill loaded:\n\n"
        f"<skill name=\"{skill.name}\">\n{skill.body}\n</skill>\n\n"
        f"Follow the skill's instructions to complete the user's task. "
        f"Use the available tools as needed."
    )


class OpenAIAdapter:
    """Adapter that runs scenarios against OpenAI, Azure OpenAI, or any
    OpenAI-compatible API endpoint.

    Provider modes:
        "openai"  — Direct OpenAI API (OPENAI_API_KEY)
        "azure"   — Azure OpenAI Service (AZURE_OPENAI_API_KEY + AZURE_OPENAI_ENDPOINT)
        "custom"  — Any OpenAI-compatible endpoint (OPENAI_API_KEY + OPENAI_BASE_URL)

    Environment variables:
        OPENAI_API_KEY          — API key for OpenAI or custom endpoints
        OPENAI_BASE_URL         — Custom base URL (e.g. Vertex AI, vLLM, Together)
        AZURE_OPENAI_API_KEY    — Azure OpenAI API key
        AZURE_OPENAI_ENDPOINT   — Azure OpenAI endpoint URL
        AZURE_OPENAI_API_VERSION — Azure API version (default: 2025-04-01-preview)
    """

    _DEFAULT_AZURE_API_VERSION = "2025-04-01-preview"

    def __init__(
        self,
        model: str = "gpt-4o",
        max_turns: int = 10,
        provider: Literal["openai", "azure", "custom"] = "openai",
        *,
        base_url: str | None = None,
        api_key: str | None = None,
        api_version: str | None = None,
    ):
        self._model = model
        self._max_turns = max_turns
        self._provider = provider
        self._base_url = base_url
        self._api_key = api_key
        self._api_version = api_version

    @property
    def name(self) -> str:
        return f"{self._provider}:{self._model}"

    def is_available(self) -> bool:
        if self._api_key:
            return True
        if self._provider == "azure":
            return bool(
                os.environ.get("AZURE_OPENAI_API_KEY")
                and os.environ.get("AZURE_OPENAI_ENDPOINT")
            )
        return bool(os.environ.get("OPENAI_API_KEY"))

    def _create_client(self):
        """Create the appropriate async client based on provider."""
        if self._provider == "azure":
            from openai import AsyncAzureOpenAI

            endpoint = self._base_url or os.environ["AZURE_OPENAI_ENDPOINT"]
            api_version = (
                self._api_version
                or os.environ.get("AZURE_OPENAI_API_VERSION", self._DEFAULT_AZURE_API_VERSION)
            )
            return AsyncAzureOpenAI(
                api_key=self._api_key or os.environ.get("AZURE_OPENAI_API_KEY"),
                azure_endpoint=endpoint,
                api_version=api_version,
            )

        from openai import AsyncOpenAI

        kwargs = {}
        if self._api_key:
            kwargs["api_key"] = self._api_key
        if self._base_url or os.environ.get("OPENAI_BASE_URL"):
            kwargs["base_url"] = self._base_url or os.environ.get("OPENAI_BASE_URL")
        return AsyncOpenAI(**kwargs)

    async def run_scenario(
        self,
        skill: Skill,
        scenario: Scenario,
        workspace: Path,
    ) -> RunResult:
        try:
            import openai as _  # noqa: F401
        except ImportError:
            return RunResult(
                scenario_name=scenario.name,
                adapter_name=self.name,
                success=False,
                error="openai package not installed",
            )

        if not self.is_available():
            missing = (
                "AZURE_OPENAI_API_KEY and AZURE_OPENAI_ENDPOINT"
                if self._provider == "azure"
                else "OPENAI_API_KEY"
            )
            return RunResult(
                scenario_name=scenario.name,
                adapter_name=self.name,
                success=False,
                error=f"{missing} not set",
            )

        client = self._create_client()
        system = _build_system_prompt(skill, workspace)
        messages: list[dict] = [
            {"role": "system", "content": system},
            {"role": "user", "content": scenario.prompt},
        ]
        tool_calls_collected: list[ToolCall] = []
        files_created: list[str] = []
        total_in = 0
        total_out = 0

        start = time.monotonic()

        try:
            for _ in range(self._max_turns):
                response = await client.chat.completions.create(
                    model=self._model,
                    messages=messages,
                    tools=_SIMULATED_TOOLS,
                    max_completion_tokens=4096,
                )

                choice = response.choices[0]
                usage = response.usage
                if usage:
                    total_in += usage.prompt_tokens
                    total_out += usage.completion_tokens

                if choice.finish_reason != "tool_calls" or not choice.message.tool_calls:
                    final_response = choice.message.content or ""
                    break

                messages.append(choice.message.model_dump())

                for tc in choice.message.tool_calls:
                    fn = tc.function
                    try:
                        args = json.loads(fn.arguments) if fn.arguments else {}
                    except json.JSONDecodeError:
                        args = {"raw": fn.arguments}

                    tool_call = ToolCall(name=fn.name, arguments=args)
                    result_text = _simulate_tool(fn.name, args, workspace, files_created)
                    tool_call.result = result_text
                    tool_calls_collected.append(tool_call)

                    messages.append(
                        {
                            "role": "tool",
                            "tool_call_id": tc.id,
                            "content": result_text,
                        }
                    )
            else:
                final_response = "[max turns reached]"

            elapsed = (time.monotonic() - start) * 1000

            return RunResult(
                scenario_name=scenario.name,
                adapter_name=self.name,
                success=True,
                response=final_response,
                tool_calls=tool_calls_collected,
                tokens_in=total_in,
                tokens_out=total_out,
                latency_ms=elapsed,
                files_created=files_created,
                raw_messages=messages,
            )

        except Exception as e:
            elapsed = (time.monotonic() - start) * 1000
            error_msg = str(e)
            if self._provider == "azure" and "404" in error_msg:
                endpoint = self._base_url or os.environ.get("AZURE_OPENAI_ENDPOINT", "?")
                api_ver = (
                    self._api_version
                    or os.environ.get("AZURE_OPENAI_API_VERSION", self._DEFAULT_AZURE_API_VERSION)
                )
                error_msg = (
                    f"{error_msg}\n\n"
                    f"  Endpoint:    {endpoint}\n"
                    f"  Deployment:  {self._model}\n"
                    f"  API Version: {api_ver}\n\n"
                    f"  Check that the deployment name matches exactly "
                    f"(Azure Portal > your resource > Model deployments).\n"
                    f"  Also verify the API version supports your model."
                )
            return RunResult(
                scenario_name=scenario.name,
                adapter_name=self.name,
                success=False,
                error=error_msg,
                tool_calls=tool_calls_collected,
                latency_ms=elapsed,
            )
        finally:
            await client.close()


def _simulate_tool(
    name: str, args: dict, workspace: Path, files_created: list[str]
) -> str:
    """Simulate tool execution in the workspace sandbox."""
    if name == "Read":
        target = workspace / args.get("path", "")
        if target.exists():
            return target.read_text(encoding="utf-8", errors="replace")[:4000]
        return f"Error: File not found: {args.get('path')}"

    if name == "Write":
        target = workspace / args.get("path", "")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(args.get("content", ""), encoding="utf-8")
        files_created.append(str(args.get("path", "")))
        return f"Wrote {len(args.get('content', ''))} bytes to {args.get('path')}"

    if name == "Bash":
        return (
            f"[simulated] Would execute: {args.get('command', '')}\n"
            f"(Tool execution is simulated in eval mode)"
        )

    return f"Unknown tool: {name}"
