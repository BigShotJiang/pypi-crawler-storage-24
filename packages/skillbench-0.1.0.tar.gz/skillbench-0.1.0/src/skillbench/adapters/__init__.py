"""Framework adapters for running Agent Skills across different agent runtimes."""

from skillbench.adapters.aider import AiderAdapter
from skillbench.adapters.claude_api import ClaudeAdapter
from skillbench.adapters.claude_code import ClaudeCodeAdapter
from skillbench.adapters.codex import CodexAdapter
from skillbench.adapters.cursor import CursorAdapter
from skillbench.adapters.openai_api import OpenAIAdapter
from skillbench.adapters.opencode import OpenCodeAdapter

__all__ = [
    "AiderAdapter",
    "ClaudeAdapter",
    "ClaudeCodeAdapter",
    "CodexAdapter",
    "CursorAdapter",
    "OpenAIAdapter",
    "OpenCodeAdapter",
]
