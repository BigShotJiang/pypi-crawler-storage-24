"""Claude Code CLI adapter — runs scenarios via the `claude` CLI in print mode."""

from __future__ import annotations

import asyncio
import json
import shutil
import time
from pathlib import Path

from skillbench.adapters.base import RunResult, ToolCall
from skillbench.core.scenario import Scenario
from skillbench.core.skill import Skill


def _install_skill(skill: Skill, workspace: Path) -> None:
    """Install a skill into the workspace's .claude/skills/ directory."""
    skills_dir = workspace / ".claude" / "skills" / skill.name
    skills_dir.mkdir(parents=True, exist_ok=True)

    shutil.copy2(skill.location, skills_dir / "SKILL.md")

    for subdir in ("scripts", "references", "assets"):
        src = skill.skill_dir / subdir
        if src.is_dir():
            shutil.copytree(src, skills_dir / subdir, dirs_exist_ok=True)


def _parse_json_output(raw: str) -> dict:
    """Parse Claude Code's JSON output, handling stream-json or single JSON."""
    lines = raw.strip().splitlines()
    result_event = None
    tool_calls = []
    messages = []

    for line in lines:
        line = line.strip()
        if not line:
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue

        event_type = event.get("type")

        if event_type == "result":
            result_event = event
        elif event_type == "tool_call":
            tool_calls.append(event)
        elif event_type == "assistant":
            messages.append(event)

    if result_event:
        return {
            "result": result_event,
            "tool_calls": tool_calls,
            "messages": messages,
        }

    # Single JSON blob (non-streaming)
    if lines:
        try:
            return {"result": json.loads(lines[-1]), "tool_calls": [], "messages": []}
        except json.JSONDecodeError:
            pass

    return {"result": None, "tool_calls": [], "messages": [], "raw": raw}


def _extract_tool_calls(parsed: dict) -> list[ToolCall]:
    """Extract ToolCall objects from parsed Claude Code output."""
    calls = []
    for tc_event in parsed.get("tool_calls", []):
        tc_data = tc_event.get("tool_call", tc_event)
        name = "unknown"
        arguments = {}
        result = None

        for key in ("bashToolCall", "readToolCall", "writeToolCall", "editToolCall"):
            if key in tc_data:
                inner = tc_data[key]
                name = key.replace("ToolCall", "").title()
                if name == "Bash":
                    arguments = {"command": inner.get("args", {}).get("command", "")}
                elif name == "Read":
                    arguments = {"path": inner.get("args", {}).get("path", "")}
                elif name == "Write":
                    arguments = {
                        "path": inner.get("args", {}).get("path", ""),
                        "content": inner.get("args", {}).get("content", ""),
                    }
                elif name == "Edit":
                    arguments = inner.get("args", {})
                result_data = inner.get("result", {})
                if isinstance(result_data, dict):
                    result = json.dumps(result_data)
                break

        if "tool_name" in tc_data:
            name = tc_data["tool_name"]
            arguments = tc_data.get("tool_input", {})

        calls.append(ToolCall(name=name, arguments=arguments, result=result))

    return calls


def _extract_response_text(parsed: dict) -> str:
    """Extract the final response text from parsed output."""
    result = parsed.get("result")
    if not result:
        return parsed.get("raw", "")

    if isinstance(result, dict):
        # stream-json result event
        if "result" in result:
            return result["result"]
        # Plain JSON output
        content = result.get("content", result.get("message", ""))
        if isinstance(content, list):
            return "\n".join(
                block.get("text", "") for block in content if block.get("type") == "text"
            )
        return str(content)

    return str(result)


class ClaudeCodeAdapter:
    """Adapter that runs scenarios through the Claude Code CLI.

    Requires the `claude` CLI to be installed and authenticated.
    Uses print mode (-p) with JSON output for structured results.

    Environment variables:
        ANTHROPIC_API_KEY — Used by claude CLI for authentication
    """

    def __init__(
        self,
        model: str | None = None,
        max_turns: int = 10,
        timeout: int = 120,
    ):
        self._model = model
        self._max_turns = max_turns
        self._timeout = timeout

    @property
    def name(self) -> str:
        model_str = self._model or "default"
        return f"claude-code:{model_str}"

    def is_available(self) -> bool:
        return shutil.which("claude") is not None

    async def run_scenario(
        self,
        skill: Skill,
        scenario: Scenario,
        workspace: Path,
    ) -> RunResult:
        if not self.is_available():
            return RunResult(
                scenario_name=scenario.name,
                adapter_name=self.name,
                success=False,
                error="claude CLI not found. Install from https://docs.anthropic.com/en/docs/claude-code",
            )

        _install_skill(skill, workspace)

        files_before: set[str] = set()
        for f in workspace.rglob("*"):
            if f.is_file():
                files_before.add(str(f.relative_to(workspace)))

        cmd = [
            "claude",
            "-p", scenario.prompt,
            "--output-format", "stream-json",
            "--max-turns", str(self._max_turns),
            "--dangerously-skip-permissions",
        ]
        if self._model:
            cmd.extend(["--model", self._model])

        start = time.monotonic()

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(workspace),
            )

            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=self._timeout
            )
            elapsed = (time.monotonic() - start) * 1000

            raw_output = stdout.decode("utf-8", errors="replace")

            if proc.returncode != 0:
                error_msg = stderr.decode("utf-8", errors="replace").strip()
                return RunResult(
                    scenario_name=scenario.name,
                    adapter_name=self.name,
                    success=False,
                    error=f"claude CLI exited with code {proc.returncode}: {error_msg}",
                    response=raw_output,
                    latency_ms=elapsed,
                )

            parsed = _parse_json_output(raw_output)
            tool_calls = _extract_tool_calls(parsed)
            response_text = _extract_response_text(parsed)

            files_after: set[str] = set()
            for f in workspace.rglob("*"):
                if f.is_file():
                    files_after.add(str(f.relative_to(workspace)))
            files_created = sorted(files_after - files_before)

            result_event = parsed.get("result", {})
            tokens_in = 0
            tokens_out = 0
            if isinstance(result_event, dict):
                usage = result_event.get("usage", {})
                tokens_in = usage.get("input_tokens", 0)
                tokens_out = usage.get("output_tokens", 0)

            return RunResult(
                scenario_name=scenario.name,
                adapter_name=self.name,
                success=True,
                response=response_text,
                tool_calls=tool_calls,
                tokens_in=tokens_in,
                tokens_out=tokens_out,
                latency_ms=elapsed,
                files_created=files_created,
            )

        except asyncio.TimeoutError:
            elapsed = (time.monotonic() - start) * 1000
            return RunResult(
                scenario_name=scenario.name,
                adapter_name=self.name,
                success=False,
                error=f"claude CLI timed out after {self._timeout}s",
                latency_ms=elapsed,
            )
        except Exception as e:
            elapsed = (time.monotonic() - start) * 1000
            return RunResult(
                scenario_name=scenario.name,
                adapter_name=self.name,
                success=False,
                error=str(e),
                latency_ms=elapsed,
            )
