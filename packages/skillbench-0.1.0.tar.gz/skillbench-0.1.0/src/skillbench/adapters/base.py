"""Base adapter protocol and shared types for framework adapters."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Protocol, runtime_checkable

from skillbench.core.scenario import Scenario
from skillbench.core.skill import Skill


@dataclass
class ToolCall:
    """A single tool call made by the agent during a scenario run."""

    name: str
    arguments: dict
    result: str | None = None


@dataclass
class RunResult:
    """Result of running a single scenario through a framework adapter."""

    scenario_name: str
    adapter_name: str
    success: bool
    response: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)
    error: str | None = None
    tokens_in: int = 0
    tokens_out: int = 0
    latency_ms: float = 0.0
    files_created: list[str] = field(default_factory=list)
    raw_messages: list[dict] = field(default_factory=list)


@runtime_checkable
class FrameworkAdapter(Protocol):
    """Protocol that all framework adapters must implement."""

    @property
    def name(self) -> str: ...

    async def run_scenario(
        self,
        skill: Skill,
        scenario: Scenario,
        workspace: Path,
    ) -> RunResult:
        """Execute a scenario and return structured results."""
        ...

    def is_available(self) -> bool:
        """Check if the framework is installed/configured."""
        ...
