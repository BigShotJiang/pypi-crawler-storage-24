"""Claude API adapter — runs scenarios via Anthropic's tool-use API."""

from __future__ import annotations

import os
import time
from pathlib import Path

from skillbench.adapters.base import RunResult, ToolCall
from skillbench.core.scenario import Scenario
from skillbench.core.skill import Skill

_SIMULATED_TOOLS = [
    {
        "name": "Bash",
        "description": "Execute a bash command in the workspace.",
        "input_schema": {
            "type": "object",
            "properties": {
                "command": {"type": "string", "description": "The command to run."}
            },
            "required": ["command"],
        },
    },
    {
        "name": "Read",
        "description": "Read a file from the workspace.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Path to the file to read."}
            },
            "required": ["path"],
        },
    },
    {
        "name": "Write",
        "description": "Write content to a file in the workspace.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Path to the file."},
                "content": {"type": "string", "description": "Content to write."},
            },
            "required": ["path", "content"],
        },
    },
]


def _build_system_prompt(skill: Skill, workspace: Path) -> str:
    return (
        f"You are an AI agent with access to tools. Your workspace is: {workspace}\n\n"
        f"You have the following skill loaded:\n\n"
        f"<skill name=\"{skill.name}\">\n{skill.body}\n</skill>\n\n"
        f"Follow the skill's instructions to complete the user's task. "
        f"Use the available tools as needed."
    )


class ClaudeAdapter:
    """Adapter that runs scenarios against Anthropic's Claude API with tool use."""

    def __init__(self, model: str = "claude-sonnet-4-20250514", max_turns: int = 10):
        self._model = model
        self._max_turns = max_turns

    @property
    def name(self) -> str:
        return f"claude:{self._model}"

    def is_available(self) -> bool:
        return bool(os.environ.get("ANTHROPIC_API_KEY"))

    async def run_scenario(
        self,
        skill: Skill,
        scenario: Scenario,
        workspace: Path,
    ) -> RunResult:
        try:
            import anthropic
        except ImportError:
            return RunResult(
                scenario_name=scenario.name,
                adapter_name=self.name,
                success=False,
                error="anthropic package not installed",
            )

        if not self.is_available():
            return RunResult(
                scenario_name=scenario.name,
                adapter_name=self.name,
                success=False,
                error="ANTHROPIC_API_KEY not set",
            )

        client = anthropic.AsyncAnthropic()
        system = _build_system_prompt(skill, workspace)
        messages: list[dict] = [{"role": "user", "content": scenario.prompt}]
        tool_calls: list[ToolCall] = []
        files_created: list[str] = []
        total_in = 0
        total_out = 0

        start = time.monotonic()

        try:
            for _ in range(self._max_turns):
                response = await client.messages.create(
                    model=self._model,
                    max_tokens=4096,
                    system=system,
                    tools=_SIMULATED_TOOLS,
                    messages=messages,
                )

                total_in += response.usage.input_tokens
                total_out += response.usage.output_tokens

                if response.stop_reason == "end_turn":
                    text_parts = [
                        b.text for b in response.content if hasattr(b, "text")
                    ]
                    final_response = "\n".join(text_parts)
                    break

                tool_use_blocks = [
                    b for b in response.content if b.type == "tool_use"
                ]
                if not tool_use_blocks:
                    text_parts = [
                        b.text for b in response.content if hasattr(b, "text")
                    ]
                    final_response = "\n".join(text_parts)
                    break

                messages.append({"role": "assistant", "content": response.content})

                tool_results = []
                for block in tool_use_blocks:
                    tc = ToolCall(
                        name=block.name,
                        arguments=dict(block.input) if isinstance(block.input, dict) else {},
                    )

                    result_text = _simulate_tool(
                        block.name, tc.arguments, workspace, files_created
                    )
                    tc.result = result_text
                    tool_calls.append(tc)

                    tool_results.append(
                        {
                            "type": "tool_result",
                            "tool_use_id": block.id,
                            "content": result_text,
                        }
                    )

                messages.append({"role": "user", "content": tool_results})
            else:
                final_response = "[max turns reached]"

            elapsed = (time.monotonic() - start) * 1000

            return RunResult(
                scenario_name=scenario.name,
                adapter_name=self.name,
                success=True,
                response=final_response,
                tool_calls=tool_calls,
                tokens_in=total_in,
                tokens_out=total_out,
                latency_ms=elapsed,
                files_created=files_created,
                raw_messages=messages,
            )

        except Exception as e:
            elapsed = (time.monotonic() - start) * 1000
            return RunResult(
                scenario_name=scenario.name,
                adapter_name=self.name,
                success=False,
                error=str(e),
                tool_calls=tool_calls,
                latency_ms=elapsed,
            )


def _simulate_tool(
    name: str, args: dict, workspace: Path, files_created: list[str]
) -> str:
    """Simulate tool execution in the workspace sandbox."""
    if name == "Read":
        target = workspace / args.get("path", "")
        if target.exists():
            return target.read_text(encoding="utf-8", errors="replace")[:4000]
        return f"Error: File not found: {args.get('path')}"

    if name == "Write":
        target = workspace / args.get("path", "")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(args.get("content", ""), encoding="utf-8")
        files_created.append(str(args.get("path", "")))
        return f"Wrote {len(args.get('content', ''))} bytes to {args.get('path')}"

    if name == "Bash":
        return (
            f"[simulated] Would execute: {args.get('command', '')}\n"
            f"(Tool execution is simulated in eval mode)"
        )

    return f"Unknown tool: {name}"
