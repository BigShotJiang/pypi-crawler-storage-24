"""OpenAI Codex CLI adapter — runs scenarios via the `codex exec` command."""

from __future__ import annotations

import asyncio
import json
import shutil
import time
from pathlib import Path

from skillbench.adapters.base import RunResult, ToolCall
from skillbench.core.scenario import Scenario
from skillbench.core.skill import Skill


def _install_skill(skill: Skill, workspace: Path) -> None:
    """Install a skill into the workspace's .agents/skills/ directory.

    Codex follows the cross-client .agents/skills/ convention.
    """
    skills_dir = workspace / ".agents" / "skills" / skill.name
    skills_dir.mkdir(parents=True, exist_ok=True)

    shutil.copy2(skill.location, skills_dir / "SKILL.md")

    for subdir in ("scripts", "references", "assets"):
        src = skill.skill_dir / subdir
        if src.is_dir():
            shutil.copytree(src, skills_dir / subdir, dirs_exist_ok=True)


def _parse_jsonl_output(raw: str) -> dict:
    """Parse Codex's JSONL output from exec --json mode.

    Codex emits structured events like:
      {"type":"item.completed","item":{"type":"command_execution","command":"...","aggregated_output":"...","exit_code":0}}
      {"type":"item.completed","item":{"type":"file_change","changes":[...]}}
      {"type":"item.completed","item":{"type":"agent_message","text":"..."}}
    """
    lines = raw.strip().splitlines()
    events = []
    last_message = None

    for line in lines:
        line = line.strip()
        if not line:
            continue
        try:
            event = json.loads(line)
            events.append(event)
            if event.get("type") == "item.completed":
                item = event.get("item", {})
                if item.get("type") == "agent_message":
                    last_message = item
            elif event.get("type") in ("message", "response"):
                last_message = event
        except json.JSONDecodeError:
            continue

    return {
        "events": events,
        "last_message": last_message,
        "raw": raw,
    }


def _extract_tool_calls(parsed: dict) -> list[ToolCall]:
    calls = []
    for event in parsed.get("events", []):
        event_type = event.get("type")

        if event_type == "item.completed":
            item = event.get("item", {})
            item_type = item.get("type")

            if item_type == "command_execution":
                cmd = item.get("command", "")
                calls.append(ToolCall(
                    name="Bash",
                    arguments={"command": cmd},
                    result=item.get("aggregated_output", ""),
                ))

            elif item_type == "file_change":
                for change in item.get("changes", []):
                    calls.append(ToolCall(
                        name="Write",
                        arguments={"path": change.get("path", ""), "kind": change.get("kind", "")},
                    ))

        elif event_type == "function_call":
            name = event.get("name", "unknown")
            arguments = event.get("arguments", {})
            if isinstance(arguments, str):
                try:
                    arguments = json.loads(arguments)
                except json.JSONDecodeError:
                    arguments = {"raw": arguments}
            calls.append(ToolCall(
                name=name,
                arguments=arguments,
                result=event.get("output"),
            ))

        elif event_type == "tool_call":
            tc = event.get("tool_call", event)
            name = tc.get("name", tc.get("function", {}).get("name", "unknown"))
            args = tc.get("arguments", tc.get("function", {}).get("arguments", {}))
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except json.JSONDecodeError:
                    args = {"raw": args}
            calls.append(ToolCall(name=name, arguments=args))

    return calls


def _extract_response_text(parsed: dict) -> str:
    last = parsed.get("last_message")
    if last:
        text = last.get("text", last.get("content", last.get("message", "")))
        if isinstance(text, list):
            return "\n".join(
                block.get("text", str(block))
                for block in text
            )
        return str(text)

    messages = []
    for event in parsed.get("events", []):
        if event.get("type") == "item.completed":
            item = event.get("item", {})
            if item.get("type") == "agent_message":
                messages.append(item.get("text", ""))

    if messages:
        return "\n\n".join(messages)

    texts = []
    for event in parsed.get("events", []):
        if event.get("type") in ("text", "message_delta"):
            texts.append(event.get("text", event.get("delta", "")))
    if texts:
        return "".join(texts)

    return parsed.get("raw", "")


class CodexAdapter:
    """Adapter that runs scenarios through the OpenAI Codex CLI.

    Requires the `codex` CLI to be installed and authenticated.
    Uses `codex exec` for non-interactive runs with JSON output.

    Install: npm install -g @openai/codex
    Auth:    codex login
    """

    def __init__(
        self,
        model: str | None = None,
        timeout: int = 300,
    ):
        self._model = model
        self._timeout = timeout

    @property
    def name(self) -> str:
        model_str = self._model or "default"
        return f"codex:{model_str}"

    def is_available(self) -> bool:
        return shutil.which("codex") is not None

    async def run_scenario(
        self,
        skill: Skill,
        scenario: Scenario,
        workspace: Path,
    ) -> RunResult:
        if not self.is_available():
            return RunResult(
                scenario_name=scenario.name,
                adapter_name=self.name,
                success=False,
                error="codex CLI not found. Install with: npm install -g @openai/codex",
            )

        _install_skill(skill, workspace)

        files_before: set[str] = set()
        for f in workspace.rglob("*"):
            if f.is_file():
                files_before.add(str(f.relative_to(workspace)))

        cmd = [
            "codex", "exec",
            scenario.prompt,
            "--json",
            "--full-auto",
            "--skip-git-repo-check",
            "-C", str(workspace),
        ]
        if self._model:
            cmd.extend(["-m", self._model])

        start = time.monotonic()

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )

            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=self._timeout
            )
            elapsed = (time.monotonic() - start) * 1000

            raw_output = stdout.decode("utf-8", errors="replace")

            if proc.returncode != 0:
                error_msg = stderr.decode("utf-8", errors="replace").strip()
                return RunResult(
                    scenario_name=scenario.name,
                    adapter_name=self.name,
                    success=False,
                    error=f"codex exec exited with code {proc.returncode}: {error_msg}",
                    response=raw_output,
                    latency_ms=elapsed,
                )

            parsed = _parse_jsonl_output(raw_output)
            tool_calls = _extract_tool_calls(parsed)
            response_text = _extract_response_text(parsed)

            files_after: set[str] = set()
            for f in workspace.rglob("*"):
                if f.is_file():
                    files_after.add(str(f.relative_to(workspace)))
            files_created = sorted(files_after - files_before)

            return RunResult(
                scenario_name=scenario.name,
                adapter_name=self.name,
                success=True,
                response=response_text,
                tool_calls=tool_calls,
                latency_ms=elapsed,
                files_created=files_created,
            )

        except asyncio.TimeoutError:
            elapsed = (time.monotonic() - start) * 1000
            return RunResult(
                scenario_name=scenario.name,
                adapter_name=self.name,
                success=False,
                error=f"codex exec timed out after {self._timeout}s",
                latency_ms=elapsed,
            )
        except Exception as e:
            elapsed = (time.monotonic() - start) * 1000
            return RunResult(
                scenario_name=scenario.name,
                adapter_name=self.name,
                success=False,
                error=str(e),
                latency_ms=elapsed,
            )
