"""OpenCode CLI adapter — runs scenarios via the `opencode run` command.

OpenCode is an open-source AI coding agent built for the terminal.
https://opencode.ai / https://github.com/sst/opencode
"""

from __future__ import annotations

import asyncio
import json
import os
import shutil
import time
from pathlib import Path

from skillbench.adapters.base import RunResult, ToolCall
from skillbench.core.scenario import Scenario
from skillbench.core.skill import Skill


def _install_skill(skill: Skill, workspace: Path) -> None:
    """Install a skill into the workspace.

    OpenCode reads .claude/skills/ by default (unless OPENCODE_DISABLE_CLAUDE_CODE_SKILLS
    is set), so we use that convention for compatibility.
    """
    skills_dir = workspace / ".claude" / "skills" / skill.name
    skills_dir.mkdir(parents=True, exist_ok=True)

    shutil.copy2(skill.location, skills_dir / "SKILL.md")

    for subdir in ("scripts", "references", "assets"):
        src = skill.skill_dir / subdir
        if src.is_dir():
            shutil.copytree(src, skills_dir / subdir, dirs_exist_ok=True)


def _parse_json_events(raw: str) -> dict:
    """Parse OpenCode's JSON output (newline-delimited JSON events)."""
    events = []
    last_assistant = None

    for line in raw.strip().splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            event = json.loads(line)
            events.append(event)
            event_type = event.get("type", "")
            if event_type in ("assistant", "message", "response", "text"):
                last_assistant = event
        except json.JSONDecodeError:
            continue

    return {
        "events": events,
        "last_assistant": last_assistant,
        "raw": raw,
    }


def _extract_tool_calls(parsed: dict) -> list[ToolCall]:
    calls = []
    for event in parsed.get("events", []):
        event_type = event.get("type", "")

        if event_type == "tool_call":
            tc = event.get("tool_call", event)
            name = tc.get("name", tc.get("tool", "unknown"))
            args = tc.get("arguments", tc.get("input", tc.get("args", {})))
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except json.JSONDecodeError:
                    args = {"raw": args}
            result = tc.get("output", tc.get("result"))
            calls.append(ToolCall(name=name, arguments=args, result=result))

        elif event_type == "tool_result":
            pass

    return calls


def _extract_response_text(parsed: dict) -> str:
    last = parsed.get("last_assistant")
    if last:
        content = last.get("content", last.get("message", last.get("text", "")))
        if isinstance(content, list):
            return "\n".join(
                block.get("text", str(block))
                for block in content
                if isinstance(block, dict) and block.get("type") == "text"
            )
        if isinstance(content, str):
            return content
        return str(content)

    texts = []
    for event in parsed.get("events", []):
        if event.get("type") in ("text", "assistant"):
            text = event.get("text", event.get("content", ""))
            if isinstance(text, str):
                texts.append(text)
    if texts:
        return "".join(texts)

    return parsed.get("raw", "")


def _detect_files_created(workspace: Path, before: set[str]) -> list[str]:
    after = set()
    for f in workspace.rglob("*"):
        if f.is_file():
            after.add(str(f.relative_to(workspace)))
    return sorted(after - before)


class OpenCodeAdapter:
    """Adapter that runs scenarios through the OpenCode CLI.

    Requires the `opencode` CLI to be installed and authenticated.
    Uses `opencode run` for non-interactive execution.

    Install: curl -fsSL https://opencode.ai/install | bash
    Auth:    opencode auth login

    Model format: provider/model (e.g., anthropic/claude-sonnet-4-20250514).
    If a bare model name is passed (e.g. ``gpt-5.2-chat``), the provider is
    inferred from available API keys.
    """

    def __init__(
        self,
        model: str | None = None,
        timeout: int = 120,
    ):
        self._model = model
        self._timeout = timeout

    @property
    def name(self) -> str:
        model_str = self._model or "default"
        return f"opencode:{model_str}"

    _SUPPORTED_KEY_VARS = (
        "ANTHROPIC_API_KEY",
        "OPENAI_API_KEY",
        "GOOGLE_API_KEY",
        "AZURE_OPENAI_API_KEY",
    )

    def is_available(self) -> bool:
        has_cli = shutil.which("opencode") is not None
        has_key = any(os.environ.get(k) for k in self._SUPPORTED_KEY_VARS)
        return has_cli and has_key

    def _resolve_model(self) -> str | None:
        """Resolve model to ``provider/model`` format expected by OpenCode.

        If the model already contains ``/`` it is returned as-is.
        Otherwise, infer the provider from the model name and available
        environment variables.
        """
        if not self._model:
            return None

        if "/" in self._model:
            return self._model

        model = self._model

        # Azure: gpt-* models when Azure keys are present
        if os.environ.get("AZURE_OPENAI_API_KEY") and (
            os.environ.get("AZURE_RESOURCE_NAME") or os.environ.get("AZURE_OPENAI_ENDPOINT")
        ):
            return f"azure/{model}"

        # OpenAI: gpt-*, o1-*, o3-* models
        if os.environ.get("OPENAI_API_KEY"):
            return f"openai/{model}"

        # Anthropic: claude-* models
        if os.environ.get("ANTHROPIC_API_KEY"):
            return f"anthropic/{model}"

        # Google: gemini-* models
        if os.environ.get("GOOGLE_API_KEY"):
            return f"google/{model}"

        return model

    def _build_env(self) -> dict[str, str]:
        """Build environment variables for the opencode subprocess."""
        env = os.environ.copy()
        if os.environ.get("AZURE_RESOURCE_NAME"):
            env["AZURE_RESOURCE_NAME"] = os.environ["AZURE_RESOURCE_NAME"]
        elif os.environ.get("AZURE_OPENAI_ENDPOINT") and not env.get("AZURE_RESOURCE_NAME"):
            endpoint = os.environ["AZURE_OPENAI_ENDPOINT"]
            if ".openai.azure.com" in endpoint:
                if "//" in endpoint:
                    resource_name = endpoint.split("//")[1].split(".")[0]
                else:
                    resource_name = endpoint.split(".")[0]
                env["AZURE_RESOURCE_NAME"] = resource_name
        return env

    async def run_scenario(
        self,
        skill: Skill,
        scenario: Scenario,
        workspace: Path,
    ) -> RunResult:
        if not self.is_available():
            return RunResult(
                scenario_name=scenario.name,
                adapter_name=self.name,
                success=False,
                error="opencode CLI not found. Install from https://opencode.ai/docs/",
            )

        _install_skill(skill, workspace)

        files_before = set()
        for f in workspace.rglob("*"):
            if f.is_file():
                files_before.add(str(f.relative_to(workspace)))

        cmd = [
            "opencode", "run",
            scenario.prompt,
            "--format", "json",
        ]
        resolved_model = self._resolve_model()
        if resolved_model:
            cmd.extend(["--model", resolved_model])

        start = time.monotonic()

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(workspace),
                env=self._build_env(),
            )

            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=self._timeout
            )
            elapsed = (time.monotonic() - start) * 1000

            raw_output = stdout.decode("utf-8", errors="replace")

            if proc.returncode != 0:
                error_msg = stderr.decode("utf-8", errors="replace").strip()
                return RunResult(
                    scenario_name=scenario.name,
                    adapter_name=self.name,
                    success=False,
                    error=f"opencode run exited with code {proc.returncode}: {error_msg}",
                    response=raw_output,
                    latency_ms=elapsed,
                )

            parsed = _parse_json_events(raw_output)
            tool_calls = _extract_tool_calls(parsed)
            response_text = _extract_response_text(parsed)
            files_created = _detect_files_created(workspace, files_before)

            return RunResult(
                scenario_name=scenario.name,
                adapter_name=self.name,
                success=True,
                response=response_text,
                tool_calls=tool_calls,
                latency_ms=elapsed,
                files_created=files_created,
            )

        except asyncio.TimeoutError:
            elapsed = (time.monotonic() - start) * 1000
            return RunResult(
                scenario_name=scenario.name,
                adapter_name=self.name,
                success=False,
                error=f"opencode run timed out after {self._timeout}s",
                latency_ms=elapsed,
            )
        except Exception as e:
            elapsed = (time.monotonic() - start) * 1000
            return RunResult(
                scenario_name=scenario.name,
                adapter_name=self.name,
                success=False,
                error=str(e),
                latency_ms=elapsed,
            )
