"""Aider CLI adapter — runs scenarios via the `aider` CLI in non-interactive mode.

Aider is a popular AI coding assistant with native Azure OpenAI support.
https://github.com/Aider-AI/aider
"""

from __future__ import annotations

import asyncio
import os
import shutil
import time
from pathlib import Path

from skillbench.adapters.base import RunResult, ToolCall
from skillbench.core.scenario import Scenario
from skillbench.core.skill import Skill


def _install_skill(skill: Skill, workspace: Path) -> None:
    """Copy the skill's SKILL.md into the workspace so aider can read it."""
    dest = workspace / "SKILL.md"
    shutil.copy2(skill.location, dest)

    for subdir in ("scripts", "references", "assets"):
        src = skill.skill_dir / subdir
        if src.is_dir():
            shutil.copytree(src, workspace / subdir, dirs_exist_ok=True)


def _parse_tool_calls_from_output(raw: str) -> list[ToolCall]:
    """Extract tool-call-like actions from aider's output.

    Aider doesn't emit structured tool calls. We infer file writes from
    its output patterns (e.g. "Wrote file.py", "Applied edit to file.py").
    """
    calls = []
    for line in raw.splitlines():
        line_stripped = line.strip()

        if line_stripped.startswith("Applied edit to "):
            path = line_stripped.removeprefix("Applied edit to ").strip()
            calls.append(ToolCall(name="Edit", arguments={"path": path}))
        elif line_stripped.startswith("Wrote "):
            path = line_stripped.removeprefix("Wrote ").strip()
            calls.append(ToolCall(name="Write", arguments={"path": path}))
        elif line_stripped.startswith("Created "):
            path = line_stripped.removeprefix("Created ").strip()
            calls.append(ToolCall(name="Write", arguments={"path": path}))

    return calls


def _detect_files_created(workspace: Path, before: set[str]) -> list[str]:
    """Detect new files created in the workspace during the run."""
    after = set()
    for f in workspace.rglob("*"):
        if f.is_file():
            after.add(str(f.relative_to(workspace)))
    return sorted(after - before)


class AiderAdapter:
    """Adapter that runs scenarios through the Aider CLI.

    Requires the `aider` CLI to be installed. Supports Azure OpenAI
    via the model prefix `azure/<deployment-name>`.

    Install: pip install aider-chat

    Azure usage:
        export AZURE_API_KEY="your-key"
        export AZURE_API_BASE="https://your-resource.openai.azure.com"
        export AZURE_API_VERSION="2025-04-01-preview"
        skillbench test ./my-skill --adapter aider --model azure/gpt-5.2-chat
    """

    def __init__(
        self,
        model: str | None = None,
        timeout: int = 120,
    ):
        self._model = model
        self._timeout = timeout

    @property
    def name(self) -> str:
        model_str = self._model or "default"
        return f"aider:{model_str}"

    def is_available(self) -> bool:
        return shutil.which("aider") is not None

    def _build_env(self) -> dict[str, str]:
        """Build environment variables for the aider subprocess."""
        env = os.environ.copy()

        if os.environ.get("AZURE_OPENAI_API_KEY"):
            env.setdefault("AZURE_API_KEY", os.environ["AZURE_OPENAI_API_KEY"])
        if os.environ.get("AZURE_OPENAI_ENDPOINT"):
            env.setdefault("AZURE_API_BASE", os.environ["AZURE_OPENAI_ENDPOINT"])
        if os.environ.get("AZURE_OPENAI_API_VERSION"):
            env.setdefault("AZURE_API_VERSION", os.environ["AZURE_OPENAI_API_VERSION"])
        else:
            env.setdefault("AZURE_API_VERSION", "2025-04-01-preview")

        return env

    async def run_scenario(
        self,
        skill: Skill,
        scenario: Scenario,
        workspace: Path,
    ) -> RunResult:
        if not self.is_available():
            return RunResult(
                scenario_name=scenario.name,
                adapter_name=self.name,
                success=False,
                error="aider CLI not found. Install with: pip install aider-chat",
            )

        _install_skill(skill, workspace)

        # Snapshot files before the run
        files_before = set()
        for f in workspace.rglob("*"):
            if f.is_file():
                files_before.add(str(f.relative_to(workspace)))

        skill_content = skill.location.read_text(encoding="utf-8")
        full_prompt = (
            f"You have the following skill loaded:\n\n{skill_content}\n\n"
            f"Follow the skill instructions to complete this task:\n\n{scenario.prompt}"
        )

        cmd = [
            "aider",
            "--message", full_prompt,
            "--yes",
            "--no-auto-commits",
            "--no-git",
            "--no-stream",
        ]
        if self._model:
            cmd.extend(["--model", self._model])

        start = time.monotonic()

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(workspace),
                env=self._build_env(),
            )

            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=self._timeout
            )
            elapsed = (time.monotonic() - start) * 1000

            raw_output = stdout.decode("utf-8", errors="replace")
            raw_stderr = stderr.decode("utf-8", errors="replace")

            if proc.returncode != 0:
                return RunResult(
                    scenario_name=scenario.name,
                    adapter_name=self.name,
                    success=False,
                    error=f"aider exited with code {proc.returncode}: {raw_stderr.strip()}",
                    response=raw_output,
                    latency_ms=elapsed,
                )

            tool_calls = _parse_tool_calls_from_output(raw_output)
            files_created = _detect_files_created(workspace, files_before)

            return RunResult(
                scenario_name=scenario.name,
                adapter_name=self.name,
                success=True,
                response=raw_output,
                tool_calls=tool_calls,
                latency_ms=elapsed,
                files_created=files_created,
            )

        except asyncio.TimeoutError:
            elapsed = (time.monotonic() - start) * 1000
            return RunResult(
                scenario_name=scenario.name,
                adapter_name=self.name,
                success=False,
                error=f"aider timed out after {self._timeout}s",
                latency_ms=elapsed,
            )
        except Exception as e:
            elapsed = (time.monotonic() - start) * 1000
            return RunResult(
                scenario_name=scenario.name,
                adapter_name=self.name,
                success=False,
                error=str(e),
                latency_ms=elapsed,
            )
