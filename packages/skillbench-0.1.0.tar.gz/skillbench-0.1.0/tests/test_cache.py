"""Tests for the local skill cache."""

from __future__ import annotations

from pathlib import Path

import pytest

from skillbench.registry.cache import SkillCache


@pytest.fixture
def cache(tmp_path: Path) -> SkillCache:
    return SkillCache(cache_dir=tmp_path / "cache")


@pytest.fixture
def sample_skill_dir(tmp_path: Path) -> Path:
    skill_dir = tmp_path / "my-skill"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text(
        "---\nname: my-skill\ndescription: Test\n---\nBody"
    )
    (skill_dir / "scripts").mkdir()
    (skill_dir / "scripts" / "run.py").write_text("print('hi')")
    return skill_dir


class TestSkillCache:
    def test_store_and_retrieve(self, cache: SkillCache, sample_skill_dir: Path):
        dest = cache.store_skill(
            owner="test-org",
            repo="test-repo",
            skill_dir=sample_skill_dir,
            relative_path="skills/my-skill",
            commit_hash="abc123",
        )

        assert dest.exists()
        assert (dest / "SKILL.md").exists()
        assert (dest / "scripts" / "run.py").exists()

        path = cache.get_skill_path("test-org", "test-repo", "my-skill")
        assert path == dest

    def test_metadata(self, cache: SkillCache, sample_skill_dir: Path):
        dest = cache.store_skill(
            owner="test-org",
            repo="test-repo",
            skill_dir=sample_skill_dir,
            relative_path="skills/my-skill",
            commit_hash="abc123",
        )

        meta = cache.get_metadata(dest)
        assert meta is not None
        assert meta["source"] == "test-org/test-repo"
        assert meta["commit_hash"] == "abc123"
        assert meta["skill_name"] == "my-skill"

    def test_list_skills(self, cache: SkillCache, sample_skill_dir: Path):
        cache.store_skill("org", "repo", sample_skill_dir, "s/my-skill", "abc")
        skills = cache.list_skills()
        assert len(skills) == 1
        assert skills[0]["name"] == "my-skill"

    def test_remove_skill(self, cache: SkillCache, sample_skill_dir: Path):
        cache.store_skill("org", "repo", sample_skill_dir, "s/my-skill", "abc")
        assert cache.remove_skill("org", "repo", "my-skill")
        assert cache.get_skill_path("org", "repo", "my-skill") is None

    def test_get_nonexistent(self, cache: SkillCache):
        assert cache.get_skill_path("x", "y", "z") is None

    def test_overwrite_existing(self, cache: SkillCache, sample_skill_dir: Path):
        cache.store_skill("org", "repo", sample_skill_dir, "s/my-skill", "v1")
        cache.store_skill("org", "repo", sample_skill_dir, "s/my-skill", "v2")

        meta = cache.get_metadata(
            cache.get_skill_path("org", "repo", "my-skill")
        )
        assert meta["commit_hash"] == "v2"
