"""Tests for the evaluator (deterministic assertions only — LLM judge requires API key)."""

from __future__ import annotations

import pytest

from skillbench.adapters.base import RunResult, ToolCall
from skillbench.core.evaluator import evaluate_run
from skillbench.core.scenario import Assertion, Scenario


def _make_scenario(assertions: list[Assertion]) -> Scenario:
    return Scenario(
        name="test",
        description="test scenario",
        prompt="do something",
        assertions=assertions,
    )


def _make_result(
    tool_calls: list[ToolCall] | None = None,
    files_created: list[str] | None = None,
    response: str = "done",
    success: bool = True,
) -> RunResult:
    return RunResult(
        scenario_name="test",
        adapter_name="test-adapter",
        success=success,
        response=response,
        tool_calls=tool_calls or [],
        files_created=files_created or [],
    )


class TestToolCalledAssertion:
    @pytest.mark.asyncio
    async def test_tool_called_pass(self):
        scenario = _make_scenario([
            Assertion(type="tool_called", tool="Write"),
        ])
        result = _make_result(tool_calls=[ToolCall(name="Write", arguments={"path": "out.txt"})])

        eval_result = await evaluate_run(scenario, result)
        assert eval_result.overall_pass
        assert eval_result.assertion_results[0].score == 1.0

    @pytest.mark.asyncio
    async def test_tool_called_fail(self):
        scenario = _make_scenario([
            Assertion(type="tool_called", tool="Write"),
        ])
        result = _make_result(tool_calls=[ToolCall(name="Read", arguments={})])

        eval_result = await evaluate_run(scenario, result)
        assert not eval_result.overall_pass

    @pytest.mark.asyncio
    async def test_tool_called_with_args(self):
        scenario = _make_scenario([
            Assertion(type="tool_called", tool="Bash", args_contain="pdfplumber"),
        ])
        result = _make_result(
            tool_calls=[
                ToolCall(name="Bash", arguments={"command": "python -c 'import pdfplumber'"})
            ]
        )

        eval_result = await evaluate_run(scenario, result)
        assert eval_result.overall_pass

    @pytest.mark.asyncio
    async def test_tool_called_args_mismatch(self):
        scenario = _make_scenario([
            Assertion(type="tool_called", tool="Bash", args_contain="pdfplumber"),
        ])
        result = _make_result(
            tool_calls=[ToolCall(name="Bash", arguments={"command": "ls -la"})]
        )

        eval_result = await evaluate_run(scenario, result)
        assert not eval_result.overall_pass


class TestFileCreatedAssertion:
    @pytest.mark.asyncio
    async def test_file_created_pass(self):
        scenario = _make_scenario([
            Assertion(type="file_created", path="output.txt"),
        ])
        result = _make_result(files_created=["output.txt"])

        eval_result = await evaluate_run(scenario, result)
        assert eval_result.overall_pass

    @pytest.mark.asyncio
    async def test_file_created_fail(self):
        scenario = _make_scenario([
            Assertion(type="file_created", path="output.txt"),
        ])
        result = _make_result(files_created=["other.txt"])

        eval_result = await evaluate_run(scenario, result)
        assert not eval_result.overall_pass


class TestOutputContainsAssertion:
    @pytest.mark.asyncio
    async def test_output_contains_pass(self):
        scenario = _make_scenario([
            Assertion(type="output_contains", content="success"),
        ])
        result = _make_result(response="Operation completed with success!")

        eval_result = await evaluate_run(scenario, result)
        assert eval_result.overall_pass

    @pytest.mark.asyncio
    async def test_output_contains_case_insensitive(self):
        scenario = _make_scenario([
            Assertion(type="output_contains", content="SUCCESS"),
        ])
        result = _make_result(response="success achieved")

        eval_result = await evaluate_run(scenario, result)
        assert eval_result.overall_pass

    @pytest.mark.asyncio
    async def test_output_contains_fail(self):
        scenario = _make_scenario([
            Assertion(type="output_contains", content="error"),
        ])
        result = _make_result(response="Everything is fine")

        eval_result = await evaluate_run(scenario, result)
        assert not eval_result.overall_pass


class TestRunFailure:
    @pytest.mark.asyncio
    async def test_failed_run(self):
        scenario = _make_scenario([
            Assertion(type="tool_called", tool="Write"),
        ])
        result = _make_result(success=False)
        result.error = "API key not set"

        eval_result = await evaluate_run(scenario, result)
        assert not eval_result.run_success
        assert eval_result.error == "API key not set"


class TestMultipleAssertions:
    @pytest.mark.asyncio
    async def test_all_pass(self):
        scenario = _make_scenario([
            Assertion(type="tool_called", tool="Write"),
            Assertion(type="file_created", path="out.txt"),
            Assertion(type="output_contains", content="done"),
        ])
        result = _make_result(
            tool_calls=[ToolCall(name="Write", arguments={})],
            files_created=["out.txt"],
            response="done",
        )

        eval_result = await evaluate_run(scenario, result)
        assert eval_result.overall_pass
        assert eval_result.overall_score == 1.0

    @pytest.mark.asyncio
    async def test_partial_fail(self):
        scenario = _make_scenario([
            Assertion(type="tool_called", tool="Write"),
            Assertion(type="file_created", path="out.txt"),
        ])
        result = _make_result(
            tool_calls=[ToolCall(name="Write", arguments={})],
            files_created=[],
        )

        eval_result = await evaluate_run(scenario, result)
        assert not eval_result.overall_pass
        assert 0 < eval_result.overall_score < 1.0
