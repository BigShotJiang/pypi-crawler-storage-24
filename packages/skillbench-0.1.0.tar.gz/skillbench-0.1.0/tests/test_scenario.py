"""Tests for scenario model and YAML loader."""

from __future__ import annotations

import textwrap
from pathlib import Path

import pytest

from skillbench.core.scenario import (
    load_scenarios,
    scenarios_to_yaml,
)


class TestLoadScenarios:
    def test_load_from_skill_dir(self, tmp_scenarios: Path):
        suite = load_scenarios(tmp_scenarios)
        assert suite.skill == "test-skill"
        assert suite.scenario_count == 2

    def test_load_from_file(self, tmp_scenarios: Path):
        suite = load_scenarios(tmp_scenarios / "scenarios" / "scenarios.yaml")
        assert suite.scenario_count == 2

    def test_scenario_fields(self, tmp_scenarios: Path):
        suite = load_scenarios(tmp_scenarios)
        s = suite.scenarios[0]
        assert s.name == "basic-process"
        assert s.prompt == "Process data.csv and save to output.csv"
        assert len(s.assertions) == 2
        assert s.assertions[0].type == "tool_called"
        assert s.assertions[0].tool == "Write"
        assert s.tags == ["core"]

    def test_filter_by_tags(self, tmp_scenarios: Path):
        suite = load_scenarios(tmp_scenarios)
        core = suite.filter_by_tags(["core"])
        assert len(core) == 1
        assert core[0].name == "basic-process"

        edge = suite.filter_by_tags(["edge-case"])
        assert len(edge) == 1
        assert edge[0].name == "missing-file"

    def test_filter_no_tags(self, tmp_scenarios: Path):
        suite = load_scenarios(tmp_scenarios)
        assert suite.filter_by_tags([]) == suite.scenarios

    def test_missing_scenarios_file(self, tmp_path: Path):
        with pytest.raises(FileNotFoundError):
            load_scenarios(tmp_path)

    def test_environment_parsing(self, tmp_scenarios: Path):
        suite = load_scenarios(tmp_scenarios)
        assert suite.environment.os == "any"
        assert "Bash" in suite.environment.tools

    def test_minimal_scenario(self, tmp_path: Path):
        scenario_file = tmp_path / "scenarios.yaml"
        scenario_file.write_text(
            textwrap.dedent("""\
                skill: minimal
                scenarios:
                  - name: hello
                    prompt: "Say hello"
            """)
        )
        suite = load_scenarios(scenario_file)
        assert suite.scenario_count == 1
        assert suite.scenarios[0].assertions == []
        assert suite.scenarios[0].tags == []


class TestScenariosToYaml:
    def test_roundtrip(self, tmp_scenarios: Path):
        suite = load_scenarios(tmp_scenarios)
        yaml_str = scenarios_to_yaml(suite)

        roundtrip_path = tmp_scenarios / "roundtrip.yaml"
        roundtrip_path.write_text(yaml_str)
        suite2 = load_scenarios(roundtrip_path)

        assert suite2.skill == suite.skill
        assert suite2.scenario_count == suite.scenario_count
        assert suite2.scenarios[0].name == suite.scenarios[0].name
