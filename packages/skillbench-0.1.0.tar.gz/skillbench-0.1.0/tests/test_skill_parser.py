"""Tests for SKILL.md parser and validator."""

from __future__ import annotations

import textwrap
from pathlib import Path

import pytest

from skillbench.core.skill import load_skill, validate_skill


class TestLoadSkill:
    def test_load_valid_skill(self, tmp_skill: Path):
        skill = load_skill(tmp_skill)
        assert skill.name == "test-skill"
        assert "unit testing" in skill.description
        assert "Instructions" in skill.body
        assert skill.content_hash

    def test_load_from_file_path(self, tmp_skill: Path):
        skill = load_skill(tmp_skill / "SKILL.md")
        assert skill.name == "test-skill"

    def test_load_with_source_repo(self, tmp_skill: Path):
        skill = load_skill(tmp_skill, source_repo="org/repo")
        assert skill.source_repo == "org/repo"

    def test_load_missing_skill(self, tmp_path: Path):
        with pytest.raises(FileNotFoundError):
            load_skill(tmp_path / "nonexistent")

    def test_load_missing_name(self, tmp_path: Path):
        skill_dir = tmp_path / "bad-skill"
        skill_dir.mkdir()
        (skill_dir / "SKILL.md").write_text(
            "---\ndescription: No name field\n---\nBody"
        )
        with pytest.raises(ValueError, match="missing required 'name'"):
            load_skill(skill_dir)

    def test_load_missing_description(self, tmp_path: Path):
        skill_dir = tmp_path / "bad-skill"
        skill_dir.mkdir()
        (skill_dir / "SKILL.md").write_text("---\nname: bad-skill\n---\nBody")
        with pytest.raises(ValueError, match="missing required 'description'"):
            load_skill(skill_dir)

    def test_skill_dir_property(self, tmp_skill: Path):
        skill = load_skill(tmp_skill)
        assert skill.skill_dir == tmp_skill.resolve()

    def test_content_hash_changes(self, tmp_path: Path):
        skill_dir = tmp_path / "hash-skill"
        skill_dir.mkdir()
        (skill_dir / "SKILL.md").write_text(
            "---\nname: hash-skill\ndescription: Test hashing\n---\nBody v1"
        )
        skill1 = load_skill(skill_dir)

        (skill_dir / "SKILL.md").write_text(
            "---\nname: hash-skill\ndescription: Test hashing\n---\nBody v2"
        )
        skill2 = load_skill(skill_dir)

        assert skill1.content_hash != skill2.content_hash

    def test_load_with_optional_fields(self, tmp_path: Path):
        skill_dir = tmp_path / "full-skill"
        skill_dir.mkdir()
        skill_md = textwrap.dedent("""\
            ---
            name: full-skill
            description: A skill with all optional fields.
            license: MIT
            compatibility: Requires Python 3.11+
            metadata:
              author: test-org
              version: "2.0"
            allowed-tools: Bash Read Write
            ---

            # Full Skill
        """)
        (skill_dir / "SKILL.md").write_text(skill_md)
        skill = load_skill(skill_dir)

        assert skill.metadata.license == "MIT"
        assert skill.metadata.compatibility == "Requires Python 3.11+"
        assert skill.metadata.metadata["author"] == "test-org"
        assert skill.metadata.allowed_tools == ["Bash", "Read", "Write"]

    def test_resource_paths(self, tmp_skill: Path):
        (tmp_skill / "scripts" / "extract.py").write_text("print('hello')")
        (tmp_skill / "references").mkdir(exist_ok=True)
        (tmp_skill / "references" / "guide.md").write_text("# Guide")

        skill = load_skill(tmp_skill)
        resources = skill.resource_paths()
        assert len(resources) == 2
        names = [r.name for r in resources]
        assert "extract.py" in names
        assert "guide.md" in names


class TestValidateSkill:
    def test_valid_skill(self, tmp_skill: Path):
        issues = validate_skill(tmp_skill)
        errors = [i for i in issues if i.level == "error"]
        assert len(errors) == 0

    def test_missing_skill_md(self, tmp_path: Path):
        issues = validate_skill(tmp_path)
        assert any(i.level == "error" and "not found" in i.message for i in issues)

    def test_missing_name(self, tmp_path: Path):
        skill_dir = tmp_path / "noname"
        skill_dir.mkdir()
        (skill_dir / "SKILL.md").write_text("---\ndescription: Hi\n---\nBody")
        issues = validate_skill(skill_dir)
        assert any(i.field == "name" and i.level == "error" for i in issues)

    def test_missing_description(self, tmp_path: Path):
        skill_dir = tmp_path / "nodesc"
        skill_dir.mkdir()
        (skill_dir / "SKILL.md").write_text("---\nname: nodesc\n---\nBody")
        issues = validate_skill(skill_dir)
        assert any(i.field == "description" and i.level == "error" for i in issues)

    def test_name_dir_mismatch(self, tmp_path: Path):
        skill_dir = tmp_path / "wrong-dir"
        skill_dir.mkdir()
        (skill_dir / "SKILL.md").write_text(
            "---\nname: correct-name\ndescription: Test\n---\nBody"
        )
        issues = validate_skill(skill_dir)
        warnings = [i for i in issues if i.level == "warning"]
        assert any("does not match" in w.message for w in warnings)

    def test_empty_body_warning(self, tmp_path: Path):
        skill_dir = tmp_path / "empty-body"
        skill_dir.mkdir()
        (skill_dir / "SKILL.md").write_text(
            "---\nname: empty-body\ndescription: Test\n---\n"
        )
        issues = validate_skill(skill_dir)
        assert any("body is empty" in i.message for i in issues)

    def test_long_name_warning(self, tmp_path: Path):
        long_name = "a" * 65
        skill_dir = tmp_path / long_name
        skill_dir.mkdir()
        (skill_dir / "SKILL.md").write_text(
            f"---\nname: {long_name}\ndescription: Test\n---\nBody"
        )
        issues = validate_skill(skill_dir)
        assert any("exceeds 64" in i.message for i in issues)
