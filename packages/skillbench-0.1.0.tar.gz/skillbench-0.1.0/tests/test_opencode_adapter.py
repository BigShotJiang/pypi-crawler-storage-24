"""Tests for the OpenCode adapter."""

from __future__ import annotations

import os
from unittest.mock import patch

from skillbench.adapters.opencode import OpenCodeAdapter


class TestOpenCodeAdapterInstantiation:
    """Test basic instantiation and configuration of OpenCode adapter."""

    def test_default_instantiation(self):
        """Test creating adapter with default settings."""
        adapter = OpenCodeAdapter()
        assert adapter.name == "opencode:default"
        assert adapter._timeout == 120

    def test_custom_model(self):
        """Test creating adapter with custom model."""
        adapter = OpenCodeAdapter(model="claude-3-5-sonnet")
        assert adapter.name == "opencode:claude-3-5-sonnet"

    def test_custom_timeout(self):
        """Test creating adapter with custom timeout."""
        adapter = OpenCodeAdapter(timeout=60)
        assert adapter._timeout == 60


class TestOpenCodeAdapterAvailability:
    """Test adapter availability checks."""

    @patch("shutil.which")
    def test_is_available_with_cli_and_key(self, mock_which):
        """Test availability when CLI is installed and API key is set."""
        mock_which.return_value = "/usr/local/bin/opencode"
        with patch.dict(os.environ, {"ANTHROPIC_API_KEY": "test-key"}):
            adapter = OpenCodeAdapter()
            assert adapter.is_available()

    @patch("shutil.which")
    def test_is_available_with_openai_key(self, mock_which):
        """Test availability with OpenAI API key."""
        mock_which.return_value = "/usr/local/bin/opencode"
        with patch.dict(os.environ, {"OPENAI_API_KEY": "test-key"}, clear=True):
            adapter = OpenCodeAdapter()
            assert adapter.is_available()

    @patch("shutil.which")
    def test_is_available_with_google_key(self, mock_which):
        """Test availability with Google API key."""
        mock_which.return_value = "/usr/local/bin/opencode"
        with patch.dict(os.environ, {"GOOGLE_API_KEY": "test-key"}, clear=True):
            adapter = OpenCodeAdapter()
            assert adapter.is_available()

    @patch("shutil.which")
    def test_not_available_missing_cli(self, mock_which):
        """Test unavailability when CLI is not installed."""
        mock_which.return_value = None
        with patch.dict(os.environ, {"ANTHROPIC_API_KEY": "test-key"}):
            adapter = OpenCodeAdapter()
            assert not adapter.is_available()

    @patch("shutil.which")
    def test_not_available_missing_key(self, mock_which):
        """Test unavailability when API key is not set."""
        mock_which.return_value = "/usr/local/bin/opencode"
        with patch.dict(os.environ, {}, clear=True):
            adapter = OpenCodeAdapter()
            assert not adapter.is_available()


class TestOpenCodeAdapterEnvironment:
    """Test environment variable handling."""

    def test_build_env_preserves_existing(self):
        """Test that _build_env preserves existing environment variables."""
        with patch.dict(os.environ, {"ANTHROPIC_API_KEY": "test-key", "PATH": "/usr/bin"}):
            adapter = OpenCodeAdapter()
            env = adapter._build_env()
            assert env["ANTHROPIC_API_KEY"] == "test-key"
            assert env["PATH"] == "/usr/bin"
