from __future__ import annotations

import time
from typing import Any

from prompt_toolkit.utils import get_cwidth
from rich.console import Console

from comate_cli.terminal_agent.animations import _cyan_sweep_text, breathing_dot_color, breathing_dot_glyph
from comate_cli.terminal_agent.text_effects import fit_single_line

console = Console()


class RenderPanelsMixin:
    _COMPLETION_PANEL_MAX_LINES = 8

    def _terminal_width(self) -> int:
        if self._app is None:
            return 100
        try:
            return max(int(self._app.output.get_size().columns), 40)
        except Exception:
            return 100

    def _queue_text(self) -> list[tuple[str, str]]:
        queued_messages = list(self._queued_messages)
        if not queued_messages:
            return [("", " ")]

        preview_fn = getattr(self, "_queued_preview_text", None)
        width = self._terminal_width()
        fragments: list[tuple[str, str]] = []
        for idx, message in enumerate(queued_messages):
            if callable(preview_fn):
                preview_source = str(preview_fn(message))
            else:
                preview_source = str(message)
            preview = " ".join(preview_source.split())
            line = fit_single_line(f"     > {preview}", width)
            if idx > 0:
                fragments.append(("", "\n"))
            fragments.append(("class:queue.item", line))
        return fragments

    def _queue_height(self) -> int:
        return max(1, len(self._queued_messages))

    def _status_text(self) -> list[tuple[str, str]]:
        width = self._terminal_width()

        # 左栏：mode 图标 + 提示文字
        mode = self._status_bar.get_mode()
        hint_text = "(shift+tab to cycle)"
        if mode == "plan":
            left_main = "⏸ Plan mode on "
            left_style = "class:status.mode.plan"
        else:
            left_main = "⏵⏵ Act mode on "
            left_style = "class:status.mode.act"

        # 右栏：model | ~branch / X% left
        right_text = self._status_bar.info_status_text()
        # busy 状态下跳过 git diff 计算，避免状态栏触发阻塞式 git 调用影响输入流畅度。
        if self._busy or self._initializing:
            git_frags = []
        else:
            git_frags = self._status_bar.git_diff_fragments()

        left_w = sum(get_cwidth(c) for c in left_main + hint_text)
        right_w = sum(get_cwidth(c) for c in right_text)
        if git_frags:
            right_w += 2 + sum(get_cwidth(c) for _, t in git_frags for c in t)

        padding = max(1, width - left_w - right_w - 2)

        frags: list[tuple[str, str]] = [
            (left_style, left_main),
            ("class:status.hint", hint_text),
            ("class:status", " " * padding),
            ("class:status", right_text),
        ]
        if git_frags:
            frags.append(("class:status", "  "))
            frags.extend(git_frags)
        return frags

    def _completion_panel_state(self) -> tuple[list[Any], int] | None:
        input_area = getattr(self, "_input_area", None)
        if input_area is None:
            return None
        buffer = getattr(input_area, "buffer", None)
        if buffer is None:
            return None
        complete_state = getattr(buffer, "complete_state", None)
        if complete_state is None:
            return None

        completions = list(getattr(complete_state, "completions", []) or [])
        if not completions:
            return None

        selected_index: int | None = None
        current_completion = getattr(complete_state, "current_completion", None)
        if current_completion is not None:
            for idx, completion in enumerate(completions):
                if completion is current_completion:
                    selected_index = idx
                    break
        if selected_index is None:
            raw_index = getattr(complete_state, "complete_index", None)
            if isinstance(raw_index, int) and 0 <= raw_index < len(completions):
                selected_index = raw_index
        if selected_index is None:
            selected_index = 0
        return completions, selected_index

    def _completion_panel_text(self) -> list[tuple[str, str]]:
        state = self._completion_panel_state()
        if state is None:
            return self._status_text()

        completions, selected_index = state
        width = self._terminal_width()
        max_lines = max(1, int(self._COMPLETION_PANEL_MAX_LINES))
        visible_slots = max_lines
        hidden_below_count = 0
        start = 0
        end = len(completions)
        if len(completions) > max_lines:
            visible_slots = max(1, max_lines - 1)
            start = max(0, selected_index - (visible_slots // 2))
            end = min(len(completions), start + visible_slots)
            start = max(0, end - visible_slots)
            hidden_below_count = len(completions) - end

        fragments: list[tuple[str, str]] = []
        visible = completions[start:end]
        slash_command_width = 0
        for completion in completions:
            display_text = str(getattr(completion, "display_text", completion.text))
            meta_text = str(getattr(completion, "display_meta_text", "")).strip()
            if meta_text and display_text.startswith("/"):
                slash_command_width = max(slash_command_width, get_cwidth(display_text))

        for idx, completion in enumerate(visible):
            absolute_idx = start + idx
            is_selected = absolute_idx == selected_index
            line_style = (
                "class:completion.status.current"
                if is_selected
                else "class:completion.status.item"
            )

            display_text = str(getattr(completion, "display_text", completion.text))
            meta_text = str(getattr(completion, "display_meta_text", "")).strip()
            line_prefix = "› " if is_selected else "  "
            row_text = f"{line_prefix}{display_text}"
            meta_start_index: int | None = None
            render_meta_with_split_style = False
            if meta_text:
                if display_text.startswith("/") and slash_command_width > 0:
                    command_width = get_cwidth(display_text)
                    align_padding = " " * (
                        max(0, slash_command_width - command_width) + 5
                    )
                    row_text = f"{row_text}{align_padding}{meta_text}"
                    meta_start_index = (
                        len(line_prefix) + len(display_text) + len(align_padding)
                    )
                    render_meta_with_split_style = True
                else:
                    row_text = f"{row_text}  —  {meta_text}"

            clipped = fit_single_line(row_text, width)
            padding = " " * max(0, width - get_cwidth(clipped))
            if (
                render_meta_with_split_style
                and meta_start_index is not None
                and meta_start_index < len(clipped)
            ):
                command_part = clipped[:meta_start_index]
                meta_part = clipped[meta_start_index:]
                if command_part:
                    fragments.append((line_style, command_part))
                if meta_part:
                    fragments.append(("class:completion.status.meta", meta_part))
                if padding:
                    fragments.append((line_style, padding))
            else:
                fragments.append((line_style, f"{clipped}{padding}"))
            if idx != len(visible) - 1 or hidden_below_count > 0:
                fragments.append(("", "\n"))

        if hidden_below_count > 0:
            more_text = fit_single_line(f"… and {hidden_below_count} more", width)
            padding = " " * max(0, width - get_cwidth(more_text))
            fragments.append(("class:completion.status.more", f"{more_text}{padding}"))

        return fragments if fragments else [("", " ")]

    def _completion_panel_height(self) -> int:
        state = self._completion_panel_state()
        if state is None:
            return 1
        completions, _ = state
        max_lines = max(1, int(self._COMPLETION_PANEL_MAX_LINES))
        if len(completions) <= max_lines:
            return max(1, len(completions))
        return max_lines

    def _should_hide_loading_panel(self) -> bool:
        """统一 loading 显隐逻辑：仅当 Todo 面板出现且无工具运行时隐藏 loading 区域。"""
        if self._renderer.has_running_tools():
            return False
        return self._renderer.has_active_todos()

    def _sync_todo_panel_state(self) -> None:
        if self._renderer.has_active_todos():
            return
        self._todo_panel_expanded = False
        self._todo_panel_scroll = 0

    def _todo_panel_view(self) -> list[str]:
        self._sync_todo_panel_state()
        all_lines_fn = getattr(self._renderer, "todo_all_lines", None)
        if callable(all_lines_fn):
            all_lines = list(all_lines_fn())
        else:
            all_lines = list(
                self._renderer.todo_panel_lines(max_lines=self._todo_panel_max_lines)
            )
        if not all_lines:
            return []

        if not getattr(self, "_todo_panel_expanded", False):
            collapsed_lines = list(
                self._renderer.todo_panel_lines(max_lines=self._todo_panel_max_lines)
            )
            if len(all_lines) > len(collapsed_lines) and collapsed_lines:
                last_line = collapsed_lines[-1]
                if last_line.startswith("… (+"):
                    collapsed_lines[-1] = f"{last_line}, Ctrl+Y to expand"
            return collapsed_lines

        if len(all_lines) == 1:
            return all_lines

        viewport = max(2, int(self._todo_panel_expanded_max_lines))
        visible_item_slots = max(1, viewport - 1)
        total_items = len(all_lines) - 1
        max_scroll = max(0, total_items - visible_item_slots)
        offset = min(max(int(self._todo_panel_scroll), 0), max_scroll)
        self._todo_panel_scroll = offset

        item_lines = all_lines[1:]
        visible_items = item_lines[offset : offset + visible_item_slots]
        start = offset + 1
        end = offset + len(visible_items)
        header = (
            f"{all_lines[0]} [{start}-{end}/{total_items}] "
            "Ctrl+Y collapse, ↑↓ scroll"
        )
        return [header, *visible_items]

    def _loading_text(self) -> list[tuple[str, str]]:
        if self._should_hide_loading_panel():
            return [("", " ")]

        # Running tools: multi-line tool panel with breathing dot.
        if self._renderer.has_running_tools():
            width = self._terminal_width()
            show_flash_line = (
                self._tool_result_flash_active and self._tool_panel_max_lines >= 2
            )
            # 动态计算所需行数，但至少保留配置值作为最小值
            required_lines = self._renderer.compute_required_tool_panel_lines()
            base_max = self._tool_panel_max_lines
            tool_max = max(required_lines, base_max)
            if show_flash_line:
                tool_max = max(tool_max + 1, self._tool_panel_max_lines)
            entries = self._renderer.tool_panel_entries(max_lines=max(1, tool_max))
            if not entries:
                return [("", " ")]

            dot_color = breathing_dot_color(self._loading_frame)
            now_monotonic = time.monotonic()
            dot_glyph = breathing_dot_glyph(now_monotonic)
            dot_style = f"fg:{dot_color} bold"
            primary_style = "fg:#D1D5DB"
            nested_style = "fg:#9CA3AF"

            fragments: list[tuple[str, str]] = []
            if show_flash_line and self._tool_result_animator.is_active:
                renderable = self._tool_result_animator.renderable()
                fragments.extend(self._rich_text_to_pt_fragments(renderable))
                fragments.append(("", "\n"))

            last_index = len(entries) - 1
            for idx, (indent, line) in enumerate(entries):
                if indent < 0:
                    clipped = fit_single_line(line, width - 1)
                    fragments.append((nested_style, clipped))
                elif indent == 0:
                    clipped = fit_single_line(line, max(width - 2, 8))
                    fragments.append((dot_style, f"{dot_glyph} "))
                    fragments.append((primary_style, clipped))
                else:
                    padding = "  " * indent
                    clipped = fit_single_line(line, max(width - get_cwidth(padding), 8))
                    fragments.append((nested_style, padding))
                    fragments.append((nested_style, clipped))

                if idx != last_index:
                    fragments.append(("", "\n"))

            return fragments

        # 优先使用动画器的渲染（流光走字 + 随机 geek 术语）
        if self._tool_result_animator.is_active:
            renderable = self._tool_result_animator.renderable()
            frags = self._rich_text_to_pt_fragments(renderable)
            return self._append_run_elapsed_fragment(frags)

        if self._animator.is_active:
            renderable = self._animator.renderable()
            frags = self._rich_text_to_pt_fragments(renderable)
            return self._append_run_elapsed_fragment(frags)

        # 获取语义化的 loading 状态
        loading_state = self._renderer.loading_state()
        text = loading_state.text.strip()

        if not text:
            if self._busy:
                return self._animated_loading_fragments(self._fallback_loading_phrase)
            return [("", " ")]

        return self._animated_loading_fragments(text)

    def _animated_loading_fragments(self, phrase: str) -> list[tuple[str, str]]:
        """用与工具调用一致的呼吸圆点 + 流光走字渲染 loading 文案."""
        width = self._terminal_width()

        # 若正在计时，预先计算时间后缀宽度，给 phrase 预留空间
        run_start: float | None = getattr(self, "_run_start_time", None)
        elapsed_suffix = ""
        if run_start is not None:
            elapsed = time.monotonic() - run_start
            elapsed_suffix = (
                f"  ({self._format_run_elapsed(elapsed)} • ctrl+c to interrupt)"
            )

        # glyph(1) + space(1) = 2，再减去时间后缀宽度
        phrase_budget = width - 4 - get_cwidth(elapsed_suffix)
        clipped = fit_single_line(phrase, max(phrase_budget, 8))

        frame = self._loading_frame
        dot_color = breathing_dot_color(frame)
        now_monotonic = time.monotonic()

        # 构建 Rich Text（与 SubmissionAnimator.renderable 相同结构）
        from rich.text import Text as RichText

        dot = RichText(f"{breathing_dot_glyph(now_monotonic)} ", style=f"bold {dot_color}")
        sweep = _cyan_sweep_text(clipped, frame=frame)
        combined = RichText.assemble(dot, sweep)
        frags = self._rich_text_to_pt_fragments(combined)
        if elapsed_suffix:
            frags = frags + [("fg:#6B7280", elapsed_suffix)]
        return frags

    def _append_run_elapsed_fragment(
        self,
        frags: list[tuple[str, str]],
    ) -> list[tuple[str, str]]:
        """若当前正在计时，在 fragments 末尾追加 '  ·  Xs' 时间后缀."""
        run_start: float | None = getattr(self, "_run_start_time", None)
        if run_start is None:
            return frags
        elapsed = time.monotonic() - run_start
        duration_str = self._format_run_elapsed(elapsed)
        # Rich __rich_console__ 末尾会输出一个 "\n" segment，需要先剥掉再追加，
        # 否则时间后缀会落在换行符之后，在单行 Window 里不可见。
        tail: list[tuple[str, str]] = []
        trimmed = list(frags)
        while trimmed and trimmed[-1][1] == "\n":
            tail.insert(0, trimmed.pop())
        return (
            trimmed
            + [("fg:#6B7280", f"  ({duration_str} • ctrl+c to interrupt)")]
            + tail
        )

    def _loading_height(self) -> int:
        if self._should_hide_loading_panel():
            return 1

        # 工具面板优先：即使 animator 仍活跃，也需要为多行工具面板分配正确高度，
        # 否则在 Task subagent 执行期间嵌套工具行会被 Window 裁剪为 1 行。
        if self._renderer.has_running_tools():
            show_flash_line = (
                self._tool_result_flash_active and self._tool_panel_max_lines >= 2
            )
            # 动态计算所需行数，但至少保留配置值作为最小值
            required_lines = self._renderer.compute_required_tool_panel_lines()
            base_max = self._tool_panel_max_lines
            tool_max = max(required_lines, base_max)
            if show_flash_line:
                tool_max = max(tool_max + 1, self._tool_panel_max_lines)
            tool_lines = self._renderer.tool_panel_entries(max_lines=max(1, tool_max))
            total = len(tool_lines) + (1 if show_flash_line else 0)
            return max(1, total)
        if self._animator.is_active:
            return 1
        if self._tool_result_animator.is_active:
            return 1
        if self._renderer.loading_state().text.strip():
            return 1
        return 1

    _DIFF_PANEL_MAX_VISIBLE = 20

    def _todo_title_shimmer_fragments(self, title: str) -> list[tuple[str, str]]:
        """Todo 标题流光走字：文字不位移，仅高亮带扫过。"""
        if not title:
            return [("fg:#7DD3FC bold", title)]

        sweep_center = (self._loading_frame % (len(title) + 8)) - 4
        fragments: list[tuple[str, str]] = []
        for idx, char in enumerate(title):
            distance = abs(idx - sweep_center)
            if distance <= 1:
                style = "fg:#F8FAFC bold"
            elif distance <= 3:
                style = "fg:#CFFAFE bold"
            elif distance <= 5:
                style = "fg:#A7F3D0 bold"
            else:
                style = "fg:#7DD3FC bold"
            fragments.append((style, char))
        return fragments

    def _diff_panel_text(self) -> list[tuple[str, str]]:
        import re

        diff_lines = self._renderer.latest_diff_lines
        if not diff_lines:
            return [("", " ")]

        width = self._terminal_width()
        total = len(diff_lines)
        viewport = self._DIFF_PANEL_MAX_VISIBLE - 1  # reserve 1 for header
        offset = self._diff_panel_scroll
        max_scroll = max(0, total - viewport)
        scroll_info = ""
        if total > viewport:
            scroll_info = f" [{offset + 1}-{min(offset + viewport, total)}/{total}] ↑↓"

        title = (
            " Diff Preview (Ctrl+O to close, use arrow keys (↑↓) to scroll) "
            f"{scroll_info} "
        )
        pad_len = max(width - len(title) - 2, 0)
        left_pad = pad_len // 2
        right_pad = pad_len - left_pad
        header = f"{'─' * left_pad}{title}{'─' * right_pad}"

        fragments: list[tuple[str, str]] = [("fg:#6B7280", header)]

        hunk_pattern = re.compile(r"^@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@")
        # To track line numbers correctly, we must parse from the beginning
        old_line = 0
        new_line = 0
        visible_start = offset
        visible_end = offset + viewport

        for idx, line in enumerate(diff_lines):
            # Always parse hunk headers and file headers to track line numbers
            if line.startswith("---") or line.startswith("+++"):
                if visible_start <= idx < visible_end:
                    fragments.append(("", "\n"))
                    fragments.append(("fg:#6B7280", line))
                continue

            m = hunk_pattern.match(line)
            if m:
                old_line = int(m.group(1))
                new_line = int(m.group(2))
                if visible_start <= idx < visible_end:
                    fragments.append(("", "\n"))
                    fragments.append(("fg:#00BCD4", line))
                continue

            if visible_start <= idx < visible_end:
                fragments.append(("", "\n"))
                if line.startswith("-"):
                    prefix = f"{old_line:>4} "
                    prefix_width = get_cwidth(prefix)
                    content_width = max(0, width - prefix_width)
                    fitted = fit_single_line(line, content_width)
                    padding = " " * (content_width - get_cwidth(fitted))

                    fragments.append(("fg:#ffffff bg:#4a0202", prefix))
                    fragments.append(("fg:#ffffff bg:#4a0202", fitted + padding))
                elif line.startswith("+"):
                    prefix = f"{new_line:>4} "
                    prefix_width = get_cwidth(prefix)
                    content_width = max(0, width - prefix_width)
                    fitted = fit_single_line(line, content_width)
                    padding = " " * (content_width - get_cwidth(fitted))

                    fragments.append(("fg:#c6c6c6 bg:#2e502e", prefix))
                    fragments.append(("fg:#ffffff bg:#2e502e", fitted + padding))
                else:
                    fragments.append(("fg:#6B7280", f"{new_line:>4} "))
                    fragments.append(("fg:#6B7280", line))

            # Always update line counters
            if line.startswith("-"):
                old_line += 1
            elif line.startswith("+"):
                new_line += 1
            else:
                old_line += 1
                new_line += 1

        return fragments

    def _diff_panel_height(self) -> int:
        diff_lines = self._renderer.latest_diff_lines
        if not diff_lines:
            return 0
        viewport = self._DIFF_PANEL_MAX_VISIBLE - 1
        content_lines = min(len(diff_lines), viewport)
        return content_lines + 1  # +1 for header

    def _todo_text(self) -> list[tuple[str, str]]:
        lines = self._todo_panel_view()
        if not lines:
            return [("", " ")]

        width = self._terminal_width()
        fragments: list[tuple[str, str]] = []
        last_index = len(lines) - 1
        for idx, line in enumerate(lines):
            if idx == 0:
                title_elapsed_suffix = ""
                run_start = getattr(self, "_run_start_time", None)
                if run_start is not None:
                    elapsed = time.monotonic() - run_start
                    title_elapsed_suffix = (
                        f"  ({self._format_run_elapsed(elapsed)} • ctrl+c to interrupt)"
                    )
                title_budget = width - 1 - get_cwidth(title_elapsed_suffix)
                clipped_title = fit_single_line(line, max(title_budget, 8))
                fragments.extend(self._todo_title_shimmer_fragments(clipped_title))
                if title_elapsed_suffix:
                    fragments.append(("fg:#6B7280", title_elapsed_suffix))
            else:
                clipped = fit_single_line(line, width - 3)  # 留空间给 prefix + space
                # prefix 列：第一条任务行用 ⎿，后续用空格
                is_first_task_row = idx == 1
                prefix_char = "⎿" if is_first_task_row else " "
                prefix_style = "fg:#555555"

                # 解析符号和文本，应用分色
                if clipped.startswith("✓ "):
                    symbol, text = "✓", clipped[2:]
                    symbol_style = "fg:#86EFAC"
                    text_style = "fg:#6B7280 strike"
                elif clipped.startswith("◼ "):
                    symbol, text = "◼", clipped[2:]
                    symbol_style = "fg:#F97316"
                    text_style = "fg:#E2E8F0"
                elif clipped.startswith("▫ "):
                    # blocked pending: ▫ 是中间符号，渲染时显示为 ▢
                    symbol, text = "▢", clipped[2:]
                    symbol_style = "fg:#4B5563"
                    text_style = "fg:#4B5563"
                elif clipped.startswith("▢ "):
                    symbol, text = "▢", clipped[2:]
                    symbol_style = "fg:#6B7280"
                    text_style = "fg:#6B7280"
                else:
                    # 溢出行 "… (+N)" 等
                    symbol, text = "", clipped
                    symbol_style = ""
                    text_style = "fg:#6B7280"

                fragments.append((prefix_style, prefix_char))
                fragments.append(("", " "))
                if symbol:
                    fragments.append((symbol_style, symbol))
                    fragments.append(("", " "))
                fragments.append((text_style, text))
            if idx != last_index:
                fragments.append(("", "\n"))
        return fragments

    def _todo_height(self) -> int:
        lines = self._todo_panel_view()
        return max(1, len(lines))

    def _rich_text_to_pt_fragments(self, renderable: Any) -> list[tuple[str, str]]:
        """将 Rich Text 转换为 prompt_toolkit 的 fragments 格式."""
        from rich.segment import Segment

        fragments: list[tuple[str, str]] = []
        for segment in renderable.__rich_console__(console, console.options):
            if isinstance(segment, Segment):
                text = segment.text
                style = segment.style
                if style:
                    # 将 Rich style 转换为 prompt_toolkit style
                    pt_style = self._rich_style_to_pt(style)
                    fragments.append((pt_style, text))
                else:
                    fragments.append(("", text))
        while fragments and fragments[-1][1] == "\n":
            fragments.pop()
        return fragments if fragments else [("", " ")]

    def _rich_style_to_pt(self, rich_style: Any) -> str:
        """将 Rich style 转换为 prompt_toolkit style 字符串."""
        parts: list[str] = []
        if rich_style.bold:
            parts.append("bold")
        if rich_style.italic:
            parts.append("italic")
        if rich_style.underline:
            parts.append("underline")
        if rich_style.strike:
            parts.append("strike")
        if rich_style.dim:
            parts.append("dim")

        # 前景色
        if rich_style.color and rich_style.color.triplet:
            parts.append(f"fg:{rich_style.color.triplet.hex}")
        elif rich_style.color and rich_style.color.type.name == "STANDARD":
            parts.append(f"fg:ansi{rich_style.color.number}")
        elif rich_style.color and rich_style.color.type.name == "EIGHT_BIT":
            parts.append(f"fg:ansi{rich_style.color.number}")

        # 背景色
        if rich_style.bgcolor and rich_style.bgcolor.triplet:
            parts.append(f"bg:{rich_style.bgcolor.triplet.hex}")
        elif rich_style.bgcolor and rich_style.bgcolor.type.name == "STANDARD":
            parts.append(f"bg:ansi{rich_style.bgcolor.number}")
        elif rich_style.bgcolor and rich_style.bgcolor.type.name == "EIGHT_BIT":
            parts.append(f"bg:ansi{rich_style.bgcolor.number}")

        return " ".join(parts) if parts else ""
