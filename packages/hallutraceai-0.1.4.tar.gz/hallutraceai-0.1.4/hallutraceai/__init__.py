"""HalluTrace AI - Python SDK for LLM hallucination detection."""

from hallutraceai.client import HalluTrace

__version__ = "0.1.0"
__all__ = ["HalluTrace"]
