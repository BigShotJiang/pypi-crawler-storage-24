# HalluTrace AI - Python SDK

Detect hallucinations in your LLM applications with [HalluTrace AI](https://hallutraceai.com).

## Installation

```bash
pip install hallutraceai
```

## Quick Start

```python
from hallutraceai import HalluTrace

ht = HalluTrace(api_key="sk_live_your_api_key")

# Send a trace
ht.trace(
    session_id="chat-123",
    message_id="msg-1",
    type="agent",
    input="What is the capital of France?",
    output="The capital of France is Paris.",
    system_prompt="You are a helpful assistant.",
    model_name="gpt-4",
)
```

## Batch Tracing

```python
ht.trace_batch([
    {
        "session_id": "chat-123",
        "messages": [
            {
                "message_id": "msg-1",
                "type": "agent",
                "input": "Hello",
                "output": "Hi! How can I help?",
                "model_name": "gpt-4",
            },
            {
                "message_id": "msg-2",
                "type": "tool",
                "input": "search: weather",
                "output": '{"temp": 72, "condition": "sunny"}',
            },
        ],
    }
])
```

## Message Types

- `agent` — LLM responses (evaluated for hallucinations)
- `tool` — Tool/function call results (logged but not evaluated)

## API Reference

### `HalluTrace(api_key, base_url=None, timeout=30.0)`

Create a client instance.

### `ht.trace(session_id, message_id=None, type="agent", input="", output="", ...)`

Send a single trace. Returns session and message info.

### `ht.trace_batch(traces)`

Send multiple traces in one request.

## Links

- [Dashboard](https://hallutraceai.com/dashboard)
- [API Docs](https://api.hallutraceai.com/docs)
- [Support](mailto:support@hallutraceai.com)
