import os

from aiohttp import ClientSession
from requests import Session

from app.constants.proxies import get_proxy

from .agents import get_agent

PROXY_USERNAME = os.getenv("PROXY_USERNAME")
PROXY_PASSWORD = os.getenv("PROXY_PASSWORD")


class RandomUserAgentSession(Session):
    """
    Session class (inherited from requests.Session) which passes
    a random user agent with each request
    """

    def request(self, *args, **kwargs):
        self.headers.update({"User-Agent": get_agent()})

        return super().request(*args, **kwargs)


class AsyncRandomAgentSession(ClientSession):
    """
    Session class (inherited from aiohttp.ClientSession) which passes
    a random user agent and proxy with each request
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    async def _request(self, method, url, **kwargs):
        headers = kwargs.get("headers", {})
        headers.update({"User-Agent": get_agent()})
        kwargs["headers"] = headers
        if PROXY_USERNAME and PROXY_PASSWORD:
            kwargs["proxy"] = f"http://{PROXY_USERNAME}:{PROXY_PASSWORD}@{get_proxy()}"
        else:
            kwargs["proxy"] = f"http://{get_proxy()}"

        return await super()._request(method, url, **kwargs)
