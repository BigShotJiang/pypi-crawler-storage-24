"""Async Reddit API scraper using YARS pattern with fetch_async."""

import asyncio
import logging
import random
from typing import Any, Dict, List, Optional

from app.utils.common import fetch_async

logger = logging.getLogger(__name__)


class AsyncYARS:
    """Async version of YARS Reddit scraper using fetch_async."""

    __slots__ = ("use_proxy", "timeout")

    def __init__(self, timeout: int = 10, use_proxy: bool = True):
        """Initialize AsyncYARS with optional proxy and timeout."""
        self.timeout = timeout
        self.use_proxy = use_proxy

    async def handle_search(
        self,
        url: str,
        params: Dict[str, Any],
        after: Optional[str] = None,
        before: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Handle search requests with pagination support."""
        if after:
            params["after"] = after
        if before:
            params["before"] = before

        try:
            # Use fetch_async instead of requests.Session.get
            response = await fetch_async(
                url=url,
                method="GET",
                timeout=self.timeout,
                use_proxy=self.use_proxy,
                params=params,
            )

            # Get JSON data from response
            data = await response.json()
            logging.info("Search request successful")

        except Exception as e:
            logging.info("Search request unsuccessful due to: %s", e)
            print(f"Failed to fetch search results: {e}")
            return []

        results = []
        for post in data["data"]["children"]:
            post_data = post["data"]
            results.append(
                {
                    "title": post_data["title"],
                    "link": f"https://www.reddit.com{post_data['permalink']}",
                    "description": post_data.get("selftext", "")[:269],
                }
            )
        logging.info("Search Results Returned %d Results", len(results))
        return results

    async def search_reddit(
        self,
        query: str,
        limit: int = 10,
        after: Optional[str] = None,
        before: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Search Reddit for posts matching query."""
        url = "https://www.reddit.com/search.json"
        params = {"q": query, "limit": limit, "sort": "relevance", "type": "link"}
        return await self.handle_search(url, params, after, before)

    async def search_subreddit(
        self,
        subreddit: str,
        query: str,
        limit: int = 10,
        after: Optional[str] = None,
        before: Optional[str] = None,
        sort: str = "relevance",
    ) -> List[Dict[str, Any]]:
        """Search within a specific subreddit for posts matching query."""
        url = f"https://www.reddit.com/r/{subreddit}/search.json"
        params = {
            "q": query,
            "limit": limit,
            "sort": sort,
            "type": "link",
            "restrict_sr": "on",
        }
        return await self.handle_search(url, params, after, before)

    async def scrape_post_details(self, permalink: str) -> Optional[Dict[str, Any]]:
        """Scrape detailed information about a specific post, including comments."""
        url = f"https://www.reddit.com{permalink}.json"

        try:
            response = await fetch_async(
                url=url,
                method="GET",
                timeout=self.timeout,
                use_proxy=self.use_proxy,
            )

            post_data = await response.json()
            logging.info("Post details request successful : %s", url)

        except Exception as e:
            logging.info("Post details request unsuccessful: %s", e)
            print(f"Failed to fetch post data: {e}")
            return None

        if not isinstance(post_data, list) or len(post_data) < 2:
            logging.info("Unexpected post data structure")
            print("Unexpected post data structure")
            return None

        main_post = post_data[0]["data"]["children"][0]["data"]
        title = main_post["title"]
        body = main_post.get("selftext", "")

        comments = self._extract_comments(post_data[1]["data"]["children"])
        logging.info("Successfully scraped post: %s", title)
        return {"title": title, "body": body, "comments": comments}

    async def scrape_post_details_raw(self, permalink: str) -> Optional[Dict[str, Any]]:
        """Scrape detailed information about a specific post, including comments."""
        url = f"https://www.reddit.com{permalink}.json"

        try:
            response = await fetch_async(
                url=url,
                method="GET",
                timeout=self.timeout,
                use_proxy=self.use_proxy,
            )

            post_data = await response.json()
            logging.info("Post details request successful : %s", url)

        except Exception as e:
            logging.info("Post details request unsuccessful: %s", e)
            return None
        return post_data

    def _extract_comments(self, comments: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Extract comments from Reddit post data structure."""
        logging.info("Extracting comments")
        extracted_comments = []
        for comment in comments:
            if isinstance(comment, dict):
                if comment.get("kind") == "t1":
                    comment_data = comment.get("data", {})
                    extracted_comment = {
                        "author": comment_data.get("author", ""),
                        "body": comment_data.get("body", ""),
                        "score": comment_data.get("score", ""),
                        "replies": [],
                    }

                    replies = comment_data.get("replies", "")
                    if isinstance(replies, dict):
                        extracted_comment["replies"] = self._extract_comments(
                            replies.get("data", {}).get("children", [])
                        )
                    extracted_comments.append(extracted_comment)
                if comment.get("kind") == "more":
                    extracted_comments.append(comment.get("data", {}))
        logging.info("Successfully extracted comments")
        return extracted_comments

    async def _extract_comments_flatten(
        self, comments: List[Dict[str, Any]], subreddit_permalink: str
    ) -> List[Dict[str, Any]]:
        """Extract comments from Reddit post data structure, flattening hierarchical structure."""
        logging.info("Extracting comments (flattened)")
        extracted_comments = []

        for comment in comments:
            if isinstance(comment, dict):
                if comment.get("kind") == "t1":
                    comment_data = comment.get("data", {})

                    # Extract main comment data matching the database schema
                    extracted_comment = {
                        "comment_id": comment_data.get("id", ""),
                        "subreddit": comment_data.get("subreddit", ""),
                        "subreddit_id": comment_data.get("subreddit_id", ""),
                        "parent_id": comment_data.get("parent_id", ""),
                        "link_id": comment_data.get("link_id", ""),
                        "body": comment_data.get("body", ""),
                        "full_id": comment_data.get("name", ""),
                        "score": comment_data.get("score", 0),
                        "author": comment_data.get("author", ""),
                        "created_utc": comment_data.get("created_utc", 0.0),
                        "permalink": comment_data.get("permalink", ""),
                    }

                    extracted_comments.append(extracted_comment)

                    # Recursively extract replies (flattened)
                    replies = comment_data.get("replies", "")
                    if isinstance(replies, dict):
                        reply_children = replies.get("data", {}).get("children", [])
                        extracted_replies = await self._extract_comments_flatten(
                            reply_children, subreddit_permalink=subreddit_permalink
                        )
                        extracted_comments.extend(extracted_replies)

                elif comment.get("kind") == "more":
                    # Handle "more" comments placeholder - store metadata
                    data = comment.get("data", {})
                    children = data.get("children", [])
                    batch_size_hidden = 10
                    for i in range(0, len(children), batch_size_hidden):
                        max_index = min(i + batch_size_hidden, len(children))
                        batch = children[i:max_index]
                        hidden_data_task = [
                            self.fetch_hidden_comments(subreddit_permalink, post) for post in batch
                        ]
                        hidden_data = await asyncio.gather(*hidden_data_task)
                        for hidden_comment in hidden_data:
                            if hidden_comment is None or len(hidden_comment) == 0:
                                continue
                            extracted_comments.extend(
                                await self._extract_comments_flatten(
                                    hidden_comment[1]["data"]["children"],
                                    subreddit_permalink,
                                )
                            )

        logging.info("Successfully extracted %d flattened comments", len(extracted_comments))
        return extracted_comments

    async def scrape_user_data(self, username: str, limit: int = 10) -> List[Dict[str, Any]]:
        """Scrape user's posts and comments with pagination support."""
        logging.info("Scraping user data for %s, limit: %d", username, limit)
        base_url = f"https://www.reddit.com/user/{username}/.json"
        params = {"limit": limit, "after": None}
        all_items = []
        count = 0

        while count < limit:
            try:
                response = await fetch_async(
                    url=base_url,
                    method="GET",
                    timeout=self.timeout,
                    use_proxy=self.use_proxy,
                    params=params,
                )

                data = await response.json()
                logging.info("User data request successful")

            except Exception as e:
                logging.info("User data request unsuccessful: %s", e)
                print(f"Failed to fetch data for user {username}: {e}")
                break

            try:
                if "data" not in data or "children" not in data["data"]:
                    print(f"No 'data' or 'children' field found in response for user {username}.")
                    logging.info("No 'data' or 'children' field found in response")
                    break

                items = data["data"]["children"]
                if not items:
                    print(f"No more items found for user {username}.")
                    logging.info("No more items found for user")
                    break

                for item in items:
                    kind = item["kind"]
                    item_data = item["data"]
                    if kind == "t3":
                        post_url = f"https://www.reddit.com{item_data.get('permalink', '')}"
                        all_items.append(
                            {
                                "type": "post",
                                "title": item_data.get("title", ""),
                                "subreddit": item_data.get("subreddit", ""),
                                "url": post_url,
                                "created_utc": item_data.get("created_utc", ""),
                            }
                        )
                    elif kind == "t1":
                        comment_url = f"https://www.reddit.com{item_data.get('permalink', '')}"
                        all_items.append(
                            {
                                "type": "comment",
                                "subreddit": item_data.get("subreddit", ""),
                                "body": item_data.get("body", ""),
                                "created_utc": item_data.get("created_utc", ""),
                                "url": comment_url,
                            }
                        )
                    count += 1
                    if count >= limit:
                        break

                params["after"] = data["data"].get("after")
                if not params["after"]:
                    break

                # Use asyncio.sleep instead of time.sleep
                await asyncio.sleep(random.uniform(1, 2))
                logging.info("Sleeping for random time")

            except (KeyError, TypeError) as e:
                print(f"Failed to parse JSON response for user {username}: {e}")
                break

        logging.info("Successfully scraped user data for %s", username)
        return all_items

    async def fetch_hidden_comments(
        self, permalink: str, hidden_comment_id: str
    ) -> List[Dict[str, Any]]:
        """Get hidden comments for a post."""
        # https://www.reddit.com/r/ChatGPT/comments/1mtj4la/comment/n9hn4bs.json
        # permalink:"/r/ChatGPT/comments/1muf8li/were_so_cooked/" -> transformed_permalink: /r/ChatGPT/comments/1muf8li/
        try:
            transformed_permalink = (
                "/".join(permalink.split("/")[:-2]) + "/comments/" + hidden_comment_id
            )
            url = f"https://www.reddit.com{transformed_permalink}.json"
            response = await fetch_async(
                url=url, method="GET", timeout=self.timeout, use_proxy=self.use_proxy
            )
            data = await response.json()
            return data
        except Exception as e:
            logging.error("Failed to fetch hidden comments: %s", e)
            return None

    async def fetch_subreddit_posts(
        self,
        subreddit: str,
        limit: int = 10,
        category: str = "hot",
        time_filter: str = "all",
    ) -> List[Dict[str, Any]]:
        """Fetch posts from a subreddit or user with specified category and time filter."""
        logging.info(
            "Fetching subreddit/user posts for %s, limit: %d, category: %s, time_filter: %s",
            subreddit,
            limit,
            category,
            time_filter,
        )
        if category not in ["hot", "top", "new", "userhot", "usertop", "usernew"]:
            raise ValueError(
                "Category for Subreddit must be either 'hot', 'top', or 'new' or for User must be 'userhot', 'usertop', or 'usernew'"
            )

        batch_size = min(100, limit)
        total_fetched = 0
        after = None
        all_posts = []

        while total_fetched < limit:
            if category == "hot":
                url = f"https://www.reddit.com/r/{subreddit}/hot.json"
            elif category == "top":
                url = f"https://www.reddit.com/r/{subreddit}/top.json"
            elif category == "new":
                url = f"https://www.reddit.com/r/{subreddit}/new.json"
            elif category == "userhot":
                url = f"https://www.reddit.com/user/{subreddit}/submitted/hot.json"
            elif category == "usertop":
                url = f"https://www.reddit.com/user/{subreddit}/submitted/top.json"
            else:
                url = f"https://www.reddit.com/user/{subreddit}/submitted/new.json"

            params = {
                "limit": batch_size,
                "after": after,
                "raw_json": 1,
                "t": time_filter,
            }

            try:
                response = await fetch_async(
                    url=url,
                    method="GET",
                    timeout=self.timeout,
                    use_proxy=self.use_proxy,
                    params=params,
                )

                data = await response.json()
                logging.info("Subreddit/user posts request successful")

            except Exception as e:
                logging.error("Subreddit/user posts request unsuccessful: %s", e)
                break

            posts = data["data"]["children"]
            if not posts:
                break

            for post in posts:
                post_data = post["data"]
                post_info = {
                    "post_id": post_data["id"],
                    "title": post_data["title"],
                    "author": post_data["author"],
                    "permalink": post_data["permalink"],
                    "score": post_data["score"],
                    "num_comments": post_data["num_comments"],
                    "created_utc": post_data["created_utc"],
                }
                if post_data.get("post_hint") == "image" and "url" in post_data:
                    post_info["image_url"] = post_data["url"]
                elif "preview" in post_data and "images" in post_data["preview"]:
                    post_info["image_url"] = post_data["preview"]["images"][0]["source"]["url"]
                if "thumbnail" in post_data and post_data["thumbnail"] != "self":
                    post_info["thumbnail_url"] = post_data["thumbnail"]

                all_posts.append(post_info)
                total_fetched += 1
                if total_fetched >= limit:
                    break

            after = data["data"].get("after")
            if not after:
                break

            # Use asyncio.sleep instead of time.sleep
            await asyncio.sleep(random.uniform(1, 2))
            logging.info("Sleeping for random time")

        logging.info("Successfully fetched subreddit posts for %s", subreddit)
        return all_posts

    # async def fetch_comments(self, post_id, depth=0):
    #     url = f"https://www.reddit.com/comments/{post_id}.json"
    #     headers = {"User-Agent": "nested-comment-reader/0.1"}
    #     resp = await fetch_async(url, headers=headers)
    #     data = await resp.json()
    #     # The second element [1] contains the comments
    #     comments = data[1]["data"]["children"]
    #     return data


# if __name__ == "__main__":
#     permalink = "/r/ChatGPT/comments/1muf8li/were_so_cooked/"
#     hidden_comment_id = "n9hn4bs"
#     print("/".join(permalink.split("/")[:-2]) + "/comments/" + hidden_comment_id)
