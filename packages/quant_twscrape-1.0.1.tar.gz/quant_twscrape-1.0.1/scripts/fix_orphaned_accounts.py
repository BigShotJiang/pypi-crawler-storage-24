#!/usr/bin/env python3
"""
Fix orphaned accounts by re-adding them to specified queues.

This script finds accounts that are in tws:acc:active but not in any queue,
and adds them back to the specified queues.

Usage:
    # Fix UserTweets queue only
    python scripts/fix_orphaned_accounts.py --queue UserTweets

    # Fix all queues
    python scripts/fix_orphaned_accounts.py --all-queues

    # Dry run (show what would be fixed without making changes)
    python scripts/fix_orphaned_accounts.py --queue UserTweets --dry-run
"""

import asyncio
import argparse
import os
import redis.asyncio as aioredis


async def fix_orphaned_accounts(queue_names=None, all_queues=False, dry_run=False):
    """
    Fix orphaned accounts by adding them back to queues.

    Args:
        queue_names: List of specific queue names to fix (e.g., ['UserTweets'])
        all_queues: If True, add orphaned accounts to ALL existing queues
        dry_run: If True, only show what would be done without making changes
    """
    # Connect to Redis
    redis_url = os.getenv("TWS_REDIS_URL") or os.getenv("REDIS_URL") or "redis://localhost:6379"
    r = aioredis.from_url(redis_url, decode_responses=True)

    try:
        print("🔍 Finding orphaned accounts...")
        print()

        # Get all active accounts
        active_accounts = await r.smembers("tws:acc:active")
        print(f"📊 Total active accounts: {len(active_accounts)}")

        # Get all queue keys
        cursor = 0
        existing_queue_keys = []
        while True:
            cursor, keys = await r.scan(cursor, match="tws:queue:*")
            existing_queue_keys.extend(keys)
            if cursor == 0:
                break

        print(f"📊 Total existing queues: {len(existing_queue_keys)}")
        for queue_key in existing_queue_keys:
            queue_name = queue_key.replace("tws:queue:", "")
            count = await r.zcard(queue_key)
            print(f"  - {queue_name}: {count} accounts")
        print()

        # Find orphaned accounts (in active but not in any queue)
        orphaned = []
        for username in active_accounts:
            in_any_queue = False
            for queue_key in existing_queue_keys:
                if await r.zscore(queue_key, username) is not None:
                    in_any_queue = True
                    break

            if not in_any_queue:
                orphaned.append(username)

        if not orphaned:
            print("✅ No orphaned accounts found! Nothing to fix.")
            return

        print(f"❌ Found {len(orphaned)} orphaned accounts")
        print()

        # Determine which queues to add accounts to
        target_queues = []
        if all_queues:
            target_queues = [key.replace("tws:queue:", "") for key in existing_queue_keys]
            print(f"🎯 Will add orphaned accounts to ALL {len(target_queues)} queues")
        elif queue_names:
            target_queues = queue_names
            print(f"🎯 Will add orphaned accounts to specified queues: {', '.join(target_queues)}")
        else:
            print("❌ Error: Must specify either --queue or --all-queues")
            return

        print()

        if dry_run:
            print("🔍 DRY RUN MODE - No changes will be made")
            print()
            print(f"Would add {len(orphaned)} orphaned accounts to {len(target_queues)} queue(s):")
            for queue_name in target_queues:
                print(f"  - tws:queue:{queue_name}")
            print()
            print("Sample orphaned accounts (first 5):")
            for username in orphaned[:5]:
                print(f"  - {username}")
            if len(orphaned) > 5:
                print(f"  ... and {len(orphaned) - 5} more")
        else:
            print(f"🔧 Adding {len(orphaned)} orphaned accounts to {len(target_queues)} queue(s)...")
            print()

            # Add orphaned accounts to each target queue with score=0 (immediately available)
            for queue_name in target_queues:
                queue_key = f"tws:queue:{queue_name}"

                # Prepare mapping: {username: score}
                mapping = {username: 0 for username in orphaned}

                # Add all orphaned accounts to this queue
                await r.zadd(queue_key, mapping)

                new_count = await r.zcard(queue_key)
                print(f"  ✅ {queue_name}: Added {len(orphaned)} accounts (total now: {new_count})")

            print()
            print(f"✅ Successfully fixed {len(orphaned)} orphaned accounts!")

        print()
        print("📊 Final Summary:")
        print(f"  - Active accounts: {len(active_accounts)}")
        print(f"  - Orphaned accounts fixed: {len(orphaned) if not dry_run else 0}")
        print(f"  - Queues updated: {len(target_queues)}")

    finally:
        await r.aclose()


async def main():
    parser = argparse.ArgumentParser(
        description="Fix orphaned accounts by re-adding them to queues",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Fix UserTweets queue only
  python scripts/fix_orphaned_accounts.py --queue UserTweets

  # Fix multiple specific queues
  python scripts/fix_orphaned_accounts.py --queue UserTweets --queue Followers

  # Fix all existing queues
  python scripts/fix_orphaned_accounts.py --all-queues

  # Dry run (preview changes without making them)
  python scripts/fix_orphaned_accounts.py --queue UserTweets --dry-run
        """
    )

    parser.add_argument(
        "--queue",
        action="append",
        dest="queues",
        help="Queue name to fix (can be specified multiple times)"
    )
    parser.add_argument(
        "--all-queues",
        action="store_true",
        help="Fix all existing queues"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be done without making changes"
    )

    args = parser.parse_args()

    if not args.queues and not args.all_queues:
        parser.error("Must specify either --queue or --all-queues")

    if args.queues and args.all_queues:
        parser.error("Cannot specify both --queue and --all-queues")

    await fix_orphaned_accounts(
        queue_names=args.queues,
        all_queues=args.all_queues,
        dry_run=args.dry_run
    )


if __name__ == "__main__":
    asyncio.run(main())
