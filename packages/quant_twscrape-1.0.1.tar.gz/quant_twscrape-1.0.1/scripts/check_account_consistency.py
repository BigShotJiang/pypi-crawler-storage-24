#!/usr/bin/env python3
"""
Validation script to check for orphaned accounts in Redis.

This script checks for accounts that are in tws:acc:active but not in any queue,
which indicates the race condition bug.

Usage:
    python scripts/check_account_consistency.py
"""

import asyncio
import os
import redis.asyncio as aioredis


async def check_consistency():
    """Check for orphaned accounts in Redis."""
    # Connect to Redis
    redis_url = os.getenv("TWS_REDIS_URL") or os.getenv("REDIS_URL") or "redis://localhost:6379"
    r = aioredis.from_url(redis_url, decode_responses=True)

    try:
        print("🔍 Checking account consistency in Redis...")
        print()

        # Get all active accounts
        active_accounts = await r.smembers("tws:acc:active")
        print(f"📊 Total active accounts: {len(active_accounts)}")

        # Get all queue keys
        cursor = 0
        queue_keys = []
        while True:
            cursor, keys = await r.scan(cursor, match="tws:queue:*")
            queue_keys.extend(keys)
            if cursor == 0:
                break

        print(f"📊 Total queues found: {len(queue_keys)}")
        print()

        # Check each queue
        queue_stats = {}
        for queue_key in queue_keys:
            queue_name = queue_key.replace("tws:queue:", "")
            count = await r.zcard(queue_key)
            queue_stats[queue_name] = count
            print(f"  - {queue_name}: {count} accounts")

        print()

        # Find orphaned accounts (in active but not in any queue)
        orphaned = []
        for username in active_accounts:
            in_any_queue = False
            for queue_key in queue_keys:
                if await r.zscore(queue_key, username) is not None:
                    in_any_queue = True
                    break

            if not in_any_queue:
                orphaned.append(username)

        print("🔍 Orphaned accounts check:")
        if orphaned:
            print(f"  ❌ FOUND {len(orphaned)} orphaned accounts (in active but not in any queue):")
            for username in orphaned[:10]:  # Show first 10
                # Check if account really exists and is active
                acc_key = f"tws:acc:{username}"
                active_flag = await r.hget(acc_key, "active")
                error_msg = await r.hget(acc_key, "error_msg")
                print(f"    - {username} (active={active_flag}, error={error_msg[:50] if error_msg else 'None'})")

            if len(orphaned) > 10:
                print(f"    ... and {len(orphaned) - 10} more")

            print()
            print("🔧 To fix orphaned accounts, you can:")
            print("   1. Re-initialize the queue: await pool.init_queue('UserTweets')")
            print("   2. Or mark them properly inactive if they should be")
        else:
            print("  ✅ No orphaned accounts found! All active accounts are in at least one queue.")

        print()

        # Summary
        print("📈 Summary:")
        print(f"  - Active accounts: {len(active_accounts)}")
        print(f"  - Orphaned accounts: {len(orphaned)}")
        print(f"  - Percentage orphaned: {len(orphaned) / len(active_accounts) * 100:.2f}%")

    finally:
        await r.aclose()


if __name__ == "__main__":
    asyncio.run(check_consistency())
