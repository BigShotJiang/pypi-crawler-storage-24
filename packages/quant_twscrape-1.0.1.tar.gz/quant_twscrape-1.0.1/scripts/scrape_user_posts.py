#!/usr/bin/env python3
import argparse
import asyncio
import json
from dataclasses import asdict

from twscrape import API


def _extract_error_details(raw: object) -> str:
    if not isinstance(raw, dict):
        return "unparseable response payload"

    errors = raw.get("errors")
    if isinstance(errors, list) and errors:
        return "; ".join(
            str(item.get("message", item)) if isinstance(item, dict) else str(item)
            for item in errors
        )

    data = raw.get("data")
    if isinstance(data, dict):
        user_result = data.get("user", {}).get("result", {})
        reason = user_result.get("reason")
        if reason:
            return f"user.result.reason={reason}"

        typename = user_result.get("__typename")
        if typename:
            return f"user.result.__typename={typename}"

    return "no explicit error field from X response"


async def _resolve_user(api: API, username: str):
    normalized = username.strip().lstrip("@")

    # Try direct endpoint first.
    user = await api.user_by_login(normalized)
    if user is not None:
        return user

    # Fallback: user search and exact username match.
    async for candidate in api.search_user(normalized, limit=20):
        if candidate.username.lower() == normalized.lower():
            return candidate

    # Collect debug information from raw endpoint for better diagnostics.
    rep = await api.user_by_login_raw(normalized)
    if rep is None:
        raise ValueError(
            f"Could not resolve '{normalized}'. user_by_login_raw returned None "
            "(usually no available scraper account, auth failure, or temporary transport issue)."
        )

    status_code = getattr(rep, "status_code", "unknown")
    detail = "unknown"
    try:
        detail = _extract_error_details(rep.json())
    except Exception:
        detail = "failed to decode JSON payload"

    raise ValueError(
        f"Could not resolve '{normalized}' from X API. HTTP {status_code}. Detail: {detail}"
    )


async def scrape_user_posts(username: str, limit: int, latest_only: bool) -> list[dict]:
    api = API()
    user = await _resolve_user(api, username)

    # Keep output small and predictable for quick testing.
    posts: list[dict] = []
    source = (
        api.user_tweets(user.id, limit=limit)
        if latest_only
        else api.user_tweets_and_replies(user.id, limit=limit)
    )
    async for tweet in source:
        posts.append(asdict(tweet))
    return posts


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Scrape recent posts from an X account")
    parser.add_argument("--username", required=True, help="Target X username (without @)")
    parser.add_argument("--limit", type=int, default=20, help="Max number of posts to fetch")
    parser.add_argument(
        "--with-replies",
        action="store_true",
        help="Include replies (default: only original tweets)",
    )
    parser.add_argument(
        "--output",
        default="",
        help="Optional output file path (default: print to stdout)",
    )
    return parser.parse_args()


async def _main() -> None:
    args = parse_args()
    posts = await scrape_user_posts(
        username=args.username,
        limit=args.limit,
        latest_only=not args.with_replies,
    )

    payload = {
        "username": args.username,
        "count": len(posts),
        "posts": posts,
    }
    encoded = json.dumps(payload, ensure_ascii=True, default=str, indent=2)

    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(encoded + "\n")
        print(f"Wrote {len(posts)} posts to {args.output}")
    else:
        print(encoded)


if __name__ == "__main__":
    asyncio.run(_main())
