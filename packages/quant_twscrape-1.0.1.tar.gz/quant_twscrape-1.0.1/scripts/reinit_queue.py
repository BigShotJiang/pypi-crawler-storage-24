#!/usr/bin/env python3
"""
Re-initialize a specific queue with all active accounts.

This script adds ALL accounts from tws:acc:active to a specific queue,
regardless of whether they're already in other queues or not.

Usage:
    # Dry run (preview changes)
    python scripts/reinit_queue.py --queue UserTweets --dry-run

    # Actually reinitialize the queue
    python scripts/reinit_queue.py --queue UserTweets
"""

import asyncio
import argparse
import os
import redis.asyncio as aioredis


async def reinit_queue(queue_name, dry_run=False):
    """
    Re-initialize a queue with all active accounts.

    Args:
        queue_name: Name of the queue to reinitialize (e.g., 'UserTweets')
        dry_run: If True, only show what would be done without making changes
    """
    # Connect to Redis
    redis_url = os.getenv("TWS_REDIS_URL") or os.getenv("REDIS_URL") or "redis://localhost:6379"
    r = aioredis.from_url(redis_url, decode_responses=True)

    try:
        queue_key = f"tws:queue:{queue_name}"

        print(f"🔍 Re-initializing queue: {queue_name}")
        print()

        # Get all active accounts
        active_accounts = await r.smembers("tws:acc:active")
        print(f"📊 Total active accounts in tws:acc:active: {len(active_accounts)}")

        # Get current queue size
        current_size = await r.zcard(queue_key)
        print(f"📊 Current size of {queue_name} queue: {current_size}")
        print()

        if len(active_accounts) == 0:
            print("❌ No active accounts found in tws:acc:active")
            return

        # Calculate what would change
        accounts_to_add = len(active_accounts)
        print(f"📊 Accounts that will be added: {accounts_to_add}")
        print(f"📊 Expected final queue size: {accounts_to_add} (duplicates will be updated)")
        print()

        if dry_run:
            print("🔍 DRY RUN MODE - No changes will be made")
            print()
            print(f"Would add {accounts_to_add} active accounts to queue: {queue_name}")
            print("  - All accounts will have score=0 (immediately available)")
            print("  - Existing accounts in queue will have their scores updated to 0")
            print()
            print("Sample accounts (first 5):")
            for username in list(active_accounts)[:5]:
                current_score = await r.zscore(queue_key, username)
                if current_score is not None:
                    print(f"  - {username} (already in queue, score={current_score} → will be 0)")
                else:
                    print(f"  - {username} (NOT in queue → will be added)")
        else:
            print(f"🔧 Adding all {accounts_to_add} active accounts to {queue_name} queue...")
            print()

            # Prepare mapping: {username: 0} for all active accounts
            # ZADD with score=0 means immediately available
            mapping = {username: 0 for username in active_accounts}

            # Add all active accounts to the queue
            # Note: ZADD updates existing members, so this is safe to run multiple times
            added_count = await r.zadd(queue_key, mapping)

            new_size = await r.zcard(queue_key)
            print("✅ Queue re-initialized successfully!")
            print(f"  - New accounts added: {added_count}")
            print(f"  - Final queue size: {new_size}")
            print()

            # Verify consistency
            if new_size == len(active_accounts):
                print(f"✅ Perfect! Queue now has all {new_size} active accounts")
            else:
                print(f"⚠️  Warning: Queue size ({new_size}) doesn't match active accounts ({len(active_accounts)})")
                print("   This might be normal if some accounts were removed during the operation")

        print()
        print("📊 Summary:")
        print(f"  - Queue: {queue_name}")
        print(f"  - Active accounts: {len(active_accounts)}")
        print(f"  - Queue size before: {current_size}")
        if not dry_run:
            print(f"  - Queue size after: {new_size}")
            print(f"  - Change: +{new_size - current_size} accounts")

    finally:
        await r.aclose()


async def main():
    parser = argparse.ArgumentParser(
        description="Re-initialize a queue with all active accounts",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Preview changes (dry run)
  python scripts/reinit_queue.py --queue UserTweets --dry-run

  # Actually reinitialize UserTweets queue
  python scripts/reinit_queue.py --queue UserTweets

  # Reinitialize another queue
  python scripts/reinit_queue.py --queue SearchTimeline
        """
    )

    parser.add_argument(
        "--queue",
        required=True,
        help="Queue name to reinitialize (e.g., UserTweets, SearchTimeline)"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be done without making changes"
    )

    args = parser.parse_args()

    await reinit_queue(queue_name=args.queue, dry_run=args.dry_run)


if __name__ == "__main__":
    asyncio.run(main())
