"""Async HTTP client with proxy and retry patterns."""

import asyncio
import logging
import os
import random
from typing import Optional

import aiohttp

from app.constants.proxies import get_proxy
from yars.agents import get_agent as get_random_user_agent

PROXY_USERNAME = os.getenv("PROXY_USERNAME")
PROXY_PASSWORD = os.getenv("PROXY_PASSWORD")


logger = logging.getLogger(__name__)


async def fetch_async(
    url: str,
    method: str = "GET",
    max_retries: int = 3,
    timeout: int = 30,
    use_proxy: bool = True,
    session: Optional[aiohttp.ClientSession] = None,
    **kwargs,
) -> aiohttp.ClientResponse:
    """
    Async HTTP fetch with random proxy, user agent, and retry patterns.

    Args:
        url: Target URL to fetch
        method: HTTP method (GET, POST, etc.)
        max_retries: Maximum retry attempts
        timeout: Request timeout in seconds
        use_proxy: Whether to use random proxy
        session: Optional existing aiohttp session
        **kwargs: Additional arguments for aiohttp request

    Returns:
        aiohttp.ClientResponse object

    Raises:
        aiohttp.ClientError: After all retry attempts fail
    """
    close_session = session is None
    if session is None:
        session = aiohttp.ClientSession()

    try:
        for attempt in range(max_retries + 1):
            try:
                # Setup random proxy and user agent
                proxy = None
                if use_proxy:
                    proxy_addr = get_proxy()
                    if proxy_addr:  # Only set proxy if we get a valid address
                        if PROXY_USERNAME and PROXY_PASSWORD:
                            proxy = f"http://{PROXY_USERNAME}:{PROXY_PASSWORD}@{proxy_addr}"
                        else:
                            proxy = f"http://{proxy_addr}"

                headers = kwargs.pop("headers", {})
                headers["User-Agent"] = get_random_user_agent()

                # Configure timeout
                timeout_config = aiohttp.ClientTimeout(total=timeout)

                # Make request
                params = kwargs.pop("params", None)
                # Filter out None values from params
                if params:
                    params = {k: v for k, v in params.items() if v is not None}

                async with session.request(
                    method=method,
                    url=url,
                    proxy=proxy,
                    timeout=timeout_config,
                    headers=headers,
                    params=params,
                    **kwargs,
                ) as response:
                    # Return successful response
                    if response.status < 400:
                        logger.debug(f"Fetch successful: {method} {url} -> {response.status}")
                        # Read the response content within the context
                        content = await response.read()

                        # Create a mock response object with the data
                        class MockResponse:
                            def __init__(self, status, content, headers):
                                self.status = status
                                self._content = content
                                self.headers = headers

                            async def json(self):
                                import json

                                return json.loads(self._content.decode("utf-8"))

                            async def text(self):
                                return self._content.decode("utf-8")

                            async def read(self):
                                return self._content

                        return MockResponse(response.status, content, response.headers)

                    # Log non-successful status
                    logger.warning(f"HTTP {response.status} for {method} {url}")
                    if attempt == max_retries:
                        response.raise_for_status()

            except (aiohttp.ClientError, asyncio.TimeoutError) as e:
                if attempt == max_retries:
                    logger.error(f"Final attempt failed for {method} {url}: {e}")
                    raise

                # Exponential backoff with jitter
                delay = (2**attempt) + random.uniform(0, 1)
                logger.warning(
                    f"Attempt {attempt + 1} failed for {url}, retrying in {delay:.1f}s: {e}"
                )
                await asyncio.sleep(delay)

    finally:
        if close_session:
            await session.close()
