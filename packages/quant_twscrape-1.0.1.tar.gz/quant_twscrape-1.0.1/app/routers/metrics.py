"""
Prometheus metrics endpoint for account pool monitoring.

Exposes metrics in Prometheus format for scraping:
- Account statistics (total, active, inactive)
- Per-queue statistics (total accounts, total requests)
- Per-account request counts by queue

This endpoint does NOT require authentication (standard for Prometheus).
"""

import os
from typing import Any, Dict

from fastapi import APIRouter, Query
from fastapi.responses import JSONResponse, PlainTextResponse
from prometheus_client import CollectorRegistry, Counter, Gauge, generate_latest

from twscrape.logger import logger

router = APIRouter()


async def get_pool_instance():
    """Get the account pool instance directly (uses Redis v2)"""
    backend = "redis_v2"
    pool_url = None
    if backend == "redis_v2":
        from twscrape.redis_accounts_pool_v2 import RedisAccountsPoolV2

        pool_url = os.getenv("TWS_REDIS_URL") or os.getenv("REDIS_URL")
        return RedisAccountsPoolV2(pool_url)
    else:
        from twscrape.accounts_pool import AccountsPool

        pool_url = os.getenv("ACCOUNTS_DB_FILE", "accounts.db")
        return AccountsPool(pool_url)


@router.get("/metrics")
async def metrics_endpoint(
    format: str = Query("prometheus", description="Output format: 'prometheus' or 'json'"),
    include_members: bool = Query(
        False, description="Include queue member lists (slower, use for JSON format)"
    ),
    details: bool = Query(
        False, description="Include per-account request metrics (slower, high cardinality)"
    ),
):
    """
    Prometheus metrics endpoint for account pool monitoring.

    Query Parameters:
    - format: Output format ('prometheus' or 'json'). Default: 'prometheus'
    - include_members: Include list of usernames in each queue (only works with JSON format)
    - details: Include per-account request metrics (adds high cardinality metrics)

    Metrics always exposed:
    - twitter_accounts_total: Total number of accounts
    - twitter_accounts_active: Number of active accounts
    - twitter_accounts_inactive: Number of inactive accounts
    - twitter_queue_accounts_total{queue}: Total accounts in queue
    - twitter_queue_requests_total{queue}: Total requests per queue

    With details=true (high cardinality per-account metrics):
    - twitter_accounts_requests_total{username, queue}: Requests per account per queue
    - twitter_accounts_requests_total_all{username}: Total requests per account
    """
    pool = await get_pool_instance()

    try:
        # Fetch data from pool
        # Only include members for JSON format (too expensive for Prometheus scraping)
        fetch_members = include_members and format.lower() == "json"
        stats = await pool.stats(include_members=fetch_members)

        # Always fetch account stats to calculate queue request totals
        # But we only need the stats field, not full account details
        accounts_info = await pool.accounts_info(include_stats=True)
    except Exception as e:
        # Log the error
        logger.error(
            f"Error fetching metrics from account pool: {type(e).__name__}: {e}", exc_info=True
        )

        # Close pool on error
        if hasattr(pool, "close"):
            await pool.close()
        # Return error in JSON format for debugging
        return JSONResponse(
            status_code=500,
            content={
                "error": "Failed to fetch metrics from account pool",
                "detail": str(e),
                "type": type(e).__name__,
                "hint": "Check Redis keys with: redis-cli KEYS 'tws:queue:*' and verify types with TYPE command",
            },
        )

    # Close pool before generating output (we have all data we need)
    if hasattr(pool, "close"):
        await pool.close()

    if format.lower() == "json":
        # Return JSON format for human readability
        return JSONResponse(content=await _generate_json_metrics(stats, accounts_info, details))

    # Generate Prometheus format (default)
    prometheus_output = await _generate_prometheus_metrics(stats, accounts_info, details)
    return PlainTextResponse(content=prometheus_output)


async def _generate_prometheus_metrics(
    stats: Dict[str, Any], accounts_info: list, details: bool = False
) -> str:
    """
    Generate metrics in Prometheus text format.

    Exposes only essential metrics that are consistent across all instances.
    When details=True, also exposes high-cardinality per-account metrics.
    """
    registry = CollectorRegistry()

    # Account-level metrics
    accounts_total = Gauge(
        "twitter_accounts_total", "Total number of Twitter accounts", registry=registry
    )
    accounts_active = Gauge(
        "twitter_accounts_active", "Number of active accounts", registry=registry
    )
    accounts_inactive = Gauge(
        "twitter_accounts_inactive", "Number of inactive accounts", registry=registry
    )

    accounts_total.set(stats.get("total", 0))
    accounts_active.set(stats.get("active", 0))
    accounts_inactive.set(stats.get("inactive", 0))

    # Per-account request metrics (only when details=True)
    if details and accounts_info:
        account_requests = Gauge(
            "twitter_accounts_requests_total",
            "Total requests per account per queue",
            ["username", "queue"],
            registry=registry,
        )

        account_requests_all = Gauge(
            "twitter_accounts_requests_total_all",
            "Total requests per account (all queues)",
            ["username"],
            registry=registry,
        )

        # Process each account's stats
        for account in accounts_info:
            username = account.get("username", "")
            account_stats = account.get("stats", {})

            if account_stats:
                total_requests = 0
                for queue, count in account_stats.items():
                    account_requests.labels(username=username, queue=queue).set(count)
                    total_requests += count

                account_requests_all.labels(username=username).set(total_requests)

    # Queue-level metrics
    queue_accounts_total = Gauge(
        "twitter_queue_accounts_total", "Total accounts in queue", ["queue"], registry=registry
    )

    queue_requests_total = Counter(
        "twitter_queue_requests_total", "Total requests per queue", ["queue"], registry=registry
    )

    # Process queue stats
    queues = stats.get("queues", {})
    for queue_name, queue_data in queues.items():
        queue_accounts_total.labels(queue=queue_name).set(queue_data.get("total", 0))

        # Calculate total requests for this queue across all accounts
        total_queue_requests = sum(
            account.get("stats", {}).get(queue_name, 0) for account in accounts_info
        )
        queue_requests_total.labels(queue=queue_name).inc(total_queue_requests)

    # Generate Prometheus text format
    return generate_latest(registry).decode("utf-8")


async def _generate_json_metrics(
    stats: Dict[str, Any], accounts_info: list, details: bool = False
) -> Dict[str, Any]:
    """
    Generate metrics in JSON format for human readability.

    Exposes only essential metrics that are consistent across all instances.
    When details=True, also exposes per-account metrics.
    """

    # Calculate per-queue request totals (always) and account metrics (only if details=True)
    queue_requests = {}
    account_metrics = []

    # Always calculate queue request totals
    for account in accounts_info:
        account_stats = account.get("stats", {})

        # Aggregate by queue
        for queue, count in account_stats.items():
            queue_requests[queue] = queue_requests.get(queue, 0) + count

        # Only include per-account details if details=True
        if details:
            username = account.get("username", "")
            total_requests = sum(account_stats.values())

            account_metrics.append(
                {
                    "username": username,
                    "active": account.get("active", False),
                    "total_requests": total_requests,
                    "requests_by_queue": account_stats,
                }
            )

    # Build queue metrics
    queue_metrics = []
    queues = stats.get("queues", {})

    for queue_name, queue_data in queues.items():
        queue_metric = {
            "queue": queue_name,
            "accounts_total": queue_data.get("total", 0),
            "total_requests": queue_requests.get(queue_name, 0),  # Always include
        }

        queue_metrics.append(queue_metric)

    result = {
        "accounts": {
            "total": stats.get("total", 0),
            "active": stats.get("active", 0),
            "inactive": stats.get("inactive", 0),
        },
        "queues": queue_metrics,
    }

    # Only include account details if details=True
    if details and account_metrics:
        result["accounts"]["details"] = account_metrics

    return result
