"""
FastAPI routers package
"""
