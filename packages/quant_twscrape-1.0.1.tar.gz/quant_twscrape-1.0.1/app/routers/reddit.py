"""
Reddit router for FastAPI using local AsyncYARS service
"""

from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException, Query

from twscrape.logger import logger
from yars.async_yars import AsyncYARS

router = APIRouter()


def _get_async_yars(use_proxy: Optional[bool] = True, timeout: int = 10) -> AsyncYARS:
    return AsyncYARS(timeout=timeout, use_proxy=bool(use_proxy))


@router.get("/reddit/search", response_model=List[Dict[str, Any]])
async def reddit_search(
    q: str = Query(..., description="Search query"),
    limit: int = Query(default=10, ge=1, le=100),
    after: Optional[str] = Query(default=None, description="Reddit after token"),
    before: Optional[str] = Query(default=None, description="Reddit before token"),
    use_proxy: Optional[bool] = Query(default=True, description="Use proxy pool"),
    timeout: int = Query(default=10, ge=1, le=120),
):
    try:
        yars = _get_async_yars(use_proxy=use_proxy, timeout=timeout)
        results = await yars.search_reddit(q, limit=limit, after=after, before=before)
        return results
    except Exception as e:
        logger.error(
            f"Error searching Reddit with query '{q}': {type(e).__name__}: {e}", exc_info=True
        )
        raise HTTPException(status_code=500, detail=f"Error  searching Reddit: {str(e)}")


@router.get("/reddit/r/{subreddit}/search", response_model=List[Dict[str, Any]])
async def reddit_search_subreddit(
    subreddit: str,
    q: str = Query(..., description="Search query"),
    limit: int = Query(default=10, ge=1, le=100),
    sort: str = Query(default="relevance", description="Sort order"),
    after: Optional[str] = Query(default=None),
    before: Optional[str] = Query(default=None),
    use_proxy: Optional[bool] = Query(default=True),
    timeout: int = Query(default=10, ge=1, le=120),
):
    try:
        yars = _get_async_yars(use_proxy=use_proxy, timeout=timeout)
        results = await yars.search_subreddit(
            subreddit, q, limit=limit, after=after, before=before, sort=sort
        )
        return results
    except Exception as e:
        logger.error(
            f"Error searching subreddit '{subreddit}' with query '{q}': {type(e).__name__}: {e}",
            exc_info=True,
        )
        raise HTTPException(
            status_code=500,
            detail=f"Error  searching subreddit '{subreddit}': {str(e)}",
        )


@router.get("/reddit/post", response_model=Dict[str, Any])
async def reddit_post_details(
    permalink: str = Query(..., description="Permalink path like /r/sub/comments/..."),
    use_proxy: Optional[bool] = Query(default=True),
    timeout: int = Query(default=10, ge=1, le=120),
):
    try:
        yars = _get_async_yars(use_proxy=use_proxy, timeout=timeout)
        data = await yars.scrape_post_details(permalink)
        if data is None:
            raise HTTPException(status_code=404, detail="Post not found or invalid")
        return data
    except HTTPException:
        raise
    except Exception as e:
        logger.error(
            f"Error getting Reddit post details for {permalink}: {type(e).__name__}: {e}",
            exc_info=True,
        )
        raise HTTPException(status_code=500, detail=f"Error getting post details: {str(e)}")


@router.get("/reddit/user/{username}", response_model=List[Dict[str, Any]])
async def reddit_user_items(
    username: str,
    limit: int = Query(default=10, ge=1, le=1000),
    use_proxy: Optional[bool] = Query(default=True),
    timeout: int = Query(default=10, ge=1, le=120),
):
    try:
        yars = _get_async_yars(use_proxy=use_proxy, timeout=timeout)
        items = await yars.scrape_user_data(username, limit=limit)
        return items
    except Exception as e:
        logger.error(
            f"Error getting Reddit user data for '{username}': {type(e).__name__}: {e}",
            exc_info=True,
        )
        raise HTTPException(status_code=500, detail=f"Error getting user data: {str(e)}")


@router.get("/reddit/r/{subreddit}/posts", response_model=List[Dict[str, Any]])
async def reddit_subreddit_posts(
    subreddit: str,
    limit: int = Query(default=10, ge=1, le=1000),
    category: str = Query(
        default="hot", description="hot | top | new | userhot | usertop | usernew"
    ),
    time_filter: str = Query(default="all", description="hour, day, week, month, year, all"),
    use_proxy: Optional[bool] = Query(default=True),
    timeout: int = Query(default=10, ge=1, le=120),
):
    try:
        yars = _get_async_yars(use_proxy=use_proxy, timeout=timeout)
        posts = await yars.fetch_subreddit_posts(
            subreddit, limit=limit, category=category, time_filter=time_filter
        )
        return posts
    except ValueError as e:
        logger.warning(f"Invalid request for subreddit '{subreddit}': {e}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(
            f"Error getting subreddit posts for r/{subreddit}: {type(e).__name__}: {e}",
            exc_info=True,
        )
        raise HTTPException(status_code=500, detail=f"Error getting subreddit posts: {str(e)}")
