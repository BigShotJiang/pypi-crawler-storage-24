"""
Tweets router for FastAPI
"""

from typing import Any, Dict, List

from fastapi import APIRouter, Depends, HTTPException, Query

from app.dependencies import collect_async_generator, get_api
from app.models import (
    TweetsResponse,
)
from twscrape import API
from twscrape.logger import logger

router = APIRouter()


@router.get("/tweets/search", response_model=TweetsResponse)
async def search_tweets(
    q: str = Query(default="", description="Basic search query"),
    exact_phrase: str = Query(
        default=None, description="Exact phrase to search for (wrapped in quotes)"
    ),
    any_of_word: str = Query(default=None, description="Any of these words (OR logic)"),
    none_of_word: str = Query(default=None, description="None of these words (exclude)"),
    hashtags: str = Query(default=None, description="Hashtags to search for"),
    from_account: str = Query(default=None, description="Tweets from this account"),
    to_account: str = Query(default=None, description="Tweets to this account"),
    mention_account: str = Query(default=None, description="Tweets mentioning this account"),
    min_replies: int = Query(default=None, description="Minimum number of replies"),
    min_likes: int = Query(default=None, description="Minimum number of likes"),
    min_retweets: int = Query(default=None, description="Minimum number of retweets"),
    from_date: str = Query(default=None, description="Start date (YYYY-MM-DD)"),
    to_date: str = Query(default=None, description="End date (YYYY-MM-DD)"),
    limit: int = Query(default=20, ge=1, le=10000, description="Number of tweets to return"),
    product: str = Query(default="Latest", description="Search product type (Latest, Top, Media)"),
    api: API = Depends(get_api),
):
    """
    Advanced search for tweets with multiple filter options
    """
    try:
        # Build the final query using the provided logic
        q = " ".join(
            filter(
                None,
                [
                    q,
                    f'"{exact_phrase}"' if exact_phrase else None,
                    f"({any_of_word})" if any_of_word else None,
                    f"-{none_of_word}" if none_of_word else None,
                    f"(#{hashtags})" if hashtags else None,
                    f"(from:{from_account})" if from_account else None,
                    f"(to:{to_account})" if to_account else None,
                    f"(@{mention_account})" if mention_account else None,
                    f"min_replies:{min_replies}" if min_replies else None,
                    f"min_faves:{min_likes}" if min_likes else None,
                    f"min_retweets:{min_retweets}" if min_retweets else None,
                    f"since:{from_date}" if from_date else None,
                    f"until:{to_date}" if to_date else None,
                ],
            )
        ).strip()

        # Ensure we have a valid query
        if not q:
            raise HTTPException(
                status_code=400, detail="At least one search parameter must be provided"
            )

        kv = {"product": product} if product != "Latest" else None
        tweets = await collect_async_generator(api.search(q, limit=limit, kv=kv), limit=limit)

        return TweetsResponse(tweets=tweets, count=len(tweets), has_more=len(tweets) == limit)
    except HTTPException:
        # Re-raise HTTPException without modification to preserve status code
        raise
    except Exception as e:
        error_msg = str(e)
        logger.error(
            f"Unexpected error searching tweets: {type(e).__name__}: {error_msg}", exc_info=True
        )
        raise HTTPException(status_code=500, detail=f"Error searching tweets: {error_msg}")


@router.get("/tweets/{tweet_id}", response_model=Dict[str, Any])
async def get_tweet_details(tweet_id: int, api: API = Depends(get_api)):
    """
    Get detailed information about a specific tweet
    """
    try:
        tweet = await api.tweet_details(tweet_id)
        if tweet is None:
            raise HTTPException(status_code=404, detail="Tweet not found")

        return tweet.dict()
    except HTTPException:
        # Re-raise HTTPException without modification to preserve status code
        raise
    except ValueError as e:
        logger.warning(f"ValueError for tweet {tweet_id}: {str(e)}")
        raise HTTPException(status_code=404, detail="Tweet not found")
    except Exception as e:
        error_msg = str(e)
        logger.error(
            f"Unexpected error getting tweet details for {tweet_id}: {type(e).__name__}: {error_msg}",
            exc_info=True,
        )
        raise HTTPException(status_code=500, detail=f"Error getting tweet details: {error_msg}")


@router.get("/tweets/{tweet_id}/replies", response_model=TweetsResponse)
async def get_tweet_replies(
    tweet_id: int,
    limit: int = Query(default=20, ge=1, le=5000, description="Number of replies to return"),
    api: API = Depends(get_api),
):
    """
    Get replies to a specific tweet
    """
    try:
        replies = await collect_async_generator(
            api.tweet_replies(tweet_id, limit=limit), limit=limit
        )

        return TweetsResponse(tweets=replies, count=len(replies), has_more=len(replies) == limit)
    except Exception as e:
        logger.error(
            f"Error getting tweet replies for {tweet_id}: {type(e).__name__}: {e}", exc_info=True
        )
        raise HTTPException(status_code=500, detail=f"Error getting tweet replies: {str(e)}")


@router.get("/tweets/{tweet_id}/retweeters", response_model=List[Dict[str, Any]])
async def get_tweet_retweeters(
    tweet_id: int,
    limit: int = Query(default=20, ge=1, le=5000, description="Number of retweeters to return"),
    api: API = Depends(get_api),
):
    """
    Get users who retweeted a specific tweet
    """
    try:
        retweeters = await collect_async_generator(
            api.retweeters(tweet_id, limit=limit), limit=limit
        )

        return retweeters
    except Exception as e:
        logger.error(
            f"Error getting retweeters for {tweet_id}: {type(e).__name__}: {e}", exc_info=True
        )
        raise HTTPException(status_code=500, detail=f"Error getting retweeters: {str(e)}")


# @router.post("/tweets/search", response_model=TweetsResponse)
# async def search_tweets_post(request: SearchRequest, api: API = Depends(get_api)):
#     """
#     Search for tweets using POST method with request body
#     """
#     try:
#         kv = {"product": request.product} if request.product != "Latest" else None
#         tweets = await collect_async_generator(
#             api.search(request.query, limit=request.limit, kv=kv), limit=request.limit
#         )

#         return TweetsResponse(
#             tweets=tweets, count=len(tweets), has_more=len(tweets) == request.limit
#         )
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"Error searching tweets: {str(e)}")


@router.get("/tweets/community/{community_id}", response_model=TweetsResponse)
async def get_community_tweets(
    community_id: str,
    limit: int = Query(default=20, ge=1, le=1000, description="Number of tweets to return"),
    ranking_mode: str = Query(
        default="Relevance", description="Ranking mode (Relevance, Recency)"
    ),
    api: API = Depends(get_api),
):
    """
    Get tweets from a specific community by community ID
    """
    try:
        kv = {
            "communityId": community_id,
            "rankingMode": ranking_mode,
        }
        tweets = await collect_async_generator(
            api.community_tweets(limit=limit, kv=kv), limit=limit
        )

        return TweetsResponse(tweets=tweets, count=len(tweets), has_more=len(tweets) == limit)
    except Exception as e:
        logger.error(
            f"Error getting community tweets for {community_id}: {type(e).__name__}: {e}",
            exc_info=True,
        )
        raise HTTPException(status_code=500, detail=f"Error getting community tweets: {str(e)}")


@router.get("/tweets/article/{user_id}", response_model=TweetsResponse)
async def get_article_tweets(
    user_id: str,
    limit: int = Query(default=20, ge=1, le=1000, description="Number of tweets to return"),
    api: API = Depends(get_api),
):
    """
    Get tweets from a specific user by user ID
    """
    try:
        kv = {
            "userId": user_id,
        }
        tweets = await collect_async_generator(
            api.article_tweets_by_user_id(limit=limit, kv=kv), limit=limit
        )

        return TweetsResponse(tweets=tweets, count=len(tweets), has_more=len(tweets) == limit)
    except Exception as e:
        logger.error(
            f"Error getting article tweets for user {user_id}: {type(e).__name__}: {e}",
            exc_info=True,
        )
        raise HTTPException(status_code=500, detail=f"Error getting article tweets: {str(e)}")
