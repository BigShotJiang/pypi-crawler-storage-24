"""
Trends router for FastAPI
"""

from fastapi import APIRouter, Depends, HTTPException, Query

from app.dependencies import collect_async_generator, get_api
from app.models import TrendsRequest, TrendsResponse
from twscrape import API
from twscrape.logger import logger

router = APIRouter()


@router.get("/trends", response_model=TrendsResponse)
async def get_trends(
    trend_id: str = Query(
        default="trending",
        description="Trend ID or category (trending, news, sport, entertainment)",
    ),
    limit: int = Query(default=20, ge=1, le=1000, description="Number of trends to return"),
    api: API = Depends(get_api),
):
    """
    Get trending topics by category or trend ID

    Available trend categories:
    - trending: General trending topics
    - news: News trends
    - sport: Sports trends
    - entertainment: Entertainment trends

    You can also provide a specific trend ID string.
    """
    try:
        trends = await collect_async_generator(api.trends(trend_id, limit=limit), limit=limit)

        return TrendsResponse(trends=trends, count=len(trends), location=trend_id)
    except Exception as e:
        logger.error(
            f"Error getting trends for {trend_id}: {type(e).__name__}: {e}", exc_info=True
        )
        raise HTTPException(status_code=500, detail=f"Error getting trends: {str(e)}")


@router.get("/trends/search", response_model=TrendsResponse)
async def search_trends(
    q: str = Query(..., description="Search query for trends"),
    limit: int = Query(default=20, ge=1, le=1000, description="Number of trends to return"),
    api: API = Depends(get_api),
):
    """
    Search for trends based on a query
    """
    try:
        trends = await collect_async_generator(api.search_trend(q, limit=limit), limit=limit)

        return TrendsResponse(trends=trends, count=len(trends), location=f"search:{q}")
    except Exception as e:
        logger.error(
            f"Error searching trends with query '{q}': {type(e).__name__}: {e}", exc_info=True
        )
        raise HTTPException(status_code=500, detail=f"Error searching trends: {str(e)}")


@router.get("/trends/news", response_model=TrendsResponse)
async def get_news_trends(
    limit: int = Query(default=20, ge=1, le=1000, description="Number of news trends to return"),
    api: API = Depends(get_api),
):
    """
    Get news trending topics
    """
    try:
        trends = await collect_async_generator(api.trends("news", limit=limit), limit=limit)

        return TrendsResponse(trends=trends, count=len(trends), location="news")
    except Exception as e:
        logger.error(f"Error getting news trends: {type(e).__name__}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Error getting news trends: {str(e)}")


@router.get("/trends/sports", response_model=TrendsResponse)
async def get_sports_trends(
    limit: int = Query(default=20, ge=1, le=1000, description="Number of sports trends to return"),
    api: API = Depends(get_api),
):
    """
    Get sports trending topics
    """
    try:
        trends = await collect_async_generator(api.trends("sport", limit=limit), limit=limit)

        return TrendsResponse(trends=trends, count=len(trends), location="sport")
    except Exception as e:
        logger.error(f"Error getting sports trends: {type(e).__name__}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Error getting sports trends: {str(e)}")


@router.get("/trends/entertainment", response_model=TrendsResponse)
async def get_entertainment_trends(
    limit: int = Query(
        default=20,
        ge=1,
        le=1000,
        description="Number of entertainment trends to return",
    ),
    api: API = Depends(get_api),
):
    """
    Get entertainment trending topics
    """
    try:
        trends = await collect_async_generator(
            api.trends("entertainment", limit=limit), limit=limit
        )

        return TrendsResponse(trends=trends, count=len(trends), location="entertainment")
    except Exception as e:
        logger.error(f"Error getting entertainment trends: {type(e).__name__}: {e}", exc_info=True)
        raise HTTPException(
            status_code=500, detail=f"Error getting entertainment trends: {str(e)}"
        )


@router.post("/trends", response_model=TrendsResponse)
async def get_trends_post(request: TrendsRequest, api: API = Depends(get_api)):
    """
    Get trends using POST method with request body
    """
    try:
        trends = await collect_async_generator(
            api.trends(request.trend_id, limit=request.limit), limit=request.limit
        )

        return TrendsResponse(trends=trends, count=len(trends), location=request.trend_id)
    except Exception as e:
        logger.error(
            f"Error getting trends (POST) for {request.trend_id}: {type(e).__name__}: {e}",
            exc_info=True,
        )
        raise HTTPException(status_code=500, detail=f"Error getting trends: {str(e)}")
