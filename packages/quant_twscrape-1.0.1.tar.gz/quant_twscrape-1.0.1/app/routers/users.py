"""
Users router for FastAPI
"""

from typing import Any, Dict

from fastapi import APIRouter, Depends, HTTPException, Query

from app.dependencies import collect_async_generator, get_api
from app.models import (
    SearchUserRequest,
    TweetsResponse,
    UsersResponse,
)
from twscrape import API
from twscrape.logger import logger

router = APIRouter()


@router.get("/users/search", response_model=UsersResponse)
async def search_users(
    q: str = Query(..., description="Search query for users"),
    limit: int = Query(default=20, ge=1, le=1000, description="Number of users to return"),
    api: API = Depends(get_api),
):
    """
    Search for users based on a query
    """
    try:
        users = await collect_async_generator(api.search_user(q, limit=limit), limit=limit)

        return UsersResponse(users=users, count=len(users), has_more=len(users) == limit)
    except Exception as e:
        logger.error(
            f"Error searching users with query '{q}': {type(e).__name__}: {e}", exc_info=True
        )
        raise HTTPException(status_code=500, detail=f"Error searching users: {str(e)}")


# DEPRECATED: This endpoint has been deprecated and is no longer registered.
# Use /users/by-username/{username} instead.
# The code is kept here for reference only.
# @router.get("/users/by-id/{user_id}", response_model=Dict[str, Any])
async def get_user_by_id(user_id: int, api: API = Depends(get_api)):
    """
    DEPRECATED: Get user information by user ID

    This endpoint has been deprecated. Use /users/by-username/{username} instead.
    This code is kept for reference only and is not registered as a route.
    """
    try:
        user = await api.user_by_id(user_id)
        if user is None:
            raise HTTPException(status_code=404, detail="User not found")

        return user.dict()
    except HTTPException:
        # Re-raise HTTPException without modification to preserve status code
        raise
    except ValueError as e:
        logger.warning(f"ValueError for user {user_id}: {str(e)}")
        raise HTTPException(status_code=404, detail="User not found")
    except Exception as e:
        error_msg = str(e)
        logger.error(
            f"Unexpected error getting user by ID {user_id}: {type(e).__name__}: {error_msg}",
            exc_info=True,
        )
        raise HTTPException(status_code=500, detail=f"Error getting user by ID: {error_msg}")


@router.get("/users/by-username/{username}", response_model=Dict[str, Any])
async def get_user_by_username(username: str, api: API = Depends(get_api)):
    """
    Get user information by username/screen name
    """
    try:
        user = await api.user_by_login(username)
        if user is None:
            raise HTTPException(status_code=404, detail="User not found")

        return user.dict()
    except HTTPException:
        # Re-raise HTTPException without modification to preserve status code
        raise
    except ValueError as e:
        logger.warning(f"ValueError for user '{username}': {str(e)}")
        raise HTTPException(status_code=404, detail="User not found")
    except Exception as e:
        error_msg = str(e)
        logger.error(
            f"Unexpected error getting user by username '{username}': {type(e).__name__}: {error_msg}",
            exc_info=True,
        )
        raise HTTPException(status_code=500, detail=f"Error getting user by username: {error_msg}")


@router.get("/users/{user_id}/tweets", response_model=TweetsResponse)
async def get_user_tweets(
    user_id: int,
    limit: int = Query(default=20, ge=1, le=5000, description="Number of tweets to return"),
    api: API = Depends(get_api),
):
    """
    Get tweets from a specific user
    """
    try:
        tweets = await collect_async_generator(api.user_tweets(user_id, limit=limit), limit=limit)

        return TweetsResponse(tweets=tweets, count=len(tweets), has_more=len(tweets) == limit)
    except Exception as e:
        logger.error(
            f"Error getting user tweets for user {user_id}: {type(e).__name__}: {e}", exc_info=True
        )
        raise HTTPException(status_code=500, detail=f"Error getting user tweets: {str(e)}")


@router.get("/users/{user_id}/tweets-and-replies", response_model=TweetsResponse)
async def get_user_tweets_and_replies(
    user_id: int,
    limit: int = Query(default=20, ge=1, le=1000, description="Number of tweets to return"),
    api: API = Depends(get_api),
):
    """
    Get tweets and replies from a specific user
    """
    try:
        tweets = await collect_async_generator(
            api.user_tweets_and_replies(user_id, limit=limit), limit=limit
        )

        return TweetsResponse(tweets=tweets, count=len(tweets), has_more=len(tweets) == limit)
    except Exception as e:
        logger.error(
            f"Error getting user tweets and replies for user {user_id}: {type(e).__name__}: {e}",
            exc_info=True,
        )
        raise HTTPException(
            status_code=500, detail=f"Error getting user tweets and replies: {str(e)}"
        )


@router.get("/users/{user_id}/media", response_model=TweetsResponse)
async def get_user_media(
    user_id: int,
    limit: int = Query(default=20, ge=1, le=1000, description="Number of media tweets to return"),
    api: API = Depends(get_api),
):
    """
    Get media tweets from a specific user
    """
    try:
        media_tweets = await collect_async_generator(
            api.user_media(user_id, limit=limit), limit=limit
        )

        return TweetsResponse(
            tweets=media_tweets,
            count=len(media_tweets),
            has_more=len(media_tweets) == limit,
        )
    except Exception as e:
        logger.error(
            f"Error getting user media for user {user_id}: {type(e).__name__}: {e}", exc_info=True
        )
        raise HTTPException(status_code=500, detail=f"Error getting user media: {str(e)}")


@router.get("/users/{user_id}/followers", response_model=UsersResponse)
async def get_user_followers(
    user_id: int,
    limit: int = Query(default=20, ge=1, le=5000, description="Number of followers to return"),
    api: API = Depends(get_api),
):
    """
    Get followers of a specific user
    """
    try:
        followers = await collect_async_generator(api.followers(user_id, limit=limit), limit=limit)

        return UsersResponse(
            users=followers, count=len(followers), has_more=len(followers) == limit
        )
    except Exception as e:
        logger.error(
            f"Error getting user followers for user {user_id}: {type(e).__name__}: {e}",
            exc_info=True,
        )
        raise HTTPException(status_code=500, detail=f"Error getting user followers: {str(e)}")


@router.get("/users/{user_id}/following", response_model=UsersResponse)
async def get_user_following(
    user_id: int,
    limit: int = Query(default=70, ge=1, le=35000, description="Number of following to return"),
    api: API = Depends(get_api),
):
    """
    Get users that a specific user is following
    Optimized for high concurrency with per-request API instances
    """
    try:
        following = await collect_async_generator(api.following(user_id, limit=limit), limit=limit)

        return UsersResponse(
            users=following, count=len(following), has_more=len(following) == limit
        )
    except Exception as e:
        # Better error handling for concurrent requests
        error_msg = f"Error getting user following: {str(e)}"

        # Log the error first
        logger.error(
            f"Error getting user following for user {user_id}: {type(e).__name__}: {e}",
            exc_info=True,
        )

        # Check if it's an account availability issue
        if "No account available" in str(e):
            raise HTTPException(
                status_code=503,
                detail="Service temporarily unavailable - all Twitter accounts are busy. Please retry in a few moments.",
            )
        elif "Rate limit" in str(e):
            raise HTTPException(
                status_code=429,
                detail="Rate limit exceeded. Please retry after some time.",
            )
        else:
            raise HTTPException(status_code=500, detail=error_msg)


@router.get("/users/{user_id}/verified-followers", response_model=UsersResponse)
async def get_user_verified_followers(
    user_id: int,
    limit: int = Query(
        default=20, ge=1, le=50000, description="Number of verified followers to return"
    ),
    api: API = Depends(get_api),
):
    """
    Get verified followers of a specific user
    """
    try:
        verified_followers = await collect_async_generator(
            api.verified_followers(user_id, limit=limit), limit=limit
        )

        return UsersResponse(
            users=verified_followers,
            count=len(verified_followers),
            has_more=len(verified_followers) == limit,
        )
    except Exception as e:
        logger.error(
            f"Error getting verified followers for user {user_id}: {type(e).__name__}: {e}",
            exc_info=True,
        )
        raise HTTPException(status_code=500, detail=f"Error getting verified followers: {str(e)}")


@router.get("/users/{user_id}/subscriptions", response_model=UsersResponse)
async def get_user_subscriptions(
    user_id: int,
    limit: int = Query(default=20, ge=1, le=1000, description="Number of subscriptions to return"),
    api: API = Depends(get_api),
):
    """
    Get subscriptions of a specific user
    """
    try:
        subscriptions = await collect_async_generator(
            api.subscriptions(user_id, limit=limit), limit=limit
        )

        return UsersResponse(
            users=subscriptions,
            count=len(subscriptions),
            has_more=len(subscriptions) == limit,
        )
    except Exception as e:
        logger.error(
            f"Error getting user subscriptions for user {user_id}: {type(e).__name__}: {e}",
            exc_info=True,
        )
        raise HTTPException(status_code=500, detail=f"Error getting user subscriptions: {str(e)}")


@router.post("/users/search", response_model=UsersResponse)
async def search_users_post(request: SearchUserRequest, api: API = Depends(get_api)):
    """
    Search for users using POST method with request body
    """
    try:
        users = await collect_async_generator(
            api.search_user(request.query, limit=request.limit), limit=request.limit
        )

        return UsersResponse(users=users, count=len(users), has_more=len(users) == request.limit)
    except Exception as e:
        logger.error(
            f"Error searching users (POST) with query '{request.query}': {type(e).__name__}: {e}",
            exc_info=True,
        )
        raise HTTPException(status_code=500, detail=f"Error searching users: {str(e)}")


@router.get("/performance/stats", response_model=Dict[str, Any])
async def get_performance_stats():
    """
    Get API performance statistics for monitoring concurrent performance
    """
    try:
        from twscrape.accounts_pool import AccountsPool

        # Create a temporary pool to get stats
        pool = AccountsPool("accounts.db")
        stats = await pool.stats()

        return {
            "api_mode": "per-request-optimized",
            "account_stats": stats,
            "optimization_features": {
                "per_request_api_instances": True,
                "concurrent_processing": True,
                "fast_fail_accounts": True,
                "proxy_pool_integration": True,
            },
        }
    except Exception as e:
        return {
            "api_mode": "per-request-optimized",
            "error": str(e),
            "account_stats": "unavailable",
        }
