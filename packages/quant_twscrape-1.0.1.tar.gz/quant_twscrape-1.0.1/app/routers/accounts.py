"""
Accounts router for FastAPI - manages Twitter accounts for scraping
"""

import asyncio
from typing import Any, Dict, List

from fastapi import APIRouter, Depends, HTTPException, Query

from app.dependencies import get_api
from app.models import (
    AccountsResponse,
    AccountStatus,
    AddAccountRequest,
    SuccessResponse,
)
from twscrape import API
from twscrape.logger import logger

router = APIRouter()


@router.get("/accounts", response_model=AccountsResponse)
async def get_accounts(
    api: API = Depends(get_api),
    active_only: bool = Query(False, description="Return only active accounts"),
    include_stats: bool = Query(False, description="Include per-queue stats (slower)"),
):
    """
    Get list of all Twitter accounts and their status
    """
    try:
        accounts_data: List[AccountStatus] = []

        # Fast path: use accounts_info() (pipeline + HMGET) and avoid loading full accounts
        infos = await api.pool.accounts_info()
        if active_only:
            infos = [x for x in infos if x.get("active")]

        total_count = len(infos)
        page = infos  # return all

        if include_stats:
            # Fast path: bulk fetch stats directly from Redis without constructing Account objects
            usernames = [item["username"] for item in page]  # type: ignore
            if hasattr(api.pool, "get_stats_bulk"):
                stats_map = await api.pool.get_stats_bulk(usernames)  # type: ignore
            else:
                # Fallback: minimal concurrency get_account
                semaphore = asyncio.Semaphore(100)

                async def fetch_stats(u: str):
                    async with semaphore:
                        acc = await api.pool.get_account(u)
                        return u, (acc.stats if acc else {})

                pairs = await asyncio.gather(*[fetch_stats(u) for u in usernames])
                stats_map = {u: s for u, s in pairs}

            for item in page:
                u = item["username"]  # type: ignore
                accounts_data.append(
                    AccountStatus(
                        username=u,
                        active=bool(item["active"]),
                        last_used=item.get("last_used"),
                        total_req=stats_map.get(u, {}),
                        error_message=item.get("error_msg"),
                    )
                )
        else:
            # No stats: return empty stats dict for speed
            for item in page:
                accounts_data.append(
                    AccountStatus(
                        username=item["username"],
                        active=bool(item["active"]),
                        last_used=item.get("last_used"),
                        total_req={},
                        error_message=item.get("error_msg"),
                    )
                )

        active_count = sum(1 for acc in accounts_data if acc.active)

        return AccountsResponse(accounts=accounts_data, total=total_count, active=active_count)
    except Exception as e:
        logger.error(f"Error getting accounts: {type(e).__name__}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Error getting accounts: {str(e)}")


@router.post("/accounts", response_model=SuccessResponse)
async def add_account(request: AddAccountRequest, api: API = Depends(get_api)):
    """
    Add a new Twitter account to the pool
    """
    try:
        await api.pool.add_account(
            username=request.username,
            password=request.password,
            email=request.email,
            email_password=request.email_password,
            cookies=request.cookies,
        )

        return SuccessResponse(
            message=f"Account {request.username} added successfully",
            data={"username": request.username},
        )
    except Exception as e:
        logger.error(
            f"Error adding account {request.username}: {type(e).__name__}: {e}", exc_info=True
        )
        raise HTTPException(status_code=500, detail=f"Error adding account: {str(e)}")


@router.post("/accounts/login", response_model=SuccessResponse)
async def login_accounts(api: API = Depends(get_api)):
    """
    Attempt to login all accounts in the pool
    """
    try:
        login_results = await api.pool.login_all()

        return SuccessResponse(
            message="Login process completed",
            data={"total_attempts": len(login_results), "results": login_results},
        )
    except Exception as e:
        logger.error(f"Error during login process: {type(e).__name__}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Error during login process: {str(e)}")


@router.delete("/accounts/{username}", response_model=SuccessResponse)
async def delete_account(username: str, api: API = Depends(get_api)):
    """
    Delete a Twitter account from the pool
    """
    try:
        await api.pool.delete_accounts(username)
        return SuccessResponse(message=f"Account '{username}' deleted successfully")
    except Exception as e:
        logger.error(f"Error deleting account {username}: {type(e).__name__}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Error deleting account: {str(e)}")


@router.get("/accounts/{username}", response_model=AccountStatus)
async def get_account_status(username: str, api: API = Depends(get_api)):
    """
    Get status of a specific Twitter account
    """
    try:
        account = await api.pool.get_account(username)
        if account is None:
            raise HTTPException(status_code=404, detail="Account not found")

        return AccountStatus(
            username=account.username,
            active=account.active,
            last_used=account.last_used,
            total_requests=account.stats,
            error_message=account.error_msg,
        )
    except HTTPException:
        # Re-raise HTTPException without modification to preserve status code
        raise
    except Exception as e:
        error_msg = str(e)
        logger.error(
            f"Unexpected error getting account status for {username}: {type(e).__name__}: {error_msg}",
            exc_info=True,
        )
        raise HTTPException(status_code=500, detail=f"Error getting account status: {error_msg}")


@router.post("/accounts/{username}/relogin", response_model=SuccessResponse)
async def relogin_account(username: str, api: API = Depends(get_api)):
    """
    Attempt to re-login a specific account
    """
    try:
        account = await api.pool.get_account(username)
        if account is None:
            raise HTTPException(status_code=404, detail="Account not found")

        # Attempt to login the specific account
        success = await api.pool.login_account(account)

        return SuccessResponse(
            message=f"Re-login attempt completed for {username}",
            data={"username": username, "success": success},
        )
    except HTTPException:
        # Re-raise HTTPException without modification to preserve status code
        raise
    except Exception as e:
        error_msg = str(e)
        logger.error(
            f"Unexpected error re-logging account {username}: {type(e).__name__}: {error_msg}",
            exc_info=True,
        )
        raise HTTPException(status_code=500, detail=f"Error re-logging account: {error_msg}")


@router.get("/accounts/stats", response_model=Dict[str, Any])
async def get_account_stats(api: API = Depends(get_api)):
    """
    Get overall statistics about accounts in the pool
    """
    try:
        # Use the optimized stats() and accounts_info() methods from RedisAccountsPoolV2
        pool_stats = await api.pool.stats(include_members=False)
        accounts_info = await api.pool.accounts_info(include_stats=True)

        # Calculate total requests across all accounts
        total_requests = sum(sum(acc.get("stats", {}).values()) for acc in accounts_info)

        # Count accounts with errors
        accounts_with_errors = sum(1 for acc in accounts_info if acc.get("error_msg"))

        return {
            "total_accounts": pool_stats.get("total", 0),
            "active_accounts": pool_stats.get("active", 0),
            "inactive_accounts": pool_stats.get("inactive", 0),
            "accounts_with_errors": accounts_with_errors,
            "total_requests": total_requests,
        }
    except Exception as e:
        logger.error(f"Error getting account stats: {type(e).__name__}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Error getting account stats: {str(e)}")


@router.post("/accounts/recover-queues", response_model=Dict[str, Any])
async def recover_lost_accounts(api: API = Depends(get_api)):
    """
    Validate and recover lost accounts in queues.

    This endpoint detects and fixes account queue inconsistencies:
    - Accounts that are active but missing from all queues (lost accounts)
    - Recovers lost accounts by re-adding them to all queues

    This is useful when accounts have been lost due to crashes or errors
    between ZPOPMIN and ZADD operations.

    Returns statistics about the recovery operation.
    """
    try:
        recovery_stats = await api.pool.validate_and_recover_queues()

        return {
            "status": "success",
            "message": f"Queue validation complete. Recovered {recovery_stats['recovered']}/{recovery_stats['lost_accounts']} lost accounts.",
            "stats": recovery_stats,
        }
    except Exception as e:
        logger.error(f"Error recovering queues: {type(e).__name__}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Error recovering queues: {str(e)}")
