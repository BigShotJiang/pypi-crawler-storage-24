"""
Lists router for FastAPI
"""

from typing import Any, Dict

from fastapi import APIRouter, Depends, HTTPException, Query

from app.dependencies import collect_async_generator, get_api
from app.models import ListTimelineRequest, TweetsResponse
from twscrape import API
from twscrape.logger import logger

router = APIRouter()


@router.get("/lists/{list_id}/timeline", response_model=TweetsResponse)
async def get_list_timeline(
    list_id: int,
    limit: int = Query(default=20, ge=1, le=1000, description="Number of tweets to return"),
    api: API = Depends(get_api),
):
    """
    Get tweets from a Twitter list timeline
    """
    try:
        tweets = await collect_async_generator(
            api.list_timeline(list_id, limit=limit), limit=limit
        )

        return TweetsResponse(tweets=tweets, count=len(tweets), has_more=len(tweets) == limit)
    except Exception as e:
        logger.error(
            f"Error getting list timeline for list {list_id}: {type(e).__name__}: {e}",
            exc_info=True,
        )
        raise HTTPException(status_code=500, detail=f"Error getting list timeline: {str(e)}")


@router.post("/lists/timeline", response_model=TweetsResponse)
async def get_list_timeline_post(request: ListTimelineRequest, api: API = Depends(get_api)):
    """
    Get tweets from a Twitter list timeline using POST method with request body
    """
    try:
        tweets = await collect_async_generator(
            api.list_timeline(request.list_id, limit=request.limit), limit=request.limit
        )

        return TweetsResponse(
            tweets=tweets, count=len(tweets), has_more=len(tweets) == request.limit
        )
    except Exception as e:
        logger.error(
            f"Error getting list timeline (POST) for list {request.list_id}: {type(e).__name__}: {e}",
            exc_info=True,
        )
        raise HTTPException(status_code=500, detail=f"Error getting list timeline: {str(e)}")


@router.get("/lists/{list_id}", response_model=Dict[str, Any])
async def get_list_info(list_id: int, api: API = Depends(get_api)):
    """
    Get basic information about a Twitter list

    Note: This endpoint currently returns limited information.
    The full list information API may not be available in TWScrape.
    """
    try:
        # This is a placeholder - TWScrape may not have a dedicated list info endpoint
        # We'll return basic info and a sample of tweets from the list
        tweets = await collect_async_generator(api.list_timeline(list_id, limit=1), limit=1)

        return {
            "list_id": list_id,
            "has_tweets": len(tweets) > 0,
            "sample_tweet_count": len(tweets),
            "note": "Full list metadata not available via TWScrape. Use /lists/{list_id}/timeline to get tweets.",
        }
    except Exception as e:
        logger.error(
            f"Error getting list info for list {list_id}: {type(e).__name__}: {e}", exc_info=True
        )
        raise HTTPException(status_code=500, detail=f"Error getting list info: {str(e)}")
