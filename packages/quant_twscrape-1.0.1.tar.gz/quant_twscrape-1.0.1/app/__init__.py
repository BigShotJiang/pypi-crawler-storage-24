"""
FastAPI application package for Twitter Scraper
"""
