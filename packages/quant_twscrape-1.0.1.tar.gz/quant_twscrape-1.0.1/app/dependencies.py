"""
FastAPI dependencies
"""

import asyncio
import os
import time
from typing import AsyncGenerator, Tuple

from fastapi import HTTPException, Request, Security
from fastapi.security import APIKeyHeader

from twscrape import API

# Remove global API instance - create per request instead

# Swagger/OpenAPI API key auth scheme so "Authorize" works once for all endpoints
api_key_scheme = APIKeyHeader(name="X-ORAICHAIN-X-CRAWLER-API-KEY", auto_error=False)


async def verify_api_key(
    request: Request,
    x_oraichain_x_crawler_api_key: str | None = Security(api_key_scheme),
):
    """
    Verify API key from header against environment variable.
    Adds secondary whitelist keys that are rate-limited by request.

    Rate limit config is loaded from app.state:
      - app.state.rate_limit_whitelist: set[str]
      - app.state.rate_limit_requests: int (N requests)
      - app.state.rate_limit_window_minutes: int (X minutes)
      - app.state.rate_limit_counters: dict[str, tuple[int, float]]
      - app.state.rate_limit_lock: asyncio.Lock
    """
    expected_api_key = os.getenv("X_ORAICHAIN_X_CRAWLER_API_KEY")
    if not expected_api_key:
        raise HTTPException(status_code=500, detail="API key not configured on server")

    # Main key: full access, no rate limit
    if x_oraichain_x_crawler_api_key == expected_api_key:
        return True

    # Whitelisted keys: apply rate limit if configured
    app_state = request.app.state
    whitelist = getattr(app_state, "rate_limit_whitelist", set())
    if not x_oraichain_x_crawler_api_key:
        raise HTTPException(status_code=401, detail="Missing API key")

    if x_oraichain_x_crawler_api_key not in whitelist:
        raise HTTPException(status_code=401, detail="Invalid API key")

    max_requests: int = int(getattr(app_state, "rate_limit_requests", 60))
    window_minutes: int = int(getattr(app_state, "rate_limit_window_minutes", 1))
    window_seconds: int = window_minutes * 60

    counters = getattr(app_state, "rate_limit_counters", {})
    lock = getattr(app_state, "rate_limit_lock", None)

    now = time.time()

    async def _check_and_increment(key: str) -> Tuple[int, float]:
        """Return (count, reset_ts) after increment or reset within window."""
        entry = counters.get(key)
        if entry is None:
            counters[key] = (1, now)
            return counters[key]

        count, start_ts = entry
        # reset window if expired
        if now - start_ts >= window_seconds:
            counters[key] = (1, now)
            return counters[key]

        # within window
        new_count = count + 1
        counters[key] = (new_count, start_ts)
        return counters[key]

    # Ensure atomicity across concurrent requests
    if lock is not None:
        async with lock:
            count, start_ts = await _check_and_increment(x_oraichain_x_crawler_api_key)
    else:
        count, start_ts = await _check_and_increment(x_oraichain_x_crawler_api_key)

    if count > max_requests:
        reset_in = window_seconds - int(now - start_ts)
        reset_in = max(reset_in, 0)
        raise HTTPException(
            status_code=429,
            detail=f"Rate limit exceeded for API key. Allowed {max_requests} requests per {window_minutes} minutes. Retry in {reset_in} seconds.",
        )

    return True


async def get_api(request: Request) -> API:
    """
    Create API instance using shared pool from app state.
    The shared pool enables hot pool caching across requests for better performance.
    """
    # Get shared pool from app state
    pool = request.app.state.accounts_pool

    # Create API instance with shared pool
    # Each request gets its own API instance, but they share the same underlying pool
    # This allows concurrent requests while sharing the hot pool cache
    return API(
        pool=pool,
        debug=False,
        raise_when_no_account=False,
        use_random_proxy=False,
    )


async def collect_async_generator_concurrent(
    generator: AsyncGenerator, limit: int = -1, max_concurrent: int = 5
) -> list:
    """
    Optimized async generator collection with concurrent processing.
    Fetches multiple pages simultaneously for better performance.
    """
    items = []
    count = 0

    # Create semaphore to limit concurrent operations
    semaphore = asyncio.Semaphore(max_concurrent)

    async def process_item(item):
        async with semaphore:
            return item.dict() if hasattr(item, "dict") else item

    # Collect items with concurrent processing
    tasks = []
    async for item in generator:
        if limit > 0 and count >= limit:
            break

        # Create task for concurrent processing
        task = asyncio.create_task(process_item(item))
        tasks.append(task)
        count += 1

        # Process in batches to avoid memory issues
        if len(tasks) >= max_concurrent:
            batch_results = await asyncio.gather(*tasks)
            items.extend(batch_results)
            tasks.clear()

    # Process remaining tasks
    if tasks:
        remaining_results = await asyncio.gather(*tasks)
        items.extend(remaining_results)

    return items


async def collect_async_generator(generator: AsyncGenerator, limit: int = -1) -> list:
    """
    Helper function to collect items from an async generator
    Optimized version with concurrent processing for better performance
    """
    # Use the concurrent version for better performance
    return await collect_async_generator_concurrent(generator, limit, max_concurrent=10)


# Connection pool configuration for better performance
async def configure_api_pool_settings():
    """Configure optimal settings for high-concurrency scenarios"""
    # These would be applied when creating API instances
    return {
        "pool_timeout": 5.0,  # Don't wait too long for accounts
        "max_retries": 2,  # Fewer retries for faster failover
        "request_timeout": 30.0,  # Reasonable request timeout
    }
