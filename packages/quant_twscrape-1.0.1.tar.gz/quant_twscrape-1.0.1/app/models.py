"""
Pydantic models for FastAPI request/response validation
"""

from datetime import datetime
from typing import Any, Dict, List, Optional, Union

from pydantic import BaseModel, Field


class ErrorResponse(BaseModel):
    """Standard error response model"""

    error: str
    detail: Optional[str] = None
    status_code: int


class SuccessResponse(BaseModel):
    """Standard success response model"""

    message: str
    data: Optional[Any] = None


# Search Models
class SearchRequest(BaseModel):
    """Search tweets request model"""

    query: str = Field(..., description="Search query")
    limit: int = Field(default=20, ge=1, le=1000, description="Number of tweets to return")
    product: str = Field(
        default="Latest",
        description="Search product type (Latest, Top, Media, People)",
    )


class SearchUserRequest(BaseModel):
    """Search users request model"""

    query: str = Field(..., description="Search query for users")
    limit: int = Field(default=20, ge=1, le=1000, description="Number of users to return")


# User Models
class UserByIdRequest(BaseModel):
    """Get user by ID request model"""

    user_id: int = Field(..., description="User ID")


class UserByLoginRequest(BaseModel):
    """Get user by login request model"""

    username: str = Field(..., description="Username/screen name")


class UserTweetsRequest(BaseModel):
    """Get user tweets request model"""

    user_id: int = Field(..., description="User ID")
    limit: int = Field(default=20, ge=1, le=1000, description="Number of tweets to return")


class UserFollowersRequest(BaseModel):
    """Get user followers request model"""

    user_id: int = Field(..., description="User ID")
    limit: int = Field(default=20, ge=1, le=1000, description="Number of followers to return")


class UserFollowingRequest(BaseModel):
    """Get user following request model"""

    user_id: int = Field(..., description="User ID")
    limit: int = Field(default=20, ge=1, le=1000, description="Number of following to return")


# Tweet Models
class TweetDetailsRequest(BaseModel):
    """Get tweet details request model"""

    tweet_id: int = Field(..., description="Tweet ID")


class TweetRepliesRequest(BaseModel):
    """Get tweet replies request model"""

    tweet_id: int = Field(..., description="Tweet ID")
    limit: int = Field(default=20, ge=1, le=1000, description="Number of replies to return")


class TweetRetweetersRequest(BaseModel):
    """Get tweet retweeters request model"""

    tweet_id: int = Field(..., description="Tweet ID")
    limit: int = Field(default=20, ge=1, le=1000, description="Number of retweeters to return")


# Account Models
class AddAccountRequest(BaseModel):
    """Add account request model"""

    username: str = Field(..., description="Twitter username")
    password: str = Field(..., description="Twitter password")
    email: str = Field(..., description="Email address")
    email_password: str = Field(..., description="Email password")
    cookies: Optional[Union[str, Dict[str, str]]] = Field(
        None, description="Account cookies (optional)"
    )


class AccountStatus(BaseModel):
    """Account status response model"""

    username: str
    active: bool
    last_used: Optional[datetime]
    total_req: dict[str, int]
    error_message: Optional[str]


# Trends Models
class TrendsRequest(BaseModel):
    """Get trends request model"""

    trend_id: str = Field(default="trending", description="Trend ID or category")
    limit: int = Field(default=20, ge=1, le=1000, description="Number of trends to return")


# Lists Models
class ListTimelineRequest(BaseModel):
    """Get list timeline request model"""

    list_id: int = Field(..., description="List ID")
    limit: int = Field(default=20, ge=1, le=1000, description="Number of tweets to return")


class CommunityTweetsRequest(BaseModel):
    """Get community tweets request model"""

    community_id: str = Field(..., description="Community ID")
    limit: int = Field(default=20, ge=1, le=1000, description="Number of tweets to return")
    ranking_mode: str = Field(default="Relevance", description="Ranking mode (Relevance, Recency)")


# Response wrapper models
class TweetsResponse(BaseModel):
    """Tweets response wrapper"""

    tweets: List[Dict[str, Any]]
    count: int
    has_more: Optional[bool] = None


class UsersResponse(BaseModel):
    """Users response wrapper"""

    users: List[Dict[str, Any]]
    count: int
    has_more: Optional[bool] = None


class TrendsResponse(BaseModel):
    """Trends response wrapper"""

    trends: List[Dict[str, Any]]
    count: int
    location: Optional[str] = None


class AccountsResponse(BaseModel):
    """Accounts response wrapper"""

    accounts: List[AccountStatus]
    total: int
    active: int
