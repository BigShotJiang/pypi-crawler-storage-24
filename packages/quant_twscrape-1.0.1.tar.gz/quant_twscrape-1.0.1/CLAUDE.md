# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is a Twitter/X scraper API built on top of the TWScrape library, providing a FastAPI REST interface for Twitter data extraction. The project features a custom Redis-based account pool (v2) for high-concurrency operations and automatic rate limiting through intelligent account rotation.

## Key Commands

### Development
```bash
# Install dependencies
make install

# Run linter and tests
make check

# Run tests only
make test

# Run tests with coverage
make test-cov

# Lint code (ruff + pyright)
make lint
```

### Running the API
```bash
# Start server with uvicorn (development)
uvicorn main:app --host 0.0.0.0 --port 8000 --reload

# Or use uv
uv run python main.py

# Build and run with Docker
docker build -t oraichain-twitter-scraper:latest -f Dockerfile .
docker-compose up
```

### Testing
```bash
# Run all tests
pytest -s --cov=twscrape tests/

# Run specific test file
pytest tests/test_api.py

# Run Redis pool tests specifically
pytest tests/redis_account_pools/
```

### Account Management
```bash
# Import accounts from MongoDB to SQLite (REQUIRED before first use)
uv run python twitter_account_scripts/add_accounts_to_sqlite_db.py

# Import acc to redis
uv run python twitter_account_scripts/add_accounts_to_redis_db.py

# Check account consistency
uv run python scripts/check_account_consistency.py

# Fix orphaned accounts in Redis
uv run python scripts/fix_orphaned_accounts.py

# Reinitialize Redis queue
uv run python scripts/reinit_queue.py
```

## Architecture

### Core Components

1. **FastAPI Application** ([main.py](main.py))
   - Lifespan manager creates shared `accounts_pool` instance in `app.state`
   - Per-request API instances created via `get_api()` dependency
   - All API instances share the same underlying pool for hot pool efficiency
   - Supports both SQLite (local dev) and Redis v2 (production) backends

2. **Account Pool System** (twscrape/)
   - **Factory**: [twscrape/pools.py](twscrape/pools.py) - `create_accounts_pool()` returns appropriate pool type
   - **SQLite Pool**: [twscrape/accounts_pool.py](twscrape/accounts_pool.py) - Traditional file-based storage
   - **Redis Pool v2**: [twscrape/redis_accounts_pool_v2.py](twscrape/redis_accounts_pool_v2.py) - Queue-based architecture with hot pool caching
   - Pool selection: env var `TWS_POOL_BACKEND` or auto-detect from `TWS_REDIS_URL`/`REDIS_URL`

3. **API Routers** (app/routers/)
   - [tweets.py](app/routers/tweets.py) - Tweet search, details, replies, retweeters
   - [users.py](app/routers/users.py) - User profiles, followers, following, tweets
   - [accounts.py](app/routers/accounts.py) - Account management endpoints
   - [trends.py](app/routers/trends.py) - Trending topics
   - [lists.py](app/routers/lists.py) - Twitter list operations
   - [metrics.py](app/routers/metrics.py) - Prometheus metrics (no auth required)
   - [reddit.py](app/routers/reddit.py) - Reddit scraping via YARS

4. **YARS Reddit Scraper** (yars/)
   - Async Reddit scraping library
   - Used by reddit router for Reddit data extraction

### Data Flow

```
Client Request → FastAPI → verify_api_key (with rate limiting)
                         ↓
                    get_api() dependency (per-request API instance)
                         ↓
                    Shared accounts_pool (app.state)
                         ↓
                    Account selection & locking
                         ↓
                    Twitter GraphQL API request
                         ↓
                    Response parsing → Return to client
```

### Redis Pool v2 Architecture (Production)

The Redis v2 pool uses a queue-based architecture for superior performance under high load:

- **Hot Pool**: In-memory cache of frequently-used accounts per queue (configurable size, default 5)
- **Queue Structure**: Redis sorted sets track account availability by `last_used` timestamp
- **Account Selection**: `ZPOPMIN` atomically pops least-recently-used account from queue
- **Account Return**: `ZADD` atomically returns account to queue with updated timestamp
- **No Lua Scripts**: Simple Redis commands for better debugging and performance
- **Rate Limiting**: Handled by QueueClient (in [twscrape/queue_client.py](twscrape/queue_client.py)), not the pool

Key Redis keys:
- `tws:acc:all` - Hash of all account data
- `tws:queue:{queue_name}` - Sorted set of available accounts per queue (e.g., search, user_by_id)

### API Authentication & Rate Limiting

All endpoints (except `/health` and `/metrics`) require header:
```
X-ORAICHAIN-X-CRAWLER-API-KEY: <value>
```

Two key types:
1. **Main key** (from `X_ORAICHAIN_X_CRAWLER_API_KEY` env): Full access, no rate limit
2. **Whitelist keys** (from `RATE_LIMIT_WHITELIST_KEYS` env, comma-separated): Rate limited to N requests per X minutes (configured in [main.py](main.py) lifespan)

Rate limit counters stored in `app.state.rate_limit_counters` with asyncio lock for thread safety.

## Important Patterns

### Creating API Instances

**ALWAYS** use the dependency injection pattern:

```python
from app.dependencies import get_api

@router.get("/endpoint")
async def my_endpoint(api: API = Depends(get_api)):
    # api instance shares the pool but is request-specific
    result = await api.search("query", limit=20)
```

**NEVER** create API instances manually - this bypasses the shared pool and breaks hot pool efficiency.

### Collecting Async Generators

Use the helper from [app/dependencies.py](app/dependencies.py):

```python
from app.dependencies import collect_async_generator

tweets = await collect_async_generator(
    api.search("query", limit=100),
    limit=100
)
```

This handles concurrent processing with semaphores and proper dict conversion.

### Error Handling in Routers

Always log errors with context before raising HTTPException:

```python
from twscrape.logger import logger

try:
    result = await api.some_operation()
except Exception as e:
    logger.error(f"Error in operation: {type(e).__name__}: {e}", exc_info=True)
    raise HTTPException(status_code=500, detail=f"Error: {str(e)}")
```

## Configuration

### Environment Variables

**TWScrape Core:**
- `TWS_REDIS_URL` or `REDIS_URL` - Redis connection string (e.g., `redis://localhost:6379/0`)
- `TWS_REDIS_MAX_CONNECTIONS` - Maximum Redis connections per instance (default: 300). Formula: `expected_concurrent_requests × 5`. Recommended: 500-1000 for high-concurrency production. **Optimized**: Reduced per-request usage from ~12-15 to ~4-6 connections
- `TWS_REDIS_CONNECT_TIMEOUT` - Maximum time to establish Redis connection in seconds (default: 5.0). Prevents hanging on connection
- `TWS_REDIS_SOCKET_TIMEOUT` - Maximum time for Redis read/write operations in seconds (default: 5.0). Prevents hanging on slow operations
- `TWS_HOT_POOL_SIZE` - Number of accounts to prefetch per queue (default: 3, reduced from 5 for lower connection usage). Lower = fewer connections, Higher = better cache hit rate. Range: 1-10
- `TWS_POOL_BACKEND` - Force pool type: `sqlite`, `redis`, or `redis_v2`
- `TWS_LOG_LEVEL` - Logging level: TRACE, DEBUG, INFO, WARNING, ERROR, CRITICAL
- `ACCOUNTS_DB_FILE` - SQLite database path (default: `accounts.db`)
- `TWS_PROXY` - Global proxy for all accounts
- `TWS_WAIT_EMAIL_CODE` - Email verification timeout in seconds (default: 30)
- `TWS_RAISE_WHEN_NO_ACCOUNT` - Raise exception vs wait when no accounts available (default: false)

**API Server:**
- `X_ORAICHAIN_X_CRAWLER_API_KEY` - Main API key (required)
- `RATE_LIMIT_WHITELIST_KEYS` - Comma-separated secondary API keys with rate limiting
- `API_HOST`, `API_PORT`, `API_DEBUG` - Server configuration

**Sentry (Error Tracking & Performance Monitoring):**
- `SENTRY_DSN` - Sentry Data Source Name (leave empty to disable Sentry)
- `SENTRY_TRACES_SAMPLE_RATE` - Percentage of requests to trace (0.0-1.0, default: 1.0)
  - `1.0` = Trace 100% of requests (low-traffic or debugging)
  - `0.1` = Trace 10% of requests (high-traffic production)
  - `0.01` = Trace 1% of requests (very high-traffic APIs)
- `SENTRY_PROFILES_SAMPLE_RATE` - Percentage of traced requests to profile (0.0-1.0, default: 1.0)
  - `1.0` = Profile all traced requests (performance debugging)
  - `0.1` = Profile 10% of traced requests (balance between insight and overhead)

**Sentry Initialization:**
- Only initializes if `SENTRY_DSN` is configured
- **Version tracking**: Automatically reads version from `pyproject.toml` to identify which version has which bugs
- All errors are automatically captured regardless of sampling rates
- Health check (`/health`) and metrics (`/metrics`) endpoints are excluded from tracing
- Sampling reduces costs and performance overhead in high-traffic scenarios
- **Breadcrumbs** (max 100): Automatic "trail" of events before errors (HTTP requests, logs, DB queries)
- **Stack traces**: Attached to all messages for better debugging context

**To update version**: Edit `version = "x.x.x"` in `pyproject.toml` - changes are automatically detected on restart

### Docker Compose

The project uses a multi-instance setup ([docker-compose.yml](docker-compose.yml)):
- 5 API instances on ports 8101-8105
- All share the same Redis backend via `TWS_REDIS_URL`
- Health checks on `/health` endpoint
- External network: `distilledstg_backend_net`

## Testing

Tests are in [tests/](tests/) with mocked Twitter API responses in [tests/mocked-data/](tests/mocked-data/).

**Important test categories:**
- Core API tests: [tests/test_api.py](tests/test_api.py)
- Pool tests: [tests/test_pool.py](tests/test_pool.py)
- Redis pool tests: [tests/redis_account_pools/](tests/redis_account_pools/)
- Parser tests: [tests/test_parser.py](tests/test_parser.py)

To update mock data from live API:
```bash
make update-mocks
```

## Common Pitfalls

1. **Never create API instances directly** - Always use `get_api()` dependency to preserve shared pool
2. **Don't forget to collect async generators** - Use `collect_async_generator()` helper
3. **Redis connection limits** - Redis pool default is `max_connections=300` per instance (configurable via `TWS_REDIS_MAX_CONNECTIONS`)
4. **Hot pool size** - Default is 5 accounts per queue; tune based on concurrency needs
5. **Account consistency** - If Redis and reality diverge, run `scripts/fix_orphaned_accounts.py`
6. **Queue initialization** - If queues are corrupted, run `scripts/reinit_queue.py`

## Debugging

Enable debug logging:
```bash
export TWS_LOG_LEVEL=DEBUG
```

Check account pool status:
```bash
# Via API
curl -H "X-ORAICHAIN-X-CRAWLER-API-KEY: <key>" http://localhost:8000/api/v1/accounts

# Direct Redis inspection
redis-cli
> HGETALL tws:acc:all
> ZRANGE tws:queue:search 0 -1 WITHSCORES
```

Monitor metrics:
```bash
curl http://localhost:8000/metrics
```

## Reference Documentation

- [README.md](readme.md) - TWScrape library documentation
- [API_README.md](API_README.md) - FastAPI server documentation
- [DEVELOPMENT.md](DEVELOPMENT.md) - TWScrape development guide
- [ACCOUNTS_POOL_COMPARISON.md](ACCOUNTS_POOL_COMPARISON.md) - SQLite vs Redis comparison
