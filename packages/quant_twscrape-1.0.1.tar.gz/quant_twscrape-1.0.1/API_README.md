# Twitter Scraper FastAPI

A REST API for scraping Twitter data using the TWScrape library. This FastAPI application provides convenient HTTP endpoints for accessing Twitter data.

## 🚨 IMPORTANT: First Setup Required

**Before using the API, you MUST run the account setup script to add Twitter cookies to the local SQLite database:**

```bash
uv run python twitter_account_scripts/add_accounts_to_sqlite_db.py
```

This script connects to your MongoDB database and imports Twitter account cookies into the local SQLite database that the API uses for scraping.

## Features

- **Tweet Operations**: Search tweets, get tweet details, replies, and retweeters
- **User Operations**: Get user profiles, tweets, followers, following, and media
- **Trends**: Access trending topics by category
- **Lists**: Get tweets from Twitter lists
- **Account Management**: Manage Twitter accounts for scraping
- **Rate Limiting**: Automatic account rotation and rate limit handling
- **Async Support**: Full async/await support for high performance
- **Auto Documentation**: Interactive API documentation with Swagger UI

## Quick Start

### 1. Install Dependencies

```bash
# Using pip
pip install fastapi uvicorn twscrape

# Or using the project's dependencies
pip install -e .
```

### 2. Setup Twitter Accounts (Required)

```bash
# Add cookies from MongoDB to SQLite database
uv run python twitter_account_scripts/add_accounts_to_sqlite_db.py
```

### 3. Start the Server

```bash
# Method 1: Using the startup script
python start_server.py

# Method 2: Using uvicorn directly
uvicorn app:app --host 0.0.0.0 --port 8000 --reload

# Method 3: Using the app module
python app.py
```

### 4. Access the API

- **Interactive Documentation**: http://localhost:8000/docs
- **Alternative Documentation**: http://localhost:8000/redoc
- **Health Check**: http://localhost:8000/health

## API Endpoints

### Tweet Endpoints

#### Search Tweets
- `GET /api/v1/tweets/search?q={query}&limit={limit}&product={product}`
- `POST /api/v1/tweets/search` with JSON body

#### Tweet Details
- `GET /api/v1/tweets/{tweet_id}` - Get detailed tweet information

#### Tweet Replies
- `GET /api/v1/tweets/{tweet_id}/replies?limit={limit}` - Get tweet replies

#### Tweet Retweeters
- `GET /api/v1/tweets/{tweet_id}/retweeters?limit={limit}` - Get users who retweeted

### User Endpoints

#### Search Users
- `GET /api/v1/users/search?q={query}&limit={limit}`
- `POST /api/v1/users/search` with JSON body

#### User Information
- `GET /api/v1/users/by-id/{user_id}` - ⚠️ **DEPRECATED** - Get user by ID (use by-username instead)
- `GET /api/v1/users/by-username/{username}` - Get user by username (recommended)

#### User Content
- `GET /api/v1/users/{user_id}/tweets?limit={limit}` - User's tweets
- `GET /api/v1/users/{user_id}/tweets-and-replies?limit={limit}` - Tweets and replies
- `GET /api/v1/users/{user_id}/media?limit={limit}` - Media tweets

#### User Connections
- `GET /api/v1/users/{user_id}/followers?limit={limit}` - Followers
- `GET /api/v1/users/{user_id}/following?limit={limit}` - Following
- `GET /api/v1/users/{user_id}/verified-followers?limit={limit}` - Verified followers
- `GET /api/v1/users/{user_id}/subscriptions?limit={limit}` - Subscriptions

### Trends Endpoints

#### Get Trends
- `GET /api/v1/trends?trend_id={trend_id}&limit={limit}` - General trends
- `GET /api/v1/trends/news?limit={limit}` - News trends
- `GET /api/v1/trends/sports?limit={limit}` - Sports trends
- `GET /api/v1/trends/entertainment?limit={limit}` - Entertainment trends

#### Search Trends
- `GET /api/v1/trends/search?q={query}&limit={limit}` - Search trends

### Lists Endpoints

#### List Timeline
- `GET /api/v1/lists/{list_id}/timeline?limit={limit}` - Get list tweets
- `GET /api/v1/lists/{list_id}` - Get basic list information

### Account Management Endpoints

#### Account Operations
- `GET /api/v1/accounts` - List all accounts and their status
- `POST /api/v1/accounts` - Add a new account
- `GET /api/v1/accounts/{username}` - Get specific account status
- `DELETE /api/v1/accounts/{username}` - Delete account (not implemented)

#### Account Actions
- `POST /api/v1/accounts/login` - Login all accounts
- `POST /api/v1/accounts/{username}/relogin` - Re-login specific account
- `GET /api/v1/accounts/stats` - Get account statistics

## Authentication

All API endpoints require authentication using an API key in the header:

```bash
# Required header for all API calls
X-ORAICHAIN-X-CRAWLER-API-KEY: your-api-key-here
```

Set the API key in your environment:
```bash
export X_ORAICHAIN_X_CRAWLER_API_KEY="your-secret-api-key"
```

## Example Usage

### Using curl

#### Search for tweets
```bash
curl -H "X-ORAICHAIN-X-CRAWLER-API-KEY: your-api-key" \
  "http://localhost:8000/api/v1/tweets/search?q=python&limit=5"
```

#### Get user information
```bash
curl -H "X-ORAICHAIN-X-CRAWLER-API-KEY: your-api-key" \
  "http://localhost:8000/api/v1/users/by-username/elonmusk"
```

#### Get trending topics
```bash
curl "http://localhost:8000/api/v1/trends?trend_id=trending&limit=10"
```

### Using Python requests

```python
import requests

# Search tweets
response = requests.get(
    "http://localhost:8000/api/v1/tweets/search",
    params={"q": "AI", "limit": 10}
)
tweets = response.json()

# Get user info
response = requests.get(
    "http://localhost:8000/api/v1/users/by-username/elonmusk"
)
user = response.json()

# Add account for scraping
response = requests.post(
    "http://localhost:8000/api/v1/accounts",
    json={
        "username": "your_username",
        "password": "your_password",
        "email": "your_email@example.com",
        "email_password": "your_email_password"
    }
)
```

### Using JavaScript/fetch

```javascript
// Search tweets
const searchTweets = async (query, limit = 20) => {
    const response = await fetch(
        `http://localhost:8000/api/v1/tweets/search?q=${encodeURIComponent(query)}&limit=${limit}`
    );
    return await response.json();
};

// Get user by username
const getUser = async (username) => {
    const response = await fetch(
        `http://localhost:8000/api/v1/users/by-username/${username}`
    );
    return await response.json();
};

// Usage
searchTweets("machine learning", 10).then(console.log);
getUser("elonmusk").then(console.log);
```

## Account Setup

Before using the API for scraping, you need to add Twitter accounts:

### 1. Add Accounts

```bash
# Using curl
curl -X POST "http://localhost:8000/api/v1/accounts" \
  -H "Content-Type: application/json" \
  -d '{
    "username": "your_twitter_username",
    "password": "your_twitter_password",
    "email": "your_email@example.com",
    "email_password": "your_email_password"
  }'
```

### 2. Login Accounts

```bash
curl -X POST "http://localhost:8000/api/v1/accounts/login"
```

### 3. Check Account Status

```bash
curl "http://localhost:8000/api/v1/accounts"
```

## Configuration

### Environment Variables

You can configure the application using environment variables:

- `API_HOST`: Server host (default: 0.0.0.0)
- `API_PORT`: Server port (default: 8000)
- `API_DEBUG`: Enable debug mode (default: False)

### Rate Limiting

The API automatically handles Twitter's rate limiting by:
- Rotating between available accounts
- Waiting for rate limit resets
- Providing clear error messages when limits are exceeded

## Error Handling

The API returns standard HTTP status codes:

- `200`: Success
- `404`: Resource not found (user, tweet, etc.)
- `422`: Validation error (invalid parameters)
- `500`: Internal server error
- `503`: Service0
. unavailable (no accounts available)

Error responses include detailed messages:

```json
{
  "detail": "Error description",
  "status_code": 500
}
```

## Response Formats

### Tweet Response
```json
{
  "tweets": [...],
  "count": 10,
  "has_more": true
}
```

### User Response
```json
{
  "users": [...],
  "count": 5,
  "has_more": false
}
```

### Trends Response
```json
{
  "trends": [...],
  "count": 15,
  "location": "trending"
}
```

## Development

### Project Structure

```
├── app/
│   ├── __init__.py
│   ├── models.py          # Pydantic models
│   ├── dependencies.py    # Dependency injection
│   └── routers/           # API route handlers
│       ├── __init__.py
│       ├── tweets.py      # Tweet endpoints
│       ├── users.py       # User endpoints
│       ├── accounts.py    # Account management
│       ├── trends.py      # Trends endpoints
│       └── lists.py       # Lists endpoints
├── app.py                 # Main FastAPI application
├── start_server.py        # Server startup script
└── API_README.md          # This file
```

### Adding New Endpoints

1. Create new router in `app/routers/`
2. Add Pydantic models in `app/models.py`
3. Include router in `app.py`
4. Update documentation

## Troubleshooting

### Common Issues

#### 1. No accounts available (503 error)
- Add Twitter accounts using the `/accounts` endpoint
- Ensure accounts are successfully logged in

#### 2. Rate limit exceeded
- Add more Twitter accounts for rotation
- Wait for rate limits to reset (usually 15 minutes)

#### 3. Authentication failures
- Check account credentials
- Verify email access for 2FA verification

#### 4. Import errors
- Ensure all dependencies are installed
- Check Python path and module structure

### Debugging

Enable debug mode for detailed logging:

```python
# In app.py, modify the lifespan function:
api_instance = API(debug=True)
```

## Security Considerations

- Store account credentials securely
- Use HTTPS in production
- Implement authentication for the API if needed
- Monitor rate limits and usage
- Regularly rotate Twitter account passwords

## Contributing

1. Fork the repository
2. Create a feature branch
3. Add tests for new functionality
4. Submit a pull request

## License

This project uses the same license as the TWScrape library (MIT License).

## Support

For issues related to:
- **Twitter scraping**: Check TWScrape documentation
- **FastAPI usage**: Check FastAPI documentation
- **This API wrapper**: Create an issue in the repository
