import asyncio
import os

from twscrape import API
from twscrape.logger import logger


async def run_once_and_check_stats():
    redis_url = os.getenv("TWS_REDIS_URL", None)
    api = API(pool=redis_url, raise_when_no_account=False, use_random_proxy=False)

    # Capture stats before
    infos_before = await api.pool.accounts_info(include_stats=True)
    if not infos_before:
        logger.error("No accounts in pool")
        return False

    # For user_by_id, the internal queue is the GQL op tail: "UserByRestId"
    user_by_id_queue = "UserByRestId"

    # Perform request and capture which account was used
    try:
        rep = await asyncio.wait_for(api.user_by_id_raw(21), timeout=30.0)
        if not rep:
            logger.error("user_by_id_raw returned None")
            return False
        used_username = getattr(rep, "__username", None)
        if not used_username:
            logger.error("Could not detect used username from response (__username missing)")
            return False
    except Exception as e:
        logger.error(f"user_by_id_raw failed: {e}")
        return False

    # Sanity checks: ensure Redis pool and account presence
    # logger.info(f"Pool class: {type(api.pool).__name__}")
    # try:
    #     in_set = await api.pool._r.sismember(api.pool._k_accounts_all, used_username)  # type: ignore
    #     h_exists = await api.pool._r.exists(api.pool._acc_key(used_username))  # type: ignore
    #     logger.info(
    #         f"Redis membership for @{used_username}: in_set={bool(in_set)}, hash_exists={bool(h_exists)}, key={api.pool._acc_key(used_username)}"  # type: ignore
    #     )
    #     if not in_set or not h_exists:
    #         logger.error("Used username not found in Redis set/hash - check Redis URL/DB and population")
    #         return False
    # except Exception as e:
    #     logger.error(f"Redis sanity checks failed: {e}")
    #     return False

    # Aggregate BEFORE across all accounts
    def sum_queue(acc_list, q):
        total = 0
        for it in acc_list:
            st = it.get("stats", {}) or {}
            v = st.get(q, 0)
            try:
                total += int(v)
            except Exception:
                pass
        return total

    def sum_all(acc_list):
        total = 0
        for it in acc_list:
            st = it.get("stats", {}) or {}
            for v in st.values():
                try:
                    total += int(v)
                except Exception:
                    pass
        return total

    before_specific_sum = sum_queue(infos_before, user_by_id_queue)
    before_total_sum = sum_all(infos_before)

    # Small delay to ensure the unlock/save finished
    await asyncio.sleep(0.5)

    # Aggregate AFTER across all accounts
    infos_after = await api.pool.accounts_info(include_stats=True)
    after_specific_sum = sum_queue(infos_after, user_by_id_queue)
    after_total_sum = sum_all(infos_after)

    logger.info(f"Specific({user_by_id_queue}) sum before: {before_specific_sum}, after: {after_specific_sum}")
    logger.info(f"Total sum before: {before_total_sum}, after: {after_total_sum}")
    return (after_specific_sum >= before_specific_sum + 1) or (after_total_sum >= before_total_sum + 1)


async def main():
    ok = await run_once_and_check_stats()
    if ok:
        logger.info("✓ Stats increment test passed")
    else:
        logger.error("✗ Stats increment test failed")


if __name__ == "__main__":
    import logging
    logging.basicConfig(level=logging.INFO)
    asyncio.run(main())
