"""
Realistic multiprocess load test simulating 10 scraper instances with 1 Redis instance.
Uses instrumented Redis pool to separately track Redis operations vs GraphQL latency.
"""

import asyncio
import json
import multiprocessing as mp
import os
import sys
import time
from dataclasses import dataclass, asdict, field
from typing import Dict, List, Any, Optional
from datetime import datetime

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from twscrape import API
from twscrape.logger import logger

# Import instrumented Redis pool
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from instrumented_redis_pool import InstrumentedRedisPool


@dataclass
class DetailedLatencyMetrics:
    """Complete latency breakdown for a single API call"""
    # Redis operation breakdown
    redis_smembers_ms: float = 0.0
    redis_pipeline_ms: float = 0.0
    redis_json_parse_ms: float = 0.0
    redis_lua_eval_ms: float = 0.0
    redis_reload_ms: float = 0.0
    redis_total_ms: float = 0.0

    # Redis operation counts
    batches_checked: int = 0
    accounts_checked: int = 0
    lock_attempts: int = 0

    # GraphQL timing
    graphql_request_ms: float = 0.0

    # Overall
    total_ms: float = 0.0
    success: bool = False
    error: Optional[str] = None
    process_id: int = 0


@dataclass
class ProcessStats:
    """Statistics for a single scraper process"""
    process_id: int
    total_requests: int = 0
    successful_requests: int = 0
    failed_requests: int = 0

    # Detailed metrics per request
    all_metrics: List[DetailedLatencyMetrics] = field(default_factory=list)

    # Aggregated Redis metrics
    redis_smembers_times: List[float] = field(default_factory=list)
    redis_pipeline_times: List[float] = field(default_factory=list)
    redis_lua_eval_times: List[float] = field(default_factory=list)
    redis_total_times: List[float] = field(default_factory=list)

    # Aggregated GraphQL metrics
    graphql_times: List[float] = field(default_factory=list)

    # Aggregated total times
    total_times: List[float] = field(default_factory=list)

    # Timing
    start_time: float = 0.0
    end_time: float = 0.0
    duration: float = 0.0


async def fetch_user_with_instrumented_pool(
    instrumented_pool: InstrumentedRedisPool,
    user_id: str,
    process_id: int,
    timeout: float = 30.0
) -> DetailedLatencyMetrics:
    """
    Fetch user info with detailed Redis operation tracking.
    Uses instrumented pool to capture Redis-level metrics.
    """
    total_start = time.time()
    metrics = DetailedLatencyMetrics(process_id=process_id)

    try:
        # Create API instance with our instrumented pool
        api = API(pool=instrumented_pool)

        # Get account with instrumentation (this captures Redis metrics)
        queue = "UserByRestId"  # Queue name for user_by_id operation

        # Call the instrumented get_for_queue method
        account, redis_metrics = await instrumented_pool.get_for_queue_instrumented(queue)

        if not account:
            metrics.error = redis_metrics.error or "No account available"
            metrics.redis_total_ms = redis_metrics.total_account_mgmt_time * 1000
            metrics.total_ms = (time.time() - total_start) * 1000
            return metrics

        # Capture Redis operation metrics
        metrics.redis_smembers_ms = redis_metrics.smembers_time * 1000
        metrics.redis_pipeline_ms = redis_metrics.pipeline_execute_time * 1000
        metrics.redis_json_parse_ms = redis_metrics.json_parse_time * 1000
        metrics.redis_lua_eval_ms = redis_metrics.lua_eval_time * 1000
        metrics.redis_reload_ms = redis_metrics.reload_time * 1000
        metrics.redis_total_ms = redis_metrics.total_account_mgmt_time * 1000
        metrics.batches_checked = redis_metrics.batches_checked
        metrics.accounts_checked = redis_metrics.accounts_checked
        metrics.lock_attempts = redis_metrics.lock_attempts

        # Now make the actual GraphQL request
        graphql_start = time.time()

        # Create client for this account

        clt = account.make_client()

        # Set up headers (same as queue_client does)
        TOKEN = "Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA"
        clt.headers["authorization"] = TOKEN
        clt.headers["user-agent"] = account.user_agent
        clt.headers["content-type"] = "application/json"
        clt.headers["x-twitter-active-user"] = "yes"
        clt.headers["x-twitter-client-language"] = "en"

        # Add cookies
        clt.cookies.update(account.cookies)
        if "ct0" in clt.cookies:
            clt.headers["x-csrf-token"] = clt.cookies["ct0"]

        # Make GraphQL request
        from twscrape.api import GQL_URL, OP_UserByRestId, GQL_FEATURES
        from twscrape.utils import encode_params

        op = OP_UserByRestId
        kv = {"userId": str(user_id), "withSafetyModeUserFields": True}
        ft = {**GQL_FEATURES}
        params = {"variables": kv, "features": ft}

        try:
            rep = await asyncio.wait_for(
                clt.get(f"{GQL_URL}/{op}", params=encode_params(params)),
                timeout=timeout
            )

            graphql_time = time.time() - graphql_start
            metrics.graphql_request_ms = graphql_time * 1000

            if rep.status_code == 200:
                metrics.success = True
            else:
                metrics.error = f"HTTP {rep.status_code}"

        except asyncio.TimeoutError:
            metrics.error = "GraphQL timeout"
            metrics.graphql_request_ms = (time.time() - graphql_start) * 1000
        except Exception as e:
            metrics.error = f"GraphQL error: {str(e)}"
            metrics.graphql_request_ms = (time.time() - graphql_start) * 1000
        finally:
            await clt.aclose()

        # Release the account lock
        await instrumented_pool.unlock(account.username, queue)

    except Exception as e:
        metrics.error = str(e)

    metrics.total_ms = (time.time() - total_start) * 1000
    return metrics


async def scraper_process_worker(
    process_id: int,
    user_ids: List[str],
    redis_url: str,
    result_queue: mp.Queue,
    requests_per_process: int = 20
) -> None:
    """
    Worker function for a single scraper process.
    Uses instrumented Redis pool to track detailed metrics.
    """
    logger.info(f"[Process {process_id}] Starting scraper worker")

    stats = ProcessStats(process_id=process_id)
    stats.start_time = time.time()

    try:
        # Create instrumented Redis pool
        instrumented_pool = InstrumentedRedisPool(
            redis_url=redis_url,
            debug=False,
            raise_when_no_account=False
        )

        logger.info(f"[Process {process_id}] Connected to Redis with instrumented pool")

        # Make requests
        for i in range(requests_per_process):
            user_id = user_ids[i % len(user_ids)]

            # Fetch with detailed metrics
            metrics = await fetch_user_with_instrumented_pool(
                instrumented_pool,
                user_id,
                process_id
            )

            # Update stats
            stats.total_requests += 1
            stats.all_metrics.append(metrics)

            if metrics.success:
                stats.successful_requests += 1
                stats.redis_smembers_times.append(metrics.redis_smembers_ms)
                stats.redis_pipeline_times.append(metrics.redis_pipeline_ms)
                stats.redis_lua_eval_times.append(metrics.redis_lua_eval_ms)
                stats.redis_total_times.append(metrics.redis_total_ms)
                stats.graphql_times.append(metrics.graphql_request_ms)
                stats.total_times.append(metrics.total_ms)

                logger.info(
                    f"[Process {process_id}] Request {i+1}/{requests_per_process}: SUCCESS | "
                    f"Redis[SMEMBERS:{metrics.redis_smembers_ms:.1f}ms Pipeline:{metrics.redis_pipeline_ms:.1f}ms "
                    f"Lua:{metrics.redis_lua_eval_ms:.1f}ms Total:{metrics.redis_total_ms:.1f}ms] | "
                    f"GraphQL:{metrics.graphql_request_ms:.1f}ms | Total:{metrics.total_ms:.1f}ms"
                )
            else:
                stats.failed_requests += 1
                logger.warning(
                    f"[Process {process_id}] Request {i+1}/{requests_per_process}: "
                    f"FAILED | Error: {metrics.error}"
                )

            # Small delay between requests
            await asyncio.sleep(0.5)

    except Exception as e:
        logger.error(f"[Process {process_id}] Worker failed: {e}")
        import traceback
        traceback.print_exc()
    finally:
        stats.end_time = time.time()
        stats.duration = stats.end_time - stats.start_time

        # Send stats back to main process
        result_queue.put(asdict(stats))
        logger.info(f"[Process {process_id}] Completed.")


def run_scraper_process(
    process_id: int,
    user_ids: List[str],
    redis_url: str,
    result_queue: mp.Queue,
    requests_per_process: int
):
    """Entry point for multiprocessing"""
    import logging
    logging.basicConfig(
        level=logging.INFO,
        format=f'%(asctime)s - P{process_id} - %(levelname)s - %(message)s'
    )

    asyncio.run(scraper_process_worker(
        process_id,
        user_ids,
        redis_url,
        result_queue,
        requests_per_process
    ))


def calculate_percentiles(values: List[float]) -> Dict[str, float]:
    """Calculate percentile statistics"""
    if not values:
        return {"min": 0, "max": 0, "avg": 0, "p50": 0, "p95": 0, "p99": 0}

    sorted_vals = sorted(values)
    return {
        "min": sorted_vals[0],
        "max": sorted_vals[-1],
        "avg": sum(sorted_vals) / len(sorted_vals),
        "p50": sorted_vals[int(len(sorted_vals) * 0.50)],
        "p95": sorted_vals[int(len(sorted_vals) * 0.95)],
        "p99": sorted_vals[int(len(sorted_vals) * 0.99)] if len(sorted_vals) > 1 else sorted_vals[-1],
    }


def aggregate_statistics(all_stats: List[ProcessStats]) -> Dict[str, Any]:
    """Aggregate statistics from all processes"""

    # Collect all timing data
    all_redis_smembers = []
    all_redis_pipeline = []
    all_redis_lua_eval = []
    all_redis_total = []
    all_graphql = []
    all_total = []

    for stats in all_stats:
        all_redis_smembers.extend(stats.redis_smembers_times)
        all_redis_pipeline.extend(stats.redis_pipeline_times)
        all_redis_lua_eval.extend(stats.redis_lua_eval_times)
        all_redis_total.extend(stats.redis_total_times)
        all_graphql.extend(stats.graphql_times)
        all_total.extend(stats.total_times)

    total_requests = sum(s.total_requests for s in all_stats)
    successful_requests = sum(s.successful_requests for s in all_stats)
    failed_requests = sum(s.failed_requests for s in all_stats)

    start_time = min(s.start_time for s in all_stats)
    end_time = max(s.end_time for s in all_stats)
    total_duration = end_time - start_time

    return {
        "summary": {
            "total_processes": len(all_stats),
            "total_requests": total_requests,
            "successful_requests": successful_requests,
            "failed_requests": failed_requests,
            "success_rate": successful_requests / total_requests if total_requests > 0 else 0,
            "total_duration": total_duration,
            "requests_per_second": total_requests / total_duration if total_duration > 0 else 0,
        },
        "redis_operations": {
            "smembers": calculate_percentiles(all_redis_smembers),
            "pipeline": calculate_percentiles(all_redis_pipeline),
            "lua_eval": calculate_percentiles(all_redis_lua_eval),
            "total": calculate_percentiles(all_redis_total),
        },
        "graphql_requests": calculate_percentiles(all_graphql),
        "total_latency": calculate_percentiles(all_total),
        "per_process_stats": [
            {
                "process_id": s.process_id,
                "requests": s.total_requests,
                "successful": s.successful_requests,
                "failed": s.failed_requests,
                "redis_total_avg_ms": sum(s.redis_total_times) / len(s.redis_total_times) if s.redis_total_times else 0,
                "graphql_avg_ms": sum(s.graphql_times) / len(s.graphql_times) if s.graphql_times else 0,
                "total_avg_ms": sum(s.total_times) / len(s.total_times) if s.total_times else 0,
            }
            for s in all_stats
        ]
    }


def print_detailed_report(aggregated_stats: Dict[str, Any]):
    """Print comprehensive report with Redis operation breakdown"""

    print("\n" + "=" * 90)
    print("REALISTIC MULTIPROCESS LOAD TEST - DETAILED REDIS ANALYSIS")
    print("=" * 90)

    summary = aggregated_stats["summary"]
    print(f"\n{'OVERALL SUMMARY':^90}")
    print("-" * 90)
    print(f"  Total Processes:        {summary['total_processes']}")
    print(f"  Total Requests:         {summary['total_requests']}")
    print(f"  Successful:             {summary['successful_requests']} ({summary['success_rate']:.1%})")
    print(f"  Failed:                 {summary['failed_requests']}")
    print(f"  Total Duration:         {summary['total_duration']:.2f}s")
    print(f"  Throughput:             {summary['requests_per_second']:.2f} req/s")

    # Redis Operations Breakdown
    redis_ops = aggregated_stats["redis_operations"]
    print(f"\n{'REDIS OPERATIONS LATENCY BREAKDOWN':^90}")
    print("-" * 90)

    print(f"  {'Operation':<20} {'Min':>10} {'Avg':>10} {'P50':>10} {'P95':>10} {'P99':>10} {'Max':>10}")
    print("-" * 90)

    for op_name, op_stats in redis_ops.items():
        print(f"  {op_name.upper():<20} "
              f"{op_stats['min']:>9.2f}ms "
              f"{op_stats['avg']:>9.2f}ms "
              f"{op_stats['p50']:>9.2f}ms "
              f"{op_stats['p95']:>9.2f}ms "
              f"{op_stats['p99']:>9.2f}ms "
              f"{op_stats['max']:>9.2f}ms")

    # GraphQL Latency
    gql = aggregated_stats["graphql_requests"]
    print(f"\n{'GRAPHQL REQUEST LATENCY':^90}")
    print("-" * 90)
    print(f"  Min:    {gql['min']:8.2f}ms")
    print(f"  Avg:    {gql['avg']:8.2f}ms")
    print(f"  P50:    {gql['p50']:8.2f}ms")
    print(f"  P95:    {gql['p95']:8.2f}ms")
    print(f"  P99:    {gql['p99']:8.2f}ms")
    print(f"  Max:    {gql['max']:8.2f}ms")

    # Total Latency
    total = aggregated_stats["total_latency"]
    print(f"\n{'TOTAL END-TO-END LATENCY':^90}")
    print("-" * 90)
    print(f"  Min:    {total['min']:8.2f}ms")
    print(f"  Avg:    {total['avg']:8.2f}ms")
    print(f"  P50:    {total['p50']:8.2f}ms")
    print(f"  P95:    {total['p95']:8.2f}ms")
    print(f"  P99:    {total['p99']:8.2f}ms")
    print(f"  Max:    {total['max']:8.2f}ms")

    # Latency Breakdown
    print(f"\n{'LATENCY BREAKDOWN ANALYSIS':^90}")
    print("-" * 90)
    redis_pct = (redis_ops['total']['avg'] / total['avg'] * 100) if total['avg'] > 0 else 0
    graphql_pct = (gql['avg'] / total['avg'] * 100) if total['avg'] > 0 else 0
    print(f"  Redis Operations:       {redis_pct:6.2f}% of total latency ({redis_ops['total']['avg']:.2f}ms)")
    print(f"  GraphQL Request:        {graphql_pct:6.2f}% of total latency ({gql['avg']:.2f}ms)")

    # Redis sub-operation breakdown
    redis_total_avg = redis_ops['total']['avg']
    if redis_total_avg > 0:
        print("\n  Redis Operation Breakdown (% of Redis total):")
        print(f"    SMEMBERS:            {redis_ops['smembers']['avg'] / redis_total_avg * 100:6.2f}% ({redis_ops['smembers']['avg']:.2f}ms)")
        print(f"    Pipeline (HGETALL):  {redis_ops['pipeline']['avg'] / redis_total_avg * 100:6.2f}% ({redis_ops['pipeline']['avg']:.2f}ms)")
        print(f"    Lua Script:          {redis_ops['lua_eval']['avg'] / redis_total_avg * 100:6.2f}% ({redis_ops['lua_eval']['avg']:.2f}ms)")

    # Per-Process Stats
    print(f"\n{'PER-PROCESS STATISTICS':^90}")
    print("-" * 90)
    print(f"  {'PID':<6} {'Req':>6} {'Succ':>6} {'Fail':>6} {'Redis(ms)':>12} {'GraphQL(ms)':>12} {'Total(ms)':>12}")
    print("-" * 90)

    for proc in aggregated_stats["per_process_stats"]:
        print(f"  {proc['process_id']:<6} "
              f"{proc['requests']:>6} "
              f"{proc['successful']:>6} "
              f"{proc['failed']:>6} "
              f"{proc['redis_total_avg_ms']:>12.2f} "
              f"{proc['graphql_avg_ms']:>12.2f} "
              f"{proc['total_avg_ms']:>12.2f}")

    print("\n" + "=" * 90)


def main():
    """Main test orchestrator"""

    NUM_PROCESSES = 10
    REQUESTS_PER_PROCESS = 20

    USER_IDS = [
        '21', '51333', '15134663', '1193503663441842176', '1034810390',
        '2901249944', '1789054203987439616', '406989529', '430928457',
        '1334813570098294785', '1283789577753374721', '3013934917',
    ]

    redis_url = os.getenv("TWS_REDIS_URL", None)

    if not redis_url:
        print("ERROR: TWS_REDIS_URL environment variable not set")
        return

    print("=" * 90)
    print("STARTING REALISTIC MULTIPROCESS LOAD TEST WITH REDIS INSTRUMENTATION")
    print("=" * 90)
    print(f"  Scraper Instances:     {NUM_PROCESSES}")
    print(f"  Requests per Instance: {REQUESTS_PER_PROCESS}")
    print(f"  Total Requests:        {NUM_PROCESSES * REQUESTS_PER_PROCESS}")
    print(f"  Redis URL:             {redis_url}")
    print("=" * 90)
    print()

    result_queue = mp.Queue()
    processes = []

    print(f"Launching {NUM_PROCESSES} scraper processes...")

    for i in range(NUM_PROCESSES):
        p = mp.Process(
            target=run_scraper_process,
            args=(i, USER_IDS, redis_url, result_queue, REQUESTS_PER_PROCESS)
        )
        p.start()
        processes.append(p)
        print(f"  ✓ Process {i} started (PID: {p.pid})")

    print("\nAll processes launched. Waiting for completion...\n")

    for i, p in enumerate(processes):
        p.join()
        print(f"  ✓ Process {i} completed")

    print("\nCollecting results...")
    all_stats = []

    while not result_queue.empty():
        stats_dict = result_queue.get()
        stats = ProcessStats(**stats_dict)
        all_stats.append(stats)

    if not all_stats:
        print("ERROR: No stats collected")
        return

    aggregated_stats = aggregate_statistics(all_stats)
    print_detailed_report(aggregated_stats)

    # Save results
    output_file = f"multiprocess_redis_analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(output_file, "w") as f:
        json.dump(aggregated_stats, f, indent=2, default=str)

    print(f"\nDetailed results saved to: {output_file}")


if __name__ == "__main__":
    mp.set_start_method('spawn', force=True)

    try:
        main()
    except KeyboardInterrupt:
        print("\nTest interrupted")
    except Exception as e:
        print(f"\nTest failed: {e}")
        import traceback
        traceback.print_exc()
