"""
Detailed performance profiling to identify Redis vs SQLite bottlenecks.
"""

import asyncio
import os
import sys
import time

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from twscrape import API
from twscrape.logger import logger


async def profile_account_selection():
    """Profile account selection performance in detail"""
    logger.info("=" * 60)
    logger.info("ACCOUNT SELECTION PROFILING")
    logger.info("=" * 60)

    # Test Redis pool
    logger.info("\n1. Profiling Redis pool account selection...")
    redis_url = os.getenv("TWS_REDIS_URL", None)

    try:
        api_redis = API(
            pool=redis_url,
            debug=False,
            raise_when_no_account=False,
            use_random_proxy=False
        )

        # Profile multiple account selections with detailed timing
        for i in range(3):
            logger.info(f"\n--- Redis Selection {i+1} ---")

            # Time the entire get_for_queue process
            start_time = time.time()
            account = await api_redis.pool.get_for_queue("test")
            total_time = time.time() - start_time

            if account:
                logger.info(f"✓ Got @{account.username} in {total_time:.3f}s")
            else:
                logger.info(f"✗ No account available in {total_time:.3f}s")

    except Exception as e:
        logger.error(f"✗ Redis profiling failed: {e}")

    # Test SQLite pool
    logger.info("\n2. Profiling SQLite pool account selection...")
    sqlite_db = "accounts.db"

    try:
        api_sqlite = API(
            pool=sqlite_db,
            debug=False,
            raise_when_no_account=False,
            use_random_proxy=False
        )

        # Profile multiple account selections with detailed timing
        for i in range(3):
            logger.info(f"\n--- SQLite Selection {i+1} ---")

            # Time the entire get_for_queue process
            start_time = time.time()
            account = await api_sqlite.pool.get_for_queue("test")
            total_time = time.time() - start_time

            if account:
                logger.info(f"✓ Got @{account.username} in {total_time:.3f}s")
            else:
                logger.info(f"✗ No account available in {total_time:.3f}s")

    except Exception as e:
        logger.error(f"✗ SQLite profiling failed: {e}")


async def profile_redis_internals():
    """Profile Redis pool internal operations"""
    logger.info("\n" + "=" * 60)
    logger.info("REDIS INTERNAL OPERATIONS PROFILING")
    logger.info("=" * 60)

    redis_url = os.getenv("TWS_REDIS_URL", None)

    try:
        api_redis = API(
            pool=redis_url,
            debug=False,
            raise_when_no_account=False,
            use_random_proxy=False
        )

        pool = api_redis.pool

        # Profile getting active users
        logger.info("\n1. Profiling active users retrieval...")
        start_time = time.time()
        active_users = await pool._r.smembers(pool._k_accounts_active)
        time1 = time.time() - start_time
        logger.info(f"✓ Got {len(active_users)} active users in {time1:.3f}s")

        # Profile getting a single document
        if active_users:
            logger.info("\n2. Profiling single document retrieval...")
            first_user = list(active_users)[0]
            start_time = time.time()
            doc = await pool._get_doc(first_user)
            time2 = time.time() - start_time
            logger.info(f"✓ Got document for @{first_user} in {time2:.3f}s")

            # Profile account conversion
            if doc:
                logger.info("\n3. Profiling account conversion...")
                start_time = time.time()
                account = pool._redis_doc_to_acc(doc)
                time3 = time.time() - start_time
                logger.info(f"✓ Converted to Account object in {time3:.3f}s")

        # Profile batch operations
        logger.info("\n4. Profiling batch document retrieval...")
        sample_users = list(active_users)[:10]  # First 10 users
        start_time = time.time()
        batch_docs = await asyncio.gather(
            *[pool._get_doc(u) for u in sample_users],
            return_exceptions=True
        )
        time4 = time.time() - start_time
        logger.info(f"✓ Got {len(sample_users)} documents in batch in {time4:.3f}s")
        logger.info(f"  Average per document: {time4/len(sample_users):.3f}s")

        # Profile lock checking
        logger.info("\n5. Profiling lock checking...")
        if doc:
            start_time = time.time()
            locks_epoch_str = doc.get("locks_epoch", "{}")
            import json
            locks_epoch = json.loads(locks_epoch_str)
            time5 = time.time() - start_time
            logger.info(f"✓ Parsed locks_epoch in {time5:.3f}s")

    except Exception as e:
        logger.error(f"✗ Redis internal profiling failed: {e}")


async def profile_concurrent_account_selection():
    """Profile concurrent account selection to see contention"""
    logger.info("\n" + "=" * 60)
    logger.info("CONCURRENT ACCOUNT SELECTION PROFILING")
    logger.info("=" * 60)

    redis_url = os.getenv("TWS_REDIS_URL", None)

    try:
        api_redis = API(
            pool=redis_url,
            debug=False,
            raise_when_no_account=False,
            use_random_proxy=False
        )

        async def get_account_with_timing(queue_name: str, request_id: int):
            start_time = time.time()
            account = await api_redis.pool.get_for_queue(queue_name)
            total_time = time.time() - start_time

            if account:
                logger.info(f"Request {request_id}: Got @{account.username} in {total_time:.3f}s")
            else:
                logger.info(f"Request {request_id}: No account in {total_time:.3f}s")

            return account, total_time

        # Test concurrent account selection
        logger.info("\nTesting 5 concurrent account selections...")
        start_time = time.time()
        tasks = [get_account_with_timing("test", i) for i in range(5)]
        results = await asyncio.gather(*tasks)
        total_time = time.time() - start_time

        successful = sum(1 for account, _ in results if account is not None)
        logger.info(f"\n✓ {successful}/5 successful in {total_time:.3f}s total")

        # Show individual timings
        individual_times = [time for _, time in results]
        logger.info(f"Individual times: {[f'{t:.3f}s' for t in individual_times]}")
        logger.info(f"Average time: {sum(individual_times)/len(individual_times):.3f}s")

    except Exception as e:
        logger.error(f"✗ Concurrent profiling failed: {e}")


async def main():
    """Main profiling function"""
    await profile_account_selection()
    await profile_redis_internals()
    await profile_concurrent_account_selection()

    logger.info("\n" + "=" * 60)
    logger.info("PROFILING COMPLETED")
    logger.info("=" * 60)


if __name__ == "__main__":
    # Set up logging
    import logging
    logging.basicConfig(level=logging.INFO)

    # Run the profiling with overall timeout
    try:
        asyncio.run(asyncio.wait_for(main(), timeout=120.0))  # 2 minute overall timeout
    except asyncio.TimeoutError:
        logger.error("Overall profiling timeout after 2 minutes")
    except KeyboardInterrupt:
        logger.info("Profiling interrupted by user")
    except Exception as e:
        logger.error(f"Profiling failed with error: {e}")
