"""
Simple single-account test to debug 400 errors.
"""
import asyncio
import json
import os
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from twscrape.redis_accounts_pool_v2 import RedisAccountsPoolV2
from twscrape.api import GQL_URL, OP_UserByRestId, GQL_FEATURES
from twscrape.utils import encode_params
from twscrape.queue_client import QueueClient


async def test_single_request():
    """Test a single request with detailed logging using QueueClient"""
    redis_url = os.getenv("TWS_REDIS_URL") or os.getenv("REDIS_URL")

    if not redis_url:
        print("ERROR: TWS_REDIS_URL or REDIS_URL environment variable not set")
        return

    print("=" * 80)
    print("SINGLE ACCOUNT DEBUG TEST (Using QueueClient)")
    print("=" * 80)
    print(f"Redis URL: {redis_url}")
    print()

    # Create pool
    pool = RedisAccountsPoolV2(db_file=redis_url, raise_when_no_account=False)

    # Initialize queue
    await pool.init_queue("UserByRestId")
    print("✓ Queue initialized")

    # Prepare request params (use same features as API.user_by_id_raw)
    op = OP_UserByRestId
    user_id = "44196397"  # elonmusk
    kv = {"userId": str(user_id), "withSafetyModeUserFields": True}
    ft = {
        **GQL_FEATURES,
        "hidden_profile_likes_enabled": True,
        "highlights_tweets_tab_ui_enabled": True,
        "creator_subscriptions_tweet_preview_api_enabled": True,
        "hidden_profile_subscriptions_enabled": True,
        "responsive_web_twitter_article_notes_tab_enabled": False,
        "subscriptions_feature_can_gift_premium": False,
        "profile_label_improvements_pcf_label_in_post_enabled": False,
    }
    params = {"variables": kv, "features": ft}

    print(f"Making request to: {GQL_URL}/{op}")
    print(f"User ID: {user_id}")
    print()

    try:
        # Use QueueClient - it handles everything: account management, headers, retries, etc.
        async with QueueClient(pool, "UserByRestId", debug=True) as client:
            rep = await client.get(f"{GQL_URL}/{op}", params=encode_params(params))

            if not rep:
                print("✗ FAILED: No response from QueueClient")
                return

            print(f"Response status: {rep.status_code}")
            print("Response headers:")
            for key, value in rep.headers.items():
                if key.lower().startswith("x-rate-limit"):
                    print(f"  - {key}: {value}")
            print()

            if rep.status_code == 200:
                print("✓ SUCCESS!")
                data = rep.json()
                if "data" in data and "user" in data["data"]:
                    user = data["data"]["user"]["result"]
                    print(f"  - User: @{user.get('legacy', {}).get('screen_name', 'unknown')}")
                    print(f"  - Name: {user.get('legacy', {}).get('name', 'unknown')}")
                else:
                    print("  - Response has data but no user info")
                    print(f"  - Keys: {list(data.keys())}")
            else:
                print(f"✗ FAILED with status {rep.status_code}")
                try:
                    error_data = rep.json()
                    print("Error response:")
                    print(json.dumps(error_data, indent=2))
                except:
                    print(f"Response text: {rep.text[:500]}")

    except Exception as e:
        print(f"✗ EXCEPTION: {type(e).__name__}: {e}")
        import traceback
        traceback.print_exc()

    print("\n" + "=" * 80)


if __name__ == "__main__":
    try:
        asyncio.run(test_single_request())
    except KeyboardInterrupt:
        print("\nTest interrupted")
    except Exception as e:
        print(f"\nTest failed: {e}")
        import traceback
        traceback.print_exc()
