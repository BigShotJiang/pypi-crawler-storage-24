"""
Minimal Redis pool test to debug the hanging issue.
"""

import asyncio
import os
import sys
import time

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from twscrape import API
from twscrape.logger import logger


async def test_minimal_redis():
    """Minimal test to identify where the hang occurs"""
    logger.info("=" * 60)
    logger.info("MINIMAL REDIS POOL TEST")
    logger.info("=" * 60)

    redis_url = os.getenv("TWS_REDIS_URL", None)
    logger.info(f"Redis URL: {redis_url}")

    try:
        # Step 1: Create API instance
        logger.info("\n1. Creating API instance...")
        start_time = time.time()
        api = API(
            pool=redis_url,
            debug=False,
            raise_when_no_account=False,
            use_random_proxy=False
        )
        logger.info(f"✓ API created in {time.time() - start_time:.2f}s")

        # Step 2: Test pool stats (should be fast)
        logger.info("\n2. Testing pool stats...")
        start_time = time.time()
        stats = await asyncio.wait_for(api.pool.stats(), timeout=5.0)
        logger.info(f"✓ Pool stats: {stats} (took {time.time() - start_time:.2f}s)")

        # Step 3: Test getting a single account by username
        logger.info("\n3. Testing single account retrieval...")
        start_time = time.time()

        # Get a username from the active set
        active_users = await asyncio.wait_for(api.pool._r.smembers(api.pool._k_accounts_active), timeout=5.0)
        if active_users:
            first_username = list(active_users)[0]
            logger.info(f"Testing with username: {first_username}")

            account = await asyncio.wait_for(api.pool.get_account(first_username), timeout=5.0)
            if account:
                logger.info(f"✓ Retrieved account: @{account.username} (took {time.time() - start_time:.2f}s)")
            else:
                logger.warning("⚠ Account retrieval returned None")
        else:
            logger.warning("⚠ No active users found")

        # Step 4: Test a simple API request
        logger.info("\n4. Testing simple API request...")
        start_time = time.time()

        try:
            user = await asyncio.wait_for(api.user_by_id(21), timeout=30.0)  # @twitter
            if user:
                logger.info(f"✓ API request successful: @{user.username} (took {time.time() - start_time:.2f}s)")
            else:
                logger.warning("⚠ API request returned None")
        except Exception as e:
            logger.error(f"✗ API request failed: {e}")

        logger.info("\n" + "=" * 60)
        logger.info("MINIMAL TEST COMPLETED SUCCESSFULLY!")
        logger.info("=" * 60)

    except asyncio.TimeoutError as e:
        logger.error(f"✗ Test timeout: {e}")
    except Exception as e:
        logger.error(f"✗ Test failed: {e}")


if __name__ == "__main__":
    # Set up logging
    import logging
    logging.basicConfig(level=logging.INFO)

    # Run the test with overall timeout
    try:
        asyncio.run(asyncio.wait_for(test_minimal_redis(), timeout=60.0))  # 1 minute overall timeout
    except asyncio.TimeoutError:
        logger.error("Overall test timeout after 1 minute")
    except KeyboardInterrupt:
        logger.info("Test interrupted by user")
    except Exception as e:
        logger.error(f"Test failed with error: {e}")
