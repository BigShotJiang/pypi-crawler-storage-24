"""
Simple test runner script to execute Redis pool tests.
Usage: python run_redis_tests.py
"""

import asyncio
import os
import sys
import subprocess
from pathlib import Path

def check_redis_connection():
    """Check if Redis is accessible"""
    try:
        import redis
        r = redis.Redis.from_url(os.getenv("TWS_REDIS_URL", None))
        r.ping()
        print("✓ Redis connection successful")
        return True
    except Exception as e:
        print(f"✗ Redis connection failed: {e}")
        print("Make sure Redis is running and accessible")
        return False

def check_dependencies():
    """Check if required dependencies are installed"""
    try:
        import twscrape
        print("✓ twscrape module available")
        return True
    except ImportError as e:
        print(f"✗ twscrape module not found: {e}")
        return False

async def run_test(test_file: str, description: str):
    """Run a specific test file"""
    print(f"\n{'='*60}")
    print(f"Running: {description}")
    print(f"File: {test_file}")
    print(f"{'='*60}")

    try:
        # Change to the directory containing these tests
        tests_dir = Path(__file__).parent
        os.chdir(tests_dir)

        # Run the test
        result = subprocess.run([sys.executable, test_file],
                              capture_output=True, text=True, timeout=300)

        if result.returncode == 0:
            print(f"✓ {description} completed successfully")
            if result.stdout:
                print("Output:")
                print(result.stdout)
        else:
            print(f"✗ {description} failed with return code {result.returncode}")
            if result.stderr:
                print("Error output:")
                print(result.stderr)
            if result.stdout:
                print("Standard output:")
                print(result.stdout)

    except subprocess.TimeoutExpired:
        print(f"✗ {description} timed out after 5 minutes")
    except Exception as e:
        print(f"✗ Error running {description}: {e}")

def main():
    """Main test runner"""
    print("Redis Pool Test Runner")
    print("=" * 60)

    # Check prerequisites
    if not check_dependencies():
        print("Please install required dependencies first")
        return

    if not check_redis_connection():
        print("Please start Redis and ensure it's accessible")
        return

    # Check environment variables
    redis_url = os.getenv("TWS_REDIS_URL", None)
    print(f"Using Redis URL: {redis_url}")

    threshold = os.getenv("TWS_RATE_LIMIT_THRESHOLD", "0.9")
    print(f"Rate limit threshold: {threshold}")

    # Run tests
    tests = [
        ("test_minimal_redis.py", "Minimal Redis Connectivity and Single Request Test"),
        ("test_redis_pool_lru.py", "LRU Selection Behavior Test"),
        ("test_redis_pool_concurrent.py", "Concurrent Requests Test"),
        ("test_performance_comparison.py", "Performance Comparison (Redis vs SQLite) Test"),
        ("test_redis_profiling.py", "Redis Profiling (batch timings) Test"),
        ("test_stats_increment.py", "Stats Increment After Successful Request Test"),
    ]

    for test_file, description in tests:
        asyncio.run(run_test(test_file, description))

    print(f"\n{'='*60}")
    print("All tests completed!")
    print("Check the generated JSON result files for detailed output.")
    print(f"{'='*60}")

if __name__ == "__main__":
    main()
