"""
Performance comparison test between SQLite and Redis account pools.
"""

import asyncio
import os
import sys
import time

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from twscrape import API
from twscrape.logger import logger


async def test_account_selection_performance():
    """Test how fast account selection is in both pools"""
    logger.info("=" * 60)
    logger.info("ACCOUNT SELECTION PERFORMANCE TEST")
    logger.info("=" * 60)

    # Test Redis pool
    logger.info("\n1. Testing Redis pool account selection...")
    redis_url = os.getenv("TWS_REDIS_URL", None)

    try:
        api_redis = API(
            pool=redis_url,
            debug=False,
            raise_when_no_account=False,
            use_random_proxy=False
        )

        # Test multiple account selections
        start_time = time.time()
        for i in range(5):
            account = await asyncio.wait_for(api_redis.pool.get_for_queue("test"), timeout=10.0)
            if account:
                logger.info(f"  Selection {i+1}: Got @{account.username}")
            else:
                logger.warning(f"  Selection {i+1}: No account available")

        redis_time = time.time() - start_time
        logger.info(f"✓ Redis pool: 5 selections took {redis_time:.2f}s")

    except Exception as e:
        logger.error(f"✗ Redis pool test failed: {e}")
        redis_time = None

    # Test SQLite pool
    logger.info("\n2. Testing SQLite pool account selection...")
    sqlite_db = "accounts.db"

    try:
        api_sqlite = API(
            pool=sqlite_db,
            debug=False,
            raise_when_no_account=False,
            use_random_proxy=False
        )

        # Test multiple account selections
        start_time = time.time()
        for i in range(5):
            account = await asyncio.wait_for(api_sqlite.pool.get_for_queue("test"), timeout=10.0)
            if account:
                logger.info(f"  Selection {i+1}: Got @{account.username}")
            else:
                logger.warning(f"  Selection {i+1}: No account available")

        sqlite_time = time.time() - start_time
        logger.info(f"✓ SQLite pool: 5 selections took {sqlite_time:.2f}s")

    except Exception as e:
        logger.error(f"✗ SQLite pool test failed: {e}")
        sqlite_time = None

    # Compare results
    logger.info("\n" + "=" * 60)
    logger.info("PERFORMANCE COMPARISON")
    logger.info("=" * 60)

    if redis_time and sqlite_time:
        if redis_time > sqlite_time:
            ratio = redis_time / sqlite_time
            logger.info(f"Redis is {ratio:.1f}x slower than SQLite")
        else:
            ratio = sqlite_time / redis_time
            logger.info(f"Redis is {ratio:.1f}x faster than SQLite")
    else:
        logger.warning("Could not compare - one or both tests failed")


async def test_simple_api_request():
    """Test a simple API request with both pools"""
    logger.info("\n" + "=" * 60)
    logger.info("SIMPLE API REQUEST TEST")
    logger.info("=" * 60)

    # Test Redis pool
    logger.info("\n1. Testing Redis pool API request...")
    redis_url = os.getenv("TWS_REDIS_URL", None)

    try:
        api_redis = API(
            pool=redis_url,
            debug=False,
            raise_when_no_account=False,
            use_random_proxy=False
        )
        start_time = time.time()

        user = await asyncio.wait_for(api_redis.user_by_id(21), timeout=30.0)
        redis_time = time.time() - start_time

        if user:
            logger.info(f"✓ Redis: Got @{user.username} in {redis_time:.2f}s")
        else:
            logger.warning("⚠ Redis: User not found")

    except Exception as e:
        logger.error(f"✗ Redis API request failed: {e}")
        redis_time = None

    # Test SQLite pool
    logger.info("\n2. Testing SQLite pool API request...")
    sqlite_db = "accounts.db"

    try:
        api_sqlite = API(
            pool=sqlite_db,
            debug=False,
            raise_when_no_account=False,
            use_random_proxy=False
        )
        start_time = time.time()

        user = await asyncio.wait_for(api_sqlite.user_by_id(21), timeout=30.0)
        sqlite_time = time.time() - start_time

        if user:
            logger.info(f"✓ SQLite: Got @{user.username} in {sqlite_time:.2f}s")
        else:
            logger.warning("⚠ SQLite: User not found")

    except Exception as e:
        logger.error(f"✗ SQLite API request failed: {e}")
        sqlite_time = None

    # Compare results
    logger.info("\n" + "=" * 60)
    logger.info("API REQUEST COMPARISON")
    logger.info("=" * 60)

    if redis_time and sqlite_time:
        if redis_time > sqlite_time:
            ratio = redis_time / sqlite_time
            logger.info(f"Redis API request is {ratio:.1f}x slower than SQLite")
        else:
            ratio = sqlite_time / redis_time
            logger.info(f"Redis API request is {ratio:.1f}x faster than SQLite")
    else:
        logger.warning("Could not compare API requests - one or both tests failed")


async def test_concurrent_user_fetching():
    """Test concurrent user fetching performance"""
    logger.info("\n" + "=" * 60)
    logger.info("CONCURRENT USER FETCHING TEST")
    logger.info("=" * 60)

    # Test user IDs (mix of known active accounts)
    redis_user_ids = ['1008649805093064704', '100944168', '1009984504247676928', '1014090405628010497', '1017925596414767104', '1019575235748745221', '1019701567103078400', '1023756347387662338', '1035201811513139200', '1039458395265282048', '1040124936843550720', '1042043344086609922', '1043050627381653505', '104995410', '1051676602646462464', '1052820197361348608', '1061807865067782145', '1064633043896414213', '1065817584396713984', '1069641650', '107096758', '1072838767961092096', '1073671233596784640', '107528682', '1077335540', '1080380903841394689', '1081429498246111232', '1082048983797657600', '108260481', '1084494155403968512']

    sqlite_user_ids = ['1085638344565051393', '1087623464', '1088354609247051776', '1098881129057112064', '1100247761000194048', '1103349960991481857', '1105590911503880192', '1108008358672515072', '1112647722933248000', '1116499887997243393', '111902927', '1133010589087723527', '1134047585088544768', '1134052146800922625', '1139572882776965120', '1140326419', '1141656975815643137', '1141720339', '1143975809813811202', '1148875269320650758', '1149641989949992960', '1150321171784765440', '1153896252280623107', '1153985713836384256', '1154645471195017216', '1154693269', '1162196651546513411', '1163418288262717442']

    logger.info(f"Testing with {len(sqlite_user_ids)} user IDs")
    logger.info(f"Testing with {len(redis_user_ids)} user IDs")

    # Test SQLite pool (use its own ID set)
    logger.info("\n2. Testing SQLite pool concurrent fetching...")
    sqlite_db = "accounts.db"
    sqlite_results = await test_concurrent_with_pool(sqlite_db, sqlite_user_ids, "SQLite")

    # Test Redis pool (use different ID set)
    logger.info("\n1. Testing Redis pool concurrent fetching...")
    redis_url = os.getenv("TWS_REDIS_URL", None)
    redis_results = await test_concurrent_with_pool(redis_url, redis_user_ids, "Redis")

    # Compare results
    logger.info("\n" + "=" * 60)
    logger.info("CONCURRENT FETCHING COMPARISON")
    logger.info("=" * 60)

    if redis_results and sqlite_results:
        logger.info(f"Redis: {redis_results['successful']}/{redis_results['total']} successful in {redis_results['total_time']:.2f}s (IDs: {len(redis_user_ids)})")
        logger.info(f"SQLite: {sqlite_results['successful']}/{sqlite_results['total']} successful in {sqlite_results['total_time']:.2f}s (IDs: {len(sqlite_user_ids)})")

        if redis_results['total_time'] > sqlite_results['total_time']:
            ratio = redis_results['total_time'] / sqlite_results['total_time']
            logger.info(f"Redis concurrent fetching is {ratio:.1f}x slower than SQLite")
        else:
            ratio = sqlite_results['total_time'] / redis_results['total_time']
            logger.info(f"Redis concurrent fetching is {ratio:.1f}x faster than SQLite")

        # Compare success rates
        redis_success_rate = redis_results['successful'] / redis_results['total']
        sqlite_success_rate = sqlite_results['successful'] / sqlite_results['total']
        logger.info(f"Redis success rate: {redis_success_rate:.1%}")
        logger.info(f"SQLite success rate: {sqlite_success_rate:.1%}")

        # Compare requests per second
        redis_rps = redis_results['total'] / redis_results['total_time']
        sqlite_rps = sqlite_results['total'] / sqlite_results['total_time']
        logger.info(f"Redis: {redis_rps:.1f} requests/second")
        logger.info(f"SQLite: {sqlite_rps:.1f} requests/second")
    else:
        logger.warning("Could not compare concurrent fetching - one or both tests failed")


async def test_concurrent_with_pool(pool_url: str, user_ids: list, pool_name: str):
    """Test concurrent fetching with a specific pool"""
    try:
        api = API(
            pool=pool_url,
            debug=False,
            raise_when_no_account=False,
            use_random_proxy=False
        )

        # Create semaphore to limit concurrent requests
        max_concurrent = 10
        semaphore = asyncio.Semaphore(max_concurrent)

        async def fetch_user_safe(user_id: int):
            async with semaphore:
                try:
                    user = await asyncio.wait_for(api.user_by_id(user_id), timeout=30.0)
                    return {
                        "user_id": user_id,
                        "success": user is not None,
                        "username": user.username if user else None,
                        "error": None
                    }
                except Exception as e:
                    return {
                        "user_id": user_id,
                        "success": False,
                        "username": None,
                        "error": str(e)
                    }

        # Execute all requests concurrently
        start_time = time.time()
        tasks = [fetch_user_safe(user_id) for user_id in user_ids]
        results = await asyncio.wait_for(
            asyncio.gather(*tasks, return_exceptions=True),
            timeout=120.0  # 2 minute overall timeout
        )
        total_time = time.time() - start_time

        # Process results
        successful = 0
        failed = 0
        errors = []

        for result in results:
            if isinstance(result, Exception):
                failed += 1
                errors.append(str(result))
            elif result["success"]:
                successful += 1
            else:
                failed += 1
                errors.append(result["error"])

        logger.info(f"✓ {pool_name}: {successful}/{len(user_ids)} successful in {total_time:.2f}s")

        # Show sample errors
        if errors:
            logger.info(f"  Sample errors: {errors[:3]}")

        return {
            "total": len(user_ids),
            "successful": successful,
            "failed": failed,
            "total_time": total_time,
            "errors": errors[:5]  # First 5 errors
        }

    except Exception as e:
        logger.error(f"✗ {pool_name} concurrent test failed: {e}")
        return None


async def main():
    """Main test function"""
    await test_account_selection_performance()
    await test_simple_api_request()
    await test_concurrent_user_fetching()

    logger.info("\n" + "=" * 60)
    logger.info("PERFORMANCE TEST COMPLETED")
    logger.info("=" * 60)


if __name__ == "__main__":
    # Set up logging
    import logging
    logging.basicConfig(level=logging.INFO)

    # Run the test with overall timeout
    try:
        asyncio.run(asyncio.wait_for(main(), timeout=120.0))  # 2 minute overall timeout
    except asyncio.TimeoutError:
        logger.error("Overall test timeout after 2 minutes")
    except KeyboardInterrupt:
        logger.info("Test interrupted by user")
    except Exception as e:
        logger.error(f"Test failed with error: {e}")
