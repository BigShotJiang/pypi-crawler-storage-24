"""
Simple Redis pool concurrent test with proper error handling and timeouts.
"""

import asyncio
import os
import sys
import time
import json
from typing import Dict, List, Any

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from twscrape import API
from twscrape.logger import logger


async def fetch_user_tweets_safe(api: API, user_id: str, timeout: float = 30.0) -> Dict[str, Any]:
    """Safely fetch tweets for a single user with timeout"""
    start_time = time.time()

    try:
        # Get user info first with timeout
        user = await asyncio.wait_for(api.user_by_id(int(user_id)), timeout=timeout)

        if not user:
            return {
                "user_id": user_id,
                "error": "User not found",
                "duration": time.time() - start_time
            }

        logger.info(f"✓ Fetched user @{user.username} (ID: {user_id})")

        # Fetch a few tweets with timeout
        tweets = []
        tweet_count = 0
        max_tweets = 3  # Limit to avoid long waits

        async for tweet in api.user_tweets(int(user_id), limit=max_tweets):
            tweets.append({
                "id": tweet.id,
                "text": tweet.text[:50] + "..." if len(tweet.text) > 50 else tweet.text,
                "created_at": tweet.created_at.isoformat() if tweet.created_at else None
            })
            tweet_count += 1

            # Break early if we have enough tweets
            if tweet_count >= max_tweets:
                break

        duration = time.time() - start_time

        return {
            "user_id": user_id,
            "username": user.username,
            "tweets": tweets,
            "tweet_count": len(tweets),
            "duration": duration,
            "success": True
        }

    except asyncio.TimeoutError:
        duration = time.time() - start_time
        return {
            "user_id": user_id,
            "error": "Timeout",
            "duration": duration,
            "success": False
        }
    except Exception as e:
        duration = time.time() - start_time
        return {
            "user_id": user_id,
            "error": str(e),
            "duration": duration,
            "success": False
        }


async def test_concurrent_requests_safe(user_ids: List[str], max_concurrent: int = 5) -> Dict[str, Any]:
    """Test concurrent requests with safety measures"""

    redis_url = os.getenv("TWS_REDIS_URL", None)
    logger.info(f"Using Redis URL: {redis_url}")

    # Create API with Redis pool
    api = API(
        pool=redis_url,
        debug=False,
        raise_when_no_account=False,
        use_random_proxy=False
    )

    logger.info(f"Starting concurrent test with {len(user_ids)} user IDs, max {max_concurrent} concurrent")

    # Create semaphore to limit concurrent requests
    semaphore = asyncio.Semaphore(max_concurrent)

    async def fetch_with_semaphore(user_id: str):
        async with semaphore:
            return await fetch_user_tweets_safe(api, user_id)

    # Execute all requests concurrently with overall timeout
    start_time = time.time()

    try:
        tasks = [fetch_with_semaphore(user_id) for user_id in user_ids]
        results = await asyncio.wait_for(
            asyncio.gather(*tasks, return_exceptions=True),
            timeout=120.0  # 2 minute overall timeout
        )
    except asyncio.TimeoutError:
        logger.error("Overall test timeout after 2 minutes")
        return {"error": "Overall timeout"}

    total_time = time.time() - start_time

    # Process results
    successful_results = []
    failed_results = []

    for i, result in enumerate(results):
        if isinstance(result, Exception):
            failed_results.append({
                "user_id": user_ids[i],
                "error": str(result)
            })
        elif result.get("success", False):
            successful_results.append(result)
        else:
            failed_results.append(result)

    # Get pool statistics
    try:
        pool_stats = await asyncio.wait_for(api.pool.stats(), timeout=10.0)
        accounts_info = await asyncio.wait_for(api.pool.accounts_info(), timeout=10.0)
    except Exception as e:
        logger.error(f"Failed to get pool stats: {e}")
        pool_stats = {}
        accounts_info = []

    # Compile results
    test_results = {
        "test_summary": {
            "total_users": len(user_ids),
            "successful_requests": len(successful_results),
            "failed_requests": len(failed_results),
            "total_time": total_time,
            "requests_per_second": len(user_ids) / total_time if total_time > 0 else 0
        },
        "pool_stats": pool_stats,
        "accounts_count": len(accounts_info),
        "sample_results": successful_results[:3],  # First 3 successful results
        "errors": failed_results[:5]  # First 5 errors
    }

    return test_results


async def main():
    """Main test function"""
    logger.info("=" * 60)
    logger.info("REDIS POOL CONCURRENT TEST")
    logger.info("=" * 60)

    # Test user IDs (subset for faster testing)
    user_ids = [
        '21', '51333', '15134663', '21', '51333',  # Repeat to test rotation
        '1193503663441842176', '1034810390', '2901249944', '1789054203987439616', '406989529',
        '430928457', '1334813570098294785', '1283789577753374721', '3013934917', '1699783689943797760',
        '2467057448', '2960234686', '35865630', '953559767242498049', '1469774395321294848'
    ]

    logger.info(f"Testing with {len(user_ids)} user IDs")

    # Run concurrent test
    logger.info("\nRunning concurrent requests test...")
    results = await test_concurrent_requests_safe(user_ids, max_concurrent=3)

    if "error" in results:
        logger.error(f"Test failed: {results['error']}")
        return

    # Print summary
    logger.info("\n" + "=" * 60)
    logger.info("TEST SUMMARY")
    logger.info("=" * 60)

    summary = results["test_summary"]
    logger.info(f"Total users tested: {summary['total_users']}")
    logger.info(f"Successful requests: {summary['successful_requests']}")
    logger.info(f"Failed requests: {summary['failed_requests']}")
    logger.info(f"Total time: {summary['total_time']:.2f}s")
    logger.info(f"Requests per second: {summary['requests_per_second']:.2f}")

    logger.info(f"Pool stats: {results['pool_stats']}")
    logger.info(f"Accounts in pool: {results['accounts_count']}")

    # Show sample results
    if results["sample_results"]:
        logger.info("\nSample successful results:")
        for result in results["sample_results"]:
            logger.info(f"  @{result['username']}: {result['tweet_count']} tweets in {result['duration']:.2f}s")

    # Show errors
    if results["errors"]:
        logger.info("\nSample errors:")
        for error in results["errors"]:
            logger.info(f"  User {error['user_id']}: {error.get('error', 'Unknown error')}")

    # Save results
    results_file = "redis_concurrent_test_results.json"
    with open(results_file, "w") as f:
        json.dump(results, f, indent=2, default=str)

    logger.info(f"\nDetailed results saved to: {results_file}")
    logger.info("\nTest completed!")


if __name__ == "__main__":
    # Set up logging
    import logging
    logging.basicConfig(level=logging.INFO)

    # Run the test with overall timeout
    try:
        asyncio.run(asyncio.wait_for(main(), timeout=300.0))  # 5 minute overall timeout
    except asyncio.TimeoutError:
        logger.error("Overall test timeout after 5 minutes")
    except KeyboardInterrupt:
        logger.info("Test interrupted by user")
    except Exception as e:
        logger.error(f"Test failed with error: {e}")
