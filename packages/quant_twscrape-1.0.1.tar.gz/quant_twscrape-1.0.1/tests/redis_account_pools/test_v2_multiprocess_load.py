"""
Simple multiprocess load test for Redis Pool V2.
Tests the queue-based architecture under realistic load.
"""

import asyncio
import json
import multiprocessing as mp
import os
import sys
import time
from dataclasses import dataclass, asdict, field
from typing import List, Dict, Any
from datetime import datetime

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from twscrape.redis_accounts_pool_v2 import RedisAccountsPoolV2
from twscrape.logger import logger


@dataclass
class RequestMetrics:
    """Metrics for a single request"""
    process_id: int
    request_num: int
    success: bool
    error: str | None = None

    # Timing breakdown
    get_account_ms: float = 0.0
    graphql_ms: float = 0.0
    total_ms: float = 0.0

    # Queue info
    queue_name: str = ""
    username: str = ""


@dataclass
class ProcessStats:
    """Statistics for a single scraper process"""
    process_id: int
    total_requests: int = 0
    successful_requests: int = 0
    failed_requests: int = 0

    # Timing lists
    get_account_times: List[float] = field(default_factory=list)
    graphql_times: List[float] = field(default_factory=list)
    total_times: List[float] = field(default_factory=list)

    # All metrics
    all_metrics: List[RequestMetrics] = field(default_factory=list)

    start_time: float = 0.0
    end_time: float = 0.0
    duration: float = 0.0


async def fetch_user_v2(
    pool: RedisAccountsPoolV2,
    user_id: str,
    process_id: int,
    request_num: int
) -> RequestMetrics:
    """Fetch user info using Redis Pool V2 with QueueClient"""
    from twscrape.api import GQL_URL, OP_UserByRestId, GQL_FEATURES
    from twscrape.utils import encode_params
    from twscrape.queue_client import QueueClient

    total_start = time.time()
    metrics = RequestMetrics(
        process_id=process_id,
        request_num=request_num,
        success=False,
        queue_name="UserByRestId"
    )

    try:
        # Prepare request params (use same features as API.user_by_id_raw)
        op = OP_UserByRestId
        kv = {"userId": str(user_id), "withSafetyModeUserFields": True}
        ft = {
            **GQL_FEATURES,
            "hidden_profile_likes_enabled": True,
            "highlights_tweets_tab_ui_enabled": True,
            "creator_subscriptions_tweet_preview_api_enabled": True,
            "hidden_profile_subscriptions_enabled": True,
            "responsive_web_twitter_article_notes_tab_enabled": False,
            "subscriptions_feature_can_gift_premium": False,
            "profile_label_improvements_pcf_label_in_post_enabled": False,
        }
        params = {"variables": kv, "features": ft}

        # Track account acquisition time
        account_start = time.time()

        # Use QueueClient - handles account management, headers, rate limits, retries automatically
        async with QueueClient(pool, "UserByRestId", debug=False) as client:
            metrics.get_account_ms = (time.time() - account_start) * 1000

            # Get username from context
            if client.ctx and client.ctx.acc:
                metrics.username = client.ctx.acc.username

            # Make GraphQL request
            graphql_start = time.time()
            rep = await client.get(f"{GQL_URL}/{op}", params=encode_params(params))
            metrics.graphql_ms = (time.time() - graphql_start) * 1000

            if not rep:
                metrics.error = "No response from QueueClient"
            elif rep.status_code == 200:
                metrics.success = True
            else:
                metrics.error = f"HTTP {rep.status_code}"

    except Exception as e:
        metrics.error = f"Error: {str(e)}"

    metrics.total_ms = (time.time() - total_start) * 1000
    return metrics


async def scraper_process_worker(
    process_id: int,
    user_ids: List[str],
    redis_url: str,
    result_queue: mp.Queue,
    requests_per_process: int = 20
):
    """Worker function for a single scraper process"""
    logger.info(f"[Process {process_id}] Starting V2 scraper worker")

    stats = ProcessStats(process_id=process_id)
    stats.start_time = time.time()

    try:
        # Create Redis Pool V2
        pool = RedisAccountsPoolV2(
            db_file=redis_url,
            raise_when_no_account=False
        )

        logger.info(f"[Process {process_id}] Connected to Redis Pool V2")

        # Initialize queue (idempotent)
        await pool.init_queue("UserByRestId")

        # Make requests
        for i in range(requests_per_process):
            user_id = user_ids[i % len(user_ids)]

            metrics = await fetch_user_v2(pool, user_id, process_id, i + 1)

            stats.total_requests += 1
            stats.all_metrics.append(metrics)

            if metrics.success:
                stats.successful_requests += 1
                stats.get_account_times.append(metrics.get_account_ms)
                stats.graphql_times.append(metrics.graphql_ms)
                stats.total_times.append(metrics.total_ms)

                logger.info(
                    f"[Process {process_id}] Request {i+1}/{requests_per_process}: SUCCESS | "
                    f"Account:{metrics.get_account_ms:.1f}ms GraphQL:{metrics.graphql_ms:.1f}ms "
                    f"Total:{metrics.total_ms:.1f}ms | User:{metrics.username}"
                )
            else:
                stats.failed_requests += 1
                logger.warning(
                    f"[Process {process_id}] Request {i+1}/{requests_per_process}: "
                    f"FAILED | Error: {metrics.error}"
                )

            # Small delay between requests
            await asyncio.sleep(0.5)

    except Exception as e:
        logger.error(f"[Process {process_id}] Worker failed: {e}")
        import traceback
        traceback.print_exc()
    finally:
        stats.end_time = time.time()
        stats.duration = stats.end_time - stats.start_time

        # Convert to dict for serialization
        result_queue.put(asdict(stats))
        logger.info(f"[Process {process_id}] Completed.")


def run_scraper_process(
    process_id: int,
    user_ids: List[str],
    redis_url: str,
    result_queue: mp.Queue,
    requests_per_process: int
):
    """Entry point for multiprocessing"""
    import logging
    logging.basicConfig(
        level=logging.INFO,
        format=f'%(asctime)s - P{process_id} - %(levelname)s - %(message)s'
    )

    asyncio.run(scraper_process_worker(
        process_id,
        user_ids,
        redis_url,
        result_queue,
        requests_per_process
    ))


def calculate_percentiles(values: List[float]) -> Dict[str, float]:
    """Calculate percentile statistics"""
    if not values:
        return {"min": 0, "max": 0, "avg": 0, "p50": 0, "p95": 0, "p99": 0}

    sorted_vals = sorted(values)
    return {
        "min": sorted_vals[0],
        "max": sorted_vals[-1],
        "avg": sum(sorted_vals) / len(sorted_vals),
        "p50": sorted_vals[int(len(sorted_vals) * 0.50)],
        "p95": sorted_vals[int(len(sorted_vals) * 0.95)],
        "p99": sorted_vals[int(len(sorted_vals) * 0.99)] if len(sorted_vals) > 1 else sorted_vals[-1],
    }


def aggregate_statistics(all_stats: List[ProcessStats]) -> Dict[str, Any]:
    """Aggregate statistics from all processes"""
    all_get_account = []
    all_graphql = []
    all_total = []

    for stats in all_stats:
        all_get_account.extend(stats.get_account_times)
        all_graphql.extend(stats.graphql_times)
        all_total.extend(stats.total_times)

    total_requests = sum(s.total_requests for s in all_stats)
    successful_requests = sum(s.successful_requests for s in all_stats)
    failed_requests = sum(s.failed_requests for s in all_stats)

    start_time = min(s.start_time for s in all_stats)
    end_time = max(s.end_time for s in all_stats)
    total_duration = end_time - start_time

    return {
        "summary": {
            "pool_version": "v2 (queue-based)",
            "total_processes": len(all_stats),
            "total_requests": total_requests,
            "successful_requests": successful_requests,
            "failed_requests": failed_requests,
            "success_rate": successful_requests / total_requests if total_requests > 0 else 0,
            "total_duration": total_duration,
            "requests_per_second": total_requests / total_duration if total_duration > 0 else 0,
        },
        "get_account_latency": calculate_percentiles(all_get_account),
        "graphql_latency": calculate_percentiles(all_graphql),
        "total_latency": calculate_percentiles(all_total),
        "per_process_stats": [
            {
                "process_id": s.process_id,
                "requests": s.total_requests,
                "successful": s.successful_requests,
                "failed": s.failed_requests,
                "get_account_avg_ms": sum(s.get_account_times) / len(s.get_account_times) if s.get_account_times else 0,
                "graphql_avg_ms": sum(s.graphql_times) / len(s.graphql_times) if s.graphql_times else 0,
                "total_avg_ms": sum(s.total_times) / len(s.total_times) if s.total_times else 0,
            }
            for s in all_stats
        ]
    }


def print_report(aggregated_stats: Dict[str, Any]):
    """Print comprehensive report"""
    print("\n" + "=" * 90)
    print("REDIS POOL V2 - MULTIPROCESS LOAD TEST RESULTS")
    print("=" * 90)

    summary = aggregated_stats["summary"]
    print(f"\n{'OVERALL SUMMARY':^90}")
    print("-" * 90)
    print(f"  Pool Version:           {summary['pool_version']}")
    print(f"  Total Processes:        {summary['total_processes']}")
    print(f"  Total Requests:         {summary['total_requests']}")
    print(f"  Successful:             {summary['successful_requests']} ({summary['success_rate']:.1%})")
    print(f"  Failed:                 {summary['failed_requests']}")
    print(f"  Total Duration:         {summary['total_duration']:.2f}s")
    print(f"  Throughput:             {summary['requests_per_second']:.2f} req/s")

    # Get Account Latency (Hot Pool + Queue operations)
    get_acc = aggregated_stats["get_account_latency"]
    print(f"\n{'GET ACCOUNT LATENCY (Hot Pool + Queue)':^90}")
    print("-" * 90)
    print(f"  Min:    {get_acc['min']:8.2f}ms")
    print(f"  Avg:    {get_acc['avg']:8.2f}ms")
    print(f"  P50:    {get_acc['p50']:8.2f}ms")
    print(f"  P95:    {get_acc['p95']:8.2f}ms")
    print(f"  P99:    {get_acc['p99']:8.2f}ms")
    print(f"  Max:    {get_acc['max']:8.2f}ms")

    # GraphQL Latency
    gql = aggregated_stats["graphql_latency"]
    print(f"\n{'GRAPHQL REQUEST LATENCY':^90}")
    print("-" * 90)
    print(f"  Min:    {gql['min']:8.2f}ms")
    print(f"  Avg:    {gql['avg']:8.2f}ms")
    print(f"  P50:    {gql['p50']:8.2f}ms")
    print(f"  P95:    {gql['p95']:8.2f}ms")
    print(f"  P99:    {gql['p99']:8.2f}ms")
    print(f"  Max:    {gql['max']:8.2f}ms")

    # Total Latency
    total = aggregated_stats["total_latency"]
    print(f"\n{'TOTAL END-TO-END LATENCY':^90}")
    print("-" * 90)
    print(f"  Min:    {total['min']:8.2f}ms")
    print(f"  Avg:    {total['avg']:8.2f}ms")
    print(f"  P50:    {total['p50']:8.2f}ms")
    print(f"  P95:    {total['p95']:8.2f}ms")
    print(f"  P99:    {total['p99']:8.2f}ms")
    print(f"  Max:    {total['max']:8.2f}ms")

    # Latency Breakdown
    print(f"\n{'LATENCY BREAKDOWN':^90}")
    print("-" * 90)
    get_acc_pct = (get_acc['avg'] / total['avg'] * 100) if total['avg'] > 0 else 0
    graphql_pct = (gql['avg'] / total['avg'] * 100) if total['avg'] > 0 else 0
    print(f"  Get Account (V2):       {get_acc_pct:6.2f}% of total ({get_acc['avg']:.2f}ms)")
    print(f"  GraphQL Request:        {graphql_pct:6.2f}% of total ({gql['avg']:.2f}ms)")

    # Per-Process Stats
    print(f"\n{'PER-PROCESS STATISTICS':^90}")
    print("-" * 90)
    print(f"  {'PID':<6} {'Req':>6} {'Succ':>6} {'Fail':>6} {'GetAcct(ms)':>12} {'GraphQL(ms)':>12} {'Total(ms)':>12}")
    print("-" * 90)

    for proc in aggregated_stats["per_process_stats"]:
        print(f"  {proc['process_id']:<6} "
              f"{proc['requests']:>6} "
              f"{proc['successful']:>6} "
              f"{proc['failed']:>6} "
              f"{proc['get_account_avg_ms']:>12.2f} "
              f"{proc['graphql_avg_ms']:>12.2f} "
              f"{proc['total_avg_ms']:>12.2f}")

    print("\n" + "=" * 90)


def main():
    """Main test orchestrator"""
    NUM_PROCESSES = 10
    REQUESTS_PER_PROCESS = 20

    USER_IDS = [
        '44196397',  # elonmusk
        '813286',    # BarackObama
        '25073877',  # realDonaldTrump
        '50393960',  # BillGates
        '759251',    # cnnbrk
        '1367531',   # FoxNews
        '807095',    # nytimes
        '428333',    # cnn
        '2467791',   # YouTube
        '17919972',  # taylorswift13
    ]

    redis_url = os.getenv("TWS_REDIS_URL") or os.getenv("REDIS_URL")

    if not redis_url:
        print("ERROR: TWS_REDIS_URL or REDIS_URL environment variable not set")
        return

    print("=" * 90)
    print("STARTING REDIS POOL V2 MULTIPROCESS LOAD TEST")
    print("=" * 90)
    print("  Pool Version:          V2 (queue-based)")
    print(f"  Scraper Instances:     {NUM_PROCESSES}")
    print(f"  Requests per Instance: {REQUESTS_PER_PROCESS}")
    print(f"  Total Requests:        {NUM_PROCESSES * REQUESTS_PER_PROCESS}")
    print(f"  Redis URL:             {redis_url}")
    print("=" * 90)
    print()

    result_queue = mp.Queue()
    processes = []

    print(f"Launching {NUM_PROCESSES} scraper processes...")

    for i in range(NUM_PROCESSES):
        p = mp.Process(
            target=run_scraper_process,
            args=(i, USER_IDS, redis_url, result_queue, REQUESTS_PER_PROCESS)
        )
        p.start()
        processes.append(p)
        print(f"  ✓ Process {i} started (PID: {p.pid})")

    print("\nAll processes launched. Waiting for completion...\n")

    for i, p in enumerate(processes):
        p.join()
        print(f"  ✓ Process {i} completed")

    print("\nCollecting results...")
    all_stats = []

    while not result_queue.empty():
        stats_dict = result_queue.get()
        stats = ProcessStats(**stats_dict)
        all_stats.append(stats)

    if not all_stats:
        print("ERROR: No stats collected")
        return

    aggregated_stats = aggregate_statistics(all_stats)
    print_report(aggregated_stats)

    # Save results
    output_file = f"v2_multiprocess_load_test_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(output_file, "w") as f:
        json.dump(aggregated_stats, f, indent=2, default=str)

    print(f"\nDetailed results saved to: {output_file}")


if __name__ == "__main__":
    mp.set_start_method('spawn', force=True)

    try:
        main()
    except KeyboardInterrupt:
        print("\nTest interrupted")
    except Exception as e:
        print(f"\nTest failed: {e}")
        import traceback
        traceback.print_exc()
