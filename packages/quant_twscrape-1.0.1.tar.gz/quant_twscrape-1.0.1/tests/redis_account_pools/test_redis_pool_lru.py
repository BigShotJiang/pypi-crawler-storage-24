"""
Simple Redis pool LRU test with proper error handling and timeouts.
"""

import asyncio
import os
import sys

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from twscrape import API
from twscrape.logger import logger


async def test_redis_connection():
    """Test basic Redis connectivity"""
    logger.info("Testing Redis connection...")

    try:
        redis_url = os.getenv("TWS_REDIS_URL", None)
        logger.info(f"Connecting to Redis: {redis_url}")

        # Test Redis connection with timeout
        api = API(
            pool=redis_url,
            debug=False,
            raise_when_no_account=False,
            use_random_proxy=False
        )

        # Try to get pool stats with timeout
        stats = await asyncio.wait_for(api.pool.stats(), timeout=10.0)
        logger.info(f"✓ Redis connection successful. Pool stats: {stats}")
        return True

    except asyncio.TimeoutError:
        logger.error("✗ Redis connection timeout")
        return False
    except Exception as e:
        logger.error(f"✗ Redis connection failed: {e}")
        return False


async def test_account_retrieval():
    """Test basic account retrieval"""
    logger.info("Testing account retrieval...")

    try:
        redis_url = os.getenv("TWS_REDIS_URL", None)
        api = API(
            pool=redis_url,
            debug=False,
            raise_when_no_account=False,
            use_random_proxy=False
        )

        # Get accounts info instead of full accounts (much faster)
        logger.info("Getting accounts info (faster than full accounts)...")
        accounts_info = await asyncio.wait_for(api.pool.accounts_info(), timeout=10.0)
        logger.info(f"✓ Retrieved info for {len(accounts_info)} accounts")

        if len(accounts_info) == 0:
            logger.warning("⚠ No accounts found in pool")
            return False

        # Show first few accounts
        for i, acc in enumerate(accounts_info[:3]):
            logger.info(f"  Account {i+1}: @{acc['username']} (active: {acc['active']})")

        # Test getting a single account by username
        if accounts_info:
            first_username = accounts_info[0]['username']
            logger.info(f"Testing single account retrieval for @{first_username}...")
            single_account = await asyncio.wait_for(api.pool.get_account(first_username), timeout=5.0)
            if single_account:
                logger.info(f"✓ Successfully retrieved single account: @{single_account.username}")
            else:
                logger.warning("⚠ Single account retrieval returned None")

        return True

    except asyncio.TimeoutError:
        logger.error("✗ Account retrieval timeout")
        return False
    except Exception as e:
        logger.error(f"✗ Account retrieval failed: {e}")
        return False


async def test_simple_request():
    """Test a simple API request"""
    logger.info("Testing simple API request...")

    try:
        redis_url = os.getenv("TWS_REDIS_URL", None)
        api = API(
            pool=redis_url,
            debug=False,
            raise_when_no_account=False,
            use_random_proxy=False
        )

        # Test with a known user ID (Twitter's official account)
        user_id = '1283789577753374721'  # @twitter

        logger.info(f"Fetching user info for ID: {user_id}")
        user = await asyncio.wait_for(api.user_by_id(int(user_id)), timeout=30.0)

        if user:
            logger.info(f"✓ Successfully fetched user: @{user.username}")
            return True
        else:
            logger.warning("⚠ User not found")
            return False

    except asyncio.TimeoutError:
        logger.error("✗ API request timeout")
        return False
    except Exception as e:
        logger.error(f"✗ API request failed: {e}")
        return False


async def test_last_used_update():
    """Verify that last_used is set/updated when an account is acquired"""
    logger.info("Testing last_used update on acquire...")

    redis_url = os.getenv("TWS_REDIS_URL", None)
    api = API(
        pool=redis_url,
        debug=False,
        raise_when_no_account=False,
        use_random_proxy=False,
    )

    # Snapshot last_used for all accounts
    accounts_info_before = await asyncio.wait_for(api.pool.accounts_info(), timeout=15.0)
    if not accounts_info_before:
        logger.warning("No accounts found for last_used test")
        return False

    last_used_before = {x["username"]: x["last_used"] for x in accounts_info_before}

    # Acquire an account for a synthetic queue
    acc = await asyncio.wait_for(api.pool.get_for_queue("test_last_used"), timeout=10.0)
    if not acc:
        logger.error("Could not acquire any account for last_used test")
        return False

    target_username = acc.username
    prev_last_used = last_used_before.get(target_username)

    # Small delay to ensure a measurable timestamp difference
    await asyncio.sleep(0.5)

    # Reload the document for the acquired account
    accounts_info_after = await asyncio.wait_for(api.pool.accounts_info(), timeout=15.0)
    after_map = {x["username"]: x for x in accounts_info_after}
    after_entry = after_map.get(target_username)

    if not after_entry:
        logger.error(f"Account {target_username} missing after acquisition")
        return False

    updated_last_used = after_entry.get("last_used")

    # Clean up the lock for the synthetic queue
    try:
        await api.pool.unlock(target_username, "test_last_used")
    except Exception:
        pass

    if updated_last_used is None:
        logger.error("last_used was not set on acquire")
        return False

    # Retrieve the specific account again and verify last_used persisted on the Account object
    acc_after = await asyncio.wait_for(api.pool.get_account(target_username), timeout=10.0)
    if not acc_after:
        logger.error(f"Failed to fetch account @{target_username} after acquisition")
        return False

    if acc_after.last_used is None:
        logger.error("Account object's last_used is None after acquisition")
        return False

    # Ensure the Account object's last_used is at least as recent as the value in accounts_info
    if updated_last_used and acc_after.last_used < updated_last_used:
        logger.error(
            f"Account object's last_used ({acc_after.last_used}) is older than info map ({updated_last_used})"
        )
        return False

    if prev_last_used is None:
        logger.info("last_used was previously empty; now set. ✓")
        return True

    if updated_last_used > prev_last_used:
        logger.info(
            f"last_used updated for @{target_username}: {prev_last_used.isoformat()} -> {updated_last_used.isoformat()}"
        )
        return True

    logger.error(
        f"last_used did not increase for @{target_username}: before={prev_last_used}, after={updated_last_used}"
    )
    return False


async def test_lru_behavior():
    """Test LRU behavior with minimal requests"""
    logger.info("Testing LRU behavior...")

    try:
        redis_url = os.getenv("TWS_REDIS_URL", None)
        api = API(
            pool=redis_url,
            debug=False,
            raise_when_no_account=False,
            use_random_proxy=False
        )

        # Get initial account states (using accounts_info for speed)
        accounts_before = await asyncio.wait_for(api.pool.accounts_info(), timeout=10.0)
        logger.info(f"Found {len(accounts_before)} accounts")

        if len(accounts_before) == 0:
            logger.warning("⚠ No accounts available for LRU test")
            return False

        # Sort by last_used to see expected LRU order
        from datetime import datetime, timezone
        old_time = datetime(1970, 1, 1).replace(tzinfo=timezone.utc)
        accounts_sorted = sorted(
            accounts_before,
            key=lambda x: x["last_used"] or old_time
        )

        logger.info("Expected LRU order (oldest first):")
        for i, acc in enumerate(accounts_sorted[:5]):
            last_used = acc["last_used"].isoformat() if acc["last_used"] else "Never"
            logger.info(f"  {i+1}. @{acc['username']} - Last used: {last_used}")

        # Make a few simple requests
        test_user_ids = [21, 51333]  # Known active accounts

        for i, user_id in enumerate(test_user_ids):
            try:
                logger.info(f"Making request {i+1} for user ID: {user_id}")
                user = await asyncio.wait_for(api.user_by_id(user_id), timeout=30.0)

                if user:
                    logger.info(f"✓ Request {i+1}: Got user @{user.username}")
                else:
                    logger.warning(f"⚠ Request {i+1}: User {user_id} not found")

            except asyncio.TimeoutError:
                logger.error(f"✗ Request {i+1}: Timeout")
                break
            except Exception as e:
                logger.error(f"✗ Request {i+1}: {e}")
                break

        # Get final account states
        accounts_after = await asyncio.wait_for(api.pool.accounts_info(), timeout=10.0)

        logger.info(f"Accounts after test: {len(accounts_after)}")

        return True

    except asyncio.TimeoutError:
        logger.error("✗ LRU test timeout")
        return False
    except Exception as e:
        logger.error(f"✗ LRU test failed: {e}")
        return False


async def main():
    """Main test function with proper error handling"""
    logger.info("=" * 60)
    logger.info("REDIS POOL LRU BEHAVIOR TEST")
    logger.info("=" * 60)

    # Check environment
    redis_url = os.getenv("TWS_REDIS_URL", None)
    logger.info(f"Redis URL: {redis_url}")

    # Test 1: Redis connection
    logger.info("\n1. Testing Redis connection...")
    if not await test_redis_connection():
        logger.error("Redis connection failed. Exiting.")
        return

    # Test 2: Account retrieval
    logger.info("\n2. Testing account retrieval...")
    if not await test_account_retrieval():
        logger.error("Account retrieval failed. Exiting.")
        return

    # Test 3: Simple API request
    logger.info("\n3. Testing simple API request...")
    if not await test_simple_request():
        logger.error("API request failed. Exiting.")
        return

    # Test 3.5: last_used update on acquire
    logger.info("\n3.5. Testing last_used update...")
    if not await test_last_used_update():
        logger.error("last_used update test failed.")
        return

    # Test 4: LRU behavior
    logger.info("\n4. Testing LRU behavior...")
    if not await test_lru_behavior():
        logger.error("LRU test failed.")
        return

    logger.info("\n" + "=" * 60)
    logger.info("ALL TESTS COMPLETED SUCCESSFULLY!")
    logger.info("=" * 60)


if __name__ == "__main__":
    # Set up logging
    import logging
    logging.basicConfig(level=logging.INFO)

    # Run the test with overall timeout
    try:
        asyncio.run(asyncio.wait_for(main(), timeout=300.0))  # 5 minute overall timeout
    except asyncio.TimeoutError:
        logger.error("Overall test timeout after 5 minutes")
    except KeyboardInterrupt:
        logger.info("Test interrupted by user")
    except Exception as e:
        logger.error(f"Test failed with error: {e}")
