"""
Instrumented Redis pool wrapper for detailed latency measurement.
Tracks individual Redis operations during account selection.
"""

import time
import json
from dataclasses import dataclass, field
from typing import Optional, List
from twscrape.redis_accounts_pool import RedisAccountsPool
from twscrape.account import Account
from twscrape import utc


@dataclass
class RedisOperationMetrics:
    """Detailed metrics for Redis operations during account selection"""
    # Individual operation latencies
    smembers_time: float = 0.0          # SMEMBERS tws:acc:active
    pipeline_build_time: float = 0.0     # Time to build pipeline
    pipeline_execute_time: float = 0.0   # HGETALL × batch_size in pipeline
    json_parse_time: float = 0.0         # JSON.loads(locks_epoch)
    lock_check_time: float = 0.0         # Lock expiry calculation
    lua_eval_time: float = 0.0           # EVAL lua script (atomic lock)
    reload_time: float = 0.0             # HGETALL after lock acquired
    total_account_mgmt_time: float = 0.0 # Total time in get_for_queue

    # Operation counts
    batches_checked: int = 0
    accounts_checked: int = 0
    lock_attempts: int = 0
    lock_acquired: bool = False

    # Account info
    selected_account: Optional[str] = None
    success: bool = False
    error: Optional[str] = None


@dataclass
class AggregatedRedisMetrics:
    """Aggregated metrics across multiple operations"""
    operations: List[RedisOperationMetrics] = field(default_factory=list)

    def add(self, metrics: RedisOperationMetrics):
        self.operations.append(metrics)

    def get_stats(self):
        """Calculate statistics across all operations"""
        if not self.operations:
            return {}

        def calc_percentiles(values: List[float]) -> dict:
            if not values:
                return {"min": 0, "max": 0, "avg": 0, "p50": 0, "p95": 0, "p99": 0}
            sorted_vals = sorted(values)
            return {
                "min": sorted_vals[0],
                "max": sorted_vals[-1],
                "avg": sum(sorted_vals) / len(sorted_vals),
                "p50": sorted_vals[int(len(sorted_vals) * 0.50)],
                "p95": sorted_vals[int(len(sorted_vals) * 0.95)],
                "p99": sorted_vals[int(len(sorted_vals) * 0.99)] if len(sorted_vals) > 1 else sorted_vals[-1],
            }

        return {
            "smembers": calc_percentiles([op.smembers_time for op in self.operations if op.smembers_time > 0]),
            "pipeline_execute": calc_percentiles([op.pipeline_execute_time for op in self.operations if op.pipeline_execute_time > 0]),
            "json_parse": calc_percentiles([op.json_parse_time for op in self.operations if op.json_parse_time > 0]),
            "lua_eval": calc_percentiles([op.lua_eval_time for op in self.operations if op.lua_eval_time > 0]),
            "reload": calc_percentiles([op.reload_time for op in self.operations if op.reload_time > 0]),
            "total_account_mgmt": calc_percentiles([op.total_account_mgmt_time for op in self.operations if op.total_account_mgmt_time > 0]),
            "summary": {
                "total_operations": len(self.operations),
                "successful_operations": sum(1 for op in self.operations if op.success),
                "total_batches_checked": sum(op.batches_checked for op in self.operations),
                "total_accounts_checked": sum(op.accounts_checked for op in self.operations),
                "total_lock_attempts": sum(op.lock_attempts for op in self.operations),
                "total_locks_acquired": sum(1 for op in self.operations if op.lock_acquired),
            }
        }


class InstrumentedRedisPool(RedisAccountsPool):
    """
    Instrumented version of RedisAccountsPool that tracks detailed metrics.

    Wraps the original get_for_queue method to measure individual Redis operations.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.metrics = AggregatedRedisMetrics()
        self._current_operation_metrics: Optional[RedisOperationMetrics] = None

    async def get_for_queue_instrumented(self, queue: str) -> tuple[Optional[Account], RedisOperationMetrics]:
        """
        Instrumented version of get_for_queue that tracks detailed metrics.
        Returns (Account, Metrics) tuple.
        """
        metrics = RedisOperationMetrics()
        operation_start = time.time()

        try:
            # OPERATION 1: SMEMBERS - Get active accounts
            smembers_start = time.time()
            active_users = list(await self._r.smembers(self._k_accounts_active))
            metrics.smembers_time = time.time() - smembers_start

            if not active_users:
                metrics.total_account_mgmt_time = time.time() - operation_start
                metrics.error = "No active accounts"
                return None, metrics

            # Batch processing
            batch_size = 20
            now_ts = utc.ts()

            for i in range(0, len(active_users), batch_size):
                metrics.batches_checked += 1
                batch_users = active_users[i:i + batch_size]

                # OPERATION 2: PIPELINE - Batch fetch account documents
                pipeline_build_start = time.time()
                pipe = self._r.pipeline()
                for u in batch_users:
                    pipe.hgetall(self._acc_key(u))
                metrics.pipeline_build_time += time.time() - pipeline_build_start

                pipeline_exec_start = time.time()
                try:
                    batch_docs = await pipe.execute()
                    metrics.pipeline_execute_time += time.time() - pipeline_exec_start
                except Exception:
                    # Fallback to individual requests if pipeline fails
                    import asyncio
                    batch_docs = await asyncio.gather(
                        *[self._get_doc(u) for u in batch_users],
                        return_exceptions=True
                    )
                    metrics.pipeline_execute_time += time.time() - pipeline_exec_start

                # OPERATION 3: Check each account in batch
                for u, doc in zip(batch_users, batch_docs):
                    metrics.accounts_checked += 1

                    if isinstance(doc, Exception) or not doc:
                        continue

                    # OPERATION 4: JSON PARSE - Parse locks_epoch
                    json_parse_start = time.time()
                    locks_epoch_str = doc.get("locks_epoch", "{}")
                    try:
                        locks_epoch = json.loads(locks_epoch_str)
                        queue_lock_epoch = locks_epoch.get(queue)
                        metrics.json_parse_time += time.time() - json_parse_start

                        # OPERATION 5: LOCK CHECK - Check if lock expired
                        lock_check_start = time.time()
                        is_available = queue_lock_epoch is None or queue_lock_epoch < now_ts
                        metrics.lock_check_time += time.time() - lock_check_start

                        if is_available:
                            metrics.lock_attempts += 1

                            # OPERATION 6: LUA EVAL - Atomic lock acquisition
                            lua_eval_start = time.time()
                            lock_acquired = await self._try_lock_account(u, queue)
                            metrics.lua_eval_time += time.time() - lua_eval_start

                            if lock_acquired:
                                metrics.lock_acquired = True
                                metrics.selected_account = u

                                # OPERATION 7: RELOAD - Get updated account document
                                reload_start = time.time()
                                doc2 = await self._get_doc(u)
                                metrics.reload_time = time.time() - reload_start

                                account = self._redis_doc_to_acc(doc2) if doc2 else None

                                if account:
                                    metrics.success = True
                                    metrics.total_account_mgmt_time = time.time() - operation_start
                                    return account, metrics
                                else:
                                    metrics.error = "Failed to convert doc to account"

                    except (json.JSONDecodeError, TypeError):
                        metrics.json_parse_time += time.time() - json_parse_start
                        # If locks_epoch is malformed, try to acquire anyway
                        metrics.lock_attempts += 1

                        lua_eval_start = time.time()
                        lock_acquired = await self._try_lock_account(u, queue)
                        metrics.lua_eval_time += time.time() - lua_eval_start

                        if lock_acquired:
                            metrics.lock_acquired = True
                            metrics.selected_account = u

                            reload_start = time.time()
                            doc2 = await self._get_doc(u)
                            metrics.reload_time = time.time() - reload_start

                            account = self._redis_doc_to_acc(doc2) if doc2 else None

                            if account:
                                metrics.success = True
                                metrics.total_account_mgmt_time = time.time() - operation_start
                                return account, metrics

            # No account found
            metrics.error = "No available accounts"
            metrics.total_account_mgmt_time = time.time() - operation_start
            return None, metrics

        except Exception as e:
            metrics.error = str(e)
            metrics.total_account_mgmt_time = time.time() - operation_start
            return None, metrics

    async def get_for_queue(self, queue: str) -> Optional[Account]:
        """
        Override get_for_queue to collect metrics automatically.
        Use this for normal operation with automatic metrics collection.
        """
        account, metrics = await self.get_for_queue_instrumented(queue)
        self.metrics.add(metrics)
        return account

    async def get_for_queue_or_wait_instrumented(
        self,
        queue: str,
        max_wait_iterations: Optional[int] = None
    ) -> tuple[Optional[Account], List[RedisOperationMetrics]]:
        """
        Instrumented version of get_for_queue_or_wait.
        Returns (Account, List[Metrics for each attempt])
        """
        if max_wait_iterations is None:
            max_wait_iterations = 3 if self._raise_when_no_account else 100

        all_metrics = []
        msg_shown = False

        for iteration in range(max_wait_iterations):
            account, metrics = await self.get_for_queue_instrumented(queue)
            all_metrics.append(metrics)

            if account:
                return account, all_metrics

            if not msg_shown:
                from twscrape.logger import logger
                logger.warning(
                    f"No account available for queue '{queue}'. "
                    f"Waiting... (attempt {iteration + 1}/{max_wait_iterations})"
                )
                msg_shown = True

            # Wait before retry
            import asyncio
            await asyncio.sleep(1 if self._raise_when_no_account else 5)

        return None, all_metrics

    def get_aggregated_metrics(self) -> dict:
        """Get aggregated statistics for all operations"""
        return self.metrics.get_stats()

    def reset_metrics(self):
        """Reset collected metrics"""
        self.metrics = AggregatedRedisMetrics()
