#!/usr/bin/env python3
"""
Test script for the Twitter Scraper FastAPI

This script demonstrates how to use the API endpoints.
Make sure the server is running on http://localhost:8000
"""

import requests

BASE_URL = "http://localhost:8000/api/v1"


def test_health():
    """Test the health endpoint"""
    print("🔍 Testing health endpoint...")
    try:
        response = requests.get("http://localhost:8000/health")
        print(f"Health Status: {response.json()}")
        return response.json().get("api_ready", False)
    except Exception as e:
        print(f"❌ Health check failed: {e}")
        return False


def test_search_tweets():
    """Test tweet search"""
    print("\n🐦 Testing tweet search...")
    try:
        response = requests.get(
            f"{BASE_URL}/tweets/search",
            params={"q": "python programming", "limit": 20},
        )
        print("🚀 ~ test_api.py:35 ~ response:", response.json())

        if response.status_code == 200:
            data = response.json()
            print(f"✅ Found {data['count']} tweets")
            if data["tweets"]:
                first_tweet = data["tweets"][0]
                print(f"   Sample tweet: {first_tweet.get('rawContent', '')[:100]}...")
        else:
            print(f"❌ Search failed: {response.status_code} - {response.text}")

    except Exception as e:
        print(f"❌ Tweet search failed: {e}")


def test_search_users():
    """Test user search"""
    print("\n👥 Testing user search...")
    try:
        response = requests.get(
            f"{BASE_URL}/users/search", params={"q": "elon musk", "limit": 2}
        )

        if response.status_code == 200:
            data = response.json()
            print(f"✅ Found {data['count']} users")
            if data["users"]:
                first_user = data["users"][0]
                print(f"   Sample user: @{first_user.get('username', 'unknown')}")
        else:
            print(f"❌ User search failed: {response.status_code} - {response.text}")

    except Exception as e:
        print(f"❌ User search failed: {e}")


def test_get_user_by_username():
    """Test getting user by username"""
    print("\n👤 Testing get user by username...")
    try:
        # Try to get a well-known user
        response = requests.get(f"{BASE_URL}/users/by-username/elonmusk")

        if response.status_code == 200:
            user = response.json()
            print(f"✅ Found user: @{user.get('username', 'unknown')}")
            print(f"   Display name: {user.get('displayname', 'N/A')}")
            print(f"   Followers: {user.get('followersCount', 'N/A')}")
        else:
            print(f"❌ Get user failed: {response.status_code} - {response.text}")

    except Exception as e:
        print(f"❌ Get user by username failed: {e}")


def test_trends():
    """Test getting trends"""
    print("\n📈 Testing trends...")
    try:
        response = requests.get(
            f"{BASE_URL}/trends", params={"trend_id": "trending", "limit": 5}
        )

        if response.status_code == 200:
            data = response.json()
            print(f"✅ Found {data['count']} trends")
            if data["trends"]:
                first_trend = data["trends"][0]
                print(f"   Sample trend: {first_trend.get('name', 'N/A')}")
        else:
            print(f"❌ Trends failed: {response.status_code} - {response.text}")

    except Exception as e:
        print(f"❌ Trends failed: {e}")


def test_accounts():
    """Test account management"""
    print("\n🔐 Testing account management...")
    try:
        response = requests.get(f"{BASE_URL}/accounts")

        if response.status_code == 200:
            data = response.json()
            print("✅ Account status retrieved")
            print(f"   Total accounts: {data.get('total', 0)}")
            print(f"   Active accounts: {data.get('active', 0)}")
        else:
            print(f"❌ Account status failed: {response.status_code} - {response.text}")

    except Exception as e:
        print(f"❌ Account management failed: {e}")


def test_add_dummy_account():
    """Test adding a dummy account (this will fail but tests the endpoint)"""
    print("\n➕ Testing add account endpoint (with dummy data)...")
    try:
        response = requests.post(
            f"{BASE_URL}/accounts",
            json={
                "username": "test_user",
                "password": "test_password",
                "email": "test@example.com",
                "email_password": "test_email_password",
            },
        )

        # This will likely fail since these are dummy credentials
        if response.status_code == 200:
            print("✅ Account added successfully (unexpected with dummy data)")
        else:
            print(f"⚠️  Account addition failed as expected: {response.status_code}")
            print("   (This is normal with dummy credentials)")

    except Exception as e:
        print(f"⚠️  Add account failed as expected: {e}")


def main():
    """Run all tests"""
    print("🚀 Starting Twitter Scraper API Tests")
    print("=" * 50)

    # Test health first
    if not test_health():
        print("\n❌ API not ready. Make sure:")
        print("   1. The server is running (python start_server.py)")
        print("   2. Dependencies are installed")
        print("   3. At least one Twitter account is added and logged in")
        return

    # Run other tests
    test_search_tweets()
    test_search_users()
    test_get_user_by_username()
    test_trends()
    # test_accounts()
    # test_add_dummy_account()

    print("\n" + "=" * 50)
    print("🎉 Test suite completed!")
    print("\nTo use the API:")
    print("1. Add real Twitter accounts via the /accounts endpoint")
    print("2. Login accounts via /accounts/login endpoint")
    print("3. Start scraping data!")
    print("\nAPI Documentation: http://localhost:8000/docs")


if __name__ == "__main__":
    main()
