import asyncio
import json
import os
import time
from typing import Any
from urllib.parse import urlparse

import httpx
from httpx import AsyncClient, Response

from .accounts_pool import Account, AccountsPool
from .logger import logger
from .login import LoginConfig
from .utils import utc
from .xclid import XClIdGen

# Import proxy managers
try:
    from .proxies import proxy_manager
    from .proxy_pool import ProxyInfo, proxy_pool_manager
except ImportError:
    proxy_manager = None
    proxy_pool_manager = None
    ProxyInfo = None

ReqParams = dict[str, str | int] | None
TMP_TS = utc.now().isoformat().split(".")[0].replace("T", "_").replace(":", "-")[0:16]


class HandledError(Exception): ...


class AbortReqError(Exception): ...


class ProxyError(Exception):
    """Raised when proxy-related errors occur that should trigger proxy retry"""

    pass


class XClIdGenStore:
    items: dict[str, XClIdGen] = {}  # username -> XClIdGen

    @classmethod
    async def get(cls, username: str, fresh=False) -> XClIdGen:
        if username in cls.items and not fresh:
            return cls.items[username]

        tries = 0
        while tries < 3:
            try:
                clid_gen = await XClIdGen.create()
                cls.items[username] = clid_gen
                return clid_gen
            except httpx.HTTPStatusError:
                tries += 1
                await asyncio.sleep(1)

        raise AbortReqError(
            "Faield to create XClIdGen. See: https://github.com/vladkens/twscrape/issues/248"
        )


class Ctx:
    def __init__(self, acc: Account, clt: AsyncClient, proxy_info: ProxyInfo | None = None):
        self.req_count = 0
        self.acc = acc
        self.clt = clt
        self.proxy_info = proxy_info
        self.session_start_time = time.time()

    async def aclose(self):
        if proxy_pool_manager and self.proxy_info:
            # Return session to pool instead of just closing
            await proxy_pool_manager.return_session(
                self.clt,
                self.proxy_info,
                success=True,  # We'll track success/failure in requests
                response_time=time.time() - self.session_start_time,
            )
        else:
            await self.clt.aclose()

    async def req(self, method: str, url: str, params: ReqParams = None) -> Response:
        # if code 404 on first try then generate new x-client-transaction-id and retry
        # https://github.com/vladkens/twscrape/issues/248
        path = urlparse(url).path or "/"

        tries = 0
        while tries < 3:
            gen = await XClIdGenStore.get(self.acc.username, fresh=tries > 0)
            hdr = {"x-client-transaction-id": gen.calc(method, path)}
            rep = await self.clt.request(method, url, params=params, headers=hdr)
            logger.debug(f"rep {rep}")
            if rep.status_code != 404:
                return rep

            tries += 1
            logger.debug(f"Retrying request with new x-client-transaction-id: {url}")
            await asyncio.sleep(1)

        raise AbortReqError(
            "Faield to get XClIdGen. See: https://github.com/vladkens/twscrape/issues/248"
        )


def req_id(rep: Response):
    lr = str(rep.headers.get("x-rate-limit-remaining", -1))
    ll = str(rep.headers.get("x-rate-limit-limit", -1))
    sz = max(len(lr), len(ll))
    lr, ll = lr.rjust(sz), ll.rjust(sz)

    username = getattr(rep, "__username", "<UNKNOWN>")
    return f"{lr}/{ll} - {username}"


def dump_rep(rep: Response):
    count = getattr(dump_rep, "__count", -1) + 1
    setattr(dump_rep, "__count", count)

    acc = getattr(rep, "__username", "<unknown>")
    outfile = f"{count:05d}_{rep.status_code}_{acc}.txt"
    outfile = f"/tmp/twscrape-{TMP_TS}/{outfile}"
    os.makedirs(os.path.dirname(outfile), exist_ok=True)

    msg = []
    msg.append(f"{count:,d} - {req_id(rep)}")
    msg.append(f"{rep.status_code} {rep.request.method} {rep.request.url}")
    msg.append("\n")
    # msg.append("\n".join([str(x) for x in list(rep.request.headers.items())]))
    msg.append("\n".join([str(x) for x in list(rep.headers.items())]))
    msg.append("\n")

    try:
        msg.append(json.dumps(rep.json(), indent=2))
    except json.JSONDecodeError:
        msg.append(rep.text)

    txt = "\n".join(msg)
    with open(outfile, "w") as f:
        f.write(txt)


class QueueClient:
    def __init__(
        self,
        pool: AccountsPool | None,
        queue: str,
        debug: bool = False,
        proxy: str | None = None,
        *,
        backend: str | None = None,
        db_file: str = "accounts.db",
        login_config: LoginConfig | None = None,
        raise_when_no_account: bool = False,
    ):
        # Single source of truth: if a pool is provided (from get_api), use it directly.
        # Only if not provided, create via factory using explicit args/env.
        self.pool = pool
        self.queue = queue
        self.debug = debug
        self.ctx: Ctx | None = None
        self.proxy = proxy
        self.proxy_retry_count = 0
        self.max_proxy_retries = 3
        self.current_proxy_info: ProxyInfo | None = None
        self.failed_proxy_ids: list[str] = []
        # Proactive cooldown threshold (0.0-1.0). Default from env or 0.9 (90%).
        try:
            self.rate_limit_threshold = float(os.getenv("TWS_RATE_LIMIT_THRESHOLD", "0.9"))
        except Exception:
            self.rate_limit_threshold = 0.9

    async def __aenter__(self):
        await self._get_ctx()
        # Start proxy pool cleanup if using new proxy manager
        if proxy_pool_manager:
            await proxy_pool_manager.start_cleanup_task()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self._close_ctx()

    def _get_next_proxy(self) -> str | None:
        """Get a different proxy for retry attempts"""
        if proxy_manager and proxy_manager.get_proxy_count() > 0:
            return proxy_manager.get_random_proxy()
        return None

    async def _close_ctx(self, reset_at=-1, inactive=False, msg: str | None = None):
        if self.ctx is None:
            return

        ctx, self.ctx, self.req_count = self.ctx, None, 0
        username = ctx.acc.username
        await ctx.aclose()

        if inactive:
            await self.pool.mark_inactive(username, msg)
            return

        if reset_at > 0:
            await self.pool.lock_until(ctx.acc.username, self.queue, reset_at, ctx.req_count)
            return

        await self.pool.unlock(ctx.acc.username, self.queue, ctx.req_count)

    async def _get_ctx(self, proxy_override: str | None = None):
        if self.ctx:
            return self.ctx

        acc = await self.pool.get_for_queue_or_wait(self.queue)
        if acc is None:
            return None

        # Use new proxy pool manager only if proxy is configured
        if proxy_pool_manager and (self.proxy or proxy_override):
            # Get excluded proxy IDs from recent failures
            excluded_proxy_ids = self.failed_proxy_ids[-5:]  # Last 5 failed proxies

            # Try to get the best proxy
            proxy_info = proxy_pool_manager.get_best_proxy(exclude_proxy_ids=excluded_proxy_ids)

            # Get a session (may reuse existing)
            clt, proxy_info = await proxy_pool_manager.get_session(
                proxy_info=proxy_info, reuse_existing=True
            )

            self.current_proxy_info = proxy_info

            if self.debug and proxy_info:
                logger.debug(
                    f"Using proxy: {proxy_info.host}:{proxy_info.port} ({proxy_info.proxy_type.value})"
                )
        else:
            # Fallback to original proxy logic or no proxy
            current_proxy = proxy_override or self.proxy
            clt = acc.make_client(proxy=current_proxy)

        # Configure the client with account settings
        clt.cookies.update(acc.cookies)
        clt.headers.update(acc.headers)

        # default settings (from Account.make_client)
        clt.headers["user-agent"] = acc.user_agent
        clt.headers["content-type"] = "application/json"
        clt.headers["authorization"] = (
            "Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA"
        )
        clt.headers["x-twitter-active-user"] = "yes"
        clt.headers["x-twitter-client-language"] = "en"

        if "ct0" in clt.cookies:
            clt.headers["x-csrf-token"] = clt.cookies["ct0"]

        self.ctx = Ctx(acc, clt, self.current_proxy_info)
        return self.ctx

    async def _recreate_ctx_with_new_proxy(self):
        """Recreate context with a new proxy for retry"""
        # Record failed proxy ID
        if self.current_proxy_info:
            proxy_id = f"{self.current_proxy_info.proxy_type.value}_{self.current_proxy_info.host}_{self.current_proxy_info.port}"
            if proxy_id not in self.failed_proxy_ids:
                self.failed_proxy_ids.append(proxy_id)

            # Return failed session
            if proxy_pool_manager:
                await proxy_pool_manager.return_session(
                    self.ctx.clt, self.current_proxy_info, success=False
                )
            else:
                await self.ctx.aclose()
        elif self.ctx:
            await self.ctx.aclose()

        self.ctx = None

        if proxy_pool_manager:
            # Use new proxy pool manager
            return await self._get_ctx()
        else:
            # Fallback to old logic
            new_proxy = self._get_next_proxy()
            if self.debug and new_proxy:
                logger.debug(f"Retrying with new proxy: {new_proxy}")
            return await self._get_ctx(proxy_override=new_proxy)

    def _is_proxy_error(self, exc: Exception) -> bool:
        """Check if the exception is a proxy-related error that should trigger proxy retry"""
        if isinstance(exc, (httpx.ProxyError, httpx.ConnectError, httpx.ConnectTimeout)):
            return True

        # Check for specific proxy-related error messages
        error_msg = str(exc).lower()
        proxy_error_indicators = [
            "proxy",
            "connection refused",
            "connection timeout",
            "tunnel connection failed",
            "socks",
            "http_proxy",
            "connection reset",
            "network is unreachable",
        ]

        return any(indicator in error_msg for indicator in proxy_error_indicators)

    async def _check_rep(self, rep: Response) -> None:
        """
        This function can raise Exception and request will be retried or aborted
        Or if None is returned, response will passed to api parser as is
        """

        if self.debug:
            dump_rep(rep)

        try:
            res = rep.json()
        except json.JSONDecodeError:
            res: Any = {"_raw": rep.text}

        limit_remaining = int(rep.headers.get("x-rate-limit-remaining", -1))
        limit_reset = int(rep.headers.get("x-rate-limit-reset", -1))
        limit_max = int(rep.headers.get("x-rate-limit-limit", -1))

        err_msg = "OK"
        if "errors" in res:
            err_msg = set([f"({x.get('code', -1)}) {x['message']}" for x in res["errors"]])
            err_msg = "; ".join(list(err_msg))

        log_msg = f"{rep.status_code:3d} - {req_id(rep)} - {err_msg}"
        logger.trace(log_msg)

        # for dev: need to add some features in api.py
        if err_msg.startswith("(336) The following features cannot be null"):
            logger.error(f"[DEV] Update required: {err_msg}")
            exit(1)

        # proactive cooldown at configured threshold (e.g., 90%) if headers present
        if (
            limit_max > 0
            and limit_remaining >= 0
            and limit_reset > 0
            and (limit_remaining / max(1, limit_max)) <= (1.0 - self.rate_limit_threshold)
        ):
            logger.debug(
                f"Proactive cooldown: {log_msg} (remaining={limit_remaining}/{limit_max}, reset={limit_reset})"
            )
            await self._close_ctx(limit_reset)
            raise HandledError()

        # general api rate limit
        if limit_remaining == 0 and limit_reset > 0:
            logger.debug(f"Rate limited: {log_msg}")
            await self._close_ctx(limit_reset)
            raise HandledError()

        # no way to check is account banned in direct way, but this check should work
        if err_msg.startswith("(88) Rate limit exceeded") and limit_remaining > 0:
            logger.warning(f"(88) Rate limit exceeded: {log_msg}")
            await self._close_ctx(-1, inactive=True, msg=err_msg)
            raise HandledError()

        if err_msg.startswith("(326) Authorization: Denied by access control"):
            logger.warning(f"Ban detected: {log_msg}")
            await self._close_ctx(-1, inactive=True, msg=err_msg)
            raise HandledError()

        if err_msg.startswith("(32) Could not authenticate you"):
            logger.warning(f"Session expired or banned: {log_msg}")
            await self._close_ctx(-1, inactive=True, msg=err_msg)
            raise HandledError()

        if err_msg == "OK" and rep.status_code == 403:
            logger.warning(f"Session expired or banned: {log_msg}")
            await self._close_ctx(-1, inactive=False, msg=None)
            raise HandledError()

        # account suspended - deactivate account
        if rep.status_code == 403 and "suspended" in err_msg.lower():
            logger.warning(f"Account suspended: {log_msg}")
            await self._close_ctx(-1, inactive=True, msg=err_msg)
            raise HandledError()

        # CSRF token mismatch - session invalid
        if err_msg.startswith("(353)") or "csrf cookie and header" in err_msg.lower():
            logger.warning(f"CSRF token mismatch (session invalid): {log_msg}")
            await self._close_ctx(-1, inactive=True, msg=err_msg)
            raise HandledError()

        # something from twitter side - abort all queries, see: https://github.com/vladkens/twscrape/pull/80
        if err_msg.startswith("(131) Dependency: Internal error"):
            # looks like when data exists, we can ignore this error
            # https://github.com/vladkens/twscrape/issues/166
            if rep.status_code == 200 and "data" in res and "user" in res["data"]:
                err_msg = "OK"
            else:
                logger.warning(f"Dependency error (request skipped): {err_msg}")
                raise AbortReqError()

        # content not found
        if rep.status_code == 200 and "_Missing: No status found with that ID" in err_msg:
            return  # ignore this error

        # something from twitter side  - just ignore it, see: https://github.com/vladkens/twscrape/pull/95
        if rep.status_code == 200 and "Authorization" in err_msg:
            logger.warning(f"Authorization unknown error: {log_msg}")
            return

        if err_msg != "OK":
            logger.warning(f"API unknown error: {log_msg}")
            return  # ignore any other unknown errors

        try:
            rep.raise_for_status()
        except httpx.HTTPStatusError:
            logger.error(f"Unhandled API response code: {log_msg}")
            await self._close_ctx(utc.ts() + 60 * 15)  # 15 minutes
            raise HandledError()

    async def get(self, url: str, params: ReqParams = None) -> Response | None:
        return await self.req("GET", url, params=params)

    async def req(self, method: str, url: str, params: ReqParams = None) -> Response | None:
        unknown_retry, connection_retry = 0, 0
        proxy_retry = 0

        while True:
            ctx = await self._get_ctx()  # not need to close client, class implements __aexit__
            if ctx is None:
                return None

            try:
                request_start = time.time()
                rep = await ctx.req(method, url, params=params)
                request_time = time.time() - request_start

                setattr(rep, "__username", ctx.acc.username)
                await self._check_rep(rep)

                # Record successful request for proxy stats
                if self.current_proxy_info and proxy_pool_manager:
                    self.current_proxy_info.record_success(request_time)

                ctx.req_count += 1  # count only successful
                unknown_retry, connection_retry, proxy_retry = 0, 0, 0
                # Clear failed proxy list on success
                self.failed_proxy_ids.clear()
                return rep
            except AbortReqError:
                # abort all queries
                return
            except HandledError:
                # retry with new account
                continue
            except (httpx.ReadTimeout, httpx.ProxyError):
                # http transport failed, just retry with same account
                continue
            except (httpx.ConnectError, httpx.ConnectTimeout) as e:
                # Check if this is a proxy-related error and we're actually using a proxy
                if (
                    self._is_proxy_error(e)
                    and (
                        self.proxy or self.current_proxy_info
                    )  # Only retry if actually using a proxy
                    and (proxy_pool_manager or proxy_manager)
                    and proxy_retry < self.max_proxy_retries
                ):
                    proxy_retry += 1
                    logger.warning(
                        f"Proxy error (attempt {proxy_retry}/{self.max_proxy_retries}): {e}"
                    )

                    # Try with a different proxy
                    try:
                        await self._recreate_ctx_with_new_proxy()
                        continue
                    except Exception as proxy_exc:
                        logger.warning(f"Failed to recreate context with new proxy: {proxy_exc}")
                        # Fall through to original connection retry logic

                # Original connection retry logic
                connection_retry += 1
                if connection_retry >= 3:
                    if proxy_retry > 0:
                        logger.error(
                            f"Failed after {proxy_retry} proxy retries and {connection_retry} connection retries"
                        )
                    raise e
            except Exception as e:
                # Check if this is a proxy-related error and we're actually using a proxy
                if (
                    self._is_proxy_error(e)
                    and (
                        self.proxy or self.current_proxy_info
                    )  # Only retry if actually using a proxy
                    and (proxy_pool_manager or proxy_manager)
                    and proxy_retry < self.max_proxy_retries
                ):
                    proxy_retry += 1
                    logger.warning(
                        f"Proxy-related error (attempt {proxy_retry}/{self.max_proxy_retries}): {e}"
                    )

                    try:
                        await self._recreate_ctx_with_new_proxy()
                        continue
                    except Exception as proxy_exc:
                        logger.warning(f"Failed to recreate context with new proxy: {proxy_exc}")
                        # Fall through to original unknown retry logic

                # Original unknown error retry logic
                unknown_retry += 1
                if unknown_retry >= 3:
                    msg = [
                        "Unknown error. Account timeouted for 15 minutes.",
                        "Create issue please: https://github.com/vladkens/twscrape/issues",
                        f"If it mistake, you can unlock accounts with `twscrape reset_locks`. Err: {type(e)}: {e}",
                    ]

                    logger.warning(" ".join(msg))
                    await self._close_ctx(utc.ts() + 60 * 15)  # 15 minutes
                    raise HandledError()

                logger.warning(f"Unknown error (retrying): {type(e)}: {e}")
                await asyncio.sleep(1)  # wait a bit before retry
