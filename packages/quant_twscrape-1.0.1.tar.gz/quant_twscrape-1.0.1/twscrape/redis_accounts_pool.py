import ast
import asyncio
import json
import os
import time
from datetime import datetime, timedelta, timezone
from typing import Any, TypedDict

try:
    import redis.asyncio as aioredis
except Exception:  # pragma: no cover
    aioredis = None  # type: ignore

from fake_useragent import UserAgent
from httpx import HTTPStatusError

from .account import Account
from .logger import logger
from .login import LoginConfig, login
from .utils import get_env_bool, parse_cookies, utc


class NoAccountError(Exception):
    pass


class AccountInfo(TypedDict, total=False):
    username: str
    logged_in: bool
    active: bool
    last_used: datetime | None
    total_req: int
    error_msg: str | None
    stats: dict[str, int] | None


def _env(name: str, default: str | None = None) -> str | None:
    v = os.getenv(name)
    return v if v not in (None, "") else default


def _now_iso() -> str:
    return utc.now().isoformat()


def _from_iso_or_none(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        return utc.from_iso(value)
    except Exception:
        return None


class RedisAccountsPool:
    _order_by: str = "username"

    def __init__(
        self,
        db_file: str = "accounts.db",  # kept for signature compatibility
        login_config: LoginConfig | None = None,
        raise_when_no_account: bool = False,
    ):
        if aioredis is None:
            raise RuntimeError("redis.asyncio is required. Install with `pip install redis>=5`")

        self._login_config = login_config or LoginConfig()
        self._raise_when_no_account = raise_when_no_account

        # Resolve Redis connection string. Prefer explicit env var, then treat db_file if it looks like URL
        redis_url = (
            _env("TWS_REDIS_URL")
            or _env("REDIS_URL")
            or (db_file if db_file.startswith("redis://") else None)
            or None
        )
        self._r = aioredis.from_url(redis_url, decode_responses=True)

        # Key namespace
        self._k_accounts_all = "tws:acc:all"
        self._k_accounts_active = "tws:acc:active"

    # -------------------------
    # Helpers for (de)serialization
    # -------------------------
    def _acc_key(self, username: str) -> str:
        return f"tws:acc:{username}"

    @staticmethod
    def _acc_to_redis_doc(account: Account) -> dict[str, str]:
        # Store JSON strings for complex fields; primitives as strings
        locks_epoch: dict[str, int] = {}
        for k, v in (account.locks or {}).items():
            try:
                locks_epoch[k] = int(v.timestamp())
            except Exception:
                pass
        # Fast flag for logged-in state to avoid parsing full headers later
        try:
            has_auth_flag = "1" if (account.headers or {}).get("authorization") else "0"
        except Exception:
            has_auth_flag = "0"
        return {
            "username": account.username,
            "password": account.password,
            "email": account.email,
            "email_password": account.email_password,
            "user_agent": account.user_agent,
            "active": "1" if account.active else "0",
            "locks": json.dumps({k: v.isoformat() for k, v in (account.locks or {}).items()}),
            "locks_epoch": json.dumps(locks_epoch),
            "stats": json.dumps(account.stats or {}),
            "headers": json.dumps(account.headers or {}),
            "cookies": json.dumps(account.cookies or {}),
            "mfa_code": account.mfa_code or "",
            "proxy": account.proxy or "",
            "error_msg": account.error_msg or "",
            "last_used": account.last_used.isoformat() if account.last_used else "",
            "total_req": str(account.total_req or 0),
            "has_auth": has_auth_flag,
        }

    @staticmethod
    def _redis_doc_to_acc(doc: dict[str, str]) -> Account:
        locks_raw = json.loads(doc.get("locks", "{}"))
        locks: dict[str, datetime] = {
            k: utc.from_iso(v) for k, v in locks_raw.items() if isinstance(v, str)
        }
        stats = json.loads(doc.get("stats", "{}"))
        headers = json.loads(doc.get("headers", "{}"))
        cookies = json.loads(doc.get("cookies", "{}"))
        last_used = _from_iso_or_none(doc.get("last_used") or None)
        return Account(
            username=doc["username"],
            password=doc.get("password", ""),
            email=doc.get("email", ""),
            email_password=doc.get("email_password", ""),
            user_agent=doc.get("user_agent", UserAgent().safari),
            active=(doc.get("active", "0") == "1"),
            locks=locks,
            stats={
                k: int(v)
                for k, v in stats.items()
                if isinstance(v, (int, float)) or str(v).isdigit()
            },
            headers=headers,
            cookies=cookies,
            mfa_code=(doc.get("mfa_code") or None),
            proxy=(doc.get("proxy") or None),
            error_msg=(doc.get("error_msg") or None),
            last_used=last_used,
            _tx=None,
            total_req=int(doc.get("total_req", "0")),
        )

    async def _get_doc(self, username: str) -> dict[str, str] | None:
        k = self._acc_key(username)
        doc = await self._r.hgetall(k)
        return doc or None

    # -------------------------
    # Public API (compatible with AccountsPool)
    # -------------------------
    async def load_from_file(self, filepath: str, line_format: str):
        def guess_delim(line: str):
            lp, rp = tuple([x.strip() for x in line.split("username")])
            return rp[0] if not lp else lp[-1]

        line_delim = guess_delim(line_format)
        tokens = line_format.split(line_delim)

        required = set(["username", "password", "email", "email_password"])
        if not required.issubset(tokens):
            raise ValueError(f"Invalid line format: {line_format}")

        accounts = []
        with open(filepath, "r") as f:
            lines = f.read().split("\n")
            lines = [x.strip() for x in lines if x.strip()]

            for line in lines:
                data = [x.strip() for x in line.split(line_delim)]
                if len(data) < len(tokens):
                    raise ValueError(f"Invalid line: {line}")

                data = data[: len(tokens)]
                vals = {k: v for k, v in zip(tokens, data) if k != "_"}
                accounts.append(vals)

        for x in accounts:
            await self.add_account(**x)

    async def add_account(
        self,
        username: str,
        password: str,
        email: str,
        email_password: str,
        user_agent: str | None = None,
        proxy: str | None = None,
        cookies: Any | None = None,
        mfa_code: str | None = None,
    ):
        # Parse cookies from input: accept JSON or raw Cookie header format
        cookies_dict: dict[str, str] = {}
        if cookies:
            try:
                if isinstance(cookies, dict):
                    cookies_dict = {str(k): str(v) for k, v in cookies.items()}
                elif isinstance(cookies, str):
                    # Try JSON first
                    parsed = None
                    try:
                        parsed = json.loads(cookies)
                    except Exception:
                        # Fallback to Python literal (single quotes)
                        try:
                            parsed = ast.literal_eval(cookies)
                        except Exception:
                            parsed = None
                    if isinstance(parsed, dict):
                        cookies_dict = {str(k): str(v) for k, v in parsed.items()}
                    else:
                        cookies_dict = parse_cookies(cookies)
                else:
                    # Unknown format; try generic parser
                    cookies_dict = parse_cookies(str(cookies))
            except Exception:
                # Final fallback: treat as cookie header string
                cookies_dict = parse_cookies(str(cookies))

        # Check if account already exists
        existing_account = await self.get_account(username)
        if existing_account:
            # Update existing account: set active=True and update cookies if provided
            logger.info(f"Account {username} already exists, updating to active=True")
            existing_account.active = True
            if cookies_dict:
                existing_account.cookies = cookies_dict
            if "ct0" in existing_account.cookies:
                existing_account.active = True
            await self.save(existing_account)
            logger.info(
                f"Account {username} updated successfully (active={existing_account.active})"
            )
            return

        # Create new account
        account = Account(
            username=username,
            password=password,
            email=email,
            email_password=email_password,
            user_agent=user_agent or UserAgent().safari,
            active=False,
            locks={},
            stats={},
            headers={},
            cookies=cookies_dict,
            proxy=proxy,
            mfa_code=mfa_code,
        )

        if "ct0" in account.cookies:
            account.active = True

        await self.save(account)
        logger.info(f"Account {username} added successfully (active={account.active})")

    async def delete_accounts(self, usernames: str | list[str]):
        usernames = usernames if isinstance(usernames, list) else [usernames]
        usernames = list(set(usernames))
        if not usernames:
            logger.warning("No usernames provided")
            return

        pipe = self._r.pipeline()
        for u in usernames:
            pipe.delete(self._acc_key(u))
            pipe.srem(self._k_accounts_all, u)
            pipe.srem(self._k_accounts_active, u)
        await pipe.execute()

    async def delete_inactive(self):
        all_users = await self._r.smembers(self._k_accounts_all)
        pipe = self._r.pipeline()
        for u in all_users:
            doc = await self._get_doc(u)
            if not doc:
                continue
            if doc.get("active", "0") != "1":
                pipe.delete(self._acc_key(u))
                pipe.srem(self._k_accounts_all, u)
                pipe.srem(self._k_accounts_active, u)
        await pipe.execute()

    async def get(self, username: str):
        doc = await self._get_doc(username)
        if not doc:
            raise ValueError(f"Account {username} not found")
        return self._redis_doc_to_acc(doc)

    async def get_all(self):
        # Optimized: pipeline HGETALL in batches to construct full Account objects
        all_users = await self._r.smembers(self._k_accounts_all)
        if not all_users:
            return []

        accounts: list[Account] = []
        batch_size = 500
        all_users_list = list(all_users)
        for i in range(0, len(all_users_list), batch_size):
            batch_users = all_users_list[i : i + batch_size]
            pipe = self._r.pipeline()
            for u in batch_users:
                pipe.hgetall(self._acc_key(u))
            try:
                batch_docs = await pipe.execute()
            except Exception:
                batch_docs = await asyncio.gather(
                    *[self._get_doc(u) for u in batch_users],
                    return_exceptions=True,
                )
            for doc in batch_docs:
                if isinstance(doc, Exception) or not doc:
                    continue
                try:
                    accounts.append(self._redis_doc_to_acc(doc))
                except Exception:
                    continue
        return accounts

    async def get_account(self, username: str):
        doc = await self._get_doc(username)
        if not doc:
            return None
        return self._redis_doc_to_acc(doc)

    async def get_stats_bulk(self, usernames: list[str]) -> dict[str, dict[str, int]]:
        if not usernames:
            return {}
        result: dict[str, dict[str, int]] = {}
        batch_size = 500
        for i in range(0, len(usernames), batch_size):
            batch = usernames[i : i + batch_size]
            pipe = self._r.pipeline()
            for u in batch:
                pipe.hmget(self._acc_key(u), "stats")
            try:
                rows = await pipe.execute()
            except Exception:
                rows = await asyncio.gather(
                    *[self._r.hmget(self._acc_key(u), "stats") for u in batch],
                    return_exceptions=True,
                )
            for u, vals in zip(batch, rows):
                if isinstance(vals, Exception) or not vals:
                    result[u] = {}
                    continue
                stats_raw = vals[0] if isinstance(vals, (list, tuple)) else None
                if not stats_raw:
                    result[u] = {}
                    continue
                try:
                    parsed = json.loads(stats_raw)
                    # coerce to dict[str,int]
                    result[u] = {
                        str(k): int(v)
                        for k, v in parsed.items()
                        if isinstance(v, (int, float)) or str(v).isdigit()
                    }
                except Exception:
                    result[u] = {}
        return result

    async def save(self, account: Account):
        k = self._acc_key(account.username)
        doc = self._acc_to_redis_doc(account)
        pipe = self._r.pipeline()
        pipe.hset(k, mapping=doc)
        pipe.sadd(self._k_accounts_all, account.username)
        if account.active:
            pipe.sadd(self._k_accounts_active, account.username)
        else:
            pipe.srem(self._k_accounts_active, account.username)
        await pipe.execute()

    async def login(self, account: Account):
        try:
            await login(account, cfg=self._login_config)
            logger.info(f"Logged in to {account.username} successfully")
            return True
        except HTTPStatusError as e:
            rep = e.response
            logger.error(f"Failed to login '{account.username}': {rep.status_code} - {rep.text}")
            return False
        except Exception as e:
            logger.error(f"Failed to login '{account.username}': {e}")
            return False
        finally:
            await self.save(account)

    async def login_all(self, usernames: list[str] | None = None):
        if usernames is None:
            accounts = [x for x in await self.get_all() if not x.active and not x.error_msg]
        else:
            uniq = list({*usernames})
            accounts = []
            for u in uniq:
                acc = await self.get_account(u)
                if acc:
                    accounts.append(acc)

        counter = {"total": len(accounts), "success": 0, "failed": 0}
        for i, x in enumerate(accounts, start=1):
            logger.info(f"[{i}/{len(accounts)}] Logging in {x.username} - {x.email}")
            status = await self.login(x)
            counter["success" if status else "failed"] += 1
        return counter

    async def relogin(self, usernames: str | list[str]):
        usernames = usernames if isinstance(usernames, list) else [usernames]
        usernames = list(set(usernames))
        if not usernames:
            logger.warning("No usernames provided")
            return

        for u in usernames:
            acc = await self.get_account(u)
            if not acc:
                continue
            acc.active = False
            acc.locks = {}
            acc.last_used = None
            acc.error_msg = None
            acc.headers = {}
            acc.cookies = {}
            acc.user_agent = UserAgent().safari
            await self.save(acc)

        await self.login_all(usernames)

    async def relogin_failed(self):
        all_users = await self._r.smembers(self._k_accounts_all)
        failed = []
        for u in all_users:
            doc = await self._get_doc(u)
            if doc and doc.get("active", "0") == "0" and (doc.get("error_msg") or ""):
                failed.append(u)
        await self.relogin(failed)

    async def reset_locks(self):
        all_users = await self._r.smembers(self._k_accounts_all)
        for u in all_users:
            doc = await self._get_doc(u)
            if not doc:
                continue
            acc = self._redis_doc_to_acc(doc)
            acc.locks = {}
            await self.save(acc)

    async def set_active(self, username: str, active: bool):
        doc = await self._get_doc(username)
        if not doc:
            return
        doc["active"] = "1" if active else "0"
        await self._r.hset(self._acc_key(username), mapping=doc)
        if active:
            await self._r.sadd(self._k_accounts_active, username)
        else:
            await self._r.srem(self._k_accounts_active, username)

    async def lock_until(self, username: str, queue: str, unlock_at: int, req_count=0):
        doc = await self._get_doc(username)
        if not doc:
            return
        acc = self._redis_doc_to_acc(doc)
        acc.locks[queue] = datetime.fromtimestamp(unlock_at, tz=timezone.utc)
        acc.stats[queue] = int(acc.stats.get(queue, 0)) + int(req_count)
        acc.last_used = utc.now()
        await self.save(acc)

    async def unlock(self, username: str, queue: str, req_count=0):
        doc = await self._get_doc(username)
        if not doc:
            return
        acc = self._redis_doc_to_acc(doc)
        if queue in acc.locks:
            acc.locks.pop(queue, None)
        acc.stats[queue] = int(acc.stats.get(queue, 0)) + int(req_count)
        acc.last_used = utc.now()
        await self.save(acc)

    async def _try_lock_account(self, username: str, queue: str) -> bool:
        # Optimistic, atomic check+set via Lua to avoid races
        script = """
        local key = KEYS[1]
        local queue = ARGV[1]
        local now = tonumber(ARGV[2])
        local until_ts = tonumber(ARGV[3])
        local locks = redis.call('HGET', key, 'locks')
        local locks_epoch = redis.call('HGET', key, 'locks_epoch')
        if not locks then locks = '{}' end
        if not locks_epoch then locks_epoch = '{}' end
        local obj = cjson.decode(locks)
        local obj_epoch = cjson.decode(locks_epoch)
        local cur_epoch = obj_epoch[queue]
        if (cur_epoch == nil) or (tonumber(cur_epoch) < now) then
          obj[queue] = ARGV[4]
          obj_epoch[queue] = until_ts
          redis.call('HSET', key, 'locks', cjson.encode(obj))
          redis.call('HSET', key, 'locks_epoch', cjson.encode(obj_epoch))
          redis.call('HSET', key, 'last_used', ARGV[5])
          return 1
        else
          return 0
        end
        """
        now = utc.ts()
        unlock_iso = (utc.now() + timedelta(minutes=15)).isoformat()
        last_used_iso = _now_iso()
        try:
            res = await self._r.eval(
                script,
                1,
                self._acc_key(username),
                queue,
                str(now),
                str(now + 15 * 60),
                unlock_iso,
                last_used_iso,
            )
        except Exception:
            return False
        return bool(res)

    async def get_for_queue(self, queue: str):
        # Optimized approach: use Redis pipeline for batch operations
        active_users = list(await self._r.smembers(self._k_accounts_active))
        if not active_users:
            return None

        # Use smaller batches for better performance
        batch_size = 20
        now_ts = utc.ts()

        for i in range(0, len(active_users), batch_size):
            batch_users = active_users[i : i + batch_size]

            # Use Redis pipeline to get multiple docs at once
            pipe = self._r.pipeline()
            for u in batch_users:
                pipe.hgetall(self._acc_key(u))

            try:
                batch_docs = await pipe.execute()
            except Exception:
                # Fallback to individual requests if pipeline fails
                batch_docs = await asyncio.gather(
                    *[self._get_doc(u) for u in batch_users], return_exceptions=True
                )

            # Check each account in the batch
            for u, doc in zip(batch_users, batch_docs):
                if isinstance(doc, Exception) or not doc:
                    continue

                # Quick check if account is available (no lock or expired lock)
                locks_epoch_str = doc.get("locks_epoch", "{}")
                try:
                    locks_epoch = json.loads(locks_epoch_str)
                    queue_lock_epoch = locks_epoch.get(queue)

                    # If no lock or lock expired, try to acquire it
                    if queue_lock_epoch is None or queue_lock_epoch < now_ts:
                        if await self._try_lock_account(u, queue):
                            # Reload and return updated account with lock set
                            doc2 = await self._get_doc(u)
                            return self._redis_doc_to_acc(doc2) if doc2 else None
                except (json.JSONDecodeError, TypeError):
                    # If locks_epoch is malformed, try to acquire anyway
                    if await self._try_lock_account(u, queue):
                        doc2 = await self._get_doc(u)
                        return self._redis_doc_to_acc(doc2) if doc2 else None

        return None

    async def get_for_queue_or_wait(self, queue: str) -> Account | None:
        msg_shown = False
        max_wait_iterations = 3 if self._raise_when_no_account else 100

        for iteration in range(max_wait_iterations):
            account = await self.get_for_queue(queue)
            if account:
                if msg_shown:
                    logger.info(f"Continuing with account {account.username} on queue {queue}")
                return account

            if self._raise_when_no_account or get_env_bool("TWS_RAISE_WHEN_NO_ACCOUNT"):
                if iteration >= 2:
                    logger.warning(f"No account available for queue {queue} - failing fast")
                    raise NoAccountError(f"No account available for queue {queue}")

            if not msg_shown:
                nat = await self.next_available_at(queue)
                if not nat:
                    logger.warning("No active accounts. Stopping...")
                    return None

                msg = f'No account available for queue "{queue}". Next available at {nat}'
                logger.info(msg)
                msg_shown = True

            await asyncio.sleep(1 if self._raise_when_no_account else 5)

        return None

    async def next_available_at(self, queue: str):
        active_users = list(await self._r.smembers(self._k_accounts_active))
        if not active_users:
            return None
        min_lock: datetime | None = None
        now = utc.now()
        for u in active_users:
            doc = await self._get_doc(u)
            if not doc:
                continue
            acc = self._redis_doc_to_acc(doc)
            lock_at = acc.locks.get(queue)
            if lock_at and lock_at > now:
                if (min_lock is None) or (lock_at < min_lock):
                    min_lock = lock_at
        if min_lock is None:
            return None
        if min_lock < now:
            return "now"
        at_local = datetime.now() + (min_lock - now)
        return at_local.strftime("%H:%M:%S")

    async def mark_inactive(self, username: str, error_msg: str | None):
        doc = await self._get_doc(username)
        if not doc:
            return
        doc["active"] = "0"
        doc["error_msg"] = error_msg or ""
        await self._r.hset(self._acc_key(username), mapping=doc)
        await self._r.srem(self._k_accounts_active, username)

    async def stats(self):
        active_users = list(await self._r.smembers(self._k_accounts_active))
        all_users = list(await self._r.smembers(self._k_accounts_all))

        # Collect queues from locks
        queues: set[str] = set()
        for u in all_users:
            doc = await self._get_doc(u)
            if not doc:
                continue
            try:
                locks = json.loads(doc.get("locks", "{}"))
                queues.update(list(locks.keys()))
            except Exception:
                pass

        def is_locked(doc: dict[str, str], q: str) -> bool:
            try:
                locks = json.loads(doc.get("locks", "{}"))
                v = locks.get(q)
                return bool(v) and utc.from_iso(v) > utc.now()
            except Exception:
                return False

        locked_counts: dict[str, int] = {f"locked_{q}": 0 for q in queues}
        for u in all_users:
            doc = await self._get_doc(u)
            if not doc:
                continue
            for q in queues:
                if is_locked(doc, q):
                    locked_counts[f"locked_{q}"] += 1

        res = {
            "total": len(all_users),
            "active": len(active_users),
            "inactive": len(all_users) - len(active_users),
            **locked_counts,
        }
        return res

    async def accounts_info(self, include_stats: bool = False):
        # Get all usernames efficiently
        all_users = await self._r.smembers(self._k_accounts_all)

        items: list[AccountInfo] = []

        # Process accounts in batches using Redis pipeline to reduce RTTs
        batch_size = 500
        all_users_list = list(all_users)
        # total_batches = (len(all_users_list) + batch_size - 1) // batch_size
        for i in range(0, len(all_users_list), batch_size):
            batch_users = all_users_list[i : i + batch_size]

            pipe = self._r.pipeline()
            for u in batch_users:
                # Only fetch the minimal subset of fields needed
                if include_stats:
                    pipe.hmget(
                        self._acc_key(u),
                        "active",
                        "last_used",
                        "total_req",
                        "error_msg",
                        "has_auth",
                        "stats",
                    )
                else:
                    pipe.hmget(
                        self._acc_key(u),
                        "active",
                        "last_used",
                        "total_req",
                        "error_msg",
                        "has_auth",
                    )
            try:
                batch_docs = await pipe.execute()
            except Exception:
                # Fallback to individual gets if pipeline fails
                if include_stats:
                    batch_docs = await asyncio.gather(
                        *[
                            self._r.hmget(
                                self._acc_key(u),
                                "active",
                                "last_used",
                                "total_req",
                                "error_msg",
                                "has_auth",
                                "stats",
                            )
                            for u in batch_users
                        ],
                        return_exceptions=True,
                    )
                else:
                    batch_docs = await asyncio.gather(
                        *[
                            self._r.hmget(
                                self._acc_key(u),
                                "active",
                                "last_used",
                                "total_req",
                                "error_msg",
                                "has_auth",
                            )
                            for u in batch_users
                        ],
                        return_exceptions=True,
                    )
                logger.info(
                    f"accounts_info: fallback gathered {len(batch_docs)} docs in {time.time()}s"
                )

            for u, vals in zip(batch_users, batch_docs):
                if isinstance(vals, Exception) or not vals:
                    continue

                if include_stats:
                    active, last_used, total_req, error_msg, has_auth, stats_raw = vals
                else:
                    active, last_used, total_req, error_msg, has_auth = vals
                try:
                    total_req_val = int(total_req or 0)
                except Exception:
                    total_req_val = 0

                item: AccountInfo = {
                    "username": u,
                    "logged_in": (has_auth == "1"),
                    "active": ((active == "1") if isinstance(active, str) else bool(active)),
                    "last_used": _from_iso_or_none(last_used),
                    "total_req": total_req_val,
                    "error_msg": (error_msg or "")[:60],
                }
                if include_stats:
                    try:
                        parsed_stats = json.loads(stats_raw or "{}")
                        item["stats"] = {
                            str(k): int(v)
                            for k, v in parsed_stats.items()
                            if isinstance(v, (int, float)) or str(v).isdigit()
                        }
                    except Exception:
                        item["stats"] = {}
                items.append(item)

        old_time = datetime(1970, 1, 1).replace(tzinfo=timezone.utc)
        items = sorted(items, key=lambda x: x["username"].lower())
        items = sorted(
            items,
            key=lambda x: (x["last_used"] or old_time if x["total_req"] > 0 else old_time),
            reverse=True,
        )
        items = sorted(items, key=lambda x: x["active"], reverse=True)
        return items
