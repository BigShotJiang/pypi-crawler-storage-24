"""
Redis-based account pool with queue architecture (v2).

Key improvements over v1:
- Hot pool for frequently used accounts (in-memory cache)
- Simple queue operations using Redis sorted sets (ZPOPMIN/ZADD)
- Rate limiting handled by QueueClient, not the pool
- No complex Lua scripts needed for basic operations
- Better performance under high load with multiple instances
"""

import asyncio
import json
import os
from datetime import datetime, timezone
from typing import Any, TypedDict

try:
    import redis.asyncio as aioredis
except Exception:  # pragma: no cover
    aioredis = None  # type: ignore

from fake_useragent import UserAgent
from httpx import HTTPStatusError

from .account import Account
from .logger import logger
from .login import LoginConfig, login
from .utils import get_env_bool, utc


class NoAccountError(Exception):
    pass


class AccountInfo(TypedDict, total=False):
    username: str
    logged_in: bool
    active: bool
    last_used: datetime | None
    total_req: int
    error_msg: str | None
    stats: dict[str, int] | None


def _env(name: str, default: str | None = None) -> str | None:
    v = os.getenv(name)
    return v if v not in (None, "") else default


def _from_iso_or_none(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        return utc.from_iso(value)
    except Exception:
        return None


class RedisAccountsPoolV2:
    _order_by: str = "username"

    def __init__(
        self,
        db_file: str = "accounts.db",  # kept for signature compatibility
        login_config: LoginConfig | None = None,
        raise_when_no_account: bool = False,
        hot_pool_size: int = 3,  # Number of accounts to prefetch per queue (reduced from 5 to 3 to lower connection usage)
    ):
        if aioredis is None:
            raise RuntimeError("redis.asyncio is required. Install with `pip install redis>=5`")

        self._login_config = login_config or LoginConfig()
        self._raise_when_no_account = raise_when_no_account

        # Allow hot pool size override via environment variable
        # Lower values = fewer connections per request, but more Redis round-trips
        # Higher values = more connections per request, but better cache hit rate
        # Recommended: 3-5 for balanced performance
        hot_pool_size_env = int(_env("TWS_HOT_POOL_SIZE", str(hot_pool_size)))
        self._hot_pool_size = max(1, hot_pool_size_env)  # Minimum 1 account

        # Resolve Redis connection string. Prefer explicit env var, then treat db_file if it looks like URL
        redis_url = (
            _env("TWS_REDIS_URL")
            or _env("REDIS_URL")
            or (db_file if db_file.startswith("redis://") else None)
            or None
        )

        # Configure connection pool for high-concurrency scenarios
        # Get max connections from env or use default of 300
        # Formula: max_connections = (expected_concurrent_requests × 0.3)
        # Default 300 assumes ~1000 concurrent requests per instance
        # socket_keepalive: Prevent idle connections from being dropped
        # decode_responses: Automatically decode Redis responses to strings
        max_connections = int(_env("TWS_REDIS_MAX_CONNECTIONS", "300"))

        # Timeout configuration (seconds)
        # socket_connect_timeout: Max time to establish connection to Redis
        # socket_timeout: Max time for socket read/write operations
        # These prevent indefinite hangs and connection pool exhaustion
        socket_connect_timeout = float(_env("TWS_REDIS_CONNECT_TIMEOUT", "5.0"))
        socket_timeout = float(_env("TWS_REDIS_SOCKET_TIMEOUT", "5.0"))

        self._r = aioredis.from_url(
            redis_url,
            decode_responses=True,
            max_connections=max_connections,
            socket_keepalive=True,
            socket_keepalive_options={},
            socket_connect_timeout=socket_connect_timeout,  # Connection timeout
            socket_timeout=socket_timeout,  # Read/write timeout
            retry_on_timeout=True,  # Retry on timeout instead of raising
        )

        logger.info(
            f"Redis connection pool initialized: max_connections={max_connections}, "
            f"hot_pool_size={self._hot_pool_size}, connect_timeout={socket_connect_timeout}s, "
            f"socket_timeout={socket_timeout}s"
        )

        # Key namespace
        self._k_accounts_all = "tws:acc:all"
        self._k_accounts_active = "tws:acc:active"

        # Hot pool: {queue_name: {username: Account}}
        # Accounts actively being used by this instance
        self._hot_pool: dict[str, dict[str, Account]] = {}

        # Per-queue locks to prevent concurrent refills from Redis
        # Critical: When hot pool is empty and 100 concurrent requests arrive,
        # only ONE should fetch from Redis while others wait for the result
        self._queue_locks: dict[str, asyncio.Lock] = {}

        # Cache of initialized queues to avoid redundant Redis EXISTS checks
        # Critical for high-traffic performance: prevents N Redis calls per second
        self._initialized_queues: set[str] = set()

    # -------------------------
    # Lifecycle Management
    # -------------------------
    async def close(self):
        """
        Cleanup method to return all hot pool accounts back to Redis.
        Should be called on graceful shutdown to prevent account loss.

        CRITICAL: Without this, accounts in hot pool are lost on instance shutdown!
        """
        if not self._hot_pool:
            return  # Nothing to clean up

        logger.info(
            f"Returning {sum(len(pool) for pool in self._hot_pool.values())} hot pool accounts to Redis"
        )

        # Return all accounts from all queues back to Redis
        for queue, accounts in self._hot_pool.items():
            for username in accounts:
                # Re-enqueue with current timestamp for immediate availability
                await self._enqueue_to_redis(queue, username, utc.ts())
                logger.debug(f"Returned account {username} to queue '{queue}'")

        # Clear hot pool
        self._hot_pool.clear()

        # Close Redis connection
        await self._r.aclose()
        logger.info("RedisAccountsPoolV2 closed successfully")

    async def __aenter__(self):
        """Async context manager entry"""
        return self

    async def __aexit__(self, _exc_type, _exc_val, _exc_tb):
        """Async context manager exit - ensures hot pool cleanup"""
        await self.close()
        return False  # Don't suppress exceptions

    # -------------------------
    # Helpers for (de)serialization
    # -------------------------
    def _acc_key(self, username: str) -> str:
        return f"tws:acc:{username}"

    def _queue_key(self, queue: str) -> str:
        """Get Redis key for queue sorted set"""
        return f"tws:queue:{queue}"

    def _get_queue_lock(self, queue: str) -> asyncio.Lock:
        """
        Get or create a lock for a specific queue (lazy initialization).
        Prevents race conditions when multiple concurrent requests try to refill
        the same empty hot pool simultaneously.
        """
        if queue not in self._queue_locks:
            self._queue_locks[queue] = asyncio.Lock()
        return self._queue_locks[queue]

    @staticmethod
    def _acc_to_redis_doc(account: Account) -> dict[str, str]:
        """Convert Account object to Redis hash document"""
        # Note: We no longer store locks in account doc (they're in queues)
        # But keep locks field for backward compatibility
        locks_epoch: dict[str, int] = {}
        for k, v in (account.locks or {}).items():
            try:
                locks_epoch[k] = int(v.timestamp())
            except Exception:
                pass

        # Fast flag for logged-in state
        try:
            has_auth_flag = "1" if (account.headers or {}).get("authorization") else "0"
        except Exception:
            has_auth_flag = "0"

        return {
            "username": account.username,
            "password": account.password,
            "email": account.email,
            "email_password": account.email_password,
            "user_agent": account.user_agent,
            "active": "1" if account.active else "0",
            "locks": json.dumps({k: v.isoformat() for k, v in (account.locks or {}).items()}),
            "locks_epoch": json.dumps(locks_epoch),
            "stats": json.dumps(account.stats or {}),
            "headers": json.dumps(account.headers or {}),
            "cookies": json.dumps(account.cookies or {}),
            "mfa_code": account.mfa_code or "",
            "proxy": account.proxy or "",
            "error_msg": account.error_msg or "",
            "last_used": account.last_used.isoformat() if account.last_used else "",
            "total_req": str(account.total_req or 0),
            "has_auth": has_auth_flag,
        }

    @staticmethod
    def _redis_doc_to_acc(doc: dict[str, str]) -> Account:
        """Convert Redis hash document to Account object"""
        locks_raw = json.loads(doc.get("locks", "{}"))
        locks: dict[str, datetime] = {
            k: utc.from_iso(v) for k, v in locks_raw.items() if isinstance(v, str)
        }
        stats = json.loads(doc.get("stats", "{}"))
        headers = json.loads(doc.get("headers", "{}"))
        cookies = json.loads(doc.get("cookies", "{}"))
        last_used = _from_iso_or_none(doc.get("last_used") or None)
        return Account(
            username=doc["username"],
            password=doc.get("password", ""),
            email=doc.get("email", ""),
            email_password=doc.get("email_password", ""),
            user_agent=doc.get("user_agent", UserAgent().safari),
            active=(doc.get("active", "0") == "1"),
            locks=locks,
            stats={
                k: int(v)
                for k, v in stats.items()
                if isinstance(v, (int, float)) or str(v).isdigit()
            },
            headers=headers,
            cookies=cookies,
            mfa_code=(doc.get("mfa_code") or None),
            proxy=(doc.get("proxy") or None),
            error_msg=(doc.get("error_msg") or None),
            last_used=last_used,
            _tx=None,
            total_req=int(doc.get("total_req", "0")),
        )

    async def _get_doc(self, username: str) -> dict[str, str] | None:
        k = self._acc_key(username)
        doc = await self._r.hgetall(k)
        return doc or None

    # -------------------------
    # Queue Operations (NEW in v2)
    # -------------------------
    async def init_queue(self, queue: str):
        """
        Initialize queue with all active accounts.
        Called once per endpoint or when adding new accounts.
        Sets all accounts to score=0 (immediately available).
        """
        active_users = await self._r.smembers(self._k_accounts_active)
        if not active_users:
            logger.warning(f"No active accounts to initialize queue '{queue}'")
            return

        # Add all active accounts with score=0 (available now)
        mapping = {user: 0 for user in active_users}
        await self._r.zadd(self._queue_key(queue), mapping)

        # Mark as initialized in cache
        self._initialized_queues.add(queue)

        logger.info(f"✓ Initialized queue '{queue}' with {len(active_users)} accounts")

    async def _ensure_queue_initialized(self, queue: str):
        """
        Auto-initialize queue if it doesn't exist (idempotent).
        Uses in-memory cache to avoid redundant Redis EXISTS checks under high traffic.
        """
        # Fast path: check in-memory cache first (no Redis call)
        if queue in self._initialized_queues:
            return

        # Slow path: check Redis only if not in cache
        exists = await self._r.exists(self._queue_key(queue))
        if not exists:
            logger.debug(f"Queue '{queue}' does not exist, initializing...")
            await self.init_queue(queue)
        else:
            # Queue exists in Redis but not in cache (e.g., created by another instance)
            self._initialized_queues.add(queue)
            logger.debug(f"Queue '{queue}' already exists, added to cache")

    async def _dequeue_from_redis(self, queue: str, count: int = 1) -> list[Account]:
        """
        Atomically pop up to 'count' accounts from Redis queue if available.
        Uses ZPOPMIN for race-free operation across multiple instances.
        Returns list of ready accounts (may be fewer than requested).
        """
        now = utc.ts()

        # Atomic pop of accounts with lowest scores
        results = await self._r.zpopmin(self._queue_key(queue), count)

        if not results:
            logger.debug(f"Queue '{queue}' is empty in Redis (no accounts to dequeue)")
            return []  # Queue empty

        logger.debug(
            f"Dequeued {len(results)} accounts from Redis queue '{queue}': {[u for u, _ in results]}"
        )

        ready_accounts: list[Account] = []
        not_ready: dict[str, float] = {}

        # Separate ready and not-ready accounts
        ready_usernames: list[str] = []
        for username, score in results:
            if score > now:
                # Not ready yet, will put it back
                not_ready[username] = score
                logger.debug(
                    f"Account {username} not ready yet (cooling), putting back to queue '{queue}'"
                )
            else:
                ready_usernames.append(username)

        # Load all ready accounts using pipeline (single connection instead of N connections)
        if ready_usernames:
            # Use pipeline to batch all HGETALL operations into single connection
            # This reduces connection usage from N to 1 (critical for high concurrency)
            pipe = self._r.pipeline()
            for username in ready_usernames:
                pipe.hgetall(self._acc_key(username))

            try:
                account_docs = await pipe.execute()
            except Exception as e:
                logger.error(
                    f"Error loading accounts in batch: {type(e).__name__}: {e}",
                    exc_info=True,
                )
                # Fallback to individual loads if pipeline fails
                account_tasks = [self.get_account(username) for username in ready_usernames]
                accounts = await asyncio.gather(*account_tasks, return_exceptions=True)
            else:
                # Convert docs to Account objects
                accounts = []
                for doc in account_docs:
                    if not doc:
                        accounts.append(None)
                    else:
                        try:
                            accounts.append(self._redis_doc_to_acc(doc))
                        except Exception as e:
                            accounts.append(e)

            for username, account in zip(ready_usernames, accounts):
                if isinstance(account, Exception):
                    # Only retry on transient exceptions (network, timeout)
                    # Don't retry on permanent errors to prevent infinite loops
                    logger.error(
                        f"Error loading account {username}: {type(account).__name__}: {account}",
                        exc_info=True,
                    )
                    if isinstance(account, (asyncio.TimeoutError, ConnectionError)):
                        logger.warning(
                            f"Transient error for account {username}, returning to queue for retry"
                        )
                        not_ready[username] = 0  # Return to queue with score=0 for immediate retry
                    else:
                        logger.warning(
                            f"Permanent error for account {username}, removing from active set"
                        )
                        # Remove from active set to prevent requeuing
                        await self._r.srem(self._k_accounts_active, username)
                    continue
                if not account:
                    # Account doesn't exist - remove from active set to prevent infinite loop
                    logger.warning(
                        f"Account {username} not found during dequeue, removing from active set "
                        f"to prevent infinite loop"
                    )
                    await self._r.srem(self._k_accounts_active, username)
                    continue
                if not account.active:
                    # Re-add inactive account to queue so mark_inactive() can properly clean it up
                    # This prevents account orphaning when dequeue happens during mark_inactive()
                    logger.warning(
                        f"Account {username} is inactive during dequeue, "
                        f"re-adding to queue '{queue}' with score=0 for proper cleanup"
                    )
                    not_ready[username] = 0  # Add to not_ready dict to be re-added to queue
                    continue
                ready_accounts.append(account)

        # Put back not-ready accounts in a single batch operation
        if not_ready:
            await self._r.zadd(self._queue_key(queue), not_ready)

        logger.info(
            f"✓ Dequeued {len(ready_accounts)} ready accounts for queue '{queue}': {[a.username for a in ready_accounts]}"
        )
        return ready_accounts

    async def _enqueue_to_redis(self, queue: str, username: str, available_at: int):
        """Add account to Redis queue with availability timestamp"""
        await self._r.zadd(self._queue_key(queue), {username: available_at})

    async def _update_account_stats(self, username: str, queue: str, req_count: int):
        """
        Update account stats and last_used timestamp efficiently.
        Uses atomic operations to avoid full read-modify-write cycle.
        Reduces from 2 Redis operations to 1 pipeline.
        """
        if req_count <= 0:
            return

        acc_key = self._acc_key(username)

        # Use Lua script for atomic stats update (single round-trip)
        # This is more efficient than read-modify-write cycle
        script = """
        local acc_key = KEYS[1]
        local queue = ARGV[1]
        local req_count = tonumber(ARGV[2])
        local timestamp = ARGV[3]

        -- Check if account exists
        if redis.call('EXISTS', acc_key) == 0 then
            return 0
        end

        -- Get current stats JSON
        local stats_json = redis.call('HGET', acc_key, 'stats')
        local stats = {}
        if stats_json and stats_json ~= '' then
            stats = cjson.decode(stats_json)
        end

        -- Update queue stats
        stats[queue] = (stats[queue] or 0) + req_count

        -- Get current total_req
        local total_req = tonumber(redis.call('HGET', acc_key, 'total_req') or 0)

        -- Update account fields atomically
        redis.call('HSET', acc_key,
            'stats', cjson.encode(stats),
            'last_used', timestamp,
            'total_req', tostring(total_req + req_count)
        )

        return 1
        """

        try:
            await self._r.eval(
                script,
                1,  # number of keys
                acc_key,  # KEYS[1]
                queue,  # ARGV[1]
                str(req_count),  # ARGV[2]
                utc.now().isoformat(),  # ARGV[3]
            )
        except Exception as e:
            logger.warning(
                f"Failed to update stats atomically for {username}, falling back to read-modify-write: {e}"
            )
            # Fallback to original method if Lua script fails
            doc = await self._get_doc(username)
            if not doc:
                return

            acc = self._redis_doc_to_acc(doc)
            acc.stats[queue] = int(acc.stats.get(queue, 0)) + int(req_count)
            acc.last_used = utc.now()
            acc.total_req = int(acc.total_req or 0) + int(req_count)

            await self.save(acc)

    # -------------------------
    # Hot Pool Management (NEW in v2)
    # -------------------------
    async def _get_from_hot_pool(self, queue: str) -> Account | None:
        """Get and remove account from hot pool if available (no lock needed - sequential access per queue)"""
        pool = self._hot_pool.get(queue)
        if pool:
            # Pop and return first available account
            username = next(iter(pool))
            account = pool.pop(username)
            # Clean up empty queue entries
            if not pool:
                del self._hot_pool[queue]
            return account
        return None

    async def _add_to_hot_pool(self, queue: str, account: Account):
        """Add account to hot pool"""
        if queue not in self._hot_pool:
            self._hot_pool[queue] = {}
        self._hot_pool[queue][account.username] = account
        logger.debug(
            f"Added account {account.username} to hot pool for queue '{queue}' (hot pool size: {len(self._hot_pool[queue])})"
        )

    async def _remove_from_hot_pool(self, queue: str, username: str):
        """Remove account from hot pool"""
        if queue in self._hot_pool:
            was_present = username in self._hot_pool[queue]
            self._hot_pool[queue].pop(username, None)
            if was_present:
                logger.debug(
                    f"Removed account {username} from hot pool for queue '{queue}' (remaining: {len(self._hot_pool[queue])})"
                )
            # Clean up empty queue entries
            if not self._hot_pool[queue]:
                del self._hot_pool[queue]

    # -------------------------
    # Public API (called by QueueClient)
    # -------------------------
    async def get_for_queue(self, queue: str) -> Account | None:
        """
        Get account for queue (dequeue operation).
        First checks hot pool, then prefills from Redis if needed.

        Uses per-queue lock to prevent race conditions:
        - If 100 concurrent requests arrive, only 1 fetches from Redis
        - Others wait for the lock and then get accounts from hot pool
        """
        await self._ensure_queue_initialized(queue)

        # Fast path: Check hot pool first (no lock needed for reads)
        account = await self._get_from_hot_pool(queue)
        if account:
            logger.debug(f"✓ Got account {account.username} from hot pool for queue '{queue}'")
            return account

        # Hot pool is empty, need to refill from Redis
        # Use lock to prevent concurrent refills by multiple requests
        lock = self._get_queue_lock(queue)
        async with lock:
            # Double-check hot pool after acquiring lock
            # (another request might have refilled it while we were waiting)
            account = await self._get_from_hot_pool(queue)
            if account:
                logger.debug(
                    f"✓ Got account {account.username} from hot pool (after lock wait) for queue '{queue}'"
                )
                return account

            # Still empty, we're the first one - fetch from Redis
            logger.debug(
                f"Hot pool empty for queue '{queue}', fetching {self._hot_pool_size} accounts from Redis..."
            )
            accounts = await self._dequeue_from_redis(queue, self._hot_pool_size)
            if not accounts:
                logger.debug(f"No accounts available in Redis for queue '{queue}'")
                return None

            # Add all fetched accounts to hot pool (except the first one we'll return)
            for acc in accounts[1:]:
                await self._add_to_hot_pool(queue, acc)

            logger.info(
                f"✓ Returning account {accounts[0].username} for queue '{queue}' (cached {len(accounts) - 1} others in hot pool)"
            )
            # Return the first account
            return accounts[0]

    async def lock_until(self, username: str, queue: str, unlock_at: int, req_count=0):
        """
        Lock account until unlock_at timestamp (called by QueueClient on rate limit).
        Adds account to queue with future availability time and removes from hot pool.
        """
        cooldown_seconds = unlock_at - utc.ts()

        # Add to Redis queue with unlock time
        await self._enqueue_to_redis(queue, username, unlock_at)

        # Update stats
        await self._update_account_stats(username, queue, req_count)

        # Remove from hot pool (account is now cooling down)
        await self._remove_from_hot_pool(queue, username)

        logger.info(
            f"🔒 Account {username} locked on queue '{queue}' for {cooldown_seconds}s "
            f"(requests: {req_count}, available at: {unlock_at})"
        )

    async def unlock(self, username: str, queue: str, req_count=0):
        """
        Unlock account (called by QueueClient on normal completion).
        Returns account to hot pool for immediate local reuse (performance optimization).

        If hot pool is at capacity, returns account to Redis for fair distribution
        across instances. This prevents unbounded memory growth while maintaining
        high cache hit rate.
        """
        # Update stats
        await self._update_account_stats(username, queue, req_count)

        # Check hot pool capacity (allow 2x configured size for flexibility)
        max_hot_pool_size = self._hot_pool_size * 2
        current_hot_pool_size = len(self._hot_pool.get(queue, {}))

        if current_hot_pool_size >= max_hot_pool_size:
            # Hot pool is full, return to Redis for fair distribution
            await self._enqueue_to_redis(queue, username, utc.ts())
            logger.debug(
                f"♻️  Account {username} returned to Redis (hot pool at capacity: "
                f"{current_hot_pool_size}/{max_hot_pool_size})"
            )
        else:
            # Return account to hot pool for immediate reuse by this instance
            # This is the KEY optimization: avoid Redis round-trip for every request
            account = await self.get_account(username)
            if account and account.active:
                await self._add_to_hot_pool(queue, account)
                logger.debug(
                    f"🔄 Account {username} returned to hot pool for queue '{queue}' "
                    f"(requests: {req_count}, pool size: {current_hot_pool_size + 1}/{max_hot_pool_size})"
                )
            else:
                # Account was deactivated during request or not found
                if account and not account.active:
                    # Account became inactive - ensure it's properly cleaned up from all queues
                    logger.warning(
                        f"⚠️  Account {username} became inactive during use, "
                        f"triggering cleanup from all queues"
                    )
                    await self.mark_inactive(username, account.error_msg)
                else:
                    # Account doesn't exist - do NOT return to queue to prevent infinite loop
                    # Remove from active set to prevent it from being picked up again
                    logger.warning(
                        f"⚠️  Account {username} not found during unlock. "
                        f"Removing from active set to prevent infinite loop."
                    )
                    try:
                        # Remove from active set to prevent requeuing
                        await self._r.srem(self._k_accounts_active, username)
                        logger.info(f"Account {username} removed from active set")
                    except Exception as e:
                        logger.error(
                            f"Failed to remove missing account {username} from active set: {e}",
                            exc_info=True,
                        )

    async def get_for_queue_or_wait(self, queue: str) -> Account | None:
        """
        Get account for queue, waiting if none available.
        Used by QueueClient for automatic retry logic.
        """
        msg_shown = False
        max_wait_iterations = 3 if self._raise_when_no_account else 100

        for iteration in range(max_wait_iterations):
            account = await self.get_for_queue(queue)
            if account:
                if msg_shown:
                    logger.info(f"Continuing with account {account.username} on queue {queue}")
                return account

            if self._raise_when_no_account or get_env_bool("TWS_RAISE_WHEN_NO_ACCOUNT"):
                if iteration >= 2:
                    logger.warning(f"No account available for queue {queue} - failing fast")
                    raise NoAccountError(f"No account available for queue {queue}")

            # Check if queue has any accounts at all
            queue_size = await self._r.zcard(self._queue_key(queue))
            if queue_size == 0:
                logger.warning(f"Queue '{queue}' is empty. Stopping...")
                return None

            if not msg_shown:
                nat = await self.next_available_at(queue)
                if not nat:
                    logger.warning("No active accounts. Stopping...")
                    return None

                msg = f'No account available for queue "{queue}". Next available at {nat}'
                logger.info(msg)
                msg_shown = True

            await asyncio.sleep(1 if self._raise_when_no_account else 5)

        return None

    async def next_available_at(self, queue: str):
        """Get next available time for queue"""
        # Check hot pool first
        if queue in self._hot_pool and self._hot_pool[queue]:
            return "now"

        # Check Redis queue
        result = await self._r.zrange(self._queue_key(queue), 0, 0, withscores=True)

        if not result:
            return None

        username, score = result[0]
        now = utc.now()
        available_time = datetime.fromtimestamp(score, tz=timezone.utc)

        if available_time <= now:
            return "now"

        at_local = datetime.now() + (available_time - now)
        return at_local.strftime("%H:%M:%S")

    async def mark_inactive(self, username: str, error_msg: str | None):
        """
        Mark account as inactive and remove from all queues atomically.
        Called by QueueClient when account is banned/suspended.

        Uses Lua script to prevent race conditions where other instances
        might dequeue the account while we're removing it from queues.
        """
        # Remove from hot pool first (local operation, must be done before Lua script)
        for queue_name in list(self._hot_pool.keys()):
            self._hot_pool[queue_name].pop(username, None)

        # Atomic Lua script to:
        # 1. Set active="0" in account hash
        # 2. Remove from tws:acc:active set
        # 3. Scan and remove from all tws:queue:* keys
        # All operations are atomic to prevent race conditions
        script = """
        local username = ARGV[1]
        local error_msg = ARGV[2]
        local acc_key = 'tws:acc:' .. username

        -- Check if account exists
        if redis.call('EXISTS', acc_key) == 0 then
            return 0
        end

        -- Set account inactive atomically
        redis.call('HSET', acc_key, 'active', '0')
        redis.call('HSET', acc_key, 'error_msg', error_msg)

        -- Remove from active set
        redis.call('SREM', 'tws:acc:active', username)

        -- Find and remove from all queues atomically
        local cursor = '0'
        local removed_count = 0
        repeat
            local result = redis.call('SCAN', cursor, 'MATCH', 'tws:queue:*', 'COUNT', 100)
            cursor = result[1]
            local keys = result[2]
            for i, key in ipairs(keys) do
                local removed = redis.call('ZREM', key, username)
                removed_count = removed_count + removed
            end
        until cursor == '0'

        return removed_count
        """

        try:
            removed_count = await self._r.eval(script, 0, username, error_msg or "")
            logger.warning(
                f"Account {username} marked inactive atomically: {error_msg} "
                f"(removed from {removed_count} queues)"
            )
        except Exception as e:
            logger.error(f"Failed to mark {username} inactive atomically: {e}")
            # Fallback to non-atomic approach if Lua script fails
            logger.warning(f"Falling back to non-atomic mark_inactive for {username}")
            doc = await self._get_doc(username)
            if doc:
                doc["active"] = "0"
                doc["error_msg"] = error_msg or ""
                await self._r.hset(self._acc_key(username), mapping=doc)
                await self._r.srem(self._k_accounts_active, username)

                cursor = 0
                while True:
                    cursor, keys = await self._r.scan(cursor, match="tws:queue:*")
                    for key in keys:
                        await self._r.zrem(key, username)
                    if cursor == 0:
                        break

    # -------------------------
    # Account Management (unchanged from v1)
    # -------------------------
    async def load_from_file(self, filepath: str, line_format: str):
        def guess_delim(line: str):
            lp, rp = tuple([x.strip() for x in line.split("username")])
            return rp[0] if not lp else lp[-1]

        line_delim = guess_delim(line_format)
        tokens = line_format.split(line_delim)

        required = set(["username", "password", "email", "email_password"])
        if not required.issubset(tokens):
            raise ValueError(f"Invalid line format: {line_format}")

        accounts = []
        with open(filepath, "r") as f:
            lines = f.read().split("\n")
            lines = [x.strip() for x in lines if x.strip()]

            for line in lines:
                data = [x.strip() for x in line.split(line_delim)]
                if len(data) < len(tokens):
                    raise ValueError(f"Invalid line: {line}")

                data = data[: len(tokens)]
                vals = {k: v for k, v in zip(tokens, data) if k != "_"}
                accounts.append(vals)

        for x in accounts:
            await self.add_account(**x)

    async def add_account(
        self,
        username: str,
        password: str,
        email: str,
        email_password: str,
        user_agent: str | None = None,
        proxy: str | None = None,
        cookies: str | None = None,
        mfa_code: str | None = None,
    ):
        # Check if account already exists
        existing_account = await self.get_account(username)
        if existing_account:
            # Update existing account: set active=True and update cookies if provided
            logger.info(f"Account {username} already exists, updating to active=True")
            existing_account.active = True
            if cookies:
                # Handle cookies - could be dict or string
                if isinstance(cookies, dict):
                    existing_account.cookies = cookies
                elif isinstance(cookies, str):
                    try:
                        # Try parsing as JSON
                        existing_account.cookies = json.loads(cookies)
                    except json.JSONDecodeError:
                        # If not JSON, treat as dict string or keep existing
                        pass
            if "ct0" in existing_account.cookies:
                existing_account.active = True
            await self.save(existing_account)
            logger.info(
                f"Account {username} updated successfully (active={existing_account.active})"
            )

            # Auto-add to existing queues if active (optimized with pipeline)
            if existing_account.active:
                cursor = 0
                queue_keys = []
                # Collect all queue keys first
                while True:
                    cursor, keys = await self._r.scan(cursor, match="tws:queue:*", count=100)
                    queue_keys.extend(keys)
                    if cursor == 0:
                        break

                # Batch all ZADD operations in a single pipeline
                if queue_keys:
                    pipe = self._r.pipeline()
                    for key in queue_keys:
                        pipe.zadd(key, {username: 0})
                    await pipe.execute()
            return

        # Create new account
        account = Account(
            username=username,
            password=password,
            email=email,
            email_password=email_password,
            user_agent=user_agent or UserAgent().safari,
            active=False,
            locks={},
            stats={},
            headers={},
            cookies=cookies if cookies else {},
            proxy=proxy,
            mfa_code=mfa_code,
        )

        if "ct0" in account.cookies:
            account.active = True

        await self.save(account)
        logger.info(f"Account {username} added successfully (active={account.active})")

        # Auto-add to existing queues if active (optimized with pipeline)
        if account.active:
            cursor = 0
            queue_keys = []
            # Collect all queue keys first
            while True:
                cursor, keys = await self._r.scan(cursor, match="tws:queue:*", count=100)
                queue_keys.extend(keys)
                if cursor == 0:
                    break

            # Batch all ZADD operations in a single pipeline
            if queue_keys:
                pipe = self._r.pipeline()
                for key in queue_keys:
                    pipe.zadd(key, {username: 0})
                await pipe.execute()

    async def delete_accounts(self, usernames: str | list[str]):
        usernames = usernames if isinstance(usernames, list) else [usernames]
        usernames = list(set(usernames))
        if not usernames:
            logger.warning("No usernames provided")
            return

        pipe = self._r.pipeline()
        for u in usernames:
            pipe.delete(self._acc_key(u))
            pipe.srem(self._k_accounts_all, u)
            pipe.srem(self._k_accounts_active, u)
        await pipe.execute()

        # Remove from hot pool
        for queue_name in list(self._hot_pool.keys()):
            for u in usernames:
                self._hot_pool[queue_name].pop(u, None)

        # Remove from all queues
        cursor = 0
        while True:
            cursor, keys = await self._r.scan(cursor, match="tws:queue:*")
            for key in keys:
                await self._r.zrem(key, *usernames)
            if cursor == 0:
                break

    async def delete_inactive(self):
        all_users = await self._r.smembers(self._k_accounts_all)
        pipe = self._r.pipeline()
        for u in all_users:
            doc = await self._get_doc(u)
            if not doc:
                continue
            if doc.get("active", "0") != "1":
                pipe.delete(self._acc_key(u))
                pipe.srem(self._k_accounts_all, u)
                pipe.srem(self._k_accounts_active, u)
        await pipe.execute()

    async def get(self, username: str):
        doc = await self._get_doc(username)
        if not doc:
            raise ValueError(f"Account {username} not found")
        return self._redis_doc_to_acc(doc)

    async def get_all(self):
        all_users = await self._r.smembers(self._k_accounts_all)
        if not all_users:
            return []

        accounts: list[Account] = []
        batch_size = 500
        all_users_list = list(all_users)
        for i in range(0, len(all_users_list), batch_size):
            batch_users = all_users_list[i : i + batch_size]
            pipe = self._r.pipeline()
            for u in batch_users:
                pipe.hgetall(self._acc_key(u))
            try:
                batch_docs = await pipe.execute()
            except Exception:
                batch_docs = await asyncio.gather(
                    *[self._get_doc(u) for u in batch_users],
                    return_exceptions=True,
                )
            for doc in batch_docs:
                if isinstance(doc, Exception) or not doc:
                    continue
                try:
                    accounts.append(self._redis_doc_to_acc(doc))
                except Exception:
                    continue
        return accounts

    async def get_account(self, username: str):
        doc = await self._get_doc(username)
        if not doc:
            return None
        return self._redis_doc_to_acc(doc)

    async def get_stats_bulk(self, usernames: list[str]) -> dict[str, dict[str, int]]:
        if not usernames:
            return {}
        result: dict[str, dict[str, int]] = {}
        batch_size = 500
        for i in range(0, len(usernames), batch_size):
            batch = usernames[i : i + batch_size]
            pipe = self._r.pipeline()
            for u in batch:
                pipe.hmget(self._acc_key(u), "stats")
            try:
                rows = await pipe.execute()
            except Exception:
                rows = await asyncio.gather(
                    *[self._r.hmget(self._acc_key(u), "stats") for u in batch],
                    return_exceptions=True,
                )
            for u, vals in zip(batch, rows):
                if isinstance(vals, Exception) or not vals:
                    result[u] = {}
                    continue
                stats_raw = vals[0] if isinstance(vals, (list, tuple)) else None
                if not stats_raw:
                    result[u] = {}
                    continue
                try:
                    parsed = json.loads(stats_raw)
                    result[u] = {
                        str(k): int(v)
                        for k, v in parsed.items()
                        if isinstance(v, (int, float)) or str(v).isdigit()
                    }
                except Exception:
                    result[u] = {}
        return result

    async def save(self, account: Account):
        """
        Save account to Redis and maintain account sets.

        This function atomically:
        1. Saves account data as a hash
        2. Adds username to 'all accounts' set
        3. Adds/removes username from 'active accounts' set based on account.active
        """
        k = self._acc_key(account.username)
        doc = self._acc_to_redis_doc(account)
        pipe = self._r.pipeline()
        pipe.hset(k, mapping=doc)
        pipe.sadd(self._k_accounts_all, account.username)
        # Maintain active set: add if active, remove if inactive
        # Note: SADD/SREM are idempotent - safe to call even if member already exists/doesn't exist
        if account.active:
            pipe.sadd(self._k_accounts_active, account.username)
        else:
            pipe.srem(self._k_accounts_active, account.username)
        await pipe.execute()

    async def login(self, account: Account):
        try:
            await login(account, cfg=self._login_config)
            logger.info(f"Logged in to {account.username} successfully")
            return True
        except HTTPStatusError as e:
            rep = e.response
            logger.error(f"Failed to login '{account.username}': {rep.status_code} - {rep.text}")
            return False
        except Exception as e:
            logger.error(f"Failed to login '{account.username}': {e}")
            return False
        finally:
            await self.save(account)

    async def login_all(self, usernames: list[str] | None = None):
        if usernames is None:
            accounts = [x for x in await self.get_all() if not x.active and not x.error_msg]
        else:
            uniq = list({*usernames})
            accounts = []
            for u in uniq:
                acc = await self.get_account(u)
                if acc:
                    accounts.append(acc)

        counter = {"total": len(accounts), "success": 0, "failed": 0}
        for i, x in enumerate(accounts, start=1):
            logger.info(f"[{i}/{len(accounts)}] Logging in {x.username} - {x.email}")
            status = await self.login(x)
            counter["success" if status else "failed"] += 1
        return counter

    async def relogin(self, usernames: str | list[str]):
        usernames = usernames if isinstance(usernames, list) else [usernames]
        usernames = list(set(usernames))
        if not usernames:
            logger.warning("No usernames provided")
            return

        for u in usernames:
            acc = await self.get_account(u)
            if not acc:
                continue
            acc.active = False
            acc.locks = {}
            acc.last_used = None
            acc.error_msg = None
            acc.headers = {}
            acc.cookies = {}
            acc.user_agent = UserAgent().safari
            await self.save(acc)

        await self.login_all(usernames)

    async def relogin_failed(self):
        all_users = await self._r.smembers(self._k_accounts_all)
        failed = []
        for u in all_users:
            doc = await self._get_doc(u)
            if doc and doc.get("active", "0") == "0" and (doc.get("error_msg") or ""):
                failed.append(u)
        await self.relogin(failed)

    async def reset_locks(self):
        """Reset all locks (v2: clears all queues)"""
        all_users = await self._r.smembers(self._k_accounts_all)

        # Clear all queues
        cursor = 0
        while True:
            cursor, keys = await self._r.scan(cursor, match="tws:queue:*")
            for key in keys:
                await self._r.delete(key)
            if cursor == 0:
                break

        # Clear hot pool
        self._hot_pool.clear()

        # Clear locks in account data (for compatibility)
        for u in all_users:
            doc = await self._get_doc(u)
            if not doc:
                continue
            acc = self._redis_doc_to_acc(doc)
            acc.locks = {}
            await self.save(acc)

        logger.info("All locks and queues reset")

    async def set_active(self, username: str, active: bool):
        doc = await self._get_doc(username)
        if not doc:
            return
        doc["active"] = "1" if active else "0"
        await self._r.hset(self._acc_key(username), mapping=doc)
        if active:
            await self._r.sadd(self._k_accounts_active, username)
        else:
            await self._r.srem(self._k_accounts_active, username)

    # -------------------------
    # Stats & Monitoring
    # -------------------------
    async def stats(self, include_members: bool = False):
        """
        Enhanced stats with queue information

        Args:
            include_members: If True, include list of usernames in each queue

        Note:
            Hot pool stats are excluded because each instance maintains its own
            separate hot pool, making these metrics inconsistent across instances.
        """
        active_users = list(await self._r.smembers(self._k_accounts_active))
        all_users = list(await self._r.smembers(self._k_accounts_all))

        # Discover all queues
        cursor = 0
        queue_stats = {}
        while True:
            cursor, keys = await self._r.scan(cursor, match="tws:queue:*")
            for key in keys:
                queue_name = key.replace("tws:queue:", "")

                try:
                    # Check if the key is a sorted set (ZSET)
                    key_type = await self._r.type(key)
                    if key_type != "zset":
                        logger.warning(
                            f"Skipping key {key} - wrong type: {key_type} (expected zset)"
                        )
                        continue

                    count = await self._r.zcard(key)

                    # Count ready vs cooling down
                    now = utc.ts()
                    ready = await self._r.zcount(key, "-inf", now)

                    queue_data = {
                        "total": count,
                        "ready": ready,
                        "cooling": count - ready,
                    }

                    # Include member lists if requested
                    if include_members and count > 0:
                        # Get all members with scores
                        all_members = await self._r.zrange(key, 0, -1, withscores=True)

                        ready_members = []
                        cooling_members = []

                        for username, score in all_members:
                            if score <= now:
                                ready_members.append(username)
                            else:
                                cooling_members.append(username)

                        queue_data["members_ready"] = ready_members
                        queue_data["members_cooling"] = cooling_members

                    queue_stats[queue_name] = queue_data

                except Exception as e:
                    logger.warning(f"Error processing queue key {key}: {e}")
                    continue

            if cursor == 0:
                break

        return {
            "total": len(all_users),
            "active": len(active_users),
            "inactive": len(all_users) - len(active_users),
            "queues": queue_stats,
        }

    async def accounts_info(self, include_stats: bool = False):
        # Get all usernames efficiently
        all_users = await self._r.smembers(self._k_accounts_all)

        items: list[AccountInfo] = []

        # Process accounts in batches using Redis pipeline
        batch_size = 500
        all_users_list = list(all_users)
        for i in range(0, len(all_users_list), batch_size):
            batch_users = all_users_list[i : i + batch_size]

            pipe = self._r.pipeline()
            for u in batch_users:
                if include_stats:
                    pipe.hmget(
                        self._acc_key(u),
                        "active",
                        "last_used",
                        "total_req",
                        "error_msg",
                        "has_auth",
                        "stats",
                    )
                else:
                    pipe.hmget(
                        self._acc_key(u),
                        "active",
                        "last_used",
                        "total_req",
                        "error_msg",
                        "has_auth",
                    )
            try:
                batch_docs = await pipe.execute()
            except Exception:
                if include_stats:
                    batch_docs = await asyncio.gather(
                        *[
                            self._r.hmget(
                                self._acc_key(u),
                                "active",
                                "last_used",
                                "total_req",
                                "error_msg",
                                "has_auth",
                                "stats",
                            )
                            for u in batch_users
                        ],
                        return_exceptions=True,
                    )
                else:
                    batch_docs = await asyncio.gather(
                        *[
                            self._r.hmget(
                                self._acc_key(u),
                                "active",
                                "last_used",
                                "total_req",
                                "error_msg",
                                "has_auth",
                            )
                            for u in batch_users
                        ],
                        return_exceptions=True,
                    )

            for u, vals in zip(batch_users, batch_docs):
                if isinstance(vals, Exception) or not vals:
                    continue

                if include_stats:
                    active, last_used, total_req, error_msg, has_auth, stats_raw = vals
                else:
                    active, last_used, total_req, error_msg, has_auth = vals
                try:
                    total_req_val = int(total_req or 0)
                except Exception:
                    total_req_val = 0

                item: AccountInfo = {
                    "username": u,
                    "logged_in": (has_auth == "1"),
                    "active": ((active == "1") if isinstance(active, str) else bool(active)),
                    "last_used": _from_iso_or_none(last_used),
                    "total_req": total_req_val,
                    "error_msg": (error_msg or "")[:60],
                }
                if include_stats:
                    try:
                        parsed_stats = json.loads(stats_raw or "{}")
                        item["stats"] = {
                            str(k): int(v)
                            for k, v in parsed_stats.items()
                            if isinstance(v, (int, float)) or str(v).isdigit()
                        }
                    except Exception:
                        item["stats"] = {}
                items.append(item)

        old_time = datetime(1970, 1, 1).replace(tzinfo=timezone.utc)
        items = sorted(items, key=lambda x: x["username"].lower())
        items = sorted(
            items,
            key=lambda x: (x["last_used"] or old_time if x["total_req"] > 0 else old_time),
            reverse=True,
        )
        items = sorted(items, key=lambda x: x["active"], reverse=True)
        return items

    async def validate_and_recover_queues(self) -> dict[str, Any]:
        """
        Validate queue consistency and recover lost accounts.

        This method detects and fixes the following issues:
        1. Active accounts that are missing from queues (lost accounts)
        2. Accounts in queues that are no longer active
        3. Queue size mismatches

        Returns a dictionary with recovery statistics.
        """
        logger.info("Starting queue validation and recovery...")

        # Get all active accounts
        active_accounts = await self._r.smembers(self._k_accounts_active)
        active_count = len(active_accounts)

        # Get all accounts currently in queues
        accounts_in_queues: set[str] = set()
        queue_keys = []
        cursor = 0
        while True:
            cursor, keys = await self._r.scan(cursor, match="tws:queue:*")
            queue_keys.extend(keys)
            if cursor == 0:
                break

        # Collect all usernames from all queues
        for queue_key in queue_keys:
            members = await self._r.zrange(queue_key, 0, -1)
            accounts_in_queues.update(members)

        # Also check hot pool
        hot_pool_accounts = set()
        for queue, accounts in self._hot_pool.items():
            hot_pool_accounts.update(accounts.keys())

        # Find lost accounts (active but not in any queue or hot pool)
        all_available_accounts = accounts_in_queues | hot_pool_accounts
        lost_accounts = active_accounts - all_available_accounts

        recovery_stats = {
            "active_accounts": active_count,
            "accounts_in_queues": len(accounts_in_queues),
            "accounts_in_hot_pool": len(hot_pool_accounts),
            "total_available": len(all_available_accounts),
            "lost_accounts": len(lost_accounts),
            "lost_account_usernames": list(lost_accounts),
            "recovered": 0,
        }

        # Recover lost accounts by adding them back to all queues
        if lost_accounts:
            logger.warning(
                f"Found {len(lost_accounts)} lost accounts: {list(lost_accounts)}. "
                f"Attempting recovery..."
            )

            recovered = 0
            for username in lost_accounts:
                try:
                    # Verify account still exists and is active
                    account = await self.get_account(username)
                    if account and account.active:
                        # Check if queues exist before attempting recovery
                        if not queue_keys:
                            logger.error(
                                f"Cannot recover account {username} - no queues exist! "
                                f"Create queues first or this account will remain lost."
                            )
                            continue

                        # Add to all queues with current timestamp
                        for queue_key in queue_keys:
                            await self._r.zadd(queue_key, {username: utc.ts()})
                        recovered += 1
                        logger.info(
                            f"Recovered lost account {username} - added back to {len(queue_keys)} queues"
                        )
                    else:
                        logger.warning(
                            f"Lost account {username} is no longer active or doesn't exist, skipping recovery"
                        )
                except Exception as e:
                    logger.error(f"Failed to recover account {username}: {e}", exc_info=True)

            recovery_stats["recovered"] = recovered
            logger.info(f"Recovery complete: {recovered}/{len(lost_accounts)} accounts recovered")
        else:
            logger.info("No lost accounts found - all active accounts are in queues or hot pool")

        return recovery_stats
