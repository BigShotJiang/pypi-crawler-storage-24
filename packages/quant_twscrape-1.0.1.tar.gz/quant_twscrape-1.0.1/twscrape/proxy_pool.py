import asyncio
import os
import random
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Tuple

import httpx
from dotenv import load_dotenv

from twscrape.proxies import PROXIES_ALL

from .logger import logger

load_dotenv()


class ProxyType(Enum):
    HTTP = "http"
    HTTPS = "https"
    SOCKS4 = "socks4"
    SOCKS5 = "socks5"


@dataclass
class ProxyInfo:
    """Information about a proxy"""

    host: str
    port: int
    proxy_type: ProxyType
    username: str = ""
    password: str = ""
    success_count: int = 0
    failure_count: int = 0
    last_used: float = 0
    last_success: float = 0
    last_failure: float = 0
    response_times: List[float] = field(default_factory=list)
    is_healthy: bool = True
    consecutive_failures: int = 0

    @property
    def success_rate(self) -> float:
        total = self.success_count + self.failure_count
        return self.success_count / total if total > 0 else 0.0

    @property
    def avg_response_time(self) -> float:
        return (
            sum(self.response_times[-10:]) / len(self.response_times[-10:])
            if self.response_times
            else 0.0
        )

    @property
    def score(self) -> float:
        """Calculate proxy score for load balancing"""
        base_score = self.success_rate * 100

        # Penalty for recent usage (encourage rotation)
        time_since_use = time.time() - self.last_used
        if time_since_use < 60:  # Within last minute
            base_score *= 0.8

        # Penalty for slow response times
        if self.avg_response_time > 2.0:
            base_score *= 0.9
        elif self.avg_response_time > 5.0:
            base_score *= 0.7

        # Penalty for consecutive failures
        if self.consecutive_failures > 0:
            base_score *= 0.9**self.consecutive_failures

        return base_score

    def to_url(self) -> str:
        """Convert proxy info to URL format"""
        if self.username and self.password:
            auth = f"{self.username}:{self.password}@"
        else:
            auth = ""

        return f"{self.proxy_type.value}://{auth}{self.host}:{self.port}"

    def record_success(self, response_time: float = 0):
        """Record successful usage"""
        self.success_count += 1
        self.last_used = time.time()
        self.last_success = time.time()
        self.consecutive_failures = 0
        self.is_healthy = True

        if response_time > 0:
            self.response_times.append(response_time)
            if len(self.response_times) > 20:  # Keep only last 20 measurements
                self.response_times.pop(0)

    def record_failure(self):
        """Record failed usage"""
        self.failure_count += 1
        self.last_failure = time.time()
        self.consecutive_failures += 1

        # Mark as unhealthy after 3 consecutive failures
        if self.consecutive_failures >= 3:
            self.is_healthy = False


class ProxyPoolManager:
    """Advanced proxy pool manager with session reuse and intelligent load balancing"""

    def __init__(self, max_sessions_per_proxy: int = 3, session_reuse_time: int = 300):
        self.proxies: Dict[str, ProxyInfo] = {}
        self.sessions: Dict[
            str, List[Tuple[httpx.AsyncClient, float]]
        ] = {}  # proxy_id -> [(client, created_time)]
        self.max_sessions_per_proxy = max_sessions_per_proxy
        self.session_reuse_time = session_reuse_time  # seconds
        self.proxy_user = os.getenv("PROXY_USER", "")
        self.proxy_pass = os.getenv("PROXY_PASS", "")

        # Initialize with existing proxies (converted to HTTP/SOCKS)
        self._load_default_proxies()

        # Background task for cleanup
        self._cleanup_task = None

    def _load_default_proxies(self):
        """Load default proxies and try to detect if they support SOCKS"""
        # Default proxy list (you can keep the existing ones)
        default_proxies = PROXIES_ALL

        # Try to load SOCKS proxies from environment
        socks_proxies = os.getenv("SOCKS_PROXIES", "").split(",")
        socks_proxies = [p.strip() for p in socks_proxies if p.strip()]

        # Add HTTP proxies
        for proxy in default_proxies:
            if ":" in proxy:
                host, port = proxy.split(":", 1)
                proxy_id = f"http_{host}_{port}"
                self.proxies[proxy_id] = ProxyInfo(
                    host=host,
                    port=int(port),
                    proxy_type=ProxyType.HTTP,
                    username=self.proxy_user,
                    password=self.proxy_pass,
                )

        # Add SOCKS proxies
        for proxy in socks_proxies:
            if ":" in proxy:
                host, port = proxy.split(":", 1)
                proxy_id = f"socks5_{host}_{port}"
                self.proxies[proxy_id] = ProxyInfo(
                    host=host,
                    port=int(port),
                    proxy_type=ProxyType.SOCKS5,
                    username=self.proxy_user,
                    password=self.proxy_pass,
                )

        logger.info(
            f"Loaded {len(self.proxies)} proxies ({len([p for p in self.proxies.values() if p.proxy_type == ProxyType.HTTP])} HTTP, {len([p for p in self.proxies.values() if p.proxy_type == ProxyType.SOCKS5])} SOCKS5)"
        )

    async def start_cleanup_task(self):
        """Start background cleanup task"""
        if self._cleanup_task is None:
            self._cleanup_task = asyncio.create_task(self._cleanup_sessions())

    async def stop_cleanup_task(self):
        """Stop background cleanup task"""
        if self._cleanup_task:
            self._cleanup_task.cancel()
            try:
                await self._cleanup_task
            except asyncio.CancelledError:
                pass
            self._cleanup_task = None

    async def _cleanup_sessions(self):
        """Background task to clean up old sessions"""
        while True:
            try:
                await asyncio.sleep(60)  # Check every minute
                current_time = time.time()

                for proxy_id, sessions in list(self.sessions.items()):
                    # Remove expired sessions
                    fresh_sessions = []
                    for client, created_time in sessions:
                        if current_time - created_time < self.session_reuse_time:
                            fresh_sessions.append((client, created_time))
                        else:
                            await client.aclose()

                    if fresh_sessions:
                        self.sessions[proxy_id] = fresh_sessions
                    else:
                        del self.sessions[proxy_id]

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in proxy cleanup task: {e}")

    def get_best_proxy(self, exclude_proxy_ids: Optional[List[str]] = None) -> Optional[ProxyInfo]:
        """Get the best available proxy based on scoring"""
        exclude_proxy_ids = exclude_proxy_ids or []

        # Filter healthy proxies
        available_proxies = [
            proxy
            for proxy_id, proxy in self.proxies.items()
            if proxy.is_healthy and proxy_id not in exclude_proxy_ids
        ]

        if not available_proxies:
            # If no healthy proxies, reset all to healthy and try again
            for proxy in self.proxies.values():
                if proxy.consecutive_failures >= 3:
                    proxy.consecutive_failures = 0
                    proxy.is_healthy = True

            available_proxies = [
                proxy
                for proxy_id, proxy in self.proxies.items()
                if proxy_id not in exclude_proxy_ids
            ]

        if not available_proxies:
            return None

        # Sort by score (higher is better)
        available_proxies.sort(key=lambda p: p.score, reverse=True)

        # Use weighted random selection from top 3 proxies
        top_proxies = available_proxies[:3]
        weights = [proxy.score + 1 for proxy in top_proxies]  # +1 to avoid zero weights

        return random.choices(top_proxies, weights=weights)[0]

    async def get_session(
        self, proxy_info: Optional[ProxyInfo] = None, reuse_existing: bool = True
    ) -> Tuple[httpx.AsyncClient, Optional[ProxyInfo]]:
        """Get a session for the given proxy, reusing existing ones if available"""
        if proxy_info is None:
            proxy_info = self.get_best_proxy()
            if proxy_info is None:
                # Return session without proxy
                return (
                    httpx.AsyncClient(
                        transport=httpx.AsyncHTTPTransport(retries=3),
                        follow_redirects=True,
                        timeout=30.0,
                    ),
                    None,
                )

        proxy_id = f"{proxy_info.proxy_type.value}_{proxy_info.host}_{proxy_info.port}"

        # Try to reuse existing session
        if reuse_existing and proxy_id in self.sessions:
            sessions = self.sessions[proxy_id]
            if sessions:
                client, created_time = sessions.pop(0)  # Get oldest session
                # Check if session is still fresh
                if time.time() - created_time < self.session_reuse_time:
                    return client, proxy_info
                else:
                    await client.aclose()

        # Create new session
        client = await self._create_client(proxy_info)
        return client, proxy_info

    async def _create_client(self, proxy_info: ProxyInfo) -> httpx.AsyncClient:
        """Create a new HTTP client with proxy configuration"""

        if proxy_info.proxy_type in [ProxyType.SOCKS4, ProxyType.SOCKS5]:
            # Create SOCKS proxy transport
            proxy_url = proxy_info.to_url()

            # For SOCKS proxies, we need to use httpx with SOCKS support
            transport = httpx.AsyncHTTPTransport(proxy=proxy_url, retries=3)
        else:
            # HTTP proxy
            proxy_url = proxy_info.to_url()
            transport = httpx.AsyncHTTPTransport(proxy=proxy_url, retries=3)

        client = httpx.AsyncClient(transport=transport, follow_redirects=True, timeout=30.0)

        return client

    async def return_session(
        self,
        client: httpx.AsyncClient,
        proxy_info: Optional[ProxyInfo],
        success: bool,
        response_time: float = 0,
    ):
        """Return a session to the pool or close it"""
        if proxy_info is None:
            await client.aclose()
            return

        proxy_id = f"{proxy_info.proxy_type.value}_{proxy_info.host}_{proxy_info.port}"

        if success:
            proxy_info.record_success(response_time)

            # Return session to pool if we have space
            if proxy_id not in self.sessions:
                self.sessions[proxy_id] = []

            if len(self.sessions[proxy_id]) < self.max_sessions_per_proxy:
                self.sessions[proxy_id].append((client, time.time()))
            else:
                await client.aclose()
        else:
            proxy_info.record_failure()
            await client.aclose()

    def get_proxy_stats(self) -> Dict:
        """Get statistics about proxy usage"""
        stats = {
            "total_proxies": len(self.proxies),
            "healthy_proxies": len([p for p in self.proxies.values() if p.is_healthy]),
            "total_sessions": sum(len(sessions) for sessions in self.sessions.values()),
            "proxy_types": {},
        }

        for proxy_type in ProxyType:
            count = len([p for p in self.proxies.values() if p.proxy_type == proxy_type])
            if count > 0:
                stats["proxy_types"][proxy_type.value] = count

        return stats

    async def health_check(self, test_url: str = "https://httpbin.org/ip") -> Dict:
        """Perform health check on all proxies"""
        results = {}

        for proxy_id, proxy_info in self.proxies.items():
            try:
                start_time = time.time()
                client = await self._create_client(proxy_info)

                response = await client.get(test_url, timeout=10.0)
                response_time = time.time() - start_time

                if response.status_code == 200:
                    proxy_info.record_success(response_time)
                    results[proxy_id] = {
                        "status": "healthy",
                        "response_time": response_time,
                    }
                else:
                    proxy_info.record_failure()
                    results[proxy_id] = {
                        "status": "unhealthy",
                        "error": f"HTTP {response.status_code}",
                    }

                await client.aclose()

            except Exception as e:
                proxy_info.record_failure()
                results[proxy_id] = {"status": "unhealthy", "error": str(e)}

        return results


# Global instance
proxy_pool_manager = ProxyPoolManager()
