from __future__ import annotations

import os
from typing import Literal

from .accounts_pool import AccountsPool
from .login import LoginConfig

try:
    from .redis_accounts_pool import RedisAccountsPool
except Exception:  # pragma: no cover
    RedisAccountsPool = None  # type: ignore

try:
    from .redis_accounts_pool_v2 import RedisAccountsPoolV2
except Exception:  # pragma: no cover
    RedisAccountsPoolV2 = None  # type: ignore


Backend = Literal["sqlite", "redis", "redis_v2"]


def create_accounts_pool(
    backend: Backend = "sqlite",
    *,
    db_file: str = "accounts.db",
    login_config: LoginConfig | None = None,
    raise_when_no_account: bool = False,
):
    """
    Factory to create an accounts pool using SQLite, Redis v1, or Redis v2.

    - backend: "sqlite" (default), "redis" (v1 lock-based), or "redis_v2" (queue-based)
    - If backend is not provided, but db_file starts with "redis://", Redis v2 will be used.
    - Can be controlled via TWS_POOL_BACKEND environment variable.

    Redis v2 (queue-based) offers better performance under high load with multiple instances.
    """
    # Check environment variable for backend override
    env_backend = os.getenv("TWS_POOL_BACKEND")
    if env_backend:
        backend = env_backend  # type: ignore

    # Auto-detect Redis URL
    if backend == "sqlite" and db_file.startswith("redis://"):
        # Default to v2 for new Redis deployments
        backend = "redis_v2"

    if backend == "redis_v2":
        if RedisAccountsPoolV2 is None:
            raise RuntimeError(
                "Redis v2 backend requested but not available. Install 'redis>=5' first."
            )
        return RedisAccountsPoolV2(
            db_file=db_file,
            login_config=login_config,
            raise_when_no_account=raise_when_no_account,
        )

    if backend == "redis":
        if RedisAccountsPool is None:
            raise RuntimeError(
                "Redis backend requested but not available. Install 'redis>=5' first."
            )
        return RedisAccountsPool(
            db_file=db_file,
            login_config=login_config,
            raise_when_no_account=raise_when_no_account,
        )

    return AccountsPool(
        db_file=db_file,
        login_config=login_config,
        raise_when_no_account=raise_when_no_account,
    )
