# TWScrape Development Guide

## Overview

TWScrape is a Python library for scraping Twitter/X data using the GraphQL API with SNScrape data models. It supports both async operations and CLI commands for Twitter data extraction with automatic account management and rate limiting.

## Project Structure

```
twscrape/
├── .git/                        # Git repository metadata
├── .github/                     # GitHub workflows and templates
├── .venv/                       # Python virtual environment
├── .vscode/                     # VS Code configuration
├── examples/                    # Usage examples
│   ├── download_media.py        # Media download example
│   ├── parallel_search.py       # Parallel search example
│   └── parallel_search_with_limit.py
├── tests/                       # Test suite
│   ├── mocked-data/            # Mock API responses for testing
│   ├── conftest.py             # Pytest configuration
│   ├── test_api.py             # API tests
│   ├── test_parser.py          # Data parsing tests
│   ├── test_pool.py            # Account pool tests
│   ├── test_queue_client.py    # Queue client tests
│   └── test_utils.py           # Utility tests
├── twscrape/                   # Main package source code
│   ├── __init__.py             # Package exports
│   ├── account.py              # Account data model
│   ├── accounts_pool.py        # Account management system
│   ├── api.py                  # Main API interface
│   ├── cli.py                  # Command-line interface
│   ├── db.py                   # Database operations
│   ├── imap.py                 # Email verification via IMAP
│   ├── logger.py               # Logging configuration
│   ├── login.py                # Login flow implementation
│   ├── models.py               # Data models (Tweet, User, etc.)
│   ├── queue_client.py         # Rate limiting and request handling
│   ├── utils.py                # Utility functions
│   └── xclid.py                # X-Client-Transaction-ID generation
├── pyproject.toml              # Project configuration and dependencies
├── readme.md                   # Main documentation
├── Makefile                    # Development tasks
├── LICENSE                     # MIT license
├── Dockerfile.py-matrix        # Python version testing
├── Dockerfile.sq-matrix        # SQLite version testing
├── _get_gql_ops.py            # GraphQL operations discovery
├── .gitignore                  # Git ignore rules
├── .dockerignore               # Docker ignore rules
├── .gitattributes              # Git attributes
└── uv.lock                     # UV package manager lock file
```

## Core Architecture

### 1. Main Components

#### API Layer (`api.py`)
- **Primary Interface**: The `API` class serves as the main entry point
- **GraphQL Operations**: Defines all Twitter GraphQL endpoints as constants
- **Feature Flags**: Manages Twitter's feature flags for GraphQL requests
- **Method Types**: Each operation has both raw and parsed versions
- **Rate Limiting**: Integrates with the queue system for automatic rate limiting

Key GraphQL Operations:
- `OP_SearchTimeline`: Tweet search functionality
- `OP_UserByRestId`: User data by ID
- `OP_UserByScreenName`: User data by username
- `OP_TweetDetail`: Individual tweet details
- `OP_Followers/Following`: User connections
- `OP_UserTweets`: User's tweet timeline
- `OP_Retweeters`: Tweet engagement data

#### Account Management (`accounts_pool.py`)
- **Pool System**: Manages multiple Twitter accounts for rotation
- **Lock Mechanism**: Prevents concurrent use of same account
- **Auto-switching**: Automatically switches accounts when rate limited
- **Database Storage**: Persists account data in SQLite
- **Login State**: Tracks active/inactive accounts

#### Queue Client (`queue_client.py`)
- **Rate Limiting**: Implements Twitter's rate limiting rules
- **Request Retry**: Handles failed requests with exponential backoff
- **Account Rotation**: Automatically switches accounts when needed
- **Transaction ID**: Generates required x-client-transaction-id headers
- **Error Handling**: Manages various Twitter API error responses

#### Data Models (`models.py`)
- **Tweet Model**: Complete tweet data structure with media, links, metrics
- **User Model**: User profile data with verification status, counts
- **Media Types**: Photo, video, animated GIF support
- **Cards**: Summary cards, polls, broadcasts
- **Trends**: Trending topics with metadata
- **JSON Serialization**: All models support dict/json conversion

### 2. Data Flow Architecture

```
CLI/API Call → AccountsPool → QueueClient → Twitter GraphQL → Response Parser → Data Models
     ↑              ↓              ↓              ↓               ↓              ↓
 User Input    Account Lock    Rate Limit    HTTP Request    Raw JSON      Structured Data
```

## Tweet Crawling Logic

### Search Workflow
1. **Query Preparation**: Format search query with parameters
2. **Account Selection**: Get available account from pool
3. **GraphQL Request**: Send to SearchTimeline endpoint
4. **Response Processing**: Parse entries and extract tweets
5. **Pagination**: Use cursor for next page
6. **Rate Limit Handling**: Switch accounts or wait when limited

### Key Search Parameters
```python
{
    "rawQuery": "search query",
    "count": 20,                    # tweets per request
    "product": "Latest",            # Latest, Top, Media, People
    "querySource": "typed_query",
    "cursor": "pagination_token"    # for subsequent pages
}
```

### Pagination System
- **Cursor-based**: Uses Twitter's cursor system for pagination
- **Entry Filtering**: Filters out promotional and cursor entries
- **Limit Handling**: Respects user-specified limits
- **Auto-termination**: Stops when no more results available

## User Information Logic

### User Data Collection
1. **User by ID/Login**: Direct user profile lookup
2. **Social Graph**: Followers, following, subscriptions
3. **Content**: User tweets, replies, media
4. **Verification**: Blue checkmark, verification type
5. **Metrics**: Follower counts, tweet counts, engagement

### User Profile Parsing
```python
User(
    id=int(obj["id_str"]),
    username=obj["screen_name"],
    displayname=obj["name"],
    rawDescription=obj["description"],
    created=email.utils.parsedate_to_datetime(obj["created_at"]),
    followersCount=obj["followers_count"],
    # ... additional fields
)
```

## Account Management System

### Account Lifecycle
1. **Addition**: Add account credentials to database
2. **Login**: Authenticate and obtain session cookies
3. **Activation**: Mark account as active after successful login
4. **Usage**: Rotate accounts based on rate limits
5. **Monitoring**: Track request counts and error states
6. **Maintenance**: Handle bans, suspensions, and relogins

### Login Flow (`login.py`)
1. **Session Creation**: Initialize HTTP session with headers
2. **Authentication**: Login with username/password
3. **2FA Handling**: Support for email and SMS verification
4. **Cookie Extraction**: Save session cookies for future use
5. **Verification**: Confirm account is properly authenticated

### Rate Limiting Strategy
- **Per-endpoint Limits**: Different limits for different operations
- **Account Rotation**: Switch accounts when rate limited
- **Reset Timing**: Wait for rate limit reset when all accounts exhausted
- **Lock System**: Prevent concurrent use of same account

## Database Schema

### Accounts Table
```sql
CREATE TABLE accounts (
    username TEXT PRIMARY KEY,
    password TEXT,
    email TEXT,
    email_password TEXT,
    user_agent TEXT,
    active BOOLEAN,
    last_used DATETIME,
    total_req INTEGER,
    error_msg TEXT,
    locks TEXT,  -- JSON object
    stats TEXT,  -- JSON object
    headers TEXT, -- JSON object
    cookies TEXT, -- JSON object
    proxy TEXT,
    mfa_code TEXT
);
```

## Development Workflow

### Setup
```bash
# Install dependencies
make install

# Run tests
make test

# Check code quality
make lint

# Build package
make build
```

### Testing Strategy
- **Unit Tests**: Individual component testing
- **Integration Tests**: Full workflow testing
- **Mock Data**: Real API responses for consistent testing
- **Matrix Testing**: Multiple Python and SQLite versions

### Key Make Targets
- `make check`: Run linting and tests
- `make test`: Run test suite with coverage
- `make lint`: Code formatting and type checking
- `make update-mocks`: Refresh test data from live API

## CLI Commands

### Account Management
```bash
twscrape add_accounts accounts.txt username:password:email:email_password
twscrape login_accounts
twscrape accounts         # List account status
twscrape stats           # Show usage statistics
```

### Data Extraction
```bash
twscrape search "query" --limit=100
twscrape user_by_id 123456789
twscrape user_tweets 123456789 --limit=50
twscrape followers 123456789 --limit=100
```

## Error Handling

### Common Error Scenarios
1. **Rate Limits**: Automatic account switching
2. **Account Bans**: Mark inactive and skip
3. **Network Errors**: Retry with exponential backoff
4. **Invalid Responses**: Graceful degradation
5. **Authentication Failures**: Re-login attempts

### Recovery Mechanisms
- **Auto-retry**: Failed requests retried up to 3 times
- **Account Rotation**: Switch to fresh account on errors
- **Graceful Degradation**: Continue with available accounts
- **Error Logging**: Detailed error tracking for debugging

## Configuration

### Environment Variables
- Debug mode can be enabled via `--debug` flag
- Proxy support through account configuration
- Custom database paths supported

### Feature Flags
The system includes comprehensive Twitter feature flags that need to match the current Twitter web interface to ensure compatibility.

## Security Considerations

1. **Credential Storage**: Accounts stored in encrypted SQLite database
2. **Rate Limiting**: Respects Twitter's API limits
3. **User Agents**: Rotates user agents to avoid detection
4. **Proxy Support**: Can route through proxies for IP rotation
5. **Session Management**: Proper cookie handling and session cleanup

## Performance Optimization

1. **Async Operations**: Full async/await support for concurrent operations
2. **Connection Pooling**: Reuses HTTP connections
3. **Efficient Parsing**: Optimized JSON parsing for large responses
4. **Memory Management**: Streams data instead of loading everything
5. **Caching**: Account sessions cached for reuse

## Extension Points

### Adding New Endpoints
1. Add GraphQL operation constant to `api.py`
2. Implement raw and parsed methods
3. Add appropriate data models if needed
4. Update CLI commands in `cli.py`
5. Add tests with mock data

### Custom Data Models
1. Define new dataclass in `models.py`
2. Implement `parse()` static method
3. Add JSON serialization support
4. Create parser functions for API responses

This development guide provides a comprehensive overview of TWScrape's architecture, workflows, and extension capabilities for contributors and users looking to understand or modify the system.
