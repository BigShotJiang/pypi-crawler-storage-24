"""
FastAPI Twitter Scraper Application

A REST API for scraping Twitter data using the TWScrape library.
Optimized for high concurrency by eliminating shared state bottlenecks.
"""

import asyncio
import os
from contextlib import asynccontextmanager
from importlib.metadata import PackageNotFoundError, version

import sentry_sdk
import uvicorn
from fastapi import Depends, FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from sentry_sdk.integrations.fastapi import FastApiIntegration
from sentry_sdk.integrations.starlette import StarletteIntegration

from app.dependencies import verify_api_key
from app.routers import accounts, lists, metrics, reddit, trends, tweets, users
from twscrape.logger import set_log_level

# Initialize Sentry for error tracking and performance monitoring
sentry_dsn = os.getenv("SENTRY_DSN")
if sentry_dsn:
    # Get app version from pyproject.toml
    try:
        app_version = version("oraichain-twitter-scraper")
    except PackageNotFoundError:
        app_version = "dev"  # Fallback for development

    # Get sampling rates from environment or use defaults
    # Production default: 1% traces, 1% profiles (reduces performance quota by ~99%)
    traces_sample_rate = float(os.getenv("SENTRY_TRACES_SAMPLE_RATE", "0.01"))
    profiles_sample_rate = float(os.getenv("SENTRY_PROFILES_SAMPLE_RATE", "0.01"))

    sentry_sdk.init(
        dsn=sentry_dsn,
        # Release tracking - helps identify which version has which bugs
        release=f"oraichain-twitter-scraper@{app_version}",
        # Performance monitoring - capture transaction traces
        traces_sample_rate=traces_sample_rate,
        # Profiling - capture performance profiles
        profiles_sample_rate=profiles_sample_rate,
        # Include request data and user IP for debugging
        send_default_pii=True,
        # FastAPI and Starlette integrations
        integrations=[
            StarletteIntegration(
                transaction_style="endpoint",
                failed_request_status_codes={403, *range(500, 599)},
            ),
            FastApiIntegration(
                transaction_style="endpoint",
            ),
        ],
        # Maximum breadcrumbs to capture for context
        # Breadcrumbs are "trails" of actions before an error (logs, HTTP requests, DB queries, etc.)
        # 20 = keep last 20 breadcrumbs to understand what led to the error (reduced for quota savings)
        max_breadcrumbs=20,
        # Attach stack traces to messages
        # When you manually log messages (not errors), include full stack trace for debugging
        attach_stacktrace=True,
        # Filter out health check endpoints from traces
        traces_sampler=lambda sampling_context: (
            0.0
            if sampling_context.get("asgi_scope", {}).get("path") in ["/health", "/metrics"]
            else traces_sample_rate
        ),
    )
    print(
        f"Sentry initialized (version: {app_version}, traces: {traces_sample_rate}, profiles: {profiles_sample_rate})"
    )
else:
    print("Sentry DSN not configured - error tracking disabled")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Application lifespan manager
    Creates shared pool instance for optimal concurrency and hot pool efficiency
    """
    # Startup - set logging level from environment variable or default to INFO for production
    log_level_str = os.getenv("TWS_LOG_LEVEL", "INFO").upper()
    valid_levels = ["TRACE", "DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
    if log_level_str not in valid_levels:
        print(f"⚠️  Invalid TWS_LOG_LEVEL '{log_level_str}', defaulting to INFO")
        log_level_str = "INFO"

    set_log_level(log_level_str)  # type: ignore
    print(f"📋 TWScrape log-level set to: {log_level_str}")

    # Initialize rate limiting state
    # Comma-separated whitelist keys
    whitelist_env = os.getenv("RATE_LIMIT_WHITELIST_KEYS", "")
    whitelist_keys = set(k.strip() for k in whitelist_env.split(",") if k.strip())

    # Configurable limits: N requests per X minutes
    n_requests = 100
    window_minutes = 5

    app.state.rate_limit_whitelist = whitelist_keys
    app.state.rate_limit_requests = n_requests
    app.state.rate_limit_window_minutes = window_minutes
    app.state.rate_limit_counters = {}
    app.state.rate_limit_lock = asyncio.Lock()

    # Create shared accounts pool instance for all requests
    # This enables hot pool sharing and reduces connection overhead
    from twscrape.pools import create_accounts_pool

    pool_url = os.getenv("TWS_REDIS_URL") or os.getenv("REDIS_URL")

    if pool_url:
        # Use Redis v2 (queue-based) for high concurrency
        print("🔄 Initializing shared Redis accounts pool (v2)...")
        app.state.accounts_pool = create_accounts_pool(
            backend="redis_v2",
            db_file=pool_url,
            raise_when_no_account=False,
        )
        print("✅ Shared accounts pool initialized with Redis v2")
    else:
        # Fallback to SQLite
        db_file = os.getenv("ACCOUNTS_DB_FILE", "accounts.db")
        print("🔄 Initializing shared SQLite accounts pool...")
        app.state.accounts_pool = create_accounts_pool(
            backend="sqlite",
            db_file=db_file,
            raise_when_no_account=False,
        )
        print("✅ Shared accounts pool initialized with SQLite")

    yield

    # Shutdown - cleanup pool resources
    print("🧹 Shutting down shared accounts pool...")
    if hasattr(app.state.accounts_pool, "close"):
        await app.state.accounts_pool.close()
    print("✅ Accounts pool closed successfully")


# Create FastAPI application
app = FastAPI(
    title="Twitter Scraper API",
    description="A high-performance REST API for scraping Twitter data with concurrent request support",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure as needed
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers with API key authentication
app.include_router(
    tweets.router,
    prefix="/api/v1",
    tags=["tweets"],
    dependencies=[Depends(verify_api_key)],
)
app.include_router(
    users.router,
    prefix="/api/v1",
    tags=["users"],
    dependencies=[Depends(verify_api_key)],
)
app.include_router(
    accounts.router,
    prefix="/api/v1",
    tags=["accounts"],
    dependencies=[Depends(verify_api_key)],
)
app.include_router(
    trends.router,
    prefix="/api/v1",
    tags=["trends"],
    dependencies=[Depends(verify_api_key)],
)
app.include_router(
    lists.router,
    prefix="/api/v1",
    tags=["lists"],
    dependencies=[Depends(verify_api_key)],
)

app.include_router(
    reddit.router,
    prefix="/api/v1",
    tags=["reddit"],
    dependencies=[Depends(verify_api_key)],
)

# Metrics endpoint - NO authentication required (Prometheus standard)
app.include_router(
    metrics.router,
    tags=["metrics"],
)


@app.get("/", response_model=dict)
async def root():
    """Root endpoint with API information"""
    return {
        "message": "Twitter Scraper API - High Performance Edition",
        "version": "2.0.0",
        "docs": "/docs",
        "redoc": "/redoc",
        "optimization": "Per-request API instances for maximum concurrency",
    }


@app.get("/health", response_model=dict)
async def health_check(request: Request):
    """Health check endpoint with Redis connection validation"""
    try:
        pool = request.app.state.accounts_pool
        pool_type = type(pool).__name__

        response = {
            "status": "healthy",
            "api_ready": True,
            "concurrency_mode": "per-request-optimized",
            "pool_type": pool_type,
        }

        # Check Redis connection if using Redis pool
        if pool_type == "RedisAccountsPoolV2" or pool_type == "RedisAccountsPool":
            try:
                # Ping Redis to verify connection with timeout
                # Critical: Use asyncio.wait_for to prevent indefinite hangs
                # Timeout must be less than Docker health check timeout (10s)
                await asyncio.wait_for(pool._r.ping(), timeout=3.0)
                response["redis_status"] = "connected"
            except asyncio.TimeoutError:
                response["status"] = "unhealthy"
                response["redis_status"] = "timeout"
                response["redis_error"] = (
                    "Redis ping timeout after 3s (connection pool may be exhausted)"
                )
            except Exception as redis_error:
                response["status"] = "unhealthy"
                response["redis_status"] = "disconnected"
                response["redis_error"] = str(redis_error)
        else:
            # SQLite pool
            response["redis_status"] = "not_using_redis"

        return response
    except Exception as e:
        return {"status": "unhealthy", "api_ready": False, "error": str(e)}


# @app.get("/sentry-debug")
# async def trigger_error():
#     division_by_zero = 1 / 0

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info",
        # Optimize for high concurrency
        workers=1,  # Single worker but with async concurrency
        limit_concurrency=1000,  # Allow up to 1000 concurrent connections
        # limit_max_requests=10000,  # Process many requests before recycling
    )
