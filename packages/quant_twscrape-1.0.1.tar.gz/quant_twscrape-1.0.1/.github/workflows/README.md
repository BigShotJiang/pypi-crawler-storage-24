# GitHub Actions Workflows

## lint.yml - Code Quality Checks

Automatically runs linting and code quality checks on pull requests and pushes to `main` and `staging` branches.

### What it checks:
- ✅ All pre-commit hooks (trailing whitespace, YAML/JSON/TOML validation, etc.)
- ✅ Ruff linting with auto-fix suggestions
- ✅ Code formatting with ruff-format
- 🧪 Optional: pytest tests (currently disabled)

### When it runs:
- On pull requests targeting `main` or `staging`
- On direct pushes to `main` or `staging`

### How to enable branch protection:

To require this check to pass before merging:

1. Go to **Settings** → **Branches** → **Branch protection rules**
2. Add rule for `main` branch
3. Enable "Require status checks to pass before merging"
4. Select "Lint and Code Quality" workflow
5. Enable "Require branches to be up to date before merging"

### Local testing:

Run the same checks locally before pushing:

```bash
# Run all pre-commit hooks
uv run pre-commit run --all-files

# Or just ruff
uv run ruff check .
uv run ruff format --check .
```

## deploy.yml - Deployment Workflow

Handles Docker image building and deployment to production/staging environments.

### When it runs:
- On pushes to `main` or `staging` branches
- On version tags (v*)

See the workflow file for detailed deployment steps.
