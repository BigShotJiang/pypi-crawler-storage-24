#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 1 || $1 =~ [^0-9] ]]; then
  echo "Usage: $0 <number_of_instances>"
  exit 1
fi

COUNT=$1
OUT_FILE=docker-compose.yml

docker-compose down

cat > "$OUT_FILE" <<EOF
version: '3.8'

# shared config for all scraper instances
x-twitter-scraper-api: &twitter-scraper-api
  image:
  environment:
    PYTHONUNBUFFERED: "1"
    LOG_LEVEL: "info"
  env_file:
    - .env
  restart: always
  healthcheck:
    test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
    interval: 30s
    timeout: 10s
    retries: 3
    start_period: 40s
  networks:
    - distilledstg_backend_net

services:
EOF

for i in $(seq 1 $COUNT); do
  PORT=$((8100 + i))
  cat >> "$OUT_FILE" <<EOF
  twitter-scraper-api-$i:
    <<: *twitter-scraper-api
    container_name: twitter-scraper-api-$i
    ports:
      - "${PORT}:8000"

EOF
done

cat >> "$OUT_FILE" <<EOF
networks:
  distilledstg_backend_net:
    external: true
EOF

echo "Generated $OUT_FILE with $COUNT instances (ports 8101–$((8100+COUNT)))."

docker-compose up -d
