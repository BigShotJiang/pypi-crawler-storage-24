#!/usr/bin/env python3
"""
Simple Concurrent API Benchmark Script
Makes concurrent HTTP requests to test API performance without limitations
"""

import asyncio
import json
import os
import statistics
import time
from typing import Any, Dict, List

import aiohttp
from dotenv import load_dotenv

load_dotenv()


async def fetch_user_following(
    session: aiohttp.ClientSession, user_id: str, base_url: str
) -> Dict[str, Any]:
    """Fetch user following data from API"""
    headers = {"X-ORAICHAIN-X-CRAWLER-API-KEY": os.getenv("X_ORAICHAIN_X_CRAWLER_API_KEY")}
    url = f"{base_url}/api/v1/users/{user_id}/following?limit=350"
    start_time = time.time()

    try:
        async with session.get(url, headers=headers) as response:
            response_time = time.time() - start_time
            if response.status == 200:
                data = await response.json()
                following_count = len(data) if isinstance(data, list) else 0
                return {
                    "success": True,
                    "response_time": response_time,
                    "following_count": following_count,
                }
            else:
                return {
                    "success": False,
                    "response_time": response_time,
                    "error": f"HTTP {response.status}",
                }
    except Exception as e:
        return {
            "success": False,
            "response_time": time.time() - start_time,
            "error": str(e),
        }


async def run_benchmark(user_ids: List[str], base_url: str = "http://localhost:8101"):
    """Run concurrent benchmark without limitations"""
    print("\n🚀 Starting API benchmark...")
    print(f"   API Endpoint: {base_url}/api/v1/users/{{user_id}}/following")
    print(f"   Total requests: {len(user_ids)}")

    # Configure aiohttp session for maximum performance
    connector = aiohttp.TCPConnector(
        limit=0,
        ttl_dns_cache=300,
        force_close=True,  # No connection limit
    )

    start_time = time.time()

    async with aiohttp.ClientSession(connector=connector) as session:
        # Create tasks for all requests
        tasks = [fetch_user_following(session, user_id, base_url) for user_id in user_ids]

        # Execute all tasks concurrently
        results = await asyncio.gather(*tasks)

    total_time = time.time() - start_time

    # Process results
    successful_requests = sum(1 for r in results if r["success"])
    response_times = [r["response_time"] for r in results if r["success"]]
    total_following = sum(r.get("following_count", 0) for r in results if r["success"])

    # Calculate statistics
    if response_times:
        avg_response_time = statistics.mean(response_times)
        median_response_time = statistics.median(response_times)
        min_response_time = min(response_times)
        max_response_time = max(response_times)
    else:
        avg_response_time = median_response_time = min_response_time = max_response_time = 0

    # Print results
    print("\n📊 Benchmark Results:")
    print(f"  Total Requests: {len(user_ids)}")
    print(f"  ✅ Successful: {successful_requests}")
    print(f"  ❌ Failed: {len(user_ids) - successful_requests}")
    print("\n⏱️  Performance:")
    print(f"  Total Time: {total_time:.2f}s")
    print(f"  Avg Response Time: {avg_response_time:.2f}s")
    print(f"  Median Response Time: {median_response_time:.2f}s")
    print(f"  Min/Max Response: {min_response_time:.2f}s / {max_response_time:.2f}s")
    print("\n📈 Throughput:")
    print(f"  Requests/Second: {len(user_ids) / total_time:.2f}")
    print(f"  Success Rate: {successful_requests / len(user_ids):.1%}")
    print(f"  Total Following Fetched: {total_following}")
    if successful_requests > 0:
        print(f"  Avg Following/Request: {total_following / successful_requests:.1f}")


async def main():
    """Main function"""
    # Load user IDs from JSON
    try:
        with open("examples/distilled.twitter_users.json", "r", encoding="utf-8") as f:
            data = json.load(f)
            user_ids = [user["user_id"] for user in data if "user_id" in user]
            print(f"📁 Loaded {len(user_ids)} user IDs")
    except Exception as e:
        print(f"❌ Failed to load user IDs: {e}")
        return

    # Run benchmark
    try:
        await run_benchmark(user_ids)
    except KeyboardInterrupt:
        print("\n🛑 Benchmark interrupted")
    except Exception as e:
        print(f"\n❌ Benchmark failed: {e}")


if __name__ == "__main__":
    asyncio.run(main())
