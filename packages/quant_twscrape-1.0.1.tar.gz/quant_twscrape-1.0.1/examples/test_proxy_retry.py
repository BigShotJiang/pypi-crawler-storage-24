#!/usr/bin/env python3
"""
Test script to demonstrate proxy retry functionality

This script intentionally includes some dead proxies to test the retry mechanism.
"""

import asyncio
import os
import sys
from pathlib import Path

# Add parent directory to path to import twscrape
sys.path.insert(0, str(Path(__file__).parent.parent))

from twscrape import API
from twscrape.proxies import proxy_manager


async def test_proxy_retry():
    """Test proxy retry functionality with intentionally bad proxies"""

    # Add a few dead proxies to test retry logic
    test_dead_proxies = [
        "192.168.1.1:8080",  # Dead proxy
        "10.0.0.1:3128",  # Dead proxy
        "127.0.0.1:9999",  # Dead proxy
    ]

    # Temporarily add dead proxies to the beginning of the list for testing
    original_proxies = proxy_manager.proxies.copy()
    proxy_manager.proxies = test_dead_proxies + proxy_manager.proxies

    print(
        f"Testing with {len(proxy_manager.proxies)} proxies (including {len(test_dead_proxies)} intentionally dead ones)"
    )
    print(f"Proxy authentication configured: {proxy_manager.has_auth()}")

    # Initialize API with random proxy rotation and debug enabled
    api = API(
        pool="accounts.db",
        debug=True,  # Enable debug to see proxy retry logs
        use_random_proxy=True,
    )

    try:
        print("\n=== Testing user lookup with proxy retry ===")

        # This should succeed after retrying with working proxies
        user_id = 783214  # @Twitter account ID
        print(f"Attempting to fetch user {user_id}...")

        user = await api.user_by_id(user_id)
        if user:
            print(f"✓ Successfully fetched user: @{user.username} ({user.displayname})")
            print(f"  Followers: {user.followersCount:,}")
            print(f"  Following: {user.friendsCount:,}")
        else:
            print(f"✗ Failed to fetch user {user_id}")

    except Exception as e:
        print(f"Error during API call: {e}")
    finally:
        # Restore original proxy list
        proxy_manager.proxies = original_proxies
        print(f"\nRestored original proxy list with {len(proxy_manager.proxies)} proxies")


async def test_search_with_proxy_retry():
    """Test search functionality with proxy retry"""

    # Initialize API with proxy retry enabled
    api = API(pool="accounts.db", debug=True, use_random_proxy=True)

    print("\n=== Testing search with proxy retry ===")

    try:
        search_query = "python programming"
        print(f"Searching for: '{search_query}'")

        tweet_count = 0
        async for tweet in api.search(search_query, limit=3):
            tweet_count += 1
            print(f"  Tweet {tweet_count}: {tweet.rawContent[:80]}...")

        print(f"✓ Found {tweet_count} tweets")

    except Exception as e:
        print(f"✗ Search failed: {e}")


if __name__ == "__main__":
    # Load environment variables if .env file exists
    env_file = Path(".env")
    if env_file.exists():
        with open(env_file) as f:
            for line in f:
                if line.strip() and not line.startswith("#"):
                    key, value = line.strip().split("=", 1)
                    os.environ[key] = value

    print("=== Proxy Retry Test Script ===")
    print("This script tests the automatic proxy retry functionality.")
    print("When a proxy fails, the system will automatically try up to 3 different proxies.")

    # Run the tests
    asyncio.run(test_proxy_retry())
    asyncio.run(test_search_with_proxy_retry())
