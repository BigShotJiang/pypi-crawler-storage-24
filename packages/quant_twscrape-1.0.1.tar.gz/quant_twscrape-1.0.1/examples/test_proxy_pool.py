#!/usr/bin/env python3
"""
Test script for the new proxy pool manager with session reuse and SOCKS support

This script demonstrates:
1. SOCKS proxy pool usage
2. Session reuse functionality
3. Intelligent load balancing
4. Performance improvements over the old random proxy approach
"""

import asyncio
import os
import sys
import time
from pathlib import Path

# Add parent directory to path to import twscrape
sys.path.insert(0, str(Path(__file__).parent.parent))

from twscrape import API
from twscrape.proxy_pool import proxy_pool_manager


async def test_proxy_pool_performance():
    """Test proxy pool performance vs traditional approach"""

    print("=== Proxy Pool Performance Test ===\n")

    # Show initial proxy stats
    stats = proxy_pool_manager.get_proxy_stats()
    print("📊 Proxy Pool Stats:")
    print(f"   Total proxies: {stats['total_proxies']}")
    print(f"   Healthy proxies: {stats['healthy_proxies']}")
    print(f"   Proxy types: {stats['proxy_types']}")
    print(f"   Active sessions: {stats['total_sessions']}")
    print()

    # Initialize API with new proxy pool
    api = API(
        pool="accounts.db",
        debug=True,
        use_random_proxy=False,  # We'll use the proxy pool instead
    )

    print("🚀 Testing with session reuse enabled...")

    # Test multiple requests to see session reuse in action
    test_requests = [
        ("user_by_id", 783214),  # @Twitter
        ("user_by_id", 50393960),  # @BillGates
        ("user_by_id", 25073877),  # @elonmusk
    ]

    start_time = time.time()
    successful_requests = 0

    for test_name, user_id in test_requests:
        try:
            print(f"🔍 Fetching user {user_id}...")

            if test_name == "user_by_id":
                user = await api.user_by_id(user_id)
                if user:
                    print(f"✅ Success: @{user.username} - {user.displayname}")
                    successful_requests += 1
                else:
                    print(f"❌ Failed to fetch user {user_id}")

            # Show current session stats
            stats = proxy_pool_manager.get_proxy_stats()
            print(f"   Sessions in pool: {stats['total_sessions']}")

        except Exception as e:
            print(f"❌ Error fetching user {user_id}: {e}")

    total_time = time.time() - start_time
    print("\n📈 Performance Results:")
    print(f"   Total time: {total_time:.2f}s")
    print(f"   Successful requests: {successful_requests}/{len(test_requests)}")
    print(f"   Average time per request: {total_time / len(test_requests):.2f}s")

    # Show final proxy stats
    stats = proxy_pool_manager.get_proxy_stats()
    print("\n📊 Final Proxy Pool Stats:")
    print(f"   Total sessions: {stats['total_sessions']}")
    print(f"   Healthy proxies: {stats['healthy_proxies']}")


async def test_proxy_health_check():
    """Test proxy health checking functionality"""

    print("\n=== Proxy Health Check ===\n")

    print("🏥 Running health check on all proxies...")
    health_results = await proxy_pool_manager.health_check()

    healthy_count = 0
    unhealthy_count = 0

    for proxy_id, result in health_results.items():
        status = result["status"]
        if status == "healthy":
            healthy_count += 1
            response_time = result.get("response_time", 0)
            print(f"✅ {proxy_id}: Healthy ({response_time:.2f}s)")
        else:
            unhealthy_count += 1
            error = result.get("error", "Unknown error")
            print(f"❌ {proxy_id}: Unhealthy - {error}")

    print("\n📊 Health Check Results:")
    print(f"   Healthy proxies: {healthy_count}")
    print(f"   Unhealthy proxies: {unhealthy_count}")
    print(f"   Success rate: {healthy_count / (healthy_count + unhealthy_count) * 100:.1f}%")


async def test_session_reuse():
    """Test session reuse functionality"""

    print("\n=== Session Reuse Test ===\n")

    print("🔄 Testing session reuse...")

    # Get multiple sessions for the same proxy
    proxy_info = proxy_pool_manager.get_best_proxy()
    if not proxy_info:
        print("❌ No available proxies for testing")
        return

    print(f"📡 Using proxy: {proxy_info.host}:{proxy_info.port} ({proxy_info.proxy_type.value})")

    sessions = []

    # Create multiple sessions
    for i in range(3):
        client, proxy_info = await proxy_pool_manager.get_session(proxy_info, reuse_existing=True)
        sessions.append((client, proxy_info))
        print(f"   Session {i + 1}: {'Reused' if i > 0 else 'New'}")

    # Return sessions to pool
    for client, proxy_info in sessions:
        await proxy_pool_manager.return_session(
            client, proxy_info, success=True, response_time=1.0
        )

    # Check pool stats
    stats = proxy_pool_manager.get_proxy_stats()
    print(f"   Sessions in pool after return: {stats['total_sessions']}")


async def demonstrate_load_balancing():
    """Demonstrate intelligent load balancing"""

    print("\n=== Load Balancing Demo ===\n")

    print("⚖️ Demonstrating intelligent load balancing...")

    # Get best proxies multiple times
    for i in range(5):
        proxy_info = proxy_pool_manager.get_best_proxy()
        if proxy_info:
            print(
                f"   Best proxy #{i + 1}: {proxy_info.host}:{proxy_info.port} (score: {proxy_info.score:.2f})"
            )

            # Simulate usage
            proxy_info.record_success(response_time=0.5 + i * 0.2)
        else:
            print(f"   No proxy available for request #{i + 1}")


async def setup_test_environment():
    """Setup test environment with SOCKS proxies if available"""

    print("🔧 Setting up test environment...\n")

    # Check for SOCKS proxies in environment
    socks_proxies = os.getenv("SOCKS_PROXIES", "")
    if socks_proxies:
        print(f"✅ SOCKS proxies configured: {len(socks_proxies.split(','))} proxies")
    else:
        print(
            "ℹ️  No SOCKS proxies configured. Set SOCKS_PROXIES environment variable for SOCKS testing."
        )
        print("   Example: SOCKS_PROXIES='127.0.0.1:1080,proxy2.com:1080'")

    # Check for proxy authentication
    proxy_user = os.getenv("PROXY_USER", "")
    proxy_pass = os.getenv("PROXY_PASS", "")

    if proxy_user and proxy_pass:
        print("✅ Proxy authentication configured")
    else:
        print(
            "ℹ️  No proxy authentication. Set PROXY_USER and PROXY_PASS for authenticated proxies."
        )

    print()


async def main():
    """Main test function"""

    print("🧪 Proxy Pool Test Suite")
    print("=" * 50)

    # Setup environment
    await setup_test_environment()

    # Start proxy pool cleanup task
    await proxy_pool_manager.start_cleanup_task()

    try:
        # Run tests
        await test_proxy_pool_performance()
        await test_session_reuse()
        await demonstrate_load_balancing()
        await test_proxy_health_check()

    finally:
        # Cleanup
        await proxy_pool_manager.stop_cleanup_task()
        print("\n✅ Proxy pool test completed!")


if __name__ == "__main__":
    # Load environment variables if .env file exists
    env_file = Path(".env")
    if env_file.exists():
        print("📄 Loading environment variables from .env file...")
        with open(env_file) as f:
            for line in f:
                if line.strip() and not line.startswith("#"):
                    if "=" in line:
                        key, value = line.strip().split("=", 1)
                        os.environ[key] = value

    # Run tests
    asyncio.run(main())
