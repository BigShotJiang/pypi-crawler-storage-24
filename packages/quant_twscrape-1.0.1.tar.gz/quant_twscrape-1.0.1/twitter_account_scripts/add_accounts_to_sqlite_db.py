import os
import sys
import asyncio
from dotenv import load_dotenv
from pymongo import MongoClient

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from twscrape.api import API

load_dotenv()

TWITTER_COOKIES_DATABASE_NAME = "distilled"
TWITTER_COOKIES_COLLECTION_NAME = "distilled_twitter_cookies"
TWITTER_COOKIES_MONGO_CONNECTION_STRING = os.getenv(
    "TWITTER_COOKIES_MONGO_CONNECTION_STRING"
)

# MongoDB connection with optimized pooling
client = MongoClient(
    TWITTER_COOKIES_MONGO_CONNECTION_STRING,
    maxPoolSize=50,  # Increased pool size
    minPoolSize=10,
    maxIdleTimeMS=30000,
    serverSelectionTimeoutMS=5000,
)
db = client[TWITTER_COOKIES_DATABASE_NAME]
twitter_cookies_collection = db[TWITTER_COOKIES_COLLECTION_NAME]


async def add_single_account(twscrape_api, account_data):
    """Add a single account to the SQLite database"""
    try:
        username = account_data["user_name"]
        cookies = account_data["cookie"]
        await twscrape_api.pool.add_account(username, "", "", "", cookies=cookies)
        print(f"Successfully added account: {username}")
        return True
    except Exception as e:
        print(f"Failed to add account {account_data['user_name']}: {e}")
        return False


async def get_accounts_from_db():
    """Get twitter accounts from MongoDB and add them to the sqlite db"""
    try:
        accounts = list(
            twitter_cookies_collection.find(
                {"is_live": True, "is_active": True, "new_account": True}
            )
        )
        print(f"Found {len(accounts)} accounts in MongoDB")

        twscrape_api = API(
            "accounts.db"
        )  # or API("path-to.db") – default is `accounts.db`

        # Get existing accounts from SQLite
        pool_accounts = await twscrape_api.pool.get_all()
        existing_usernames = {acc.username for acc in pool_accounts}
        print(f"Found {len(existing_usernames)} existing accounts in SQLite")

        # Filter out accounts that already exist
        new_accounts = []
        for acc in accounts:
            username = acc["user_name"]
            if username not in existing_usernames:
                new_accounts.append(acc)
            else:
                print(f"Account {username} already exists in SQLite, skipping...")

        if not new_accounts:
            print("No new accounts to add")
            return accounts

        print(f"Processing {len(new_accounts)} new accounts concurrently...")

        # Process all new accounts concurrently
        tasks = [add_single_account(twscrape_api, acc) for acc in new_accounts]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        # Count successful additions
        successful_additions = sum(1 for result in results if result is True)
        failed_additions = len(new_accounts) - successful_additions

        print(
            f"Successfully added {successful_additions} new accounts to SQLite database"
        )
        if failed_additions > 0:
            print(f"Failed to add {failed_additions} accounts")

        # Get updated count
        updated_pool_accounts = await twscrape_api.pool.get_all()
        print(f"Total accounts in SQLite after update: {len(updated_pool_accounts)}")

        return accounts
    except Exception as e:
        print(f"Error adding accounts to sqlite db: {e}")
        return []


if __name__ == "__main__":
    asyncio.run(get_accounts_from_db())
