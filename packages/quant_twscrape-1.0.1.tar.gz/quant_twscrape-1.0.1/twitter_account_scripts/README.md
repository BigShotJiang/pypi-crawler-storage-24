# Twitter Account Management Scripts

This directory contains scripts for managing Twitter accounts between MongoDB and a local SQLite database used by the Twitter scraper.

## Scripts Overview

### 1. `add_accounts_to_sqlite_db.py`

Synchronizes Twitter accounts from MongoDB to the local SQLite database used by the scraper.

**Features:**
- Concurrent account processing for optimal performance
- Checks for existing accounts to avoid duplicates
- Detailed success/failure reporting
- Error handling for individual accounts

**Usage:**
```bash
python add_accounts_to_sqlite_db.py
```

**Requirements:**
- MongoDB connection string in `.env` file
- Twitter account cookies in MongoDB with format:
  ```json
  {
    "user_name": "twitter_username",
    "cookie": "twitter_cookie_string",
    "is_live": true,
    "is_active": true,
    "new_account": true
  }
  ```

### 2. `cronjob_check_dead_accounts.py`

Monitors the SQLite database for inactive Twitter accounts and updates their status in MongoDB.

**Features:**
- Runs every 15 minutes
- Concurrent processing of dead accounts
- Parallel MongoDB updates and SQLite removals
- Detailed logging with timestamps
- Continuous operation with error recovery

**Usage:**
```bash
python cronjob_check_dead_accounts.py
```

**Process:**
1. Checks all accounts in SQLite pool
2. Identifies accounts with `active=False`
3. Concurrently:
   - Updates MongoDB (`is_live=False`)
   - Removes account from SQLite pool
4. Waits 15 minutes before next check

## Environment Setup

Create a `.env` file in the project root with:
```env
TWITTER_COOKIES_MONGO_CONNECTION_STRING=your_mongodb_connection_string
```

## MongoDB Collection Structure

The scripts expect a MongoDB collection with the following structure:

```javascript
{
  "user_name": String,       // Twitter username
  "cookie": String,         // Twitter cookie string
  "is_live": Boolean,      // Account status
  "is_active": Boolean,    // Account activity status
  "new_account": Boolean   // New account flag
}
```

## Performance

Both scripts utilize concurrent processing for optimal performance:

- **Account Addition**: Multiple accounts are added simultaneously
- **Dead Account Processing**: Both database operations (MongoDB update and SQLite removal) run in parallel
- **Error Handling**: Individual account failures don't affect the batch process

## Logging

Both scripts provide detailed logging:
- Number of accounts processed
- Success/failure counts
- Individual account status
- Error messages when applicable

## Error Handling

The scripts include comprehensive error handling:
- Individual account failures are isolated
- Process continues even if some accounts fail
- Detailed error reporting for troubleshooting
- Automatic retry on next run for failed operations

## Dependencies

- Python 3.10+
- `python-dotenv`
- `pymongo`
- Local `twscrape` package

## Notes
- The scripts use the local `twscrape` package, not the PyPI version
- MongoDB connection is optimized with connection pooling
- The cronjob script runs indefinitely until manually stopped
- All operations are logged with timestamps for monitoring
