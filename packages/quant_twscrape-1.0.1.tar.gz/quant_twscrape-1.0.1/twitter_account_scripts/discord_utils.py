import os
from discord_webhook import DiscordWebhook
from dotenv import load_dotenv

load_dotenv()

DISCORD_URL = os.getenv("DISCORD_MONITOR_URL")


def sent_notify_discord(content):
    webhook = DiscordWebhook(url=DISCORD_URL, content=content)
    response = webhook.execute()
    return response
