import os
import asyncio
from datetime import datetime
from dotenv import load_dotenv
from pymongo import MongoClient
from twscrape.api import API
from discord_utils import sent_notify_discord

load_dotenv()

TWITTER_COOKIES_DATABASE_NAME = "distilled"
TWITTER_COOKIES_COLLECTION_NAME = "distilled_twitter_cookies"
TWITTER_COOKIES_MONGO_CONNECTION_STRING = os.getenv(
    "TWITTER_COOKIES_MONGO_CONNECTION_STRING"
)

# Monitoring thresholds
MIN_ACTIVE_ACCOUNTS = 2000
CHECK_INTERVAL = 30 * 60  # 30 minutes in seconds

# MongoDB connection with optimized pooling
client = MongoClient(
    TWITTER_COOKIES_MONGO_CONNECTION_STRING,
    maxPoolSize=50,
    minPoolSize=10,
    maxIdleTimeMS=30000,
    serverSelectionTimeoutMS=5000,
)
db = client[TWITTER_COOKIES_DATABASE_NAME]
twitter_cookies_collection = db[TWITTER_COOKIES_COLLECTION_NAME]


async def process_single_dead_account(twscrape_api, account):
    """Process a single dead account - update MongoDB and remove from pool"""
    try:
        username = account.username

        # Update MongoDB and remove from pool concurrently
        mongo_task = asyncio.create_task(update_mongo_account(username))
        pool_task = asyncio.create_task(remove_from_pool(twscrape_api, username))

        # Wait for both operations to complete
        mongo_result, pool_result = await asyncio.gather(
            mongo_task, pool_task, return_exceptions=True
        )

        success = True
        if isinstance(mongo_result, Exception):
            print(
                f"[{datetime.now()}] Failed to update MongoDB for {username}: {mongo_result}"
            )
            success = False
        else:
            print(
                f"[{datetime.now()}] Updated MongoDB for {username}: matched={mongo_result.matched_count}"
            )

        if isinstance(pool_result, Exception):
            print(
                f"[{datetime.now()}] Failed to remove {username} from pool: {pool_result}"
            )
            success = False
        else:
            print(f"[{datetime.now()}] Removed {username} from pool")

        return success
    except Exception as e:
        print(f"[{datetime.now()}] Error processing account {account.username}: {e}")
        return False


async def update_mongo_account(username):
    """Update account status in MongoDB"""
    try:
        result = twitter_cookies_collection.update_one(
            {"user_name": username},
            {"$set": {"is_live": False}},
        )
        return result
    except Exception as e:
        raise e


async def remove_from_pool(twscrape_api, username):
    """Remove account from SQLite pool"""
    try:
        await twscrape_api.pool.delete_accounts(username)
        return True
    except Exception as e:
        raise e


async def check_active_account_count(pool_accounts):
    """Monitor the number of active accounts and send alerts if below threshold"""
    active_accounts = [acc for acc in pool_accounts if acc.active]
    active_count = len(active_accounts)

    print(f"[{datetime.now()}] Current active accounts: {active_count}")

    if active_count < MIN_ACTIVE_ACCOUNTS:
        alert_message = f"🚨 **ALERT**: Active Twitter accounts ({active_count}) are below minimum threshold ({MIN_ACTIVE_ACCOUNTS})!\nImmediate attention required to add more accounts."
        try:
            sent_notify_discord(alert_message)
            print(f"[{datetime.now()}] Sent low account alert to Discord")
        except Exception as e:
            print(f"[{datetime.now()}] Failed to send Discord alert: {e}")

    return active_count


async def check_dead_accounts():
    """Check for inactive accounts and update databases"""
    try:
        twscrape_api = API("accounts.db")

        # Get all accounts from pool
        pool_accounts = await twscrape_api.pool.get_all()
        print(f"[{datetime.now()}] Checking {len(pool_accounts)} accounts in pool")

        # Check active account count first
        active_count = await check_active_account_count(pool_accounts)

        # Find inactive accounts
        inactive_accounts = [acc for acc in pool_accounts if not acc.active]

        if not inactive_accounts:
            print(f"[{datetime.now()}] No inactive accounts found")
            return

        print(f"[{datetime.now()}] Found {len(inactive_accounts)} inactive accounts")
        print(f"[{datetime.now()}] Processing dead accounts concurrently...")

        # Process all inactive accounts concurrently
        tasks = [
            process_single_dead_account(twscrape_api, acc) for acc in inactive_accounts
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        # Count successful removals
        successful_removals = sum(1 for result in results if result is True)
        failed_removals = len(inactive_accounts) - successful_removals

        print(
            f"[{datetime.now()}] Successfully processed {successful_removals} dead accounts"
        )
        if failed_removals > 0:
            print(f"[{datetime.now()}] Failed to process {failed_removals} accounts")

        print(
            f"[{datetime.now()}] Completed processing {len(inactive_accounts)} inactive accounts"
        )

    except Exception as e:
        print(f"[{datetime.now()}] Error checking dead accounts: {e}")


if __name__ == "__main__":
    print(f"[{datetime.now()}] Starting dead accounts check...")
    asyncio.run(check_dead_accounts())
    print(f"[{datetime.now()}] Dead accounts check completed.")
