import os
import sys
import asyncio
from dotenv import load_dotenv
from pymongo import MongoClient

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from twscrape.api import API

load_dotenv()

TWITTER_COOKIES_DATABASE_NAME = "distilled"
TWITTER_COOKIES_COLLECTION_NAME = "distilled_twitter_cookies"
TWITTER_COOKIES_MONGO_CONNECTION_STRING = os.getenv(
    "TWITTER_COOKIES_MONGO_CONNECTION_STRING"
)

# Redis URL: prefer TWS_REDIS_URL, then REDIS_URL, fallback localhost
REDIS_URL = (
    os.getenv("TWS_REDIS_URL") or os.getenv("REDIS_URL") or "redis://localhost:6379/0"
)

# MongoDB connection with optimized pooling
client = MongoClient(
    TWITTER_COOKIES_MONGO_CONNECTION_STRING,
    maxPoolSize=50,
    minPoolSize=10,
    maxIdleTimeMS=30000,
    serverSelectionTimeoutMS=5000,
)
db = client[TWITTER_COOKIES_DATABASE_NAME]
twitter_cookies_collection = db[TWITTER_COOKIES_COLLECTION_NAME]


async def add_single_account(twscrape_api: API, account_data: dict) -> bool:
    try:
        username = account_data["user_name"]
        cookies = account_data["cookie"]
        await twscrape_api.pool.add_account(username, "", "", "", cookies=cookies)
        # add_account will handle both new accounts and updating existing ones
        return True
    except Exception as e:
        print(f"Failed to process account {account_data.get('user_name')}: {e}")
        return False


async def add_accounts_to_redis():
    try:
        accounts = list(
            twitter_cookies_collection.find(
                {"is_live": True, "is_active": True, "new_account": True}
            )
        )
        print(f"Found {len(accounts)} accounts in MongoDB")

        # Use Redis via API factory (API will choose Redis when pool string is redis://)
        twscrape_api = API(REDIS_URL)

        # Get existing accounts from Redis
        pool_accounts = await twscrape_api.pool.get_all()
        existing_usernames = {acc.username for acc in pool_accounts}
        print(f"Found {len(existing_usernames)} existing accounts in Redis")

        # Process all accounts (both new and existing)
        # Existing accounts will be updated to active=True
        print(f"Processing {len(accounts)} accounts concurrently (new and existing)...")
        tasks = [add_single_account(twscrape_api, acc) for acc in accounts]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        successful_operations = sum(1 for r in results if r is True)
        failed_operations = len(accounts) - successful_operations
        print(
            f"Successfully processed {successful_operations} accounts (added/updated in Redis)"
        )
        if failed_operations > 0:
            print(f"Failed to process {failed_operations} accounts")

        updated_pool_accounts = await twscrape_api.pool.get_all()
        print(f"Total accounts in Redis after update: {len(updated_pool_accounts)}")

        return accounts
    except Exception as e:
        print(f"Error adding accounts to Redis: {e}")
        return []


if __name__ == "__main__":
    asyncio.run(add_accounts_to_redis())
