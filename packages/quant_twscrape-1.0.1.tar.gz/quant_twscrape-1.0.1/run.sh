#!/bin/bash


# uv run python twitter_account_scripts/add_accounts_to_sqlite_db.py
uv run python main.py
