"""
Admin endpoint for synchronising tier changes from Stripe/Clerk.

The web application (Next.js) calls this endpoint after updating Clerk metadata
so that the FastAPI backend maintains the same subscription tier and status.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Literal, Optional

from fastapi import APIRouter, Depends, Header, HTTPException
from pydantic import BaseModel, root_validator
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ... import settings as saas_settings
from ...db import get_session
from ...middleware.quota_checker import TIER_LIMITS
from ...models import Account, AccountEntitlements, TrialEmailTemplate, UsageQuotaModel, User
from ...services.usage_gateway import UsageGateway

log = logging.getLogger("fmatch.api.sync_tier")

router = APIRouter(prefix="/api/v1/admin", tags=["admin-internal"])


class TierSyncPayload(BaseModel):
    """Payload for tier synchronisation from Stripe webhooks or admin tooling."""

    clerk_user_id: str
    tier: Literal["free", "pro", "scale", "unleashed"]
    status: str  # active, canceled, past_due, trialing, etc.
    monthly_enrichments: Optional[int] = None
    monthly_match_limit: Optional[int] = None
    period_start: Optional[str] = None
    period_end: Optional[str] = None
    source: Optional[str] = "webhook"
    force_reset: Optional[bool] = (
        False  # Allow admin scripts to bypass downgrade protection
    )
    addons: Optional[list[str]] = None

    @root_validator(pre=True)
    def _normalise_aliases(cls, values: dict[str, object]) -> dict[str, object]:
        """Allow camelCase aliases used by the web team."""
        if "monthlyEnrichmentCredits" in values and "monthly_enrichments" not in values:
            values["monthly_enrichments"] = values["monthlyEnrichmentCredits"]
        if "monthlyMatchLimit" in values and "monthly_match_limit" not in values:
            values["monthly_match_limit"] = values["monthlyMatchLimit"]
        if "source" not in values and "event_source" in values:
            values["source"] = values["event_source"]
        return values


class TrialSyncPayload(BaseModel):
    """Payload for provisioning a Gremlin trial into the FastAPI entitlement system."""

    clerk_user_id: str
    email: str
    trial_started_at: str
    trial_ends_at: str
    first_name: Optional[str] = None
    account_name: Optional[str] = None
    source: Optional[str] = "agent_trial_start"
    send_welcome_now: Optional[bool] = True


async def require_webhook_secret(
    authorization: str = Header(..., alias="Authorization"),
) -> str:
    """
    Verify webhook secret for internal service-to-service calls.

    Expected format: "Bearer <WEBHOOK_SECRET>"
    """

    if not authorization.startswith("Bearer "):
        raise HTTPException(
            status_code=401, detail="Invalid authorization header format"
        )

    token = authorization.replace("Bearer ", "")

    # Development escape hatch to simplify local testing.
    if saas_settings.ENV.lower() in ("dev", "development") and token == "dev-token":
        log.info("[sync-tier] Allowing dev-token in development")
        return token

    webhook_secret = saas_settings.WEBHOOK_SECRET
    if not webhook_secret:
        log.error("[sync-tier] WEBHOOK_SECRET not configured!")
        raise HTTPException(
            status_code=500, detail="Webhook authentication not configured"
        )

    if token != webhook_secret:
        log.warning("[sync-tier] Invalid webhook secret provided")
        raise HTTPException(status_code=401, detail="Invalid webhook secret")

    return token


def _resolve_entitlements(payload: TierSyncPayload) -> tuple[int, int]:
    """Determine entitlement values using payload overrides or tier defaults."""
    tier_limits = TIER_LIMITS.get(payload.tier, TIER_LIMITS["free"])
    monthly_rows = payload.monthly_match_limit or tier_limits["monthly_rows"]
    monthly_enrichments = (
        payload.monthly_enrichments or tier_limits["enrichment_credits"]
    )
    return monthly_rows, monthly_enrichments


def _parse_iso8601_utc(value: str, field_name: str) -> datetime:
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise HTTPException(
            status_code=400, detail=f"Invalid {field_name}: expected ISO8601 timestamp"
        ) from exc

    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)

    return parsed.astimezone(timezone.utc)


def _default_account_name(email: str) -> str:
    domain = (email.split("@")[1] if "@" in email else "").split(".")[0]
    cleaned = domain.replace("-", " ").replace("_", " ").strip()
    if not cleaned:
        return "Gremlin Trial"
    return " ".join(part.capitalize() for part in cleaned.split())


def _should_refresh_account_name(current_name: Optional[str]) -> bool:
    if not current_name:
        return True

    normalized = current_name.strip().lower()
    return normalized.startswith("clerk org ") or normalized.startswith("cli user ")


async def _load_trial_user(
    db: AsyncSession, clerk_user_id: str, email: str
) -> Optional[User]:
    by_id = await db.get(User, clerk_user_id)
    if by_id:
        return by_id

    by_clerk = await db.execute(select(User).where(User.clerk_user_id == clerk_user_id))
    clerk_user = by_clerk.scalar_one_or_none()
    if clerk_user:
        return clerk_user

    by_email = await db.execute(select(User).where(User.email == email))
    return by_email.scalar_one_or_none()


@router.post("/sync-tier")
async def sync_tier_from_stripe(
    payload: TierSyncPayload,
    _auth: str = Depends(require_webhook_secret),
    db: AsyncSession = Depends(get_session),
) -> dict:
    """
    Update UsageQuotaModel to reflect the tier coming from Stripe/Clerk.

    Flow:
        1. Stripe fires webhook to Next.js
        2. Next.js updates PostgreSQL & Clerk metadata
        3. Next.js calls this endpoint with the same tier information
    """

    tier_limits = TIER_LIMITS.get(payload.tier)
    if not tier_limits:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid tier: {payload.tier}. Must be one of: {list(TIER_LIMITS.keys())}",
        )

    monthly_rows, monthly_enrichments = _resolve_entitlements(payload)

    enrichments_str = (
        f", enrichments={monthly_enrichments}"
        if monthly_enrichments is not None
        else ""
    )
    log.info(
        "[sync-tier] Received tier sync for user %s: tier=%s, status=%s%s, source=%s",
        payload.clerk_user_id,
        payload.tier,
        payload.status,
        enrichments_str,
        payload.source,
    )

    stmt = select(UsageQuotaModel).where(
        UsageQuotaModel.account_id == payload.clerk_user_id
    )
    result = await db.execute(stmt)
    quota = result.scalar_one_or_none()

    now = datetime.utcnow()

    if not quota:
        quota = UsageQuotaModel(
            account_id=payload.clerk_user_id,
            tier=payload.tier,
            monthly_rows_used=0,
            enrichment_credits_used=0,
            subscription_status=payload.status or "unknown",
            tier_synced_at=now,
            tier_sync_source=payload.source or "webhook",
            monthly_enrichment_entitlement=monthly_enrichments,
            monthly_match_entitlement=monthly_rows,
        )
        db.add(quota)
        await db.commit()
        await db.refresh(quota)

        try:
            gateway = UsageGateway(db)
            await gateway.sync_from_stripe(
                account_id=payload.clerk_user_id,
                tier=payload.tier,
                addons=payload.addons or [],
                source=payload.source or "webhook",
                monthly_row_limit=monthly_rows,
            )
        except Exception as exc:  # noqa: BLE001 - best effort
            log.warning("[sync-tier] Failed to sync usage gateway: %s", exc)

        return {
            "ok": True,
            "updated": True,
            "message": f"Created new quota record with tier={payload.tier}",
            "account_id": payload.clerk_user_id,
            "tier": quota.tier,
            "status": quota.subscription_status,
            "enrichments": quota.monthly_enrichment_entitlement,
            "monthly_match_limit": quota.monthly_match_entitlement,
            "source": quota.tier_sync_source,
        }

    old_tier = quota.tier

    # Protect against erroneous downgrades from paid to free
    # If current tier is paid (pro/scale) and new tier is free, check if this is legitimate
    if (
        old_tier in ("pro", "scale")
        and payload.tier == "free"
        and not payload.force_reset
    ):
        # Check if there's an active subscription in the database
        from sqlalchemy import text

        active_sub = await db.execute(
            text("""
                SELECT s.stripe_subscription_id, s.status
                FROM subscription s
                WHERE s.account_id = :aid
                AND s.status IN ('active', 'trialing')
                ORDER BY s.created_at DESC
                LIMIT 1
            """),
            {"aid": payload.clerk_user_id},
        )
        active_subscription = active_sub.first()

        if active_subscription:
            # There's an active subscription - reject the downgrade regardless of status
            log.warning(
                "[sync-tier] Rejecting downgrade from %s to free - active subscription %s exists (status=%s). "
                "If this is legitimate, cancel the subscription first or use force_reset=true. Source: %s",
                old_tier,
                active_subscription[0],
                active_subscription[1],
                payload.source,
            )
            return {
                "ok": True,
                "updated": False,
                "message": f"Rejected downgrade from {old_tier} to free - active subscription exists",
                "account_id": payload.clerk_user_id,
                "old_tier": old_tier,
                "new_tier": old_tier,  # Kept old tier
                "status": quota.subscription_status,
                "enrichments": quota.monthly_enrichment_entitlement,
                "monthly_match_limit": quota.monthly_match_entitlement,
                "source": quota.tier_sync_source,
                "active_subscription": active_subscription[0],
            }

    # Log if force_reset was used
    if payload.force_reset and old_tier in ("pro", "scale") and payload.tier == "free":
        log.info(
            "[sync-tier] Force reset enabled - allowing downgrade from %s to free. Source: %s",
            old_tier,
            payload.source,
        )

    quota.tier = payload.tier
    quota.subscription_status = payload.status or quota.subscription_status or "unknown"
    quota.tier_synced_at = now
    quota.tier_sync_source = payload.source or quota.tier_sync_source or "webhook"
    quota.monthly_enrichment_entitlement = monthly_enrichments
    quota.monthly_match_entitlement = monthly_rows

    await db.commit()
    await db.refresh(quota)

    try:
        gateway = UsageGateway(db)
        await gateway.sync_from_stripe(
            account_id=payload.clerk_user_id,
            tier=payload.tier,
            addons=payload.addons or [],
            source=payload.source or "webhook",
            monthly_row_limit=monthly_rows,
        )
    except Exception as exc:  # noqa: BLE001 - best effort
        log.warning("[sync-tier] Failed to sync usage gateway: %s", exc)

    log.info(
        "[sync-tier] Updated tier for %s: %s -> %s (status=%s, source=%s)",
        payload.clerk_user_id,
        old_tier,
        quota.tier,
        quota.subscription_status,
        quota.tier_sync_source,
    )

    return {
        "ok": True,
        "updated": old_tier != quota.tier
        or quota.subscription_status != payload.status
        or quota.monthly_enrichment_entitlement != monthly_enrichments,
        "message": f"Tier updated from {old_tier} to {quota.tier}",
        "account_id": payload.clerk_user_id,
        "old_tier": old_tier,
        "new_tier": quota.tier,
        "status": quota.subscription_status,
        "enrichments": quota.monthly_enrichment_entitlement,
        "monthly_match_limit": quota.monthly_match_entitlement,
        "source": quota.tier_sync_source,
    }


@router.post("/sync-trial")
async def sync_trial_start(
    payload: TrialSyncPayload,
    _auth: str = Depends(require_webhook_secret),
    db: AsyncSession = Depends(get_session),
) -> dict:
    """Provision a Gremlin trial user so the drip scheduler can send onboarding emails."""

    account_id = payload.clerk_user_id.strip()
    email = payload.email.strip().lower()
    if not account_id or not email:
        raise HTTPException(status_code=400, detail="clerk_user_id and email are required")

    trial_started_at = _parse_iso8601_utc(payload.trial_started_at, "trial_started_at")
    trial_ends_at = _parse_iso8601_utc(payload.trial_ends_at, "trial_ends_at")
    if trial_ends_at <= trial_started_at:
        raise HTTPException(
            status_code=400, detail="trial_ends_at must be after trial_started_at"
        )

    account_name = (payload.account_name or "").strip() or _default_account_name(email)
    first_name = (payload.first_name or "").strip() or None
    source = (payload.source or "agent_trial_start").strip() or "agent_trial_start"
    monthly_rows, monthly_enrichments = _resolve_entitlements(
        TierSyncPayload(
            clerk_user_id=account_id,
            tier="free",
            status="trialing",
            source=source,
        )
    )

    log.info(
        "[sync-trial] Provisioning trial for user %s (%s) from %s",
        account_id,
        email,
        source,
    )

    account = await db.get(Account, account_id)
    if not account:
        account = Account(id=account_id, name=account_name)
        db.add(account)
    elif _should_refresh_account_name(account.name):
        account.name = account_name
        db.add(account)

    user = await _load_trial_user(db, account_id, email)
    if not user:
        profile_metadata = {"first_name": first_name} if first_name else None
        user = User(
            id=account_id,
            account_id=account_id,
            email=email,
            clerk_user_id=account_id,
            profile_metadata=profile_metadata,
        )
        db.add(user)
    else:
        dirty = False
        if user.email != email:
            user.email = email
            dirty = True
        if user.account_id != account_id:
            user.account_id = account_id
            dirty = True
        if user.clerk_user_id != account_id:
            user.clerk_user_id = account_id
            dirty = True

        metadata = dict(user.profile_metadata or {})
        if first_name and metadata.get("first_name") != first_name:
            metadata["first_name"] = first_name
            user.profile_metadata = metadata
            dirty = True

        if dirty:
            db.add(user)

    stmt = select(UsageQuotaModel).where(UsageQuotaModel.account_id == account_id)
    quota_result = await db.execute(stmt)
    quota = quota_result.scalar_one_or_none()
    now = datetime.utcnow()
    preserve_paid_tier = bool(quota and quota.tier and quota.tier != "free")

    if not quota:
        quota = UsageQuotaModel(
            account_id=account_id,
            tier="free",
            monthly_rows_used=0,
            enrichment_credits_used=0,
            subscription_status="trialing",
            tier_synced_at=now,
            tier_sync_source=source,
            monthly_enrichment_entitlement=monthly_enrichments,
            monthly_match_entitlement=monthly_rows,
        )
        db.add(quota)
        await db.commit()
    elif not preserve_paid_tier:
        quota.tier = "free"
        quota.subscription_status = "trialing"
        quota.tier_synced_at = now
        quota.tier_sync_source = source
        quota.monthly_enrichment_entitlement = monthly_enrichments
        quota.monthly_match_entitlement = monthly_rows
        db.add(quota)
        await db.commit()
    else:
        log.info(
            "[sync-trial] Preserving existing paid tier for %s: tier=%s status=%s",
            account_id,
            quota.tier,
            quota.subscription_status,
        )

    entitlements: Optional[AccountEntitlements] = None
    if not preserve_paid_tier:
        gateway = UsageGateway(db)
        entitlements = await gateway.sync_from_stripe(
            account_id=account_id,
            tier="free",
            addons=[],
            source=source,
            monthly_row_limit=monthly_rows,
            expires_at=trial_ends_at,
        )
        entitlements.trial_started_at = trial_started_at
        entitlements.expires_at = trial_ends_at
        db.add(entitlements)
        await db.commit()
        await db.refresh(entitlements)
    else:
        entitlements_result = await db.execute(
            select(AccountEntitlements).where(AccountEntitlements.account_id == account_id)
        )
        entitlements = entitlements_result.scalar_one_or_none()

    welcome_sent = False
    if payload.send_welcome_now:
        from ...services.trial_drip_service import send_drip_email

        template_result = await db.execute(
            select(TrialEmailTemplate).where(
                TrialEmailTemplate.day_offset == 0,
                TrialEmailTemplate.enabled == True,  # noqa: E712
            )
        )
        template = template_result.scalar_one_or_none()
        if template:
            resend_id = await send_drip_email(
                db=db,
                template=template,
                account=account,
                user=user,
                trial_end_date=trial_ends_at,
            )
            welcome_sent = bool(resend_id)

    return {
        "ok": True,
        "account_id": account_id,
        "tier": entitlements.tier if entitlements else quota.tier,
        "status": "trialing" if not preserve_paid_tier else quota.subscription_status,
        "trial_started_at": trial_started_at.isoformat(),
        "trial_ends_at": trial_ends_at.isoformat(),
        "welcome_sent": welcome_sent,
        "drip_enabled": not preserve_paid_tier,
        "source": source,
    }
