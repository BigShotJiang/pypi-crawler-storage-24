"""Bucket company sizes into standard segments."""

from __future__ import annotations

from typing import Any, Dict, Union

from ._employee_count_parser import parse_employee_count

__transform_id__ = "company_size_bucket"
__version__ = "1.1.0"
__updated__ = "2024-09-20"


def company_size_bucket(value: Union[str, int, float]) -> Dict[str, Any]:
    """
    Bucket company employee counts into standard RevOps segments.

    Examples:
        15 -> "Small Business"
        250 -> "Mid-Market"
        5000 -> "Enterprise"
        "10-50 employees" -> "Small Business"
        "10K+" -> "Strategic/Global"
        "~5,000 employees" -> "Enterprise"
    """
    if value is None or value == "":
        return {"value": None, "numeric": None}

    employee_count, parse_reason, parse_meta = parse_employee_count(value)
    if employee_count is None:
        result: Dict[str, Any] = {"value": None, "numeric": None}
        if parse_reason:
            result["meta"] = {"reason": parse_reason, **parse_meta}
        return result

    buckets = [
        (1, 10, "Startup", "startup"),
        (11, 50, "Small Business", "smb"),
        (51, 200, "SMB", "smb"),
        (201, 500, "Mid-Market", "mid_market"),
        (501, 1000, "Commercial", "commercial"),
        (1001, 5000, "Enterprise", "enterprise"),
        (5001, 10000, "Large Enterprise", "large_enterprise"),
        (10001, float("inf"), "Strategic/Global", "strategic"),
    ]

    for min_size, max_size, label, segment_code in buckets:
        if min_size <= employee_count <= max_size:
            result = {
                "value": label,
                "numeric": employee_count,
                "segment_code": segment_code,
                "min": min_size,
                "max": max_size if max_size != float("inf") else None,
            }
            if parse_meta:
                result["meta"] = parse_meta

            if employee_count <= 50:
                result["tier"] = "T4"
            elif employee_count <= 500:
                result["tier"] = "T3"
            elif employee_count <= 5000:
                result["tier"] = "T2"
            else:
                result["tier"] = "T1"

            if employee_count <= 10:
                result["arr_potential"] = "$10K-$50K"
            elif employee_count <= 50:
                result["arr_potential"] = "$50K-$250K"
            elif employee_count <= 200:
                result["arr_potential"] = "$250K-$1M"
            elif employee_count <= 500:
                result["arr_potential"] = "$1M-$5M"
            elif employee_count <= 1000:
                result["arr_potential"] = "$5M-$10M"
            elif employee_count <= 5000:
                result["arr_potential"] = "$10M-$50M"
            elif employee_count <= 10000:
                result["arr_potential"] = "$50M-$100M"
            else:
                result["arr_potential"] = "$100M+"

            return result

    return {
        "value": None,
        "numeric": employee_count,
        "segment_code": "unknown",
        "tier": "T4",
    }
