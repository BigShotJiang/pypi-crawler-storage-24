from __future__ import annotations

from typing import Any, Dict

from fmatch.core import map_state_name_to_code


def state_name_to_code(
    value: str,
    *,
    country: str | None = None,
) -> Dict[str, Any]:
    code = map_state_name_to_code(value, country or "")
    return {"value": code or ""}
