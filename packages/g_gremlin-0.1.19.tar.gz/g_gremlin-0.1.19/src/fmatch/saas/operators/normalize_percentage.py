from __future__ import annotations

from typing import Any, Dict


def normalize_percentage(value: Any) -> Dict[str, Any]:
    if value is None or value == "":
        return {"value": ""}

    raw = str(value).strip()
    if not raw:
        return {"value": ""}

    normalized = raw.replace(",", "").replace(" ", "")
    had_percent = "%" in normalized
    normalized = normalized.replace("%", "")
    if not normalized:
        return {"value": ""}

    try:
        numeric = float(normalized)
    except ValueError:
        return {"value": ""}

    # Bare values above 1 are treated as whole-percent inputs, e.g. "75" -> 0.75.
    if had_percent or abs(numeric) > 1:
        numeric = numeric / 100.0

    return {"value": round(numeric, 6)}
