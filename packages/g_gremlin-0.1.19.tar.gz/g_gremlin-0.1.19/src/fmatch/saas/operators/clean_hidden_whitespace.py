from __future__ import annotations

import re
import unicodedata
from typing import Any, Dict


_HIDDEN_CHARS_RE = re.compile(r"[\u00AD\u200B-\u200D\u2060\uFEFF]")
_WHITESPACE_RE = re.compile(r"\s+")


def clean_hidden_whitespace(value: str) -> Dict[str, Any]:
    text = unicodedata.normalize("NFKC", value or "")
    text = text.replace("\u00A0", " ")
    text = _HIDDEN_CHARS_RE.sub("", text)
    text = _WHITESPACE_RE.sub(" ", text).strip()
    return {"value": text}
