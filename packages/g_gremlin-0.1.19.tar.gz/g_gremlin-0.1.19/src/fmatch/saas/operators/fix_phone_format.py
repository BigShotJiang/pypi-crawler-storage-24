from __future__ import annotations

from typing import Any, Dict

from .normalize_phone_to_e164 import normalize_phone_to_e164


def fix_phone_format(text: str, *, country: str = "US") -> Dict[str, Any]:
    result = normalize_phone_to_e164(text, country=country or "US")
    if not result.get("valid"):
        result["value"] = ""
    meta = dict(result.get("meta") or {})
    meta["deprecated_alias_for"] = "normalize_phone_to_e164"
    result["meta"] = meta
    return result
