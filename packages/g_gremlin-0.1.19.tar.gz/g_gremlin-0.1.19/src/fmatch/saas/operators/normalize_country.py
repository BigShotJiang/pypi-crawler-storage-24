from __future__ import annotations

from typing import Any, Dict

from fmatch.core import normalize_country as normalize_country_core


def normalize_country(value: str) -> Dict[str, Any]:
    return {"value": normalize_country_core(value)}
