from __future__ import annotations

from typing import Any, Dict


_TRUE_VALUES = {
    "1",
    "active",
    "enabled",
    "on",
    "t",
    "true",
    "y",
    "yes",
}
_FALSE_VALUES = {
    "0",
    "disabled",
    "false",
    "f",
    "inactive",
    "n",
    "no",
    "off",
}


def normalize_boolean(value: Any) -> Dict[str, Any]:
    if isinstance(value, bool):
        return {"value": value}
    if value is None or value == "":
        return {"value": ""}
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if value == 1:
            return {"value": True}
        if value == 0:
            return {"value": False}

    normalized = str(value).strip().lower()
    if not normalized:
        return {"value": ""}
    if normalized in _TRUE_VALUES:
        return {"value": True}
    if normalized in _FALSE_VALUES:
        return {"value": False}
    return {"value": ""}
