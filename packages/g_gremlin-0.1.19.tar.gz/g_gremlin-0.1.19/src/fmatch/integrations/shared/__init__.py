# Shared utilities
