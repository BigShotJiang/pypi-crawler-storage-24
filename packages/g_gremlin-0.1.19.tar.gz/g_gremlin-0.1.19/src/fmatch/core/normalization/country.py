"""Country normalization using vendored ISO 3166-1 alpha-2 data."""

from __future__ import annotations

from ..heuristics import normalize_country_code


def normalize_country(value: str | None) -> str:
    """Normalize a country name or code to ISO 3166-1 alpha-2."""
    return normalize_country_code(value)
