"""State/province code normalization using static mappings.

This module provides state/province mapping without any external
dependencies - no LLM. It uses only static lookup tables.
"""

from __future__ import annotations

import re
from typing import Optional

from ..heuristics import (
    US_STATE_MAP,
    CA_PROVINCE_MAP,
    AU_STATE_MAP,
    normalize_country_code,
)


# Reverse mappings: Code → Full Name
US_STATE_NAMES = {
    "AL": "Alabama",
    "AK": "Alaska",
    "AZ": "Arizona",
    "AR": "Arkansas",
    "CA": "California",
    "CO": "Colorado",
    "CT": "Connecticut",
    "DE": "Delaware",
    "DC": "District of Columbia",
    "FL": "Florida",
    "GA": "Georgia",
    "HI": "Hawaii",
    "ID": "Idaho",
    "IL": "Illinois",
    "IN": "Indiana",
    "IA": "Iowa",
    "KS": "Kansas",
    "KY": "Kentucky",
    "LA": "Louisiana",
    "ME": "Maine",
    "MD": "Maryland",
    "MA": "Massachusetts",
    "MI": "Michigan",
    "MN": "Minnesota",
    "MS": "Mississippi",
    "MO": "Missouri",
    "MT": "Montana",
    "NE": "Nebraska",
    "NV": "Nevada",
    "NH": "New Hampshire",
    "NJ": "New Jersey",
    "NM": "New Mexico",
    "NY": "New York",
    "NC": "North Carolina",
    "ND": "North Dakota",
    "OH": "Ohio",
    "OK": "Oklahoma",
    "OR": "Oregon",
    "PA": "Pennsylvania",
    "RI": "Rhode Island",
    "SC": "South Carolina",
    "SD": "South Dakota",
    "TN": "Tennessee",
    "TX": "Texas",
    "UT": "Utah",
    "VT": "Vermont",
    "VA": "Virginia",
    "WA": "Washington",
    "WV": "West Virginia",
    "WI": "Wisconsin",
    "WY": "Wyoming",
    "PR": "Puerto Rico",
    "GU": "Guam",
    "AS": "American Samoa",
    "VI": "U.S. Virgin Islands",
}

CA_PROVINCE_NAMES = {
    "AB": "Alberta",
    "BC": "British Columbia",
    "MB": "Manitoba",
    "NB": "New Brunswick",
    "NL": "Newfoundland and Labrador",
    "NS": "Nova Scotia",
    "ON": "Ontario",
    "PE": "Prince Edward Island",
    "QC": "Quebec",
    "SK": "Saskatchewan",
    "NT": "Northwest Territories",
    "NU": "Nunavut",
    "YT": "Yukon",
}

AU_STATE_NAMES = {
    "NSW": "New South Wales",
    "VIC": "Victoria",
    "QLD": "Queensland",
    "SA": "South Australia",
    "WA": "Western Australia",
    "TAS": "Tasmania",
    "ACT": "Australian Capital Territory",
    "NT": "Northern Territory",
}


_STATE_NAME_SUFFIX_RE = re.compile(r"(state|territory|province)$")
_STATE_NAME_OVERRIDES = {
    "districtcolumbia": "DC",
    "washingtondc": "DC",
    "washingtondistrictcolumbia": "DC",
}


def _build_sanitized_state_lookup(mapping: dict[str, str]) -> dict[str, str]:
    lookup: dict[str, str] = {}
    for key, code in mapping.items():
        if len(key) <= 2:
            continue
        cleaned = re.sub(r"[^a-z]", "", key)
        if cleaned:
            lookup[cleaned] = code
    return lookup


_STATE_NAME_TO_CODE = {
    "US": {
        **_build_sanitized_state_lookup(US_STATE_MAP),
        **_STATE_NAME_OVERRIDES,
    },
    "CA": _build_sanitized_state_lookup(CA_PROVINCE_MAP),
    "AU": _build_sanitized_state_lookup(AU_STATE_MAP),
}


def map_state_code(value: str, country: str = "US") -> Optional[str]:
    """Map state code or name to full state/province name.

    Handles both directions:
    - Code → Full name: "CA" → "California"
    - Full name → Full name: "california" → "California"

    Args:
        value: State code or name (case-insensitive)
        country: Country code: "US", "CA" (Canada), or "AU" (Australia)

    Returns:
        Full state/province name, or None if not found
    """
    v = (value or "").strip()
    if not v:
        return None

    raw_country = (country or "").strip()
    country = normalize_country_code(raw_country) or raw_country.upper() or "US"

    # Try uppercase match first (code → name)
    v_upper = v.upper()
    if country == "US" and v_upper in US_STATE_NAMES:
        return US_STATE_NAMES[v_upper]
    if country == "CA" and v_upper in CA_PROVINCE_NAMES:
        return CA_PROVINCE_NAMES[v_upper]
    if country == "AU" and v_upper in AU_STATE_NAMES:
        return AU_STATE_NAMES[v_upper]

    # Try case-insensitive match for full names
    v_lower = v.lower()
    if country == "US":
        code = US_STATE_MAP.get(v_lower)
        return US_STATE_NAMES.get(code) if code else None
    if country == "CA":
        code = CA_PROVINCE_MAP.get(v_lower)
        return CA_PROVINCE_NAMES.get(code) if code else None
    if country == "AU":
        code = AU_STATE_MAP.get(v_lower)
        return AU_STATE_NAMES.get(code) if code else None

    # Legacy default when country is omitted is US. Respect explicit non-US context.
    if not raw_country or country == "US":
        code = US_STATE_MAP.get(v_lower)
        return US_STATE_NAMES.get(code) if code else None

    return None


def map_state_name_to_code(value: str, country: str = "") -> Optional[str]:
    """Map state/province names to postal or ISO subdivision codes.

    Args:
        value: State/province name (case-insensitive)
        country: Optional country code. When omitted, preserve legacy behavior
            by searching US/CA/AU lookups. When provided, constrain lookup to
            that country and do not fall through to other countries.

    Returns:
        State/province code, or None if not found
    """
    v = (value or "").strip()
    if not v:
        return None

    raw_country = (country or "").strip()
    country = normalize_country_code(raw_country) or raw_country.upper()

    key = re.sub(r"[^a-z]", "", v.lower())
    if not key:
        return None

    search_countries = ("US", "CA", "AU") if not raw_country else (country,)
    for search_country in search_countries:
        code = _STATE_NAME_TO_CODE.get(search_country, {}).get(key)
        if code:
            return code

    trimmed = _STATE_NAME_SUFFIX_RE.sub("", key)
    if trimmed and trimmed != key:
        for search_country in search_countries:
            code = _STATE_NAME_TO_CODE.get(search_country, {}).get(trimmed)
            if code:
                return code

    return None


def normalize_state(value: str, country: str = "US") -> str:
    """Normalize state/province to full name.

    Args:
        value: State code or name (case-insensitive)
        country: Country code: "US", "CA" (Canada), or "AU" (Australia)

    Returns:
        Full state/province name, or empty string if not found

    Note:
        This function does NOT use LLM fallback.
        For LLM-enhanced normalization, use the saas normalize_state operator.
    """
    result = map_state_code(value, country)
    return result or ""
