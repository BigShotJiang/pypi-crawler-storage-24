from __future__ import annotations

import json
import subprocess
import logging
import os
import shutil
import tempfile
from jonq.json_utils import dumps, loads
import asyncio

logger = logging.getLogger(__name__)


def detect_json_structure(json_file):
    with open(json_file, "r") as f:
        char = " "
        while char.isspace() and char:
            char = f.read(1)
        return char == "["


def split_json_array(json_file, chunk_size=1000):
    temp_dir = tempfile.mkdtemp(prefix="jonq_")
    chunk_files: list[str] = []

    try:
        proc = subprocess.Popen(
            ["jq", "-c", ".[]", json_file],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

        current_chunk_idx = 0
        current_line_count = 0
        current_path = os.path.join(temp_dir, f"chunk_{current_chunk_idx:06d}")
        current_handle = open(current_path, "w", encoding="utf-8")
        current_handle.write("[")

        for line in proc.stdout:
            if current_line_count:
                current_handle.write(",")
            current_handle.write(line.strip())
            current_line_count += 1

            if current_line_count >= chunk_size:
                current_handle.write("]")
                current_handle.close()
                chunk_files.append(current_path)

                current_chunk_idx += 1
                current_line_count = 0
                current_path = os.path.join(temp_dir, f"chunk_{current_chunk_idx:06d}")
                current_handle = open(current_path, "w", encoding="utf-8")
                current_handle.write("[")

        current_handle.write("]")
        current_handle.close()
        chunk_files.append(current_path)

        jq_err = proc.stderr.read()
        if proc.wait() != 0:
            raise RuntimeError(f"jq failed: {jq_err.strip()}")

        return temp_dir, chunk_files

    except Exception:
        shutil.rmtree(temp_dir, ignore_errors=True)
        raise


def iter_json_array_chunks(json_file, chunk_size=1000):
    if not detect_json_structure(json_file):
        raise ValueError(
            "Streaming mode only works with JSON files containing an array at the root level"
        )

    proc = subprocess.Popen(
        ["jq", "-c", ".[]", json_file],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )

    chunk: list[str] = []
    try:
        for line in proc.stdout:
            item = line.strip()
            if not item:
                continue
            chunk.append(item)
            if len(chunk) >= chunk_size:
                yield "[" + ",".join(chunk) + "]"
                chunk.clear()

        if chunk:
            yield "[" + ",".join(chunk) + "]"

        jq_err = proc.stderr.read().strip()
        if proc.wait() != 0:
            raise RuntimeError(f"jq failed: {jq_err}")
    finally:
        if proc.poll() is None:
            proc.terminate()
            proc.wait()


def merge_stream_results(chunk_results):
    all_results = []
    for chunk_result in chunk_results:
        try:
            result_data = loads(chunk_result)
            if isinstance(result_data, list):
                all_results.extend(result_data)
            else:
                all_results.append(result_data)
        except json.JSONDecodeError:
            all_results.append(chunk_result)

    if all(isinstance(r, (dict, list)) for r in all_results):
        return dumps(all_results)
    return "\n".join(str(r) for r in all_results)


def process_json_streaming_inline(json_file, process_func, chunk_size=1000):
    try:
        chunk_results = []
        for chunk_json in iter_json_array_chunks(json_file, chunk_size=chunk_size):
            chunk_results.append(process_func(chunk_json))
        return merge_stream_results(chunk_results)
    except Exception as e:
        logger.error(f"Error in streaming process: {str(e)}")
        raise


def process_json_streaming(json_file, process_func, chunk_size=1000):
    if not detect_json_structure(json_file):
        raise ValueError(
            "Streaming mode only works with JSON files containing an array at the root level"
        )

    try:
        temp_dir, chunk_files = split_json_array(json_file, chunk_size)

        all_results = []
        for chunk_file in chunk_files:
            logger.info(f"Processing chunk: {chunk_file}")
            chunk_result = process_func(chunk_file)

            try:
                result_data = loads(chunk_result)
                if isinstance(result_data, list):
                    all_results.extend(result_data)
                else:
                    all_results.append(result_data)
            except json.JSONDecodeError:
                all_results.append(chunk_result)

        shutil.rmtree(temp_dir)

        if all(isinstance(r, (dict, list)) for r in all_results):
            return dumps(all_results)
        else:
            return "\n".join(str(r) for r in all_results)

    except Exception as e:
        logger.error(f"Error in streaming process: {str(e)}")
        raise


async def split_json_array_async(json_file, chunk_size=1000):
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, split_json_array, json_file, chunk_size)


async def iter_json_array_chunks_async(json_file, chunk_size=1000):
    if not detect_json_structure(json_file):
        raise ValueError(
            "Streaming mode only works with JSON files containing an array at the root level"
        )

    proc = await asyncio.create_subprocess_exec(
        "jq",
        "-c",
        ".[]",
        json_file,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )

    chunk: list[str] = []
    try:
        while True:
            line = await proc.stdout.readline()
            if not line:
                break
            item = line.decode().strip()
            if not item:
                continue
            chunk.append(item)
            if len(chunk) >= chunk_size:
                yield "[" + ",".join(chunk) + "]"
                chunk.clear()

        if chunk:
            yield "[" + ",".join(chunk) + "]"

        jq_err = (await proc.stderr.read()).decode().strip()
        if await proc.wait() != 0:
            raise RuntimeError(f"jq failed: {jq_err}")
    finally:
        if proc.returncode is None:
            proc.terminate()
            await proc.wait()


async def process_json_streaming_inline_async(json_file, process_func, chunk_size=1000):
    try:
        chunk_results = []
        async for chunk_json in iter_json_array_chunks_async(
            json_file, chunk_size=chunk_size
        ):
            chunk_results.append(await process_func(chunk_json))
        return merge_stream_results(chunk_results)
    except Exception as e:
        logger.error(f"Error in streaming process: {str(e)}")
        raise


async def process_json_streaming_async(json_file, process_func, chunk_size=1000):
    if not detect_json_structure(json_file):
        raise ValueError(
            "Streaming mode only works with JSON files containing an array at the root level"
        )

    try:
        temp_dir, chunk_files = await split_json_array_async(json_file, chunk_size)

        tasks = []
        for chunk_file in chunk_files:
            logger.info(f"Processing chunk: {chunk_file}")
            task = process_func(chunk_file)
            tasks.append(task)

        chunk_results = await asyncio.gather(*tasks)

        all_results = []
        for chunk_result in chunk_results:
            try:
                result_data = loads(chunk_result)
                if isinstance(result_data, list):
                    all_results.extend(result_data)
                else:
                    all_results.append(result_data)
            except json.JSONDecodeError:
                all_results.append(chunk_result)

        shutil.rmtree(temp_dir)

        if all(isinstance(r, (dict, list)) for r in all_results):
            return dumps(all_results)
        else:
            return "\n".join(str(r) for r in all_results)

    except Exception as e:
        logger.error(f"Error in streaming process: {str(e)}")
        raise
