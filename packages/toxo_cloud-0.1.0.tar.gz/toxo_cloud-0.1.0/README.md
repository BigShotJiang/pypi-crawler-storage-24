# toxo-cloud

Lightweight Python client and CLI for TOXO Cloud.

`toxo-cloud` is a connector package:
- your `.toxo` file stays with you
- your API key stays with you
- all heavy processing runs in TOXO Cloud infrastructure

## Install

```bash
pip install toxo-cloud
```

## Python usage

```python
from toxo_cloud import ToxoCloudClient

client = ToxoCloudClient(
    api_key="YOUR_API_KEY",
)

response = client.query(
    layer="finance_expert.toxo",
    question="Explain inflation in simple words."
)
print(response)
```

## CLI usage

```bash
toxo-cloud health
toxo-cloud query my_layer.toxo "What can you do?" --api-key "$GEMINI_API_KEY"
toxo-cloud ask-doc my_layer.toxo ./report.pdf "Summarize this report" --api-key "$GEMINI_API_KEY"
```

## Supported endpoints

- `GET /`
- `GET /health`
- `POST /v1/query`
- `POST /v1/query_multimodal`
- `POST /v1/feedback`
- `POST /v1/train_from_data`
- `POST /v1/train/extract_contexts`
- `POST /v1/rag/index`
- `POST /v1/rag/query`
- `POST /v1/agent/run`
# toxo-cloud
