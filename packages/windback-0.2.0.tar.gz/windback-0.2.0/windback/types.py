from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Literal, Optional


PaymentProvider = Literal[
    "stripe",
    "razorpay",
    "paypal",
    "wise",
    "paddle",
    "polar",
    "dodo",
    "chargebee",
    "lemonsqueezy",
    "custom",
]

# Each value maps to a specific winback email strategy that Windback selects automatically.
CancelReason = Literal[
    "too_expensive",
    "missing_features",
    "not_using_enough",
    "switching_competitor",
    "technical_issues",
    "poor_support",
    "dont_need_anymore",
    "other",
]


@dataclass
class ChurnEventInput:
    """
    Input for tracking a churn event.

    Stores the event in Windback but does NOT automatically send an email.
    Use CancelFlowInput + submit_cancel_flow for automatic AI + email.
    """

    email: str
    """Customer's email address."""

    provider: PaymentProvider
    """Payment provider name."""

    mrr: int
    """Monthly recurring revenue in cents (e.g. 4900 = $49.00)."""

    name: Optional[str] = None
    """Customer's full name."""

    provider_customer_id: Optional[str] = None
    """Customer ID from the payment provider."""

    provider_subscription_id: Optional[str] = None
    """Subscription ID from the payment provider."""

    plan_name: Optional[str] = None
    """Subscription plan name (e.g. 'Pro', 'Starter')."""

    currency: str = "USD"
    """ISO 4217 currency code."""

    tenure_days: Optional[int] = None
    """Number of days since the customer first subscribed."""

    last_active_at: Optional[str] = None
    """ISO 8601 timestamp of customer's last activity."""

    cancel_reason: Optional[CancelReason] = None
    """Structured reason the customer cancelled."""

    cancel_reason_text: Optional[str] = None
    """Free-text elaboration on the cancel reason."""

    notes: Optional[str] = None
    """Any additional internal notes about the cancellation."""

    def to_api_payload(self) -> dict:
        payload: dict = {
            "customer_email": self.email,
            "provider": self.provider,
            "mrr": self.mrr,
            "currency": self.currency,
            "provider_customer_id": self.provider_customer_id or "",
            "provider_subscription_id": self.provider_subscription_id or "",
        }
        if self.name is not None:
            payload["customer_name"] = self.name
        if self.plan_name is not None:
            payload["plan_name"] = self.plan_name
        if self.tenure_days is not None:
            payload["tenure_days"] = self.tenure_days
        if self.last_active_at is not None:
            payload["last_active_at"] = self.last_active_at
        if self.cancel_reason is not None:
            payload["cancel_reason"] = self.cancel_reason
        if self.cancel_reason_text is not None:
            payload["cancel_reason_text"] = self.cancel_reason_text
        if self.notes is not None:
            payload["notes"] = self.notes
        return payload


@dataclass
class CancelFlowInput:
    """
    Input for the all-in-one cancel flow endpoint.

    Windback creates the event, picks the best winback strategy for the reason,
    and sends the recovery email automatically.
    """

    email: str
    """Customer's email address."""

    provider: PaymentProvider
    """Payment provider name."""

    mrr: int
    """Monthly recurring revenue in cents."""

    currency: str
    """ISO 4217 currency code."""

    cancel_reason: CancelReason
    """Why the customer is cancelling."""

    cancel_reason_text: Optional[str] = None
    """Free-text elaboration on the cancel reason."""

    name: Optional[str] = None
    """Customer's full name."""

    plan_name: Optional[str] = None
    """Subscription plan name."""

    tenure_days: Optional[int] = None
    """Number of days since the customer first subscribed."""

    def to_api_payload(self) -> dict:
        payload: dict = {
            "customer_email": self.email,
            "provider": self.provider,
            "mrr": self.mrr,
            "currency": self.currency,
            "cancel_reason": self.cancel_reason,
        }
        if self.cancel_reason_text is not None:
            payload["cancel_reason_text"] = self.cancel_reason_text
        if self.name is not None:
            payload["customer_name"] = self.name
        if self.plan_name is not None:
            payload["plan_name"] = self.plan_name
        if self.tenure_days is not None:
            payload["tenure_days"] = self.tenure_days
        return payload


@dataclass
class CancelReasonInput:
    """Input for reporting a cancel reason on an existing churn event."""

    cancel_reason: CancelReason
    """Why the customer cancelled."""

    cancel_reason_text: Optional[str] = None
    """Free-text elaboration on the cancel reason."""

    def to_api_payload(self) -> dict:
        payload: dict = {"cancel_reason": self.cancel_reason}
        if self.cancel_reason_text is not None:
            payload["cancel_reason_text"] = self.cancel_reason_text
        return payload


@dataclass
class RecoveryVariant:
    """An AI-generated recovery email variant."""

    id: str
    strategy: str
    subject: str
    body: str
    churn_event_id: Optional[str] = None
    coupon_code: Optional[str] = None
    coupon_percent: Optional[int] = None
    sent_at: Optional[str] = None
    opened_at: Optional[str] = None
    clicked_at: Optional[str] = None
    created_at: Optional[str] = None


@dataclass
class ChurnEventResponse:
    """Response from the Windback API after tracking a churn event."""

    id: str
    status: str
    customer_email: str
    provider: str
    mrr: int
    currency: str
    created_at: str
    customer_name: Optional[str] = None
    cancel_reason: Optional[str] = None
    provider_customer_id: Optional[str] = None
    provider_subscription_id: Optional[str] = None
    plan_name: Optional[str] = None
    tenure_days: Optional[int] = None
    last_active_at: Optional[str] = None
    updated_at: Optional[str] = None
    variants: List[RecoveryVariant] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict) -> ChurnEventResponse:
        variants = [
            RecoveryVariant(
                id=v["id"],
                strategy=v.get("strategy", ""),
                subject=v["subject"],
                body=v["body"],
                churn_event_id=v.get("churn_event_id"),
                coupon_code=v.get("coupon_code"),
                coupon_percent=v.get("coupon_percent"),
                sent_at=v.get("sent_at"),
                opened_at=v.get("opened_at"),
                clicked_at=v.get("clicked_at"),
                created_at=v.get("created_at"),
            )
            for v in data.get("variants", [])
        ]
        return cls(
            id=data["id"],
            status=data["status"],
            customer_email=data["customer_email"],
            provider=data["provider"],
            mrr=data["mrr"],
            currency=data["currency"],
            created_at=data["created_at"],
            customer_name=data.get("customer_name"),
            cancel_reason=data.get("cancel_reason"),
            provider_customer_id=data.get("provider_customer_id"),
            provider_subscription_id=data.get("provider_subscription_id"),
            plan_name=data.get("plan_name"),
            tenure_days=data.get("tenure_days"),
            last_active_at=data.get("last_active_at"),
            updated_at=data.get("updated_at"),
            variants=variants,
        )


@dataclass
class CancelFlowResponse:
    """Response from the cancel flow submit endpoint."""

    churn_event_id: str
    status: str
    message: str

    @classmethod
    def from_dict(cls, data: dict) -> CancelFlowResponse:
        return cls(
            churn_event_id=data["churn_event_id"],
            status=data["status"],
            message=data["message"],
        )


@dataclass
class UpdateVariantInput:
    """Input for editing a recovery variant's subject and body before sending."""

    subject: str
    """Updated email subject line."""

    body: str
    """Updated email body."""

    def to_api_payload(self) -> dict:
        return {"subject": self.subject, "body": self.body}


@dataclass
class RecoveryTemplate:
    """A custom email template for a specific cancel reason."""

    id: str
    project_id: str
    cancel_reason: str
    name: str
    subject: str
    body: str
    is_active: bool
    created_at: str
    updated_at: str

    @classmethod
    def from_dict(cls, data: dict) -> RecoveryTemplate:
        return cls(
            id=data["id"],
            project_id=data["project_id"],
            cancel_reason=data["cancel_reason"],
            name=data["name"],
            subject=data["subject"],
            body=data["body"],
            is_active=data["is_active"],
            created_at=data["created_at"],
            updated_at=data["updated_at"],
        )


@dataclass
class CreateTemplateInput:
    """Input for creating a new custom email template."""

    cancel_reason: CancelReason
    """The cancel reason this template should handle."""

    name: str
    """A human-readable name for the template."""

    subject: str
    """Email subject — supports {{customer_name}}, {{plan_name}}, {{cancel_reason}}, {{customer_email}}."""

    body: str
    """Email body — supports the same template variables."""

    is_active: bool = True
    """Whether to immediately activate this template (replaces AI for this cancel reason)."""

    def to_api_payload(self) -> dict:
        return {
            "cancel_reason": self.cancel_reason,
            "name": self.name,
            "subject": self.subject,
            "body": self.body,
            "is_active": self.is_active,
        }


@dataclass
class UpdateTemplateInput:
    """Input for updating an existing custom email template. All fields are optional."""

    name: Optional[str] = None
    subject: Optional[str] = None
    body: Optional[str] = None
    is_active: Optional[bool] = None

    def to_api_payload(self) -> dict:
        payload: dict = {}
        if self.name is not None:
            payload["name"] = self.name
        if self.subject is not None:
            payload["subject"] = self.subject
        if self.body is not None:
            payload["body"] = self.body
        if self.is_active is not None:
            payload["is_active"] = self.is_active
        return payload
