from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import Any, Callable, Dict, Generic, List, Optional, TypeVar

import httpx

from windback.types import (
    ChurnEventInput,
    ChurnEventResponse,
    CancelFlowInput,
    CancelFlowResponse,
    CancelReasonInput,
    UpdateVariantInput,
    RecoveryTemplate,
    CreateTemplateInput,
    UpdateTemplateInput,
)

DEFAULT_BASE_URL = "https://api.windbackai.com"
DEFAULT_TIMEOUT = 10.0
DEFAULT_RETRIES = 2

logger = logging.getLogger("windback")

T = TypeVar("T")


class WindbackError(Exception):
    """Raised when the Windback API returns an error."""

    def __init__(self, message: str, status: int = 0) -> None:
        self.status = status
        super().__init__(f"Windback: {message}")


@dataclass
class SafeResult(Generic[T]):
    """
    Result wrapper returned by safe-mode methods.
    Check ``ok`` before accessing ``data``.
    """

    ok: bool
    data: Optional[T]
    error: Optional[WindbackError]


class Windback:
    """
    Official Windback Python SDK.

    **Safe by default** — all methods return a ``SafeResult`` and will
    NEVER raise exceptions that could crash your application.

    Usage::

        from windback import Windback

        pb = Windback("sk_live_your_api_key")

        # All-in-one: submit cancel reason and get winback email sent automatically
        result = pb.submit_cancel_flow(
            email="jane@company.com",
            provider="stripe",
            mrr=4900,
            currency="USD",
            cancel_reason="too_expensive",
        )

        # Or with project-scoped methods (requires project_slug):
        pb = Windback("sk_live_your_api_key", project_slug="my-saas")
        pb.track_churn(email="jane@company.com", provider="stripe", mrr=4900)

    To opt into exceptions (advanced)::

        pb = Windback("sk_live_your_api_key", safe=False)
        # Now methods raise WindbackError on failure
    """

    def __init__(
        self,
        api_key: str,
        *,
        project_slug: str = "",
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        retries: int = DEFAULT_RETRIES,
        safe: bool = True,
        on_error: Optional[Callable[[WindbackError], None]] = None,
    ) -> None:
        self._safe = safe
        self._on_error = on_error
        self._api_key = api_key
        self._project_slug = project_slug
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._retries = retries

        if not api_key:
            if self._safe:
                logger.warning("[Windback] API key is missing. SDK calls will be no-ops.")
                self._client = None
                return
            raise ValueError("Windback: API key is required")

        self._client: Optional[httpx.Client] = httpx.Client(
            base_url=self._base_url,
            timeout=self._timeout,
            headers={
                "Content-Type": "application/json",
                "X-API-Key": self._api_key,
                "User-Agent": "windback-python/0.2.0",
            },
        )

    # ── Project-scoped path helper ─────────────────────────────────────────────

    def _project_path(self, suffix: str) -> str:
        if not self._project_slug:
            raise WindbackError(
                "project_slug is required for this method — pass it in the constructor"
            )
        return f"/api/v1/projects/{self._project_slug}{suffix}"

    # ── Public Methods ─────────────────────────────────────────────────────────

    def track_churn(
        self,
        input: Optional[ChurnEventInput] = None,
        /,
        **kwargs: Any,
    ) -> SafeResult[ChurnEventResponse]:
        """
        Track a churn event when a customer cancels their subscription.
        Stores the event but does NOT automatically send an email.
        Use submit_cancel_flow for the all-in-one flow with automatic AI + email.

        Requires ``project_slug`` in the constructor.
        """
        try:
            if input is None:
                input = ChurnEventInput(**kwargs)
            self._validate(input)
            path = self._project_path("/churn-events")
            data = self._request("POST", path, json=input.to_api_payload())
            return SafeResult(ok=True, data=ChurnEventResponse.from_dict(data), error=None)
        except Exception as exc:
            return self._handle_safe_error(exc)

    def submit_cancel_flow(
        self,
        input: Optional[CancelFlowInput] = None,
        /,
        **kwargs: Any,
    ) -> SafeResult[CancelFlowResponse]:
        """
        All-in-one cancel flow. Accepts the customer's cancel reason, creates the
        churn event, runs AI to pick the best winback email variant, and sends it
        automatically. Returns immediately — processing runs in the background.

        Does NOT require ``project_slug`` — the project is derived from the API key.
        """
        try:
            if input is None:
                input = CancelFlowInput(**kwargs)
            data = self._request("POST", "/api/v1/cancel-flow/submit", json=input.to_api_payload())
            return SafeResult(ok=True, data=CancelFlowResponse.from_dict(data), error=None)
        except Exception as exc:
            return self._handle_safe_error(exc)

    def report_cancel_reason(
        self,
        event_id: str,
        input: Optional[CancelReasonInput] = None,
        /,
        **kwargs: Any,
    ) -> SafeResult[None]:
        """
        Attach a cancel reason to an existing churn event (e.g. one created
        automatically by a payment webhook) and trigger the AI → email pipeline.

        Requires ``project_slug`` in the constructor.
        """
        try:
            if input is None:
                input = CancelReasonInput(**kwargs)
            path = self._project_path(f"/churn-events/{event_id}/cancel-reason")
            self._request("PATCH", path, json=input.to_api_payload())
            return SafeResult(ok=True, data=None, error=None)
        except Exception as exc:
            return self._handle_safe_error(exc)

    def get_event(self, event_id: str) -> SafeResult[ChurnEventResponse]:
        """
        Get a churn event by ID.
        Requires ``project_slug`` in the constructor.
        """
        try:
            path = self._project_path(f"/churn-events/{event_id}")
            data = self._request("GET", path)
            return SafeResult(ok=True, data=ChurnEventResponse.from_dict(data), error=None)
        except Exception as exc:
            return self._handle_safe_error(exc)

    def generate_variants(self, event_id: str) -> SafeResult[ChurnEventResponse]:
        """
        Trigger AI variant generation for a churn event.
        Requires ``project_slug`` in the constructor.
        """
        try:
            path = self._project_path(f"/churn-events/{event_id}/generate")
            data = self._request("POST", path)
            return SafeResult(ok=True, data=ChurnEventResponse.from_dict(data), error=None)
        except Exception as exc:
            return self._handle_safe_error(exc)

    def send_variant(self, event_id: str, variant_id: str) -> SafeResult[None]:
        """
        Send a specific recovery email variant.
        Requires ``project_slug`` in the constructor.
        """
        try:
            path = self._project_path(f"/churn-events/{event_id}/variants/{variant_id}/send")
            self._request("POST", path)
            return SafeResult(ok=True, data=None, error=None)
        except Exception as exc:
            return self._handle_safe_error(exc)

    def update_variant(
        self,
        event_id: str,
        variant_id: str,
        input: Optional[UpdateVariantInput] = None,
        /,
        **kwargs: Any,
    ) -> SafeResult[None]:
        """
        Edit a recovery variant's subject and/or body before sending.
        Only works on variants that have not been sent yet.

        Requires ``project_slug`` in the constructor.
        """
        try:
            if input is None:
                input = UpdateVariantInput(**kwargs)
            path = self._project_path(f"/churn-events/{event_id}/variants/{variant_id}")
            self._request("PATCH", path, json=input.to_api_payload())
            return SafeResult(ok=True, data=None, error=None)
        except Exception as exc:
            return self._handle_safe_error(exc)

    # ── Recovery Templates ─────────────────────────────────────────────────────

    def list_templates(self) -> SafeResult[List[RecoveryTemplate]]:
        """
        List all custom email templates for the project.
        Requires ``project_slug`` in the constructor.
        """
        try:
            path = self._project_path("/recovery-templates")
            data = self._request("GET", path)
            templates = [RecoveryTemplate.from_dict(t) for t in (data if isinstance(data, list) else [])]
            return SafeResult(ok=True, data=templates, error=None)
        except Exception as exc:
            return self._handle_safe_error(exc)

    def create_template(
        self,
        input: Optional[CreateTemplateInput] = None,
        /,
        **kwargs: Any,
    ) -> SafeResult[RecoveryTemplate]:
        """
        Create a custom email template for a specific cancel reason.
        When active, this template replaces AI generation for that reason.

        Supports template variables: ``{{customer_name}}``, ``{{customer_email}}``,
        ``{{plan_name}}``, ``{{cancel_reason}}``.

        Requires ``project_slug`` in the constructor.
        """
        try:
            if input is None:
                input = CreateTemplateInput(**kwargs)
            path = self._project_path("/recovery-templates")
            data = self._request("POST", path, json=input.to_api_payload())
            return SafeResult(ok=True, data=RecoveryTemplate.from_dict(data), error=None)
        except Exception as exc:
            return self._handle_safe_error(exc)

    def get_template(self, template_id: str) -> SafeResult[RecoveryTemplate]:
        """
        Get a single custom email template by ID.
        Requires ``project_slug`` in the constructor.
        """
        try:
            path = self._project_path(f"/recovery-templates/{template_id}")
            data = self._request("GET", path)
            return SafeResult(ok=True, data=RecoveryTemplate.from_dict(data), error=None)
        except Exception as exc:
            return self._handle_safe_error(exc)

    def update_template(
        self,
        template_id: str,
        input: Optional[UpdateTemplateInput] = None,
        /,
        **kwargs: Any,
    ) -> SafeResult[RecoveryTemplate]:
        """
        Update an existing custom email template.
        Requires ``project_slug`` in the constructor.
        """
        try:
            if input is None:
                input = UpdateTemplateInput(**kwargs)
            path = self._project_path(f"/recovery-templates/{template_id}")
            data = self._request("PUT", path, json=input.to_api_payload())
            return SafeResult(ok=True, data=RecoveryTemplate.from_dict(data), error=None)
        except Exception as exc:
            return self._handle_safe_error(exc)

    def delete_template(self, template_id: str) -> SafeResult[None]:
        """
        Delete a custom email template.
        Requires ``project_slug`` in the constructor.
        """
        try:
            path = self._project_path(f"/recovery-templates/{template_id}")
            self._request("DELETE", path)
            return SafeResult(ok=True, data=None, error=None)
        except Exception as exc:
            return self._handle_safe_error(exc)

    def close(self) -> None:
        """Close the underlying HTTP client."""
        if self._client is not None:
            self._client.close()

    def __enter__(self) -> Windback:
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    # ── Internal ───────────────────────────────────────────────────────────────

    def _handle_safe_error(self, exc: Exception) -> SafeResult:
        if isinstance(exc, WindbackError):
            pb_error = exc
        else:
            pb_error = WindbackError(str(exc))

        if self._on_error is not None:
            try:
                self._on_error(pb_error)
            except Exception:
                pass

        if self._safe:
            logger.warning("[Windback] %s (status: %d)", pb_error, pb_error.status)
            return SafeResult(ok=False, data=None, error=pb_error)

        raise pb_error from exc

    def _validate(self, input: ChurnEventInput) -> None:
        if not input.email or "@" not in input.email:
            raise WindbackError("valid email is required")
        if not input.provider:
            raise WindbackError("provider is required")
        if not isinstance(input.mrr, int) or input.mrr < 0:
            raise WindbackError("mrr must be a non-negative integer (in cents)")

    def _request(
        self,
        method: str,
        path: str,
        json: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        if self._client is None:
            raise WindbackError("API key is missing")

        last_error: Optional[Exception] = None

        for attempt in range(self._retries + 1):
            try:
                response = self._client.request(method, path, json=json)

                if response.status_code >= 400:
                    try:
                        body = response.json()
                        msg = body.get("message", f"HTTP {response.status_code}")
                    except Exception:
                        msg = f"HTTP {response.status_code}"
                    raise WindbackError(msg, response.status_code)

                if not response.text:
                    return {}
                return response.json()

            except WindbackError as e:
                if e.status < 500:
                    raise  # don't retry client errors
                last_error = e

            except httpx.HTTPError as e:
                last_error = WindbackError(str(e))

            if attempt < self._retries:
                time.sleep((2**attempt) * 0.5)

        raise last_error or WindbackError("request failed")
