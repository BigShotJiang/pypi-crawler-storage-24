from fastapi import FastAPI
from fastapi.responses import StreamingResponse

from sneakydog_object_storage_service.async_client import AsyncOSSClient
from sneakydog_object_storage_service.base import ObjectInfo
from sneakydog_object_storage_service.client import OSSClient
from sneakydog_object_storage_service.config import OSSConfig

# 初始化同步客户端
config = OSSConfig(
    default_backend="minio",
    backends={
        "local": {"type": "local", "root_path": "./storage"},
        "minio": {
            "type": "minio",
            "endpoint": "127.0.0.1:9000", #不要用localhost 会卡20s
            "access_key": "appuser",
            "secret_key": "appsecret123",
            "bucket_name": "yolo-bucket",
            "secure": False,
        },
        # "minio": {
        #     "type": "minio",
        #     "endpoint": "play.min.io",
        #     "access_key": "Q3AM3UQ867SPQQA43P2F",
        #     "secret_key": "zuf+tfteSlswRu7BJ86wekitnifILbZam1KYY3TG",
        #     "bucket_name": "my-bucket",
        #     "secure": True,
        # },
        "rustfs": {
            "type": "rustfs",
            "endpoint": "play.rustfs.com",
            "access_key": "QZdNJEF8KkudQlwRAib1",
            "secret_key": "w0fy2OLLJsZr9tSOYpI6u3t6NMKIdVpS1H8gY3WP",
            "bucket_name": "my-bucket",
            "secure": True,
            "create_bucket_if_not_exists": True,
        },
    },
)

sync_client = OSSClient(config=config)
storage_async = AsyncOSSClient(sync_client)

app = FastAPI()


@app.get("/")
async def index() -> str:  # noqa: N802
    return "ok"


@app.get("/imageUrl")
async def imageUrl() -> StreamingResponse:  # noqa: N802
    object_name = "屏幕截图 2025-11-26 220459.png"
    # object_name = "8ab6909a-75d6-4177-8f72-4e4968501763_thumbnail.webp"
    stream = storage_async.get_object_stream(object_name)
    objectinfo: ObjectInfo = await storage_async.get_object_info(object_name)
    return StreamingResponse(stream, media_type="image/jpeg",headers={
        "Content-Length": str(objectinfo.size)
    })


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        app,
        host="0.0.0.0",
        port=7000,
    )
