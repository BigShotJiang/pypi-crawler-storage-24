from typing import BinaryIO


def get_file_size(file: BinaryIO) -> int:
    """获取 BinaryIO 大小，不依赖 fileno"""
    pos = file.tell()
    file.seek(0, 2)  # 移到末尾
    size = file.tell()
    file.seek(pos)  # 恢复指针
    return size
