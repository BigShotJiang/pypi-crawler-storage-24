from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any, BinaryIO, Dict, Iterator, Optional


@dataclass
class ObjectInfo:
    """对象元信息"""

    key: str
    size: int
    last_modified: datetime
    etag: Optional[str] = None
    content_type: Optional[str] = None
    metadata: Optional[dict[str, str]] = None


@dataclass
class StorageConfig:
    """存储配置"""

    backend_type: str
    name: str
    config: dict[str, Any]


class StorageBackend(ABC):
    """存储后端抽象基类

    Args:
        ABC (_type_): _description_
    """

    def __init__(self, config: StorageConfig) -> None:
        """初始化

        Args:
            config (StorageConfig): _description_
        """
        self.name = config.name
        self.backend_type = config.backend_type
        self.config = config.config

    @abstractmethod
    def put_object(
        self,
        key: str,
        data: BinaryIO,
        content_type: Optional[str] = None,
        metadata: Optional[dict[str, str]] = None,
    ) -> bool:
        """上传文件

        Args:
            key (str): _description_
            data (bytes): _description_
            content_type (Optional[str], optional): _description_. Defaults to None.
            metadata (Optional[dict[str, str]], optional): _description_. Defaults to None.

        Returns:
            bool: _description_
        """
        pass

    @abstractmethod
    def get_object(self, key: str) -> bytes:
        """下载文件

        Args:
            key (str): _description_

        Returns:
            bytes: _description_
        """
        pass

    @abstractmethod
    def get_object_stream(self, key: str, chunk_size: int = 8 * 1024) -> Iterator[bytes]:
        """下载文件流

        Args:
            key (str): _description_
            chunk_size (int, optional): _description_. Defaults to 8*1024.

        Yields:
            Iterator[bytes]: _description_
        """
        pass

    @abstractmethod
    def delete(self, key: str) -> bool:
        """删除文件

        Args:
            key (str): _description_

        Returns:
            bool: _description_
        """
        pass

    @abstractmethod
    def exists(self, key: str) -> bool:
        """检查文件是否存在

        Args:
            key (str): _description_

        Returns:
            bool: _description_
        """
        pass

    @abstractmethod
    def list_objects(self, prefix: Optional[str] = None, max_keys: int = 1000) -> list[ObjectInfo]:
        """列出对象

        Args:
            prefix (Optional[str], optional): _description_. Defaults to None.
            max_keys (int, optional): _description_. Defaults to 1000.

        Returns:
            list[ObjectInfo]: _description_
        """
        pass

    @abstractmethod
    def get_object_info(self, key: str) -> ObjectInfo:
        """获取对象元信息

        Args:
            key (str): _description_

        Returns:
            ObjectInfo: _description_
        """
        pass

    @abstractmethod
    def presigned_url(self, key: str, expires_in: timedelta = timedelta(days=7)) -> str:
        """生成预签名 URL

        Args:
            key (str): _description_
            expires_in (timedelta, optional): _description_. Defaults to timedelta(days=7).

        Returns:
            str: _description_
        """
        pass

    @abstractmethod
    def initiate_multipart_upload(
        self,
        key: str,
        content_type: Optional[str] = None,
        metadata: Optional[Dict[str, str]] = None,
    ) -> str:
        """初始化分片上传

        Args:
            key (str): _description_
            content_type (Optional[str], optional): _description_. Defaults to None.
            metadata (Optional[Dict[str, str]], optional): _description_. Defaults to None.

        Returns:
            str: _description_
        """
        pass

    @abstractmethod
    def upload_part(self, key: str, upload_id: str, part_number: int, bytes_data: bytes) -> str:
        """上传单片

        Args:
            key (str): _description_
            upload_id (str): _description_
            part_number (int): _description_
            bytes_data (_type_): _description_

        Returns:
            str: _description_
        """
        pass

    @abstractmethod
    def complete_multipart_upload(self, key: str, upload_id: str, parts: list) -> str:
        """完成分片上传

        Args:
            key (str): _description_
            upload_id (str): _description_
            parts (list): _description_

        Returns:
            str: _description_
        """
        pass

    @abstractmethod
    def abort_multipart_upload(self, key: str, upload_id: str) -> bool:
        """中止分片上传

        Args:
            key (str): _description_
            upload_id (str): _description_

        Returns:
            bool: _description_
        """
        pass
