"""CloudSense Upgrade Compass - MCP server for upgrade assessment and analysis."""

__version__ = "0.10.3"
