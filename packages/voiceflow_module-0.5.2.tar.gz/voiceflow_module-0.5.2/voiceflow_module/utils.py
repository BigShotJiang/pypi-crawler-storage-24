import requests
import xmltodict
import tiktoken


def get_structered_xml(url: str, proxy: str = None):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
    }

    proxies = {'http': proxy, 'https': proxy} if proxy else None
    response = requests.get(url, headers=headers, proxies=proxies)
    xml_content = response.content
    parsed_data = xmltodict.parse(xml_content)
    return parsed_data


def split_text_into_chunks(text: str, title: str, url: str, chunk_size=500, overlap=100):
    encoding = tiktoken.get_encoding("cl100k_base")
    tokens = encoding.encode(text)
    size = len(tokens)
    step = chunk_size - overlap
    
    chunks = []
    for i in range(0, size, step):
        chunk_tokens = tokens[i:i + chunk_size]
        chunk_text = encoding.decode(chunk_tokens)
        
        chunks.append({
            "Tema": title,
            "Informacija": chunk_text,
            "url": url
        })
    
    return chunks