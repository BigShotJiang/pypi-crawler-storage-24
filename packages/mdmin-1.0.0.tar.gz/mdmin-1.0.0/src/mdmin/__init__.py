"""
mdmin — Rule-based markdown compression for LLM consumption.

Basic usage::

    from mdmin import compress, estimate_tokens

    result = compress(text, level="medium")
    print(result.output)
    print(result.stats)  # CompressResult with .input_tokens, .saved, .pct …

"""

from mdmin.engine import compress, estimate_tokens, CompressResult, CompressionStats

__all__ = ["compress", "estimate_tokens", "CompressResult", "CompressionStats"]
__version__ = "1.0.0"
