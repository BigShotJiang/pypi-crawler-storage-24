"""Client for Amrood's transaction verification API."""

from __future__ import annotations

import httpx


_DEFAULT_BASE_URL = "https://amrood.io"


async def verify_payment(
    transaction_id: str,
    agent_key: str,
    expected_payee: str | None = None,
    expected_amount: float | None = None,
    nonce: str | None = None,
    base_url: str = _DEFAULT_BASE_URL,
) -> dict:
    """Verify a payment transaction via Amrood's API.

    Returns the verification response dict. Raises on network errors.
    """
    params: dict[str, str | float] = {}
    if expected_payee:
        params["expected_payee"] = expected_payee
    if expected_amount is not None:
        params["expected_amount"] = expected_amount
    if nonce:
        params["nonce"] = nonce

    async with httpx.AsyncClient(timeout=10) as client:
        resp = await client.get(
            f"{base_url}/v1/transactions/{transaction_id}/verify",
            params=params,
            headers={"x-agent-key": agent_key},
        )
        return resp.json()
