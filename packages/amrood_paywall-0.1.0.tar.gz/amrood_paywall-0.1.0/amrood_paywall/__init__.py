"""amrood-paywall — x402-style HTTP 402 paywall for INR payments via Amrood."""

__version__ = "0.1.0"

from amrood_paywall.middleware import amrood_pay  # noqa: F401
