"""Tests for the structured fact system (FactStore, FactExtractor, FactInjector)."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import AsyncMock

import pytest

from lightclaw.agent.memory.fact_extractor import (
    FactCandidate,
    FactExtractor,
    _extract_json_from_text,
    _parse_conflict_response,
    _parse_extraction_response,
)
from lightclaw.agent.memory.fact_injector import FactInjector
from lightclaw.agent.memory.fact_store import FactStore

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def tmp_db_dir(tmp_path: Path) -> Path:
    """Create a temporary directory for the test database."""
    return tmp_path / "memory"


@pytest.fixture
async def fact_store(tmp_db_dir: Path) -> FactStore:
    """Create and start a FactStore with an in-memory-like temp dir."""
    store = FactStore(db_dir=tmp_db_dir)
    await store.start()
    yield store
    await store.close()


# ---------------------------------------------------------------------------
# FactStore tests
# ---------------------------------------------------------------------------


class TestFactStore:
    """Tests for FactStore CRUD and search operations."""

    @pytest.mark.asyncio
    async def test_add_and_get_fact(self, fact_store: FactStore) -> None:
        fact_id = await fact_store.add_fact(
            content="The user prefers dark mode",
            category="preference",
            source_turn_id="turn-001",
            importance=0.8,
        )
        assert fact_id > 0

        fact = await fact_store.get_fact(fact_id)
        assert fact is not None
        assert fact["content"] == "The user prefers dark mode"
        assert fact["category"] == "preference"
        assert fact["importance"] == 0.8
        assert fact["is_active"] == 1
        assert fact["access_count"] == 0

    @pytest.mark.asyncio
    async def test_update_fact(self, fact_store: FactStore) -> None:
        fact_id = await fact_store.add_fact(
            content="The user lives in Tokyo",
            category="biographical",
            source_turn_id="turn-001",
        )

        await fact_store.update_fact(
            fact_id=fact_id,
            new_content="The user lives in Berlin",
            source_turn_id="turn-002",
            reason="User relocated",
        )

        fact = await fact_store.get_fact(fact_id)
        assert fact is not None
        assert fact["content"] == "The user lives in Berlin"

        # Check history
        history = await fact_store.get_fact_history(fact_id)
        assert len(history) == 2
        actions = {h["action"] for h in history}
        assert actions == {"ADD", "UPDATE"}
        update_entry = next(h for h in history if h["action"] == "UPDATE")
        assert update_entry["old_content"] == "The user lives in Tokyo"
        assert update_entry["new_content"] == "The user lives in Berlin"

    @pytest.mark.asyncio
    async def test_delete_fact_soft(self, fact_store: FactStore) -> None:
        fact_id = await fact_store.add_fact(
            content="The user likes Java",
            category="technical",
            source_turn_id="turn-001",
        )

        await fact_store.delete_fact(
            fact_id=fact_id,
            source_turn_id="turn-002",
            reason="User no longer uses Java",
        )

        fact = await fact_store.get_fact(fact_id)
        assert fact is not None
        assert fact["is_active"] == 0

        # Should not appear in active facts
        active = await fact_store.get_all_active_facts()
        assert all(f["id"] != fact_id for f in active)

    @pytest.mark.asyncio
    async def test_get_all_active_facts(self, fact_store: FactStore) -> None:
        await fact_store.add_fact("Fact A", "general", "t1")
        await fact_store.add_fact("Fact B", "general", "t1")
        fid = await fact_store.add_fact("Fact C", "general", "t1")
        await fact_store.delete_fact(fid, "t2")

        active = await fact_store.get_all_active_facts()
        assert len(active) == 2

    @pytest.mark.asyncio
    async def test_search_by_text(self, fact_store: FactStore) -> None:
        await fact_store.add_fact("The user prefers Python for backend", "technical", "t1")
        await fact_store.add_fact("The user's name is Alex", "biographical", "t1")
        await fact_store.add_fact("The user likes hiking on weekends", "preference", "t1")

        results = await fact_store.search_facts_by_text("Python backend")
        assert len(results) >= 1
        assert any("Python" in r["content"] for r in results)

    @pytest.mark.asyncio
    async def test_search_by_embedding(self, fact_store: FactStore) -> None:
        # Simple 3-dim embeddings for testing
        await fact_store.add_fact(
            "The user prefers dark mode",
            "preference",
            "t1",
            embedding=[1.0, 0.0, 0.0],
        )
        await fact_store.add_fact(
            "The user likes Python",
            "technical",
            "t1",
            embedding=[0.0, 1.0, 0.0],
        )

        results = await fact_store.search_facts_by_embedding(
            query_embedding=[0.9, 0.1, 0.0],
            min_score=0.5,
        )
        assert len(results) >= 1
        assert results[0]["content"] == "The user prefers dark mode"

    @pytest.mark.asyncio
    async def test_increment_access(self, fact_store: FactStore) -> None:
        fid = await fact_store.add_fact("Test fact", "general", "t1")
        await fact_store.increment_access([fid])
        await fact_store.increment_access([fid])

        fact = await fact_store.get_fact(fid)
        assert fact is not None
        assert fact["access_count"] == 2

    @pytest.mark.asyncio
    async def test_count_active_facts(self, fact_store: FactStore) -> None:
        await fact_store.add_fact("A", "general", "t1")
        await fact_store.add_fact("B", "general", "t1")
        assert await fact_store.count_active_facts() == 2

    @pytest.mark.asyncio
    async def test_invalid_category_defaults_to_general(self, fact_store: FactStore) -> None:
        fid = await fact_store.add_fact("Test", "invalid_cat", "t1")
        fact = await fact_store.get_fact(fid)
        assert fact is not None
        assert fact["category"] == "general"

    @pytest.mark.asyncio
    async def test_facts_by_category(self, fact_store: FactStore) -> None:
        await fact_store.add_fact("Pref 1", "preference", "t1", importance=0.9)
        await fact_store.add_fact("Bio 1", "biographical", "t1")
        await fact_store.add_fact("Pref 2", "preference", "t1", importance=0.7)

        prefs = await fact_store.get_facts_by_category("preference")
        assert len(prefs) == 2
        # Sorted by importance desc
        assert prefs[0]["importance"] >= prefs[1]["importance"]


# ---------------------------------------------------------------------------
# Extraction parsing tests
# ---------------------------------------------------------------------------


class TestExtractionParsing:
    """Tests for LLM response parsing utilities."""

    def test_extract_json_from_code_fence(self) -> None:
        text = 'Some text\n```json\n[{"content": "hello"}]\n```\nMore text'
        result = _extract_json_from_text(text)
        assert result == '[{"content": "hello"}]'

    def test_extract_json_raw_array(self) -> None:
        text = 'Here are the facts: [{"content": "test"}]'
        result = _extract_json_from_text(text)
        data = json.loads(result)
        assert isinstance(data, list)

    def test_parse_extraction_response_valid(self) -> None:
        raw = json.dumps(
            [
                {"content": "User likes Python", "category": "technical", "importance": 0.7},
                {"content": "User is in Berlin", "category": "biographical", "importance": 0.9},
            ]
        )
        candidates = _parse_extraction_response(raw)
        assert len(candidates) == 2
        assert candidates[0].content == "User likes Python"
        assert candidates[0].category == "technical"
        assert candidates[1].importance == 0.9

    def test_parse_extraction_response_empty(self) -> None:
        candidates = _parse_extraction_response("[]")
        assert len(candidates) == 0

    def test_parse_extraction_response_invalid_json(self) -> None:
        candidates = _parse_extraction_response("not json at all")
        assert len(candidates) == 0

    def test_parse_conflict_response_add(self) -> None:
        candidate = FactCandidate("Test fact", "general", 0.5)
        raw = json.dumps(
            {
                "action": "ADD",
                "target_fact_id": None,
                "merged_content": None,
                "reason": "New fact",
            }
        )
        decision = _parse_conflict_response(raw, candidate)
        assert decision.action == "ADD"
        assert decision.target_fact_id is None

    def test_parse_conflict_response_update(self) -> None:
        candidate = FactCandidate("User moved to Berlin", "biographical", 0.8)
        raw = json.dumps(
            {
                "action": "UPDATE",
                "target_fact_id": 42,
                "merged_content": "The user lives in Berlin",
                "reason": "Location updated",
            }
        )
        decision = _parse_conflict_response(raw, candidate)
        assert decision.action == "UPDATE"
        assert decision.target_fact_id == 42
        assert decision.merged_content == "The user lives in Berlin"

    def test_parse_conflict_response_noop(self) -> None:
        candidate = FactCandidate("User likes Python", "technical", 0.7)
        raw = json.dumps(
            {
                "action": "NOOP",
                "target_fact_id": None,
                "merged_content": None,
                "reason": "Already known",
            }
        )
        decision = _parse_conflict_response(raw, candidate)
        assert decision.action == "NOOP"


# ---------------------------------------------------------------------------
# FactExtractor tests
# ---------------------------------------------------------------------------


class TestFactExtractor:
    """Tests for the extraction pipeline with mocked LLM."""

    @pytest.mark.asyncio
    async def test_process_turn_extracts_and_adds(self, fact_store: FactStore) -> None:
        """Full pipeline: extract a fact, no similar existing → ADD."""
        extraction_response = json.dumps(
            [
                {"content": "The user's name is Alice", "category": "biographical", "importance": 0.9},
            ]
        )

        call_count = 0

        async def mock_llm(system: str, user: str) -> str:
            nonlocal call_count
            call_count += 1
            return extraction_response

        extractor = FactExtractor(fact_store=fact_store, invoke_llm=mock_llm)
        result = await extractor.process_turn(
            user_message="Hi, my name is Alice and I work in Berlin.",
            assistant_message="Nice to meet you, Alice!",
            turn_id="turn-001",
        )

        assert result.candidates_extracted == 1
        assert len(result.decisions) == 1
        assert result.decisions[0].action == "ADD"

        # Verify fact was persisted
        facts = await fact_store.get_all_active_facts()
        assert len(facts) == 1
        assert facts[0]["content"] == "The user's name is Alice"

    @pytest.mark.asyncio
    async def test_process_turn_skips_short_messages(self, fact_store: FactStore) -> None:
        """Messages shorter than FACT_MIN_MESSAGE_LENGTH are skipped."""
        extractor = FactExtractor(fact_store=fact_store, invoke_llm=AsyncMock())
        result = await extractor.process_turn(
            user_message="ok",
            assistant_message="Great!",
            turn_id="turn-001",
        )
        assert result.candidates_extracted == 0

    @pytest.mark.asyncio
    async def test_process_turn_no_llm(self, fact_store: FactStore) -> None:
        """Returns error when no LLM is configured."""
        extractor = FactExtractor(fact_store=fact_store)
        result = await extractor.process_turn(
            user_message="Some long enough message for extraction",
            assistant_message="Response text here",
            turn_id="turn-001",
        )
        assert len(result.errors) == 1
        assert "No LLM" in result.errors[0]

    @pytest.mark.asyncio
    async def test_process_turn_update_existing(self, fact_store: FactStore) -> None:
        """When a similar fact exists, LLM decides UPDATE."""
        # Pre-populate with an existing fact
        await fact_store.add_fact(
            "The user lives in Tokyo",
            "biographical",
            "turn-000",
        )

        extraction_response = json.dumps(
            [
                {"content": "The user moved to Berlin", "category": "biographical", "importance": 0.8},
            ]
        )
        conflict_response = json.dumps(
            {
                "action": "UPDATE",
                "target_fact_id": 1,
                "merged_content": "The user lives in Berlin",
                "reason": "Location changed",
            }
        )

        call_count = 0

        async def mock_llm(system: str, user: str) -> str:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return extraction_response
            return conflict_response

        extractor = FactExtractor(fact_store=fact_store, invoke_llm=mock_llm)
        result = await extractor.process_turn(
            user_message="I just moved to Berlin from Tokyo, it is a big change.",
            assistant_message="That sounds exciting!",
            turn_id="turn-002",
        )

        assert len(result.decisions) == 1
        assert result.decisions[0].action == "UPDATE"

        # Verify the fact was updated
        fact = await fact_store.get_fact(1)
        assert fact is not None
        assert fact["content"] == "The user lives in Berlin"


# ---------------------------------------------------------------------------
# FactInjector tests
# ---------------------------------------------------------------------------


class TestFactInjector:
    """Tests for fact injection formatting."""

    @pytest.mark.asyncio
    async def test_empty_store_returns_empty(self, fact_store: FactStore) -> None:
        injector = FactInjector(fact_store=fact_store)
        block = await injector.get_relevant_facts_block()
        assert block == ""

    @pytest.mark.asyncio
    async def test_formats_facts_by_category(self, fact_store: FactStore) -> None:
        await fact_store.add_fact("User prefers vim", "preference", "t1", importance=0.8)
        await fact_store.add_fact("User's name is Bob", "biographical", "t1", importance=0.9)

        injector = FactInjector(fact_store=fact_store)
        block = await injector.get_relevant_facts_block()

        assert "<structured-facts>" in block
        assert "</structured-facts>" in block
        assert "## Biographical" in block
        assert "## Preferences" in block
        assert "User's name is Bob" in block
        assert "User prefers vim" in block

    @pytest.mark.asyncio
    async def test_cache_invalidation(self, fact_store: FactStore) -> None:
        await fact_store.add_fact("Fact A", "preference", "t1", importance=0.7)

        injector = FactInjector(fact_store=fact_store)
        block1 = await injector.get_relevant_facts_block(last_user_text="test")
        assert "Fact A" in block1

        # Add another fact and check cache returns stale
        await fact_store.add_fact("Fact B", "preference", "t2", importance=0.7)
        block2 = await injector.get_relevant_facts_block(
            last_user_text="test",
            extractor_last_modified_ms=0,
        )
        # Same query hash + same modified time → cached
        assert block2 == block1

        # Invalidate by updating modified time
        import time

        block3 = await injector.get_relevant_facts_block(
            last_user_text="test",
            extractor_last_modified_ms=int(time.time() * 1000),
        )
        assert "Fact B" in block3
