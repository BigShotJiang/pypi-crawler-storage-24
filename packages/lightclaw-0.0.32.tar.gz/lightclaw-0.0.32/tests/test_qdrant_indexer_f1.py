"""
Week1 F1 验收脚本：文件监听与索引
对标 openclaw: warmSession + chokidar watcher + deleteFileChunks

运行方式：
    cd finnie_0309
    python -m pytest tests/test_qdrant_indexer_f1.py -v -s

或直接运行：
    python tests/test_qdrant_indexer_f1.py
"""

from __future__ import annotations

import asyncio
import sys
import tempfile
from pathlib import Path

# 把 src 加入 path，方便直接运行
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from lightclaw.agent.memory.qdrant_indexer import QdrantMemoryIndexer, create_qdrant_indexer


# ── 辅助：无 embedding 的 dummy fn（FTS-only 模式）────────────────────────
async def _no_embedding(texts: list[str]) -> list[list[float]]:
    return [[] for _ in texts]


async def _make_indexer(working_dir: str, data_dir: str) -> QdrantMemoryIndexer:
    """创建 local mode 的 QdrantMemoryIndexer（FTS-only，无需 embedding API）。"""
    return await create_qdrant_indexer(
        working_dir=working_dir,
        embedding_fn=_no_embedding,
        qdrant_backend="local",
        qdrant_path=str(Path(data_dir) / "qdrant_data"),
        collection_name="test_lightclaw_memory",
        model_name="test-model",
        vector_dims=4,  # 最小维度，FTS-only 模式下不实际使用
        data_dir=data_dir,
    )


async def _fts_count(indexer: QdrantMemoryIndexer, path: str | None = None) -> int:
    """查询 FTS5 中指定 path（或全部）的 chunk 数量。"""
    if path:
        cur = indexer.fts_db.execute("SELECT COUNT(*) FROM chunks_fts WHERE path = ?", (path,))
    else:
        cur = indexer.fts_db.execute("SELECT COUNT(*) FROM chunks_fts")
    return cur.fetchone()[0]


async def _fts_search(indexer: QdrantMemoryIndexer, keyword: str) -> list[str]:
    """在 FTS5 中搜索关键词，返回匹配的 snippet 列表。
    注意：SQLite FTS5 默认 tokenizer 对中文支持有限，使用 LIKE 作为补充。
    """
    # 先尝试 FTS5 MATCH（对英文效果好）
    try:
        cur = indexer.fts_db.execute(
            "SELECT text FROM chunks_fts WHERE chunks_fts MATCH ? LIMIT 10",
            (f'"{keyword}"',),
        )
        results = [row[0] for row in cur.fetchall()]
        if results:
            return results
    except Exception:
        pass
    # 降级到 LIKE（支持中文子串匹配）
    cur = indexer.fts_db.execute(
        "SELECT text FROM chunks_fts WHERE text LIKE ? LIMIT 10",
        (f"%{keyword}%",),
    )
    return [row[0] for row in cur.fetchall()]


# ── 验收项 F1-1：启动时全量同步 ──────────────────────────────────────────
async def test_f1_1_initial_sync() -> None:
    """
    验收项：启动时全量同步 MEMORY.md / memory/*.md
    验收方法：启动后查询 FTS5 chunk 数量 > 0
    对标 openclaw: warmSession + onSessionStart sync
    """
    print("\n[F1-1] 启动时全量同步...")
    with tempfile.TemporaryDirectory() as tmpdir:
        # 准备测试文件
        memory_md = Path(tmpdir) / "MEMORY.md"
        memory_md.write_text(
            "# 用户记忆\n\n用户喜欢喝咖啡，每天早上必喝一杯。\n\n用户的生日是3月17日。", encoding="utf-8"
        )

        memory_dir = Path(tmpdir) / "memory"
        memory_dir.mkdir()
        (memory_dir / "2026-03-17.md").write_text("今天和用户聊了很多关于Python的话题。", encoding="utf-8")
        (memory_dir / "topics.md").write_text("用户感兴趣的话题：AI、编程、咖啡。", encoding="utf-8")

        indexer = await _make_indexer(tmpdir, tmpdir)
        await indexer.start()

        total = await _fts_count(indexer)
        memory_md_count = await _fts_count(indexer, "MEMORY.md")
        dated_count = await _fts_count(indexer, "memory/2026-03-17.md")
        topics_count = await _fts_count(indexer, "memory/topics.md")

        indexer.close()

        assert total > 0, f"❌ 全量同步后 FTS5 chunk 数量应 > 0，实际为 {total}"
        assert memory_md_count > 0, f"❌ MEMORY.md 应被索引，实际 chunk 数 = {memory_md_count}"
        assert dated_count > 0, f"❌ memory/2026-03-17.md 应被索引，实际 chunk 数 = {dated_count}"
        assert topics_count > 0, f"❌ memory/topics.md 应被索引，实际 chunk 数 = {topics_count}"

        print(
            f"  ✅ 全量同步成功：总 chunk={total}，MEMORY.md={memory_md_count}，"
            f"2026-03-17.md={dated_count}，topics.md={topics_count}"
        )


# ── 验收项 F1-2：文件变更后自动重新索引 ──────────────────────────────────
async def test_f1_2_file_change() -> None:
    """
    验收项：文件变更后自动重新索引
    验收方法：修改 MEMORY.md，等待 2s，查询新内容可被检索到
    对标 openclaw: chokidar watcher → markDirty → indexFile
    """
    print("\n[F1-2] 文件变更后自动重新索引...")
    with tempfile.TemporaryDirectory() as tmpdir:
        memory_md = Path(tmpdir) / "MEMORY.md"
        memory_md.write_text("# 用户记忆\n\n用户喜欢喝咖啡。", encoding="utf-8")

        indexer = await _make_indexer(tmpdir, tmpdir)
        await indexer.start()

        # 确认初始内容已索引
        initial_results = await _fts_search(indexer, "咖啡")
        assert initial_results, "❌ 初始内容 '咖啡' 应可被检索到"

        # 修改文件，加入新内容
        memory_md.write_text(
            "# 用户记忆\n\n用户喜欢喝咖啡。\n\n用户最近开始学习量子计算。",
            encoding="utf-8",
        )

        # 等待 watchdog 触发（最多等 3s）
        for _ in range(6):
            await asyncio.sleep(0.5)
            results = await _fts_search(indexer, "量子计算")
            if results:
                break

        indexer.close()

        assert results, "❌ 文件变更后，新内容 '量子计算' 应可被检索到（等待 3s 后）"
        print(f"  ✅ 文件变更后自动重新索引成功：找到 {len(results)} 个包含 '量子计算' 的 chunk")


# ── 验收项 F1-3：新增 memory/YYYY-MM-DD.md 后自动索引 ────────────────────
async def test_f1_3_new_file() -> None:
    """
    验收项：新增 memory/YYYY-MM-DD.md 后自动索引
    验收方法：新建日期文件，等待 2s，查询内容可被检索到
    对标 openclaw: chokidar watcher → indexFile
    """
    print("\n[F1-3] 新增文件后自动索引...")
    with tempfile.TemporaryDirectory() as tmpdir:
        memory_dir = Path(tmpdir) / "memory"
        memory_dir.mkdir()
        (memory_dir / "2026-03-16.md").write_text("昨天的记录。", encoding="utf-8")

        indexer = await _make_indexer(tmpdir, tmpdir)
        await indexer.start()

        # 新建日期文件
        new_file = memory_dir / "2026-03-17.md"
        new_file.write_text("今天用户提到了一个新项目：lightclaw记忆系统改造。", encoding="utf-8")

        # 等待 watchdog 触发（最多等 3s）
        results = []
        for _ in range(6):
            await asyncio.sleep(0.5)
            results = await _fts_search(indexer, "lightclaw")
            if results:
                break

        indexer.close()

        assert results, "❌ 新增文件后，内容 'lightclaw' 应可被检索到（等待 3s 后）"
        print(f"  ✅ 新增文件后自动索引成功：找到 {len(results)} 个包含 'lightclaw' 的 chunk")


# ── 验收项 F1-4：删除文件后 chunk 被清理 ─────────────────────────────────
async def test_f1_4_delete_file() -> None:
    """
    验收项：删除文件后 chunk 被清理
    验收方法：删除文件，等待 2s，查询 FTS5 对应 path 的 chunk 数量为 0
    对标 openclaw: chokidar watcher → deleteFileChunks
    """
    print("\n[F1-4] 删除文件后 chunk 被清理...")
    with tempfile.TemporaryDirectory() as tmpdir:
        memory_dir = Path(tmpdir) / "memory"
        memory_dir.mkdir()
        target_file = memory_dir / "2026-03-17.md"
        target_file.write_text("这是一个将被删除的记忆文件，包含独特内容：蓝色大象。", encoding="utf-8")

        indexer = await _make_indexer(tmpdir, tmpdir)
        await indexer.start()

        # 确认文件已被索引
        count_before = await _fts_count(indexer, "memory/2026-03-17.md")
        assert count_before > 0, f"❌ 删除前文件应已被索引，实际 chunk 数 = {count_before}"

        # 删除文件
        target_file.unlink()

        # 等待 watchdog 触发（最多等 3s）
        count_after = count_before
        for _ in range(6):
            await asyncio.sleep(0.5)
            count_after = await _fts_count(indexer, "memory/2026-03-17.md")
            if count_after == 0:
                break

        indexer.close()

        assert count_after == 0, f"❌ 删除文件后，FTS5 中对应 path 的 chunk 数量应为 0，实际为 {count_after}"
        print(f"  ✅ 删除文件后 chunk 清理成功：删除前 {count_before} 个 chunk → 删除后 0 个")


# ── 额外验收：手动调用 index_file + delete_file_chunks ────────────────────
async def test_f1_manual_index_and_delete() -> None:
    """
    额外验收：直接调用 index_file 和 delete_file_chunks（不依赖 watchdog）
    用于验证核心逻辑，不受文件监听延迟影响
    """
    print("\n[F1-manual] 手动 index_file + delete_file_chunks...")
    with tempfile.TemporaryDirectory() as tmpdir:
        memory_md = Path(tmpdir) / "MEMORY.md"
        memory_md.write_text(
            "# 用户记忆\n\n用户叫小明，是一名软件工程师。\n\n用户喜欢用Python写代码。",
            encoding="utf-8",
        )

        indexer = await _make_indexer(tmpdir, tmpdir)
        # 不调用 start()，直接手动操作

        # 手动索引
        await indexer.index_file(memory_md)
        count = await _fts_count(indexer, "MEMORY.md")  # FTS5 存的是相对路径
        assert count > 0, f"❌ index_file 后 chunk 数量应 > 0，实际为 {count}"

        # 验证内容可检索
        results = await _fts_search(indexer, "软件工程师")
        assert results, "❌ index_file 后 '软件工程师' 应可被检索到"

        # 手动删除（传相对路径）
        await indexer.delete_file_chunks("MEMORY.md")
        count_after = await _fts_count(indexer, "MEMORY.md")
        assert count_after == 0, f"❌ delete_file_chunks 后 chunk 数量应为 0，实际为 {count_after}"

        indexer.close()
        print(f"  ✅ 手动 index_file 成功：{count} 个 chunk，内容可检索")
        print(f"  ✅ 手动 delete_file_chunks 成功：chunk 数量 {count} → 0")


# ── 额外验收：分块逻辑 ────────────────────────────────────────────────────
def test_f1_chunk_logic() -> None:
    """
    额外验收：分块逻辑（对标 openclaw chunkMarkdown）
    - CHUNK_SIZE=400 chars
    - OVERLAP=80 chars
    - 空内容返回空列表
    - 超长行被切分
    """
    from lightclaw.agent.memory.qdrant_indexer import CHUNK_SIZE, _chunk_markdown

    print("\n[F1-chunk] 分块逻辑验证...")

    # 空内容
    assert _chunk_markdown("") == [], "❌ 空内容应返回空列表"

    # 短内容：只有一个 chunk
    short = "这是一段很短的内容。"
    chunks = _chunk_markdown(short)
    assert len(chunks) == 1, f"❌ 短内容应只有 1 个 chunk，实际 {len(chunks)}"
    assert chunks[0]["start_line"] == 1
    assert chunks[0]["end_line"] == 1

    # 长内容：应被分成多个 chunk
    long_content = "\n".join([f"第{i}行内容：{'x' * 50}" for i in range(20)])
    chunks = _chunk_markdown(long_content)
    assert len(chunks) > 1, f"❌ 长内容应被分成多个 chunk，实际 {len(chunks)}"

    # 超长单行：应被切分
    very_long_line = "A" * (CHUNK_SIZE * 3)
    chunks = _chunk_markdown(very_long_line)
    assert len(chunks) > 1, f"❌ 超长单行应被切分为多个 chunk，实际 {len(chunks)}"

    # chunk 的 hash 字段存在且非空
    for c in chunks:
        assert c.get("hash"), "❌ 每个 chunk 应有非空 hash 字段"
        assert "start_line" in c and "end_line" in c, "❌ 每个 chunk 应有 start_line 和 end_line"

    print(f"  ✅ 分块逻辑正确：短内容 1 chunk，长内容 {len(_chunk_markdown(long_content))} chunks，超长行被切分")


# ── 主入口 ────────────────────────────────────────────────────────────────
async def _run_all() -> None:
    print("=" * 60)
    print("Week1 F1 验收：文件监听与索引")
    print("=" * 60)

    passed = 0
    failed = 0

    tests = [
        ("F1-manual（手动索引，不依赖 watchdog）", test_f1_manual_index_and_delete),
        ("F1-1（启动时全量同步）", test_f1_1_initial_sync),
        ("F1-2（文件变更后自动重新索引）", test_f1_2_file_change),
        ("F1-3（新增文件后自动索引）", test_f1_3_new_file),
        ("F1-4（删除文件后 chunk 被清理）", test_f1_4_delete_file),
    ]

    for name, fn in tests:
        try:
            await fn()
            passed += 1
        except AssertionError as e:
            print(f"  {e}")
            failed += 1
        except Exception as e:
            print(f"  ❌ {name} 异常：{e}")
            import traceback

            traceback.print_exc()
            failed += 1

    # 同步测试
    try:
        test_f1_chunk_logic()
        passed += 1
    except AssertionError as e:
        print(f"  {e}")
        failed += 1

    print("\n" + "=" * 60)
    print(f"验收结果：{passed} 通过，{failed} 失败")
    print("=" * 60)

    if failed > 0:
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(_run_all())
