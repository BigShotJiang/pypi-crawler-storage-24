from .config import (
    AgentsRunningConfig,
    ChannelConfig,
    ChannelConfigUnion,
    Config,
)
from .utils import (
    get_config_path,
    get_heartbeat_config,
    get_heartbeat_query_path,
    load_config,
    save_config,
    update_last_dispatch,
)

# ConfigWatcher is provided by __getattr__ (lazy-loaded).
# pylint: disable=undefined-all-variable
__all__ = [
    "AgentsRunningConfig",
    "ChannelConfig",
    "ChannelConfigUnion",
    "Config",
    "ConfigWatcher",
    "get_config_path",
    "get_heartbeat_config",
    "get_heartbeat_query_path",
    "load_config",
    "save_config",
    "update_last_dispatch",
]


def __getattr__(name: str):
    """Lazy-load ConfigWatcher to avoid pulling app.channels/lark_oapi."""
    if name == "ConfigWatcher":
        from .watcher import ConfigWatcher

        return ConfigWatcher
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
