"""Watch lightclaw.json for changes and auto-reload channels."""

from __future__ import annotations

import asyncio
import contextlib
import logging
from pathlib import Path

from ..app.channels import ChannelManager  # pylint: disable=no-name-in-module
from ..constant import get_available_channels
from .config import CHANNEL_REGISTRY_KEY_TO_CONFIG_ATTR, ChannelConfig
from .utils import get_config_path, load_config

logger = logging.getLogger(__name__)

# How often to poll (seconds)
DEFAULT_POLL_INTERVAL = 2.0


class ConfigWatcher:
    """Poll lightclaw.json mtime; reload only changed channels automatically."""

    def __init__(
        self,
        channel_manager: ChannelManager,
        poll_interval: float = DEFAULT_POLL_INTERVAL,
        config_path: Path | None = None,
    ):
        self._channel_manager = channel_manager
        self._poll_interval = poll_interval
        self._config_path = config_path or get_config_path()
        self._task: asyncio.Task | None = None

        # Snapshot of the last known channel config (for diffing)
        self._last_channels: ChannelConfig | None = None
        self._last_channels_hash: int | None = None
        self._last_show_tool_details: bool | None = None
        # mtime of lightclaw.json at last check
        self._last_mtime: float = 0.0

    async def start(self) -> None:
        """Take initial snapshot and start the polling task."""
        self._snapshot()
        self._task = asyncio.create_task(
            self._poll_loop(),
            name="config_watcher",
        )
        logger.info(
            "ConfigWatcher started (poll=%.1fs, path=%s)",
            self._poll_interval,
            self._config_path,
        )

    async def stop(self) -> None:
        if self._task:
            self._task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._task
            self._task = None
        logger.info("ConfigWatcher stopped")

    # ------------------------------------------------------------------

    def _snapshot(self) -> None:
        """Load current config and record mtime + channels hash."""
        try:
            self._last_mtime = self._config_path.stat().st_mtime
        except FileNotFoundError:
            self._last_mtime = 0.0
        try:
            config = load_config(self._config_path)
            self._last_channels = config.channels.model_copy(deep=True)
            self._last_channels_hash = self._channels_hash(config.channels)
            self._last_show_tool_details = bool(
                getattr(config, "show_tool_details", True),
            )
        except Exception:
            logger.exception("ConfigWatcher: failed to load initial config")
            self._last_channels = None
            self._last_channels_hash = None
            self._last_show_tool_details = None

    @staticmethod
    def _channels_hash(channels: ChannelConfig) -> int:
        """Fast hash of channels section for quick change detection."""
        return hash(str(channels.model_dump(mode="json")))

    async def _poll_loop(self) -> None:
        while True:
            try:
                await asyncio.sleep(self._poll_interval)
                await self._check()
            except Exception:
                logger.exception("ConfigWatcher: poll iteration failed")

    async def _check(self) -> None:
        # 1) Check mtime
        try:
            mtime = self._config_path.stat().st_mtime
        except FileNotFoundError:
            return
        if mtime == self._last_mtime:
            return
        self._last_mtime = mtime

        # 2) Load new config; quick-reject if channels + tool detail flag unchanged
        try:
            config = load_config(self._config_path)
        except Exception:
            logger.exception("ConfigWatcher: failed to parse lightclaw.json")
            return

        new_hash = self._channels_hash(config.channels)
        new_show_tool_details = bool(
            getattr(config, "show_tool_details", True),
        )
        show_tool_details_changed = new_show_tool_details != self._last_show_tool_details
        if new_hash == self._last_channels_hash and not show_tool_details_changed:
            return  # Only unrelated fields changed (e.g. last_dispatch)

        # 3) Diff per-channel and reload changed ones
        new_channels = config.channels
        old_channels = self._last_channels

        extra_new = getattr(new_channels, "__pydantic_extra__", None) or {}
        extra_old = getattr(old_channels, "__pydantic_extra__", None) if old_channels else {}

        for name in get_available_channels():
            # Map registry key to the actual ChannelConfig attribute name.
            config_attr = CHANNEL_REGISTRY_KEY_TO_CONFIG_ATTR.get(name, name)
            new_ch = getattr(new_channels, config_attr, None) or extra_new.get(name)
            old_ch = getattr(old_channels, config_attr, None) or extra_old.get(name) if old_channels else None

            if new_ch is None:
                continue

            if isinstance(new_ch, dict):
                new_dump = new_ch
                old_dump = old_ch if isinstance(old_ch, dict) else None
            else:
                new_dump = new_ch.model_dump(mode="json") if hasattr(new_ch, "model_dump") else None
                old_dump = old_ch.model_dump(mode="json") if old_ch and hasattr(old_ch, "model_dump") else None
            channel_changed = True
            if new_dump is not None:
                channel_changed = new_dump != old_dump

            if not channel_changed and not show_tool_details_changed:
                continue

            if channel_changed and show_tool_details_changed:
                reason = "channel config + show_tool_details changed"
            elif channel_changed:
                reason = "channel config changed"
            else:
                reason = "show_tool_details changed"
            logger.info(
                "ConfigWatcher: channel '%s' %s, reloading",
                name,
                reason,
            )
            try:
                old_channel = await self._channel_manager.get_channel(name)
                if old_channel is None:
                    logger.warning(
                        f"ConfigWatcher: channel '{name}' not found, skip",
                    )
                    continue
                new_channel = old_channel.clone(
                    new_ch,
                    show_tool_details=new_show_tool_details,
                )
                await self._channel_manager.replace_channel(new_channel)
                logger.info(f"ConfigWatcher: channel '{name}' reloaded")
            except Exception:
                # Reload failed — keep old snapshot for this channel so
                # the next config change will retry the reload.
                logger.exception(
                    f"ConfigWatcher: failed to reload channel '{name}'",
                )
                setattr(new_channels, config_attr, old_ch if old_ch else new_ch)

        # 4) Update snapshot
        self._last_channels = new_channels.model_copy(deep=True)
        self._last_channels_hash = self._channels_hash(new_channels)
        self._last_show_tool_details = new_show_tool_details
