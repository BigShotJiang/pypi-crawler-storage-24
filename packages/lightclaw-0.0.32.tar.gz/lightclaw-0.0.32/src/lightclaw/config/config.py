import os
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

from ..constant import (
    HEARTBEAT_DEFAULT_EVERY,
    HEARTBEAT_DEFAULT_TARGET,
)

# Import ProvidersData here to embed it in Config.
# Use a TYPE_CHECKING guard for the heavy provider registry to avoid
# circular imports at module load time.
from ..providers.models import ProvidersData


class BaseChannelConfig(BaseModel):
    """Base for channel config (read from lightclaw.json, no env)."""

    model_config = ConfigDict(populate_by_name=True)

    enabled: bool = False
    bot_prefix: str = Field(default="", alias="botPrefix")


class DiscordConfig(BaseChannelConfig):
    bot_token: str = Field(default="", alias="botToken")
    http_proxy: str = Field(default="", alias="httpProxy")
    http_proxy_auth: str = Field(default="", alias="httpProxyAuth")


class DingTalkConfig(BaseChannelConfig):
    """DingTalk: client_id, client_secret; media_dir for received media."""

    client_id: str = Field(default="", alias="clientId")
    client_secret: str = Field(default="", alias="clientSecret")
    media_dir: str = Field(default="~/.lightclaw/media", alias="mediaDir")


class FeishuConfig(BaseChannelConfig):
    """Feishu/Lark channel: app_id, app_secret; optional encrypt_key,
    verification_token for event handler. media_dir for received media.
    """

    app_id: str = Field(default="", alias="appId")
    app_secret: str = Field(default="", alias="appSecret")
    encrypt_key: str = Field(default="", alias="encryptKey")
    verification_token: str = Field(default="", alias="verificationToken")
    media_dir: str = Field(default="~/.lightclaw/media", alias="mediaDir")


class QQConfig(BaseChannelConfig):
    app_id: str = Field(default="", alias="appId")
    client_secret: str = Field(default="", alias="clientSecret")


class YuanbaoConfig(BaseChannelConfig):
    """Tencent YuanBao bot channel: appKey + appSecret or static token."""

    app_key: str = Field(default="", alias="appKey")
    app_secret: str = Field(default="", alias="appSecret")
    token: str = Field(default="")
    identifier: str = Field(default="")
    api_domain: str = Field(default="bot.yuanbao.tencent.com", alias="apiDomain")
    ws_url: str = Field(default="wss://bot-wss.yuanbao.tencent.com/wss/connection", alias="wsUrl")
    route_env: str = Field(default="", alias="routeEnv")


class DashboardConfig(BaseChannelConfig):
    """Dashboard channel: prints agent responses to stdout."""

    enabled: bool = True


class WeComConfig(BaseChannelConfig):
    """WeCom (Enterprise WeChat) AI Bot channel: WebSocket long connection.

    Field aliases match OpenClaw wecom-openclaw-plugin for migration compat.
    """

    model_config = ConfigDict(populate_by_name=True, extra="allow")

    bot_id: str = Field(default="", alias="botId")
    secret: str = Field(default="", alias="secret")
    name: str = Field(default="", alias="name")
    websocket_url: str = Field(default="", alias="websocketUrl")

    # Access control — aligned with OpenClaw dmPolicy / allowFrom
    dm_policy: str = Field(
        default="open",
        alias="dmPolicy",
        description='Private-chat policy: "open" | "allowlist" | "pairing" | "disabled"',
    )
    allow_from: list = Field(
        default_factory=list,
        alias="allowFrom",
        description="Private-chat allowlist (user IDs); only effective when dmPolicy=allowlist",
    )
    group_policy: str = Field(
        default="open",
        alias="groupPolicy",
        description='Group-chat policy: "open" | "allowlist" | "disabled"',
    )
    group_allow_from: list = Field(
        default_factory=list,
        alias="groupAllowFrom",
        description="Group-chat allowlist (group IDs); only effective when groupPolicy=allowlist",
    )
    groups: dict = Field(
        default_factory=dict,
        alias="groups",
        description="Per-group config, e.g. {groupId: {allowFrom: [...]}}",
    )

    # Behavior
    send_thinking: bool = Field(default=True, alias="sendThinkingMessage")
    media_dir: str = Field(default="~/.lightclaw/media", alias="mediaDir")
    media_local_roots: list[str] = Field(
        default_factory=list,
        alias="mediaLocalRoots",
        description="Extra local paths allowed for media access (supports ~)",
    )

    @model_validator(mode="before")
    @classmethod
    def _compat_send_thinking(cls, data):
        """Backward compat: accept legacy 'sendThinking' key."""
        if isinstance(data, dict) and "sendThinking" in data and "sendThinkingMessage" not in data:
            data["sendThinkingMessage"] = data.pop("sendThinking")
        return data


class ChannelConfig(BaseModel):
    """Built-in channel configs; extra keys allowed for plugin channels."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    discord: DiscordConfig = DiscordConfig()
    dingtalk: DingTalkConfig = DingTalkConfig()
    feishu: FeishuConfig = FeishuConfig()
    qqbot: QQConfig = Field(default_factory=QQConfig)
    yuanbao: YuanbaoConfig = Field(default_factory=YuanbaoConfig)
    dashboard: DashboardConfig = DashboardConfig()
    wecom: WeComConfig = WeComConfig()

    @model_validator(mode="before")
    @classmethod
    def _normalize_qq_key(cls, data):
        """Backward compat: map legacy 'qq' key to 'qqbot'."""
        if isinstance(data, dict) and "qq" in data and "qqbot" not in data:
            data = dict(data)
            data["qqbot"] = data.pop("qq")
        return data


class LastApiConfig(BaseModel):
    host: str | None = None
    port: int | None = None


class ActiveHoursConfig(BaseModel):
    """Optional active window for heartbeat (e.g. 08:00–22:00)."""

    start: str = "08:00"
    end: str = "22:00"


class HeartbeatConfig(BaseModel):
    """Heartbeat: run agent with HEARTBEAT.md as query at interval."""

    model_config = {"populate_by_name": True}

    every: str = Field(default=HEARTBEAT_DEFAULT_EVERY)
    target: str = Field(default=HEARTBEAT_DEFAULT_TARGET)
    active_hours: ActiveHoursConfig | None = Field(
        default=None,
        alias="activeHours",
    )


class AgentsDefaultsConfig(BaseModel):
    heartbeat: HeartbeatConfig | None = None


class AgentsRunningConfig(BaseModel):
    """Agent runtime behavior configuration."""

    model_config = ConfigDict(populate_by_name=True)

    max_iters: int = Field(
        default=50,
        ge=1,
        alias="maxIters",
        description=("Maximum number of reasoning-acting iterations for ReAct agent"),
    )
    max_input_length: int = Field(
        default=128 * 1024,  # 128K = 131072 tokens
        ge=1000,
        alias="maxInputLength",
        description=("Maximum input length (tokens) for the model context window"),
    )


class CompactionAgentConfig(BaseModel):
    """Fine-grained compaction configuration.

    Loaded from ``agents.compaction`` in ``lightclaw.json``.
    All compaction uses the safeguard pipeline (structured output,
    identifier preservation, adaptive chunking, quality guard).
    """

    model_config = ConfigDict(populate_by_name=True)

    identifier_policy: str = Field(
        default="strict",
        alias="identifierPolicy",
        description="Identifier preservation policy: 'strict', 'off', or 'custom'",
    )
    identifier_instructions: str = Field(
        default="",
        alias="identifierInstructions",
        description="Custom identifier instructions (only used when identifierPolicy='custom')",
    )
    quality_guard_enabled: bool = Field(
        default=True,
        alias="qualityGuardEnabled",
        description="Enable post-compaction quality audit",
    )
    quality_guard_max_retries: int = Field(
        default=1,
        ge=0,
        le=3,
        alias="qualityGuardMaxRetries",
        description="Max retries when quality audit fails (0-3)",
    )
    recent_turns_preserve: int = Field(
        default=3,
        ge=0,
        le=12,
        alias="recentTurnsPreserve",
        description="Number of recent turns to preserve verbatim (0-12)",
    )
    max_history_share: float = Field(
        default=0.5,
        ge=0.1,
        le=0.9,
        alias="maxHistoryShare",
        description="Fraction of context window reserved for history (0.1-0.9)",
    )
    base_chunk_ratio: float = Field(
        default=0.4,
        ge=0.1,
        le=0.8,
        alias="baseChunkRatio",
        description="Default chunk size as fraction of context window",
    )
    min_chunk_ratio: float = Field(
        default=0.15,
        ge=0.05,
        le=0.5,
        alias="minChunkRatio",
        description="Floor for chunk ratio when messages are large",
    )
    safety_margin: float = Field(
        default=1.2,
        ge=1.0,
        le=2.0,
        alias="safetyMargin",
        description="Token estimate safety multiplier (1.0-2.0)",
    )
    custom_instructions: str = Field(
        default="",
        alias="customInstructions",
        description="Extra instructions appended to compaction prompt",
    )
    timeout_seconds: int = Field(
        default=900,
        ge=60,
        le=3600,
        alias="timeoutSeconds",
        description="Compaction LLM call timeout in seconds",
    )


class AgentsConfig(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    defaults: AgentsDefaultsConfig = Field(
        default_factory=AgentsDefaultsConfig,
    )
    running: AgentsRunningConfig = Field(
        default_factory=AgentsRunningConfig,
    )
    language: str = Field(
        default="zh",
        description="Language for agent MD files (en/zh)",
    )
    installed_prompts_language: str | None = Field(
        default=None,
        alias="installedPromptsLanguage",
        description="Language of currently installed prompt files",
    )


class LastDispatchConfig(BaseModel):
    """Last channel/user/session that received a user-originated reply."""

    model_config = ConfigDict(populate_by_name=True)

    channel: str = ""
    user_id: str = Field(default="", alias="userId")
    session_id: str = Field(default="", alias="sessionId")


class MCPClientConfig(BaseModel):
    """Configuration for a single MCP client.

    Supports three transport types:
    - ``stdio``: Launch a local process (requires ``command``).
    - ``streamable_http``: Connect to a remote HTTP MCP endpoint (requires ``url``).
    - ``sse``: Connect via Server-Sent Events (requires ``url``).
    """

    model_config = ConfigDict(populate_by_name=True)

    name: str
    description: str = ""
    enabled: bool = True
    transport: Literal["stdio", "streamable_http", "sse"] = "stdio"
    url: str = ""
    headers: dict[str, str] = Field(default_factory=dict)
    command: str = ""
    args: list[str] = Field(default_factory=list)
    env: dict[str, str] = Field(default_factory=dict)
    cwd: str = ""

    @model_validator(mode="before")
    @classmethod
    def _normalize_legacy_fields(cls, data):
        """Normalize common MCP field aliases from third-party examples."""
        if not isinstance(data, dict):
            return data

        payload = dict(data)

        # Alias: isActive -> enabled
        if "isActive" in payload and "enabled" not in payload:
            payload["enabled"] = payload["isActive"]

        # Alias: baseUrl -> url
        if "baseUrl" in payload and "url" not in payload:
            payload["url"] = payload["baseUrl"]

        # Alias: type -> transport
        if "type" in payload and "transport" not in payload:
            payload["transport"] = payload["type"]

        # Auto-detect: has url but no command → streamable_http
        if "transport" not in payload and (payload.get("url") or payload.get("baseUrl")) and not payload.get("command"):
            payload["transport"] = "streamable_http"

        # Normalize transport aliases (http → streamable_http, etc.)
        raw_transport = payload.get("transport")
        if isinstance(raw_transport, str):
            normalized = raw_transport.strip().lower()
            transport_alias_map = {
                "streamablehttp": "streamable_http",
                "streamable_http": "streamable_http",
                "http": "streamable_http",
                "stdio": "stdio",
                "sse": "sse",
            }
            payload["transport"] = transport_alias_map.get(
                normalized,
                normalized,
            )

        return payload

    @model_validator(mode="after")
    def _validate_transport_config(self):
        """Validate required fields for each MCP transport type."""
        if self.transport == "stdio":
            if not self.command.strip():
                raise ValueError("stdio MCP client requires non-empty command")
            return self

        if not self.url.strip():
            raise ValueError(
                f"{self.transport} MCP client requires non-empty url",
            )
        return self


class MCPConfig(BaseModel):
    """MCP clients configuration.

    Uses a dict to allow dynamic client definitions.
    Default tavily_search client is created and auto-enabled if API key exists.
    """

    clients: dict[str, MCPClientConfig] = Field(
        default_factory=lambda: {
            "tavily_search": MCPClientConfig(
                name="tavily_mcp",
                # Auto-enable if TAVILY_API_KEY exists in environment
                enabled=bool(os.getenv("TAVILY_API_KEY")),
                command="npx",
                args=["-y", "tavily-mcp@latest"],
                env={"TAVILY_API_KEY": os.getenv("TAVILY_API_KEY", "")},
            ),
        },
    )


class OpenClawConfig(BaseModel):
    """Optional pointers to the OpenClaw installation.

    When either field is set it overrides the default discovery logic used by
    the ``sync_from_openclaw`` command / API.

    Defaults (when fields are *None*):
    - ``config_path``    → ``~/.openclaw/openclaw.json``
    - ``workspace_path`` → value of ``agents.defaults.workspace`` inside that
                           openclaw.json (usually ``~/.openclaw/workspace``)
    """

    model_config = ConfigDict(populate_by_name=True)

    config_path: str | None = Field(
        default=None,
        alias="configPath",
        description="Override path to openclaw.json",
    )
    workspace_path: str | None = Field(
        default=None,
        alias="workspacePath",
        description="Override path to openclaw workspace directory",
    )


class SkillEntryConfig(BaseModel):
    """Configuration for a single skill entry (enabled/disabled)."""

    model_config = ConfigDict(populate_by_name=True)

    enabled: bool = True


class SkillsConfig(BaseModel):
    """Skills configuration — mirrors openclaw's plugins.entries pattern.

    Example lightclaw.json:
        {
          "skills": {
            "entries": {
              "pdf":  { "enabled": true },
              "xlsx": { "enabled": false }
            }
          }
        }

    Skills whose name does not appear in ``entries`` are treated as disabled.
    """

    model_config = ConfigDict(populate_by_name=True)

    entries: dict[str, SkillEntryConfig] = Field(default_factory=dict)


class EmbeddingConfig(BaseModel):
    """Embedding provider configuration.

    provider 取值：
    - ``none``   : 禁用向量搜索，仅使用 FTS 关键词搜索（默认）
    - ``local``  : 使用本地 fastembed 模型（需安装 local-embedding extra）
    - ``custom`` : 使用用户自定义的 OpenAI 兼容 embedding API
    """

    model_config = ConfigDict(populate_by_name=True)

    provider: Literal["none", "local", "custom"] = "none"

    # --- local 模式 ---
    local_model: str = Field(
        default="BAAI/bge-small-zh-v1.5",
        alias="localModel",
        description=(
            "fastembed TextEmbedding 支持的模型 ID（非任意 HuggingFace 名），"
            "首次使用时自动下载；可用列表见 fastembed.TextEmbedding.list_supported_models()"
        ),
    )

    # --- custom 模式 ---
    api_key: str = Field(default="", alias="apiKey")
    base_url: str = Field(default="", alias="baseUrl")
    model_name: str = Field(default="", alias="modelName")
    dimensions: int = Field(default=512, ge=1)


class Config(BaseModel):
    """Root config (lightclaw.json)."""

    model_config = ConfigDict(populate_by_name=True)

    channels: ChannelConfig = ChannelConfig()
    mcp: MCPConfig = MCPConfig()
    last_api: LastApiConfig = Field(default_factory=LastApiConfig, alias="lastApi")
    agents: AgentsConfig = Field(default_factory=AgentsConfig)
    last_dispatch: LastDispatchConfig | None = Field(default=None, alias="lastDispatch")
    # When False, hide tool call/result messages entirely.
    show_tool_details: bool = Field(default=True, alias="showToolDetails")
    # Provider/model config — merged into lightclaw.json (openclaw-compatible).
    models: ProvidersData = Field(default_factory=ProvidersData)
    # Skills enable/disable config — mirrors openclaw plugins.entries pattern.
    skills: SkillsConfig = Field(default_factory=SkillsConfig)
    # Optional openclaw integration paths.
    openclaw: OpenClawConfig = Field(default_factory=OpenClawConfig)
    # Embedding provider config (vector search for memory).
    embedding: EmbeddingConfig = Field(default_factory=EmbeddingConfig)


# Mapping from runtime channel registry key -> ChannelConfig attribute name.
# Used when the lightclaw.json key (openclaw-compatible) differs from the
# internal channel identifier.  e.g. QQ channel runs as "qq" internally but
# stores its config under "qqbot" in lightclaw.json.
CHANNEL_REGISTRY_KEY_TO_CONFIG_ATTR: dict[str, str] = {
    "qq": "qqbot",
}


ChannelConfigUnion = (
    DiscordConfig | DingTalkConfig | FeishuConfig | QQConfig | YuanbaoConfig | DashboardConfig | WeComConfig
)
