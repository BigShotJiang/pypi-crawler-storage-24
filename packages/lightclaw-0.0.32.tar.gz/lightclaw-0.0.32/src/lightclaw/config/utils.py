from __future__ import annotations

import json
import shutil
from pathlib import Path

from ..constant import (
    ACTIVE_SKILLS_DIR,
    BASE_DIR,
    CHATS_FILE,
    CUSTOMIZED_SKILLS_DIR,
    HEARTBEAT_FILE,
    JOBS_FILE,
    PROVIDERS_FILE,
    SKILLS_DIR,
    WORKING_DIR,
)
from .config import (
    Config,
    HeartbeatConfig,
    LastApiConfig,
    LastDispatchConfig,
    SkillEntryConfig,
)


def get_config_path() -> Path:
    """Get the path to the config file (in BASE_DIR, not workspace)."""
    return BASE_DIR / "lightclaw.json"


def get_heartbeat_query_path() -> Path:
    """Get path to heartbeat query file (HEARTBEAT.md in WORKING_DIR)."""
    return WORKING_DIR / HEARTBEAT_FILE


# ---------------------------------------------------------------------------
# providers.json migration
# ---------------------------------------------------------------------------


def _get_legacy_providers_path() -> Path:
    """Old standalone providers.json in BASE_DIR (pre-merge era)."""
    return BASE_DIR / PROVIDERS_FILE


def _migrate_providers_into_config(config: Config) -> bool:
    """One-time migration: if providers.json still exists in WORKING_DIR,
    parse it and merge the provider data into config.models, then rename
    the file to providers.json.bak so it is never loaded again.

    Returns True if migration was applied.
    """
    legacy_path = _get_legacy_providers_path()
    if not legacy_path.is_file():
        return False

    try:
        with open(legacy_path, encoding="utf-8") as fh:
            raw: dict = json.load(fh)
    except (json.JSONDecodeError, OSError):
        # Unreadable; rename it away and continue with empty providers
        _rename_to_bak(legacy_path)
        return False

    # Reuse the parse helpers from store.py (import here to avoid module-load
    # circular imports; store.py does NOT import utils.py at load time).
    from ..providers.store import (
        _parse_legacy_format,
        _parse_new_format,
        _parse_split_format,
    )

    try:
        if "activeLlm" in raw:
            providers, active_llm = _parse_new_format(raw)
        elif "custom_providers" in raw or ("providers" in raw and isinstance(raw.get("providers"), dict)):
            providers, active_llm = _parse_split_format(raw)
        else:
            providers, active_llm = _parse_legacy_format(raw)
    except Exception:
        _rename_to_bak(legacy_path)
        return False

    # Merge into config.models — only overwrite fields that are still default
    models = config.models
    if providers:
        # Prefer existing config.models.providers (already loaded from lightclaw.json)
        # but fill in any providers not yet present from the legacy file.
        for pid, entry in providers.items():
            if pid not in models.providers:
                models.providers[pid] = entry
            else:
                # Merge credentials if the config entry is empty
                existing = models.providers[pid]
                if not existing.api_key and entry.api_key:
                    existing.api_key = entry.api_key
                if not existing.base_url and entry.base_url:
                    existing.base_url = entry.base_url

    if not models.active_llm and active_llm:
        models.active_llm = active_llm

    _rename_to_bak(legacy_path)
    return True


def _rename_to_bak(path: Path) -> None:
    """Rename *path* to *path*.bak, overwriting any previous backup."""
    try:
        bak = path.with_suffix(".json.bak")
        shutil.move(str(path), str(bak))
    except OSError:
        pass


# ---------------------------------------------------------------------------
# Provider registry sync helpers (imported lazily to avoid circular imports)
# ---------------------------------------------------------------------------


def _sync_providers_after_load(config: Config) -> None:
    """Run provider registry sync and validation after loading config.

    Populates the in-memory PROVIDERS registry with custom providers and
    Ollama models, ensures every built-in provider has an entry, and
    validates/clears a stale active_llm value.
    """
    from ..providers.models import CustomProviderData
    from ..providers.registry import (
        sync_custom_providers,
        sync_ollama_models,
    )
    from ..providers.store import (
        _ensure_all_providers,
        _entry_to_custom_data,
        _validate_active_llm,
    )

    providers = config.models.providers

    # Build custom provider map for registry sync
    custom_map: dict[str, CustomProviderData] = {
        pid: _entry_to_custom_data(pid, entry) for pid, entry in providers.items() if entry.is_custom
    }

    sync_custom_providers(custom_map)
    sync_ollama_models()
    _ensure_all_providers(providers)
    _validate_active_llm(config.models)


# ---------------------------------------------------------------------------
# Load / Save
# ---------------------------------------------------------------------------


def load_config(config_path: Path | None = None) -> Config:
    """Load config from file. Returns default Config if file is missing.

    Also handles one-time migration from the old standalone providers.json
    and runs provider-registry sync so that PROVIDERS is up to date.
    """
    if config_path is None:
        config_path = get_config_path()
    if not config_path.is_file():
        config = Config()
    else:
        with open(config_path, encoding="utf-8") as file:
            data = json.load(file)
        # Backward compat: top-level last_api_host / last_api_port -> last_api
        if "last_api_host" in data or "last_api_port" in data:
            la = data.setdefault("last_api", {})
            if "host" not in la and "last_api_host" in data:
                la["host"] = data.get("last_api_host")
            if "port" not in la and "last_api_port" in data:
                la["port"] = data.get("last_api_port")
        config = Config.model_validate(data)

    # One-time migration: absorb leftover providers.json into config.models
    migrated = _migrate_providers_into_config(config)

    # One-time migration: move active_skills/customized_skills -> skills/
    skills_migrated = _migrate_skills_to_new_dir(config)

    # Sync provider registry and validate active LLM
    _sync_providers_after_load(config)

    # Persist: save if file was missing OR migration ran
    if migrated or skills_migrated or not config_path.is_file():
        save_config(config, config_path)

    return config


# ---------------------------------------------------------------------------
# Skills migration: active_skills/ + customized_skills/ -> skills/
# ---------------------------------------------------------------------------


def _migrate_skills_to_new_dir(config: Config) -> bool:
    """One-time migration: consolidate legacy active_skills/ and
    customized_skills/ into the unified skills/ directory, and initialise
    config.skills.entries based on what was previously active.

    Returns True if any migration work was performed.
    """
    # Nothing to migrate if new skills/ dir already exists
    if SKILLS_DIR.exists():
        return False

    # Also nothing to do if neither legacy dir exists
    if not ACTIVE_SKILLS_DIR.exists() and not CUSTOMIZED_SKILLS_DIR.exists():
        return False

    import logging

    logger = logging.getLogger(__name__)
    logger.info(
        "Migrating skills from legacy active_skills/customized_skills to skills/",
    )

    SKILLS_DIR.mkdir(parents=True, exist_ok=True)

    # Collect skill names that were active (to seed skills.entries)
    active_skill_names: set[str] = set()
    if ACTIVE_SKILLS_DIR.exists():
        for d in ACTIVE_SKILLS_DIR.iterdir():
            if d.is_dir() and (d / "SKILL.md").exists():
                active_skill_names.add(d.name)

    # Copy customized skills into skills/ (user-created, takes priority)
    if CUSTOMIZED_SKILLS_DIR.exists():
        for skill_dir in CUSTOMIZED_SKILLS_DIR.iterdir():
            if skill_dir.is_dir() and (skill_dir / "SKILL.md").exists():
                target = SKILLS_DIR / skill_dir.name
                if not target.exists():
                    try:
                        shutil.copytree(skill_dir, target)
                        logger.debug(
                            "Migrated customized skill '%s' to skills/",
                            skill_dir.name,
                        )
                    except Exception as exc:
                        logger.warning(
                            "Failed to migrate customized skill '%s': %s",
                            skill_dir.name,
                            exc,
                        )

    # Seed skills.entries from formerly active skills
    # (builtin skills will be synced into skills/ on next init)
    if active_skill_names and not config.skills.entries:
        for name in active_skill_names:
            config.skills.entries[name] = SkillEntryConfig(enabled=True)
        logger.info(
            "Initialised skills.entries with %d previously active skill(s): %s",
            len(active_skill_names),
            ", ".join(sorted(active_skill_names)),
        )

    logger.info(
        "Skills migration complete. Legacy directories active_skills/ and "
        "customized_skills/ have been preserved; you may remove them manually.",
    )
    return True


def save_config(config: Config, config_path: Path | None = None) -> None:
    """Save the config to the file."""
    if config_path is None:
        config_path = get_config_path()
    config_path.parent.mkdir(parents=True, exist_ok=True)
    with open(config_path, "w", encoding="utf-8") as file:
        json.dump(
            config.model_dump(mode="json", by_alias=True, exclude_none=True),
            file,
            indent=2,
            ensure_ascii=False,
        )


def get_heartbeat_config() -> HeartbeatConfig | None:
    """Return heartbeat config, or None if heartbeat is disabled."""
    config = load_config()
    return config.agents.defaults.heartbeat


def update_last_dispatch(channel: str, user_id: str, session_id: str) -> None:
    """Persist last user-reply dispatch target (user send+reply only)."""
    config = load_config()
    config.last_dispatch = LastDispatchConfig(
        channel=channel,
        user_id=user_id,
        session_id=session_id,
    )
    save_config(config)


def read_last_api() -> tuple[str, int] | None:
    """Read last API host/port from config (via config load/save)."""
    config = load_config()
    host = config.last_api.host
    port = config.last_api.port
    if not host or port is None:
        return None
    return host, port


def write_last_api(host: str, port: int) -> None:
    """Write last API host/port to config (via config load/save)."""
    config = load_config()
    config.last_api = LastApiConfig(host=host, port=port)
    save_config(config)


def get_jobs_path() -> Path:
    """Return cron jobs.json path (in BASE_DIR, not workspace)."""
    return BASE_DIR / JOBS_FILE


def get_chats_path() -> Path:
    """Return chats.json path (in BASE_DIR, not workspace)."""
    return BASE_DIR / CHATS_FILE
