import os
from pathlib import Path

# BASE_DIR: root lightclaw directory — holds config, database, auth, env vars.
# This is NOT the agent working area; use WORKING_DIR for md/skills files.
BASE_DIR = Path(os.environ.get("LIGHTCLAW_BASE_DIR", "~/.lightclaw")).expanduser().resolve()

# WORKING_DIR: agent workspace — holds *.md files, skills/, memory/, etc.
# Sub-directory of BASE_DIR so that config files and workspace are separated.
WORKING_DIR = Path(os.environ.get("LIGHTCLAW_WORKING_DIR", str(BASE_DIR / "workspace"))).expanduser().resolve()

JOBS_FILE = os.environ.get("LIGHTCLAW_JOBS_FILE", "jobs.json")

CHATS_FILE = os.environ.get("LIGHTCLAW_CHATS_FILE", "chats.json")

CONFIG_FILE = os.environ.get("LIGHTCLAW_CONFIG_FILE", "lightclaw.json")

PROVIDERS_FILE = os.environ.get("LIGHTCLAW_PROVIDERS_FILE", "providers.json")

HEARTBEAT_FILE = os.environ.get("LIGHTCLAW_HEARTBEAT_FILE", "HEARTBEAT.md")
HEARTBEAT_DEFAULT_EVERY = "30m"
HEARTBEAT_DEFAULT_TARGET = "main"
HEARTBEAT_TARGET_LAST = "last"

# Env key for app log level (used by CLI and app load for reload child).
LOG_LEVEL_ENV = "LIGHTCLAW_LOG_LEVEL"

# When True, expose /docs, /redoc, /openapi.json
# (dev only; keep False in prod).
DOCS_ENABLED = os.environ.get("LIGHTCLAW_OPENAPI_DOCS", "false").lower() in (
    "true",
    "1",
    "yes",
)

# Skills directories
# Unified skills directory (all skills: builtin synced + user-created)
SKILLS_DIR = WORKING_DIR / "skills"
# Legacy directories (kept for backward-compat migration only)
ACTIVE_SKILLS_DIR = WORKING_DIR / "active_skills"
CUSTOMIZED_SKILLS_DIR = WORKING_DIR / "customized_skills"

# Logs directory (one file per day, e.g. ~/.lightclaw/logs/lightclaw.log.YYYY-MM-DD)
LOGS_DIR = BASE_DIR / "logs"

# Memory directory
MEMORY_DIR = WORKING_DIR / "memory"

# Custom channel modules (installed via `lightclaw channels install`); manager
# loads BaseChannel subclasses from here.
CUSTOM_CHANNELS_DIR = WORKING_DIR / "custom_channels"

# Uploads directory (user-uploaded images / files)
UPLOADS_DIR = WORKING_DIR / "uploads"

# Memory compaction configuration
MEMORY_COMPACT_KEEP_RECENT = int(
    os.environ.get("LIGHTCLAW_MEMORY_COMPACT_KEEP_RECENT", "3"),
)

MEMORY_COMPACT_RATIO = float(
    os.environ.get("LIGHTCLAW_MEMORY_COMPACT_RATIO", "0.7"),
)

# Memory file governance — limits to prevent uncontrolled file proliferation
MEMORY_MAX_FILES = int(os.environ.get("LIGHTCLAW_MEMORY_MAX_FILES", "100"))
MEMORY_MAX_FILE_SIZE = int(os.environ.get("LIGHTCLAW_MEMORY_MAX_FILE_SIZE", str(50 * 1024)))  # 50 KB

# ---------------------------------------------------------------------------
# Structured fact extraction — Mem0-style fact management
# ---------------------------------------------------------------------------

# Master switch: set to "true" to enable fact extraction (disabled by default
# since v2 personality system relies on agent self-write instead).
FACT_EXTRACTION_ENABLED = os.environ.get("LIGHTCLAW_FACT_EXTRACTION", "false").lower() != "false"

# Maximum facts extracted per conversation turn.
FACT_MAX_PER_TURN = int(os.environ.get("LIGHTCLAW_FACT_MAX_PER_TURN", "5"))

# Token budget for injected facts in the LLM context window.
FACT_INJECTION_MAX_TOKENS = int(os.environ.get("LIGHTCLAW_FACT_INJECTION_MAX_TOKENS", "1500"))

# Cosine similarity threshold to consider two facts "similar" during
# conflict resolution.  Lower = more aggressive matching.
FACT_SIMILARITY_THRESHOLD = float(os.environ.get("LIGHTCLAW_FACT_SIMILARITY_THRESHOLD", "0.6"))

# When active fact count exceeds this, trigger automatic pruning of
# low-importance, zero-access, old facts.
FACT_MAX_COUNT = int(os.environ.get("LIGHTCLAW_FACT_MAX_COUNT", "500"))

# Minimum user message length (chars) to trigger fact extraction.
# Short messages (greetings, "ok", "thanks") are skipped.
FACT_MIN_MESSAGE_LENGTH = int(os.environ.get("LIGHTCLAW_FACT_MIN_MESSAGE_LENGTH", "15"))

# ---------------------------------------------------------------------------
# Auto Memory Recall — proactive memory retrieval before each LLM call
# ---------------------------------------------------------------------------

# Master switch: set to "false" to disable automatic memory recall.
AUTO_RECALL_ENABLED = os.environ.get("LIGHTCLAW_AUTO_RECALL_ENABLED", "true").lower() != "false"

# Maximum number of memory snippets injected per turn.
AUTO_RECALL_MAX_RESULTS = int(os.environ.get("LIGHTCLAW_AUTO_RECALL_MAX_RESULTS", "3"))

# Minimum cosine similarity score for a memory snippet to be injected.
AUTO_RECALL_MIN_SCORE = float(os.environ.get("LIGHTCLAW_AUTO_RECALL_MIN_SCORE", "0.5"))

# Maximum characters of the user query used as search input.
AUTO_RECALL_MAX_QUERY_LENGTH = int(os.environ.get("LIGHTCLAW_AUTO_RECALL_MAX_QUERY_LENGTH", "500"))

# ---------------------------------------------------------------------------
# Channel availability — controlled by LIGHTCLAW_ENABLED_CHANNELS env var.
# When unset / empty, all registered channels (built-in + plugins) are
# available. Set to a comma-separated list to restrict, e.g.
#   LIGHTCLAW_ENABLED_CHANNELS=dingtalk,feishu,qq
# ---------------------------------------------------------------------------


def get_available_channels() -> tuple[str, ...]:
    """Return channel keys enabled for this run (built-in + entry point
    lightclaw.channels), filtered by LIGHTCLAW_ENABLED_CHANNELS when set.
    """
    from .app.channels.registry import get_channel_registry

    registry = get_channel_registry()
    all_keys = tuple(registry.keys())
    raw = os.environ.get("LIGHTCLAW_ENABLED_CHANNELS", "").strip()
    if not raw:
        return all_keys
    enabled = tuple(ch.strip() for ch in raw.split(",") if ch.strip())
    return tuple(k for k in all_keys if k in enabled) or all_keys


# ---------------------------------------------------------------------------
# One-time migration: BASE_DIR/*.md + BASE_DIR/skills/ -> WORKING_DIR/
# ---------------------------------------------------------------------------


def migrate_to_workspace() -> bool:
    """Migrate legacy md files and skills from BASE_DIR into WORKING_DIR.

    This is a one-time migration that runs when WORKING_DIR does not yet exist
    (i.e. first start after upgrading to workspace-subdirectory layout).

    Moves:
    - ``BASE_DIR/*.md``  →  ``WORKING_DIR/*.md``
    - ``BASE_DIR/skills/``  →  ``WORKING_DIR/skills/``
    - ``BASE_DIR/memory/``  →  ``WORKING_DIR/memory/``
    - ``BASE_DIR/custom_channels/``  →  ``WORKING_DIR/custom_channels/``
    - ``BASE_DIR/uploads/``  →  ``WORKING_DIR/uploads/``

    Returns True if any migration was performed.
    """
    import logging
    import shutil

    logger = logging.getLogger(__name__)

    # Only migrate if WORKING_DIR doesn't exist yet (fresh layout transition)
    if WORKING_DIR.exists():
        return False

    WORKING_DIR.mkdir(parents=True, exist_ok=True)
    migrated = False

    # Move *.md files from BASE_DIR root
    for md_file in BASE_DIR.glob("*.md"):
        target = WORKING_DIR / md_file.name
        try:
            shutil.move(str(md_file), str(target))
            logger.info("Migrated md file: %s -> %s", md_file, target)
            migrated = True
        except Exception as exc:
            logger.warning("Failed to migrate %s: %s", md_file, exc)

    # Move directories: skills, memory, custom_channels, uploads
    for dir_name in ("skills", "memory", "custom_channels", "uploads"):
        src = BASE_DIR / dir_name
        dst = WORKING_DIR / dir_name
        if src.is_dir() and not dst.exists():
            try:
                shutil.move(str(src), str(dst))
                logger.info("Migrated directory: %s -> %s", src, dst)
                migrated = True
            except Exception as exc:
                logger.warning("Failed to migrate directory %s: %s", src, exc)

    if migrated:
        logger.info("Migration complete: agent workspace files moved to %s", WORKING_DIR)
    return migrated
