#!/usr/bin/env python3
# /// script
# requires-python = ">=3.10"
# dependencies = [
#     "httpx>=0.27.0",
# ]
# ///
"""
Style & Media Library CLI — Read-Only Skill

A lightweight CLI for viewing style presets and media assets.
Uses the same authentication as Agent Publisher.

Note: This skill is read-only. To create/edit/delete styles or manage media,
use the Agent Publisher skill.

Usage:
    uv run style_media_lib.py <command> [options]

Commands:
    auth            Authenticate with email, obtain a skill token
    whoami          Show current identity
    list-styles     List all style presets (read-only)
    media           List media assets (read-only)

Environment:
    AP_URL          Backend URL (default: http://localhost:9099)
    AP_TOKEN        Skill token (from 'auth' command). Can also use --token.
    AP_EMAIL        Email for auto-auth. Can also use --email.
"""

import argparse
import json
import os
import sys

import httpx

DEFAULT_URL = "http://localhost:9099"
TOKEN_FILE = os.path.expanduser("~/.agent-publisher-token")


# ---------------------------------------------------------------------------
# Helpers (shared with Agent Publisher)
# ---------------------------------------------------------------------------


def get_base_url(args):
    """Resolve the backend URL from args or environment."""
    return (getattr(args, "url", None) or os.environ.get("AP_URL") or DEFAULT_URL).rstrip("/")


def save_token(token, email):
    """Persist token locally for subsequent commands."""
    with open(TOKEN_FILE, "w") as f:
        json.dump({"token": token, "email": email}, f)
    os.chmod(TOKEN_FILE, 0o600)


def load_token():
    """Load persisted token."""
    if os.path.exists(TOKEN_FILE):
        with open(TOKEN_FILE) as f:
            return json.load(f)
    return None


def resolve_token(args):
    """Get the skill token from --token, env, or saved file."""
    token = getattr(args, "token", None) or os.environ.get("AP_TOKEN")
    if token:
        return token
    saved = load_token()
    if saved:
        return saved.get("token")
    return None


def api(method, url, token=None, **kwargs):
    """Make an HTTP request and return parsed JSON or exit on error."""
    headers = kwargs.pop("headers", {})
    if token:
        headers["Authorization"] = f"Bearer {token}"
    if "json" in kwargs:
        headers.setdefault("Content-Type", "application/json")

    try:
        resp = httpx.request(method, url, headers=headers, timeout=60, **kwargs)
    except httpx.ConnectError:
        print(f"Error: Cannot connect to {url}", file=sys.stderr)
        sys.exit(1)

    if resp.status_code >= 400:
        print(f"Error {resp.status_code}: {resp.text}", file=sys.stderr)
        sys.exit(1)

    if resp.headers.get("content-type", "").startswith("application/json"):
        return resp.json()
    return resp.text


def require_token(args):
    """Ensure we have a valid token, auto-auth if email is available."""
    token = resolve_token(args)
    if token:
        return token

    email = getattr(args, "email", None) or os.environ.get("AP_EMAIL")
    if email:
        base = get_base_url(args)
        result = api("POST", f"{base}/api/skills/auth", json={"email": email})
        save_token(result["token"], result["email"])
        return result["token"]

    print('Error: No token found. Run "auth" first or provide --email / AP_EMAIL.', file=sys.stderr)
    sys.exit(1)


def pp(data):
    """Pretty-print JSON data."""
    print(json.dumps(data, indent=2, ensure_ascii=False, default=str))


# ---------------------------------------------------------------------------
# Auth Commands
# ---------------------------------------------------------------------------


def cmd_auth(args):
    """Authenticate with email and save the token."""
    base = get_base_url(args)
    email = args.email or os.environ.get("AP_EMAIL")
    if not email:
        print("Error: --email is required for auth.", file=sys.stderr)
        sys.exit(1)

    result = api("POST", f"{base}/api/skills/auth", json={"email": email})
    save_token(result["token"], result["email"])
    print(f"✅ Authenticated as {result['email']} (admin={result['is_admin']})")
    print(f"Token saved to {TOKEN_FILE}")
    if args.show_token:
        print(f"Token: {result['token']}")


def cmd_whoami(args):
    """Show current identity."""
    base = get_base_url(args)
    token = require_token(args)
    result = api("GET", f"{base}/api/skills/whoami", token=token)
    pp(result)


# ---------------------------------------------------------------------------
# Style Commands
# ---------------------------------------------------------------------------


def cmd_list_styles(args):
    """List all style presets with full prompt content."""
    base = get_base_url(args)
    token = require_token(args)
    result = api("GET", f"{base}/api/skills/style-presets", token=token)
    if not result:
        print("No style presets found.")
        return
    for s in result:
        builtin = " [builtin]" if s.get("is_builtin") else " [custom]"
        print(f"\n  [{s['style_id']}] {s['name']}{builtin}")
        print(f"    Description: {s.get('description', '-')}")
        prompt = s.get("prompt", "")
        if len(prompt) > 200:
            print(f"    Prompt: {prompt[:200]}...")
        else:
            print(f"    Prompt: {prompt}")
    if args.full:
        print("\n--- Full prompt content ---")
        for s in result:
            print(f"\n=== {s['style_id']} ({s['name']}) ===")
            print(s.get("prompt", "(empty)"))


# ---------------------------------------------------------------------------
# Media Commands
# ---------------------------------------------------------------------------


def cmd_media(args):
    """List media assets."""
    base = get_base_url(args)
    token = require_token(args)
    params = []
    if args.tag:
        params.append(f"tag={args.tag}")
    if args.page:
        params.append(f"page={args.page}")
    url = f"{base}/api/skills/media"
    if params:
        url += "?" + "&".join(params)
    result = api("GET", url, token=token)
    if not result:
        print('No media assets found. Use "upload-media" to add one.')
        return
    # Support both paginated format {items, total, ...} and legacy array format
    items = result.get("items", result) if isinstance(result, dict) else result
    if isinstance(result, dict) and "total" in result:
        print(
            f"  Total: {result['total']}  Page: {result.get('page', 1)}/{max(1, -(-result['total'] // result.get('page_size', 50)))}"
        )
    if not items:
        print('No media assets found. Use "upload-media" to add one.')
        return
    for m in items:
        size_kb = m.get("file_size", 0) / 1024
        tags = ", ".join(m.get("tags", [])) or "-"
        source = m.get("source_kind", "-")
        print(f"  [{m['id']}] {m['filename']}  {size_kb:.1f}KB  source={source}  tags=[{tags}]  url={m.get('url')}")


def cmd_upload_media(args):
    """Upload a file to the media library."""
    base = get_base_url(args)
    token = require_token(args)
    file_path = args.file

    if not os.path.isfile(file_path):
        print(f"Error: File not found: {file_path}", file=sys.stderr)
        sys.exit(1)

    filename = os.path.basename(file_path)
    with open(file_path, "rb") as f:
        file_content = f.read()

    headers = {"Authorization": f"Bearer {token}"}
    files = {"file": (filename, file_content)}
    data = {}
    if args.tags:
        data["tags"] = args.tags
    if args.description:
        data["description"] = args.description

    try:
        resp = httpx.post(
            f"{base}/api/skills/media",
            headers=headers,
            files=files,
            data=data,
            timeout=120,
        )
    except httpx.ConnectError:
        print(f"Error: Cannot connect to {base}", file=sys.stderr)
        sys.exit(1)

    if resp.status_code >= 400:
        print(f"Error {resp.status_code}: {resp.text}", file=sys.stderr)
        sys.exit(1)

    result = resp.json()
    print(f"✅ Uploaded: id={result['id']} filename={result['filename']} size={result['file_size']}")
    print(f"   URL: {base}{result.get('url', '')}")
    if result.get("tags"):
        print(f"   Tags: {', '.join(result['tags'])}")


def cmd_delete_media(args):
    """Delete a media asset."""
    base = get_base_url(args)
    token = require_token(args)
    result = api("DELETE", f"{base}/api/skills/media/{args.media_id}", token=token)
    if result.get("ok"):
        print(f"✅ Deleted media asset {args.media_id}")
    else:
        print(f"❌ Failed: {result}")


# ---------------------------------------------------------------------------
# CLI parser
# ---------------------------------------------------------------------------


def build_parser():
    parser = argparse.ArgumentParser(
        prog="style_media_lib",
        description="Style & Media Library CLI — Lightweight Skill Script",
    )
    parser.add_argument("--url", help=f"Backend URL (default: {DEFAULT_URL}, env: AP_URL)")
    parser.add_argument("--token", help="Skill token (env: AP_TOKEN)")
    parser.add_argument("--email", help="Email for auto-auth (env: AP_EMAIL)")

    sub = parser.add_subparsers(dest="command", required=True)

    # auth
    p = sub.add_parser("auth", help="Authenticate with email")
    p.add_argument("--email", "-e", dest="email", help="Your whitelisted email")
    p.add_argument("--show-token", action="store_true", help="Print token to stdout")
    p.set_defaults(func=cmd_auth)

    # whoami
    p = sub.add_parser("whoami", help="Show current identity")
    p.set_defaults(func=cmd_whoami)

    # list-styles
    p = sub.add_parser("list-styles", help="List all style presets (read-only)")
    p.add_argument("--full", action="store_true", help="Show full prompt content")
    p.set_defaults(func=cmd_list_styles)

    # media
    p = sub.add_parser("media", help="List media assets (read-only)")
    p.add_argument("--tag", help="Filter by tag")
    p.add_argument("--page", type=int, default=1, help="Page number")
    p.set_defaults(func=cmd_media)

    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
