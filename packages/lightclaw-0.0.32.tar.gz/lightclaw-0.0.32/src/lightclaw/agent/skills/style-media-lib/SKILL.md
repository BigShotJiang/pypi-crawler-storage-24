---
name: style-media-lib
description: 只读访问风格预设和素材库。通过邮箱认证后即可浏览可用资源。
metadata:
  openclaw:
    emoji: "🎨"
    requires: { "bins": ["uv", "curl"] }
    primaryEnv: "AP_EMAIL"
---

# 风格预设 & 素材库 Skill（只读）

轻量级 skill，用于**查看**风格预设和素材资源。与 Agent Publisher 共享同一套认证机制。

**注意**：本 skill 为只读模式。如需创建/编辑/删除风格或管理素材，请使用 Agent Publisher skill。

## 前置条件

- **Agent Publisher 后端**已运行（默认地址：`http://43.132.178.232:9099`）
- 你的邮箱已在后端白名单中
- 已安装 `uv`（用于运行内置 Python 脚本）

## 快速开始

### 第 1 步：认证

```bash
uv run {baseDir}/scripts/style_media_lib.py --url "$AP_URL" auth --email "user@example.com"
```

认证后 token 会保存到 `~/.agent-publisher-token`（与 Agent Publisher 共享）。

### 第 2 步：验证身份

```bash
uv run {baseDir}/scripts/style_media_lib.py whoami
```

---

## 全部命令

### 浏览风格预设（只读）

**列出所有风格预设（内置 + 自定义）：**

```bash
uv run {baseDir}/scripts/style_media_lib.py list-styles
uv run {baseDir}/scripts/style_media_lib.py list-styles --full  # 显示完整的 prompt 内容
```

**注意**：如需创建、编辑或删除风格预设，请使用 Agent Publisher skill。

### 浏览素材库（只读）

**列出素材资源：**

```bash
uv run {baseDir}/scripts/style_media_lib.py media
uv run {baseDir}/scripts/style_media_lib.py media --tag "cover"
uv run {baseDir}/scripts/style_media_lib.py media --page 2
```

**注意**：如需上传或删除素材，请使用 Agent Publisher skill。

---

## 环境变量

| 变量名     | 说明                                          | 默认值                           |
|-----------|----------------------------------------------|----------------------------------|
| `AP_URL`   | 后端地址                                      | `http://localhost:9099`          |
| `AP_EMAIL` | 用于自动认证的邮箱                              | —                                |
| `AP_TOKEN` | Skill token（替代保存的 token 文件）             | —                                |

---

## 说明

- Token 与 Agent Publisher skill 共享（同一个 `~/.agent-publisher-token` 文件）
- Token 有效期 30 天，过期后重新执行 `auth` 命令即可刷新
