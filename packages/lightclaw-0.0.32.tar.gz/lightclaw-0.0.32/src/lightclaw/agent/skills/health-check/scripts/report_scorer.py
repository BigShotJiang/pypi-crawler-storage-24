#!/usr/bin/env python3
"""LightClaw 安全自检评分器 — 根据 health_check.py 输出的 JSON 计算分数。

读取 stdin 的 JSON 数据，按评分规则输出各维度得分和总分。

Usage:
    python health_check.py | python report_scorer.py
    python report_scorer.py < health_data.json
"""

from __future__ import annotations

import contextlib
import json
import sys
from typing import Any

DIMENSION_WEIGHTS = {
    "process": 20,
    "logs": 15,
    "auth_security": 15,
    "network": 15,
    "storage": 10,
    "host_environment": 10,
    "lightclaw_config": 10,
    "dependencies": 5,
}

DIMENSION_LABELS = {
    "process": "🫀 进程生命体征",
    "logs": "🧠 日志观测",
    "auth_security": "🔐 认证与密钥安全",
    "network": "🌐 网络安全",
    "storage": "💾 存储与数据安全",
    "host_environment": "🖥️ 宿主环境安全",
    "lightclaw_config": "⚙️ LightClaw 配置健康",
    "dependencies": "🛡️ 依赖与供应链安全",
}

RATINGS = [
    (90, "S", "🏆 铜墙铁壁·无懈可击"),
    (80, "A", "🛡️ 坚如磐石·值得信赖"),
    (70, "B", "👍 状态良好·小有瑕疵"),
    (60, "C", "⚠️ 亚健康·需要关注"),
    (40, "D", "🚨 状况频出·亟需修复"),
    (0, "F", "💀 病入膏肓·紧急抢救"),
]


def _clamp(value: float, lo: float = 0, hi: float = 100) -> float:
    return max(lo, min(hi, value))


def score_process(data: dict[str, Any]) -> tuple[float, list[dict]]:
    """Score process health (max 100, then scaled by weight)."""
    score = 100.0
    findings: list[dict] = []

    if not data.get("lightclaw_running"):
        return 0, [{"severity": "critical", "item": "LightClaw 进程未运行", "deduction": 100}]

    cpu = data.get("cpu_percent")
    if cpu is not None:
        if cpu > 80:
            d = 40
            findings.append({"severity": "high", "item": f"CPU 使用率过高: {cpu}%", "deduction": d})
            score -= d
        elif cpu > 60:
            d = 25
            findings.append(
                {
                    "severity": "medium",
                    "item": f"CPU 使用率偏高: {cpu}%",
                    "deduction": d,
                }
            )
            score -= d
        elif cpu > 30:
            d = 15
            findings.append({"severity": "low", "item": f"CPU 使用率略高: {cpu}%", "deduction": d})
            score -= d

    mem = data.get("memory_mb")
    if mem is not None:
        if mem > 1024:
            d = 25
            findings.append(
                {
                    "severity": "medium",
                    "item": f"内存占用较大: {mem:.0f}MB",
                    "deduction": d,
                }
            )
            score -= d
        elif mem > 500:
            d = 10
            findings.append(
                {
                    "severity": "low",
                    "item": f"内存占用偏高: {mem:.0f}MB",
                    "deduction": d,
                }
            )
            score -= d

    threads = data.get("threads")
    if threads is not None:
        if threads > 200:
            d = 20
            findings.append({"severity": "medium", "item": f"线程数过多: {threads}", "deduction": d})
            score -= d
        elif threads > 100:
            d = 10
            findings.append({"severity": "low", "item": f"线程数偏多: {threads}", "deduction": d})
            score -= d

    return _clamp(score), findings


def score_logs(data: dict[str, Any]) -> tuple[float, list[dict]]:
    score = 100.0
    findings: list[dict] = []

    if not data.get("logs_dir_exists"):
        return 50, [{"severity": "medium", "item": "日志目录不存在", "deduction": 50}]

    if not data.get("logs_dir_writable"):
        d = 25
        findings.append({"severity": "medium", "item": "日志目录不可写", "deduction": d})
        score -= d

    errors = data.get("error_count_24h", 0)
    if errors > 20:
        d = 40
        findings.append({"severity": "high", "item": f"ERROR 日志过多: {errors} 条", "deduction": d})
        score -= d
    elif errors > 5:
        d = 25
        findings.append(
            {
                "severity": "medium",
                "item": f"ERROR 日志较多: {errors} 条",
                "deduction": d,
            }
        )
        score -= d
    elif errors > 0:
        d = 10
        findings.append({"severity": "low", "item": f"存在少量 ERROR: {errors} 条", "deduction": d})
        score -= d

    warnings = data.get("warning_count_24h", 0)
    if warnings > 20:
        d = 20
        findings.append(
            {
                "severity": "medium",
                "item": f"WARNING 较多: {warnings} 条",
                "deduction": d,
            }
        )
        score -= d
    elif warnings > 5:
        d = 10
        findings.append({"severity": "low", "item": f"WARNING 偏多: {warnings} 条", "deduction": d})
        score -= d

    panics = data.get("panic_traceback_count", 0)
    if panics > 0:
        d = 25
        findings.append(
            {
                "severity": "high",
                "item": f"发现 Traceback/Panic: {panics} 处",
                "deduction": d,
            }
        )
        score -= d

    log_size = data.get("latest_log_size_bytes", 0)
    if log_size > 500 * 1024 * 1024:
        d = 30
        findings.append(
            {
                "severity": "high",
                "item": f"日志文件过大: {log_size / 1024 / 1024:.0f}MB",
                "deduction": d,
            }
        )
        score -= d
    elif log_size > 100 * 1024 * 1024:
        d = 15
        findings.append(
            {
                "severity": "medium",
                "item": f"日志文件偏大: {log_size / 1024 / 1024:.0f}MB",
                "deduction": d,
            }
        )
        score -= d

    return _clamp(score), findings


def score_auth_security(data: dict[str, Any]) -> tuple[float, list[dict]]:
    score = 100.0
    findings: list[dict] = []

    if data.get("api_key_in_logs"):
        d = 50
        findings.append(
            {
                "severity": "critical",
                "item": "API Key 可能暴露在日志中！",
                "deduction": d,
            }
        )
        score -= d

    for sf in data.get("sensitive_files", []):
        if sf.get("status") == "too_permissive":
            d = 25
            findings.append(
                {
                    "severity": "high",
                    "item": f"敏感文件权限过于宽松: {sf.get('path')} ({sf.get('permissions')})",
                    "deduction": d,
                }
            )
            score -= d

    return _clamp(score), findings


def score_network(data: dict[str, Any]) -> tuple[float, list[dict]]:
    score = 100.0
    findings: list[dict] = []

    if not data.get("dns_resolution"):
        d = 25
        findings.append({"severity": "medium", "item": "DNS 解析异常", "deduction": d})
        score -= d

    if data.get("firewall_enabled") is False:
        d = 15
        findings.append({"severity": "low", "item": "防火墙未启用", "deduction": d})
        score -= d

    # Check for 0.0.0.0 bindings
    for port_line in data.get("listening_ports", []):
        if "0.0.0.0" in port_line or "*:" in port_line:
            d = 10
            findings.append(
                {
                    "severity": "low",
                    "item": f"服务监听在所有接口: {port_line[:80]}",
                    "deduction": d,
                }
            )
            score -= d
            break  # only deduct once

    return _clamp(score), findings


def score_storage(data: dict[str, Any]) -> tuple[float, list[dict]]:
    score = 100.0
    findings: list[dict] = []

    free_pct = data.get("disk_free_percent")
    if free_pct is not None:
        if free_pct < 10:
            d = 40
            findings.append(
                {
                    "severity": "critical",
                    "item": f"磁盘空间严重不足: 仅剩 {free_pct}%",
                    "deduction": d,
                }
            )
            score -= d
        elif free_pct < 20:
            d = 15
            findings.append(
                {
                    "severity": "medium",
                    "item": f"磁盘空间偏低: 剩余 {free_pct}%",
                    "deduction": d,
                }
            )
            score -= d

    lc_size = data.get("lightclaw_dir_size_bytes", 0)
    if lc_size > 5 * 1024**3:
        d = 25
        findings.append(
            {
                "severity": "medium",
                "item": f"LightClaw 数据目录过大: {data.get('lightclaw_dir_size')}",
                "deduction": d,
            }
        )
        score -= d
    elif lc_size > 1024**3:
        d = 10
        findings.append(
            {
                "severity": "low",
                "item": f"LightClaw 数据目录偏大: {data.get('lightclaw_dir_size')}",
                "deduction": d,
            }
        )
        score -= d

    return _clamp(score), findings


def score_host_environment(data: dict[str, Any]) -> tuple[float, list[dict]]:
    score = 100.0
    findings: list[dict] = []

    if data.get("running_as_root"):
        d = 25
        findings.append({"severity": "high", "item": "以 root 用户运行 LightClaw", "deduction": d})
        score -= d

    py_ver = data.get("python_version", "0.0.0")
    major, minor = 0, 0
    try:
        parts = py_ver.split(".")
        major, minor = int(parts[0]), int(parts[1])
    except (ValueError, IndexError):
        pass
    if major == 3 and minor < 10:
        d = 15 if minor < 8 else 10
        findings.append({"severity": "medium", "item": f"Python 版本偏低: {py_ver}", "deduction": d})
        score -= d

    uptime = data.get("uptime_seconds")
    if uptime and uptime > 365 * 86400:
        d = 10
        findings.append(
            {
                "severity": "low",
                "item": f"系统运行超过一年未重启: {data.get('uptime_human')}",
                "deduction": d,
            }
        )
        score -= d

    if data.get("ssh_password_auth") == "yes":
        d = 15
        findings.append({"severity": "medium", "item": "SSH 允许密码登录", "deduction": d})
        score -= d

    if data.get("ssh_root_login") == "yes":
        d = 15
        findings.append({"severity": "medium", "item": "SSH 允许 root 登录", "deduction": d})
        score -= d

    return _clamp(score), findings


def score_lightclaw_config(data: dict[str, Any]) -> tuple[float, list[dict]]:
    score = 100.0
    findings: list[dict] = []

    if not data.get("config_parseable"):
        return 0, [
            {
                "severity": "critical",
                "item": f"配置文件无法解析: {data.get('error')}",
                "deduction": 100,
            }
        ]

    if not data.get("has_providers"):
        d = 25
        findings.append({"severity": "medium", "item": "未配置任何 Provider", "deduction": d})
        score -= d

    if not data.get("has_skills"):
        d = 10
        findings.append({"severity": "low", "item": "没有启用任何 Skill", "deduction": d})
        score -= d

    interval = data.get("heartbeat_interval")
    if interval and isinstance(interval, str):
        # Parse interval like "5m", "1h"
        match_m = None
        if interval.endswith("m"):
            with contextlib.suppress(ValueError):
                match_m = int(interval[:-1])
        if match_m is not None and match_m < 5:
            d = 10
            findings.append(
                {
                    "severity": "low",
                    "item": f"Heartbeat 间隔过短: {interval}",
                    "deduction": d,
                }
            )
            score -= d

    return _clamp(score), findings


def score_dependencies(data: dict[str, Any]) -> tuple[float, list[dict]]:
    score = 100.0
    findings: list[dict] = []

    vulns = data.get("known_vulnerabilities", 0)
    if vulns > 0:
        d = min(50, vulns * 15)
        findings.append({"severity": "high", "item": f"发现 {vulns} 个已知安全漏洞", "deduction": d})
        score -= d

    pip_source = data.get("pip_source", "")
    if (
        pip_source
        and "pypi.org" not in pip_source
        and "tuna" not in pip_source
        and "aliyun" not in pip_source
        and "default" not in pip_source.lower()
    ):
        d = 10
        findings.append(
            {
                "severity": "low",
                "item": f"使用非标准 pip 源: {pip_source}",
                "deduction": d,
            }
        )
        score -= d

    return _clamp(score), findings


SCORERS = {
    "process": score_process,
    "logs": score_logs,
    "auth_security": score_auth_security,
    "network": score_network,
    "storage": score_storage,
    "host_environment": score_host_environment,
    "lightclaw_config": score_lightclaw_config,
    "dependencies": score_dependencies,
}


def compute_scores(report_data: dict[str, Any]) -> dict[str, Any]:
    checks = report_data.get("checks", {})
    results: dict[str, Any] = {
        "dimensions": {},
        "total_score": 0,
        "rating": "",
        "rating_title": "",
        "all_findings": [],
    }

    weighted_sum = 0.0
    for dim_key, weight in DIMENSION_WEIGHTS.items():
        dim_data = checks.get(dim_key, {})
        scorer = SCORERS.get(dim_key)
        if scorer:
            raw_score, findings = scorer(dim_data)
        else:
            raw_score, findings = 100.0, []

        # Weighted contribution
        weighted = raw_score * weight / 100
        weighted_sum += weighted

        results["dimensions"][dim_key] = {
            "label": DIMENSION_LABELS.get(dim_key, dim_key),
            "weight": weight,
            "raw_score": round(raw_score, 1),
            "weighted_score": round(weighted, 1),
            "max_weighted_score": weight,
            "findings": findings,
        }
        for f in findings:
            f["dimension"] = DIMENSION_LABELS.get(dim_key, dim_key)
            results["all_findings"].append(f)

    results["total_score"] = round(weighted_sum, 1)

    # Rating
    for threshold, grade, title in RATINGS:
        if results["total_score"] >= threshold:
            results["rating"] = grade
            results["rating_title"] = title
            break

    # Sort findings by severity
    severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    results["all_findings"].sort(key=lambda x: severity_order.get(x.get("severity", "low"), 9))

    return results


def main() -> None:
    raw = sys.stdin.read()
    report_data = json.loads(raw)
    scores = compute_scores(report_data)

    # Merge scores into report
    output = {
        "raw_data": report_data,
        "scores": scores,
    }
    print(json.dumps(output, indent=2, ensure_ascii=False, default=str))


if __name__ == "__main__":
    main()
