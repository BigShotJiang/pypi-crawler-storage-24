#!/usr/bin/env python3
"""LightClaw 安全自检脚本 — 全面收集系统健康与安全数据。

输出 JSON 格式的检查结果，供 Agent 分析和生成报告。
兼容 macOS 和 Linux。

Usage:
    python health_check.py [--lightclaw-dir ~/.lightclaw] [--pretty]
"""

from __future__ import annotations

import argparse
import contextlib
import json
import os
import platform
import re
import shutil
import socket
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _run(cmd: str | list[str], timeout: int = 15) -> tuple[str, int]:
    """Run a shell command and return (stdout, returncode)."""
    try:
        if isinstance(cmd, str):
            result = subprocess.run(
                cmd,
                shell=True,
                capture_output=True,
                text=True,
                timeout=timeout,
            )
        else:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout,
            )
        return result.stdout.strip(), result.returncode
    except subprocess.TimeoutExpired:
        return "", -1
    except Exception as exc:
        return str(exc), -1


def _safe_stat(path: str | Path) -> dict[str, Any]:
    """Return file/dir stat info safely."""
    p = Path(path)
    if not p.exists():
        return {"exists": False}
    try:
        st = p.stat()
        return {
            "exists": True,
            "size_bytes": st.st_size,
            "mode_octal": oct(st.st_mode)[-3:],
            "uid": st.st_uid,
            "gid": st.st_gid,
            "mtime": datetime.fromtimestamp(st.st_mtime, tz=UTC).isoformat(),
        }
    except Exception as exc:
        return {"exists": True, "error": str(exc)}


def _dir_total_size(path: Path) -> int:
    """Recursively sum the size of all files under *path*."""
    total = 0
    try:
        for f in path.rglob("*"):
            if f.is_file():
                with contextlib.suppress(OSError):
                    total += f.stat().st_size
    except Exception:
        pass
    return total


def _bytes_human(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(n) < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024  # type: ignore[assignment]
    return f"{n:.1f} PB"


def _is_mac() -> bool:
    return platform.system() == "Darwin"


# ---------------------------------------------------------------------------
# Check modules
# ---------------------------------------------------------------------------


def check_process() -> dict[str, Any]:
    """维度一：进程生命体征。"""
    result: dict[str, Any] = {
        "lightclaw_running": False,
        "pids": [],
        "cpu_percent": None,
        "memory_mb": None,
        "threads": None,
        "uptime_seconds": None,
        "command": None,
    }

    # Find LightClaw process(es)
    ps_out, rc = _run("ps aux")
    if rc != 0:
        result["error"] = "ps command failed"
        return result

    lc_lines = []
    for line in ps_out.splitlines():
        lower = line.lower()
        if ("lightclaw" in lower or "uvicorn" in lower) and "health_check" not in lower:
            lc_lines.append(line)

    if not lc_lines:
        return result

    result["lightclaw_running"] = True
    result["process_lines"] = lc_lines[:5]  # cap for readability

    # Try to get detailed info via the first matching PID
    for line in lc_lines:
        parts = line.split()
        if len(parts) < 2:
            continue
        pid = parts[1]
        if not pid.isdigit():
            continue
        result["pids"].append(int(pid))

    if result["pids"]:
        pid = result["pids"][0]
        # CPU & memory via ps
        ps_detail, _ = _run(f"ps -p {pid} -o %cpu,%mem,rss,etime,nlwp 2>/dev/null")
        lines = ps_detail.strip().splitlines()
        if len(lines) >= 2:
            vals = lines[-1].split()
            with contextlib.suppress(IndexError, ValueError):
                result["cpu_percent"] = float(vals[0])
            with contextlib.suppress(IndexError, ValueError):
                result["memory_mb"] = int(vals[2]) / 1024  # rss in KB -> MB
            with contextlib.suppress(IndexError, ValueError):
                result["threads"] = int(vals[4])

        # macOS fallback for threads
        if result["threads"] is None and _is_mac():
            thr_out, _ = _run(f"ps -M -p {pid} 2>/dev/null | tail -n +2 | wc -l")
            with contextlib.suppress(ValueError):
                result["threads"] = int(thr_out.strip())

        # Uptime via /proc or ps etime
        proc_uptime = Path(f"/proc/{pid}/stat")
        if proc_uptime.exists():
            try:
                boot_out, _ = _run("cat /proc/uptime")
                sys_up = float(boot_out.split()[0])
                stat_content = proc_uptime.read_text()
                starttime_ticks = int(stat_content.split()[21])
                clk_tck_out, _ = _run("getconf CLK_TCK")
                clk_tck = int(clk_tck_out) if clk_tck_out else 100
                result["uptime_seconds"] = sys_up - (starttime_ticks / clk_tck)
            except Exception:
                pass

    return result


def check_logs(lightclaw_dir: Path) -> dict[str, Any]:
    """维度二：日志观测。"""
    logs_dir = lightclaw_dir / "logs"
    result: dict[str, Any] = {
        "logs_dir_exists": logs_dir.is_dir(),
        "logs_dir_writable": os.access(str(logs_dir), os.W_OK) if logs_dir.is_dir() else False,
        "log_files": [],
        "latest_log": None,
        "latest_log_size_bytes": 0,
        "error_count_24h": 0,
        "warning_count_24h": 0,
        "panic_traceback_count": 0,
        "recent_errors": [],
        "recent_warnings": [],
    }

    if not logs_dir.is_dir():
        return result

    log_files = sorted(logs_dir.glob("lightclaw.log*"), key=lambda p: p.stat().st_mtime, reverse=True)
    result["log_files"] = [
        {
            "name": f.name,
            "size": _bytes_human(f.stat().st_size),
            "size_bytes": f.stat().st_size,
        }
        for f in log_files[:10]
    ]

    if not log_files:
        return result

    latest = log_files[0]
    result["latest_log"] = latest.name
    result["latest_log_size_bytes"] = latest.stat().st_size

    # Analyze latest log
    try:
        content = latest.read_text(encoding="utf-8", errors="replace")
        lines = content.splitlines()

        errors = [line for line in lines if "ERROR" in line]
        warnings = [line for line in lines if "WARNING" in line]
        panics = [line for line in lines if "Traceback" in line or "panic" in line.lower()]

        result["error_count_24h"] = len(errors)
        result["warning_count_24h"] = len(warnings)
        result["panic_traceback_count"] = len(panics)
        result["recent_errors"] = errors[-5:]
        result["recent_warnings"] = warnings[-5:]
    except Exception as exc:
        result["log_read_error"] = str(exc)

    return result


def check_auth_security(lightclaw_dir: Path) -> dict[str, Any]:
    """维度三：认证与密钥安全。"""
    result: dict[str, Any] = {
        "config_file_permissions": None,
        "env_file_permissions": None,
        "api_key_in_logs": False,
        "hardcoded_secrets_risk": False,
        "sensitive_files": [],
    }

    # Check config file permissions
    config_file = lightclaw_dir / "lightclaw.json"
    if config_file.exists():
        stat = _safe_stat(config_file)
        result["config_file_permissions"] = stat.get("mode_octal")
        result["sensitive_files"].append(
            {
                "path": str(config_file),
                "permissions": stat.get("mode_octal"),
                "status": "ok" if stat.get("mode_octal", "777") in ("600", "644", "640") else "too_permissive",
            }
        )

    # Check providers file
    providers_file = lightclaw_dir / "providers.json"
    if providers_file.exists():
        stat = _safe_stat(providers_file)
        result["sensitive_files"].append(
            {
                "path": str(providers_file),
                "permissions": stat.get("mode_octal"),
                "status": "ok" if stat.get("mode_octal", "777") in ("600", "644", "640") else "too_permissive",
            }
        )

    # Check .env files
    for env_name in (".env", ".env.local"):
        env_file = lightclaw_dir / env_name
        if env_file.exists():
            stat = _safe_stat(env_file)
            result["env_file_permissions"] = stat.get("mode_octal")
            result["sensitive_files"].append(
                {
                    "path": str(env_file),
                    "permissions": stat.get("mode_octal"),
                    "status": "ok" if stat.get("mode_octal", "777") == "600" else "too_permissive",
                }
            )

    # Check if API keys appear in log files
    logs_dir = lightclaw_dir / "logs"
    if logs_dir.is_dir():
        for log_file in logs_dir.glob("lightclaw.log*"):
            try:
                content = log_file.read_text(encoding="utf-8", errors="replace")
                # Pattern: common API key formats
                key_patterns = [
                    r"sk-[a-zA-Z0-9]{20,}",  # OpenAI-style
                    r"key-[a-zA-Z0-9]{20,}",
                    r'"api_key"\s*:\s*"[^"]{20,}"',
                    r'"secret"\s*:\s*"[^"]{10,}"',
                ]
                for pattern in key_patterns:
                    if re.search(pattern, content):
                        result["api_key_in_logs"] = True
                        break
                if result["api_key_in_logs"]:
                    break
            except Exception:
                continue

    return result


def check_network() -> dict[str, Any]:
    """维度四：网络安全。"""
    result: dict[str, Any] = {
        "listening_ports": [],
        "dns_resolution": False,
        "external_connections": [],
        "firewall_enabled": None,
    }

    # Listening ports
    if _is_mac():
        ports_out, _ = _run("lsof -iTCP -sTCP:LISTEN -nP 2>/dev/null | grep -i 'lightclaw\\|uvicorn\\|python'")
    else:
        ports_out, _ = _run("ss -tlnp 2>/dev/null || netstat -tlnp 2>/dev/null")

    if ports_out:
        for line in ports_out.splitlines()[:20]:
            result["listening_ports"].append(line.strip())

    # Also get a clean port list
    if _is_mac():
        clean_ports, _ = _run("lsof -iTCP -sTCP:LISTEN -nP 2>/dev/null")
    else:
        clean_ports, _ = _run("ss -tlnp 2>/dev/null")
    result["all_listening_ports_summary"] = clean_ports[:3000] if clean_ports else "unable to retrieve"

    # DNS resolution
    try:
        socket.getaddrinfo("api.openai.com", 443, socket.AF_INET, socket.SOCK_STREAM)
        result["dns_resolution"] = True
    except Exception:
        result["dns_resolution"] = False

    # Firewall status
    if _is_mac():
        fw_out, rc = _run("/usr/libexec/ApplicationFirewall/socketfilterfw --getglobalstate 2>/dev/null")
        result["firewall_enabled"] = "enabled" in fw_out.lower() if rc == 0 else None
    else:
        # Linux: check ufw, firewalld, iptables
        for fw_cmd, kw in [
            ("ufw status 2>/dev/null", "active"),
            ("firewall-cmd --state 2>/dev/null", "running"),
            ("iptables -L -n 2>/dev/null | head -5", "chain"),
        ]:
            fw_out, rc = _run(fw_cmd)
            if rc == 0 and kw in fw_out.lower():
                result["firewall_enabled"] = True
                break

    # Suspicious outbound (lightweight sample)
    if _is_mac():
        estab_out, _ = _run("lsof -i -nP 2>/dev/null | grep ESTABLISHED | head -20")
    else:
        estab_out, _ = _run("ss -tnp 2>/dev/null | grep ESTAB | head -20")
    if estab_out:
        result["external_connections"] = estab_out.splitlines()[:15]

    return result


def check_storage(lightclaw_dir: Path) -> dict[str, Any]:
    """维度五：存储与数据安全。"""
    result: dict[str, Any] = {}

    # Disk usage
    try:
        usage = shutil.disk_usage(str(lightclaw_dir))
        result["disk_total_gb"] = round(usage.total / (1024**3), 1)
        result["disk_used_gb"] = round(usage.used / (1024**3), 1)
        result["disk_free_gb"] = round(usage.free / (1024**3), 1)
        result["disk_free_percent"] = round(usage.free / usage.total * 100, 1)
    except Exception as exc:
        result["disk_error"] = str(exc)

    # LightClaw data size
    lc_size = _dir_total_size(lightclaw_dir)
    result["lightclaw_dir_size"] = _bytes_human(lc_size)
    result["lightclaw_dir_size_bytes"] = lc_size

    # Workspace subdirs size
    workspace = lightclaw_dir / "workspace"
    if workspace.is_dir():
        for subdir in ("skills", "memory", "uploads"):
            sd = workspace / subdir
            if sd.is_dir():
                result[f"{subdir}_size"] = _bytes_human(_dir_total_size(sd))

    # Database file check
    db_files = list(lightclaw_dir.rglob("*.db")) + list(lightclaw_dir.rglob("*.sqlite*"))
    result["database_files"] = [{"path": str(f.relative_to(lightclaw_dir)), **_safe_stat(f)} for f in db_files[:5]]

    # Temp files
    tmp_path = Path("/tmp")
    if tmp_path.is_dir():
        lc_tmp = [f for f in tmp_path.iterdir() if "lightclaw" in f.name.lower()]
        result["tmp_lightclaw_files"] = len(lc_tmp)

    return result


def check_host_environment() -> dict[str, Any]:
    """维度六：宿主环境安全。"""
    result: dict[str, Any] = {
        "os": platform.system(),
        "os_version": platform.version(),
        "os_release": platform.release(),
        "architecture": platform.machine(),
        "hostname": socket.gethostname(),
        "python_version": platform.python_version(),
        "running_as_root": os.getuid() == 0 if hasattr(os, "getuid") else None,
        "current_user": os.environ.get("USER") or os.environ.get("USERNAME", "unknown"),
    }

    # System uptime
    if _is_mac():
        boot_out, _ = _run("sysctl -n kern.boottime 2>/dev/null")
        match = re.search(r"sec\s*=\s*(\d+)", boot_out)
        if match:
            boot_time = int(match.group(1))
            result["uptime_seconds"] = int(time.time() - boot_time)
            result["uptime_human"] = _format_duration(result["uptime_seconds"])
    else:
        up_out, _ = _run("cat /proc/uptime 2>/dev/null")
        if up_out:
            try:
                result["uptime_seconds"] = int(float(up_out.split()[0]))
                result["uptime_human"] = _format_duration(result["uptime_seconds"])
            except (ValueError, IndexError):
                pass

    # SSH config (if applicable)
    ssh_config = Path("/etc/ssh/sshd_config")
    if ssh_config.exists():
        try:
            ssh_content = ssh_config.read_text(encoding="utf-8", errors="replace")
            result["ssh_password_auth"] = (
                "yes" if re.search(r"^\s*PasswordAuthentication\s+yes", ssh_content, re.MULTILINE) else "no"
            )
            result["ssh_root_login"] = (
                "yes" if re.search(r"^\s*PermitRootLogin\s+yes", ssh_content, re.MULTILINE) else "no"
            )
        except Exception:
            result["ssh_config_readable"] = False

    # Security updates (best effort — skip on macOS as softwareupdate is slow)
    if _is_mac():
        result["pending_updates"] = None  # softwareupdate -l is too slow for inline check
    else:
        apt_out, rc = _run("apt list --upgradable 2>/dev/null | grep -i security | wc -l", timeout=10)
        if rc == 0:
            with contextlib.suppress(ValueError):
                result["pending_security_updates"] = int(apt_out.strip())

    return result


def check_lightclaw_config(lightclaw_dir: Path) -> dict[str, Any]:
    """维度七：LightClaw 配置健康。"""
    result: dict[str, Any] = {
        "config_parseable": False,
        "has_providers": False,
        "provider_count": 0,
        "has_skills": False,
        "enabled_skills_count": 0,
        "heartbeat_configured": False,
        "heartbeat_interval": None,
        "channels_configured": [],
    }

    config_file = lightclaw_dir / "lightclaw.json"
    if not config_file.exists():
        result["error"] = "lightclaw.json not found"
        return result

    try:
        config = json.loads(config_file.read_text(encoding="utf-8"))
        result["config_parseable"] = True
    except Exception as exc:
        result["error"] = f"Config parse error: {exc}"
        return result

    # Providers
    providers_file = lightclaw_dir / "providers.json"
    if providers_file.exists():
        try:
            providers = json.loads(providers_file.read_text(encoding="utf-8"))
            if isinstance(providers, list):
                result["has_providers"] = len(providers) > 0
                result["provider_count"] = len(providers)
                result["provider_names"] = [p.get("name", "unknown") for p in providers if isinstance(p, dict)][:10]
            elif isinstance(providers, dict):
                entries = providers.get("entries", providers)
                if isinstance(entries, dict):
                    result["has_providers"] = len(entries) > 0
                    result["provider_count"] = len(entries)
        except Exception:
            pass

    # Skills
    skills = config.get("skills", {})
    entries = skills.get("entries", {}) if isinstance(skills, dict) else {}
    enabled = [name for name, entry in entries.items() if isinstance(entry, dict) and entry.get("enabled")]
    result["has_skills"] = len(enabled) > 0
    result["enabled_skills_count"] = len(enabled)
    result["enabled_skills"] = enabled

    # Heartbeat
    agents = config.get("agents", {})
    defaults = agents.get("defaults", {}) if isinstance(agents, dict) else {}
    heartbeat = defaults.get("heartbeat") if isinstance(defaults, dict) else None
    if heartbeat and isinstance(heartbeat, dict):
        result["heartbeat_configured"] = True
        result["heartbeat_interval"] = heartbeat.get("every")

    # Channels (from config)
    channels = config.get("channels", {})
    if isinstance(channels, dict):
        result["channels_configured"] = list(channels.keys())

    return result


def check_dependencies() -> dict[str, Any]:
    """维度八：依赖与供应链安全。"""
    result: dict[str, Any] = {
        "pip_source": None,
        "lightclaw_version": None,
        "key_packages": [],
    }

    # pip source
    pip_conf, _ = _run("pip config get global.index-url 2>/dev/null")
    result["pip_source"] = pip_conf.strip() if pip_conf else "default (pypi.org)"

    # LightClaw version
    lc_ver, rc = _run("pip show lightclaw 2>/dev/null | grep Version")
    if rc == 0 and lc_ver:
        result["lightclaw_version"] = lc_ver.replace("Version:", "").strip()

    # Key dependencies
    key_deps = [
        "fastapi",
        "uvicorn",
        "langchain-core",
        "pydantic",
        "httpx",
        "aiohttp",
        "cryptography",
        "python-frontmatter",
    ]
    for dep in key_deps:
        ver_out, rc = _run(f"pip show {dep} 2>/dev/null | grep Version", timeout=5)
        if rc == 0 and ver_out:
            result["key_packages"].append(
                {
                    "name": dep,
                    "version": ver_out.replace("Version:", "").strip(),
                }
            )

    # pip audit (if available — skip gracefully if slow)
    audit_out, rc = _run("pip audit --format json 2>/dev/null", timeout=10)
    if rc == 0 and audit_out:
        try:
            audit_data = json.loads(audit_out)
            vulns = audit_data.get("vulnerabilities", [])
            result["known_vulnerabilities"] = len(vulns)
            result["vulnerability_details"] = [
                {
                    "package": v.get("name"),
                    "installed": v.get("version"),
                    "advisory": v.get("advisory", ""),
                }
                for v in vulns[:5]
            ]
        except Exception:
            pass
    else:
        result["pip_audit_available"] = False

    return result


def _format_duration(seconds: int) -> str:
    days = seconds // 86400
    hours = (seconds % 86400) // 3600
    minutes = (seconds % 3600) // 60
    parts = []
    if days > 0:
        parts.append(f"{days}d")
    if hours > 0:
        parts.append(f"{hours}h")
    if minutes > 0:
        parts.append(f"{minutes}m")
    return " ".join(parts) if parts else "< 1m"


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(description="LightClaw 安全自检")
    parser.add_argument(
        "--lightclaw-dir",
        default=os.path.expanduser("~/.lightclaw"),
        help="LightClaw base directory (default: ~/.lightclaw)",
    )
    parser.add_argument("--pretty", action="store_true", help="Pretty-print JSON output")
    args = parser.parse_args()

    lightclaw_dir = Path(args.lightclaw_dir).expanduser().resolve()

    report: dict[str, Any] = {
        "timestamp": datetime.now(UTC).isoformat(),
        "lightclaw_dir": str(lightclaw_dir),
        "lightclaw_dir_exists": lightclaw_dir.is_dir(),
        "system": {
            "os": platform.system(),
            "hostname": socket.gethostname(),
        },
        "checks": {},
    }

    print("🩺 LightClaw 安全自检开始...", file=sys.stderr)

    checks = [
        ("process", "进程生命体征", lambda: check_process()),
        ("logs", "日志观测", lambda: check_logs(lightclaw_dir)),
        ("auth_security", "认证与密钥安全", lambda: check_auth_security(lightclaw_dir)),
        ("network", "网络安全", lambda: check_network()),
        ("storage", "存储与数据安全", lambda: check_storage(lightclaw_dir)),
        ("host_environment", "宿主环境安全", lambda: check_host_environment()),
        (
            "lightclaw_config",
            "LightClaw 配置健康",
            lambda: check_lightclaw_config(lightclaw_dir),
        ),
        ("dependencies", "依赖与供应链安全", lambda: check_dependencies()),
    ]

    for key, label, func in checks:
        print(f"  检查中: {label}...", file=sys.stderr)
        try:
            report["checks"][key] = func()
        except Exception as exc:
            report["checks"][key] = {"error": str(exc)}

    print("✅ 自检数据收集完成！", file=sys.stderr)

    indent = 2 if args.pretty else None
    print(json.dumps(report, indent=indent, ensure_ascii=False, default=str))


if __name__ == "__main__":
    main()
