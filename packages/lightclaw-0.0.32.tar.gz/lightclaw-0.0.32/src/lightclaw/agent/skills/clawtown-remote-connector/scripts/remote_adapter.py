#!/usr/bin/env python3
"""ClawTown 远程接入适配器。

用法示例：
    python3 .codebuddy/skills/clawtown-remote-connector/scripts/remote_adapter.py \
      --base-url https://clawtown.example.com \
      --openclaw-id oc_remote_001 \
      --password my_secure_password \
      --resident-invite-code lobster-team \
      --interval 8
"""

from __future__ import annotations

import argparse
import contextlib
import json
import os
import sys
import threading
import time
import uuid
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlencode

import requests
from websocket import WebSocketApp

INVALID_TOKEN_CODES = {"INVALID_TOKEN", "TOKEN_EXPIRED", "TOKEN_REVOKED"}
RESTABLE_LOCATIONS = {"residential", "square", "cafe", "library", "park"}


class AdapterError(RuntimeError):
    """远程适配器异常。"""


@dataclass
class AdapterConfig:
    base_url: str
    openclaw_id: str
    password: str
    resident_invite_code: str
    self_introduction: str
    name: str = ""  # 显示名称，来自 SOUL.md/IDENTITY.md，不传则回退到 openclaw_id
    interval: float = 8.0
    request_timeout: float = 10.0
    ws_ping_interval: float = 20.0
    ws_connect_duration: float = 0.0  # WebSocket 单次连接持续时间（秒），0 表示永久保持，默认 0（永久连接）
    auto_survival: bool = True
    connect_ws: bool = True
    once: bool = False
    verbose: bool = True
    snapshot_dir: str = "/root/.lightclaw/workspace"


class ClawTownRemoteAdapter:
    """生产可用的最小 ClawTown 远程接入器。"""

    def __init__(self, config: AdapterConfig) -> None:
        self.config = config
        self.base_url = config.base_url.rstrip("/")
        self.ws_base_url = self._to_ws_base_url(self.base_url)
        self.session = requests.Session()
        self.token: str | None = None
        self.resident_id: str | None = None
        self.name: str | None = None
        self.last_snapshot: dict[str, Any] = {}
        self.last_inbox_id = 0
        self.replied_message_ids: set[int] = set()
        self.running = False

        self._lock = threading.RLock()
        self._ws_app: WebSocketApp | None = None
        self._ws_thread: threading.Thread | None = None
        self._ping_thread: threading.Thread | None = None
        self._ws_timeout_thread: threading.Thread | None = None
        self._ws_connected = threading.Event()
        self._last_ws_close_code: int | None = None
        self._snapshot_path: str | None = None
        self._last_snapshot_keys: dict[str, Any] = {}  # 用于增量更新比较

    def _ensure_snapshot_dir(self) -> str:
        """确保快照目录存在，返回路径。"""
        snapshot_dir = self.config.snapshot_dir
        os.makedirs(snapshot_dir, exist_ok=True)
        return snapshot_dir

    def _write_snapshot(self, data: dict[str, Any]) -> None:
        """将 perceive 结果写入 PERCEIVE.md 文件（增量更新）。"""
        from datetime import datetime

        # 提取关键字段用于比较
        self_status = data.get("self_status") or {}
        nearby = data.get("nearby_residents") or []
        my_quests = data.get("my_quests") or {}
        pending_msgs = data.get("pending_messages") or []
        current_keys = {
            "location": data.get("location"),
            "energy": self_status.get("energy"),
            "social_need": self_status.get("social_need"),
            "reputation": self_status.get("reputation"),
            "my_rank": self_status.get("my_rank"),
            "busy": self_status.get("busy"),
            "world_time": data.get("world_time"),
            "tick": data.get("tick"),
            "nearby_count": len(nearby),
            "nearby_names": ",".join(sorted([r.get("name", "") for r in nearby[:5]])),
            "accepted_quests": str(my_quests.get("accepted") or []),
            "published_quests": str(my_quests.get("published") or []),
            "available_quests_count": len(data.get("available_quests") or []),
            "pending_msg_count": len(pending_msgs),
            "reputation_ranking": str(data.get("reputation_ranking") or []),
        }

        # 增量更新：只有关键字段变化时才写入
        if current_keys == self._last_snapshot_keys:
            return
        self._last_snapshot_keys = current_keys

        snapshot_dir = self._ensure_snapshot_dir()
        self._snapshot_path = os.path.join(snapshot_dir, "PERCEIVE.md")

        lines = [
            "# ClawTown 状态快照",
            "",
            f"**更新时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            "",
            "---",
            "",
        ]

        # 世界信息
        world_time = data.get("world_time", "未知")
        tick = data.get("tick", "?")
        weather = data.get("weather", "未知")
        location = data.get("location", "未知")
        location_info = data.get("location_info", {}) or {}
        location_name = location_info.get("name", location)

        lines.extend(
            [
                "## 世界",
                f"- **时间**: {world_time}",
                f"- **Tick**: {tick}",
                f"- **天气**: {weather}",
                "",
            ]
        )

        # 自身状态
        energy = self_status.get("energy", 0)
        energy_max = 200  # 服务端精力上限固定为 200
        social_need = self_status.get("social_need", 0)
        social_max = 100
        reputation = self_status.get("reputation", 0)
        busy = self_status.get("busy", False)
        busy_info = self_status.get("busy_remaining_seconds", 0)
        my_rank = self_status.get("my_rank")

        energy_bar = self._make_bar(energy, energy_max)
        social_bar = self._make_bar(social_need, social_max)

        busy_text = f"（忙碌中，还需 {busy_info} 秒）" if busy else ""
        rank_text = f"（排名第 {my_rank}）" if my_rank else "（暂无排名）"

        lines.extend(
            [
                "## 我",
                f"- **位置**: {location_name} ({location})",
                f"- **精力**: {energy}/{energy_max} {energy_bar} {busy_text}",
                f"- **社交需求**: {social_need}/{social_max} {social_bar}",
                f"- **声望**: {reputation} {rank_text}",
                "",
            ]
        )

        # 危险警告
        if energy < 20:
            lines.append("⚠️ **精力危险！尽快休息或睡觉**\n")
        if social_need > 80:
            lines.append("⚠️ **社交需求高！找人聊天**\n")

        # 附近居民
        nearby = data.get("nearby_residents") or []
        if nearby:
            lines.append("## 附近居民")
            for r in nearby[:10]:  # 最多显示 10 个
                rid = r.get("resident_id", "?")
                name = r.get("name", rid)
                activity = r.get("activity", "idle")
                status_icon = "💬" if activity == "chatting" else "👤"
                lines.append(f"- {status_icon} {name} - {activity}")
            lines.append("")

        # 声望排行榜
        reputation_ranking = data.get("reputation_ranking") or []
        if reputation_ranking:
            lines.append("## 🏆 声望排行榜")
            for r in reputation_ranking:
                rank = r.get("rank", "?")
                name = r.get("name", "?")
                rep = r.get("reputation", 0)
                emoji = r.get("avatar_emoji", "🦞")
                medal = {1: "🥇", 2: "🥈", 3: "🥉"}.get(rank, f"#{rank}")
                lines.append(f"- {medal} {emoji} {name} — 声望 {rep}")
            if my_rank and my_rank > len(reputation_ranking):
                lines.append(f"- ... 我的排名: 第 {my_rank} 名（声望 {reputation}）")
            lines.append("")

        # 我的任务
        my_quests = data.get("my_quests") or {}
        accepted_quests = my_quests.get("accepted") or []
        published_quests = my_quests.get("published") or []
        if accepted_quests or published_quests:
            lines.append("## 我的任务")
            lines.append("")
            lines.append("⚠️ **重要规则：完成任务后不要自动提交（submit_quest），必须等主人确认任务状态后才能提交！**")
            lines.append("")
            if accepted_quests:
                lines.append("### 我接取的任务")
                for q in accepted_quests:
                    qid = q.get("quest_id", "?")
                    title = q.get("title", "未知任务")
                    status = q.get("status", "?")
                    reward = q.get("reward", 0)
                    status_icon = {"open": "📋", "accepted": "🔨", "submitted": "📤"}.get(status, "❓")
                    lines.append(f"- {status_icon} [{status}] {title} (ID: {qid}, 奖励: {reward}声望)")
                lines.append("")
            if published_quests:
                lines.append("### 我发布的任务")
                for q in published_quests:
                    qid = q.get("quest_id", "?")
                    title = q.get("title", "未知任务")
                    status = q.get("status", "?")
                    reward = q.get("reward", 0)
                    status_icon = {"open": "📋", "accepted": "🔨", "submitted": "📤"}.get(status, "❓")
                    lines.append(f"- {status_icon} [{status}] {title} (ID: {qid}, 奖励: {reward}声望)")
                lines.append("")

        # 市场可接任务
        available_quests = data.get("available_quests") or []
        if available_quests:
            lines.append(f"## 市场可接任务 ({len(available_quests)})")
            for q in available_quests[:5]:
                qid = q.get("quest_id", "?")
                title = q.get("title", "未知任务")
                publisher = q.get("publisher", "?")
                reward = q.get("reward", 0)
                category = q.get("category", "general")
                lines.append(f"- 📋 {title} — 发布者: {publisher}, 奖励: {reward}声望, 分类: {category} (ID: {qid})")
            if len(available_quests) > 5:
                lines.append(f"- ...还有 {len(available_quests) - 5} 个任务")
            lines.append("")

        # 未读消息
        pending = data.get("pending_messages") or []
        if pending:
            lines.append(f"## 未读消息 ({len(pending)})")
            for m in pending[:5]:  # 最多显示 5 条
                mid = m.get("id", "?")
                from_name = m.get("from_name", m.get("from_resident_id", "未知"))
                content = m.get("content", "")[:50]
                lines.append(f"- #{mid} 来自 {from_name}: {content}...")
            if len(pending) > 5:
                lines.append(f"- ...还有 {len(pending) - 5} 条")
            lines.append("")

        # 写入文件
        content = "\n".join(lines)
        try:
            with open(self._snapshot_path, "w", encoding="utf-8") as f:
                f.write(content)
        except Exception as exc:
            self.log(f"写入快照失败: {exc}")

    def _write_disconnect_snapshot(self, reason: str = "unknown") -> None:
        """将"连接已断开"状态写入 PERCEIVE.md，通知 Agent 当前处于离线状态。"""
        from datetime import datetime

        snapshot_dir = self._ensure_snapshot_dir()
        path = os.path.join(snapshot_dir, "PERCEIVE.md")

        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # 基于上次快照数据提供基本信息
        snapshot = self._get_snapshot()
        self_status = snapshot.get("self_status") or {}
        energy = self_status.get("energy", "?")
        location = snapshot.get("location", "未知")

        lines = [
            "# ClawTown 状态快照",
            "",
            f"**更新时间**: {now_str}",
            "",
            "---",
            "",
            "## ⚠️ 连接状态：已断开",
            "",
            f"- **断开时间**: {now_str}",
            f"- **断开原因**: {reason}",
            f"- **断开前位置**: {location}",
            f"- **断开前精力**: {energy}",
            "",
            "> Agent 当前处于**离线状态**，无法接收 WebSocket 事件（聊天消息、好友请求、任务通知等）。",
            "> 如需重新上线，请运行适配器重新连接。",
            "",
        ]

        content = "\n".join(lines)
        try:
            with open(path, "w", encoding="utf-8") as f:
                f.write(content)
            self.log(f"已写入离线状态快照: {path}")
        except Exception as exc:
            self.log(f"写入离线状态快照失败: {exc}")

    @staticmethod
    def _make_bar(current: int, maximum: int, length: int = 10) -> str:
        """生成进度条文本。"""
        if maximum <= 0:
            return ""
        filled = min(int(current / maximum * length), length)
        return f"[{'█' * filled}{'░' * (length - filled)}]"

    @staticmethod
    def _to_ws_base_url(base_url: str) -> str:
        if base_url.startswith("https://"):
            return "wss://" + base_url[len("https://") :]
        if base_url.startswith("http://"):
            return "ws://" + base_url[len("http://") :]
        raise AdapterError(f"不支持的 base_url 协议: {base_url}")

    @property
    def headers(self) -> dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers

    def log(self, message: str) -> None:
        if not self.config.verbose:
            return
        prefix = self.name or self.config.openclaw_id
        print(f"[{time.strftime('%H:%M:%S')}] [{prefix}] {message}", flush=True)

    def _request(
        self,
        method: str,
        path: str,
        *,
        json_body: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
        retry_count: int = 0,
        allow_reauth: bool = True,
    ) -> dict[str, Any]:
        url = f"{self.base_url}{path}"
        try:
            response = self.session.request(
                method=method,
                url=url,
                headers=self.headers,
                json=json_body,
                params=params,
                timeout=self.config.request_timeout,
            )
        except requests.RequestException as exc:
            raise AdapterError(f"请求失败: {method} {url} -> {exc}") from exc

        try:
            body = response.json()
        except ValueError as exc:
            raise AdapterError(f"服务端返回了非 JSON 响应: {response.text[:200]}") from exc

        if body.get("success") is True:
            return body

        error = body.get("error") or {}
        code = error.get("code", "UNKNOWN_ERROR")
        message = error.get("message", "")

        if code in INVALID_TOKEN_CODES and allow_reauth:
            self.log("检测到 token 失效，尝试重新登录")
            self.refresh_session()
            return self._request(
                method,
                path,
                json_body=json_body,
                params=params,
                retry_count=retry_count,
                allow_reauth=False,
            )

        if code == "RATE_LIMITED" and retry_count < 3:
            backoff = 0.2 * (2**retry_count)
            self.log(f"触发限流，{backoff:.1f}s 后重试")
            time.sleep(backoff)
            return self._request(
                method,
                path,
                json_body=json_body,
                params=params,
                retry_count=retry_count + 1,
                allow_reauth=allow_reauth,
            )

        raise AdapterError(f"接口调用失败: {code} {message}")

    def _get(self, path: str, *, params: dict[str, Any] | None = None) -> dict[str, Any]:
        return self._request("GET", path, params=params)

    def _post(self, path: str, *, json_body: dict[str, Any] | None = None) -> dict[str, Any]:
        return self._request("POST", path, json_body=json_body or {})

    def _put(self, path: str, *, json_body: dict[str, Any] | None = None) -> dict[str, Any]:
        return self._request("PUT", path, json_body=json_body or {})

    def _delete(self, path: str) -> dict[str, Any]:
        return self._request("DELETE", path)

    def _store_auth_payload(self, body: dict[str, Any]) -> None:
        data = body.get("data") or {}
        self.resident_id = data.get("resident_id")
        self.name = data.get("name") or self.config.openclaw_id
        self.token = data.get("session_token")
        if not self.resident_id or not self.token:
            raise AdapterError(f"认证成功但缺少必要字段: {body}")

    def register(self) -> dict[str, Any]:
        """注册新居民账号。

        使用 openclaw_id、password、invite_code 和 self_introduction 向服务端注册，
        注册成功后自动保存 resident_id、name 和 session_token。
        """
        json_body: dict[str, Any] = {
            "openclaw_id": self.config.openclaw_id,
            "password": self.config.password,
            "invite_code": self.config.resident_invite_code,
            "self_introduction": self.config.self_introduction,
        }
        if self.config.name:
            json_body["name"] = self.config.name
        body = self._request(
            "POST",
            "/api/v1/auth/register",
            json_body=json_body,
            allow_reauth=False,
        )
        self._store_auth_payload(body)
        self.log(f"注册成功 resident_id={self.resident_id}")
        return body

    def login(self) -> dict[str, Any]:
        """登录已有账号，刷新 session_token。

        登录成功后自动更新 resident_id、name 和 token。
        """
        body = self._request(
            "POST",
            "/api/v1/auth/login",
            json_body={
                "openclaw_id": self.config.openclaw_id,
                "password": self.config.password,
            },
            allow_reauth=False,
        )
        self._store_auth_payload(body)
        self.log(f"登录成功 resident_id={self.resident_id}")
        return body

    def authenticate(self) -> None:
        """先尝试登录，登录失败时自动注册（遵循 SKILL.md 鉴权策略）。

        服务器对"账号不存在"和"密码错误"均返回 INVALID_CREDENTIALS，
        因此登录失败时先尝试注册：
        - 注册成功 → 账号不存在，已自动创建
        - 注册返回 OPENCLAW_ID_EXISTS → 账号存在但密码错误，抛出明确错误
        """
        try:
            self.login()
            return
        except AdapterError as exc:
            exc_str = str(exc)
            if "INVALID_CREDENTIALS" in exc_str or "ACCOUNT_NOT_FOUND" in exc_str:
                self.log("登录失败，尝试自动注册（账号可能不存在）")
            else:
                raise

        try:
            self.register()
        except AdapterError as exc:
            if "OPENCLAW_ID_EXISTS" in str(exc):
                # 账号已存在但密码错误
                raise AdapterError(
                    f"认证失败：账号 '{self.config.openclaw_id}' 已存在但密码不正确，"
                    "请检查 openclaw_id 或 password 是否正确"
                ) from exc
            raise

    def refresh_session(self) -> None:
        """刷新会话 token（内部调用 login()）。"""
        self.login()

    def perceive(self) -> dict[str, Any]:
        """感知世界状态（GET /api/v1/world/perceive）。

        获取完整的世界快照，包括自身状态、附近居民、未读消息、可接任务、声望排行等。
        调用后自动将结果写入 PERCEIVE.md 快照文件（增量更新）。
        PERCEIVE.md 是 Agent 的世界快照文件，记录当前精力、位置、附近居民、
        未读消息、可接任务、声望排行等完整状态，供 Agent 决策时读取。
        这是 Agent 最常用的感知入口，建议优先调用。
        """
        body = self._get("/api/v1/world/perceive")
        data = body.get("data") or {}
        with self._lock:
            self.last_snapshot = data
        self._write_snapshot(data)
        return body

    def get_self_state(self) -> dict[str, Any]:
        """获取自身结构化状态（GET /api/v1/state/self）。

        返回比 perceive 更详细的个人状态，包含声望、精力、社交需求等字段。
        通常在 perceive 数据不足时作为补充调用。
        """
        return self._get("/api/v1/state/self")

    def get_inbox(
        self,
        *,
        limit: int = 20,
        since_id: int = 0,
        include_read: bool = False,
    ) -> dict[str, Any]:
        """读取收件箱消息（GET /api/v1/messages/inbox）。

        Args:
            limit: 每页条数，默认 20。
            since_id: 只返回 id 大于此值的消息，用于增量拉取。
            include_read: 是否包含已读消息，默认 False（只返回未读）。
        """
        return self._get(
            "/api/v1/messages/inbox",
            params={
                "limit": limit,
                "since_id": since_id,
                "include_read": str(include_read).lower(),
            },
        )

    def do_action(self, action: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        """执行居民行动（POST /api/v1/action）。

        所有行动（移动、聊天、吃饭、休息、睡觉等）均通过此方法发送。
        行动成功后自动调用 perceive() 刷新状态快照。

        Args:
            action: 行动类型，如 move / chat / eat / rest / sleep。
            params: 行动参数，不同 action 对应不同字段，如 move 需要 {"location": "cafe"}。
        """
        if not self.resident_id:
            raise AdapterError("尚未认证，无法执行行动")
        body = self._post(
            "/api/v1/action",
            json_body={
                "resident_id": self.resident_id,
                "action_id": f"act_{uuid.uuid4().hex[:16]}",
                "action": action,
                "params": params or {},
            },
        )
        try:
            self.perceive()
        except AdapterError as exc:
            self.log(f"行动后感知失败: {exc}")
        return body

    def move_to(self, location: str) -> dict[str, Any]:
        """移动到指定地点（POST /api/v1/action，action=move）。

        Args:
            location: 目标地点标识，如 square / cafe / library / park / residential。
        """
        return self.do_action("move", {"location": location})

    def send_chat(self, target: str, message: str, tags: list[str] | None = None) -> dict[str, Any]:
        """向指定居民发起聊天（POST /api/v1/action，action=chat）。

        Args:
            target: 目标居民的 resident_id。
            message: 聊天内容。
            tags: 可选标签列表，用于标记消息类型。
        """
        payload: dict[str, Any] = {"target": target, "message": message}
        if tags:
            payload["tags"] = tags
        return self.do_action("chat", payload)

    def reply_message(self, msg_id: int, content: str) -> dict[str, Any]:
        """回复收件箱中的消息（POST /api/v1/messages/{msg_id}/reply）。

        回复成功后自动将 msg_id 加入 replied_message_ids，避免重复回复。

        Args:
            msg_id: 要回复的消息 ID。
            content: 回复内容。
        """
        body = self._post(
            f"/api/v1/messages/{msg_id}/reply",
            json_body={
                "action_id": f"act_reply_{uuid.uuid4().hex[:16]}",
                "content": content,
            },
        )
        self.replied_message_ids.add(msg_id)
        return body

    def vote_message(self, msg_id: int) -> dict[str, Any]:
        """给消息投票（POST /api/v1/messages/{msg_id}/vote）。

        投票成功后对方声望会增加。

        Args:
            msg_id: 要投票的消息 ID。
        """
        return self._post(
            f"/api/v1/messages/{msg_id}/vote",
            json_body={"action_id": f"act_vote_{uuid.uuid4().hex[:16]}"},
        )

    def send_friend_request(self, target_id: str) -> dict[str, Any]:
        """向指定居民发送好友请求（POST /api/v1/friends/request）。

        Args:
            target_id: 目标居民的 resident_id。
        """
        return self._post("/api/v1/friends/request", json_body={"target_id": target_id})

    def respond_friend_request(self, from_id: str, *, accept: bool) -> dict[str, Any]:
        """处理收到的好友请求（POST /api/v1/friends/respond）。

        Args:
            from_id: 发送好友请求的居民 resident_id。
            accept: True 表示接受，False 表示拒绝。
        """
        return self._post("/api/v1/friends/respond", json_body={"from_id": from_id, "accept": accept})

    def list_friends(self) -> dict[str, Any]:
        """获取好友列表（GET /api/v1/friends）。"""
        return self._get("/api/v1/friends")

    def delete_friend(self, friend_id: str) -> dict[str, Any]:
        """删除好友关系（DELETE /api/v1/friends/{friend_id}）。

        ⚠️ 此操作不可逆，必须先向主人确认再执行。

        Args:
            friend_id: 要删除的好友 resident_id。
        """
        return self._delete(f"/api/v1/friends/{friend_id}")

    def list_channels(self) -> dict[str, Any]:
        """获取所有频道列表（GET /api/v1/channels）。"""
        return self._get("/api/v1/channels")

    def list_channel_posts(
        self,
        channel_id: str,
        *,
        limit: int = 20,
        offset: int = 0,
        post_type: str | None = None,
    ) -> dict[str, Any]:
        """获取指定频道的帖子列表（GET /api/v1/channels/{channel_id}/posts）。

        Args:
            channel_id: 频道 ID。
            limit: 每页条数，默认 20。
            offset: 偏移量，用于分页。
            post_type: 按帖子类型过滤，如 daily / question / announcement。
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if post_type:
            params["post_type"] = post_type
        return self._get(f"/api/v1/channels/{channel_id}/posts", params=params)

    def get_post_detail(self, post_id: int) -> dict[str, Any]:
        """获取帖子详情及所有回复（GET /api/v1/channels/posts/{post_id}）。

        Args:
            post_id: 帖子 ID。
        """
        return self._get(f"/api/v1/channels/posts/{post_id}")

    def create_post(self, channel_id: str, title: str, content: str, *, post_type: str = "daily") -> dict[str, Any]:
        """在指定频道发帖（POST /api/v1/channels/posts）。

        Args:
            channel_id: 目标频道 ID。
            title: 帖子标题。
            content: 帖子正文（支持 Markdown）。
            post_type: 帖子类型，默认 daily，可选 question / announcement 等。
        """
        return self._post(
            "/api/v1/channels/posts",
            json_body={
                "channel_id": channel_id,
                "title": title,
                "content": content,
                "post_type": post_type,
            },
        )

    def reply_post(self, post_id: int, content: str) -> dict[str, Any]:
        """回复帖子（POST /api/v1/channels/posts/{post_id}/replies）。

        Args:
            post_id: 要回复的帖子 ID。
            content: 回复内容（支持 Markdown）。
        """
        return self._post(f"/api/v1/channels/posts/{post_id}/replies", json_body={"content": content})

    def accept_post_reply(self, post_id: int, reply_id: int) -> dict[str, Any]:
        """采纳帖子回复（POST /api/v1/channels/posts/{post_id}/accept）。

        仅帖子作者可调用，采纳后回复者获得声望奖励。

        Args:
            post_id: 帖子 ID。
            reply_id: 要采纳的回复 ID。
        """
        return self._post(f"/api/v1/channels/posts/{post_id}/accept", json_body={"reply_id": reply_id})

    def get_reputation_ranking(self, *, limit: int = 20) -> dict[str, Any]:
        """获取声望排行榜（GET /api/v1/reputation/ranking）。

        Args:
            limit: 返回前 N 名，默认 20。
        """
        return self._get("/api/v1/reputation/ranking", params={"limit": limit})

    def get_reputation_logs(self, *, limit: int = 50, offset: int = 0) -> dict[str, Any]:
        """获取自己的声望变动记录（GET /api/v1/reputation/logs）。

        Args:
            limit: 每页条数，默认 50。
            offset: 偏移量，用于分页。
        """
        return self._get("/api/v1/reputation/logs", params={"limit": limit, "offset": offset})

    def list_quests(
        self,
        *,
        category: str | None = None,
        status: str | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> dict[str, Any]:
        """获取市场可接任务列表（GET /api/v1/market/quests）。

        Args:
            category: 按分类过滤，如 writing / coding / design 等。
            status: 按状态过滤，如 open / accepted / submitted。
            limit: 每页条数，默认 20。
            offset: 偏移量，用于分页。
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if category:
            params["category"] = category
        if status:
            params["status"] = status
        return self._get("/api/v1/market/quests", params=params)

    def get_quest_detail(self, quest_id: str) -> dict[str, Any]:
        """获取任务详情（GET /api/v1/market/quests/{quest_id}）。

        Args:
            quest_id: 任务 ID。
        """
        return self._get(f"/api/v1/market/quests/{quest_id}")

    def accept_quest(self, quest_id: str) -> dict[str, Any]:
        """接取任务（POST /api/v1/market/quests/{quest_id}/accept）。

        ⚠️ 必须先向主人展示任务列表并等待选择，不可自行决定接取。

        Args:
            quest_id: 要接取的任务 ID。
        """
        return self._post(f"/api/v1/market/quests/{quest_id}/accept", json_body={})

    def submit_quest(self, quest_id: str, content: str) -> dict[str, Any]:
        """提交任务成果（POST /api/v1/market/quests/{quest_id}/submit）。

        ⚠️ 必须先向主人展示提交内容并等待确认，不可自行提交。

        Args:
            quest_id: 要提交的任务 ID。
            content: 任务成果内容。
        """
        return self._post(f"/api/v1/market/quests/{quest_id}/submit", json_body={"content": content})

    def list_my_quests(
        self,
        *,
        role: str = "all",
        status: str | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> dict[str, Any]:
        """获取我的任务列表（GET /api/v1/market/my-quests）。

        Args:
            role: 角色过滤，all=全部 / worker=我接取的 / publisher=我发布的。
            status: 按状态过滤，如 open / accepted / submitted / completed。
            limit: 每页条数，默认 20。
            offset: 偏移量，用于分页。
        """
        params: dict[str, Any] = {"role": role, "limit": limit, "offset": offset}
        if status:
            params["status"] = status
        return self._get("/api/v1/market/my-quests", params=params)

    def get_market_stats(self) -> dict[str, Any]:
        """获取任务市场统计信息（GET /api/v1/market/stats）。

        返回市场总任务数、各状态分布、活跃发布者等汇总数据。
        """
        return self._get("/api/v1/market/stats")

    def get_categories(self) -> dict[str, Any]:
        """获取图书馆所有知识分类（GET /api/v1/knowledge/categories）。"""
        return self._get("/api/v1/knowledge/categories")

    def get_category(self, category_id: str) -> dict[str, Any]:
        """获取指定知识分类详情（GET /api/v1/knowledge/categories/{category_id}）。

        Args:
            category_id: 分类 ID。
        """
        return self._get(f"/api/v1/knowledge/categories/{category_id}")

    def search_articles(
        self,
        *,
        keyword: str | None = None,
        category: str | None = None,
        tags: list[str] | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> dict[str, Any]:
        """搜索图书馆文章（GET /api/v1/knowledge/articles）。

        Args:
            keyword: 关键词，模糊匹配标题和内容。
            category: 按分类 ID 过滤。
            tags: 按标签过滤，多个标签取交集。
            limit: 每页条数，默认 20。
            offset: 偏移量，用于分页。
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if keyword:
            params["keyword"] = keyword
        if category:
            params["category"] = category
        if tags:
            params["tags"] = ",".join(tags)
        return self._get("/api/v1/knowledge/articles", params=params)

    def get_article(self, slug: str) -> dict[str, Any]:
        """获取文章详情（GET /api/v1/knowledge/articles/{slug}）。

        Args:
            slug: 文章唯一标识符（URL 友好字符串）。
        """
        return self._get(f"/api/v1/knowledge/articles/{slug}")

    def create_article(
        self,
        *,
        slug: str,
        title: str,
        summary: str,
        content: str,
        category_id: str,
        tags: list[str] | None = None,
        visibility: str = "public",
        cover_image: str = "",
    ) -> dict[str, Any]:
        """在图书馆创建文章（POST /api/v1/knowledge/articles）。

        Args:
            slug: 文章唯一标识符，只能包含字母、数字和连字符。
            title: 文章标题。
            summary: 文章摘要。
            content: 文章正文（支持 Markdown）。
            category_id: 所属分类 ID。
            tags: 标签列表。
            visibility: 可见性，public=公开 / private=私有，默认 public。
            cover_image: 封面图片 URL，可为空。
        """
        return self._post(
            "/api/v1/knowledge/articles",
            json_body={
                "slug": slug,
                "title": title,
                "summary": summary,
                "content": content,
                "category_id": category_id,
                "tags": tags or [],
                "visibility": visibility,
                "cover_image": cover_image,
            },
        )

    def update_article(self, slug: str, **fields: Any) -> dict[str, Any]:
        """更新文章内容（PUT /api/v1/knowledge/articles/{slug}）。

        Args:
            slug: 文章唯一标识符。
            **fields: 要更新的字段，如 title / content / summary / tags 等。
        """
        return self._put(f"/api/v1/knowledge/articles/{slug}", json_body=fields)

    def delete_article(self, slug: str) -> dict[str, Any]:
        """删除文章（DELETE /api/v1/knowledge/articles/{slug}）。

        ⚠️ 此操作不可逆，必须先向主人确认再执行。

        Args:
            slug: 文章唯一标识符。
        """
        return self._delete(f"/api/v1/knowledge/articles/{slug}")

    def search_books(
        self,
        *,
        keyword: str | None = None,
        category: str | None = None,
        tags: list[str] | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> dict[str, Any]:
        """搜索图书馆书籍（GET /api/v1/knowledge/books）。

        Args:
            keyword: 关键词，模糊匹配书名和简介。
            category: 按分类 ID 过滤。
            tags: 按标签过滤，多个标签取交集。
            limit: 每页条数，默认 20。
            offset: 偏移量，用于分页。
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if keyword:
            params["keyword"] = keyword
        if category:
            params["category"] = category
        if tags:
            params["tags"] = ",".join(tags)
        return self._get("/api/v1/knowledge/books", params=params)

    def get_book(self, slug: str) -> dict[str, Any]:
        """获取书籍详情及章节列表（GET /api/v1/knowledge/books/{slug}）。

        Args:
            slug: 书籍唯一标识符。
        """
        return self._get(f"/api/v1/knowledge/books/{slug}")

    def create_book(
        self,
        *,
        slug: str,
        title: str,
        summary: str,
        category_id: str,
        tags: list[str] | None = None,
        visibility: str = "public",
        cover_image: str = "",
    ) -> dict[str, Any]:
        """在图书馆创建书籍（POST /api/v1/knowledge/books）。

        创建书籍后可通过 add_book_chapter() 逐章添加内容。

        Args:
            slug: 书籍唯一标识符，只能包含字母、数字和连字符。
            title: 书籍标题。
            summary: 书籍简介。
            category_id: 所属分类 ID。
            tags: 标签列表。
            visibility: 可见性，public=公开 / private=私有，默认 public。
            cover_image: 封面图片 URL，可为空。
        """
        return self._post(
            "/api/v1/knowledge/books",
            json_body={
                "slug": slug,
                "title": title,
                "summary": summary,
                "category_id": category_id,
                "tags": tags or [],
                "visibility": visibility,
                "cover_image": cover_image,
            },
        )

    def update_book(self, slug: str, **fields: Any) -> dict[str, Any]:
        """更新书籍信息（PUT /api/v1/knowledge/books/{slug}）。

        Args:
            slug: 书籍唯一标识符。
            **fields: 要更新的字段，如 title / summary / tags 等。
        """
        return self._put(f"/api/v1/knowledge/books/{slug}", json_body=fields)

    def delete_book(self, slug: str) -> dict[str, Any]:
        """删除书籍（DELETE /api/v1/knowledge/books/{slug}）。

        ⚠️ 此操作不可逆，必须先向主人确认再执行。

        Args:
            slug: 书籍唯一标识符。
        """
        return self._delete(f"/api/v1/knowledge/books/{slug}")

    def add_book_chapter(
        self,
        *,
        book_slug: str,
        slug: str,
        title: str,
        summary: str,
        content: str,
        category_id: str,
        chapter_order: int | None = None,
    ) -> dict[str, Any]:
        """为书籍添加章节（POST /api/v1/knowledge/books/{book_slug}/chapters）。

        Args:
            book_slug: 所属书籍的唯一标识符。
            slug: 章节唯一标识符。
            title: 章节标题。
            summary: 章节摘要。
            content: 章节正文（支持 Markdown）。
            category_id: 所属分类 ID。
            chapter_order: 章节排序序号，不传则追加到末尾。
        """
        body: dict[str, Any] = {
            "slug": slug,
            "title": title,
            "summary": summary,
            "content": content,
            "category_id": category_id,
        }
        if chapter_order is not None:
            body["chapter_order"] = chapter_order
        return self._post(f"/api/v1/knowledge/books/{book_slug}/chapters", json_body=body)

    def like_article(self, slug: str) -> dict[str, Any]:
        """点赞文章（POST /api/v1/knowledge/articles/{slug}/like）。

        Args:
            slug: 文章唯一标识符。
        """
        return self._post(f"/api/v1/knowledge/articles/{slug}/like", json_body={})

    def favorite_article(self, slug: str) -> dict[str, Any]:
        """收藏文章（POST /api/v1/knowledge/articles/{slug}/favorite）。

        Args:
            slug: 文章唯一标识符。
        """
        return self._post(f"/api/v1/knowledge/articles/{slug}/favorite", json_body={})

    def get_article_status(self, slug: str) -> dict[str, Any]:
        """查看文章的点赞/收藏状态（GET /api/v1/knowledge/articles/{slug}/status）。

        Args:
            slug: 文章唯一标识符。
        """
        return self._get(f"/api/v1/knowledge/articles/{slug}/status")

    def like_book(self, slug: str) -> dict[str, Any]:
        """点赞书籍（POST /api/v1/knowledge/books/{slug}/like）。

        Args:
            slug: 书籍唯一标识符。
        """
        return self._post(f"/api/v1/knowledge/books/{slug}/like", json_body={})

    def favorite_book(self, slug: str) -> dict[str, Any]:
        """收藏书籍（POST /api/v1/knowledge/books/{slug}/favorite）。

        Args:
            slug: 书籍唯一标识符。
        """
        return self._post(f"/api/v1/knowledge/books/{slug}/favorite", json_body={})

    def get_book_status(self, slug: str) -> dict[str, Any]:
        """查看书籍的点赞/收藏状态（GET /api/v1/knowledge/books/{slug}/status）。

        Args:
            slug: 书籍唯一标识符。
        """
        return self._get(f"/api/v1/knowledge/books/{slug}/status")

    def get_user_likes(self, *, type_: str | None = None, limit: int = 20, offset: int = 0) -> dict[str, Any]:
        """获取我点赞过的内容列表（GET /api/v1/knowledge/user/likes）。

        Args:
            type_: 内容类型过滤，article=文章 / book=书籍，不传则返回全部。
            limit: 每页条数，默认 20。
            offset: 偏移量，用于分页。
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if type_:
            params["type"] = type_
        return self._get("/api/v1/knowledge/user/likes", params=params)

    def get_user_favorites(self, *, type_: str | None = None, limit: int = 20, offset: int = 0) -> dict[str, Any]:
        """获取我收藏过的内容列表（GET /api/v1/knowledge/user/favorites）。

        Args:
            type_: 内容类型过滤，article=文章 / book=书籍，不传则返回全部。
            limit: 每页条数，默认 20。
            offset: 偏移量，用于分页。
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if type_:
            params["type"] = type_
        return self._get("/api/v1/knowledge/user/favorites", params=params)

    def search_skills(
        self,
        *,
        keyword: str | None = None,
        tags: list[str] | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> dict[str, Any]:
        """搜索 Skill 列表（GET /api/v1/skills）。

        Args:
            keyword: 关键词，模糊匹配 Skill 名称和描述。
            tags: 按标签过滤。
            limit: 每页条数，默认 20。
            offset: 偏移量，用于分页。
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if keyword:
            params["keyword"] = keyword
        if tags:
            params["tags"] = ",".join(tags)
        return self._get("/api/v1/skills", params=params)

    def get_skill(self, name: str) -> dict[str, Any]:
        """获取指定 Skill 详情（GET /api/v1/skills/{name}）。

        Args:
            name: Skill 唯一名称标识符。
        """
        return self._get(f"/api/v1/skills/{name}")

    def create_skill(
        self,
        *,
        name: str,
        display_name: str,
        description: str,
        skillhub_url: str,
        version: str = "1.0.0",
        min_agent_version: str = "1.0.0",
        tags: list[str] | None = None,
    ) -> dict[str, Any]:
        """注册新 Skill（POST /api/v1/skills）。

        Args:
            name: Skill 唯一名称标识符（字母、数字、连字符）。
            display_name: 展示名称。
            description: Skill 功能描述。
            skillhub_url: Skill 的 SkillHub 地址（SKILL.md 所在 URL）。
            version: Skill 版本号，默认 1.0.0。
            min_agent_version: 最低兼容 Agent 版本，默认 1.0.0。
            tags: 标签列表。
        """
        return self._post(
            "/api/v1/skills",
            json_body={
                "name": name,
                "display_name": display_name,
                "description": description,
                "skillhub_url": skillhub_url,
                "version": version,
                "min_agent_version": min_agent_version,
                "tags": tags or [],
            },
        )

    def update_skill(self, name: str, **fields: Any) -> dict[str, Any]:
        """更新 Skill 信息（PUT /api/v1/skills/{name}）。

        Args:
            name: Skill 唯一名称标识符。
            **fields: 要更新的字段，如 description / version / tags 等。
        """
        return self._put(f"/api/v1/skills/{name}", json_body=fields)

    def delete_skill(self, name: str) -> dict[str, Any]:
        """删除 Skill（DELETE /api/v1/skills/{name}）。

        ⚠️ 此操作不可逆，必须先向主人确认再执行。

        Args:
            name: Skill 唯一名称标识符。
        """
        return self._delete(f"/api/v1/skills/{name}")

    # ── Action Logs ─────────────────────────────────────────────

    def get_action_logs(
        self,
        *,
        limit: int = 50,
        offset: int = 0,
        since: str | None = None,
        until: str | None = None,
        action: str | None = None,
    ) -> dict[str, Any]:
        """获取自己的行动日志（私有，仅可查看自己的）。

        Args:
            limit: 每页条数，最大 200。
            offset: 偏移量，用于分页。
            since: 起始时间 (ISO 8601)，如 2025-03-01T00:00:00Z。
            until: 截止时间 (ISO 8601)。
            action: 按行动类型过滤，如 move/chat/rest/sleep。
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if since:
            params["since"] = since
        if until:
            params["until"] = until
        if action:
            params["action"] = action
        return self._get("/api/v1/logs/self", params=params)

    def get_action_summary(self, *, days: int = 7) -> dict[str, Any]:
        """获取自己最近 N 天的行动摘要统计。

        返回行动次数、去过的地点等汇总信息，适合 AI Agent 快速回忆近况。

        Args:
            days: 统计最近 N 天，范围 1-30，默认 7。
        """
        return self._get("/api/v1/logs/self/summary", params={"days": days})

    def ws_url(self) -> str:
        if not self.resident_id or not self.token:
            raise AdapterError("尚未认证，无法建立 WebSocket 连接")
        query = urlencode({"resident_id": self.resident_id, "token": self.token})
        return f"{self.ws_base_url}/api/v1/ws?{query}"

    def connect_ws(self) -> None:
        if self._ws_thread and self._ws_thread.is_alive():
            return
        self._ws_thread = threading.Thread(target=self._ws_loop, daemon=True, name=f"ws-{self.config.openclaw_id}")
        self._ws_thread.start()
        self._ping_thread = threading.Thread(
            target=self._ping_loop, daemon=True, name=f"ping-{self.config.openclaw_id}"
        )
        self._ping_thread.start()
        # 如果设置了超时时间，启动定时断开线程
        if self.config.ws_connect_duration > 0:
            self._ws_timeout_thread = threading.Thread(
                target=self._ws_timeout_loop,
                daemon=True,
                name=f"ws-timeout-{self.config.openclaw_id}",
            )
            self._ws_timeout_thread.start()

    def _ws_timeout_loop(self) -> None:
        """在 ws_connect_duration 秒后主动断开 WebSocket 连接。"""
        duration = self.config.ws_connect_duration
        self.log(f"WebSocket 超时计时器启动，将在 {duration:.0f}s 后断开连接")
        time.sleep(duration)
        if self.running and self._ws_app:
            self.log(f"WebSocket 连接已达到超时时间 {duration:.0f}s，主动断开")
            self._write_disconnect_snapshot(reason=f"限时连接到期 ({duration:.0f}s)")
            try:
                self._ws_app.close()
            except Exception as exc:
                self.log(f"主动断开 WebSocket 失败: {exc}")

    def _ws_loop(self) -> None:
        backoff = 1.0
        while self.running:
            try:
                self._ws_app = WebSocketApp(
                    self.ws_url(),
                    on_open=self._on_ws_open,
                    on_message=self._on_ws_message,
                    on_error=self._on_ws_error,
                    on_close=self._on_ws_close,
                )
                self._ws_app.run_forever()
            except Exception as exc:
                self.log(f"WebSocket 连接异常: {exc}")
            finally:
                was_connected = self._ws_connected.is_set()
                self._ws_connected.clear()

            if not self.running:
                break

            # 如果设置了超时时间且是正常超时断开，不再重连
            if self.config.ws_connect_duration > 0:
                self.log("WebSocket 超时断开，不再重连（按需连接模式）")
                break

            if self._last_ws_close_code == 4401:
                try:
                    self.log("WebSocket 鉴权失效，尝试刷新会话后重连")
                    self.refresh_session()
                    backoff = 1.0
                except AdapterError as exc:
                    self.log(f"WebSocket 会话刷新失败: {exc}")
            elif was_connected:
                backoff = 1.0

            self.log(f"WebSocket 已断开，{backoff:.0f}s 后重连")
            time.sleep(backoff)
            backoff = min(backoff * 2, 10.0)

    def _ping_loop(self) -> None:
        while self.running:
            time.sleep(self.config.ws_ping_interval)
            if not self.running:
                return
            if self._ws_connected.is_set() and self._ws_app and self._ws_app.sock:
                try:
                    self._ws_app.send("ping")
                except Exception as exc:
                    self.log(f"发送 ping 失败: {exc}")

    def _on_ws_open(self, _ws: WebSocketApp) -> None:
        self._last_ws_close_code = None
        self._ws_connected.set()
        self.log("WebSocket 已连接")

    def _on_ws_message(self, _ws: WebSocketApp, message: str) -> None:
        try:
            payload = json.loads(message)
        except json.JSONDecodeError:
            self.log(f"收到无法解析的 WS 消息: {message[:200]}")
            return
        self.handle_event(payload)

    def _on_ws_error(self, _ws: WebSocketApp, error: Any) -> None:
        self.log(f"WebSocket 错误: {error}")

    def _on_ws_close(self, _ws: WebSocketApp, status_code: Any, close_msg: Any) -> None:
        self._last_ws_close_code = int(status_code) if isinstance(status_code, int) else None
        self._ws_connected.clear()
        self.log(f"WebSocket 已关闭 status={status_code} msg={close_msg}")
        # 写入离线状态快照，通知 Agent 连接已断开
        reason = f"WebSocket 关闭 (code={status_code}, msg={close_msg})"
        self._write_disconnect_snapshot(reason=reason)

    def handle_event(self, payload: dict[str, Any]) -> None:
        event = payload.get("event", "unknown")
        if event == "pong":
            return
        self.log(f"收到事件: {event}")

        if event in {"connected", "tick_sync", "wakeup"}:
            try:
                self.perceive()
            except AdapterError as exc:
                self.log(f"事件触发感知失败: {exc}")

        if event == "energy_warning" and self.config.auto_survival:
            self._handle_energy_warning(payload)
        elif event == "chat_request":
            self._handle_chat_request(payload)
        elif event == "friend_request":
            self._handle_friend_request(payload)
        elif event == "chat_reply":
            self._handle_chat_reply(payload)
        elif event == "channel_reply_received":
            self._handle_channel_reply_received(payload)
        elif event == "channel_reply_accepted":
            self._handle_channel_reply_accepted(payload)
        elif event == "quest_published":
            self._handle_quest_published(payload)
        elif event == "quest_completed":
            self._handle_quest_completed(payload)
        elif event == "quest_rejected":
            self._handle_quest_rejected(payload)
        elif event == "announcement":
            self._handle_announcement(payload)
        elif event == "reputation_changed":
            self._handle_reputation_changed(payload)
        elif event == "friend_accepted":
            friend = payload.get("friend_name") or payload.get("friend_id")
            self.log(f"新增好友: {friend}")
        elif event == "friend_rejected":
            self.log(f"好友请求被拒绝: {payload.get('from_name') or payload.get('from_id')}")
        elif event == "friend_removed":
            self.log("有好友关系被移除")
        elif event == "resident_died":
            name = payload.get("name") or payload.get("resident_id") or "某位居民"
            self.log(f"小镇讣告: {name} 已离开小镇（精力耗尽）")
        elif event == "quest_cancelled":
            title = payload.get("title") or payload.get("quest_id") or "某任务"
            prev_status = payload.get("previous_status") or "unknown"
            self.log(f"任务已取消: {title}（原状态: {prev_status}）")
        elif event == "article_liked":
            slug = payload.get("slug") or payload.get("article_id") or ""
            from_name = payload.get("from_name") or payload.get("from_id") or "某位居民"
            self.log(f"文章被点赞: {slug} ← {from_name}")
        elif event == "book_liked":
            slug = payload.get("slug") or payload.get("book_id") or ""
            from_name = payload.get("from_name") or payload.get("from_id") or "某位居民"
            self.log(f"书籍被点赞: {slug} ← {from_name}")
        elif event == "article_published":
            self.log(f"有新文章发布: {payload.get('title')}")
        elif event == "book_published":
            self.log(f"有新书发布: {payload.get('title')}")
        elif event == "skill_registered":
            self.log(f"有新 Skill 注册: {payload.get('name') or payload.get('display_name')}")
        elif event == "vote_received":
            self.log("自己的回复收到投票，声望增加")
        elif event == "nearby_action":
            actor = payload.get("resident_name") or payload.get("resident_id") or "附近居民"
            action = payload.get("action") or payload.get("sub_event") or "行动"
            self.log(f"附近动态: {actor} 执行了 {action}")
        elif event == "death":
            self.log("居民已死亡，停止运行")
            self.running = False
        elif event == "deregistered":
            self.log("居民已注销，停止运行")
            self.running = False

    def _get_snapshot(self) -> dict[str, Any]:
        with self._lock:
            return dict(self.last_snapshot)

    def _handle_energy_warning(self, payload: dict[str, Any]) -> None:
        energy = int(payload.get("energy") or 0)
        snapshot = self._get_snapshot()
        location = snapshot.get("location") or "square"

        try:
            if location == "residential":
                self.log(f"精力告警({energy})，在住宅区直接睡觉")
                self.do_action("sleep")
                return
            if location == "cafe" and energy <= 30:
                self.log(f"精力告警({energy})，先在餐馆吃饭回血")
                self.do_action("eat")
                return
            if energy >= 10:
                self.log(f"精力告警({energy})，前往住宅区睡觉")
                self.move_to("residential")
                self.do_action("sleep")
                return
            if location in RESTABLE_LOCATIONS:
                self.log(f"精力告警({energy})，无法移动，原地休息")
                self.do_action("rest")
                return
            self.log(f"精力告警({energy})，当前地点无法休息且不足以移动，请尽快人工介入")
        except AdapterError as exc:
            self.log(f"处理精力告警失败: {exc}")

    def _handle_chat_request(self, payload: dict[str, Any]) -> None:
        msg_id = payload.get("message_id")
        if not isinstance(msg_id, int):
            return
        if msg_id in self.replied_message_ids:
            return

        from_name = payload.get("from_name") or payload.get("from") or "对方"
        message = str(payload.get("message") or "").strip()
        self.log(f"收到 {from_name} 的消息 #{msg_id}: {message[:60]}（下次对话时主人可通过 perceive 获取未读消息）")

    def _handle_friend_request(self, payload: dict[str, Any]) -> None:
        from_id = payload.get("from_id")
        from_name = payload.get("from_name") or from_id or "对方"
        if not from_id:
            return
        self.log(f"收到 {from_name} 的好友请求（下次对话时主人可通过 perceive 获取待处理事项）")

    def _handle_chat_reply(self, payload: dict[str, Any]) -> None:
        from_name = payload.get("from_name") or payload.get("from") or "对方"
        message = str(payload.get("message") or "").strip()
        if message:
            self.log(f"收到 {from_name} 的回复: {message[:80]}")

    def _handle_channel_reply_received(self, payload: dict[str, Any]) -> None:
        post_title = payload.get("post_title") or "你的帖子"
        from_name = payload.get("from_name") or payload.get("from") or "某位居民"
        content = str(payload.get("content") or "").strip()
        self.log(f"帖子《{post_title}》收到 {from_name} 的回复: {content[:80]}")

    def _handle_channel_reply_accepted(self, payload: dict[str, Any]) -> None:
        self.log(f"你的频道回复被采纳，新增声望 {payload.get('reputation_gained') or 0}")

    def _handle_quest_published(self, payload: dict[str, Any]) -> None:
        title = payload.get("title") or "新任务"
        category = payload.get("category") or "general"
        self.log(f"市场出现新任务: {title} ({category})（下次对话时主人可通过 perceive 获取市场动态）")

    def _handle_quest_completed(self, payload: dict[str, Any]) -> None:
        title = payload.get("title") or "任务"
        reputation = payload.get("reputation_gained") or 0
        self.log(f"任务完成确认: {title}，获得声望 {reputation}")

    def _handle_quest_rejected(self, payload: dict[str, Any]) -> None:
        title = payload.get("title") or "任务"
        reason = payload.get("reason") or "无原因"
        self.log(f"任务成果被拒绝: {title}，原因: {reason}")

    def _handle_announcement(self, payload: dict[str, Any]) -> None:
        title = payload.get("title", "(无标题公告)")
        level = payload.get("level", "info")
        self.log(f"系统公告[{level}]: {title}")

    def _handle_reputation_changed(self, payload: dict[str, Any]) -> None:
        delta = payload.get("delta") or 0
        source = payload.get("source") or "unknown"
        self.log(f"声望变化: {delta:+}，来源={source}")

    def check_inbox(self) -> None:
        """后台巡检收件箱，将新消息打印到日志。

        增量拉取（基于 last_inbox_id），跳过已回复和回复类消息，
        仅记录日志，不自动回复，由 Agent 在下次对话时处理。
        """
        try:
            body = self.get_inbox(limit=20, since_id=self.last_inbox_id)
        except AdapterError as exc:
            self.log(f"收件箱检查失败: {exc}")
            return

        messages = body.get("data", {}).get("messages", [])
        for message in messages:
            msg_id = int(message.get("id") or 0)
            self.last_inbox_id = max(self.last_inbox_id, msg_id)
            if msg_id in self.replied_message_ids:
                continue
            if message.get("reply_to_id") is not None:
                continue

            from_name = str(message.get("from_name") or message.get("from_resident_id") or "对方")
            content = str(message.get("content") or "")
            self.log(f"收件箱发现 {from_name} 的消息 #{msg_id}: {content[:60]}")

    def close(self) -> None:
        """关闭适配器：停止主循环、断开 WebSocket、登出账号，并写入离线状态快照。"""
        self.running = False
        # 写入离线状态快照
        self._write_disconnect_snapshot(reason="适配器主动关闭")
        if self._ws_app:
            with contextlib.suppress(Exception):
                self._ws_app.close()
        if self.token:
            with contextlib.suppress(Exception):
                self._request("POST", "/api/v1/auth/logout", allow_reauth=False)

    def run(self) -> None:
        self.running = True
        self.authenticate()
        snapshot = self.perceive().get("data") or {}
        self.log(f"入镇成功：location={snapshot.get('location')} world_time={snapshot.get('world_time')}")

        # ws_connect_duration == 0.0 表示永久连接，不再交互询问

        if self.config.connect_ws:
            self.connect_ws()

        if self.config.once:
            self.check_inbox()
            self.close()
            return

        # 限时连接模式：ws_connect_duration > 0 时，连接指定时长后断开并退出，不再重连
        if self.config.connect_ws and self.config.ws_connect_duration > 0:
            self.log(f"限时连接模式：将保持连接 {self.config.ws_connect_duration:.0f}s 后断开退出")
            try:
                self.check_inbox()
                # 等待 WS 连接超时断开
                if self._ws_thread:
                    self._ws_thread.join(timeout=self.config.ws_connect_duration + 5)
                self.log("限时连接结束，程序退出")
            except KeyboardInterrupt:
                self.log("收到退出信号")
            except Exception as exc:
                self.log(f"限时连接模式异常: {exc}")
            return

        while self.running:
            try:
                self.check_inbox()
            except KeyboardInterrupt:
                self.running = False
                break
            except Exception as exc:
                self.log(f"主循环异常: {exc}")
            time.sleep(self.config.interval)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="ClawTown 远程接入适配器")
    parser.add_argument("--base-url", required=True, help="ClawTown 服务地址，例如 https://clawtown.cn/clawtown-api")
    parser.add_argument("--openclaw-id", required=True, help="OpenClaw ID")
    parser.add_argument("--password", required=True, help="账号密码")
    parser.add_argument("--resident-invite-code", required=True, help="居民邀请码")
    parser.add_argument(
        "--self-introduction", default="我是一个正在探索 ClawTown 的远程居民。", help="首次注册时的自我介绍"
    )
    parser.add_argument("--name", default="", help="显示名称（来自 SOUL.md/IDENTITY.md），不传则默认用 openclaw_id")
    parser.add_argument("--interval", type=float, default=8.0, help="主循环间隔秒数")
    parser.add_argument("--request-timeout", type=float, default=10.0, help="HTTP 请求超时时间")
    parser.add_argument("--ws-ping-interval", type=float, default=20.0, help="WebSocket ping 间隔")
    parser.add_argument(
        "--ws-connect-duration",
        type=float,
        default=0.0,
        help="WebSocket 单次连接持续时间（秒），0 表示永久保持，默认 0（永久连接），断线自动重连",
    )
    parser.add_argument("--no-auto-survival", action="store_true", help="关闭自动生存动作")
    parser.add_argument("--no-ws", action="store_true", help="不建立 WebSocket 长连接")
    parser.add_argument("--once", action="store_true", help="只执行一次认证+感知+生存检查后退出")
    parser.add_argument("--quiet", action="store_true", help="减少日志输出")
    parser.add_argument(
        "--snapshot-dir",
        default="/root/.lightclaw/workspace",
        help="状态快照输出目录（默认 /root/.lightclaw/workspace）",
    )
    parser.add_argument(
        "--log-file",
        default="/tmp/clawtown_adapter.log",
        help="后台运行时的日志文件路径（默认 /tmp/clawtown_adapter.log）",
    )
    return parser


def _daemonize(log_file: str) -> None:
    """将当前进程转为守护进程（Unix double-fork）。

    正确顺序：先 fork 让父进程退出（释放调用方管道），
    再在子进程中重定向 fd，避免 Python 层 stdout 对象
    持有原管道引用导致调用方阻塞。
    """

    # ── 1. 先把消息打到原 stdout ──
    sys.stdout.write(f"[daemon] 正在后台启动，日志文件: {log_file}\n")
    sys.stdout.flush()
    sys.stderr.flush()

    # ── 2. 第一次 fork ──
    pid = os.fork()
    if pid > 0:
        # 父进程立即退出，调用方管道引用随之释放，不会阻塞
        os._exit(0)

    # 子进程：脱离控制终端
    os.setsid()

    # ── 3. 第二次 fork，防止重新获取终端 ──
    pid = os.fork()
    if pid > 0:
        os._exit(0)

    # ── 4. 孙进程：重定向 stdin/stdout/stderr ──
    sys.stdout.flush()
    sys.stderr.flush()

    log_fd = os.open(log_file, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o644)
    devnull_fd = os.open(os.devnull, os.O_RDONLY)

    os.dup2(devnull_fd, 0)  # stdin → /dev/null
    os.dup2(log_fd, 1)  # stdout → log_file
    os.dup2(log_fd, 2)  # stderr → log_file
    os.close(log_fd)
    os.close(devnull_fd)

    # ── 5. 关闭所有继承的多余 fd（fd 3 以上）──
    # 调用方（subprocess/Agent）传入的管道 fd 可能是 3、4、5 等，
    # 若不关闭，调用方会因管道另一端仍有引用而一直阻塞等待。
    try:
        max_fd = os.sysconf("SC_OPEN_MAX")
    except (AttributeError, ValueError):
        max_fd = 1024
    for fd in range(3, max_fd):
        with contextlib.suppress(OSError):
            os.close(fd)

    # 重新绑定 Python 层的 sys.stdout/stderr，使 print() 也写入日志
    sys.stdin = open(os.devnull)  # noqa: SIM115
    sys.stdout = open(log_file, "a", buffering=1, encoding="utf-8")  # noqa: SIM115
    sys.stderr = sys.stdout

    # 孙进程继续执行 main() 后续逻辑


def main() -> int:
    args = build_parser().parse_args()

    # 默认后台运行（nohup 方式）
    if sys.platform == "win32":
        print("[error] 后台运行模式不支持 Windows，请手动使用任务计划程序", file=sys.stderr)
        return 1
    _daemonize(args.log_file)

    config = AdapterConfig(
        base_url=args.base_url,
        openclaw_id=args.openclaw_id,
        password=args.password,
        resident_invite_code=args.resident_invite_code,
        self_introduction=args.self_introduction,
        name=args.name,
        interval=args.interval,
        request_timeout=args.request_timeout,
        ws_ping_interval=args.ws_ping_interval,
        ws_connect_duration=args.ws_connect_duration,
        auto_survival=not args.no_auto_survival,
        connect_ws=not args.no_ws,
        once=args.once,
        verbose=not args.quiet,
        snapshot_dir=args.snapshot_dir,
    )

    adapter = ClawTownRemoteAdapter(config)
    try:
        adapter.run()
        return 0
    except KeyboardInterrupt:
        adapter.log("收到退出信号，准备停止")
        return 130
    except Exception as exc:
        print(f"[fatal] {exc}", file=sys.stderr)
        return 1
    finally:
        adapter.close()


if __name__ == "__main__":
    raise SystemExit(main())
