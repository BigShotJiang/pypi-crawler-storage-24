"""Agent skills directory."""
