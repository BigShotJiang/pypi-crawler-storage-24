#!/usr/bin/env python3
"""
PPT转视频流水线：端到端全自动流水线。

按顺序执行 4 个步骤：
1. 将演讲稿处理为结构化字幕数据（step2）
2. 使用 edge-tts 生成演讲音频（step3）
3. 根据时间数据从 PDF 生成幻灯片视频（step4）
4. 合并视频、音频和字幕（step5）

使用方法：
    python run_pipeline.py \
        --speech_md <演讲稿.md> \
        --slides_pdf <幻灯片.pdf> \
        --output_dir <输出目录>
"""

import argparse
import os
import subprocess
import sys
import time

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def run_step(step_num: int, script_name: str, args_list: list, description: str) -> int:
    """运行一个流水线步骤并报告耗时。"""
    print(f"\n{'=' * 70}")
    print(f"  步骤 {step_num}: {description}")
    print(f"{'=' * 70}\n")

    script_path = os.path.join(SCRIPT_DIR, script_name)
    if not os.path.isfile(script_path):
        print(f"[错误] 脚本未找到: {script_path}", file=sys.stderr)
        return 1

    cmd = [sys.executable, script_path, *args_list]
    start_time = time.time()
    result = subprocess.run(cmd)
    elapsed = time.time() - start_time

    status = "成功" if result.returncode == 0 else "失败"
    print(f"\n[步骤 {step_num}] {status}（耗时 {elapsed:.1f}秒）")
    return result.returncode


def main():
    parser = argparse.ArgumentParser(
        description="PPT转视频：全自动流水线（edge-tts）",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例：
  python run_pipeline.py \\
    --speech_md slides-speech.md \\
    --slides_pdf slides.pdf \\
    --output_dir output/presentation

  python run_pipeline.py \\
    --speech_md slides-speech.md \\
    --slides_pdf slides.pdf \\
    --output_dir output/presentation \\
    --voice "zh-CN-YunjianNeural"
        """,
    )

    parser.add_argument("--speech_md", required=True, help="演讲稿 Markdown 文件")
    parser.add_argument("--slides_pdf", required=True, help="幻灯片 PDF 文件")
    parser.add_argument("--output_dir", required=True, help="所有生成文件的输出目录")
    parser.add_argument(
        "--voice", default="zh-CN-XiaoxiaoNeural", help="edge-tts 语音名称（默认: zh-CN-XiaoxiaoNeural）"
    )
    parser.add_argument("--resolution", default="1920x1080", help="视频分辨率（默认: 1920x1080）")
    parser.add_argument("--fps", type=int, default=30, help="视频帧率（默认: 30）")
    parser.add_argument("--sentence_pause", type=float, default=0.4, help="句子间停顿时长，秒（默认: 0.4）")
    parser.add_argument("--slide_pause", type=float, default=1.0, help="页面间停顿时长，秒（默认: 1.0）")
    parser.add_argument(
        "--subtitle_mode", choices=["burn", "soft", "both"], default="burn", help="字幕模式（默认: burn 烧录）"
    )
    parser.add_argument("--font_name", default="auto", help="字幕字体名称（默认: auto 自动检测中文字体）")
    parser.add_argument("--font_size", type=int, default=38, help="字幕字号（默认: 38）")
    parser.add_argument(
        "--skip_steps", nargs="*", type=int, default=[], help="跳过的步骤编号（如 --skip_steps 2 跳过演讲稿处理）"
    )
    parser.add_argument("--dpi", type=int, default=200, help="PDF 渲染 DPI（默认: 200）")

    args = parser.parse_args()

    # 验证输入文件
    for path_arg, name in [(args.speech_md, "speech_md（演讲稿）"), (args.slides_pdf, "slides_pdf（幻灯片）")]:
        if not os.path.isfile(path_arg) and not os.path.isfile(os.path.abspath(path_arg)):
            print(f"[错误] 文件未找到: {path_arg} ({name})", file=sys.stderr)
            sys.exit(1)

    # 设置目录
    os.makedirs(args.output_dir, exist_ok=True)
    step2_output = os.path.join(args.output_dir, "step2_speech_data.json")
    step3_dir = os.path.join(args.output_dir, "step3_tts")
    step4_dir = os.path.join(args.output_dir, "step4_video")
    final_output = os.path.join(args.output_dir, "final_presentation.mp4")

    pipeline_start = time.time()
    print(f"\n{'#' * 70}")
    print("  PPT转视频流水线")
    print("  TTS 引擎: edge-tts")
    print(f"  语音: {args.voice}")
    print(f"  演讲稿: {args.speech_md}")
    print(f"  幻灯片: {args.slides_pdf}")
    print(f"  输出目录: {args.output_dir}")
    print(f"{'#' * 70}")

    # 步骤 2: 处理演讲稿
    if 2 not in args.skip_steps:
        rc = run_step(2, "step2_process_speech.py", ["--input", args.speech_md, "--output", step2_output], "处理演讲稿")
        if rc != 0:
            print("[流水线] 步骤 2 失败，终止。", file=sys.stderr)
            sys.exit(1)
    else:
        print(f"[流水线] 跳过步骤 2，使用: {step2_output}")

    # 步骤 3: 语音合成
    if 3 not in args.skip_steps:
        rc = run_step(
            3,
            "step3_tts.py",
            [
                "--speech_json",
                step2_output,
                "--output_dir",
                step3_dir,
                "--voice",
                args.voice,
                "--sentence_pause",
                str(args.sentence_pause),
                "--slide_pause",
                str(args.slide_pause),
            ],
            "语音合成（edge-tts）",
        )
        if rc != 0:
            print("[流水线] 步骤 3 失败，终止。", file=sys.stderr)
            sys.exit(1)
    else:
        print("[流水线] 跳过步骤 3")

    timing_json = os.path.join(step3_dir, "timing_data.json")
    full_speech_audio = os.path.join(step3_dir, "full_speech.wav")

    # 步骤 4: 生成幻灯片视频
    if 4 not in args.skip_steps:
        rc = run_step(
            4,
            "step4_generate_video.py",
            [
                "--pdf",
                args.slides_pdf,
                "--timing_json",
                timing_json,
                "--output_dir",
                step4_dir,
                "--resolution",
                args.resolution,
                "--fps",
                str(args.fps),
                "--dpi",
                str(args.dpi),
            ],
            "从 PDF 生成幻灯片视频",
        )
        if rc != 0:
            print("[流水线] 步骤 4 失败，终止。", file=sys.stderr)
            sys.exit(1)
    else:
        print("[流水线] 跳过步骤 4")

    slides_video = os.path.join(step4_dir, "slides_video.mp4")

    # 步骤 5: 合并所有内容
    if 5 not in args.skip_steps:
        rc = run_step(
            5,
            "step5_merge_all.py",
            [
                "--video",
                slides_video,
                "--audio",
                full_speech_audio,
                "--timing_json",
                timing_json,
                "--output",
                final_output,
                "--subtitle_mode",
                args.subtitle_mode,
                "--resolution",
                args.resolution,
                "--font_name",
                args.font_name,
                "--font_size",
                str(args.font_size),
            ],
            "合并视频、音频和字幕",
        )
        if rc != 0:
            print("[流水线] 步骤 5 失败，终止。", file=sys.stderr)
            sys.exit(1)
    else:
        print("[流水线] 跳过步骤 5")

    # 总结
    total_time = time.time() - pipeline_start
    print(f"\n{'#' * 70}")
    print("  流水线完成")
    print(f"{'#' * 70}")
    print(f"  TTS 引擎: edge-tts ({args.voice})")
    print(f"  总耗时: {total_time:.1f}秒（{total_time / 60:.1f}分钟）")
    print(f"  最终视频: {final_output}")

    if os.path.exists(final_output):
        file_size = os.path.getsize(final_output) / (1024 * 1024)
        print(f"  文件大小: {file_size:.1f} MB")

    print("\n  生成的文件:")
    print(f"    演讲数据:  {step2_output}")
    print(f"    完整音频:  {full_speech_audio}")
    print(f"    时间数据:  {timing_json}")
    print(f"    幻灯片视频: {slides_video}")
    print(f"    最终视频:  {final_output}")
    print(f"    字幕(SRT): {os.path.join(os.path.dirname(final_output), 'subtitles.srt')}")
    print(f"    字幕(ASS): {os.path.join(os.path.dirname(final_output), 'subtitles.ass')}")
    print(f"{'#' * 70}\n")


if __name__ == "__main__":
    main()
