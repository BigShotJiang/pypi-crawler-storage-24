#!/usr/bin/env python3
"""
第3步：使用 edge-tts 生成演讲音频。

功能说明：
1. 读取第2步生成的结构化演讲数据
2. 使用 edge-tts（微软免费在线 TTS）逐句生成音频
3. 插入句间/页间停顿
4. 拼接为完整演讲音频并记录精确时间元数据

使用方法：
    python step3_tts.py \
        --speech_json <演讲数据.json> \
        --output_dir <输出目录> \
        --voice "zh-CN-XiaoxiaoNeural"

依赖：
    pip install edge-tts
"""

import argparse
import asyncio
import contextlib
import json
import os
import re
import subprocess
import sys
import tempfile
import time
import wave

# edge-tts 中文推荐语音
EDGE_VOICES = {
    "zh-CN-XiaoxiaoNeural": "晓晓（女，温暖自然）",
    "zh-CN-XiaoyiNeural": "晓伊（女，亲切活泼）",
    "zh-CN-YunjianNeural": "云健（男，沉稳大气）",
    "zh-CN-YunxiNeural": "云希（男，年轻阳光）",
    "zh-CN-YunyangNeural": "云扬（男，新闻播报）",
}

SAMPLE_RATE = 24000


def get_audio_duration(audio_path: str) -> float:
    """使用 ffprobe 获取音频文件时长（秒）。"""
    try:
        result = subprocess.run(
            [
                "ffprobe",
                "-v",
                "error",
                "-show_entries",
                "format=duration",
                "-of",
                "default=noprint_wrappers=1:nokey=1",
                audio_path,
            ],
            capture_output=True,
            text=True,
        )
        return float(result.stdout.strip())
    except Exception:
        return 0.0


def synthesize(text: str, output_path: str, voice: str) -> float:
    """
    使用 edge-tts 合成单句音频。

    返回：音频时长（秒），失败返回 0.0
    """
    import edge_tts

    try:
        mp3_path = output_path.rsplit(".", 1)[0] + ".mp3"

        communicate = edge_tts.Communicate(text=text, voice=voice)
        # 兼容不同版本 edge-tts：优先 save_sync，回退 asyncio.run(save())
        if hasattr(communicate, "save_sync"):
            communicate.save_sync(mp3_path)
        else:
            asyncio.run(communicate.save(mp3_path))

        # MP3 → WAV（24kHz 单声道 16bit PCM）
        cmd = ["ffmpeg", "-y", "-i", mp3_path, "-acodec", "pcm_s16le", "-ar", str(SAMPLE_RATE), "-ac", "1", output_path]
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            print(f"[错误] MP3→WAV 转换失败: {result.stderr}", file=sys.stderr)
            return 0.0

        if os.path.exists(mp3_path):
            os.remove(mp3_path)

        return get_audio_duration(output_path)

    except Exception as e:
        print(f"[错误] edge-tts 合成失败 '{text[:30]}...': {e}", file=sys.stderr)
        return 0.0


_silence_counter = 0


def add_silence(duration_sec: float) -> str:
    """生成指定时长的静音 WAV 文件（跨平台安全，唯一路径）。"""
    global _silence_counter
    _silence_counter += 1
    samples = int(duration_sec * SAMPLE_RATE)
    tmp_dir = tempfile.gettempdir()
    tmp_path = os.path.join(tmp_dir, f"silence_{_silence_counter:04d}_{duration_sec:.2f}s.wav")

    with wave.open(tmp_path, "w") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(SAMPLE_RATE)
        wf.writeframes(b"\x00\x00" * samples)

    return tmp_path


def concatenate_audio_files(audio_files: list, output_path: str):
    """使用 FFmpeg 拼接多个音频文件。"""
    if not audio_files:
        return

    list_path = output_path + ".filelist.txt"
    with open(list_path, "w") as f:
        for af in audio_files:
            abs_path = os.path.abspath(af)
            f.write(f"file '{abs_path}'\n")

    cmd = [
        "ffmpeg",
        "-y",
        "-f",
        "concat",
        "-safe",
        "0",
        "-i",
        list_path,
        "-acodec",
        "pcm_s16le",
        "-ar",
        str(SAMPLE_RATE),
        "-ac",
        "1",
        output_path,
    ]

    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"[错误] 音频拼接失败: {result.stderr}", file=sys.stderr)

    if os.path.exists(list_path):
        os.remove(list_path)


def normalize_text_for_tts(text: str) -> str:
    """文本预处理：清理特殊符号，减少 TTS 异常。edge-tts 自带数字朗读能力。"""
    result = text
    result = re.sub(r"——", "，", result)
    result = re.sub(r"—", "，", result)
    result = re.sub(r"\s+", " ", result).strip()
    return result


def main():
    parser = argparse.ArgumentParser(description="使用 edge-tts 生成演讲音频")
    parser.add_argument("--speech_json", required=True, help="第2步生成的结构化演讲 JSON")
    parser.add_argument("--output_dir", required=True, help="输出目录")
    parser.add_argument(
        "--voice",
        default="zh-CN-XiaoxiaoNeural",
        help="edge-tts 语音名称（默认: zh-CN-XiaoxiaoNeural）。可选: "
        + ", ".join(f"{k}({v})" for k, v in EDGE_VOICES.items()),
    )
    parser.add_argument("--sentence_pause", type=float, default=0.4, help="句子间停顿时长（秒，默认: 0.4）")
    parser.add_argument("--slide_pause", type=float, default=1.0, help="页面间停顿时长（秒，默认: 1.0）")
    args = parser.parse_args()

    # 检查 edge-tts
    try:
        import edge_tts  # noqa: F401
    except ImportError:
        print("[错误] edge-tts 未安装。请运行: pip install edge-tts", file=sys.stderr)
        sys.exit(1)

    # 加载演讲数据
    with open(args.speech_json, encoding="utf-8") as f:
        speech_data = json.load(f)

    slides = speech_data["slides"]
    os.makedirs(args.output_dir, exist_ok=True)

    sentences_dir = os.path.join(args.output_dir, "sentences")
    slides_audio_dir = os.path.join(args.output_dir, "slides")
    os.makedirs(sentences_dir, exist_ok=True)
    os.makedirs(slides_audio_dir, exist_ok=True)

    voice = args.voice
    print("\n[第3步] TTS 引擎: edge-tts")
    print(f"[第3步] 语音: {voice}")
    if voice in EDGE_VOICES:
        print(f"[第3步] 描述: {EDGE_VOICES[voice]}")

    # 时间元数据
    timing_data = {
        "sample_rate": SAMPLE_RATE,
        "tts_engine": "edge",
        "voice": voice,
        "slides": [],
        "total_duration": 0.0,
    }

    all_audio_files = []
    current_time = 0.0

    for slide in slides:
        slide_num = slide["slide_number"]
        slide_title = slide["title"]
        sentences = slide["sentences"]

        print(f"\n[第3步] 处理第 {slide_num} 页: {slide_title}")
        print(f"  句子数: {len(sentences)}")

        slide_start_time = current_time
        slide_audio_files = []
        sentence_timings = []

        for idx, sentence in enumerate(sentences):
            sent_file = os.path.join(sentences_dir, f"slide{slide_num}_sent{idx:03d}.wav")

            # 文本预处理
            processed = normalize_text_for_tts(sentence)
            if processed != sentence:
                print(f"  [预处理] {sentence[:40]} → {processed[:40]}")

            print(f"  生成中: [{idx + 1}/{len(sentences)}] {sentence[:40]}...")
            start_t = time.time()

            duration = synthesize(text=processed, output_path=sent_file, voice=voice)

            gen_time = time.time() - start_t
            print(f"    时长: {duration:.2f}秒（耗时 {gen_time:.1f}秒）")

            if duration > 0:
                sentence_timings.append(
                    {
                        "index": idx,
                        "text": sentence,
                        "start_time": current_time,
                        "duration": duration,
                        "end_time": current_time + duration,
                        "audio_file": sent_file,
                    }
                )
                slide_audio_files.append(sent_file)
                all_audio_files.append(sent_file)
                current_time += duration

                # 句子间停顿（最后一句不加）
                if idx < len(sentences) - 1:
                    pause_file = add_silence(args.sentence_pause)
                    slide_audio_files.append(pause_file)
                    all_audio_files.append(pause_file)
                    current_time += args.sentence_pause

        # 拼接本页音频
        slide_audio_path = os.path.join(slides_audio_dir, f"slide{slide_num}_audio.wav")
        concatenate_audio_files(slide_audio_files, slide_audio_path)

        slide_end_time = current_time
        slide_duration = slide_end_time - slide_start_time

        timing_data["slides"].append(
            {
                "slide_number": slide_num,
                "title": slide_title,
                "start_time": slide_start_time,
                "end_time": slide_end_time,
                "duration": slide_duration,
                "audio_file": slide_audio_path,
                "sentences": sentence_timings,
            }
        )

        print(f"  第 {slide_num} 页时长: {slide_duration:.2f}秒")

        # 页间停顿
        if slide != slides[-1]:
            pause_file = add_silence(args.slide_pause)
            all_audio_files.append(pause_file)
            current_time += args.slide_pause

    # 拼接完整音频
    full_audio_path = os.path.join(args.output_dir, "full_speech.wav")
    concatenate_audio_files(all_audio_files, full_audio_path)

    # 清理临时静音文件
    tmp_dir = tempfile.gettempdir()
    for af in all_audio_files:
        if af.startswith(tmp_dir) and "silence_" in af and os.path.exists(af):
            with contextlib.suppress(OSError):
                os.remove(af)

    timing_data["total_duration"] = current_time

    # 保存时间数据
    timing_path = os.path.join(args.output_dir, "timing_data.json")
    with open(timing_path, "w", encoding="utf-8") as f:
        json.dump(timing_data, f, ensure_ascii=False, indent=2)

    print("\n[第3步完成] 语音合成完成。")
    print(f"  语音: {voice}")
    print(f"  完整音频: {full_audio_path}")
    print(f"  总时长: {current_time:.2f}秒")
    print(f"  时间数据: {timing_path}")

    return timing_data


if __name__ == "__main__":
    main()
