"""Configuration dataclass for the LangGraph-based LightClaw agent."""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from langchain_core.language_models import BaseChatModel
    from langchain_core.tools import BaseTool

    from .middleware import LightClawMiddleware


@dataclass
class LightClawGraphConfig:
    """All parameters needed to build and run a LightClaw LangGraph agent.

    Attributes:
        model: A LangChain-compatible chat model instance.
        tools: Sequence of LangChain tools to bind to the agent.
        system_prompt: The system prompt injected as the first message.
        max_iterations: Maximum ReAct loop iterations (maps to
            ``recursion_limit`` in LangGraph).
        middleware: Optional LightClawMiddleware instance for hooks (PR5).
    """

    model: BaseChatModel
    tools: Sequence[BaseTool] = field(default_factory=list)
    system_prompt: str = ""
    max_iterations: int = 50
    middleware: LightClawMiddleware | None = None
