"""Turn-protocol adapters around LangChain messages.

These helpers are intentionally scoped to protocol boundaries so the
LangGraph execution path can stay BaseMessage-native while the app layer
projects messages into turn DTOs only where needed.
"""

from __future__ import annotations

from collections.abc import Sequence
from copy import deepcopy
from typing import Any
from uuid import uuid4

from langchain_core.messages import AIMessage, BaseMessage, ToolMessage

from ....app.turn_protocol import TurnEvent, TurnEventType, TurnHistoryEntry
from ..message_converter import (
    _additional_media_blocks,
    _append_text_or_multimodal,
    _langchain_part_to_block,
    _langchain_role,
    _message_to_internal_kwargs,
    _strip_file_placeholder_lines,
    _strip_placeholder_blocks,
    msgs_to_langchain,
)


def turn_inputs_to_langchain_messages(inputs: Sequence[Any]) -> list[BaseMessage]:
    """Convert turn-protocol input DTOs to LangChain messages."""
    return msgs_to_langchain(list(inputs))


def langchain_message_to_turn_payload(message: BaseMessage) -> dict[str, Any]:
    """Project one LangChain message into turn-protocol fields."""
    role = _langchain_role(message)
    blocks: list[dict[str, Any]] = []
    extra_media_blocks = _additional_media_blocks(message)
    thinking = (getattr(message, "additional_kwargs", None) or {}).get("thinking")
    content = getattr(message, "content", None)

    if isinstance(message, ToolMessage):
        output = message.content if isinstance(message.content, str) else str(message.content)
        blocks.append(
            {
                "type": "tool_result",
                "id": message.tool_call_id or "",
                "name": getattr(message, "name", "") or "",
                "output": output,
            }
        )
        role = "tool"

    elif isinstance(message, AIMessage) and message.tool_calls:
        if content:
            _append_text_or_multimodal(
                blocks,
                content,
                strip_file_placeholders=bool(extra_media_blocks),
            )
        if thinking:
            blocks.append({"type": "thinking", "thinking": thinking})
        for tool_call in message.tool_calls:
            blocks.append(
                {
                    "type": "tool_use",
                    "id": tool_call.get("id", ""),
                    "name": tool_call.get("name", ""),
                    "input": tool_call.get("args", {}),
                }
            )
        blocks.extend(extra_media_blocks)

    else:
        if thinking:
            blocks.append({"type": "thinking", "thinking": thinking})

        if isinstance(content, str):
            text = _strip_file_placeholder_lines(content) if extra_media_blocks else content
            if text:
                blocks.append({"type": "text", "text": text})
        elif isinstance(content, list):
            for part in content:
                if isinstance(part, str):
                    text = _strip_file_placeholder_lines(part) if extra_media_blocks else part
                    if text:
                        blocks.append({"type": "text", "text": text})
                elif isinstance(part, dict):
                    _langchain_part_to_block(blocks, part)
        elif content is not None:
            blocks.append({"type": "text", "text": str(content)})

        if extra_media_blocks:
            blocks = _strip_placeholder_blocks(blocks)
            blocks.extend(extra_media_blocks)

    kwargs = _message_to_internal_kwargs(message)
    payload: dict[str, Any] = {
        "role": role,
        "content": blocks,
        "usage": kwargs.get("usage"),
        "metadata": kwargs.get("metadata"),
    }
    return payload


def langchain_message_to_turn_event(
    message: BaseMessage,
    *,
    turn_id: str,
    event_type: str = TurnEventType.ASSISTANT_COMPLETED,
    message_id: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> TurnEvent:
    """Convert one LangChain message into a canonical turn event."""
    payload = langchain_message_to_turn_payload(message)
    merged_metadata = deepcopy(payload.get("metadata") or {})
    if metadata:
        merged_metadata.update(metadata)

    event_message_id = message_id or str(getattr(message, "id", "") or "") or str(uuid4())
    return TurnEvent(
        type=event_type,
        turn_id=turn_id,
        message_id=event_message_id,
        role=payload.get("role"),
        content=payload.get("content") or [],
        usage=payload.get("usage"),
        metadata=merged_metadata or None,
    )


def langchain_messages_to_turn_history_entries(
    messages: Sequence[BaseMessage],
    *,
    turn_id_prefix: str = "history",
) -> list[TurnHistoryEntry]:
    """Project LangChain history into turn-native history DTOs."""
    entries: list[TurnHistoryEntry] = []
    for index, message in enumerate(messages):
        payload = langchain_message_to_turn_payload(message)
        message_id = str(getattr(message, "id", "") or "") or f"{turn_id_prefix}:{index}"
        entries.append(
            TurnHistoryEntry(
                turn_id=f"{turn_id_prefix}:{index}",
                message_id=message_id,
                role=payload.get("role"),
                content=payload.get("content") or [],
                usage=payload.get("usage"),
                metadata=payload.get("metadata"),
            )
        )
    return entries
