"""LangGraph EventBridge — streams LangGraph events as turn-native events.

This module consumes the ``astream_events`` (v2) stream from a compiled
LangGraph graph and yields canonical ``TurnEvent`` objects.  Legacy
``Message`` / process-protocol projection happens later at the app
boundary.

Event mapping (LangGraph v2 → TurnEvent):
    on_chat_model_stream   → assistant.delta
    on_tool_start          → tool.started
    on_tool_end            → tool.completed
    on_chain_end(LangGraph)→ assistant.completed

Usage:
    >>> bridge = LangGraphEventBridge()
    >>> async for event in bridge.stream(graph, messages, turn_id="turn-1"):
    ...     print(event.type)
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
import warnings
from collections.abc import AsyncIterator, Sequence
from copy import deepcopy
from numbers import Real
from typing import TYPE_CHECKING, Any
from uuid import uuid4

from langgraph.errors import GraphRecursionError

from ...app.schemas.message_types import MessageType
from ...app.turn_protocol import TurnEvent, TurnEventType
from .boundary_adapters.turn_protocol import langchain_message_to_turn_event

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)


def _coerce_dict_like(value: Any) -> dict[str, Any] | None:
    """Convert pydantic-ish metadata objects to plain dicts when possible."""
    if value is None:
        return None
    if hasattr(value, "model_dump"):
        value = value.model_dump(exclude_none=True)
    elif hasattr(value, "dict"):
        value = value.dict(exclude_none=True)
    if isinstance(value, dict):
        return dict(value)
    return None


def _coerce_usage(value: Any) -> dict[str, Any] | None:
    """Return a normalized usage dict or ``None`` when unavailable."""
    usage = _coerce_dict_like(value)
    if usage:
        return usage
    return None


def _extract_usage_metadata(message: Any) -> dict[str, Any] | None:
    """Extract LangChain-standard usage metadata from a message-like object."""
    return _coerce_usage(getattr(message, "usage_metadata", None))


def _sum_usage(
    left: dict[str, Any] | None,
    right: dict[str, Any] | None,
) -> dict[str, Any] | None:
    """Recursively sum numeric usage fields while preserving nested structure."""
    if not right:
        return deepcopy(left) if left else None

    result = deepcopy(left) if left else {}
    for key, value in right.items():
        if isinstance(value, dict):
            merged = _sum_usage(
                result.get(key) if isinstance(result.get(key), dict) else None,
                _coerce_dict_like(value),
            )
            if merged:
                result[key] = merged
            continue

        if isinstance(value, Real) and not isinstance(value, bool):
            current = result.get(key, 0)
            if not isinstance(current, Real) or isinstance(current, bool):
                current = 0
            result[key] = current + value

    return result or None


def _extract_tool_result_payload(
    value: Any,
) -> tuple[str, dict[str, Any] | None]:
    """Extract structured output and optional metadata from one tool result.

    Returns:
        A tuple (output_str, metadata):
        - output_str: JSON array of blocks (if structured), or plain text (if unstructured)
        - metadata: Optional dict with extracted metadata (e.g., from data blocks)
    """
    raw_value = value.content if hasattr(value, "content") else value

    blocks: list[Any] | None = None
    if isinstance(raw_value, list):
        candidate_blocks = list(raw_value)
        if any(isinstance(block, dict) and isinstance(block.get("type"), str) for block in candidate_blocks):
            blocks = candidate_blocks
        else:
            return str(raw_value), None
    elif isinstance(raw_value, str):
        try:
            parsed = json.loads(raw_value)
        except (TypeError, ValueError):
            return raw_value, None
        if not (
            isinstance(parsed, list)
            and any(isinstance(block, dict) and isinstance(block.get("type"), str) for block in parsed)
        ):
            return raw_value, None
        blocks = parsed

    if blocks is None:
        return str(raw_value), None

    # Extract metadata and serialize full structured blocks
    metadata: dict[str, Any] | None = None
    for block in blocks:
        if not isinstance(block, dict):
            continue
        if metadata is None and block.get("type") == "data":
            data = _coerce_dict_like(block.get("data"))
            if data:
                metadata = data

    # Return structured blocks as JSON string (frontend will parse and render)
    output_json = json.dumps(blocks, ensure_ascii=False)
    return output_json, metadata


class _UsageAggregator:
    """Aggregate per-chat-model usage without double counting stream fallbacks."""

    def __init__(self) -> None:
        self.reset()

    def reset(self) -> None:
        self._final_usage_by_run_id: dict[str, dict[str, Any]] = {}
        self._fallback_usage_by_run_id: dict[str, dict[str, Any]] = {}
        self._run_order: list[str] = []

    def record_stream_chunk(self, run_id: str, chunk: Any) -> None:
        usage = _extract_usage_metadata(chunk)
        if not usage or not run_id:
            return
        self._remember_run(run_id)
        self._fallback_usage_by_run_id[run_id] = usage

    def record_final_message(self, run_id: str, message: Any) -> None:
        usage = _extract_usage_metadata(message)
        if not usage or not run_id:
            return
        self._remember_run(run_id)
        self._final_usage_by_run_id[run_id] = usage

    @property
    def run_usage(self) -> dict[str, Any] | None:
        total: dict[str, Any] | None = None
        for run_id in self._run_order:
            usage = self._final_usage_by_run_id.get(run_id)
            if usage is None:
                usage = self._fallback_usage_by_run_id.get(run_id)
            total = _sum_usage(total, usage)
        return total

    @property
    def last_usage(self) -> dict[str, Any] | None:
        for run_id in reversed(self._run_order):
            usage = self._final_usage_by_run_id.get(run_id)
            if usage is None:
                usage = self._fallback_usage_by_run_id.get(run_id)
            if usage is not None:
                return deepcopy(usage)
        return None

    def _remember_run(self, run_id: str) -> None:
        if run_id not in self._run_order:
            self._run_order.append(run_id)


class LangGraphEventBridge:
    """Bridge LangGraph ``astream_events`` to canonical turn events.

    The execution path stays LangChain-native; any legacy protocol
    projection happens outside this bridge.
    """

    def __init__(
        self,
        *,
        emit_tool_events: bool = False,
        stream_version: str = "v2",
    ) -> None:
        """
        Args:
            emit_tool_events: If ``True``, tool start/end events are
                also yielded as Msg.  Defaults to ``False`` (only LLM
                stream tokens and the final message are emitted).
            stream_version: astream_events version. ``"v2"`` recommended.
        """
        self._emit_tool_events = emit_tool_events
        self._stream_version = stream_version
        # PR5: capture final output messages for session persistence
        self.final_output_messages: list = []
        self.final_output_usage: dict[str, Any] | None = None
        self.run_usage: dict[str, Any] | None = None
        # Track whether tool events have been streamed so we can avoid
        # duplicating them in the final ``on_chain_end`` message.
        self._streamed_tool_events: bool = False
        self._usage_aggregator = _UsageAggregator()
        self._current_stream_message_id: str | None = None
        self._current_stream_message_type: str | None = None
        # Buffer for accumulating content that may contain a partial
        # <think> tag split across stream chunks.
        self._think_buffer: str = ""

    def _start_stream_message(self, message_type: str) -> str:
        if self._current_stream_message_type != message_type:
            self._current_stream_message_id = str(uuid4())
            self._current_stream_message_type = message_type
        elif self._current_stream_message_id is None:
            self._current_stream_message_id = str(uuid4())
        return self._current_stream_message_id

    def _reset_stream_message(self) -> None:
        self._current_stream_message_id = None
        self._current_stream_message_type = None

    # ------------------------------------------------------------------
    # <think> tag buffering across stream chunks
    # ------------------------------------------------------------------

    async def _process_think_content(
        self,
        content: str,
        turn_id: str,
        text_buffer: list[str],
    ) -> AsyncIterator[TurnEvent]:
        """Process stream content that may contain ``<think>`` tags.

        Handles the case where ``<think>`` tags span across multiple
        stream chunks by buffering partial tags.  Complete ``<think>``
        blocks are yielded as REASONING deltas; normal text is yielded
        as MESSAGE deltas.
        """
        self._think_buffer += content

        # Yield all fully closed <think>...</think> blocks as reasoning
        think_pattern = re.compile(r"<think>(.*?)</think>", re.DOTALL)
        while True:
            match = think_pattern.search(self._think_buffer)
            if not match:
                break

            # Yield any normal text BEFORE this <think> block
            before = self._think_buffer[: match.start()]
            if before:
                text_buffer.append(before)
                yield TurnEvent(
                    type=TurnEventType.ASSISTANT_DELTA,
                    turn_id=turn_id,
                    message_id=self._start_stream_message(MessageType.MESSAGE),
                    role="assistant",
                    delta={"type": "text", "text": before},
                )

            # Yield the thinking content
            thinking_text = match.group(1)
            if thinking_text:
                yield TurnEvent(
                    type=TurnEventType.ASSISTANT_DELTA,
                    turn_id=turn_id,
                    message_id=self._start_stream_message(MessageType.REASONING),
                    role="assistant",
                    delta={"type": "text", "text": thinking_text},
                    metadata={"message_type": MessageType.REASONING},
                )

            # Advance buffer past the matched block
            self._think_buffer = self._think_buffer[match.end() :]

        # If there is an unclosed <think> tag, keep buffering
        open_idx = self._think_buffer.find("<think>")
        if open_idx >= 0:
            # Yield any text before the opening tag
            before = self._think_buffer[:open_idx]
            if before:
                text_buffer.append(before)
                yield TurnEvent(
                    type=TurnEventType.ASSISTANT_DELTA,
                    turn_id=turn_id,
                    message_id=self._start_stream_message(MessageType.MESSAGE),
                    role="assistant",
                    delta={"type": "text", "text": before},
                )
            # Keep only the partial <think> onwards in the buffer
            self._think_buffer = self._think_buffer[open_idx:]
        else:
            # No pending <think> — flush the remaining buffer as text
            if self._think_buffer:
                text_buffer.append(self._think_buffer)
                yield TurnEvent(
                    type=TurnEventType.ASSISTANT_DELTA,
                    turn_id=turn_id,
                    message_id=self._start_stream_message(MessageType.MESSAGE),
                    role="assistant",
                    delta={"type": "text", "text": self._think_buffer},
                )
            self._think_buffer = ""

    async def _flush_think_buffer(
        self,
        turn_id: str,
        text_buffer: list[str],
    ) -> AsyncIterator[TurnEvent]:
        """Flush any remaining think buffer content at end of stream.

        If there is a dangling ``<think>`` that was never closed, treat
        the entire buffered content as reasoning (best-effort).
        """
        if not self._think_buffer:
            return

        remaining = self._think_buffer
        self._think_buffer = ""

        # If it starts with <think> but never closed, treat as reasoning
        if remaining.startswith("<think>"):
            thinking_text = remaining[len("<think>") :]
            if thinking_text:
                yield TurnEvent(
                    type=TurnEventType.ASSISTANT_DELTA,
                    turn_id=turn_id,
                    message_id=self._start_stream_message(MessageType.REASONING),
                    role="assistant",
                    delta={"type": "text", "text": thinking_text},
                    metadata={"message_type": MessageType.REASONING},
                )
        else:
            # Unexpected leftover — yield as normal text
            text_buffer.append(remaining)
            yield TurnEvent(
                type=TurnEventType.ASSISTANT_DELTA,
                turn_id=turn_id,
                message_id=self._start_stream_message(MessageType.MESSAGE),
                role="assistant",
                delta={"type": "text", "text": remaining},
            )

    # ------------------------------------------------------------------
    # ToolGuard 集成
    # ------------------------------------------------------------------

    async def _check_tool_guard(
        self,
        *,
        tool_name: str,
        tool_input: dict,
        turn_id: str,
        run_id: str,
        session_id: str,
        user_id: str,
        channel: str,
    ) -> TurnEvent | None:
        """在工具执行前运行 ToolGuard 检查。

        返回 TOOL_APPROVAL_REQUIRED 事件（需要审批），或 None（安全/已禁用）。
        """
        try:
            from lightclaw.security.tool_guard.approval import format_findings_summary
            from lightclaw.security.tool_guard.engine import get_guard_engine
            from lightclaw.security.tool_guard.service import get_approval_service
            from lightclaw.security.tool_guard.utils import log_findings

            engine = get_guard_engine()
            if not engine.enabled:
                return None

            # 无条件拒绝的工具
            if engine.is_denied(tool_name):
                logger.warning(
                    "Tool guard: tool '%s' is in the denied set, auto-denying",
                    tool_name,
                )
                result = engine.guard(tool_name, tool_input)
                findings_text = (
                    format_findings_summary(result)
                    if result and result.findings
                    else "- Tool is in the denied list / 工具在禁止列表中"
                )
                return TurnEvent(
                    type=TurnEventType.TOOL_APPROVAL_REQUIRED,
                    turn_id=turn_id,
                    data={
                        "call_id": run_id,
                        "tool_name": tool_name,
                        "tool_input": tool_input,
                        "auto_denied": True,
                        "findings_text": findings_text,
                        "severity": result.max_severity.value if result else "DENIED",
                        "findings_count": result.findings_count if result else 0,
                        "session_id": session_id,
                        "user_id": user_id,
                        "channel": channel,
                    },
                )

            # 受保护工具：检查是否已有预批准
            if engine.is_guarded(tool_name) and session_id:
                svc = get_approval_service()
                consumed = await svc.consume_approval(
                    session_id,
                    tool_name,
                    tool_params=tool_input,
                )
                if consumed:
                    logger.info(
                        "Tool guard: pre-approved '%s' (session %s), skipping",
                        tool_name,
                        session_id[:8],
                    )
                    return None

            # 运行 guard 规则扫描
            if engine.is_guarded(tool_name):
                result = engine.guard(tool_name, tool_input)
                if result is not None and result.findings:
                    log_findings(tool_name, result)

                    if session_id:
                        # 创建 pending 审批记录
                        await svc.create_pending(
                            session_id=session_id,
                            user_id=user_id,
                            channel=channel,
                            tool_name=tool_name,
                            result=result,
                            extra={"tool_call": {"name": tool_name, "input": tool_input}},
                        )

                    findings_text = format_findings_summary(result)
                    return TurnEvent(
                        type=TurnEventType.TOOL_APPROVAL_REQUIRED,
                        turn_id=turn_id,
                        data={
                            "call_id": run_id,
                            "tool_name": tool_name,
                            "tool_input": tool_input,
                            "auto_denied": False,
                            "findings_text": findings_text,
                            "severity": result.max_severity.value,
                            "findings_count": result.findings_count,
                            "session_id": session_id,
                            "user_id": user_id,
                            "channel": channel,
                        },
                    )
        except ImportError:
            # ToolGuard 模块未安装，跳过
            pass
        except Exception as exc:
            logger.warning("Tool guard check error (non-blocking): %s", exc, exc_info=True)

        return None

    async def _wait_for_approval(
        self,
        *,
        session_id: str,
        tool_name: str,
        timeout: float = 300.0,
    ) -> str:
        """等待审批结果。

        返回 "approved"、"denied" 或 "timeout"。
        """
        if not session_id:
            return "denied"
        try:
            from lightclaw.security.tool_guard.approval import ApprovalDecision
            from lightclaw.security.tool_guard.service import get_approval_service

            svc = get_approval_service()
            pending = await svc.get_pending_by_session(session_id)
            if pending is None:
                return "denied"

            try:
                decision = await asyncio.wait_for(
                    asyncio.shield(pending.future),
                    timeout=timeout,
                )
                return decision.value
            except TimeoutError:
                await svc.resolve_request(
                    pending.request_id,
                    ApprovalDecision.TIMEOUT,
                )
                return "timeout"
        except Exception as exc:
            logger.warning("Tool guard wait_for_approval error: %s", exc)
            return "denied"

    async def stream(
        self,
        graph: Any,
        messages: Sequence[Any],
        *,
        turn_id: str,
        config: dict | None = None,
        max_iterations: int | None = None,
    ) -> AsyncIterator[TurnEvent]:
        """Stream a LangGraph agent run, yielding canonical ``TurnEvent`` objects.

        Args:
            graph: A compiled LangGraph graph.
            messages: Input LangChain messages.
            turn_id: Turn identifier propagated through the event stream.
        """
        self.final_output_messages = []
        self.final_output_usage = None
        self.run_usage = None
        self._streamed_tool_events = False
        self._usage_aggregator.reset()
        self._reset_stream_message()
        self._think_buffer = ""

        final_result: dict | None = None
        text_buffer: list[str] = []

        # 将 max_iterations 换算为 LangGraph recursion_limit 并注入 config
        # 每次 ReAct 循环包含 agent 节点 + tools 节点 = 2 步，最后一次 agent 输出 +1
        run_config = dict(config or {})
        if max_iterations is not None:
            run_config["recursion_limit"] = max_iterations * 2 + 1
            logger.debug(
                "Setting recursion_limit=%d (max_iterations=%d)",
                run_config["recursion_limit"],
                max_iterations,
            )

        try:
            with warnings.catch_warnings():
                warnings.filterwarnings("ignore", category=DeprecationWarning)

                async for event in graph.astream_events(
                    {"messages": list(messages)},
                    config=run_config,
                    version=self._stream_version,
                ):
                    kind = event.get("event", "")

                    # ── LLM streaming token ──
                    if kind == "on_chat_model_stream":
                        chunk = event.get("data", {}).get("chunk")
                        if chunk is None:
                            continue
                        self._usage_aggregator.record_stream_chunk(
                            str(event.get("run_id", "") or ""),
                            chunk,
                        )

                        content = getattr(chunk, "content", None)
                        if content and isinstance(content, str):
                            # Accumulate into think_buffer to handle
                            # <think> tags that span across chunks.
                            async for te in self._process_think_content(content, turn_id, text_buffer):
                                yield te

                        # Handle thinking blocks in streaming
                        thinking = (getattr(chunk, "additional_kwargs", {}) or {}).get("thinking")
                        if thinking:
                            yield TurnEvent(
                                type=TurnEventType.ASSISTANT_DELTA,
                                turn_id=turn_id,
                                message_id=self._start_stream_message(MessageType.REASONING),
                                role="assistant",
                                delta={"type": "text", "text": thinking},
                                metadata={"message_type": MessageType.REASONING},
                            )

                    elif kind == "on_chat_model_end":
                        # Flush any remaining think buffer when the model
                        # finishes so partial <think> blocks are not lost.
                        async for te in self._flush_think_buffer(turn_id, text_buffer):
                            yield te

                        self._usage_aggregator.record_final_message(
                            str(event.get("run_id", "") or ""),
                            event.get("data", {}).get("output"),
                        )

                    # ── Tool execution events ──
                    elif kind == "on_tool_start":
                        tool_name = event.get("name", "unknown")
                        tool_input = event.get("data", {}).get("input", {})
                        tool_input_dict = tool_input if isinstance(tool_input, dict) else {"input": str(tool_input)}

                        # ToolGuard 拦截：在工具执行前检查参数安全性
                        guard_event = await self._check_tool_guard(
                            tool_name=tool_name,
                            tool_input=tool_input_dict,
                            turn_id=turn_id,
                            run_id=event.get("run_id", ""),
                            session_id=config.get("configurable", {}).get("session_id", "") if config else "",
                            user_id=config.get("configurable", {}).get("user_id", "") if config else "",
                            channel=config.get("configurable", {}).get("channel", "") if config else "",
                        )
                        if guard_event is not None:
                            # 工具被拦截，yield TOOL_APPROVAL_REQUIRED 事件后暂停
                            yield guard_event
                            # 等待审批结果（阻塞直到用户 /approve 或拒绝）
                            decision = await self._wait_for_approval(
                                session_id=config.get("configurable", {}).get("session_id", "") if config else "",
                                tool_name=tool_name,
                            )
                            if decision != "approved":
                                # 审批被拒绝或超时，终止当前 turn
                                return
                            # 审批通过，继续正常流程（不 yield TOOL_STARTED，直接继续）

                        if self._emit_tool_events:
                            self._streamed_tool_events = True
                            self._reset_stream_message()
                            yield TurnEvent(
                                type=TurnEventType.TOOL_STARTED,
                                turn_id=turn_id,
                                data={
                                    "call_id": event.get("run_id", ""),
                                    "name": tool_name,
                                    "arguments": tool_input_dict,
                                },
                            )

                    elif kind == "on_tool_end" and self._emit_tool_events:
                        self._reset_stream_message()
                        tool_output, tool_metadata = _extract_tool_result_payload(
                            event.get("data", {}).get("output", "")
                        )
                        tool_payload: dict[str, Any] = {
                            "call_id": event.get("run_id", ""),
                            "name": event.get("name", ""),
                            "output": tool_output,
                        }
                        if tool_metadata:
                            tool_payload.update(tool_metadata)
                        yield TurnEvent(
                            type=TurnEventType.TOOL_COMPLETED,
                            turn_id=turn_id,
                            data=tool_payload,
                        )

                    # ── Graph execution complete ──
                    elif kind == "on_chain_end" and event.get("name") == "LangGraph":
                        output = event.get("data", {}).get("output", {})
                        final_messages = output.get("messages", [])
                        if final_messages:
                            final_result = final_messages[-1]
                            # PR5: capture all output messages for persistence
                            self.final_output_messages = list(final_messages)

        except GraphRecursionError:
            self.run_usage = self._usage_aggregator.run_usage
            self.final_output_usage = self._usage_aggregator.last_usage
            # 达到最大迭代次数，向用户返回友好引导消息
            logger.warning(
                "GraphRecursionError: reached recursion_limit (max_iterations=%s)",
                max_iterations,
            )
            yield TurnEvent(
                type=TurnEventType.ASSISTANT_COMPLETED,
                turn_id=turn_id,
                message_id=self._current_stream_message_id or str(uuid4()),
                role="assistant",
                content=[
                    {
                        "type": "text",
                        "text": (
                            "⚠️ 已达到最大迭代次数限制，任务未能在限定步骤内完成。\n\n"
                            "**建议：**\n"
                            "- 尝试将任务拆分为更小的子任务后重新提问\n"
                            "- 在「运行配置」中适当增大「最大迭代次数」\n"
                            "- 或者换一种更简洁的方式描述你的需求"
                        ),
                    }
                ],
                usage=self.final_output_usage,
            )
            return

        self.run_usage = self._usage_aggregator.run_usage

        # ── Yield final assistant event ──
        if final_result is not None:
            final_event = langchain_message_to_turn_event(
                final_result,
                turn_id=turn_id,
                message_id=self._current_stream_message_id,
            )
            final_usage = _coerce_usage(final_event.usage)
            if final_usage is None and final_event.role == "assistant":
                final_usage = self._usage_aggregator.last_usage
                if final_usage is not None:
                    final_event = final_event.model_copy(update={"usage": deepcopy(final_usage)})
            self.final_output_usage = deepcopy(final_usage) if final_usage else None

            if text_buffer or self._streamed_tool_events:
                filtered_blocks: list[dict[str, Any]] = []
                for block in final_event.content:
                    if not isinstance(block, dict):
                        filtered_blocks.append(block)
                        continue
                    btype = block.get("type", "")
                    if btype == "text" and text_buffer:
                        continue
                    if btype in ("tool_use", "tool_result") and self._streamed_tool_events:
                        continue
                    filtered_blocks.append(block)

                final_event = final_event.model_copy(update={"content": filtered_blocks})

            yield final_event
        else:
            full_text = "".join(text_buffer) if text_buffer else ""
            self.final_output_usage = self._usage_aggregator.last_usage
            yield TurnEvent(
                type=TurnEventType.ASSISTANT_COMPLETED,
                turn_id=turn_id,
                message_id=self._current_stream_message_id or str(uuid4()),
                role="assistant",
                content=[{"type": "text", "text": full_text}],
                usage=self.final_output_usage,
            )
        self._reset_stream_message()

    async def stream_agent_run(
        self,
        *,
        graph: Any,
        messages: Sequence[Any],
        turn_id: str,
        config: dict | None = None,
        max_iterations: int | None = None,
    ) -> AsyncIterator[TurnEvent]:
        """Compatibility alias for the turn-native stream method."""
        async for event in self.stream(
            graph,
            messages,
            turn_id=turn_id,
            config=config,
            max_iterations=max_iterations,
        ):
            yield event
