"""LangChain-compatible wrapper for the memory_search tool.

Uses the same factory pattern as the original: accepts a
``MemoryManager`` instance and returns a bound tool.

When a :class:`FactStore` is provided, search results also include
matching structured facts from the Mem0-style fact database.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from langchain_core.tools import StructuredTool

if TYPE_CHECKING:
    from ...memory.fact_store import FactStore
    from ...memory.memory_manager import MemoryManager


def create_memory_search_langchain_tool(
    memory_manager: MemoryManager,
    fact_store: FactStore | None = None,
) -> StructuredTool:
    """Create a LangChain tool for semantic memory search.

    Args:
        memory_manager: A ``MemoryManager`` instance to delegate searches to.
        fact_store: Optional ``FactStore`` for structured fact search.

    Returns:
        A ``StructuredTool`` that wraps ``memory_manager.memory_search()``.
    """

    async def _arun(
        query: str,
        max_results: int = 5,
        min_score: float = 0.1,
    ) -> str:
        """Search MEMORY.md, memory/*.md files, and structured facts semantically.

        Use this tool before answering questions about prior work, decisions,
        dates, people, preferences, or todos. Returns top relevant snippets
        with file paths and line numbers, plus any matching structured facts.

        Args:
            query: The semantic search query.
            max_results: Maximum number of results (default 5).
            min_score: Minimum similarity score (default 0.1).
        """
        if memory_manager is None:
            return "Error: Memory manager is not enabled."

        parts: list[str] = []

        # Search memory files (existing Qdrant/FTS path)
        try:
            resp = await memory_manager.memory_search(
                query=query,
                max_results=max_results,
                min_score=min_score,
            )
            try:
                blocks = resp.content
                texts = [b["text"] for b in blocks if isinstance(b, dict) and "text" in b]
                if texts:
                    parts.append("\n".join(texts))
            except (AttributeError, TypeError):
                text = str(resp)
                if text:
                    parts.append(text)
        except Exception as e:
            parts.append(f"Memory file search error: {e}")

        # Search structured facts
        if fact_store is not None:
            try:
                fact_results = await fact_store.search_facts_by_text(
                    query=query,
                    limit=max_results,
                )
                if fact_results:
                    fact_lines = ["## Structured Facts"]
                    for f in fact_results:
                        fact_lines.append(
                            f"- [id={f['id']}] ({f['category']}, importance={f['importance']}) {f['content']}"
                        )
                    parts.append("\n".join(fact_lines))
            except Exception as e:
                parts.append(f"Fact search error: {e}")

        return "\n\n".join(parts) if parts else "No results found."

    def _run(
        query: str,
        max_results: int = 5,
        min_score: float = 0.1,
    ) -> str:
        raise NotImplementedError("memory_search is async-only")

    return StructuredTool.from_function(
        func=_run,
        coroutine=_arun,
        name="memory_search",
        description=(
            "Search MEMORY.md, memory/*.md files, and structured facts semantically. "
            "Use before answering questions about prior work, decisions, "
            "dates, people, preferences, or todos."
        ),
    )
