"""Utility for extracting text from AgentScope ToolResponse objects."""

from __future__ import annotations

from typing import Any


def extract_text_from_tool_response(response: Any) -> str:
    """Extract plain text from an AgentScope ``ToolResponse``.

    The original tools return ``ToolResponse(content=[TextBlock(...), ...])``.
    LangChain tools expect a plain ``str`` return value.  This helper
    concatenates all ``TextBlock.text`` values found in the response.

    Args:
        response: A ``ToolResponse`` instance (or anything with a
            ``.content`` list of dicts containing ``"text"`` keys).

    Returns:
        The concatenated text content, or ``str(response)`` as fallback.
    """
    try:
        blocks = response.content
        if not blocks:
            return ""
        texts = []
        for block in blocks:
            if isinstance(block, dict) and "text" in block:
                texts.append(block["text"])
        return "\n".join(texts) if texts else str(response)
    except (AttributeError, TypeError):
        return str(response)
