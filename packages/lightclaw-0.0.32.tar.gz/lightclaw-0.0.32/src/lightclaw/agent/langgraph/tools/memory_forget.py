"""LangChain-compatible wrapper for the memory_forget tool.

Uses the same factory pattern as memory.py: accepts a
``MemoryManager`` instance and returns a bound tool.

When a :class:`FactStore` is provided, also supports deleting
structured facts by ID.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from langchain_core.tools import StructuredTool

if TYPE_CHECKING:
    from ...memory.fact_store import FactStore
    from ...memory.memory_manager import MemoryManager


def create_memory_forget_langchain_tool(
    memory_manager: MemoryManager,
    fact_store: FactStore | None = None,
) -> StructuredTool:
    """Create a LangChain tool for deleting/forgetting memories.

    Supports four modes:
    - query: Search by semantic query, auto-delete high-confidence match
             or return candidates for user selection.
    - file_name: Delete an entire daily memory file by name.
    - chunk_ids: Delete specific chunks by ID (from prior search results).
    - fact_ids: Delete specific structured facts by their IDs.

    Args:
        memory_manager: A ``MemoryManager`` instance to delegate operations to.
        fact_store: Optional ``FactStore`` for structured fact deletion.

    Returns:
        A ``StructuredTool`` that wraps memory forget operations.
    """

    async def _arun(
        query: str = "",
        file_name: str = "",
        chunk_ids: str = "",
        fact_ids: str = "",
    ) -> str:
        """Forget (delete) memories or structured facts. Use one of four modes:

        1. query mode: Provide a natural language query to find and delete
           matching memories. If one result scores very high, it is
           auto-deleted. Otherwise, candidates are listed for user selection.
        2. file mode: Provide a file_name (e.g.
           "2026-03-15_console_abc_v1.md") to delete an entire daily memory
           file. Use "MEMORY.md" to clear all long-term memory.
        3. chunk_ids mode: Provide comma-separated chunk IDs to delete
           specific chunks (from candidates returned by a prior query call).
        4. fact_ids mode: Provide comma-separated fact IDs to delete
           specific structured facts (from memory_search results).

        Args:
            query: Semantic search query to find memories to forget.
            file_name: Daily memory filename to delete entirely.
            chunk_ids: Comma-separated chunk_id values to delete.
            fact_ids: Comma-separated fact ID values to delete.
        """
        # Handle structured fact deletion
        if fact_ids and fact_store is not None:
            ids = [fid.strip() for fid in fact_ids.split(",") if fid.strip()]
            deleted = []
            errors = []
            for fid in ids:
                try:
                    await fact_store.delete_fact(
                        fact_id=int(fid),
                        source_turn_id="user_request",
                        reason="User requested deletion via memory_forget tool",
                    )
                    deleted.append(fid)
                except Exception as e:
                    errors.append(f"fact_id={fid}: {e}")
            parts = []
            if deleted:
                parts.append(f"Deleted facts: {', '.join(deleted)}")
            if errors:
                parts.append(f"Errors: {'; '.join(errors)}")
            return " | ".join(parts) if parts else "No facts deleted."

        if file_name:
            return await memory_manager.memory_forget_by_file(file_name)
        if chunk_ids:
            ids = [cid.strip() for cid in chunk_ids.split(",") if cid.strip()]
            return await memory_manager.memory_forget_by_chunk_ids(ids)
        if query:
            return await memory_manager.memory_forget_by_query(query)
        return "Error: Provide at least one of: query, file_name, chunk_ids, or fact_ids."

    def _run(
        query: str = "",
        file_name: str = "",
        chunk_ids: str = "",
        fact_ids: str = "",
    ) -> str:
        raise NotImplementedError("memory_forget is async-only")

    return StructuredTool.from_function(
        func=_run,
        coroutine=_arun,
        name="memory_forget",
        description=(
            "Delete or forget specific memories or structured facts. Use when the user asks to "
            "forget something, correct wrong memories, or delete memory files. "
            "Four modes: (1) query — search-and-delete by semantic query, "
            "(2) file_name — delete a daily memory file or clear MEMORY.md, "
            "(3) chunk_ids — delete specific chunks by their IDs, "
            "(4) fact_ids — delete specific structured facts by their IDs."
        ),
    )
