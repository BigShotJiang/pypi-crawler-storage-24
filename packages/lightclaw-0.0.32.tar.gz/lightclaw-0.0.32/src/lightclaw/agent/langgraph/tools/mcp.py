"""MCP → LangChain tool adapter.

Converts MCP clients (``MCPClientWrapper``) into LangChain ``StructuredTool``
instances so they can be used in the LangGraph ``create_agent`` graph.

Each MCP tool exposed by a client is wrapped as a separate ``StructuredTool``
that calls the MCP server asynchronously via ``client.call_tool()``.
"""

from __future__ import annotations

import logging
from typing import Any

import mcp.types
from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field, create_model

logger = logging.getLogger(__name__)


def _mcp_schema_to_pydantic(
    tool_name: str,
    input_schema: dict[str, Any],
) -> type[BaseModel]:
    """Convert an MCP tool's JSON Schema ``inputSchema`` to a Pydantic model.

    This dynamically creates a Pydantic model class whose fields match the
    properties defined in the MCP tool's input schema.  LangChain uses the
    model to validate arguments and generate the ``args_schema`` metadata
    that the LLM sees.
    """
    properties = input_schema.get("properties", {})
    required = set(input_schema.get("required", []))

    field_definitions: dict[str, Any] = {}
    for prop_name, prop_schema in properties.items():
        # Map JSON Schema types to Python types
        json_type = prop_schema.get("type", "string")
        py_type: type = str
        if json_type == "integer":
            py_type = int
        elif json_type == "number":
            py_type = float
        elif json_type == "boolean":
            py_type = bool
        elif json_type == "array":
            py_type = list
        elif json_type == "object":
            py_type = dict

        description = prop_schema.get("description", "")
        default = ... if prop_name in required else prop_schema.get("default", None)

        if prop_name in required:
            field_definitions[prop_name] = (py_type, Field(description=description))
        else:
            field_definitions[prop_name] = (
                py_type | None,
                Field(default=default, description=description),
            )

    model_name = f"MCPArgs_{tool_name}"
    return create_model(model_name, **field_definitions)


def _extract_text_from_mcp_result(result: mcp.types.CallToolResult) -> str:
    """Extract plain text from an MCP ``CallToolResult``."""
    texts: list[str] = []
    for content in result.content:
        if isinstance(content, mcp.types.TextContent):
            texts.append(content.text)
        elif isinstance(content, mcp.types.ImageContent):
            texts.append(f"[Image: {content.mimeType}]")
        elif isinstance(content, mcp.types.EmbeddedResource):
            if isinstance(content.resource, mcp.types.TextResourceContents):
                texts.append(content.resource.text or "")
            else:
                texts.append("[Binary resource]")
        else:
            texts.append(str(content))
    return "\n".join(texts) if texts else "(empty result)"


async def mcp_clients_to_langchain_tools(
    mcp_clients: list[Any],
) -> list[StructuredTool]:
    """Convert a list of MCP clients to LangChain tools.

    For each MCP client, this:
    1. Calls ``client.list_tools()`` to discover available tools
    2. Wraps each tool as a ``StructuredTool`` that calls
       ``client.call_tool(name, arguments)`` and returns text

    Args:
        mcp_clients: List of ``MCPClientWrapper`` instances (or any object
            exposing ``list_tools()`` and ``call_tool(name, arguments)``).

    Returns:
        List of LangChain ``StructuredTool`` instances.
    """
    tools: list[StructuredTool] = []

    for client in mcp_clients:
        try:
            mcp_tools: list = await client.list_tools()
        except Exception:
            logger.exception("Failed to list tools from MCP client %s", getattr(client, "name", "?"))
            continue

        for mcp_tool in mcp_tools:
            tool_name: str = mcp_tool.name
            tool_desc: str = mcp_tool.description or tool_name

            # Build args schema from MCP tool input schema
            input_schema = mcp_tool.inputSchema if hasattr(mcp_tool, "inputSchema") else {}

            try:
                args_model = _mcp_schema_to_pydantic(tool_name, input_schema)
            except Exception:
                logger.warning(
                    "Could not build args schema for MCP tool %s, using empty schema",
                    tool_name,
                )
                args_model = create_model(f"MCPArgs_{tool_name}")

            # Create the async wrapper that calls the MCP server via client.call_tool()
            async def _call_mcp(
                _client=client,
                _tool_name=tool_name,
                **kwargs: Any,
            ) -> str:
                try:
                    result = await _client.call_tool(_tool_name, kwargs or None)
                    if isinstance(result, mcp.types.CallToolResult):
                        return _extract_text_from_mcp_result(result)
                    # Fallback: if result has content attribute
                    if hasattr(result, "content"):
                        parts = []
                        for block in result.content:
                            if hasattr(block, "text"):
                                parts.append(block.text)
                            elif isinstance(block, dict) and "text" in block:
                                parts.append(block["text"])
                        return "\n".join(parts) if parts else str(result)
                    return str(result)
                except Exception as exc:
                    logger.exception("MCP tool %s call failed", _tool_name)
                    return f"Error calling tool: {exc}"

            lc_tool = StructuredTool.from_function(
                coroutine=_call_mcp,
                name=tool_name,
                description=tool_desc,
                args_schema=args_model,
            )
            tools.append(lc_tool)
            logger.info("Registered MCP tool as LangChain tool: %s", tool_name)

    return tools
