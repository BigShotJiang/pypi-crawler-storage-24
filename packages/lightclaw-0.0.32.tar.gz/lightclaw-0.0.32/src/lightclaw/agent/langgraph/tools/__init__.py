"""LangChain-compatible tool wrappers for the LangGraph agent.

This package wraps LightClaw's existing tool implementations as LangChain
``BaseTool`` instances so they can be used with ``create_agent``.

Usage:
    >>> from lightclaw.agent.langgraph.tools import load_builtin_tools
    >>> tools = load_builtin_tools()
"""

from .builtins import load_builtin_tools
from .mcp import mcp_clients_to_langchain_tools
from .memory import create_memory_search_langchain_tool
from .memory_forget import create_memory_forget_langchain_tool
from .retrieve_compressed import create_retrieve_compressed_tool
from .skills import load_active_skills_as_tools

__all__ = [
    "create_memory_forget_langchain_tool",
    "create_memory_search_langchain_tool",
    "create_retrieve_compressed_tool",
    "load_active_skills_as_tools",
    "load_builtin_tools",
    "mcp_clients_to_langchain_tools",
]
