"""Factory for creating LangChain-compatible chat models.

Bridges LightClaw's existing provider configuration (providers.json) to
LangChain's ``BaseChatModel`` hierarchy so the rest of the LangGraph
pipeline can stay provider-agnostic.

Supports multiple model providers (OpenAI, Anthropic, Google, Ollama,
Azure, and any OpenAI-compatible endpoint) via the ``chat_model`` field
in each provider definition.

Example:
    >>> from lightclaw.agent.langgraph.model_factory import create_chat_model
    >>> model = create_chat_model()          # uses active provider
    >>> model = create_chat_model(llm_cfg)   # explicit config
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from langchain_core.language_models import BaseChatModel

    from ...providers.models import ResolvedModelConfig

logger = logging.getLogger(__name__)

# Providers known to reject ``stream_options: {include_usage: true}``.
# For these we disable ``stream_usage`` to avoid 400 errors.
_STREAM_USAGE_UNSUPPORTED_PROVIDERS: frozenset[str] = frozenset(
    {
        "minimax",
        "zhipu",
        "moonshot",
        "hunyuan",
        "mimo",
    }
)


def _supports_stream_usage(provider_id: str, base_url: str) -> bool:
    """Return whether the provider supports OpenAI ``stream_options``.

    Checks both provider_id and base_url to detect unsupported providers.
    Defaults to False (conservative) when both are empty to avoid 400 errors.
    """
    provider_id_lower = (provider_id or "").lower()
    base_url_lower = (base_url or "").lower()

    # Check provider_id against known unsupported list
    if provider_id_lower in _STREAM_USAGE_UNSUPPORTED_PROVIDERS:
        return False

    # Check base_url for known incompatible domains
    # Covers: MiniMax, Zhipu, Moonshot, Hunyuan, MiMo, Volcengine
    unsupported_domains = (
        "minimaxi.com",  # MiniMax
        "bigmodel.cn",  # Zhipu AI
        "moonshot.cn",  # Moonshot AI
        "hunyuan.cloud.tencent.com",  # Tencent Hunyuan
        "xiaomimimo.com",  # Xiaomi MiMo
        "ark.cn-beijing.volces.com",  # Volcengine
    )
    if any(domain in base_url_lower for domain in unsupported_domains):
        return False

    # Conservative: if both provider_id and base_url are empty, default to False
    # to avoid accidental 400 errors with unknown providers
    return not (not provider_id_lower and not base_url_lower)


def _resolve_chat_model_name(provider_id: str) -> str:
    """Look up the ``chat_model`` class name for *provider_id*.

    Returns ``"ChatOpenAI"`` when the provider is unknown or has no
    explicit ``chat_model`` configured.
    """
    if not provider_id:
        return "ChatOpenAI"

    try:
        from ...providers.registry import get_provider_chat_model

        name = get_provider_chat_model(provider_id)
        # Map legacy AgentScope names to LangChain equivalents
        if name == "OpenAIChatModel":
            return "ChatOpenAI"
        return name
    except Exception:
        return "ChatOpenAI"


def create_chat_model(
    llm_cfg: ResolvedModelConfig | None = None,
) -> BaseChatModel:
    """Create a LangChain ``BaseChatModel`` from LightClaw provider config.

    Resolution order:
    1. If *llm_cfg* is provided, use it directly.
    2. Otherwise call ``get_active_llm_config()`` to read providers.json.

    The concrete ``BaseChatModel`` subclass (``ChatOpenAI``,
    ``ChatAnthropic``, ``ChatGoogleGenerativeAI``, etc.) is determined
    by the provider's ``chat_model`` field in providers.json.

    Args:
        llm_cfg: Resolved model configuration.  When ``None``, the
            active configuration is loaded automatically.

    Returns:
        A ready-to-use LangChain chat model.

    Raises:
        ValueError: If no LLM is configured.
    """
    if llm_cfg is None:
        from ...providers import get_active_llm_config

        llm_cfg = get_active_llm_config()

    return _create_remote_model(llm_cfg)


def _create_remote_model(
    llm_cfg: ResolvedModelConfig | None,
) -> BaseChatModel:
    """Create a remote chat model, routing to the correct LangChain class."""
    if llm_cfg and (llm_cfg.model or llm_cfg.base_url or llm_cfg.provider_id):
        model_name = llm_cfg.model or "qwen3-max"
        api_key = llm_cfg.api_key
        base_url = llm_cfg.base_url
        provider_id = llm_cfg.provider_id
    else:
        logger.warning("No active LLM configured ")
        model_name = llm_cfg.model if llm_cfg else "qwen3-max"
        api_key = llm_cfg.api_key if llm_cfg else ""
        base_url = llm_cfg.base_url if llm_cfg else ""
        provider_id = llm_cfg.provider_id if llm_cfg else ""

    chat_model_name = _resolve_chat_model_name(provider_id)

    from ...providers.registry import get_langchain_model_class

    model_class = get_langchain_model_class(chat_model_name)

    return _instantiate_model(
        model_class=model_class,
        chat_model_name=chat_model_name,
        model_name=model_name,
        api_key=api_key,
        base_url=base_url,
        provider_id=provider_id,
    )


def _instantiate_model(
    *,
    model_class: type,
    chat_model_name: str,
    model_name: str,
    api_key: str,
    base_url: str,
    provider_id: str = "",
) -> BaseChatModel:
    """Instantiate a LangChain ChatModel with provider-specific parameters.

    Different providers have slightly different constructor signatures;
    this function handles the variance.
    """
    if chat_model_name == "ChatAnthropic":
        kwargs: dict = {
            "model": model_name,
            "api_key": api_key,
            "streaming": True,
            "stream_usage": True,
        }
        if base_url:
            kwargs["base_url"] = base_url
        return model_class(**kwargs)

    if chat_model_name == "ChatGoogleGenerativeAI":
        # Current langchain-google-genai does not accept `stream_usage`.
        return model_class(
            model=model_name,
            google_api_key=api_key,
            streaming=True,
        )

    if chat_model_name == "ChatOllama":
        kwargs: dict = {
            "model": model_name,
        }
        if base_url:
            kwargs["base_url"] = base_url
        return model_class(**kwargs)

    if chat_model_name == "AzureChatOpenAI":
        return model_class(
            model=model_name,
            api_key=api_key or "lightclaw-local",
            azure_endpoint=base_url,
            streaming=True,
            stream_usage=True,
        )

    # Default: ChatOpenAI and any OpenAI-compatible API.
    # Some providers (MiniMax, Zhipu, Moonshot, etc.) reject the
    # ``stream_options`` parameter, so we conditionally disable it.
    # When both provider_id and base_url are empty (fallback case),
    # _supports_stream_usage() returns False to avoid 400 errors.
    use_stream_usage = _supports_stream_usage(provider_id, base_url)
    logger.info(
        "ChatOpenAI init: model=%s, provider=%s, base_url=%s, stream_usage=%s",
        model_name,
        provider_id or "(empty)",
        base_url or "(empty)",
        use_stream_usage,
    )
    return model_class(
        model=model_name,
        api_key=api_key or "lightclaw-local",
        base_url=base_url,
        streaming=True,
        stream_usage=use_stream_usage,
    )
