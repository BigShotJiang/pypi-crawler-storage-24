"""Skills management: sync skills from code to working_dir."""

import filecmp
import logging
import shutil
from pathlib import Path
from typing import Any

import frontmatter
from pydantic import BaseModel, Field

from ..constant import ACTIVE_SKILLS_DIR, CUSTOMIZED_SKILLS_DIR, SKILLS_DIR

logger = logging.getLogger(__name__)


class SkillInfo(BaseModel):
    """Skill information structure.

    The references and scripts fields represent directory trees
    as nested dicts.

    When reading existing skills:
    - Files are represented as {filename: None}
    - Directories are represented as {dirname: {nested_structure}}

    When creating new skills via SkillService.create_skill:
    - Files are represented as {filename: "content"}
    - Directories are represented as {dirname: {nested_structure}}

    Example (reading):
        {
            "file.txt": None,
            "subdir": {
                "nested.py": None,
                "deeper": {
                    "file.sh": None
                }
            }
        }
    """

    # Legacy identifier used throughout the backend/frontend today.
    # This remains the on-disk directory name for backward compatibility.
    name: str
    # Stable directory name for future API consumers.
    slug: str
    # Frontmatter `name` from SKILL.md.
    tool_name: str
    # Frontmatter `description` from SKILL.md.
    description: str = ""
    # Explicit structured classification for UI grouping.
    kind: str  # "builtin" or "workspace"
    content: str
    # Legacy source field retained for compatibility.
    source: str  # "builtin" or "workspace"
    path: str
    references: dict[str, Any] = Field(default_factory=dict)
    scripts: dict[str, Any] = Field(default_factory=dict)
    has_references: bool = False
    has_scripts: bool = False


def get_builtin_skills_dir() -> Path:
    """Get the path to built-in skills directory in the code."""
    return Path(__file__).parent / "skills"


def get_skills_dir() -> Path:
    """Get the path to the unified skills directory in working_dir.

    This is the new single location for all skills (builtin-synced and
    user-created).  It replaces the old active_skills/ + customized_skills/
    split layout.
    """
    return SKILLS_DIR


def get_customized_skills_dir() -> Path:
    """Get the path to legacy customized skills directory.

    Deprecated: Use get_skills_dir() instead.
    """
    return CUSTOMIZED_SKILLS_DIR


def get_active_skills_dir() -> Path:
    """Get the path to legacy active skills directory.

    Deprecated: Use get_skills_dir() instead.
    """
    return ACTIVE_SKILLS_DIR


def get_working_skills_dir() -> Path:
    """
    Get the path to skills directory in working_dir.

    Deprecated: Use get_skills_dir() instead.
    """
    return get_skills_dir()


def _build_directory_tree(directory: Path) -> dict[str, Any]:
    """
    Recursively build a directory tree structure.

    Args:
        directory: Directory to scan.

    Returns:
        Dictionary representing the tree structure where:
        - Files are represented as {filename: None}
        - Directories are represented as {dirname: {nested_structure}}

    Example:
        {
            "file1.txt": None,
            "subdir": {
                "file2.py": None,
                "nested": {
                    "file3.sh": None
                }
            }
        }
    """
    tree: dict[str, Any] = {}

    if not directory.exists() or not directory.is_dir():
        return tree

    for item in sorted(directory.iterdir()):
        if item.is_file():
            tree[item.name] = None
        elif item.is_dir():
            tree[item.name] = _build_directory_tree(item)

    return tree


def _collect_skills_from_dir(directory: Path) -> dict[str, Path]:
    """
    Collect skills from a directory.

    Args:
        directory: Directory to scan for skills.

    Returns:
        Dictionary mapping skill names to their paths.
    """
    skills: dict[str, Path] = {}
    if directory.exists():
        for skill_dir in sorted(directory.iterdir()):
            if skill_dir.is_dir() and (skill_dir / "SKILL.md").exists():
                skills[skill_dir.name] = skill_dir
    return skills


def _parse_skill_metadata(content: str, slug: str) -> tuple[str, str]:
    """Extract stable metadata from a skill's frontmatter.

    Falls back to the directory slug when frontmatter is missing or invalid so
    that listing skills remains robust even with malformed SKILL.md content.
    """
    try:
        post = frontmatter.loads(content)
    except Exception as exc:
        logger.warning(
            "Failed to parse SKILL.md frontmatter for skill '%s': %s",
            slug,
            exc,
        )
        return slug, ""

    raw_tool_name = post.get("name")
    raw_description = post.get("description")

    tool_name = str(raw_tool_name).strip() if raw_tool_name is not None else ""
    description = str(raw_description).strip() if raw_description is not None else ""

    return tool_name or slug, description


def sync_skills_to_working_dir(
    skill_names: list[str] | None = None,
    force: bool = False,
) -> tuple[int, int]:
    """
    Sync built-in skills into the unified skills/ directory.

    Only builtin skills that do not yet exist in skills/ are copied (unless
    force=True).  User-modified skills in skills/ are never overwritten.

    Args:
        skill_names: List of skill names to sync. If None, sync all skills.
        force: If True, overwrite existing skills in skills/.

    Returns:
        Tuple of (synced_count, skipped_count).
    """
    builtin_skills = get_builtin_skills_dir()
    skills_dir = get_skills_dir()

    # Ensure skills directory exists
    skills_dir.mkdir(parents=True, exist_ok=True)

    # Collect builtin skills
    skills_to_sync = _collect_skills_from_dir(builtin_skills)
    if not skills_to_sync and not builtin_skills.exists():
        logger.warning(
            "Built-in skills directory not found: %s",
            builtin_skills,
        )

    # Filter by skill_names if specified
    if skill_names is not None:
        skills_to_sync = {name: path for name, path in skills_to_sync.items() if name in skill_names}

    if not skills_to_sync:
        logger.debug("No skills to sync.")
        return 0, 0

    synced_count = 0
    skipped_count = 0

    # Sync each skill
    for skill_name, skill_dir in skills_to_sync.items():
        target_dir = skills_dir / skill_name

        # Check if skill already exists
        if target_dir.exists() and not force:
            logger.debug(
                "Skill '%s' already exists in skills/, skipping. Use force=True to overwrite.",
                skill_name,
            )
            skipped_count += 1
            continue

        # Copy skill directory
        try:
            if target_dir.exists():
                shutil.rmtree(target_dir)
            shutil.copytree(skill_dir, target_dir)
            logger.debug("Synced built-in skill '%s' to skills/.", skill_name)
            synced_count += 1
        except Exception as e:
            logger.error(
                "Failed to sync skill '%s': %s",
                skill_name,
                e,
            )

    return synced_count, skipped_count


def _is_directory_same(dir1: Path, dir2: Path) -> bool:
    """
    Check if two directories have the same content.

    Args:
        dir1: First directory path.
        dir2: Second directory path.

    Returns:
        True if directories have the same structure and file contents.
    """
    if not dir1.exists() or not dir2.exists():
        return False

    dcmp = filecmp.dircmp(dir1, dir2)

    if dcmp.left_only or dcmp.right_only or dcmp.funny_files:
        return False

    if dcmp.diff_files:
        return False

    return all(_compare_dircmp(sub_dcmp) for sub_dcmp in dcmp.subdirs.values())


def _compare_dircmp(dcmp: "filecmp.dircmp") -> bool:
    """Helper to recursively compare dircmp objects."""
    if dcmp.left_only or dcmp.right_only or dcmp.funny_files or dcmp.diff_files:
        return False
    return all(_compare_dircmp(sub_dcmp) for sub_dcmp in dcmp.subdirs.values())


def sync_skills_from_active_to_customized(
    skill_names: list[str] | None = None,
) -> tuple[int, int]:
    """
    Legacy helper kept for backward compatibility.

    The new skills layout uses a single skills/ directory; this function is a
    no-op and always returns (0, 0).

    Deprecated: No longer needed with the unified skills/ directory.
    """
    logger.debug(
        "sync_skills_from_active_to_customized called but is a no-op in the new unified-skills layout.",
    )
    return 0, 0


def list_available_skills() -> list[str]:
    """
    List skill names that are currently enabled.

    Reads ``skills.entries`` from ``lightclaw.json`` and returns the names of
    skills whose ``enabled`` flag is ``True``.  Only skills that also exist on
    disk inside ``skills/`` are returned.

    Returns:
        List of enabled skill names.
    """
    skills_dir = get_skills_dir()

    if not skills_dir.exists():
        return []

    # Skills on disk
    on_disk: set[str] = {d.name for d in skills_dir.iterdir() if d.is_dir() and (d / "SKILL.md").exists()}

    # Read enabled state from config
    try:
        from ..config.utils import load_config

        config = load_config()
        entries = config.skills.entries
    except Exception as exc:
        logger.warning("Could not load config for skills entries: %s", exc)
        entries = {}

    return [name for name, entry in entries.items() if entry.enabled and name in on_disk]


def ensure_skills_initialized() -> None:
    """
    Sync built-in skills to skills/ dir and auto-enable newly added ones.

    For any built-in skill that is synced for the first time (not yet present
    in ``skills.entries`` in lightclaw.json), it is automatically added with
    ``enabled: true``.  Skills that the user has explicitly disabled are left
    untouched.
    """
    from ..config.config import SkillEntryConfig
    from ..config.utils import load_config, save_config

    # Sync builtin skills into skills/ (skips existing ones)
    sync_skills_to_working_dir()

    # Auto-enable newly synced builtin skills that have no entry in config yet
    try:
        config = load_config()
        builtin_names = set(_collect_skills_from_dir(get_builtin_skills_dir()).keys())
        skills_dir = get_skills_dir()
        changed = False

        for name in builtin_names:
            if (skills_dir / name).exists() and name not in config.skills.entries:
                config.skills.entries[name] = SkillEntryConfig(enabled=True)
                logger.debug("Auto-enabled built-in skill '%s' in lightclaw.json.", name)
                changed = True

        if changed:
            save_config(config)
    except Exception as exc:
        logger.warning("Failed to auto-enable built-in skills: %s", exc)

    available = list_available_skills()

    if not available:
        logger.warning("No skills are enabled after initialization.")
    else:
        logger.debug(
            "Loaded %d skill(s): %s",
            len(available),
            ", ".join(available),
        )


def _read_skills_from_dir(
    directory: Path,
    source: str = "",
    source_resolver=None,
) -> list[SkillInfo]:
    """
    Read skills from a directory and return SkillInfo list.

    Args:
        directory: Directory to read skills from.
        source: Static source label for all skills (used when source_resolver
            is None).
        source_resolver: Optional callable ``(skill_name: str) -> str`` that
            returns a dynamic source label per skill.  Takes precedence over
            the ``source`` argument when provided.

    Returns:
        List of SkillInfo objects.
    """
    skills: list[SkillInfo] = []

    if not directory.exists():
        return skills

    for skill_dir in sorted(directory.iterdir()):
        skill = _read_skill_from_path(
            skill_dir,
            source=source,
            source_resolver=source_resolver,
        )
        if skill is not None:
            skills.append(skill)

    return skills


def _read_skill_from_path(
    skill_dir: Path,
    source: str = "",
    source_resolver=None,
) -> SkillInfo | None:
    """Read a single skill directory into a SkillInfo object."""
    if not skill_dir.is_dir():
        return None

    skill_md = skill_dir / "SKILL.md"
    if not skill_md.exists():
        return None

    try:
        content = skill_md.read_text(encoding="utf-8")
        tool_name, description = _parse_skill_metadata(content, skill_dir.name)

        references = {}
        references_dir = skill_dir / "references"
        if references_dir.exists() and references_dir.is_dir():
            references = _build_directory_tree(references_dir)

        scripts = {}
        scripts_dir = skill_dir / "scripts"
        if scripts_dir.exists() and scripts_dir.is_dir():
            scripts = _build_directory_tree(scripts_dir)

        resolved_source = source_resolver(skill_dir.name) if source_resolver is not None else source
        kind = resolved_source or "workspace"

        return SkillInfo(
            name=skill_dir.name,
            slug=skill_dir.name,
            tool_name=tool_name,
            description=description,
            kind=kind,
            content=content,
            source=kind,
            path=str(skill_dir),
            references=references,
            scripts=scripts,
            has_references=bool(references),
            has_scripts=bool(scripts),
        )
    except Exception as e:
        logger.error(
            "Failed to read skill '%s': %s",
            skill_dir.name,
            e,
        )
        return None


def _create_files_from_tree(
    base_dir: Path,
    tree: dict[str, Any],
) -> None:
    """
    Create files and directories from a tree structure.

    Args:
        base_dir: Base directory to create files in.
        tree: Tree structure where:
            - {filename: str_content} creates a file with content
            - {dirname: {nested_tree}} creates a directory recursively

    Raises:
        ValueError: If tree contains invalid value types.

    Example:
        tree = {
            "file.txt": "content",
            "subdir": {
                "nested.py": "print('hello')",
                "deeper": {
                    "file.sh": "#!/bin/bash"
                }
            }
        }
    """
    if not tree:
        return

    for name, value in tree.items():
        item_path = base_dir / name

        if value is None or isinstance(value, str):
            # It's a file
            content = value if isinstance(value, str) else ""
            item_path.write_text(content, encoding="utf-8")
        elif isinstance(value, dict):
            # It's a directory
            item_path.mkdir(parents=True, exist_ok=True)
            _create_files_from_tree(item_path, value)
        else:
            raise ValueError(
                f"Invalid tree value for '{name}': {type(value)}. Expected None, str, or dict.",
            )


class SkillService:
    """
    Service for managing skills.

    Manages skills in the unified skills/ directory with enable/disable state
    stored in lightclaw.json (skills.entries), mirroring openclaw's
    plugins.entries pattern.
    """

    @staticmethod
    def list_all_skills() -> list[SkillInfo]:
        """
        List all skills from the unified skills/ directory.

        Built-in skills are distinguished from workspace-added skills by
        comparing against the builtin skills code directory.

        Returns:
            List of SkillInfo with name, content, source, and path.
        """
        skills_dir = get_skills_dir()
        builtin_names = set(_collect_skills_from_dir(get_builtin_skills_dir()).keys())

        return _read_skills_from_dir(
            skills_dir,
            source_resolver=lambda name: "builtin" if name in builtin_names else "workspace",
        )

    @staticmethod
    def list_available_skills() -> list[SkillInfo]:
        """
        List all enabled skills.

        Returns:
            List of SkillInfo for skills whose enabled flag is True in config.
        """
        skills_dir = get_skills_dir()
        builtin_names = set(_collect_skills_from_dir(get_builtin_skills_dir()).keys())
        enabled_names = set(list_available_skills())

        all_skills = _read_skills_from_dir(
            skills_dir,
            source_resolver=lambda name: "builtin" if name in builtin_names else "workspace",
        )
        return [s for s in all_skills if s.name in enabled_names]

    @staticmethod
    def get_skill(name: str) -> SkillInfo | None:
        """Return a single skill by slug from the unified skills directory."""
        skill_dir = get_skills_dir() / name
        builtin_names = set(_collect_skills_from_dir(get_builtin_skills_dir()).keys())
        return _read_skill_from_path(
            skill_dir,
            source_resolver=lambda skill_name: "builtin" if skill_name in builtin_names else "workspace",
        )

    @staticmethod
    def create_skill(
        name: str,
        content: str,
        overwrite: bool = False,
        references: dict[str, Any] | None = None,
        scripts: dict[str, Any] | None = None,
        extra_files: dict[str, Any] | None = None,
    ) -> bool:
        """
        Create a new skill in the unified skills/ directory.

        The skill is automatically added to skills.entries with enabled=True
        in lightclaw.json.

        Args:
            name: Skill name (will be the directory name).
            content: Content of SKILL.md file.
            overwrite: If True, overwrite existing skill.
            references: Optional tree structure for references/ subdirectory.
                Can be flat {filename: content} or nested
                {dirname: {filename: content}}.
            scripts: Optional tree structure for scripts/ subdirectory.
                Can be flat {filename: content} or nested
                {dirname: {filename: content}}.
            extra_files: Optional tree structure for additional files
                written to skill root (excluding SKILL.md), usually used
                by imported hub skills that contain runtime assets.

        Returns:
            True if skill was created successfully, False otherwise.

        Examples:
            # Simple flat structure
            create_skill(
                name="my_skill",
                content="# My Skill\\n...",
                references={"doc1.md": "content1"},
                scripts={"script1.py": "print('hello')"}
            )

            # Nested structure
            create_skill(
                name="my_skill",
                content="# My Skill\\n...",
                references={
                    "readme.md": "# Documentation",
                    "examples": {
                        "example1.py": "print('example')",
                        "data": {
                            "sample.json": '{"key": "value"}'
                        }
                    }
                }
            )
        """
        # Validate SKILL.md content has required YAML Front Matter
        try:
            post = frontmatter.loads(content)
            skill_name = post.get("name", None)
            skill_description = post.get("description", None)

            if not skill_name or not skill_description:
                logger.error(
                    "SKILL.md content must have YAML Front Matter with 'name' and 'description' fields.",
                )
                return False

            logger.debug(
                "Validated SKILL.md: name='%s', description='%s'",
                skill_name,
                skill_description,
            )
        except Exception as e:
            logger.error(
                "Failed to parse SKILL.md YAML Front Matter: %s",
                e,
            )
            return False

        skills_dir = get_skills_dir()
        skills_dir.mkdir(parents=True, exist_ok=True)

        skill_dir = skills_dir / name
        skill_md = skill_dir / "SKILL.md"

        # Check if skill already exists
        if skill_dir.exists() and not overwrite:
            logger.debug(
                "Skill '%s' already exists in skills/. Use overwrite=True to replace.",
                name,
            )
            return False

        # Create skill directory and SKILL.md
        try:
            # Clean up existing directory if overwriting
            if skill_dir.exists() and overwrite:
                shutil.rmtree(skill_dir)

            skill_dir.mkdir(parents=True, exist_ok=True)
            skill_md.write_text(content, encoding="utf-8")

            # Create extra files in skill root
            if extra_files:
                _create_files_from_tree(skill_dir, extra_files)
                logger.debug(
                    "Created extra root files for skill '%s'.",
                    name,
                )

            # Create references subdirectory and files from tree
            if references:
                references_dir = skill_dir / "references"
                references_dir.mkdir(parents=True, exist_ok=True)
                _create_files_from_tree(references_dir, references)
                logger.debug(
                    "Created references structure for skill '%s'.",
                    name,
                )

            # Create scripts subdirectory and files from tree
            if scripts:
                scripts_dir = skill_dir / "scripts"
                scripts_dir.mkdir(parents=True, exist_ok=True)
                _create_files_from_tree(scripts_dir, scripts)
                logger.debug(
                    "Created scripts structure for skill '%s'.",
                    name,
                )

            logger.debug("Created skill '%s' in skills/.", name)

            # Auto-enable newly created skill in config
            try:
                from ..config.config import SkillEntryConfig
                from ..config.utils import load_config, save_config

                config = load_config()
                config.skills.entries[name] = SkillEntryConfig(enabled=True)
                save_config(config)
                logger.debug("Auto-enabled skill '%s' in lightclaw.json.", name)
            except Exception as cfg_exc:
                logger.warning(
                    "Created skill '%s' but failed to update config: %s",
                    name,
                    cfg_exc,
                )

            return True
        except Exception as e:
            logger.error(
                "Failed to create skill '%s': %s",
                name,
                e,
            )
            return False

    @staticmethod
    def disable_skill(name: str) -> bool:
        """
        Disable a skill by setting enabled=False in lightclaw.json.

        The skill files remain in skills/ but are no longer loaded by agents.

        Args:
            name: Skill name to disable.

        Returns:
            True if skill was disabled successfully, False otherwise.
        """
        skills_dir = get_skills_dir()
        skill_dir = skills_dir / name

        if not skill_dir.exists():
            logger.debug("Skill '%s' not found in skills/.", name)
            return False

        try:
            from ..config.config import SkillEntryConfig
            from ..config.utils import load_config, save_config

            config = load_config()
            config.skills.entries[name] = SkillEntryConfig(enabled=False)
            save_config(config)
            logger.debug("Disabled skill '%s' in lightclaw.json.", name)
            return True
        except Exception as e:
            logger.error("Failed to disable skill '%s': %s", name, e)
            return False

    @staticmethod
    def enable_skill(name: str, force: bool = False) -> bool:
        """
        Enable a skill by setting enabled=True in lightclaw.json.

        If the skill does not yet exist in skills/, it is synced from
        built-in skills first.

        Args:
            name: Skill name to enable.
            force: If True, re-sync the built-in skill even if it already
                exists in skills/ (refreshes the files).

        Returns:
            True if skill was enabled successfully, False otherwise.
        """
        # Ensure the skill exists on disk (sync from builtin if needed)
        skills_dir = get_skills_dir()
        target = skills_dir / name
        if not target.exists() or force:
            sync_skills_to_working_dir(skill_names=[name], force=force)

        if not target.exists():
            logger.debug(
                "Skill '%s' not found in skills/ or builtin.",
                name,
            )
            return False

        try:
            from ..config.config import SkillEntryConfig
            from ..config.utils import load_config, save_config

            config = load_config()
            config.skills.entries[name] = SkillEntryConfig(enabled=True)
            save_config(config)
            logger.debug("Enabled skill '%s' in lightclaw.json.", name)
            return True
        except Exception as e:
            logger.error("Failed to enable skill '%s': %s", name, e)
            return False

    @staticmethod
    def delete_skill(name: str) -> bool:
        """
        Delete a skill from the skills/ directory permanently.

        Built-in skills (those present in the source code) can be deleted
        from the working directory; they will not be re-synced automatically.

        Args:
            name: Skill name to delete.

        Returns:
            True if skill was deleted successfully, False otherwise.
        """
        skills_dir = get_skills_dir()
        skill_dir = skills_dir / name

        if not skill_dir.exists():
            logger.debug("Skill '%s' not found in skills/.", name)
            return False

        try:
            shutil.rmtree(skill_dir)
            logger.debug("Deleted skill '%s' from skills/.", name)

            # Remove from config entries
            try:
                from ..config.utils import load_config, save_config

                config = load_config()
                config.skills.entries.pop(name, None)
                save_config(config)
            except Exception as cfg_exc:
                logger.warning(
                    "Deleted skill '%s' but failed to update config: %s",
                    name,
                    cfg_exc,
                )

            return True
        except Exception as e:
            logger.error("Failed to delete skill '%s': %s", name, e)
            return False

    @staticmethod
    def sync_from_active_to_customized(
        skill_names: list[str] | None = None,
    ) -> tuple[int, int]:
        """
        Legacy no-op kept for backward compatibility.

        Deprecated: No longer needed with the unified skills/ directory.
        """
        return sync_skills_from_active_to_customized(skill_names=skill_names)

    @staticmethod
    def load_skill_file(  # pylint: disable=too-many-return-statements
        skill_name: str,
        file_path: str,
        source: str,
    ) -> str | None:
        """
        Load a specific file from a skill's references or scripts directory.

        Args:
            skill_name: Name of the skill.
            file_path: Relative path to the file within the skill directory.
                Must start with "references/" or "scripts/".
                Example: "references/doc.md" or "scripts/utils/helper.py"
            source: Source directory, must be "builtin" or "workspace".
                ``customized`` is accepted as a legacy alias for ``workspace``.

        Returns:
            File content as string, or None if failed.

        Examples:
            # Load from workspace skills
            content = load_skill_file(
                "my_skill",
                "references/doc.md",
                "workspace"
            )

            # Load nested file from builtin
            content = load_skill_file(
                "builtin_skill",
                "scripts/utils/helper.py",
                "builtin"
            )
        """
        # Validate source
        if source not in {"builtin", "workspace", "customized"}:
            logger.error(
                "Invalid source '%s'. Must be 'builtin', 'workspace', or 'customized'.",
                source,
            )
            return None

        # Normalize separators to forward slash for consistent checking
        normalized = file_path.replace("\\", "/")

        # Validate file_path starts with references/ or scripts/
        if not (normalized.startswith("references/") or normalized.startswith("scripts/")):
            logger.error(
                "Invalid file_path '%s'. Must start with 'references/' or 'scripts/'.",
                file_path,
            )
            return None

        # Prevent path traversal attacks
        if ".." in normalized or normalized.startswith("/"):
            logger.error(
                "Invalid file_path '%s': path traversal not allowed",
                file_path,
            )
            return None

        # Get source directory
        # 'workspace' and 'customized' (legacy alias) both use unified skills/
        if source == "builtin":
            base_dir = get_builtin_skills_dir()
        else:  # 'workspace' or 'customized'
            base_dir = get_skills_dir()

        skill_dir = base_dir / skill_name
        full_path = skill_dir / file_path

        # Check if skill exists
        if not skill_dir.exists():
            logger.debug(
                "Skill '%s' not found in %s",
                skill_name,
                source,
            )
            return None

        # Check if file exists
        if not full_path.exists():
            logger.debug(
                "File '%s' not found in skill '%s' (%s)",
                file_path,
                skill_name,
                source,
            )
            return None

        # Check if it's actually a file (not a directory)
        if not full_path.is_file():
            logger.debug(
                "Path '%s' is not a file in skill '%s' (%s)",
                file_path,
                skill_name,
                source,
            )
            return None

        # Read file content
        try:
            content = full_path.read_text(encoding="utf-8")
            logger.debug(
                "Loaded file '%s' from skill '%s' (%s)",
                file_path,
                skill_name,
                source,
            )
            return content
        except Exception as e:
            logger.error(
                "Failed to read file '%s' from skill '%s': %s",
                file_path,
                skill_name,
                e,
            )
            return None
