"""
Agent tools schema: type definitions for agent tool responses.
"""

from typing import Literal, Required

from typing_extensions import TypedDict


class URLSource(TypedDict):
    """URL source for media blocks."""

    type: Literal["url"]
    url: str


class Base64Source(TypedDict):
    """Base64 source for media blocks."""

    type: Literal["base64"]
    media_type: str
    data: str


class FileBlock(TypedDict, total=False):
    """File block for sending files to users."""

    type: Required[Literal["file"]]
    """The type of the block"""

    source: Required[Base64Source | URLSource]
    """The source of the file"""

    filename: str | None
    """The filename of the file"""
