"""将本地文件路径转换为可供前端预览和 LLM 消费的 URL。

``build_local_media_urls`` 是 ``send_file`` 和 ``desktop_screenshot``
等工具的公共辅助函数。
"""

from __future__ import annotations

import hashlib
import hmac
import mimetypes
import os
import time
from pathlib import Path
from urllib.parse import quote

from ...app.core import auth as auth_mod
from ...app.file_store import file_payload, store_local_file
from ...constant import WORKING_DIR


def build_workspace_image_url(
    rel_path: str,
    *,
    ttl_seconds: int = 24 * 60 * 60,
) -> str:
    """Build a signed access URL for workspace images.

    Args:
        rel_path: Relative path within workspace (e.g. "output/image.jpg")
        ttl_seconds: Token time-to-live in seconds

    Returns:
        Signed URL like "/api/workspace/image?path=output/image.jpg&exp=...&sig=..."
        If auth is disabled, returns unsigned URL.
    """
    base_url = f"/api/workspace/image?path={quote(rel_path, safe='')}"

    auth = auth_mod._read_auth()
    if not auth.enabled:
        return base_url

    # Add signature for authenticated endpoints
    now_ts = int(time.time())
    exp = now_ts + max(1, int(ttl_seconds))

    # Build signature using the same method as file_store.py
    secret = auth_mod._ensure_jwt_secret(auth)
    msg = f"{rel_path}:{int(exp)}".encode()
    sig = hmac.new(secret.encode("utf-8"), msg, hashlib.sha256).hexdigest()

    return f"{base_url}&exp={exp}&sig={sig}"


def build_local_media_urls(
    file_path: str,
) -> tuple[dict, str | None, str | None]:
    """将本地文件路径转换为 source dict 和可选的 preview_url。

    Args:
        file_path: 本地文件的绝对路径。

    Returns:
        一个元组 ``(source, preview_url, file_id)``：

        - ``source`` — 符合 content block 规范的 dict，例如
          ``{"type": "url", "url": "file:///tmp/shot.png"}``。用作 LLM 侧消费。
        - ``preview_url`` — 如果文件在 workspace 目录内，返回带签名的 /api/workspace/image URL；
          否则尝试拷贝到 uploads 目录生成签名 URL；失败时为 ``None``。
        - ``file_id`` — uploads 内部稳定文件标识（仅当文件拷贝到 uploads 时）；否则为 ``None``。
    """
    # 构建 file:// 形式的 source，供 LLM 侧消费
    abs_path = os.path.abspath(file_path)
    file_uri = Path(abs_path).as_uri()  # file:///...

    media_type = mimetypes.guess_type(abs_path)[0] or "application/octet-stream"

    source: dict = {
        "type": "url",
        "url": file_uri,
        "media_type": media_type,
    }

    # 检查文件是否在 workspace 目录内
    try:
        target_resolve = Path(abs_path).resolve()
        working_dir_resolve = Path(WORKING_DIR).resolve()
        if str(target_resolve).startswith(str(working_dir_resolve)):
            # 文件在 workspace 内，直接用带签名的 /api/workspace/image URL
            rel_path = target_resolve.relative_to(working_dir_resolve).as_posix()
            preview_url = build_workspace_image_url(rel_path)
            file_id = None  # workspace 文件不需要 file_id
            return source, preview_url, file_id
    except (ValueError, OSError):
        # 路径解析失败，继续尝试拷贝到 uploads
        pass

    # 尝试拷贝到 UPLOADS_DIR，生成 /api/files/... 的预览 URL
    preview_url: str | None = None
    file_id: str | None = None
    try:
        metadata = store_local_file(
            abs_path,
            filename=os.path.basename(abs_path),
            media_type=media_type,
        )
        payload = file_payload(metadata)
        preview_url = str(payload["access_url"])
        file_id = str(payload["file_id"])
    except Exception:
        preview_url = None
        file_id = None

    return source, preview_url, file_id
