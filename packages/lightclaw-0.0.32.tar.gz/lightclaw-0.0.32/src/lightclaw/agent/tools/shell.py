# pylint: disable=line-too-long
"""The shell command tool.

Commands are always executed in non-interactive mode so the agent never hangs
waiting for terminal input that it cannot provide.
"""

import asyncio
import locale
import os
import re
from pathlib import Path

from lightclaw.constant import WORKING_DIR

from .result import LightClawToolResult, data_block, text_block

_INTERACTIVE_OUTPUT_PATTERNS = (
    re.compile(r"password", re.IGNORECASE),
    re.compile(r"passphrase", re.IGNORECASE),
    re.compile(r"username", re.IGNORECASE),
    re.compile(r"verification code", re.IGNORECASE),
    re.compile(r"one-time password", re.IGNORECASE),
    re.compile(r"\botp\b", re.IGNORECASE),
    re.compile(r"terminal prompts disabled", re.IGNORECASE),
    re.compile(r"could not read (?:username|password)", re.IGNORECASE),
    re.compile(r"no tty present", re.IGNORECASE),
    re.compile(r"requires a tty", re.IGNORECASE),
    re.compile(r"press (?:enter|return) to continue", re.IGNORECASE),
    re.compile(r"are you sure you want to continue connecting", re.IGNORECASE),
    re.compile(r"\(yes/no(?:/\[fingerprint\])?\)", re.IGNORECASE),
    re.compile(r"eof when reading a line", re.IGNORECASE),
)

_AUTONOMY_BLOCKED_MESSAGE = (
    "Command could not be completed autonomously because it requires "
    "interactive terminal input or confirmation. LightClaw runs shell "
    "commands in non-interactive mode and cannot type passwords, MFA codes, "
    "yes/no confirmations, or editor input."
)

SHELL_ERROR_CODE_INTERACTIVE_BLOCKED = "shell_interactive_blocked"
SHELL_ERROR_CODE_TIMEOUT = "shell_timeout"


def _decode_output(data: bytes | None, *, encoding: str) -> str:
    if not data:
        return ""
    return data.decode(encoding, errors="replace").strip("\n")


def _build_non_interactive_env() -> dict[str, str]:
    env = os.environ.copy()
    env["GIT_TERMINAL_PROMPT"] = "0"
    env["GCM_INTERACTIVE"] = "never"
    env.setdefault("GIT_PAGER", "cat")
    env.setdefault("PAGER", "cat")
    return env


def _looks_like_interactive_block(stdout_str: str, stderr_str: str) -> bool:
    combined = "\n".join(part for part in (stdout_str, stderr_str) if part).strip()
    if not combined:
        return False
    return any(pattern.search(combined) for pattern in _INTERACTIVE_OUTPUT_PATTERNS)


def _format_response(
    *,
    returncode: int,
    stdout_str: str,
    stderr_str: str,
    autonomy_blocked: bool = False,
) -> str:
    if returncode == 0:
        if stdout_str:
            return stdout_str
        return "Command executed successfully (no output)."

    response_parts: list[str] = []
    if autonomy_blocked:
        response_parts.append(_AUTONOMY_BLOCKED_MESSAGE)
        response_parts.append("\n")

    response_parts.append(f"Command failed with exit code {returncode}.")
    if stdout_str:
        response_parts.append(f"\n[stdout]\n{stdout_str}")
    if stderr_str:
        response_parts.append(f"\n[stderr]\n{stderr_str}")
    return "".join(response_parts)


def _build_error_result(
    *,
    text: str,
    error_code: str,
    returncode: int,
) -> LightClawToolResult:
    return LightClawToolResult(
        content=[
            text_block(text),
            data_block(
                {
                    "error_code": error_code,
                    "returncode": returncode,
                }
            ),
        ]
    )


# pylint: disable=too-many-branches
async def execute_shell_command(
    command: str,
    timeout: int = 60,
    cwd: Path | None = None,
) -> LightClawToolResult:
    """Execute given command and return the return code, standard output and
    error within <returncode></returncode>, <stdout></stdout> and
    <stderr></stderr> tags.

    Args:
        command (`str`):
            The shell command to execute.
        timeout (`int`, defaults to `10`):
            The maximum time (in seconds) allowed for the command to run.
            Default is 60 seconds.
        cwd (`Optional[Path]`, defaults to `None`):
            The working directory for the command execution.
            If None, defaults to WORKING_DIR.

    Returns:
        `LightClawToolResult`:
            The tool response containing the return code, standard output, and
            standard error of the executed command. If timeout occurs, the
            return code will be -1 and stderr will contain timeout information.
    """

    cmd = (command or "").strip()

    # Set working directory
    working_dir = cwd if cwd is not None else WORKING_DIR

    try:
        subprocess_kwargs = {
            "stdout": asyncio.subprocess.PIPE,
            "stderr": asyncio.subprocess.PIPE,
            "stdin": asyncio.subprocess.DEVNULL,
            "bufsize": 0,
            "cwd": str(working_dir),
            "env": _build_non_interactive_env(),
        }
        if os.name != "nt":
            subprocess_kwargs["start_new_session"] = True

        proc = await asyncio.create_subprocess_shell(
            cmd,
            **subprocess_kwargs,
        )

        encoding = locale.getpreferredencoding(False) or "utf-8"
        try:
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(),
                timeout=timeout,
            )
            stdout_str = _decode_output(stdout, encoding=encoding)
            stderr_str = _decode_output(stderr, encoding=encoding)
            returncode = proc.returncode

        except TimeoutError:
            stderr_suffix = (
                f"⚠️ TimeoutError: The command execution exceeded the timeout "
                f"of {timeout} seconds. This command may be long-running, or "
                f"it may be waiting for terminal input that LightClaw cannot "
                f"provide."
            )
            returncode = -1
            try:
                proc.terminate()
                try:
                    await asyncio.wait_for(proc.wait(), timeout=1)
                except TimeoutError:
                    proc.kill()
                    await proc.wait()

                stdout, stderr = await proc.communicate()
                stdout_str = _decode_output(stdout, encoding=encoding)
                stderr_str = _decode_output(stderr, encoding=encoding)
                if stderr_str:
                    stderr_str += f"\n{stderr_suffix}"
                else:
                    stderr_str = stderr_suffix
            except ProcessLookupError:
                stdout_str = ""
                stderr_str = stderr_suffix

        response_text = _format_response(
            returncode=returncode,
            stdout_str=stdout_str,
            stderr_str=stderr_str,
            autonomy_blocked=(returncode != 0 and _looks_like_interactive_block(stdout_str, stderr_str)),
        )

        if returncode != 0:
            if _looks_like_interactive_block(stdout_str, stderr_str):
                return _build_error_result(
                    text=response_text,
                    error_code=SHELL_ERROR_CODE_INTERACTIVE_BLOCKED,
                    returncode=returncode,
                )
            if returncode == -1:
                return _build_error_result(
                    text=response_text,
                    error_code=SHELL_ERROR_CODE_TIMEOUT,
                    returncode=returncode,
                )

        return LightClawToolResult(text=response_text)

    except Exception as e:
        return LightClawToolResult(
            text=f"Error: Shell command execution failed due to \n{e}",
        )
