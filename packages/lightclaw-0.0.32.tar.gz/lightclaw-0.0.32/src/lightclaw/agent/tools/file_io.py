# pylint: disable=line-too-long
from __future__ import annotations

import logging
import os
from pathlib import Path

from ...constant import MEMORY_DIR, MEMORY_MAX_FILE_SIZE, MEMORY_MAX_FILES, WORKING_DIR
from .result import LightClawToolResult

logger = logging.getLogger(__name__)


def _resolve_file_path(file_path: str) -> str:
    """Resolve file path: use absolute path as-is,
    resolve relative path from WORKING_DIR.

    Args:
        file_path: The input file path (absolute or relative).

    Returns:
        The resolved absolute file path as string.
    """
    path = Path(file_path)
    if path.is_absolute():
        return str(path)
    else:
        return str(WORKING_DIR / file_path)


def _redirect_memory_file(file_path: str) -> str:
    """Redirect .md files written to workspace root into memory/ directory.

    Agent-created knowledge files (e.g. topic notes, archives) should live
    under ``memory/`` so they are indexed by the vector search layer on
    startup.  System prompt files (AGENTS.md, SOUL.md, USER.md, IDENTITY.md,
    MEMORY.md, HEARTBEAT.md, TOOLS.md, BOOTSTRAP.md, PROACTIVE.md,
    PROACTIVITY_ANALYSIS.md) are exempt and stay in workspace root.
    """
    resolved = Path(file_path).resolve()
    working = WORKING_DIR.resolve()

    # Only applies to .md files directly in workspace root
    if not str(resolved).endswith(".md"):
        return file_path
    try:
        resolved.relative_to(working)
    except ValueError:
        return file_path  # Outside workspace — leave as-is

    if resolved.parent != working:
        return file_path  # Already in a subdirectory

    # Exempt system-level prompt files
    exempt_names = {
        "AGENTS.md",
        "SOUL.md",
        "USER.md",
        "IDENTITY.md",
        "MEMORY.md",
        "HEARTBEAT.md",
        "TOOLS.md",
        "BOOTSTRAP.md",
        "PROACTIVE.md",
        "PROACTIVITY_ANALYSIS.md",
    }
    if resolved.name in exempt_names:
        return file_path

    # Redirect into memory/
    new_path = str(MEMORY_DIR / resolved.name)
    logger.info("Redirecting memory file: %s → %s", file_path, new_path)
    return new_path


def _check_memory_limits(file_path: str, content: str) -> str | None:
    """Validate memory directory file count and individual file size.

    Returns an error message string if a limit is exceeded, else None.
    """
    resolved = Path(file_path).resolve()
    memory_dir = MEMORY_DIR.resolve()

    # Only enforce for files inside memory/
    try:
        resolved.relative_to(memory_dir)
    except ValueError:
        return None

    # Check single file size
    if len(content.encode("utf-8")) > MEMORY_MAX_FILE_SIZE:
        return (
            f"Error: File size ({len(content.encode('utf-8'))} bytes) exceeds "
            f"the memory file limit ({MEMORY_MAX_FILE_SIZE} bytes). "
            f"Consider splitting into multiple files or distilling into MEMORY.md."
        )

    # Check total file count (only for new files)
    if not resolved.exists():
        existing = list(memory_dir.glob("*.md")) if memory_dir.exists() else []
        if len(existing) >= MEMORY_MAX_FILES:
            return (
                f"Error: Memory directory already contains {len(existing)} files "
                f"(limit: {MEMORY_MAX_FILES}). Please consolidate old files into "
                f"MEMORY.md or delete outdated ones with memory_forget before "
                f"creating new memory files."
            )

    return None


async def read_file(  # pylint: disable=too-many-return-statements
    file_path: str,
    start_line: int | None = None,
    end_line: int | None = None,
) -> LightClawToolResult:
    """Read a file. Relative paths resolve from WORKING_DIR.

    Use start_line/end_line to read a specific line range (output includes
    line numbers). Omit both to read the full file.

    Args:
        file_path (`str`):
            Path to the file.
        start_line (`int`, optional):
            First line to read (1-based, inclusive).
        end_line (`int`, optional):
            Last line to read (1-based, inclusive).
    """

    file_path = _resolve_file_path(file_path)

    if not os.path.exists(file_path):
        return LightClawToolResult(text=f"Error: The file {file_path} does not exist.")

    if not os.path.isfile(file_path):
        return LightClawToolResult(text=f"Error: The path {file_path} is not a file.")

    try:
        with open(file_path, encoding="utf-8") as f:
            all_lines = f.readlines()

        range_requested = start_line is not None or end_line is not None

        if range_requested:
            total = len(all_lines)
            s = max(1, start_line if start_line is not None else 1)
            e = min(total, end_line if end_line is not None else total)

            if s > total:
                return LightClawToolResult(
                    text=(f"Error: start_line {s} exceeds file length ({total} lines) in {file_path}."),
                )

            if s > e:
                return LightClawToolResult(
                    text=(f"Error: start_line ({s}) is greater than end_line ({e}) in {file_path}."),
                )

            selected = all_lines[s - 1 : e]
            content = "".join(selected)
            header = f"{file_path}  (lines {s}-{e} of {total})\n"
            return LightClawToolResult(text=header + content)
        else:
            content = "".join(all_lines)
            return LightClawToolResult(text=content)

    except Exception as e:
        return LightClawToolResult(text=f"Error: Read file failed due to \n{e}")


async def write_file(
    file_path: str,
    content: str,
) -> LightClawToolResult:
    """Create or overwrite a file. Relative paths resolve from WORKING_DIR.

    Memory-type .md files in the workspace root are automatically redirected
    to the ``memory/`` directory for proper indexing.

    Args:
        file_path (`str`):
            Path to the file.
        content (`str`):
            Content to write.
    """

    if not file_path:
        return LightClawToolResult(text="Error: No `file_path` provide.")

    file_path = _resolve_file_path(file_path)
    file_path = _redirect_memory_file(file_path)

    # Enforce memory directory limits
    limit_error = _check_memory_limits(file_path, content)
    if limit_error:
        return LightClawToolResult(text=limit_error)

    try:
        # Ensure parent directory exists
        Path(file_path).parent.mkdir(parents=True, exist_ok=True)
        with open(file_path, "w", encoding="utf-8") as file:
            file.write(content)
        return LightClawToolResult(text=f"Wrote {len(content)} bytes to {file_path}.")
    except Exception as e:
        return LightClawToolResult(text=f"Error: Write file failed due to \n{e}")


async def edit_file(
    file_path: str,
    old_text: str,
    new_text: str,
) -> LightClawToolResult:
    """Find-and-replace text in a file. All occurrences of old_text are
    replaced with new_text. Relative paths resolve from WORKING_DIR.

    Args:
        file_path (`str`):
            Path to the file.
        old_text (`str`):
            Exact text to find.
        new_text (`str`):
            Replacement text.
    """

    response = await read_file(file_path=file_path)
    if response.content and len(response.content) > 0:
        error_text = response.content[0].get("text", "")
        if error_text.startswith("Error:"):
            return response
    if not response.content or len(response.content) == 0:
        return LightClawToolResult(text=f"Error: Failed to read file {file_path}.")

    content = response.content[0].get("text", "")
    if old_text not in content:
        return LightClawToolResult(
            text=f"Error: The text to replace was not found in {file_path}.",
        )

    new_content = content.replace(old_text, new_text)
    write_response = await write_file(file_path=file_path, content=new_content)

    if write_response.content and len(write_response.content) > 0:
        write_text = write_response.content[0].get("text", "")
        if write_text.startswith("Error:"):
            return write_response

    return LightClawToolResult(text=f"Successfully replaced text in {file_path}.")


async def append_file(
    file_path: str,
    content: str,
) -> LightClawToolResult:
    """Append content to the end of a file. Relative paths resolve from
    WORKING_DIR. Memory-type .md files are redirected like ``write_file``.

    Args:
        file_path (`str`):
            Path to the file.
        content (`str`):
            Content to append.
    """

    if not file_path:
        return LightClawToolResult(text="Error: No `file_path` provide.")

    file_path = _resolve_file_path(file_path)
    file_path = _redirect_memory_file(file_path)

    try:
        Path(file_path).parent.mkdir(parents=True, exist_ok=True)
        with open(file_path, "a", encoding="utf-8") as file:
            file.write(content)
        return LightClawToolResult(text=f"Appended {len(content)} bytes to {file_path}.")
    except Exception as e:
        return LightClawToolResult(text=f"Error: Append file failed due to \n{e}")
