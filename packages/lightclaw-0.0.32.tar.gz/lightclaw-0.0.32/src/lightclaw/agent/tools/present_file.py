# pylint: disable=line-too-long,too-many-return-statements
import mimetypes
import os

from .media_output import build_local_media_urls
from .result import (
    LightClawToolResult,
    audio_block,
    file_block,
    image_block,
    text_block,
    video_block,
)


def _auto_as_type(mt: str) -> str:
    if mt.startswith("image/"):
        return "image"
    if mt.startswith("audio/"):
        return "audio"
    if mt.startswith("video/"):
        return "video"
    return "file"


async def present_file(
    file_path: str,
) -> LightClawToolResult:
    """Present a file to the user by generating a previewable URL or inline content.

    For images, audio, and video files this returns a signed preview URL that
    renders inline in the chat window. For other file types it returns a
    download link. The file must already exist on disk.

    Args:
        file_path (`str`):
            Absolute or relative path to the file to present.

    Returns:
        `LightClawToolResult`:
            Structured result with media block + preview_url, or an error message.
    """

    if not os.path.exists(file_path):
        return LightClawToolResult(text=f"Error: The file {file_path} does not exist.")

    if not os.path.isfile(file_path):
        return LightClawToolResult(text=f"Error: The path {file_path} is not a file.")

    # Detect MIME type
    mime_type, _ = mimetypes.guess_type(file_path)
    if mime_type is None:
        mime_type = "application/octet-stream"
    as_type = _auto_as_type(mime_type)

    try:
        # Plain text files: return content directly
        if as_type == "text":
            with open(file_path, encoding="utf-8") as file:
                return LightClawToolResult(text=file.read())

        source, preview_url, file_id = build_local_media_urls(file_path)
        filename = os.path.basename(file_path)
        text_msg = f"file: {filename}\npreview_url: {preview_url}" if preview_url else f"file: {filename}"

        if as_type == "image":
            block = image_block(source)
            block["filename"] = filename
            if preview_url:
                block["preview_url"] = preview_url
            if file_id:
                block["file_id"] = file_id
            return LightClawToolResult(content=[block, text_block(text_msg)])

        if as_type == "audio":
            block = audio_block(source)
            block["filename"] = filename
            if preview_url:
                block["preview_url"] = preview_url
            if file_id:
                block["file_id"] = file_id
            return LightClawToolResult(content=[block, text_block(text_msg)])

        if as_type == "video":
            block = video_block(source)
            block["filename"] = filename
            if preview_url:
                block["preview_url"] = preview_url
            if file_id:
                block["file_id"] = file_id
            return LightClawToolResult(content=[block, text_block(text_msg)])

        # Generic file
        block = file_block(source, filename=filename)
        if preview_url:
            block["preview_url"] = preview_url
        if file_id:
            block["file_id"] = file_id
        return LightClawToolResult(content=[block, text_block(text_msg)])

    except Exception as e:
        return LightClawToolResult(text=f"Error: present_file failed: {e}")
