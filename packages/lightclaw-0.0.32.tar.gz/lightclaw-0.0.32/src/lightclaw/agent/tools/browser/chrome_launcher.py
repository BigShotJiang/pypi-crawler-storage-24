"""Native Chrome process launcher and CDP connection manager.

Manages the lifecycle of Chrome processes launched via ``subprocess.Popen``
with ``--user-data-dir`` and ``--remote-debugging-port``, and provides
Playwright CDP attachment via ``chromium.connect_over_cdp()``.

Ported from openclaw/src/browser/chrome.ts (launchOpenClawChrome,
stopOpenClawChrome) and pw-session.ts (connectBrowser).
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import os
import signal
import subprocess
import time
from dataclasses import dataclass
from typing import Any

import httpx

from .environment import (
    build_chrome_flags,
    detect_display_environment,
    find_chrome_executable,
)
from .profiles import BrowserProfile

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Data types
# ---------------------------------------------------------------------------


@dataclass
class RunningChrome:
    """Represents a live Chrome process managed by the launcher."""

    profile_name: str
    process: subprocess.Popen[bytes] | None = None
    cdp_port: int = 18800
    pid: int | None = None
    xvfb_process: subprocess.Popen[bytes] | None = None


@dataclass
class CDPConnection:
    """Holds the Playwright objects attached to a Chrome via CDP."""

    playwright: Any = None  # playwright async_api Playwright instance
    browser: Any = None  # playwright Browser
    context: Any = None  # playwright BrowserContext


# ---------------------------------------------------------------------------
# Chrome process manager (singleton)
# ---------------------------------------------------------------------------


class ChromeProcessManager:
    """Manage Chrome process lifecycles across profiles.

    One Chrome process per profile; tracks ``{profile_name: RunningChrome}``.
    """

    def __init__(self) -> None:
        self._processes: dict[str, RunningChrome] = {}

    # -- launch -------------------------------------------------------------

    async def launch_chrome(
        self,
        profile: BrowserProfile,
        *,
        headed: bool = False,
        enable_xvfb: bool = False,
        explicit_executable: str | None = None,
    ) -> RunningChrome:
        """Launch a native Chrome process for *profile*.

        Args:
            profile: The browser profile configuration.
            headed: Whether to launch a visible window.
            enable_xvfb: Start Xvfb if on headless-server and *headed* is
                requested.
            explicit_executable: Override auto-detected executable path.

        Returns:
            A :class:`RunningChrome` handle.

        Raises:
            RuntimeError: If Chrome cannot be started.
        """
        # Already running?
        existing = self._processes.get(profile.name)
        if existing and existing.process and existing.process.poll() is None:
            logger.info(
                "Chrome for profile '%s' already running (pid=%s)",
                profile.name,
                existing.pid,
            )
            return existing

        env = detect_display_environment()
        exe = find_chrome_executable(explicit_executable)
        if not exe:
            raise RuntimeError(
                "No Chrome/Chromium executable found. Install Google Chrome or set an explicit path.",
            )

        xvfb_proc: subprocess.Popen[bytes] | None = None

        # Handle headed request on headless-server
        if headed and env == "headless-server":
            if enable_xvfb:
                xvfb_proc = _start_xvfb()
                if xvfb_proc:
                    logger.info("Started Xvfb for headed mode on headless-server")
                    # Chrome will use the virtual display
                else:
                    logger.warning(
                        "Xvfb start failed; falling back to headless mode",
                    )
                    headed = False
            else:
                logger.warning(
                    "headed=True requested on headless-server without Xvfb — auto-falling back to headless mode",
                )
                headed = False

        headless = not headed
        flags = build_chrome_flags(
            headless=headless,
            environment=env,
            cdp_port=profile.cdp_port,
            user_data_dir=profile.user_data_dir,
        )

        cmd = [exe.path, *flags, "about:blank"]
        logger.info(
            "Launching Chrome: %s (port=%d, headless=%s)",
            exe.path,
            profile.cdp_port,
            headless,
        )

        try:
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
                preexec_fn=os.setpgrp if os.name != "nt" else None,
            )
        except FileNotFoundError as exc:
            raise RuntimeError(
                f"Failed to start Chrome at {exe.path}: {exc}",
            ) from exc

        running = RunningChrome(
            profile_name=profile.name,
            process=proc,
            cdp_port=profile.cdp_port,
            pid=proc.pid,
            xvfb_process=xvfb_proc,
        )
        self._processes[profile.name] = running

        # Wait for CDP to become ready
        ready = await _wait_for_cdp(profile.cdp_port, timeout=15.0)
        if not ready:
            # Check if process died
            if proc.poll() is not None:
                stderr_output = ""
                with contextlib.suppress(Exception):
                    stderr_output = (proc.stderr.read() or b"").decode(
                        errors="replace",
                    )[:500]
                self._processes.pop(profile.name, None)
                raise RuntimeError(
                    f"Chrome exited immediately (code={proc.returncode}). stderr: {stderr_output}",
                )
            self._processes.pop(profile.name, None)
            _kill_process(proc)
            raise RuntimeError(
                f"Chrome CDP not ready on port {profile.cdp_port} after 15s",
            )

        logger.info(
            "Chrome ready for profile '%s' (pid=%d, port=%d)",
            profile.name,
            proc.pid,
            profile.cdp_port,
        )
        return running

    # -- stop ---------------------------------------------------------------

    async def stop_chrome(self, profile_name: str) -> None:
        """Stop the Chrome process for *profile_name*."""
        running = self._processes.pop(profile_name, None)
        if not running:
            return
        if running.process and running.process.poll() is None:
            _kill_process(running.process)
            logger.info("Stopped Chrome for profile '%s'", profile_name)
        if running.xvfb_process and running.xvfb_process.poll() is None:
            _kill_process(running.xvfb_process)
            logger.info("Stopped Xvfb for profile '%s'", profile_name)

    # -- health check -------------------------------------------------------

    def is_running(self, profile_name: str) -> bool:
        """Check if Chrome process for *profile_name* is alive."""
        running = self._processes.get(profile_name)
        if not running or not running.process:
            return False
        return running.process.poll() is None

    def get_running(self, profile_name: str) -> RunningChrome | None:
        return self._processes.get(profile_name)

    # -- cleanup ------------------------------------------------------------

    async def stop_all(self) -> None:
        """Stop all managed Chrome processes."""
        names = list(self._processes.keys())
        for name in names:
            await self.stop_chrome(name)


# ---------------------------------------------------------------------------
# CDP connection via Playwright
# ---------------------------------------------------------------------------


async def connect_via_cdp(cdp_port: int) -> CDPConnection:
    """Attach to a running Chrome via CDP using Playwright.

    Args:
        cdp_port: The Chrome DevTools Protocol port.

    Returns:
        A :class:`CDPConnection` with ``playwright``, ``browser``, and
        ``context`` objects.
    """
    from playwright.async_api import async_playwright

    pw = await async_playwright().start()
    endpoint = f"http://127.0.0.1:{cdp_port}"
    browser = await pw.chromium.connect_over_cdp(endpoint)

    # Use first existing context or create a new one
    contexts = browser.contexts
    if contexts:
        context = contexts[0]
    else:
        context = await browser.new_context()

    return CDPConnection(
        playwright=pw,
        browser=browser,
        context=context,
    )


async def disconnect_cdp(conn: CDPConnection) -> None:
    """Gracefully disconnect a CDP connection (keep Chrome running)."""
    try:
        if conn.browser:
            await conn.browser.close()
    except Exception as exc:
        logger.debug("Error closing CDP browser: %s", exc)
    try:
        if conn.playwright:
            await conn.playwright.stop()
    except Exception as exc:
        logger.debug("Error stopping Playwright: %s", exc)


# ---------------------------------------------------------------------------
# Fallback: Playwright-managed Chromium
# ---------------------------------------------------------------------------


async def launch_playwright_fallback(
    headless: bool = True,
) -> CDPConnection:
    """Launch Playwright's bundled Chromium as a fallback.

    This does NOT use a persistent user-data-dir, so login state will be
    lost on stop.
    """
    from playwright.async_api import async_playwright

    logger.warning(
        "No native Chrome found — using Playwright Chromium. Login state will NOT persist across sessions.",
    )
    pw = await async_playwright().start()
    browser = await pw.chromium.launch(headless=headless)
    context = await browser.new_context()
    return CDPConnection(
        playwright=pw,
        browser=browser,
        context=context,
    )


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _kill_process(proc: subprocess.Popen[bytes]) -> None:
    """Gracefully kill a process (SIGTERM then SIGKILL)."""
    try:
        if os.name != "nt":
            os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
        else:
            proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            if os.name != "nt":
                os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
            else:
                proc.kill()
            proc.wait(timeout=3)
    except (ProcessLookupError, OSError):
        pass


async def _wait_for_cdp(port: int, timeout: float = 15.0) -> bool:
    """Poll ``http://127.0.0.1:{port}/json/version`` until it responds."""
    url = f"http://127.0.0.1:{port}/json/version"
    deadline = time.monotonic() + timeout
    async with httpx.AsyncClient() as client:
        while time.monotonic() < deadline:
            try:
                resp = await client.get(url, timeout=2.0)
                if resp.status_code == 200:
                    return True
            except (httpx.ConnectError, httpx.ReadTimeout, httpx.ConnectTimeout):
                pass
            await asyncio.sleep(0.5)
    return False


def _start_xvfb(display: str = ":99") -> subprocess.Popen[bytes] | None:
    """Start an Xvfb virtual display server.

    Returns the Popen handle, or ``None`` if Xvfb is not available.
    """
    import shutil as _shutil

    xvfb_path = _shutil.which("Xvfb")
    if not xvfb_path:
        logger.warning("Xvfb not found in PATH")
        return None

    try:
        proc = subprocess.Popen(
            [
                xvfb_path,
                display,
                "-screen",
                "0",
                "1280x800x24",
                "-ac",
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        # Set DISPLAY for child processes
        os.environ["DISPLAY"] = display
        # Brief pause for Xvfb to initialise
        time.sleep(0.5)
        if proc.poll() is not None:
            logger.warning("Xvfb exited immediately (code=%s)", proc.returncode)
            return None
        return proc
    except FileNotFoundError:
        logger.warning("Xvfb binary not found")
        return None
