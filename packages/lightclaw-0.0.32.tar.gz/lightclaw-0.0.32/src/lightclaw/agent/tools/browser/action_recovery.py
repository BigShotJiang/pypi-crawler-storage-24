"""Post-action verification, failure classification, and recovery orchestrator.

Implements requirement 5: action confirmation, failure recovery, and
recovery strategy orchestration.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

logger = logging.getLogger(__name__)

# Maximum recovery attempts before escalating
MAX_RECOVERY_ATTEMPTS = 3


class FailureCategory(StrEnum):
    """Classification of action failure reasons."""

    ELEMENT_MISSING = "element_missing"
    ELEMENT_NOT_INTERACTABLE = "element_not_interactable"
    TIMEOUT = "timeout"
    PAGE_BLOCKED = "page_blocked"
    STATE_UNCHANGED = "state_unchanged"
    NAVIGATION_FAILED = "navigation_failed"
    SCRIPT_ERROR = "script_error"
    UNKNOWN = "unknown"


class RecoveryStrategy(StrEnum):
    """Ordered recovery strategies."""

    WAIT_AND_RETRY = "wait_and_retry"
    RELOCATE_ELEMENT = "relocate_element"
    DISMISS_BLOCKER = "dismiss_blocker"
    REFRESH_PAGE = "refresh_page"
    REQUEST_HANDOFF = "request_handoff"
    ABORT = "abort"


class VerificationResult(StrEnum):
    """Result of post-action verification."""

    SUCCESS = "success"
    PARTIAL = "partial"
    FAILED = "failed"
    SKIPPED = "skipped"


# Strategy chain per failure category
_RECOVERY_CHAIN: dict[FailureCategory, list[RecoveryStrategy]] = {
    FailureCategory.ELEMENT_MISSING: [
        RecoveryStrategy.WAIT_AND_RETRY,
        RecoveryStrategy.RELOCATE_ELEMENT,
        RecoveryStrategy.REFRESH_PAGE,
        RecoveryStrategy.REQUEST_HANDOFF,
    ],
    FailureCategory.ELEMENT_NOT_INTERACTABLE: [
        RecoveryStrategy.WAIT_AND_RETRY,
        RecoveryStrategy.DISMISS_BLOCKER,
        RecoveryStrategy.RELOCATE_ELEMENT,
        RecoveryStrategy.REQUEST_HANDOFF,
    ],
    FailureCategory.TIMEOUT: [
        RecoveryStrategy.WAIT_AND_RETRY,
        RecoveryStrategy.REFRESH_PAGE,
        RecoveryStrategy.REQUEST_HANDOFF,
    ],
    FailureCategory.PAGE_BLOCKED: [
        RecoveryStrategy.DISMISS_BLOCKER,
        RecoveryStrategy.WAIT_AND_RETRY,
        RecoveryStrategy.REQUEST_HANDOFF,
    ],
    FailureCategory.STATE_UNCHANGED: [
        RecoveryStrategy.WAIT_AND_RETRY,
        RecoveryStrategy.RELOCATE_ELEMENT,
        RecoveryStrategy.REFRESH_PAGE,
        RecoveryStrategy.ABORT,
    ],
    FailureCategory.NAVIGATION_FAILED: [
        RecoveryStrategy.WAIT_AND_RETRY,
        RecoveryStrategy.REFRESH_PAGE,
        RecoveryStrategy.ABORT,
    ],
    FailureCategory.SCRIPT_ERROR: [
        RecoveryStrategy.WAIT_AND_RETRY,
        RecoveryStrategy.ABORT,
    ],
    FailureCategory.UNKNOWN: [
        RecoveryStrategy.WAIT_AND_RETRY,
        RecoveryStrategy.REFRESH_PAGE,
        RecoveryStrategy.REQUEST_HANDOFF,
    ],
}


@dataclass(slots=True)
class ActionVerification:
    """Result of verifying a browser action's outcome."""

    action: str
    page_id: str
    result: VerificationResult = VerificationResult.SKIPPED
    url_changed: bool = False
    title_changed: bool = False
    snapshot_changed: bool = False
    expected_element_found: bool = False
    detail: str = ""
    verified_at: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        return {
            "action": self.action,
            "page_id": self.page_id,
            "result": self.result.value,
            "url_changed": self.url_changed,
            "title_changed": self.title_changed,
            "snapshot_changed": self.snapshot_changed,
            "expected_element_found": self.expected_element_found,
            "detail": self.detail,
            "verified_at": self.verified_at,
        }


@dataclass(slots=True)
class FailureClassification:
    """Classified failure with category and recovery chain."""

    category: FailureCategory
    error_message: str = ""
    action: str = ""
    page_id: str = ""
    recovery_chain: list[RecoveryStrategy] = field(default_factory=list)
    classified_at: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        return {
            "category": self.category.value,
            "error_message": self.error_message,
            "action": self.action,
            "page_id": self.page_id,
            "recovery_chain": [s.value for s in self.recovery_chain],
            "classified_at": self.classified_at,
        }


@dataclass(slots=True)
class RecoveryAttempt:
    """Record of a single recovery attempt."""

    strategy: RecoveryStrategy
    success: bool = False
    detail: str = ""
    attempted_at: float = field(default_factory=time.time)


@dataclass(slots=True)
class RecoveryResult:
    """Aggregate result of the recovery process."""

    recovered: bool = False
    attempts: list[RecoveryAttempt] = field(default_factory=list)
    final_strategy: RecoveryStrategy = RecoveryStrategy.ABORT
    escalated: bool = False
    detail: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "recovered": self.recovered,
            "attempts": [
                {"strategy": a.strategy.value, "success": a.success, "detail": a.detail} for a in self.attempts
            ],
            "final_strategy": self.final_strategy.value,
            "escalated": self.escalated,
            "detail": self.detail,
        }


# ---------------------------------------------------------------------------
# Failure classification
# ---------------------------------------------------------------------------

# Error message patterns for classification
_CLASSIFICATION_PATTERNS: dict[FailureCategory, list[str]] = {
    FailureCategory.ELEMENT_MISSING: [
        "not found",
        "no such element",
        "unknown ref",
        "locator resolved to",
        "waiting for locator",
    ],
    FailureCategory.ELEMENT_NOT_INTERACTABLE: [
        "not visible",
        "not interactable",
        "intercept",
        "disabled",
        "detached",
        "outside viewport",
    ],
    FailureCategory.TIMEOUT: [
        "timeout",
        "timed out",
        "deadline exceeded",
        "exceeded the time",
    ],
    FailureCategory.PAGE_BLOCKED: [
        "dialog",
        "alert",
        "blocked",
        "popup",
        "overlay",
    ],
    FailureCategory.NAVIGATION_FAILED: [
        "navigation",
        "net::err",
        "chrome-error",
        "dns",
        "connection refused",
    ],
    FailureCategory.SCRIPT_ERROR: [
        "evaluationfailed",
        "javascript error",
        "syntax error",
        "referenceerror",
        "typeerror",
    ],
}


def classify_failure(
    error_message: str,
    *,
    action: str = "",
    page_id: str = "",
) -> FailureClassification:
    """Classify an error message into a failure category.

    Scans the error message against known patterns and assigns the
    appropriate recovery chain.
    """
    lower = error_message.lower()
    category = FailureCategory.UNKNOWN

    for cat, patterns in _CLASSIFICATION_PATTERNS.items():
        if any(p in lower for p in patterns):
            category = cat
            break

    chain = list(_RECOVERY_CHAIN.get(category, _RECOVERY_CHAIN[FailureCategory.UNKNOWN]))
    return FailureClassification(
        category=category,
        error_message=error_message,
        action=action,
        page_id=page_id,
        recovery_chain=chain,
    )


# ---------------------------------------------------------------------------
# Post-action verification
# ---------------------------------------------------------------------------


def verify_action(
    *,
    action: str,
    page_id: str,
    pre_url: str = "",
    post_url: str = "",
    pre_title: str = "",
    post_title: str = "",
    pre_fingerprint: str = "",
    post_fingerprint: str = "",
    expected_element_found: bool | None = None,
) -> ActionVerification:
    """Verify whether an action produced the expected effect.

    Compares before/after URL, title, and snapshot fingerprints to
    determine if something meaningful changed.
    """
    url_changed = pre_url != post_url and bool(post_url)
    title_changed = pre_title != post_title and bool(post_title)
    snapshot_changed = pre_fingerprint != post_fingerprint and bool(post_fingerprint)

    # Determine result
    element_ok = expected_element_found if expected_element_found is not None else True
    any_change = url_changed or title_changed or snapshot_changed

    if action in ("navigate", "open", "navigate_back"):
        # Navigation actions: URL change is the primary signal
        result = VerificationResult.SUCCESS if url_changed else VerificationResult.FAILED
    elif action in ("click", "type", "fill_form", "select_option", "press_key"):
        # Interaction actions: any page change or element confirmation
        if element_ok and any_change:
            result = VerificationResult.SUCCESS
        elif element_ok:
            result = VerificationResult.PARTIAL
        else:
            result = VerificationResult.FAILED
    elif action in ("screenshot", "snapshot", "console_messages", "network_requests"):
        # Observation actions: always succeed if no error
        result = VerificationResult.SUCCESS
    else:
        result = VerificationResult.SUCCESS if element_ok else VerificationResult.FAILED

    return ActionVerification(
        action=action,
        page_id=page_id,
        result=result,
        url_changed=url_changed,
        title_changed=title_changed,
        snapshot_changed=snapshot_changed,
        expected_element_found=element_ok,
        detail=f"url_changed={url_changed}, title_changed={title_changed}, snapshot_changed={snapshot_changed}",
    )


# ---------------------------------------------------------------------------
# Recovery orchestrator
# ---------------------------------------------------------------------------


class RecoveryOrchestrator:
    """Orchestrates recovery attempts for failed browser actions.

    Tries strategies from the failure's recovery chain in order,
    recording each attempt until one succeeds or all are exhausted.
    """

    def __init__(self, *, max_attempts: int = MAX_RECOVERY_ATTEMPTS) -> None:
        self._max_attempts = max_attempts
        self._history: list[RecoveryResult] = []

        # Metrics
        self.total_recoveries: int = 0
        self.total_escalations: int = 0
        self.total_attempts: int = 0

    def plan_recovery(
        self,
        classification: FailureClassification,
    ) -> list[RecoveryStrategy]:
        """Return the ordered list of strategies to attempt."""
        chain = classification.recovery_chain[: self._max_attempts]
        if not chain:
            chain = [RecoveryStrategy.ABORT]
        return chain

    def record_attempt(
        self,
        strategy: RecoveryStrategy,
        *,
        success: bool,
        detail: str = "",
    ) -> RecoveryAttempt:
        """Record a single recovery attempt."""
        self.total_attempts += 1
        return RecoveryAttempt(
            strategy=strategy,
            success=success,
            detail=detail,
        )

    def build_result(
        self,
        attempts: list[RecoveryAttempt],
    ) -> RecoveryResult:
        """Build the aggregate recovery result from attempts."""
        recovered = any(a.success for a in attempts)
        final = attempts[-1].strategy if attempts else RecoveryStrategy.ABORT
        escalated = final == RecoveryStrategy.REQUEST_HANDOFF

        if recovered:
            self.total_recoveries += 1
        if escalated:
            self.total_escalations += 1

        result = RecoveryResult(
            recovered=recovered,
            attempts=attempts,
            final_strategy=final,
            escalated=escalated,
            detail=f"tried {len(attempts)} strategies, recovered={recovered}",
        )
        self._history.append(result)
        return result

    @property
    def history(self) -> list[RecoveryResult]:
        return list(self._history)

    def metrics(self) -> dict[str, Any]:
        return {
            "total_recoveries": self.total_recoveries,
            "total_escalations": self.total_escalations,
            "total_attempts": self.total_attempts,
            "history_length": len(self._history),
        }
