from __future__ import annotations

import logging
import os
import time
from dataclasses import asdict, dataclass, field
from typing import Any

logger = logging.getLogger(__name__)

MODULE_NAMES = (
    "snapshot_cache",
    "summary",
    "ref_map",
    "recovery",
    "error_translation",
    "advanced_debug",
)

ACTION_DEFAULT_STRATEGY = {
    "snapshot": "dom_snapshot",
    "click": "dom_action",
    "type": "dom_action",
    "fill_form": "dom_action",
    "drag": "dom_action",
    "hover": "dom_action",
    "select_option": "dom_action",
    "screenshot": "visual_capture",
    "network_requests": "network_observe",
    "run_code": "script_eval",
    "evaluate": "script_eval",
    "eval": "script_eval",
}


@dataclass(slots=True)
class EnhancementModuleState:
    name: str
    enabled: bool = True
    healthy: bool = True
    degraded: bool = False
    last_error: str = ""
    last_error_at: float | None = None

    def mark_failed(self, error: str, *, degrade_only: bool = True) -> None:
        self.healthy = False
        self.degraded = degrade_only
        if not degrade_only:
            self.enabled = False
        self.last_error = error
        self.last_error_at = time.time()


@dataclass(slots=True)
class BrowserEnhancementFlags:
    enabled: bool = True
    allow_graceful_fallback: bool = True
    gray_percentage: int = 100
    snapshot_cache_enabled: bool = True
    summary_enabled: bool = True
    ref_map_enabled: bool = True
    recovery_enabled: bool = True
    error_translation_enabled: bool = True
    advanced_debug_enabled: bool = False

    @classmethod
    def from_env(cls) -> BrowserEnhancementFlags:
        return cls(
            enabled=_env_bool("LIGHTCLAW_BROWSER_ENHANCEMENT_ENABLED", True),
            allow_graceful_fallback=_env_bool(
                "LIGHTCLAW_BROWSER_ENHANCEMENT_GRACEFUL_FALLBACK",
                True,
            ),
            gray_percentage=_env_int(
                "LIGHTCLAW_BROWSER_ENHANCEMENT_GRAY_PERCENTAGE",
                100,
                minimum=0,
                maximum=100,
            ),
            snapshot_cache_enabled=_env_bool(
                "LIGHTCLAW_BROWSER_ENHANCEMENT_SNAPSHOT_CACHE_ENABLED",
                True,
            ),
            summary_enabled=_env_bool(
                "LIGHTCLAW_BROWSER_ENHANCEMENT_SUMMARY_ENABLED",
                True,
            ),
            ref_map_enabled=_env_bool(
                "LIGHTCLAW_BROWSER_ENHANCEMENT_REF_MAP_ENABLED",
                True,
            ),
            recovery_enabled=_env_bool(
                "LIGHTCLAW_BROWSER_ENHANCEMENT_RECOVERY_ENABLED",
                True,
            ),
            error_translation_enabled=_env_bool(
                "LIGHTCLAW_BROWSER_ENHANCEMENT_ERROR_TRANSLATION_ENABLED",
                True,
            ),
            advanced_debug_enabled=_env_bool(
                "LIGHTCLAW_BROWSER_ENHANCEMENT_ADVANCED_DEBUG_ENABLED",
                False,
            ),
        )

    def module_enabled(self, module_name: str) -> bool:
        module_key = f"{module_name}_enabled"
        return bool(getattr(self, module_key, False))


@dataclass(slots=True)
class BrowserEnhancementContext:
    action: str = ""
    page_id: str = ""
    status: str = "disabled"
    strategy: str = "base"
    used_capabilities: list[str] = field(default_factory=list)
    fallback_reason: str = ""
    timestamp: float = field(default_factory=time.time)


@dataclass(slots=True)
class BrowserEnhancementRuntimeState:
    initialized: bool = False
    enabled: bool = False
    degraded: bool = False
    initialized_at: float | None = None
    last_error: str = ""
    last_error_at: float | None = None
    flags: BrowserEnhancementFlags = field(default_factory=BrowserEnhancementFlags)
    modules: dict[str, EnhancementModuleState] = field(default_factory=dict)
    last_context: BrowserEnhancementContext = field(
        default_factory=BrowserEnhancementContext,
    )

    def to_dict(self) -> dict[str, Any]:
        return {
            "initialized": self.initialized,
            "enabled": self.enabled,
            "degraded": self.degraded,
            "initialized_at": self.initialized_at,
            "last_error": self.last_error,
            "last_error_at": self.last_error_at,
            "flags": asdict(self.flags),
            "modules": {name: asdict(module_state) for name, module_state in self.modules.items()},
            "last_context": asdict(self.last_context),
        }


class BrowserEnhancementRuntime:
    def __init__(self, flags: BrowserEnhancementFlags | None = None) -> None:
        self._flags = flags or BrowserEnhancementFlags.from_env()
        self._state = BrowserEnhancementRuntimeState(flags=self._flags)

    @property
    def state(self) -> BrowserEnhancementRuntimeState:
        return self._state

    def ensure_initialized(self) -> BrowserEnhancementRuntimeState:
        if self._state.initialized:
            return self._state

        try:
            self._state.modules = {
                module_name: EnhancementModuleState(
                    name=module_name,
                    enabled=self._flags.module_enabled(module_name),
                )
                for module_name in MODULE_NAMES
            }
            self._state.initialized = True
            self._state.enabled = self._flags.enabled
            self._state.initialized_at = time.time()
            self._state.last_context = BrowserEnhancementContext(
                status="ready" if self._flags.enabled else "disabled",
                strategy="base",
            )
        except Exception as exc:
            self.mark_runtime_failure(f"initialization_failed:{exc}")
            raise

        return self._state

    def begin_action(self, *, action: str, page_id: str) -> BrowserEnhancementContext:
        self.ensure_initialized()

        if not self._state.enabled:
            context = BrowserEnhancementContext(
                action=action,
                page_id=page_id,
                status="disabled",
                strategy="base",
            )
            self._state.last_context = context
            return context

        if self._state.degraded:
            context = BrowserEnhancementContext(
                action=action,
                page_id=page_id,
                status="degraded",
                strategy="fallback",
                used_capabilities=["fallback"],
                fallback_reason=self._state.last_error,
            )
            self._state.last_context = context
            return context

        strategy = ACTION_DEFAULT_STRATEGY.get(action, "base")
        used_capabilities: list[str] = []
        if strategy.startswith("dom"):
            used_capabilities.append("dom")
        if strategy == "visual_capture":
            used_capabilities.append("visual")
        if strategy == "network_observe":
            used_capabilities.append("network")
        if strategy == "script_eval":
            used_capabilities.append("script")

        context = BrowserEnhancementContext(
            action=action,
            page_id=page_id,
            status="active",
            strategy=strategy,
            used_capabilities=used_capabilities,
        )
        self._state.last_context = context
        return context

    def complete_action(
        self,
        *,
        action: str,
        page_id: str,
        used_capabilities: list[str] | None = None,
        strategy: str | None = None,
    ) -> BrowserEnhancementContext:
        current_context = self.begin_action(action=action, page_id=page_id)
        current_context.status = "completed"
        if strategy:
            current_context.strategy = strategy
        if used_capabilities is not None:
            current_context.used_capabilities = list(used_capabilities)
        current_context.timestamp = time.time()
        self._state.last_context = current_context
        return current_context

    def record_module_failure(self, module_name: str, error: str) -> None:
        self.ensure_initialized()
        module_state = self._state.modules.get(module_name)
        if module_state is None:
            logger.warning("Unknown browser enhancement module failed: %s", module_name)
            self.mark_runtime_failure(error)
            return

        module_state.mark_failed(error)
        self._state.degraded = True
        self._state.last_error = error
        self._state.last_error_at = time.time()
        self._state.last_context = BrowserEnhancementContext(
            action=self._state.last_context.action,
            page_id=self._state.last_context.page_id,
            status="degraded",
            strategy="fallback",
            used_capabilities=["fallback"],
            fallback_reason=error,
        )

    def mark_runtime_failure(self, error: str) -> None:
        self._state.initialized = True
        self._state.enabled = False
        self._state.degraded = True
        self._state.last_error = error
        self._state.last_error_at = time.time()
        self._state.last_context = BrowserEnhancementContext(
            action=self._state.last_context.action,
            page_id=self._state.last_context.page_id,
            status="degraded",
            strategy="fallback",
            used_capabilities=["fallback"],
            fallback_reason=error,
        )

    def snapshot(self) -> dict[str, Any]:
        self.ensure_initialized()
        return self._state.to_dict()


def _env_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _env_int(
    name: str,
    default: int,
    *,
    minimum: int,
    maximum: int,
) -> int:
    raw = os.getenv(name)
    if raw is None:
        return default

    try:
        value = int(raw)
    except ValueError:
        logger.warning("Invalid integer for %s: %s", name, raw)
        return default

    return max(minimum, min(maximum, value))
