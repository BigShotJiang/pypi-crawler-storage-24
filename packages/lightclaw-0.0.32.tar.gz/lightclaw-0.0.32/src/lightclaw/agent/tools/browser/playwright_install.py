"""Playwright browser auto-install helpers."""

from __future__ import annotations

import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path

import click

# ---------------------------------------------------------------------------
# Mirror configuration
# ---------------------------------------------------------------------------

# Default mirror host for Playwright browser downloads (avoids storage.googleapis.com)
# Can be overridden via PLAYWRIGHT_DOWNLOAD_HOST env var.
_DEFAULT_MIRROR = "https://npmmirror.com/mirrors/playwright"

# ---------------------------------------------------------------------------
# Internal: executable detection
# ---------------------------------------------------------------------------


def _chromium_executable() -> str | None:
    """Return the Playwright-managed Chromium executable path via CLI query.

    Uses ``playwright show-downloads-dir`` + path construction to avoid
    launching a full sync_playwright context (which deadlocks inside an
    existing asyncio event loop).
    """
    try:
        result = subprocess.run(
            [sys.executable, "-m", "playwright", "show-downloads-dir"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            return None
        downloads_dir = Path(result.stdout.strip())
        if not downloads_dir.is_dir():
            return None

        system = platform.system()
        # Search for any chromium-* subdirectory containing the binary
        exe_name = "chrome.exe" if system == "Windows" else "chrome"
        for candidate in downloads_dir.glob("chromium-*/chrome-*/"):
            exe = candidate / exe_name
            if exe.exists():
                return str(exe)
        # Fallback: headless-shell variant
        for candidate in downloads_dir.glob("chromium_headless_shell-*/chrome-*/"):
            exe_name_hs = "headless_shell.exe" if system == "Windows" else "headless_shell"
            exe = candidate / exe_name_hs
            if exe.exists():
                return str(exe)
        return None
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Internal: OS-level dependency installation
# ---------------------------------------------------------------------------


def _install_system_deps(python: str) -> None:
    """Attempt to install OS-level shared libraries required by Chromium.

    Strategy per platform:
    - **Windows**: no action needed; Chromium is fully self-contained.
    - **macOS**: no action needed; deps bundled inside the .app structure.
    - **Linux (Debian/Ubuntu/apt)**: run ``playwright install-deps chromium``.
    - **Linux (dnf/yum — RHEL/Fedora/CentOS)**: print a manual guidance message.
    - **Linux (pacman — Arch)**: print a manual guidance message.
    - **Other Linux**: print a generic guidance message.
    """
    system = platform.system()

    if system == "Windows":
        # Playwright's Chromium on Windows bundles all required DLLs.
        click.echo("  (Windows: no system dependencies needed)")
        return

    if system == "Darwin":
        # macOS: libraries are bundled; Homebrew deps are not typically needed.
        click.echo("  (macOS: no system dependencies needed)")
        return

    if system != "Linux":
        click.echo(
            f"  (Unknown OS '{system}': skipping system deps — "
            "run 'playwright install-deps chromium' manually if needed)"
        )
        return

    # ----- Linux branch -----
    if shutil.which("apt-get") or shutil.which("apt"):
        # Debian / Ubuntu / Mint — Playwright natively supports install-deps
        click.echo("  Detected apt-based Linux — running playwright install-deps...")
        result = subprocess.run(
            [python, "-m", "playwright", "install-deps", "chromium"],
            check=False,
        )
        if result.returncode != 0:
            click.echo(
                "! Could not install system dependencies automatically.\n"
                "  Run manually: sudo playwright install-deps chromium",
                err=True,
            )
        return

    if shutil.which("dnf") or shutil.which("yum"):
        # RHEL / Fedora / CentOS — install-deps not supported; give package list
        click.echo(
            "! dnf/yum-based Linux detected (RHEL/Fedora/CentOS).\n"
            "  playwright install-deps is not supported on this distro.\n"
            "  Install dependencies manually:\n"
            "    sudo dnf install -y alsa-lib atk at-spi2-atk cups-libs \\\n"
            "      libdrm libgbm libX11 libXcomposite libXdamage libXext \\\n"
            "      libXfixes libXrandr libxkbcommon nss pango"
        )
        return

    if shutil.which("pacman"):
        # Arch Linux / Manjaro
        click.echo(
            "! pacman-based Linux detected (Arch/Manjaro).\n"
            "  playwright install-deps is not supported on this distro.\n"
            "  Install dependencies manually:\n"
            "    sudo pacman -S --needed alsa-lib atk at-spi2-atk cups \\\n"
            "      libdrm mesa libx11 libxcomposite libxdamage libxext \\\n"
            "      libxfixes libxrandr libxkbcommon nss pango"
        )
        return

    if shutil.which("zypper"):
        # openSUSE
        click.echo(
            "! zypper-based Linux detected (openSUSE).\n"
            "  playwright install-deps is not supported on this distro.\n"
            "  Install dependencies manually:\n"
            "    sudo zypper in -y alsa libatk-1_0-0 libatk-bridge-2_0-0 \\\n"
            "      libcups2 libdrm2 Mesa-libgbm1 libX11-6 libXcomposite1 \\\n"
            "      libXdamage1 libXext6 libXfixes3 libXrandr2 libxkbcommon0 \\\n"
            "      libnspr4 libnss3 libpango-1_0-0"
        )
        return

    # Generic fallback for unknown Linux distros
    click.echo(
        "! Unrecognised Linux distro — skipping automatic system dependency install.\n"
        "  If Chromium fails to launch, try:\n"
        "    playwright install-deps chromium\n"
        "  or install the required shared libraries for your distro manually."
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def ensure_playwright_browsers(*, quiet: bool = False) -> bool:
    """Ensure Playwright Chromium binary and its system deps are present.

    Downloads the browser binary and installs OS-level libraries if missing.
    Returns ``True`` if everything is ready, ``False`` if installation failed.

    Supports Windows, macOS, and Linux (apt / dnf / pacman / zypper).

    The download mirror can be configured via the ``PLAYWRIGHT_DOWNLOAD_HOST``
    environment variable.  When the variable is not set, falls back to the
    built-in default mirror (``npmmirror.com``) to avoid timeouts caused by
    direct access to ``storage.googleapis.com`` from restricted networks.
    """
    exe = _chromium_executable()
    if exe and Path(exe).exists():
        if not quiet:
            click.echo("✓ Playwright Chromium already installed.")
        return True

    click.echo("Playwright Chromium not found — installing...")
    python = sys.executable

    # Build subprocess environment: inject download mirror unless the caller
    # has already set PLAYWRIGHT_DOWNLOAD_HOST explicitly.
    env = os.environ.copy()
    if "PLAYWRIGHT_DOWNLOAD_HOST" not in env:
        env["PLAYWRIGHT_DOWNLOAD_HOST"] = _DEFAULT_MIRROR
        click.echo(f"  Using download mirror: {_DEFAULT_MIRROR}")
        click.echo("  (Override with PLAYWRIGHT_DOWNLOAD_HOST env var)")

    # 1. Install the browser binary (cross-platform, always safe to run)
    result = subprocess.run(
        [python, "-m", "playwright", "install", "chromium"],
        check=False,
        env=env,
    )
    if result.returncode != 0:
        click.echo("✗ Failed to install Playwright Chromium binary.", err=True)
        return False

    # 2. Install OS-level shared libraries where applicable
    _install_system_deps(python)

    click.echo("✓ Playwright Chromium installed.")
    return True
