"""Browser automation sub-package: environment detection, profiles, Chrome
launcher, session management, screenshot streaming, control handoff, and
server-side image upload pipeline."""

from .file_resolver import FileResolver
from .upload_compat import (
    UploadControlInfo,
    detect_upload_controls,
    trigger_upload_control,
)
from .upload_models import (
    UploadErrorCode,
    UploadFileSpec,
    UploadPhase,
    UploadRequest,
    UploadResult,
)
from .upload_pipeline import build_upload_request, execute_upload
from .upload_verify import VerifyResult, verify_upload

__all__ = [
    "FileResolver",
    "UploadControlInfo",
    "UploadErrorCode",
    "UploadFileSpec",
    "UploadPhase",
    "UploadRequest",
    "UploadResult",
    "VerifyResult",
    "build_upload_request",
    "detect_upload_controls",
    "execute_upload",
    "trigger_upload_control",
    "verify_upload",
]
