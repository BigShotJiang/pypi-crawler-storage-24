"""Structured page observation and summary generation pipeline.

Implements requirement 3: page summary with structured observation output.
"""

from __future__ import annotations

import logging
import re
import time
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

logger = logging.getLogger(__name__)

# Default summary TTL in seconds (3 minutes)
DEFAULT_SUMMARY_TTL = 180.0

# Minimum confidence score to consider a summary trustworthy
MIN_CONFIDENCE = 0.5


class BlockingSignalType(StrEnum):
    """Types of page-level blocking signals."""

    LOGIN_PROMPT = "login_prompt"
    CAPTCHA = "captcha"
    PERMISSION_DENIED = "permission_denied"
    UPLOAD_IN_PROGRESS = "upload_in_progress"
    ERROR_MESSAGE = "error_message"
    COOKIE_CONSENT = "cookie_consent"
    PAYWALL = "paywall"
    RATE_LIMITED = "rate_limited"
    NONE = "none"


class SummaryStatus(StrEnum):
    """Status of a page summary."""

    VALID = "valid"
    EXPIRED = "expired"
    LOW_CONFIDENCE = "low_confidence"
    GENERATION_FAILED = "generation_failed"
    FALLBACK_USED = "fallback_used"


# ---------------------------------------------------------------------------
# Blocking signal patterns (heuristic)
# ---------------------------------------------------------------------------

_BLOCKING_PATTERNS: dict[BlockingSignalType, list[re.Pattern[str]]] = {
    BlockingSignalType.LOGIN_PROMPT: [
        re.compile(r"\blog[\s-]?in\b", re.IGNORECASE),
        re.compile(r"\bsign[\s-]?in\b", re.IGNORECASE),
        re.compile(r"\b(username|password)\b.*\btextbox\b", re.IGNORECASE),
        re.compile(r"\bSSO\b", re.IGNORECASE),
        re.compile(r"\bOAuth\b", re.IGNORECASE),
    ],
    BlockingSignalType.CAPTCHA: [
        re.compile(r"\bcaptcha\b", re.IGNORECASE),
        re.compile(r"\bverif(y|ication)\b.*\bcode\b", re.IGNORECASE),
        re.compile(r"\breCAPTCHA\b", re.IGNORECASE),
        re.compile(r"\bslide\b.*\bverif", re.IGNORECASE),
    ],
    BlockingSignalType.PERMISSION_DENIED: [
        re.compile(r"\b(403|forbidden|access denied)\b", re.IGNORECASE),
        re.compile(r"\bpermission\b.*\bdenied\b", re.IGNORECASE),
        re.compile(r"\bunauthori[sz]ed\b", re.IGNORECASE),
    ],
    BlockingSignalType.UPLOAD_IN_PROGRESS: [
        re.compile(r"\bupload(ing)?\b.*\bprogress\b", re.IGNORECASE),
        re.compile(r"\b\d+%\b.*\bupload\b", re.IGNORECASE),
    ],
    BlockingSignalType.ERROR_MESSAGE: [
        re.compile(r"\b(500|502|503|504)\b.*\b(error|internal)\b", re.IGNORECASE),
        re.compile(r"\bserver\b.*\berror\b", re.IGNORECASE),
        re.compile(r"\bsomething went wrong\b", re.IGNORECASE),
        re.compile(r"\bpage not found\b", re.IGNORECASE),
        re.compile(r"\b404\b.*\bnot found\b", re.IGNORECASE),
    ],
    BlockingSignalType.COOKIE_CONSENT: [
        re.compile(r"\bcookie\b.*\b(consent|accept|agree)\b", re.IGNORECASE),
        re.compile(r"\baccept\b.*\bcookie\b", re.IGNORECASE),
    ],
    BlockingSignalType.PAYWALL: [
        re.compile(r"\bsubscri(be|ption)\b.*\b(required|needed|access)\b", re.IGNORECASE),
        re.compile(r"\bpaywall\b", re.IGNORECASE),
    ],
    BlockingSignalType.RATE_LIMITED: [
        re.compile(r"\brate\b.*\blimit(ed)?\b", re.IGNORECASE),
        re.compile(r"\btoo many requests\b", re.IGNORECASE),
        re.compile(r"\b429\b", re.IGNORECASE),
    ],
}


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------


@dataclass(slots=True)
class InteractiveElement:
    """A summarised interactive element on the page."""

    ref: str = ""
    role: str = ""
    name: str = ""
    element_type: str = ""  # button, link, textbox, combobox, etc.
    visible: bool = True


@dataclass(slots=True)
class FormRegion:
    """A detected form area with its fields."""

    form_name: str = ""
    fields: list[InteractiveElement] = field(default_factory=list)
    submit_ref: str = ""


@dataclass(slots=True)
class BlockingSignal:
    """A detected blocking condition on the page."""

    signal_type: BlockingSignalType = BlockingSignalType.NONE
    detail: str = ""
    confidence: float = 0.0


@dataclass(slots=True)
class PageObservation:
    """Unified structured page observation output.

    Contains title, URL, interactive elements, form regions, error messages,
    and blocking signals.
    """

    url: str = ""
    title: str = ""
    page_id: str = ""
    interactive_elements: list[InteractiveElement] = field(default_factory=list)
    form_regions: list[FormRegion] = field(default_factory=list)
    blocking_signals: list[BlockingSignal] = field(default_factory=list)
    error_messages: list[str] = field(default_factory=list)
    element_count: int = 0
    observed_at: float = field(default_factory=time.time)

    def has_blockers(self) -> bool:
        """Return True if any blocking signal was detected."""
        return any(s.signal_type != BlockingSignalType.NONE for s in self.blocking_signals)

    def to_dict(self) -> dict[str, Any]:
        return {
            "url": self.url,
            "title": self.title,
            "page_id": self.page_id,
            "interactive_elements": [
                {"ref": e.ref, "role": e.role, "name": e.name, "type": e.element_type}
                for e in self.interactive_elements
            ],
            "form_regions": [
                {
                    "form_name": f.form_name,
                    "fields": [{"ref": e.ref, "role": e.role, "name": e.name} for e in f.fields],
                    "submit_ref": f.submit_ref,
                }
                for f in self.form_regions
            ],
            "blocking_signals": [
                {"type": s.signal_type.value, "detail": s.detail, "confidence": s.confidence}
                for s in self.blocking_signals
            ],
            "error_messages": self.error_messages,
            "element_count": self.element_count,
            "has_blockers": self.has_blockers(),
            "observed_at": self.observed_at,
        }


@dataclass(slots=True)
class PageSummary:
    """A concise summary of a page observation."""

    page_id: str = ""
    url: str = ""
    purpose: str = ""
    key_interactions: list[str] = field(default_factory=list)
    blocking_info: str = ""
    suggested_actions: list[str] = field(default_factory=list)
    source_snapshot_id: str = ""
    generated_at: float = field(default_factory=time.time)
    ttl: float = DEFAULT_SUMMARY_TTL
    confidence: float = 1.0
    status: SummaryStatus = SummaryStatus.VALID
    fallback_reason: str = ""

    @property
    def expired(self) -> bool:
        return (time.time() - self.generated_at) > self.ttl

    @property
    def trustworthy(self) -> bool:
        return self.confidence >= MIN_CONFIDENCE and not self.expired

    def to_dict(self) -> dict[str, Any]:
        return {
            "page_id": self.page_id,
            "url": self.url,
            "purpose": self.purpose,
            "key_interactions": self.key_interactions,
            "blocking_info": self.blocking_info,
            "suggested_actions": self.suggested_actions,
            "source_snapshot_id": self.source_snapshot_id,
            "generated_at": self.generated_at,
            "confidence": self.confidence,
            "status": self.status.value,
            "expired": self.expired,
            "trustworthy": self.trustworthy,
        }


# ---------------------------------------------------------------------------
# Observation builder
# ---------------------------------------------------------------------------

# Roles that represent interactive elements in ARIA snapshots
_INTERACTIVE_ROLES = frozenset(
    {
        "button",
        "link",
        "textbox",
        "combobox",
        "checkbox",
        "radio",
        "slider",
        "tab",
        "menuitem",
        "switch",
        "searchbox",
        "spinbutton",
        "option",
    }
)


def build_observation(
    *,
    snapshot_text: str,
    refs: dict[str, dict[str, Any]],
    url: str = "",
    title: str = "",
    page_id: str = "",
) -> PageObservation:
    """Build a :class:`PageObservation` from a snapshot and its ref map.

    Extracts interactive elements, detects form regions (heuristic), and
    scans for blocking signals.
    """
    interactive_elements: list[InteractiveElement] = []
    form_fields: list[InteractiveElement] = []

    for ref_id, info in refs.items():
        role = info.get("role", "")
        name = info.get("name", "")
        if role in _INTERACTIVE_ROLES:
            elem = InteractiveElement(
                ref=ref_id,
                role=role,
                name=name,
                element_type=role,
            )
            interactive_elements.append(elem)
            if role in ("textbox", "combobox", "checkbox", "radio", "slider", "searchbox"):
                form_fields.append(elem)

    # Heuristic form detection: group form fields + find a submit button
    form_regions: list[FormRegion] = []
    if form_fields:
        submit_ref = ""
        for elem in interactive_elements:
            if elem.role == "button" and _looks_like_submit(elem.name):
                submit_ref = elem.ref
                break
        form_regions.append(
            FormRegion(
                form_name="detected_form",
                fields=form_fields,
                submit_ref=submit_ref,
            ),
        )

    # Blocking signal detection
    blocking_signals = detect_blocking_signals(snapshot_text)

    # Error message extraction
    error_messages = _extract_error_messages(snapshot_text)

    return PageObservation(
        url=url,
        title=title,
        page_id=page_id,
        interactive_elements=interactive_elements,
        form_regions=form_regions,
        blocking_signals=blocking_signals,
        error_messages=error_messages,
        element_count=len(refs),
    )


def detect_blocking_signals(snapshot_text: str) -> list[BlockingSignal]:
    """Scan snapshot text for blocking signals using heuristic patterns."""
    signals: list[BlockingSignal] = []
    for signal_type, patterns in _BLOCKING_PATTERNS.items():
        matches = 0
        detail_parts: list[str] = []
        for pattern in patterns:
            match = pattern.search(snapshot_text)
            if match:
                matches += 1
                detail_parts.append(match.group(0))
        if matches > 0:
            confidence = min(1.0, matches * 0.4)
            signals.append(
                BlockingSignal(
                    signal_type=signal_type,
                    detail="; ".join(detail_parts[:3]),
                    confidence=confidence,
                ),
            )
    return signals


def _looks_like_submit(name: str) -> bool:
    """Heuristic: does this button name suggest a form submission?"""
    if not name:
        return False
    lower = name.lower()
    return any(kw in lower for kw in ("submit", "login", "sign in", "register", "send", "save", "confirm", "ok", "go"))


def _extract_error_messages(snapshot_text: str) -> list[str]:
    """Extract likely error messages from snapshot text."""
    errors: list[str] = []
    error_pattern = re.compile(
        r"(error|warning|alert|danger)[\s:]*(.{5,80})",
        re.IGNORECASE,
    )
    for match in error_pattern.finditer(snapshot_text):
        msg = match.group(0).strip()
        if msg not in errors:
            errors.append(msg)
    return errors[:10]  # Cap at 10 to avoid noise


# ---------------------------------------------------------------------------
# Summary generator
# ---------------------------------------------------------------------------


def generate_summary(
    observation: PageObservation,
    *,
    source_snapshot_id: str = "",
) -> PageSummary:
    """Generate a concise summary from a page observation.

    This is a heuristic/rule-based generator. A future enhancement can
    replace this with an LLM-based summariser while keeping the same
    interface.
    """
    try:
        purpose = _infer_page_purpose(observation)
        key_interactions = _extract_key_interactions(observation)
        blocking_info = _summarise_blockers(observation)
        suggested_actions = _suggest_actions(observation)

        # Confidence: lower if we have blockers or no interactive elements
        confidence = 1.0
        if observation.has_blockers():
            confidence -= 0.2
        if not observation.interactive_elements:
            confidence -= 0.3
        if not observation.url:
            confidence -= 0.1
        confidence = max(0.0, confidence)

        return PageSummary(
            page_id=observation.page_id,
            url=observation.url,
            purpose=purpose,
            key_interactions=key_interactions,
            blocking_info=blocking_info,
            suggested_actions=suggested_actions,
            source_snapshot_id=source_snapshot_id,
            confidence=confidence,
            status=SummaryStatus.VALID,
        )
    except Exception as exc:
        logger.warning("Summary generation failed: %s", exc)
        return PageSummary(
            page_id=observation.page_id,
            url=observation.url,
            purpose="unknown",
            confidence=0.0,
            status=SummaryStatus.GENERATION_FAILED,
            fallback_reason=str(exc),
        )


def validate_summary(summary: PageSummary) -> PageSummary:
    """Check if a summary is still valid; update status if not."""
    if summary.expired:
        summary.status = SummaryStatus.EXPIRED
        return summary
    if summary.confidence < MIN_CONFIDENCE:
        summary.status = SummaryStatus.LOW_CONFIDENCE
        return summary
    return summary


# ---------------------------------------------------------------------------
# Heuristic helpers
# ---------------------------------------------------------------------------


def _infer_page_purpose(obs: PageObservation) -> str:
    """Infer a one-line purpose for the page based on URL, title, and signals."""
    parts: list[str] = []

    if obs.title:
        parts.append(obs.title)

    for signal in obs.blocking_signals:
        if signal.signal_type == BlockingSignalType.LOGIN_PROMPT:
            return f"Login page: {obs.title or obs.url}"
        if signal.signal_type == BlockingSignalType.CAPTCHA:
            return f"Captcha verification: {obs.title or obs.url}"
        if signal.signal_type == BlockingSignalType.PERMISSION_DENIED:
            return f"Access denied: {obs.title or obs.url}"
        if signal.signal_type == BlockingSignalType.ERROR_MESSAGE:
            return f"Error page: {obs.title or obs.url}"

    if obs.form_regions:
        return f"Form page: {obs.title or obs.url}"

    return obs.title or obs.url or "Unknown page"


def _extract_key_interactions(obs: PageObservation) -> list[str]:
    """Extract a short list of key interaction descriptions."""
    interactions: list[str] = []
    for elem in obs.interactive_elements[:10]:
        desc = f"{elem.role}"
        if elem.name:
            desc += f" '{elem.name}'"
        desc += f" [ref={elem.ref}]"
        interactions.append(desc)
    return interactions


def _summarise_blockers(obs: PageObservation) -> str:
    """Summarise blocking signals as a single string."""
    if not obs.has_blockers():
        return ""
    blocker_parts = [
        f"{s.signal_type.value}: {s.detail}" for s in obs.blocking_signals if s.signal_type != BlockingSignalType.NONE
    ]
    return "; ".join(blocker_parts)


def _suggest_actions(obs: PageObservation) -> list[str]:
    """Suggest next actions based on the page state."""
    suggestions: list[str] = []

    for signal in obs.blocking_signals:
        if signal.signal_type == BlockingSignalType.LOGIN_PROMPT:
            suggestions.append("Complete login or request user handoff")
        elif signal.signal_type == BlockingSignalType.CAPTCHA:
            suggestions.append("Request user handoff for captcha resolution")
        elif signal.signal_type == BlockingSignalType.COOKIE_CONSENT:
            suggestions.append("Accept cookie consent banner")
        elif signal.signal_type == BlockingSignalType.PERMISSION_DENIED:
            suggestions.append("Check permissions or navigate to accessible page")
        elif signal.signal_type == BlockingSignalType.ERROR_MESSAGE:
            suggestions.append("Refresh page or navigate to alternative URL")
        elif signal.signal_type == BlockingSignalType.RATE_LIMITED:
            suggestions.append("Wait and retry after delay")

    if not suggestions and obs.form_regions:
        suggestions.append("Fill and submit the form")

    if not suggestions and obs.interactive_elements:
        suggestions.append("Interact with available elements")

    if not suggestions:
        suggestions.append("Take snapshot to inspect page content")

    return suggestions
