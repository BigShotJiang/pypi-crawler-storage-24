"""Browser error translation and debug context output.

Implements requirement 6: error translation, readable explanations,
recovery suggestions, and structured debug events.
"""

from __future__ import annotations

import logging
import re
import time
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

logger = logging.getLogger(__name__)


class BrowserErrorType(StrEnum):
    """Unified browser error type taxonomy."""

    ELEMENT_NOT_FOUND = "element_not_found"
    ELEMENT_NOT_VISIBLE = "element_not_visible"
    ELEMENT_NOT_INTERACTABLE = "element_not_interactable"
    ELEMENT_DETACHED = "element_detached"
    NAVIGATION_FAILED = "navigation_failed"
    DNS_ERROR = "dns_error"
    CONNECTION_REFUSED = "connection_refused"
    SSL_ERROR = "ssl_error"
    TIMEOUT = "timeout"
    DIALOG_BLOCKING = "dialog_blocking"
    SCRIPT_ERROR = "script_error"
    PERMISSION_ERROR = "permission_error"
    BROWSER_CRASHED = "browser_crashed"
    SESSION_EXPIRED = "session_expired"
    UNKNOWN = "unknown"


# ---------------------------------------------------------------------------
# Error translation rules
# ---------------------------------------------------------------------------


@dataclass(slots=True)
class ErrorTranslationRule:
    """A rule mapping raw error patterns to user-friendly info."""

    error_type: BrowserErrorType
    patterns: list[str]
    description: str
    suggestion: str


_TRANSLATION_RULES: list[ErrorTranslationRule] = [
    ErrorTranslationRule(
        error_type=BrowserErrorType.ELEMENT_NOT_FOUND,
        patterns=["not found", "unknown ref", "no such element", "locator resolved to 0"],
        description="The target element was not found on the page.",
        suggestion="Take a new snapshot to refresh element refs, then retry with the correct ref.",
    ),
    ErrorTranslationRule(
        error_type=BrowserErrorType.ELEMENT_NOT_VISIBLE,
        patterns=["not visible", "hidden", "display: none", "visibility: hidden"],
        description="The target element exists but is not visible.",
        suggestion="Scroll to the element, dismiss overlays, or wait for the element to become visible.",
    ),
    ErrorTranslationRule(
        error_type=BrowserErrorType.ELEMENT_NOT_INTERACTABLE,
        patterns=["not interactable", "intercept", "pointer-events: none", "disabled"],
        description="The element cannot be interacted with (covered, disabled, or blocked).",
        suggestion="Dismiss any overlays/dialogs, wait for loading to complete, or try a different selector.",
    ),
    ErrorTranslationRule(
        error_type=BrowserErrorType.ELEMENT_DETACHED,
        patterns=["detached", "stale element", "node is detached"],
        description="The element was removed from the page after being located.",
        suggestion="Re-take a snapshot and use a fresh ref. The page may have re-rendered.",
    ),
    ErrorTranslationRule(
        error_type=BrowserErrorType.NAVIGATION_FAILED,
        patterns=["navigation", "chrome-error://", "about:blank#blocked"],
        description="Page navigation failed.",
        suggestion="Check the URL is correct and accessible. Try a known-good URL first.",
    ),
    ErrorTranslationRule(
        error_type=BrowserErrorType.DNS_ERROR,
        patterns=["net::err_name_not_resolved", "dns"],
        description="DNS resolution failed for the target URL.",
        suggestion="Check the domain name spelling and network connectivity.",
    ),
    ErrorTranslationRule(
        error_type=BrowserErrorType.CONNECTION_REFUSED,
        patterns=["net::err_connection_refused", "connection refused", "econnrefused"],
        description="The server refused the connection.",
        suggestion="Verify the server is running and the port is correct.",
    ),
    ErrorTranslationRule(
        error_type=BrowserErrorType.SSL_ERROR,
        patterns=["net::err_cert", "ssl", "certificate"],
        description="SSL/TLS certificate error.",
        suggestion="The site may have an invalid certificate. Try with --ignore-certificate-errors if appropriate.",
    ),
    ErrorTranslationRule(
        error_type=BrowserErrorType.TIMEOUT,
        patterns=["timeout", "timed out", "deadline exceeded"],
        description="The operation timed out.",
        suggestion="The page or element may be slow to load. Increase wait time or check network.",
    ),
    ErrorTranslationRule(
        error_type=BrowserErrorType.DIALOG_BLOCKING,
        patterns=["dialog", "alert", "confirm", "prompt"],
        description="A dialog/alert is blocking the page.",
        suggestion="Handle the dialog first using handle_dialog action, then retry.",
    ),
    ErrorTranslationRule(
        error_type=BrowserErrorType.SCRIPT_ERROR,
        patterns=["evaluationfailed", "javascript error", "syntaxerror", "referenceerror", "typeerror"],
        description="JavaScript execution failed.",
        suggestion="Check the script for syntax errors or undefined variables.",
    ),
    ErrorTranslationRule(
        error_type=BrowserErrorType.PERMISSION_ERROR,
        patterns=["permission", "not allowed", "blocked by"],
        description="The operation was blocked by browser permissions.",
        suggestion="Check browser permissions or security settings.",
    ),
    ErrorTranslationRule(
        error_type=BrowserErrorType.BROWSER_CRASHED,
        patterns=[
            "browser has been closed",
            "browser closed",
            "browser crashed",
            "target closed",
            "context has been closed",
            "context destroyed",
            "has been closed",
        ],
        description="The browser or page has crashed or been closed unexpectedly.",
        suggestion="Restart the browser with action=start.",
    ),
    ErrorTranslationRule(
        error_type=BrowserErrorType.SESSION_EXPIRED,
        patterns=["session.*expired", "session.*invalid", "not connected"],
        description="The browser session has expired or been disconnected.",
        suggestion="Restart the browser session with action=start.",
    ),
]


# ---------------------------------------------------------------------------
# Translated error
# ---------------------------------------------------------------------------


@dataclass(slots=True)
class TranslatedError:
    """A browser error translated into user-friendly form."""

    error_type: BrowserErrorType
    description: str
    suggestion: str
    original_error: str
    action: str = ""
    page_id: str = ""
    page_url: str = ""
    session_id: str = ""
    site: str = ""
    translated_at: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        return {
            "error_type": self.error_type.value,
            "description": self.description,
            "suggestion": self.suggestion,
            "original_error": self.original_error,
            "action": self.action,
            "page_id": self.page_id,
            "page_url": self.page_url,
            "session_id": self.session_id,
            "site": self.site,
            "translated_at": self.translated_at,
        }


@dataclass(slots=True)
class DebugEvent:
    """A structured debug event for logging and inspection."""

    event_type: str  # "error", "recovery", "action", "state_change"
    error: TranslatedError | None = None
    action: str = ""
    page_id: str = ""
    session_id: str = ""
    site: str = ""
    context: dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        return {
            "event_type": self.event_type,
            "error": self.error.to_dict() if self.error else None,
            "action": self.action,
            "page_id": self.page_id,
            "session_id": self.session_id,
            "site": self.site,
            "context": self.context,
            "timestamp": self.timestamp,
        }


# ---------------------------------------------------------------------------
# Error translator
# ---------------------------------------------------------------------------


def translate_error(
    error_message: str,
    *,
    action: str = "",
    page_id: str = "",
    page_url: str = "",
    session_id: str = "",
) -> TranslatedError:
    """Translate a raw browser error into a user-friendly form.

    Scans the error message against known patterns and returns a
    :class:`TranslatedError` with description and recovery suggestion.
    """
    lower = error_message.lower()
    site = _extract_site(page_url)

    for rule in _TRANSLATION_RULES:
        for pattern in rule.patterns:
            if pattern in lower:
                return TranslatedError(
                    error_type=rule.error_type,
                    description=rule.description,
                    suggestion=rule.suggestion,
                    original_error=error_message,
                    action=action,
                    page_id=page_id,
                    page_url=page_url,
                    session_id=session_id,
                    site=site,
                )

    return TranslatedError(
        error_type=BrowserErrorType.UNKNOWN,
        description=f"An unexpected browser error occurred: {error_message[:200]}",
        suggestion="Try taking a snapshot to check page state, then retry the action.",
        original_error=error_message,
        action=action,
        page_id=page_id,
        page_url=page_url,
        session_id=session_id,
        site=site,
    )


def create_debug_event(
    translated: TranslatedError,
    *,
    extra_context: dict[str, Any] | None = None,
) -> DebugEvent:
    """Create a structured debug event from a translated error."""
    return DebugEvent(
        event_type="error",
        error=translated,
        action=translated.action,
        page_id=translated.page_id,
        session_id=translated.session_id,
        site=translated.site,
        context=extra_context or {},
    )


# ---------------------------------------------------------------------------
# Debug event log (in-memory ring buffer)
# ---------------------------------------------------------------------------

MAX_DEBUG_EVENTS = 200


class DebugEventLog:
    """In-memory ring buffer for debug events.

    Supports filtering by error type, site, action, and time range.
    """

    def __init__(self, max_size: int = MAX_DEBUG_EVENTS) -> None:
        self._events: list[DebugEvent] = []
        self._max_size = max_size

    def append(self, event: DebugEvent) -> None:
        """Add an event to the log."""
        self._events.append(event)
        if len(self._events) > self._max_size:
            self._events = self._events[-self._max_size :]

    def query(
        self,
        *,
        error_type: BrowserErrorType | None = None,
        site: str | None = None,
        action: str | None = None,
        since: float | None = None,
        limit: int = 50,
    ) -> list[DebugEvent]:
        """Query events with optional filters."""
        result: list[DebugEvent] = []
        for event in reversed(self._events):
            if error_type and event.error and event.error.error_type != error_type:
                continue
            if site and event.site != site:
                continue
            if action and event.action != action:
                continue
            if since and event.timestamp < since:
                continue
            result.append(event)
            if len(result) >= limit:
                break
        return result

    def clear(self) -> int:
        """Clear all events. Returns count removed."""
        count = len(self._events)
        self._events.clear()
        return count

    @property
    def size(self) -> int:
        return len(self._events)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_site(url: str) -> str:
    """Extract the site domain from a URL."""
    if not url:
        return ""
    match = re.match(r"https?://([^/]+)", url)
    return match.group(1) if match else ""
