"""Snapshot cache model with fingerprint-based invalidation and jitter suppression.

Implements requirement 2: on-demand snapshot with cache reuse.
"""

from __future__ import annotations

import hashlib
import logging
import time
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

logger = logging.getLogger(__name__)

# Default cache TTL in seconds (5 minutes)
DEFAULT_CACHE_TTL = 300.0

# Minimum interval between consecutive snapshots to suppress jitter (seconds)
JITTER_SUPPRESSION_INTERVAL = 2.0

# Maximum number of cached entries per session (LRU eviction)
MAX_CACHE_SIZE = 50


class InvalidationReason(StrEnum):
    """Why a cached snapshot was invalidated."""

    NAVIGATION = "navigation"
    EXPLICIT_REFRESH = "explicit_refresh"
    CACHE_EXPIRED = "cache_expired"
    FINGERPRINT_CHANGED = "fingerprint_changed"
    MANUAL = "manual"
    EVICTED = "evicted"


class CacheHitReason(StrEnum):
    """Why a cached snapshot was reused."""

    URL_MATCH = "url_match"
    FINGERPRINT_MATCH = "fingerprint_match"
    JITTER_SUPPRESSED = "jitter_suppressed"


@dataclass(slots=True)
class SnapshotCacheEntry:
    """A single cached page snapshot."""

    page_id: str
    url: str
    fingerprint: str
    snapshot_text: str
    refs: dict[str, dict[str, Any]]
    created_at: float = field(default_factory=time.time)
    last_accessed_at: float = field(default_factory=time.time)
    ttl: float = DEFAULT_CACHE_TTL
    hit_count: int = 0
    hit_reason: str = ""

    @property
    def expired(self) -> bool:
        """Return True if the entry has exceeded its TTL."""
        return (time.time() - self.created_at) > self.ttl

    def touch(self, reason: CacheHitReason) -> None:
        """Record a cache hit."""
        self.last_accessed_at = time.time()
        self.hit_count += 1
        self.hit_reason = reason.value

    def to_dict(self) -> dict[str, Any]:
        """Serialise for API / debug output."""
        return {
            "page_id": self.page_id,
            "url": self.url,
            "fingerprint": self.fingerprint[:16],
            "created_at": self.created_at,
            "last_accessed_at": self.last_accessed_at,
            "ttl": self.ttl,
            "hit_count": self.hit_count,
            "hit_reason": self.hit_reason,
            "expired": self.expired,
            "snapshot_length": len(self.snapshot_text),
        }


@dataclass(slots=True)
class CacheLookupResult:
    """Result of a cache lookup attempt."""

    hit: bool
    entry: SnapshotCacheEntry | None = None
    reason: str = ""
    invalidation_reason: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "hit": self.hit,
            "reason": self.reason,
            "invalidation_reason": self.invalidation_reason,
            "entry": self.entry.to_dict() if self.entry else None,
        }


def compute_page_fingerprint(snapshot_text: str) -> str:
    """Compute a lightweight fingerprint of the snapshot text.

    Uses a truncated SHA-256 of the normalised snapshot so that trivial
    whitespace changes do not cause spurious invalidation.
    """
    normalised = " ".join(snapshot_text.split())
    return hashlib.sha256(normalised.encode("utf-8")).hexdigest()


class SnapshotCache:
    """Per-session page snapshot cache with TTL and fingerprint invalidation.

    Thread-safety note: This is designed for single-event-loop usage
    (asyncio), so no locks are required.
    """

    def __init__(
        self,
        *,
        default_ttl: float = DEFAULT_CACHE_TTL,
        max_size: int = MAX_CACHE_SIZE,
        jitter_interval: float = JITTER_SUPPRESSION_INTERVAL,
    ) -> None:
        self._entries: dict[str, SnapshotCacheEntry] = {}  # keyed by page_id
        self._default_ttl = default_ttl
        self._max_size = max_size
        self._jitter_interval = jitter_interval
        self._last_snapshot_time: dict[str, float] = {}  # page_id -> timestamp

        # Metrics
        self.total_hits: int = 0
        self.total_misses: int = 0
        self.total_invalidations: int = 0
        self.total_jitter_suppressions: int = 0

    # -- public API ---------------------------------------------------------

    def lookup(
        self,
        page_id: str,
        current_url: str,
        current_fingerprint: str | None = None,
    ) -> CacheLookupResult:
        """Try to find a valid cached snapshot for *page_id*.

        Args:
            page_id: The page identifier.
            current_url: The page's current URL.
            current_fingerprint: Optional fingerprint of the current page
                state.  When provided, enables fingerprint-based invalidation.

        Returns:
            A :class:`CacheLookupResult` indicating hit/miss and reason.
        """
        entry = self._entries.get(page_id)
        if entry is None:
            self.total_misses += 1
            return CacheLookupResult(hit=False, reason="no_cache")

        # Check TTL
        if entry.expired:
            self._invalidate(page_id, InvalidationReason.CACHE_EXPIRED)
            self.total_misses += 1
            return CacheLookupResult(
                hit=False,
                reason="cache_expired",
                invalidation_reason=InvalidationReason.CACHE_EXPIRED.value,
            )

        # Check URL change (navigation)
        if entry.url != current_url:
            self._invalidate(page_id, InvalidationReason.NAVIGATION)
            self.total_misses += 1
            return CacheLookupResult(
                hit=False,
                reason="url_changed",
                invalidation_reason=InvalidationReason.NAVIGATION.value,
            )

        # Check fingerprint change
        if current_fingerprint and entry.fingerprint != current_fingerprint:
            self._invalidate(page_id, InvalidationReason.FINGERPRINT_CHANGED)
            self.total_misses += 1
            return CacheLookupResult(
                hit=False,
                reason="fingerprint_changed",
                invalidation_reason=InvalidationReason.FINGERPRINT_CHANGED.value,
            )

        # Cache hit
        self.total_hits += 1
        entry.touch(CacheHitReason.URL_MATCH if not current_fingerprint else CacheHitReason.FINGERPRINT_MATCH)
        return CacheLookupResult(
            hit=True,
            entry=entry,
            reason=entry.hit_reason,
        )

    def should_suppress_snapshot(self, page_id: str) -> bool:
        """Return True if a snapshot was taken too recently (jitter suppression).

        Does NOT invalidate the cache — the caller should reuse the existing
        entry when this returns True.
        """
        last_time = self._last_snapshot_time.get(page_id)
        if last_time is None:
            return False
        elapsed = time.time() - last_time
        if elapsed < self._jitter_interval:
            self.total_jitter_suppressions += 1
            return True
        return False

    def store(
        self,
        page_id: str,
        url: str,
        snapshot_text: str,
        refs: dict[str, dict[str, Any]],
        *,
        ttl: float | None = None,
    ) -> SnapshotCacheEntry:
        """Store a new snapshot in the cache, evicting the oldest entry if full."""
        fingerprint = compute_page_fingerprint(snapshot_text)
        entry = SnapshotCacheEntry(
            page_id=page_id,
            url=url,
            fingerprint=fingerprint,
            snapshot_text=snapshot_text,
            refs=refs,
            ttl=ttl if ttl is not None else self._default_ttl,
        )
        self._entries[page_id] = entry
        self._last_snapshot_time[page_id] = time.time()

        # LRU eviction
        if len(self._entries) > self._max_size:
            self._evict_oldest()

        return entry

    def invalidate(
        self,
        page_id: str,
        reason: InvalidationReason = InvalidationReason.MANUAL,
    ) -> bool:
        """Explicitly invalidate a cached entry. Returns True if an entry was removed."""
        return self._invalidate(page_id, reason)

    def invalidate_all(self) -> int:
        """Invalidate all cached entries. Returns the number of entries removed."""
        count = len(self._entries)
        self._entries.clear()
        self._last_snapshot_time.clear()
        self.total_invalidations += count
        return count

    def get_entry(self, page_id: str) -> SnapshotCacheEntry | None:
        """Return the raw cache entry without performing validation."""
        return self._entries.get(page_id)

    def metrics(self) -> dict[str, Any]:
        """Return cache performance metrics."""
        total = self.total_hits + self.total_misses
        return {
            "total_hits": self.total_hits,
            "total_misses": self.total_misses,
            "total_invalidations": self.total_invalidations,
            "total_jitter_suppressions": self.total_jitter_suppressions,
            "hit_rate": self.total_hits / total if total > 0 else 0.0,
            "active_entries": len(self._entries),
            "max_size": self._max_size,
        }

    # -- internal -----------------------------------------------------------

    def _invalidate(self, page_id: str, reason: InvalidationReason) -> bool:
        entry = self._entries.pop(page_id, None)
        if entry is not None:
            self.total_invalidations += 1
            logger.debug(
                "Snapshot cache invalidated page_id=%s reason=%s",
                page_id,
                reason.value,
            )
            return True
        return False

    def _evict_oldest(self) -> None:
        """Evict the least-recently-accessed entry."""
        if not self._entries:
            return
        oldest_key = min(
            self._entries,
            key=lambda k: self._entries[k].last_accessed_at,
        )
        self._invalidate(oldest_key, InvalidationReason.EVICTED)
