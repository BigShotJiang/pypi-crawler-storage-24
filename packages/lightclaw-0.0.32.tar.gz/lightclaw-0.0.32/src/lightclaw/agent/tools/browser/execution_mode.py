"""Advanced debug capabilities and execution mode switching.

Implements requirement 9: debug mode toggle, step-by-step execution,
verbose logging, execution mode management.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

logger = logging.getLogger(__name__)


class ExecutionMode(StrEnum):
    """Browser automation execution modes."""

    NORMAL = "normal"
    DEBUG = "debug"
    STEP_BY_STEP = "step_by_step"
    DRY_RUN = "dry_run"


class DebugLevel(StrEnum):
    """Debug verbosity levels."""

    OFF = "off"
    MINIMAL = "minimal"
    VERBOSE = "verbose"
    TRACE = "trace"


@dataclass(slots=True)
class DebugConfig:
    """Configuration for debug capabilities."""

    mode: ExecutionMode = ExecutionMode.NORMAL
    debug_level: DebugLevel = DebugLevel.OFF
    capture_screenshots_on_error: bool = True
    capture_network_on_error: bool = False
    log_all_actions: bool = False
    pause_before_action: bool = False
    pause_after_error: bool = False
    max_action_log_size: int = 100

    def to_dict(self) -> dict[str, Any]:
        return {
            "mode": self.mode.value,
            "debug_level": self.debug_level.value,
            "capture_screenshots_on_error": self.capture_screenshots_on_error,
            "capture_network_on_error": self.capture_network_on_error,
            "log_all_actions": self.log_all_actions,
            "pause_before_action": self.pause_before_action,
            "pause_after_error": self.pause_after_error,
            "max_action_log_size": self.max_action_log_size,
        }

    @classmethod
    def for_mode(cls, mode: ExecutionMode) -> DebugConfig:
        """Create a config pre-set for the given mode."""
        if mode == ExecutionMode.DEBUG:
            return cls(
                mode=mode,
                debug_level=DebugLevel.VERBOSE,
                capture_screenshots_on_error=True,
                capture_network_on_error=True,
                log_all_actions=True,
            )
        if mode == ExecutionMode.STEP_BY_STEP:
            return cls(
                mode=mode,
                debug_level=DebugLevel.TRACE,
                capture_screenshots_on_error=True,
                capture_network_on_error=True,
                log_all_actions=True,
                pause_before_action=True,
                pause_after_error=True,
            )
        if mode == ExecutionMode.DRY_RUN:
            return cls(
                mode=mode,
                debug_level=DebugLevel.VERBOSE,
                log_all_actions=True,
            )
        return cls(mode=mode)


@dataclass(slots=True)
class ActionLogEntry:
    """A logged action for debugging."""

    action: str
    page_id: str
    params: dict[str, Any] = field(default_factory=dict)
    result_ok: bool | None = None
    error: str = ""
    duration_ms: float = 0.0
    mode: ExecutionMode = ExecutionMode.NORMAL
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        return {
            "action": self.action,
            "page_id": self.page_id,
            "params": self.params,
            "result_ok": self.result_ok,
            "error": self.error,
            "duration_ms": self.duration_ms,
            "mode": self.mode.value,
            "timestamp": self.timestamp,
        }


class ExecutionModeManager:
    """Manages execution mode switching and debug capabilities.

    Provides action logging, mode-specific behavior, and a queryable
    action history for debugging.
    """

    def __init__(self, config: DebugConfig | None = None) -> None:
        self._config = config or DebugConfig()
        self._action_log: list[ActionLogEntry] = []
        self._mode_history: list[tuple[ExecutionMode, float]] = [
            (self._config.mode, time.time()),
        ]

        # Metrics
        self.total_actions_logged: int = 0
        self.total_mode_switches: int = 0

    @property
    def config(self) -> DebugConfig:
        return self._config

    @property
    def current_mode(self) -> ExecutionMode:
        return self._config.mode

    @property
    def is_debug(self) -> bool:
        return self._config.mode in (ExecutionMode.DEBUG, ExecutionMode.STEP_BY_STEP)

    @property
    def is_dry_run(self) -> bool:
        return self._config.mode == ExecutionMode.DRY_RUN

    def switch_mode(self, mode: ExecutionMode) -> DebugConfig:
        """Switch execution mode and update config accordingly."""
        old_mode = self._config.mode
        self._config = DebugConfig.for_mode(mode)
        self._mode_history.append((mode, time.time()))
        self.total_mode_switches += 1
        logger.info("Execution mode switched: %s → %s", old_mode.value, mode.value)
        return self._config

    def should_log_action(self) -> bool:
        """Whether the current mode requires action logging."""
        return self._config.log_all_actions or self._config.debug_level != DebugLevel.OFF

    def should_pause_before(self) -> bool:
        """Whether execution should pause before an action."""
        return self._config.pause_before_action

    def should_pause_after_error(self) -> bool:
        """Whether execution should pause after an error."""
        return self._config.pause_after_error

    def should_capture_screenshot_on_error(self) -> bool:
        """Whether to capture a screenshot on error."""
        return self._config.capture_screenshots_on_error

    def should_capture_network_on_error(self) -> bool:
        """Whether to capture network log on error."""
        return self._config.capture_network_on_error

    def log_action(
        self,
        *,
        action: str,
        page_id: str,
        params: dict[str, Any] | None = None,
        result_ok: bool | None = None,
        error: str = "",
        duration_ms: float = 0.0,
    ) -> ActionLogEntry:
        """Record an action in the debug log."""
        entry = ActionLogEntry(
            action=action,
            page_id=page_id,
            params=params or {},
            result_ok=result_ok,
            error=error,
            duration_ms=duration_ms,
            mode=self._config.mode,
        )
        self._action_log.append(entry)
        self.total_actions_logged += 1

        # Evict oldest entries if over limit
        if len(self._action_log) > self._config.max_action_log_size:
            self._action_log = self._action_log[-self._config.max_action_log_size :]

        if self._config.debug_level in (DebugLevel.VERBOSE, DebugLevel.TRACE):
            logger.debug(
                "[DEBUG] action=%s page=%s ok=%s err=%s dur=%.1fms",
                action,
                page_id,
                result_ok,
                error[:50] if error else "",
                duration_ms,
            )

        return entry

    def get_action_log(
        self,
        *,
        limit: int = 50,
        action: str | None = None,
        errors_only: bool = False,
    ) -> list[ActionLogEntry]:
        """Query the action log with optional filters."""
        result: list[ActionLogEntry] = []
        for entry in reversed(self._action_log):
            if action and entry.action != action:
                continue
            if errors_only and entry.result_ok is not False:
                continue
            result.append(entry)
            if len(result) >= limit:
                break
        return result

    def get_mode_history(self) -> list[dict[str, Any]]:
        """Return the history of mode switches."""
        return [{"mode": m.value, "switched_at": t} for m, t in self._mode_history]

    def clear_log(self) -> int:
        """Clear the action log. Returns count removed."""
        count = len(self._action_log)
        self._action_log.clear()
        return count

    def metrics(self) -> dict[str, Any]:
        return {
            "current_mode": self._config.mode.value,
            "debug_level": self._config.debug_level.value,
            "total_actions_logged": self.total_actions_logged,
            "total_mode_switches": self.total_mode_switches,
            "action_log_size": len(self._action_log),
        }
