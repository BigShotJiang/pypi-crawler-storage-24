"""Process-level singletons for browser infrastructure.

All modules (``browser_control``, ``browser.py`` REST router,
``browser_stream.py`` WebSocket router) **must** obtain
:class:`ChromeProcessManager`, :class:`SessionManager`, and
:class:`ProfileManager` instances through this module so that a single
Chrome process is shared across the entire application.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
from typing import Any

from .chrome_launcher import (
    CDPConnection,
    ChromeProcessManager,
    RunningChrome,
    connect_via_cdp,
    launch_playwright_fallback,
)
from .environment import find_chrome_executable
from .profiles import DEFAULT_PROFILE_NAME, BrowserProfile, ProfileManager
from .session import SessionManager

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Process-level singletons
# ---------------------------------------------------------------------------

_profile_manager: ProfileManager | None = None
_chrome_manager: ChromeProcessManager | None = None
_session_manager: SessionManager | None = None

# Lock to serialise browser launch/teardown across concurrent callers
_browser_lock = asyncio.Lock()

# Callbacks invoked when Chrome terminates unexpectedly.
# Signature: async def callback(profile_name: str) -> None
_chrome_exit_callbacks: list[Any] = []


def get_profile_manager() -> ProfileManager:
    """Return the global :class:`ProfileManager` (lazy-created)."""
    global _profile_manager
    if _profile_manager is None:
        _profile_manager = ProfileManager()
    return _profile_manager


def get_chrome_manager() -> ChromeProcessManager:
    """Return the global :class:`ChromeProcessManager` (lazy-created)."""
    global _chrome_manager
    if _chrome_manager is None:
        _chrome_manager = ChromeProcessManager()
    return _chrome_manager


def get_session_manager() -> SessionManager:
    """Return the global :class:`SessionManager` (lazy-created)."""
    global _session_manager
    if _session_manager is None:
        _session_manager = SessionManager()
    return _session_manager


# ---------------------------------------------------------------------------
# Unified browser acquisition
# ---------------------------------------------------------------------------


async def get_or_create_browser(
    profile_name: str = DEFAULT_PROFILE_NAME,
    *,
    headless: bool = True,
) -> tuple[RunningChrome | None, CDPConnection, BrowserProfile]:
    """Ensure a Chrome process is running for *profile_name* and return a CDP connection.

    If Chrome is already running for the requested profile the existing
    process is reused; otherwise a new one is launched via
    :class:`ChromeProcessManager`.

    Returns:
        A 3-tuple ``(running_chrome, cdp_connection, browser_profile)``.
        ``running_chrome`` may be ``None`` when the Playwright fallback is
        used (no native Chrome found).

    Raises:
        RuntimeError: If the browser cannot be started.
    """
    async with _browser_lock:
        pm = get_profile_manager()
        cm = get_chrome_manager()

        profile = pm.get_profile(profile_name)
        if not profile:
            profile = pm.create_profile(profile_name)

        # Already running? Just create a new CDP connection.
        if cm.is_running(profile_name):
            running = cm.get_running(profile_name)
            assert running is not None
            cdp_conn = await connect_via_cdp(running.cdp_port)
            pm.touch_used(profile_name)
            return running, cdp_conn, profile

        # Try native Chrome launch
        exe = find_chrome_executable()
        if exe:
            running = await cm.launch_chrome(profile, headed=not headless)
            cdp_conn = await connect_via_cdp(running.cdp_port)
            pm.touch_used(profile_name)
            start_chrome_exit_monitor()
            return running, cdp_conn, profile

        # Fallback: Playwright-managed Chromium (no persistent state)
        cdp_conn = await launch_playwright_fallback(headless=headless)
        pm.touch_used(profile_name)
        start_chrome_exit_monitor()
        return None, cdp_conn, profile


# ---------------------------------------------------------------------------
# Chrome exit monitoring
# ---------------------------------------------------------------------------


def register_chrome_exit_callback(callback: Any) -> None:
    """Register *callback* to be called when Chrome terminates unexpectedly.

    The callback signature should be
    ``async def callback(profile_name: str) -> None``.
    """
    _chrome_exit_callbacks.append(callback)


def unregister_chrome_exit_callback(callback: Any) -> None:
    """Remove a previously registered exit callback."""
    with contextlib.suppress(ValueError):
        _chrome_exit_callbacks.remove(callback)


async def _notify_chrome_exit(profile_name: str) -> None:
    """Invoke all registered exit callbacks."""
    for cb in _chrome_exit_callbacks:
        try:
            await cb(profile_name)
        except Exception as exc:
            logger.warning("Chrome exit callback error: %s", exc)


_monitor_task: asyncio.Task[None] | None = None


async def _chrome_exit_monitor_loop() -> None:
    """Background task that polls all managed Chrome processes.

    When a process terminates unexpectedly, notifies registered callbacks
    so that SSE/WebSocket consumers can inform the frontend.
    """
    cm = get_chrome_manager()
    while True:
        await asyncio.sleep(2.0)
        for profile_name in list(cm._processes.keys()):
            running = cm._processes.get(profile_name)
            if not running or not running.process:
                continue
            ret = running.process.poll()
            if ret is not None:
                logger.warning(
                    "Chrome process for profile '%s' exited unexpectedly (code=%s)",
                    profile_name,
                    ret,
                )
                cm._processes.pop(profile_name, None)
                await _notify_chrome_exit(profile_name)


def start_chrome_exit_monitor() -> None:
    """Start the background Chrome exit monitor if not already running.

    Safe to call multiple times; only one monitor task is created.
    Should be called once during application startup.
    """
    global _monitor_task
    if _monitor_task is not None and not _monitor_task.done():
        return
    try:
        loop = asyncio.get_running_loop()
        _monitor_task = loop.create_task(_chrome_exit_monitor_loop(), name="chrome-exit-monitor")
        logger.debug("Chrome exit monitor started")
    except RuntimeError:
        logger.debug("Cannot start exit monitor — no running event loop")


# ---------------------------------------------------------------------------
# Agent state bridge — tab synchronisation
# ---------------------------------------------------------------------------
# The Agent's ``_state`` dict lives in ``browser_control.py``.  Rather than
# importing it directly (which would create a circular dependency), we
# expose accessor functions that ``browser_control`` registers at import
# time.  ``BrowserStreamSession`` can then call these to read / mutate the
# Agent's page list.

_agent_state_getter: Any = None  # Callable[[], dict[str, Any]]
_enhancement_runtime_getter: Any = None  # Callable[[], Any]


def register_agent_state(getter: Any) -> None:
    """Register the Agent's global ``_state`` accessor.

    Called once by ``browser_control`` at module load.
    ``getter`` should be a callable that returns the ``_state`` dict.
    """
    global _agent_state_getter
    _agent_state_getter = getter


def get_agent_state() -> dict[str, Any] | None:
    """Return the Agent ``_state`` dict, or ``None`` if not registered."""
    if _agent_state_getter is None:
        return None
    try:
        return _agent_state_getter()
    except Exception:
        return None


def register_enhancement_runtime(getter: Any) -> None:
    """Register the browser enhancement runtime accessor."""
    global _enhancement_runtime_getter
    _enhancement_runtime_getter = getter


def get_enhancement_runtime() -> Any | None:
    """Return the shared browser enhancement runtime, or ``None``."""
    if _enhancement_runtime_getter is None:
        return None
    try:
        return _enhancement_runtime_getter()
    except Exception:
        return None
