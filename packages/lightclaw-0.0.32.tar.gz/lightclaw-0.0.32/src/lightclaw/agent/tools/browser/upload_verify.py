"""Post-upload verification helpers.

After files are injected into the FileChooser, this module provides
strategies to verify whether the target website actually accepted the
upload.  Verification is intentionally best-effort — it improves
confidence but the Agent should always follow up with a snapshot.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Verification result
# ---------------------------------------------------------------------------


@dataclass
class VerifyResult:
    """Outcome of a post-upload verification attempt."""

    verified: bool = False
    method: str = ""  # Which strategy succeeded
    detail: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "verified": self.verified,
            "method": self.method,
            "detail": self.detail,
        }


# ---------------------------------------------------------------------------
# JS snippets
# ---------------------------------------------------------------------------

_CHECK_UPLOAD_SUCCESS_JS = """
(() => {
    const signals = [];

    // 1. Success toast / message
    const toastSelectors = [
        '.ant-message-success',
        '.el-message--success',
        '.ant-notification-notice',
        '[class*="toast"][class*="success"]',
        '[class*="Toast"][class*="success"]',
    ];
    for (const sel of toastSelectors) {
        const el = document.querySelector(sel);
        if (el && el.offsetParent !== null) {
            signals.push({
                method: 'success_toast',
                detail: el.textContent?.trim().slice(0, 120) || sel,
            });
        }
    }

    // 2. Upload list items appeared
    const listSelectors = [
        '.ant-upload-list-item',
        '.el-upload-list__item',
        '[class*="upload-list"] [class*="item"]',
        '[class*="file-list"] [class*="item"]',
    ];
    for (const sel of listSelectors) {
        const els = document.querySelectorAll(sel);
        if (els.length > 0) {
            signals.push({
                method: 'upload_list',
                detail: `${els.length} item(s) in upload list (${sel})`,
            });
        }
    }

    // 3. Image preview appeared
    const previewSelectors = [
        '.ant-upload-list-item-image',
        '.ant-upload-list-item-thumbnail img',
        '[class*="preview"] img[src*="blob:"]',
        '[class*="preview"] img[src*="data:"]',
        '[class*="upload"] img[src*="blob:"]',
        '[class*="upload"] img[src*="data:"]',
    ];
    for (const sel of previewSelectors) {
        const els = document.querySelectorAll(sel);
        if (els.length > 0) {
            signals.push({
                method: 'image_preview',
                detail: `${els.length} preview image(s) (${sel})`,
            });
        }
    }

    // 4. Error indicators
    const errorSelectors = [
        '.ant-message-error',
        '.el-message--error',
        '.ant-upload-list-item-error',
        '[class*="upload"][class*="error"]',
        '[class*="upload"][class*="fail"]',
    ];
    for (const sel of errorSelectors) {
        const el = document.querySelector(sel);
        if (el && el.offsetParent !== null) {
            signals.push({
                method: 'error_indicator',
                detail: el.textContent?.trim().slice(0, 120) || sel,
            });
        }
    }

    return signals;
})()
"""


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


async def verify_upload(
    page: Any,
    *,
    wait_seconds: float = 3.0,
    poll_interval: float = 0.5,
) -> VerifyResult:
    """Poll the page for upload success/failure signals.

    Waits up to *wait_seconds*, polling every *poll_interval*.  Returns as
    soon as a conclusive signal is found.
    """
    elapsed = 0.0
    last_signals: list[dict[str, str]] = []

    while elapsed < wait_seconds:
        try:
            raw = await page.evaluate(_CHECK_UPLOAD_SUCCESS_JS)
            if isinstance(raw, list):
                last_signals = raw
        except Exception as exc:
            logger.debug("verify_upload JS eval error: %s", exc)
            # Page might be navigating — wait and retry
            await asyncio.sleep(poll_interval)
            elapsed += poll_interval
            continue

        # Check for conclusive signals.
        for sig in last_signals:
            method = sig.get("method", "")
            detail = sig.get("detail", "")

            if method == "error_indicator":
                return VerifyResult(
                    verified=False,
                    method=method,
                    detail=f"Upload error detected: {detail}",
                )

            if method in ("success_toast", "upload_list", "image_preview"):
                return VerifyResult(
                    verified=True,
                    method=method,
                    detail=detail,
                )

        await asyncio.sleep(poll_interval)
        elapsed += poll_interval

    # Timeout — inconclusive.
    if last_signals:
        return VerifyResult(
            verified=False,
            method="timeout",
            detail=("Timed out; last signals: " + "; ".join(s.get("detail", "") for s in last_signals[:3])),
        )

    return VerifyResult(
        verified=False,
        method="timeout",
        detail=(f"No upload signals detected after {wait_seconds}s. Take a snapshot to check the page state."),
    )
