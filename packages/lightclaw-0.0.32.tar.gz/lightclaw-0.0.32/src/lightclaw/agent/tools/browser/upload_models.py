"""Structured models for the browser file-upload pipeline.

Defines input params, result envelopes, error codes and upload phases
so that every layer — from Agent tool to API router — speaks the same
protocol.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

# ---------------------------------------------------------------------------
# Upload phase
# ---------------------------------------------------------------------------


class UploadPhase(StrEnum):
    """Ordered phases that a file-upload request passes through."""

    RESOLVE = "resolve"  # Locate the file on the server
    VALIDATE = "validate"  # Check existence, type, size, permissions
    CHOOSER_WAIT = "chooser_wait"  # Wait for a pending FileChooser
    INJECT = "inject"  # Set files on the FileChooser
    VERIFY = "verify"  # Post-injection page-level verification
    DONE = "done"  # Successfully completed


# ---------------------------------------------------------------------------
# Error codes
# ---------------------------------------------------------------------------


class UploadErrorCode(StrEnum):
    """Machine-readable error codes returned by the upload pipeline."""

    # File resolution
    FILE_NOT_FOUND = "file_not_found"
    PATH_NOT_ALLOWED = "path_not_allowed"
    PATH_TRAVERSAL = "path_traversal"
    TOO_MANY_CANDIDATES = "too_many_candidates"
    PERMISSION_DENIED = "permission_denied"

    # File validation
    INVALID_TYPE = "invalid_type"
    FILE_TOO_LARGE = "file_too_large"
    FILE_UNREADABLE = "file_unreadable"

    # Browser interaction
    NO_ACTIVE_PAGE = "no_active_page"
    NO_FILE_CHOOSER = "no_file_chooser"
    CHOOSER_EXPIRED = "chooser_expired"
    PAGE_NAVIGATED = "page_navigated"

    # Verification
    VERIFICATION_TIMEOUT = "verification_timeout"
    UPLOAD_REJECTED = "upload_rejected"

    # Generic
    UNKNOWN = "unknown"


# ---------------------------------------------------------------------------
# Input models
# ---------------------------------------------------------------------------


@dataclass
class UploadFileSpec:
    """A single file to be uploaded.

    *path* is the resolved absolute path on the server.
    *identifier* is an optional logical name (e.g. "header-image") that the
    Agent uses when the path is not yet known.
    """

    path: str = ""
    identifier: str = ""

    def to_dict(self) -> dict[str, str]:
        d: dict[str, str] = {}
        if self.path:
            d["path"] = self.path
        if self.identifier:
            d["identifier"] = self.identifier
        return d


@dataclass
class UploadRequest:
    """Everything the upload pipeline needs to begin work."""

    files: list[UploadFileSpec] = field(default_factory=list)
    page_id: str = "default"
    # Optional: base directory hint when identifiers are used
    base_directory: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "files": [f.to_dict() for f in self.files],
            "page_id": self.page_id,
            "base_directory": self.base_directory,
        }


# ---------------------------------------------------------------------------
# Result models
# ---------------------------------------------------------------------------


@dataclass
class UploadResult:
    """Structured outcome of an upload attempt."""

    ok: bool = False
    phase: UploadPhase = UploadPhase.RESOLVE
    error_code: UploadErrorCode | None = None
    error_message: str = ""
    files_injected: int = 0
    resolved_paths: list[str] = field(default_factory=list)
    page_context: str = ""  # e.g. current URL or page title

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "ok": self.ok,
            "phase": self.phase.value,
            "files_injected": self.files_injected,
        }
        if self.error_code is not None:
            d["error_code"] = self.error_code.value
        if self.error_message:
            d["error_message"] = self.error_message
        if self.resolved_paths:
            d["resolved_paths"] = self.resolved_paths
        if self.page_context:
            d["page_context"] = self.page_context
        return d

    # -- Convenience factory helpers ----------------------------------------

    @classmethod
    def success(
        cls,
        *,
        files_injected: int,
        resolved_paths: list[str] | None = None,
        page_context: str = "",
    ) -> UploadResult:
        return cls(
            ok=True,
            phase=UploadPhase.DONE,
            files_injected=files_injected,
            resolved_paths=resolved_paths or [],
            page_context=page_context,
        )

    @classmethod
    def failure(
        cls,
        *,
        phase: UploadPhase,
        error_code: UploadErrorCode,
        error_message: str = "",
        page_context: str = "",
    ) -> UploadResult:
        return cls(
            ok=False,
            phase=phase,
            error_code=error_code,
            error_message=error_message,
            page_context=page_context,
        )
