"""Structured audit logging for the upload pipeline.

Emits events at each upload phase so that diagnostic tools, API
responses and log aggregators can trace the full lifecycle of an
upload attempt.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any

from .upload_models import UploadErrorCode, UploadPhase

logger = logging.getLogger(__name__)


@dataclass
class UploadAuditEvent:
    """A single immutable record of an upload lifecycle event."""

    timestamp: float = field(default_factory=time.time)
    session_id: str = ""
    page_id: str = ""
    phase: str = ""
    status: str = ""  # "start" | "ok" | "fail"
    file_count: int = 0
    error_code: str = ""
    error_message: str = ""
    page_url: str = ""
    elapsed_ms: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "timestamp": self.timestamp,
            "phase": self.phase,
            "status": self.status,
        }
        if self.session_id:
            d["session_id"] = self.session_id
        if self.page_id:
            d["page_id"] = self.page_id
        if self.file_count:
            d["file_count"] = self.file_count
        if self.error_code:
            d["error_code"] = self.error_code
        if self.error_message:
            d["error_message"] = self.error_message
        if self.page_url:
            d["page_url"] = self.page_url
        if self.elapsed_ms:
            d["elapsed_ms"] = round(self.elapsed_ms, 2)
        return d


class UploadAuditLog:
    """Collects audit events for a single upload attempt."""

    def __init__(self, session_id: str = "", page_id: str = "") -> None:
        self.session_id = session_id
        self.page_id = page_id
        self.events: list[UploadAuditEvent] = []
        self._start_time = time.monotonic()

    def record(
        self,
        phase: UploadPhase | str,
        status: str,
        *,
        file_count: int = 0,
        error_code: UploadErrorCode | str = "",
        error_message: str = "",
        page_url: str = "",
    ) -> UploadAuditEvent:
        """Append and return a new audit event."""
        phase_str = phase.value if isinstance(phase, UploadPhase) else phase
        code_str = error_code.value if isinstance(error_code, UploadErrorCode) else error_code
        elapsed = (time.monotonic() - self._start_time) * 1000

        event = UploadAuditEvent(
            session_id=self.session_id,
            page_id=self.page_id,
            phase=phase_str,
            status=status,
            file_count=file_count,
            error_code=code_str,
            error_message=error_message,
            page_url=page_url,
            elapsed_ms=elapsed,
        )
        self.events.append(event)

        # Also emit a structured log line.
        log_fn = logger.info if status != "fail" else logger.warning
        log_fn(
            "UploadAudit [%s] phase=%s status=%s files=%d err=%s (%.1fms)",
            self.session_id[:8] if self.session_id else "-",
            phase_str,
            status,
            file_count,
            code_str or "-",
            elapsed,
        )
        return event

    def to_list(self) -> list[dict[str, Any]]:
        """Serialise the full trail for API responses."""
        return [e.to_dict() for e in self.events]
