"""Unified metrics aggregation and data governance for browser enhancement.

Implements requirement 10: aggregate metrics from all enhancement modules,
provide TTL-based data governance, and expose a single snapshot endpoint.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger(__name__)

DEFAULT_DATA_TTL = 3600.0  # 1 hour


@dataclass(slots=True)
class GovernancePolicy:
    """Data governance configuration."""

    snapshot_cache_ttl: float = 300.0  # 5 min
    ref_map_max_entries: int = 500
    debug_log_max_entries: int = 200
    loop_detector_window: int = 20
    handoff_history_max: int = 50
    action_log_max: int = 100
    metrics_retention: float = DEFAULT_DATA_TTL

    def to_dict(self) -> dict[str, Any]:
        return {
            "snapshot_cache_ttl": self.snapshot_cache_ttl,
            "ref_map_max_entries": self.ref_map_max_entries,
            "debug_log_max_entries": self.debug_log_max_entries,
            "loop_detector_window": self.loop_detector_window,
            "handoff_history_max": self.handoff_history_max,
            "action_log_max": self.action_log_max,
            "metrics_retention": self.metrics_retention,
        }


class MetricsAggregator:
    """Aggregates metrics from all browser enhancement modules.

    Acts as a single point to collect, snapshot, and periodically
    prune stale data across all subsystems.
    """

    def __init__(self, policy: GovernancePolicy | None = None) -> None:
        self._policy = policy or GovernancePolicy()
        self._module_metrics: dict[str, dict[str, Any]] = {}
        self._last_snapshot_at: float | None = None
        self._created_at: float = time.time()

        # Counters
        self.total_snapshots: int = 0
        self.total_prune_runs: int = 0

    @property
    def policy(self) -> GovernancePolicy:
        return self._policy

    def register_module(self, name: str, metrics_fn: Any) -> None:
        """Register a module's metrics callable.

        ``metrics_fn`` should be a callable that returns a ``dict``.
        """
        self._module_metrics[name] = {"fn": metrics_fn, "last_value": {}}

    def collect(self) -> dict[str, Any]:
        """Collect metrics from all registered modules."""
        result: dict[str, Any] = {
            "collected_at": time.time(),
            "uptime_seconds": time.time() - self._created_at,
            "total_snapshots": self.total_snapshots,
            "total_prune_runs": self.total_prune_runs,
            "governance_policy": self._policy.to_dict(),
            "modules": {},
        }

        for name, entry in self._module_metrics.items():
            try:
                metrics = entry["fn"]()
                entry["last_value"] = metrics
                result["modules"][name] = metrics
            except Exception as exc:
                logger.warning("Failed to collect metrics from %s: %s", name, exc)
                result["modules"][name] = {"error": str(exc)}

        self._last_snapshot_at = time.time()
        self.total_snapshots += 1
        return result

    def get_module_metrics(self, name: str) -> dict[str, Any]:
        """Return cached metrics for a specific module."""
        entry = self._module_metrics.get(name)
        if entry is None:
            return {}
        return dict(entry.get("last_value", {}))

    def prune_stale_data(
        self,
        *,
        snapshot_cache: Any = None,
        ref_map_store: Any = None,
        debug_event_log: Any = None,
        loop_detector: Any = None,
        execution_mode_manager: Any = None,
    ) -> dict[str, int]:
        """Run data governance: prune stale entries across modules.

        Each module argument is optional. Only modules that are passed
        will be pruned.

        Returns a dict of ``{module_name: items_removed}``.
        """
        results: dict[str, int] = {}

        if snapshot_cache is not None:
            try:
                removed = snapshot_cache.invalidate_all()
                results["snapshot_cache"] = removed
            except Exception as exc:
                logger.warning("Snapshot cache pruning failed: %s", exc)
                results["snapshot_cache"] = -1

        if ref_map_store is not None:
            try:
                removed = ref_map_store.prune(max_entries=self._policy.ref_map_max_entries)
                results["ref_map"] = removed
            except Exception as exc:
                logger.warning("RefMap pruning failed: %s", exc)
                results["ref_map"] = -1

        if debug_event_log is not None:
            try:
                removed = debug_event_log.clear()
                results["debug_event_log"] = removed
            except Exception as exc:
                logger.warning("Debug event log pruning failed: %s", exc)
                results["debug_event_log"] = -1

        if loop_detector is not None:
            try:
                loop_detector.clear()
                results["loop_detector"] = 0
            except Exception as exc:
                logger.warning("Loop detector pruning failed: %s", exc)
                results["loop_detector"] = -1

        if execution_mode_manager is not None:
            try:
                removed = execution_mode_manager.clear_log()
                results["execution_mode"] = removed
            except Exception as exc:
                logger.warning("Execution mode log pruning failed: %s", exc)
                results["execution_mode"] = -1

        self.total_prune_runs += 1
        logger.info("Data governance prune completed: %s", results)
        return results

    def summary(self) -> dict[str, Any]:
        """Return a lightweight summary without re-collecting."""
        return {
            "registered_modules": list(self._module_metrics.keys()),
            "last_snapshot_at": self._last_snapshot_at,
            "total_snapshots": self.total_snapshots,
            "total_prune_runs": self.total_prune_runs,
            "uptime_seconds": time.time() - self._created_at,
        }
