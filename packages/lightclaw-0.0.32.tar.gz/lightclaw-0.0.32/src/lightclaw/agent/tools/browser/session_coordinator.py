"""Enhanced session coordination for remote browser, handoff, and human takeover.

Implements requirement 8: coordinate enhancement runtime state with
session handoff, auto-handoff triggers from blocking signal detection,
and post-handoff re-sync.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

logger = logging.getLogger(__name__)


class HandoffTrigger(StrEnum):
    """Reasons for initiating a control handoff."""

    AUTH_DETECTED = "auth_detected"
    CAPTCHA_DETECTED = "captcha_detected"
    PERMISSION_DENIED = "permission_denied"
    MANUAL_REQUEST = "manual_request"
    RECOVERY_ESCALATION = "recovery_escalation"
    API_REQUEST = "api_request"


class HandoffDirection(StrEnum):
    """Direction of a handoff."""

    AGENT_TO_USER = "agent_to_user"
    USER_TO_AGENT = "user_to_agent"


@dataclass(slots=True)
class HandoffEvent:
    """Record of a handoff event."""

    direction: HandoffDirection
    trigger: HandoffTrigger
    session_id: str = ""
    page_id: str = ""
    page_url: str = ""
    detail: str = ""
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        return {
            "direction": self.direction.value,
            "trigger": self.trigger.value,
            "session_id": self.session_id,
            "page_id": self.page_id,
            "page_url": self.page_url,
            "detail": self.detail,
            "timestamp": self.timestamp,
        }


@dataclass(slots=True)
class HandoffCoordinationResult:
    """Result of a coordination check."""

    should_handoff: bool = False
    trigger: HandoffTrigger = HandoffTrigger.MANUAL_REQUEST
    reason: str = ""
    blocking_type: str = ""
    confidence: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "should_handoff": self.should_handoff,
            "trigger": self.trigger.value,
            "reason": self.reason,
            "blocking_type": self.blocking_type,
            "confidence": self.confidence,
        }


class SessionCoordinator:
    """Coordinates enhancement runtime decisions with session handoff.

    - Evaluates blocking signals to recommend auto-handoff
    - Records handoff events for auditing
    - Provides post-handoff state re-synchronisation helpers
    """

    def __init__(self) -> None:
        self._history: list[HandoffEvent] = []
        self._auto_handoff_enabled: bool = True

        # Metrics
        self.total_auto_handoffs: int = 0
        self.total_manual_handoffs: int = 0
        self.total_returns: int = 0

    @property
    def auto_handoff_enabled(self) -> bool:
        return self._auto_handoff_enabled

    @auto_handoff_enabled.setter
    def auto_handoff_enabled(self, value: bool) -> None:
        self._auto_handoff_enabled = value

    def evaluate_for_handoff(
        self,
        blocking_signals: list[dict[str, Any]],
        *,
        current_owner: str = "agent",
    ) -> HandoffCoordinationResult:
        """Evaluate blocking signals and decide whether handoff is needed.

        ``blocking_signals`` should be a list of dicts with keys
        ``signal_type``, ``confidence``, ``detail``.
        """
        if current_owner != "agent":
            return HandoffCoordinationResult(
                should_handoff=False,
                reason="user_already_in_control",
            )

        if not self._auto_handoff_enabled:
            return HandoffCoordinationResult(
                should_handoff=False,
                reason="auto_handoff_disabled",
            )

        # Check for blocking signals that warrant handoff
        for signal in blocking_signals:
            signal_type = signal.get("signal_type", signal.get("type", ""))
            confidence = float(signal.get("confidence", 0.0))

            if signal_type in ("login_prompt", "captcha") and confidence >= 0.4:
                trigger = (
                    HandoffTrigger.AUTH_DETECTED if signal_type == "login_prompt" else HandoffTrigger.CAPTCHA_DETECTED
                )
                return HandoffCoordinationResult(
                    should_handoff=True,
                    trigger=trigger,
                    reason=f"Blocking signal: {signal_type}",
                    blocking_type=signal_type,
                    confidence=confidence,
                )

            if signal_type == "permission_denied" and confidence >= 0.6:
                return HandoffCoordinationResult(
                    should_handoff=True,
                    trigger=HandoffTrigger.PERMISSION_DENIED,
                    reason="Access denied, user intervention needed",
                    blocking_type=signal_type,
                    confidence=confidence,
                )

        return HandoffCoordinationResult(
            should_handoff=False,
            reason="no_blocking_signals",
        )

    def evaluate_recovery_escalation(
        self,
        *,
        escalated: bool,
        current_owner: str = "agent",
    ) -> HandoffCoordinationResult:
        """Evaluate whether recovery escalation should trigger handoff."""
        if not escalated or current_owner != "agent":
            return HandoffCoordinationResult(should_handoff=False)

        return HandoffCoordinationResult(
            should_handoff=True,
            trigger=HandoffTrigger.RECOVERY_ESCALATION,
            reason="Recovery exhausted all strategies, escalating to user",
            confidence=1.0,
        )

    def record_handoff(
        self,
        *,
        direction: HandoffDirection,
        trigger: HandoffTrigger,
        session_id: str = "",
        page_id: str = "",
        page_url: str = "",
        detail: str = "",
    ) -> HandoffEvent:
        """Record a handoff event."""
        event = HandoffEvent(
            direction=direction,
            trigger=trigger,
            session_id=session_id,
            page_id=page_id,
            page_url=page_url,
            detail=detail,
        )
        self._history.append(event)

        if direction == HandoffDirection.AGENT_TO_USER:
            if trigger in (
                HandoffTrigger.AUTH_DETECTED,
                HandoffTrigger.CAPTCHA_DETECTED,
                HandoffTrigger.PERMISSION_DENIED,
                HandoffTrigger.RECOVERY_ESCALATION,
            ):
                self.total_auto_handoffs += 1
            else:
                self.total_manual_handoffs += 1
        else:
            self.total_returns += 1

        logger.info(
            "Handoff recorded: direction=%s trigger=%s session=%s",
            direction.value,
            trigger.value,
            session_id,
        )
        return event

    def get_history(self, *, limit: int = 20) -> list[HandoffEvent]:
        """Return recent handoff events."""
        return list(self._history[-limit:])

    def metrics(self) -> dict[str, Any]:
        return {
            "total_auto_handoffs": self.total_auto_handoffs,
            "total_manual_handoffs": self.total_manual_handoffs,
            "total_returns": self.total_returns,
            "history_length": len(self._history),
            "auto_handoff_enabled": self._auto_handoff_enabled,
        }
