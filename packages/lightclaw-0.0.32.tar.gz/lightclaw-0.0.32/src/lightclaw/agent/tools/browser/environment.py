"""Runtime environment detection, Chrome executable discovery, system
dependency checking, and Chrome launch-flag assembly.

Ported from openclaw/src/browser/chrome.executables.ts and
openclaw/sandbox-browser-entrypoint.sh to Python.
"""

from __future__ import annotations

import logging
import os
import platform
import shutil
import subprocess
from dataclasses import dataclass, field
from typing import Literal

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Type aliases
# ---------------------------------------------------------------------------
DisplayEnvironment = Literal["desktop", "headless-server"]

BrowserKind = Literal[
    "chrome",
    "brave",
    "edge",
    "chromium",
    "canary",
    "custom",
]


@dataclass
class BrowserExecutable:
    """Describes a discovered browser binary."""

    kind: BrowserKind
    path: str


@dataclass
class DependencyCheckResult:
    """Result of a system dependency check."""

    ok: bool
    missing: list[str] = field(default_factory=list)
    install_command: str = ""


# ---------------------------------------------------------------------------
# Display environment detection
# ---------------------------------------------------------------------------


def detect_display_environment() -> DisplayEnvironment:
    """Detect whether the host has a graphical display.

    Returns ``'desktop'`` when a usable display is available (macOS, X11,
    Wayland) and ``'headless-server'`` otherwise.
    """
    system = platform.system()

    # macOS always has a display (even headless Macs expose quartz)
    if system == "Darwin":
        return "desktop"

    # Linux: check for active display server
    if system == "Linux":
        # Wayland
        if os.environ.get("WAYLAND_DISPLAY"):
            return "desktop"
        # X11
        display = os.environ.get("DISPLAY")
        if display:
            return "desktop"
        return "headless-server"

    # Fallback for other platforms (Windows always has a display when running)
    if system == "Windows":
        return "desktop"

    return "headless-server"


# ---------------------------------------------------------------------------
# Chrome executable discovery
# ---------------------------------------------------------------------------

# macOS candidates (priority order: Chrome > Brave > Edge > Chromium > Canary)
_MAC_CANDIDATES: list[tuple[BrowserKind, str]] = [
    ("chrome", "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
    (
        "chrome",
        os.path.expanduser(
            "~/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        ),
    ),
    ("brave", "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser"),
    (
        "brave",
        os.path.expanduser(
            "~/Applications/Brave Browser.app/Contents/MacOS/Brave Browser",
        ),
    ),
    ("edge", "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"),
    (
        "edge",
        os.path.expanduser(
            "~/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
        ),
    ),
    ("chromium", "/Applications/Chromium.app/Contents/MacOS/Chromium"),
    (
        "chromium",
        os.path.expanduser(
            "~/Applications/Chromium.app/Contents/MacOS/Chromium",
        ),
    ),
    ("canary", "/Applications/Google Chrome Canary.app/Contents/MacOS/Google Chrome Canary"),
    (
        "canary",
        os.path.expanduser(
            "~/Applications/Google Chrome Canary.app/Contents/MacOS/Google Chrome Canary",
        ),
    ),
]

# Linux candidates (priority order matching openclaw)
_LINUX_CANDIDATES: list[tuple[BrowserKind, str]] = [
    ("chrome", "/usr/bin/google-chrome"),
    ("chrome", "/usr/bin/google-chrome-stable"),
    ("chrome", "/usr/bin/chrome"),
    ("brave", "/usr/bin/brave-browser"),
    ("brave", "/usr/bin/brave-browser-stable"),
    ("brave", "/usr/bin/brave"),
    ("brave", "/snap/bin/brave"),
    ("edge", "/usr/bin/microsoft-edge"),
    ("edge", "/usr/bin/microsoft-edge-stable"),
    ("chromium", "/usr/bin/chromium"),
    ("chromium", "/usr/bin/chromium-browser"),
    ("chromium", "/snap/bin/chromium"),
]


def _find_first_executable(
    candidates: list[tuple[BrowserKind, str]],
) -> BrowserExecutable | None:
    """Return the first candidate whose path exists on disk."""
    for kind, path in candidates:
        if os.path.isfile(path) and os.access(path, os.X_OK):
            return BrowserExecutable(kind=kind, path=path)
    return None


def find_chrome_executable(
    explicit_path: str | None = None,
) -> BrowserExecutable | None:
    """Discover a Chromium-based browser on the current platform.

    Args:
        explicit_path: If given, use this path directly (``custom`` kind).

    Returns:
        A :class:`BrowserExecutable` or ``None`` if nothing is found.
    """
    if explicit_path:
        if os.path.isfile(explicit_path) and os.access(explicit_path, os.X_OK):
            return BrowserExecutable(kind="custom", path=explicit_path)
        logger.warning(
            "Explicit browser path %s not found or not executable",
            explicit_path,
        )
        return None

    # Also try the PATH as last resort via shutil.which
    system = platform.system()
    if system == "Darwin":
        result = _find_first_executable(_MAC_CANDIDATES)
        if result:
            return result
    elif system == "Linux":
        result = _find_first_executable(_LINUX_CANDIDATES)
        if result:
            return result

    # Fallback: try PATH lookup
    for name in ("google-chrome", "google-chrome-stable", "chromium-browser", "chromium"):
        found = shutil.which(name)
        if found:
            kind: BrowserKind = "chrome" if "chrome" in name else "chromium"
            return BrowserExecutable(kind=kind, path=found)

    return None


# ---------------------------------------------------------------------------
# System dependency checking (Linux only)
# ---------------------------------------------------------------------------

# Required shared libraries for Chrome on Ubuntu/Debian
_REQUIRED_LINUX_PACKAGES = [
    "libnss3",
    "libatk-bridge2.0-0",
    "libatk1.0-0",
    "libcups2",
    "libdrm2",
    "libxkbcommon0",
    "libxcomposite1",
    "libxdamage1",
    "libxrandr2",
    "libgbm1",
    "libpango-1.0-0",
    "libasound2",
]


def check_system_dependencies() -> DependencyCheckResult:
    """Check Chrome runtime library dependencies on Linux.

    On non-Linux systems, always returns ``ok=True``.
    """
    if platform.system() != "Linux":
        return DependencyCheckResult(ok=True)

    dpkg = shutil.which("dpkg")
    if not dpkg:
        # Cannot check — assume OK
        logger.debug("dpkg not found; skipping dependency check")
        return DependencyCheckResult(ok=True)

    missing: list[str] = []
    for pkg in _REQUIRED_LINUX_PACKAGES:
        try:
            result = subprocess.run(
                [dpkg, "-s", pkg],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode != 0:
                missing.append(pkg)
        except (subprocess.TimeoutExpired, FileNotFoundError):
            missing.append(pkg)

    if not missing:
        return DependencyCheckResult(ok=True)

    install_cmd = f"sudo apt install -y {' '.join(missing)}"
    return DependencyCheckResult(
        ok=False,
        missing=missing,
        install_command=install_cmd,
    )


# ---------------------------------------------------------------------------
# Chrome launch flags
# ---------------------------------------------------------------------------

# Base flags used in all environments
_BASE_FLAGS = [
    "--disable-background-networking",
    "--disable-background-timer-throttling",
    "--disable-backgrounding-occluded-windows",
    "--disable-breakpad",
    "--disable-component-extensions-with-background-pages",
    "--disable-component-update",
    "--disable-default-apps",
    "--disable-extensions",
    "--disable-hang-monitor",
    "--disable-ipc-flooding-protection",
    "--disable-popup-blocking",
    "--disable-prompt-on-repost",
    "--disable-renderer-backgrounding",
    "--disable-sync",
    "--enable-features=NetworkService,NetworkServiceInProcess",
    "--force-color-profile=srgb",
    "--metrics-recording-only",
    "--no-first-run",
    "--password-store=basic",
    "--use-mock-keychain",
]

# Extra flags for headless-server environments (Ubuntu Server, Docker, etc.)
_HEADLESS_SERVER_FLAGS = [
    "--headless=new",
    "--no-sandbox",
    "--disable-gpu",
    "--disable-dev-shm-usage",
    "--disable-software-rasterizer",
    "--no-zygote",
]


def build_chrome_flags(
    *,
    headless: bool = True,
    environment: DisplayEnvironment | None = None,
    cdp_port: int = 18800,
    user_data_dir: str = "",
    extra_flags: list[str] | None = None,
) -> list[str]:
    """Assemble Chrome command-line flags.

    Args:
        headless: Whether to use headless mode.
        environment: Override auto-detected environment.
        cdp_port: CDP remote-debugging port.
        user_data_dir: Path for ``--user-data-dir``.
        extra_flags: Additional flags to append.

    Returns:
        A list of flag strings (no executable path).
    """
    env = environment or detect_display_environment()
    flags = list(_BASE_FLAGS)

    if env == "headless-server":
        # On a headless server we always add server-specific flags
        flags.extend(_HEADLESS_SERVER_FLAGS)
    elif headless:
        # Desktop but caller wants headless
        flags.append("--headless=new")

    # Chrome refuses to run as root without --no-sandbox on Linux.
    # Always add it when running as root, regardless of environment.
    if os.getuid() == 0 and "--no-sandbox" not in flags:
        flags.append("--no-sandbox")

    flags.append(f"--remote-debugging-port={cdp_port}")

    if user_data_dir:
        flags.append(f"--user-data-dir={user_data_dir}")

    if extra_flags:
        flags.extend(extra_flags)

    return flags
