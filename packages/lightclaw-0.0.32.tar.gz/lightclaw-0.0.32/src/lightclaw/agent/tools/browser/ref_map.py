"""RefMap: stable element mapping storage, matching, and learning.

Implements requirement 4: RefMap hit, learning, and invalidation governance.
"""

from __future__ import annotations

import json
import logging
import os
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# Consecutive failures before a mapping is auto-disabled
MAX_CONSECUTIVE_FAILURES = 3

# Default RefMap data directory
DEFAULT_REFMAP_DIR = os.path.expanduser("~/.lightclaw/refmap")


@dataclass(slots=True)
class RefMapEntry:
    """A single stable element mapping for a site + action combination."""

    site: str
    action_name: str
    selector_type: str  # "role", "css", "xpath"
    selector_value: str
    role: str = ""
    name: str = ""
    nth: int = 0
    version: int = 1
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    success_count: int = 0
    failure_count: int = 0
    consecutive_failures: int = 0
    disabled: bool = False
    disabled_reason: str = ""

    @property
    def confidence(self) -> float:
        """Confidence score based on success/failure ratio."""
        total = self.success_count + self.failure_count
        if total == 0:
            return 0.5  # neutral for untested entries
        return self.success_count / total

    @property
    def suspicious(self) -> bool:
        """True if the entry has too many consecutive failures."""
        return self.consecutive_failures >= MAX_CONSECUTIVE_FAILURES

    def record_success(self) -> None:
        """Record a successful use of this mapping."""
        self.success_count += 1
        self.consecutive_failures = 0
        self.updated_at = time.time()

    def record_failure(self) -> None:
        """Record a failed use of this mapping."""
        self.failure_count += 1
        self.consecutive_failures += 1
        self.updated_at = time.time()
        if self.consecutive_failures >= MAX_CONSECUTIVE_FAILURES:
            self.disabled = True
            self.disabled_reason = f"auto_disabled_after_{self.consecutive_failures}_consecutive_failures"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class RefMapLookupResult:
    """Result of a RefMap lookup attempt."""

    hit: bool
    entry: RefMapEntry | None = None
    reason: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "hit": self.hit,
            "reason": self.reason,
            "entry": self.entry.to_dict() if self.entry else None,
        }


def _make_key(site: str, action_name: str) -> str:
    """Create a lookup key from site and action name."""
    return f"{site.lower().strip()}::{action_name.strip()}"


class RefMapStore:
    """In-memory RefMap store with optional file persistence.

    Manages stable element mappings per site and action, supporting
    lookup, learning (write-back), and automatic failure-based disabling.
    """

    def __init__(self, *, persist_dir: str | None = None) -> None:
        self._entries: dict[str, list[RefMapEntry]] = {}
        self._persist_dir = persist_dir

        # Metrics
        self.total_hits: int = 0
        self.total_misses: int = 0
        self.total_writes: int = 0
        self.total_disables: int = 0

    # -- lookup -------------------------------------------------------------

    def lookup(self, site: str, action_name: str) -> RefMapLookupResult:
        """Try to find a valid RefMap entry for *site* + *action_name*.

        Returns the highest-confidence non-disabled entry.
        """
        key = _make_key(site, action_name)
        entries = self._entries.get(key, [])

        if not entries:
            self.total_misses += 1
            return RefMapLookupResult(hit=False, reason="no_mapping")

        # Filter to enabled entries
        active = [e for e in entries if not e.disabled]
        if not active:
            self.total_misses += 1
            return RefMapLookupResult(hit=False, reason="all_disabled")

        # Pick highest confidence
        best = max(active, key=lambda e: e.confidence)
        self.total_hits += 1
        return RefMapLookupResult(hit=True, entry=best, reason="refmap_hit")

    # -- write-back ---------------------------------------------------------

    def add_or_update(
        self,
        *,
        site: str,
        action_name: str,
        selector_type: str,
        selector_value: str,
        role: str = "",
        name: str = "",
        nth: int = 0,
    ) -> RefMapEntry:
        """Add a new mapping or update an existing one.

        If a matching entry already exists (same selector), increment its
        version and reset failure counts.
        """
        key = _make_key(site, action_name)
        entries = self._entries.setdefault(key, [])

        # Check for existing match
        for entry in entries:
            if entry.selector_type == selector_type and entry.selector_value == selector_value:
                entry.version += 1
                entry.updated_at = time.time()
                entry.consecutive_failures = 0
                entry.disabled = False
                entry.disabled_reason = ""
                entry.role = role or entry.role
                entry.name = name or entry.name
                self.total_writes += 1
                return entry

        # New entry
        new_entry = RefMapEntry(
            site=site,
            action_name=action_name,
            selector_type=selector_type,
            selector_value=selector_value,
            role=role,
            name=name,
            nth=nth,
        )
        entries.append(new_entry)
        self.total_writes += 1
        return new_entry

    def record_success(self, site: str, action_name: str) -> None:
        """Record success for the best mapping of site + action."""
        result = self.lookup(site, action_name)
        if result.entry:
            result.entry.record_success()

    def record_failure(self, site: str, action_name: str) -> None:
        """Record failure for the best mapping of site + action."""
        key = _make_key(site, action_name)
        entries = self._entries.get(key, [])
        active = [e for e in entries if not e.disabled]
        if active:
            best = max(active, key=lambda e: e.confidence)
            best.record_failure()
            if best.disabled:
                self.total_disables += 1

    # -- management ---------------------------------------------------------

    def list_entries(
        self,
        *,
        site: str | None = None,
        include_disabled: bool = False,
    ) -> list[RefMapEntry]:
        """List all entries, optionally filtered by site."""
        result: list[RefMapEntry] = []
        for entries in self._entries.values():
            for entry in entries:
                if not include_disabled and entry.disabled:
                    continue
                if site and entry.site.lower() != site.lower():
                    continue
                result.append(entry)
        return result

    def remove(self, site: str, action_name: str) -> int:
        """Remove all entries for a site + action. Returns count removed."""
        key = _make_key(site, action_name)
        entries = self._entries.pop(key, [])
        return len(entries)

    def clear(self) -> int:
        """Remove all entries. Returns count removed."""
        count = sum(len(v) for v in self._entries.values())
        self._entries.clear()
        return count

    def metrics(self) -> dict[str, Any]:
        """Return RefMap performance metrics."""
        total = self.total_hits + self.total_misses
        all_entries = self.list_entries(include_disabled=True)
        return {
            "total_hits": self.total_hits,
            "total_misses": self.total_misses,
            "total_writes": self.total_writes,
            "total_disables": self.total_disables,
            "hit_rate": self.total_hits / total if total > 0 else 0.0,
            "total_entries": len(all_entries),
            "active_entries": len([e for e in all_entries if not e.disabled]),
            "disabled_entries": len([e for e in all_entries if e.disabled]),
        }

    # -- persistence --------------------------------------------------------

    def save(self, path: str | None = None) -> str:
        """Save all entries to a JSON file. Returns the file path used."""
        file_path = path or self._default_path()
        Path(file_path).parent.mkdir(parents=True, exist_ok=True)

        data: list[dict[str, Any]] = []
        for entries in self._entries.values():
            for entry in entries:
                data.append(entry.to_dict())

        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

        logger.debug("RefMap saved %d entries to %s", len(data), file_path)
        return file_path

    def load(self, path: str | None = None) -> int:
        """Load entries from a JSON file. Returns the number loaded."""
        file_path = path or self._default_path()
        if not os.path.exists(file_path):
            return 0

        with open(file_path, encoding="utf-8") as f:
            data = json.load(f)

        count = 0
        for item in data:
            try:
                entry = RefMapEntry(**item)
                key = _make_key(entry.site, entry.action_name)
                self._entries.setdefault(key, []).append(entry)
                count += 1
            except (TypeError, KeyError) as exc:
                logger.warning("Skipping invalid RefMap entry: %s", exc)

        logger.debug("RefMap loaded %d entries from %s", count, file_path)
        return count

    def _default_path(self) -> str:
        base = self._persist_dir or DEFAULT_REFMAP_DIR
        return os.path.join(base, "refmap.json")
