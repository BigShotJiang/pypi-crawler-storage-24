"""Browser session state machine, lifecycle management, and control-ownership
handoff between user and agent.

Implements requirements 4 (control switching) and 7 (session lifecycle).
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import time
import uuid
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

from .chrome_launcher import CDPConnection, RunningChrome

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class SessionState(StrEnum):
    """Session lifecycle states."""

    IDLE = "idle"
    AWAITING_USER_AUTH = "awaiting_user_auth"
    AUTHENTICATING = "authenticating"
    AUTHENTICATED = "authenticated"
    AGENT_AUTOMATION = "agent_automation"
    TIMEOUT = "timeout"
    FAILED = "failed"


class ControlOwner(StrEnum):
    """Who currently controls the browser."""

    AGENT = "agent"
    USER = "user"


# Valid state transitions
_VALID_TRANSITIONS: dict[SessionState, set[SessionState]] = {
    SessionState.IDLE: {
        SessionState.AWAITING_USER_AUTH,
        SessionState.AGENT_AUTOMATION,
        SessionState.FAILED,
    },
    SessionState.AWAITING_USER_AUTH: {
        SessionState.AUTHENTICATING,
        SessionState.TIMEOUT,
        SessionState.FAILED,
        SessionState.IDLE,
    },
    SessionState.AUTHENTICATING: {
        SessionState.AUTHENTICATED,
        SessionState.AWAITING_USER_AUTH,
        SessionState.TIMEOUT,
        SessionState.FAILED,
    },
    SessionState.AUTHENTICATED: {
        SessionState.AGENT_AUTOMATION,
        SessionState.IDLE,
        SessionState.FAILED,
    },
    SessionState.AGENT_AUTOMATION: {
        SessionState.IDLE,
        SessionState.AWAITING_USER_AUTH,
        SessionState.FAILED,
    },
    SessionState.TIMEOUT: {
        SessionState.IDLE,
        SessionState.FAILED,
    },
    SessionState.FAILED: {
        SessionState.IDLE,
    },
}


# ---------------------------------------------------------------------------
# Audit event
# ---------------------------------------------------------------------------


@dataclass
class AuditEvent:
    """An immutable record of a state or control change."""

    timestamp: float
    session_id: str
    profile_name: str
    event_type: str  # "state_change" | "handoff"
    old_value: str
    new_value: str
    trigger_source: str  # who/what triggered the change
    detail: str = ""


# ---------------------------------------------------------------------------
# Browser session
# ---------------------------------------------------------------------------


@dataclass
class BrowserSession:
    """A single browser session tied to one profile."""

    session_id: str
    profile_name: str

    # State
    state: SessionState = SessionState.IDLE
    control_owner: ControlOwner = ControlOwner.AGENT

    # URLs
    current_url: str = ""

    # Pages/tabs owned by this session (1:N relationship).
    # Each entry is a page_id string matching a key in _state["pages"].
    page_ids: list[str] = field(default_factory=list)

    # Enhancement runtime snapshot
    enhancement_runtime: dict[str, Any] = field(default_factory=dict)

    # Underlying resources (set after launch)
    chrome: RunningChrome | None = None
    cdp: CDPConnection | None = None

    # Timestamps
    created_at: float = field(default_factory=time.time)
    last_activity_at: float = field(default_factory=time.time)

    # Audit trail
    audit_log: list[AuditEvent] = field(default_factory=list)

    # Agent operation queue — operations enqueued while user has control
    _agent_queue: asyncio.Queue[Any] = field(
        default_factory=lambda: asyncio.Queue(),
    )
    _queue_gate: asyncio.Event = field(
        default_factory=lambda: asyncio.Event(),
    )

    def __post_init__(self) -> None:
        # Gate is open by default (agent has control)
        if self.control_owner == ControlOwner.AGENT:
            self._queue_gate.set()
        else:
            self._queue_gate.clear()

    # -- state transitions --------------------------------------------------

    def transition(
        self,
        new_state: SessionState,
        trigger_source: str = "system",
    ) -> None:
        """Move the session to *new_state* if the transition is valid.

        Raises:
            ValueError: If the transition is not allowed.
        """
        allowed = _VALID_TRANSITIONS.get(self.state, set())
        if new_state not in allowed:
            raise ValueError(
                f"Invalid transition: {self.state.value} → {new_state.value}",
            )
        old = self.state
        self.state = new_state
        self.last_activity_at = time.time()
        event = AuditEvent(
            timestamp=time.time(),
            session_id=self.session_id,
            profile_name=self.profile_name,
            event_type="state_change",
            old_value=old.value,
            new_value=new_state.value,
            trigger_source=trigger_source,
        )
        self.audit_log.append(event)
        logger.info(
            "Session %s: %s → %s (by %s)",
            self.session_id[:8],
            old.value,
            new_state.value,
            trigger_source,
        )

    # -- control handoff ----------------------------------------------------

    def handoff(
        self,
        target_owner: ControlOwner,
        trigger_reason: str = "",
    ) -> None:
        """Switch control between agent and user.

        When control passes to ``user``, the agent queue gate is closed so
        agent operations block.  When control returns to ``agent``, the gate
        opens and pending operations resume.
        """
        if target_owner == self.control_owner:
            return  # no-op
        old = self.control_owner
        self.control_owner = target_owner
        self.last_activity_at = time.time()

        if target_owner == ControlOwner.USER:
            self._queue_gate.clear()
        else:
            self._queue_gate.set()

        event = AuditEvent(
            timestamp=time.time(),
            session_id=self.session_id,
            profile_name=self.profile_name,
            event_type="handoff",
            old_value=old.value,
            new_value=target_owner.value,
            trigger_source="handoff",
            detail=trigger_reason,
        )
        self.audit_log.append(event)
        logger.info(
            "Session %s: control %s → %s (%s)",
            self.session_id[:8],
            old.value,
            target_owner.value,
            trigger_reason or "manual",
        )

    async def wait_for_agent_control(self, timeout: float = 600) -> bool:
        """Block until control returns to agent (used by agent operations).

        Returns ``True`` if control returned, ``False`` on timeout.
        """
        if self.control_owner == ControlOwner.AGENT:
            return True
        try:
            await asyncio.wait_for(self._queue_gate.wait(), timeout=timeout)
            return True
        except TimeoutError:
            return False

    def request_user_control(self, reason: str = "auth_needed") -> None:
        """Convenience: switch to user control and update state."""
        self.handoff(ControlOwner.USER, trigger_reason=reason)
        if self.state in (SessionState.IDLE, SessionState.AGENT_AUTOMATION):
            self.transition(SessionState.AWAITING_USER_AUTH, trigger_source=reason)

    def return_control_to_agent(self, reason: str = "auth_complete") -> None:
        """Convenience: switch back to agent and optionally mark authenticated."""
        self.handoff(ControlOwner.AGENT, trigger_reason=reason)
        if self.state == SessionState.AWAITING_USER_AUTH:
            self.transition(SessionState.AUTHENTICATING, trigger_source=reason)
        if self.state == SessionState.AUTHENTICATING:
            self.transition(SessionState.AUTHENTICATED, trigger_source=reason)

    # -- serialisation ------------------------------------------------------

    def to_dict(self) -> dict[str, Any]:
        """Serialise session state for API responses."""
        return {
            "session_id": self.session_id,
            "profile_name": self.profile_name,
            "state": self.state.value,
            "control_owner": self.control_owner.value,
            "current_url": self.current_url,
            "page_ids": list(self.page_ids),
            "enhancement_runtime": self.enhancement_runtime,
            "created_at": self.created_at,
            "last_activity_at": self.last_activity_at,
        }


# ---------------------------------------------------------------------------
# Session manager
# ---------------------------------------------------------------------------

# Timeout settings (seconds)
AUTH_TIMEOUT = 600  # 10 minutes
IDLE_TIMEOUT = 1800  # 30 minutes


class SessionManager:
    """Maintains all active browser sessions.

    Provides create / get / list / destroy plus periodic timeout sweeps.
    """

    def __init__(self) -> None:
        self._sessions: dict[str, BrowserSession] = {}
        self._listeners: list[Callable[[AuditEvent], None]] = []
        self._sweep_task: asyncio.Task[None] | None = None

    # -- lifecycle ----------------------------------------------------------

    def create_session(self, profile_name: str) -> BrowserSession:
        """Create a new session for *profile_name*."""
        session_id = uuid.uuid4().hex[:12]
        session = BrowserSession(
            session_id=session_id,
            profile_name=profile_name,
        )
        self._sessions[session_id] = session
        logger.info(
            "Created session %s for profile '%s'",
            session_id,
            profile_name,
        )
        return session

    def get_session(self, session_id: str) -> BrowserSession | None:
        return self._sessions.get(session_id)

    def get_session_by_profile(self, profile_name: str) -> BrowserSession | None:
        """Return the first active session for *profile_name*."""
        for s in self._sessions.values():
            if s.profile_name == profile_name:
                return s
        return None

    def list_sessions(self) -> list[BrowserSession]:
        return list(self._sessions.values())

    async def destroy_session(self, session_id: str) -> bool:
        """Remove a session (does NOT stop Chrome — caller handles that)."""
        session = self._sessions.pop(session_id, None)
        if session is None:
            return False
        logger.info("Destroyed session %s", session_id)
        return True

    # -- event listeners ----------------------------------------------------

    def add_listener(self, callback: Callable[[AuditEvent], None]) -> None:
        self._listeners.append(callback)

    def _notify(self, event: AuditEvent) -> None:
        for cb in self._listeners:
            try:
                cb(event)
            except Exception as exc:
                logger.warning("Session listener error: %s", exc)

    # -- timeout sweep ------------------------------------------------------

    def start_sweep(self) -> None:
        """Start the background timeout sweep task."""
        if self._sweep_task is None or self._sweep_task.done():
            self._sweep_task = asyncio.ensure_future(self._sweep_loop())

    def stop_sweep(self) -> None:
        if self._sweep_task and not self._sweep_task.done():
            self._sweep_task.cancel()

    async def _sweep_loop(self) -> None:
        """Periodically check for timed-out sessions."""
        while True:
            try:
                await asyncio.sleep(30)
                self._check_timeouts()
            except asyncio.CancelledError:
                break
            except Exception as exc:
                logger.warning("Sweep error: %s", exc)

    def _check_timeouts(self) -> None:
        now = time.time()
        for session in list(self._sessions.values()):
            elapsed = now - session.last_activity_at

            # awaiting_user_auth > 10 min → timeout
            if session.state == SessionState.AWAITING_USER_AUTH and elapsed > AUTH_TIMEOUT:
                try:
                    session.transition(
                        SessionState.TIMEOUT,
                        trigger_source="timeout_sweep",
                    )
                    logger.warning(
                        "Session %s timed out (awaiting auth for %ds)",
                        session.session_id[:8],
                        int(elapsed),
                    )
                except ValueError:
                    pass

            # idle > 30 min → mark for cleanup
            if session.state == SessionState.IDLE and elapsed > IDLE_TIMEOUT:
                logger.info(
                    "Session %s idle for %ds — marking for reclaim",
                    session.session_id[:8],
                    int(elapsed),
                )
                # The actual Chrome stop is handled by the caller
                # We just set the state to failed so the API layer can clean up
                with contextlib.suppress(ValueError):
                    session.transition(
                        SessionState.FAILED,
                        trigger_source="idle_reclaim",
                    )


# ---------------------------------------------------------------------------
# Auth auto-detection helpers
# ---------------------------------------------------------------------------


async def detect_auth_completion(
    session: BrowserSession,
    *,
    target_url_pattern: str = "",
    cookie_names: list[str] | None = None,
    poll_interval: float = 2.0,
    timeout: float = 600.0,
) -> bool:
    """Monitor page to auto-detect authentication success.

    Uses the LLM-based auth detector to semantically determine whether
    the page is still an auth page, replacing the URL-keyword heuristic.
    Falls back to keyword check if the LLM is unavailable.

    Returns ``True`` if auth was detected, ``False`` on timeout.
    This runs while the user has control.
    """
    if not session.cdp or not session.cdp.context:
        return False

    context = session.cdp.context
    pages = context.pages
    if not pages:
        return False

    page = pages[0]
    deadline = time.monotonic() + timeout

    while time.monotonic() < deadline:
        if session.control_owner != ControlOwner.USER:
            # Control already returned — assume auth done
            return True

        current_url = page.url
        session.current_url = current_url

        # Check URL pattern (explicit override)
        url_ok = False
        if target_url_pattern:
            if target_url_pattern in current_url:
                url_ok = True
        else:
            # Use LLM to determine if page is still an auth page
            try:
                from .auth_detector_llm import LLMAuthDetector

                detector = LLMAuthDetector(session)
                result = await detector.detect()
                # Page is "done with auth" when LLM says it's NOT an auth page
                url_ok = not result.is_auth_page
            except Exception:
                # Fallback: URL no longer contains login/auth/sso keywords
                lower_url = current_url.lower()
                url_ok = not any(kw in lower_url for kw in ("login", "auth", "sso", "signin", "oauth"))

        # Check cookies
        cookies_ok = True
        if cookie_names:
            try:
                cookies = await context.cookies()
                present = {c["name"] for c in cookies}
                cookies_ok = all(cn in present for cn in cookie_names)
            except Exception:
                cookies_ok = False

        if url_ok and cookies_ok:
            logger.info(
                "Auth auto-detected for session %s (url=%s)",
                session.session_id[:8],
                current_url,
            )
            session.return_control_to_agent(reason="auto_detect_auth")
            return True

        await asyncio.sleep(poll_interval)

    return False
