"""Automatic request-time model routing based on message signals."""

from __future__ import annotations

import logging
import re
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ..providers import list_resolved_llm_configs
from ..providers.models import ProvidersData, ResolvedModelInfo

logger = logging.getLogger(__name__)

_REASONING_HINT_RE = re.compile(
    r"(审查|review|debug|排查|分析|推理|reason|方案|设计|架构|实现|计划|plan|refactor)",
    re.IGNORECASE,
)
_IMAGE_EXTENSIONS = {
    ".png",
    ".jpg",
    ".jpeg",
    ".webp",
    ".gif",
    ".bmp",
    ".heic",
}
_AUDIO_EXTENSIONS = {".mp3", ".wav", ".m4a", ".aac", ".opus", ".ogg", ".flac"}
_VIDEO_EXTENSIONS = {".mp4", ".mov", ".avi", ".mkv", ".webm", ".m4v"}
_DOCUMENT_EXTENSIONS = {
    ".pdf",
    ".doc",
    ".docx",
    ".ppt",
    ".pptx",
    ".xls",
    ".xlsx",
    ".csv",
    ".md",
    ".txt",
    ".json",
}


@dataclass(frozen=True)
class RouteSignals:
    """Signals extracted from the incoming request."""

    required_modalities: frozenset[str]
    prefers_reasoning: bool
    prefers_large_context: bool
    text_length: int
    message_count: int
    file_count: int


@dataclass(frozen=True)
class RouteDecision:
    """Route decision for a single request."""

    selected: ResolvedModelInfo | None
    candidates: tuple[ResolvedModelInfo, ...]
    reasons: tuple[str, ...]
    signals: RouteSignals


def route_model_for_request(
    *,
    msgs: Sequence[Any] | Any,
    providers_data: ProvidersData,
) -> RouteDecision:
    """Choose the best configured model for the current request."""
    signals = extract_route_signals(msgs)
    candidates = list_resolved_llm_configs(providers_data)
    if not candidates:
        return RouteDecision(
            selected=None,
            candidates=(),
            reasons=("no_configured_models",),
            signals=signals,
        )

    active_provider_id, active_model = providers_data.parse_active_llm()
    compatible = [candidate for candidate in candidates if _supports_modalities(candidate, signals.required_modalities)]
    pool = compatible or candidates
    ranked = sorted(
        pool,
        key=lambda candidate: _score_candidate(
            candidate,
            signals=signals,
            active_provider_id=active_provider_id,
            active_model=active_model,
        ),
        reverse=True,
    )
    selected = ranked[0]
    reasons = list(_summarize_signals(signals))
    if compatible:
        reasons.append("compatible_capability_match")
    elif signals.required_modalities:
        reasons.append("no_exact_multimodal_match_fell_back")
    if (
        selected.provider_id == active_provider_id
        and selected.model == active_model
        and not signals.required_modalities
    ):
        reasons.append("kept_active_model")
    return RouteDecision(
        selected=selected,
        candidates=tuple(ranked),
        reasons=tuple(reasons),
        signals=signals,
    )


def extract_route_signals(msgs: Sequence[Any] | Any) -> RouteSignals:
    """Extract routing signals from messages after media preprocessing."""
    messages = msgs if isinstance(msgs, Sequence) and not isinstance(msgs, str | bytes) else [msgs]
    required_modalities: set[str] = set()
    text_parts: list[str] = []
    file_count = 0
    document_count = 0

    for message in messages:
        content = getattr(message, "content", None)
        if isinstance(content, str):
            text_parts.append(content)
            continue
        if not isinstance(content, list):
            get_text = getattr(message, "get_text_content", None)
            if callable(get_text):
                text_parts.append(get_text())
            continue

        for raw_block in content:
            block = _normalize_block(raw_block)
            if not block:
                continue

            btype = str(block.get("type", ""))
            if btype == "text":
                text_parts.append(str(block.get("text", "")))
                continue

            if btype == "image":
                required_modalities.add("image")
                continue

            if btype == "audio":
                required_modalities.add("audio")
                continue

            if btype == "video":
                required_modalities.add("video")
                continue

            if btype != "file":
                continue

            file_count += 1
            file_hint = _extract_file_hint(block)
            suffix = (Path(file_hint).suffix or "").lower()
            if suffix in _IMAGE_EXTENSIONS:
                required_modalities.add("image")
            elif suffix in _AUDIO_EXTENSIONS:
                required_modalities.add("audio")
            elif suffix in _VIDEO_EXTENSIONS:
                required_modalities.add("video")
            elif suffix in _DOCUMENT_EXTENSIONS:
                document_count += 1

    text = "\n".join(part for part in text_parts if part).strip()
    text_length = len(text)
    prefers_reasoning = bool(
        _REASONING_HINT_RE.search(text) or "```" in text or text.count("\n") >= 12 or text_length >= 1200
    )
    prefers_large_context = bool(text_length >= 5000 or len(messages) >= 8 or document_count > 0 or file_count >= 3)
    return RouteSignals(
        required_modalities=frozenset(required_modalities),
        prefers_reasoning=prefers_reasoning,
        prefers_large_context=prefers_large_context,
        text_length=text_length,
        message_count=len(messages),
        file_count=file_count,
    )


def _normalize_block(block: Any) -> dict[str, Any] | None:
    if isinstance(block, dict):
        return block
    if hasattr(block, "model_dump"):
        return block.model_dump(exclude_none=True)
    if hasattr(block, "dict"):
        return block.dict(exclude_none=True)
    return None


def _extract_file_hint(block: dict[str, Any]) -> str:
    for key in ("path", "filename", "name"):
        value = block.get(key)
        if isinstance(value, str) and value:
            return value
    source = block.get("source")
    if isinstance(source, dict):
        for key in ("url", "data"):
            value = source.get(key)
            if isinstance(value, str) and value:
                return value
    if isinstance(source, str):
        return source
    return ""


def _supports_modalities(
    candidate: ResolvedModelInfo,
    required_modalities: frozenset[str],
) -> bool:
    if not required_modalities:
        return True
    supported = set(candidate.input or ["text"])
    return required_modalities.issubset(supported)


def _score_candidate(
    candidate: ResolvedModelInfo,
    *,
    signals: RouteSignals,
    active_provider_id: str,
    active_model: str,
) -> float:
    score = 0.0
    is_active = candidate.provider_id == active_provider_id and candidate.model == active_model
    supported = set(candidate.input or ["text"])

    if signals.required_modalities:
        if signals.required_modalities.issubset(supported):
            score += 120
        else:
            score -= 250
    elif is_active:
        score += 35

    if signals.prefers_reasoning:
        score += 45 if candidate.reasoning else -10
    elif candidate.reasoning:
        score -= 2

    if signals.prefers_large_context:
        score += min(float(candidate.context_window or 0) / 4096.0, 80.0)
    elif is_active:
        score += 10

    if signals.required_modalities:
        score += 5 * len(supported.intersection(signals.required_modalities))
    else:
        # For text-only requests, mildly prefer models without extra modalities
        # to avoid routing to more expensive multimodal models unnecessarily.
        extra_modalities = supported - {"text"}
        if extra_modalities:
            score -= 3

    cost = candidate.cost
    if cost and not signals.required_modalities and not signals.prefers_large_context:
        score -= (cost.input + cost.output) / 10.0

    if candidate.context_window:
        score += min(float(candidate.context_window) / 65536.0, 6.0)

    return score


def _summarize_signals(signals: RouteSignals) -> Iterable[str]:
    if signals.required_modalities:
        yield "required_modalities=" + ",".join(sorted(signals.required_modalities))
    if signals.prefers_reasoning:
        yield "prefers_reasoning"
    if signals.prefers_large_context:
        yield "prefers_large_context"
    if not signals.required_modalities and not signals.prefers_reasoning:
        yield "default_request"


def format_route_log(decision: RouteDecision) -> str:
    """Return a concise human-readable log line for the route decision."""
    selected = decision.selected
    if selected is None:
        return "auto-route: no configured model candidates"

    labels = [f"{selected.provider_id}/{selected.model}"]
    if decision.reasons:
        labels.append("reasons=" + ",".join(decision.reasons))
    top_candidates = ",".join(f"{candidate.provider_id}/{candidate.model}" for candidate in decision.candidates[:3])
    if top_candidates:
        labels.append("top=" + top_candidates)
    return "auto-route: " + " ".join(labels)
