"""Setup and initialization utilities for agent configuration.

This module handles copying markdown configuration files to
the working directory.
"""

import logging
import shutil
from pathlib import Path

logger = logging.getLogger(__name__)


def copy_prompts(
    language: str,
    skip_existing: bool = False,
) -> list[str]:
    """Copy md files from agent/prompts to working directory.

    Args:
        language: Language code (e.g. 'en', 'zh')
        skip_existing: If True, skip files that already exist in working dir.

    Returns:
        List of copied file names.
    """
    from ...constant import WORKING_DIR

    # Get prompts directory path with language subdirectory
    prompts_dir = Path(__file__).parent.parent / "prompts" / language

    if not prompts_dir.exists():
        logger.warning(
            "Prompts directory not found: %s, falling back to 'en'",
            prompts_dir,
        )
        # Fallback to English if specified language not found
        prompts_dir = Path(__file__).parent.parent / "prompts" / "en"
        if not prompts_dir.exists():
            logger.error("Default 'en' prompts not found either")
            return []

    # Ensure working directory exists
    WORKING_DIR.mkdir(parents=True, exist_ok=True)

    # Copy all .md files to working directory
    copied_files: list[str] = []
    for md_file in prompts_dir.glob("*.md"):
        target_file = WORKING_DIR / md_file.name
        if skip_existing and target_file.exists():
            logger.debug("Skipped existing md file: %s", md_file.name)
            continue
        try:
            shutil.copy2(md_file, target_file)
            logger.debug("Copied md file: %s", md_file.name)
            copied_files.append(md_file.name)
        except Exception as e:
            logger.error(
                "Failed to copy md file '%s': %s",
                md_file.name,
                e,
            )

    if copied_files:
        logger.debug(
            "Copied %d prompt(s) [%s] to %s",
            len(copied_files),
            language,
            WORKING_DIR,
        )

    return copied_files


# System-level template files that are safe to overwrite on sync.
# User-data files (USER.md, MEMORY.md, IDENTITY.md) are never touched.
_SYSTEM_PROMPTS = frozenset(
    {
        "AGENTS.md",
        "SOUL.md",
        "BOOTSTRAP.md",
        "TOOLS.md",
        "HEARTBEAT.md",
    }
)


def sync_workspace_prompts(
    language: str,
) -> tuple[list[str], list[str]]:
    """Overwrite **system** prompt templates in the workspace with the latest
    versions shipped in the package, while leaving user-data files untouched.

    Args:
        language: Language code (e.g. ``'en'``, ``'zh'``).

    Returns:
        A ``(synced, skipped)`` tuple where *synced* lists the file names that
        were overwritten and *skipped* lists files in the prompts directory
        that were intentionally left alone (user-data files).
    """
    from ...constant import WORKING_DIR

    prompts_dir = Path(__file__).parent.parent / "prompts" / language

    if not prompts_dir.exists():
        logger.warning(
            "Prompts directory not found: %s, falling back to 'en'",
            prompts_dir,
        )
        prompts_dir = Path(__file__).parent.parent / "prompts" / "en"
        if not prompts_dir.exists():
            logger.error("Default 'en' prompts not found either")
            return [], []

    WORKING_DIR.mkdir(parents=True, exist_ok=True)

    synced: list[str] = []
    skipped: list[str] = []

    for md_file in prompts_dir.glob("*.md"):
        if md_file.name not in _SYSTEM_PROMPTS:
            skipped.append(md_file.name)
            continue
        target_file = WORKING_DIR / md_file.name
        try:
            shutil.copy2(md_file, target_file)
            logger.debug("Synced system prompt: %s", md_file.name)
            synced.append(md_file.name)
        except Exception as e:
            logger.error(
                "Failed to sync prompt '%s': %s",
                md_file.name,
                e,
            )

    if synced:
        logger.info(
            "Synced %d system prompt(s) [%s] to %s",
            len(synced),
            language,
            WORKING_DIR,
        )

    return synced, skipped
