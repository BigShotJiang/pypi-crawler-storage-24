"""Document parsing helpers for uploaded file ingestion."""

from __future__ import annotations

import contextlib
import csv
import json
import logging
import mimetypes
import re
import zipfile
import zlib
from dataclasses import dataclass
from io import StringIO
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET

from ...app.file_store import (
    derived_text_path,
    get_file_metadata,
    update_file_parse_metadata,
)

logger = logging.getLogger(__name__)

MAX_PARSED_TEXT_CHARS = 120_000
MAX_EXCERPT_CHARS = 400
MAX_CSV_ROWS = 200
MAX_XLSX_ROWS_PER_SHEET = 200

_DOCX_NS = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
_PPTX_NS = {"a": "http://schemas.openxmlformats.org/drawingml/2006/main"}
_XLSX_MAIN_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
_XLSX_REL_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
_XLSX_PKG_REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"


@dataclass
class ParsedDocumentResult:
    """Stable sidecar parse result."""

    status: str
    parsed_text_path: str | None
    excerpt: str
    summary: str
    metadata: dict[str, Any]


def _is_parseable(media_type: str, suffix: str) -> bool:
    suffix = suffix.lower()
    if suffix in {
        ".txt",
        ".md",
        ".markdown",
        ".json",
        ".csv",
        ".pdf",
        ".docx",
        ".xlsx",
        ".pptx",
    }:
        return True
    if media_type.startswith("text/"):
        return True
    return media_type in {
        "application/json",
        "application/pdf",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    }


def _decode_text_bytes(data: bytes) -> str:
    for encoding in ("utf-8", "utf-8-sig"):
        try:
            return data.decode(encoding)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace")


def _truncate_text(text: str) -> tuple[str, bool]:
    if len(text) <= MAX_PARSED_TEXT_CHARS:
        return text, False
    trimmed = text[:MAX_PARSED_TEXT_CHARS].rstrip()
    return trimmed + "\n\n[Truncated for context safety]\n", True


def _excerpt(text: str) -> str:
    compact = " ".join(text.split())
    return compact[:MAX_EXCERPT_CHARS]


def _parse_text_file(path: Path, suffix: str) -> tuple[str, dict[str, Any]]:
    raw = path.read_bytes()
    text = _decode_text_bytes(raw)

    if suffix.lower() == ".json":
        try:
            parsed = json.loads(text)
            text = json.dumps(parsed, ensure_ascii=False, indent=2)
        except json.JSONDecodeError:
            pass
    elif suffix.lower() == ".csv":
        reader = csv.reader(StringIO(text))
        rows = []
        total_rows = 0
        for row in reader:
            total_rows += 1
            if len(rows) < MAX_CSV_ROWS:
                rows.append(" | ".join(cell.strip() for cell in row))
        text = "\n".join(rows)
        if total_rows > MAX_CSV_ROWS:
            text += f"\n\n[Only first {MAX_CSV_ROWS} rows shown; total rows: {total_rows}]"
        return text, {"row_count": total_rows}

    return text, {"line_count": text.count("\n") + (1 if text else 0)}


def _docx_paragraphs(xml_bytes: bytes) -> list[str]:
    root = ET.fromstring(xml_bytes)
    lines: list[str] = []
    for para in root.findall(".//w:p", _DOCX_NS):
        texts = [node.text or "" for node in para.findall(".//w:t", _DOCX_NS)]
        line = "".join(texts).strip()
        if line:
            lines.append(line)
    return lines


def _parse_docx(path: Path) -> tuple[str, dict[str, Any]]:
    parts: list[str] = []
    with zipfile.ZipFile(path) as zf:
        names = set(zf.namelist())
        ordered = [
            "word/document.xml",
            *sorted(
                name
                for name in names
                if (
                    name.startswith("word/header")
                    or name.startswith("word/footer")
                    or name.startswith("word/footnotes")
                    or name.startswith("word/endnotes")
                )
                and name.endswith(".xml")
            ),
        ]
        for name in ordered:
            if name not in names:
                continue
            parts.extend(_docx_paragraphs(zf.read(name)))
    return "\n".join(parts), {"paragraph_count": len(parts)}


def _parse_pptx(path: Path) -> tuple[str, dict[str, Any]]:
    sections: list[str] = []
    with zipfile.ZipFile(path) as zf:
        slide_names = sorted(
            (name for name in zf.namelist() if name.startswith("ppt/slides/slide") and name.endswith(".xml")),
            key=lambda value: int(re.search(r"slide(\d+)\.xml$", value).group(1)),
        )
        for idx, name in enumerate(slide_names, start=1):
            root = ET.fromstring(zf.read(name))
            texts = [node.text.strip() for node in root.findall(".//a:t", _PPTX_NS) if node.text and node.text.strip()]
            if texts:
                sections.append(f"## Slide {idx}\n" + "\n".join(texts))
    return "\n\n".join(sections), {"slide_count": len(sections)}


def _xlsx_shared_strings(zf: zipfile.ZipFile) -> list[str]:
    if "xl/sharedStrings.xml" not in zf.namelist():
        return []
    root = ET.fromstring(zf.read("xl/sharedStrings.xml"))
    strings: list[str] = []
    for item in root.findall(f".//{{{_XLSX_MAIN_NS}}}si"):
        texts = [node.text or "" for node in item.findall(f".//{{{_XLSX_MAIN_NS}}}t")]
        strings.append("".join(texts))
    return strings


def _xlsx_sheet_targets(zf: zipfile.ZipFile) -> list[tuple[str, str]]:
    workbook = ET.fromstring(zf.read("xl/workbook.xml"))
    rels_root = ET.fromstring(zf.read("xl/_rels/workbook.xml.rels"))
    rel_map = {
        rel.attrib.get("Id"): rel.attrib.get("Target", "")
        for rel in rels_root.findall(f".//{{{_XLSX_PKG_REL_NS}}}Relationship")
    }
    sheets: list[tuple[str, str]] = []
    for sheet in workbook.findall(f".//{{{_XLSX_MAIN_NS}}}sheet"):
        name = sheet.attrib.get("name", "Sheet")
        rel_id = sheet.attrib.get(f"{{{_XLSX_REL_NS}}}id")
        target = rel_map.get(rel_id, "")
        if target:
            sheets.append((name, f"xl/{target.lstrip('/')}"))
    return sheets


def _xlsx_cell_value(cell: ET.Element, shared_strings: list[str]) -> str:
    cell_type = cell.attrib.get("t")
    if cell_type == "inlineStr":
        texts = [node.text or "" for node in cell.findall(f".//{{{_XLSX_MAIN_NS}}}t")]
        return "".join(texts).strip()

    value_node = cell.find(f"./{{{_XLSX_MAIN_NS}}}v")
    if value_node is None or value_node.text is None:
        return ""

    value = value_node.text
    if cell_type == "s":
        try:
            return shared_strings[int(value)]
        except (ValueError, IndexError):
            return value
    if cell_type == "b":
        return "TRUE" if value == "1" else "FALSE"
    return value


def _parse_xlsx(path: Path) -> tuple[str, dict[str, Any]]:
    sections: list[str] = []
    with zipfile.ZipFile(path) as zf:
        shared_strings = _xlsx_shared_strings(zf)
        sheets = _xlsx_sheet_targets(zf)
        for sheet_name, sheet_path in sheets:
            if sheet_path not in zf.namelist():
                continue
            root = ET.fromstring(zf.read(sheet_path))
            lines: list[str] = []
            total_rows = 0
            for row in root.findall(f".//{{{_XLSX_MAIN_NS}}}row"):
                total_rows += 1
                if len(lines) >= MAX_XLSX_ROWS_PER_SHEET:
                    continue
                cells = [_xlsx_cell_value(cell, shared_strings) for cell in row.findall(f"./{{{_XLSX_MAIN_NS}}}c")]
                if any(cell.strip() for cell in cells):
                    lines.append(" | ".join(cell.strip() for cell in cells))
            section = f"## Sheet: {sheet_name}\n" + "\n".join(lines)
            if total_rows > MAX_XLSX_ROWS_PER_SHEET:
                section += f"\n\n[Only first {MAX_XLSX_ROWS_PER_SHEET} rows shown; total rows: {total_rows}]"
            sections.append(section)
    return "\n\n".join(sections), {"sheet_count": len(sections)}


_PDF_STREAM_RE = re.compile(rb"stream\r?\n(.*?)\r?\nendstream", re.S)
_PDF_TEXT_BLOCK_RE = re.compile(rb"BT(.*?)ET", re.S)
_PDF_LITERAL_RE = re.compile(rb"\((?:\\.|[^\\)])*\)")


def _decode_pdf_literal(raw: bytes) -> str:
    chars: list[str] = []
    i = 0
    length = len(raw)
    while i < length:
        byte = raw[i]
        if byte == 0x5C and i + 1 < length:
            i += 1
            esc = raw[i]
            mapping = {
                ord("n"): "\n",
                ord("r"): "\r",
                ord("t"): "\t",
                ord("b"): "\b",
                ord("f"): "\f",
                ord("("): "(",
                ord(")"): ")",
                ord("\\"): "\\",
            }
            if esc in mapping:
                chars.append(mapping[esc])
                i += 1
                continue
            if 48 <= esc <= 55:
                oct_digits = [chr(esc)]
                for extra in range(1, 3):
                    if i + extra < length and 48 <= raw[i + extra] <= 55:
                        oct_digits.append(chr(raw[i + extra]))
                    else:
                        break
                i += len(oct_digits)
                chars.append(chr(int("".join(oct_digits), 8)))
                continue
            chars.append(chr(esc))
            i += 1
            continue
        chars.append(chr(byte))
        i += 1
    return "".join(chars)


def _extract_pdf_text(data: bytes) -> str:
    texts: list[str] = []
    candidate_streams: list[bytes] = [data]
    for match in _PDF_STREAM_RE.finditer(data):
        stream = match.group(1).strip(b"\r\n")
        candidate_streams.append(stream)
        with contextlib.suppress(Exception):
            candidate_streams.append(zlib.decompress(stream))

    for stream in candidate_streams:
        for block in _PDF_TEXT_BLOCK_RE.findall(stream):
            parts = []
            for literal in _PDF_LITERAL_RE.findall(block):
                parts.append(_decode_pdf_literal(literal[1:-1]))
            text = "".join(parts).strip()
            if text:
                texts.append(text)
    deduped: list[str] = []
    seen: set[str] = set()
    for item in texts:
        if item not in seen:
            deduped.append(item)
            seen.add(item)
    return "\n".join(deduped)


def _parse_pdf(path: Path) -> tuple[str, dict[str, Any]]:
    try:
        import fitz

        doc = fitz.open(path)
        try:
            sections: list[str] = []
            for page_index, page in enumerate(doc, start=1):
                page_text = (page.get_text("text") or "").strip()
                if page_text:
                    sections.append(f"## Page {page_index}\n{page_text}")
            return "\n\n".join(sections), {
                "page_count": doc.page_count,
                "extractor": "pymupdf",
            }
        finally:
            doc.close()
    except Exception as exc:
        logger.debug("PyMuPDF PDF extraction failed for %s: %s", path, exc)

    data = path.read_bytes()
    text = _extract_pdf_text(data)
    page_count = len(re.findall(rb"/Type\s*/Page\b", data))
    return text, {"page_count": page_count, "extractor": "regex"}


def _parse_document(path: Path, media_type: str) -> tuple[str, dict[str, Any]]:
    suffix = path.suffix.lower()
    if (
        suffix in {".txt", ".md", ".markdown", ".json", ".csv"}
        or media_type.startswith("text/")
        or media_type == "application/json"
    ):
        return _parse_text_file(path, suffix)
    if suffix == ".pdf" or media_type == "application/pdf":
        return _parse_pdf(path)
    if suffix == ".docx":
        return _parse_docx(path)
    if suffix == ".xlsx":
        return _parse_xlsx(path)
    if suffix == ".pptx":
        return _parse_pptx(path)
    raise ValueError(f"Unsupported document type: {suffix or media_type}")


def ensure_parsed_document(
    file_path: str,
    *,
    file_id: str | None = None,
    filename: str | None = None,
    media_type: str | None = None,
) -> ParsedDocumentResult | None:
    """Ensure a stored document has a parsed text sidecar."""
    path = Path(file_path).expanduser().resolve()
    if not path.is_file():
        return None

    resolved_media_type = media_type or mimetypes.guess_type(str(path))[0] or "application/octet-stream"
    if not _is_parseable(resolved_media_type, path.suffix):
        return None

    metadata = get_file_metadata(file_id) if file_id else None
    parse_metadata = dict((metadata or {}).get("parse") or {})
    cached_path = str(parse_metadata.get("parsed_text_path") or "")
    if parse_metadata.get("status") == "ready" and cached_path and Path(cached_path).is_file():
        return ParsedDocumentResult(
            status="ready",
            parsed_text_path=cached_path,
            excerpt=str(parse_metadata.get("excerpt") or ""),
            summary=str(parse_metadata.get("summary") or ""),
            metadata=parse_metadata,
        )

    try:
        parsed_text, parse_details = _parse_document(path, resolved_media_type)
    except Exception as exc:
        logger.warning("Failed to parse document %s: %s", path, exc)
        result_meta = {
            "status": "error",
            "summary": f"Document parse failed: {exc}",
            "excerpt": "",
            "parsed_text_path": None,
        }
        if file_id:
            update_file_parse_metadata(file_id, result_meta)
        return ParsedDocumentResult(
            status="error",
            parsed_text_path=None,
            excerpt="",
            summary=result_meta["summary"],
            metadata=result_meta,
        )

    parsed_text = parsed_text.strip()
    if not parsed_text:
        result_meta = {
            "status": "no_text",
            "summary": "No extractable text found in document",
            "excerpt": "",
            "parsed_text_path": None,
            **parse_details,
        }
        if file_id:
            update_file_parse_metadata(file_id, result_meta)
        return ParsedDocumentResult(
            status="no_text",
            parsed_text_path=None,
            excerpt="",
            summary=result_meta["summary"],
            metadata=result_meta,
        )

    truncated_text, truncated = _truncate_text(parsed_text)
    title = filename or path.name
    markdown = f"# File\nname: {title}\ntype: {resolved_media_type}\n\n# Content\n{truncated_text}\n"

    parsed_text_output = None
    if file_id:
        output_path = derived_text_path(file_id)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(markdown, encoding="utf-8")
        parsed_text_output = str(output_path)

    summary_bits = []
    if parse_details.get("page_count"):
        summary_bits.append(f"pages={parse_details['page_count']}")
    if parse_details.get("slide_count"):
        summary_bits.append(f"slides={parse_details['slide_count']}")
    if parse_details.get("sheet_count"):
        summary_bits.append(f"sheets={parse_details['sheet_count']}")
    if parse_details.get("paragraph_count"):
        summary_bits.append(f"paragraphs={parse_details['paragraph_count']}")
    if parse_details.get("row_count"):
        summary_bits.append(f"rows={parse_details['row_count']}")
    summary_bits.append(f"chars={len(parsed_text)}")
    if truncated:
        summary_bits.append("truncated=true")

    result_meta = {
        "status": "ready",
        "summary": ", ".join(summary_bits),
        "excerpt": _excerpt(parsed_text),
        "parsed_text_path": parsed_text_output,
        **parse_details,
    }
    if file_id:
        update_file_parse_metadata(file_id, result_meta)

    return ParsedDocumentResult(
        status="ready",
        parsed_text_path=parsed_text_output,
        excerpt=str(result_meta["excerpt"]),
        summary=str(result_meta["summary"]),
        metadata=result_meta,
    )
