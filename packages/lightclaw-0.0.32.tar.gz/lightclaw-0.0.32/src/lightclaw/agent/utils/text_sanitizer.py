"""Sanitize raw LLM output text.

Removes model-specific markup (thinking tags, vendor-specific tool-call
XML, etc.) that may pollute compressed summaries and cause downstream
API errors when the summary is later injected into requests for a
different model provider.
"""

from __future__ import annotations

import logging
import re
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from langchain_core.messages import BaseMessage

logger = logging.getLogger(__name__)

# Pre-compiled patterns for performance.  Each tuple is
# (compiled_regex, replacement_string).
_SANITIZE_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    # 1. <think>…</think> blocks (DeepSeek, QwQ, etc.)
    (re.compile(r"<think>\s*.*?\s*</think>", re.DOTALL), ""),
    # 2. <minimax:tool_call>…</minimax:tool_call> (MiniMax)
    (re.compile(r"<minimax:tool_call>\s*.*?\s*</minimax:tool_call>", re.DOTALL), ""),
    # 3. Generic vendor-prefixed XML tags: <vendor:anything>…</vendor:anything>
    (re.compile(r"<[a-zA-Z0-9_-]+:[a-zA-Z0-9_-]+>.*?</[a-zA-Z0-9_-]+:[a-zA-Z0-9_-]+>", re.DOTALL), ""),
    # 4. Self-closing vendor-prefixed tags: <vendor:tag />
    (re.compile(r"<[a-zA-Z0-9_-]+:[a-zA-Z0-9_-]+\s*/>", re.DOTALL), ""),
    # 5. Stray opening vendor tags without closing (best-effort)
    (re.compile(r"<[a-zA-Z0-9_-]+:[a-zA-Z0-9_-]+>"), ""),
    # 6. <|im_start|> / <|im_end|> chat-template tokens (ChatML leaks)
    (re.compile(r"<\|im_(?:start|end)\|>[^\n]*"), ""),
    # 7. Collapse 3+ consecutive blank lines into 2
    (re.compile(r"\n{3,}"), "\n\n"),
]


def sanitize_summary_text(text: str) -> str:
    """Strip model-specific tags and artefacts from summary text.

    This is applied after compaction LLM calls and before injecting
    summaries into the message history, providing two layers of defence.

    Args:
        text: Raw LLM output intended as a compressed summary.

    Returns:
        Cleaned text with vendor-specific markup removed.
    """
    if not text:
        return text

    for pattern, replacement in _SANITIZE_PATTERNS:
        text = pattern.sub(replacement, text)

    return text.strip()


def _sanitize_content(content: str | list) -> str | list:
    """Apply sanitization patterns to a content value (str or list of blocks)."""
    if isinstance(content, str):
        sanitized = content
        for pattern, replacement in _SANITIZE_PATTERNS:
            sanitized = pattern.sub(replacement, sanitized)
        return sanitized.strip()

    if isinstance(content, list):
        result = []
        for block in content:
            if isinstance(block, str):
                cleaned = block
                for pattern, replacement in _SANITIZE_PATTERNS:
                    cleaned = pattern.sub(replacement, cleaned)
                cleaned = cleaned.strip()
                if cleaned:
                    result.append(cleaned)
            elif isinstance(block, dict) and "text" in block:
                text = block["text"]
                if isinstance(text, str):
                    cleaned = text
                    for pattern, replacement in _SANITIZE_PATTERNS:
                        cleaned = pattern.sub(replacement, cleaned)
                    cleaned = cleaned.strip()
                    if cleaned:
                        result.append({**block, "text": cleaned})
                    # Drop block entirely if text is empty after sanitization.
                else:
                    result.append(block)
            else:
                result.append(block)
        return result

    return content


def sanitize_messages(messages: list[BaseMessage]) -> list[BaseMessage]:
    """Strip model-specific artefacts from AI messages in-place.

    When a session switches between model providers (e.g. MiniMax →
    haihub), older AI responses may contain vendor-specific XML tags
    such as ``<think>…</think>`` or ``<minimax:tool_call>…``.  These
    tags can trigger HTTP 400 errors from the new provider.

    This function walks the message list and sanitizes only ``AIMessage``
    content, leaving user, system, and tool messages untouched.

    Args:
        messages: Mutable list of LangChain BaseMessage instances.

    Returns:
        The same list, modified in-place for efficiency.
    """
    from langchain_core.messages import AIMessage

    for msg in messages:
        if not isinstance(msg, AIMessage):
            continue

        content = msg.content
        if not content:
            continue

        cleaned = _sanitize_content(content)
        if cleaned != content:
            msg.content = cleaned

    return messages
