"""
Qdrant 记忆检索器。
对标 openclaw: src/memory/hybrid.ts + temporal-decay.ts + mmr.ts + manager-search.ts

完整搜索流程：
  query
    ├─ [FTS-only 模式，无 embedding_fn]
    │    └─ extractKeywords(query) → FTS5 MATCH → 合并去重 → 返回
    └─ [Hybrid 模式，有 embedding_fn]
         ├─ 1. dense 检索：embed(query) → Qdrant.search(limit=candidates)
         ├─ 2. BM25 检索：buildFtsQuery(query) → SQLite FTS5 MATCH → bm25RankToScore
         ├─ 3. mergeHybridResults：score = 0.7 * vectorScore + 0.3 * textScore
         ├─ 4. temporal decay（可选，默认关闭）
         ├─ 5. 排序 + minScore 过滤
         └─ 6. MMR 重排（可选，默认关闭）
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import math
import os
import re
import sqlite3
import uuid
from collections.abc import Callable, Coroutine
from dataclasses import dataclass, field, replace
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

from .query_expansion import build_fts_query, expand_query_for_fts, extract_keywords

if TYPE_CHECKING:
    from .qdrant_indexer import QdrantMemoryIndexer

logger = logging.getLogger(__name__)

# ── 默认参数（对标 openclaw 默认值）──────────────────────────────────────────
VECTOR_WEIGHT = 0.7  # 对标 hybrid.vectorWeight
TEXT_WEIGHT = 0.3  # 对标 hybrid.textWeight
CANDIDATE_MULTIPLIER = 4  # candidates = maxResults * CANDIDATE_MULTIPLIER
MAX_CANDIDATES = 200  # 对标 openclaw min(200, ...)
SNIPPET_MAX_CHARS = 700  # 对标 openclaw SNIPPET_MAX_CHARS
HALF_LIFE_DAYS = 30.0  # 对标 temporal-decay DEFAULT_TEMPORAL_DECAY_CONFIG
MMR_LAMBDA = 0.7  # 对标 mmr DEFAULT_MMR_CONFIG.lambda
DAY_SECONDS = 86400.0

# memory/YYYY-MM-DD.md 路径正则（对标 openclaw DATED_MEMORY_PATH_RE）
_DATED_MEMORY_PATH_RE = re.compile(r"(?:^|/)memory/(\d{4})-(\d{2})-(\d{2})\.md$")


# ── 数据类 ────────────────────────────────────────────────────────────────────


@dataclass
class SearchResult:
    """单条搜索结果（对标 openclaw HybridSearchResult）。"""

    chunk_id: str
    path: str
    start_line: int
    end_line: int
    score: float
    snippet: str
    source: str
    vector_score: float = 0.0
    text_score: float = 0.0
    importance: float = 0.5  # from payload, default neutral
    access_count: int = 0  # from payload, search-hit accumulator


@dataclass
class TemporalDecayConfig:
    """时间衰减配置（对标 openclaw TemporalDecayConfig）。"""

    enabled: bool = True
    half_life_days: float = 90.0  # 90 days: gentler than 30, avoids over-aggressive decay


@dataclass
class MMRConfig:
    """MMR 多样性重排配置（对标 openclaw MMRConfig）。"""

    enabled: bool = False
    lambda_: float = MMR_LAMBDA


@dataclass
class SearchConfig:
    """搜索配置，汇总所有可调参数。"""

    max_results: int = 5
    min_score: float = 0.3
    vector_weight: float = VECTOR_WEIGHT
    text_weight: float = TEXT_WEIGHT
    temporal_decay: TemporalDecayConfig = field(default_factory=TemporalDecayConfig)
    mmr: MMRConfig = field(default_factory=MMRConfig)


# ── 工具函数 ──────────────────────────────────────────────────────────────────


def bm25_rank_to_score(rank: float) -> float:
    """
    将 SQLite FTS5 bm25() 返回值转换为 [0,1] 分数。
    对标 openclaw bm25RankToScore（hybrid.ts）。

    SQLite FTS5 bm25() 返回负数（越负越相关）：
      rank < 0: relevance = -rank, score = relevance / (1 + relevance)
      rank >= 0: score = 1 / (1 + rank)
    """
    if not math.isfinite(rank):
        return 1 / (1 + 999)
    if rank < 0:
        relevance = -rank
        return relevance / (1 + relevance)
    return 1 / (1 + rank)


def _parse_memory_date_from_path(file_path: str) -> datetime | None:
    """
    从 memory/YYYY-MM-DD.md 路径提取日期。
    对标 openclaw parseMemoryDateFromPath（temporal-decay.ts）。
    """
    normalized = file_path.replace("\\", "/").lstrip("./")
    match = _DATED_MEMORY_PATH_RE.search(normalized)
    if not match:
        return None
    try:
        year, month, day = int(match[1]), int(match[2]), int(match[3])
        dt = datetime(year, month, day, tzinfo=UTC)
        # 验证日期合法性
        if dt.year != year or dt.month != month or dt.day != day:
            return None
        return dt
    except (ValueError, OverflowError):
        return None


def _is_evergreen_memory_path(file_path: str) -> bool:
    """
    判断是否为 evergreen 路径（不参与时间衰减）。
    对标 openclaw isEvergreenMemoryPath（temporal-decay.ts）。

    MEMORY.md / memory.md → evergreen
    memory/ 下非日期文件 → evergreen
    """
    normalized = file_path.replace("\\", "/").lstrip("./")
    if normalized in ("MEMORY.md", "memory.md"):
        return True
    if not normalized.startswith("memory/"):
        return False
    return not bool(_DATED_MEMORY_PATH_RE.search(normalized))


def _calculate_temporal_decay_multiplier(age_days: float, half_life_days: float) -> float:
    """
    计算时间衰减乘数。
    对标 openclaw calculateTemporalDecayMultiplier（temporal-decay.ts）。

    λ = ln(2) / half_life_days
    multiplier = exp(-λ * max(0, age_days))
    """
    if not math.isfinite(half_life_days) or half_life_days <= 0:
        return 1.0
    lambda_ = math.log(2) / half_life_days
    clamped_age = max(0.0, age_days)
    if not math.isfinite(clamped_age):
        return 1.0
    return math.exp(-lambda_ * clamped_age)


def _get_file_mtime(abs_path: str) -> datetime | None:
    """获取文件修改时间（用于时间衰减 fallback）。"""
    try:
        mtime = Path(abs_path).stat().st_mtime
        if not math.isfinite(mtime):
            return None
        return datetime.fromtimestamp(mtime, tz=UTC)
    except OSError:
        return None


def _apply_temporal_decay(
    results: list[SearchResult],
    config: TemporalDecayConfig,
    working_dir: str | None = None,
    now: datetime | None = None,
) -> list[SearchResult]:
    """
    对搜索结果应用时间衰减。
    对标 openclaw applyTemporalDecayToHybridResults（temporal-decay.ts）。
    """
    if not config.enabled:
        return results

    now_dt = now or datetime.now(UTC)
    decayed: list[SearchResult] = []

    for r in results:
        # 1. 从路径提取日期
        ts = _parse_memory_date_from_path(r.path)

        # 2. evergreen 路径不衰减
        if ts is None and r.source == "memory" and _is_evergreen_memory_path(r.path):
            decayed.append(r)
            continue

        # 3. fallback：从文件 mtime 获取时间戳
        if ts is None and working_dir:
            abs_path = str(Path(working_dir) / r.path)
            ts = _get_file_mtime(abs_path)

        if ts is None:
            decayed.append(r)
            continue

        age_days = max(0.0, (now_dt - ts).total_seconds()) / DAY_SECONDS
        multiplier = _calculate_temporal_decay_multiplier(age_days, config.half_life_days)
        new_r = SearchResult(
            chunk_id=r.chunk_id,
            path=r.path,
            start_line=r.start_line,
            end_line=r.end_line,
            score=r.score * multiplier,
            snippet=r.snippet,
            source=r.source,
            vector_score=r.vector_score,
            text_score=r.text_score,
            importance=r.importance,
            access_count=r.access_count,
        )
        decayed.append(new_r)

    return decayed


# ── Importance boost ─────────────────────────────────────────────────────


def _apply_importance_boost(results: list[SearchResult]) -> list[SearchResult]:
    """Apply importance and access-frequency boost to search scores.

    Formula::

        score *= importance_factor * frequency_factor

    Where:
        importance_factor = 0.5 + 0.5 * importance
            importance=0.0 → ×0.5 (halved)
            importance=0.5 → ×0.75
            importance=1.0 → ×1.0 (unchanged)

        frequency_factor = 1.0 + log2(1 + access_count) * 0.1
            access_count=0  → ×1.0
            access_count=7  → ×1.3  (30% boost)
            access_count=31 → ×1.5  (50% boost, logarithmic cap)
    """
    boosted: list[SearchResult] = []
    for r in results:
        imp_factor = 0.5 + 0.5 * max(0.0, min(1.0, r.importance))
        freq_factor = 1.0 + math.log2(1 + max(0, r.access_count)) * 0.1
        new_score = r.score * imp_factor * freq_factor
        boosted.append(replace(r, score=new_score))
    return boosted


# ── MMR 重排（对标 openclaw mmr.ts）──────────────────────────────────────────


def _tokenize_for_mmr(text: str) -> frozenset[str]:
    """提取小写字母数字 token 集合（对标 openclaw tokenize in mmr.ts）。"""
    return frozenset(re.findall(r"[a-z0-9_]+", text.lower()))


def _jaccard_similarity(set_a: frozenset[str], set_b: frozenset[str]) -> float:
    """Jaccard 相似度（对标 openclaw jaccardSimilarity）。"""
    if not set_a and not set_b:
        return 1.0
    if not set_a or not set_b:
        return 0.0
    intersection = len(set_a & set_b)
    union = len(set_a | set_b)
    return intersection / union if union > 0 else 0.0


def _compute_max_similarity(
    candidate: SearchResult,
    selected: list[SearchResult],
    token_cache: dict[str, frozenset[str]],
) -> float:
    """计算候选项与已选结果的最大 Jaccard 相似度（对标 openclaw maxSimilarityToSelected）。"""
    if not selected:
        return 0.0
    cand_tokens = token_cache[candidate.chunk_id]
    return max(_jaccard_similarity(cand_tokens, token_cache[sel.chunk_id]) for sel in selected)


def _select_best_mmr_candidate(
    remaining: list[SearchResult],
    selected: list[SearchResult],
    token_cache: dict[str, frozenset[str]],
    normalize: Callable[[float], float],
    lambda_: float,
) -> SearchResult | None:
    """从候选列表中选出 MMR 得分最高的项目。"""
    best: SearchResult | None = None
    best_mmr = float("-inf")
    for candidate in remaining:
        max_sim = _compute_max_similarity(candidate, selected, token_cache)
        mmr_score = lambda_ * normalize(candidate.score) - (1 - lambda_) * max_sim
        best_score = best.score if best is not None else float("-inf")
        if mmr_score > best_mmr or (mmr_score >= best_mmr - 1e-9 and candidate.score > best_score):
            best_mmr = mmr_score
            best = candidate
    return best


def _mmr_rerank(results: list[SearchResult], config: MMRConfig) -> list[SearchResult]:
    """
    MMR 多样性重排。
    对标 openclaw mmrRerank + applyMMRToHybridResults（mmr.ts）。

    算法：
    1. 归一化 score 到 [0,1]
    2. 迭代选择：mmr_score = λ * relevance - (1-λ) * max_jaccard_sim_to_selected
    3. Jaccard 相似度基于 snippet token 集合
    """
    if not config.enabled or len(results) <= 1:
        return results

    lambda_ = max(0.0, min(1.0, config.lambda_))

    # lambda 接近 1 时等价于纯相关性排序（对标 openclaw lambda=1 分支）
    if lambda_ >= 1.0 - 1e-9:
        return sorted(results, key=lambda r: r.score, reverse=True)

    # 预计算 token 集合
    token_cache: dict[str, frozenset[str]] = {r.chunk_id: _tokenize_for_mmr(r.snippet) for r in results}

    # 归一化分数
    scores = [r.score for r in results]
    max_score = max(scores)
    min_score = min(scores)
    score_range = max_score - min_score

    def normalize(s: float) -> float:
        return 1.0 if score_range < 1e-9 else (s - min_score) / score_range

    selected: list[SearchResult] = []
    remaining = list(results)

    while remaining:
        best = _select_best_mmr_candidate(remaining, selected, token_cache, normalize, lambda_)
        if best is None:
            break
        selected.append(best)
        remaining.remove(best)

    return selected


# ── 核心检索器 ────────────────────────────────────────────────────────────────


class QdrantMemorySearcher:
    """
    Qdrant 记忆检索器。
    对标 openclaw MemoryIndexManager.search()（manager.ts）。

    支持：
    - Hybrid 模式（dense + BM25 融合）
    - FTS-only 模式（无 embedding_fn 时自动降级）
    - 时间衰减（可选）
    - MMR 多样性重排（可选）
    """

    def __init__(
        self,
        indexer: QdrantMemoryIndexer,
        embedding_fn: Callable[[list[str]], Coroutine[Any, Any, list[list[float]]]] | None = None,
    ) -> None:
        self.indexer = indexer
        self.embedding_fn = embedding_fn

    async def search(
        self,
        query: str,
        max_results: int = 5,
        min_score: float = 0.3,
        config: SearchConfig | None = None,
    ) -> list[SearchResult]:
        """
        执行 hybrid 搜索，返回排序后的结果列表。
        对标 openclaw MemoryIndexManager.search()。
        """
        if not query.strip():
            return []

        # onSearch 自动同步：若有待同步的文件变更，先触发增量同步
        if self.indexer._dirty:
            loop = None
            with contextlib.suppress(RuntimeError):
                loop = asyncio.get_running_loop()
            if loop is not None and loop.is_running():
                asyncio.create_task(self.indexer._initial_sync())
                logger.debug("onSearch: triggered incremental sync (dirty=True)")

        cfg = config or SearchConfig(max_results=max_results, min_score=min_score)
        candidates_limit = min(MAX_CANDIDATES, cfg.max_results * CANDIDATE_MULTIPLIER)

        if self.embedding_fn is not None:
            results = await self._hybrid_search(query, candidates_limit, cfg)
        else:
            results = self._fts_only_search(query, candidates_limit)

        # 时间衰减
        results = _apply_temporal_decay(
            results,
            cfg.temporal_decay,
            working_dir=str(self.indexer.working_dir),
        )

        # 重要性 + 访问频率加成
        results = _apply_importance_boost(results)

        # 排序 + minScore 过滤
        results.sort(key=lambda r: r.score, reverse=True)
        results = [r for r in results if r.score >= cfg.min_score]

        # MMR 重排
        results = _mmr_rerank(results, cfg.mmr)

        final = results[: cfg.max_results]

        # Reinforce: async bump access_count for returned results (fire-and-forget)
        if final and self.indexer.client is not None:
            loop = None
            with contextlib.suppress(RuntimeError):
                loop = asyncio.get_running_loop()
            if loop is not None and loop.is_running():
                asyncio.create_task(self._reinforce_results(final))

        return final

    async def _reinforce_results(self, results: list[SearchResult]) -> None:
        """Increment access_count and update last_accessed_at for search hits.

        Runs as a fire-and-forget background task — failures are silently
        logged at DEBUG level and never affect the search response.
        """
        now_iso = datetime.now(UTC).isoformat()
        for r in results:
            try:
                point_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, r.chunk_id))
                # Retrieve current access_count to increment atomically
                points = await self.indexer.client.retrieve(
                    collection_name=self.indexer.collection_name,
                    ids=[point_id],
                    with_payload=["access_count"],
                )
                current_count = 0
                if points:
                    current_count = (points[0].payload or {}).get("access_count", 0)

                await self.indexer.client.set_payload(
                    collection_name=self.indexer.collection_name,
                    payload={
                        "access_count": current_count + 1,
                        "last_accessed_at": now_iso,
                    },
                    points=[point_id],
                )
            except Exception as exc:
                logger.debug("Reinforce failed for chunk %s: %s", r.chunk_id, exc)

    async def _hybrid_search(
        self,
        query: str,
        candidates_limit: int,
        cfg: SearchConfig,
    ) -> list[SearchResult]:
        """
        Hybrid 搜索：dense + BM25 融合。
        对标 openclaw mergeHybridResults（hybrid.ts）。
        """
        # 1. dense 检索
        vector_results = await self._search_vector(query, candidates_limit)

        # 2. BM25 关键词检索
        keyword_results = self._search_keyword(query, candidates_limit)
        # 3. 融合（对标 openclaw mergeHybridResults）
        return _merge_hybrid_results(
            vector_results,
            keyword_results,
            cfg.vector_weight,
            cfg.text_weight,
        )

    async def _search_vector(
        self,
        query: str,
        limit: int,
    ) -> list[dict[str, Any]]:
        """
        Dense 向量检索。
        对标 openclaw searchVector（manager-search.ts）。
        """
        if self.embedding_fn is None or limit <= 0:
            return []

        try:
            embeddings = await self.embedding_fn([query])
            query_vec = embeddings[0] if embeddings else []
        except Exception as exc:
            logger.warning("Embedding failed for query: %s", exc)
            return []

        if not query_vec:
            return []

        try:
            resp = await self.indexer.client.query_points(
                collection_name=self.indexer.collection_name,
                query=query_vec,
                limit=limit,
                with_payload=True,
            )
            hits = resp.points
        except Exception as exc:
            logger.warning("Qdrant search failed: %s", exc)
            return []

        results = []
        for hit in hits:
            payload = hit.payload or {}
            results.append(
                {
                    "chunk_id": payload.get("chunk_id", str(hit.id)),
                    "path": payload.get("path", ""),
                    "start_line": payload.get("start_line", 0),
                    "end_line": payload.get("end_line", 0),
                    "source": payload.get("source", "memory"),
                    "snippet": payload.get("snippet", "")[:SNIPPET_MAX_CHARS],
                    "vector_score": float(hit.score),
                    "text_score": 0.0,
                    "importance": float(payload.get("importance", 0.5)),
                    "access_count": int(payload.get("access_count", 0)),
                }
            )
        return results

    def _search_keyword(
        self,
        query: str,
        limit: int,
    ) -> list[dict[str, Any]]:
        """
        BM25 关键词检索（SQLite FTS5）。
        对标 openclaw searchKeyword（manager-search.ts）。

        使用 expand_query_for_fts 将口语化 query 扩展为 original OR keywords 形式，
        兼顾精确匹配和关键词召回，对标 openclaw expandQueryForFts。
        """
        if limit <= 0:
            return []

        fts_query = expand_query_for_fts(query)
        if not fts_query:
            return []

        try:
            rows = self.indexer.fts_db.execute(
                "SELECT id, path, source, start_line, end_line, text, "
                "bm25(chunks_fts) AS rank "
                "FROM chunks_fts "
                "WHERE chunks_fts MATCH ? "
                "ORDER BY rank ASC "
                "LIMIT ?",
                (fts_query, limit),
            ).fetchall()
        except sqlite3.OperationalError as exc:
            logger.warning("FTS5 search failed: %s", exc)
            return []

        results = []
        for row in rows:
            chunk_id, path, source, start_line, end_line, text, rank = row
            text_score = bm25_rank_to_score(rank)
            results.append(
                {
                    "chunk_id": chunk_id,
                    "path": path,
                    "start_line": start_line,
                    "end_line": end_line,
                    "source": source,
                    "snippet": text[:SNIPPET_MAX_CHARS],
                    "vector_score": 0.0,
                    "text_score": text_score,
                }
            )
        return results

    def _fts_only_search(
        self,
        query: str,
        limit: int,
    ) -> list[SearchResult]:
        """
        FTS-only 模式（无 embedding_fn 时的降级路径）。
        对标 openclaw FTS-only fallback（manager.ts）。

        两路搜索合并：
          第一路：expand_query_for_fts（精确短语 + 关键词扩展，一次完整搜索）
          第二路：extract_keywords 逐个关键词搜索（补充召回）
        多关键词命中同一 chunk 时取最大分数，hit_count 作为 tiebreaker，
        最终 score = max_text_score * (1 + 0.1 * (hit_count - 1))，保持量纲一致。
        """
        by_id: dict[str, dict[str, Any]] = {}

        def _upsert_row(row: tuple) -> None:
            chunk_id, path, source, start_line, end_line, text, rank = row
            text_score = bm25_rank_to_score(rank)
            if chunk_id not in by_id:
                by_id[chunk_id] = {
                    "chunk_id": chunk_id,
                    "path": path,
                    "start_line": start_line,
                    "end_line": end_line,
                    "source": source,
                    "snippet": text[:SNIPPET_MAX_CHARS],
                    "vector_score": 0.0,
                    "text_score": text_score,
                    "hit_count": 1,
                }
            else:
                # 取最大分数，hit_count 累加（保持量纲一致，避免累加导致分数虚高）
                by_id[chunk_id]["text_score"] = max(by_id[chunk_id]["text_score"], text_score)
                by_id[chunk_id]["hit_count"] += 1

        # ── 第一路：expand_query_for_fts（精确 + 关键词扩展）────────────────
        expanded_query = expand_query_for_fts(query)
        if expanded_query:
            try:
                rows = self.indexer.fts_db.execute(
                    "SELECT id, path, source, start_line, end_line, text, "
                    "bm25(chunks_fts) AS rank "
                    "FROM chunks_fts "
                    "WHERE chunks_fts MATCH ? "
                    "ORDER BY rank ASC "
                    "LIMIT ?",
                    (expanded_query, limit),
                ).fetchall()
                for row in rows:
                    _upsert_row(row)
            except sqlite3.OperationalError as exc:
                logger.warning("FTS5 expand search failed: %s", exc)

        # ── 第二路：extract_keywords 逐个关键词搜索（补充召回）──────────────
        keywords = extract_keywords(query)
        if not keywords:
            keywords = [query]

        for kw in keywords:
            fts_query = build_fts_query(kw)
            if not fts_query:
                continue
            try:
                rows = self.indexer.fts_db.execute(
                    "SELECT id, path, source, start_line, end_line, text, "
                    "bm25(chunks_fts) AS rank "
                    "FROM chunks_fts "
                    "WHERE chunks_fts MATCH ? "
                    "ORDER BY rank ASC "
                    "LIMIT ?",
                    (fts_query, limit),
                ).fetchall()
                for row in rows:
                    _upsert_row(row)
            except sqlite3.OperationalError as exc:
                logger.warning("FTS5 keyword search failed for '%s': %s", kw, exc)
                continue

        return [
            SearchResult(
                chunk_id=v["chunk_id"],
                path=v["path"],
                start_line=v["start_line"],
                end_line=v["end_line"],
                # hit_count 加成：命中关键词越多，分数轻微提升，作为 tiebreaker
                score=v["text_score"] * (1 + 0.1 * (v["hit_count"] - 1)),
                snippet=v["snippet"],
                source=v["source"],
                vector_score=0.0,
                text_score=v["text_score"],
            )
            for v in by_id.values()
        ]


# ── 融合函数（对标 openclaw mergeHybridResults）───────────────────────────────


def _merge_hybrid_results(
    vector_results: list[dict[str, Any]],
    keyword_results: list[dict[str, Any]],
    vector_weight: float,
    text_weight: float,
) -> list[SearchResult]:
    """
    融合 dense 和 BM25 结果。
    对标 openclaw mergeHybridResults（hybrid.ts）。

    score = vectorWeight * vectorScore + textWeight * textScore
    """
    by_id: dict[str, dict[str, Any]] = {}

    for r in vector_results:
        by_id[r["chunk_id"]] = {**r}

    for r in keyword_results:
        cid = r["chunk_id"]
        if cid in by_id:
            by_id[cid]["text_score"] = r["text_score"]
            # 优先使用 keyword 结果的 snippet（通常更精确）
            if r["snippet"]:
                by_id[cid]["snippet"] = r["snippet"]
        else:
            by_id[cid] = {**r}

    results: list[SearchResult] = []
    for entry in by_id.values():
        score = vector_weight * entry["vector_score"] + text_weight * entry["text_score"]
        results.append(
            SearchResult(
                chunk_id=entry["chunk_id"],
                path=entry["path"],
                start_line=entry["start_line"],
                end_line=entry["end_line"],
                score=score,
                snippet=entry["snippet"],
                source=entry["source"],
                vector_score=entry["vector_score"],
                text_score=entry["text_score"],
                importance=float(entry.get("importance", 0.5)),
                access_count=int(entry.get("access_count", 0)),
            )
        )

    return results


# ── 工厂函数 ──────────────────────────────────────────────────────────────────


def create_search_config_from_env() -> SearchConfig:
    """
    从环境变量创建 SearchConfig。
    对标 openclaw 的环境变量配置（backend-config.ts）。
    """
    temporal_decay_enabled = os.environ.get("MEMORY_TEMPORAL_DECAY_ENABLED", "true").lower() == "true"
    half_life_days = float(os.environ.get("MEMORY_TEMPORAL_DECAY_HALF_LIFE_DAYS", "90.0"))
    mmr_enabled = os.environ.get("MEMORY_MMR_ENABLED", "true").lower() == "true"
    mmr_lambda = float(os.environ.get("MEMORY_MMR_LAMBDA", str(MMR_LAMBDA)))

    return SearchConfig(
        temporal_decay=TemporalDecayConfig(
            enabled=temporal_decay_enabled,
            half_life_days=half_life_days,
        ),
        mmr=MMRConfig(
            enabled=mmr_enabled,
            lambda_=mmr_lambda,
        ),
    )
