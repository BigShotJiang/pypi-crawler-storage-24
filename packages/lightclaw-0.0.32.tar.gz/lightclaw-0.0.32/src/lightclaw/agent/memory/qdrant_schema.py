"""
Qdrant collection schema + SQLite FTS5 schema。
对标 openclaw: src/memory/memory-schema.ts
"""

from __future__ import annotations

import logging
import sqlite3
from datetime import UTC
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from qdrant_client import AsyncQdrantClient
    from qdrant_client.models import PayloadSchemaType

logger = logging.getLogger(__name__)

# ── 常量（对标 openclaw manager.ts 顶部常量）──────────────────────────────
COLLECTION_NAME = "lightclaw_memory"
FTS_DB_FILENAME = "memory_fts.db"

# Payload 字段名（对标 openclaw chunks 表列名）
PAYLOAD_CHUNK_ID = "chunk_id"  # SHA256[:16]，唯一标识
PAYLOAD_PATH = "path"  # 相对路径，如 "memory/2026-03-17.md"
PAYLOAD_SOURCE = "source"  # "memory" | "sessions"
PAYLOAD_START_LINE = "start_line"  # chunk 起始行（1-indexed）
PAYLOAD_END_LINE = "end_line"  # chunk 结束行
PAYLOAD_SNIPPET = "snippet"  # 截断到 SNIPPET_MAX_CHARS 的文本
PAYLOAD_CREATED_AT = "created_at"  # ISO-8601 时间戳
PAYLOAD_MODEL = "model"  # embedding 模型名称
PAYLOAD_HASH = "hash"  # chunk 文本的 SHA256[:16]

# Payload 字段名（记忆重要性评分，对标 importance.py）
PAYLOAD_IMPORTANCE = "importance"  # float, 0.0~1.0
PAYLOAD_ACCESS_COUNT = "access_count"  # integer, search-hit accumulator
PAYLOAD_LAST_ACCESSED_AT = "last_accessed_at"  # datetime, last search hit

# Payload 字段名（主动触达专用，对标 proactive_engine.py）
PAYLOAD_PROACTIVE_ENABLED = "proactive_enabled"  # bool
PAYLOAD_PROACTIVE_TIME_WINDOW = "proactive_time_window"  # keyword
PAYLOAD_PROACTIVE_LAST_TRIGGERED_AT = "proactive_last_triggered_at"  # datetime
PAYLOAD_PROACTIVE_PRIORITY = "proactive_priority"  # integer


async def ensure_qdrant_collection(
    client: AsyncQdrantClient,
    collection_name: str,
    vector_dims: int,
) -> None:
    """
    确保 Qdrant collection 存在，并建立 payload 索引。
    对标 openclaw: ensureMemoryIndexSchema + idx_chunks_source + idx_chunks_path
    """
    from qdrant_client.models import (
        Distance,
        PayloadSchemaType,
        VectorParams,
    )

    # 检查 collection 是否已存在
    existing = await client.get_collections()
    existing_names = {c.name for c in existing.collections}

    if collection_name not in existing_names:
        await client.create_collection(
            collection_name=collection_name,
            vectors_config=VectorParams(
                size=vector_dims,
                distance=Distance.COSINE,
            ),
        )
        logger.info("Qdrant collection '%s' created (dims=%d)", collection_name, vector_dims)
    else:
        # Validate existing collection dimension matches expected dimension.
        # If mismatched (e.g. embedding model changed), recreate the collection.
        info = await client.get_collection(collection_name)
        existing_dims = info.config.params.vectors.size  # type: ignore[union-attr]
        if existing_dims != vector_dims:
            logger.warning(
                "Qdrant collection '%s' dimension mismatch: existing=%d, expected=%d. "
                "Recreating collection to match current embedding model.",
                collection_name,
                existing_dims,
                vector_dims,
            )
            await client.delete_collection(collection_name)
            await client.create_collection(
                collection_name=collection_name,
                vectors_config=VectorParams(
                    size=vector_dims,
                    distance=Distance.COSINE,
                ),
            )
            logger.info(
                "Qdrant collection '%s' recreated (dims=%d → %d)",
                collection_name,
                existing_dims,
                vector_dims,
            )
        else:
            logger.debug("Qdrant collection '%s' already exists (dims=%d)", collection_name, vector_dims)

    # 建立 payload 索引（对标 openclaw idx_chunks_source + idx_chunks_path）
    # source: keyword index
    await _ensure_payload_index(client, collection_name, PAYLOAD_SOURCE, PayloadSchemaType.KEYWORD)
    # path: keyword index
    await _ensure_payload_index(client, collection_name, PAYLOAD_PATH, PayloadSchemaType.KEYWORD)
    # model: keyword index
    await _ensure_payload_index(client, collection_name, PAYLOAD_MODEL, PayloadSchemaType.KEYWORD)
    # created_at: datetime index（用于时间衰减和主动触达过滤）
    await _ensure_payload_index(client, collection_name, PAYLOAD_CREATED_AT, PayloadSchemaType.DATETIME)

    # ── 记忆重要性评分 payload 索引（对标 importance.py）──
    # importance: float index (for pre-filtering low-importance chunks)
    await _ensure_payload_index(client, collection_name, PAYLOAD_IMPORTANCE, PayloadSchemaType.FLOAT)
    # access_count: integer index (for reinforcement tracking)
    await _ensure_payload_index(client, collection_name, PAYLOAD_ACCESS_COUNT, PayloadSchemaType.INTEGER)
    # last_accessed_at: datetime index (for access recency)
    await _ensure_payload_index(client, collection_name, PAYLOAD_LAST_ACCESSED_AT, PayloadSchemaType.DATETIME)

    # ── 主动触达专用 payload 索引（对标 proactive_engine.py _filter_candidates）──
    # proactive_enabled: keyword index（bool 用 keyword 索引）
    await _ensure_payload_index(client, collection_name, PAYLOAD_PROACTIVE_ENABLED, PayloadSchemaType.KEYWORD)
    # proactive_time_window: keyword index
    await _ensure_payload_index(client, collection_name, PAYLOAD_PROACTIVE_TIME_WINDOW, PayloadSchemaType.KEYWORD)
    # proactive_last_triggered_at: datetime index（用于冷却时间过滤）
    await _ensure_payload_index(
        client, collection_name, PAYLOAD_PROACTIVE_LAST_TRIGGERED_AT, PayloadSchemaType.DATETIME
    )
    # proactive_priority: integer index
    await _ensure_payload_index(client, collection_name, PAYLOAD_PROACTIVE_PRIORITY, PayloadSchemaType.INTEGER)


async def _ensure_payload_index(
    client: AsyncQdrantClient,
    collection_name: str,
    field_name: str,
    schema_type: PayloadSchemaType,
) -> None:
    """建立 payload 字段索引（幂等操作）。"""
    try:
        await client.create_payload_index(
            collection_name=collection_name,
            field_name=field_name,
            field_schema=schema_type,
        )
        logger.debug("Payload index created: %s.%s", collection_name, field_name)
    except Exception as exc:
        # 索引已存在时 Qdrant 会报错，忽略即可
        msg = str(exc).lower()
        if "already exists" in msg or "conflict" in msg:
            logger.debug("Payload index already exists: %s.%s", collection_name, field_name)
        else:
            logger.warning("Failed to create payload index %s.%s: %s", collection_name, field_name, exc)


def ensure_fts_schema(db: sqlite3.Connection) -> None:
    """
    确保 SQLite FTS5 虚拟表存在。
    对标 openclaw: ensureMemoryIndexSchema 中的 chunks_fts 部分

    表结构：
        text        — 全文检索内容（BM25 索引）
        id          — chunk_id（UNINDEXED，不参与全文检索）
        path        — 相对路径（UNINDEXED）
        source      — "memory" | "sessions"（UNINDEXED）
        model       — embedding 模型名称（UNINDEXED）
        start_line  — chunk 起始行（UNINDEXED）
        end_line    — chunk 结束行（UNINDEXED）
    """
    db.execute(
        """
        CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts
        USING fts5(
            text,
            id UNINDEXED,
            path UNINDEXED,
            source UNINDEXED,
            model UNINDEXED,
            start_line UNINDEXED,
            end_line UNINDEXED
        )
        """
    )
    # 文件级 hash 元数据表（用于增量同步：跳过未变更文件）
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS file_index_meta (
            path        TEXT PRIMARY KEY,
            file_hash   TEXT NOT NULL,
            indexed_at  TEXT NOT NULL
        )
        """
    )
    db.commit()
    logger.debug("SQLite FTS5 table 'chunks_fts' ensured")


def get_indexed_file_hash(db: sqlite3.Connection, rel_path: str) -> str | None:
    """
    查询已索引文件的 SHA256 hash。
    返回 None 表示该文件从未被索引过。
    """
    row = db.execute(
        "SELECT file_hash FROM file_index_meta WHERE path = ?",
        (rel_path,),
    ).fetchone()
    return row[0] if row else None


def set_indexed_file_hash(db: sqlite3.Connection, rel_path: str, file_hash: str) -> None:
    """
    更新（或插入）文件的已索引 hash 记录。
    在 index_file 成功完成后调用。
    """
    from datetime import datetime

    now_iso = datetime.now(UTC).isoformat()
    db.execute(
        """
        INSERT INTO file_index_meta (path, file_hash, indexed_at)
        VALUES (?, ?, ?)
        ON CONFLICT(path) DO UPDATE SET
            file_hash  = excluded.file_hash,
            indexed_at = excluded.indexed_at
        """,
        (rel_path, file_hash, now_iso),
    )
    db.commit()


def delete_indexed_file_hash(db: sqlite3.Connection, rel_path: str) -> None:
    """删除文件的 hash 记录（文件被删除时调用）。"""
    db.execute("DELETE FROM file_index_meta WHERE path = ?", (rel_path,))
    db.commit()


def open_fts_db(data_dir: str | Path) -> sqlite3.Connection:
    """
    打开（或创建）FTS5 数据库，返回 sqlite3.Connection。
    数据库文件路径：{data_dir}/memory_fts.db
    """
    db_path = Path(data_dir) / FTS_DB_FILENAME
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path), check_same_thread=False)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=5000")
    ensure_fts_schema(conn)
    return conn
