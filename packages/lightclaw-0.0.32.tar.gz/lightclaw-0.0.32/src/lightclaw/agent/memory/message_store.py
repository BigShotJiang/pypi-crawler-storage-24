"""SQLite-backed message persistence for LightClaw memory.

Provides :class:`SqliteMessageStore`, a thin wrapper around :mod:`sqlite3`
that persists messages, marks, and the compressed-summary string to a
local ``messages.db`` file.  The store is designed to back
:class:`LightClawInMemoryMemory` transparently — all public methods are
``async def`` so they can be ``await``-ed from the existing async call
sites, even though the underlying sqlite3 calls are synchronous.

Database location::

    {working_dir}/memory/messages.db
"""

from __future__ import annotations

import json
import logging
import sqlite3
import time
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Schema version — bump when table definitions change.
# ---------------------------------------------------------------------------
_SCHEMA_VERSION = 2


class SqliteMessageStore:
    """Persist conversation messages and memory state to SQLite.

    Lifecycle::

        store = SqliteMessageStore(db_dir)
        await store.start()          # create tables / open connection
        ...
        await store.close()          # release connection
    """

    def __init__(self, db_dir: str | Path) -> None:
        """Initialise store (does **not** open the database yet).

        Args:
            db_dir: Directory where ``messages.db`` will be stored.
                    Typically ``{WORKING_DIR}/memory``.
        """
        self._db_dir = Path(db_dir)
        self._db_path = self._db_dir / "messages.db"
        self._conn: sqlite3.Connection | None = None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """Open the database and create tables if they don't exist."""
        if self._conn is not None:
            return

        self._db_dir.mkdir(parents=True, exist_ok=True)

        self._conn = sqlite3.connect(
            str(self._db_path),
            check_same_thread=False,
        )
        # Enable WAL mode for better concurrent-read performance.
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")

        await self._create_tables()
        logger.info("SqliteMessageStore opened: %s", self._db_path)

    async def close(self) -> None:
        """Close the database connection."""
        if self._conn is not None:
            self._conn.close()
            self._conn = None
            logger.info("SqliteMessageStore closed.")

    # ------------------------------------------------------------------
    # Table creation
    # ------------------------------------------------------------------

    async def _create_tables(self) -> None:
        """Create all tables, migrating from older schema versions."""
        assert self._conn is not None

        cursor = self._conn.cursor()
        try:
            cursor.execute("BEGIN")

            # ---- V1 tables (messages + memory_state) ----
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS messages (
                    id          TEXT    PRIMARY KEY,
                    seq         INTEGER NOT NULL,
                    role        TEXT    NOT NULL,
                    content     TEXT    NOT NULL,
                    metadata    TEXT,
                    created_at  INTEGER NOT NULL,
                    marks       TEXT    NOT NULL DEFAULT '[]'
                )
                """
            )
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS memory_state (
                    key         TEXT    PRIMARY KEY,
                    value       TEXT,
                    updated_at  INTEGER NOT NULL
                )
                """
            )
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_messages_created ON messages (created_at)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_messages_seq ON messages (seq)")

            # ---- V2 tables (summary versioning + traceability) ----
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS summaries (
                    id              INTEGER PRIMARY KEY AUTOINCREMENT,
                    version         INTEGER NOT NULL,
                    summary_text    TEXT    NOT NULL,
                    token_count     INTEGER,
                    created_at      INTEGER NOT NULL,
                    parent_id       INTEGER,
                    FOREIGN KEY (parent_id) REFERENCES summaries(id)
                )
                """
            )
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_summaries_version ON summaries (version DESC)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_summaries_created ON summaries (created_at DESC)")
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS summary_message_map (
                    summary_id      INTEGER NOT NULL,
                    message_id      TEXT    NOT NULL,
                    PRIMARY KEY (summary_id, message_id),
                    FOREIGN KEY (summary_id) REFERENCES summaries(id)
                )
                """
            )
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_smm_message ON summary_message_map (message_id)")
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS compaction_events (
                    id              INTEGER PRIMARY KEY AUTOINCREMENT,
                    summary_id      INTEGER NOT NULL,
                    trigger_source  TEXT    NOT NULL,
                    messages_count  INTEGER NOT NULL,
                    tokens_before   INTEGER,
                    tokens_after    INTEGER,
                    created_at      INTEGER NOT NULL,
                    FOREIGN KEY (summary_id) REFERENCES summaries(id)
                )
                """
            )
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_ce_created ON compaction_events (created_at DESC)")

            # Store / update schema version.
            cursor.execute(
                """
                INSERT INTO memory_state (key, value, updated_at)
                VALUES ('schema_version', ?, ?)
                ON CONFLICT(key) DO UPDATE SET value = excluded.value,
                                               updated_at = excluded.updated_at
                """,
                (str(_SCHEMA_VERSION), _now_ms()),
            )

            cursor.execute("COMMIT")
        except Exception:
            cursor.execute("ROLLBACK")
            raise
        finally:
            cursor.close()

    # ------------------------------------------------------------------
    # Message CRUD
    # ------------------------------------------------------------------

    async def add_message(
        self,
        msg_id: str,
        role: str,
        content: Any,
        metadata: Any = None,
        marks: list[str] | None = None,
    ) -> None:
        """Persist a single message.

        Args:
            msg_id: Unique message identifier (``Message.id``).
            role: Message role (``user``, ``assistant``, ``system``).
            content: Message content — will be JSON-serialised.
            metadata: Optional metadata dict — will be JSON-serialised.
            marks: Initial mark list (default ``[]``).
        """
        assert self._conn is not None

        content_json = json.dumps(
            content,
            ensure_ascii=False,
            default=str,
        )
        metadata_json = json.dumps(metadata, ensure_ascii=False, default=str) if metadata is not None else None
        marks_json = json.dumps(marks or [])

        seq = await self._next_seq()
        self._conn.execute(
            """
            INSERT OR REPLACE INTO messages
                (id, seq, role, content, metadata, created_at, marks)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (msg_id, seq, role, content_json, metadata_json, _now_ms(), marks_json),
        )
        self._conn.commit()

    async def add_messages_batch(
        self,
        messages: list[tuple[str, str, Any, Any, list[str]]],
    ) -> None:
        """Persist multiple messages in a single transaction.

        Each element is ``(msg_id, role, content, metadata, marks)``.
        """
        if not messages:
            return
        assert self._conn is not None

        cursor = self._conn.cursor()
        try:
            cursor.execute("BEGIN")
            seq = await self._next_seq()
            for i, (msg_id, role, content, metadata, marks) in enumerate(messages):
                content_json = json.dumps(
                    content,
                    ensure_ascii=False,
                    default=str,
                )
                metadata_json = json.dumps(metadata, ensure_ascii=False, default=str) if metadata is not None else None
                marks_json = json.dumps(marks or [])
                cursor.execute(
                    """
                    INSERT OR REPLACE INTO messages
                        (id, seq, role, content, metadata, created_at, marks)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        msg_id,
                        seq + i,
                        role,
                        content_json,
                        metadata_json,
                        _now_ms(),
                        marks_json,
                    ),
                )
            cursor.execute("COMMIT")
        except Exception:
            cursor.execute("ROLLBACK")
            raise
        finally:
            cursor.close()

    async def get_all_messages(
        self,
    ) -> list[dict[str, Any]]:
        """Load every message ordered by insertion sequence.

        Returns:
            List of dicts with keys:
            ``id``, ``role``, ``content`` (parsed JSON), ``metadata``
            (parsed JSON or None), ``marks`` (list[str]).
        """
        assert self._conn is not None

        cursor = self._conn.execute("SELECT id, role, content, metadata, marks FROM messages ORDER BY seq ASC")
        rows: list[dict[str, Any]] = []
        for row in cursor.fetchall():
            msg_id, role, content_json, metadata_json, marks_json = row
            rows.append(
                {
                    "id": msg_id,
                    "role": role,
                    "content": json.loads(content_json),
                    "metadata": (json.loads(metadata_json) if metadata_json else None),
                    "marks": json.loads(marks_json),
                }
            )
        return rows

    async def update_marks(
        self,
        msg_ids: list[str],
        new_mark: str,
    ) -> int:
        """Add *new_mark* to the marks list of the given messages.

        Returns:
            Number of rows actually updated.
        """
        if not msg_ids:
            return 0
        assert self._conn is not None

        updated = 0
        cursor = self._conn.cursor()
        try:
            cursor.execute("BEGIN")
            placeholders = ",".join("?" for _ in msg_ids)
            cursor.execute(
                f"SELECT id, marks FROM messages WHERE id IN ({placeholders})",
                msg_ids,
            )
            for row in cursor.fetchall():
                row_id, marks_json = row
                marks: list[str] = json.loads(marks_json)
                if new_mark not in marks:
                    marks.append(new_mark)
                    cursor.execute(
                        "UPDATE messages SET marks = ? WHERE id = ?",
                        (json.dumps(marks), row_id),
                    )
                    updated += 1
            cursor.execute("COMMIT")
        except Exception:
            cursor.execute("ROLLBACK")
            raise
        finally:
            cursor.close()
        return updated

    async def delete_messages(self, msg_ids: list[str]) -> int:
        """Delete messages by ID.

        Returns:
            Number of rows deleted.
        """
        if not msg_ids:
            return 0
        assert self._conn is not None

        placeholders = ",".join("?" for _ in msg_ids)
        cursor = self._conn.execute(
            f"DELETE FROM messages WHERE id IN ({placeholders})",
            msg_ids,
        )
        self._conn.commit()
        return cursor.rowcount

    async def count(self) -> int:
        """Return the total number of persisted messages."""
        assert self._conn is not None
        row = self._conn.execute("SELECT COUNT(*) FROM messages").fetchone()
        return row[0] if row else 0

    # ------------------------------------------------------------------
    # Memory state (compressed summary, etc.)
    # ------------------------------------------------------------------

    async def save_state(self, key: str, value: str) -> None:
        """Upsert a key/value pair in ``memory_state``."""
        assert self._conn is not None
        self._conn.execute(
            """
            INSERT INTO memory_state (key, value, updated_at)
            VALUES (?, ?, ?)
            ON CONFLICT(key) DO UPDATE SET value = excluded.value,
                                           updated_at = excluded.updated_at
            """,
            (key, value, _now_ms()),
        )
        self._conn.commit()

    async def load_state(self, key: str, default: str = "") -> str:
        """Read a value from ``memory_state``.

        Args:
            key: State key (e.g. ``"compressed_summary"``).
            default: Returned when the key does not exist.
        """
        assert self._conn is not None
        row = self._conn.execute(
            "SELECT value FROM memory_state WHERE key = ?",
            (key,),
        ).fetchone()
        return row[0] if row else default

    async def save_summary(
        self,
        summary: str,
        message_ids: list[str] | None = None,
        trigger_source: str = "hook",
        tokens_before: int | None = None,
    ) -> None:
        """Persist the compressed summary.

        When *message_ids* is provided, creates a versioned summary with
        full traceability.  When omitted (legacy callers), falls back to
        a plain key/value update in ``memory_state``.
        """
        if message_ids is not None:
            await self.add_summary(
                summary_text=summary,
                message_ids=message_ids,
                trigger_source=trigger_source,
                tokens_before=tokens_before,
            )
        else:
            # Legacy path — direct state update.
            await self.save_state("compressed_summary", summary)

    async def load_summary(self) -> str:
        """Load the latest compressed summary text."""
        return await self.load_state("compressed_summary", "")

    # ------------------------------------------------------------------
    # Summary versioning & traceability
    # ------------------------------------------------------------------

    async def add_summary(
        self,
        summary_text: str,
        message_ids: list[str],
        token_count: int | None = None,
        trigger_source: str = "hook",
        tokens_before: int | None = None,
    ) -> int:
        """Create a versioned summary linked to the messages it compressed.

        Args:
            summary_text: The compressed summary content.
            message_ids: IDs of messages compressed into this summary.
            token_count: Estimated token count of the summary (optional).
            trigger_source: ``'hook'`` or ``'middleware'``.
            tokens_before: Token count *before* compaction (for audit).

        Returns:
            The auto-generated summary row ID.
        """
        assert self._conn is not None

        now = _now_ms()
        cursor = self._conn.cursor()
        try:
            cursor.execute("BEGIN")

            # Determine next version and parent.
            row = cursor.execute("SELECT id, version FROM summaries ORDER BY version DESC LIMIT 1").fetchone()
            if row:
                parent_id, prev_version = row
                version = prev_version + 1
            else:
                parent_id = None
                version = 1

            # Insert summary.
            cursor.execute(
                """
                INSERT INTO summaries
                    (version, summary_text, token_count, created_at, parent_id)
                VALUES (?, ?, ?, ?, ?)
                """,
                (version, summary_text, token_count, now, parent_id),
            )
            summary_id: int = cursor.lastrowid  # type: ignore[assignment]

            # Link messages.
            for msg_id in message_ids:
                cursor.execute(
                    "INSERT OR IGNORE INTO summary_message_map (summary_id, message_id) VALUES (?, ?)",
                    (summary_id, msg_id),
                )

            # Record compaction event.
            cursor.execute(
                """
                INSERT INTO compaction_events
                    (summary_id, trigger_source, messages_count,
                     tokens_before, tokens_after, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    summary_id,
                    trigger_source,
                    len(message_ids),
                    tokens_before,
                    token_count,
                    now,
                ),
            )

            # Keep memory_state in sync for backward compatibility.
            cursor.execute(
                """
                INSERT INTO memory_state (key, value, updated_at)
                VALUES ('compressed_summary', ?, ?)
                ON CONFLICT(key) DO UPDATE SET value = excluded.value,
                                               updated_at = excluded.updated_at
                """,
                (summary_text, now),
            )

            cursor.execute("COMMIT")
            logger.info(
                "Summary v%d created (id=%d, messages=%d, source=%s)",
                version,
                summary_id,
                len(message_ids),
                trigger_source,
            )
            return summary_id

        except Exception:
            cursor.execute("ROLLBACK")
            raise
        finally:
            cursor.close()

    async def get_latest_summary(self) -> tuple[str, int | None]:
        """Return ``(summary_text, version)`` of the most recent summary.

        Returns ``("", None)`` when no versioned summaries exist.
        """
        assert self._conn is not None
        row = self._conn.execute("SELECT summary_text, version FROM summaries ORDER BY version DESC LIMIT 1").fetchone()
        if row:
            return row[0], row[1]
        return "", None

    async def get_summary_history(
        self,
        limit: int = 10,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        """Return paginated summary history (most recent first).

        Each dict contains: ``id``, ``version``, ``summary_text``,
        ``created_at``, ``messages_count``.
        """
        assert self._conn is not None
        rows = self._conn.execute(
            """
            SELECT s.id, s.version, s.summary_text, s.created_at,
                   COUNT(m.message_id) AS messages_count
            FROM summaries s
            LEFT JOIN summary_message_map m ON m.summary_id = s.id
            GROUP BY s.id
            ORDER BY s.version DESC
            LIMIT ? OFFSET ?
            """,
            (limit, offset),
        ).fetchall()
        return [
            {
                "id": r[0],
                "version": r[1],
                "summary_text": r[2],
                "created_at": r[3],
                "messages_count": r[4],
            }
            for r in rows
        ]

    async def get_messages_for_summary(self, summary_id: int) -> list[str]:
        """Return message IDs compressed into a given summary."""
        assert self._conn is not None
        rows = self._conn.execute(
            "SELECT message_id FROM summary_message_map WHERE summary_id = ?",
            (summary_id,),
        ).fetchall()
        return [r[0] for r in rows]

    async def get_summary_for_message(self, message_id: str) -> int | None:
        """Return the summary ID that compressed a given message, or None."""
        assert self._conn is not None
        row = self._conn.execute(
            "SELECT summary_id FROM summary_message_map WHERE message_id = ?",
            (message_id,),
        ).fetchone()
        return row[0] if row else None

    async def get_messages_for_summary_full(
        self,
        summary_id: int,
    ) -> list[dict[str, Any]]:
        """Retrieve full original messages that were compressed into a summary.

        Unlike :meth:`get_messages_for_summary` which returns only message IDs,
        this method returns the complete message content parsed from JSON.

        Args:
            summary_id: ID from the ``summaries`` table.

        Returns:
            List of message dicts ordered by insertion sequence.  Each dict
            contains ``id``, ``seq``, ``role``, ``content``, ``metadata``,
            ``marks``, and ``created_at``.  If JSON parsing fails for a field,
            the raw string is returned instead.
        """
        message_ids = await self.get_messages_for_summary(summary_id)
        if not message_ids:
            return []

        assert self._conn is not None
        placeholders = ",".join("?" for _ in message_ids)
        cursor = self._conn.execute(
            f"SELECT id, seq, role, content, metadata, marks, created_at "
            f"FROM messages WHERE id IN ({placeholders}) ORDER BY seq ASC",
            message_ids,
        )

        result: list[dict[str, Any]] = []
        for row in cursor.fetchall():
            msg_id, seq, role, content_json, metadata_json, marks_json, created_at = row

            # Parse JSON fields; fall back to raw string on failure.
            try:
                content = json.loads(content_json)
            except (json.JSONDecodeError, TypeError):
                content = content_json

            try:
                metadata = json.loads(metadata_json) if metadata_json else None
            except (json.JSONDecodeError, TypeError):
                metadata = metadata_json

            try:
                marks = json.loads(marks_json)
            except (json.JSONDecodeError, TypeError):
                marks = marks_json

            result.append(
                {
                    "id": msg_id,
                    "seq": seq,
                    "role": role,
                    "content": content,
                    "metadata": metadata,
                    "marks": marks,
                    "created_at": created_at,
                }
            )

        return result

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    async def _next_seq(self) -> int:
        """Return the next monotonic sequence number."""
        assert self._conn is not None
        row = self._conn.execute("SELECT COALESCE(MAX(seq), 0) + 1 FROM messages").fetchone()
        return row[0] if row else 1


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------


def _now_ms() -> int:
    """Current UTC time in milliseconds since epoch."""
    return int(time.time() * 1000)
