"""Proactive memory trigger engine (LightClaw differentiator, not in openclaw).

How it works:
1. Periodic (or event-driven) calls to evaluate_and_trigger
2. Use Qdrant payload filter to select memories meeting trigger conditions:
   - trigger_condition.time_window: "morning" | "afternoon" | "evening" | "night"
   - trigger_condition.enabled: true
   - trigger_condition.last_triggered_at: > cooldown_hours since now
3. Dense vector search (using current time context as query)
4. Select highest-priority candidate and generate proactive message
5. Update last_triggered_at (write back to Qdrant payload)

Qdrant payload filtering leverages payload index capabilities:
  - keyword index: trigger_condition.time_window, trigger_condition.enabled
  - datetime index: trigger_condition.last_triggered_at
"""

from __future__ import annotations

import asyncio
import logging
import os
from collections.abc import Callable, Coroutine
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .qdrant_indexer import QdrantMemoryIndexer

logger = logging.getLogger(__name__)

# Time window definitions (aligns with openclaw btw.ts time-awareness capability)
TIME_WINDOW_MORNING = "morning"  # 06:00 - 11:59
TIME_WINDOW_AFTERNOON = "afternoon"  # 12:00 - 17:59
TIME_WINDOW_EVENING = "evening"  # 18:00 - 21:59
TIME_WINDOW_NIGHT = "night"  # 22:00 - 05:59

# Payload field names (proactive-specific, written to Qdrant proactive_* prefix fields)
PAYLOAD_PROACTIVE_ENABLED = "proactive_enabled"
PAYLOAD_PROACTIVE_TIME_WINDOW = "proactive_time_window"
PAYLOAD_PROACTIVE_LAST_TRIGGERED_AT = "proactive_last_triggered_at"
PAYLOAD_PROACTIVE_PRIORITY = "proactive_priority"


def get_current_time_window(now: datetime | None = None) -> str:
    """Return time window name based on current time.

    Aligns with openclaw btw.ts time-awareness logic.
    """
    dt = now or datetime.now(UTC).astimezone()
    hour = dt.hour
    if 6 <= hour < 12:
        return TIME_WINDOW_MORNING
    if 12 <= hour < 18:
        return TIME_WINDOW_AFTERNOON
    if 18 <= hour < 22:
        return TIME_WINDOW_EVENING
    return TIME_WINDOW_NIGHT


def get_time_window_greeting(time_window: str, language: str = "zh") -> str:
    """Return time window greeting for proactive message generation."""
    if language == "zh":
        greetings = {
            TIME_WINDOW_MORNING: "早上好",
            TIME_WINDOW_AFTERNOON: "下午好",
            TIME_WINDOW_EVENING: "晚上好",
            TIME_WINDOW_NIGHT: "夜深了",
        }
    else:
        greetings = {
            TIME_WINDOW_MORNING: "Good morning",
            TIME_WINDOW_AFTERNOON: "Good afternoon",
            TIME_WINDOW_EVENING: "Good evening",
            TIME_WINDOW_NIGHT: "It's late",
        }
    return greetings.get(time_window, "")


@dataclass
class ProactiveConfig:
    """Proactive trigger engine configuration."""

    enabled: bool = False
    check_interval_seconds: float = 3600.0  # Check interval in seconds
    cooldown_hours: float = 8.0  # Cooldown between same-memory triggers in hours
    language: str = "zh"
    # Trigger callback: receives generated proactive message text, handled by upstream (e.g. channel)
    on_trigger: Callable[[str], Coroutine[Any, Any, None]] | None = None


@dataclass
class ProactiveTriggerResult:
    """Proactive trigger result."""

    triggered: bool
    message: str = ""
    chunk_id: str = ""
    path: str = ""
    score: float = 0.0
    time_window: str = ""


def create_proactive_config_from_env(
    on_trigger: Callable[[str], Coroutine[Any, Any, None]] | None = None,
) -> ProactiveConfig:
    """Create ProactiveConfig from environment variables."""
    return ProactiveConfig(
        enabled=os.environ.get("PROACTIVE_MEMORY_ENABLED", "false").lower() == "true",
        check_interval_seconds=float(os.environ.get("PROACTIVE_CHECK_INTERVAL_SECONDS", "3600")),
        cooldown_hours=float(os.environ.get("PROACTIVE_COOLDOWN_HOURS", "8")),
        language=os.environ.get("PROACTIVE_LANGUAGE", "zh"),
        on_trigger=on_trigger,
    )


class ProactiveMemoryEngine:
    """Proactive trigger engine.

    Uses two-phase Qdrant payload filter queries:
    Phase 1: payload filter (time window + enabled + cooldown)
    Phase 2: dense vector search (current context relevance)

    Qdrant payload fields (set by external tools/scripts during write):
        proactive_enabled: bool          — whether proactive trigger is enabled
        proactive_time_window: str       — trigger time window
        proactive_last_triggered_at: str — last trigger time (ISO-8601)
        proactive_priority: int          — priority (higher = more preferred)
    """

    def __init__(
        self,
        indexer: QdrantMemoryIndexer,
        embedding_fn: Callable[[list[str]], Coroutine[Any, Any, list[list[float]]]] | None,
        config: ProactiveConfig,
    ) -> None:
        self.indexer = indexer
        self.embedding_fn = embedding_fn
        self.config = config
        self._task: asyncio.Task | None = None
        self._closed = False

    # Lifecycle
    def start(self) -> None:
        """Start periodic check task."""
        if not self.config.enabled:
            logger.info("ProactiveMemoryEngine: disabled (PROACTIVE_MEMORY_ENABLED=false)")
            return
        if self._task is not None and not self._task.done():
            logger.debug("ProactiveMemoryEngine: already running")
            return
        self._closed = False
        self._task = asyncio.create_task(self._run_loop())
        logger.info(
            "ProactiveMemoryEngine: started (interval=%.0fs, cooldown=%.1fh)",
            self.config.check_interval_seconds,
            self.config.cooldown_hours,
        )

    def stop(self) -> None:
        """Stop periodic check task."""
        self._closed = True
        if self._task is not None and not self._task.done():
            self._task.cancel()
            self._task = None
        logger.info("ProactiveMemoryEngine: stopped")

    # Core logic
    async def evaluate_and_trigger(
        self,
        now: datetime | None = None,
    ) -> ProactiveTriggerResult:
        """Evaluate and trigger proactive message.

        Phase 1: Qdrant payload filter (time window + enabled + cooldown)
        Phase 2: dense vector search (current time context relevance)
        """
        now_dt = now or datetime.now(UTC)
        time_window = get_current_time_window(now_dt)
        cooldown_threshold = now_dt - timedelta(hours=self.config.cooldown_hours)

        # Phase 1: payload filter
        candidates = await self._filter_candidates(time_window, cooldown_threshold)
        if not candidates:
            logger.debug("ProactiveMemoryEngine: no candidates for time_window=%s", time_window)
            return ProactiveTriggerResult(triggered=False, time_window=time_window)

        # Phase 2: dense vector search (use time context as query)
        best = await self._rank_candidates(candidates, time_window)
        if best is None:
            return ProactiveTriggerResult(triggered=False, time_window=time_window)

        # Generate proactive message
        message = self._build_proactive_message(best, time_window)

        # Update last_triggered_at
        await self._update_last_triggered(best["point_id"], now_dt)

        # Call trigger callback
        if self.config.on_trigger is not None:
            try:
                await self.config.on_trigger(message)
            except Exception as exc:
                logger.warning("ProactiveMemoryEngine: on_trigger callback failed: %s", exc)

        logger.info(
            "ProactiveMemoryEngine: triggered [%s] path=%s score=%.3f",
            time_window,
            best.get("path", ""),
            best.get("score", 0.0),
        )

        return ProactiveTriggerResult(
            triggered=True,
            message=message,
            chunk_id=best.get("chunk_id", ""),
            path=best.get("path", ""),
            score=best.get("score", 0.0),
            time_window=time_window,
        )

    async def _filter_candidates(
        self,
        time_window: str,
        cooldown_threshold: datetime,
    ) -> list[dict[str, Any]]:
        """Phase 1: use Qdrant payload filter to select candidate memories.

        Filter conditions:
        - proactive_enabled == True
        - proactive_time_window == time_window
        - proactive_last_triggered_at < cooldown_threshold (or field missing)
        """
        try:
            from qdrant_client.models import (
                DatetimeRange,
                FieldCondition,
                Filter,
                MatchValue,
            )
        except ImportError:
            logger.warning("qdrant-client not installed; proactive engine disabled")
            return []

        try:
            # Build payload filter
            must_conditions = [
                FieldCondition(
                    key=PAYLOAD_PROACTIVE_ENABLED,
                    match=MatchValue(value=True),
                ),
                FieldCondition(
                    key=PAYLOAD_PROACTIVE_TIME_WINDOW,
                    match=MatchValue(value=time_window),
                ),
            ]
            must_not_conditions = [
                FieldCondition(
                    key=PAYLOAD_PROACTIVE_LAST_TRIGGERED_AT,
                    range=DatetimeRange(
                        gte=cooldown_threshold.isoformat(),
                    ),
                ),
            ]

            scroll_filter = Filter(
                must=must_conditions,
                must_not=must_not_conditions,
            )

            # Scroll query (fetch up to 20 candidates)
            result, _ = await self.indexer.client.scroll(
                collection_name=self.indexer.collection_name,
                scroll_filter=scroll_filter,
                limit=20,
                with_payload=True,
                with_vectors=False,
            )

            candidates = []
            for point in result:
                payload = point.payload or {}
                candidates.append(
                    {
                        "point_id": str(point.id),
                        "chunk_id": payload.get("chunk_id", str(point.id)),
                        "path": payload.get("path", ""),
                        "snippet": payload.get("snippet", ""),
                        "priority": int(payload.get(PAYLOAD_PROACTIVE_PRIORITY, 0)),
                        "score": 0.0,
                    }
                )

            logger.debug(
                "ProactiveMemoryEngine: %d candidates for time_window=%s",
                len(candidates),
                time_window,
            )
            return candidates

        except Exception as exc:
            logger.warning("ProactiveMemoryEngine: filter_candidates failed: %s", exc)
            return []

    async def _rank_candidates(
        self,
        candidates: list[dict[str, Any]],
        time_window: str,
    ) -> dict[str, Any] | None:
        """Phase 2: rank candidate memories via dense vector search.

        Use current time context as query, select most relevant candidate.
        """
        if not candidates:
            return None

        # If no embedding_fn, sort by priority and return top candidate
        if self.embedding_fn is None:
            return max(candidates, key=lambda c: c["priority"])

        # Build time context query
        greeting = get_time_window_greeting(time_window, self.config.language)
        if self.config.language == "zh":
            query = f"{greeting}，现在是{time_window}时间，有什么值得关注的事情"
        else:
            query = f"{greeting}, it's {time_window} time, what's worth noting"

        try:
            embeddings = await self.embedding_fn([query])
            query_vec = embeddings[0] if embeddings else []
        except Exception as exc:
            logger.warning("ProactiveMemoryEngine: embedding failed: %s", exc)
            return max(candidates, key=lambda c: c["priority"])

        if not query_vec:
            return max(candidates, key=lambda c: c["priority"])

        # Use point_id list to filter search scope
        try:
            from qdrant_client.models import Filter, HasIdCondition

            point_ids = [c["point_id"] for c in candidates]
            id_filter = Filter(must=[HasIdCondition(has_id=point_ids)])

            resp = await self.indexer.client.query_points(
                collection_name=self.indexer.collection_name,
                query=query_vec,
                query_filter=id_filter,
                limit=len(candidates),
                with_payload=True,
            )
            hits = resp.points

            # Write dense score back to candidates
            score_map = {str(hit.id): float(hit.score) for hit in hits}
            for c in candidates:
                c["score"] = score_map.get(c["point_id"], 0.0)

            # Combine score and priority for ranking
            # final_score = dense_score * 0.7 + priority_normalized * 0.3
            max_priority = max(c["priority"] for c in candidates) or 1
            for c in candidates:
                priority_norm = c["priority"] / max_priority
                c["final_score"] = 0.7 * c["score"] + 0.3 * priority_norm

            return max(candidates, key=lambda c: c["final_score"])

        except Exception as exc:
            logger.warning("ProactiveMemoryEngine: rank_candidates search failed: %s", exc)
            return max(candidates, key=lambda c: c["priority"])

    def _build_proactive_message(
        self,
        candidate: dict[str, Any],
        time_window: str,
    ) -> str:
        """Generate proactive message text from candidate memory.

        Format: greeting + memory summary
        """
        greeting = get_time_window_greeting(time_window, self.config.language)
        snippet = candidate.get("snippet", "").strip()

        if not snippet:
            return greeting

        if self.config.language == "zh":
            return f"{greeting}！我想起了一件事：\n\n{snippet}"
        return f"{greeting}! I just remembered something:\n\n{snippet}"

    async def _update_last_triggered(
        self,
        point_id: str,
        now_dt: datetime,
    ) -> None:
        """Update point's proactive_last_triggered_at field in Qdrant."""
        try:
            from qdrant_client.models import PointIdsList

            await self.indexer.client.set_payload(
                collection_name=self.indexer.collection_name,
                payload={PAYLOAD_PROACTIVE_LAST_TRIGGERED_AT: now_dt.isoformat()},
                points=PointIdsList(points=[point_id]),
            )
            logger.debug("ProactiveMemoryEngine: updated last_triggered_at for point %s", point_id)
        except Exception as exc:
            logger.warning("ProactiveMemoryEngine: failed to update last_triggered_at: %s", exc)

    # Periodic loop
    async def _run_loop(self) -> None:
        """Periodic check loop."""
        logger.info(
            "ProactiveMemoryEngine: loop started (interval=%.0fs)",
            self.config.check_interval_seconds,
        )
        while not self._closed:
            try:
                result = await self.evaluate_and_trigger()
                if result.triggered:
                    logger.info(
                        "ProactiveMemoryEngine: triggered message for window=%s",
                        result.time_window,
                    )
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                logger.warning("ProactiveMemoryEngine: loop error: %s", exc)

            try:
                await asyncio.sleep(self.config.check_interval_seconds)
            except asyncio.CancelledError:
                raise

        logger.info("ProactiveMemoryEngine: loop stopped")


# Factory functions


def create_proactive_engine(
    indexer: QdrantMemoryIndexer,
    embedding_fn: Callable[[list[str]], Coroutine[Any, Any, list[list[float]]]] | None = None,
    on_trigger: Callable[[str], Coroutine[Any, Any, None]] | None = None,
) -> ProactiveMemoryEngine:
    """Factory function: create ProactiveMemoryEngine from environment variables.

    Args:
        indexer       — QdrantMemoryIndexer instance
        embedding_fn  — async embedding function (optional; uses priority if missing)
        on_trigger    — trigger callback (receives message text, handled by upstream)
    """
    config = create_proactive_config_from_env(on_trigger=on_trigger)
    return ProactiveMemoryEngine(
        indexer=indexer,
        embedding_fn=embedding_fn,
        config=config,
    )
