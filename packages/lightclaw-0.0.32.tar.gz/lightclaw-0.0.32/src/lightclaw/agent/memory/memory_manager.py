"""Memory manager independent from AgentScope runtime types."""

from __future__ import annotations

import asyncio
import datetime
import json
import logging
import os
import re
from pathlib import Path
from typing import TYPE_CHECKING, Any

from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    HumanMessage,
    SystemMessage,
    ToolMessage,
)

from ...config.utils import load_config
from ...constant import MEMORY_COMPACT_RATIO
from ..utils.text_sanitizer import sanitize_summary_text
from ..utils.token_counting import count_str_tokens
from .compaction_config import CompactionConfig

if TYPE_CHECKING:
    from langchain_core.language_models import BaseChatModel as LCBaseChatModel

    from .qdrant_indexer import QdrantMemoryIndexer
    from .qdrant_searcher import QdrantMemorySearcher

logger = logging.getLogger(__name__)

# ── Safeguard compaction constants (aligned with OpenClaw) ────────────
_MAX_TOOL_FAILURES = 8
_MAX_TOOL_FAILURE_CHARS = 240
_SUMMARIZATION_OVERHEAD_TOKENS = 4096


def _split_summary_into_blocks(text: str) -> list[str]:
    """Split a markdown summary into logical blocks for dedup checking.

    Splits on double newlines, keeping markdown headers attached
    to their following content paragraph.
    """
    raw_blocks = re.split(r"\n\n+", text)
    merged: list[str] = []
    for block in raw_blocks:
        stripped = block.strip()
        if merged and merged[-1].strip().startswith("#") and not stripped.startswith("#"):
            # Attach content to its preceding header
            merged[-1] = merged[-1] + "\n\n" + block
        else:
            merged.append(block)
    return merged


class MemoryManager:
    """Memory manager for compaction/summarization/search."""

    def __init__(
        self,
        working_dir: str,
    ):
        config = load_config()
        max_input_length = config.agents.running.max_input_length
        self._memory_compact_threshold = int(
            max_input_length * MEMORY_COMPACT_RATIO * 0.9,
        )

        (
            embedding_api_key,
            embedding_base_url,
            embedding_model_name,
            embedding_dimensions,
            embedding_cache_enabled,
            embedding_max_cache_size,
            embedding_max_input_length,
            embedding_max_batch_size,
        ) = self.get_emb_envs()

        vector_enabled = bool(embedding_api_key)
        if vector_enabled:
            logger.info("Vector search enabled.")
        else:
            logger.info(
                "Vector search disabled (keyword-only mode). Enable in Settings → Memory.",
            )

        self.working_dir = working_dir
        self.embedding_api_key = embedding_api_key
        self.embedding_base_url = embedding_base_url
        self.embedding_model_name = embedding_model_name
        self.embedding_dimensions = embedding_dimensions
        self.embedding_cache_enabled = embedding_cache_enabled
        self.embedding_max_cache_size = embedding_max_cache_size
        self.embedding_max_input_length = embedding_max_input_length
        self.embedding_max_batch_size = embedding_max_batch_size

        global_config = load_config()
        self.language = "zh" if global_config.agents.language == "zh" else ""
        self.summary_tasks: list[asyncio.Task] = []

        self.langchain_chat_model: LCBaseChatModel | None = None

        # Qdrant 记忆索引层（注入后替换默认的 memory_search / memory_get）
        self._qdrant_indexer: QdrantMemoryIndexer | None = None
        self._qdrant_searcher: QdrantMemorySearcher | None = None

    @staticmethod
    def _safe_int(value: str | None, default: int) -> int:
        if value is None:
            return default
        try:
            return int(value)
        except ValueError:
            logger.warning("Invalid int value '%s', using default %d", value, default)
            return default

    @staticmethod
    def get_emb_envs():
        # 优先读取配置文件中的 embedding 字段，环境变量作为 fallback
        try:
            cfg_embedding = load_config().embedding
        except Exception:
            cfg_embedding = None

        if cfg_embedding is not None and cfg_embedding.provider == "custom":
            # custom 模式：从配置文件读取，环境变量可覆盖
            embedding_api_key = os.environ.get("EMBEDDING_API_KEY", "") or cfg_embedding.api_key
            embedding_base_url = os.environ.get("EMBEDDING_BASE_URL", "") or cfg_embedding.base_url
            embedding_model_name = os.environ.get("EMBEDDING_MODEL_NAME", "") or cfg_embedding.model_name
            default_dimensions = cfg_embedding.dimensions
        else:
            # none / local 模式或配置文件读取失败：回退到纯环境变量
            embedding_api_key = os.environ.get("EMBEDDING_API_KEY", "")
            embedding_base_url = os.environ.get("EMBEDDING_BASE_URL", "")
            embedding_model_name = os.environ.get("EMBEDDING_MODEL_NAME", "")
            default_dimensions = 1024

        # Graceful degradation: log info instead of warnings when embedding
        # env vars are not configured — this is expected when provider="none".
        # Vector search will be disabled automatically (see __init__).
        if not embedding_base_url:
            logger.info(
                "EMBEDDING_BASE_URL not set. Memory vector search disabled. "
                "Enable in Settings → Memory to use semantic search."
            )
        if not embedding_model_name:
            logger.info("EMBEDDING_MODEL_NAME not set. Memory vector search disabled.")

        embedding_dimensions = MemoryManager._safe_int(
            os.environ.get("EMBEDDING_DIMENSIONS"),
            default_dimensions,
        )
        embedding_cache_enabled = os.environ.get("EMBEDDING_CACHE_ENABLED", "true").lower() == "true"
        embedding_max_cache_size = MemoryManager._safe_int(
            os.environ.get("EMBEDDING_MAX_CACHE_SIZE"),
            2000,
        )
        embedding_max_input_length = MemoryManager._safe_int(
            os.environ.get("EMBEDDING_MAX_INPUT_LENGTH"),
            8192,
        )
        embedding_max_batch_size = MemoryManager._safe_int(
            os.environ.get("EMBEDDING_MAX_BATCH_SIZE"),
            10,
        )
        return (
            embedding_api_key,
            embedding_base_url,
            embedding_model_name,
            embedding_dimensions,
            embedding_cache_enabled,
            embedding_max_cache_size,
            embedding_max_input_length,
            embedding_max_batch_size,
        )

    def update_emb_envs(self):
        (
            embedding_api_key,
            embedding_base_url,
            embedding_model_name,
            embedding_dimensions,
            embedding_cache_enabled,
            embedding_max_cache_size,
            embedding_max_input_length,
            embedding_max_batch_size,
        ) = self.get_emb_envs()

        self.embedding_api_key = embedding_api_key
        self.embedding_base_url = embedding_base_url
        self.embedding_model_name = embedding_model_name
        self.embedding_dimensions = embedding_dimensions
        self.embedding_cache_enabled = embedding_cache_enabled
        self.embedding_max_cache_size = embedding_max_cache_size
        self.embedding_max_input_length = embedding_max_input_length
        self.embedding_max_batch_size = embedding_max_batch_size

    async def start(self):
        """启动 MemoryManager（当前由 Qdrant 层接管，此处为空实现）。"""
        return None

    async def close(self):
        """关闭 MemoryManager（当前由 Qdrant 层接管，此处为空实现）。"""
        return None

    def _extract_message_text(self, message: Any) -> str:
        if isinstance(message, BaseMessage):
            return self._extract_langchain_message_text(message)

        content = getattr(message, "content", "")

        if isinstance(content, str):
            return content

        if not isinstance(content, list):
            return str(content)

        parts: list[str] = []
        for block in content:
            if not isinstance(block, dict):
                parts.append(str(block))
                continue

            block_type = block.get("type", "")
            if block_type == "text":
                parts.append(str(block.get("text", "")))
            elif block_type == "thinking":
                parts.append(str(block.get("thinking", "")))
            elif block_type == "tool_use":
                name = block.get("name", "")
                tool_input = block.get("input", {})
                parts.append(
                    f"[tool_use] {name} {json.dumps(tool_input, ensure_ascii=False)}",
                )
            elif block_type == "tool_result":
                output = block.get("output", "")
                if isinstance(output, list | dict):
                    output = json.dumps(output, ensure_ascii=False)
                parts.append(f"[tool_result] {output}")
            elif block_type in ("image", "audio", "video", "file"):
                source = block.get("source", {})
                parts.append(f"[{block_type}] {source.get('url', '')}")

        return "\n".join(part for part in parts if part)

    def _extract_langchain_message_text(self, message: BaseMessage) -> str:
        """Extract readable text from a LangChain message."""
        parts: list[str] = []

        content = getattr(message, "content", "")
        if isinstance(content, str) and content:
            parts.append(content)
        elif isinstance(content, list):
            for block in content:
                if isinstance(block, str):
                    parts.append(block)
                    continue
                if not isinstance(block, dict):
                    parts.append(str(block))
                    continue
                block_type = block.get("type", "")
                if block_type == "text":
                    parts.append(str(block.get("text", "")))
                elif block_type == "image_url":
                    image_url = block.get("image_url", {}).get("url", "")
                    parts.append(f"[image] {image_url}")
                else:
                    parts.append(str(block))

        additional_kwargs = getattr(message, "additional_kwargs", None) or {}
        thinking = additional_kwargs.get("thinking")
        if isinstance(thinking, str) and thinking:
            parts.append(f"[thinking] {thinking}")

        if isinstance(message, AIMessage):
            for tool_call in message.tool_calls or []:
                parts.append(
                    "[tool_use] "
                    f"{tool_call.get('name', '')} "
                    f"{json.dumps(tool_call.get('args', {}), ensure_ascii=False)}"
                )
        elif isinstance(message, ToolMessage):
            tool_name = getattr(message, "name", "") or ""
            parts.append(f"[tool_result] {tool_name} {message.content}")
        elif isinstance(message, HumanMessage | SystemMessage):
            pass

        for key, label in (
            ("file_blocks", "file"),
            ("audio_blocks", "audio"),
            ("video_blocks", "video"),
        ):
            for block in additional_kwargs.get(key, []) or []:
                if not isinstance(block, dict):
                    continue
                source = block.get("source", {})
                if isinstance(source, dict):
                    parts.append(f"[{label}] {source.get('url', '')}")

        return "\n".join(part for part in parts if part)

    async def _invoke_llm(
        self,
        system_prompt: str,
        user_message: str,
    ) -> str:
        if self.langchain_chat_model is None:
            return user_message[:3000]

        from langchain_core.messages import HumanMessage, SystemMessage

        result = await self.langchain_chat_model.ainvoke(
            [
                SystemMessage(content=system_prompt),
                HumanMessage(content=user_message),
            ],
        )
        return result.content if isinstance(result.content, str) else str(result.content)

    async def _invoke_llm_with_tools(
        self,
        system_prompt: str,
        user_message: str,
    ) -> str:
        if self.langchain_chat_model is None:
            return await self._invoke_llm(system_prompt, user_message)

        from langchain.agents import create_agent

        from ..langgraph.tools.builtins import (
            edit_file as lc_edit_file,
        )
        from ..langgraph.tools.builtins import (
            read_file as lc_read_file,
        )
        from ..langgraph.tools.builtins import (
            write_file as lc_write_file,
        )

        graph = create_agent(
            model=self.langchain_chat_model,
            tools=[lc_read_file, lc_write_file, lc_edit_file],
            system_prompt=system_prompt,
        )
        result = await graph.ainvoke({"messages": [("user", user_message)]})
        final_msg = result["messages"][-1]
        return final_msg.content if isinstance(final_msg.content, str) else str(final_msg.content)

    # ── Compaction (safeguard pipeline) ────────────────────────────────

    def _build_compaction_prompt(self, config: CompactionConfig) -> str:
        """Build a structured system prompt for compaction.

        Requires the LLM to produce 5 mandatory sections and follows
        the configured identifier preservation policy.
        """
        # Identifier policy instruction
        if config.identifier_policy == "strict":
            id_instruction = (
                "Preserve all opaque identifiers exactly as written "
                "(no shortening or reconstruction), including UUIDs, hashes, "
                "IDs, tokens, API keys, hostnames, IPs, ports, URLs, and file names."
            )
        elif config.identifier_policy == "custom" and config.identifier_instructions:
            id_instruction = config.identifier_instructions[:4000]
        else:
            id_instruction = (
                "Include identifiers only when needed for continuity; do not enforce literal-preservation rules."
            )

        custom_block = ""
        if config.custom_instructions:
            custom_block = f"\n\nADDITIONAL INSTRUCTIONS:\n{config.custom_instructions}"

        if self.language == "zh":
            return (
                "你是一个高质量对话上下文压缩器。将对话历史压缩为结构化摘要。\n\n"
                "【输出格式 — 必须包含以下所有 section】：\n\n"
                "## Decisions\n决策及其理由（如：选择了方案 A 因为 X）\n\n"
                "## Open TODOs\n待办事项、截止日期、承诺\n\n"
                "## Constraints/Rules\n技术约束、用户偏好、项目规则\n\n"
                "## Pending user asks\n最近未完成的用户请求\n\n"
                "## Exact identifiers\nUUID、URL、文件路径、哈希值、日期、端口号\n\n"
                f"【标识符策略】：{id_instruction}\n\n"
                "【可以丢弃】：\n"
                "- 寒暄和客套话\n"
                "- 没有结论的中间调试过程\n"
                "- 重复或冗余的信息 — 主动合并多次出现的相同事实，"
                "同一事实只保留最完整/最新的版本\n"
                "- 工具调用的完整输入输出（只保留关键结论）\n\n"
                "如果某个 section 没有内容，保留标题并写 '(none)'。"
                f"{custom_block}"
            )
        return (
            "You are a high-quality conversation context compressor. "
            "Condense the conversation history into a structured summary.\n\n"
            "OUTPUT FORMAT — you MUST include ALL of the following sections:\n\n"
            "## Decisions\nDecisions and their rationale\n\n"
            "## Open TODOs\nPending tasks, deadlines, commitments\n\n"
            "## Constraints/Rules\nTechnical constraints, user preferences, project rules\n\n"
            "## Pending user asks\nRecent unresolved user requests\n\n"
            "## Exact identifiers\nUUIDs, URLs, file paths, hashes, dates, ports\n\n"
            f"IDENTIFIER POLICY: {id_instruction}\n\n"
            "MAY DROP:\n"
            "- Conversational filler and pleasantries\n"
            "- Intermediate debugging steps that led nowhere\n"
            "- Redundant or repeated information — actively MERGE duplicate facts "
            "that appear multiple times; keep only the most complete/recent version\n"
            "- Full tool call input/output (keep only key conclusions)\n\n"
            "If a section has no content, keep the heading and write '(none)'."
            f"{custom_block}"
        )

    def _collect_tool_failures(self, messages: list[Any]) -> str:
        """Extract failed tool calls and format as a summary section.

        Returns an empty string when there are no failures.
        """
        failures: list[str] = []
        seen_ids: set[str] = set()

        for msg in messages:
            if not isinstance(msg, ToolMessage):
                continue
            # ToolMessage.status == "error" indicates failure
            status = getattr(msg, "status", None)
            is_error = status == "error"
            # Also check additional_kwargs for isError flag
            if not is_error:
                additional = getattr(msg, "additional_kwargs", {}) or {}
                is_error = additional.get("isError", False)
            if not is_error:
                continue

            tool_call_id = getattr(msg, "tool_call_id", "") or ""
            if tool_call_id in seen_ids:
                continue
            if tool_call_id:
                seen_ids.add(tool_call_id)

            tool_name = getattr(msg, "name", "") or "tool"
            content = msg.content if isinstance(msg.content, str) else str(msg.content)
            # Normalize whitespace and truncate
            content = " ".join(content.split()).strip()
            if len(content) > _MAX_TOOL_FAILURE_CHARS:
                content = content[: _MAX_TOOL_FAILURE_CHARS - 3] + "..."

            failures.append(f"- {tool_name}: {content}")
            if len(failures) >= _MAX_TOOL_FAILURES:
                break

        if not failures:
            return ""

        return "\n\n## Tool Failures\n" + "\n".join(failures)

    def _compute_adaptive_chunks(
        self,
        messages: list[Any],
        context_window: int,
        config: CompactionConfig,
    ) -> list[list[Any]]:
        """Split messages into adaptive-size chunks based on message complexity.

        Chunk size adapts to average message size — larger messages produce
        smaller chunks to stay within the summarization model's capacity.
        """
        if not messages:
            return []

        # Estimate total tokens
        msg_texts = [self._extract_message_text(m) for m in messages]
        msg_tokens = [count_str_tokens(t) for t in msg_texts]
        total_tokens = sum(msg_tokens)

        if total_tokens == 0:
            return [messages]

        # Compute adaptive chunk ratio
        avg_msg_tokens = total_tokens / len(messages)
        context_10pct = context_window * 0.1

        if avg_msg_tokens > context_10pct:
            # Large messages — shrink chunk ratio proportionally
            ratio = max(
                config.min_chunk_ratio,
                config.base_chunk_ratio * (context_10pct / avg_msg_tokens),
            )
        else:
            ratio = config.base_chunk_ratio

        # Apply safety margin and compute target chunk token count
        chunk_budget = int(context_window * ratio / config.safety_margin)
        chunk_budget = max(chunk_budget, _SUMMARIZATION_OVERHEAD_TOKENS * 2)

        # Split messages into chunks
        chunks: list[list[Any]] = []
        current_chunk: list[Any] = []
        current_tokens = 0

        for msg, tok in zip(messages, msg_tokens, strict=True):
            if current_tokens + tok > chunk_budget and current_chunk:
                chunks.append(current_chunk)
                current_chunk = []
                current_tokens = 0
            current_chunk.append(msg)
            current_tokens += tok

        if current_chunk:
            chunks.append(current_chunk)

        logger.info(
            "Adaptive chunking: %d messages → %d chunks (avg_msg=%d tokens, ratio=%.2f, budget=%d tokens/chunk)",
            len(messages),
            len(chunks),
            int(avg_msg_tokens),
            ratio,
            chunk_budget,
        )
        return chunks

    async def _summarize_in_stages(
        self,
        chunks: list[list[Any]],
        previous_summary: str,
        system_prompt: str,
    ) -> str:
        """Summarize message chunks independently, then merge into one summary.

        For a single chunk, performs a single-pass summarization (same as
        default behavior).  For multiple chunks, summarizes each independently
        and then merges partial summaries.
        """
        if len(chunks) == 1:
            # Single chunk — direct summarization
            text = "\n\n".join(self._extract_message_text(m) for m in chunks[0])
            prompt_parts = []
            if previous_summary:
                prompt_parts.append(f"Previous summary:\n{previous_summary}")
            prompt_parts.append(f"Conversation to summarize:\n{text}")
            prompt = "\n\n".join(prompt_parts).strip()
            return await self._invoke_llm(system_prompt, prompt)

        # Multi-stage: summarize each chunk, then merge
        partial_summaries: list[str] = []
        for i, chunk in enumerate(chunks):
            text = "\n\n".join(self._extract_message_text(m) for m in chunk)
            chunk_prompt_parts = []
            if i == 0 and previous_summary:
                chunk_prompt_parts.append(f"Previous summary:\n{previous_summary}")
            chunk_prompt_parts.append(
                f"Conversation chunk {i + 1}/{len(chunks)} to summarize:\n{text}",
            )
            chunk_prompt = "\n\n".join(chunk_prompt_parts).strip()

            partial = await self._invoke_llm(system_prompt, chunk_prompt)
            partial_summaries.append(partial)
            logger.info("Stage %d/%d summarized (%d chars)", i + 1, len(chunks), len(partial))

        # Merge partial summaries
        if self.language == "zh":
            merge_instruction = (
                "将以下部分摘要合并为一个连贯的完整摘要。保留所有必需的 section，合并重复内容，保持时间顺序。\n\n"
            )
        else:
            merge_instruction = (
                "Merge the following partial summaries into a single cohesive summary. "
                "Preserve all required sections, deduplicate, keep chronological order.\n\n"
            )

        parts_text = "\n\n---\n\n".join(f"[Part {i + 1}]\n{s}" for i, s in enumerate(partial_summaries))
        merge_prompt = f"{merge_instruction}{parts_text}"
        return await self._invoke_llm(system_prompt, merge_prompt)

    def _summary_system_prompt(self) -> str:
        """Return a structured system prompt for long-term memory extraction."""
        if self.language == "zh":
            return (
                "你是一个长期记忆提取器。从对话中提取值得长期保存的关键信息。\n\n"
                "请用以下结构组织输出：\n\n"
                "## 关键决策\n- 做了什么决定，为什么\n\n"
                "## 待办事项\n- [ ] 尚未完成的任务\n- [x] 已完成的任务\n\n"
                "## 重要事实\n- 人名、项目名、技术栈等关键事实\n\n"
                "## 约束与偏好\n- 用户明确表达的约束条件和偏好\n\n"
                "如果某个分类没有内容，直接省略该分类。保持简洁，只记录值得长期保存的信息。\n\n"
                "去重规则：记录事实前，检查你的输出中是否已有相同内容。"
                "同一事实、偏好或决策只保留一条，合并为最完整的版本。"
            )
        return (
            "You are a long-term memory extractor. Extract key information worth "
            "preserving from the conversation.\n\n"
            "Organize your output using this structure:\n\n"
            "## Key Decisions\n- What was decided and why\n\n"
            "## Action Items\n- [ ] Pending tasks\n- [x] Completed tasks\n\n"
            "## Important Facts\n- Names, projects, tech stack, and other key facts\n\n"
            "## Constraints & Preferences\n- User-stated constraints and preferences\n\n"
            "Omit any section that has no content. Be concise — only record "
            "information worth long-term preservation.\n\n"
            "DEDUP RULE: Before recording a fact, check if it already appears in "
            "your output. Never repeat the same fact, preference, or decision — "
            "merge into one entry with the most complete version."
        )

    async def compact_memory(
        self,
        messages_to_summarize: list[Any] | None = None,
        turn_prefix_messages: list[Any] | None = None,
        previous_summary: str = "",
        config: CompactionConfig | None = None,
    ) -> str:
        """Compact conversation messages into a structured summary.

        Uses the safeguard pipeline: structured output with 5 mandatory
        sections, identifier preservation policy, adaptive chunking,
        tool failure tracking, and optional quality guard with retry.
        """
        self.update_emb_envs()

        if config is None:
            config = CompactionConfig()

        summarize_msgs = messages_to_summarize or []
        prefix_msgs = turn_prefix_messages or []
        if not summarize_msgs and not prefix_msgs:
            return ""

        all_msgs = summarize_msgs + prefix_msgs

        # Step 1: Build structured system prompt
        system_prompt = self._build_compaction_prompt(config)

        # Step 2: Adaptive chunking + multi-stage summarization
        app_config = load_config()
        context_window = app_config.agents.running.max_input_length

        chunks = self._compute_adaptive_chunks(summarize_msgs, context_window, config)
        if not chunks:
            chunks = [summarize_msgs] if summarize_msgs else []

        if chunks:
            summary = await self._summarize_in_stages(chunks, previous_summary, system_prompt)
        elif previous_summary:
            summary = previous_summary
        else:
            summary = ""

        # If there were prefix messages, include them as context addendum
        if prefix_msgs and summary:
            prefix_text = "\n\n".join(self._extract_message_text(m) for m in prefix_msgs)
            if prefix_text.strip():
                if self.language == "zh":
                    addendum_prompt = (
                        f"以下是当前摘要和最近的上下文。请将最近上下文中的关键信息整合到摘要中。\n\n"
                        f"当前摘要:\n{summary}\n\n最近上下文:\n{prefix_text}"
                    )
                else:
                    addendum_prompt = (
                        f"Below is the current summary and recent context. "
                        f"Integrate key information from the recent context into the summary.\n\n"
                        f"Current summary:\n{summary}\n\nRecent context:\n{prefix_text}"
                    )
                summary = await self._invoke_llm(system_prompt, addendum_prompt)

        # Step 3: Collect and append tool failures
        tool_failures_section = self._collect_tool_failures(all_msgs)
        if tool_failures_section:
            summary = summary.rstrip() + tool_failures_section

        # Step 4: Quality guard with retry
        if config.quality_guard_enabled and summary:
            from .compaction_quality_guard import audit_and_retry

            original_text = "\n\n".join(self._extract_message_text(m) for m in all_msgs)

            # Build base prompt for retry (same as initial single-chunk prompt)
            base_prompt_parts = []
            if previous_summary:
                base_prompt_parts.append(f"Previous summary:\n{previous_summary}")
            base_prompt_parts.append(
                f"Conversation to summarize:\n{original_text}",
            )
            base_user_prompt = "\n\n".join(base_prompt_parts).strip()

            summary = await audit_and_retry(
                summary=summary,
                original_messages=[m for m in all_msgs if isinstance(m, BaseMessage)],
                original_text=original_text,
                config=config,
                invoke_llm=self._invoke_llm,
                system_prompt=system_prompt,
                base_user_prompt=base_user_prompt,
                language=self.language or "en",
            )

        # Step 5: Sanitize
        return sanitize_summary_text(summary)

    def _next_version(self, memory_dir: Path, prefix: str) -> int:
        """Find the next available version number for a given filename prefix.

        Scans existing files matching ``{prefix}_v{N}.md`` and returns N+1.
        """
        max_ver = 0
        for f in memory_dir.glob(f"{prefix}_v*.md"):
            stem = f.stem  # e.g. "2026-03-05_console_sess123_v2"
            parts = stem.rsplit("_v", 1)
            if len(parts) == 2:
                try:
                    max_ver = max(max_ver, int(parts[1]))
                except ValueError:
                    continue
        return max_ver + 1

    async def summary_memory(
        self,
        messages: list[Any],
        date: str,
        channel: str = "",
        session_id: str = "",
    ) -> str:
        self.update_emb_envs()

        text = "\n\n".join(self._extract_message_text(msg) for msg in messages)
        if not text.strip():
            return ""

        meta = f"Date: {date}"
        if channel:
            meta += f" | Channel: {channel}"
        if session_id:
            meta += f" | Session: {session_id}"

        if self.language == "zh":
            prompt = f"{meta}\n\n请从以下对话中提取值得长期保存的关键信息：\n\n{text}"
        else:
            prompt = (
                f"{meta}\n\n"
                f"Extract key information worth long-term preservation "
                f"from the following conversation:\n\n{text}"
            )
        try:
            result = await self._invoke_llm_with_tools(
                system_prompt=self._summary_system_prompt(),
                user_message=prompt,
            )
            logger.info("Memory Summary Result:\n%s", result)

            # Post-filter: remove paragraphs that duplicate existing memory
            result = await self._dedup_summary_against_existing(result)

            # Persist summary to ~/.lightclaw/memory/ so file_watcher can
            # index it and memory_search can retrieve it later.
            if result.strip():
                memory_dir = Path(self.working_dir) / "memory"
                memory_dir.mkdir(parents=True, exist_ok=True)

                # Build filename: {date}_{channel}_{session_id}_v{N}.md
                parts = [date]
                if channel:
                    parts.append(channel)
                if session_id:
                    # Truncate long session ids for readable filenames
                    parts.append(session_id[:13])
                prefix = "_".join(parts)
                ver = self._next_version(memory_dir, prefix)
                filename = f"{prefix}_v{ver}.md"

                filepath = memory_dir / filename
                filepath.write_text(result, encoding="utf-8")
                logger.info("Memory summary persisted to %s", filepath)

            return result
        except Exception as exc:
            logger.exception("Failed to generate memory summary: %s", exc)
            return ""

    async def _dedup_summary_against_existing(self, summary_text: str) -> str:
        """Remove paragraphs from a new summary that duplicate existing memory.

        Splits the summary into blocks, checks each against the vector/FTS
        index, and omits near-duplicates of already-indexed content.
        Returns the original text if dedup is disabled or searcher unavailable.
        """
        if self._qdrant_searcher is None or not summary_text.strip():
            return summary_text

        from .dedup import create_dedup_config_from_env, jaccard_similarity

        config = create_dedup_config_from_env()
        if not config.enabled:
            return summary_text

        # Split into logical blocks (paragraphs / sections)
        blocks = _split_summary_into_blocks(summary_text)
        if len(blocks) <= 1:
            # Single block — don't risk removing everything
            return summary_text

        kept_blocks: list[str] = []
        for block in blocks:
            text = block.strip()
            if not text or text.startswith("#"):
                # Always keep headers and empty lines
                kept_blocks.append(block)
                continue

            # Skip very short blocks (likely not meaningful facts)
            if len(text) < 20:
                kept_blocks.append(block)
                continue

            try:
                from .qdrant_searcher import SearchConfig

                cfg = SearchConfig(max_results=3, min_score=0.5)
                results = await self._qdrant_searcher.search(text, config=cfg)

                is_dup = False
                for result in results:
                    sim = jaccard_similarity(text, result.snippet)
                    if sim >= config.jaccard_skip_threshold:
                        logger.info(
                            "Summary dedup: omitting block (%.3f Jaccard with %s): %.80s",
                            sim,
                            result.chunk_id,
                            text,
                        )
                        is_dup = True
                        break
                if not is_dup:
                    kept_blocks.append(block)
            except Exception:
                # On any error, keep the block (safe fallback)
                kept_blocks.append(block)

        result = "\n\n".join(kept_blocks).strip()
        if not result:
            # Safety: never return empty
            logger.warning("Summary dedup removed ALL blocks — keeping original")
            return summary_text

        return result

    async def await_summary_tasks(self) -> str:
        result = ""
        for task in self.summary_tasks:
            if task.done():
                exc = task.exception()
                if exc is not None:
                    logger.exception("Summary task failed: %s", exc)
                    result += f"Summary task failed: {exc}\n"
                else:
                    done = task.result()
                    logger.info("Summary task completed: %s", done)
                    result += f"Summary task completed: {done}\n"
            else:
                try:
                    done = await task
                    logger.info("Summary task completed: %s", done)
                    result += f"Summary task completed: {done}\n"
                except Exception as exc:
                    logger.exception("Summary task failed: %s", exc)
                    result += f"Summary task failed: {exc}\n"

        self.summary_tasks.clear()
        return result

    def add_async_summary_task(
        self,
        messages: list[Any],
        date: str = "",
        channel: str = "",
        session_id: str = "",
    ):
        remaining_tasks = []
        for task in self.summary_tasks:
            if task.done():
                exc = task.exception()
                if exc is not None:
                    logger.exception("Summary task failed: %s", exc)
                else:
                    logger.info("Summary task completed: %s", task.result())
            else:
                remaining_tasks.append(task)
        self.summary_tasks = remaining_tasks

        self.summary_tasks.append(
            asyncio.create_task(
                self.summary_memory(
                    messages=messages,
                    date=date or datetime.datetime.now().strftime("%Y-%m-%d"),
                    channel=channel,
                    session_id=session_id,
                ),
            ),
        )

    def set_qdrant_searcher(
        self,
        indexer: QdrantMemoryIndexer,
        searcher: QdrantMemorySearcher,
    ) -> None:
        """
        注入 Qdrant 索引器和检索器。
        在 agent 启动时调用（对标 openclaw MemoryIndexManager.get() 工厂方法）。
        """
        self._qdrant_indexer = indexer
        self._qdrant_searcher = searcher
        logger.info("QdrantMemorySearcher injected into MemoryManager")

    # ── Distillation: memory/*.md → MEMORY.md ────────────────────────────

    # Default: distill at most once every 3 days.
    DISTILL_INTERVAL_DAYS = int(os.environ.get("LIGHTCLAW_DISTILL_INTERVAL_DAYS", "1"))
    # How many recent days of daily notes to read for distillation.
    DISTILL_LOOKBACK_DAYS = int(os.environ.get("LIGHTCLAW_DISTILL_LOOKBACK_DAYS", "7"))

    def _distill_stamp_path(self) -> Path:
        """Path to the timestamp file that records when distillation last ran."""
        return Path(self.working_dir) / ".last_distill"

    def should_distill(self) -> bool:
        """Check whether enough time has passed since last distillation."""
        stamp = self._distill_stamp_path()
        if not stamp.exists():
            return True
        try:
            last_ts = float(stamp.read_text(encoding="utf-8").strip())
            elapsed_days = (datetime.datetime.now().timestamp() - last_ts) / 86400
            return elapsed_days >= self.DISTILL_INTERVAL_DAYS
        except (ValueError, OSError):
            return True

    async def distill_to_memory_md(self) -> str:
        """Distill recent daily notes into MEMORY.md.

        Reads memory/*.md files from the last DISTILL_LOOKBACK_DAYS days,
        asks the LLM to extract key insights, deduplicates against existing
        MEMORY.md content, and appends the result.

        Returns the distilled text (empty string if nothing to distill).
        """
        memory_dir = Path(self.working_dir) / "memory"
        if not memory_dir.exists():
            return ""

        # Collect recent daily note files (YYYY-MM-DD pattern in filename)
        cutoff = datetime.datetime.now() - datetime.timedelta(days=self.DISTILL_LOOKBACK_DAYS)
        date_pattern = re.compile(r"(\d{4}-\d{2}-\d{2})")
        recent_files: list[tuple[str, Path]] = []

        for md_file in sorted(memory_dir.glob("*.md")):
            m = date_pattern.search(md_file.name)
            if not m:
                continue
            try:
                file_date = datetime.datetime.strptime(m.group(1), "%Y-%m-%d")
            except ValueError:
                continue
            if file_date >= cutoff:
                recent_files.append((m.group(1), md_file))

        if not recent_files:
            logger.info("Distillation: no recent daily notes found")
            self._touch_distill_stamp()
            return ""

        # Read contents
        source_texts: list[str] = []
        for date_str, fpath in recent_files:
            try:
                text = fpath.read_text(encoding="utf-8").strip()
                if text:
                    source_texts.append(f"### {date_str}\n{text}")
            except OSError:
                continue

        if not source_texts:
            self._touch_distill_stamp()
            return ""

        combined = "\n\n".join(source_texts)
        # Truncate to avoid exceeding context window — keep ~60k chars max
        if len(combined) > 60000:
            combined = combined[:60000] + "\n\n[... truncated ...]"

        # Read existing MEMORY.md to provide context for dedup
        memory_md_path = Path(self.working_dir) / "MEMORY.md"
        existing_memory = ""
        if memory_md_path.exists():
            import contextlib

            with contextlib.suppress(OSError):
                existing_memory = memory_md_path.read_text(encoding="utf-8").strip()

        # Build distillation prompt
        if self.language == "zh":
            system = (
                "你是一个记忆蒸馏助手。从每日笔记中提炼出值得长期保留的关键信息——"
                "重大决策、用户偏好变化、踩过的坑、重要结论。"
                "输出简洁的要点列表（Markdown），不要复述原文，不要包含日常闲聊和临时信息。"
                "如果所有内容都不值得长期保留，只输出 NOTHING_TO_DISTILL。"
            )
            user_msg = (
                f"## 现有 MEMORY.md 内容（避免重复）\n\n{existing_memory}\n\n---\n\n## 近期每日笔记\n\n{combined}"
            )
        else:
            system = (
                "You are a memory distillation assistant. Extract key information "
                "worth long-term retention from daily notes — major decisions, user "
                "preference changes, lessons learned, important conclusions. "
                "Output a concise bullet-point list (Markdown). Do not repeat raw "
                "conversation logs or trivial chat. "
                "If nothing is worth keeping, output only NOTHING_TO_DISTILL."
            )
            user_msg = (
                f"## Existing MEMORY.md (avoid repeating)\n\n{existing_memory}\n\n"
                f"---\n\n## Recent daily notes\n\n{combined}"
            )

        try:
            result = await self._invoke_llm(system, user_msg)
            result = sanitize_summary_text(result).strip()
        except Exception:
            logger.exception("Distillation LLM call failed")
            return ""

        if not result or "NOTHING_TO_DISTILL" in result:
            logger.info("Distillation: nothing worth keeping from recent notes")
            self._touch_distill_stamp()
            return ""

        # Dedup against existing memory index
        result = await self._dedup_summary_against_existing(result)
        if not result.strip():
            logger.info("Distillation: all content duplicated existing memory")
            self._touch_distill_stamp()
            return ""

        # Append to MEMORY.md
        today = datetime.datetime.now().strftime("%Y-%m-%d")
        distill_section = f"\n\n## Distilled on {today}\n\n{result}\n"
        try:
            with open(memory_md_path, "a", encoding="utf-8") as f:
                f.write(distill_section)
            logger.info(
                "Distillation: appended %d chars to MEMORY.md from %d daily notes",
                len(distill_section),
                len(recent_files),
            )
        except OSError:
            logger.exception("Failed to append distilled content to MEMORY.md")

        self._touch_distill_stamp()
        return result

    def _touch_distill_stamp(self) -> None:
        """Update the distillation timestamp file."""
        try:
            self._distill_stamp_path().write_text(
                str(datetime.datetime.now().timestamp()),
                encoding="utf-8",
            )
        except OSError:
            logger.warning("Failed to update distillation timestamp")

    async def memory_search(
        self,
        query: str,
        max_results: int = 5,
        min_score: float = 0.3,
    ) -> str:
        if not query:
            return "Error: No query provided."

        if isinstance(max_results, int):
            max_results = min(max(max_results, 1), 100)
        else:
            max_results = 5

        if isinstance(min_score, float):
            min_score = min(max(min_score, 0.001), 0.999)
        else:
            min_score = 0.3

        # 优先走 Qdrant 检索器
        if self._qdrant_searcher is not None:
            return await self._qdrant_memory_search(query, max_results, min_score)

        return "No memory backend available."

    async def _qdrant_memory_search(
        self,
        query: str,
        max_results: int,
        min_score: float,
    ) -> str:
        """
        使用 Qdrant 执行 hybrid 搜索，返回格式化字符串。
        对标 openclaw MemorySearchResult 格式。
        """
        from .qdrant_searcher import create_search_config_from_env

        cfg = create_search_config_from_env()
        cfg.max_results = max_results
        cfg.min_score = min_score

        try:
            results = await self._qdrant_searcher.search(  # type: ignore[union-attr]
                query=query,
                config=cfg,
            )
        except Exception as exc:
            logger.warning("Qdrant memory_search failed: %s", exc)
            return "Memory search failed."

        if not results:
            return "No relevant memories found."

        # 格式化输出（对标 openclaw citation 格式）
        lines: list[str] = []
        for r in results:
            lines.append(f"[{r.path}:{r.start_line}] (score={r.score:.3f})\n{r.snippet}")
        return "\n\n---\n\n".join(lines)

    async def memory_get(
        self,
        path: str,
        offset: int | None = None,
        limit: int | None = None,
    ) -> str:
        # 优先走 Qdrant indexer 的 read_file
        if self._qdrant_indexer is not None:
            try:
                return self._qdrant_indexer.read_file(path, offset, limit)
            except Exception as exc:
                logger.warning("Qdrant memory_get failed: %s", exc)

        return ""

    async def memory_status(self) -> dict:
        """
        返回记忆系统的健康状态。
        可用于 Dashboard 展示或日志排查。

        返回字段：
            chunk_count     — Qdrant 中的 chunk 总数
            vector_enabled  — 是否启用向量搜索
            dirty           — 是否有待同步的文件变更
            fts_count       — SQLite FTS5 中的行数
        """
        vector_enabled = self._qdrant_searcher is not None and self._qdrant_searcher.embedding_fn is not None

        chunk_count = 0
        if self._qdrant_indexer is not None:
            try:
                chunk_count = await self._qdrant_indexer.get_chunk_count()
            except Exception as exc:
                logger.warning("memory_status: get_chunk_count failed: %s", exc)

        dirty = self._qdrant_indexer._dirty if self._qdrant_indexer is not None else False

        fts_count = 0
        if self._qdrant_indexer is not None:
            try:
                row = self._qdrant_indexer.fts_db.execute("SELECT COUNT(*) FROM chunks_fts").fetchone()
                fts_count = row[0] if row else 0
            except Exception as exc:
                logger.warning("memory_status: fts_count failed: %s", exc)

        return {
            "chunk_count": chunk_count,
            "vector_enabled": vector_enabled,
            "dirty": dirty,
            "fts_count": fts_count,
        }

    # ── Memory Forget (deletion) ──────────────────────────────────────────

    async def memory_forget_by_query(
        self,
        query: str,
        max_candidates: int = 5,
        min_score: float = 0.5,
        auto_delete_threshold: float = 0.9,
    ) -> str:
        """Search memories by query and delete the best match, or return candidates.

        Inspired by OpenClaw memory_forget:
        - If exactly 1 result with score >= auto_delete_threshold: auto-delete.
        - Otherwise: return candidates for user selection.

        Returns a human-readable status string for the agent to relay.
        """
        if not query:
            return "Error: No query provided for memory_forget."

        if self._qdrant_searcher is None:
            return "Error: No memory search backend available."

        from .qdrant_searcher import SearchResult, create_search_config_from_env

        cfg = create_search_config_from_env()
        cfg.max_results = max_candidates
        cfg.min_score = min_score

        try:
            results: list[SearchResult] = await self._qdrant_searcher.search(
                query=query,
                config=cfg,
            )
        except Exception as exc:
            logger.warning("memory_forget_by_query search failed: %s", exc)
            return f"Error: Memory search failed: {exc}"

        if not results:
            return "No matching memories found for the given query."

        # Auto-delete if exactly 1 high-confidence match
        if len(results) == 1 and results[0].score >= auto_delete_threshold:
            r = results[0]
            if self._qdrant_indexer is not None:
                await self._qdrant_indexer.delete_chunks_by_ids([r.chunk_id])
            snippet_preview = r.snippet[:100].replace("\n", " ")
            return (
                f"Deleted memory (auto, score={r.score:.3f}):\n"
                f"  [{r.path}:{r.start_line}-{r.end_line}] {snippet_preview}"
            )

        # Return candidate list for user selection
        lines: list[str] = [
            f"Found {len(results)} candidate memories. Please confirm which to delete by providing chunk_ids:\n"
        ]
        for i, r in enumerate(results, 1):
            snippet_preview = r.snippet[:120].replace("\n", " ")
            lines.append(
                f"  {i}. chunk_id={r.chunk_id} | [{r.path}:{r.start_line}-{r.end_line}] "
                f"(score={r.score:.3f})\n     {snippet_preview}"
            )
        return "\n".join(lines)

    async def memory_forget_by_file(
        self,
        file_name: str,
    ) -> str:
        """Delete an entire daily memory file and its vector chunks.

        Args:
            file_name: Filename relative to memory/ dir
                       (e.g. "2026-03-15_console_abc_v1.md")
                       or "MEMORY.md" to clear long-term memory content.

        Returns a human-readable status string.
        """
        from .agent_md_manager import AGENT_MD_MANAGER

        if file_name.upper() in ("MEMORY.MD", "MEMORY"):
            # Clear MEMORY.md content instead of deleting the file
            AGENT_MD_MANAGER.write_working_md("MEMORY.md", "")
            # Clean up vector chunks for MEMORY.md
            if self._qdrant_indexer is not None:
                await self._qdrant_indexer.delete_file_chunks("MEMORY.md")
            return "MEMORY.md content cleared (file preserved)."

        try:
            deleted = AGENT_MD_MANAGER.delete_memory_md(file_name)
        except ValueError as exc:
            return f"Error: {exc}"

        if not deleted:
            return f"Memory file not found: {file_name}"

        # Clean up vector chunks for the deleted file
        if self._qdrant_indexer is not None:
            md_name = file_name if file_name.endswith(".md") else f"{file_name}.md"
            rel_path = f"memory/{md_name}"
            await self._qdrant_indexer.delete_file_chunks(rel_path)

        return f"Deleted memory file: {file_name} (and its vector chunks)."

    async def delete_vector_chunks_for_file(self, file_name: str) -> None:
        """Delete vector chunks associated with a memory file.

        This is a public API for the router layer to request vector
        cleanup without touching the file system.  It does NOT delete
        the markdown file itself.

        Args:
            file_name: Filename relative to memory/ dir,
                       e.g. "2026-03-15_console_abc_v1.md".
        """
        if self._qdrant_indexer is None:
            return
        md_name = file_name if file_name.endswith(".md") else f"{file_name}.md"
        rel_path = f"memory/{md_name}"
        await self._qdrant_indexer.delete_file_chunks(rel_path)

    async def memory_forget_by_chunk_ids(
        self,
        chunk_ids: list[str],
    ) -> str:
        """Delete specific vector chunks by their chunk_id.

        Used when the user selects specific candidates from
        memory_forget_by_query results.

        Returns a human-readable status string.
        """
        if not chunk_ids:
            return "Error: No chunk_ids provided."

        if self._qdrant_indexer is None:
            return "Error: No memory indexer available."

        count = await self._qdrant_indexer.delete_chunks_by_ids(chunk_ids)
        if count == 0:
            return "No valid chunk_ids were deleted (invalid format?)."
        return f"Deleted {count} memory chunk(s) successfully."
