"""
记忆存储后端抽象层。

MemoryStore  — 协议接口，定义后端的生命周期与注入契约
QdrantMemoryStore — 基于 Qdrant + FTS 的具体实现，封装降级逻辑

设计目标：
  runner.py 只需持有 MemoryStore，完全不感知 Qdrant / ProactiveEngine 的存在。
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Protocol, runtime_checkable

if TYPE_CHECKING:
    from .memory_manager import MemoryManager

logger = logging.getLogger(__name__)


@runtime_checkable
class MemoryStore(Protocol):
    """记忆存储后端协议。

    实现此协议的类负责：
    1. 生命周期管理（start / stop）
    2. 将自身注入到 MemoryManager（通过 set_qdrant_searcher 等接口）
    """

    async def start(self, memory_manager: MemoryManager) -> None:
        """启动后端，并将检索器注入到 memory_manager。"""
        ...

    def stop(self) -> None:
        """同步关闭后端（释放资源、停止后台线程）。"""
        ...


class QdrantMemoryStore:
    """
    基于 Qdrant + SQLite FTS5 的记忆存储后端。

    封装了：
    - QdrantMemoryIndexer（索引 + 文件监听）
    - QdrantMemorySearcher（检索）
    - ProactiveMemoryEngine（主动触达，可选）
    - FTS-only 降级逻辑

    runner.py 只需调用 start() / stop()，无需感知内部细节。
    """

    def __init__(self, working_dir: str) -> None:
        self.working_dir = working_dir
        self._indexer = None
        self._proactive_engine = None

    async def start(self, memory_manager: MemoryManager) -> None:
        """
        启动记忆后端，失败时自动降级到 FTS-only 模式。
        成功后将检索器注入到 memory_manager。
        """
        from .init_memory_system import init_fts_only_system, init_memory_system

        try:
            indexer, _searcher, proactive_engine = await init_memory_system(
                working_dir=self.working_dir,
                memory_manager=memory_manager,
            )
            self._indexer = indexer
            self._proactive_engine = proactive_engine
            has_vector = indexer.embedding_fn is not None
            logger.info(
                "✓ Memory system ready: mode=%s, collection=%s",
                "vector+FTS" if has_vector else "FTS-only (no embedding)",
                getattr(indexer, "collection_name", "?"),
            )
        except Exception as e:
            logger.warning(
                "✗ Qdrant init failed, falling back to FTS-only: %s",
                e,
            )
            try:
                fts_indexer, _fts_searcher = await init_fts_only_system(
                    working_dir=self.working_dir,
                    memory_manager=memory_manager,
                )
                self._indexer = fts_indexer
                logger.info("✓ Memory system ready: mode=FTS-only (Qdrant unavailable)")
            except Exception as fts_e:
                logger.error(
                    "✗ Memory search unavailable: both Qdrant and FTS init failed: %s",
                    fts_e,
                )

    def stop(self) -> None:
        """关闭 Qdrant 索引器和主动触达引擎。"""
        from .init_memory_system import shutdown_memory_system

        try:
            shutdown_memory_system(self._indexer, self._proactive_engine)
        except Exception as e:
            logger.warning("QdrantMemoryStore stop failed: %s", e)
        finally:
            self._indexer = None
            self._proactive_engine = None
