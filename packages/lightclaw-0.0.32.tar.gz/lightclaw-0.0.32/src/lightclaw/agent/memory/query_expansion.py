"""
多语言关键词提取，用于 FTS-only 搜索模式。
对标 openclaw: src/memory/query-expansion.ts

当没有 embedding provider 时，降级到 FTS 全文检索。
FTS 对精确关键词效果最好，但用户往往使用口语化查询，
本模块从口语化 query 中提取有效关键词以提升 FTS 检索效果。
"""

from __future__ import annotations

import re

# ── 英语停用词（对标 openclaw STOP_WORDS_EN）────────────────────────────────
STOP_WORDS_EN: frozenset[str] = frozenset(
    {
        # 冠词和限定词
        "a",
        "an",
        "the",
        "this",
        "that",
        "these",
        "those",
        # 代词
        "i",
        "me",
        "my",
        "we",
        "our",
        "you",
        "your",
        "he",
        "she",
        "it",
        "they",
        "them",
        # 常见动词
        "is",
        "are",
        "was",
        "were",
        "be",
        "been",
        "being",
        "have",
        "has",
        "had",
        "do",
        "does",
        "did",
        "will",
        "would",
        "could",
        "should",
        "can",
        "may",
        "might",
        # 介词
        "in",
        "on",
        "at",
        "to",
        "for",
        "of",
        "with",
        "by",
        "from",
        "about",
        "into",
        "through",
        "during",
        "before",
        "after",
        "above",
        "below",
        "between",
        "under",
        "over",
        # 连词
        "and",
        "or",
        "but",
        "if",
        "then",
        "because",
        "as",
        "while",
        "when",
        "where",
        "what",
        "which",
        "who",
        "how",
        "why",
        # 模糊时间词
        "yesterday",
        "today",
        "tomorrow",
        "earlier",
        "later",
        "recently",
        "ago",
        "just",
        "now",  # 模糊指代
        "thing",
        "things",
        "stuff",
        "something",
        "anything",
        "everything",
        "nothing",
        # 请求词
        "please",
        "help",
        "find",
        "show",
        "get",
        "tell",
        "give",
    }
)

# ── 西班牙语停用词（对标 openclaw STOP_WORDS_ES）────────────────────────────
STOP_WORDS_ES: frozenset[str] = frozenset(
    {
        "el",
        "la",
        "los",
        "las",
        "un",
        "una",
        "unos",
        "unas",
        "este",
        "esta",
        "ese",
        "esa",
        "yo",
        "me",
        "mi",
        "nosotros",
        "nosotras",
        "tu",
        "tus",
        "usted",
        "ustedes",
        "ellos",
        "ellas",
        "de",
        "del",
        "a",
        "en",
        "con",
        "por",
        "para",
        "sobre",
        "entre",
        "y",
        "o",
        "pero",
        "si",
        "porque",
        "como",
        "es",
        "son",
        "fue",
        "fueron",
        "ser",
        "estar",
        "haber",
        "tener",
        "hacer",
        "ayer",
        "hoy",
        "mañana",
        "antes",
        "despues",
        "después",
        "ahora",
        "recientemente",
        "que",
        "qué",
        "cómo",
        "cuando",
        "cuándo",
        "donde",
        "dónde",
        "porqué",
        "favor",
        "ayuda",
    }
)

# ── 葡萄牙语停用词（对标 openclaw STOP_WORDS_PT）────────────────────────────
STOP_WORDS_PT: frozenset[str] = frozenset(
    {
        "os",
        "as",
        "um",
        "uma",
        "uns",
        "umas",
        "este",
        "esta",
        "esse",
        "essa",
        "eu",
        "me",
        "meu",
        "minha",
        "nos",
        "nós",
        "você",
        "vocês",
        "ele",
        "ela",
        "eles",
        "elas",
        "de",
        "do",
        "da",
        "em",
        "com",
        "por",
        "para",
        "sobre",
        "entre",
        "e",
        "ou",
        "mas",
        "se",
        "porque",
        "como",
        "é",
        "são",
        "foi",
        "foram",
        "ser",
        "estar",
        "ter",
        "fazer",
        "ontem",
        "hoje",
        "amanhã",
        "antes",
        "depois",
        "agora",
        "recentemente",
        "que",
        "quê",
        "quando",
        "onde",
        "porquê",
        "favor",
        "ajuda",
    }
)

# ── 阿拉伯语停用词（对标 openclaw STOP_WORDS_AR）────────────────────────────
STOP_WORDS_AR: frozenset[str] = frozenset(
    {
        "ال",
        "و",
        "أو",
        "لكن",
        "ثم",
        "بل",
        "أنا",
        "نحن",
        "هو",
        "هي",
        "هم",
        "هذا",
        "هذه",
        "ذلك",
        "تلك",
        "هنا",
        "هناك",
        "من",
        "إلى",
        "الى",
        "في",
        "على",
        "عن",
        "مع",
        "بين",
        "ل",
        "ب",
        "ك",
        "كان",
        "كانت",
        "يكون",
        "تكون",
        "صار",
        "أصبح",
        "يمكن",
        "ممكن",
        "بالأمس",
        "امس",
        "اليوم",
        "غدا",
        "الآن",
        "قبل",
        "بعد",
        "مؤخرا",
        "لماذا",
        "كيف",
        "ماذا",
        "متى",
        "أين",
        "هل",
        "من فضلك",
        "فضلا",
        "ساعد",
    }
)

# ── 韩语停用词（对标 openclaw STOP_WORDS_KO）────────────────────────────────
STOP_WORDS_KO: frozenset[str] = frozenset(
    {
        # 助词
        "은",
        "는",
        "이",
        "가",
        "을",
        "를",
        "의",
        "에",
        "에서",
        "로",
        "으로",
        "와",
        "과",
        "도",
        "만",
        "까지",
        "부터",
        "한테",
        "에게",
        "께",
        "처럼",
        "같이",
        "마다",
        "밖에",
        "대로",
        # 代词
        "나",
        "나는",
        "내가",
        "나를",
        "너",
        "우리",
        "저",
        "저희",
        "그",
        "그녀",
        "그들",
        "이것",
        "저것",
        "그것",
        "여기",
        "저기",
        "거기",
        # 常见动词
        "있다",
        "없다",
        "하다",
        "되다",
        "이다",
        "아니다",
        "보다",
        "주다",
        "오다",
        "가다",
        # 依存名词
        "것",
        "거",
        "등",
        "수",
        "때",
        "곳",
        "중",
        "분",
        # 副词
        "잘",
        "더",
        "또",
        "매우",
        "정말",
        "아주",
        "많이",
        "너무",
        "좀",
        # 连词
        "그리고",
        "하지만",
        "그래서",
        "그런데",
        "그러나",
        "또는",
        "그러면",
        # 疑问词
        "왜",
        "어떻게",
        "뭐",
        "언제",
        "어디",
        "누구",
        "무엇",
        "어떤",
        # 模糊时间词
        "어제",
        "오늘",
        "내일",
        "최근",
        "지금",
        "아까",
        "나중",
        "전에",
        # 请求词
        "제발",
        "부탁",
    }
)

# 韩语尾部助词（按长度降序，保证最长匹配优先）
_KO_TRAILING_PARTICLES: list[str] = sorted(
    [
        "에서",
        "으로",
        "에게",
        "한테",
        "처럼",
        "같이",
        "보다",
        "까지",
        "부터",
        "마다",
        "밖에",
        "대로",
        "은",
        "는",
        "이",
        "가",
        "을",
        "를",
        "의",
        "에",
        "로",
        "와",
        "과",
        "도",
        "만",
    ],
    key=len,
    reverse=True,
)

# ── 日语停用词（对标 openclaw STOP_WORDS_JA）────────────────────────────────
STOP_WORDS_JA: frozenset[str] = frozenset(
    {
        "これ",
        "それ",
        "あれ",
        "この",
        "その",
        "あの",
        "ここ",
        "そこ",
        "あそこ",
        "する",
        "した",
        "して",
        "です",
        "ます",
        "いる",
        "ある",
        "なる",
        "できる",
        "の",
        "こと",
        "もの",
        "ため",
        "そして",
        "しかし",
        "また",
        "でも",
        "から",
        "まで",
        "より",
        "だけ",
        "なぜ",
        "どう",
        "何",
        "いつ",
        "どこ",
        "誰",
        "どれ",
        "昨日",
        "今日",
        "明日",
        "最近",
        "今",
        "さっき",
        "前",
        "後",
    }
)

# ── 中文停用词（对标 openclaw STOP_WORDS_ZH）────────────────────────────────
STOP_WORDS_ZH: frozenset[str] = frozenset(
    {
        # 代词
        "我",
        "我们",
        "你",
        "你们",
        "他",
        "她",
        "它",
        "他们",
        "这",
        "那",
        "这个",
        "那个",
        "这些",
        "那些",
        # 助词
        "的",
        "了",
        "着",
        "过",
        "得",
        "地",
        "吗",
        "呢",
        "吧",
        "啊",
        "呀",
        "嘛",
        "啦",
        # 常见动词（模糊）
        "是",
        "有",
        "在",
        "被",
        "把",
        "给",
        "让",
        "用",
        "到",
        "去",
        "来",
        "做",
        "说",
        "看",
        "找",
        "想",
        "要",
        "能",
        "会",
        "可以",
        # 介词和连词
        "和",
        "与",
        "或",
        "但",
        "但是",
        "因为",
        "所以",
        "如果",
        "虽然",
        "而",
        "也",
        "都",
        "就",
        "还",
        "又",
        "再",
        "才",
        "只",
        # 模糊时间词
        "之前",
        "以前",
        "之后",
        "以后",
        "刚才",
        "现在",
        "昨天",
        "今天",
        "明天",
        "最近",
        # 模糊指代
        "东西",
        "事情",
        "事",
        "什么",
        "哪个",
        "哪些",
        "怎么",
        "为什么",
        "多少",
        # 请求词
        "请",
        "帮",
        "帮忙",
        "告诉",
    }
)


def is_stop_word(token: str) -> bool:
    """检查 token 是否为任意语言的停用词。对标 openclaw isQueryStopWordToken。"""
    return (
        token in STOP_WORDS_EN
        or token in STOP_WORDS_ES
        or token in STOP_WORDS_PT
        or token in STOP_WORDS_AR
        or token in STOP_WORDS_ZH
        or token in STOP_WORDS_KO
        or token in STOP_WORDS_JA
    )


def _strip_korean_trailing_particle(token: str) -> str | None:
    """剥离韩语尾部助词，返回词干；无法剥离时返回 None。"""
    for particle in _KO_TRAILING_PARTICLES:
        if len(token) > len(particle) and token.endswith(particle):
            return token[: -len(particle)]
    return None


def _is_useful_korean_stem(stem: str) -> bool:
    """判断韩语词干是否有意义（对标 openclaw isUsefulKoreanStem）。"""
    if re.search(r"[\uac00-\ud7af]", stem):
        return len(stem) >= 2
    return bool(re.match(r"^[a-z0-9_]+$", stem, re.IGNORECASE))


def _is_valid_keyword(token: str) -> bool:
    """判断 token 是否为有效关键词（对标 openclaw isValidKeyword）。"""
    if not token:
        return False
    # 纯英文字母且长度 < 3 → 跳过
    if re.match(r"^[a-zA-Z]+$", token) and len(token) < 3:
        return False
    # 纯数字 → 跳过
    if re.match(r"^\d+$", token):
        return False
    # 全标点 → 跳过（非字母数字/CJK/假名字符）
    if re.match(r"^[^\w\u4e00-\u9fff\uac00-\ud7af\u3040-\u30ff]+$", token):
        return False
    # 单个中文字符 → 跳过（bigram 拆分产生的噪音，FTS5 单字命中意义不大）
    return not re.match(r"^[\u4e00-\u9fff]$", token)


def _tokenize_japanese_segment(segment: str) -> list[str]:
    """处理日文混合脚本 segment（对标 openclaw 日文分词逻辑）。"""
    tokens: list[str] = []
    jp_parts = re.findall(
        r"[a-z0-9_]+|[\u30a0-\u30ff]+|[\u4e00-\u9fff]+|[\u3040-\u309f]{2,}",
        segment,
    )
    for part in jp_parts:
        if re.match(r"^[\u4e00-\u9fff]+$", part):
            tokens.append(part)
            for i in range(len(part) - 1):
                tokens.append(part[i] + part[i + 1])
        else:
            tokens.append(part)
    return tokens


def _tokenize_chinese_segment(segment: str) -> list[str]:
    """处理中文 segment：字符 + bigram（对标 openclaw 中文分词逻辑）。"""
    chars = [c for c in segment if re.match(r"[\u4e00-\u9fff]", c)]
    tokens = list(chars)
    for i in range(len(chars) - 1):
        tokens.append(chars[i] + chars[i + 1])
    return tokens


def _tokenize_korean_segment(segment: str) -> list[str]:
    """处理韩文 segment：助词剥离（对标 openclaw 韩文分词逻辑）。"""
    tokens: list[str] = []
    stem = _strip_korean_trailing_particle(segment)
    stem_is_stop = stem is not None and stem in STOP_WORDS_KO
    if segment not in STOP_WORDS_KO and not stem_is_stop:
        tokens.append(segment)
    if stem and stem not in STOP_WORDS_KO and _is_useful_korean_stem(stem):
        tokens.append(stem)
    return tokens


def _tokenize(text: str) -> list[str]:
    """
    多语言分词器。
    对标 openclaw tokenize（query-expansion.ts）。
    支持：英文 / 中文（字符+bigram）/ 日文（混合脚本）/ 韩文（助词剥离）
    """
    tokens: list[str] = []
    normalized = text.lower().strip()
    segments = [s for s in re.split(r"[\s\.,!?;:\"'()\[\]{}<>/@#$%^&*+=|\\~`]+", normalized) if s]

    for segment in segments:
        if re.search(r"[\u3040-\u30ff]", segment):  # 日文
            tokens.extend(_tokenize_japanese_segment(segment))
        elif re.search(r"[\u4e00-\u9fff]", segment):  # 中文
            tokens.extend(_tokenize_chinese_segment(segment))
        elif re.search(r"[\uac00-\ud7af\u3131-\u3163]", segment):  # 韩文
            tokens.extend(_tokenize_korean_segment(segment))
        else:
            tokens.append(segment)

    return tokens


def extract_keywords(query: str) -> list[str]:
    """
    从口语化 query 中提取有效关键词。
    对标 openclaw extractKeywords。

    示例：
        "之前讨论的那个方案" → ["讨论", "方案"]
        "that thing we discussed about the API" → ["discussed", "api"]
    """
    raw_tokens = _tokenize(query)
    keywords: list[str] = []
    seen: set[str] = set()

    for token in raw_tokens:
        if is_stop_word(token):
            continue
        if not _is_valid_keyword(token):
            continue
        if token in seen:
            continue
        seen.add(token)
        keywords.append(token)

    return keywords


def build_fts_query(raw: str) -> str | None:
    """
    将原始 query 转换为 SQLite FTS5 MATCH 表达式。
    对标 openclaw buildFtsQuery（hybrid.ts）。

    示例：
        'API 设计方案' → '"API" AND "设计方案"'
        '  ' → None（无有效 token）
    """
    tokens = re.findall(r"[\w\u4e00-\u9fff\uac00-\ud7af\u3040-\u30ff]+", raw)
    tokens = [t.strip() for t in tokens if t.strip()]
    if not tokens:
        return None
    quoted = [f'"{t.replace(chr(34), "")}"' for t in tokens]
    return " AND ".join(quoted)


def expand_query_for_fts(query: str) -> str | None:
    """
    将口语化 query 扩展为 FTS5 MATCH 表达式，兼顾精确匹配和关键词匹配。
    对标 openclaw expandQueryForFts（query-expansion.ts）。

    策略：原始 token（AND 连接）OR 提取的关键词（OR 连接）
    这样既保留精确短语的命中，又通过关键词扩展提升口语化查询的召回率。

    示例：
        '之前讨论的那个方案' → '"之前" AND "讨论" AND "的" AND "那个" AND "方案" OR "讨论" OR "方案"'
        'API 设计方案'       → '"API" AND "设计方案" OR "API" OR "设计" OR "方案"'
        '  '                 → None
    """
    original_fts = build_fts_query(query)
    keywords = extract_keywords(query)

    if not original_fts and not keywords:
        return None

    if not keywords:
        return original_fts

    quoted_keywords = [f'"{kw.replace(chr(34), "")}"' for kw in keywords]
    keywords_expr = " OR ".join(quoted_keywords)

    if not original_fts:
        return keywords_expr

    return f"{original_fts} OR {keywords_expr}"
