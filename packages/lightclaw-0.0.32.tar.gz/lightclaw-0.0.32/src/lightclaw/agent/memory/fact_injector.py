"""Retrieve and format structured facts for LLM context injection.

The :class:`FactInjector` is called by the middleware before each LLM
invocation to inject relevant user facts into the context window.  It
maintains a per-turn cache so that facts are fetched only once per
ReAct loop iteration.

Injection format::

    <structured-facts>
    ## Preferences
    - The user prefers dark mode in all IDEs [importance=0.8]
    ## Biographical
    - The user's name is Alex [importance=0.9]
    </structured-facts>
"""

from __future__ import annotations

import logging
from collections.abc import Callable, Coroutine
from typing import Any

from ...constant import FACT_INJECTION_MAX_TOKENS
from .fact_store import FactStore

logger = logging.getLogger(__name__)

# Token estimation: ~4 chars per token for mixed English/Chinese text.
_CHARS_PER_TOKEN = 4

# Categories that are always included regardless of query relevance,
# because they represent core user identity.
_ALWAYS_INCLUDE_CATEGORIES = frozenset({"biographical", "preference", "behavioral"})

# Display order for categories in the injection block.
_CATEGORY_ORDER = [
    "biographical",
    "preference",
    "behavioral",
    "project",
    "technical",
    "general",
]

# Human-readable category headers.
_CATEGORY_HEADERS = {
    "preference": "Preferences",
    "biographical": "Biographical",
    "project": "Project",
    "technical": "Technical",
    "behavioral": "Behavioral",
    "general": "General",
}


class FactInjector:
    """Retrieve relevant facts and format them for LLM context injection.

    The injector uses a two-stage retrieval:
    1. **Always-include**: biographical/preference/behavioral facts (core identity)
    2. **Query-relevant**: semantic search against the latest user message

    Results are merged, deduplicated, and formatted within a token budget.
    """

    def __init__(
        self,
        fact_store: FactStore,
        embedding_fn: Callable[[list[str]], Coroutine[Any, Any, list[list[float]]]] | None = None,
        max_tokens: int | None = None,
    ) -> None:
        """Initialise the injector.

        Args:
            fact_store: The SQLite fact store to read facts from.
            embedding_fn: Optional async embedding function for semantic search.
            max_tokens: Token budget for the injected block.
        """
        self._store = fact_store
        self._embedding_fn = embedding_fn
        self._max_tokens = max_tokens or FACT_INJECTION_MAX_TOKENS

        # Per-turn cache: invalidated when facts are modified.
        self._cached_block: str | None = None
        self._cache_query_hash: int | None = None
        self._cache_modified_ms: int = 0

    def invalidate_cache(self) -> None:
        """Force cache invalidation (called after fact extraction)."""
        self._cached_block = None
        self._cache_query_hash = None

    async def get_relevant_facts_block(
        self,
        last_user_text: str = "",
        extractor_last_modified_ms: int = 0,
    ) -> str:
        """Retrieve and format relevant facts as an XML block.

        Args:
            last_user_text: The latest user message (for relevance ranking).
            extractor_last_modified_ms: Timestamp of last fact modification
                from :class:`FactExtractor`.  Used to invalidate cache.

        Returns:
            A formatted string ready for injection, or empty string if
            no facts are available.
        """
        # Cache check
        query_hash = hash(last_user_text)
        if (
            self._cached_block is not None
            and self._cache_query_hash == query_hash
            and extractor_last_modified_ms <= self._cache_modified_ms
        ):
            return self._cached_block

        try:
            block = await self._build_facts_block(last_user_text)
        except Exception:
            logger.exception("Failed to build facts block")
            block = ""

        # Update cache
        self._cached_block = block
        self._cache_query_hash = query_hash
        self._cache_modified_ms = extractor_last_modified_ms
        return block

    async def _build_facts_block(self, last_user_text: str) -> str:
        """Build the formatted facts block."""
        # Collect all active facts
        all_facts = await self._store.get_all_active_facts()
        if not all_facts:
            return ""

        # Stage 1: always-include core identity facts
        core_facts = [f for f in all_facts if f["category"] in _ALWAYS_INCLUDE_CATEGORIES]
        other_facts = [f for f in all_facts if f["category"] not in _ALWAYS_INCLUDE_CATEGORIES]

        # Stage 2: if we have a user query, rank other facts by relevance
        relevant_others: list[dict[str, Any]] = []
        if last_user_text and other_facts and self._embedding_fn is not None:
            try:
                query_emb = await self._embedding_fn([last_user_text])
                if query_emb and query_emb[0]:
                    scored = await self._store.search_facts_by_embedding(
                        query_embedding=query_emb[0],
                        limit=10,
                        min_score=0.3,
                    )
                    # Filter to only non-core facts
                    core_ids = {f["id"] for f in core_facts}
                    relevant_others = [f for f in scored if f["id"] not in core_ids]
            except Exception:
                logger.debug("Fact relevance ranking failed, including all")

        if not relevant_others:
            # Fallback: include all non-core facts sorted by importance
            relevant_others = sorted(other_facts, key=lambda f: f["importance"], reverse=True)

        # Merge and deduplicate
        seen_ids: set[int] = set()
        merged: list[dict[str, Any]] = []
        for f in core_facts + relevant_others:
            if f["id"] not in seen_ids:
                seen_ids.add(f["id"])
                merged.append(f)

        if not merged:
            return ""

        # Apply token budget
        char_budget = self._max_tokens * _CHARS_PER_TOKEN
        # Reserve chars for XML wrapper and headers
        overhead = 200
        available = char_budget - overhead

        selected: list[dict[str, Any]] = []
        used_chars = 0
        for f in merged:
            line = f"- {f['content']} [importance={f['importance']}]"
            if used_chars + len(line) > available:
                break
            selected.append(f)
            used_chars += len(line) + 1  # +1 for newline

        if not selected:
            return ""

        # Track access
        try:
            await self._store.increment_access([f["id"] for f in selected])
        except Exception:
            logger.debug("Failed to increment access counts")

        # Format by category
        return _format_facts_block(selected)


def _format_facts_block(facts: list[dict[str, Any]]) -> str:
    """Format facts into the injection XML block, grouped by category."""
    by_category: dict[str, list[dict[str, Any]]] = {}
    for f in facts:
        cat = f["category"]
        if cat not in by_category:
            by_category[cat] = []
        by_category[cat].append(f)

    lines = ["<structured-facts>"]

    for cat in _CATEGORY_ORDER:
        if cat not in by_category:
            continue
        header = _CATEGORY_HEADERS.get(cat, cat.capitalize())
        lines.append(f"## {header}")
        for f in by_category[cat]:
            lines.append(f"- {f['content']} [importance={f['importance']}]")
        lines.append("")  # blank line between categories

    lines.append("</structured-facts>")
    return "\n".join(lines)
