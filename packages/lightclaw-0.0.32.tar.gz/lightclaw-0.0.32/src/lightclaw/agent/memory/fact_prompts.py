"""LLM prompts for structured fact extraction and conflict resolution.

Separated from the extraction logic so prompts can be tuned independently.
All prompts are bilingual (English primary, Chinese examples) because the
user base is primarily Chinese-speaking but facts should be stored in a
language-neutral way.
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Fact extraction — run after each conversation turn
# ---------------------------------------------------------------------------

EXTRACTION_SYSTEM_PROMPT = """\
You are a memory extraction assistant. Your job is to extract structured \
facts from a conversation turn between a user and an AI assistant.

Extract ONLY concrete, durable facts — not transient requests or greetings.

Categories:
- preference: User likes, dislikes, habits, style preferences
- biographical: Name, age, location, occupation, relationships, life events
- project: Current projects, goals, deadlines, technical decisions
- technical: Tech stack preferences, coding style, tool preferences
- behavioral: Communication style, working hours, response format preferences
- general: Other noteworthy facts that don't fit above categories

Rules:
1. Extract 0–{max_facts} facts per turn. Return an empty list if nothing \
noteworthy.
2. Each fact must be a single, self-contained sentence.
3. Write facts in third person ("The user prefers…", "The user's name is…").
4. Assign importance 0.0–1.0:
   - 0.8–1.0: Core identity, strong preferences, important relationships
   - 0.5–0.7: Project details, technical choices, habits
   - 0.2–0.4: Transient context, one-time mentions
5. Do NOT extract:
   - Greetings, acknowledgments, or small talk
   - The AI assistant's opinions or suggestions
   - Hypothetical or speculative statements
   - Information that only matters for the current task
6. Prefer the user's own language for proper nouns, but keep the fact \
sentence structure clear and consistent.
"""

EXTRACTION_USER_TEMPLATE = """\
<conversation-turn>
<user>{user_message}</user>
<assistant>{assistant_message}</assistant>
</conversation-turn>

Extract structured facts from this turn. Return a JSON array:
```json
[
  {{"content": "fact text", "category": "category_name", "importance": 0.8}},
  ...
]
```
Return `[]` if no durable facts are present. Return ONLY the JSON array, \
no other text."""

# ---------------------------------------------------------------------------
# Conflict resolution — run for each candidate that has similar existing facts
# ---------------------------------------------------------------------------

CONFLICT_SYSTEM_PROMPT = """\
You are a memory conflict resolver. Given a NEW fact candidate and EXISTING \
similar facts from the user's memory database, decide what action to take.

Actions:
- ADD: The new fact is genuinely new information not covered by any existing \
fact. Store it as a new entry.
- UPDATE: The new fact is an updated version of an existing fact. Specify \
which existing fact to update (by id) and provide the merged/replacement \
content.
- DELETE: The new fact explicitly negates an existing fact without providing \
a replacement (e.g., "The user no longer uses Java" when "The user prefers \
Java" exists). Specify which fact to delete.
- NOOP: The new fact is already captured by an existing fact. No change needed.

Rules:
1. Prefer UPDATE over ADD+DELETE when information evolves naturally \
(e.g., job change, location change, preference shift).
2. For contradictions where the new information replaces the old, use \
UPDATE on the old fact with the new information.
3. Only use DELETE when the new fact explicitly negates something \
without providing a replacement.
4. Use NOOP when the existing fact already fully contains the new information.
5. When updating, write the merged content as a clean, self-contained \
sentence — do not concatenate old and new.
"""

CONFLICT_USER_TEMPLATE = """\
<new-fact>
{candidate_content} (category: {candidate_category}, importance: {candidate_importance})
</new-fact>

<existing-facts>
{existing_facts_xml}
</existing-facts>

Decide the action. Return a single JSON object:
```json
{{"action": "ADD|UPDATE|DELETE|NOOP", "target_fact_id": null, \
"merged_content": "updated text if UPDATE, else null", \
"reason": "brief explanation"}}
```
- For ADD: target_fact_id=null, merged_content=null
- For UPDATE: target_fact_id=<id of fact to update>, merged_content=<new text>
- For DELETE: target_fact_id=<id of fact to delete>, merged_content=null
- For NOOP: target_fact_id=null, merged_content=null

Return ONLY the JSON object, no other text."""


def format_extraction_prompt(
    user_message: str,
    assistant_message: str,
    max_facts: int = 5,
) -> tuple[str, str]:
    """Return (system_prompt, user_prompt) for fact extraction.

    Args:
        user_message: The user's message text.
        assistant_message: The assistant's response text.
        max_facts: Maximum facts to extract per turn.

    Returns:
        A tuple of (system_prompt, user_prompt).
    """
    system = EXTRACTION_SYSTEM_PROMPT.format(max_facts=max_facts)
    user = EXTRACTION_USER_TEMPLATE.format(
        user_message=user_message,
        assistant_message=assistant_message,
    )
    return system, user


def format_conflict_prompt(
    candidate_content: str,
    candidate_category: str,
    candidate_importance: float,
    existing_facts: list[dict],
) -> tuple[str, str]:
    """Return (system_prompt, user_prompt) for conflict resolution.

    Args:
        candidate_content: The new fact candidate text.
        candidate_category: Category of the candidate.
        candidate_importance: Importance score of the candidate.
        existing_facts: List of similar existing facts (dicts with
            ``id``, ``content``, ``category``, ``importance``).

    Returns:
        A tuple of (system_prompt, user_prompt).
    """
    facts_xml_parts = []
    for f in existing_facts:
        facts_xml_parts.append(
            f'<fact id="{f["id"]}" category="{f["category"]}" importance="{f["importance"]}">{f["content"]}</fact>'
        )
    existing_xml = "\n".join(facts_xml_parts) if facts_xml_parts else "<none />"

    user = CONFLICT_USER_TEMPLATE.format(
        candidate_content=candidate_content,
        candidate_category=candidate_category,
        candidate_importance=candidate_importance,
        existing_facts_xml=existing_xml,
    )
    return CONFLICT_SYSTEM_PROMPT, user
