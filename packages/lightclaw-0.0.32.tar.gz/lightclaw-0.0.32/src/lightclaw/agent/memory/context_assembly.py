"""Shared context assembly utilities for all execution paths.

This module provides unified context assembly logic used by both the
AgentScope hook path and the LangGraph middleware path:

- :func:`build_summary_message` — format a compressed-summary with
  version / scope metadata so the LLM can assess its freshness.
- :func:`apply_token_budget` — priority-aware message selection that
  keeps system prompts + recent messages while deprioritising tool
  results and already-compressed entries.
- :func:`estimate_message_tokens` — quick 4-chars-per-token heuristic.
- :func:`get_message_priority` — assign a retention priority to a
  message based on its role and marks.
- :func:`truncate_tool_result` — head+tail truncation for large tool
  outputs.
"""

from __future__ import annotations

import logging
from typing import Any

from ..utils.token_counting import count_str_tokens

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Priority constants (higher → more important to keep)
# ---------------------------------------------------------------------------
PRIORITY_SYSTEM: int = 100
PRIORITY_USER: int = 80
PRIORITY_ASSISTANT: int = 70
PRIORITY_TOOL_RESULT: int = 40
PRIORITY_COMPRESSED: int = 0


# ---------------------------------------------------------------------------
# Summary message builder
# ---------------------------------------------------------------------------


def build_summary_message(
    summary_text: str,
    version: int | None = None,
    messages_compressed: int | None = None,
    compressed_at: str | None = None,
    language: str = "zh",
) -> dict[str, Any]:
    """Build a formatted summary message with structured metadata.

    The returned dict has ``role`` and ``content`` keys and can be passed
    directly to ``Message(**result)`` (internal path) or used to construct
    a ``SystemMessage`` (LangChain path).

    Args:
        summary_text: The compressed summary content.
        version: Summary version number (from ``summaries`` table).
        messages_compressed: How many messages were compressed.
        compressed_at: ISO-8601 timestamp of the compression event.
        language: ``"zh"`` for Chinese instruction, ``"en"`` for English.

    Returns:
        ``{"role": "system", "content": [{"type": "text", "text": ...}]}``
    """
    # Build XML attributes
    attrs: list[str] = []
    if version is not None:
        attrs.append(f'version="{version}"')
    if messages_compressed is not None:
        attrs.append(f'messages_compressed="{messages_compressed}"')
    if compressed_at is not None:
        attrs.append(f'compressed_at="{compressed_at}"')

    attr_str = " " + " ".join(attrs) if attrs else ""

    if language == "zh":
        instruction = "以上是之前对话的摘要，请以此为上下文保持对话的连续性。"
    else:
        instruction = "The above summarizes our previous conversation. Use it as context for continuity."

    text = f"<context-summary{attr_str}>\n{summary_text}\n</context-summary>\n\n{instruction}"

    return {
        "role": "system",
        "content": [{"type": "text", "text": text}],
    }


# ---------------------------------------------------------------------------
# Token estimation
# ---------------------------------------------------------------------------


def estimate_message_tokens(content: Any) -> int:
    """Count tokens in message content using tiktoken.

    Uses tiktoken ``cl100k_base`` when available; otherwise falls back
    to ``len(text) // 4``.  Delegates to the shared
    :func:`~lightclaw.agent.utils.token_counting.count_str_tokens`.
    """
    if isinstance(content, str):
        return count_str_tokens(content)
    if isinstance(content, list):
        total = 0
        for part in content:
            if isinstance(part, str):
                total += count_str_tokens(part)
            elif isinstance(part, dict):
                text = part.get("text") or part.get("output") or ""
                if text:
                    total += count_str_tokens(str(text))
                else:
                    total += count_str_tokens(str(part))
        return total
    return count_str_tokens(str(content))


# ---------------------------------------------------------------------------
# Message priority
# ---------------------------------------------------------------------------


def get_message_priority(
    msg: Any,
    marks: list[str] | None = None,
) -> int:
    """Assign a retention priority to a message.

    Priority order (descending):
        SYSTEM (100) > USER (80) > ASSISTANT (70) > TOOL_RESULT (40)
        > COMPRESSED (0)

    Args:
        msg: Any object with a ``.role`` attribute.
        marks: Mark list from ``LightClawInMemoryMemory.content``.

    Returns:
        An integer priority score.
    """
    marks = marks or []
    role = getattr(msg, "role", "assistant")

    # Marks take precedence.
    if "COMPRESSED" in marks:
        return PRIORITY_COMPRESSED
    if "TOOL_RESULT" in marks:
        return PRIORITY_TOOL_RESULT

    # Infer tool-result from content blocks.
    content = getattr(msg, "content", [])
    if isinstance(content, list):
        for block in content:
            if isinstance(block, dict) and block.get("type") == "tool_result":
                return PRIORITY_TOOL_RESULT

    # Fall back to role.
    if role == "system":
        return PRIORITY_SYSTEM
    if role == "user":
        return PRIORITY_USER
    return PRIORITY_ASSISTANT


# ---------------------------------------------------------------------------
# Priority-aware token budgeting
# ---------------------------------------------------------------------------


def apply_token_budget(
    messages: list[tuple[Any, list[str]]],
    max_tokens: int,
    keep_recent: int = 3,
) -> list[Any]:
    """Select messages that fit within *max_tokens*, priority-first.

    Unlike a naive oldest-first approach this function:

    1. **Always** keeps system-role messages.
    2. **Always** keeps the most recent *keep_recent* non-system messages.
    3. From the remaining candidates, picks messages in priority order
       (higher priority first, then recency) until the budget is full.

    Args:
        messages: ``(message, marks)`` tuples as stored in
                  ``LightClawInMemoryMemory.content``.
        max_tokens: Total token budget for the context window.
        keep_recent: Number of trailing non-system messages to preserve
                     unconditionally.

    Returns:
        A flat list of messages (marks stripped) in their original order.
    """
    if not messages:
        return []

    # ---- split system vs non-system ----
    system_msgs: list[Any] = []
    non_system: list[tuple[Any, list[str]]] = []
    for msg, marks in messages:
        if getattr(msg, "role", "assistant") == "system":
            system_msgs.append(msg)
        else:
            non_system.append((msg, marks))

    system_tokens = sum(estimate_message_tokens(getattr(m, "content", "")) for m in system_msgs)
    remaining_budget = max_tokens - system_tokens
    if remaining_budget <= 0:
        logger.warning("System messages alone exceed token budget")
        return system_msgs

    # All non-system fit as-is?
    if len(non_system) <= keep_recent:
        return system_msgs + [msg for msg, _ in non_system]

    # ---- split: recent (always keep) vs candidates ----
    recent = non_system[-keep_recent:]
    candidates = non_system[:-keep_recent]

    recent_tokens = sum(estimate_message_tokens(getattr(msg, "content", "")) for msg, _ in recent)
    candidate_budget = remaining_budget - recent_tokens
    if candidate_budget <= 0:
        return system_msgs + [msg for msg, _ in recent]

    # ---- score candidates: (priority, index) ----
    scored = [(get_message_priority(msg, marks), idx, msg) for idx, (msg, marks) in enumerate(candidates)]
    # Higher priority first; within the same priority prefer newer (higher idx).
    scored.sort(key=lambda x: (x[0], x[1]), reverse=True)

    kept: list[tuple[int, Any]] = []
    used = 0
    for _priority, idx, msg in scored:
        msg_tokens = estimate_message_tokens(getattr(msg, "content", ""))
        if used + msg_tokens <= candidate_budget:
            kept.append((idx, msg))
            used += msg_tokens

    # Restore original chronological order.
    kept.sort(key=lambda x: x[0])
    kept_msgs = [msg for _, msg in kept]

    logger.debug(
        "Token budget: kept %d/%d candidates (%d tokens), %d recent",
        len(kept_msgs),
        len(candidates),
        used,
        len(recent),
    )

    return system_msgs + kept_msgs + [msg for msg, _ in recent]


# ---------------------------------------------------------------------------
# Tool-result truncation
# ---------------------------------------------------------------------------


def truncate_tool_result(
    content: str,
    max_length: int = 3000,
    keep_head: int = 1500,
    keep_tail: int = 500,
) -> str:
    """Truncate a tool-result string while preserving head and tail.

    Args:
        content: Original tool-result text.
        max_length: Maximum allowed length.
        keep_head: Characters to preserve from the start.
        keep_tail: Characters to preserve from the end.

    Returns:
        The (possibly truncated) content.
    """
    if len(content) <= max_length:
        return content

    omitted = len(content) - keep_head - keep_tail
    return content[:keep_head] + f"\n\n... [{omitted} chars truncated] ...\n\n" + content[-keep_tail:]
