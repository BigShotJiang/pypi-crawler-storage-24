"""
Rule-based importance scoring for memory chunks.

Evaluate how "important" a piece of memory is at index time, producing a
float in [0.0, 1.0].  The score influences search ranking so that core
user preferences always surface above ephemeral, time-bound notes.

Design principles:
  - Rules first, zero LLM calls  (covers ~80% of cases)
  - Deterministic & fast  (< 1 ms per chunk)
  - Graceful defaults  (unknown content -> 0.4, neutral)
"""

from __future__ import annotations

import re

# ── Keyword signal lists ─────────────────────────────────────────────────

# Signals that indicate long-term / identity-level facts.
_HIGH_IMPORTANCE_SIGNALS: tuple[str, ...] = (
    # Chinese
    "偏好",
    "喜欢",
    "不喜欢",
    "讨厌",
    "习惯",
    "擅长",
    "性格",
    "身份",
    "职业",
    "家乡",
    "母语",
    "过敏",
    "禁忌",
    # English
    "preference",
    "favorite",
    "always",
    "never",
    "identity",
    "occupation",
    "allergy",
    "important to me",
)

# Signals that indicate ephemeral / time-bound information.
_LOW_IMPORTANCE_SIGNALS: tuple[str, ...] = (
    # Chinese
    "明天",
    "今天",
    "待办",
    "会议",
    "提醒",
    "临时",
    "一次性",
    # English
    "tomorrow",
    "today",
    "meeting",
    "remind",
    "temporary",
    "one-off",
    "todo",
)

# Path pattern for dated daily summaries: memory/YYYY-MM-DD.md
_DATED_MEMORY_PATH_RE = re.compile(r"(?:^|/)memory/\d{4}-\d{2}-\d{2}\.md$")


# ── Public API ───────────────────────────────────────────────────────────


def evaluate_importance(
    text: str,
    path: str,
    source: str = "memory",
) -> float:
    """Evaluate the importance of a memory chunk using rule-based heuristics.

    Args:
        text:   The chunk text content.
        path:   Relative file path (e.g. ``"MEMORY.md"``, ``"memory/2026-03-17.md"``).
        source: Data source tag (``"memory"`` | ``"sessions"``).

    Returns:
        A float in [0.0, 1.0] where higher means more important.
        - 1.0  core identity / user preferences
        - 0.9  MEMORY.md (curated long-term memory)
        - 0.7  agent-created topic files / high-signal daily content
        - 0.4  neutral / unknown
        - 0.2  ephemeral / time-bound information
    """
    normalized = path.replace("\\", "/").lstrip("./")

    # Rule 1: USER.md = user preferences, highest importance
    if normalized.upper() in ("USER.MD",):
        return 1.0

    # Rule 2: MEMORY.md / memory.md = curated long-term memory
    if normalized in ("MEMORY.md", "memory.md"):
        return 0.9

    # Rule 3: Agent-created topic files in workspace root (e.g. TOOLS.md)
    if "/" not in normalized and normalized.endswith(".md"):
        return 0.7

    # Rule 4: Dated daily summaries — score by content signals
    if _DATED_MEMORY_PATH_RE.search(normalized):
        return _score_by_content_signals(text)

    # Rule 5: Session-derived content
    if source == "sessions":
        return _score_by_content_signals(text)

    # Default: neutral importance
    return 0.4


def _score_by_content_signals(text: str) -> float:
    """Score text content by counting high/low importance keyword signals.

    Returns:
        0.7 if strong long-term signals, 0.2 if strong ephemeral signals,
        0.4 otherwise (neutral).
    """
    if not text:
        return 0.4

    text_lower = text.lower()
    high_hits = sum(1 for signal in _HIGH_IMPORTANCE_SIGNALS if signal in text_lower)
    low_hits = sum(1 for signal in _LOW_IMPORTANCE_SIGNALS if signal in text_lower)

    # Strong long-term signal
    if high_hits >= 2 and high_hits > low_hits:
        return 0.7

    # Mixed signals — lean slightly toward important
    if high_hits >= 1 and low_hits == 0:
        return 0.6

    # Strong ephemeral signal
    if low_hits >= 2 and low_hits > high_hits:
        return 0.2

    # Slight ephemeral signal
    if low_hits >= 1 and high_hits == 0:
        return 0.3

    return 0.4
