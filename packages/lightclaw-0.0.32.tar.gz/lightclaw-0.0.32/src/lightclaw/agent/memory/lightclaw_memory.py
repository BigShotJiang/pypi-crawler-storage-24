"""Custom in-memory storage independent from AgentScope memory types."""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

from ...app.schemas.message_types import Message
from .marks import MemoryMark

if TYPE_CHECKING:
    from .message_store import SqliteMessageStore

logger = logging.getLogger(__name__)


class LightClawInMemoryMemory:
    """Simple in-memory message store with optional SQLite persistence.

    Messages are always kept in memory for hot access. When a
    :class:`SqliteMessageStore` is attached (via :meth:`init_persistence`),
    writes are transparently mirrored to the database for durability.

    On startup, call :meth:`load_from_persistence` to restore messages
    and the compressed summary from the database.
    """

    def __init__(self) -> None:
        self.content: list[tuple[Any, list[str]]] = []
        self._compressed_summary = ""
        self._summary_version: int | None = None
        self._summary_message_count: int | None = None
        self._summary_timestamp: str | None = None
        self._store: SqliteMessageStore | None = None

    async def init_persistence(
        self,
        db_dir: str | Path,
    ) -> None:
        """Attach a SQLite persistence store to this memory.

        Args:
            db_dir: Directory where ``messages.db`` will be stored.
                    Typically ``{WORKING_DIR}/memory``.
        """
        # Import here to avoid circular dependency.
        from .message_store import SqliteMessageStore

        if self._store is not None:
            logger.warning("Persistence already initialized; skipping")
            return

        self._store = SqliteMessageStore(db_dir)
        await self._store.start()
        logger.info("Memory persistence initialized at %s", db_dir)

    async def load_from_persistence(self) -> None:
        """Restore all messages and summary from the database.

        Call this during agent startup to recover from previous sessions.
        """
        if self._store is None:
            logger.debug("No persistence store; skipping load")
            return

        # Load all messages from database.
        msg_rows = await self._store.get_all_messages()
        self.content = []
        for row in msg_rows:
            msg = self._dict_to_message(row)
            marks = row.get("marks", [])
            self.content.append((msg, marks))

        # Load compressed summary and metadata.
        self._compressed_summary = await self._store.load_summary()
        if self._compressed_summary:
            _, version = await self._store.get_latest_summary()
            if version is not None:
                self._summary_version = version
                # Retrieve message count from the latest summary history.
                history = await self._store.get_summary_history(limit=1)
                if history:
                    self._summary_message_count = history[0].get(
                        "messages_count",
                    )
        logger.info(
            "Loaded %d messages and summary (v%s) from persistence",
            len(msg_rows),
            self._summary_version,
        )

    async def add(self, msg: Any, mark: str | None = None) -> None:
        marks = [mark] if mark else []
        self.content.append((msg, marks))

        # Persist to store if attached.
        if self._store is not None:
            msg_id = getattr(msg, "id", None)
            if msg_id is None:
                logger.warning("Message has no id; not persisting")
                return
            role = getattr(msg, "role", "assistant")
            content = getattr(msg, "content", "")
            metadata = getattr(msg, "metadata", None)
            await self._store.add_message(
                msg_id=msg_id,
                role=role,
                content=content,
                metadata=metadata,
                marks=marks,
            )

    async def add_batch(self, messages: list[Any]) -> None:
        for msg in messages:
            await self.add(msg)

    async def get_memory(
        self,
        mark: str | None = None,
        exclude_mark: str | None = MemoryMark.COMPRESSED.value,
        prepend_summary: bool = True,
        max_tokens: int | None = None,
        language: str = "zh",
        **_kwargs,
    ) -> list[Any]:
        """Get messages filtered by marks, with optional token budgeting.

        Args:
            mark: Only include messages that have this mark.
            exclude_mark: Exclude messages that have this mark.
            prepend_summary: Prepend the compressed summary as a system
                             message (with version metadata).
            max_tokens: When set, apply priority-aware token budgeting.
            language: Language for the summary instruction text.
        """
        from .context_assembly import apply_token_budget, build_summary_message

        filtered = [
            (msg, marks)
            for msg, marks in self.content
            if (mark is None or mark in marks) and (exclude_mark is None or exclude_mark not in marks)
        ]

        # Apply priority-aware token budgeting when requested.
        if max_tokens is not None:
            messages = apply_token_budget(
                filtered,
                max_tokens,
                keep_recent=3,
            )
        else:
            messages = [msg for msg, _ in filtered]

        if prepend_summary and self._compressed_summary:
            summary_dict = build_summary_message(
                summary_text=self._compressed_summary,
                version=self._summary_version,
                messages_compressed=self._summary_message_count,
                compressed_at=self._summary_timestamp,
                language=language,
            )
            summary_msg = Message(**summary_dict)
            return [summary_msg, *messages]
        return messages

    async def update_messages_mark(
        self,
        new_mark: str,
        msg_ids: list[str],
    ) -> int:
        """Add a mark to messages identified by ``msg_ids``."""
        updated = 0
        target_ids = set(msg_ids)
        for msg, marks in self.content:
            msg_id = getattr(msg, "id", None)
            if msg_id in target_ids and new_mark not in marks:
                marks.append(new_mark)
                updated += 1

        # Persist mark updates to store if attached.
        if self._store is not None and updated > 0:
            await self._store.update_marks(msg_ids, new_mark)

        return updated

    async def update_compressed_summary(
        self,
        summary: str,
        message_ids: list[str] | None = None,
        trigger_source: str = "hook",
        tokens_before: int | None = None,
    ) -> None:
        """Update the compressed summary with optional versioning.

        Args:
            summary: The new summary text.
            message_ids: When provided, creates a versioned summary
                         linked to these message IDs for traceability.
            trigger_source: ``'hook'`` or ``'middleware'`` (audit trail).
            tokens_before: Token count before compaction (audit).
        """
        self._compressed_summary = summary or ""

        # Update metadata.
        if message_ids:
            self._summary_message_count = len(message_ids)
        self._summary_timestamp = datetime.now(UTC).isoformat(timespec="seconds")

        # Persist summary to store if attached.
        if self._store is not None:
            await self._store.save_summary(
                summary=self._compressed_summary,
                message_ids=message_ids,
                trigger_source=trigger_source,
                tokens_before=tokens_before,
            )
            # Refresh version from the database.
            _, version = await self._store.get_latest_summary()
            if version is not None:
                self._summary_version = version

    def get_compressed_summary(self) -> str:
        return self._compressed_summary

    def state_dict(self) -> dict[str, Any]:
        serialized = []
        for msg, marks in self.content:
            if hasattr(msg, "model_dump"):
                msg_data = msg.model_dump()
            elif hasattr(msg, "dict"):
                msg_data = msg.dict()
            elif isinstance(msg, dict):
                msg_data = msg
            else:
                msg_data = {
                    "role": getattr(msg, "role", "assistant"),
                    "content": getattr(msg, "content", ""),
                }
            serialized.append([msg_data, list(marks)])

        return {
            "content": serialized,
            "_compressed_summary": self._compressed_summary,
        }

    def load_state_dict(self, state_dict: dict[str, Any], strict: bool = True) -> None:
        """Load state data with backward compatibility."""
        if strict and "content" not in state_dict:
            raise KeyError("Missing 'content' key in memory state_dict.")

        loaded: list[tuple[Any, list[str]]] = []
        for item in state_dict.get("content", []):
            msg_dict: dict[str, Any] | None = None
            marks: list[str] = []

            if isinstance(item, tuple | list) and len(item) == 2:
                maybe_msg, maybe_marks = item
                if isinstance(maybe_msg, dict):
                    msg_dict = maybe_msg
                if isinstance(maybe_marks, list):
                    marks = [str(mark) for mark in maybe_marks]
            elif isinstance(item, dict):
                msg_dict = item

            if msg_dict is None:
                continue

            loaded.append((self._dict_to_message(msg_dict), marks))

        self.content = loaded
        self._compressed_summary = state_dict.get("_compressed_summary", "")

    def _dict_to_message(self, msg_dict: dict[str, Any]) -> Message:
        role = msg_dict.get("role", "assistant")
        content = msg_dict.get("content", "")

        if isinstance(content, str):
            content_blocks: list[dict[str, Any]] = [
                {"type": "text", "text": content},
            ]
        elif isinstance(content, list):
            content_blocks = [
                block if isinstance(block, dict) else {"type": "text", "text": str(block)} for block in content
            ]
        else:
            content_blocks = [{"type": "text", "text": str(content)}]

        return Message(
            role=role,
            content=content_blocks,
            id=str(msg_dict.get("id") or Message().id),
            metadata=msg_dict.get("metadata"),
        )

    async def get_summary_history(self, limit: int = 10) -> list[dict]:
        """Return recent summary version history for debugging."""
        if self._store is None:
            return []
        return await self._store.get_summary_history(limit=limit)

    async def get_summary_for_message(self, message_id: str) -> int | None:
        """Return the summary ID that compressed a given message."""
        if self._store is None:
            return None
        return await self._store.get_summary_for_message(message_id)

    async def close_persistence(self) -> None:
        """Close the persistence store if attached."""
        if self._store is not None:
            await self._store.close()
            self._store = None
