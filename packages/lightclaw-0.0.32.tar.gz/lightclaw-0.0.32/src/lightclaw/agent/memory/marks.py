"""Memory mark constants for memory compaction state."""

from __future__ import annotations

from enum import StrEnum


class MemoryMark(StrEnum):
    """Marks used to annotate memory items."""

    COMPRESSED = "COMPRESSED"
    TOOL_RESULT = "TOOL_RESULT"
