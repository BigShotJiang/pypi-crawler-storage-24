from __future__ import annotations

import logging
import os

import click

from ..config.utils import read_last_api, write_last_api
from ..constant import LOG_LEVEL_ENV


@click.command("run")
@click.option(
    "--host",
    default="127.0.0.1",
    show_default=True,
    help="Bind host",
)
@click.option(
    "--port",
    default=8088,
    type=int,
    show_default=True,
    help="Bind port",
)
@click.option("--reload", is_flag=True, help="Enable auto-reload (dev only)")
@click.option(
    "--from-configfile",
    is_flag=True,
    help="Read host and port from lightclaw.json instead of using defaults.",
)
@click.option(
    "--workers",
    default=1,
    type=int,
    show_default=True,
    help="Worker processes",
)
@click.option(
    "--log-level",
    default="info",
    type=click.Choice(
        ["critical", "error", "warning", "info", "debug", "trace"],
        case_sensitive=False,
    ),
    show_default=True,
    help="Log level",
)
@click.option(
    "--hide-access-paths",
    multiple=True,
    default=("/dashboard/messages",),
    show_default=True,
    help="Path substrings to hide from uvicorn access log (repeatable).",
)
def app_cmd(
    host: str,
    port: int,
    reload: bool,
    from_configfile: bool,
    workers: int,
    log_level: str,
    hide_access_paths: tuple[str, ...],
) -> None:
    """Run LightClaw FastAPI app."""
    import uvicorn

    from ..utils.logging import SuppressPathAccessLogFilter, setup_logger

    if from_configfile:
        saved = read_last_api()
        if saved:
            host, port = saved

    write_last_api(host, port)
    os.environ[LOG_LEVEL_ENV] = log_level
    setup_logger(log_level)
    if log_level in ("debug", "trace"):
        from .main import log_init_timings

        log_init_timings()

    paths = [p for p in hide_access_paths if p]
    if paths:
        logging.getLogger("uvicorn.access").addFilter(
            SuppressPathAccessLogFilter(paths),
        )

    uvicorn.run(
        "lightclaw.app._app:app",
        host=host,
        port=port,
        reload=reload,
        workers=workers,
        log_level=log_level,
    )
