"""lightclaw init — non-interactive setup with sensible defaults."""

from __future__ import annotations

from pathlib import Path

import click

from ..config import get_config_path, get_heartbeat_query_path, load_config, save_config
from ..config.config import Config, HeartbeatConfig
from ..constant import HEARTBEAT_DEFAULT_EVERY
from ..providers import load_providers_json
from .embedding_cmd import configure_embedding_interactive
from .providers_cmd import configure_providers_interactive

_HEARTBEAT_MDS = {
    "zh": """\
# Heartbeat checklist
- 扫描收件箱紧急邮件
- 查看未来 2h 的日历
- 检查待办是否卡住
- 若安静超过 8h，轻量 check-in
""",
    "en": """\
# Heartbeat checklist
- Scan inbox for urgent email
- Check calendar for next 2h
- Check tasks for blockers
- Light check-in if quiet for 8h
""",
}


@click.command("init")
@click.option("--force", is_flag=True, help="Overwrite existing lightclaw.json and HEARTBEAT.md.")
@click.option(
    "--reset-password",
    is_flag=True,
    help='Reset login password to default ("lightclaw").',
)
def init_cmd(force: bool, reset_password: bool) -> None:
    """Initialize LightClaw with default configuration (non-interactive).

    \b
    Examples:
      lightclaw init                  # first-time setup
      lightclaw init --force          # reset existing config to defaults
      lightclaw init --reset-password # reset login password
    """
    config_path = get_config_path()
    heartbeat_path = get_heartbeat_query_path()
    working_dir = config_path.parent

    click.echo(f"Working dir: {working_dir}")
    working_dir.mkdir(parents=True, exist_ok=True)

    if reset_password:
        from ..app.core.auth import AUTH_FILE, _hash_password, _read_auth, _write_auth

        if not AUTH_FILE.is_file():
            click.echo("No auth.json found, nothing to reset.")
            return

        auth = _read_auth()

        new_pw = click.prompt("New password (min 4 chars)", hide_input=True)
        if len(new_pw) < 4:
            click.echo("✗ Password must be at least 4 characters.")
            return
        confirm_pw = click.prompt("Confirm new password", hide_input=True)
        if new_pw != confirm_pw:
            click.echo("✗ Passwords do not match.")
            return

        auth.password_hash = _hash_password(new_pw)
        auth.jwt_secret = __import__("secrets").token_hex(32)
        auth.setup_done = True
        _write_auth(auth)
        click.echo("✓ Password changed. Old tokens invalidated.")
        return

    if not config_path.is_file() or force:
        cfg = load_config(config_path) if config_path.is_file() else Config()
        cfg.agents.defaults.heartbeat = HeartbeatConfig(
            every=HEARTBEAT_DEFAULT_EVERY,
            target="main",
            active_hours=None,
        )
        cfg.show_tool_details = True
        save_config(cfg, config_path)
        click.echo(f"\n✓ Config saved to {config_path}")
    else:
        click.echo("Config already exists, skipping.")

    # Initialize .env file from .env.example template
    _initialize_env_file(working_dir, force)

    data = load_providers_json()
    llm_pid, llm_model = data.parse_active_llm()
    if llm_pid and llm_model:
        click.echo(f"\n✓ LLM: {llm_pid} / {llm_model}")
    else:
        click.echo("\n=== LLM Provider (required) ===")
        configure_providers_interactive(use_defaults=True)

    from ..agent.skills_manager import sync_skills_to_working_dir

    click.echo("\nEnabling all skills...")
    synced, skipped = sync_skills_to_working_dir(skill_names=None, force=False)
    click.echo(f"✓ Skills: {synced} enabled, {skipped} skipped (already present)")

    from ..agent.utils import copy_prompts

    cfg = load_config(config_path) if config_path.is_file() else Config()
    lang = cfg.agents.language
    click.echo(f"\nChecking MD files [{lang}]...")
    copied = copy_prompts(lang, skip_existing=True)
    if copied:
        cfg.agents.installed_prompts_language = lang
        save_config(cfg, config_path)
        click.echo(f"✓ Copied: {', '.join(copied)}")
    else:
        click.echo("✓ MD files already present.")

    if not heartbeat_path.is_file() or force:
        heartbeat_path.write_text(_HEARTBEAT_MDS[lang].strip(), encoding="utf-8")
        click.echo(f"✓ HEARTBEAT.md saved to {heartbeat_path}")
    else:
        click.echo("✓ HEARTBEAT.md already present.")

    # === NEW: Embedding Configuration (optional) ===
    cfg = load_config(config_path) if config_path.is_file() else Config()
    embedding = cfg.embedding
    if embedding.provider == "none":
        click.echo("\n=== Embedding Configuration (optional) ===")
        if click.confirm("Configure vector search for memory?", default=False):
            click.echo("Embedding enables semantic search in memory.")
            try:
                configure_embedding_interactive(use_defaults=True)
            except Exception as exc:
                click.echo(click.style(f"Warning: Embedding setup skipped ({exc})", fg="yellow"))
        else:
            click.echo("✓ Embedding disabled. Memory will use keyword-only search.")
    else:
        click.echo(f"\n✓ Embedding: {embedding.provider}")

    click.echo("\n✓ Done! LightClaw is ready.")
    click.echo("\nNext steps:")
    click.echo("  lightclaw run    # start in the foreground (development)")
    click.echo("  lightclaw start  # register and start as a background service")


def _initialize_env_file(working_dir: Path, force: bool) -> None:
    """Initialize .env file from the bundled .env.example template.

    Reads .env.example from the installed package data and writes it
    to working_dir/.env so the user has a complete, commented template
    ready to fill in.  Skips the write if .env already exists and
    force is False.
    """
    import importlib.resources

    from ..envs import get_env_file_path

    env_file = get_env_file_path()

    if env_file.is_file() and not force:
        click.echo("✓ .env file already exists.")
        return

    # Read the bundled .env.example from the installed package
    try:
        package_ref = importlib.resources.files("lightclaw")
        example_content = (package_ref / ".env.example").read_text(encoding="utf-8")
    except (FileNotFoundError, TypeError):
        # Fall back to default template if package data is unavailable
        from ..envs import ensure_env_file

        ensure_env_file(env_file)
        click.echo(f"✓ .env file initialized with defaults at {env_file}")
        return

    env_file.parent.mkdir(parents=True, exist_ok=True)
    env_file.write_text(example_content, encoding="utf-8")
    click.echo(f"✓ .env file created from template at {env_file}")
