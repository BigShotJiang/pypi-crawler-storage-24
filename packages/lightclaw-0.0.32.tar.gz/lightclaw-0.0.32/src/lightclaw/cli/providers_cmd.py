"""CLI commands for managing LLM providers."""

from __future__ import annotations

import click

from ..providers import (
    PROVIDERS,
    ModelInfo,
    add_model,
    create_custom_provider,
    delete_custom_provider,
    is_builtin,
    list_providers,
    load_providers_json,
    mask_api_key,
    refresh_provider_models,
    remove_model,
    set_active_llm,
    update_provider_settings,
)
from .utils import prompt_choice


def _select_provider_interactive(
    prompt_text: str = "Select provider:",
    *,
    default_pid: str = "",
) -> str:
    """Prompt user to pick a provider. Returns provider_id."""
    data = refresh_provider_models()
    all_providers = list_providers()

    labels: list[str] = []
    ids: list[str] = []
    for d in all_providers:
        mark = "✓" if data.is_configured(d) else "✗"
        labels.append(f"{d.name} ({d.id}) [{mark}]")
        ids.append(d.id)

    default_label: str | None = None
    if default_pid in ids:
        default_label = labels[ids.index(default_pid)]

    chosen_label = prompt_choice(
        prompt_text,
        options=labels,
        default=default_label,
    )
    return ids[labels.index(chosen_label)]


def configure_provider_api_key_interactive(
    provider_id: str | None = None,
) -> str:
    """Interactively configure a provider's API key. Returns provider_id."""
    data = refresh_provider_models()

    if provider_id is None:
        provider_id = _select_provider_interactive(
            "Select provider to configure API key:",
        )

    defn = PROVIDERS[provider_id]

    # Ollama provider is local-like (no API key needed)
    if provider_id == "ollama":
        # Ensure an entry exists in providers config so is_configured() returns True.
        update_provider_settings(provider_id)
        click.echo(f"✓ {defn.name} — local provider (no API key needed)")
        return provider_id

    current_base, current_key = data.get_credentials(provider_id)

    base_url: str | None = None
    if defn.is_custom:
        base_url = click.prompt(
            "Base URL (OpenAI-compatible endpoint)",
            default=current_base or "",
            show_default=bool(current_base),
        ).strip()
        if not base_url:
            click.echo(click.style("Error: base_url is required.", fg="red"))
            raise SystemExit(1)

    hint = f"prefix: {defn.api_key_prefix}" if defn.api_key_prefix else "optional"
    api_key = click.prompt(
        f"API key ({hint})",
        default=current_key or "",
        hide_input=True,
        show_default=False,
        prompt_suffix=f" [{'set' if current_key else 'not set'}]: ",
    )

    update_provider_settings(
        provider_id,
        api_key=api_key if api_key else None,
        base_url=base_url,
    )

    click.echo(
        f"✓ {defn.name} — API Key: {mask_api_key(api_key) or '(not set)'}"
        + (f", Base URL: {base_url}" if base_url else ""),
    )
    return provider_id


def _add_models_interactive(provider_id: str) -> None:
    """Interactively add models to a provider after configuration."""
    defn = PROVIDERS[provider_id]
    data = refresh_provider_models()

    # Ollama models cannot be added manually - they come from Ollama daemon
    if provider_id == "ollama":
        return

    settings = data.providers.get(provider_id)
    extra = list(settings.extra_models) if settings and not defn.is_custom else []
    all_models = list(defn.models) + extra

    if all_models:
        click.echo(f"\nCurrent models for {defn.name}:")
        for m in all_models:
            click.echo(f"  - {m.name} ({m.id})")
    else:
        click.echo(f"\nNo models configured for {defn.name}.")

    # Default to yes if there are no models at all
    while click.confirm("Add a model?", default=not all_models):
        model_id = click.prompt("Model identifier").strip()
        if not model_id:
            click.echo(click.style("Error: model id is required.", fg="red"))
            continue
        model_name = click.prompt(
            "Model display name",
            default=model_id,
        ).strip()
        try:
            add_model(provider_id, ModelInfo(id=model_id, name=model_name))
            click.echo(f"✓ Model '{model_name}' ({model_id}) added.")
            all_models.append(ModelInfo(id=model_id, name=model_name))
        except ValueError as exc:
            click.echo(click.style(f"Error: {exc}", fg="red"))


def _pick_model_from_list(
    models: list,
    prompt_text: str,
    current_model: str = "",
) -> str:
    labels = [m.name for m in models]
    ids = [m.id for m in models]

    default_label: str | None = None
    if current_model in ids:
        default_label = labels[ids.index(current_model)]

    chosen = prompt_choice(prompt_text, options=labels, default=default_label)
    return ids[labels.index(chosen)]


def _pick_model_free_text(prompt_text: str, current_model: str = "") -> str:
    model = click.prompt(prompt_text, default=current_model or "").strip()
    if not model:
        click.echo(click.style("Error: model name is required.", fg="red"))
        raise SystemExit(1)
    return model


def _filter_eligible(data, all_providers):
    return [d for d in all_providers if data.is_configured(d)]


def _select_llm_model(defn, pid, cur_pid, cur_model, data, *, use_defaults):
    """Pick a model for the given provider. Returns model id."""
    cur = cur_model if cur_pid == pid else ""

    settings = data.providers.get(pid)
    extra = list(settings.extra_models) if settings and not defn.is_custom else []
    all_models = list(defn.models) + extra

    if use_defaults:
        return cur or (all_models[0].id if all_models else "")

    if all_models:
        return _pick_model_from_list(
            all_models,
            "Select LLM model:",
            current_model=cur,
        )
    return _pick_model_free_text(
        "LLM model name (required):",
        current_model=cur,
    )


def configure_llm_slot_interactive(*, use_defaults: bool = False) -> None:
    """Interactively configure the active LLM model slot."""
    data = refresh_provider_models()
    all_providers = list_providers()
    cur_pid, cur_model = data.parse_active_llm()

    eligible = _filter_eligible(data, all_providers)

    if not eligible:
        if use_defaults:
            click.echo(
                "No LLM provider configured. Run 'lightclaw models config' to configure later.",
            )
            return
        click.echo(
            click.style(
                "No providers are configured yet. Let's configure one now.",
                fg="yellow",
            ),
        )
        pid = configure_provider_api_key_interactive()
        _add_models_interactive(pid)
        data = load_providers_json()
        cur_pid, cur_model = data.parse_active_llm()
        eligible = _filter_eligible(data, all_providers)
        if not eligible:
            click.echo(
                click.style("Error: provider configuration failed.", fg="red"),
            )
            raise SystemExit(1)

    ids = [d.id for d in eligible]
    if use_defaults:
        pid = cur_pid if cur_pid in ids else ids[0]
    else:
        labels = [f"{d.name} ({d.id})" for d in eligible]
        default_label = labels[ids.index(cur_pid)] if cur_pid in ids else None
        chosen_label = prompt_choice(
            "Select provider for LLM:",
            options=labels,
            default=default_label,
        )
        pid = ids[labels.index(chosen_label)]

    defn = PROVIDERS[pid]
    model = _select_llm_model(
        defn,
        pid,
        cur_pid,
        cur_model,
        data,
        use_defaults=use_defaults,
    )
    if not model and use_defaults:
        click.echo(
            f"No default model for {defn.name}. Run 'lightclaw models config' to set one.",
        )
        return
    set_active_llm(pid, model)
    click.echo(f"✓ LLM: {defn.name} / {model}")


def configure_providers_interactive(*, use_defaults: bool = False) -> None:
    """Full interactive setup: configure provider → add models →
    activate LLM."""
    if use_defaults:
        configure_llm_slot_interactive(use_defaults=True)
        return

    click.echo("\n--- Provider Configuration ---")
    while True:
        pid = configure_provider_api_key_interactive()

        # For Ollama, skip to model activation directly
        defn = PROVIDERS[pid]
        if pid == "ollama":
            click.echo(f"\n--- Activate {defn.name} Model ---")
            configure_llm_slot_interactive()
            return

        _add_models_interactive(pid)
        if not click.confirm("Configure another provider?", default=False):
            break

    click.echo("\n--- Activate LLM Model ---")
    configure_llm_slot_interactive()


@click.group("models")
def models_group() -> None:
    """Manage LLM models and provider configuration."""


@models_group.command("list")
def list_cmd() -> None:
    """Show all providers and their current configuration."""
    data = refresh_provider_models()

    click.echo("\n=== Providers ===")
    for defn in list_providers():
        cur_url, cur_key = data.get_credentials(defn.id)
        settings = data.providers.get(defn.id)

        tag = " [custom]" if defn.is_custom else ""
        click.echo(f"\n{'─' * 44}")
        click.echo(f"  {defn.name} ({defn.id}){tag}")
        click.echo(f"{'─' * 44}")

        if defn.is_custom:
            click.echo(f"  {'base_url':16s}: {cur_url or '(not set)'}")
        click.echo(
            f"  {'api_key':16s}: {mask_api_key(cur_key) or '(not set)'}",
        )
        if defn.api_key_prefix:
            click.echo(
                f"  {'api_key_prefix':16s}: {defn.api_key_prefix}",
            )

        extra = list(settings.extra_models) if settings and not defn.is_custom else []
        all_models = list(defn.models) + extra
        if all_models:
            click.echo(f"  {'models':16s}:")
            for m in all_models:
                label = " [user-added]" if m in extra else ""
                click.echo(f"    - {m.name} ({m.id}){label}")

    click.echo(f"\n{'═' * 44}")
    click.echo("  Active Model Slot")
    click.echo(f"{'═' * 44}")

    llm_pid, llm_model = data.parse_active_llm()
    if llm_pid and llm_model:
        click.echo(f"  {'LLM':16s}: {llm_pid} / {llm_model}")
    else:
        click.echo(f"  {'LLM':16s}: (not configured)")
    click.echo()


@models_group.command("config")
def config_cmd() -> None:
    """Interactively configure providers and active models."""
    configure_providers_interactive()


@models_group.command("config-key")
@click.argument("provider_id", required=False, default=None)
def config_key_cmd(provider_id: str | None) -> None:
    """Configure a provider's API key."""
    if provider_id is not None and provider_id not in PROVIDERS:
        click.echo(click.style(f"Unknown provider: {provider_id}", fg="red"))
        raise SystemExit(1)
    configure_provider_api_key_interactive(provider_id)


@models_group.command("set-llm")
def set_llm_cmd() -> None:
    """Interactively set the active LLM model."""
    configure_llm_slot_interactive()


@models_group.command("add-provider")
@click.argument("provider_id")
@click.option("--name", "-n", required=True, help="Human-readable name")
@click.option("--base-url", "-u", default="", help="Default API base URL")
@click.option("--api-key-prefix", default="", help="Expected API key prefix")
def add_provider_cmd(
    provider_id: str,
    name: str,
    base_url: str,
    api_key_prefix: str,
) -> None:
    """Add a new custom provider."""
    try:
        create_custom_provider(
            provider_id,
            name,
            default_base_url=base_url,
            api_key_prefix=api_key_prefix,
        )
    except ValueError as exc:
        click.echo(click.style(f"Error: {exc}", fg="red"))
        raise SystemExit(1) from exc
    click.echo(f"✓ Custom provider '{name}' ({provider_id}) created.")
    if base_url:
        click.echo(f"  base_url: {base_url}")
    click.echo(
        "  Run 'lightclaw models add-model' to add models, then 'lightclaw models config-key' to set the API key.",
    )


@models_group.command("remove-provider")
@click.argument("provider_id")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
def remove_provider_cmd(provider_id: str, yes: bool) -> None:
    """Remove a custom provider."""
    if is_builtin(provider_id):
        click.echo(
            click.style(
                f"Error: '{provider_id}' is a built-in provider and cannot be removed.",
                fg="red",
            ),
        )
        raise SystemExit(1)
    if not yes and not click.confirm(
        f"Delete custom provider '{provider_id}' and all its models?",
    ):
        return
    try:
        delete_custom_provider(provider_id)
    except ValueError as exc:
        click.echo(click.style(f"Error: {exc}", fg="red"))
        raise SystemExit(1) from exc
    click.echo(f"✓ Custom provider '{provider_id}' deleted.")


@models_group.command("add-model")
@click.argument("provider_id")
@click.option("--model-id", "-m", required=True, help="Model identifier")
@click.option("--model-name", "-n", required=True, help="Model display name")
def add_model_cmd(provider_id: str, model_id: str, model_name: str) -> None:
    """Add a model to any provider (built-in or custom)."""
    # Prevent manual model addition for Ollama
    if provider_id == "ollama":
        click.echo(
            click.style(
                "Error: Ollama models cannot be added manually. Use 'ollama pull <model>' to download models.",
                fg="red",
            ),
        )
        raise SystemExit(1)

    try:
        add_model(provider_id, ModelInfo(id=model_id, name=model_name))
    except ValueError as exc:
        click.echo(click.style(f"Error: {exc}", fg="red"))
        raise SystemExit(1) from exc
    click.echo(
        f"✓ Model '{model_name}' ({model_id}) added to '{provider_id}'.",
    )


@models_group.command("remove-model")
@click.argument("provider_id")
@click.option("--model-id", "-m", required=True, help="Model identifier")
def remove_model_cmd(provider_id: str, model_id: str) -> None:
    """Remove a user-added model from any provider."""
    # Prevent manual model removal for Ollama
    if provider_id == "ollama":
        click.echo(
            click.style(
                "Error: Ollama models cannot be removed via this command. Use 'ollama rm <model>' to delete models.",
                fg="red",
            ),
        )
        raise SystemExit(1)

    try:
        remove_model(provider_id, model_id)
    except ValueError as exc:
        click.echo(click.style(f"Error: {exc}", fg="red"))
        raise SystemExit(1) from exc
    click.echo(f"✓ Model '{model_id}' removed from '{provider_id}'.")


# ---------------------------------------------------------------------------
# Ollama model management commands
# ---------------------------------------------------------------------------


@models_group.command("ollama-pull")
@click.argument("model_name")
def ollama_pull_cmd(model_name: str) -> None:
    """Download an Ollama model.

    \b
    Examples:
      lightclaw models ollama-pull mistral:7b
      lightclaw models ollama-pull qwen2.5:3b
    """
    try:
        from ..providers.ollama_manager import OllamaModelManager
    except ImportError as exc:
        click.echo(
            click.style(
                "Ollama SDK not installed. Install with: pip install ollama",
                fg="red",
            ),
        )
        raise SystemExit(1) from exc

    click.echo(f"Downloading Ollama model: {model_name}...")
    try:
        manager = OllamaModelManager()
        manager.pull_model(model_name)
        click.echo(f"✓ Model '{model_name}' downloaded successfully.")
        click.echo("\nTo use this model, run:\n  lightclaw models set-llm")
    except Exception as exc:
        click.echo(click.style(f"Download failed: {exc}", fg="red"))
        raise SystemExit(1) from exc


@models_group.command("ollama-list")
def ollama_list_cmd() -> None:
    """List all Ollama models."""
    try:
        from ..providers.ollama_manager import OllamaModelManager
    except ImportError as exc:
        click.echo(
            click.style(
                "Ollama SDK not installed. Install with: pip install ollama",
                fg="red",
            ),
        )
        raise SystemExit(1) from exc

    try:
        manager = OllamaModelManager()
        models = manager.list_models()
    except Exception as exc:
        click.echo(click.style(f"Error: {exc}", fg="red"))
        raise SystemExit(1) from exc

    if not models:
        click.echo("No Ollama models found.")
        click.echo("Use 'lightclaw models ollama-pull <model>' to download one.")
        return

    click.echo(f"\n=== Ollama Models ({len(models)}) ===")
    for m in models:
        size_gb = m.size / (1024 * 1024 * 1024)
        click.echo(f"\n{'─' * 44}")
        click.echo(f"  {m.name}")
        if m.size > 0:
            click.echo(f"  Size:    {size_gb:.2f} GB")
        if m.digest:
            click.echo(f"  Digest:  {m.digest[:16]}...")
    click.echo()


@models_group.command("ollama-remove")
@click.argument("model_name")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
def ollama_remove_cmd(model_name: str, yes: bool) -> None:
    """Remove an Ollama model.

    \b
    Examples:
      lightclaw models ollama-remove mistral:7b
      lightclaw models ollama-remove qwen2.5:3b -y
    """
    try:
        from ..providers.ollama_manager import OllamaModelManager
    except ImportError as exc:
        click.echo(
            click.style(
                "Ollama SDK not installed. Install with: pip install ollama",
                fg="red",
            ),
        )
        raise SystemExit(1) from exc

    if not yes and not click.confirm(f"Delete Ollama model '{model_name}'?"):
        return

    try:
        manager = OllamaModelManager()
        manager.delete_model(model_name)
        click.echo(f"✓ Model '{model_name}' deleted.")
    except Exception as exc:
        click.echo(click.style(f"Error: {exc}", fg="red"))
        raise SystemExit(1) from exc
