"""lightclaw env — manage runtime environment variables."""

from __future__ import annotations

import re

import click

from ..envs import delete_env_var, load_envs, set_env_var


@click.group("env")
def env_group() -> None:
    """Manage environment variables.

    \b
    Examples:
      lightclaw env list          - View all variables
      lightclaw env edit          - Interactive editor (add/edit/delete/view)
      lightclaw env set KEY VALUE - Set a single variable
      lightclaw env delete KEY    - Delete a variable
    """


@env_group.command("list")
def list_cmd() -> None:
    """List all configured environment variables."""
    envs = load_envs()
    if not envs:
        click.echo("No environment variables configured.")
        return
    click.echo(f"\n  {'Key':<30s}  Value")
    click.echo(f"  {'─' * 56}")
    for key in sorted(envs):
        click.echo(f"  {key:<30s}  {envs[key]}")
    click.echo()


@env_group.command("set")
@click.argument("key")
@click.argument("value")
def set_cmd(key: str, value: str) -> None:
    """Set an environment variable.

    \b
    Examples:
      lightclaw env set OPENAI_API_KEY sk-abc123
      lightclaw env set CUSTOM_BASE_URL https://api.example.com/v1
    """
    set_env_var(key, value)
    click.echo(f"✓ {key} = {value}")


@env_group.command("delete")
@click.argument("key")
def delete_cmd(key: str) -> None:
    """Delete an environment variable.

    \b
    Examples:
      lightclaw env delete OPENAI_API_KEY
    """
    envs = load_envs()
    if key not in envs:
        raise click.ClickException(f"env var '{key}' not found.")
    delete_env_var(key)
    click.echo(f"✓ Deleted: {key}")


@env_group.command("edit")
def edit_cmd() -> None:
    """Interactively edit environment variables in .env file.

    \b
    Features:
      • View all variables
      • Add new variables
      • Edit existing values
      • Delete variables
      • Bulk operations

    Navigation: Use arrow keys, Space to select, Enter to confirm.
    """
    from .utils import prompt_select

    while True:
        envs = load_envs()

        # Build menu options
        menu_options = [
            ("➕ Add new variable", "add"),
            ("📝 Edit existing variable", "edit"),
            ("🗑️  Delete variable", "delete"),
            ("📋 View all variables", "list"),
            ("✅ Done", "done"),
        ]

        action = prompt_select("What would you like to do?", menu_options)
        if action is None or action == "done":
            click.echo("✓ Environment configuration saved.")
            break

        if action == "add":
            _add_variable_interactive()
        elif action == "edit":
            if not envs:
                click.echo("⚠️  No environment variables configured yet.")
                continue
            _edit_variable_interactive(envs)
        elif action == "delete":
            if not envs:
                click.echo("⚠️  No environment variables configured yet.")
                continue
            _delete_variable_interactive(envs)
        elif action == "list":
            _list_variables(envs)


def _add_variable_interactive() -> None:
    """Interactively add a new environment variable."""
    click.echo()
    while True:
        key = click.prompt("  Variable name", default="", show_default=False).strip()
        if not key:
            click.echo("  (Cancelled)")
            return
        if not _is_valid_env_key(key):
            click.echo(click.style("  ✗ Invalid key (use A-Z, 0-9, underscore)", fg="red"))
            continue
        envs = load_envs()
        if key in envs:
            click.echo(
                click.style(
                    f"  ⚠️  Variable '{key}' already exists (current value: {envs[key]})",
                    fg="yellow",
                )
            )
            if not click.confirm("  Overwrite?"):
                continue
        break

    value = click.prompt(f"  Value for {key}", default="", show_default=False).strip()
    set_env_var(key, value)
    click.echo(click.style(f"  ✓ Added: {key} = {value}", fg="green"))
    click.echo()


def _edit_variable_interactive(envs: dict[str, str]) -> None:
    """Interactively edit an existing environment variable."""
    from .utils import prompt_choice

    click.echo()
    key = prompt_choice(
        "  Which variable to edit?",
        sorted(envs.keys()),
    )
    if key is None:
        return

    current_value = envs[key]
    click.echo(f"  Current value: {current_value}")
    new_value = click.prompt(f"  New value for {key}", default=current_value)

    if new_value == current_value:
        click.echo("  (No changes)")
        click.echo()
        return

    set_env_var(key, new_value)
    click.echo(click.style(f"  ✓ Updated: {key} = {new_value}", fg="green"))
    click.echo()


def _delete_variable_interactive(envs: dict[str, str]) -> None:
    """Interactively delete an environment variable."""
    from .utils import prompt_choice

    click.echo()
    key = prompt_choice(
        "  Which variable to delete?",
        sorted(envs.keys()),
    )
    if key is None:
        return

    if click.confirm(f"  Delete '{key}'? (value: {envs[key]})"):
        delete_env_var(key)
        click.echo(click.style(f"  ✓ Deleted: {key}", fg="green"))
    else:
        click.echo("  (Cancelled)")
    click.echo()


def _list_variables(envs: dict[str, str]) -> None:
    """Display all environment variables in a formatted table."""
    if not envs:
        click.echo("No environment variables configured.")
        click.echo()
        return

    click.echo()
    click.echo(f"  {'Key':<30s}  Value")
    click.echo(f"  {'─' * 60}")
    for key in sorted(envs):
        value = envs[key]
        # Truncate long values for display
        if len(value) > 25:
            display_value = value[:22] + "..."
        else:
            display_value = value
        click.echo(f"  {key:<30s}  {display_value}")
    click.echo()


def _is_valid_env_key(key: str) -> bool:
    """Check if a string is a valid environment variable name.

    Valid names: uppercase letters, digits, underscores, no leading digits.
    """
    if not key:
        return False
    # Environment variable names: [A-Z_][A-Z0-9_]*
    return bool(re.match(r"^[A-Z_][A-Z0-9_]*$", key))


def configure_env_interactive() -> None:
    """Interactively add/edit environment variables (used by lightclaw config)."""
    from .utils import prompt_confirm

    while True:
        key = click.prompt("  Variable name", default="", show_default=False).strip()
        if not key:
            break
        current = load_envs().get(key, "")
        value = click.prompt(
            f"  Value for {key}",
            default=current or "",
            show_default=bool(current),
        )
        set_env_var(key, value)
        click.echo(f"  ✓ {key} = {value}")
        if not prompt_confirm("Add another variable?", default=False):
            break
    click.echo("Environment variable configuration complete.")
