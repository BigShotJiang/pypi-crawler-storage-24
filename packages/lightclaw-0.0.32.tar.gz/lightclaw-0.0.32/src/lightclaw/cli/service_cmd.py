"""lightclaw service commands — start / stop / restart as a system service.

Supported backends:
  - Linux:  systemd  (user service, ~/.config/systemd/user/)
  - macOS:  launchd  (user agent,  ~/Library/LaunchAgents/)
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import click

from ..config.utils import read_last_api, write_last_api

# ── Helpers ───────────────────────────────────────────────────────────────────

_PLATFORM = sys.platform  # "linux", "darwin", "win32"

# Service / plist identifier used for both systemd and launchd.
_SERVICE_NAME = "com.lightclaw.service"

# systemd unit name (without the redundant .service extension that would
# result from appending .service to a name that already ends in .service).
_SYSTEMD_UNIT_NAME = "com.lightclaw"


# systemd unit file path (Linux).
# Prefer system-level unit (/etc/systemd/system/) when running as root,
# otherwise fall back to user-level (~/.config/systemd/user/).
def _systemd_is_root() -> bool:
    import os

    return os.geteuid() == 0


def _systemd_unit_dir() -> Path:
    if _systemd_is_root():
        return Path("/etc/systemd/system")
    return Path.home() / ".config" / "systemd" / "user"


def _systemd_unit_file() -> Path:
    return _systemd_unit_dir() / f"{_SYSTEMD_UNIT_NAME}.service"


def _systemctl(*args: str) -> list[str]:
    """Build a systemctl command (system-level for root, user-level otherwise)."""
    if _systemd_is_root():
        return ["systemctl", *args]
    return ["systemctl", "--user", *args]


# launchd plist path (macOS).
_LAUNCHD_DIR = Path.home() / "Library" / "LaunchAgents"
_LAUNCHD_PLIST = _LAUNCHD_DIR / f"{_SERVICE_NAME}.plist"


def _lightclaw_bin() -> str:
    """Return the absolute path to the lightclaw executable."""
    import shutil

    # Prefer the executable in the same venv that is currently running.
    candidate = Path(sys.executable).parent / "lightclaw"
    if candidate.exists():
        return str(candidate)

    found = shutil.which("lightclaw")
    if found:
        return found

    return "lightclaw"  # fallback — hope it is on PATH at service start


def _run(cmd: list[str], *, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(cmd, check=check, text=True, capture_output=True)


# ── systemd (Linux) ───────────────────────────────────────────────────────────


def _systemd_unit_content(log_level: str) -> str:
    exe = _lightclaw_bin()
    exec_start = f"{exe} run --from-configfile --log-level {log_level}"
    wanted_by = "multi-user.target" if _systemd_is_root() else "default.target"
    return f"""\
[Unit]
Description=LightClaw AI assistant service
After=network.target

[Service]
Type=simple
ExecStart={exec_start}
Restart=on-failure
RestartSec=5

[Install]
WantedBy={wanted_by}
"""


def _systemd_install(log_level: str) -> None:
    unit_file = _systemd_unit_file()
    unit_file.parent.mkdir(parents=True, exist_ok=True)
    unit_file.write_text(_systemd_unit_content(log_level))
    _run(_systemctl("daemon-reload"))
    _run(_systemctl("enable", _SYSTEMD_UNIT_NAME))
    click.echo(f"  systemd unit installed: {unit_file}")


def _systemd_start(log_level: str) -> None:
    if not _systemd_unit_file().exists():
        _systemd_install(log_level)
    _run(_systemctl("start", _SYSTEMD_UNIT_NAME))


def _systemd_stop() -> None:
    _run(_systemctl("stop", _SYSTEMD_UNIT_NAME), check=False)


def _systemd_restart(log_level: str) -> None:
    if not _systemd_unit_file().exists():
        _systemd_install(log_level)
    _run(_systemctl("restart", _SYSTEMD_UNIT_NAME))


def _systemd_status() -> None:
    result = _run(_systemctl("status", _SYSTEMD_UNIT_NAME), check=False)
    click.echo(result.stdout or result.stderr)


# ── launchd (macOS) ───────────────────────────────────────────────────────────


def _launchd_plist_content(log_level: str) -> str:
    exe = _lightclaw_bin()
    log_out = Path.home() / ".lightclaw" / "logs" / "lightclaw.log"
    log_err = Path.home() / ".lightclaw" / "logs" / "lightclaw-error.log"
    log_out.parent.mkdir(parents=True, exist_ok=True)

    return f"""\
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
    "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>{_SERVICE_NAME}</string>

    <key>ProgramArguments</key>
    <array>
        <string>{exe}</string>
        <string>run</string>
        <string>--from-configfile</string>
        <string>--log-level</string>
        <string>{log_level}</string>
    </array>

    <key>RunAtLoad</key>
    <true/>

    <key>KeepAlive</key>
    <true/>

    <key>StandardOutPath</key>
    <string>{log_out}</string>

    <key>StandardErrorPath</key>
    <string>{log_err}</string>
</dict>
</plist>
"""


def _launchd_install(log_level: str) -> None:
    _LAUNCHD_DIR.mkdir(parents=True, exist_ok=True)
    _LAUNCHD_PLIST.write_text(_launchd_plist_content(log_level))
    click.echo(f"  launchd plist installed: {_LAUNCHD_PLIST}")


def _launchd_load() -> None:
    _run(["launchctl", "load", "-w", str(_LAUNCHD_PLIST)], check=False)


def _launchd_unload() -> None:
    _run(["launchctl", "unload", str(_LAUNCHD_PLIST)], check=False)


def _launchd_start(log_level: str) -> None:
    if not _LAUNCHD_PLIST.exists():
        _launchd_install(log_level)
    _launchd_load()


def _launchd_stop() -> None:
    if _LAUNCHD_PLIST.exists():
        _launchd_unload()


def _launchd_restart(log_level: str) -> None:
    if not _LAUNCHD_PLIST.exists():
        _launchd_install(log_level)
    _launchd_unload()
    _launchd_load()


# ── start ─────────────────────────────────────────────────────────────────────


def _default_host() -> str:
    """Return host from last_api config, or fall back to 127.0.0.1."""
    try:
        result = read_last_api()
        if result:
            return result[0]
    except Exception:
        pass
    return "127.0.0.1"


def _default_port() -> int:
    """Return port from last_api config, or fall back to 8088."""
    try:
        result = read_last_api()
        if result:
            return result[1]
    except Exception:
        pass
    return 8088


@click.command("start")
@click.option("--host", default=None, help="Bind host (default: from lastApi config or 127.0.0.1)")
@click.option(
    "--port",
    default=None,
    type=int,
    help="Bind port (default: from lastApi config or 8088)",
)
@click.option(
    "--log-level",
    default="info",
    show_default=True,
    type=click.Choice(
        ["critical", "error", "warning", "info", "debug"],
        case_sensitive=False,
    ),
    help="Log level",
)
def start_cmd(host: str, port: int, log_level: str) -> None:
    """Register and start LightClaw as a system service (auto-starts on reboot).

    If host/port are specified, they will be saved to the config file.
    Otherwise, the service will use values from the config file.
    """
    _check_platform()

    # If user explicitly provided host or port, save them to config
    if host is not None or port is not None:
        # Get current config values
        current = read_last_api()
        current_host = current[0] if current else _default_host()
        current_port = current[1] if current else _default_port()

        # Use provided values or keep current
        resolved_host = host if host is not None else current_host
        resolved_port = port if port is not None else current_port

        # Write to config
        write_last_api(resolved_host, resolved_port)
        click.echo(f"Config updated: host={resolved_host}, port={resolved_port}")

    click.echo("Starting LightClaw service...")
    try:
        if _PLATFORM == "linux":
            _systemd_start(log_level)
        else:
            _launchd_start(log_level)
        click.echo("LightClaw service started.")
        _print_log_hint()
    except subprocess.CalledProcessError as exc:
        _die(exc)


# ── stop ──────────────────────────────────────────────────────────────────────


@click.command("stop")
def stop_cmd() -> None:
    """Stop the LightClaw system service."""
    _check_platform()
    click.echo("Stopping LightClaw service...")
    try:
        if _PLATFORM == "linux":
            _systemd_stop()
        else:
            _launchd_stop()
        click.echo("LightClaw service stopped.")
    except subprocess.CalledProcessError as exc:
        _die(exc)


# ── restart ───────────────────────────────────────────────────────────────────


@click.command("restart")
@click.option(
    "--log-level",
    default="info",
    show_default=True,
    type=click.Choice(
        ["critical", "error", "warning", "info", "debug"],
        case_sensitive=False,
    ),
    help="Log level",
)
def restart_cmd(log_level: str) -> None:
    """Restart the LightClaw system service.

    The service will use host/port values from the config file.
    """
    _check_platform()
    click.echo("Restarting LightClaw service...")
    try:
        if _PLATFORM == "linux":
            _systemd_restart(log_level)
        else:
            _launchd_restart(log_level)
        click.echo("LightClaw service restarted.")
        _print_log_hint()
    except subprocess.CalledProcessError as exc:
        _die(exc)


# ── Utilities ─────────────────────────────────────────────────────────────────


def _check_platform() -> None:
    if _PLATFORM not in ("linux", "darwin"):
        raise click.ClickException(
            f"System service management is not supported on {_PLATFORM}. "
            "Use 'lightclaw run' to start the service manually."
        )


def _print_log_hint() -> None:
    if _PLATFORM == "linux":
        click.echo(f"  Logs: journalctl --user -u {_SYSTEMD_UNIT_NAME} -f")
    else:
        log_path = Path.home() / ".lightclaw" / "logs" / "lightclaw.log"
        click.echo(f"  Logs: tail -f {log_path}")


def _die(exc: subprocess.CalledProcessError) -> None:
    msg = (exc.stderr or exc.stdout or str(exc)).strip()
    raise click.ClickException(msg)
