"""CLI commands for managing embedding providers (none/local/custom)."""

from __future__ import annotations

import asyncio
import logging
import threading
import time

import click

from ..config import load_config, save_config
from ..config.config import EmbeddingConfig
from ..embedding.local_server import PRESET_MODELS, LocalEmbeddingServer
from ..providers import mask_api_key
from .utils import prompt_choice, prompt_confirm

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Interactive Configuration Functions
# ─────────────────────────────────────────────────────────────────────────────


def _select_provider_interactive() -> str:
    """Prompt user to pick a provider (none/local/custom). Returns provider id."""
    options = [
        "none (keyword-only search)",
        "local (offline fastembed, ~100-450MB)",
        "custom (OpenAI-compatible API)",
    ]
    labels = options
    ids = ["none", "local", "custom"]

    chosen_label = prompt_choice(
        "Select embedding provider:",
        options=labels,
        default=labels[1],  # Default to local
    )
    return ids[labels.index(chosen_label)]


def _select_local_model_interactive() -> str:
    """Prompt user to pick a local model from preset list."""
    if not PRESET_MODELS:
        model = click.prompt("Model name (e.g., BAAI/bge-small-zh-v1.5)").strip()
        if not model:
            click.echo(click.style("Error: model name is required.", fg="red"))
            raise SystemExit(1)
        return model

    labels = PRESET_MODELS
    chosen = prompt_choice(
        "Select embedding model:",
        options=labels,
        default=labels[0] if labels else None,
    )
    return chosen


def configure_custom_embedding_interactive() -> tuple[str, str, str, int]:
    """Interactively configure custom (OpenAI-compatible) embedding provider.

    Returns: (base_url, api_key, model_name, dimensions)
    """
    base_url = click.prompt("Base URL (OpenAI-compatible endpoint)").strip()
    if not base_url:
        click.echo(click.style("Error: base_url is required.", fg="red"))
        raise SystemExit(1)

    api_key = click.prompt(
        "API key",
        hide_input=True,
        show_default=False,
        prompt_suffix=": ",
    )
    if not api_key:
        click.echo(click.style("Error: API key is required.", fg="red"))
        raise SystemExit(1)

    model_name = click.prompt("Model name (e.g., text-embedding-3-small)").strip()
    if not model_name:
        click.echo(click.style("Error: model_name is required.", fg="red"))
        raise SystemExit(1)

    dimensions = click.prompt(
        "Vector dimensions (optional)",
        type=int,
        default=512,
        show_default=True,
    )

    return base_url, api_key, model_name, dimensions


def configure_embedding_interactive(*, use_defaults: bool = False) -> None:
    """Interactively configure embedding provider."""
    provider = _select_provider_interactive()

    if provider == "none":
        config = load_config()
        config.embedding = EmbeddingConfig(provider="none")
        save_config(config)
        click.echo("✓ Embedding disabled. Memory will use keyword-only search.")
        return

    if provider == "local":
        if use_defaults and PRESET_MODELS:
            model_name = PRESET_MODELS[0]
        else:
            model_name = _select_local_model_interactive()

        config = load_config()
        config.embedding = EmbeddingConfig(
            provider="local",
            local_model=model_name,
        )
        save_config(config)

        # Trigger download
        click.echo(f"\nDownloading {model_name}...")
        try:
            download_local_model_cli_sync(model_name)
        except Exception as exc:
            click.echo(click.style(f"Download failed: {exc}", fg="red"))
            click.echo("You can retry later with: lightclaw embedding download <model>")
        return

    if provider == "custom":
        base_url, api_key, model_name, dimensions = configure_custom_embedding_interactive()

        config = load_config()
        config.embedding = EmbeddingConfig(
            provider="custom",
            api_key=api_key,
            base_url=base_url,
            model_name=model_name,
            dimensions=dimensions,
        )
        save_config(config)
        click.echo(f"✓ Custom embedding configured: {base_url}")
        click.echo(f"  Model: {model_name}")
        return


def show_embedding_status() -> None:
    """Print current embedding configuration and status."""
    config = load_config()
    embedding = config.embedding

    click.echo("\n" + "─" * 44)
    click.echo("  Embedding Configuration")
    click.echo("─" * 44)

    if embedding.provider == "none":
        click.echo("  Provider:          none (disabled)")
        click.echo("  Search Mode:       Keyword-only (FTS)")
        click.echo("  Vector Search:     ✗ Disabled")
    elif embedding.provider == "local":
        click.echo("  Provider:          local")
        click.echo(f"  Model:             {embedding.local_model}")
        click.echo(f"  Vector Dimensions: {512}")  # Default for local
        click.echo("  Cache Location:    ~/.lightclaw/embedding_models/")
        click.echo("  Search Mode:       ✓ Vector + Keyword")
        click.echo("  Status:            ✓ Ready")
    elif embedding.provider == "custom":
        click.echo("  Provider:          custom")
        click.echo(f"  Base URL:          {embedding.base_url}")
        click.echo(f"  Model:             {embedding.model_name}")
        click.echo(f"  Vector Dimensions: {embedding.dimensions}")
        click.echo(f"  API Key:           {mask_api_key(embedding.api_key)}")
        click.echo("  Search Mode:       ✓ Vector + Keyword")
        click.echo("  Status:            ✓ Ready")

    click.echo("─" * 44 + "\n")


def list_local_models() -> None:
    """Show available preset local models."""
    click.echo("\nAvailable Local Embedding Models:\n")

    if not PRESET_MODELS:
        click.echo("  No preset models available.")
    else:
        for model in PRESET_MODELS:
            click.echo(f"  • {model}")

    click.echo("\nTo download a model, run:")
    click.echo("  lightclaw embedding download <model_name>\n")
    click.echo("Or use interactive config:")
    click.echo("  lightclaw embedding config\n")


def download_local_model_cli_sync(model_name: str) -> None:
    """Download a local embedding model with spinner (synchronous, blocking)."""
    if not model_name or not model_name.strip():
        click.echo(click.style("Error: model_name is required.", fg="red"))
        raise SystemExit(1)

    # Warn if not in preset list but allow custom
    if model_name not in PRESET_MODELS:
        click.echo(click.style(f"⚠ Warning: '{model_name}' not in preset models list.", fg="yellow"))
        if not prompt_confirm("Continue downloading anyway?", default=False):
            return

    click.echo(f"Downloading {model_name}...")

    # Run spinner in a background thread while download happens in asyncio
    _done = threading.Event()
    _error: list[Exception] = []

    def _spin() -> None:
        frames = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
        i = 0
        while not _done.is_set():
            click.echo(f"\r  {frames[i % len(frames)]} Loading...", nl=False)
            time.sleep(0.1)
            i += 1
        click.echo("\r" + " " * 30 + "\r", nl=False)  # Clear spinner line

    spinner_thread = threading.Thread(target=_spin, daemon=True)
    spinner_thread.start()

    async def _do_download() -> None:
        server = LocalEmbeddingServer(model_name=model_name)
        try:
            await server.initialize()
        except ImportError:
            _error.append(ImportError("fastembed not installed. Run: uv sync --extra local-embedding"))
        except Exception as exc:
            _error.append(exc)
        finally:
            _done.set()

    try:
        asyncio.run(_do_download())
    except Exception as exc:
        _done.set()
        spinner_thread.join(timeout=1)
        click.echo(click.style(f"✗ Download failed: {exc}", fg="red"))
        raise SystemExit(1) from exc

    spinner_thread.join(timeout=1)

    if _error:
        click.echo(click.style(f"✗ Download failed: {_error[0]}", fg="red"))
        raise SystemExit(1)

    # Save config
    config = load_config()
    config.embedding = EmbeddingConfig(provider="local", local_model=model_name)
    save_config(config)

    click.echo(f"✓ Model '{model_name}' ready!")
    click.echo(f"✓ Embedding configured: local / {model_name}")


# ─────────────────────────────────────────────────────────────────────────────
# CLI Commands
# ─────────────────────────────────────────────────────────────────────────────


@click.group("embedding")
def embedding_group() -> None:
    """Manage embedding providers (vector search configuration)."""


@embedding_group.command("config")
def config_cmd() -> None:
    """Interactively configure embedding provider (none/local/custom)."""
    configure_embedding_interactive(use_defaults=False)


@embedding_group.command("status")
def status_cmd() -> None:
    """Show current embedding configuration and status."""
    show_embedding_status()


@embedding_group.command("list")
def list_cmd() -> None:
    """List available preset local embedding models."""
    list_local_models()


@embedding_group.command("download")
@click.argument("model_name")
def download_cmd(model_name: str) -> None:
    """Download a local embedding model with progress bar.

    \b
    Example:
      lightclaw embedding download BAAI/bge-small-zh-v1.5
    """
    download_local_model_cli_sync(model_name)
