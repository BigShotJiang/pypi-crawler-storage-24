"""lightclaw update — check for a newer release on PyPI and upgrade if needed."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.request

import click

_PACKAGE_NAME = "lightclaw"
_PYPI_URL = f"https://pypi.org/pypi/{_PACKAGE_NAME}/json"


def _sync_workspace_templates() -> None:
    """Sync system prompt templates in the workspace to the latest package version."""
    from ..agent.utils import sync_workspace_prompts
    from ..config import get_config_path, load_config

    config_path = get_config_path()
    if config_path.is_file():
        cfg = load_config(config_path)
        language = cfg.agents.language
    else:
        language = "en"

    click.echo(f"\nSyncing workspace templates [{language}]...")
    synced, skipped = sync_workspace_prompts(language)
    if synced:
        click.echo(
            click.style(
                f"  Synced {len(synced)} file(s): {', '.join(sorted(synced))}",
                fg="green",
            )
        )
    else:
        click.echo("  No system templates needed syncing.")
    if skipped:
        click.echo(
            click.style(
                f"  Skipped {len(skipped)} user file(s): {', '.join(sorted(skipped))}",
                fg="yellow",
            )
        )


def _get_installed_version(python_exe: str | None = None) -> str | None:
    """Query the installed version by spawning a fresh interpreter.

    Because importlib.metadata caches metadata for the lifetime of the current
    process, calling it after an in-process upgrade still returns the old
    version.  Spawning a subprocess with the target interpreter bypasses the
    cache and always reflects what is on disk.
    """
    exe = python_exe or sys.executable
    try:
        result = subprocess.run(
            [
                exe,
                "-c",
                f"from importlib.metadata import version; print(version({_PACKAGE_NAME!r}))",
            ],
            capture_output=True,
            text=True,
            check=False,
        )
        if result.returncode == 0:
            return result.stdout.strip() or None
    except Exception:
        pass
    return None


def _get_local_version() -> str:
    """Return the currently installed package version.

    Prefer importlib.metadata so the version reflects what is actually
    installed on disk rather than the in-process source tree (important
    when the package is installed in editable mode).
    """
    try:
        from importlib.metadata import version

        return version(_PACKAGE_NAME)
    except Exception:
        from .. import __version__

        return __version__


def _get_pypi_version(timeout: int = 10) -> str | None:
    """Fetch the latest version string from PyPI. Returns None on failure."""
    try:
        req = urllib.request.Request(
            _PYPI_URL,
            headers={"User-Agent": f"{_PACKAGE_NAME}-updater/1.0"},
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        return data["info"]["version"]
    except urllib.error.URLError as exc:
        click.echo(
            click.style(f"Network error while checking PyPI: {exc}", fg="yellow"),
            err=True,
        )
    except Exception as exc:
        click.echo(
            click.style(f"Failed to fetch version from PyPI: {exc}", fg="yellow"),
            err=True,
        )
    return None


def _parse_version(v: str) -> tuple[int, ...]:
    """Parse a version string into a comparable tuple, ignoring non-numeric parts."""
    parts = []
    for segment in v.split("."):
        # Strip pre-release suffixes (a, b, rc, post, dev …)
        numeric = ""
        for ch in segment:
            if ch.isdigit():
                numeric += ch
            else:
                break
        try:
            parts.append(int(numeric))
        except ValueError:
            parts.append(0)
    return tuple(parts)


def _is_newer(remote: str, local: str) -> bool:
    """Return True if *remote* is strictly newer than *local*."""
    return _parse_version(remote) > _parse_version(local)


def _get_editable_path() -> str | None:
    """Return the source directory path if installed in editable mode, else None."""
    try:
        import importlib.metadata as meta

        dist = meta.distribution(_PACKAGE_NAME)
        direct_url = dist.read_text("direct_url.json")
        if direct_url:
            info = json.loads(direct_url)
            if info.get("dir_info", {}).get("editable", False):
                return info.get("url", "").replace("file://", "") or None
    except Exception:
        pass
    return None


def _get_venv_python() -> str | None:
    """Return the Python executable of the current venv, if running inside one.

    When installed via install.sh the process runs inside ~/.lightclaw/venv.
    Returning sys.executable (which already points to the venv interpreter)
    lets uv / pip upgrade the package in the correct environment without
    needing --system or --break-system-packages.
    """
    # sys.prefix != sys.base_prefix  →  we are inside a virtual environment
    if sys.prefix != getattr(sys, "base_prefix", sys.prefix):
        return sys.executable

    # Also honour the VIRTUAL_ENV env-var (set by the wrapper script or shell)
    venv = os.environ.get("VIRTUAL_ENV", "")
    if venv:
        python = os.path.join(venv, "bin", "python")
        if os.path.isfile(python):
            return python

    return None


def _detect_installer() -> str:
    """Detect whether the package was installed via uv or pip."""
    if shutil.which("uv"):
        return "uv"
    return "pip"


def _has_pip(python_exe: str) -> bool:
    """Return True if the given Python interpreter has pip available."""
    try:
        result = subprocess.run(
            [python_exe, "-m", "pip", "--version"],
            capture_output=True,
            text=True,
            check=False,
        )
        return result.returncode == 0
    except Exception:
        return False


def _try_bootstrap_pip(python_exe: str, verbose: bool) -> bool:
    """Attempt to bootstrap pip via ensurepip. Return True on success."""
    try:
        result = subprocess.run(
            [python_exe, "-m", "ensurepip", "--upgrade"],
            capture_output=not verbose,
            text=True,
            check=False,
        )
        if result.returncode == 0:
            return True
        if not verbose and result.stderr:
            click.echo(result.stderr, err=True)
        return False
    except Exception:
        return False


def _run_upgrade(installer: str, venv_python: str | None, verbose: bool) -> bool:
    """Run the upgrade command and return True on success."""
    if installer == "uv":
        if venv_python:
            # Install into the active venv by passing its Python interpreter.
            # This is the normal path for installs done via install.sh.
            cmd = [
                "uv",
                "pip",
                "install",
                "--python",
                venv_python,
                "--upgrade",
                _PACKAGE_NAME,
            ]
        else:
            # Fallback: no venv detected — install into the system Python.
            cmd = [
                "uv",
                "pip",
                "install",
                "--system",
                "--break-system-packages",
                "--upgrade",
                _PACKAGE_NAME,
            ]
    else:
        # pip always installs into the environment of the running interpreter.
        python_exe = venv_python or sys.executable

        # Verify pip is actually available before attempting to use it.
        # Some venvs are created without pip (e.g. python -m venv --without-pip).
        if not _has_pip(python_exe):
            click.echo(
                click.style(
                    f"pip is not available in {python_exe}. Attempting to bootstrap via ensurepip…",
                    fg="yellow",
                )
            )
            if not _try_bootstrap_pip(python_exe, verbose):
                click.echo(
                    click.style(
                        "Could not bootstrap pip. Consider installing uv (`pip install uv` or "
                        "https://docs.astral.sh/uv/) and re-running `lightclaw update`, or "
                        "manually run: `python -m ensurepip --upgrade` in your environment.",
                        fg="red",
                    ),
                    err=True,
                )
                return False
            click.echo(click.style("pip bootstrapped successfully.", fg="green"))

        cmd = [
            python_exe,
            "-m",
            "pip",
            "install",
            "--upgrade",
            _PACKAGE_NAME,
        ]

    click.echo(f"Running: {' '.join(cmd)}")
    result = subprocess.run(
        cmd,
        check=False,
        capture_output=not verbose,
        text=True,
    )
    if result.returncode != 0:
        if not verbose and result.stderr:
            click.echo(result.stderr, err=True)
        return False
    if verbose and result.stdout:
        click.echo(result.stdout)
    return True


@click.command("update")
@click.option(
    "--check",
    "check_only",
    is_flag=True,
    default=False,
    help="Only check for a newer version; do not install.",
)
@click.option(
    "--yes",
    "-y",
    is_flag=True,
    default=False,
    help="Skip confirmation prompt and upgrade immediately.",
)
@click.option(
    "--verbose",
    "-v",
    is_flag=True,
    default=False,
    help="Show full installer output.",
)
@click.option(
    "--sync-workspace",
    "sync_workspace",
    is_flag=True,
    default=False,
    help="Sync system prompt templates (AGENTS.md, SOUL.md, etc.) in the workspace to the latest version shipped with the package. User-data files (USER.md, MEMORY.md, IDENTITY.md) are never touched.",
)
def update_cmd(check_only: bool, yes: bool, verbose: bool, sync_workspace: bool) -> None:
    """Check PyPI for a newer version and upgrade if available.

    \b
    Examples:
      lightclaw update                    # interactive upgrade
      lightclaw update --check            # print version info, no install
      lightclaw update --yes              # non-interactive upgrade
      lightclaw update --sync-workspace   # upgrade + sync workspace templates
    """
    local_ver = _get_local_version()
    click.echo(f"Current version : {click.style(local_ver, bold=True)}")
    click.echo("Checking PyPI for latest version …")

    remote_ver = _get_pypi_version()
    if remote_ver is None:
        click.echo(click.style("Could not determine the latest version.", fg="red"))
        raise SystemExit(1)

    click.echo(f"Latest version  : {click.style(remote_ver, bold=True)}")

    if not _is_newer(remote_ver, local_ver):
        click.echo(
            click.style(
                f"\n{_PACKAGE_NAME} {local_ver} is already up to date.",
                fg="green",
            )
        )
        if sync_workspace:
            _sync_workspace_templates()
        return

    click.echo(
        click.style(
            f"\nNew version available: {local_ver} → {remote_ver}",
            fg="cyan",
        )
    )

    if check_only:
        click.echo("Run `lightclaw update` (without --check) to install the new version.")
        if sync_workspace:
            _sync_workspace_templates()
        return

    # Editable installs: upgrading via pip/uv would install a separate copy in
    # site-packages while the entry-point still runs from the source checkout.
    # Guide the user to use git instead, which is the correct workflow.
    editable_path = _get_editable_path()
    if editable_path:
        click.echo(
            click.style(
                f"\nThis installation is running from source ({editable_path}).",
                fg="yellow",
            )
        )
        click.echo(f"To upgrade a source / editable install, pull the latest code:\n  cd {editable_path} && git pull")
        if sync_workspace:
            _sync_workspace_templates()
        return

    if not yes:
        ok = click.confirm(
            f"Upgrade {_PACKAGE_NAME} to {remote_ver}?",
            default=True,
        )
        if not ok:
            click.echo("Upgrade cancelled.")
            if sync_workspace:
                _sync_workspace_templates()
            return

    venv_python = _get_venv_python()
    installer = _detect_installer()
    click.echo(f"Using installer  : {installer}")

    success = _run_upgrade(installer, venv_python, verbose)
    if success:
        # Verify by spawning a fresh interpreter — importlib.metadata caches
        # the old version for the lifetime of this process, so we cannot rely
        # on calling it directly after the upgrade.
        # Retry up to 3 times with a short delay, as the package metadata
        # may take a moment to update after installation.
        actual_ver = None
        for attempt in range(3):
            actual_ver = _get_installed_version(venv_python)
            if actual_ver and actual_ver != local_ver:
                # Version has changed, stop retrying
                break
            if attempt < 2:
                time.sleep(0.5)

        if actual_ver and _is_newer(actual_ver, local_ver):
            # Version advanced — report the actual version installed
            click.echo(
                click.style(
                    f"\n{_PACKAGE_NAME} successfully upgraded to {actual_ver}.",
                    fg="green",
                )
            )
        elif actual_ver == local_ver:
            # Installer reported success but version did not change after retries
            click.echo(
                click.style(
                    f"\nWarning: upgrade reported success but version is still "
                    f"{actual_ver}. You may need to restart your shell.",
                    fg="yellow",
                )
            )
        else:
            # Could not verify — trust the installer exit code
            click.echo(
                click.style(
                    f"\n{_PACKAGE_NAME} successfully upgraded to {remote_ver}.",
                    fg="green",
                )
            )
        click.echo("Please restart lightclaw for the changes to take effect.")
        click.echo("\nNext steps:")
        click.echo("  lightclaw run    # start in the foreground")
        click.echo("  lightclaw start  # restart as a background service")
    else:
        click.echo(click.style("\nUpgrade failed. Check the output above for details.", fg="red"))
        if not sync_workspace:
            raise SystemExit(1)

    if sync_workspace:
        _sync_workspace_templates()
