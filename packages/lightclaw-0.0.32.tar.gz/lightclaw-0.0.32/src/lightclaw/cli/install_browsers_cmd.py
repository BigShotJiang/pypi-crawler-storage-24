"""lightclaw install-browsers — manually install Playwright browser binaries."""

from __future__ import annotations

import click


@click.command("install-browsers")
@click.option(
    "--mirror",
    default=None,
    metavar="URL",
    help="Override download mirror URL (sets PLAYWRIGHT_DOWNLOAD_HOST).",
)
def install_browsers_cmd(mirror: str | None) -> None:
    """Install Playwright Chromium browser binary.

    \b
    Downloads the Chromium binary used by the browser-use tool.
    By default uses npmmirror.com to avoid timeouts on restricted networks.
    Run this once after installation; it is not triggered automatically.

    \b
    Examples:
      lightclaw install-browsers
      lightclaw install-browsers --mirror https://npmmirror.com/mirrors/playwright
    """
    import os

    from ..agent.tools.browser.playwright_install import ensure_playwright_browsers

    if mirror:
        os.environ["PLAYWRIGHT_DOWNLOAD_HOST"] = mirror
        click.echo(f"Using mirror: {mirror}")

    ok = ensure_playwright_browsers(quiet=False)
    if not ok:
        raise SystemExit(1)
