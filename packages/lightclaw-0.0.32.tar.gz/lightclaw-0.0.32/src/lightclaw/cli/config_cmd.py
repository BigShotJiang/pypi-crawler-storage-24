"""lightclaw config — interactive configuration wizard."""

from __future__ import annotations

import click
from rich.console import Console
from rich.panel import Panel

from ..config import (
    get_config_path,
    get_heartbeat_query_path,
    load_config,
    save_config,
)
from ..config.config import (
    ActiveHoursConfig,
    Config,
    HeartbeatConfig,
)
from ..constant import HEARTBEAT_DEFAULT_EVERY
from ..providers import load_providers_json
from .channels_cmd import configure_channels_interactive
from .embedding_cmd import configure_embedding_interactive
from .env_cmd import configure_env_interactive
from .providers_cmd import configure_providers_interactive
from .skills_cmd import configure_skills_interactive
from .utils import prompt_choice, prompt_confirm

SECURITY_WARNING = """
Security warning — please read.

LightClaw is a personal assistant that runs in your own environment. It can connect to
channels (DingTalk, Feishu, QQ, Discord, etc.) and run skills that read
files, run commands, and call external APIs. By default it is a single-operator
boundary: one trusted user. A malicious or confused prompt can lead the agent to
do unsafe things if tools are enabled.

If multiple people can message the same LightClaw instance with tools enabled, they
share the same delegated authority (files, commands, secrets the agent can use).

If you are not comfortable with access control and hardening, do not run LightClaw with
tools or expose it to untrusted users. Get help from someone experienced before
enabling powerful skills or exposing the bot to the internet.

Recommended baseline:
- Restrict which channels and users can trigger the agent; use allowlists where possible.
- Multi-user or shared inbox: use separate config/credentials and ideally separate
  OS users or hosts per trust boundary.
- Run skills with least privilege; sandbox where you can.
- Keep secrets out of the agent's working directory and skill-accessible paths.
- Use a capable model when the agent has tools or handles untrusted input.

Review your config and skills regularly; limit tool scope to what you need.
"""


def _echo_security_warning_box() -> None:
    """Print SECURITY_WARNING in a rich panel with blue border."""
    console = Console()
    console.print(
        Panel(
            SECURITY_WARNING.strip(),
            title="[bold]🐾 Security warning — please read[/bold]",
            border_style="blue",
        ),
    )


DEFAULT_HEARTBEAT_MDS = {
    "zh": """# Heartbeat checklist
- 扫描收件箱紧急邮件
- 查看未来 2h 的日历
- 检查待办是否卡住
- 若安静超过 8h，轻量 check-in
""",
    "en": """# Heartbeat checklist
- Scan inbox for urgent email
- Check calendar for next 2h
- Check tasks for blockers
- Light check-in if quiet for 8h
""",
}


@click.command("config")
@click.option(
    "--force",
    is_flag=True,
    help="Overwrite existing lightclaw.json and HEARTBEAT.md if present.",
)
# pylint: disable=too-many-branches,too-many-statements
def config_cmd(force: bool) -> None:
    """Interactively configure LightClaw (channels, LLM, skills, env)."""
    config_path = get_config_path()
    working_dir = config_path.parent
    heartbeat_path = get_heartbeat_query_path()

    click.echo(f"Working dir: {working_dir}")

    # --- Security warning ---
    _echo_security_warning_box()
    accepted = prompt_confirm(
        "Have you read and accepted the security notice above? (yes to continue, no to abort)",
        default=True,
    )
    if not accepted:
        click.echo(
            "Initialization aborted. Read the security notice and run again when ready.",
        )
        raise click.Abort()
    working_dir.mkdir(parents=True, exist_ok=True)

    # --- lightclaw.json ---
    write_config = True
    if config_path.is_file() and not force:
        prompt_text = (
            f'{config_path} exists. Do you want to overwrite it? ("no" for skipping the configuration process)'
        )
        write_config = prompt_confirm(prompt_text, default=False)
    if not write_config:
        click.echo("Skipping configuration.")
    else:
        click.echo("\n=== Heartbeat Configuration ===")
        every = click.prompt(
            "Heartbeat interval (e.g. 30m, 1h)",
            default=HEARTBEAT_DEFAULT_EVERY,
            type=str,
        ).strip()

        target = prompt_choice(
            "Heartbeat target:",
            options=["main", "last"],
            default="main",
        ).lower()

        use_active = prompt_confirm(
            "Set active hours for heartbeat? (skip = run 24h)",
            default=False,
        )
        active_hours = None
        if use_active:
            start = click.prompt("Active start (HH:MM)", default="08:00", type=str)
            end = click.prompt("Active end (HH:MM)", default="22:00", type=str)
            active_hours = ActiveHoursConfig(
                start=start.strip(),
                end=end.strip(),
            )

        hb = HeartbeatConfig(
            every=every or HEARTBEAT_DEFAULT_EVERY,
            target=target or "main",
            active_hours=active_hours,
        )
        existing = load_config(config_path) if config_path.is_file() else Config()
        existing.agents.defaults.heartbeat = hb

        existing.show_tool_details = prompt_confirm(
            "Show tool call/result details in channel messages?",
            default=True,
        )

        language = prompt_choice(
            "Select language for MD files:",
            options=["zh", "en"],
            default=existing.agents.language,
        )
        existing.agents.language = language

        if prompt_confirm(
            "Configure channels? (Discord/DingTalk/Feishu/QQ/WeCom/Console)",
            default=False,
        ):
            configure_channels_interactive(existing)

        save_config(existing, config_path)
        click.echo(f"\n✓ Configuration saved to {config_path}")

    # --- LLM provider ---
    data = load_providers_json()
    llm_pid, llm_model = data.parse_active_llm()
    has_llm = bool(llm_pid and llm_model)

    if has_llm:
        click.echo(
            f"\n✓ LLM already configured: {llm_pid} / {llm_model}",
        )
        if prompt_confirm("Reconfigure LLM provider?", default=False):
            click.echo("\n=== LLM Provider Configuration ===")
            configure_providers_interactive(use_defaults=False)
        else:
            click.echo("Skipped LLM configuration.")
    else:
        click.echo("\n=== LLM Provider Configuration (required) ===")
        configure_providers_interactive(use_defaults=False)

    # --- skills ---
    if write_config:
        skills_choice = prompt_choice(
            "Configure skills:",
            options=["all", "none", "custom"],
            default="all",
        )

        if skills_choice == "all":
            from ..agent.skills_manager import sync_skills_to_working_dir

            click.echo("Enabling all skills...")
            synced, skipped = sync_skills_to_working_dir(skill_names=None, force=False)
            click.echo(f"✓ Skills synced: {synced}, skipped: {skipped}")
        elif skills_choice == "custom":
            configure_skills_interactive()
        else:
            click.echo("Skipped skills configuration.")

    # --- environment variables ---
    if prompt_confirm("Configure environment variables?", default=False):
        configure_env_interactive()
    else:
        click.echo("Skipped environment variable configuration.")

    # --- prompts ---
    from ..agent.utils import copy_prompts

    config = load_config(config_path) if config_path.is_file() else Config()
    current_language = config.agents.language
    installed_language = config.agents.installed_prompts_language

    if installed_language != current_language or force:
        click.echo(f"\nChecking MD files [language: {current_language}]...")
        if installed_language and installed_language != current_language:
            click.echo(f"Language changed: {installed_language} → {current_language}")
        copied = copy_prompts(current_language)
        if copied:
            config.agents.installed_prompts_language = current_language
            save_config(config, config_path)
            click.echo(f"✓ Copied {len(copied)} md file(s): " + ", ".join(copied))
        else:
            click.echo("⚠ No md files copied")
    else:
        click.echo(f"\n✓ MD files [{current_language}] are already up to date.")

    # --- HEARTBEAT.md ---
    write_heartbeat = True
    if heartbeat_path.is_file() and not force:
        write_heartbeat = prompt_confirm(
            f"{heartbeat_path} exists. Overwrite?",
            default=False,
        )
    if not write_heartbeat:
        click.echo("Skipped HEARTBEAT.md.")
    else:
        DEFAULT_HEARTBEAT_MD = DEFAULT_HEARTBEAT_MDS[current_language]
        click.echo("\n=== Heartbeat Query Configuration ===")
        if prompt_confirm("Edit heartbeat query in your default editor?", default=True):
            content = click.edit(DEFAULT_HEARTBEAT_MD, extension=".md", require_save=False)
            if content is None:
                content = DEFAULT_HEARTBEAT_MD
        else:
            content = DEFAULT_HEARTBEAT_MD
        heartbeat_path.write_text(
            content.strip() or DEFAULT_HEARTBEAT_MD,
            encoding="utf-8",
        )
        click.echo(f"✓ Heartbeat query saved to {heartbeat_path}")

    # === NEW: Embedding Configuration ===
    current_config = load_config()
    current_embedding = current_config.embedding

    if current_embedding.provider != "none":
        click.echo(f"\n✓ Embedding configured: {current_embedding.provider}")
        if prompt_confirm("Reconfigure embedding?", default=False):
            click.echo("\n=== Embedding Configuration ===")
            try:
                configure_embedding_interactive(use_defaults=False)
            except Exception as exc:
                click.echo(click.style(f"Warning: Embedding reconfiguration skipped ({exc})", fg="yellow"))
    else:
        if prompt_confirm("Configure embedding for vector search?", default=False):
            click.echo("\n=== Embedding Configuration ===")
            try:
                configure_embedding_interactive(use_defaults=False)
            except Exception as exc:
                click.echo(click.style(f"Warning: Embedding setup skipped ({exc})", fg="yellow"))

    click.echo("\n✓ Configuration complete!")
