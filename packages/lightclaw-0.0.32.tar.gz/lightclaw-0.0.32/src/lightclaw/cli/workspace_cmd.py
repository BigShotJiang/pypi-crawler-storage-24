"""CLI workspace commands — sync with OpenClaw and other workspace utilities."""

from __future__ import annotations

import click


@click.group("workspace")
def workspace_group() -> None:
    """Workspace utilities (sync, export, etc.)."""


@workspace_group.command("sync-openclaw")
@click.option(
    "--openclaw-json",
    "openclaw_json",
    default=None,
    metavar="PATH",
    help="Path to openclaw.json (default: ~/.openclaw/openclaw.json)",
)
@click.option(
    "--dry-run",
    is_flag=True,
    default=False,
    help="Preview what would be synced without writing any files.",
)
@click.option(
    "--no-config",
    "no_config",
    is_flag=True,
    default=False,
    help="Only sync .md files; skip lightclaw.json config update.",
)
@click.option(
    "--no-md",
    "no_md",
    is_flag=True,
    default=False,
    help="Only update lightclaw.json config; skip .md file sync.",
)
def sync_openclaw_cmd(
    openclaw_json: str | None,
    dry_run: bool,
    no_config: bool,
    no_md: bool,
) -> None:
    """Sync .md files and config fields from an OpenClaw workspace.

    \b
    What gets synced
    ----------------
    - All .md files under the OpenClaw workspace directory are copied to
      ~/.lightclaw/workspace/, preserving subdirectory structure.  Existing files are
      overwritten.
    - models, channels and agents fields from openclaw.json are merged into
      lightclaw.json (openclaw values overwrite lightclaw values for the same
      keys; lightclaw-only keys are left untouched).

    \b
    Default paths
    -------------
    - openclaw.json   : ~/.openclaw/openclaw.json
    - workspace       : value of agents.defaults.workspace inside openclaw.json
    - lightclaw dir   : ~/.lightclaw/workspace/
    """
    import json as _json
    from pathlib import Path

    from ..app.sync.openclaw_sync import (
        OpenClawSyncResult,
        get_openclaw_config_path,
        get_openclaw_workspace_path,
        sync_from_openclaw,
    )
    from ..constant import WORKING_DIR

    sync_md = not no_md
    sync_config = not no_config

    # Resolve and display paths before running
    oc_json_path = get_openclaw_config_path(openclaw_json)

    click.echo()
    click.echo("Syncing from OpenClaw workspace...")
    click.echo(f"  Source config : {oc_json_path}")

    if oc_json_path.is_file():
        try:
            with open(oc_json_path, encoding="utf-8") as fh:
                oc_cfg = _json.load(fh)
            ws_path = get_openclaw_workspace_path(oc_cfg)
            click.echo(f"  Source workspace : {ws_path}")
        except Exception:
            pass
    else:
        click.echo(
            click.style(f"  WARNING: {oc_json_path} not found", fg="yellow"),
        )

    click.echo(f"  Target           : {WORKING_DIR}")
    if dry_run:
        click.echo(click.style("  [DRY RUN — no files will be written]", fg="cyan"))
    click.echo()

    result: OpenClawSyncResult = sync_from_openclaw(
        openclaw_json_path=Path(openclaw_json) if openclaw_json else None,
        sync_md=sync_md,
        sync_config=sync_config,
        dry_run=dry_run,
    )

    # --- Print results ---
    if sync_md:
        if result.md_synced > 0 or result.md_skipped == 0:
            click.echo(
                click.style(
                    f"  ✓ {result.md_synced} .md file(s) synced" + (" (dry-run)" if dry_run else ""),
                    fg="green",
                )
            )
        if result.md_skipped > 0:
            click.echo(
                click.style(
                    f"  ! {result.md_skipped} .md file(s) skipped (read errors)",
                    fg="yellow",
                )
            )

    if sync_config:
        if result.config_updated:
            fields = ", ".join(result.updated_fields) if result.updated_fields else "—"
            click.echo(
                click.style(
                    f"  ✓ lightclaw.json updated ({fields})" + (" (dry-run)" if dry_run else ""),
                    fg="green",
                )
            )
        else:
            click.echo("  · lightclaw.json — no changes")

    if result.warnings:
        click.echo()
        for w in result.warnings:
            click.echo(click.style(f"  ! {w}", fg="yellow"))

    if result.errors:
        click.echo()
        for e in result.errors:
            click.echo(click.style(f"  ✗ {e}", fg="red"))
        raise SystemExit(1)

    click.echo()
    click.echo(click.style("Done.", fg="green" if result.success else "red"))
