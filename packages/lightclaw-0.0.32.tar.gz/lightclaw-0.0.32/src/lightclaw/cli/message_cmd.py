"""CLI command: lightclaw message — send messages to channels."""

from __future__ import annotations

import json

import click
import httpx

from .http import authed_client, print_json


def _base_url(ctx: click.Context, base_url: str | None) -> str:
    """Resolve base_url with priority:
    1) command --base-url
    2) global --host/--port
    """
    if base_url:
        return base_url.rstrip("/")
    host = (ctx.obj or {}).get("host", "127.0.0.1")
    port = (ctx.obj or {}).get("port", 8088)
    return f"http://{host}:{port}"


@click.group("message")
def message_group() -> None:
    """Send and manage messages via channels.

    \b
    Common examples:
      lightclaw message send -m "hello" -c dingtalk -u alice
      lightclaw message send -m "deploy done" -c feishu -u bob
    """


@message_group.command("send")
@click.option(
    "-m",
    "--message",
    "text",
    required=True,
    help="Message text to send.",
)
@click.option(
    "-c",
    "--channel",
    required=True,
    help="Target channel: dingtalk/feishu/discord/qq.",
)
@click.option(
    "-s",
    "--session-id",
    default=None,
    help="Session ID for targeting the recipient.",
)
@click.option(
    "--meta",
    "meta_json",
    default=None,
    help="Channel-specific metadata as JSON string.",
)
@click.option(
    "--base-url",
    default=None,
    help="Override API base URL, e.g. http://127.0.0.1:8088",
)
@click.pass_context
def send_cmd(
    ctx: click.Context,
    text: str,
    channel: str,
    session_id: str | None,
    meta_json: str | None,
    base_url: str | None,
) -> None:
    """Send a text message directly to a channel (bypasses Agent).

    Requires the LightClaw service to be running with the target channel
    connected and enabled.

    \b
    Examples:
      lightclaw message send -m "hello" -c dingtalk -s "dingtalk:sw:alice"
      lightclaw message send -m "deploy done" -c feishu -s "feishu:bob:chat123"
      lightclaw message send -m "notice" -c dingtalk \\
        --meta '{"session_webhook": "https://oapi.dingtalk.com/..."}'
    """
    # Parse --meta JSON
    meta = None
    if meta_json:
        try:
            meta = json.loads(meta_json)
        except json.JSONDecodeError as exc:
            raise click.BadParameter(
                f"Invalid JSON for --meta: {exc}",
                param_hint="--meta",
            ) from exc

    url = _base_url(ctx, base_url)
    payload: dict = {"text": text}
    if session_id:
        payload["session_id"] = session_id
    if meta:
        payload["meta"] = meta

    try:
        with authed_client(url) as c:
            r = c.post(f"/channels/{channel}/send", json=payload)
            if r.status_code == 404:
                raise click.ClickException(
                    f"Channel not found or not enabled: {channel}",
                )
            r.raise_for_status()
            print_json(r.json())
    except click.ClickException:
        raise
    except httpx.ConnectError:
        raise click.ClickException(
            f"Cannot connect to LightClaw service at {url}. Is the service running? Start it with: lightclaw run"
        ) from None
    except httpx.HTTPStatusError as exc:
        raise click.ClickException(f"Server error: {exc.response.status_code} — {exc.response.text}") from exc
