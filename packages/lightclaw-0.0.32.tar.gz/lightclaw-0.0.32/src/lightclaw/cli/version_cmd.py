"""lightclaw version — display the current installed package version."""

from __future__ import annotations

import click


@click.command("version")
def version_cmd() -> None:
    """Show the installed LightClaw version."""
    try:
        from importlib.metadata import version

        ver = version("lightclaw")
    except Exception:
        ver = "unknown"
    click.echo(f"LightClaw v{ver}")
