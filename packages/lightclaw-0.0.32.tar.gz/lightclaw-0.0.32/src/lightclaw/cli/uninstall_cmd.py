"""lightclaw uninstall — remove the LightClaw environment and CLI wrapper."""

from __future__ import annotations

import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

import click

from ..constant import BASE_DIR, WORKING_DIR

# Directories created by the installer (relative to BASE_DIR).
_INSTALLER_DIRS = ("venv", "bin")

# Shell profiles to clean up.
_SHELL_PROFILES = (
    Path.home() / ".zshrc",
    Path.home() / ".bashrc",
    Path.home() / ".bash_profile",
)


_PLATFORM = sys.platform


def _remove_service() -> bool:
    """Stop and remove the LightClaw system service. Returns True if anything was done."""
    if _PLATFORM == "linux":
        return _remove_systemd_service()
    elif _PLATFORM == "darwin":
        return _remove_launchd_service()
    return False


def _remove_systemd_service() -> bool:
    import os

    is_root = os.geteuid() == 0
    unit_dir = Path("/etc/systemd/system") if is_root else Path.home() / ".config" / "systemd" / "user"
    unit_file = unit_dir / "com.lightclaw.service"
    if not unit_file.exists():
        return False

    def _systemctl(*args: str) -> list[str]:
        return ["systemctl", *args] if is_root else ["systemctl", "--user", *args]

    subprocess.run(_systemctl("stop", "com.lightclaw"), check=False, capture_output=True)
    subprocess.run(_systemctl("disable", "com.lightclaw"), check=False, capture_output=True)
    unit_file.unlink()
    subprocess.run(_systemctl("daemon-reload"), check=False, capture_output=True)
    click.echo(f"  Removed systemd unit: {unit_file}")
    return True


def _remove_launchd_service() -> bool:
    plist = Path.home() / "Library" / "LaunchAgents" / "com.lightclaw.service.plist"
    if not plist.exists():
        return False

    subprocess.run(["launchctl", "unload", str(plist)], check=False, capture_output=True)
    plist.unlink()
    click.echo(f"  Removed launchd plist: {plist}")
    return True


def _remove_path_entry(profile: Path) -> bool:
    """
    Remove LightClaw PATH lines from a shell profile. Returns True if changed.
    """
    if not profile.is_file():
        return False

    text = profile.read_text()
    # Remove the "# LightClaw" comment line and the export PATH line
    cleaned = re.sub(
        r"\n?# LightClaw\nexport PATH=\"\$HOME/\.lightclaw/bin:\$PATH\"\n?",
        "\n",
        text,
    )
    if cleaned == text:
        return False

    profile.write_text(cleaned)
    return True


def _reset_setup_done() -> bool:
    """Reset setup_done in auth.json so the setup wizard triggers on next install."""
    auth_file = BASE_DIR / "auth.json"
    if not auth_file.is_file():
        return False
    try:
        data = json.loads(auth_file.read_text(encoding="utf-8"))
        if data.get("setup_done") is True:
            data["setup_done"] = False
            auth_file.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
            return True
    except (json.JSONDecodeError, OSError):
        pass
    return False


@click.command("uninstall")
@click.option(
    "--purge",
    is_flag=True,
    help="Also remove all data (config, chats, models, etc.)",
)
@click.option(
    "--remove-workspace",
    is_flag=True,
    help="Also remove the workspace directory (~/.lightclaw/workspace)",
)
@click.option("--yes", is_flag=True, help="Do not prompt for confirmation")
def uninstall_cmd(purge: bool, remove_workspace: bool, yes: bool) -> None:
    """Remove LightClaw environment, CLI wrapper, and shell PATH entries."""
    wd = BASE_DIR

    if purge:
        click.echo(f"This will remove ALL LightClaw data in {wd}")
    elif remove_workspace:
        click.echo(
            "This will remove the LightClaw Python environment, CLI wrapper, and workspace.",
        )
        click.echo(f"Your configuration in {wd} will be preserved.")
    else:
        click.echo(
            "This will remove the LightClaw Python environment and CLI wrapper.",
        )
        click.echo(f"Your configuration and workspace in {wd} will be preserved.")

    if not yes:
        ok = click.confirm("Continue?", default=False)
        if not ok:
            click.echo("Cancelled.")
            return

    # Stop and remove system service
    _remove_service()

    # Remove installer-managed directories
    for dirname in _INSTALLER_DIRS:
        d = wd / dirname
        if d.exists():
            shutil.rmtree(d)
            click.echo(f"  Removed {d}")

    # Remove workspace only if explicitly requested or purging
    if (remove_workspace or purge) and WORKING_DIR.exists():
        shutil.rmtree(WORKING_DIR)
        click.echo(f"  Removed {WORKING_DIR}")

    # Reset setup wizard flag so it triggers on next install
    if not purge and _reset_setup_done():
        click.echo("  Reset setup wizard flag in auth.json")

    # Purge everything if requested
    if purge and wd.exists():
        shutil.rmtree(wd)
        click.echo(f"  Removed {wd}")

    # Clean shell profiles
    for profile in _SHELL_PROFILES:
        if _remove_path_entry(profile):
            click.echo(f"  Cleaned {profile}")

    click.echo("")
    click.echo("LightClaw uninstalled. Please restart your terminal.")
