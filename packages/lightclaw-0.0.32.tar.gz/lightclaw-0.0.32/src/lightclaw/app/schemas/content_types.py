"""Content type definitions — pure Pydantic models.

Drop-in replacements for ``agentscope_runtime.engine.schemas.agent_schemas``
content classes (TextContent, ImageContent, …).  The field names, defaults,
and serialization output are kept **identical** so that Channel / Renderer
code continues to work without change.

No dependency on agentscope or langchain.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel

# ---------------------------------------------------------------------------
# ContentType — mirrors runtime ContentType (plain class with string attrs)
# ---------------------------------------------------------------------------


class ContentType:
    """Content type constants.  Mirrors ``agentscope_runtime`` ContentType."""

    TEXT: str = "text"
    IMAGE: str = "image"
    VIDEO: str = "video"
    AUDIO: str = "audio"
    FILE: str = "file"
    DATA: str = "data"
    REFUSAL: str = "refusal"


# ---------------------------------------------------------------------------
# Base for all content models
# ---------------------------------------------------------------------------


class _ContentBase(BaseModel):
    """Shared base fields present on every runtime Content object."""

    sequence_number: int | None = None
    object: str = "content"
    status: str | None = None
    error: Any | None = None
    type: str
    index: int | None = None
    delta: bool = False
    msg_id: str | None = None

    model_config = {"extra": "allow"}


# ---------------------------------------------------------------------------
# Concrete content types
# ---------------------------------------------------------------------------


class TextContent(_ContentBase):
    """Text content block."""

    type: str = ContentType.TEXT
    text: str = ""


class ImageContent(_ContentBase):
    """Image content block."""

    type: str = ContentType.IMAGE
    image_url: str = ""


class VideoContent(_ContentBase):
    """Video content block."""

    type: str = ContentType.VIDEO
    video_url: str = ""


class AudioContent(_ContentBase):
    """Audio content block."""

    type: str = ContentType.AUDIO
    data: str | None = None
    format: str | None = None


class FileContent(_ContentBase):
    """File content block."""

    type: str = ContentType.FILE
    file_url: str | None = None
    file_id: str | None = None
    filename: str | None = None
    file_data: str | None = None


class RefusalContent(_ContentBase):
    """Refusal content block."""

    type: str = ContentType.REFUSAL
    refusal: str = ""


class DataContent(_ContentBase):
    """Arbitrary data content block (tool call args / tool output)."""

    type: str = ContentType.DATA
    data: Any | None = None


# ---------------------------------------------------------------------------
# Helper models used inside runner/utils.py  (FunctionCall, FunctionCallOutput)
# ---------------------------------------------------------------------------


class FunctionCall(BaseModel):
    """Tool/function call descriptor."""

    call_id: str | None = None
    name: str | None = None
    arguments: str | None = None

    model_config = {"extra": "allow"}


class FunctionCallOutput(BaseModel):
    """Tool/function call output descriptor."""

    call_id: str | None = None
    name: str | None = None
    output: str | None = None

    model_config = {"extra": "allow"}
