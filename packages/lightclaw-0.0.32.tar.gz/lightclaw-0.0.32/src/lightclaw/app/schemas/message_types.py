"""Message / request level types — pure Pydantic models.

Drop-in replacements for ``agentscope_runtime.engine.schemas.agent_schemas``
message-level classes (MessageType, RunStatus, Role, Message, AgentRequest).

No dependency on agentscope or langchain.
"""

from __future__ import annotations

from typing import Any
from uuid import uuid4

from pydantic import BaseModel, Field

# ---------------------------------------------------------------------------
# Enums as plain classes (matches runtime pattern)
# ---------------------------------------------------------------------------


class RunStatus:
    """Run status constants.  Attribute names use PascalCase to match runtime."""

    Created: str = "created"
    InProgress: str = "in_progress"
    Completed: str = "completed"
    Failed: str = "failed"
    Canceled: str = "canceled"
    Incomplete: str = "incomplete"
    Queued: str = "queued"
    Rejected: str = "rejected"
    Unknown: str = "unknown"


class MessageType:
    """Message type constants.  Matches runtime MessageType attributes."""

    MESSAGE: str = "message"
    REASONING: str = "reasoning"
    PLUGIN_CALL: str = "plugin_call"
    PLUGIN_CALL_OUTPUT: str = "plugin_call_output"
    FUNCTION_CALL: str = "function_call"
    FUNCTION_CALL_OUTPUT: str = "function_call_output"
    MCP_TOOL_CALL: str = "mcp_tool_call"
    MCP_TOOL_CALL_OUTPUT: str = "mcp_tool_call_output"
    MCP_APPROVAL_REQUEST: str = "mcp_approval_request"
    MCP_APPROVAL_RESPONSE: str = "mcp_approval_response"
    MCP_LIST_TOOLS: str = "mcp_list_tools"
    HEARTBEAT: str = "heartbeat"
    ERROR: str = "error"
    COMPONENT_CALL: str = "component_call"
    COMPONENT_CALL_OUTPUT: str = "component_call_output"
    A2UI_ACTION: str = "a2ui_action"
    A2UI_RESPONSE: str = "a2ui_response"


class Role:
    """Message role constants."""

    USER: str = "user"
    ASSISTANT: str = "assistant"
    SYSTEM: str = "system"


# ---------------------------------------------------------------------------
# Message — one message in the conversation
# ---------------------------------------------------------------------------


class Message(BaseModel):
    """Single message in a conversation.

    Mirrors ``agentscope_runtime.engine.schemas.agent_schemas.Message``.
    """

    sequence_number: int | None = None
    object: str = "message"
    status: str | None = None
    error: Any | None = None
    id: str = Field(default_factory=lambda: str(uuid4()))
    type: str = MessageType.MESSAGE
    role: str = Role.ASSISTANT
    content: list[Any] = Field(default_factory=list)
    code: Any | None = None
    message: str | None = None
    usage: Any | None = None
    metadata: Any | None = None

    model_config = {"extra": "allow"}

    def get_text_content(self) -> str:
        """Extract plain text from content blocks.

        Compatible with the old ``agentscope.message.Msg.get_text_content()``
        API so that call-sites can work with both ``Msg`` and ``Message``.
        """
        if isinstance(self.content, str):
            return self.content
        parts: list[str] = []
        for block in self.content:
            if isinstance(block, str):
                parts.append(block)
            elif isinstance(block, dict) and block.get("type") == "text":
                parts.append(block.get("text", ""))
            elif getattr(block, "type", None) == "text" and hasattr(block, "text"):
                parts.append(block.text or "")
        return "".join(parts)


# ---------------------------------------------------------------------------
# AgentRequest — the input to /api/agent/process
# ---------------------------------------------------------------------------


class AgentRequest(BaseModel):
    """Request payload for the agent process endpoint.

    Mirrors ``agentscope_runtime.engine.schemas.agent_schemas.AgentRequest``.
    """

    input: list[Message] = Field(default_factory=list)
    stream: bool = True
    id: str | None = None
    model: str | None = None
    top_p: float | None = None
    temperature: float | None = None
    frequency_penalty: float | None = None
    presence_penalty: float | None = None
    max_tokens: int | None = None
    stop: Any | None = None
    n: int | None = None
    seed: int | None = None
    tools: Any | None = None
    session_id: str = ""
    user_id: str = ""

    # Extra fields used by channels (channel, channel_meta, etc.)
    model_config = {"extra": "allow"}
