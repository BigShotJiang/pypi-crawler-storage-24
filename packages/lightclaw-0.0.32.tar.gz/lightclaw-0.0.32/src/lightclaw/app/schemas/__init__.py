"""LightClaw internal message/event schemas.

Pure data classes with no dependency on agentscope or langchain.
Provides drop-in replacements for agentscope_runtime.engine.schemas.agent_schemas
types used throughout the Channel and Runner layers.
"""

from .content_types import (
    AudioContent,
    ContentType,
    DataContent,
    FileContent,
    FunctionCall,
    FunctionCallOutput,
    ImageContent,
    RefusalContent,
    TextContent,
    VideoContent,
)
from .events import (
    ContentEvent,
    MessageEvent,
    MessageEventMetadata,
    ResponseEvent,
    ResponseEventMetadata,
    SequenceCounter,
)
from .message_types import (
    AgentRequest,
    Message,
    MessageType,
    Role,
    RunStatus,
)

__all__ = [
    "AgentRequest",
    "AudioContent",
    "ContentEvent",
    # Content
    "ContentType",
    "DataContent",
    "FileContent",
    "FunctionCall",
    "FunctionCallOutput",
    "ImageContent",
    "Message",
    "MessageEvent",
    "MessageEventMetadata",
    # Message
    "MessageType",
    "RefusalContent",
    # Events (SSE)
    "ResponseEvent",
    "ResponseEventMetadata",
    "Role",
    "RunStatus",
    "SequenceCounter",
    "TextContent",
    "VideoContent",
]
