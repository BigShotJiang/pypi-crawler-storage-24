"""Adapters between external schemas and LightClaw internal schemas.

Conversion direction:
  external → internal  (``runtime_content_to_internal``, ``runtime_message_to_internal``)

These convert duck-typed objects (e.g. from old session files or external
sources) into LightClaw internal Pydantic models.  The internal → runtime
direction has been removed as of PR9 (agentscope_runtime dependency eliminated).
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .message_types import Message


# ---------------------------------------------------------------------------
# external → internal
# ---------------------------------------------------------------------------


def runtime_content_to_internal(rc: Any) -> Any:
    """Convert one external content object to an internal content object.

    Uses duck-typing on ``rc.type`` to determine the content kind, then
    copies the relevant fields into the internal Pydantic model.

    Returns the original object unchanged if conversion is not needed
    (e.g. already an internal type or a plain dict).
    """
    from .content_types import (
        AudioContent,
        ContentType,
        DataContent,
        FileContent,
        ImageContent,
        RefusalContent,
        TextContent,
        VideoContent,
    )

    # Already an internal type or plain dict — pass through
    mod = type(rc).__module__
    if mod.startswith("lightclaw.") or isinstance(rc, dict):
        return rc

    ctype = getattr(rc, "type", None)

    if ctype == ContentType.TEXT:
        return TextContent(
            text=getattr(rc, "text", "") or "",
            delta=getattr(rc, "delta", False),
            sequence_number=getattr(rc, "sequence_number", None),
            status=getattr(rc, "status", None),
            msg_id=getattr(rc, "msg_id", None),
        )

    if ctype == ContentType.IMAGE:
        return ImageContent(
            image_url=getattr(rc, "image_url", "") or "",
            delta=getattr(rc, "delta", False),
            sequence_number=getattr(rc, "sequence_number", None),
            status=getattr(rc, "status", None),
        )

    if ctype == ContentType.VIDEO:
        return VideoContent(
            video_url=getattr(rc, "video_url", "") or "",
            delta=getattr(rc, "delta", False),
            sequence_number=getattr(rc, "sequence_number", None),
            status=getattr(rc, "status", None),
        )

    if ctype == ContentType.AUDIO:
        return AudioContent(
            data=getattr(rc, "data", None),
            format=getattr(rc, "format", None),
            delta=getattr(rc, "delta", False),
            sequence_number=getattr(rc, "sequence_number", None),
            status=getattr(rc, "status", None),
        )

    if ctype == ContentType.FILE:
        return FileContent(
            file_url=getattr(rc, "file_url", None),
            file_id=getattr(rc, "file_id", None),
            filename=getattr(rc, "filename", None),
            file_data=getattr(rc, "file_data", None),
            delta=getattr(rc, "delta", False),
            sequence_number=getattr(rc, "sequence_number", None),
            status=getattr(rc, "status", None),
        )

    if ctype == ContentType.REFUSAL:
        return RefusalContent(
            refusal=getattr(rc, "refusal", "") or "",
            delta=getattr(rc, "delta", False),
            sequence_number=getattr(rc, "sequence_number", None),
            status=getattr(rc, "status", None),
        )

    if ctype == ContentType.DATA:
        return DataContent(
            data=getattr(rc, "data", None),
            delta=getattr(rc, "delta", False),
            sequence_number=getattr(rc, "sequence_number", None),
            status=getattr(rc, "status", None),
        )

    # Unknown type — return as-is
    return rc


def runtime_message_to_internal(rm: Any) -> Message:
    """Convert an external Message to an internal Message."""
    from .message_types import Message

    return Message(
        sequence_number=getattr(rm, "sequence_number", None),
        object=getattr(rm, "object", "message"),
        status=getattr(rm, "status", None),
        error=getattr(rm, "error", None),
        id=getattr(rm, "id", ""),
        type=getattr(rm, "type", "message"),
        role=getattr(rm, "role", "assistant"),
        content=[runtime_content_to_internal(c) for c in (getattr(rm, "content", None) or [])],
        code=getattr(rm, "code", None),
        message=getattr(rm, "message", None),
        usage=getattr(rm, "usage", None),
        metadata=getattr(rm, "metadata", None),
    )
