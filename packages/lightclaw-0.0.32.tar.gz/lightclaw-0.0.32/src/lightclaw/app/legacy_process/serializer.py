"""Legacy process SSE protocol serialization helpers."""

from __future__ import annotations

import json
from typing import Any

from pydantic import BaseModel

PROCESS_PROTOCOL_V2 = "v2"
DEFAULT_PROCESS_PROTOCOL_VERSION = PROCESS_PROTOCOL_V2


def _to_json_payload(event: BaseModel) -> dict[str, Any]:
    payload = event.model_dump(mode="json")
    if not isinstance(payload, dict):
        raise TypeError("Process event payload must serialize to a dict")
    return payload


def process_event_to_payload(event: BaseModel) -> dict[str, Any]:
    """Convert one internal event to the legacy wire payload."""
    return _to_json_payload(event)


def serialize_process_event(event: BaseModel) -> str:
    """Serialize one process event to the legacy wire protocol."""
    payload = process_event_to_payload(event)
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))


__all__ = [
    "DEFAULT_PROCESS_PROTOCOL_VERSION",
    "PROCESS_PROTOCOL_V2",
    "process_event_to_payload",
    "serialize_process_event",
]
