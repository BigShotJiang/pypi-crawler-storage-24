"""Boundary adapters between turn protocol and legacy process protocol."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from ..turn_protocol import TurnInput, TurnRequest
from .schemas import (
    AgentRequest,
    Message,
)
from .serializer import (
    serialize_process_event,
)


def _normalize_turn_input_content(content: Any) -> list[Any]:
    if isinstance(content, str):
        return [{"type": "text", "text": content}]
    if isinstance(content, list):
        return content
    if content is None:
        return []
    return [content]


def turn_request_to_legacy_agent_request(request: TurnRequest) -> AgentRequest:
    """Convert a canonical turn request into the legacy process request DTO."""
    payload: dict[str, Any] = {
        "input": [
            Message(
                role=item.role,
                content=_normalize_turn_input_content(item.content),
                metadata=item.metadata,
            )
            for item in request.inputs
        ],
        "stream": request.stream,
        "model": request.model,
        "top_p": request.top_p,
        "temperature": request.temperature,
        "frequency_penalty": request.frequency_penalty,
        "presence_penalty": request.presence_penalty,
        "max_tokens": request.max_tokens,
        "stop": request.stop,
        "n": request.n,
        "seed": request.seed,
        "tools": request.tools,
        "session_id": request.session_id,
        "user_id": request.user_id,
    }
    if request.channel:
        payload["channel"] = request.channel

    if isinstance(request.context, dict):
        for key, value in request.context.items():
            payload.setdefault(key, value)

    extras = request.model_dump(
        exclude_none=True,
        exclude={
            "turn_id",
            "inputs",
            "stream",
            "session_id",
            "user_id",
            "channel",
            "model",
            "top_p",
            "temperature",
            "frequency_penalty",
            "presence_penalty",
            "max_tokens",
            "stop",
            "n",
            "seed",
            "tools",
            "context",
            "delivery",
        },
    )
    for key, value in extras.items():
        payload.setdefault(key, value)

    return AgentRequest(**payload)


def legacy_agent_request_to_turn_request(request: AgentRequest) -> TurnRequest:
    """Convert a legacy process request DTO into a canonical turn request."""
    payload = request.model_dump(exclude_none=True)
    turn_payload: dict[str, Any] = {
        "inputs": [
            TurnInput(
                role=message.role,
                content=list(message.content or []),
                metadata=(message.metadata if isinstance(message.metadata, dict) else None),
            )
            for message in request.input
        ],
        "stream": request.stream,
        "session_id": request.session_id,
        "user_id": request.user_id,
        "channel": payload.get("channel", ""),
        "model": request.model,
        "top_p": request.top_p,
        "temperature": request.temperature,
        "frequency_penalty": request.frequency_penalty,
        "presence_penalty": request.presence_penalty,
        "max_tokens": request.max_tokens,
        "stop": request.stop,
        "n": request.n,
        "seed": request.seed,
        "tools": request.tools,
    }
    extras = {
        key: value
        for key, value in payload.items()
        if key
        not in {
            "input",
            "stream",
            "id",
            "model",
            "top_p",
            "temperature",
            "frequency_penalty",
            "presence_penalty",
            "max_tokens",
            "stop",
            "n",
            "seed",
            "tools",
            "protocol_version",
            "session_id",
            "user_id",
            "channel",
        }
    }
    if extras:
        turn_payload["context"] = extras
    return TurnRequest(**turn_payload)


def parse_legacy_process_request(body: Mapping[str, Any]) -> AgentRequest:
    """Parse one legacy request payload."""
    return AgentRequest(**dict(body))


def serialize_legacy_sse_event(event: Any) -> str:
    """Serialize one event for the legacy ``/api/agent/process`` wire."""
    return serialize_process_event(event)


# LegacyToTurnEventAdapter 已删除（无调用方）
# TurnToLegacyProcessAdapter 已删除（/api/agent/process 端点已升级为直接输出 TurnEvent）


__all__ = [
    "legacy_agent_request_to_turn_request",
    "parse_legacy_process_request",
    "serialize_legacy_sse_event",
    "turn_request_to_legacy_agent_request",
]
