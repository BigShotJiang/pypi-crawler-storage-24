"""Helpers for stored uploads, signed access URLs, and file metadata."""

from __future__ import annotations

import hashlib
import hmac
import json
import mimetypes
import shutil
import time
import urllib.parse
import uuid
from pathlib import Path
from typing import Any

from ..constant import UPLOADS_DIR
from .core import auth as auth_mod

DEFAULT_ACCESS_URL_TTL_SECONDS = 24 * 60 * 60


def _meta_dir() -> Path:
    return UPLOADS_DIR / ".meta"


def _derived_dir() -> Path:
    return UPLOADS_DIR / ".derived"


def validate_file_id(file_id: str) -> str:
    """Validate and normalize a stored upload file id."""
    candidate = urllib.parse.unquote((file_id or "").strip())
    if not candidate or "/" in candidate or "\\" in candidate or candidate in {".", ".."}:
        raise ValueError("Invalid file id")
    return candidate


def resolve_file_id_from_url(url: str | None) -> str | None:
    """Extract a stable file id from a local ``/api/files/...`` URL."""
    if not url:
        return None
    parsed = urllib.parse.urlparse(url)
    path = parsed.path or ""
    if not path.startswith("/api/files/"):
        return None
    raw = path.split("/api/files/", 1)[-1]
    try:
        return validate_file_id(raw)
    except ValueError:
        return None


def resolve_upload_path(file_id: str) -> Path:
    """Resolve an upload path and ensure it stays under ``UPLOADS_DIR``."""
    normalized = validate_file_id(file_id)
    target = (UPLOADS_DIR / normalized).resolve()
    root = UPLOADS_DIR.resolve()
    if target.parent != root:
        raise ValueError("Invalid file id")
    return target


def _meta_path(file_id: str) -> Path:
    return _meta_dir() / f"{validate_file_id(file_id)}.json"


def derived_text_path(file_id: str) -> Path:
    return _derived_dir() / f"{validate_file_id(file_id)}.md"


def _write_metadata(file_id: str, metadata: dict[str, Any]) -> None:
    _meta_dir().mkdir(parents=True, exist_ok=True)
    path = _meta_path(file_id)
    tmp_path = path.with_suffix(".tmp")
    with open(tmp_path, "w", encoding="utf-8") as fh:
        json.dump(metadata, fh, ensure_ascii=False, indent=2)
    tmp_path.replace(path)


def _infer_media_type(path: Path, default: str = "application/octet-stream") -> str:
    return mimetypes.guess_type(str(path))[0] or default


def ensure_file_metadata(
    file_id: str,
    *,
    filename: str | None = None,
    media_type: str | None = None,
) -> dict[str, Any] | None:
    """Load or create metadata for an already-stored file."""
    try:
        normalized = validate_file_id(file_id)
        path = resolve_upload_path(normalized)
    except ValueError:
        return None

    if not path.is_file():
        return None

    meta_path = _meta_path(normalized)
    if meta_path.is_file():
        try:
            with open(meta_path, encoding="utf-8") as fh:
                metadata = json.load(fh)
        except Exception:
            metadata = {}
    else:
        metadata = {}

    stat = path.stat()
    metadata.update(
        {
            "file_id": normalized,
            "stored_name": normalized,
            "filename": filename or metadata.get("filename") or path.name,
            "media_type": media_type or metadata.get("media_type") or _infer_media_type(path),
            "size": stat.st_size,
            "created_at": metadata.get("created_at") or int(stat.st_mtime),
        }
    )
    _write_metadata(normalized, metadata)
    return metadata


def update_file_parse_metadata(
    file_id: str,
    parse_metadata: dict[str, Any],
) -> dict[str, Any] | None:
    """Persist document parse metadata for a stored file."""
    metadata = ensure_file_metadata(file_id)
    if metadata is None:
        return None
    metadata["parse"] = dict(parse_metadata)
    _write_metadata(file_id, metadata)
    return metadata


def get_file_metadata(file_id: str) -> dict[str, Any] | None:
    """Return stored file metadata, inferring it for legacy files when needed."""
    try:
        normalized = validate_file_id(file_id)
    except ValueError:
        return None
    meta_path = _meta_path(normalized)
    if meta_path.is_file():
        try:
            with open(meta_path, encoding="utf-8") as fh:
                return json.load(fh)
        except Exception:
            return ensure_file_metadata(normalized)
    return ensure_file_metadata(normalized)


def _extension_for_media_type(media_type: str, fallback_name: str = "") -> str:
    ext = Path(fallback_name or "").suffix.lower()
    if ext:
        return ext
    guessed = mimetypes.guess_extension(media_type or "")
    return (guessed or "").lower()


def store_uploaded_bytes(
    data: bytes,
    *,
    filename: str,
    media_type: str,
) -> dict[str, Any]:
    """Store uploaded bytes in ``UPLOADS_DIR`` and write metadata."""
    ext = _extension_for_media_type(media_type, filename)
    file_id = f"{uuid.uuid4().hex}{ext}"
    UPLOADS_DIR.mkdir(parents=True, exist_ok=True)
    path = resolve_upload_path(file_id)
    path.write_bytes(data)
    metadata = ensure_file_metadata(
        file_id,
        filename=filename or file_id,
        media_type=media_type,
    )
    if metadata is None:
        raise RuntimeError("Failed to persist uploaded file metadata")
    return metadata


def store_local_file(
    file_path: str,
    *,
    filename: str | None = None,
    media_type: str | None = None,
) -> dict[str, Any]:
    """Copy a local file into ``UPLOADS_DIR`` and register metadata."""
    source = Path(file_path).expanduser().resolve()
    if not source.is_file():
        raise FileNotFoundError(file_path)

    resolved_media_type = media_type or _infer_media_type(source)
    ext = _extension_for_media_type(resolved_media_type, source.name)
    file_id = f"{uuid.uuid4().hex}{ext}"
    UPLOADS_DIR.mkdir(parents=True, exist_ok=True)
    target = resolve_upload_path(file_id)
    shutil.copy2(source, target)
    metadata = ensure_file_metadata(
        file_id,
        filename=filename or source.name,
        media_type=resolved_media_type,
    )
    if metadata is None:
        raise RuntimeError("Failed to persist copied file metadata")
    return metadata


def build_canonical_file_url(file_id: str) -> str:
    return f"/api/files/{urllib.parse.quote(validate_file_id(file_id))}"


def _build_access_signature(file_id: str, exp: int) -> str:
    auth = auth_mod._read_auth()
    secret = auth_mod._ensure_jwt_secret(auth)
    msg = f"{validate_file_id(file_id)}:{int(exp)}".encode()
    return hmac.new(secret.encode("utf-8"), msg, hashlib.sha256).hexdigest()


def build_access_url(
    file_id: str,
    *,
    ttl_seconds: int = DEFAULT_ACCESS_URL_TTL_SECONDS,
    now: int | None = None,
) -> str:
    """Return a browser-safe access URL for a stored file."""
    normalized = validate_file_id(file_id)
    base = build_canonical_file_url(normalized)
    auth = auth_mod._read_auth()
    if not auth.enabled:
        return base

    now_ts = int(now if now is not None else time.time())
    exp = now_ts + max(1, int(ttl_seconds))
    sig = _build_access_signature(normalized, exp)
    return f"{base}?exp={exp}&sig={sig}"


def verify_signed_access(file_id: str, exp: int | str | None, sig: str | None) -> bool:
    """Validate signed access for a stored file."""
    if exp is None or not sig:
        return False
    try:
        exp_int = int(exp)
    except (TypeError, ValueError):
        return False
    if exp_int < int(time.time()):
        return False
    expected = _build_access_signature(file_id, exp_int)
    return hmac.compare_digest(expected, str(sig))


def is_bearer_token_valid(token: str | None) -> bool:
    """Validate a bearer token against the current auth secret."""
    auth = auth_mod._read_auth()
    if not auth.enabled:
        return True
    if not token:
        return False
    try:
        auth_mod._jwt_decode(token, auth_mod._ensure_jwt_secret(auth))
        return True
    except ValueError:
        return False


def file_payload(
    metadata: dict[str, Any],
    *,
    ttl_seconds: int = DEFAULT_ACCESS_URL_TTL_SECONDS,
) -> dict[str, Any]:
    """Return API payload fields for a stored file."""
    file_id = validate_file_id(str(metadata.get("file_id") or ""))
    access_url = build_access_url(file_id, ttl_seconds=ttl_seconds)
    return {
        "file_id": file_id,
        "url": access_url,
        "access_url": access_url,
        "filename": str(metadata.get("filename") or file_id),
        "media_type": str(metadata.get("media_type") or "application/octet-stream"),
    }


def _iter_message_blocks(messages: Any):
    if not isinstance(messages, list):
        messages = [messages]

    for message in messages:
        content = getattr(message, "content", None)
        if content is None and isinstance(message, dict):
            content = message.get("content")
        if not isinstance(content, list):
            continue
        for block in content:
            if isinstance(block, dict):
                yield block


def refresh_message_file_urls(messages: Any) -> None:
    """Refresh signed preview URLs for file/image blocks in-place."""
    for block in _iter_message_blocks(messages):
        block_type = str(block.get("type") or "")
        if block_type not in {"image", "file"}:
            continue

        candidate_urls = [
            block.get("preview_url"),
            block.get("image_url"),
            block.get("file_url"),
            block.get("url"),
        ]
        source = block.get("source")
        if isinstance(source, dict):
            candidate_urls.append(source.get("url"))
        elif isinstance(source, str):
            candidate_urls.append(source)

        file_id = block.get("file_id")
        if not isinstance(file_id, str) or not file_id:
            for candidate in candidate_urls:
                if isinstance(candidate, str):
                    file_id = resolve_file_id_from_url(candidate)
                    if file_id:
                        break
        if not isinstance(file_id, str) or not file_id:
            continue
        if not resolve_upload_path(file_id).is_file():
            continue

        block["file_id"] = file_id
        access_url = build_access_url(file_id)
        block["preview_url"] = access_url
        if block_type == "image":
            block["image_url"] = access_url
        else:
            block["file_url"] = access_url

        metadata = get_file_metadata(file_id)
        if metadata:
            block.setdefault("filename", metadata.get("filename"))
            media_type = metadata.get("media_type")
            if media_type:
                block.setdefault("media_type", media_type)
                if isinstance(source, dict) and source.get("type") == "url":
                    source.setdefault("media_type", media_type)
