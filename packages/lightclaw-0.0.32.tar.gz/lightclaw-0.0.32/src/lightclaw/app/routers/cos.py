"""Tencent Cloud COS integration — browse buckets, list objects, upload & download.

Upload: server-side file (from WORKING_DIR) → COS.
Download: COS object → server-side file (into WORKING_DIR).
"""

from __future__ import annotations

import contextlib
import logging
import os
import tempfile
from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from ...constant import WORKING_DIR

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/cos", tags=["cos"])

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_cos_credentials() -> tuple[str, str]:
    """Read COS credentials from environment, raise 422 if missing."""
    secret_id = os.environ.get("TENCENT_CLOUD_SECRET_ID", "").strip()
    secret_key = os.environ.get("TENCENT_CLOUD_SECRET_KEY", "").strip()
    if not secret_id or not secret_key:
        raise HTTPException(
            status_code=422,
            detail=(
                "Tencent Cloud credentials not configured. "
                "Please set TENCENT_CLOUD_SECRET_ID and TENCENT_CLOUD_SECRET_KEY "
                "in the environment variables page."
            ),
        )
    return secret_id, secret_key


def _make_client(region: str = "ap-guangzhou") -> Any:
    """Create a COS client for the given region.

    Returns a ``CosS3Client`` instance.  Created per-request so that
    credential changes are picked up immediately.
    """
    try:
        from qcloud_cos import CosConfig, CosS3Client  # type: ignore[import-untyped]
    except ImportError as exc:
        raise HTTPException(
            status_code=500,
            detail="cos-python-sdk-v5 is not installed. Run: pip install cos-python-sdk-v5",
        ) from exc

    secret_id, secret_key = _get_cos_credentials()
    config = CosConfig(
        Region=region,
        SecretId=secret_id,
        SecretKey=secret_key,
    )
    return CosS3Client(config)


def _resolve_working_path(relative_path: str) -> Path:
    """Resolve a relative path within WORKING_DIR with traversal protection."""
    target = (WORKING_DIR / relative_path).resolve()
    if not str(target).startswith(str(WORKING_DIR.resolve())):
        raise HTTPException(status_code=400, detail="Invalid path: traversal detected")
    return target


# ---------------------------------------------------------------------------
# Response / request models
# ---------------------------------------------------------------------------


class BucketInfo(BaseModel):
    """Single bucket metadata."""

    name: str = Field(..., description="Bucket name")
    region: str = Field(..., description="Bucket region, e.g. ap-guangzhou")
    creation_date: str = Field("", description="ISO creation date string")


class ListBucketsResponse(BaseModel):
    """Response for listing all buckets."""

    buckets: list[BucketInfo] = Field(default_factory=list)


class ObjectInfo(BaseModel):
    """Single object (file or prefix) metadata."""

    key: str = Field(..., description="Full object key")
    size: int = Field(0, description="Object size in bytes")
    last_modified: str = Field("", description="Last modified ISO string")
    is_dir: bool = Field(False, description="True if this is a common-prefix (directory)")


class ListObjectsResponse(BaseModel):
    """Response for listing objects in a bucket."""

    objects: list[ObjectInfo] = Field(default_factory=list)
    is_truncated: bool = Field(False, description="Whether there are more objects")
    next_marker: str = Field("", description="Marker for next page")


class UploadRequest(BaseModel):
    """Request body for uploading a server file to COS."""

    server_path: str = Field(..., description="Relative path within WORKING_DIR")
    bucket: str = Field(..., description="Target bucket name")
    region: str = Field(..., description="Bucket region")
    cos_key: str = Field("", description="Object key in COS (defaults to filename)")


class UploadCosResponse(BaseModel):
    """Response after uploading a file to COS."""

    key: str = Field(..., description="Object key in COS")
    etag: str = Field("", description="ETag returned by COS")


class DownloadRequest(BaseModel):
    """Request body for downloading a COS object to server."""

    bucket: str = Field(..., description="Source bucket name")
    region: str = Field(..., description="Bucket region")
    cos_key: str = Field(..., description="Object key in COS")
    server_path: str = Field(
        "",
        description="Relative directory path within WORKING_DIR to save to (defaults to root)",
    )


class DownloadCosResponse(BaseModel):
    """Response after downloading a COS object to the server."""

    server_path: str = Field(..., description="Relative path of saved file in WORKING_DIR")
    size: int = Field(0, description="Downloaded file size in bytes")


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


class CosStatusResponse(BaseModel):
    """Response for COS configuration status check."""

    configured: bool = Field(..., description="Whether COS credentials are configured and valid")


@router.get("/status", response_model=CosStatusResponse, summary="Check if COS credentials are configured and valid")
async def cos_status() -> CosStatusResponse:
    """Check whether COS credentials are set AND valid.

    1. If TENCENT_CLOUD_SECRET_ID / TENCENT_CLOUD_SECRET_KEY are empty → ``configured=false``.
    2. Otherwise, call ``list_buckets`` to verify the credentials are accepted
       by the COS API.  A failed call (bad key, network error, etc.) also
       yields ``configured=false`` so the frontend hides the button.
    """
    secret_id = os.environ.get("TENCENT_CLOUD_SECRET_ID", "").strip()
    secret_key = os.environ.get("TENCENT_CLOUD_SECRET_KEY", "").strip()

    if not secret_id or not secret_key:
        return CosStatusResponse(configured=False)

    # Credentials are present — verify them with a real API call.
    try:
        client = _make_client()
        client.list_buckets()
    except Exception:
        logger.debug("COS credential validation failed", exc_info=True)
        return CosStatusResponse(configured=False)

    return CosStatusResponse(configured=True)


@router.get("/buckets", response_model=ListBucketsResponse, summary="List all COS buckets")
async def list_buckets() -> ListBucketsResponse:
    """Return all COS buckets owned by the account."""
    client = _make_client()
    try:
        resp = client.list_buckets()
    except Exception as exc:
        logger.exception("Failed to list COS buckets")
        raise HTTPException(status_code=502, detail=f"COS API error: {exc}") from exc

    buckets: list[BucketInfo] = []
    for b in resp.get("Buckets", {}).get("Bucket", []):
        buckets.append(
            BucketInfo(
                name=b.get("Name", ""),
                region=b.get("Location", ""),
                creation_date=b.get("CreationDate", ""),
            )
        )
    return ListBucketsResponse(buckets=buckets)


@router.get("/objects", response_model=ListObjectsResponse, summary="List objects in a bucket")
async def list_objects(
    bucket: str,
    region: str,
    prefix: str = "",
    marker: str = "",
    max_keys: int = 100,
) -> ListObjectsResponse:
    """List objects (files and directories) under a given prefix."""
    client = _make_client(region)
    try:
        resp = client.list_objects(
            Bucket=bucket,
            Prefix=prefix,
            Delimiter="/",
            Marker=marker,
            MaxKeys=max_keys,
        )
    except Exception as exc:
        logger.exception("Failed to list COS objects")
        raise HTTPException(status_code=502, detail=f"COS API error: {exc}") from exc

    objects: list[ObjectInfo] = []

    # Directories (common prefixes)
    for cp in resp.get("CommonPrefixes", []):
        p = cp.get("Prefix", "")
        if p:
            objects.append(ObjectInfo(key=p, is_dir=True))

    # Files
    for obj in resp.get("Contents", []):
        key = obj.get("Key", "")
        # Skip the prefix itself (COS returns the folder entry)
        if key == prefix:
            continue
        objects.append(
            ObjectInfo(
                key=key,
                size=int(obj.get("Size", 0)),
                last_modified=obj.get("LastModified", ""),
                is_dir=False,
            )
        )

    return ListObjectsResponse(
        objects=objects,
        is_truncated=resp.get("IsTruncated") == "true",
        next_marker=resp.get("NextMarker", ""),
    )


@router.post("/upload", response_model=UploadCosResponse, summary="Upload a server file to COS")
async def upload_to_cos(body: UploadRequest) -> UploadCosResponse:
    """Upload a file from WORKING_DIR to a COS bucket.

    The file must exist on the server (within the agent workspace).
    """
    local_path = _resolve_working_path(body.server_path)

    if not local_path.is_file():
        raise HTTPException(
            status_code=404,
            detail=f"File not found in workspace: {body.server_path}",
        )

    # Default COS key to the filename if not provided
    cos_key = body.cos_key or local_path.name

    client = _make_client(body.region)
    try:
        resp = client.upload_file(
            Bucket=body.bucket,
            Key=cos_key,
            LocalFilePath=str(local_path),
        )
    except Exception as exc:
        logger.exception("Failed to upload file to COS")
        raise HTTPException(status_code=502, detail=f"COS upload error: {exc}") from exc

    return UploadCosResponse(
        key=cos_key,
        etag=resp.get("ETag", ""),
    )


@router.post("/download", response_model=DownloadCosResponse, summary="Download a COS object to server")
async def download_from_cos(body: DownloadRequest) -> DownloadCosResponse:
    """Download a COS object and save it to WORKING_DIR.

    The file is streamed to a temp file first, then moved into the
    target directory to avoid partial-write issues.
    """
    # Determine target directory within WORKING_DIR
    if body.server_path:
        target_dir = _resolve_working_path(body.server_path)
    else:
        target_dir = WORKING_DIR

    # Ensure target directory exists
    target_dir.mkdir(parents=True, exist_ok=True)
    if not target_dir.is_dir():
        raise HTTPException(
            status_code=400,
            detail=f"Target is not a directory: {body.server_path}",
        )

    # Extract filename from COS key
    filename = body.cos_key.rsplit("/", maxsplit=1)[-1]
    if not filename:
        raise HTTPException(status_code=400, detail="COS key does not contain a valid filename")

    final_path = target_dir / filename

    client = _make_client(body.region)
    tmp_path: str | None = None
    try:
        # Download to a temp file first, then move to final location
        with tempfile.NamedTemporaryFile(
            delete=False,
            suffix=".cosdownload",
            dir=str(target_dir),
        ) as tmp:
            tmp_path = tmp.name

        client.download_file(
            Bucket=body.bucket,
            Key=body.cos_key,
            DestFilePath=tmp_path,
        )

        # Atomic move (same filesystem)
        Path(tmp_path).replace(final_path)
        tmp_path = None  # successfully moved, no cleanup needed
    except Exception as exc:
        logger.exception("Failed to download file from COS")
        raise HTTPException(status_code=502, detail=f"COS download error: {exc}") from exc
    finally:
        if tmp_path:
            with contextlib.suppress(OSError):
                os.unlink(tmp_path)

    file_size = final_path.stat().st_size
    relative = final_path.relative_to(WORKING_DIR).as_posix()

    return DownloadCosResponse(server_path=relative, size=file_size)
