"""Agent file management API."""

from __future__ import annotations

import logging

from fastapi import APIRouter, Body, HTTPException, Request
from pydantic import BaseModel, Field

from ... import __version__
from ...agent.memory.agent_md_manager import AGENT_MD_MANAGER
from ...config import (
    AgentsRunningConfig,
    load_config,
    save_config,
)
from ...config.config import ActiveHoursConfig, HeartbeatConfig

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/agent", tags=["agent"])

# Public router — endpoints that do NOT require authentication
public_router = APIRouter(prefix="/agent", tags=["agent"])


@public_router.get(
    "/",
    summary="Service discovery",
    description="Returns service name, version and available endpoints",
)
async def service_info() -> dict:
    """Service discovery — returns service metadata and available endpoints."""
    return {
        "service": "LightClaw Agent",
        "version": __version__,
        "endpoints": {
            "health": "/api/agent/health",
            "running_status": "/api/agent/running-status",
            "process": "/api/agent/process",
            "turns_stream": "/api/turns/stream",
            "files": "/api/agent/files",
            "memory": "/api/agent/memory",
            "running_config": "/api/agent/running-config",
            "heartbeat_config": "/api/agent/heartbeat-config",
        },
    }


@public_router.get(
    "/health",
    summary="Health check",
    description="Returns 200 if the agent service is healthy",
)
async def health_check() -> dict:
    """Lightweight health check — confirms the FastAPI process is alive."""
    return {"status": "ok"}


class AgentRunningProbeResponse(BaseModel):
    """Response for probing whether agent has active tasks running."""

    is_running: bool
    active_count: int

    # Optional filters echoed back for debugging.
    user_id: str | None = None
    session_id: str | None = None
    channel: str | None = None


@public_router.get(
    "/running-status",
    response_model=AgentRunningProbeResponse,
    summary="Probe whether agent is running",
    description="Return whether there are active agent tasks right now.",
)
async def agent_running_status(
    request: Request,
    user_id: str | None = None,
    session_id: str | None = None,
    channel: str | None = None,
):
    """Check global or filtered 'agent is running' state.

    Business rule: in UI we map 'turn is running' to 'session has any active task'.
    """
    registry = getattr(request.app.state, "task_registry", None)
    if registry is None:
        # Keep consistent with other TaskBoard endpoints' behavior.
        raise HTTPException(status_code=503, detail="task_registry not initialized")

    # Fast path: no filters → only return active_count.
    if not user_id and not session_id and not channel:
        stats = await registry.get_stats()
        active_count = int(stats.get("active_count") or 0)
        return AgentRunningProbeResponse(
            is_running=active_count > 0,
            active_count=active_count,
        )

    # Filter path: fetch active tasks and count matches.
    tasks = await registry.get_active_tasks()
    filtered = [
        t
        for t in tasks
        if (user_id is None or t.user_id == user_id)
        and (session_id is None or t.session_id == session_id)
        and (channel is None or t.channel == channel)
    ]
    active_count = len(filtered)
    return AgentRunningProbeResponse(
        is_running=active_count > 0,
        active_count=active_count,
        user_id=user_id,
        session_id=session_id,
        channel=channel,
    )


class MdFileInfo(BaseModel):
    """Markdown file metadata."""

    filename: str = Field(..., description="File name")
    path: str = Field(..., description="File path")
    size: int = Field(..., description="Size in bytes")
    created_time: str = Field(..., description="Created time")
    modified_time: str = Field(..., description="Modified time")


class MdFileContent(BaseModel):
    """Markdown file content."""

    content: str = Field(..., description="File content")


@router.get(
    "/files",
    response_model=list[MdFileInfo],
    summary="List working files",
    description="List all working files",
)
async def list_working_files() -> list[MdFileInfo]:
    """List working directory markdown files."""
    try:
        files = [MdFileInfo.model_validate(file) for file in AGENT_MD_MANAGER.list_working_mds()]
        return files
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.get(
    "/files/{md_name}",
    response_model=MdFileContent,
    summary="Read a working file",
    description="Read a working markdown file",
)
async def read_working_file(
    md_name: str,
) -> MdFileContent:
    """Read a working directory markdown file."""
    try:
        content = AGENT_MD_MANAGER.read_working_md(md_name)
        return MdFileContent(content=content)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.put(
    "/files/{md_name}",
    response_model=dict,
    summary="Write a working file",
    description="Create or update a working file",
)
async def write_working_file(
    md_name: str,
    request: MdFileContent,
) -> dict:
    """Write a working directory markdown file."""
    try:
        AGENT_MD_MANAGER.write_working_md(md_name, request.content)
        return {"written": True}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.get(
    "/memory",
    response_model=list[MdFileInfo],
    summary="List memory files",
    description="List all memory files",
)
async def list_memory_files() -> list[MdFileInfo]:
    """List memory directory markdown files."""
    try:
        files = [MdFileInfo.model_validate(file) for file in AGENT_MD_MANAGER.list_memory_mds()]
        return files
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


class MemoryForgetRequest(BaseModel):
    """Request body for memory forget/delete operations."""

    query: str = Field(default="", description="Semantic search query to find memories to delete")
    chunk_ids: list[str] = Field(default_factory=list, description="Specific chunk IDs to delete")


class MemoryForgetResponse(BaseModel):
    """Response for memory forget operations."""

    success: bool
    message: str
    deleted_count: int = 0


@router.post(
    "/memory/forget",
    response_model=MemoryForgetResponse,
    summary="Forget memories by query or chunk IDs",
    description="Search and delete vector memory chunks",
)
async def forget_memory(body: MemoryForgetRequest, request: Request) -> MemoryForgetResponse:
    """Delete memories by semantic query or specific chunk IDs."""
    runner = getattr(request.app.state, "runner", None)
    mm = getattr(runner, "memory_manager", None) if runner is not None else None
    if mm is None:
        raise HTTPException(status_code=503, detail="Memory manager not available")

    if body.chunk_ids:
        result = await mm.memory_forget_by_chunk_ids(body.chunk_ids)
        return MemoryForgetResponse(
            success=True,
            message=result,
            deleted_count=len(body.chunk_ids),
        )

    if body.query:
        result = await mm.memory_forget_by_query(body.query)
        is_deleted = "Deleted" in result
        return MemoryForgetResponse(
            success=True,
            message=result,
            deleted_count=1 if is_deleted else 0,
        )

    raise HTTPException(status_code=400, detail="Provide query or chunk_ids")


@router.get(
    "/memory/{md_name}",
    response_model=MdFileContent,
    summary="Read a memory file",
    description="Read a memory markdown file",
)
async def read_memory_file(
    md_name: str,
) -> MdFileContent:
    """Read a memory directory markdown file."""
    try:
        content = AGENT_MD_MANAGER.read_memory_md(md_name)
        return MdFileContent(content=content)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.put(
    "/memory/{md_name}",
    response_model=dict,
    summary="Write a memory file",
    description="Create or update a memory file",
)
async def write_memory_file(
    md_name: str,
    request: MdFileContent,
) -> dict:
    """Write a memory directory markdown file."""
    try:
        AGENT_MD_MANAGER.write_memory_md(md_name, request.content)
        return {"written": True}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@router.delete(
    "/memory/{md_name}",
    response_model=dict,
    summary="Delete a memory file",
    description="Delete a daily memory markdown file and its vector chunks",
)
async def delete_memory_file(md_name: str, request: Request) -> dict:
    """Delete a memory file by name and clean up its vector chunks."""
    try:
        deleted = AGENT_MD_MANAGER.delete_memory_md(md_name)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    if not deleted:
        raise HTTPException(status_code=404, detail=f"Memory file not found: {md_name}")

    # Trigger vector chunk cleanup via MemoryManager public API
    runner = getattr(request.app.state, "runner", None)
    if runner is not None:
        mm = getattr(runner, "memory_manager", None)
        if mm is not None:
            try:
                await mm.delete_vector_chunks_for_file(md_name)
            except Exception as exc:
                logger.warning("Vector chunk cleanup failed for %s: %s", md_name, exc)

    return {"deleted": True, "filename": md_name}


@router.get(
    "/running-config",
    response_model=AgentsRunningConfig,
    summary="Get agent running config",
    description="Retrieve agent runtime behavior configuration",
)
async def get_agents_running_config() -> AgentsRunningConfig:
    """Get agent running configuration."""
    config = load_config()
    return config.agents.running


@router.put(
    "/running-config",
    response_model=AgentsRunningConfig,
    summary="Update agent running config",
    description="Update agent runtime behavior configuration",
)
async def put_agents_running_config(
    running_config: AgentsRunningConfig = Body(
        ...,
        description="Updated agent running configuration",
    ),
) -> AgentsRunningConfig:
    """Update agent running configuration."""
    config = load_config()
    config.agents.running = running_config
    save_config(config)
    return running_config


# --------------- Heartbeat config ---------------


class HeartbeatConfigResponse(BaseModel):
    """Heartbeat configuration response/request."""

    enabled: bool = Field(
        default=False,
        description="Whether heartbeat is enabled",
    )
    every: str = Field(
        default="30m",
        description="Interval string, e.g. '30m', '1h', '2h30m'",
    )
    target: str = Field(
        default="main",
        description="Dispatch target: 'main' or 'last'",
    )
    active_hours_enabled: bool = Field(
        default=False,
        description="Whether active hours are configured",
    )
    active_hours_start: str = Field(
        default="08:00",
        description="Active hours start time (HH:MM)",
    )
    active_hours_end: str = Field(
        default="22:00",
        description="Active hours end time (HH:MM)",
    )


@router.get(
    "/heartbeat-config",
    response_model=HeartbeatConfigResponse,
    summary="Get heartbeat config",
    description="Retrieve heartbeat configuration",
)
async def get_heartbeat_config_api() -> HeartbeatConfigResponse:
    """Get heartbeat configuration."""
    config = load_config()
    hb = config.agents.defaults.heartbeat
    if hb is None:
        return HeartbeatConfigResponse(enabled=False)
    return HeartbeatConfigResponse(
        enabled=True,
        every=hb.every,
        target=hb.target,
        active_hours_enabled=hb.active_hours is not None,
        active_hours_start=(hb.active_hours.start if hb.active_hours else "08:00"),
        active_hours_end=(hb.active_hours.end if hb.active_hours else "22:00"),
    )


@router.put(
    "/heartbeat-config",
    response_model=HeartbeatConfigResponse,
    summary="Update heartbeat config",
    description="Update heartbeat configuration",
)
async def put_heartbeat_config(
    req: HeartbeatConfigResponse = Body(
        ...,
        description="Updated heartbeat configuration",
    ),
) -> HeartbeatConfigResponse:
    """Update heartbeat configuration and reschedule."""
    config = load_config()
    if not req.enabled:
        config.agents.defaults.heartbeat = None
    else:
        active_hours = None
        if req.active_hours_enabled:
            active_hours = ActiveHoursConfig(
                start=req.active_hours_start,
                end=req.active_hours_end,
            )
        config.agents.defaults.heartbeat = HeartbeatConfig(
            every=req.every,
            target=req.target,
            active_hours=active_hours,
        )
    save_config(config)

    # Reschedule heartbeat in CronManager if running
    try:
        from .._app import cron_manager

        if cron_manager is not None:
            await cron_manager.reschedule_heartbeat()
    except Exception:
        pass  # CronManager may not be started yet

    return req
