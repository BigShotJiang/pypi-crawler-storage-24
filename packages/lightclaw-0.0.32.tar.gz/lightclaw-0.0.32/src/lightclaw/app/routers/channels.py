"""API router for channel operations (send messages, etc.)."""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/channels", tags=["channels"])


class SendMessageRequest(BaseModel):
    """Request body for sending a message to a channel."""

    text: str
    user_id: str | None = None
    session_id: str | None = None
    meta: dict[str, Any] | None = None


@router.post("/{channel}/send")
async def send_message(
    channel: str,
    body: SendMessageRequest,
    request: Request,
) -> dict:
    """Send a text message directly to a channel (bypassing Agent).

    Requires the LightClaw service to be running with the target channel
    connected and enabled.
    """
    manager = request.app.state.channel_manager
    user_id = body.user_id or "cli"
    session_id = body.session_id or f"{channel}:{user_id}"

    try:
        await manager.send_text(
            channel=channel,
            user_id=user_id,
            session_id=session_id,
            text=body.text,
            meta=body.meta or {},
        )
    except KeyError:
        raise HTTPException(
            status_code=404,
            detail=f"Channel not found or not enabled: {channel}",
        ) from None
    except Exception as exc:
        logger.exception("Failed to send message to channel %s", channel)
        raise HTTPException(
            status_code=500,
            detail=f"Failed to send message: {exc}",
        ) from exc

    return {"ok": True, "channel": channel}
