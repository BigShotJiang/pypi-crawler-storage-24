"""Turn-native streaming API."""

from __future__ import annotations

from typing import Any
from uuid import uuid4

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import StreamingResponse

from ..tasks import TaskInfo, TaskRegistry, TaskSource, TaskStatus, resolve_role
from ..turn_protocol import (
    DEFAULT_TURN_PROTOCOL_VERSION,
    TurnRequest,
    serialize_turn_event,
)

router = APIRouter(prefix="/turns", tags=["turns"])


def _get_runner(request: Request):
    runner = getattr(request.app.state, "runner", None)
    if runner is None:
        raise HTTPException(status_code=503, detail="Runner not initialized")
    return runner


@router.post("/stream")
async def stream_turns(request: Request):
    """Canonical turn stream endpoint."""
    body = await request.json()
    turn_request = TurnRequest(**body)
    runner = _get_runner(request)

    async def sse_generator():
        # --- Task Board tracking (mirrors /api/agent/process) ---
        # Dashboard's chat path uses /turns/stream, so we must also publish
        # turn lifecycle into TaskRegistry here; otherwise /api/tasks/* won't
        # reflect running turns.
        task_registry: TaskRegistry = request.app.state.task_registry

        task_id = str(uuid4())

        # Extract short description from user's last input.
        description = ""
        if turn_request.inputs:
            last_msg: Any = turn_request.inputs[-1]
            if hasattr(last_msg, "get_text_content"):
                txt = last_msg.get_text_content() or ""
            else:
                txt = str(getattr(last_msg, "content", "") or "")
            description = txt[:120]

        channel = turn_request.channel or "dashboard"
        task_source = TaskSource.CHAT if channel == "dashboard" else TaskSource.CHANNEL
        agent_role, agent_name = resolve_role(
            description=description,
            source=task_source,
            task_id=task_id,
        )

        task_info = TaskInfo(
            id=task_id,
            source=task_source,
            session_id=turn_request.session_id,
            user_id=turn_request.user_id,
            channel=channel,
            status=TaskStatus.QUEUED,
            description=description,
            agent_name=agent_name,
            agent_role=agent_role,
        )

        await task_registry.register_task(task_info)

        final_status: TaskStatus = TaskStatus.COMPLETED
        last_status: TaskStatus = task_info.status
        last_current_tool: str | None = task_info.current_tool

        async def update_task_status(
            *,
            status: TaskStatus | None = None,
            current_tool: str | None = None,
            update_current_tool: bool = False,
        ) -> None:
            nonlocal last_status, last_current_tool
            changes: dict[str, Any] = {}

            if status is not None and status != last_status:
                changes["status"] = status
                last_status = status

            if update_current_tool and current_tool != last_current_tool:
                changes["current_tool"] = current_tool
                last_current_tool = current_tool

            if changes:
                await task_registry.update_task(task_id, **changes)

        try:
            async for turn_event in runner.stream_turns(turn_request):
                if turn_event.type == "turn.started":
                    await update_task_status(
                        status=TaskStatus.THINKING,
                        current_tool=None,
                        update_current_tool=True,
                    )
                elif turn_event.type == "assistant.delta":
                    await update_task_status(
                        status=TaskStatus.STREAMING,
                        current_tool=None,
                        update_current_tool=(last_current_tool is not None),
                    )
                elif turn_event.type == "tool.started":
                    data = turn_event.data or {}
                    tool_name = data.get("name") or data.get("tool_name") or None
                    await update_task_status(
                        status=TaskStatus.TOOL_CALLING,
                        current_tool=tool_name,
                        update_current_tool=True,
                    )
                elif turn_event.type == "tool.approval_required":
                    data = turn_event.data or {}
                    tool_name = data.get("tool_name") or None
                    await update_task_status(
                        status=TaskStatus.TOOL_CALLING,
                        current_tool=tool_name,
                        update_current_tool=True,
                    )
                elif turn_event.type == "tool.completed":
                    await update_task_status(
                        status=TaskStatus.THINKING,
                        current_tool=None,
                        update_current_tool=(last_current_tool is not None),
                    )
                elif turn_event.type == "turn.failed":
                    final_status = TaskStatus.FAILED
                    await update_task_status(
                        status=TaskStatus.FAILED,
                        current_tool=None,
                        update_current_tool=True,
                    )

                yield f"data: {serialize_turn_event(turn_event)}\n\n"

            await task_registry.complete_task(task_id, final_status)
        except Exception:
            # If an exception bubbles up, treat as a failed task.
            await task_registry.complete_task(task_id, TaskStatus.FAILED)
            raise

    return StreamingResponse(
        sse_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
            "X-Turn-Protocol-Version": DEFAULT_TURN_PROTOCOL_VERSION,
        },
    )
