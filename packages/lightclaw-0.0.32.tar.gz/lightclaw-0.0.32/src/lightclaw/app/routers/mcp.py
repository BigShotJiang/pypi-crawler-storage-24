"""API routes for MCP (Model Context Protocol) clients management."""

from __future__ import annotations

from typing import Literal

from fastapi import APIRouter, Body, HTTPException, Path, Request
from pydantic import BaseModel, ConfigDict, Field, model_validator

from ...config import load_config, save_config
from ...config.config import MCPClientConfig

router = APIRouter(prefix="/mcp", tags=["mcp"])


class MCPClientInfo(BaseModel):
    """MCP client information for API responses."""

    key: str = Field(..., description="Unique client key identifier")
    name: str = Field(..., description="Client display name")
    description: str = Field(default="", description="Client description")
    enabled: bool = Field(..., description="Whether the client is enabled")
    transport: Literal["stdio", "streamable_http", "sse"] = Field(
        ...,
        description="MCP transport type",
    )
    url: str = Field(
        default="",
        description="Remote MCP endpoint URL (for HTTP/SSE transports)",
    )
    headers: dict[str, str] = Field(
        default_factory=dict,
        description="HTTP headers for remote transport",
    )
    command: str = Field(
        default="",
        description="Command to launch the MCP server",
    )
    args: list[str] = Field(
        default_factory=list,
        description="Command-line arguments",
    )
    env: dict[str, str] = Field(
        default_factory=dict,
        description="Environment variables",
    )
    cwd: str = Field(
        default="",
        description="Working directory for stdio MCP command",
    )


class MCPClientCreateRequest(BaseModel):
    """Request body for creating/updating an MCP client."""

    model_config = ConfigDict(extra="ignore")

    name: str = Field(..., description="Client display name")
    description: str = Field(default="", description="Client description")
    enabled: bool = Field(
        default=True,
        description="Whether to enable the client",
    )
    transport: str = Field(
        default="stdio",
        description="MCP transport type (stdio, streamable_http, sse, http)",
    )
    url: str = Field(
        default="",
        description="Remote MCP endpoint URL (for HTTP/SSE transports)",
    )
    headers: dict[str, str] = Field(
        default_factory=dict,
        description="HTTP headers for remote transport",
    )
    command: str = Field(
        default="",
        description="Command to launch the MCP server",
    )
    args: list[str] = Field(
        default_factory=list,
        description="Command-line arguments",
    )
    env: dict[str, str] = Field(
        default_factory=dict,
        description="Environment variables",
    )
    cwd: str = Field(
        default="",
        description="Working directory for stdio MCP command",
    )

    @model_validator(mode="before")
    @classmethod
    def _normalize_fields(cls, data):
        """Normalize aliases so MCPClientConfig validation succeeds."""
        if not isinstance(data, dict):
            return data
        payload = dict(data)

        # Alias: type -> transport
        if "type" in payload and "transport" not in payload:
            payload["transport"] = payload.pop("type")

        # Alias: baseUrl -> url
        if "baseUrl" in payload and "url" not in payload:
            payload["url"] = payload.pop("baseUrl")

        # Alias: isActive -> enabled
        if "isActive" in payload and "enabled" not in payload:
            payload["enabled"] = payload.pop("isActive")

        # Auto-detect: has url but no command → streamable_http
        if "transport" not in payload and (payload.get("url") or payload.get("baseUrl")) and not payload.get("command"):
            payload["transport"] = "streamable_http"

        return payload


class MCPClientUpdateRequest(BaseModel):
    """Request body for updating an MCP client (all fields optional)."""

    model_config = ConfigDict(extra="ignore")

    name: str | None = Field(None, description="Client display name")
    description: str | None = Field(None, description="Client description")
    enabled: bool | None = Field(
        None,
        description="Whether to enable the client",
    )
    transport: str | None = Field(
        None,
        description="MCP transport type (stdio, streamable_http, sse, http)",
    )
    url: str | None = Field(
        None,
        description="Remote MCP endpoint URL (for HTTP/SSE transports)",
    )
    headers: dict[str, str] | None = Field(
        None,
        description="HTTP headers for remote transport",
    )
    command: str | None = Field(
        None,
        description="Command to launch the MCP server",
    )
    args: list[str] | None = Field(
        None,
        description="Command-line arguments",
    )
    env: dict[str, str] | None = Field(
        None,
        description="Environment variables",
    )
    cwd: str | None = Field(
        None,
        description="Working directory for stdio MCP command",
    )

    @model_validator(mode="before")
    @classmethod
    def _normalize_fields(cls, data):
        """Normalize aliases so MCPClientConfig validation succeeds."""
        if not isinstance(data, dict):
            return data
        payload = dict(data)

        if "type" in payload and "transport" not in payload:
            payload["transport"] = payload.pop("type")

        if "baseUrl" in payload and "url" not in payload:
            payload["url"] = payload.pop("baseUrl")

        if "isActive" in payload and "enabled" not in payload:
            payload["enabled"] = payload.pop("isActive")

        return payload


def _mask_env_value(value: str) -> str:
    """
    Mask environment variable value showing first 2-3 chars and last 4 chars.

    Examples::

        "xx-xxxx-xxxxxxxxxxxxxxxxxx9999" -> "xx-****************************9999"
        "ABCDEFGHIJKLMNO" -> "AB***********MNO" (no dash in prefix)
        "ab-xxxxxxxx-yyyy" -> "ab-************yyy"
        "12345678" -> "********" (8 chars or less → fully masked)
    """
    if not value:
        return value

    length = len(value)
    if length <= 8:
        # For short values, just mask everything
        return "*" * length

    # Show first 2-3 characters (3 if there's a dash at position 2)
    prefix_len = 3 if length > 2 and value[2] == "-" else 2
    prefix = value[:prefix_len]

    # Show last 4 characters
    suffix = value[-4:]

    # Calculate masked section length (at least 4 asterisks)
    masked_len = max(length - prefix_len - 4, 4)

    return f"{prefix}{'*' * masked_len}{suffix}"


def _build_client_info(key: str, client: MCPClientConfig) -> MCPClientInfo:
    """Build MCPClientInfo from config with masked env values."""
    # Mask environment variable values for security
    masked_env = {k: _mask_env_value(v) for k, v in client.env.items()} if client.env else {}
    masked_headers = {k: _mask_env_value(v) for k, v in client.headers.items()} if client.headers else {}

    return MCPClientInfo(
        key=key,
        name=client.name,
        description=client.description,
        enabled=client.enabled,
        transport=client.transport,
        url=client.url,
        headers=masked_headers,
        command=client.command,
        args=client.args,
        env=masked_env,
        cwd=client.cwd,
    )


@router.get(
    "",
    response_model=list[MCPClientInfo],
    summary="List all MCP clients",
)
async def list_mcp_clients() -> list[MCPClientInfo]:
    """Get list of all configured MCP clients."""
    config = load_config()
    return [_build_client_info(key, client) for key, client in config.mcp.clients.items()]


@router.get(
    "/{client_key}",
    response_model=MCPClientInfo,
    summary="Get MCP client details",
)
async def get_mcp_client(client_key: str = Path(...)) -> MCPClientInfo:
    """Get details of a specific MCP client."""
    config = load_config()
    client = config.mcp.clients.get(client_key)
    if client is None:
        raise HTTPException(404, detail=f"MCP client '{client_key}' not found")
    return _build_client_info(client_key, client)


@router.post(
    "",
    response_model=MCPClientInfo,
    summary="Create a new MCP client",
    status_code=201,
)
async def create_mcp_client(
    request: Request,
) -> MCPClientInfo:
    """Create a new MCP client configuration.

    Accepts raw JSON body and delegates all normalization / validation to
    ``MCPClientConfig.model_validate()`` so that alias fields like ``type``,
    ``baseUrl`` etc. are handled transparently.
    """
    body = await request.json()

    # Support both { "client_key": ..., "client": {...} } and flat formats
    if "client_key" in body and "client" in body:
        client_key: str = body["client_key"]
        client_data: dict = body["client"]
    else:
        raise HTTPException(
            422,
            detail="Request body must contain 'client_key' and 'client' fields.",
        )

    if not client_key or not isinstance(client_key, str):
        raise HTTPException(422, detail="'client_key' must be a non-empty string.")

    # Ensure name is present (default to client_key)
    if "name" not in client_data:
        client_data["name"] = client_key

    config = load_config()

    # Check if client already exists
    if client_key in config.mcp.clients:
        raise HTTPException(
            400,
            detail=f"MCP client '{client_key}' already exists. Use PUT to update.",
        )

    # MCPClientConfig.model_validate runs the before-validator that handles
    # type->transport, baseUrl->url, http->streamable_http, auto-detection etc.
    try:
        new_client = MCPClientConfig.model_validate(client_data)
    except Exception as e:
        raise HTTPException(422, detail=str(e)) from e

    # Add to config and save
    config.mcp.clients[client_key] = new_client
    save_config(config)

    return _build_client_info(client_key, new_client)


@router.put(
    "/{client_key}",
    response_model=MCPClientInfo,
    summary="Update an MCP client",
)
async def update_mcp_client(
    client_key: str = Path(...),
    updates: MCPClientUpdateRequest = Body(...),
) -> MCPClientInfo:
    """Update an existing MCP client configuration."""
    config = load_config()

    # Check if client exists
    existing = config.mcp.clients.get(client_key)
    if existing is None:
        raise HTTPException(404, detail=f"MCP client '{client_key}' not found")

    # Update fields if provided
    update_data = updates.model_dump(exclude_unset=True)

    # Special handling for env: merge with existing, don't replace
    if "env" in update_data and update_data["env"] is not None:
        updated_env = existing.env.copy() if existing.env else {}
        updated_env.update(update_data["env"])
        update_data["env"] = updated_env

    # Re-validate through MCPClientConfig to run transport validators
    merged_data = existing.model_dump(mode="json")
    merged_data.update(update_data)
    updated_client = MCPClientConfig.model_validate(merged_data)
    config.mcp.clients[client_key] = updated_client

    # Save updated config
    save_config(config)

    return _build_client_info(client_key, updated_client)


@router.patch(
    "/{client_key}/toggle",
    response_model=MCPClientInfo,
    summary="Toggle MCP client enabled status",
)
async def toggle_mcp_client(
    client_key: str = Path(...),
) -> MCPClientInfo:
    """Toggle the enabled status of an MCP client."""
    config = load_config()

    client = config.mcp.clients.get(client_key)
    if client is None:
        raise HTTPException(404, detail=f"MCP client '{client_key}' not found")

    # Toggle enabled status
    client.enabled = not client.enabled
    save_config(config)

    return _build_client_info(client_key, client)


@router.delete(
    "/{client_key}",
    response_model=dict[str, str],
    summary="Delete an MCP client",
)
async def delete_mcp_client(
    client_key: str = Path(...),
) -> dict[str, str]:
    """Delete an MCP client configuration."""
    config = load_config()

    if client_key not in config.mcp.clients:
        raise HTTPException(404, detail=f"MCP client '{client_key}' not found")

    # Remove client
    del config.mcp.clients[client_key]
    save_config(config)

    return {"message": f"MCP client '{client_key}' deleted successfully"}
