from fastapi import APIRouter, Depends

from ..core.auth import require_auth
from ..core.auth import router as auth_router
from ..cron.api import router as cron_router
from ..runner.api import router as runner_router
from ..tasks.api import router as tasks_router
from .agent import public_router as agent_public_router
from .agent import router as agent_router
from .browser import router as browser_router
from .browser_stream import router as browser_stream_router
from .channels import router as channels_router
from .config import router as config_router
from .cos import router as cos_router
from .dashboard import router as dashboard_router
from .embedding import router as embedding_router
from .envs import router as envs_router
from .mcp import router as mcp_router
from .ollama_models import router as ollama_models_router
from .providers import (
    public_router as providers_public_router,
)
from .providers import (
    router as providers_router,
)
from .scenes import router as scenes_router
from .search import router as search_router
from .skills import router as skills_router
from .terminal import router as terminal_router
from .turns import router as turns_router
from .upload import router as upload_router
from .video_chat import router as video_chat_router
from .workspace import router as workspace_router

router = APIRouter()

# Auth routes are public (login / status don't need auth)
router.include_router(auth_router)

# Agent health & service discovery are public (no auth needed)
router.include_router(agent_public_router)

# Provider read-only routes are public (list providers, models, active LLM)
router.include_router(providers_public_router)

# All other routes require authentication (when password protection is on)
_protected = APIRouter(dependencies=[Depends(require_auth)])

_protected.include_router(agent_router)
_protected.include_router(config_router)
_protected.include_router(dashboard_router)
_protected.include_router(cron_router)
_protected.include_router(mcp_router)
_protected.include_router(ollama_models_router)
_protected.include_router(providers_router)
_protected.include_router(runner_router)
_protected.include_router(skills_router)
_protected.include_router(envs_router)
_protected.include_router(search_router)
_protected.include_router(scenes_router)
_protected.include_router(turns_router)
_protected.include_router(channels_router)
_protected.include_router(workspace_router)
_protected.include_router(embedding_router)
_protected.include_router(cos_router)
_protected.include_router(tasks_router)
_protected.include_router(browser_router)

# Upload routes stay outside the authenticated sub-router because browser
# previews/downloads use short-lived signed URLs instead of Authorization
# headers. The upload POST itself still enforces auth at the endpoint level.
router.include_router(upload_router)
router.include_router(video_chat_router)
router.include_router(terminal_router)
router.include_router(browser_stream_router)
router.include_router(_protected)

__all__ = ["router"]
