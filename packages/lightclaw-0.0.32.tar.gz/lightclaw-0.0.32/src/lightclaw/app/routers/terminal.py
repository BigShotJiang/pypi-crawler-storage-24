"""WebSocket endpoint for interactive terminal sessions.

Uses pty.openpty() to create a real pseudo-terminal paired with
subprocess.Popen so that bash sees a proper TTY and interactive
features (prompts, colours, job control) work correctly.

Message protocol
----------------
Client → Server (JSON):
  {"type": "input",  "data": "<raw keystrokes>"}
  {"type": "resize", "cols": 80, "rows": 24}

Server → Client (JSON):
  {"type": "output", "data": "<raw terminal bytes as text>"}
  {"type": "exit",   "code": <int>}
  {"type": "error",  "message": "<description>"}
"""

import asyncio
import contextlib
import errno
import fcntl
import json
import logging
import os
import pathlib
import pty
import pwd
import signal
import struct
import subprocess
import termios
import uuid

from fastapi import APIRouter, Query, WebSocket, WebSocketDisconnect
from starlette.websockets import WebSocketState

logger = logging.getLogger(__name__)

router = APIRouter()

# Maximum number of concurrent terminal sessions
_MAX_TERMINAL_SESSIONS = 20
_terminal_semaphore = asyncio.Semaphore(_MAX_TERMINAL_SESSIONS)
_active_terminal_count = 0

# Shells that we know how to invoke in login-interactive mode
_KNOWN_SHELLS = frozenset({"/bin/bash", "/bin/zsh", "/bin/sh", "/usr/bin/bash", "/usr/bin/zsh"})
_FALLBACK_SHELL = "/bin/bash"


def _get_user_shell() -> str:
    """Detect the current user's default login shell.

    Resolution order:
      1. $SHELL environment variable (set by most systems at login)
      2. /etc/passwd entry for current UID
      3. Fallback to /bin/bash
    """
    shell = os.environ.get("SHELL", "").strip()
    if shell and os.path.isfile(shell) and os.access(shell, os.X_OK):
        return shell

    try:
        pw = pwd.getpwuid(os.getuid())
        if pw.pw_shell and os.path.isfile(pw.pw_shell):
            return pw.pw_shell
    except (KeyError, OSError):
        pass

    return _FALLBACK_SHELL


def _build_shell_cmd(shell: str) -> list[str]:
    """Build the command list to start a login, interactive shell.

    For zsh/bash we pass both ``--login`` and ``-i`` so that:
      - ``--login`` loads /etc/profile, ~/.zprofile / ~/.bash_profile etc.
      - ``-i``      loads ~/.zshrc / ~/.bashrc and enables job control,
                    matching the experience of ``ssh localhost``.

    For unknown shells we still try ``--login``.
    """
    base = os.path.basename(shell)
    if base in ("zsh", "bash"):
        return [shell, "--login", "-i"]
    if base == "sh":
        return [shell, "--login"]
    return [shell, "--login"]


def _build_shell_env() -> dict[str, str]:
    """Build the environment dict for the child shell process.

    Starts with the current process environment (which already contains
    ``~/.lightclaw/.env`` values loaded at startup), then overlays a set of
    terminal-specific variables so that the experience matches a real SSH
    session.
    """
    home = pathlib.Path.home()
    env = {**os.environ}

    # Terminal capabilities
    env["TERM"] = "xterm-256color"
    env["COLORTERM"] = "truecolor"

    # Locale — ensure a UTF-8 locale is set (many CLI tools misbehave without)
    if not env.get("LANG"):
        env["LANG"] = "en_US.UTF-8"
    if not env.get("LC_ALL"):
        env.setdefault("LC_CTYPE", "UTF-8")

    # HOME must be correct
    env["HOME"] = str(home)

    # Default editor / pager fallbacks (non-destructive: only set if absent)
    env.setdefault("EDITOR", "vi")
    env.setdefault("PAGER", "less")

    return env


def _verify_ws_token(token: str | None) -> bool:
    """Verify JWT token for WebSocket connections."""
    try:
        from ..core.auth import _ensure_jwt_secret, _jwt_decode, _read_auth

        auth = _read_auth()
        if not auth.enabled:
            return True
        if not token:
            logger.warning("Auth enabled but no token provided — rejecting terminal WS")
            return False
        secret = _ensure_jwt_secret(auth)
        _jwt_decode(token, secret)
        return True
    except Exception as exc:
        logger.warning("Terminal token verification failed: %s: %s", type(exc).__name__, exc)
        return False


def _set_winsize(fd: int, cols: int, rows: int) -> None:
    """Set the terminal window size via ioctl."""
    try:
        winsize = struct.pack("HHHH", rows, cols, 0, 0)
        fcntl.ioctl(fd, termios.TIOCSWINSZ, winsize)
    except Exception as exc:
        logger.debug("Failed to set winsize: %s", exc)


@router.websocket("/terminal/ws")
async def terminal_ws(
    websocket: WebSocket,
    token: str | None = Query(default=None),
    session_id: str | None = Query(default=None),
    cols: int = Query(default=80),
    rows: int = Query(default=24),
):
    """WebSocket endpoint for interactive terminal sessions.

    Query params:
        token: JWT authentication token
        session_id: Optional client-provided session identifier (for logging)
        cols: Initial terminal width (default: 80)
        rows: Initial terminal height (default: 24)
    """
    global _active_terminal_count

    sid = session_id or str(uuid.uuid4())[:8]
    client_host = websocket.client.host if websocket.client else "unknown"

    # Authenticate
    if not _verify_ws_token(token):
        await websocket.accept()
        await websocket.send_text(json.dumps({"type": "error", "message": "Unauthorized"}))
        await websocket.close(code=4001, reason="Unauthorized")
        return

    # Enforce session limit
    if _terminal_semaphore._value <= 0:  # type: ignore[attr-defined]
        await websocket.accept()
        await websocket.send_text(
            json.dumps(
                {
                    "type": "error",
                    "message": f"Too many terminal sessions (max {_MAX_TERMINAL_SESSIONS})",
                }
            )
        )
        await websocket.close(code=4029, reason="Too Many Sessions")
        return

    await _terminal_semaphore.acquire()
    _active_terminal_count += 1
    logger.info(
        "Terminal session started: sid=%s active=%d host=%s",
        sid,
        _active_terminal_count,
        client_host,
    )

    await websocket.accept()

    proc: subprocess.Popen | None = None
    master_fd: int | None = None
    slave_fd: int | None = None

    try:
        # Create a real PTY pair: master_fd is the controller side,
        # slave_fd is handed to the child process as its stdin/stdout/stderr.
        master_fd, slave_fd = pty.openpty()

        # Set initial terminal window size on the master side
        _set_winsize(master_fd, cols, rows)

        # Set master_fd to non-blocking so we can poll it asynchronously
        flags = fcntl.fcntl(master_fd, fcntl.F_GETFL)
        fcntl.fcntl(master_fd, fcntl.F_SETFL, flags | os.O_NONBLOCK)

        # Spawn the user's default shell with the slave PTY as its
        # controlling terminal.  We use login + interactive mode so that
        # all rc files are sourced, matching a real SSH experience.
        user_shell = _get_user_shell()
        shell_cmd = _build_shell_cmd(user_shell)
        shell_env = _build_shell_env()
        logger.info("Starting shell: %s (sid=%s)", shell_cmd, sid)

        proc = subprocess.Popen(
            shell_cmd,
            stdin=slave_fd,
            stdout=slave_fd,
            stderr=slave_fd,
            close_fds=True,
            preexec_fn=os.setsid,
            env=shell_env,
            cwd=os.path.expanduser("~"),
        )

        # Close slave_fd in the parent — the child owns it now
        os.close(slave_fd)
        slave_fd = None

        # ────────────────────────────────────────────────────────────────────
        # Relay I/O between WebSocket and PTY master fd
        # ────────────────────────────────────────────────────────────────────

        async def read_from_pty() -> None:
            """Continuously read PTY output and forward to WebSocket."""
            while True:
                try:
                    if master_fd is None or proc is None:
                        break

                    # Non-blocking read from PTY master
                    try:
                        data = os.read(master_fd, 4096)
                        if not data:
                            break
                    except OSError as e:
                        if e.errno in (errno.EAGAIN, errno.EWOULDBLOCK):
                            # No data available yet; check if process exited
                            if proc.poll() is not None:
                                break
                            await asyncio.sleep(0.02)
                            continue
                        elif e.errno == errno.EIO:
                            # EIO means the slave side was closed (shell exited)
                            break
                        else:
                            logger.debug("PTY read error (sid=%s): %s", sid, e)
                            break

                    if websocket.client_state != WebSocketState.CONNECTED:
                        break

                    try:
                        await websocket.send_text(
                            json.dumps(
                                {
                                    "type": "output",
                                    "data": data.decode("utf-8", errors="replace"),
                                }
                            )
                        )
                    except Exception as exc:
                        logger.debug("Failed to send output (sid=%s): %s", sid, exc)
                        break

                except Exception as exc:
                    logger.debug("Unexpected error in PTY reader (sid=%s): %s", sid, exc)
                    break

        reader_task = asyncio.create_task(read_from_pty())

        try:
            while True:
                try:
                    raw = await websocket.receive_text()
                except WebSocketDisconnect:
                    break
                except Exception as exc:
                    logger.debug("WebSocket receive error (sid=%s): %s", sid, exc)
                    break

                try:
                    msg = json.loads(raw)
                except json.JSONDecodeError:
                    continue

                msg_type = msg.get("type")

                if msg_type == "input":
                    data = msg.get("data", "")
                    if data and master_fd is not None:
                        try:
                            os.write(master_fd, data.encode("utf-8", errors="replace"))
                        except OSError as exc:
                            logger.debug("PTY write error (sid=%s): %s", sid, exc)
                            break

                elif msg_type == "resize":
                    try:
                        new_cols = int(msg.get("cols", 80))
                        new_rows = int(msg.get("rows", 24))
                        if master_fd is not None:
                            _set_winsize(master_fd, new_cols, new_rows)
                    except (ValueError, TypeError, OSError):
                        pass

        finally:
            reader_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await reader_task

        # Notify client that the shell exited
        if websocket.client_state == WebSocketState.CONNECTED:
            try:
                if proc and proc.poll() is None:
                    try:
                        proc.wait(timeout=1)
                    except subprocess.TimeoutExpired:
                        proc.terminate()
                        try:
                            proc.wait(timeout=1)
                        except subprocess.TimeoutExpired:
                            proc.kill()
                            proc.wait()

                exit_code = proc.returncode if proc else 0
                await websocket.send_text(json.dumps({"type": "exit", "code": exit_code}))
            except Exception:
                pass

    except Exception as exc:
        logger.exception("Terminal session error (sid=%s): %s", sid, exc)
        if websocket.client_state == WebSocketState.CONNECTED:
            with contextlib.suppress(Exception):
                await websocket.send_text(
                    json.dumps(
                        {
                            "type": "error",
                            "message": str(exc),
                        }
                    )
                )

    finally:
        # Close PTY file descriptors
        if slave_fd is not None:
            with contextlib.suppress(OSError):
                os.close(slave_fd)
        if master_fd is not None:
            with contextlib.suppress(OSError):
                os.close(master_fd)

        # Clean up the subprocess
        if proc:
            try:
                if proc.poll() is None:
                    with contextlib.suppress(ProcessLookupError, OSError):
                        os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
                    try:
                        proc.wait(timeout=1)
                    except subprocess.TimeoutExpired:
                        with contextlib.suppress(ProcessLookupError, OSError):
                            os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
                        with contextlib.suppress(subprocess.TimeoutExpired):
                            proc.wait(timeout=1)
            except Exception as e:
                logger.debug("Error cleaning up process (sid=%s): %s", sid, e)

        # Close WebSocket if still open
        try:
            if websocket.client_state == WebSocketState.CONNECTED:
                await websocket.close()
        except Exception:
            pass

        _active_terminal_count -= 1
        _terminal_semaphore.release()
        logger.info("Terminal session ended: sid=%s active=%d", sid, _active_terminal_count)
