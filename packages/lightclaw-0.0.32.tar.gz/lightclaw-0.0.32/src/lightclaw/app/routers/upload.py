"""Attachment upload API — upload files and serve uploaded content."""

from __future__ import annotations

import logging
import mimetypes
from pathlib import Path

from fastapi import APIRouter, Depends, File, HTTPException, Query, Request, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from ..core.auth import require_auth
from ..file_store import (
    file_payload,
    get_file_metadata,
    is_bearer_token_valid,
    resolve_upload_path,
    store_uploaded_bytes,
    validate_file_id,
    verify_signed_access,
)

logger = logging.getLogger(__name__)

router = APIRouter(tags=["upload"])

# Maximum upload size: 20 MB
MAX_UPLOAD_SIZE = 20 * 1024 * 1024

ALLOWED_MIME_TYPES: dict[str, str] = {
    "image/png": ".png",
    "image/jpeg": ".jpg",
    "image/gif": ".gif",
    "image/webp": ".webp",
    "application/pdf": ".pdf",
    "text/plain": ".txt",
    "text/markdown": ".md",
    "application/json": ".json",
    "text/csv": ".csv",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": ".xlsx",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation": ".pptx",
    "application/zip": ".zip",
}

ALLOWED_EXTENSIONS: dict[str, str] = {
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif": "image/gif",
    ".webp": "image/webp",
    ".pdf": "application/pdf",
    ".txt": "text/plain",
    ".md": "text/markdown",
    ".markdown": "text/markdown",
    ".json": "application/json",
    ".csv": "text/csv",
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    ".zip": "application/zip",
}

MAGIC_BYTES: dict[str, list[bytes]] = {
    "image/png": [b"\x89PNG\r\n\x1a\n"],
    "image/jpeg": [b"\xff\xd8\xff"],
    "image/gif": [b"GIF87a", b"GIF89a"],
    "image/webp": [b"RIFF"],
    "application/pdf": [b"%PDF-"],
    "application/zip": [b"PK\x03\x04", b"PK\x05\x06", b"PK\x07\x08"],
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [
        b"PK\x03\x04",
        b"PK\x05\x06",
        b"PK\x07\x08",
    ],
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": [
        b"PK\x03\x04",
        b"PK\x05\x06",
        b"PK\x07\x08",
    ],
    "application/vnd.openxmlformats-officedocument.presentationml.presentation": [
        b"PK\x03\x04",
        b"PK\x05\x06",
        b"PK\x07\x08",
    ],
}

TEXT_LIKE_MIME_TYPES = {
    "text/plain",
    "text/markdown",
    "application/json",
    "text/csv",
}


class UploadResponse(BaseModel):
    """Upload response."""

    file_id: str = Field(..., description="Stable file identifier")
    url: str = Field(..., description="Short-lived access URL for the uploaded file")
    access_url: str = Field(..., description="Short-lived access URL for the uploaded file")
    filename: str = Field(..., description="Original filename")
    media_type: str = Field(..., description="MIME type of the file")


class FileAccessUrlItem(BaseModel):
    """Single access URL payload."""

    file_id: str = Field(..., description="Stable file identifier")
    access_url: str = Field(..., description="Short-lived access URL")
    filename: str = Field(..., description="Original filename")
    media_type: str = Field(..., description="MIME type")


class FileAccessUrlRequest(BaseModel):
    """Batch request to mint signed file URLs."""

    file_ids: list[str] = Field(default_factory=list, description="Stored file ids")


class FileAccessUrlResponse(BaseModel):
    """Batch response for signed file URLs."""

    items: list[FileAccessUrlItem] = Field(default_factory=list)


def _validate_magic_bytes(data: bytes, mime_type: str) -> bool:
    """Validate file header bytes match the declared MIME type."""
    signatures = MAGIC_BYTES.get(mime_type, [])
    if not signatures:
        return False
    for sig in signatures:
        if data[: len(sig)] == sig:
            # Extra check for webp: bytes 8-12 must be "WEBP"
            if mime_type == "image/webp":
                return len(data) >= 12 and data[8:12] == b"WEBP"
            return True
    return False


def _detect_media_type_by_magic(data: bytes) -> str | None:
    """Detect the real MIME type by inspecting file header (magic bytes).

    Returns an allowed MIME type string if recognized, else ``None``.
    """
    if len(data) < 8:
        return None
    for mime_type, signatures in MAGIC_BYTES.items():
        for sig in signatures:
            if data[: len(sig)] == sig:
                # Extra check for webp
                if mime_type == "image/webp":
                    if len(data) >= 12 and data[8:12] == b"WEBP":
                        return mime_type
                    continue
                # Disambiguate ZIP-based formats by sniffing internal file names
                if mime_type == "application/zip":
                    continue  # skip, let specific Office types match first
                return mime_type
    # Check ZIP last (docx/xlsx/pptx are also PK-based)
    if data[:4] in (b"PK\x03\x04", b"PK\x05\x06", b"PK\x07\x08"):
        return "application/zip"
    return None


def _resolve_media_type(file: UploadFile) -> str | None:
    """Resolve allowed media type from filename extension or declared MIME."""
    filename = (file.filename or "").strip()
    suffix = Path(filename).suffix.lower()
    if suffix in ALLOWED_EXTENSIONS:
        return ALLOWED_EXTENSIONS[suffix]

    declared = (file.content_type or "").lower().strip()
    if declared in ALLOWED_MIME_TYPES:
        return declared

    guessed, _ = mimetypes.guess_type(filename)
    guessed = (guessed or "").lower()
    if guessed in ALLOWED_MIME_TYPES:
        return guessed
    return None


def _validate_text_payload(data: bytes) -> bool:
    """Heuristic validation for text-like uploads."""
    if b"\x00" in data:
        return False
    try:
        data.decode("utf-8")
        return True
    except UnicodeDecodeError:
        try:
            data.decode("utf-8-sig")
            return True
        except UnicodeDecodeError:
            return False


@router.post(
    "/upload",
    dependencies=[Depends(require_auth)],
    response_model=UploadResponse,
    summary="Upload an attachment",
    description=(
        "Upload an attachment file. Supported: images, PDF, text/markdown, JSON, CSV, DOCX, XLSX, PPTX, ZIP. Max 20 MB."
    ),
)
async def upload_image(
    file: UploadFile = File(..., description="Attachment file to upload"),
) -> UploadResponse:
    """Upload an attachment and return a URL to access it."""
    media_type = _resolve_media_type(file)
    if media_type is None:
        raise HTTPException(
            status_code=415,
            detail=(
                f"Unsupported file type: {file.content_type or 'unknown'}. "
                f"Allowed extensions: {', '.join(sorted(ALLOWED_EXTENSIONS.keys()))}"
            ),
        )

    # --- Read file data (with size check) ---
    data = await file.read()
    if len(data) > MAX_UPLOAD_SIZE:
        raise HTTPException(
            status_code=413,
            detail=(f"File too large: {len(data)} bytes. Maximum allowed: {MAX_UPLOAD_SIZE} bytes (20 MB)."),
        )
    if len(data) == 0:
        raise HTTPException(status_code=400, detail="Empty file.")

    # --- Magic bytes validation ---
    if media_type in TEXT_LIKE_MIME_TYPES:
        if not _validate_text_payload(data):
            raise HTTPException(
                status_code=400,
                detail="File content does not look like UTF-8 text.",
            )
    elif not _validate_magic_bytes(data, media_type):
        # The extension/declared MIME doesn't match the actual file content.
        # Try to detect the real type from magic bytes and use it if allowed.
        detected = _detect_media_type_by_magic(data)
        if detected and detected in ALLOWED_MIME_TYPES:
            logger.info(
                "MIME type mismatch for %r: declared=%s, detected=%s — using detected",
                file.filename,
                media_type,
                detected,
            )
            media_type = detected
        else:
            logger.warning(
                "Magic bytes validation failed for %r: declared=%s, detected=%s",
                file.filename,
                media_type,
                detected,
            )
            raise HTTPException(
                status_code=400,
                detail=(
                    "File content does not match declared MIME type. The file may be corrupted or incorrectly named."
                ),
            )

    metadata = store_uploaded_bytes(
        data,
        filename=file.filename or "",
        media_type=media_type,
    )
    return UploadResponse(**file_payload(metadata))


@router.post(
    "/files/access-urls",
    dependencies=[Depends(require_auth)],
    response_model=FileAccessUrlResponse,
    summary="Mint short-lived file access URLs",
)
async def get_file_access_urls(body: FileAccessUrlRequest) -> FileAccessUrlResponse:
    """Return fresh signed URLs for one or more stored files."""
    items: list[FileAccessUrlItem] = []
    for raw_file_id in body.file_ids:
        try:
            file_id = validate_file_id(raw_file_id)
        except ValueError:
            continue
        metadata = get_file_metadata(file_id)
        if metadata is None:
            continue
        items.append(FileAccessUrlItem(**file_payload(metadata)))
    return FileAccessUrlResponse(items=items)


@router.get(
    "/files/{filename:path}",
    summary="Serve an uploaded file",
    description="Retrieve a previously uploaded file by its id.",
)
async def serve_file(
    filename: str,
    request: Request,
    exp: int | None = Query(None, description="Signed access expiration"),
    sig: str | None = Query(None, description="Signed access signature"),
) -> FileResponse:
    """Serve an uploaded file from the uploads directory."""
    try:
        file_id = validate_file_id(filename)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="Invalid filename.") from exc

    auth_header = request.headers.get("authorization", "")
    bearer_token = None
    if auth_header.lower().startswith("bearer "):
        bearer_token = auth_header[7:].strip()

    if not (is_bearer_token_valid(bearer_token) or verify_signed_access(file_id, exp, sig)):
        raise HTTPException(status_code=401, detail="Not authenticated")

    try:
        target = resolve_upload_path(file_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="Invalid filename.") from exc

    if not target.is_file():
        raise HTTPException(status_code=404, detail="File not found.")

    suffix = target.suffix.lower()
    media_type = ALLOWED_EXTENSIONS.get(suffix)
    if media_type is None:
        media_type = mimetypes.guess_type(str(target))[0] or "application/octet-stream"

    return FileResponse(target, media_type=media_type)
