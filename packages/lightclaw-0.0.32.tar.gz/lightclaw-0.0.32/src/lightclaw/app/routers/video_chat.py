"""WebSocket endpoint for video chat.

Phases implemented:
  Phase 1 — Connection lifecycle + avatar assignment + state messages.
  Phase 2 — STT (faster-whisper) integration.
  Phase 3 — LLM bridge.
  Phase 4 — TTS synthesis + audio streaming.
"""

import asyncio
import contextlib
import logging
import time
import uuid

from fastapi import APIRouter, Query, WebSocket, WebSocketDisconnect
from starlette.websockets import WebSocketState

from ..video import get_lipsync_mode
from ..video.avatar_manager import get_avatar
from ..video.protocol import ClientMessage, ServerMessage
from ..video.video_chat_logger import session_id_var, setup_chat_and_3d_logger

logger = logging.getLogger(__name__)

# ── Unified file logging for all video-chat & 3D avatar modules ──────────────
setup_chat_and_3d_logger()

router = APIRouter()

# ── Concurrency limiter ────────────────────────────────────────────────────────
# Cap the number of simultaneous video-chat sessions to prevent exhausting the
# Whisper thread pool and GPU VRAM (XTTS ~700MB per concurrent load).
# Adjust MAX_CONCURRENT_SESSIONS to match your hardware capacity.
_MAX_CONCURRENT_SESSIONS = 10
_session_semaphore = asyncio.Semaphore(_MAX_CONCURRENT_SESSIONS)
# Tracks the current active session count for logging/monitoring
_active_session_count = 0


def _verify_ws_token(token: str | None) -> bool:
    """Verify JWT token for WebSocket (auth may be disabled)."""
    try:
        from ..core.auth import _ensure_jwt_secret, _jwt_decode, _read_auth

        auth = _read_auth()
        if not auth.enabled:
            return True
        if not token:
            logger.warning("Auth enabled but no token provided — rejecting WS")
            return False
        secret = _ensure_jwt_secret(auth)
        _jwt_decode(token, secret)
        return True
    except Exception as exc:
        logger.warning("Token verification failed: %s: %s", type(exc).__name__, exc)
        return False


@router.websocket("/video-chat")
async def video_chat_ws(
    websocket: WebSocket,
    token: str | None = Query(default=None),
):
    """Main WebSocket endpoint for video chat sessions."""
    global _active_session_count
    client_host = websocket.client.host if websocket.client else "unknown"

    # Verify auth token (passed as ?token=xxx query param)
    if not _verify_ws_token(token):
        logger.warning("WS auth failed — closing with 4001")
        await websocket.accept()
        await websocket.close(code=4001, reason="Unauthorized")
        return

    # Enforce concurrent session limit before accepting the connection
    if _session_semaphore._value <= 0:  # type: ignore[attr-defined]
        logger.warning(
            "Max concurrent sessions (%d) reached — rejecting connection from %s",
            _MAX_CONCURRENT_SESSIONS,
            client_host,
        )
        await websocket.accept()
        await websocket.send_text(
            ServerMessage(
                type="error",
                error=f"服务器当前并发会话已满（最多 {_MAX_CONCURRENT_SESSIONS} 路），请稍后再试。",
            ).model_dump_json()
        )
        await websocket.close(code=4029, reason="Too Many Sessions")
        return

    await _session_semaphore.acquire()
    _active_session_count += 1
    logger.info(
        "Session started: active=%d/%d host=%s",
        _active_session_count,
        _MAX_CONCURRENT_SESSIONS,
        client_host,
    )

    await websocket.accept()
    session_id = f"vc-{uuid.uuid4().hex[:12]}"
    session_id_var.set(session_id)

    # 获取 AgentRunner（已在 _app.py lifespan 中挂载到 app.state）
    runner = getattr(websocket.app.state, "runner", None)

    # Lazy-import optional services
    stt_service = None
    tts_service = None
    llm_bridge = None  # fallback: only used when runner is unavailable
    agent_bridge = None  # primary: VoiceAgentBridge wrapping full ReAct loop
    _stt_init_error_msg = ""  # 记录 STT 初始化失败原因
    _tts_init_error_msg = ""  # 记录 TTS 初始化失败原因
    lipsync_mode = get_lipsync_mode()
    # Maximum allowed size for a single WebSocket message data field (bytes)
    _MAX_MSG_DATA_SIZE = 100 * 1024  # 100 KB
    # Idle timeout: close session after 10 minutes of no messages
    _IDLE_TIMEOUT = 10 * 60  # seconds

    avatar = None  # assigned on start_session
    stt_err_notified = False  # 标记是否已通知前端 STT 不可用
    current_state = "idle"  # track session state to suppress audio during speaking
    audio_chunk_count = 0  # debug: count received audio chunks
    audio_chunk_last_log = time.monotonic()
    # Interrupt flag — set when client sends "interrupt", checked inside _run_llm_with_tts
    interrupt_event = asyncio.Event()
    # Reference to the currently running LLM+TTS task so it can be cancelled on interrupt
    _pipeline_task: asyncio.Task | None = None

    try:
        while True:
            # Guard: stop looping if the WebSocket is no longer connected
            if not _ws_is_connected(websocket):
                break

            # Apply idle timeout to receive_text
            try:
                raw = await asyncio.wait_for(
                    websocket.receive_text(),
                    timeout=_IDLE_TIMEOUT,
                )
            except TimeoutError:
                # Only send messages if connection is still alive
                if _ws_is_connected(websocket):
                    await _send(
                        websocket,
                        ServerMessage(
                            type="error",
                            error="会话空闲超时，连接已关闭。",
                        ),
                    )
                    await _send(websocket, ServerMessage(type="session_ended"))
                break

            # Log non-audio messages at INFO, audio_chunk count every 5s
            if '"audio_chunk"' not in raw[:50]:
                logger.info("WS recv msg type=%s len=%d", raw[:60], len(raw))
            else:
                audio_chunk_count += 1
                now = time.monotonic()
                if now - audio_chunk_last_log > 5.0:
                    logger.info(
                        "Received %d audio_chunks in last ~5s (state=%s)",
                        audio_chunk_count,
                        current_state,
                    )
                    audio_chunk_count = 0
                    audio_chunk_last_log = now

            try:
                msg = ClientMessage.model_validate_json(raw)
            except Exception as exc:
                logger.warning("Failed to parse ClientMessage: %s | raw=%s", exc, raw[:200])
                await _send(
                    websocket,
                    ServerMessage(
                        type="error",
                        error=f"Invalid message format: {exc}",
                    ),
                )
                continue

            # ── start_session ────────────────────────────────────────────
            if msg.type == "start_session":
                avatar = get_avatar(msg.avatar_id)

                # 决策 2C：优先使用前端传入的 session_id / user_id 与文字对话共享会话。
                # 若前端未传（旧版客户端），则使用本次 WS 连接生成的 vc-xxx session_id。
                effective_session_id = msg.session_id or session_id
                effective_user_id = msg.user_id or ""

                # 初始化 VoiceAgentBridge（ReAct 路径）
                if runner is not None:
                    from ..video.agent_bridge import VoiceAgentBridge

                    agent_bridge = VoiceAgentBridge(
                        runner=runner,
                        session_id=effective_session_id,
                        user_id=effective_user_id,
                        avatar=avatar,
                    )
                    logger.info(
                        "VoiceAgentBridge initialized (session=%s, user=%s)",
                        effective_session_id,
                        effective_user_id,
                    )
                else:
                    logger.warning(
                        "AgentRunner not available in app.state, falling back to LLMBridge (no tools/memory)"
                    )

                # 1. Send session_started immediately so avatar appears in UI
                await _send(
                    websocket,
                    ServerMessage(
                        type="session_started",
                        avatar=avatar,
                        lipsync_mode=lipsync_mode,
                    ),
                )

                # 2. Send initializing state so UI shows loading indicator
                await _send(
                    websocket,
                    ServerMessage(
                        type="state_change",
                        state="initializing",
                    ),
                )
                current_state = "initializing"

                # 3. Initialize STT and TTS in parallel for faster startup
                t_init_start = time.monotonic()
                (
                    (stt_service, _stt_init_error_msg),
                    (tts_service, _tts_init_error_msg),
                ) = await asyncio.gather(
                    _init_stt(ws=websocket),
                    _init_tts_with_preload(
                        voice_id=getattr(avatar, "voice_id", None),
                    ),
                )
                t_init_end = time.monotonic()
                logger.info(
                    "[PERF] STT+TTS parallel init: %.0fms",
                    (t_init_end - t_init_start) * 1000,
                )
                logger.info(
                    "STT service: %s",
                    type(stt_service).__name__ if stt_service else "None",
                )
                logger.info(
                    "TTS service: %s (engine=%s, voice=%s)",
                    type(tts_service).__name__ if tts_service else "None",
                    getattr(tts_service, "_engine", "N/A"),
                    getattr(tts_service, "_voice_id", "N/A"),
                )

                if stt_service is None:
                    await _send(
                        websocket,
                        ServerMessage(
                            type="error",
                            error=_stt_init_error_msg,
                        ),
                    )

                if tts_service is None:
                    await _send(
                        websocket,
                        ServerMessage(
                            type="error",
                            error=_tts_init_error_msg,
                        ),
                    )

                # 4. Models loaded — ready to listen
                await _send(
                    websocket,
                    ServerMessage(
                        type="state_change",
                        state="listening",
                    ),
                )
                current_state = "listening"

            # ── audio_chunk ──────────────────────────────────────────────
            elif msg.type == "audio_chunk":
                # Suppress audio input while AI is speaking or thinking
                if current_state in ("speaking", "thinking"):
                    continue

                if stt_service is None or msg.data is None:
                    # STT 不可用时通知前端，避免界面一直停留在"聆听中"
                    if stt_service is None and not stt_err_notified:
                        await _send(
                            websocket,
                            ServerMessage(
                                type="error",
                                error="语音识别服务未就绪，请检查 faster-whisper 依赖和模型是否正常。",
                            ),
                        )
                        stt_err_notified = True
                    continue

                # Validate message data size to prevent memory abuse
                if len(msg.data) > _MAX_MSG_DATA_SIZE:
                    logger.warning(
                        "audio_chunk data too large (%d bytes), dropping",
                        len(msg.data),
                    )
                    await _send(
                        websocket,
                        ServerMessage(
                            type="error",
                            error="音频数据过大，已丢弃。",
                        ),
                    )
                    continue

                try:
                    async for text in stt_service.feed_audio_b64(msg.data, msg.sample_rate or 16000):
                        if not text.strip():
                            continue

                        # ── 端到端链路计时开始 ──
                        t_pipeline_start = time.monotonic()
                        logger.info(
                            "[PERF] ══ Pipeline START ══ STT result: %r (session=%s)",
                            text,
                            session_id,
                        )

                        # Abort if WS closed while we were transcribing
                        if not _ws_is_connected(websocket):
                            break

                        await _send(websocket, ServerMessage(type="stt_text", data=text))
                        await _send(
                            websocket,
                            ServerMessage(type="state_change", state="thinking"),
                        )
                        current_state = "thinking"

                        # Reset STT buffer so audio captured while AI is thinking/speaking
                        # does not leak into the next recognition round.
                        if stt_service is not None:
                            stt_service.reset_buffer()

                        t_llm_start = time.monotonic()
                        logger.info(
                            "[PERF] STT→LLM handoff: %.0fms",
                            (t_llm_start - t_pipeline_start) * 1000,
                        )

                        # LLM + TTS streaming pipeline (Phase 3+4)
                        # 优先使用 VoiceAgentBridge（完整 ReAct 循环），
                        # runner 不可用时降级为 LLMBridge（兼容旧行为）。
                        if agent_bridge is None and llm_bridge is None:
                            from ..video.llm_bridge import LLMBridge

                            llm_bridge = LLMBridge(avatar=avatar)

                        # Clear interrupt flag before starting a new pipeline
                        interrupt_event.clear()

                        # Run LLM+TTS as a background task so the main loop can
                        # continue receiving messages (especially "interrupt").
                        async def _pipeline_wrapper(
                            _text: str,
                            _sid: str,
                            _ws: WebSocket,
                            _tts,
                            _agent_bridge,
                            _llm_bridge,
                            _evt: asyncio.Event,
                            _t_start: float,
                        ):
                            nonlocal current_state
                            _LLM_TTS_TIMEOUT = 120  # ReAct 可能有工具调用，延长超时
                            try:
                                resp = await asyncio.wait_for(
                                    _run_llm_with_tts(
                                        _text,
                                        _sid,
                                        _ws,
                                        _tts,
                                        agent_bridge=_agent_bridge,
                                        llm_bridge=_llm_bridge,
                                        interrupt_event=_evt,
                                    ),
                                    timeout=_LLM_TTS_TIMEOUT,
                                )
                            except asyncio.CancelledError:
                                logger.info(
                                    "LLM+TTS pipeline cancelled (session=%s, input=%r)",
                                    _sid,
                                    _text[:40],
                                )
                                return
                            except TimeoutError:
                                logger.error(
                                    "LLM+TTS pipeline timed out after %ds (session=%s, input=%r)",
                                    _LLM_TTS_TIMEOUT,
                                    _sid,
                                    _text[:40],
                                )
                                if _ws_is_connected(_ws):
                                    await _send(
                                        _ws,
                                        ServerMessage(
                                            type="error",
                                            error="AI 响应超时，请重试。",
                                        ),
                                    )
                                return
                            except Exception as exc:
                                logger.exception(
                                    "LLM+TTS error in session %s: %s",
                                    _sid,
                                    exc,
                                )
                                if _ws_is_connected(_ws):
                                    exc_type = type(exc).__name__
                                    if "AuthenticationError" in exc_type or "authentication" in str(exc).lower():
                                        err_msg = "LLM API 认证失败，请检查 API Key 是否正确。"
                                    elif "RateLimitError" in exc_type or "rate_limit" in str(exc).lower():
                                        err_msg = "LLM API 请求过于频繁，请稍后再试。"
                                    elif "ConnectionError" in exc_type or "connect" in str(exc).lower():
                                        err_msg = "LLM 服务连接失败，请检查网络和 API 地址配置。"
                                    elif "ValueError" in exc_type and "No LLM" in str(exc):
                                        err_msg = "未配置 LLM 模型，请在设置中配置 AI 模型后重试。"
                                    else:
                                        err_msg = "AI 响应出错，请重试。"
                                    await _send(
                                        _ws,
                                        ServerMessage(
                                            type="error",
                                            error=err_msg,
                                        ),
                                    )
                                return

                            t_end = time.monotonic()
                            logger.info(
                                "[PERF] ══ Pipeline END ══ total=%.0fms, response_len=%d (session=%s, input=%r)",
                                (t_end - _t_start) * 1000,
                                len(resp),
                                _sid,
                                _text[:40],
                            )

                            # If interrupted while we were running, don't switch state
                            if _evt.is_set():
                                return

                            if not _ws_is_connected(_ws):
                                return

                            if not resp:
                                logger.warning(
                                    "LLM returned empty response for STT text: %r",
                                    _text[:80],
                                )
                                await _send(
                                    _ws,
                                    ServerMessage(
                                        type="error",
                                        error="AI 未返回有效回复，请重试。",
                                    ),
                                )

                            await _send(
                                _ws,
                                ServerMessage(type="state_change", state="listening"),
                            )
                            current_state = "listening"

                        # Cancel any still-running pipeline from a previous turn
                        if _pipeline_task is not None and not _pipeline_task.done():
                            _pipeline_task.cancel()
                        _pipeline_task = asyncio.create_task(
                            _pipeline_wrapper(
                                text,
                                session_id,
                                websocket,
                                tts_service,
                                agent_bridge,
                                llm_bridge,
                                interrupt_event,
                                t_pipeline_start,
                            )
                        )

                except Exception as audio_exc:
                    logger.exception(
                        "audio_chunk processing failed in session=%s | %s: %s",
                        session_id,
                        type(audio_exc).__name__,
                        audio_exc,
                    )
                    if isinstance(audio_exc, ImportError | ModuleNotFoundError):
                        err_msg = "语音识别依赖缺失，语音输入已停用。请运行 uv sync 安装依赖后重启。"
                        logger.warning("Disabling STT for this session due to missing dependency")
                        stt_service = None
                    else:
                        err_msg = "音频处理出错，请重试。"
                    await _send(
                        websocket,
                        ServerMessage(
                            type="error",
                            error=err_msg,
                        ),
                    )
                    await _send(websocket, ServerMessage(type="state_change", state="listening"))
                    current_state = "listening"

            # ── interrupt ────────────────────────────────────────────────
            elif msg.type == "interrupt":
                logger.info(
                    "Interrupt requested (session=%s, state=%s)",
                    session_id,
                    current_state,
                )
                # Signal the running LLM+TTS pipeline to stop producing output
                interrupt_event.set()
                # Cancel the background pipeline task
                if _pipeline_task is not None and not _pipeline_task.done():
                    _pipeline_task.cancel()
                    _pipeline_task = None
                # Reset STT buffer to discard any audio captured during speaking
                if stt_service is not None:
                    stt_service.reset_buffer()
                await _send(websocket, ServerMessage(type="state_change", state="listening"))
                current_state = "listening"

            # ── mute ────────────────────────────────────────────────────
            elif msg.type == "mute":
                is_muting = msg.data == "on"
                # When user mutes, flush any pending audio in STT buffer
                if is_muting and stt_service is not None:
                    try:
                        async for text in stt_service.flush():
                            if not text.strip():
                                continue
                            if not _ws_is_connected(websocket):
                                break
                            await _send(websocket, ServerMessage(type="stt_text", data=text))
                            await _send(
                                websocket,
                                ServerMessage(type="state_change", state="thinking"),
                            )
                            current_state = "thinking"
                            if agent_bridge is None and llm_bridge is None:
                                from ..video.llm_bridge import LLMBridge

                                llm_bridge = LLMBridge(avatar=avatar)
                            interrupt_event.clear()
                            try:
                                llm_response = await asyncio.wait_for(
                                    _run_llm_with_tts(
                                        text,
                                        session_id,
                                        websocket,
                                        tts_service,
                                        agent_bridge=agent_bridge,
                                        llm_bridge=llm_bridge,
                                        interrupt_event=interrupt_event,
                                    ),
                                    timeout=120,
                                )
                            except TimeoutError:
                                logger.error(
                                    "LLM+TTS timed out on mute-flush (session=%s)",
                                    session_id,
                                )
                                await _send(
                                    websocket,
                                    ServerMessage(
                                        type="error",
                                        error="AI 响应超时，请重试。",
                                    ),
                                )
                                llm_response = ""
                            if not _ws_is_connected(websocket):
                                break
                            if not llm_response:
                                await _send(
                                    websocket,
                                    ServerMessage(
                                        type="error",
                                        error="AI 未返回有效回复，请重试。",
                                    ),
                                )
                            await _send(
                                websocket,
                                ServerMessage(type="state_change", state="listening"),
                            )
                            current_state = "listening"
                    except Exception as flush_exc:
                        logger.warning("STT flush on mute failed: %s", flush_exc)
                        await _send(
                            websocket,
                            ServerMessage(
                                type="error",
                                error="处理静音前的语音时出错，本段语音可能未被识别。",
                            ),
                        )
                        await _send(
                            websocket,
                            ServerMessage(type="state_change", state="listening"),
                        )
                        current_state = "listening"

            # ── end_session ──────────────────────────────────────────────
            elif msg.type == "end_session":
                # Only send session_ended if connection is still alive
                if _ws_is_connected(websocket):
                    await _send(websocket, ServerMessage(type="session_ended"))
                break

    except WebSocketDisconnect:
        logger.info("Client disconnected: session=%s host=%s", session_id, client_host)
    except RuntimeError as exc:
        # Starlette raises RuntimeError when receive_text() is called on
        # a WebSocket that is already closed / was never accepted.
        logger.warning("RuntimeError in video_chat_ws session=%s: %s", session_id, exc)
    except Exception as exc:
        logger.exception(
            "Unexpected error in video_chat_ws session=%s | %s: %s",
            session_id,
            type(exc).__name__,
            exc,
        )
        with contextlib.suppress(Exception):
            await _send(websocket, ServerMessage(type="error", error=str(exc)))
    finally:
        # Cancel any running LLM+TTS pipeline task
        if _pipeline_task is not None and not _pipeline_task.done():
            _pipeline_task.cancel()
        if stt_service is not None:
            await _cleanup_stt(stt_service)
        _session_semaphore.release()
        _active_session_count -= 1
        logger.info(
            "Session ended: active=%d/%d session=%s",
            _active_session_count,
            _MAX_CONCURRENT_SESSIONS,
            session_id,
        )


# ── Helpers ───────────────────────────────────────────────────────────────────


def _ws_is_connected(ws: WebSocket) -> bool:
    """Check if the WebSocket is still in a sendable state."""
    return ws.client_state == WebSocketState.CONNECTED and ws.application_state == WebSocketState.CONNECTED


async def _send(ws: WebSocket, msg: ServerMessage) -> bool:
    """Send a message; return False if the connection is dead."""
    if not _ws_is_connected(ws):
        logger.warning(
            "_send skipped (type=%s): WebSocket not connected (state=%s/%s)",
            msg.type,
            ws.client_state,
            ws.application_state,
        )
        return False
    try:
        payload = msg.model_dump_json()
        await ws.send_text(payload)
        return True
    except Exception as exc:
        logger.warning("_send failed (type=%s): %s", msg.type, exc)
        return False


async def _init_stt(ws=None):
    """Try to import and initialise STTService; return (service, error_msg).

    Model loading is wrapped in a timeout to prevent the WebSocket message loop
    from being blocked indefinitely if the model lock is contended or the model
    download hangs.

    If the model is not cached (first-time download), a status message is sent
    to the frontend via *ws* so the user sees "正在下载语音模型..." instead of
    just a generic spinner.
    """
    _MODEL_LOAD_TIMEOUT_CACHED = 30  # seconds — model already on disk
    _MODEL_LOAD_TIMEOUT_DOWNLOAD = 300  # seconds — first-time download (~145MB)
    try:
        from ..video.stt_service import (
            STTService,  # Phase 2
            _WhisperModelSingleton,
        )

        svc = STTService()

        # Check if model needs to be downloaded
        is_cached = _WhisperModelSingleton._is_model_cached(svc._whisper._model_size)
        timeout = _MODEL_LOAD_TIMEOUT_CACHED if is_cached else _MODEL_LOAD_TIMEOUT_DOWNLOAD

        if not is_cached and ws is not None:
            await _send(
                ws,
                ServerMessage(
                    type="state_change",
                    state="initializing",
                    data="downloading_stt",
                ),
            )

        # Load model in background thread with timeout
        loop = asyncio.get_event_loop()
        await asyncio.wait_for(
            loop.run_in_executor(None, svc._load_model),
            timeout=timeout,
        )
        return svc, ""
    except TimeoutError:
        msg = "语音识别模型加载超时，语音输入暂不可用。请重新开始会话。"
        logger.error(
            "STT model loading timed out — the model lock may be "
            "deadlocked from a previous session. STT will be unavailable.",
        )
        return None, msg
    except ImportError as exc:
        msg = "语音识别模块未安装（faster-whisper），语音输入暂不可用。请运行 uv sync 安装依赖后重启。"
        logger.warning("STT unavailable (faster-whisper not installed): %s", exc)
        return None, msg
    except Exception as exc:
        msg = f"语音识别服务初始化失败，语音输入暂不可用。错误：{exc}"
        logger.exception("STT init failed: %s", exc)
        return None, msg


async def _cleanup_stt(stt_service) -> None:
    try:
        if hasattr(stt_service, "close"):
            await stt_service.close()
    except Exception:
        pass


async def _init_tts(voice_id=None):
    """Try to import and initialise TTSService; return (service, error_msg)."""
    try:
        from ..video.tts_service import TTSService  # Phase 4

        svc = TTSService(voice_id=voice_id)
        return svc, ""
    except ImportError as exc:
        msg = "语音合成模块未安装，AI 将无法朗读回复（文字回复仍正常）。"
        logger.warning("TTS unavailable: %s", exc)
        return None, msg
    except Exception as exc:
        msg = f"语音合成服务初始化失败，AI 将无法朗读回复（文字回复仍正常）。错误：{exc}"
        logger.exception("TTS init failed: %s", exc)
        return None, msg


async def _init_tts_with_preload(voice_id=None):
    """Initialize TTSService and eagerly preload the engine model.

    This avoids first-call latency when the user's first TTS request triggers
    a heavy model load (Kokoro ~300MB, XTTS ~700MB).
    """
    try:
        from ..video.tts_service import TTSService

        svc = TTSService(voice_id=voice_id)
        await svc.preload()
        return svc, ""
    except ImportError as exc:
        msg = "语音合成模块未安装，AI 将无法朗读回复（文字回复仍正常）。"
        logger.warning("TTS unavailable: %s", exc)
        return None, msg
    except Exception as exc:
        msg = f"语音合成服务初始化失败，AI 将无法朗读回复（文字回复仍正常）。错误：{exc}"
        logger.exception("TTS init+preload failed: %s", exc)
        return None, msg


async def _run_llm_with_tts(
    user_text: str,
    session_id: str,
    ws: WebSocket,
    tts_service,
    agent_bridge=None,
    llm_bridge=None,
    interrupt_event: asyncio.Event | None = None,
) -> str:
    """Stream LLM response with concurrent TTS synthesis.

    优先使用 agent_bridge（VoiceAgentBridge，完整 ReAct 循环），
    不可用时降级为 llm_bridge（LLMBridge，直接调 LLM）。

    As LLM streams text, sentences are detected via SentenceSplitter and
    dispatched to TTS as asyncio Tasks — the LLM consumer loop does NOT
    await each TTS call sequentially.  This means:

      LLM chunk N+1 is processed while TTS for sentence N is still running,
      reducing overall tail latency by 30-50% on multi-sentence responses.

    Ordering is preserved by collecting TTS tasks in submission order and
    awaiting them in sequence before the function returns (so the caller's
    timeout still works correctly).

    ``interrupt_event`` if set, signals that the user requested interrupt;
    we should stop producing output as soon as possible.
    """
    from ..video.sentence_splitter import SentenceSplitter

    def _interrupted() -> bool:
        return interrupt_event is not None and interrupt_event.is_set()

    # 选择 bridge：VoiceAgentBridge 优先，降级 LLMBridge，最后兜底新建 LLMBridge
    if agent_bridge is not None:
        active_bridge = agent_bridge

        # VoiceAgentBridge.get_response 只需 user_text 参数
        async def _get_chunks():
            async for chunk in active_bridge.get_response(user_text=user_text):
                yield chunk
    else:
        from ..video.llm_bridge import LLMBridge

        active_bridge = llm_bridge or LLMBridge()

        # LLMBridge.get_response 需要 session_id
        async def _get_chunks():
            async for chunk in active_bridge.get_response(user_text=user_text, session_id=session_id):
                yield chunk

    splitter = SentenceSplitter()
    full_response = ""
    chunk_count = 0
    tts_chunks = 0
    first_tts_sent = False
    t_func_start = time.monotonic()
    t_first_llm_chunk = None
    t_first_tts_audio = None
    t_last_tts_audio = None

    # Pending TTS tasks (asyncio.Task list) — submitted during LLM streaming,
    # awaited in order after the LLM loop finishes.
    pending_tts_tasks: list[asyncio.Task] = []

    # ── TTS ordering mechanism ────────────────────────────────────────────
    # TTS synthesis runs concurrently (sentence N+1 synthesizes while N is
    # still going), but audio must be SENT to the WebSocket in strict
    # sentence order.  We use an event-chain: each task gets a "ready"
    # event it must wait on before sending, and signals the next task's
    # event after it finishes sending.  This keeps synthesis parallel but
    # sending sequential.
    _next_send_ready = asyncio.Event()
    _next_send_ready.set()  # first task can send immediately

    async def _synth_and_send(sentence: str, my_turn: asyncio.Event, next_turn: asyncio.Event) -> int:
        """Synthesize one sentence, wait for ordering turn, then send audio.

        ``my_turn``  — Event to await before sending (set by the previous task).
        ``next_turn`` — Event to signal after we finish sending (unblocks the next task).
        """
        nonlocal first_tts_sent, t_first_tts_audio, t_last_tts_audio
        sent = 0
        audio_chunks: list[str] = []
        try:
            if tts_service is None or not sentence.strip():
                return sent
            # Check interrupt before starting TTS for this sentence
            if _interrupted():
                return sent

            # Phase 1: Synthesize (can overlap with other tasks)
            try:
                async for audio_b64 in tts_service.synthesize_sentence(sentence):
                    if _interrupted():
                        break
                    audio_chunks.append(audio_b64)
            except Exception as exc:
                logger.error("TTS error for sentence %r: %s", sentence[:40], exc)
                if not _interrupted():
                    await _send(
                        ws,
                        ServerMessage(
                            type="error",
                            error="语音合成失败，文字回复仍可正常查看。",
                        ),
                    )
                # Don't continue further processing for this sentence
                return sent

            # Phase 2: Wait for our turn to send (preserves sentence order)
            await my_turn.wait()

            if _interrupted() or not _ws_is_connected(ws):
                return sent

            if not first_tts_sent and audio_chunks:
                # Switch to speaking state on first TTS output
                await _send(ws, ServerMessage(type="state_change", state="speaking"))
                first_tts_sent = True

            # Send all audio chunks for this sentence
            for audio_b64 in audio_chunks:
                if not _ws_is_connected(ws) or _interrupted():
                    break
                await _send(ws, ServerMessage(type="tts_audio", data=audio_b64))
                sent += 1
                t_now = time.monotonic()
                if t_first_tts_audio is None:
                    t_first_tts_audio = t_now
                    logger.info(
                        "[PERF] First TTS audio sent: %.0fms after LLM+TTS start",
                        (t_first_tts_audio - t_func_start) * 1000,
                    )
                t_last_tts_audio = t_now

            return sent
        finally:
            # Always signal the next task, even on error/cancel, to prevent
            # downstream tasks from hanging on my_turn.wait() forever.
            next_turn.set()

    def _create_tts_task(sentence: str) -> None:
        """Create a TTS task with proper ordering events."""
        nonlocal _next_send_ready
        my_turn = _next_send_ready
        next_turn = asyncio.Event()
        _next_send_ready = next_turn
        task = asyncio.create_task(_synth_and_send(sentence, my_turn, next_turn))
        pending_tts_tasks.append(task)

    try:
        async for chunk in _get_chunks():
            # Check interrupt before processing each LLM chunk
            if _interrupted():
                logger.info("LLM streaming interrupted (session=%s)", session_id)
                break

            full_response += chunk
            chunk_count += 1
            if chunk_count == 1:
                t_first_llm_chunk = time.monotonic()
                logger.info(
                    "[PERF] First LLM chunk in _run_llm_with_tts: %.0fms",
                    (t_first_llm_chunk - t_func_start) * 1000,
                )
            await _send(ws, ServerMessage(type="llm_text", data=chunk))

            # Feed chunk to sentence splitter; fire TTS tasks concurrently
            # (do NOT await here — let LLM streaming continue in parallel)
            for sentence in splitter.feed(chunk):
                if not _ws_is_connected(ws) or _interrupted():
                    break
                _create_tts_task(sentence)

            if not _ws_is_connected(ws):
                break

        # Flush remaining text in splitter buffer (skip if interrupted)
        if not _interrupted():
            for sentence in splitter.flush():
                if not _ws_is_connected(ws) or _interrupted():
                    break
                _create_tts_task(sentence)

        # Await all TTS tasks in submission order so exceptions are surfaced
        # before we return (audio was already sent in order via event chain).
        # If interrupted, cancel pending tasks instead.
        for task in pending_tts_tasks:
            if _interrupted() and not task.done():
                task.cancel()
                continue
            try:
                tts_chunks += await task
            except asyncio.CancelledError:
                pass
            except Exception as exc:
                logger.warning("TTS task raised: %s", exc)

        t_func_end = time.monotonic()
        logger.info(
            "[PERF] LLM+TTS pipeline summary: total=%.0fms | "
            "first_llm=%.0fms | first_tts=%.0fms | last_tts=%.0fms | "
            "llm_chunks=%d, tts_chunks=%d, response_len=%d%s",
            (t_func_end - t_func_start) * 1000,
            ((t_first_llm_chunk - t_func_start) * 1000) if t_first_llm_chunk else 0,
            ((t_first_tts_audio - t_func_start) * 1000) if t_first_tts_audio else 0,
            ((t_last_tts_audio - t_func_start) * 1000) if t_last_tts_audio else 0,
            chunk_count,
            tts_chunks,
            len(full_response),
            " [INTERRUPTED]" if _interrupted() else "",
        )
    except ImportError as exc:
        logger.exception("LLMBridge import failed: %s", exc)
        await _send(ws, ServerMessage(type="error", error="LLM 模块加载失败，请检查依赖安装。"))
    except Exception as exc:
        # Cancel any still-running TTS tasks to avoid dangling coroutines
        for task in pending_tts_tasks:
            if not task.done():
                task.cancel()
        logger.exception(
            "LLM+TTS error in session %s | %s: %s",
            session_id,
            type(exc).__name__,
            exc,
        )
        # 根据异常类型给出更友好的提示
        exc_type = type(exc).__name__
        if "AuthenticationError" in exc_type or "authentication" in str(exc).lower():
            err_msg = "LLM API 认证失败，请检查 API Key 是否正确。"
        elif "RateLimitError" in exc_type or "rate_limit" in str(exc).lower():
            err_msg = "LLM API 请求过于频繁，请稍后再试。"
        elif "ConnectionError" in exc_type or "connect" in str(exc).lower():
            err_msg = "LLM 服务连接失败，请检查网络和 API 地址配置。"
        elif "ValueError" in exc_type and "No LLM" in str(exc):
            err_msg = "未配置 LLM 模型，请在设置中配置 AI 模型后重试。"
        else:
            err_msg = "AI 响应出错，请重试。"
        await _send(ws, ServerMessage(type="error", error=err_msg))

    return full_response
