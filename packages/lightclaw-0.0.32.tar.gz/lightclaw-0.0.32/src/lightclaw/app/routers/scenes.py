"""Scenes API – list and retrieve pre-built scene packs."""

from __future__ import annotations

import json
import logging
from pathlib import Path

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/scenes", tags=["scenes"])

# Scenes are stored under src/lightclaw/agent/scenes/<scene-id>/
# Each scene directory contains a manifest.json and several .md files.
_SCENES_DIR = Path(__file__).resolve().parent.parent.parent / "agent" / "scenes"


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------


class SceneLabel(BaseModel):
    """Localised label."""

    zh: str = ""
    en: str = ""


class SceneSummary(BaseModel):
    """Scene summary returned by the list endpoint (no file contents)."""

    id: str
    label: SceneLabel
    description: SceneLabel
    icon_name: str = ""
    color: str = ""
    file_count: int = 0


class SceneFile(BaseModel):
    """A single file inside a scene pack."""

    path: str = Field(
        ...,
        description="Relative path, e.g. 'SOUL.md' or 'skills/video-script/SKILL.md'",
    )
    content: str = Field(..., description="File content (UTF-8 text)")


class SceneDetail(SceneSummary):
    """Full scene detail including file contents."""

    files: list[SceneFile] = []


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _load_manifest(scene_dir: Path) -> dict | None:
    """Load and parse manifest.json from *scene_dir*."""
    manifest_path = scene_dir / "manifest.json"
    if not manifest_path.is_file():
        return None
    try:
        with manifest_path.open("r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        logger.warning("Failed to parse manifest: %s", manifest_path, exc_info=True)
        return None


def _build_summary(manifest: dict) -> SceneSummary:
    """Build a SceneSummary from a parsed manifest dict."""
    label = manifest.get("label", {})
    desc = manifest.get("description", {})
    files = manifest.get("files", [])
    return SceneSummary(
        id=manifest["id"],
        label=SceneLabel(zh=label.get("zh", ""), en=label.get("en", "")),
        description=SceneLabel(zh=desc.get("zh", ""), en=desc.get("en", "")),
        icon_name=manifest.get("icon_name", ""),
        color=manifest.get("color", ""),
        file_count=len(files),
    )


def _read_scene_files(scene_dir: Path, manifest: dict) -> list[SceneFile]:
    """Read file contents listed in the manifest."""
    result: list[SceneFile] = []
    for rel_path in manifest.get("files", []):
        file_path = scene_dir / rel_path
        if not file_path.is_file():
            logger.warning("Scene file not found: %s", file_path)
            continue
        try:
            content = file_path.read_text(encoding="utf-8")
        except Exception:
            logger.warning("Failed to read scene file: %s", file_path, exc_info=True)
            continue
        result.append(SceneFile(path=rel_path, content=content))
    return result


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get(
    "",
    response_model=list[SceneSummary],
    summary="List all available scenes",
    description="Return metadata for every scene pack (without file contents).",
)
async def list_scenes() -> list[SceneSummary]:
    """List available scene packs."""
    if not _SCENES_DIR.is_dir():
        return []

    summaries: list[SceneSummary] = []
    for entry in sorted(_SCENES_DIR.iterdir(), key=lambda p: p.name):
        if not entry.is_dir():
            continue
        manifest = _load_manifest(entry)
        if manifest is None:
            continue
        try:
            summaries.append(_build_summary(manifest))
        except Exception:
            logger.warning("Skipping scene: %s", entry.name, exc_info=True)
    return summaries


@router.get(
    "/{scene_id}",
    response_model=SceneDetail,
    summary="Get a scene with full file contents",
    description="Return scene metadata together with the content of every file.",
)
async def get_scene(scene_id: str) -> SceneDetail:
    """Return full scene detail including file contents."""
    scene_dir = (_SCENES_DIR / scene_id).resolve()

    # Path traversal check
    if not str(scene_dir).startswith(str(_SCENES_DIR.resolve())):
        raise HTTPException(status_code=400, detail="Invalid scene id")

    if not scene_dir.is_dir():
        raise HTTPException(status_code=404, detail=f"Scene not found: {scene_id}")

    manifest = _load_manifest(scene_dir)
    if manifest is None:
        raise HTTPException(status_code=404, detail=f"Scene manifest not found: {scene_id}")

    summary = _build_summary(manifest)
    files = _read_scene_files(scene_dir, manifest)

    return SceneDetail(
        **summary.model_dump(),
        files=files,
    )
