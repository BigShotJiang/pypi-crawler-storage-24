"""Workspace router — aggregates tree, files, and archive sub-routers."""

from fastapi import APIRouter

from .archive import router as archive_router
from .files import router as files_router
from .tree import router as tree_router

router = APIRouter(prefix="/workspace", tags=["workspace"])
router.include_router(tree_router)
router.include_router(files_router)
router.include_router(archive_router)

__all__ = ["router"]
