"""Workspace file read/write API endpoints."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from ....constant import WORKING_DIR
from ...core import auth as auth_mod
from ...file_store import verify_signed_access

router = APIRouter()

# Image extensions supported for preview
IMAGE_EXTENSIONS = {
    ".png",
    ".jpg",
    ".jpeg",
    ".gif",
    ".webp",
    ".svg",
    ".bmp",
    ".ico",
    ".tiff",
    ".tif",
    ".avif",
}

IMAGE_MIME_TYPES = {
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif": "image/gif",
    ".webp": "image/webp",
    ".svg": "image/svg+xml",
    ".bmp": "image/bmp",
    ".ico": "image/x-icon",
    ".tiff": "image/tiff",
    ".tif": "image/tiff",
    ".avif": "image/avif",
}

# Max image size for preview (10 MB)
MAX_IMAGE_SIZE = 10 * 1024 * 1024

VIEWABLE_EXTENSIONS = {
    ".md",
    ".json",
    ".env",
    # Source code
    ".py",
    ".js",
    ".jsx",
    ".ts",
    ".tsx",
    ".html",
    ".css",
    ".less",
    ".scss",
    ".sass",
    # Config / data
    ".yaml",
    ".yml",
    ".toml",
    ".ini",
    ".cfg",
    ".conf",
    ".xml",
    ".csv",
    # Shell / scripts
    ".sh",
    ".bash",
    ".zsh",
    ".bat",
    ".ps1",
    # Others
    ".sql",
    ".graphql",
    ".gql",
    ".rs",
    ".go",
    ".java",
    ".kt",
    ".c",
    ".cpp",
    ".h",
    ".hpp",
    ".swift",
    ".rb",
    ".php",
    ".lua",
    ".r",
    ".txt",
    ".log",
    ".dockerfile",
}

# .env is read-only; all other viewable extensions are editable
EDITABLE_EXTENSIONS = VIEWABLE_EXTENSIONS - {".env"}

# Special filenames viewable regardless of extension
VIEWABLE_FILENAMES = {
    "dockerfile",
    "makefile",
    ".gitignore",
    ".dockerignore",
    ".editorconfig",
    ".prettierrc",
    ".eslintrc",
}

# Max file size for viewing (1 MB)
MAX_VIEW_SIZE = 1 * 1024 * 1024


class FileContent(BaseModel):
    """Response for file content reading."""

    name: str
    path: str
    content: str
    size: int


class SaveFileRequest(BaseModel):
    """Request body for saving a file."""

    path: str = Field(..., description="Relative path to the file within WORKING_DIR")
    content: str = Field(..., description="New file content")


@router.get(
    "/file",
    response_model=FileContent,
    summary="Read a workspace file",
    description="Read the text content of a file in WORKING_DIR. Supports source code, config, and text files.",
)
async def read_workspace_file(
    path: str = Query(..., description="Relative path to the file within WORKING_DIR"),
) -> FileContent:
    """Read a single file from the workspace (read-only)."""
    # Resolve and validate path
    target = (WORKING_DIR / path).resolve()
    if not str(target).startswith(str(WORKING_DIR.resolve())):
        raise HTTPException(status_code=400, detail="Invalid path: traversal detected")
    if not target.is_file():
        raise HTTPException(status_code=404, detail=f"File not found: {path}")

    name_lower = target.name.lower()
    ext = target.suffix.lower()
    # For dotfiles like ".env", Path.suffix returns "" while Path.name is ".env"
    # Treat the full name as the extension in that case
    effective_ext = ext if ext else name_lower
    if name_lower not in VIEWABLE_FILENAMES and effective_ext not in VIEWABLE_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file type: {effective_ext or target.name}",
        )

    stat = target.stat()
    if stat.st_size > MAX_VIEW_SIZE:
        raise HTTPException(
            status_code=400,
            detail=(f"File too large to view: {stat.st_size / 1024:.1f} KB (max {MAX_VIEW_SIZE / 1024:.0f} KB)"),
        )

    try:
        content = target.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        raise HTTPException(status_code=400, detail="File is not valid UTF-8 text") from None

    return FileContent(
        name=target.name,
        path=path,
        content=content,
        size=stat.st_size,
    )


@router.put(
    "/file",
    response_model=FileContent,
    summary="Save a workspace file",
    description="Save (write) the text content of a file in WORKING_DIR. .env files are read-only.",
)
async def save_workspace_file(
    body: SaveFileRequest,
) -> FileContent:
    """Save a single file in the workspace."""
    path = body.path
    # Resolve and validate path
    target = (WORKING_DIR / path).resolve()
    if not str(target).startswith(str(WORKING_DIR.resolve())):
        raise HTTPException(status_code=400, detail="Invalid path: traversal detected")

    name_lower = target.name.lower()
    ext = target.suffix.lower()
    effective_ext = ext if ext else name_lower
    if name_lower not in VIEWABLE_FILENAMES and effective_ext not in EDITABLE_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=f"File type {effective_ext or target.name} is not editable.",
        )

    # Create parent directories if needed
    target.parent.mkdir(parents=True, exist_ok=True)

    # Write the file
    try:
        target.write_text(body.content, encoding="utf-8")
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to write file: {exc}",
        ) from exc

    stat = target.stat()
    return FileContent(
        name=target.name,
        path=path,
        content=body.content,
        size=stat.st_size,
    )


@router.get(
    "/image",
    summary="Serve a workspace image file",
    description="Stream a binary image from WORKING_DIR with the correct Content-Type header.",
)
async def read_workspace_image(
    path: str = Query(..., description="Relative path to the image within WORKING_DIR"),
    exp: int | str | None = Query(None, description="Signature expiry timestamp"),
    sig: str | None = Query(None, description="HMAC-SHA256 signature"),
) -> FileResponse:
    """Serve an image file directly so it can be used as <img src> URL.

    Supports two modes:
    1. With Bearer token in Authorization header (for web dashboard)
    2. With exp+sig query params (for external channels)
    """
    # Verify signature if provided (for external channels, e.g. Telegram, Discord)
    auth = auth_mod._read_auth()
    if auth.enabled and (exp is not None or sig is not None) and not verify_signed_access(path, exp, sig):
        raise HTTPException(status_code=403, detail="Invalid or expired signature")

    target = (WORKING_DIR / path).resolve()
    if not str(target).startswith(str(WORKING_DIR.resolve())):
        raise HTTPException(status_code=400, detail="Invalid path: traversal detected")
    if not target.is_file():
        raise HTTPException(status_code=404, detail=f"File not found: {path}")

    ext = target.suffix.lower()
    if ext not in IMAGE_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported image type: {ext or target.name}",
        )

    stat = target.stat()
    if stat.st_size > MAX_IMAGE_SIZE:
        raise HTTPException(
            status_code=400,
            detail=f"Image too large to preview: {stat.st_size / 1024 / 1024:.1f} MB (max {MAX_IMAGE_SIZE / 1024 / 1024:.0f} MB)",
        )

    mime_type = IMAGE_MIME_TYPES.get(ext, "application/octet-stream")
    return FileResponse(path=str(target), media_type=mime_type, filename=target.name)
