"""Workspace file tree API endpoints."""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel

from ....constant import WORKING_DIR

router = APIRouter()


class FileTreeNode(BaseModel):
    """A node in the workspace file tree."""

    name: str
    path: str
    is_dir: bool
    size: int = 0
    modified_time: str = ""
    children: list[FileTreeNode] = []


def _list_dir_shallow(root: Path, base: Path, depth: int = 1) -> list[FileTreeNode]:
    """List children of *root*.

    Parameters
    ----------
    root:
        The directory to list.
    base:
        The base directory used to compute relative paths.
    depth:
        How many levels deep to recurse.  ``1`` means direct children only
        (the previous behaviour).  ``2`` means children + grandchildren, etc.
    """
    nodes: list[FileTreeNode] = []
    if not root.is_dir():
        return nodes
    for entry in sorted(root.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower())):
        # Skip macOS resource-fork files (._*) and common hidden metadata
        if entry.name.startswith("._") or entry.name == ".DS_Store":
            continue
        rel = entry.relative_to(base).as_posix()
        if entry.is_dir():
            children: list[FileTreeNode] = []
            if depth > 1:
                children = _list_dir_shallow(entry, base, depth - 1)
            nodes.append(
                FileTreeNode(
                    name=entry.name,
                    path=rel,
                    is_dir=True,
                    children=children,
                )
            )
        else:
            stat = entry.stat()
            nodes.append(
                FileTreeNode(
                    name=entry.name,
                    path=rel,
                    is_dir=False,
                    size=stat.st_size,
                    modified_time=datetime.fromtimestamp(stat.st_mtime, tz=UTC).isoformat(),
                )
            )
    return nodes


@router.get(
    "/tree",
    response_model=list[FileTreeNode],
    summary="Get workspace file tree (two levels)",
    description=(
        "Return children of WORKING_DIR with one extra level of nesting. "
        "Use /workspace/tree-children to expand deeper subdirectories on demand."
    ),
)
async def get_workspace_tree() -> list[FileTreeNode]:
    """Return workspace directory listing with two levels of depth."""
    if not WORKING_DIR.is_dir():
        raise HTTPException(
            status_code=404,
            detail=f"WORKING_DIR does not exist: {WORKING_DIR}",
        )
    return _list_dir_shallow(WORKING_DIR, WORKING_DIR)


@router.get(
    "/tree-children",
    response_model=list[FileTreeNode],
    summary="Get children of a directory",
    description="Return the direct children of a subdirectory inside WORKING_DIR.",
)
async def get_tree_children(
    path: str = Query(..., description="Relative directory path within WORKING_DIR"),
) -> list[FileTreeNode]:
    """Return direct children of a subdirectory (lazy-load on expand)."""
    target = (WORKING_DIR / path).resolve()
    if not str(target).startswith(str(WORKING_DIR.resolve())):
        raise HTTPException(status_code=400, detail="Invalid path: traversal detected")
    if not target.is_dir():
        raise HTTPException(status_code=404, detail=f"Directory not found: {path}")
    return _list_dir_shallow(target, WORKING_DIR)
