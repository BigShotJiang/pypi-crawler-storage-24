"""Workspace archive (download/upload/sync) API endpoints."""

from __future__ import annotations

import io
import shutil
import tempfile
import zipfile
from datetime import UTC, datetime
from pathlib import Path

from fastapi import APIRouter, File, HTTPException, UploadFile
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from ....constant import WORKING_DIR

router = APIRouter()

# 导出时排除的顶级目录和文件模式
# 这些目录/文件体积大或不需要迁移（如本地模型、会话数据、备份包等）
_EXPORT_EXCLUDE_DIRS = {
    "models",  # 本地模型文件，体积很大
    "sessions",  # 会话数据，不需要迁移
    "__MACOSX",  # macOS 资源文件
    "uploads",  # 用户上传的临时文件
    "embedding_cache",  # 嵌入缓存
    "file_store",  # 文件存储缓存
}
_EXPORT_EXCLUDE_EXTENSIONS = {
    ".zip",  # 排除已有的备份 zip 文件
    ".db",  # 排除 SQLite 数据库文件
}


def _should_exclude(entry: Path, root: Path) -> bool:
    """判断一个文件/目录是否应该从导出中排除。"""
    rel = entry.relative_to(root)
    # 排除顶级目录
    top_level = rel.parts[0] if rel.parts else entry.name
    if top_level in _EXPORT_EXCLUDE_DIRS:
        return True
    # 排除特定扩展名的文件
    if entry.is_file() and entry.suffix.lower() in _EXPORT_EXCLUDE_EXTENSIONS:
        return True
    # 排除隐藏文件/目录（以 . 开头，但保留 .md 等配置文件）
    return bool(entry.name.startswith("._") or entry.name == ".DS_Store")


def _dir_stats(root: Path) -> tuple[int, int]:
    """Return (file_count, total_size) for *root* recursively."""
    count = 0
    size = 0
    if root.is_dir():
        for p in root.rglob("*"):
            if p.is_file():
                count += 1
                size += p.stat().st_size
    return count, size


def _zip_directory(root: Path) -> io.BytesIO:
    """Create an in-memory zip archive of *root* and return the buffer."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        _zip_walk(zf, root, root)
    buf.seek(0)
    return buf


def _zip_walk(zf: zipfile.ZipFile, current: Path, root: Path) -> None:
    """递归遍历目录并添加到 zip，在目录层面跳过被排除的目录。"""
    for entry in sorted(current.iterdir(), key=lambda p: p.name.lower()):
        if _should_exclude(entry, root):
            continue
        arcname = entry.relative_to(root).as_posix()
        if entry.is_file():
            zf.write(entry, arcname)
        elif entry.is_dir():
            # Zip spec: directory entries end with '/'
            zf.write(entry, arcname + "/")
            _zip_walk(zf, entry, root)


def _validate_zip_data(data: bytes) -> None:
    """Ensure *data* is a valid zip without path-traversal entries."""
    if not zipfile.is_zipfile(io.BytesIO(data)):
        raise HTTPException(
            status_code=400,
            detail="Uploaded file is not a valid zip archive",
        )
    with zipfile.ZipFile(io.BytesIO(data)) as zf:
        for name in zf.namelist():
            resolved = (WORKING_DIR / name).resolve()
            if not str(resolved).startswith(str(WORKING_DIR)):
                raise HTTPException(
                    status_code=400,
                    detail=f"Zip contains unsafe path: {name}",
                )


@router.get(
    "/download",
    summary="Download workspace as zip",
    description=("Package the entire WORKING_DIR into a zip archive and stream it back as a downloadable file."),
    responses={
        200: {
            "content": {"application/zip": {}},
            "description": "Zip archive of WORKING_DIR",
        },
    },
)
async def download_workspace():
    """Stream WORKING_DIR as a zip file."""
    if not WORKING_DIR.is_dir():
        raise HTTPException(
            status_code=404,
            detail=f"WORKING_DIR does not exist: {WORKING_DIR}",
        )

    buf = _zip_directory(WORKING_DIR)

    timestamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    filename = f"lightclaw_workspace_{timestamp}.zip"

    return StreamingResponse(
        buf,
        media_type="application/zip",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
        },
    )


@router.post(
    "/upload",
    response_model=dict,
    summary="Upload zip and merge into workspace",
    description=(
        "Upload a zip archive.  Paths present in the zip are merged into "
        "WORKING_DIR (files overwritten, dirs merged).  Paths not in the zip "
        "are left unchanged (e.g. lightclaw.db, runtime dirs).  Download packs "
        "the entire WORKING_DIR; upload only overwrites/merges zip contents."
    ),
)
async def upload_workspace(  # pylint: disable=too-many-branches
    file: UploadFile = File(
        ...,
        description="Zip archive to merge into WORKING_DIR",
    ),
) -> dict:
    """
    Merge uploaded zip contents into WORKING_DIR (overwrite, do not clear).
    """

    # --- validate uploaded file ---
    if file.content_type and file.content_type not in (
        "application/zip",
        "application/x-zip-compressed",
        "application/octet-stream",
    ):
        raise HTTPException(
            status_code=400,
            detail=(f"Expected a zip file, got content-type: {file.content_type}"),
        )

    data = await file.read()
    _validate_zip_data(data)

    tmp_dir = None
    try:
        tmp_dir = Path(tempfile.mkdtemp(prefix="lightclaw_upload_"))
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            zf.extractall(tmp_dir)

        # If the zip contains a single top-level directory, use its contents
        top_entries = list(tmp_dir.iterdir())
        extract_root = tmp_dir
        if len(top_entries) == 1 and top_entries[0].is_dir():
            extract_root = top_entries[0]

        WORKING_DIR.mkdir(parents=True, exist_ok=True)

        # Merge: overwrite paths present in zip; leave others untouched
        for item in extract_root.iterdir():
            dest = WORKING_DIR / item.name
            if item.is_file():
                shutil.copy2(item, dest)
            else:
                if dest.exists() and dest.is_file():
                    dest.unlink()
                shutil.copytree(item, dest, dirs_exist_ok=True)

        return {
            "success": True,
        }

    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to merge workspace: {exc}",
        ) from exc
    finally:
        if tmp_dir and tmp_dir.is_dir():
            shutil.rmtree(tmp_dir, ignore_errors=True)


# ---------------------------------------------------------------------------
# Sync from OpenClaw
# ---------------------------------------------------------------------------


class SyncFromOpenClawRequest(BaseModel):
    """Optional body for POST /workspace/sync-from-openclaw."""

    openclaw_json_path: str | None = None
    sync_md: bool = True
    sync_config: bool = True
    dry_run: bool = False


class SyncFromOpenClawResponse(BaseModel):
    """Result of a sync-from-openclaw operation."""

    success: bool
    md_synced: int
    md_skipped: int
    skills_synced: int = 0
    config_updated: bool
    updated_fields: list[str] = []
    warnings: list[str] = []
    errors: list[str] = []


@router.post(
    "/sync-from-openclaw",
    response_model=SyncFromOpenClawResponse,
    summary="Sync workspace from OpenClaw",
    description=(
        "Pull .md files from the OpenClaw workspace directory into WORKING_DIR, "
        "and/or merge OpenClaw config fields (models, channels, agents) into "
        "lightclaw.json.  The default openclaw.json path is "
        "``~/.openclaw/openclaw.json``; override via the request body or via "
        "``openclaw.configPath`` in lightclaw.json."
    ),
)
async def sync_from_openclaw_endpoint(
    request: SyncFromOpenClawRequest = SyncFromOpenClawRequest(),
) -> SyncFromOpenClawResponse:
    """Trigger a sync from OpenClaw workspace into LightClaw WORKING_DIR."""
    from pathlib import Path

    from ...sync.openclaw_sync import sync_from_openclaw

    oc_path = Path(request.openclaw_json_path) if request.openclaw_json_path else None

    try:
        result = sync_from_openclaw(
            openclaw_json_path=oc_path,
            sync_md=request.sync_md,
            sync_config=request.sync_config,
            dry_run=request.dry_run,
        )
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Sync failed unexpectedly: {exc}",
        ) from exc

    if result.errors and not result.success:
        # Surface the first error as a 4xx/5xx where appropriate
        first = result.errors[0]
        status = 404 if "not found" in first.lower() else 500
        raise HTTPException(status_code=status, detail=first)

    return SyncFromOpenClawResponse(
        success=result.success,
        md_synced=result.md_synced,
        md_skipped=result.md_skipped,
        config_updated=result.config_updated,
        updated_fields=result.updated_fields,
        warnings=result.warnings,
        errors=result.errors,
    )
