"""Browser session and profile management REST API.

Endpoints:
    GET    /api/browser/profiles                   - List profiles
    POST   /api/browser/profiles                   - Create profile
    DELETE /api/browser/profiles/{name}             - Delete profile
    GET    /api/browser/sessions                    - List active sessions
    POST   /api/browser/sessions/{id}/handoff       - Control handoff
    GET    /api/browser/sessions/{id}/screenshot-stream - SSE screenshot stream
"""

from __future__ import annotations

import asyncio
import base64
import json
import logging
import time
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from ...agent.tools.browser.environment import detect_display_environment
from ...agent.tools.browser.session import (
    BrowserSession,
    ControlOwner,
)
from ...agent.tools.browser.shared import (
    get_profile_manager as _get_pm,
)
from ...agent.tools.browser.shared import (
    get_session_manager as _get_sm,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/browser", tags=["browser"])

# ---------------------------------------------------------------------------
# Singletons — obtained from browser.shared so that all modules
# (agent tool, REST API, WebSocket stream) share the same instances.
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class CreateProfileRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=64)


class HandoffRequest(BaseModel):
    target: str = Field(..., pattern="^(agent|user)$")
    reason: str = ""


class MouseEventRequest(BaseModel):
    """Mouse interaction event from the frontend screenshot panel."""

    action: str = Field(
        ...,
        pattern="^(click|dblclick|mousedown|mouseup|mousemove|scroll)$",
    )
    x: float = Field(..., description="X coordinate (ratio 0.0-1.0 relative to viewport)")
    y: float = Field(..., description="Y coordinate (ratio 0.0-1.0 relative to viewport)")
    button: str = Field(default="left", pattern="^(left|right|middle)$")
    scroll_x: float = Field(default=0, description="Horizontal scroll delta")
    scroll_y: float = Field(default=0, description="Vertical scroll delta")


class KeyboardEventRequest(BaseModel):
    """Keyboard interaction event from the frontend screenshot panel."""

    action: str = Field(..., pattern="^(keydown|keyup|type|press)$")
    key: str = Field(default="", description="Key name for press/keydown/keyup (e.g. Enter, Tab)")
    text: str = Field(default="", description="Text to type for action=type")


# ---------------------------------------------------------------------------
# Profile endpoints
# ---------------------------------------------------------------------------


@router.get("/profiles")
async def list_profiles() -> dict[str, Any]:
    """Return all browser profiles."""
    pm = _get_pm()
    profiles = pm.list_profiles()
    return {
        "ok": True,
        "profiles": [p.to_dict() for p in profiles],
    }


@router.post("/profiles")
async def create_profile(body: CreateProfileRequest) -> dict[str, Any]:
    """Create a new named browser profile."""
    pm = _get_pm()
    try:
        profile = pm.create_profile(body.name)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
    return {
        "ok": True,
        "profile": profile.to_dict(),
    }


@router.delete("/profiles/{name}")
async def delete_profile(name: str) -> dict[str, Any]:
    """Delete a browser profile and clean up its data."""
    pm = _get_pm()
    deleted = pm.delete_profile(name)
    if not deleted:
        raise HTTPException(status_code=404, detail=f"Profile '{name}' not found")
    return {"ok": True, "message": f"Profile '{name}' deleted"}


# ---------------------------------------------------------------------------
# Session endpoints
# ---------------------------------------------------------------------------


@router.get("/sessions")
async def list_sessions() -> dict[str, Any]:
    """Return all active browser sessions."""
    sm = _get_sm()
    env = detect_display_environment()
    sessions = sm.list_sessions()
    return {
        "ok": True,
        "environment": env,
        "sessions": [s.to_dict() for s in sessions],
    }


@router.post("/sessions/{session_id}/handoff")
async def handoff_control(
    session_id: str,
    body: HandoffRequest,
) -> dict[str, Any]:
    """Switch control between agent and user."""
    sm = _get_sm()
    session = sm.get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    target = ControlOwner.AGENT if body.target == "agent" else ControlOwner.USER
    session.handoff(target, trigger_reason=body.reason or "api_request")

    return {
        "ok": True,
        "session": session.to_dict(),
    }


@router.get("/sessions/{session_id}/screenshot-stream")
async def screenshot_stream(session_id: str, request: Request) -> StreamingResponse:
    """SSE endpoint streaming base64 PNG screenshots at ~1-2 fps."""
    sm = _get_sm()
    session = sm.get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    auth_check_counter = 0

    async def event_generator():
        """Yield SSE events with screenshot data."""
        nonlocal auth_check_counter
        while True:
            # Check if client disconnected
            if await request.is_disconnected():
                break

            frame_data = await _capture_screenshot(session)
            if frame_data:
                # Gather tabs info for the frontend
                tabs_info = _gather_tabs_info(session)

                payload_dict: dict[str, Any] = {
                    "type": "screenshot",
                    "data": frame_data,
                    "url": session.current_url,
                    "state": session.state.value,
                    "control_owner": session.control_owner.value,
                    "timestamp": time.time(),
                    "tabs": tabs_info,
                }

                # Run auth detection every ~5th frame (~7.5s)
                auth_check_counter += 1
                if auth_check_counter % 5 == 0:
                    auth_info = await _check_auth_during_stream(session)
                    if auth_info:
                        payload_dict["auth_detected"] = auth_info

                yield f"data: {json.dumps(payload_dict)}\n\n"
            else:
                # No page available — send heartbeat
                yield f"data: {json.dumps({'type': 'heartbeat'})}\n\n"

            await asyncio.sleep(1.5)  # ~1-2 fps

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


# ---------------------------------------------------------------------------
# User interaction endpoints (for headless browser remote control)
# ---------------------------------------------------------------------------


def _resolve_active_page(session: BrowserSession):
    """Get the active page from a session for interaction.

    Tries to follow the Agent's current_page_id so that screenshots,
    mouse events, and keyboard events target the same tab the Agent
    is working on.  Falls back to the first page if lookup fails.
    """
    if not session.cdp or not session.cdp.context:
        return None
    pages = session.cdp.context.pages
    if not pages:
        return None

    # Try to get Agent's current page from browser_control state
    try:
        from ...agent.tools.browser_control import _state as _agent_state

        current_pid = _agent_state.get("current_page_id")
        agent_pages = _agent_state.get("pages") or {}
        if current_pid and current_pid in agent_pages:
            pw_page = agent_pages[current_pid]
            # Verify it's still in context pages
            if pw_page in pages:
                return pw_page
    except Exception:
        pass

    # Fallback: last page (most recently opened/activated)
    return pages[-1]


@router.post("/sessions/{session_id}/mouse")
async def send_mouse_event(
    session_id: str,
    body: MouseEventRequest,
) -> dict[str, Any]:
    """Send a mouse event to the browser page.

    Coordinates are ratios (0.0-1.0) relative to the viewport dimensions.
    The server converts them to actual pixel coordinates.
    """
    sm = _get_sm()
    session = sm.get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    page = _resolve_active_page(session)
    if not page:
        raise HTTPException(status_code=400, detail="No active page")

    try:
        # Get viewport size to convert ratios to pixels
        viewport = page.viewport_size
        if not viewport:
            viewport = {"width": 1280, "height": 720}

        px_x = body.x * viewport["width"]
        px_y = body.y * viewport["height"]

        session.last_activity_at = time.time()

        if body.action == "click":
            await page.mouse.click(px_x, px_y, button=body.button)
        elif body.action == "dblclick":
            await page.mouse.dblclick(px_x, px_y, button=body.button)
        elif body.action == "mousedown":
            await page.mouse.down(button=body.button)
            await page.mouse.move(px_x, px_y)
        elif body.action == "mouseup":
            await page.mouse.move(px_x, px_y)
            await page.mouse.up(button=body.button)
        elif body.action == "mousemove":
            await page.mouse.move(px_x, px_y)
        elif body.action == "scroll":
            await page.mouse.move(px_x, px_y)
            await page.mouse.wheel(body.scroll_x, body.scroll_y)

        return {"ok": True, "action": body.action, "x": px_x, "y": px_y}
    except Exception as exc:
        logger.warning("Mouse event failed: %s", exc)
        return {"ok": False, "error": str(exc)}


@router.post("/sessions/{session_id}/keyboard")
async def send_keyboard_event(
    session_id: str,
    body: KeyboardEventRequest,
) -> dict[str, Any]:
    """Send a keyboard event to the browser page."""
    sm = _get_sm()
    session = sm.get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    page = _resolve_active_page(session)
    if not page:
        raise HTTPException(status_code=400, detail="No active page")

    try:
        session.last_activity_at = time.time()

        if body.action == "press":
            await page.keyboard.press(body.key)
        elif body.action == "keydown":
            await page.keyboard.down(body.key)
        elif body.action == "keyup":
            await page.keyboard.up(body.key)
        elif body.action == "type":
            await page.keyboard.type(body.text)

        return {"ok": True, "action": body.action}
    except Exception as exc:
        logger.warning("Keyboard event failed: %s", exc)
        return {"ok": False, "error": str(exc)}


# ---------------------------------------------------------------------------
# Tabs endpoint (for frontend tab switching)
# ---------------------------------------------------------------------------


class TabSwitchRequest(BaseModel):
    """Request to switch the active tab by page_id."""

    page_id: str = Field(..., description="The Agent-side page_id to switch to")


class TabCloseRequest(BaseModel):
    """Request to close a tab by page_id."""

    page_id: str = Field(..., description="The Agent-side page_id to close")


class TabNewRequest(BaseModel):
    """Request to open a new blank tab."""

    url: str = Field(default="about:blank", description="Optional URL to open in the new tab")


@router.get("/sessions/{session_id}/tabs")
async def get_tabs(session_id: str) -> dict[str, Any]:
    """Return all open tabs for a session with the active tab highlighted."""
    sm = _get_sm()
    session = sm.get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    return {"ok": True, "tabs": _gather_tabs_info(session)}


@router.post("/sessions/{session_id}/tabs/switch")
async def switch_tab(
    session_id: str,
    body: TabSwitchRequest,
) -> dict[str, Any]:
    """Switch the active tab (Agent-side current_page_id)."""
    sm = _get_sm()
    session = sm.get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    try:
        from ...agent.tools.browser_control import _state as _agent_state

        agent_pages = _agent_state.get("pages") or {}
        if body.page_id not in agent_pages:
            raise HTTPException(
                status_code=404,
                detail=f"Tab '{body.page_id}' not found",
            )
        _agent_state["current_page_id"] = body.page_id
        page = agent_pages[body.page_id]
        return {
            "ok": True,
            "page_id": body.page_id,
            "url": page.url,
        }
    except HTTPException:
        raise
    except Exception as exc:
        logger.warning("Tab switch failed: %s", exc)
        return {"ok": False, "error": str(exc)}


@router.post("/sessions/{session_id}/tabs/new")
async def new_tab(
    session_id: str,
    body: TabNewRequest | None = None,
) -> dict[str, Any]:
    """Create a new browser tab, optionally navigating to a URL."""
    sm = _get_sm()
    session = sm.get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    url = (body.url if body else None) or "about:blank"

    try:
        from ...agent.tools.browser_control import (
            _attach_page_listeners,
            _next_page_id,
        )
        from ...agent.tools.browser_control import (
            _state as _agent_state,
        )

        context = _agent_state.get("context")
        if not context:
            raise HTTPException(
                status_code=400,
                detail="Browser context not available",
            )
        page = await context.new_page()
        new_id = _next_page_id()
        _agent_state["refs"][new_id] = {}
        _agent_state["console_logs"][new_id] = []
        _agent_state["network_requests"][new_id] = []
        _agent_state["pending_dialogs"][new_id] = []
        _agent_state["pending_file_choosers"][new_id] = []
        _attach_page_listeners(page, new_id)
        if url and url != "about:blank":
            await page.goto(url)
        _agent_state["pages"][new_id] = page
        _agent_state["current_page_id"] = new_id
        return {
            "ok": True,
            "page_id": new_id,
            "url": page.url,
            "tabs": _gather_tabs_info(session),
        }
    except HTTPException:
        raise
    except Exception as exc:
        logger.warning("New tab failed: %s", exc)
        return {"ok": False, "error": str(exc)}


@router.post("/sessions/{session_id}/tabs/close")
async def close_tab(
    session_id: str,
    body: TabCloseRequest,
) -> dict[str, Any]:
    """Close a browser tab by page_id."""
    sm = _get_sm()
    session = sm.get_session(session_id)
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    try:
        from ...agent.tools.browser_control import _action_close

        await _action_close(body.page_id)
        return {
            "ok": True,
            "closed": body.page_id,
            "tabs": _gather_tabs_info(session),
        }
    except Exception as exc:
        logger.warning("Close tab failed: %s", exc)
        return {"ok": False, "error": str(exc)}


def _gather_tabs_info(session: BrowserSession) -> list[dict[str, Any]]:
    """Build a list of tab info dicts for API responses / SSE payloads."""
    tabs: list[dict[str, Any]] = []
    try:
        from ...agent.tools.browser_control import _state as _agent_state

        current_pid = _agent_state.get("current_page_id")
        agent_pages = _agent_state.get("pages") or {}
        for pid, page in agent_pages.items():
            try:
                tab_url = page.url
            except Exception:
                tab_url = "(unknown)"
            tabs.append(
                {
                    "page_id": pid,
                    "url": tab_url,
                    "active": pid == current_pid,
                }
            )
    except Exception:
        pass
    return tabs


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _capture_screenshot(session: BrowserSession) -> str | None:
    """Take a screenshot of the current (active) page and return base64 PNG."""
    if not session.cdp or not session.cdp.context:
        return None
    try:
        page = _resolve_active_page(session)
        if not page:
            return None
        session.current_url = page.url
        png_bytes = await page.screenshot(type="png")
        return base64.b64encode(png_bytes).decode("ascii")
    except Exception as exc:
        logger.debug("Screenshot capture failed: %s", exc)
        return None


# Track last URL we notified about to avoid repeated detections
_last_auth_notified_url: str = ""

# Negative cache: URLs confirmed as non-auth within the last 60 seconds.
# Prevents repeated expensive detection on the same content page.
_non_auth_cache: dict[str, float] = {}  # url -> expiry timestamp
_NON_AUTH_CACHE_TTL = 60.0  # seconds


async def _check_auth_during_stream(session: BrowserSession) -> dict[str, Any] | None:
    """Periodically check for auth pages during screenshot streaming.

    Uses the LLM-based detector for semantic analysis, with automatic
    fallback to keyword heuristics.  If detected, auto-handoff control
    to user and return detection info.  URL dedup avoids spamming.
    """
    global _last_auth_notified_url

    # Fast-path: skip detection if URL was recently confirmed as non-auth
    current_url = session.current_url or ""
    now = time.time()
    if current_url in _non_auth_cache and _non_auth_cache[current_url] > now:
        return None

    try:
        from ...agent.tools.browser.auth_detector_llm import LLMAuthDetector

        detector = LLMAuthDetector(session)
        result = await detector.detect()

        if not result.is_auth_page or result.confidence < 0.75:
            # Confirmed non-auth — cache the result to avoid repeated checks
            if current_url:
                _non_auth_cache[current_url] = now + _NON_AUTH_CACHE_TTL
                # Evict expired entries
                if len(_non_auth_cache) > 50:
                    _non_auth_cache.clear()
            return None

        if result.url == _last_auth_notified_url:
            return None

        _last_auth_notified_url = result.url
        # Auto-handoff to user
        if session.control_owner == ControlOwner.AGENT:
            session.request_user_control(
                reason=f"auth_detected:{result.auth_type}",
            )
        logger.info(
            "Auth page detected during stream: type=%s, url=%s, confidence=%.2f",
            result.auth_type,
            result.url,
            result.confidence,
        )
        return {
            "auth_type": result.auth_type,
            "detail": result.detail,
            "confidence": result.confidence,
            "url": result.url,
        }
    except Exception as exc:
        logger.debug("Auth detection during stream failed: %s", exc)
    return None
