"""Dashboard API: push messages for cron text bubbles on the frontend."""

from fastapi import APIRouter, Query

router = APIRouter(prefix="/dashboard", tags=["dashboard"])


@router.get("/messages")
async def get_messages(
    session_id: str | None = Query(None, description="Optional session id"),
):
    """
    Return pending push messages. Without session_id: recent messages
    (all sessions, last 60s), not consumed so every tab sees them.
    """
    from ..stores.push import get_recent, take

    if session_id:
        messages = await take(session_id)
    else:
        messages = await get_recent()
    return {"messages": messages}
