"""WebSocket endpoint for remote browser streaming.

Uses Playwright CDP ``Page.startScreencast`` to stream the browser viewport
as a sequence of JPEG frames to the web client in real-time, and forwards
user input events (mouse, keyboard, scroll) back to the browser page via
Playwright APIs.

Message protocol
----------------
Client → Server (JSON):
  {"type": "start",      "url": "<initial URL>"}
  {"type": "stop"}
  {"type": "navigate",   "url": "<new URL>"}
  {"type": "click",      "x": N, "y": N}
  {"type": "dblclick",   "x": N, "y": N}
  {"type": "mousemove",  "x": N, "y": N}
  {"type": "mousedown",  "x": N, "y": N, "button": "left"}
  {"type": "mouseup",    "x": N, "y": N, "button": "left"}
  {"type": "scroll",     "x": N, "y": N, "deltaX": N, "deltaY": N}
  {"type": "keydown",    "key": "<key name>"}
  {"type": "keyup",      "key": "<key name>"}
  {"type": "type",       "text": "<string>"}
  {"type": "resize",     "width": N, "height": N}
  {"type": "tab_switch", "tab_id": N}
  {"type": "tab_close",  "tab_id": N}
  {"type": "tab_new"}

Server → Client (JSON):
  {"type": "frame",    "data": "<base64 JPEG>", "metadata": {...}}
  {"type": "status",   "status": "browser_started|streaming|stopped|error", ...}
  {"type": "error",    "message": "<description>"}
  {"type": "tabs",     "tabs": [{"id": N, "url": "...", "title": "...", "active": bool}]}
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import time
from typing import ClassVar

from fastapi import APIRouter, Query, WebSocket, WebSocketDisconnect
from starlette.websockets import WebSocketState

logger = logging.getLogger(__name__)

router = APIRouter()

# Limit concurrent browser-stream sessions
_MAX_STREAM_SESSIONS = 3
_stream_semaphore = asyncio.Semaphore(_MAX_STREAM_SESSIONS)
_active_stream_count = 0
_sessions_lock = asyncio.Lock()


def _verify_ws_token(token: str | None) -> bool:
    """Verify JWT token for WebSocket connections."""
    try:
        from ..core.auth import _ensure_jwt_secret, _jwt_decode, _read_auth

        auth = _read_auth()
        if not auth.enabled:
            return True
        if not token:
            logger.warning("Auth enabled but no token provided — rejecting browser-stream WS")
            return False
        secret = _ensure_jwt_secret(auth)
        _jwt_decode(token, secret)
        return True
    except Exception as exc:
        logger.warning("Browser-stream token verification failed: %s: %s", type(exc).__name__, exc)
        return False


class BrowserStreamSession:
    """Manage a single browser CDP screencast streaming session with multi-tab support."""

    def __init__(self, ws: WebSocket, viewport_width: int = 1280, viewport_height: int = 720) -> None:
        self.ws = ws
        self.viewport_width = viewport_width
        self.viewport_height = viewport_height
        self._running = False
        self._playwright = None
        self._browser = None
        self._context = None

        # True when we connected to an existing Chrome via shared.py
        # (in which case stop() must NOT close the browser).
        self._reusing_chrome = False

        # Multi-tab support
        self._pages: dict[int, object] = {}  # tab_id -> Playwright page
        self._tab_titles: dict[int, str] = {}  # tab_id -> page title
        self._tab_urls: dict[int, str] = {}  # tab_id -> current url
        self._cdp_sessions: dict[int, object] = {}  # tab_id -> CDP session
        self._active_tab_id: int = 0
        self._next_tab_id: int = 0

        # Bidirectional mapping: tab_id <-> Agent page_id (e.g. "page_0")
        # Only populated in shared mode.
        self._tab_to_page_id: dict[int, str] = {}
        self._page_id_to_tab: dict[str, int] = {}

    def _alloc_tab_id(self) -> int:
        tid = self._next_tab_id
        self._next_tab_id += 1
        return tid

    @property
    def _page(self):
        """Current active page (backward-compat shorthand)."""
        return self._pages.get(self._active_tab_id)

    @property
    def _cdp_session(self):
        """Current active CDP session (backward-compat shorthand)."""
        return self._cdp_sessions.get(self._active_tab_id)

    async def start(
        self,
        url: str = "https://cloud.tencent.com",
        *,
        reuse_session: bool = True,
    ) -> None:
        """Start a browser streaming session.

        When *reuse_session* is ``True`` (the default) the method first
        attempts to connect to the Chrome process already managed by
        :pymod:`browser.shared` (launched by the Agent or a previous
        session).  This shares cookies, tabs, and login state.

        If no Chrome is running yet, ``get_or_create_browser()`` launches
        one via :class:`ChromeProcessManager` with persistent user-data-dir.

        Falls back to a standalone Playwright launch only when
        *reuse_session* is explicitly ``False``.
        """
        if reuse_session:
            await self._start_shared(url)
        else:
            await self._start_standalone(url)

    async def _start_shared(self, url: str) -> None:
        """Connect to the shared Chrome managed by :mod:`browser.shared`.

        Only registers tabs that belong to the **active** Agent session
        (identified by ``BrowserSession.page_ids``).  This prevents stale
        tabs from other sessions from leaking into the dashboard preview.

        Includes retry logic: if Chrome is not yet running (e.g. the Agent
        hasn't started a browser_use action yet), we retry up to 3 times
        with a short delay so the dashboard preview doesn't permanently
        fail on the first open.
        """
        from ...agent.tools.browser.shared import get_agent_state, get_or_create_browser

        # Retry browser connection with backoff — Chrome may not be
        # running yet if the user opens the preview before the Agent
        # starts a browser_use action.
        last_exc: Exception | None = None
        for attempt in range(3):
            try:
                _, cdp_conn, _profile = await get_or_create_browser(headless=True)
                break
            except Exception as exc:
                last_exc = exc
                logger.warning(
                    "Browser connect attempt %d/3 failed: %s",
                    attempt + 1,
                    exc,
                )
                if attempt < 2:
                    await self._send_status(
                        "connecting",
                        message=f"Connecting to browser (attempt {attempt + 2}/3)...",
                    )
                    await asyncio.sleep(1.5 * (attempt + 1))
        else:
            raise RuntimeError(f"Failed to connect to browser after 3 attempts: {last_exc}")

        self._playwright = cdp_conn.playwright
        self._browser = cdp_conn.browser
        self._context = cdp_conn.context
        self._reusing_chrome = True

        logger.info(
            "Shared browser connected: context=%s, pages=%d",
            id(self._context),
            len(self._context.pages) if self._context else 0,
        )

        # Build tab_id <-> page_id mapping from Agent state
        agent_state = get_agent_state()
        agent_pages: dict[str, object] = agent_state.get("pages", {}) if agent_state else {}
        logger.info(
            "Agent state: pages=%s, active_session_page_ids will be resolved next",
            list(agent_pages.keys()) if agent_pages else "(none)",
        )

        # Determine which page_ids belong to the active session so we
        # only show those tabs in the dashboard browser preview.
        active_session_page_ids: set[str] | None = None
        try:
            from ...agent.tools.browser.session import SessionManager

            sm = SessionManager.instance()
            if sm is not None:
                sessions = sm.list_sessions()
                if sessions:
                    # Pick the most recently created session (same logic
                    # the dashboard polling uses).
                    latest = max(sessions, key=lambda s: s.created_at)
                    if latest.page_ids:
                        active_session_page_ids = set(latest.page_ids)
        except Exception:
            pass

        # Enumerate pages already open in the shared context
        existing_pages = self._context.pages
        logger.info(
            "Existing pages in context: %d, active_session_page_ids=%s",
            len(existing_pages),
            active_session_page_ids,
        )
        if existing_pages:
            # Build a reverse lookup: Playwright Page object -> agent page_id
            page_obj_to_id: dict[int, str] = {id(p): pid for pid, p in agent_pages.items()}

            for page in existing_pages:
                # Resolve this page's agent page_id
                agent_pid = page_obj_to_id.get(id(page))

                # If we know the active session's pages, skip tabs that
                # don't belong to it (they belong to an older session).
                if active_session_page_ids is not None and agent_pid and agent_pid not in active_session_page_ids:
                    continue

                tab_id = self._alloc_tab_id()
                self._pages[tab_id] = page
                try:
                    self._tab_titles[tab_id] = await page.title() or page.url or "New Tab"
                except Exception:
                    self._tab_titles[tab_id] = page.url or "New Tab"
                self._tab_urls[tab_id] = page.url or "about:blank"
                self._attach_page_listeners(page, tab_id)

                # Map to agent page_id if known
                if agent_pid:
                    self._tab_to_page_id[tab_id] = agent_pid
                    self._page_id_to_tab[agent_pid] = tab_id

            if self._pages:
                # Activate the last registered page (most recently used)
                self._active_tab_id = max(self._pages)
            else:
                # All existing pages belonged to other sessions — create a
                # fresh tab for the current session.
                page = await self._context.new_page()
                tab_id = self._alloc_tab_id()
                self._pages[tab_id] = page
                self._tab_titles[tab_id] = "New Tab"
                self._tab_urls[tab_id] = url
                self._active_tab_id = tab_id
                self._attach_page_listeners(page, tab_id)
                self._sync_new_page_to_agent(tab_id, page)
                try:
                    await page.goto(url, wait_until="domcontentloaded", timeout=30000)
                except Exception as exc:
                    logger.warning("Initial navigation failed: %s", exc)
        else:
            # No pages yet — create one and register with Agent state
            page = await self._context.new_page()
            tab_id = self._alloc_tab_id()
            self._pages[tab_id] = page
            self._tab_titles[tab_id] = "New Tab"
            self._tab_urls[tab_id] = url
            self._active_tab_id = tab_id
            self._attach_page_listeners(page, tab_id)
            self._sync_new_page_to_agent(tab_id, page)
            try:
                await page.goto(url, wait_until="domcontentloaded", timeout=30000)
            except Exception as exc:
                logger.warning("Initial navigation failed: %s", exc)

        # Listen for NEW pages opened after this point
        self._context.on("page", self._on_new_page)

        logger.info(
            "Tab registration done: pages=%s active_tab=%d tab_to_page=%s",
            list(self._pages.keys()),
            self._active_tab_id,
            self._tab_to_page_id,
        )

        await self._send_status("browser_started")
        await self._start_screencast_for_tab(self._active_tab_id)
        await self._send_tabs()

        # Push an immediate one-shot screenshot so the client gets a
        # first frame right away without waiting for the CDP screencast
        # interval to fire.  This dramatically reduces perceived latency
        # when opening the browser preview panel.
        await self._send_screenshot_for_tab(self._active_tab_id)

    async def _start_standalone(self, url: str) -> None:
        """Launch a fresh Playwright Chromium (no shared state)."""
        from playwright.async_api import async_playwright

        self._playwright = await async_playwright().start()
        self._browser = await self._playwright.chromium.launch(
            headless=True,
            args=[
                "--disable-gpu",
                "--no-sandbox",
                "--disable-dev-shm-usage",
            ],
        )
        self._context = await self._browser.new_context(
            viewport={"width": self.viewport_width, "height": self.viewport_height},
            device_scale_factor=1,
        )
        self._reusing_chrome = False

        # Create initial tab BEFORE registering the context page listener
        # so that new_page() itself does not trigger _on_new_page
        page = await self._context.new_page()
        tab_id = self._alloc_tab_id()
        self._pages[tab_id] = page
        self._tab_titles[tab_id] = "New Tab"
        self._tab_urls[tab_id] = url
        self._active_tab_id = tab_id

        # Track URL/title changes on this page
        self._attach_page_listeners(page, tab_id)

        # Listen for NEW pages opened by target=_blank / window.open
        # registered AFTER initial page so it won't fire for the initial page
        self._context.on("page", self._on_new_page)

        await self._send_status("browser_started")

        # Navigate to the initial URL
        try:
            await page.goto(url, wait_until="domcontentloaded", timeout=30000)
        except Exception as exc:
            logger.warning("Initial navigation failed: %s", exc)

        # Start CDP screencast for the initial tab
        await self._start_screencast_for_tab(tab_id)
        await self._send_tabs()

        # Push immediate first-frame screenshot
        await self._send_screenshot_for_tab(tab_id)

    def _attach_page_listeners(self, page, tab_id: int) -> None:
        """Attach URL / title change listeners to a page."""

        def _schedule(coro):
            asyncio.ensure_future(coro)

        def on_frame_navigated(frame) -> None:
            # Only track the main frame (not iframes)
            if frame == page.main_frame:
                self._tab_urls[tab_id] = page.url
                _schedule(self._update_tab_title(tab_id, page))

        def on_close() -> None:
            _schedule(self._on_page_closed(tab_id))

        page.on("framenavigated", on_frame_navigated)
        page.on("domcontentloaded", lambda: _schedule(self._update_tab_title(tab_id, page)))
        page.on("close", on_close)

    async def _update_tab_title(self, tab_id: int, page) -> None:
        """Fetch and store the current page title, then push tabs update."""
        try:
            title = await page.title()
            self._tab_titles[tab_id] = title or self._tab_urls.get(tab_id, "New Tab")
        except Exception:
            pass
        await self._send_tabs()

    def _on_new_page(self, page) -> None:
        """Called by Playwright when target=_blank or window.open creates a new page."""
        try:
            loop = asyncio.get_event_loop()
            loop.call_soon_threadsafe(lambda: asyncio.ensure_future(self._register_new_page(page)))
        except Exception:
            asyncio.ensure_future(self._register_new_page(page))

    async def _register_new_page(self, page) -> None:
        """Register a newly-opened page as a tab and switch to it."""
        tab_id = self._alloc_tab_id()
        self._pages[tab_id] = page
        self._tab_urls[tab_id] = page.url or "about:blank"
        self._tab_titles[tab_id] = "New Tab"

        # Attach listeners before waiting for load so we don't miss events
        self._attach_page_listeners(page, tab_id)
        # Sync to Agent state
        self._sync_new_page_to_agent(tab_id, page)

        logger.info("New tab opened: tab_id=%d url=%s", tab_id, page.url)

        # Switch screencast to the new tab automatically
        await self._switch_active_tab(tab_id)

        # Try to get title after a short wait for page to load
        try:
            title = await page.title()
            if title:
                self._tab_titles[tab_id] = title
                await self._send_tabs()
        except Exception:
            pass

    async def _on_page_closed(self, tab_id: int) -> None:
        """Clean up a closed tab."""
        # Stop CDP screencast for this tab
        cdp = self._cdp_sessions.pop(tab_id, None)
        if cdp:
            with contextlib.suppress(Exception):
                await cdp.send("Page.stopScreencast")
            with contextlib.suppress(Exception):
                await cdp.detach()

        self._pages.pop(tab_id, None)
        self._tab_titles.pop(tab_id, None)
        self._tab_urls.pop(tab_id, None)

        # Remove from Agent state when in shared mode
        self._sync_remove_page_from_agent(tab_id)
        self._tab_to_page_id.pop(tab_id, None)

        # If the closed tab was active, switch to another
        if self._active_tab_id == tab_id and self._pages:
            await self._switch_active_tab(next(iter(self._pages)))
        elif not self._pages:
            self._running = False

        await self._send_tabs()

    async def _switch_active_tab(self, tab_id: int) -> None:
        """Stop screencast on current tab, start it on tab_id."""
        if tab_id not in self._pages:
            logger.warning("tab_switch: unknown tab_id=%d", tab_id)
            return

        # Stop old screencast
        old_cdp = self._cdp_sessions.get(self._active_tab_id)
        if old_cdp and self._active_tab_id != tab_id:
            with contextlib.suppress(Exception):
                await old_cdp.send("Page.stopScreencast")

        self._active_tab_id = tab_id
        await self._start_screencast_for_tab(tab_id)

        # Immediately push a screenshot so the canvas updates right away
        # without waiting for the next scheduled screencast frame
        await self._send_screenshot_for_tab(tab_id)

        await self._send_tabs()

    async def _send_screenshot_for_tab(self, tab_id: int) -> None:
        """Take a one-shot screenshot of the given tab and push it as a frame."""
        page = self._pages.get(tab_id)
        if not page or self.ws.client_state != WebSocketState.CONNECTED:
            return
        try:
            import base64

            data = await page.screenshot(type="jpeg", quality=65)
            b64 = base64.b64encode(data).decode()
            await self.ws.send_text(
                json.dumps(
                    {
                        "type": "frame",
                        "data": b64,
                        "metadata": {"timestamp": time.time(), "sessionId": 0},
                    }
                )
            )
        except Exception as exc:
            logger.debug("Failed to send tab switch screenshot: %s", exc)

    async def _start_screencast_for_tab(self, tab_id: int) -> None:
        """Start CDP screencast for a specific tab."""
        page = self._pages.get(tab_id)
        if not page:
            return

        # Detach old CDP session for this tab if exists
        old_cdp = self._cdp_sessions.get(tab_id)
        if old_cdp:
            with contextlib.suppress(Exception):
                await old_cdp.send("Page.stopScreencast")
            with contextlib.suppress(Exception):
                await old_cdp.detach()

        cdp_session = await self._context.new_cdp_session(page)
        self._cdp_sessions[tab_id] = cdp_session
        self._running = True

        async def on_frame(params: dict) -> None:
            if not self._running:
                logger.debug("on_frame: not running, ignoring")
                return
            logger.info(
                "Screencast frame received: tab_id=%d active=%d ws_state=%s data_len=%d",
                tab_id,
                self._active_tab_id,
                self.ws.client_state.name if hasattr(self.ws.client_state, "name") else str(self.ws.client_state),
                len(params.get("data", "")),
            )
            # Only stream frames from the currently active tab
            if tab_id != self._active_tab_id:
                with contextlib.suppress(Exception):
                    await cdp_session.send("Page.screencastFrameAck", {"sessionId": params["sessionId"]})
                return
            try:
                if self.ws.client_state == WebSocketState.CONNECTED:
                    await self.ws.send_text(
                        json.dumps(
                            {
                                "type": "frame",
                                "data": params["data"],
                                "metadata": {
                                    "timestamp": time.time(),
                                    "sessionId": params["sessionId"],
                                },
                            }
                        )
                    )
                await cdp_session.send(
                    "Page.screencastFrameAck",
                    {"sessionId": params["sessionId"]},
                )
            except Exception as exc:
                logger.debug("Failed to send frame: %s", exc)

        cdp_session.on("Page.screencastFrame", on_frame)
        try:
            await cdp_session.send(
                "Page.startScreencast",
                {
                    "format": "jpeg",
                    "quality": 65,
                    "maxWidth": self.viewport_width,
                    "maxHeight": self.viewport_height,
                    "everyNthFrame": 2,
                },
            )
        except Exception as exc:
            logger.error("Failed to send Page.startScreencast: %s", exc)
            return

        if tab_id == self._active_tab_id:
            await self._send_status("streaming")
        logger.info(
            "Screencast started for tab_id=%d (viewport=%dx%d)", tab_id, self.viewport_width, self.viewport_height
        )

    # CDP button name mapping
    _CDP_BUTTON_MAP: ClassVar[dict[str, str]] = {
        "left": "left",
        "middle": "middle",
        "right": "right",
    }

    # CDP button bitmask for Input.dispatchMouseEvent
    _CDP_BUTTONS_MAP: ClassVar[dict[str, int]] = {
        "left": 1,
        "middle": 4,
        "right": 2,
    }

    async def _cdp_mouse_event(
        self,
        event_type: str,
        x: float,
        y: float,
        button: str = "left",
        click_count: int = 0,
    ) -> None:
        """Dispatch a mouse event via CDP Input.dispatchMouseEvent."""
        cdp = self._cdp_session
        if not cdp:
            return
        cdp_button = self._CDP_BUTTON_MAP.get(button, "none")
        buttons = self._CDP_BUTTONS_MAP.get(button, 0) if event_type != "mouseReleased" else 0
        await cdp.send(
            "Input.dispatchMouseEvent",
            {
                "type": event_type,
                "x": x,
                "y": y,
                "button": cdp_button,
                "buttons": buttons,
                "clickCount": click_count,
            },
        )

    async def handle_input(self, event: dict) -> None:
        """Forward user input events to the browser page."""
        page = self._page
        if not page or not self._running:
            return

        event_type = event.get("type", "")
        logger.debug("Input event: %s %s", event_type, {k: v for k, v in event.items() if k != "type"})
        try:
            if event_type == "click":
                x, y = event.get("x", 0), event.get("y", 0)
                button = event.get("button", "left")
                await self._cdp_mouse_event("mouseMoved", x, y)
                await self._cdp_mouse_event("mousePressed", x, y, button=button, click_count=1)
                await self._cdp_mouse_event("mouseReleased", x, y, button=button, click_count=1)
            elif event_type == "dblclick":
                x, y = event.get("x", 0), event.get("y", 0)
                button = event.get("button", "left")
                await self._cdp_mouse_event("mouseMoved", x, y)
                await self._cdp_mouse_event("mousePressed", x, y, button=button, click_count=1)
                await self._cdp_mouse_event("mouseReleased", x, y, button=button, click_count=1)
                await self._cdp_mouse_event("mousePressed", x, y, button=button, click_count=2)
                await self._cdp_mouse_event("mouseReleased", x, y, button=button, click_count=2)
            elif event_type == "mousemove":
                await self._cdp_mouse_event("mouseMoved", event.get("x", 0), event.get("y", 0))
            elif event_type == "mousedown":
                x, y = event.get("x", 0), event.get("y", 0)
                button = event.get("button", "left")
                await self._cdp_mouse_event("mouseMoved", x, y)
                await self._cdp_mouse_event("mousePressed", x, y, button=button, click_count=1)
            elif event_type == "mouseup":
                x, y = event.get("x", 0), event.get("y", 0)
                button = event.get("button", "left")
                await self._cdp_mouse_event("mouseReleased", x, y, button=button, click_count=1)
            elif event_type == "scroll":
                x = event.get("x", 0)
                y = event.get("y", 0)
                # Use CDP directly for scroll too so it targets the active tab
                await self._cdp_mouse_event("mouseMoved", x, y)
                delta_x = event.get("deltaX", 0)
                delta_y = event.get("deltaY", 0)
                cdp = self._cdp_session
                if cdp:
                    await cdp.send(
                        "Input.dispatchMouseEvent",
                        {
                            "type": "mouseWheel",
                            "x": x,
                            "y": y,
                            "deltaX": delta_x,
                            "deltaY": delta_y,
                            "button": "none",
                            "buttons": 0,
                        },
                    )
            elif event_type == "keydown":
                cdp = self._cdp_session
                if cdp:
                    await cdp.send(
                        "Input.dispatchKeyEvent",
                        {"type": "keyDown", "key": event["key"]},
                    )
            elif event_type == "keyup":
                cdp = self._cdp_session
                if cdp:
                    await cdp.send(
                        "Input.dispatchKeyEvent",
                        {"type": "keyUp", "key": event["key"]},
                    )
            elif event_type == "type":
                cdp = self._cdp_session
                if cdp:
                    for char in event.get("text", ""):
                        await cdp.send(
                            "Input.dispatchKeyEvent",
                            {"type": "char", "text": char},
                        )
            elif event_type == "navigate":
                try:
                    await page.goto(event["url"], wait_until="domcontentloaded", timeout=30000)
                except Exception as exc:
                    logger.warning("Navigation failed: %s", exc)
                    await self._send_error(f"Navigation failed: {exc}")
            elif event_type == "resize":
                new_width = int(event.get("width", self.viewport_width))
                new_height = int(event.get("height", self.viewport_height))
                self.viewport_width = new_width
                self.viewport_height = new_height
                await page.set_viewport_size({"width": new_width, "height": new_height})
                # Restart screencast with new dimensions
                await self._start_screencast_for_tab(self._active_tab_id)
            elif event_type == "goback":
                await page.go_back()
            elif event_type == "goforward":
                await page.go_forward()
            elif event_type == "reload":
                await page.reload()
            elif event_type == "tab_switch":
                raw_id = event.get("tab_id", -1)
                # Support both internal integer tab_id and Agent page_id string
                if isinstance(raw_id, str) and raw_id in self._page_id_to_tab:
                    tab_id = self._page_id_to_tab[raw_id]
                else:
                    try:
                        tab_id = int(raw_id)
                    except (ValueError, TypeError):
                        tab_id = -1
                if tab_id in self._pages:
                    await self._switch_active_tab(tab_id)
            elif event_type == "tab_close":
                raw_id = event.get("tab_id", -1)
                if isinstance(raw_id, str) and raw_id in self._page_id_to_tab:
                    tab_id = self._page_id_to_tab[raw_id]
                else:
                    try:
                        tab_id = int(raw_id)
                    except (ValueError, TypeError):
                        tab_id = -1
                await self._close_tab(tab_id)
            elif event_type == "tab_new":
                await self._open_new_tab()
        except Exception as exc:
            logger.debug("Input handling error for %s: %s", event_type, exc)

    async def _close_tab(self, tab_id: int) -> None:
        """Close a specific tab by ID."""
        page = self._pages.get(tab_id)
        if not page:
            return
        # Don't close the last tab
        if len(self._pages) <= 1:
            return
        with contextlib.suppress(Exception):
            await page.close()
        # _on_page_closed will be triggered by the page's close event

    async def _open_new_tab(self) -> None:
        """Open a new blank tab and switch to it."""
        if not self._context:
            return
        page = await self._context.new_page()
        tab_id = self._alloc_tab_id()
        self._pages[tab_id] = page
        self._tab_titles[tab_id] = "New Tab"
        self._tab_urls[tab_id] = "about:blank"
        self._attach_page_listeners(page, tab_id)
        # Sync to Agent state so agent tools see this page
        self._sync_new_page_to_agent(tab_id, page)
        await self._switch_active_tab(tab_id)

    # -- Agent state sync helpers -------------------------------------------

    def _sync_new_page_to_agent(self, tab_id: int, page: object) -> None:
        """Register a newly created page into the Agent's ``_state["pages"]``."""
        if not self._reusing_chrome:
            return
        from ...agent.tools.browser.shared import get_agent_state

        agent_state = get_agent_state()
        if not agent_state:
            return
        counter = agent_state.get("page_counter", 0)
        page_id = f"page_{counter}"
        agent_state["page_counter"] = counter + 1
        agent_state["pages"][page_id] = page
        # Also set as current if no current page
        if not agent_state.get("current_page_id"):
            agent_state["current_page_id"] = page_id
        self._tab_to_page_id[tab_id] = page_id
        self._page_id_to_tab[page_id] = tab_id
        logger.debug("Synced new tab %d -> agent page %s", tab_id, page_id)

    def _sync_remove_page_from_agent(self, tab_id: int) -> None:
        """Remove a closed page from the Agent's ``_state["pages"]``."""
        if not self._reusing_chrome:
            return
        page_id = self._tab_to_page_id.get(tab_id)
        if not page_id:
            return
        from ...agent.tools.browser.shared import get_agent_state

        agent_state = get_agent_state()
        if not agent_state:
            return
        agent_state["pages"].pop(page_id, None)
        self._page_id_to_tab.pop(page_id, None)
        # If the removed page was the current one, pick another
        if agent_state.get("current_page_id") == page_id:
            remaining = list(agent_state["pages"].keys())
            agent_state["current_page_id"] = remaining[0] if remaining else None
        logger.debug("Removed agent page %s (tab %d closed)", page_id, tab_id)

    async def stop(self) -> None:
        """Stop all screencasts and disconnect.

        When the session is reusing a shared Chrome (``_reusing_chrome``),
        only the CDP screencast sessions are detached and local references
        cleared — the underlying Chrome process and context stay alive for
        the Agent and other consumers.

        When the session owns its own Playwright browser (standalone mode),
        the browser is fully closed.
        """
        self._running = False

        for _tab_id, cdp in list(self._cdp_sessions.items()):
            with contextlib.suppress(Exception):
                await cdp.send("Page.stopScreencast")
            with contextlib.suppress(Exception):
                await cdp.detach()
        self._cdp_sessions.clear()

        if self._reusing_chrome:
            # Shared mode: do NOT close pages, context, or browser.
            # Just drop our local references.
            self._pages.clear()
            self._tab_titles.clear()
            self._tab_urls.clear()

            # Disconnect the Playwright CDP connection without killing Chrome
            if self._browser:
                with contextlib.suppress(Exception):
                    await self._browser.close()
                self._browser = None

            if self._playwright:
                with contextlib.suppress(Exception):
                    await self._playwright.stop()
                self._playwright = None

            self._context = None
            logger.info("Browser stream session disconnected (shared Chrome kept alive)")
        else:
            # Standalone mode: full cleanup
            for page in list(self._pages.values()):
                with contextlib.suppress(Exception):
                    await page.close()
            self._pages.clear()

            if self._context:
                with contextlib.suppress(Exception):
                    await self._context.close()
                self._context = None

            if self._browser:
                with contextlib.suppress(Exception):
                    await self._browser.close()
                self._browser = None

            if self._playwright:
                with contextlib.suppress(Exception):
                    await self._playwright.stop()
                self._playwright = None

            logger.info("Browser stream session stopped (standalone)")

    async def _send_tabs(self) -> None:
        """Send current tab list to the client.

        When running in shared mode the ``id`` field is set to the
        Agent-side ``page_id`` (e.g. ``"page_0"``) so the frontend
        can use it directly when calling REST API endpoints such as
        ``/tabs/switch``.  In standalone mode the internal integer
        ``tab_id`` is sent (as a string for consistency).
        """
        if self.ws.client_state != WebSocketState.CONNECTED:
            return
        tabs = []
        for tab_id, _page in self._pages.items():
            url = self._tab_urls.get(tab_id, "about:blank")
            title = self._tab_titles.get(tab_id, url or "New Tab")
            # Prefer the Agent page_id so the frontend can reference
            # it in REST API calls without translation.
            external_id = self._tab_to_page_id.get(tab_id, str(tab_id))
            tabs.append(
                {
                    "id": external_id,
                    "url": url,
                    "title": title,
                    "active": tab_id == self._active_tab_id,
                }
            )
        with contextlib.suppress(Exception):
            await self.ws.send_text(json.dumps({"type": "tabs", "tabs": tabs}))

    async def _send_status(self, status: str, **extra: object) -> None:
        """Send a status message to the client."""
        if self.ws.client_state == WebSocketState.CONNECTED:
            msg: dict = {"type": "status", "status": status, **extra}
            await self.ws.send_text(json.dumps(msg))

    async def _send_error(self, message: str) -> None:
        """Send an error message to the client."""
        if self.ws.client_state == WebSocketState.CONNECTED:
            await self.ws.send_text(json.dumps({"type": "error", "message": message}))


@router.websocket("/browser-stream/ws")
async def browser_stream_ws(
    websocket: WebSocket,
    token: str | None = Query(default=None),
    width: int = Query(default=1280),
    height: int = Query(default=720),
) -> None:
    """WebSocket endpoint for remote browser streaming.

    Query params:
        token: JWT authentication token
        width: Viewport width (default: 1280)
        height: Viewport height (default: 720)
    """
    global _active_stream_count

    session_acquired = False

    # Authenticate
    if not _verify_ws_token(token):
        await websocket.accept()
        await websocket.send_text(json.dumps({"type": "error", "message": "Unauthorized"}))
        await websocket.close(code=4001, reason="Unauthorized")
        return

    # Enforce session limit
    if _stream_semaphore.locked():
        await websocket.accept()
        await websocket.send_text(
            json.dumps(
                {
                    "type": "error",
                    "message": f"Too many browser stream sessions (max {_MAX_STREAM_SESSIONS})",
                }
            )
        )
        await websocket.close(code=4029, reason="Too Many Sessions")
        logger.warning(
            "Browser stream connection rejected: max sessions reached (active=%d)",
            _active_stream_count,
        )
        return

    await _stream_semaphore.acquire()
    session_acquired = True
    async with _sessions_lock:
        _active_stream_count += 1
    logger.info(
        "Browser stream session started (active=%d, max=%d)",
        _active_stream_count,
        _MAX_STREAM_SESSIONS,
    )

    await websocket.accept()
    session: BrowserStreamSession | None = None

    # Input event queue: decouple WS receive from CDP dispatch so the
    # receive loop never blocks on slow CDP calls.
    input_queue: asyncio.Queue[dict] = asyncio.Queue(maxsize=64)
    input_worker_task: asyncio.Task | None = None  # type: ignore[type-arg]

    async def _input_worker() -> None:
        """Consume input events from the queue and forward to the session.

        Coalesces consecutive mousemove events so only the latest position
        is dispatched, preventing cursor-move spam from starving clicks.
        """
        while True:
            event = await input_queue.get()
            if event.get("_stop"):
                break
            try:
                # Drain any queued mousemove, keeping only the latest
                if event.get("type") == "mousemove":
                    latest = event
                    while not input_queue.empty():
                        try:
                            peeked = input_queue.get_nowait()
                        except asyncio.QueueEmpty:
                            break
                        if peeked.get("type") == "mousemove":
                            latest = peeked  # overwrite with newer
                        else:
                            # Non-mousemove event — process latest move first,
                            # then handle the other event immediately after.
                            if session:
                                await session.handle_input(latest)
                            latest = None
                            if session:
                                await session.handle_input(peeked)
                            break
                    if latest and session:
                        await session.handle_input(latest)
                else:
                    if session:
                        await session.handle_input(event)
            except Exception as exc:
                logger.debug("Input worker error: %s", exc)

    # Heartbeat: periodically send a ping to detect stale connections
    async def _heartbeat() -> None:
        while True:
            await asyncio.sleep(15)
            try:
                if websocket.client_state == WebSocketState.CONNECTED:
                    await websocket.send_text(json.dumps({"type": "ping"}))
            except Exception:
                break

    heartbeat_task = asyncio.create_task(_heartbeat())

    try:
        while True:
            raw = await websocket.receive_text()
            try:
                data = json.loads(raw)
            except json.JSONDecodeError:
                continue

            msg_type = data.get("type", "")

            # Respond to client pong (no-op, keeps connection alive)
            if msg_type == "pong":
                continue

            if msg_type == "start":
                # Stop input worker + any previous session
                if input_worker_task and not input_worker_task.done():
                    await input_queue.put({"_stop": True})
                    await input_worker_task

                if session:
                    await session.stop()

                url = data.get("url", "https://cloud.tencent.com")
                vp_width = data.get("width", width)
                vp_height = data.get("height", height)
                reuse = data.get("reuse_session", True)

                session = BrowserStreamSession(
                    websocket,
                    viewport_width=vp_width,
                    viewport_height=vp_height,
                )
                try:
                    await session.start(url, reuse_session=reuse)
                    # Start background input worker
                    input_worker_task = asyncio.create_task(_input_worker())
                except Exception as exc:
                    logger.exception("Failed to start browser: %s", exc)
                    await websocket.send_text(
                        json.dumps({"type": "error", "message": f"Failed to start browser: {exc}"})
                    )
                    session = None

            elif msg_type == "stop":
                if input_worker_task and not input_worker_task.done():
                    await input_queue.put({"_stop": True})
                    await input_worker_task
                    input_worker_task = None

                if session:
                    await session.stop()
                    session = None
                await websocket.send_text(json.dumps({"type": "status", "status": "stopped"}))

            else:
                # All other messages (including tab events) are enqueued as input events
                if session:
                    try:
                        input_queue.put_nowait(data)
                    except asyncio.QueueFull:
                        logger.debug("Input queue full, dropping event: %s", msg_type)

    except (WebSocketDisconnect, RuntimeError):
        logger.info("Browser stream WebSocket disconnected")
    except Exception as exc:
        logger.exception("Browser stream session error: %s", exc)
    finally:
        # Cancel heartbeat
        heartbeat_task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await heartbeat_task

        # Shut down input worker
        if input_worker_task and not input_worker_task.done():
            input_worker_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await input_worker_task

        if session:
            try:
                await session.stop()
            except Exception as exc:
                logger.exception("Error stopping session: %s", exc)

        try:
            if websocket.client_state == WebSocketState.CONNECTED:
                await websocket.close()
        except Exception:
            pass

        # Release semaphore and decrement counter - critical for preventing session leaks
        if session_acquired:
            _stream_semaphore.release()
            async with _sessions_lock:
                _active_stream_count -= 1
            logger.info(
                "Browser stream session ended (active=%d, max=%d)",
                _active_stream_count,
                _MAX_STREAM_SESSIONS,
            )
        else:
            logger.warning("Session cleanup: semaphore was not acquired")
