"""API routes for LLM providers and models."""

from __future__ import annotations

import asyncio
import logging
import time

from fastapi import APIRouter, Body, HTTPException, Path
from pydantic import BaseModel, Field

from ...providers import (
    ActiveModelsInfo,
    ModelInfo,
    ModelSlotConfig,
    ProviderDefinition,
    ProviderEntry,
    ProviderInfo,
    ProvidersData,
    ResolvedModelPublic,
    add_model,
    create_custom_provider,
    delete_custom_provider,
    get_model_template,
    get_provider,
    list_providers,
    list_resolved_llm_configs,
    load_providers_json,
    mask_api_key,
    refresh_provider_models,
    remove_model,
    set_active_llm,
    toggle_model_enabled,
    update_provider_settings,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/models", tags=["models"])

# Read-only endpoints — no authentication required
public_router = APIRouter(prefix="/models", tags=["models"])


class ProviderConfigRequest(BaseModel):
    api_key: str | None = Field(default=None)
    base_url: str | None = Field(default=None)


class ModelSlotRequest(BaseModel):
    provider_id: str = Field(..., description="Provider to use")
    model: str = Field(..., description="Model identifier")


class CreateCustomProviderRequest(BaseModel):
    id: str = Field(...)
    name: str = Field(...)
    default_base_url: str = Field(default="")
    api_key_prefix: str = Field(default="")
    api_key: str = Field(default="")
    models: list[ModelInfo] = Field(default_factory=list)


class AddModelRequest(BaseModel):
    id: str = Field(...)
    name: str = Field(...)
    # Advanced / optional openclaw-compatible metadata
    context_window: int | None = Field(default=None)
    max_tokens: int | None = Field(default=None)
    reasoning: bool | None = Field(default=None)
    input: list[str] | None = Field(default=None)
    cost: dict | None = Field(default=None)


class ToggleModelRequest(BaseModel):
    enabled: bool = Field(..., description="Whether the model should be enabled")


class TestModelRequest(BaseModel):
    model_id: str | None = Field(
        default=None,
        description="Model to test. If omitted, uses the first enabled model.",
    )


class TestModelDirectRequest(BaseModel):
    """Test a model directly with explicit credentials (no saved provider needed)."""

    base_url: str = Field(..., description="API base URL")
    api_key: str = Field(default="", description="API key")
    model_id: str = Field(..., description="Model identifier to test")


class TestModelResponse(BaseModel):
    success: bool
    provider_id: str = Field(default="")
    model_id: str | None = Field(default=None)
    response_time_ms: int = Field(default=0)
    message: str = Field(default="")
    error: str = Field(default="")
    error_type: str = Field(default="")


def _build_provider_info(
    provider: ProviderDefinition,
    data: ProvidersData,
) -> ProviderInfo:
    cur_base_url, cur_api_key = data.get_credentials(provider.id)
    configured = data.is_configured(provider)

    # Fall back to the provider definition's default base_url when no
    # explicit base_url is stored (e.g. ollama before the user configures it).
    display_base_url = cur_base_url or provider.default_base_url

    entry: ProviderEntry | None = data.providers.get(provider.id)

    if provider.is_custom:
        # Custom providers: all models are in entry.models
        return ProviderInfo(
            id=provider.id,
            name=provider.name,
            api_key_prefix=provider.api_key_prefix,
            models=list(provider.models),
            extra_models=[],
            is_custom=provider.is_custom,
            has_api_key=configured,
            current_api_key=mask_api_key(cur_api_key),
            current_base_url=display_base_url,
        )

    # Built-in providers: merge built-in models with extra_models overrides
    extra_list = list(entry.extra_models) if entry else []
    extra_by_id = {m.id: m for m in extra_list}

    # Apply enabled overrides from extra_models to built-in models
    merged_models: list[ModelInfo] = []
    for m in provider.models:
        override = extra_by_id.get(m.id)
        if override is not None:
            # Use the override (which may have enabled=False)
            merged_models.append(override)
        else:
            merged_models.append(m)

    # Truly user-added models (not overrides of built-in models)
    builtin_ids = {m.id for m in provider.models}
    user_added = [m for m in extra_list if m.id not in builtin_ids]
    merged_models.extend(user_added)

    return ProviderInfo(
        id=provider.id,
        name=provider.name,
        api_key_prefix=provider.api_key_prefix,
        models=merged_models,
        extra_models=user_added,
        is_custom=provider.is_custom,
        has_api_key=configured,
        current_api_key=mask_api_key(cur_api_key),
        current_base_url=display_base_url,
    )


@public_router.get(
    "",
    response_model=list[ProviderInfo],
    summary="List all providers",
)
async def list_all_providers() -> list[ProviderInfo]:
    data = load_providers_json()
    return [_build_provider_info(p, data) for p in list_providers()]


@router.post(
    "/refresh",
    response_model=list[ProviderInfo],
    summary="Refresh local/Ollama model lists and return all providers",
)
async def refresh_all_providers() -> list[ProviderInfo]:
    """Explicitly sync local and Ollama model lists.

    Unlike ``GET /models`` which reads from cache, this endpoint performs
    a full refresh — scanning the local model manifest and querying the
    Ollama daemon.  The frontend should call this only when the user
    explicitly requests a refresh (e.g. clicks a "refresh" button).
    """
    data = refresh_provider_models()
    return [_build_provider_info(p, data) for p in list_providers()]


@public_router.get(
    "/{provider_id}/models/{model_id:path}/template",
    summary="Get bundled metadata template for a model",
)
async def get_model_template_endpoint(
    provider_id: str = Path(...),
    model_id: str = Path(...),
) -> dict:
    """Return the bundled metadata template for a known model, or 404 if not found.

    Useful for pre-filling the Advanced Options form when adding a model
    that matches a well-known built-in model.
    """
    tmpl = get_model_template(provider_id, model_id)
    if tmpl is None:
        raise HTTPException(
            status_code=404,
            detail=f"No template found for '{provider_id}/{model_id}'",
        )
    return tmpl


@router.put(
    "/{provider_id}/config",
    response_model=ProviderInfo,
    summary="Configure a provider",
)
async def configure_provider(
    provider_id: str = Path(...),
    body: ProviderConfigRequest = Body(...),
) -> ProviderInfo:
    provider = get_provider(provider_id)
    if provider is None:
        raise HTTPException(404, detail=f"Provider '{provider_id}' not found")

    base_url = body.base_url if provider.is_custom else None
    data = update_provider_settings(
        provider_id,
        api_key=body.api_key,
        base_url=base_url,
    )
    return _build_provider_info(provider, data)


@router.post(
    "/custom-providers",
    response_model=ProviderInfo,
    summary="Create a custom provider",
    status_code=201,
)
async def create_custom_provider_endpoint(
    body: CreateCustomProviderRequest = Body(...),
) -> ProviderInfo:
    try:
        data = create_custom_provider(
            provider_id=body.id,
            name=body.name,
            default_base_url=body.default_base_url,
            api_key_prefix=body.api_key_prefix,
            api_key=body.api_key,
            models=body.models,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    provider = get_provider(body.id)
    assert provider is not None
    return _build_provider_info(provider, data)


@router.delete(
    "/custom-providers/{provider_id}",
    response_model=list[ProviderInfo],
    summary="Delete a custom provider",
)
async def delete_custom_provider_endpoint(
    provider_id: str = Path(...),
) -> list[ProviderInfo]:
    try:
        data = delete_custom_provider(provider_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return [_build_provider_info(p, data) for p in list_providers()]


@router.post(
    "/{provider_id}/models",
    response_model=ProviderInfo,
    summary="Add a model to a provider",
    status_code=201,
)
async def add_model_endpoint(
    provider_id: str = Path(...),
    body: AddModelRequest = Body(...),
) -> ProviderInfo:
    from ...providers.models import ModelCost

    cost = None
    if body.cost:
        try:
            cost = ModelCost.model_validate(body.cost)
        except Exception:
            cost = None

    model = ModelInfo(
        id=body.id,
        name=body.name,
        context_window=body.context_window,
        max_tokens=body.max_tokens,
        reasoning=body.reasoning,
        input=body.input,
        cost=cost,
    )
    try:
        data = add_model(provider_id, model)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    provider = get_provider(provider_id)
    assert provider is not None
    return _build_provider_info(provider, data)


@router.delete(
    "/{provider_id}/models/{model_id:path}",
    response_model=ProviderInfo,
    summary="Remove a model from a provider",
)
async def remove_model_endpoint(
    provider_id: str = Path(...),
    model_id: str = Path(...),
) -> ProviderInfo:
    try:
        data = remove_model(provider_id, model_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    provider = get_provider(provider_id)
    assert provider is not None
    return _build_provider_info(provider, data)


@router.put(
    "/{provider_id}/models/{model_id:path}/enabled",
    response_model=ProviderInfo,
    summary="Toggle a model's enabled state",
)
async def toggle_model_enabled_endpoint(
    provider_id: str = Path(...),
    model_id: str = Path(...),
    body: ToggleModelRequest = Body(...),
) -> ProviderInfo:
    try:
        data = toggle_model_enabled(provider_id, model_id, body.enabled)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    provider = get_provider(provider_id)
    assert provider is not None
    return _build_provider_info(provider, data)


@public_router.get(
    "/resolved",
    response_model=list[ResolvedModelPublic],
    summary="List all resolved model candidates for auto-routing",
)
async def list_resolved_models() -> list[ResolvedModelPublic]:
    """Return every model that is available for automatic routing.

    This includes all models from configured (authorised) providers.
    Secrets (``api_key``, ``base_url``) are stripped from the response.
    """
    resolved = list_resolved_llm_configs()
    return [ResolvedModelPublic.from_resolved(r) for r in resolved]


@public_router.get(
    "/active",
    response_model=ActiveModelsInfo,
    summary="Get active LLM",
)
async def get_active_models() -> ActiveModelsInfo:
    data = load_providers_json()
    pid, model = data.parse_active_llm()
    return ActiveModelsInfo(active_llm=ModelSlotConfig(provider_id=pid, model=model))


@router.put(
    "/active",
    response_model=ActiveModelsInfo,
    summary="Set active LLM",
)
async def set_active_model(
    body: ModelSlotRequest = Body(...),
) -> ActiveModelsInfo:
    provider = get_provider(body.provider_id)
    if provider is None:
        raise HTTPException(
            404,
            detail=f"Provider '{body.provider_id}' not found",
        )

    data = load_providers_json()
    if not data.is_configured(provider):
        if body.provider_id == "ollama":
            msg = f"Provider '{provider.name}' is not configured. Please configure Ollama first."
        elif provider.is_custom:
            msg = f"Provider '{provider.name}' has no base_url configured. Please configure the base URL first."
        else:
            msg = f"Provider '{provider.name}' has no API key configured. Please configure the API key first."
        raise HTTPException(status_code=400, detail=msg)

    if not body.model:
        raise HTTPException(status_code=400, detail="Model is required.")

    data = set_active_llm(body.provider_id, body.model)
    pid, model = data.parse_active_llm()
    return ActiveModelsInfo(active_llm=ModelSlotConfig(provider_id=pid, model=model))


# ---------------------------------------------------------------------------
# Test model connectivity
# ---------------------------------------------------------------------------

TEST_TIMEOUT_SECONDS = 15


def _classify_error(exc: Exception) -> tuple[str, str]:
    """Classify an exception into (error_type, user_message)."""
    msg = str(exc)

    # Auth errors (401/403)
    if any(code in msg for code in ("401", "403", "Unauthorized", "Forbidden", "AuthenticationError")):
        return "auth_error", "API Key invalid or expired"

    # Model not found (404 or specific provider errors)
    if any(s in msg for s in ("404", "model_not_found", "Model not found", "does not exist")):
        return "model_not_found", "Model does not exist or is unavailable"

    # Network / connection errors
    if isinstance(exc, ConnectionError | OSError):
        return "network_error", "Cannot connect to server"
    if "ConnectionError" in type(exc).__name__ or "ConnectError" in msg:
        return "network_error", "Cannot connect to server"

    # Timeout
    if isinstance(exc, asyncio.TimeoutError):
        return "timeout", f"Request timed out ({TEST_TIMEOUT_SECONDS}s)"

    return "unknown", msg[:500]


@router.post(
    "/{provider_id}/test",
    response_model=TestModelResponse,
    summary="Test model connectivity",
)
async def test_model_endpoint(
    provider_id: str = Path(...),
    body: TestModelRequest = Body(default=TestModelRequest()),
) -> TestModelResponse:
    """Send a minimal chat request to verify provider/model connectivity."""
    provider = get_provider(provider_id)
    if provider is None:
        raise HTTPException(404, detail=f"Provider '{provider_id}' not found")

    data = load_providers_json()

    # Determine model_id
    model_id = body.model_id
    if not model_id:
        # Use same merge logic as _build_provider_info to respect enabled overrides
        info = _build_provider_info(provider, data)
        enabled_models = [m for m in info.models if m.enabled is not False]
        if not enabled_models:
            return TestModelResponse(
                success=False,
                provider_id=provider_id,
                model_id=None,
                error="No enabled model available for testing",
                error_type="no_enabled_model",
            )
        model_id = enabled_models[0].id

    # Check provider is configured
    if not data.is_configured(provider):
        return TestModelResponse(
            success=False,
            provider_id=provider_id,
            model_id=model_id,
            error="Provider not configured. Please set API Key first.",
            error_type="auth_error",
        )

    # Build resolved config
    from ...providers.models import ResolvedModelConfig

    base_url, api_key = data.get_credentials(provider_id)
    if not base_url:
        base_url = provider.default_base_url
    cfg = ResolvedModelConfig(
        model=model_id,
        base_url=base_url,
        api_key=api_key,
        provider_id=provider_id,
    )

    # Create model and invoke
    start_time = time.monotonic()
    try:
        from langchain_core.messages import HumanMessage

        from ...agent.langgraph.model_factory import create_chat_model

        chat_model = create_chat_model(cfg)
        await asyncio.wait_for(
            chat_model.ainvoke([HumanMessage(content="Hi")]),
            timeout=TEST_TIMEOUT_SECONDS,
        )
        elapsed_ms = int((time.monotonic() - start_time) * 1000)

        return TestModelResponse(
            success=True,
            provider_id=provider_id,
            model_id=model_id,
            response_time_ms=elapsed_ms,
            message="Model is available",
        )
    except Exception as exc:
        elapsed_ms = int((time.monotonic() - start_time) * 1000)
        error_type, error_msg = _classify_error(exc)
        logger.warning(
            "Model test failed: provider=%s model=%s error=%s",
            provider_id,
            model_id,
            exc,
        )
        return TestModelResponse(
            success=False,
            provider_id=provider_id,
            model_id=model_id,
            response_time_ms=elapsed_ms,
            error=error_msg,
            error_type=error_type,
        )


@router.post(
    "/test-direct",
    response_model=TestModelResponse,
    summary="Test a model with explicit credentials (no saved provider needed)",
)
async def test_model_direct_endpoint(
    body: TestModelDirectRequest = Body(...),
) -> TestModelResponse:
    """Test a model using explicitly provided base_url/api_key/model_id.

    Useful for testing models before saving the provider configuration
    (e.g. in the setup wizard when creating a new custom provider).
    """
    from ...providers.models import ResolvedModelConfig

    cfg = ResolvedModelConfig(
        model=body.model_id,
        base_url=body.base_url,
        api_key=body.api_key,
        provider_id="",
    )

    start_time = time.monotonic()
    try:
        from langchain_core.messages import HumanMessage

        from ...agent.langgraph.model_factory import create_chat_model

        chat_model = create_chat_model(cfg)
        await asyncio.wait_for(
            chat_model.ainvoke([HumanMessage(content="Hi")]),
            timeout=TEST_TIMEOUT_SECONDS,
        )
        elapsed_ms = int((time.monotonic() - start_time) * 1000)

        return TestModelResponse(
            success=True,
            model_id=body.model_id,
            response_time_ms=elapsed_ms,
            message="Model is available",
        )
    except Exception as exc:
        elapsed_ms = int((time.monotonic() - start_time) * 1000)
        error_type, error_msg = _classify_error(exc)
        logger.warning(
            "Direct model test failed: base_url=%s model=%s error=%s",
            body.base_url,
            body.model_id,
            exc,
        )
        return TestModelResponse(
            success=False,
            model_id=body.model_id,
            response_time_ms=elapsed_ms,
            error=error_msg,
            error_type=error_type,
        )
