"""Parse WeCom message body into LightClaw ContentPart list."""

from __future__ import annotations

import logging
import re
from typing import TYPE_CHECKING, Any

from ...schemas import (
    ContentType,
    FileContent,
    ImageContent,
    TextContent,
)

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)


def _strip_bot_mention(text: str, bot_name: str) -> str:
    """Remove @BotName mention from message text.

    WeCom prepends '@BotName ' to group messages when the bot is mentioned.
    This function removes it so the Agent doesn't see the bot's own name.
    """
    if not bot_name:
        return text
    # Pattern: @BotName (possibly followed by whitespace)
    # Also handle zero-width spaces and non-breaking spaces that WeCom may insert
    pattern = rf"@{re.escape(bot_name)}[\s\u200b\u00a0]*"
    cleaned = re.sub(pattern, "", text, count=1).strip()
    return cleaned if cleaned else text


def _extract_quote_text(quote: dict) -> str:
    """Extract text content from a quote/reply structure."""
    text = (quote.get("text") or {}).get("content", "")
    return text.strip()


async def parse_wecom_message(
    body: dict,
    ws_client: Any,
    bot_name: str = "",
) -> list[Any]:
    """Convert WeCom message body to a list of runtime Content objects.

    Args:
        body: The ``frame["body"]`` dict from a WeCom callback.
        ws_client: WSClient instance for downloading media (may be None).
        bot_name: Bot display name; used to strip @mention from text.

    Returns:
        List of TextContent / ImageContent / FileContent objects.
    """
    msgtype = body.get("msgtype", "")
    parts: list[Any] = []

    if msgtype == "text":
        content = (body.get("text") or {}).get("content", "").strip()
        if content and bot_name:
            content = _strip_bot_mention(content, bot_name)
        if content:
            parts.append(TextContent(type=ContentType.TEXT, text=content))

    elif msgtype == "image":
        if ws_client is not None:
            from .media_handler import download_and_save

            image_data = body.get("image") or {}
            local_path = await download_and_save(ws_client, image_data)
            if local_path:
                parts.append(ImageContent(type=ContentType.IMAGE, image_url=local_path))

    elif msgtype == "voice":
        content = (body.get("voice") or {}).get("content", "").strip()
        if content:
            parts.append(TextContent(type=ContentType.TEXT, text=f"[语音] {content}"))

    elif msgtype == "file":
        if ws_client is not None:
            from .media_handler import download_and_save

            file_data = body.get("file") or {}
            local_path = await download_and_save(ws_client, file_data)
            if local_path:
                parts.append(FileContent(type=ContentType.FILE, file_url=local_path))

    elif msgtype == "mixed":
        msg_items = (body.get("mixed") or {}).get("msg_item", [])
        for item in msg_items:
            sub_parts = await parse_wecom_message(item, ws_client, bot_name=bot_name)
            parts.extend(sub_parts)

    else:
        if msgtype:
            logger.debug("wecom: unhandled msgtype=%s", msgtype)

    # Prepend quote content if present
    quote = body.get("quote")
    if quote:
        quote_text = _extract_quote_text(quote)
        if quote_text:
            parts.insert(
                0,
                TextContent(type=ContentType.TEXT, text=f"> {quote_text}\n\n"),
            )

    return parts
