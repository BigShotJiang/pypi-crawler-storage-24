"""WeCom (Enterprise WeChat) channel: WebSocket long connection via aibot SDK.

Uses wecom-aibot-sdk (pip install wecom-aibot-sdk) for WebSocket connection.
Receives messages via WSClient events, enqueues to ChannelManager, replies
via reply_stream (streaming text) and send_message (proactive/media).
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any

from ...schemas import FileContent, ImageContent, MessageType, TextContent
from ...turn_protocol import TurnEvent, TurnEventType, TurnRequest
from ..core.base import (
    _INTERNAL_MESSAGE_TYPES,
    BaseChannel,
    ContentType,
    OnReplySent,
    OutgoingContentPart,
    ProcessHandler,
    _TurnMsg,
)
from ..core.schema import ChannelType
from .constants import STREAM_REPLY_TIMEOUT, WECOM_CHANNEL_ID
from .message_parser import parse_wecom_message

if TYPE_CHECKING:
    from ....config.config import WeComConfig

logger = logging.getLogger(__name__)


class WeComChannel(BaseChannel):
    """WeCom channel: WebSocket receive via aibot SDK, stream reply."""

    channel: ChannelType = WECOM_CHANNEL_ID
    uses_manager_queue: bool = True

    def __init__(
        self,
        process: ProcessHandler,
        enabled: bool,
        bot_id: str,
        secret: str,
        bot_prefix: str = "",
        bot_name: str = "",
        websocket_url: str = "",
        send_thinking: bool = True,
        media_dir: str = "~/.lightclaw/media",
        dm_policy: str = "open",
        allow_from: list | None = None,
        group_policy: str = "open",
        group_allow_from: list | None = None,
        on_reply_sent: OnReplySent = None,
        show_tool_details: bool = True,
    ):
        super().__init__(
            process,
            on_reply_sent=on_reply_sent,
            show_tool_details=show_tool_details,
        )
        self.enabled = enabled
        self._bot_id = bot_id
        self._secret = secret
        self.bot_prefix = bot_prefix
        self._bot_name = bot_name
        self._ws_url = websocket_url
        self._send_thinking = send_thinking
        self._media_dir = Path(media_dir).expanduser()
        self._dm_policy = dm_policy or "open"
        self._allow_from = set(str(x) for x in (allow_from or []))
        self._group_policy = group_policy or "open"
        self._group_allow_from = set(str(x) for x in (group_allow_from or []))
        self._ws_client: Any = None
        self._connected = False

    @classmethod
    def from_env(
        cls,
        process: ProcessHandler,
        on_reply_sent: OnReplySent = None,
    ) -> WeComChannel:
        import os

        return cls(
            process=process,
            enabled=os.getenv("WECOM_CHANNEL_ENABLED", "0") == "1",
            bot_id=os.getenv("WECOM_BOT_ID", ""),
            secret=os.getenv("WECOM_SECRET", ""),
            bot_prefix=os.getenv("WECOM_BOT_PREFIX", ""),
            bot_name=os.getenv("WECOM_BOT_NAME", ""),
            websocket_url=os.getenv("WECOM_WEBSOCKET_URL", ""),
            on_reply_sent=on_reply_sent,
        )

    @classmethod
    def from_config(
        cls,
        process: ProcessHandler,
        config: WeComConfig,
        on_reply_sent: OnReplySent = None,
        show_tool_details: bool = True,
    ) -> WeComChannel:
        return cls(
            process=process,
            enabled=config.enabled,
            bot_id=config.bot_id or "",
            secret=config.secret or "",
            bot_prefix=config.bot_prefix or "",
            bot_name=getattr(config, "name", "") or "",
            websocket_url=config.websocket_url or "",
            send_thinking=getattr(config, "send_thinking", True),
            media_dir=getattr(config, "media_dir", "~/.lightclaw/media"),
            dm_policy=getattr(config, "dm_policy", "open") or "open",
            allow_from=list(getattr(config, "allow_from", []) or []),
            group_policy=getattr(config, "group_policy", "open") or "open",
            group_allow_from=list(getattr(config, "group_allow_from", []) or []),
            on_reply_sent=on_reply_sent,
            show_tool_details=show_tool_details,
        )

    # ── Lifecycle ──

    async def start(self) -> None:
        if not self.enabled:
            logger.debug("wecom channel disabled")
            return
        if not self._bot_id or not self._secret:
            raise RuntimeError(
                "WeCom channel enabled but bot_id/secret not configured. "
                "Set channels.wecom.botId and channels.wecom.secret in lightclaw.json."
            )

        from wecom_aibot_sdk import WSClient

        self._ws_client = WSClient(
            bot_id=self._bot_id,
            secret=self._secret,
            ws_url=self._ws_url or "",
            max_reconnect_attempts=-1,  # infinite reconnect
            heartbeat_interval=30000,
        )

        # Register event handlers
        self._ws_client.on("authenticated", self._on_authenticated)
        self._ws_client.on("disconnected", self._on_disconnected)
        self._ws_client.on("error", self._on_error)
        self._ws_client.on("message", self._on_message)
        self._ws_client.on("event.enter_chat", self._on_enter_chat)

        await self._ws_client.connect()
        logger.info("wecom channel started (bot_id=%s)", self._bot_id[:12])

    async def stop(self) -> None:
        if not self.enabled:
            return
        if self._ws_client:
            await self._ws_client.disconnect()
            self._ws_client = None
        self._connected = False
        logger.info("wecom channel stopped")

    # ── Event Handlers ──

    def _on_authenticated(self) -> None:
        self._connected = True
        logger.info("wecom WebSocket authenticated")

    def _on_disconnected(self, reason: str = "") -> None:
        self._connected = False
        logger.warning("wecom WebSocket disconnected: %s", reason)

    def _on_error(self, error: Exception) -> None:
        logger.error("wecom WebSocket error: %s", error)

    async def _on_message(self, frame: dict) -> None:
        """WSClient message event → build native payload → enqueue."""
        body = frame.get("body") or {}
        sender_id = (body.get("from") or {}).get("userid", "unknown")
        chat_id = body.get("chatid", "")
        chat_type = body.get("chattype", "single")

        logger.info(
            "wecom _on_message: sender=%s chat_type=%s msgtype=%s body_keys=%s",
            sender_id,
            chat_type,
            body.get("msgtype"),
            list(body.keys()),
        )

        # ── Access control filtering ──
        if chat_type == "single":
            if self._dm_policy == "disabled":
                logger.info("wecom: DM from %s dropped (dm_policy=disabled)", sender_id)
                return
            if self._dm_policy == "allowlist" and self._allow_from and str(sender_id) not in self._allow_from:
                logger.info("wecom: DM from %s dropped (not in allowlist)", sender_id)
                return
        elif chat_type == "group":
            if self._group_policy == "disabled":
                logger.info("wecom: group msg from %s dropped (group_policy=disabled)", sender_id)
                return
            if (
                self._group_policy == "allowlist"
                and self._group_allow_from
                and str(sender_id) not in self._group_allow_from
            ):
                logger.info("wecom: group msg from %s dropped (not in group allowlist)", sender_id)
                return

        content_parts = await parse_wecom_message(
            body,
            self._ws_client,
            bot_name=self._bot_name,
        )
        if not content_parts:
            logger.warning(
                "wecom _on_message: no content_parts, skip. msgtype=%s body=%s",
                body.get("msgtype"),
                {k: v for k, v in body.items() if k not in ("from",)},
            )
            return

        logger.info(
            "wecom _on_message: parsed %d content_parts, types=%s",
            len(content_parts),
            [getattr(p, "type", None) for p in content_parts],
        )

        native_payload = {
            "channel_id": self.channel,
            "sender_id": sender_id,
            "content_parts": content_parts,
            "meta": {
                "frame": frame,
                "chat_id": chat_id,
                "chat_type": chat_type,
                "ws_client": self._ws_client,
            },
        }

        if self._enqueue:
            logger.info("wecom _on_message: enqueuing payload for sender=%s", sender_id)
            self._enqueue(native_payload)
        else:
            logger.warning("wecom _on_message: no enqueue callback set")

    async def _on_enter_chat(self, frame: dict) -> None:
        """User enters bot conversation → send welcome message."""
        if not self._ws_client:
            return
        try:
            await self._ws_client.reply_welcome(
                frame,
                {
                    "msgtype": "text",
                    "text": {"content": "你好！我是你的 AI 助手，有什么可以帮你的吗？"},
                },
            )
        except Exception as exc:
            logger.warning("wecom enter_chat welcome failed: %s", exc)

    # ── TurnRequest Building ──

    def resolve_session_id(
        self,
        sender_id: str,
        channel_meta: dict[str, Any] | None = None,
    ) -> str:
        meta = channel_meta or {}
        chat_type = meta.get("chat_type", "single")
        chat_id = meta.get("chat_id", "")
        if chat_type == "group" and chat_id:
            return f"wecom:group:{chat_id}"
        return f"wecom:{sender_id}"

    def build_turn_request_from_native(
        self,
        native_payload: Any,
    ) -> TurnRequest:
        payload = native_payload if isinstance(native_payload, dict) else {}
        channel_id = payload.get("channel_id") or self.channel
        sender_id = payload.get("sender_id") or ""
        content_parts = payload.get("content_parts") or []
        meta = payload.get("meta") or {}

        session_id = self.resolve_session_id(sender_id, meta)

        return self.build_turn_request_from_user_content(
            channel_id=channel_id,
            sender_id=sender_id,
            session_id=session_id,
            content_parts=content_parts,
            channel_meta=meta,
        )

    # ── Sending ──

    async def send(
        self,
        to_handle: str,
        text: str,
        meta: dict[str, Any] | None = None,
    ) -> None:
        """Send text reply. Uses reply_stream for streaming finish."""
        if not text or not text.strip():
            logger.debug("wecom send: empty text, skip")
            return
        meta = meta or {}
        ws_client = meta.get("ws_client") or self._ws_client
        frame = meta.get("frame")

        logger.info(
            "wecom send: to_handle=%s text_len=%d has_frame=%s has_ws=%s meta_keys=%s",
            to_handle[:20] if to_handle else "",
            len(text),
            bool(frame),
            bool(ws_client),
            list(meta.keys()),
        )

        if not ws_client:
            logger.warning("wecom send: no ws_client available")
            return

        if frame:
            # Passive reply via stream (single-shot, finish=True)
            from wecom_aibot_sdk import generate_req_id

            stream_id = meta.get("_stream_id")
            if not stream_id:
                stream_id = generate_req_id("stream")
                meta["_stream_id"] = stream_id

            try:
                await asyncio.wait_for(
                    ws_client.reply_stream(
                        frame=frame,
                        stream_id=stream_id,
                        content=text,
                        finish=True,
                    ),
                    timeout=STREAM_REPLY_TIMEOUT,
                )
            except Exception as exc:
                logger.error("wecom reply_stream failed: %s", exc)
        else:
            # Proactive send (no frame context, e.g. cron)
            chat_id = meta.get("chat_id") or to_handle
            if chat_id:
                try:
                    await ws_client.send_message(
                        chat_id,
                        {
                            "msgtype": "markdown",
                            "markdown": {"content": text},
                        },
                    )
                except Exception as exc:
                    logger.error("wecom send_message failed: %s", exc)

    async def send_content_parts(
        self,
        to_handle: str,
        parts: list[OutgoingContentPart],
        meta: dict[str, Any] | None = None,
    ) -> None:
        """Send text + media parts. Text via reply_stream, media via send_message."""
        meta = meta or {}
        text_parts: list[str] = []
        media_parts: list[OutgoingContentPart] = []

        for p in parts:
            t = getattr(p, "type", None)
            if t == ContentType.TEXT and getattr(p, "text", None):
                text_parts.append(p.text or "")
            elif t == ContentType.REFUSAL and getattr(p, "refusal", None):
                text_parts.append(p.refusal or "")
            elif t in (
                ContentType.IMAGE,
                ContentType.VIDEO,
                ContentType.AUDIO,
                ContentType.FILE,
            ):
                media_parts.append(p)

        prefix = (meta or {}).get("bot_prefix", "") or self.bot_prefix or ""
        body = "\n".join(text_parts).strip()
        if prefix and body:
            body = prefix + body

        # Send media first (via proactive send_message)
        for mp in media_parts:
            await self.send_media(to_handle, mp, meta)

        # Then send text (via reply_stream or send_message)
        if body:
            await self.send(to_handle, body, meta)

    async def send_media(
        self,
        to_handle: str,
        part: OutgoingContentPart,
        meta: dict[str, Any] | None = None,
    ) -> None:
        """Send a media part (image/file) via WeCom proactive send."""
        meta = meta or {}
        ws_client = meta.get("ws_client") or self._ws_client
        chat_id = meta.get("chat_id") or to_handle

        if not ws_client or not chat_id:
            logger.warning("wecom send_media: missing ws_client or chat_id")
            return

        t = getattr(part, "type", None)
        file_path = None
        if t == ContentType.IMAGE:
            file_path = getattr(part, "image_url", None)
        elif t == ContentType.FILE:
            file_path = getattr(part, "file_url", None) or getattr(part, "file_id", None)

        if not file_path:
            logger.debug("wecom send_media: no file path for type=%s", t)
            return

        # For local file paths, read and send
        from .media_handler import read_and_send_media

        try:
            await read_and_send_media(ws_client, chat_id, file_path, t)
        except Exception as exc:
            logger.error("wecom send_media failed: %s", exc)

    # ── Process Loop (accumulate streamed text) ──

    async def _run_process_loop(
        self,
        request: TurnRequest,
        to_handle: str,
        send_meta: dict[str, Any],
    ) -> None:
        """Override to accumulate ASSISTANT_DELTA text.

        The LangGraph event bridge filters text from the final
        ASSISTANT_COMPLETED event when text was already streamed as deltas.
        Queue-based channels (like WeCom) don't consume deltas in real-time,
        so we must collect them here and use the accumulated text when the
        final event's content is empty.
        """
        bot_prefix = send_meta.get("bot_prefix", "") or self.bot_prefix or ""
        turn_failed = False
        turn_error: Any = None

        # Accumulate streamed text/media by message_id
        _streamed_text: dict[str, str] = {}
        _streamed_media: dict[str, list[OutgoingContentPart]] = {}

        try:
            async for event in self._process(request):
                if not isinstance(event, TurnEvent):
                    continue

                if event.type == TurnEventType.ASSISTANT_DELTA:
                    msg_id = event.message_id or ""
                    delta = event.delta or {}
                    if isinstance(delta, dict):
                        d_type = delta.get("type", "")
                        if d_type == "text":
                            delta_text = delta.get("text", "") or ""
                            if delta_text:
                                _streamed_text[msg_id] = _streamed_text.get(msg_id, "") + delta_text
                        elif d_type == "image":
                            url = delta.get("image_url", "") or ""
                            if url:
                                _streamed_media.setdefault(msg_id, []).append(
                                    ImageContent(type=ContentType.IMAGE, image_url=url)
                                )
                        elif d_type == "file":
                            url = delta.get("file_url", "") or ""
                            if url:
                                _streamed_media.setdefault(msg_id, []).append(
                                    FileContent(type=ContentType.FILE, file_url=url)
                                )

                elif event.type == TurnEventType.ASSISTANT_COMPLETED:
                    metadata = event.metadata or {}
                    message_type = metadata.get("message_type", MessageType.MESSAGE)

                    # Skip internal tool/plugin messages
                    if message_type in _INTERNAL_MESSAGE_TYPES:
                        continue

                    msg_id = event.message_id or ""
                    msg = _TurnMsg(
                        message_type,
                        list(event.content or []),
                        event.role or "assistant",
                    )
                    parts = self._message_to_content_parts(msg)

                    # If content is empty, use accumulated streamed text
                    if not parts:
                        text = _streamed_text.pop(msg_id, "")
                        media = _streamed_media.pop(msg_id, [])
                        if not text:
                            # msg_id may not match; try any accumulated text
                            for k, v in list(_streamed_text.items()):
                                text = v
                                del _streamed_text[k]
                                break
                        if not media:
                            for k, v in list(_streamed_media.items()):
                                media = v
                                del _streamed_media[k]
                                break
                        if text:
                            parts.append(TextContent(type=ContentType.TEXT, text=text))
                        parts.extend(media)
                    else:
                        _streamed_text.pop(msg_id, None)
                        _streamed_media.pop(msg_id, None)

                    if parts:
                        forwarding_meta = dict(send_meta or {})
                        forwarding_meta["_msg_type"] = message_type
                        await self.send_content_parts(to_handle, parts, forwarding_meta)

                elif event.type == TurnEventType.TOOL_APPROVAL_REQUIRED:
                    await self._on_tool_approval_required(request, to_handle, event, send_meta)

                elif event.type == TurnEventType.TURN_FAILED:
                    turn_failed = True
                    turn_error = event.error

            if turn_failed and turn_error is not None:
                from ...core.error_utils import extract_event_error_message

                err = extract_event_error_message(turn_error)
                err_text = (bot_prefix or "") + f"Error: {err}"
                await self._on_consume_error(request, to_handle, err_text)
            if self._on_reply_sent:
                args = self.get_on_reply_sent_args(request, to_handle)
                self._on_reply_sent(self.channel, *args)
        except Exception:
            logger.exception("wecom process/reply failed")
            await self._on_consume_error(
                request,
                to_handle,
                "处理请求时发生错误，请稍后再试。",
            )

    # ── Connection Status ──

    def get_connection_status(self) -> dict:
        if not self.enabled:
            return {"status": "not_enabled", "reason": None}
        if not self._bot_id:
            return {"status": "disconnected", "reason": "Bot ID 未配置"}
        if not self._secret:
            return {"status": "disconnected", "reason": "Secret 未配置"}
        if not self._connected:
            return {"status": "disconnected", "reason": "WebSocket 未连接"}
        return {"status": "connected", "reason": None}

    async def verify_credentials(self) -> dict:
        """校验当前实例的凭据。

        如果当前实例的 WebSocket 已连接且已认证，直接返回成功。
        如果 WSClient 已创建但未认证（正在连接中），返回 connecting 状态。
        如果未启动，创建新连接验证；验证成功后复用为主连接（不断开）。
        """
        if self._connected and self._ws_client:
            return {
                "valid": True,
                "status": "connected",
                "reason": None,
            }
        if self._ws_client and not self._connected:
            return {
                "valid": False,
                "status": "connecting",
                "reason": "正在连接中，请稍候再试",
            }
        # 没有 WSClient（未启动），创建连接验证并复用
        return await self._verify_and_adopt(
            self._bot_id,
            self._secret,
        )

    async def _verify_and_adopt(self, bot_id: str, secret: str) -> dict:
        """创建临时连接验证凭据，成功后将其收编为主连接。"""
        bot_id = (bot_id or "").strip()
        secret = (secret or "").strip()
        if not bot_id:
            return {"valid": False, "status": "disconnected", "reason": "Bot ID 未配置"}
        if not secret:
            return {"valid": False, "status": "disconnected", "reason": "Secret 未配置"}

        try:
            from wecom_aibot_sdk import WSClient

            client = WSClient(
                bot_id=bot_id,
                secret=secret,
                ws_url=self._ws_url or "",
                max_reconnect_attempts=-1,
                heartbeat_interval=30000,
            )

            authenticated = asyncio.Event()
            auth_error: list = []

            def on_auth():
                authenticated.set()

            def on_error(err):
                auth_error.append(str(err))
                authenticated.set()

            client.on("authenticated", on_auth)
            client.on("error", on_error)

            await client.connect()

            with contextlib.suppress(TimeoutError):
                await asyncio.wait_for(authenticated.wait(), timeout=10)

            if auth_error:
                with contextlib.suppress(Exception):
                    await client.disconnect()
                return {
                    "valid": False,
                    "status": "disconnected",
                    "reason": f"认证失败: {auth_error[0]}",
                }
            if authenticated.is_set():
                # 认证成功 → 复用此连接作为主连接
                # 先移除临时 handlers，绑定正式 handlers
                client.off("authenticated")
                client.off("error")
                client.on("authenticated", self._on_authenticated)
                client.on("disconnected", self._on_disconnected)
                client.on("error", self._on_error)
                client.on("message", self._on_message)
                client.on("event.enter_chat", self._on_enter_chat)

                # 如果有旧 client，停掉
                if self._ws_client:
                    with contextlib.suppress(Exception):
                        await self._ws_client.disconnect()

                self._ws_client = client
                self._connected = True
                logger.info(
                    "wecom verify_and_adopt: adopted verified connection (bot_id=%s)",
                    bot_id[:12],
                )
                return {
                    "valid": True,
                    "status": "connected",
                    "reason": None,
                }

            # 超时
            with contextlib.suppress(Exception):
                await client.disconnect()
            return {
                "valid": False,
                "status": "disconnected",
                "reason": "连接超时，请检查 Bot ID 和 Secret 是否正确",
            }
        except ImportError:
            return {"valid": False, "status": "disconnected", "reason": "wecom-aibot-sdk 未安装"}
        except Exception as exc:
            return {"valid": False, "status": "disconnected", "reason": f"检测异常: {exc!s}"}

    @staticmethod
    async def verify_credentials_with_params(credentials: dict) -> dict:
        """使用传入的凭据参数校验企业微信连接联通性（静态方法，仅校验不复用）。

        企业微信 AI Bot 使用 WebSocket 长连接，无独立的 REST 校验接口。
        此处通过尝试短暂连接 WebSocket 来验证凭据是否有效。
        仅在没有运行实例时由 API 层调用。
        """
        bot_id = (credentials.get("bot_id") or "").strip()
        secret = (credentials.get("secret") or "").strip()
        if not bot_id:
            return {
                "valid": False,
                "status": "disconnected",
                "reason": "Bot ID 未配置",
            }
        if not secret:
            return {
                "valid": False,
                "status": "disconnected",
                "reason": "Secret 未配置",
            }

        try:
            from wecom_aibot_sdk import WSClient

            client = WSClient(
                bot_id=bot_id,
                secret=secret,
            )

            import asyncio

            authenticated = asyncio.Event()
            auth_error: list = []

            def on_auth():
                authenticated.set()

            def on_error(err):
                auth_error.append(str(err))
                authenticated.set()

            client.on("authenticated", on_auth)
            client.on("error", on_error)

            await client.connect()

            with contextlib.suppress(TimeoutError):
                await asyncio.wait_for(authenticated.wait(), timeout=10)

            # Disconnect after check
            with contextlib.suppress(Exception):
                await client.disconnect()

            if auth_error:
                return {
                    "valid": False,
                    "status": "disconnected",
                    "reason": f"认证失败: {auth_error[0]}",
                }
            if authenticated.is_set():
                return {
                    "valid": True,
                    "status": "connected",
                    "reason": None,
                }
            return {
                "valid": False,
                "status": "disconnected",
                "reason": "连接超时，请检查 Bot ID 和 Secret 是否正确",
            }
        except ImportError:
            return {
                "valid": False,
                "status": "disconnected",
                "reason": "wecom-aibot-sdk 未安装",
            }
        except Exception as exc:
            return {
                "valid": False,
                "status": "disconnected",
                "reason": f"检测异常: {exc!s}",
            }
