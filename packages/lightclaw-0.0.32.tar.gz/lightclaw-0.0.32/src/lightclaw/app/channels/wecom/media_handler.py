"""WeCom media download, save, and upload utilities."""

from __future__ import annotations

import asyncio
import logging
import time
from pathlib import Path
from typing import Any
from uuid import uuid4

from .constants import MEDIA_DOWNLOAD_TIMEOUT

logger = logging.getLogger(__name__)

# Default media storage directory; tests may patch this.
MEDIA_DIR = Path("~/.lightclaw/media/wecom").expanduser()


def detect_extension(data: bytes) -> str:
    """Detect file extension from magic bytes."""
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return ".png"
    if data[:3] == b"\xff\xd8\xff":
        return ".jpg"
    if data[:4] == b"GIF8":
        return ".gif"
    if data[:4] == b"%PDF":
        return ".pdf"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return ".webp"
    return ".bin"


async def download_and_save(
    ws_client: Any,
    media_data: dict,
    *,
    media_dir: Path | None = None,
) -> str | None:
    """Download a WeCom media file (with optional AES decryption) and save locally.

    Args:
        ws_client: ``aibot.WSClient`` instance.
        media_data: Dict with ``url`` and optional ``aeskey``.
        media_dir: Override save directory (for testing).

    Returns:
        Absolute path string of saved file, or None on failure.
    """
    url = media_data.get("url")
    if not url:
        return None

    aes_key = media_data.get("aeskey") or None
    save_dir = media_dir or MEDIA_DIR

    try:
        result = await asyncio.wait_for(
            ws_client.download_file(url, aes_key),
            timeout=MEDIA_DOWNLOAD_TIMEOUT,
        )
        # SDK returns dict {"buffer": bytes, "filename": str | None}
        if isinstance(result, dict):
            file_bytes = result.get("buffer")
            filename = result.get("filename")
        else:
            # Fallback for older SDK that returns tuple (bytes, filename)
            file_bytes, filename = result
    except Exception as exc:
        logger.warning("wecom media download failed: %s", exc)
        return None

    if not file_bytes:
        return None

    # Ensure bytes type (SDK may return str in some cases)
    if isinstance(file_bytes, str):
        file_bytes = file_bytes.encode("utf-8")

    save_dir.mkdir(parents=True, exist_ok=True)

    if not filename:
        ext = detect_extension(file_bytes)
        filename = f"{int(time.time())}_{uuid4().hex[:8]}{ext}"

    save_path = save_dir / filename
    save_path.write_bytes(file_bytes)
    logger.info(
        "wecom media saved: %s (%d bytes)",
        save_path,
        len(file_bytes),
    )
    return str(save_path)


async def read_and_send_media(
    ws_client: Any,
    chat_id: str,
    file_path: str,
    content_type: str,
) -> None:
    """Read a local file and send it via WeCom proactive message.

    Falls back to sending as a file link in markdown if upload is not
    supported by the SDK.
    """
    from .constants import MEDIA_SEND_TIMEOUT

    path = Path(file_path)
    if not path.exists():
        logger.warning("wecom read_and_send_media: file not found: %s", file_path)
        return

    # For now, send as markdown with file reference.
    # Full upload support can be added when the SDK provides upload_media().
    media_type_label = "图片" if content_type == "image" else "文件"
    text = f"[{media_type_label}: {path.name}]"

    try:
        await asyncio.wait_for(
            ws_client.send_message(
                chat_id,
                {
                    "msgtype": "markdown",
                    "markdown": {"content": text},
                },
            ),
            timeout=MEDIA_SEND_TIMEOUT,
        )
    except Exception as exc:
        logger.error("wecom read_and_send_media failed: %s", exc)
