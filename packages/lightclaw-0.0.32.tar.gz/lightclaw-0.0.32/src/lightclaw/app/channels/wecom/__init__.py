"""WeCom (Enterprise WeChat) channel package."""

from .channel import WeComChannel

__all__ = ["WeComChannel"]
