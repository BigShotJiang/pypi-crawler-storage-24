"""WeCom channel constants."""

# Timeouts (seconds)
MEDIA_DOWNLOAD_TIMEOUT = 30
MEDIA_SEND_TIMEOUT = 15
STREAM_REPLY_TIMEOUT = 10

# Media size limits (bytes)
IMAGE_MAX_BYTES = 10 * 1024 * 1024  # 10MB
FILE_MAX_BYTES = 20 * 1024 * 1024  # 20MB

# Channel identifier
WECOM_CHANNEL_ID = "wecom"
