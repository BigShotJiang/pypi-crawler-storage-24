# pylint: disable=too-many-return-statements
"""
Bridge between channels and AgentApp process: factory to build
ProcessHandler from runner. Shared helpers for channels (e.g. file URL).
"""

from __future__ import annotations

import os
from typing import Any
from urllib.parse import urljoin, urlparse
from urllib.request import url2pathname
from uuid import uuid4


def file_url_to_local_path(url: str) -> str | None:
    """Convert file:// URL or plain local path to local path string.

    Supports:
    - file:// URL (all platforms): file:///path, file://D:/path,
      file://D:\\path (Windows two-slash).
    - Plain local path: D:\\path, /tmp/foo (no scheme). Pass-through after
      stripping whitespace; no existence check (caller may use Path().exists).

    Returns None only when url is clearly not a local file (e.g. http(s) URL)
    or file URL could not be resolved to a non-empty path.
    """
    if not url or not isinstance(url, str):
        return None
    s = url.strip()
    if not s:
        return None
    parsed = urlparse(s)
    if parsed.scheme == "file":
        path = url2pathname(parsed.path)
        if not path and parsed.netloc:
            path = url2pathname(parsed.netloc.replace("\\", "/"))
        elif path and parsed.netloc and len(parsed.netloc) == 1 and os.name == "nt":
            path = f"{parsed.netloc}:{path}"
        return path if path else None
    if parsed.scheme in ("http", "https"):
        return None
    if not parsed.scheme:
        return s
    if os.name == "nt" and len(parsed.scheme) == 1 and parsed.path.startswith("\\"):
        return s
    return None


def to_public_access_url(url: str) -> str:
    """Convert local attachment paths to public absolute URLs when possible."""
    if not url or not isinstance(url, str):
        return ""
    s = url.strip()
    if not s:
        return ""

    parsed = urlparse(s)
    if parsed.scheme in ("http", "https", "data", "file"):
        return s

    if s.startswith("/"):
        base = os.environ.get("LIGHTCLAW_PUBLIC_BASE_URL", "").strip()
        if base:
            return urljoin(base.rstrip("/") + "/", s.lstrip("/"))
    return s


def _extract_task_description(request: Any) -> str:
    """Extract a short task description from the latest user input."""
    input_messages = getattr(request, "input", None) or []
    if not input_messages:
        return ""

    last_msg = input_messages[-1]
    if hasattr(last_msg, "get_text_content"):
        text = last_msg.get_text_content() or ""
    else:
        text = str(getattr(last_msg, "content", "") or "")
    return text[:120]


async def _track_process_event(registry: Any, task_id: str, event: Any) -> None:
    """Mirror ``/api/agent/process`` task status tracking for channel traffic."""
    from ..tasks import TaskStatus

    obj = getattr(event, "object", None)
    status_str = getattr(event, "status", None)

    if obj == "response":
        if status_str == "in_progress":
            await registry.update_task(task_id, status=TaskStatus.THINKING)
        return

    if obj == "message":
        msg_type = getattr(event, "type", "")
        if msg_type in {
            "function_call",
            "plugin_call",
            "mcp_tool_call",
            "component_call",
        }:
            tool_name = ""
            content = getattr(event, "content", None) or []
            if content:
                first = content[0]
                if isinstance(first, dict):
                    tool_name = first.get("name", "")
                elif hasattr(first, "name"):
                    tool_name = first.name or ""
            await registry.update_task(
                task_id,
                status=TaskStatus.TOOL_CALLING,
                current_tool=tool_name,
            )
        elif msg_type == "message" and status_str == "in_progress":
            await registry.update_task(
                task_id,
                status=TaskStatus.STREAMING,
                current_tool=None,
            )
        return

    if obj == "content" and getattr(event, "delta", False):
        await registry.update_task(task_id, status=TaskStatus.STREAMING)


def _build_task_info(request: Any, task_id: str):
    """Build a Task Board snapshot for one channel-originated request."""
    from ..tasks import TaskInfo, TaskSource, TaskStatus, resolve_role

    description = _extract_task_description(request)
    channel = getattr(request, "channel", "dashboard") or "dashboard"
    task_source = TaskSource.CHAT if channel == "dashboard" else TaskSource.CHANNEL
    agent_role, agent_name = resolve_role(
        description=description,
        source=task_source,
        task_id=task_id,
    )
    return TaskInfo(
        id=task_id,
        source=task_source,
        session_id=getattr(request, "session_id", "") or "",
        user_id=getattr(request, "user_id", "") or "",
        channel=channel,
        status=TaskStatus.QUEUED,
        description=description,
        agent_name=agent_name,
        agent_role=agent_role,
    )


def make_process_from_runner(runner: Any, task_registry: Any = None):
    """Build the channel process handler from ``runner.stream_turns``.

    When ``task_registry`` is provided, channel-originated requests will also
    publish task lifecycle events so Task Board / virtual office can react to
    messages from external channels (QQ, Feishu, DingTalk, etc.).
    """
    if task_registry is None:
        return runner.stream_turns

    async def _tracked_process(request: Any):
        from ..schemas import AgentRequest
        from ..tasks import TaskStatus

        normalized_request = AgentRequest(**request) if isinstance(request, dict) else request
        task_id = str(uuid4())
        task_info = _build_task_info(normalized_request, task_id)

        await task_registry.register_task(task_info)
        try:
            async for event in runner.stream_turns(normalized_request):
                await _track_process_event(task_registry, task_id, event)
                yield event
            await task_registry.complete_task(task_id, TaskStatus.COMPLETED)
        except Exception:
            await task_registry.complete_task(task_id, TaskStatus.FAILED)
            raise

    return _tracked_process
