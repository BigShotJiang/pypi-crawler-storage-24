"""Compatibility shim: re-export from channels.core.renderer."""

from .core.renderer import MessageRenderer, RenderStyle

__all__ = ["MessageRenderer", "RenderStyle"]
