"""Yuanbao WebSocket client.

Manages the persistent WebSocket connection to YuanBao's gateway, including
authentication, heartbeat, reconnection, and request/response matching.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import platform
import time
from typing import Any

import aiohttp

from .codec import (
    BIZ_CMD_SEND_C2C,
    BIZ_CMD_SEND_GROUP,
    BIZ_MODULE,
    CMD_AUTH_BIND,
    CMD_KICKOUT,
    CMD_PING,
    CMD_TYPE_PUSH,
    CMD_TYPE_RESPONSE,
    PB_MSG_TYPES,
    build_auth_bind_msg,
    build_business_conn_msg,
    build_ping_msg,
    build_push_ack,
    decode_conn_msg,
    decode_pb,
    decode_send_msg_rsp,
    encode_send_c2c_msg_req,
    encode_send_group_msg_req,
    generate_msg_id,
)

logger = logging.getLogger(__name__)

LOG_PREFIX = "[yuanbao]"

# Close codes that must NOT trigger reconnection
NO_RECONNECT_CLOSE_CODES = frozenset({4012, 4013, 4014, 4018, 4019, 4021})

DEFAULT_RECONNECT_DELAYS = [1, 2, 5, 10, 30, 60]
DEFAULT_MAX_RECONNECT_ATTEMPTS = 100
DEFAULT_SEND_TIMEOUT_S = 30
DEFAULT_HEARTBEAT_INTERVAL_S = 5
HEARTBEAT_TIMEOUT_THRESHOLD = 2


class _PendingRequest:
    """Tracks an in-flight business request."""

    def __init__(self) -> None:
        self.future: asyncio.Future[dict[str, Any]] = asyncio.get_running_loop().create_future()
        self.timeout_handle: asyncio.TimerHandle | None = None


class YuanbaoWsClient:
    """Async WebSocket client for the YuanBao bot gateway."""

    def __init__(
        self,
        *,
        gateway_url: str,
        auth: dict[str, str],
        max_reconnect_attempts: int = DEFAULT_MAX_RECONNECT_ATTEMPTS,
        on_dispatch: Any | None = None,
        on_ready: Any | None = None,
        on_state_change: Any | None = None,
        on_error: Any | None = None,
        on_kickout: Any | None = None,
    ) -> None:
        self._gateway_url = gateway_url
        self._auth = auth
        self._max_reconnect_attempts = max_reconnect_attempts

        # Callbacks
        self._on_dispatch = on_dispatch
        self._on_ready = on_ready
        self._on_state_change = on_state_change
        self._on_error = on_error
        self._on_kickout = on_kickout

        self._ws: aiohttp.ClientWebSocketResponse | None = None
        self._session: aiohttp.ClientSession | None = None
        self._state: str = "disconnected"
        self._connect_id: str | None = None
        self._disposed = False

        # Heartbeat
        self._heartbeat_interval_s = DEFAULT_HEARTBEAT_INTERVAL_S
        self._heartbeat_task: asyncio.Task[None] | None = None
        self._heartbeat_ack_received = True
        self._last_heartbeat_at: float = 0
        self._heartbeat_timeout_count = 0

        # Reconnection
        self._reconnect_attempts = 0
        self._reconnect_task: asyncio.Task[None] | None = None

        # Pending requests
        self._pending: dict[str, _PendingRequest] = {}

        # Background reader task
        self._reader_task: asyncio.Task[None] | None = None

    @property
    def state(self) -> str:
        return self._state

    @property
    def connect_id(self) -> str | None:
        return self._connect_id

    async def connect(self) -> None:
        """Start the WebSocket connection."""
        if self._disposed:
            raise RuntimeError("Client has been disposed")
        await self._do_connect()

    async def disconnect(self) -> None:
        """Gracefully disconnect and clean up."""
        self._disposed = True
        await self._cleanup()

    async def send_c2c_message(self, data: dict[str, Any]) -> dict[str, Any]:
        """Send a private (C2C) message and wait for response."""
        encoded = encode_send_c2c_msg_req(data)
        if not encoded:
            raise RuntimeError("Failed to encode SendC2CMessageReq")
        return await self._send_and_wait(BIZ_CMD_SEND_C2C, BIZ_MODULE, encoded)

    async def send_group_message(self, data: dict[str, Any]) -> dict[str, Any]:
        """Send a group message and wait for response."""
        encoded = encode_send_group_msg_req(data)
        if not encoded:
            raise RuntimeError("Failed to encode SendGroupMessageReq")
        return await self._send_and_wait(BIZ_CMD_SEND_GROUP, BIZ_MODULE, encoded)

    # ------------------------------------------------------------------
    # Internal connection management
    # ------------------------------------------------------------------

    def _set_state(self, state: str) -> None:
        if self._state == state:
            return
        self._state = state
        if self._on_state_change:
            self._on_state_change(state)

    async def _do_connect(self) -> None:
        if self._disposed:
            return
        self._set_state("connecting")
        logger.info("%s connecting to %s", LOG_PREFIX, self._gateway_url)

        try:
            if self._session is None:
                self._session = aiohttp.ClientSession()
            self._ws = await self._session.ws_connect(
                self._gateway_url,
                protocols=["binary"],
            )
            logger.info("%s WebSocket opened, sending auth...", LOG_PREFIX)
            self._reconnect_attempts = 0
            await self._send_auth_bind()

            # Start background reader
            self._reader_task = asyncio.create_task(self._read_loop())
        except Exception as e:
            logger.error("%s connection failed: %s", LOG_PREFIX, e)
            if self._on_error:
                self._on_error(e)
            if not self._disposed:
                self._schedule_reconnect()

    async def _read_loop(self) -> None:
        """Read messages from WebSocket until disconnected."""
        try:
            async for msg in self._ws:  # type: ignore[union-attr]
                if msg.type == aiohttp.WSMsgType.BINARY:
                    await self._on_message(msg.data)
                elif msg.type == aiohttp.WSMsgType.TEXT:
                    # Unexpected text, ignore
                    logger.debug("%s received unexpected text message", LOG_PREFIX)
                elif msg.type in (aiohttp.WSMsgType.CLOSED, aiohttp.WSMsgType.CLOSING):
                    break
                elif msg.type == aiohttp.WSMsgType.ERROR:
                    logger.error(
                        "%s WebSocket error: %s",
                        LOG_PREFIX,
                        self._ws.exception() if self._ws else "unknown",
                    )
                    break
        except asyncio.CancelledError:
            return
        except Exception as e:
            logger.error("%s read loop error: %s", LOG_PREFIX, e)
            if self._on_error:
                self._on_error(e)

        # Connection closed
        self._stop_heartbeat()
        close_code = getattr(self._ws, "close_code", None)
        logger.info("%s connection closed: code=%s", LOG_PREFIX, close_code)

        if not self._disposed:
            if close_code and close_code in NO_RECONNECT_CLOSE_CODES:
                logger.info("%s non-retryable close code=%s, giving up", LOG_PREFIX, close_code)
                self._set_state("disconnected")
                if self._on_error:
                    self._on_error(RuntimeError(f"Non-retryable close code={close_code}"))
            else:
                self._schedule_reconnect()

    async def _on_message(self, raw: bytes) -> None:
        """Process a single binary message."""
        conn_msg = decode_conn_msg(raw)
        if not conn_msg or not conn_msg.get("head"):
            logger.warning("%s received undecodable message", LOG_PREFIX)
            return
        await self._handle_conn_msg(conn_msg)

    async def _handle_conn_msg(self, conn_msg: dict[str, Any]) -> None:
        head = conn_msg["head"]
        cmd_type = head.get("cmdType", 0)

        if cmd_type == CMD_TYPE_RESPONSE:
            await self._on_response(conn_msg)
        elif cmd_type == CMD_TYPE_PUSH:
            await self._on_push(conn_msg)
        else:
            logger.debug("%s unhandled cmdType=%s cmd=%s", LOG_PREFIX, cmd_type, head.get("cmd"))

    # ------------------------------------------------------------------
    # Auth
    # ------------------------------------------------------------------

    async def _send_auth_bind(self) -> None:
        self._set_state("authenticating")
        msg_id = generate_msg_id()
        binary = build_auth_bind_msg(
            biz_id=self._auth.get("biz_id", "ybBot"),
            uid=self._auth.get("uid", ""),
            source=self._auth.get("source", "bot"),
            token=self._auth.get("token", ""),
            msg_id=msg_id,
            route_env=self._auth.get("route_env"),
            app_version="1.0.0",
            bot_version="lightclaw",
            operation_system=platform.system(),
        )
        if not binary:
            logger.error("%s failed to encode auth-bind", LOG_PREFIX)
            if self._on_error:
                self._on_error(RuntimeError("Failed to encode auth-bind message"))
            return
        logger.info("%s sending auth request...", LOG_PREFIX)
        await self._send_binary(binary)

    async def _on_response(self, conn_msg: dict[str, Any]) -> None:
        head = conn_msg["head"]
        data = conn_msg.get("data", b"")
        cmd = head.get("cmd", "")

        if cmd == CMD_AUTH_BIND:
            self._on_auth_bind_response(head, data)
        elif cmd == CMD_PING:
            self._on_ping_response(head, data)
        else:
            self._on_business_response(head, data)

    def _on_auth_bind_response(self, head: dict[str, Any], data: bytes) -> None:
        status = head.get("status", 0)
        if status and status != 0:
            logger.error("%s auth failed: status=%s", LOG_PREFIX, status)
            rsp = decode_pb(PB_MSG_TYPES["AuthBindRsp"], data)
            if rsp:
                logger.error(
                    "%s auth detail: code=%s message=%s",
                    LOG_PREFIX,
                    rsp.get("code"),
                    rsp.get("message"),
                )
            if self._on_error:
                self._on_error(RuntimeError(f"Auth-bind failed: status={status}"))
            return

        rsp = decode_pb(PB_MSG_TYPES["AuthBindRsp"], data)
        if not rsp or rsp.get("code", 0) != 0:
            logger.error("%s auth response error: %s", LOG_PREFIX, rsp)
            if self._on_error:
                self._on_error(RuntimeError(f"Auth-bind response error: code={rsp.get('code') if rsp else 'none'}"))
            return

        self._connect_id = rsp.get("connectId")
        logger.info("%s auth success: connectId=%s", LOG_PREFIX, self._connect_id)
        self._set_state("connected")
        self._start_heartbeat(is_first=True)
        if self._on_ready:
            self._on_ready(
                {
                    "connect_id": self._connect_id or "",
                    "timestamp": int(rsp.get("timestamp", 0)),
                    "client_ip": rsp.get("clientIp", ""),
                }
            )

    # ------------------------------------------------------------------
    # Heartbeat
    # ------------------------------------------------------------------

    def _start_heartbeat(self, *, is_first: bool = False) -> None:
        self._stop_heartbeat()
        self._heartbeat_ack_received = True
        if is_first:
            self._heartbeat_timeout_count = 0
        delay = 5.0 if is_first else max(1.0, self._heartbeat_interval_s - 1)
        self._heartbeat_task = asyncio.create_task(self._heartbeat_loop(delay))

    def _stop_heartbeat(self) -> None:
        if self._heartbeat_task and not self._heartbeat_task.done():
            self._heartbeat_task.cancel()
            self._heartbeat_task = None

    async def _heartbeat_loop(self, initial_delay: float) -> None:
        try:
            await asyncio.sleep(initial_delay)
            while not self._disposed:
                await self._send_ping()
                await asyncio.sleep(max(1.0, self._heartbeat_interval_s - 1))
        except asyncio.CancelledError:
            return

    async def _send_ping(self) -> None:
        if not self._heartbeat_ack_received:
            self._heartbeat_timeout_count += 1
            elapsed = time.monotonic() - self._last_heartbeat_at
            if self._heartbeat_timeout_count >= HEARTBEAT_TIMEOUT_THRESHOLD:
                logger.warning(
                    "%s heartbeat timeout %d times (%.1fs), reconnecting",
                    LOG_PREFIX,
                    self._heartbeat_timeout_count,
                    elapsed,
                )
                self._heartbeat_timeout_count = 0
                await self._close_current_ws()
                self._schedule_reconnect()
                return
            logger.warning(
                "%s heartbeat timeout (%.1fs), attempt %d/%d",
                LOG_PREFIX,
                elapsed,
                self._heartbeat_timeout_count,
                HEARTBEAT_TIMEOUT_THRESHOLD,
            )
            return

        msg_id = generate_msg_id()
        binary = build_ping_msg(msg_id)
        if not binary:
            logger.error("%s failed to encode ping", LOG_PREFIX)
            return
        self._heartbeat_ack_received = False
        self._last_heartbeat_at = time.monotonic()
        await self._send_binary(binary)

    def _on_ping_response(self, head: dict[str, Any], data: bytes) -> None:
        self._heartbeat_ack_received = True
        self._heartbeat_timeout_count = 0
        latency = time.monotonic() - self._last_heartbeat_at
        rsp = decode_pb(PB_MSG_TYPES["PingRsp"], data)
        if rsp and rsp.get("heartInterval") and int(rsp["heartInterval"]) > 1:
            self._heartbeat_interval_s = int(rsp["heartInterval"])
        logger.debug("%s heartbeat ACK: latency=%.1fms", LOG_PREFIX, latency * 1000)

    # ------------------------------------------------------------------
    # Push handling
    # ------------------------------------------------------------------

    async def _on_push(self, conn_msg: dict[str, Any]) -> None:
        head = conn_msg["head"]
        data = conn_msg.get("data", b"")

        # ACK if needed
        if head.get("needAck"):
            ack = build_push_ack(head)
            if ack:
                await self._send_binary(ack)

        # Kickout
        if head.get("cmd") == CMD_KICKOUT:
            kickout = decode_pb(PB_MSG_TYPES["KickoutMsg"], data)
            logger.warning("%s kicked out: %s", LOG_PREFIX, kickout)
            if self._on_kickout:
                self._on_kickout(
                    {
                        "status": kickout.get("status", 0) if kickout else 0,
                        "reason": kickout.get("reason", "") if kickout else "",
                    }
                )
            return

        # Try DirectedPush
        directed = decode_pb(PB_MSG_TYPES["DirectedPush"], data)
        if directed and (directed.get("type") or directed.get("content")):
            push_event = {
                "type": directed.get("type"),
                "content": directed.get("content"),
                "cmd": head.get("cmd"),
                "module": head.get("module"),
                "msg_id": head.get("msgId"),
            }
            if self._on_dispatch:
                self._on_dispatch(push_event)
            return

        # Try PushMsg
        push_msg = decode_pb(PB_MSG_TYPES["PushMsg"], data)
        if push_msg:
            push_event = {
                "cmd": push_msg.get("cmd") or head.get("cmd"),
                "module": push_msg.get("module") or head.get("module"),
                "msg_id": push_msg.get("msgId") or head.get("msgId"),
                "raw_data": push_msg.get("data"),
            }
            if self._on_dispatch:
                self._on_dispatch(push_event)
            return

        # Fallback
        if self._on_dispatch:
            self._on_dispatch(
                {
                    "cmd": head.get("cmd"),
                    "module": head.get("module"),
                    "msg_id": head.get("msgId"),
                    "raw_data": data,
                }
            )

    # ------------------------------------------------------------------
    # Business request/response
    # ------------------------------------------------------------------

    async def _send_and_wait(
        self,
        cmd: str,
        module: str,
        data: bytes,
        timeout_s: float = DEFAULT_SEND_TIMEOUT_S,
    ) -> dict[str, Any]:
        msg_id = generate_msg_id()
        binary = build_business_conn_msg(cmd, module, data, msg_id)
        if not binary:
            raise RuntimeError("Failed to encode business message")

        pending = _PendingRequest()
        loop = asyncio.get_running_loop()

        def _on_timeout() -> None:
            self._pending.pop(msg_id, None)
            if not pending.future.done():
                pending.future.set_exception(
                    TimeoutError(f"WS request timeout ({timeout_s}s) for msgId={msg_id}"),
                )

        pending.timeout_handle = loop.call_later(timeout_s, _on_timeout)
        self._pending[msg_id] = pending

        sent = await self._send_binary(binary)
        if not sent:
            if pending.timeout_handle:
                pending.timeout_handle.cancel()
            self._pending.pop(msg_id, None)
            raise RuntimeError("WebSocket not connected, cannot send")

        return await pending.future

    def _on_business_response(self, head: dict[str, Any], data: bytes) -> None:
        msg_id = head.get("msgId")
        if not msg_id:
            return
        pending = self._pending.pop(msg_id, None)
        if not pending:
            logger.debug("%s unmatched business response: cmd=%s msgId=%s", LOG_PREFIX, head.get("cmd"), msg_id)
            return

        if pending.timeout_handle:
            pending.timeout_handle.cancel()

        if data:
            rsp = decode_send_msg_rsp(data, msg_id)
            if rsp:
                status = head.get("status", 0)
                if status and status != 0:
                    rsp["code"] = status
                    rsp["message"] = rsp.get("message") or "FAIL"
                if not pending.future.done():
                    pending.future.set_result(rsp)
                return

        result = {
            "msg_id": msg_id,
            "code": head.get("status", 0),
            "message": "" if head.get("status", 0) == 0 else "FAIL",
        }
        if not pending.future.done():
            pending.future.set_result(result)

    # ------------------------------------------------------------------
    # Reconnection
    # ------------------------------------------------------------------

    def _get_reconnect_delay(self) -> float:
        idx = min(self._reconnect_attempts, len(DEFAULT_RECONNECT_DELAYS) - 1)
        return DEFAULT_RECONNECT_DELAYS[idx]

    def _schedule_reconnect(self) -> None:
        if self._disposed:
            return
        if self._reconnect_attempts >= self._max_reconnect_attempts:
            logger.error("%s max reconnect attempts (%d) reached", LOG_PREFIX, self._max_reconnect_attempts)
            self._set_state("disconnected")
            if self._on_error:
                self._on_error(RuntimeError(f"Max reconnect attempts ({self._max_reconnect_attempts}) exceeded"))
            return

        delay = self._get_reconnect_delay()
        self._reconnect_attempts += 1
        self._set_state("reconnecting")
        logger.info(
            "%s reconnecting in %.1fs (attempt %d/%d)",
            LOG_PREFIX,
            delay,
            self._reconnect_attempts,
            self._max_reconnect_attempts,
        )
        self._reconnect_task = asyncio.create_task(self._delayed_reconnect(delay))

    async def _delayed_reconnect(self, delay: float) -> None:
        try:
            await asyncio.sleep(delay)
            if not self._disposed:
                await self._do_connect()
        except asyncio.CancelledError:
            return

    # ------------------------------------------------------------------
    # Low-level helpers
    # ------------------------------------------------------------------

    async def _send_binary(self, data: bytes) -> bool:
        if not self._ws or self._ws.closed:
            logger.error("%s send failed: connection not available", LOG_PREFIX)
            return False
        try:
            await self._ws.send_bytes(data)
            return True
        except Exception as e:
            logger.error("%s send failed: %s", LOG_PREFIX, e)
            return False

    async def _close_current_ws(self) -> None:
        self._stop_heartbeat()
        if self._reader_task and not self._reader_task.done():
            self._reader_task.cancel()
            self._reader_task = None
        if self._ws and not self._ws.closed:
            with contextlib.suppress(Exception):
                await self._ws.close(code=1000, message=b"client closing")
        self._ws = None

    async def _cleanup(self) -> None:
        await self._close_current_ws()
        if self._reconnect_task and not self._reconnect_task.done():
            self._reconnect_task.cancel()
            self._reconnect_task = None

        # Resolve all pending requests
        for msg_id, pending in list(self._pending.items()):
            if pending.timeout_handle:
                pending.timeout_handle.cancel()
            if not pending.future.done():
                pending.future.set_result(
                    {
                        "msg_id": msg_id,
                        "code": -1,
                        "message": "Client disconnected",
                    }
                )
        self._pending.clear()
        self._set_state("disconnected")

        if self._session and not self._session.closed:
            await self._session.close()
            self._session = None
