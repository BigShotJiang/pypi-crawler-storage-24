"""Yuanbao Channel.

Connects to the Tencent YuanBao bot platform via WebSocket for receiving
messages, and sends replies through the same WebSocket connection using
Protobuf-encoded business messages.

Supports both C2C (direct) and group chat modes.
"""

from __future__ import annotations

import asyncio
import base64
import json
import logging
import random
from typing import Any

from ...core.error_utils import extract_event_error_message
from ...schemas import ContentType, MessageType, TextContent
from ...turn_protocol import TurnEvent, TurnEventType, TurnRequest
from ..base import BaseChannel, OnReplySent, OutgoingContentPart, ProcessHandler
from ..core.base import _INTERNAL_MESSAGE_TYPES, _TurnMsg
from .api import DEFAULT_API_DOMAIN, get_sign_token
from .codec import decode_inbound_message
from .ws_client import YuanbaoWsClient

logger = logging.getLogger(__name__)

LOG_PREFIX = "[yuanbao]"

DEFAULT_WS_GATEWAY_URL = "wss://bot-wss.yuanbao.tencent.com/wss/connection"
MAX_TEXT_CHUNK = 10000


def _extract_text_from_msg_body(
    msg_body: list[dict[str, Any]] | None,
    bot_id: str = "",
) -> tuple[str, bool]:
    """Extract text content and @bot detection from msg_body elements.

    The @bot detection mirrors the OpenClaw plugin logic:
    a TIMCustomElem whose JSON ``data`` field has ``elem_type == 1002``
    and ``user_id == bot_id`` indicates an @-mention of the bot.

    Returns:
        (text, is_at_bot) tuple.
    """
    if not msg_body:
        return "", False

    text_parts: list[str] = []
    is_at_bot = False

    for el in msg_body:
        msg_type = el.get("msg_type", "")
        content = el.get("msg_content", {})

        if msg_type == "TIMTextElem":
            t = content.get("text", "")
            if t:
                text_parts.append(t)
        elif msg_type == "TIMCustomElem":
            raw_data = content.get("data", "")
            if raw_data:
                try:
                    custom_data = json.loads(raw_data)
                    # elem_type 1002 = at-mention element (YuanBao protocol)
                    if custom_data.get("elem_type") == 1002:
                        mentioned_uid = custom_data.get("user_id", "")
                        if bot_id and mentioned_uid == bot_id:
                            is_at_bot = True
                        elif not bot_id:
                            # No bot_id available — assume any 1002 targets bot
                            is_at_bot = True
                        logger.info(
                            "%s @mention: text=%s user_id=%s isAtBot=%s",
                            LOG_PREFIX,
                            custom_data.get("text", ""),
                            mentioned_uid,
                            is_at_bot,
                        )
                    elif custom_data.get("type") == "at" and custom_data.get("atBot"):
                        # Fallback: alternative at-bot format
                        is_at_bot = True
                except (json.JSONDecodeError, TypeError):
                    pass
            # Also check desc field as fallback
            desc = content.get("desc", "")
            if desc == "@bot" and not is_at_bot:
                is_at_bot = True

    return " ".join(text_parts).strip(), is_at_bot


def _parse_push_content_to_msg(content: str | None) -> dict[str, Any] | None:
    """Parse push event content string into an inbound message dict."""
    if not content or not content.strip():
        return None
    try:
        parsed = json.loads(content)
        if isinstance(parsed, dict) and parsed.get("msg_body") and isinstance(parsed["msg_body"], list):
            return parsed
        if isinstance(parsed, dict) and parsed.get("text"):
            return {
                "msg_body": [{"msg_type": "TIMTextElem", "msg_content": {"text": parsed["text"]}}],
                **{k: v for k, v in parsed.items() if k != "text"},
            }
    except (json.JSONDecodeError, TypeError):
        pass
    # Plain text fallback
    return {
        "msg_body": [{"msg_type": "TIMTextElem", "msg_content": {"text": content}}],
    }


class YuanbaoChannel(BaseChannel):
    """Channel implementation for Tencent YuanBao bot platform."""

    channel = "yuanbao"
    uses_manager_queue = True

    def __init__(
        self,
        process: ProcessHandler,
        *,
        enabled: bool = False,
        app_key: str = "",
        app_secret: str = "",
        token: str = "",
        identifier: str = "",
        api_domain: str = DEFAULT_API_DOMAIN,
        ws_url: str = DEFAULT_WS_GATEWAY_URL,
        route_env: str = "",
        bot_prefix: str = "",
        on_reply_sent: OnReplySent = None,
        show_tool_details: bool = True,
    ) -> None:
        super().__init__(
            process=process,
            on_reply_sent=on_reply_sent,
            show_tool_details=show_tool_details,
        )
        self.enabled = enabled
        self._app_key = app_key
        self._app_secret = app_secret
        self._token = token
        self._identifier = identifier
        self._api_domain = api_domain
        self._ws_url = ws_url
        self._route_env = route_env
        self._bot_prefix = bot_prefix
        self._bot_id: str = ""

        self._ws_client: YuanbaoWsClient | None = None
        self._loop: asyncio.AbstractEventLoop | None = None
        self._gateway_task: asyncio.Task[None] | None = None

    @classmethod
    def from_config(
        cls,
        process: ProcessHandler,
        config: Any,
        on_reply_sent: OnReplySent = None,
        show_tool_details: bool = True,
    ) -> YuanbaoChannel:
        """Create a YuanbaoChannel from config object."""
        return cls(
            process=process,
            enabled=getattr(config, "enabled", False),
            app_key=getattr(config, "app_key", "") or "",
            app_secret=getattr(config, "app_secret", "") or "",
            token=getattr(config, "token", "") or "",
            identifier=getattr(config, "identifier", "") or "",
            api_domain=getattr(config, "api_domain", "") or DEFAULT_API_DOMAIN,
            ws_url=getattr(config, "ws_url", "") or DEFAULT_WS_GATEWAY_URL,
            route_env=getattr(config, "route_env", "") or "",
            bot_prefix=getattr(config, "bot_prefix", "") or "",
            on_reply_sent=on_reply_sent,
            show_tool_details=show_tool_details,
        )

    @classmethod
    def from_env(
        cls,
        process: ProcessHandler,
        on_reply_sent: OnReplySent = None,
    ) -> YuanbaoChannel:
        """Create a YuanbaoChannel from environment variables (not typically used)."""
        import os

        return cls(
            process=process,
            enabled=os.getenv("YUANBAO_ENABLED", "0") == "1",
            app_key=os.getenv("YUANBAO_APP_KEY", ""),
            app_secret=os.getenv("YUANBAO_APP_SECRET", ""),
            token=os.getenv("YUANBAO_TOKEN", ""),
            on_reply_sent=on_reply_sent,
        )

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """Start the WebSocket gateway connection."""
        if not self.enabled:
            logger.debug("%s channel disabled", LOG_PREFIX)
            return

        configured = bool(self._app_key and self._app_secret) or bool(self._token)
        if not configured:
            logger.warning(
                "%s not configured (missing app_key/app_secret or token), skipping",
                LOG_PREFIX,
            )
            return

        self._loop = asyncio.get_running_loop()
        logger.info("%s starting WebSocket gateway...", LOG_PREFIX)
        self._gateway_task = asyncio.create_task(self._run_gateway())

    async def stop(self) -> None:
        """Stop the WebSocket gateway connection."""
        logger.info("%s stopping...", LOG_PREFIX)
        if self._ws_client:
            await self._ws_client.disconnect()
            self._ws_client = None
        if self._gateway_task and not self._gateway_task.done():
            self._gateway_task.cancel()
            self._gateway_task = None

    # ------------------------------------------------------------------
    # Gateway
    # ------------------------------------------------------------------

    async def _run_gateway(self) -> None:
        """Initialize and run the WebSocket gateway."""
        try:
            auth = await self._resolve_ws_auth()

            self._ws_client = YuanbaoWsClient(
                gateway_url=self._ws_url,
                auth=auth,
                on_dispatch=self._on_ws_dispatch,
                on_ready=self._on_ws_ready,
                on_state_change=self._on_ws_state_change,
                on_error=self._on_ws_error,
                on_kickout=self._on_ws_kickout,
            )
            await self._ws_client.connect()
        except asyncio.CancelledError:
            return
        except Exception:
            logger.exception("%s gateway startup failed", LOG_PREFIX)

    async def _resolve_ws_auth(self) -> dict[str, str]:
        """Resolve WebSocket authentication parameters."""
        if self._token:
            uid = self._bot_id or self._identifier
            logger.info("%s using static token, uid=%s", LOG_PREFIX, uid)
            return {
                "biz_id": "ybBot",
                "uid": uid,
                "source": "bot",
                "token": self._token,
                "route_env": self._route_env or "",
            }

        token_data = await get_sign_token(
            app_key=self._app_key,
            app_secret=self._app_secret,
            api_domain=self._api_domain,
            route_env=self._route_env or None,
        )
        bot_id = token_data.get("bot_id", "")
        if bot_id:
            self._bot_id = bot_id
        uid = bot_id or self._bot_id or self._identifier
        logger.info("%s sign-token completed, uid=%s", LOG_PREFIX, uid)
        return {
            "biz_id": "ybBot",
            "uid": uid,
            "source": token_data.get("source", "bot"),
            "token": token_data.get("token", ""),
            "route_env": self._route_env or "",
        }

    # ------------------------------------------------------------------
    # WebSocket callbacks
    # ------------------------------------------------------------------

    def _on_ws_ready(self, data: dict[str, Any]) -> None:
        logger.info(
            "%s WebSocket ready: connectId=%s",
            LOG_PREFIX,
            data.get("connect_id"),
        )

    def _on_ws_state_change(self, state: str) -> None:
        logger.info("%s WS state: %s", LOG_PREFIX, state)

    def _on_ws_error(self, error: Exception) -> None:
        logger.error("%s WS error: %s", LOG_PREFIX, error)

    def _on_ws_kickout(self, data: dict[str, Any]) -> None:
        logger.warning(
            "%s kicked out: status=%s reason=%s",
            LOG_PREFIX,
            data.get("status"),
            data.get("reason"),
        )

    def _on_ws_dispatch(self, push_event: dict[str, Any]) -> None:
        """Handle dispatched push events from WebSocket.

        This runs in the event loop's context (called from the WS client),
        so we schedule the async handler as a task.
        """
        if self._loop:
            self._loop.call_soon_threadsafe(
                lambda: asyncio.ensure_future(self._handle_dispatch(push_event)),
            )

    async def _handle_dispatch(self, push_event: dict[str, Any]) -> None:
        """Process a push event and convert it to an inbound message."""
        msg, chat_type = self._decode_push_event(push_event)
        if not msg:
            logger.debug("%s push event is not a message, skipping", LOG_PREFIX)
            return

        logger.info(
            "%s received %s message from=%s",
            LOG_PREFIX,
            chat_type,
            msg.get("from_account", "unknown"),
        )

        # Skip messages from self
        from_account = (msg.get("from_account") or "").strip()
        if from_account and from_account == self._bot_id:
            logger.debug("%s skipping own message", LOG_PREFIX)
            return

        text, is_at_bot = _extract_text_from_msg_body(
            msg.get("msg_body"),
            bot_id=self._bot_id,
        )

        logger.info(
            "%s msg detail: chat_type=%s text=%s is_at_bot=%s msg_body_count=%d",
            LOG_PREFIX,
            chat_type,
            text[:80] if text else "(empty)",
            is_at_bot,
            len(msg.get("msg_body", [])),
        )

        # For group messages, only respond when @bot
        if chat_type == "group" and not is_at_bot:
            logger.info("%s group message without @bot, skipping", LOG_PREFIX)
            return

        if not text.strip():
            logger.info("%s empty message, skipping", LOG_PREFIX)
            return

        # Build session and sender info
        group_id = (msg.get("group_id") or "").strip()
        sender_id = from_account or "unknown"
        sender_name = (msg.get("sender_nickname") or sender_id).strip()

        if chat_type == "group" and group_id:
            session_id = f"yuanbao:group:{group_id}"
        else:
            session_id = f"yuanbao:{sender_id}"

        # Build content parts and enqueue
        content_parts: list[Any] = [TextContent(type=ContentType.TEXT, text=text)]

        channel_meta = {
            "chat_type": chat_type,
            "from_account": from_account,
            "sender_name": sender_name,
            "msg_key": msg.get("msg_key", ""),
            "msg_id": msg.get("msg_id", ""),
        }
        if group_id:
            channel_meta["group_id"] = group_id
            channel_meta["group_name"] = msg.get("group_name", "")

        request = self.build_turn_request_from_user_content(
            channel_id=self.channel,
            sender_id=sender_id,
            session_id=session_id,
            content_parts=content_parts,
            channel_meta=channel_meta,
        )

        if self._enqueue:
            self._enqueue(request)

    def _decode_push_event(
        self,
        push_event: dict[str, Any],
    ) -> tuple[dict[str, Any] | None, str]:
        """Decode a WS push event into an inbound message and chat type.

        Returns:
            (msg_dict, chat_type) or (None, "") if not decodable.
        """
        # Try raw protobuf data first
        raw_data = push_event.get("raw_data")
        if raw_data and isinstance(raw_data, bytes | bytearray):
            decoded = decode_inbound_message(bytes(raw_data))
            if decoded and self._has_valid_msg_fields(decoded):
                chat_type = "group" if decoded.get("group_id") else "c2c"
                return decoded, chat_type

            # Try JSON decode from raw bytes
            try:
                raw_json = json.loads(raw_data.decode("utf-8"))
                if isinstance(raw_json, dict) and self._has_valid_msg_fields(raw_json):
                    chat_type = "group" if raw_json.get("group_id") else "c2c"
                    return raw_json, chat_type
            except (json.JSONDecodeError, UnicodeDecodeError):
                pass
        elif raw_data and isinstance(raw_data, str):
            # base64-encoded bytes from protobuf decode
            try:
                decoded_bytes = base64.b64decode(raw_data)
                decoded = decode_inbound_message(decoded_bytes)
                if decoded and self._has_valid_msg_fields(decoded):
                    chat_type = "group" if decoded.get("group_id") else "c2c"
                    return decoded, chat_type
            except Exception:
                pass

        # Try content field
        content = push_event.get("content")
        if content:
            msg = _parse_push_content_to_msg(content)
            if msg:
                chat_type = "group" if msg.get("group_id") else "c2c"
                return msg, chat_type

        return None, ""

    @staticmethod
    def _has_valid_msg_fields(msg: dict[str, Any]) -> bool:
        return bool(msg.get("callback_command") or msg.get("from_account") or msg.get("msg_body"))

    # ------------------------------------------------------------------
    # Process loop override (accumulate deltas for non-streaming send)
    # ------------------------------------------------------------------

    async def _run_process_loop(
        self,
        request: TurnRequest,
        to_handle: str,
        send_meta: dict[str, Any],
    ) -> None:
        """Run _process and accumulate streamed text for final send.

        The default BaseChannel._run_process_loop only handles
        ASSISTANT_COMPLETED events. However, the event bridge filters out
        text content from the completed event when it has already been
        streamed via ASSISTANT_DELTA events. Since yuanbao is a
        non-streaming channel (sends one final message), we must
        accumulate deltas ourselves and use them when the completed
        event has empty content.
        """
        bot_prefix = send_meta.get("bot_prefix", "") or getattr(
            self,
            "bot_prefix",
            "",
        )
        turn_failed = False
        turn_error: Any = None
        # Accumulate streamed text by message_id
        streamed_text: dict[str, str] = {}

        try:
            async for event in self._process(request):
                if not isinstance(event, TurnEvent):
                    continue

                if event.type == TurnEventType.ASSISTANT_DELTA:
                    # Accumulate text from streaming deltas
                    delta = event.delta
                    if isinstance(delta, dict) and delta.get("type") == "text":
                        msg_id = event.message_id or "_default"
                        streamed_text[msg_id] = streamed_text.get(msg_id, "") + (delta.get("text") or "")

                elif event.type == TurnEventType.ASSISTANT_COMPLETED:
                    metadata = event.metadata or {}
                    message_type = metadata.get("message_type", MessageType.MESSAGE)

                    if message_type in _INTERNAL_MESSAGE_TYPES:
                        logger.info(
                            "%s skipped internal message_type=%s",
                            LOG_PREFIX,
                            message_type,
                        )
                        continue

                    content = list(event.content or [])

                    # If content is empty but we accumulated delta text,
                    # rebuild content from the streamed text.
                    has_text = any(
                        (isinstance(c, dict) and c.get("type") == "text" and c.get("text"))
                        or (getattr(c, "type", None) == ContentType.TEXT and getattr(c, "text", None))
                        for c in content
                    )
                    if not has_text and streamed_text:
                        full_text = "".join(streamed_text.values())
                        if full_text.strip():
                            content = [{"type": "text", "text": full_text}]
                            logger.info(
                                "%s rebuilt content from %d delta chars",
                                LOG_PREFIX,
                                len(full_text),
                            )
                    # Clear streamed buffer for next message
                    streamed_text.clear()

                    msg = _TurnMsg(
                        message_type,
                        content,
                        event.role or "assistant",
                    )
                    forwarding_meta = dict(send_meta or {})
                    forwarding_meta["_msg_type"] = message_type
                    await self.on_event_message_completed(
                        request,
                        to_handle,
                        msg,
                        forwarding_meta,
                    )

                elif event.type == TurnEventType.TURN_FAILED:
                    turn_failed = True
                    turn_error = event.error

            if turn_failed and turn_error is not None:
                err = extract_event_error_message(turn_error)
                err_text = (bot_prefix or "") + f"Error: {err}"
                await self._on_consume_error(request, to_handle, err_text)
            if self._on_reply_sent:
                args = self.get_on_reply_sent_args(request, to_handle)
                self._on_reply_sent(self.channel, *args)
        except Exception:
            logger.exception("%s consume_one failed", LOG_PREFIX)
            await self._on_consume_error(
                request,
                to_handle,
                "An error occurred while processing your request.",
            )

    # ------------------------------------------------------------------
    # Sending
    # ------------------------------------------------------------------

    def get_to_handle_from_request(self, request: Any) -> str:
        """Resolve send target from TurnRequest."""
        ctx = getattr(request, "context", {}) or {}
        meta = ctx.get("channel_meta", {})
        group_id = meta.get("group_id")
        if group_id:
            return f"group:{group_id}"
        return meta.get("from_account") or getattr(request, "user_id", "") or ""

    async def send(
        self,
        to_handle: str,
        text: str,
        meta: dict[str, Any] | None = None,
    ) -> None:
        """Send a text message to the specified target."""
        if not self._ws_client:
            logger.error("%s cannot send: WebSocket client not connected", LOG_PREFIX)
            return

        if not text.strip():
            return

        msg_body = [{"msg_type": "TIMTextElem", "msg_content": {"text": text}}]
        msg_random = random.randint(0, 0xFFFFFFFF)

        try:
            if to_handle.startswith("group:"):
                group_id = to_handle[len("group:") :]
                ref_msg_id = (meta or {}).get("msg_key", "") or (meta or {}).get("msg_id", "")
                result = await self._ws_client.send_group_message(
                    {
                        "group_id": group_id,
                        "msg_body": msg_body,
                        "random": str(msg_random),
                        "from_account": self._bot_id,
                        **({"ref_msg_id": ref_msg_id} if ref_msg_id else {}),
                    }
                )
            else:
                result = await self._ws_client.send_c2c_message(
                    {
                        "to_account": to_handle,
                        "msg_body": msg_body,
                        "msg_random": msg_random,
                        **({"from_account": self._bot_id} if self._bot_id else {}),
                    }
                )

            code = result.get("code", 0)
            if code != 0:
                logger.error(
                    "%s send failed: code=%s message=%s",
                    LOG_PREFIX,
                    code,
                    result.get("message"),
                )
            else:
                logger.info(
                    "%s sent message -> %s, msgId=%s",
                    LOG_PREFIX,
                    to_handle[:30],
                    result.get("msg_id"),
                )
        except Exception:
            logger.exception("%s send failed", LOG_PREFIX)

    async def send_content_parts(
        self,
        to_handle: str,
        parts: list[OutgoingContentPart],
        meta: dict[str, Any] | None = None,
    ) -> None:
        """Send content parts, assembling text and handling media."""
        text_parts: list[str] = []
        for p in parts:
            t = getattr(p, "type", None)
            if t == ContentType.TEXT and getattr(p, "text", None):
                text_parts.append(p.text or "")
            elif t == ContentType.REFUSAL and getattr(p, "refusal", None):
                text_parts.append(p.refusal or "")
            elif t == ContentType.IMAGE and getattr(p, "image_url", None):
                text_parts.append(f"[Image: {p.image_url}]")
            elif t == ContentType.VIDEO and getattr(p, "video_url", None):
                text_parts.append(f"[Video: {p.video_url}]")
            elif t == ContentType.FILE:
                url = getattr(p, "file_url", None) or getattr(p, "file_id", None)
                if url:
                    text_parts.append(f"[File: {url}]")

        body = "\n".join(text_parts) if text_parts else ""
        prefix = (meta or {}).get("bot_prefix", "") or ""
        if prefix and body:
            body = prefix + body

        if body.strip():
            await self.send(to_handle, body.strip(), meta)

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------

    def get_connection_status(self) -> dict:
        """Return channel connection status."""
        if not self.enabled:
            return {"status": "not_enabled", "reason": None}
        if not self._ws_client:
            return {"status": "disconnected", "reason": "WebSocket client not initialized"}
        state = self._ws_client.state
        if state == "connected":
            return {"status": "connected", "reason": None}
        return {"status": "disconnected", "reason": f"WebSocket state: {state}"}

    async def verify_credentials(self) -> dict:
        """Verify channel credentials."""
        if not self.enabled:
            return {"valid": False, "status": "not_enabled", "reason": None}
        if self._token:
            return {"valid": True, "status": "connected", "reason": None}
        if not self._app_key or not self._app_secret:
            return {
                "valid": False,
                "status": "disconnected",
                "reason": "Missing appKey or appSecret",
            }
        try:
            await get_sign_token(
                app_key=self._app_key,
                app_secret=self._app_secret,
                api_domain=self._api_domain,
            )
            return {"valid": True, "status": "connected", "reason": None}
        except Exception as e:
            return {
                "valid": False,
                "status": "disconnected",
                "reason": str(e),
            }

    @staticmethod
    async def verify_credentials_with_params(credentials: dict) -> dict:
        """Verify credentials without an instance."""
        app_key = credentials.get("app_key", "")
        app_secret = credentials.get("app_secret", "")
        token = credentials.get("token", "")

        if token:
            return {"valid": True, "status": "connected", "reason": None}

        if not app_key or not app_secret:
            return {
                "valid": False,
                "status": "disconnected",
                "reason": "Missing appKey or appSecret",
            }
        try:
            await get_sign_token(
                app_key=app_key,
                app_secret=app_secret,
                api_domain=credentials.get("api_domain", DEFAULT_API_DOMAIN),
            )
            return {"valid": True, "status": "connected", "reason": None}
        except Exception as e:
            return {
                "valid": False,
                "status": "disconnected",
                "reason": str(e),
            }
