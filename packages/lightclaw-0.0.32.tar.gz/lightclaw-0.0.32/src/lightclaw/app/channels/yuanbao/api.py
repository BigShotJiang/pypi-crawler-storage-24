"""Yuanbao HTTP API helpers.

Handles sign-token authentication, token caching, and generic API requests
to the YuanBao bot platform.
"""

from __future__ import annotations

import hashlib
import hmac
import logging
import os
import platform
import time
from datetime import datetime, timezone
from typing import Any

import aiohttp

logger = logging.getLogger(__name__)

LOG_PREFIX = "[yuanbao-api]"

SIGN_TOKEN_PATH = "/api/v5/robotLogic/sign-token"
DEFAULT_API_DOMAIN = "bot.yuanbao.tencent.com"

SIGN_MAX_RETRIES = 3
SIGN_RETRY_DELAY_S = 1.0
CACHE_TTL_S = 20 * 24 * 3600  # 20 days

# Token cache
_token_cache: dict[str, dict[str, Any]] = {}


def _compute_signature(nonce: str, timestamp: str, app_key: str, app_secret: str) -> str:
    """Compute HMAC-SHA256 signature for sign-token request."""
    plain = nonce + timestamp + app_key + app_secret
    return hmac.new(app_secret.encode("utf-8"), plain.encode("utf-8"), hashlib.sha256).hexdigest()


def _generate_nonce() -> str:
    return os.urandom(16).hex()


def _beijing_timestamp() -> str:
    """Generate Beijing timezone timestamp in ISO 8601 format."""
    from datetime import timedelta

    bj_tz = timezone(timedelta(hours=8))
    now = datetime.now(tz=bj_tz)
    # Format: 2024-01-15T10:30:00+08:00 (no milliseconds)
    return now.strftime("%Y-%m-%dT%H:%M:%S+08:00")


def _credential_fingerprint(app_key: str, app_secret: str) -> str:
    """Compute a short hash fingerprint from credentials for cache invalidation."""
    raw = f"{app_key}:{app_secret}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]


async def get_sign_token(
    *,
    app_key: str,
    app_secret: str,
    api_domain: str = DEFAULT_API_DOMAIN,
    account_id: str = "default",
    route_env: str | None = None,
) -> dict[str, Any]:
    """Get a sign token, using cache when available.

    The cache is keyed by *account_id* **and** a fingerprint of the
    credentials.  When the caller switches to a different app_key /
    app_secret pair the stale entry is automatically evicted.
    """
    fp = _credential_fingerprint(app_key, app_secret)
    cached = _token_cache.get(account_id)
    if cached and cached.get("expires_at", 0) > time.time() and cached.get("fp") == fp:
        logger.info("%s [%s] using cached token", LOG_PREFIX, account_id)
        return cached["data"]

    data = await _do_fetch_sign_token(
        app_key=app_key,
        app_secret=app_secret,
        api_domain=api_domain,
        account_id=account_id,
        route_env=route_env,
    )
    _token_cache[account_id] = {
        "data": data,
        "expires_at": time.time() + CACHE_TTL_S,
        "fp": fp,
    }
    return data


async def _do_fetch_sign_token(
    *,
    app_key: str,
    app_secret: str,
    api_domain: str,
    account_id: str,
    route_env: str | None,
) -> dict[str, Any]:
    """Fetch a sign token from the YuanBao API."""
    if not app_key or not app_secret:
        raise RuntimeError("Missing appKey or appSecret for sign-token")

    url = f"https://{api_domain}{SIGN_TOKEN_PATH}"

    for attempt in range(SIGN_MAX_RETRIES + 1):
        nonce = _generate_nonce()
        timestamp = _beijing_timestamp()
        signature = _compute_signature(nonce, timestamp, app_key, app_secret)

        body = {
            "app_key": app_key,
            "nonce": nonce,
            "signature": signature,
            "timestamp": timestamp,
        }

        headers: dict[str, str] = {
            "Content-Type": "application/json",
            "X-AppVersion": "1.0.0",
            "X-OperationSystem": platform.system(),
            "X-Instance-Id": "16",
            "X-Bot-Version": "lightclaw",
        }
        if route_env:
            headers["x-route-env"] = route_env

        logger.info(
            "%s [%s] signing token: url=%s attempt=%d",
            LOG_PREFIX,
            account_id,
            url,
            attempt,
        )

        async with aiohttp.ClientSession() as session, session.post(url, json=body, headers=headers) as resp:
            if not resp.ok:
                raise RuntimeError(
                    f"Sign-token request failed: HTTP {resp.status} {resp.reason}",
                )
            result = await resp.json()

        if result.get("code") == 0:
            data = result.get("data", {})
            logger.info(
                "%s [%s] sign-token success: bot_id=%s",
                LOG_PREFIX,
                account_id,
                data.get("bot_id"),
            )
            return data

        retryable_code = 10099
        if result.get("code") == retryable_code and attempt < SIGN_MAX_RETRIES:
            logger.warning(
                "%s [%s] retryable error code=%s, retrying in %.1fs",
                LOG_PREFIX,
                account_id,
                result.get("code"),
                SIGN_RETRY_DELAY_S,
            )
            import asyncio

            await asyncio.sleep(SIGN_RETRY_DELAY_S)
            continue

        raise RuntimeError(
            f"Sign-token error: code={result.get('code')}, msg={result.get('msg')}",
        )

    raise RuntimeError("Sign-token failed: max retries exceeded")


def clear_token_cache(account_id: str | None = None) -> None:
    """Clear cached sign tokens."""
    if account_id:
        _token_cache.pop(account_id, None)
    else:
        _token_cache.clear()
