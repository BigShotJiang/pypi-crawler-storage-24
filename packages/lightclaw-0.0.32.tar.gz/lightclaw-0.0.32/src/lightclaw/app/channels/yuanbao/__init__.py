"""Yuanbao channel package."""

from .channel import YuanbaoChannel

__all__ = ["YuanbaoChannel"]
