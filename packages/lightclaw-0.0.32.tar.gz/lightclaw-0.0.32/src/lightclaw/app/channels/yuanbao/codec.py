"""Yuanbao WebSocket protocol codec.

Encodes / decodes Protobuf messages for the YuanBao connection and business
protocols using the ``protobuf`` library with JSON descriptors loaded at
runtime.
"""

from __future__ import annotations

import json
import logging
import threading
import uuid
from pathlib import Path
from typing import Any

from google.protobuf import descriptor_pb2, descriptor_pool, json_format
from google.protobuf.message_factory import GetMessageClass

logger = logging.getLogger(__name__)

_PROTO_DIR = Path(__file__).parent / "proto"

# ---------------------------------------------------------------------------
# Lazy-loaded protobuf registries
# ---------------------------------------------------------------------------

_pool = descriptor_pool.DescriptorPool()
_conn_loaded = False
_biz_loaded = False
_lock = threading.Lock()


def _json_descriptor_to_file_proto(json_path: Path, *, filename: str) -> descriptor_pb2.FileDescriptorProto:
    """Convert a protobufjs JSON descriptor to a ``FileDescriptorProto``.

    The JSON files shipped with the yuanbao plugin are protobufjs-style nested
    descriptors.  Namespaces (nodes with only ``nested``) are collapsed into
    the ``package`` field, and actual messages / enums are added at file level.
    """
    raw = json.loads(json_path.read_text(encoding="utf-8"))
    fdp = descriptor_pb2.FileDescriptorProto()
    fdp.name = filename
    fdp.syntax = raw.get("options", {}).get("syntax", "proto3")

    scalar_map = {
        "string": descriptor_pb2.FieldDescriptorProto.TYPE_STRING,
        "bytes": descriptor_pb2.FieldDescriptorProto.TYPE_BYTES,
        "uint32": descriptor_pb2.FieldDescriptorProto.TYPE_UINT32,
        "uint64": descriptor_pb2.FieldDescriptorProto.TYPE_UINT64,
        "int32": descriptor_pb2.FieldDescriptorProto.TYPE_INT32,
        "int64": descriptor_pb2.FieldDescriptorProto.TYPE_INT64,
        "bool": descriptor_pb2.FieldDescriptorProto.TYPE_BOOL,
        "float": descriptor_pb2.FieldDescriptorProto.TYPE_FLOAT,
        "double": descriptor_pb2.FieldDescriptorProto.TYPE_DOUBLE,
    }

    def _populate_fields(
        msg_dp: descriptor_pb2.DescriptorProto,
        fields: dict,
    ) -> None:
        for f_name, f_spec in fields.items():
            fd = msg_dp.field.add()
            fd.name = f_name
            fd.number = f_spec["id"]
            fd.json_name = f_name
            type_str = f_spec["type"]

            if type_str in scalar_map:
                fd.type = scalar_map[type_str]
            else:
                # Message or enum reference – must be fully qualified
                fd.type = descriptor_pb2.FieldDescriptorProto.TYPE_MESSAGE
                fd.type_name = type_str

            if f_spec.get("rule") == "repeated":
                fd.label = descriptor_pb2.FieldDescriptorProto.LABEL_REPEATED
            else:
                fd.label = descriptor_pb2.FieldDescriptorProto.LABEL_OPTIONAL

    def _add_nested(parent_dp: descriptor_pb2.DescriptorProto, nested: dict) -> None:
        """Recursively add nested messages and enums to a parent message."""
        for name, spec in nested.items():
            fields = spec.get("fields")
            inner = spec.get("nested")
            values = spec.get("values")
            if values is not None:
                enum_dp = parent_dp.enum_type.add()
                enum_dp.name = name
                for v_name, v_number in values.items():
                    ev = enum_dp.value.add()
                    ev.name = v_name
                    ev.number = v_number
            elif fields is not None:
                msg_dp = parent_dp.nested_type.add()
                msg_dp.name = name
                _populate_fields(msg_dp, fields)
                if inner:
                    _add_nested(msg_dp, inner)

    def _add_to_file(nested: dict, package_parts: list[str]) -> None:
        """Walk the namespace tree.

        Pure namespace nodes (only ``nested``, no ``fields`` / ``values``)
        extend the package path.  Nodes with ``fields`` or ``values`` become
        file-level messages or enums.
        """
        for name, spec in nested.items():
            inner = spec.get("nested")
            fields = spec.get("fields")
            values = spec.get("values")

            is_pure_namespace = inner and fields is None and values is None
            if is_pure_namespace:
                # Extend the package and recurse
                _add_to_file(inner, [*package_parts, name])
            elif values is not None:
                # Enum at file level
                if package_parts:
                    fdp.package = ".".join(package_parts)
                enum_dp = fdp.enum_type.add()
                enum_dp.name = name
                for v_name, v_number in values.items():
                    ev = enum_dp.value.add()
                    ev.name = v_name
                    ev.number = v_number
            elif fields is not None:
                # Message at file level
                if package_parts:
                    fdp.package = ".".join(package_parts)
                msg_dp = fdp.message_type.add()
                msg_dp.name = name
                _populate_fields(msg_dp, fields)
                if inner:
                    _add_nested(msg_dp, inner)

    top = raw.get("nested", {})
    _add_to_file(top, [])
    return fdp


def _load_json_descriptor(json_path: Path, *, filename: str) -> None:
    """Load a protobufjs JSON descriptor into the shared pool."""
    fdp = _json_descriptor_to_file_proto(json_path, filename=filename)
    _pool.Add(fdp)


def _ensure_conn_loaded() -> None:
    global _conn_loaded
    if _conn_loaded:
        return
    with _lock:
        if _conn_loaded:
            return
        _load_json_descriptor(_PROTO_DIR / "conn.json", filename="conn.proto")
        _conn_loaded = True


def _ensure_biz_loaded() -> None:
    global _biz_loaded
    if _biz_loaded:
        return
    with _lock:
        if _biz_loaded:
            return
        _ensure_conn_loaded()
        _load_json_descriptor(_PROTO_DIR / "biz.json", filename="biz.proto")
        _biz_loaded = True


def _get_message_class(full_name: str) -> type:
    """Get a protobuf message class by fully qualified name."""
    desc = _pool.FindMessageTypeByName(full_name)
    return GetMessageClass(desc)


# ---------------------------------------------------------------------------
# Connection-layer message types
# ---------------------------------------------------------------------------

CONN_PKG = "trpc.yuanbao.conn_common"

PB_MSG_TYPES = {
    "ConnMsg": f"{CONN_PKG}.ConnMsg",
    "AuthBindReq": f"{CONN_PKG}.AuthBindReq",
    "AuthBindRsp": f"{CONN_PKG}.AuthBindRsp",
    "PingReq": f"{CONN_PKG}.PingReq",
    "PingRsp": f"{CONN_PKG}.PingRsp",
    "KickoutMsg": f"{CONN_PKG}.KickoutMsg",
    "DirectedPush": f"{CONN_PKG}.DirectedPush",
    "PushMsg": f"{CONN_PKG}.PushMsg",
}

# cmd_type constants
CMD_TYPE_REQUEST = 0
CMD_TYPE_RESPONSE = 1
CMD_TYPE_PUSH = 2
CMD_TYPE_PUSH_ACK = 3

CMD_AUTH_BIND = "auth-bind"
CMD_PING = "ping"
CMD_KICKOUT = "kickout"

MODULE_CONN_ACCESS = "conn_access"

# Business-layer
BIZ_PKG = "trpc.yuanbao.yuanbao_conn.yuanbao_openclaw_proxy"

BIZ_MSG_TYPES = {
    "MsgContent": f"{BIZ_PKG}.MsgContent",
    "MsgBodyElement": f"{BIZ_PKG}.MsgBodyElement",
    "InboundMessagePush": f"{BIZ_PKG}.InboundMessagePush",
    "SendC2CMessageReq": f"{BIZ_PKG}.SendC2CMessageReq",
    "SendGroupMessageReq": f"{BIZ_PKG}.SendGroupMessageReq",
    "SendC2CMessageRsp": f"{BIZ_PKG}.SendC2CMessageRsp",
    "SendGroupMessageRsp": f"{BIZ_PKG}.SendGroupMessageRsp",
}

BIZ_CMD_SEND_C2C = "send_c2c_message"
BIZ_CMD_SEND_GROUP = "send_group_message"
BIZ_MODULE = "yuanbao_openclaw_proxy"

# Sequence counter
_seq_counter = 0
_seq_lock = threading.Lock()


def _next_seq_no() -> int:
    global _seq_counter
    with _seq_lock:
        val = _seq_counter
        _seq_counter = val + 1
        if _seq_counter >= 2**53:
            _seq_counter = 0
        return val


def generate_msg_id() -> str:
    """Generate a 32-char hex message ID (UUID without dashes)."""
    return uuid.uuid4().hex


# ---------------------------------------------------------------------------
# Encode / Decode helpers
# ---------------------------------------------------------------------------


def encode_pb(type_name: str, value: dict[str, Any]) -> bytes | None:
    """Encode a dict into protobuf binary using the named message type."""
    try:
        _ensure_conn_loaded()
        cls = _get_message_class(type_name)
        msg = cls()
        json_format.ParseDict(value, msg)
        return msg.SerializeToString()
    except Exception:
        logger.exception("encode_pb failed: type=%s", type_name)
        return None


def decode_pb(type_name: str, data: bytes) -> dict[str, Any] | None:
    """Decode protobuf binary into a dict using the named message type."""
    try:
        _ensure_conn_loaded()
        cls = _get_message_class(type_name)
        msg = cls()
        msg.ParseFromString(data)
        return json_format.MessageToDict(msg, preserving_proto_field_name=True)
    except Exception:
        logger.debug("decode_pb failed: type=%s", type_name, exc_info=True)
        return None


def encode_biz_pb(type_name: str, value: dict[str, Any]) -> bytes | None:
    """Encode a business-layer protobuf message."""
    try:
        _ensure_biz_loaded()
        cls = _get_message_class(type_name)
        msg = cls()
        json_format.ParseDict(value, msg)
        return msg.SerializeToString()
    except Exception:
        logger.exception("encode_biz_pb failed: type=%s", type_name)
        return None


def decode_biz_pb(type_name: str, data: bytes) -> dict[str, Any] | None:
    """Decode a business-layer protobuf message."""
    try:
        _ensure_biz_loaded()
        cls = _get_message_class(type_name)
        msg = cls()
        msg.ParseFromString(data)
        return json_format.MessageToDict(msg, preserving_proto_field_name=True)
    except Exception:
        logger.debug("decode_biz_pb failed: type=%s", type_name, exc_info=True)
        return None


# ---------------------------------------------------------------------------
# Connection-layer codec
# ---------------------------------------------------------------------------


def create_head(cmd: str, module: str, msg_id: str) -> dict[str, Any]:
    """Create a ConnMsg head dict."""
    return {
        "cmdType": CMD_TYPE_REQUEST,
        "cmd": cmd,
        "seqNo": _next_seq_no(),
        "msgId": msg_id,
        "module": module,
    }


def encode_conn_msg(head: dict[str, Any], inner_data: bytes | None = None) -> bytes | None:
    """Encode a ConnMsg (head + inner data)."""
    payload: dict[str, Any] = {"head": head}
    if inner_data is not None:
        # protobuf bytes field expects base64 in JSON dict mode
        import base64

        payload["data"] = base64.b64encode(inner_data).decode("ascii")
    return encode_pb(PB_MSG_TYPES["ConnMsg"], payload)


def decode_conn_msg(raw: bytes) -> dict[str, Any] | None:
    """Decode a ConnMsg from raw bytes, returning the full message dict.

    The ``data`` field (inner payload) is returned as raw bytes.
    """
    _ensure_conn_loaded()
    try:
        cls = _get_message_class(PB_MSG_TYPES["ConnMsg"])
        msg = cls()
        msg.ParseFromString(raw)
        head_dict = (
            json_format.MessageToDict(
                msg.head,
                preserving_proto_field_name=True,
            )
            if msg.HasField("head")
            else {}
        )
        return {"head": head_dict, "data": bytes(msg.data)}
    except Exception:
        logger.debug("decode_conn_msg failed", exc_info=True)
        return None


def build_auth_bind_msg(
    *,
    biz_id: str,
    uid: str,
    source: str,
    token: str,
    msg_id: str,
    route_env: str | None = None,
    app_version: str = "",
    bot_version: str = "",
    operation_system: str = "",
) -> bytes | None:
    """Build an AuthBind request message."""
    payload: dict[str, Any] = {
        "bizId": biz_id,
        "authInfo": {
            "uid": uid,
            "source": source,
            "token": token,
        },
        "deviceInfo": {
            "appVersion": app_version,
            "appOperationSystem": operation_system,
            "botVersion": bot_version,
            "instanceId": "16",
        },
    }
    if route_env:
        payload["envName"] = route_env

    inner = encode_pb(PB_MSG_TYPES["AuthBindReq"], payload)
    if inner is None:
        return None
    head = create_head(CMD_AUTH_BIND, MODULE_CONN_ACCESS, msg_id)
    return encode_conn_msg(head, inner)


def build_ping_msg(msg_id: str) -> bytes | None:
    """Build a ping (heartbeat) request message."""
    inner = encode_pb(PB_MSG_TYPES["PingReq"], {})
    if inner is None:
        return None
    head = create_head(CMD_PING, MODULE_CONN_ACCESS, msg_id)
    return encode_conn_msg(head, inner)


def build_push_ack(original_head: dict[str, Any]) -> bytes | None:
    """Build a push-ack response for a received push."""
    ack_head = dict(original_head)
    ack_head["cmdType"] = CMD_TYPE_PUSH_ACK
    ack_head["seqNo"] = _next_seq_no()
    return encode_conn_msg(ack_head, None)


def build_business_conn_msg(
    cmd: str,
    module: str,
    biz_data: bytes,
    msg_id: str,
) -> bytes | None:
    """Build a generic business request wrapped in ConnMsg."""
    head = create_head(cmd, module, msg_id)
    return encode_conn_msg(head, biz_data)


# ---------------------------------------------------------------------------
# Business-layer codec
# ---------------------------------------------------------------------------


def _to_proto_msg_body(elements: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Convert wire-format msg_body elements to protobuf-compatible dicts."""
    result = []
    for el in elements:
        c = el.get("msg_content", {})
        proto_content: dict[str, Any] = {}
        for src_key, dst_key in [
            ("text", "text"),
            ("uuid", "uuid"),
            ("image_format", "imageFormat"),
            ("data", "data"),
            ("desc", "desc"),
            ("ext", "ext"),
            ("sound", "sound"),
            ("image_info_array", "imageInfoArray"),
            ("index", "index"),
            ("url", "url"),
            ("file_size", "fileSize"),
            ("file_name", "fileName"),
        ]:
            if src_key in c and c[src_key] is not None:
                proto_content[dst_key] = c[src_key]
        result.append(
            {
                "msgType": el.get("msg_type", ""),
                "msgContent": proto_content,
            }
        )
    return result


def _from_proto_msg_body(elements: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Convert protobuf-decoded msg_body elements to wire-format dicts."""
    result = []
    for el in elements:
        mc = el.get("msgContent", {})
        content: dict[str, Any] = {}
        for src_key, dst_key in [
            ("text", "text"),
            ("uuid", "uuid"),
            ("imageFormat", "image_format"),
            ("data", "data"),
            ("desc", "desc"),
            ("ext", "ext"),
            ("sound", "sound"),
            ("imageInfoArray", "image_info_array"),
            ("index", "index"),
            ("url", "url"),
            ("fileSize", "file_size"),
            ("fileName", "file_name"),
        ]:
            if mc.get(src_key):
                content[dst_key] = mc[src_key]
        result.append(
            {
                "msg_type": el.get("msgType", ""),
                "msg_content": content,
            }
        )
    return result


def encode_send_c2c_msg_req(data: dict[str, Any]) -> bytes | None:
    """Encode a SendC2CMessageReq for sending a private message."""
    return encode_biz_pb(
        BIZ_MSG_TYPES["SendC2CMessageReq"],
        {
            "msgId": data.get("msg_id", ""),
            "toAccount": data["to_account"],
            "fromAccount": data.get("from_account", ""),
            "msgRandom": data.get("msg_random", 0),
            "msgBody": _to_proto_msg_body(data.get("msg_body", [])),
        },
    )


def encode_send_group_msg_req(data: dict[str, Any]) -> bytes | None:
    """Encode a SendGroupMessageReq for sending a group message."""
    return encode_biz_pb(
        BIZ_MSG_TYPES["SendGroupMessageReq"],
        {
            "msgId": data.get("msg_id", ""),
            "groupId": data["group_id"],
            "fromAccount": data.get("from_account", ""),
            "toAccount": data.get("to_account", ""),
            "random": data.get("random", ""),
            "msgBody": _to_proto_msg_body(data.get("msg_body", [])),
            "refMsgId": data.get("ref_msg_id", ""),
        },
    )


def decode_inbound_message(data: bytes) -> dict[str, Any] | None:
    """Decode an InboundMessagePush from raw bytes."""
    decoded = decode_biz_pb(BIZ_MSG_TYPES["InboundMessagePush"], data)
    if not decoded:
        return None
    return {
        "callback_command": decoded.get("callbackCommand"),
        "from_account": decoded.get("fromAccount"),
        "to_account": decoded.get("toAccount"),
        "sender_nickname": decoded.get("senderNickname"),
        "group_id": decoded.get("groupId"),
        "group_code": decoded.get("groupCode"),
        "group_name": decoded.get("groupName"),
        "msg_seq": decoded.get("msgSeq"),
        "msg_random": decoded.get("msgRandom"),
        "msg_time": decoded.get("msgTime"),
        "msg_key": decoded.get("msgKey"),
        "msg_id": decoded.get("msgId"),
        "msg_body": _from_proto_msg_body(decoded.get("msgBody", [])),
        "cloud_custom_data": decoded.get("cloudCustomData"),
        "event_time": decoded.get("eventTime"),
        "bot_owner_id": decoded.get("botOwnerId"),
    }


def decode_send_msg_rsp(data: bytes, msg_id: str) -> dict[str, Any] | None:
    """Decode a send-message response (try C2C first, then Group)."""
    for type_key in ("SendC2CMessageRsp", "SendGroupMessageRsp"):
        decoded = decode_biz_pb(BIZ_MSG_TYPES[type_key], data)
        if decoded:
            return {
                "msg_id": msg_id,
                "code": decoded.get("code", 0),
                "message": decoded.get("message", ""),
            }
    return None
