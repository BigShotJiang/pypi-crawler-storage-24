# pylint: disable=too-many-branches,too-many-statements
"""QQ Channel.

QQ uses WebSocket for incoming events and HTTP API for replies.
No request-reply coupling: handler enqueues Incoming, consumer processes
and sends reply via send_c2c_message / send_channel_message /
send_group_message.
"""

from __future__ import annotations

import asyncio
import base64
import contextlib
import json
import logging
import mimetypes
import os
import threading
import time
import urllib.parse
from email.message import Message as EmailMessage
from email.utils import collapse_rfc2231_value
from pathlib import Path
from typing import Any

import aiohttp

from ....config.config import QQConfig as QQChannelConfig
from ...channels.core.base import _INTERNAL_MESSAGE_TYPES
from ...file_store import (
    file_payload,
    resolve_file_id_from_url,
    resolve_upload_path,
    store_local_file,
    store_uploaded_bytes,
)
from ...schemas import (
    ContentType,
    FileContent,
    ImageContent,
    MessageType,
    TextContent,
)
from ...turn_protocol import TurnEvent, TurnEventType
from ..base import (
    BaseChannel,
    OnReplySent,
    OutgoingContentPart,
    ProcessHandler,
)
from ..utils import file_url_to_local_path, to_public_access_url

logger = logging.getLogger(__name__)

# QQ Bot WebSocket op codes
OP_DISPATCH = 0
OP_HEARTBEAT = 1
OP_IDENTIFY = 2
OP_RESUME = 6
OP_RECONNECT = 7
OP_INVALID_SESSION = 9
OP_HELLO = 10
OP_HEARTBEAT_ACK = 11

# Intents
INTENT_PUBLIC_GUILD_MESSAGES = 1 << 30
INTENT_DIRECT_MESSAGE = 1 << 12
INTENT_GROUP_AND_C2C = 1 << 25
INTENT_GUILD_MEMBERS = 1 << 1

RECONNECT_DELAYS = [1, 2, 5, 10, 30, 60]
RATE_LIMIT_DELAY = 60

# Short suffix length for session_id (from user_openid / member_openid / author.id)
QQ_SESSION_ID_SUFFIX_LEN = 8
MAX_RECONNECT_ATTEMPTS = 100
QUICK_DISCONNECT_THRESHOLD = 5
MAX_QUICK_DISCONNECT_COUNT = 3

# 长任务进度提示相关常量
PROGRESS_INTERVAL_SECONDS = 30  # 每隔 N 秒发送一次进度提示（降低频率避免消耗被动回复额度）
MSG_ID_TIMEOUT_SECONDS = 240  # 被动回复 msg_id 超时阈值（QQ 限制 5 分钟，预留 1 分钟 buffer）
MAX_PROGRESS_COUNT = 3  # 最多发送 N 条进度提示，避免消耗过多被动回复额度

DEFAULT_API_BASE = "https://api.sgroup.qq.com"
TOKEN_URL = "https://bots.qq.com/app/getAppAccessToken"


def _get_api_base() -> str:
    """API root address (e.g. sandbox: https://sandbox.api.sgroup.qq.com)"""
    return os.getenv("QQ_API_BASE", DEFAULT_API_BASE).rstrip("/")


def _get_channel_url_sync(access_token: str) -> str:
    import urllib.error
    import urllib.request

    url = f"{_get_api_base()}/gateway"
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"QQBot {access_token}",
            "Content-Type": "application/json",
        },
        method="GET",
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        body = ""
        with contextlib.suppress(Exception):
            body = e.read().decode() if e.fp else ""
        msg = f"HTTP {e.code}: {e.reason}"
        if body:
            msg += f" | body: {body[:500]}"
        raise RuntimeError(f"Failed to get channel url: {msg}") from e
    except Exception as e:
        raise RuntimeError(f"Failed to get channel url: {e}") from e
    channel_url = data.get("url")
    if not channel_url:
        raise RuntimeError(f"No url in channel response: {data}")
    return channel_url


def _api_request_sync(
    access_token: str,
    method: str,
    path: str,
    body: dict[str, Any] | None = None,
) -> dict[str, Any]:
    import urllib.request

    url = f"{_get_api_base()}{path}"
    data = None
    if body is not None:
        data = json.dumps(body).encode()
    req = urllib.request.Request(
        url,
        data=data,
        headers={
            "Authorization": f"QQBot {access_token}",
            "Content-Type": "application/json",
        },
        method=method,
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read().decode())


_msg_seq: dict[str, int] = {}
_msg_seq_lock = threading.Lock()


def _get_next_msg_seq(msg_id: str) -> int:
    with _msg_seq_lock:
        if msg_id not in _msg_seq:
            # Use a value within int32 range to avoid potential overflow
            # on QQ server side.  time_s % 1_000_000 gives a unique-ish
            # starting point that stays well under 2^31.
            _msg_seq[msg_id] = int(time.time()) % 1_000_000

        n = _msg_seq[msg_id] + 1
        _msg_seq[msg_id] = n
        if len(_msg_seq) > 1000:
            for k in list(_msg_seq.keys())[:500]:
                if k in ("c2c", "group", "c2c-rich", "group-rich"):
                    continue
                del _msg_seq[k]
        return n


async def _api_request_async(
    session: Any,
    access_token: str,
    method: str,
    path: str,
    body: dict[str, Any] | None = None,
) -> dict[str, Any]:
    url = f"{_get_api_base()}{path}"
    kwargs = {
        "headers": {
            "Authorization": f"QQBot {access_token}",
            "Content-Type": "application/json",
        },
    }
    if body is not None:
        kwargs["json"] = body
    logger.info("QQ API request: %s %s body=%s", method, path, body)
    async with session.request(method, url, **kwargs) as resp:
        data = await resp.json()
        logger.info("QQ API response: %s %s status=%s resp=%s", method, path, resp.status, data)
        if resp.status >= 400:
            logger.warning(
                "QQ API error: %s %s status=%s body=%s resp=%s",
                method,
                path,
                resp.status,
                body,
                data,
            )
            raise RuntimeError(f"API {path} {resp.status}: {data}")
        return data


async def _send_c2c_message_async(
    session: Any,
    access_token: str,
    openid: str,
    content: str,
    msg_id: str | None = None,
) -> None:
    if not msg_id:
        # 主动消息（如 cron 定时推送）：根据 QQ 官方文档，不传 msg_id / msg_seq，
        # 直接用 msg_type=0 纯文本发送，避免触发 40011000。
        body: dict[str, Any] = {
            "content": content,
            "msg_type": 0,
        }
        await _api_request_async(
            session,
            access_token,
            "POST",
            f"/v2/users/{openid}/messages",
            body,
        )
        return

    # 被动回复：先尝试 markdown，失败回退纯文本
    msg_seq = _get_next_msg_seq(msg_id)
    body = {
        "content": "",
        "msg_type": 2,
        "msg_seq": msg_seq,
        "msg_id": msg_id,
        "markdown": {"content": content},
    }

    try:
        await _api_request_async(
            session,
            access_token,
            "POST",
            f"/v2/users/{openid}/messages",
            body,
        )
    except RuntimeError as e:
        # 40011000: 请求数据异常 (通常是 Markdown 格式问题或不支持 Markdown)
        if "400" in str(e):
            logger.warning("QQ send markdown failed, retrying with text. error=%s", e)
            msg_seq = _get_next_msg_seq(msg_id)
            body = {
                "content": content,
                "msg_type": 0,
                "msg_seq": msg_seq,
                "msg_id": msg_id,
            }
            await _api_request_async(
                session,
                access_token,
                "POST",
                f"/v2/users/{openid}/messages",
                body,
            )
        else:
            raise e


async def _send_channel_message_async(
    session: Any,
    access_token: str,
    channel_id: str,
    content: str,
    msg_id: str | None = None,
) -> None:
    body = {"content": content}
    if msg_id:
        body["msg_id"] = msg_id
    await _api_request_async(
        session,
        access_token,
        "POST",
        f"/channels/{channel_id}/messages",
        body,
    )


async def _send_group_message_async(
    session: Any,
    access_token: str,
    group_openid: str,
    content: str,
    msg_id: str | None = None,
) -> None:
    if not msg_id:
        # 主动消息：不传 msg_id / msg_seq，用纯文本
        body: dict[str, Any] = {
            "content": content,
            "msg_type": 0,
        }
        await _api_request_async(
            session,
            access_token,
            "POST",
            f"/v2/groups/{group_openid}/messages",
            body,
        )
        return

    # 被动回复：先尝试 markdown，失败回退纯文本
    msg_seq = _get_next_msg_seq(msg_id)
    body = {
        "content": "",
        "msg_type": 2,
        "msg_seq": msg_seq,
        "msg_id": msg_id,
        "markdown": {"content": content},
    }

    try:
        await _api_request_async(
            session,
            access_token,
            "POST",
            f"/v2/groups/{group_openid}/messages",
            body,
        )
    except RuntimeError as e:
        # 40011000: 请求数据异常 (通常是 Markdown 格式问题或不支持 Markdown)
        if "400" in str(e):
            logger.warning("QQ send markdown failed, retrying with text. error=%s", e)
            msg_seq = _get_next_msg_seq(msg_id)
            body = {
                "content": content,
                "msg_type": 0,
                "msg_seq": msg_seq,
                "msg_id": msg_id,
            }
            await _api_request_async(
                session,
                access_token,
                "POST",
                f"/v2/groups/{group_openid}/messages",
                body,
            )
        else:
            raise e


async def _upload_c2c_media_async(
    session: Any,
    access_token: str,
    openid: str,
    file_type: int,
    url: str,
) -> dict[str, Any]:
    return await _api_request_async(
        session,
        access_token,
        "POST",
        f"/v2/users/{openid}/files",
        {
            "file_type": file_type,
            "url": url,
            "srv_send_msg": False,
        },
    )


async def _upload_group_media_async(
    session: Any,
    access_token: str,
    group_openid: str,
    file_type: int,
    url: str,
) -> dict[str, Any]:
    return await _api_request_async(
        session,
        access_token,
        "POST",
        f"/v2/groups/{group_openid}/files",
        {
            "file_type": file_type,
            "url": url,
            "srv_send_msg": False,
        },
    )


async def _send_c2c_rich_media_async(
    session: Any,
    access_token: str,
    openid: str,
    media: dict[str, Any],
    msg_id: str | None = None,
    content: str = "",
) -> None:
    msg_seq = _get_next_msg_seq(msg_id or "c2c-rich")
    body: dict[str, Any] = {
        "msg_type": 7,
        "msg_seq": msg_seq,
        "media": media,
        "content": content,
    }
    if msg_id:
        body["msg_id"] = msg_id
    await _api_request_async(
        session,
        access_token,
        "POST",
        f"/v2/users/{openid}/messages",
        body,
    )


async def _send_group_rich_media_async(
    session: Any,
    access_token: str,
    group_openid: str,
    media: dict[str, Any],
    msg_id: str | None = None,
    content: str = "",
) -> None:
    msg_seq = _get_next_msg_seq(msg_id or "group-rich")
    body: dict[str, Any] = {
        "msg_type": 7,
        "msg_seq": msg_seq,
        "media": media,
        "content": content,
    }
    if msg_id:
        body["msg_id"] = msg_id
    await _api_request_async(
        session,
        access_token,
        "POST",
        f"/v2/groups/{group_openid}/messages",
        body,
    )


# QQ attachment 中的图片 content_type 前缀
_IMAGE_CONTENT_TYPE_PREFIXES = ("image/",)
_IMAGE_FILE_SUFFIXES = (
    ".png",
    ".jpg",
    ".jpeg",
    ".gif",
    ".webp",
    ".bmp",
    ".tiff",
)


def _is_image_attachment(
    content_type: str,
    url: str,
    attachment: dict[str, Any],
) -> bool:
    if any(content_type.startswith(prefix) for prefix in _IMAGE_CONTENT_TYPE_PREFIXES):
        return True

    filename = attachment.get("filename") or attachment.get("file_name") or attachment.get("name") or ""
    filename = str(filename).lower()
    if filename.endswith(_IMAGE_FILE_SUFFIXES):
        return True

    path = urllib.parse.urlparse(url).path.lower()
    return bool(path.endswith(_IMAGE_FILE_SUFFIXES))


def _build_content_parts_from_qq(
    text: str,
    attachments: list[dict[str, Any]],
) -> list[Any]:
    """从 QQ 消息的 text 和 attachments 构建 content_parts 列表。

    将 attachments 中的图片类型附件转化为 ImageContent，其他文件附件
    转化为 FileContent。文本部分（即使为空）始终作为 TextContent 保留。
    """
    parts: list[Any] = []
    # 文本部分：即使为空也保留，方便后续合并
    if text:
        parts.append(TextContent(type=ContentType.TEXT, text=text))
    # 解析 attachments 中的图片
    for att in attachments:
        ct = (att.get("content_type") or "").lower()
        url = (att.get("url") or "").strip()
        if not url:
            continue
        # 确保 URL 有协议头
        if url.startswith("//"):
            url = "https:" + url
        elif not url.startswith("http"):
            url = "https://" + url
        if _is_image_attachment(ct, url, att):
            parts.append(ImageContent(type=ContentType.IMAGE, image_url=url))
        else:
            parts.append(
                FileContent(
                    type=ContentType.FILE,
                    file_url=url,
                    source={
                        "type": "url",
                        "url": url,
                        "media_type": ct or "application/octet-stream",
                    },
                    filename=att.get("filename") or att.get("file_name") or att.get("name"),
                    media_type=ct or "application/octet-stream",
                    qq_attachment=dict(att),
                )
            )
    # 如果既没有文本也没有识别出的附件，保留一个空文本防止 content_parts 为空
    if not parts:
        parts.append(TextContent(type=ContentType.TEXT, text=""))
    return parts


class QQChannel(BaseChannel):
    """QQ Channel:
    WebSocket events -> Incoming -> process -> HTTP API reply.
    """

    channel = "qq"

    def __init__(
        self,
        process: ProcessHandler,
        enabled: bool,
        app_id: str,
        client_secret: str,
        bot_prefix: str = "",
        on_reply_sent: OnReplySent = None,
        show_tool_details: bool = True,
    ):
        super().__init__(
            process,
            on_reply_sent=on_reply_sent,
            show_tool_details=show_tool_details,
        )
        self.enabled = enabled
        self.app_id = app_id
        self.client_secret = client_secret
        self.bot_prefix = bot_prefix

        self._loop: asyncio.AbstractEventLoop | None = None
        self._ws_thread: threading.Thread | None = None
        self._stop_event = threading.Event()
        self._account_id = "default"
        self._token_cache: dict[str, Any] | None = None
        self._token_lock = threading.Lock()

        self._http: aiohttp.ClientSession | None = None

    def _get_access_token_sync(self) -> str:
        """Sync get access_token for WebSocket thread. Instance-level cache."""
        with self._token_lock:
            if self._token_cache and time.time() < self._token_cache["expires_at"] - 300:
                return self._token_cache["token"]
        try:
            import urllib.request

            req = urllib.request.Request(
                TOKEN_URL,
                data=json.dumps(
                    {"appId": self.app_id, "clientSecret": self.client_secret},
                ).encode(),
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=15) as resp:
                data = json.loads(resp.read().decode())
        except Exception as e:
            raise RuntimeError(f"Failed to get access_token: {e}") from e
        token = data.get("access_token")
        if not token:
            raise RuntimeError(f"No access_token in response: {data}")
        expires_in = data.get("expires_in", 7200)
        if isinstance(expires_in, str):
            expires_in = int(expires_in)
        with self._token_lock:
            self._token_cache = {
                "token": token,
                "expires_at": time.time() + expires_in,
            }
        return token

    async def _get_access_token_async(self) -> str:
        """Async get token for send. Instance-level cache."""
        with self._token_lock:
            if self._token_cache and time.time() < self._token_cache["expires_at"] - 300:
                return self._token_cache["token"]
        async with self._http.post(
            TOKEN_URL,
            json={"appId": self.app_id, "clientSecret": self.client_secret},
            headers={"Content-Type": "application/json"},
        ) as resp:
            if resp.status >= 400:
                text = await resp.text()
                raise RuntimeError(
                    f"Token request failed {resp.status}: {text}",
                )
            data = await resp.json()
        token = data.get("access_token")
        if not token:
            raise RuntimeError(f"No access_token: {data}")
        expires_in = data.get("expires_in", 7200)
        if isinstance(expires_in, str):
            expires_in = int(expires_in)
        with self._token_lock:
            self._token_cache = {
                "token": token,
                "expires_at": time.time() + expires_in,
            }
        return token

    def _clear_token_cache(self) -> None:
        with self._token_lock:
            self._token_cache = None

    @classmethod
    def from_env(
        cls,
        process: ProcessHandler,
        on_reply_sent: OnReplySent = None,
    ) -> QQChannel:
        return cls(
            process=process,
            enabled=os.getenv("QQ_CHANNEL_ENABLED", "1") == "1",
            app_id=os.getenv("QQ_APP_ID", ""),
            client_secret=os.getenv("QQ_CLIENT_SECRET", ""),
            bot_prefix=os.getenv("QQ_BOT_PREFIX", ""),
            on_reply_sent=on_reply_sent,
        )

    @classmethod
    def from_config(
        cls,
        process: ProcessHandler,
        config: QQChannelConfig,
        on_reply_sent: OnReplySent = None,
        show_tool_details: bool = True,
    ) -> QQChannel:
        return cls(
            process=process,
            enabled=config.enabled,
            app_id=config.app_id or "",
            client_secret=config.client_secret or "",
            bot_prefix=config.bot_prefix or "",
            on_reply_sent=on_reply_sent,
            show_tool_details=show_tool_details,
        )

    async def _on_tool_approval_required(
        self,
        request: Any,
        to_handle: str,
        event: Any,
        send_meta: dict[str, Any],
    ) -> None:
        """QQ：发送格式化文本风险提示。

        QQ 官方 API 不支持按钮回调，用户需直接回复 /approve 批准执行。
        审批消息不携带 msg_id（主动消息），使用纯文本格式发送。
        """
        if not self.enabled:
            return
        data = event.data or {}
        tool_name = data.get("tool_name", "unknown")
        severity = data.get("severity", "UNKNOWN")
        findings_count = data.get("findings_count", 0)
        findings_text = data.get("findings_text", "")
        auto_denied = data.get("auto_denied", False)

        if auto_denied:
            msg_text = (
                f"⛔ 工具已被系统拦截\n\n"
                f"工具：{tool_name}\n"
                f"严重性：{severity}\n"
                f"发现数：{findings_count}\n\n"
                f"{findings_text}\n\n"
                f"该工具已被禁止，无法批准执行。"
            )
        else:
            msg_text = (
                f"⚠️ 检测到风险操作\n\n"
                f"工具：{tool_name}\n"
                f"严重性：{severity}\n"
                f"发现数：{findings_count}\n\n"
                f"{findings_text}\n\n"
                f"回复 /approve 批准执行，或回复任意内容拒绝。"
            )

        bot_prefix = send_meta.get("bot_prefix", "") or getattr(self, "bot_prefix", "")
        if bot_prefix:
            msg_text = bot_prefix + msg_text

        # 审批通知作为主动消息发送（不携带 msg_id，避免被动消息限制）
        approval_meta = dict(send_meta)
        approval_meta.pop("message_id", None)

        logger.info(
            "qq _on_tool_approval_required: tool=%s severity=%s auto_denied=%s",
            tool_name,
            severity,
            auto_denied,
        )
        await self.send(to_handle, msg_text, approval_meta)

    async def send(
        self,
        to_handle: str,
        text: str,
        meta: dict[str, Any] | None = None,
    ) -> None:
        """Send one text via QQ HTTP API.
        Routes by meta or to_handle (group:/channel:/openid).
        """
        if not self.enabled or not text.strip():
            return
        meta = meta or {}
        message_type = meta.get("message_type")
        msg_id = meta.get("message_id")
        sender_id = meta.get("sender_id") or to_handle
        channel_id = meta.get("channel_id")
        group_openid = meta.get("group_openid")
        if message_type is None:
            if to_handle.startswith("group:"):
                message_type = "group"
                group_openid = to_handle[6:]
            elif to_handle.startswith("channel:"):
                message_type = "guild"
                channel_id = to_handle[8:]
            else:
                message_type = "c2c"
        try:
            token = await self._get_access_token_async()
        except Exception:
            logger.exception("get access_token failed")
            raise
        try:
            if message_type == "c2c":
                await _send_c2c_message_async(
                    self._http,
                    token,
                    sender_id,
                    text.strip(),
                    msg_id,
                )
            elif message_type == "group" and group_openid:
                await _send_group_message_async(
                    self._http,
                    token,
                    group_openid,
                    text.strip(),
                    msg_id,
                )
            elif channel_id:
                await _send_channel_message_async(
                    self._http,
                    token,
                    channel_id,
                    text.strip(),
                    msg_id,
                )
            else:
                await _send_c2c_message_async(
                    self._http,
                    token,
                    sender_id,
                    text.strip(),
                    msg_id,
                )
        except Exception:
            logger.exception("send failed")
            raise

    @staticmethod
    def _media_fallback_text(part: OutgoingContentPart) -> str:
        ptype = getattr(part, "type", None)
        if ptype == ContentType.IMAGE:
            return f"[Image: {getattr(part, 'image_url', '')}]"
        if ptype == ContentType.VIDEO:
            return f"[Video: {getattr(part, 'video_url', '')}]"
        if ptype == ContentType.AUDIO:
            data = getattr(part, "data", None) or ""
            return f"[Audio: {data}]" if data else "[Audio]"
        if ptype == ContentType.FILE:
            file_url = getattr(part, "file_url", None) or ""
            filename = getattr(part, "filename", None) or getattr(part, "file_id", None) or "attachment"
            if file_url:
                return f"[File: {filename}] {file_url}"
            return f"[File: {filename}]"
        return ""

    @staticmethod
    def _guess_media_filename(
        url: str,
        *,
        fallback_name: str,
        media_type: str | None = None,
    ) -> str:
        candidate = Path(urllib.parse.urlparse(url).path).name or fallback_name
        ext = Path(candidate).suffix
        if ext:
            return candidate
        guessed_ext = mimetypes.guess_extension(media_type or "") or ""
        return candidate + guessed_ext

    def _candidate_media_url(self, part: OutgoingContentPart) -> str:
        ptype = getattr(part, "type", None)
        if ptype == ContentType.IMAGE:
            return getattr(part, "image_url", None) or ""
        if ptype == ContentType.VIDEO:
            return getattr(part, "video_url", None) or ""
        if ptype == ContentType.AUDIO:
            return getattr(part, "data", None) or ""
        if ptype == ContentType.FILE:
            return getattr(part, "file_url", None) or ""
        return ""

    def _part_to_public_media_url(
        self,
        part: OutgoingContentPart,
    ) -> str | None:
        raw = self._candidate_media_url(part)
        if not isinstance(raw, str) or not raw.strip():
            return None
        raw = raw.strip()

        if raw.startswith("data:") and "base64," in raw:
            header, payload = raw.split("base64,", 1)
            media_type = (
                header.split(":", 1)[1].split(";", 1)[0].strip() if ":" in header else "application/octet-stream"
            )
            try:
                data = base64.b64decode(payload)
            except Exception:
                logger.warning("qq media upload: failed to decode data URL")
                return None
            filename = self._guess_media_filename(
                "",
                fallback_name=getattr(part, "filename", None) or "upload",
                media_type=media_type,
            )
            metadata = store_uploaded_bytes(
                data,
                filename=filename,
                media_type=media_type,
            )
            return to_public_access_url(str(file_payload(metadata)["access_url"]))

        if raw.startswith("/api/files/"):
            return to_public_access_url(raw)

        local_path = file_url_to_local_path(raw)
        if not local_path and Path(raw).expanduser().exists():
            local_path = str(Path(raw).expanduser().resolve())
        if local_path:
            if not Path(local_path).is_file():
                return None
            metadata = store_local_file(
                local_path,
                filename=getattr(part, "filename", None) or Path(local_path).name,
            )
            return to_public_access_url(str(file_payload(metadata)["access_url"]))

        return to_public_access_url(raw)

    async def send_content_parts(
        self,
        to_handle: str,
        parts: list[OutgoingContentPart],
        meta: dict[str, Any] | None = None,
    ) -> None:
        text_parts: list[str] = []
        media_parts: list[OutgoingContentPart] = []
        for part in parts:
            ptype = getattr(part, "type", None)
            if ptype == ContentType.TEXT and getattr(part, "text", None):
                text_parts.append(part.text or "")
            elif ptype == ContentType.REFUSAL and getattr(part, "refusal", None):
                text_parts.append(part.refusal or "")
            elif ptype in (
                ContentType.IMAGE,
                ContentType.VIDEO,
                ContentType.AUDIO,
                ContentType.FILE,
            ):
                media_parts.append(part)

        body = "\n".join(text_parts).strip()
        prefix = (meta or {}).get("bot_prefix", "") or ""
        if prefix and body:
            body = prefix + body
        if body:
            await self.send(to_handle, body, meta)

        fallback_lines: list[str] = []
        for media_part in media_parts:
            sent = await self.send_media(to_handle, media_part, meta)
            if not sent:
                fallback = self._media_fallback_text(media_part).strip()
                if fallback:
                    fallback_lines.append(fallback)

        if fallback_lines:
            fallback_body = "\n".join(fallback_lines).strip()
            if prefix and fallback_body:
                fallback_body = prefix + fallback_body
            if fallback_body:
                await self.send(to_handle, fallback_body, meta)

    async def send_media(
        self,
        to_handle: str,
        part: OutgoingContentPart,
        meta: dict[str, Any] | None = None,
    ) -> bool:
        meta = meta or {}
        message_type = meta.get("message_type")
        msg_id = meta.get("message_id")
        sender_id = meta.get("sender_id") or to_handle
        group_openid = meta.get("group_openid")
        if message_type not in {"c2c", "group"}:
            return False

        ptype = getattr(part, "type", None)
        file_type = {
            ContentType.IMAGE: 1,
            ContentType.VIDEO: 2,
            ContentType.AUDIO: 3,
            ContentType.FILE: 4,
        }.get(ptype)
        if file_type is None:
            return False

        # QQ 官方限制：群场景下 file_type=4（文件）暂不开放，仅私聊支持
        if file_type == 4 and message_type != "c2c":
            logger.info(
                "qq file_type=4 (file) not supported in %s scene, fallback to text",
                message_type,
            )
            return False

        media_url = self._part_to_public_media_url(part)
        if not media_url or not media_url.startswith(("http://", "https://")):
            logger.info(
                "qq media upload skipped: no public URL for part type=%s",
                ptype,
            )
            return False

        try:
            token = await self._get_access_token_async()
            if message_type == "c2c":
                uploaded = await _upload_c2c_media_async(
                    self._http,
                    token,
                    sender_id,
                    file_type,
                    media_url,
                )
                media = (
                    {"file_info": uploaded["file_info"]}
                    if isinstance(uploaded, dict) and uploaded.get("file_info")
                    else uploaded
                )
                await _send_c2c_rich_media_async(
                    self._http,
                    token,
                    sender_id,
                    media,
                    msg_id=msg_id,
                )
                return True

            if not group_openid:
                return False
            uploaded = await _upload_group_media_async(
                self._http,
                token,
                group_openid,
                file_type,
                media_url,
            )
            media = (
                {"file_info": uploaded["file_info"]}
                if isinstance(uploaded, dict) and uploaded.get("file_info")
                else uploaded
            )
            await _send_group_rich_media_async(
                self._http,
                token,
                group_openid,
                media,
                msg_id=msg_id,
            )
            return True
        except Exception:
            logger.exception("qq native media send failed type=%s", ptype)
            return False

    def resolve_session_id(
        self,
        sender_id: str,
        channel_meta: dict[str, Any] | None = None,
    ) -> str:
        """Use last N chars of sender_id as session_id to keep it short.

        QQ openids (user_openid / member_openid) are long opaque strings;
        taking the last QQ_SESSION_ID_SUFFIX_LEN chars gives a compact,
        unique-enough key that matches the convention used by Feishu and
        DingTalk channels.
        """
        meta = channel_meta or {}
        message_type = meta.get("message_type", "")
        n = QQ_SESSION_ID_SUFFIX_LEN

        if message_type == "group":
            # Group chat: key by group, not by individual sender
            group_openid = meta.get("group_openid") or sender_id
            short = (group_openid[-n:] if len(group_openid) >= n else group_openid).lower()
            return f"qq-group-{short}"

        # c2c / dm / guild: key by sender
        short = (sender_id[-n:] if len(sender_id) >= n else sender_id).lower()
        return f"qq-{short}"

    def build_turn_request_from_native(self, native_payload: Any) -> Any:
        """Build TurnRequest from QQ native dict (runtime content_parts)."""
        payload = native_payload if isinstance(native_payload, dict) else {}
        channel_id = payload.get("channel_id") or self.channel
        sender_id = payload.get("sender_id") or ""
        content_parts = payload.get("content_parts") or []
        meta = payload.get("meta") or {}
        session_id = self.resolve_session_id(sender_id, meta)
        return self.build_turn_request_from_user_content(
            channel_id=channel_id,
            sender_id=sender_id,
            session_id=session_id,
            content_parts=content_parts,
            channel_meta=meta,
        )

    @staticmethod
    def _filename_from_disposition(value: str | None) -> str | None:
        if not value:
            return None
        try:
            header = EmailMessage()
            header["content-disposition"] = value
            candidate = header.get_param(
                "filename*",
                header="content-disposition",
            ) or header.get_param("filename", header="content-disposition")
        except Exception:
            candidate = None
        if not candidate:
            return None
        if isinstance(candidate, tuple):
            candidate = collapse_rfc2231_value(candidate)
        elif isinstance(candidate, bytes):
            candidate = candidate.decode("utf-8", errors="ignore")
        candidate = str(candidate).strip()
        if "''" in candidate:
            candidate = candidate.split("''", 1)[-1]
        candidate = urllib.parse.unquote(candidate).strip().strip("\"'")
        candidate = Path(candidate).name
        return candidate or None

    @staticmethod
    def _guess_download_filename(
        url: str,
        *,
        disposition: str | None = None,
        filename_hint: str | None = None,
    ) -> str:
        filename = QQChannel._filename_from_disposition(disposition)
        if not filename:
            candidate = Path(urllib.parse.urlparse(url).path).name
            filename = urllib.parse.unquote(candidate) if candidate else ""
        if not filename:
            filename = filename_hint or ""
        filename = Path(filename).name
        return filename or (filename_hint or "attachment")

    async def _download_incoming_attachment(
        self,
        url: str,
        *,
        filename_hint: str | None = None,
        media_type_hint: str | None = None,
    ) -> tuple[bytes, str, str]:
        if not self._http:
            raise RuntimeError("QQ HTTP session is not initialized")

        normalized_url = (url or "").strip()
        if normalized_url.startswith("//"):
            normalized_url = "https:" + normalized_url
        elif normalized_url and not normalized_url.startswith(("http://", "https://")):
            normalized_url = "https://" + normalized_url
        if not normalized_url:
            raise ValueError("QQ attachment URL is empty")

        token = await self._get_access_token_async()
        attempts = [
            {"Authorization": f"QQBot {token}"},
            {},
        ]
        last_error: Exception | None = None

        for headers in attempts:
            try:
                async with self._http.get(
                    normalized_url,
                    headers=headers,
                    allow_redirects=True,
                ) as resp:
                    if resp.status in (401, 403) and headers:
                        last_error = RuntimeError(f"QQ attachment download unauthorized: {resp.status}")
                        continue
                    if resp.status >= 400:
                        text = await resp.text()
                        raise RuntimeError(f"QQ attachment download failed {resp.status}: {text[:200]}")

                    data = await resp.read()
                    if not data:
                        raise RuntimeError("QQ attachment download returned empty body")

                    content_type = resp.headers.get("Content-Type", "").split(";", 1)[0].strip()
                    filename = self._guess_download_filename(
                        str(resp.url),
                        disposition=resp.headers.get("Content-Disposition"),
                        filename_hint=filename_hint,
                    )
                    media_type = (
                        content_type
                        or media_type_hint
                        or mimetypes.guess_type(filename)[0]
                        or "application/octet-stream"
                    )
                    return data, filename, media_type
            except Exception as exc:
                last_error = exc

        raise RuntimeError(f"Failed to download QQ attachment: {last_error}")

    @staticmethod
    def _update_content_part(part: Any, **updates: Any) -> Any:
        if hasattr(part, "model_copy"):
            return part.model_copy(update=updates)
        if isinstance(part, dict):
            updated = dict(part)
            updated.update(updates)
            return updated
        for key, value in updates.items():
            setattr(part, key, value)
        return part

    async def _materialize_incoming_file_parts(self, request: Any) -> None:
        if not getattr(request, "inputs", None):
            return

        content = list(getattr(request.inputs[0], "content", None) or [])
        if not content:
            return

        changed = False
        for index, part in enumerate(content):
            part_type = getattr(part, "type", None)
            if part_type != ContentType.FILE:
                continue

            file_id = getattr(part, "file_id", None)
            if isinstance(file_id, str) and file_id:
                continue

            source = getattr(part, "source", None)
            source_url = None
            source_media_type = None
            if isinstance(source, dict) and source.get("type") == "url":
                source_url = source.get("url")
                source_media_type = source.get("media_type")

            file_url = getattr(part, "file_url", None)
            candidate_url = source_url or file_url
            if not isinstance(candidate_url, str) or not candidate_url.strip():
                continue

            existing_file_id = resolve_file_id_from_url(candidate_url)
            if existing_file_id:
                continue

            filename_hint = getattr(part, "filename", None) or None
            media_type_hint = (
                getattr(part, "media_type", None)
                or source_media_type
                or mimetypes.guess_type(filename_hint or "")[0]
                or "application/octet-stream"
            )

            metadata: dict[str, Any] | None = None
            local_path = file_url_to_local_path(candidate_url)
            if local_path and Path(local_path).is_file():
                metadata = store_local_file(
                    local_path,
                    filename=filename_hint or Path(local_path).name,
                    media_type=media_type_hint,
                )
            else:
                try:
                    (
                        data,
                        resolved_name,
                        resolved_media_type,
                    ) = await self._download_incoming_attachment(
                        candidate_url,
                        filename_hint=filename_hint,
                        media_type_hint=media_type_hint,
                    )
                except Exception:
                    logger.exception(
                        "qq inbound attachment download failed url=%s",
                        candidate_url,
                    )
                    continue

                metadata = store_uploaded_bytes(
                    data,
                    filename=resolved_name,
                    media_type=resolved_media_type,
                )

            payload = file_payload(metadata)
            stored_file_id = payload["file_id"]
            stored_path = resolve_upload_path(stored_file_id)
            resolved_filename = str(metadata.get("filename") or filename_hint or stored_file_id)
            resolved_media_type = str(metadata.get("media_type") or media_type_hint or "application/octet-stream")
            access_url = str(payload["access_url"])
            content[index] = self._update_content_part(
                part,
                file_id=stored_file_id,
                file_url=access_url,
                preview_url=access_url,
                filename=resolved_filename,
                media_type=resolved_media_type,
                source={
                    "type": "url",
                    "url": stored_path.as_uri(),
                    "media_type": resolved_media_type,
                },
            )
            changed = True

        if not changed:
            return

        if hasattr(request.inputs[0], "model_copy"):
            new_input = request.inputs[0].model_copy(update={"content": content})
            if hasattr(request, "model_copy"):
                request = request.model_copy(update={"inputs": [new_input, *list(request.inputs[1:])]})
            else:
                request.inputs[0] = new_input
        else:
            request.inputs[0].content = content

    async def consume_one(self, payload: Any) -> None:
        """Process one TurnRequest from manager queue."""
        request = self._payload_to_request(payload)
        await self._materialize_incoming_file_parts(request)
        if getattr(request, "inputs", None):
            session_id = getattr(request, "session_id", "") or ""
            contents = list(
                getattr(request.inputs[0], "content", None) or [],
            )
            should_process, merged = self._apply_no_text_debounce(
                session_id,
                contents,
            )
            if not should_process:
                return
            if merged:
                if hasattr(request.inputs[0], "model_copy"):
                    new_input = request.inputs[0].model_copy(update={"content": merged})
                    request = request.model_copy(update={"inputs": [new_input, *list(request.inputs[1:])]})
                else:
                    request.inputs[0].content = merged
        try:
            ctx = request.context or {}
            send_meta = dict(ctx.get("channel_meta") or {})
            send_meta.setdefault("bot_prefix", self.bot_prefix)
            to_handle = request.user_id or ""
            turn_failed = False
            event_count = 0
            # 累积来自 ASSISTANT_DELTA 事件的流式文本（按 message_id 分组）
            _streamed_text: dict[str, str] = {}
            _streamed_media: dict[str, list[OutgoingContentPart]] = {}

            # ── 长任务体验优化：记录消息接收时间 ──
            _msg_received_at = time.time()

            # ── 启动周期性进度提示定时器 ──
            # 注意：所有消息优先使用被动回复（带 msg_id），
            # 仅在 msg_id 超时（4分钟）后才自动降级为主动消息。
            # 不再单独发送确认消息，避免消耗宝贵的被动回复额度。
            _progress_task = asyncio.create_task(
                self._send_periodic_progress(
                    to_handle,
                    send_meta,
                    _msg_received_at,
                )
            )

            async for event in self._process(request):
                if not isinstance(event, TurnEvent):
                    continue
                event_count += 1
                ev_type = event.type
                logger.debug(
                    "qq TurnEvent #%s: type=%s",
                    event_count,
                    ev_type,
                )
                if ev_type == TurnEventType.ASSISTANT_DELTA:
                    # 从流式 ASSISTANT_DELTA 中累积文本和媒体内容
                    msg_id = event.message_id or ""
                    # 收到内容事件时重置进度提示计时器
                    _progress_task.cancel()
                    _progress_task = asyncio.create_task(
                        self._send_periodic_progress(
                            to_handle,
                            send_meta,
                            _msg_received_at,
                        )
                    )
                    delta = event.delta or {}
                    if isinstance(delta, dict):
                        d_type = delta.get("type", "")
                        if d_type == "text":
                            delta_text = delta.get("text", "") or ""
                            if delta_text:
                                _streamed_text[msg_id] = _streamed_text.get(msg_id, "") + delta_text
                        elif d_type == "image":
                            url = delta.get("image_url", "") or ""
                            if url:
                                from ...schemas import ImageContent as _IC

                                _streamed_media.setdefault(msg_id, []).append(_IC(image_url=url))
                        elif d_type == "file":
                            url = delta.get("file_url", "") or ""
                            fname = delta.get("filename", "") or ""
                            if url:
                                from ...schemas import FileContent as _FC

                                _streamed_media.setdefault(msg_id, []).append(_FC(file_url=url, filename=fname))
                        elif d_type == "video":
                            url = delta.get("video_url", "") or ""
                            if url:
                                from ...schemas import VideoContent as _VC

                                _streamed_media.setdefault(msg_id, []).append(_VC(video_url=url))

                elif ev_type == TurnEventType.ASSISTANT_COMPLETED:
                    msg_id = event.message_id or ""
                    metadata = event.metadata or {}
                    message_type = metadata.get("message_type", MessageType.MESSAGE)

                    # ── 工具调用开始时发送提示（仅 PLUGIN_CALL，不含 OUTPUT）──
                    if message_type in (
                        MessageType.PLUGIN_CALL,
                        MessageType.MCP_TOOL_CALL,
                        MessageType.FUNCTION_CALL,
                    ):
                        tool_name = self._extract_tool_name_from_event(event)
                        if tool_name:
                            try:
                                tool_meta = self._make_active_meta(
                                    send_meta,
                                    _msg_received_at,
                                )
                                await self.send_content_parts(
                                    to_handle,
                                    [
                                        TextContent(
                                            type=ContentType.TEXT,
                                            text=f"🔧 正在调用工具: {tool_name}",
                                        )
                                    ],
                                    tool_meta,
                                )
                            except Exception:
                                logger.debug("qq send tool progress failed")
                            # 重置进度计时器
                            _progress_task.cancel()
                            _progress_task = asyncio.create_task(
                                self._send_periodic_progress(
                                    to_handle,
                                    send_meta,
                                    _msg_received_at,
                                )
                            )

                    # 跳过内部工具/插件消息
                    if message_type in _INTERNAL_MESSAGE_TYPES:
                        continue

                    # 使用 event.content 作为完整内容
                    from ...channels.core.base import _TurnMsg

                    msg = _TurnMsg(
                        message_type,
                        list(event.content or []),
                        event.role or "assistant",
                    )
                    parts = self._message_to_content_parts(msg)

                    # 如果 content 为空，使用从 ASSISTANT_DELTA 中累积的流式文本
                    if not parts:
                        text = _streamed_text.pop(msg_id, "")
                        media = _streamed_media.pop(msg_id, [])
                        if not text:
                            # msg_id 可能不匹配，尝试获取任何累积的文本
                            for k, v in list(_streamed_text.items()):
                                text = v
                                del _streamed_text[k]
                                break
                        if text:
                            parts.append(TextContent(type=ContentType.TEXT, text=text))
                        parts.extend(media)
                    else:
                        _streamed_text.pop(msg_id, None)
                        _streamed_media.pop(msg_id, None)

                    logger.info(
                        "qq completed message: type=%s parts_count=%s",
                        message_type,
                        len(parts),
                    )
                    if parts:
                        # 发送最终结果：优先被动回复，超时后降级为主动消息
                        final_meta = self._make_active_meta(
                            send_meta,
                            _msg_received_at,
                        )
                        await self.send_content_parts(
                            to_handle,
                            parts,
                            final_meta,
                        )

                elif ev_type == TurnEventType.TURN_FAILED:
                    turn_failed = True

            # ── 停止进度提示定时器 ──
            _progress_task.cancel()

            if turn_failed:
                err_text = "我的'灵魂'不在线，请检查你的主机服务部署环境。检查指引 👉 https://mc.tencent.com/2T358SA0"
                err_meta = self._make_active_meta(send_meta, _msg_received_at)
                await self.send_content_parts(
                    to_handle,
                    [TextContent(type=ContentType.TEXT, text=err_text)],
                    err_meta,
                )
            if self._on_reply_sent:
                self._on_reply_sent(
                    self.channel,
                    to_handle,
                    request.session_id or f"{self.channel}:{to_handle}",
                )
        except Exception:
            logger.exception("qq process/reply failed")
            # 确保异常时也停止进度提示定时器
            with contextlib.suppress(Exception):
                _progress_task.cancel()
            try:
                fallback_handle = getattr(request, "user_id", "")
                err_text = "我的'灵魂'不在线，请检查你的主机服务部署环境。检查指引 👉 https://mc.tencent.com/2T358SA0"
                await self.send_content_parts(
                    fallback_handle,
                    [TextContent(type=ContentType.TEXT, text=err_text)],
                    getattr(request, "channel_meta", None) or {},
                )
            except Exception:
                logger.exception("send error message failed")

    # ------------------------------------------------------------------
    # 长任务体验优化辅助方法
    # ------------------------------------------------------------------

    async def _send_periodic_progress(
        self,
        to_handle: str,
        send_meta: dict[str, Any],
        received_at: float,
        interval: float = PROGRESS_INTERVAL_SECONDS,
    ) -> None:
        """周期性发送进度提示，让用户知道 bot 仍在处理中。

        该协程作为 asyncio.Task 运行，通过 cancel() 停止。
        使用 _make_active_meta 智能判断：
        - msg_id 未过期 → 被动回复
        - msg_id 已过期 → 自动降级为主动消息
        限制最多发送 MAX_PROGRESS_COUNT 条进度提示，避免过度消耗被动回复额度。
        """
        progress_messages = [
            "仍在处理中，请耐心等待... ⏳",
            "任务比较复杂，还在努力处理中... 🔄",
            "还在工作中，复杂任务需要更多时间... 💪",
        ]
        idx = 0
        try:
            while idx < MAX_PROGRESS_COUNT:
                await asyncio.sleep(interval)
                meta = self._make_active_meta(send_meta, received_at)
                msg = progress_messages[min(idx, len(progress_messages) - 1)]
                try:
                    await self.send_content_parts(
                        to_handle,
                        [TextContent(type=ContentType.TEXT, text=msg)],
                        meta,
                    )
                except Exception:
                    logger.debug("qq send periodic progress failed")
                idx += 1
        except asyncio.CancelledError:
            pass

    @staticmethod
    def _make_active_meta(
        send_meta: dict[str, Any],
        received_at: float,
        timeout: float = MSG_ID_TIMEOUT_SECONDS,
    ) -> dict[str, Any]:
        """如果 msg_id 已接近超时（默认 4 分钟），移除 msg_id 改用主动消息。

        QQ 被动回复的 msg_id 有 5 分钟有效期，超过后 API 会报错。
        预留 1 分钟 buffer，在 4 分钟时切换为主动消息模式。
        """
        if time.time() - received_at > timeout:
            meta = dict(send_meta)
            meta.pop("message_id", None)
            return meta
        return send_meta

    @staticmethod
    def _extract_tool_name_from_event(event: Any) -> str | None:
        """从工具调用事件的 content 中提取工具名称。

        事件 content 结构为:
          [{"type": "data", "data": {"name": "tool_name", ...}}]
        或:
          [{"type": "tool_use", "name": "tool_name", ...}]
        """
        content = getattr(event, "content", None) or []
        for block in content:
            if isinstance(block, dict):
                # DataContent 格式
                if block.get("type") == "data" and isinstance(block.get("data"), dict):
                    name = block["data"].get("name")
                    if name:
                        return str(name)
                # tool_use 格式
                if block.get("type") == "tool_use":
                    name = block.get("name")
                    if name:
                        return str(name)
            # Pydantic model 格式
            elif hasattr(block, "type") and hasattr(block, "data"):
                data = getattr(block, "data", None)
                if isinstance(data, dict):
                    name = data.get("name")
                    if name:
                        return str(name)
        return None

    def _run_ws_forever(self) -> None:
        try:
            import websocket
        except ImportError:
            logger.error(
                "websocket-client not installed. pip install websocket-client",
            )
            return
        reconnect_attempts = 0
        last_connect_time = 0.0
        quick_disconnect_count = 0
        session_id: str | None = None
        last_seq: int | None = None
        identify_fail_count = 0
        should_refresh_token = False

        def connect() -> bool:
            nonlocal session_id, last_seq, reconnect_attempts, last_connect_time, quick_disconnect_count, should_refresh_token, identify_fail_count  # pylint: disable=line-too-long
            if self._stop_event.is_set():
                return False
            if should_refresh_token:
                self._clear_token_cache()
                should_refresh_token = False
            try:
                token = self._get_access_token_sync()
                url = _get_channel_url_sync(token)
            except Exception as e:
                logger.warning("qq get token/gateway failed: %s", e)
                return True
            logger.info("qq connecting to %s", url)
            try:
                ws = websocket.create_connection(url)
            except Exception as e:
                logger.warning("qq ws connect failed: %s", e)
                return True
            current_ws = ws
            heartbeat_interval: float | None = None
            heartbeat_timer: threading.Timer | None = None

            def stop_heartbeat() -> None:
                if heartbeat_timer:
                    heartbeat_timer.cancel()

            def schedule_heartbeat() -> None:
                nonlocal heartbeat_timer
                if heartbeat_interval is None or self._stop_event.is_set():
                    return

                def send_ping() -> None:
                    if self._stop_event.is_set():
                        return
                    try:
                        if current_ws.connected:
                            current_ws.send(
                                json.dumps(
                                    {"op": OP_HEARTBEAT, "d": last_seq},
                                ),
                            )
                            logger.debug("qq heartbeat sent")
                    except Exception:
                        pass
                    schedule_heartbeat()

                heartbeat_timer = threading.Timer(
                    heartbeat_interval / 1000.0,
                    send_ping,
                )
                heartbeat_timer.daemon = True
                heartbeat_timer.start()

            try:
                while not self._stop_event.is_set():
                    raw = current_ws.recv()
                    if not raw:
                        break
                    payload = json.loads(raw)
                    op = payload.get("op")
                    d = payload.get("d")
                    s = payload.get("s")
                    t = payload.get("t")
                    if s is not None:
                        last_seq = s

                    if op == OP_HELLO:
                        hi = d or {}
                        heartbeat_interval = hi.get(
                            "heartbeat_interval",
                            45000,
                        )
                        if session_id and last_seq is not None:
                            current_ws.send(
                                json.dumps(
                                    {
                                        "op": OP_RESUME,
                                        "d": {
                                            "token": f"QQBot {token}",
                                            "session_id": session_id,
                                            "seq": last_seq,
                                        },
                                    },
                                ),
                            )
                        else:
                            intents = INTENT_PUBLIC_GUILD_MESSAGES | INTENT_GUILD_MEMBERS
                            if identify_fail_count < 3:
                                intents |= INTENT_DIRECT_MESSAGE | INTENT_GROUP_AND_C2C
                            current_ws.send(
                                json.dumps(
                                    {
                                        "op": OP_IDENTIFY,
                                        "d": {
                                            "token": f"QQBot {token}",
                                            "intents": intents,
                                            "shard": [0, 1],
                                        },
                                    },
                                ),
                            )
                        schedule_heartbeat()
                    elif op == OP_DISPATCH:
                        if t == "READY":
                            session_id = (d or {}).get("session_id")
                            identify_fail_count = 0
                            reconnect_attempts = 0
                            last_connect_time = time.time()
                            logger.info("qq ready session_id=%s", session_id)
                        elif t == "RESUMED":
                            logger.info("qq session resumed")
                        elif t == "C2C_MESSAGE_CREATE":
                            logger.debug(
                                "qq c2c raw payload: %s",
                                d,
                            )
                            author = (d or {}).get("author") or {}
                            text = ((d or {}).get("content") or "").strip()
                            if not text and not (d or {}).get("attachments"):
                                continue
                            if self.bot_prefix and text.startswith(
                                self.bot_prefix,
                            ):
                                continue
                            sender = author.get("user_openid") or author.get("id") or ""
                            if not sender:
                                continue
                            msg_id = (d or {}).get("id", "")
                            # ts = (d or {}).get("timestamp", "")
                            att = (d or {}).get("attachments") or []
                            meta = {
                                "message_type": "c2c",
                                "message_id": msg_id,
                                "sender_id": sender,
                                "incoming_raw": d,
                                "attachments": att,
                            }
                            native = {
                                "channel_id": "qq",
                                "sender_id": sender,
                                "content_parts": _build_content_parts_from_qq(text, att),
                                "meta": meta,
                            }
                            request = self.build_agent_request_from_native(
                                native,
                            )
                            request.channel_meta = meta
                            if self._enqueue is not None:
                                self._enqueue(request)
                            logger.info(
                                "qq recv c2c from=%s text=%r",
                                sender,
                                text[:100],
                            )
                        elif t == "AT_MESSAGE_CREATE":
                            author = (d or {}).get("author") or {}
                            text = ((d or {}).get("content") or "").strip()
                            if not text and not (d or {}).get("attachments"):
                                continue
                            if self.bot_prefix and text.startswith(
                                self.bot_prefix,
                            ):
                                continue
                            sender = author.get("id") or author.get("username") or ""
                            if not sender:
                                continue
                            channel_id = (d or {}).get("channel_id", "")
                            guild_id = (d or {}).get("guild_id", "")
                            msg_id = (d or {}).get("id", "")
                            # ts = (d or {}).get("timestamp", "")
                            att = (d or {}).get("attachments") or []
                            meta = {
                                "message_type": "guild",
                                "message_id": msg_id,
                                "sender_id": sender,
                                "channel_id": channel_id,
                                "guild_id": guild_id,
                                "incoming_raw": d,
                                "attachments": att,
                            }
                            native = {
                                "channel_id": "qq",
                                "sender_id": sender,
                                "content_parts": _build_content_parts_from_qq(text, att),
                                "meta": meta,
                            }
                            request = self.build_agent_request_from_native(
                                native,
                            )
                            request.channel_meta = meta
                            if self._enqueue is not None:
                                self._enqueue(request)
                            logger.info(
                                "qq recv guild from=%s channel=%s text=%r",
                                sender,
                                channel_id,
                                text[:100],
                            )
                        elif t == "DIRECT_MESSAGE_CREATE":
                            author = (d or {}).get("author") or {}
                            text = ((d or {}).get("content") or "").strip()
                            if not text and not (d or {}).get("attachments"):
                                continue
                            if self.bot_prefix and text.startswith(
                                self.bot_prefix,
                            ):
                                continue
                            sender = author.get("id") or author.get("username") or ""
                            if not sender:
                                continue
                            channel_id = (d or {}).get("channel_id", "")
                            guild_id = (d or {}).get("guild_id", "")
                            msg_id = (d or {}).get("id", "")
                            att = (d or {}).get("attachments") or []
                            meta = {
                                "message_type": "dm",
                                "message_id": msg_id,
                                "sender_id": sender,
                                "channel_id": channel_id,
                                "guild_id": guild_id,
                                "incoming_raw": d,
                                "attachments": att,
                            }
                            native = {
                                "channel_id": "qq",
                                "sender_id": sender,
                                "content_parts": _build_content_parts_from_qq(text, att),
                                "meta": meta,
                            }
                            request = self.build_agent_request_from_native(
                                native,
                            )
                            request.channel_meta = meta
                            if self._enqueue is not None:
                                self._enqueue(request)
                            logger.info(
                                "qq recv dm from=%s text=%r",
                                sender,
                                text[:100],
                            )
                        elif t == "GROUP_AT_MESSAGE_CREATE":
                            author = (d or {}).get("author") or {}
                            text = ((d or {}).get("content") or "").strip()
                            if not text and not (d or {}).get("attachments"):
                                continue
                            if self.bot_prefix and text.startswith(
                                self.bot_prefix,
                            ):
                                continue
                            sender = author.get("member_openid") or author.get("id") or ""
                            if not sender:
                                continue
                            group_openid = (d or {}).get("group_openid", "")
                            msg_id = (d or {}).get("id", "")
                            att = (d or {}).get("attachments") or []
                            meta = {
                                "message_type": "group",
                                "message_id": msg_id,
                                "sender_id": sender,
                                "group_openid": group_openid,
                                "incoming_raw": d,
                                "attachments": att,
                            }
                            native = {
                                "channel_id": "qq",
                                "sender_id": sender,
                                "content_parts": _build_content_parts_from_qq(text, att),
                                "meta": meta,
                            }
                            request = self.build_agent_request_from_native(
                                native,
                            )
                            request.channel_meta = meta
                            if self._enqueue is not None:
                                self._enqueue(request)
                            logger.info(
                                "qq recv group from=%s group=%s text=%r",
                                sender,
                                group_openid,
                                text[:100],
                            )
                    elif op == OP_HEARTBEAT_ACK:
                        logger.debug("qq heartbeat ack")
                    elif op == OP_RECONNECT:
                        logger.info("qq server requested reconnect")
                        break
                    elif op == OP_INVALID_SESSION:
                        can_resume = d
                        logger.error(
                            "qq invalid session can_resume=%s",
                            can_resume,
                        )
                        if not can_resume:
                            session_id = None
                            last_seq = None
                            identify_fail_count += 1
                            should_refresh_token = True
                        break
            except websocket.WebSocketConnectionClosedException:
                pass
            except Exception as e:
                logger.exception("qq ws loop: %s", e)
            finally:
                stop_heartbeat()
                with contextlib.suppress(Exception):
                    current_ws.close()
            last_connect_time_val = last_connect_time
            if last_connect_time_val and (time.time() - last_connect_time_val) < QUICK_DISCONNECT_THRESHOLD:
                quick_disconnect_count += 1
                if quick_disconnect_count >= MAX_QUICK_DISCONNECT_COUNT:
                    session_id = None
                    last_seq = None
                    should_refresh_token = True
                    quick_disconnect_count = 0
                    reconnect_attempts = min(
                        reconnect_attempts,
                        len(RECONNECT_DELAYS) - 1,
                    )
                    delay = RATE_LIMIT_DELAY
                else:
                    delay = RECONNECT_DELAYS[min(reconnect_attempts, len(RECONNECT_DELAYS) - 1)]
            else:
                quick_disconnect_count = 0
                delay = RECONNECT_DELAYS[min(reconnect_attempts, len(RECONNECT_DELAYS) - 1)]
            reconnect_attempts += 1
            if reconnect_attempts >= MAX_RECONNECT_ATTEMPTS:
                logger.error("qq max reconnect attempts reached")
                return False
            logger.info(
                "qq reconnecting in %ss (attempt %s)",
                delay,
                reconnect_attempts,
            )
            self._stop_event.wait(timeout=delay)
            if self._stop_event.is_set():
                logger.info("qq reconnect aborted: stop_event was set during wait")
                return False
            return True

        while connect():
            pass
        self._stop_event.set()
        logger.info("qq ws thread stopped")

    def get_connection_status(self) -> dict:
        """QQ 频道连接状态：基于 WebSocket 线程和 stop_event 判断，同时校验凭据。"""
        if not self.enabled:
            return {"status": "not_enabled", "reason": None}
        # 凭据校验
        if not self.app_id:
            return {
                "status": "disconnected",
                "reason": "App ID 未配置",
            }
        if not self.client_secret:
            return {
                "status": "disconnected",
                "reason": "Client Secret 未配置",
            }
        if self._ws_thread is None or not self._ws_thread.is_alive():
            return {
                "status": "disconnected",
                "reason": "WebSocket 线程已停止",
            }
        if self._stop_event.is_set():
            return {
                "status": "disconnected",
                "reason": "频道正在关闭或已断开",
            }
        return {"status": "connected", "reason": None}

    async def verify_credentials(self) -> dict:
        """QQ 频道凭据校验：调用 getAppAccessToken 接口验证 App ID 和 Client Secret。"""
        if not self.enabled:
            return {"valid": False, "status": "not_enabled", "reason": None}
        return await self.verify_credentials_with_params(
            {
                "app_id": self.app_id,
                "client_secret": self.client_secret,
            }
        )

    @staticmethod
    async def verify_credentials_with_params(credentials: dict) -> dict:
        """使用传入的凭据参数直接调用 QQ 平台 API 校验连接联通性。"""
        app_id = (credentials.get("app_id") or "").strip()
        client_secret = (credentials.get("client_secret") or "").strip()
        if not app_id:
            return {
                "valid": False,
                "status": "disconnected",
                "reason": "App ID 未配置",
            }
        if not client_secret:
            return {
                "valid": False,
                "status": "disconnected",
                "reason": "Client Secret 未配置",
            }
        import aiohttp as _aiohttp

        try:
            async with (
                _aiohttp.ClientSession() as session,
                session.post(
                    TOKEN_URL,
                    json={
                        "appId": app_id,
                        "clientSecret": client_secret,
                    },
                    headers={"Content-Type": "application/json"},
                    timeout=_aiohttp.ClientTimeout(total=10),
                ) as resp,
            ):
                data = await resp.json(content_type=None)
                if resp.status >= 400:
                    return {
                        "valid": False,
                        "status": "disconnected",
                        "reason": f"凭据验证失败 (HTTP {resp.status}): {data}",
                    }
                token = data.get("access_token")
                if not token:
                    err_msg = data.get("message") or data.get("msg") or str(data)
                    return {
                        "valid": False,
                        "status": "disconnected",
                        "reason": f"凭据无效: {err_msg}",
                    }
                return {
                    "valid": True,
                    "status": "connected",
                    "reason": None,
                }
        except Exception as e:
            return {
                "valid": False,
                "status": "disconnected",
                "reason": f"连接检测失败: {e}",
            }

    async def start(self) -> None:
        if not self.enabled:
            logger.debug("qq channel disabled by QQ_CHANNEL_ENABLED=0")
            return
        if not self.app_id or not self.client_secret:
            raise RuntimeError(
                "QQ_APP_ID and QQ_CLIENT_SECRET are required when channel is enabled.",
            )
        self._loop = asyncio.get_running_loop()
        self._stop_event.clear()
        self._ws_thread = threading.Thread(
            target=self._run_ws_forever,
            daemon=True,
        )
        self._ws_thread.start()
        if self._http is None:
            self._http = aiohttp.ClientSession()

    async def stop(self) -> None:
        if not self.enabled:
            return
        self._stop_event.set()
        if self._ws_thread:
            self._ws_thread.join(timeout=8)
        if self._http is not None:
            await self._http.close()
            self._http = None
