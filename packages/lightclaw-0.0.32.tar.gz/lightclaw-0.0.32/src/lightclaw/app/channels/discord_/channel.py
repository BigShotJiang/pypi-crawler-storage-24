# pylint: disable=too-many-branches,too-many-statements
from __future__ import annotations

import asyncio
import contextlib
import logging
import os
from typing import Any

import aiohttp

from ....config.config import DiscordConfig as DiscordChannelConfig
from ...schemas import (
    AudioContent,
    ContentType,
    FileContent,
    ImageContent,
    TextContent,
    VideoContent,
)
from ...turn_protocol import TurnRequest
from ..base import BaseChannel, OnReplySent, ProcessHandler

logger = logging.getLogger(__name__)


class DiscordChannel(BaseChannel):
    channel = "discord"
    uses_manager_queue = True

    def __init__(
        self,
        process: ProcessHandler,
        enabled: bool,
        token: str,
        http_proxy: str,
        http_proxy_auth: str,
        bot_prefix: str,
        on_reply_sent: OnReplySent = None,
        show_tool_details: bool = True,
    ):
        super().__init__(
            process,
            on_reply_sent=on_reply_sent,
            show_tool_details=show_tool_details,
        )
        self.enabled = enabled
        self.token = token
        self.http_proxy = http_proxy
        self.http_proxy_auth = http_proxy_auth
        self.bot_prefix = bot_prefix
        self._task: asyncio.Task | None = None
        self._client = None

        if self.enabled:
            import discord  # type: ignore

            intents = discord.Intents.default()
            intents.message_content = True
            intents.dm_messages = True
            intents.messages = True
            intents.guilds = True

            proxy_auth = None
            if self.http_proxy_auth:
                u, p = self.http_proxy_auth.split(":", 1)
                proxy_auth = aiohttp.BasicAuth(u, p)

            self._client = discord.Client(
                intents=intents,
                proxy=self.http_proxy,
                proxy_auth=proxy_auth,
            )

            @self._client.event
            async def on_message(message):
                if message.author.bot:
                    return
                text = (message.content or "").strip()
                attachments = message.attachments

                # Build runtime content parts
                content_parts = []
                if text:
                    content_parts.append(
                        TextContent(type=ContentType.TEXT, text=text),
                    )
                if attachments:
                    for att in attachments:
                        file_name = (att.filename or "").lower()
                        url = att.url
                        ctype = (att.content_type or "").lower()

                        is_image = ctype.startswith(
                            "image/",
                        ) or file_name.endswith(
                            (
                                ".png",
                                ".jpg",
                                ".jpeg",
                                ".gif",
                                ".webp",
                                ".bmp",
                                ".tiff",
                            ),
                        )
                        is_video = ctype.startswith(
                            "video/",
                        ) or file_name.endswith(
                            (".mp4", ".mov", ".mkv", ".webm", ".avi"),
                        )
                        is_audio = ctype.startswith(
                            "audio/",
                        ) or file_name.endswith(
                            (".mp3", ".wav", ".m4a", ".aac", ".ogg", ".flac"),
                        )

                        if is_image:
                            content_parts.append(
                                ImageContent(
                                    type=ContentType.IMAGE,
                                    image_url=url,
                                ),
                            )
                        elif is_video:
                            content_parts.append(
                                VideoContent(
                                    type=ContentType.VIDEO,
                                    video_url=url,
                                ),
                            )
                        elif is_audio:
                            content_parts.append(
                                AudioContent(
                                    type=ContentType.AUDIO,
                                    data=url,
                                ),
                            )
                        else:
                            content_parts.append(
                                FileContent(
                                    type=ContentType.FILE,
                                    file_url=url,
                                ),
                            )

                meta = {
                    "user_id": str(message.author.id),
                    "channel_id": str(message.channel.id),
                    "guild_id": str(message.guild.id) if message.guild else None,
                    "message_id": str(message.id),
                    "is_dm": message.guild is None,
                }
                native = {
                    "channel_id": self.channel,
                    "sender_id": str(message.author),
                    "content_parts": content_parts,
                    "meta": meta,
                }
                if self._enqueue is not None:
                    self._enqueue(native)
                else:
                    logger.warning(
                        "discord: _enqueue not set, message dropped",
                    )

    @classmethod
    def from_env(
        cls,
        process: ProcessHandler,
        on_reply_sent: OnReplySent = None,
    ) -> DiscordChannel:
        return cls(
            process=process,
            enabled=os.getenv("DISCORD_CHANNEL_ENABLED", "1") == "1",
            token=os.getenv("DISCORD_BOT_TOKEN", ""),
            http_proxy=os.getenv(
                "DISCORD_HTTP_PROXY",
                "",
            ),
            http_proxy_auth=os.getenv("DISCORD_HTTP_PROXY_AUTH", ""),
            bot_prefix=os.getenv("DISCORD_BOT_PREFIX", "[BOT] "),
            on_reply_sent=on_reply_sent,
        )

    @classmethod
    def from_config(
        cls,
        process: ProcessHandler,
        config: DiscordChannelConfig,
        on_reply_sent: OnReplySent = None,
        show_tool_details: bool = True,
    ) -> DiscordChannel:
        return cls(
            process=process,
            enabled=config.enabled,
            token=config.bot_token or "",
            http_proxy=config.http_proxy,
            http_proxy_auth=config.http_proxy_auth or "",
            bot_prefix=config.bot_prefix or "[BOT] ",
            on_reply_sent=on_reply_sent,
            show_tool_details=show_tool_details,
        )

    def _route_from_handle(self, to_handle: str) -> dict:
        # to_handle: discord:ch:<channel_id> 或 discord:dm:<user_id>
        parts = (to_handle or "").split(":")
        if len(parts) >= 3 and parts[0] == "discord":
            kind, ident = parts[1], parts[2]
            if kind == "ch":
                return {"channel_id": ident}
            if kind == "dm":
                return {"user_id": ident}
        return {}

    async def _on_tool_approval_required(
        self,
        request: Any,
        to_handle: str,
        event: Any,
        meta: dict | None = None,
    ) -> None:
        """Discord：发送 Embed 格式风险提示消息。

        使用 discord.py Embed 展示风险详情，颜色根据严重性区分。
        用户直接回复 /approve 批准执行。
        """
        if not self.enabled or not self._client:
            return
        data = event.data or {}
        tool_name = data.get("tool_name", "unknown")
        severity = data.get("severity", "UNKNOWN")
        findings_count = data.get("findings_count", 0)
        findings_text = data.get("findings_text", "")
        auto_denied = data.get("auto_denied", False)

        try:
            import discord  # type: ignore

            # 颜色：CRITICAL/HIGH=红，MEDIUM=橙，LOW=黄，自动拒绝=深红
            color_map = {
                "CRITICAL": discord.Color.red(),
                "HIGH": discord.Color.red(),
                "MEDIUM": discord.Color.orange(),
                "LOW": discord.Color.yellow(),
            }
            if auto_denied:
                color = discord.Color.dark_red()
                title = "⛔ 工具已被系统拦截"
                footer = "该工具已被禁止，无法批准执行。"
            else:
                color = color_map.get(severity.upper(), discord.Color.orange())
                title = "⚠️ 检测到风险操作"
                footer = "回复 /approve 批准执行，或回复任意内容拒绝。"

            embed = discord.Embed(title=title, color=color)
            embed.add_field(name="工具 / Tool", value=f"`{tool_name}`", inline=True)
            embed.add_field(name="严重性 / Severity", value=f"`{severity}`", inline=True)
            embed.add_field(name="发现数 / Findings", value=str(findings_count), inline=True)
            if findings_text:
                embed.add_field(name="详情", value=findings_text[:1024], inline=False)
            embed.set_footer(text=footer)

            send_meta = dict(meta or {})
            if not send_meta.get("channel_id") and not send_meta.get("user_id"):
                send_meta.update(self._route_from_handle(to_handle))

            channel_id = send_meta.get("channel_id")
            user_id = send_meta.get("user_id")

            if channel_id:
                ch = self._client.get_channel(int(channel_id))
                if ch is None:
                    ch = await self._client.fetch_channel(int(channel_id))
                await ch.send(embed=embed)
            elif user_id:
                user = self._client.get_user(int(user_id))
                if user is None:
                    user = await self._client.fetch_user(int(user_id))
                dm = user.dm_channel or await user.create_dm()
                await dm.send(embed=embed)
            else:
                logger.warning("discord _on_tool_approval_required: no channel_id or user_id, fallback to text send")
                await super()._on_tool_approval_required(request, to_handle, event, meta)
                return

            logger.info(
                "discord _on_tool_approval_required: sent embed tool=%s severity=%s auto_denied=%s",
                tool_name,
                severity,
                auto_denied,
            )
        except Exception:
            logger.exception("discord _on_tool_approval_required failed, fallback to text")
            await super()._on_tool_approval_required(request, to_handle, event, meta)

    async def send(
        self,
        to_handle: str,
        text: str,
        meta: dict | None = None,
    ) -> None:
        """
        Proactive send for Discord.

        Notes:
        - Discord cannot send to a "user handle" directly without resolving
            a User/Channel.
        - This implementation supports:
            1) meta["channel_id"]  -> send to that channel
            2) meta["user_id"]     -> DM that user (opens/uses DM channel)
        - If neither is provided, this raises ValueError.
        """
        if not self.enabled:
            return
        if not self._client:
            raise RuntimeError("Discord client is not initialized")
        if not self._client.is_ready():
            raise RuntimeError("Discord client is not ready yet")

        meta = meta or {}

        if not meta.get("channel_id") and not meta.get("user_id"):
            meta.update(self._route_from_handle(to_handle))

        channel_id = meta.get("channel_id")
        user_id = meta.get("user_id")

        if channel_id:
            ch = self._client.get_channel(int(channel_id))
            if ch is None:
                ch = await self._client.fetch_channel(
                    int(channel_id),
                )
            await ch.send(text)
            return

        if user_id:
            user = self._client.get_user(int(user_id))
            if user is None:
                user = await self._client.fetch_user(
                    int(user_id),
                )
            dm = user.dm_channel or await user.create_dm()
            await dm.send(text)
            return

        raise ValueError(
            "DiscordChannel.send requires meta['channel_id'] or meta['user_id']",
        )

    async def _run(self) -> None:
        if not self.enabled or not self.token or not self._client:
            return
        await self._client.start(self.token, reconnect=True)

    async def start(self) -> None:
        if not self.enabled:
            return
        self._task = asyncio.create_task(self._run(), name="discord_gateway")

    async def stop(self) -> None:
        if not self.enabled:
            return
        if self._task:
            self._task.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await asyncio.wait_for(self._task, timeout=5)
        if self._client:
            await self._client.close()

    def resolve_session_id(
        self,
        sender_id: str,
        channel_meta: dict | None = None,
    ) -> str:
        """Session by channel (guild) or DM user id."""
        meta = channel_meta or {}
        is_dm = bool(meta.get("is_dm"))
        channel_id = meta.get("channel_id")
        user_id = meta.get("user_id") or sender_id
        if is_dm:
            return f"discord:dm:{user_id}"
        if channel_id:
            return f"discord:ch:{channel_id}"
        return f"discord:dm:{user_id}"

    def get_to_handle_from_request(self, request: Any) -> str:
        """Discord send target is session_id (discord:ch:xxx or dm:xxx)."""
        sid = getattr(request, "session_id", "")
        uid = getattr(request, "user_id", "")
        return sid or uid or ""

    def build_turn_request_from_native(self, native_payload: Any) -> TurnRequest:
        """Build TurnRequest from Discord dict (content_parts + meta)."""
        payload = native_payload if isinstance(native_payload, dict) else {}
        channel_id = payload.get("channel_id") or self.channel
        sender_id = payload.get("sender_id") or ""
        content_parts = payload.get("content_parts") or []
        meta = payload.get("meta") or {}
        user_id = str(meta.get("user_id") or sender_id)
        session_id = self.resolve_session_id(user_id, meta)
        return self.build_turn_request_from_user_content(
            channel_id=channel_id,
            sender_id=user_id,
            session_id=session_id,
            content_parts=content_parts,
            channel_meta=meta,
        )

    def to_handle_from_target(self, *, user_id: str, session_id: str) -> str:
        return session_id
