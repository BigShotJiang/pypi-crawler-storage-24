"""Compatibility shim: re-export from channels.core.schema."""

from .core.schema import DEFAULT_CHANNEL, ChannelType

__all__ = ["DEFAULT_CHANNEL", "ChannelType"]
