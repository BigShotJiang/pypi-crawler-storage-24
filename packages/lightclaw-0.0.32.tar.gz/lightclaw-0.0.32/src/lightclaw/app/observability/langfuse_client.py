"""Langfuse 可观测性客户端封装。

通过环境变量配置（Langfuse SDK 原生支持，可放在 WORKING_DIR/.env）：
    LANGFUSE_PUBLIC_KEY=pk-lf-xxx
    LANGFUSE_SECRET_KEY=sk-lf-xxx
    LANGFUSE_BASE_URL=http://your-langfuse-host
    LANGFUSE_HOST=http://your-langfuse-host  # 兼容旧变量名，可选

未配置时所有函数均为空操作，不影响主流程。

注意：此文件适配 langfuse >= 3.0。
    v3 破坏性变更：
    - CallbackHandler 从 langfuse.callback 移至 langfuse.langchain
    - CallbackHandler 不再接受 trace_name/session_id/user_id/metadata 参数
    - trace_id 必须是 32 位小写十六进制字符串（UUID 格式）
    - 改用 client.create_trace_id(seed=...) 生成确定性合法 trace_id
    - 改用 client.start_observation() 设置 name/session_id/user_id/metadata
    - project 由 API Key 绑定，无需单独配置
"""

from __future__ import annotations

import logging
import os

logger = logging.getLogger(__name__)

# 延迟初始化，避免未安装 langfuse 时报错
_langfuse_client = None
_initialized = False


def is_langfuse_enabled() -> bool:
    """判断 Langfuse 是否已配置（存在 public key 和 secret key）。"""
    return bool(os.getenv("LANGFUSE_PUBLIC_KEY") and os.getenv("LANGFUSE_SECRET_KEY"))


def _get_client():
    """获取（或懒初始化）Langfuse 客户端单例。"""
    global _langfuse_client, _initialized
    if _initialized:
        return _langfuse_client
    _initialized = True

    if not is_langfuse_enabled():
        return None

    try:
        # langfuse v3：使用 get_client() 获取全局单例
        from langfuse import get_client

        _langfuse_client = get_client()
        logger.info(
            "Langfuse initialized (host=%s)",
            os.getenv("LANGFUSE_BASE_URL", os.getenv("LANGFUSE_HOST", "https://cloud.langfuse.com")),
        )
    except ImportError:
        logger.warning("langfuse package not installed, observability disabled")
    except Exception as e:
        logger.warning("Langfuse initialization failed (non-fatal): %s", e)

    return _langfuse_client


def get_langfuse_callback(
    *,
    trace_name: str = "agent_run",
    session_id: str | None = None,
    user_id: str | None = None,
    metadata: dict | None = None,
):
    """返回 LangChain CallbackHandler，注入到 LangGraph config 的 callbacks 列表。

    未配置 Langfuse 时返回 None，调用方需做 None 检查。

    Args:
        trace_name: Langfuse trace 名称。
        session_id: 关联的会话 ID，用作 trace_id 的 seed（自动转换为合法 hex）。
        user_id: 关联的用户 ID，记录在 metadata 中。
        metadata: 附加元数据（如 channel）。

    Returns:
        CallbackHandler 实例，或 None（未配置时）。
    """
    if not is_langfuse_enabled():
        return None

    try:
        from langfuse import get_client
        from langfuse.langchain import CallbackHandler

        client = get_client()

        # v3 要求 trace_id 必须是 32 位小写 hex 字符串
        # 使用 create_trace_id(seed=session_id) 将任意字符串确定性地映射为合法 trace_id
        trace_id = client.create_trace_id(seed=session_id) if session_id else client.create_trace_id()

        # 通过 start_observation 初始化 trace，设置 name / session_id / user_id / metadata
        # v3 中 session_id/user_id 通过 metadata 传递
        trace_metadata = dict(metadata or {})
        if session_id:
            trace_metadata["session_id"] = session_id
        if user_id:
            trace_metadata["user_id"] = user_id

        span = client.start_observation(
            trace_context={"trace_id": trace_id},
            name=trace_name,
            metadata=trace_metadata,
        )
        span.end()  # 立即结束，仅用于初始化 trace 元数据，实际执行由 CallbackHandler 接管

        return CallbackHandler(trace_context={"trace_id": trace_id})
    except ImportError:
        return None
    except Exception as e:
        logger.warning("Failed to create Langfuse CallbackHandler (non-fatal): %s", e)
        return None


def flush_langfuse() -> None:
    """在应用关闭时调用，确保所有 trace 数据都已发送到 Langfuse。"""
    client = _get_client()
    if client is None:
        return
    try:
        client.flush()
        logger.debug("Langfuse flushed successfully")
    except Exception as e:
        logger.warning("Langfuse flush failed (non-fatal): %s", e)


def reset_langfuse() -> None:
    """重置 Langfuse 单例，使新的环境变量配置在后续请求中生效。"""
    global _langfuse_client, _initialized
    if _langfuse_client is not None:
        try:
            _langfuse_client.flush()
        except Exception:
            logger.debug("Langfuse flush during reset failed", exc_info=True)
    _langfuse_client = None
    _initialized = False
