"""MCP client manager for hot-reloadable client lifecycle management.

This module provides centralized management of MCP clients with support
for runtime updates without restarting the application.

Uses the official ``mcp`` SDK (``ClientSession`` / ``stdio_client`` /
``streamablehttp_client`` / ``sse_client``) instead of the former
``agentscope.mcp.StdIOStatefulClient``.
"""

from __future__ import annotations

import asyncio
import logging
from contextlib import AsyncExitStack, suppress
from typing import TYPE_CHECKING, Any

from mcp import ClientSession, StdioServerParameters
from mcp.client.sse import sse_client
from mcp.client.stdio import stdio_client
from mcp.client.streamable_http import streamablehttp_client

if TYPE_CHECKING:
    from ...config.config import MCPClientConfig, MCPConfig

logger = logging.getLogger(__name__)


class MCPClientWrapper:
    """Wraps an official ``mcp`` SDK ``ClientSession`` with imperative
    ``connect()`` / ``close()`` lifecycle so it can be managed by
    ``MCPClientManager`` without requiring ``async with`` blocks.

    Supports three transport types:
    - ``stdio``: Launch a local process.
    - ``streamable_http``: Connect to a remote HTTP MCP endpoint.
    - ``sse``: Connect via Server-Sent Events.

    Also exposes ``list_tools()`` and ``call_tool()`` with a compatible
    interface so that ``mcp_clients_to_langchain_tools()`` can consume
    it directly.
    """

    def __init__(
        self,
        name: str,
        transport: str = "stdio",
        command: str = "",
        args: list[str] | None = None,
        env: dict[str, str] | None = None,
        cwd: str | None = None,
        url: str = "",
        headers: dict[str, str] | None = None,
    ) -> None:
        self.name = name
        self._transport = transport
        self._command = command
        self._args = args or []
        self._env = env
        self._cwd = cwd or None
        self._url = url
        self._headers = headers or {}
        self._exit_stack: AsyncExitStack | None = None
        self._session: ClientSession | None = None

    async def connect(self) -> None:
        """Start the MCP server process / HTTP connection and initialise the session."""
        self._exit_stack = AsyncExitStack()
        try:
            if self._transport == "stdio":
                server_params = StdioServerParameters(
                    command=self._command,
                    args=self._args,
                    env=self._env,
                    cwd=self._cwd,
                )
                transport = await self._exit_stack.enter_async_context(
                    stdio_client(server_params),
                )
            elif self._transport == "sse":
                transport = await self._exit_stack.enter_async_context(
                    sse_client(
                        url=self._url,
                        headers=self._headers or None,
                    ),
                )
            else:
                # streamable_http (default for remote)
                transport = await self._exit_stack.enter_async_context(
                    streamablehttp_client(
                        url=self._url,
                        headers=self._headers or None,
                    ),
                )

            read_stream, write_stream = transport
            session = ClientSession(read_stream, write_stream)
            self._session = await self._exit_stack.enter_async_context(session)
            await self._session.initialize()
        except BaseException:
            await self.close()
            raise

    async def close(self) -> None:
        """Tear down session and server process."""
        if self._exit_stack is not None:
            try:
                await self._exit_stack.aclose()
            except Exception:
                pass
            finally:
                self._exit_stack = None
                self._session = None

    # ------------------------------------------------------------------
    # Public helpers consumed by tools/mcp.py
    # ------------------------------------------------------------------

    @property
    def session(self) -> ClientSession:
        if self._session is None:
            raise RuntimeError(f"MCP client '{self.name}' is not connected")
        return self._session

    async def list_tools(self) -> list:
        """Return the list of ``mcp.types.Tool`` exposed by the server."""
        result = await self.session.list_tools()
        return result.tools

    async def call_tool(self, name: str, arguments: dict[str, Any] | None = None):
        """Call a tool on the server and return ``CallToolResult``."""
        return await self.session.call_tool(name, arguments)


class MCPClientManager:
    """Manages MCP clients with hot-reload support.

    This manager handles the lifecycle of MCP clients, including:
    - Initial loading from config
    - Runtime replacement when config changes
    - Cleanup on shutdown

    Design pattern mirrors ChannelManager for consistency.
    """

    def __init__(self) -> None:
        """Initialize an empty MCP client manager."""
        self._clients: dict[str, MCPClientWrapper] = {}
        self._lock = asyncio.Lock()

    async def init_from_config(self, config: MCPConfig) -> None:
        """Initialize clients from configuration.

        Args:
            config: MCP configuration containing client definitions
        """
        logger.debug("Initializing MCP clients from config")
        for key, client_config in config.clients.items():
            if not client_config.enabled:
                logger.debug(f"MCP client '{key}' is disabled, skipping")
                continue

            try:
                await self._add_client(key, client_config)
                logger.debug(f"MCP client '{key}' initialized successfully")
            except Exception as e:
                logger.warning(
                    f"Failed to initialize MCP client '{key}': {e}",
                    exc_info=True,
                )

    async def get_clients(self) -> list[Any]:
        """Get list of all active MCP clients.

        This method is called by the runner on each query to get
        the latest set of clients.

        Returns:
            List of connected MCPClientWrapper instances
        """
        async with self._lock:
            return [client for client in self._clients.values() if client is not None]

    async def replace_client(
        self,
        key: str,
        client_config: MCPClientConfig,
        timeout: float = 60.0,
    ) -> None:
        """Replace or add a client with new configuration.

        Flow: connect new (outside lock) → swap + close old (inside lock).
        This ensures minimal lock holding time.

        Args:
            key: Client identifier (from config)
            client_config: New client configuration
            timeout: Connection timeout in seconds (default 60s)
        """
        # 1. Create and connect new client outside lock (may be slow)
        logger.debug(f"Connecting new MCP client: {key}")
        new_client = MCPClientWrapper(
            name=client_config.name,
            transport=client_config.transport,
            command=client_config.command,
            args=client_config.args,
            env=client_config.env,
            cwd=client_config.cwd or None,
            url=client_config.url,
            headers=client_config.headers,
        )

        try:
            await asyncio.wait_for(new_client.connect(), timeout=timeout)
        except TimeoutError:
            logger.warning(
                f"Timeout connecting MCP client '{key}' after {timeout}s",
            )
            with suppress(Exception):
                await new_client.close()
            raise
        except Exception as e:
            logger.warning(f"Failed to connect MCP client '{key}': {e}")
            with suppress(Exception):
                await new_client.close()
            raise

        # 2. Swap and close old client inside lock
        async with self._lock:
            old_client = self._clients.get(key)
            self._clients[key] = new_client

            if old_client is not None:
                logger.debug(f"Closing old MCP client: {key}")
                try:
                    await old_client.close()
                except Exception as e:
                    logger.warning(
                        f"Error closing old MCP client '{key}': {e}",
                    )
            else:
                logger.debug(f"Added new MCP client: {key}")

    async def remove_client(self, key: str) -> None:
        """Remove and close a client.

        Args:
            key: Client identifier to remove
        """
        async with self._lock:
            old_client = self._clients.pop(key, None)

        if old_client is not None:
            logger.debug(f"Removing MCP client: {key}")
            try:
                await old_client.close()
            except Exception as e:
                logger.warning(f"Error closing MCP client '{key}': {e}")

    async def close_all(self) -> None:
        """Close all MCP clients.

        Called during application shutdown.
        """
        async with self._lock:
            clients_snapshot = list(self._clients.items())
            self._clients.clear()

        logger.debug("Closing all MCP clients")
        for key, client in clients_snapshot:
            if client is not None:
                try:
                    await client.close()
                except Exception as e:
                    logger.warning(f"Error closing MCP client '{key}': {e}")

    async def _add_client(
        self,
        key: str,
        client_config: MCPClientConfig,
        timeout: float = 60.0,
    ) -> None:
        """Add a new client (used during initial setup).

        Args:
            key: Client identifier
            client_config: Client configuration
            timeout: Connection timeout in seconds (default 60s)
        """
        client = MCPClientWrapper(
            name=client_config.name,
            transport=client_config.transport,
            command=client_config.command,
            args=client_config.args,
            env=client_config.env,
            cwd=client_config.cwd or None,
            url=client_config.url,
            headers=client_config.headers,
        )

        # Add timeout to prevent indefinite blocking
        await asyncio.wait_for(client.connect(), timeout=timeout)

        async with self._lock:
            self._clients[key] = client
