from __future__ import annotations

import asyncio
import logging
from typing import Any
from uuid import uuid4

from ..tasks.models import TaskInfo, TaskSource, TaskStatus
from ..tasks.role_resolver import resolve_role
from ..turn_protocol import TurnEventType, TurnInput, TurnRequest
from .models import CronJobSpec

logger = logging.getLogger(__name__)


class CronExecutor:
    def __init__(self, *, runner: Any, channel_manager: Any, task_registry: Any | None = None):
        self._runner = runner
        self._channel_manager = channel_manager
        self._task_registry = task_registry

    async def execute(self, job: CronJobSpec) -> None:
        """Execute one job once.

        - task_type text: send fixed text to channel
        - task_type agent: ask agent with prompt via stream_turns, dispatch
            TurnEvent(assistant.completed) to channel via send_event
        """
        target_user_id = job.dispatch.target.user_id
        target_session_id = job.dispatch.target.session_id
        dispatch_meta: dict[str, Any] = dict(job.dispatch.meta or {})
        # Ensure session_id is in meta so dashboard channel can push results
        dispatch_meta.setdefault("session_id", target_session_id)
        channels: list = job.dispatch.channel  # always a list[str]
        logger.info(
            "cron execute: job_id=%s channels=%s task_type=%s target_user_id=%s target_session_id=%s",
            job.id,
            channels,
            job.task_type,
            target_user_id[:40] if target_user_id else "",
            target_session_id[:40] if target_session_id else "",
        )

        if job.task_type == "text" and job.text:
            logger.info(
                "cron send_text: job_id=%s channels=%s len=%s",
                job.id,
                channels,
                len(job.text or ""),
            )
            for channel in channels:
                await self._channel_manager.send_text(
                    channel=channel,
                    user_id=target_user_id,
                    session_id=target_session_id,
                    text=job.text.strip(),
                    meta=dispatch_meta,
                )
            return

        # agent: run request as the dispatch target user so context matches.
        # Use stream_turns (canonical TurnEvent) and dispatch assistant.completed
        # events directly to channels — no legacy process-protocol conversion needed.
        logger.info(
            "cron agent: job_id=%s channels=%s stream_turns then send_event",
            job.id,
            channels,
        )
        assert job.request is not None
        req_dict: dict[str, Any] = job.request.model_dump(mode="json")
        user_id = target_user_id or "cron"
        session_id = target_session_id or f"cron:{job.id}"
        channel_name = channels[0] if channels else req_dict.get("channel", "dashboard")

        # Build canonical TurnRequest from the job request
        input_msgs = req_dict.get("input", [])
        turn_inputs = [
            TurnInput(
                role=m.get("role", "user"),
                content=m.get("content", []),
            )
            for m in input_msgs
        ]
        turn_request = TurnRequest(
            inputs=turn_inputs,
            session_id=session_id,
            user_id=user_id,
            channel=channel_name,
        )

        # --- Task Board tracking ---
        task_id = str(uuid4())
        if self._task_registry:
            cron_desc = f"Cron: {job.name or job.id}"
            agent_role, agent_name = resolve_role(
                description=cron_desc,
                source=TaskSource.CRON,
                task_id=task_id,
            )
            task_info = TaskInfo(
                id=task_id,
                source=TaskSource.CRON,
                session_id=session_id,
                user_id=user_id,
                channel=channel_name,
                status=TaskStatus.QUEUED,
                description=cron_desc,
                cron_job_name=job.name or job.id,
                agent_name=agent_name,
                agent_role=agent_role,
            )
            await self._task_registry.register_task(task_info)

        async def _run() -> None:
            async for event in self._runner.stream_turns(turn_request):
                if event.type != TurnEventType.ASSISTANT_COMPLETED:
                    continue
                for channel in channels:
                    await self._channel_manager.send_event(
                        channel=channel,
                        user_id=target_user_id,
                        session_id=target_session_id,
                        event=event,
                        meta=dispatch_meta,
                    )

        try:
            await asyncio.wait_for(_run(), timeout=job.runtime.timeout_seconds)
            if self._task_registry:
                await self._task_registry.complete_task(task_id, TaskStatus.COMPLETED)
        except Exception:
            if self._task_registry:
                await self._task_registry.complete_task(task_id, TaskStatus.FAILED)
            raise
