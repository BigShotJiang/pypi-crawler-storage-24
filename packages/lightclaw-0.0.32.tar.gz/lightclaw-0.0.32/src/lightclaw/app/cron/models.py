from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    field_validator,
    model_validator,
)

from ..channels.schema import DEFAULT_CHANNEL


def _parse_channels(v: object) -> list[str]:
    """Normalise channel field to a non-empty list of strings.

    Accepts:
    - str  -> split on comma, strip whitespace
    - list -> validate each element is a non-empty string
    """
    if isinstance(v, str):
        parts = [c.strip() for c in v.split(",") if c.strip()]
        if not parts:
            raise ValueError("channel must not be empty")
        return parts
    if isinstance(v, list):
        parts = [c for c in v if isinstance(c, str) and c.strip()]
        if not parts:
            raise ValueError("channel list must not be empty")
        return [c.strip() for c in parts]
    raise ValueError(f"channel must be a string or list, got {type(v)}")


class ScheduleSpec(BaseModel):
    type: Literal["cron"] = "cron"
    cron: str = Field(...)
    timezone: str = "UTC"

    @field_validator("cron")
    @classmethod
    def normalize_cron_5_fields(cls, v: str) -> str:
        parts = [p for p in v.split() if p]
        if len(parts) == 5:
            return " ".join(parts)

        if len(parts) == 4:
            # treat as: hour dom month dow
            hour, dom, month, dow = parts
            return f"0 {hour} {dom} {month} {dow}"

        if len(parts) == 3:
            # treat as: dom month dow
            dom, month, dow = parts
            return f"0 0 {dom} {month} {dow}"

        # 6 fields (seconds) or too short: reject
        raise ValueError(
            "cron must have 5 fields (or 4/3 fields that can be normalized); seconds not supported.",
        )


class DispatchTarget(BaseModel):
    user_id: str
    session_id: str


class DispatchSpec(BaseModel):
    type: Literal["channel"] = "channel"
    channel: list[str] = Field(default_factory=lambda: [DEFAULT_CHANNEL])
    target: DispatchTarget
    mode: Literal["stream", "final"] = Field(default="stream")
    meta: dict[str, Any] = Field(default_factory=dict)

    @field_validator("channel", mode="before")
    @classmethod
    def _normalise_channel(cls, v: object) -> list[str]:
        return _parse_channels(v)


class JobRuntimeSpec(BaseModel):
    max_concurrency: int = Field(default=1, ge=1)
    timeout_seconds: int = Field(default=120, ge=1)
    misfire_grace_seconds: int = Field(default=60, ge=0)


class CronJobRequest(BaseModel):
    """Passthrough payload to runner.stream_turns(request=...).

    This is aligned with AgentRequest(extra="allow"). We keep it permissive.
    """

    model_config = ConfigDict(extra="allow")

    input: Any
    session_id: str | None = None
    user_id: str | None = None


TaskType = Literal["text", "agent"]


class CronJobSpec(BaseModel):
    id: str
    name: str
    enabled: bool = True

    schedule: ScheduleSpec
    task_type: TaskType = "agent"
    text: str | None = None
    request: CronJobRequest | None = None
    dispatch: DispatchSpec

    runtime: JobRuntimeSpec = Field(default_factory=JobRuntimeSpec)
    meta: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _validate_task_type_fields(self) -> CronJobSpec:
        if self.task_type == "text":
            if not (self.text and self.text.strip()):
                raise ValueError("task_type is text but text is empty")
        elif self.task_type == "agent":
            if self.request is None:
                raise ValueError("task_type is agent but request is missing")
            # Keep request.user_id and request.session_id in sync with target
            target = self.dispatch.target
            self.request = self.request.model_copy(
                update={
                    "user_id": target.user_id,
                    "session_id": target.session_id,
                },
            )
        return self


class JobsFile(BaseModel):
    version: int = 1
    jobs: list[CronJobSpec] = Field(default_factory=list)


class CronJobState(BaseModel):
    next_run_at: datetime | None = None
    last_run_at: datetime | None = None
    last_status: Literal["success", "error", "running", "skipped"] | None = None
    last_error: str | None = None


class CronJobView(BaseModel):
    spec: CronJobSpec
    state: CronJobState = Field(default_factory=CronJobState)
