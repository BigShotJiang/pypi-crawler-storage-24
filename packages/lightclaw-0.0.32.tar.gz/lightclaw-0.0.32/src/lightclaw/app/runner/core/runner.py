# pylint: disable=unused-argument too-many-branches too-many-statements

import logging
import time
from collections.abc import AsyncIterator
from typing import Any

from dotenv import load_dotenv

from ....agent.memory import MemoryManager
from ....agent.memory.memory_store import QdrantMemoryStore
from ....constant import WORKING_DIR
from ....envs.store import get_env_file_path
from ...core.error_utils import classify_exception
from ...turn_protocol import TurnEvent, TurnEventType, TurnRequest
from ..session.session import SafeSession
from ..session.session_factory import SessionFactory
from ..tools.registry import ToolRegistry
from .event_bridge import EventBridge
from .run_controller import RunController

logger = logging.getLogger(__name__)


class AgentRunner:
    """Self-built runner that directly produces TurnEvent streams.

    ``stream_turns(request)`` is consumed by:
      - ``/api/agent/process`` SSE endpoint (via _app.py)
      - Channels via ``make_process_from_runner(runner)``
    """

    _APPROVAL_TIMEOUT_SECONDS = 300.0

    def __init__(self) -> None:
        self._chat_manager = None
        self._mcp_manager = None
        self.session: SafeSession | None = None
        self.memory_manager: MemoryManager | None = None
        self._memory_store: QdrantMemoryStore | None = None

    # ----- 外部依赖注入 -----

    def set_chat_manager(self, chat_manager):
        """Set chat manager for auto-registration."""
        self._chat_manager = chat_manager

    def set_mcp_manager(self, mcp_manager):
        """Set MCP client manager for hot-reload support."""
        self._mcp_manager = mcp_manager

    # ----- 生命周期 -----

    async def start(self):
        """Initialise session, memory, etc. (replaces init_handler)."""
        env_path = get_env_file_path()
        if env_path.exists():
            load_dotenv(env_path)
            logger.debug("Loaded environment variables from %s", env_path)
        else:
            logger.debug(
                ".env file not found at %s, using existing environment variables",
                env_path,
            )

        session_dir = str(WORKING_DIR / "sessions")
        self.session = SafeSession(save_dir=session_dir)

        try:
            if self.memory_manager is None:
                self.memory_manager = MemoryManager(
                    working_dir=str(WORKING_DIR),
                )
            await self.memory_manager.start()
        except Exception as e:
            logger.exception("MemoryManager start failed: %s", e)

        # 启动记忆存储后端（含 Qdrant 降级逻辑）
        try:
            self._memory_store = QdrantMemoryStore(working_dir=str(WORKING_DIR))
            await self._memory_store.start(self.memory_manager)
        except Exception as e:
            logger.exception("MemoryStore start failed: %s", e)

    async def stop(self):
        """Shutdown handler."""
        if self._memory_store is not None:
            self._memory_store.stop()
            self._memory_store = None

        try:
            if self.memory_manager:
                await self.memory_manager.close()
        except Exception as e:
            logger.warning("MemoryManager stop failed: %s", e)

    # ----- 私有辅助方法 -----

    def _extract_query_text(self, request: TurnRequest) -> str:
        """从请求的第一条消息中提取纯文本内容。"""
        inputs = getattr(request, "inputs", None) or []
        if not inputs:
            return ""
        content = getattr(inputs[0], "content", None) or []
        if not isinstance(content, list):
            return ""
        for part in content:
            text = part.get("text") if isinstance(part, dict) else getattr(part, "text", None)
            if text:
                return str(text).strip()
        return ""

    @staticmethod
    def _format_args_summary(arguments: dict, max_items: int = 3) -> str:
        """将工具参数字典格式化为可读摘要字符串。"""
        items = list(arguments.items())[:max_items]
        summary = ", ".join(f"{k}={v!r}" for k, v in items)
        return summary + (", ..." if len(arguments) > max_items else "")

    # ----- ToolGuard 审批路由 -----

    async def _handle_tool_guard_approval(self, request: TurnRequest) -> bool:
        """检查并处理 ToolGuard pending 审批命令。

        如果该 session 有 pending 审批：
        - 用户发送 /approve → 批准，返回 True（不继续正常流程）
        - 用户发送其他消息 → 拒绝，返回 True（不继续正常流程）

        如果没有 pending 审批，返回 False（继续正常流程）。
        """
        try:
            from lightclaw.security.tool_guard.approval import ApprovalDecision
            from lightclaw.security.tool_guard.service import get_approval_service

            session_id = getattr(request, "session_id", "") or ""
            if not session_id:
                return False

            svc = get_approval_service()
            pending = await svc.get_pending_by_session(session_id)
            if pending is None:
                return False

            query = self._extract_query_text(request)

            elapsed = time.time() - pending.created_at

            if elapsed > self._APPROVAL_TIMEOUT_SECONDS:
                await svc.resolve_request(pending.request_id, ApprovalDecision.TIMEOUT)
                logger.info(
                    "Tool guard: approval timed out for tool '%s' (session %s)",
                    pending.tool_name,
                    session_id[:8],
                )
                return True

            normalized = query.lower()
            if normalized in ("/approve", "/daemon approve"):
                await svc.resolve_request(pending.request_id, ApprovalDecision.APPROVED)
                logger.info(
                    "Tool guard: approved tool '%s' (session %s)",
                    pending.tool_name,
                    session_id[:8],
                )
                # 审批通过后，让 LangGraph 重新执行（返回 False 继续正常流程）
                return False

            # 任何其他消息 = 拒绝
            await svc.resolve_request(pending.request_id, ApprovalDecision.DENIED)
            logger.info(
                "Tool guard: denied tool '%s' (session %s)",
                pending.tool_name,
                session_id[:8],
            )
            return True

        except ImportError:
            return False
        except Exception as exc:
            logger.warning("Tool guard approval routing error: %s", exc)
            return False

    # ----- 核心：stream_turns -----

    async def stream_turns(
        self,
        request: TurnRequest,
    ) -> AsyncIterator[TurnEvent]:
        """Canonical turn-native event stream."""
        if not isinstance(request, TurnRequest):
            request = TurnRequest.model_validate(request if isinstance(request, dict) else request.model_dump())

        if self.session is None:
            raise RuntimeError("Session is not initialised")

        seq = 0

        def _stamp(event: TurnEvent) -> TurnEvent:
            nonlocal seq
            stamped = event.model_copy(update={"sequence_number": seq})
            seq += 1
            return stamped

        # ToolGuard: 检查是否有 pending 审批
        # 如果有 pending 审批，先路由审批命令，再决定是否继续正常流程
        guard_consumed = await self._handle_tool_guard_approval(request)
        if guard_consumed:
            # 审批命令已处理（approve/deny），不继续正常 LLM 流程
            return

        yield _stamp(
            TurnEvent(
                type=TurnEventType.TURN_STARTED,
                turn_id=request.turn_id,
                metadata={"session_id": request.session_id},
            )
        )

        controller = None
        try:
            session_factory = SessionFactory(
                session=self.session,
                memory_manager=self.memory_manager,
                chat_manager=self._chat_manager,
            )
            tool_registry = ToolRegistry(mcp_manager=self._mcp_manager)
            event_bridge = EventBridge()
            controller = RunController(
                session_factory=session_factory,
                tool_registry=tool_registry,
                event_bridge=event_bridge,
            )

            async for event, _is_last in controller.run(
                msgs=request.inputs,
                request=request,
            ):
                yield _stamp(event)

        except Exception as exc:
            error_info = classify_exception(exc)
            logger.exception(
                "stream_turns error [%s/%s]: %s",
                error_info.code,
                error_info.source,
                error_info.raw_message or error_info.message,
            )
            yield _stamp(
                TurnEvent(
                    type=TurnEventType.TURN_FAILED,
                    turn_id=request.turn_id,
                    error=error_info.to_event_error(),
                )
            )
            return

        run_usage = getattr(controller, "last_run_usage", None)
        yield _stamp(
            TurnEvent(
                type=TurnEventType.TURN_COMPLETED,
                turn_id=request.turn_id,
                usage=run_usage,
            )
        )

    async def stream_content(
        self,
        request: Any,
        *,
        include_tool_details: bool = False,
    ) -> AsyncIterator[str]:
        """AgentExecutor.stream_content() 的便利方法。

        直接产出纯文本片段，供新 Channel（OpenAI / MCP 等）使用，
        无需调用方自行解析 TurnEvent。

        Args:
            request: TurnRequest 或兼容的请求对象。
            include_tool_details: 为 True 时，TOOL_STARTED 事件会 yield
                格式化的工具调用描述（工具名 + 参数摘要）；默认 False 不输出。

        Yields:
            str: AI 回复文本片段，或工具调用描述（当 include_tool_details=True）。
        """
        async for turn_event in self.stream_turns(request):
            if turn_event.type == TurnEventType.ASSISTANT_DELTA:
                # 只输出文本类型的 delta
                delta = turn_event.delta
                if isinstance(delta, dict) and delta.get("type") == "text":
                    text = delta.get("text", "")
                    if text:
                        yield text

            elif turn_event.type == TurnEventType.TOOL_STARTED and include_tool_details:
                # 输出格式化的工具调用描述
                data = turn_event.data or {}
                tool_name = ""
                args_summary = ""
                if isinstance(data, dict):
                    tool_name = str(data.get("name") or data.get("tool_name") or "")
                    arguments = data.get("arguments") or data.get("args") or {}
                    if isinstance(arguments, dict) and arguments:
                        args_summary = self._format_args_summary(arguments)
                if tool_name:
                    desc = f"\n[调用工具: {tool_name}"
                    if args_summary:
                        desc += f"({args_summary})"
                    desc += "]\n"
                    yield desc

            # TURN_STARTED / TURN_COMPLETED / TURN_FAILED / ASSISTANT_COMPLETED
            # / TOOL_COMPLETED 不输出任何内容
