"""Event bridge for streaming agent events back to runtime.

This module isolates the streaming implementation from the core runner
so that future loop implementations can swap out the underlying mechanism
without changing external behaviour.

PR4 additions:
* ``stream_langgraph_run`` — delegate to ``LangGraphEventBridge``
"""

from __future__ import annotations

import logging
from collections.abc import AsyncIterator, Sequence
from typing import Any

logger = logging.getLogger(__name__)


class EventBridge:
    """Bridge between the agent execution loop and runtime events.

    Only the LangGraph streaming path is supported.
    """

    async def stream_langgraph_run(
        self,
        *,
        graph: Any,
        messages: Sequence[Any],
        turn_id: str,
        config: dict | None = None,
        emit_tool_events: bool = False,
    ) -> AsyncIterator[Any]:
        """Stream a LangGraph agent run as turn-native events.

        Delegates to ``LangGraphEventBridge`` from the langgraph package
        so that the Runner layer can use a unified ``EventBridge`` API
        regardless of the backend.
        """
        from ....agent.langgraph.event_bridge import LangGraphEventBridge

        bridge = LangGraphEventBridge(emit_tool_events=emit_tool_events)
        async for event in bridge.stream(
            graph,
            messages,
            turn_id=turn_id,
            config=config,
        ):
            yield event
