"""Chat models for runner with UUID management."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any
from uuid import uuid4

from pydantic import BaseModel, Field, field_validator, model_validator

from ...channels.schema import DEFAULT_CHANNEL
from ...schemas import Message


class ChatSpec(BaseModel):
    """Chat specification with UUID identifier.

    Stored in Redis and can be persisted in JSON file.
    """

    id: str = Field(
        default_factory=lambda: str(uuid4()),
        description="Chat UUID identifier",
    )
    name: str = Field(default="New Chat", description="Chat name")
    session_id: str = Field(
        ...,
        description="Session identifier (channel:user_id format)",
    )
    user_id: str = Field(..., description="User identifier")
    channel: str = Field(default=DEFAULT_CHANNEL, description="Channel name")
    created_at: datetime = Field(
        default_factory=lambda: datetime.now(UTC),
        description="Chat creation timestamp",
    )
    updated_at: datetime | None = Field(
        default=None,
        description="Chat last update timestamp",
    )

    @model_validator(mode="after")
    def _default_updated_at(self) -> ChatSpec:
        if self.updated_at is None:
            self.updated_at = self.created_at
        return self

    meta: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional metadata",
    )

    @field_validator("created_at", "updated_at", mode="before")
    @classmethod
    def _assume_utc(cls, v: Any) -> Any:
        """Treat naive datetime strings/objects as UTC."""
        if isinstance(v, str) and v and v[-1] not in ("+", "Z") and "+" not in v[10:] and "-" not in v[10:]:
            return v + "Z"
        if isinstance(v, datetime) and v.tzinfo is None:
            return v.replace(tzinfo=UTC)
        return v


class ChatHistory(BaseModel):
    """Complete chat view with spec and state."""

    messages: list[Message] = Field(default_factory=list)


class ChatsFile(BaseModel):
    """Chat registry file for JSON repository.

    Stores chat_id (UUID) -> session_id mappings for persistence.
    """

    version: int = 1
    chats: list[ChatSpec] = Field(default_factory=list)
