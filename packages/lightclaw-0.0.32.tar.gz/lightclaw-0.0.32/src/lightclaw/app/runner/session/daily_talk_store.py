"""Global daily talk memory files for prompt personalization.

Stores all users' natural-language user messages in:
  - WORKING_DIR/DAILY_TALK.md
  - WORKING_DIR/TALK_SUMMARY.md

Rollover strategy:
  - Lazy trigger on first normal conversation of the next day.
  - Previous day's DAILY_TALK.md is summarized by the current chat model.
  - Summary is appended to TALK_SUMMARY.md.
  - DAILY_TALK.md is reset for the current day.
"""

from __future__ import annotations

import asyncio
import logging
import re
from datetime import datetime
from pathlib import Path
from typing import Any

from langchain_core.messages import HumanMessage, SystemMessage

logger = logging.getLogger(__name__)

_DATE_MARKER_RE = re.compile(r"<!--\s*daily_talk_date:\s*(\d{4}-\d{2}-\d{2})\s*-->")


def _to_local_now(now: datetime | None = None) -> datetime:
    if now is None:
        return datetime.now().astimezone()
    if now.tzinfo is None:
        return now.astimezone()
    return now.astimezone()


def _current_day(now: datetime | None = None) -> str:
    return _to_local_now(now).strftime("%Y-%m-%d")


def _current_time(now: datetime | None = None) -> str:
    return _to_local_now(now).strftime("%H:%M:%S")


def _coerce_text(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict):
                text = item.get("text")
                if isinstance(text, str):
                    parts.append(text)
        return "\n".join(part for part in parts if part)
    return str(content or "")


class DailyTalkStore:
    """Global user-talk memory store under WORKING_DIR."""

    def __init__(self, working_dir: str | Path) -> None:
        root = Path(working_dir)
        self._daily_path = root / "DAILY_TALK.md"
        self._summary_path = root / "TALK_SUMMARY.md"
        self._lock = asyncio.Lock()

    @property
    def daily_path(self) -> Path:
        return self._daily_path

    @property
    def summary_path(self) -> Path:
        return self._summary_path

    async def needs_rollover(self, *, now: datetime | None = None) -> bool:
        """Return whether DAILY_TALK.md belongs to a previous day."""
        today = _current_day(now)
        async with self._lock:
            text = await asyncio.to_thread(self._read_text, self._daily_path)
        stored = self._extract_daily_date(text)
        return bool(stored and stored != today)

    async def append_user_message(
        self,
        text: str,
        *,
        now: datetime | None = None,
    ) -> None:
        """Append one USER_MESSAGE into today's DAILY_TALK.md."""
        normalized = (text or "").strip()
        if not normalized:
            return

        today = _current_day(now)
        stamp = _current_time(now)

        async with self._lock:
            await asyncio.to_thread(
                self._append_message_sync,
                normalized,
                today,
                stamp,
            )

    async def maybe_rollover(
        self,
        *,
        model: Any,
        now: datetime | None = None,
    ) -> bool:
        """Summarize previous day and reset DAILY_TALK.md for today."""
        today = _current_day(now)
        async with self._lock:
            daily_text = await asyncio.to_thread(self._read_text, self._daily_path)
        stored_date = self._extract_daily_date(daily_text)
        if not stored_date or stored_date == today:
            return False

        daily_body = self._daily_body(daily_text).strip()
        summary_text = ""
        if daily_body:
            summary_text = (await self._summarize_with_model(model, stored_date, daily_body)).strip()

        async with self._lock:
            await asyncio.to_thread(
                self._persist_rollover_sync,
                from_date=stored_date,
                to_date=today,
                summary_text=summary_text,
            )
        return True

    async def build_prompt_context(self) -> str:
        """Build context snippets injected into system prompt."""
        async with self._lock:
            daily_text = await asyncio.to_thread(self._read_text, self._daily_path)
            summary_text = await asyncio.to_thread(self._read_text, self._summary_path)

        parts: list[str] = []
        daily_body = self._daily_body(daily_text).strip()
        daily_date = self._extract_daily_date(daily_text) or ""
        if daily_body:
            attr = f' date="{daily_date}"' if daily_date else ""
            parts.append(f"<daily-talk-context{attr}>\n{daily_body}\n</daily-talk-context>")

        summary_body = self._summary_body(summary_text).strip()
        if summary_body:
            parts.append(f"<talk-summary-context>\n{summary_body}\n</talk-summary-context>")

        return "\n\n".join(parts)

    async def _summarize_with_model(self, model: Any, day: str, body: str) -> str:
        prompt = (
            "你是对话记忆整理助手。请把“仅用户消息”的当天记录压缩成可长期复用的记忆摘要。\n"
            "保留：明确偏好、反复关注点、约束条件、未完成诉求、重要目标变化。\n"
            "要求：简洁、客观、可追溯；输出纯文本，不要 Markdown 花样。"
        )
        user_input = f"日期：{day}\n\n当日用户消息：\n{body}"
        try:
            result = await model.ainvoke(
                [
                    SystemMessage(content=prompt),
                    HumanMessage(content=user_input),
                ]
            )
            summary = _coerce_text(getattr(result, "content", ""))
            if summary.strip():
                return summary.strip()
        except Exception:
            logger.exception("Failed to summarize DAILY_TALK.md for %s", day)

        fallback = body[:1200].strip()
        return fallback if fallback else "当日无有效用户消息。"

    def _append_message_sync(self, text: str, today: str, stamp: str) -> None:
        existing = self._read_text(self._daily_path)
        stored = self._extract_daily_date(existing)
        if stored != today:
            existing = self._daily_header(today)

        payload = existing.rstrip()
        if payload:
            payload += "\n\n"
        payload += f"## {stamp}\n{text}\n"
        self._write_text_atomic(self._daily_path, payload)

    def _persist_rollover_sync(self, *, from_date: str, to_date: str, summary_text: str) -> None:
        if summary_text.strip():
            existing_summary = self._read_text(self._summary_path)
            if not existing_summary.strip():
                existing_summary = "# TALK_SUMMARY\n"

            summary_payload = existing_summary.rstrip()
            if summary_payload:
                summary_payload += "\n\n"
            summary_payload += f"## {from_date}\n{summary_text.strip()}\n"
            self._write_text_atomic(self._summary_path, summary_payload)

        self._write_text_atomic(self._daily_path, self._daily_header(to_date))

    @staticmethod
    def _daily_header(day: str) -> str:
        return f"<!-- daily_talk_date: {day} -->\n# DAILY_TALK\n"

    @staticmethod
    def _extract_daily_date(text: str) -> str:
        if not text:
            return ""
        match = _DATE_MARKER_RE.search(text)
        return match.group(1) if match else ""

    def _daily_body(self, text: str) -> str:
        if not text:
            return ""
        body = _DATE_MARKER_RE.sub("", text, count=1)
        lines = body.splitlines()
        if lines and lines[0].strip() == "# DAILY_TALK":
            lines = lines[1:]
        return "\n".join(lines).strip()

    @staticmethod
    def _summary_body(text: str) -> str:
        if not text:
            return ""
        lines = text.splitlines()
        if lines and lines[0].strip() == "# TALK_SUMMARY":
            lines = lines[1:]
        return "\n".join(lines).strip()

    @staticmethod
    def _read_text(path: Path) -> str:
        if not path.exists():
            return ""
        try:
            return path.read_text(encoding="utf-8")
        except Exception:
            logger.exception("Failed to read %s", path)
            return ""

    @staticmethod
    def _write_text_atomic(path: Path, text: str) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(text, encoding="utf-8")
        tmp.replace(path)
