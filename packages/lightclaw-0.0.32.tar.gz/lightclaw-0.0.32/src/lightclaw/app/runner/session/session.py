"""Session persistence with filename sanitization.

Windows filenames cannot contain: \\ / : * ? " < > |
"""

from __future__ import annotations

import json
import logging
import os
import re
from pathlib import Path
from typing import Any

from ....constant import BASE_DIR

logger = logging.getLogger(__name__)


# Characters forbidden in Windows filenames
_UNSAFE_FILENAME_RE = re.compile(r'[\\/:*?"<>|]')


def sanitize_filename(name: str) -> str:
    """Replace illegal filename chars and strip path traversal hints."""
    # Strip path separators to prevent directory traversal
    name = name.replace("..", ".")
    name = name.replace("/", ".")
    return _UNSAFE_FILENAME_RE.sub("--", name)


class SafeSession:
    """Filesystem-backed session persistence for legacy agent state."""

    def __init__(self, save_dir: str | Path) -> None:
        self.save_dir = str(save_dir)
        os.makedirs(self.save_dir, exist_ok=True)

    def _get_save_path(
        self,
        session_id: str,
        user_id: str | None,
    ) -> str:
        """Return a filesystem-safe save path."""
        os.makedirs(self.save_dir, exist_ok=True)
        file_name = self._build_file_name(session_id, user_id, ".json")
        return os.path.join(self.save_dir, file_name)

    def _build_file_name(
        self,
        session_id: str,
        user_id: str | None,
        suffix: str,
    ) -> str:
        """Return a sanitized file name for the requested session artifact."""
        safe_sid = sanitize_filename(session_id)
        safe_uid = sanitize_filename(user_id) if user_id else ""
        if safe_uid:
            return f"{safe_uid}_{safe_sid}{suffix}"
        return f"{safe_sid}{suffix}"

    def _candidate_save_dirs(self) -> list[Path]:
        """Return directories that may still contain session artifacts.

        Session storage moved from ``BASE_DIR/sessions`` to
        ``WORKING_DIR/sessions``. Keep cleaning both so deleting an existing chat
        also removes artifacts created by older builds.
        """
        current = Path(self.save_dir)
        candidates = [current]
        legacy = BASE_DIR / "sessions"
        if legacy != current:
            candidates.append(legacy)
        return candidates

    def clear_session_files(
        self,
        session_id: str,
        user_id: str | None = None,
    ) -> list[Path]:
        """Delete all known on-disk artifacts for a session.

        Removes both legacy ``.json`` state files and LangGraph
        ``.langgraph.json`` files from the current save directory and the
        legacy pre-workspace directory.
        """
        deleted: list[Path] = []
        for save_dir in self._candidate_save_dirs():
            if not save_dir.exists():
                continue
            for suffix in (".json", ".langgraph.json"):
                path = save_dir / self._build_file_name(session_id, user_id, suffix)
                if path.exists():
                    path.unlink()
                    deleted.append(path)
        if deleted:
            logger.debug(
                "Cleared session files for %s/%s: %s",
                user_id or "",
                session_id,
                ", ".join(str(path) for path in deleted),
            )
        return deleted

    async def save_session_state(
        self,
        *,
        session_id: str | None,
        user_id: str | None,
        agent: Any,
    ) -> None:
        """Save agent state to JSON."""
        if not session_id or agent is None:
            return

        payload = self._build_state_payload(agent)
        if payload is None:
            return

        path = Path(self._get_save_path(session_id, user_id))
        temp_path = path.with_suffix(path.suffix + ".tmp")

        try:
            with open(temp_path, "w", encoding="utf-8") as file:
                json.dump(payload, file, ensure_ascii=False, indent=2)
            temp_path.replace(path)
        except Exception:  # pylint: disable=broad-except
            logger.exception("Failed to save session state to %s", path)

    async def load_session_state(
        self,
        *,
        session_id: str | None,
        user_id: str | None,
        agent: Any,
    ) -> None:
        """Load agent state from JSON if it exists."""
        if not session_id or agent is None:
            return

        path = Path(self._get_save_path(session_id, user_id))
        if not path.exists():
            return

        try:
            with open(path, encoding="utf-8") as file:
                payload = json.load(file)
        except Exception:  # pylint: disable=broad-except
            logger.exception("Failed to load session state from %s", path)
            return

        if isinstance(payload, dict):
            state = payload.get("agent", payload)
        else:
            state = payload

        loader = getattr(agent, "load_state_dict", None)
        if not callable(loader):
            return

        try:
            loader(state)
        except Exception:  # pylint: disable=broad-except
            logger.exception("Failed to load state_dict into agent")

    def _build_state_payload(self, agent: Any) -> dict | None:
        dumper = getattr(agent, "state_dict", None)
        if not callable(dumper):
            return None

        try:
            return {"agent": dumper()}
        except Exception:  # pylint: disable=broad-except
            logger.exception("Failed to build state_dict from agent")
            return None
