"""Session factory for constructing per-run session context.

Responsibilities:
* Load historical session state
* Build environment context and system prompt
* Construct agent context (LangGraph path)
* Manage chat objects via the chat manager
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from typing import Any

from ....config import load_config
from ....constant import (
    MEMORY_COMPACT_KEEP_RECENT,
    MEMORY_COMPACT_RATIO,
    WORKING_DIR,
)
from ...channels.schema import DEFAULT_CHANNEL
from ..tools.utils import build_env_context
from .daily_talk_store import DailyTalkStore
from .session import SafeSession

logger = logging.getLogger(__name__)


def _build_memory_usage_policy(language: str = "zh") -> str:
    """Build instruction block for how to use injected talk memory."""
    if language == "zh":
        return (
            "<memory-usage-policy>\n"
            "你会看到 daily-talk-context 和 talk-summary-context。\n"
            "使用原则：\n"
            "1. 每次回复最多使用 1-2 个相关记忆点，优先用户偏好与未完成事项。\n"
            "2. 用自然口吻体现连续性，不要提及“记忆文件/日志/上下文块”。\n"
            "3. 对不确定的历史信息先确认，不要把旧信息当作绝对事实。\n"
            "4. 优先提供贴合用户历史习惯的下一步建议（时间、格式、粒度）。\n"
            "5. 目标是让用户感到被持续理解和被照顾，而不是被监控或被审问。\n"
            "</memory-usage-policy>"
        )
    return (
        "<memory-usage-policy>\n"
        "You receive daily-talk-context and talk-summary-context.\n"
        "Usage rules:\n"
        "1. Use at most 1-2 relevant memory points per reply; prioritize preferences and unfinished intents.\n"
        "2. Show continuity naturally; never mention memory files, logs, or context blocks.\n"
        "3. Confirm uncertain historical details before relying on them.\n"
        "4. Prefer next-step suggestions aligned with user habits (time, format, granularity).\n"
        "5. Goal: make the user feel consistently understood and cared for, not monitored.\n"
        "</memory-usage-policy>"
    )


@dataclass
class SessionContext:
    """Lightweight container for per-run session state."""

    session_id: str | None
    user_id: str | None
    channel: str
    env_context: str
    agent: Any  # legacy — retained for type compat
    chat: Any | None = None


@dataclass
class LangGraphSessionContext:
    """Container for the LangGraph agent path (PR4+PR5).

    Unlike ``SessionContext`` which carries a ``LightClawAgent``, this holds
    a compiled LangGraph graph, pre-assembled messages, middleware, and
    a session store for persistence.
    """

    session_id: str | None
    user_id: str | None
    channel: str
    env_context: str
    graph: Any  # CompiledStateGraph
    config: Any  # LightClawGraphConfig
    chat: Any | None = None
    history_messages: list = field(default_factory=list)
    # PR5 additions
    middleware: Any | None = None  # LightClawMiddleware
    session_store: Any | None = None  # LangGraphSessionStore
    compressed_summary: str = ""
    # Structured fact extraction (Mem0-style)
    fact_extractor: Any | None = None  # FactExtractor
    fact_store: Any | None = None  # FactStore (for cleanup)


class SessionFactory:
    """Factory responsible for assembling session / agent context."""

    def __init__(
        self,
        *,
        session: SafeSession,
        memory_manager: Any | None,
        chat_manager: Any | None,
    ) -> None:
        self._session = session
        self._memory_manager = memory_manager
        self._chat_manager = chat_manager

    # ------------------------------------------------------------------
    # LangGraph path (PR4 + PR5)
    # ------------------------------------------------------------------

    def _make_langgraph_session_store(self):
        from ....agent.langgraph.session_store import LangGraphSessionStore

        return LangGraphSessionStore(save_dir=self._session.save_dir)

    def _get_chat_name(self, msgs) -> str:
        name = "New Chat"
        if msgs:
            content = msgs[0].get_text_content()
            if content:
                name = content[:10]
            else:
                name = "Media Message"
        return name

    async def _get_or_create_chat(
        self,
        *,
        msgs,
        session_id: str | None,
        user_id: str | None,
        channel: str,
    ) -> Any | None:
        if self._chat_manager is None:
            return None
        return await self._chat_manager.get_or_create_chat(
            session_id,
            user_id,
            channel,
            name=self._get_chat_name(msgs),
        )

    async def create_command_context(
        self,
        *,
        msgs,
        request: Any,
    ) -> LangGraphSessionContext:
        """Build the minimal context required for pure slash commands."""
        from ....agent.langgraph.middleware import LightClawMiddleware

        session_id = request.session_id
        user_id = request.user_id
        channel = getattr(request, "channel", DEFAULT_CHANNEL)

        session_store = self._make_langgraph_session_store()
        history_messages, compressed_summary = await session_store.aload(
            session_id=session_id,
            user_id=user_id,
        )

        middleware = LightClawMiddleware(
            working_dir=WORKING_DIR,
            memory_manager=self._memory_manager,
            compressed_summary=compressed_summary,
            channel=channel,
            session_id=session_id or "",
        )

        chat = await self._get_or_create_chat(
            msgs=msgs,
            session_id=session_id,
            user_id=user_id,
            channel=channel,
        )

        return LangGraphSessionContext(
            session_id=session_id,
            user_id=user_id,
            channel=channel,
            env_context="",
            graph=None,
            config=None,
            chat=chat,
            history_messages=history_messages,
            middleware=middleware,
            session_store=session_store,
            compressed_summary=compressed_summary,
        )

    async def create_langgraph_context(
        self,
        *,
        msgs,
        request: Any,
        mcp_clients: list[Any],
    ) -> LangGraphSessionContext:
        """Build a ``LangGraphSessionContext`` — the new three-stage path.

        Stage 1 (this method): assemble model + tools + prompt + history
        and build the compiled graph.  No LightClawAgent is created.

        PR5: Also loads session history, creates middleware, and wires
        up the session store for persistence.
        """
        from ....agent.langgraph import (
            LightClawGraphConfig,
            build_lightclaw_graph,
        )
        from ....agent.langgraph.middleware import LightClawMiddleware
        from ....agent.langgraph.model_factory import create_chat_model
        from ....agent.langgraph.tools import (
            create_memory_forget_langchain_tool,
            create_memory_search_langchain_tool,
            load_active_skills_as_tools,
            load_builtin_tools,
            mcp_clients_to_langchain_tools,
        )
        from ....agent.model_routing import format_route_log, route_model_for_request
        from ....agent.prompt import build_system_prompt_from_working_dir

        session_id = request.session_id
        user_id = request.user_id
        channel = getattr(request, "channel", DEFAULT_CHANNEL)

        env_context = build_env_context(
            session_id=session_id,
            user_id=user_id,
            channel=channel,
            working_dir=str(WORKING_DIR),
        )

        app_config = load_config()
        max_iters = app_config.agents.running.max_iters
        max_input_length = app_config.agents.running.max_input_length

        # ── Model ──
        route_decision = route_model_for_request(
            msgs=msgs,
            providers_data=app_config.models,
        )
        selected = route_decision.selected
        if selected is not None:
            # Prefer non-Ollama models for LangGraph agents that rely on tools,
            # because most Ollama models (e.g. gemma:2b) do not support
            # OpenAI-style tool calling and will fail with
            # "does not support tools".
            if selected.provider_id == "ollama":
                fallback = next(
                    (c for c in route_decision.candidates if c.provider_id != "ollama"),
                    None,
                )
                if fallback is not None:
                    logger.info(
                        "auto-route: selected ollama/%s for tools-based agent; falling back to %s/%s",
                        selected.model,
                        fallback.provider_id,
                        fallback.model,
                    )
                    selected = fallback
            logger.info(format_route_log(route_decision))
        else:
            logger.warning("auto-route: no configured candidates; will use default model from providers config")

        model = create_chat_model(selected)

        # ── Daily talk memory (global files, lazy rollover) ──
        daily_talk_store = DailyTalkStore(working_dir=WORKING_DIR)
        try:
            await daily_talk_store.maybe_rollover(model=model)
        except Exception:
            logger.exception("DAILY_TALK rollover failed")
        talk_memory_context = ""
        try:
            talk_memory_context = await daily_talk_store.build_prompt_context()
        except Exception:
            logger.exception("Failed to build DAILY_TALK/TALK_SUMMARY prompt context")

        # ── Tools ──
        tools: list = load_builtin_tools()
        tools.extend(load_active_skills_as_tools())

        # MCP tools
        if mcp_clients:
            try:
                mcp_tools = await mcp_clients_to_langchain_tools(mcp_clients)
                tools.extend(mcp_tools)
                logger.info("Registered %d MCP tools for LangGraph", len(mcp_tools))
            except Exception:
                logger.exception("Failed to convert MCP tools for LangGraph")

        # memory_search tool
        enable_mm = os.getenv("ENABLE_MEMORY_MANAGER", "").lower() != "false"

        # Pre-create FactStore for tool integration (actual fact system
        # initialization happens later; this just opens the DB).
        from ....agent.memory.fact_store import FactStore
        from ....constant import FACT_EXTRACTION_ENABLED, MEMORY_DIR

        _fact_store_for_tools: FactStore | None = None
        if FACT_EXTRACTION_ENABLED and enable_mm:
            try:
                _fact_store_for_tools = FactStore(db_dir=MEMORY_DIR)
                await _fact_store_for_tools.start()
            except Exception:
                logger.exception("Failed to pre-create FactStore for tools")
                _fact_store_for_tools = None

        if enable_mm and self._memory_manager is not None:
            # Wire LangChain model into MemoryManager so it uses
            # ChatModel.ainvoke() instead of AgentScope ReActAgent.
            self._memory_manager.langchain_chat_model = model
            tools.append(
                create_memory_search_langchain_tool(
                    self._memory_manager,
                    fact_store=_fact_store_for_tools,
                ),
            )
            # memory_forget tool — allow agent to delete/correct memories
            tools.append(
                create_memory_forget_langchain_tool(
                    self._memory_manager,
                    fact_store=_fact_store_for_tools,
                ),
            )

            # retrieve_compressed tool — allow agent to recall original
            # messages that were replaced by a summary during compaction.
            try:
                from ....agent.langgraph.tools.retrieve_compressed import (
                    create_retrieve_compressed_tool,
                )
                from ....agent.memory.message_store import SqliteMessageStore

                _msg_store = SqliteMessageStore(db_dir=MEMORY_DIR)
                await _msg_store.start()
                tools.append(create_retrieve_compressed_tool(_msg_store))
                logger.info("Registered retrieve_compressed_messages tool")
            except Exception:
                logger.exception("Failed to register retrieve_compressed_messages tool")

        # ── System prompt ──
        sys_prompt = build_system_prompt_from_working_dir()
        if env_context:
            sys_prompt = env_context + "\n\n" + sys_prompt
        if talk_memory_context:
            sys_prompt = (
                sys_prompt
                + "\n\n"
                + talk_memory_context
                + "\n\n"
                + _build_memory_usage_policy(app_config.agents.language)
            )

        # 语音对话渠道：将调用方传入的 voice_system_prompt_addon 追加到系统提示末尾。
        # addon 由 VoiceAgentBridge 生成，包含简短口语、禁 Markdown 等语音规则。
        if channel == "video_chat":
            voice_addon = getattr(request, "voice_system_prompt_addon", None)
            if voice_addon:
                sys_prompt = sys_prompt + "\n\n" + voice_addon

        # ── Session store & load history (PR5) ──
        session_store = self._make_langgraph_session_store()
        history_messages, compressed_summary = await session_store.aload(
            session_id=session_id,
            user_id=user_id,
        )

        # ── Middleware (PR5) ──
        memory_compact_threshold = int(max_input_length * MEMORY_COMPACT_RATIO)

        # Load fine-grained compaction config from lightclaw.json
        from ....agent.memory.compaction_config import load_compaction_config

        compaction_config = load_compaction_config(app_config)

        # ── Structured fact system (Mem0-style) ──
        from ....agent.memory.fact_extractor import FactExtractor
        from ....agent.memory.fact_injector import FactInjector

        fact_injector = None
        fact_extractor = None
        if FACT_EXTRACTION_ENABLED and enable_mm and _fact_store_for_tools is not None:
            try:
                # Reuse the FactStore already opened for tool registration.
                fact_store = _fact_store_for_tools

                # Reuse the embedding_fn from the memory manager if available
                embedding_fn = None
                if self._memory_manager is not None:
                    embedding_fn = getattr(self._memory_manager, "_embedding_fn", None)

                fact_injector = FactInjector(
                    fact_store=fact_store,
                    embedding_fn=embedding_fn,
                )
                fact_extractor = FactExtractor(
                    fact_store=fact_store,
                    embedding_fn=embedding_fn,
                )

                # Wire the LLM invocation function into the extractor.
                # Uses the same chat model as the agent, called with
                # a system+user prompt pair.
                async def _invoke_llm_for_facts(system_prompt: str, user_prompt: str) -> str:
                    from langchain_core.messages import HumanMessage as HM
                    from langchain_core.messages import SystemMessage as SM

                    resp = await model.ainvoke([SM(content=system_prompt), HM(content=user_prompt)])
                    return resp.content if isinstance(resp.content, str) else str(resp.content)

                fact_extractor.set_invoke_llm(_invoke_llm_for_facts)
                logger.info("Structured fact system initialized (store + extractor + injector)")
            except Exception:
                logger.exception("Failed to initialize structured fact system, continuing without it")
                fact_injector = None
                fact_extractor = None

        middleware = LightClawMiddleware(
            working_dir=WORKING_DIR,
            language=app_config.agents.language,
            memory_manager=(self._memory_manager if enable_mm else None),
            memory_compact_threshold=memory_compact_threshold,
            max_input_length=max_input_length,
            keep_recent=MEMORY_COMPACT_KEEP_RECENT,
            compressed_summary=compressed_summary,
            channel=channel,
            session_id=session_id or "",
            compaction_config=compaction_config,
            fact_injector=fact_injector,
        )

        # ── Build graph ──
        graph_config = LightClawGraphConfig(
            model=model,
            tools=tools,
            system_prompt=sys_prompt,
            max_iterations=max_iters,
            middleware=middleware,
        )
        graph = build_lightclaw_graph(graph_config)

        # ── Chat object ──
        chat = await self._get_or_create_chat(
            msgs=msgs,
            session_id=session_id,
            user_id=user_id,
            channel=channel,
        )

        return LangGraphSessionContext(
            session_id=session_id,
            user_id=user_id,
            channel=channel,
            env_context=env_context,
            graph=graph,
            config=graph_config,
            chat=chat,
            history_messages=history_messages,
            middleware=middleware,
            session_store=session_store,
            compressed_summary=compressed_summary,
            fact_extractor=fact_extractor,
            fact_store=_fact_store_for_tools,
        )

    # ------------------------------------------------------------------
    # Shared helpers
    # ------------------------------------------------------------------

    async def save_langgraph_session_state(
        self,
        context: LangGraphSessionContext,
        final_messages: list | None = None,
    ) -> None:
        """Persist LangGraph session state after a run completes (PR5)."""
        if context.session_store is None or context.session_id is None:
            return

        if self._chat_manager is not None and context.chat is not None and getattr(context.chat, "id", None):
            existing_chat = await self._chat_manager.get_chat(context.chat.id)
            if existing_chat is None:
                logger.debug(
                    "Skipping LangGraph session save for deleted chat %s",
                    context.chat.id,
                )
                return

        messages_to_save = final_messages or context.history_messages
        compressed_summary = context.middleware.compressed_summary if context.middleware else context.compressed_summary

        if not messages_to_save and not compressed_summary:
            logger.debug(
                "Skipping LangGraph session save for %s: no messages or summary",
                context.session_id,
            )
            return

        await context.session_store.asave(
            session_id=context.session_id,
            user_id=context.user_id,
            messages=messages_to_save,
            compressed_summary=compressed_summary,
        )

    async def update_chat(self, chat: Any | None) -> None:
        """Persist chat metadata if a chat object exists."""
        if self._chat_manager is None or chat is None:
            return
        await self._chat_manager.update_chat(chat)
