"""Compatibility shim for runner models."""

from .core.models import *  # noqa: F403
