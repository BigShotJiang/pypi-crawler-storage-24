"""AgentRunnerAdapter — 将 finnie 的 AgentRunner 适配为 AgentExecutor 接口。

这是一个轻量级适配器（Adapter Pattern），让各类 Channel
能够直接驱动 finnie 的 AgentRunner，而无需修改 AgentRunner 本身的任何代码。
"""

from __future__ import annotations

import logging
import uuid
from abc import ABC, abstractmethod
from collections.abc import AsyncGenerator
from typing import Any

from langchain_core.messages import AnyMessage
from langchain_core.runnables.config import RunnableConfig

from ..turn_protocol import TurnInput, TurnRequest
from .core.runner import AgentRunner

logger = logging.getLogger(__name__)


class AgentExecutor(ABC):
    """AgentExecutor 抽象接口。"""

    @abstractmethod
    async def call(
        self,
        messages: list[AnyMessage],
        thread_id: str | None = None,
        user: str | None = None,
        tags: list[str] | None = None,
        config: RunnableConfig | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]: ...

    @abstractmethod
    async def stream(
        self,
        messages: list[AnyMessage],
        thread_id: str | None = None,
        user: str | None = None,
        tags: list[str] | None = None,
        config: RunnableConfig | None = None,
        **kwargs: Any,
    ) -> AsyncGenerator[dict[str, Any], None]: ...

    @abstractmethod
    async def stream_content(
        self,
        messages: list[AnyMessage],
        thread_id: str | None = None,
        user: str | None = None,
        tags: list[str] | None = None,
        config: RunnableConfig | None = None,
        include_tool_result: bool = True,
        **kwargs: Any,
    ) -> AsyncGenerator[str, None]: ...


def _messages_to_turn_request(
    messages: list[AnyMessage],
    thread_id: str | None = None,
    user: str | None = None,
) -> TurnRequest:
    """将 LangChain AnyMessage 列表转换为 finnie TurnRequest。

    只取最后一条 human/user 消息作为本轮输入，其余历史消息由 finnie 的
    SafeSession（基于 thread_id）自行管理，避免重复注入历史。

    Args:
        messages: LangChain 消息列表。
        thread_id: 会话 ID，映射到 finnie 的 session_id。
        user: 用户 ID，映射到 finnie 的 user_id。

    Returns:
        TurnRequest 实例。
    """
    last_msg = messages[-1] if messages else None
    if last_msg is not None:
        content = getattr(last_msg, "content", "")
        if isinstance(content, list):
            text_parts = [item.get("text", "") if isinstance(item, dict) else str(item) for item in content]
            content = "".join(text_parts)
        turn_input = TurnInput(role="user", content=str(content))
    else:
        turn_input = TurnInput(role="user", content="")

    return TurnRequest(
        turn_id=str(uuid.uuid4()),
        inputs=[turn_input],
        session_id=thread_id or str(uuid.uuid4()),
        user_id=user or "",
        channel="finnie",
    )


class AgentRunnerAdapter(AgentExecutor):
    """将 finnie AgentRunner 适配为 AgentExecutor 接口。

    主要使用 stream_content() 方法，它直接复用 AgentRunner.stream_content()
    产出纯文本片段，无需解析 TurnEvent。
    """

    def __init__(self, runner: AgentRunner) -> None:
        self._runner = runner

    async def call(
        self,
        messages: list[AnyMessage],
        thread_id: str | None = None,
        user: str | None = None,
        tags: list[str] | None = None,
        config: RunnableConfig | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """非流式调用：收集所有文本片段后一次性返回。"""
        request = _messages_to_turn_request(messages, thread_id, user)
        chunks: list[str] = []
        async for chunk in self._runner.stream_content(request):
            chunks.append(chunk)
        return {"content": "".join(chunks), "role": "assistant"}

    async def stream(
        self,
        messages: list[AnyMessage],
        thread_id: str | None = None,
        user: str | None = None,
        tags: list[str] | None = None,
        config: RunnableConfig | None = None,
        **kwargs: Any,
    ) -> AsyncGenerator[dict[str, Any], None]:
        """流式调用：将 AgentRunner.stream_content() 包装为 dict 事件流。"""
        request = _messages_to_turn_request(messages, thread_id, user)
        async for chunk in self._runner.stream_content(request):
            yield {"content": chunk, "role": "assistant", "finished": False}
        yield {"content": "", "role": "assistant", "finished": True}

    async def stream_content(
        self,
        messages: list[AnyMessage],
        thread_id: str | None = None,
        user: str | None = None,
        tags: list[str] | None = None,
        config: RunnableConfig | None = None,
        include_tool_result: bool = True,
        **kwargs: Any,
    ) -> AsyncGenerator[str, None]:
        """直接产出纯文本片段，供各 Channel 使用。"""
        request = _messages_to_turn_request(messages, thread_id, user)
        async for chunk in self._runner.stream_content(
            request,
            include_tool_details=include_tool_result,
        ):
            yield chunk
