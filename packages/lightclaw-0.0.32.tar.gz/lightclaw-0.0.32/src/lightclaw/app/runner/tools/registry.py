"""Tool registry abstraction for LightClaw agent runs.

Stage A scope: provide a thin layer that centralises how MCP clients and
other tool capabilities are wired into the agent, without changing the
underlying behaviour.

PR4 additions:
* ``get_langchain_mcp_tools`` — returns MCP tools in LangChain format
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)


class ToolRegistry:
    """Registry and wiring layer for tools / skills / MCP clients.

    For now this focuses on MCP client integration, matching existing
    behaviour in ``AgentRunner``. The class is intentionally small so it
    can evolve into a more complete abstraction in later phases.
    """

    def __init__(self, mcp_manager: Any | None = None) -> None:
        self._mcp_manager = mcp_manager

    async def get_mcp_clients(self) -> list[Any]:
        """Return the current list of MCP clients from the manager."""
        if self._mcp_manager is None:
            return []
        try:
            return await self._mcp_manager.get_clients()
        except Exception as exc:  # pragma: no cover - defensive logging
            logger.exception("Failed to get MCP clients: %s", exc)
            return []

    async def register_agent_tools(self, agent: Any) -> None:
        """Register tools / MCP clients on the given agent instance.

        Current behaviour mirrors the existing call to
        ``agent.register_mcp_clients``.

        Note: ``agent`` is a ``LightClawAgent`` but the type annotation is
        kept as ``Any`` so the module does not need a top-level import of
        ``react_agent`` (which pulls in agentscope).
        """
        await agent.register_mcp_clients()

    async def get_langchain_mcp_tools(self) -> list:
        """Return MCP tools as LangChain-compatible ``BaseTool`` objects.

        Iterates MCP clients, converts each tool to LangChain StructuredTool
        via the MCP adapter in ``agents.langgraph.tools.mcp``.
        """
        from ...agent.langgraph.tools.mcp import mcp_clients_to_langchain_tools

        clients = await self.get_mcp_clients()
        if not clients:
            return []
        return await mcp_clients_to_langchain_tools(clients)
