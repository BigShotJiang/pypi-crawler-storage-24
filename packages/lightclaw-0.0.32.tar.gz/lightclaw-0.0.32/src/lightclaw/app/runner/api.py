"""Chat management API."""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException, Query, Request

from ...agent.langgraph.boundary_adapters.turn_protocol import (
    langchain_messages_to_turn_history_entries,
)
from ...agent.langgraph.message_converter import langchain_to_msgs
from ...agent.langgraph.session_store import LangGraphSessionStore
from ...config import load_config
from ..file_store import refresh_message_file_urls
from ..schemas import Message
from ..turn_protocol import TurnHistory
from .core.models import (
    ChatHistory,
    ChatSpec,
)
from .manager import ChatManager

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/chats", tags=["chats"])


async def _clear_session_artifacts(
    session: Any,
    *,
    session_id: str,
    user_id: str | None,
) -> None:
    """Remove all persisted artifacts for a chat session."""
    clear_files = getattr(session, "clear_session_files", None)
    if callable(clear_files):
        await asyncio.to_thread(clear_files, session_id, user_id)
        return

    save_dir = getattr(session, "save_dir", None)
    if save_dir:
        store = LangGraphSessionStore(save_dir=save_dir)
        await store.aclear(session_id=session_id, user_id=user_id)


def _load_langgraph_history(path: str) -> list[Message]:
    """Compatibility helper for reading a LangGraph session file."""
    try:
        with open(path, encoding="utf-8") as file:
            payload = json.load(file)
    except Exception:
        logger.exception("Failed to load LangGraph history from %s", path)
        return []

    raw_messages = payload.get("messages", [])
    try:
        from langchain_core.messages import messages_from_dict

        messages = messages_from_dict(raw_messages)
    except Exception:
        logger.exception("Failed to deserialize LangGraph history from %s", path)
        return []

    converted = langchain_to_msgs(messages)
    refresh_message_file_urls(converted)
    return converted


def _show_tool_details_enabled() -> bool:
    try:
        config = load_config()
        return bool(getattr(config, "show_tool_details", True))
    except Exception:
        logger.exception("Failed to load config for tool visibility check")
        return True


def _filter_tool_blocks(content: Any) -> list[Any]:
    """Remove tool-related blocks while preserving all other message fields."""
    if not isinstance(content, list):
        return []

    kept_blocks: list[Any] = []
    for block in content:
        if not isinstance(block, dict):
            kept_blocks.append(block)
            continue

        btype = block.get("type")
        if btype in ("tool_use", "tool_result"):
            continue
        if btype == "data":
            data = block.get("data")
            if isinstance(data, dict) and ("arguments" in data or "output" in data):
                continue
        kept_blocks.append(block)

    return kept_blocks


def _filter_tool_messages(messages: list[Any]) -> list[Any]:
    """Hide all tool messages/blocks when show_tool_details is False."""
    if _show_tool_details_enabled():
        return messages

    filtered: list[Any] = []
    for msg in messages:
        if isinstance(msg, Message):
            if msg.role == "tool":
                continue

            kept_blocks = _filter_tool_blocks(msg.content)
            if not kept_blocks and isinstance(msg.content, list):
                continue

            filtered.append(msg.model_copy(update={"content": kept_blocks or msg.content}))
            continue

        if not isinstance(msg, dict):
            filtered.append(msg)
            continue

        role = msg.get("role")
        if role == "tool":
            continue

        content = msg.get("content")
        if not isinstance(content, list):
            filtered.append(msg)
            continue

        kept_blocks = _filter_tool_blocks(content)
        if not kept_blocks:
            continue

        new_msg = dict(msg)
        new_msg["content"] = kept_blocks
        filtered.append(new_msg)

    return filtered


def get_chat_manager(request: Request) -> ChatManager:
    """Get the chat manager from app state.

    Args:
        request: FastAPI request object

    Returns:
        ChatManager instance

    Raises:
        HTTPException: If manager is not initialized
    """
    mgr = getattr(request.app.state, "chat_manager", None)
    if mgr is None:
        raise HTTPException(
            status_code=503,
            detail="Chat manager not initialized",
        )
    return mgr


def get_session(request: Request) -> Any:
    """Get the session from app state.

    Args:
        request: FastAPI request object

    Returns:
        Session persistence instance

    Raises:
        HTTPException: If session is not initialized
    """
    runner = getattr(request.app.state, "runner", None)
    if runner is None:
        raise HTTPException(
            status_code=503,
            detail="Session not initialized",
        )
    return runner.session


async def _get_chat_spec_or_404(chat_id: str, mgr: ChatManager) -> ChatSpec:
    chat_spec = await mgr.get_chat(chat_id)
    if not chat_spec:
        raise HTTPException(
            status_code=404,
            detail=f"Chat not found: {chat_id}",
        )
    return chat_spec


def _sum_usage_from_langchain_messages(messages: list[Any]) -> dict[str, int] | None:
    """Sum usage_metadata across all AI messages in a LangChain message list."""
    total_input = 0
    total_output = 0
    total_tokens = 0
    found_any = False

    for msg in messages:
        usage = getattr(msg, "usage_metadata", None)
        if not usage or not isinstance(usage, dict):
            continue
        inp = usage.get("input_tokens") or 0
        out = usage.get("output_tokens") or 0
        tot = usage.get("total_tokens") or 0
        if inp or out or tot:
            found_any = True
            total_input += inp
            total_output += out
            total_tokens += tot

    if not found_any:
        return None

    return {
        "input_tokens": total_input,
        "output_tokens": total_output,
        "total_tokens": total_tokens,
    }


@router.get("", response_model=list[ChatSpec])
async def list_chats(
    user_id: str | None = Query(None, description="Filter by user ID"),
    channel: str | None = Query(None, description="Filter by channel"),
    mgr: ChatManager = Depends(get_chat_manager),
    session: Any = Depends(get_session),
):
    """List all chats with optional filters.

    For chats missing ``meta.total_usage``, back-fills token usage from
    the LangGraph session history so that the dashboard can display it.

    Args:
        user_id: Optional user ID to filter chats
        channel: Optional channel name to filter chats
        mgr: Chat manager dependency
        session: Session dependency (for session store access)
    """
    chats = await mgr.list_chats(user_id=user_id, channel=channel)

    # Back-fill token usage for chats that don't have it yet
    save_dir = getattr(session, "save_dir", None)
    if save_dir:
        store = LangGraphSessionStore(save_dir=save_dir)
        chats_to_update: list[ChatSpec] = []

        for chat in chats:
            if chat.meta.get("total_usage"):
                continue
            try:
                messages, _ = await store.aload(
                    session_id=chat.session_id,
                    user_id=chat.user_id,
                )
                if not messages:
                    continue
                usage = _sum_usage_from_langchain_messages(messages)
                if usage:
                    chat.meta["total_usage"] = usage
                    chats_to_update.append(chat)
            except Exception:
                logger.debug("Failed to back-fill usage for chat %s", chat.id)

        # Persist back-filled usage so we don't recalculate next time
        for chat in chats_to_update:
            try:
                await mgr.update_chat(chat)
            except Exception:
                logger.debug("Failed to persist back-filled usage for chat %s", chat.id)

    return chats


@router.post("", response_model=ChatSpec)
async def create_chat(
    request: ChatSpec,
    mgr: ChatManager = Depends(get_chat_manager),
):
    """Create a new chat.

    Server generates chat_id (UUID) automatically.

    Args:
        request: Chat creation request
        mgr: Chat manager dependency

    Returns:
        Created chat spec with UUID
    """
    chat_id = str(uuid4())
    spec = ChatSpec(
        id=chat_id,
        name=request.name,
        session_id=request.session_id,
        user_id=request.user_id,
        channel=request.channel,
        meta=request.meta,
    )
    return await mgr.create_chat(spec)


@router.post("/batch-delete", response_model=dict)
async def batch_delete_chats(
    chat_ids: list[str],
    mgr: ChatManager = Depends(get_chat_manager),
    session: Any = Depends(get_session),
):
    """Delete chats by chat IDs.

    Args:
        chat_ids: List of chat IDs
        mgr: Chat manager dependency
        session: Session dependency (for clearing session files)
    Returns:
        True if deleted, False if failed

    """
    # Collect chat specs before deletion so we know session_id / user_id
    specs = [await mgr.get_chat(cid) for cid in chat_ids]

    deleted = await mgr.delete_chats(chat_ids=chat_ids)

    # Clear session files for successfully deleted chats
    if deleted:
        for spec in specs:
            if spec is None:
                continue
            try:
                await _clear_session_artifacts(
                    session,
                    session_id=spec.session_id,
                    user_id=spec.user_id,
                )
            except Exception:  # pylint: disable=broad-except
                logger.exception("Failed to clear session file for chat %s", spec.id)

    return {"deleted": deleted}


@router.get("/{chat_id}", response_model=ChatHistory)
async def get_chat(
    chat_id: str,
    mgr: ChatManager = Depends(get_chat_manager),
    session: Any = Depends(get_session),
):
    """Get detailed information about a specific chat by UUID.

    Args:
        chat_id: Chat UUID
        mgr: Chat manager dependency
        session: Session dependency

    Returns:
        ChatHistory with messages

    Raises:
        HTTPException: If chat not found (404)
    """
    chat_spec = await _get_chat_spec_or_404(chat_id, mgr)

    save_dir = getattr(session, "save_dir", None)
    if save_dir:
        store = LangGraphSessionStore(save_dir=save_dir)
        messages, _ = await store.aload(
            session_id=chat_spec.session_id,
            user_id=chat_spec.user_id,
        )
        if messages:
            converted = langchain_to_msgs(messages)
            refresh_message_file_urls(converted)
            return ChatHistory(messages=_filter_tool_messages(converted))

        # 文件存在但无有效内容：返回空历史
        # pylint: disable=protected-access
        if store._get_path(chat_spec.session_id, chat_spec.user_id).exists():
            return ChatHistory(messages=[])

        legacy_load = getattr(session, "load_session_state", None)
        if callable(legacy_load):
            try:
                dummy_agent = type(
                    "_DummyAgent",
                    (),
                    {
                        "__init__": lambda self: setattr(self, "_state", {}),
                        "state_dict": lambda self: dict(getattr(self, "_state", {})),
                        "load_state_dict": lambda self, state: setattr(
                            self,
                            "_state",
                            dict(state or {}),
                        ),
                    },
                )()
                await legacy_load(
                    session_id=chat_spec.session_id,
                    user_id=chat_spec.user_id,
                    agent=dummy_agent,
                )
                content = dummy_agent.state_dict().get("memory", {}).get("content", [])
                if content:
                    converted = []
                    for item in content:
                        if not isinstance(item, list) or not item:
                            continue
                        message = item[0]
                        if isinstance(message, dict):
                            if isinstance(message.get("content"), str):
                                message = {
                                    **message,
                                    "content": [
                                        {
                                            "type": "text",
                                            "text": message.get("content", ""),
                                        }
                                    ],
                                }
                            converted.append(Message.model_validate(message))
                    if converted:
                        refresh_message_file_urls(converted)
                        return ChatHistory(messages=_filter_tool_messages(converted))
            except Exception:
                logger.exception("Failed to load legacy session history for %s", chat_id)

    return ChatHistory(messages=[])


@router.get("/{chat_id}/turns", response_model=TurnHistory)
async def get_chat_turns(
    chat_id: str,
    mgr: ChatManager = Depends(get_chat_manager),
    session: Any = Depends(get_session),
):
    """Get turn-native chat history from the LangGraph session store."""
    chat_spec = await _get_chat_spec_or_404(chat_id, mgr)

    save_dir = getattr(session, "save_dir", None)
    if save_dir:
        store = LangGraphSessionStore(save_dir=save_dir)
        messages, _ = await store.aload(
            session_id=chat_spec.session_id,
            user_id=chat_spec.user_id,
        )
        if messages:
            return TurnHistory(turns=langchain_messages_to_turn_history_entries(messages))

        # pylint: disable=protected-access
        if store._get_path(chat_spec.session_id, chat_spec.user_id).exists():
            return TurnHistory(turns=[])

    return TurnHistory(turns=[])


@router.put("/{chat_id}", response_model=ChatSpec)
async def update_chat(
    chat_id: str,
    spec: ChatSpec,
    mgr: ChatManager = Depends(get_chat_manager),
):
    """Update an existing chat.

    Args:
        chat_id: Chat UUID
        spec: Updated chat specification
        mgr: Chat manager dependency

    Returns:
        Updated chat spec

    Raises:
        HTTPException: If chat_id mismatch (400) or not found (404)
    """
    if spec.id != chat_id:
        raise HTTPException(
            status_code=400,
            detail="chat_id mismatch",
        )

    # Check if exists
    existing = await mgr.get_chat(chat_id)
    if not existing:
        raise HTTPException(
            status_code=404,
            detail=f"Chat not found: {chat_id}",
        )

    updated = await mgr.update_chat(spec)
    return updated


@router.delete("/{chat_id}", response_model=dict)
async def delete_chat(
    chat_id: str,
    mgr: ChatManager = Depends(get_chat_manager),
    session: Any = Depends(get_session),
):
    """Delete a chat by UUID, including its session state file.

    Args:
        chat_id: Chat UUID
        mgr: Chat manager dependency
        session: Session dependency (for clearing session files)

    Returns:
        True if deleted, False if failed

    Raises:
        HTTPException: If chat not found (404)
    """
    # Fetch spec before deletion to retrieve session_id / user_id
    spec = await mgr.get_chat(chat_id)
    if not spec:
        raise HTTPException(
            status_code=404,
            detail=f"Chat not found: {chat_id}",
        )

    deleted = await mgr.delete_chats(chat_ids=[chat_id])
    if not deleted:
        raise HTTPException(
            status_code=404,
            detail=f"Chat not found: {chat_id}",
        )

    # Clear the session state file
    try:
        await _clear_session_artifacts(
            session,
            session_id=spec.session_id,
            user_id=spec.user_id,
        )
    except Exception:  # pylint: disable=broad-except
        logger.exception("Failed to clear session file for chat %s", chat_id)

    return {"deleted": True}
