# pylint: disable=redefined-outer-name,unused-argument
import os

# Suppress transformers advisory warning ("PyTorch was not found …") before
# any transitive import pulls in the transformers package.
os.environ.setdefault("TRANSFORMERS_NO_ADVISORY_WARNINGS", "1")

from contextlib import asynccontextmanager, suppress
from pathlib import Path
from uuid import uuid4

from fastapi import APIRouter, Depends, FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles

from .. import __version__
from ..agent.skills_manager import ensure_skills_initialized
from ..config import (  # pylint: disable=no-name-in-module
    ConfigWatcher,
    load_config,
    update_last_dispatch,
)
from ..config.utils import get_chats_path, get_config_path, get_jobs_path
from ..constant import DOCS_ENABLED, LOG_LEVEL_ENV, migrate_to_workspace
from ..embedding.manager import EmbeddingManager
from ..envs import load_envs_into_environ
from ..utils.logging import setup_logger
from .channels import ChannelManager  # pylint: disable=no-name-in-module
from .channels.utils import make_process_from_runner
from .core.auth import require_auth
from .cron.manager import CronManager
from .cron.repo.json_repo import JsonJobRepository
from .env_watcher import EnvWatcher
from .mcp import MCPClientManager, MCPConfigWatcher  # MCP hot-reload support
from .routers import router as api_router
from .runner import AgentRunner
from .runner.manager import ChatManager
from .runner.repo.json_repo import JsonChatRepository
from .tasks import TaskInfo, TaskRegistry, TaskSource, TaskStatus, resolve_role
from .turn_protocol import TurnEventType, TurnRequest

# Apply log level on load so reload child process gets same level as CLI.
logger = setup_logger(os.environ.get(LOG_LEVEL_ENV, "info"))

# One-time migration: move *.md, skills/, memory/ etc. from BASE_DIR root
# into BASE_DIR/workspace/ (new layout introduced after initial release).
migrate_to_workspace()

# Load persisted env vars into os.environ at module import time
# so they are available before the lifespan starts.
load_envs_into_environ()

runner = AgentRunner()
cron_manager: CronManager | None = None


@asynccontextmanager
async def lifespan(app: FastAPI):  # pylint: disable=too-many-statements
    app.state.skills_initialized = False
    try:
        ensure_skills_initialized()
        app.state.skills_initialized = True
        logger.debug("Built-in skills initialized during app startup")
    except Exception:
        logger.exception("Failed to initialize built-in skills on startup")

    # --- embedding manager init (local model / custom / none) ---
    # MUST run BEFORE runner.start() so that EMBEDDING_* env vars are
    # available when init_memory_system() creates the embedding_fn.
    config = load_config()
    embedding_manager = EmbeddingManager()
    try:
        await embedding_manager.startup(config.embedding)
    except Exception:
        logger.exception("Failed to start embedding manager (non-fatal, continuing)")

    await runner.start()

    # --- MCP client manager init (independent module, hot-reloadable) ---
    mcp_manager = MCPClientManager()
    if hasattr(config, "mcp"):
        try:
            await mcp_manager.init_from_config(config.mcp)
            runner.set_mcp_manager(mcp_manager)
            logger.debug("MCP client manager initialized")
        except Exception:
            logger.exception("Failed to initialize MCP manager")

    # --- task registry (must be created before channels / cron) ---
    task_registry = TaskRegistry()

    # --- channel connector init/start (from lightclaw.json) ---
    channel_manager = ChannelManager.from_config(
        process=make_process_from_runner(runner, task_registry=task_registry),
        config=config,
        on_last_dispatch=update_last_dispatch,
    )
    await channel_manager.start_all()

    # --- chat manager init and connect to runner.session ---
    chat_repo = JsonChatRepository(get_chats_path())
    chat_manager = ChatManager(
        repo=chat_repo,
    )

    runner.set_chat_manager(chat_manager)

    # --- cron init/start ---
    global cron_manager
    repo = JsonJobRepository(get_jobs_path())
    cron_manager = CronManager(
        repo=repo,
        runner=runner,
        channel_manager=channel_manager,
        timezone="UTC",
        task_registry=task_registry,
    )
    await cron_manager.start()

    # --- config file watcher (auto-reload channels on lightclaw.json change) ---
    config_watcher = ConfigWatcher(channel_manager=channel_manager)
    await config_watcher.start()

    # --- workspace .env watcher (hot-reload environment variables) ---
    env_watcher = EnvWatcher()
    await env_watcher.start()

    # --- MCP config watcher (auto-reload MCP clients on change) ---
    mcp_watcher = None
    if hasattr(config, "mcp"):
        try:
            mcp_watcher = MCPConfigWatcher(
                mcp_manager=mcp_manager,
                config_loader=load_config,
                config_path=get_config_path(),
            )
            await mcp_watcher.start()
            logger.debug("MCP config watcher started")
        except Exception:
            logger.exception("Failed to start MCP watcher")

    # expose to endpoints
    app.state.runner = runner
    app.state.channel_manager = channel_manager
    app.state.cron_manager = cron_manager
    app.state.chat_manager = chat_manager
    app.state.config_watcher = config_watcher
    app.state.env_watcher = env_watcher
    app.state.mcp_manager = mcp_manager
    app.state.mcp_watcher = mcp_watcher
    app.state.embedding_manager = embedding_manager
    app.state.task_registry = task_registry

    # --- STT (faster-whisper) model is NOT pre-loaded at startup -----
    # The Whisper model will be lazily downloaded & loaded when the user
    # starts their first voice-chat session. This keeps startup fast and
    # avoids blocking on a ~145 MB download that only voice-chat needs.
    logger.info("STT model will be loaded on-demand (first voice session).")

    try:
        yield
    finally:
        # stop order: watchers -> cron -> channels -> mcp -> runner
        with suppress(Exception):
            await config_watcher.stop()
        with suppress(Exception):
            await env_watcher.stop()
        if mcp_watcher:
            with suppress(Exception):
                await mcp_watcher.stop()
        try:
            await cron_manager.stop()
        finally:
            await channel_manager.stop_all()
            if mcp_manager:
                with suppress(Exception):
                    await mcp_manager.close_all()
            await runner.stop()
            with suppress(Exception):
                await embedding_manager.shutdown()
            # 确保所有 Langfuse trace 数据在退出前发送
            with suppress(Exception):
                from .observability import flush_langfuse

                flush_langfuse()


app = FastAPI(
    lifespan=lifespan,
    docs_url="/docs" if DOCS_ENABLED else None,
    redoc_url="/redoc" if DOCS_ENABLED else None,
    openapi_url="/openapi.json" if DOCS_ENABLED else None,
)


# Dashboard static dir: env, or lightclaw package data (dashboard), or cwd.
_CONSOLE_STATIC_ENV = "LIGHTCLAW_CONSOLE_STATIC_DIR"


def _resolve_console_static_dir() -> str:
    if os.environ.get(_CONSOLE_STATIC_ENV):
        return os.environ[_CONSOLE_STATIC_ENV]
    # Shipped dist lives in lightclaw package as static data (not a Python pkg).
    pkg_dir = Path(__file__).resolve().parent.parent
    candidate = pkg_dir / "dashboard"
    if candidate.is_dir() and (candidate / "index.html").exists():
        return str(candidate)
    cwd = Path(os.getcwd())
    for subdir in ("dashboard/dist", "dashboard_dist"):
        candidate = cwd / subdir
        if candidate.is_dir() and (candidate / "index.html").exists():
            return str(candidate)
    return str(cwd / "dashboard" / "dist")


_CONSOLE_STATIC_DIR = _resolve_console_static_dir()
_CONSOLE_INDEX = Path(_CONSOLE_STATIC_DIR) / "index.html" if _CONSOLE_STATIC_DIR else None
logger.info(f"STATIC_DIR: {_CONSOLE_STATIC_DIR}")


@app.get("/")
def read_root():
    if _CONSOLE_INDEX and _CONSOLE_INDEX.exists():
        return FileResponse(_CONSOLE_INDEX)
    return {"message": "Hello World"}


@app.get("/api/version")
def get_version():
    """Return the current LightClaw version."""
    return {"version": __version__}


app.include_router(api_router, prefix="/api")

# ----- /api/agent/process SSE endpoint (TurnEvent v3) -----
agent_router = APIRouter()


@agent_router.post("/process")
async def agent_process(req: Request):
    """SSE endpoint that streams TurnEvent directly.

    Each event is serialized as ``data: {json}\\n\\n``.
    The wire protocol is v3 (TurnEvent format).

    Also feeds task lifecycle events into the TaskRegistry for the
    real-time Task Board.
    """
    body = await req.json()
    request = TurnRequest.model_validate(body)

    show_tool_details = True
    try:
        app_config = load_config()
        show_tool_details = bool(getattr(app_config, "show_tool_details", True))
    except Exception:  # pylint: disable=broad-except
        logger.warning("Failed to load config.show_tool_details for /api/agent/process")

    # 过滤工具事件的类型集合
    _tool_event_types = {TurnEventType.TOOL_STARTED, TurnEventType.TOOL_COMPLETED}

    # --- Task Board tracking ---
    task_registry: TaskRegistry = req.app.state.task_registry
    task_id = str(uuid4())
    # Extract a short description from the user's last input message
    description = ""
    if request.inputs:
        last_msg = request.inputs[-1]
        txt = last_msg.get_text_content() if hasattr(last_msg, "get_text_content") else str(last_msg.content)
        description = txt[:120]

    channel = getattr(request, "channel", "dashboard") or "dashboard"
    task_source = TaskSource.CHAT if channel == "dashboard" else TaskSource.CHANNEL
    agent_role, agent_name = resolve_role(
        description=description,
        source=task_source,
        task_id=task_id,
    )
    task_info = TaskInfo(
        id=task_id,
        source=task_source,
        session_id=request.session_id,
        user_id=request.user_id,
        channel=channel,
        status=TaskStatus.QUEUED,
        description=description,
        agent_name=agent_name,
        agent_role=agent_role,
    )

    async def sse_generator():
        await task_registry.register_task(task_info)
        final_status = TaskStatus.COMPLETED
        last_status: TaskStatus = task_info.status
        last_current_tool: str | None = task_info.current_tool

        async def update_task_status(
            *,
            status: TaskStatus | None = None,
            current_tool: str | None = None,
            update_current_tool: bool = False,
        ) -> None:
            """Patch TaskInfo.status/current_tool only when it actually changes."""
            nonlocal last_status, last_current_tool
            changes: dict[str, object] = {}

            if status is not None and status != last_status:
                changes["status"] = status
                last_status = status

            if update_current_tool and current_tool != last_current_tool:
                changes["current_tool"] = current_tool
                last_current_tool = current_tool

            if changes:
                await task_registry.update_task(task_id, **changes)

        try:
            async for turn_event in runner.stream_turns(request):
                # --- Task Board turn-status tracking (independent from show_tool_details) ---
                if turn_event.type == TurnEventType.TURN_STARTED:
                    await update_task_status(
                        status=TaskStatus.THINKING,
                        current_tool=None,
                        update_current_tool=True,
                    )
                elif turn_event.type == TurnEventType.ASSISTANT_DELTA:
                    # Model token streaming after thinking/tool result.
                    await update_task_status(
                        status=TaskStatus.STREAMING,
                        current_tool=None,
                        update_current_tool=(last_current_tool is not None),
                    )
                elif turn_event.type == TurnEventType.TOOL_STARTED:
                    data = turn_event.data or {}
                    tool_name = data.get("name") or data.get("tool_name") or None
                    await update_task_status(
                        status=TaskStatus.TOOL_CALLING,
                        current_tool=tool_name,
                        update_current_tool=True,
                    )
                elif turn_event.type == TurnEventType.TOOL_APPROVAL_REQUIRED:
                    # ToolGuard: paused and waiting for approval.
                    data = turn_event.data or {}
                    tool_name = data.get("tool_name") or None
                    await update_task_status(
                        status=TaskStatus.TOOL_CALLING,
                        current_tool=tool_name,
                        update_current_tool=True,
                    )
                elif turn_event.type == TurnEventType.TOOL_COMPLETED:
                    # Tool result comes back; next is usually assistant reasoning/streaming.
                    await update_task_status(
                        status=TaskStatus.THINKING,
                        current_tool=None,
                        update_current_tool=(last_current_tool is not None),
                    )
                elif turn_event.type == TurnEventType.TURN_FAILED:
                    # Ensure turn-level failure ends the Task as FAILED.
                    final_status = TaskStatus.FAILED
                    await update_task_status(
                        status=TaskStatus.FAILED,
                        current_tool=None,
                        update_current_tool=True,
                    )

                # 若 show_tool_details=False，跳过工具调用事件
                if not show_tool_details and turn_event.type in _tool_event_types:
                    continue
                yield f"data: {turn_event.model_dump_json(exclude_none=True)}\n\n"
            await task_registry.complete_task(task_id, final_status)
        except Exception:
            await task_registry.complete_task(task_id, TaskStatus.FAILED)
            raise

    return StreamingResponse(
        sse_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
            "X-Process-Protocol-Version": "v3",
        },
    )


app.include_router(
    agent_router,
    prefix="/api/agent",
    tags=["agent"],
    dependencies=[Depends(require_auth)],
)

# Mount dashboard: root static files (logo.png etc.) then assets, then SPA
# fallback.
if os.path.isdir(_CONSOLE_STATIC_DIR):
    _console_path = Path(_CONSOLE_STATIC_DIR)

    @app.get("/logo.png")
    def _console_logo():
        f = _console_path / "logo.png"
        if f.is_file():
            return FileResponse(f, media_type="image/png")

        raise HTTPException(status_code=404, detail="Not Found")

    @app.get("/logo.svg")
    def _console_logo_svg():
        f = _console_path / "logo.svg"
        if f.is_file():
            return FileResponse(f, media_type="image/svg+xml")

        raise HTTPException(status_code=404, detail="Not Found")

    @app.get("/lightclaw-symbol.svg")
    def _console_icon():
        f = _console_path / "lightclaw-symbol.svg"
        if f.is_file():
            return FileResponse(f, media_type="image/svg+xml")

        raise HTTPException(status_code=404, detail="Not Found")

    @app.get("/lightclaw-logo.png")
    def _console_lightclaw_logo():
        f = _console_path / "lightclaw-logo.png"
        if f.is_file():
            return FileResponse(f, media_type="image/png")

        raise HTTPException(status_code=404, detail="Not Found")

    @app.get("/lightclaw-symbol.png")
    def _console_lightclaw_symbol():
        f = _console_path / "lightclaw-symbol.png"
        if f.is_file():
            return FileResponse(f, media_type="image/png")

        raise HTTPException(status_code=404, detail="Not Found")

    class _CachedStaticFiles(StaticFiles):
        """StaticFiles with Cache-Control: no-cache — always revalidate via ETag."""

        async def get_response(self, path, scope):
            resp = await super().get_response(path, scope)
            resp.headers["Cache-Control"] = "no-cache"
            return resp

    _assets_dir = _console_path / "assets"
    if _assets_dir.is_dir():
        app.mount(
            "/assets",
            _CachedStaticFiles(directory=str(_assets_dir)),
            name="assets",
        )

    _models_dir = _console_path / "models"
    if _models_dir.is_dir():
        app.mount(
            "/models",
            _CachedStaticFiles(directory=str(_models_dir)),
            name="models",
        )

    _videos_dir = _console_path / "videos"
    if _videos_dir.is_dir():
        app.mount(
            "/videos",
            StaticFiles(directory=str(_videos_dir)),
            name="videos",
        )

    _gifs_dir = _console_path / "gifs"
    if _gifs_dir.is_dir():
        app.mount(
            "/gifs",
            _CachedStaticFiles(directory=str(_gifs_dir)),
            name="gifs",
        )

    @app.get("/{full_path:path}")
    def _console_spa(full_path: str):
        # Serve root-level static files (e.g. pcm-processor.js) before SPA fallback
        candidate = _console_path / full_path
        if candidate.is_file() and ".." not in full_path and not full_path.startswith("/"):
            import mimetypes

            mt, _ = mimetypes.guess_type(str(candidate))
            return FileResponse(candidate, media_type=mt or "application/octet-stream")

        if _CONSOLE_INDEX and _CONSOLE_INDEX.exists():
            return FileResponse(_CONSOLE_INDEX)

        raise HTTPException(status_code=404, detail="Not Found")
