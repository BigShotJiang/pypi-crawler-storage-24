"""STT service using faster-whisper.

Requires:  faster-whisper>=1.1.0  (included in main dependencies)

Design
------
* The Whisper model is a process-level singleton (_WhisperModelSingleton).
  It is loaded once at first use and shared across all concurrent sessions,
  avoiding duplicate ~244MB memory footprints per connection.

* Each WebSocket session creates its own STTService instance which holds
  only the lightweight per-session VAD state (audio buffer, silence counter).
  The heavy model lives in the singleton.

* Audio chunks arrive as base64-encoded Int16 PCM at 16 kHz.
* A circular buffer accumulates chunks; simple energy-based VAD determines
  speech end (≥1.0 s of silence after speech).
* When speech end is detected the buffer is transcribed and cleared.
* Uses initial_prompt to guide Whisper to output simplified Chinese.
"""

from __future__ import annotations

import asyncio
import logging
import re as _re
import threading
import time
from collections.abc import AsyncGenerator

import numpy as np

from .audio_utils import base64_to_float32

logger = logging.getLogger(__name__)

# VAD parameters
_SAMPLE_RATE = 16000
_SILENCE_THRESHOLD = 0.008  # RMS below this = silence (raised to filter environmental noise)
_MIN_SPEECH_FRAMES = int(0.3 * _SAMPLE_RATE)  # 0.3 s minimum speech before triggering
_SILENCE_FRAMES_NEEDED = int(0.4 * _SAMPLE_RATE)  # 0.4 s silence → end of speech
# Minimum RMS energy of the entire audio buffer before sending to Whisper.
# If the overall energy is below this, it's likely just noise — skip transcription.
_MIN_AUDIO_RMS = 0.006

# Whisper initial_prompt: guide the model to output simplified Chinese
# This is a well-known trick — Whisper conditions on the prompt style.
_ZH_INITIAL_PROMPT = "以下是普通话的句子。"

# ── Whisper hallucination filter ─────────────────────────────────────────────
# Whisper is known to hallucinate fixed phrases when the input audio is
# mostly silence or background noise. These come from its training data
# (YouTube subtitles, podcast intros, etc.).
#
# Strategy: match WHOLE SENTENCES, not keywords, to avoid false positives.
# e.g. user asking "怎么打赏主播" should NOT be filtered.
# We only filter when the entire transcription is a known hallucination pattern.

# Full-sentence hallucination patterns (regex).
# Each pattern must match the ENTIRE transcription (anchored with ^ and $).
_HALLUCINATION_PATTERNS = [
    # YouTube/podcast outro hallucinations
    _re.compile(r"^.*请不吝点赞.*订阅.*转发.*$"),
    _re.compile(r"^.*点赞.*订阅.*转发.*$"),
    _re.compile(r"^.*点赞.*转发.*打赏.*$"),
    _re.compile(r"^.*订阅.*转发.*打赏.*$"),
    _re.compile(r"^.*打赏.*打赏.*$"),  # repeated 打赏
    _re.compile(r"^.*支持明镜.*点点栏目.*$"),
    _re.compile(r"^(感谢|谢谢)(观看|收看|收听).*$"),
    _re.compile(r"^欢迎(收看|订阅|关注).*$"),
    _re.compile(r"^(我们)?下(集|期)再见[。！]?$"),
    _re.compile(r"^字幕(由|组|制作).*$"),
    # Subtitle credit hallucinations
    _re.compile(r"^.*字幕(由|组).*提供.*$"),
    _re.compile(r"^.*翻译.*字幕.*$"),
    # Generic filler that Whisper produces on near-silence
    _re.compile(r"^[。，、！？\s]+$"),
    # Bilibili / Chinese video platform hallucinations
    _re.compile(r"^.*请(关注|订阅).*频道.*$"),
    _re.compile(r"^.*一键三连.*$"),
    _re.compile(r"^.*点赞.*关注.*$"),
    _re.compile(r"^.*点赞.*订阅.*$"),  # 点赞+订阅 combo
    _re.compile(r"^.*投币.*收藏.*$"),
    # Podcast / audiobook ending hallucinations
    _re.compile(r"^.*谢谢.*聆听.*$"),
    _re.compile(r"^.*本(期|集)(节目|内容).*$"),
    _re.compile(r"^.*播(客|出).*结束.*$"),
    # Subtitle / translation credit patterns
    _re.compile(r"^.*由.*字幕.*$"),
    _re.compile(r"^.*CC字幕.*$"),
    _re.compile(r"^.*Amara\.org.*$"),
    _re.compile(r"^.*字幕.*志愿.*$"),
    # English hallucination patterns (Whisper sometimes switches to English)
    _re.compile(r"^[Tt]hank(s| you).*$"),
    _re.compile(r"^[Ss]ubscribe.*$"),
    _re.compile(r"^[Pp]lease (like|subscribe).*$"),
    _re.compile(r"^[Yy]ou$"),
    _re.compile(r"^[Bb]ye[.!]?$"),
    # Single character or very short meaningless output
    _re.compile(r"^.{1,2}$"),
]


def _is_hallucination(text: str) -> bool:
    """Return True if the transcribed text is likely a Whisper hallucination.

    Uses whole-sentence pattern matching to avoid false positives.
    A user saying "怎么打赏" or "帮我订阅" will NOT be filtered.
    Only stereotypical Whisper hallucination sentences are caught.
    """
    stripped = text.strip()
    if not stripped:
        return True

    # Check against full-sentence hallucination patterns
    for pattern in _HALLUCINATION_PATTERNS:
        if pattern.match(stripped):
            logger.info("STT hallucination filtered (pattern=%s): %r", pattern.pattern, stripped)
            return True

    # Detect repetitive output: if the text is just one short phrase repeated
    # e.g. "对对对对对对" or "嗯嗯嗯嗯嗯"
    if len(stripped) >= 6:
        for unit_len in range(1, 4):
            unit = stripped[:unit_len]
            if unit * (len(stripped) // unit_len) == stripped:
                logger.info("STT hallucination filtered (repetitive=%r): %r", unit, stripped)
                return True

    # Detect text that is mostly punctuation with minimal content
    content_chars = _re.sub(r"[\s。，、！？.,!?…~]+", "", stripped)
    if len(content_chars) <= 1 and len(stripped) > 1:
        logger.info("STT hallucination filtered (mostly punctuation): %r", stripped)
        return True

    return False


# Timeout for Whisper transcription (seconds) — prevents session freeze
# if the model hangs due to GPU issues or OOM.
_TRANSCRIBE_TIMEOUT = 30


# ── Global Whisper model singleton ────────────────────────────────────────────


class _WhisperModelSingleton:
    """Process-level singleton holding the loaded WhisperModel.

    Thread-safe: uses a threading.Lock for one-time initialisation.
    All concurrent STTService sessions share this single model instance,
    avoiding duplicate large memory allocations.
    """

    _instance: _WhisperModelSingleton | None = None
    _lock = threading.Lock()

    def __init__(
        self,
        model_size: str = "base",
        device: str = "cpu",
        language: str = "zh",
    ) -> None:
        self._model_size = model_size
        self._device = device
        self._language = language
        self._model = None
        self._model_lock = threading.RLock()  # serialises concurrent transcription calls (RLock to avoid self-deadlock)

    @classmethod
    def get(
        cls,
        model_size: str = "base",
        device: str = "cpu",
        language: str = "zh",
    ) -> _WhisperModelSingleton:
        """Return (creating if necessary) the singleton instance."""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls(model_size=model_size, device=device, language=language)
        return cls._instance

    @staticmethod
    def _is_model_cached(model_size: str) -> bool:
        """Check if the Whisper model is already cached locally."""
        try:
            from huggingface_hub import try_to_load_from_cache  # type: ignore

            # faster-whisper uses the ctranslate2-4you org on HF Hub
            repo_id = f"ctranslate2-4you/whisper-{model_size}-ct2"
            result = try_to_load_from_cache(repo_id, "model.bin")
            return result is not None
        except Exception:
            # If huggingface_hub is not available or check fails,
            # we can't determine cache status — assume not cached
            return False

    def load_model(self, timeout: float = 300) -> None:
        """Load the Whisper model if not already loaded (thread-safe).

        On first run, the model will be downloaded from Hugging Face Hub.
        This may take several minutes depending on network speed.

        Args:
            timeout: Maximum seconds to wait for the model lock.
                     Default 300s (5 min) to account for first-time download.
        """
        if self._model is not None:
            return
        acquired = self._model_lock.acquire(timeout=timeout)
        if not acquired:
            raise TimeoutError(
                f"Could not acquire model lock within {timeout}s — possible deadlock from a previous session."
            )
        try:
            if self._model is not None:
                return
            try:
                from faster_whisper import WhisperModel  # type: ignore

                is_cached = self._is_model_cached(self._model_size)

                if is_cached:
                    logger.info(
                        "Loading faster-whisper model '%s' on %s (cached) …",
                        self._model_size,
                        self._device,
                    )
                else:
                    import os

                    logger.info(
                        "⏳ Downloading faster-whisper model '%s' (first time only, this may take a few minutes) …",
                        self._model_size,
                    )
                    # Use China mirror (hf-mirror.com) for faster downloads
                    # if user hasn't set a custom HF_ENDPOINT already.
                    if not os.environ.get("HF_ENDPOINT"):
                        os.environ["HF_ENDPOINT"] = "https://hf-mirror.com"
                        logger.info("Using China mirror (hf-mirror.com) for model download.")

                t_start = time.monotonic()
                self._model = WhisperModel(
                    self._model_size,
                    device=self._device,
                    compute_type="int8",
                )
                elapsed = time.monotonic() - t_start
                logger.info(
                    "✅ faster-whisper model '%s' loaded in %.1fs (singleton).",
                    self._model_size,
                    elapsed,
                )
            except ImportError as exc:
                raise ImportError(
                    "faster-whisper is not installed. Run: uv sync  or  pip install faster-whisper"
                ) from exc
        finally:
            self._model_lock.release()

    def transcribe(self, audio: np.ndarray, language: str = "zh") -> tuple[str, float, float]:
        """Synchronous transcription; intended to be called from a thread pool.

        Uses a per-singleton lock so that concurrent sessions queue their
        transcription requests rather than running Whisper in parallel on the
        same model (which would cause OOM on CPU or GPU contention).

        Returns:
            Tuple of (text, audio_duration_ms, transcribe_ratio).
        """
        self.load_model()
        with self._model_lock:
            t_start = time.monotonic()
            audio_duration_ms = len(audio) / _SAMPLE_RATE * 1000
            segments, _ = self._model.transcribe(
                audio,
                language=language,
                beam_size=1,
                best_of=1,
                vad_filter=True,
                vad_parameters=dict(
                    min_silence_duration_ms=300,
                    speech_pad_ms=200,
                    threshold=0.35,
                ),
                initial_prompt=_ZH_INITIAL_PROMPT,
                no_speech_threshold=0.5,
                log_prob_threshold=-0.8,
                condition_on_previous_text=False,
            )
            # Collect segments and check no_speech_prob per segment
            parts = []
            high_noise_count = 0
            total_segments = 0
            for seg in segments:
                total_segments += 1
                if seg.no_speech_prob > 0.6:
                    high_noise_count += 1
                    logger.debug(
                        "STT segment skipped (no_speech_prob=%.2f): %r",
                        seg.no_speech_prob,
                        seg.text.strip(),
                    )
                    continue
                parts.append(seg.text.strip())
            text = "".join(parts).strip()
        elapsed_ms = (time.monotonic() - t_start) * 1000
        ratio = elapsed_ms / max(audio_duration_ms, 1)
        logger.info(
            "[PERF] STT transcribe: %.0fms (audio=%.0fms, ratio=%.1fx) segments=%d, skipped=%d → %r",
            elapsed_ms,
            audio_duration_ms,
            ratio,
            total_segments,
            high_noise_count,
            text,
        )
        return text, audio_duration_ms, ratio

    def release(self) -> None:
        """Explicitly release the Whisper model and free memory.

        Normally you should NOT call this — the singleton lives for the
        process lifetime. Only use it in tests or when shutting down cleanly.
        """
        with self._model_lock:
            if self._model is not None:
                del self._model
                self._model = None
                logger.info("faster-whisper model released.")
        _WhisperModelSingleton._instance = None


# ── Per-session STT service ───────────────────────────────────────────────────


class STTService:
    """Per-session STT using a shared faster-whisper model with simple energy VAD.

    Each session holds its own VAD state (audio buffer, silence counter) but
    delegates the expensive model inference to the process-level singleton.
    """

    def __init__(
        self,
        model_size: str = "base",
        device: str = "cpu",
        language: str = "zh",
    ) -> None:
        # Fail-fast: verify faster-whisper is importable at construction time
        # so that _init_stt() in video_chat.py can catch ImportError early.
        try:
            import faster_whisper  # noqa: F401  # type: ignore
        except ImportError as exc:
            raise ImportError("faster-whisper is not installed. Run: uv sync  or  pip install faster-whisper") from exc

        self._language = language
        # Grab (or create) the shared model singleton
        self._whisper = _WhisperModelSingleton.get(model_size=model_size, device=device, language=language)

        # Per-session VAD state (lightweight — no model weights here)
        self._chunks: list[np.ndarray] = []
        self._buffer_len = 0
        self._silence_count = 0
        self._has_speech = False

    def _load_model(self) -> None:
        """Pre-load the shared model (called from thread pool at session start)."""
        self._whisper.load_model()

    def _transcribe(self, audio: np.ndarray) -> tuple[str, float, float]:
        """Delegate transcription to the singleton (runs in thread pool).

        Returns:
            Tuple of (text, audio_duration_ms, transcribe_ratio).
        """
        return self._whisper.transcribe(audio, language=self._language)

    async def feed_audio_b64(self, b64_chunk: str, sample_rate: int = 16000) -> AsyncGenerator[str, None]:
        """
        Accept a base64 Int16 PCM chunk, run VAD, and yield text when
        a complete utterance is detected.
        """
        try:
            chunk = base64_to_float32(b64_chunk)
        except Exception as exc:
            logger.warning("Failed to decode audio chunk: %s", exc)
            return

        # Resample if needed
        if sample_rate != _SAMPLE_RATE:
            from .audio_utils import resample

            chunk = resample(chunk, sample_rate, _SAMPLE_RATE)

        self._chunks.append(chunk)
        self._buffer_len += len(chunk)

        # Energy VAD
        rms = float(np.sqrt(np.mean(chunk**2)))
        if rms >= _SILENCE_THRESHOLD:
            self._has_speech = True
            self._silence_count = 0
        else:
            if self._has_speech:
                self._silence_count += len(chunk)

        # Debug logging: log VAD state periodically
        if self._buffer_len % int(0.5 * _SAMPLE_RATE) == 0:  # Every 0.5 seconds
            logger.debug(
                "[VAD] buffer=%.1fs, has_speech=%s, silence=%.1fs, rms=%.6f, threshold=%.6f",
                self._buffer_len / _SAMPLE_RATE,
                self._has_speech,
                self._silence_count / _SAMPLE_RATE,
                rms,
                _SILENCE_THRESHOLD,
            )

        # Speech end detected
        if (
            self._has_speech
            and self._silence_count >= _SILENCE_FRAMES_NEEDED
            and self._buffer_len >= _MIN_SPEECH_FRAMES
        ):
            logger.info(
                "[PERF] VAD speech-end detected: buffer=%.1fs (%d samples), silence=%.1fs",
                self._buffer_len / _SAMPLE_RATE,
                self._buffer_len,
                self._silence_count / _SAMPLE_RATE,
            )
            # Concatenate all accumulated chunks at once (O(n) only once)
            audio_to_transcribe = np.concatenate(self._chunks)
            self._chunks = []
            self._buffer_len = 0
            self._has_speech = False
            self._silence_count = 0

            # Pre-check: if overall audio energy is too low, skip transcription
            audio_rms = float(np.sqrt(np.mean(audio_to_transcribe**2)))
            if audio_rms < _MIN_AUDIO_RMS:
                logger.info(
                    "[VAD] Audio buffer too quiet (rms=%.6f < %.6f), skipping transcription",
                    audio_rms,
                    _MIN_AUDIO_RMS,
                )
                return

            # Run blocking transcription in thread pool with timeout
            loop = asyncio.get_event_loop()
            try:
                text, audio_dur_ms, ratio = await asyncio.wait_for(
                    loop.run_in_executor(None, self._transcribe, audio_to_transcribe),
                    timeout=_TRANSCRIBE_TIMEOUT,
                )
            except TimeoutError:
                logger.error(
                    "Whisper transcription timed out after %ds for %d samples",
                    _TRANSCRIBE_TIMEOUT,
                    len(audio_to_transcribe),
                )
                return
            # Ratio-based hallucination guard: if transcription took >3x the
            # audio duration AND the audio was short (<2s), Whisper is almost
            # certainly hallucinating on noise.
            if ratio > 3.0 and audio_dur_ms < 2000:
                logger.info(
                    "STT hallucination filtered (high ratio=%.1fx, audio=%.0fms): %r",
                    ratio,
                    audio_dur_ms,
                    text,
                )
                return
            if text and not _is_hallucination(text):
                yield text

    def reset_buffer(self) -> None:
        """Discard all accumulated audio without transcribing.

        Call this when the AI starts speaking/thinking so that any audio
        captured during that period is silently dropped and does not trigger
        a spurious recognition after the AI finishes.
        """
        dropped = self._buffer_len
        self._chunks = []
        self._buffer_len = 0
        self._has_speech = False
        self._silence_count = 0
        if dropped > 0:
            logger.debug(
                "STT buffer reset: discarded %.1fs of audio (%d samples)",
                dropped / _SAMPLE_RATE,
                dropped,
            )

    async def flush(self) -> AsyncGenerator[str, None]:
        """Force-transcribe whatever remains in the buffer."""
        if self._has_speech and self._buffer_len >= _MIN_SPEECH_FRAMES:
            audio = np.concatenate(self._chunks)
            self._chunks = []
            self._buffer_len = 0
            self._has_speech = False
            self._silence_count = 0
            loop = asyncio.get_event_loop()
            try:
                text, audio_dur_ms, ratio = await asyncio.wait_for(
                    loop.run_in_executor(None, self._transcribe, audio),
                    timeout=_TRANSCRIBE_TIMEOUT,
                )
            except TimeoutError:
                logger.error(
                    "Whisper transcription timed out after %ds during flush",
                    _TRANSCRIBE_TIMEOUT,
                )
                return
            if ratio > 3.0 and audio_dur_ms < 2000:
                logger.info(
                    "STT hallucination filtered in flush (high ratio=%.1fx, audio=%.0fms): %r",
                    ratio,
                    audio_dur_ms,
                    text,
                )
                return
            if text and not _is_hallucination(text):
                yield text

    async def close(self) -> None:
        """Release per-session resources (VAD buffer).

        The shared Whisper model is NOT released here — it lives for the
        process lifetime. Only the lightweight per-session buffer is cleared.
        """
        self._chunks = []
        self._buffer_len = 0
        self._has_speech = False
        self._silence_count = 0
