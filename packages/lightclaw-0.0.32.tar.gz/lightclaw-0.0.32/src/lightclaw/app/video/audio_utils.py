"""Audio utility functions for the video chat pipeline."""

import base64
import io
import logging
import struct

import numpy as np

logger = logging.getLogger(__name__)


def pcm_int16_to_float32(data: bytes) -> np.ndarray:
    """Convert raw Int16 PCM bytes to float32 numpy array in [-1, 1]."""
    samples = np.frombuffer(data, dtype=np.int16).astype(np.float32)
    return samples / 32768.0


def float32_to_pcm_int16(data: np.ndarray) -> bytes:
    """Convert float32 array to Int16 PCM bytes."""
    clipped = np.clip(data, -1.0, 1.0)
    return (clipped * 32767).astype(np.int16).tobytes()


def base64_to_float32(b64: str) -> np.ndarray:
    """Decode a base64-encoded Int16 PCM chunk to float32 array."""
    try:
        raw = base64.b64decode(b64)
    except Exception as exc:
        logger.warning("base64 decode failed (len=%d): %s", len(b64), exc)
        raise
    if len(raw) == 0:
        logger.debug("base64_to_float32: empty audio chunk after decode")
    return pcm_int16_to_float32(raw)


def float32_to_wav_bytes(
    data: np.ndarray,
    sample_rate: int = 22050,
    num_channels: int = 1,
) -> bytes:
    """Encode a float32 numpy array as a WAV byte string."""
    pcm = float32_to_pcm_int16(data)
    buf = io.BytesIO()
    _write_wav_header(buf, num_channels, sample_rate, len(pcm))
    buf.write(pcm)
    return buf.getvalue()


def wav_bytes_to_base64(wav: bytes) -> str:
    return base64.b64encode(wav).decode()


def float32_to_wav_base64(
    data: np.ndarray,
    sample_rate: int = 22050,
) -> str:
    return wav_bytes_to_base64(float32_to_wav_bytes(data, sample_rate))


def resample(data: np.ndarray, orig_sr: int, target_sr: int) -> np.ndarray:
    """Simple linear resampling (for sample-rate conversion)."""
    if orig_sr == target_sr:
        return data
    ratio = target_sr / orig_sr
    new_length = int(len(data) * ratio)
    indices = np.linspace(0, len(data) - 1, new_length)
    return np.interp(indices, np.arange(len(data)), data).astype(np.float32)


# ── WAV header writer ─────────────────────────────────────────────────────────


def _write_wav_header(buf: io.BytesIO, channels: int, sample_rate: int, pcm_length: int) -> None:
    bits_per_sample = 16
    byte_rate = sample_rate * channels * bits_per_sample // 8
    block_align = channels * bits_per_sample // 8
    data_size = pcm_length  # already in bytes (Int16)
    chunk_size = 36 + data_size

    buf.write(b"RIFF")
    buf.write(struct.pack("<I", chunk_size))
    buf.write(b"WAVE")
    buf.write(b"fmt ")
    buf.write(struct.pack("<I", 16))  # subchunk1 size
    buf.write(struct.pack("<H", 1))  # PCM format
    buf.write(struct.pack("<H", channels))
    buf.write(struct.pack("<I", sample_rate))
    buf.write(struct.pack("<I", byte_rate))
    buf.write(struct.pack("<H", block_align))
    buf.write(struct.pack("<H", bits_per_sample))
    buf.write(b"data")
    buf.write(struct.pack("<I", data_size))
