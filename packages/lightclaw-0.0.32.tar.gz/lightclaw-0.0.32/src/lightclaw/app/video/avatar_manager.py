"""AI avatar manager — maps avatar_id to AvatarInfo with voice and personality."""

import logging

from .protocol import AvatarInfo

logger = logging.getLogger(__name__)


# ── Avatar registry ────────────────────────────────────────────────────────────

_AVATARS: dict[str, AvatarInfo] = {
    "jinx": AvatarInfo(
        id="jinx",
        name="锦锦",
        gender="female",
        image_url="",
        description="活泼开朗的女生助手，声音甜美清澈",
        voice_id="zh-CN-XiaoxiaoNeural",
        personality="你说话温柔自然，像一个耐心的朋友，语气平和亲切，偶尔带一点幽默感。",
    ),
}

# 默认角色（未指定或找不到时使用）
_DEFAULT_AVATAR_ID = "jinx"


def get_avatar(avatar_id: str | None = None) -> AvatarInfo:
    """Return AvatarInfo for the given avatar_id.

    Falls back to the default avatar if avatar_id is None or unknown.
    """
    key = avatar_id or _DEFAULT_AVATAR_ID
    avatar = _AVATARS.get(key)
    if avatar is None:
        logger.warning(
            "Unknown avatar_id=%r, falling back to default=%r",
            avatar_id,
            _DEFAULT_AVATAR_ID,
        )
        avatar = _AVATARS[_DEFAULT_AVATAR_ID]
    return avatar.model_copy()


def list_avatars() -> list[AvatarInfo]:
    """Return all available avatars."""
    return [a.model_copy() for a in _AVATARS.values()]
