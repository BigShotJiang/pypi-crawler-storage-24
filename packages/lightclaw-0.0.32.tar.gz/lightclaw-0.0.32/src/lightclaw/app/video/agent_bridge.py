"""VoiceAgentBridge — 语音对话接入完整 ReAct 循环。

替代 LLMBridge 的轻量直调方式，通过 AgentRunner.stream_turns() 走完整管道：
  - 工具调用（shell / 文件 / 浏览器 / MCP 等）
  - 记忆系统（加载/持久化/压缩）
  - 中间件（Bootstrap / Token 预算控制）
  - 会话持久化（与文字对话共享 session_id）

语音特化处理：
  1. 在系统提示末尾注入语音规则（简短口语、禁 Markdown/emoji 等）
  2. ThinkingStripper 过滤流式文本中的 <thinking>...</thinking> 块
  3. 事件过滤：跳过 REASONING / PLUGIN_CALL / PLUGIN_CALL_OUTPUT 类型事件
     只有 ContentEvent(delta=True, type=TEXT) 的文本才送给 TTS
"""

from __future__ import annotations

import logging
from collections.abc import AsyncGenerator
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..video.protocol import AvatarInfo

logger = logging.getLogger(__name__)

# ── 语音场景追加的系统提示 ────────────────────────────────────────────────────
# 注入在现有 system_prompt 末尾，不覆盖 AGENTS.md / SOUL.md 内容。
# 用户角色/性格由原有 system_prompt 负责，这里只做语音格式约束。
_VOICE_SYSTEM_PROMPT_ADDON = """
---
## 语音对话模式 (Voice Chat Mode)

当前你正在进行实时语音对话，回复会被 TTS 直接朗读给用户。请严格遵守：

1. **回复简短** — 1~3 句话，控制在 50 字以内，像朋友聊天一样自然。
2. **纯口语** — 禁止使用 Markdown（**加粗**、`代码`、列表、标题等），禁止 emoji、波浪号、颜文字。
3. **STT 容错** — 用户输入经语音识别，可能有错别字或漏字，请根据上下文理解真实意图，不要纠正。
4. **直接回答** — 不要寒暄客套，不要重复用户的话，不要说"好的，我来帮你..."之类的废话。
5. **工具结果口语化** — 如果调用了工具，将结果转化为口语化的简短句子告知用户，不要直接朗读原始数据。
""".strip()


# ── ThinkingStripper ─────────────────────────────────────────────────────────


class ThinkingStripper:
    """从流式文本中过滤 <thinking>...</thinking> 块。

    使用状态机处理跨 chunk 的不完整标签，例如一个 chunk 末尾是 "<thin"，
    下一个 chunk 开头才是 "king>..." 的情况。

    用法::

        stripper = ThinkingStripper()
        for chunk in llm_stream:
            clean = stripper.feed(chunk)
            if clean:
                tts_queue.put(clean)
        remaining = stripper.flush()
    """

    # 最长可能的前缀标签，用于决定暂存区大小
    _OPEN_TAG = "<thinking>"
    _CLOSE_TAG = "</thinking>"
    # 暂存区最多保留多少字符等待拼合判断（略大于最长标签长度即可）
    _MAX_HOLD = 12

    def __init__(self) -> None:
        self._in_thinking = False
        self._hold = ""  # 末尾疑似标签前缀的暂存区

    def feed(self, chunk: str) -> str:
        """处理一个流式 chunk，返回干净文本（可能为空串）。"""
        text = self._hold + chunk
        self._hold = ""
        output_parts: list[str] = []

        while text:
            if self._in_thinking:
                idx = text.find(self._CLOSE_TAG)
                if idx != -1:
                    # 找到结束标签，切换回正常模式
                    text = text[idx + len(self._CLOSE_TAG) :]
                    self._in_thinking = False
                else:
                    # 末尾可能是结束标签的前缀，暂存等待下一 chunk
                    hold_from = max(0, len(text) - self._MAX_HOLD)
                    self._hold = text[hold_from:]
                    break
            else:
                idx = text.find(self._OPEN_TAG)
                if idx != -1:
                    # 找到开始标签前的文本正常输出
                    output_parts.append(text[:idx])
                    text = text[idx + len(self._OPEN_TAG) :]
                    self._in_thinking = True
                else:
                    # 末尾可能是开始标签的前缀，暂存
                    hold_from = max(0, len(text) - self._MAX_HOLD)
                    output_parts.append(text[:hold_from])
                    self._hold = text[hold_from:]
                    break

        return "".join(output_parts)

    def flush(self) -> str:
        """流结束时清空暂存区，返回剩余干净文本。"""
        if self._in_thinking:
            self._hold = ""
            self._in_thinking = False
            return ""
        remaining = self._hold
        self._hold = ""
        return remaining


# ── VoiceAgentBridge ─────────────────────────────────────────────────────────


class VoiceAgentBridge:
    """语音对话 LLM 桥接器，使用完整 ReAct 循环。

    替代 ``LLMBridge``，会话历史、工具调用、记忆系统全部生效。
    通过 ``session_id`` / ``user_id`` 与文字对话共享同一会话上下文（决策 2C）。

    用法::

        bridge = VoiceAgentBridge(runner=app.state.runner, session_id="xxx", user_id="yyy")
        async for text_chunk in bridge.get_response(user_text):
            tts_queue.put(text_chunk)
    """

    def __init__(
        self,
        runner,
        session_id: str,
        user_id: str = "",
        avatar: AvatarInfo | None = None,
    ) -> None:
        self._runner = runner
        self._session_id = session_id
        self._user_id = user_id
        self._avatar = avatar

    def _build_voice_system_prompt_addon(self) -> str:
        """返回语音规则追加文本，可根据 avatar 个性化（预留扩展点）。"""
        return _VOICE_SYSTEM_PROMPT_ADDON

    async def get_response(
        self,
        user_text: str,
    ) -> AsyncGenerator[str, None]:
        """流式产出干净的、适合 TTS 朗读的文本 chunk。

        只产出 ``assistant.delta`` / ``assistant.completed`` 中的文本，
        过滤掉 reasoning 和工具事件。
        工具调用期间静默等待（决策 3A），调用方保持 thinking 状态即可。

        Args:
            user_text: STT 识别出的用户语音文本。

        Yields:
            经 ThinkingStripper 过滤后的文本片段，可直接送给 SentenceSplitter。
        """
        from ..turn_protocol import TurnEventType, TurnRequest

        # 构造请求，注入语音规则 addon 到 turn request，
        # SessionFactory 读取 channel="video_chat" 后会在 sys_prompt 末尾追加。
        request = TurnRequest(
            inputs=[{"role": "user", "content": [{"type": "text", "text": user_text}]}],
            session_id=self._session_id,
            user_id=self._user_id,
            channel="video_chat",
            voice_system_prompt_addon=self._build_voice_system_prompt_addon(),
        )

        stripper = ThinkingStripper()
        got_any_text = False

        try:
            async for event in self._runner.stream_turns(request):
                if event.type == TurnEventType.ASSISTANT_DELTA:
                    delta = event.delta if isinstance(event.delta, dict) else {}
                    text = delta.get("text") if isinstance(delta, dict) else None
                    if isinstance(text, str) and text:
                        clean = stripper.feed(text)
                        if clean:
                            got_any_text = True
                            yield clean
                    continue

                if event.type == TurnEventType.ASSISTANT_COMPLETED:
                    for block in event.content or []:
                        if not isinstance(block, dict) or block.get("type") != "text":
                            continue
                        text = block.get("text")
                        if isinstance(text, str) and text:
                            clean = stripper.feed(text)
                            if clean:
                                got_any_text = True
                                yield clean
                    continue

                if event.type in (
                    TurnEventType.TURN_COMPLETED,
                    TurnEventType.TURN_FAILED,
                ):
                    remaining = stripper.flush()
                    if remaining:
                        got_any_text = True
                        yield remaining
                    if event.type == TurnEventType.TURN_FAILED:
                        logger.warning(
                            "VoiceAgentBridge: AgentRunner returned Failed (session=%s, user=%s)",
                            self._session_id,
                            self._user_id,
                        )
                    break

        except Exception:
            logger.exception(
                "VoiceAgentBridge: stream_turns error (session=%s, user=%s)",
                self._session_id,
                self._user_id,
            )
            remaining = stripper.flush()
            if remaining:
                yield remaining
            raise

        if not got_any_text:
            logger.warning(
                "VoiceAgentBridge: no text output produced (session=%s, user=%s, input=%r)",
                self._session_id,
                self._user_id,
                user_text[:60],
            )
