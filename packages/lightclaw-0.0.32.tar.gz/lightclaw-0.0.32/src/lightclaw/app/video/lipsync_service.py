"""Lip-sync service.

On macOS / CPU-only environments the default mode is "css":
  - No video frames are generated.
  - The frontend uses CSS animations to simulate mouth movement.

On NVIDIA GPU environments with MuseTalk installed the mode is "musetalk":
  - Audio + reference image → JPEG video frame stream.
  - Frames are base64-encoded and sent to the frontend as video_frame messages.

The active mode is reported to the frontend in the session_started message
so it can switch between <img> + CSS and <canvas> rendering accordingly.
"""

import logging
from collections.abc import AsyncGenerator

from ..video import get_lipsync_mode

logger = logging.getLogger(__name__)


class LipSyncService:
    """Lip-sync abstraction.  CSS mode is always available; MuseTalk is optional."""

    def __init__(self, mode: str | None = None) -> None:
        self._mode = mode or get_lipsync_mode()
        self._musetalk = None
        logger.info("LipSyncService mode: %s", self._mode)

    @property
    def mode(self) -> str:
        return self._mode

    # ── MuseTalk (GPU) ────────────────────────────────────────────────────────

    def _load_musetalk(self):
        if self._musetalk is not None:
            return
        try:
            import musetalk  # type: ignore  # noqa: F401

            # Actual MuseTalk init would go here
            # self._musetalk = musetalk.MuseTalkInference(...)
            logger.info("MuseTalk loaded (stub — replace with real init).")
        except ImportError as exc:
            raise RuntimeError("MuseTalk is not installed.") from exc

    async def generate_frames(
        self,
        audio_chunk: bytes,
        reference_image_path: str,
    ) -> AsyncGenerator[bytes, None]:
        """
        Yield JPEG video frames (bytes) for the given audio chunk.
        Only meaningful in 'musetalk' mode; yields nothing in 'css' mode.
        """
        if self._mode != "musetalk":
            return

        # MuseTalk inference (stub — replace with real implementation)
        self._load_musetalk()
        # frames = self._musetalk.inference(audio_chunk, reference_image_path)
        # for frame in frames:
        #     import cv2
        #     yield cv2.imencode('.jpg', frame)[1].tobytes()
        logger.debug("MuseTalk generate_frames called (stub)")
        return  # yield nothing until real MuseTalk is wired up
