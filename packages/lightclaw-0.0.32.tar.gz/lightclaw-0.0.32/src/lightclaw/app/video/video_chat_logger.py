"""Unified logging for video chat & 3D avatar modules.

All ``lightclaw.app.video.*`` and ``lightclaw.app.routers.video_chat``
loggers write to ``finnie/logs/chat_and_3d.log`` with session context
auto-injected via :class:`contextvars.ContextVar`.

Usage::

    # In video_chat.py (entry point):
    from ..video.video_chat_logger import setup_chat_and_3d_logger, session_id_var
    setup_chat_and_3d_logger()

    # Inside WebSocket handler:
    session_id_var.set(session_id)

    # In any sub-module (stt, tts, llm, ...):
    #   No changes needed — just use logging.getLogger(__name__) as usual.
    #   The file handler auto-injects session_id from the ContextVar.
"""

from __future__ import annotations

import logging
import logging.handlers
from contextvars import ContextVar
from pathlib import Path

# ── Session context ──────────────────────────────────────────────────────────
# Set this ContextVar once per WebSocket session in video_chat_ws().
# All async tasks spawned within that coroutine inherit the value automatically.
session_id_var: ContextVar[str] = ContextVar("vc_session_id", default="no-session")

# ── Module prefix mapping ────────────────────────────────────────────────────
# Keys MUST match the __name__ of each module so that
# ``logging.getLogger(__name__)`` resolves correctly.
MODULE_PREFIXES: dict[str, str] = {
    "lightclaw.app.routers.video_chat": "[VIDEO_CHAT]",
    "lightclaw.app.video.stt_service": "[STT]",
    "lightclaw.app.video.tts_service": "[TTS]",
    "lightclaw.app.video.llm_bridge": "[LLM]",
    "lightclaw.app.video.lipsync_service": "[LIPSYNC]",
    "lightclaw.app.video.avatar_manager": "[AVATAR]",
    "lightclaw.app.video.protocol": "[PROTOCOL]",
    "lightclaw.app.video.audio_utils": "[AUDIO]",
    "lightclaw.app.video.sentence_splitter": "[SPLITTER]",
}


class _SessionFilter(logging.Filter):
    """Inject ``session_id`` and ``module_prefix`` into every log record.

    This filter reads from :data:`session_id_var` at log-emit time, so each
    asyncio Task sees its own session context even when multiple sessions run
    concurrently.
    """

    def filter(self, record: logging.LogRecord) -> bool:
        record.session_id = session_id_var.get()  # type: ignore[attr-defined]
        record.module_prefix = MODULE_PREFIXES.get(  # type: ignore[attr-defined]
            record.name, "[UNKNOWN]"
        )
        return True


# ── Format ───────────────────────────────────────────────────────────────────
_LOG_FMT = "%(asctime)s | %(levelname)-7s | %(module_prefix)s | session=%(session_id)s | %(message)s"
_DATE_FMT = "%Y-%m-%d %H:%M:%S"

# ── Guard against double-init (e.g. hot reload) ─────────────────────────────
_initialized: bool = False


def setup_chat_and_3d_logger(
    log_dir: str | Path = "logs",
    max_bytes: int = 10 * 1024 * 1024,  # 10 MB
    backup_count: int = 5,
) -> None:
    """Attach a shared :class:`RotatingFileHandler` to all video-chat loggers.

    The handler writes to ``<log_dir>/chat_and_3d.log`` and auto-injects
    ``session_id`` + ``module_prefix`` via :class:`_SessionFilter`.

    This function is idempotent: calling it more than once is a no-op.

    Args:
        log_dir: Directory for the log file.  Created if missing.
        max_bytes: Max size per log file before rotation (default 10 MB).
        backup_count: Number of rotated backups to keep (default 5).
    """
    global _initialized
    if _initialized:
        return
    _initialized = True

    log_path = Path(log_dir)
    log_path.mkdir(parents=True, exist_ok=True)
    log_file = log_path / "chat_and_3d.log"

    # Create one shared handler for all video-chat loggers.
    handler = logging.handlers.RotatingFileHandler(
        log_file,
        maxBytes=max_bytes,
        backupCount=backup_count,
        encoding="utf-8",
    )
    handler.setLevel(logging.DEBUG)
    handler.setFormatter(logging.Formatter(_LOG_FMT, datefmt=_DATE_FMT))
    handler.addFilter(_SessionFilter())

    # Attach to every module logger listed in MODULE_PREFIXES.
    for logger_name in MODULE_PREFIXES:
        lgr = logging.getLogger(logger_name)
        # Guard: avoid duplicate handlers on hot-reload.
        already = any(
            isinstance(h, logging.handlers.RotatingFileHandler)
            and getattr(h, "baseFilename", "").endswith("chat_and_3d.log")
            for h in lgr.handlers
        )
        if not already:
            lgr.addHandler(handler)
