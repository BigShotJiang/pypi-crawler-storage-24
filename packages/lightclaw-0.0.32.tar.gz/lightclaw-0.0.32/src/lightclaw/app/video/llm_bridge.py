"""Lightweight LLM bridge for video chat.

Bypasses the full AgentRunner pipeline (tools, history, middleware, session
persistence) and calls the LLM directly via LangChain's ChatOpenAI for
minimal latency.  Thinking/chain-of-thought is explicitly disabled via
``extra_body`` so the model responds immediately without generating
reasoning tokens.

Only affects video-chat; the normal text chat path is untouched.
"""

import logging
import time
from collections import deque
from collections.abc import AsyncGenerator

from .protocol import AvatarInfo

logger = logging.getLogger(__name__)

# ── 语音对话系统提示 ─────────────────────────────────────────────────────────
# 这是实时语音对话场景，输出会直接经过 TTS 朗读。
# Prompt 设计原则：
#   1. 口语化 — 输出必须适合朗读，不能有书面格式
#   2. STT 容错 — 用户输入经过语音识别，常有错别字/漏字，需理解意图
#   3. 简短 — 语音对话节奏快，回复要精炼
#   4. 自然断句 — 便于 TTS 分句合成
#   5. 禁止文字装饰 — 波浪号、颜文字、emoji 等 TTS 无法朗读

_VIDEO_CHAT_SYSTEM_PROMPT = (
    "你是一个语音助手，名字叫小龙虾。"
    "你正在和用户进行实时语音对话，你的回复会被直接朗读出来。\n"
    "规则：\n"
    "1. 回复简短，1-2句话，像朋友聊天一样自然。\n"
    "2. 用纯口语表达，不要书面语。禁止使用markdown、列表、括号注释、emoji、波浪号等任何文字装饰。\n"
    "3. 用户的话经过语音识别，可能有错别字或漏字，请根据上下文理解用户的真实意图，不要纠正用户的错别字。\n"
    "4. 如果实在听不懂用户在说什么，简短地请用户再说一遍。\n"
    "5. 直接回答问题，不要寒暄客套，不要重复用户的话。"
)


def _build_system_prompt(avatar: AvatarInfo | None = None) -> str:
    """根据角色信息构建语音对话的个性化系统提示。"""
    if avatar is None or not avatar.personality:
        return _VIDEO_CHAT_SYSTEM_PROMPT

    return (
        f"你是一个语音助手，名字叫{avatar.name}。"
        f"{avatar.personality}\n"
        "你正在和用户进行实时语音对话，你的回复会被直接朗读出来。\n"
        "规则：\n"
        "1. 回复简短，1-2句话，像朋友聊天一样自然。\n"
        "2. 用纯口语表达，不要书面语。禁止使用markdown、列表、括号注释、emoji、波浪号等任何文字装饰。\n"
        "3. 用户的话经过语音识别，可能有错别字或漏字，请根据上下文理解用户的真实意图，不要纠正用户的错别字。\n"
        "4. 如果实在听不懂用户在说什么，简短地请用户再说一遍。\n"
        "5. 直接回答问题，不要寒暄客套，不要重复用户的话。\n"
        "6. 保持你的性格特点，但不要刻意卖萌或用夸张的语气词。"
    )


def _create_video_chat_model():
    """Create a lightweight ChatOpenAI instance for video chat.

    - Reuses the same provider config as the normal chat path.
    - Passes ``extra_body`` to disable thinking/chain-of-thought for speed.
    - Falls back to the first available model if no active model is configured.

    Raises:
        ValueError: If no LLM is configured.
    """
    from ...agent.langgraph.model_factory import (
        _resolve_chat_model_name,
    )
    from ...providers import get_active_llm_config, list_resolved_llm_configs
    from ...providers.registry import get_langchain_model_class

    llm_cfg = get_active_llm_config()

    # If no active model is configured, try to get the first available model
    if not llm_cfg or not (llm_cfg.model or llm_cfg.base_url or llm_cfg.provider_id):
        logger.warning("No active LLM configured. Attempting to use the first available model.")
        available_models = list_resolved_llm_configs()

        if not available_models:
            raise ValueError(
                "No LLM is configured for video chat. Please configure an active LLM "
                "in lightclaw.json (models.activeLlm) or set up a provider with "
                "an API key."
            )

        # Use the first available model
        llm_cfg = available_models[0]
        logger.info(
            "Selected first available model for video chat: %s (provider: %s)",
            llm_cfg.model,
            llm_cfg.provider_id,
        )

    model_name = llm_cfg.model
    api_key = llm_cfg.api_key
    base_url = llm_cfg.base_url
    provider_id = llm_cfg.provider_id

    chat_model_name = _resolve_chat_model_name(provider_id)
    model_class = get_langchain_model_class(chat_model_name)

    # Build kwargs based on provider type
    if chat_model_name == "ChatOpenAI":
        return model_class(
            model=model_name,
            api_key=api_key or "lightclaw-local",
            base_url=base_url,
            streaming=True,
            max_tokens=150,
            temperature=0.7,
            extra_body={
                "chat_template_kwargs": {"thinking": False},
                "enable_thinking": False,
            },
        )
    else:
        # For other providers (Anthropic, Google, etc.), skip extra_body
        # as they don't support chat_template_kwargs
        kwargs = {
            "model": model_name,
            "streaming": True,
            "max_tokens": 150,
            "temperature": 0.7,
        }
        if api_key:
            kwargs["api_key"] = api_key
        if base_url:
            kwargs["base_url"] = base_url
        return model_class(**kwargs)


# Maximum number of history turns (user+assistant pairs) to keep
_MAX_HISTORY_TURNS = 10

# Rough token budget for the entire history passed to the LLM.
# Chinese text is ~1.5 chars/token; we use a conservative char-based estimate
# to avoid sending more context than the model's window allows.
# (max_tokens=80 for output; typical context window is 4k-8k tokens)
_MAX_HISTORY_CHARS = 2000  # ~1300 tokens — leaves headroom for system prompt + output


class LLMBridge:
    """Lightweight LLM bridge for video chat — calls model directly."""

    def __init__(self, runner=None, avatar: AvatarInfo | None = None) -> None:
        # runner is accepted for backward compat but no longer used
        self._model = None  # lazy init
        self._avatar = avatar  # 角色信息，用于构建个性化系统提示
        # Conversation history for multi-turn context (stores LangChain message objects)
        self._history: deque = deque(maxlen=_MAX_HISTORY_TURNS * 2)

    def _ensure_model(self):
        if self._model is None:
            self._model = _create_video_chat_model()
            logger.info("LLMBridge: created video-chat model (thinking disabled)")

    def _trim_history(self) -> list:
        """Return a token-budget-respecting subset of conversation history.

        Iterates the deque from newest to oldest, accumulating messages until
        the total character count exceeds _MAX_HISTORY_CHARS.  This ensures
        recent context is always preserved even when history is long.
        Messages are returned in chronological order (oldest first).
        """
        messages = list(self._history)  # chronological order
        if not messages:
            return messages

        total_chars = sum(len(m.content) for m in messages)
        if total_chars <= _MAX_HISTORY_CHARS:
            return messages

        # Drop oldest messages until we fit within the budget
        trimmed = []
        budget = _MAX_HISTORY_CHARS
        for msg in reversed(messages):
            cost = len(msg.content)
            if budget - cost < 0:
                break
            trimmed.append(msg)
            budget -= cost

        trimmed.reverse()  # restore chronological order
        dropped = len(messages) - len(trimmed)
        if dropped:
            logger.debug(
                "LLMBridge: trimmed %d old history message(s) to stay within %d char budget",
                dropped,
                _MAX_HISTORY_CHARS,
            )
        return trimmed

    async def get_response(
        self,
        user_text: str,
        session_id: str,
    ) -> AsyncGenerator[str, None]:
        """Stream LLM text chunks for ``user_text``.

        Uses direct LangChain ``astream()`` — no AgentRunner overhead.
        Yields incremental text strings (partial words/sentences).
        Maintains conversation history for multi-turn context.
        """
        from langchain_core.messages import AIMessage, HumanMessage, SystemMessage

        self._ensure_model()

        system_prompt = _build_system_prompt(self._avatar)
        messages = [
            SystemMessage(content=system_prompt),
            *self._trim_history(),  # token-budget-trimmed conversation history
            HumanMessage(content=user_text),
        ]

        try:
            chunk_count = 0
            full_response = ""
            t_start = time.monotonic()
            t_first_token = None
            # Note: overall timeout is enforced by the caller (video_chat.py) via
            # asyncio.wait_for wrapping _run_llm_with_tts. No per-token timeout here
            # to keep the async generator compatible.
            async for chunk in self._model.astream(messages):
                text = chunk.content if hasattr(chunk, "content") else ""
                if text:
                    chunk_count += 1
                    if chunk_count == 1:
                        t_first_token = time.monotonic()
                        logger.info(
                            "[PERF] LLM first-token: %.0fms (session=%s)",
                            (t_first_token - t_start) * 1000,
                            session_id,
                        )
                    full_response += text
                    yield text
            t_done = time.monotonic()
            logger.info(
                "[PERF] LLM complete: total=%.0fms, first_token=%.0fms, "
                "generation=%.0fms, chunks=%d, chars=%d (session=%s)",
                (t_done - t_start) * 1000,
                ((t_first_token - t_start) * 1000) if t_first_token else 0,
                ((t_done - t_first_token) * 1000) if t_first_token else 0,
                chunk_count,
                len(full_response),
                session_id,
            )
            if chunk_count == 0:
                logger.warning(
                    "LLMBridge: session=%s model returned 0 text chunks",
                    session_id,
                )
            # Append this turn to history for multi-turn context
            self._history.append(HumanMessage(content=user_text))
            if full_response:
                self._history.append(AIMessage(content=full_response))
        except Exception:
            logger.exception("LLMBridge error for session %s", session_id)
            # Re-raise instead of yielding error text — yielding would cause
            # the error string to be spoken aloud via TTS.
            raise
