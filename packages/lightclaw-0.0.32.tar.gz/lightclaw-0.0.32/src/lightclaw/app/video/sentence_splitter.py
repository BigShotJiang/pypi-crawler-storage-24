"""Sentence splitter for TTS streaming.

Splits a streaming LLM text output into sentences suitable for TTS synthesis.
A sentence is emitted when:
  - A sentence-ending punctuation is encountered (.。!！?？;；), OR
  - The accumulated buffer exceeds MAX_CHARS characters.
"""

import logging

logger = logging.getLogger(__name__)

# Punctuation that marks the end of a TTS-able chunk.
# Commas included to enable earlier TTS triggering for lower first-sentence latency.
_END_PUNCTS = set(".。!！?？;；,，")
MAX_CHARS = 10  # flush buffer if no punctuation after this many chars


class SentenceSplitter:
    """Accumulates streaming text and yields complete sentences."""

    def __init__(self) -> None:
        self._buf = ""

    def feed(self, text: str):
        """Feed a text chunk; yield zero or more sentences."""
        for ch in text:
            self._buf += ch
            if ch in _END_PUNCTS and len(self._buf.strip()) > 0:
                yield self._buf.strip()
                self._buf = ""
            elif len(self._buf) >= MAX_CHARS:
                # Force flush on long chunk without punctuation
                logger.debug("Buffer force flush at %d chars: %r", len(self._buf), self._buf[:30])
                yield self._buf.strip()
                self._buf = ""

    def flush(self):
        """Yield any remaining buffered text."""
        if self._buf.strip():
            yield self._buf.strip()
            self._buf = ""
