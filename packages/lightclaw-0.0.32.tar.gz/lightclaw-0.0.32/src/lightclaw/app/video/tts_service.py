"""TTS service for video chat.

Engine priority (auto-selected at init):
  1. Kokoro-82M  — fastest, Apache 2.0 (pip install kokoro>=0.9.4)
  2. XTTS-v2     — best Chinese quality (pip install coqui-tts)
  3. edge-tts    — cloud-based fallback, no install needed beyond edge-tts pkg
  4. Silent      — returns empty audio if nothing is available

Usage:
    svc = TTSService()          # auto-detect
    svc = TTSService("kokoro")  # force engine
    async for b64_wav in svc.synthesize_b64("你好"):
        ...  # send to frontend
"""

import asyncio
import io
import logging
import threading
import time
from collections.abc import AsyncGenerator

from .audio_utils import float32_to_wav_base64
from .sentence_splitter import SentenceSplitter

logger = logging.getLogger(__name__)

_ENGINE_PRIORITY = ["kokoro", "xtts", "edge", "silent"]

# ── Dynamic edge-tts voice registry ─────────────────────────────────────────
# Fetched once from Microsoft's API and cached for the process lifetime.
# This eliminates hardcoded voice lists that break when Microsoft deprecates voices.
_edge_voices_cache: set[str] | None = None
_edge_voices_lock = asyncio.Lock() if hasattr(asyncio, "Lock") else None
_EDGE_DEFAULT_VOICE = "zh-CN-XiaoxiaoNeural"


async def _fetch_edge_voices() -> set[str]:
    """Fetch all available edge-tts voice ShortNames from Microsoft's API.

    Results are cached globally so subsequent calls are instant.
    Falls back to a minimal safe set if the API is unreachable.
    """
    global _edge_voices_cache
    if _edge_voices_cache is not None:
        return _edge_voices_cache

    try:
        import edge_tts  # type: ignore

        voices = await edge_tts.list_voices()
        _edge_voices_cache = {v["ShortName"] for v in voices}
        logger.info(
            "edge-tts: fetched %d available voices from Microsoft API",
            len(_edge_voices_cache),
        )
    except Exception as exc:
        logger.warning(
            "edge-tts: failed to fetch voice list (%s), using safe default",
            exc,
        )
        # Minimal safe fallback — XiaoxiaoNeural has been stable for years
        _edge_voices_cache = {_EDGE_DEFAULT_VOICE}
    return _edge_voices_cache


async def _validate_edge_voice(voice_id: str | None) -> str:
    """Validate voice_id against the live edge-tts voice list.

    Returns the voice_id if valid, or a working fallback voice otherwise.
    """
    if not voice_id:
        return _EDGE_DEFAULT_VOICE

    available = await _fetch_edge_voices()
    if voice_id in available:
        return voice_id

    logger.warning(
        "edge-tts voice %r is not available (possibly deprecated by Microsoft). "
        "Available zh-CN voices: %s. Falling back to %r.",
        voice_id,
        sorted(v for v in available if v.startswith("zh-CN")),
        _EDGE_DEFAULT_VOICE,
    )
    return _EDGE_DEFAULT_VOICE


# Per-engine init locks: prevent concurrent sessions from loading the same
# heavy model simultaneously (Kokoro ~300MB, XTTS ~700MB GPU VRAM).
_kokoro_init_lock = threading.Lock()
_xtts_init_lock = threading.Lock()


def _detect_engine() -> str:
    for engine in _ENGINE_PRIORITY:
        if engine == "kokoro":
            try:
                import kokoro  # type: ignore  # noqa: F401

                return "kokoro"
            except ImportError:
                pass
        elif engine == "xtts":
            try:
                from TTS.api import TTS  # type: ignore  # noqa: F401

                return "xtts"
            except ImportError:
                pass
        elif engine == "edge":
            try:
                import edge_tts  # type: ignore  # noqa: F401

                return "edge"
            except ImportError:
                pass
    return "silent"


class TTSService:
    """Multi-engine TTS with sentence-level streaming."""

    def __init__(
        self,
        engine: str | None = None,
        voice_id: str | None = None,
        edge_rate: str = "+0%",
    ) -> None:
        self._engine = engine or _detect_engine()
        self._original_engine = self._engine  # 记住初始引擎，用于重试恢复
        self._voice_id = voice_id  # 角色对应的 TTS 声音 ID，None 时使用默认声音
        self._edge_rate = edge_rate  # edge-tts speech rate (e.g. "+30%", "+0%")
        self._pipeline = None  # lazy init
        self._consecutive_failures = 0  # 连续失败计数
        self._max_failures_before_degrade = 3  # 连续失败N次才真正降级
        logger.info(
            "TTSService using engine: %s, voice_id: %s, edge_rate: %s",
            self._engine,
            self._voice_id,
            self._edge_rate,
        )

    # ── Engine init (lazy) ────────────────────────────────────────────────────

    def _init_kokoro(self):
        if self._pipeline is not None:
            return
        with _kokoro_init_lock:
            # Double-checked locking: re-check after acquiring the lock
            if self._pipeline is not None:
                return
            from kokoro import KPipeline  # type: ignore

            # lang_code: 'z' = Chinese/Mandarin, 'a' = American English
            self._pipeline = KPipeline(lang_code="z")
            logger.info("Kokoro TTS pipeline initialised.")

    def _init_xtts(self):
        if self._pipeline is not None:
            return
        with _xtts_init_lock:
            # Double-checked locking: re-check after acquiring the lock
            if self._pipeline is not None:
                return
            from TTS.api import TTS  # type: ignore

            self._pipeline = TTS("tts_models/multilingual/multi-dataset/xtts_v2")
            logger.info("XTTS-v2 pipeline initialised.")

    # ── Synthesis helpers (sync, run in executor) ─────────────────────────────

    def _synth_kokoro(self, text: str) -> list[bytes]:
        """Return list of WAV byte strings (one per internal segment)."""
        self._init_kokoro()
        voice = self._voice_id or "af_heart"
        results = []
        for _, _, audio in self._pipeline(text, voice=voice):
            import numpy as np  # type: ignore

            if audio is not None and len(audio) > 0:
                arr = audio if hasattr(audio, "dtype") else np.array(audio, dtype=np.float32)
                results.append(float32_to_wav_base64(arr, sample_rate=24000).encode())
        return results

    def _synth_xtts(self, text: str) -> list[bytes]:
        self._init_xtts()
        import soundfile as sf  # type: ignore

        buf = io.BytesIO()
        self._pipeline.tts_to_file(text=text, file_path=buf, language="zh-cn")
        buf.seek(0)
        wav_data, sr = sf.read(buf, dtype="float32")
        return [float32_to_wav_base64(wav_data, sample_rate=sr).encode()]

    async def _synth_edge(self, text: str) -> list[bytes]:
        """edge-tts with retry logic and timeout for network resilience."""
        import edge_tts  # type: ignore

        # voice_id is validated during preload(); use default as final safety net
        voice = self._voice_id or _EDGE_DEFAULT_VOICE
        logger.debug(
            "edge-tts: synthesizing with voice=%s, rate=%s, text=%r",
            voice,
            self._edge_rate,
            text[:40],
        )

        # Retry logic: attempt up to 2 times (network issues may be transient)
        max_attempts = 2
        last_exc = None

        for attempt in range(1, max_attempts + 1):
            try:
                communicate = edge_tts.Communicate(text, voice=voice, rate=self._edge_rate)
                chunks = []

                # Add timeout to prevent hanging on network issues.
                # NOTE: asyncio.timeout() is the correct way to apply a deadline
                # to an async-for loop.  The previous asyncio.wait_for() does NOT
                # work with async generators — it expects a coroutine/future.
                try:
                    async with asyncio.timeout(10.0):
                        async for chunk in communicate.stream():
                            if chunk["type"] == "audio":
                                chunks.append(chunk["data"])
                except TimeoutError:
                    logger.warning(
                        "edge-tts timeout (attempt %d/%d) for voice=%s: connection timeout after 10s",
                        attempt,
                        max_attempts,
                        voice,
                    )
                    if attempt < max_attempts:
                        # Wait briefly before retry
                        await asyncio.sleep(0.5)
                        continue
                    else:
                        raise

                if not chunks:
                    logger.warning(
                        "edge-tts returned 0 audio chunks (attempt %d/%d) for voice=%s",
                        attempt,
                        max_attempts,
                        voice,
                    )
                    if attempt < max_attempts:
                        await asyncio.sleep(0.5)
                        continue
                    else:
                        # Raise exception instead of returning empty to signal failure
                        raise RuntimeError(
                            f"edge-tts returned no audio after {max_attempts} attempts for voice {voice}"
                        )

                # Success
                logger.debug("edge-tts succeeded (attempt %d/%d)", attempt, max_attempts)
                import base64

                full_mp3 = b"".join(chunks)
                return [base64.b64encode(full_mp3).decode().encode()]

            except Exception as exc:
                last_exc = exc
                logger.warning(
                    "edge-tts error (attempt %d/%d) for voice=%s: %s",
                    attempt,
                    max_attempts,
                    voice,
                    exc,
                )
                if attempt < max_attempts:
                    await asyncio.sleep(0.5)
                    continue

        # All retries exhausted
        if last_exc:
            raise last_exc
        return []

    # ── Public API ─────────────────────────────────────────────────────────────

    async def preload(self) -> None:
        """Eagerly load the TTS model to avoid first-call latency.

        Call this during session initialization to warm up the model.
        For local engines (Kokoro, XTTS), this loads the model weights.
        For edge-tts, this validates the voice_id against the live API.
        """
        if self._engine == "silent":
            return

        # For edge-tts: validate voice_id against Microsoft's live voice list.
        # This is the root fix for voice deprecation — if Microsoft removes a
        # voice, we detect it here and switch to a working one before any
        # synthesis attempt.
        if self._engine == "edge":
            validated = await _validate_edge_voice(self._voice_id)
            if validated != self._voice_id:
                logger.info(
                    "TTS voice_id corrected: %r → %r",
                    self._voice_id,
                    validated,
                )
                self._voice_id = validated
            return

        loop = asyncio.get_event_loop()
        try:
            if self._engine == "kokoro":
                await loop.run_in_executor(None, self._init_kokoro)
            elif self._engine == "xtts":
                await loop.run_in_executor(None, self._init_xtts)
            logger.info("TTS model preloaded: engine=%s", self._engine)
        except Exception as exc:
            logger.warning("TTS preload failed (engine=%s): %s", self._engine, exc)

    async def synthesize_sentence(self, sentence: str) -> AsyncGenerator[str, None]:
        """Synthesize a single pre-split sentence (no internal splitting).

        Used by the streaming pipeline where SentenceSplitter runs externally.
        Now properly propagates exceptions so backend can notify frontend.
        """
        if not sentence.strip():
            return
        t_start = time.monotonic()
        chunk_count = 0
        try:
            async for b64 in self._synth_sentence(sentence):
                chunk_count += 1
                yield b64
            elapsed_ms = (time.monotonic() - t_start) * 1000
            logger.info(
                "[PERF] TTS sentence: %.0fms, engine=%s, chunks=%d, text=%r",
                elapsed_ms,
                self._engine,
                chunk_count,
                sentence[:50],
            )
            # 合成成功，重置连续失败计数
            self._consecutive_failures = 0
        except Exception as exc:
            self._consecutive_failures += 1
            elapsed_ms = (time.monotonic() - t_start) * 1000
            logger.error(
                "[PERF] TTS error: %.0fms (consecutive=%d) for sentence %r: %s",
                elapsed_ms,
                self._consecutive_failures,
                sentence[:40],
                exc,
            )
            # Re-raise the exception so backend can catch it and notify frontend
            raise

    async def synthesize_b64(self, text: str) -> AsyncGenerator[str, None]:
        """
        Synthesize `text` and yield base64-encoded audio chunks (WAV or MP3).
        Uses SentenceSplitter internally so long text is processed sentence by sentence.
        """
        splitter = SentenceSplitter()
        sentences = list(splitter.feed(text)) + list(splitter.flush())

        for sentence in sentences:
            if not sentence.strip():
                continue
            # Let exceptions propagate so caller can detect TTS failures
            async for b64 in self._synth_sentence(sentence):
                yield b64

    async def _synth_sentence(self, sentence: str) -> AsyncGenerator[str, None]:
        """Synthesize using current engine, with automatic fallback on failure.

        改进策略：单次失败不永久降级，只有连续多次失败才降级。
        每次调用前，如果当前引擎是 silent 但原始引擎不是，尝试恢复。
        """
        # 如果当前被降级为 silent，但连续失败次数未达阈值，尝试恢复原始引擎
        if (
            self._engine == "silent"
            and self._original_engine != "silent"
            and self._consecutive_failures < self._max_failures_before_degrade
        ):
            logger.info(
                "TTS: restoring engine from 'silent' back to '%s'",
                self._original_engine,
            )
            self._engine = self._original_engine
            self._pipeline = None

        if self._engine == "silent":
            return

        loop = asyncio.get_event_loop()

        # Determine fallback order starting from current engine
        start_idx = _ENGINE_PRIORITY.index(self._engine) if self._engine in _ENGINE_PRIORITY else 0
        engines_to_try = _ENGINE_PRIORITY[start_idx:]

        for engine in engines_to_try:
            try:
                if engine == "kokoro":
                    chunks = await loop.run_in_executor(None, self._synth_kokoro, sentence)
                    for c in chunks:
                        yield c.decode()
                    return
                elif engine == "xtts":
                    chunks = await loop.run_in_executor(None, self._synth_xtts, sentence)
                    for c in chunks:
                        yield c.decode()
                    return
                elif engine == "edge":
                    chunks = await self._synth_edge(sentence)
                    for c in chunks:
                        yield c.decode()
                    return
                elif engine == "silent":
                    return
            except Exception as exc:
                logger.warning(
                    "TTS engine '%s' failed for sentence %r, trying next: %s",
                    engine,
                    sentence[:40],
                    exc,
                )
                # 只在连续失败达到阈值时才永久降级
                next_engines = _ENGINE_PRIORITY[_ENGINE_PRIORITY.index(engine) + 1 :]
                if next_engines:
                    self._engine = next_engines[0]
                    self._pipeline = None
                    if self._consecutive_failures >= self._max_failures_before_degrade:
                        logger.warning(
                            "TTS engine permanently degraded to '%s' after %d failures",
                            self._engine,
                            self._consecutive_failures,
                        )
                    else:
                        logger.info(
                            "TTS engine temporarily using '%s' for this sentence",
                            self._engine,
                        )
                continue
