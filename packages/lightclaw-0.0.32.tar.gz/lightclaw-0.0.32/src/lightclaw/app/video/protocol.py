"""WebSocket message protocol definitions for video chat."""

import logging
from typing import Literal

from pydantic import BaseModel

logger = logging.getLogger(__name__)


class AvatarInfo(BaseModel):
    id: str
    name: str
    gender: Literal["male", "female"] = "female"  # 性别（TTS 声音选择用）
    image_url: str = ""  # 兼容旧逻辑，3D 模式下可为空
    description: str | None = None
    voice_id: str | None = None  # TTS 声音标识
    personality: str | None = None  # 性格标签（传给前端显示 + LLM 人设）


# ── Client → Server ──────────────────────────────────────────────────────────


class ClientMessage(BaseModel):
    type: Literal[
        "audio_chunk",
        "start_session",
        "end_session",
        "interrupt",
        "mute",
    ]
    data: str | None = None  # base64-encoded PCM audio (audio_chunk)
    avatar_id: str | None = None  # start_session: requested avatar
    sample_rate: int | None = 16000  # audio sample rate
    # start_session: 与文字对话共享会话，前端传入当前打开的 chat session_id / user_id
    session_id: str | None = None
    user_id: str | None = None


# ── Server → Client ──────────────────────────────────────────────────────────


class ServerMessage(BaseModel):
    type: Literal[
        "session_started",
        "stt_text",
        "llm_text",
        "tts_audio",
        "video_frame",
        "state_change",
        "error",
        "session_ended",
    ]
    data: str | None = None  # text / base64 audio / base64 JPEG frame
    avatar: AvatarInfo | None = None  # returned on session_started
    state: Literal["listening", "thinking", "speaking", "idle", "initializing"] | None = None
    lipsync_mode: Literal["css", "musetalk"] | None = None  # session_started
    error: str | None = None
