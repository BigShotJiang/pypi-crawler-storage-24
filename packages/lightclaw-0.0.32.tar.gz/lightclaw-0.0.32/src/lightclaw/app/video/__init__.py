"""Video chat module for Finnie."""


def get_lipsync_mode() -> str:
    """Auto-detect environment and choose lip sync strategy."""
    try:
        import torch  # type: ignore

        if torch.cuda.is_available():
            try:
                import musetalk  # type: ignore  # noqa: F401

                return "musetalk"
            except ImportError:
                pass
    except ImportError:
        pass
    return "css"
