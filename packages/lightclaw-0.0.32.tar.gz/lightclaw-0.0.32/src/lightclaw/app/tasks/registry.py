"""TaskRegistry — process-level singleton that tracks active Agent tasks.

Design goals:
  • Minimal intrusion — callers only need register / update / complete.
  • SSE fan-out — each subscriber gets its own asyncio.Queue.
  • Memory-safe — history capped at HISTORY_MAX, stale tasks auto-reaped.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import time
from collections import deque
from typing import Any

from .models import AgentRole, LastActiveInfo, TaskEvent, TaskInfo, TaskStatus
from .role_resolver import resolve_role

logger = logging.getLogger(__name__)

HISTORY_MAX = 50
STALE_TIMEOUT_S = 600  # 10 minutes without update → stale
LAST_ACTIVE_TTL_S = 7 * 24 * 3600  # cache "last active" for 7 days
LAST_ACTIVE_PRUNE_BATCH = 200  # soft limit per prune call


class TaskRegistry:
    """Thread-safe (asyncio) registry for active Agent tasks."""

    def __init__(self) -> None:
        self._active: dict[str, TaskInfo] = {}
        self._history: deque[TaskInfo] = deque(maxlen=HISTORY_MAX)
        self._subscribers: list[asyncio.Queue] = []
        self._lock = asyncio.Lock()
        self._stats_completed_today: int = 0
        self._stats_total_elapsed_ms: float = 0.0
        self._stats_day: str = ""
        # (user_id, session_id) -> LastActiveInfo
        self._session_last_active: dict[tuple[str, str], LastActiveInfo] = {}

    def _session_key(self, user_id: str, session_id: str) -> tuple[str, str]:
        return (user_id or "", session_id or "")

    def _prune_session_last_active_locked(self, now: float) -> None:
        """Remove expired last-active entries.

        Must be called under ``self._lock``.
        """
        if not self._session_last_active:
            return

        expired: list[tuple[str, str]] = []
        for key, info in self._session_last_active.items():
            if now - info.last_active_at > LAST_ACTIVE_TTL_S:
                expired.append(key)
                if len(expired) >= LAST_ACTIVE_PRUNE_BATCH:
                    break

        for key in expired:
            self._session_last_active.pop(key, None)

    async def get_session_last_active(
        self,
        *,
        user_id: str,
        session_id: str,
    ) -> LastActiveInfo | None:
        """Get cached last-active time for one session."""
        now = time.time()
        async with self._lock:
            self._prune_session_last_active_locked(now)
            info = self._session_last_active.get(self._session_key(user_id, session_id))
            if info is None:
                return None
            if now - info.last_active_at > LAST_ACTIVE_TTL_S:
                self._session_last_active.pop(self._session_key(user_id, session_id), None)
                return None
            return info

    async def get_sessions_last_active_batch(
        self,
        *,
        user_id: str,
        session_ids: list[str],
    ) -> dict[str, LastActiveInfo]:
        """Get cached last-active time for many sessions (same user)."""
        now = time.time()
        found: dict[str, LastActiveInfo] = {}
        async with self._lock:
            self._prune_session_last_active_locked(now)
            for sid in session_ids:
                info = self._session_last_active.get(self._session_key(user_id, sid))
                if info is None:
                    continue
                if now - info.last_active_at > LAST_ACTIVE_TTL_S:
                    self._session_last_active.pop(self._session_key(user_id, sid), None)
                    continue
                found[sid] = info
        return found

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def register_task(self, task: TaskInfo) -> None:
        """Register a new active task and broadcast *task_created*."""
        async with self._lock:
            self._active[task.id] = task
        logger.debug("task_registry: registered %s (%s)", task.id, task.source)
        await self._broadcast(TaskEvent(event_type="task_created", task=task))

    async def update_task(self, task_id: str, **updates: Any) -> None:
        """Patch fields on an active task and broadcast *task_updated*."""
        async with self._lock:
            task = self._active.get(task_id)
            if task is None:
                return
            for k, v in updates.items():
                if hasattr(task, k):
                    setattr(task, k, v)

            current_tool = updates.get("current_tool")
            if current_tool and task.agent_role in {AgentRole.AGENT, AgentRole.ENGINEER}:
                next_role, next_name = resolve_role(
                    description=task.description,
                    source=task.source,
                    current_tool=current_tool,
                    task_id=task.id,
                )
                if next_role == AgentRole.ENGINEER:
                    task.agent_role = next_role
                    task.agent_name = next_name

            task.refresh_elapsed()
        await self._broadcast(TaskEvent(event_type="task_updated", task=task))

    async def complete_task(
        self,
        task_id: str,
        status: TaskStatus = TaskStatus.COMPLETED,
    ) -> None:
        """Move task from active → history and broadcast completion."""
        async with self._lock:
            task = self._active.pop(task_id, None)
            if task is None:
                return
            task.status = status
            task.ended_at = time.time()
            task.refresh_elapsed()
            self._history.appendleft(task)
            self._accumulate_stats(task)
            # "Last active" is updated for both COMPLETED and FAILED runs.
            # This enables UI to show "how long since user last interacted",
            # even when a turn terminates with an error.
            ended_at = task.ended_at or time.time()
            key = self._session_key(task.user_id, task.session_id)
            self._session_last_active[key] = LastActiveInfo(
                user_id=task.user_id,
                session_id=task.session_id,
                last_active_at=ended_at,
                last_task_id=task.id,
                last_channel=task.channel,
                last_task_status=status,
            )
            self._prune_session_last_active_locked(time.time())

        event_type = "task_completed" if status == TaskStatus.COMPLETED else "task_failed"
        logger.debug("task_registry: %s %s (%.0fms)", event_type, task_id, task.elapsed_ms)
        await self._broadcast(TaskEvent(event_type=event_type, task=task))

    async def get_active_tasks(self) -> list[TaskInfo]:
        """Return a snapshot of currently active tasks."""
        async with self._lock:
            tasks = list(self._active.values())
        for t in tasks:
            t.refresh_elapsed()
        return tasks

    async def get_history(self, limit: int = HISTORY_MAX) -> list[TaskInfo]:
        """Return the most recent completed/failed tasks."""
        async with self._lock:
            return list(self._history)[:limit]

    async def get_stats(self) -> dict[str, Any]:
        """Aggregate stats for the dashboard header."""
        self._maybe_reset_daily_stats()
        active = await self.get_active_tasks()
        avg_ms = (
            round(self._stats_total_elapsed_ms / self._stats_completed_today, 1)
            if self._stats_completed_today > 0
            else 0
        )
        return {
            "active_count": len(active),
            "completed_today": self._stats_completed_today,
            "avg_elapsed_ms": avg_ms,
        }

    # ------------------------------------------------------------------
    # SSE subscription
    # ------------------------------------------------------------------

    async def subscribe(self) -> asyncio.Queue:
        """Create a new subscriber queue and return it."""
        q: asyncio.Queue = asyncio.Queue(maxsize=256)
        async with self._lock:
            self._subscribers.append(q)
        # Send an initial snapshot so the client has up-to-date state
        for task in self._active.values():
            task.refresh_elapsed()
            await q.put(TaskEvent(event_type="snapshot", task=task))
        return q

    def unsubscribe(self, q: asyncio.Queue) -> None:
        """Remove a subscriber queue (fire-and-forget, no lock needed)."""
        with contextlib.suppress(ValueError):
            self._subscribers.remove(q)

    # ------------------------------------------------------------------
    # Stale task reaper (called externally or via periodic check)
    # ------------------------------------------------------------------

    async def reap_stale(self) -> None:
        """Mark tasks that have not been updated for STALE_TIMEOUT_S as failed."""
        now = time.time()
        stale_ids: list[str] = []
        async with self._lock:
            for tid, task in self._active.items():
                age = now - (task.ended_at or task.started_at)
                if age > STALE_TIMEOUT_S:
                    stale_ids.append(tid)
        for tid in stale_ids:
            logger.warning("task_registry: reaping stale task %s", tid)
            await self.complete_task(tid, status=TaskStatus.FAILED)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _broadcast(self, event: TaskEvent) -> None:
        """Fan-out event to all subscriber queues (drop if full)."""
        dead: list[asyncio.Queue] = []
        for q in list(self._subscribers):
            try:
                q.put_nowait(event)
            except asyncio.QueueFull:
                dead.append(q)
        # Remove dead/full queues
        for q in dead:
            self.unsubscribe(q)

    def _accumulate_stats(self, task: TaskInfo) -> None:
        self._maybe_reset_daily_stats()
        self._stats_completed_today += 1
        self._stats_total_elapsed_ms += task.elapsed_ms

    def _maybe_reset_daily_stats(self) -> None:
        today = time.strftime("%Y-%m-%d")
        if self._stats_day != today:
            self._stats_day = today
            self._stats_completed_today = 0
            self._stats_total_elapsed_ms = 0.0
