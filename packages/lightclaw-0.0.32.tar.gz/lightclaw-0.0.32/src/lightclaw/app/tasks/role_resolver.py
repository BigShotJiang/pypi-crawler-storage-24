"""Agent role resolver — derives agent_name and agent_role from task context.

Given a task's description, source, and current_tool, this module
assigns a meaningful role and a deterministic display name so the
virtual office can render each Agent with a unique identity.
"""

from __future__ import annotations

import hashlib

from .models import AgentRole, TaskSource

# ---------------------------------------------------------------------------
# Keyword → role mapping (checked in order; first match wins)
# ---------------------------------------------------------------------------
_ROLE_KEYWORDS: list[tuple[AgentRole, list[str]]] = [
    (
        AgentRole.CODER,
        [
            "code",
            "debug",
            "fix",
            "bug",
            "refactor",
            "implement",
            "function",
            "class",
            "compile",
            "编程",
            "代码",
            "修复",
            "调试",
            "开发",
            "编写代码",
            "重构",
            "实现",
            "函数",
        ],
    ),
    (
        AgentRole.RESEARCHER,
        [
            "search",
            "find",
            "look up",
            "research",
            "investigate",
            "query",
            "搜索",
            "查找",
            "研究",
            "调查",
            "查询",
            "检索",
        ],
    ),
    (
        AgentRole.WRITER,
        [
            "write",
            "draft",
            "compose",
            "essay",
            "article",
            "report",
            "blog",
            "document",
            "summary",
            "translate",
            "写",
            "文案",
            "报告",
            "文章",
            "翻译",
            "总结",
            "草稿",
            "撰写",
        ],
    ),
    (AgentRole.SCHEDULER, []),  # matched by source, not keywords
    (AgentRole.ENGINEER, []),  # matched by current_tool, not keywords
]

# ---------------------------------------------------------------------------
# Name pools per role — deterministic pick via task_id hash
# ---------------------------------------------------------------------------
_NAME_POOLS: dict[AgentRole, list[str]] = {
    AgentRole.CODER: [
        "Felix",
        "Ada",
        "Linus",
        "Grace",
        "Rust",
        "Ruby",
        "Kotlin",
        "Swift",
        "Elixir",
        "Clojure",
        "Dart",
        "Nova",
    ],
    AgentRole.RESEARCHER: [
        "Iris",
        "Scout",
        "Sherlock",
        "Atlas",
        "Darwin",
        "Curie",
        "Sage",
        "Falcon",
        "Oracle",
        "Quasar",
        "Lynx",
        "Cipher",
    ],
    AgentRole.WRITER: [
        "Quill",
        "Poet",
        "Luna",
        "Aria",
        "Hemingway",
        "Austen",
        "Fable",
        "Lyric",
        "Prose",
        "Muse",
        "Echo",
        "Bloom",
    ],
    AgentRole.SCHEDULER: [
        "Chrono",
        "Tick",
        "Tempo",
        "Cron",
        "Pulse",
        "Rhythm",
        "Beacon",
        "Sundial",
        "Metron",
        "Cadence",
        "Flux",
        "Orbit",
    ],
    AgentRole.ENGINEER: [
        "Bolt",
        "Gear",
        "Forge",
        "Anvil",
        "Wrench",
        "Spark",
        "Piston",
        "Dynamo",
        "Ratchet",
        "Torque",
        "Circuit",
        "Helix",
    ],
    AgentRole.AGENT: [
        "Claw",
        "Finnie",
        "Neo",
        "Pixel",
        "Blaze",
        "Zephyr",
        "Nimbus",
        "Prism",
        "Astra",
        "Vortex",
        "Cosmo",
        "Glitch",
    ],
}


def _pick_name(role: AgentRole, task_id: str) -> str:
    """Deterministically pick a name from the pool based on task_id hash."""
    pool = _NAME_POOLS.get(role, _NAME_POOLS[AgentRole.AGENT])
    digest = hashlib.md5(task_id.encode()).hexdigest()
    index = int(digest[:8], 16) % len(pool)
    return pool[index]


def _match_keywords(text: str) -> AgentRole | None:
    """Return the first matching role based on description keywords."""
    lower = text.lower()
    for role, keywords in _ROLE_KEYWORDS:
        if not keywords:
            continue
        for kw in keywords:
            if kw in lower:
                return role
    return None


def resolve_role(
    *,
    description: str = "",
    source: TaskSource = TaskSource.CHAT,
    current_tool: str | None = None,
    task_id: str = "",
) -> tuple[AgentRole, str]:
    """Derive ``(agent_role, agent_name)`` from task context.

    Resolution order:
    1. source == CRON → Scheduler
    2. description keyword match → Coder / Researcher / Writer
    3. current_tool is set → Engineer
    4. fallback → Agent

    The name is deterministically picked from the role's name pool
    using the task_id hash, so the same task always gets the same name.
    """
    role: AgentRole = AgentRole.AGENT

    # 1) Cron source overrides everything
    if source == TaskSource.CRON:
        role = AgentRole.SCHEDULER
    else:
        # 2) Keyword match on description
        matched = _match_keywords(description)
        if matched is not None:
            role = matched
        # 3) Has a tool call → Engineer
        elif current_tool:
            role = AgentRole.ENGINEER

    name = _pick_name(role, task_id)
    return role, name
