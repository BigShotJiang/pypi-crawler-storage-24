"""Task Board data models.

Pure Pydantic models for task tracking — no external dependencies.
"""

from __future__ import annotations

import time
from enum import StrEnum

from pydantic import BaseModel, Field


class TaskStatus(StrEnum):
    """Lifecycle status of an Agent task."""

    QUEUED = "queued"
    THINKING = "thinking"
    TOOL_CALLING = "tool_calling"
    STREAMING = "streaming"
    COMPLETED = "completed"
    FAILED = "failed"


class TaskSource(StrEnum):
    """Origin of the task."""

    CHAT = "chat"
    CRON = "cron"
    CHANNEL = "channel"


class AgentRole(StrEnum):
    """Visual role of the Agent in the virtual office."""

    CODER = "coder"
    RESEARCHER = "researcher"
    WRITER = "writer"
    SCHEDULER = "scheduler"
    ENGINEER = "engineer"
    AGENT = "agent"


class TaskInfo(BaseModel):
    """Full snapshot of a single Agent task."""

    id: str
    source: TaskSource = TaskSource.CHAT
    session_id: str = ""
    user_id: str = ""
    channel: str = "dashboard"
    status: TaskStatus = TaskStatus.QUEUED
    started_at: float = Field(default_factory=time.time)
    ended_at: float | None = None
    description: str = ""
    current_tool: str | None = None
    cron_job_name: str | None = None
    elapsed_ms: float = 0.0
    agent_name: str = ""
    agent_role: AgentRole = AgentRole.AGENT

    model_config = {"extra": "allow"}

    def refresh_elapsed(self) -> None:
        """Recompute *elapsed_ms* from ``started_at`` to now (or ended_at)."""
        end = self.ended_at or time.time()
        self.elapsed_ms = round((end - self.started_at) * 1000, 1)


class TaskEvent(BaseModel):
    """SSE payload pushed to subscribed dashboards."""

    event_type: str  # task_created | task_updated | task_completed | task_failed | snapshot
    task: TaskInfo
    timestamp: float = Field(default_factory=time.time)


class LastActiveInfo(BaseModel):
    """Cache entry for a user's latest session activity.

    Used for fast "how long since last active" queries without scanning
    session files on disk.
    """

    user_id: str
    session_id: str

    # Unix timestamp (seconds) of the last turn completion time.
    last_active_at: float

    # Extra debugging / UI hints (optional).
    last_task_id: str | None = None
    last_channel: str | None = None
    last_task_status: TaskStatus | None = None

    model_config = {"extra": "allow"}
