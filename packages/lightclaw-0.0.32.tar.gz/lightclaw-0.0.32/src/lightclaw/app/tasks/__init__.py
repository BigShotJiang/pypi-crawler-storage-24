"""Task Board — pluggable task tracking for LightClaw.

Provides real-time visibility into active Agent tasks (chat, cron, channel)
through a TaskRegistry singleton + REST/SSE API layer.
"""

from .models import AgentRole, TaskEvent, TaskInfo, TaskSource, TaskStatus
from .registry import TaskRegistry
from .role_resolver import resolve_role

__all__ = [
    "AgentRole",
    "TaskEvent",
    "TaskInfo",
    "TaskRegistry",
    "TaskSource",
    "TaskStatus",
    "resolve_role",
]
