"""Task Board REST & SSE API routes.

Endpoints:
  GET /tasks/active   — list currently active tasks
  GET /tasks/history  — list recently completed/failed tasks
  GET /tasks/stats    — aggregated stats (active count, today completed, avg time)
  GET /tasks/stream   — SSE real-time task event stream
"""

from __future__ import annotations

import asyncio
import json
import logging
import time

from fastapi import APIRouter, Body, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from .registry import TaskRegistry

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/tasks", tags=["tasks"])


def _get_registry(request: Request) -> TaskRegistry:
    return request.app.state.task_registry


@router.get("/active")
async def list_active_tasks(request: Request):
    """Return all currently running agent tasks."""
    registry = _get_registry(request)
    tasks = await registry.get_active_tasks()
    return [t.model_dump(mode="json") for t in tasks]


@router.get("/history")
async def list_task_history(request: Request, limit: int = 50):
    """Return recently completed/failed tasks."""
    registry = _get_registry(request)
    tasks = await registry.get_history(limit=limit)
    return [t.model_dump(mode="json") for t in tasks]


@router.get("/stats")
async def task_stats(request: Request):
    """Aggregated dashboard stats."""
    registry = _get_registry(request)
    return await registry.get_stats()


class SessionsLastActiveRequest(BaseModel):
    user_id: str = Field(default="", description="Owner user id")
    session_ids: list[str] = Field(default_factory=list, description="Session ids to query")


@router.get("/session-last-active")
async def session_last_active(
    request: Request,
    user_id: str,
    session_id: str,
):
    """Return cached "how long since last active" for one session."""
    registry = _get_registry(request)
    info = await registry.get_session_last_active(user_id=user_id, session_id=session_id)
    if info is None:
        return {
            "found": False,
            "user_id": user_id,
            "session_id": session_id,
        }

    now = time.time()
    age_ms = round((now - info.last_active_at) * 1000, 1)
    age_seconds = round(now - info.last_active_at, 3)
    return {
        "found": True,
        "user_id": info.user_id,
        "session_id": info.session_id,
        "last_active_at": info.last_active_at,
        "age_ms": age_ms,
        "age_seconds": age_seconds,
        "last_channel": info.last_channel,
        "last_task_id": info.last_task_id,
        "last_task_status": info.last_task_status,
    }


@router.post("/sessions-last-active")
async def sessions_last_active(
    request: Request,
    body: SessionsLastActiveRequest = Body(...),
):
    """Batch version of ``GET /tasks/session-last-active``."""
    registry = _get_registry(request)
    found = await registry.get_sessions_last_active_batch(
        user_id=body.user_id,
        session_ids=body.session_ids,
    )
    now = time.time()
    results: dict[str, dict] = {}
    for sid in body.session_ids:
        info = found.get(sid)
        if info is None:
            results[sid] = {"found": False, "session_id": sid}
            continue
        age_ms = round((now - info.last_active_at) * 1000, 1)
        age_seconds = round(now - info.last_active_at, 3)
        results[sid] = {
            "found": True,
            "session_id": sid,
            "user_id": info.user_id,
            "last_active_at": info.last_active_at,
            "age_ms": age_ms,
            "age_seconds": age_seconds,
            "last_channel": info.last_channel,
            "last_task_id": info.last_task_id,
            "last_task_status": info.last_task_status,
        }

    return {
        "user_id": body.user_id,
        "results": results,
    }


@router.get("/stream")
async def task_event_stream(request: Request):
    """SSE endpoint — streams TaskEvent payloads in real-time.

    Wire format: ``data: {json}\\n\\n`` (same convention as /api/agent/process).
    """
    registry = _get_registry(request)
    queue = await registry.subscribe()

    async def _sse_generator():
        try:
            while True:
                # Check client disconnect
                if await request.is_disconnected():
                    break
                try:
                    event = await asyncio.wait_for(queue.get(), timeout=30.0)
                    payload = event.model_dump(mode="json")
                    yield f"data: {json.dumps(payload, ensure_ascii=False)}\n\n"
                except TimeoutError:
                    # Send keep-alive comment to prevent proxy timeouts
                    yield ": heartbeat\n\n"
        finally:
            registry.unsubscribe(queue)

    return StreamingResponse(
        _sse_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )
