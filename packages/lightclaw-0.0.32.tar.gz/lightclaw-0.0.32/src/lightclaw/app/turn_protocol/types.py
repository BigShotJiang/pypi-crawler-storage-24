"""Canonical turn protocol constants."""

TURN_PROTOCOL_V1 = "v1"
DEFAULT_TURN_PROTOCOL_VERSION = TURN_PROTOCOL_V1


class TurnEventType:
    """Event names exposed by the new turn protocol."""

    TURN_STARTED: str = "turn.started"
    ASSISTANT_DELTA: str = "assistant.delta"
    ASSISTANT_COMPLETED: str = "assistant.completed"
    TOOL_STARTED: str = "tool.started"
    TOOL_COMPLETED: str = "tool.completed"
    TURN_COMPLETED: str = "turn.completed"
    TURN_FAILED: str = "turn.failed"
    # ToolGuard: 工具调用被拦截，等待用户审批
    TOOL_APPROVAL_REQUIRED: str = "tool.approval_required"


__all__ = [
    "DEFAULT_TURN_PROTOCOL_VERSION",
    "TURN_PROTOCOL_V1",
    "TurnEventType",
]
