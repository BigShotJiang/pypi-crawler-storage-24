"""Outbound DTOs for the canonical turn protocol."""

from __future__ import annotations

import json
from typing import Any

from pydantic import BaseModel, Field


class TurnEvent(BaseModel):
    """One normalized turn stream event."""

    type: str
    turn_id: str
    sequence_number: int | None = None
    message_id: str | None = None
    role: str | None = None
    delta: Any | None = None
    content: list[Any] = Field(default_factory=list)
    data: Any | None = None
    usage: Any | None = None
    metadata: dict[str, Any] | None = None
    error: Any | None = None

    model_config = {"extra": "allow"}


def serialize_turn_event(event: TurnEvent) -> str:
    """Serialize one turn event for SSE transport."""
    payload = event.model_dump(mode="json", exclude_none=True)
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))


__all__ = ["TurnEvent", "serialize_turn_event"]
