"""History DTOs for turn-native APIs."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class TurnHistoryEntry(BaseModel):
    """One history entry normalized around a turn/message result."""

    turn_id: str
    message_id: str | None = None
    role: str | None = None
    content: list[Any] = Field(default_factory=list)
    usage: Any | None = None
    metadata: dict[str, Any] | None = None

    model_config = {"extra": "allow"}


class TurnHistory(BaseModel):
    """Turn-native history response."""

    turns: list[TurnHistoryEntry] = Field(default_factory=list)

    model_config = {"extra": "allow"}


__all__ = ["TurnHistory", "TurnHistoryEntry"]
