"""Inbound DTOs for the canonical turn protocol."""

from __future__ import annotations

from typing import Any
from uuid import uuid4

from pydantic import BaseModel, Field


class TurnInput(BaseModel):
    """One inbound conversational item for a turn."""

    role: str = "user"
    content: Any = Field(default_factory=list)
    metadata: dict[str, Any] | None = None

    model_config = {"extra": "allow"}

    def get_text_content(self) -> str:
        """Extract plain text content, mirroring the legacy Message API."""
        if isinstance(self.content, str):
            return self.content
        parts: list[str] = []
        for block in self.content or []:
            if isinstance(block, str):
                parts.append(block)
            elif isinstance(block, dict) and block.get("type") == "text":
                parts.append(str(block.get("text", "")))
            elif getattr(block, "type", None) == "text" and hasattr(block, "text"):
                parts.append(block.text or "")
        return "".join(parts)


class TurnRequest(BaseModel):
    """Canonical request payload for turn streaming APIs."""

    turn_id: str = Field(default_factory=lambda: str(uuid4()))
    inputs: list[TurnInput] = Field(default_factory=list)
    stream: bool = True
    session_id: str = ""
    user_id: str = ""
    channel: str = ""
    model: str | None = None
    top_p: float | None = None
    temperature: float | None = None
    frequency_penalty: float | None = None
    presence_penalty: float | None = None
    max_tokens: int | None = None
    stop: Any | None = None
    n: int | None = None
    seed: int | None = None
    tools: Any | None = None
    reasoning_enabled: bool | None = None
    context: dict[str, Any] | None = None
    delivery: dict[str, Any] | None = None

    model_config = {"extra": "allow"}


__all__ = ["TurnInput", "TurnRequest"]
