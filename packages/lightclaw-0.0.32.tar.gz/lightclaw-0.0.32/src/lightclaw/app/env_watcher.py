"""Watch workspace .env for changes and hot-reload environment variables."""

from __future__ import annotations

import asyncio
import contextlib
import logging
from pathlib import Path

from ..envs import get_env_file_path, load_envs_into_environ
from .observability import reset_langfuse

logger = logging.getLogger(__name__)

DEFAULT_POLL_INTERVAL = 2.0


class EnvWatcher:
    """Poll workspace .env mtime and hot-reload os.environ on change."""

    def __init__(
        self,
        poll_interval: float = DEFAULT_POLL_INTERVAL,
        env_path: Path | None = None,
    ):
        self._poll_interval = poll_interval
        self._env_path = env_path or get_env_file_path()
        self._task: asyncio.Task | None = None
        self._last_mtime: float | None = None

    async def start(self) -> None:
        self._snapshot()
        self._task = asyncio.create_task(self._poll_loop(), name="env_watcher")
        logger.info(
            "EnvWatcher started (poll=%.1fs, path=%s)",
            self._poll_interval,
            self._env_path,
        )

    async def stop(self) -> None:
        if self._task:
            self._task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._task
            self._task = None
        logger.info("EnvWatcher stopped")

    def _snapshot(self) -> None:
        try:
            self._last_mtime = self._env_path.stat().st_mtime
        except FileNotFoundError:
            self._last_mtime = None

    async def _poll_loop(self) -> None:
        while True:
            try:
                await asyncio.sleep(self._poll_interval)
                await self._check()
            except Exception:
                logger.exception("EnvWatcher: poll iteration failed")

    async def _check(self) -> None:
        try:
            mtime = self._env_path.stat().st_mtime
        except FileNotFoundError:
            mtime = None

        if mtime == self._last_mtime:
            return

        self._last_mtime = mtime
        envs = load_envs_into_environ()
        reset_langfuse()
        logger.info(
            "EnvWatcher: reloaded %s (%d vars)",
            self._env_path,
            len(envs),
        )
