"""Compatibility shim for auth helpers."""

from .core import auth as _auth
from .core.auth import (
    AuthData,
    AuthStatusResponse,
    ChangePasswordRequest,
    LoginRequest,
    LoginResponse,
    SetPasswordRequest,
    SetupDoneRequest,
    create_token,
    require_auth,
    router,
)

_read_auth = _auth._read_auth
_write_auth = _auth._write_auth
_hash_password = _auth._hash_password
_ensure_jwt_secret = _auth._ensure_jwt_secret

__all__ = [
    "AuthData",
    "AuthStatusResponse",
    "ChangePasswordRequest",
    "LoginRequest",
    "LoginResponse",
    "SetPasswordRequest",
    "SetupDoneRequest",
    "_ensure_jwt_secret",
    "_hash_password",
    "_read_auth",
    "_write_auth",
    "create_token",
    "require_auth",
    "router",
]
