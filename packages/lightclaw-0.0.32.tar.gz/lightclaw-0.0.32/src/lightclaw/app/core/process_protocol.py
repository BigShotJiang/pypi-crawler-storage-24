"""Compatibility shim for the legacy process serializer."""

from ..legacy_process.serializer import (
    DEFAULT_PROCESS_PROTOCOL_VERSION,
    PROCESS_PROTOCOL_V2,
    process_event_to_payload,
    serialize_process_event,
)

__all__ = [
    "DEFAULT_PROCESS_PROTOCOL_VERSION",
    "PROCESS_PROTOCOL_V2",
    "process_event_to_payload",
    "serialize_process_event",
]
