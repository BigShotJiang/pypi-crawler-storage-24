"""EmbeddingManager：统一管理 embedding provider 的生命周期。

职责：
1. 根据 EmbeddingConfig 决定使用哪种 provider（none / local / custom）
2. 管理 LocalEmbeddingServer 的 startup / shutdown
3. 将 embedding 配置注入 os.environ，供 MemoryManager.get_emb_envs() 读取
4. 跟踪本地模型下载进度（实时 WebSocket 推送）
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import os
from dataclasses import dataclass
from enum import StrEnum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from fastapi import WebSocket

logger = logging.getLogger(__name__)

# Module-level reference to the active LocalEmbeddingServer.
# Set by EmbeddingManager when provider="local" startup succeeds.
# Read by create_embedding_fn() to call embed() in-process (no HTTP).
_active_local_server: LocalEmbeddingServer | None = None  # noqa: F821


def get_active_local_server() -> LocalEmbeddingServer | None:  # noqa: F821
    """Return the in-process LocalEmbeddingServer, or None if unavailable."""
    return _active_local_server


class DownloadStatus(StrEnum):
    IDLE = "idle"
    DOWNLOADING = "downloading"
    DONE = "done"
    FAILED = "failed"


@dataclass
class DownloadState:
    status: DownloadStatus = DownloadStatus.IDLE
    progress: float = 0.0  # 0.0 ~ 1.0
    error: str | None = None
    model_name: str = ""

    def model_dump(self) -> dict:
        """序列化为 JSON 可序列化的 dict（供 WebSocket 发送）。"""
        return {
            "status": self.status.value,
            "progress": self.progress,
            "error": self.error,
            "model_name": self.model_name,
        }


class DownloadStateNotifier:
    """管理 WebSocket 订阅者列表，在下载状态变化时广播。"""

    def __init__(self) -> None:
        self._subscribers: set[WebSocket] = set()
        self._lock = asyncio.Lock()

    async def subscribe(self, ws: WebSocket) -> None:
        """注册一个 WebSocket 连接。"""
        async with self._lock:
            self._subscribers.add(ws)

    async def unsubscribe(self, ws: WebSocket) -> None:
        """注销一个 WebSocket 连接。"""
        async with self._lock:
            self._subscribers.discard(ws)

    async def broadcast(self, state: DownloadState) -> None:
        """将状态广播给所有已连接的客户端，自动清理已断开的连接。"""
        async with self._lock:
            disconnected: set[WebSocket] = set()
            for ws in self._subscribers:
                try:
                    await ws.send_json(state.model_dump())
                except Exception:
                    disconnected.add(ws)
            for ws in disconnected:
                self._subscribers.discard(ws)


class EmbeddingManager:
    """统一管理 embedding provider 的启动/关闭/配置注入。

    使用方式（在 _app.py lifespan 中）::

        manager = EmbeddingManager()
        await manager.startup(config.embedding)
        app.state.embedding_manager = manager

        # shutdown
        await manager.shutdown()
    """

    def __init__(self) -> None:
        self._local_server: LocalEmbeddingServer | None = None  # noqa: F821
        self._download_state = DownloadState()
        self._download_lock = asyncio.Lock()
        self._provider: str = "none"
        self._notifier = DownloadStateNotifier()

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def startup(self, config: EmbeddingConfig) -> None:  # noqa: F821
        """根据配置启动 embedding provider。由 lifespan startup 调用。"""
        self._provider = config.provider

        if config.provider == "none":
            logger.info(
                "✗ Embedding disabled: provider=none. "
                "Memory search uses keyword-only (FTS) mode. "
                "Enable vector search in Settings → Memory."
            )
            self._clear_embedding_envs()
            return

        if config.provider == "local":
            await self._startup_local(config)
            return

        if config.provider == "custom":
            self._startup_custom(config)
            return

    async def shutdown(self) -> None:
        """释放资源。由 lifespan shutdown 调用。"""
        self._unpublish_local_server()
        if self._local_server is not None:
            try:
                await self._local_server.shutdown()
            except Exception as exc:
                logger.warning("Error shutting down local embedding server: %s", exc)
            finally:
                self._local_server = None

    # ------------------------------------------------------------------
    # Download API（供 Router 调用）
    # ------------------------------------------------------------------

    def get_download_state(self) -> DownloadState:
        """获取当前下载状态快照。"""
        return DownloadState(
            status=self._download_state.status,
            progress=self._download_state.progress,
            error=self._download_state.error,
            model_name=self._download_state.model_name,
        )

    async def reset_download_state(self) -> None:
        """重置下载状态（并广播给已连接的 WebSocket/前端轮询）。"""
        self._download_state = DownloadState()
        await self._broadcast_download_state()

    def get_notifier(self) -> DownloadStateNotifier:
        """获取下载状态通知器，供 WebSocket 路由使用。"""
        return self._notifier

    async def _broadcast_download_state(self) -> None:
        """广播当前下载状态给所有已连接的 WebSocket 客户端。"""
        await self._notifier.broadcast(self._download_state)

    async def trigger_local_model_download(
        self,
        config: EmbeddingConfig,  # noqa: F821
    ) -> None:
        """触发本地模型下载（异步后台任务，不阻塞调用方）。

        下载完成后自动将 env 变量注入，使 MemoryManager 生效。
        """
        async with self._download_lock:
            if self._download_state.status == DownloadStatus.DOWNLOADING:
                logger.info("Local model download already in progress, skipping.")
                return
            self._download_state = DownloadState(
                status=DownloadStatus.DOWNLOADING,
                model_name=config.local_model,
            )

        # 立即广播"下载中"状态
        await self._broadcast_download_state()

        # 后台执行，不 await
        asyncio.create_task(self._do_download(config))

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def is_ready(self) -> bool:
        """是否有可用的 embedding provider（local 且已加载 或 custom 已配置）。"""
        if self._provider == "local":
            return self._local_server is not None and self._local_server.is_ready
        if self._provider == "custom":
            return bool(os.environ.get("EMBEDDING_BASE_URL"))
        return False

    @property
    def local_server(self) -> LocalEmbeddingServer | None:  # noqa: F821
        return self._local_server

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    async def _startup_local(self, config: EmbeddingConfig) -> None:  # noqa: F821
        """启动本地 embedding 模型。"""
        from .local_server import LocalEmbeddingServer  # pylint: disable=import-outside-toplevel

        self._local_server = LocalEmbeddingServer(
            model_name=config.local_model,
        )
        self._download_state = DownloadState(
            status=DownloadStatus.DOWNLOADING,
            model_name=config.local_model,
        )
        await self._broadcast_download_state()

        done_event = asyncio.Event()

        async def _fake_progress() -> None:
            thresholds = [
                (30, 0.7, 1.0),
                (120, 0.95, 3.0),
            ]
            for duration, target, interval in thresholds:
                steps = int(duration / interval)
                step_size = (target - self._download_state.progress) / max(steps, 1)
                for _ in range(steps):
                    if done_event.is_set():
                        return
                    await asyncio.sleep(interval)
                    if done_event.is_set():
                        return
                    new_progress = min(self._download_state.progress + step_size, target)
                    self._download_state.progress = new_progress
                    if self._download_state.status == DownloadStatus.DOWNLOADING:
                        await self._broadcast_download_state()

        progress_task = asyncio.create_task(_fake_progress())
        try:
            await self._local_server.initialize()
            done_event.set()
            progress_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await progress_task
            self._download_state.status = DownloadStatus.DONE
            self._download_state.progress = 1.0
            # 注入 env，让 MemoryManager 读取
            self._inject_local_envs()
            self._publish_local_server()
            await self._broadcast_download_state()
            logger.info(
                "✓ Embedding ready: provider=local, model=%s, dims=%s (in-process, no HTTP)",
                self._local_server.model_name,
                self._local_server.dimensions,
            )
        except ImportError:
            done_event.set()
            progress_task.cancel()
            self._download_state.status = DownloadStatus.FAILED
            self._download_state.error = "fastembed not installed. Run: uv sync --extra local-embedding"
            self._clear_embedding_envs()
            await self._broadcast_download_state()
            logger.warning(
                "%s — Degrading to FTS-only keyword search.",
                self._download_state.error,
            )
        except Exception as exc:
            done_event.set()
            progress_task.cancel()
            self._download_state.status = DownloadStatus.FAILED
            self._download_state.error = str(exc)
            self._clear_embedding_envs()
            await self._broadcast_download_state()
            logger.warning(
                "Failed to start local embedding: %s — Degrading to FTS-only keyword search.",
                exc,
            )

    def _startup_custom(self, config: EmbeddingConfig) -> None:  # noqa: F821
        """注入用户自定义 embedding 的 env。"""
        if config.api_key:
            os.environ["EMBEDDING_API_KEY"] = config.api_key
        if config.base_url:
            os.environ["EMBEDDING_BASE_URL"] = config.base_url
        if config.model_name:
            os.environ["EMBEDDING_MODEL_NAME"] = config.model_name
        if config.dimensions:
            os.environ["EMBEDDING_DIMENSIONS"] = str(config.dimensions)
        logger.info(
            "✓ Embedding ready: provider=custom, base_url=%s, model=%s (HTTP)",
            config.base_url,
            config.model_name,
        )

    def _inject_local_envs(self) -> None:
        """将本地 embedding server 的参数注入 os.environ。

        MemoryManager.get_emb_envs() 从 EMBEDDING_* 读取，这里我们
        注入一个指向本地进程内服务的虚拟 HTTP 地址（实际不走 HTTP，
        直接由 EmbeddingManager 代理），key 固定为 "local"。
        """
        if self._local_server is None:
            return
        os.environ["EMBEDDING_API_KEY"] = "local"
        os.environ["EMBEDDING_BASE_URL"] = self._local_server.get_base_url()
        os.environ["EMBEDDING_MODEL_NAME"] = self._local_server.model_name
        if self._local_server.dimensions:
            os.environ["EMBEDDING_DIMENSIONS"] = str(self._local_server.dimensions)

    def _publish_local_server(self) -> None:
        """Publish local server to module-level global for in-process access."""
        global _active_local_server
        _active_local_server = self._local_server

    def _unpublish_local_server(self) -> None:
        """Clear module-level global reference on shutdown."""
        global _active_local_server
        _active_local_server = None

    @staticmethod
    def _clear_embedding_envs() -> None:
        """清除 embedding 相关 env，确保向量搜索被禁用。"""
        for key in (
            "EMBEDDING_API_KEY",
            "EMBEDDING_BASE_URL",
            "EMBEDDING_MODEL_NAME",
            "EMBEDDING_DIMENSIONS",
        ):
            os.environ.pop(key, None)

    async def _do_download(self, config: EmbeddingConfig) -> None:  # noqa: F821
        """后台下载任务（被 trigger_local_model_download 调用）。"""
        from .local_server import LocalEmbeddingServer  # pylint: disable=import-outside-toplevel

        done_event = asyncio.Event()

        async def _fake_progress() -> None:
            """在下载完成前持续推进模拟进度（最高到 0.95，留给真正完成时跳 1.0）。"""
            # 前 30s 快速推进到 0.7，之后缓慢爬升到 0.95
            thresholds = [
                (30, 0.7, 1.0),  # 30s 内推进到 70%，每秒 +1/30 * 0.7
                (120, 0.95, 3.0),  # 再 120s 推进到 95%，每 3s 一次
            ]
            for duration, target, interval in thresholds:
                steps = int(duration / interval)
                step_size = (target - self._download_state.progress) / max(steps, 1)
                for _ in range(steps):
                    if done_event.is_set():
                        return
                    await asyncio.sleep(interval)
                    if done_event.is_set():
                        return
                    new_progress = min(self._download_state.progress + step_size, target)
                    self._download_state.progress = new_progress
                    # 仅在仍处于下载中状态时广播
                    if self._download_state.status == DownloadStatus.DOWNLOADING:
                        await self._broadcast_download_state()

        try:
            server = LocalEmbeddingServer(model_name=config.local_model)
            # 并发：模拟进度推进 + 真正下载
            progress_task = asyncio.create_task(_fake_progress())
            try:
                await server.initialize()
            finally:
                done_event.set()
                progress_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await progress_task
            self._local_server = server
            self._provider = "local"
            self._inject_local_envs()
            self._publish_local_server()
            # 自动持久化：将 provider 切换为 local 并保存到配置文件
            try:
                from ...config import load_config, save_config  # pylint: disable=import-outside-toplevel

                app_config = load_config()
                app_config.embedding = config
                save_config(app_config)
                logger.info("Embedding config auto-saved as provider=local.")
            except Exception as save_exc:
                logger.warning("Failed to auto-save embedding config: %s", save_exc)
            self._download_state.status = DownloadStatus.DONE
            self._download_state.progress = 1.0
            await self._broadcast_download_state()
            logger.info(
                "Local embedding model '%s' downloaded and ready.",
                config.local_model,
            )
        except Exception as exc:
            self._download_state.status = DownloadStatus.FAILED
            self._download_state.error = str(exc)
            await self._broadcast_download_state()
            logger.error("Local embedding download failed: %s", exc)
