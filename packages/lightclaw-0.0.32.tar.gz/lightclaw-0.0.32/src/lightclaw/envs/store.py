"""Reading and writing environment variables.

Persistence strategy (two layers):

1. **WORKING_DIR/.env** – canonical store in dotenv format, survives process
   restarts.  Falls back to reading the legacy ``envs.json`` once and migrates
   the data automatically.
2. **os.environ** – injected into the current Python process so that
   ``os.getenv()`` and child subprocesses (``subprocess.run``, etc.)
   can read them immediately.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

_DEFAULT_ENV_TEMPLATE = """# LightClaw workspace environment variables
# This file is auto-created on first startup.
#
# Langfuse observability (optional)
# Fill in your own values to enable Langfuse tracing.
LANGFUSE_PUBLIC_KEY=
LANGFUSE_SECRET_KEY=
LANGFUSE_BASE_URL=
# Optional legacy alias. Usually you only need LANGFUSE_BASE_URL.
# LANGFUSE_HOST=
"""

_last_loaded_envs: dict[str, str] = {}


def _get_base_dir() -> Path:
    """Return BASE_DIR (lazy import to avoid circular dependencies)."""
    from ..constant import BASE_DIR

    return BASE_DIR


def _get_working_dir() -> Path:
    """Return WORKING_DIR (lazy import to avoid circular dependencies)."""
    from ..constant import WORKING_DIR

    return WORKING_DIR


def get_env_file_path() -> Path:
    """Return the path to the canonical .env file inside WORKING_DIR."""
    return _get_working_dir() / ".env"


# Legacy paths – used only for one-time migration
def _get_legacy_base_env_path() -> Path:
    """Return the legacy .env path inside BASE_DIR."""
    return _get_base_dir() / ".env"


def _get_legacy_envs_json_path() -> Path:
    return Path(__file__).resolve().parent / "envs.json"


# ------------------------------------------------------------------
# dotenv format helpers
# ------------------------------------------------------------------


def _parse_dotenv(text: str) -> dict[str, str]:
    """Parse a dotenv-formatted string into a dict.

    Supports:
    - ``KEY=value``
    - ``KEY="quoted value"`` / ``KEY='quoted value'``
    - Blank lines and ``# comments`` are ignored.
    - Multi-line values are **not** supported (not needed here).
    """
    result: dict[str, str] = {}
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            continue
        key, _, raw_value = line.partition("=")
        key = key.strip()
        if not key:
            continue
        value = raw_value.strip()
        # Strip surrounding quotes (single or double)
        if len(value) >= 2 and value[0] == value[-1] and value[0] in ('"', "'"):
            value = value[1:-1]
        result[key] = value
    return result


def _serialize_dotenv(envs: dict[str, str]) -> str:
    """Serialise *envs* to dotenv format.

    Values that contain spaces, ``=``, ``#``, or newlines are
    double-quoted.  Single ``"`` inside values is escaped as ``\\"``.
    """
    lines: list[str] = []
    for key in sorted(envs):
        value = envs[key]
        needs_quotes = any(c in value for c in (" ", "\t", "=", "#", '"', "'", "\n", "\r"))
        if needs_quotes:
            escaped = value.replace("\\", "\\\\").replace('"', '\\"')
            lines.append(f'{key}="{escaped}"')
        else:
            lines.append(f"{key}={value}")
    return "\n".join(lines) + ("\n" if lines else "")


# ------------------------------------------------------------------
# os.environ helpers
# ------------------------------------------------------------------


def _apply_to_environ(envs: dict[str, str]) -> None:
    """Set every key/value into ``os.environ``."""
    for key, value in envs.items():
        os.environ[key] = value


def _remove_from_environ(key: str) -> None:
    """Remove *key* from ``os.environ`` if present."""
    os.environ.pop(key, None)


def _sync_environ(
    old: dict[str, str],
    new: dict[str, str],
) -> None:
    """Synchronise ``os.environ``: set *new*, remove stale *old*."""
    for key in old:
        if key not in new:
            _remove_from_environ(key)
    _apply_to_environ(new)


# ------------------------------------------------------------------
# Migration from legacy envs.json
# ------------------------------------------------------------------


def _migrate_from_legacy_json(dot_env_path: Path) -> dict[str, str]:
    """If the legacy envs.json exists and .env does not, migrate once.

    Returns the migrated dict (empty dict if no migration was needed).
    """
    legacy = _get_legacy_envs_json_path()
    if not legacy.is_file():
        return {}
    try:
        with open(legacy, encoding="utf-8") as fh:
            data = json.load(fh)
        if not isinstance(data, dict):
            return {}
        envs = {k: str(v) for k, v in data.items()}
    except (json.JSONDecodeError, ValueError, OSError):
        return {}

    # Write to new location
    dot_env_path.parent.mkdir(parents=True, exist_ok=True)
    dot_env_path.write_text(_serialize_dotenv(envs), encoding="utf-8")

    # Rename legacy file so migration only happens once
    legacy.rename(legacy.with_suffix(".json.bak"))

    return envs


def _migrate_from_legacy_base_env(dot_env_path: Path) -> dict[str, str]:
    """If legacy BASE_DIR/.env exists and WORKING_DIR/.env does not, copy once."""
    legacy = _get_legacy_base_env_path()
    if legacy.resolve() == dot_env_path.resolve() or not legacy.is_file():
        return {}
    try:
        text = legacy.read_text(encoding="utf-8")
        envs = _parse_dotenv(text)
        if not envs:
            return {}
    except OSError:
        return {}

    dot_env_path.parent.mkdir(parents=True, exist_ok=True)
    dot_env_path.write_text(_serialize_dotenv(envs), encoding="utf-8")
    return envs


def ensure_env_file(path: Path | None = None) -> Path:
    """Ensure WORKING_DIR/.env exists, creating a template when missing."""
    if path is None:
        path = get_env_file_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.write_text(_DEFAULT_ENV_TEMPLATE, encoding="utf-8")
    return path


# ------------------------------------------------------------------
# .env persistence
# ------------------------------------------------------------------


def load_envs(
    path: Path | None = None,
) -> dict[str, str]:
    """Load env vars from WORKING_DIR/.env (dotenv format)."""
    if path is None:
        path = get_env_file_path()
    if not path.is_file():
        legacy_base_envs = _migrate_from_legacy_base_env(path)
        if legacy_base_envs:
            return legacy_base_envs
        # Try one-time migration from legacy envs.json
        legacy_json_envs = _migrate_from_legacy_json(path)
        if legacy_json_envs:
            return legacy_json_envs
        ensure_env_file(path)
        return {}
    try:
        text = path.read_text(encoding="utf-8")
        return _parse_dotenv(text)
    except OSError:
        return {}


def save_envs(
    envs: dict[str, str],
    path: Path | None = None,
) -> None:
    """Write env vars to WORKING_DIR/.env and sync to ``os.environ``."""
    old = load_envs(path)

    if path is None:
        path = get_env_file_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(_serialize_dotenv(envs), encoding="utf-8")

    _sync_environ(old, envs)


def set_env_var(
    key: str,
    value: str,
) -> dict[str, str]:
    """Set a single env var. Returns updated dict."""
    envs = load_envs()
    envs[key] = value
    save_envs(envs)
    return envs


def delete_env_var(key: str) -> dict[str, str]:
    """Delete a single env var. Returns updated dict."""
    envs = load_envs()
    envs.pop(key, None)
    save_envs(envs)
    return envs


_DEFAULT_ENVS: dict[str, str] = {
    "TENCENT_CLOUD_SECRET_ID": "",
    "TENCENT_CLOUD_SECRET_KEY": "",
}


def load_envs_into_environ() -> dict[str, str]:
    """Load WORKING_DIR/.env and apply all entries to ``os.environ``.

    Call this once at application startup so that environment
    variables persisted from a previous session are available
    immediately.  Also injects default placeholder entries for
    well-known keys (e.g. Tencent Cloud credentials) when they
    are not already present.
    """
    global _last_loaded_envs
    envs = load_envs()

    # Inject default entries that are not yet persisted.
    changed = False
    for key, default_value in _DEFAULT_ENVS.items():
        if key not in envs:
            envs[key] = default_value
            changed = True
    if changed:
        save_envs(envs)

    _sync_environ(_last_loaded_envs, envs)
    _last_loaded_envs = dict(envs)
    return envs
