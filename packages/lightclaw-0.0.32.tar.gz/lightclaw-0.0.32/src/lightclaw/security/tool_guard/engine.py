"""ToolGuard 引擎 — 编排所有已注册的 guardian。

用法::

    engine = ToolGuardEngine()
    result = engine.guard("execute_shell_command", {"command": "rm -rf /"})
    if not result.is_safe:
        logger.warning("Tool guard found issues: %s", result.max_severity)
"""

from __future__ import annotations

import logging
import os
import time
from typing import Any

from .guardians import BaseToolGuardian
from .guardians.rule_guardian import RuleBasedToolGuardian
from .models import ToolGuardResult

logger = logging.getLogger(__name__)

_TRUE_STRINGS = {"true", "1", "yes"}


def _guard_enabled() -> bool:
    """返回 tool-call guarding 是否启用。优先读取环境变量。"""
    env_val = os.environ.get("LIGHTCLAW_TOOL_GUARD_ENABLED")
    if env_val is not None:
        return env_val.lower() in _TRUE_STRINGS
    # 默认启用
    return True


class ToolGuardEngine:
    """编排所有已注册 guardian 的引擎。"""

    def __init__(
        self,
        guardians: list[BaseToolGuardian] | None = None,
        *,
        enabled: bool | None = None,
    ) -> None:
        self._enabled = enabled if enabled is not None else _guard_enabled()

        if guardians is not None:
            self._guardians = list(guardians)
        else:
            self._guardians = self._default_guardians()

        self._reload_tool_sets()

    @staticmethod
    def _default_guardians() -> list[BaseToolGuardian]:
        guardians: list[BaseToolGuardian] = []
        try:
            guardians.append(RuleBasedToolGuardian())
        except Exception as exc:
            logger.warning("Failed to initialise RuleBasedToolGuardian: %s", exc)
        return guardians

    def register_guardian(self, guardian: BaseToolGuardian) -> None:
        self._guardians.append(guardian)
        logger.debug("Registered tool guardian: %s", guardian.name)

    def unregister_guardian(self, name: str) -> bool:
        before = len(self._guardians)
        self._guardians = [g for g in self._guardians if g.name != name]
        return len(self._guardians) < before

    @property
    def guardian_names(self) -> list[str]:
        return [g.name for g in self._guardians]

    @property
    def enabled(self) -> bool:
        return self._enabled

    @enabled.setter
    def enabled(self, value: bool) -> None:
        self._enabled = value

    @property
    def guarded_tools(self) -> set[str] | None:
        return self._guarded_tools

    @property
    def denied_tools(self) -> set[str]:
        return self._denied_tools

    def _reload_tool_sets(self) -> None:
        from .utils import resolve_denied_tools, resolve_guarded_tools

        self._guarded_tools: set[str] | None = resolve_guarded_tools()
        self._denied_tools: set[str] = resolve_denied_tools()

    def reload_rules(self) -> None:
        for g in self._guardians:
            if hasattr(g, "reload"):
                g.reload()
        self._reload_tool_sets()

    def is_denied(self, tool_name: str) -> bool:
        return tool_name in self._denied_tools

    def is_guarded(self, tool_name: str) -> bool:
        if self._guarded_tools is None:
            return True
        return tool_name in self._guarded_tools

    def guard(
        self,
        tool_name: str,
        params: dict[str, Any],
    ) -> ToolGuardResult | None:
        """检查工具调用参数。

        返回 None 表示 guarding 已禁用。
        """
        if not self._enabled:
            return None

        t0 = time.monotonic()
        result = ToolGuardResult(tool_name=tool_name, params=params)

        for guardian in self._guardians:
            try:
                findings = guardian.guard(tool_name, params)
                result.findings.extend(findings)
                result.guardians_used.append(guardian.name)
            except Exception as exc:
                logger.warning(
                    "Tool guardian '%s' failed on tool '%s': %s",
                    guardian.name,
                    tool_name,
                    exc,
                )
                result.guardians_failed.append({"name": guardian.name, "error": str(exc)})

        result.guard_duration_seconds = time.monotonic() - t0
        return result


_engine_instance: ToolGuardEngine | None = None


def get_guard_engine() -> ToolGuardEngine:
    """返回懒加载的 ToolGuardEngine 单例。"""
    global _engine_instance
    if _engine_instance is None:
        _engine_instance = ToolGuardEngine()
    return _engine_instance
