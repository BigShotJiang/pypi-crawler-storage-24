"""敏感工具执行的审批服务。

ApprovalService 是 pending/completed 审批记录的中央存储。
审批通过 /approve 命令在聊天界面中触发。
"""

from __future__ import annotations

import asyncio
import logging
import time
import uuid
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from .approval import ApprovalDecision

if TYPE_CHECKING:
    from .models import ToolGuardResult

logger = logging.getLogger(__name__)

_GC_MAX_AGE_SECONDS = 3600.0
_GC_MAX_COMPLETED = 500
_GC_PENDING_MAX_AGE_SECONDS = 1800.0
_GC_MAX_PENDING = 200


@dataclass
class PendingApproval:
    """单条 pending 审批的内存记录。"""

    request_id: str
    session_id: str
    user_id: str
    channel: str
    tool_name: str
    created_at: float
    future: asyncio.Future[ApprovalDecision]
    status: str = "pending"
    resolved_at: float | None = None
    result_summary: str = ""
    findings_count: int = 0
    extra: dict[str, Any] = field(default_factory=dict)


class ApprovalService:
    """中央审批服务。

    跟踪 pending 和 completed 审批记录。
    审批通过 /approve 命令解决（见 runner.py）。
    """

    def __init__(self) -> None:
        self._lock = asyncio.Lock()
        self._pending: dict[str, PendingApproval] = {}
        self._completed: dict[str, PendingApproval] = {}

    async def create_pending(
        self,
        *,
        session_id: str,
        user_id: str,
        channel: str,
        tool_name: str,
        result: ToolGuardResult,
        extra: dict[str, Any] | None = None,
    ) -> PendingApproval:
        """创建 pending 审批记录并返回。"""
        from .approval import format_findings_summary

        request_id = str(uuid.uuid4())
        loop = asyncio.get_running_loop()

        pending = PendingApproval(
            request_id=request_id,
            session_id=session_id,
            user_id=user_id,
            channel=channel,
            tool_name=tool_name,
            created_at=time.time(),
            future=loop.create_future(),
            result_summary=format_findings_summary(result),
            findings_count=result.findings_count,
            extra=dict(extra or {}),
        )

        async with self._lock:
            self._pending[request_id] = pending
            self._gc_pending_locked()
            self._gc_completed_locked()

        return pending

    async def resolve_request(
        self,
        request_id: str,
        decision: ApprovalDecision,
    ) -> PendingApproval | None:
        """解决一条 pending 审批请求。"""
        async with self._lock:
            pending = self._pending.pop(request_id, None)
            if pending is None:
                return self._completed.get(request_id)

            pending.status = decision.value
            pending.resolved_at = time.time()
            self._completed[request_id] = pending
            self._gc_completed_locked()

        if not pending.future.done():
            pending.future.set_result(decision)

        return pending

    async def get_request(self, request_id: str) -> PendingApproval | None:
        async with self._lock:
            return self._pending.get(request_id) or self._completed.get(request_id)

    async def get_pending_by_session(
        self,
        session_id: str,
    ) -> PendingApproval | None:
        """返回该 session_id 最近的 pending 审批。"""
        async with self._lock:
            for pending in reversed(list(self._pending.values())):
                if pending.session_id == session_id and pending.status == "pending":
                    return pending
        return None

    async def consume_approval(
        self,
        session_id: str,
        tool_name: str,
        tool_params: dict[str, Any] | None = None,
    ) -> bool:
        """检查并消费一次性工具审批。

        如果 tool_name 已通过 /approve 批准，移除 completed 记录并返回 True。
        当 tool_params 不为 None 时，会比较参数，防止批准的 rm foo.txt 被用于执行 rm -rf /。
        """
        async with self._lock:
            for key, completed in list(self._completed.items()):
                if (
                    completed.session_id == session_id
                    and completed.tool_name == tool_name
                    and completed.status == "approved"
                ):
                    if tool_params is not None:
                        approved_call = completed.extra.get("tool_call", {})
                        approved_params = approved_call.get("input", {})
                        if approved_params != tool_params:
                            logger.warning(
                                "Tool guard: params mismatch for '%s' (session %s), rejecting stale approval",
                                tool_name,
                                session_id[:8],
                            )
                            del self._completed[key]
                            return False
                    del self._completed[key]
                    return True
        return False

    # ------------------------------------------------------------------
    # 垃圾回收
    # ------------------------------------------------------------------

    def _gc_pending_locked(self) -> None:
        """清理超时的 pending 记录（调用方需持有 _lock）。"""
        now = time.time()
        expired = [k for k, v in self._pending.items() if now - v.created_at > _GC_PENDING_MAX_AGE_SECONDS]
        for k in expired:
            pending = self._pending.pop(k)
            if not pending.future.done():
                pending.future.set_result(ApprovalDecision.TIMEOUT)
            pending.status = "timeout"
            pending.resolved_at = now
            self._completed[k] = pending

        overflow = len(self._pending) - _GC_MAX_PENDING
        if overflow <= 0:
            return
        ordered = sorted(self._pending.items(), key=lambda item: item[1].created_at)
        for key, pending in ordered[:overflow]:
            del self._pending[key]
            if not pending.future.done():
                pending.future.set_result(ApprovalDecision.TIMEOUT)
            pending.status = "timeout"
            pending.resolved_at = now
            self._completed[key] = pending

    def _gc_completed_locked(self) -> None:
        """清理过期/溢出的 completed 记录（调用方需持有 _lock）。"""
        now = time.time()
        expired = [k for k, v in self._completed.items() if v.resolved_at and now - v.resolved_at > _GC_MAX_AGE_SECONDS]
        for k in expired:
            del self._completed[k]

        overflow = len(self._completed) - _GC_MAX_COMPLETED
        if overflow <= 0:
            return
        ordered = sorted(
            self._completed.items(),
            key=lambda item: item[1].resolved_at or item[1].created_at,
        )
        for key, _ in ordered[:overflow]:
            del self._completed[key]


# ------------------------------------------------------------------
# 单例
# ------------------------------------------------------------------

_approval_service: ApprovalService | None = None


def get_approval_service() -> ApprovalService:
    """返回进程级 ApprovalService 单例。"""
    global _approval_service
    if _approval_service is None:
        _approval_service = ApprovalService()
    return _approval_service
