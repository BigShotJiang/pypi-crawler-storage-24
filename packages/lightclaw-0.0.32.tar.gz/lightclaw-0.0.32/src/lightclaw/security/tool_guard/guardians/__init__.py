"""BaseToolGuardian 抽象基类。"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from ..models import GuardFinding


class BaseToolGuardian(ABC):
    """所有 tool-call guardian 的抽象基类。"""

    def __init__(self, name: str) -> None:
        self.name = name

    @abstractmethod
    def guard(
        self,
        tool_name: str,
        params: dict[str, Any],
    ) -> list[GuardFinding]:
        """检查工具调用参数是否存在安全问题。

        返回发现列表，空列表表示无问题。
        """

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__} name={self.name!r}>"
