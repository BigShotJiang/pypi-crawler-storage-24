"""基于 YAML 正则规则的工具调用 guardian。

规则格式（每个威胁类别一个 YAML 文件）::

    - id: SHELL_PIPE_TO_EXEC
      tool: execute_shell_command    # 可选：空 = 匹配所有工具
      params: [command]              # 可选：空 = 匹配所有参数
      category: command_injection
      severity: HIGH
      patterns:
        - "curl.*\\|.*(?:sh|bash)"
      exclude_patterns:             # 可选
        - "^#"
      description: "将下载内容直接管道到 shell"
      remediation: "先下载到文件，检查后再执行"
"""

from __future__ import annotations

import logging
import re
import uuid
from pathlib import Path
from typing import Any

import yaml

from ..models import GuardFinding, GuardSeverity, GuardThreatCategory
from . import BaseToolGuardian

logger = logging.getLogger(__name__)

# 默认规则目录（随包发布）
_DEFAULT_RULES_DIR = Path(__file__).resolve().parent.parent / "rules"

# 默认加载的规则文件
_DEFAULT_RULE_FILES: list[str] = [
    "dangerous_shell_commands.yaml",
]


class GuardRule:
    """单条正则 guard 检测规则。"""

    __slots__ = (
        "category",
        "compiled_exclude_patterns",
        "compiled_patterns",
        "description",
        "exclude_patterns",
        "id",
        "params",
        "patterns",
        "remediation",
        "severity",
        "tools",
    )

    def __init__(self, rule_data: dict[str, Any]) -> None:
        self.id: str = rule_data["id"]

        raw_tool = rule_data.get("tool", rule_data.get("tools", []))
        if isinstance(raw_tool, str):
            self.tools: list[str] = [raw_tool] if raw_tool else []
        else:
            self.tools = list(raw_tool or [])

        raw_params = rule_data.get("params", rule_data.get("param", []))
        if isinstance(raw_params, str):
            self.params: list[str] = [raw_params] if raw_params else []
        else:
            self.params = list(raw_params or [])

        self.category = GuardThreatCategory(rule_data["category"])
        self.severity = GuardSeverity(rule_data["severity"])
        self.patterns: list[str] = rule_data.get("patterns", [])
        self.exclude_patterns: list[str] = rule_data.get("exclude_patterns", [])
        self.description: str = rule_data.get("description", "")
        self.remediation: str = rule_data.get("remediation", "")

        self.compiled_patterns: list[re.Pattern[str]] = []
        for pat in self.patterns:
            try:
                self.compiled_patterns.append(re.compile(pat, re.IGNORECASE))
            except re.error as exc:
                logger.warning("Bad regex in guard rule %s: %s", self.id, exc)

        self.compiled_exclude_patterns: list[re.Pattern[str]] = []
        for pat in self.exclude_patterns:
            try:
                self.compiled_exclude_patterns.append(re.compile(pat, re.IGNORECASE))
            except re.error as exc:
                logger.warning("Bad exclude regex in guard rule %s: %s", self.id, exc)

    def applies_to_tool(self, tool_name: str) -> bool:
        if not self.tools:
            return True
        return tool_name in self.tools

    def applies_to_param(self, param_name: str) -> bool:
        if not self.params:
            return True
        return param_name in self.params

    def match(self, value: str) -> tuple[re.Match[str] | None, str | None]:
        if any(ep.search(value) for ep in self.compiled_exclude_patterns):
            return None, None
        for pattern in self.compiled_patterns:
            m = pattern.search(value)
            if m:
                return m, pattern.pattern
        return None, None


def load_rules_from_yaml(yaml_path: Path) -> list[GuardRule]:
    """从单个 YAML 文件加载 guard 规则。"""
    try:
        with open(yaml_path, encoding="utf-8") as f:
            data = yaml.safe_load(f)
        if not isinstance(data, list):
            logger.warning("Expected a list in %s, got %s", yaml_path, type(data).__name__)
            return []
        rules: list[GuardRule] = []
        for item in data:
            if not isinstance(item, dict):
                continue
            try:
                rules.append(GuardRule(item))
            except Exception as exc:
                logger.warning(
                    "Skipping invalid rule %r in %s: %s",
                    item.get("id", "<no id>"),
                    yaml_path,
                    exc,
                )
        return rules
    except Exception as exc:
        logger.warning("Failed to load guard rules from %s: %s", yaml_path, exc)
        return []


def load_rules_from_directory(
    rules_dir: Path | None = None,
    *,
    rule_files: list[str] | None = None,
) -> list[GuardRule]:
    """从目录加载 YAML 规则文件。"""
    directory = rules_dir or _DEFAULT_RULES_DIR
    if not directory.is_dir():
        logger.warning("Guard rules directory not found: %s", directory)
        return []

    if rule_files is not None:
        yaml_files = [directory / f for f in rule_files]
    elif rules_dir is not None:
        yaml_files = sorted(directory.glob("*.yaml")) + sorted(directory.glob("*.yml"))
    else:
        yaml_files = [directory / f for f in _DEFAULT_RULE_FILES]

    rules: list[GuardRule] = []
    for yaml_file in yaml_files:
        if yaml_file.is_file():
            rules.extend(load_rules_from_yaml(yaml_file))
        else:
            logger.warning("Guard rule file not found: %s", yaml_file)

    logger.debug("Loaded %d guard rules from %s", len(rules), directory)
    return rules


class RuleBasedToolGuardian(BaseToolGuardian):
    """基于 YAML 正则规则的 guardian。"""

    def __init__(
        self,
        *,
        rules_dir: Path | None = None,
        extra_rules: list[GuardRule] | None = None,
    ) -> None:
        super().__init__(name="rule_based_tool_guardian")
        self._rules_dir = rules_dir
        self._extra_rules = list(extra_rules) if extra_rules else []
        self._rules: list[GuardRule] = []
        self._load_all_rules()

    def _load_all_rules(self) -> None:
        builtin = load_rules_from_directory(self._rules_dir)
        self._rules = builtin + self._extra_rules

    def reload(self) -> None:
        self._load_all_rules()
        logger.info("Reloaded guard rules: %d active", len(self._rules))

    @property
    def rules(self) -> list[GuardRule]:
        return list(self._rules)

    @property
    def rule_count(self) -> int:
        return len(self._rules)

    def guard(
        self,
        tool_name: str,
        params: dict[str, Any],
    ) -> list[GuardFinding]:
        """扫描所有字符串类型参数值，匹配已加载的规则。"""
        findings: list[GuardFinding] = []
        applicable_rules = [r for r in self._rules if r.applies_to_tool(tool_name)]

        if not applicable_rules:
            return findings

        for param_name, param_value in params.items():
            value_str = str(param_value) if param_value is not None else ""
            if not value_str:
                continue

            for rule in applicable_rules:
                if not rule.applies_to_param(param_name):
                    continue
                m, pattern_str = rule.match(value_str)
                if m:
                    start = max(0, m.start() - 40)
                    end = min(len(value_str), m.end() + 40)
                    snippet = value_str[start:end]

                    findings.append(
                        GuardFinding(
                            id=f"GUARD-{uuid.uuid4().hex}",
                            rule_id=rule.id,
                            category=rule.category,
                            severity=rule.severity,
                            title=f"[{rule.severity.value}] {rule.description}",
                            description=(f"Rule {rule.id} matched parameter '{param_name}' of tool '{tool_name}'."),
                            tool_name=tool_name,
                            param_name=param_name,
                            matched_value=m.group(0),
                            matched_pattern=pattern_str,
                            snippet=snippet,
                            remediation=rule.remediation,
                            guardian=self.name,
                        ),
                    )
        return findings
