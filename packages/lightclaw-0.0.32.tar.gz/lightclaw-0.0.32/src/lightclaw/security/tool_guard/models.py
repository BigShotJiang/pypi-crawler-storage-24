"""ToolGuard 数据模型。

移植自 CoPaw security/tool_guard/models.py，去除 CoPaw 依赖。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any

# 附加在被 tool-guard 拒绝的消息上的标记，用于跨模块识别和清理。
TOOL_GUARD_DENIED_MARK = "tool_guard_denied"


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class GuardSeverity(StrEnum):
    """Guard 发现的严重级别。"""

    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"
    INFO = "INFO"
    SAFE = "SAFE"


class GuardThreatCategory(StrEnum):
    """工具参数中可检测的威胁类别。"""

    COMMAND_INJECTION = "command_injection"
    DATA_EXFILTRATION = "data_exfiltration"
    PATH_TRAVERSAL = "path_traversal"
    SENSITIVE_FILE_ACCESS = "sensitive_file_access"
    NETWORK_ABUSE = "network_abuse"
    CREDENTIAL_EXPOSURE = "credential_exposure"
    RESOURCE_ABUSE = "resource_abuse"
    PROMPT_INJECTION = "prompt_injection"
    CODE_EXECUTION = "code_execution"
    PRIVILEGE_ESCALATION = "privilege_escalation"


# ---------------------------------------------------------------------------
# GuardFinding
# ---------------------------------------------------------------------------


@dataclass
class GuardFinding:
    """单条安全发现。"""

    id: str
    rule_id: str
    category: GuardThreatCategory
    severity: GuardSeverity
    title: str
    description: str
    tool_name: str
    param_name: str | None = None
    matched_value: str | None = None
    matched_pattern: str | None = None
    snippet: str | None = None
    remediation: str | None = None
    guardian: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "rule_id": self.rule_id,
            "category": self.category.value,
            "severity": self.severity.value,
            "title": self.title,
            "description": self.description,
            "tool_name": self.tool_name,
            "param_name": self.param_name,
            "matched_value": self.matched_value,
            "matched_pattern": self.matched_pattern,
            "snippet": self.snippet,
            "remediation": self.remediation,
            "guardian": self.guardian,
            "metadata": self.metadata,
        }


# ---------------------------------------------------------------------------
# ToolGuardResult
# ---------------------------------------------------------------------------


@dataclass
class ToolGuardResult:
    """单次工具调用的 guard 聚合结果。"""

    tool_name: str
    params: dict[str, Any]
    findings: list[GuardFinding] = field(default_factory=list)
    guard_duration_seconds: float = 0.0
    guardians_used: list[str] = field(default_factory=list)
    guardians_failed: list[dict[str, str]] = field(default_factory=list)
    timestamp: datetime = field(
        default_factory=lambda: datetime.now(UTC),
    )

    @property
    def is_safe(self) -> bool:
        """无 CRITICAL 或 HIGH 发现时返回 True。"""
        return not any(f.severity in (GuardSeverity.CRITICAL, GuardSeverity.HIGH) for f in self.findings)

    @property
    def max_severity(self) -> GuardSeverity:
        """返回最高严重级别，无发现时返回 SAFE。"""
        if not self.findings:
            return GuardSeverity.SAFE
        order = [
            GuardSeverity.CRITICAL,
            GuardSeverity.HIGH,
            GuardSeverity.MEDIUM,
            GuardSeverity.LOW,
            GuardSeverity.INFO,
        ]
        for sev in order:
            if any(f.severity == sev for f in self.findings):
                return sev
        return GuardSeverity.SAFE

    @property
    def findings_count(self) -> int:
        return len(self.findings)

    def to_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "tool_name": self.tool_name,
            "params": {k: _safe_repr(v) for k, v in self.params.items()},
            "is_safe": self.is_safe,
            "max_severity": self.max_severity.value,
            "findings_count": self.findings_count,
            "findings": [f.to_dict() for f in self.findings],
            "guard_duration_seconds": self.guard_duration_seconds,
            "guardians_used": self.guardians_used,
            "timestamp": self.timestamp.isoformat(),
        }
        if self.guardians_failed:
            result["guardians_failed"] = self.guardians_failed
        return result


def _safe_repr(value: Any, max_len: int = 200) -> str:
    s = str(value)
    if len(s) > max_len:
        return s[:max_len] + "…"
    return s
