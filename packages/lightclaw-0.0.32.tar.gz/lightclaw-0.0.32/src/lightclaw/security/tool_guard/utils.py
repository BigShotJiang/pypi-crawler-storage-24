"""工具 guard 工具函数：配置解析 + 日志。"""

from __future__ import annotations

import logging
import os
from collections.abc import Iterable
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .models import ToolGuardResult

logger = logging.getLogger(__name__)

# 默认受保护的高风险工具集
_DEFAULT_GUARDED_TOOLS = frozenset(
    {
        "execute_shell_command",
    },
)


def _parse_guarded_tokens(tokens: Iterable[str]) -> set[str] | None:
    """解析受保护工具 token 列表为集合。None 表示保护所有工具。"""
    normalized = {item.strip() for item in tokens if item and item.strip()}
    if not normalized:
        return set()
    lowered = {item.lower() for item in normalized}
    if "*" in lowered or "all" in lowered:
        return None
    if lowered.issubset({"none", "off", "false", "0"}):
        return set()
    return normalized


def resolve_guarded_tools(
    user_defined: set[str] | list[str] | tuple[str, ...] | None = None,
) -> set[str] | None:
    """解析受保护工具集合。

    优先级：
    1) 构造函数传入的 user_defined
    2) LIGHTCLAW_TOOL_GUARD_TOOLS 环境变量
    3) 内置默认集合（execute_shell_command）

    返回 None 表示保护所有工具。
    """
    if user_defined is not None:
        return _parse_guarded_tokens(user_defined)

    raw = os.environ.get("LIGHTCLAW_TOOL_GUARD_TOOLS")
    if raw is not None:
        normalized = raw.strip().lower()
        if normalized in {"*", "all"}:
            return None
        if normalized in {"", "none", "off", "false", "0"}:
            return set()
        return _parse_guarded_tokens(raw.split(","))

    return set(_DEFAULT_GUARDED_TOOLS)


def resolve_denied_tools(
    user_defined: set[str] | list[str] | tuple[str, ...] | None = None,
) -> set[str]:
    """解析无条件拒绝的工具集合。

    优先级：
    1) 构造函数传入的 user_defined
    2) LIGHTCLAW_TOOL_GUARD_DENIED_TOOLS 环境变量（逗号分隔）
    3) 内置默认（空集合）
    """
    if user_defined is not None:
        return set(user_defined)

    raw = os.environ.get("LIGHTCLAW_TOOL_GUARD_DENIED_TOOLS")
    if raw is not None:
        return {t.strip() for t in raw.split(",") if t.strip()}

    return set()


def log_findings(tool_name: str, result: ToolGuardResult) -> None:
    """为每条发现输出结构化日志。"""
    from .models import GuardSeverity

    _HIGH_SEVERITIES = (GuardSeverity.CRITICAL, GuardSeverity.HIGH)

    for finding in result.findings:
        log_fn = logger.warning if finding.severity in _HIGH_SEVERITIES else logger.info
        log_fn(
            "[TOOL GUARD] %s | tool=%s param=%s rule=%s | %s | matched=%r",
            finding.severity.value,
            tool_name,
            finding.param_name or "*",
            finding.rule_id,
            finding.description,
            finding.matched_value,
        )

    summary_fn = logger.warning if result.max_severity in _HIGH_SEVERITIES else logger.info
    summary_fn(
        "[TOOL GUARD] Summary for tool '%s': %d finding(s), max_severity=%s, duration=%.3fs",
        tool_name,
        result.findings_count,
        result.max_severity.value,
        result.guard_duration_seconds,
    )
