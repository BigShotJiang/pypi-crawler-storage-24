"""审批决策枚举和格式化工具。"""

from __future__ import annotations

from enum import StrEnum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .models import ToolGuardResult


class ApprovalDecision(StrEnum):
    """工具 guard 审批结果。"""

    APPROVED = "approved"
    DENIED = "denied"
    TIMEOUT = "timeout"


def format_findings_summary(
    result: ToolGuardResult,
    *,
    max_items: int = 3,
) -> str:
    """将发现格式化为简洁的 Markdown 摘要。"""
    if not result.findings:
        return "No specific risk rules matched."

    lines = []
    for finding in result.findings[:max_items]:
        lines.append(
            f"- [{finding.severity.value}] {finding.description}",
        )
    remaining = result.findings_count - len(lines)
    if remaining > 0:
        lines.append(f"- ... and {remaining} more finding(s) omitted")
    return "\n".join(lines)
