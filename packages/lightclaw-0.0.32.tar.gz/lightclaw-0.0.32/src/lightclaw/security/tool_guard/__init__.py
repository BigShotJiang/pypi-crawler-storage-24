"""
Finnie ToolGuard — 工具调用前安全拦截框架。

在工具执行前扫描参数，检测危险模式（命令注入、数据泄露、敏感文件访问等），
并通过 /approve 命令实现人工审批机制，支持所有 Channel（CLI/QQ/飞书等）。

快速开始::

    from lightclaw.security.tool_guard import ToolGuardEngine

    engine = ToolGuardEngine()
    result = engine.guard("execute_shell_command", {"command": "rm -rf /"})
    if not result.is_safe:
        print(f"WARN: {result.max_severity.value} findings")
"""

from __future__ import annotations

from .approval import ApprovalDecision, format_findings_summary
from .engine import ToolGuardEngine, get_guard_engine
from .guardians import BaseToolGuardian
from .guardians.rule_guardian import RuleBasedToolGuardian
from .models import (
    TOOL_GUARD_DENIED_MARK,
    GuardFinding,
    GuardSeverity,
    GuardThreatCategory,
    ToolGuardResult,
)
from .service import ApprovalService, PendingApproval, get_approval_service

__all__ = [
    "TOOL_GUARD_DENIED_MARK",
    "ApprovalDecision",
    "ApprovalService",
    "BaseToolGuardian",
    "GuardFinding",
    "GuardSeverity",
    "GuardThreatCategory",
    "PendingApproval",
    "RuleBasedToolGuardian",
    "ToolGuardEngine",
    "ToolGuardResult",
    "format_findings_summary",
    "get_approval_service",
    "get_guard_engine",
]
