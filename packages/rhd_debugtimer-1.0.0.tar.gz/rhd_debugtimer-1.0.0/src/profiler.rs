use std::collections::HashMap;

use crate::stats::FunctionStats;

pub struct Profiler {
    pub data: HashMap<String, FunctionStats>,
}

impl Profiler {
    pub fn new() -> Self {
        Self {
            data: HashMap::new(),
        }
    }

    pub fn record(&mut self, name: String, duration: f64) {
        let entry = self.data.entry(name).or_insert(FunctionStats::new());
        entry.update(duration);
    }
}