use std::fmt;

#[derive(Clone)]
pub struct FunctionStats {
    pub calls: u64,
    pub total_time: f64,
    pub min_time: f64,
    pub max_time: f64,
}

impl FunctionStats {
    pub fn new() -> Self {
        Self {
            calls: 0,
            total_time: 0.0,
            min_time: f64::MAX,
            max_time: 0.0,
        }
    }

    pub fn update(&mut self, duration: f64) {
        self.calls += 1;
        self.total_time += duration;

        if duration < self.min_time {
            self.min_time = duration;
        }

        if duration > self.max_time {
            self.max_time = duration;
        }
    }

    pub fn average(&self) -> f64 {
        if self.calls == 0 {
            0.0
        } else {
            self.total_time / self.calls as f64
        }
    }
}

impl fmt::Display for FunctionStats {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "calls: {}, total: {:.6}, avg: {:.6}, min: {:.6}, max: {:.6}",
            self.calls,
            self.total_time,
            self.average(),
            self.min_time,
            self.max_time
        )
    }
}