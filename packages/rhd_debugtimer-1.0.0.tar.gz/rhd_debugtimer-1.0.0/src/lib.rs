use pyo3::prelude::*;
use once_cell::sync::Lazy;
use parking_lot::Mutex;

mod profiler;
mod stats;

use profiler::Profiler;

static GLOBAL_PROFILER: Lazy<Mutex<Profiler>> =
    Lazy::new(|| Mutex::new(Profiler::new()));

#[pyfunction]
fn record(name: String, duration: f64) {
    let mut profiler = GLOBAL_PROFILER.lock();
    profiler.record(name, duration);
}

#[pyfunction]
fn results() -> Vec<(String, u64, f64, f64, f64)> {
    let profiler = GLOBAL_PROFILER.lock();

    profiler
        .data
        .iter()
        .map(|(name, stat)| {
            (
                name.clone(),
                stat.calls,
                stat.total_time,
                stat.min_time,
                stat.max_time,
            )
        })
        .collect()
}

#[pymodule]
fn debugtimer(_py: Python, m: &PyModule) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(record, m)?)?;
    m.add_function(wrap_pyfunction!(results, m)?)?;
    Ok(())
}