"""Version information for bb2gh."""

__version__ = "0.20.0"
