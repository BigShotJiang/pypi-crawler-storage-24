"""bb2gh adapters package - source and target system adapters."""

from migration_core.adapters.github.multi_app import GitHubAppConfig, MultiAppGitHubAdapter

from bb2gh.adapters.base import BitbucketSourceAdapter, SourceAdapter, TargetAdapter
from bb2gh.adapters.bitbucket_cloud import BitbucketCloudAdapter
from bb2gh.adapters.bitbucket_dc import BitbucketDCAdapter
from bb2gh.adapters.github_base import GitHubBaseAdapter
from bb2gh.adapters.github_cloud import GitHubCloudAdapter
from bb2gh.adapters.github_cloud_dr import GitHubCloudDRAdapter
from bb2gh.adapters.github_server import GitHubServerAdapter

__all__ = [
    "BitbucketCloudAdapter",
    "BitbucketDCAdapter",
    "BitbucketSourceAdapter",
    "GitHubAppConfig",
    "GitHubBaseAdapter",
    "GitHubCloudAdapter",
    "GitHubCloudDRAdapter",
    "GitHubServerAdapter",
    "MultiAppGitHubAdapter",
    "SourceAdapter",
    "TargetAdapter",
]
