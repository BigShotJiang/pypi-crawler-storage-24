"""bb2gh GitHub Cloud adapter wrapper."""

from __future__ import annotations

from bb2gh.adapters.github_base import GitHubBaseAdapter

GITHUB_CLOUD_API_URL = "https://api.github.com"


class GitHubCloudAdapter(GitHubBaseAdapter):
    """GitHub Cloud API adapter."""

    @property
    def api_url(self) -> str:
        """Get the GitHub Cloud API URL."""
        return GITHUB_CLOUD_API_URL
