"""bb2gh GitHub Enterprise Server adapter wrapper."""

from __future__ import annotations

from migration_core.adapters.github.github_server import (
    GitHubServerAdapter as MigrationCoreGitHubServerAdapter,
)

from bb2gh.adapters.github_base import GitHubBaseAdapter


class GitHubServerAdapter(MigrationCoreGitHubServerAdapter, GitHubBaseAdapter):
    """GitHub Enterprise Server adapter with bb2gh review-comment support."""
