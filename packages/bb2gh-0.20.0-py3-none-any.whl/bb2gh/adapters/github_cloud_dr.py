"""bb2gh GitHub Cloud Data Residency adapter wrapper."""

from __future__ import annotations

from migration_core.adapters.github.github_cloud_dr import (
    GitHubCloudDRAdapter as MigrationCoreGitHubCloudDRAdapter,
)

from bb2gh.adapters.github_base import GitHubBaseAdapter


class GitHubCloudDRAdapter(MigrationCoreGitHubCloudDRAdapter, GitHubBaseAdapter):
    """GitHub Cloud Data Residency adapter with bb2gh review-comment support."""
