"""bb2gh GitHub adapter wrappers over migration-core implementations."""

from __future__ import annotations

from typing import Any

import structlog
from migration_core.adapters.github.github_base import (
    GitHubBaseAdapter as MigrationCoreGitHubBaseAdapter,
)
from migration_core.models.repository import Repository
from migration_core.models.user import User

from bb2gh.adapters.base import TargetAdapter

logger = structlog.get_logger(__name__)


class GitHubBaseAdapter(MigrationCoreGitHubBaseAdapter, TargetAdapter[Repository, User]):
    """GitHub adapter with bb2gh-specific review comment support."""

    @property
    def supports_review_comments(self) -> bool:
        """GitHub pull requests support native review comments."""
        return True

    async def create_review_comment(
        self,
        repo: str,
        pr_number: int,
        *,
        body: str,
        path: str,
        line: int,
        commit_id: str | None,
    ) -> dict[str, Any]:
        """Create a pull-request review comment."""
        if not commit_id:
            raise ValueError("commit_id is required for GitHub review comments")

        logger.debug(
            "creating_review_comment",
            repo=repo,
            pr_number=pr_number,
            path=path,
            line=line,
        )

        response = await self._request(
            "POST",
            f"/repos/{repo}/pulls/{pr_number}/comments",
            json={
                "body": body,
                "path": path,
                "line": line,
                "side": "RIGHT",
                "commit_id": commit_id,
            },
        )
        response.raise_for_status()
        result: dict[str, Any] = response.json()
        return result
