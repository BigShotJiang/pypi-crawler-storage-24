"""Shared GitHub target adapter factory for CLI commands."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from bb2gh.adapters import GitHubCloudAdapter, GitHubCloudDRAdapter, GitHubServerAdapter
from bb2gh.cli.credential_resolver import resolve_github_credentials
from bb2gh.exceptions import ConfigurationError

if TYPE_CHECKING:
    from bb2gh.adapters.base import TargetAdapter


def _get_ssl_verify() -> str | bool:
    """Resolve SSL verification from bb2gh settings."""
    from bb2gh.models.config import BB2GHSettings
    from bb2gh.services.ssl import resolve_ssl_verify

    settings = BB2GHSettings()
    return resolve_ssl_verify(settings.ssl_ca_bundle)


def _get_github_auth_kwargs(
    creds: dict[str, Any],
    *,
    ssl_verify: str | bool,
) -> dict[str, Any]:
    """Build auth kwargs for GitHub target adapters."""
    if creds.get("auth_method") == "pat" and creds.get("token"):
        return {
            "token": creds["token"],
            "ssl_verify": ssl_verify,
        }
    if creds.get("auth_method") == "app" and creds.get("private_key"):
        return {
            "app_id": creds["app_id"],
            "private_key": creds["private_key"],
            "installation_id": creds["installation_id"],
            "ssl_verify": ssl_verify,
        }
    raise ConfigurationError(
        "GitHub credentials not found."
        " Run 'bb2gh auth login' or set:\n"
        "  - GH_TOKEN for PAT auth, or\n"
        "  - GH_APP_ID + GH_APP_PRIVATE_KEY + GH_APP_INSTALLATION_ID, or\n"
        "  - GH_APP_ID + GH_APP_PRIVATE_KEY_FILE + GH_APP_INSTALLATION_ID"
    )


def create_github_target_adapter(
    *,
    profile_name: str = "default",
) -> TargetAdapter[Any, Any]:
    """Create the appropriate GitHub target adapter for the active target config."""
    creds = resolve_github_credentials(profile_name=profile_name)
    target_type = str(creds.get("target_type") or "github-cloud")
    base_url = str(creds.get("base_url") or "https://api.github.com")
    auth_kwargs = _get_github_auth_kwargs(creds, ssl_verify=_get_ssl_verify())

    if target_type == "github-cloud":
        return GitHubCloudAdapter(**auth_kwargs)
    if target_type == "github-server":
        return GitHubServerAdapter(base_url=base_url, **auth_kwargs)
    if target_type == "github-cloud-dr":
        return GitHubCloudDRAdapter(api_endpoint=base_url, **auth_kwargs)

    raise ConfigurationError(f"Unsupported GitHub target type: {target_type}")
