"""bb2gh CLI - Main entry point.

This is the main CLI application for bb2gh, the Bitbucket to GitHub migration tool.
The CLI follows a Terraform-inspired workflow: discover -> plan -> migrate -> validate.
"""

from __future__ import annotations

import os
import sys
from typing import TYPE_CHECKING

import typer

from bb2gh.__about__ import __version__
from bb2gh.cli.console import reset_shared_console

if TYPE_CHECKING:
    from rich.console import Console

    from bb2gh.models.state import MigrationRecord

# Create main Typer app
app = typer.Typer(
    name="bb2gh",
    help="Bitbucket to GitHub migration tool - migrate repositories with full metadata preservation.",
    no_args_is_help=True,
    rich_markup_mode="rich",
)

# Add config subcommand
from bb2gh.cli.config_cmd import config_app  # noqa: E402

app.add_typer(config_app, name="config")

# Add auth subcommand
from bb2gh.cli.auth_cmd import auth_app  # noqa: E402

app.add_typer(auth_app, name="auth")

# Add license subcommand
from bb2gh.cli.license_cmd import license_app  # noqa: E402

app.add_typer(license_app, name="license")

# Add cleanup subcommand
from bb2gh.cli.cleanup import cleanup_app  # noqa: E402

app.add_typer(cleanup_app, name="cleanup")

# Users subcommand group
users_app = typer.Typer(
    name="users",
    help="User export and mapping commands for PR attribution.",
    no_args_is_help=True,
)
app.add_typer(users_app, name="users")

# PRs subcommand group
prs_app = typer.Typer(
    name="prs",
    help="Pull request migration commands.",
    no_args_is_help=True,
)
app.add_typer(prs_app, name="prs")

# Secrets subcommand group
secrets_app = typer.Typer(
    name="secrets",
    help="Secret inventory, scaffolding, and validation.",
    no_args_is_help=True,
)
app.add_typer(secrets_app, name="secrets")

# Protect subcommand group (branch protection)
protect_app = typer.Typer(
    name="protect",
    help="Branch protection migration: plan, apply, diff, validate, rollback, promote.",
    no_args_is_help=True,
)
app.add_typer(protect_app, name="protect")

# Migrations subcommand group
migrations_app = typer.Typer(
    name="migrations",
    help="List and manage migration runs.",
    no_args_is_help=True,
)
app.add_typer(migrations_app, name="migrations")


@migrations_app.command("list")
def migrations_list(
    plan_file: str | None = typer.Option(
        None,
        "--plan",
        "-p",
        help="Filter by plan file path.",
    ),
    limit: int = typer.Option(
        20,
        "--limit",
        "-n",
        help="Maximum number of migrations to show.",
    ),
    state_db: str | None = typer.Option(
        None,
        "--state-db",
        help="Path to state database file. Defaults to .bb2gh/state.db",
    ),
) -> None:
    """List all migration runs.

    Shows migration ID, status, progress, and timestamps for each migration.
    Use the migration ID with --resume to continue an interrupted migration.
    """
    import asyncio
    from pathlib import Path

    from rich.table import Table

    from bb2gh.cli.console import get_shared_console
    from bb2gh.cli.output import print_error, print_info
    from bb2gh.state.store import StateStore

    console = get_shared_console()
    db_path = Path(state_db) if state_db else Path(".bb2gh/state.db")

    if not db_path.exists():
        print_info("No migrations found. State database does not exist yet.")
        print_info(f"Expected location: {db_path}")
        return

    async def _list_migrations() -> list[MigrationRecord]:
        async with StateStore(db_path) as store:
            return await store.list_migrations(limit=limit, plan_file=plan_file)

    try:
        migrations = asyncio.run(_list_migrations())
    except Exception as e:
        print_error(f"Failed to read migrations: {e}")
        raise typer.Exit(1) from None

    if not migrations:
        print_info("No migrations found.")
        if plan_file:
            print_info(f"No migrations for plan: {plan_file}")
        return

    # Build table
    table = Table(title="Migration Runs", show_lines=False)
    table.add_column("Migration ID", style="cyan")
    table.add_column("Status", style="bold")
    table.add_column("Progress", justify="right")
    table.add_column("Plan File", style="dim", max_width=40, overflow="ellipsis")
    table.add_column("Created", style="dim")

    for mig in migrations:
        # Format status with color
        status_str = mig.status.value
        if mig.status.value == "completed":
            status_str = "[green]completed[/green]"
        elif mig.status.value == "failed":
            status_str = "[red]failed[/red]"
        elif mig.status.value == "in_progress":
            status_str = "[yellow]in_progress[/yellow]"
        elif mig.status.value == "cancelled":
            status_str = "[dim]cancelled[/dim]"

        # Format progress
        total = mig.total_repos or 0
        completed = mig.completed_repos or 0
        failed = mig.failed_repos or 0
        if total > 0:
            progress_str = f"{completed}/{total}"
            if failed > 0:
                progress_str += f" [red]({failed} failed)[/red]"
        else:
            progress_str = "-"

        # Format timestamp
        created_str = mig.created_at.strftime("%Y-%m-%d %H:%M") if mig.created_at else "-"

        # Shorten plan file path
        plan_display = mig.plan_file
        if plan_display and len(plan_display) > 40:
            plan_display = "..." + plan_display[-37:]

        table.add_row(
            mig.migration_id,
            status_str,
            progress_str,
            plan_display,
            created_str,
        )

    console.print()
    console.print(table)
    console.print()
    console.print(
        "[dim]Resume a migration with:[/dim] bb2gh migrate --plan <plan.json> --resume <migration_id>"
    )
    console.print("[dim]Or use auto-resume:[/dim] bb2gh migrate --plan <plan.json> --auto-resume")


@users_app.command("export")
def users_export(
    source: str = typer.Argument(
        ...,
        help="Source platform: 'bitbucket' or 'github'.",
    ),
    workspace: str | None = typer.Option(
        None,
        "--workspace",
        "-w",
        help="Bitbucket workspace (required for bitbucket).",
    ),
    org: str | None = typer.Option(
        None,
        "--org",
        "-o",
        help="GitHub organization (required for github).",
    ),
    output: str | None = typer.Option(
        None,
        "--output",
        help="Output CSV file path.",
    ),
) -> None:
    """Export users from Bitbucket or GitHub to CSV."""
    from bb2gh.cli.users import run_export

    run_export(source, workspace=workspace, org=org, output=output)


@users_app.command("map")
def users_map(
    bb_users: str = typer.Argument(
        ...,
        help="Path to Bitbucket users CSV file.",
    ),
    gh_users: str = typer.Argument(
        ...,
        help="Path to GitHub users CSV file.",
    ),
    output: str | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Output path for mapping CSV. Defaults to user-mapping.csv.",
    ),
    load: str | None = typer.Option(
        None,
        "--load",
        "-l",
        help="Load existing mapping file and update it.",
    ),
) -> None:
    """Generate or update user mappings by auto-matching Bitbucket and GitHub users."""
    from bb2gh.cli.users import run_map

    run_map(bb_users, gh_users, output=output, load=load)


@users_app.command("validate")
def users_validate(
    mapping_file: str = typer.Argument(
        ...,
        help="Path to user mapping CSV file.",
    ),
) -> None:
    """Validate a user mapping file."""
    from bb2gh.cli.users import run_validate

    run_validate(mapping_file)


@users_app.command("export-mannequins")
def users_export_mannequins(
    workspace: str = typer.Argument(
        ...,
        help="Bitbucket workspace to export users from.",
    ),
    output: str = typer.Option(
        "mannequins.csv",
        "--output",
        "-o",
        help="Output CSV file path for mannequin mapping.",
    ),
) -> None:
    """Export mannequin mapping CSV for GEI reclaim-mannequin.

    Generates a CSV file with Bitbucket workspace users that can be used
    with 'gh gei reclaim-mannequin' after a GEI migration to properly
    attribute content to real GitHub users.
    """
    from bb2gh.cli.users import run_export_mannequins

    run_export_mannequins(workspace, output=output)


# PR commands
@prs_app.command("migrate")
def prs_migrate(
    source_repo: str = typer.Argument(
        ...,
        help="Source repository (workspace/repo).",
    ),
    target_repo: str = typer.Argument(
        ...,
        help="Target repository (org/repo).",
    ),
    user_mapping: str | None = typer.Option(
        None,
        "--user-mapping",
        "-u",
        help="Path to user mapping CSV file for attribution.",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Preview without creating PRs.",
    ),
) -> None:
    """Migrate open PRs from Bitbucket to GitHub."""
    from bb2gh.cli.prs import run_migrate_prs

    run_migrate_prs(source_repo, target_repo, user_mapping=user_mapping, dry_run=dry_run)


@prs_app.command("migrate-closed")
def prs_migrate_closed(
    source_repo: str = typer.Argument(
        ...,
        help="Source repository (workspace/repo).",
    ),
    target_repo: str = typer.Argument(
        ...,
        help="Target repository (org/repo).",
    ),
    user_mapping: str | None = typer.Option(
        None,
        "--user-mapping",
        "-u",
        help="Path to user mapping CSV file for attribution.",
    ),
    since: str | None = typer.Option(
        None,
        "--since",
        help="Only migrate PRs updated after this date (ISO format).",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Preview without creating PRs.",
    ),
) -> None:
    """Migrate closed/merged PRs from Bitbucket to GitHub for historical record."""
    from bb2gh.cli.prs import run_migrate_closed_prs

    run_migrate_closed_prs(
        source_repo,
        target_repo,
        user_mapping=user_mapping,
        since=since,
        dry_run=dry_run,
    )


@prs_app.command("migrate-all")
def prs_migrate_all(
    plan_file: str = typer.Option(
        ...,
        "--plan",
        "-p",
        help="Path to migration plan file.",
    ),
    user_mapping: str | None = typer.Option(
        None,
        "--user-mapping",
        "-u",
        help="Path to user mapping CSV file for attribution.",
    ),
    include_closed: bool = typer.Option(
        False,
        "--include-closed",
        help="Also migrate closed/merged PRs.",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Preview without creating PRs.",
    ),
    state_db: str | None = typer.Option(
        None,
        "--state-db",
        help="Path to state database for tracking migrations.",
    ),
) -> None:
    """Migrate PRs for all repositories in a migration plan.

    Batch PR migration from a plan file. By default migrates only open PRs.
    Use --include-closed to also migrate historical closed/merged PRs.
    """
    from bb2gh.cli.prs import run_migrate_all_prs

    run_migrate_all_prs(
        plan_file,
        user_mapping=user_mapping,
        include_closed=include_closed,
        dry_run=dry_run,
        state_db=state_db,
    )


# Secrets commands
@secrets_app.command("export")
def secrets_export(
    source: str = typer.Option(
        "bitbucket",
        "--source",
        "-s",
        help="Source platform (bitbucket).",
    ),
    workspace: str = typer.Option(
        ...,
        "--workspace",
        "-w",
        help="Bitbucket workspace to scan.",
    ),
    output: str | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Output JSON file path.",
    ),
) -> None:
    """Export secrets inventory from Bitbucket (names only, never values)."""
    from bb2gh.cli.secrets import run_export

    run_export(source, workspace, output=output)


@secrets_app.command("checklist")
def secrets_checklist(
    inventory_file: str = typer.Argument(
        ...,
        help="Path to secrets inventory JSON file.",
    ),
    output: str | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Output file path.",
    ),
    output_format: str = typer.Option(
        "csv",
        "--format",
        "-f",
        help="Output format (csv or json).",
    ),
) -> None:
    """Generate a migration checklist from secrets inventory."""
    from bb2gh.cli.secrets import run_checklist

    run_checklist(inventory_file, output=output, output_format=output_format)


@secrets_app.command("scaffold")
def secrets_scaffold(
    inventory_file: str = typer.Argument(
        ...,
        help="Path to secrets inventory JSON file.",
    ),
    target_org: str = typer.Option(
        ...,
        "--target-org",
        "-t",
        help="Target GitHub organization.",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Preview without creating secrets.",
    ),
) -> None:
    """Scaffold placeholder secrets in GitHub from inventory."""
    from bb2gh.cli.secrets import run_scaffold

    run_scaffold(inventory_file, target_org, dry_run=dry_run)


@secrets_app.command("validate")
def secrets_validate(
    inventory_file: str = typer.Argument(
        ...,
        help="Path to secrets inventory JSON file.",
    ),
    target_org: str = typer.Option(
        ...,
        "--target-org",
        "-t",
        help="Target GitHub organization.",
    ),
) -> None:
    """Validate that secrets exist in GitHub."""
    from bb2gh.cli.secrets import run_validate

    run_validate(inventory_file, target_org)


# Protect commands
@protect_app.command("plan")
def protect_plan(
    source_repo: str = typer.Argument(
        ...,
        help="Source Bitbucket repository (workspace/repo).",
    ),
    target_repo: str = typer.Argument(
        ...,
        help="Target GitHub repository (org/repo).",
    ),
    output: str | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Output file for the plan (JSON).",
    ),
) -> None:
    """Generate a branch protection migration plan.

    Discovers Bitbucket branch restrictions and maps them to GitHub rulesets.
    """
    from bb2gh.cli.protect import run_protect_plan

    run_protect_plan(source_repo, target_repo, output=output)


@protect_app.command("apply")
def protect_apply(
    plan_file: str = typer.Argument(
        ...,
        help="Path to branch protection plan JSON file.",
    ),
    mode: str = typer.Option(
        "evaluate",
        "--mode",
        "-m",
        help="Enforcement mode: evaluate (default, safe) or active.",
    ),
) -> None:
    """Apply a branch protection plan to GitHub.

    Creates rulesets in the target repository. Default mode is 'evaluate'
    which shows policy violations without blocking.
    """
    from bb2gh.cli.protect import run_protect_apply

    run_protect_apply(plan_file, mode=mode)


@protect_app.command("diff")
def protect_diff(
    source_repo: str = typer.Argument(
        ...,
        help="Source Bitbucket repository (workspace/repo).",
    ),
    target_repo: str = typer.Argument(
        ...,
        help="Target GitHub repository (org/repo).",
    ),
) -> None:
    """Show what branch protection changes would be made.

    Displays a mapping table of Bitbucket restrictions to GitHub rules
    with status indicators (no side effects).
    """
    from bb2gh.cli.protect import run_protect_diff

    run_protect_diff(source_repo, target_repo)


@protect_app.command("validate")
def protect_validate(
    plan_file: str = typer.Argument(
        ...,
        help="Path to branch protection plan JSON file.",
    ),
) -> None:
    """Validate that applied rulesets match the plan."""
    from bb2gh.cli.protect import run_protect_validate

    run_protect_validate(plan_file)


@protect_app.command("rollback")
def protect_rollback(
    target_repo: str = typer.Argument(
        ...,
        help="Target GitHub repository to rollback (org/repo).",
    ),
) -> None:
    """Delete all bb2gh-created rulesets from a repository.

    Only removes rulesets with the 'bb2gh-' prefix.
    """
    from bb2gh.cli.protect import run_protect_rollback

    run_protect_rollback(target_repo)


@protect_app.command("promote")
def protect_promote(
    target_repo: str = typer.Argument(
        ...,
        help="Target GitHub repository to promote (org/repo).",
    ),
) -> None:
    """Promote bb2gh rulesets from evaluate to active enforcement.

    Upgrades all bb2gh-created rulesets that are currently in evaluate
    mode to active enforcement.
    """
    from bb2gh.cli.protect import run_protect_promote

    run_protect_promote(target_repo)


def _get_console() -> Console:
    """Get the current console instance."""
    from bb2gh.cli.console import get_shared_console

    return get_shared_console()


def version_callback(value: bool) -> None:
    """Print version and exit."""
    if value:
        c = _get_console()
        c.print(f"[bold blue]bb2gh[/bold blue] version [green]{__version__}[/green]")
        raise typer.Exit()


def no_color_callback(value: bool) -> None:
    """Handle --no-color flag by setting NO_COLOR env var."""
    if value:
        os.environ["NO_COLOR"] = "1"
        reset_shared_console()


def _apply_ssl_ca_bundle() -> None:
    """Set REQUESTS_CA_BUNDLE for libraries that use requests (e.g. PostHog SDK).

    Precedence (first match wins):
    1. Explicit ``REQUESTS_CA_BUNDLE`` already in env → keep it.
    2. ``BB2GH_SSL_CA_BUNDLE`` setting → use that.
    3. Auto-detected system CA bundle → use it (handles Zscaler/corporate proxies).
    4. None of the above → let certifi handle it (SDK default).
    """
    if os.environ.get("REQUESTS_CA_BUNDLE"):
        return  # Already set externally — respect it

    from bb2gh.models.config import BB2GHSettings
    from bb2gh.services.ssl import detect_system_ca_bundle, resolve_ssl_verify

    try:
        settings = BB2GHSettings()

        # Explicit config takes priority over auto-detection.
        if settings.ssl_ca_bundle is not None:
            resolved = resolve_ssl_verify(settings.ssl_ca_bundle)
            if isinstance(resolved, str):
                os.environ["REQUESTS_CA_BUNDLE"] = resolved
            return

        # Auto-detect system CA bundle (includes corporate proxy root CAs).
        system_ca = detect_system_ca_bundle()
        if system_ca is not None:
            os.environ["REQUESTS_CA_BUNDLE"] = system_ca
    except Exception:
        pass  # Never block CLI startup for SSL config issues


def _init_telemetry(ctx: typer.Context) -> None:
    """Initialize telemetry for this CLI invocation."""
    from bb2gh.telemetry.privacy import is_telemetry_enabled, show_telemetry_notice

    if not is_telemetry_enabled():
        return

    show_telemetry_notice()

    from bb2gh.models.telemetry import TelemetryConfig
    from bb2gh.telemetry.collector import TelemetryCollector
    from bb2gh.telemetry.privacy import get_anonymous_id
    from bb2gh.telemetry.sender import PostHogSender

    config = TelemetryConfig.from_env()
    config.anonymous_id = get_anonymous_id()

    sender = PostHogSender(config)
    collector = TelemetryCollector(config)

    # Initialise module-level helpers so CLI commands can emit events
    from bb2gh.cli.telemetry_helpers import init as init_telemetry_helpers

    init_telemetry_helpers(collector, sender)

    # Store in context for commands to access
    ctx.ensure_object(dict)
    ctx.obj["telemetry_sender"] = sender
    ctx.obj["telemetry_collector"] = collector

    # Capture command start
    command_name = ctx.invoked_subcommand or "unknown"
    collector.command_start(command_name)

    # Queue the startup event without blocking CLI startup on a network flush.
    for event in collector.flush():
        sender.capture(event)

    # Register shutdown to flush pending events on exit
    import atexit

    atexit.register(sender.shutdown)


def _should_init_telemetry(argv: list[str] | None = None) -> bool:
    """Skip telemetry for help and completion paths.

    These invocations should stay instant and never depend on telemetry
    background workers or network conditions.
    """
    args = argv if argv is not None else sys.argv[1:]
    skip_flags = {"--help", "-h", "--install-completion", "--show-completion"}
    return not any(flag in args for flag in skip_flags)


@app.callback()
def main(
    ctx: typer.Context,
    _version: bool | None = typer.Option(
        None,
        "--version",
        "-v",
        help="Show version and exit.",
        callback=version_callback,
        is_eager=True,
    ),
    _no_color: bool = typer.Option(
        False,
        "--no-color",
        help="Disable colored output.",
        callback=no_color_callback,
        is_eager=True,
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        help="Enable verbose (DEBUG) logging.",
    ),
    debug: bool = typer.Option(
        False,
        "--debug",
        help="Show full stack traces on errors.",
    ),
    log_format: str = typer.Option(
        "console",
        "--log-format",
        help="Log format: console or json.",
    ),
) -> None:
    """bb2gh - Migrate Bitbucket repositories to GitHub Enterprise.

    A CLI tool for migrating Bitbucket (Cloud and DataCenter) repositories to GitHub,
    with full metadata preservation including Pull Requests, comments, user attribution,
    and secrets.

    [bold]Workflow:[/bold]
        discover -> plan -> migrate -> validate

    [bold]Quick Start:[/bold]
        bb2gh discover --workspace my-company --output inventory.json
        bb2gh plan --inventory inventory.json --target-org my-gh-org
        bb2gh migrate --plan plan.json
        bb2gh validate --migration mig_xxx
    """
    # Initialize logging
    from typing import Literal

    from bb2gh.utils.logging import configure_logging

    level = "DEBUG" if verbose else "INFO"
    fmt: Literal["console", "json"] = "json" if log_format == "json" else "console"
    configure_logging(level=level, log_format=fmt)

    # Install exception handler
    from bb2gh.cli.error_handler import install_exception_handler

    install_exception_handler(debug=debug)

    # Apply SSL CA bundle for requests-based libraries (PostHog SDK)
    _apply_ssl_ca_bundle()

    # Initialize telemetry only for real command execution paths.
    if _should_init_telemetry():
        _init_telemetry(ctx)


@app.command()
def discover(
    workspace: str = typer.Option(
        ...,
        "--workspace",
        "-w",
        help="Bitbucket workspace to discover.",
    ),
    output: str | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Output file for the inventory.",
    ),
    source: str = typer.Option(
        "bitbucket-cloud",
        "--source",
        "-s",
        help="Source type: bitbucket-cloud or bitbucket-dc.",
    ),
    project: str | None = typer.Option(
        None,
        "--project",
        "-p",
        help="Filter by Bitbucket project key.",
    ),
    analyze: bool = typer.Option(
        True,
        "--analyze/--no-analyze",
        "-a",
        help="Deep analysis: complexity scoring, large files, LFS detection. Enabled by default.",
    ),
    report: bool = typer.Option(
        True,
        "--report/--no-report",
        help="Generate an HTML discovery report.",
    ),
    report_path: str | None = typer.Option(
        None,
        "--report-path",
        help="Custom path for the HTML report file.",
    ),
    excel: bool = typer.Option(
        True,
        "--excel/--no-excel",
        help="Generate an Excel discovery workbook.",
    ),
    excel_path: str | None = typer.Option(
        None,
        "--excel-path",
        help="Custom path for the Excel workbook.",
    ),
) -> None:
    """Discover and analyze source Bitbucket environment.

    Scans the specified Bitbucket workspace and generates an inventory
    with repository metadata, complexity scoring, and migration recommendations.

    Deep analysis is enabled by default, fetching additional metrics
    (branch count, PR count, large files, LFS) for each repository.
    Use --no-analyze to skip deep analysis for faster discovery.
    """
    from bb2gh.cli.discover import run_discover

    run_discover(
        workspace=workspace,
        output=output,
        source=source,
        project=project,
        analyze=analyze,
        report=report,
        report_path=report_path,
        excel=excel,
        excel_path=excel_path,
    )


@app.command()
def plan(
    inventory: str = typer.Option(
        ...,
        "--inventory",
        "-i",
        help="Path to inventory file from discover phase.",
    ),
    target_org: str = typer.Option(
        ...,
        "--target-org",
        "-t",
        help="Default target GitHub organization.",
    ),
    output: str = typer.Option(
        "plan.json",
        "--output",
        "-o",
        help="Output file for the migration plan.",
    ),
    include: list[str] = typer.Option(
        None,
        "--include",
        help="Glob pattern to include repositories (can be used multiple times).",
    ),
    exclude: list[str] = typer.Option(
        None,
        "--exclude",
        help="Glob pattern to exclude repositories (can be used multiple times).",
    ),
    project: str | None = typer.Option(
        None,
        "--project",
        "-p",
        help="Filter by Bitbucket project key.",
    ),
    rename: list[str] = typer.Option(
        None,
        "--rename",
        help="Rename repository: 'old_name:new_name' (can be used multiple times).",
    ),
    rename_file: str | None = typer.Option(
        None,
        "--rename-file",
        help="CSV file with rename mappings (old_name,new_name).",
    ),
    project_to_org: list[str] = typer.Option(
        None,
        "--project-to-org",
        help="Map Bitbucket project to GitHub org: 'PROJECT:org' (can be used multiple times).",
    ),
    preview: bool = typer.Option(
        False,
        "--preview",
        help="Show detailed preview without saving plan.",
    ),
    check_target: bool = typer.Option(
        True,
        "--check-target/--no-check-target",
        help="Check if target repos already exist in GitHub (requires GH_TOKEN).",
    ),
    on_conflict: str = typer.Option(
        "fail",
        "--on-conflict",
        help="Action when target repo exists: 'fail' (default), 'skip', or 'update'.",
    ),
) -> None:
    """Generate a migration plan from inventory.

    Creates a detailed migration plan including repository mapping
    and estimated migration scope.

    Use --include/--exclude for glob pattern filtering (e.g., --include 'frontend-*').
    Use --project to filter by Bitbucket project key.
    Use --rename to rename repositories (e.g., --rename 'old-repo:new-repo').
    Use --rename-file to load rename mappings from a CSV file.
    Use --project-to-org to route projects to different GitHub orgs.
    Use --preview to see what the plan will look like without saving it.
    Use --check-target to verify target repos don't exist (default: enabled).
    Use --on-conflict to handle existing target repos: 'fail' (error), 'skip', or 'update'.
    """
    from bb2gh.cli.plan import run_plan

    # Validate on_conflict value
    if on_conflict not in ("fail", "skip", "update"):
        raise typer.BadParameter(
            f"Invalid --on-conflict value: {on_conflict}. Must be 'fail', 'skip', or 'update'."
        )

    run_plan(
        inventory,
        target_org,
        output,
        include_patterns=include if include else None,
        exclude_patterns=exclude if exclude else None,
        project_filter=project,
        rename_args=rename if rename else None,
        rename_file=rename_file,
        org_mapping_args=project_to_org if project_to_org else None,
        preview=preview,
        check_target=check_target,
        on_conflict=on_conflict,
    )


@app.command()
def migrate(
    plan_file: str = typer.Option(
        ...,
        "--plan",
        "-p",
        help="Path to migration plan file.",
    ),
    mode: str = typer.Option(
        "mirror",
        "--mode",
        "-m",
        help="Transfer mode: mirror (all refs), branches-only (no tags), or main-only (default branch only).",
    ),
    workers: int = typer.Option(
        1,
        "--workers",
        "-w",
        min=1,
        help="Number of parallel workers.",
    ),
    resume: str | None = typer.Option(
        None,
        "--resume",
        help="Resume a failed migration by ID.",
    ),
    auto_resume: bool = typer.Option(
        False,
        "--auto-resume",
        help="Automatically resume the latest incomplete migration for this plan.",
    ),
    work_dir: str | None = typer.Option(
        None,
        "--work-dir",
        help="Working directory for git operations (uses temp dir if not specified).",
    ),
    stop_on_error: bool = typer.Option(
        False,
        "--stop-on-error",
        help="Stop migration on first error.",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Preview migration without making changes.",
    ),
    with_prs: bool = typer.Option(
        False,
        "--with-prs",
        help="Also migrate open PRs after each repository migration.",
    ),
    user_mapping: str | None = typer.Option(
        None,
        "--user-mapping",
        "-u",
        help="Path to user mapping CSV file for PR attribution (used with --with-prs).",
    ),
) -> None:
    """Execute the migration plan.

    Migrates repositories according to the plan with configurable transfer modes.

    [bold]Transfer Modes:[/bold]
        mirror       - Migrate all branches and tags (default)
        branches-only - Migrate all branches, skip tags
        main-only    - Migrate only the default branch

    [bold]PR Migration:[/bold]
        Use --with-prs to automatically migrate open PRs after each repository.
        Use --user-mapping to provide user attribution for PR authors.
    """
    from bb2gh.cli.migrate import run_migrate

    run_migrate(
        plan_file,
        mode=mode,
        workers=workers,
        resume=resume,
        auto_resume=auto_resume,
        work_dir=work_dir,
        stop_on_error=stop_on_error,
        dry_run=dry_run,
        with_prs=with_prs,
        user_mapping=user_mapping,
    )


@app.command()
def validate(
    plan: str = typer.Argument(
        ...,
        help="Path to migration plan file.",
    ),
    migration: str | None = typer.Option(
        None,
        "--migration",
        "-m",
        help="Migration ID to validate (for report tracking).",
    ),
    output: str | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Output path for JSON validation report.",
    ),
    quick: bool = typer.Option(
        False,
        "--quick",
        help="Quick validation (counts only).",
    ),
    include_prs: bool = typer.Option(
        False,
        "--include-prs",
        help="Include PR migration validation in the report.",
    ),
    state_db: str | None = typer.Option(
        None,
        "--state-db",
        help="Path to state database file (required with --include-prs).",
    ),
) -> None:
    """Validate migration completeness by comparing source and target.

    Compares branches, tags, and commit counts between source Bitbucket
    repositories and target GitHub repositories.
    """
    from bb2gh.cli.validate import run_validate

    run_validate(
        plan,
        migration_id=migration,
        output=output,
        quick=quick,
        include_prs=include_prs,
        state_db=state_db,
    )


@app.command()
def status(
    migration_id: str = typer.Argument(
        ...,
        help="Migration ID to check status.",
    ),
    failed: bool = typer.Option(
        False,
        "--failed",
        "-f",
        help="Show only failed repositories.",
    ),
    watch: bool = typer.Option(
        False,
        "--watch",
        "-w",
        help="Live refresh status.",
    ),
    state_db: str | None = typer.Option(
        None,
        "--state-db",
        help="Path to state database file. Defaults to .bb2gh/state.db",
    ),
) -> None:
    """Check status of a running or completed migration."""
    from bb2gh.cli.status import run_status

    run_status(
        migration_id,
        failed=failed,
        watch=watch,
        state_db=state_db,
    )


@app.command()
def rollback(
    migration: str = typer.Argument(
        ...,
        help="Migration ID to rollback.",
    ),
    mode: str = typer.Option(
        "soft",
        "--mode",
        "-m",
        help="Rollback mode: soft, staged, or full.",
    ),
    repos: str | None = typer.Option(
        None,
        "--repos",
        help="Specific repos to rollback (comma-separated).",
    ),
    prs_only: bool = typer.Option(
        False,
        "--prs-only",
        help="Only rollback PRs (close with note).",
    ),
    repos_only: bool = typer.Option(
        False,
        "--repos-only",
        help="Only rollback repos (archive).",
    ),
    everything: bool = typer.Option(
        False,
        "--everything",
        help="Rollback both repos and PRs (default).",
    ),
    confirm: bool = typer.Option(
        False,
        "--confirm",
        help="Confirm destructive operations (required for full mode).",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Preview rollback without making changes.",
    ),
    state_db: str | None = typer.Option(
        None,
        "--state-db",
        help="Path to state database file. Defaults to .bb2gh/state.db",
    ),
) -> None:
    """Rollback a migration (archive repos, close PRs with note).

    [bold]Modes:[/bold]
        soft    - Archive repos, close PRs with rollback note (default)
        staged  - Stage repos for deletion, close PRs
        full    - Delete repos (requires --confirm)

    [bold]Scope:[/bold]
        --prs-only   - Only close migrated PRs
        --repos-only - Only archive migrated repos
        --everything - Both repos and PRs (default)
    """
    import asyncio
    from pathlib import Path

    from bb2gh.cli.console import get_shared_console
    from bb2gh.cli.output import print_error, print_success, print_warning
    from bb2gh.models.rollback import (
        RollbackMode,
        RollbackPlan,
        RollbackResult,
        RollbackScope,
    )
    from bb2gh.services.rollback import RollbackService
    from bb2gh.state.store import StateStore

    console = get_shared_console()

    # Check license before proceeding
    try:
        from bb2gh.licensing.decorators import LicenseRequiredError
        from bb2gh.licensing.features import require_license

        require_license()
    except LicenseRequiredError as e:
        print_error(str(e))
        raise typer.Exit(1) from None

    # Validate mode
    try:
        rollback_mode = RollbackMode(mode)
    except ValueError:
        print_error(f"Invalid mode: {mode}. Must be 'soft', 'staged', or 'full'.")
        raise typer.Exit(1) from None

    # Full mode requires confirmation
    if rollback_mode == RollbackMode.FULL and not confirm:
        print_error("Full rollback requires --confirm flag.")
        raise typer.Exit(1) from None

    # Determine scope
    scope = RollbackScope.EVERYTHING
    if prs_only:
        scope = RollbackScope.PRS_ONLY
    elif repos_only:
        scope = RollbackScope.REPOS_ONLY
    elif everything:
        scope = RollbackScope.EVERYTHING

    # Parse repos list
    repos_list: list[str] = []
    if repos:
        repos_list = [r.strip() for r in repos.split(",") if r.strip()]

    # Build the plan
    plan = RollbackPlan(
        migration_id=migration,
        mode=rollback_mode,
        scope=scope,
        repos=repos_list,
        dry_run=dry_run,
        confirm=confirm,
    )

    # Display plan
    console.print(f"[bold]Rolling back migration[/bold]: [cyan]{migration}[/cyan]")
    console.print(f"Mode: {rollback_mode.value}")
    console.print(f"Scope: {scope.value}")
    if repos_list:
        console.print(f"Repos: {', '.join(repos_list)}")
    if dry_run:
        print_warning("DRY RUN - no changes will be made")

    db_path = Path(state_db) if state_db else Path(".bb2gh/state.db")

    if not db_path.exists():
        print_error(f"State database not found: {db_path}")
        raise typer.Exit(1) from None

    async def _run_rollback() -> RollbackResult:
        from bb2gh.adapters import GitHubCloudAdapter

        async with (
            StateStore(db_path) as store,
            GitHubCloudAdapter() as target,
        ):
            service = RollbackService(target_adapter=target, state_store=store)
            return await service.execute_rollback(plan)

    try:
        result = asyncio.run(_run_rollback())
    except Exception as e:
        print_error(f"Rollback failed: {e}")
        raise typer.Exit(2) from None

    # Display results
    console.print()
    if result.success:
        print_success("Rollback completed successfully!")
    else:
        print_error("Rollback completed with errors.")

    console.print(f"  Repos processed: {result.repos_processed}")
    console.print(f"  Repos archived:  {result.repos_archived}")
    if result.repos_deleted > 0:
        console.print(f"  Repos deleted:   {result.repos_deleted}")
    if result.repos_failed > 0:
        console.print(f"  [red]Repos failed:    {result.repos_failed}[/red]")
    console.print(f"  PRs closed:      {result.prs_closed}")
    if result.prs_failed > 0:
        console.print(f"  [red]PRs failed:      {result.prs_failed}[/red]")

    if result.errors:
        console.print()
        print_warning("Errors:")
        for error in result.errors:
            console.print(f"  - {error}")

    if not result.success:
        raise typer.Exit(1) from None


if __name__ == "__main__":
    app()
