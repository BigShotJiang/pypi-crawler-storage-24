"""Migrate command implementation for bb2gh.

Executes the migration plan, transferring repositories from Bitbucket to GitHub
with configurable transfer modes. Supports checkpoint/resume via SQLite state store.
"""

from __future__ import annotations

import asyncio
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any

import structlog
import typer

from bb2gh.cli.console import get_shared_console
from bb2gh.cli.github_target_factory import create_github_target_adapter
from bb2gh.cli.output import print_error, print_info, print_success, progress_context
from bb2gh.exceptions import AuthenticationError, ConfigurationError, LimitExceededError
from bb2gh.licensing.decorators import LicenseRequiredError
from bb2gh.licensing.features import check_repo_limit, check_worker_limit
from bb2gh.models.plan import MigrationPlan, MigrationStatus, TransferMode

if TYPE_CHECKING:
    from rich.console import Console

    from bb2gh.adapters.base import TargetAdapter
    from bb2gh.services.migration import MigrationStats

logger = structlog.get_logger(__name__)

# Default state database location
DEFAULT_STATE_DIR = Path(".bb2gh")
DEFAULT_STATE_DB = DEFAULT_STATE_DIR / "state.db"


# Valid transfer modes for CLI validation
TRANSFER_MODES = ["mirror", "branches-only", "main-only"]


def _get_github_adapter(
    *,
    profile: str = "default",
) -> TargetAdapter[Any, Any]:
    """Create a GitHub adapter from resolved credentials.

    Uses credential resolver: env vars > keyring > profile config.

    Args:
        profile: Name of the migration profile to use for credential lookup.

    Returns:
        Configured GitHub adapter.

    Raises:
        ConfigurationError: If required credentials are missing.
    """
    return create_github_target_adapter(profile_name=profile)


def _parse_transfer_mode(mode: str) -> TransferMode:
    """Parse transfer mode string to enum.

    Args:
        mode: Mode string (mirror, branches-only, main-only).

    Returns:
        TransferMode enum value.

    Raises:
        ValueError: If mode is not valid.
    """
    mode_map = {
        "mirror": TransferMode.MIRROR,
        "branches-only": TransferMode.BRANCHES_ONLY,
        "main-only": TransferMode.MAIN_ONLY,
    }

    if mode not in mode_map:
        raise ValueError(
            f"Invalid transfer mode: {mode}. Must be one of: {', '.join(TRANSFER_MODES)}"
        )

    return mode_map[mode]


async def _run_migration(
    plan: MigrationPlan,
    *,
    plan_file: str,
    mode: TransferMode | None = None,
    work_dir: Path | None = None,
    stop_on_error: bool = False,
    resume_migration_id: str | None = None,
    auto_resume: bool = False,
    state_db: Path | None = None,
    workers: int = 1,
) -> tuple[MigrationStats, str | None]:
    """Execute migration for all repositories in the plan.

    Args:
        plan: Migration plan to execute.
        plan_file: Path to the plan file.
        mode: Optional transfer mode override.
        work_dir: Working directory for git operations.
        stop_on_error: Whether to stop on first error.
        resume_migration_id: Migration ID to resume from.
        auto_resume: If True, automatically find and resume the latest migration.
        state_db: Path to state database.
        workers: Number of concurrent workers (1 = sequential).

    Returns:
        Tuple of (MigrationStats, migration_id).
    """
    from bb2gh.cli.credential_resolver import (
        resolve_bitbucket_credentials,
        resolve_github_credentials,
    )
    from bb2gh.services.git import GitService
    from bb2gh.services.migration import MigrationService
    from bb2gh.state.store import StateStore

    console = get_shared_console()
    github_adapter = _get_github_adapter()

    # Get auth tokens from resolver
    bb_creds = resolve_bitbucket_credentials(profile_name="default")
    gh_creds = resolve_github_credentials(profile_name="default")
    source_token = bb_creds.get("api_token")
    target_token = gh_creds.get("token")

    # Override transfer mode in plan if specified
    if mode is not None:
        for mapping in plan.repositories:
            mapping.transfer_mode = mode

    # Create services
    git_service = GitService(work_dir=work_dir)

    # Initialize state store
    db_path = state_db or DEFAULT_STATE_DB

    async with github_adapter, git_service, StateStore(db_path) as state_store:
        migration_service = MigrationService(
            target_adapter=github_adapter,
            git_service=git_service,
            source_auth_token=source_token,
            target_auth_token=target_token,
            state_store=state_store,
        )

        # Run migration with progress
        total = len(plan.repositories)

        with progress_context(console=console) as progress:
            task = progress.add_task(
                f"[cyan]Migrating {total} repositories...",
                total=100,  # Use percentage-based progress for accurate ETA
            )

            def progress_callback(repo_name: str, phase: str, pct: float) -> None:
                """Update progress display with percentage for ETA calculation."""
                progress.update(
                    task,
                    description=f"[cyan]{repo_name}: {phase}",
                    completed=pct,  # Update completed value for progress bar and ETA
                )

            stats = await migration_service.migrate_plan(
                plan,
                plan_file=plan_file,
                progress_callback=progress_callback,
                stop_on_error=stop_on_error,
                resume_migration_id=resume_migration_id,
                resume=auto_resume,
                workers=workers,
            )

            progress.update(
                task,
                description=f"[green]Migration complete: {stats.completed}/{total} succeeded",
                completed=100,  # Match the total=100 percentage-based progress
            )

        return stats, migration_service.migration_id


def _print_migration_summary(
    console: Console,
    stats: MigrationStats,
    _plan: MigrationPlan,
    *,
    migration_id: str | None = None,
) -> None:
    """Print migration summary table.

    Args:
        console: Rich console instance.
        stats: Migration statistics.
        _plan: Migration plan.
        migration_id: Optional migration ID for state tracking.
    """
    from rich.panel import Panel
    from rich.table import Table

    # Overview
    console.print()
    overview = Table(show_header=False, box=None, padding=(0, 2))
    overview.add_column("Label", style="dim")
    overview.add_column("Value", style="cyan")

    if migration_id:
        overview.add_row("Migration ID", migration_id)
    overview.add_row("Total repositories", str(stats.total))
    overview.add_row("Completed", f"[green]{stats.completed}[/green]")
    overview.add_row("Failed", f"[red]{stats.failed}[/red]" if stats.failed > 0 else "0")
    overview.add_row("Skipped", str(stats.skipped))

    console.print(Panel(overview, title="[bold]Migration Summary[/bold]", border_style="blue"))

    # Failed repositories details
    if stats.failed > 0:
        failed_table = Table(show_header=True, box=None, padding=(0, 2))
        failed_table.add_column("Repository", style="cyan")
        failed_table.add_column("Error", style="red")

        for result in stats.results:
            if not result.success:
                failed_table.add_row(
                    result.source_name,
                    result.error_message or "Unknown error",
                )

        console.print(
            Panel(
                failed_table, title="[bold red]Failed Repositories[/bold red]", border_style="red"
            )
        )


def run_migrate(
    plan_file: str,
    *,
    mode: str = "mirror",
    workers: int = 1,
    resume: str | None = None,
    auto_resume: bool = False,
    work_dir: str | None = None,
    stop_on_error: bool = False,
    dry_run: bool = False,
    state_db: str | None = None,
    with_prs: bool = False,
    user_mapping: str | None = None,
) -> None:
    """Run the migration process.

    Args:
        plan_file: Path to migration plan file.
        mode: Transfer mode (mirror, branches-only, main-only).
        workers: Number of parallel workers (1 = sequential).
        resume: Migration ID to resume.
        auto_resume: If True, automatically resume the latest incomplete migration.
        work_dir: Working directory for git operations.
        stop_on_error: Stop on first error.
        dry_run: Preview without executing.
        state_db: Path to state database file.
        with_prs: If True, also migrate open PRs after each repository.
        user_mapping: Path to user mapping CSV file for PR attribution.

    Raises:
        typer.Exit: On error.
    """
    console = get_shared_console()

    # Validate plan file exists
    plan_path = Path(plan_file)
    if not plan_path.exists():
        print_error(f"Plan file not found: {plan_file}")
        raise typer.Exit(1)

    # Parse transfer mode
    try:
        transfer_mode = _parse_transfer_mode(mode)
    except ValueError as e:
        print_error(str(e))
        raise typer.Exit(1) from None

    # Load plan
    try:
        plan = MigrationPlan.from_json_file(plan_path)
    except Exception as e:
        print_error(f"Failed to load plan: {e}")
        raise typer.Exit(1) from None

    # Summary info
    console.print("\n[bold]Starting migration[/bold]")
    console.print(f"  Plan: [cyan]{plan_file}[/cyan]")
    console.print(f"  Mode: [cyan]{mode}[/cyan]")
    console.print(f"  Source: [cyan]{plan.metadata.source_workspace}[/cyan]")
    console.print(f"  Target: [cyan]{plan.metadata.target_org}[/cyan]")
    console.print(f"  Repositories: [cyan]{len(plan.repositories)}[/cyan]")

    if resume:
        console.print(f"  Resuming: [cyan]{resume}[/cyan]")
    elif auto_resume:
        console.print(
            "  Mode: [cyan]auto-resume (will continue from last incomplete migration)[/cyan]"
        )

    if with_prs:
        console.print("  [cyan]PR migration enabled[/cyan]")
        if user_mapping:
            console.print(f"  User mapping: [cyan]{user_mapping}[/cyan]")

    if dry_run:
        console.print("\n[yellow]DRY RUN - No changes will be made[/yellow]")
        _print_dry_run_summary(console, plan, transfer_mode)
        return

    # Check license limits (skipped for dry-run)
    try:
        check_repo_limit(len(plan.repositories))
        workers = check_worker_limit(workers)
    except (LicenseRequiredError, LimitExceededError) as e:
        print_error(str(e))
        raise typer.Exit(1) from None

    pending = plan.get_pending_repositories()
    if not pending and not resume and not auto_resume:
        print_info("No pending repositories to migrate")
        return

    if pending:
        console.print(f"  Pending: [cyan]{len(pending)}[/cyan]")
    console.print()

    if workers > 1:
        print_info(f"Using {workers} parallel workers")
        if workers > 4:
            console.print(
                "  [dim]Tip: Add more GitHub Apps to increase throughput."
                " Each app adds 5,000 req/hr.[/dim]"
            )

    # Emit migration_start telemetry
    from bb2gh.cli import telemetry_helpers

    start_time = time.monotonic()
    repo_count = len(plan.repositories)

    telemetry_helpers.emit_migration_start(repo_count=repo_count)

    # Execute migration
    try:
        work_path = Path(work_dir) if work_dir else None
        db_path = Path(state_db) if state_db else None

        stats, migration_id = asyncio.run(
            _run_migration(
                plan,
                plan_file=str(plan_path.resolve()),
                mode=transfer_mode,
                work_dir=work_path,
                stop_on_error=stop_on_error,
                resume_migration_id=resume,
                auto_resume=auto_resume,
                state_db=db_path,
                workers=workers,
            )
        )

        # Save updated plan with status
        plan.to_json_file(plan_path)

        # Print summary
        _print_migration_summary(console, stats, plan, migration_id=migration_id)

        # Migrate PRs if requested
        pr_stats = None
        if with_prs and stats.completed > 0:
            console.print("\n[bold]Migrating PRs for completed repositories...[/bold]")
            pr_stats = _migrate_prs_for_plan(
                plan,
                user_mapping=user_mapping,
                console=console,
            )
            _print_pr_migration_summary(console, pr_stats)

        elapsed_ms = int((time.monotonic() - start_time) * 1000)

        if stats.failed > 0:
            telemetry_helpers.emit_migration_failure(
                repo_count=repo_count,
                repos_completed=stats.completed,
                repos_failed=stats.failed,
                error_type="partial_failure",
                duration_ms=elapsed_ms,
            )
            telemetry_helpers.emit_command_failure("migrate", error_type="partial_failure")

            print_error(f"{stats.failed} repositories failed to migrate")
            if migration_id:
                console.print(
                    f"\n[dim]Resume with:[/dim] bb2gh migrate --plan {plan_file} --resume {migration_id}"
                )
            logger.warning(
                "migration_completed_with_errors",
                completed=stats.completed,
                failed=stats.failed,
                migration_id=migration_id,
            )
            raise typer.Exit(1)

        telemetry_helpers.emit_migration_success(
            repo_count=repo_count,
            duration_ms=elapsed_ms,
            repos_completed=stats.completed,
            repos_failed=stats.failed,
        )
        telemetry_helpers.emit_command_success("migrate", duration_ms=elapsed_ms)

        print_success("Migration completed successfully!")
        if migration_id:
            console.print(f"[dim]Migration ID: {migration_id}[/dim]")
        logger.info(
            "migration_complete",
            completed=stats.completed,
            total=stats.total,
            migration_id=migration_id,
        )

    except ConfigurationError as e:
        elapsed_ms = int((time.monotonic() - start_time) * 1000)
        telemetry_helpers.emit_migration_failure(
            repo_count=repo_count,
            error_type="ConfigurationError",
            duration_ms=elapsed_ms,
        )
        telemetry_helpers.emit_command_failure("migrate", error_type="ConfigurationError")
        print_error(f"Configuration error: {e}")
        raise typer.Exit(1) from None
    except AuthenticationError as e:
        elapsed_ms = int((time.monotonic() - start_time) * 1000)
        telemetry_helpers.emit_migration_failure(
            repo_count=repo_count,
            error_type="AuthenticationError",
            duration_ms=elapsed_ms,
        )
        telemetry_helpers.emit_command_failure("migrate", error_type="AuthenticationError")
        print_error(f"Authentication failed: {e}")
        raise typer.Exit(1) from None
    except Exception as e:
        elapsed_ms = int((time.monotonic() - start_time) * 1000)
        telemetry_helpers.emit_migration_failure(
            repo_count=repo_count,
            error_type=type(e).__name__,
            duration_ms=elapsed_ms,
        )
        telemetry_helpers.emit_command_failure("migrate", error_type=type(e).__name__)
        logger.exception("migration_failed", plan=plan_file)
        print_error(f"Migration failed: {e}")
        raise typer.Exit(2) from None


def _migrate_prs_for_plan(
    plan: MigrationPlan,
    *,
    user_mapping: str | None = None,
    console: Console,
) -> dict[str, int]:
    """Migrate PRs for completed repositories in a plan.

    Args:
        plan: Migration plan.
        user_mapping: Path to user mapping CSV file.
        console: Rich console instance.

    Returns:
        Dict with total, migrated, failed counts.
    """
    from bb2gh.cli.prs import _migrate_open_prs

    total_prs = 0
    migrated_prs = 0
    failed_prs = 0
    repos_processed = 0

    # Get completed repositories
    completed_repos = [r for r in plan.repositories if r.status == MigrationStatus.COMPLETED]

    mapping_path = Path(user_mapping) if user_mapping else None

    with progress_context(console=console) as progress:
        task = progress.add_task(
            f"[cyan]Migrating PRs for {len(completed_repos)} repositories...",
            total=len(completed_repos),
        )

        for repo in completed_repos:
            source_repo = repo.source_full_name
            target_repo = repo.target_full_name

            progress.update(
                task,
                description=f"[cyan]PRs: {source_repo}",
            )

            try:
                stats = asyncio.run(
                    _migrate_open_prs(
                        source_repo,
                        target_repo,
                        user_mapping_file=mapping_path,
                        dry_run=False,
                    )
                )
                total_prs += stats.get("total", 0)
                migrated_prs += stats.get("migrated", 0)
                failed_prs += stats.get("failed", 0)
            except Exception as e:
                logger.warning("pr_migration_failed", repo=source_repo, error=str(e))
                # Don't fail the whole migration for PR errors

            repos_processed += 1
            progress.update(task, completed=repos_processed)

    return {
        "repos_processed": repos_processed,
        "total_prs": total_prs,
        "migrated_prs": migrated_prs,
        "failed_prs": failed_prs,
    }


def _print_pr_migration_summary(console: Console, stats: dict[str, int]) -> None:
    """Print PR migration summary.

    Args:
        console: Rich console instance.
        stats: PR migration stats dict.
    """
    from rich.panel import Panel
    from rich.table import Table

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Label", style="dim")
    table.add_column("Value", style="cyan")

    table.add_row("Repositories processed", str(stats["repos_processed"]))
    table.add_row("Total PRs", str(stats["total_prs"]))
    table.add_row("Migrated", f"[green]{stats['migrated_prs']}[/green]")
    if stats["failed_prs"] > 0:
        table.add_row("Failed", f"[red]{stats['failed_prs']}[/red]")

    console.print(Panel(table, title="[bold]PR Migration Summary[/bold]", border_style="blue"))


def _print_dry_run_summary(
    console: Console,
    plan: MigrationPlan,
    mode: TransferMode,
) -> None:
    """Print dry run summary showing what would be migrated.

    Args:
        console: Rich console instance.
        plan: Migration plan.
        mode: Transfer mode.
    """
    from rich.table import Table

    console.print("\n[bold]Migration Preview[/bold]")

    table = Table(show_header=True, box=None, padding=(0, 2))
    table.add_column("Source", style="cyan")
    table.add_column("Target", style="green")
    table.add_column("Mode", style="yellow")
    table.add_column("Status", style="dim")

    for mapping in plan.repositories:
        effective_mode = mode.value
        status = mapping.status.value

        if mapping.status == MigrationStatus.COMPLETED:
            status = "[green]completed[/green]"
        elif mapping.status == MigrationStatus.FAILED:
            status = "[red]failed[/red]"
        elif mapping.status == MigrationStatus.SKIPPED:
            status = "[dim]skipped[/dim]"
        else:
            status = "[cyan]pending[/cyan]"

        table.add_row(
            mapping.source_full_name,
            mapping.target_full_name,
            effective_mode,
            status,
        )

    console.print(table)

    # Summary counts
    pending = len(plan.get_pending_repositories())
    completed = len([m for m in plan.repositories if m.status == MigrationStatus.COMPLETED])
    failed = len(plan.get_failed_repositories())

    console.print(f"\n  Pending: {pending}")
    console.print(f"  Previously completed: {completed}")
    if failed > 0:
        console.print(f"  [red]Previously failed: {failed}[/red]")
