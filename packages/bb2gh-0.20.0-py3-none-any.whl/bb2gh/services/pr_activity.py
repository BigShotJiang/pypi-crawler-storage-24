"""PR Activity migration service for bb2gh.

Handles fetching and migrating PR activities (comments, approvals, updates)
from Bitbucket to GitHub.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

import structlog

from bb2gh.models.pull_request import (
    PRActivity,
    PRActivityType,
    PRAuthor,
)
from bb2gh.services.pr_authorship import build_author_header

if TYPE_CHECKING:
    from typing import Any

    from bb2gh.adapters.base import BitbucketSourceAdapter, TargetAdapter
    from bb2gh.models.user_mapping import UserMappingStore

logger = structlog.get_logger(__name__)


class PRActivityService:
    """Service for migrating PR activities from Bitbucket to GitHub."""

    def __init__(
        self,
        *,
        source_adapter: BitbucketSourceAdapter,
        target_adapter: TargetAdapter[Any, Any],
        user_mapping: UserMappingStore | None = None,
    ) -> None:
        """Initialize PRActivityService.

        Args:
            source_adapter: Adapter for source platform (Bitbucket).
            target_adapter: Adapter for target platform (GitHub).
            user_mapping: User mapping store for attribution.
        """
        self._source = source_adapter
        self._target = target_adapter
        self._user_mapping = user_mapping

    def _parse_activity(self, raw: dict[str, Any]) -> PRActivity:
        """Parse raw Bitbucket activity into PRActivity model.

        Args:
            raw: Raw activity dict from Bitbucket API.

        Returns:
            PRActivity model.
        """
        activity_type_str = raw.get("type", "unknown")

        # Map activity type
        type_map = {
            "comment": PRActivityType.COMMENT,
            "approval": PRActivityType.APPROVAL,
            "changes_requested": PRActivityType.CHANGES_REQUESTED,
            "update": PRActivityType.UPDATE,
        }
        activity_type = type_map.get(activity_type_str, PRActivityType.UPDATE)

        # Extract data based on type
        if activity_type == PRActivityType.COMMENT:
            comment_data = raw.get("comment", {})
            user_data = comment_data.get("user", {})
            created_str = comment_data.get("created_on")
            content = comment_data.get("content", {}).get("raw", "")
            activity_id = str(comment_data.get("id", ""))
            inline = comment_data.get("inline")
            file_path = inline.get("path") if inline else None
            line_number = inline.get("to") or inline.get("from") if inline else None
            commit_hash = None
        elif activity_type == PRActivityType.APPROVAL:
            approval_data = raw.get("approval", {})
            user_data = approval_data.get("user", {})
            created_str = approval_data.get("date")
            content = None
            activity_id = f"approval-{created_str}"
            file_path = None
            line_number = None
            commit_hash = None
        elif activity_type == PRActivityType.CHANGES_REQUESTED:
            changes_data = raw.get("changes_requested", {})
            user_data = changes_data.get("user", {})
            created_str = changes_data.get("date")
            content = None
            activity_id = f"changes-{created_str}"
            file_path = None
            line_number = None
            commit_hash = None
        else:  # UPDATE
            update_data = raw.get("update", {})
            user_data = update_data.get("author", {})
            created_str = update_data.get("date")
            content = None
            activity_id = f"update-{created_str}"
            file_path = None
            line_number = None
            source = update_data.get("source", {})
            commit = source.get("commit", {})
            commit_hash = commit.get("hash")

        # Parse author
        author = PRAuthor(
            username=user_data.get("username", user_data.get("account_id", "unknown")),
            display_name=user_data.get("display_name"),
            source_id=user_data.get("source_id") or user_data.get("account_id"),
            account_id=user_data.get("account_id"),
        )

        # Parse timestamp
        created_at = None
        if created_str:
            created_at = datetime.fromisoformat(created_str.replace("Z", "+00:00"))

        return PRActivity(
            id=activity_id,
            activity_type=activity_type,
            author=author,
            created_at=created_at,
            content=content,
            file_path=file_path,
            line_number=line_number,
            commit_hash=commit_hash,
        )

    def build_activity_timeline(self, activities: list[PRActivity]) -> str:
        """Build a markdown activity timeline.

        Args:
            activities: List of PRActivity objects (should be sorted by time).

        Returns:
            Markdown string with activity timeline table.
        """
        if not activities:
            return ""

        lines = [
            "",
            "## 📋 Activity Timeline",
            "",
            "| Time | User | Action |",
            "|------|------|--------|",
        ]

        # Map activity types to human-readable actions
        action_map = {
            PRActivityType.COMMENT: "Commented",
            PRActivityType.APPROVAL: "Approved",
            PRActivityType.CHANGES_REQUESTED: "Requested changes",
            PRActivityType.UPDATE: "Pushed update",
            PRActivityType.MERGE: "Merged",
            PRActivityType.DECLINE: "Declined",
        }

        for activity in activities:
            timestamp = (
                activity.created_at.strftime("%Y-%m-%d %H:%M") if activity.created_at else "Unknown"
            )
            user = activity.author.display_name or activity.author.username
            action = action_map.get(activity.activity_type, "Activity")

            # Add detail for updates
            if activity.activity_type == PRActivityType.UPDATE and activity.commit_hash:
                action += f" (`{activity.commit_hash[:7]}`)"

            lines.append(f"| {timestamp} | {user} | {action} |")

        return "\n".join(lines)

    async def fetch_activities(
        self,
        repo_full_name: str,
        pr_id: str,
    ) -> list[PRActivity]:
        """Fetch all activities for a PR.

        Args:
            repo_full_name: Full repository name (workspace/repo).
            pr_id: Pull request ID.

        Returns:
            List of PRActivity objects sorted by created_at.
        """
        activities = []

        async for raw_activity in self._source.list_pr_activity(repo_full_name, pr_id):
            activity = self._parse_activity(raw_activity)
            activities.append(activity)

        # Sort by created_at (oldest first)
        activities.sort(key=lambda a: a.created_at or datetime.min.replace(tzinfo=UTC))

        return activities

    def _resolve_user(
        self,
        bb_username: str | None,
        source_id: str | None = None,
    ) -> tuple[str | None, str | None]:
        """Resolve a Bitbucket actor to GitHub username.

        Args:
            bb_username: Bitbucket username when available.
            source_id: Stable Bitbucket source ID when available.

        Returns:
            Tuple of (github_username, attribution_note).
        """
        if self._user_mapping:
            return self._user_mapping.resolve_actor(
                source_username=bb_username,
                source_id=source_id,
            )
        if bb_username:
            return None, f"[Migrated from Bitbucket: @{bb_username}]"
        if source_id:
            return None, f"[Migrated from Bitbucket: source id {source_id}]"
        return None, "[Migrated from Bitbucket: unknown]"

    def _build_comment_body(self, activity: PRActivity) -> str:
        """Build comment body with attribution.

        Args:
            activity: PRActivity with comment content.

        Returns:
            Formatted comment body.
        """
        parts = []

        # Attribution header
        target_user, attribution = self._resolve_user(
            activity.author.username,
            activity.author.source_id or activity.author.account_id,
        )
        has_github_mapping = target_user is not None and attribution is None
        parts.append(
            "*"
            + build_author_header(
                source_username=activity.author.username,
                source_id=activity.author.source_id or activity.author.account_id,
                display_name=activity.author.display_name,
                target_username=target_user,
                has_github_mapping=has_github_mapping,
            )
            + "*"
        )
        if attribution:
            parts.append(f"*{attribution}*")
        parts.append("")

        # Original content
        parts.append(activity.content or "")

        # Metadata footer for inline comments
        if activity.file_path:
            parts.append("")
            parts.append("---")
            loc = f"*Originally on `{activity.file_path}`"
            if activity.line_number:
                loc += f" line {activity.line_number}"
            loc += "*"
            parts.append(loc)

        # Timestamp
        if activity.created_at:
            parts.append(f"*Original: {activity.created_at.strftime('%Y-%m-%d %H:%M UTC')}*")

        return "\n".join(parts)

    async def migrate_activity_as_comment(
        self,
        activity: PRActivity,
        target_repo: str,
        target_pr_number: int,
    ) -> dict[str, Any]:
        """Migrate a single activity as a GitHub comment.

        Args:
            activity: PRActivity to migrate.
            target_repo: Target repository (org/repo).
            target_pr_number: Target PR number.

        Returns:
            Created comment data dict.
        """
        body = self._build_comment_body(activity)

        return await self._target.create_issue_comment(
            target_repo,
            target_pr_number,
            body,
        )

    async def migrate_pr_activities(
        self,
        source_repo: str,
        source_pr_id: str,
        target_repo: str,
        target_pr_number: int,
        *,
        include_in_description: bool = True,
    ) -> dict[str, Any]:
        """Migrate all activities for a PR.

        Args:
            source_repo: Source repository (workspace/repo).
            source_pr_id: Source PR ID.
            target_repo: Target repository (org/repo).
            target_pr_number: Target PR number.
            include_in_description: Whether to include timeline in description.

        Returns:
            Migration stats dict.
        """
        stats: dict[str, Any] = {
            "total": 0,
            "comments_migrated": 0,
            "comments_failed": 0,
            "timeline_generated": False,
        }

        logger.info(
            "migrating_pr_activities",
            source_repo=source_repo,
            source_pr=source_pr_id,
            target_pr=target_pr_number,
        )

        # Fetch all activities
        activities = await self.fetch_activities(source_repo, source_pr_id)
        stats["total"] = len(activities)

        # Migrate comment activities as individual comments
        for activity in activities:
            if activity.activity_type == PRActivityType.COMMENT and activity.content:
                try:
                    await self.migrate_activity_as_comment(activity, target_repo, target_pr_number)
                    stats["comments_migrated"] += 1
                except Exception as e:
                    logger.warning(
                        "comment_migration_failed",
                        activity_id=activity.id,
                        error=str(e),
                    )
                    stats["comments_failed"] += 1

        # Generate timeline
        if include_in_description:
            stats["timeline"] = self.build_activity_timeline(activities)
            stats["timeline_generated"] = bool(stats["timeline"])

        logger.info(
            "pr_activities_migrated",
            source_pr=source_pr_id,
            total=stats["total"],
            comments_migrated=stats["comments_migrated"],
        )

        return stats
