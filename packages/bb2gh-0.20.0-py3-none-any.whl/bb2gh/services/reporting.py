"""Discovery report generation service.

Renders a self-contained HTML dashboard from an Inventory model
using Jinja2 templates with vendored Chart.js.
"""

from __future__ import annotations

from importlib.resources import files
from pathlib import Path
from typing import TYPE_CHECKING

import jinja2
import structlog

from bb2gh.exceptions import BB2GHError, ExitCode
from bb2gh.services.discovery_deliverables import build_discovery_deliverable_data
from bb2gh.services.formatting import format_bytes_human_readable

if TYPE_CHECKING:
    from bb2gh.models.inventory import Inventory

logger = structlog.get_logger(__name__)

_DEFAULT_REPORT_DIR = Path(".bb2gh") / "reports"
_DEFAULT_REPORT_PATH = _DEFAULT_REPORT_DIR / "discovery-report.html"


class ReportError(BB2GHError):
    """Raised when report generation fails."""

    def __init__(self, message: str) -> None:
        super().__init__(message, exit_code=ExitCode.SYSTEM_ERROR)


class ReportService:
    """Generates self-contained HTML discovery reports."""

    @staticmethod
    def generate(
        inventory: Inventory,
        output_path: Path | None = None,
    ) -> Path:
        """Render the discovery report HTML and write to disk.

        Args:
            inventory: The discovery inventory to render.
            output_path: Where to write the HTML file. Defaults to
                ``.bb2gh/reports/discovery-report.html``.

        Returns:
            The path to the generated report file.

        Raises:
            ReportError: If template rendering or file writing fails.
        """
        if output_path is None:
            output_path = _DEFAULT_REPORT_PATH

        try:
            env = jinja2.Environment(
                loader=jinja2.PackageLoader("bb2gh", "templates"),
                autoescape=True,
            )
            env.globals["format_bytes_human_readable"] = format_bytes_human_readable
            template = env.get_template("discovery_report.html.j2")

            # Load vendored Chart.js (empty string if not yet vendored)
            chart_js_resource = files("bb2gh") / "templates" / "chart.min.js"
            try:
                chart_js = chart_js_resource.read_text(encoding="utf-8")
            except FileNotFoundError:
                chart_js = ""

            inventory_payload = inventory.model_dump(mode="json")
            try:
                deliverables = build_discovery_deliverable_data(inventory)
            except Exception as e:
                logger.error("report_generation_failed", error=str(e), stage="projection")
                msg = f"Failed to build discovery report data: {e}"
                raise ReportError(msg) from e

            deliverables_payload = {
                "repositories": [
                    repo.model_dump(mode="json") for repo in deliverables.repositories
                ],
                "projects": [project.model_dump(mode="json") for project in deliverables.projects],
                "warning_rows": [
                    warning.model_dump(mode="json") for warning in deliverables.warning_rows
                ],
                "generator": deliverables.generator.model_dump(mode="json"),
                "analysis_performed": deliverables.analysis_performed,
            }

            html = template.render(
                inventory_payload=inventory_payload,
                deliverables_payload=deliverables_payload,
                chart_js=chart_js,
            )

            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(html, encoding="utf-8")

        except ReportError:
            raise
        except jinja2.TemplateError as e:
            logger.error("report_generation_failed", error=str(e), stage="render")
            msg = f"Failed to render discovery report template: {e}"
            raise ReportError(msg) from e
        except OSError as e:
            logger.error("report_generation_failed", error=str(e), stage="write")
            msg = f"Failed to write discovery report to {output_path}: {e}"
            raise ReportError(msg) from e

        logger.info(
            "report_generated",
            report_path=str(output_path),
            repo_count=inventory.summary.total_repositories,
        )
        return output_path
