"""Projection models for discovery deliverables.

Builds shared, deterministic data for discovery HTML and Excel outputs from the
repo-centric discovery inventory.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

from bb2gh.__about__ import __version__
from bb2gh.models.inventory import (
    ComplexityLevel,
    Inventory,
    InventoryMetadata,
    InventorySummary,
    RepositoryInventoryItem,
)

PRODUCT_URL = "https://bb2gh.dev"
REPOSITORY_URL = "https://github.com/n8group-oss/bb2gh"
_UNASSIGNED_PROJECT = "Unassigned"


class GeneratorMetadata(BaseModel):
    """Metadata about the tool that generated discovery deliverables."""

    model_config = ConfigDict(extra="forbid")

    tool_name: str = Field(description="Name of the generating tool")
    version: str = Field(description="Exact tool version")
    product_url: str = Field(description="Product homepage URL")
    repository_url: str = Field(description="Source repository URL")


class ProjectDiscoverySummary(BaseModel):
    """Derived rollup for one Bitbucket project."""

    model_config = ConfigDict(extra="forbid")

    name: str = Field(description="Canonical project label")
    repository_count: int = Field(ge=0)
    private_count: int = Field(ge=0)
    public_count: int = Field(ge=0)
    archived_count: int = Field(ge=0)
    fork_count: int = Field(ge=0)
    total_size_bytes: int = Field(ge=0)
    simple_count: int = Field(ge=0)
    moderate_count: int = Field(ge=0)
    complex_count: int = Field(ge=0)
    repos_with_large_files: int = Field(ge=0)
    repos_with_lfs: int = Field(ge=0)
    repos_with_pipelines: int = Field(ge=0)
    warning_count: int = Field(ge=0)


class DiscoveryWarningRow(BaseModel):
    """Flattened warning row for tabular exports."""

    model_config = ConfigDict(extra="forbid")

    source_type: str = Field(description="Source type for this warning row")
    project: str = Field(description="Canonical project label")
    repository: str = Field(description="Repository name")
    category: str = Field(description="Warning category")
    severity: str = Field(description="Warning severity")
    message: str = Field(description="Warning message")


class DiscoveryDeliverableData(BaseModel):
    """Shared projection payload for discovery deliverables."""

    model_config = ConfigDict(extra="forbid")

    metadata: InventoryMetadata = Field(description="Original inventory metadata")
    summary: InventorySummary = Field(description="Original inventory summary")
    repositories: list[RepositoryInventoryItem] = Field(description="Sorted repositories")
    projects: list[ProjectDiscoverySummary] = Field(description="Derived project rollups")
    warning_rows: list[DiscoveryWarningRow] = Field(description="Flattened warning rows")
    generator: GeneratorMetadata = Field(description="Generator metadata")
    analysis_performed: bool = Field(description="Whether deep analysis data is present")


def project_label(project: str | None) -> str:
    """Normalize a project key for customer-facing outputs."""
    if project and project.strip():
        return project
    return _UNASSIGNED_PROJECT


def _repository_sort_key(repo: RepositoryInventoryItem) -> tuple[str, str, str]:
    label = project_label(repo.project)
    return (label, repo.name, repo.full_name)


def _warning_messages(repo: RepositoryInventoryItem) -> list[str]:
    return sorted(set(repo.warnings))


def _warning_rows(repositories: list[RepositoryInventoryItem]) -> list[DiscoveryWarningRow]:
    rows: list[DiscoveryWarningRow] = []
    for repo in repositories:
        label = project_label(repo.project)
        for message in _warning_messages(repo):
            rows.append(
                DiscoveryWarningRow(
                    source_type="repository",
                    project=label,
                    repository=repo.name,
                    category="repository_warning",
                    severity="warning",
                    message=message,
                )
            )
    return sorted(rows, key=lambda row: (row.project, row.repository, row.message))


def _repo_has_analysis(repo: RepositoryInventoryItem) -> bool:
    return (
        repo.branch_count is not None
        or repo.pr_count is not None
        or repo.pipelines is not None
        or bool(repo.large_files)
        or repo.lfs.has_lfs
        or bool(repo.lfs.patterns)
        or bool(repo.warnings)
        or bool(repo.complexity.factors)
        or bool(repo.complexity.notes)
        or repo.complexity.score != 0
    )


def _project_summary(name: str, repos: list[RepositoryInventoryItem]) -> ProjectDiscoverySummary:
    private_count = sum(1 for repo in repos if repo.private)
    analysis_repos = [repo for repo in repos if _repo_has_analysis(repo)]

    simple_count = sum(
        1 for repo in analysis_repos if repo.complexity.level == ComplexityLevel.SIMPLE
    )
    moderate_count = sum(
        1 for repo in analysis_repos if repo.complexity.level == ComplexityLevel.MODERATE
    )
    complex_count = sum(
        1 for repo in analysis_repos if repo.complexity.level == ComplexityLevel.COMPLEX
    )

    return ProjectDiscoverySummary(
        name=name,
        repository_count=len(repos),
        private_count=private_count,
        public_count=len(repos) - private_count,
        archived_count=sum(1 for repo in repos if repo.archived),
        fork_count=sum(1 for repo in repos if repo.fork),
        total_size_bytes=sum(repo.size_bytes or 0 for repo in repos),
        simple_count=simple_count,
        moderate_count=moderate_count,
        complex_count=complex_count,
        repos_with_large_files=sum(1 for repo in analysis_repos if repo.large_files),
        repos_with_lfs=sum(1 for repo in analysis_repos if repo.lfs.has_lfs),
        repos_with_pipelines=sum(
            1
            for repo in analysis_repos
            if repo.pipelines is not None and repo.pipelines.has_pipelines
        ),
        warning_count=sum(len(_warning_messages(repo)) for repo in repos),
    )


def build_discovery_deliverable_data(inventory: Inventory) -> DiscoveryDeliverableData:
    """Build shared deliverable data from the discovery inventory."""
    repositories = sorted(inventory.repositories, key=_repository_sort_key)

    grouped: dict[str, list[RepositoryInventoryItem]] = {}
    for repo in repositories:
        label = project_label(repo.project)
        grouped.setdefault(label, []).append(repo)

    projects = [_project_summary(name, grouped[name]) for name in sorted(grouped)]

    return DiscoveryDeliverableData(
        metadata=inventory.metadata,
        summary=inventory.summary,
        repositories=repositories,
        projects=projects,
        warning_rows=_warning_rows(repositories),
        generator=GeneratorMetadata(
            tool_name=inventory.metadata.generated_by,
            version=__version__,
            product_url=PRODUCT_URL,
            repository_url=REPOSITORY_URL,
        ),
        analysis_performed=any(_repo_has_analysis(repo) for repo in inventory.repositories),
    )
