"""Shared helpers for migrated PR authorship attribution."""

from __future__ import annotations


def format_source_actor(
    *,
    source_username: str | None,
    source_id: str | None = None,
    display_name: str | None = None,
) -> str:
    """Format the original Bitbucket author for human-readable attribution."""
    if source_id and (not source_username or source_username == source_id):
        identity = f"source id: {source_id}"
    elif source_username:
        identity = f"@{source_username}"
    else:
        identity = "unknown"

    if display_name:
        if source_username and display_name == source_username:
            return identity
        return f"{display_name} ({identity})"

    return identity


def build_author_header(
    *,
    source_username: str | None,
    source_id: str | None = None,
    display_name: str | None = None,
    target_username: str | None = None,
    has_github_mapping: bool = False,
) -> str:
    """Build the explicit original-author attribution header."""
    source_actor = format_source_actor(
        source_username=source_username,
        source_id=source_id,
        display_name=display_name,
    )
    if has_github_mapping and target_username:
        return f"Original Bitbucket author: {source_actor}, mapped to @{target_username}"
    return f"Original Bitbucket author: {source_actor}, no GitHub mapping"
