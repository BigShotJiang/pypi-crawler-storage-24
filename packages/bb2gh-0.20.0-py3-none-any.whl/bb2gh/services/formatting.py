"""Formatting helpers shared by discovery deliverables."""

from __future__ import annotations


def format_bytes_human_readable(value: int | None) -> str:
    """Format bytes using the report's human-readable conventions."""
    if value is None:
        return "—"
    if value >= 1024 * 1024 * 1024:
        return f"{value / (1024 * 1024 * 1024):.2f} GB"
    if value >= 1024 * 1024:
        return f"{value / (1024 * 1024):.1f} MB"
    if value >= 1024:
        return f"{value / 1024:.0f} KB"
    return f"{value} B"
