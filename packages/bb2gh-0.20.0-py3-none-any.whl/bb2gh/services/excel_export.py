"""Excel workbook export for discovery deliverables."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table, TableStyleInfo

from bb2gh.exceptions import BB2GHError, ExitCode
from bb2gh.services.discovery_deliverables import build_discovery_deliverable_data
from bb2gh.services.formatting import format_bytes_human_readable

if TYPE_CHECKING:
    from openpyxl.worksheet.worksheet import Worksheet

    from bb2gh.models.inventory import Inventory
    from bb2gh.services.discovery_deliverables import DiscoveryDeliverableData


_DEFAULT_REPORT_DIR = Path(".bb2gh") / "reports"
_DEFAULT_EXCEL_PATH = _DEFAULT_REPORT_DIR / "discovery-report.xlsx"

SUMMARY_HEADERS = ["Section", "Key", "Value"]
SUMMARY_PROJECT_HEADERS = [
    "Project",
    "Repository Count",
    "Private Count",
    "Public Count",
    "Archived Count",
    "Fork Count",
    "Total Size",
    "Simple Count",
    "Moderate Count",
    "Complex Count",
    "Repos With Pipelines",
    "Warning Count",
]
PROJECT_HEADERS = [
    "Project",
    "Repository Count",
    "Private Count",
    "Public Count",
    "Archived Count",
    "Fork Count",
    "Total Size",
    "Simple Count",
    "Moderate Count",
    "Complex Count",
    "Repos With Large Files",
    "Repos With LFS",
    "Repos With Pipelines",
    "Warning Count",
]
REPOSITORY_HEADERS = [
    "Project",
    "Repository ID",
    "Repository",
    "Full Name",
    "Description",
    "Private",
    "Archived",
    "Fork",
    "Default Branch",
    "Size Bytes",
    "Size",
    "Branch Count",
    "PR Count",
    "Complexity Level",
    "Complexity Score",
    "Complexity Notes",
    "Large File Count",
    "Large File Details",
    "LFS Enabled",
    "LFS Patterns",
    "Has Pipeline Analysis",
    "Total Pipeline Steps",
    "Supported Steps",
    "Partially Supported Steps",
    "Unsupported Steps",
    "Script Steps",
    "Pipeline Migration Complexity",
    "Pipeline Migration Notes",
    "Warnings",
    "Created At",
    "Updated At",
]
WARNING_HEADERS = [
    "Source Type",
    "Project",
    "Repository",
    "Category",
    "Severity",
    "Message",
]

_HEADER_FILL = PatternFill(start_color="1F4E79", end_color="1F4E79", fill_type="solid")
_HEADER_FONT = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
_METADATA_FILL = PatternFill(start_color="D6E4F0", end_color="D6E4F0", fill_type="solid")
_METADATA_FONT = Font(name="Calibri", size=11, bold=True, color="1F4E79")
_TOTALS_FILL = PatternFill(start_color="E2EFDA", end_color="E2EFDA", fill_type="solid")
_TOTALS_FONT = Font(name="Calibri", size=11, bold=True)
_DATA_FONT = Font(name="Calibri", size=10)
_LINK_FONT = Font(name="Calibri", size=10, color="2E75B6", underline="single")
_WRAP_ALIGNMENT = Alignment(wrap_text=True, vertical="top")
_THIN_BORDER = Border(
    left=Side(style="thin", color="D9D9D9"),
    right=Side(style="thin", color="D9D9D9"),
    top=Side(style="thin", color="D9D9D9"),
    bottom=Side(style="thin", color="D9D9D9"),
)
_ALT_ROW_FILL = PatternFill(start_color="F5F5F5", end_color="F5F5F5", fill_type="solid")
_COMPLEXITY_COLORS: dict[str, PatternFill] = {
    "simple": PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid"),
    "moderate": PatternFill(start_color="FFEB9C", end_color="FFEB9C", fill_type="solid"),
    "complex": PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid"),
}
_MIGRATION_COLORS: dict[str, PatternFill] = {
    "trivial": PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid"),
    "low": PatternFill(start_color="D6E4F0", end_color="D6E4F0", fill_type="solid"),
    "medium": PatternFill(start_color="FFEB9C", end_color="FFEB9C", fill_type="solid"),
    "high": PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid"),
}
_WARNING_COLORS: dict[str, PatternFill] = {
    "warning": PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid"),
    "note": PatternFill(start_color="FFEB9C", end_color="FFEB9C", fill_type="solid"),
    "info": PatternFill(start_color="FFEB9C", end_color="FFEB9C", fill_type="solid"),
}
_TAB_COLORS: dict[str, str] = {
    "Summary": "1F4E79",
    "Projects": "2E75B6",
    "Repositories": "2E75B6",
    "Warnings": "C00000",
}


class ExcelExportError(BB2GHError):
    """Raised when Excel export fails."""

    def __init__(self, message: str) -> None:
        super().__init__(message, exit_code=ExitCode.SYSTEM_ERROR)


def _yes_no(value: bool) -> str:
    return "Yes" if value else "No"


def _join_lines(values: list[str]) -> str | None:
    non_empty = [value for value in values if value]
    return "\n".join(non_empty) if non_empty else None


def _iso(value: object) -> str | None:
    if value is None:
        return None
    if hasattr(value, "isoformat"):
        return value.isoformat()  # type: ignore[no-any-return]
    return str(value)


def _analysis_value(data: DiscoveryDeliverableData, value: object) -> object | None:
    if not data.analysis_performed:
        return None
    return value


def _display_value(value: object | None) -> object:
    if value is None:
        return "Unavailable"
    return value


def _link_label(url: str) -> str:
    return url.replace("https://", "").replace("http://", "").rstrip("/")


def _create_sheet(workbook: Workbook, title: str, headers: list[str]) -> Worksheet:
    worksheet = workbook.create_sheet(title=title)
    worksheet.append(headers)
    return worksheet


def _create_summary_sheet(workbook: Workbook, data: DiscoveryDeliverableData) -> Worksheet:
    worksheet = workbook.create_sheet(title="Summary")
    worksheet.append(["BB2GH Discovery Report"])
    worksheet.append(["Bitbucket to GitHub Migration Inventory"])
    worksheet.append(
        [
            _link_label(data.generator.product_url),
            _link_label(data.generator.repository_url),
        ]
    )
    worksheet.append([None])
    worksheet.append(SUMMARY_HEADERS)
    return worksheet


def _add_table(sheet: Worksheet, name: str) -> None:
    max_row = sheet.max_row
    max_col = sheet.max_column
    if max_row < 1 or max_col < 1:
        return
    if max_row == 1:
        sheet.append([None] * max_col)
        max_row = 2
    ref = f"A1:{get_column_letter(max_col)}{max_row}"
    table = Table(displayName=name, ref=ref)
    table.tableStyleInfo = TableStyleInfo(
        name="TableStyleMedium2",
        showFirstColumn=False,
        showLastColumn=False,
        showRowStripes=True,
        showColumnStripes=False,
    )
    sheet.add_table(table)


def _write_summary_sheet(sheet: Worksheet, data: DiscoveryDeliverableData) -> None:
    meta = data.metadata
    summary = data.summary
    generator = data.generator

    metadata_rows: list[list[object | None]] = [
        ["Metadata", "Workspace", meta.workspace],
        ["Metadata", "Source Type", meta.source_type],
        ["Metadata", "Generated At", _iso(meta.generated_at)],
        ["Metadata", "Schema Version", meta.schema_version],
        ["Metadata", "Tool Version", generator.version],
        ["Metadata", "Analysis Performed", _yes_no(data.analysis_performed)],
        ["Metadata", "Workspace User Count", _display_value(summary.workspace_user_count)],
    ]
    totals_rows: list[list[object | None]] = [
        ["Totals", "Total Repositories", summary.total_repositories],
        ["Totals", "Total Size", format_bytes_human_readable(summary.total_size_bytes)],
        ["Totals", "Private Count", summary.private_count],
        ["Totals", "Public Count", summary.public_count],
        ["Totals", "Archived Count", summary.archived_count],
        ["Totals", "Fork Count", summary.fork_count],
        ["Totals", "Repos With Pipelines", _analysis_value(data, summary.repos_with_pipelines)],
        ["Totals", "Repos With Large Files", _analysis_value(data, summary.repos_with_large_files)],
        ["Totals", "Repos With LFS", _analysis_value(data, summary.repos_with_lfs)],
        ["Totals", "Total Warnings", _analysis_value(data, summary.total_warnings)],
        ["Totals", "Complexity Simple", _analysis_value(data, summary.complexity_simple)],
        ["Totals", "Complexity Moderate", _analysis_value(data, summary.complexity_moderate)],
        ["Totals", "Complexity Complex", _analysis_value(data, summary.complexity_complex)],
    ]

    for row in metadata_rows:
        sheet.append(row)
    for row in totals_rows:
        sheet.append(row)

    sheet.append([None])
    sheet.append(SUMMARY_PROJECT_HEADERS)

    for project in data.projects:
        sheet.append(
            [
                project.name,
                project.repository_count,
                project.private_count,
                project.public_count,
                project.archived_count,
                project.fork_count,
                format_bytes_human_readable(project.total_size_bytes),
                _analysis_value(data, project.simple_count),
                _analysis_value(data, project.moderate_count),
                _analysis_value(data, project.complex_count),
                _analysis_value(data, project.repos_with_pipelines),
                _analysis_value(data, project.warning_count),
            ]
        )


def _write_projects_sheet(sheet: Worksheet, data: DiscoveryDeliverableData) -> None:
    for project in data.projects:
        sheet.append(
            [
                project.name,
                project.repository_count,
                project.private_count,
                project.public_count,
                project.archived_count,
                project.fork_count,
                format_bytes_human_readable(project.total_size_bytes),
                _analysis_value(data, project.simple_count),
                _analysis_value(data, project.moderate_count),
                _analysis_value(data, project.complex_count),
                _analysis_value(data, project.repos_with_large_files),
                _analysis_value(data, project.repos_with_lfs),
                _analysis_value(data, project.repos_with_pipelines),
                _analysis_value(data, project.warning_count),
            ]
        )


def _write_repositories_sheet(sheet: Worksheet, data: DiscoveryDeliverableData) -> None:
    for repo in data.repositories:
        pipeline = repo.pipelines
        large_file_details = _join_lines(
            [f"{large_file.path} ({large_file.size_bytes})" for large_file in repo.large_files]
        )
        warnings = _join_lines(sorted(set(repo.warnings)))
        sheet.append(
            [
                repo.project or "Unassigned",
                repo.id,
                repo.name,
                repo.full_name,
                repo.description,
                _yes_no(repo.private),
                _yes_no(repo.archived),
                _yes_no(repo.fork),
                repo.default_branch,
                repo.size_bytes,
                format_bytes_human_readable(repo.size_bytes),
                _analysis_value(data, repo.branch_count),
                _analysis_value(data, repo.pr_count),
                _analysis_value(data, repo.complexity.level.value),
                _analysis_value(data, repo.complexity.score),
                _analysis_value(data, _join_lines(repo.complexity.notes)),
                _analysis_value(data, len(repo.large_files)),
                _analysis_value(data, large_file_details),
                _analysis_value(data, _yes_no(repo.lfs.has_lfs)),
                _analysis_value(data, _join_lines(repo.lfs.patterns)),
                _analysis_value(data, _yes_no(pipeline is not None)),
                _analysis_value(data, pipeline.total_step_count if pipeline else None),
                _analysis_value(data, pipeline.supported_step_count if pipeline else None),
                _analysis_value(
                    data, pipeline.partially_supported_step_count if pipeline else None
                ),
                _analysis_value(data, pipeline.unsupported_step_count if pipeline else None),
                _analysis_value(data, pipeline.script_step_count if pipeline else None),
                _analysis_value(data, pipeline.migration_complexity.value if pipeline else None),
                _analysis_value(data, _join_lines(pipeline.migration_notes) if pipeline else None),
                _analysis_value(data, warnings),
                _iso(repo.created_at),
                _iso(repo.updated_at),
            ]
        )


def _write_warnings_sheet(sheet: Worksheet, data: DiscoveryDeliverableData) -> None:
    for row in data.warning_rows:
        sheet.append(
            [
                row.source_type,
                row.project,
                row.repository,
                row.category,
                row.severity,
                row.message,
            ]
        )


def _auto_fit_columns(sheet: Worksheet, min_width: int = 10, max_width: int = 50) -> None:
    for col_cells in sheet.columns:
        max_len = 0
        col_letter = get_column_letter(col_cells[0].column)
        for cell in col_cells:
            if cell.value is not None:
                cell_len = max(len(str(line)) for line in str(cell.value).split("\n"))
                max_len = max(max_len, cell_len)
        adjusted = min(max(max_len + 2, min_width), max_width)
        sheet.column_dimensions[col_letter].width = adjusted


def _style_header_row(sheet: Worksheet, row_number: int) -> None:
    for cell in sheet[row_number]:
        cell.font = _HEADER_FONT
        cell.fill = _HEADER_FILL
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = _THIN_BORDER


def _style_data_cells(sheet: Worksheet, *, min_row: int = 2) -> None:
    for row in sheet.iter_rows(min_row=min_row, max_row=sheet.max_row, max_col=sheet.max_column):
        for cell in row:
            cell.font = _DATA_FONT
            cell.border = _THIN_BORDER
            cell.alignment = _WRAP_ALIGNMENT


def _apply_alternating_rows(sheet: Worksheet, *, min_row: int = 2) -> None:
    for row_idx in range(min_row + 1, sheet.max_row + 1, 2):
        for cell in sheet[row_idx]:
            if cell.fill == PatternFill():
                cell.fill = _ALT_ROW_FILL


def _bold_first_column(sheet: Worksheet, *, min_row: int = 2) -> None:
    for row in sheet.iter_rows(min_row=min_row, max_row=sheet.max_row):
        if row[0].value is not None:
            row[0].font = Font(name="Calibri", size=10, bold=True)


def _apply_number_formatting(workbook: Workbook) -> None:
    number_fmt = "#,##0"

    summary = workbook["Summary"]
    for row in range(13, 26):
        cell = summary[f"C{row}"]
        if isinstance(cell.value, (int, float)):
            cell.number_format = number_fmt
    for row in range(28, summary.max_row + 1):
        for col_idx in [2, 3, 4, 5, 6, 8, 9, 10, 11, 12]:
            cell = summary.cell(row=row, column=col_idx)
            if isinstance(cell.value, (int, float)):
                cell.number_format = number_fmt

    projects = workbook["Projects"]
    for row in projects.iter_rows(min_row=2, max_row=projects.max_row):
        for col_idx in [2, 3, 4, 5, 6, 8, 9, 10, 11, 12, 13, 14]:
            if col_idx <= len(row):
                cell = row[col_idx - 1]
                if isinstance(cell.value, (int, float)):
                    cell.number_format = number_fmt

    repositories = workbook["Repositories"]
    for row in repositories.iter_rows(min_row=2, max_row=repositories.max_row):
        for col_idx in [10, 12, 13, 15, 17, 22, 23, 24, 25, 26]:
            if col_idx <= len(row):
                cell = row[col_idx - 1]
                if isinstance(cell.value, (int, float)):
                    cell.number_format = number_fmt


def _style_summary_sheet(sheet: Worksheet, data: DiscoveryDeliverableData) -> None:
    sheet.merge_cells("A1:C1")
    sheet["A1"].font = Font(name="Calibri", size=16, bold=True, color="1F4E79")
    sheet["A1"].alignment = Alignment(horizontal="left")

    sheet.merge_cells("A2:C2")
    sheet["A2"].font = Font(name="Calibri", size=11, italic=True, color="808080")

    sheet["A3"].hyperlink = data.generator.product_url
    sheet["A3"].font = _LINK_FONT
    sheet["B3"].hyperlink = data.generator.repository_url
    sheet["B3"].font = _LINK_FONT

    _style_header_row(sheet, 5)

    project_header_row: int | None = None
    for row_idx in range(6, sheet.max_row + 1):
        first_value = sheet.cell(row=row_idx, column=1).value
        second_value = sheet.cell(row=row_idx, column=2).value
        for cell in sheet[row_idx]:
            cell.border = _THIN_BORDER
            cell.alignment = _WRAP_ALIGNMENT

        if first_value == "Metadata":
            for cell in sheet[row_idx]:
                cell.fill = _METADATA_FILL
                cell.font = _METADATA_FONT
        elif first_value == "Totals":
            for cell in sheet[row_idx]:
                cell.fill = _TOTALS_FILL
                cell.font = _TOTALS_FONT
            sheet.cell(row=row_idx, column=3).alignment = Alignment(
                horizontal="right", vertical="center"
            )
        elif first_value == "Project" and second_value == "Repository Count":
            project_header_row = row_idx
            _style_header_row(sheet, row_idx)
        elif project_header_row is not None and row_idx > project_header_row:
            for cell in sheet[row_idx]:
                cell.font = _DATA_FONT
                cell.border = _THIN_BORDER
                cell.alignment = _WRAP_ALIGNMENT
            if sheet.cell(row=row_idx, column=1).value is not None:
                sheet.cell(row=row_idx, column=1).font = Font(name="Calibri", size=10, bold=True)

    _apply_alternating_rows(sheet, min_row=project_header_row or sheet.max_row)


def _apply_semantic_fills(workbook: Workbook) -> None:
    repositories = workbook["Repositories"]
    for row in repositories.iter_rows(min_row=2, max_row=repositories.max_row):
        complexity_cell = row[13]
        complexity_value = str(complexity_cell.value).lower() if complexity_cell.value else ""
        if complexity_value in _COMPLEXITY_COLORS:
            complexity_cell.fill = _COMPLEXITY_COLORS[complexity_value]

        migration_cell = row[26]
        migration_value = str(migration_cell.value).lower() if migration_cell.value else ""
        if migration_value in _MIGRATION_COLORS:
            migration_cell.fill = _MIGRATION_COLORS[migration_value]

    warnings = workbook["Warnings"]
    for row in warnings.iter_rows(min_row=2, max_row=warnings.max_row):
        severity_cell = row[4]
        severity_value = str(severity_cell.value).lower() if severity_cell.value else ""
        if severity_value in _WARNING_COLORS:
            severity_cell.fill = _WARNING_COLORS[severity_value]


def _apply_formatting(workbook: Workbook, data: DiscoveryDeliverableData) -> None:
    for sheet_name in ["Projects", "Repositories", "Warnings"]:
        sheet = workbook[sheet_name]
        sheet.freeze_panes = "A2"
        _add_table(sheet, sheet_name.replace(" ", "") + "Table")
        _style_header_row(sheet, 1)
        _style_data_cells(sheet)
        _apply_alternating_rows(sheet)
        _bold_first_column(sheet)
        _auto_fit_columns(sheet)

    summary = workbook["Summary"]
    summary.freeze_panes = "A6"
    _style_summary_sheet(summary, data)
    _auto_fit_columns(summary)

    _apply_number_formatting(workbook)
    _apply_semantic_fills(workbook)

    for sheet_name, color in _TAB_COLORS.items():
        workbook[sheet_name].sheet_properties.tabColor = color


class ExcelExportService:
    """Generate Excel workbooks from discovery inventory."""

    @staticmethod
    def generate(inventory: Inventory, output_path: Path | None = None) -> Path:
        """Write the workbook to disk and return the output path."""
        if output_path is None:
            output_path = _DEFAULT_EXCEL_PATH

        data = build_discovery_deliverable_data(inventory)

        workbook = Workbook()
        workbook.remove(workbook.active)

        summary_sheet = _create_summary_sheet(workbook, data)
        projects_sheet = _create_sheet(workbook, "Projects", PROJECT_HEADERS)
        repositories_sheet = _create_sheet(workbook, "Repositories", REPOSITORY_HEADERS)
        warnings_sheet = _create_sheet(workbook, "Warnings", WARNING_HEADERS)

        _write_summary_sheet(summary_sheet, data)
        _write_projects_sheet(projects_sheet, data)
        _write_repositories_sheet(repositories_sheet, data)
        _write_warnings_sheet(warnings_sheet, data)
        _apply_formatting(workbook, data)

        try:
            output_path.parent.mkdir(parents=True, exist_ok=True)
            workbook.save(output_path)
        except OSError as exc:
            msg = f"Failed to write Excel workbook to {output_path}: {exc}"
            raise ExcelExportError(msg) from exc

        return output_path
