from blends.ctx import ctx
from blends.models import (
    NId,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)


def build_catch_clause_node(
    args: SyntaxGraphArgs,
    block_node: NId | None,
    catch_decl: NId | None = None,
) -> NId:
    args.syntax_graph.add_node(
        args.n_id,
        label_type="CatchClause",
    )

    if block_node:
        args.syntax_graph.update_node_attribute(args.n_id, "block_id", block_node)
        args.syntax_graph.add_edge(
            args.n_id,
            args.generic(args.fork_n_id(block_node)),
            label_ast="AST",
        )

    if catch_decl:
        args.syntax_graph.update_node_attribute(args.n_id, "catch_declaration", catch_decl)
        args.syntax_graph.add_edge(
            args.n_id,
            args.generic(args.fork_n_id(catch_decl)),
            label_ast="AST",
        )
        if (
            ctx.has_feature_flag("ScopeIndex")
            and (variable := args.syntax_graph.nodes.get(catch_decl, {}).get("variable"))
            and (scope_stack := args.metadata.get("scope_stack"))
        ):
            args.syntax_graph.symbol_index.setdefault(variable, {}).setdefault(
                scope_stack[-1], []
            ).append(catch_decl)

    return args.n_id
