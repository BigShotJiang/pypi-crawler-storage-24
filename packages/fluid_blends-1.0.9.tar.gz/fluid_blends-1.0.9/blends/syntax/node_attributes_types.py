from __future__ import annotations

from typing import TYPE_CHECKING, TypedDict

if TYPE_CHECKING:
    from blends.syntax.models import FileInstanceData, FileStructData


class SyntaxNodeAttrs(TypedDict, total=False):
    access_modifier: str
    access_modifiers: str
    annotation_id: int
    argument_name: str
    arguments_id: int
    attributes_id: int
    block_id: int
    case_expression: str
    catch_declaration: int
    comment: str
    condition_id: int
    constructor_id: int
    declaration_id: int
    expression: str
    expression_id: int
    false_id: int
    import_type: str
    imports: list[str]
    inherited_class: str
    initializer: int
    initializer_id: int
    initializers: str
    instances: dict[str, dict[str, FileInstanceData]]
    iterable_item_id: int
    key_id: int
    label_alias: str
    label_c: str
    label_l: str
    label_type: str
    left_id: int
    member: str
    method_name: str
    modifiers_id: int
    name: str
    node_type: str
    object: str
    object_id: int
    operand_id: int
    operator: str
    parameter_mode: str
    parameters_id: int
    path: str
    resources_id: int
    right_id: int
    selector_name: str
    sg_node_type: str
    stack_graph_import_module_stem: str
    stack_graph_import_relative_level: int
    stack_graph_import_source_symbol: str
    stack_graph_is_definition: bool
    stack_graph_is_exported: bool
    stack_graph_is_import_binding: bool
    stack_graph_is_reference: bool
    stack_graph_kind: str
    stack_graph_precedence: int
    stack_graph_scope: int
    stack_graph_scope_type: str
    stack_graph_symbol: str
    structure: dict[str, FileStructData]
    symbol: str
    symbol_scope: int
    tf_reference: str
    true_id: int
    update_id: int
    value: str
    value_id: int
    value_type: str
    variable: str
    variable_id: int
    variable_type: str
