#
#
#


from datetime import datetime
from json import loads
from logging import getLogger
from os import environ
from shlex import split as shlex_split
from subprocess import PIPE, run

from .pr import Pr


class GitHubCli:

    def __init__(self, repo=None, max_lookback=50, base_branch='main'):
        self.log = getLogger('GitHubCli[{repo}]')
        self.log.info(
            '__init__: repo=%s, max_lookback=%d, base_branch=%s',
            repo,
            max_lookback,
            base_branch,
        )
        self.repo = repo
        self.max_lookback = max_lookback
        self.base_branch = base_branch

        self._prs = None

    def _run(self, cmd):
        result = run(cmd, check=True, stdout=PIPE)
        return loads(result.stdout)

    def prs(self, root, directory):
        # we're making an assumption here that we'll always be called with the
        # same root & directory so we can use them once and cache the results.
        if self._prs is None:
            # will be indexed by both id & filename
            prs = {}

            cmd = [
                'gh',
                'pr',
                'list',
                '--base',
                self.base_branch,
                '--state',
                'merged',
                f'--limit={self.max_lookback}',
                '--json',
                'files,mergedAt,number',
            ]
            repo = self.repo
            if repo:
                cmd.extend(('--repo', f'{repo}'))

            # we need to know the repo for PR urls
            if not repo:
                repo = self._run(
                    ['gh', 'repo', 'view', '--json', 'nameWithOwner']
                )['nameWithOwner']

            for pr in self._run(cmd):
                number = pr['number']
                url = f'https://github.com/{repo}/pull/{number}'
                merged_at = datetime.fromisoformat(pr['mergedAt'])

                files = [
                    f['path']
                    for f in pr['files']
                    if f['path'].startswith(f'{directory}/')
                ]
                if not files:
                    # no changelog entries, ignore it
                    continue

                pr = Pr(
                    id=number, text=f'#{number}', url=url, merged_at=merged_at
                )
                prs[number] = pr
                for filename in files:
                    prs[filename] = pr
            self._prs = prs

        return self._prs

    def pr_by_id(self, root, directory, id):
        return self.prs(root=root, directory=directory).get(id)

    def pr_by_filename(self, root, directory, filename):
        return self.prs(root=root, directory=directory).get(filename)

    def changelog_entries_in_branch(self, root, directory):
        result = run(
            ['git', 'diff', '--name-only', f'origin/{self.base_branch}'],
            check=False,
            stdout=PIPE,
        )
        return {
            l
            for l in result.stdout.decode('utf-8').split()
            if l.endswith('.md') and l.startswith(f'{directory}/')
        }

    def add_file(self, filename):
        cmd = ['git', 'add', filename]
        extra_args = environ.get('CHANGELET_GIT_ADD_ARGS', '').strip()
        if extra_args:
            # Use shlex.split to handle quoted arguments properly
            cmd[2:2] = shlex_split(extra_args)
        run(cmd, check=True)

    def has_staged(self, exclude=None):
        result = run(
            ['git', 'diff', '--staged', '--name-only'],
            check=True,
            capture_output=True,
        )
        files = set(result.stdout.decode('utf-8').split())
        if exclude:
            files -= {exclude}
        return len(files) > 0

    def staged_changelog_entry(self, directory):
        result = run(
            ['git', 'diff', '--staged', '--name-only'],
            check=True,
            capture_output=True,
        )
        for line in result.stdout.decode('utf-8').split():
            if line.startswith(f'{directory}/') and line.endswith('.md'):
                return line
        return None

    def commit(self, description):
        cmd = ['git', 'commit', '--message', description]
        extra_args = environ.get('CHANGELET_GIT_COMMIT_ARGS', '').strip()
        if extra_args:
            # Use shlex.split to handle quoted arguments properly
            cmd[2:2] = shlex_split(extra_args)
        run(cmd, check=True)

    def current_branch(self):
        result = run(
            ['git', 'branch', '--show-current'],
            check=True,
            capture_output=True,
            text=True,
        )
        return result.stdout.strip()

    def has_local_changes(self):
        result = run(
            ['git', 'status', '--porcelain'],
            check=True,
            capture_output=True,
            text=True,
        )
        return bool(result.stdout.strip())

    def pull(self):
        run(['git', 'pull'], check=True, capture_output=True, text=True)

    def create_branch(self, name):
        run(
            ['git', 'checkout', '-b', name],
            check=True,
            capture_output=True,
            text=True,
        )

    def push_branch(self, name):
        run(
            ['git', 'push', '-u', 'origin', name],
            check=True,
            capture_output=True,
            text=True,
        )

    def create_pr(self, title, body):
        result = run(
            [
                'gh',
                'pr',
                'create',
                '--title',
                title,
                '--body',
                body,
                '--assignee',
                '@me',
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        return result.stdout.strip()

    def __repr__(self):
        return f'GitHubCli<repo={self.repo}, max_lookback={self.max_lookback}, base_branch={self.base_branch}>'
