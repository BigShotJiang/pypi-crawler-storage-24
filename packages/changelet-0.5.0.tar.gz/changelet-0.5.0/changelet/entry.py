#
#
#

from datetime import datetime, timezone
from enum import Enum
from os import listdir, makedirs, remove
from os.path import dirname, isdir, join

from yaml import safe_load


class EntryType(Enum):
    NONE = 'none'
    PATCH = 'patch'
    MINOR = 'minor'
    MAJOR = 'major'


class Entry:
    EPOCH = datetime(1970, 1, 1, tzinfo=timezone.utc)
    ORDERING = {
        EntryType.MAJOR: 3,
        EntryType.MINOR: 2,
        EntryType.PATCH: 1,
        EntryType.NONE: 0,
    }

    @classmethod
    def _parse_file(cls, filename):
        with open(filename, 'r') as fh:
            pieces = fh.read().split('---\n', 2)
            data = safe_load(pieces[1])
            description = pieces[2]
            return data, description

    @classmethod
    def load(cls, filename, config):
        data, description = cls._parse_file(filename)
        if 'pr' in data:
            pr = config.provider.pr_by_id(
                root=config.root, directory=config.directory, id=data['pr']
            )
        else:
            pr = config.provider.pr_by_filename(
                root=config.root, directory=config.directory, filename=filename
            )
        return Entry(
            filename=filename, type=data['type'], description=description, pr=pr
        )

    @classmethod
    def load_file(cls, filename):
        data, description = cls._parse_file(filename)
        return Entry(
            filename=filename, type=data['type'], description=description
        )

    @classmethod
    def load_all(cls, config):
        directory = config.directory
        entries = []
        if isdir(directory):
            for filename in sorted(listdir(directory)):
                if not filename.endswith('.md'):
                    continue
                filename = join(directory, filename)
                entries.append(Entry.load(filename, config))
        return entries

    def __init__(self, type, description, pr=None, filename=None):
        self._description = None
        self._type = None

        self.type = type
        self.description = description
        self.pr = pr
        self.filename = filename

    @property
    def type(self):
        return self._type

    @type.setter
    def type(self, value):
        if isinstance(value, EntryType):
            self._type = value
        else:
            self._type = EntryType(value)

    @property
    def description(self):
        return self._description

    @description.setter
    def description(self, value):
        self._description = value.strip()

    @property
    def _ordering(self):
        return (
            self.ORDERING[self.type],
            self.pr.merged_at if self.pr else self.EPOCH,
        )

    def save(self, filename=None):
        if filename is None:
            filename = self.filename
        directory = dirname(filename)
        if not isdir(directory):
            makedirs(directory)
        with open(filename, 'w') as fh:
            fh.write('---\ntype: ')
            fh.write(self.type.value)
            if self.pr:
                fh.write('\npr: ')
                fh.write(str(self.pr.id))
            fh.write('\n---\n')
            fh.write(self.description)
            fh.write('\n')
        self.filename = filename

    def remove(self):
        if not self.filename:
            return False
        remove(self.filename)
        return True

    @property
    def text(self):
        if self.pr:
            return f'* {self.description} - {self.pr.plain}'
        return f'* {self.description}'

    @property
    def markdown(self):
        if self.pr:
            return f'* {self.description} - {self.pr.markdown}'
        return f'* {self.description}'

    def copy(self):
        return Entry(
            type=self.type,
            description=self.description,
            pr=self.pr,
            filename=self.filename,
        )

    def __lt__(self, other):
        return self._ordering < other._ordering

    def __repr__(self):
        return f'Entry<{self.type.value}, {self.description[:16]}, {self.filename}, {self.pr}>'
