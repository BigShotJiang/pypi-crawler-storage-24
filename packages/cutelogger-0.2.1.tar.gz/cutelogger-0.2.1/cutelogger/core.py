from .utils import color
from .utils import creation

# print("RUNNING LOCAL VERSION")
__all__ = ["log", "log_help"]

COLOR_MAP = {
    "debug": color.DEBUG,
    "info": color.INFO,
    "warning": color.WARNING,
    "error": color.ERROR,
    "critical": color.CRITICAL,
    "success": color.SUCCESS,
    "fail": color.FAIL,
    "blue": color.BLUE,
    "magenta": color.MAGENTA,
    "white": color.WHITE,
    "gray": color.GRAY,
}

HELP_TEXT = {
    "debug": "cyan - used for debugging details (dev-only info)",
    "info": "green - used for general information",
    "warning": "yellow - used when something might go wrong",
    "error": "red - used when something fails",
    "critical": "red bg - used for serious system failures",
    "success": "bright green - used for successful operations",
    "fail": "bright red - used for failed operations",
    "blue": "blue - used for highlights or custom logs",
    "magenta": "magenta - used for special/rare logs",
    "white": "white - used for neutral/default text",
    "gray": "gray - used for less important/subtle logs",
}

def log(message,state="none"):
    state = state.lower()
    if state == "none":
        print(message)
        return

    ansi = COLOR_MAP.get(state)
    if ansi:
        print(f'{ansi}{message}{color.RESET}')
        if creation.log_file:
            save_log = f"[{state}]: {message}\n"
            creation.logs.append(save_log)
            if creation.auto_save:
                creation.log_to_file(save_log,name=creation.filename,ext=creation.ext)
    else:
        raise ValueError("State NOT found. please use log_help()")

def log_help(argg="everything"):
    argg = argg.lower()

    if argg == "everything":
        for key, desc in HELP_TEXT.items():
            ansi = COLOR_MAP[key]
            print(f"{ansi}{key.upper()}{color.RESET} - {desc}")
    elif argg == "grey":
        print("LMAO, you spelt gray wrong")
    else:
        desc = HELP_TEXT.get(argg)
        ansi = COLOR_MAP.get(argg)

        if desc and ansi:
            print(f"{ansi}{argg.upper()}{color.RESET} - {desc}")
        else:
            print(f"Unknown state '{argg}'. Call help() with no args to see all options.")
