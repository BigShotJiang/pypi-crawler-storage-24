from claude_session_sync.cli import main

if __name__ == "__main__":
    main()
