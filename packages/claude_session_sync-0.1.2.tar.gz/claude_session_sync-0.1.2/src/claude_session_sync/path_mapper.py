from __future__ import annotations


class PathMapper:
    """Convert between real local paths and portable placeholder strings."""

    def __init__(self, placeholders: dict) -> None:
        """Initialize with a mapping of placeholder -> real path.

        Example:
            {"{{HOME}}": "/home/tubome"}
        """
        self._placeholders = placeholders
        # Build reverse mapping: real path -> placeholder
        self._real_to_placeholder: dict[str, str] = {
            v: k for k, v in placeholders.items()
        }
        # Windowsパス正規化版も追加（バックスラッシュ→スラッシュ）
        normalized_extra: dict[str, str] = {}
        for real_path, placeholder in self._real_to_placeholder.items():
            normalized = real_path.replace("\\", "/")
            if normalized != real_path and normalized not in self._real_to_placeholder:
                normalized_extra[normalized] = placeholder
        self._real_to_placeholder.update(normalized_extra)

    def to_placeholder(self, text: str) -> str:
        """Replace real paths in text with placeholders.

        Longer paths are replaced first to avoid partial replacements
        (e.g. /home/tubome/projects is replaced before /home/tubome).
        """
        # Sort real paths by length descending so longer paths match first
        sorted_paths = sorted(
            self._real_to_placeholder.keys(), key=len, reverse=True
        )
        for real_path in sorted_paths:
            placeholder = self._real_to_placeholder[real_path]
            # Windowsのバックスラッシュにも対応
            text = text.replace(real_path, placeholder)
            # バックスラッシュ版でもマッチを試みる
            normalized_real = real_path.replace("\\", "/")
            if normalized_real != real_path:
                text = text.replace(normalized_real, placeholder)
        return text

    def to_local(self, text: str) -> str:
        """Replace placeholders in text with real local paths."""
        for placeholder, real_path in self._placeholders.items():
            text = text.replace(placeholder, real_path)
        return text

    def convert_project_dir_name(self, name: str) -> str:
        """Convert a project directory name between machines.

        Claude stores project paths as directory names by replacing '/' with '-'.
        For example: /home/tubome/projects -> -home-tubome-projects

        This method applies placeholder substitution at the directory-name level
        so that names can be translated across platforms.

        Example:
            -home-tubome-projects  (Linux)
            -> -Users-tubome-projects  (macOS)
        """
        # Convert from directory-name form back to path form
        path_form = self.dir_name_to_path(name)
        # Apply placeholder conversion
        converted = self.to_placeholder(path_form)
        converted = self.to_local(converted)
        # Convert back to directory-name form
        return self.path_to_project_dir(converted)

    @staticmethod
    def path_to_project_dir(path: str) -> str:
        """Convert a filesystem path to a Claude project directory name.

        Claude Code の HD() 関数と同じアルゴリズム:
        [^a-zA-Z0-9] を全て '-' に置換する。

        Example:
            /home/tubome/projects    ->  -home-tubome-projects
            C:\\Users\\tubome\\projects  ->  C--Users-tubome-projects
        """
        import re
        return re.sub(r"[^a-zA-Z0-9]", "-", path)

    @staticmethod
    def dir_name_to_path(name: str) -> str:
        """Convert a Claude project directory name back to a filesystem path.

        This is the inverse of path_to_project_dir.

        Example:
            -home-tubome-projects      ->  /home/tubome/projects
            --PROJECTS--               ->  {{PROJECTS}}
            --PROJECTS---crossclip     ->  {{PROJECTS}}/crossclip

        Note: This heuristic assumes the directory name started with a leading
        separator, which is always the case for absolute paths stored by Claude.
        Placeholder tokens like {{PROJECTS}} are encoded as --PROJECTS-- by
        path_to_project_dir and are restored here before converting remaining
        dashes to slashes.
        """
        import re
        # Restore {{PLACEHOLDER}} tokens that were encoded as --PLACEHOLDER--
        result = re.sub(r"--([A-Z][A-Z0-9_]*)--", r"{{\1}}", name)
        # Replace remaining '-' with '/' to recover the path
        # The leading '-' becomes the leading '/'
        result = re.sub(r"-(?!\})", "/", result)
        return result
