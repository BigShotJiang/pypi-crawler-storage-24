from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional


@dataclass
class Session:
    session_id: str
    project_dir: str        # e.g. -home-tubome-projects
    project_path: str       # e.g. /home/tubome/projects  (from first cwd field)
    file_path: str          # full path to the .jsonl file
    first_message: str      # content of the first user message
    last_modified: float    # file mtime (epoch seconds)
    size: int               # file size in bytes


def _extract_metadata(file_path: str) -> tuple[str, str]:
    """Read the first few lines of a .jsonl file and extract:
      - project_path: the ``cwd`` field from the first entry that has one
      - first_message: the display text of the first ``user`` role entry

    Returns (project_path, first_message).  Both default to "" if not found.
    """
    project_path = ""
    first_message = ""
    max_lines = 50  # read at most this many lines to keep it fast

    try:
        with open(file_path, "r", encoding="utf-8", errors="replace") as f:
            for i, line in enumerate(f):
                if i >= max_lines:
                    break
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                except json.JSONDecodeError:
                    continue

                # Extract cwd for project_path
                if not project_path and isinstance(entry.get("cwd"), str):
                    project_path = entry["cwd"]

                # Extract first user message
                if not first_message and entry.get("type") == "user":
                    message = entry.get("message", {})
                    content = message.get("content", "")
                    if isinstance(content, str):
                        first_message = content
                    elif isinstance(content, list):
                        # content can be a list of blocks
                        for block in content:
                            if isinstance(block, dict):
                                text = block.get("text", "") or block.get("display", "")
                                if text:
                                    first_message = text
                                    break

                if project_path and first_message:
                    break
    except OSError:
        pass

    return project_path, first_message


def discover_sessions(claude_projects_dir: str) -> List[Session]:
    """Discover all Claude session files under *claude_projects_dir*.

    Scans ``<claude_projects_dir>/<project_dir>/*.jsonl`` and returns a list
    of :class:`Session` objects sorted by last-modified time (newest first).
    """
    sessions: List[Session] = []
    base = Path(claude_projects_dir)

    if not base.is_dir():
        return sessions

    for project_dir_path in base.iterdir():
        if not project_dir_path.is_dir():
            continue
        project_dir_name = project_dir_path.name

        for jsonl_file in project_dir_path.glob("*.jsonl"):
            stat = jsonl_file.stat()
            session_id = jsonl_file.stem  # filename without extension

            project_path, first_message = _extract_metadata(str(jsonl_file))

            sessions.append(
                Session(
                    session_id=session_id,
                    project_dir=project_dir_name,
                    project_path=project_path,
                    file_path=str(jsonl_file),
                    first_message=first_message,
                    last_modified=stat.st_mtime,
                    size=stat.st_size,
                )
            )

    sessions.sort(key=lambda s: s.last_modified, reverse=True)
    return sessions
