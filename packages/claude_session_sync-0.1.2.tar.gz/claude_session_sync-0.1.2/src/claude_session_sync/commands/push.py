"""
`claude-session-sync push` コマンド実装
"""
from __future__ import annotations

import argparse
import sys


def run(args: argparse.Namespace) -> None:
    from claude_session_sync.config import Config
    from claude_session_sync.sync import push_sessions

    # 1. 設定読み込み
    if not Config.exists():
        print("設定が見つかりません。先に `claude-session-sync init` を実行してください。")
        sys.exit(1)

    config = Config.load()

    dry_run: bool = getattr(args, "dry_run", False)

    if dry_run:
        print("=== dry-run モード: 実際のプッシュは行いません ===")

    # 2. プッシュ実行
    try:
        pushed_ids = push_sessions(config, dry_run=dry_run)
    except Exception as e:
        print(f"プッシュ中にエラーが発生しました: {e}")
        sys.exit(1)

    # 3. 結果表示
    if dry_run:
        print(f"\n対象セッション数: {len(pushed_ids)}")
        if pushed_ids:
            print("プッシュ対象セッション ID 一覧:")
            for sid in pushed_ids:
                print(f"  - {sid}")
    else:
        if pushed_ids:
            print(f"\nプッシュ完了: {len(pushed_ids)} 件のセッションを同期しました。")
            if getattr(args, "verbose", False):
                for sid in pushed_ids:
                    print(f"  - {sid}")
        else:
            print("プッシュするセッションがありませんでした。")
