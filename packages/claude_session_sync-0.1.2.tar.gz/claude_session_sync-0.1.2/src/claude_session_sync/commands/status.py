"""
`claude-session-sync status` コマンド実装
"""
from __future__ import annotations

import argparse
import os
import sys


def run(args: argparse.Namespace) -> None:
    from claude_session_sync.config import Config
    from claude_session_sync.session import discover_sessions
    from claude_session_sync.git_ops import git_status

    # 1. 設定読み込み
    if not Config.exists():
        print("設定が見つかりません。先に `claude-session-sync init` を実行してください。")
        sys.exit(1)

    config = Config.load()

    print("=== claude-session-sync ステータス ===")
    print(f"マシンID        : {config.machine_id}")
    print(f"GitHubリポジトリ: {config.github_owner}/{config.github_repo}")
    print(f"同期ディレクトリ: {config.sync_repo_dir}")
    print("")

    # 2. ローカルセッション数を表示
    try:
        sessions = discover_sessions(config.claude_projects_dir)
        print(f"ローカルセッション数: {len(sessions)} 件")
    except Exception as e:
        print(f"ローカルセッション取得エラー: {e}")

    print("")

    # 3. last_push_at / last_pull_at を表示
    last_push = config.last_push_at or "（未実行）"
    last_pull = config.last_pull_at or "（未実行）"
    print(f"最終プッシュ日時: {last_push}")
    print(f"最終プル日時    : {last_pull}")
    print("")

    # 4. sync_repo_dir の git status を表示
    if os.path.isdir(os.path.join(config.sync_repo_dir, ".git")):
        print("=== 同期リポジトリの git status ===")
        try:
            status_output = git_status(config.sync_repo_dir)
            if status_output.strip():
                print(status_output)
            else:
                print("変更なし（クリーンな状態）")
        except Exception as e:
            print(f"git status 取得エラー: {e}")
    else:
        print("同期リポジトリが初期化されていません。`push` または `pull` を実行してください。")
