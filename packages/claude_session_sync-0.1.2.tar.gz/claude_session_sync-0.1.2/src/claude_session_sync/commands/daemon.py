"""
`claude-session-sync daemon` コマンド実装

指定間隔（デフォルト5分）で push / pull を繰り返す。
PIDファイルで二重起動防止。
"""
from __future__ import annotations

import argparse
import os
import signal
import sys
import time
from datetime import datetime
from pathlib import Path


PID_DIR = Path.home() / ".claude-session-sync"
PID_FILE = PID_DIR / "daemon.pid"
STOP_FILE = PID_DIR / "daemon.stop"

# quiet モードフラグ（グローバル）
_quiet = False


def _log(message: str) -> None:
    """タイムスタンプ付きでログを出力する。quiet モード時はエラーのみ出力。"""
    if _quiet:
        return
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{ts}] {message}", flush=True)


def _log_error(message: str) -> None:
    """エラーログを出力する（quiet モードでも出力）。"""
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{ts}] ERROR: {message}", file=sys.stderr, flush=True)


def _write_pid() -> None:
    """現在のプロセス PID をファイルに書き込む。"""
    PID_DIR.mkdir(parents=True, exist_ok=True)
    PID_FILE.write_text(str(os.getpid()), encoding="utf-8")


def _remove_pid() -> None:
    """PID ファイルを削除する。"""
    try:
        PID_FILE.unlink(missing_ok=True)
    except OSError:
        pass


def _is_running() -> tuple[bool, int]:
    """
    既存の daemon が稼働中かどうかを確認する。
    戻り値: (稼働中かどうか, PID)
    """
    if not PID_FILE.exists():
        return False, 0

    try:
        pid = int(PID_FILE.read_text(encoding="utf-8").strip())
    except (ValueError, OSError):
        return False, 0

    # プロセスが存在するか確認
    try:
        if sys.platform == "win32":
            import ctypes
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
            if handle:
                kernel32.CloseHandle(handle)
                return True, pid
            return False, pid
        else:
            os.kill(pid, 0)  # シグナル 0 = 存在確認のみ
            return True, pid
    except ProcessLookupError:
        return False, pid
    except PermissionError:
        return True, pid  # プロセスは存在するが権限なし


def _stop_daemon() -> None:
    """daemon を停止する。Windows では stop ファイルを作成、Unix では SIGTERM を送信する。"""
    running, pid = _is_running()
    if not running:
        if pid == 0:
            print("daemon は起動していません（PID ファイルなし）。")
        else:
            print(f"daemon は起動していません（PID {pid} は存在しない）。")
        return

    if sys.platform == "win32":
        PID_DIR.mkdir(parents=True, exist_ok=True)
        STOP_FILE.write_text("stop", encoding="utf-8")
        print(f"daemon (PID: {pid}) に停止ファイルを作成しました。")
    else:
        try:
            os.kill(pid, signal.SIGTERM)
            print(f"daemon (PID: {pid}) に SIGTERM を送信しました。")
        except (ProcessLookupError, PermissionError) as e:
            print(f"SIGTERM 送信に失敗しました (PID: {pid}): {e}")


def _acquire_session_locks(config, machine_id: str) -> list[str]:
    """
    アクティブな Claude Code セッションを検出してロックを取得する。

    Returns
    -------
    list[str]
        ロックを取得したセッション ID のリスト。
    """
    from claude_session_sync.session_lock import get_active_session_ids, acquire_lock

    session_ids = get_active_session_ids()
    acquired: list[str] = []

    for sid in session_ids:
        ok = acquire_lock(config.sync_repo_dir, sid, machine_id)
        if ok:
            acquired.append(sid)

    return acquired


def _release_all_session_locks(config, machine_id: str) -> list[str]:
    """
    このマシンの全セッションロックを解放する。

    Returns
    -------
    list[str]
        解放したセッション ID のリスト。
    """
    from claude_session_sync.session_lock import release_all_locks
    return release_all_locks(config.sync_repo_dir, machine_id)


def _commit_lock_changes(config, message: str) -> None:
    """ロック変更を git add/commit/push する（失敗しても続行）。"""
    from claude_session_sync.git_ops import git_add, git_commit, git_push

    try:
        git_add(config.sync_repo_dir, ["locks"])
        git_commit(config.sync_repo_dir, message)
        git_push(config.sync_repo_dir)
    except Exception as e:
        _log(f"ロック変更のコミット失敗（スキップ）: {e}")


def _do_sync_cycle(config, push_only: bool = False) -> None:
    """
    1回の同期サイクルを実行する。
    1. pull（他マシンの変更を取得）※ push_only=True の場合はスキップ
    2. push（自分の変更を送信）
    3. アクティブセッションのロックを renew（heartbeat）
    4. 期限切れロックを cleanup
    5. ロック変更があれば git add/commit/push
    エラーが発生しても例外を上位に投げずに記録する。
    """
    from claude_session_sync.sync import push_sessions, pull_sessions
    from claude_session_sync.session_lock import (
        renew_locks,
        cleanup_expired_locks,
    )
    from claude_session_sync.git_ops import git_add, git_commit, git_push

    # 1. pull（push_only モードではスキップ）
    if not push_only:
        try:
            _log("pull 開始...")
            pulled = pull_sessions(config, dry_run=False, force=False)
            _log(f"pull 完了: {len(pulled)} 件")
        except Exception as e:
            _log_error(f"pull エラー (スキップ): {e}")

    # 2. push
    try:
        _log("push 開始...")
        pushed = push_sessions(config, dry_run=False)
        _log(f"push 完了: {len(pushed)} 件")
    except Exception as e:
        _log_error(f"push エラー (スキップ): {e}")

    # 3. アクティブセッションのロック renew（heartbeat）
    lock_changed = False
    try:
        renewed = renew_locks(config.sync_repo_dir, config.machine_id)
        if renewed > 0:
            _log(f"ロック更新: {renewed} 件")
            lock_changed = True
    except Exception as e:
        _log_error(f"ロック更新エラー (スキップ): {e}")

    # 4. 期限切れロック cleanup
    try:
        cleaned = cleanup_expired_locks(config.sync_repo_dir)
        if cleaned:
            _log(f"期限切れロック削除: {len(cleaned)} 件")
            lock_changed = True
    except Exception as e:
        _log_error(f"ロック cleanup エラー (スキップ): {e}")

    # 5. ロック変更があれば commit/push
    if lock_changed:
        try:
            ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
            _commit_lock_changes(
                config,
                f"lock: heartbeat from {config.machine_id} [{ts}]"
            )
        except Exception as e:
            _log_error(f"ロック変更コミットエラー (スキップ): {e}")


def run(args: argparse.Namespace) -> None:
    global _quiet

    from claude_session_sync.config import Config

    # 設定確認
    if not Config.exists():
        print("設定が見つかりません。先に `claude-session-sync init` を実行してください。")
        sys.exit(1)

    config = Config.load()

    interval: int = getattr(args, "interval", 300)
    once: bool = getattr(args, "once", False)
    quiet: bool = getattr(args, "quiet", False)
    stop: bool = getattr(args, "stop", False)
    push_only: bool = getattr(args, "push_only", False)

    _quiet = quiet

    # --stop: 既存 daemon に SIGTERM を送信
    if stop:
        _stop_daemon()
        return

    if once:
        # --once: 1回だけ実行して終了
        _log("1回実行モード")
        _do_sync_cycle(config, push_only=push_only)
        _log("完了")
        return

    # 二重起動チェック
    running, existing_pid = _is_running()
    if running:
        print(f"daemon は既に起動中です (PID: {existing_pid})")
        print(f"PID ファイル: {PID_FILE}")
        sys.exit(1)

    # PID ファイルを書き込み
    _write_pid()

    # daemon 起動時: アクティブセッションのロックを取得
    try:
        acquired = _acquire_session_locks(config, config.machine_id)
        if acquired:
            _log(f"セッションロック取得: {len(acquired)} 件")
            ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
            _commit_lock_changes(
                config,
                f"lock: acquire {len(acquired)} sessions on {config.machine_id} [{ts}]"
            )
    except Exception as e:
        _log_error(f"起動時ロック取得エラー (スキップ): {e}")

    # Ctrl+C / SIGTERM でクリーンに終了
    def _shutdown(signum, frame):  # noqa: ANN001
        _log("シャットダウンシグナルを受信しました。終了します...")
        # このマシンの全ロックを解放
        try:
            released = _release_all_session_locks(config, config.machine_id)
            if released:
                _log(f"セッションロック解放: {len(released)} 件")
                ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
                _commit_lock_changes(
                    config,
                    f"lock: release all on {config.machine_id} [{ts}]"
                )
        except Exception as e:
            _log_error(f"終了時ロック解放エラー (スキップ): {e}")
        _remove_pid()
        sys.exit(0)

    signal.signal(signal.SIGINT, _shutdown)
    if sys.platform != "win32":
        signal.signal(signal.SIGTERM, _shutdown)

    mode_label = "push-only モード" if push_only else "通常モード"
    _log(f"daemon 起動 (PID: {os.getpid()}, 間隔: {interval}秒, {mode_label})")
    _log(f"PID ファイル: {PID_FILE}")
    _log("Ctrl+C で終了できます")

    try:
        while True:
            # Windows 用: stop ファイルが存在したら停止
            if STOP_FILE.exists():
                STOP_FILE.unlink(missing_ok=True)
                _log("停止ファイルを検出しました。終了します...")
                _shutdown(None, None)

            _log("同期サイクル開始")
            _do_sync_cycle(config, push_only=push_only)
            _log(f"次のサイクルまで {interval} 秒待機...")
            time.sleep(interval)

            # sleep 後にも stop ファイルをチェック
            if STOP_FILE.exists():
                STOP_FILE.unlink(missing_ok=True)
                _log("停止ファイルを検出しました。終了します...")
                _shutdown(None, None)
    except KeyboardInterrupt:
        _log("KeyboardInterrupt を受信しました。終了します...")
        # ロック解放
        try:
            released = _release_all_session_locks(config, config.machine_id)
            if released:
                _log(f"セッションロック解放: {len(released)} 件")
                ts = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
                _commit_lock_changes(
                    config,
                    f"lock: release all on {config.machine_id} [{ts}]"
                )
        except Exception as e:
            _log_error(f"終了時ロック解放エラー (スキップ): {e}")
    finally:
        _remove_pid()
        _log("daemon 終了")
