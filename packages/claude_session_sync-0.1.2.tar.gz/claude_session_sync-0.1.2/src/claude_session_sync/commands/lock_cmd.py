"""
`claude-session-sync lock` サブコマンド実装

サブコマンド:
  show      - 現在の全ロック一覧表示
  release   - ロック解放（SESSION_ID 省略時は自マシンの全ロック）
  cleanup   - 期限切れロック一括削除
"""
from __future__ import annotations

import argparse
import sys


def run(args: argparse.Namespace) -> None:
    from claude_session_sync.config import Config

    if not Config.exists():
        print("設定が見つかりません。先に `claude-session-sync init` を実行してください。")
        sys.exit(1)

    config = Config.load()
    subcommand = getattr(args, "lock_subcommand", None)

    if subcommand == "show" or subcommand is None:
        _run_show(config)
    elif subcommand == "release":
        _run_release(config, args)
    elif subcommand == "cleanup":
        _run_cleanup(config)
    else:
        print(f"不明なサブコマンド: {subcommand}")
        sys.exit(1)


def _run_show(config) -> None:
    """現在の全ロック一覧を表示する。"""
    from pathlib import Path
    from claude_session_sync.session_lock import _locks_dir, _read_lock, _is_expired, _now_utc

    locks_dir = _locks_dir(config.sync_repo_dir)

    if not locks_dir.exists():
        print("ロックはありません。")
        return

    lock_files = list(locks_dir.glob("*.lock.json"))
    if not lock_files:
        print("ロックはありません。")
        return

    print(f"{'セッション ID':<40} {'マシン ID':<20} {'状態':<8} {'期限'}")
    print("-" * 90)

    for lock_path in sorted(lock_files):
        data = _read_lock(lock_path)
        if data is None:
            print(f"{lock_path.stem:<40} (読み込みエラー)")
            continue

        session_id = data.get("session_id", lock_path.stem)
        machine_id = data.get("machine_id", "unknown")
        expires_at = data.get("expires_at", "")
        status = "期限切れ" if _is_expired(data) else "有効"
        own = " (自)" if machine_id == config.machine_id else ""

        print(f"{session_id:<40} {machine_id + own:<20} {status:<8} {expires_at}")


def _run_release(config, args: argparse.Namespace) -> None:
    """ロックを解放する。SESSION_ID 省略時は自マシンの全ロック。"""
    from claude_session_sync.session_lock import release_lock, release_all_locks
    from claude_session_sync.git_ops import git_add, git_commit, git_push
    from pathlib import Path
    import os

    session_id = getattr(args, "session_id", None)

    if session_id:
        ok = release_lock(config.sync_repo_dir, session_id, config.machine_id)
        if ok:
            print(f"ロックを解放しました: {session_id}")
            _commit_lock_changes(config, f"lock: release {session_id} from {config.machine_id}")
        else:
            print(f"ロックの解放に失敗しました: {session_id} （他マシンのロックの可能性があります）")
            sys.exit(1)
    else:
        released = release_all_locks(config.sync_repo_dir, config.machine_id)
        if released:
            print(f"{len(released)} 件のロックを解放しました:")
            for sid in released:
                print(f"  {sid}")
            _commit_lock_changes(config, f"lock: release all locks from {config.machine_id}")
        else:
            print("解放するロックはありませんでした。")


def _run_cleanup(config) -> None:
    """期限切れロックを一括削除する。"""
    from claude_session_sync.session_lock import cleanup_expired_locks

    cleaned = cleanup_expired_locks(config.sync_repo_dir)
    if cleaned:
        print(f"{len(cleaned)} 件の期限切れロックを削除しました:")
        for sid in cleaned:
            print(f"  {sid}")
        _commit_lock_changes(config, f"lock: cleanup expired locks from {config.machine_id}")
    else:
        print("削除する期限切れロックはありませんでした。")


def _commit_lock_changes(config, message: str) -> None:
    """ロック変更を git add/commit/push する（失敗しても終了しない）。"""
    import os
    from claude_session_sync.git_ops import git_add, git_commit, git_push

    locks_rel = "locks"
    try:
        git_add(config.sync_repo_dir, [locks_rel])
        git_commit(config.sync_repo_dir, message)
        git_push(config.sync_repo_dir)
    except Exception as e:
        # ロック変更のコミット失敗は致命的ではない（変更がない場合も含む）
        pass
