"""
`claude-session-sync update` コマンド実装

Claude Code を終了した後に push 忘れやロック残りを一括で処理する。

フロー:
1. Config.load()
2. push_sessions(config) を実行
3. release_all_locks(sync_repo_dir, machine_id) を実行
4. ロック変更があれば git add/commit/push
5. 結果を表示
"""
from __future__ import annotations

import argparse
import sys


def run(args: argparse.Namespace) -> None:
    from claude_session_sync.config import Config
    from claude_session_sync.sync import push_sessions
    from claude_session_sync.session_lock import release_all_locks

    # 設定確認
    if not Config.exists():
        print("設定が見つかりません。先に `claude-session-sync init` を実行してください。")
        sys.exit(1)

    config = Config.load()

    # Step 2: push_sessions を実行
    try:
        pushed_ids = push_sessions(config, dry_run=False)
    except Exception as e:
        print(f"警告: push に失敗しました: {e}", file=sys.stderr)
        pushed_ids = []

    push_count = len(pushed_ids)

    # Step 3: release_all_locks を実行
    try:
        released_ids = release_all_locks(config.sync_repo_dir, config.machine_id)
    except Exception as e:
        print(f"警告: ロック解放に失敗しました: {e}", file=sys.stderr)
        released_ids = []

    lock_count = len(released_ids)

    # Step 4: ロック変更があれば git add/commit/push
    if lock_count > 0:
        try:
            import os
            import time
            from claude_session_sync.git_ops import git_add, git_commit, git_push

            locks_dir = os.path.join(config.sync_repo_dir, "locks")
            # locks/ ディレクトリ全体を git add（削除されたファイルも含む）
            try:
                import subprocess
                subprocess.run(
                    ["git", "add", "locks/"],
                    cwd=config.sync_repo_dir,
                    check=True,
                    capture_output=True,
                )
            except Exception:
                git_add(config.sync_repo_dir, ["locks/"])

            commit_msg = (
                f"sync: release {lock_count} lock(s) from {config.machine_id} "
                f"[{time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}]"
            )
            git_commit(config.sync_repo_dir, commit_msg)
            git_push(config.sync_repo_dir)
        except Exception as e:
            print(f"警告: ロック解放の git push に失敗しました: {e}", file=sys.stderr)

    # Step 5: 結果を表示
    if push_count == 0 and lock_count == 0:
        print("✓ 変更はありませんでした")
    else:
        if push_count > 0:
            print(f"✓ {push_count}件のセッションをプッシュしました")
        if lock_count > 0:
            print(f"✓ ロックを解放しました（{lock_count}件）")
