"""
`claude-session-sync list` コマンド実装
"""
from __future__ import annotations

import argparse
import datetime
import json
import os
import sys


def _format_timestamp(ts: float) -> str:
    """Unix タイムスタンプを人間が読みやすい形式に変換する。"""
    try:
        dt = datetime.datetime.fromtimestamp(ts)
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return "不明"


def _truncate(text: str, width: int) -> str:
    """テキストを指定幅に切り詰める。"""
    if len(text) <= width:
        return text
    return text[: width - 3] + "..."


def run(args: argparse.Namespace) -> None:
    from claude_session_sync.config import Config
    from claude_session_sync.session import discover_sessions

    # 1. 設定読み込み
    if not Config.exists():
        print("設定が見つかりません。先に `claude-session-sync init` を実行してください。")
        sys.exit(1)

    config = Config.load()

    output_format: str = getattr(args, "format", "table")
    show_remote: bool = getattr(args, "remote", False)

    # 2. セッション一覧取得
    if show_remote:
        sessions_data = _list_remote_sessions(config)
    else:
        try:
            sessions = discover_sessions(config.claude_projects_dir)
        except Exception as e:
            print(f"セッション一覧取得エラー: {e}")
            sys.exit(1)
        sessions_data = [
            {
                "session_id": s.session_id,
                "last_modified": s.last_modified,
                "project_path": s.project_path,
                "first_message": s.first_message,
                "size": s.size,
                "machine": config.machine_id,
            }
            for s in sessions
        ]

    if not sessions_data:
        src = "リモート" if show_remote else "ローカル"
        print(f"{src}にセッションが見つかりませんでした。")
        return

    # 3. 出力
    if output_format == "json":
        print(json.dumps(sessions_data, ensure_ascii=False, indent=2))
    else:
        _print_table(sessions_data, show_remote=show_remote)


def _list_remote_sessions(config) -> list[dict]:
    """同期リポジトリから全マシンのセッション情報を収集する。"""
    sessions_root = os.path.join(config.sync_repo_dir, "sessions")
    if not os.path.isdir(sessions_root):
        return []

    result: list[dict] = []
    for machine_id in os.listdir(sessions_root):
        machine_dir = os.path.join(sessions_root, machine_id)
        if not os.path.isdir(machine_dir):
            continue
        for project_dir in os.listdir(machine_dir):
            project_path = os.path.join(machine_dir, project_dir)
            if not os.path.isdir(project_path):
                continue
            for fname in os.listdir(project_path):
                if not fname.endswith(".jsonl"):
                    continue
                fpath = os.path.join(project_path, fname)
                stat = os.stat(fpath)
                session_id = fname.replace(".jsonl", "")
                first_message = _extract_first_message(fpath)
                result.append(
                    {
                        "session_id": session_id,
                        "last_modified": stat.st_mtime,
                        "project_path": project_dir,
                        "first_message": first_message,
                        "size": stat.st_size,
                        "machine": machine_id,
                    }
                )
    # 最終更新日時の降順にソート
    result.sort(key=lambda x: x["last_modified"], reverse=True)
    return result


def _extract_first_message(jsonl_path: str) -> str:
    """JSONL ファイルから最初のユーザーメッセージを抽出する。"""
    try:
        with open(jsonl_path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    record = json.loads(line)
                except json.JSONDecodeError:
                    continue
                msg = record.get("message", {})
                if isinstance(msg, dict):
                    content = msg.get("content", "")
                    if isinstance(content, str) and content:
                        return content[:80]
                    if isinstance(content, list):
                        for part in content:
                            if isinstance(part, dict) and part.get("type") == "text":
                                text = part.get("text", "")
                                if text:
                                    return text[:80]
    except Exception:
        pass
    return ""


def _print_table(sessions_data: list[dict], show_remote: bool = False) -> None:
    """テーブル形式でセッション一覧を表示する。"""
    # ヘッダー
    col_id = 36
    col_date = 19
    col_machine = 15
    col_project = 30
    col_message = 40

    header_parts = [
        f"{'セッションID':<{col_id}}",
        f"{'最終更新':<{col_date}}",
    ]
    if show_remote:
        header_parts.append(f"{'マシン':<{col_machine}}")
    header_parts += [
        f"{'プロジェクト':<{col_project}}",
        f"{'最初のメッセージ':<{col_message}}",
    ]
    header = "  ".join(header_parts)
    separator = "-" * len(header)

    src_label = "リモート" if show_remote else "ローカル"
    print(f"\n=== {src_label}セッション一覧 ({len(sessions_data)} 件) ===")
    print(separator)
    print(header)
    print(separator)

    for s in sessions_data:
        row_parts = [
            f"{_truncate(s['session_id'], col_id):<{col_id}}",
            f"{_format_timestamp(s['last_modified']):<{col_date}}",
        ]
        if show_remote:
            row_parts.append(f"{_truncate(s['machine'], col_machine):<{col_machine}}")
        row_parts += [
            f"{_truncate(s['project_path'], col_project):<{col_project}}",
            f"{_truncate(s['first_message'], col_message):<{col_message}}",
        ]
        print("  ".join(row_parts))

    print(separator)
