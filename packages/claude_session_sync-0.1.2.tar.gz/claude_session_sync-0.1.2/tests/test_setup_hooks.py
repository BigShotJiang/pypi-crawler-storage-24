"""
tests/test_setup_hooks.py

setup-hooks コマンドのテスト

設計変更: setup-hooks コマンドは hooks の設定を行わなくなった。
代わりに resume コマンドの使用を推奨するメッセージを表示するのみ。
"""
from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

import pytest


def _import_setup_hooks():
    from claude_session_sync.commands import setup_hooks
    return setup_hooks


def _run_setup_hooks(tmp_path: Path):
    setup_hooks = _import_setup_hooks()
    settings_file = tmp_path / "settings.json"

    import argparse
    args = argparse.Namespace()

    with (
        patch.object(setup_hooks, "SETTINGS_PATH", settings_file),
    ):
        setup_hooks.run(args)

    return settings_file


class TestSetupHooksRecommendation:
    def test_shows_resume_recommendation(self, tmp_path, capsys):
        """setup-hooks 実行時に resume コマンドの推奨メッセージが表示される。"""
        setup_hooks = _import_setup_hooks()
        settings_file = tmp_path / "settings.json"

        import argparse
        args = argparse.Namespace()

        with patch.object(setup_hooks, "SETTINGS_PATH", settings_file):
            setup_hooks.run(args)

        captured = capsys.readouterr()
        assert "resume" in captured.out, "resume コマンドの推奨が表示されていない"

    def test_shows_non_recommended_message(self, tmp_path, capsys):
        """setup-hooks 実行時に非推奨または推奨変更のメッセージが表示される。"""
        setup_hooks = _import_setup_hooks()
        settings_file = tmp_path / "settings.json"

        import argparse
        args = argparse.Namespace()

        with patch.object(setup_hooks, "SETTINGS_PATH", settings_file):
            setup_hooks.run(args)

        captured = capsys.readouterr()
        # 「非推奨」か「推奨」に関するメッセージ
        assert len(captured.out) > 0, "何もメッセージが表示されていない"

    def test_does_not_write_settings_file(self, tmp_path):
        """setup-hooks が settings.json を書き込まない（新しい動作）。"""
        setup_hooks = _import_setup_hooks()
        settings_file = tmp_path / "settings.json"

        import argparse
        args = argparse.Namespace()

        with patch.object(setup_hooks, "SETTINGS_PATH", settings_file):
            setup_hooks.run(args)

        # settings.json が作成されていない（ファイルなし）
        assert not settings_file.exists(), \
            "setup-hooks が settings.json を書き込んでしまった（resume 推奨モードでは不要）"

    def test_detect_command_returns_which_path(self):
        """_detect_command が which で見つかったパスを返す。"""
        setup_hooks = _import_setup_hooks()
        with patch("shutil.which", return_value="/usr/local/bin/claude-session-sync"):
            assert setup_hooks._detect_command() == "/usr/local/bin/claude-session-sync"

    def test_detect_command_returns_fallback(self):
        """_detect_command が which で見つからない場合フォールバックを返す。"""
        setup_hooks = _import_setup_hooks()
        with patch("shutil.which", return_value=None):
            assert setup_hooks._detect_command() == "python3 -m claude_session_sync"
