"""
tests/test_daemon.py

daemon コマンドのテスト:
1. daemon の1回実行（--once）が正常に動作するか
2. PIDファイルの二重起動防止
3. git_pull_safe の競合解決ロジック
"""
from __future__ import annotations

import argparse
import json
import os
import signal
import subprocess
import sys
from pathlib import Path
from unittest.mock import MagicMock, call, patch

import pytest


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _import_daemon():
    from claude_session_sync.commands import daemon
    return daemon


def _import_git_ops():
    from claude_session_sync import git_ops
    return git_ops


def _make_args(once: bool = False, interval: int = 300) -> argparse.Namespace:
    return argparse.Namespace(once=once, interval=interval)


def _make_mock_config(tmp_path: Path):
    from claude_session_sync.config import Config
    cfg = Config()
    cfg.machine_id = "test-machine"
    cfg.claude_projects_dir = str(tmp_path / "claude_projects")
    cfg.claude_history_file = str(tmp_path / ".claude" / "history.jsonl")
    cfg.sync_repo_dir = str(tmp_path / "sync_repo")
    cfg.placeholders = {}
    return cfg


# ---------------------------------------------------------------------------
# テスト 1: --once の1回実行
# ---------------------------------------------------------------------------

class TestOnce:
    def test_once_calls_pull_and_push(self, tmp_path):
        """--once 実行時に pull と push がそれぞれ1回ずつ呼ばれる。"""
        daemon = _import_daemon()
        cfg = _make_mock_config(tmp_path)

        pull_called = []
        push_called = []

        def mock_pull(config, dry_run=False, force=False):
            pull_called.append(True)
            return []

        def mock_push(config, dry_run=False):
            push_called.append(True)
            return []

        args = _make_args(once=True)

        with (
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
            patch("claude_session_sync.sync.pull_sessions", mock_pull),
            patch("claude_session_sync.sync.push_sessions", mock_push),
        ):
            daemon.run(args)

        assert len(pull_called) == 1, "pull が1回呼ばれていない"
        assert len(push_called) == 1, "push が1回呼ばれていない"

    def test_once_exits_after_one_cycle(self, tmp_path):
        """--once 実行時にループしない（SystemExit が発生しない）。"""
        daemon = _import_daemon()
        cfg = _make_mock_config(tmp_path)

        args = _make_args(once=True)

        with (
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
            patch("claude_session_sync.sync.pull_sessions", return_value=[]),
            patch("claude_session_sync.sync.push_sessions", return_value=[]),
        ):
            # 例外なく正常終了することを確認
            daemon.run(args)

    def test_once_does_not_write_pid_file(self, tmp_path):
        """--once 実行時は PID ファイルを作成しない。"""
        daemon = _import_daemon()
        cfg = _make_mock_config(tmp_path)
        pid_file = tmp_path / "daemon.pid"

        args = _make_args(once=True)

        with (
            patch.object(daemon, "PID_FILE", pid_file),
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
            patch("claude_session_sync.sync.pull_sessions", return_value=[]),
            patch("claude_session_sync.sync.push_sessions", return_value=[]),
        ):
            daemon.run(args)

        assert not pid_file.exists(), "--once 実行時に PID ファイルが作成された"

    def test_once_continues_on_pull_error(self, tmp_path):
        """pull でエラーが発生しても push は実行される。"""
        daemon = _import_daemon()
        cfg = _make_mock_config(tmp_path)

        push_called = []

        def mock_pull_fail(config, dry_run=False, force=False):
            raise RuntimeError("pull 失敗テスト")

        def mock_push(config, dry_run=False):
            push_called.append(True)
            return []

        args = _make_args(once=True)

        with (
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
            patch("claude_session_sync.sync.pull_sessions", mock_pull_fail),
            patch("claude_session_sync.sync.push_sessions", mock_push),
        ):
            daemon.run(args)

        assert len(push_called) == 1, "pull エラー後に push が実行されていない"

    def test_once_continues_on_push_error(self, tmp_path):
        """push でエラーが発生しても例外が伝播しない（クラッシュしない）。"""
        daemon = _import_daemon()
        cfg = _make_mock_config(tmp_path)

        def mock_push_fail(config, dry_run=False):
            raise RuntimeError("push 失敗テスト")

        args = _make_args(once=True)

        with (
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
            patch("claude_session_sync.sync.pull_sessions", return_value=[]),
            patch("claude_session_sync.sync.push_sessions", mock_push_fail),
        ):
            # 例外なく終了することを確認
            daemon.run(args)

    def test_once_exits_with_error_if_no_config(self, tmp_path, capsys):
        """設定が存在しない場合は sys.exit(1) する。"""
        daemon = _import_daemon()
        args = _make_args(once=True)

        with (
            patch("claude_session_sync.config.Config.exists", return_value=False),
        ):
            with pytest.raises(SystemExit) as exc:
                daemon.run(args)
        assert exc.value.code == 1


# ---------------------------------------------------------------------------
# テスト 2: PID ファイルによる二重起動防止
# ---------------------------------------------------------------------------

class TestPidFile:
    def test_pid_file_written_and_removed(self, tmp_path):
        """通常起動時に PID ファイルが書かれ、終了後に削除される。"""
        daemon = _import_daemon()
        cfg = _make_mock_config(tmp_path)
        pid_file = tmp_path / "daemon.pid"
        pid_dir = tmp_path

        # 1回だけ sleep を呼んだ後に KeyboardInterrupt を発生させる
        call_count = [0]

        def mock_sleep(seconds):
            call_count[0] += 1
            raise KeyboardInterrupt()

        args = _make_args(once=False, interval=1)

        with (
            patch.object(daemon, "PID_FILE", pid_file),
            patch.object(daemon, "PID_DIR", pid_dir),
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
            patch("claude_session_sync.sync.pull_sessions", return_value=[]),
            patch("claude_session_sync.sync.push_sessions", return_value=[]),
            patch("time.sleep", mock_sleep),
        ):
            daemon.run(args)

        assert not pid_file.exists(), "終了後も PID ファイルが残っている"

    def test_double_start_prevented(self, tmp_path, capsys):
        """既に PID ファイルが存在し、プロセスが稼働中の場合は起動しない。"""
        daemon = _import_daemon()
        cfg = _make_mock_config(tmp_path)
        pid_file = tmp_path / "daemon.pid"

        # 存在するプロセス PID（自プロセスの PID を使う）
        my_pid = os.getpid()
        pid_file.write_text(str(my_pid), encoding="utf-8")

        args = _make_args(once=False, interval=1)

        with (
            patch.object(daemon, "PID_FILE", pid_file),
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
        ):
            with pytest.raises(SystemExit) as exc:
                daemon.run(args)

        assert exc.value.code == 1
        captured = capsys.readouterr()
        assert "既に起動中" in captured.out

    def test_stale_pid_file_does_not_block(self, tmp_path):
        """
        存在しないプロセスの PID ファイルが残っていても起動できる。
        """
        daemon = _import_daemon()
        cfg = _make_mock_config(tmp_path)
        pid_file = tmp_path / "daemon.pid"
        pid_dir = tmp_path

        # 存在しないであろう PID
        pid_file.write_text("999999999", encoding="utf-8")

        def mock_sleep(seconds):
            raise KeyboardInterrupt()

        args = _make_args(once=False, interval=1)

        with (
            patch.object(daemon, "PID_FILE", pid_file),
            patch.object(daemon, "PID_DIR", pid_dir),
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
            patch("claude_session_sync.sync.pull_sessions", return_value=[]),
            patch("claude_session_sync.sync.push_sessions", return_value=[]),
            patch("time.sleep", mock_sleep),
        ):
            # 例外なく起動できることを確認（stale PID でブロックされない）
            daemon.run(args)


# ---------------------------------------------------------------------------
# テスト 3: git_pull_safe の競合解決ロジック
# ---------------------------------------------------------------------------

class TestGitPullSafe:
    def _make_error(self, returncode: int = 1) -> subprocess.CalledProcessError:
        return subprocess.CalledProcessError(returncode, ["git"])

    def test_returns_true_on_normal_pull(self):
        """通常の git pull が成功すれば True を返す。"""
        git_ops = _import_git_ops()
        with patch("claude_session_sync.git_ops._run") as mock_run:
            mock_run.return_value = MagicMock()
            result = git_ops.git_pull_safe("/fake/repo")
        assert result is True

    def test_fallback_to_rebase_on_pull_failure(self):
        """通常 pull 失敗 → rebase が成功すれば True。"""
        git_ops = _import_git_ops()
        call_commands = []

        def mock_run(args, cwd=None):
            call_commands.append(args)
            if args == ["git", "pull"]:
                raise subprocess.CalledProcessError(1, args)
            # rebase は成功
            return MagicMock()

        with patch("claude_session_sync.git_ops._run", mock_run):
            result = git_ops.git_pull_safe("/fake/repo")

        assert result is True
        assert ["git", "pull", "--rebase"] in call_commands

    def test_fallback_to_stash_on_rebase_failure(self):
        """通常 pull・rebase 両方失敗 → stash + pull が成功すれば True。"""
        git_ops = _import_git_ops()
        call_commands = []

        def mock_run(args, cwd=None):
            call_commands.append(args)
            if args in (["git", "pull"], ["git", "pull", "--rebase"]):
                raise subprocess.CalledProcessError(1, args)
            return MagicMock()

        with patch("claude_session_sync.git_ops._run", mock_run):
            result = git_ops.git_pull_safe("/fake/repo")

        assert result is True
        assert ["git", "stash"] in call_commands

    def test_fallback_to_reset_hard_as_last_resort(self, capsys):
        """
        全ての手段が失敗 → reset --hard origin/main にフォールバックし、
        警告を表示して True を返す。
        """
        git_ops = _import_git_ops()
        call_commands = []

        def mock_run(args, cwd=None):
            call_commands.append(args)
            # stash と fetch / reset は成功させる
            if args in (
                ["git", "stash"],
                ["git", "fetch", "origin"],
                ["git", "reset", "--hard", "origin/main"],
                ["git", "stash", "pop"],
            ):
                return MagicMock()
            raise subprocess.CalledProcessError(1, args)

        with patch("claude_session_sync.git_ops._run", mock_run):
            result = git_ops.git_pull_safe("/fake/repo")

        assert result is True
        assert ["git", "reset", "--hard", "origin/main"] in call_commands
        captured = capsys.readouterr()
        assert "警告" in captured.out

    def test_returns_false_when_all_fail(self):
        """全ての手段（fetch / reset を含む）が失敗したら False を返す。"""
        git_ops = _import_git_ops()

        def mock_run(args, cwd=None):
            raise subprocess.CalledProcessError(1, args)

        with patch("claude_session_sync.git_ops._run", mock_run):
            result = git_ops.git_pull_safe("/fake/repo")

        assert result is False


# ---------------------------------------------------------------------------
# テスト 13: --stop でPIDファイル読み取りとプロセス停止
# ---------------------------------------------------------------------------

class TestStopDaemon:
    def test_stop_sends_sigterm_to_running_process(self, tmp_path, capsys):
        """--stop で稼働中の daemon が停止される。
        Unix: SIGTERM を送信する。
        Windows: stop ファイルを作成する（SIGTERM は未サポート）。
        """
        daemon = _import_daemon()
        cfg = _make_mock_config(tmp_path)

        pid_file = tmp_path / "daemon.pid"
        pid_dir = tmp_path
        stop_file = tmp_path / "daemon.stop"
        my_pid = os.getpid()
        pid_file.write_text(str(my_pid), encoding="utf-8")

        sigterm_sent = []

        def mock_kill(pid, sig):
            sigterm_sent.append((pid, sig))
            # SIGTERM を実際には送らない（自分自身を終了させないため）

        args = argparse.Namespace(
            once=False, interval=300, quiet=False, stop=True
        )

        with (
            patch.object(daemon, "PID_FILE", pid_file),
            patch.object(daemon, "PID_DIR", pid_dir),
            patch.object(daemon, "STOP_FILE", stop_file),
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
            patch("os.kill", mock_kill),
        ):
            daemon.run(args)

        captured = capsys.readouterr()

        if sys.platform == "win32":
            # Windows: stop ファイルが作成され、その旨がログに出力される
            assert stop_file.exists(), "Windows: stop ファイルが作成されていない"
            assert "停止ファイル" in captured.out or str(my_pid) in captured.out, \
                f"Windows: 停止メッセージが出力されていない: {captured.out!r}"
        else:
            # Unix: SIGTERM (15) が送信された
            assert any(sig == signal.SIGTERM for _, sig in sigterm_sent), \
                f"SIGTERM が送信されていない: {sigterm_sent}"
            assert "SIGTERM" in captured.out

    def test_stop_when_no_pid_file(self, tmp_path, capsys):
        """--stop で PID ファイルが存在しない場合はメッセージを表示して終了。"""
        daemon = _import_daemon()
        cfg = _make_mock_config(tmp_path)
        pid_file = tmp_path / "daemon.pid"

        args = argparse.Namespace(
            once=False, interval=300, quiet=False, stop=True
        )

        with (
            patch.object(daemon, "PID_FILE", pid_file),
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
        ):
            daemon.run(args)  # 例外なく終了すること

        captured = capsys.readouterr()
        assert "起動していません" in captured.out

    def test_stop_with_nonexistent_pid(self, tmp_path, capsys):
        """--stop で存在しないプロセスの PID ファイルがある場合。"""
        daemon = _import_daemon()
        cfg = _make_mock_config(tmp_path)
        pid_file = tmp_path / "daemon.pid"
        pid_file.write_text("999999999", encoding="utf-8")

        args = argparse.Namespace(
            once=False, interval=300, quiet=False, stop=True
        )

        with (
            patch.object(daemon, "PID_FILE", pid_file),
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
        ):
            daemon.run(args)

        captured = capsys.readouterr()
        assert "起動していません" in captured.out


# ---------------------------------------------------------------------------
# テスト 14: --quiet でログ抑制
# ---------------------------------------------------------------------------

class TestQuietMode:
    def test_quiet_suppresses_normal_logs(self, tmp_path, capsys):
        """--quiet モードで通常ログが出力されない。"""
        daemon = _import_daemon()
        cfg = _make_mock_config(tmp_path)

        args = argparse.Namespace(
            once=True, interval=300, quiet=True, stop=False
        )

        with (
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
            patch("claude_session_sync.sync.pull_sessions", return_value=[]),
            patch("claude_session_sync.sync.push_sessions", return_value=[]),
        ):
            daemon.run(args)

        captured = capsys.readouterr()
        # quiet モードでは通常ログ（タイムスタンプ付き）が出ない
        assert "[" not in captured.out, \
            f"quiet モードでログが出力された: {captured.out!r}"

    def test_non_quiet_shows_logs(self, tmp_path, capsys):
        """通常モード（--quiet なし）ではログが出力される。"""
        daemon = _import_daemon()
        cfg = _make_mock_config(tmp_path)

        args = argparse.Namespace(
            once=True, interval=300, quiet=False, stop=False
        )

        with (
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
            patch("claude_session_sync.sync.pull_sessions", return_value=[]),
            patch("claude_session_sync.sync.push_sessions", return_value=[]),
        ):
            daemon.run(args)

        captured = capsys.readouterr()
        # 通常モードではログが出力される
        assert len(captured.out) > 0


# ---------------------------------------------------------------------------
# push-only モード
# ---------------------------------------------------------------------------

class TestPushOnlyMode:
    def test_push_only_skips_pull(self, tmp_path):
        """--push-only で pull がスキップされる。"""
        daemon = _import_daemon()
        from claude_session_sync.config import Config

        cfg = Config(
            machine_id="test-pc",
            sync_repo_dir=str(tmp_path / "repo"),
        )
        os.makedirs(cfg.sync_repo_dir, exist_ok=True)

        pull_called = False
        push_called = False

        def mock_pull(*a, **kw):
            nonlocal pull_called
            pull_called = True
            return []

        def mock_push(*a, **kw):
            nonlocal push_called
            push_called = True
            return []

        with (
            patch("claude_session_sync.sync.pull_sessions", side_effect=mock_pull),
            patch("claude_session_sync.sync.push_sessions", side_effect=mock_push),
            patch("claude_session_sync.session_lock.renew_locks", return_value=0),
            patch("claude_session_sync.session_lock.cleanup_expired_locks", return_value=[]),
        ):
            daemon._do_sync_cycle(cfg, push_only=True)

        assert not pull_called, "push-only モードなのに pull が呼ばれた"
        assert push_called, "push が呼ばれていない"

    def test_normal_mode_calls_pull(self, tmp_path):
        """push_only=False で pull が呼ばれる。"""
        daemon = _import_daemon()
        from claude_session_sync.config import Config

        cfg = Config(
            machine_id="test-pc",
            sync_repo_dir=str(tmp_path / "repo"),
        )
        os.makedirs(cfg.sync_repo_dir, exist_ok=True)

        pull_called = False

        def mock_pull(*a, **kw):
            nonlocal pull_called
            pull_called = True
            return []

        with (
            patch("claude_session_sync.sync.pull_sessions", side_effect=mock_pull),
            patch("claude_session_sync.sync.push_sessions", return_value=[]),
            patch("claude_session_sync.session_lock.renew_locks", return_value=0),
            patch("claude_session_sync.session_lock.cleanup_expired_locks", return_value=[]),
        ):
            daemon._do_sync_cycle(cfg, push_only=False)

        assert pull_called, "通常モードなのに pull が呼ばれていない"


# ---------------------------------------------------------------------------
# テスト: Windows 互換性
# ---------------------------------------------------------------------------

class TestWindowsCompatibility:
    def test_stop_file_terminates_daemon_loop(self, tmp_path):
        """
        Windows の stop ファイル方式: ループ開始前に stop ファイルが存在する場合、
        daemon が _shutdown を呼んで終了する。
        """
        daemon = _import_daemon()
        cfg = _make_mock_config(tmp_path)

        pid_file = tmp_path / "daemon.pid"
        pid_dir = tmp_path
        stop_file = tmp_path / "daemon.stop"

        # stop ファイルをあらかじめ作成しておく
        stop_file.write_text("stop", encoding="utf-8")

        args = argparse.Namespace(
            once=False, interval=300, quiet=False, stop=False, push_only=False
        )

        with (
            patch.object(daemon, "PID_FILE", pid_file),
            patch.object(daemon, "PID_DIR", pid_dir),
            patch.object(daemon, "STOP_FILE", stop_file),
            patch("claude_session_sync.config.Config.exists", return_value=True),
            patch("claude_session_sync.config.Config.load", return_value=cfg),
            patch("claude_session_sync.sync.pull_sessions", return_value=[]),
            patch("claude_session_sync.sync.push_sessions", return_value=[]),
            patch("claude_session_sync.session_lock.get_active_session_ids", return_value=[]),
            patch("claude_session_sync.session_lock.acquire_lock", return_value=True),
            patch("claude_session_sync.session_lock.release_all_locks", return_value=[]),
            patch("claude_session_sync.git_ops.git_add"),
            patch("claude_session_sync.git_ops.git_commit"),
            patch("claude_session_sync.git_ops.git_push"),
        ):
            with pytest.raises(SystemExit) as exc:
                daemon.run(args)

        # _shutdown は sys.exit(0) を呼ぶ
        assert exc.value.code == 0
        # stop ファイルは削除されている
        assert not stop_file.exists(), "stop ファイルが削除されていない"
        # PID ファイルも削除されている
        assert not pid_file.exists(), "PID ファイルが残っている"

    def test_start_push_daemon_skips_if_existing_daemon_alive(self, tmp_path):
        """
        既存の resume_daemon.pid に生きているプロセスの PID が書かれている場合、
        _start_push_daemon は新規プロセスを起動せず既存 PID を返す。
        """
        import claude_session_sync.commands.resume as resume_mod
        from claude_session_sync.commands import daemon as daemon_mod

        cfg = _make_mock_config(tmp_path)

        # 存在するプロセスとして自プロセスの PID を使う
        my_pid = os.getpid()

        pid_file = tmp_path / "resume_daemon.pid"
        pid_file.write_text(str(my_pid), encoding="utf-8")

        popen_called = {"count": 0}

        def fake_popen(cmd, **kwargs):
            popen_called["count"] += 1
            return MagicMock(pid=99999)

        with (
            patch.object(resume_mod, "RESUME_DAEMON_PID_FILE", pid_file),
            patch.object(daemon_mod, "PID_DIR", tmp_path),
            patch("subprocess.Popen", fake_popen),
        ):
            returned_pid = resume_mod._start_push_daemon(cfg)

        # 既存 PID が返される
        assert returned_pid == my_pid, \
            f"既存 PID {my_pid} が返されるべきだが {returned_pid} が返された"
        # 新規プロセスは起動されていない
        assert popen_called["count"] == 0, \
            f"既存 daemon が生きているのに Popen が {popen_called['count']} 回呼ばれた"

    def test_git_ops_run_has_encoding_utf8(self):
        """
        git_ops._run が encoding='utf-8' を subprocess.run に渡すことを確認する。
        """
        import claude_session_sync.git_ops as git_ops_mod

        captured_kwargs = {}

        def mock_subprocess_run(args, **kwargs):
            captured_kwargs.update(kwargs)
            result = MagicMock()
            result.stdout = ""
            result.stderr = ""
            result.returncode = 0
            return result

        with patch("subprocess.run", mock_subprocess_run):
            try:
                git_ops_mod._run(["git", "status"])
            except Exception:
                pass

        assert captured_kwargs.get("encoding") == "utf-8", \
            f"encoding='utf-8' が設定されていない: {captured_kwargs}"
