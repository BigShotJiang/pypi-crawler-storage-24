"""
tests/test_git_ops.py

git_ops.git_push のリトライロジックのテスト:
1. test_git_push_succeeds_on_first_attempt  — 成功時は1回でreturn
2. test_git_push_retries_on_rejection       — 1回目失敗→pull→2回目成功
3. test_git_push_raises_after_max_retries   — 全リトライ失敗で例外
"""
from __future__ import annotations

import subprocess
from unittest.mock import patch

import pytest

import claude_session_sync.git_ops as git_ops_mod


# ---------------------------------------------------------------------------
# テスト 1: 初回で成功 — 1回だけ push が呼ばれて即 return
# ---------------------------------------------------------------------------

class TestGitPushSucceedsOnFirstAttempt:
    def test_git_push_succeeds_first_try(self):
        """push が初回に成功した場合、_run は ["git", "push"] を1回だけ呼ぶ。"""
        calls = []

        def fake_run(args, cwd=None):
            calls.append(args)
            return subprocess.CompletedProcess(args, 0)

        with patch.object(git_ops_mod, "_run", fake_run):
            git_ops_mod.git_push("/fake/repo")

        assert calls == [["git", "push"]], f"呼び出し履歴が予想外: {calls}"


# ---------------------------------------------------------------------------
# テスト 2: 初回失敗 → pull してリトライ → 成功
# ---------------------------------------------------------------------------

class TestGitPushRetriesOnRejection:
    def test_git_push_retries_on_failure(self):
        """
        1回目の ["git", "push"] が失敗 →
        ["git", "push", "-u", "origin", "main"] も失敗 →
        ["git", "pull", "--rebase"] を実行 →
        2回目の ["git", "push"] が成功。
        """
        push_attempts = {"count": 0}
        calls = []

        def fake_run(args, cwd=None):
            calls.append(args)
            if args == ["git", "push"]:
                push_attempts["count"] += 1
                # 1回目の push だけ失敗させる
                if push_attempts["count"] == 1:
                    raise subprocess.CalledProcessError(1, "git push")
                # 2回目の push は成功
                return subprocess.CompletedProcess(args, 0)
            if args == ["git", "push", "-u", "origin", "main"]:
                # upstream 設定試行も失敗させてリトライを促す
                raise subprocess.CalledProcessError(1, "git push -u")
            # pull --rebase や pull --no-rebase は成功
            return subprocess.CompletedProcess(args, 0)

        with patch.object(git_ops_mod, "_run", fake_run):
            git_ops_mod.git_push("/fake/repo")

        # push が少なくとも2回試みられたことを確認
        assert push_attempts["count"] >= 2, \
            f"push のリトライ回数が少ない: {push_attempts['count']}"
        # pull 系コマンドが少なくとも1回呼ばれたことを確認
        pull_calls = [c for c in calls if "pull" in c]
        assert len(pull_calls) >= 1, f"pull が呼ばれていない: {calls}"


# ---------------------------------------------------------------------------
# テスト 3: 全リトライ失敗 — CalledProcessError が送出される
# ---------------------------------------------------------------------------

class TestGitPushRaisesAfterMaxRetries:
    def test_git_push_raises_after_max_retries(self):
        """全リトライが失敗した場合、CalledProcessError が送出される。"""
        def fake_run(args, cwd=None):
            raise subprocess.CalledProcessError(1, args)

        with patch.object(git_ops_mod, "_run", fake_run):
            with pytest.raises(subprocess.CalledProcessError):
                git_ops_mod.git_push("/fake/repo", max_retries=3)

    def test_git_push_raises_with_custom_max_retries(self):
        """max_retries=1 の場合は1サイクルで例外が発生する。"""
        calls = []

        def fake_run(args, cwd=None):
            calls.append(args)
            raise subprocess.CalledProcessError(1, args)

        with patch.object(git_ops_mod, "_run", fake_run):
            with pytest.raises(subprocess.CalledProcessError):
                git_ops_mod.git_push("/fake/repo", max_retries=1)
