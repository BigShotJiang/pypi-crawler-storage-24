"""Tests for claude_session_sync.sync module (file conversion / placement logic).

Git operations are not tested here — we test only the pure file-transformation
and placement logic that does NOT require a real git repository.
"""
from __future__ import annotations

import json
import os
import shutil
import time
from pathlib import Path

import pytest

from claude_session_sync.sync import (
    _apply_placeholder_to_record,
    _apply_local_to_record,
    _read_jsonl,
    _update_history,
    _write_jsonl,
)
from claude_session_sync.path_mapper import PathMapper
from claude_session_sync.config import Config
import claude_session_sync.config as config_mod


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

FIXTURES_DIR = Path(__file__).parent / "fixtures"
MINIMAL_SESSION = FIXTURES_DIR / "minimal_session.jsonl"

PLACEHOLDERS = {
    "{{HOME}}": "/home/alice",
}

MACHINE_ID = "test-machine-linux"


def make_config(tmp_path: Path, machine_id: str = MACHINE_ID) -> Config:
    cfg = Config()
    cfg.machine_id = machine_id
    cfg.claude_projects_dir = str(tmp_path / "claude_projects")
    cfg.claude_history_file = str(tmp_path / ".claude" / "history.jsonl")
    cfg.sync_repo_dir = str(tmp_path / "sync_repo")
    cfg.placeholders = PLACEHOLDERS
    return cfg


def make_session_records(cwd: str = "/home/alice/projects", message: str = "Hi") -> list[dict]:
    return [
        {"type": "system", "cwd": cwd, "sessionId": "sess-001"},
        {
            "type": "user",
            "message": {"role": "user", "content": message},
            "cwd": cwd,
        },
    ]


# ---------------------------------------------------------------------------
# push ロジックテスト: プレースホルダ変換と書き出し
# ---------------------------------------------------------------------------


class TestPushLogic:
    def test_placeholder_conversion_replaces_home_in_records(self):
        """セッションファイルをプレースホルダ化できる"""
        mapper = PathMapper(PLACEHOLDERS)
        records = make_session_records(cwd="/home/alice/projects", message="Hello from /home/alice!")

        converted = [_apply_placeholder_to_record(r, mapper) for r in records]

        # cwd が変換されている
        assert converted[0]["cwd"] == "{{HOME}}/projects"
        # message 内のパスも変換されている
        assert "/home/alice" not in json.dumps(converted)
        assert "{{HOME}}" in json.dumps(converted)

    def test_write_jsonl_creates_file_with_correct_content(self, tmp_path):
        """_write_jsonl がファイルを正しく書き出す"""
        dest = str(tmp_path / "subdir" / "out.jsonl")
        records = [{"key": "value"}, {"num": 42}]

        _write_jsonl(dest, records)

        assert os.path.exists(dest)
        loaded = _read_jsonl(dest)
        assert loaded == records

    def test_push_session_file_placed_in_correct_directory(self, tmp_path):
        """セッションファイルが sessions/{placeholder_project_dir}/ に書き出される（共有1コピー方式）"""
        cfg = make_config(tmp_path)
        mapper = PathMapper(cfg.placeholders)

        # ローカルのセッションファイルを模擬
        project_dir_name = "-home-alice-projects"
        session_id = "session-abc"
        records = make_session_records()

        converted = [_apply_placeholder_to_record(r, mapper) for r in records]
        placeholder_project_dir = mapper.to_placeholder(project_dir_name)

        dest_rel = os.path.join(
            "sessions",
            placeholder_project_dir,
            f"{session_id}.jsonl",
        )
        dest_abs = os.path.join(cfg.sync_repo_dir, dest_rel)

        _write_jsonl(dest_abs, converted)

        # ファイルが存在する
        assert os.path.exists(dest_abs)

        # 読み戻して内容確認
        loaded = _read_jsonl(dest_abs)
        assert len(loaded) == 2
        # プレースホルダが含まれている (実パスは含まれない)
        content_str = json.dumps(loaded)
        assert "/home/alice" not in content_str
        assert "{{HOME}}" in content_str

    def test_subagents_directory_is_copied(self, tmp_path):
        """subagents ディレクトリがある場合も正しくコピーされる"""
        cfg = make_config(tmp_path)

        # subagents ディレクトリを作成 (claude_projects_dir の1つ上)
        claude_parent = Path(cfg.claude_projects_dir).parent
        subagents_src = claude_parent / "subagents"
        subagents_src.mkdir(parents=True)
        (subagents_src / "agent1.json").write_text('{"name":"agent1"}', encoding="utf-8")
        (subagents_src / "subdir").mkdir()
        (subagents_src / "subdir" / "agent2.json").write_text('{"name":"agent2"}', encoding="utf-8")

        # shutil.copytree を使った模擬 (sync.py の os.walk ロジックをそのまま再現)
        dest_subagents_base = os.path.join(
            cfg.sync_repo_dir, "subagents", cfg.machine_id
        )
        for root, _, filenames in os.walk(str(subagents_src)):
            for fname in filenames:
                src_file = os.path.join(root, fname)
                rel = os.path.relpath(src_file, str(subagents_src))
                dest_file = os.path.join(dest_subagents_base, rel)
                os.makedirs(os.path.dirname(dest_file), exist_ok=True)
                shutil.copy2(src_file, dest_file)

        # コピーされている
        assert os.path.exists(os.path.join(dest_subagents_base, "agent1.json"))
        assert os.path.exists(os.path.join(dest_subagents_base, "subdir", "agent2.json"))

    def test_machine_json_is_created_with_correct_fields(self, tmp_path):
        """machines/{machine_id}.json が正しく作成される"""
        cfg = make_config(tmp_path)
        pushed_ids = ["session-1", "session-2", "session-3"]

        machines_dir = os.path.join(cfg.sync_repo_dir, "machines")
        os.makedirs(machines_dir, exist_ok=True)
        machine_meta = {
            "machine_id": cfg.machine_id,
            "updated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "session_count": len(pushed_ids),
            "placeholders": cfg.placeholders,
        }
        machine_file = os.path.join(machines_dir, f"{cfg.machine_id}.json")
        with open(machine_file, "w", encoding="utf-8") as f:
            json.dump(machine_meta, f, ensure_ascii=False, indent=2)

        # 検証
        assert os.path.exists(machine_file)
        with open(machine_file, encoding="utf-8") as f:
            loaded = json.load(f)

        assert loaded["machine_id"] == MACHINE_ID
        assert loaded["session_count"] == 3
        assert loaded["placeholders"] == PLACEHOLDERS
        assert "updated_at" in loaded

    def test_session_meta_is_created_with_correct_fields(self, tmp_path):
        """push 時に session_meta/{session_id}.json が正しく作成される"""
        cfg = make_config(tmp_path)
        session_id = "session-meta-test"

        session_meta_dir = os.path.join(cfg.sync_repo_dir, "session_meta")
        os.makedirs(session_meta_dir, exist_ok=True)

        meta = {
            "session_id": session_id,
            "last_editor": cfg.machine_id,
            "last_edited_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "last_modified": time.time(),  # 元ファイルのmtime（全マシンで共通の最終更新時刻）
        }
        meta_file = os.path.join(session_meta_dir, f"{session_id}.json")
        with open(meta_file, "w", encoding="utf-8") as f:
            json.dump(meta, f, ensure_ascii=False, indent=2)

        # 検証
        assert os.path.exists(meta_file)
        with open(meta_file, encoding="utf-8") as f:
            loaded = json.load(f)

        assert loaded["session_id"] == session_id
        assert loaded["last_editor"] == MACHINE_ID
        assert "last_edited_at" in loaded
        assert "last_modified" in loaded


# ---------------------------------------------------------------------------
# pull ロジックテスト: プレースホルダ復元と配置
# ---------------------------------------------------------------------------


class TestPullLogic:
    def _setup_repo_with_session(
        self,
        tmp_path: Path,
        project_dir_placeholder: str = "{{HOME}}-projects",
        session_id: str = "pulled-session-001",
        records: list[dict] | None = None,
    ) -> tuple[Config, str]:
        """テスト用のリポジトリ構造とセッションファイルを作成（共有1コピー方式）。

        セッションファイルは sessions/{placeholder_project_dir}/{session_id}.jsonl に配置し、
        sessions/_paths.json も作成する（新形式マーカー）。
        """
        cfg = make_config(tmp_path)
        if records is None:
            records = [
                {"type": "system", "cwd": "{{HOME}}/projects", "sessionId": session_id},
                {"type": "user", "message": {"role": "user", "content": "Hello"}, "cwd": "{{HOME}}/projects"},
            ]

        # リポジトリにセッションファイルを置く（新形式: machine_id なし）
        src_dir = Path(cfg.sync_repo_dir) / "sessions" / project_dir_placeholder
        src_dir.mkdir(parents=True)
        src_file = src_dir / f"{session_id}.jsonl"
        _write_jsonl(str(src_file), records)

        # sessions/_paths.json を作成（新形式マーカー）
        paths_json_path = Path(cfg.sync_repo_dir) / "sessions" / "_paths.json"
        paths_data: dict = {}
        if paths_json_path.is_file():
            with paths_json_path.open(encoding="utf-8") as _f:
                paths_data = json.load(_f)
        paths_data[project_dir_placeholder] = project_dir_placeholder
        with paths_json_path.open("w", encoding="utf-8") as _f:
            json.dump(paths_data, _f, ensure_ascii=False, indent=2)

        return cfg, str(src_file)

    def test_pull_restores_placeholder_to_local_path(self, tmp_path):
        """プレースホルダ化されたファイルをローカルパスに復元できる"""
        cfg, _ = self._setup_repo_with_session(tmp_path)
        mapper = PathMapper(cfg.placeholders)

        placeholder_records = [
            {"type": "system", "cwd": "{{HOME}}/projects", "sessionId": "s1"},
        ]

        converted = [_apply_local_to_record(r, mapper) for r in placeholder_records]

        assert converted[0]["cwd"] == "/home/alice/projects"
        assert "{{HOME}}" not in json.dumps(converted)

    def test_pull_places_file_in_correct_local_directory(self, tmp_path):
        """pull でファイルが claude_projects_dir/{project_dir}/ に配置される"""
        cfg, src_file = self._setup_repo_with_session(
            tmp_path,
            project_dir_placeholder="{{HOME}}-projects",
            session_id="session-xyz",
        )
        mapper = PathMapper(cfg.placeholders)

        # pull ロジックを再現
        project_dir_placeholder = "{{HOME}}-projects"
        session_id = "session-xyz"
        fname = f"{session_id}.jsonl"

        records = _read_jsonl(src_file)
        converted = [_apply_local_to_record(r, mapper) for r in records]

        local_project_dir_placeholder = mapper.to_local(project_dir_placeholder)
        local_project_dir = mapper.path_to_project_dir(local_project_dir_placeholder)

        dest_dir = os.path.join(cfg.claude_projects_dir, local_project_dir)
        dest_file = os.path.join(dest_dir, fname)

        os.makedirs(dest_dir, exist_ok=True)
        _write_jsonl(dest_file, converted)

        assert os.path.exists(dest_file)
        loaded = _read_jsonl(dest_file)
        assert len(loaded) == 2
        # プレースホルダが実パスに復元されている
        content_str = json.dumps(loaded)
        assert "{{HOME}}" not in content_str
        assert "/home/alice" in content_str

    def test_pull_existing_session_skipped_without_force(self, tmp_path):
        """既に存在するセッションは force=False でスキップされる"""
        cfg, src_file = self._setup_repo_with_session(
            tmp_path,
            project_dir_placeholder="{{HOME}}-projects",
            session_id="existing-session",
        )
        mapper = PathMapper(cfg.placeholders)

        project_dir_placeholder = "{{HOME}}-projects"
        session_id = "existing-session"
        fname = f"{session_id}.jsonl"

        local_project_dir_placeholder = mapper.to_local(project_dir_placeholder)
        local_project_dir = mapper.path_to_project_dir(local_project_dir_placeholder)
        dest_dir = os.path.join(cfg.claude_projects_dir, local_project_dir)
        dest_file = os.path.join(dest_dir, fname)

        # 既存ファイルを作成しておく
        os.makedirs(dest_dir, exist_ok=True)
        original_content = [{"original": True}]
        _write_jsonl(dest_file, original_content)

        # force=False のときはスキップ (既存ファイルは上書きしない)
        force = False
        pulled_ids = []
        if not os.path.exists(dest_file) or force:
            records = _read_jsonl(src_file)
            converted = [_apply_local_to_record(r, mapper) for r in records]
            _write_jsonl(dest_file, converted)
            pulled_ids.append(session_id)

        # スキップされたのでファイルは元のまま
        assert pulled_ids == []
        loaded = _read_jsonl(dest_file)
        assert loaded == original_content

    def test_pull_existing_session_overwritten_with_force(self, tmp_path):
        """force=True のとき既存セッションが上書きされる"""
        cfg, src_file = self._setup_repo_with_session(
            tmp_path,
            project_dir_placeholder="{{HOME}}-projects",
            session_id="force-session",
        )
        mapper = PathMapper(cfg.placeholders)

        project_dir_placeholder = "{{HOME}}-projects"
        session_id = "force-session"
        fname = f"{session_id}.jsonl"

        local_project_dir_placeholder = mapper.to_local(project_dir_placeholder)
        local_project_dir = mapper.path_to_project_dir(local_project_dir_placeholder)
        dest_dir = os.path.join(cfg.claude_projects_dir, local_project_dir)
        dest_file = os.path.join(dest_dir, fname)

        os.makedirs(dest_dir, exist_ok=True)
        _write_jsonl(dest_file, [{"original": True}])

        # force=True のとき上書き
        force = True
        if not os.path.exists(dest_file) or force:
            records = _read_jsonl(src_file)
            converted = [_apply_local_to_record(r, mapper) for r in records]
            _write_jsonl(dest_file, converted)

        loaded = _read_jsonl(dest_file)
        # 上書きされて "original" キーは無くなっている
        assert all("original" not in r for r in loaded)


# ---------------------------------------------------------------------------
# history.jsonl の更新テスト
# ---------------------------------------------------------------------------


class TestUpdateHistory:
    def test_new_entry_is_appended(self, tmp_path):
        """新規エントリが追加される"""
        history_file = str(tmp_path / ".claude" / "history.jsonl")
        records = [
            {
                "type": "user",
                "message": {"role": "user", "content": "First message"},
            }
        ]

        _update_history(
            history_file=history_file,
            session_id="session-new-001",
            project_path="/home/alice/projects",
            records=records,
        )

        assert os.path.exists(history_file)
        entries = []
        with open(history_file, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    entries.append(json.loads(line))

        assert len(entries) == 1
        assert entries[0]["sessionId"] == "session-new-001"
        assert entries[0]["project"] == "/home/alice/projects"
        assert "timestamp" in entries[0]

    def test_duplicate_session_id_is_not_added(self, tmp_path):
        """重複する sessionId のエントリは追加されない"""
        history_file = str(tmp_path / ".claude" / "history.jsonl")
        session_id = "session-dup-001"

        records = [
            {"type": "user", "message": {"role": "user", "content": "Hello"}},
        ]

        # 1回目
        _update_history(
            history_file=history_file,
            session_id=session_id,
            project_path="/home/alice/projects",
            records=records,
        )
        # 2回目 (重複)
        _update_history(
            history_file=history_file,
            session_id=session_id,
            project_path="/home/alice/projects",
            records=records,
        )

        entries = []
        with open(history_file, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    entries.append(json.loads(line))

        # 1件だけ
        assert len(entries) == 1
        assert entries[0]["sessionId"] == session_id

    def test_multiple_different_sessions_all_added(self, tmp_path):
        """異なる sessionId のエントリは全て追加される"""
        history_file = str(tmp_path / ".claude" / "history.jsonl")

        for i in range(3):
            _update_history(
                history_file=history_file,
                session_id=f"session-{i:03d}",
                project_path="/home/alice/projects",
                records=[{"type": "user", "message": {"role": "user", "content": f"msg {i}"}}],
            )

        entries = []
        with open(history_file, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    entries.append(json.loads(line))

        assert len(entries) == 3
        ids = {e["sessionId"] for e in entries}
        assert ids == {"session-000", "session-001", "session-002"}

    def test_first_message_extracted_from_records(self, tmp_path):
        """history エントリの display フィールドに first_message が入る"""
        history_file = str(tmp_path / ".claude" / "history.jsonl")
        records = [
            {"type": "user", "message": {"role": "user", "content": "This is the first message"}},
        ]

        _update_history(
            history_file=history_file,
            session_id="session-msg",
            project_path="/home/alice/projects",
            records=records,
        )

        with open(history_file, encoding="utf-8") as f:
            entry = json.loads(f.readline())

        assert entry["display"] == "This is the first message"

    def test_history_file_created_if_not_exists(self, tmp_path):
        """history.jsonl が存在しなくても新規作成される"""
        history_file = str(tmp_path / "nested" / "dir" / "history.jsonl")
        assert not os.path.exists(history_file)

        _update_history(
            history_file=history_file,
            session_id="session-create",
            project_path="/home/alice/projects",
            records=[],
        )

        assert os.path.exists(history_file)


# ---------------------------------------------------------------------------
# sync_directories フィルタリングテスト
# ---------------------------------------------------------------------------


def _make_local_session(
    claude_projects_dir: Path,
    project_path: str,
    session_id: str,
    message: str = "Hello",
) -> None:
    """claude_projects_dir 配下にローカルセッションファイルを作成する。"""
    from claude_session_sync.path_mapper import PathMapper

    # project_dir 名: パスを - 区切りに変換（先頭の / を - に）
    project_dir_name = project_path.replace("/", "-")
    project_dir = claude_projects_dir / project_dir_name
    project_dir.mkdir(parents=True, exist_ok=True)

    records = [
        {"type": "system", "cwd": project_path, "sessionId": session_id},
        {"type": "user", "message": {"role": "user", "content": message}, "cwd": project_path},
    ]
    session_file = project_dir / f"{session_id}.jsonl"
    _write_jsonl(str(session_file), records)


def _make_push_config(tmp_path: Path, sync_directories: list) -> "Config":
    """push テスト用の Config を作成する（git 操作なし）。"""
    cfg = Config()
    cfg.machine_id = "test-machine"
    cfg.claude_projects_dir = str(tmp_path / "claude_projects")
    cfg.claude_history_file = str(tmp_path / ".claude" / "history.jsonl")
    cfg.sync_repo_dir = str(tmp_path / "sync_repo")
    cfg.placeholders = {"{{PROJECTS}}": "/home/alice/projects"}
    cfg.custom_placeholders = {"PROJECTS": "/home/alice/projects"}
    cfg.sync_directories = sync_directories
    return cfg


class TestSyncDirectoriesFilter:
    """sync_directories によるセッションフィルタリングのテスト。"""

    def test_only_sessions_in_sync_directories_are_pushed(self, tmp_path, monkeypatch):
        """sync_directories 内のセッションだけが push される。"""
        monkeypatch.setattr(config_mod, "CONFIG_FILE", tmp_path / "test_config.json")
        monkeypatch.setattr(config_mod, "CONFIG_DIR", tmp_path)

        cfg = _make_push_config(tmp_path, sync_directories=["/home/alice/projects"])

        # projects 配下のセッション（共有対象）
        _make_local_session(
            Path(cfg.claude_projects_dir),
            "/home/alice/projects/myapp",
            "sess-in-projects",
        )
        # home 直下のセッション（共有対象外）
        _make_local_session(
            Path(cfg.claude_projects_dir),
            "/home/alice",
            "sess-home",
        )

        # git 操作をすべてスタブ化
        import claude_session_sync.sync as sync_mod
        monkeypatch.setattr(sync_mod, "_ensure_repo", lambda cfg: None)

        pushed_ids = []
        original_write = sync_mod._write_jsonl

        def fake_write(path, records):
            original_write(path, records)

        monkeypatch.setattr(sync_mod, "_write_jsonl", fake_write)

        # git_ops をスタブ化
        import claude_session_sync.git_ops as git_ops_mod
        monkeypatch.setattr(git_ops_mod, "git_add", lambda repo, files: None)
        monkeypatch.setattr(git_ops_mod, "git_commit", lambda repo, msg: None)
        monkeypatch.setattr(git_ops_mod, "git_push", lambda repo: None)

        # sync_repo_dir を初期化（machines/ ディレクトリが必要）
        Path(cfg.sync_repo_dir).mkdir(parents=True, exist_ok=True)
        (Path(cfg.sync_repo_dir) / ".git").mkdir()

        from claude_session_sync.sync import push_sessions
        result = push_sessions(cfg, dry_run=False)

        # projects 配下のセッションのみが push される
        assert "sess-in-projects" in result
        assert "sess-home" not in result

    def test_sessions_outside_sync_directories_are_skipped(self, tmp_path, monkeypatch):
        """sync_directories 外のセッションがスキップされる。"""
        monkeypatch.setattr(config_mod, "CONFIG_FILE", tmp_path / "test_config.json")
        monkeypatch.setattr(config_mod, "CONFIG_DIR", tmp_path)

        cfg = _make_push_config(tmp_path, sync_directories=["/home/alice/projects"])

        # 全て対象外
        _make_local_session(
            Path(cfg.claude_projects_dir),
            "/home/alice",
            "sess-home-only",
        )
        _make_local_session(
            Path(cfg.claude_projects_dir),
            "/tmp/scratch",
            "sess-tmp",
        )

        import claude_session_sync.sync as sync_mod
        monkeypatch.setattr(sync_mod, "_ensure_repo", lambda cfg: None)
        import claude_session_sync.git_ops as git_ops_mod
        monkeypatch.setattr(git_ops_mod, "git_add", lambda repo, files: None)
        monkeypatch.setattr(git_ops_mod, "git_commit", lambda repo, msg: None)
        monkeypatch.setattr(git_ops_mod, "git_push", lambda repo: None)

        Path(cfg.sync_repo_dir).mkdir(parents=True, exist_ok=True)
        (Path(cfg.sync_repo_dir) / ".git").mkdir()

        from claude_session_sync.sync import push_sessions
        result = push_sessions(cfg, dry_run=False)

        assert result == []

    def test_empty_sync_directories_pushes_all_sessions(self, tmp_path, monkeypatch):
        """sync_directories が空の場合は後方互換で全セッションが push される。"""
        monkeypatch.setattr(config_mod, "CONFIG_FILE", tmp_path / "test_config.json")
        monkeypatch.setattr(config_mod, "CONFIG_DIR", tmp_path)

        cfg = _make_push_config(tmp_path, sync_directories=[])  # 空 = フィルタなし

        _make_local_session(
            Path(cfg.claude_projects_dir),
            "/home/alice/projects/myapp",
            "sess-projects",
        )
        _make_local_session(
            Path(cfg.claude_projects_dir),
            "/home/alice",
            "sess-home",
        )

        import claude_session_sync.sync as sync_mod
        monkeypatch.setattr(sync_mod, "_ensure_repo", lambda cfg: None)
        import claude_session_sync.git_ops as git_ops_mod
        monkeypatch.setattr(git_ops_mod, "git_add", lambda repo, files: None)
        monkeypatch.setattr(git_ops_mod, "git_commit", lambda repo, msg: None)
        monkeypatch.setattr(git_ops_mod, "git_push", lambda repo: None)

        Path(cfg.sync_repo_dir).mkdir(parents=True, exist_ok=True)
        (Path(cfg.sync_repo_dir) / ".git").mkdir()

        from claude_session_sync.sync import push_sessions
        result = push_sessions(cfg, dry_run=False)

        # 全セッションが push される
        assert "sess-projects" in result
        assert "sess-home" in result


# ---------------------------------------------------------------------------
# push → pull 往復統合テスト
# ---------------------------------------------------------------------------


class TestPushPullRoundtrip:
    """push したデータを別マシン設定で pull して正しく復元されるか。"""

    def test_session_roundtrip_with_placeholder_conversion(self, tmp_path, monkeypatch):
        """マシンAで push → マシンBで pull → パスが正しく変換される。"""
        import claude_session_sync.config as config_mod
        monkeypatch.setattr(config_mod, "CONFIG_FILE", tmp_path / "test_config.json")
        monkeypatch.setattr(config_mod, "CONFIG_DIR", tmp_path)

        # マシンA（Linux的な設定）
        cfg_a = Config()
        cfg_a.machine_id = "linux-pc"
        cfg_a.claude_projects_dir = str(tmp_path / "machine_a" / "claude_projects")
        cfg_a.claude_history_file = str(tmp_path / "machine_a" / "history.jsonl")
        cfg_a.sync_repo_dir = str(tmp_path / "sync_repo")
        cfg_a.placeholders = {"{{PROJECTS}}": "/home/alice/projects"}
        cfg_a.sync_directories = ["/home/alice/projects"]

        # マシンAのセッションを作成
        project_dir = Path(cfg_a.claude_projects_dir) / "-home-alice-projects-myapp"
        project_dir.mkdir(parents=True)
        records = [
            {"type": "system", "cwd": "/home/alice/projects/myapp", "sessionId": "roundtrip-001"},
            {"type": "user", "message": {"role": "user", "content": "Hello from Linux"}, "cwd": "/home/alice/projects/myapp"},
        ]
        session_file = project_dir / "roundtrip-001.jsonl"
        _write_jsonl(str(session_file), records)

        # git操作をスタブ化
        import claude_session_sync.sync as sync_mod
        import claude_session_sync.git_ops as git_ops_mod
        monkeypatch.setattr(sync_mod, "_ensure_repo", lambda cfg: None)
        monkeypatch.setattr(git_ops_mod, "git_add", lambda repo, files: None)
        monkeypatch.setattr(git_ops_mod, "git_commit", lambda repo, msg: None)
        monkeypatch.setattr(git_ops_mod, "git_push", lambda repo: None)

        # sync_repo を初期化
        Path(cfg_a.sync_repo_dir).mkdir(parents=True, exist_ok=True)
        (Path(cfg_a.sync_repo_dir) / ".git").mkdir()

        # マシンAで push
        from claude_session_sync.sync import push_sessions
        pushed = push_sessions(cfg_a, dry_run=False)
        assert "roundtrip-001" in pushed

        # マシンB（Mac的な設定）
        cfg_b = Config()
        cfg_b.machine_id = "mac-mini"
        cfg_b.claude_projects_dir = str(tmp_path / "machine_b" / "claude_projects")
        cfg_b.claude_history_file = str(tmp_path / "machine_b" / "history.jsonl")
        cfg_b.sync_repo_dir = str(tmp_path / "sync_repo")  # 同じリポジトリ
        cfg_b.placeholders = {"{{PROJECTS}}": "/Users/bob/projects"}
        cfg_b.sync_directories = ["/Users/bob/projects"]

        # マシンBで pull (git_pull をスタブ化)
        monkeypatch.setattr(git_ops_mod, "git_pull", lambda repo: None)

        from claude_session_sync.sync import pull_sessions
        pulled = pull_sessions(cfg_b, dry_run=False, force=True)
        assert "roundtrip-001" in pulled

        # マシンBのローカルにファイルが配置されているか確認
        # cwd が /Users/bob/projects/myapp に変換されているはず
        expected_dir = Path(cfg_b.claude_projects_dir) / "-Users-bob-projects-myapp"
        expected_file = expected_dir / "roundtrip-001.jsonl"
        assert expected_file.is_file(), f"セッションファイルが配置されていない: {expected_file}"

        # パスが正しく変換されているか
        pulled_records = _read_jsonl(str(expected_file))
        assert pulled_records[0]["cwd"] == "/Users/bob/projects/myapp"
        assert "/home/alice" not in json.dumps(pulled_records)
        assert "/Users/bob" in json.dumps(pulled_records)


# ---------------------------------------------------------------------------
# _paths.json 書き出し統合テスト
# ---------------------------------------------------------------------------


class TestPushPathsJson:
    """push_sessions が sessions/_paths.json に正しいプレースホルダパスを書くこと。"""

    def _stub_git(self, monkeypatch):
        import claude_session_sync.sync as sync_mod
        import claude_session_sync.git_ops as git_ops_mod
        monkeypatch.setattr(sync_mod, "_ensure_repo", lambda cfg: None)
        monkeypatch.setattr(git_ops_mod, "git_add", lambda repo, files: None)
        monkeypatch.setattr(git_ops_mod, "git_commit", lambda repo, msg: None)
        monkeypatch.setattr(git_ops_mod, "git_push", lambda repo: None)

    def test_push_writes_paths_json_with_correct_placeholder_path(self, tmp_path, monkeypatch):
        """push_sessions が sessions/_paths.json にプレースホルダパスを書き出す。"""
        monkeypatch.setattr(config_mod, "CONFIG_FILE", tmp_path / "test_config.json")
        monkeypatch.setattr(config_mod, "CONFIG_DIR", tmp_path)
        self._stub_git(monkeypatch)

        cfg = _make_push_config(tmp_path, sync_directories=["/home/alice/projects"])
        _make_local_session(
            Path(cfg.claude_projects_dir),
            "/home/alice/projects/myapp",
            "sess-paths-json",
        )

        Path(cfg.sync_repo_dir).mkdir(parents=True, exist_ok=True)
        (Path(cfg.sync_repo_dir) / ".git").mkdir()

        from claude_session_sync.sync import push_sessions
        push_sessions(cfg, dry_run=False)

        paths_file = Path(cfg.sync_repo_dir) / "sessions" / "_paths.json"
        assert paths_file.is_file(), "sessions/_paths.json が作成されていない"

        with paths_file.open(encoding="utf-8") as f:
            paths_data = json.load(f)

        # プレースホルダパスが含まれている（実パスは含まれない）
        all_values = json.dumps(paths_data)
        assert "{{PROJECTS}}" in all_values, "_paths.json にプレースホルダが含まれていない"
        assert "/home/alice" not in all_values, "_paths.json に実パスが含まれている"

    def test_push_paths_json_key_is_placeholder_project_dir(self, tmp_path, monkeypatch):
        """_paths.json のキーが placeholder_project_dir 形式になっている。"""
        monkeypatch.setattr(config_mod, "CONFIG_FILE", tmp_path / "test_config.json")
        monkeypatch.setattr(config_mod, "CONFIG_DIR", tmp_path)
        self._stub_git(monkeypatch)

        cfg = _make_push_config(tmp_path, sync_directories=["/home/alice/projects"])
        _make_local_session(
            Path(cfg.claude_projects_dir),
            "/home/alice/projects/myapp",
            "sess-key-check",
        )

        Path(cfg.sync_repo_dir).mkdir(parents=True, exist_ok=True)
        (Path(cfg.sync_repo_dir) / ".git").mkdir()

        from claude_session_sync.sync import push_sessions
        push_sessions(cfg, dry_run=False)

        paths_file = Path(cfg.sync_repo_dir) / "sessions" / "_paths.json"
        with paths_file.open(encoding="utf-8") as f:
            paths_data = json.load(f)

        # キーがリポジトリ内の実際のディレクトリ名と一致している
        sessions_dir = Path(cfg.sync_repo_dir) / "sessions"
        actual_dirs = [
            d.name for d in sessions_dir.iterdir()
            if d.is_dir()
        ]
        for key in paths_data.keys():
            assert key in actual_dirs, (
                f"_paths.json のキー {key!r} がリポジトリ内に存在しない"
            )

    def test_push_no_machine_id_dir_in_sessions(self, tmp_path, monkeypatch):
        """push_sessions が sessions/ 直下に machine_id ディレクトリを作らない（共有1コピー方式）。"""
        monkeypatch.setattr(config_mod, "CONFIG_FILE", tmp_path / "test_config.json")
        monkeypatch.setattr(config_mod, "CONFIG_DIR", tmp_path)
        self._stub_git(monkeypatch)

        cfg = _make_push_config(tmp_path, sync_directories=["/home/alice/projects"])
        _make_local_session(
            Path(cfg.claude_projects_dir),
            "/home/alice/projects/myapp",
            "sess-no-machineid",
        )

        Path(cfg.sync_repo_dir).mkdir(parents=True, exist_ok=True)
        (Path(cfg.sync_repo_dir) / ".git").mkdir()

        from claude_session_sync.sync import push_sessions
        push_sessions(cfg, dry_run=False)

        sessions_dir = Path(cfg.sync_repo_dir) / "sessions"
        # machine_id ディレクトリが存在しない
        assert not (sessions_dir / cfg.machine_id).is_dir(), (
            f"sessions/{cfg.machine_id}/ が作成されてしまっている（共有1コピー方式では不要）"
        )


# ---------------------------------------------------------------------------
# pull_sessions 旧形式フォールバックテスト
# ---------------------------------------------------------------------------


class TestPullLegacyFallback:
    """_paths.json なしの旧形式リポジトリで pull_sessions がフォールバック動作すること。"""

    def _stub_git_pull(self, monkeypatch):
        import claude_session_sync.git_ops as git_ops_mod
        monkeypatch.setattr(git_ops_mod, "git_pull", lambda repo: None)

    def test_pull_fallback_without_paths_json(self, tmp_path, monkeypatch):
        """sessions/_paths.json がない旧形式でも pull できる（フォールバック）。"""
        monkeypatch.setattr(config_mod, "CONFIG_FILE", tmp_path / "test_config.json")
        monkeypatch.setattr(config_mod, "CONFIG_DIR", tmp_path)
        self._stub_git_pull(monkeypatch)

        cfg = make_config(tmp_path, machine_id="mac-mini")
        cfg.placeholders = {"{{HOME}}": "/home/alice"}

        # 旧形式: sessions/{other_machine_id}/{project_dir_placeholder}/{session_id}.jsonl
        other_machine = "linux-pc"
        project_dir_placeholder = "{{HOME}}-projects"
        session_id = "legacy-session-001"

        src_dir = Path(cfg.sync_repo_dir) / "sessions" / other_machine / project_dir_placeholder
        src_dir.mkdir(parents=True)
        records = [
            {"type": "system", "cwd": "{{HOME}}/projects", "sessionId": session_id},
            {"type": "user", "message": {"role": "user", "content": "Hello"}, "cwd": "{{HOME}}/projects"},
        ]
        _write_jsonl(str(src_dir / f"{session_id}.jsonl"), records)

        # .git ディレクトリを作成
        (Path(cfg.sync_repo_dir) / ".git").mkdir(parents=True, exist_ok=True)

        from claude_session_sync.sync import pull_sessions
        # _paths.json なし = 旧形式フォールバックモード
        assert not (Path(cfg.sync_repo_dir) / "sessions" / "_paths.json").exists()
        pulled = pull_sessions(cfg, dry_run=False, force=True)

        # 旧形式でも pull されること
        assert session_id in pulled, (
            f"旧形式フォールバックで {session_id} が pull されていない"
        )

    def test_pull_new_format_takes_priority_over_legacy(self, tmp_path, monkeypatch):
        """_paths.json がある場合は新形式として処理される（旧形式ディレクトリは無視）。"""
        monkeypatch.setattr(config_mod, "CONFIG_FILE", tmp_path / "test_config.json")
        monkeypatch.setattr(config_mod, "CONFIG_DIR", tmp_path)
        self._stub_git_pull(monkeypatch)

        cfg = make_config(tmp_path, machine_id="mac-mini")
        cfg.placeholders = {"{{HOME}}": "/home/alice"}

        # 新形式: sessions/{placeholder_project_dir}/{session_id}.jsonl
        placeholder_dir = "{{HOME}}-projects"
        session_id_new = "new-format-session"
        src_dir = Path(cfg.sync_repo_dir) / "sessions" / placeholder_dir
        src_dir.mkdir(parents=True)
        records_new = [
            {"type": "system", "cwd": "{{HOME}}/projects", "sessionId": session_id_new},
            {"type": "user", "message": {"role": "user", "content": "Hello new"}, "cwd": "{{HOME}}/projects"},
        ]
        _write_jsonl(str(src_dir / f"{session_id_new}.jsonl"), records_new)

        # _paths.json を作成（新形式マーカー）
        paths_file = Path(cfg.sync_repo_dir) / "sessions" / "_paths.json"
        with paths_file.open("w", encoding="utf-8") as f:
            json.dump({placeholder_dir: "{{HOME}}/projects"}, f)

        # 旧形式: sessions/{other_machine}/{project_dir}/{session_id}.jsonl（同時に存在）
        other_machine = "linux-pc"
        session_id_old = "old-format-session"
        old_dir = Path(cfg.sync_repo_dir) / "sessions" / other_machine / "{{HOME}}-work"
        old_dir.mkdir(parents=True)
        records_old = [
            {"type": "system", "cwd": "{{HOME}}/work", "sessionId": session_id_old},
        ]
        _write_jsonl(str(old_dir / f"{session_id_old}.jsonl"), records_old)

        # .git ディレクトリを作成
        (Path(cfg.sync_repo_dir) / ".git").mkdir(parents=True, exist_ok=True)

        from claude_session_sync.sync import pull_sessions
        pulled = pull_sessions(cfg, dry_run=False, force=True)

        # 新形式のセッションが pull される
        assert session_id_new in pulled, "新形式のセッションが pull されていない"
        # 旧形式ディレクトリはスキップされる（_paths.json にないので）
        assert session_id_old not in pulled, (
            "_paths.json にない旧形式セッションが pull されてしまっている"
        )


# ---------------------------------------------------------------------------
# push_sessions 削除ファイル反映テスト
# ---------------------------------------------------------------------------


class TestPushDeletedFiles:
    """push 時にローカルで削除したセッションがリモートからも消えること。"""

    def _stub_git(self, monkeypatch):
        import claude_session_sync.sync as sync_mod
        import claude_session_sync.git_ops as git_ops_mod
        monkeypatch.setattr(sync_mod, "_ensure_repo", lambda cfg: None)
        monkeypatch.setattr(git_ops_mod, "git_add", lambda repo, files: None)
        monkeypatch.setattr(git_ops_mod, "git_commit", lambda repo, msg: None)
        monkeypatch.setattr(git_ops_mod, "git_push", lambda repo: None)

    @pytest.mark.xfail(
        reason=(
            "現在の push_sessions 実装はセッションを個別に書き出すだけで"
            "ローカルで削除されたファイルをリモートから削除しない。"
            "config_sync.py の shutil.rmtree + copytree パターンと同様の"
            "完全置換が必要。この動作を将来実装するための仕様テスト。"
        ),
        strict=True,
    )
    def test_deleted_session_removed_from_remote(self, tmp_path, monkeypatch):
        """ローカルで削除したセッションファイルがリモートからも削除される。

        push_sessions は sessions/{placeholder_project_dir}/ を
        shutil.rmtree + copytree パターンで置き換えることで実現する。
        """
        monkeypatch.setattr(config_mod, "CONFIG_FILE", tmp_path / "test_config.json")
        monkeypatch.setattr(config_mod, "CONFIG_DIR", tmp_path)
        self._stub_git(monkeypatch)

        cfg = _make_push_config(tmp_path, sync_directories=["/home/alice/projects"])

        # セッション1とセッション2を作成して push
        _make_local_session(
            Path(cfg.claude_projects_dir),
            "/home/alice/projects/myapp",
            "sess-keep",
        )
        _make_local_session(
            Path(cfg.claude_projects_dir),
            "/home/alice/projects/myapp",
            "sess-delete",
        )

        Path(cfg.sync_repo_dir).mkdir(parents=True, exist_ok=True)
        (Path(cfg.sync_repo_dir) / ".git").mkdir()

        from claude_session_sync.sync import push_sessions
        # 1回目 push: 2つのセッションをリモートに書き出す
        pushed1 = push_sessions(cfg, dry_run=False)
        assert "sess-keep" in pushed1
        assert "sess-delete" in pushed1

        # リモートに2つのファイルが存在することを確認
        from claude_session_sync.path_mapper import PathMapper
        mapper = PathMapper(cfg.placeholders)
        placeholder_path = mapper.to_placeholder("/home/alice/projects/myapp")
        placeholder_project_dir = PathMapper.path_to_project_dir(placeholder_path)
        remote_dir = Path(cfg.sync_repo_dir) / "sessions" / placeholder_project_dir
        assert (remote_dir / "sess-keep.jsonl").is_file()
        assert (remote_dir / "sess-delete.jsonl").is_file()

        # ローカルでセッション2を削除
        local_project_dir_name = "/home/alice/projects/myapp".replace("/", "-")
        local_session_file = (
            Path(cfg.claude_projects_dir) / local_project_dir_name / "sess-delete.jsonl"
        )
        local_session_file.unlink()
        assert not local_session_file.exists()

        # 2回目 push: ローカルで削除したファイルがリモートからも消えること
        pushed2 = push_sessions(cfg, dry_run=False)
        assert "sess-keep" in pushed2
        assert "sess-delete" not in pushed2

        # リモートから sess-delete.jsonl が消えている
        assert not (remote_dir / "sess-delete.jsonl").is_file(), (
            "ローカルで削除したセッションがリモートに残っている"
        )
        # sess-keep.jsonl は残っている
        assert (remote_dir / "sess-keep.jsonl").is_file(), (
            "削除していないセッションまで消えてしまっている"
        )


# ---------------------------------------------------------------------------
# session_meta 差分更新テスト
# ---------------------------------------------------------------------------


class TestSessionMetaDiffUpdate:
    """session_meta が変更のあったセッションだけ更新されること。"""

    def _stub_git(self, monkeypatch):
        import claude_session_sync.sync as sync_mod
        import claude_session_sync.git_ops as git_ops_mod
        monkeypatch.setattr(sync_mod, "_ensure_repo", lambda cfg: None)
        monkeypatch.setattr(git_ops_mod, "git_add", lambda repo, files: None)
        monkeypatch.setattr(git_ops_mod, "git_commit", lambda repo, msg: None)
        monkeypatch.setattr(git_ops_mod, "git_push", lambda repo: None)

    def test_unchanged_session_meta_not_overwritten(self, tmp_path, monkeypatch):
        """変更のないセッションの session_meta は上書きされない（last_editor が保持される）。"""
        monkeypatch.setattr(config_mod, "CONFIG_FILE", tmp_path / "test_config.json")
        monkeypatch.setattr(config_mod, "CONFIG_DIR", tmp_path)
        self._stub_git(monkeypatch)

        cfg = _make_push_config(tmp_path, sync_directories=["/home/alice/projects"])
        # machine_id を "machine-a" に設定（更新しないセッションの last_editor にする）
        cfg.machine_id = "machine-a"

        _make_local_session(
            Path(cfg.claude_projects_dir),
            "/home/alice/projects/myapp",
            "sess-stable",
        )

        Path(cfg.sync_repo_dir).mkdir(parents=True, exist_ok=True)
        (Path(cfg.sync_repo_dir) / ".git").mkdir()

        from claude_session_sync.sync import push_sessions
        # 1回目 push（machine-a として）
        push_sessions(cfg, dry_run=False)

        meta_file = Path(cfg.sync_repo_dir) / "session_meta" / "sess-stable.json"
        assert meta_file.is_file(), "session_meta が作成されていない"
        with meta_file.open(encoding="utf-8") as f:
            first_meta = json.load(f)
        assert first_meta["last_editor"] == "machine-a"
        first_mtime = first_meta.get("last_modified")

        # 2回目 push: machine_id を "machine-b" に変更してもファイルを変更しない
        cfg.machine_id = "machine-b"
        push_sessions(cfg, dry_run=False)

        with meta_file.open(encoding="utf-8") as f:
            second_meta = json.load(f)

        # ファイルが変更されていないため session_meta の last_editor は変わらない
        assert second_meta["last_editor"] == "machine-a", (
            "変更のないセッションの last_editor が上書きされた"
            f"（期待: machine-a, 実際: {second_meta['last_editor']!r}）"
        )

    def test_modified_session_meta_is_updated(self, tmp_path, monkeypatch):
        """変更のあったセッションの session_meta は更新される。"""
        monkeypatch.setattr(config_mod, "CONFIG_FILE", tmp_path / "test_config.json")
        monkeypatch.setattr(config_mod, "CONFIG_DIR", tmp_path)
        self._stub_git(monkeypatch)

        cfg = _make_push_config(tmp_path, sync_directories=["/home/alice/projects"])
        cfg.machine_id = "machine-a"

        local_project_dir_name = "/home/alice/projects/myapp".replace("/", "-")
        project_dir = Path(cfg.claude_projects_dir) / local_project_dir_name
        project_dir.mkdir(parents=True, exist_ok=True)

        # セッションファイルを作成
        session_file = project_dir / "sess-modified.jsonl"
        records_v1 = [
            {"type": "system", "cwd": "/home/alice/projects/myapp", "sessionId": "sess-modified"},
            {"type": "user", "message": {"role": "user", "content": "Original"}, "cwd": "/home/alice/projects/myapp"},
        ]
        _write_jsonl(str(session_file), records_v1)

        Path(cfg.sync_repo_dir).mkdir(parents=True, exist_ok=True)
        (Path(cfg.sync_repo_dir) / ".git").mkdir()

        from claude_session_sync.sync import push_sessions
        # 1回目 push
        push_sessions(cfg, dry_run=False)

        meta_file = Path(cfg.sync_repo_dir) / "session_meta" / "sess-modified.json"
        with meta_file.open(encoding="utf-8") as f:
            first_meta = json.load(f)
        assert first_meta["last_editor"] == "machine-a"

        # セッションファイルを変更
        cfg.machine_id = "machine-b"
        cfg.placeholders = {"{{PROJECTS}}": "/home/alice/projects"}  # 再設定
        records_v2 = records_v1 + [
            {"type": "user", "message": {"role": "user", "content": "Updated"}, "cwd": "/home/alice/projects/myapp"},
        ]
        # mtime を確実に変えるために少し待ってから書き出す
        _write_jsonl(str(session_file), records_v2)
        # mtime を強制的に変更
        new_mtime = time.time() + 10
        os.utime(str(session_file), (new_mtime, new_mtime))

        # 2回目 push
        push_sessions(cfg, dry_run=False)

        with meta_file.open(encoding="utf-8") as f:
            second_meta = json.load(f)

        # ファイルが変更されたので session_meta の last_editor が更新される
        assert second_meta["last_editor"] == "machine-b", (
            "変更のあったセッションの last_editor が更新されなかった"
            f"（期待: machine-b, 実際: {second_meta['last_editor']!r}）"
        )
