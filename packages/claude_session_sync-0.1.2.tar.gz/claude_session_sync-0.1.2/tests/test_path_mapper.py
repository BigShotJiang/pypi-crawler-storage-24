"""Comprehensive tests for PathMapper."""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from claude_session_sync.path_mapper import PathMapper

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

FIXTURES_DIR = Path(__file__).parent / "fixtures"


@pytest.fixture()
def linux_mapper() -> PathMapper:
    """A mapper representing a Linux developer's machine."""
    return PathMapper(
        {
            "{{HOME}}": "/home/tubome",
            "{{PROJECTS}}": "/home/tubome/projects",
        }
    )


@pytest.fixture()
def mac_mapper() -> PathMapper:
    """A mapper representing a macOS developer's machine."""
    return PathMapper(
        {
            "{{HOME}}": "/Users/tubome",
            "{{PROJECTS}}": "/Users/tubome/projects",
        }
    )


@pytest.fixture()
def windows_mapper() -> PathMapper:
    """A mapper representing a Windows developer's machine."""
    return PathMapper(
        {
            "{{HOME}}": "C:\\Users\\tubome",
        }
    )


@pytest.fixture()
def simple_mapper() -> PathMapper:
    """Minimal mapper with only HOME."""
    return PathMapper({"{{HOME}}": "/home/tubome"})


@pytest.fixture()
def sample_session_line() -> str:
    """First line of the sample session fixture file."""
    path = FIXTURES_DIR / "sample_session.jsonl"
    with path.open(encoding="utf-8") as fh:
        return fh.readline().rstrip("\n")


# ---------------------------------------------------------------------------
# to_placeholder
# ---------------------------------------------------------------------------


class TestToPlaceholder:
    def test_simple_home_replacement(self, simple_mapper: PathMapper) -> None:
        """Single occurrence of HOME path is replaced."""
        result = simple_mapper.to_placeholder("/home/tubome/file.txt")
        assert result == "{{HOME}}/file.txt"

    def test_multiple_paths_in_json(self, linux_mapper: PathMapper) -> None:
        """cwd and file_path mixed in a JSON string are both replaced."""
        data = json.dumps(
            {
                "cwd": "/home/tubome/projects",
                "file_path": "/home/tubome/projects/main.py",
            }
        )
        result = linux_mapper.to_placeholder(data)
        assert "/home/tubome" not in result
        assert "/home/tubome/projects" not in result
        assert "{{PROJECTS}}/main.py" in result
        assert '"cwd": "{{PROJECTS}}"' in result

    def test_longer_path_replaced_first(self, linux_mapper: PathMapper) -> None:
        """/home/tubome/projects must map to {{PROJECTS}}, not {{HOME}}/projects."""
        result = linux_mapper.to_placeholder("/home/tubome/projects/foo")
        assert result == "{{PROJECTS}}/foo"
        assert "{{HOME}}" not in result

    def test_no_path_no_change(self, simple_mapper: PathMapper) -> None:
        """Text without any registered paths is returned unchanged."""
        text = "hello world, no paths here"
        assert simple_mapper.to_placeholder(text) == text

    def test_empty_string(self, simple_mapper: PathMapper) -> None:
        """Empty string input returns empty string."""
        assert simple_mapper.to_placeholder("") == ""

    def test_windows_style_path(self, windows_mapper: PathMapper) -> None:
        """Windows-style path with backslashes is replaced correctly."""
        result = windows_mapper.to_placeholder("C:\\Users\\tubome\\file.txt")
        assert result == "{{HOME}}\\file.txt"

    def test_japanese_path(self, simple_mapper: PathMapper) -> None:
        """Path containing Japanese characters is replaced correctly."""
        result = simple_mapper.to_placeholder("/home/tubome/ダウンロード/file.txt")
        assert result == "{{HOME}}/ダウンロード/file.txt"


# ---------------------------------------------------------------------------
# to_local
# ---------------------------------------------------------------------------


class TestToLocal:
    def test_simple_placeholder_restore(self, simple_mapper: PathMapper) -> None:
        """Single placeholder is restored to the real path."""
        result = simple_mapper.to_local("{{HOME}}/file.txt")
        assert result == "/home/tubome/file.txt"

    def test_multiple_placeholders_restored(self, linux_mapper: PathMapper) -> None:
        """Multiple different placeholders in one string are all restored."""
        text = '{"cwd": "{{PROJECTS}}", "home": "{{HOME}}"}'
        result = linux_mapper.to_local(text)
        assert "{{HOME}}" not in result
        assert "{{PROJECTS}}" not in result
        assert "/home/tubome/projects" in result
        assert "/home/tubome" in result

    def test_unknown_placeholder_unchanged(self, simple_mapper: PathMapper) -> None:
        """An unregistered placeholder is left as-is."""
        text = "{{UNKNOWN}}/path"
        assert simple_mapper.to_local(text) == text

    def test_empty_string(self, simple_mapper: PathMapper) -> None:
        """Empty string input returns empty string."""
        assert simple_mapper.to_local("") == ""


# ---------------------------------------------------------------------------
# Round-trip
# ---------------------------------------------------------------------------


class TestRoundTrip:
    @pytest.mark.parametrize(
        "original",
        [
            "/home/tubome/file.txt",
            "/home/tubome/projects/src/main.py",
            '{"cwd": "/home/tubome/projects", "path": "/home/tubome/.config"}',
            "/home/tubome/ダウンロード/レポート.pdf",
        ],
    )
    def test_round_trip(self, linux_mapper: PathMapper, original: str) -> None:
        """to_placeholder followed by to_local recovers the original string."""
        placeholder_form = linux_mapper.to_placeholder(original)
        restored = linux_mapper.to_local(placeholder_form)
        assert restored == original

    def test_round_trip_sample_session_line(
        self, linux_mapper: PathMapper, sample_session_line: str
    ) -> None:
        """First line of the real session fixture survives a round-trip."""
        placeholder_form = linux_mapper.to_placeholder(sample_session_line)
        restored = linux_mapper.to_local(placeholder_form)
        assert restored == sample_session_line

    def test_round_trip_no_placeholder_unchanged(
        self, linux_mapper: PathMapper
    ) -> None:
        """Text with no registered paths is unchanged through the round-trip."""
        text = "just some text without any known path"
        assert linux_mapper.to_local(linux_mapper.to_placeholder(text)) == text


# ---------------------------------------------------------------------------
# path_to_project_dir
# ---------------------------------------------------------------------------


class TestPathToProjectDir:
    def test_linux_path(self) -> None:
        assert PathMapper.path_to_project_dir("/home/tubome/projects") == "-home-tubome-projects"

    def test_macos_path(self) -> None:
        assert PathMapper.path_to_project_dir("/Users/tubome/projects") == "-Users-tubome-projects"

    def test_windows_path(self) -> None:
        assert (
            PathMapper.path_to_project_dir("C:\\Users\\tubome\\projects")
            == "C--Users-tubome-projects"
        )

    def test_root_path(self) -> None:
        assert PathMapper.path_to_project_dir("/") == "-"

    def test_home_only(self) -> None:
        assert PathMapper.path_to_project_dir("/home/tubome") == "-home-tubome"


# ---------------------------------------------------------------------------
# convert_project_dir_name  (Linux -> macOS)
# ---------------------------------------------------------------------------


class TestConvertProjectDirName:
    def test_linux_to_mac(
        self, linux_mapper: PathMapper, mac_mapper: PathMapper
    ) -> None:
        """A Linux project dir name is converted to the equivalent macOS name.

        Strategy: use linux_mapper to convert to placeholder, then mac_mapper
        to convert back.  convert_project_dir_name applies both steps internally
        when the mapper holds both the source and target mappings, so we need a
        combined mapper that knows how to go from Linux real-paths -> placeholder
        and placeholder -> macOS real-paths.

        The cleanest way to test the cross-machine scenario is:
          1. linux_mapper.to_placeholder  (dir-name level)
          2. mac_mapper.to_local          (dir-name level)
        which is exactly what convert_project_dir_name does using a single
        combined mapper (source real-paths as keys, target real-paths via
        placeholder bridge).

        Here we build a cross mapper that bridges Linux->Mac directly.
        """
        # A mapper whose _real_to_placeholder knows Linux paths
        # and whose _placeholders map to Mac paths.
        cross_mapper = PathMapper(
            {
                "{{HOME}}": "/Users/tubome",
                "{{PROJECTS}}": "/Users/tubome/projects",
            }
        )
        # Temporarily patch real_to_placeholder to use Linux paths as keys
        cross_mapper._real_to_placeholder = {
            "/home/tubome": "{{HOME}}",
            "/home/tubome/projects": "{{PROJECTS}}",
        }

        linux_dir_name = "-home-tubome-projects"
        result = cross_mapper.convert_project_dir_name(linux_dir_name)
        assert result == "-Users-tubome-projects"


# ---------------------------------------------------------------------------
# Windows path normalization
# ---------------------------------------------------------------------------


class TestWindowsPathNormalization:
    def test_to_placeholder_with_backslash(self) -> None:
        """Windowsのバックスラッシュパスがプレースホルダに変換される"""
        mapper = PathMapper({"{{PROJECTS}}": "C:\\Users\\tubome\\projects"})
        result = mapper.to_placeholder("C:\\Users\\tubome\\projects\\crossclip")
        assert result == "{{PROJECTS}}\\crossclip"

    def test_to_placeholder_with_forward_slash(self) -> None:
        """Windowsのスラッシュ混在パスもプレースホルダに変換される"""
        mapper = PathMapper({"{{PROJECTS}}": "C:\\Users\\tubome\\projects"})
        result = mapper.to_placeholder("C:/Users/tubome/projects/crossclip")
        assert result == "{{PROJECTS}}/crossclip"
