"""
tests/test_session_lock.py

session_lock モジュールのテスト:
1. acquire_lock: 新規ロック取得
2. acquire_lock: 自マシンのロック更新（TTL延長）
3. acquire_lock: 他マシンのロック中（期限内）→ False
4. acquire_lock: 他マシンのロック（期限切れ）→ 奪取成功
5. release_lock: 正常解放
6. release_lock: 他マシンのロック → False
7. check_lock: ロックあり（期限内）→ dict返却
8. check_lock: ロックなし → None
9. check_lock: 期限切れ → None
10. release_all_locks: 複数ロック一括解放
11. cleanup_expired_locks: 期限切れのみ削除、有効は残す
12. renew_locks: TTL延長
"""
from __future__ import annotations

import json
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from claude_session_sync.session_lock import (
    acquire_lock,
    check_lock,
    cleanup_expired_locks,
    release_all_locks,
    release_lock,
    renew_locks,
    _lock_file,
    _locks_dir,
    _fmt_dt,
    _now_utc,
)


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

MACHINE_A = "machine-a"
MACHINE_B = "machine-b"
SESSION_1 = "session-00000001"
SESSION_2 = "session-00000002"
SESSION_3 = "session-00000003"


def _write_lock_raw(sync_repo_dir: str, session_id: str, machine_id: str, delta_minutes: float) -> None:
    """テスト用にロックファイルを直接書き込む。delta_minutes > 0 で未来（有効）、< 0 で過去（期限切れ）。"""
    now = _now_utc()
    expires_at = now + timedelta(minutes=delta_minutes)
    locked_at = now
    lock_data = {
        "session_id": session_id,
        "machine_id": machine_id,
        "locked_at": _fmt_dt(locked_at),
        "expires_at": _fmt_dt(expires_at),
    }
    path = _lock_file(sync_repo_dir, session_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(lock_data, f, indent=2, ensure_ascii=False)
        f.write("\n")


# ---------------------------------------------------------------------------
# テスト 1: 新規ロック取得
# ---------------------------------------------------------------------------

class TestAcquireLockNew:
    def test_acquire_creates_lock_file(self, tmp_path):
        """新規ロック取得でロックファイルが作成される。"""
        repo = str(tmp_path / "repo")
        result = acquire_lock(repo, SESSION_1, MACHINE_A)
        assert result is True

        lock_path = _lock_file(repo, SESSION_1)
        assert lock_path.exists()

        with lock_path.open() as f:
            data = json.load(f)
        assert data["session_id"] == SESSION_1
        assert data["machine_id"] == MACHINE_A
        assert "locked_at" in data
        assert "expires_at" in data

    def test_acquire_lock_has_correct_ttl(self, tmp_path):
        """取得したロックの TTL が指定通り（10分）になっている。"""
        repo = str(tmp_path / "repo")
        acquire_lock(repo, SESSION_1, MACHINE_A, ttl_minutes=10)

        lock_path = _lock_file(repo, SESSION_1)
        with lock_path.open() as f:
            data = json.load(f)

        now = _now_utc()
        expires_at_str = data["expires_at"].replace("Z", "+00:00")
        expires_at = datetime.fromisoformat(expires_at_str)
        diff = (expires_at - now).total_seconds()
        # 10分 ± 5秒の範囲に収まっている
        assert 595 <= diff <= 605, f"TTL が想定外: {diff}秒"


# ---------------------------------------------------------------------------
# テスト 2: 自マシンのロック更新（TTL延長）
# ---------------------------------------------------------------------------

class TestAcquireLockRenew:
    def test_own_lock_is_renewed(self, tmp_path):
        """自マシンのロックは TTL が更新される。"""
        repo = str(tmp_path / "repo")
        # 残り1分のロックを作成
        _write_lock_raw(repo, SESSION_1, MACHINE_A, delta_minutes=1)

        lock_path = _lock_file(repo, SESSION_1)
        with lock_path.open() as f:
            before = json.load(f)

        result = acquire_lock(repo, SESSION_1, MACHINE_A, ttl_minutes=10)
        assert result is True

        with lock_path.open() as f:
            after = json.load(f)

        # expires_at が延長されている
        before_exp = datetime.fromisoformat(before["expires_at"].replace("Z", "+00:00"))
        after_exp = datetime.fromisoformat(after["expires_at"].replace("Z", "+00:00"))
        assert after_exp > before_exp


# ---------------------------------------------------------------------------
# テスト 3: 他マシンのロック中（期限内）→ False
# ---------------------------------------------------------------------------

class TestAcquireLockBlocked:
    def test_other_machine_active_lock_returns_false(self, tmp_path):
        """他マシンのロックが期限内の場合は False を返す。"""
        repo = str(tmp_path / "repo")
        _write_lock_raw(repo, SESSION_1, MACHINE_B, delta_minutes=5)

        result = acquire_lock(repo, SESSION_1, MACHINE_A)
        assert result is False


# ---------------------------------------------------------------------------
# テスト 4: 他マシンのロック（期限切れ）→ 奪取成功
# ---------------------------------------------------------------------------

class TestAcquireLockExpiredOther:
    def test_expired_other_lock_can_be_taken(self, tmp_path):
        """他マシンのロックが期限切れなら奪取できる。"""
        repo = str(tmp_path / "repo")
        _write_lock_raw(repo, SESSION_1, MACHINE_B, delta_minutes=-1)

        result = acquire_lock(repo, SESSION_1, MACHINE_A)
        assert result is True

        lock_path = _lock_file(repo, SESSION_1)
        with lock_path.open() as f:
            data = json.load(f)
        assert data["machine_id"] == MACHINE_A


# ---------------------------------------------------------------------------
# テスト 5: release_lock 正常解放
# ---------------------------------------------------------------------------

class TestReleaseLockSuccess:
    def test_release_own_lock_removes_file(self, tmp_path):
        """自マシンのロックを正常に解放できる。"""
        repo = str(tmp_path / "repo")
        acquire_lock(repo, SESSION_1, MACHINE_A)
        lock_path = _lock_file(repo, SESSION_1)
        assert lock_path.exists()

        result = release_lock(repo, SESSION_1, MACHINE_A)
        assert result is True
        assert not lock_path.exists()

    def test_release_nonexistent_lock_returns_true(self, tmp_path):
        """ロックが存在しない場合も True を返す（既に解放済み）。"""
        repo = str(tmp_path / "repo")
        result = release_lock(repo, SESSION_1, MACHINE_A)
        assert result is True


# ---------------------------------------------------------------------------
# テスト 6: release_lock 他マシンのロック → False
# ---------------------------------------------------------------------------

class TestReleaseLockOtherMachine:
    def test_cannot_release_other_machine_lock(self, tmp_path):
        """他マシンのロックは解放できない（False を返す）。"""
        repo = str(tmp_path / "repo")
        _write_lock_raw(repo, SESSION_1, MACHINE_B, delta_minutes=5)

        result = release_lock(repo, SESSION_1, MACHINE_A)
        assert result is False

        # ファイルが残っている
        lock_path = _lock_file(repo, SESSION_1)
        assert lock_path.exists()


# ---------------------------------------------------------------------------
# テスト 7: check_lock ロックあり（期限内）→ dict返却
# ---------------------------------------------------------------------------

class TestCheckLockActive:
    def test_active_lock_returns_dict(self, tmp_path):
        """期限内のロックは dict を返す。"""
        repo = str(tmp_path / "repo")
        _write_lock_raw(repo, SESSION_1, MACHINE_A, delta_minutes=5)

        result = check_lock(repo, SESSION_1)
        assert result is not None
        assert isinstance(result, dict)
        assert result["session_id"] == SESSION_1
        assert result["machine_id"] == MACHINE_A


# ---------------------------------------------------------------------------
# テスト 8: check_lock ロックなし → None
# ---------------------------------------------------------------------------

class TestCheckLockNone:
    def test_no_lock_returns_none(self, tmp_path):
        """ロックが存在しない場合は None を返す。"""
        repo = str(tmp_path / "repo")
        result = check_lock(repo, SESSION_1)
        assert result is None


# ---------------------------------------------------------------------------
# テスト 9: check_lock 期限切れ → None
# ---------------------------------------------------------------------------

class TestCheckLockExpired:
    def test_expired_lock_returns_none(self, tmp_path):
        """期限切れのロックは None を返す。"""
        repo = str(tmp_path / "repo")
        _write_lock_raw(repo, SESSION_1, MACHINE_A, delta_minutes=-1)

        result = check_lock(repo, SESSION_1)
        assert result is None


# ---------------------------------------------------------------------------
# テスト 10: release_all_locks 複数ロック一括解放
# ---------------------------------------------------------------------------

class TestReleaseAllLocks:
    def test_releases_all_own_locks(self, tmp_path):
        """自マシンの複数ロックを一括解放できる。"""
        repo = str(tmp_path / "repo")
        _write_lock_raw(repo, SESSION_1, MACHINE_A, delta_minutes=5)
        _write_lock_raw(repo, SESSION_2, MACHINE_A, delta_minutes=5)
        _write_lock_raw(repo, SESSION_3, MACHINE_B, delta_minutes=5)  # 他マシン

        released = release_all_locks(repo, MACHINE_A)

        assert set(released) == {SESSION_1, SESSION_2}
        # 自マシンのロックは削除されている
        assert not _lock_file(repo, SESSION_1).exists()
        assert not _lock_file(repo, SESSION_2).exists()
        # 他マシンのロックは残っている
        assert _lock_file(repo, SESSION_3).exists()

    def test_no_own_locks_returns_empty_list(self, tmp_path):
        """自マシンのロックがない場合は空リストを返す。"""
        repo = str(tmp_path / "repo")
        _write_lock_raw(repo, SESSION_1, MACHINE_B, delta_minutes=5)

        released = release_all_locks(repo, MACHINE_A)
        assert released == []

    def test_no_locks_dir_returns_empty_list(self, tmp_path):
        """locks ディレクトリが存在しない場合は空リストを返す。"""
        repo = str(tmp_path / "repo")
        released = release_all_locks(repo, MACHINE_A)
        assert released == []


# ---------------------------------------------------------------------------
# テスト 11: cleanup_expired_locks 期限切れのみ削除、有効は残す
# ---------------------------------------------------------------------------

class TestCleanupExpiredLocks:
    def test_removes_expired_keeps_active(self, tmp_path):
        """期限切れのみ削除し、有効なロックは残す。"""
        repo = str(tmp_path / "repo")
        _write_lock_raw(repo, SESSION_1, MACHINE_A, delta_minutes=5)   # 有効
        _write_lock_raw(repo, SESSION_2, MACHINE_B, delta_minutes=-1)  # 期限切れ
        _write_lock_raw(repo, SESSION_3, MACHINE_A, delta_minutes=-5)  # 期限切れ

        cleaned = cleanup_expired_locks(repo)

        assert set(cleaned) == {SESSION_2, SESSION_3}
        assert _lock_file(repo, SESSION_1).exists()   # 有効は残る
        assert not _lock_file(repo, SESSION_2).exists()
        assert not _lock_file(repo, SESSION_3).exists()

    def test_no_locks_dir_returns_empty_list(self, tmp_path):
        """locks ディレクトリが存在しない場合は空リストを返す。"""
        repo = str(tmp_path / "repo")
        cleaned = cleanup_expired_locks(repo)
        assert cleaned == []

    def test_all_active_returns_empty_list(self, tmp_path):
        """期限切れのロックがない場合は空リストを返す。"""
        repo = str(tmp_path / "repo")
        _write_lock_raw(repo, SESSION_1, MACHINE_A, delta_minutes=5)
        _write_lock_raw(repo, SESSION_2, MACHINE_B, delta_minutes=3)

        cleaned = cleanup_expired_locks(repo)
        assert cleaned == []


# ---------------------------------------------------------------------------
# テスト 12: renew_locks TTL延長
# ---------------------------------------------------------------------------

class TestRenewLocks:
    def test_renews_own_locks(self, tmp_path):
        """自マシンのロックの TTL が延長される。"""
        repo = str(tmp_path / "repo")
        _write_lock_raw(repo, SESSION_1, MACHINE_A, delta_minutes=1)  # 残り1分
        _write_lock_raw(repo, SESSION_2, MACHINE_A, delta_minutes=1)

        count = renew_locks(repo, MACHINE_A, ttl_minutes=10)
        assert count == 2

        for sid in (SESSION_1, SESSION_2):
            lock_path = _lock_file(repo, sid)
            with lock_path.open() as f:
                data = json.load(f)
            expires_at = datetime.fromisoformat(data["expires_at"].replace("Z", "+00:00"))
            diff = (expires_at - _now_utc()).total_seconds()
            # 残り約10分になっている（±5秒）
            assert 595 <= diff <= 605, f"TTL が想定外: {diff}秒"

    def test_does_not_renew_other_machine_locks(self, tmp_path):
        """他マシンのロックは更新しない。"""
        repo = str(tmp_path / "repo")
        _write_lock_raw(repo, SESSION_1, MACHINE_B, delta_minutes=1)

        lock_path = _lock_file(repo, SESSION_1)
        with lock_path.open() as f:
            before = json.load(f)

        count = renew_locks(repo, MACHINE_A, ttl_minutes=10)
        assert count == 0

        with lock_path.open() as f:
            after = json.load(f)

        assert before["expires_at"] == after["expires_at"]

    def test_no_locks_dir_returns_zero(self, tmp_path):
        """locks ディレクトリが存在しない場合は 0 を返す。"""
        repo = str(tmp_path / "repo")
        count = renew_locks(repo, MACHINE_A)
        assert count == 0


# ---------------------------------------------------------------------------
# テスト 13: acquire_lock の verify_callback
# ---------------------------------------------------------------------------

class TestAcquireLockVerifyCallback:
    def test_acquire_lock_with_verify_callback_success(self, tmp_path):
        """
        verify_callback が True を返す場合、ロック取得は成功し
        ロックファイルが残る。
        """
        repo = str(tmp_path / "repo")
        callback_called = {"count": 0}

        def verify_ok():
            callback_called["count"] += 1
            return True

        result = acquire_lock(repo, SESSION_1, MACHINE_A, verify_callback=verify_ok)

        assert result is True
        assert callback_called["count"] == 1
        # ロックファイルが存在している
        assert _lock_file(repo, SESSION_1).exists()

    def test_acquire_lock_with_verify_callback_failure(self, tmp_path):
        """
        verify_callback が False を返す場合、ロック取得は失敗し
        ロックファイルが削除される。
        """
        repo = str(tmp_path / "repo")

        def verify_fail():
            return False

        result = acquire_lock(repo, SESSION_1, MACHINE_A, verify_callback=verify_fail)

        assert result is False
        # ロックファイルは削除されている
        assert not _lock_file(repo, SESSION_1).exists()

    def test_acquire_lock_without_callback_unchanged(self, tmp_path):
        """
        verify_callback を指定しない（None）場合、従来通りの動作をする。
        ロック取得が成功し、ロックファイルが作成される。
        """
        repo = str(tmp_path / "repo")

        result = acquire_lock(repo, SESSION_1, MACHINE_A)

        assert result is True
        lock_path = _lock_file(repo, SESSION_1)
        assert lock_path.exists()
        import json
        with lock_path.open() as f:
            data = json.load(f)
        assert data["machine_id"] == MACHINE_A
