# blinear

A lightweight bilinear neural network library.

## Install
```bash
pip install blinear