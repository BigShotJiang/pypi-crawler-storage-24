from setuptools import setup, find_packages

setup(
    name="blinear",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "torch",
        "numpy"
    ],
    author="Your Name",
    description="Bilinear Neural Network Library",
    python_requires=">=3.8",
)