"""Tests for Mistral OCR package."""
