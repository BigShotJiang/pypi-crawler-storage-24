# TinySDK

Shared service clients for the TinyAI microservices platform — MongoDB, MinIO, RabbitMQ, and structured logging with a consistent interface.

## Installation

```bash
pip install tinysdk
```

## Quick Start

```python
from tinysdk import TinyDBService, TinyStorageService, TinyMessageService, TinyMessageServiceSync, TinyLogger

# MongoDB
db = TinyDBService()
doc_id = db.create("users", {"name": "John", "email": "john@example.com"})
users  = db.read("users", filter={"name": "John"})
count  = db.update("users", {"name": "John"}, {"$set": {"active": True}})
count  = db.delete("users", {"name": "John"})
exists = db.exists("users", {"email": "john@example.com"})
ids    = db.create_multiple("users", [{"name": "Alice"}, {"name": "Bob"}])
db.close()

# MinIO / S3
storage = TinyStorageService()
storage.upload_file("my-bucket", "file.txt", buffer)          # file_size auto-detected
storage.upload_file("my-bucket", "file.txt", buffer, 1024)    # or pass explicitly
file_buffer, name = storage.download_file("my-bucket", "file.txt")
storage.upload_folder("my-bucket", "/local/folder")
storage.download_folder("my-bucket", "folder-name", "/local/dest")
storage.close()

# RabbitMQ (async, event-driven)
def handler(msg: dict):
    print(msg)

svc = TinyMessageService(queue_settings=[("my-queue", handler)])
svc.publish("my-queue", {"task": "run"})
svc.run()  # blocks, starts IOLoop

# RabbitMQ (sync, blocking)
with TinyMessageServiceSync() as svc:
    svc.publish("my-queue", {"task": "run"})

# Logger
logger = TinyLogger()
logger.log("something happened", level="INFO", context={"key": "value"})
logger.start_heartbeat()   # emits periodic HEARTBEAT events
logger.stop_heartbeat()    # clean shutdown

doc_logger = logger.for_document("doc-id-123")
doc_logger.log("processing started")
```

## Configuration

All clients read credentials from environment variables.

| Service | Variable | Example |
|---------|----------|---------|
| MongoDB | `DB_LINK` | `mongodb://mongo:27017` |
| MongoDB | `DB_NAME` | `tinyDatabase` |
| MinIO | `MINIO_ENDPOINT` | `minio:9000` |
| MinIO | `MINIO_ACCESSKEY` | `minioadmin` |
| MinIO | `MINIO_SECRETKEY` | `minioadmin` |
| RabbitMQ | `RABBITMQ_HOST` | `rabbitmq` |
| RabbitMQ | `RABBITMQ_PORT` | `5672` |
| RabbitMQ | `RABBITMQ_USER` | `guest` |
| RabbitMQ | `RABBITMQ_PASS` | `guest` |
| Logger | `SERVICE_NAME` | `my-service` |
| Logger | `CLUSTER` | `prod` |
| Logger | `NAMESPACE` | `default` |
| Logger | `LOG_LEVEL` | `INFO` |
| Logger | `HEARTBEAT_INTERVAL` | `30` |

Credentials can also be passed directly as constructor arguments.

## License

MIT
