from dataclasses import dataclass, field, asdict
from typing import Any, Dict

from tinysdk.utils import get_date


@dataclass(frozen=True)
class LogEvent:
  service: str
  instance: str
  cluster: str
  namespace: str
  level: str
  event_type: str
  message: str
  context: Dict[str, Any] = field(default_factory=dict)
  document_id: str = ""
  error: str = ""
  timestamp: str = field(default_factory=get_date)

  def to_dict(self) -> Dict[str, Any]:
    return asdict(self)
