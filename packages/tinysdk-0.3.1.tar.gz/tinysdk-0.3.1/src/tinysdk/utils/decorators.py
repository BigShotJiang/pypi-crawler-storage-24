"""Decorators for error handling and retry logic.

This module provides decorators used throughout TinySDK for logging exceptions,
implementing retry mechanisms with exponential backoff and jitter, and
suppressing exceptions with a default return value.

Example:
  Using exception_logger::

    from tinysdk.utils import exception_logger

    @exception_logger
    def risky_operation():
        # Automatically logs exceptions before re-raising
        return 1 / 0

  Using retry decorator::

    from tinysdk.utils import retry
    from pika.exceptions import AMQPConnectionError

    @retry(exceptions=(AMQPConnectionError,), tries=5, delay=5, backoff=2)
    def connect_to_rabbitmq():
        # Retries up to 5 times with exponential backoff
        pass

  Using suppress_raise::

    from tinysdk.utils import suppress_raise

    @suppress_raise(default="")
    def maybe_fails():
        return risky_call()
"""

import random
import time
from functools import wraps
from typing import Any, Callable, Optional, Tuple, Type


def exception_logger(func: Callable[..., Any]) -> Callable[..., Any]:
  """Decorator that logs exceptions before re-raising them.

  Uses the instance's TinyLogger (self.logger) when available, otherwise
  creates a temporary one. The lazy import avoids a circular import between
  decorators.py and tinylogger.py.

  Args:
    func (Callable): The function to wrap

  Returns:
    Callable: Wrapped function with exception logging

  Example:
    >>> @exception_logger
    ... def my_function():
    ...     raise ValueError("Something went wrong")
    >>> my_function()  # Logs error and re-raises
  """

  @wraps(func)
  def wrapper(*args: Any, **kwargs: Any) -> Any:
    try:
      return func(*args, **kwargs)
    except Exception as e:
      # Lazy import avoids circular: decorators → tinylogger → utils → decorators
      from tinysdk.tinylogger import TinyLogger

      _logger = getattr(args[0], "logger", None) if args else None
      if not isinstance(_logger, TinyLogger):
        _logger = TinyLogger()
      _logger.log(f"Error in {func.__name__}: {str(e)}", level="ERROR", error=e)
      raise

  return wrapper


def retry(
  exceptions: Tuple[Type[BaseException], ...] = (Exception,),
  tries: int = 5,
  delay: int = 5,
  backoff: int = 1,
  jitter: Tuple[int, int] = (1, 3),
  logger: Optional[Any] = None,
) -> Callable:
  """Decorator that retries a function with exponential backoff and jitter.

  Implements a retry mechanism with configurable exponential backoff and random
  jitter to prevent thundering herd problems. The function is retried on specified
  exception types up to a maximum number of attempts.

  Args:
    exceptions (Tuple[type, ...]): Tuple of exception types to catch and retry on.
      Defaults to (Exception,).
    tries (int): Maximum number of retry attempts. Defaults to 5.
    delay (int): Initial delay in seconds before first retry. Defaults to 5.
    backoff (int): Exponential backoff multiplier. Delay is multiplied by
      (backoff ** attempt) for each retry. Defaults to 1 (no backoff).
    jitter (Tuple[int, int]): Random jitter range (min, max) in seconds to add
      to each delay. Helps prevent synchronized retries. Defaults to (1, 3).
    logger (TinyLogger, optional): TinyLogger instance for retry warnings and errors.

  Returns:
    Callable: Decorator function

  Raises:
    Exception: Raises "Maximum retries exceeded" if all retry attempts fail

  Example:
    >>> from pika.exceptions import AMQPConnectionError
    >>> @retry(exceptions=(AMQPConnectionError,), tries=5, delay=2, backoff=2)
    ... def connect():
    ...     # Will retry up to 5 times with 2s, 4s, 8s, 16s, 32s delays (+ jitter)
    ...     pass
  """

  def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
    @wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
      attempt = 0
      while attempt < tries:
        try:
          return func(*args, **kwargs)
        except exceptions as e:
          attempt += 1
          if logger:
            logger.log(f"Attempt {attempt} failed with exception: {str(e)}", level="WARNING")
          sleep_time = delay * (backoff**attempt) + random.uniform(float(jitter[0]), float(jitter[1]))
          time.sleep(sleep_time)
      if logger:
        logger.log("Exceeded maximum number of connection retries.", level="ERROR")
      raise Exception("Maximum retries exceeded")

    return wrapper

  return decorator


def suppress_raise(default: Any = None) -> Callable[..., Any]:
  """Decorator that suppresses all exceptions, returning a default value instead.

  Args:
    default: Value to return when an exception is raised. Defaults to None.

  Returns:
    Callable: Decorator function

  Example:
    >>> @suppress_raise(default="")
    ... def risky():
    ...     raise ValueError("oops")
    >>> risky()
    ''
  """

  def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
    @wraps(fn)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
      try:
        return fn(*args, **kwargs)
      except Exception:
        return default

    return wrapper

  return decorator
