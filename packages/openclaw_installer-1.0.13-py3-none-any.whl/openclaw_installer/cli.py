"""CLI interface using Typer."""

from pathlib import Path
from typing import Optional

import typer
from rich import print as rprint

from .config import Config, generate_example_config
from .installer import OpenClawInstaller as Installer

app = typer.Typer(help="Zero-config installer for OpenClaw AI assistant")


# Import automation after app is defined to avoid circular imports
def _run_auto_login(browser_path: Optional[str] = None):
    """Run auto-login automation."""
    try:
        from .automation.auto_login import auto_login
        return auto_login(browser_path)
    except ImportError:
        # Fallback to direct import if automation module not installed
        import sys
        automation_path = Path(__file__).parent / "automation"
        sys.path.insert(0, str(automation_path))
        from auto_login import auto_login
        return auto_login(browser_path)


@app.command()
def install(
    config: Path = typer.Option(..., "--config", "-c", help="Path to YAML config file"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Simulate without making changes"),
):
    """Install OpenClaw from configuration file."""
    if not config.exists():
        rprint(f"[red]Config file not found: {config}[/]")
        raise typer.Exit(1)

    cfg = Config.from_yaml(config)
    installer = Installer(cfg, dry_run=dry_run)

    success = installer.install()
    raise typer.Exit(0 if success else 1)


@app.command()
def generate_config(
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Output file (default: stdout)"),
):
    """Generate example configuration file."""
    example = generate_example_config()

    if output:
        output.write_text(example)
        rprint(f"[green]Example config written to {output}[/]")
    else:
        print(example)


@app.command()
def uninstall(
    dry_run: bool = typer.Option(False, "--dry-run", help="Simulate without making changes"),
):
    """Uninstall OpenClaw."""
    installer = Installer(Config(version="latest"), dry_run=dry_run)
    success = installer.uninstall()
    raise typer.Exit(0 if success else 1)


@app.command()
def dashboard(
    auto_login: bool = typer.Option(True, "--auto-login/--no-auto-login", help="Auto-login without user interaction"),
    browser: Optional[str] = typer.Option(None, "--browser", "-b", help="Path to browser executable"),
):
    """Open OpenClaw dashboard with automatic login."""
    if auto_login:
        success = _run_auto_login(browser)
        raise typer.Exit(0 if success else 1)
    else:
        # Just run the standard openclaw dashboard command
        import subprocess
        import sys
        
        if sys.platform == "win32":
            wrapper = Path.home() / "bin" / "openclaw.cmd"
        else:
            wrapper = Path.home() / ".local" / "bin" / "openclaw"
        
        if not wrapper.exists():
            rprint("[red]OpenClaw not installed. Run: openclaw-installer install --config <config.yaml>[/]")
            raise typer.Exit(1)
        
        subprocess.run([str(wrapper), "dashboard"])


@app.command(name="auto-login")
def auto_login_cmd(
    browser: Optional[str] = typer.Option(None, "--browser", "-b", help="Path to browser executable"),
):
    """Automatically login to OpenClaw dashboard (follows 'How to connect' steps)."""
    rprint("[bold blue]OpenClaw Auto-Login[/]")
    rprint("Following the 'How to connect' steps from the dashboard...")
    rprint("")
    
    success = _run_auto_login(browser)
    raise typer.Exit(0 if success else 1)


def main():
    app()


if __name__ == "__main__":
    main()
