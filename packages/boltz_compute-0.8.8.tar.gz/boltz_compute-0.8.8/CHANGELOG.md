# Changelog

## 0.8.8 (2026-03-08)

Full Changelog: [v0.8.7...v0.8.8](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.8.7...v0.8.8)

### Chores

* **ci:** skip uploading artifacts on stainless-internal branches ([5a40f5a](https://github.com/boltz-bio/boltz-compute-api-python/commit/5a40f5a0b299b6c5a81b306076c6c01fbbe0807c))

## 0.8.7 (2026-03-05)

Full Changelog: [v0.8.6...v0.8.7](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.8.6...v0.8.7)

### Bug Fixes

* **compute-api:** rename model boltz-2 to boltz-2.1, update versions ([2ce7ccd](https://github.com/boltz-bio/boltz-compute-api-python/commit/2ce7ccd61d5a05166ef56ccb59fc2567ff4afc03))

## 0.8.6 (2026-03-04)

Full Changelog: [v0.8.5...v0.8.6](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.8.5...v0.8.6)

### Chores

* update SDK settings ([bcbe97d](https://github.com/boltz-bio/boltz-compute-api-python/commit/bcbe97dde59f55efccd2fb9db78a8ac8be79ee40))

## 0.8.5 (2026-03-04)

Full Changelog: [v0.8.4...v0.8.5](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.8.4...v0.8.5)

### Chores

* **internal:** refactor authentication internals ([b0e2781](https://github.com/boltz-bio/boltz-compute-api-python/commit/b0e27813da54fc203fed4ea5198fa84b2177e723))

## 0.8.4 (2026-03-04)

Full Changelog: [v0.8.3...v0.8.4](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.8.3...v0.8.4)

### Chores

* enable PyPI publishing for Python SDK ([4a0876a](https://github.com/boltz-bio/boltz-compute-api-python/commit/4a0876ac44571984c67b7462980c974c61d7289b))

## 0.8.3 (2026-03-04)

Full Changelog: [v0.8.2...v0.8.3](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.8.2...v0.8.3)

### Chores

* rename SDK packages from boltz-compute-api to boltz-compute ([737e90f](https://github.com/boltz-bio/boltz-compute-api-python/commit/737e90fa3030fba407bddde9c93d5c2a4c92d3b4))
* update Stainless production URL to api.boltz.bio ([34c8263](https://github.com/boltz-bio/boltz-compute-api-python/commit/34c8263868fcc38f992a60d9001427b964b9e447))

## 0.8.2 (2026-03-04)

Full Changelog: [v0.8.1...v0.8.2](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.8.1...v0.8.2)

### Chores

* update SDK settings ([6a1ac8e](https://github.com/boltz-bio/boltz-compute-api-python/commit/6a1ac8e2e239906e0059aaad65336559d9c1dc99))

## 0.8.1 (2026-03-04)

Full Changelog: [v0.8.0...v0.8.1](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.8.0...v0.8.1)

### Chores

* update SDK settings ([4761a9e](https://github.com/boltz-bio/boltz-compute-api-python/commit/4761a9eca35b1343a5b60ea83940b3edd46e39ad))

## 0.8.0 (2026-02-28)

Full Changelog: [v0.7.0...v0.8.0](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.7.0...v0.8.0)

### Features

* **compute-api:** improve prediction response shape ([da937d1](https://github.com/boltz-bio/boltz-compute-api-python/commit/da937d12dbcf145a764191aa9116593fa9bccde0))

## 0.7.0 (2026-02-27)

Full Changelog: [v0.6.1...v0.7.0](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.6.1...v0.7.0)

### Features

* **compute-api:** add usage API and estimate-cost endpoints ([22778f3](https://github.com/boltz-bio/boltz-compute-api-python/commit/22778f36a795c678e21aca12c762b3c9a19811ee))
* **compute-api:** extract prediction & pipeline payloads into separate tables ([bdf3fbe](https://github.com/boltz-bio/boltz-compute-api-python/commit/bdf3fbe2d471cd9e5098596dc563df9d6868a5f2))


### Chores

* **ci:** bump uv version ([3a6b4b8](https://github.com/boltz-bio/boltz-compute-api-python/commit/3a6b4b8f963e04aaffc34b0ddc2184793eb592fd))
* **internal:** make `test_proxy_environment_variables` more resilient to env ([cd0e306](https://github.com/boltz-bio/boltz-compute-api-python/commit/cd0e306539007e7f9fbfb5982aaf1531a849e2cb))

## 0.6.1 (2026-02-24)

Full Changelog: [v0.6.0...v0.6.1](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.6.0...v0.6.1)

### Chores

* **internal:** add request options to SSE classes ([9264b0b](https://github.com/boltz-bio/boltz-compute-api-python/commit/9264b0bd935d987b576ab4d69fc69d28bb5c3b20))
* **internal:** make `test_proxy_environment_variables` more resilient ([3e6ebe0](https://github.com/boltz-bio/boltz-compute-api-python/commit/3e6ebe054a4ffac81af7f951d1d2ebbe4f917a71))

## 0.6.0 (2026-02-23)

Full Changelog: [v0.5.0...v0.6.0](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.5.0...v0.6.0)

### Features

* **compute-api:** improve OpenAPI specs for SDK generation ([d3bb19e](https://github.com/boltz-bio/boltz-compute-api-python/commit/d3bb19e0906e0ccdfe2ab86bb7144999afcc8a73))
* **compute-api:** schema improvements — model renames, index optimization, cascade rules ([c071ca1](https://github.com/boltz-bio/boltz-compute-api-python/commit/c071ca16e04853f9329ecb8d0f6cb3dad9733aa2))

## 0.5.0 (2026-02-20)

Full Changelog: [v0.4.0...v0.5.0](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.4.0...v0.5.0)

### Features

* **compute-api:** ECR repository, CI/CD pipeline, and app code ([785c856](https://github.com/boltz-bio/boltz-compute-api-python/commit/785c856cbcdccf309d7bc5af3bff9617db4c59b0))
* **compute-api:** permission system, ApiError class, HMAC-SHA256 keys ([9c681de](https://github.com/boltz-bio/boltz-compute-api-python/commit/9c681de9b1ce305b47b463f0943394fc9a72b9bd))
* **compute-api:** rename key type compute→workspace, visible default workspace ([d10c12a](https://github.com/boltz-bio/boltz-compute-api-python/commit/d10c12afe1492124cb4a39e15c0482f128fc0783))
* **compute-api:** test mode with Stripe-style livemode pattern ([42f9141](https://github.com/boltz-bio/boltz-compute-api-python/commit/42f914124acd79c0cb967db8731f4fc414786094))


### Chores

* **internal:** remove mock server code ([4ce146d](https://github.com/boltz-bio/boltz-compute-api-python/commit/4ce146d61264d563735d5ebda631b3cf0b7e33ff))
* remove custom code ([0690903](https://github.com/boltz-bio/boltz-compute-api-python/commit/0690903967f7d59cdbd3c6801687fa71bc8ec02d))
* update mock server docs ([b9a4c80](https://github.com/boltz-bio/boltz-compute-api-python/commit/b9a4c800c038503fd151376f9edd0191196b30be))


### Refactors

* **compute-api:** auth + DB→API transform layer with repository pattern ([6848185](https://github.com/boltz-bio/boltz-compute-api-python/commit/6848185eb08736349247d640624c2bb89bfa8836))

## 0.4.0 (2026-02-13)

Full Changelog: [v0.3.0...v0.4.0](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.3.0...v0.4.0)

### Features

* **compute-api:** refine workspace model + wire workspace_id into compute schemas ([2baeba6](https://github.com/boltz-bio/boltz-compute-api-python/commit/2baeba64eb78200c6045f784f18f5de64cb890f7))


### Chores

* **compute-api:** improve Stainless SDK naming, ordering, and docs ([e32730c](https://github.com/boltz-bio/boltz-compute-api-python/commit/e32730c2fcbf125f1bf378083e54ef2897826a7d))
* format all `api.md` files ([60b8ae5](https://github.com/boltz-bio/boltz-compute-api-python/commit/60b8ae5610254f72e61be4785508a734f70c5cba))


### Refactors

* **compute-api:** restructure API types to 2-file-per-workflow pattern ([8d6ebe0](https://github.com/boltz-bio/boltz-compute-api-python/commit/8d6ebe0a11434fd9265db7f1fb66d2e4656dcbeb))

## 0.3.0 (2026-02-12)

Full Changelog: [v0.2.1...v0.3.0](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.2.1...v0.3.0)

### Features

* **compute-api:** separate input/response schemas and refine API types ([bc2e3f8](https://github.com/boltz-bio/boltz-compute-api-python/commit/bc2e3f8142f973688ce0d2b7b5946c2b90975dc0))

## 0.2.1 (2026-02-12)

Full Changelog: [v0.2.0...v0.2.1](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.2.0...v0.2.1)

### Bug Fixes

* **compute-api:** update Stainless config for health check and admin API ([d0ccc8f](https://github.com/boltz-bio/boltz-compute-api-python/commit/d0ccc8f08e99f6476b3de4ecdb64b95d18b7465a))


### Chores

* **internal:** fix lint error on Python 3.14 ([6506bb2](https://github.com/boltz-bio/boltz-compute-api-python/commit/6506bb2749cff7e309d5a6110cc9c3d47684438f))

## 0.2.0 (2026-02-12)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.1.0...v0.2.0)

### Features

* **compute-api:** admin API, internal provisioning & auth enforcement ([1fbf75b](https://github.com/boltz-bio/boltz-compute-api-python/commit/1fbf75b4659973229292da5ef7baafdb72c4842a))


### Chores

* **compute-api:** add Stainless pagination config and OpenAPI examples ([19fe01a](https://github.com/boltz-bio/boltz-compute-api-python/commit/19fe01a868605f1bb585478168e93e018826b3bd))

## 0.1.0 (2026-02-11)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.0.1...v0.1.0)

### Features

* **compute-api:** add prediction stub routes and share schema compiler ([bb56e56](https://github.com/boltz-bio/boltz-compute-api-python/commit/bb56e566cdd532e6e0ce8f32dd90c5a1e6b3adf1))


### Chores

* **compute-api:** configure Stainless SDK/docs and unify error schema ([a66b30a](https://github.com/boltz-bio/boltz-compute-api-python/commit/a66b30aa83d9f24c5291c05fecd004edd735c13f))
* update SDK settings ([1941f7c](https://github.com/boltz-bio/boltz-compute-api-python/commit/1941f7c17ec69bbd4f84baff0a9b0b4fa507bcb9))
* update SDK settings ([83f6091](https://github.com/boltz-bio/boltz-compute-api-python/commit/83f60913210cc981dc9e6b7645b6cbc7a4eadc78))
