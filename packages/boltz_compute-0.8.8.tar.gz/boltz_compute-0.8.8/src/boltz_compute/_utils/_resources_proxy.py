from __future__ import annotations

from typing import Any
from typing_extensions import override

from ._proxy import LazyProxy


class ResourcesProxy(LazyProxy[Any]):
    """A proxy for the `boltz_compute.resources` module.

    This is used so that we can lazily import `boltz_compute.resources` only when
    needed *and* so that users can just import `boltz_compute` and reference `boltz_compute.resources`
    """

    @override
    def __load__(self) -> Any:
        import importlib

        mod = importlib.import_module("boltz_compute.resources")
        return mod


resources = ResourcesProxy().__as_proxied__()
