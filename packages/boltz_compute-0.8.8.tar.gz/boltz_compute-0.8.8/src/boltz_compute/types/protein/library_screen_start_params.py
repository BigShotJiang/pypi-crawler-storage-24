# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Iterable
from typing_extensions import Literal, Required, TypeAlias, TypedDict

from ..._types import SequenceNotStr

__all__ = [
    "LibraryScreenStartParams",
    "Protein",
    "ProteinEntity",
    "ProteinEntityProteinEntity",
    "ProteinEntityProteinEntityModification",
    "ProteinEntityProteinEntityModificationCcdModification",
    "ProteinEntityProteinEntityModificationSmilesModification",
    "ProteinEntityRnaEntity",
    "ProteinEntityRnaEntityModification",
    "ProteinEntityRnaEntityModificationCcdModification",
    "ProteinEntityRnaEntityModificationSmilesModification",
    "ProteinEntityDnaEntity",
    "ProteinEntityDnaEntityModification",
    "ProteinEntityDnaEntityModificationCcdModification",
    "ProteinEntityDnaEntityModificationSmilesModification",
    "ProteinEntityLigandCcdEntity",
    "ProteinEntityLigandSmilesEntity",
    "Target",
    "TargetStructureTemplateTarget",
    "TargetStructureTemplateTargetChainSelection",
    "TargetStructureTemplateTargetStructure",
    "TargetStructureTemplateTargetStructureURLSource",
    "TargetStructureTemplateTargetStructureCifBase64Source",
    "TargetNoTemplateTarget",
    "TargetNoTemplateTargetEntity",
    "TargetNoTemplateTargetEntityProteinEntity",
    "TargetNoTemplateTargetEntityProteinEntityModification",
    "TargetNoTemplateTargetEntityProteinEntityModificationCcdModification",
    "TargetNoTemplateTargetEntityProteinEntityModificationSmilesModification",
    "TargetNoTemplateTargetEntityRnaEntity",
    "TargetNoTemplateTargetEntityRnaEntityModification",
    "TargetNoTemplateTargetEntityRnaEntityModificationCcdModification",
    "TargetNoTemplateTargetEntityRnaEntityModificationSmilesModification",
    "TargetNoTemplateTargetEntityDnaEntity",
    "TargetNoTemplateTargetEntityDnaEntityModification",
    "TargetNoTemplateTargetEntityDnaEntityModificationCcdModification",
    "TargetNoTemplateTargetEntityDnaEntityModificationSmilesModification",
    "TargetNoTemplateTargetEntityLigandCcdEntity",
    "TargetNoTemplateTargetEntityLigandSmilesEntity",
    "TargetNoTemplateTargetBond",
    "TargetNoTemplateTargetBondAtom1",
    "TargetNoTemplateTargetBondAtom1LigandAtom",
    "TargetNoTemplateTargetBondAtom1PolymerAtom",
    "TargetNoTemplateTargetBondAtom2",
    "TargetNoTemplateTargetBondAtom2LigandAtom",
    "TargetNoTemplateTargetBondAtom2PolymerAtom",
    "TargetNoTemplateTargetConstraint",
    "TargetNoTemplateTargetConstraintPocketConstraint",
    "TargetNoTemplateTargetConstraintContactConstraint",
    "TargetNoTemplateTargetConstraintContactConstraintToken1",
    "TargetNoTemplateTargetConstraintContactConstraintToken1PolymerContactToken",
    "TargetNoTemplateTargetConstraintContactConstraintToken1LigandContactToken",
    "TargetNoTemplateTargetConstraintContactConstraintToken2",
    "TargetNoTemplateTargetConstraintContactConstraintToken2PolymerContactToken",
    "TargetNoTemplateTargetConstraintContactConstraintToken2LigandContactToken",
]


class LibraryScreenStartParams(TypedDict, total=False):
    proteins: Required[Iterable[Protein]]
    """List of protein entries to screen."""

    target: Required[Target]
    """Target specification (structure template or template-free)"""

    idempotency_key: str
    """Client-provided key to prevent duplicate submissions on retries"""

    workspace_id: str
    """Target workspace ID (admin keys only; ignored for workspace keys)"""


class ProteinEntityProteinEntityModificationCcdModification(TypedDict, total=False):
    residue_index: Required[int]
    """0-based index of the residue to modify"""

    type: Required[Literal["ccd"]]

    value: Required[str]
    """CCD code from RCSB PDB (e.g.

    'MSE' for selenomethionine, 'SEP' for phosphoserine)
    """


class ProteinEntityProteinEntityModificationSmilesModification(TypedDict, total=False):
    residue_index: Required[int]
    """0-based index of the residue to modify"""

    type: Required[Literal["smiles"]]

    value: Required[str]
    """SMILES string for the modification"""


ProteinEntityProteinEntityModification: TypeAlias = Union[
    ProteinEntityProteinEntityModificationCcdModification, ProteinEntityProteinEntityModificationSmilesModification
]


class ProteinEntityProteinEntity(TypedDict, total=False):
    chain_ids: Required[SequenceNotStr[str]]
    """Chain IDs for this entity"""

    modifications: Required[Iterable[ProteinEntityProteinEntityModification]]
    """Post-translational modifications"""

    type: Required[Literal["protein"]]

    value: Required[str]
    """Amino acid sequence (one-letter codes)"""

    cyclic: bool
    """Whether the sequence is cyclic"""


class ProteinEntityRnaEntityModificationCcdModification(TypedDict, total=False):
    residue_index: Required[int]
    """0-based index of the residue to modify"""

    type: Required[Literal["ccd"]]

    value: Required[str]
    """CCD code from RCSB PDB (e.g.

    'MSE' for selenomethionine, 'SEP' for phosphoserine)
    """


class ProteinEntityRnaEntityModificationSmilesModification(TypedDict, total=False):
    residue_index: Required[int]
    """0-based index of the residue to modify"""

    type: Required[Literal["smiles"]]

    value: Required[str]
    """SMILES string for the modification"""


ProteinEntityRnaEntityModification: TypeAlias = Union[
    ProteinEntityRnaEntityModificationCcdModification, ProteinEntityRnaEntityModificationSmilesModification
]


class ProteinEntityRnaEntity(TypedDict, total=False):
    chain_ids: Required[SequenceNotStr[str]]
    """Chain IDs for this entity"""

    modifications: Required[Iterable[ProteinEntityRnaEntityModification]]
    """Chemical modifications"""

    type: Required[Literal["rna"]]

    value: Required[str]
    """RNA nucleotide sequence (A, C, G, U, N)"""

    cyclic: bool
    """Whether the sequence is cyclic"""


class ProteinEntityDnaEntityModificationCcdModification(TypedDict, total=False):
    residue_index: Required[int]
    """0-based index of the residue to modify"""

    type: Required[Literal["ccd"]]

    value: Required[str]
    """CCD code from RCSB PDB (e.g.

    'MSE' for selenomethionine, 'SEP' for phosphoserine)
    """


class ProteinEntityDnaEntityModificationSmilesModification(TypedDict, total=False):
    residue_index: Required[int]
    """0-based index of the residue to modify"""

    type: Required[Literal["smiles"]]

    value: Required[str]
    """SMILES string for the modification"""


ProteinEntityDnaEntityModification: TypeAlias = Union[
    ProteinEntityDnaEntityModificationCcdModification, ProteinEntityDnaEntityModificationSmilesModification
]


class ProteinEntityDnaEntity(TypedDict, total=False):
    chain_ids: Required[SequenceNotStr[str]]
    """Chain IDs for this entity"""

    modifications: Required[Iterable[ProteinEntityDnaEntityModification]]
    """Chemical modifications"""

    type: Required[Literal["dna"]]

    value: Required[str]
    """DNA nucleotide sequence (A, C, G, T, N)"""

    cyclic: bool
    """Whether the sequence is cyclic"""


class ProteinEntityLigandCcdEntity(TypedDict, total=False):
    chain_ids: Required[SequenceNotStr[str]]
    """Chain IDs for this ligand"""

    type: Required[Literal["ligand_ccd"]]

    value: Required[str]
    """CCD code (e.g., ATP, ADP)"""


class ProteinEntityLigandSmilesEntity(TypedDict, total=False):
    chain_ids: Required[SequenceNotStr[str]]
    """Chain IDs for this ligand"""

    type: Required[Literal["ligand_smiles"]]

    value: Required[str]
    """SMILES string representing the ligand"""


ProteinEntity: TypeAlias = Union[
    ProteinEntityProteinEntity,
    ProteinEntityRnaEntity,
    ProteinEntityDnaEntity,
    ProteinEntityLigandCcdEntity,
    ProteinEntityLigandSmilesEntity,
]


class Protein(TypedDict, total=False):
    """A protein screen entry with entities and optional ID"""

    entities: Required[Iterable[ProteinEntity]]
    """Entities that make up this protein complex"""

    id: str
    """Optional client-provided identifier for this entry"""


class TargetStructureTemplateTargetChainSelection(TypedDict, total=False):
    """Per-chain specification for a structure template target."""

    crop_residues: Required[Union[Iterable[int], Literal["all"]]]
    """
    0-indexed residue indices to retain from this chain, or 'all' to keep all
    residues. Residues not listed are excluded from the engine run.
    """

    epitope_residues: Iterable[int]
    """0-indexed residue indices where binder contact is desired (the epitope).

    All indices must be present in crop_residues.
    """

    flexible_residues: Iterable[int]
    """0-indexed residue indices allowed to move during design (e.g.

    flexible loop regions). All indices must be present in crop_residues.
    """


class TargetStructureTemplateTargetStructureURLSource(TypedDict, total=False):
    type: Required[Literal["url"]]

    url: Required[str]


class TargetStructureTemplateTargetStructureCifBase64Source(TypedDict, total=False):
    data: Required[str]
    """Base64-encoded CIF file contents"""

    media_type: Required[Literal["chemical/x-cif"]]
    """Must be chemical/x-cif for CIF files"""

    type: Required[Literal["base64"]]


TargetStructureTemplateTargetStructure: TypeAlias = Union[
    TargetStructureTemplateTargetStructureURLSource, TargetStructureTemplateTargetStructureCifBase64Source
]


class TargetStructureTemplateTarget(TypedDict, total=False):
    """Target defined by an uploaded 3D structure (CIF or PDB file).

    Only chains included in chain_selection are used.
    """

    chain_selection: Required[Dict[str, TargetStructureTemplateTargetChainSelection]]
    """Chains selected from the uploaded structure, keyed by chain ID.

    Only chains listed here are included in the engine run — any chains omitted from
    this mapping are ignored. Each value defines which residues to keep, which are
    epitope residues, and which are flexible.
    """

    structure: Required[TargetStructureTemplateTargetStructure]
    """How to provide a CIF structure file.

    URLs are auto-detected; base64 uploads must use chemical/x-cif media type.
    """

    type: Required[Literal["structure_template"]]


class TargetNoTemplateTargetEntityProteinEntityModificationCcdModification(TypedDict, total=False):
    residue_index: Required[int]
    """0-based index of the residue to modify"""

    type: Required[Literal["ccd"]]

    value: Required[str]
    """CCD code from RCSB PDB (e.g.

    'MSE' for selenomethionine, 'SEP' for phosphoserine)
    """


class TargetNoTemplateTargetEntityProteinEntityModificationSmilesModification(TypedDict, total=False):
    residue_index: Required[int]
    """0-based index of the residue to modify"""

    type: Required[Literal["smiles"]]

    value: Required[str]
    """SMILES string for the modification"""


TargetNoTemplateTargetEntityProteinEntityModification: TypeAlias = Union[
    TargetNoTemplateTargetEntityProteinEntityModificationCcdModification,
    TargetNoTemplateTargetEntityProteinEntityModificationSmilesModification,
]


class TargetNoTemplateTargetEntityProteinEntity(TypedDict, total=False):
    chain_ids: Required[SequenceNotStr[str]]
    """Chain IDs for this entity"""

    modifications: Required[Iterable[TargetNoTemplateTargetEntityProteinEntityModification]]
    """Post-translational modifications"""

    type: Required[Literal["protein"]]

    value: Required[str]
    """Amino acid sequence (one-letter codes)"""

    cyclic: bool
    """Whether the sequence is cyclic"""


class TargetNoTemplateTargetEntityRnaEntityModificationCcdModification(TypedDict, total=False):
    residue_index: Required[int]
    """0-based index of the residue to modify"""

    type: Required[Literal["ccd"]]

    value: Required[str]
    """CCD code from RCSB PDB (e.g.

    'MSE' for selenomethionine, 'SEP' for phosphoserine)
    """


class TargetNoTemplateTargetEntityRnaEntityModificationSmilesModification(TypedDict, total=False):
    residue_index: Required[int]
    """0-based index of the residue to modify"""

    type: Required[Literal["smiles"]]

    value: Required[str]
    """SMILES string for the modification"""


TargetNoTemplateTargetEntityRnaEntityModification: TypeAlias = Union[
    TargetNoTemplateTargetEntityRnaEntityModificationCcdModification,
    TargetNoTemplateTargetEntityRnaEntityModificationSmilesModification,
]


class TargetNoTemplateTargetEntityRnaEntity(TypedDict, total=False):
    chain_ids: Required[SequenceNotStr[str]]
    """Chain IDs for this entity"""

    modifications: Required[Iterable[TargetNoTemplateTargetEntityRnaEntityModification]]
    """Chemical modifications"""

    type: Required[Literal["rna"]]

    value: Required[str]
    """RNA nucleotide sequence (A, C, G, U, N)"""

    cyclic: bool
    """Whether the sequence is cyclic"""


class TargetNoTemplateTargetEntityDnaEntityModificationCcdModification(TypedDict, total=False):
    residue_index: Required[int]
    """0-based index of the residue to modify"""

    type: Required[Literal["ccd"]]

    value: Required[str]
    """CCD code from RCSB PDB (e.g.

    'MSE' for selenomethionine, 'SEP' for phosphoserine)
    """


class TargetNoTemplateTargetEntityDnaEntityModificationSmilesModification(TypedDict, total=False):
    residue_index: Required[int]
    """0-based index of the residue to modify"""

    type: Required[Literal["smiles"]]

    value: Required[str]
    """SMILES string for the modification"""


TargetNoTemplateTargetEntityDnaEntityModification: TypeAlias = Union[
    TargetNoTemplateTargetEntityDnaEntityModificationCcdModification,
    TargetNoTemplateTargetEntityDnaEntityModificationSmilesModification,
]


class TargetNoTemplateTargetEntityDnaEntity(TypedDict, total=False):
    chain_ids: Required[SequenceNotStr[str]]
    """Chain IDs for this entity"""

    modifications: Required[Iterable[TargetNoTemplateTargetEntityDnaEntityModification]]
    """Chemical modifications"""

    type: Required[Literal["dna"]]

    value: Required[str]
    """DNA nucleotide sequence (A, C, G, T, N)"""

    cyclic: bool
    """Whether the sequence is cyclic"""


class TargetNoTemplateTargetEntityLigandCcdEntity(TypedDict, total=False):
    chain_ids: Required[SequenceNotStr[str]]
    """Chain IDs for this ligand"""

    type: Required[Literal["ligand_ccd"]]

    value: Required[str]
    """CCD code (e.g., ATP, ADP)"""


class TargetNoTemplateTargetEntityLigandSmilesEntity(TypedDict, total=False):
    chain_ids: Required[SequenceNotStr[str]]
    """Chain IDs for this ligand"""

    type: Required[Literal["ligand_smiles"]]

    value: Required[str]
    """SMILES string representing the ligand"""


TargetNoTemplateTargetEntity: TypeAlias = Union[
    TargetNoTemplateTargetEntityProteinEntity,
    TargetNoTemplateTargetEntityRnaEntity,
    TargetNoTemplateTargetEntityDnaEntity,
    TargetNoTemplateTargetEntityLigandCcdEntity,
    TargetNoTemplateTargetEntityLigandSmilesEntity,
]


class TargetNoTemplateTargetBondAtom1LigandAtom(TypedDict, total=False):
    atom_name: Required[str]
    """Standardized atom name (verifiable in CIF file on RCSB)"""

    chain_id: Required[str]
    """Chain ID containing the atom"""

    type: Required[Literal["ligand_atom"]]


class TargetNoTemplateTargetBondAtom1PolymerAtom(TypedDict, total=False):
    atom_name: Required[str]
    """Standardized atom name (verifiable in CIF file on RCSB)"""

    chain_id: Required[str]
    """Chain ID containing the atom"""

    residue_index: Required[int]
    """0-based residue index"""

    type: Required[Literal["polymer_atom"]]


TargetNoTemplateTargetBondAtom1: TypeAlias = Union[
    TargetNoTemplateTargetBondAtom1LigandAtom, TargetNoTemplateTargetBondAtom1PolymerAtom
]


class TargetNoTemplateTargetBondAtom2LigandAtom(TypedDict, total=False):
    atom_name: Required[str]
    """Standardized atom name (verifiable in CIF file on RCSB)"""

    chain_id: Required[str]
    """Chain ID containing the atom"""

    type: Required[Literal["ligand_atom"]]


class TargetNoTemplateTargetBondAtom2PolymerAtom(TypedDict, total=False):
    atom_name: Required[str]
    """Standardized atom name (verifiable in CIF file on RCSB)"""

    chain_id: Required[str]
    """Chain ID containing the atom"""

    residue_index: Required[int]
    """0-based residue index"""

    type: Required[Literal["polymer_atom"]]


TargetNoTemplateTargetBondAtom2: TypeAlias = Union[
    TargetNoTemplateTargetBondAtom2LigandAtom, TargetNoTemplateTargetBondAtom2PolymerAtom
]


class TargetNoTemplateTargetBond(TypedDict, total=False):
    atom1: Required[TargetNoTemplateTargetBondAtom1]

    atom2: Required[TargetNoTemplateTargetBondAtom2]


class TargetNoTemplateTargetConstraintPocketConstraint(TypedDict, total=False):
    """Constrains the binder to interact with specific pocket residues on the target."""

    binder_chain_id: Required[str]
    """Chain ID of the binder molecule"""

    contact_residues: Required[Dict[str, Iterable[int]]]
    """Binding pocket residues keyed by chain ID.

    Each key is a chain ID (e.g. "A") and the value is an array of 0-indexed residue
    indices that define the pocket on that chain.
    """

    max_distance_angstrom: Required[float]
    """Maximum allowed distance in Angstroms between binder and pocket residues.

    Typical range: 4-8 A.
    """

    type: Required[Literal["pocket"]]

    force: bool
    """Whether to force the constraint"""


class TargetNoTemplateTargetConstraintContactConstraintToken1PolymerContactToken(TypedDict, total=False):
    chain_id: Required[str]
    """Chain ID"""

    residue_index: Required[int]
    """0-based residue index"""

    type: Required[Literal["polymer_contact"]]


class TargetNoTemplateTargetConstraintContactConstraintToken1LigandContactToken(TypedDict, total=False):
    atom_name: Required[str]
    """Atom name"""

    chain_id: Required[str]
    """Chain ID"""

    type: Required[Literal["ligand_contact"]]


TargetNoTemplateTargetConstraintContactConstraintToken1: TypeAlias = Union[
    TargetNoTemplateTargetConstraintContactConstraintToken1PolymerContactToken,
    TargetNoTemplateTargetConstraintContactConstraintToken1LigandContactToken,
]


class TargetNoTemplateTargetConstraintContactConstraintToken2PolymerContactToken(TypedDict, total=False):
    chain_id: Required[str]
    """Chain ID"""

    residue_index: Required[int]
    """0-based residue index"""

    type: Required[Literal["polymer_contact"]]


class TargetNoTemplateTargetConstraintContactConstraintToken2LigandContactToken(TypedDict, total=False):
    atom_name: Required[str]
    """Atom name"""

    chain_id: Required[str]
    """Chain ID"""

    type: Required[Literal["ligand_contact"]]


TargetNoTemplateTargetConstraintContactConstraintToken2: TypeAlias = Union[
    TargetNoTemplateTargetConstraintContactConstraintToken2PolymerContactToken,
    TargetNoTemplateTargetConstraintContactConstraintToken2LigandContactToken,
]


class TargetNoTemplateTargetConstraintContactConstraint(TypedDict, total=False):
    max_distance_angstrom: Required[float]
    """Maximum distance in Angstroms"""

    token1: Required[TargetNoTemplateTargetConstraintContactConstraintToken1]

    token2: Required[TargetNoTemplateTargetConstraintContactConstraintToken2]

    type: Required[Literal["contact"]]

    force: bool
    """Whether to force the constraint"""


TargetNoTemplateTargetConstraint: TypeAlias = Union[
    TargetNoTemplateTargetConstraintPocketConstraint, TargetNoTemplateTargetConstraintContactConstraint
]


class TargetNoTemplateTarget(TypedDict, total=False):
    """Target defined by sequences only, without a 3D structure template"""

    entities: Required[Iterable[TargetNoTemplateTargetEntity]]
    """Entities (proteins, RNA, DNA, ligands) defining the target complex."""

    type: Required[Literal["no_template"]]

    bonds: Iterable[TargetNoTemplateTargetBond]
    """Covalent bond constraints between atoms in the target complex."""

    constraints: Iterable[TargetNoTemplateTargetConstraint]
    """Structural constraints (pocket and contact)"""

    epitope_residues: Dict[str, Iterable[int]]
    """Residues where binder contact is desired (the epitope).

    Each key is a chain ID and the value is an array of 0-indexed residue indices.
    All indices must be valid within the corresponding entity sequence.
    """


Target: TypeAlias = Union[TargetStructureTemplateTarget, TargetNoTemplateTarget]
