# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime
from typing_extensions import Literal

from ..._models import BaseModel

__all__ = ["WorkspaceRetrieveResponse", "DataRetention"]


class DataRetention(BaseModel):
    """How long result data is retained before automatic deletion.

    Defaults to 7 days. Maximum retention is 30 days (720 hours).
    """

    unit: Literal["hours", "days"]
    """Time unit for retention duration"""

    value: int
    """Duration value. Maximum retention is 30 days (or 720 hours)."""


class WorkspaceRetrieveResponse(BaseModel):
    id: str
    """Workspace ID"""

    archived_at: Optional[datetime] = None

    created_at: datetime

    data_retention: DataRetention
    """How long result data is retained before automatic deletion.

    Defaults to 7 days. Maximum retention is 30 days (720 hours).
    """

    is_default: bool
    """Whether this is the default workspace"""

    name: Optional[str] = None
    """Workspace name"""

    updated_at: datetime
