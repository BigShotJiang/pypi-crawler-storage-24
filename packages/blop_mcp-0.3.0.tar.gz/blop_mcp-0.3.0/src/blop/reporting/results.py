"""Aggregate run data into structured RunResult report."""
from __future__ import annotations

from blop.schemas import FailureCase

_TERMINAL_RUN_STATUSES = {"completed", "failed", "cancelled", "waiting_auth"}


def _artifact_paths_for_case(case: dict) -> list[str]:
    paths: list[str] = []
    for path in case.get("artifact_paths", []) or []:
        if path and path not in paths:
            paths.append(path)
    trace_path = case.get("trace_path")
    if trace_path and trace_path not in paths:
        paths.append(trace_path)
    return paths


def _extract_observed_assertions(case: dict) -> list[str]:
    observed: list[str] = []
    for result in case.get("assertion_results", []) or []:
        if not result.get("passed", False):
            continue
        assertion = str(result.get("assertion", "")).strip()
        if assertion and assertion not in observed:
            observed.append(assertion)
    return observed


def _classify_failure_kind(case: dict) -> str:
    failure_class = (case.get("failure_class") or "").strip()
    mapping = {
        "product_bug": "product_regression",
        "test_fragility": "automation_fragility",
        "auth_failure": "auth_session_failure",
        "env_issue": "environment_or_infra",
    }
    return mapping.get(failure_class, "unknown")


def explain_run_status(status: str, *, run_id: str = "", top_failure_mode: str | None = None) -> dict:
    poll_hint = f"Poll get_test_results(run_id='{run_id}')" if run_id else "Poll get_test_results(run_id='...')"
    guidance = {
        "queued": {
            "status_detail": "Run is queued and waiting for execution to begin.",
            "recommended_next_action": poll_hint,
            "is_terminal": False,
        },
        "running": {
            "status_detail": "Run is actively replaying recorded flows and collecting evidence.",
            "recommended_next_action": poll_hint,
            "is_terminal": False,
        },
        "waiting_auth": {
            "status_detail": "Run is blocked on authentication and will not execute until a valid session is available.",
            "recommended_next_action": "Refresh auth with capture_auth_session(...) or fix the auth profile, then retry the run.",
            "is_terminal": True,
        },
        "completed": {
            "status_detail": "Run finished and the final release recommendation is ready for review.",
            "recommended_next_action": "Review the release recommendation, evidence, and remediation guidance.",
            "is_terminal": True,
        },
        "failed": {
            "status_detail": "Run terminated with at least one failure condition that needs investigation.",
            "recommended_next_action": "Inspect the top failed case and captured evidence before retrying.",
            "is_terminal": True,
        },
        "cancelled": {
            "status_detail": "Run was cancelled before it finished.",
            "recommended_next_action": "Restart the run when you are ready to continue.",
            "is_terminal": True,
        },
    }
    result = guidance.get(
        status,
        {
            "status_detail": f"Run is in an unknown state: {status}.",
            "recommended_next_action": "Inspect the run record and health events for more detail.",
            "is_terminal": False,
        },
    ).copy()
    if status == "failed":
        action_overrides = {
            "auth_session_failure": "Refresh auth, confirm the session lands inside the app, and re-run.",
            "automation_fragility": "Inspect traces/screenshots, refresh the recorded flow if the UI drifted, and re-run.",
            "environment_or_infra": "Verify the app, runtime dependencies, and network access before retrying.",
            "product_regression": "Debug the top failed case, fix the regression, and re-run.",
            "unknown": "Inspect the top failed case and captured evidence before retrying.",
        }
        result["recommended_next_action"] = action_overrides.get(
            top_failure_mode or "unknown",
            result["recommended_next_action"],
        )
    return result


def infer_top_failure_mode(report: dict) -> str:
    status = report.get("status", "unknown")
    if status == "waiting_auth":
        return "waiting_auth"

    auth = report.get("auth_provenance", {}) or {}
    session_status = auth.get("session_validation_status")
    if session_status in {"expired_session", "redirected_to_auth", "unresolved_storage_state", "missing_profile", "validation_error"}:
        return "auth_session_failure"

    failure_kinds = (report.get("coverage_summary", {}) or {}).get("failure_kinds", []) or []
    if "environment_or_infra" in failure_kinds:
        return "environment_or_infra"
    if "product_regression" in failure_kinds:
        return "product_regression"
    if "automation_fragility" in failure_kinds:
        return "automation_fragility"

    if report.get("failed_cases"):
        return "unknown"
    return "unknown"


def remediation_steps_for_failure_mode(mode: str) -> list[str]:
    steps = {
        "waiting_auth": [
            "Refresh or capture a valid auth session with capture_auth_session(...).",
            "Validate the profile against the target app_url before retrying the run.",
            "Re-run the blocked release check once auth lands inside the app.",
        ],
        "auth_session_failure": [
            "Refresh or capture auth again and confirm the session still lands in the authenticated app.",
            "Run validate_release_setup(app_url='...', profile_name='...') to verify the auth profile before replay.",
            "Retry the replay after the auth session validates cleanly.",
        ],
        "automation_fragility": [
            "Inspect the top trace and screenshots to confirm whether the UI changed or the selector drifted.",
            "Refresh the recorded flow if the app surface changed or the old flow is stale.",
            "Re-run the replay and confirm the repaired flow passes without fallback drift.",
        ],
        "environment_or_infra": [
            "Verify the app is reachable and healthy from this machine.",
            "Check runtime dependencies, browser availability, and any recent environment/config changes.",
            "Retry the run once infrastructure issues are resolved.",
        ],
        "product_regression": [
            "Debug the top failed case using its trace, screenshots, and console/network evidence.",
            "Fix the underlying product issue in the affected journey.",
            "Re-run the release check to confirm the regression is gone.",
        ],
        "unknown": [
            "Inspect the top failed case and its evidence bundle first.",
            "Use the failure classification, trace, and screenshots to decide whether this is auth, drift, infra, or product.",
            "Retry only after the likely cause is addressed.",
        ],
    }
    return steps.get(mode, steps["unknown"])


def _compute_release_recommendation(cases: list[FailureCase], status: str) -> dict:
    """Compute a deterministic go/no-go release recommendation from run cases.

    Base logic uses severity and business_criticality.  Policy-as-code gates
    (BLOP_BLOCK_ON_REVENUE_FAILURE, BLOP_BLOCK_ON_ACTIVATION_FAILURE,
    BLOP_BLOCK_ON_ANY_FAILURE) can escalate INVESTIGATE → BLOCK via env vars.
    """
    from blop.config import (
        BLOP_BLOCK_ON_ACTIVATION_FAILURE,
        BLOP_BLOCK_ON_ANY_FAILURE,
        BLOP_BLOCK_ON_REVENUE_FAILURE,
    )

    failed = [c for c in cases if c.status in ("fail", "error", "blocked")]
    blockers = [c for c in failed if c.severity == "blocker"]
    revenue_failures = [c for c in failed if c.business_criticality == "revenue"]
    activation_failures = [c for c in failed if c.business_criticality == "activation"]
    critical_journey_failures = revenue_failures + activation_failures
    critical_drifted_passes = [
        c for c in cases
        if c.status == "pass"
        and c.business_criticality in ("revenue", "activation")
        and getattr(getattr(c, "drift_summary", None), "drift_detected", False)
        and getattr(getattr(c, "drift_summary", None), "disallowed_fallback_used", [])
    ]

    # Base decision
    policy_blocks: list[str] = []

    if blockers or critical_journey_failures:
        decision = "BLOCK"
        rationale = (
            f"{len(blockers)} blocker(s) and {len(critical_journey_failures)} critical journey failure(s) detected. "
            "Do not ship until these are resolved."
        )
    elif critical_drifted_passes:
        decision = "INVESTIGATE"
        rationale = (
            f"{len(critical_drifted_passes)} critical journey pass(es) required disallowed drift or fallback. "
            "Review replay fidelity before shipping."
        )
    elif failed:
        decision = "INVESTIGATE"
        rationale = f"{len(failed)} non-critical failure(s) detected. Review before shipping."
    else:
        decision = "SHIP"
        rationale = "All flows passed. No failures detected."

    # Policy gate escalations (INVESTIGATE → BLOCK only; SHIP is never silently overridden)
    if decision == "INVESTIGATE":
        if BLOP_BLOCK_ON_ANY_FAILURE and failed:
            policy_blocks.append("BLOP_BLOCK_ON_ANY_FAILURE=true")
        if BLOP_BLOCK_ON_REVENUE_FAILURE and revenue_failures:
            policy_blocks.append(f"BLOP_BLOCK_ON_REVENUE_FAILURE=true ({len(revenue_failures)} revenue failure(s))")
        if BLOP_BLOCK_ON_ACTIVATION_FAILURE and activation_failures:
            policy_blocks.append(f"BLOP_BLOCK_ON_ACTIVATION_FAILURE=true ({len(activation_failures)} activation failure(s))")
        if policy_blocks:
            decision = "BLOCK"
            rationale = rationale + f" Escalated to BLOCK by policy: {'; '.join(policy_blocks)}."

    terminal_statuses = {"completed", "failed", "cancelled"}
    passed = [c for c in cases if c.status == "pass"]
    screenshot_case_count = sum(1 for c in cases if getattr(c, "screenshots", []) or [])
    trace_case_count = sum(1 for c in cases if getattr(c, "trace_path", None))
    assertion_backed_case_count = sum(
        1 for c in cases if any(bool(result.get("passed")) for result in (getattr(c, "assertion_results", []) or []))
    )
    fragility_failures = sum(1 for c in failed if getattr(c, "failure_class", None) == "test_fragility")
    terminal = status in terminal_statuses
    strong_evidence = (
        terminal
        and len(cases) >= 3
        and len(passed) >= max(1, len(cases) - len(failed))
        and screenshot_case_count >= max(1, len(cases) - len(failed))
        and trace_case_count >= max(1, len(cases) - len(failed))
        and assertion_backed_case_count >= max(1, len(passed))
    )
    if strong_evidence and fragility_failures == 0:
        confidence = "high"
    elif terminal:
        confidence = "medium"
    else:
        confidence = "low"

    result: dict = {
        "decision": decision,
        "confidence": confidence,
        "rationale": rationale,
        "blocker_count": len(blockers),
        "critical_journey_failures": len(critical_journey_failures),
        "critical_drifted_passes": len(critical_drifted_passes),
    }
    if policy_blocks:
        result["policy_gates_applied"] = policy_blocks
    return result


def _severity_label(case: FailureCase) -> str:
    """Return a human-readable label like 'BLOCKER in revenue flow: checkout'."""
    bc = getattr(case, "business_criticality", "other") or "other"
    sev = (case.severity or "none").upper()
    if bc != "other" and case.status != "pass":
        return f"{sev} in {bc} flow: {case.flow_name}"
    return sev


def _enrich_case(c: FailureCase) -> dict:
    """Return a case payload enriched with reporting metadata."""
    d = c.model_dump()
    d["artifact_paths"] = c.screenshots
    d["severity_label"] = _severity_label(c)
    d["healed_step_count"] = len(c.healed_steps or [])
    d["was_rerecorded"] = c.rerecorded
    d["failure_kind"] = _classify_failure_kind(d)
    return d


def build_decision_summary(report: dict) -> dict:
    """Build a compact decision-first summary from a run report payload."""
    rec = report.get("release_recommendation", {}) or {}
    failed_cases = report.get("failed_cases", []) or []
    top_blockers = [
        case.get("flow_name", "")
        for case in failed_cases
        if case.get("severity") == "blocker" and case.get("status") in ("fail", "error", "blocked")
    ]
    top_blockers = [name for name in top_blockers if name][:3]

    decision = rec.get("decision", "INVESTIGATE")
    status_guidance = explain_run_status(
        report.get("status", "unknown"),
        run_id=report.get("run_id", ""),
        top_failure_mode=report.get("top_failure_mode"),
    )
    next_recommended_action = report.get("recommended_next_action")
    if not next_recommended_action:
        if report.get("status") in ("queued", "running", "waiting_auth"):
            next_recommended_action = status_guidance["recommended_next_action"]
        elif decision == "BLOCK":
            next_recommended_action = "Investigate the top blocker and re-run after a fix."
        elif decision == "INVESTIGATE":
            next_recommended_action = "Review failed cases and inspect the highest-signal evidence."
        else:
            next_recommended_action = "Review the final release brief and ship if it matches release scope."

    return {
        "decision": decision,
        "confidence": rec.get("confidence", "medium"),
        "blocker_count": rec.get("blocker_count", 0),
        "critical_journey_failures": rec.get("critical_journey_failures", 0),
        "critical_drifted_passes": rec.get("critical_drifted_passes", 0),
        "top_blocker_journeys": top_blockers,
        "verified_journeys": [
            case.get("flow_name", "")
            for case in (report.get("cases", []) or [])
            if case.get("status") == "pass" and case.get("flow_name")
        ][:5],
        "plan_fidelity": (report.get("drift_summary", {}) or {}).get("plan_fidelity"),
        "next_recommended_action": next_recommended_action,
    }


def build_evidence_summary(report: dict) -> dict:
    """Build a compact evidence summary from a run report payload."""
    failed_cases = report.get("failed_cases", []) or []
    all_cases = report.get("cases", []) or []
    evidence_cases = failed_cases or [case for case in all_cases if case.get("status") == "pass"]
    artifact_refs: list[str] = []
    console_error_count = 0
    network_error_count = 0
    healed_case_count = 0
    trace_count = 0
    screenshot_count = 0

    for case in all_cases:
        if case.get("trace_path"):
            trace_count += 1
        screenshot_count += len(case.get("artifact_paths", []) or [])

    for case in evidence_cases[:5]:
        console_error_count += len(case.get("console_errors", []) or [])
        network_error_count += len(case.get("network_errors", []) or [])
        if case.get("healed_step_count", 0):
            healed_case_count += 1
        for path in _artifact_paths_for_case(case)[:2]:
            if path and path not in artifact_refs:
                artifact_refs.append(path)
            if len(artifact_refs) >= 5:
                break
        if len(artifact_refs) >= 5:
            break

    return {
        "failed_case_count": len(failed_cases),
        "console_error_count": console_error_count,
        "network_error_count": network_error_count,
        "healed_case_count": healed_case_count,
        "trace_count": trace_count,
        "screenshot_count": screenshot_count,
        "top_artifact_refs": artifact_refs,
    }


def build_coverage_summary(report: dict) -> dict:
    """Summarize what product surface was actually verified during the run."""
    cases = report.get("cases", []) or []
    passed_cases = [case for case in cases if case.get("status") == "pass"]
    failed_cases = [case for case in cases if case.get("status") in ("fail", "error", "blocked")]
    observed_assertions: list[str] = []
    proof_artifact_refs: list[str] = []
    failure_kinds: list[str] = []

    for case in passed_cases:
        for assertion in _extract_observed_assertions(case):
            if assertion not in observed_assertions:
                observed_assertions.append(assertion)
            if len(observed_assertions) >= 5:
                break
        for path in _artifact_paths_for_case(case):
            if path not in proof_artifact_refs:
                proof_artifact_refs.append(path)
            if len(proof_artifact_refs) >= 5:
                break
        if len(observed_assertions) >= 5 and len(proof_artifact_refs) >= 5:
            break

    for case in failed_cases:
        kind = case.get("failure_kind", "unknown")
        if kind not in failure_kinds:
            failure_kinds.append(kind)

    verified_journeys = []
    blocked_journeys = []
    for case in passed_cases:
        name = case.get("flow_name", "")
        if name and name not in verified_journeys:
            verified_journeys.append(name)
    for case in failed_cases:
        name = case.get("flow_name", "")
        if name and name not in blocked_journeys:
            blocked_journeys.append(name)

    return {
        "total_cases": len(cases),
        "passed_case_count": len(passed_cases),
        "failed_case_count": len(failed_cases),
        "verified_journeys": verified_journeys[:5],
        "blocked_journeys": blocked_journeys[:5],
        "observed_assertions": observed_assertions[:5],
        "proof_artifact_refs": proof_artifact_refs[:5],
        "failure_kinds": failure_kinds[:3],
    }


def build_evidence_quality(report: dict) -> dict:
    """Describe how much proof exists behind the run result."""
    cases = report.get("cases", []) or []
    total_cases = len(cases)
    screenshot_case_count = sum(1 for case in cases if case.get("artifact_paths"))
    trace_case_count = sum(1 for case in cases if case.get("trace_path"))
    assertion_backed_case_count = sum(1 for case in cases if _extract_observed_assertions(case))
    failure_kinds = {
        case.get("failure_kind", "unknown")
        for case in cases
        if case.get("status") in ("fail", "error", "blocked")
    }
    confidence_drivers: list[str] = []
    if screenshot_case_count:
        confidence_drivers.append(f"{screenshot_case_count}/{total_cases or 1} case(s) include screenshots")
    if trace_case_count:
        confidence_drivers.append(f"{trace_case_count}/{total_cases or 1} case(s) include traces")
    if assertion_backed_case_count:
        confidence_drivers.append(f"{assertion_backed_case_count}/{total_cases or 1} case(s) include passed assertions")
    if "automation_fragility" in failure_kinds:
        confidence_drivers.append("Some failures appear to be automation fragility, not confirmed product regressions")
    if not confidence_drivers:
        confidence_drivers.append("Evidence capture is sparse")

    return {
        "screenshots_present": screenshot_case_count > 0,
        "traces_present": trace_case_count > 0,
        "screenshot_case_count": screenshot_case_count,
        "trace_case_count": trace_case_count,
        "assertion_backed_case_count": assertion_backed_case_count,
        "confidence_drivers": confidence_drivers,
    }


def build_drift_summary(report: dict) -> dict:
    cases = report.get("cases", []) or []
    drift_types: list[str] = []
    allowed_fallback_used: list[str] = []
    disallowed_fallback_used: list[str] = []
    surface_match = True
    assertion_match = True
    plan_fidelity = "high"

    for case in cases:
        drift = case.get("drift_summary", {}) or {}
        for item in drift.get("drift_types", []) or []:
            if item not in drift_types:
                drift_types.append(item)
        for item in drift.get("allowed_fallback_used", []) or []:
            if item not in allowed_fallback_used:
                allowed_fallback_used.append(item)
        for item in drift.get("disallowed_fallback_used", []) or []:
            if item not in disallowed_fallback_used:
                disallowed_fallback_used.append(item)
        if drift.get("surface_match") is False:
            surface_match = False
        if drift.get("assertion_match") is False:
            assertion_match = False
        if drift.get("plan_fidelity") == "low":
            plan_fidelity = "low"
        elif drift.get("plan_fidelity") == "medium" and plan_fidelity != "low":
            plan_fidelity = "medium"

    return {
        "drift_detected": bool(drift_types or allowed_fallback_used or disallowed_fallback_used),
        "drift_types": drift_types,
        "allowed_fallback_used": allowed_fallback_used,
        "disallowed_fallback_used": disallowed_fallback_used,
        "surface_match": surface_match if cases else None,
        "assertion_match": assertion_match if cases else None,
        "plan_fidelity": plan_fidelity if cases else "low",
    }


async def build_report(run: dict, cases: list[FailureCase]) -> dict:
    severity_counts: dict[str, int] = {
        "blocker": 0, "high": 0, "medium": 0, "low": 0, "none": 0, "pass": 0, "error": 0
    }
    for c in cases:
        if c.status == "pass":
            severity_counts["pass"] = severity_counts.get("pass", 0) + 1
        elif c.status in ("error", "blocked"):
            severity_counts["error"] = severity_counts.get("error", 0) + 1
        else:
            severity_counts[c.severity] = severity_counts.get(c.severity, 0) + 1

    failed = [c for c in cases if c.status in ("fail", "error", "blocked")]

    status = run.get("status", "unknown")
    status_meta = explain_run_status(status, run_id=run.get("run_id", ""))
    extra: dict = {
        "status_detail": status_meta["status_detail"],
        "recommended_next_action": status_meta["recommended_next_action"],
        "is_terminal": status_meta["is_terminal"],
        "top_failure_mode": "waiting_auth" if status == "waiting_auth" else "unknown",
        "recommended_remediation_steps": remediation_steps_for_failure_mode("waiting_auth" if status == "waiting_auth" else "unknown"),
    }
    if status == "waiting_auth":
        extra["waiting_auth_message"] = (
            "Run is waiting for auth. The auth profile could not be resolved or the session needs to be refreshed before replay can start."
        )

    # Enrich case dicts with replay metadata, severity label, and healing info
    cases_out = [_enrich_case(c) for c in cases]
    failed_out = [_enrich_case(c) for c in failed]

    report = {
        "run_id": run.get("run_id", ""),
        "status": status,
        "started_at": run.get("started_at", ""),
        "completed_at": run.get("completed_at"),
        "cases": cases_out,
        "severity_counts": severity_counts,
        "failed_cases": failed_out,
        "artifacts_dir": run.get("artifacts_dir", ""),
        "run_mode": run.get("run_mode", "hybrid"),
        "next_actions": run.get("next_actions", []),
        "release_recommendation": _compute_release_recommendation(cases, status),
        **extra,
    }
    report["decision_summary"] = build_decision_summary(report)
    report["evidence_summary"] = build_evidence_summary(report)
    report["coverage_summary"] = build_coverage_summary(report)
    report["evidence_quality"] = build_evidence_quality(report)
    report["drift_summary"] = build_drift_summary(report)
    return report
