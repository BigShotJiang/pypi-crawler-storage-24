"""Tests for engine/regression.py."""
from __future__ import annotations

import asyncio
import os
import sys
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from blop.schemas import FlowStep, IntentContract, RecordedFlow


def make_flow(flow_id: str = "flow1", goal: str = "Test the page") -> RecordedFlow:
    return RecordedFlow(
        flow_id=flow_id,
        flow_name="test_flow",
        app_url="https://example.com",
        goal=goal,
        steps=[
            FlowStep(step_id=0, action="navigate", value="https://example.com"),
            FlowStep(step_id=1, action="assert", description="page loads"),
        ],
        created_at=datetime.now(timezone.utc).isoformat(),
        intent_contract=IntentContract(
            goal_text=goal,
            goal_type="milestone",
            target_surface="authenticated_app",
            success_assertions=["page loads"],
            must_interact=["navigate"],
            forbidden_shortcuts=["goal_fallback_without_surface_match"],
            scope="authed",
            business_criticality="other",
            planning_source="explicit_goal",
            expected_url_patterns=["https://example.com"],
            allowed_fallbacks=["hybrid_repair"],
        ),
    )


def _mock_browser_use():
    """Create a mock browser_use module that avoids display detection."""
    mock_bu = MagicMock()
    mock_bu.Agent = MagicMock()
    mock_bu.BrowserSession = MagicMock()
    mock_bu.llm.ChatGoogle = MagicMock()
    mock_bu.llm.messages.UserMessage = MagicMock()
    return mock_bu


class _FinalPage:
    async def inner_text(self, selector: str) -> str:
        return "All good"


@pytest.mark.asyncio
async def test_execute_flow_pass():
    """Flow returns pass status when result has no error keywords."""
    from blop.engine.regression import execute_flow

    mock_history = MagicMock()
    mock_history.final_result.return_value = "All steps completed successfully"

    mock_agent = AsyncMock()
    mock_agent.run.return_value = mock_history

    mock_session = AsyncMock()
    mock_session.context = None
    mock_session.aclose = AsyncMock()
    mock_session.get_current_page = AsyncMock(return_value=_FinalPage())
    mock_session.get_current_page_url = AsyncMock(return_value="https://example.com")

    mock_bu = _mock_browser_use()
    mock_bu.Agent.return_value = mock_agent
    mock_bu.BrowserSession.return_value = mock_session

    with patch.dict(os.environ, {"GOOGLE_API_KEY": "test_key"}):
        with patch.dict(sys.modules, {"browser_use": mock_bu, "browser_use.llm": mock_bu.llm, "browser_use.llm.messages": mock_bu.llm.messages}):
            with patch("blop.engine.browser.make_browser_profile"):
                with patch("blop.storage.files.screenshot_path", return_value="/tmp/shot.png"):
                    flow = make_flow()
                    case = await execute_flow(
                        flow=flow,
                        app_url="https://example.com",
                        run_id="run1",
                        case_id="case1",
                        storage_state=None,
                        headless=True,
                        run_mode="goal_fallback",
                    )

    assert case.status == "pass"
    assert case.flow_id == "flow1"
    assert case.drift_summary.drift_detected is True
    assert "plan_drift" in case.drift_summary.drift_types


@pytest.mark.asyncio
async def test_execute_flow_fail_on_error_keyword():
    """Flow returns fail status when result contains error keywords."""
    from blop.engine.regression import execute_flow

    mock_history = MagicMock()
    mock_history.final_result.return_value = "Page returned 404 error"

    mock_agent = AsyncMock()
    mock_agent.run.return_value = mock_history

    mock_session = AsyncMock()
    mock_session.context = None
    mock_session.aclose = AsyncMock()
    mock_session.get_current_page = AsyncMock(return_value=_FinalPage())
    mock_session.get_current_page_url = AsyncMock(return_value="https://example.com")

    mock_bu = _mock_browser_use()
    mock_bu.Agent.return_value = mock_agent
    mock_bu.BrowserSession.return_value = mock_session

    with patch.dict(os.environ, {"GOOGLE_API_KEY": "test_key"}):
        with patch.dict(sys.modules, {"browser_use": mock_bu, "browser_use.llm": mock_bu.llm, "browser_use.llm.messages": mock_bu.llm.messages}):
            with patch("blop.engine.browser.make_browser_profile"):
                with patch("blop.storage.files.screenshot_path", return_value="/tmp/shot.png"):
                    flow = make_flow()
                    case = await execute_flow(
                        flow=flow,
                        app_url="https://example.com",
                        run_id="run1",
                        case_id="case1",
                        storage_state=None,
                        headless=True,
                        run_mode="goal_fallback",
                    )

    assert case.status == "fail"


def test_build_drift_summary_flags_goal_fallback_when_not_allowed():
    from blop.engine.regression import _build_drift_summary

    flow = make_flow(goal="Open settings")
    drift = _build_drift_summary(
        flow=flow,
        status="pass",
        replay_mode="goal_fallback",
        assertion_results=[],
        failure_reason_codes=[],
        rerecorded=False,
        actual_landing_url="https://example.com/settings",
    )

    assert drift.drift_detected is True
    assert "plan_drift" in drift.drift_types
    assert "goal_fallback" in drift.disallowed_fallback_used


@pytest.mark.asyncio
async def test_run_flows_parallel():
    """run_flows executes multiple flows and returns one case per flow."""
    from blop.engine.regression import run_flows

    mock_history = MagicMock()
    mock_history.final_result.return_value = "Success"

    mock_agent = AsyncMock()
    mock_agent.run.return_value = mock_history

    mock_session = AsyncMock()
    mock_session.context = None
    mock_session.aclose = AsyncMock()
    mock_session.get_current_page = AsyncMock(return_value=_FinalPage())
    mock_session.get_current_page_url = AsyncMock(return_value="https://example.com")

    mock_bu = _mock_browser_use()
    mock_bu.Agent.return_value = mock_agent
    mock_bu.BrowserSession.return_value = mock_session

    flows = [make_flow(f"flow{i}", f"Goal {i}") for i in range(3)]

    with patch.dict(os.environ, {"GOOGLE_API_KEY": "test_key"}):
        with patch.dict(sys.modules, {"browser_use": mock_bu, "browser_use.llm": mock_bu.llm, "browser_use.llm.messages": mock_bu.llm.messages}):
            with patch("blop.engine.browser.make_browser_profile"):
                with patch("blop.storage.files.screenshot_path", return_value="/tmp/shot.png"):
                    cases = await run_flows(
                        flows=flows,
                        app_url="https://example.com",
                        run_id="run1",
                        storage_state=None,
                        headless=True,
                    )

    assert len(cases) == 3
    assert all(c.run_id == "run1" for c in cases)


@pytest.mark.asyncio
async def test_run_flows_propagates_business_criticality():
    """Flow with business_criticality='revenue' -> resulting FailureCase has same value."""
    from blop.engine.regression import run_flows
    from blop.schemas import RecordedFlow

    revenue_flow = RecordedFlow(
        flow_id="flow-rev",
        flow_name="checkout_with_credit_card",
        app_url="https://example.com",
        goal="Complete checkout",
        steps=[FlowStep(step_id=0, action="navigate", value="https://example.com/checkout")],
        created_at=datetime.now(timezone.utc).isoformat(),
        business_criticality="revenue",
    )

    mock_history = MagicMock()
    mock_history.final_result.return_value = "Checkout completed successfully"

    mock_agent = AsyncMock()
    mock_agent.run.return_value = mock_history

    mock_session = AsyncMock()
    mock_session.context = None
    mock_session.aclose = AsyncMock()
    mock_session.get_current_page = AsyncMock(return_value=_FinalPage())
    mock_session.get_current_page_url = AsyncMock(return_value="https://example.com")

    mock_bu = _mock_browser_use()
    mock_bu.Agent.return_value = mock_agent
    mock_bu.BrowserSession.return_value = mock_session

    with patch.dict(os.environ, {"GOOGLE_API_KEY": "test_key"}):
        with patch.dict(sys.modules, {"browser_use": mock_bu, "browser_use.llm": mock_bu.llm, "browser_use.llm.messages": mock_bu.llm.messages}):
            with patch("blop.engine.browser.make_browser_profile"):
                with patch("blop.storage.files.screenshot_path", return_value="/tmp/shot.png"):
                    cases = await run_flows(
                        flows=[revenue_flow],
                        app_url="https://example.com",
                        run_id="run-rev",
                        storage_state=None,
                        headless=True,
                    )

    assert len(cases) == 1
    assert cases[0].flow_id == "flow-rev"
    assert cases[0].flow_name == "checkout_with_credit_card"


@pytest.mark.asyncio
async def test_run_flows_semaphore():
    """run_flows respects semaphore and does not exceed 5 concurrent flows."""
    from blop.engine.regression import run_flows

    concurrent_count = 0
    max_concurrent = 0

    async def slow_execute(*args, **kwargs):
        nonlocal concurrent_count, max_concurrent
        concurrent_count += 1
        max_concurrent = max(max_concurrent, concurrent_count)
        await asyncio.sleep(0.05)
        concurrent_count -= 1

        from blop.schemas import FailureCase
        return FailureCase(
            run_id=kwargs.get("run_id", "run1"),
            flow_id=kwargs.get("flow", make_flow()).flow_id,
            flow_name="test",
            status="pass",
        )

    flows = [make_flow(f"flow{i}") for i in range(10)]

    with patch("blop.engine.regression.execute_flow", side_effect=slow_execute):
        cases = await run_flows(
            flows=flows,
            app_url="https://example.com",
            run_id="run1",
            storage_state=None,
            headless=True,
        )

    assert len(cases) == 10
    assert max_concurrent <= 5


def test_repair_flow_context_suffix_includes_goal_for_weak_steps():
    from blop.engine.regression import _repair_flow_context_suffix

    step = FlowStep(step_id=1, action="click", target_text="click")

    suffix = _repair_flow_context_suffix(
        flow_name="view_plans_modal",
        flow_goal="Open the View Plans button until the upgrade plan modal is visible.",
        step_index=2,
        step=step,
    )

    assert "Flow name: view_plans_modal" in suffix
    assert "Flow goal: Open the View Plans button" in suffix
    assert "weak locator data" in suffix
