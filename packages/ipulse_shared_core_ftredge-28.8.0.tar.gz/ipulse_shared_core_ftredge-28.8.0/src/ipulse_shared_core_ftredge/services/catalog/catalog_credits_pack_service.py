"""
Credits Pack Catalog Service

This service manages credits pack templates stored in Firestore.
These templates define purchasable credit bundles with pricing and eligibility rules.

Follows the same catalog service conventions as CatalogSubscriptionPlanService:
- Full CRUD (create, get, update, delete, list, exists, validate)
- Aligned method naming: create_credits_pack, get_credits_pack, etc.
- Domain-specific queries (by plan eligibility, purchasable status)
"""

import logging
from typing import Dict, List, Optional, Any
from google.cloud import firestore
from google.cloud.firestore import Client
from ipulse_shared_base_ftredge import SubscriptionPlanName
from ipulse_shared_base_ftredge.enums.enums_status import ObjectOverallStatus
from ipulse_shared_core_ftredge.models.catalog.credits_pack import CreditsPack
from ipulse_shared_core_ftredge.services.base.base_firestore_service import BaseFirestoreService


class CatalogCreditsPackService(BaseFirestoreService[CreditsPack]):
    """
    Service for managing credits pack catalog configurations.

    Provides CRUD operations for credits pack templates and domain-specific
    queries (by plan eligibility, active status, etc.).
    """

    def __init__(
        self,
        firestore_client: Client,
        logger: Optional[logging.Logger] = None
    ):
        """
        Initialize the Credits Pack Catalog Service.

        Args:
            firestore_client: Firestore client instance
            logger: Logger instance (optional)
        """
        super().__init__(
            db=firestore_client,
            collection_name=CreditsPack.COLLECTION_NAME,
            resource_type="CreditsPack",
            model_class=CreditsPack,
            logger=logger or logging.getLogger(__name__)
        )
        self.archive_collection_name = "~archive_papp_core_catalog_credit_packs"

    # ---------- CRUD ----------

    async def create_credits_pack(
        self,
        credits_pack_id: str,
        credits_pack: CreditsPack,
        creator_uid: str
    ) -> CreditsPack:
        """
        Create a new credits pack catalog entry.

        Args:
            credits_pack_id: Unique identifier for the credits pack
            credits_pack: Credits pack data
            creator_uid: UID of the user creating the pack

        Returns:
            Created credits pack

        Raises:
            ServiceError: If creation fails
            ValidationError: If pack data is invalid
        """
        self.logger.info(f"Creating credits pack: {credits_pack_id}")

        created_doc = await self.create_document(
            doc_id=credits_pack_id,
            data=credits_pack,
            creator_uid=creator_uid
        )

        result = CreditsPack.model_validate(created_doc)
        self.logger.info(f"Successfully created credits pack: {credits_pack_id}")
        return result

    async def get_credits_pack(self, credits_pack_id: str) -> Optional[CreditsPack]:
        """
        Retrieve a credits pack by document ID.

        Args:
            credits_pack_id: Unique identifier for the credits pack

        Returns:
            Credits pack if found, None otherwise

        Raises:
            ServiceError: If retrieval fails
        """
        self.logger.debug(f"Retrieving credits pack: {credits_pack_id}")
        doc_data = await self.get_document(credits_pack_id)
        if doc_data is None:
            return None
        return CreditsPack.model_validate(doc_data) if isinstance(doc_data, dict) else doc_data

    async def update_credits_pack(
        self,
        credits_pack_id: str,
        updates: Dict[str, Any],
        updater_uid: str
    ) -> CreditsPack:
        """
        Update a credits pack.

        Args:
            credits_pack_id: Unique identifier for the credits pack
            updates: Fields to update
            updater_uid: UID of the user updating the pack

        Returns:
            Updated credits pack

        Raises:
            ServiceError: If update fails
            ResourceNotFoundError: If pack not found
            ValidationError: If update data is invalid
        """
        self.logger.info(f"Updating credits pack: {credits_pack_id}")

        updated_doc = await self.update_document(
            doc_id=credits_pack_id,
            update_data=updates,
            updater_uid=updater_uid
        )

        result = CreditsPack.model_validate(updated_doc)
        self.logger.info(f"Successfully updated credits pack: {credits_pack_id}")
        return result

    async def delete_credits_pack(
        self,
        credits_pack_id: str,
        archive: bool = True
    ) -> bool:
        """
        Delete a credits pack (optionally archive first).

        Args:
            credits_pack_id: Unique identifier for the credits pack
            archive: Whether to archive before deletion

        Returns:
            True if deletion was successful

        Raises:
            ServiceError: If deletion fails
            ResourceNotFoundError: If pack not found
        """
        self.logger.info(f"Deleting credits pack: {credits_pack_id}")

        if archive:
            pack = await self.get_credits_pack(credits_pack_id)
            if pack:
                await self.archive_document(
                    document_data=pack.model_dump(),
                    doc_id=credits_pack_id,
                    archive_collection=self.archive_collection_name,
                    archived_by="system"
                )

        result = await self.delete_document(credits_pack_id)
        self.logger.info(f"Successfully deleted credits pack: {credits_pack_id}")
        return result

    # ---------- Query ----------

    async def list_credits_packs(
        self,
        pulse_status: Optional[ObjectOverallStatus] = None,
        for_plan: Optional[SubscriptionPlanName] = None,
        purchasable_only: bool = False,
        latest_version_only: bool = False,
        limit: Optional[int] = None,
    ) -> List[CreditsPack]:
        """
        List credits packs with optional filtering.

        Args:
            pulse_status: Filter by specific pulse status
            for_plan: Filter by subscription plan eligibility (array_contains)
            purchasable_only: Only return purchasable packs
            latest_version_only: Only return the latest version per pack_name
            limit: Maximum number of packs to return

        Returns:
            List of credits packs ordered by credits_amount ascending

        Raises:
            ServiceError: If listing fails
        """
        self.logger.debug(
            f"Listing credits packs - pulse_status: {pulse_status}, "
            f"for_plan: {for_plan}, purchasable_only: {purchasable_only}"
        )

        filters = []
        if pulse_status:
            filters.append(("pulse_status", "==", pulse_status.value))
        if purchasable_only:
            filters.append(("purchasable", "==", True))
        if for_plan:
            filters.append(("available_for_plans", "array_contains", for_plan.value))

        docs = await self.list_documents(
            filters=filters,
            order_by="credits_amount",
            order_direction=firestore.Query.ASCENDING,
            limit=limit
        )

        packs = [CreditsPack.model_validate(doc) for doc in docs]

        if latest_version_only:
            pack_groups: Dict[str, CreditsPack] = {}
            for pack in sorted(packs, key=lambda p: p.pack_version, reverse=True):
                if pack.pack_name not in pack_groups:
                    pack_groups[pack.pack_name] = pack
            return sorted(pack_groups.values(), key=lambda p: p.credits_amount)

        return packs

    async def credits_pack_exists(self, credits_pack_id: str) -> bool:
        """
        Check if a credits pack exists.

        Args:
            credits_pack_id: Unique identifier for the credits pack

        Returns:
            True if pack exists, False otherwise

        Raises:
            ServiceError: If check fails
        """
        return await self.document_exists(credits_pack_id)

    async def validate_credits_pack_data(self, credits_pack_data: Dict[str, Any]) -> tuple[bool, List[str]]:
        """
        Validate credits pack data against the CreditsPack model.

        Args:
            credits_pack_data: Pack data to validate

        Returns:
            Tuple of (is_valid, list_of_errors)
        """
        try:
            CreditsPack.model_validate(credits_pack_data)
            return True, []
        except Exception as e:
            return False, [str(e)]

    # ---------- Domain-specific convenience ----------

    async def get_active_purchasable_packs(
        self,
        for_plan: Optional[SubscriptionPlanName] = None,
    ) -> List[CreditsPack]:
        """
        Return all ACTIVE + purchasable packs, optionally filtered by plan eligibility.

        This is the primary query used by the billing flow to show
        available credits packs to a user.

        Args:
            for_plan: Filter by subscription plan name eligibility

        Returns:
            List of active, purchasable credits packs (latest version per pack_name)
        """
        return await self.list_credits_packs(
            pulse_status=ObjectOverallStatus.ACTIVE,
            purchasable_only=True,
            for_plan=for_plan,
            latest_version_only=True,
        )
