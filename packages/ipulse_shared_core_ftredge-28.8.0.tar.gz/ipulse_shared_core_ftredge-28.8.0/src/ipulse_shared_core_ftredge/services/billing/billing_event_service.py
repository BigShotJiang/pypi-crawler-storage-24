"""
BillingEventService -- Append-only audit log for all billing state changes.

Every billing-related action (Stripe webhook, verify-session, admin, reconciliation)
produces a BillingEvent record. These records are immutable and support:
- Compliance auditing
- Debugging billing issues
- Dead-letter replay
- Reconciliation against Stripe
"""

import logging
import uuid
from datetime import datetime, timezone
from typing import Optional, Dict, Any, List
from google.cloud.firestore import Client
from ipulse_shared_core_ftredge.models.billing.billing_event import BillingEvent
from ipulse_shared_core_ftredge.services.base.base_firestore_service import BaseFirestoreService
from ipulse_shared_core_ftredge.exceptions import ServiceError


class BillingEventService(BaseFirestoreService[BillingEvent]):
    """
    Append-only service for recording billing events.

    All writes use WRITE (set) -- never update/delete.
    Events are immutable after creation.
    """

    def __init__(
        self,
        firestore_client: Client,
        logger: Optional[logging.Logger] = None
    ):
        super().__init__(
            db=firestore_client,
            collection_name=BillingEvent.COLLECTION_NAME,
            resource_type="BillingEvent",
            model_class=BillingEvent,
            logger=logger or logging.getLogger(__name__)
        )

    def record_event(
        self,
        user_uid: str,
        event_type: str,
        source: str,
        processing_result: str,
        stripe_event_id: Optional[str] = None,
        stripe_event_type: Optional[str] = None,
        stripe_session_id: Optional[str] = None,
        stripe_invoice_id: Optional[str] = None,
        stripe_subscription_id: Optional[str] = None,
        before_state: Optional[Dict[str, Any]] = None,
        after_state: Optional[Dict[str, Any]] = None,
        amount_usd: Optional[float] = None,
        promo_code_applied: Optional[str] = None,
        discount_amount_usd: Optional[float] = None,
        processing_error: Optional[str] = None,
    ) -> BillingEvent:
        """
        Create and persist a billing event record.

        Args:
            user_uid: User UID associated with this event.
            event_type: Internal event type (e.g., 'subscription_created').
            source: What triggered this event (e.g., 'verify_session', 'stripe_webhook').
            processing_result: Outcome ('success', 'skipped_duplicate', 'failed', 'stale_event_ignored').
            stripe_event_id: Stripe event ID for correlation.
            stripe_event_type: Stripe event type string.
            stripe_session_id: Checkout Session ID if applicable.
            stripe_invoice_id: Invoice ID if applicable.
            stripe_subscription_id: Subscription ID if applicable.
            before_state: State snapshot before change.
            after_state: State snapshot after change.
            amount_usd: Transaction amount.
            promo_code_applied: Promo code if used.
            discount_amount_usd: Discount amount.
            processing_error: Error message if processing_result is 'failed'.

        Returns:
            The created BillingEvent instance.
        """
        event_id = str(uuid.uuid4())

        event = BillingEvent(
            id=event_id,
            user_uid=user_uid,
            event_type=event_type,
            source=source,
            processing_result=processing_result,
            stripe_event_id=stripe_event_id,
            stripe_event_type=stripe_event_type,
            stripe_session_id=stripe_session_id,
            stripe_invoice_id=stripe_invoice_id,
            stripe_subscription_id=stripe_subscription_id,
            before_state=before_state,
            after_state=after_state,
            amount_usd=amount_usd,
            promo_code_applied=promo_code_applied,
            discount_amount_usd=discount_amount_usd,
            processing_error=processing_error,
            processed_timestamp_utc=datetime.now(timezone.utc),
        )

        try:
            self._get_collection().document(event_id).set(
                event.model_dump(exclude_none=True)
            )
            self.logger.info(
                f"BillingEvent recorded: type={event_type}, source={source}, "
                f"result={processing_result}, user={user_uid}, id={event_id}"
            )
        except Exception as e:
            # Billing event logging should never break the main flow.
            # Log the error but do not raise.
            self.logger.error(
                f"Failed to persist BillingEvent: type={event_type}, "
                f"user={user_uid}, error={e}"
            )

        return event

    def get_recent_events_for_user(
        self,
        user_uid: str,
        limit: int = 10
    ) -> List[BillingEvent]:
        """
        Fetch the most recent billing events for a user.

        Args:
            user_uid: User UID.
            limit: Maximum number of events to return.

        Returns:
            List of BillingEvent instances, newest first.
        """
        try:
            query = (
                self._get_collection()
                .where("user_uid", "==", user_uid)
                .order_by("processed_timestamp_utc", direction="DESCENDING")
                .limit(limit)
            )
            docs = query.stream()
            events = []
            for doc in docs:
                try:
                    event = self._convert_to_model(doc.to_dict(), doc.id)
                    events.append(event)
                except Exception as e:
                    self.logger.warning(f"Failed to parse BillingEvent {doc.id}: {e}")
            return events
        except Exception as e:
            self.logger.error(f"Failed to fetch billing events for user {user_uid}: {e}")
            return []

    def list_events(
        self,
        limit: int = 50,
        offset: int = 0,
        user_uid: Optional[str] = None,
        event_type: Optional[str] = None,
        source: Optional[str] = None,
    ) -> List[BillingEvent]:
        """
        List billing events with optional filters, sorted by newest first.

        Designed for admin use -- supports cross-user queries and filtering.

        Args:
            limit: Maximum number of events to return (default 50).
            offset: Number of events to skip for pagination.
            user_uid: Optional filter by user UID.
            event_type: Optional filter by event type (e.g., 'subscription_created').
            source: Optional filter by source (e.g., 'stripe_webhook', 'verify_session').

        Returns:
            List of BillingEvent instances, newest first.
        """
        try:
            query = self._get_collection().order_by(
                "processed_timestamp_utc", direction="DESCENDING"
            )

            if user_uid:
                query = query.where("user_uid", "==", user_uid)
            if event_type:
                query = query.where("event_type", "==", event_type)
            if source:
                query = query.where("source", "==", source)

            if offset > 0:
                query = query.offset(offset)
            query = query.limit(limit)

            docs = query.stream()
            events = []
            for doc in docs:
                try:
                    event = self._convert_to_model(doc.to_dict(), doc.id)
                    events.append(event)
                except Exception as e:
                    self.logger.warning(f"Failed to parse BillingEvent {doc.id}: {e}")
            return events
        except Exception as e:
            self.logger.error(f"Failed to list billing events: {e}")
            return []
