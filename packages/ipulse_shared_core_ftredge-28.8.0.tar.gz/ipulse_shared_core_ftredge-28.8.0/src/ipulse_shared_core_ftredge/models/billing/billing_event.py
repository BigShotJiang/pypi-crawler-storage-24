"""
BillingEvent model -- immutable audit log for all billing state changes.

Every Stripe event and every internal billing state change produces a BillingEvent record.
These are append-only (never deleted or modified) and power:
- Audit trail for compliance
- Debugging billing issues
- Reconciliation against Stripe
- Dead-letter replay
"""

from datetime import datetime, timezone
from typing import Optional, ClassVar, Dict, Any
from pydantic import Field, ConfigDict
from ipulse_shared_base_ftredge import Layer, Module, list_enums_as_lower_strings, SystemSubject
from ..base_nosql_model import BaseNoSQLModel


class BillingEvent(BaseNoSQLModel):
    """
    Immutable billing event record for audit and replay.

    Each record captures a single billing state transition with before/after snapshots.
    Sources include: verify_session, stripe_webhook, admin_action, system_reconciliation, authz_review.
    """

    model_config = ConfigDict(frozen=True, extra="ignore")

    SCHEMA_ID: ClassVar[str] = ""
    SCHEMA_NAME: ClassVar[str] = ""
    VERSION: ClassVar[int] = 1
    DOMAIN: ClassVar[str] = "_".join(list_enums_as_lower_strings(Layer.PULSE_APP, Module.CORE, SystemSubject.PAYMENT))
    OBJ_REF: ClassVar[str] = "billing_event"
    COLLECTION_NAME: ClassVar[str] = "papp_core_billing_events"

    # Event identity
    id: Optional[str] = Field(
        default=None,
        description="Unique billing event ID (auto-generated UUID if not provided)"
    )

    user_uid: str = Field(
        ...,
        min_length=1,
        description="User UID associated with this billing event"
    )

    event_type: str = Field(
        ...,
        min_length=1,
        description=(
            "Internal event type describing what happened. "
            "Examples: subscription_created, credits_pack_purchased, payment_failed, "
            "downgrade_to_free, subscription_renewed, trial_started, dispute_created"
        )
    )

    source: str = Field(
        ...,
        min_length=1,
        description=(
            "What triggered this event. One of: "
            "verify_session, stripe_webhook, admin_action, system_reconciliation, authz_review"
        )
    )

    # Stripe event correlation
    stripe_event_id: Optional[str] = Field(
        default=None,
        description="Stripe event ID for idempotency and correlation (e.g., evt_xxxxx)"
    )

    stripe_event_type: Optional[str] = Field(
        default=None,
        description="Stripe event type (e.g., invoice.paid, checkout.session.completed)"
    )

    # State snapshot for debugging and audit
    before_state: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Snapshot of subscription/credits state before this change"
    )

    after_state: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Snapshot of subscription/credits state after this change"
    )

    # Financial details
    amount_usd: Optional[float] = Field(
        default=None,
        ge=0,
        description="Transaction amount in USD (if applicable)"
    )

    stripe_invoice_id: Optional[str] = Field(
        default=None,
        description="Stripe Invoice ID associated with this event"
    )

    stripe_subscription_id: Optional[str] = Field(
        default=None,
        description="Stripe Subscription ID associated with this event"
    )

    stripe_session_id: Optional[str] = Field(
        default=None,
        description="Stripe Checkout Session ID (for verify-session/checkout events)"
    )

    # Promo/discount
    promo_code_applied: Optional[str] = Field(
        default=None,
        description="Promotion code applied in this transaction (e.g., LAUNCH20)"
    )

    discount_amount_usd: Optional[float] = Field(
        default=None,
        ge=0,
        description="Discount amount in USD applied via promo code"
    )

    # Processing metadata
    processed_timestamp_utc: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        description="When this event was processed by our system"
    )

    processing_result: str = Field(
        ...,
        description="Processing outcome: success, skipped_duplicate, failed, stale_event_ignored"
    )

    processing_error: Optional[str] = Field(
        default=None,
        description="Error message if processing_result is 'failed'"
    )
