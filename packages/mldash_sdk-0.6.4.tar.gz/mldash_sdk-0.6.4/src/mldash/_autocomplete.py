"""Local AI autocomplete engine using llama-cpp-python.

Downloads and runs Qwen2.5-Coder-1.5B (Q8_0 GGUF) for fill-in-the-middle
code completions. Used by the bridge to serve ghost-text suggestions to Studio.
"""

import os
import sys
import tempfile
import threading

from ._env import autocomplete_model_path, models_dir

MODEL_URL = (
    "https://huggingface.co/ggml-org/Qwen2.5-Coder-1.5B-Q8_0-GGUF"
    "/resolve/main/qwen2.5-coder-1.5b-q8_0.gguf"
)


def model_exists():
    """Check if the autocomplete model has been downloaded."""
    return os.path.isfile(autocomplete_model_path())


def model_path():
    """Return the autocomplete model path."""
    return autocomplete_model_path()


def download_model():
    """Download the autocomplete model from Hugging Face.

    Streams to a temp file first, then renames on success (atomic).
    Returns the path on success, None on failure.
    """
    import requests

    dest = autocomplete_model_path()
    if os.path.isfile(dest):
        return dest

    os.makedirs(models_dir(), exist_ok=True)

    print(f"Downloading autocomplete model...")
    print(f"  {MODEL_URL}")

    try:
        resp = requests.get(MODEL_URL, stream=True, timeout=30)
        resp.raise_for_status()

        total = int(resp.headers.get("content-length", 0))
        downloaded = 0

        # Write to temp file in the same directory (for atomic rename)
        fd, tmp_path = tempfile.mkstemp(dir=models_dir(), suffix=".tmp")
        try:
            with os.fdopen(fd, "wb") as f:
                for chunk in resp.iter_content(chunk_size=1024 * 1024):  # 1MB chunks
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total > 0:
                        pct = downloaded * 100 // total
                        mb_done = downloaded / (1024 * 1024)
                        mb_total = total / (1024 * 1024)
                        bar = "#" * (pct // 5) + "-" * (20 - pct // 5)
                        sys.stdout.write(
                            f"\r  [{bar}] {pct}% ({mb_done:.0f}/{mb_total:.0f} MB)"
                        )
                        sys.stdout.flush()

            print()  # newline after progress bar
            os.rename(tmp_path, dest)
            print(f"  Saved to {dest}")
            return dest

        except Exception:
            # Clean up temp file on failure
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
            raise

    except Exception as e:
        print(f"\n  Warning: Failed to download autocomplete model: {e}")
        return None


class AutocompleteEngine:
    """Manages a local LLM for code completions.

    Thread-safe: the model is guarded by a lock and generation can be
    cancelled by bumping the request ID.
    """

    def __init__(self):
        self._model = None
        self._lock = threading.Lock()
        self._loading = False
        self._loaded = False
        self._request_id = 0

    def load_in_background(self):
        """Start loading the model in a daemon thread."""
        if self._loaded or self._loading:
            return
        self._loading = True
        t = threading.Thread(target=self._load, daemon=True)
        t.start()

    def _load(self):
        """Load the GGUF model. Called from background thread."""
        try:
            from llama_cpp import Llama

            path = autocomplete_model_path()
            if not os.path.isfile(path):
                print("[autocomplete] Model file not found, skipping.")
                return

            print("[autocomplete] Loading model...")
            with self._lock:
                self._model = Llama(
                    model_path=path,
                    n_ctx=4096,
                    n_gpu_layers=-1,
                    verbose=False,
                )
            self._loaded = True
            print("[autocomplete] Model ready.")
        except Exception as e:
            print(f"[autocomplete] Failed to load model: {e}")
        finally:
            self._loading = False

    @property
    def ready(self):
        return self._loaded and self._model is not None

    async def complete(self, prefix, suffix, request_id):
        """Generate a completion asynchronously.

        Returns the completion text, or None if cancelled/unavailable.
        """
        if not self.ready:
            return None

        # Accept this request — any older in-flight request is now stale
        self._request_id = request_id

        import asyncio
        return await asyncio.to_thread(self._generate, prefix, suffix, request_id)

    def _generate(self, prefix, suffix, request_id):
        """Synchronous generation. Checks request_id for cancellation."""
        if self._request_id != request_id:
            return None  # A newer request arrived

        with self._lock:
            if self._request_id != request_id:
                return None

            try:
                result = self._model.create_completion(
                    prompt=prefix,
                    suffix=suffix,
                    max_tokens=64,
                    temperature=0.0,
                    stop=["\n\n", "\ndef ", "\nclass "],
                )
                # Check cancellation after generation
                if self._request_id != request_id:
                    return None

                text = result["choices"][0]["text"] if result.get("choices") else None
                return text or None
            except Exception:
                return None
