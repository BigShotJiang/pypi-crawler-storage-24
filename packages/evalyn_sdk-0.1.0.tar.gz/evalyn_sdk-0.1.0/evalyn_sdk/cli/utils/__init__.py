"""CLI utility modules."""

from .ui import Spinner, ProgressIndicator
from .config import (
    load_config,
    get_config_default,
    find_latest_dataset,
    resolve_dataset_path,
    _expand_env_vars,
)
from .loaders import (
    _load_callable,
    _get_module_callables,
    _suggest_similar,
)
from .llm_callers import (
    _ollama_caller,
    _openai_caller,
    _with_spinner,
    _build_llm_caller,
)
from .dataset_utils import (
    _extract_code_meta,
    _resolve_dataset_and_metrics,
    _dataset_has_reference,
    ProgressBar,
)
from .dataset_resolver import DatasetInfo, get_dataset, list_datasets
from .formatters import (
    is_json_format,
    print_if_table,
    print_error_if_table,
    output_json,
    print_table,
)
from .pipeline import PipelineStep, PipelineOrchestrator, PipelineState, StepResult
from .pipeline_steps import create_pipeline_steps
from .errors import fatal_error, warning
from .input_helpers import (
    truncate_text,
    get_bool_input,
    get_int_input,
    get_str_input,
    get_confidence,
)

__all__ = [
    # UI
    "Spinner",
    "ProgressIndicator",
    # Config
    "load_config",
    "get_config_default",
    "find_latest_dataset",
    "resolve_dataset_path",
    "_expand_env_vars",
    # Loaders
    "_load_callable",
    "_get_module_callables",
    "_suggest_similar",
    # LLM callers
    "_ollama_caller",
    "_openai_caller",
    "_with_spinner",
    "_build_llm_caller",
    # Dataset utils
    "_extract_code_meta",
    "_resolve_dataset_and_metrics",
    "_dataset_has_reference",
    "ProgressBar",
    # Dataset resolver
    "DatasetInfo",
    "get_dataset",
    "list_datasets",
    # Formatters
    "is_json_format",
    "print_if_table",
    "print_error_if_table",
    "output_json",
    "print_table",
    # Pipeline
    "PipelineStep",
    "PipelineOrchestrator",
    "PipelineState",
    "StepResult",
    "create_pipeline_steps",
    # Errors
    "fatal_error",
    "warning",
    # Input helpers
    "truncate_text",
    "get_bool_input",
    "get_int_input",
    "get_str_input",
    "get_confidence",
]
