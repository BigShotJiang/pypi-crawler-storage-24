from __future__ import annotations

import os
from typing import Any, Callable, Optional

from .storage.sqlite import SQLiteStorage
from .trace.otel import configure_default_otel
from .trace.tracer import EvalTracer

ALLOWED_METRIC_MODES = {"llm-registry", "llm-brainstorm", "bundle"}

_default_tracer: Optional[EvalTracer] = None


def get_default_tracer() -> EvalTracer:
    """Lazily create a tracer backed by local SQLite storage."""
    global _default_tracer
    if _default_tracer is None:
        _default_tracer = EvalTracer(SQLiteStorage())
        # Auto-enable OpenTelemetry spans unless explicitly disabled.
        otel_flag = os.getenv("EVALYN_OTEL", "on").lower()
        if otel_flag not in {"0", "off", "false"}:
            otel_tracer = configure_default_otel(
                service_name=os.getenv("EVALYN_OTEL_SERVICE", "evalyn"),
                exporter=os.getenv("EVALYN_OTEL_EXPORTER", "sqlite"),
                endpoint=os.getenv("EVALYN_OTEL_ENDPOINT"),
            )
            if otel_tracer:
                _default_tracer.attach_otel_tracer(otel_tracer)
    return _default_tracer


def configure_tracer(tracer: EvalTracer) -> None:
    """Override the module-level tracer (useful for tests or custom backends)."""
    global _default_tracer
    _default_tracer = tracer


def eval(
    func: Optional[Callable[..., Any]] = None,
    *,
    tracer: Optional[EvalTracer] = None,
    name: Optional[str] = None,
    project: Optional[str] = None,
    version: Optional[str] = None,
    is_simulation: bool = False,
    metric_mode: Optional[str] = None,
    metric_bundle: Optional[str] = None,
):
    """
    Decorator to trace sync/async functions. Example:

    @eval
    def my_agent(user_input: str) -> str:
        ...

    @eval(project="myproj", version="v1")
    def my_agent(user_input: str) -> str:
        ...

    @eval(is_simulation=True)  # For simulation/test runs
    def my_agent(user_input: str) -> str:
        ...

    is_simulation: Set to True for simulation/test runs (default: False for production)
    """

    def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
        tracer_obj = tracer or get_default_tracer()

        mode = metric_mode
        bundle = metric_bundle
        if mode and mode.startswith("bundle-") and not bundle:
            bundle = mode.split("bundle-", 1)[1] or None
            mode = "bundle"

        if mode and mode not in ALLOWED_METRIC_MODES:
            raise ValueError(
                f"Invalid metric_mode '{mode}'. Allowed: {sorted(ALLOWED_METRIC_MODES)}"
            )

        wrapped = tracer_obj.instrument(
            fn,
            name=name,
            project=project,
            version=version,
            is_simulation=is_simulation,
            metric_mode=mode,
            metric_bundle=bundle,
        )
        setattr(wrapped, "_evalyn_metric_mode", mode)
        setattr(wrapped, "_evalyn_metric_bundle", bundle)
        setattr(wrapped, "_evalyn_project", project)
        setattr(wrapped, "_evalyn_version", version)
        setattr(wrapped, "_evalyn_is_simulation", is_simulation)
        return wrapped

    if func is not None:
        return decorator(func)
    return decorator
