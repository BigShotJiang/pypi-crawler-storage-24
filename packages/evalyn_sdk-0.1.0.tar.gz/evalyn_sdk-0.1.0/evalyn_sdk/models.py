from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Literal, Optional
import uuid


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def _iso(dt: Optional[datetime]) -> Optional[str]:
    return dt.isoformat() if dt else None


def _parse_datetime(raw: Optional[str]) -> Optional[datetime]:
    if raw is None:
        return None
    return datetime.fromisoformat(raw)


def _default_id() -> str:
    return str(uuid.uuid4())


def _safe_details(data: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    return data or {}


# Span types for hierarchical tracing
SpanType = Literal[
    "session",  # Root session span
    "graph",  # LangGraph execution
    "node",  # LangGraph node
    "llm_call",  # LLM API call
    "tool_call",  # Tool/function call
    "retrieval",  # RAG retrieval
    "scorer",  # Metric evaluation
    "agent",  # Agent execution (Google ADK, Anthropic Agents, etc.)
    "custom",  # User-defined span
    # Semantic span kinds for fine-grained evaluation
    "input_message",  # User/system message input
    "output_message",  # Assistant message output
    "tool_use",  # Tool invocation request
    "tool_result",  # Tool execution result
]

SpanStatus = Literal["ok", "error", "running"]

# Evaluation unit types for span-level evaluation
EvalUnitType = Literal[
    "outcome",  # Full trace outcome (default, backward-compatible)
    "single_turn",  # Single LLM call: input -> output
    "tool_use",  # Tool invocation: request -> result
    "multi_turn",  # Consecutive exchanges in a conversation
    "custom",  # User-defined evaluation boundary
]


@dataclass
class Span:
    """
    A hierarchical span with parent-child relationships.

    Enables Phoenix/LangSmith-style trace visualization:

    Trace (run_agent)
     └── graph.execution
         ├── node (generate_query)
         │    └── llm_call (gemini-2.5-flash)
         └── node (finalize_answer)
              └── llm_call (gemini-2.5-flash)
     ├── scorer (helpfulness) ✓
     └── scorer (hallucination) ✗
    """

    id: str
    name: str
    span_type: str  # SpanType
    parent_id: Optional[str]  # Parent span ID (None for root)
    start_time: datetime
    end_time: Optional[datetime] = None
    status: str = "ok"  # SpanStatus
    attributes: Dict[str, Any] = field(default_factory=dict)

    # Computed properties
    @property
    def duration_ms(self) -> Optional[float]:
        if self.end_time and self.start_time:
            return (self.end_time - self.start_time).total_seconds() * 1000
        return None

    def as_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "span_type": self.span_type,
            "parent_id": self.parent_id,
            "start_time": _iso(self.start_time),
            "end_time": _iso(self.end_time),
            "status": self.status,
            "attributes": self.attributes,
            "duration_ms": self.duration_ms,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Span":
        return cls(
            id=data["id"],
            name=data["name"],
            span_type=data.get("span_type", "custom"),
            parent_id=data.get("parent_id"),
            start_time=_parse_datetime(data.get("start_time")) or now_utc(),
            end_time=_parse_datetime(data.get("end_time")),
            status=data.get("status", "ok"),
            attributes=data.get("attributes", {}),
        )

    @classmethod
    def new(
        cls,
        name: str,
        span_type: str,
        parent_id: Optional[str] = None,
        **attributes: Any,
    ) -> "Span":
        """Create a new span with auto-generated ID."""
        return cls(
            id=_default_id(),
            name=name,
            span_type=span_type,
            parent_id=parent_id,
            start_time=now_utc(),
            status="running",
            attributes=attributes,
        )

    def finish(self, status: str = "ok", **extra_attributes: Any) -> "Span":
        """Mark span as finished."""
        self.end_time = now_utc()
        self.status = status
        self.attributes.update(extra_attributes)
        return self


@dataclass
class TraceEvent:
    kind: str
    timestamp: datetime
    detail: Dict[str, Any] = field(default_factory=dict)
    span_id: Optional[str] = None  # Link to associated Span
    parent_span_id: Optional[str] = None  # Parent span for hierarchy

    def as_dict(self) -> Dict[str, Any]:
        result = {
            "kind": self.kind,
            "timestamp": _iso(self.timestamp),
            "detail": self.detail,
        }
        if self.span_id:
            result["span_id"] = self.span_id
        if self.parent_span_id:
            result["parent_span_id"] = self.parent_span_id
        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TraceEvent":
        return cls(
            kind=data["kind"],
            timestamp=_parse_datetime(data["timestamp"]) or now_utc(),
            detail=_safe_details(data.get("detail")),
            span_id=data.get("span_id"),
            parent_span_id=data.get("parent_span_id"),
        )


@dataclass
class FunctionCall:
    id: str
    function_name: str
    inputs: Dict[str, Any]
    output: Any
    error: Optional[str]
    started_at: datetime
    ended_at: Optional[datetime]
    duration_ms: Optional[float]
    session_id: Optional[str]
    trace: List[TraceEvent] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    # Hierarchical span support
    parent_call_id: Optional[str] = None  # Parent @eval call (for nested calls)
    spans: List[Span] = field(default_factory=list)  # Hierarchical span tree

    def as_dict(self) -> Dict[str, Any]:
        result = {
            "id": self.id,
            "function_name": self.function_name,
            "inputs": self.inputs,
            "output": self.output,
            "error": self.error,
            "started_at": _iso(self.started_at),
            "ended_at": _iso(self.ended_at),
            "duration_ms": self.duration_ms,
            "session_id": self.session_id,
            "trace": [t.as_dict() for t in self.trace],
            "metadata": self.metadata,
        }
        if self.parent_call_id:
            result["parent_call_id"] = self.parent_call_id
        if self.spans:
            result["spans"] = [s.as_dict() for s in self.spans]
        return result

    @classmethod
    def new(
        cls,
        function_name: str,
        inputs: Dict[str, Any],
        session_id: Optional[str],
        metadata: Optional[Dict[str, Any]] = None,
        parent_call_id: Optional[str] = None,
    ) -> "FunctionCall":
        return cls(
            id=_default_id(),
            function_name=function_name,
            inputs=inputs,
            output=None,
            error=None,
            started_at=now_utc(),
            ended_at=None,
            duration_ms=None,
            session_id=session_id,
            trace=[],
            metadata=metadata or {},
            parent_call_id=parent_call_id,
            spans=[],
        )

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "FunctionCall":
        return cls(
            id=data["id"],
            function_name=data["function_name"],
            inputs=data.get("inputs", {}),
            output=data.get("output"),
            error=data.get("error"),
            started_at=_parse_datetime(data.get("started_at")) or now_utc(),
            ended_at=_parse_datetime(data.get("ended_at")),
            duration_ms=data.get("duration_ms"),
            session_id=data.get("session_id"),
            trace=[TraceEvent.from_dict(t) for t in data.get("trace", [])],
            metadata=data.get("metadata", {}),
            parent_call_id=data.get("parent_call_id"),
            spans=[Span.from_dict(s) for s in data.get("spans", [])],
        )

    def add_span(self, span: Span) -> None:
        """Add a span to this call's span tree."""
        self.spans.append(span)

    def get_span_tree(self) -> Dict[str, Any]:
        """Build hierarchical span tree for visualization."""
        # Build lookup by id
        by_id = {s.id: {"span": s, "children": []} for s in self.spans}
        roots = []

        for s in self.spans:
            node = by_id[s.id]
            if s.parent_id and s.parent_id in by_id:
                by_id[s.parent_id]["children"].append(node)
            else:
                roots.append(node)

        return {"roots": roots, "by_id": by_id}


@dataclass
class EvalUnit:
    """
    An evaluatable unit discovered from trace structure.

    Units can represent different evaluation granularities:
    - outcome: Full trace (backward-compatible default)
    - single_turn: Single LLM call with input/output
    - tool_use: Tool invocation with request/result
    - multi_turn: Sequence of exchanges
    - custom: User-defined boundary
    """

    id: str
    unit_type: str  # EvalUnitType
    call_id: str  # Parent FunctionCall ID
    span_ids: List[str]  # Spans comprising this unit
    context: Dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "EvalUnit":
        return cls(
            id=data["id"],
            unit_type=data["unit_type"],
            call_id=data["call_id"],
            span_ids=data.get("span_ids", []),
            context=data.get("context", {}),
        )


@dataclass
class EvalView:
    """
    Projected view of an EvalUnit for metric evaluation.

    Provides a normalized interface regardless of unit type,
    allowing metrics to evaluate different granularities uniformly.
    """

    unit_id: str
    unit_type: str
    input: Any  # Projected input (varies by unit type)
    output: Any  # Projected output (varies by unit type)
    context: Dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> Dict[str, Any]:
        return asdict(self)


MetricType = Literal["objective", "subjective"]


@dataclass
class MetricSpec:
    id: str
    name: str
    type: MetricType
    description: str = ""
    config: Dict[str, Any] = field(default_factory=dict)
    why: str = ""
    # Unit types this metric can evaluate (default: ["outcome"] for backward compat)
    unit_types: List[str] = field(default_factory=lambda: ["outcome"])


@dataclass
class MetricResult:
    metric_id: str
    item_id: str
    call_id: str
    score: Optional[float]
    passed: Optional[bool]
    details: Dict[str, Any] = field(default_factory=dict)
    raw_judge: Optional[Dict[str, Any]] = None
    # Token usage for subjective metrics (LLM judge)
    input_tokens: Optional[int] = None
    output_tokens: Optional[int] = None
    model: Optional[str] = None
    # Unit-level evaluation fields (optional, for span-level evals)
    unit_id: Optional[str] = None
    unit_type: Optional[str] = None  # EvalUnitType
    span_ids: Optional[List[str]] = None

    def as_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MetricResult":
        return cls(
            metric_id=data["metric_id"],
            item_id=data["item_id"],
            call_id=data["call_id"],
            score=data.get("score"),
            passed=data.get("passed"),
            details=data.get("details", {}),
            raw_judge=data.get("raw_judge"),
            input_tokens=data.get("input_tokens"),
            output_tokens=data.get("output_tokens"),
            model=data.get("model"),
            unit_id=data.get("unit_id"),
            unit_type=data.get("unit_type"),
            span_ids=data.get("span_ids"),
        )


@dataclass
class SpanMetricLink:
    """Links a metric result to a specific span with relevance scoring."""

    id: str
    metric_result_id: str  # composite: metric_id:item_id:call_id
    span_id: str
    relevance: float  # 0.0-1.0
    reason: str
    run_id: str

    def as_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SpanMetricLink":
        return cls(
            id=data["id"],
            metric_result_id=data["metric_result_id"],
            span_id=data["span_id"],
            relevance=data.get("relevance", 0.0),
            reason=data.get("reason", ""),
            run_id=data["run_id"],
        )


class Metric:
    """Runtime metric that binds a spec to an evaluation function."""

    def __init__(
        self,
        spec: MetricSpec,
        handler: Callable[["FunctionCall", "DatasetItem"], MetricResult],
        unit_handler: Optional[
            Callable[["EvalView", "DatasetItem"], MetricResult]
        ] = None,
    ):
        self.spec = spec
        self.handler = handler
        self.unit_handler = unit_handler

    def evaluate(self, call: "FunctionCall", item: "DatasetItem") -> MetricResult:
        return self.handler(call, item)

    def evaluate_unit(self, view: "EvalView", item: "DatasetItem") -> MetricResult:
        """Evaluate a unit view. Falls back to handler with synthetic call if no unit_handler."""
        if self.unit_handler:
            return self.unit_handler(view, item)
        # Fallback: create synthetic call from view for backward compat
        synthetic_call = FunctionCall(
            id=view.unit_id,
            function_name="unit_eval",
            inputs={"input": view.input},
            output=view.output,
            error=None,
            started_at=now_utc(),
            ended_at=now_utc(),
            duration_ms=0,
            session_id=None,
        )
        return self.handler(synthetic_call, item)

    def supports_unit_type(self, unit_type: str) -> bool:
        """Check if this metric supports a given unit type."""
        return unit_type in self.spec.unit_types


class MetricRegistry:
    """Registry for managing multiple metrics."""

    def __init__(self):
        self._metrics: Dict[str, Metric] = {}

    def register(self, metric: Metric) -> None:
        self._metrics[metric.spec.id] = metric

    def get(self, metric_id: str) -> Optional[Metric]:
        return self._metrics.get(metric_id)

    def list(self) -> List[Metric]:
        return list(self._metrics.values())

    def apply_all(
        self, call: "FunctionCall", item: "DatasetItem"
    ) -> List[MetricResult]:
        return [metric.evaluate(call, item) for metric in self._metrics.values()]


@dataclass
class DatasetItem:
    """
    Represents a single evaluation item with 4 core columns:

    - input: User/system input to the agent
    - output: Agent/LLM response (captured from trace)
    - human_label: Human judgement/annotation (optional, for calibration)
    - metadata: Additional info (call_id, trace data, etc.)

    The old 'inputs' and 'expected' fields are kept for backwards compatibility.
    """

    id: str
    input: Dict[str, Any] = field(default_factory=dict)  # User input
    output: Optional[Any] = None  # Agent output
    human_label: Optional[Dict[str, Any]] = None  # Human judgement
    metadata: Dict[str, Any] = field(default_factory=dict)

    # Backwards compatibility
    inputs: Dict[str, Any] = field(default_factory=dict)  # Alias for input
    expected: Optional[Any] = None  # Deprecated

    def __post_init__(self):
        # Merge inputs into input for backwards compat
        if self.inputs and not self.input:
            self.input = self.inputs
        elif self.input and not self.inputs:
            self.inputs = self.input
        # Sync expected <-> output for backwards compat
        if self.expected is not None and self.output is None:
            self.output = self.expected
        elif self.output is not None and self.expected is None:
            self.expected = self.output

    def as_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "input": self.input,
            "output": self.output,
            "human_label": self.human_label,
            "metadata": self.metadata,
        }

    @classmethod
    def from_payload(cls, payload: Dict[str, Any]) -> "DatasetItem":
        # Support both old format (inputs/expected) and new format (input/output)
        input_data = payload.get("input") or payload.get("inputs", {})
        output_data = payload.get("output") or payload.get("expected")

        return cls(
            id=payload.get("id", _default_id()),
            input=input_data,
            output=output_data,
            human_label=payload.get("human_label"),
            metadata=payload.get("metadata", {}),
            inputs=input_data,  # Backwards compat
            expected=output_data,  # Backwards compat
        )

    @classmethod
    def from_call(cls, call: "FunctionCall") -> "DatasetItem":
        """Create a DatasetItem from a traced FunctionCall."""
        return cls(
            id=_default_id(),
            input=call.inputs,
            output=call.output,
            human_label=None,
            metadata={
                "call_id": call.id,
                "function": call.function_name,
                "duration_ms": call.duration_ms,
                "error": call.error,
                "session_id": call.session_id,
            },
            inputs=call.inputs,
            expected=None,
        )


@dataclass
class JudgeConfig:
    id: str
    model: str
    prompt: str
    parameters: Dict[str, Any] = field(default_factory=dict)
    version: str = "v0"


@dataclass
class EvalRun:
    id: str
    dataset_name: str
    created_at: datetime
    metric_results: List[MetricResult]
    metrics: List[MetricSpec] = field(default_factory=list)
    judge_configs: List[JudgeConfig] = field(default_factory=list)
    summary: Dict[str, Any] = field(default_factory=dict)
    # Token usage summary for LLM judge evaluations
    usage_summary: Dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "dataset_name": self.dataset_name,
            "created_at": _iso(self.created_at),
            "metric_results": [r.as_dict() for r in self.metric_results],
            "metrics": [asdict(m) for m in self.metrics],
            "judge_configs": [asdict(j) for j in self.judge_configs],
            "summary": self.summary,
            "usage_summary": self.usage_summary,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "EvalRun":
        return cls(
            id=data["id"],
            dataset_name=data["dataset_name"],
            created_at=_parse_datetime(data.get("created_at")) or now_utc(),
            metric_results=[
                MetricResult.from_dict(r) for r in data.get("metric_results", [])
            ],
            metrics=[MetricSpec(**m) for m in data.get("metrics", [])],
            judge_configs=[JudgeConfig(**j) for j in data.get("judge_configs", [])],
            summary=data.get("summary", {}),
            usage_summary=data.get("usage_summary", {}),
        )


@dataclass
class HumanLabel:
    """
    Human annotation for calibration.

    Schema for human judgement on (input, output, eval_result) tuples:
    - passed: Overall pass/fail judgement
    - scores: Per-metric human scores (0-1)
    - notes: Free-form notes from annotator
    - annotator: Annotator identifier
    - timestamp: When annotation was made
    """

    passed: bool
    scores: Dict[str, float] = field(default_factory=dict)
    notes: str = ""
    annotator: str = ""
    timestamp: datetime = field(default_factory=now_utc)

    def as_dict(self) -> Dict[str, Any]:
        return {
            "passed": self.passed,
            "scores": self.scores,
            "notes": self.notes,
            "annotator": self.annotator,
            "timestamp": _iso(self.timestamp),
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "HumanLabel":
        return cls(
            passed=data.get("passed", True),
            scores=data.get("scores", {}),
            notes=data.get("notes", ""),
            annotator=data.get("annotator", ""),
            timestamp=_parse_datetime(data.get("timestamp")) or now_utc(),
        )


@dataclass
class AnnotationItem:
    """
    Export format for human annotation workflow.

    Contains the (input, output, eval_results) tuple for annotators to review.
    """

    id: str
    input: Dict[str, Any]
    output: Any
    eval_results: Dict[str, Dict[str, Any]] = field(
        default_factory=dict
    )  # metric_id -> result
    human_label: Optional[HumanLabel] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "input": self.input,
            "output": self.output,
            "eval_results": self.eval_results,
            "human_label": self.human_label.as_dict() if self.human_label else None,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AnnotationItem":
        human_label_data = data.get("human_label")
        return cls(
            id=data.get("id", _default_id()),
            input=data.get("input", {}),
            output=data.get("output"),
            eval_results=data.get("eval_results", {}),
            human_label=HumanLabel.from_dict(human_label_data)
            if human_label_data
            else None,
            metadata=data.get("metadata", {}),
        )


@dataclass
class MetricLabel:
    """Human label for a specific metric."""

    metric_id: str
    agree_with_llm: bool  # Does human agree with LLM judge?
    human_label: bool  # Human's own judgement (pass/fail)
    notes: str = ""

    def as_dict(self) -> Dict[str, Any]:
        return {
            "metric_id": self.metric_id,
            "agree_with_llm": self.agree_with_llm,
            "human_label": self.human_label,
            "notes": self.notes,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MetricLabel":
        return cls(
            metric_id=data.get("metric_id", ""),
            agree_with_llm=data.get("agree_with_llm", True),
            human_label=data.get("human_label", True),
            notes=data.get("notes", ""),
        )


@dataclass
class Annotation:
    """
    Human annotation for an eval item.

    Supports two modes:
    1. Simple mode: Just overall label (bool) for backwards compatibility
    2. Per-metric mode: metric_labels dict with per-metric human judgements

    confidence: 1-5 scale (1=very uncertain, 5=very confident)
    """

    id: str
    target_id: str
    label: Any  # Overall pass/fail (bool) - for backwards compat
    rationale: Optional[str]
    annotator: str
    source: str = "human"
    confidence: Optional[int] = None  # 1-5 scale
    metric_labels: Dict[str, MetricLabel] = field(
        default_factory=dict
    )  # metric_id -> MetricLabel
    created_at: datetime = field(default_factory=now_utc)

    def as_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "target_id": self.target_id,
            "label": self.label,
            "rationale": self.rationale,
            "annotator": self.annotator,
            "source": self.source,
            "confidence": self.confidence,
            "metric_labels": {k: v.as_dict() for k, v in self.metric_labels.items()},
            "created_at": _iso(self.created_at),
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Annotation":
        metric_labels_raw = data.get("metric_labels", {})
        metric_labels = {
            k: MetricLabel.from_dict(v)
            for k, v in metric_labels_raw.items()
            if isinstance(v, dict)
        }
        return cls(
            id=data["id"],
            target_id=data["target_id"],
            label=data.get("label"),
            rationale=data.get("rationale"),
            annotator=data.get("annotator", "unknown"),
            source=data.get("source", "human"),
            confidence=data.get("confidence"),
            metric_labels=metric_labels,
            created_at=_parse_datetime(data.get("created_at")) or now_utc(),
        )


@dataclass
class CalibrationRecord:
    id: str
    judge_config_id: str
    gold_items: List[str]
    adjustments: Dict[str, Any]
    created_at: datetime = field(default_factory=now_utc)
    # Token usage summary for calibration (LLM optimizer calls)
    usage_summary: Dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "judge_config_id": self.judge_config_id,
            "gold_items": self.gold_items,
            "adjustments": self.adjustments,
            "created_at": _iso(self.created_at),
            "usage_summary": self.usage_summary,
        }
