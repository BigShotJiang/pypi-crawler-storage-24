# vue-collector

Утилита для сборки Vue single-file components (.vue) в отдельные JS/CSS файлы или в один HTML файл.

## Структура проекта

```
src/vue_collector/
├── __init__.py      # публичный API: VueComponent, VueSectionError, collect_vue,
│                    # find_vue_files, prepare_compiled, prepare_assets, write_assets
├── __main__.py      # точка входа: python -m vue_collector
├── cli.py           # main() — argparse CLI, команда format
├── collector.py     # VueComponent, collect_vue, prepare_compiled,
│                    # prepare_assets, write_assets, find_vue_files,
│                    # _escape_js_template, _content_hash
├── script.py        # _js_advance, _has_import, _extract_export_default, _parse_script
├── style.py         # _compile_style, _scope_ast (lesscpy AST), _parser (singleton LessParser)
├── template.py      # CustomHTML (парсер .vue секций, валидация HTML)
├── util.py          # VueSectionError, _make_template_name, _make_scope_id
└── format/
    ├── __init__.py  # публичный API: format_vue_dir
    ├── vue.py       # format_vue_dir, _format_vue_file_content
    ├── script.py    # _format_script, _scan_line, _skip_regex
    ├── style.py     # _format_style (через lesscpy PLY tokenizer)
    └── template.py  # _format_template, _TemplateFormatter
tests/
├── fixtures/            # .vue файлы для test_collector.py и test_assets.py
│   ├── Card.vue
│   ├── Counter.vue
│   ├── ItemList.vue
│   └── Static.vue
├── test_assets.py       # тесты _escape_js_template, _content_hash, prepare_assets, write_assets
├── test_collector.py    # end-to-end тесты верхнего уровня API
├── test_errors.py       # тесты VueSectionError и всех путей ошибок
├── test_format.py       # тесты format/ — script, style, template, vue, dir
├── test_script.py       # тесты _extract_export_default, _parse_script
├── test_style.py        # тесты _compile_style (LESS, scoped, at-rules)
├── test_template.py     # тесты CustomHTML
└── test_util.py         # тесты _make_template_name, _make_scope_id
```

## Окружение

- Python: `.venv/bin/python` (Python 3.11.14, создано через `uv`)
- Установка зависимостей: `uv pip install --python .venv/bin/python <пакет>`
- Зависимости: `lesscpy`, `six` (транзитивная для lesscpy internals), `ruff` (dev)

## Команды

```bash
# Тесты
PYTHONPATH=src .venv/bin/python -m unittest discover -s tests -v

# Линтинг и форматирование
.venv/bin/ruff check src/ tests/
.venv/bin/ruff format src/ tests/

# CLI format
PYTHONPATH=src .venv/bin/python -m vue_collector format <dir>
```

## Соглашения кода

- Python 3.11+, типизация везде: `str | None`, `list[str]`, `dict[str, int]`
- Приватные helper-функции с префиксом `_` (не методы — чистые, тестируемые по отдельности)
- Ruff: одиночные кавычки, длина строки 120, правила E/W/F/I/N
- Тесты: `unittest.TestCase`; `assertEqual` для точного сравнения строк; `assertIn` допустим в `test_collector.py`, `test_errors.py`, `test_assets.py`
- Тесты запускаются через `PYTHONPATH=src`; `sys.path` в тестах не модифицируется
- В тестах нет моков lesscpy — всегда используется настоящая компиляция через singleton `_parser`

## Архитектурные решения

### VueSectionError (util.py)
- Единственный тип ошибок, публично экспортируемый из `vue_collector`
- Наследует `ValueError` для обратной совместимости
- Атрибуты: `file_name: str`, `section: str | None`, `message: str`
- `section = None` — структурные ошибки файла (дубликаты секций, незакрытые теги)
- `section = 'script' | 'style'` — ошибки содержимого секции
- Формат `str(err)`: `'Foo.vue [script]: ...'` или `'Foo.vue: ...'` (без section)

### CustomHTML (template.py)
- Наследует `HTMLParser`, извлекает секции `<template>`, `<script>`, `<style>`
- `ROOT_TAGS` и `VOID_ELEMENTS` — `frozenset[str]`
- `root_attrs` — атрибуты root-тегов (`<style scoped>` и т.п.)
- `is_scoped() -> bool` — True если у `<style>` есть атрибут `scoped`
- `scope_id: str | None` — если задан, инжектирует `data-v-{scope_id}` на все элементы внутри `<template>`
- `_is_root_boundary(tag) -> bool` — True если тег является root-тегом и никакой другой root-тег сейчас не открыт (используется в `handle_starttag` и `handle_endtag`)
- **Валидация структуры** (все ошибки — `ValueError`):
  - Дублирующиеся секции: `Duplicate <script> section`
  - Незакрытые root-секции: выявляются методом `validate()` после `feed()`
  - Незакрытые внутренние теги: `Unclosed tag <div> in <template>`
  - Несовпадающие теги: `Mismatched tag: expected </span>, got </div>`
  - Лишние закрывающие теги: `Unexpected closing tag </div> in <template>`
- `handle_startendtag` вызывает `_append_open_tag(self_closing=True)` напрямую — самозакрывающиеся элементы (`<MyComp />`) не попадают в `inner_stack`
- `validate()` — вызывается в `VueComponent.__init__` после `feed()`, проверяет что все `levels == 0`

### _js_advance / _extract_export_default / _has_import (script.py)
- `_js_advance(code, i) -> int` — общий хелпер: пропускает строковый литерал (`'`, `"`, `` ` ``) или комментарий (`//`, `/* */`) начиная с позиции `i`, возвращает новый индекс
- `_extract_export_default` — мини-лексер с подсчётом скобок; использует `_js_advance`
  - Возвращает `(before, component_body, after)` — код до и после `export default {}`
  - Если `export default` не найден — возвращает `(script, '', '')`
- `_has_import(code)` — детекция `import ...` на границах выражений; использует `_js_advance`
- `_parse_script` проверяет импорты ДО проверки на отсутствие export default

### VueComponent (collector.py)
- Принимает `file_name` и `content`, парсит всё в `__init__`
- Атрибуты: `name`, `template_name`, `template`, `raw_template`, `variables`, `component`, `style`
- `template` — `<template id="...">...</template>` (для HTML-режима)
- `raw_template` — сырой HTML из `<template>` без обёртки (для assets-режима)
- Два прохода парсинга при `<style scoped>`: первый для детекции, второй с `scope_id`
- Каждая секция обёрнута в `try/except ValueError → VueSectionError(file_name, section, ...)`
- HTML-ошибки (feed + validate) → `VueSectionError(file_name, None, ...)`
- Script-ошибки → `VueSectionError(file_name, 'script', ...)`
- Style-ошибки → `VueSectionError(file_name, 'style', ...)`

### _compile_style (style.py)
- Перед компиляцией проверяет `@import` в любой строке → `ValueError`
- `CompilationError` от lesscpy оборачивается в `ValueError('CSS compilation error: ...')`
- `_scope_ast(nodes, scope_id)` обходит lesscpy AST (`Block` → `Identifier.parsed`) и добавляет токен `[data-v-{id}]` в конец каждого списка селектора
- `@keyframes`, `@font-face` — passthrough (не скопируются)
- `@media` — `block.name.subparse = True`, рекурсируем в `inner`
- Единый путь для scoped и non-scoped: используется модульный singleton `_parser: LessParser`
- При `CompilationError` singleton пересоздаётся (`_parser = LessParser(...)`) перед re-raise, т.к. PLY-парсер повреждается при исключении

### collect_vue / find_vue_files (collector.py)
- `collect_vue(vue_dir) -> Generator[VueComponent]` — итерирует все `.vue` файлы в директории
  - Возвращает объекты `VueComponent` (не dict)
- `find_vue_files(base_dir) -> list[str]` — рекурсивный поиск через `pathlib.Path.rglob('*.vue')`

### prepare_assets / write_assets (collector.py)
- `prepare_assets(vue_dir, extra_js='') -> tuple[str, str]` — возвращает `(js, css)` в памяти
  - `vue_dir` — прямой путь к директории с `.vue` файлами
  - JS содержит module-level переменные (`variables` каждого компонента) и функцию `initComponents(app)`
  - `initComponents` регистрирует компоненты через `app.component()` с inline backtick-шаблонами
  - `extra_js` (если передан) вставляется в начало JS-файла
- `write_assets(vue_dir, output_dir, extra_js='') -> tuple[str, str]` — пишет файлы на диск
  - Имена файлов: `components.{hash}.js` / `components.{hash}.css`
  - Хэш — первые 16 символов SHA-256 содержимого всех `.vue` файлов (отсортированных)
- `_escape_js_template(s)` — экранирует `` ` ``, `${`, `\` для встраивания в JS template literal
- `_content_hash(vue_dir)` — 16-символьный hex SHA-256 всех `.vue` файлов в директории

### prepare_compiled (collector.py)
- `prepare_compiled(template, vue_dir) -> str`
  - `vue_dir` — прямой путь к директории с `.vue` файлами

### Запрещённое в .vue файлах
- `import` в `<script>` (строки начинающиеся с `import ` или `import{`)
- `@import` в `<style>`
- Несколько `<template>`, `<script>` или `<style>` секций в одном файле
- Незакрытые или несовпадающие теги в `<template>`
- `export default` — единственный поддерживаемый способ объявления компонента

## Режимы сборки

### HTML-режим (`prepare_compiled`)
Плейсхолдеры в `template.html`:
- `<|style|>` — скомпилированный CSS
- `<|templates|>` — `<template id="...">` теги
- `<|variables|>` — JS-переменные вне export default
- `<|components|>` — `app.component(...)` вызовы с `template: '#id'`

### Assets-режим (`prepare_assets` / `write_assets`)
Выходные файлы:
- `components.{hash}.js` — module-level переменные + `function initComponents(app) { ... }`
- `components.{hash}.css` — конкатенированный минифицированный CSS

## CLI (format)

### Команда `format`
`vue-collector format <dir>` — форматирует все `.vue` файлы в директории in-place.

### format/vue.py
- `format_vue_dir(vue_dir) -> list[str]` — возвращает список изменённых файлов
- `_format_vue_file_content(content) -> str` — форматирует одиночный файл; при ошибке валидации возвращает оригинал без изменений
- Порядок секций в выходном файле: `<template>`, `<style>`, `<script>`

### format/script.py
- `_format_script(js) -> str` — переиндентирует JS, 2 пробела на уровень
- `_scan_line(line, in_template, in_block_comment) -> (opens, closes, in_template, in_block_comment)` — подсчитывает `{`/`}` вне строк/комментариев/regex
- `_skip_regex(line, i) -> int` — пропускает JS regex literal (`/…/flags`), обрабатывает `\/` и `[…]`
- `prev_was_operand` флаг в `_scan_line` — определяет контекст `/`: regex или деление
- Открывающая строка multiline template literal: `line.lstrip()` (не `strip()`) — trailing spaces сохраняются
- Строки внутри template literal: `line` без rstrip — содержимое не модифицируется

### format/style.py
- `_format_style(css) -> str` — форматирует CSS/LESS через lesscpy PLY tokenizer (не компиляцию)
- Использует `_style_module._parser.lex.lexer.clone()` — заимствует lexer из singleton

### format/template.py
- `_format_template(html) -> str` — переформатирует HTML через `_TemplateFormatter(HTMLParser)`
- `_TemplateFormatter` — indent-based formatter, void elements получают ` />`
- SVG атрибуты нормализуются через `_SVG_ATTR_CASE_MAP` из `template.py`

## PyPI

- Пакет: `vue-collector`, модуль: `vue_collector`
- Build: hatchling (`packages = ["src/vue_collector"]`)
- Сборка: `uv build` / `hatch build`
