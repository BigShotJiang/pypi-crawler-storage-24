# Kiwi AI CLI - LLM Understanding

This document summarizes the architecture and behavior of this repository so an LLM (or a new contributor) can quickly understand how the Kiwi AI CLI agent works.

## Repository layout (git-tracked)

- README.md: End-user installation and usage.
- pyproject.toml: Packaging metadata, dependencies, console entrypoint.
- src/kiwi_cli/__init__.py: Package marker and __version__.
- src/kiwi_cli/main.py: Main implementation (auth, websocket client, execution, PTY, restricted mode).
- .gitignore: Standard Python ignores.
- .DS_Store: macOS Finder metadata (currently tracked; usually should be ignored).

There are no tests and no extra modules. Nearly all logic lives in src/kiwi_cli/main.py.

## What this project is

kiwi-ai-cli is a Python CLI that runs on a user machine and connects to Kiwi AI servers. After authenticating, it maintains a WebSocket connection and executes shell commands (and interactive shell sessions) requested by a remote LLM-driven agent, returning stdout and stderr back over the socket.

Primary goals:
- Provide a bridge between an AI agent and a real terminal.
- Safer default via restricted mode that limits filesystem access to an allowlist of directories.
- Support both one-shot commands and interactive (persistent) sessions.

## Packaging and entrypoint

From pyproject.toml:
- Package name: kiwi-ai-cli
- Console script: kiwi = kiwi_cli.main:main
- Dependencies: websockets, httpx, psutil

## CLI surface

Implemented subcommands (argparse):
- kiwi connect

Key flags for kiwi connect:
- --server: preset (app, dev, local) or a custom base URL
- --email: email (prompts if omitted)
- --token: access token to skip login (or env var KIWI_AUTH_TOKEN)
- --scope: restricted (default) or full
- --allow PATH: add extra allowed directories in restricted scope

## Runtime flow

### 1) Resolve server URLs
main() resolves --server using presets in SERVER_PRESETS or by inferring WebSocket and HTTP variants from the provided scheme.

### 2) Authenticate (HTTP)
Function: login(http_base_url, email, password) -> access_token
- Sends a form-encoded POST request to the auth endpoint (path v1/auth/token).
- Expects JSON containing access_token.
- Raises a descriptive exception on failure.

If --token or KIWI_AUTH_TOKEN is provided, interactive login is skipped.

### 3) Connect and listen (WebSocket)
Function: connect(ws_url, token, mode, allowed_dirs)
- Connects to websocket path v1/terminal/ws/connect.
- Sends an auth message with the token.
- Waits for auth_ok (or fails fast on error).
- Enters an async receive loop and reacts to messages from the server.

## WebSocket message types handled by the client

Within connect(), the client handles:

- command (one-shot execution)
  - Input: request_id, command
  - Executes run_command()
  - Reply: type=result with request_id, stdout, stderr, exit_code

- pty_start (start an interactive session)
  - Input: session_id, command (default bash), cols, rows
  - Starts a PTY-backed session on Unix-like systems, and a piped persistent shell on Windows
  - Reply: type=pty_started with session_id, platform, mode, and allowed_dirs in restricted mode

- pty_input (write input to an interactive session)
  - Validates the input in restricted mode (prevents path escapes)
  - Windows: ensures a completion sentinel wrapper is present and arms a watchdog timeout

- pty_close (close and cleanup)
- pty_interrupt (attempt to interrupt)
- pty_restart (restart the shell process; mainly for Windows)
- ping (reply pong)

Unknown types are logged.

## Command execution

### One-shot commands: run_command()
- Uses asyncio.create_subprocess_shell().
- In restricted mode, calls validate_command() first.
- If allowed_dirs is set, runs commands with cwd=allowed_dirs[0].
- Captures stdout and stderr and truncates each to MAX_OUTPUT_BYTES (50KB).
- Enforces a timeout (default 120 seconds).

### Interactive sessions

Unix-like systems: PTYProcess
- Allocates a pseudo-terminal and spawns a shell with PTY-connected stdin and stdout.
- Reads output from the PTY master fd and forwards chunks as pty_output messages.
- Sends pty_exited when the process ends.

Windows: PipeProcess
- Spawns a persistent shell (typically cmd.exe) with piped stdin and combined stdout.
- Continuously reads and forwards output.
- Supports interruption and uses psutil to kill child processes when needed.
- Implements a watchdog: if completion is not detected within a configured timeout, it interrupts and restarts the shell.

## Restricted mode (allowlisted filesystem access)

Restricted mode is designed to reduce risk by blocking commands that reference paths outside an allowlist.

Allowlist construction (scope restricted):
- allowed_dirs starts with the real path of the current working directory
- each --allow directory is resolved to a real path and appended

Validation strategy:
Function: validate_command(command, allowed_dirs, pid=None) -> (ok, reason)
- Extracts path-like tokens (shlex.split when possible)
- Also scans for paths embedded inside quoted strings
- Resolves candidates by expanding home references, making relative paths absolute using the actual shell current working directory (when available), normalizing traversal, and resolving symlinks
- Blocks if any resolved path falls outside all allowed roots

Validation is applied both for one-shot commands and for interactive pty_input data.

## Sentinel integration (completion detection)

The code references a completion sentinel _SENTINEL intended to match server-side tooling (comment references terminal_tool.py). It is used to:
- Strip wrappers from displayed commands (cleaning PTY input for logs)
- Detect command completion in Windows persistent shells
- Ensure Windows persistent sessions always emit a completion marker

In this repository snapshot, _SENTINEL is referenced but not defined in main.py. That would raise NameError at runtime when the module-level regex patterns are created. This likely needs a constant added (or imported) to make the client functional and compatible with the server.

## UX and logging
- Prints an ANSI banner on startup
- Logs each received command with a short request or session prefix
- Prints the configured mode and allowed directories at startup in restricted mode

## Notable inconsistencies and cleanup opportunities
1) Version mismatch
- pyproject.toml version is 0.1.5
- src/kiwi_cli/__init__.py reports 0.1.0

2) Missing _SENTINEL
- Define _SENTINEL and document the required server contract

3) Repo hygiene
- .DS_Store is tracked; consider ignoring and removing from git

## Suggested next steps
- Split main.py into smaller modules (auth, protocol, execution, restrictions)
- Add unit tests for validate_command() (quoting, traversal, symlinks, platform-specific path forms)
- Add a small mock server for protocol-level tests
- Document the exact websocket message schema and sentinel behavior
