/* An array of initialization methods to run. */
let inits = [];

/* View tabs. */
let tabs = {};
let shown_tab = "UNKNOWN";

/*
 * Create a worker from our 'text/js-worker' element.
 */
const worker = new Worker(window.URL.createObjectURL(new Blob(
    Array.prototype.map.call(
        document.querySelectorAll("script[type='text\/js-worker']"),
        (script) => script.textContent,
        ),
    {type : "module"},
    )));

/*
 * Utility methods.
 */

function setupCursorContext(elem, registerMethod) {
  /* Mouse and touch. */
  let startEvents = [ "mousedown", "touchstart" ];
  let moveEvents = [ "mousemove", "touchmove" ];
  let endEvents = [ "mouseup", "touchend" ];

  for (let i = 0; i < startEvents.length; i++) {
    registerMethod(elem, startEvents[i], moveEvents[i], endEvents[i]);
  }
}

function setupCursorMove(elem, down, move, up, handleMove) {
  elem.addEventListener(down, (event) => {
    elem.classList.add("moving");

    document.addEventListener(move, handleMove);
    document.addEventListener(up, (event) => {
      document.removeEventListener(move, handleMove);
      elem.classList.remove("moving");
    }, {once : true});
  }, {passive : true});
}

function randomHexColor() {
  return "#" + (Math.random() * 0xFFFFFF << 0).toString(16).padStart(6, "0");
}

function isModifierKeyEvent(event) {
  return event.key == "Shift" || event.key == "Control" ||
         event.key == "Meta" || event.key == "Alt";
}

function ignoreFilterKeyEvent(event) {
  return isModifierKeyEvent(event) || event.key == "Tab" ||
         (event.key.startsWith("F") && event.key.length > 1) ||
         event.key.startsWith("Del") || event.key == "Home" ||
         event.key == "End" || event.key == "PageUp" || event.key == "PageDown";
}

function globalKeyEvent(event) {
  // (common)
  // keybind for dedent (ctrl-d?) + expand (ctrl-e?)
  // toggle tabs + toggle channel table
  return false;
}

/* Load settings control mappings. */
let settings = {};

function loadSettings() {
  for (const key of ["min-tx-period-ms"]) {
    let elem = document.getElementById(`setting-${key}`);
    if (elem) {
      settings[key] = elem;
    }
  }
}
