"""Provider management for LLM configuration."""

from copy import deepcopy
from functools import lru_cache

from pydantic import SecretStr
from pydantic_ai._json_schema import JsonSchema, JsonSchemaTransformer
from pydantic_ai.models import Model
from pydantic_ai.models.anthropic import AnthropicModel, AnthropicModelSettings
from pydantic_ai.models.google import GoogleModel
from pydantic_ai.models.openai import OpenAIChatModel, OpenAIResponsesModel
from pydantic_ai.profiles import ModelProfile
from pydantic_ai.providers.anthropic import AnthropicProvider
from pydantic_ai.providers.google import GoogleProvider
from pydantic_ai.providers.openai import OpenAIProvider
from pydantic_ai.settings import ModelSettings

from shotgun.llm_proxy import (
    create_anthropic_proxy_provider,
    create_litellm_provider,
)
from shotgun.logging_config import get_logger

from .manager import get_config_manager
from .models import (
    MODEL_SPECS,
    OLLAMA_PLACEHOLDER_API_KEY,
    OPENROUTER_BASE_URL,
    KeyProvider,
    ModelConfig,
    ModelName,
    ProviderType,
    ShotgunConfig,
    get_ollama_api_base_url,
    get_ollama_model_name,
    get_sub_agent_model,
    is_ollama_model,
)
from .streaming_test import check_streaming_capability

logger = get_logger(__name__)


class OllamaCompatibleJsonSchemaTransformer(JsonSchemaTransformer):
    """JSON schema transformer optimized for Ollama/OpenAI-compatible endpoints.

    This transformer:
    1. Inlines $defs references (required for Ollama which doesn't support $ref)
    2. Simplifies nullable unions (anyOf with null) to just the non-null type

    Ollama's model templates don't support `anyOf` in tool parameter schemas,
    which causes template errors like:
    "template: :108:130: error calling index: reflect: slice index out of range"

    This transformer converts schemas like:
        {"anyOf": [{"type": "array", "items": {"type": "string"}}, {"type": "null"}]}
    to:
        {"type": "array", "items": {"type": "string"}}
    """

    def __init__(self, schema: JsonSchema, *, strict: bool | None = None):
        super().__init__(schema, strict=strict, prefer_inlined_defs=True)

    def transform(self, schema: JsonSchema) -> JsonSchema:
        """Transform the schema to be compatible with Ollama."""
        # Remove anyOf nullable unions - Ollama doesn't support them
        if "anyOf" in schema:
            schema = self._simplify_anyof_nullable(schema)
        if "oneOf" in schema:
            schema = self._simplify_oneof_nullable(schema)
        return schema

    def _simplify_anyof_nullable(self, schema: JsonSchema) -> JsonSchema:
        """Simplify anyOf nullable unions to just the non-null type."""
        any_of = schema.get("anyOf", [])
        if len(any_of) == 2:
            # Check if one is null type
            non_null_schemas = [s for s in any_of if s.get("type") != "null"]
            null_schemas = [s for s in any_of if s.get("type") == "null"]

            if len(null_schemas) == 1 and len(non_null_schemas) == 1:
                # This is a nullable union - use just the non-null schema
                result: JsonSchema = deepcopy(non_null_schemas[0])
                # Preserve other fields from the original schema (like default, description)
                for key, value in schema.items():
                    if key != "anyOf" and key not in result:
                        result[key] = value
                return result

        # Not a simple nullable union, keep as-is (may cause issues with Ollama)
        return schema

    def _simplify_oneof_nullable(self, schema: JsonSchema) -> JsonSchema:
        """Simplify oneOf nullable unions to just the non-null type."""
        one_of = schema.get("oneOf", [])
        if len(one_of) == 2:
            non_null_schemas = [s for s in one_of if s.get("type") != "null"]
            null_schemas = [s for s in one_of if s.get("type") == "null"]

            if len(null_schemas) == 1 and len(non_null_schemas) == 1:
                result: JsonSchema = deepcopy(non_null_schemas[0])
                for key, value in schema.items():
                    if key != "oneOf" and key not in result:
                        result[key] = value
                return result

        return schema


# Max number of cached Model instances (LRU eviction)
_MAX_MODEL_CACHE_SIZE = 8


# Module-level model override for OpenAI-compatible mode (set via --model CLI flag)
_openai_compat_model_override: str | None = None
_openai_compat_sub_agent_model_override: str | None = None

# Default model for OpenAI-compatible endpoints
OPENAI_COMPAT_DEFAULT_MODEL = "gpt-5.2"


def set_openai_compat_model(model: str | None) -> None:
    """Set the model override for OpenAI-compatible endpoints.

    This is called by the CLI when --model is specified.

    Args:
        model: Model name to use, or None to use the default.
    """
    global _openai_compat_model_override
    _openai_compat_model_override = model


def set_openai_compat_sub_agent_model(model: str | None) -> None:
    """Set the sub-agent model override for OpenAI-compatible endpoints.

    This is called by the CLI when --sub-agent-model is specified.

    Args:
        model: Model name to use for sub-agents, or None to use the main model.
    """
    global _openai_compat_sub_agent_model_override
    _openai_compat_sub_agent_model_override = model


# Module-level general model override (set via --model CLI flag for non-OpenAI-compat providers)
_general_model_override: ModelName | None = None


def set_general_model_override(model: ModelName | None) -> None:
    """Set the general model override for all providers.

    This is called by the CLI when --model resolves to a known ModelName.
    It applies to Shotgun Account, OpenRouter, and BYOK providers (not OpenAI-compat).
    The override is transient (session-only) and does not persist to config.

    Args:
        model: ModelName to use, or None to clear the override.
    """
    global _general_model_override
    _general_model_override = model


def _create_openai_compat_model(
    api_key: str, model_name: str, max_tokens: int, base_url: str | None = None
) -> Model:
    """Create a model for OpenAI-compatible endpoints.

    Uses the provided base_url or falls back to SHOTGUN_OPENAI_COMPAT_BASE_URL
    from settings to configure the provider with a custom base URL.

    Args:
        api_key: API key for the endpoint
        model_name: Name of the model to use (may include "ollama/" prefix)
        max_tokens: Maximum output tokens
        base_url: Base URL for the endpoint (optional, falls back to settings)

    Returns:
        Configured OpenAI-compatible Model instance
    """
    from shotgun.settings import settings

    if not base_url:
        base_url = settings.openai_compat.base_url
    if not base_url:
        raise ValueError("base_url is required for OpenAI-compatible mode")

    # Strip "ollama/" prefix if present - Ollama expects just the model name
    # The prefix is used internally to identify Ollama models in the config
    is_ollama = is_ollama_model(model_name)
    if is_ollama:
        model_name = get_ollama_model_name(model_name)
        # Ensure the base URL includes /v1 for OpenAI compatibility
        base_url = get_ollama_api_base_url(base_url)

    # Use OpenAI provider with custom base_url
    openai_provider = OpenAIProvider(api_key=api_key, base_url=base_url)

    # Create a profile that handles Ollama/OpenAI-compatible schema limitations:
    # - Inlines $defs references (Ollama doesn't support $ref)
    # - Simplifies nullable anyOf unions (Ollama templates don't support anyOf)
    compat_profile = ModelProfile(
        json_schema_transformer=OllamaCompatibleJsonSchemaTransformer,
    )

    logger.info(
        "Creating OpenAI-compatible model with OllamaCompatibleJsonSchemaTransformer: %s",
        model_name,
    )

    # Use OpenAIChatModel for broad compatibility with OpenAI-compatible APIs
    return OpenAIChatModel(
        model_name,
        provider=openai_provider,
        profile=compat_profile,
        settings=ModelSettings(max_tokens=max_tokens),
    )


def _resolve_multi_provider_model(
    config: ShotgunConfig,
    provider_or_model: ProviderType | ModelName | None,
    for_sub_agent: bool,
) -> ModelName:
    """Resolve which ModelName to use for multi-provider backends (Shotgun Account, OpenRouter).

    Encapsulates the logic for determining the model when the backend supports all providers.

    Args:
        config: Shotgun configuration
        provider_or_model: Explicit model, provider hint, or None for auto-selection
        for_sub_agent: If True, substitute a cheaper model for cost optimization

    Returns:
        Resolved ModelName
    """
    if isinstance(provider_or_model, ModelName):
        # Specific model requested - honor it (e.g., web search tools)
        model_name = provider_or_model
    elif isinstance(provider_or_model, ProviderType):
        # Specific provider requested - use default model for that provider
        provider_defaults = {
            ProviderType.OPENAI: ModelName.GPT_5_2,
            ProviderType.ANTHROPIC: ModelName.CLAUDE_OPUS_4_6,
            ProviderType.GOOGLE: ModelName.GEMINI_3_FLASH_PREVIEW,
        }
        selected = (
            config.selected_model
            if isinstance(config.selected_model, ModelName)
            else get_default_model_for_provider(config)
        )
        model_name = provider_defaults.get(provider_or_model, selected)
    else:
        # No specific model requested - check general override first, then selected/default
        if _general_model_override is not None:
            model_name = _general_model_override
        elif isinstance(config.selected_model, ModelName):
            model_name = config.selected_model
        else:
            model_name = get_default_model_for_provider(config)

    # Gracefully fall back if the selected model doesn't exist (backwards compatibility)
    if model_name not in MODEL_SPECS:
        model_name = get_default_model_for_provider(config)

    # Apply sub-agent model mapping for cost optimization
    if for_sub_agent:
        original_model = model_name
        model_name = get_sub_agent_model(model_name)
        if model_name != original_model:
            logger.debug(
                "Sub-agent model substitution: %s -> %s",
                original_model.value,
                model_name.value,
            )

    return model_name


def _build_multi_provider_model_config(
    config: ShotgunConfig,
    provider_or_model: ProviderType | ModelName | None,
    for_sub_agent: bool,
    *,
    key_provider: KeyProvider,
    api_key: str,
) -> ModelConfig:
    """Build a ModelConfig for multi-model providers (Shotgun Account, OpenRouter).

    These providers give access to all models through a single API key,
    so the logic for resolving which model to use is shared.

    Args:
        config: Shotgun configuration
        provider_or_model: Explicit model, provider hint, or None for auto-selection
        for_sub_agent: If True, substitute a cheaper model for cost optimization
        key_provider: Authentication method (SHOTGUN or OPENROUTER)
        api_key: The resolved API key string

    Returns:
        Fully configured ModelConfig
    """
    model_name = _resolve_multi_provider_model(config, provider_or_model, for_sub_agent)
    spec = MODEL_SPECS[model_name]
    return ModelConfig(
        name=spec.name,
        provider=spec.provider,
        key_provider=key_provider,
        max_input_tokens=spec.max_input_tokens,
        max_output_tokens=spec.max_output_tokens,
        api_key=api_key,
        supports_streaming=True,
    )


def get_default_model_for_provider(config: ShotgunConfig) -> ModelName:
    """Get the default model based on which provider/account is configured.

    Checks API keys in priority order and returns appropriate default model.
    Treats Shotgun Account as a provider context.

    Args:
        config: Shotgun configuration containing API keys

    Returns:
        Default ModelName for the configured provider/account
    """
    # Priority 1: Shotgun Account
    if _get_api_key(config.shotgun.api_key):
        return ModelName.CLAUDE_OPUS_4_6

    # Priority 1.5: OpenRouter
    if _get_api_key(config.openrouter.api_key):
        return ModelName.CLAUDE_OPUS_4_6

    # Priority 2: Individual provider keys
    if _get_api_key(config.anthropic.api_key):
        return ModelName.CLAUDE_OPUS_4_6
    if _get_api_key(config.openai.api_key):
        return ModelName.GPT_5_2
    if _get_api_key(config.google.api_key):
        return ModelName.GEMINI_3_1_PRO_PREVIEW

    # Fallback: system-wide default
    return ModelName.CLAUDE_OPUS_4_6


@lru_cache(maxsize=_MAX_MODEL_CACHE_SIZE)
def get_or_create_model(
    provider: ProviderType,
    key_provider: "KeyProvider",
    model_name: ModelName | str,
    api_key: str,
    base_url: str | None = None,
) -> Model:
    """Get or create a singleton Model instance.

    Bounded by ``functools.lru_cache`` (maxsize=8) with automatic LRU eviction.

    Args:
        provider: Actual LLM provider (openai, anthropic, google)
        key_provider: Authentication method (byok or shotgun)
        model_name: Name of the model
        api_key: API key for the provider
        base_url: Base URL for OpenAI-compatible endpoints (optional)

    Returns:
        Cached or newly created Model instance

    Raises:
        ValueError: If provider is not supported
    """
    logger.debug(
        "Creating new %s model instance via %s: %s",
        provider.value,
        key_provider.value,
        model_name,
    )

    # Get max_tokens from MODEL_SPECS (only for known models)
    if isinstance(model_name, ModelName) and model_name in MODEL_SPECS:
        max_tokens = MODEL_SPECS[model_name].max_output_tokens
    else:
        max_tokens = {
            ProviderType.OPENAI: 16_000,
            ProviderType.ANTHROPIC: 32_000,
            ProviderType.GOOGLE: 64_000,
            ProviderType.OPENAI_COMPATIBLE: 16_000,
        }.get(provider, 16_000)

    # Handle OpenAI-compatible endpoints (uses provided base_url or settings)
    if provider == ProviderType.OPENAI_COMPATIBLE:
        return _create_openai_compat_model(
            api_key, str(model_name), max_tokens, base_url
        )

    # At this point, model_name must be a ModelName (string handled above via OPENAI_COMPATIBLE)
    if not isinstance(model_name, ModelName):
        raise ValueError(
            f"Unknown model name: {model_name}. "
            "For custom models, set SHOTGUN_OPENAI_COMPAT_BASE_URL."
        )

    if key_provider == KeyProvider.SHOTGUN:
        # Shotgun Account uses LiteLLM proxy with native model types where possible
        if model_name in MODEL_SPECS:
            litellm_model_name = MODEL_SPECS[model_name].litellm_proxy_model_name
        else:
            litellm_model_name = f"openai/{model_name.value}"

        if provider == ProviderType.ANTHROPIC:
            anthropic_provider = create_anthropic_proxy_provider(api_key)
            return AnthropicModel(
                model_name.value,
                provider=anthropic_provider,
                settings=AnthropicModelSettings(
                    max_tokens=max_tokens,
                    timeout=600,
                ),
            )
        else:
            litellm_provider = create_litellm_provider(api_key)
            return OpenAIChatModel(
                litellm_model_name,
                provider=litellm_provider,
                settings=ModelSettings(max_tokens=max_tokens),
            )
    elif key_provider == KeyProvider.BYOK:
        if provider == ProviderType.OPENAI:
            openai_provider = OpenAIProvider(api_key=api_key)
            return OpenAIResponsesModel(
                model_name,
                provider=openai_provider,
                settings=ModelSettings(max_tokens=max_tokens),
            )
        elif provider == ProviderType.ANTHROPIC:
            anthropic_provider = AnthropicProvider(api_key=api_key)
            return AnthropicModel(
                model_name,
                provider=anthropic_provider,
                settings=AnthropicModelSettings(
                    max_tokens=max_tokens,
                    timeout=600,
                ),
            )
        elif provider == ProviderType.GOOGLE:
            google_provider = GoogleProvider(api_key=api_key)
            return GoogleModel(
                model_name,
                provider=google_provider,
                settings=ModelSettings(max_tokens=max_tokens),
            )
        else:
            raise ValueError(f"Unsupported provider: {provider}")
    elif key_provider == KeyProvider.OPENROUTER:
        # OpenRouter: all models go through OpenAI-compatible API
        if isinstance(model_name, ModelName) and model_name in MODEL_SPECS:
            openrouter_name = MODEL_SPECS[model_name].openrouter_model_name
        else:
            openrouter_name = str(model_name)
        openai_provider = OpenAIProvider(api_key=api_key, base_url=OPENROUTER_BASE_URL)
        return OpenAIChatModel(
            openrouter_name,
            provider=openai_provider,
            settings=ModelSettings(max_tokens=max_tokens),
        )
    else:
        raise ValueError(f"Unsupported key provider: {key_provider}")


async def get_provider_model(
    provider_or_model: ProviderType | ModelName | None = None,
    for_sub_agent: bool = False,
) -> ModelConfig:
    """Get a fully configured ModelConfig with API key and Model instance.

    Args:
        provider_or_model: Either a ProviderType, ModelName, or None.
            - If ModelName: returns that specific model with appropriate API key
            - If ProviderType: returns default model for that provider (backward compatible)
            - If None: uses default provider with its default model
        for_sub_agent: If True, substitute cheaper model for cost optimization.

    Returns:
        ModelConfig with API key configured and lazy Model instance

    Raises:
        ValueError: If provider is not configured properly or model not found

    Note:
        When SHOTGUN_OPENAI_COMPAT_BASE_URL is set, this function bypasses all
        other provider configuration and uses the OpenAI-compatible endpoint.
        The model name comes from SHOTGUN_OPENAI_COMPAT_DEFAULT_MODEL (default: gpt-4).
    """
    from shotgun.settings import settings

    # PRIORITY 0: Check for OpenAI-compatible mode
    # When both SHOTGUN_OPENAI_COMPAT_BASE_URL and API_KEY are set, bypass all other providers
    if settings.openai_compat.base_url and settings.openai_compat.api_key:
        compat_api_key = settings.openai_compat.api_key

        # Use CLI override if set, otherwise use hardcoded default
        main_model = _openai_compat_model_override or OPENAI_COMPAT_DEFAULT_MODEL

        # For sub-agents, use sub-agent model if specified, otherwise fall back to main model
        if for_sub_agent and _openai_compat_sub_agent_model_override:
            model_name = _openai_compat_sub_agent_model_override
            logger.info(
                "Using OpenAI-compatible endpoint: %s with sub-agent model: %s",
                settings.openai_compat.base_url,
                model_name,
            )
        else:
            model_name = main_model
            logger.info(
                "Using OpenAI-compatible endpoint: %s with model: %s",
                settings.openai_compat.base_url,
                model_name,
            )

        return ModelConfig(
            name=model_name,
            provider=ProviderType.OPENAI_COMPATIBLE,
            key_provider=KeyProvider.BYOK,
            max_input_tokens=128_000,  # Reasonable default for OpenAI-compatible
            max_output_tokens=16_000,
            api_key=compat_api_key,
            supports_streaming=True,
        )

    config_manager = get_config_manager()
    # Use cached config for read-only access (performance)
    config = await config_manager.load(force_reload=False)

    # Priority 1: Shotgun Account — use it for ANY model
    shotgun_api_key = _get_api_key(config.shotgun.api_key)
    if shotgun_api_key:
        return _build_multi_provider_model_config(
            config,
            provider_or_model,
            for_sub_agent,
            key_provider=KeyProvider.SHOTGUN,
            api_key=shotgun_api_key,
        )

    # Priority 1.5: OpenRouter — multi-model aggregator
    openrouter_api_key = _get_api_key(config.openrouter.api_key, "OPENROUTER_API_KEY")
    if openrouter_api_key:
        return _build_multi_provider_model_config(
            config,
            provider_or_model,
            for_sub_agent,
            key_provider=KeyProvider.OPENROUTER,
            api_key=openrouter_api_key,
        )

    # Priority 2: Check for Ollama model (selected via TUI)
    # Handle when user has selected an Ollama model without any cloud API keys
    if is_ollama_model(config.selected_model) and config.ollama.enabled:
        # is_ollama_model TypeGuard narrows type to str
        ollama_model = config.selected_model
        logger.info(
            "Using Ollama model from config: %s (base_url: %s)",
            ollama_model,
            config.ollama.base_url,
        )
        return ModelConfig(
            name=ollama_model,
            provider=ProviderType.OPENAI_COMPATIBLE,
            key_provider=KeyProvider.BYOK,
            max_input_tokens=128_000,  # Reasonable default for Ollama
            max_output_tokens=16_000,
            api_key=OLLAMA_PLACEHOLDER_API_KEY,
            supports_streaming=True,
            base_url=config.ollama.base_url,
        )

    # Priority 2: Fall back to individual provider keys

    # Check if a specific model was requested
    if isinstance(provider_or_model, ModelName):
        # Look up the model spec
        if provider_or_model not in MODEL_SPECS:
            requested_model = None  # Fall back to provider default
            provider_enum = None  # Will be determined below
        else:
            spec = MODEL_SPECS[provider_or_model]
            provider_enum = spec.provider
            requested_model = provider_or_model
    else:
        # Convert string to ProviderType enum if needed (backward compatible)
        if provider_or_model:
            provider_enum = (
                provider_or_model
                if isinstance(provider_or_model, ProviderType)
                else ProviderType(provider_or_model)
            )
            requested_model = None  # Will use provider's default model
        else:
            # No provider specified - check general override first, then selected model
            if (
                _general_model_override is not None
                and _general_model_override in MODEL_SPECS
            ):
                override_spec = MODEL_SPECS[_general_model_override]
                provider_enum = override_spec.provider
                requested_model = _general_model_override
            elif (
                isinstance(config.selected_model, ModelName)
                and config.selected_model in MODEL_SPECS
            ):
                # Only use selected_model if it's a ModelName enum (not Ollama string)
                selected_spec = MODEL_SPECS[config.selected_model]
                # Only use selected model if its provider has a configured key
                if _has_provider_key(config, selected_spec.provider):
                    provider_enum = selected_spec.provider
                    requested_model = config.selected_model
                else:
                    # Selected model's provider has no key - fall back to finding available provider
                    provider_enum = None
                    requested_model = None
            else:
                provider_enum = None
                requested_model = None

            # If no selected model or its provider unavailable, find first available provider
            if provider_enum is None:
                for provider in ProviderType:
                    if _has_provider_key(config, provider):
                        provider_enum = provider
                        break

            # If still no provider, check if Ollama is enabled as a fallback
            if provider_enum is None and config.ollama.enabled:
                # User has Ollama enabled but no cloud API keys
                # Return a placeholder config - the model will need to be selected
                logger.info(
                    "No cloud API keys configured, using Ollama fallback (base_url: %s)",
                    config.ollama.base_url,
                )
                # Use a generic Ollama model name - user should select one from the model picker
                return ModelConfig(
                    name="ollama/llama3.2:latest",  # Default suggestion
                    provider=ProviderType.OPENAI_COMPATIBLE,
                    key_provider=KeyProvider.BYOK,
                    max_input_tokens=128_000,
                    max_output_tokens=16_000,
                    api_key=OLLAMA_PLACEHOLDER_API_KEY,
                    supports_streaming=True,
                    supports_pdf=False,
                    supports_images=False,
                    base_url=config.ollama.base_url,
                )

            if provider_enum is None:
                raise ValueError(
                    "No provider keys configured. Set via environment variables or config."
                )

    if provider_enum == ProviderType.OPENAI:
        api_key = _get_api_key(config.openai.api_key, "OPENAI_API_KEY")
        if not api_key:
            raise ValueError(
                "OpenAI API key not configured. Set via config or OPENAI_API_KEY env var."
            )

        # Use requested model or default to gpt-5.2
        model_name = requested_model if requested_model else ModelName.GPT_5_2
        # Gracefully fall back if model doesn't exist
        if model_name not in MODEL_SPECS:
            model_name = ModelName.GPT_5_2

        # Apply sub-agent model mapping for cost optimization
        if for_sub_agent:
            original_model = model_name
            model_name = get_sub_agent_model(model_name)
            if model_name != original_model:
                logger.debug(
                    "Sub-agent model substitution: %s -> %s",
                    original_model.value,
                    model_name.value,
                )

        spec = MODEL_SPECS[model_name]

        # Check and test streaming capability for GPT-5 family models
        supports_streaming = True  # Default to True for all models
        if model_name in (
            ModelName.GPT_5_1,
            ModelName.GPT_5_2,
            ModelName.GPT_5_4,
        ):
            # Check if streaming capability has been tested
            streaming_capability = config.openai.supports_streaming

            if streaming_capability is None:
                # Not tested yet - run streaming test (test once for all GPT-5 models)
                logger.info("Testing streaming capability for OpenAI GPT-5 family...")
                streaming_capability = await check_streaming_capability(
                    api_key, model_name.value
                )

                # Save result to config (applies to all OpenAI models)
                config.openai.supports_streaming = streaming_capability
                await config_manager.save(config)
                logger.info(
                    f"Streaming test result: "
                    f"{'enabled' if streaming_capability else 'disabled'}"
                )

            supports_streaming = streaming_capability

        # Create fully configured ModelConfig
        return ModelConfig(
            name=spec.name,
            provider=spec.provider,
            key_provider=KeyProvider.BYOK,
            max_input_tokens=spec.max_input_tokens,
            max_output_tokens=spec.max_output_tokens,
            api_key=api_key,
            supports_streaming=supports_streaming,
        )

    elif provider_enum == ProviderType.ANTHROPIC:
        api_key = _get_api_key(config.anthropic.api_key, "ANTHROPIC_API_KEY")
        if not api_key:
            raise ValueError(
                "Anthropic API key not configured. Set via config or ANTHROPIC_API_KEY env var."
            )

        # Use requested model or default to claude-opus-4-6
        model_name = requested_model if requested_model else ModelName.CLAUDE_OPUS_4_6
        # Gracefully fall back if model doesn't exist
        if model_name not in MODEL_SPECS:
            model_name = ModelName.CLAUDE_OPUS_4_6

        # Apply sub-agent model mapping for cost optimization
        if for_sub_agent:
            original_model = model_name
            model_name = get_sub_agent_model(model_name)
            if model_name != original_model:
                logger.debug(
                    "Sub-agent model substitution: %s -> %s",
                    original_model.value,
                    model_name.value,
                )

        spec = MODEL_SPECS[model_name]

        # Create fully configured ModelConfig
        return ModelConfig(
            name=spec.name,
            provider=spec.provider,
            key_provider=KeyProvider.BYOK,
            max_input_tokens=spec.max_input_tokens,
            max_output_tokens=spec.max_output_tokens,
            api_key=api_key,
        )

    elif provider_enum == ProviderType.GOOGLE:
        api_key = _get_api_key(config.google.api_key, "GEMINI_API_KEY")
        if not api_key:
            raise ValueError(
                "Gemini API key not configured. Set via config or GEMINI_API_KEY env var."
            )

        # Use requested model or default to gemini-3.1-pro-preview
        model_name = (
            requested_model if requested_model else ModelName.GEMINI_3_1_PRO_PREVIEW
        )
        # Gracefully fall back if model doesn't exist
        if model_name not in MODEL_SPECS:
            model_name = ModelName.GEMINI_3_1_PRO_PREVIEW

        # Apply sub-agent model mapping for cost optimization
        if for_sub_agent:
            original_model = model_name
            model_name = get_sub_agent_model(model_name)
            if model_name != original_model:
                logger.debug(
                    "Sub-agent model substitution: %s -> %s",
                    original_model.value,
                    model_name.value,
                )

        spec = MODEL_SPECS[model_name]

        # Create fully configured ModelConfig
        return ModelConfig(
            name=spec.name,
            provider=spec.provider,
            key_provider=KeyProvider.BYOK,
            max_input_tokens=spec.max_input_tokens,
            max_output_tokens=spec.max_output_tokens,
            api_key=api_key,
        )

    else:
        raise ValueError(f"Unsupported provider: {provider_enum}")


def _has_provider_key(config: "ShotgunConfig", provider: ProviderType) -> bool:
    """Check if a provider has a configured API key (config or env var).

    Args:
        config: Shotgun configuration
        provider: Provider to check

    Returns:
        True if provider has a configured API key
    """
    if provider == ProviderType.OPENAI:
        return bool(_get_api_key(config.openai.api_key, "OPENAI_API_KEY"))
    elif provider == ProviderType.ANTHROPIC:
        return bool(_get_api_key(config.anthropic.api_key, "ANTHROPIC_API_KEY"))
    elif provider == ProviderType.GOOGLE:
        return bool(_get_api_key(config.google.api_key, "GEMINI_API_KEY"))
    return False


def _get_api_key(
    config_key: SecretStr | None, env_var_name: str | None = None
) -> str | None:
    """Get API key from config or environment variable.

    Args:
        config_key: API key from configuration
        env_var_name: Optional environment variable name to check as fallback

    Returns:
        API key string or None
    """
    # First check config
    if config_key is not None:
        return config_key.get_secret_value()

    # Fallback to environment variable
    if env_var_name:
        import os

        return os.environ.get(env_var_name)

    return None
