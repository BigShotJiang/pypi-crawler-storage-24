from pathlib import Path

from jps_observability_utils.scanner import audit_repository


FIXTURES = Path(__file__).parent / "fixtures"


def test_node_audit_detects_expected_technologies() -> None:
    result = audit_repository(FIXTURES / "node_repo_otel", "node")

    technologies = {finding.technology for finding in result.report.findings}
    assert "OpenTelemetry" in technologies
    assert "Prometheus" in technologies
    assert "OTLP / Collector" in technologies
    assert "Structured Logging" in technologies


def test_node_audit_assigns_deterministic_ids() -> None:
    first = audit_repository(FIXTURES / "node_repo_otel", "node")
    second = audit_repository(FIXTURES / "node_repo_otel", "node")

    assert [finding.finding_id for finding in first.report.findings] == [
        finding.finding_id for finding in second.report.findings
    ]


def test_node_audit_handles_clean_repo() -> None:
    result = audit_repository(FIXTURES / "node_repo_clean", "node")
    assert result.report.findings == []


def test_node_vendor_detection_finds_platform_integrations() -> None:
    result = audit_repository(FIXTURES / "node_repo_vendor", "node")
    technologies = {finding.technology for finding in result.report.findings}
    assert "Datadog" in technologies
    assert "Sentry" in technologies
