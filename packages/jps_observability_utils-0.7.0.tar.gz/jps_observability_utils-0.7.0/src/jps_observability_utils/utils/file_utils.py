"""Filesystem helpers used by repository scanners."""

from __future__ import annotations

from dataclasses import dataclass
from fnmatch import fnmatch
from pathlib import Path

from jps_observability_utils.constants import DEFAULT_IGNORE_DIRS, DEFAULT_TEXT_EXTENSIONS


@dataclass(slots=True)
class ScannedFile:
    """A safely loaded repository file."""

    relative_path: str
    absolute_path: Path
    content: str


def should_ignore(relative_path: str, ignore_patterns: list[str]) -> bool:
    """Return True when a path matches any ignore pattern."""
    if not ignore_patterns:
        return False
    return any(fnmatch(relative_path, pattern) or fnmatch(Path(relative_path).name, pattern) for pattern in ignore_patterns)


def is_probably_text_file(path: Path) -> bool:
    """Use filename heuristics to decide whether a file should be read as text."""
    if path.suffix.lower() in DEFAULT_TEXT_EXTENSIONS:
        return True
    return path.name.lower() in {
        "dockerfile",
        "makefile",
        "jenkinsfile",
        ".env",
        "procfile",
    }


def walk_repository(
    repo_path: Path,
    ignore_patterns: list[str] | None = None,
) -> tuple[list[ScannedFile], list[str], list[str]]:
    """Recursively collect readable text files from a repository."""
    patterns = ignore_patterns or []
    scanned_files: list[ScannedFile] = []
    ignored_paths: list[str] = []
    unreadable_files: list[str] = []

    for path in sorted(repo_path.rglob("*")):
        if path.is_dir():
            continue

        relative_path = path.relative_to(repo_path).as_posix()
        parts = set(path.relative_to(repo_path).parts)
        if DEFAULT_IGNORE_DIRS.intersection(parts):
            ignored_paths.append(relative_path)
            continue
        if should_ignore(relative_path, patterns):
            ignored_paths.append(relative_path)
            continue
        if not is_probably_text_file(path):
            continue

        try:
            content = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            unreadable_files.append(relative_path)
            continue
        except OSError:
            unreadable_files.append(relative_path)
            continue

        scanned_files.append(
            ScannedFile(relative_path=relative_path, absolute_path=path, content=content)
        )

    return scanned_files, sorted(set(ignored_paths)), sorted(set(unreadable_files))
