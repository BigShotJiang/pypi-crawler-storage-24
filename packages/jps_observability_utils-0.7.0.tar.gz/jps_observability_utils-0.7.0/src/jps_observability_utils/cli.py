"""Typer CLI for observability audits."""

from __future__ import annotations

import getpass
from datetime import datetime
from enum import Enum
from pathlib import Path

import typer

from jps_observability_utils.report_writer import build_report_paths, write_json, write_markdown
from jps_observability_utils.scanner import audit_repository
from jps_observability_utils.trace_matrix_writer import write_trace_matrix

app = typer.Typer(
    name="jps-observability-utils",
    help="Audit Python and Node.js repositories for evidence of observability instrumentation and integrations.",
    no_args_is_help=True,
)


class OutputFormat(str, Enum):
    """Supported output formats."""

    md = "md"
    json = "json"
    both = "both"


def _default_output_dir() -> Path:
    user = getpass.getuser()
    timestamp = datetime.now().strftime("%Y-%m-%d-%H%M%S")
    return Path(f"/tmp/{user}/jps-observability-utils/{timestamp}")


def _run_audit(
    language_target: str,
    repo_path: Path,
    output_dir: Path | None,
    output_format: OutputFormat,
    trace_matrix: bool,
    ignore: list[str] | None,
) -> None:
    if output_dir is None:
        output_dir = _default_output_dir()
    if not repo_path.exists() or not repo_path.is_dir():
        raise typer.BadParameter(f"Repository path does not exist or is not a directory: {repo_path}")

    scan_result = audit_repository(repo_path=repo_path, language_target=language_target, ignore_patterns=ignore or [])
    report = scan_result.report
    report_paths = build_report_paths(output_dir, language_target, report.repository_name, report.scan_timestamp)

    written_files: dict[str, str] = {}
    if output_format in {OutputFormat.md, OutputFormat.both}:
        markdown_path = write_markdown(report, report_paths["markdown"], ignore or [])
        written_files["markdown"] = str(markdown_path)
    if output_format in {OutputFormat.json, OutputFormat.both}:
        json_path = write_json(report, report_paths["json"])
        written_files["json"] = str(json_path)

    if trace_matrix:
        trace_matrix_path = write_trace_matrix(report, report_paths["trace_matrix"])
        written_files["trace_matrix"] = str(trace_matrix_path)

    report.report_files = written_files
    if "json" in written_files:
        write_json(report, Path(written_files["json"]))

    technologies = ", ".join(report.summary["major_technologies_detected"]) or "None detected"
    typer.echo(f"Repository: {report.repository_path}")
    typer.echo(f"Findings: {len(report.findings)}")
    typer.echo(f"Technologies: {technologies}")
    for label, path in written_files.items():
        typer.echo(f"{label}: {path}")


@app.command("audit-python")
def audit_python(
    repo_path: Path = typer.Argument(..., help="Path to the Python repository to scan."),
    output_dir: Path | None = typer.Option(None, "--output-dir", help="Directory for report artifacts (default: /tmp/<user>/jps-observability-utils/<timestamp>/)."),
    output_format: OutputFormat = typer.Option(OutputFormat.both, "--format", help="Report format to write."),
    trace_matrix: bool = typer.Option(True, "--trace-matrix/--no-trace-matrix", help="Write CSV trace matrix output."),
    ignore: list[str] | None = typer.Option(None, "--ignore", help="Glob pattern to ignore. Repeat for multiple patterns."),
) -> None:
    """Audit a Python repository."""
    _run_audit("python", repo_path, output_dir, output_format, trace_matrix, ignore)


@app.command("audit-node")
def audit_node(
    repo_path: Path = typer.Argument(..., help="Path to the Node.js repository to scan."),
    output_dir: Path | None = typer.Option(None, "--output-dir", help="Directory for report artifacts (default: /tmp/<user>/jps-observability-utils/<timestamp>/)."),
    output_format: OutputFormat = typer.Option(OutputFormat.both, "--format", help="Report format to write."),
    trace_matrix: bool = typer.Option(True, "--trace-matrix/--no-trace-matrix", help="Write CSV trace matrix output."),
    ignore: list[str] | None = typer.Option(None, "--ignore", help="Glob pattern to ignore. Repeat for multiple patterns."),
) -> None:
    """Audit a Node.js repository."""
    _run_audit("node", repo_path, output_dir, output_format, trace_matrix, ignore)


if __name__ == "__main__":
    app()
