"""jps_observability_utils package."""

__version__ = "0.7.0"
