"""Detection rules for Python repositories."""

from __future__ import annotations

from jps_observability_utils.matchers.common import Rule, apply_rules
from jps_observability_utils.models import AuditFinding
from jps_observability_utils.utils.file_utils import ScannedFile

PYTHON_RULES = [
    Rule(
        technology="OpenTelemetry",
        category="Telemetry Instrumentation",
        title="OpenTelemetry dependency or import detected",
        evidence_type="dependency/import",
        pattern=r"opentelemetry(?:[-_.a-z/*]+)?|from\s+opentelemetry|import\s+opentelemetry",
        interpretation="The repository contains static evidence consistent with Python OpenTelemetry instrumentation or SDK usage.",
        recommended_action="Confirm whether OpenTelemetry SDK initialization and exporters are enabled in deployment paths.",
        confidence="Medium",
        file_names=(
            "pyproject.toml",
            "requirements.txt",
            "poetry.lock",
            "setup.py",
            "setup.cfg",
            "pipfile",
            "pipfile.lock",
        ),
    ),
    Rule(
        technology="OpenTelemetry",
        category="Telemetry Instrumentation",
        title="OpenTelemetry initialization pattern detected",
        evidence_type="initialization",
        pattern=r"TracerProvider|MeterProvider|BatchSpanProcessor|OTLPSpanExporter|opentelemetry-instrument",
        interpretation="The repository contains stronger evidence of OpenTelemetry initialization or startup instrumentation behavior.",
        recommended_action="Review exporter endpoints, resource attributes, and service naming to confirm production telemetry coverage.",
        confidence="High",
        path_suffixes=(".py", ".sh", ".yaml", ".yml", ".toml", ".env"),
    ),
    Rule(
        technology="Prometheus",
        category="Monitoring and Metrics",
        title="Prometheus client or metrics endpoint evidence detected",
        evidence_type="metrics instrumentation",
        pattern=r"prometheus_client|start_http_server|Counter\(|Histogram\(|Summary\(|Gauge\(|['\"]/metrics['\"]",
        interpretation="The repository contains evidence consistent with Prometheus metrics collection or metrics endpoint exposure.",
        recommended_action="Verify scrape configuration and confirm which metrics are intended to be exposed.",
        confidence="Medium",
        path_suffixes=(".py", ".txt", ".toml", ".yaml", ".yml"),
    ),
    Rule(
        technology="Datadog",
        category="Observability Platforms",
        title="Datadog integration evidence detected",
        evidence_type="dependency/configuration",
        pattern=r"\bddtrace\b|\bdatadog\b|\bDD_(SERVICE|ENV|VERSION|AGENT_HOST|TRACE_[A-Z0-9_]+|LOGS_[A-Z0-9_]+|PROFILING_[A-Z0-9_]+|RUNTIME_METRICS_[A-Z0-9_]+)\b",
        interpretation="The repository contains configuration or dependencies consistent with Datadog observability integration.",
        recommended_action="Validate which Datadog products are expected to be active and whether tracing/log correlation is configured.",
        confidence="Medium",
        path_suffixes=(".py", ".txt", ".toml", ".yaml", ".yml", ".env"),
    ),
    Rule(
        technology="New Relic",
        category="Observability Platforms",
        title="New Relic integration evidence detected",
        evidence_type="dependency/configuration",
        pattern=r"newrelic",
        interpretation="The repository contains evidence consistent with a New Relic integration.",
        recommended_action="Check runtime bootstrap and environment settings to confirm New Relic agent initialization.",
        confidence="Medium",
        path_suffixes=(".py", ".txt", ".toml", ".yaml", ".yml", ".env"),
    ),
    Rule(
        technology="Sentry",
        category="Observability Platforms",
        title="Sentry integration evidence detected",
        evidence_type="dependency/configuration",
        pattern=r"sentry_sdk|sentry\.init",
        interpretation="The repository contains evidence consistent with Sentry error or performance monitoring configuration.",
        recommended_action="Confirm DSN management, environment tagging, and whether tracing is intentionally enabled.",
        confidence="Medium",
        path_suffixes=(".py", ".txt", ".toml", ".yaml", ".yml", ".env"),
    ),
    Rule(
        technology="Elastic APM",
        category="Observability Platforms",
        title="Elastic APM integration evidence detected",
        evidence_type="dependency/configuration",
        pattern=r"elasticapm|ELASTIC_APM",
        interpretation="The repository contains evidence consistent with Elastic APM instrumentation or configuration.",
        recommended_action="Confirm service naming, server URLs, and whether automatic instrumentation is active at runtime.",
        confidence="Medium",
        path_suffixes=(".py", ".txt", ".toml", ".yaml", ".yml", ".env"),
    ),
    Rule(
        technology="OTLP / Collector",
        category="Pipeline and Export Configuration",
        title="OTLP or collector configuration evidence detected",
        evidence_type="export configuration",
        pattern=r"\bOTEL_[A-Z0-9_]+\b|\botlp\b|\botelcol\b|^\s*(receivers|exporters):",
        interpretation="The repository contains environment variables or configuration structures consistent with OTLP or collector-based telemetry export.",
        recommended_action="Inspect deployment configuration to identify actual exporter targets and environment-specific overrides.",
        confidence="High",
        path_suffixes=(".py", ".yaml", ".yml", ".toml", ".json", ".env", ".sh"),
    ),
    Rule(
        technology="Structured Logging",
        category="Logging",
        title="Structured logging evidence detected",
        evidence_type="logging configuration",
        pattern=r"structlog|python-json-logger|jsonlogger|extra=\{|request_id|trace_id",
        interpretation="The repository contains evidence of structured logging or correlation identifier handling relevant to observability.",
        recommended_action="Verify log schema consistency and whether trace or request correlation fields are propagated end to end.",
        confidence="Low",
        path_suffixes=(".py", ".toml", ".yaml", ".yml", ".json"),
    ),
]


def find_python_evidence(scanned_files: list[ScannedFile]) -> list[AuditFinding]:
    """Return Python-specific observability findings."""
    return apply_rules(scanned_files, PYTHON_RULES)
