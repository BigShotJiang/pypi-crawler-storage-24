"""Reusable matcher helpers."""

from __future__ import annotations

import re
from dataclasses import dataclass

from jps_observability_utils.models import AuditFinding
from jps_observability_utils.utils.file_utils import ScannedFile
from jps_observability_utils.utils.text_utils import compact_snippet


@dataclass(frozen=True, slots=True)
class Rule:
    """A static evidence rule."""

    technology: str
    category: str
    title: str
    evidence_type: str
    pattern: str
    interpretation: str
    recommended_action: str
    confidence: str
    file_names: tuple[str, ...] = ()
    path_suffixes: tuple[str, ...] = ()


def rule_applies(rule: Rule, scanned_file: ScannedFile) -> bool:
    """Return True when a rule should be evaluated against a file."""
    if rule.file_names and scanned_file.absolute_path.name.lower() not in rule.file_names:
        return False
    if rule.path_suffixes:
        suffix = scanned_file.absolute_path.suffix.lower()
        file_name = scanned_file.absolute_path.name.lower()
        if suffix not in rule.path_suffixes and file_name not in rule.path_suffixes:
            return False
    return True


def finding_from_match(rule: Rule, scanned_file: ScannedFile, match: re.Match[str]) -> AuditFinding:
    """Build a finding object from a regex match."""
    matched_text = compact_snippet(match.group(0))
    line_number = scanned_file.content.count("\n", 0, match.start()) + 1
    return AuditFinding(
        title=rule.title,
        technology=rule.technology,
        category=rule.category,
        confidence=rule.confidence,
        evidence_type=rule.evidence_type,
        file_path=scanned_file.relative_path,
        line_number=line_number,
        match_text=matched_text,
        interpretation=rule.interpretation,
        recommended_action=rule.recommended_action,
    )


def apply_rules(scanned_files: list[ScannedFile], rules: list[Rule]) -> list[AuditFinding]:
    """Evaluate regex rules across scanned files."""
    findings: list[AuditFinding] = []
    seen_keys: set[tuple[str, str, int | None, str]] = set()
    for scanned_file in scanned_files:
        for rule in rules:
            if not rule_applies(rule, scanned_file):
                continue
            match = re.search(rule.pattern, scanned_file.content, re.MULTILINE)
            if not match:
                continue
            finding = finding_from_match(rule, scanned_file, match)
            key = (finding.title, finding.file_path, finding.line_number, finding.match_text)
            if key in seen_keys:
                continue
            seen_keys.add(key)
            findings.append(finding)
    return findings
