from __future__ import annotations

import asyncio
import time
from datetime import datetime, timezone
from pathlib import Path

from claude_agent_sdk import ClaudeAgentOptions

from probegen.config import ProbegenConfig
from probegen.context import count_tokens
from probegen.models import CoverageGap, ProbeProposal
from probegen.prompts.stage3_template import render_stage3_prompt
from probegen.stages._common import StageRunResult, build_metadata, run_stage_with_retry
from probegen.tools.similarity import apply_diversity_limit, rank_probes


def run_stage3(
    stage1_manifest: dict,
    stage2_manifest: dict,
    context,
    config: ProbegenConfig,
    *,
    cwd: str | Path | None = None,
) -> StageRunResult:
    run_id = f"stage3-{int(time.time())}"
    timestamp = datetime.now(tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    prompt = render_stage3_prompt(
        stage1_manifest,
        stage2_manifest,
        context,
        max_probes_surfaced=config.generation.max_probes_surfaced,
    )

    # Generate JSON schema for structured output validation
    output_schema = ProbeProposal.model_json_schema(
        mode="serialization",
        by_alias=True,
    )

    options = ClaudeAgentOptions(
        allowed_tools=[],  # Stage 3 is pure generation from prompt context; no tools needed
        mcp_servers={},
        max_turns=25,
        max_budget_usd=config.budgets.stage3_usd,
        cwd=str(cwd or Path.cwd()),
        betas=["structured-outputs-2025-11-13"],
        output_format={
            "type": "json_schema",
            "schema": output_schema,
        },
    )
    result = asyncio.run(
        run_stage_with_retry(
            stage_num=3,
            prompt=prompt,
            options=options,
            output_model=ProbeProposal,
            inject_fields={
                "run_id": run_id,
                "stage1_run_id": stage1_manifest.get("run_id", ""),
                "stage2_run_id": stage2_manifest.get("run_id", ""),
                "timestamp": timestamp,
                "pr_number": stage1_manifest.get("pr_number"),
                "commit_sha": stage1_manifest.get("commit_sha", ""),
                "probe_count": 0,
            },
        )
    )

    gap_models = [CoverageGap.model_validate(gap) for gap in stage2_manifest.get("gaps", [])]
    ranked = rank_probes(result.data.probes, gap_models)
    diversified = apply_diversity_limit(
        ranked,
        limit_per_gap=config.generation.diversity_limit_per_gap,
    )
    result.data.probes = diversified[: config.generation.max_probes_surfaced]
    result.data.probe_count = len(result.data.probes)
    if context.warnings:
        result.data.warnings.extend(context.warnings)
    result.extras = {"prompt_tokens": count_tokens(prompt)}
    return result
