# mayhem

A lightweight Python framework for chaos engineering, fault injection, and resilience testing.

## Installation

```bash
pip install mayhem
```

## Status

Currently in early development. First release coming soon.
