"""."""

from association_studio.exp_metrics.iou_like_dia_mah import IouLikeDiaMah


def test_init(driver: IouLikeDiaMah) -> None:
    assert driver._square_diff_z.shape == (10,)
