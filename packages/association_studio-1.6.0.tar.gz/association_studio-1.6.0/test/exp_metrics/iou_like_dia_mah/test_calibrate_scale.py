"""."""

import numpy as np

from kinematic_tracker.association.metric_giou_yaw import MetricGIoUYaw

from association_studio.common import FMT
from association_studio.exp_metrics.iou_like_dia_mah import IouLikeDiaMah

from ..conftest import get_kf


def test_scale(driver: IouLikeDiaMah, ref_drv: MetricGIoUYaw, ref_1z: FMT) -> None:
    """."""
    probe_z = np.array((0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 2.0, 2.0, 1.0))
    kf = get_kf(probe_z)
    ref = ref_drv.compute_metric(ref_1z, [kf])[0, 0]
    probe = driver.compute_metric(ref_1z, [kf])[0, 0]
    assert abs(probe - ref) < 0.017
