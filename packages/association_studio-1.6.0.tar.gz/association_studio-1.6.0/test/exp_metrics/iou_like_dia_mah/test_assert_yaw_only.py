"""."""

import cv2
import numpy as np
import pytest

from association_studio.exp_metrics.iou_like_dia_mah import IouLikeDiaMah


def test_compute_metric(driver: IouLikeDiaMah, kf: cv2.KalmanFilter) -> None:
    det_1z = np.array((0.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 4.0, 2.0, 1.0)).reshape(1, 10)
    with pytest.raises(RuntimeWarning):
        driver.compute_metric(det_1z, [kf])
