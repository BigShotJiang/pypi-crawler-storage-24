"""."""

import pytest

from association_studio.exp_metrics.iou_like_dia_mah import IouLikeDiaMah


@pytest.fixture
def driver() -> IouLikeDiaMah:
    return IouLikeDiaMah()
