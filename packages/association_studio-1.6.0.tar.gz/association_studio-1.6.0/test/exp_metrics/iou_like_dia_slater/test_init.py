"""."""

from association_studio.exp_metrics.iou_like_dia_slater import IouLikeDiaSlater


def test_init(driver: IouLikeDiaSlater) -> None:
    assert driver._square_diff_z.shape == (10,)
