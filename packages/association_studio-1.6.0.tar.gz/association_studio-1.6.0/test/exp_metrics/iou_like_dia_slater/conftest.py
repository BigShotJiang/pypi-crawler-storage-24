"""."""

import pytest

from association_studio.exp_metrics.iou_like_dia_slater import IouLikeDiaSlater


@pytest.fixture
def driver() -> IouLikeDiaSlater:
    return IouLikeDiaSlater()
