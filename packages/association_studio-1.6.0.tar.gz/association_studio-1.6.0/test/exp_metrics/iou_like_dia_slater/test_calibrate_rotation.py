"""."""

import numpy as np

from kinematic_tracker.association.metric_giou_yaw import MetricGIoUYaw

from association_studio.exp_metrics.iou_like_dia_slater import IouLikeDiaSlater

from ..conftest import get_kf


def test_rotation(driver: IouLikeDiaSlater, ref_drv: MetricGIoUYaw) -> None:
    """."""
    ref_1z = np.array((0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 4.0, 2.0, 1.0)).reshape(1, 10)
    probe90_z = np.array((0.0, 0.0, 0.0, 0.707106781, 0.0, 0.0, 0.707106781, 4.0, 2.0, 1.0))
    kf90 = get_kf(probe90_z)
    ref = ref_drv.compute_metric(ref_1z, [kf90])[0, 0]
    probe = driver.compute_metric(ref_1z, [kf90])[0, 0]
    assert abs(probe - ref) < 0.02
