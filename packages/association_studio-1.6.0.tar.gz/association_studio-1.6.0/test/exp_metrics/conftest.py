"""."""

import cv2
import numpy as np
import pytest

from kinematic_tracker.association.metric_giou_yaw import MetricGIoUYaw

from association_studio.common import FMT


@pytest.fixture
def ref_drv() -> MetricGIoUYaw:
    indices = 0, 1, 2, 3, 6, 7, 8, 9
    return MetricGIoUYaw(1, 1, 10, indices)


@pytest.fixture
def kf() -> cv2.KalmanFilter:
    kf = cv2.KalmanFilter(10, 10, 0, cv2.CV_64F)
    kf.statePre = np.array((0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 4.0, 2.0, 1.0)).reshape(10, 1)
    return kf


def get_kf(pre_z: FMT) -> cv2.KalmanFilter:
    kf = cv2.KalmanFilter(10, 10, 0, cv2.CV_64F)
    kf.statePre = pre_z.reshape(10, 1)
    kf.measurementMatrix = np.eye(10)
    return kf


@pytest.fixture
def ref_1z() -> FMT:
    return np.array((0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0)).reshape(1, 10)
