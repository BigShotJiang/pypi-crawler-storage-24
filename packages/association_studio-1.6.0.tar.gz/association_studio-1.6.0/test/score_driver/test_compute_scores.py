"""."""

import pytest

from association_studio.common import FVT
from association_studio.score_driver.score_driver import ScoreDriver


def test_compute_scores(vec_z: FVT, driver: ScoreDriver) -> None:
    driver.compute_scores(vec_z)
    ref = 0.139487179487, 0.1902341996, 0.252306998, 0.728156653, 0.181316789, 0.31068506
    assert driver.scores == pytest.approx(ref)
