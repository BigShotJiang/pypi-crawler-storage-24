"""."""

import pytest

from kinematic_tracker import NdKkfTracker
from kinematic_tracker.association.metric_giou_yaw import MetricGIoUYaw

from association_studio.exp_metrics.iou_like_dia_mah import IouLikeDiaMah
from association_studio.exp_metrics.iou_like_dia_slater import IouLikeDiaSlater
from association_studio.score_driver.valid_metrics import ValidMetrics


@pytest.fixture
def vms() -> ValidMetrics:
    return ValidMetrics()


def test_init(vms: ValidMetrics) -> None:
    assert isinstance(vms.tracker, NdKkfTracker)


def test_get_valid_metrics(vms: ValidMetrics) -> None:
    # fmt: off
    ref = [
        'giou-axes-aligned', 'giou-yaw',
        'mahalanobis', 'mahalanobis-size-modulated',
        'iou-like-dia-mah', 'iou-like-dia-slater'
    ]
    # fmt: on
    assert vms.get_valid_metrics() == ref


def test_driver(vms: ValidMetrics) -> None:
    assert isinstance(vms.get_driver('giou-yaw'), MetricGIoUYaw)
    assert isinstance(vms.get_driver('iou-like-dia-mah'), IouLikeDiaMah)
    assert isinstance(vms.get_driver('iou-like-dia-slater'), IouLikeDiaSlater)
    with pytest.raises(ValueError):
        vms.get_driver('bogus-metric')
