"""."""

import numpy as np
import pytest

from association_studio.core.mid_box import Box


def test_mid_corners(box: Box) -> None:
    corners = box.mid_corners()
    # fmt: off
    ref = [
        [0.5034013605442178, 0.5714285714285716, 1.4965986394557822, 1.4285714285714284],
        [4.221088435374149, 3.6428571428571423, -0.22108843537414957, 0.35714285714285743],
        [0.7482993197278915, 5.7142857142857135, 5.2517006802721085, 0.2857142857142865]
    ]
    # fmt: on
    assert corners == pytest.approx(np.array(ref))
