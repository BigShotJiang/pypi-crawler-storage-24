"""."""

import numpy as np
import pytest

from association_studio.app.back import AssociationStudioBackend
from association_studio.core.mid_box import Box


def test_upd_ref_patches(be: AssociationStudioBackend, box: Box) -> None:
    be.box_ref = box
    be.upd_ref_patches()
    # fmt: off
    ref = [
        [2.6644295270646188, 4.7348993307680365], [-2.0335570481537326, 3.0234899294066446],
        [-0.6644295270646188, -0.7348993307680365], [4.033557048153733, 0.9765100705933556],
        [2.6644295270646188, 4.7348993307680365]
    ]
    # fmt: on
    assert be.ref_poly.get_xy() == pytest.approx(np.array(ref))
    assert be.ref_circle.get_center() == pytest.approx([1.684563760544557, 0.12080536991265955])
