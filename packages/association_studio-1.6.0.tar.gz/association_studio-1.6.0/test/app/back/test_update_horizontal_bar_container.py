"""."""

import matplotlib.pyplot as plt
import pytest

from association_studio.app.back import AssociationStudioBackend


def test_it(be: AssociationStudioBackend, ax: plt.Axes) -> None:
    bar = ax.barh(range(4), range(4))
    be.update_horizontal_bar_container(bar)
    scores = [float(b.get_width()) for b in bar]
    ref = 0.6968361840236645, 0.6389961679998885, 0.9820862284712972, 0.9899001837330043
    assert scores == pytest.approx(ref)
