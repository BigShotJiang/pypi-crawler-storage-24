"""."""

import pytest

from pytest_mock import MockerFixture

from association_studio.app.back import AssociationStudioBackend


def test_set_size_probe(be: AssociationStudioBackend, mocker: MockerFixture) -> None:
    mock_upd = mocker.patch.object(be, 'upd_scores_and_probe')
    be.set_size_probe(10.0, 5.0)
    assert be.box_probe.vec_z[7:] == pytest.approx((10.0, 5.0, 1.0))
    assert be.box_ref.vec_z[7:] == pytest.approx((4.0, 2.0, 1.0))
    mock_upd.assert_called_once()
