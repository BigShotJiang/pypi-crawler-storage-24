"""."""

import numpy as np
import pytest

from association_studio.app.back import AssociationStudioBackend
from association_studio.core.mid_box import Box


@pytest.fixture
def be() -> AssociationStudioBackend:
    return AssociationStudioBackend()


@pytest.fixture
def box() -> Box:
    return Box(np.array([1.0, 2.0, 3.0, 0.573462344, 0.0, 0.0, 0.819231921, 4.0, 5.0, 6.0]))
