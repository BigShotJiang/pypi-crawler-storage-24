"""."""

import pytest

from pytest_mock import MockerFixture

from association_studio.app.back import AssociationStudioBackend
from association_studio.core.mid_box import Box


def test_upd_scores_and_probe(
    be: AssociationStudioBackend, mocker: MockerFixture, box: Box
) -> None:
    be.box_probe = box
    mock_upd_probe_patches = mocker.patch.object(be, 'upd_probe_patches')
    mock_upd_ref_patches = mocker.patch.object(be, 'upd_ref_patches')
    be.upd_scores_and_probe()
    mock_upd_probe_patches.assert_called_once()
    mock_upd_ref_patches.assert_called_once()
    ref = 0.3606945738, 0.3788795, 0.294838691, 0.7805876354, 0.0894671298, 0.31149245
    assert be.score_driver.scores == pytest.approx(ref)
