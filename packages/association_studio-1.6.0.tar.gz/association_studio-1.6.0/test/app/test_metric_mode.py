"""."""

import pytest

from association_studio.app.metric_mode import MetricMode


@pytest.fixture
def mm() -> MetricMode:
    return MetricMode(['1', '2', '3', '4'])


def test_metric_mode(mm: MetricMode) -> None:
    assert len(mm.choices) > 1
    assert mm.choices[0] == '1'
    assert mm.metric == mm.choices[0]


def test_next(mm: MetricMode) -> None:
    mm.next()
    assert mm.metric == mm.choices[1]
    mm.next()
    assert mm.metric == mm.choices[2]
    mm.next()
    assert mm.metric == mm.choices[3]
    mm.next()
    assert mm.metric == mm.choices[0]
