"""."""

from association_studio.app.front import AssociationFrontend


def test_init(front: AssociationFrontend) -> None:
    assert front.pick_events == []
    assert front.fig_boxes.canvas.manager.get_window_title() == 'Association Studio: boxes'
    assert front.ax_boxes.get_title() == 'giou-axes-aligned 0.6968'
    assert len(front.ax_metrics.patches) == 6
