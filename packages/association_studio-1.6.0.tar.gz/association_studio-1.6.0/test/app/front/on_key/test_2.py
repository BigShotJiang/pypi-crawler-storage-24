"""."""

from matplotlib.backend_bases import KeyEvent
from pytest_mock import MockerFixture

from association_studio.app.front import AssociationFrontend


def test_2(front: AssociationFrontend, key_event: KeyEvent, mocker: MockerFixture) -> None:
    key_event.key = '2'
    mock_update = mocker.patch.object(front.back, 'update_horizontal_bar_container')
    front.on_key(key_event)
    mock_update.assert_called_once_with(front.bar)
    assert front.ax_boxes.get_title() == 'giou-axes-aligned 0.5417'
