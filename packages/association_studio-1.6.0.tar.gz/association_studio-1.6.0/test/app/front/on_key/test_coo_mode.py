"""."""

from matplotlib.backend_bases import KeyEvent

from association_studio.app.front import AssociationFrontend
from association_studio.app.show_coo_mode import ShowCooMode


def test_coo_mode(front: AssociationFrontend, key_event: KeyEvent) -> None:
    front.on_key(key_event)
    assert front.back.show_coo_mode == ShowCooMode.TRANSLATION
    assert front.text.get_text() == 'xy 0.300 0.700'
