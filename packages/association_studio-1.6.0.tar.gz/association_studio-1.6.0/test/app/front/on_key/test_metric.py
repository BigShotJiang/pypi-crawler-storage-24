"""."""

from kinematic_tracker.association.association_metric import AssociationMetric
from matplotlib.backend_bases import KeyEvent

from association_studio.app.front import AssociationFrontend


def test_metric(front: AssociationFrontend, key_event: KeyEvent) -> None:
    key_event.key = 'm'
    front.on_key(key_event)
    assert front.back.metric_mode.metric == AssociationMetric.GIOU_YAW.value
    assert front.ax_boxes.get_title() == 'giou-yaw 0.6390'
