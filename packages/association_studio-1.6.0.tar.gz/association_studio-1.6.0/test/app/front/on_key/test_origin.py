"""."""

import pytest

from matplotlib.backend_bases import KeyEvent
from pytest_mock import MockerFixture

from association_studio.app.front import AssociationFrontend


def test_origin(front: AssociationFrontend, key_event: KeyEvent, mocker: MockerFixture) -> None:
    key_event.key = 'O'
    mock_update = mocker.patch.object(front.back, 'update_horizontal_bar_container')
    front.on_key(key_event)
    mock_update.assert_called_once_with(front.bar)
    assert front.back.score_driver.scores == pytest.approx(1.0)
    assert front.ax_boxes.get_title() == 'giou-axes-aligned 1.0000'
