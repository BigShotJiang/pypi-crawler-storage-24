"""."""

import pytest

from matplotlib.backend_bases import KeyEvent
from pytest_mock import MockerFixture

from association_studio.app.front import AssociationFrontend


def test_rotate(front: AssociationFrontend, key_event: KeyEvent, mocker: MockerFixture) -> None:
    key_event.key = 'R'
    mock_update = mocker.patch.object(front.back, 'update_horizontal_bar_container')
    front.on_key(key_event)
    mock_update.assert_called_once_with(front.bar)
    ref = 0.69683618402, 0.7073877687, 0.9852578748, 0.993097065, 0.96675897987, 0.8307008
    assert front.back.score_driver.scores == pytest.approx(ref)
    assert front.ax_boxes.get_title() == 'giou-axes-aligned 0.6968'
