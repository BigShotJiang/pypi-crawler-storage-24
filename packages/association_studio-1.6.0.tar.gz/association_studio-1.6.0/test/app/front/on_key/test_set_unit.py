"""."""

import pytest

from matplotlib.backend_bases import KeyEvent
from pytest_mock import MockerFixture

from association_studio.app.front import AssociationFrontend


def test_set_unit(front: AssociationFrontend, key_event: KeyEvent, mocker: MockerFixture) -> None:
    key_event.key = '1'
    mock_update = mocker.patch.object(front.back, 'update_horizontal_bar_container')
    front.on_key(key_event)
    mock_update.assert_called_once_with(front.bar)
    ref = 0.5146895787, 0.51274987966, 0.764849523777, 0.90554415261, 0.325945784, 0.46321533
    assert front.back.score_driver.scores == pytest.approx(ref)
    assert front.ax_boxes.get_title() == 'giou-axes-aligned 0.5147'
