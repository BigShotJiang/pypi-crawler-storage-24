# 1.6.0

  - Calibrating the IoU-like-dia-Mah.
  - Experimental metric using Slater exponent `exp(-d)`.
  - Update dependencies.


# 1.5.0

  - Experimental association metric based on Mahalanobis distance with diagonal covariance.
  - Bugfix the size format wlh means dx, dy, dz with zero rotation.
  - Keystroke 2 results in 4x2 probe box.