"""."""

import numpy as np


A3T = np.ndarray[tuple[int, int, int], np.dtype[np.float64]]
FVT = np.ndarray[tuple[int], np.dtype[np.float64]]
FMT = np.ndarray[tuple[int, int], np.dtype[np.float64]]
IVT = np.ndarray[tuple[int], np.dtype[np.int64]]
OVT = np.ndarray[tuple[int], np.dtype[np.object_]]
