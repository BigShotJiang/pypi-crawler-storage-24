"""."""

import cv2
import numpy as np

from kinematic_tracker.association.metric_driver_base import MetricDriverBase

from association_studio.common import FMT


class IouLikeDiaSlater(MetricDriverBase):
    NAME = 'iou-like-dia-slater'

    def __init__(self) -> None:
        super().__init__(1, 1, 10)
        self.pos = 0.2136
        self.size = 0.25
        self.qua = 0.5
        self._precision_dia = np.zeros(10)
        self._precision_dia[3:7] = self.qua
        self._square_size = np.zeros(3)
        self._square_diff_z = np.zeros(10)

    def compute_metric(self, det_1z: FMT, filters: list[cv2.KalmanFilter]) -> FMT:
        if not np.allclose(det_1z[0, 4:6], 0.0):
            raise RuntimeWarning('rx, ry are assumed to be zeros')

        metric_rt = self.get_rect_chunk(1, 1)
        ref_z = det_1z[0]
        probe_z = filters[0].statePre[:, 0]
        self._square_size[:] = np.square((ref_z[7:] + probe_z[7:]) / 2.0)
        self._precision_dia[:3] = self.pos / self._square_size
        self._precision_dia[7:] = self.size / self._square_size
        self._square_diff_z[:] = np.square(probe_z - ref_z)
        distance = float(np.sqrt(np.sum(self._precision_dia * self._square_diff_z)))
        metric_rt[0, 0] = np.exp(-distance)
        return metric_rt
