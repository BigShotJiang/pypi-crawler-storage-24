"""."""

from typing import Sequence


class MetricMode:
    def __init__(self, metric_names: Sequence[str]) -> None:
        self.choices = [str(name) for name in metric_names]
        self.metric = self.choices[0]

    def next(self) -> None:
        i = (self.choices.index(self.metric) + 1) % len(self.choices)
        self.metric = self.choices[i]
