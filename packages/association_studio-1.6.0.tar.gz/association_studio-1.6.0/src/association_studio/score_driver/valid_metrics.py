"""."""

from kinematic_tracker.association.association import MDT
from kinematic_tracker.association.association_metric import AssociationMetric

from association_studio.exp_metrics.iou_like_dia_mah import IouLikeDiaMah
from association_studio.exp_metrics.iou_like_dia_slater import IouLikeDiaSlater

from .tracker_factory import get_low_order_nu_scenes_tracker


class ValidMetrics:
    """."""

    def __init__(self) -> None:
        self.tracker = get_low_order_nu_scenes_tracker()
        self.kt_metrics = [mt.value for mt in AssociationMetric]

    def get_valid_metrics(self) -> list[str]:
        return self.kt_metrics + [IouLikeDiaMah.NAME, IouLikeDiaSlater.NAME]

    def get_driver(self, name: str) -> MDT | IouLikeDiaMah | IouLikeDiaSlater:
        match name:
            case m if m in self.kt_metrics:
                self.tracker.set_association_metric(name)
                driver = self.tracker.metric_driver
            case IouLikeDiaMah.NAME:
                driver = IouLikeDiaMah()
            case IouLikeDiaSlater.NAME:
                driver = IouLikeDiaSlater()
            case _:
                raise ValueError(f'Unknown metric {name}')
        return driver
