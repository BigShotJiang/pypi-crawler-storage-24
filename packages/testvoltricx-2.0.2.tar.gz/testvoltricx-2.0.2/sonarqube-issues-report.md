# SonarQube-Equivalent Issues Report — `voltricx`

**Project Key:** `voltricx`
**Analysis Date:** 2026-03-22
**Tools Used:** Flake8 · Pylint · Bandit
**Overall Pylint Score:** 8.43 / 10
**Total Lines Scanned:** 3,133

---

## Summary

| Category | Count | Severity |
|---|---|---|
| Cyclic Imports (Architecture) | 5 | 🔴 High |
| Broad Exception Handling | 9 | 🟠 Medium |
| Protected Member Access | 17 | 🟡 Low–Medium |
| Wildcard Imports (`import *`) | 20 | 🟡 Low |
| Unused Arguments | 3 | 🟡 Low |
| Lines Too Long | 9 | 🟢 Minor |
| Too Many Public Methods | 3 | 🟡 Low |
| Too Many Instance Attributes | 2 | 🟡 Low |
| Too Many Branches / Statements | 3 | 🟡 Low |
| Dangerous Default Value | 1 | 🟠 Medium |
| Security (Bandit Low) | 9 | 🟡 Low |
| Import Outside Toplevel | 8 | 🟡 Low |
| Missing `raise ... from exc` | 4 | 🟡 Low |
| Other (try/except/pass, unnecessary pass, etc.) | 4 | 🟡 Low |

---

## 🔴 Critical / Architecture Issues

### 1. Cyclic Imports — `voltricx/typings/websocket.py`
Multiple circular import chains detected:

- `voltricx.pool` → `voltricx.typings.track`
- `voltricx.node` → `voltricx.websocket` → `voltricx.pool`
- `voltricx.node` → `voltricx.websocket` → `voltricx.typings.events` → `voltricx.typings.track` → `voltricx.pool`
- `voltricx.node` → `voltricx.websocket` → `voltricx.typings.websocket` → `voltricx.typings.player` → `voltricx.typings.track` → `voltricx.pool`
- `voltricx.node` → `voltricx.websocket` → `voltricx.typings.websocket` → `voltricx.typings.events` → `voltricx.typings.track` → `voltricx.pool`

**Fix:** Refactor `typings` into a separate standalone module with no back-imports into `pool`, `node`, or `websocket`. Use `TYPE_CHECKING` guard for type-only imports.

---

## 🟠 Medium Severity Issues

### 2. Broad Exception Handling (9 occurrences)
Catching bare `Exception` hides the real error type and makes debugging harder.

| File | Line |
|---|---|
| `logger.py` | 113 |
| `player.py` | 323, 521, 607, 617, 697 |
| `node.py` | 178 |
| `pool.py` | 174, 318 |

**Fix:** Catch specific exceptions (e.g., `aiohttp.ClientError`, `asyncio.TimeoutError`).

### 3. Dangerous Default Value — `utils.py:55`
```python
def some_func(arg={}):  # mutable default!
```
Mutable default arguments are shared across all calls.

**Fix:** Use `None` as default and assign inside the function body.

---

## 🟡 Low–Medium Severity Issues

### 4. Protected Member Access (17 occurrences)
Code in `player.py`, `queue.py`, `hypercache.py`, and `pool.py` directly accesses `_` prefixed (private) members of other classes.

Key examples:
- `pool._players` accessed 8× in `player.py`
- `queue._items` accessed in `player.py` and `queue.py`
- `node._update_player`, `node._destroy_player` accessed in `player.py`
- `hypercache._data` accessed 5× in `hypercache.py`

**Fix:** Expose these via proper public methods or properties on the owning class.

### 5. Wildcard Imports — `__init__.py` files (20 occurrences)
Both `voltricx/__init__.py` and `voltricx/typings/__init__.py` use `from .module import *`, which:
- Makes it impossible to detect undefined names
- Pollutes the namespace
- Triggers F401/F403 from Flake8

**Fix:** Replace with explicit imports, or maintain an `__all__` list in each sub-module.

### 6. Missing `raise ... from exc` (4 occurrences)
Exception chaining not preserved in `node.py` (lines 224, 232) and `player.py` (lines 369, 393).

**Fix:**
```python
# Before
except SomeError:
    raise OtherError(...)

# After
except SomeError as exc:
    raise OtherError(...) from exc
```

### 7. `asyncio.timeout` not recognized — `player.py` (lines 356, 390, 766)
Pylint reports `Module 'asyncio' has no 'timeout' member`. `asyncio.timeout` was added in Python 3.11. The project targets 3.12 so this should work, but Pylint is running on 3.10. Verify the `sonar.python.version=3.12` is respected.

### 8. Import Outside Toplevel (8 occurrences)
Conditional or deferred imports found in:
- `utils.py`: `discord`
- `player.py`: `pool.Pool` (×4)
- `hypercache.py`: `random`, `typings.common.HyperCacheConfig` (×2)

**Fix:** Move imports to the top of each file, using `TYPE_CHECKING` guard where necessary to avoid circular imports.

### 9. Unused Arguments (3 occurrences)

| File | Line | Argument |
|---|---|---|
| `player.py` | 335 | `reconnect` |
| `player.py` | 399 | `kwargs` |
| `pool.py` | 243 | `node` |

**Fix:** Either remove the argument or prefix with `_` to indicate intentionally unused.

---

## 🟡 Complexity / Design Issues

### 10. Too Many Public Methods
| Class | File | Methods |
|---|---|---|
| `Queue` | `queue.py:45` | 21 (limit: 20) |
| `Player` | `player.py:69` | 27 (limit: 20) |
| `Node` | `node.py:52` | 22 (limit: 20) |

**Fix:** Break large classes into smaller focused classes or use mixins.

### 11. Too Many Instance Attributes
| Class | File | Attributes |
|---|---|---|
| `Player` | `player.py:69` | 32 (limit: 7) |
| `Node` | `node.py:52` | 12 (limit: 7) |

**Fix:** Group related attributes into a dataclass or config object.

### 12. Too Many Branches / Statements
| Method | File | Count |
|---|---|---|
| Unknown | `player.py:569` | 14 branches (limit: 12) |
| Unknown | `player.py:638` | 14 branches (limit: 12) |
| Unknown | `pool.py:242` | 22 branches, 52 statements |

**Fix:** Extract sub-methods to reduce complexity.

### 13. `no-else-return` — `player.py:589`
Unnecessary `elif` after a `return` statement.

**Fix:** Remove the `el` prefix from `elif` since the preceding `return` makes it unreachable.

---

## 🟡 Security Issues (Bandit — Low Severity)

| ID | Issue | File | Line |
|---|---|---|---|
| B404 | `subprocess` module imported | `__main__.py` | 25 |
| B607 | Process started with partial path | `__main__.py` | 44 |
| B603 | Subprocess call — check for untrusted input | `__main__.py` | 44 |
| B311 | Non-cryptographic random generator | `backoff.py` | 53 |
| B311 | Non-cryptographic random generator | `hypercache.py` | 188 |
| B110 | `try/except/pass` detected | `logger.py` | 113 |
| B110 | `try/except/pass` detected | `node.py` | 178 |
| B110 | `try/except/pass` detected | `player.py` | 521 |
| B110 | `try/except/pass` detected | `player.py` | 607 |

For `B311`: if randomness is used for shuffling (not cryptography), this is acceptable — add `# nosec B311` comment to suppress.
For `B110`: silent `except: pass` blocks can hide errors. At minimum log them.

---

## 🟢 Minor Style Issues

### Lines Too Long (9 occurrences)
| File | Lines |
|---|---|
| `pool.py` | 187, 195, 301, 358, 365, 383 |
| `player.py` | 321, 324 |
| `hypercache.py` | 51 |

---

## Recommended Priority Actions

1. **Fix cyclic imports** — most impactful structural change
2. **Narrow exception handlers** — improves observability
3. **Fix dangerous default value** in `utils.py:55`
4. **Replace wildcard imports** with explicit ones
5. **Add `raise ... from exc`** for all re-raised exceptions
6. **Use `_` prefix or remove** unused arguments
7. **Suppress false-positive `asyncio.timeout`** with Pylint 3.12 target config
