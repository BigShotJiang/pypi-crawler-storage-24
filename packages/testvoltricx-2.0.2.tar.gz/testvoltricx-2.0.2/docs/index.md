---
title: Voltricx — High-Performance Lavalink Wrapper
description: The elite Lavalink wrapper for Python. Built for high-load music bots with dual-tier caching, smart failover, and surgical audio control.
hide:
  - navigation
  - toc
---

<!-- ═════════════════════════════════════════════════════════════
     HERO — Full-viewport
     ═════════════════════════════════════════════════════════════ -->
<div class="vtx-hero-wrapper">
  <!-- Background effects -->
  <div class="vtx-hero-flare"></div>
  <div class="vtx-orb vtx-orb-1"></div>
  <div class="vtx-orb vtx-orb-2"></div>
  <div class="vtx-orb vtx-orb-3"></div>
  <div class="vtx-grid-overlay"></div>
  <canvas class="vtx-particle-canvas"></canvas>

  <!-- Content -->
  <div class="vtx-hero-inner">

    <a href="getting-started/installation/" class="vtx-release-badge vtx-animate-in">
      <span class="vtx-badge-dot"></span>
      v1.0.5 — Now Available &nbsp;→
    </a>

    <div class="vtx-tech-badges vtx-animate-in">
      <span class="vtx-tech-badge vtx-tech-badge--accent">⚡ Lavalink v4</span>
      <span class="vtx-tech-badge">Python 3.9+</span>
      <span class="vtx-tech-badge">discord.py 2.0</span>
      <span class="vtx-tech-badge">Pydantic v2</span>
      <span class="vtx-tech-badge">async/await</span>
    </div>

    <h1 class="vtx-headline vtx-gradient-text vtx-animate-in">Voltricx</h1>

    <p class="vtx-subheadline vtx-animate-in">
      The <em>elite Lavalink wrapper</em> for Python — engineered for high-load
      with <strong>dual-tier caching</strong>, smart failover, and a refined developer experience.
    </p>

    <div class="vtx-hero-actions vtx-animate-in">
      <a href="getting-started/installation/" class="vtx-btn vtx-btn-primary vtx-btn-lg">
        Get Started
      </a>
      <a href="getting-started/quickstart/" class="vtx-btn vtx-btn-outline vtx-btn-lg">
        Quick Start
      </a>
    </div>

    <div class="vtx-stats-bar vtx-animate-in">
      <div class="vtx-stat-item">
        <span class="vtx-stat-value" data-target="1000" data-suffix="+">1000+</span>
        <span class="vtx-stat-desc">Cached Tracks</span>
      </div>
      <div class="vtx-stat-sep"></div>
      <div class="vtx-stat-item">
        <span class="vtx-stat-value" data-target="9">9</span>
        <span class="vtx-stat-desc">Audio Filters</span>
      </div>
      <div class="vtx-stat-sep"></div>
      <div class="vtx-stat-item">
        <span class="vtx-stat-value" data-target="15">15</span>
        <span class="vtx-stat-desc">EQ Bands</span>
      </div>
      <div class="vtx-stat-sep"></div>
      <div class="vtx-stat-item">
        <span class="vtx-stat-value" data-target="0" data-prefix="~" data-suffix="ms">~0ms</span>
        <span class="vtx-stat-desc">Cache Latency</span>
      </div>
      <div class="vtx-stat-sep"></div>
      <div class="vtx-stat-item">
        <span class="vtx-stat-value" data-target="3">3</span>
        <span class="vtx-stat-desc">AutoPlay Modes</span>
      </div>
    </div>

  </div>

  <!-- Scroll hint -->
  <div class="vtx-scroll-hint">
    <div class="vtx-scroll-mouse">
      <div class="vtx-scroll-wheel"></div>
    </div>
  </div>
</div>

<!-- ═════════════════════════════════════════════════════════════
     CODE SECTION
     ═════════════════════════════════════════════════════════════ -->
<div class="vtx-section vtx-section-code">
  <div class="vtx-section-container">

    <div class="vtx-reveal">
      <p class="vtx-section-label">Zero friction</p>
      <h2 class="vtx-section-title">Up in 30 seconds.</h2>
      <p class="vtx-section-desc">Three imports. One connect call. Your music bot is playing.</p>
    </div>

    <div class="vtx-code-window vtx-reveal">
      <div class="vtx-code-titlebar">
        <div class="vtx-code-dots">
          <div class="vtx-dot vtx-dot-red"></div>
          <div class="vtx-dot vtx-dot-yellow"></div>
          <div class="vtx-dot vtx-dot-green"></div>
        </div>
        <span class="vtx-code-filename">music_bot.py</span>
        <span class="vtx-code-lang-badge">Python</span>
      </div>
      <div class="vtx-code-body">
<pre><code><span class="vtx-k">import</span> discord
<span class="vtx-k">from</span> discord.ext <span class="vtx-k">import</span> commands
<span class="vtx-k">import</span> <span class="vtx-cls">voltricx</span>

<span class="vtx-c"># ── Setup ────────────────────────────────────────</span>
<span class="vtx-k">class</span> <span class="vtx-cls">MusicBot</span>(commands.<span class="vtx-cls">Bot</span>):
    <span class="vtx-k">async def</span> <span class="vtx-fn">setup_hook</span>(<span class="vtx-b">self</span>):
        <span class="vtx-k">await</span> voltricx.<span class="vtx-cls">Pool</span>.<span class="vtx-fn">connect</span>(
            client=<span class="vtx-b">self</span>,
            nodes=[voltricx.<span class="vtx-cls">NodeConfig</span>(
                identifier=<span class="vtx-s">"Main"</span>,
                uri=<span class="vtx-s">"http://localhost:2333"</span>,
                password=<span class="vtx-s">"youshallnotpass"</span>,
            )],
            cache_config={<span class="vtx-s">"capacity"</span>: <span class="vtx-n">100</span>, <span class="vtx-s">"track_capacity"</span>: <span class="vtx-n">1000</span>},
        )

bot = <span class="vtx-cls">MusicBot</span>(command_prefix=<span class="vtx-s">"!"</span>, intents=discord.<span class="vtx-cls">Intents</span>.<span class="vtx-fn">all</span>())

<span class="vtx-c"># ── Play command ─────────────────────────────────</span>
<span class="vtx-p">@</span>bot.<span class="vtx-fn">command</span>()
<span class="vtx-k">async def</span> <span class="vtx-fn">play</span>(ctx, <span class="vtx-p">*</span>, query: <span class="vtx-cls">str</span>):
    player: voltricx.<span class="vtx-cls">Player</span> = (
        ctx.voice_client <span class="vtx-k">or</span>
        <span class="vtx-k">await</span> ctx.author.voice.channel.<span class="vtx-fn">connect</span>(cls=voltricx.<span class="vtx-cls">Player</span>)
    )
    results = <span class="vtx-k">await</span> voltricx.<span class="vtx-cls">Pool</span>.<span class="vtx-fn">fetch_tracks</span>(query)
    track = results[<span class="vtx-n">0</span>] <span class="vtx-k">if isinstance</span>(results, <span class="vtx-cls">list</span>) <span class="vtx-k">else</span> results.tracks[<span class="vtx-n">0</span>]
    player.queue.<span class="vtx-fn">put</span>(track)
    <span class="vtx-k">if not</span> player.playing:
        <span class="vtx-k">await</span> player.<span class="vtx-fn">play</span>(player.queue.<span class="vtx-fn">get</span>())
    <span class="vtx-k">await</span> ctx.<span class="vtx-fn">send</span>(<span class="vtx-s">f"🎵 Queued **{track.title}**"</span>)

bot.<span class="vtx-fn">run</span>(<span class="vtx-s">"TOKEN"</span>)</code></pre>
      </div>
    </div>

  </div>
</div>

<!-- ═════════════════════════════════════════════════════════════
     FEATURES SECTION
     ═════════════════════════════════════════════════════════════ -->
<div class="vtx-section vtx-section-features">
  <div class="vtx-section-container">

    <div class="vtx-reveal">
      <p class="vtx-section-label">Built different</p>
      <h2 class="vtx-section-title">Everything you need. Nothing you don't.</h2>
      <p class="vtx-section-desc">Every feature was designed around real production requirements — not feature lists.</p>
    </div>

    <div class="vtx-features-grid">

      <div class="vtx-feature-card vtx-reveal">
        <div class="vtx-feature-icon vtx-icon-violet">⚡</div>
        <h3>HyperCache Engine</h3>
        <p>Dual-tier <code>LRU + LFU</code> caching with frequency decay. Repeat queries are served at zero latency — no network, no Lavalink round-trip.</p>
      </div>

      <div class="vtx-feature-card vtx-reveal">
        <div class="vtx-feature-icon vtx-icon-cyan">🧬</div>
        <h3>Fully Typed with Pydantic v2</h3>
        <p>Every model, response, and payload is validated at runtime. Full IDE autocomplete on every attribute — no more guessing field names.</p>
      </div>

      <div class="vtx-feature-card vtx-reveal">
        <div class="vtx-feature-icon vtx-icon-green">🛰️</div>
        <h3>Intelligent Failover</h3>
        <p>Penalty-based node scoring with <em>silent</em> player migration. When a node drops, your guild's music keeps playing. Users never notice.</p>
      </div>

      <div class="vtx-feature-card vtx-reveal">
        <div class="vtx-feature-icon vtx-icon-amber">🎛️</div>
        <h3>Rich Filter Suite</h3>
        <p>All Lavalink v4 filters: <code>Equalizer</code>, <code>Timescale</code>, <code>Karaoke</code>, <code>Vibrato</code>, <code>Rotation</code>, <code>Distortion</code>, <code>ChannelMix</code>, <code>LowPass</code>.</p>
      </div>

      <div class="vtx-feature-card vtx-reveal">
        <div class="vtx-feature-icon vtx-icon-rose">🔐</div>
        <h3>DAVE Protocol</h3>
        <p>Scaffolding for Discord's Audio Video Encryption — E2EE audio for secure voice sessions. Future-proof from day one.</p>
      </div>

      <div class="vtx-feature-card vtx-reveal">
        <div class="vtx-feature-icon vtx-icon-indigo">⚖️</div>
        <h3>Smart Load Balancing</h3>
        <p>Region-aware node routing. CPU load, frame stats, and player count all feed the algorithm — automatically, every request.</p>
      </div>

      <div class="vtx-feature-card vtx-reveal">
        <div class="vtx-feature-icon vtx-icon-pink">🎵</div>
        <h3>AutoPlay Engine</h3>
        <p>Three autoplay modes with YouTube Radio recommendations. The queue never runs dry unless you explicitly want it to.</p>
      </div>

      <div class="vtx-feature-card vtx-reveal">
        <div class="vtx-feature-icon vtx-icon-blue">⏱️</div>
        <h3>Inactivity Manager</h3>
        <p>Nanosecond-precision idle tracking. Configurable timeouts auto-disconnect idle players, freeing node resources silently.</p>
      </div>

    </div>
  </div>
</div>

<!-- ═════════════════════════════════════════════════════════════
     ARCHITECTURE SECTION
     ═════════════════════════════════════════════════════════════ -->
<div class="vtx-section vtx-section-arch">
  <div class="vtx-section-container">

    <div class="vtx-reveal">
      <p class="vtx-section-label">How it works</p>
      <h2 class="vtx-section-title">A pool, nodes, players — clear hierarchy.</h2>
      <p class="vtx-section-desc">One Pool manages N Nodes. Each Node manages M Players. HyperCache sits between you and the network.</p>
    </div>

    <div class="vtx-reveal" style="text-align:left;max-width:800px;margin:0 auto;">

```mermaid
graph TD
    A[🤖 Your Discord Bot] -->|Pool.connect| B[🌐 Pool]
    B -->|manages| C[📡 Node — Primary]
    B -->|manages| D[📡 Node — Backup]
    B -->|L1 LRU| E[💾 Query Cache]
    B -->|L2 LFU| F[📚 Track Registry]
    C -->|WebSocket + REST| G[🎵 Lavalink Server 1]
    D -->|WebSocket + REST| H[🎵 Lavalink Server 2]
    B -->|spawns| I[🎧 Player]
    I -->|controls| J[🔊 Voice Channel]
    I -->|owns| K[📋 Queue + History]
    I -->|has| L[🎛️ Filter Chain]
```

    </div>

  </div>
</div>



<!-- ═════════════════════════════════════════════════════════════
     CTA SECTION
     ═════════════════════════════════════════════════════════════ -->
<div class="vtx-section vtx-section-cta">
  <div class="vtx-section-container">
    <div class="vtx-cta-card vtx-reveal">
      <div class="vtx-cta-glow"></div>
      <h2 class="vtx-cta-title">Start building in minutes.</h2>
      <p class="vtx-cta-desc">
        Install Voltricx, connect a Lavalink node, and your first music command is live.
        No boilerplate. No ceremony.
      </p>
      <div class="vtx-cta-install">
        <code>pip install voltricx</code>
      </div>
      <div class="vtx-cta-actions">
        <a href="getting-started/installation/" class="vtx-btn vtx-btn-primary vtx-btn-lg">
          Read the Docs
        </a>
        <a href="getting-started/quickstart/" class="vtx-btn vtx-btn-outline vtx-btn-lg">
          Quick Start
        </a>
        <a href="https://github.com/ded-lmfao/voltricx" class="vtx-btn vtx-btn-ghost" target="_blank">
          Star on GitHub ★
        </a>
      </div>
    </div>
  </div>
</div>
