---
title: Changelog
description: Release history and changes for Voltricx.
---

# Changelog

All notable changes to Voltricx are documented here. Voltricx follows [Semantic Versioning](https://semver.org/).

---

## [1.0.5] — 2026-03-20

### Added
- `player.is_idle` property — `True` when connected but not playing
- `player.idle_time` property — seconds the player has been continuously idle
- `player.inactive_timeout` property setter — update timeout in real time, even while idle
- `pool.get_random_cached_track()` — returns a random Playable from HyperCache L2
- `Pool.export_cache_data()` — export full HyperCache state for debugging
- `HyperCache.resize_from_config()` — resize using a config dict or model
- DAVE protocol scaffolding for future E2EE audio support

### Changed
- Inactivity countdown no longer starts at `connect()` time — it only begins when a track finishes and the queue is exhausted
- `Player.position` now uses nanosecond precision monotonic timestamps
- `Pool._display_report()` now shows coloured output in terminals

### Fixed
- Race condition where `_inactivity_task` could run after a new track started
- `pool._handle_node_failover` now retries node discovery for up to 5 seconds
- `Queue.get()` in `loop_all` mode now correctly refills from history

---

## [1.0.4] — 2026-02-14

### Added
- `HyperCache` — dual-tier LRU/LFU caching system
- `Pool.connect()` — new unified connection API with `cache_config` and `default_search_source`
- `Pool.fetch_tracks()` — alias for `get_tracks` with region and node overrides
- `Player.migrate_to()` — migrate a player to a different node
- `Player.switch_node()` — switch node and resume state

### Changed
- `Node` penalty formula now weighs frame nulled events 2× more heavily
- Pydantic v2 models replace all manual dataclasses
- `NodeConfig` now accepts `retries=None` for unlimited reconnect attempts

### Removed
- `Pool.add_node()` (replaced by `Pool.connect()`)
- `Pool.get_tracks()` (use `Pool.fetch_tracks()`)

---

## [1.0.3] — 2026-01-10

### Added
- `QueueMode.loop_all` — auto-refill queue from history
- `Queue.put_at_front()` — priority queueing
- `Queue.swap()` — swap two tracks by index
- `AutoPlayMode` enum — `enabled`, `partial`, `disabled`
- Region-aware node selection in `Pool.get_node()`

### Fixed
- `Queue.get()` raising `IndexError` instead of `QueueEmpty` when history was empty in `loop_all` mode

---

## [1.0.2] — 2025-12-05

### Added
- `Player.autoplay` property
- `Player.auto_queue` — dedicated queue for recommendations
- YouTube Radio-based recommendation engine
- `Filters.from_filters()` class method
- `PluginFilters` class

### Changed
- `Player.play()` now accepts `populate=True` to pre-populate `auto_queue`

---

## [1.0.1] — 2025-11-18

### Added
- `voltricx_logger` — structured logger with enable/disable/level support
- `Node.decode_track()` and `Node.decode_tracks()`
- `Node.fetch_routeplanner_status()`, `free_address()`, `free_all_addresses()`

### Fixed
- WebSocket reconnection loop on code 4014

---

## [1.0.0] — 2025-11-01

Initial release of Voltricx.

### Includes
- `Pool`, `Node`, `Player`, `Queue`, `Filters`
- All Lavalink v4 filter types
- Pydantic v2 typed models
- Full WebSocket event handling
- Automatic node failover
- discord.py 2.0+ compatibility
