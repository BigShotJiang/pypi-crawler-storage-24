import re
import typer
from pathlib import Path
from rich import print
from datetime import date
import uuid
app = typer.Typer()

TASK_PATTERN = re.compile(r"^(\s*)- \[( |x)\] (.*)")
DUE_PATTERN = re.compile(r"due:(\d{4}-\d{2}-\d{2})")
ID_PATTERN = re.compile(r"\bid:([0-9a-f]{6})\b")



def generate_id():
    return uuid.uuid4().hex[:6]
class Task:
    def __init__(self, indent, done, text, line_no):
        self.indent = indent
        self.done = done
        self.text = text
        self.line_no = line_no

    def __repr__(self):
        status = "✓" if self.done else " "
        return f"{self.line_no:03} [{status}] {self.text}"


def parse_tasks(file_path):
    tasks = []
    path = Path(file_path)
    if not path.exists():
        return [], []
    lines = path.read_text().splitlines()

    for i, line in enumerate(lines):
        m = TASK_PATTERN.match(line)
        if m:
            indent, done, text = m.groups()
            tasks.append(Task(len(indent), done == "x", text, i))

    return tasks, lines

def find_task_by_id(tasks, task_id):
    for t in tasks:
        m = ID_PATTERN.search(t.text)
        if m and m.group(1) == task_id:
            return t
    return None


def get_due_date(text):
    m = DUE_PATTERN.search(text)
    if not m:
        return None
    return date.fromisoformat(m.group(1))

@app.command()
def list(file: str = "tasks.md"):
    """List tasks"""
    tasks, _ = parse_tasks(file)

    for t in tasks:
        status = "[green]✓[/green]" if t.done else "[red]•[/red]"
        print(f"{t.line_no:03}L {status} {t.text}")


@app.command()
def add(text: str, file: str = "tasks.md"):
    """Add new task"""
    path = Path(file)
    if not path.exists():
        path.touch()
    content = path.read_text()
    task_id = generate_id()

    new_task = f"- [ ] {text} id:{task_id}\n"
    path.write_text(content + "\n" + new_task)

    print("[green]Task added[/green]")


@app.command()
def done(task_id: str, file: str = "tasks.md"):
    """Mark task as done by id"""
    tasks, lines = parse_tasks(file)
    t = find_task_by_id(tasks, task_id)
    if not t:
        print("[red]Task not found[/red]")
        return
    if t.done:
        print("[yellow]Task already completed[/yellow]")
        return
    lines[t.line_no] = re.sub(r"\[ \]", "[x]", lines[t.line_no])
    Path(file).write_text("\n".join(lines))
    print("[green]Task completed[/green]")


@app.command()
def edit(task_id: str, text: str, file: str = "tasks.md"):
    """Edit task text by id"""
    tasks, lines = parse_tasks(file)
    t = find_task_by_id(tasks, task_id)
    if not t:
        print("[red]Task not found[/red]")
        return
    checkbox = "[x]" if t.done else "[ ]"
    indent = " " * t.indent
    lines[t.line_no] = f"{indent}- {checkbox} {text} id:{task_id}"
    Path(file).write_text("\n".join(lines))
    print("[green]Task updated[/green]")


@app.command()
def remove(task_id: str, file: str = "tasks.md"):
    """Remove task by id"""
    tasks, lines = parse_tasks(file)
    t = find_task_by_id(tasks, task_id)
    if not t:
        print("[red]Task not found[/red]")
        return
    lines.pop(t.line_no)
    Path(file).write_text("\n".join(lines))
    print("[green]Task removed[/green]")


@app.command()
def tag(tag: str, file: str = "tasks.md"):
    """Filter tasks by tag"""
    tasks, _ = parse_tasks(file)

    for t in tasks:
        if tag in t.text:
            print(t)


@app.command()
def due(date: str, file: str = "tasks.md"):
    """Filter tasks by due date"""
    tasks, _ = parse_tasks(file)

    for t in tasks:
        if f"due:{date}" in t.text:
            print(t)

@app.command()
def today(file: str = "tasks.md"):
    """Show tasks due today"""

    tasks, _ = parse_tasks(file)
    today = date.today()

    for t in tasks:
        due = get_due_date(t.text)
        if due == today:
            status = "[green]✓[/green]" if t.done else "[red]•[/red]"
            print(f"{t.line_no:03} {status} {t.text}")


@app.command()
def tomorrow(file: str = "tasks.md"):
    """Show tasks due tomorrow"""

    tasks, _ = parse_tasks(file)
    target = date.today() + timedelta(days=1)

    for t in tasks:
        due = get_due_date(t.text)
        if due == target:
            status = "[green]✓[/green]" if t.done else "[red]•[/red]"
            print(f"{t.line_no:03} {status} {t.text}")

from datetime import timedelta

@app.command()
def week(file: str = "tasks.md"):
    """Show tasks due within the next 7 days"""

    tasks, _ = parse_tasks(file)

    today = date.today()
    end = today + timedelta(days=7)

    for t in tasks:
        due = get_due_date(t.text)

        if due and today <= due <= end:
            status = "[green]✓[/green]" if t.done else "[red]•[/red]"
            print(f"{t.line_no:03} {status} {t.text}")

def main():
    app()

if __name__ == "__main__":
    main()
