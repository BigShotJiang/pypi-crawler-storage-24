"""Hybrid 3-stage search with spreading activation."""

from __future__ import annotations

import math
from time import time

from synaptic.models import ActivatedNode, Node, NodeKind, SearchResult
from synaptic.protocols import QueryRewriter, StorageBackend
from synaptic.resonance import ResonanceScorer
from synaptic.synonyms import expand_synonyms

# Kind-query 키워드 매핑 (쿼리에 이런 단어가 있으면 해당 kind 부스트)
_KIND_QUERY_HINTS: dict[NodeKind, list[str]] = {
    NodeKind.LESSON: [
        "실패", "에러", "오류", "장애", "교훈", "배운", "주의",
        "failure", "error", "incident", "lesson", "postmortem",
    ],
    NodeKind.RULE: [
        "규칙", "정책", "규정", "금지", "필수", "가이드",
        "rule", "policy", "constraint", "must", "forbidden",
    ],
    NodeKind.DECISION: [
        "결정", "선택", "판단", "채택", "어떻게",
        "decision", "choice", "decided", "approach",
    ],
    NodeKind.ARTIFACT: [
        "api", "엔드포인트", "스키마", "명세", "코드",
        "endpoint", "schema", "spec", "interface",
    ],
    NodeKind.ENTITY: [
        "회사", "조직", "제품", "서비스", "시스템",
        "company", "organization", "product", "service",
    ],
}
_KIND_BOOST = 0.05  # kind 매칭 시 search_score 부스트량 (보수적)


def _cosine_sim(a: list[float], b: list[float]) -> float:
    """두 벡터의 코사인 유사도."""
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(x * x for x in b))
    if na == 0 or nb == 0:
        return 0.0
    return dot / (na * nb)


class HybridSearch:
    """3-stage fallback search: FTS+vector → synonym expansion → query rewrite."""

    __slots__ = ("_query_rewriter", "_scorer", "_spread_decay", "_spread_depth")

    def __init__(
        self,
        *,
        scorer: ResonanceScorer | None = None,
        query_rewriter: QueryRewriter | None = None,
        spread_decay: float = 0.25,
        spread_depth: int = 1,
    ) -> None:
        self._scorer = scorer or ResonanceScorer()
        self._query_rewriter = query_rewriter
        self._spread_decay = spread_decay
        self._spread_depth = spread_depth

    async def search(
        self,
        backend: StorageBackend,
        query: str,
        *,
        limit: int = 10,
        embedding: list[float] | None = None,
        node_kinds: list[NodeKind] | None = None,
    ) -> SearchResult:
        start = time()
        stages_used: list[str] = []
        all_nodes: dict[str, tuple[Node, float]] = {}

        # Stage 1: FTS + vector hybrid scoring
        fts_scores: dict[str, float] = {}
        fts_nodes = await backend.search_fts(query, limit=limit * 2)
        stages_used.append("fts")
        for rank, node in enumerate(fts_nodes):
            # FTS 순위 기반 점수: 1위=0.95, 감소율 0.05
            score = max(0.3, 0.95 - rank * 0.05)
            fts_scores[node.id] = score
            all_nodes[node.id] = (node, score)

        vec_scores: dict[str, float] = {}
        if embedding:
            vec_nodes = await backend.search_vector(embedding, limit=limit * 2)
            stages_used.append("vector")
            for rank, node in enumerate(vec_nodes):
                # Vector 순위 기반 점수 + 실제 cosine similarity 반영
                rank_score = max(0.3, 0.95 - rank * 0.05)
                # cosine similarity 직접 계산 (가능한 경우)
                if node.embedding and embedding:
                    sim = _cosine_sim(embedding, node.embedding)
                    vec_score = sim * 0.7 + rank_score * 0.3  # sim 우선
                else:
                    vec_score = rank_score
                vec_scores[node.id] = vec_score

            # FTS + vector 하이브리드 점수 합산
            alpha = 0.5  # FTS vs vector 가중치 (0.5 = 동등)
            for nid, node in {n.id: n for n in vec_nodes}.items():
                fts_s = fts_scores.get(nid, 0.0)
                vec_s = vec_scores.get(nid, 0.0)
                if nid in all_nodes:
                    # 양쪽 다 있으면 하이브리드 점수
                    hybrid = alpha * fts_s + (1 - alpha) * vec_s + 0.1  # 양쪽 매칭 보너스
                    all_nodes[nid] = (all_nodes[nid][0], min(1.0, hybrid))
                else:
                    # vector only
                    all_nodes[nid] = (node, vec_s * 0.9)  # FTS 매칭 없으면 약간 감쇠

        # Stage 2: Synonym expansion (if insufficient results)
        if len(all_nodes) < limit:
            expansions = expand_synonyms(query)
            for expanded_query in expansions[:3]:
                extra = await backend.search_fts(expanded_query, limit=limit)
                for node in extra:
                    if node.id not in all_nodes:
                        all_nodes[node.id] = (node, 0.5)
            if expansions:
                stages_used.append("synonym")

        # Stage 3: Query rewriter fallback (LLM-based)
        if len(all_nodes) < limit and self._query_rewriter is not None:
            rewritten = await self._query_rewriter.rewrite(query)
            for rq in rewritten[:2]:
                extra = await backend.search_fts(rq, limit=limit)
                for node in extra:
                    if node.id not in all_nodes:
                        all_nodes[node.id] = (node, 0.4)
            stages_used.append("rewriter")

        # Spreading activation: expand from top candidates
        total_candidates = len(all_nodes)
        top_ids = sorted(all_nodes, key=lambda nid: all_nodes[nid][1], reverse=True)[:5]
        for nid in top_ids:
            parent_score = all_nodes[nid][1]
            neighbors = await backend.get_neighbors(nid, depth=self._spread_depth)
            for neighbor_node, edge in neighbors:
                activation = parent_score * edge.weight * self._spread_decay
                if neighbor_node.id not in all_nodes:
                    all_nodes[neighbor_node.id] = (neighbor_node, max(0.0, min(1.0, activation)))
                else:
                    # 이미 있으면 미세 부스트만 (FTS 직접 매칭 랭킹 보존)
                    existing = all_nodes[neighbor_node.id]
                    boosted = min(1.0, existing[1] + activation * 0.1)
                    if boosted > existing[1]:
                        all_nodes[neighbor_node.id] = (existing[0], boosted)

        # Filter by node_kinds if specified
        if node_kinds:
            kind_set = set(node_kinds)
            all_nodes = {
                nid: (node, score)
                for nid, (node, score) in all_nodes.items()
                if node.kind in kind_set
            }

        # Kind-intent boost: 쿼리 키워드와 매칭되는 kind에 부스트
        preferred_kinds: set[NodeKind] = set()
        q_lower = query.lower()
        for kind, hints in _KIND_QUERY_HINTS.items():
            if any(h in q_lower for h in hints):
                preferred_kinds.add(kind)

        # Tag-query boost: 쿼리 키워드가 노드 태그에 있으면 부스트
        query_terms_set = set(query.lower().split())

        # Score with resonance
        now = time()
        activated: list[ActivatedNode] = []
        for _nid, (node, search_score) in all_nodes.items():
            # kind 부스트
            if preferred_kinds and node.kind in preferred_kinds:
                search_score = min(1.0, search_score + _KIND_BOOST)
            # tag 부스트 (정확 매칭만 — 2글자 이상 태그만)
            if node.tags and query_terms_set:
                tag_set = {t.lower() for t in node.tags if len(t) >= 2}
                tag_overlap = len(query_terms_set & tag_set)
                if tag_overlap > 0:
                    search_score = min(1.0, search_score + tag_overlap * 0.03)

            resonance = self._scorer.score(node, search_score=search_score, now=now)
            activated.append(
                ActivatedNode(
                    node=node,
                    activation=search_score,
                    resonance=resonance,
                    path=[],
                )
            )

        # Sort by resonance descending
        activated.sort(key=lambda a: a.resonance, reverse=True)

        elapsed_ms = (time() - start) * 1000
        return SearchResult(
            query=query,
            nodes=activated[:limit],
            total_candidates=total_candidates,
            search_time_ms=elapsed_ms,
            stages_used=stages_used,
        )
