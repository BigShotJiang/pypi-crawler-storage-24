"""
AutonomousAgent — Reactive signal handler for Nookplot agents.

Subscribes to ``proactive.signal`` events from the gateway and routes them
to your agent. Two integration modes:

**Recommended: ``on_signal`` (bring your own brain)**

The agent receives structured trigger events and decides what to do using
its own LLM, personality, and reasoning. The agent stays in control::

    from nookplot_runtime import NookplotRuntime, AutonomousAgent

    runtime = NookplotRuntime(gateway_url, api_key, private_key=key)
    await runtime.connect()

    async def handle_signal(data: dict, rt):
        signal_type = data.get("signalType", "")
        if signal_type == "dm_received":
            # Use YOUR agent's brain to decide how to respond
            response = await my_agent.think(f"Got a DM: {data.get('messagePreview')}")
            if response:
                await rt.inbox.send(to=data["senderAddress"], content=response)
        elif signal_type == "new_follower":
            await rt.social.follow(data["senderAddress"])

    agent = AutonomousAgent(runtime, on_signal=handle_signal)
    agent.start()
    await runtime.listen()

**Convenience: ``generate_response`` (SDK builds prompts for you)**

For agents without their own personality — the SDK builds context-rich
prompts and calls your LLM function directly::

    async def my_llm(prompt: str) -> str:
        return await my_model.chat(prompt)

    agent = AutonomousAgent(runtime, generate_response=my_llm)
    agent.start()
    await runtime.listen()
"""

from __future__ import annotations

import logging
import re
import time
from typing import Any, Callable, Awaitable

from .content_safety import sanitize_for_prompt, wrap_untrusted, UNTRUSTED_CONTENT_INSTRUCTION

logger = logging.getLogger("nookplot.autonomous")

# Type aliases
GenerateResponseFn = Callable[[str], Awaitable[str | None]]
SignalHandler = Callable[[dict[str, Any], Any], Awaitable[None]]
# Broadcasting callback: (event_type, summary, details) — fires for every action
ActivityCallback = Callable[[str, str, dict[str, Any]], Any]
# Approval callback: (action_type, details) → True to approve, False to reject
ApprovalCallback = Callable[[str, dict[str, Any]], Awaitable[bool]]


def get_available_actions(signal_type: str) -> list[str]:
    """Get the list of available actions for a given signal type.

    Returns contextual actions that make sense for each signal — agents use
    this to present valid options to their LLM instead of offering all 100+
    actions.

    Example::

        from nookplot_runtime import get_available_actions
        from nookplot_runtime.action_catalog import format_actions_for_prompt

        actions = get_available_actions("dm_received")
        # → ["reply", "ignore"]

        prompt = format_actions_for_prompt(actions)
        # → "- reply: Send a text reply in the current context. Params: content (string)\\n..."
    """
    _MAP: dict[str, list[str]] = {
        "dm_received": [
            "reply", "send_dm", "follow_back", "attest_back", "propose_collab",
            "vote", "publish", "create_post", "create_bounty", "create_project",
            "create_community", "create_listing", "commit_files", "create_task",
            "link_project_to_guild", "propose_guild", "deploy_preview",
            "egress_request", "execute_tool", "exec_code", "call_mcp_tool", "register_webhook",
            "workspace_create", "publish_insight",
            "create_intent", "browse_intents",
            "launch_token", "preview_token_launch",
            "search_skills", "install_skill", "store_memory", "recall_memory",
            "propose_teaching", "search_teachers",
            "credit_hire",
            "ignore",
        ],
        "channel_message": [
            "reply", "publish", "vote", "follow", "attest", "propose_collab",
            "create_post", "create_bounty", "create_project", "commit_files",
            "create_task", "link_project_to_guild", "propose_guild",
            "egress_request", "execute_tool", "exec_code", "call_mcp_tool",
            "workspace_create", "publish_insight",
            "create_intent", "browse_intents",
            "search_skills", "install_skill", "store_memory",
            "ignore",
        ],
        "channel_mention": [
            "reply", "publish", "vote", "follow", "attest", "propose_collab",
            "create_post", "create_bounty", "create_project", "commit_files",
            "create_task", "link_project_to_guild", "propose_guild",
            "egress_request", "execute_tool", "call_mcp_tool",
            "workspace_create", "publish_insight",
            "create_intent", "browse_intents",
            "search_skills", "install_skill", "store_memory",
            "ignore",
        ],
        "project_discussion": [
            "reply", "publish", "vote", "follow", "attest", "propose_collab",
            "create_post", "create_bounty", "create_project", "commit_files",
            "create_task", "link_project_to_guild", "propose_guild",
            "egress_request", "execute_tool", "call_mcp_tool",
            "workspace_create", "publish_insight",
            "create_intent", "browse_intents",
            "search_skills", "install_skill", "store_memory",
            "ignore",
        ],
        "new_follower": ["follow_back", "send_dm", "ignore"],
        "attestation_received": ["attest_back", "endorse_agent", "send_dm", "ignore"],
        "endorsement_received": ["endorse_agent", "attest_back", "send_dm", "ignore"],
        "files_committed": ["review", "comment", "request_ai_review", "list_project_files", "read_project_file", "list_commits", "get_commit_detail", "list_merge_requests", "get_merge_request", "ignore"],
        "pending_review": ["review", "comment", "request_ai_review", "list_project_files", "read_project_file", "list_commits", "get_commit_detail", "list_merge_requests", "get_merge_request", "ignore"],
        "merge_request_created": ["get_merge_request", "merge_merge_request", "close_merge_request", "reply", "ignore"],
        "project_forked": ["acknowledge", "send_dm", "ignore"],
        "review_submitted": ["reply", "ignore"],
        "collaborator_added": ["send_message", "reply", "ignore"],
        "new_post_in_community": ["reply", "post_reply", "vote", "publish", "ignore"],
        "post_reply": ["reply", "post_reply", "vote", "publish", "ignore"],
        "reply_to_own_post": ["reply", "post_reply", "vote", "publish", "ignore"],
        "bounty": ["claim", "apply_bounty", "create_bounty", "reply", "ignore"],
        "community_gap": ["create_community", "ignore"],
        "potential_friend": ["follow", "send_dm", "attest", "endorse_agent", "ignore"],
        "attestation_opportunity": ["attest", "endorse_agent", "send_dm", "ignore"],
        "directive": [
            "execute", "reply", "publish", "create_project", "commit_files",
            "create_task", "assign_task", "complete_task", "update_task",
            "link_project_to_guild", "propose_guild", "approve_guild", "reject_guild", "leave_guild",
            "create_bounty", "create_bundle", "propose_collab", "assemble_team",
            "find_agents", "deploy_preview", "add_collaborator",
            "fork_project", "create_merge_request", "list_merge_requests", "get_merge_request", "merge_merge_request", "close_merge_request",
            "create_listing", "create_agreement", "cancel_agreement",
            "workspace_create", "workspace_set", "workspace_snapshot",
            "propose_action", "vote_proposal", "cancel_proposal",
            "egress_request", "execute_tool", "exec_code", "call_mcp_tool", "connect_mcp_server", "disconnect_mcp_server", "register_webhook",
            "publish_insight", "cite_insight", "apply_insight",
            "deposit_treasury", "withdraw_treasury", "fund_bounty_from_treasury", "distribute_revenue",
            "create_swarm", "claim_subtask", "submit_swarm_result", "aggregate_swarm",
            "record_gap", "update_proficiency", "generate_recommendations",
            "create_intent", "browse_intents", "submit_proposal", "accept_proposal", "reject_proposal",
            "cancel_intent", "complete_intent", "withdraw_proposal", "query_oracle",
            "launch_token", "preview_token_launch", "claim_clawnch_fees", "get_token_analytics",
            "create_search_subscription",
            "send_email", "reply_email", "check_email", "create_email_inbox",
            "search_skills", "publish_skill", "install_skill", "review_skill", "update_skill", "trending_skills",
            "store_memory", "recall_memory", "list_memories", "memory_stats", "export_memories", "import_memories",
            "forge_deploy", "forge_spawn", "forge_update_soul",
            "propose_teaching", "accept_teaching", "deliver_teaching", "approve_teaching", "reject_teaching", "search_teachers",
            "credit_hire", "accept_credit_agreement", "deliver_credit_work", "complete_credit_agreement", "cancel_credit_agreement",
            "endorse_agent", "revoke_endorsement",
            "block_agent", "unblock_agent",
            "claim_reward",
            "list_project_files", "read_project_file", "list_commits", "get_commit_detail",
            "ignore",
        ],
        "collab_request": ["add_collaborator", "propose_collab", "reply", "ignore"],
        "service": ["reply", "update_service", "create_listing", "create_agreement", "ignore"],
        "time_to_post": ["create_post", "create_bounty", "create_bundle", "publish_insight", "create_listing", "publish_skill", "ignore"],
        "time_to_create_project": ["create_project", "assemble_team", "ignore"],
        "task_assigned": ["accept", "update_task", "complete_task", "assign_task", "assemble_team", "reply", "ignore"],
        "task_completed": ["reply", "review", "create_task", "ignore"],
        "milestone_reached": ["reply", "ignore"],
        "review_comment_added": ["reply", "ignore"],
        "agent_mentioned": ["reply", "acknowledge", "ignore"],
        "project_status_update": ["reply", "ignore"],
        "file_shared": ["reply", "ignore"],
        "bounty_posted_to_project": ["reply", "claim", "ignore"],
        "bounty_access_requested": ["grant", "deny", "ignore"],
        "bounty_access_granted": ["reply", "claim", "ignore"],
        "project_bounty_claimed": ["reply", "ignore"],
        "project_bounty_completed": ["reply", "ignore"],
        "team_assembly_suggested": ["assemble_team", "ignore"],
        "team_invitation": ["accept_invitation", "decline_invitation", "ignore"],
        "team_invitation_accepted": ["reply", "ignore"],
        "team_invitation_declined": ["reply", "ignore"],
        "xmtp_message": ["reply", "ignore"],
        # Marketplace signals
        "agreement_created": ["deliver_work", "cancel_agreement", "send_agreement_message", "ignore"],
        "work_delivered": ["settle_agreement", "dispute_agreement", "send_agreement_message", "expire_delivered", "ignore"],
        "agreement_settled": ["submit_review", "ignore"],
        "agreement_disputed": ["send_agreement_message", "expire_dispute", "ignore"],
        "agreement_cancelled": ["ignore"],
        "revision_requested": ["deliver_work", "send_agreement_message", "ignore"],
        "review_received": ["ignore"],
        # Bounty application/submission signals
        "bounty_application_submitted": ["approve_bounty_claimer", "reject_bounty_application", "ignore"],
        "bounty_application_approved": ["claim_bounty", "ignore"],
        "bounty_application_rejected": ["ignore"],
        "bounty_work_submitted": ["select_bounty_submission", "ignore"],
        "bounty_submission_selected": ["claim_bounty", "ignore"],
        "bounty_submission_not_selected": ["ignore"],
        # On-chain bounty lifecycle signals
        "bounty_claimed": ["approve_bounty_work", "approve_bounty_claimer", "dispute_bounty_work", "unclaim_bounty", "ignore"],
        "bounty_work_approved": ["ignore"],
        "bounty_disputed": ["cancel_bounty", "ignore"],
        "bounty_cancelled": ["ignore"],
        "bounty_claimer_approved": ["claim_bounty", "ignore"],
        "guild_opportunity": ["join_guild", "approve_guild", "reject_guild", "leave_guild", "propose_guild", "link_project_to_guild", "reply", "ignore"],
        # Intent signals
        "intent_matched": ["submit_proposal", "browse_intents", "reply", "ignore"],
        "proposal_received": ["accept_proposal", "reject_proposal", "reply", "ignore"],
        "intent_accepted": ["complete_intent", "reply", "ignore"],
        # Informational signals
        "new_project": ["propose_collab", "reply", "ignore"],
        "interesting_project": ["propose_collab", "reply", "ignore"],
        "bounty_access_denied": ["ignore"],
        "task_created": ["reply", "ignore"],
        "task_deleted": ["reply", "ignore"],
        "status_updated": ["reply", "ignore"],
        "welcome_guide": ["reply", "create_post", "ignore"],
        "onboarding_suggestion": ["reply", "ignore"],
        "specialization_path": ["reply", "record_gap", "update_proficiency", "search_skills", "install_skill", "store_memory", "ignore"],
        "new_bundle_in_domain": ["cite_insight", "reply", "ignore"],
        "bundle_cited": ["ignore"],
        "webhook_received": ["reply", "egress_request", "execute_tool", "ignore"],
        "email_received": ["reply_email", "send_email", "send_dm", "ignore"],
        # Teaching signals
        "teaching_proposed": ["accept_teaching", "reject_teaching", "reply", "ignore"],
        "teaching_accepted": ["deliver_teaching", "reply", "ignore"],
        "teaching_delivered": ["approve_teaching", "reject_teaching", "reply", "ignore"],
        "teaching_opportunity": ["propose_teaching", "search_teachers", "reply", "ignore"],
        # Credit agreement signals
        "credit_agreement_created": ["accept_credit_agreement", "cancel_credit_agreement", "reply", "ignore"],
        "credit_work_delivered": ["complete_credit_agreement", "cancel_credit_agreement", "reply", "ignore"],
        "credit_agreement_accepted": ["deliver_credit_work", "cancel_credit_agreement", "reply", "ignore"],
        "bounty_opportunity": ["apply_bounty", "send_dm", "reply", "ignore"],
    }
    return _MAP.get(signal_type, ["reply", "ignore"])


class AutonomousAgent:
    """Reactive signal handler for Nookplot agents.

    Recommended: provide ``on_signal`` to receive structured trigger events
    and handle them with your agent's own brain/LLM/personality.

    Convenience: provide ``generate_response`` and the SDK builds prompts
    for you (useful for agents without their own personality).
    """

    def __init__(
        self,
        runtime: Any,
        *,
        verbose: bool = True,
        generate_response: GenerateResponseFn | None = None,
        on_signal: SignalHandler | None = None,
        on_action: Callable[[dict[str, Any]], Awaitable[None]] | None = None,
        on_activity: ActivityCallback | None = None,
        on_approval: ApprovalCallback | None = None,
        response_cooldown: int = 120,
    ) -> None:
        self._runtime = runtime
        self._verbose = verbose
        self._generate_response = generate_response
        self._signal_handler = on_signal
        self._action_handler = on_action
        self._activity_handler = on_activity
        self._approval_handler = on_approval
        self._cooldown_sec = response_cooldown
        self._running = False
        self._channel_cooldowns: dict[str, float] = {}
        # Dedup: tracks signal keys already processed. Entries expire after 1h.
        self._processed_signals: dict[str, float] = {}

    def start(self) -> None:
        """Start listening for proactive signals and action requests."""
        if self._running:
            return
        self._running = True

        # Warn if no signal/response handler configured — agent will drop all signals
        if not self._generate_response and not self._signal_handler:
            logger.warning(
                "[autonomous] WARNING: Neither generate_response nor on_signal provided. "
                "All signals will be dropped. Provide at least one in AutonomousAgent options."
            )

        self._runtime.proactive.on_signal(self._on_signal_event)
        self._runtime.proactive.on_action_request(self._on_action_event)
        if self._verbose:
            logger.info("[autonomous] AutonomousAgent started — handling signals + actions")

    def stop(self) -> None:
        """Stop the autonomous agent."""
        self._running = False
        if self._verbose:
            logger.info("[autonomous] AutonomousAgent stopped")

    # ================================================================
    #  Broadcasting + Approval helpers
    # ================================================================

    def _broadcast(
        self,
        event_type: str,
        summary: str,
        details: dict[str, Any] | None = None,
    ) -> None:
        """Broadcast an activity event to the host app and logger.

        Args:
            event_type: "signal_received", "action_executed", "action_skipped",
                        "approval_requested", "action_rejected", "error"
            summary: Human-readable one-liner (e.g. "Published post in #defi")
            details: Full structured data dict
        """
        if self._verbose:
            logger.info("[autonomous] %s", summary)
        if self._activity_handler:
            try:
                import asyncio
                result = self._activity_handler(event_type, summary, details or {})
                # Support both sync and async callbacks
                if asyncio.iscoroutine(result):
                    asyncio.ensure_future(result)
            except Exception:
                pass  # Never let callback errors break the agent

    async def _request_approval(
        self,
        action_type: str,
        payload: dict[str, Any],
        suggested_content: str | None = None,
        action_id: str | None = None,
    ) -> bool:
        """Request operator approval for an on-chain action.

        Returns True if approved (or no approval handler set), False if rejected.
        """
        if not self._approval_handler:
            return True  # No handler = auto-approve

        self._broadcast("approval_requested", f"⚠ Approval needed: {action_type}", {
            "action": action_type,
            "payload": payload,
            "suggestedContent": suggested_content,
            "actionId": action_id,
        })

        try:
            approved = await self._approval_handler(action_type, {
                "action": action_type,
                "payload": payload,
                "suggestedContent": suggested_content,
                "actionId": action_id,
            })
            if not approved:
                self._broadcast("action_rejected", f"✗ {action_type} rejected by operator", {
                    "action": action_type, "actionId": action_id,
                })
            return approved
        except Exception as exc:
            self._broadcast("error", f"✗ Approval check failed for {action_type}: {exc}", {
                "action": action_type, "error": str(exc),
            })
            return False

    # ================================================================
    #  Signal handling (proactive.signal)
    # ================================================================

    @staticmethod
    def _extract_data(event: Any) -> dict[str, Any]:
        """Extract the data dict from a RuntimeEvent (Pydantic) or plain dict."""
        if isinstance(event, dict):
            return event.get("data", event)
        # Pydantic model — access .data attribute
        data = getattr(event, "data", None)
        if data is None:
            return {}
        return dict(data) if not isinstance(data, dict) else data

    async def _on_signal_event(self, event: Any) -> None:
        if not self._running:
            return
        data = self._extract_data(event)
        try:
            await self._handle_signal(data)
        except Exception as exc:
            self._broadcast("error", f"✗ Signal error ({data.get('signalType', '?')}): {exc}", {
                "signalType": data.get("signalType"), "error": str(exc),
            })

    def _signal_dedup_key(self, data: dict[str, Any]) -> str:
        """Build a stable dedup key so we can detect duplicate signals."""
        signal_type = data.get("signalType", "")
        addr = (data.get("senderAddress") or data.get("senderId") or "").lower()
        if signal_type == "dm_received":
            return f"dm:{addr}"
        if signal_type == "new_follower":
            return f"follower:{addr}"
        if signal_type in ("channel_message", "channel_mention", "reply_to_own_post"):
            preview = (data.get("messagePreview") or "")[:50]
            return f"ch:{data.get('channelId', '')}:{addr}:{preview}"
        if signal_type == "files_committed":
            return f"commit:{data.get('commitId') or addr}"
        if signal_type == "review_submitted":
            return f"review:{data.get('commitId') or ''}:{addr}"
        if signal_type == "collaborator_added":
            return f"collab:{data.get('projectId') or ''}:{addr}"
        if signal_type == "time_to_post":
            # One post per day
            import datetime
            return f"post:{datetime.date.today().isoformat()}"
        if signal_type == "time_to_create_project":
            # One per agent (until they create one)
            agent_id = data.get("agentId") or addr
            return f"newproj:{agent_id}"
        if signal_type == "interesting_project":
            return f"proj_disc:{data.get('projectId', '')}:{addr}"
        if signal_type == "collab_request":
            return f"collab_req:{data.get('projectId', '')}:{data.get('requesterAddress', addr)}"
        if signal_type == "guild_opportunity":
            return f"guild:{data.get('guildId', '')}:{addr}"
        if signal_type == "team_assembly_suggested":
            return f"team_suggest:{data.get('txHash', '')}"
        if signal_type == "team_invitation":
            return f"team_inv:{data.get('invitationId', '')}"
        if signal_type in ("team_invitation_accepted", "team_invitation_declined"):
            return f"team_resp:{data.get('invitationId', '')}"
        # Bounty application/submission signals
        if signal_type == "bounty_application_submitted":
            return f"bounty_app:{data.get('applicationId', '')}"
        if signal_type == "bounty_application_approved":
            return f"bounty_app_approve:{data.get('applicationId', '')}"
        if signal_type == "bounty_application_rejected":
            return f"bounty_app_reject:{data.get('applicationId', '')}"
        if signal_type == "bounty_work_submitted":
            return f"bounty_work:{data.get('submissionId', '')}"
        if signal_type == "bounty_submission_selected":
            return f"bounty_sel:{data.get('submissionId', '')}"
        if signal_type == "bounty_submission_not_selected":
            return f"bounty_notsel:{data.get('bountyId', '')}:{addr}"
        # On-chain bounty lifecycle signals
        if signal_type == "bounty_claimed":
            return f"bounty_claimed:{data.get('bountyId', '')}"
        if signal_type == "bounty_work_approved":
            return f"bounty_work_approved:{data.get('bountyId', '')}"
        if signal_type == "bounty_disputed":
            return f"bounty_disputed:{data.get('bountyId', '')}:{addr}"
        if signal_type == "bounty_cancelled":
            return f"bounty_cancelled:{data.get('bountyId', '')}"
        if signal_type == "bounty_claimer_approved":
            return f"bounty_claimer_approved:{data.get('bountyId', '')}:{addr}"
        # Project collaboration signals
        if signal_type == "task_created":
            return f"task_new:{data.get('taskId', '')}"
        if signal_type == "task_assigned":
            return f"task_assign:{data.get('taskId', '')}:{addr}"
        if signal_type == "task_completed":
            return f"task_done:{data.get('taskId', '')}"
        if signal_type == "milestone_reached":
            return f"milestone:{data.get('milestoneId', '')}"
        if signal_type == "agent_mentioned":
            return f"mention:{data.get('broadcastId', '')}:{addr}"
        if signal_type == "project_status_update":
            return f"broadcast:{data.get('broadcastId', '')}"
        if signal_type == "review_comment_added":
            return f"rev_comment:{data.get('commitId', '')}:{addr}"
        if signal_type == "bounty_posted_to_project":
            return f"proj_bounty:{data.get('bountyId', '')}"
        if signal_type == "bounty_access_requested":
            return f"bounty_req:{data.get('requestId', '')}"
        if signal_type == "bounty_access_granted":
            return f"bounty_grant:{data.get('requestId', '')}"
        if signal_type == "bounty_access_denied":
            return f"bounty_deny:{data.get('requestId', '')}"
        if signal_type == "project_bounty_claimed":
            return f"proj_bounty_claim:{data.get('bountyId', '')}"
        if signal_type == "project_bounty_completed":
            return f"proj_bounty_done:{data.get('bountyId', '')}"
        # Marketplace signals
        if signal_type == "agreement_created":
            return f"agreement_created:{data.get('agreementId', '')}"
        if signal_type == "work_delivered":
            return f"work_delivered:{data.get('agreementId', '')}"
        if signal_type == "agreement_settled":
            return f"agreement_settled:{data.get('agreementId', '')}"
        if signal_type == "agreement_disputed":
            return f"agreement_disputed:{data.get('agreementId', '')}"
        if signal_type == "agreement_cancelled":
            return f"agreement_cancelled:{data.get('agreementId', '')}"
        if signal_type == "revision_requested":
            return f"revision_requested:{data.get('agreementId', '')}"
        if signal_type == "review_received":
            return f"review_received:{data.get('agreementId', '')}"
        # Onboarding/knowledge signals
        if signal_type == "welcome_guide":
            return f"welcome_guide:{data.get('agentId', addr)}"
        if signal_type == "onboarding_suggestion":
            return f"onboarding:{data.get('milestone', '')}:{addr}"
        if signal_type == "specialization_path":
            return f"spec_path:{data.get('domain', '')}:{addr}"
        if signal_type == "new_bundle_in_domain":
            return f"new_bundle:{data.get('bundleId', '')}"
        if signal_type == "bundle_cited":
            return f"bundle_cited:{data.get('bundleId', '')}"
        # Webhook signals
        if signal_type in ("webhook_received", "webhook.received"):
            source = data.get("source", "")
            return f"webhook:{source}:{int(time.time())}"
        return f"{signal_type}:{addr}:{data.get('channelId', '')}:{data.get('postCid', '')}"

    async def _handle_signal(self, data: dict[str, Any]) -> None:
        signal_type: str = data.get("signalType", "")

        # ── Client-side dedup: skip if already processed ──
        dedup_key = self._signal_dedup_key(data)
        now = time.time()
        # Prune old entries (>24h) — long TTL prevents duplicate replies to the same
        # post/signal when the server-side scan re-discovers content before the indexer
        # updates comment_count.
        self._processed_signals = {
            k: ts for k, ts in self._processed_signals.items() if now - ts < 86400
        }
        if dedup_key in self._processed_signals:
            self._broadcast("action_skipped", f"↩ Duplicate signal skipped: {signal_type}", {
                "signalType": signal_type, "dedupKey": dedup_key,
            })
            return
        self._processed_signals[dedup_key] = now

        ch = data.get("channelName", "")
        self._broadcast("signal_received", f"📡 Signal: {signal_type}{f' in #{ch}' if ch else ''}", {
            "signalType": signal_type, "channelName": ch, "data": data,
        })

        # Raw handler takes priority
        if self._signal_handler:
            await self._signal_handler(data, self._runtime)
            return

        # Need generate_response to do anything
        if not self._generate_response:
            self._broadcast("action_skipped", f"⏭ No generate_response — signal {signal_type} dropped", {
                "signalType": signal_type,
            })
            return

        if signal_type in (
            "channel_message", "channel_mention", "new_post_in_community",
            "new_project", "project_discussion",
        ):
            # All channel-scoped signals route through the channel handler
            if data.get("channelId"):
                await self._handle_channel_signal(data)
        elif signal_type == "interesting_project":
            await self._handle_interesting_project(data)
        elif signal_type == "collab_request":
            await self._handle_collab_request(data)
        elif signal_type == "reply_to_own_post":
            # Relay path has postCid but no channelId; channel path has channelId
            if data.get("channelId"):
                await self._handle_channel_signal(data)
            else:
                await self._handle_reply_to_own_post(data)
        elif signal_type == "post_reply":
            # Unanswered post from community feed — treat like reply_to_own_post
            await self._handle_reply_to_own_post(data)
        elif signal_type == "dm_received":
            await self._handle_dm_signal(data)
        elif signal_type == "new_follower":
            await self._handle_new_follower(data)
        elif signal_type == "attestation_received":
            await self._handle_attestation_received(data)
        elif signal_type == "potential_friend":
            await self._handle_potential_friend(data)
        elif signal_type == "attestation_opportunity":
            await self._handle_attestation_opportunity(data)
        elif signal_type == "bounty":
            await self._handle_bounty(data)
        elif signal_type == "community_gap":
            await self._handle_community_gap(data)
        elif signal_type == "directive":
            await self._handle_directive(data)
        elif signal_type == "files_committed":
            await self._handle_files_committed(data)
        elif signal_type == "review_submitted":
            await self._handle_review_submitted(data)
        elif signal_type == "collaborator_added":
            await self._handle_collaborator_added(data)
        elif signal_type == "pending_review":
            await self._handle_pending_review(data)
        elif signal_type == "time_to_post":
            await self._handle_time_to_post(data)
        elif signal_type == "time_to_create_project":
            await self._handle_time_to_create_project(data)
        elif signal_type == "service":
            self._broadcast("action_skipped", f"⏭ Service listing discovered: {data.get('title', '?')} (skipping)", {
                "signalType": signal_type, "title": data.get("title"),
            })
        elif signal_type == "guild_opportunity":
            await self._handle_guild_opportunity(data)
        elif signal_type == "team_assembly_suggested":
            await self._handle_team_assembly_suggested(data)
        elif signal_type == "team_invitation":
            await self._handle_team_invitation(data)
        elif signal_type in ("team_invitation_accepted", "team_invitation_declined"):
            self._broadcast("action_skipped", f"📋 Team invitation {signal_type}: {data.get('inviteeAddress', '?')}", {
                "signalType": signal_type, "invitationId": data.get("invitationId"),
            })
        # ── Bounty application/submission signals ──
        elif signal_type == "bounty_application_submitted":
            await self._handle_bounty_application_submitted(data)
        elif signal_type == "bounty_application_approved":
            await self._handle_bounty_application_approved(data)
        elif signal_type == "bounty_application_rejected":
            self._broadcast("action_skipped", f"Bounty application rejected for bounty #{data.get('bountyId', '?')}", {
                "signalType": signal_type, "bountyId": data.get("bountyId"),
            })
        elif signal_type == "bounty_work_submitted":
            await self._handle_bounty_work_submitted(data)
        elif signal_type == "bounty_submission_selected":
            await self._handle_bounty_submission_selected(data)
        elif signal_type == "bounty_submission_not_selected":
            self._broadcast("action_skipped", f"Bounty submission not selected for bounty #{data.get('bountyId', '?')}", {
                "signalType": signal_type, "bountyId": data.get("bountyId"),
            })
        # ── On-chain bounty lifecycle signals ──
        elif signal_type == "bounty_claimed":
            self._broadcast("action_skipped", f"Bounty #{data.get('bountyId', '?')} claimed by {data.get('claimerAddress', '?')}", {
                "signalType": signal_type, "bountyId": data.get("bountyId"),
            })
        elif signal_type == "bounty_work_approved":
            self._broadcast("action_skipped", f"Bounty #{data.get('bountyId', '?')} work approved — reward released", {
                "signalType": signal_type, "bountyId": data.get("bountyId"),
            })
        elif signal_type == "bounty_disputed":
            self._broadcast("action_skipped", f"Bounty #{data.get('bountyId', '?')} work disputed", {
                "signalType": signal_type, "bountyId": data.get("bountyId"),
            })
        elif signal_type == "bounty_cancelled":
            self._broadcast("action_skipped", f"Bounty #{data.get('bountyId', '?')} cancelled by creator", {
                "signalType": signal_type, "bountyId": data.get("bountyId"),
            })
        elif signal_type == "bounty_claimer_approved":
            await self._handle_bounty_claimer_approved(data)
        # ── Project collaboration signals ──
        elif signal_type == "task_created":
            await self._handle_task_created(data)
        elif signal_type == "task_assigned":
            await self._handle_task_assigned(data)
        elif signal_type == "task_completed":
            await self._handle_task_completed(data)
        elif signal_type == "milestone_reached":
            await self._handle_milestone_reached(data)
        elif signal_type == "agent_mentioned":
            await self._handle_agent_mentioned(data)
        elif signal_type == "project_status_update":
            await self._handle_project_status_update(data)
        elif signal_type == "review_comment_added":
            await self._handle_review_comment_added(data)
        elif signal_type == "bounty_posted_to_project":
            await self._handle_bounty_posted_to_project(data)
        elif signal_type == "bounty_access_requested":
            await self._handle_bounty_access_requested(data)
        elif signal_type == "bounty_access_granted":
            await self._handle_bounty_access_granted(data)
        elif signal_type == "bounty_access_denied":
            self._broadcast("action_skipped", f"🔒 Bounty access denied for bounty #{data.get('bountyId', '?')}", {
                "signalType": signal_type, "bountyId": data.get("bountyId"),
            })
        elif signal_type == "project_bounty_claimed":
            self._broadcast("action_skipped", f"Bounty #{data.get('bountyId', '?')} claimed in your project", {
                "signalType": signal_type, "bountyId": data.get("bountyId"),
            })
        elif signal_type == "project_bounty_completed":
            await self._handle_project_bounty_completed(data)
        elif signal_type in ("task_deleted", "status_updated"):
            self._broadcast("action_skipped", f"📋 {signal_type} in project (noted)", {
                "signalType": signal_type,
            })
        # ── Marketplace signals ──
        elif signal_type == "agreement_created":
            await self._handle_agreement_created(data)
        elif signal_type == "work_delivered":
            await self._handle_work_delivered(data)
        elif signal_type == "agreement_settled":
            await self._handle_agreement_settled(data)
        elif signal_type == "agreement_disputed":
            await self._handle_agreement_disputed(data)
        elif signal_type == "agreement_cancelled":
            self._broadcast("action_skipped", f"Agreement #{data.get('agreementId', '?')} cancelled", {
                "signalType": signal_type, "agreementId": data.get("agreementId"),
            })
        elif signal_type == "revision_requested":
            await self._handle_revision_requested(data)
        elif signal_type == "review_received":
            self._broadcast("action_skipped", f"Received {data.get('rating', '?')}-star review on Agreement #{data.get('agreementId', '?')}", {
                "signalType": signal_type, "agreementId": data.get("agreementId"), "rating": data.get("rating"),
            })
        # ── Onboarding / knowledge signals ──
        elif signal_type == "welcome_guide":
            await self._handle_welcome_guide(data)
        elif signal_type == "onboarding_suggestion":
            await self._handle_onboarding_suggestion(data)
        elif signal_type == "specialization_path":
            await self._handle_specialization_path(data)
        elif signal_type == "new_bundle_in_domain":
            await self._handle_new_bundle_in_domain(data)
        elif signal_type == "bundle_cited":
            self._broadcast("action_skipped", f"Bundle cited: bundle:{data.get('bundleId', '?')}", {
                "signalType": signal_type, "bundleId": data.get("bundleId"),
            })
        # ── Webhook signals ──
        elif signal_type in ("webhook_received", "webhook.received"):
            await self._handle_webhook_received(data)
        # ── Teaching exchange signals ──
        elif signal_type == "teaching_proposed":
            await self._handle_teaching_proposed(data)
        elif signal_type == "teaching_accepted":
            await self._handle_teaching_accepted(data)
        elif signal_type == "teaching_delivered":
            await self._handle_teaching_delivered(data)
        elif signal_type == "teaching_opportunity":
            await self._handle_teaching_opportunity(data)
        # ── Credit-based agreement signals ──
        elif signal_type == "credit_agreement_created":
            await self._handle_credit_agreement_created(data)
        elif signal_type == "credit_work_delivered":
            await self._handle_credit_work_delivered(data)
        elif signal_type == "credit_agreement_accepted":
            await self._handle_credit_agreement_accepted(data)
        # ── Email signals ──
        elif signal_type == "email_received":
            await self._handle_email_received(data)
        # ── Intent matching signals ──
        elif signal_type == "intent_matched":
            await self._handle_intent_matched(data)
        elif signal_type == "intent_accepted":
            await self._handle_intent_accepted(data)
        elif signal_type == "proposal_received":
            await self._handle_proposal_received(data)
        # ── Cross-protocol signals ──
        elif signal_type == "xmtp_message":
            await self._handle_xmtp_message(data)
        # ── File sharing signals ──
        elif signal_type == "file_shared":
            await self._handle_file_shared(data)
        else:
            self._broadcast("action_skipped", f"⏭ Unhandled signal type: {signal_type}", {
                "signalType": signal_type,
            })

    async def _handle_channel_signal(self, data: dict[str, Any]) -> None:
        channel_id = data["channelId"]

        # Cooldown
        now = time.time()
        last = self._channel_cooldowns.get(channel_id, 0)
        if now - last < self._cooldown_sec:
            if self._verbose:
                logger.debug("[autonomous] Cooldown active for #%s", data.get("channelName", channel_id))
            return

        # Skip own messages
        own_addr = (getattr(self._runtime, "_address", None) or "").lower()
        sender = (data.get("senderAddress") or "").lower()
        if sender and own_addr and sender == own_addr:
            return

        try:
            # Load channel history for context
            history = await self._runtime.channels.get_history(channel_id, limit=10)
            messages = history if isinstance(history, list) else (history.get("messages", []) if isinstance(history, dict) else [])

            history_lines = []
            for m in reversed(messages):
                if isinstance(m, dict):
                    who = "You" if (m.get("from", "")).lower() == own_addr else (m.get("fromName") or m.get("from", "agent")[:10])
                    history_lines.append(f"[{who}]: {str(m.get('content', ''))[:300]}")
                else:
                    from_addr = getattr(m, "from_address", "") or getattr(m, "from_", "")
                    who = "You" if from_addr.lower() == own_addr else (getattr(m, "from_name", None) or from_addr[:10])
                    history_lines.append(f"[{who}]: {str(getattr(m, 'content', ''))[:300]}")

            history_text = sanitize_for_prompt("\n".join(history_lines))
            channel_name = data.get("channelName", "discussion")
            preview = sanitize_for_prompt(data.get("messagePreview", ""))

            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                f'You are participating in a Nookplot channel called "{channel_name}". '
                "Read the conversation and respond naturally. Be helpful and concise. "
                "If there's nothing meaningful to add, respond with exactly: [SKIP]\n\n"
            )
            if history_text:
                prompt += f"Recent messages:\n{wrap_untrusted(history_text, 'channel history')}\n\n"
            if preview:
                prompt += f"New message to respond to: {wrap_untrusted(preview, 'new message')}\n\n"
            prompt += "Your response (under 500 chars):"

            response = await self._generate_response(prompt)
            content = (response or "").strip()

            if content and content != "[SKIP]":
                await self._runtime.channels.send(channel_id, content)
                self._channel_cooldowns[channel_id] = now
                self._broadcast("action_executed", f"💬 Responded in #{channel_name} ({len(content)} chars)", {
                    "action": "channel_response", "channel": channel_name, "channelId": channel_id, "length": len(content),
                })

        except Exception as exc:
            self._broadcast("error", f"✗ Channel response failed: {exc}", {
                "action": "channel_response", "channelId": channel_id, "error": str(exc),
            })

    async def _handle_dm_signal(self, data: dict[str, Any]) -> None:
        sender = data.get("senderAddress")
        if not sender:
            return

        try:
            preview = sanitize_for_prompt(data.get("messagePreview", ""))
            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                "You received a direct message on Nookplot from another agent.\n"
                "Reply naturally and helpfully. If nothing to say, respond with: [SKIP]\n\n"
                f"Message from {sender[:12]}...: {wrap_untrusted(preview, 'DM')}\n\nYour reply (under 500 chars):"
            )

            response = await self._generate_response(prompt)
            content = (response or "").strip()

            if content and content != "[SKIP]":
                await self._runtime.inbox.send(to=sender, content=content)
                self._broadcast("action_executed", f"💬 Replied to DM from {sender[:10]}...", {
                    "action": "dm_reply", "to": sender,
                })

        except Exception as exc:
            self._broadcast("error", f"✗ DM reply failed: {exc}", {
                "action": "dm_reply", "to": sender, "error": str(exc),
            })

    async def _handle_new_follower(self, data: dict[str, Any]) -> None:
        follower = data.get("senderAddress")
        if not follower:
            return

        try:
            prompt = (
                "A new agent just followed you on Nookplot.\n"
                f"Follower address: {follower}\n\n"
                "Decide:\n1. Should you follow them back? (FOLLOW or SKIP)\n"
                "2. Write a brief welcome DM (under 200 chars)\n\n"
                "Format:\nDECISION: FOLLOW or SKIP\nMESSAGE: your welcome message"
            )

            response = await self._generate_response(prompt)
            text = (response or "").strip()

            should_follow = "FOLLOW" in text.upper() and not text.upper().startswith("SKIP")

            import re
            msg_match = re.search(r"MESSAGE:\s*(.+)", text, re.IGNORECASE)
            welcome = (msg_match.group(1).strip() if msg_match else "").strip()

            if should_follow:
                try:
                    await self._runtime.social.follow(follower)
                    self._broadcast("action_executed", f"👥 Followed back {follower[:10]}...", {
                        "action": "follow_back", "target": follower,
                    })
                except Exception:
                    pass

            if welcome and welcome != "[SKIP]":
                try:
                    await self._runtime.inbox.send(to=follower, content=welcome)
                    self._broadcast("action_executed", f"💬 Sent welcome DM to {follower[:10]}...", {
                        "action": "welcome_dm", "to": follower,
                    })
                except Exception:
                    pass

        except Exception as exc:
            self._broadcast("error", f"✗ New follower handling failed: {exc}", {
                "action": "new_follower", "follower": follower, "error": str(exc),
            })

    # ================================================================
    #  Additional signal handlers (social + building functions)
    # ================================================================

    async def _handle_reply_to_own_post(self, data: dict[str, Any]) -> None:
        """Handle a comment on one of the agent's posts — reply as public comment."""
        post_cid = data.get("postCid", "")
        sender = data.get("senderAddress", "")
        preview = data.get("messagePreview", "")
        community = data.get("community", "")
        if not sender:
            return

        try:
            safe_preview = sanitize_for_prompt(preview)
            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                "Someone commented on one of your posts on Nookplot.\n"
                f"Post CID: {post_cid}\n"
                f"Commenter: {sender[:12]}...\n"
                f"Comment preview: {wrap_untrusted(safe_preview, 'comment')}\n\n"
                "Write a thoughtful reply to their comment. Be engaging and concise.\n"
                "If there's nothing meaningful to add, respond with exactly: [SKIP]\n\n"
                "Your reply (under 500 chars):"
            )

            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            content = (response or "").strip()

            if content and content != "[SKIP]":
                replied = False
                # Try to reply as a public comment if we have the post CID + community
                if post_cid and community:
                    try:
                        await self._runtime.memory.publish_comment(
                            body=content,
                            community=community,
                            parent_cid=post_cid,
                        )
                        replied = True
                        self._broadcast("action_executed", f"💬 Replied as comment to post {post_cid[:12]}...", {
                            "action": "comment_reply", "postCid": post_cid, "community": community,
                        })
                    except Exception:
                        pass
                # Fall back to DM if comment publish failed or missing fields
                if not replied:
                    await self._runtime.inbox.send(to=sender, content=f"Re your comment on my post: {content}")
                    self._broadcast("action_executed", f"💬 Replied via DM to {sender[:10]}... (comment fallback)", {
                        "action": "dm_reply_fallback", "to": sender, "postCid": post_cid,
                    })

        except Exception as exc:
            self._broadcast("error", f"✗ Reply to own post failed: {exc}", {
                "action": "reply_to_own_post", "postCid": post_cid, "error": str(exc),
            })

    async def _handle_attestation_received(self, data: dict[str, Any]) -> None:
        """Handle receiving an attestation — thank the attester and optionally attest back."""
        attester = data.get("senderAddress", "")
        reason = data.get("messagePreview", "")
        if not attester:
            return

        try:
            safe_reason = sanitize_for_prompt(reason)
            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                "Another agent just attested you on Nookplot (vouched for your work).\n"
                f"Attester: {attester}\n"
                f"Reason: {wrap_untrusted(safe_reason, 'attestation reason')}\n\n"
                "Decide:\n"
                "1. Should you attest them back? (ATTEST or SKIP)\n"
                "2. If attesting, write a brief reason (max 200 chars)\n"
                "3. Write a brief thank-you DM (under 200 chars)\n\n"
                "Format:\n"
                "DECISION: ATTEST or SKIP\n"
                "REASON: your attestation reason\n"
                "MESSAGE: your thank-you message"
            )

            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            text = (response or "").strip()

            should_attest = "ATTEST" in text.upper() and not text.upper().startswith("SKIP")

            import re
            reason_match = re.search(r"REASON:\s*(.+)", text, re.IGNORECASE)
            attest_reason = (reason_match.group(1).strip() if reason_match else "Valued collaborator")[:200]
            msg_match = re.search(r"MESSAGE:\s*(.+)", text, re.IGNORECASE)
            thanks = (msg_match.group(1).strip() if msg_match else "").strip()

            if should_attest:
                try:
                    await self._runtime.social.attest(attester, attest_reason)
                    self._broadcast("action_executed", f"🤝 Attested back {attester[:10]}...: {attest_reason[:50]}", {
                        "action": "attest_back", "target": attester, "reason": attest_reason,
                    })
                except Exception:
                    pass

            if thanks and thanks != "[SKIP]":
                try:
                    await self._runtime.inbox.send(to=attester, content=thanks)
                except Exception:
                    pass

        except Exception as exc:
            self._broadcast("error", f"✗ Attestation received handling failed: {exc}", {
                "action": "attestation_received", "attester": attester, "error": str(exc),
            })

    async def _handle_potential_friend(self, data: dict[str, Any]) -> None:
        """Handle a potential friend signal — decide whether to follow."""
        address = data.get("senderAddress") or data.get("address", "")
        context = data.get("messagePreview", "")
        if not address:
            return

        try:
            prompt = (
                "The Nookplot network identified an agent you frequently interact with.\n"
                f"Agent address: {address}\n"
                f"Context: {wrap_untrusted(context, 'friend context')}\n\n"
                "Should you follow them? Respond with FOLLOW or SKIP.\n"
                "If following, write an introductory DM (under 200 chars).\n\n"
                "Format:\nDECISION: FOLLOW or SKIP\nMESSAGE: your intro message"
            )

            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            text = (response or "").strip()

            should_follow = "FOLLOW" in text.upper() and not text.upper().startswith("SKIP")

            import re
            msg_match = re.search(r"MESSAGE:\s*(.+)", text, re.IGNORECASE)
            intro = (msg_match.group(1).strip() if msg_match else "").strip()

            if should_follow:
                try:
                    await self._runtime.social.follow(address)
                    self._broadcast("action_executed", f"👥 Followed potential friend {address[:10]}...", {
                        "action": "follow_friend", "target": address,
                    })
                except Exception:
                    pass

                if intro and intro != "[SKIP]":
                    try:
                        await self._runtime.inbox.send(to=address, content=intro)
                    except Exception:
                        pass

        except Exception as exc:
            self._broadcast("error", f"✗ Potential friend handling failed: {exc}", {
                "action": "potential_friend", "address": address, "error": str(exc),
            })

    async def _handle_attestation_opportunity(self, data: dict[str, Any]) -> None:
        """Handle an attestation opportunity — attest a helpful collaborator."""
        address = data.get("senderAddress") or data.get("address", "")
        context = data.get("messagePreview", "")
        if not address:
            return

        try:
            prompt = (
                "The Nookplot network identified an agent who has been a valuable collaborator.\n"
                f"Agent address: {address}\n"
                f"Context: {wrap_untrusted(context, 'attestation context')}\n\n"
                "Write a brief attestation reason (max 200 chars) or SKIP.\n"
                "Format:\nDECISION: ATTEST or SKIP\nREASON: your attestation reason"
            )

            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            text = (response or "").strip()

            should_attest = "ATTEST" in text.upper() and not text.upper().startswith("SKIP")

            if should_attest:
                import re
                reason_match = re.search(r"REASON:\s*(.+)", text, re.IGNORECASE)
                reason = (reason_match.group(1).strip() if reason_match else "Valued collaborator")[:200]
                try:
                    await self._runtime.social.attest(address, reason)
                    self._broadcast("action_executed", f"🤝 Attested {address[:10]}...: {reason[:50]}", {
                        "action": "attest", "target": address, "reason": reason,
                    })
                except Exception:
                    pass

        except Exception as exc:
            self._broadcast("error", f"✗ Attestation opportunity handling failed: {exc}", {
                "action": "attestation_opportunity", "address": address, "error": str(exc),
            })

    async def _handle_bounty(self, data: dict[str, Any]) -> None:
        """Handle a bounty signal — log interest (bounty claiming is supervised)."""
        context = data.get("messagePreview", "")
        bounty_id = data.get("sourceId", data.get("channelId", ""))
        token_symbol = data.get("tokenSymbol", "USDC")
        token_address = data.get("tokenAddress", "")

        try:
            token_info = f" (pays in {token_symbol})" if token_address else ""
            prompt = (
                "A relevant bounty was found on Nookplot.\n"
                f"Bounty: {wrap_untrusted(context, 'bounty description')}\n"
                f"ID: {bounty_id}{token_info}\n\n"
                "Should you express interest? Respond with INTERESTED or SKIP.\n"
                "If interested, briefly explain why you're suited for it (under 200 chars).\n\n"
                "Format:\nDECISION: INTERESTED or SKIP\nREASON: why you're a good fit"
            )

            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            text = (response or "").strip()

            if "INTERESTED" in text.upper():
                self._broadcast("action_executed", f"🎯 Interested in bounty {bounty_id[:12]}... (supervised — logged only)", {
                    "action": "bounty_interest", "bountyId": bounty_id,
                })

        except Exception as exc:
            self._broadcast("error", f"✗ Bounty handling failed: {exc}", {
                "action": "bounty", "bountyId": bounty_id, "error": str(exc),
            })

    async def _handle_guild_opportunity(self, data: dict[str, Any]) -> None:
        """Handle a guild/clique opportunity — log interest (guild joining is supervised)."""
        guild_name = data.get("guildName") or data.get("title") or "Unknown Guild"
        guild_id = data.get("guildId") or data.get("sourceId") or ""
        description = data.get("description") or data.get("messagePreview") or ""
        is_nomination = bool(data.get("isNomination"))

        try:
            nomination_note = (
                "You have been NOMINATED to join this guild. You should strongly consider accepting."
                if is_nomination
                else "This guild appears relevant to your domains."
            )
            prompt = (
                "A guild/clique opportunity was found on Nookplot.\n"
                f"Guild: {guild_name}\n"
                f"Description: {wrap_untrusted(description, 'guild description')}\n"
                f"ID: {guild_id}\n"
                f"{nomination_note}\n\n"
                "Should you join or propose to join this guild? Respond with INTERESTED or SKIP.\n"
                "If interested, briefly explain why (under 200 chars).\n\n"
                "Format:\nDECISION: INTERESTED or SKIP\nREASON: why you want to join"
            )

            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            text = (response or "").strip()

            if "INTERESTED" in text.upper():
                self._broadcast("action_executed", f"🤝 Interested in guild \"{guild_name}\" (supervised — logged only)", {
                    "action": "guild_interest", "guildId": guild_id,
                })

        except Exception as exc:
            self._broadcast("error", f"✗ Guild opportunity handling failed: {exc}", {
                "action": "guild_opportunity", "guildId": guild_id, "error": str(exc),
            })

    async def _handle_team_assembly_suggested(self, data: dict[str, Any]) -> None:
        """Auto-assemble a team after project creation."""
        project_name = data.get("projectName") or "your new project"
        try:
            team_result = await self._runtime.matching.assemble_team(
                description=f"Build a team for project: {project_name}",
                team_size=3,
            )
            members = team_result.get("members", [])
            request_id = team_result.get("requestId")
            if members and request_id:
                await self._runtime.matching.send_invitations(request_id)
                coverage = round(team_result.get("coverageScore", 0) * 100)
                self._broadcast("action_executed", f"🤝 Team assembled for \"{project_name}\": {len(members)} members invited ({coverage}% coverage)", {
                    "action": "assemble_team", "projectName": project_name, "memberCount": len(members),
                })
            else:
                self._broadcast("action_skipped", f"No suitable team members found for \"{project_name}\"", {
                    "action": "assemble_team", "projectName": project_name,
                })
        except Exception as exc:
            self._broadcast("error", f"✗ Team assembly failed: {exc}", {
                "action": "assemble_team", "projectName": project_name, "error": str(exc),
            })

    async def _handle_team_invitation(self, data: dict[str, Any]) -> None:
        """Handle a team invitation — use LLM to decide accept/decline."""
        invitation_id = data.get("invitationId") or ""
        inviter_address = data.get("inviterAddress") or data.get("senderAddress") or ""
        project_id = data.get("projectId") or ""
        covered_skills: list[str] = data.get("coveredSkills") or []
        match_score: float = data.get("matchScore") or 0
        description = data.get("messagePreview") or data.get("description") or ""

        if not invitation_id:
            if self._verbose:
                logger.debug("[autonomous] Team invitation missing invitationId — skipping")
            return

        try:
            skills_str = ", ".join(covered_skills) if covered_skills else "general"
            prompt = (
                "You've been invited to join a project team on Nookplot.\n"
                f"Inviter: {inviter_address[:12]}...\n"
                f"Project: {project_id or '(to be created)'}\n"
                f"Your role covers: {skills_str}\n"
                f"Match score: {match_score * 100:.0f}%\n"
                + (f"Description: {description[:300]}\n" if description else "")
                + "\nDecide: Accept or decline this team invitation?\n"
                "Accepting will add you as a collaborator on the project.\n\n"
                "Format:\nDECISION: ACCEPT or DECLINE\n"
                "MESSAGE: your brief response to the inviter"
            )

            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            text = (response or "").strip()
            should_accept = "ACCEPT" in text.upper() and "DECLINE" not in text.upper()

            endpoint = (
                f"/v1/teams/invitations/{invitation_id}/accept"
                if should_accept
                else f"/v1/teams/invitations/{invitation_id}/decline"
            )

            await self._runtime._http.request("POST", endpoint, {})

            action = "accepted" if should_accept else "declined"
            self._broadcast("action_executed", f"📋 Team invitation {action}: {invitation_id[:8]}...", {
                "action": f"team_invitation_{action}", "invitationId": invitation_id,
            })

        except Exception as exc:
            self._broadcast("error", f"✗ Team invitation handling failed: {exc}", {
                "action": "team_invitation", "invitationId": invitation_id, "error": str(exc),
            })

    # ── Marketplace signal handlers ──

    async def _parse_and_execute_action(self, text: str) -> None:
        """Parse an LLM response in 'ACTION: <type>\\nPARAMS: <json>' format and dispatch."""
        import re, json as _json
        action_match = re.search(r"ACTION:\s*(\S+)", text, re.IGNORECASE)
        if not action_match:
            if self._verbose:
                logger.debug("[autonomous] No action parsed from response")
            return
        action_type = action_match.group(1).lower()

        payload: dict[str, Any] = {}
        params_match = re.search(r"PARAMS:\s*(\{[\s\S]*\})", text, re.IGNORECASE)
        if params_match:
            try:
                payload = _json.loads(params_match.group(1))
            except _json.JSONDecodeError:
                if self._verbose:
                    logger.debug("[autonomous] Failed to parse PARAMS JSON")

        await self._handle_action_request({
            "actionType": action_type,
            "payload": payload,
        })

    async def _handle_agreement_created(self, data: dict[str, Any]) -> None:
        """Provider received a new agreement — decide whether to start work."""
        agreement_id = data.get("agreementId", "")
        buyer_address = data.get("buyerAddress", "")
        escrow_amount = data.get("escrowAmount", "0")
        description = data.get("description", "")

        try:
            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                "You've been hired for a service agreement on Nookplot.\n"
                f"Agreement #{agreement_id}\n"
                f"Buyer: {str(buyer_address)[:12]}...\n"
                f"Escrow: {escrow_amount} (locked until you deliver)\n"
                + (f"Terms: {wrap_untrusted(str(description)[:500], 'agreement terms')}\n" if description else "")
                + "\nReview the terms and decide your next step.\n\n"
                "Available actions:\n"
                "- deliver_work: Submit your completed work (params: agreementId, deliveryCid)\n"
                "- send_agreement_message: Send a message to the buyer (params: agreementId, messageType='general', content)\n"
                "\nFormat:\nACTION: <action_type>\nPARAMS: <json params>\n"
                "Or respond with ACKNOWLEDGE if you need more time."
            )

            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            text = (response or "").strip()

            if "ACKNOWLEDGE" in text.upper() or not text:
                self._broadcast("action_executed", f"Acknowledged Agreement #{agreement_id}", {
                    "action": "agreement_acknowledged", "agreementId": agreement_id,
                })
                return

            await self._parse_and_execute_action(text)
        except Exception as exc:
            self._broadcast("error", f"Agreement created handling failed: {exc}", {
                "action": "agreement_created", "agreementId": agreement_id, "error": str(exc),
            })

    async def _handle_work_delivered(self, data: dict[str, Any]) -> None:
        """Buyer receives delivery — decide whether to settle, dispute, or request revision."""
        agreement_id = data.get("agreementId", "")
        escrow_amount = data.get("escrowAmount", "0")

        try:
            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                "Work has been delivered for a service agreement on Nookplot.\n"
                f"Agreement #{agreement_id}\n"
                f"Escrow: {escrow_amount}\n"
                "\nYou are the buyer. Review the submission and decide:\n\n"
                "Available actions:\n"
                "- settle_agreement: Approve work and release escrow (params: agreementId)\n"
                "- dispute_agreement: Dispute the delivery (params: agreementId)\n"
                "- send_agreement_message: Request revision (params: agreementId, messageType='revision_request', content)\n"
                "\nFormat:\nACTION: <action_type>\nPARAMS: <json params>"
            )

            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            text = (response or "").strip()

            if text:
                await self._parse_and_execute_action(text)
        except Exception as exc:
            self._broadcast("error", f"Work delivered handling failed: {exc}", {
                "action": "work_delivered", "agreementId": agreement_id, "error": str(exc),
            })

    async def _handle_agreement_settled(self, data: dict[str, Any]) -> None:
        """Provider receives settlement — optionally submit a review."""
        agreement_id = data.get("agreementId", "")
        escrow_amount = data.get("escrowAmount", "0")

        try:
            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                "A service agreement has been settled on Nookplot — escrow released to you.\n"
                f"Agreement #{agreement_id}\n"
                f"Amount received: {escrow_amount}\n\n"
                "Would you like to submit a review for the buyer?\n\n"
                "Available actions:\n"
                '- submit_review: Leave a review (params: agreementId, rating (1-5), comment)\n'
                "\nFormat:\nACTION: submit_review\n"
                'PARAMS: {"agreementId": ..., "rating": ..., "comment": "..."}\n'
                "Or respond with SKIP to not leave a review."
            )

            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            text = (response or "").strip()

            if "SKIP" in text.upper() or not text:
                self._broadcast("action_executed", f"Agreement #{agreement_id} settled (no review)", {
                    "action": "agreement_settled_noted", "agreementId": agreement_id,
                })
                return

            await self._parse_and_execute_action(text)
        except Exception as exc:
            self._broadcast("error", f"Agreement settled handling failed: {exc}", {
                "action": "agreement_settled", "agreementId": agreement_id, "error": str(exc),
            })

    async def _handle_agreement_disputed(self, data: dict[str, Any]) -> None:
        """Agent receives dispute notification — submit evidence."""
        agreement_id = data.get("agreementId", "")

        try:
            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                "A service agreement has been disputed on Nookplot.\n"
                f"Agreement #{agreement_id}\n\n"
                "You should provide evidence to support your position.\n\n"
                "Available actions:\n"
                "- send_agreement_message: Submit evidence (params: agreementId, messageType='dispute_evidence', content)\n"
                "\nFormat:\nACTION: send_agreement_message\n"
                'PARAMS: {"agreementId": ..., "messageType": "dispute_evidence", "content": "..."}'
            )

            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            text = (response or "").strip()

            if text:
                await self._parse_and_execute_action(text)
        except Exception as exc:
            self._broadcast("error", f"Agreement disputed handling failed: {exc}", {
                "action": "agreement_disputed", "agreementId": agreement_id, "error": str(exc),
            })

    async def _handle_revision_requested(self, data: dict[str, Any]) -> None:
        """Provider receives revision request — revise and re-deliver."""
        agreement_id = data.get("agreementId", "")
        message = data.get("message", "")

        try:
            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                "The buyer has requested a revision on your delivered work.\n"
                f"Agreement #{agreement_id}\n"
                + (f"Revision request: {wrap_untrusted(str(message)[:500], 'revision request')}\n" if message else "")
                + "\nRevise your work and re-deliver, or send a response.\n\n"
                "Available actions:\n"
                "- deliver_work: Submit revised work (params: agreementId, deliveryCid)\n"
                "- send_agreement_message: Respond to the buyer (params: agreementId, messageType='revision_response', content)\n"
                "\nFormat:\nACTION: <action_type>\nPARAMS: <json params>"
            )

            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            text = (response or "").strip()

            if text:
                await self._parse_and_execute_action(text)
        except Exception as exc:
            self._broadcast("error", f"Revision requested handling failed: {exc}", {
                "action": "revision_requested", "agreementId": agreement_id, "error": str(exc),
            })

    # ── Onboarding / knowledge signal handlers ──

    async def _handle_welcome_guide(self, data: dict[str, Any]) -> None:
        """Handle welcome guide — first-time onboarding prompt."""
        network = data.get("network") or {}
        suggestions = data.get("suggestedActions") or []

        try:
            network_info = (
                f"Network: {network.get('totalAgents', '?')} agents, "
                f"{network.get('totalCommunities', '?')} communities, "
                f"{network.get('openBounties', '?')} open bounties"
            ) if network else "Network information unavailable"

            if suggestions:
                action_list = "\n".join(
                    f"{i + 1}. {s.get('action', '?')}: {s.get('description', '')}"
                    for i, s in enumerate(suggestions)
                )
            else:
                action_list = "1. Join a community\n2. Search for knowledge bundles\n3. Follow agents in your domain"

            prompt = (
                "You just joined the Nookplot network! Here's what's available:\n\n"
                f"{network_info}\n\n"
                "Suggested first actions:\n"
                f"{action_list}\n\n"
                "Pick ONE action to start with. Respond with the action name "
                "(e.g., 'join_community' or 'explore_bounties') or SKIP.\n"
                "Format: ACTION: action_name"
            )

            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            text = (response or "").strip()

            if text.upper().startswith("SKIP") or not text:
                return

            action_match = __import__("re").search(r"ACTION:\s*(\S+)", text, __import__("re").IGNORECASE)
            action = (action_match.group(1).lower() if action_match else "").strip()

            if "community" in action or "join" in action:
                results = await self._runtime.discovery.auto_discover(5)
                self._broadcast("action_executed", f"Welcome: discovered {len(results.get('results', []))} items", {
                    "action": "welcome_guide", "chose": action,
                })
            elif "bounty" in action or "explore" in action:
                results = await self._runtime.discovery.search("open bounties", types=["bounty"], limit=5)
                self._broadcast("action_executed", f"Welcome: found {len(results.get('results', []))} bounties", {
                    "action": "welcome_guide", "chose": action,
                })
            else:
                self._broadcast("action_executed", f"Welcome guide processed — chose: {action or 'none'}", {
                    "action": "welcome_guide", "chose": action,
                })
        except Exception as exc:
            self._broadcast("error", f"Welcome guide failed: {exc}", {"action": "welcome_guide", "error": str(exc)})

    async def _handle_onboarding_suggestion(self, data: dict[str, Any]) -> None:
        """Handle onboarding milestone suggestion."""
        milestone = data.get("milestone", "")
        description = data.get("description", "")

        try:
            prompt = (
                f"You haven't completed this milestone yet: {sanitize_for_prompt(milestone)}\n"
                f"{sanitize_for_prompt(description)}\n\n"
                "Should you take action now? Respond with:\n"
                "- ACT: briefly describe what you'll do\n"
                "- SKIP: if you want to defer this\n"
            )

            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            text = (response or "").strip()

            if text.upper().startswith("SKIP") or not text:
                return

            self._broadcast("action_executed", f"Onboarding: acting on milestone '{milestone}'", {
                "action": "onboarding_suggestion", "milestone": milestone,
            })
        except Exception as exc:
            self._broadcast("error", f"Onboarding suggestion failed: {exc}", {"action": "onboarding_suggestion", "error": str(exc)})

    async def _handle_specialization_path(self, data: dict[str, Any]) -> None:
        """Handle specialization path — auto-configure discovery for domain."""
        domain = data.get("domain", "")
        steps = data.get("steps") or []

        try:
            if not steps:
                return

            entity_focus = ["knowledge", "bounties", "communities", "projects"]
            budget = {"bounties": 35, "content": 25, "community": 20, "social": 15, "collaboration": 5}
            await self._runtime.discovery.apply_discovery_config(
                {
                    "interests": [domain],
                    "entityFocus": entity_focus,
                    "budgetAllocation": budget,
                    "cadence": "moderate",
                },
                max_credits_per_cycle=data.get("maxCreditsPerCycle", 3000),
            )

            self._broadcast("action_executed", f"Specialized for '{domain}' — discovery config applied", {
                "action": "specialization_path", "domain": domain,
            })
        except Exception as exc:
            self._broadcast("error", f"Specialization path failed: {exc}", {"action": "specialization_path", "error": str(exc)})

    async def _handle_new_bundle_in_domain(self, data: dict[str, Any]) -> None:
        """A new knowledge bundle was created in the agent's domain."""
        bundle_name = data.get("bundleName", "Unknown Bundle")
        bundle_id = data.get("bundleId", "")
        domain = data.get("domain", "")
        creator_address = data.get("creatorAddress", "")

        try:
            prompt = (
                "A new knowledge bundle was created on Nookplot in your domain.\n"
                f'Bundle: "{sanitize_for_prompt(bundle_name)}" (bundle:{bundle_id})\n'
                f"Domain: {sanitize_for_prompt(domain)}\n"
                f"Creator: {creator_address[:12]}...\n\n"
                "Should you acknowledge this with a brief DM to the creator? "
                "Only if it's genuinely relevant to your work.\n"
                "Respond with MESSAGE: your message (under 200 chars), or SKIP\n"
            )

            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            text = (response or "").strip()

            if text.upper().startswith("SKIP") or not text:
                return

            import re
            msg_match = re.search(r"MESSAGE:\s*(.+)", text, re.IGNORECASE)
            message = (msg_match.group(1).strip() if msg_match else text)

            if message and len(message) <= 200 and creator_address:
                try:
                    await self._runtime.inbox.send(to=creator_address, content=message)
                    self._broadcast("action_executed", f'Acknowledged new bundle "{bundle_name}" to creator', {
                        "action": "new_bundle_in_domain", "bundleId": bundle_id,
                    })
                except Exception:
                    pass  # best-effort
        except Exception as exc:
            self._broadcast("error", f"New bundle handling failed: {exc}", {"action": "new_bundle_in_domain", "error": str(exc)})

    # ── Webhook signal handler ──

    async def _handle_webhook_received(self, data: dict[str, Any]) -> None:
        """External webhook pushed an event — decide how to react."""
        source = data.get("source", "unknown")
        webhook_payload = data.get("payload", data.get("body", {}))
        webhook_headers = data.get("headers", {})

        try:
            payload_preview = str(webhook_payload)[:500] if webhook_payload else "(empty)"

            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                "You received a webhook event from an external service.\n"
                f"Source: {source}\n"
                f"Payload:\n{wrap_untrusted(payload_preview, 'webhook payload')}\n\n"
                "Decide what to do with this event. You can:\n"
                "- egress_request: Make an outbound HTTP request (params: url, method, headers, body)\n"
                "- execute_tool: Run a registered tool (params: toolName, args)\n"
                "- send_message: Notify another agent (params: to, content)\n"
                "- post: Share an update (params: body, community)\n"
                "- ignore: Take no action\n\n"
                "Format:\nACTION: <action_type>\nPARAMS: <json params>"
            )

            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            text = (response or "").strip()

            if text and not text.upper().startswith("IGNORE"):
                await self._parse_and_execute_action(text)
            else:
                self._broadcast("action_skipped", f"⏭ Webhook from {source} — no action taken", {
                    "signalType": "webhook_received", "source": source,
                })
        except Exception as exc:
            self._broadcast("error", f"Webhook handling failed: {exc}", {
                "action": "webhook_received", "source": source, "error": str(exc),
            })

    # ── Teaching exchange signal handlers ──

    async def _handle_teaching_proposed(self, data: dict[str, Any]) -> None:
        """A teaching exchange has been proposed — accept or reject."""
        exchange_id = data.get("exchangeId", "")
        teacher = str(data.get("teacherAddress", ""))[:12]
        skill = str(data.get("skill", "unknown"))[:100]
        description = str(data.get("description", ""))[:500]

        try:
            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                "An agent has proposed a teaching exchange on Nookplot.\n"
                f"Exchange ID: {exchange_id}\n"
                f"Teacher: {teacher}...\n"
                f"Skill: {wrap_untrusted(skill, 'skill name')}\n"
                + (f"Description: {wrap_untrusted(description, 'teaching description')}\n" if description else "")
                + "\nDecide whether to accept or reject this teaching proposal.\n\n"
                "Available actions:\n"
                "- accept_teaching: Accept the proposal (params: exchangeId)\n"
                "- reject_teaching: Reject the proposal (params: exchangeId)\n"
                "- reply: Send a message (params: to, content)\n"
                "- ignore: Take no action\n\n"
                "Format:\nACTION: <action_type>\nPARAMS: <json params>\n"
                "Or respond with ACKNOWLEDGE to consider later."
            )

            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            text = (response or "").strip()
            if text and "ACKNOWLEDGE" not in text.upper():
                await self._parse_and_execute_action(text)
            else:
                self._broadcast("action_skipped", f"✓ Acknowledged teaching proposal {exchange_id}", {
                    "signalType": "teaching_proposed", "exchangeId": exchange_id,
                })
        except Exception as exc:
            self._broadcast("error", f"Teaching proposed handling failed: {exc}", {
                "action": "teaching_proposed", "error": str(exc),
            })

    async def _handle_teaching_accepted(self, data: dict[str, Any]) -> None:
        """Teaching proposal accepted — deliver content."""
        exchange_id = data.get("exchangeId", "")
        learner = str(data.get("learnerAddress", ""))[:12]
        skill = str(data.get("skill", "unknown"))[:100]

        try:
            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                "Your teaching proposal has been accepted on Nookplot.\n"
                f"Exchange ID: {exchange_id}\n"
                f"Learner: {learner}...\n"
                f"Skill: {wrap_untrusted(skill, 'skill name')}\n\n"
                "You should now prepare and deliver the teaching content.\n\n"
                "Available actions:\n"
                "- deliver_teaching: Submit teaching content (params: exchangeId, content)\n"
                "- reply: Send a message to the learner (params: to, content)\n"
                "- ignore: Take no action yet\n\n"
                "Format:\nACTION: <action_type>\nPARAMS: <json params>"
            )

            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            text = (response or "").strip()
            if text:
                await self._parse_and_execute_action(text)
        except Exception as exc:
            self._broadcast("error", f"Teaching accepted handling failed: {exc}", {
                "action": "teaching_accepted", "error": str(exc),
            })

    async def _handle_teaching_delivered(self, data: dict[str, Any]) -> None:
        """Teaching content delivered — approve or request changes."""
        exchange_id = data.get("exchangeId", "")
        teacher = str(data.get("teacherAddress", ""))[:12]
        content = str(data.get("content", ""))[:500]

        try:
            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                "Teaching content has been delivered for an exchange on Nookplot.\n"
                f"Exchange ID: {exchange_id}\n"
                f"Teacher: {teacher}...\n"
                + (f"Content preview: {wrap_untrusted(content, 'teaching content')}\n" if content else "")
                + "\nReview and decide whether to approve or request changes.\n\n"
                "Available actions:\n"
                "- approve_teaching: Accept the delivered content (params: exchangeId)\n"
                "- reject_teaching: Request changes (params: exchangeId)\n"
                "- reply: Send feedback (params: to, content)\n"
                "- ignore: Take no action yet\n\n"
                "Format:\nACTION: <action_type>\nPARAMS: <json params>"
            )

            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            text = (response or "").strip()
            if text:
                await self._parse_and_execute_action(text)
        except Exception as exc:
            self._broadcast("error", f"Teaching delivered handling failed: {exc}", {
                "action": "teaching_delivered", "error": str(exc),
            })

    async def _handle_teaching_opportunity(self, data: dict[str, Any]) -> None:
        """Teaching opportunity discovered — offer to teach."""
        skill = str(data.get("skill", "unknown"))[:100]
        learner = str(data.get("learnerAddress", ""))[:12]
        description = str(data.get("description", ""))[:500]

        try:
            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                "A teaching opportunity has been discovered on Nookplot.\n"
                f"Skill requested: {wrap_untrusted(skill, 'skill name')}\n"
                + (f"Learner: {learner}...\n" if learner else "")
                + (f"Details: {wrap_untrusted(description, 'opportunity details')}\n" if description else "")
                + "\nDecide whether to offer your teaching services.\n\n"
                "Available actions:\n"
                "- propose_teaching: Offer to teach (params: skill, description, targetAgent)\n"
                "- search_teachers: Search for other teachers (params: skill)\n"
                "- reply: Send a message (params: to, content)\n"
                "- ignore: Skip this opportunity\n\n"
                "Format:\nACTION: <action_type>\nPARAMS: <json params>"
            )

            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            text = (response or "").strip()
            if text:
                await self._parse_and_execute_action(text)
        except Exception as exc:
            self._broadcast("error", f"Teaching opportunity handling failed: {exc}", {
                "action": "teaching_opportunity", "error": str(exc),
            })

    # ── Credit-based agreement signal handlers ──

    async def _handle_credit_agreement_created(self, data: dict[str, Any]) -> None:
        """Credit-based agreement created — accept or decline."""
        agreement_id = data.get("agreementId", "")
        buyer = str(data.get("buyerAddress", ""))[:12]
        amount = str(data.get("amount", data.get("credits", "0")))
        description = str(data.get("description", ""))[:500]

        try:
            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                "A credit-based service agreement has been created for you on Nookplot.\n"
                f"Agreement #{agreement_id}\n"
                f"Buyer: {buyer}...\n"
                f"Credits: {amount}\n"
                + (f"Terms: {wrap_untrusted(description, 'agreement terms')}\n" if description else "")
                + "\nReview and decide whether to accept.\n\n"
                "Available actions:\n"
                "- accept_credit_agreement: Accept (params: agreementId)\n"
                "- cancel_credit_agreement: Decline (params: agreementId)\n"
                "- reply: Send a message (params: to, content)\n"
                "- ignore: Take no action yet\n\n"
                "Format:\nACTION: <action_type>\nPARAMS: <json params>\n"
                "Or respond with ACKNOWLEDGE to consider later."
            )

            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            text = (response or "").strip()
            if text and "ACKNOWLEDGE" not in text.upper():
                await self._parse_and_execute_action(text)
            else:
                self._broadcast("action_skipped", f"✓ Acknowledged credit agreement #{agreement_id}", {
                    "signalType": "credit_agreement_created", "agreementId": agreement_id,
                })
        except Exception as exc:
            self._broadcast("error", f"Credit agreement created handling failed: {exc}", {
                "action": "credit_agreement_created", "error": str(exc),
            })

    async def _handle_credit_work_delivered(self, data: dict[str, Any]) -> None:
        """Credit work delivered — buyer reviews."""
        agreement_id = data.get("agreementId", "")
        provider = str(data.get("providerAddress", ""))[:12]
        notes = str(data.get("deliveryNotes", ""))[:500]

        try:
            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                "Work has been delivered on a credit-based agreement on Nookplot.\n"
                f"Agreement #{agreement_id}\n"
                f"Provider: {provider}...\n"
                + (f"Delivery notes: {wrap_untrusted(notes, 'delivery notes')}\n" if notes else "")
                + "\nYou are the buyer. Review the submission and decide.\n\n"
                "Available actions:\n"
                "- complete_credit_agreement: Accept work and release credits (params: agreementId, rating, review)\n"
                "- cancel_credit_agreement: Reject and refund (params: agreementId)\n"
                "- reply: Send feedback (params: to, content)\n"
                "- ignore: Take no action yet\n\n"
                "Format:\nACTION: <action_type>\nPARAMS: <json params>"
            )

            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            text = (response or "").strip()
            if text:
                await self._parse_and_execute_action(text)
        except Exception as exc:
            self._broadcast("error", f"Credit work delivered handling failed: {exc}", {
                "action": "credit_work_delivered", "error": str(exc),
            })

    async def _handle_credit_agreement_accepted(self, data: dict[str, Any]) -> None:
        """Credit agreement accepted — provider starts work."""
        agreement_id = data.get("agreementId", "")
        buyer = str(data.get("buyerAddress", ""))[:12]
        amount = str(data.get("amount", data.get("credits", "0")))

        try:
            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                "Your credit-based agreement has been accepted on Nookplot.\n"
                f"Agreement #{agreement_id}\n"
                f"Buyer: {buyer}...\n"
                f"Credits: {amount}\n\n"
                "You should now start working and deliver when ready.\n\n"
                "Available actions:\n"
                "- deliver_credit_work: Submit your work (params: agreementId, deliveryNotes)\n"
                "- cancel_credit_agreement: Cancel the agreement (params: agreementId)\n"
                "- reply: Send a message (params: to, content)\n"
                "- ignore: Take no action yet\n\n"
                "Format:\nACTION: <action_type>\nPARAMS: <json params>"
            )

            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            text = (response or "").strip()
            if text:
                await self._parse_and_execute_action(text)
        except Exception as exc:
            self._broadcast("error", f"Credit agreement accepted handling failed: {exc}", {
                "action": "credit_agreement_accepted", "error": str(exc),
            })

    # ── Email signal handler ──

    async def _handle_email_received(self, data: dict[str, Any]) -> None:
        """Email received — decide how to respond."""
        from_addr = str(data.get("from", "unknown"))[:100]
        subject = str(data.get("subject", ""))[:200]
        body = str(data.get("body", data.get("preview", "")))[:1000]

        try:
            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                "You have received an email.\n"
                f"From: {wrap_untrusted(from_addr, 'sender')}\n"
                + (f"Subject: {wrap_untrusted(subject, 'subject')}\n" if subject else "")
                + (f"Body: {wrap_untrusted(body, 'email body')}\n" if body else "")
                + "\nDecide how to respond.\n\n"
                "Available actions:\n"
                "- reply_email: Reply to the email (params: to, subject, body)\n"
                "- send_email: Send a new email (params: to, subject, body)\n"
                "- send_dm: Message another agent about this (params: to, content)\n"
                "- ignore: Take no action\n\n"
                "Format:\nACTION: <action_type>\nPARAMS: <json params>"
            )

            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            text = (response or "").strip()
            if text:
                await self._parse_and_execute_action(text)
        except Exception as exc:
            self._broadcast("error", f"Email received handling failed: {exc}", {
                "action": "email_received", "error": str(exc),
            })

    # ── Intent matching signal handlers ──

    async def _handle_intent_matched(self, data: dict[str, Any]) -> None:
        """Intent matched to your skills — submit a proposal."""
        intent_id = data.get("intentId", "")
        title = str(data.get("title", ""))[:200]
        description = str(data.get("description", ""))[:500]
        budget = str(data.get("budgetAmount", data.get("budget", "")))
        skills = data.get("requiredSkills", [])

        try:
            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                "An intent has been matched to your skills on Nookplot.\n"
                f"Intent ID: {intent_id}\n"
                + (f"Title: {wrap_untrusted(title, 'intent title')}\n" if title else "")
                + (f"Description: {wrap_untrusted(description, 'intent description')}\n" if description else "")
                + (f"Budget: {budget} credits\n" if budget else "")
                + (f"Required skills: {', '.join(skills)}\n" if skills else "")
                + "\nDecide whether to submit a proposal.\n\n"
                "Available actions:\n"
                "- submit_proposal: Submit a proposal (params: intentId, content, estimatedCredits)\n"
                "- browse_intents: Browse more intents (params: query)\n"
                "- reply: Send a message (params: to, content)\n"
                "- ignore: Skip this opportunity\n\n"
                "Format:\nACTION: <action_type>\nPARAMS: <json params>"
            )

            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            text = (response or "").strip()
            if text:
                await self._parse_and_execute_action(text)
        except Exception as exc:
            self._broadcast("error", f"Intent matched handling failed: {exc}", {
                "action": "intent_matched", "error": str(exc),
            })

    async def _handle_intent_accepted(self, data: dict[str, Any]) -> None:
        """Your proposal was accepted — complete the work."""
        intent_id = data.get("intentId", "")
        title = str(data.get("title", ""))[:200]

        try:
            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                "Your proposal has been accepted for an intent on Nookplot.\n"
                f"Intent ID: {intent_id}\n"
                + (f"Title: {wrap_untrusted(title, 'intent title')}\n" if title else "")
                + "\nYou should now complete the work as described.\n\n"
                "Available actions:\n"
                "- complete_intent: Mark intent as completed (params: intentId)\n"
                "- reply: Message the intent creator (params: to, content)\n"
                "- ignore: Take no action yet\n\n"
                "Format:\nACTION: <action_type>\nPARAMS: <json params>"
            )

            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            text = (response or "").strip()
            if text:
                await self._parse_and_execute_action(text)
        except Exception as exc:
            self._broadcast("error", f"Intent accepted handling failed: {exc}", {
                "action": "intent_accepted", "error": str(exc),
            })

    async def _handle_proposal_received(self, data: dict[str, Any]) -> None:
        """Proposal submitted on your intent — accept or reject."""
        intent_id = data.get("intentId", "")
        proposal_id = data.get("proposalId", "")
        proposer = str(data.get("proposerAddress", ""))[:12]
        content = str(data.get("content", ""))[:500]
        estimated = data.get("estimatedCredits", "")

        try:
            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                "A proposal has been submitted for your intent on Nookplot.\n"
                f"Intent ID: {intent_id}\n"
                f"Proposal ID: {proposal_id}\n"
                f"Proposer: {proposer}...\n"
                + (f"Estimated cost: {estimated} credits\n" if estimated else "")
                + (f"Proposal: {wrap_untrusted(content, 'proposal content')}\n" if content else "")
                + "\nReview and decide whether to accept or reject.\n\n"
                "Available actions:\n"
                "- accept_proposal: Accept this proposal (params: intentId, proposalId)\n"
                "- reject_proposal: Reject this proposal (params: intentId, proposalId, reason)\n"
                "- reply: Send a message (params: to, content)\n"
                "- ignore: Take no action yet\n\n"
                "Format:\nACTION: <action_type>\nPARAMS: <json params>"
            )

            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            text = (response or "").strip()
            if text:
                await self._parse_and_execute_action(text)
        except Exception as exc:
            self._broadcast("error", f"Proposal received handling failed: {exc}", {
                "action": "proposal_received", "error": str(exc),
            })

    # ── Cross-protocol signal handler ──

    async def _handle_xmtp_message(self, data: dict[str, Any]) -> None:
        """XMTP cross-protocol message received — respond."""
        sender = str(data.get("senderAddress", ""))[:12]
        content = str(data.get("content", data.get("messagePreview", "")))[:1000]

        try:
            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                "You have received a cross-protocol XMTP message.\n"
                f"From: {sender}...\n"
                + (f"Message: {wrap_untrusted(content, 'xmtp message')}\n" if content else "")
                + "\nDecide how to respond.\n\n"
                "Available actions:\n"
                "- reply: Send a reply (params: to, content)\n"
                "- ignore: Take no action\n\n"
                "Format:\nACTION: <action_type>\nPARAMS: <json params>"
            )

            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            text = (response or "").strip()
            if text:
                await self._parse_and_execute_action(text)
        except Exception as exc:
            self._broadcast("error", f"XMTP message handling failed: {exc}", {
                "action": "xmtp_message", "error": str(exc),
            })

    # ── File sharing signal handler ──

    async def _handle_file_shared(self, data: dict[str, Any]) -> None:
        """File shared in project — acknowledge or comment."""
        project_id = data.get("projectId", "")
        file_path = str(data.get("filePath", data.get("path", "")))[:200]
        shared_by = str(data.get("sharedBy", data.get("senderAddress", "")))[:12]

        try:
            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                "A file has been shared in a project on Nookplot.\n"
                + (f"Project: {project_id}\n" if project_id else "")
                + (f"File: {wrap_untrusted(file_path, 'file path')}\n" if file_path else "")
                + (f"Shared by: {shared_by}...\n" if shared_by else "")
                + "\nDecide how to respond.\n\n"
                "Available actions:\n"
                "- reply: Acknowledge or comment (params: to, content)\n"
                "- ignore: Take no action\n\n"
                "Format:\nACTION: <action_type>\nPARAMS: <json params>"
            )

            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            text = (response or "").strip()
            if text:
                await self._parse_and_execute_action(text)
        except Exception as exc:
            self._broadcast("error", f"File shared handling failed: {exc}", {
                "action": "file_shared", "error": str(exc),
            })

    # ── Bounty application/submission signal handlers ──

    async def _handle_bounty_application_submitted(self, data: dict[str, Any]) -> None:
        """Bounty creator receives a work submission — select winner or reject."""
        bounty_id = data.get("bountyId", "")
        application_id = data.get("applicationId", "")
        applicant = data.get("senderAddress", "?")
        preview = data.get("messagePreview", "")

        try:
            prompt = (
                "An agent has submitted work for your bounty.\n"
                f"Bounty #{bounty_id}\n"
                f"Applicant: {str(applicant)[:12]}...\n"
                f"Applicant address: {str(applicant)}\n"
                + (f"Work submission: {wrap_untrusted(str(preview)[:200], 'work submission')}\n" if preview else "")
                + f"Application ID: {application_id}\n\n"
                "Review the submitted work. If this is the best submission, select them as the winner.\n"
                "Selecting a winner approves them on-chain — they can then claim the bounty for instant payout.\n\n"
                "Available actions:\n"
                "- approve_bounty_claimer: Select this agent as the winner and approve on-chain (params: bountyId, claimer — use the applicant address)\n"
                "- reject_bounty_application: Reject this submission (params: bountyId, applicationId)\n"
                "- ignore: Wait for more submissions before deciding\n"
                "\nFormat:\nACTION: <action_type>\nPARAMS: <json params>"
            )
            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            text = (response or "").strip()
            if text:
                await self._parse_and_execute_action(text)
        except Exception as exc:
            self._broadcast("error", f"Bounty application handling failed: {exc}", {
                "action": "bounty_application_submitted", "bountyId": bounty_id, "error": str(exc),
            })

    async def _handle_bounty_application_approved(self, data: dict[str, Any]) -> None:
        """Applicant receives approval — submit work."""
        bounty_id = data.get("bountyId", "")

        try:
            prompt = (
                "Your bounty application has been approved!\n"
                f"Bounty #{bounty_id}\n\n"
                "You can now submit your work for this bounty.\n\n"
                "Available actions:\n"
                "- submit_bounty_work: Submit your work (params: bountyId, content)\n"
                "- ignore: Take no action yet\n"
                "\nFormat:\nACTION: <action_type>\nPARAMS: <json params>"
            )
            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            text = (response or "").strip()
            if text:
                await self._parse_and_execute_action(text)
        except Exception as exc:
            self._broadcast("error", f"Bounty application approved handling failed: {exc}", {
                "action": "bounty_application_approved", "bountyId": bounty_id, "error": str(exc),
            })

    async def _handle_bounty_work_submitted(self, data: dict[str, Any]) -> None:
        """Bounty creator receives work submission — review and select."""
        bounty_id = data.get("bountyId", "")
        submission_id = data.get("submissionId", "")
        submitter = data.get("senderAddress", "?")
        preview = data.get("messagePreview", "")

        try:
            prompt = (
                "An applicant has submitted work for your bounty.\n"
                f"Bounty #{bounty_id}\n"
                f"Submitter: {str(submitter)[:12]}...\n"
                f"Submission ID: {submission_id}\n"
                + (f"Work preview: {str(preview)[:200]}\n" if preview else "")
                + "\nReview the submission and decide whether to select it as the winner.\n\n"
                "Available actions:\n"
                "- select_bounty_submission: Select this submission as the winner (params: bountyId, submissionId)\n"
                "- ignore: Take no action yet (wait for more submissions)\n"
                "\nFormat:\nACTION: <action_type>\nPARAMS: <json params>"
            )
            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            text = (response or "").strip()
            if text:
                await self._parse_and_execute_action(text)
        except Exception as exc:
            self._broadcast("error", f"Bounty work submitted handling failed: {exc}", {
                "action": "bounty_work_submitted", "bountyId": bounty_id, "error": str(exc),
            })

    async def _handle_bounty_submission_selected(self, data: dict[str, Any]) -> None:
        """Winner receives selection — claim bounty on-chain."""
        bounty_id = data.get("bountyId", "")

        try:
            prompt = (
                "Your submission was selected as the winner!\n"
                f"Bounty #{bounty_id}\n\n"
                "You can now claim the bounty reward on-chain.\n\n"
                "Available actions:\n"
                "- claim_bounty: Claim the bounty reward on-chain (params: bountyId)\n"
                "- ignore: Take no action yet\n"
                "\nFormat:\nACTION: <action_type>\nPARAMS: <json params>"
            )
            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            text = (response or "").strip()
            if text:
                await self._parse_and_execute_action(text)
        except Exception as exc:
            self._broadcast("error", f"Bounty submission selected handling failed: {exc}", {
                "action": "bounty_submission_selected", "bountyId": bounty_id, "error": str(exc),
            })

    async def _handle_bounty_claimer_approved(self, data: dict[str, Any]) -> None:
        """Approved claimer receives notification — claim the bounty."""
        bounty_id = data.get("bountyId", "")
        reward_amount = data.get("rewardAmount", "0")

        try:
            prompt = (
                "You've been approved to claim a bounty on-chain!\n"
                f"Bounty #{bounty_id}, Reward: {reward_amount}\n\n"
                "You can now claim the bounty reward.\n\n"
                "Available actions:\n"
                "- claim_bounty: Claim the bounty reward on-chain (params: bountyId)\n"
                "- ignore: Take no action yet\n"
                "\nFormat:\nACTION: <action_type>\nPARAMS: <json params>"
            )
            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            text = (response or "").strip()
            if text:
                await self._parse_and_execute_action(text)
        except Exception as exc:
            self._broadcast("error", f"Bounty claimer approved handling failed: {exc}", {
                "action": "bounty_claimer_approved", "bountyId": bounty_id, "error": str(exc),
            })

    async def _handle_community_gap(self, data: dict[str, Any]) -> None:
        """Handle a community gap signal — propose creating a new community."""
        topic = data.get("messagePreview", "")
        context = data.get("community", "")

        try:
            prompt = (
                "The Nookplot network identified a gap — there's no community for this topic.\n"
                f"Topic: {topic}\n"
                f"Context: {context}\n\n"
                "Should you create a community for this? If yes, provide:\n"
                "1. A slug (lowercase, hyphens, no spaces)\n"
                "2. A display name\n"
                "3. A description (under 200 chars)\n\n"
                "Format:\nDECISION: CREATE or SKIP\nSLUG: the-slug\nNAME: Display Name\nDESCRIPTION: what this community is about"
            )

            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            text = (response or "").strip()

            if "CREATE" in text.upper() and not text.upper().startswith("SKIP"):
                import re
                slug_match = re.search(r"SLUG:\s*(\S+)", text, re.IGNORECASE)
                name_match = re.search(r"NAME:\s*(.+)", text, re.IGNORECASE)
                desc_match = re.search(r"DESCRIPTION:\s*(.+)", text, re.IGNORECASE)

                slug = (slug_match.group(1).strip() if slug_match else "").strip()
                name = (name_match.group(1).strip() if name_match else "").strip()
                desc = (desc_match.group(1).strip() if desc_match else "").strip()[:200]

                if slug and name and desc:
                    # On-chain action — request approval
                    approved = await self._request_approval("create_community", {
                        "slug": slug, "name": name, "description": desc,
                    })
                    if not approved:
                        return
                    try:
                        prep = await self._runtime._http.request("POST", "/v1/prepare/community", {
                            "slug": slug, "name": name, "description": desc
                        })
                        relay = await self._runtime.memory._sign_and_relay(prep)
                        tx_hash = relay.get("txHash") if isinstance(relay, dict) else getattr(relay, "tx_hash", None)
                        self._broadcast("action_executed", f"🏘 Created community '{name}' ({slug}) tx={tx_hash}", {
                            "action": "create_community", "slug": slug, "name": name, "txHash": tx_hash,
                        })
                    except Exception as e:
                        self._broadcast("error", f"✗ Community creation failed: {e}", {
                            "action": "create_community", "slug": slug, "error": str(e),
                        })

        except Exception as exc:
            self._broadcast("error", f"✗ Community gap handling failed: {exc}", {
                "action": "community_gap", "error": str(exc),
            })

    async def _handle_directive(self, data: dict[str, Any]) -> None:
        """Handle a directive signal — execute the directed action."""
        directive_content = data.get("messagePreview", "")
        channel_id = data.get("channelId")
        community = data.get("community", "general")

        try:
            prompt = (
                "You received a directive on Nookplot.\n"
                f"Directive: {directive_content}\n\n"
                "Follow the directive and compose your response.\n"
                "If it asks you to post, write the post content.\n"
                "If it asks you to discuss, write a discussion message.\n"
                "If you can't follow this directive, respond with exactly: [SKIP]\n\n"
                "Your response (under 500 chars):"
            )

            assert self._generate_response is not None
            response = await self._generate_response(prompt)
            content = (response or "").strip()

            if content and content != "[SKIP]":
                if channel_id:
                    await self._runtime.channels.send(channel_id, content)
                    self._broadcast("action_executed", f"💬 Directive response sent to channel {channel_id[:12]}...", {
                        "action": "directive_channel", "channelId": channel_id,
                    })
                else:
                    # Create a post in the relevant community
                    title = content[:100]
                    await self._runtime.memory.publish_knowledge(title=title, body=content, community=community)
                    self._broadcast("action_executed", f"📝 Directive response posted in {community}", {
                        "action": "directive_post", "community": community, "title": title,
                    })

        except Exception as exc:
            self._broadcast("error", f"✗ Directive handling failed: {exc}", {
                "action": "directive", "error": str(exc),
            })

    # ================================================================
    #  Proactive content creation handlers
    # ================================================================

    async def _handle_time_to_post(self, data: dict[str, Any]) -> None:
        """Proactively publish a post in a community."""
        community = data.get("community", "general")
        domains = data.get("agentDomains", [])
        domain_str = ", ".join(domains) if isinstance(domains, list) else str(domains)

        self._broadcast("signal_received", f"📝 Considering a post for #{community}...", {
            "action": "time_to_post", "community": community, "domains": domains,
        })

        try:
            assert self._generate_response is not None
            prompt = (
                "You are an agent on Nookplot, a decentralized network for AI agents.\n"
                f"Write a post for the '{community}' community.\n"
                f"Your areas of expertise: {domain_str}\n\n"
                "Share something useful — an insight, a question, a resource, or start a discussion.\n"
                "Be authentic and concise. If you have nothing worthwhile to share right now, respond with: [SKIP]\n\n"
                "Format:\nTITLE: your post title\nBODY: your post content (under 500 chars)"
            )

            response = await self._generate_response(prompt)
            text = (response or "").strip()

            if not text or text == "[SKIP]":
                self._broadcast("action_skipped", f"⏭ Skipped posting in #{community}", {
                    "action": "time_to_post", "community": community,
                })
                return

            title_match = re.search(r"TITLE:\s*(.+)", text, re.IGNORECASE)
            body_match = re.search(r"BODY:\s*(.+)", text, re.IGNORECASE | re.DOTALL)
            title = (title_match.group(1).strip() if title_match else text[:100])[:200]
            body = (body_match.group(1).strip() if body_match else text)[:2000]

            # On-chain action — request approval
            approved = await self._request_approval("create_post", {
                "community": community, "title": title, "body": body[:200],
            })
            if not approved:
                return

            pub = await self._runtime.memory.publish_knowledge(title=title, body=body, community=community)
            tx_hash = pub.get("txHash") if isinstance(pub, dict) else getattr(pub, "tx_hash", None)
            self._broadcast("action_executed", f"📝 Published post '{title[:50]}...' in #{community}{f' (tx={tx_hash})' if tx_hash else ''}", {
                "action": "create_post", "community": community, "title": title, "txHash": tx_hash,
            })

        except Exception as exc:
            self._broadcast("error", f"✗ Proactive posting failed: {exc}", {
                "action": "time_to_post", "community": community, "error": str(exc),
            })

    async def _handle_time_to_create_project(self, data: dict[str, Any]) -> None:
        """Proactively create a project based on agent's expertise."""
        domains = data.get("agentDomains", [])
        mission = data.get("agentMission", "")
        domain_str = ", ".join(domains) if isinstance(domains, list) else str(domains)

        self._broadcast("signal_received", f"🔧 Considering creating a project...", {
            "action": "time_to_create_project", "domains": domains,
        })

        try:
            assert self._generate_response is not None
            prompt = (
                "You are an agent on Nookplot, a decentralized network for AI agents.\n"
                f"Your areas of expertise: {domain_str}\n"
                f"{'Your mission: ' + mission if mission else ''}\n\n"
                "Propose a project you could build or lead. It should be something useful\n"
                "for other agents or the broader ecosystem.\n"
                "If you have nothing worthwhile to propose, respond with: [SKIP]\n\n"
                "Format:\n"
                "ID: a-slug-id (lowercase, hyphens only)\n"
                "NAME: Your Project Name\n"
                "DESCRIPTION: What this project does and why (under 300 chars)"
            )

            response = await self._generate_response(prompt)
            text = (response or "").strip()

            if not text or text == "[SKIP]":
                self._broadcast("action_skipped", "⏭ Skipped project creation", {
                    "action": "time_to_create_project",
                })
                return

            id_match = re.search(r"ID:\s*(\S+)", text, re.IGNORECASE)
            name_match = re.search(r"NAME:\s*(.+)", text, re.IGNORECASE)
            desc_match = re.search(r"DESCRIPTION:\s*(.+)", text, re.IGNORECASE | re.DOTALL)
            proj_id = (id_match.group(1).strip() if id_match else "").strip()
            proj_name = (name_match.group(1).strip() if name_match else "").strip()
            proj_desc = (desc_match.group(1).strip() if desc_match else "").strip()[:500]

            if not proj_id or not proj_name:
                self._broadcast("action_skipped", "⏭ Could not parse project details from LLM response", {
                    "action": "time_to_create_project", "rawResponse": text[:200],
                })
                return

            # Validate projectId format (must match gateway regex)
            if not re.fullmatch(r'[a-zA-Z0-9-]{1,100}', proj_id):
                self._broadcast("action_skipped", "⏭ Invalid project ID format (must be alphanumeric/hyphens, 1-100 chars)", {
                    "action": "time_to_create_project", "projectId": proj_id,
                })
                return

            # On-chain action — request approval
            approved = await self._request_approval("create_project", {
                "projectId": proj_id, "name": proj_name, "description": proj_desc[:200],
            })
            if not approved:
                return

            # Step 1: Discover similar projects (required by gateway — returns discoveryId)
            discover_resp = await self._runtime._http.request("POST", "/v1/projects/discover", {
                "name": proj_name, "description": proj_desc,
            })
            discovery_id = discover_resp.get("discoveryId") if isinstance(discover_resp, dict) else None
            if not discovery_id:
                self._broadcast("action_failed", "❌ Failed to get discovery ID for project creation", {
                    "action": "time_to_create_project", "projectId": proj_id,
                })
                return

            # Step 2: Prepare with discoveryId
            prep = await self._runtime._http.request("POST", "/v1/prepare/project", {
                "discoveryId": discovery_id,
                "projectId": proj_id, "name": proj_name, "description": proj_desc,
            })
            relay = await self._runtime.memory._sign_and_relay(prep)
            tx_hash = relay.get("txHash") if isinstance(relay, dict) else None
            self._broadcast("action_executed", f"🔧 Created project '{proj_name}' ({proj_id}){f' tx={tx_hash}' if tx_hash else ''}", {
                "action": "create_project", "projectId": proj_id, "name": proj_name, "txHash": tx_hash,
            })

        except Exception as exc:
            self._broadcast("error", f"✗ Proactive project creation failed: {exc}", {
                "action": "time_to_create_project", "error": str(exc),
            })

    # ================================================================
    #  Project collaboration signal handlers
    # ================================================================

    async def _handle_files_committed(self, data: dict[str, Any]) -> None:
        """Handle a collaborator committing code — review the changes."""
        project_id = data.get("projectId", "")
        commit_id = data.get("commitId", "")
        sender = data.get("senderAddress", "")
        preview = data.get("messagePreview", "")

        if not project_id or not commit_id:
            return

        try:
            # Load commit details for context
            detail: Any = None
            try:
                detail = await self._runtime.projects.get_commit(project_id, commit_id)
            except Exception:
                pass

            # Build diff context from commit changes
            # detail can be a Pydantic FileCommitDetail model or a dict
            diff_lines: list[str] = []
            if detail is not None:
                changes = getattr(detail, "changes", None) or (detail.get("changes") if isinstance(detail, dict) else []) or []
                for ch in changes[:10]:
                    path = ch.get("path", "unknown") if isinstance(ch, dict) else getattr(ch, "path", "unknown")
                    action = ch.get("action", "modified") if isinstance(ch, dict) else getattr(ch, "action", "modified")
                    diff_lines.append(f"  {action}: {path}")
                    snippet = (ch.get("diff") or ch.get("content") or "") if isinstance(ch, dict) else (getattr(ch, "diff", None) or getattr(ch, "content", None) or "")
                    if snippet:
                        diff_lines.append(f"    {str(snippet)[:500]}")
            diff_text = "\n".join(diff_lines)[:3000] if diff_lines else "(no diff available)"

            # Extract commit message from detail
            if detail is not None:
                commit_obj = getattr(detail, "commit", None) or (detail.get("commit") if isinstance(detail, dict) else None)
                if commit_obj:
                    message = getattr(commit_obj, "message", None) or (commit_obj.get("message") if isinstance(commit_obj, dict) else None) or preview
                else:
                    message = preview
            else:
                message = preview

            assert self._generate_response is not None
            safe_message = sanitize_for_prompt(str(message))
            safe_diff = sanitize_for_prompt(diff_text, max_length=3000)
            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                "A collaborator committed code to your project on Nookplot.\n"
                f"Committer: {sender[:12]}...\n"
                f"Commit message: {wrap_untrusted(safe_message, 'commit message')}\n\n"
                f"Changes:\n{wrap_untrusted(safe_diff, 'code diff')}\n\n"
                "Review the changes and decide:\n"
                "VERDICT: APPROVE, REQUEST_CHANGES, or COMMENT\n"
                "BODY: your review comments\n\n"
                "Format your response as:\n"
                "VERDICT: <your verdict>\n"
                "BODY: <your review comments>"
            )

            response = await self._generate_response(prompt)
            text = (response or "").strip()

            import re
            verdict_match = re.search(r"VERDICT:\s*(APPROVE|REQUEST_CHANGES|COMMENT)", text, re.IGNORECASE)
            verdict = verdict_match.group(1).lower() if verdict_match else "comment"
            body_match = re.search(r"BODY:\s*(.+)", text, re.IGNORECASE | re.DOTALL)
            body = (body_match.group(1).strip() if body_match else text)[:1000]

            try:
                await self._runtime.projects.submit_review(project_id, commit_id, verdict, body)
                self._broadcast("action_executed", f"📝 Reviewed commit {commit_id[:8]}: {verdict.upper()}", {
                    "action": "review_commit", "projectId": project_id, "commitId": commit_id, "verdict": verdict,
                })
            except Exception as e:
                self._broadcast("error", f"✗ Review submission failed: {e}", {
                    "action": "review_commit", "commitId": commit_id, "error": str(e),
                })

            # Post summary in project discussion channel
            try:
                summary = f"Reviewed {sender[:10]}'s commit ({commit_id[:8]}): {verdict.upper()} — {body[:200]}"
                await self._runtime.channels.send_to_project(project_id, summary)
            except Exception:
                pass

        except Exception as exc:
            self._broadcast("error", f"✗ Files committed handling failed: {exc}", {
                "action": "files_committed", "projectId": project_id, "error": str(exc),
            })

    async def _handle_review_submitted(self, data: dict[str, Any]) -> None:
        """Handle someone reviewing your code — respond in project discussion channel."""
        project_id = data.get("projectId", "")
        commit_id = data.get("commitId", "")
        sender = data.get("senderAddress", "")
        preview = data.get("messagePreview", "")

        if not project_id:
            return

        try:
            assert self._generate_response is not None
            safe_preview = sanitize_for_prompt(preview)
            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                "Your code was reviewed by another agent on Nookplot.\n"
                f"Reviewer: {sender[:12]}...\n"
                f"Review: {wrap_untrusted(safe_preview, 'code review')}\n\n"
                "Write a brief response for the project discussion channel.\n"
                "Thank them for their review and address any feedback.\n"
                "If there's nothing to say, respond with exactly: [SKIP]\n\n"
                "Your response (under 500 chars):"
            )

            response = await self._generate_response(prompt)
            content = (response or "").strip()

            if content and content != "[SKIP]":
                try:
                    await self._runtime.channels.send_to_project(project_id, content)
                    self._broadcast("action_executed", f"💬 Responded to review from {sender[:10]}... in project channel", {
                        "action": "review_response", "projectId": project_id, "reviewer": sender,
                    })
                except Exception:
                    pass

        except Exception as exc:
            self._broadcast("error", f"✗ Review submitted handling failed: {exc}", {
                "action": "review_submitted", "projectId": project_id, "error": str(exc),
            })

    async def _handle_collaborator_added(self, data: dict[str, Any]) -> None:
        """Handle being added as collaborator — post intro in project discussion channel."""
        project_id = data.get("projectId", "")
        sender = data.get("senderAddress", "")
        preview = data.get("messagePreview", "")

        if not project_id:
            return

        try:
            assert self._generate_response is not None
            safe_preview = sanitize_for_prompt(preview)
            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                "You were added as a collaborator to a project on Nookplot.\n"
                f"Added by: {sender[:12]}...\n"
                f"Details: {wrap_untrusted(safe_preview, 'collaboration details')}\n\n"
                "Write a brief introductory message for the project discussion channel.\n"
                "Express enthusiasm and mention how you'd like to contribute.\n\n"
                "Your intro (under 300 chars):"
            )

            response = await self._generate_response(prompt)
            content = (response or "").strip()

            if content and content != "[SKIP]":
                try:
                    await self._runtime.channels.send_to_project(project_id, content)
                    self._broadcast("action_executed", f"💬 Sent intro to project {project_id[:8]}... discussion", {
                        "action": "collab_intro", "projectId": project_id,
                    })
                except Exception:
                    pass

        except Exception as exc:
            self._broadcast("error", f"✗ Collaborator added handling failed: {exc}", {
                "action": "collaborator_added", "projectId": project_id, "error": str(exc),
            })

    # ================================================================
    #  Project Discovery + Collaboration Request Handlers
    # ================================================================

    async def _handle_interesting_project(self, data: dict[str, Any]) -> None:
        """Handle discovery of an interesting project — decide whether to request collaboration."""
        project_id = data.get("projectId", "")
        project_name = data.get("projectName", "")
        project_desc = data.get("projectDescription", "")
        creator = data.get("creatorAddress", "")

        if not project_id:
            return

        self._broadcast("signal_received", f"🔍 Discovered project: {project_name} ({project_id[:12]}...)", {
            "action": "interesting_project", "projectId": project_id, "projectName": project_name,
        })

        try:
            assert self._generate_response is not None
            safe_desc = sanitize_for_prompt(project_desc[:300])

            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                "You discovered a project on Nookplot that may match your expertise.\n"
                f"Project: {project_name} ({project_id})\n"
                f"Description: {wrap_untrusted(safe_desc, 'project description')}\n"
                f"Creator: {creator[:12]}...\n\n"
                "Decide: Do you want to request collaboration access?\n"
                "If yes, write a brief message explaining how you'd contribute.\n"
                "If no, respond with: [SKIP]\n\n"
                "Format:\nDECISION: JOIN or SKIP\n"
                "MESSAGE: your collaboration request message (under 300 chars)"
            )

            response = await self._generate_response(prompt)
            text = (response or "").strip()

            if not text or text == "[SKIP]":
                self._broadcast("action_skipped", f"⏭ Skipped project {project_name}", {
                    "action": "interesting_project", "projectId": project_id,
                })
                return

            should_join = "JOIN" in text.upper() and "SKIP" not in text.upper()

            msg_match = re.search(r"MESSAGE:\s*(.+)", text, re.IGNORECASE | re.DOTALL)
            message = (msg_match.group(1).strip() if msg_match else "").strip()[:300]

            if should_join and message:
                # Ensure message contains a collab-intent keyword for scanCollabRequests detection
                if not any(kw in message.lower() for kw in ("collaborat", "contribut", "join", "help", "work on")):
                    message = f"I'd like to collaborate — {message}"

                await self._runtime.channels.send_to_project(project_id, message)
                self._broadcast("action_executed", f"🤝 Requested to join project '{project_name}'", {
                    "action": "request_collaboration", "projectId": project_id, "message": message[:100],
                })
            elif should_join:
                self._broadcast("action_skipped", f"⏭ JOIN decided but no message — skipping", {
                    "action": "interesting_project", "projectId": project_id,
                })
            else:
                self._broadcast("action_skipped", f"⏭ Decided not to join project {project_name}", {
                    "action": "interesting_project", "projectId": project_id,
                })

        except Exception as exc:
            self._broadcast("error", f"✗ Project discovery handling failed: {exc}", {
                "action": "interesting_project", "projectId": project_id, "error": str(exc),
            })

    async def _handle_collab_request(self, data: dict[str, Any]) -> None:
        """Handle a collaboration request — decide whether to accept and add collaborator."""
        project_id = data.get("projectId", "")
        requester_addr = data.get("requesterAddress", "")
        channel_id = data.get("channelId", "")
        message = data.get("messagePreview", "") or data.get("description", "")
        requester_name = data.get("requesterName", "")

        if not project_id or not requester_addr:
            # Fall back to channel handler if no structured metadata
            if channel_id:
                await self._handle_channel_signal(data)
            return

        self._broadcast("signal_received", f"📩 Collab request for project {project_id[:12]}... from {requester_name or requester_addr[:10]}...", {
            "action": "collab_request", "projectId": project_id, "requester": requester_addr,
        })

        try:
            assert self._generate_response is not None
            safe_msg = sanitize_for_prompt(message[:300])

            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                f"An agent wants to collaborate on your project ({project_id}).\n"
                f"Requester: {requester_name or requester_addr[:12]}...\n"
                f"Their message: {wrap_untrusted(safe_msg, 'collaboration request')}\n\n"
                "Decide: Accept or decline this collaboration request?\n"
                "If you accept, they will be added as an editor (can commit code, submit reviews).\n\n"
                "Format:\nDECISION: ACCEPT or DECLINE\n"
                "MESSAGE: your response message to them"
            )

            response = await self._generate_response(prompt)
            text = (response or "").strip()

            should_accept = "ACCEPT" in text.upper() and "DECLINE" not in text.upper()

            msg_match = re.search(r"MESSAGE:\s*(.+)", text, re.IGNORECASE | re.DOTALL)
            reply = (msg_match.group(1).strip() if msg_match else "").strip()[:300]

            if should_accept:
                # On-chain action — request approval
                approved = await self._request_approval("add_collaborator", {
                    "projectId": project_id,
                    "collaborator": requester_addr,
                    "role": "editor",
                })
                if not approved:
                    return

                try:
                    await self._runtime.projects.add_collaborator(
                        project_id, requester_addr, "editor"
                    )
                    self._broadcast("action_executed", f"✅ Added {requester_name or requester_addr[:10]}... as collaborator to {project_id[:12]}...", {
                        "action": "accept_collaborator", "projectId": project_id, "collaborator": requester_addr,
                    })
                except Exception as add_err:
                    self._broadcast("error", f"✗ Failed to add collaborator: {add_err}", {
                        "action": "add_collaborator", "projectId": project_id, "error": str(add_err),
                    })

                # Post acceptance message in project channel
                if reply:
                    try:
                        await self._runtime.channels.send_to_project(project_id, reply)
                    except Exception:
                        pass
            else:
                # Post decline message in project channel
                if reply:
                    try:
                        await self._runtime.channels.send_to_project(project_id, reply)
                        self._broadcast("action_executed", f"🚫 Declined collab request from {requester_name or requester_addr[:10]}...", {
                            "action": "decline_collaborator", "projectId": project_id,
                        })
                    except Exception:
                        pass
                else:
                    self._broadcast("action_skipped", f"⏭ Declined collab request (no response)", {
                        "action": "collab_request", "projectId": project_id,
                    })

        except Exception as exc:
            self._broadcast("error", f"✗ Collab request handling failed: {exc}", {
                "action": "collab_request", "projectId": project_id, "error": str(exc),
            })

    async def _handle_pending_review(self, data: dict[str, Any]) -> None:
        """Handle a pending review opportunity — review a commit that needs attention.

        Discovered by the proactive opportunity scanner when commits in projects
        the agent collaborates on have no reviews yet.
        """
        project_id = data.get("projectId", "")
        commit_id = data.get("commitId", "")
        title = data.get("title", "")
        preview = data.get("messagePreview", "")

        if not project_id:
            return

        try:
            # Try to get commit details if we have a commit ID
            detail: Any = None
            if commit_id:
                try:
                    detail = await self._runtime.projects.get_commit(project_id, commit_id)
                except Exception:
                    pass

            diff_lines: list[str] = []
            if detail is not None:
                changes = getattr(detail, "changes", None) or (detail.get("changes") if isinstance(detail, dict) else []) or []
                for ch in changes[:10]:
                    path = ch.get("path", "unknown") if isinstance(ch, dict) else getattr(ch, "path", "unknown")
                    action = ch.get("action", "modified") if isinstance(ch, dict) else getattr(ch, "action", "modified")
                    diff_lines.append(f"  {action}: {path}")
                    snippet = (ch.get("diff") or ch.get("content") or "") if isinstance(ch, dict) else (getattr(ch, "diff", None) or getattr(ch, "content", None) or "")
                    if snippet:
                        diff_lines.append(f"    {str(snippet)[:500]}")
            diff_text = "\n".join(diff_lines)[:3000] if diff_lines else "(no diff available)"

            assert self._generate_response is not None
            safe_preview = sanitize_for_prompt(preview)
            safe_diff = sanitize_for_prompt(diff_text, max_length=3000)
            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                "A commit in one of your projects needs a code review.\n"
                f"Context: {sanitize_for_prompt(title)}\n"
                f"Details: {wrap_untrusted(safe_preview, 'commit details')}\n\n"
                f"Changes:\n{wrap_untrusted(safe_diff, 'code diff')}\n\n"
                "Review the changes and decide:\n"
                "VERDICT: APPROVE, REQUEST_CHANGES, or COMMENT\n"
                "BODY: your review comments\n\n"
                "If this doesn't need your review, respond with: [SKIP]\n\n"
                "Format your response as:\n"
                "VERDICT: <your verdict>\n"
                "BODY: <your review comments>"
            )

            response = await self._generate_response(prompt)
            text = (response or "").strip()

            if text == "[SKIP]":
                return

            import re
            verdict_match = re.search(r"VERDICT:\s*(APPROVE|REQUEST_CHANGES|COMMENT)", text, re.IGNORECASE)
            verdict = verdict_match.group(1).lower() if verdict_match else "comment"
            body_match = re.search(r"BODY:\s*(.+)", text, re.IGNORECASE | re.DOTALL)
            body = (body_match.group(1).strip() if body_match else text)[:1000]

            if commit_id:
                try:
                    await self._runtime.projects.submit_review(project_id, commit_id, verdict, body)
                    self._broadcast("action_executed", f"📝 Reviewed pending commit {commit_id[:8]}: {verdict.upper()}", {
                        "action": "pending_review", "projectId": project_id, "commitId": commit_id, "verdict": verdict,
                    })
                except Exception as e:
                    self._broadcast("error", f"✗ Pending review submission failed: {e}", {
                        "action": "pending_review", "commitId": commit_id, "error": str(e),
                    })

        except Exception as exc:
            self._broadcast("error", f"✗ Pending review handling failed: {exc}", {
                "action": "pending_review", "projectId": project_id, "error": str(exc),
            })

    # ================================================================
    #  Project signal handlers (task_created, agent_mentioned, etc.)
    # ================================================================

    async def _handle_task_created(self, data: dict[str, Any]) -> None:
        """Handle a new task created in a project — just log, don't auto-respond (too noisy)."""
        project_id = data.get("projectId", "")
        task_id = data.get("taskId", "")
        title = data.get("title", "")
        if self._verbose:
            logger.info("[autonomous] New task created: %s (%s) in project %s", title, task_id, project_id)

    async def _handle_task_assigned(self, data: dict[str, Any]) -> None:
        """Handle being assigned a task — acknowledge in project channel."""
        project_id = data.get("projectId", "")
        task_id = data.get("taskId", "")
        title = data.get("title", "") or data.get("messagePreview", "")
        if not project_id or not task_id:
            return
        try:
            assert self._generate_response is not None
            safe_title = sanitize_for_prompt(title)
            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                "You were assigned a task in a Nookplot project.\n"
                f"Project: {project_id}\n"
                f"Task: {wrap_untrusted(safe_title, 'task title')} (ID: {task_id})\n\n"
                "Acknowledge the assignment in the project channel.\n"
                "If you can't work on it, say so. Otherwise confirm you'll take it on.\n"
                "Response (under 300 chars):"
            )
            response = await self._generate_response(prompt)
            content = (response or "").strip()
            if content and content != "[SKIP]":
                try:
                    await self._runtime.channels.send_to_project(project_id, content)
                    self._broadcast("action_executed", f"Acknowledged task assignment: {task_id}", {
                        "action": "task_assigned", "projectId": project_id, "taskId": task_id,
                    })
                except Exception:
                    pass
        except Exception as exc:
            self._broadcast("error", f"Task assigned handling failed: {exc}", {
                "action": "task_assigned", "projectId": project_id, "error": str(exc),
            })

    async def _handle_task_completed(self, data: dict[str, Any]) -> None:
        """Handle a task completion in a project — acknowledge in project channel."""
        project_id = data.get("projectId", "")
        task_id = data.get("taskId", "")
        title = data.get("title", "")
        sender = data.get("senderAddress", "")
        if not project_id:
            return
        try:
            assert self._generate_response is not None
            safe_title = sanitize_for_prompt(title)
            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                "A task was completed in a project you collaborate on.\n"
                f"Project: {project_id}\n"
                f"Task: {wrap_untrusted(safe_title, 'task title')} (ID: {task_id})\n"
                f"Completed by: {sender[:12]}...\n\n"
                "Decide how to respond — write a brief acknowledgment for the project channel.\n"
                "If there's nothing meaningful to say, respond with: [SKIP]\n\n"
                "Your response (under 300 chars):"
            )
            response = await self._generate_response(prompt)
            content = (response or "").strip()
            if content and content != "[SKIP]":
                try:
                    await self._runtime.channels.send_to_project(project_id, content)
                    self._broadcast("action_executed", f"Acknowledged task completion: {task_id}", {
                        "action": "task_completed", "projectId": project_id, "taskId": task_id,
                    })
                except Exception:
                    pass
        except Exception as exc:
            self._broadcast("error", f"Task completed handling failed: {exc}", {
                "action": "task_completed", "projectId": project_id, "error": str(exc),
            })

    async def _handle_milestone_reached(self, data: dict[str, Any]) -> None:
        """Handle a milestone completion — celebrate in project channel."""
        project_id = data.get("projectId", "")
        milestone_id = data.get("milestoneId", "")
        title = data.get("title", "")
        if not project_id:
            return
        try:
            assert self._generate_response is not None
            safe_title = sanitize_for_prompt(title)
            prompt = (
                "A project milestone was just completed!\n"
                f"Project: {project_id}\n"
                f"Milestone: {wrap_untrusted(safe_title, 'milestone title')} (ID: {milestone_id})\n\n"
                "Write a brief celebratory or acknowledgment message for the project channel.\n"
                "If you prefer silence, respond with: [SKIP]\n\n"
                "Your message (under 300 chars):"
            )
            response = await self._generate_response(prompt)
            content = (response or "").strip()
            if content and content != "[SKIP]":
                try:
                    await self._runtime.channels.send_to_project(project_id, content)
                    self._broadcast("action_executed", f"Celebrated milestone: {milestone_id}", {
                        "action": "milestone_reached", "projectId": project_id, "milestoneId": milestone_id,
                    })
                except Exception:
                    pass
        except Exception as exc:
            self._broadcast("error", f"Milestone reached handling failed: {exc}", {
                "action": "milestone_reached", "projectId": project_id, "error": str(exc),
            })

    async def _handle_project_status_update(self, data: dict[str, Any]) -> None:
        """Handle a project broadcast — optionally respond in project channel."""
        project_id = data.get("projectId", "")
        sender = data.get("senderAddress", "")
        preview = data.get("messagePreview", "")
        if not project_id or not preview:
            return
        try:
            assert self._generate_response is not None
            safe_preview = sanitize_for_prompt(preview)
            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                "A broadcast was posted in a project you collaborate on.\n"
                f"Project: {project_id}\n"
                f"From: {sender[:12]}...\n"
                f"Message:\n{wrap_untrusted(safe_preview, 'project broadcast')}\n\n"
                "Decide if you should respond in the project channel.\n"
                "If there's nothing meaningful to add, respond with: [SKIP]\n\n"
                "Your response (under 300 chars):"
            )
            response = await self._generate_response(prompt)
            content = (response or "").strip()
            if content and content != "[SKIP]":
                try:
                    await self._runtime.channels.send_to_project(project_id, content)
                    self._broadcast("action_executed", "Responded to project broadcast", {
                        "action": "project_status_update", "projectId": project_id,
                    })
                except Exception:
                    pass
        except Exception as exc:
            self._broadcast("error", f"Project broadcast handling failed: {exc}", {
                "action": "project_status_update", "projectId": project_id, "error": str(exc),
            })

    async def _handle_bounty_access_granted(self, data: dict[str, Any]) -> None:
        """Handle bounty access being granted — thank in project channel."""
        project_id = data.get("projectId", "")
        bounty_id = data.get("bountyId", "")
        if not project_id:
            return
        self._broadcast("action_executed", f"Bounty access granted for {bounty_id} in project {project_id}", {
            "action": "bounty_access_granted", "bountyId": bounty_id, "projectId": project_id,
        })
        try:
            await self._runtime.channels.send_to_project(
                project_id, f"Thanks for granting access to bounty {bounty_id}! I'll start working on it.",
            )
        except Exception:
            pass

    async def _handle_project_bounty_completed(self, data: dict[str, Any]) -> None:
        """Handle bounty completion in project — celebrate in channel."""
        project_id = data.get("projectId", "")
        bounty_id = data.get("bountyId", "")
        if not project_id:
            return
        self._broadcast("action_executed", f"Bounty {bounty_id} completed in project {project_id}", {
            "action": "project_bounty_completed", "bountyId": bounty_id, "projectId": project_id,
        })
        try:
            await self._runtime.channels.send_to_project(
                project_id, f"Bounty {bounty_id} has been approved and completed!",
            )
        except Exception:
            pass

    async def _handle_agent_mentioned(self, data: dict[str, Any]) -> None:
        """Handle being @mentioned in a project broadcast — reply in project channel."""
        project_id = data.get("projectId", "")
        broadcast_id = data.get("broadcastId", "")
        sender = data.get("senderAddress", "")
        preview = data.get("messagePreview", "")
        if not project_id or not preview:
            return

        try:
            assert self._generate_response is not None
            safe_preview = sanitize_for_prompt(preview)
            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                "You were @mentioned in a project broadcast on Nookplot.\n"
                f"Project: {project_id}\n"
                f"From: {sender[:12]}...\n"
                f"Message:\n{wrap_untrusted(safe_preview, 'broadcast mention')}\n\n"
                "Write a reply to the mention in the project channel.\n"
                "If nothing to say, respond with: [SKIP]\n\n"
                "Your reply (under 400 chars):"
            )

            response = await self._generate_response(prompt)
            content = (response or "").strip()
            if content and content != "[SKIP]":
                try:
                    await self._runtime.channels.send_to_project(project_id, content)
                    self._broadcast("action_executed", f"💬 Replied to mention in broadcast {broadcast_id}", {
                        "action": "agent_mentioned", "projectId": project_id, "broadcastId": broadcast_id,
                    })
                except Exception:
                    pass

        except Exception as exc:
            self._broadcast("error", f"✗ Agent mentioned handling failed: {exc}", {
                "action": "agent_mentioned", "projectId": project_id, "error": str(exc),
            })

    async def _handle_review_comment_added(self, data: dict[str, Any]) -> None:
        """Handle a review comment on a commit — respond in project channel."""
        project_id = data.get("projectId", "")
        commit_id = data.get("commitId", "")
        reviewer = data.get("senderAddress", "")
        preview = data.get("messagePreview", "")
        if not preview or not project_id:
            return

        try:
            assert self._generate_response is not None
            safe_preview = sanitize_for_prompt(preview)
            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                "Someone left a review comment on your commit.\n"
                f"Reviewer: {reviewer[:12]}...\n"
                f"Comment:\n{wrap_untrusted(safe_preview, 'review comment')}\n\n"
                "Write a brief response for the project channel.\n"
                "If there's nothing meaningful to say, respond with: [SKIP]\n\n"
                "Your response (under 300 chars):"
            )

            response = await self._generate_response(prompt)
            content = (response or "").strip()
            if content and content != "[SKIP]":
                try:
                    await self._runtime.channels.send_to_project(project_id, content)
                    self._broadcast("action_executed", f"💬 Responded to review comment on {commit_id[:8]}", {
                        "action": "review_comment_response", "projectId": project_id, "commitId": commit_id,
                    })
                except Exception:
                    pass

        except Exception as exc:
            self._broadcast("error", f"✗ Review comment handling failed: {exc}", {
                "action": "review_comment_added", "projectId": project_id, "error": str(exc),
            })

    async def _handle_bounty_posted_to_project(self, data: dict[str, Any]) -> None:
        """Handle a bounty posted to a project — express interest in project channel."""
        project_id = data.get("projectId", "")
        bounty_id = data.get("bountyId", "")
        preview = data.get("messagePreview", "")
        if not project_id:
            return

        if self._verbose:
            logger.info("[autonomous] Bounty posted to project: %s", bounty_id)

        try:
            assert self._generate_response is not None
            safe_preview = sanitize_for_prompt(preview)
            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                "A bounty was linked to a project you collaborate on.\n"
                f"Project: {project_id}\n"
                f"Bounty ID: {bounty_id}\n"
                f"Details:\n{wrap_untrusted(safe_preview, 'bounty details')}\n\n"
                "Should you express interest? Write a brief message for the project channel.\n"
                "If not interested, respond with: [SKIP]\n\n"
                "Your response (under 300 chars):"
            )

            response = await self._generate_response(prompt)
            content = (response or "").strip()
            if content and content != "[SKIP]":
                try:
                    await self._runtime.channels.send_to_project(project_id, content)
                    self._broadcast("action_executed", f"💬 Expressed interest in bounty {bounty_id}", {
                        "action": "bounty_interest", "projectId": project_id, "bountyId": bounty_id,
                    })
                except Exception:
                    pass

        except Exception as exc:
            self._broadcast("error", f"✗ Project bounty posted handling failed: {exc}", {
                "action": "bounty_posted_to_project", "projectId": project_id, "error": str(exc),
            })

    async def _handle_bounty_access_requested(self, data: dict[str, Any]) -> None:
        """Handle a bounty access request — decide whether to grant or deny."""
        project_id = data.get("projectId", "")
        request_id = data.get("requestId", "")
        bounty_id = data.get("bountyId", "")
        requester = data.get("senderAddress", "")
        preview = data.get("messagePreview", "")
        if not project_id or not bounty_id:
            return

        if self._verbose:
            logger.info("[autonomous] Bounty access requested by %s for %s", requester[:10], bounty_id)

        try:
            assert self._generate_response is not None
            safe_preview = sanitize_for_prompt(preview)
            prompt = (
                f"{UNTRUSTED_CONTENT_INSTRUCTION}\n\n"
                "An agent requested access to a bounty in your project.\n"
                f"Project: {project_id}\n"
                f"Bounty: {bounty_id}\n"
                f"Requester: {requester[:12]}...\n"
                f"Message:\n{wrap_untrusted(safe_preview, 'access request')}\n\n"
                "Decide: GRANT or DENY access.\n"
                "If you need more information, ask in the project channel.\n\n"
                "Format:\nDECISION: GRANT or DENY\nMESSAGE: brief response"
            )

            response = await self._generate_response(prompt)
            text = (response or "").strip()

            if "GRANT" in text.upper():
                try:
                    await self._runtime._http.request(
                        "POST",
                        f"/v1/projects/{project_id}/bounties/{bounty_id}/grant-access",
                        {"requesterAddress": requester},
                    )
                    self._broadcast("action_executed", f"🔓 Granted bounty access to {requester[:10]}...", {
                        "action": "grant_bounty_access", "projectId": project_id, "bountyId": bounty_id,
                    })
                except Exception as e:
                    self._broadcast("error", f"✗ Failed to grant bounty access: {e}", {
                        "action": "grant_bounty_access", "error": str(e),
                    })
            else:
                # Denial is supervised — just log it
                if self._verbose:
                    logger.info("[autonomous] Bounty access decision: DENY for %s (logged, not auto-denied)", requester[:10])

        except Exception as exc:
            self._broadcast("error", f"✗ Bounty access request handling failed: {exc}", {
                "action": "bounty_access_requested", "projectId": project_id, "error": str(exc),
            })

    # ================================================================
    #  Action request handling (proactive.action.request)
    # ================================================================

    async def _on_action_event(self, event: Any) -> None:
        if not self._running:
            return
        data = self._extract_data(event)
        try:
            await self._handle_action_request(data)
        except Exception as exc:
            self._broadcast("error", f"✗ Error handling {data.get('actionType', '?')}: {exc}", {
                "action": data.get("actionType"), "error": str(exc),
            })

    async def _handle_action_request(self, data: dict[str, Any]) -> None:
        if self._action_handler:
            await self._action_handler(data)
            return

        action_type: str = data.get("actionType", "unknown")
        action_id: str | None = data.get("actionId")
        suggested_content: str | None = data.get("suggestedContent")
        payload: dict[str, Any] = data.get("payload", {})

        self._broadcast("signal_received", f"⚡ Action request: {action_type}{f' ({action_id})' if action_id else ''}", {
            "action": action_type, "actionId": action_id,
        })

        try:
            tx_hash: str | None = None
            result: dict[str, Any] | None = None

            # ── On-chain actions that need approval ──
            _ON_CHAIN_ACTIONS = {
                "create_post", "post_reply", "publish",
                "vote", "follow_agent", "attest_agent", "create_community",
                "create_project", "propose_clique", "propose_guild",
                "claim_bounty", "claim", "create_bounty", "create_bundle",
                "approve_bounty_claimer", "approve_bounty_work", "dispute_bounty_work",
                "cancel_bounty", "unclaim_bounty",
                "list_service", "create_listing", "update_service", "create_agreement",
                "deliver_work", "settle_agreement", "dispute_agreement", "cancel_agreement",
                "expire_dispute", "expire_delivered", "deploy_preview",
                "join_guild", "approve_guild", "reject_guild", "leave_guild",
                "forge_deploy", "forge_spawn", "forge_update_soul",
                "approve_token", "check_token_balance",
                "claim_reward",
                "endorse_agent", "revoke_endorsement",
                "block_agent", "unblock_agent",
            }
            if action_type in _ON_CHAIN_ACTIONS:
                approved = await self._request_approval(action_type, payload, suggested_content, action_id)
                if not approved:
                    if action_id:
                        await self._runtime.proactive.reject_delegated_action(action_id, "Rejected by operator")
                    return

            if action_type == "post_reply":
                parent_cid = payload.get("parentCid") or payload.get("sourceId")
                community = payload.get("community", "general")
                if not parent_cid or not suggested_content:
                    raise ValueError("post_reply requires parentCid and suggestedContent")
                pub = await self._runtime.memory.publish_comment(parent_cid=parent_cid, body=suggested_content, community=community)
                tx_hash = pub.get("txHash") if isinstance(pub, dict) else getattr(pub, "tx_hash", None)
                result = {"cid": pub.get("cid") if isinstance(pub, dict) else getattr(pub, "cid", None), "txHash": tx_hash}

            elif action_type in ("create_post", "publish"):
                community = payload.get("community", "general")
                title = payload.get("title") or (suggested_content[:100] if suggested_content else "Untitled")
                body = suggested_content or payload.get("body", "")
                pub = await self._runtime.memory.publish_knowledge(title=title, body=body, community=community)
                tx_hash = pub.get("txHash") if isinstance(pub, dict) else getattr(pub, "tx_hash", None)
                result = {"cid": pub.get("cid") if isinstance(pub, dict) else getattr(pub, "cid", None), "txHash": tx_hash}

            elif action_type == "vote":
                cid = payload.get("cid")
                if not cid:
                    raise ValueError("vote requires cid")
                v = await self._runtime.memory.vote(cid=cid, vote_type=payload.get("voteType", "up"))
                tx_hash = v.get("txHash") if isinstance(v, dict) else getattr(v, "tx_hash", None)
                result = {"txHash": tx_hash}

            elif action_type == "follow_agent":
                addr = payload.get("targetAddress") or payload.get("address")
                if not addr:
                    raise ValueError("follow_agent requires targetAddress")
                f = await self._runtime.social.follow(addr)
                tx_hash = f.get("txHash") if isinstance(f, dict) else getattr(f, "tx_hash", None)
                result = {"txHash": tx_hash}

            elif action_type == "attest_agent":
                addr = payload.get("targetAddress") or payload.get("address")
                reason = suggested_content or payload.get("reason", "Valued collaborator")
                if not addr:
                    raise ValueError("attest_agent requires targetAddress")
                a = await self._runtime.social.attest(addr, reason)
                tx_hash = a.get("txHash") if isinstance(a, dict) else getattr(a, "tx_hash", None)
                result = {"txHash": tx_hash}

            elif action_type == "endorse_agent":
                addr = payload.get("address") or payload.get("targetAddress")
                skill = payload.get("skill")
                rating = int(payload.get("rating", 3))
                ctx = suggested_content or payload.get("context", "")
                if not addr:
                    raise ValueError("endorse_agent requires address")
                if not skill:
                    raise ValueError("endorse_agent requires skill")
                prep = await self._runtime._http.request("POST", "/v1/prepare/endorsement", {
                    "address": addr, "skill": skill, "rating": rating, "context": ctx,
                })
                relay = await self._runtime.memory._sign_and_relay(prep)
                tx_hash = relay.get("txHash")
                result = {"txHash": tx_hash}

            elif action_type == "revoke_endorsement":
                addr = payload.get("address") or payload.get("targetAddress")
                skill = payload.get("skill")
                if not addr:
                    raise ValueError("revoke_endorsement requires address")
                if not skill:
                    raise ValueError("revoke_endorsement requires skill")
                prep = await self._runtime._http.request("POST", "/v1/prepare/endorsement/revoke", {
                    "address": addr, "skill": skill,
                })
                relay = await self._runtime.memory._sign_and_relay(prep)
                tx_hash = relay.get("txHash")
                result = {"txHash": tx_hash}

            elif action_type == "block_agent":
                addr = payload.get("address") or payload.get("targetAddress")
                if not addr:
                    raise ValueError("block_agent requires address")
                prep = await self._runtime._http.request("POST", "/v1/prepare/block", {
                    "target": addr,
                })
                relay = await self._runtime.memory._sign_and_relay(prep)
                tx_hash = relay.get("txHash")
                result = {"txHash": tx_hash}

            elif action_type == "unblock_agent":
                addr = payload.get("address") or payload.get("targetAddress")
                if not addr:
                    raise ValueError("unblock_agent requires address")
                prep = await self._runtime._http.request("POST", "/v1/prepare/unblock", {
                    "target": addr,
                })
                relay = await self._runtime.memory._sign_and_relay(prep)
                tx_hash = relay.get("txHash")
                result = {"txHash": tx_hash}

            elif action_type == "create_community":
                slug, name = payload.get("slug"), payload.get("name")
                desc = suggested_content or payload.get("description", "")
                if not slug or not name:
                    raise ValueError("create_community requires slug and name")
                if not desc:
                    raise ValueError("create_community requires a non-empty description")
                prep = await self._runtime._http.request("POST", "/v1/prepare/community", {"slug": slug, "name": name, "description": desc})
                relay = await self._runtime.memory._sign_and_relay(prep)
                tx_hash = relay.get("txHash")
                result = {"txHash": tx_hash, "slug": slug}

            elif action_type == "create_project":
                proj_id = payload.get("projectId")
                proj_name = payload.get("name")
                proj_desc = suggested_content or payload.get("description", "")
                if not proj_id or not proj_name:
                    raise ValueError("create_project requires projectId and name")
                if not re.fullmatch(r'[a-zA-Z0-9-]{1,100}', proj_id):
                    raise ValueError(f"Invalid projectId format: {proj_id}")
                # Discover similar projects first (gateway requires discoveryId)
                discover_resp = await self._runtime._http.request("POST", "/v1/projects/discover", {
                    "name": proj_name, "description": proj_desc,
                })
                discovery_id = discover_resp.get("discoveryId") if isinstance(discover_resp, dict) else None
                if not discovery_id:
                    raise ValueError("Failed to get discovery ID for project creation")
                prep = await self._runtime._http.request("POST", "/v1/prepare/project", {
                    "discoveryId": discovery_id,
                    "projectId": proj_id, "name": proj_name, "description": proj_desc,
                })
                relay = await self._runtime.memory._sign_and_relay(prep)
                tx_hash = relay.get("txHash")
                result = {"txHash": tx_hash, "projectId": proj_id, "name": proj_name}

            elif action_type in ("propose_clique", "propose_guild"):
                name = payload.get("name")
                members = payload.get("members")
                desc = suggested_content or payload.get("description", "")
                if not name or not members or len(members) < 2:
                    raise ValueError("propose_guild requires name and at least 2 members")
                prep = await self._runtime._http.request("POST", "/v1/prepare/guild", {"name": name, "description": desc, "members": members})
                relay = await self._runtime.memory._sign_and_relay(prep)
                tx_hash = relay.get("txHash")
                result = {"txHash": tx_hash, "name": name}

            elif action_type == "review_commit":
                pid = payload.get("projectId")
                cid = payload.get("commitId")
                if not pid or not cid:
                    raise ValueError("review_commit requires projectId and commitId")

                # If verdict+body supplied, use directly; otherwise generate via LLM
                verdict = payload.get("verdict")
                body = payload.get("body") or suggested_content

                if not verdict and self._generate_response:
                    detail: dict[str, Any] = {}
                    try:
                        detail = await self._runtime.projects.get_commit(pid, cid)
                    except Exception:
                        pass

                    diff_lines: list[str] = []
                    changes = detail.get("changes") or detail.get("files") or []
                    for ch in changes[:10]:
                        if isinstance(ch, dict):
                            path = ch.get("path", "unknown")
                            action_name = ch.get("action", "modified")
                            diff_lines.append(f"  {action_name}: {path}")
                            snippet = ch.get("diff") or ch.get("content") or ""
                            if snippet:
                                diff_lines.append(f"    {str(snippet)[:500]}")
                    diff_text = "\n".join(diff_lines)[:3000] if diff_lines else "(no diff available)"
                    commit_msg = detail.get("message") or ""

                    import re as _re
                    prompt = (
                        "Review this code commit.\n"
                        f"Commit message: {commit_msg}\n\n"
                        f"Changes:\n{diff_text}\n\n"
                        "Decide: APPROVE, REQUEST_CHANGES, or COMMENT\n"
                        "Format:\nVERDICT: <verdict>\nBODY: <review comments>"
                    )
                    resp = await self._generate_response(prompt)
                    text = (resp or "").strip()
                    vm = _re.search(r"VERDICT:\s*(APPROVE|REQUEST_CHANGES|COMMENT)", text, _re.IGNORECASE)
                    verdict = vm.group(1).lower() if vm else "comment"
                    bm = _re.search(r"BODY:\s*(.+)", text, _re.IGNORECASE | _re.DOTALL)
                    body = (bm.group(1).strip() if bm else text)[:1000]

                verdict = verdict or "comment"
                body = body or "Reviewed via autonomous agent"
                review_result = await self._runtime.projects.submit_review(pid, cid, verdict, body)
                result = review_result if isinstance(review_result, dict) else {"verdict": verdict}

            elif action_type == "request_ai_review":
                # AI-powered code review — costs 150 credits (1.50 cr)
                pid = payload.get("projectId")
                cid = payload.get("commitId")
                if not pid or not cid:
                    raise ValueError("request_ai_review requires projectId and commitId")
                ai_result = await self._runtime.projects.request_ai_review(pid, cid)
                result = (
                    ai_result
                    if isinstance(ai_result, dict)
                    else {
                        "reviewId": getattr(ai_result, "review_id", None),
                        "verdict": getattr(ai_result, "verdict", None),
                        "findingsCount": getattr(ai_result, "findings_count", 0),
                        "creditsCost": getattr(ai_result, "credits_cost", 0),
                    }
                )

            elif action_type in ("gateway_commit", "commit_files"):
                pid = payload.get("projectId")
                files = payload.get("files")
                msg = suggested_content or payload.get("message", "Autonomous commit")
                if not pid or not files:
                    raise ValueError("gateway_commit requires projectId and files")
                commit_result = await self._runtime.projects.commit_files(pid, files, msg)
                result = commit_result if isinstance(commit_result, dict) else {"committed": True}

            elif action_type == "list_project_files":
                pid = payload.get("projectId")
                if not pid:
                    raise ValueError("list_project_files requires projectId")
                files_list = await self._runtime.projects.list_files(pid)
                result = {"files": [f.__dict__ if hasattr(f, "__dict__") else f for f in files_list]}

            elif action_type == "read_project_file":
                pid = payload.get("projectId")
                fp = payload.get("filePath")
                if not pid or not fp:
                    raise ValueError("read_project_file requires projectId and filePath")
                file_content = await self._runtime.projects.read_file(pid, fp)
                result = file_content.__dict__ if hasattr(file_content, "__dict__") else {"content": str(file_content)}

            elif action_type == "list_commits":
                pid = payload.get("projectId")
                if not pid:
                    raise ValueError("list_commits requires projectId")
                limit = payload.get("limit", 20)
                offset = payload.get("offset", 0)
                commits_list = await self._runtime.projects.list_commits(pid, limit=limit, offset=offset)
                result = {"commits": [c.__dict__ if hasattr(c, "__dict__") else c for c in commits_list]}

            elif action_type == "get_commit_detail":
                pid = payload.get("projectId")
                cid = payload.get("commitId")
                if not pid or not cid:
                    raise ValueError("get_commit_detail requires projectId and commitId")
                commit_detail = await self._runtime.projects.get_commit(pid, cid)
                result = commit_detail.__dict__ if hasattr(commit_detail, "__dict__") else {"commit": str(commit_detail)}

            elif action_type == "apply_bounty":
                bounty_id = payload.get("bountyId")
                if not bounty_id:
                    raise ValueError("apply_bounty requires bountyId")
                apply_msg = suggested_content or payload.get("message", "")
                if not apply_msg or len(apply_msg) < 50:
                    raise ValueError("apply_bounty requires a work submission (minimum 50 characters)")
                apply_result = await self._runtime._http.request(
                    "POST", f"/v1/bounties/{bounty_id}/apply", {"message": apply_msg}
                )
                result = apply_result if isinstance(apply_result, dict) else {"applied": True}

            elif action_type == "submit_bounty_work":
                bounty_id = payload.get("bountyId")
                if not bounty_id:
                    raise ValueError("submit_bounty_work requires bountyId")
                work_content = suggested_content or payload.get("content", "")
                if not work_content:
                    raise ValueError("submit_bounty_work requires content")
                cids = payload.get("deliverableCids", [])
                project_id = payload.get("projectId")
                commit_ids = payload.get("commitIds", [])
                body: dict[str, Any] = {"content": work_content, "deliverableCids": cids}
                if project_id:
                    body["projectId"] = project_id
                if commit_ids:
                    body["commitIds"] = commit_ids
                sub_result = await self._runtime._http.request(
                    "POST", f"/v1/bounties/{bounty_id}/submissions", body
                )
                result = sub_result if isinstance(sub_result, dict) else {"submitted": True}

            elif action_type in ("claim", "claim_bounty"):
                bounty_id = payload.get("bountyId")
                if not bounty_id:
                    raise ValueError("claim_bounty requires bountyId")
                # Only works if agent is the selected winner (application flow gate)
                prep = await self._runtime._http.request(
                    "POST", f"/v1/prepare/bounty/{bounty_id}/claim", {}
                )
                relay = await self._runtime.memory._sign_and_relay(prep)
                tx_hash = relay.get("txHash") if isinstance(relay, dict) else None
                result = relay if isinstance(relay, dict) else {"claimed": True}

            elif action_type == "approve_bounty_claimer":
                bounty_id = payload.get("bountyId")
                claimer = payload.get("claimer")
                if not bounty_id:
                    raise ValueError("approve_bounty_claimer requires bountyId")
                if not claimer:
                    raise ValueError("approve_bounty_claimer requires claimer")
                prep = await self._runtime._http.request(
                    "POST", f"/v1/prepare/bounty/{bounty_id}/approve-claimer", {"claimer": claimer}
                )
                relay = await self._runtime.memory._sign_and_relay(prep)
                tx_hash = relay.get("txHash") if isinstance(relay, dict) else None
                result = relay if isinstance(relay, dict) else {"approved": True}

            elif action_type == "approve_token":
                token_addr = payload.get("tokenAddress")
                spender_addr = payload.get("spenderAddress")
                amount = payload.get("amount")
                if not token_addr:
                    raise ValueError("approve_token requires tokenAddress")
                if not spender_addr:
                    raise ValueError("approve_token requires spenderAddress")
                if not amount:
                    raise ValueError("approve_token requires amount")
                result = await self._runtime._http.request(
                    "POST", "/v1/token/approve",
                    {"tokenAddress": token_addr, "spenderAddress": spender_addr, "amount": amount},
                )

            elif action_type == "check_token_balance":
                result = await self._runtime._http.request("GET", "/v1/token/balance")

            elif action_type == "approve_bounty_application":
                bounty_id = payload.get("bountyId")
                application_id = payload.get("applicationId")
                if not bounty_id or not application_id:
                    raise ValueError("approve_bounty_application requires bountyId and applicationId")
                result_raw = await self._runtime._http.request(
                    "POST", f"/v1/bounties/{bounty_id}/applications/{application_id}/approve", {}
                )
                result = result_raw if isinstance(result_raw, dict) else {"approved": True}

            elif action_type == "reject_bounty_application":
                bounty_id = payload.get("bountyId")
                application_id = payload.get("applicationId")
                if not bounty_id or not application_id:
                    raise ValueError("reject_bounty_application requires bountyId and applicationId")
                result_raw = await self._runtime._http.request(
                    "POST", f"/v1/bounties/{bounty_id}/applications/{application_id}/reject", {}
                )
                result = result_raw if isinstance(result_raw, dict) else {"rejected": True}

            elif action_type == "select_bounty_submission":
                bounty_id = payload.get("bountyId")
                submission_id = payload.get("submissionId")
                if not bounty_id or not submission_id:
                    raise ValueError("select_bounty_submission requires bountyId and submissionId")
                result_raw = await self._runtime._http.request(
                    "POST", f"/v1/bounties/{bounty_id}/submissions/{submission_id}/select", {}
                )
                result = result_raw if isinstance(result_raw, dict) else {"selected": True}
                # Bridge: approve winner on-chain so they can claim
                try:
                    winner_addr = None
                    if isinstance(result_raw, dict):
                        winner = result_raw.get("winner")
                        if isinstance(winner, dict):
                            winner_addr = winner.get("applicantAddress")
                    if winner_addr:
                        prep = await self._runtime._http.request(
                            "POST", f"/v1/prepare/bounty/{bounty_id}/approve-claimer", {"claimer": winner_addr}
                        )
                        relay = await self._runtime.memory._sign_and_relay(prep)
                        tx_hash = relay.get("txHash") if isinstance(relay, dict) else None
                except Exception:
                    pass  # non-fatal — on-chain approval can be retried

            elif action_type == "create_bounty":
                title = suggested_content or payload.get("title")
                desc = payload.get("description", "")
                community = payload.get("community", "general")
                deadline_days = int(payload.get("deadlineDays", 7))
                reward = payload.get("tokenRewardAmount")
                if not title:
                    raise ValueError("create_bounty requires title")
                if not reward:
                    raise ValueError("create_bounty requires tokenRewardAmount")
                deadline_ts = int(time.time()) + deadline_days * 86400
                bounty_body: dict[str, Any] = {
                    "title": title, "description": desc, "community": community,
                    "deadline": deadline_ts, "tokenRewardAmount": str(reward),
                    "tokenAddress": payload.get("tokenAddress", "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913"),
                }
                if payload.get("projectId"):
                    bounty_body["projectId"] = payload["projectId"]
                if payload.get("taskId"):
                    bounty_body["taskId"] = payload["taskId"]
                prep = await self._runtime._http.request("POST", "/v1/prepare/bounty", bounty_body)
                relay = await self._runtime.memory._sign_and_relay(prep)
                tx_hash = relay.get("txHash") if isinstance(relay, dict) else None
                result = relay if isinstance(relay, dict) else {"created": True}

            elif action_type == "add_collaborator":
                pid = payload.get("projectId")
                collab_addr = payload.get("collaboratorAddress") or payload.get("address")
                role = payload.get("role", "editor")
                if not pid or not collab_addr:
                    raise ValueError("add_collaborator requires projectId and collaboratorAddress")
                add_result = await self._runtime.projects.add_collaborator(pid, collab_addr, role)
                result = add_result if isinstance(add_result, dict) else {"added": True}

            elif action_type in ("link_project_to_guild", "link_project_to_clique"):
                proj_id = payload.get("projectId")
                g_id = payload.get("guildId") or payload.get("cliqueId")
                if not proj_id or g_id is None:
                    raise ValueError("link_project_to_guild requires projectId and guildId")
                g_id = int(g_id)
                # 1. Link project to guild
                await self._runtime.guilds.link_project(g_id, proj_id)
                # 2. Set guild attribution
                await self._runtime.projects.set_guild_attribution(proj_id, str(g_id))
                # 3. Get guild members and add accepted ones as editors
                guild_data = await self._runtime.guilds.get(g_id)
                guild_members = guild_data.members if hasattr(guild_data, "members") else []
                my_addr = (self._runtime._address or "").lower()
                added_count = 0
                for m in guild_members:
                    addr = m.get("address", "") if isinstance(m, dict) else getattr(m, "address", "")
                    status = m.get("status", 0) if isinstance(m, dict) else getattr(m, "status", 0)
                    if status == 2 and addr.lower() != my_addr:
                        try:
                            await self._runtime.projects.add_collaborator(proj_id, addr, "editor")
                            added_count += 1
                        except Exception as add_err:
                            logger.warning("Failed to add guild member %s as collaborator: %s", addr, add_err)
                result = {"linked": True, "projectId": proj_id, "guildId": g_id, "collaboratorsAdded": added_count}

            elif action_type == "propose_collab":
                addr = payload.get("targetAddress") or payload.get("address")
                message = suggested_content or payload.get("message", "I'd love to collaborate on your project!")
                if not addr:
                    raise ValueError("propose_collab requires targetAddress")
                await self._runtime.inbox.send(to=addr, content=message)
                result = {"sent": True, "to": addr}

            elif action_type == "deploy_preview":
                proj_id = payload.get("projectId")
                if not proj_id:
                    raise ValueError("deploy_preview requires projectId")
                prepaid_hours = payload.get("prepaidHours", 2)
                prep = await self._runtime._http.request(
                    "POST", f"/v1/prepare/project/{proj_id}/deployment",
                    {"prepaidHours": prepaid_hours},
                )
                relay = await self._runtime.memory._sign_and_relay(prep)
                tx_hash = relay.get("txHash") if isinstance(relay, dict) else None
                result = {"txHash": tx_hash, "projectId": proj_id}

            elif action_type == "fork_project":
                proj_id = payload.get("projectId")
                if not proj_id:
                    raise ValueError("fork_project requires projectId")
                result = await self._runtime.projects.fork_project(
                    proj_id, name=payload.get("name"),
                )

            elif action_type == "create_merge_request":
                src_id = payload.get("sourceProjectId")
                tgt_id = payload.get("targetProjectId")
                mr_title = payload.get("title")
                commit_ids = payload.get("commitIds", [])
                if not src_id or not tgt_id or not mr_title or not commit_ids:
                    raise ValueError(
                        "create_merge_request requires sourceProjectId, targetProjectId, title, commitIds"
                    )
                result = await self._runtime.projects.create_merge_request(
                    src_id, tgt_id, mr_title, commit_ids,
                    description=payload.get("description"),
                )

            elif action_type == "list_merge_requests":
                proj_id = payload.get("projectId")
                if not proj_id:
                    raise ValueError("list_merge_requests requires projectId")
                result = await self._runtime.projects.list_merge_requests(
                    proj_id, status=payload.get("status"),
                )

            elif action_type == "get_merge_request":
                proj_id = payload.get("projectId")
                mr_id = payload.get("mrId")
                if not proj_id or not mr_id:
                    raise ValueError("get_merge_request requires projectId and mrId")
                result = await self._runtime.projects.get_merge_request(proj_id, mr_id)

            elif action_type == "merge_merge_request":
                proj_id = payload.get("projectId")
                mr_id = payload.get("mrId")
                if not proj_id or not mr_id:
                    raise ValueError("merge_merge_request requires projectId and mrId")
                result = await self._runtime.projects.merge_merge_request(
                    proj_id, mr_id, comment=payload.get("comment"),
                )

            elif action_type == "close_merge_request":
                proj_id = payload.get("projectId")
                mr_id = payload.get("mrId")
                if not proj_id or not mr_id:
                    raise ValueError("close_merge_request requires projectId and mrId")
                result = await self._runtime.projects.close_merge_request(
                    proj_id, mr_id, comment=payload.get("comment"),
                )

            elif action_type == "claim_reward":
                pool = payload.get("pool", "nook")
                prep = await self._runtime._http.request(
                    "POST", "/v1/prepare/reward/claim",
                    {"pool": pool},
                )
                relay = await self._runtime.memory._sign_and_relay(prep)
                tx_hash = relay.get("txHash") if isinstance(relay, dict) else None
                result = {"txHash": tx_hash, "pool": pool}

            elif action_type == "create_task":
                proj_id = payload.get("projectId")
                title = suggested_content or payload.get("title")
                if not proj_id or not title:
                    raise ValueError("create_task requires projectId and title")
                task_result = await self._runtime.projects.create_task(
                    proj_id, title,
                    description=payload.get("description"),
                    milestone_id=payload.get("milestoneId"),
                    priority=payload.get("priority", "medium"),
                    labels=payload.get("labels"),
                    due_date=payload.get("dueDate"),
                )
                result = task_result if isinstance(task_result, dict) else {"created": True}

            elif action_type == "assign_task":
                proj_id = payload.get("projectId")
                task_id = payload.get("taskId")
                assignee_addr = payload.get("assigneeAddress") or payload.get("assignee")
                if not proj_id or not task_id or not assignee_addr:
                    raise ValueError("assign_task requires projectId, taskId, and assigneeAddress")
                assign_result = await self._runtime.projects.assign_task(proj_id, task_id, assignee_addr)
                result = assign_result if isinstance(assign_result, dict) else {"assigned": True}

            elif action_type == "create_bundle":
                name = payload.get("name")
                cids = payload.get("cids")
                if not name or not cids or not isinstance(cids, list) or len(cids) == 0:
                    raise ValueError("create_bundle requires name and non-empty cids array")
                body: dict[str, Any] = {"name": name, "cids": cids}
                if payload.get("description"):
                    body["description"] = payload["description"]
                if payload.get("bundleType"):
                    body["bundleType"] = payload["bundleType"]
                if payload.get("tags"):
                    body["tags"] = payload["tags"]
                if payload.get("domain"):
                    body["domain"] = payload["domain"]
                if payload.get("summary"):
                    body["summary"] = payload["summary"]
                if payload.get("contributors"):
                    body["contributors"] = payload["contributors"]
                prep = await self._runtime._http.request("POST", "/v1/prepare/bundle", body)
                relay = await self._runtime.memory._sign_and_relay(prep)
                tx_hash = relay.get("txHash") if isinstance(relay, dict) else None
                result = {"txHash": tx_hash, "name": name, "cidCount": len(cids)}

            elif action_type in ("complete_task", "update_task"):
                proj_id = payload.get("projectId")
                tid = payload.get("taskId")
                if not proj_id or not tid:
                    raise ValueError(f"{action_type} requires projectId and taskId")
                kw: dict[str, Any] = {}
                if action_type == "complete_task":
                    kw["status"] = "completed"
                else:
                    if payload.get("status"):
                        kw["status"] = payload["status"]
                    if payload.get("title"):
                        kw["title"] = payload["title"]
                    if payload.get("description"):
                        kw["description"] = payload["description"]
                    if payload.get("priority"):
                        kw["priority"] = payload["priority"]
                    if payload.get("milestoneId") is not None:
                        kw["milestone_id"] = payload["milestoneId"]
                    if payload.get("labels"):
                        kw["labels"] = payload["labels"]
                    if payload.get("dueDate"):
                        kw["due_date"] = payload["dueDate"]
                task_result = await self._runtime.projects.update_task(proj_id, tid, **kw)
                result = task_result if isinstance(task_result, dict) else {"updated": True}

            elif action_type in ("find_matching_agents", "find_agents"):
                skills = payload.get("skills", [])
                if not skills:
                    raise ValueError("find_matching_agents requires skills array")
                match_result = await self._runtime.matching.find_agents(
                    skills,
                    count=payload.get("count"),
                    available_only=payload.get("availableOnly"),
                )
                result = match_result if isinstance(match_result, dict) else {"matches": []}

            elif action_type == "assemble_team":
                description = suggested_content or payload.get("description", "")
                if not description:
                    raise ValueError("assemble_team requires description")
                team_result = await self._runtime.matching.assemble_team(
                    description,
                    required_skills=payload.get("requiredSkills"),
                    team_size=payload.get("teamSize"),
                    filters=payload.get("filters"),
                )
                result = team_result if isinstance(team_result, dict) else {"assembled": True}

            # ── Marketplace actions ──
            elif action_type == "list_service":
                title = suggested_content or payload.get("title")
                desc = payload.get("description", "")
                category = payload.get("category", "general")
                if not title:
                    raise ValueError("list_service requires title")
                body: dict[str, Any] = {
                    "title": title, "description": desc, "category": category,
                    "pricingModel": payload.get("pricingModel", 0),
                    "priceAmount": payload.get("priceAmount", "0"),
                    "tags": payload.get("tags", []),
                }
                if payload.get("tokenAddress"):
                    body["tokenAddress"] = payload["tokenAddress"]
                prep = await self._runtime._http.request("POST", "/v1/prepare/service/list", body)
                relay = await self._runtime.memory._sign_and_relay(prep)
                tx_hash = relay.get("txHash") if isinstance(relay, dict) else None
                result = {"txHash": tx_hash, "title": title, "category": category}

            elif action_type == "create_agreement":
                listing_id = payload.get("listingId")
                terms = suggested_content or payload.get("terms")
                deadline = payload.get("deadline", int(time.time()) + 7 * 86400)
                if listing_id is None or not terms:
                    raise ValueError("create_agreement requires listingId and terms")
                agree_body: dict[str, Any] = {
                    "listingId": int(listing_id), "terms": terms,
                    "deadline": int(deadline),
                    "tokenAmount": payload.get("tokenAmount", "0"),
                }
                if payload.get("tokenAddress"):
                    agree_body["tokenAddress"] = payload["tokenAddress"]
                prep = await self._runtime._http.request("POST", "/v1/prepare/service/agree", agree_body)
                relay = await self._runtime.memory._sign_and_relay(prep)
                tx_hash = relay.get("txHash") if isinstance(relay, dict) else None
                result = {"txHash": tx_hash, "listingId": listing_id}

            elif action_type == "deliver_work":
                ag_id = payload.get("agreementId")
                delivery_cid = suggested_content or payload.get("deliveryCid")
                if ag_id is None or not delivery_cid:
                    raise ValueError("deliver_work requires agreementId and deliveryCid")
                prep = await self._runtime._http.request("POST", "/v1/prepare/service/deliver", {
                    "agreementId": int(ag_id), "deliveryCid": delivery_cid,
                })
                relay = await self._runtime.memory._sign_and_relay(prep)
                tx_hash = relay.get("txHash") if isinstance(relay, dict) else None
                result = {"txHash": tx_hash, "agreementId": ag_id}

            elif action_type == "settle_agreement":
                ag_id = payload.get("agreementId")
                if ag_id is None:
                    raise ValueError("settle_agreement requires agreementId")
                prep = await self._runtime._http.request("POST", "/v1/prepare/service/settle", {
                    "agreementId": int(ag_id),
                })
                relay = await self._runtime.memory._sign_and_relay(prep)
                tx_hash = relay.get("txHash") if isinstance(relay, dict) else None
                result = {"txHash": tx_hash, "agreementId": ag_id}

            elif action_type == "dispute_agreement":
                ag_id = payload.get("agreementId")
                if ag_id is None:
                    raise ValueError("dispute_agreement requires agreementId")
                prep = await self._runtime._http.request("POST", "/v1/prepare/service/dispute", {
                    "agreementId": int(ag_id),
                })
                relay = await self._runtime.memory._sign_and_relay(prep)
                tx_hash = relay.get("txHash") if isinstance(relay, dict) else None
                result = {"txHash": tx_hash, "agreementId": ag_id}

            elif action_type == "cancel_agreement":
                ag_id = payload.get("agreementId")
                if ag_id is None:
                    raise ValueError("cancel_agreement requires agreementId")
                prep = await self._runtime._http.request("POST", "/v1/prepare/service/cancel", {
                    "agreementId": int(ag_id),
                })
                relay = await self._runtime.memory._sign_and_relay(prep)
                tx_hash = relay.get("txHash") if isinstance(relay, dict) else None
                result = {"txHash": tx_hash, "agreementId": ag_id}

            elif action_type == "expire_dispute":
                ag_id = payload.get("agreementId")
                if ag_id is None:
                    raise ValueError("expire_dispute requires agreementId")
                prep = await self._runtime._http.request("POST", "/v1/prepare/service/expire-dispute", {
                    "agreementId": int(ag_id),
                })
                relay = await self._runtime.memory._sign_and_relay(prep)
                tx_hash = relay.get("txHash") if isinstance(relay, dict) else None
                result = {"txHash": tx_hash, "agreementId": ag_id}

            elif action_type == "expire_delivered":
                ag_id = payload.get("agreementId")
                if ag_id is None:
                    raise ValueError("expire_delivered requires agreementId")
                prep = await self._runtime._http.request("POST", "/v1/prepare/service/expire-delivered", {
                    "agreementId": int(ag_id),
                })
                relay = await self._runtime.memory._sign_and_relay(prep)
                tx_hash = relay.get("txHash") if isinstance(relay, dict) else None
                result = {"txHash": tx_hash, "agreementId": ag_id}

            elif action_type == "submit_review":
                ag_id = payload.get("agreementId")
                rating = payload.get("rating")
                comment = suggested_content or payload.get("comment", "")
                if ag_id is None or rating is None:
                    raise ValueError("submit_review requires agreementId and rating")
                review_result = await self._runtime._http.request("POST", "/v1/marketplace/reviews", {
                    "agreementId": int(ag_id), "rating": int(rating), "comment": comment,
                })
                result = review_result if isinstance(review_result, dict) else {"submitted": True}

            elif action_type == "send_agreement_message":
                ag_id = payload.get("agreementId")
                msg_type = payload.get("messageType", "general")
                content = suggested_content or payload.get("content")
                if ag_id is None or not content:
                    raise ValueError("send_agreement_message requires agreementId and content")
                msg_body: dict[str, Any] = {"messageType": msg_type, "content": content}
                if payload.get("attachmentCid"):
                    msg_body["attachmentCid"] = payload["attachmentCid"]
                msg_result = await self._runtime._http.request(
                    "POST", f"/v1/marketplace/agreements/{int(ag_id)}/messages", msg_body,
                )
                result = msg_result if isinstance(msg_result, dict) else {"sent": True}

            elif action_type == "workspace_create":
                ws_name = payload.get("name") or suggested_content
                if not ws_name:
                    raise ValueError("workspace_create requires name")
                ws = await self._runtime.workspaces.create(
                    name=ws_name,
                    description=payload.get("description"),
                    source_type=payload.get("sourceType"),
                    source_id=payload.get("sourceId"),
                )
                result = ws if isinstance(ws, dict) else {"created": True}

            elif action_type == "workspace_set":
                ws_id = payload.get("workspaceId")
                ws_key = payload.get("key")
                ws_val = payload.get("value", suggested_content)
                if not ws_id or not ws_key:
                    raise ValueError("workspace_set requires workspaceId and key")
                ws_result = await self._runtime.workspaces.set_state(ws_id, ws_key, ws_val)
                result = ws_result if isinstance(ws_result, dict) else {"set": True}

            elif action_type == "workspace_snapshot":
                ws_id = payload.get("workspaceId")
                if not ws_id:
                    raise ValueError("workspace_snapshot requires workspaceId")
                snap = await self._runtime.workspaces.create_snapshot(ws_id, label=payload.get("label"))
                result = snap if isinstance(snap, dict) else {"created": True}

            elif action_type == "propose_action":
                ws_id = payload.get("workspaceId")
                title = payload.get("title") or suggested_content
                if not ws_id or not title:
                    raise ValueError("propose_action requires workspaceId and title")
                prop = await self._runtime.workspaces.create_proposal(
                    ws_id,
                    title=title,
                    action_type=payload.get("actionType", "custom"),
                    description=payload.get("description"),
                    action_payload=payload.get("actionPayload"),
                    quorum_type=payload.get("quorumType"),
                    quorum_threshold=payload.get("quorumThreshold"),
                )
                result = prop if isinstance(prop, dict) else {"created": True}

            elif action_type == "vote_proposal":
                ws_id = payload.get("workspaceId")
                proposal_id = payload.get("proposalId")
                vote = payload.get("vote")
                if not ws_id or not proposal_id or vote is None:
                    raise ValueError("vote_proposal requires workspaceId, proposalId, vote")
                vote_result = await self._runtime.workspaces.vote(
                    ws_id, proposal_id, vote, reason=payload.get("reason"),
                )
                result = vote_result if isinstance(vote_result, dict) else {"voted": True}

            elif action_type == "cancel_proposal":
                ws_id = payload.get("workspaceId")
                proposal_id = payload.get("proposalId")
                if not ws_id or not proposal_id:
                    raise ValueError("cancel_proposal requires workspaceId and proposalId")
                cancel_result = await self._runtime.workspaces.cancel_proposal(ws_id, proposal_id)
                result = cancel_result if isinstance(cancel_result, dict) else {"cancelled": True}

            elif action_type == "send_dm":
                target = payload.get("recipientAddress")
                content = suggested_content or payload.get("content", "")
                if not target or not content:
                    raise ValueError("send_dm requires recipientAddress and content")
                await self._runtime.inbox.send(target, content)
                result = {"sent": True}

            elif action_type == "create_listing":
                # Alias for list_service
                prep = await self._runtime._http.request("POST", "/v1/prepare/service/list", payload)
                relay = await self._runtime.memory._sign_and_relay(prep)
                tx_hash = relay.get("txHash", "")
                result = relay

            elif action_type in ("join_guild", "approve_guild"):
                gid = payload.get("guildId")
                if not gid:
                    raise ValueError("approve_guild requires guildId")
                prep = await self._runtime._http.request("POST", f"/v1/prepare/guild/{gid}/approve", {})
                relay = await self._runtime.memory._sign_and_relay(prep)
                tx_hash = relay.get("txHash", "")
                result = relay

            elif action_type == "reject_guild":
                gid = payload.get("guildId")
                if not gid:
                    raise ValueError("reject_guild requires guildId")
                prep = await self._runtime._http.request("POST", f"/v1/prepare/guild/{gid}/reject", {})
                relay = await self._runtime.memory._sign_and_relay(prep)
                tx_hash = relay.get("txHash", "")
                result = relay

            elif action_type == "leave_guild":
                gid = payload.get("guildId")
                if not gid:
                    raise ValueError("leave_guild requires guildId")
                prep = await self._runtime._http.request("POST", f"/v1/prepare/guild/{gid}/leave", {})
                relay = await self._runtime.memory._sign_and_relay(prep)
                tx_hash = relay.get("txHash", "")
                result = relay

            # ── Bounty access grant/deny ───────────────────────
            elif action_type == "grant":
                proj_id = payload.get("projectId")
                bounty_id = payload.get("bountyId")
                req_id = payload.get("requestId")
                if not proj_id or not bounty_id or not req_id:
                    raise ValueError("grant requires projectId, bountyId, requestId")
                result = await self._runtime._http.request(
                    "POST", f"/v1/projects/{proj_id}/bounties/{bounty_id}/grant-access",
                    {"requestId": req_id},
                )

            elif action_type == "deny":
                proj_id = payload.get("projectId")
                bounty_id = payload.get("bountyId")
                req_id = payload.get("requestId")
                if not proj_id or not bounty_id or not req_id:
                    raise ValueError("deny requires projectId, bountyId, requestId")
                result = await self._runtime._http.request(
                    "POST", f"/v1/projects/{proj_id}/bounties/{bounty_id}/deny-access",
                    {"requestId": req_id},
                )

            # ── Team invitations ──────────────────────────────
            elif action_type == "accept_invitation":
                inv_id = payload.get("invitationId")
                if not inv_id:
                    raise ValueError("accept_invitation requires invitationId")
                result = await self._runtime._http.request(
                    "POST", f"/v1/teams/invitations/{inv_id}/accept", {},
                )

            elif action_type == "decline_invitation":
                inv_id = payload.get("invitationId")
                if not inv_id:
                    raise ValueError("decline_invitation requires invitationId")
                result = await self._runtime._http.request(
                    "POST", f"/v1/teams/invitations/{inv_id}/decline", {},
                )

            # ── Service update ────────────────────────────────
            elif action_type == "update_service":
                listing_id = payload.get("listingId")
                if not listing_id:
                    raise ValueError("update_service requires listingId")
                prep = await self._runtime._http.request(
                    "POST", "/v1/prepare/service/update", payload,
                )
                relay = await self._runtime.memory._sign_and_relay(prep)
                tx_hash = relay.get("txHash", "")
                result = relay

            # ── Additional bounty lifecycle ───────────────────
            elif action_type == "approve_bounty_work":
                bounty_id = payload.get("bountyId")
                if not bounty_id:
                    raise ValueError("approve_bounty_work requires bountyId")
                prep = await self._runtime._http.request(
                    "POST", f"/v1/prepare/bounty/{bounty_id}/approve", {},
                )
                relay = await self._runtime.memory._sign_and_relay(prep)
                tx_hash = relay.get("txHash", "")
                result = relay

            elif action_type == "dispute_bounty_work":
                bounty_id = payload.get("bountyId")
                if not bounty_id:
                    raise ValueError("dispute_bounty_work requires bountyId")
                prep = await self._runtime._http.request(
                    "POST", f"/v1/prepare/bounty/{bounty_id}/dispute", {},
                )
                relay = await self._runtime.memory._sign_and_relay(prep)
                tx_hash = relay.get("txHash", "")
                result = relay

            elif action_type == "cancel_bounty":
                bounty_id = payload.get("bountyId")
                if not bounty_id:
                    raise ValueError("cancel_bounty requires bountyId")
                prep = await self._runtime._http.request(
                    "POST", f"/v1/prepare/bounty/{bounty_id}/cancel", {},
                )
                relay = await self._runtime.memory._sign_and_relay(prep)
                tx_hash = relay.get("txHash", "")
                result = relay

            elif action_type == "unclaim_bounty":
                bounty_id = payload.get("bountyId")
                if not bounty_id:
                    raise ValueError("unclaim_bounty requires bountyId")
                prep = await self._runtime._http.request(
                    "POST", f"/v1/prepare/bounty/{bounty_id}/unclaim", {},
                )
                relay = await self._runtime.memory._sign_and_relay(prep)
                tx_hash = relay.get("txHash", "")
                result = relay

            # ── Real World Actions ──────────────────────────────
            elif action_type in ("egress_request", "http_request"):
                # Outbound HTTP request via the egress proxy (0.15 credits)
                target_url = payload.get("url", "")
                http_method = (payload.get("method", "GET")).upper()
                if not target_url:
                    raise ValueError("egress_request requires url")
                http_result = await self._runtime.tools.http_request(
                    url=target_url,
                    method=http_method,
                    headers=payload.get("headers"),
                    body=payload.get("body"),
                    timeout=payload.get("timeout"),
                    credential_service=payload.get("credentialService"),
                )
                result = http_result if isinstance(http_result, dict) else {"response": http_result}

            elif action_type == "execute_tool":
                # Execute a registered tool through the action registry
                tool_name = payload.get("toolName") or payload.get("name", "")
                tool_args = payload.get("args") or payload.get("input", {})
                if not tool_name:
                    raise ValueError("execute_tool requires toolName")
                tool_result = await self._runtime.tools.execute_tool(tool_name, tool_args)
                result = tool_result if isinstance(tool_result, dict) else {"output": tool_result}

            elif action_type == "exec_code":
                cmd = payload.get("command") or suggested_content
                img = payload.get("image", "node:20-slim")
                files = payload.get("files")
                timeout = payload.get("timeout")
                proj_id = payload.get("projectId")
                if not cmd:
                    raise ValueError("exec_code requires command")
                exec_result = await self._runtime.tools.exec_code(cmd, img, files=files, timeout=timeout, project_id=proj_id)
                result = exec_result if isinstance(exec_result, dict) else {"executed": True}

            elif action_type == "connect_mcp_server":
                # Connect to an external MCP server
                server_url = payload.get("serverUrl", "")
                server_name = payload.get("serverName") or payload.get("name", "")
                if not server_url or not server_name:
                    raise ValueError("connect_mcp_server requires serverUrl and serverName")
                mcp_result = await self._runtime.tools.connect_mcp_server(server_url, server_name)
                result = mcp_result if isinstance(mcp_result, dict) else {"connected": True}

            elif action_type == "disconnect_mcp_server":
                server_id = payload.get("serverId", "")
                if not server_id:
                    raise ValueError("disconnect_mcp_server requires serverId")
                await self._runtime.tools.disconnect_mcp_server(server_id)
                result = {"disconnected": True, "serverId": server_id}

            elif action_type in ("call_mcp_tool", "use_mcp_tool"):
                # Call a tool from a connected MCP server — goes through action registry
                mcp_tool_name = payload.get("toolName") or payload.get("name", "")
                mcp_tool_args = payload.get("args") or payload.get("input", {})
                if not mcp_tool_name:
                    raise ValueError("call_mcp_tool requires toolName")
                mcp_tool_result = await self._runtime.tools.execute_tool(mcp_tool_name, mcp_tool_args)
                result = mcp_tool_result if isinstance(mcp_tool_result, dict) else {"output": mcp_tool_result}

            elif action_type == "register_webhook":
                # Register a webhook source for inbound events
                source = payload.get("source") or payload.get("name", "")
                if not source:
                    raise ValueError("register_webhook requires source")
                config: dict[str, Any] = {}
                if payload.get("secret"):
                    config["secret"] = payload["secret"]
                if payload.get("signatureHeader"):
                    config["signatureHeader"] = payload["signatureHeader"]
                if payload.get("eventMapping"):
                    config["eventMapping"] = payload["eventMapping"]
                reg_result = await self._runtime.tools.register_webhook(source, config or None)
                result = reg_result if isinstance(reg_result, dict) else {"registered": True}

            # ── Insight actions ──
            elif action_type == "publish_insight":
                pub_result = await self._runtime.insights.publish(
                    title=payload.get("title", ""),
                    body=payload.get("body", ""),
                    strategy_type=payload.get("strategyType", "general"),
                    tags=payload.get("tags", []),
                    context=payload.get("context"),
                    outcome_score=payload.get("outcomeScore"),
                    workspace_id=payload.get("workspaceId"),
                )
                result = pub_result if isinstance(pub_result, dict) else {"published": True}

            elif action_type == "cite_insight":
                insight_id = payload.get("insightId")
                if not insight_id:
                    raise ValueError("cite_insight requires insightId")
                cite_result = await self._runtime.insights.cite(
                    insight_id,
                    context=payload.get("context"),
                    outcome_score=payload.get("outcomeScore"),
                )
                result = cite_result if isinstance(cite_result, dict) else {"cited": True}

            elif action_type == "apply_insight":
                insight_id = payload.get("insightId")
                if not insight_id:
                    raise ValueError("apply_insight requires insightId")
                apply_result = await self._runtime.insights.apply(
                    insight_id,
                    context=payload.get("context"),
                    outcome_score=payload.get("outcomeScore"),
                    success=payload.get("success", True),
                )
                result = apply_result if isinstance(apply_result, dict) else {"applied": True}

            # ── Treasury actions ──
            elif action_type == "deposit_treasury":
                guild_id = payload.get("guildId")
                amount = payload.get("amount")
                if not guild_id or not amount:
                    raise ValueError("deposit_treasury requires guildId and amount")
                dep_result = await self._runtime.guilds.deposit_treasury(guild_id, amount, memo=payload.get("memo"))
                result = dep_result if isinstance(dep_result, dict) else {"deposited": True}

            elif action_type == "withdraw_treasury":
                guild_id = payload.get("guildId")
                amount = payload.get("amount")
                if not guild_id or not amount:
                    raise ValueError("withdraw_treasury requires guildId and amount")
                wd_result = await self._runtime.guilds.withdraw_treasury(guild_id, amount, memo=payload.get("memo"))
                result = wd_result if isinstance(wd_result, dict) else {"withdrawn": True}

            elif action_type == "fund_bounty_from_treasury":
                guild_id = payload.get("guildId")
                bounty_id = payload.get("bountyId")
                amount = payload.get("amount")
                if not guild_id or not bounty_id or not amount:
                    raise ValueError("fund_bounty_from_treasury requires guildId, bountyId, amount")
                fund_result = await self._runtime.guilds.fund_bounty_from_treasury(
                    guild_id, bounty_id, amount, proposal_id=payload.get("proposalId"),
                )
                result = fund_result if isinstance(fund_result, dict) else {"funded": True}

            elif action_type == "distribute_revenue":
                guild_id = payload.get("guildId")
                if not guild_id:
                    raise ValueError("distribute_revenue requires guildId")
                dist_result = await self._runtime.guilds.distribute_revenue(guild_id, amount=payload.get("amount"))
                result = dist_result if isinstance(dist_result, dict) else {"distributed": True}

            # ── Swarm actions ──
            elif action_type == "create_swarm":
                title = payload.get("title", "")
                subtasks = payload.get("subtasks", [])
                if not title or not subtasks:
                    raise ValueError("create_swarm requires title and subtasks")
                swarm_result = await self._runtime.swarms.create(
                    title=title,
                    subtasks=subtasks,
                    description=payload.get("description"),
                    workspace_id=payload.get("workspaceId"),
                )
                result = swarm_result if isinstance(swarm_result, dict) else {"created": True}

            elif action_type == "claim_subtask":
                subtask_id = payload.get("subtaskId")
                if not subtask_id:
                    raise ValueError("claim_subtask requires subtaskId")
                claim_result = await self._runtime.swarms.claim_subtask(subtask_id)
                result = claim_result if isinstance(claim_result, dict) else {"claimed": True}

            elif action_type == "submit_swarm_result":
                subtask_id = payload.get("subtaskId")
                content = payload.get("content")
                if not subtask_id or content is None:
                    raise ValueError("submit_swarm_result requires subtaskId and content")
                sub_result = await self._runtime.swarms.submit_result(
                    subtask_id, content, result_type=payload.get("resultType", "output"),
                )
                result = sub_result if isinstance(sub_result, dict) else {"submitted": True}

            elif action_type == "aggregate_swarm":
                swarm_id = payload.get("swarmId")
                if not swarm_id:
                    raise ValueError("aggregate_swarm requires swarmId")
                agg_result = await self._runtime.swarms.aggregate(swarm_id, payload.get("summary", {}))
                result = agg_result if isinstance(agg_result, dict) else {"aggregated": True}

            elif action_type == "record_gap":
                query_text = payload.get("queryText", "")
                if not query_text:
                    raise ValueError("record_gap requires queryText")
                await self._runtime.specialization.record_gap(
                    query_text=query_text,
                    query_tags=payload.get("queryTags", []),
                    community_id=payload.get("communityId"),
                )
                result = {"recorded": True}

            elif action_type == "update_proficiency":
                domain = payload.get("skillDomain")
                if not domain:
                    raise ValueError("update_proficiency requires skillDomain")
                prof_result = await self._runtime.specialization.update_proficiency(
                    domain, float(payload.get("proficiency", 0)),
                )
                result = prof_result if isinstance(prof_result, dict) else {"updated": True}

            elif action_type == "generate_recommendations":
                recs = await self._runtime.specialization.generate_recommendations()
                result = {"recommendations": recs}

            elif action_type == "dismiss_recommendation":
                rec_id = payload.get("recommendationId")
                if not rec_id:
                    raise ValueError("dismiss_recommendation requires recommendationId")
                await self._runtime.specialization.dismiss_recommendation(rec_id)
                result = {"dismissed": True}

            # ── Intents ──
            elif action_type == "create_intent":
                intent_resp = await self._runtime._http.request("POST", "/v1/intents", {
                    "title": payload.get("title") or suggested_content or "Untitled intent",
                    "description": payload.get("description") or suggested_content or "",
                    "requiredSkills": payload.get("requiredSkills", []),
                    "budgetAmount": payload.get("budgetAmount"),
                    "category": payload.get("category"),
                    "tags": payload.get("tags", []),
                })
                result = intent_resp

            elif action_type == "browse_intents":
                params = {"status": payload.get("status", "open")}
                if payload.get("category"):
                    params["category"] = payload["category"]
                if payload.get("q"):
                    params["q"] = payload["q"]
                qs = "&".join(f"{k}={v}" for k, v in params.items() if v)
                browse_resp = await self._runtime._http.request("GET", f"/v1/intents?{qs}")
                result = browse_resp

            elif action_type == "submit_proposal":
                p_intent_id = payload.get("intentId")
                if not p_intent_id:
                    raise ValueError("submit_proposal requires intentId")
                proposal_resp = await self._runtime._http.request("POST", f"/v1/intents/{p_intent_id}/proposals", {
                    "description": payload.get("description") or suggested_content or "",
                    "approach": payload.get("approach"),
                    "estimatedCost": payload.get("estimatedCost"),
                    "estimatedDurationHours": payload.get("estimatedDurationHours"),
                })
                result = proposal_resp

            elif action_type == "accept_proposal":
                a_intent_id = payload.get("intentId")
                a_proposal_id = payload.get("proposalId")
                if not a_intent_id or not a_proposal_id:
                    raise ValueError("accept_proposal requires intentId and proposalId")
                accept_resp = await self._runtime._http.request("POST", f"/v1/intents/{a_intent_id}/proposals/{a_proposal_id}/accept")
                result = accept_resp

            elif action_type == "reject_proposal":
                rp_intent_id = payload.get("intentId")
                rp_proposal_id = payload.get("proposalId")
                if not rp_intent_id or not rp_proposal_id:
                    raise ValueError("reject_proposal requires intentId and proposalId")
                rp_reason = suggested_content or payload.get("reason", "")
                rp_body = {"reason": rp_reason} if rp_reason else {}
                result = await self._runtime._http.request("POST", f"/v1/intents/{rp_intent_id}/proposals/{rp_proposal_id}/reject", rp_body)

            elif action_type == "cancel_intent":
                c_intent_id = payload.get("intentId")
                if not c_intent_id:
                    raise ValueError("cancel_intent requires intentId")
                result = await self._runtime._http.request("POST", f"/v1/intents/{c_intent_id}/cancel")

            elif action_type == "complete_intent":
                comp_intent_id = payload.get("intentId")
                if not comp_intent_id:
                    raise ValueError("complete_intent requires intentId")
                result = await self._runtime._http.request("POST", f"/v1/intents/{comp_intent_id}/complete")

            elif action_type == "withdraw_proposal":
                w_intent_id = payload.get("intentId")
                w_proposal_id = payload.get("proposalId")
                if not w_intent_id or not w_proposal_id:
                    raise ValueError("withdraw_proposal requires intentId and proposalId")
                result = await self._runtime._http.request("POST", f"/v1/intents/{w_intent_id}/proposals/{w_proposal_id}/withdraw")

            # ── Clawnch Token Launching ──
            elif action_type == "preview_token_launch":
                result = await self._runtime._http.request("POST", "/v1/clawnch/preview", {
                    "tokenName": payload.get("tokenName"),
                    "tokenTicker": payload.get("tokenTicker"),
                    "description": payload.get("description") or suggested_content,
                    "imageUrl": payload.get("imageUrl"),
                })

            elif action_type == "launch_token":
                result = await self._runtime._http.request("POST", "/v1/clawnch/launch", {
                    "tokenName": payload.get("tokenName"),
                    "tokenTicker": payload.get("tokenTicker"),
                    "description": payload.get("description") or suggested_content,
                    "imageUrl": payload.get("imageUrl"),
                })

            elif action_type == "claim_clawnch_fees":
                token_addr = payload.get("tokenAddress")
                if not token_addr:
                    raise ValueError("claim_clawnch_fees requires tokenAddress")
                result = await self._runtime._http.request("POST", "/v1/clawnch/claim-fees", {
                    "tokenAddress": token_addr,
                })

            elif action_type == "get_token_analytics":
                t_addr = payload.get("tokenAddress")
                if not t_addr:
                    raise ValueError("get_token_analytics requires tokenAddress")
                result = await self._runtime._http.request("GET", f"/v1/clawnch/analytics/token/{t_addr}")

            # ── Oracle ──
            elif action_type == "query_oracle":
                entity_type = payload.get("entityType")
                entity_id = payload.get("entityId")
                if not entity_type or not entity_id:
                    raise ValueError("query_oracle requires entityType and entityId")
                result = await self._runtime._http.request("GET", f"/v1/oracle/{entity_type}/{entity_id}/signals")

            # ── Search Subscriptions ──
            elif action_type == "create_search_subscription":
                label = payload.get("label") or "Search subscription"
                query = payload.get("query") or ""
                if not query:
                    raise ValueError("create_search_subscription requires query")
                sub_body: dict[str, Any] = {"label": label, "query": query}
                if payload.get("types"):
                    sub_body["types"] = payload["types"]
                if payload.get("frequencyMinutes"):
                    sub_body["frequencyMinutes"] = payload["frequencyMinutes"]
                result = await self._runtime._http.request("POST", "/v1/search/subscriptions", sub_body)

            # ── Alias actions — map to existing handlers ──
            elif action_type == "reply":
                channel_id = payload.get("channelId")
                to = payload.get("to") or payload.get("targetAddress") or payload.get("senderAddress")
                if channel_id and suggested_content:
                    await self._runtime.channels.send(channel_id, suggested_content)
                elif to and suggested_content:
                    await self._runtime.inbox.send(to=to, content=suggested_content)
                result = {"sent": True}

            elif action_type in ("follow", "follow_back"):
                addr = payload.get("targetAddress") or payload.get("address") or payload.get("senderAddress")
                if not addr:
                    raise ValueError("follow requires targetAddress")
                f = await self._runtime.social.follow(addr)
                tx_hash = f.get("txHash") if isinstance(f, dict) else getattr(f, "tx_hash", None)
                result = {"txHash": tx_hash}

            elif action_type in ("attest", "attest_back"):
                addr = payload.get("targetAddress") or payload.get("address") or payload.get("senderAddress")
                reason = suggested_content or payload.get("reason", "Valued collaborator")
                if not addr:
                    raise ValueError("attest requires targetAddress")
                a = await self._runtime.social.attest(addr, reason)
                tx_hash = a.get("txHash") if isinstance(a, dict) else getattr(a, "tx_hash", None)
                result = {"txHash": tx_hash}

            elif action_type == "send_message":
                to = payload.get("to") or payload.get("targetAddress") or payload.get("senderAddress")
                channel_id = payload.get("channelId")
                if to:
                    await self._runtime.inbox.send(to=to, content=suggested_content or "Hey! Looking forward to collaborating.")
                elif channel_id:
                    await self._runtime.channels.send(channel_id, suggested_content or "Hey everyone!")
                result = {"sent": True}

            elif action_type == "acknowledge":
                proj_id = payload.get("projectId")
                if proj_id:
                    await self._runtime.channels.send_to_project(proj_id, suggested_content or "Got it, thanks for the mention!")
                result = {"acknowledged": True}

            elif action_type == "accept":
                proj_id = payload.get("projectId")
                if proj_id:
                    await self._runtime.channels.send_to_project(proj_id, suggested_content or "Accepted the task — I'll get started.")
                result = {"accepted": True}

            elif action_type == "execute":
                channel_id = payload.get("channelId")
                to = payload.get("to") or payload.get("targetAddress") or payload.get("senderAddress")
                if channel_id and suggested_content:
                    await self._runtime.channels.send(channel_id, suggested_content)
                elif to and suggested_content:
                    await self._runtime.inbox.send(to=to, content=suggested_content)
                result = {"executed": True}

            elif action_type in ("review", "comment"):
                proj_id = payload.get("projectId")
                commit_id = payload.get("commitId")
                verdict = "comment" if action_type == "comment" else payload.get("verdict", "comment")
                body = suggested_content or "Reviewed"
                if proj_id and commit_id:
                    await self._runtime.projects.submit_review(proj_id, commit_id, verdict, body)
                result = {"reviewed": True}

            # ── Email actions (off-chain REST) ──
            elif action_type == "send_email":
                to = payload.get("to")
                subject = payload.get("subject") or (suggested_content[:100] if suggested_content else None)
                body_text = payload.get("body") or suggested_content
                if not to or not subject or not body_text:
                    raise ValueError("send_email requires to, subject, and body")
                result = await self._runtime.email.send(to, subject, body_text)

            elif action_type == "reply_email":
                message_id = payload.get("messageId")
                body_text = payload.get("body") or suggested_content
                if not message_id or not body_text:
                    raise ValueError("reply_email requires messageId and body")
                result = await self._runtime.email.reply(message_id, body_text)

            elif action_type == "check_email":
                result = await self._runtime.email.list_messages(direction="inbound", limit=10)

            elif action_type == "create_email_inbox":
                username = payload.get("username")
                if not username:
                    raise ValueError("create_email_inbox requires username")
                result = await self._runtime.email.create_inbox(username, display_name=payload.get("displayName"))

            # ── Skill Registry ──────────────────────────────
            elif action_type == "search_skills":
                q = payload.get("query", payload.get("q", ""))
                category = payload.get("category")
                tags = payload.get("tags")
                limit = payload.get("limit", 20)
                params: dict[str, str] = {"limit": str(limit)}
                if q:
                    params["q"] = q
                if category:
                    params["category"] = category
                if tags:
                    params["tags"] = tags
                qs = "&".join(f"{k}={v}" for k, v in params.items())
                result = await self._runtime._http.request("GET", f"/v1/skills/registry?{qs}")

            elif action_type == "publish_skill":
                name = payload.get("name")
                if not name:
                    raise ValueError("publish_skill requires name")
                result = await self._runtime._http.request("POST", "/v1/skills/registry", {
                    "name": name,
                    "description": payload.get("description"),
                    "packageType": payload.get("packageType", "skill_md"),
                    "category": payload.get("category", "other"),
                    "tags": payload.get("tags"),
                    "content": payload.get("content"),
                    "githubUrl": payload.get("githubUrl"),
                    "npmPackage": payload.get("npmPackage"),
                    "version": payload.get("version", "1.0.0"),
                    "metadata": payload.get("metadata"),
                })

            elif action_type == "install_skill":
                skill_id = payload.get("skillId") or payload.get("skill_id")
                if not skill_id:
                    raise ValueError("install_skill requires skillId")
                result = await self._runtime._http.request("POST", f"/v1/skills/registry/{skill_id}/install", {})

            elif action_type == "review_skill":
                skill_id = payload.get("skillId") or payload.get("skill_id")
                rating = payload.get("rating")
                if not skill_id or not rating:
                    raise ValueError("review_skill requires skillId and rating")
                result = await self._runtime._http.request("POST", f"/v1/skills/registry/{skill_id}/review", {
                    "rating": rating,
                    "review": payload.get("review", payload.get("content")),
                })

            elif action_type == "update_skill":
                skill_id = payload.get("skillId") or payload.get("skill_id")
                if not skill_id:
                    raise ValueError("update_skill requires skillId")
                result = await self._runtime._http.request("PATCH", f"/v1/skills/registry/{skill_id}", {
                    "name": payload.get("name"),
                    "description": payload.get("description"),
                    "version": payload.get("version"),
                    "tags": payload.get("tags"),
                    "content": payload.get("content"),
                    "metadata": payload.get("metadata"),
                })

            elif action_type == "trending_skills":
                limit = payload.get("limit", 20)
                result = await self._runtime._http.request("GET", f"/v1/skills/registry/trending?limit={limit}")

            # ── Agent Memory ─────────────────────────────────
            elif action_type == "store_memory":
                content = payload.get("content") or payload.get("body")
                if not content:
                    raise ValueError("store_memory requires content")
                result = await self._runtime._http.request("POST", "/v1/agent-memory/store", {
                    "type": payload.get("memoryType", payload.get("type", "semantic")),
                    "content": content,
                    "importance": payload.get("importance"),
                    "tags": payload.get("tags"),
                    "source": payload.get("source"),
                    "metadata": payload.get("metadata"),
                })

            elif action_type == "recall_memory":
                query = payload.get("query") or payload.get("q")
                if not query:
                    raise ValueError("recall_memory requires query")
                # Gateway expects "types" (plural array), not "type" (singular string)
                _rt = payload.get("types") or payload.get("memoryType") or payload.get("type")
                recall_types = _rt if isinstance(_rt, list) else ([_rt] if _rt else None)
                result = await self._runtime._http.request("POST", "/v1/agent-memory/recall", {
                    "query": query,
                    "types": recall_types,
                    "limit": payload.get("limit", 10),
                })

            elif action_type == "list_memories":
                mem_type = payload.get("memoryType", payload.get("type", ""))
                limit = payload.get("limit", 20)
                qs_parts = [f"limit={limit}"]
                if mem_type:
                    qs_parts.append(f"type={mem_type}")
                result = await self._runtime._http.request("GET", f"/v1/agent-memory/list?{'&'.join(qs_parts)}")

            elif action_type == "memory_stats":
                result = await self._runtime._http.request("GET", "/v1/agent-memory/stats")

            elif action_type == "export_memories":
                result = await self._runtime._http.request("POST", "/v1/agent-memory/export", {})

            elif action_type == "import_memories":
                pack = payload.get("pack") or payload.get("memories")
                if not pack:
                    raise ValueError("import_memories requires pack data")
                # Gateway expects MemoryPack at top level (memories + packHash), not wrapped in { pack }
                result = await self._runtime._http.request("POST", "/v1/agent-memory/import", pack)

            # ── Forge (Agent Deployment) ─────────────────────
            elif action_type == "forge_deploy":
                bundle_id = payload.get("bundleId") or payload.get("bundle_id")
                agent_address = payload.get("agentAddress") or payload.get("agent_address")
                soul_cid = payload.get("soulCid") or payload.get("soul_cid")
                if not bundle_id:
                    raise ValueError("forge_deploy requires bundleId (number)")
                if not agent_address:
                    raise ValueError("forge_deploy requires agentAddress")
                if not soul_cid:
                    raise ValueError("forge_deploy requires soulCid")
                prep = await self._runtime._http.request("POST", "/v1/prepare/forge", {
                    "bundleId": bundle_id,
                    "agentAddress": agent_address,
                    "soulCid": soul_cid,
                    "deploymentFee": payload.get("deploymentFee", "0"),
                })
                relay = await self._runtime.memory._sign_and_relay(prep)
                tx_hash = relay.get("txHash")
                result = {"txHash": tx_hash}

            elif action_type == "forge_spawn":
                spawn_bundle_id = payload.get("bundleId") or payload.get("bundle_id")
                child_address = payload.get("childAddress") or payload.get("child_address") or payload.get("parentAddress")
                spawn_soul_cid = payload.get("soulCid") or payload.get("soul_cid")
                if not spawn_bundle_id:
                    raise ValueError("forge_spawn requires bundleId (number)")
                if not child_address:
                    raise ValueError("forge_spawn requires childAddress")
                if not spawn_soul_cid:
                    raise ValueError("forge_spawn requires soulCid")
                prep = await self._runtime._http.request("POST", "/v1/prepare/forge/spawn", {
                    "bundleId": spawn_bundle_id,
                    "childAddress": child_address,
                    "soulCid": spawn_soul_cid,
                    "deploymentFee": payload.get("deploymentFee", "0"),
                })
                relay = await self._runtime.memory._sign_and_relay(prep)
                tx_hash = relay.get("txHash")
                result = {"txHash": tx_hash}

            elif action_type == "forge_update_soul":
                agent_id = payload.get("agentId") or payload.get("forgeId") or payload.get("agent_id")
                if not agent_id:
                    raise ValueError("forge_update_soul requires agentId")
                prep = await self._runtime._http.request("POST", f"/v1/prepare/forge/{agent_id}/soul", {
                    "soulCid": payload.get("soulCid", payload.get("soul_cid")),
                    "metadata": payload.get("metadata"),
                })
                relay = await self._runtime.memory._sign_and_relay(prep)
                tx_hash = relay.get("txHash")
                result = {"txHash": tx_hash}

            # ── Teaching Exchanges ──────────────────────────
            elif action_type == "propose_teaching":
                learner_address = payload.get("learnerAddress") or payload.get("learner_address")
                goal = payload.get("goal") or suggested_content
                offerings = payload.get("offerings", [])
                if not learner_address or not goal or not offerings:
                    raise ValueError("propose_teaching requires learnerAddress, goal, offerings[]")
                result = await self._runtime._http.request("POST", "/v1/teaching/propose", {
                    "learnerAddress": learner_address, "goal": goal, "offerings": offerings,
                })

            elif action_type == "accept_teaching":
                exchange_id = payload.get("exchangeId") or payload.get("exchange_id")
                if not exchange_id:
                    raise ValueError("accept_teaching requires exchangeId")
                result = await self._runtime._http.request("POST", f"/v1/teaching/{exchange_id}/accept", {})

            elif action_type == "deliver_teaching":
                exchange_id = payload.get("exchangeId") or payload.get("exchange_id")
                if not exchange_id:
                    raise ValueError("deliver_teaching requires exchangeId")
                result = await self._runtime._http.request("POST", f"/v1/teaching/{exchange_id}/deliver", {
                    "notes": payload.get("notes"),
                })

            elif action_type == "approve_teaching":
                exchange_id = payload.get("exchangeId") or payload.get("exchange_id")
                if not exchange_id:
                    raise ValueError("approve_teaching requires exchangeId")
                result = await self._runtime._http.request("POST", f"/v1/teaching/{exchange_id}/approve", {
                    "feedback": payload.get("feedback"), "rating": payload.get("rating"),
                })

            elif action_type == "reject_teaching":
                exchange_id = payload.get("exchangeId") or payload.get("exchange_id")
                if not exchange_id:
                    raise ValueError("reject_teaching requires exchangeId")
                result = await self._runtime._http.request("POST", f"/v1/teaching/{exchange_id}/reject", {
                    "feedback": payload.get("feedback"),
                })

            elif action_type == "search_teachers":
                goal = payload.get("goal") or payload.get("query")
                if not goal:
                    raise ValueError("search_teachers requires goal")
                from urllib.parse import quote
                limit = payload.get("limit", 10)
                result = await self._runtime._http.request("GET", f"/v1/teaching/search-teachers?goal={quote(str(goal))}&limit={limit}")

            # ── Credit Hire (off-chain marketplace) ─────────
            elif action_type == "credit_hire":
                listing_id = payload.get("listingId") or payload.get("listing_id")
                terms = payload.get("terms") or suggested_content
                credit_amount = payload.get("creditAmount") or payload.get("credit_amount")
                if not listing_id or not terms or not credit_amount:
                    raise ValueError("credit_hire requires listingId, terms, creditAmount")
                result = await self._runtime._http.request("POST", "/v1/marketplace/credit-hire", {
                    "listingId": listing_id, "terms": terms, "creditAmount": credit_amount,
                })

            elif action_type == "accept_credit_agreement":
                agreement_id = payload.get("agreementId") or payload.get("agreement_id")
                if not agreement_id:
                    raise ValueError("accept_credit_agreement requires agreementId")
                result = await self._runtime._http.request("POST", f"/v1/marketplace/credit-agreements/{agreement_id}/accept", {})

            elif action_type == "deliver_credit_work":
                agreement_id = payload.get("agreementId") or payload.get("agreement_id")
                if not agreement_id:
                    raise ValueError("deliver_credit_work requires agreementId")
                result = await self._runtime._http.request("POST", f"/v1/marketplace/credit-agreements/{agreement_id}/deliver", {
                    "deliveryNotes": payload.get("deliveryNotes") or payload.get("delivery_notes"),
                })

            elif action_type == "complete_credit_agreement":
                agreement_id = payload.get("agreementId") or payload.get("agreement_id")
                if not agreement_id:
                    raise ValueError("complete_credit_agreement requires agreementId")
                result = await self._runtime._http.request("POST", f"/v1/marketplace/credit-agreements/{agreement_id}/complete", {
                    "rating": payload.get("rating"), "review": payload.get("review"),
                })

            elif action_type == "cancel_credit_agreement":
                agreement_id = payload.get("agreementId") or payload.get("agreement_id")
                if not agreement_id:
                    raise ValueError("cancel_credit_agreement requires agreementId")
                result = await self._runtime._http.request("POST", f"/v1/marketplace/credit-agreements/{agreement_id}/cancel", {})

            elif action_type == "ignore":
                self._broadcast("action_executed", "⏭ Action acknowledged, no action taken", {
                    "action": "ignore", "actionId": action_id,
                })
                return

            else:
                self._broadcast("action_skipped", f"⏭ Unknown action: {action_type}", {
                    "action": action_type, "actionId": action_id,
                })
                if action_id:
                    await self._runtime.proactive.reject_delegated_action(action_id, f"Unknown: {action_type}")
                return

            if action_id:
                await self._runtime.proactive.complete_action(action_id, tx_hash, result)
            self._broadcast("action_executed", f"✓ {action_type}{f' tx={tx_hash}' if tx_hash else ''}", {
                "action": action_type, "actionId": action_id, "txHash": tx_hash, "result": result,
            })

        except Exception as exc:
            err_msg = str(exc)
            self._broadcast("error", f"✗ {action_type}: {err_msg}", {
                "action": action_type, "actionId": action_id, "error": err_msg,
            })
            if action_id:
                try:
                    await self._runtime.proactive.reject_delegated_action(action_id, err_msg)
                except Exception:
                    pass
