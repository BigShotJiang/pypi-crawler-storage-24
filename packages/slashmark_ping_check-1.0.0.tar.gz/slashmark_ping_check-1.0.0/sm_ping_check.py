import os
import sys

def main():
    if len(sys.argv) < 2:
        print("Usage: sm-ping <host>")
        return

    host = sys.argv[1]

    # mac uses -c
    response = os.system(f"ping -c 4 {host}")

    if response == 0:
        print("Host is reachable")
    else:
        print("Host is unreachable")

if __name__ == "__main__":
    main()
