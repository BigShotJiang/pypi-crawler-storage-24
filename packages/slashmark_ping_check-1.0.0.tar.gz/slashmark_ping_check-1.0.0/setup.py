from setuptools import setup

setup(
    name="slashmark-ping-check",
    version="1.0.0",
    py_modules=["sm_ping_check"],
    entry_points={
        "console_scripts": [
            "sm-ping=sm_ping_check:main",
        ],
    },
)
