"""Run the MCP server with: python -m redis_client_mcp"""
from .server import main

if __name__ == "__main__":
    main()
