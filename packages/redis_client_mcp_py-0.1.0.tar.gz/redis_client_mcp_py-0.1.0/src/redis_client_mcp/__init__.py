"""Redis MCP Server (standalone + cluster)."""

__version__ = "0.1.0"
