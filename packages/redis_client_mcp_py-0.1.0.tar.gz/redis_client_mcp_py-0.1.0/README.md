# Redis MCP Server (redis-client-mcp-py)

支持单机与集群的 Redis MCP Server：连接与 key 发现、INFO、单条命令安全执行（命令由大模型产生，MCP 只做校验与执行）。

## 环境变量

### 单连接

| 变量 | 说明 |
|------|------|
| `REDIS_HOST` | 主机 |
| `REDIS_PORT` | 端口，默认 6379 |
| `REDIS_PASSWORD` | 密码，可选 |
| `REDIS_DB` | DB 编号，默认 0 |

### 多环境（推荐：TEST_REDIS_PROFILES / UAT_REDIS_PROFILES / PROD_REDIS_PROFILES）

每个为 JSON 数组，项内支持：

- **单机**：`mode: "standalone"`（可省略），`host`, `port`, `password`, `db`, `description`, `name`
- **集群**：`mode: "cluster"`, `hosts: ["host1:6379", "host2:6379"]` 或 `host`+`port`，`password`, `description`, `name`

Profile 名为 `test_0`, `prod_0`, `test_cache`（若该项有 `name: "cache"`）等。

### 安全与行为

| 变量 | 默认 | 说明 |
|------|------|------|
| `REDIS_READ_ONLY` | false | 为 true 时仅允许只读命令 |
| `REDIS_MAX_SCAN_KEYS` | 1000 | list_keys/SCAN 单次最多返回 key 数 |
| `REDIS_CONFIRM_DANGEROUS` | true | 危险命令需 confirm 或禁止 |
| `REDIS_COMMAND_TIMEOUT_SECONDS` | 30 | 命令超时(秒) |

## 安装与运行

```bash
cd redis-client-mcp-py
uv sync
uv run python -m redis_client_mcp
# 或安装后
redis-client-mcp-py
```

### Cursor / Claude 配置示例

```json
{
  "mcpServers": {
    "redis": {
      "command": "uvx",
      "args": ["redis-client-mcp-py"],
      "env": {
        "TEST_REDIS_PROFILES": "[{\"mode\":\"standalone\",\"host\":\"127.0.0.1\",\"port\":6379,\"description\":\"本机\"}]"
      }
    }
  }
}
```

## 工具

| 工具 | 说明 |
|------|------|
| `list_connections` | 列出可用连接（profile、单机/集群） |
| `list_keys` | SCAN 列出 key（pattern、max_scan_keys 限制） |
| `info` | Redis INFO（可选 section） |
| `analyze_command` | 分析一条命令（不执行）：只读/写/危险、是否需 confirm |
| `execute_command` | 执行单条命令（由大模型产生）；写操作需 confirm=true |

## 资源

- `redis://config` - 配置与安全策略摘要
- `redis://keys/{pattern}` - 指定 pattern 的 key 列表

## 设计约定

- **元数据**：list_connections、list_keys、info 由 MCP 提供。
- **CRUD**：单条命令，**内容由大模型产生**，MCP 只做安全检查与执行；写操作需 confirm。

## License

MIT
