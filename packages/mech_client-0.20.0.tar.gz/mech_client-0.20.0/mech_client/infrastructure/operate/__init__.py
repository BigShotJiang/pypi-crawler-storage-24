# -*- coding: utf-8 -*-
# ------------------------------------------------------------------------------
#
#   Copyright 2025 Valory AG
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#
# ------------------------------------------------------------------------------

"""Operate middleware integration for agent mode setup and key management."""

from mech_client.infrastructure.operate.config_loader import load_rpc_from_operate
from mech_client.infrastructure.operate.key_manager import fetch_agent_mode_keys
from mech_client.infrastructure.operate.manager import OperateManager

__all__ = [
    "OperateManager",
    "fetch_agent_mode_keys",
    "load_rpc_from_operate",
]
