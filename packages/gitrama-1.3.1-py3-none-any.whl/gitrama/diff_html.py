"""
Gitrama - AI-powered Git workflow automation

Copyright © 2026 Gitrama LLC. All Rights Reserved.

This software is proprietary and confidential.
Unauthorized copying, distribution, or use is strictly prohibited.

Gitrama LLC
South Carolina Limited Liability Company
"""

"""
diff_html.py — Browser panel for gtr diff.

Called at the end of every `gtr diff` run. Builds a self-contained HTML
file from the diff data already collected and opens it in the default
browser. Non-blocking — the CLI continues immediately.

No dependencies beyond the stdlib. The HTML is fully self-contained
(single file, no external requests at runtime).
"""

import html
import json
import os
import re
import tempfile
import threading
import webbrowser
from datetime import datetime
from pathlib import Path
from typing import Optional


# ─── Public entry point ───────────────────────────────────────────────────────

def open_diff_panel(
    changed_files: list[dict],
    risk_scores: dict[str, int],
    raw_diff: str,
    coupling_gaps: list[dict] = None,
    branch_summary: Optional[str] = None,
    label: str = "",
) -> None:
    """
    Build and open the gtr diff browser panel.

    Runs the browser open in a background thread so the CLI
    returns immediately without waiting.

    Args:
        changed_files:  List of {"status": str, "path": str} dicts.
        risk_scores:    {filepath: score} from last_scan.json.
        raw_diff:       Raw git diff output string.
        coupling_gaps:  List of {"changed", "missed", "count"} dicts.
        branch_summary: Plain-English AI summary (Feature D), or None.
        label:          e.g. "--staged", "main..feature", etc.
    """
    coupling_gaps = coupling_gaps or []

    html_content = _build_html(
        changed_files=changed_files,
        risk_scores=risk_scores,
        raw_diff=raw_diff,
        coupling_gaps=coupling_gaps,
        branch_summary=branch_summary,
        label=label,
    )

    def _write_and_open():
        import sys
        print("[gtr diff] browser thread started", file=sys.stderr)
        fd, path = tempfile.mkstemp(suffix=".html", prefix="gtr_diff_")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(html_content)
            print(f"[gtr diff] HTML written to: {path}", file=sys.stderr)
        except Exception as e:
            print(f"[gtr diff] file write failed: {e}", file=sys.stderr)
            return

        try:
            print("[gtr diff] calling _launch_browser...", file=sys.stderr)
            _launch_browser(path)
            print("[gtr diff] _launch_browser returned OK", file=sys.stderr)
        except Exception as e:
            print(f"[gtr diff] _launch_browser raised: {e}", file=sys.stderr)
            try:
                os.unlink(path)
            except OSError:
                pass

    # daemon=True — thread dies with the process if join() times out
    t = threading.Thread(target=_write_and_open, daemon=True)
    t.start()
    return t  # caller can join(timeout=5.0) to wait for browser launch


def _launch_browser(path: str) -> None:
    """
    Open the HTML file in the default browser.
    Handles Windows path quirks and falls back through multiple strategies.
    """
    import platform
    import subprocess as _sp

    system = platform.system()

    # ── Windows ──────────────────────────────────────────────────────────────
    # os.startfile is the most reliable method on Windows —
    # avoids file:// path issues with backslashes and spaces.
    if system == "Windows":
        try:
            os.startfile(path)  # type: ignore[attr-defined]
            return
        except Exception:
            pass
        # Fallback: use 'start' shell command
        try:
            _sp.Popen(
                ["cmd", "/c", "start", "", path],
                shell=False,
                stdout=_sp.DEVNULL,
                stderr=_sp.DEVNULL,
            )
            return
        except Exception:
            pass

    # ── macOS ─────────────────────────────────────────────────────────────────
    if system == "Darwin":
        try:
            _sp.Popen(
                ["open", path],
                stdout=_sp.DEVNULL,
                stderr=_sp.DEVNULL,
            )
            return
        except Exception:
            pass

    # ── Linux ─────────────────────────────────────────────────────────────────
    if system == "Linux":
        for cmd in ("xdg-open", "sensible-browser", "x-www-browser"):
            try:
                _sp.Popen(
                    [cmd, path],
                    stdout=_sp.DEVNULL,
                    stderr=_sp.DEVNULL,
                )
                return
            except FileNotFoundError:
                continue

    # ── Universal fallback via stdlib webbrowser ──────────────────────────────
    # Convert path to proper file URI — handles Windows backslashes
    from urllib.request import pathname2url
    file_uri = "file://" + pathname2url(os.path.abspath(path))
    webbrowser.open(file_uri)


# ─── Data helpers ─────────────────────────────────────────────────────────────

def _risk_info(score: Optional[int]) -> dict:
    if score is None:
        return {"label": "unknown", "cls": "risk-unknown", "color": "#5a6a7a"}
    if score >= 80:
        return {"label": f"{score} 🔴", "cls": "risk-high", "color": "#ff4455"}
    if score >= 50:
        return {"label": f"{score} ⚠", "cls": "risk-mid",  "color": "#ffaa00"}
    return {"label": str(score), "cls": "risk-low", "color": "#44cc88"}


def _status_color(status: str) -> str:
    return {
        "Modified": "#4fc3f7",
        "Added":    "#44cc88",
        "Deleted":  "#ff5566",
        "Renamed":  "#ffaa00",
    }.get(status, "#e8eaf0")


def _churn_info(churn: Optional[int]) -> dict:
    if churn is None or churn == 0:
        return {"label": "", "color": ""}
    if churn >= 20:
        return {"label": f"{churn} commits/30d ⚡ high churn", "color": "#ff4455"}
    if churn >= 8:
        return {"label": f"{churn} commits/30d ⚡", "color": "#ffaa00"}
    return {"label": f"{churn} commits/30d", "color": "#5a6a7a"}


# ─── Diff parser (mirrors _render_pretty_diff logic) ─────────────────────────

def _parse_raw_diff(raw: str) -> list[dict]:
    """
    Parse raw git diff into a list of file blocks:
    [{"path": str, "hunks": [{"explanation": str, "lines": [...]}]}]
    """
    files = []
    current_file = None
    current_hunk = None

    for line in raw.splitlines():

        if line.startswith("diff --git "):
            parts = line.split(" ")
            path = parts[-1][2:] if parts[-1].startswith("b/") else parts[-1]
            current_file = {"path": path, "hunks": []}
            files.append(current_file)
            current_hunk = None
            continue

        if line.startswith("--- ") or line.startswith("+++ "):
            continue
        if line.startswith("index ") and ".." in line:
            continue
        if any(line.startswith(p) for p in ("new file mode", "deleted file mode", "old mode", "new mode")):
            continue

        if line.startswith("@@ ") and current_file is not None:
            explanation = _parse_hunk_explanation(line)
            current_hunk = {"explanation": explanation, "lines": []}
            current_file["hunks"].append(current_hunk)
            continue

        if current_hunk is not None:
            if line.startswith("+"):
                current_hunk["lines"].append({"type": "added",   "text": line[1:]})
            elif line.startswith("-"):
                current_hunk["lines"].append({"type": "removed", "text": line[1:]})
            else:
                current_hunk["lines"].append({"type": "context", "text": line})

    return files


def _parse_hunk_explanation(line: str) -> str:
    match = re.match(r'@@\s+-(\d+)(?:,(\d+))?\s+\+(\d+)(?:,(\d+))?\s+@@(.*)', line)
    if not match:
        return line

    old_start = int(match.group(1))
    old_count = int(match.group(2)) if match.group(2) is not None else 1
    new_start = int(match.group(3))
    new_count = int(match.group(4)) if match.group(4) is not None else 1
    context   = match.group(5).strip()

    added   = max(0, new_count - old_count)
    removed = max(0, old_count - new_count)

    parts = []
    if added:
        parts.append(f'<span class="added-label">+{added} lines added</span>')
    if removed:
        parts.append(f'<span class="removed-label">−{removed} lines removed</span>')
    if not parts:
        parts.append('<span class="dim-label">lines reorganised</span>')

    location = f'<span class="dim-label">starting at line {old_start}</span>'
    scope = f' <span class="dim-label">inside</span> <span class="scope-label">{html.escape(context)}</span>' if context else ""

    return f'{"  ".join(parts)}  {location}{scope}'


# ─── HTML builder ─────────────────────────────────────────────────────────────

def _build_html(
    changed_files: list[dict],
    risk_scores: dict[str, int],
    raw_diff: str,
    coupling_gaps: list[dict],
    branch_summary: Optional[str],
    label: str,
) -> str:

    timestamp = datetime.now().strftime("%b %d, %Y  %H:%M")
    diff_blocks = _parse_raw_diff(raw_diff)

    # Build file rows HTML
    file_rows_html = ""
    for i, f in enumerate(changed_files):
        path = f["path"]
        status = f["status"]
        score = risk_scores.get(path)
        risk = _risk_info(score)
        touched = f.get("last_touched", "")
        churn = _churn_info(f.get("churn"))
        test_warn = f.get("test_warning", "")

        churn_html = f'<span class="churn-badge" style="color:{churn["color"]}">{html.escape(churn["label"])}</span>' if churn["label"] else ""
        touched_html = f'<span class="meta-val">{html.escape(touched)}</span>' if touched else ""
        test_html = f'<div class="test-warning">⚠ {html.escape(path)} changed — <strong>{html.escape(test_warn)}</strong> exists but was not modified</div>' if test_warn else ""

        file_rows_html += f"""
        <div class="file-row" style="animation-delay: {i * 0.06}s">
          <div class="file-main">
            <span class="status-badge" style="color:{_status_color(status)}">{html.escape(status)}</span>
            <span class="file-path">{html.escape(path)}</span>
            <span class="risk-badge {risk['cls']}" style="border-color:{risk['color']}55; color:{risk['color']}">
              risk: {html.escape(risk['label'])}
            </span>
          </div>
          <div class="file-meta">
            {"<span class='meta-key'>last touched:</span> " + touched_html if touched_html else ""}
            {"<span class='meta-sep'>·</span>" if touched_html and churn_html else ""}
            {"<span class='meta-key'>churn (30d):</span> " + churn_html if churn_html else ""}
          </div>
          {test_html}
        </div>"""

    # Build coupling gaps HTML
    coupling_html = ""
    if coupling_gaps:
        items = ""
        seen = set()
        for gap in coupling_gaps:
            changed = gap["changed"]
            if changed not in seen:
                items += f'<div class="gap-changed">You modified <span class="file-ref">{html.escape(changed)}</span> but did not touch its co-change partners:</div>'
                seen.add(changed)
            items += f'<div class="gap-partner">→ <span class="file-ref">{html.escape(gap["missed"])}</span> <span class="gap-count">(co-changed {gap["count"]}x historically)</span></div>'

        coupling_html = f"""
        <section class="section">
          <div class="section-header">
            <span class="section-title">Coupling Gaps</span>
            <div class="section-rule"></div>
          </div>
          <div class="coupling-block">
            <div class="coupling-icon">⚠</div>
            <div class="coupling-body">{items}</div>
          </div>
        </section>"""

    # Build branch summary HTML
    summary_html = ""
    if branch_summary:
        summary_html = f"""
        <section class="section">
          <div class="section-header">
            <span class="section-title">Branch Summary</span>
            <div class="section-rule"></div>
          </div>
          <div class="summary-block">{html.escape(branch_summary)}</div>
        </section>"""

    # Build diff blocks HTML
    diff_html = ""
    for block in diff_blocks:
        score = risk_scores.get(block["path"])
        risk = _risk_info(score)
        hunks_html = ""
        for hunk in block["hunks"]:
            lines_html = ""
            for ln in hunk["lines"]:
                prefix = "+" if ln["type"] == "added" else ("−" if ln["type"] == "removed" else " ")
                lines_html += f'<div class="diff-line diff-{ln["type"]}"><span class="line-prefix">{prefix}</span><span class="line-text">{html.escape(ln["text"])}</span></div>'
            hunks_html += f"""
            <div class="hunk">
              <div class="hunk-header">┄ {hunk["explanation"]}</div>
              <div class="hunk-lines">{lines_html}</div>
            </div>"""

        diff_html += f"""
        <div class="diff-block">
          <div class="diff-file-banner">
            <span class="banner-rule">━━━</span>
            <span class="banner-path">{html.escape(block["path"])}</span>
            <span class="banner-risk" style="color:{risk['color']}">risk: {html.escape(risk['label'])}</span>
            <span class="banner-rule-end">━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━</span>
          </div>
          {hunks_html}
        </div>"""

    label_display = html.escape(label) if label else "working tree"

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>gtr diff — {label_display}</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600;700&family=Syne:wght@700;800&display=swap');

  *, *::before, *::after {{ box-sizing: border-box; margin: 0; padding: 0; }}

  :root {{
    --bg:        #020c14;
    --surface:   #060f18;
    --border:    #0f2030;
    --border2:   #1a2a3a;
    --green:     #44cc88;
    --red:       #ff4455;
    --yellow:    #ffaa00;
    --cyan:      #4fc3f7;
    --purple:    #c792ea;
    --dim:       #3d5a70;
    --dimmer:    #1a3a5a;
    --text:      #e8eaf0;
    --meta:      #5a6a7a;
  }}

  html {{ scroll-behavior: smooth; }}

  body {{
    background: var(--bg);
    color: var(--text);
    font-family: 'JetBrains Mono', 'Fira Code', monospace;
    font-size: 13px;
    line-height: 1.6;
    min-height: 100vh;
    padding: 32px 24px 64px;
  }}

  /* CRT scanline overlay */
  body::before {{
    content: '';
    position: fixed;
    inset: 0;
    background: repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.03) 2px, rgba(0,0,0,0.03) 4px);
    pointer-events: none;
    z-index: 1000;
  }}

  .wrap {{ max-width: 920px; margin: 0 auto; }}

  /* ── Header ── */
  .header {{
    display: flex;
    align-items: center;
    gap: 16px;
    margin-bottom: 28px;
    padding-bottom: 16px;
    border-bottom: 1px solid var(--border);
  }}
  .logo {{
    font-family: 'Syne', sans-serif;
    font-weight: 800;
    font-size: 14px;
    letter-spacing: 0.2em;
    color: var(--green);
    text-transform: uppercase;
  }}
  .header-meta {{
    display: flex;
    flex-direction: column;
    gap: 2px;
    margin-left: auto;
    text-align: right;
  }}
  .header-label {{
    font-size: 11px;
    color: var(--cyan);
    font-weight: 700;
    letter-spacing: 0.1em;
  }}
  .header-time {{
    font-size: 10px;
    color: var(--dimmer);
    letter-spacing: 0.05em;
  }}

  /* ── Sections ── */
  .section {{ margin-bottom: 28px; }}
  .section-header {{
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 14px;
  }}
  .section-title {{
    font-size: 10px;
    color: var(--dimmer);
    letter-spacing: 0.2em;
    text-transform: uppercase;
    white-space: nowrap;
  }}
  .section-rule {{
    flex: 1;
    height: 1px;
    background: var(--border);
  }}

  /* ── File rows ── */
  .file-row {{
    margin-bottom: 16px;
    opacity: 0;
    transform: translateX(-10px);
    animation: slideIn 0.35s ease forwards;
  }}
  @keyframes slideIn {{
    to {{ opacity: 1; transform: translateX(0); }}
  }}
  .file-main {{
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
  }}
  .status-badge {{
    min-width: 76px;
    font-weight: 600;
    font-size: 12px;
  }}
  .file-path {{
    color: var(--text);
    flex: 1;
    min-width: 200px;
    font-size: 12.5px;
  }}
  .risk-badge {{
    font-size: 11px;
    font-weight: 700;
    padding: 1px 10px;
    border: 1px solid;
    border-radius: 4px;
    background: rgba(0,0,0,0.3);
  }}
  .risk-unknown {{ color: var(--meta) !important; border-color: #2a3a4a !important; }}

  .file-meta {{
    padding-left: 86px;
    margin-top: 4px;
    font-size: 11px;
    color: var(--meta);
    display: flex;
    align-items: center;
    gap: 6px;
    flex-wrap: wrap;
  }}
  .meta-key  {{ color: var(--dimmer); }}
  .meta-val  {{ color: #7a9ab5; }}
  .meta-sep  {{ color: var(--border2); }}
  .churn-badge {{ font-weight: 600; }}

  .test-warning {{
    margin-top: 5px;
    padding-left: 86px;
    font-size: 11px;
    color: var(--yellow);
    opacity: 0.85;
  }}
  .test-warning strong {{ font-weight: 700; }}

  /* ── Coupling gaps ── */
  .coupling-block {{
    background: #1a150055;
    border: 1px solid #4a380033;
    border-left: 3px solid var(--yellow);
    border-radius: 6px;
    padding: 14px 16px;
    display: flex;
    gap: 14px;
  }}
  .coupling-icon {{ color: var(--yellow); font-size: 16px; padding-top: 1px; }}
  .coupling-body {{ flex: 1; line-height: 2; }}
  .gap-changed {{ color: #7a7a55; font-size: 12px; margin-bottom: 4px; }}
  .gap-partner {{ font-size: 12px; color: var(--meta); padding-left: 12px; }}
  .file-ref {{ color: var(--cyan); }}
  .gap-count {{ color: var(--dimmer); }}

  /* ── Branch summary ── */
  .summary-block {{
    background: var(--surface);
    border: 1px solid var(--border);
    border-left: 3px solid var(--green);
    border-radius: 6px;
    padding: 16px 20px;
    color: #a8c8b0;
    font-size: 13px;
    line-height: 1.8;
    white-space: pre-wrap;
  }}

  /* ── Diff blocks ── */
  .diff-block {{ margin-bottom: 28px; }}
  .diff-file-banner {{
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 8px;
    font-size: 12px;
    font-weight: 700;
    flex-wrap: wrap;
    overflow: hidden;
  }}
  .banner-rule, .banner-rule-end {{ color: var(--border2); }}
  .banner-rule-end {{ flex: 1; overflow: hidden; white-space: nowrap; }}
  .banner-path {{ color: var(--cyan); }}
  .banner-risk {{ font-size: 11px; font-weight: 700; }}

  .hunk {{ margin-bottom: 12px; }}
  .hunk-header {{
    font-size: 11.5px;
    color: var(--dim);
    padding: 6px 0 8px 4px;
    line-height: 1.6;
  }}
  .added-label   {{ color: var(--green); font-weight: 700; }}
  .removed-label {{ color: var(--red);   font-weight: 700; }}
  .dim-label     {{ color: var(--meta); }}
  .scope-label   {{ color: var(--purple); font-weight: 700; }}

  .hunk-lines {{
    background: #0a1520;
    border: 1px solid var(--border2);
    border-radius: 6px;
    overflow: hidden;
    font-size: 12px;
  }}
  .diff-line {{
    display: flex;
    padding: 3px 12px 3px 10px;
    border-left: 3px solid transparent;
  }}
  .diff-added   {{ background: #0d2a1a; border-color: var(--green); }}
  .diff-removed {{ background: #2a0d0d; border-color: var(--red); }}
  .diff-context {{ background: transparent; }}

  .line-prefix {{
    min-width: 18px;
    margin-right: 10px;
    font-weight: 700;
    user-select: none;
    font-size: 11px;
  }}
  .diff-added   .line-prefix {{ color: var(--green); }}
  .diff-removed .line-prefix {{ color: var(--red); }}
  .diff-context .line-prefix {{ color: transparent; }}

  .line-text {{ white-space: pre; }}
  .diff-added   .line-text {{ color: #a8f0c6; }}
  .diff-removed .line-text {{ color: #f0a8a8; }}
  .diff-context .line-text {{ color: var(--dim); }}

  /* ── Footer ── */
  .footer {{
    margin-top: 40px;
    padding-top: 16px;
    border-top: 1px solid var(--border);
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 10px;
    color: var(--dimmer);
    letter-spacing: 0.08em;
  }}
  .footer-logo {{ color: var(--green); font-family: 'Syne', sans-serif; font-weight: 700; }}

  /* ── Legend ── */
  .legend {{
    display: flex;
    gap: 20px;
    flex-wrap: wrap;
    font-size: 10px;
    color: var(--dimmer);
  }}
  .legend-item {{ display: flex; align-items: center; gap: 6px; }}
  .legend-dot {{ width: 6px; height: 6px; border-radius: 50%; }}

  /* Scrollbar */
  ::-webkit-scrollbar {{ width: 5px; }}
  ::-webkit-scrollbar-track {{ background: var(--bg); }}
  ::-webkit-scrollbar-thumb {{ background: var(--border2); border-radius: 3px; }}
</style>
</head>
<body>
<div class="wrap">

  <!-- Header -->
  <div class="header">
    <div class="logo">🌿 Gitrama</div>
    <div class="header-meta">
      <div class="header-label">gtr diff  {label_display}</div>
      <div class="header-time">{timestamp}</div>
    </div>
  </div>

  <!-- Changed Files -->
  <section class="section">
    <div class="section-header">
      <span class="section-title">Changed Files</span>
      <div class="section-rule"></div>
      <span class="section-title">{len(changed_files)} file{"s" if len(changed_files) != 1 else ""}</span>
    </div>
    {file_rows_html}
  </section>

  {coupling_html}
  {summary_html}

  <!-- Diff -->
  <section class="section">
    <div class="section-header">
      <span class="section-title">Changes</span>
      <div class="section-rule"></div>
    </div>
    {diff_html}
  </section>

  <!-- Footer -->
  <div class="footer">
    <div class="footer-logo">🌿 Gitrama</div>
    <div class="legend">
      <div class="legend-item"><div class="legend-dot" style="background:#ff4455"></div>risk ≥ 80</div>
      <div class="legend-item"><div class="legend-dot" style="background:#ffaa00"></div>risk ≥ 50</div>
      <div class="legend-item"><div class="legend-dot" style="background:#44cc88"></div>risk &lt; 50</div>
      <div class="legend-item"><div class="legend-dot" style="background:#ffaa00"></div>coupling gap</div>
    </div>
    <div>gitrama.ai</div>
  </div>

</div>
</body>
</html>"""
