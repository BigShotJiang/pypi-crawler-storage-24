"""
Gitrama - AI-powered Git workflow automation

Copyright © 2026 Gitrama LLC. All Rights Reserved.

This software is proprietary and confidential.
Unauthorized copying, distribution, or use is strictly prohibited.

Gitrama LLC
South Carolina Limited Liability Company
"""

"""
gtr diff — Risk-annotated, coupling-aware git diff.

Replaces `git diff` with context-enriched output:
  B — Risk scores per file (from last_scan.json)
  C — Coupling gap detection (files you probably should have changed)
  D — Branch summary via Intelligence Engine (/summarize_diff)

─── TODOs ────────────────────────────────────────────────────────────────────

TODO: /summarize_diff server endpoint (Feature D — required for branch summary)
  - Add POST /summarize_diff to chat_server.py on Railway
  - Payload: {"diff_payload": "<stat + commit log string>"}
  - Response: {"summary": "<plain English summary>"}
  - Forward diff_payload to Claude with a prompt like:
      "Summarize what this branch does in 3-4 plain English sentences.
       Focus on intent, not line counts. Mention: what changed, why it
       matters, any notable omissions (e.g. no migrations, no tests)."
  - Count as 2 AI requests against daily limit (same as chat message)
  - Cap payload at 8,000 chars before sending (already enforced client-side)
  - Auth: same x-gitrama-token header as /chat
  - Fallback: client already handles gracefully — shows raw stat if 4xx/5xx/timeout

TODO: Write last_scan.json after gtr scan
  - In scan.py (or wherever scan response is handled), after getting server response:
      import json, pathlib
      pathlib.Path(".gitrama").mkdir(exist_ok=True)
      with open(".gitrama/last_scan.json", "w") as f:
          json.dump(scan_response_data, f, indent=2)
  - This unlocks Features B + C without any server calls

──────────────────────────────────────────────────────────────────────────────
"""

import json
import subprocess
import sys
from pathlib import Path
from typing import Optional

import typer
import requests
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from .config import get_value
try:
    from .diff_html import open_diff_panel as _open_diff_panel
except Exception:
    _open_diff_panel = None  # Browser panel unavailable — CLI continues normally

console = Console()

# ─── Constants ────────────────────────────────────────────────────────────────

SCAN_FILE = Path(".gitrama/last_scan.json")
API_BASE_URL = "https://api.gitrama.ai"
REQUEST_TIMEOUT = 30
MAX_COUPLING_WARNINGS = 3
SUMMARY_PAYLOAD_CAP = 8000  # chars — keeps token cost sane


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _run_git(*args: str, check: bool = False) -> str:
    """Run a git command, return stdout. Returns empty string on failure."""
    try:
        result = subprocess.run(
            ["git", *args],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=30,
        )
        if check and result.returncode != 0:
            console.print(f"[red]git error: {result.stderr.strip()}[/red]")
            raise typer.Exit(1)
        return result.stdout.strip()
    except subprocess.TimeoutExpired:
        console.print("[red]git timed out.[/red]")
        raise typer.Exit(1)


def _load_scan() -> Optional[dict]:
    """Load .gitrama/last_scan.json. Returns None silently if missing."""
    if not SCAN_FILE.exists():
        return None
    try:
        with open(SCAN_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return None


def _parse_changed_files(diff_output: str) -> list[dict]:
    """
    Parse `git diff --name-status` output into a list of:
      {"status": "Modified" | "Added" | "Deleted" | "Renamed", "path": str}
    """
    files = []
    for line in diff_output.splitlines():
        line = line.strip()
        if not line:
            continue
        parts = line.split("\t", 1)
        if len(parts) < 2:
            continue
        status_code = parts[0][0].upper()
        path = parts[1].strip()
        # Handle rename (R100\told\tnew)
        if status_code == "R" and "\t" in path:
            path = path.split("\t")[-1]
        status_map = {
            "M": "Modified",
            "A": "Added",
            "D": "Deleted",
            "R": "Renamed",
            "C": "Copied",
        }
        files.append({
            "status": status_map.get(status_code, status_code),
            "path": path,
        })
    return files


# ─── Feature B: Risk Annotation ───────────────────────────────────────────────

def _get_risk_scores(scan: dict) -> dict[str, int]:
    """
    Extract {filepath: risk_score} from last_scan.json.
    Tries common scan result structures.
    """
    scores = {}
    # Try top-level "files" list
    for entry in scan.get("files", []):
        path = entry.get("path") or entry.get("file")
        score = entry.get("risk") or entry.get("risk_score") or entry.get("fragility")
        if path is not None and score is not None:
            scores[path] = int(score)
    # Try top-level "results" list
    for entry in scan.get("results", []):
        path = entry.get("path") or entry.get("file")
        score = entry.get("risk") or entry.get("risk_score") or entry.get("fragility")
        if path is not None and score is not None:
            scores[path] = int(score)
    return scores


def _risk_label(score: int) -> tuple[str, str]:
    """Returns (label_text, rich_style) for a risk score."""
    if score >= 80:
        return f"risk: {score} 🔴", "bold red"
    elif score >= 50:
        return f"risk: {score} ⚠", "bold yellow"
    else:
        return f"risk: {score}", "bold green"


def _render_annotated_files(
    files: list[dict],
    risk_scores: dict[str, int],
    changed_paths: set = None,
    show_meta: bool = True,
) -> None:
    """
    Print the changed files table with:
    - Risk annotation (Feature B)
    - Last touched by + churn rate
    - Test coverage signal
    """
    changed_paths = changed_paths or {f["path"] for f in files}
    test_warnings = []  # collect, print after the file list

    console.print()
    for f in files:
        status = f["status"]
        path = f["path"]

        # ── Status badge ──────────────────────────────────────────────────────
        status_style = {
            "Modified": "cyan",
            "Added": "green",
            "Deleted": "red",
            "Renamed": "yellow",
        }.get(status, "white")

        status_text = Text(f"  {status:<12}", style=status_style)
        path_text = Text(f"{path:<50}", style="white")

        # ── Risk score ────────────────────────────────────────────────────────
        if path in risk_scores:
            label, risk_style = _risk_label(risk_scores[path])
            risk_text = Text(f" [{label}]", style=risk_style)
        else:
            risk_text = Text(" [risk: unknown]", style="dim")

        line = status_text + path_text + risk_text
        console.print(line)

        if show_meta:
            # ── Last touched by ───────────────────────────────────────────────
            touched = _get_last_touched(path)
            if touched:
                console.print(
                    f"               [dim]last touched:[/dim] [white]{touched}[/white]"
                )

            # ── Churn rate ────────────────────────────────────────────────────
            churn = _get_churn(path)
            if churn is not None and churn > 0:
                if churn >= 20:
                    churn_style = "bold red"
                    churn_flag = " ⚡ high churn"
                elif churn >= 8:
                    churn_style = "yellow"
                    churn_flag = " ⚡"
                else:
                    churn_style = "dim"
                    churn_flag = ""
                console.print(
                    f"               [dim]churn (30d):[/dim]  "
                    f"[{churn_style}]{churn} commits{churn_flag}[/{churn_style}]"
                )

            # ── Collect test warnings — print after the list ──────────────────
            missing_test = _check_test_coverage(path, changed_paths)
            if missing_test:
                test_warnings.append((path, missing_test))

        console.print()

    # ── Test coverage warnings ─────────────────────────────────────────────────
    if test_warnings:
        console.print("  [yellow]─── Test coverage ──────────────────────────────────────[/yellow]")
        for src, test_file in test_warnings:
            console.print(
                f"  [yellow]⚠[/yellow]  [cyan]{src}[/cyan] changed"
                f" — [white]{test_file}[/white] exists but was [bold]not modified[/bold]"
            )
        console.print()




# ─── Feature: Last Touched By ─────────────────────────────────────────────────

def _get_last_touched(path: str) -> Optional[str]:
    """
    Returns "Author, N days ago" for the last commit that touched this file.
    Pure local git — no server call.
    """
    try:
        out = _run_git(
            "log", "-1", "--format=%an|%cr", "--", path
        )
        if not out:
            return None
        author, when = out.split("|", 1)
        return f"{author.strip()}, {when.strip()}"
    except Exception:
        return None


def _get_churn(path: str, days: int = 30) -> Optional[int]:
    """
    Returns how many times this file was committed in the last N days.
    Pure local git — no server call.
    """
    try:
        out = _run_git(
            "log", f"--since={days} days ago", "--oneline", "--", path
        )
        if not out:
            return 0
        return len(out.splitlines())
    except Exception:
        return None


# ─── Feature: Test Coverage Signal ───────────────────────────────────────────

# Common test file patterns to search for a given source file
_TEST_PATTERNS = [
    "tests/test_{stem}.py",
    "tests/{stem}_test.py",
    "test/test_{stem}.py",
    "test_{stem}.py",
    "{parent}/tests/test_{stem}.py",
    "{parent}/test_{stem}.py",
]


def _find_test_file(path: str) -> Optional[str]:
    """
    Given a source file path, look for a likely test file.
    Returns the test file path if found, else None.
    """
    p = Path(path)
    stem = p.stem
    parent = str(p.parent)

    for pattern in _TEST_PATTERNS:
        candidate = pattern.format(stem=stem, parent=parent)
        if Path(candidate).exists():
            return candidate
    return None


def _check_test_coverage(path: str, changed_paths: set) -> Optional[str]:
    """
    Returns a warning string if a test file exists for this path
    but was NOT included in the current diff.
    Returns None if no warning needed.
    """
    # Only check source files, not test files themselves
    if "test" in path.lower():
        return None

    test_file = _find_test_file(path)
    if test_file and test_file not in changed_paths:
        return test_file
    return None

# ─── Feature C: Coupling Gap Detection ────────────────────────────────────────

def _get_hotspot_pairs(scan: dict) -> list[dict]:
    """
    Extract co-change pairs from scan.
    Expected structure: scan["boundary_entropy"]["hotspots"] = [
      {"files": ["a.py", "b.py"], "count": 147}, ...
    ]
    Also tries scan["hotspots"] as a fallback.
    """
    hotspots = (
        scan.get("boundary_entropy", {}).get("hotspots")
        or scan.get("hotspots")
        or []
    )
    return hotspots


def _detect_coupling_gaps(
    changed_paths: set[str],
    hotspot_pairs: list[dict],
) -> list[dict]:
    """
    For each changed file, find coupling partners that were NOT changed.
    Returns up to MAX_COUPLING_WARNINGS warnings.
    """
    warnings = []

    for pair in hotspot_pairs:
        files = pair.get("files", [])
        count = pair.get("count", 0)

        if len(files) < 2:
            continue

        for i, file_a in enumerate(files):
            if file_a not in changed_paths:
                continue
            # file_a was changed — check its partners
            for file_b in files:
                if file_b == file_a:
                    continue
                if file_b not in changed_paths:
                    warnings.append({
                        "changed": file_a,
                        "missed": file_b,
                        "count": count,
                    })
                    if len(warnings) >= MAX_COUPLING_WARNINGS:
                        return warnings

    return warnings


def _render_coupling_gaps(gaps: list[dict]) -> None:
    """Print coupling gap warnings (Feature C)."""
    if not gaps:
        return

    console.print(
        "  ─── Coupling gaps — files you may have missed ───",
        style="bold yellow"
    )
    console.print()

    seen_changed = {}
    for gap in gaps:
        changed = gap["changed"]
        missed = gap["missed"]
        count = gap["count"]

        if changed not in seen_changed:
            console.print(
                f"  ⚠  [yellow]Coupling gap detected:[/yellow]\n"
                f"     You modified [cyan]{changed}[/cyan]"
                f" but did not touch its common co-change partners:"
            )
            seen_changed[changed] = True

        console.print(
            f"       → [white]{missed}[/white]"
            f"  [dim](co-changed {count}x historically)[/dim]"
        )

    console.print()


# ─── Feature D: Branch Summary ────────────────────────────────────────────────

def _build_summary_payload(base: str, head: str) -> str:
    """Build the payload for /summarize_diff — stat + commit log, capped at limit."""
    diff_stat = _run_git("diff", f"{base}..{head}", "--stat")
    commit_log = _run_git(
        "log", f"{base}..{head}", "--oneline", "--max-count=20"
    )
    raw = f"=== diff stat ===\n{diff_stat}\n\n=== commits ===\n{commit_log}"
    return raw[:SUMMARY_PAYLOAD_CAP]


def _count_range_stats(base: str, head: str) -> dict:
    """Parse --shortstat for commit count and line changes."""
    shortstat = _run_git("diff", f"{base}..{head}", "--shortstat")
    commit_count = _run_git("rev-list", "--count", f"{base}..{head}")

    files_changed = added = deleted = 0
    for part in shortstat.split(","):
        part = part.strip()
        if "file" in part:
            files_changed = int(part.split()[0])
        elif "insertion" in part:
            added = int(part.split()[0])
        elif "deletion" in part:
            deleted = int(part.split()[0])

    return {
        "commits": commit_count or "?",
        "files": files_changed,
        "added": added,
        "deleted": deleted,
    }


def _call_summarize_diff(payload: str, token: str) -> Optional[str]:
    """POST to /summarize_diff. Returns summary string or None on failure."""
    try:
        response = requests.post(
            f"{API_BASE_URL}/summarize_diff",
            headers={
                "Content-Type": "application/json",
                "x-gitrama-token": token,
            },
            json={"diff_payload": payload},
            timeout=REQUEST_TIMEOUT,
        )
        if response.status_code == 401:
            console.print("[red]Auth failed — check your GITRAMA_TOKEN.[/red]")
            return None
        if response.status_code != 200:
            return None
        data = response.json()
        return data.get("summary") or data.get("reply")
    except requests.exceptions.ConnectionError:
        return None
    except requests.exceptions.Timeout:
        return None
    except Exception:
        return None


def _render_branch_summary(base: str, head: str, stats: dict, summary: str) -> None:
    """Render the branch summary panel (Feature D)."""
    branch_line = f"Branch: {head} → {base}"
    stats_line = (
        f"Commits: {stats['commits']}   "
        f"Files changed: {stats['files']}   "
        f"+{stats['added']} / -{stats['deleted']}"
    )

    body = f"{branch_line}\n{stats_line}\n\n{summary}"

    console.print(
        Panel(
            body,
            title="[bold green]🌿 gtr diff[/bold green]",
            border_style="green",
            padding=(1, 2),
        )
    )
    console.print()



# ─── Pretty Diff Renderer ──────────────────────────────────────────────────────

import re as _re


def _parse_hunk_header(line: str) -> Optional[str]:
    match = _re.match(r'@@\s+-(\d+)(?:,(\d+))?\s+\+(\d+)(?:,(\d+))?\s+@@(.*)', line)
    if not match:
        return None

    old_start = int(match.group(1))
    old_count = int(match.group(2)) if match.group(2) is not None else 1
    new_start = int(match.group(3))
    new_count = int(match.group(4)) if match.group(4) is not None else 1
    context   = match.group(5).strip()

    added   = max(0, new_count - old_count)
    removed = max(0, old_count - new_count)

    if added and removed:
        change = f"[green]+{added} lines added[/green]  [red]-{removed} lines removed[/red]"
    elif added:
        change = f"[green]+{added} lines added[/green]"
    elif removed:
        change = f"[red]-{removed} lines removed[/red]"
    else:
        change = "[dim]lines reorganised — no net change[/dim]"

    scope = f"  [dim]inside[/dim] [bold]{context}[/bold]" if context else ""
    return f"  [dim]┄[/dim] {change}  [dim](starting at line {old_start}){scope}[/dim]"


def _render_pretty_diff(raw: str) -> None:
    for line in raw.splitlines():

        # File banner — with last touched metadata
        if line.startswith("diff --git "):
            parts = line.split(" ")
            path = parts[-1][2:] if parts[-1].startswith("b/") else parts[-1]
            touched = _get_last_touched(path)
            churn = _get_churn(path)
            console.print()
            # Build banner line
            banner = Text()
            banner.append(f"  ━━━ {path} ━━━", style="bold cyan")
            if touched:
                banner.append(f"  last touched: {touched}", style="dim")
            if churn is not None and churn > 0:
                churn_style = "bold red" if churn >= 20 else ("yellow" if churn >= 8 else "dim")
                banner.append(f"  [{churn} commits/30d]", style=churn_style)
            console.print(banner)
            continue

        # Skip noisy internal git headers
        if line.startswith("--- ") or line.startswith("+++ "):
            continue
        if line.startswith("index ") and ".." in line:
            continue

        # File mode lines
        if any(line.startswith(p) for p in (
            "new file mode", "deleted file mode", "old mode", "new mode"
        )):
            console.print(f"  [dim]{line}[/dim]")
            continue

        # Hunk header — translate @@ notation to plain English
        if line.startswith("@@ "):
            explanation = _parse_hunk_header(line)
            console.print()
            if explanation:
                console.print(explanation)
            else:
                console.print(Text(line, style="dim"))
            console.print()
            continue

        # Added line
        if line.startswith("+"):
            console.print(Text("  + " + line[1:], style="green"))
            continue

        # Removed line
        if line.startswith("-"):
            console.print(Text("  - " + line[1:], style="red"))
            continue

        # Context line (unchanged, shown for reference)
        console.print(Text("    " + line, style="dim"))


# ─── Main Command ─────────────────────────────────────────────────────────────

def diff(
    target: Optional[str] = typer.Argument(
        None,
        help="Branch, commit, or range (e.g. main, abc123, main..feature)"
    ),
    staged: bool = typer.Option(
        False, "--staged",
        help="Diff staged changes vs HEAD"
    ),
    summary: bool = typer.Option(
        False, "--summary",
        help="Show AI branch summary panel only (requires <base>..<head> range)"
    ),
):
    """
    🔍 Risk-aware, context-enriched git diff.

    Shows what changed, how risky those changes are,
    and what files you probably forgot to touch.

    \b
    EXAMPLES:
      gtr diff                    Diff working tree vs HEAD
      gtr diff --staged           Diff staged changes
      gtr diff main               Diff current branch vs main
      gtr diff abc123             Diff vs specific commit
      gtr diff main..feature      Branch summary mode (AI-powered)
      gtr diff main..feature --summary   Summary panel only
    """

    token = get_value("gitrama_token") or ""

    # ── Determine mode ────────────────────────────────────────────────────────

    is_range = target and ".." in target

    # ── Feature D: Branch/Range Summary ──────────────────────────────────────

    if is_range:
        base, _, head = target.partition("..")
        head = head or "HEAD"

        stats = _count_range_stats(base, head)
        payload = _build_summary_payload(base, head)

        with console.status("[dim]Generating branch summary...[/dim]"):
            ai_summary = _call_summarize_diff(payload, token)

        if ai_summary:
            _render_branch_summary(base, head, stats, ai_summary)
        else:
            # Graceful fallback — show raw stat only
            console.print(
                Panel(
                    f"Branch: {head} → {base}\n"
                    f"Commits: {stats['commits']}   "
                    f"Files changed: {stats['files']}   "
                    f"+{stats['added']} / -{stats['deleted']}\n\n"
                    "[dim](AI summary unavailable — server unreachable)[/dim]",
                    title="[bold green]🌿 gtr diff[/bold green]",
                    border_style="green",
                    padding=(1, 2),
                )
            )
            console.print()

        if summary:
            # --summary flag: panel only, no raw diff
            return

        # Show raw diff below the summary panel
        raw = _run_git("diff", f"{base}..{head}")
        if raw:
            console.print(raw)
        return

    # ── Build git diff args for non-range modes ───────────────────────────────

    if summary and not is_range:
        console.print(
            "[yellow]--summary requires a range: gtr diff main..feature --summary[/yellow]"
        )
        raise typer.Exit(1)

    diff_args = ["diff", "--name-status"]
    raw_diff_args = ["diff"]

    if staged:
        diff_args.append("--staged")
        raw_diff_args.append("--staged")
    elif target:
        diff_args.append(target)
        raw_diff_args.append(target)

    # ── Parse changed files ───────────────────────────────────────────────────

    name_status_out = _run_git(*diff_args)
    changed_files = _parse_changed_files(name_status_out)

    if not changed_files:
        console.print("[dim]No changes.[/dim]")
        return

    # ── Load scan data (B + C) ────────────────────────────────────────────────

    scan = _load_scan()

    if scan is None:
        # First-run: no scan file exists — auto-trigger gtr scan
        console.print(
            "[dim]No scan data found — running [bold]gtr scan[/bold] to enable risk scores...[/dim]"
        )
        try:
            subprocess.run(
                ["gtr", "scan"],
                capture_output=False,  # let scan print its own output
                text=True,
                timeout=120,
            )
            scan = _load_scan()  # reload after scan
        except FileNotFoundError:
            pass  # gtr not on PATH in some envs
        except subprocess.TimeoutExpired:
            console.print("[yellow]Scan timed out — continuing without risk scores.[/yellow]")

        if scan is None:
            # Scan ran but still no file — surface a clear one-time hint
            console.print(
                "[yellow]⚠  Run [bold]gtr scan[/bold] to enable risk scores and coupling detection.[/yellow]\n"
            )

    risk_scores = _get_risk_scores(scan) if scan else {}

    # ── Feature B: Render annotated file list ─────────────────────────────────

    changed_paths = {f["path"] for f in changed_files}
    _render_annotated_files(changed_files, risk_scores, changed_paths=changed_paths)

    # ── Feature C: Coupling gap detection ────────────────────────────────────

    if scan:
        hotspot_pairs = _get_hotspot_pairs(scan)
        if hotspot_pairs:
            gaps = _detect_coupling_gaps(changed_paths, hotspot_pairs)
            _render_coupling_gaps(gaps)

    # ── Pretty diff output ────────────────────────────────────────────────────

    raw = _run_git(*raw_diff_args)
    if raw:
        _render_pretty_diff(raw)
    # ── Browser panel ─────────────────────────────────────────────────────────
    # Runs after all CLI output is printed.
    # os.startfile() on Windows hands off to the OS immediately — near-instant.
    # join(timeout=5) keeps the process alive just long enough for the handoff.

    if _open_diff_panel:
        for f in changed_files:
            f["last_touched"] = _get_last_touched(f["path"]) or ""
            f["churn"]        = _get_churn(f["path"]) or 0
            f["test_warning"] = _check_test_coverage(f["path"], changed_paths) or ""

        gaps = []
        if scan:
            hotspot_pairs = _get_hotspot_pairs(scan)
            if hotspot_pairs:
                gaps = _detect_coupling_gaps(changed_paths, hotspot_pairs)

        diff_label = "--staged" if staged else (target or "")

        t = _open_diff_panel(
            changed_files=changed_files,
            risk_scores=risk_scores,
            raw_diff=raw or "",
            coupling_gaps=gaps,
            label=diff_label,
        )

        if t is not None:
            t.join(timeout=5.0)
