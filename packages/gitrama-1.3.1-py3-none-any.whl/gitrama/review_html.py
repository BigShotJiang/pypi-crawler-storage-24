"""
Gitrama - AI-powered Git workflow automation

Copyright © 2026 Gitrama LLC. All Rights Reserved.

This software is proprietary and confidential.
Unauthorized copying, distribution, or use is strictly prohibited.

Gitrama LLC
South Carolina Limited Liability Company
"""

"""
review_html.py — Browser panel for gtr review.

Called at the end of every `gtr review` run. Parses the AI review text,
builds a self-contained HTML panel, and opens it in the default browser.
Non-blocking — CLI continues immediately.

Flags reflected:
  --staged       default, review staged changes
  --uncommitted  review all uncommitted changes (-u)
  --quick        critical issues only (-q)
  --full         full review with suggestions (-f)

No external dependencies. Single self-contained HTML file per run.
"""

import html
import os
import re
import tempfile
import threading
import platform
from datetime import datetime
from typing import Optional


# ─── Severity parser ──────────────────────────────────────────────────────────

_SEV_PATTERNS = [
    ("critical",   r"🔴\s*SECURITY",    "🔴", "SECURITY"),
    ("critical",   r"🔴\s*CORRECTNESS", "🔴", "CORRECTNESS"),
    ("warning",    r"⚠\s*RISK",         "⚠",  "RISK"),
    ("warning",    r"⚠\s*COUPLING",     "⚠",  "COUPLING"),
    ("suggestion", r"💡\s*SUGGESTION",  "💡", "SUGGESTION"),
    ("good",       r"✓\s*GOOD",         "✓",  "GOOD"),
]

_VERDICT_PATTERNS = [
    ("ship",    r"ship it",           "✓ SHIP IT"),
    ("fix",     r"fix before merge",  "✗ FIX BEFORE MERGE"),
    ("discuss", r"needs discussion",  "⚠ NEEDS DISCUSSION"),
]

# Maps the label string passed from review.py to a human-readable mode label
_MODE_LABELS = {
    "--staged":      ("Staged Review",      "#4fc3f7"),
    "--uncommitted": ("Uncommitted Review",  "#ffaa00"),
    "--quick":       ("Quick Review",        "#44cc88"),
    "--full":        ("Full Review",         "#c084fc"),
}


def _parse_findings(review_text: str) -> list[dict]:
    """
    Parse AI review text into structured finding blocks.
    Splits on emoji severity markers.
    """
    findings = []
    pattern = r'(?=(?:🔴|⚠|💡|✓)\s*(?:SECURITY|CORRECTNESS|RISK|COUPLING|SUGGESTION|GOOD))'
    blocks = re.split(pattern, review_text.strip())

    for block in blocks:
        block = block.strip()
        if not block:
            continue

        severity = "suggestion"
        icon     = "💡"
        label    = ""

        for sev, pat, ico, lbl in _SEV_PATTERNS:
            if re.match(pat, block, re.IGNORECASE):
                severity = sev
                icon     = ico
                label    = lbl
                break

        # Strip the severity prefix from the body
        body = re.sub(r'^[🔴⚠💡✓]\s*\w+\s*', '', block, count=1).strip()

        # Extract file:line reference
        file_ref  = ""
        line_ref  = ""
        file_match = re.search(r'([a-zA-Z0-9_/\\.-]+\.py)(?::(\d+))?', body)
        if file_match:
            file_ref = file_match.group(1)
            line_ref = file_match.group(2) or ""

        # First sentence = title, rest = detail
        sentences = re.split(r'(?<=[.!?])\s+', body, maxsplit=1)
        title  = sentences[0].strip() if sentences else body
        detail = sentences[1].strip() if len(sentences) > 1 else ""

        # Suggestion after → arrow
        suggestion = ""
        if "→" in detail:
            parts      = detail.split("→", 1)
            detail     = parts[0].strip()
            suggestion = parts[1].strip()
        elif "→" in body:
            parts      = body.split("→", 1)
            suggestion = parts[1].strip()

        findings.append({
            "severity":   severity,
            "icon":       icon,
            "label":      label,
            "title":      title[:120],
            "detail":     detail,
            "suggestion": suggestion,
            "file":       file_ref,
            "line":       line_ref,
        })

    return findings


def _parse_verdict(review_text: str) -> dict:
    """Extract verdict, detail sentence, and suggested commit from review text."""
    text_lower = review_text.lower()

    status = "discuss"
    label  = "⚠ NEEDS DISCUSSION"
    for s, pat, lbl in _VERDICT_PATTERNS:
        if re.search(pat, text_lower):
            status = s
            label  = lbl
            break

    # Suggested commit message
    commit = ""
    commit_match = re.search(
        r'(?:suggested commit[:\s]+|commit message[:\s]+)`?([^\n`]+)`?',
        review_text, re.IGNORECASE
    )
    if commit_match:
        commit = commit_match.group(1).strip()

    # Verdict detail — first line containing a verdict keyword
    detail = ""
    for line in review_text.splitlines():
        if any(re.search(pat, line.lower()) for _, pat, _ in _VERDICT_PATTERNS):
            detail = line.strip()
            break

    return {"status": status, "label": label, "detail": detail, "commit": commit}


# ─── Public entry point ───────────────────────────────────────────────────────

def open_review_panel(
    review_text: str,
    changed_files: list[dict],
    risk_scores: dict[str, int],
    label: str = "",
) -> Optional[threading.Thread]:
    """
    Build and open the gtr review browser panel.
    label is one of: --staged | --uncommitted | --quick | --full
    Returns the thread so the caller can join(timeout=5.0).
    """
    findings = _parse_findings(review_text)
    verdict  = _parse_verdict(review_text)

    html_content = _build_html(
        review_text   = review_text,
        findings      = findings,
        verdict       = verdict,
        changed_files = changed_files,
        risk_scores   = risk_scores,
        label         = label,
    )

    def _write_and_open():
        fd, path = tempfile.mkstemp(suffix=".html", prefix="gtr_review_")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(html_content)
        except Exception:
            return
        try:
            _launch_browser(path)
        except Exception:
            try:
                os.unlink(path)
            except OSError:
                pass

    t = threading.Thread(target=_write_and_open, daemon=True)
    t.start()
    return t


def _launch_browser(path: str) -> None:
    import subprocess as _sp
    system = platform.system()

    if system == "Windows":
        try:
            os.startfile(path)  # type: ignore[attr-defined]
            return
        except Exception:
            pass
        try:
            _sp.Popen(["cmd", "/c", "start", "", path],
                      shell=False, stdout=_sp.DEVNULL, stderr=_sp.DEVNULL)
            return
        except Exception:
            pass

    if system == "Darwin":
        try:
            _sp.Popen(["open", path], stdout=_sp.DEVNULL, stderr=_sp.DEVNULL)
            return
        except Exception:
            pass

    if system == "Linux":
        for cmd in ("xdg-open", "sensible-browser", "x-www-browser"):
            try:
                _sp.Popen([cmd, path], stdout=_sp.DEVNULL, stderr=_sp.DEVNULL)
                return
            except FileNotFoundError:
                continue

    import webbrowser
    from urllib.request import pathname2url
    webbrowser.open("file://" + pathname2url(os.path.abspath(path)))


# ─── Data helpers ─────────────────────────────────────────────────────────────

def _risk_info(score: Optional[int]) -> dict:
    if score is None:
        return {"label": "unknown", "color": "#3d5a70"}
    if score >= 80:
        return {"label": f"{score} 🔴", "color": "#ff4455"}
    if score >= 50:
        return {"label": f"{score} ⚠",  "color": "#ffaa00"}
    return {"label": str(score),         "color": "#44cc88"}


def _status_color(status: str) -> str:
    return {
        "Modified": "#4fc3f7",
        "Added":    "#44cc88",
        "Deleted":  "#ff5566",
        "Renamed":  "#ffaa00",
    }.get(status, "#e8eaf0")


_SEV_STYLES = {
    "critical":   {"bg": "#1a0a0a", "border": "#ff4455", "accent": "#ff4455", "dim": "#3a1a1a"},
    "warning":    {"bg": "#1a1400", "border": "#ffaa00", "accent": "#ffaa00", "dim": "#3a2a00"},
    "suggestion": {"bg": "#0a0f1a", "border": "#4fc3f7", "accent": "#4fc3f7", "dim": "#1a2a4a"},
    "good":       {"bg": "#0a1a0f", "border": "#44cc88", "accent": "#44cc88", "dim": "#1a3a22"},
}

_VERDICT_STYLES = {
    "ship":    {"bg": "#0a1a0f", "border": "#44cc88", "text": "#44cc88"},
    "fix":     {"bg": "#1a0a0a", "border": "#ff4455", "text": "#ff4455"},
    "discuss": {"bg": "#1a1400", "border": "#ffaa00", "text": "#ffaa00"},
}


# ─── HTML builder ─────────────────────────────────────────────────────────────

def _build_html(
    review_text: str,
    findings: list[dict],
    verdict: dict,
    changed_files: list[dict],
    risk_scores: dict[str, int],
    label: str,
) -> str:

    timestamp = datetime.now().strftime("%b %d, %Y  %H:%M")

    # ── Mode label ────────────────────────────────────────────────────────────
    mode_text, mode_color = _MODE_LABELS.get(label, ("Code Review", "#4fc3f7"))
    label_display = html.escape(label) if label else "--staged"

    # ── Severity badge counts ─────────────────────────────────────────────────
    counts = {}
    for f in findings:
        counts[f["severity"]] = counts.get(f["severity"], 0) + 1

    badge_html = ""
    for sev, color, lbl in [
        ("critical",   "#ff4455", "Critical"),
        ("warning",    "#ffaa00", "Warning"),
        ("suggestion", "#4fc3f7", "Suggestion"),
        ("good",       "#44cc88", "Good"),
    ]:
        if counts.get(sev):
            badge_html += f"""
            <div class="sev-badge" style="color:{color};background:{color}12;border-color:{color}30">
              <span class="sev-count">{counts[sev]}</span>
              <span class="sev-label">{lbl}</span>
            </div>"""

    # ── File rows ─────────────────────────────────────────────────────────────
    file_rows_html = ""
    for i, f in enumerate(changed_files):
        path    = f["path"]
        status  = f["status"]
        score   = risk_scores.get(path)
        risk    = _risk_info(score)
        churn   = f.get("churn", 0)
        touched = f.get("last_touched", "") or f.get("touched", "")
        test_warn = f.get("test_warning", "")

        churn_html = ""
        if churn >= 8:
            churn_color = "#ff4455" if churn >= 20 else "#ffaa00"
            churn_html = f'<span class="file-churn" style="color:{churn_color}">{churn} commits/30d{"⚡" if churn >= 20 else ""}</span>'

        touched_html = ""
        if touched:
            touched_html = f'<span class="file-touched">⏱ {html.escape(touched)}</span>'

        test_html = ""
        if test_warn:
            test_html = f'<span class="file-test-warn">⚠ test not updated</span>'

        file_rows_html += f"""
        <div class="file-row" style="animation-delay:{i * 0.06}s">
          <span class="file-status" style="color:{_status_color(status)}">{html.escape(status)}</span>
          <span class="file-path">{html.escape(path)}</span>
          <div class="file-badges">
            <span class="risk-badge" style="color:{risk['color']};border-color:{risk['color']}33;background:{risk['color']}0e">
              risk: {html.escape(risk['label'])}
            </span>
            {churn_html}
            {touched_html}
            {test_html}
          </div>
        </div>"""

    # ── Finding cards ─────────────────────────────────────────────────────────
    findings_html = ""
    for i, f in enumerate(findings):
        sev   = _SEV_STYLES.get(f["severity"], _SEV_STYLES["suggestion"])
        delay = i * 0.07

        file_ref_html = ""
        if f["file"]:
            ref = html.escape(f["file"])
            ref += f":{f['line']}" if f["line"] else ""
            file_ref_html = f'<span class="finding-file">{ref}</span>'

        detail_html = f'<div class="finding-detail">{html.escape(f["detail"])}</div>' if f["detail"] else ""
        sug_html    = f'<div class="finding-suggestion">→ {html.escape(f["suggestion"])}</div>' if f["suggestion"] else ""

        # Critical findings start expanded
        expanded_class = "expanded" if f["severity"] == "critical" else ""

        findings_html += f"""
        <div class="finding-card {expanded_class}"
             style="background:{sev['bg']};border-color:{sev['dim']};border-left-color:{sev['border']};animation-delay:{delay}s"
             onclick="this.classList.toggle('expanded')">
          <div class="finding-header">
            <span class="finding-icon">{f['icon']}</span>
            <div class="finding-meta">
              <div class="finding-top">
                <span class="finding-label" style="color:{sev['accent']}">{html.escape(f['label'])}</span>
                {file_ref_html}
              </div>
              <div class="finding-title">{html.escape(f['title'])}</div>
            </div>
            <span class="finding-chevron">▶</span>
          </div>
          <div class="finding-body">
            {detail_html}
            {sug_html}
          </div>
        </div>"""

    # ── Verdict ───────────────────────────────────────────────────────────────
    vs = _VERDICT_STYLES.get(verdict["status"], _VERDICT_STYLES["discuss"])
    commit_html = ""
    if verdict["commit"]:
        commit_html = f"""
        <div class="commit-box">
          <div class="commit-label">Suggested commit</div>
          <div class="commit-msg">{html.escape(verdict['commit'])}</div>
        </div>"""

    verdict_detail = verdict["detail"] or "Review the findings above before merging."
    verdict_html = f"""
    <div class="verdict-panel" style="background:{vs['bg']};border-color:{vs['border']}44;border-left-color:{vs['border']}">
      <div class="verdict-status" style="color:{vs['text']}">{html.escape(verdict['label'])}</div>
      <div class="verdict-detail">{html.escape(verdict_detail)}</div>
      {commit_html}
    </div>"""

    # ── Raw fallback (if parser found nothing) ────────────────────────────────
    raw_html = ""
    if not findings:
        raw_html = f"""
        <div class="raw-review">
          <pre>{html.escape(review_text)}</pre>
        </div>"""

    file_count = len(changed_files)
    finding_count = len(findings)

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>gtr review — {label_display}</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=DM+Mono:ital,wght@0,400;0,500;1,400&family=Bebas+Neue&display=swap');

  *, *::before, *::after {{ box-sizing: border-box; margin: 0; padding: 0; }}

  :root {{
    --bg:      #020c14;
    --surface: #040e18;
    --border:  #0a1a28;
    --border2: #0f2030;
    --green:   #44cc88;
    --red:     #ff4455;
    --yellow:  #ffaa00;
    --cyan:    #4fc3f7;
    --purple:  #c084fc;
    --dim:     #3d5a70;
    --dimmer:  #1a3a5a;
    --text:    #c8d8e8;
    --meta:    #5a7a8a;
  }}

  html {{ scroll-behavior: smooth; }}

  body {{
    background: var(--bg);
    color: var(--text);
    font-family: 'DM Mono', 'Fira Code', monospace;
    font-size: 13px;
    line-height: 1.6;
    min-height: 100vh;
    padding: 32px 24px 72px;
  }}

  /* CRT scanline overlay */
  body::before {{
    content: '';
    position: fixed; inset: 0; pointer-events: none; z-index: 1000;
    background: repeating-linear-gradient(
      0deg, transparent, transparent 2px,
      rgba(0,0,0,0.025) 2px, rgba(0,0,0,0.025) 4px
    );
  }}

  .wrap {{ max-width: 920px; margin: 0 auto; }}

  /* ── Header ── */
  .header {{
    display: flex; align-items: center; justify-content: space-between;
    flex-wrap: wrap; gap: 12px;
    margin-bottom: 28px; padding-bottom: 16px;
    border-bottom: 1px solid var(--border);
  }}
  .logo-group {{ display: flex; align-items: baseline; gap: 14px; }}
  .logo {{
    font-family: 'Bebas Neue', sans-serif;
    font-size: 22px; letter-spacing: 0.15em; color: var(--green);
  }}
  .logo-sub {{
    font-size: 9px; color: var(--dimmer);
    letter-spacing: 0.22em; text-transform: uppercase;
  }}
  .header-right {{ display: flex; flex-direction: column; gap: 5px; text-align: right; }}
  .header-mode {{
    font-size: 11px; font-weight: 700;
    letter-spacing: 0.1em; color: {mode_color};
  }}
  .header-cmd  {{ font-size: 10px; color: var(--dimmer); font-family: monospace; }}
  .header-time {{ font-size: 10px; color: var(--dimmer); }}

  /* ── Section headers ── */
  .section {{ margin-bottom: 24px; }}
  .section-head {{
    display: flex; align-items: center; gap: 12px; margin-bottom: 12px;
  }}
  .section-title {{
    font-size: 9px; color: var(--dimmer);
    letter-spacing: 0.22em; text-transform: uppercase; white-space: nowrap;
  }}
  .section-rule {{ flex: 1; height: 1px; background: linear-gradient(90deg, var(--border2), transparent); }}
  .section-count {{ font-size: 9px; color: var(--dimmer); }}

  /* ── Severity badges (header) ── */
  .badge-row {{ display: flex; gap: 8px; flex-wrap: wrap; }}
  .sev-badge {{
    display: flex; align-items: center; gap: 6px;
    font-size: 10px; border: 1px solid; border-radius: 4px; padding: 3px 10px;
  }}
  .sev-count {{ font-weight: 700; font-size: 13px; }}
  .sev-label {{ opacity: 0.7; letter-spacing: 0.05em; }}

  /* ── File rows ── */
  .file-table {{
    background: var(--surface); border: 1px solid var(--border2);
    border-radius: 8px; overflow: hidden;
  }}
  .file-row {{
    display: flex; align-items: center; flex-wrap: wrap; gap: 8px;
    padding: 10px 16px;
    border-bottom: 1px solid var(--border);
    opacity: 0; animation: slideIn 0.35s ease forwards;
  }}
  .file-row:last-child {{ border-bottom: none; }}
  @keyframes slideIn {{
    from {{ opacity:0; transform:translateX(-10px); }}
    to   {{ opacity:1; transform:translateX(0); }}
  }}
  .file-status  {{ font-size: 11px; font-weight: 500; min-width: 74px; }}
  .file-path    {{ font-size: 12px; color: var(--text); flex: 1; min-width: 180px; }}
  .file-badges  {{ display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }}
  .risk-badge   {{
    font-size: 10px; font-weight: 700; padding: 1px 8px;
    border: 1px solid; border-radius: 3px;
  }}
  .file-churn     {{ font-size: 10px; font-weight: 600; }}
  .file-touched   {{ font-size: 10px; color: var(--dim); }}
  .file-test-warn {{ font-size: 10px; color: var(--yellow); }}

  /* ── Finding cards ── */
  .finding-card {{
    margin-bottom: 8px;
    border: 1px solid; border-left: 3px solid;
    border-radius: 6px; overflow: hidden;
    cursor: pointer;
    opacity: 0; animation: slideIn 0.35s ease forwards;
    transition: box-shadow 0.2s;
  }}
  .finding-card:hover {{ box-shadow: 0 4px 24px rgba(0,0,0,0.5); }}

  .finding-header {{
    display: flex; align-items: flex-start; gap: 12px;
    padding: 12px 16px;
  }}
  .finding-icon    {{ font-size: 15px; line-height: 1; padding-top: 1px; flex-shrink: 0; }}
  .finding-meta    {{ flex: 1; min-width: 0; }}
  .finding-top     {{ display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin-bottom: 4px; }}
  .finding-label   {{
    font-size: 9px; font-weight: 700;
    letter-spacing: 0.18em; text-transform: uppercase;
  }}
  .finding-file    {{ font-size: 10px; color: var(--dim); font-family: monospace; }}
  .finding-title   {{ font-size: 12.5px; color: var(--text); line-height: 1.4; font-weight: 500; }}
  .finding-chevron {{
    color: var(--dimmer); font-size: 10px; padding-top: 2px; flex-shrink: 0;
    transition: transform 0.2s ease;
  }}

  /* Expand/collapse body */
  .finding-body {{
    max-height: 0; overflow: hidden;
    transition: max-height 0.25s ease, padding 0.25s ease;
    padding: 0 16px 0 43px;
  }}
  .finding-card.expanded .finding-body {{
    max-height: 500px;
    padding: 0 16px 14px 43px;
  }}
  .finding-card.expanded .finding-chevron {{ transform: rotate(90deg); }}

  .finding-detail {{
    font-size: 11.5px; color: var(--meta); line-height: 1.75;
    padding-top: 12px;
    border-top: 1px solid rgba(255,255,255,0.04);
    margin-bottom: 10px;
  }}
  .finding-suggestion {{
    font-size: 11px; color: var(--green); line-height: 1.6;
    background: #0a1a10; border: 1px solid #1a3a22;
    border-radius: 4px; padding: 8px 12px;
  }}

  /* ── Verdict ── */
  .verdict-panel {{
    border: 1px solid; border-left-width: 4px;
    border-radius: 8px; padding: 20px 24px;
    animation: fadeUp 0.5s ease 0.3s both;
  }}
  @keyframes fadeUp {{
    from {{ opacity:0; transform:translateY(10px); }}
    to   {{ opacity:1; transform:translateY(0); }}
  }}
  .verdict-status {{
    font-size: 13px; font-weight: 700;
    letter-spacing: 0.12em; margin-bottom: 10px;
  }}
  .verdict-detail {{
    font-size: 12px; color: var(--meta); line-height: 1.75; margin-bottom: 18px;
  }}
  .commit-box {{
    background: var(--bg); border: 1px solid var(--border2);
    border-radius: 5px; padding: 10px 14px;
  }}
  .commit-label {{
    font-size: 9px; color: var(--dimmer);
    letter-spacing: 0.18em; text-transform: uppercase; margin-bottom: 7px;
  }}
  .commit-msg {{ font-family: monospace; font-size: 12px; color: var(--green); word-break: break-all; }}

  /* ── Raw fallback ── */
  .raw-review {{
    background: var(--surface); border: 1px solid var(--border2);
    border-radius: 8px; padding: 20px;
  }}
  .raw-review pre {{
    font-family: monospace; font-size: 12px;
    color: var(--text); white-space: pre-wrap; line-height: 1.7;
  }}

  /* ── Footer ── */
  .footer {{
    margin-top: 40px; padding-top: 16px;
    border-top: 1px solid var(--border);
    display: flex; justify-content: space-between; align-items: center;
    flex-wrap: wrap; gap: 12px;
    font-size: 9px; color: var(--dimmer); letter-spacing: 0.1em;
  }}
  .footer-logo {{
    color: var(--green);
    font-family: 'Bebas Neue', sans-serif;
    font-size: 13px; letter-spacing: 0.15em;
  }}

  ::-webkit-scrollbar {{ width: 5px; }}
  ::-webkit-scrollbar-track {{ background: var(--bg); }}
  ::-webkit-scrollbar-thumb {{ background: var(--border2); border-radius: 3px; }}
</style>
</head>
<body>
<div class="wrap">

  <!-- Header -->
  <div class="header">
    <div class="logo-group">
      <div class="logo">🌿 GITRAMA</div>
      <div class="logo-sub">Code Review</div>
    </div>
    <div class="badge-row">{badge_html}</div>
    <div class="header-right">
      <div class="header-mode">{mode_text}</div>
      <div class="header-cmd">gtr review {label_display}</div>
      <div class="header-time">{timestamp}</div>
    </div>
  </div>

  <!-- Files Under Review -->
  <div class="section">
    <div class="section-head">
      <span class="section-title">Files Under Review</span>
      <div class="section-rule"></div>
      <span class="section-count">{file_count} file{"s" if file_count != 1 else ""}</span>
    </div>
    <div class="file-table">{file_rows_html}</div>
  </div>

  <!-- Findings -->
  <div class="section">
    <div class="section-head">
      <span class="section-title">Review Findings</span>
      <div class="section-rule"></div>
      <span class="section-count">{finding_count} finding{"s" if finding_count != 1 else ""}</span>
    </div>
    {findings_html if findings_html else raw_html}
  </div>

  <!-- Verdict -->
  <div class="section">
    <div class="section-head">
      <span class="section-title">Verdict</span>
      <div class="section-rule"></div>
    </div>
    {verdict_html}
  </div>

  <!-- Footer -->
  <div class="footer">
    <div class="footer-logo">🌿 GITRAMA</div>
    <div>🔴 security · correctness &nbsp;&nbsp;⚠ risk · coupling &nbsp;&nbsp;💡 suggestion &nbsp;&nbsp;✓ good</div>
    <div>gitrama.ai &nbsp;·&nbsp; v1.3.1</div>
  </div>

</div>
</body>
</html>"""