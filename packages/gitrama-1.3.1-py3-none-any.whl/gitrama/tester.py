import re
test = "Here's the full list:\n[EXECUTE: git branch -a]"
print(re.findall(r'\[EXECUTE:\s*([^\]]+)\]', test))
# Should print: ['git branch -a']