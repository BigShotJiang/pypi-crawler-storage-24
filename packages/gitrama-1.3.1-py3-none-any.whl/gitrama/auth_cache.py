"""
gitrama/auth_cache.py
=====================
Local token validation cache for the Gitrama CLI.

Validates once per hour max. All gtr commands call
`get_valid_auth()` instead of hitting /auth/validate
on every invocation.

Author:  Alfonso Harding Jr
Company: Gitrama LLC
"""

import hashlib
import json
import os
import threading
import time
from typing import Optional

import httpx

from .config import (
    PROVISIONING_URL,
    CONFIG_PATH,
    CACHE_TTL,
    GRACE_PERIOD,
    TIMEOUT_AUTH,
)


# ═══════════════════════════════════════════════════════════
# CONFIG I/O
# ═══════════════════════════════════════════════════════════

def _read_config() -> dict:
    try:
        if CONFIG_PATH.exists():
            with open(CONFIG_PATH) as f:
                return json.load(f)
    except Exception:
        pass
    return {}


def _write_config(config: dict) -> None:
    try:
        CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(CONFIG_PATH, "w") as f:
            json.dump(config, f, indent=2)
    except Exception:
        pass


def load_token() -> Optional[str]:
    """Load token from config or environment."""
    cfg = _read_config()
    return cfg.get("token") or cfg.get("gitrama_token") or os.environ.get("GITRAMA_TOKEN")


# ═══════════════════════════════════════════════════════════
# CACHE STRUCTURE
# ═══════════════════════════════════════════════════════════
#
# Stored in ~/.gitrama/config.json under "auth_cache":
#
# {
#   "token_hash":   "sha256 of the token (to detect token changes)",
#   "valid":        true,
#   "tier":         "free",
#   "user_id":      "uuid",
#   "email":        "user@example.com",
#   "first_name":   "Alfonso",
#   "daily_limit":  50,
#   "daily_used":   12,
#   "cached_at":    1741234567,    # unix timestamp
#   "usage_date":   "2026-03-05"   # date the usage count belongs to
# }
#
# daily_used is fetched from server on each real validate call.
# Between calls the CLI increments it locally so the count stays
# roughly accurate without a server round trip.
# ═══════════════════════════════════════════════════════════

def _token_hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()[:16]


def _load_cache(token: str) -> Optional[dict]:
    """
    Load cached auth data if:
    - cache exists
    - token hasn't changed
    - cache is not expired
    - usage_date matches today (resets daily count)
    """
    config = _read_config()
    cache = config.get("auth_cache")
    if not cache:
        return None

    # Token changed — cache invalid
    if cache.get("token_hash") != _token_hash(token):
        return None

    # Cache expired
    age = time.time() - cache.get("cached_at", 0)
    if age > CACHE_TTL:
        return None

    # New day — daily_used resets, force re-validate to get fresh count
    today = time.strftime("%Y-%m-%d")
    if cache.get("usage_date") != today:
        return None

    return cache


def _save_cache(token: str, server_response: dict) -> None:
    """Persist validated auth data to config."""
    today = time.strftime("%Y-%m-%d")
    config = _read_config()
    config["auth_cache"] = {
        "token_hash":  _token_hash(token),
        "valid":       server_response.get("valid", False),
        "tier":        server_response.get("tier", "free"),
        "user_id":     server_response.get("user_id"),
        "email":       server_response.get("email"),
        "first_name":  server_response.get("first_name"),
        "daily_limit": server_response.get("daily_limit", 50),
        "daily_used":  server_response.get("daily_used", 0),
        "cached_at":   int(time.time()),
        "usage_date":  today,
    }
    _write_config(config)


def flush_cache() -> None:
    """
    Flush the auth cache. Called when:
    - Token changes (gtr setup)
    - Server returns 401
    - gtr health (force re-validate)
    - Daily limit hit
    """
    config = _read_config()
    config.pop("auth_cache", None)
    _write_config(config)


def increment_local_usage(cost: int = 1) -> None:
    """
    Increment daily_used in the local cache after a command runs.
    Keeps the count roughly accurate without a server round trip.
    Called by every command after successful execution.
    """
    config = _read_config()
    cache = config.get("auth_cache")
    if cache and cache.get("usage_date") == time.strftime("%Y-%m-%d"):
        cache["daily_used"] = cache.get("daily_used", 0) + cost
        _write_config(config)


# ═══════════════════════════════════════════════════════════
# SERVER VALIDATION
# ═══════════════════════════════════════════════════════════

def _validate_with_server(token: str) -> dict:
    """
    Call /auth/validate on the provisioning server.
    Returns the response dict, or an error dict on failure.
    """
    try:
        with httpx.Client(timeout=TIMEOUT_AUTH) as client:
            resp = client.post(
                f"{PROVISIONING_URL}/auth/validate",
                json={"token": token},
            )
        if resp.status_code == 200:
            return resp.json()
        if resp.status_code == 401:
            flush_cache()
            return {"valid": False, "message": "Invalid or expired token."}
        return {"valid": False, "message": f"Server error: HTTP {resp.status_code}"}
    except httpx.TimeoutException:
        return {"valid": False, "message": "Validation timed out. Check your connection.", "_network_error": True}
    except httpx.ConnectError:
        return {"valid": False, "message": "Cannot reach provisioning server.", "_network_error": True}
    except Exception as e:
        return {"valid": False, "message": str(e), "_network_error": True}


def _refresh_in_background(token: str) -> None:
    """
    Fire-and-forget background thread to refresh the cache.
    Called when cache is stale but still within grace period.
    The current command proceeds immediately; next command gets fresh cache.
    """
    def _refresh():
        result = _validate_with_server(token)
        if result.get("valid"):
            _save_cache(token, result)

    t = threading.Thread(target=_refresh, daemon=True)
    t.start()


# ═══════════════════════════════════════════════════════════
# MAIN PUBLIC API
# ═══════════════════════════════════════════════════════════

# Grace period: cache expired but not by more than this → use stale
# cache and refresh in background. Avoids blocking the CLI during
# brief network hiccups.


def get_valid_auth(force: bool = False) -> dict:
    """
    Get validated auth data. Uses cache when fresh, validates with
    server when stale, uses stale cache + background refresh during
    grace period.

    Returns a dict with:
      valid:        bool
      tier:         str  ("free" | "pro" | "enterprise")
      user_id:      str
      email:        str
      first_name:   str
      daily_limit:  int
      daily_used:   int
      message:      str
      _from_cache:  bool  (True if served from cache)

    On failure (invalid token, no connection after grace period):
      valid: False
      message: str describing the problem
    """
    token = load_token()

    # ── No token configured ──
    if not token:
        return {
            "valid": False,
            "message": "no_token",
            "_from_cache": False,
        }

    # ── Force re-validate (gtr health, post-limit-hit) ──
    if force:
        result = _validate_with_server(token)
        if result.get("valid"):
            _save_cache(token, result)
        else:
            flush_cache()
        result["_from_cache"] = False
        return result

    # ── Check cache ──
    cache = _load_cache(token)
    if cache:
        cache["_from_cache"] = True
        return cache

    # ── Cache expired — check grace period ──
    config = _read_config()
    existing = config.get("auth_cache", {})
    if existing and existing.get("token_hash") == _token_hash(token):
        age = time.time() - existing.get("cached_at", 0)
        if age <= CACHE_TTL + GRACE_PERIOD:
            # Stale but within grace — use it, refresh in background
            _refresh_in_background(token)
            existing["_from_cache"] = True
            existing["_stale"] = True
            return existing

    # ── No usable cache — validate with server ──
    result = _validate_with_server(token)

    if result.get("_network_error"):
        # Network is down — if we have ANY cached data for this token, use it
        if existing and existing.get("token_hash") == _token_hash(token):
            existing["_from_cache"] = True
            existing["_offline"] = True
            return existing
        # No cache at all and no network — fail gracefully
        return result

    if result.get("valid"):
        _save_cache(token, result)
    else:
        flush_cache()

    result["_from_cache"] = False
    return result


# ═══════════════════════════════════════════════════════════
# CONVENIENCE HELPERS
# ═══════════════════════════════════════════════════════════

def check_limit(cost: int = 1) -> tuple[bool, str]:
    """
    Check if the user has enough daily quota for a command.

    Returns:
      (True, "")                    — quota available, proceed
      (False, "limit_reached")     — daily limit hit
      (False, "trial_expired")     — 30-day trial ended + low limit
      (False, "no_token")          — not authenticated
      (False, "invalid_token")     — token rejected by server
    """
    auth = get_valid_auth()

    if not auth.get("valid"):
        msg = auth.get("message", "")
        if msg == "no_token":
            return False, "no_token"
        return False, "invalid_token"

    daily_used  = auth.get("daily_used", 0)
    daily_limit = auth.get("daily_limit", 50)

    if daily_used + cost > daily_limit:
        # Distinguish trial-expired (limit dropped to 10) vs regular limit
        if daily_limit == 10:
            return False, "trial_expired"
        return False, "limit_reached"

    return True, ""


def get_tier() -> str:
    """Return current tier string. Defaults to 'free' on any error."""
    auth = get_valid_auth()
    return auth.get("tier", "free")