# gitrama/trial.py
"""
Trial / token status check — called at gtr startup.
Hits the provisioning server, shows remaining-day warnings.
Silent fail on network errors (never block the user for infra issues).
"""

import os
import sys
import requests
from datetime import datetime, timezone
from .config import get_value
from rich.console import Console

console = Console()
PROVISIONING_URL = "https://provisioning.gitrama.ai"
VALIDATE_ENDPOINT = f"{PROVISIONING_URL}/auth/validate"


def check_trial_status(silent: bool = False) -> dict | None:
    """
    Validate GITRAMA_TOKEN against provisioning server.
    Called at gtr startup. Shows warnings, hard-blocks on expired trial.
    Returns the validate response dict, or None if no token / network error.
    """
    token = (
                get_value("gitrama_token") 
                or get_value("GITRAMA_TOKEN") 
                or os.environ.get("GITRAMA_TOKEN") 
                or ""
            ).strip()
    
    if not token:
        return None  # unauthenticated — silent pass

    try:
        resp = requests.post(
            VALIDATE_ENDPOINT,
            json={"token": token},
            timeout=4
        )
        resp.raise_for_status()
        data = resp.json()
    except Exception:
        return None  # network error — never block the user

    if not data.get("valid"):
        if not silent:
            msg = data.get("message", "Token invalid")
            print(f"\n  ⚠️  Gitrama: {msg}")
            if "expired" in msg.lower():
                print(f"     Upgrade at gitrama.ai/pro — or continue with 30 requests/day free.\n")
                sys.exit(1)   # ← hard block on expired trial
            else:
                print(f"     Run `gtr setup` or visit gitrama.ai/account\n")
    return data

    # ── Trial expiry warning (4-day banner) ──────────────────────────────
    warning = data.get("warning")
    if warning and not silent:
        print(f"\n  🌿 {warning}\n")

    # ── Daily limit ───────────────────────────────────────────────────────
    tier        = data.get("tier", "free")
    daily_used  = data.get("daily_used", 0)
    daily_limit = data.get("daily_limit", 50)
    remaining   = daily_limit - daily_used

    if not silent:
        if daily_used >= daily_limit:
            print(f"\n  ❌ Daily limit reached ({daily_limit} requests used today).")
            print(f"     Resets at midnight UTC.  Upgrade at gitrama.ai/pro\n")
            sys.exit(1)
        elif tier == "free" and remaining <= 10:
            print(f"  ⚠️  {remaining} free requests remaining today — gitrama.ai/pro\n")

    return data


def show_account_info():
    """
    gtr account — print tier, usage, expiry, and upgrade info.
    """
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel

    console = Console()

    token = get_value("gitrama_token") or get_value("GITRAMA_TOKEN") or os.environ.get("GITRAMA_TOKEN") or ""
    if not token:
        console.print(Panel(
            "[yellow]No gitrama_token found.[/yellow]\n\n"
            "Sign up free at [bold]gitrama.ai[/bold] then set:\n"
            "  [bold]export gitrama_token=your_token[/bold]",
            title="🌿 Gitrama Account",
            border_style="yellow"
        ))
        return

    try:
        resp = requests.post(VALIDATE_ENDPOINT, json={"token": token}, timeout=4)
        resp.raise_for_status()
        data = resp.json()
    except Exception:
        console.print("[red]❌ Could not reach Gitrama servers. Check your connection.[/red]")
        return

    if not data.get("valid"):
        console.print(Panel(
            f"[red]{data.get('message', 'Token invalid')}[/red]\n\n"
            "Run [bold]gtr setup[/bold] or visit [bold]gitrama.ai/account[/bold]",
            title="🌿 Gitrama Account",
            border_style="red"
        ))
        return

    tier        = data.get("tier", "free").upper()
    daily_used  = data.get("daily_used", 0)
    daily_limit = data.get("daily_limit", 50)
    remaining   = daily_limit - daily_used
    email       = data.get("email", "—")
    first_name  = data.get("first_name", "")
    expires_at  = data.get("expires_at")
    warning     = data.get("warning")

    # ── Days remaining ────────────────────────────────────────────────────
    days_left_str = None
    if expires_at:
        try:
            expires = datetime.fromisoformat(expires_at)
            if expires.tzinfo is None:
                expires = expires.replace(tzinfo=timezone.utc)
            days_left = (expires - datetime.now(timezone.utc)).days
            days_left_str = (
                f"{days_left} days"
                if days_left > 0
                else "[red]Expired[/red]"
            )
        except Exception:
            pass

    # ── Usage bar ─────────────────────────────────────────────────────────
    pct = daily_used / daily_limit if daily_limit else 0
    bar_filled = int(pct * 20)
    bar_color = "green" if pct < 0.8 else "yellow" if pct < 1.0 else "red"
    usage_bar = f"[{bar_color}]{'█' * bar_filled}{'░' * (20 - bar_filled)}[/{bar_color}]"

    # ── Table ─────────────────────────────────────────────────────────────
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Key", style="dim", width=18)
    table.add_column("Value", style="bold")

    table.add_row("Account",   email)
    table.add_row("Plan",      f"[green]{tier}[/green]" if tier in ("PRO", "ENTERPRISE") else tier)
    table.add_row("Requests",  f"{usage_bar}  {daily_used} / {daily_limit} today")
    table.add_row("Remaining", f"{remaining} today")

    if days_left_str:
        table.add_row("Trial ends", days_left_str)

    if warning:
        table.add_row("", f"[yellow]{warning}[/yellow]")

    upgrade_hint = (
        "Upgrade at [bold]gitrama.ai/pro[/bold] for unlimited requests"
        if tier == "TRIAL" or tier == "FREE"
        else None
    )

    console.print(Panel(
        table,
        title=f"🌿 Gitrama Account — {first_name}" if first_name else "🌿 Gitrama Account",
        border_style="green",
        subtitle=f"[dim]{upgrade_hint}[/dim]" if upgrade_hint else None
    ))