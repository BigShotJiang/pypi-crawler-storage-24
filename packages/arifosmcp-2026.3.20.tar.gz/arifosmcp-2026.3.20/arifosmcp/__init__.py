"""arifOS MCP package root."""
