import re

profiles = {
    'get_caller_status': {'default': 'micro', 'min': 'micro', 'max': 'small', 'policy': 'truncate'},
    'init_anchor': {'default': 'small', 'min': 'small', 'max': 'medium', 'policy': 'fail'},
    'init_anchor_state': {'default': 'small', 'min': 'small', 'max': 'medium', 'policy': 'fail'},
    'revoke_anchor_state': {'default': 'micro', 'min': 'micro', 'max': 'micro', 'policy': 'fail'},
    'register_tools': {'default': 'micro', 'min': 'micro', 'max': 'small', 'policy': 'truncate'},
    'arifOS_kernel': {'default': 'medium', 'min': 'small', 'max': 'large', 'policy': 'truncate_and_flag'},
    'forge': {'default': 'large', 'min': 'medium', 'max': 'large', 'policy': 'fail'},
    'agi_reason': {'default': 'medium', 'min': 'small', 'max': 'large', 'policy': 'truncate_and_flag'},
    'agi_reflect': {'default': 'medium', 'min': 'small', 'max': 'medium', 'policy': 'truncate'},
    'reality_compass': {'default': 'small', 'min': 'small', 'max': 'medium', 'policy': 'truncate'},
    'reality_atlas': {'default': 'small', 'min': 'small', 'max': 'medium', 'policy': 'truncate'},
    'search_reality': {'default': 'small', 'min': 'small', 'max': 'medium', 'policy': 'truncate'},
    'ingest_evidence': {'default': 'small', 'min': 'small', 'max': 'medium', 'policy': 'truncate'},
    'asi_critique': {'default': 'medium', 'min': 'small', 'max': 'large', 'policy': 'truncate_and_flag'},
    'asi_simulate': {'default': 'medium', 'min': 'small', 'max': 'medium', 'policy': 'truncate_and_flag'},
    'agentzero_engineer': {'default': 'large', 'min': 'medium', 'max': 'large', 'policy': 'fail'},
    'agentzero_memory_query': {'default': 'medium', 'min': 'small', 'max': 'medium', 'policy': 'truncate'},
    'apex_judge': {'default': 'medium', 'min': 'medium', 'max': 'large', 'policy': 'fail'},
    'agentzero_validate': {'default': 'medium', 'min': 'small', 'max': 'large', 'policy': 'truncate_and_flag'},
    'audit_rules': {'default': 'micro', 'min': 'micro', 'max': 'small', 'policy': 'truncate'},
    'agentzero_armor_scan': {'default': 'small', 'min': 'micro', 'max': 'medium', 'policy': 'fail'},
    'agentzero_hold_check': {'default': 'small', 'min': 'micro', 'max': 'medium', 'policy': 'truncate'},
    'check_vital': {'default': 'micro', 'min': 'micro', 'max': 'micro', 'policy': 'truncate'},
    'open_apex_dashboard': {'default': 'small', 'min': 'micro', 'max': 'small', 'policy': 'truncate'},
    'vault_seal': {'default': 'small', 'min': 'small', 'max': 'medium', 'policy': 'fail'},
    'verify_vault_ledger': {'default': 'small', 'min': 'small', 'max': 'small', 'policy': 'fail'},
}

path = r'c:\arifosmcp\arifosmcp\runtime\public_registry.py'
with open(path, 'r') as f:
    content = f.read()

for tool, p in profiles.items():
    # Try replacing existing budget_tier pattern first
    # This also handles cases where budget_tier was already replaced by partially complete fields
    
    pattern_tier = rf'(ToolSpec\(\s*name="{tool}",.*?)budget_tier=".*?",(\s*\),)'
    new_fields = (f'\n        default_budget_tier="{p["default"]}",\n        '
                  f'min_budget_tier="{p["min"]}",\n        '
                  f'max_budget_tier="{p["max"]}",\n        '
                  f'overflow_policy="{p["policy"]}",')
                  
    if re.search(pattern_tier, content, flags=re.DOTALL):
        print(f"Updating {tool} (from budget_tier)")
        content = re.sub(pattern_tier, rf'\1{new_fields}\2', content, flags=re.DOTALL)
    else:
        # Check if already has default_budget_tier
        pattern_full = rf'(ToolSpec\(\s*name="{tool}",.*?)default_budget_tier=".*?",(\s*min_budget_tier=".*?",\s*max_budget_tier=".*?",\s*overflow_policy=".*?",)?(\s*\),)'
        if re.search(pattern_full, content, flags=re.DOTALL):
            print(f"Updating {tool} (from existing tiers)")
            content = re.sub(pattern_full, rf'\1{new_fields}\3', content, flags=re.DOTALL)
        else:
            print(f"Warning: Could not find ToolSpec for {tool}")

with open(path, 'w') as f:
    f.write(content)
print("Finished updates.")
