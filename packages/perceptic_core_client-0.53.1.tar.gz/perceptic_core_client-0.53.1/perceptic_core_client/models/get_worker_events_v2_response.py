from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.info_event_1 import InfoEvent1
    from ..models.progress_event_1 import ProgressEvent1
    from ..models.user_input_event import UserInputEvent
    from ..models.user_request_for_input_event import UserRequestForInputEvent
    from ..models.worker_v2_next_page_token import WorkerV2NextPageToken


T = TypeVar("T", bound="GetWorkerEventsV2Response")


@_attrs_define
class GetWorkerEventsV2Response:
    """
    Attributes:
        events (list[InfoEvent1 | ProgressEvent1 | UserInputEvent | UserRequestForInputEvent] | Unset):
        next_page_token (WorkerV2NextPageToken | Unset):
    """

    events: list[InfoEvent1 | ProgressEvent1 | UserInputEvent | UserRequestForInputEvent] | Unset = UNSET
    next_page_token: WorkerV2NextPageToken | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.info_event_1 import InfoEvent1
        from ..models.progress_event_1 import ProgressEvent1
        from ..models.user_request_for_input_event import UserRequestForInputEvent

        events: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.events, Unset):
            events = []
            for events_item_data in self.events:
                events_item: dict[str, Any]
                if isinstance(events_item_data, InfoEvent1):
                    events_item = events_item_data.to_dict()
                elif isinstance(events_item_data, ProgressEvent1):
                    events_item = events_item_data.to_dict()
                elif isinstance(events_item_data, UserRequestForInputEvent):
                    events_item = events_item_data.to_dict()
                else:
                    events_item = events_item_data.to_dict()

                events.append(events_item)

        next_page_token: dict[str, Any] | Unset = UNSET
        if not isinstance(self.next_page_token, Unset):
            next_page_token = self.next_page_token.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if events is not UNSET:
            field_dict["events"] = events
        if next_page_token is not UNSET:
            field_dict["nextPageToken"] = next_page_token

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.info_event_1 import InfoEvent1
        from ..models.progress_event_1 import ProgressEvent1
        from ..models.user_input_event import UserInputEvent
        from ..models.user_request_for_input_event import UserRequestForInputEvent
        from ..models.worker_v2_next_page_token import WorkerV2NextPageToken

        d = dict(src_dict)
        _events = d.pop("events", UNSET)
        events: list[InfoEvent1 | ProgressEvent1 | UserInputEvent | UserRequestForInputEvent] | Unset = UNSET
        if _events is not UNSET:
            events = []
            for events_item_data in _events:

                def _parse_events_item(
                    data: object,
                ) -> InfoEvent1 | ProgressEvent1 | UserInputEvent | UserRequestForInputEvent:
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        componentsschemas_worker_event_v2_type_0 = InfoEvent1.from_dict(data)

                        return componentsschemas_worker_event_v2_type_0
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        componentsschemas_worker_event_v2_type_1 = ProgressEvent1.from_dict(data)

                        return componentsschemas_worker_event_v2_type_1
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        componentsschemas_worker_event_v2_type_2 = UserRequestForInputEvent.from_dict(data)

                        return componentsschemas_worker_event_v2_type_2
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    if not isinstance(data, dict):
                        raise TypeError()
                    componentsschemas_worker_event_v2_type_3 = UserInputEvent.from_dict(data)

                    return componentsschemas_worker_event_v2_type_3

                events_item = _parse_events_item(events_item_data)

                events.append(events_item)

        _next_page_token = d.pop("nextPageToken", UNSET)
        next_page_token: WorkerV2NextPageToken | Unset
        if isinstance(_next_page_token, Unset):
            next_page_token = UNSET
        else:
            next_page_token = WorkerV2NextPageToken.from_dict(_next_page_token)

        get_worker_events_v2_response = cls(
            events=events,
            next_page_token=next_page_token,
        )

        get_worker_events_v2_response.additional_properties = d
        return get_worker_events_v2_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
