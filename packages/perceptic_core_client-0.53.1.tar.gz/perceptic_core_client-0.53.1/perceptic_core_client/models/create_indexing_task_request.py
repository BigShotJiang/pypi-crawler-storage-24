from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.create_indexing_task_request_settings import CreateIndexingTaskRequestSettings


T = TypeVar("T", bound="CreateIndexingTaskRequest")


@_attrs_define
class CreateIndexingTaskRequest:
    """
    Attributes:
        indexer_rid (str):
        folder_uri (str | Unset):
        namespace (str | Unset):
        target_minimum_version (int | Unset):
        settings (CreateIndexingTaskRequestSettings | Unset):
    """

    indexer_rid: str
    folder_uri: str | Unset = UNSET
    namespace: str | Unset = UNSET
    target_minimum_version: int | Unset = UNSET
    settings: CreateIndexingTaskRequestSettings | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        indexer_rid = self.indexer_rid

        folder_uri = self.folder_uri

        namespace = self.namespace

        target_minimum_version = self.target_minimum_version

        settings: dict[str, Any] | Unset = UNSET
        if not isinstance(self.settings, Unset):
            settings = self.settings.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "indexerRid": indexer_rid,
            }
        )
        if folder_uri is not UNSET:
            field_dict["folderUri"] = folder_uri
        if namespace is not UNSET:
            field_dict["namespace"] = namespace
        if target_minimum_version is not UNSET:
            field_dict["targetMinimumVersion"] = target_minimum_version
        if settings is not UNSET:
            field_dict["settings"] = settings

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.create_indexing_task_request_settings import CreateIndexingTaskRequestSettings

        d = dict(src_dict)
        indexer_rid = d.pop("indexerRid")

        folder_uri = d.pop("folderUri", UNSET)

        namespace = d.pop("namespace", UNSET)

        target_minimum_version = d.pop("targetMinimumVersion", UNSET)

        _settings = d.pop("settings", UNSET)
        settings: CreateIndexingTaskRequestSettings | Unset
        if isinstance(_settings, Unset):
            settings = UNSET
        else:
            settings = CreateIndexingTaskRequestSettings.from_dict(_settings)

        create_indexing_task_request = cls(
            indexer_rid=indexer_rid,
            folder_uri=folder_uri,
            namespace=namespace,
            target_minimum_version=target_minimum_version,
            settings=settings,
        )

        create_indexing_task_request.additional_properties = d
        return create_indexing_task_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
