from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="TagInfo")


@_attrs_define
class TagInfo:
    """
    Attributes:
        rid (str | Unset):
        name (str | Unset):
        description (str | Unset):
        user_id (str | Unset):
    """

    rid: str | Unset = UNSET
    name: str | Unset = UNSET
    description: str | Unset = UNSET
    user_id: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        rid = self.rid

        name = self.name

        description = self.description

        user_id = self.user_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if rid is not UNSET:
            field_dict["rid"] = rid
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if user_id is not UNSET:
            field_dict["userId"] = user_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        rid = d.pop("rid", UNSET)

        name = d.pop("name", UNSET)

        description = d.pop("description", UNSET)

        user_id = d.pop("userId", UNSET)

        tag_info = cls(
            rid=rid,
            name=name,
            description=description,
            user_id=user_id,
        )

        tag_info.additional_properties = d
        return tag_info

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
