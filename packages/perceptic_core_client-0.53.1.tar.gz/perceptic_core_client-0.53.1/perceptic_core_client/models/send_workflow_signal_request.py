from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.send_workflow_signal_request_inputs import SendWorkflowSignalRequestInputs


T = TypeVar("T", bound="SendWorkflowSignalRequest")


@_attrs_define
class SendWorkflowSignalRequest:
    """
    Attributes:
        inputs (SendWorkflowSignalRequestInputs | Unset):
    """

    inputs: SendWorkflowSignalRequestInputs | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        inputs: dict[str, Any] | Unset = UNSET
        if not isinstance(self.inputs, Unset):
            inputs = self.inputs.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if inputs is not UNSET:
            field_dict["inputs"] = inputs

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.send_workflow_signal_request_inputs import SendWorkflowSignalRequestInputs

        d = dict(src_dict)
        _inputs = d.pop("inputs", UNSET)
        inputs: SendWorkflowSignalRequestInputs | Unset
        if isinstance(_inputs, Unset):
            inputs = UNSET
        else:
            inputs = SendWorkflowSignalRequestInputs.from_dict(_inputs)

        send_workflow_signal_request = cls(
            inputs=inputs,
        )

        send_workflow_signal_request.additional_properties = d
        return send_workflow_signal_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
