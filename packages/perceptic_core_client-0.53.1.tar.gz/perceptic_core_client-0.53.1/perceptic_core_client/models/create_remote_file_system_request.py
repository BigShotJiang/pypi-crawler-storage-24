from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.azure_blob_file_system_root_metadata_api_dto import AzureBlobFileSystemRootMetadataApiDto
    from ..models.s3_file_system_root_metadata_api_dto import S3FileSystemRootMetadataApiDto


T = TypeVar("T", bound="CreateRemoteFileSystemRequest")


@_attrs_define
class CreateRemoteFileSystemRequest:
    """
    Attributes:
        connection_rid (str | Unset):
        name (str | Unset):
        description (str | Unset):
        metadata (AzureBlobFileSystemRootMetadataApiDto | S3FileSystemRootMetadataApiDto | Unset):
    """

    connection_rid: str | Unset = UNSET
    name: str | Unset = UNSET
    description: str | Unset = UNSET
    metadata: AzureBlobFileSystemRootMetadataApiDto | S3FileSystemRootMetadataApiDto | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.azure_blob_file_system_root_metadata_api_dto import AzureBlobFileSystemRootMetadataApiDto

        connection_rid = self.connection_rid

        name = self.name

        description = self.description

        metadata: dict[str, Any] | Unset
        if isinstance(self.metadata, Unset):
            metadata = UNSET
        elif isinstance(self.metadata, AzureBlobFileSystemRootMetadataApiDto):
            metadata = self.metadata.to_dict()
        else:
            metadata = self.metadata.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if connection_rid is not UNSET:
            field_dict["connectionRid"] = connection_rid
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if metadata is not UNSET:
            field_dict["metadata"] = metadata

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.azure_blob_file_system_root_metadata_api_dto import AzureBlobFileSystemRootMetadataApiDto
        from ..models.s3_file_system_root_metadata_api_dto import S3FileSystemRootMetadataApiDto

        d = dict(src_dict)
        connection_rid = d.pop("connectionRid", UNSET)

        name = d.pop("name", UNSET)

        description = d.pop("description", UNSET)

        def _parse_metadata(
            data: object,
        ) -> AzureBlobFileSystemRootMetadataApiDto | S3FileSystemRootMetadataApiDto | Unset:
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                componentsschemas_file_system_root_metadata_api_dto_type_0 = (
                    AzureBlobFileSystemRootMetadataApiDto.from_dict(data)
                )

                return componentsschemas_file_system_root_metadata_api_dto_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            componentsschemas_file_system_root_metadata_api_dto_type_1 = S3FileSystemRootMetadataApiDto.from_dict(data)

            return componentsschemas_file_system_root_metadata_api_dto_type_1

        metadata = _parse_metadata(d.pop("metadata", UNSET))

        create_remote_file_system_request = cls(
            connection_rid=connection_rid,
            name=name,
            description=description,
            metadata=metadata,
        )

        create_remote_file_system_request.additional_properties = d
        return create_remote_file_system_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
