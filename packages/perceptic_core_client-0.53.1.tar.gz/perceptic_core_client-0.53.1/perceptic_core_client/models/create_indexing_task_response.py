from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.indexing_task_dto import IndexingTaskDto


T = TypeVar("T", bound="CreateIndexingTaskResponse")


@_attrs_define
class CreateIndexingTaskResponse:
    """
    Attributes:
        task_rid (str | Unset):
        task (IndexingTaskDto | Unset):
        created (bool | Unset):
    """

    task_rid: str | Unset = UNSET
    task: IndexingTaskDto | Unset = UNSET
    created: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        task_rid = self.task_rid

        task: dict[str, Any] | Unset = UNSET
        if not isinstance(self.task, Unset):
            task = self.task.to_dict()

        created = self.created

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if task_rid is not UNSET:
            field_dict["taskRid"] = task_rid
        if task is not UNSET:
            field_dict["task"] = task
        if created is not UNSET:
            field_dict["created"] = created

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.indexing_task_dto import IndexingTaskDto

        d = dict(src_dict)
        task_rid = d.pop("taskRid", UNSET)

        _task = d.pop("task", UNSET)
        task: IndexingTaskDto | Unset
        if isinstance(_task, Unset):
            task = UNSET
        else:
            task = IndexingTaskDto.from_dict(_task)

        created = d.pop("created", UNSET)

        create_indexing_task_response = cls(
            task_rid=task_rid,
            task=task,
            created=created,
        )

        create_indexing_task_response.additional_properties = d
        return create_indexing_task_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
