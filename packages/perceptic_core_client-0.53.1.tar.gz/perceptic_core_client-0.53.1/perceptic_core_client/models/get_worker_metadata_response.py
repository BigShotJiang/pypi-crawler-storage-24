from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.worker_metadata_dto import WorkerMetadataDto


T = TypeVar("T", bound="GetWorkerMetadataResponse")


@_attrs_define
class GetWorkerMetadataResponse:
    """
    Attributes:
        worker_metadata (WorkerMetadataDto | Unset):
    """

    worker_metadata: WorkerMetadataDto | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        worker_metadata: dict[str, Any] | Unset = UNSET
        if not isinstance(self.worker_metadata, Unset):
            worker_metadata = self.worker_metadata.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if worker_metadata is not UNSET:
            field_dict["workerMetadata"] = worker_metadata

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.worker_metadata_dto import WorkerMetadataDto

        d = dict(src_dict)
        _worker_metadata = d.pop("workerMetadata", UNSET)
        worker_metadata: WorkerMetadataDto | Unset
        if isinstance(_worker_metadata, Unset):
            worker_metadata = UNSET
        else:
            worker_metadata = WorkerMetadataDto.from_dict(_worker_metadata)

        get_worker_metadata_response = cls(
            worker_metadata=worker_metadata,
        )

        get_worker_metadata_response.additional_properties = d
        return get_worker_metadata_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
