from enum import Enum


class OrchestratorStatus(str, Enum):
    CANCELED = "CANCELED"
    COMPLETED = "COMPLETED"
    CONTINUED_AS_NEW = "CONTINUED_AS_NEW"
    FAILED = "FAILED"
    RUNNING = "RUNNING"
    TERMINATED = "TERMINATED"
    TIMED_OUT = "TIMED_OUT"
    UNSPECIFIED = "UNSPECIFIED"

    def __str__(self) -> str:
        return str(self.value)
