from enum import Enum


class ActionType(str, Enum):
    DELETE = "DELETE"
    INDEX = "INDEX"
    NOOP = "NOOP"

    def __str__(self) -> str:
        return str(self.value)
