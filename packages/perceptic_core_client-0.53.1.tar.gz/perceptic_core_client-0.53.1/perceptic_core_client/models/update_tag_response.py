from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.tag_info import TagInfo


T = TypeVar("T", bound="UpdateTagResponse")


@_attrs_define
class UpdateTagResponse:
    """
    Attributes:
        updated_tag (TagInfo | Unset):
    """

    updated_tag: TagInfo | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        updated_tag: dict[str, Any] | Unset = UNSET
        if not isinstance(self.updated_tag, Unset):
            updated_tag = self.updated_tag.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if updated_tag is not UNSET:
            field_dict["updatedTag"] = updated_tag

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.tag_info import TagInfo

        d = dict(src_dict)
        _updated_tag = d.pop("updatedTag", UNSET)
        updated_tag: TagInfo | Unset
        if isinstance(_updated_tag, Unset):
            updated_tag = UNSET
        else:
            updated_tag = TagInfo.from_dict(_updated_tag)

        update_tag_response = cls(
            updated_tag=updated_tag,
        )

        update_tag_response.additional_properties = d
        return update_tag_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
