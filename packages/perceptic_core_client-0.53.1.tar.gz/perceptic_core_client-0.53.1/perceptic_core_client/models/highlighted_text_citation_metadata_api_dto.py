from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="HighlightedTextCitationMetadataApiDto")


@_attrs_define
class HighlightedTextCitationMetadataApiDto:
    """
    Attributes:
        page_index (int | Unset):
        paragraph_index (int | Unset):
        text (str | Unset):
    """

    page_index: int | Unset = UNSET
    paragraph_index: int | Unset = UNSET
    text: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        page_index = self.page_index

        paragraph_index = self.paragraph_index

        text = self.text

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if page_index is not UNSET:
            field_dict["pageIndex"] = page_index
        if paragraph_index is not UNSET:
            field_dict["paragraphIndex"] = paragraph_index
        if text is not UNSET:
            field_dict["text"] = text

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        page_index = d.pop("pageIndex", UNSET)

        paragraph_index = d.pop("paragraphIndex", UNSET)

        text = d.pop("text", UNSET)

        highlighted_text_citation_metadata_api_dto = cls(
            page_index=page_index,
            paragraph_index=paragraph_index,
            text=text,
        )

        highlighted_text_citation_metadata_api_dto.additional_properties = d
        return highlighted_text_citation_metadata_api_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
