from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.user_input_event_input import UserInputEventInput


T = TypeVar("T", bound="UserInputEvent")


@_attrs_define
class UserInputEvent:
    """
    Attributes:
        sequence (int | Unset):
        input_ (UserInputEventInput | Unset):
        attribution (None | str | Unset):
        created_at (datetime.datetime | Unset):
        type_ (str | Unset):
    """

    sequence: int | Unset = UNSET
    input_: UserInputEventInput | Unset = UNSET
    attribution: None | str | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    type_: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        sequence = self.sequence

        input_: dict[str, Any] | Unset = UNSET
        if not isinstance(self.input_, Unset):
            input_ = self.input_.to_dict()

        attribution: None | str | Unset
        if isinstance(self.attribution, Unset):
            attribution = UNSET
        else:
            attribution = self.attribution

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        type_ = self.type_

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if sequence is not UNSET:
            field_dict["sequence"] = sequence
        if input_ is not UNSET:
            field_dict["input"] = input_
        if attribution is not UNSET:
            field_dict["attribution"] = attribution
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at
        if type_ is not UNSET:
            field_dict["type"] = type_

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.user_input_event_input import UserInputEventInput

        d = dict(src_dict)
        sequence = d.pop("sequence", UNSET)

        _input_ = d.pop("input", UNSET)
        input_: UserInputEventInput | Unset
        if isinstance(_input_, Unset):
            input_ = UNSET
        else:
            input_ = UserInputEventInput.from_dict(_input_)

        def _parse_attribution(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        attribution = _parse_attribution(d.pop("attribution", UNSET))

        _created_at = d.pop("createdAt", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        type_ = d.pop("type", UNSET)

        user_input_event = cls(
            sequence=sequence,
            input_=input_,
            attribution=attribution,
            created_at=created_at,
            type_=type_,
        )

        user_input_event.additional_properties = d
        return user_input_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
