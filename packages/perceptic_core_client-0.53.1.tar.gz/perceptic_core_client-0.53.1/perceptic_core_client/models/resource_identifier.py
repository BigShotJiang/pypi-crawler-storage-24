from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="ResourceIdentifier")


@_attrs_define
class ResourceIdentifier:
    """
    Attributes:
        resource_identifier (str | Unset):
        service_index (int | Unset):
        instance_index (int | Unset):
        type_index (int | Unset):
        service (str | Unset):
        instance (str | Unset):
        type_ (str | Unset):
        locator (str | Unset):
    """

    resource_identifier: str | Unset = UNSET
    service_index: int | Unset = UNSET
    instance_index: int | Unset = UNSET
    type_index: int | Unset = UNSET
    service: str | Unset = UNSET
    instance: str | Unset = UNSET
    type_: str | Unset = UNSET
    locator: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        resource_identifier = self.resource_identifier

        service_index = self.service_index

        instance_index = self.instance_index

        type_index = self.type_index

        service = self.service

        instance = self.instance

        type_ = self.type_

        locator = self.locator

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if resource_identifier is not UNSET:
            field_dict["resourceIdentifier"] = resource_identifier
        if service_index is not UNSET:
            field_dict["serviceIndex"] = service_index
        if instance_index is not UNSET:
            field_dict["instanceIndex"] = instance_index
        if type_index is not UNSET:
            field_dict["typeIndex"] = type_index
        if service is not UNSET:
            field_dict["service"] = service
        if instance is not UNSET:
            field_dict["instance"] = instance
        if type_ is not UNSET:
            field_dict["type"] = type_
        if locator is not UNSET:
            field_dict["locator"] = locator

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        resource_identifier = d.pop("resourceIdentifier", UNSET)

        service_index = d.pop("serviceIndex", UNSET)

        instance_index = d.pop("instanceIndex", UNSET)

        type_index = d.pop("typeIndex", UNSET)

        service = d.pop("service", UNSET)

        instance = d.pop("instance", UNSET)

        type_ = d.pop("type", UNSET)

        locator = d.pop("locator", UNSET)

        resource_identifier = cls(
            resource_identifier=resource_identifier,
            service_index=service_index,
            instance_index=instance_index,
            type_index=type_index,
            service=service,
            instance=instance,
            type_=type_,
            locator=locator,
        )

        resource_identifier.additional_properties = d
        return resource_identifier

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
