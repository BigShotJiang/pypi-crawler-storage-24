from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.resource_entry_dto import ResourceEntryDto


T = TypeVar("T", bound="PagedListFileSystemResponse")


@_attrs_define
class PagedListFileSystemResponse:
    """
    Attributes:
        items (list[ResourceEntryDto] | Unset):
        next_token (None | str | Unset):
    """

    items: list[ResourceEntryDto] | Unset = UNSET
    next_token: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        items: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.items, Unset):
            items = []
            for items_item_data in self.items:
                items_item = items_item_data.to_dict()
                items.append(items_item)

        next_token: None | str | Unset
        if isinstance(self.next_token, Unset):
            next_token = UNSET
        else:
            next_token = self.next_token

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if items is not UNSET:
            field_dict["items"] = items
        if next_token is not UNSET:
            field_dict["nextToken"] = next_token

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.resource_entry_dto import ResourceEntryDto

        d = dict(src_dict)
        _items = d.pop("items", UNSET)
        items: list[ResourceEntryDto] | Unset = UNSET
        if _items is not UNSET:
            items = []
            for items_item_data in _items:
                items_item = ResourceEntryDto.from_dict(items_item_data)

                items.append(items_item)

        def _parse_next_token(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        next_token = _parse_next_token(d.pop("nextToken", UNSET))

        paged_list_file_system_response = cls(
            items=items,
            next_token=next_token,
        )

        paged_list_file_system_response.additional_properties = d
        return paged_list_file_system_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
