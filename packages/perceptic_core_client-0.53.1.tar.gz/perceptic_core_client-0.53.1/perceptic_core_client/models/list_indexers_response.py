from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.list_indexers_response_indexers import ListIndexersResponseIndexers


T = TypeVar("T", bound="ListIndexersResponse")


@_attrs_define
class ListIndexersResponse:
    """
    Attributes:
        indexers (ListIndexersResponseIndexers | Unset):
    """

    indexers: ListIndexersResponseIndexers | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        indexers: dict[str, Any] | Unset = UNSET
        if not isinstance(self.indexers, Unset):
            indexers = self.indexers.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if indexers is not UNSET:
            field_dict["indexers"] = indexers

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.list_indexers_response_indexers import ListIndexersResponseIndexers

        d = dict(src_dict)
        _indexers = d.pop("indexers", UNSET)
        indexers: ListIndexersResponseIndexers | Unset
        if isinstance(_indexers, Unset):
            indexers = UNSET
        else:
            indexers = ListIndexersResponseIndexers.from_dict(_indexers)

        list_indexers_response = cls(
            indexers=indexers,
        )

        list_indexers_response.additional_properties = d
        return list_indexers_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
