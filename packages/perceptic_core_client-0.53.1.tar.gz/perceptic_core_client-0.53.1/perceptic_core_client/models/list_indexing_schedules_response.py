from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.indexing_schedule_dto import IndexingScheduleDto


T = TypeVar("T", bound="ListIndexingSchedulesResponse")


@_attrs_define
class ListIndexingSchedulesResponse:
    """
    Attributes:
        schedules (list[IndexingScheduleDto] | Unset):
        total_count (int | Unset):
        next_offset (int | None | Unset):
    """

    schedules: list[IndexingScheduleDto] | Unset = UNSET
    total_count: int | Unset = UNSET
    next_offset: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        schedules: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.schedules, Unset):
            schedules = []
            for schedules_item_data in self.schedules:
                schedules_item = schedules_item_data.to_dict()
                schedules.append(schedules_item)

        total_count = self.total_count

        next_offset: int | None | Unset
        if isinstance(self.next_offset, Unset):
            next_offset = UNSET
        else:
            next_offset = self.next_offset

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if schedules is not UNSET:
            field_dict["schedules"] = schedules
        if total_count is not UNSET:
            field_dict["totalCount"] = total_count
        if next_offset is not UNSET:
            field_dict["nextOffset"] = next_offset

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.indexing_schedule_dto import IndexingScheduleDto

        d = dict(src_dict)
        _schedules = d.pop("schedules", UNSET)
        schedules: list[IndexingScheduleDto] | Unset = UNSET
        if _schedules is not UNSET:
            schedules = []
            for schedules_item_data in _schedules:
                schedules_item = IndexingScheduleDto.from_dict(schedules_item_data)

                schedules.append(schedules_item)

        total_count = d.pop("totalCount", UNSET)

        def _parse_next_offset(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        next_offset = _parse_next_offset(d.pop("nextOffset", UNSET))

        list_indexing_schedules_response = cls(
            schedules=schedules,
            total_count=total_count,
            next_offset=next_offset,
        )

        list_indexing_schedules_response.additional_properties = d
        return list_indexing_schedules_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
