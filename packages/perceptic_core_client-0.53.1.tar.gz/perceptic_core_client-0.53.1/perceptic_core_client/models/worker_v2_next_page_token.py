from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="WorkerV2NextPageToken")


@_attrs_define
class WorkerV2NextPageToken:
    """
    Attributes:
        offset_for_worker_run_events (int | Unset):
        offset_for_input_request_events (int | Unset):
    """

    offset_for_worker_run_events: int | Unset = UNSET
    offset_for_input_request_events: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        offset_for_worker_run_events = self.offset_for_worker_run_events

        offset_for_input_request_events = self.offset_for_input_request_events

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if offset_for_worker_run_events is not UNSET:
            field_dict["offsetForWorkerRunEvents"] = offset_for_worker_run_events
        if offset_for_input_request_events is not UNSET:
            field_dict["offsetForInputRequestEvents"] = offset_for_input_request_events

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        offset_for_worker_run_events = d.pop("offsetForWorkerRunEvents", UNSET)

        offset_for_input_request_events = d.pop("offsetForInputRequestEvents", UNSET)

        worker_v2_next_page_token = cls(
            offset_for_worker_run_events=offset_for_worker_run_events,
            offset_for_input_request_events=offset_for_input_request_events,
        )

        worker_v2_next_page_token.additional_properties = d
        return worker_v2_next_page_token

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
