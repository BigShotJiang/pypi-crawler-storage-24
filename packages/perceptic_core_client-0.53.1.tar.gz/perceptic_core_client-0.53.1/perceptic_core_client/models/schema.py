from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.schema_location import SchemaLocation
    from ..models.schema_unprocessed_properties import SchemaUnprocessedProperties


T = TypeVar("T", bound="Schema")


@_attrs_define
class Schema:
    """
    Attributes:
        title (str | Unset):
        description (str | Unset):
        id (str | Unset):
        schema_location (str | Unset):
        location (SchemaLocation | Unset):
        default_value (Any | Unset):
        nullable (bool | Unset):
        read_only (bool | Unset):
        write_only (bool | Unset):
        unprocessed_properties (SchemaUnprocessedProperties | Unset):
    """

    title: str | Unset = UNSET
    description: str | Unset = UNSET
    id: str | Unset = UNSET
    schema_location: str | Unset = UNSET
    location: SchemaLocation | Unset = UNSET
    default_value: Any | Unset = UNSET
    nullable: bool | Unset = UNSET
    read_only: bool | Unset = UNSET
    write_only: bool | Unset = UNSET
    unprocessed_properties: SchemaUnprocessedProperties | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        title = self.title

        description = self.description

        id = self.id

        schema_location = self.schema_location

        location: dict[str, Any] | Unset = UNSET
        if not isinstance(self.location, Unset):
            location = self.location.to_dict()

        default_value = self.default_value

        nullable = self.nullable

        read_only = self.read_only

        write_only = self.write_only

        unprocessed_properties: dict[str, Any] | Unset = UNSET
        if not isinstance(self.unprocessed_properties, Unset):
            unprocessed_properties = self.unprocessed_properties.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if title is not UNSET:
            field_dict["title"] = title
        if description is not UNSET:
            field_dict["description"] = description
        if id is not UNSET:
            field_dict["id"] = id
        if schema_location is not UNSET:
            field_dict["schemaLocation"] = schema_location
        if location is not UNSET:
            field_dict["location"] = location
        if default_value is not UNSET:
            field_dict["defaultValue"] = default_value
        if nullable is not UNSET:
            field_dict["nullable"] = nullable
        if read_only is not UNSET:
            field_dict["readOnly"] = read_only
        if write_only is not UNSET:
            field_dict["writeOnly"] = write_only
        if unprocessed_properties is not UNSET:
            field_dict["unprocessedProperties"] = unprocessed_properties

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.schema_location import SchemaLocation
        from ..models.schema_unprocessed_properties import SchemaUnprocessedProperties

        d = dict(src_dict)
        title = d.pop("title", UNSET)

        description = d.pop("description", UNSET)

        id = d.pop("id", UNSET)

        schema_location = d.pop("schemaLocation", UNSET)

        _location = d.pop("location", UNSET)
        location: SchemaLocation | Unset
        if isinstance(_location, Unset):
            location = UNSET
        else:
            location = SchemaLocation.from_dict(_location)

        default_value = d.pop("defaultValue", UNSET)

        nullable = d.pop("nullable", UNSET)

        read_only = d.pop("readOnly", UNSET)

        write_only = d.pop("writeOnly", UNSET)

        _unprocessed_properties = d.pop("unprocessedProperties", UNSET)
        unprocessed_properties: SchemaUnprocessedProperties | Unset
        if isinstance(_unprocessed_properties, Unset):
            unprocessed_properties = UNSET
        else:
            unprocessed_properties = SchemaUnprocessedProperties.from_dict(_unprocessed_properties)

        schema = cls(
            title=title,
            description=description,
            id=id,
            schema_location=schema_location,
            location=location,
            default_value=default_value,
            nullable=nullable,
            read_only=read_only,
            write_only=write_only,
            unprocessed_properties=unprocessed_properties,
        )

        schema.additional_properties = d
        return schema

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
