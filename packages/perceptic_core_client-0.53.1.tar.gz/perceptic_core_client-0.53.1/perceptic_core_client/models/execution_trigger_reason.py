from enum import Enum


class ExecutionTriggerReason(str, Enum):
    FILE_UPLOAD = "FILE_UPLOAD"
    SCHEDULED = "SCHEDULED"

    def __str__(self) -> str:
        return str(self.value)
