from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.azure_blob_file_system_root_metadata_api_dto import AzureBlobFileSystemRootMetadataApiDto
    from ..models.s3_file_system_root_metadata_api_dto import S3FileSystemRootMetadataApiDto


T = TypeVar("T", bound="RemoteFileSystemApiDto")


@_attrs_define
class RemoteFileSystemApiDto:
    """
    Attributes:
        rid (str | Unset):
        name (str | Unset):
        description (str | Unset):
        metadata (AzureBlobFileSystemRootMetadataApiDto | S3FileSystemRootMetadataApiDto | Unset):
        connection_rid (str | Unset):
        type_ (str | Unset):
    """

    rid: str | Unset = UNSET
    name: str | Unset = UNSET
    description: str | Unset = UNSET
    metadata: AzureBlobFileSystemRootMetadataApiDto | S3FileSystemRootMetadataApiDto | Unset = UNSET
    connection_rid: str | Unset = UNSET
    type_: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.azure_blob_file_system_root_metadata_api_dto import AzureBlobFileSystemRootMetadataApiDto

        rid = self.rid

        name = self.name

        description = self.description

        metadata: dict[str, Any] | Unset
        if isinstance(self.metadata, Unset):
            metadata = UNSET
        elif isinstance(self.metadata, AzureBlobFileSystemRootMetadataApiDto):
            metadata = self.metadata.to_dict()
        else:
            metadata = self.metadata.to_dict()

        connection_rid = self.connection_rid

        type_ = self.type_

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if rid is not UNSET:
            field_dict["rid"] = rid
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if metadata is not UNSET:
            field_dict["metadata"] = metadata
        if connection_rid is not UNSET:
            field_dict["connectionRid"] = connection_rid
        if type_ is not UNSET:
            field_dict["type"] = type_

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.azure_blob_file_system_root_metadata_api_dto import AzureBlobFileSystemRootMetadataApiDto
        from ..models.s3_file_system_root_metadata_api_dto import S3FileSystemRootMetadataApiDto

        d = dict(src_dict)
        rid = d.pop("rid", UNSET)

        name = d.pop("name", UNSET)

        description = d.pop("description", UNSET)

        def _parse_metadata(
            data: object,
        ) -> AzureBlobFileSystemRootMetadataApiDto | S3FileSystemRootMetadataApiDto | Unset:
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                componentsschemas_file_system_root_metadata_api_dto_type_0 = (
                    AzureBlobFileSystemRootMetadataApiDto.from_dict(data)
                )

                return componentsschemas_file_system_root_metadata_api_dto_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            componentsschemas_file_system_root_metadata_api_dto_type_1 = S3FileSystemRootMetadataApiDto.from_dict(data)

            return componentsschemas_file_system_root_metadata_api_dto_type_1

        metadata = _parse_metadata(d.pop("metadata", UNSET))

        connection_rid = d.pop("connectionRid", UNSET)

        type_ = d.pop("type", UNSET)

        remote_file_system_api_dto = cls(
            rid=rid,
            name=name,
            description=description,
            metadata=metadata,
            connection_rid=connection_rid,
            type_=type_,
        )

        remote_file_system_api_dto.additional_properties = d
        return remote_file_system_api_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
