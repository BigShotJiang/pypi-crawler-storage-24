from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.query_workflow_request_inputs_type_0_item import QueryWorkflowRequestInputsType0Item


T = TypeVar("T", bound="QueryWorkflowRequest")


@_attrs_define
class QueryWorkflowRequest:
    """
    Attributes:
        inputs (list[QueryWorkflowRequestInputsType0Item] | None | Unset):
    """

    inputs: list[QueryWorkflowRequestInputsType0Item] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        inputs: list[dict[str, Any]] | None | Unset
        if isinstance(self.inputs, Unset):
            inputs = UNSET
        elif isinstance(self.inputs, list):
            inputs = []
            for inputs_type_0_item_data in self.inputs:
                inputs_type_0_item = inputs_type_0_item_data.to_dict()
                inputs.append(inputs_type_0_item)

        else:
            inputs = self.inputs

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if inputs is not UNSET:
            field_dict["inputs"] = inputs

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.query_workflow_request_inputs_type_0_item import QueryWorkflowRequestInputsType0Item

        d = dict(src_dict)

        def _parse_inputs(data: object) -> list[QueryWorkflowRequestInputsType0Item] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                inputs_type_0 = []
                _inputs_type_0 = data
                for inputs_type_0_item_data in _inputs_type_0:
                    inputs_type_0_item = QueryWorkflowRequestInputsType0Item.from_dict(inputs_type_0_item_data)

                    inputs_type_0.append(inputs_type_0_item)

                return inputs_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[QueryWorkflowRequestInputsType0Item] | None | Unset, data)

        inputs = _parse_inputs(d.pop("inputs", UNSET))

        query_workflow_request = cls(
            inputs=inputs,
        )

        query_workflow_request.additional_properties = d
        return query_workflow_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
