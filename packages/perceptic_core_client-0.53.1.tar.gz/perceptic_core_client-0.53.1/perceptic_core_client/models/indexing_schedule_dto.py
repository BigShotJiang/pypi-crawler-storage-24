from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.cron_trigger import CronTrigger
    from ..models.indexing_schedule_dto_indexing_settings import IndexingScheduleDtoIndexingSettings
    from ..models.interval_trigger import IntervalTrigger
    from ..models.on_upload_trigger import OnUploadTrigger


T = TypeVar("T", bound="IndexingScheduleDto")


@_attrs_define
class IndexingScheduleDto:
    """
    Attributes:
        schedule_rid (str | Unset):
        name (str | Unset):
        description (str | Unset):
        indexer_rid (str | Unset):
        target_uri (str | Unset):
        namespace (str | Unset):
        target_minimum_version (int | Unset):
        indexing_settings (IndexingScheduleDtoIndexingSettings | Unset):
        trigger (CronTrigger | IntervalTrigger | OnUploadTrigger | Unset):
        enabled (bool | Unset):
        created_at (datetime.datetime | Unset):
        updated_at (datetime.datetime | Unset):
        last_executed_at (datetime.datetime | None | Unset):
        next_execution_at (datetime.datetime | None | Unset):
    """

    schedule_rid: str | Unset = UNSET
    name: str | Unset = UNSET
    description: str | Unset = UNSET
    indexer_rid: str | Unset = UNSET
    target_uri: str | Unset = UNSET
    namespace: str | Unset = UNSET
    target_minimum_version: int | Unset = UNSET
    indexing_settings: IndexingScheduleDtoIndexingSettings | Unset = UNSET
    trigger: CronTrigger | IntervalTrigger | OnUploadTrigger | Unset = UNSET
    enabled: bool | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    updated_at: datetime.datetime | Unset = UNSET
    last_executed_at: datetime.datetime | None | Unset = UNSET
    next_execution_at: datetime.datetime | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.cron_trigger import CronTrigger
        from ..models.on_upload_trigger import OnUploadTrigger

        schedule_rid = self.schedule_rid

        name = self.name

        description = self.description

        indexer_rid = self.indexer_rid

        target_uri = self.target_uri

        namespace = self.namespace

        target_minimum_version = self.target_minimum_version

        indexing_settings: dict[str, Any] | Unset = UNSET
        if not isinstance(self.indexing_settings, Unset):
            indexing_settings = self.indexing_settings.to_dict()

        trigger: dict[str, Any] | Unset
        if isinstance(self.trigger, Unset):
            trigger = UNSET
        elif isinstance(self.trigger, OnUploadTrigger):
            trigger = self.trigger.to_dict()
        elif isinstance(self.trigger, CronTrigger):
            trigger = self.trigger.to_dict()
        else:
            trigger = self.trigger.to_dict()

        enabled = self.enabled

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        updated_at: str | Unset = UNSET
        if not isinstance(self.updated_at, Unset):
            updated_at = self.updated_at.isoformat()

        last_executed_at: None | str | Unset
        if isinstance(self.last_executed_at, Unset):
            last_executed_at = UNSET
        elif isinstance(self.last_executed_at, datetime.datetime):
            last_executed_at = self.last_executed_at.isoformat()
        else:
            last_executed_at = self.last_executed_at

        next_execution_at: None | str | Unset
        if isinstance(self.next_execution_at, Unset):
            next_execution_at = UNSET
        elif isinstance(self.next_execution_at, datetime.datetime):
            next_execution_at = self.next_execution_at.isoformat()
        else:
            next_execution_at = self.next_execution_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if schedule_rid is not UNSET:
            field_dict["scheduleRid"] = schedule_rid
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if indexer_rid is not UNSET:
            field_dict["indexerRid"] = indexer_rid
        if target_uri is not UNSET:
            field_dict["targetUri"] = target_uri
        if namespace is not UNSET:
            field_dict["namespace"] = namespace
        if target_minimum_version is not UNSET:
            field_dict["targetMinimumVersion"] = target_minimum_version
        if indexing_settings is not UNSET:
            field_dict["indexingSettings"] = indexing_settings
        if trigger is not UNSET:
            field_dict["trigger"] = trigger
        if enabled is not UNSET:
            field_dict["enabled"] = enabled
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at
        if updated_at is not UNSET:
            field_dict["updatedAt"] = updated_at
        if last_executed_at is not UNSET:
            field_dict["lastExecutedAt"] = last_executed_at
        if next_execution_at is not UNSET:
            field_dict["nextExecutionAt"] = next_execution_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.cron_trigger import CronTrigger
        from ..models.indexing_schedule_dto_indexing_settings import IndexingScheduleDtoIndexingSettings
        from ..models.interval_trigger import IntervalTrigger
        from ..models.on_upload_trigger import OnUploadTrigger

        d = dict(src_dict)
        schedule_rid = d.pop("scheduleRid", UNSET)

        name = d.pop("name", UNSET)

        description = d.pop("description", UNSET)

        indexer_rid = d.pop("indexerRid", UNSET)

        target_uri = d.pop("targetUri", UNSET)

        namespace = d.pop("namespace", UNSET)

        target_minimum_version = d.pop("targetMinimumVersion", UNSET)

        _indexing_settings = d.pop("indexingSettings", UNSET)
        indexing_settings: IndexingScheduleDtoIndexingSettings | Unset
        if isinstance(_indexing_settings, Unset):
            indexing_settings = UNSET
        else:
            indexing_settings = IndexingScheduleDtoIndexingSettings.from_dict(_indexing_settings)

        def _parse_trigger(data: object) -> CronTrigger | IntervalTrigger | OnUploadTrigger | Unset:
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                componentsschemas_schedule_trigger_type_0 = OnUploadTrigger.from_dict(data)

                return componentsschemas_schedule_trigger_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                componentsschemas_schedule_trigger_type_1 = CronTrigger.from_dict(data)

                return componentsschemas_schedule_trigger_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            componentsschemas_schedule_trigger_type_2 = IntervalTrigger.from_dict(data)

            return componentsschemas_schedule_trigger_type_2

        trigger = _parse_trigger(d.pop("trigger", UNSET))

        enabled = d.pop("enabled", UNSET)

        _created_at = d.pop("createdAt", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        _updated_at = d.pop("updatedAt", UNSET)
        updated_at: datetime.datetime | Unset
        if isinstance(_updated_at, Unset):
            updated_at = UNSET
        else:
            updated_at = isoparse(_updated_at)

        def _parse_last_executed_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_executed_at_type_0 = isoparse(data)

                return last_executed_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        last_executed_at = _parse_last_executed_at(d.pop("lastExecutedAt", UNSET))

        def _parse_next_execution_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                next_execution_at_type_0 = isoparse(data)

                return next_execution_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        next_execution_at = _parse_next_execution_at(d.pop("nextExecutionAt", UNSET))

        indexing_schedule_dto = cls(
            schedule_rid=schedule_rid,
            name=name,
            description=description,
            indexer_rid=indexer_rid,
            target_uri=target_uri,
            namespace=namespace,
            target_minimum_version=target_minimum_version,
            indexing_settings=indexing_settings,
            trigger=trigger,
            enabled=enabled,
            created_at=created_at,
            updated_at=updated_at,
            last_executed_at=last_executed_at,
            next_execution_at=next_execution_at,
        )

        indexing_schedule_dto.additional_properties = d
        return indexing_schedule_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
