from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="IndexerDto")


@_attrs_define
class IndexerDto:
    """Indexer service details, including supported index version range and capabilities.

    Attributes:
        indexer_rid (str | Unset):
        target_index_version (int | Unset):
        minimum_supported_index_version (int | Unset):
    """

    indexer_rid: str | Unset = UNSET
    target_index_version: int | Unset = UNSET
    minimum_supported_index_version: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        indexer_rid = self.indexer_rid

        target_index_version = self.target_index_version

        minimum_supported_index_version = self.minimum_supported_index_version

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if indexer_rid is not UNSET:
            field_dict["indexerRid"] = indexer_rid
        if target_index_version is not UNSET:
            field_dict["targetIndexVersion"] = target_index_version
        if minimum_supported_index_version is not UNSET:
            field_dict["minimumSupportedIndexVersion"] = minimum_supported_index_version

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        indexer_rid = d.pop("indexerRid", UNSET)

        target_index_version = d.pop("targetIndexVersion", UNSET)

        minimum_supported_index_version = d.pop("minimumSupportedIndexVersion", UNSET)

        indexer_dto = cls(
            indexer_rid=indexer_rid,
            target_index_version=target_index_version,
            minimum_supported_index_version=minimum_supported_index_version,
        )

        indexer_dto.additional_properties = d
        return indexer_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
