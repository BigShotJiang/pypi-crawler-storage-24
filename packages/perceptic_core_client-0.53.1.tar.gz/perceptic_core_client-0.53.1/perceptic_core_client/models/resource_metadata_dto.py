from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.resource_type_dto import ResourceTypeDto
from ..types import UNSET, Unset

T = TypeVar("T", bound="ResourceMetadataDto")


@_attrs_define
class ResourceMetadataDto:
    """
    Attributes:
        files_system_rid (str | Unset):
        resource_id (str | Unset):
        uri (str | Unset):
        name (str | Unset):
        type_ (ResourceTypeDto | Unset):
        path (str | Unset):
        extension (None | str | Unset):
        size_in_bytes (int | None | Unset):
        last_modified (datetime.datetime | None | Unset):
        etag (None | str | Unset):
        tags (list[str] | Unset):
    """

    files_system_rid: str | Unset = UNSET
    resource_id: str | Unset = UNSET
    uri: str | Unset = UNSET
    name: str | Unset = UNSET
    type_: ResourceTypeDto | Unset = UNSET
    path: str | Unset = UNSET
    extension: None | str | Unset = UNSET
    size_in_bytes: int | None | Unset = UNSET
    last_modified: datetime.datetime | None | Unset = UNSET
    etag: None | str | Unset = UNSET
    tags: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        files_system_rid = self.files_system_rid

        resource_id = self.resource_id

        uri = self.uri

        name = self.name

        type_: str | Unset = UNSET
        if not isinstance(self.type_, Unset):
            type_ = self.type_.value

        path = self.path

        extension: None | str | Unset
        if isinstance(self.extension, Unset):
            extension = UNSET
        else:
            extension = self.extension

        size_in_bytes: int | None | Unset
        if isinstance(self.size_in_bytes, Unset):
            size_in_bytes = UNSET
        else:
            size_in_bytes = self.size_in_bytes

        last_modified: None | str | Unset
        if isinstance(self.last_modified, Unset):
            last_modified = UNSET
        elif isinstance(self.last_modified, datetime.datetime):
            last_modified = self.last_modified.isoformat()
        else:
            last_modified = self.last_modified

        etag: None | str | Unset
        if isinstance(self.etag, Unset):
            etag = UNSET
        else:
            etag = self.etag

        tags: list[str] | Unset = UNSET
        if not isinstance(self.tags, Unset):
            tags = self.tags

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if files_system_rid is not UNSET:
            field_dict["filesSystemRid"] = files_system_rid
        if resource_id is not UNSET:
            field_dict["resourceId"] = resource_id
        if uri is not UNSET:
            field_dict["uri"] = uri
        if name is not UNSET:
            field_dict["name"] = name
        if type_ is not UNSET:
            field_dict["type"] = type_
        if path is not UNSET:
            field_dict["path"] = path
        if extension is not UNSET:
            field_dict["extension"] = extension
        if size_in_bytes is not UNSET:
            field_dict["sizeInBytes"] = size_in_bytes
        if last_modified is not UNSET:
            field_dict["lastModified"] = last_modified
        if etag is not UNSET:
            field_dict["etag"] = etag
        if tags is not UNSET:
            field_dict["tags"] = tags

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        files_system_rid = d.pop("filesSystemRid", UNSET)

        resource_id = d.pop("resourceId", UNSET)

        uri = d.pop("uri", UNSET)

        name = d.pop("name", UNSET)

        _type_ = d.pop("type", UNSET)
        type_: ResourceTypeDto | Unset
        if isinstance(_type_, Unset):
            type_ = UNSET
        else:
            type_ = ResourceTypeDto(_type_)

        path = d.pop("path", UNSET)

        def _parse_extension(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        extension = _parse_extension(d.pop("extension", UNSET))

        def _parse_size_in_bytes(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        size_in_bytes = _parse_size_in_bytes(d.pop("sizeInBytes", UNSET))

        def _parse_last_modified(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_modified_type_0 = isoparse(data)

                return last_modified_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        last_modified = _parse_last_modified(d.pop("lastModified", UNSET))

        def _parse_etag(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        etag = _parse_etag(d.pop("etag", UNSET))

        tags = cast(list[str], d.pop("tags", UNSET))

        resource_metadata_dto = cls(
            files_system_rid=files_system_rid,
            resource_id=resource_id,
            uri=uri,
            name=name,
            type_=type_,
            path=path,
            extension=extension,
            size_in_bytes=size_in_bytes,
            last_modified=last_modified,
            etag=etag,
            tags=tags,
        )

        resource_metadata_dto.additional_properties = d
        return resource_metadata_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
