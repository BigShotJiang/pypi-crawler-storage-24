from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="UploadResourceResponseV2")


@_attrs_define
class UploadResourceResponseV2:
    """
    Attributes:
        resource_id (str | Unset):
        uri (str | Unset):
        size_in_bytes (int | Unset):
    """

    resource_id: str | Unset = UNSET
    uri: str | Unset = UNSET
    size_in_bytes: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        resource_id = self.resource_id

        uri = self.uri

        size_in_bytes = self.size_in_bytes

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if resource_id is not UNSET:
            field_dict["resourceId"] = resource_id
        if uri is not UNSET:
            field_dict["uri"] = uri
        if size_in_bytes is not UNSET:
            field_dict["sizeInBytes"] = size_in_bytes

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        resource_id = d.pop("resourceId", UNSET)

        uri = d.pop("uri", UNSET)

        size_in_bytes = d.pop("sizeInBytes", UNSET)

        upload_resource_response_v2 = cls(
            resource_id=resource_id,
            uri=uri,
            size_in_bytes=size_in_bytes,
        )

        upload_resource_response_v2.additional_properties = d
        return upload_resource_response_v2

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
