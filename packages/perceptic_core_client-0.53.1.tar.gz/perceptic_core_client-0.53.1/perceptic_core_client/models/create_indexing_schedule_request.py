from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.create_indexing_schedule_request_indexing_settings import (
        CreateIndexingScheduleRequestIndexingSettings,
    )
    from ..models.cron_trigger import CronTrigger
    from ..models.interval_trigger import IntervalTrigger
    from ..models.on_upload_trigger import OnUploadTrigger


T = TypeVar("T", bound="CreateIndexingScheduleRequest")


@_attrs_define
class CreateIndexingScheduleRequest:
    """
    Attributes:
        name (str): Display name for the schedule Example: Daily CSV indexing.
        indexer_rid (str): RID of the indexer to use Example: ri.indexer..instance.indexer-csv-processor.
        target_uri (str): URI of folder or filesystem to index Example: prtc://ri.perceptic..instance.fs-data-
            lake/documents.
        namespace (str): Namespace for indexing Example: production.
        trigger (CronTrigger | IntervalTrigger | OnUploadTrigger):
        description (str | Unset): Optional description of the schedule's purpose
        target_minimum_version (int | Unset): Minimum indexer version required Example: 1.
        indexing_settings (CreateIndexingScheduleRequestIndexingSettings | Unset): Indexer-specific settings
        enabled (bool | Unset): Whether the schedule is enabled Example: True.
    """

    name: str
    indexer_rid: str
    target_uri: str
    namespace: str
    trigger: CronTrigger | IntervalTrigger | OnUploadTrigger
    description: str | Unset = UNSET
    target_minimum_version: int | Unset = UNSET
    indexing_settings: CreateIndexingScheduleRequestIndexingSettings | Unset = UNSET
    enabled: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.cron_trigger import CronTrigger
        from ..models.on_upload_trigger import OnUploadTrigger

        name = self.name

        indexer_rid = self.indexer_rid

        target_uri = self.target_uri

        namespace = self.namespace

        trigger: dict[str, Any]
        if isinstance(self.trigger, OnUploadTrigger):
            trigger = self.trigger.to_dict()
        elif isinstance(self.trigger, CronTrigger):
            trigger = self.trigger.to_dict()
        else:
            trigger = self.trigger.to_dict()

        description = self.description

        target_minimum_version = self.target_minimum_version

        indexing_settings: dict[str, Any] | Unset = UNSET
        if not isinstance(self.indexing_settings, Unset):
            indexing_settings = self.indexing_settings.to_dict()

        enabled = self.enabled

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "indexerRid": indexer_rid,
                "targetUri": target_uri,
                "namespace": namespace,
                "trigger": trigger,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if target_minimum_version is not UNSET:
            field_dict["targetMinimumVersion"] = target_minimum_version
        if indexing_settings is not UNSET:
            field_dict["indexingSettings"] = indexing_settings
        if enabled is not UNSET:
            field_dict["enabled"] = enabled

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.create_indexing_schedule_request_indexing_settings import (
            CreateIndexingScheduleRequestIndexingSettings,
        )
        from ..models.cron_trigger import CronTrigger
        from ..models.interval_trigger import IntervalTrigger
        from ..models.on_upload_trigger import OnUploadTrigger

        d = dict(src_dict)
        name = d.pop("name")

        indexer_rid = d.pop("indexerRid")

        target_uri = d.pop("targetUri")

        namespace = d.pop("namespace")

        def _parse_trigger(data: object) -> CronTrigger | IntervalTrigger | OnUploadTrigger:
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                componentsschemas_schedule_trigger_type_0 = OnUploadTrigger.from_dict(data)

                return componentsschemas_schedule_trigger_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                componentsschemas_schedule_trigger_type_1 = CronTrigger.from_dict(data)

                return componentsschemas_schedule_trigger_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            componentsschemas_schedule_trigger_type_2 = IntervalTrigger.from_dict(data)

            return componentsschemas_schedule_trigger_type_2

        trigger = _parse_trigger(d.pop("trigger"))

        description = d.pop("description", UNSET)

        target_minimum_version = d.pop("targetMinimumVersion", UNSET)

        _indexing_settings = d.pop("indexingSettings", UNSET)
        indexing_settings: CreateIndexingScheduleRequestIndexingSettings | Unset
        if isinstance(_indexing_settings, Unset):
            indexing_settings = UNSET
        else:
            indexing_settings = CreateIndexingScheduleRequestIndexingSettings.from_dict(_indexing_settings)

        enabled = d.pop("enabled", UNSET)

        create_indexing_schedule_request = cls(
            name=name,
            indexer_rid=indexer_rid,
            target_uri=target_uri,
            namespace=namespace,
            trigger=trigger,
            description=description,
            target_minimum_version=target_minimum_version,
            indexing_settings=indexing_settings,
            enabled=enabled,
        )

        create_indexing_schedule_request.additional_properties = d
        return create_indexing_schedule_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
