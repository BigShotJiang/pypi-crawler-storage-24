from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.progress_event_1_payload import ProgressEvent1Payload


T = TypeVar("T", bound="ProgressEvent1")


@_attrs_define
class ProgressEvent1:
    """
    Attributes:
        sequence (int | Unset):
        payload (ProgressEvent1Payload | Unset):
        created_at (datetime.datetime | Unset):
        type_ (str | Unset):
    """

    sequence: int | Unset = UNSET
    payload: ProgressEvent1Payload | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    type_: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        sequence = self.sequence

        payload: dict[str, Any] | Unset = UNSET
        if not isinstance(self.payload, Unset):
            payload = self.payload.to_dict()

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        type_ = self.type_

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if sequence is not UNSET:
            field_dict["sequence"] = sequence
        if payload is not UNSET:
            field_dict["payload"] = payload
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at
        if type_ is not UNSET:
            field_dict["type"] = type_

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.progress_event_1_payload import ProgressEvent1Payload

        d = dict(src_dict)
        sequence = d.pop("sequence", UNSET)

        _payload = d.pop("payload", UNSET)
        payload: ProgressEvent1Payload | Unset
        if isinstance(_payload, Unset):
            payload = UNSET
        else:
            payload = ProgressEvent1Payload.from_dict(_payload)

        _created_at = d.pop("createdAt", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        type_ = d.pop("type", UNSET)

        progress_event_1 = cls(
            sequence=sequence,
            payload=payload,
            created_at=created_at,
            type_=type_,
        )

        progress_event_1.additional_properties = d
        return progress_event_1

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
