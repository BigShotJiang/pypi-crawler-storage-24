from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.get_workers_response_worker_identifiers import GetWorkersResponseWorkerIdentifiers


T = TypeVar("T", bound="GetWorkersResponse")


@_attrs_define
class GetWorkersResponse:
    """
    Attributes:
        worker_identifiers (GetWorkersResponseWorkerIdentifiers | Unset):
    """

    worker_identifiers: GetWorkersResponseWorkerIdentifiers | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        worker_identifiers: dict[str, Any] | Unset = UNSET
        if not isinstance(self.worker_identifiers, Unset):
            worker_identifiers = self.worker_identifiers.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if worker_identifiers is not UNSET:
            field_dict["workerIdentifiers"] = worker_identifiers

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.get_workers_response_worker_identifiers import GetWorkersResponseWorkerIdentifiers

        d = dict(src_dict)
        _worker_identifiers = d.pop("workerIdentifiers", UNSET)
        worker_identifiers: GetWorkersResponseWorkerIdentifiers | Unset
        if isinstance(_worker_identifiers, Unset):
            worker_identifiers = UNSET
        else:
            worker_identifiers = GetWorkersResponseWorkerIdentifiers.from_dict(_worker_identifiers)

        get_workers_response = cls(
            worker_identifiers=worker_identifiers,
        )

        get_workers_response.additional_properties = d
        return get_workers_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
