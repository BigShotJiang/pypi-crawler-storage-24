from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.indexer_dto import IndexerDto


T = TypeVar("T", bound="GetIndexerResponse")


@_attrs_define
class GetIndexerResponse:
    """
    Attributes:
        indexer (IndexerDto | Unset): Indexer service details, including supported index version range and capabilities.
    """

    indexer: IndexerDto | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        indexer: dict[str, Any] | Unset = UNSET
        if not isinstance(self.indexer, Unset):
            indexer = self.indexer.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if indexer is not UNSET:
            field_dict["indexer"] = indexer

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.indexer_dto import IndexerDto

        d = dict(src_dict)
        _indexer = d.pop("indexer", UNSET)
        indexer: IndexerDto | Unset
        if isinstance(_indexer, Unset):
            indexer = UNSET
        else:
            indexer = IndexerDto.from_dict(_indexer)

        get_indexer_response = cls(
            indexer=indexer,
        )

        get_indexer_response.additional_properties = d
        return get_indexer_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
