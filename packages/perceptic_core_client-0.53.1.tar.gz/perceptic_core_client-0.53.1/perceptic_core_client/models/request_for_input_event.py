from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.request_for_input_event_provided_data_type_0 import RequestForInputEventProvidedDataType0
    from ..models.request_for_input_event_requested_data import RequestForInputEventRequestedData


T = TypeVar("T", bound="RequestForInputEvent")


@_attrs_define
class RequestForInputEvent:
    """
    Attributes:
        sequence (int | Unset):
        requested_data (RequestForInputEventRequestedData | Unset):
        provided_data (None | RequestForInputEventProvidedDataType0 | Unset):
        attribution (None | str | Unset):
        created_at (datetime.datetime | Unset):
        type_ (str | Unset):
    """

    sequence: int | Unset = UNSET
    requested_data: RequestForInputEventRequestedData | Unset = UNSET
    provided_data: None | RequestForInputEventProvidedDataType0 | Unset = UNSET
    attribution: None | str | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    type_: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.request_for_input_event_provided_data_type_0 import RequestForInputEventProvidedDataType0

        sequence = self.sequence

        requested_data: dict[str, Any] | Unset = UNSET
        if not isinstance(self.requested_data, Unset):
            requested_data = self.requested_data.to_dict()

        provided_data: dict[str, Any] | None | Unset
        if isinstance(self.provided_data, Unset):
            provided_data = UNSET
        elif isinstance(self.provided_data, RequestForInputEventProvidedDataType0):
            provided_data = self.provided_data.to_dict()
        else:
            provided_data = self.provided_data

        attribution: None | str | Unset
        if isinstance(self.attribution, Unset):
            attribution = UNSET
        else:
            attribution = self.attribution

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        type_ = self.type_

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if sequence is not UNSET:
            field_dict["sequence"] = sequence
        if requested_data is not UNSET:
            field_dict["requestedData"] = requested_data
        if provided_data is not UNSET:
            field_dict["providedData"] = provided_data
        if attribution is not UNSET:
            field_dict["attribution"] = attribution
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at
        if type_ is not UNSET:
            field_dict["type"] = type_

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.request_for_input_event_provided_data_type_0 import RequestForInputEventProvidedDataType0
        from ..models.request_for_input_event_requested_data import RequestForInputEventRequestedData

        d = dict(src_dict)
        sequence = d.pop("sequence", UNSET)

        _requested_data = d.pop("requestedData", UNSET)
        requested_data: RequestForInputEventRequestedData | Unset
        if isinstance(_requested_data, Unset):
            requested_data = UNSET
        else:
            requested_data = RequestForInputEventRequestedData.from_dict(_requested_data)

        def _parse_provided_data(data: object) -> None | RequestForInputEventProvidedDataType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                provided_data_type_0 = RequestForInputEventProvidedDataType0.from_dict(data)

                return provided_data_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | RequestForInputEventProvidedDataType0 | Unset, data)

        provided_data = _parse_provided_data(d.pop("providedData", UNSET))

        def _parse_attribution(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        attribution = _parse_attribution(d.pop("attribution", UNSET))

        _created_at = d.pop("createdAt", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        type_ = d.pop("type", UNSET)

        request_for_input_event = cls(
            sequence=sequence,
            requested_data=requested_data,
            provided_data=provided_data,
            attribution=attribution,
            created_at=created_at,
            type_=type_,
        )

        request_for_input_event.additional_properties = d
        return request_for_input_event

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
