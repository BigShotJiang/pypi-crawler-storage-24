from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="ImageDetectionBoxApiDto")


@_attrs_define
class ImageDetectionBoxApiDto:
    """
    Attributes:
        x_min (int | Unset):
        y_min (int | Unset):
        x_max (int | Unset):
        y_max (int | Unset):
        label (str | Unset):
        confidence (float | Unset):
    """

    x_min: int | Unset = UNSET
    y_min: int | Unset = UNSET
    x_max: int | Unset = UNSET
    y_max: int | Unset = UNSET
    label: str | Unset = UNSET
    confidence: float | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        x_min = self.x_min

        y_min = self.y_min

        x_max = self.x_max

        y_max = self.y_max

        label = self.label

        confidence = self.confidence

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if x_min is not UNSET:
            field_dict["xMin"] = x_min
        if y_min is not UNSET:
            field_dict["yMin"] = y_min
        if x_max is not UNSET:
            field_dict["xMax"] = x_max
        if y_max is not UNSET:
            field_dict["yMax"] = y_max
        if label is not UNSET:
            field_dict["label"] = label
        if confidence is not UNSET:
            field_dict["confidence"] = confidence

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        x_min = d.pop("xMin", UNSET)

        y_min = d.pop("yMin", UNSET)

        x_max = d.pop("xMax", UNSET)

        y_max = d.pop("yMax", UNSET)

        label = d.pop("label", UNSET)

        confidence = d.pop("confidence", UNSET)

        image_detection_box_api_dto = cls(
            x_min=x_min,
            y_min=y_min,
            x_max=x_max,
            y_max=y_max,
            label=label,
            confidence=confidence,
        )

        image_detection_box_api_dto.additional_properties = d
        return image_detection_box_api_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
