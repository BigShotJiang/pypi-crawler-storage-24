from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.run_status_dto import RunStatusDto
from ..types import UNSET, Unset

T = TypeVar("T", bound="GetWorkerStatusResponse")


@_attrs_define
class GetWorkerStatusResponse:
    """
    Attributes:
        run_status (RunStatusDto | Unset):
    """

    run_status: RunStatusDto | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        run_status: str | Unset = UNSET
        if not isinstance(self.run_status, Unset):
            run_status = self.run_status.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if run_status is not UNSET:
            field_dict["runStatus"] = run_status

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _run_status = d.pop("runStatus", UNSET)
        run_status: RunStatusDto | Unset
        if isinstance(_run_status, Unset):
            run_status = UNSET
        else:
            run_status = RunStatusDto(_run_status)

        get_worker_status_response = cls(
            run_status=run_status,
        )

        get_worker_status_response.additional_properties = d
        return get_worker_status_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
