from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.azure_blob_connection_settings_api_dto import AzureBlobConnectionSettingsApiDto
    from ..models.s3_connection_settings_api_dto import S3ConnectionSettingsApiDto


T = TypeVar("T", bound="ConnectionApiDto")


@_attrs_define
class ConnectionApiDto:
    """
    Attributes:
        rid (str | Unset):
        name (str | Unset):
        description (str | Unset):
        user_id (str | Unset):
        settings (AzureBlobConnectionSettingsApiDto | S3ConnectionSettingsApiDto | Unset):
    """

    rid: str | Unset = UNSET
    name: str | Unset = UNSET
    description: str | Unset = UNSET
    user_id: str | Unset = UNSET
    settings: AzureBlobConnectionSettingsApiDto | S3ConnectionSettingsApiDto | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.s3_connection_settings_api_dto import S3ConnectionSettingsApiDto

        rid = self.rid

        name = self.name

        description = self.description

        user_id = self.user_id

        settings: dict[str, Any] | Unset
        if isinstance(self.settings, Unset):
            settings = UNSET
        elif isinstance(self.settings, S3ConnectionSettingsApiDto):
            settings = self.settings.to_dict()
        else:
            settings = self.settings.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if rid is not UNSET:
            field_dict["rid"] = rid
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if user_id is not UNSET:
            field_dict["userId"] = user_id
        if settings is not UNSET:
            field_dict["settings"] = settings

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.azure_blob_connection_settings_api_dto import AzureBlobConnectionSettingsApiDto
        from ..models.s3_connection_settings_api_dto import S3ConnectionSettingsApiDto

        d = dict(src_dict)
        rid = d.pop("rid", UNSET)

        name = d.pop("name", UNSET)

        description = d.pop("description", UNSET)

        user_id = d.pop("userId", UNSET)

        def _parse_settings(data: object) -> AzureBlobConnectionSettingsApiDto | S3ConnectionSettingsApiDto | Unset:
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                componentsschemas_connection_settings_api_dto_type_0 = S3ConnectionSettingsApiDto.from_dict(data)

                return componentsschemas_connection_settings_api_dto_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            componentsschemas_connection_settings_api_dto_type_1 = AzureBlobConnectionSettingsApiDto.from_dict(data)

            return componentsschemas_connection_settings_api_dto_type_1

        settings = _parse_settings(d.pop("settings", UNSET))

        connection_api_dto = cls(
            rid=rid,
            name=name,
            description=description,
            user_id=user_id,
            settings=settings,
        )

        connection_api_dto.additional_properties = d
        return connection_api_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
