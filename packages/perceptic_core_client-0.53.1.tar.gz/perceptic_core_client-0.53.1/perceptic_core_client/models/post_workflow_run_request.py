from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.post_workflow_run_request_inputs import PostWorkflowRunRequestInputs


T = TypeVar("T", bound="PostWorkflowRunRequest")


@_attrs_define
class PostWorkflowRunRequest:
    """
    Attributes:
        inputs (PostWorkflowRunRequestInputs | Unset):
    """

    inputs: PostWorkflowRunRequestInputs | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        inputs: dict[str, Any] | Unset = UNSET
        if not isinstance(self.inputs, Unset):
            inputs = self.inputs.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if inputs is not UNSET:
            field_dict["inputs"] = inputs

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.post_workflow_run_request_inputs import PostWorkflowRunRequestInputs

        d = dict(src_dict)
        _inputs = d.pop("inputs", UNSET)
        inputs: PostWorkflowRunRequestInputs | Unset
        if isinstance(_inputs, Unset):
            inputs = UNSET
        else:
            inputs = PostWorkflowRunRequestInputs.from_dict(_inputs)

        post_workflow_run_request = cls(
            inputs=inputs,
        )

        post_workflow_run_request.additional_properties = d
        return post_workflow_run_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
