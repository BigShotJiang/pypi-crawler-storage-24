from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.connection_api_dto import ConnectionApiDto


T = TypeVar("T", bound="GetConnectionResponse")


@_attrs_define
class GetConnectionResponse:
    """
    Attributes:
        connection (ConnectionApiDto | Unset):
    """

    connection: ConnectionApiDto | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        connection: dict[str, Any] | Unset = UNSET
        if not isinstance(self.connection, Unset):
            connection = self.connection.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if connection is not UNSET:
            field_dict["connection"] = connection

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.connection_api_dto import ConnectionApiDto

        d = dict(src_dict)
        _connection = d.pop("connection", UNSET)
        connection: ConnectionApiDto | Unset
        if isinstance(_connection, Unset):
            connection = UNSET
        else:
            connection = ConnectionApiDto.from_dict(_connection)

        get_connection_response = cls(
            connection=connection,
        )

        get_connection_response.additional_properties = d
        return get_connection_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
