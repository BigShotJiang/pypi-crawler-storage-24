from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_indexing_schedule_response import GetIndexingScheduleResponse
from ...types import Response


def _get_kwargs(
    schedule_rid: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/indexing/schedules/{schedule_rid}".format(
            schedule_rid=quote(str(schedule_rid), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | GetIndexingScheduleResponse | None:
    if response.status_code == 200:
        response_200 = GetIndexingScheduleResponse.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | GetIndexingScheduleResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    schedule_rid: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[Any | GetIndexingScheduleResponse]:
    """Get an indexing schedule

    Args:
        schedule_rid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | GetIndexingScheduleResponse]
    """

    kwargs = _get_kwargs(
        schedule_rid=schedule_rid,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    schedule_rid: str,
    *,
    client: AuthenticatedClient | Client,
) -> Any | GetIndexingScheduleResponse | None:
    """Get an indexing schedule

    Args:
        schedule_rid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | GetIndexingScheduleResponse
    """

    return sync_detailed(
        schedule_rid=schedule_rid,
        client=client,
    ).parsed


async def asyncio_detailed(
    schedule_rid: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[Any | GetIndexingScheduleResponse]:
    """Get an indexing schedule

    Args:
        schedule_rid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | GetIndexingScheduleResponse]
    """

    kwargs = _get_kwargs(
        schedule_rid=schedule_rid,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    schedule_rid: str,
    *,
    client: AuthenticatedClient | Client,
) -> Any | GetIndexingScheduleResponse | None:
    """Get an indexing schedule

    Args:
        schedule_rid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | GetIndexingScheduleResponse
    """

    return (
        await asyncio_detailed(
            schedule_rid=schedule_rid,
            client=client,
        )
    ).parsed
