from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.list_indexing_schedules_response import ListIndexingSchedulesResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    enabled: bool | Unset = UNSET,
    file_system_rid: str | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["enabled"] = enabled

    params["fileSystemRid"] = file_system_rid

    params["limit"] = limit

    params["offset"] = offset

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/indexing/schedules",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ListIndexingSchedulesResponse | None:
    if response.status_code == 200:
        response_200 = ListIndexingSchedulesResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ListIndexingSchedulesResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    enabled: bool | Unset = UNSET,
    file_system_rid: str | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> Response[ListIndexingSchedulesResponse]:
    """List indexing schedules

    Args:
        enabled (bool | Unset):
        file_system_rid (str | Unset):
        limit (int | Unset):  Default: 100.
        offset (int | Unset):  Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ListIndexingSchedulesResponse]
    """

    kwargs = _get_kwargs(
        enabled=enabled,
        file_system_rid=file_system_rid,
        limit=limit,
        offset=offset,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    enabled: bool | Unset = UNSET,
    file_system_rid: str | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> ListIndexingSchedulesResponse | None:
    """List indexing schedules

    Args:
        enabled (bool | Unset):
        file_system_rid (str | Unset):
        limit (int | Unset):  Default: 100.
        offset (int | Unset):  Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ListIndexingSchedulesResponse
    """

    return sync_detailed(
        client=client,
        enabled=enabled,
        file_system_rid=file_system_rid,
        limit=limit,
        offset=offset,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    enabled: bool | Unset = UNSET,
    file_system_rid: str | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> Response[ListIndexingSchedulesResponse]:
    """List indexing schedules

    Args:
        enabled (bool | Unset):
        file_system_rid (str | Unset):
        limit (int | Unset):  Default: 100.
        offset (int | Unset):  Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ListIndexingSchedulesResponse]
    """

    kwargs = _get_kwargs(
        enabled=enabled,
        file_system_rid=file_system_rid,
        limit=limit,
        offset=offset,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    enabled: bool | Unset = UNSET,
    file_system_rid: str | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> ListIndexingSchedulesResponse | None:
    """List indexing schedules

    Args:
        enabled (bool | Unset):
        file_system_rid (str | Unset):
        limit (int | Unset):  Default: 100.
        offset (int | Unset):  Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ListIndexingSchedulesResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            enabled=enabled,
            file_system_rid=file_system_rid,
            limit=limit,
            offset=offset,
        )
    ).parsed
