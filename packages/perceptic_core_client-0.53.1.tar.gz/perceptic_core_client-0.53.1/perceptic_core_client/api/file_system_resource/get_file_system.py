from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.managed_file_system_api_dto import ManagedFileSystemApiDto
from ...models.remote_file_system_api_dto import RemoteFileSystemApiDto
from ...types import Response


def _get_kwargs(
    file_system_rid: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/file-systems/{file_system_rid}".format(
            file_system_rid=quote(str(file_system_rid), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ManagedFileSystemApiDto | RemoteFileSystemApiDto | None:
    if response.status_code == 200:

        def _parse_response_200(data: object) -> ManagedFileSystemApiDto | RemoteFileSystemApiDto:
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                componentsschemas_file_system_api_dto_type_0 = RemoteFileSystemApiDto.from_dict(data)

                return componentsschemas_file_system_api_dto_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            componentsschemas_file_system_api_dto_type_1 = ManagedFileSystemApiDto.from_dict(data)

            return componentsschemas_file_system_api_dto_type_1

        response_200 = _parse_response_200(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ManagedFileSystemApiDto | RemoteFileSystemApiDto]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    file_system_rid: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[ManagedFileSystemApiDto | RemoteFileSystemApiDto]:
    """Get File System

    Args:
        file_system_rid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ManagedFileSystemApiDto | RemoteFileSystemApiDto]
    """

    kwargs = _get_kwargs(
        file_system_rid=file_system_rid,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    file_system_rid: str,
    *,
    client: AuthenticatedClient | Client,
) -> ManagedFileSystemApiDto | RemoteFileSystemApiDto | None:
    """Get File System

    Args:
        file_system_rid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ManagedFileSystemApiDto | RemoteFileSystemApiDto
    """

    return sync_detailed(
        file_system_rid=file_system_rid,
        client=client,
    ).parsed


async def asyncio_detailed(
    file_system_rid: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[ManagedFileSystemApiDto | RemoteFileSystemApiDto]:
    """Get File System

    Args:
        file_system_rid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ManagedFileSystemApiDto | RemoteFileSystemApiDto]
    """

    kwargs = _get_kwargs(
        file_system_rid=file_system_rid,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    file_system_rid: str,
    *,
    client: AuthenticatedClient | Client,
) -> ManagedFileSystemApiDto | RemoteFileSystemApiDto | None:
    """Get File System

    Args:
        file_system_rid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ManagedFileSystemApiDto | RemoteFileSystemApiDto
    """

    return (
        await asyncio_detailed(
            file_system_rid=file_system_rid,
            client=client,
        )
    ).parsed
