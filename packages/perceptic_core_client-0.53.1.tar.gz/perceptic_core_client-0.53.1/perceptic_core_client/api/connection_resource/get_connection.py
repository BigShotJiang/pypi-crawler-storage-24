from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_connection_response import GetConnectionResponse
from ...types import Response


def _get_kwargs(
    connection_rid: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/connections/{connection_rid}".format(
            connection_rid=quote(str(connection_rid), safe=""),
        ),
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> GetConnectionResponse | None:
    if response.status_code == 200:
        response_200 = GetConnectionResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[GetConnectionResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    connection_rid: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[GetConnectionResponse]:
    """Get Connection

    Args:
        connection_rid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetConnectionResponse]
    """

    kwargs = _get_kwargs(
        connection_rid=connection_rid,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    connection_rid: str,
    *,
    client: AuthenticatedClient | Client,
) -> GetConnectionResponse | None:
    """Get Connection

    Args:
        connection_rid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetConnectionResponse
    """

    return sync_detailed(
        connection_rid=connection_rid,
        client=client,
    ).parsed


async def asyncio_detailed(
    connection_rid: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[GetConnectionResponse]:
    """Get Connection

    Args:
        connection_rid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetConnectionResponse]
    """

    kwargs = _get_kwargs(
        connection_rid=connection_rid,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    connection_rid: str,
    *,
    client: AuthenticatedClient | Client,
) -> GetConnectionResponse | None:
    """Get Connection

    Args:
        connection_rid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetConnectionResponse
    """

    return (
        await asyncio_detailed(
            connection_rid=connection_rid,
            client=client,
        )
    ).parsed
