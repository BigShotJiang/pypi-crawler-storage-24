from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.paged_list_file_system_response import PagedListFileSystemResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    page_size: int | Unset = 500,
    resume_token: str | Unset = UNSET,
    uri: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["pageSize"] = page_size

    params["resumeToken"] = resume_token

    params["uri"] = uri

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/resources/files",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> PagedListFileSystemResponse | None:
    if response.status_code == 200:
        response_200 = PagedListFileSystemResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[PagedListFileSystemResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    page_size: int | Unset = 500,
    resume_token: str | Unset = UNSET,
    uri: str | Unset = UNSET,
) -> Response[PagedListFileSystemResponse]:
    """List Files

    Args:
        page_size (int | Unset):  Default: 500.
        resume_token (str | Unset):
        uri (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PagedListFileSystemResponse]
    """

    kwargs = _get_kwargs(
        page_size=page_size,
        resume_token=resume_token,
        uri=uri,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    page_size: int | Unset = 500,
    resume_token: str | Unset = UNSET,
    uri: str | Unset = UNSET,
) -> PagedListFileSystemResponse | None:
    """List Files

    Args:
        page_size (int | Unset):  Default: 500.
        resume_token (str | Unset):
        uri (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PagedListFileSystemResponse
    """

    return sync_detailed(
        client=client,
        page_size=page_size,
        resume_token=resume_token,
        uri=uri,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    page_size: int | Unset = 500,
    resume_token: str | Unset = UNSET,
    uri: str | Unset = UNSET,
) -> Response[PagedListFileSystemResponse]:
    """List Files

    Args:
        page_size (int | Unset):  Default: 500.
        resume_token (str | Unset):
        uri (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PagedListFileSystemResponse]
    """

    kwargs = _get_kwargs(
        page_size=page_size,
        resume_token=resume_token,
        uri=uri,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    page_size: int | Unset = 500,
    resume_token: str | Unset = UNSET,
    uri: str | Unset = UNSET,
) -> PagedListFileSystemResponse | None:
    """List Files

    Args:
        page_size (int | Unset):  Default: 500.
        resume_token (str | Unset):
        uri (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PagedListFileSystemResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            page_size=page_size,
            resume_token=resume_token,
            uri=uri,
        )
    ).parsed
