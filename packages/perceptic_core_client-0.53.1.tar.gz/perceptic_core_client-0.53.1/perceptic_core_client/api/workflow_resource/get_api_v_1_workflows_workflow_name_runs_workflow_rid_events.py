from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_workflow_events_response import GetWorkflowEventsResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workflow_name: str,
    workflow_rid: str,
    *,
    next_page_token: str | Unset = UNSET,
    page_size: int | Unset = 50,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["nextPageToken"] = next_page_token

    params["pageSize"] = page_size

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/workflows/{workflow_name}/runs/{workflow_rid}/events".format(
            workflow_name=quote(str(workflow_name), safe=""),
            workflow_rid=quote(str(workflow_rid), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> GetWorkflowEventsResponse | None:
    if response.status_code == 200:
        response_200 = GetWorkflowEventsResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[GetWorkflowEventsResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workflow_name: str,
    workflow_rid: str,
    *,
    client: AuthenticatedClient | Client,
    next_page_token: str | Unset = UNSET,
    page_size: int | Unset = 50,
) -> Response[GetWorkflowEventsResponse]:
    """Get Run Events

    Args:
        workflow_name (str):
        workflow_rid (str):
        next_page_token (str | Unset):
        page_size (int | Unset):  Default: 50.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetWorkflowEventsResponse]
    """

    kwargs = _get_kwargs(
        workflow_name=workflow_name,
        workflow_rid=workflow_rid,
        next_page_token=next_page_token,
        page_size=page_size,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workflow_name: str,
    workflow_rid: str,
    *,
    client: AuthenticatedClient | Client,
    next_page_token: str | Unset = UNSET,
    page_size: int | Unset = 50,
) -> GetWorkflowEventsResponse | None:
    """Get Run Events

    Args:
        workflow_name (str):
        workflow_rid (str):
        next_page_token (str | Unset):
        page_size (int | Unset):  Default: 50.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetWorkflowEventsResponse
    """

    return sync_detailed(
        workflow_name=workflow_name,
        workflow_rid=workflow_rid,
        client=client,
        next_page_token=next_page_token,
        page_size=page_size,
    ).parsed


async def asyncio_detailed(
    workflow_name: str,
    workflow_rid: str,
    *,
    client: AuthenticatedClient | Client,
    next_page_token: str | Unset = UNSET,
    page_size: int | Unset = 50,
) -> Response[GetWorkflowEventsResponse]:
    """Get Run Events

    Args:
        workflow_name (str):
        workflow_rid (str):
        next_page_token (str | Unset):
        page_size (int | Unset):  Default: 50.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetWorkflowEventsResponse]
    """

    kwargs = _get_kwargs(
        workflow_name=workflow_name,
        workflow_rid=workflow_rid,
        next_page_token=next_page_token,
        page_size=page_size,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workflow_name: str,
    workflow_rid: str,
    *,
    client: AuthenticatedClient | Client,
    next_page_token: str | Unset = UNSET,
    page_size: int | Unset = 50,
) -> GetWorkflowEventsResponse | None:
    """Get Run Events

    Args:
        workflow_name (str):
        workflow_rid (str):
        next_page_token (str | Unset):
        page_size (int | Unset):  Default: 50.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetWorkflowEventsResponse
    """

    return (
        await asyncio_detailed(
            workflow_name=workflow_name,
            workflow_rid=workflow_rid,
            client=client,
            next_page_token=next_page_token,
            page_size=page_size,
        )
    ).parsed
