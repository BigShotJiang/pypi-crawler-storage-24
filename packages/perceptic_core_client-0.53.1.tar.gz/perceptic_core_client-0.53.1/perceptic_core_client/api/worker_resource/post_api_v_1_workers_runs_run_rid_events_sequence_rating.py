from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.post_rating_request import PostRatingRequest
from ...models.post_run_event_rating_response import PostRunEventRatingResponse
from ...types import Response


def _get_kwargs(
    run_rid: str,
    sequence: int,
    *,
    body: PostRatingRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/workers/runs/{run_rid}/events/{sequence}/rating".format(
            run_rid=quote(str(run_rid), safe=""),
            sequence=quote(str(sequence), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | PostRunEventRatingResponse | None:
    if response.status_code == 200:
        response_200 = PostRunEventRatingResponse.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = cast(Any, None)
        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | PostRunEventRatingResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    run_rid: str,
    sequence: int,
    *,
    client: AuthenticatedClient | Client,
    body: PostRatingRequest,
) -> Response[Any | PostRunEventRatingResponse]:
    """Post Rating

    Args:
        run_rid (str):
        sequence (int):
        body (PostRatingRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | PostRunEventRatingResponse]
    """

    kwargs = _get_kwargs(
        run_rid=run_rid,
        sequence=sequence,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    run_rid: str,
    sequence: int,
    *,
    client: AuthenticatedClient | Client,
    body: PostRatingRequest,
) -> Any | PostRunEventRatingResponse | None:
    """Post Rating

    Args:
        run_rid (str):
        sequence (int):
        body (PostRatingRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | PostRunEventRatingResponse
    """

    return sync_detailed(
        run_rid=run_rid,
        sequence=sequence,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    run_rid: str,
    sequence: int,
    *,
    client: AuthenticatedClient | Client,
    body: PostRatingRequest,
) -> Response[Any | PostRunEventRatingResponse]:
    """Post Rating

    Args:
        run_rid (str):
        sequence (int):
        body (PostRatingRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | PostRunEventRatingResponse]
    """

    kwargs = _get_kwargs(
        run_rid=run_rid,
        sequence=sequence,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    run_rid: str,
    sequence: int,
    *,
    client: AuthenticatedClient | Client,
    body: PostRatingRequest,
) -> Any | PostRunEventRatingResponse | None:
    """Post Rating

    Args:
        run_rid (str):
        sequence (int):
        body (PostRatingRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | PostRunEventRatingResponse
    """

    return (
        await asyncio_detailed(
            run_rid=run_rid,
            sequence=sequence,
            client=client,
            body=body,
        )
    ).parsed
