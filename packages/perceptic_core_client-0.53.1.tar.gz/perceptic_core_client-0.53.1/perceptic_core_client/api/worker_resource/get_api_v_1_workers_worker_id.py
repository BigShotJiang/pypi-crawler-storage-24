from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_worker_metadata_response import GetWorkerMetadataResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    worker_id: str,
    *,
    version: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["version"] = version

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/workers/{worker_id}".format(
            worker_id=quote(str(worker_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> GetWorkerMetadataResponse | None:
    if response.status_code == 200:
        response_200 = GetWorkerMetadataResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[GetWorkerMetadataResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    worker_id: str,
    *,
    client: AuthenticatedClient | Client,
    version: str | Unset = UNSET,
) -> Response[GetWorkerMetadataResponse]:
    """Get Worker Metadata

    Args:
        worker_id (str): Unique identifier for a worker
        version (str | Unset): The semantic version of the worker

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetWorkerMetadataResponse]
    """

    kwargs = _get_kwargs(
        worker_id=worker_id,
        version=version,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    worker_id: str,
    *,
    client: AuthenticatedClient | Client,
    version: str | Unset = UNSET,
) -> GetWorkerMetadataResponse | None:
    """Get Worker Metadata

    Args:
        worker_id (str): Unique identifier for a worker
        version (str | Unset): The semantic version of the worker

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetWorkerMetadataResponse
    """

    return sync_detailed(
        worker_id=worker_id,
        client=client,
        version=version,
    ).parsed


async def asyncio_detailed(
    worker_id: str,
    *,
    client: AuthenticatedClient | Client,
    version: str | Unset = UNSET,
) -> Response[GetWorkerMetadataResponse]:
    """Get Worker Metadata

    Args:
        worker_id (str): Unique identifier for a worker
        version (str | Unset): The semantic version of the worker

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetWorkerMetadataResponse]
    """

    kwargs = _get_kwargs(
        worker_id=worker_id,
        version=version,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    worker_id: str,
    *,
    client: AuthenticatedClient | Client,
    version: str | Unset = UNSET,
) -> GetWorkerMetadataResponse | None:
    """Get Worker Metadata

    Args:
        worker_id (str): Unique identifier for a worker
        version (str | Unset): The semantic version of the worker

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetWorkerMetadataResponse
    """

    return (
        await asyncio_detailed(
            worker_id=worker_id,
            client=client,
            version=version,
        )
    ).parsed
