from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.list_users_response import ListUsersResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    limit: int | Unset = 20,
    offset: int | Unset = 0,
    q: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["limit"] = limit

    params["offset"] = offset

    params["q"] = q

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/users",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | ListUsersResponse | None:
    if response.status_code == 200:
        response_200 = ListUsersResponse.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = cast(Any, None)
        return response_400

    if response.status_code == 401:
        response_401 = cast(Any, None)
        return response_401

    if response.status_code == 503:
        response_503 = cast(Any, None)
        return response_503

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | ListUsersResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 20,
    offset: int | Unset = 0,
    q: str | Unset = UNSET,
) -> Response[Any | ListUsersResponse]:
    """List and search users

     Lists users with optional search. When query is provided, searches across username, email,
    firstName, and lastName.

    Args:
        limit (int | Unset):  Default: 20.
        offset (int | Unset):  Default: 0.
        q (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | ListUsersResponse]
    """

    kwargs = _get_kwargs(
        limit=limit,
        offset=offset,
        q=q,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 20,
    offset: int | Unset = 0,
    q: str | Unset = UNSET,
) -> Any | ListUsersResponse | None:
    """List and search users

     Lists users with optional search. When query is provided, searches across username, email,
    firstName, and lastName.

    Args:
        limit (int | Unset):  Default: 20.
        offset (int | Unset):  Default: 0.
        q (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | ListUsersResponse
    """

    return sync_detailed(
        client=client,
        limit=limit,
        offset=offset,
        q=q,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 20,
    offset: int | Unset = 0,
    q: str | Unset = UNSET,
) -> Response[Any | ListUsersResponse]:
    """List and search users

     Lists users with optional search. When query is provided, searches across username, email,
    firstName, and lastName.

    Args:
        limit (int | Unset):  Default: 20.
        offset (int | Unset):  Default: 0.
        q (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | ListUsersResponse]
    """

    kwargs = _get_kwargs(
        limit=limit,
        offset=offset,
        q=q,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 20,
    offset: int | Unset = 0,
    q: str | Unset = UNSET,
) -> Any | ListUsersResponse | None:
    """List and search users

     Lists users with optional search. When query is provided, searches across username, email,
    firstName, and lastName.

    Args:
        limit (int | Unset):  Default: 20.
        offset (int | Unset):  Default: 0.
        q (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | ListUsersResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            limit=limit,
            offset=offset,
            q=q,
        )
    ).parsed
