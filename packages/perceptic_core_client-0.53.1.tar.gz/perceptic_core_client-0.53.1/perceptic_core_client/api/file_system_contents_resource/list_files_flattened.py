from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.paged_list_file_system_response import PagedListFileSystemResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    file_system_rid: str,
    *,
    folder: str | Unset = UNSET,
    page_size: int | Unset = 1000,
    resume_token: str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["folder"] = folder

    params["pageSize"] = page_size

    params["resumeToken"] = resume_token

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/file-systems/{file_system_rid}/contents/files".format(
            file_system_rid=quote(str(file_system_rid), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> PagedListFileSystemResponse | None:
    if response.status_code == 200:
        response_200 = PagedListFileSystemResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[PagedListFileSystemResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    file_system_rid: str,
    *,
    client: AuthenticatedClient | Client,
    folder: str | Unset = UNSET,
    page_size: int | Unset = 1000,
    resume_token: str | Unset = UNSET,
) -> Response[PagedListFileSystemResponse]:
    """List Files Flattened

    Args:
        file_system_rid (str):
        folder (str | Unset):
        page_size (int | Unset):  Default: 1000.
        resume_token (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PagedListFileSystemResponse]
    """

    kwargs = _get_kwargs(
        file_system_rid=file_system_rid,
        folder=folder,
        page_size=page_size,
        resume_token=resume_token,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    file_system_rid: str,
    *,
    client: AuthenticatedClient | Client,
    folder: str | Unset = UNSET,
    page_size: int | Unset = 1000,
    resume_token: str | Unset = UNSET,
) -> PagedListFileSystemResponse | None:
    """List Files Flattened

    Args:
        file_system_rid (str):
        folder (str | Unset):
        page_size (int | Unset):  Default: 1000.
        resume_token (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PagedListFileSystemResponse
    """

    return sync_detailed(
        file_system_rid=file_system_rid,
        client=client,
        folder=folder,
        page_size=page_size,
        resume_token=resume_token,
    ).parsed


async def asyncio_detailed(
    file_system_rid: str,
    *,
    client: AuthenticatedClient | Client,
    folder: str | Unset = UNSET,
    page_size: int | Unset = 1000,
    resume_token: str | Unset = UNSET,
) -> Response[PagedListFileSystemResponse]:
    """List Files Flattened

    Args:
        file_system_rid (str):
        folder (str | Unset):
        page_size (int | Unset):  Default: 1000.
        resume_token (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[PagedListFileSystemResponse]
    """

    kwargs = _get_kwargs(
        file_system_rid=file_system_rid,
        folder=folder,
        page_size=page_size,
        resume_token=resume_token,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    file_system_rid: str,
    *,
    client: AuthenticatedClient | Client,
    folder: str | Unset = UNSET,
    page_size: int | Unset = 1000,
    resume_token: str | Unset = UNSET,
) -> PagedListFileSystemResponse | None:
    """List Files Flattened

    Args:
        file_system_rid (str):
        folder (str | Unset):
        page_size (int | Unset):  Default: 1000.
        resume_token (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        PagedListFileSystemResponse
    """

    return (
        await asyncio_detailed(
            file_system_rid=file_system_rid,
            client=client,
            folder=folder,
            page_size=page_size,
            resume_token=resume_token,
        )
    ).parsed
