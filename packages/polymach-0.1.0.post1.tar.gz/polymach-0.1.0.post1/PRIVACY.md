# Privacy Policy

Last updated: March 9, 2026

This Privacy Policy describes how PolyMach handles information in connection
with the PolyMach software distribution, license activation service, and related
hosted infrastructure.

## 1. Scope

This policy applies to information processed by PolyMach in connection with:

- the license and payment activation service
- release and runtime distribution infrastructure
- support and operational administration of those services

This policy does not change the privacy practices of third-party systems you use
with PolyMach, including Polymarket, wallet providers, RPC providers, GitHub,
package indexes, or blockchains.

## 2. Information PolyMach Processes

Depending on how you use PolyMach, PolyMach may process:

- machine fingerprints used for machine-bound licensing
- blockchain transaction hashes submitted for payment verification
- payer wallet addresses
- payment recipient addresses
- token contract addresses
- payment amounts, chain ids, block numbers, and confirmation data
- raw transaction and receipt data obtained from Polygon RPC
- issued license records, including license ids, issue times, expiry times, and
  license claims
- wallet addresses you explicitly provide during activation
- request metadata normally produced by web infrastructure, such as IP address,
  user agent, timestamps, and server logs
- email or support communications you send directly to PolyMach

## 3. Information PolyMach Does Not Intend To Collect

The PolyMach license service is not designed to receive your trading private
keys or seed phrases.

If you use local SDK helpers such as signer-based payment submission, those keys
are intended to remain on your machine and are not required to be sent to the
PolyMach license service for normal activation.

You remain responsible for protecting your own keys and local environment.

## 4. How PolyMach Uses Information

PolyMach uses the information it processes to:

- verify on-chain payments
- determine the number of purchased billing cycles
- issue and return licenses
- prevent duplicate, invalid, or fraudulent activations
- operate, maintain, and secure the service
- diagnose failures and support users
- keep internal business and operational records
- comply with law, regulation, court order, or other legal process
- investigate abuse, fraud, tampering, or security incidents

## 5. Legal And Operational Basis

PolyMach processes information because it is necessary to operate the license
and payment service you request, to protect the service and its users, and to
maintain business and legal records.

## 6. Sharing

PolyMach may share information with service providers or third parties that are
reasonably necessary to operate the service, including:

- blockchain RPC providers used to verify payments
- hosting and infrastructure providers
- logging, monitoring, and security providers
- professional advisers
- law enforcement, regulators, courts, or other parties when required by law or
  legal process

PolyMach does not sell your personal information.

PolyMach may also disclose information if reasonably necessary to detect,
prevent, or respond to fraud, abuse, security incidents, or unlawful use.

## 7. Public Blockchain Data

Payments for PolyMach occur on public blockchain infrastructure.

Wallet addresses, transaction hashes, token transfers, and related transaction
metadata may be publicly visible on-chain, independently of PolyMach.

PolyMach cannot make public blockchain activity private.

## 8. Retention

PolyMach may retain payment records, license records, machine fingerprints,
request logs, and related operational data for as long as reasonably necessary
to:

- operate the service
- maintain records of purchased licenses
- prevent abuse and duplicate issuance
- resolve disputes
- satisfy legal, accounting, tax, compliance, or security requirements

Retention periods may vary depending on the nature of the record and the needs
of the service.

## 9. Security

PolyMach uses reasonable administrative, technical, and operational measures to
protect the information it controls.

No method of storage, transmission, or internet-connected service is perfectly
secure, and PolyMach cannot guarantee absolute security.

You are responsible for the security of your own devices, wallets, credentials,
and local environment.

## 10. International And Infrastructure Transfers

PolyMach infrastructure or service providers may process information in
different jurisdictions depending on hosting, RPC, and operational setup.

By using PolyMach, you understand that information may be processed where the
service or its providers operate.

## 11. Your Choices

You can choose not to submit payment or activation information, but then the
license service may not be able to activate PolyMach for your machine.

Because blockchain payments and many license records are operationally tied to
service issuance, PolyMach may not be able to delete or alter historical
records needed to maintain accurate licensing, security, accounting, or legal
records.

## 12. Changes

PolyMach may update this Privacy Policy from time to time.

The updated version becomes effective when posted, unless stated otherwise.

## 13. Contact

Questions about this Privacy Policy may be sent to:

`hello@polymach.io`
