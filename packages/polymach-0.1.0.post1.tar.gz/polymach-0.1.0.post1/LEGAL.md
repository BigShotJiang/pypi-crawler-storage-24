# Legal Notice

This file is a practical, plain-English notice for users of the public
`polymach` SDK. It is supplemental explanatory material only. It is not legal
advice.

If there is any conflict between this file, the MIT license, applicable law, or
any separate commercial agreement, the controlling legal document or applicable
law governs.

For service terms and privacy practices, also see [`TERMS.md`](TERMS.md) and
[`PRIVACY.md`](PRIVACY.md).

## Important Summary

By using `polymach`, you accept that:

- you use it entirely at your own risk
- you are solely responsible for all actions taken through it
- this includes actions taken by you, your software, your scripts, your bots, or
  any autonomous or semi-autonomous agent you deploy
- you are solely responsible for all resulting losses, gains, fees, taxes,
  penalties, damages, compliance obligations, and legal consequences

PolyMach is not responsible for your trading decisions, your agent's decisions,
your execution outcomes, your wallet security, or your legal compliance.

## No Affiliation With Polymarket

`polymach` is not an official product of Polymarket.

PolyMach is not:

- Polymarket
- an affiliate of Polymarket
- a subsidiary of Polymarket
- a partner of Polymarket
- endorsed by Polymarket
- sponsored by Polymarket
- approved by Polymarket

Any reference in this repository to Polymarket, Polymarket APIs, Polymarket
markets, or Polymarket infrastructure is descriptive only.

You must not interpret use of the name "Polymarket" in this project as implying
any official relationship, endorsement, authorization, or agency.

## No Advice

`polymach` is software tooling only.

PolyMach does not provide:

- investment advice
- trading advice
- legal advice
- tax advice
- accounting advice
- fiduciary advice
- brokerage services
- custody services
- guaranteed execution

Nothing in this repository, the SDK, the runtime, the documentation, the
release process, benchmark results, examples, or sample code should be treated
as a recommendation to buy, sell, hold, hedge, route, size, or manage any
position.

## Human And Agent Responsibility

If you use `polymach` directly as a human, you are fully responsible for what it
does.

If you use `polymach` through any bot, trading system, automation, model,
workflow, orchestration system, or autonomous agent, then you, the deployer and
operator, are fully responsible for what that system does.

For clarity:

- an action taken by your agent is your action
- an order submitted by your agent is your order
- a payment submitted by your agent is your payment
- a compliance failure by your agent is your compliance failure
- a loss caused by your agent remains your loss

PolyMach has no obligation to supervise, approve, block, reverse, or correct
actions taken by you or your agent.

## Financial Responsibility

You bear sole responsibility for all financial consequences of use, including:

- trading losses
- slippage
- adverse selection
- failed hedges
- missed fills
- partial fills
- stale data decisions
- latency-sensitive losses
- liquidation or margin consequences elsewhere
- gas fees
- RPC fees
- venue fees
- settlement issues
- tax liabilities
- accounting treatment
- fraud losses
- key compromise losses
- operational losses of any kind

To the maximum extent permitted by law, PolyMach is not liable for any direct,
indirect, incidental, consequential, special, exemplary, punitive, or other
losses or damages arising from use or misuse of the software.

## Geographic And Regulatory Responsibility

You are solely responsible for determining whether use of `polymach`, Polymarket,
related wallets, tokens, RPC endpoints, payment flows, and trading workflows is
lawful and permitted for you in every relevant location.

This includes responsibility for:

- your country
- your state, province, or territory
- your city or municipality
- your citizenship and residency status
- the location of your agents, servers, wallets, and users
- sanctions regimes
- export controls
- securities, derivatives, gaming, prediction market, tax, AML, KYC, consumer,
  and financial regulations
- venue terms of service and third-party API terms

PolyMach does not represent or warrant that use is lawful, available, or
appropriate in any jurisdiction.

## Wallets, Keys, Credentials, And Security

You are solely responsible for:

- private keys
- wallet addresses
- signatures
- seed phrases
- RPC credentials
- API credentials
- machine credentials
- license files
- local secrets
- agent prompt security
- workstation and server security

If you lose funds because of credential leakage, key compromise, operator error,
prompt injection, malicious dependencies, host compromise, or agent misuse, that
loss is your responsibility.

PolyMach has no duty to recover funds, unwind trades, reimburse losses, or
restore compromised credentials.

## Third-Party Systems

`polymach` depends on or interacts with third-party systems that PolyMach does
not control, including but not limited to:

- blockchains
- RPC providers
- wallets
- exchanges and venues
- Polymarket infrastructure
- web APIs
- websocket infrastructure
- operating systems
- package managers
- cloud providers

PolyMach is not responsible for failures, downtime, censorship, forks,
reorganizations, inconsistent data, broken APIs, changed venue behavior, or any
other issue caused by third-party systems.

## No Warranty

The MIT license already states that the software is provided "AS IS", without
warranty of any kind.

That applies broadly, including without limitation:

- correctness
- profitability
- legality
- fitness for a specific strategy
- uptime
- security
- performance consistency
- market access
- execution quality
- compatibility with your environment
- suitability for human or autonomous operation

## Use Only If You Accept Full Responsibility

Do not use `polymach` unless you are prepared to accept full responsibility for:

- every payment
- every order
- every trade
- every automation
- every jurisdictional issue
- every compliance issue
- every financial result
- every security outcome

If you do not accept that allocation of responsibility, do not use the software.
