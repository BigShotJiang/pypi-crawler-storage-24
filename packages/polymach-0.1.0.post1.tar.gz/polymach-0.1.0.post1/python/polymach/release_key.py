from __future__ import annotations

# Embedded permanent release verification key.
PUBLIC_KEY_BASE64 = "UjOB8kS1eWFa3SpHEDLrfvwvb37aX6zceddc7kR/+Os="
