from __future__ import annotations

from typing import Iterator

from .models import (
    CancelOrderResult,
    DiscoveryEvent,
    DiscoveryMarket,
    DiscoverySearchResults,
    Fill,
    Healthcheck,
    LicenseClaims,
    LicenseStatus,
    LimitOrderReceipt,
    MachineFingerprint,
    MarketQuote,
    MidpointResponse,
    Order,
    Portfolio,
    QuoteStreamSnapshot,
    SessionInfo,
    SessionPrewarmResult,
    TimedLimitResponse,
    Trade,
    TradePage,
)
from .runtime import PolyMachRuntime


class SystemAPI:
    def __init__(self, runtime: PolyMachRuntime) -> None:
        self._runtime = runtime

    def fingerprint(self) -> MachineFingerprint:
        return MachineFingerprint.from_dict(self._runtime.run_json("fingerprint", "--json"))


class SessionAPI:
    def __init__(self, runtime: PolyMachRuntime) -> None:
        self._runtime = runtime

    def status(self) -> SessionInfo:
        payload = self._runtime.rpc("session.status")
        return SessionInfo.from_dict(payload)

    def prewarm(
        self,
        token_ids: list[str] | tuple[str, ...],
        *,
        quotes: bool = True,
        order_metadata: bool = True,
        last_trade: bool = False,
    ) -> SessionPrewarmResult:
        payload = self._runtime.rpc(
            "session.prewarm",
            {
                "token_ids": [str(token_id) for token_id in token_ids],
                "quotes": quotes,
                "order_metadata": order_metadata,
                "last_trade": last_trade,
            },
        )
        return SessionPrewarmResult.from_dict(payload)


class LicenseAPI:
    def __init__(self, runtime: PolyMachRuntime) -> None:
        self._runtime = runtime

    def status(self) -> LicenseStatus:
        return LicenseStatus.from_dict(self._runtime.run_json("license", "status", "--json"))

    def install(self, source: str) -> str:
        payload = self._runtime.run_json("license", "install", source, "--json")
        return str(payload["installed_path"])

    def verify(self, public_key_base64: str | None = None) -> LicenseClaims:
        args = ["license", "verify", "--json"]
        if public_key_base64 is not None:
            args.extend(["--public-key-base64", public_key_base64])
        return LicenseClaims.from_dict(self._runtime.run_json(*args))


class AccountAPI:
    def __init__(self, runtime: PolyMachRuntime) -> None:
        self._runtime = runtime

    def health(self, token_id: str | None = None) -> Healthcheck:
        return Healthcheck.from_dict(
            self._runtime.rpc("account.health", {"token_id": token_id} if token_id is not None else {})
        )

    def portfolio(self, token_id: str) -> Portfolio:
        return Portfolio.from_dict(self._runtime.rpc("account.portfolio", {"token_id": token_id}))


class MarketAPI:
    def __init__(self, runtime: PolyMachRuntime) -> None:
        self._runtime = runtime

    def midpoint(self, token_id: str) -> MidpointResponse:
        return MidpointResponse.from_dict(self._runtime.rpc("market.midpoint", {"token_id": token_id}))

    def quote(self, token_id: str, fallback_midpoint: float = 0.5) -> MarketQuote:
        return MarketQuote.from_dict(
            self._runtime.rpc(
                "market.quote",
                {"token_id": token_id, "fallback_midpoint": fallback_midpoint},
            )
        )

    def stream(
        self,
        token_ids: list[str] | tuple[str, ...],
        *,
        interval_ms: int = 100,
        include_last_trade: bool = False,
        count: int | None = None,
    ) -> Iterator[QuoteStreamSnapshot]:
        if not token_ids:
            raise ValueError("token_ids must contain at least one token id")
        args = [
            "market",
            "stream",
            *[str(token_id) for token_id in token_ids],
            "--interval-ms",
            str(interval_ms),
            "--json",
        ]
        if include_last_trade:
            args.append("--include-last-trade")
        if count is not None:
            args.extend(["--count", str(count)])
        for payload in self._runtime.iter_json_lines(*args):
            yield QuoteStreamSnapshot.from_dict(payload)


class OrdersAPI:
    def __init__(self, runtime: PolyMachRuntime) -> None:
        self._runtime = runtime

    def limit(
        self,
        side: str,
        token_id: str,
        qty: float,
        limit_price: float,
        *,
        order_type: str = "GTC",
        timed: bool = False,
    ) -> LimitOrderReceipt | TimedLimitResponse:
        payload = self._runtime.rpc(
            "orders.limit",
            {
                "side": side,
                "token_id": token_id,
                "qty": qty,
                "limit_price": limit_price,
                "order_type": order_type,
                "timed": timed,
            },
        )
        if timed:
            return TimedLimitResponse.from_dict(payload)
        return LimitOrderReceipt.from_dict(payload)

    def market_buy(
        self,
        token_id: str,
        usdc: float,
        *,
        price_hint: float | None = None,
    ) -> Fill:
        return Fill.from_dict(
            self._runtime.rpc(
                "orders.market_buy",
                {"token_id": token_id, "usdc": usdc, "price_hint": price_hint},
            )
        )

    def market_sell(
        self,
        token_id: str,
        qty: float,
        *,
        price_hint: float | None = None,
    ) -> Fill:
        return Fill.from_dict(
            self._runtime.rpc(
                "orders.market_sell",
                {"token_id": token_id, "qty": qty, "price_hint": price_hint},
            )
        )

    def list(self, token_id: str | None = None) -> list[Order]:
        payload = self._runtime.rpc(
            "orders.list",
            {"token_id": token_id} if token_id is not None else {},
        )
        return [Order.from_dict(item) for item in payload]

    def get(self, order_id: str) -> Order:
        return Order.from_dict(self._runtime.rpc("orders.get", {"order_id": order_id}))

    def cancel(self, order_id: str) -> CancelOrderResult:
        return CancelOrderResult.from_dict(self._runtime.rpc("orders.cancel", {"order_id": order_id}))

    def cancel_open(self, token_id: str) -> int:
        payload = self._runtime.rpc("orders.cancel_open", {"token_id": token_id})
        return int(payload["canceled"])

    def cancel_all(self) -> int:
        payload = self._runtime.rpc("orders.cancel_all")
        return int(payload["canceled"])


class TradesAPI:
    def __init__(self, runtime: PolyMachRuntime) -> None:
        self._runtime = runtime

    def get(self, trade_id: str) -> Trade | None:
        payload = self._runtime.rpc("trades.get", {"trade_id": trade_id})
        if payload is None:
            return None
        return Trade.from_dict(payload)

    def list(self, *, after: int | None = None, cursor: str | None = None) -> TradePage:
        return TradePage.from_dict(
            self._runtime.rpc("trades.list", {"after": after, "cursor": cursor})
        )


class DiscoveryAPI:
    def __init__(self, runtime: PolyMachRuntime) -> None:
        self._runtime = runtime

    def markets(
        self,
        *,
        query: str | None = None,
        limit: int = 20,
        offset: int = 0,
        include_closed: bool = False,
        category: str | None = None,
        with_live: bool = False,
    ) -> list[DiscoveryMarket]:
        payload = self._runtime.rpc(
            "discover.markets",
            {
                "query": query,
                "limit": limit,
                "offset": offset,
                "include_closed": include_closed,
                "category": category,
                "with_live": with_live,
            },
        )
        return [DiscoveryMarket.from_dict(item) for item in payload]

    def market(
        self,
        *,
        market_id: str | None = None,
        slug: str | None = None,
        token_id: str | None = None,
        with_live: bool = False,
    ) -> DiscoveryMarket:
        if market_id is None and slug is None and token_id is None:
            raise ValueError("one of market_id, slug, or token_id is required")
        return DiscoveryMarket.from_dict(
            self._runtime.rpc(
                "discover.market",
                {
                    "market_id": market_id,
                    "slug": slug,
                    "token_id": token_id,
                    "with_live": with_live,
                },
            )
        )

    def events(
        self,
        *,
        query: str | None = None,
        limit: int = 20,
        offset: int = 0,
        include_closed: bool = False,
        category: str | None = None,
        with_live: bool = False,
    ) -> list[DiscoveryEvent]:
        payload = self._runtime.rpc(
            "discover.events",
            {
                "query": query,
                "limit": limit,
                "offset": offset,
                "include_closed": include_closed,
                "category": category,
                "with_live": with_live,
            },
        )
        return [DiscoveryEvent.from_dict(item) for item in payload]

    def event(
        self,
        *,
        event_id: str | None = None,
        slug: str | None = None,
        with_live: bool = False,
    ) -> DiscoveryEvent:
        if event_id is None and slug is None:
            raise ValueError("one of event_id or slug is required")
        return DiscoveryEvent.from_dict(
            self._runtime.rpc(
                "discover.event",
                {"event_id": event_id, "slug": slug, "with_live": with_live},
            )
        )

    def search(
        self,
        query: str,
        *,
        limit: int = 10,
        include_closed: bool = False,
        include_profiles: bool = False,
        with_live: bool = False,
    ) -> DiscoverySearchResults:
        return DiscoverySearchResults.from_dict(
            self._runtime.rpc(
                "discover.search",
                {
                    "query": query,
                    "limit": limit,
                    "include_closed": include_closed,
                    "include_profiles": include_profiles,
                    "with_live": with_live,
                },
            )
        )
