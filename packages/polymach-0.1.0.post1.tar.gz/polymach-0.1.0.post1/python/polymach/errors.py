from __future__ import annotations

class PolyMachError(RuntimeError):
    pass


class BinaryNotFoundError(PolyMachError):
    pass


class CommandError(PolyMachError):
    def __init__(self, command: list[str], exit_code: int, stdout: str, stderr: str) -> None:
        self.command = command
        self.exit_code = exit_code
        self.stdout = stdout
        self.stderr = stderr
        super().__init__(self._build_message())

    def _build_message(self) -> str:
        command = " ".join(self.command)
        stderr = self.stderr.strip() or self.stdout.strip() or f"exit code {self.exit_code}"
        return f"{command}: {stderr}"


class PaymentRequiredError(PolyMachError):
    def __init__(self, message: str, payment: object) -> None:
        self.message = message
        self.payment = payment
        super().__init__(message)


class PaymentPendingError(PolyMachError):
    def __init__(
        self,
        message: str,
        *,
        tx_hash: str,
        confirmations: int | None = None,
        required_confirmations: int | None = None,
        attempted_tx_hashes: tuple[str, ...] = (),
    ) -> None:
        self.message = message
        self.tx_hash = tx_hash
        self.confirmations = confirmations
        self.required_confirmations = required_confirmations
        self.attempted_tx_hashes = attempted_tx_hashes or (tx_hash,)
        super().__init__(message)
