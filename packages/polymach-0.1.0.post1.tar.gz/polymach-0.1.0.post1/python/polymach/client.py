from __future__ import annotations

import json
import os
import tempfile
from typing import Mapping

from .domains import (
    AccountAPI,
    DiscoveryAPI,
    LicenseAPI,
    MarketAPI,
    OrdersAPI,
    SessionAPI,
    SystemAPI,
    TradesAPI,
)
from .errors import PaymentRequiredError, PolyMachError
from .models import (
    ActivationResult,
    CancelOrderResult,
    DiscoveryEvent,
    DiscoveryMarket,
    DiscoverySearchResults,
    Fill,
    Healthcheck,
    LicenseCatalog,
    LicenseClaims,
    LicenseStatus,
    LimitOrderReceipt,
    MachineFingerprint,
    MarketQuote,
    MidpointResponse,
    Order,
    PaymentRequest,
    Portfolio,
    QuoteStreamSnapshot,
    SessionInfo,
    SessionPrewarmResult,
    StartResult,
    TimedLimitResponse,
    Trade,
    TradePage,
)
from .onboarding import LicenseServiceClient
from .payments import PaymentSigner, PolygonUsdcPayer, SubmittedPayment
from .runtime import PolyMachRuntime


class PolyMach:
    def __init__(
        self,
        binary: str | os.PathLike[str] | None = None,
        license_path: str | os.PathLike[str] | None = None,
        env: Mapping[str, str] | None = None,
        persistent: bool | None = None,
    ) -> None:
        self.runtime = PolyMachRuntime(
            binary=binary,
            license_path=license_path,
            env=env,
            persistent=persistent,
        )
        self.system = SystemAPI(self.runtime)
        self.session = SessionAPI(self.runtime)
        self.license = LicenseAPI(self.runtime)
        self.account = AccountAPI(self.runtime)
        self.discover = DiscoveryAPI(self.runtime)
        self.market = MarketAPI(self.runtime)
        self.orders = OrdersAPI(self.runtime)
        self.trades = TradesAPI(self.runtime)

    def fingerprint(self) -> MachineFingerprint:
        return self.system.fingerprint()

    def session_status(self) -> SessionInfo:
        return self.session.status()

    def prewarm(
        self,
        token_ids: list[str] | tuple[str, ...],
        *,
        quotes: bool = True,
        order_metadata: bool = True,
        last_trade: bool = False,
    ) -> SessionPrewarmResult:
        return self.session.prewarm(
            token_ids,
            quotes=quotes,
            order_metadata=order_metadata,
            last_trade=last_trade,
        )

    def license_status(self) -> LicenseStatus:
        return self.license.status()

    def verify_license(self, public_key_base64: str | None = None) -> LicenseClaims:
        return self.license.verify(public_key_base64=public_key_base64)

    def install_license(self, source: str | os.PathLike[str]) -> str:
        return self.license.install(str(source))

    def pricing(self, *, service_url: str | None = None) -> LicenseCatalog:
        return self._license_service(service_url).catalog()

    def payment_request(
        self,
        *,
        cycles: int = 1,
        service_url: str | None = None,
    ) -> PaymentRequest:
        fingerprint = self.fingerprint()
        return self._license_service(service_url).payment_request(
            machine_fingerprint=fingerprint.fingerprint,
            cycles=cycles,
        )

    def activate(
        self,
        *,
        tx_hash: str,
        wallet_address: str | None = None,
        notes: str | None = None,
        service_url: str | None = None,
    ) -> ActivationResult:
        fingerprint = self.fingerprint()
        payload = self._license_service(service_url).activate(
            tx_hash=tx_hash,
            machine_fingerprint=fingerprint.fingerprint,
            wallet_address=wallet_address,
            notes=notes,
        )
        license_document = payload.get("license")
        if not isinstance(license_document, dict):
            raise PolyMachError("license service response did not contain a license document")
        installed_path = self._install_license_document(license_document)
        claims_payload = license_document.get("claims")
        if not isinstance(claims_payload, dict):
            raise PolyMachError("license service response did not contain license claims")
        payment_payload = payload.get("payment") if isinstance(payload.get("payment"), dict) else {}
        self.runtime.close()
        return ActivationResult(
            installed_path=installed_path,
            reused=bool(payload.get("reused")),
            tx_hash=str(payment_payload.get("tx_hash", tx_hash)),
            cycles=int(payload.get("cycles", 1)),
            claims=LicenseClaims.from_dict(claims_payload),
            payment_amount_display=(
                str(payment_payload["amount_display"])
                if payment_payload.get("amount_display") is not None
                else None
            ),
            wallet_address=(
                str(payment_payload["payer_address"])
                if payment_payload.get("payer_address") is not None
                else None
            ),
        )

    def pay(
        self,
        *,
        signer: PaymentSigner | None = None,
        private_key: str | None = None,
        cycles: int = 1,
        service_url: str | None = None,
        rpc_url: str | None = None,
        gas_limit: int | None = None,
        gas_price_wei: int | None = None,
        replacement_attempts: int | None = None,
        replacement_gas_bump_percent: int | None = None,
        timeout_seconds: float = 180.0,
        poll_interval_seconds: float = 2.0,
    ) -> SubmittedPayment:
        payment = self.payment_request(cycles=cycles, service_url=service_url)
        return self._payment_sender(rpc_url).pay(
            payment,
            signer=signer,
            private_key=private_key,
            gas_limit=gas_limit,
            gas_price_wei=gas_price_wei,
            replacement_attempts=replacement_attempts,
            replacement_gas_bump_percent=replacement_gas_bump_percent,
            timeout_seconds=timeout_seconds,
            poll_interval_seconds=poll_interval_seconds,
        )

    def pay_and_start(
        self,
        *,
        tx_hash: str | None = None,
        wallet_address: str | None = None,
        signer: PaymentSigner | None = None,
        private_key: str | None = None,
        cycles: int = 1,
        service_url: str | None = None,
        rpc_url: str | None = None,
        gas_limit: int | None = None,
        gas_price_wei: int | None = None,
        replacement_attempts: int | None = None,
        replacement_gas_bump_percent: int | None = None,
        timeout_seconds: float = 180.0,
        poll_interval_seconds: float = 2.0,
        notes: str | None = None,
        prewarm_tokens: list[str] | tuple[str, ...] = (),
        prewarm_quotes: bool = True,
        prewarm_order_metadata: bool = True,
        prewarm_last_trade: bool = False,
    ) -> StartResult:
        status = self.license_status()
        if status.valid:
            return self.start(
                cycles=cycles,
                service_url=service_url,
                prewarm_tokens=prewarm_tokens,
                prewarm_quotes=prewarm_quotes,
                prewarm_order_metadata=prewarm_order_metadata,
                prewarm_last_trade=prewarm_last_trade,
            )
        if tx_hash is not None:
            return self.start(
                cycles=cycles,
                tx_hash=tx_hash,
                wallet_address=wallet_address,
                notes=notes,
                service_url=service_url,
                prewarm_tokens=prewarm_tokens,
                prewarm_quotes=prewarm_quotes,
                prewarm_order_metadata=prewarm_order_metadata,
                prewarm_last_trade=prewarm_last_trade,
            )
        submitted = self.pay(
            signer=signer,
            private_key=private_key,
            cycles=cycles,
            service_url=service_url,
            rpc_url=rpc_url,
            gas_limit=gas_limit,
            gas_price_wei=gas_price_wei,
            replacement_attempts=replacement_attempts,
            replacement_gas_bump_percent=replacement_gas_bump_percent,
            timeout_seconds=timeout_seconds,
            poll_interval_seconds=poll_interval_seconds,
        )
        activation = self.activate(
            tx_hash=submitted.tx_hash,
            wallet_address=wallet_address or submitted.sender_address,
            notes=notes,
            service_url=service_url,
        )
        status = self.license_status()
        if not status.valid:
            raise PolyMachError("license activated but local verification failed")
        session_info, prewarm_result = self._start_session(
            prewarm_tokens,
            quotes=prewarm_quotes,
            order_metadata=prewarm_order_metadata,
            last_trade=prewarm_last_trade,
        )
        return StartResult(
            ready=True,
            message="license activated",
            license_status=status,
            activation=activation,
            session=session_info,
            prewarm=prewarm_result,
        )

    def start(
        self,
        *,
        cycles: int = 1,
        tx_hash: str | None = None,
        wallet_address: str | None = None,
        notes: str | None = None,
        service_url: str | None = None,
        prewarm_tokens: list[str] | tuple[str, ...] = (),
        prewarm_quotes: bool = True,
        prewarm_order_metadata: bool = True,
        prewarm_last_trade: bool = False,
    ) -> StartResult:
        status = self.license_status()
        if status.valid:
            session_info, prewarm_result = self._start_session(
                prewarm_tokens,
                quotes=prewarm_quotes,
                order_metadata=prewarm_order_metadata,
                last_trade=prewarm_last_trade,
            )
            return StartResult(
                ready=True,
                message="license already installed",
                license_status=status,
                session=session_info,
                prewarm=prewarm_result,
            )

        payment = self.payment_request(cycles=cycles, service_url=service_url)
        if tx_hash is None:
            return StartResult(
                ready=False,
                message=(
                    f"payment required: send {payment.amount_display} {payment.token_symbol} on chain "
                    f"{payment.chain_id} to {payment.recipient_address} for {payment.cycles} cycle(s), "
                    "then call start(..., tx_hash=...)"
                ),
                license_status=status,
                payment=payment,
            )

        activation = self.activate(
            tx_hash=tx_hash,
            wallet_address=wallet_address,
            notes=notes,
            service_url=service_url,
        )
        status = self.license_status()
        if not status.valid:
            raise PolyMachError("license activated but local verification failed")
        session_info, prewarm_result = self._start_session(
            prewarm_tokens,
            quotes=prewarm_quotes,
            order_metadata=prewarm_order_metadata,
            last_trade=prewarm_last_trade,
        )
        return StartResult(
            ready=True,
            message="license activated",
            license_status=status,
            activation=activation,
            session=session_info,
            prewarm=prewarm_result,
        )

    def ensure_ready(
        self,
        *,
        cycles: int = 1,
        tx_hash: str | None = None,
        wallet_address: str | None = None,
        notes: str | None = None,
        service_url: str | None = None,
        prewarm_tokens: list[str] | tuple[str, ...] = (),
        prewarm_quotes: bool = True,
        prewarm_order_metadata: bool = True,
        prewarm_last_trade: bool = False,
    ) -> StartResult:
        result = self.start(
            cycles=cycles,
            tx_hash=tx_hash,
            wallet_address=wallet_address,
            notes=notes,
            service_url=service_url,
            prewarm_tokens=prewarm_tokens,
            prewarm_quotes=prewarm_quotes,
            prewarm_order_metadata=prewarm_order_metadata,
            prewarm_last_trade=prewarm_last_trade,
        )
        if not result.ready:
            raise PaymentRequiredError(result.message, result.payment)
        return result

    def healthcheck(self, token_id: str | None = None) -> Healthcheck:
        return self.account.health(token_id=token_id)

    def midpoint(self, token_id: str) -> MidpointResponse:
        return self.market.midpoint(token_id)

    def quote(self, token_id: str, fallback_midpoint: float = 0.5) -> MarketQuote:
        return self.market.quote(token_id, fallback_midpoint=fallback_midpoint)

    def stream_quotes(
        self,
        token_ids: list[str] | tuple[str, ...],
        *,
        interval_ms: int = 100,
        include_last_trade: bool = False,
        count: int | None = None,
    ):
        return self.market.stream(
            token_ids,
            interval_ms=interval_ms,
            include_last_trade=include_last_trade,
            count=count,
        )

    def discover_markets(
        self,
        *,
        query: str | None = None,
        limit: int = 20,
        offset: int = 0,
        include_closed: bool = False,
        category: str | None = None,
        with_live: bool = False,
    ) -> list[DiscoveryMarket]:
        return self.discover.markets(
            query=query,
            limit=limit,
            offset=offset,
            include_closed=include_closed,
            category=category,
            with_live=with_live,
        )

    def discover_market(
        self,
        *,
        market_id: str | None = None,
        slug: str | None = None,
        token_id: str | None = None,
        with_live: bool = False,
    ) -> DiscoveryMarket:
        return self.discover.market(
            market_id=market_id,
            slug=slug,
            token_id=token_id,
            with_live=with_live,
        )

    def discover_events(
        self,
        *,
        query: str | None = None,
        limit: int = 20,
        offset: int = 0,
        include_closed: bool = False,
        category: str | None = None,
        with_live: bool = False,
    ) -> list[DiscoveryEvent]:
        return self.discover.events(
            query=query,
            limit=limit,
            offset=offset,
            include_closed=include_closed,
            category=category,
            with_live=with_live,
        )

    def discover_event(
        self,
        *,
        event_id: str | None = None,
        slug: str | None = None,
        with_live: bool = False,
    ) -> DiscoveryEvent:
        return self.discover.event(event_id=event_id, slug=slug, with_live=with_live)

    def search(
        self,
        query: str,
        *,
        limit: int = 10,
        include_closed: bool = False,
        include_profiles: bool = False,
        with_live: bool = False,
    ) -> DiscoverySearchResults:
        return self.discover.search(
            query,
            limit=limit,
            include_closed=include_closed,
            include_profiles=include_profiles,
            with_live=with_live,
        )

    def portfolio(self, token_id: str) -> Portfolio:
        return self.account.portfolio(token_id)

    def post_limit(
        self,
        side: str,
        token_id: str,
        qty: float,
        limit_price: float,
        *,
        order_type: str = "GTC",
        timed: bool = False,
    ) -> LimitOrderReceipt | TimedLimitResponse:
        return self.orders.limit(
            side,
            token_id,
            qty,
            limit_price,
            order_type=order_type,
            timed=timed,
        )

    def market_buy(
        self,
        token_id: str,
        usdc: float,
        *,
        price_hint: float | None = None,
    ) -> Fill:
        return self.orders.market_buy(token_id, usdc, price_hint=price_hint)

    def market_sell(
        self,
        token_id: str,
        qty: float,
        *,
        price_hint: float | None = None,
    ) -> Fill:
        return self.orders.market_sell(token_id, qty, price_hint=price_hint)

    def list_orders(self, token_id: str | None = None) -> list[Order]:
        return self.orders.list(token_id=token_id)

    def get_order(self, order_id: str) -> Order:
        return self.orders.get(order_id)

    def cancel_order(self, order_id: str) -> CancelOrderResult:
        return self.orders.cancel(order_id)

    def cancel_open_orders(self, token_id: str) -> int:
        return self.orders.cancel_open(token_id)

    def cancel_all_open_orders(self) -> int:
        return self.orders.cancel_all()

    def get_trade(self, trade_id: str) -> Trade | None:
        return self.trades.get(trade_id)

    def list_trades(self, *, after: int | None = None, cursor: str | None = None) -> TradePage:
        return self.trades.list(after=after, cursor=cursor)

    def _license_service(self, service_url: str | None = None) -> LicenseServiceClient:
        return LicenseServiceClient(env=self.runtime.env, base_url=service_url)

    def _payment_sender(self, rpc_url: str | None = None) -> PolygonUsdcPayer:
        return PolygonUsdcPayer(env=self.runtime.env, rpc_url=rpc_url)

    def _install_license_document(self, license_document: Mapping[str, object]) -> str:
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as handle:
            json.dump(license_document, handle)
            temp_path = handle.name
        try:
            return self.install_license(temp_path)
        finally:
            try:
                os.unlink(temp_path)
            except FileNotFoundError:
                pass

    def _start_session(
        self,
        token_ids: list[str] | tuple[str, ...],
        *,
        quotes: bool,
        order_metadata: bool,
        last_trade: bool,
    ) -> tuple[SessionInfo | None, SessionPrewarmResult | None]:
        if not token_ids:
            return None, None
        prewarm = self.prewarm(
            token_ids,
            quotes=quotes,
            order_metadata=order_metadata,
            last_trade=last_trade,
        )
        return self.session_status(), prewarm
