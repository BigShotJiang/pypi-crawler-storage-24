from __future__ import annotations

import atexit
import json
import os
import shutil
import subprocess
import threading
from pathlib import Path
from typing import Any, Iterator, Mapping

from .bootstrap import resolve_downloaded_binary
from .errors import BinaryNotFoundError, CommandError, PolyMachError

SENSITIVE_SUBPROCESS_ENV_KEYS = frozenset(
    {
        "POLYMACH_WALLET_PRIVATE_KEY",
    }
)


def _env_flag(raw: str | None, default: bool) -> bool:
    if raw is None:
        return default
    return raw.strip().lower() not in {"0", "false", "no", "off"}


def _sanitize_subprocess_env(env: Mapping[str, str]) -> dict[str, str]:
    return {
        key: value
        for key, value in env.items()
        if key not in SENSITIVE_SUBPROCESS_ENV_KEYS
    }


class PolyMachRuntime:
    def __init__(
        self,
        binary: str | os.PathLike[str] | None = None,
        license_path: str | os.PathLike[str] | None = None,
        env: Mapping[str, str] | None = None,
        persistent: bool | None = None,
    ) -> None:
        self._explicit_binary = Path(binary).expanduser() if binary is not None else None
        self._license_path = Path(license_path).expanduser() if license_path is not None else None
        merged_env = os.environ.copy()
        if env is not None:
            merged_env.update(env)
        self._env = merged_env
        self._subprocess_env = _sanitize_subprocess_env(merged_env)
        self._resolved_binary: Path | None = None
        self._persistent = (
            _env_flag(self._env.get("POLYMACH_PERSISTENT"), True)
            if persistent is None
            else persistent
        )
        self._daemon_disabled = False
        self._daemon_lock = threading.RLock()
        self._daemon_process: subprocess.Popen[str] | None = None
        self._daemon_command: list[str] | None = None
        self._daemon_ready: dict[str, Any] | None = None
        self._next_request_id = 1
        atexit.register(self.close)

    @property
    def env(self) -> Mapping[str, str]:
        return self._env

    @property
    def subprocess_env(self) -> Mapping[str, str]:
        return self._subprocess_env

    def candidate_binaries(self) -> list[Path]:
        candidates: list[Path] = []
        binary_name = "polymach.exe" if os.name == "nt" else "polymach"
        if self._explicit_binary is not None:
            candidates.append(self._explicit_binary)

        if not _env_flag(self._env.get("POLYMACH_SKIP_PACKAGE_BIN"), False):
            package_binary = Path(__file__).resolve().parent / "bin" / binary_name
            candidates.append(package_binary)

        env_binary = self._env.get("POLYMACH_BIN")
        if env_binary:
            candidates.append(Path(env_binary).expanduser())

        if not _env_flag(self._env.get("POLYMACH_SKIP_REPO_BIN"), False):
            parents = Path(__file__).resolve().parents
            if len(parents) >= 3:
                repo_root = parents[2]
                candidates.append(repo_root / "polymach-rs" / "target" / "release" / binary_name)
                candidates.append(repo_root / "polymach-rs" / "target" / "debug" / binary_name)

        if not _env_flag(self._env.get("POLYMACH_SKIP_PATH_BIN"), False):
            which = shutil.which("polymach", path=self._env.get("PATH"))
            if which:
                candidates.append(Path(which))

        deduped: list[Path] = []
        seen: set[Path] = set()
        for candidate in candidates:
            resolved = candidate.expanduser()
            if resolved not in seen:
                deduped.append(resolved)
                seen.add(resolved)
        return deduped

    def binary(self) -> Path:
        if self._resolved_binary is not None:
            return self._resolved_binary

        binary_name = "polymach.exe" if os.name == "nt" else "polymach"
        for candidate in self.candidate_binaries():
            if candidate.exists():
                self._resolved_binary = candidate
                return candidate

        download_error: str | None = None
        try:
            downloaded = resolve_downloaded_binary(binary_name, self._env)
        except Exception as exc:  # noqa: BLE001
            download_error = str(exc)
        else:
            if downloaded is not None and downloaded.exists():
                self._resolved_binary = downloaded
                return downloaded

        searched = ", ".join(str(path) for path in self.candidate_binaries())
        if download_error:
            searched = f"{searched}; auto-download failed: {download_error}"
        raise BinaryNotFoundError(
            f"unable to locate polymach binary; searched: {searched or 'no candidates'}"
        )

    def base_command(self) -> list[str]:
        command = [str(self.binary())]
        if self._license_path is not None:
            command.extend(["--license-path", str(self._license_path)])
        return command

    def daemon_command(self) -> list[str]:
        return self.base_command() + ["session", "serve"]

    def run(self, *args: str) -> str:
        command = self.base_command() + [str(arg) for arg in args]
        completed = subprocess.run(
            command,
            env=self._subprocess_env,
            text=True,
            capture_output=True,
            check=False,
        )
        if completed.returncode != 0:
            raise CommandError(command, completed.returncode, completed.stdout, completed.stderr)
        return completed.stdout.strip()

    def run_json(self, *args: str) -> Any:
        output = self.run(*args)
        return json.loads(output)

    def rpc(self, method: str, params: Mapping[str, Any] | None = None) -> Any:
        payload = dict(params or {})
        with self._daemon_lock:
            if self._persistent and not self._daemon_disabled and self._ensure_daemon_locked():
                return self._rpc_daemon_locked(method, payload)
            if method == "session.status":
                return self._session_status_once_locked()
        return self.run_json(*self._cli_args_for_rpc(method, payload))

    def daemon_ready(self) -> dict[str, Any] | None:
        with self._daemon_lock:
            if self._persistent and not self._daemon_disabled and self._ensure_daemon_locked():
                return dict(self._daemon_ready or {})
            return None

    def close(self) -> None:
        with self._daemon_lock:
            self._close_daemon_locked()

    def _close_daemon_locked(self) -> None:
        process = self._daemon_process
        self._daemon_process = None
        self._daemon_command = None
        self._daemon_ready = None
        if process is None:
            return
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=1.0)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=1.0)
        if process.stdout is not None:
            process.stdout.close()
        if process.stdin is not None:
            process.stdin.close()
        if process.stderr is not None:
            process.stderr.close()

    def _ensure_daemon_locked(self) -> bool:
        if self._daemon_process is not None:
            if self._daemon_process.poll() is None:
                return True
            self._close_daemon_locked()

        command = self.daemon_command()
        process = subprocess.Popen(
            command,
            env=self._subprocess_env,
            text=True,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            bufsize=1,
        )
        if process.stdout is None or process.stdin is None or process.stderr is None:
            self._daemon_disabled = True
            process.kill()
            process.wait(timeout=1.0)
            return False

        ready_line = process.stdout.readline()
        if not ready_line:
            exit_code = process.wait(timeout=1.0)
            stderr = process.stderr.read()
            self._daemon_disabled = True
            if exit_code != 0:
                raise CommandError(command, exit_code, "", stderr)
            return False

        try:
            ready_payload = json.loads(ready_line)
        except json.JSONDecodeError as exc:
            self._daemon_disabled = True
            process.terminate()
            try:
                process.wait(timeout=1.0)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=1.0)
            raise PolyMachError(f"invalid daemon ready payload: {exc}") from exc

        self._daemon_process = process
        self._daemon_command = command
        self._daemon_ready = ready_payload
        return True

    def _rpc_daemon_locked(self, method: str, params: Mapping[str, Any]) -> Any:
        process = self._daemon_process
        if process is None or process.stdin is None or process.stdout is None:
            raise PolyMachError("polymach daemon is not running")

        request_id = self._next_request_id
        self._next_request_id += 1
        request = {"id": request_id, "method": method, "params": dict(params)}
        process.stdin.write(json.dumps(request) + "\n")
        process.stdin.flush()

        line = process.stdout.readline()
        if not line:
            exit_code = process.poll() or -1
            stderr = process.stderr.read() if process.stderr is not None else ""
            self._close_daemon_locked()
            raise CommandError(self._daemon_command or self.daemon_command(), exit_code, "", stderr)

        try:
            payload = json.loads(line)
        except json.JSONDecodeError as exc:
            raise PolyMachError(f"invalid daemon response: {exc}") from exc

        if int(payload.get("id", -1)) != request_id:
            raise PolyMachError(
                f"daemon response id mismatch: expected {request_id}, got {payload.get('id')}"
            )
        if not bool(payload.get("ok")):
            raise PolyMachError(str(payload.get("error") or f"{method} failed"))
        return payload.get("result")

    def _session_status_once_locked(self) -> Any:
        command = self.daemon_command()
        process = subprocess.Popen(
            command,
            env=self._subprocess_env,
            text=True,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            bufsize=1,
        )
        try:
            if process.stdout is None or process.stderr is None:
                process.kill()
                process.wait(timeout=1.0)
                raise PolyMachError("failed to open session status process streams")

            ready_line = process.stdout.readline()
            if not ready_line:
                exit_code = process.wait(timeout=1.0)
                stderr = process.stderr.read()
                raise CommandError(command, exit_code, "", stderr)

            try:
                return json.loads(ready_line)
            except json.JSONDecodeError as exc:
                raise PolyMachError(f"invalid session status payload: {exc}") from exc
        finally:
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=1.0)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=1.0)
            if process.stdout is not None:
                process.stdout.close()
            if process.stderr is not None:
                process.stderr.close()

    def _cli_args_for_rpc(self, method: str, params: Mapping[str, Any]) -> list[str]:
        if method == "account.health":
            args = ["account", "health", "--json"]
            token_id = params.get("token_id")
            if token_id is not None:
                args.extend(["--token-id", str(token_id)])
            return args
        if method == "account.portfolio":
            return ["account", "portfolio", str(params["token_id"]), "--json"]
        if method == "market.midpoint":
            return ["market", "midpoint", str(params["token_id"]), "--json"]
        if method == "market.quote":
            return [
                "market",
                "quote",
                str(params["token_id"]),
                "--fallback-midpoint",
                str(params.get("fallback_midpoint", 0.5)),
                "--json",
            ]
        if method == "orders.limit":
            args = [
                "orders",
                "limit",
                str(params["side"]),
                str(params["token_id"]),
                str(params["qty"]),
                str(params["limit_price"]),
                "--order-type",
                str(params.get("order_type", "GTC")),
                "--json",
            ]
            if params.get("timed"):
                args.append("--timed")
            return args
        if method == "orders.market_buy":
            args = ["orders", "market-buy", str(params["token_id"]), str(params["usdc"]), "--json"]
            price_hint = params.get("price_hint")
            if price_hint is not None:
                args.extend(["--price-hint", str(price_hint)])
            return args
        if method == "orders.market_sell":
            args = ["orders", "market-sell", str(params["token_id"]), str(params["qty"]), "--json"]
            price_hint = params.get("price_hint")
            if price_hint is not None:
                args.extend(["--price-hint", str(price_hint)])
            return args
        if method == "orders.list":
            args = ["orders", "list", "--json"]
            token_id = params.get("token_id")
            if token_id is not None:
                args.extend(["--token-id", str(token_id)])
            return args
        if method == "orders.get":
            return ["orders", "get", str(params["order_id"]), "--json"]
        if method == "orders.cancel":
            return ["orders", "cancel", str(params["order_id"]), "--json"]
        if method == "orders.cancel_open":
            return ["orders", "cancel-open", str(params["token_id"]), "--json"]
        if method == "orders.cancel_all":
            return ["orders", "cancel-all", "--json"]
        if method == "trades.get":
            return ["trades", "get", str(params["trade_id"]), "--json"]
        if method == "trades.list":
            args = ["trades", "list", "--json"]
            after = params.get("after")
            cursor = params.get("cursor")
            if after is not None:
                args.extend(["--after", str(after)])
            if cursor is not None:
                args.extend(["--cursor", str(cursor)])
            return args
        if method == "discover.markets":
            args = [
                "discover",
                "markets",
                "--limit",
                str(params.get("limit", 20)),
                "--offset",
                str(params.get("offset", 0)),
                "--json",
            ]
            if params.get("query") is not None:
                args.extend(["--query", str(params["query"])])
            if params.get("include_closed"):
                args.append("--include-closed")
            if params.get("category") is not None:
                args.extend(["--category", str(params["category"])])
            if params.get("with_live"):
                args.append("--with-live")
            return args
        if method == "discover.market":
            args = ["discover", "market", "--json"]
            if params.get("market_id") is not None:
                args.extend(["--id", str(params["market_id"])])
            elif params.get("slug") is not None:
                args.extend(["--slug", str(params["slug"])])
            elif params.get("token_id") is not None:
                args.extend(["--token-id", str(params["token_id"])])
            else:
                raise PolyMachError("discover.market requires market_id, slug, or token_id")
            if params.get("with_live"):
                args.append("--with-live")
            return args
        if method == "discover.events":
            args = [
                "discover",
                "events",
                "--limit",
                str(params.get("limit", 20)),
                "--offset",
                str(params.get("offset", 0)),
                "--json",
            ]
            if params.get("query") is not None:
                args.extend(["--query", str(params["query"])])
            if params.get("include_closed"):
                args.append("--include-closed")
            if params.get("category") is not None:
                args.extend(["--category", str(params["category"])])
            if params.get("with_live"):
                args.append("--with-live")
            return args
        if method == "discover.event":
            args = ["discover", "event", "--json"]
            if params.get("event_id") is not None:
                args.extend(["--id", str(params["event_id"])])
            elif params.get("slug") is not None:
                args.extend(["--slug", str(params["slug"])])
            else:
                raise PolyMachError("discover.event requires event_id or slug")
            if params.get("with_live"):
                args.append("--with-live")
            return args
        if method == "discover.search":
            args = [
                "discover",
                "search",
                str(params["query"]),
                "--limit",
                str(params.get("limit", 10)),
                "--json",
            ]
            if params.get("include_closed"):
                args.append("--include-closed")
            if params.get("include_profiles"):
                args.append("--include-profiles")
            if params.get("with_live"):
                args.append("--with-live")
            return args
        raise PolyMachError(f"rpc fallback unavailable for method {method}")

    def iter_json_lines(self, *args: str) -> Iterator[Any]:
        command = self.base_command() + [str(arg) for arg in args]
        process = subprocess.Popen(
            command,
            env=self._env,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            bufsize=1,
        )
        stdout = process.stdout
        stderr = process.stderr
        if stdout is None or stderr is None:
            process.kill()
            raise RuntimeError("failed to open process streams")

        try:
            for line in stdout:
                stripped = line.strip()
                if stripped:
                    yield json.loads(stripped)
            exit_code = process.wait()
            if exit_code != 0:
                raise CommandError(command, exit_code, "", stderr.read())
        finally:
            if process.poll() is None:
                process.kill()
                process.wait()
