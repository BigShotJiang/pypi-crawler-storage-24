from __future__ import annotations

import json
from decimal import Decimal
from typing import Any, Mapping
from urllib import error, request

from .bootstrap import package_version
from .errors import PolyMachError
from .models import LicenseCatalog, PaymentRequest


def default_license_service_url(env: Mapping[str, str]) -> str:
    return env.get("POLYMACH_LICENSE_BASE_URL", "https://license.polymach.io").rstrip("/")


class LicenseServiceClient:
    def __init__(
        self,
        *,
        env: Mapping[str, str],
        base_url: str | None = None,
    ) -> None:
        self._env = env
        self._base_url = (base_url or default_license_service_url(env)).rstrip("/")

    @property
    def base_url(self) -> str:
        return self._base_url

    def catalog(self) -> LicenseCatalog:
        payload = self._request_json("GET", "/v1/catalog")
        return LicenseCatalog.from_dict(payload, service_url=self._base_url)

    def payment_request(
        self,
        *,
        machine_fingerprint: str,
        cycles: int,
    ) -> PaymentRequest:
        if cycles < 1:
            raise PolyMachError("cycles must be at least 1")
        catalog = self.catalog()

        multiplier = Decimal(10) ** catalog.token_decimals
        cycle_price = Decimal(catalog.cycle_price_usdc)
        amount_raw = int((cycle_price * Decimal(cycles) * multiplier).to_integral_value())
        return PaymentRequest(
            service_url=self._base_url,
            machine_fingerprint=machine_fingerprint,
            cycles=cycles,
            chain_id=catalog.chain_id,
            recipient_address=catalog.recipient_address,
            token_address=catalog.token_address,
            token_symbol=catalog.token_symbol,
            token_decimals=catalog.token_decimals,
            amount_display=format((cycle_price * Decimal(cycles)).normalize(), "f"),
            amount_raw=amount_raw,
            cycle_price_usdc=catalog.cycle_price_usdc,
            billing_cycle_days=catalog.billing_cycle_days,
            features=catalog.features,
            min_confirmations=catalog.min_confirmations,
        )

    def activate(
        self,
        *,
        tx_hash: str,
        machine_fingerprint: str,
        wallet_address: str | None = None,
        notes: str | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "tx_hash": tx_hash,
            "machine_fingerprint": machine_fingerprint,
        }
        if wallet_address is not None:
            payload["wallet_address"] = wallet_address
        if notes is not None:
            payload["notes"] = notes
        return self._request_json("POST", "/v1/activate", payload)

    def _request_json(
        self,
        method: str,
        path: str,
        payload: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        url = f"{self._base_url}{path}"
        body: bytes | None = None
        headers = {
            "Accept": "application/json",
            "User-Agent": f"polymach-sdk/{package_version()}",
        }
        if payload is not None:
            body = json.dumps(payload).encode("utf-8")
            headers["Content-Type"] = "application/json"

        token = self._env.get("POLYMACH_LICENSE_TOKEN")
        if token:
            headers["Authorization"] = f"Bearer {token}"

        req = request.Request(url, data=body, headers=headers, method=method)
        try:
            with request.urlopen(req, timeout=30) as response:
                raw = response.read()
        except error.HTTPError as exc:
            detail = self._extract_error_detail(exc)
            raise PolyMachError(f"{method} {url} failed ({exc.code}): {detail}") from exc
        except error.URLError as exc:
            raise PolyMachError(f"{method} {url} failed: {exc.reason}") from exc

        if not raw:
            return {}
        try:
            decoded = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise PolyMachError(f"{method} {url} returned invalid JSON") from exc
        if not isinstance(decoded, dict):
            raise PolyMachError(f"{method} {url} returned an unexpected response shape")
        return decoded

    def _extract_error_detail(self, exc: error.HTTPError) -> str:
        raw = exc.read()
        if raw:
            try:
                payload = json.loads(raw)
            except json.JSONDecodeError:
                return raw.decode("utf-8", errors="replace").strip() or exc.reason
            if isinstance(payload, dict):
                detail = payload.get("detail")
                if isinstance(detail, str):
                    return detail
                return json.dumps(payload, sort_keys=True)
        return str(exc.reason)
