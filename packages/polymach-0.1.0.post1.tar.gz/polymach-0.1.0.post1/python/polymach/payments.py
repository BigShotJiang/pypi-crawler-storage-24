from __future__ import annotations

import json
import time
from dataclasses import dataclass
from typing import Any, Mapping, Protocol, runtime_checkable
from urllib import error, request

from eth_account import Account
from eth_utils import keccak, to_checksum_address

from .bootstrap import package_version
from .errors import PaymentPendingError, PolyMachError
from .models import PaymentRequest

DEFAULT_POLYGON_RPC_URLS = (
    "https://polygon.publicnode.com",
    "https://1rpc.io/matic",
    "https://polygon-rpc.com",
)
DEFAULT_POLYGON_RPC_URL = DEFAULT_POLYGON_RPC_URLS[0]
DEFAULT_GAS_LIMIT = 75_000
DEFAULT_POLL_INTERVAL_SECONDS = 2.0
DEFAULT_TIMEOUT_SECONDS = 180.0
DEFAULT_REPLACEMENT_ATTEMPTS = 0
DEFAULT_REPLACEMENT_GAS_BUMP_PERCENT = 25
MAX_RPC_BACKOFF_SECONDS = 10.0
ERC20_TRANSFER_SELECTOR = keccak(text="transfer(address,uint256)")[:4]


def default_polygon_rpc_url(env: Mapping[str, str]) -> str:
    return default_polygon_rpc_urls(env)[0]


def default_polygon_rpc_urls(env: Mapping[str, str]) -> tuple[str, ...]:
    configured = env.get("POLYMACH_POLYGON_RPC_URLS")
    if configured is None or not configured.strip():
        configured = env.get("POLYMACH_POLYGON_RPC_URL")
    urls = _parse_rpc_urls(configured)
    return urls or DEFAULT_POLYGON_RPC_URLS


def _normalize_hex(value: str) -> str:
    value = value.strip()
    return value if value.startswith("0x") else f"0x{value}"


def _normalize_address(value: str) -> str:
    value = _normalize_hex(value).lower()
    if len(value) != 42:
        raise PolyMachError(f"invalid address: {value}")
    int(value[2:], 16)
    return to_checksum_address(value)


def _hex_to_int(value: str | None, *, default: int = 0) -> int:
    if value is None:
        return default
    return int(value, 16)


def _parse_rpc_urls(raw: str | None) -> tuple[str, ...]:
    if raw is None:
        return ()
    urls = tuple(dict.fromkeys(part.strip() for part in raw.split(",") if part.strip()))
    return urls


def _is_transient_rpc_error_message(message: str) -> bool:
    lowered = message.lower()
    transient_markers = (
        "429",
        "408",
        "500",
        "502",
        "503",
        "504",
        "520",
        "522",
        "524",
        "rate limit",
        "too many requests",
        "temporarily unavailable",
        "service unavailable",
        "timed out",
        "timeout",
        "bad gateway",
        "gateway timeout",
        "connection reset",
        "connection refused",
        "remote end closed connection",
    )
    return any(marker in lowered for marker in transient_markers)


def _is_known_transaction_error_message(message: str) -> bool:
    lowered = message.lower()
    known_markers = (
        "already known",
        "already imported",
        "known transaction",
        "already exists",
    )
    return any(marker in lowered for marker in known_markers)


def _poll_delay(base_seconds: float, attempt: int) -> float:
    if base_seconds <= 0:
        return 0.0
    return min(base_seconds * (1.5**attempt), MAX_RPC_BACKOFF_SECONDS)


def _encode_transfer(recipient_address: str, amount_raw: int) -> str:
    recipient = bytes.fromhex(_normalize_address(recipient_address)[2:])
    if amount_raw < 0:
        raise PolyMachError("amount_raw must be non-negative")
    return "0x" + (ERC20_TRANSFER_SELECTOR + recipient.rjust(32, b"\0") + amount_raw.to_bytes(32, "big")).hex()


def _bump_gas_price(previous_gas_price_wei: int, bump_percent: int) -> int:
    if previous_gas_price_wei <= 0:
        return 1
    if bump_percent < 1:
        bump_percent = 1
    bumped = (previous_gas_price_wei * (100 + bump_percent) + 99) // 100
    return max(previous_gas_price_wei + 1, bumped)


@dataclass(frozen=True)
class SubmittedPayment:
    tx_hash: str
    sender_address: str
    recipient_address: str
    token_address: str
    chain_id: int
    cycles: int
    amount_raw: int
    amount_display: str
    gas_limit: int
    gas_price_wei: int
    nonce: int
    receipt_block_number: int
    confirmations: int


@runtime_checkable
class PaymentSigner(Protocol):
    @property
    def address(self) -> str: ...

    def sign_transaction(self, transaction: Mapping[str, Any]) -> bytes: ...


class LocalAccountSigner:
    __slots__ = ("_private_key", "_address")

    def __init__(self, private_key: str) -> None:
        normalized = _normalize_private_key(private_key)
        self._private_key = normalized
        account = Account.from_key(normalized)
        self._address = to_checksum_address(account.address)

    @classmethod
    def from_private_key(cls, private_key: str) -> "LocalAccountSigner":
        return cls(private_key)

    @classmethod
    def from_env(cls, env: Mapping[str, str]) -> "LocalAccountSigner":
        value = env.get("POLYMACH_WALLET_PRIVATE_KEY")
        if value is None or not value.strip():
            raise PolyMachError("POLYMACH_WALLET_PRIVATE_KEY is not configured")
        return cls(value)

    @property
    def address(self) -> str:
        return self._address

    def sign_transaction(self, transaction: Mapping[str, Any]) -> bytes:
        signed = Account.sign_transaction(dict(transaction), self._private_key)
        raw_transaction = getattr(signed, "raw_transaction", None)
        if raw_transaction is None:
            raw_transaction = getattr(signed, "rawTransaction", None)
        if raw_transaction is None:
            raise PolyMachError("failed to access signed raw transaction bytes")
        return bytes(raw_transaction)

    def __repr__(self) -> str:
        return f"LocalAccountSigner(address={self._address!r})"


class PolygonUsdcPayer:
    def __init__(
        self,
        *,
        env: Mapping[str, str],
        rpc_url: str | None = None,
    ) -> None:
        self._env = env
        self._rpc_urls = _parse_rpc_urls(rpc_url) if rpc_url is not None else default_polygon_rpc_urls(env)
        if not self._rpc_urls:
            raise PolyMachError("POLYMACH_POLYGON_RPC_URL is not configured")
        self._rpc_url = self._rpc_urls[0]

    def pay(
        self,
        payment: PaymentRequest,
        *,
        signer: PaymentSigner | None = None,
        private_key: str | None = None,
        gas_limit: int | None = None,
        gas_price_wei: int | None = None,
        replacement_attempts: int | None = None,
        replacement_gas_bump_percent: int | None = None,
        timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS,
        poll_interval_seconds: float = DEFAULT_POLL_INTERVAL_SECONDS,
    ) -> SubmittedPayment:
        if payment.cycles < 1:
            raise PolyMachError("payment cycles must be at least 1")

        resolved_signer = self._resolve_signer(signer=signer, private_key=private_key)
        sender_address = to_checksum_address(resolved_signer.address)

        chain_id = _hex_to_int(self._rpc("eth_chainId", []))
        if chain_id != payment.chain_id:
            raise PolyMachError(
                f"polygon rpc chain id mismatch: expected {payment.chain_id}, got {chain_id}"
            )

        token_address = _normalize_address(payment.token_address)
        recipient_address = _normalize_address(payment.recipient_address)
        nonce = _hex_to_int(
            self._rpc("eth_getTransactionCount", [sender_address, "pending"])
        )
        data = _encode_transfer(recipient_address, payment.amount_raw)

        resolved_gas_price = gas_price_wei or self._env_int("POLYMACH_PAYMENT_GAS_PRICE_WEI")
        if resolved_gas_price is None:
            resolved_gas_price = _hex_to_int(self._rpc("eth_gasPrice", []))
        resolved_gas_limit = gas_limit or self._env_int("POLYMACH_PAYMENT_GAS_LIMIT")
        if resolved_gas_limit is None:
            resolved_gas_limit = self._estimate_gas(
                from_address=sender_address,
                to_address=token_address,
                data=data,
            )
        if resolved_gas_limit <= 0:
            resolved_gas_limit = DEFAULT_GAS_LIMIT
        resolved_replacement_attempts = replacement_attempts
        if resolved_replacement_attempts is None:
            resolved_replacement_attempts = (
                self._env_int("POLYMACH_PAYMENT_REPLACEMENT_ATTEMPTS")
                or DEFAULT_REPLACEMENT_ATTEMPTS
            )
        if resolved_replacement_attempts < 0:
            raise PolyMachError("replacement_attempts must be non-negative")
        resolved_replacement_bump_percent = replacement_gas_bump_percent
        if resolved_replacement_bump_percent is None:
            resolved_replacement_bump_percent = (
                self._env_int("POLYMACH_PAYMENT_REPLACEMENT_GAS_BUMP_PERCENT")
                or DEFAULT_REPLACEMENT_GAS_BUMP_PERCENT
            )
        if resolved_replacement_bump_percent < 1:
            raise PolyMachError("replacement_gas_bump_percent must be at least 1")

        current_gas_price = resolved_gas_price
        attempted_tx_hashes: list[str] = []
        for attempt in range(resolved_replacement_attempts + 1):
            transaction = {
                "chainId": chain_id,
                "nonce": nonce,
                "to": token_address,
                "value": 0,
                "data": data,
                "gas": resolved_gas_limit,
                "gasPrice": current_gas_price,
            }
            raw_transaction = resolved_signer.sign_transaction(transaction)
            tx_hash = self._broadcast_raw_transaction(
                raw_transaction,
                timeout_seconds=timeout_seconds,
                poll_interval_seconds=poll_interval_seconds,
            )
            attempted_tx_hashes.append(tx_hash)
            try:
                receipt, confirmations = self._wait_for_confirmations(
                    tx_hash,
                    required_confirmations=payment.min_confirmations,
                    timeout_seconds=timeout_seconds,
                    poll_interval_seconds=poll_interval_seconds,
                )
            except PaymentPendingError as exc:
                if attempt >= resolved_replacement_attempts:
                    raise PaymentPendingError(
                        str(exc),
                        tx_hash=tx_hash,
                        confirmations=exc.confirmations,
                        required_confirmations=exc.required_confirmations,
                        attempted_tx_hashes=tuple(attempted_tx_hashes),
                    ) from exc
                current_gas_price = _bump_gas_price(
                    current_gas_price,
                    resolved_replacement_bump_percent,
                )
                continue
            return SubmittedPayment(
                tx_hash=tx_hash,
                sender_address=sender_address,
                recipient_address=recipient_address,
                token_address=token_address,
                chain_id=chain_id,
                cycles=payment.cycles,
                amount_raw=payment.amount_raw,
                amount_display=payment.amount_display,
                gas_limit=resolved_gas_limit,
                gas_price_wei=current_gas_price,
                nonce=nonce,
                receipt_block_number=_hex_to_int(receipt.get("blockNumber")),
                confirmations=confirmations,
            )
        raise PolyMachError("payment flow exhausted without returning a result")

    def _estimate_gas(
        self,
        *,
        from_address: str,
        to_address: str,
        data: str,
    ) -> int:
        try:
            return _hex_to_int(
                self._rpc(
                    "eth_estimateGas",
                    [{"from": from_address, "to": to_address, "value": "0x0", "data": data}],
                )
            )
        except PolyMachError:
            return DEFAULT_GAS_LIMIT

    def _broadcast_raw_transaction(
        self,
        raw_transaction: bytes,
        *,
        timeout_seconds: float,
        poll_interval_seconds: float,
    ) -> str:
        tx_hash = "0x" + keccak(raw_transaction).hex()
        payload = "0x" + raw_transaction.hex()
        broadcast_window_seconds = max(
            0.0,
            min(timeout_seconds, max(poll_interval_seconds * 2, 5.0), 15.0),
        )
        deadline = time.monotonic() + broadcast_window_seconds
        attempt = 0
        last_transient_error: PolyMachError | None = None

        while True:
            for rpc_url in self._ordered_rpc_urls():
                try:
                    result = self._rpc_via(rpc_url, "eth_sendRawTransaction", [payload])
                    self._rpc_url = rpc_url
                    if result is None:
                        return tx_hash
                    returned_hash = str(result)
                    if returned_hash.lower() != tx_hash.lower():
                        raise PolyMachError(
                            f"eth_sendRawTransaction {rpc_url} returned mismatched tx hash: "
                            f"expected {tx_hash}, got {returned_hash}"
                        )
                    return tx_hash
                except PolyMachError as exc:
                    message = str(exc)
                    if _is_known_transaction_error_message(message):
                        self._rpc_url = rpc_url
                        return tx_hash
                    if not _is_transient_rpc_error_message(message):
                        raise
                    last_transient_error = exc
            if time.monotonic() >= deadline:
                break
            delay = _poll_delay(poll_interval_seconds, attempt)
            attempt += 1
            if delay > 0:
                time.sleep(delay)

        if last_transient_error is not None:
            return tx_hash
        raise PolyMachError(f"payment transaction broadcast failed: {tx_hash}")

    def _wait_for_confirmations(
        self,
        tx_hash: str,
        *,
        required_confirmations: int,
        timeout_seconds: float,
        poll_interval_seconds: float,
    ) -> tuple[dict[str, Any], int]:
        deadline = time.monotonic() + max(timeout_seconds, poll_interval_seconds)
        last_error: PolyMachError | None = None
        seen_confirmations = 0
        receipt_seen = False
        attempt = 0
        while time.monotonic() < deadline:
            try:
                receipt = self._rpc("eth_getTransactionReceipt", [tx_hash])
            except PolyMachError as exc:
                if not _is_transient_rpc_error_message(str(exc)):
                    raise
                last_error = exc
                delay = _poll_delay(poll_interval_seconds, attempt)
                attempt += 1
                if delay > 0:
                    time.sleep(delay)
                continue
            if receipt is None:
                delay = _poll_delay(poll_interval_seconds, attempt)
                attempt += 1
                if delay > 0:
                    time.sleep(delay)
                continue
            if _hex_to_int(receipt.get("status")) != 1:
                raise PolyMachError(f"payment transaction reverted: {tx_hash}")
            receipt_seen = True
            block_number = _hex_to_int(receipt.get("blockNumber"))
            while time.monotonic() < deadline:
                try:
                    current_block = _hex_to_int(self._rpc("eth_blockNumber", []))
                except PolyMachError as exc:
                    if not _is_transient_rpc_error_message(str(exc)):
                        raise
                    last_error = exc
                    delay = _poll_delay(poll_interval_seconds, attempt)
                    attempt += 1
                    if delay > 0:
                        time.sleep(delay)
                    continue
                confirmations = max(0, current_block - block_number + 1)
                seen_confirmations = max(seen_confirmations, confirmations)
                if confirmations >= required_confirmations:
                    return receipt, confirmations
                delay = _poll_delay(poll_interval_seconds, attempt)
                attempt += 1
                if delay > 0:
                    time.sleep(delay)
            break
        detail = (
            f"payment transaction {tx_hash} reached {seen_confirmations}/{required_confirmations} "
            f"confirmation(s) before timeout"
            if receipt_seen
            else f"payment transaction {tx_hash} is still pending or could not be confirmed before timeout"
        )
        if last_error is not None:
            detail = f"{detail}; last rpc error: {last_error}"
        detail = f"{detail}; retry start(tx_hash={tx_hash!r}) to resume activation"
        raise PaymentPendingError(
            detail,
            tx_hash=tx_hash,
            confirmations=seen_confirmations if receipt_seen else None,
            required_confirmations=required_confirmations,
        )

    def _resolve_signer(
        self,
        *,
        signer: PaymentSigner | None,
        private_key: str | None,
    ) -> PaymentSigner:
        if signer is not None and private_key is not None:
            raise PolyMachError("pass either signer or private_key, not both")
        if signer is not None:
            return signer
        if private_key is not None:
            return LocalAccountSigner.from_private_key(private_key)
        if self._env.get("POLYMACH_WALLET_PRIVATE_KEY"):
            return LocalAccountSigner.from_env(self._env)
        raise PolyMachError(
            "a payment signer is required; pass signer=LocalAccountSigner.from_private_key(...), "
            "or use private_key=/POLYMACH_WALLET_PRIVATE_KEY as an advanced fallback"
        )

    def _env_int(self, key: str) -> int | None:
        raw = self._env.get(key)
        if raw is None or not raw.strip():
            return None
        try:
            return int(raw.strip(), 0)
        except ValueError as exc:
            raise PolyMachError(f"{key} must be an integer") from exc

    def _rpc(self, method: str, params: list[Any]) -> Any:
        errors: list[str] = []
        for rpc_url in self._ordered_rpc_urls():
            try:
                result = self._rpc_via(rpc_url, method, params)
            except PolyMachError as exc:
                errors.append(str(exc))
                continue
            self._rpc_url = rpc_url
            return result
        joined = " | ".join(errors) if errors else "no polygon rpc providers configured"
        raise PolyMachError(joined)

    def _rpc_via(self, rpc_url: str, method: str, params: list[Any]) -> Any:
        payload = json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params}).encode(
            "utf-8"
        )
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": f"polymach-sdk/{package_version()}",
        }
        req = request.Request(rpc_url, data=payload, headers=headers, method="POST")
        try:
            with request.urlopen(req, timeout=30) as response:
                raw = response.read()
        except error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace").strip()
            raise PolyMachError(
                f"{method} {rpc_url} failed ({exc.code}): {body or exc.reason}"
            ) from exc
        except error.URLError as exc:
            raise PolyMachError(f"{method} {rpc_url} failed: {exc.reason}") from exc

        try:
            decoded = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise PolyMachError(f"{method} {rpc_url} returned invalid JSON") from exc
        if not isinstance(decoded, dict):
            raise PolyMachError(f"{method} {rpc_url} returned an unexpected response shape")
        if decoded.get("error"):
            message = str(decoded["error"].get("message") or "rpc error")
            raise PolyMachError(f"{method} {rpc_url} failed: {message}")
        return decoded.get("result")

    def _ordered_rpc_urls(self) -> tuple[str, ...]:
        return tuple(dict.fromkeys((self._rpc_url, *self._rpc_urls)))


def _normalize_private_key(private_key: str) -> str:
    normalized = _normalize_hex(private_key.strip())
    if len(normalized) != 66:
        raise PolyMachError("private key must be 32 bytes")
    int(normalized[2:], 16)
    return normalized
