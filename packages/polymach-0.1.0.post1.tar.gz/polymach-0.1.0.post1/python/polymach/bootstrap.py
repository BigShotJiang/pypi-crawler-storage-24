from __future__ import annotations

import base64
import hashlib
import importlib.metadata
import json
import os
import platform
import shutil
import subprocess
import tarfile
import tempfile
import tomllib
import urllib.request
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from .errors import PolyMachError
from .release_key import PUBLIC_KEY_BASE64

DEFAULT_RELEASE_INDEX_URL = (
    "https://github.com/PolyMachQuant/build/releases/latest/download/index.json"
)


@dataclass(frozen=True)
class HostSpec:
    platform: str
    arch: str
    libc: str | None
    cpu_level: str | None


@dataclass(frozen=True)
class ArtifactSpec:
    product: str
    version: str
    artifact_id: str
    target: str
    platform: str
    arch: str
    archive_name: str
    archive_sha256: str
    binary_name: str
    archive_url: str
    libc: str | None = None
    cpu_level: str | None = None

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "ArtifactSpec":
        return cls(
            product=str(payload["product"]),
            version=str(payload["version"]),
            artifact_id=str(payload["artifact_id"]),
            target=str(payload["target"]),
            platform=str(payload["platform"]),
            arch=str(payload["arch"]),
            archive_name=str(payload["archive_name"]),
            archive_sha256=str(payload["archive_sha256"]),
            binary_name=str(payload.get("binary_name", "polymach")),
            archive_url=str(payload["archive_url"]),
            libc=str(payload["libc"]) if payload.get("libc") is not None else None,
            cpu_level=str(payload["cpu_level"]) if payload.get("cpu_level") is not None else None,
        )


def _env_flag(raw: str | None, default: bool) -> bool:
    if raw is None:
        return default
    return raw.strip().lower() not in {"0", "false", "no", "off"}


def package_version() -> str:
    try:
        return importlib.metadata.version("polymach")
    except importlib.metadata.PackageNotFoundError:
        pass

    here = Path(__file__).resolve()
    for parent in here.parents:
        pyproject = parent / "pyproject.toml"
        if not pyproject.exists():
            continue
        with pyproject.open("rb") as handle:
            payload = tomllib.load(handle)
        project = payload.get("project") or {}
        version = project.get("version")
        if version:
            return str(version)
    return "0.1.0.post1"


def release_public_key_base64(env: Mapping[str, str]) -> str | None:
    value = env.get("POLYMACH_RELEASE_PUBLIC_KEY")
    if value and value.strip():
        return value.strip()
    if PUBLIC_KEY_BASE64.strip():
        return PUBLIC_KEY_BASE64.strip()
    return None


def default_cache_root(env: Mapping[str, str]) -> Path:
    explicit = env.get("POLYMACH_CACHE_DIR")
    if explicit:
        return Path(explicit).expanduser()
    if os.name == "nt":
        base = env.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
        return Path(base) / "PolyMach"
    return Path(env.get("XDG_CACHE_HOME", str(Path.home() / ".cache"))) / "polymach"


def default_release_base_url(env: Mapping[str, str]) -> str:
    return env.get("POLYMACH_RELEASE_BASE_URL", "").strip()


def default_index_url(env: Mapping[str, str], version: str) -> str:
    explicit = env.get("POLYMACH_RELEASE_INDEX_URL")
    if explicit:
        return explicit.strip()
    base_url = default_release_base_url(env)
    if base_url:
        return f"{base_url.format(version=version).rstrip('/')}/index.json"
    return DEFAULT_RELEASE_INDEX_URL


def signature_url_for(url: str) -> str:
    if url.endswith(".json"):
        return f"{url[:-5]}.sig.json"
    return f"{url}.sig.json"


def download_bytes(url: str, env: Mapping[str, str]) -> bytes:
    headers = {"User-Agent": f"polymach-sdk/{package_version()}"}
    token = env.get("POLYMACH_RELEASE_TOKEN")
    if token:
        headers["Authorization"] = f"Bearer {token}"
    request = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(request, timeout=30) as response:
        return response.read()


def verify_signed_payload(
    payload_bytes: bytes,
    signature_bytes: bytes,
    public_key_base64: str,
) -> None:
    signature = json.loads(signature_bytes)
    expected_sha = hashlib.sha256(payload_bytes).hexdigest()
    actual_sha = str(signature.get("sha256_hex", "")).lower()
    if actual_sha != expected_sha:
        raise PolyMachError("signed payload sha256 mismatch")
    signature_base64 = str(signature.get("signature_base64", "")).strip()
    if not signature_base64:
        raise PolyMachError("signed payload missing signature_base64")
    verifying_key = Ed25519PublicKey.from_public_bytes(
        base64.b64decode(public_key_base64.strip(), validate=True)
    )
    verifying_key.verify(
        base64.b64decode(signature_base64, validate=True),
        payload_bytes,
    )


def detect_linux_libc() -> str | None:
    name, _version = platform.libc_ver()
    lowered = name.lower()
    if "glibc" in lowered or "gnu" in lowered:
        return "gnu"
    if "musl" in lowered:
        return "musl"
    return None


def collect_cpu_features() -> set[str]:
    features: set[str] = set()
    system = platform.system().lower()
    if system == "linux":
        cpuinfo = Path("/proc/cpuinfo")
        if cpuinfo.exists():
            for line in cpuinfo.read_text(errors="ignore").splitlines():
                if ":" not in line:
                    continue
                key, raw = line.split(":", 1)
                if key.strip().lower() not in {"flags", "features"}:
                    continue
                features.update(token.strip().lower() for token in raw.split() if token.strip())
                break
    elif system == "darwin":
        for key in ("machdep.cpu.features", "machdep.cpu.leaf7_features"):
            completed = subprocess.run(
                ["sysctl", "-n", key],
                text=True,
                capture_output=True,
                check=False,
            )
            if completed.returncode == 0:
                features.update(
                    token.strip().lower()
                    for token in completed.stdout.replace("\n", " ").split()
                    if token.strip()
                )

    aliases = {
        "pni": "sse3",
        "abm": "lzcnt",
    }
    for alias, canonical in aliases.items():
        if alias in features:
            features.add(canonical)
    return features


def detect_x86_64_level() -> str | None:
    features = collect_cpu_features()
    if not features:
        return None

    v2 = {"cx16", "lahf_lm", "popcnt", "sse3", "ssse3", "sse4_1", "sse4_2"}
    v3 = v2 | {"avx", "avx2", "bmi1", "bmi2", "f16c", "fma", "lzcnt", "movbe"}
    v4 = v3 | {"avx512f", "avx512bw", "avx512cd", "avx512dq", "avx512vl"}

    if v4.issubset(features):
        return "v4"
    if v3.issubset(features):
        return "v3"
    if v2.issubset(features):
        return "v2"
    return "v1"


def detect_host() -> HostSpec:
    system = platform.system().lower()
    if system == "darwin":
        host_platform = "macos"
    elif system == "windows":
        host_platform = "windows"
    else:
        host_platform = system

    machine = platform.machine().lower()
    if machine in {"x86_64", "amd64"}:
        arch = "x86_64"
    elif machine in {"arm64", "aarch64"}:
        arch = "aarch64"
    else:
        arch = machine

    libc = detect_linux_libc() if host_platform == "linux" else None
    cpu_level = detect_x86_64_level() if arch == "x86_64" else None
    return HostSpec(platform=host_platform, arch=arch, libc=libc, cpu_level=cpu_level)


def cpu_level_rank(level: str | None) -> int:
    mapping = {None: 1, "v1": 1, "v2": 2, "v3": 3, "v4": 4}
    return mapping.get(level, 0)


def choose_artifact(index_payload: Mapping[str, Any], env: Mapping[str, str]) -> ArtifactSpec:
    artifact_id = env.get("POLYMACH_ARTIFACT_ID")
    artifacts = [
        ArtifactSpec.from_dict(item)
        for item in index_payload.get("artifacts", [])
    ]
    if not artifacts:
        raise PolyMachError("release index did not contain any artifacts")

    if artifact_id:
        for artifact in artifacts:
            if artifact.artifact_id == artifact_id:
                return artifact
        raise PolyMachError(f"artifact id not found in release index: {artifact_id}")

    host = detect_host()
    host_level = cpu_level_rank(host.cpu_level)
    matches: list[tuple[tuple[int, int, int], ArtifactSpec]] = []
    for artifact in artifacts:
        if artifact.platform != host.platform:
            continue
        if artifact.arch != host.arch:
            continue
        if host.libc and artifact.libc and artifact.libc != host.libc:
            continue
        artifact_level = cpu_level_rank(artifact.cpu_level)
        if host.arch == "x86_64" and artifact_level > host_level:
            continue
        score = (
            artifact_level,
            1 if artifact.libc == host.libc else 0,
            1 if artifact.cpu_level == host.cpu_level else 0,
        )
        matches.append((score, artifact))

    if not matches:
        raise PolyMachError(
            f"no release artifact matched host platform={host.platform} arch={host.arch} libc={host.libc} cpu_level={host.cpu_level}"
        )

    matches.sort(key=lambda item: item[0], reverse=True)
    return matches[0][1]


def extract_archive(archive_path: Path, destination: Path) -> None:
    if archive_path.name.endswith(".zip"):
        with zipfile.ZipFile(archive_path) as archive:
            archive.extractall(destination)
        return
    with tarfile.open(archive_path, "r:*") as archive:
        archive.extractall(destination)


def resolve_downloaded_binary(
    binary_name: str,
    env: Mapping[str, str],
) -> Path | None:
    if not _env_flag(env.get("POLYMACH_AUTO_DOWNLOAD"), True):
        return None

    public_key = release_public_key_base64(env)
    if not public_key:
        return None

    version = package_version()
    index_url = default_index_url(env, version)
    try:
        index_bytes = download_bytes(index_url, env)
        signature_bytes = download_bytes(signature_url_for(index_url), env)
        verify_signed_payload(index_bytes, signature_bytes, public_key)
        index_payload = json.loads(index_bytes)
        artifact = choose_artifact(index_payload, env)
    except Exception as exc:  # noqa: BLE001
        raise PolyMachError(f"failed resolving signed runtime bundle: {exc}") from exc

    cache_root = default_cache_root(env) / "runtime" / artifact.version / artifact.artifact_id
    final_binary = cache_root / "bin" / binary_name
    if final_binary.exists():
        return final_binary

    cache_root.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=str(cache_root.parent)) as temp_dir_raw:
        temp_dir = Path(temp_dir_raw)
        archive_path = temp_dir / artifact.archive_name
        archive_bytes = download_bytes(artifact.archive_url, env)
        archive_path.write_bytes(archive_bytes)
        actual_sha = hashlib.sha256(archive_bytes).hexdigest()
        if actual_sha.lower() != artifact.archive_sha256.lower():
            raise PolyMachError("downloaded runtime archive sha256 mismatch")

        extracted = temp_dir / "extract"
        extracted.mkdir(parents=True, exist_ok=True)
        extract_archive(archive_path, extracted)

        candidates = list(extracted.rglob(binary_name))
        if not candidates:
            raise PolyMachError(
                f"downloaded archive did not contain expected binary: {binary_name}"
            )
        binary_path = candidates[0]
        bundle_root = binary_path.parent.parent
        if cache_root.exists():
            shutil.rmtree(cache_root)
        shutil.move(str(bundle_root), str(cache_root))

    final_binary.chmod(final_binary.stat().st_mode | 0o755)
    metadata = {
        "artifact_id": artifact.artifact_id,
        "target": artifact.target,
        "archive_url": artifact.archive_url,
        "archive_sha256": artifact.archive_sha256,
    }
    (cache_root / "artifact.json").write_text(json.dumps(metadata, indent=2) + "\n")
    return final_binary
