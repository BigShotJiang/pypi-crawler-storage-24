from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True)
class MachineFingerprint:
    version: int
    product: str
    os: str
    method: str
    fingerprint: str

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "MachineFingerprint":
        return cls(
            version=int(payload["version"]),
            product=str(payload["product"]),
            os=str(payload["os"]),
            method=str(payload["method"]),
            fingerprint=str(payload["fingerprint"]),
        )


@dataclass(frozen=True)
class LicenseClaims:
    version: int
    product: str
    license_id: str
    issued_at: int
    expires_at: int | None
    machine_fingerprint: str
    tier: str
    features: tuple[str, ...]
    wallet_address: str | None
    notes: str | None

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "LicenseClaims":
        return cls(
            version=int(payload["version"]),
            product=str(payload["product"]),
            license_id=str(payload["license_id"]),
            issued_at=int(payload["issued_at"]),
            expires_at=int(payload["expires_at"]) if payload.get("expires_at") is not None else None,
            machine_fingerprint=str(payload["machine_fingerprint"]),
            tier=str(payload["tier"]),
            features=tuple(str(item) for item in payload.get("features", [])),
            wallet_address=str(payload["wallet_address"]) if payload.get("wallet_address") is not None else None,
            notes=str(payload["notes"]) if payload.get("notes") is not None else None,
        )


@dataclass(frozen=True)
class LicenseStatus:
    license_path: str
    fingerprint: MachineFingerprint
    present: bool
    valid: bool
    public_key_configured: bool
    message: str
    claims: LicenseClaims | None

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "LicenseStatus":
        claims = payload.get("claims")
        return cls(
            license_path=str(payload["license_path"]),
            fingerprint=MachineFingerprint.from_dict(payload["fingerprint"]),
            present=bool(payload["present"]),
            valid=bool(payload["valid"]),
            public_key_configured=bool(payload["public_key_configured"]),
            message=str(payload["message"]),
            claims=LicenseClaims.from_dict(claims) if claims else None,
        )


@dataclass(frozen=True)
class SessionInfo:
    pid: int
    host: str
    chain_id: int
    ws_enabled: bool
    warmed_tokens: int

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "SessionInfo":
        return cls(
            pid=int(payload["pid"]),
            host=str(payload["host"]),
            chain_id=int(payload["chain_id"]),
            ws_enabled=bool(payload["ws_enabled"]),
            warmed_tokens=int(payload.get("warmed_tokens", 0)),
        )


@dataclass(frozen=True)
class SessionPrewarmResult:
    token_ids: tuple[str, ...]
    warmed_quotes: int
    warmed_order_metadata: int
    warmed_last_trade: int

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "SessionPrewarmResult":
        return cls(
            token_ids=tuple(str(item) for item in payload.get("token_ids", [])),
            warmed_quotes=int(payload.get("warmed_quotes", 0)),
            warmed_order_metadata=int(payload.get("warmed_order_metadata", 0)),
            warmed_last_trade=int(payload.get("warmed_last_trade", 0)),
        )


@dataclass(frozen=True)
class Healthcheck:
    host: str
    chain_id: int
    signature_type: int
    signer_address: str
    funder_address: str
    collateral_balance_usdc: float
    collateral_allowance_usdc: float
    token_id: str | None
    midpoint: float | None
    bid: float | None
    ask: float | None
    token_balance: float | None
    token_allowance: float | None

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "Healthcheck":
        return cls(
            host=str(payload["host"]),
            chain_id=int(payload["chain_id"]),
            signature_type=int(payload["signature_type"]),
            signer_address=str(payload["signer_address"]),
            funder_address=str(payload["funder_address"]),
            collateral_balance_usdc=float(payload["collateral_balance_usdc"]),
            collateral_allowance_usdc=float(payload["collateral_allowance_usdc"]),
            token_id=str(payload["token_id"]) if payload.get("token_id") is not None else None,
            midpoint=float(payload["midpoint"]) if payload.get("midpoint") is not None else None,
            bid=float(payload["bid"]) if payload.get("bid") is not None else None,
            ask=float(payload["ask"]) if payload.get("ask") is not None else None,
            token_balance=float(payload["token_balance"]) if payload.get("token_balance") is not None else None,
            token_allowance=float(payload["token_allowance"]) if payload.get("token_allowance") is not None else None,
        )


@dataclass(frozen=True)
class MidpointResponse:
    token_id: str
    midpoint: float

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "MidpointResponse":
        return cls(token_id=str(payload["token_id"]), midpoint=float(payload["midpoint"]))


@dataclass(frozen=True)
class MarketQuote:
    midpoint: float
    bid: float | None
    ask: float | None

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "MarketQuote":
        return cls(
            midpoint=float(payload["midpoint"]),
            bid=float(payload["bid"]) if payload.get("bid") is not None else None,
            ask=float(payload["ask"]) if payload.get("ask") is not None else None,
        )


@dataclass(frozen=True)
class Portfolio:
    token_id: str
    cash_cents: int
    position_qty: float
    avg_entry_price: float

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "Portfolio":
        return cls(
            token_id=str(payload["token_id"]),
            cash_cents=int(payload["cash_cents"]),
            position_qty=float(payload["position_qty"]),
            avg_entry_price=float(payload["avg_entry_price"]),
        )


@dataclass(frozen=True)
class LimitOrderReceipt:
    order_id: str
    qty: float
    limit_price: float
    making_amount: float
    taking_amount: float

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "LimitOrderReceipt":
        return cls(
            order_id=str(payload["order_id"]),
            qty=float(payload["qty"]),
            limit_price=float(payload["limit_price"]),
            making_amount=float(payload["making_amount"]),
            taking_amount=float(payload["taking_amount"]),
        )


@dataclass(frozen=True)
class SubmitTimingBreakdown:
    attempts: int
    build_sign_seconds: float
    header_seconds: float
    http_seconds: float
    decode_seconds: float
    submit_seconds: float
    allowance_update_seconds: float
    total_seconds: float

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "SubmitTimingBreakdown":
        return cls(
            attempts=int(payload["attempts"]),
            build_sign_seconds=float(payload["build_sign_seconds"]),
            header_seconds=float(payload["header_seconds"]),
            http_seconds=float(payload["http_seconds"]),
            decode_seconds=float(payload["decode_seconds"]),
            submit_seconds=float(payload["submit_seconds"]),
            allowance_update_seconds=float(payload["allowance_update_seconds"]),
            total_seconds=float(payload["total_seconds"]),
        )


@dataclass(frozen=True)
class TimedLimitResponse:
    receipt: LimitOrderReceipt
    timing: SubmitTimingBreakdown

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "TimedLimitResponse":
        return cls(
            receipt=LimitOrderReceipt.from_dict(payload["receipt"]),
            timing=SubmitTimingBreakdown.from_dict(payload["timing"]),
        )


@dataclass(frozen=True)
class Fill:
    side: str
    qty: float
    fill_price: float
    fee_cents: int
    cash_after_cents: int
    position_after_qty: float
    order_id: str

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "Fill":
        return cls(
            side=str(payload["side"]),
            qty=float(payload["qty"]),
            fill_price=float(payload["fill_price"]),
            fee_cents=int(payload["fee_cents"]),
            cash_after_cents=int(payload["cash_after_cents"]),
            position_after_qty=float(payload["position_after_qty"]),
            order_id=str(payload["order_id"]),
        )


@dataclass(frozen=True)
class CancelOrderResult:
    order_id: str
    canceled: bool

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "CancelOrderResult":
        return cls(order_id=str(payload["order_id"]), canceled=bool(payload["canceled"]))


@dataclass(frozen=True)
class Order:
    order_id: str
    status: str
    maker_address: str
    market: str
    token_id: str
    side: str
    original_size: float
    size_matched: float
    price: float
    outcome: str
    created_at: str
    expiration: str
    order_type: str
    associate_trades: tuple[str, ...]

    @property
    def remaining_size(self) -> float:
        return max(0.0, self.original_size - self.size_matched)

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "Order":
        return cls(
            order_id=str(payload["order_id"]),
            status=str(payload["status"]),
            maker_address=str(payload["maker_address"]),
            market=str(payload["market"]),
            token_id=str(payload["token_id"]),
            side=str(payload["side"]),
            original_size=float(payload["original_size"]),
            size_matched=float(payload["size_matched"]),
            price=float(payload["price"]),
            outcome=str(payload["outcome"]),
            created_at=str(payload["created_at"]),
            expiration=str(payload["expiration"]),
            order_type=str(payload["order_type"]),
            associate_trades=tuple(str(item) for item in payload.get("associate_trades", [])),
        )


@dataclass(frozen=True)
class Trade:
    trade_id: str
    taker_order_id: str
    market: str
    token_id: str
    side: str
    size: float
    fee_rate_bps: float
    price: float
    status: str
    match_time: str
    last_update: str
    outcome: str
    bucket_index: int
    maker_address: str
    trader_side: str
    transaction_hash: str
    error_msg: str | None

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "Trade":
        return cls(
            trade_id=str(payload["trade_id"]),
            taker_order_id=str(payload["taker_order_id"]),
            market=str(payload["market"]),
            token_id=str(payload["token_id"]),
            side=str(payload["side"]),
            size=float(payload["size"]),
            fee_rate_bps=float(payload["fee_rate_bps"]),
            price=float(payload["price"]),
            status=str(payload["status"]),
            match_time=str(payload["match_time"]),
            last_update=str(payload["last_update"]),
            outcome=str(payload["outcome"]),
            bucket_index=int(payload["bucket_index"]),
            maker_address=str(payload["maker_address"]),
            trader_side=str(payload["trader_side"]),
            transaction_hash=str(payload["transaction_hash"]),
            error_msg=str(payload["error_msg"]) if payload.get("error_msg") is not None else None,
        )


@dataclass(frozen=True)
class TradePage:
    data: tuple[Trade, ...]
    next_cursor: str
    limit: int
    count: int

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "TradePage":
        return cls(
            data=tuple(Trade.from_dict(item) for item in payload.get("data", [])),
            next_cursor=str(payload.get("next_cursor", "")),
            limit=int(payload.get("limit", 0)),
            count=int(payload.get("count", 0)),
        )


@dataclass(frozen=True)
class StreamQuote:
    token_id: str
    midpoint: float | None
    bid: float | None
    ask: float | None
    last_trade: float | None

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "StreamQuote":
        return cls(
            token_id=str(payload["token_id"]),
            midpoint=float(payload["midpoint"]) if payload.get("midpoint") is not None else None,
            bid=float(payload["bid"]) if payload.get("bid") is not None else None,
            ask=float(payload["ask"]) if payload.get("ask") is not None else None,
            last_trade=float(payload["last_trade"]) if payload.get("last_trade") is not None else None,
        )


@dataclass(frozen=True)
class QuoteStreamSnapshot:
    timestamp: str
    quotes: tuple[StreamQuote, ...]

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "QuoteStreamSnapshot":
        return cls(
            timestamp=str(payload["timestamp"]),
            quotes=tuple(StreamQuote.from_dict(item) for item in payload.get("quotes", [])),
        )


@dataclass(frozen=True)
class DiscoveryTag:
    id: str
    label: str | None
    slug: str | None

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "DiscoveryTag":
        return cls(
            id=str(payload["id"]),
            label=str(payload["label"]) if payload.get("label") is not None else None,
            slug=str(payload["slug"]) if payload.get("slug") is not None else None,
        )


@dataclass(frozen=True)
class DiscoveryProfile:
    id: str
    name: str | None
    pseudonym: str | None
    proxy_wallet: str | None

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "DiscoveryProfile":
        return cls(
            id=str(payload["id"]),
            name=str(payload["name"]) if payload.get("name") is not None else None,
            pseudonym=str(payload["pseudonym"]) if payload.get("pseudonym") is not None else None,
            proxy_wallet=str(payload["proxy_wallet"]) if payload.get("proxy_wallet") is not None else None,
        )


@dataclass(frozen=True)
class DiscoveryLiveQuote:
    midpoint: float | None
    bid: float | None
    ask: float | None
    last_trade: float | None

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "DiscoveryLiveQuote":
        return cls(
            midpoint=float(payload["midpoint"]) if payload.get("midpoint") is not None else None,
            bid=float(payload["bid"]) if payload.get("bid") is not None else None,
            ask=float(payload["ask"]) if payload.get("ask") is not None else None,
            last_trade=float(payload["last_trade"]) if payload.get("last_trade") is not None else None,
        )


@dataclass(frozen=True)
class DiscoveryOutcome:
    outcome: str
    token_id: str | None
    catalog_price: float | None
    live_quote: DiscoveryLiveQuote | None

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "DiscoveryOutcome":
        return cls(
            outcome=str(payload["outcome"]),
            token_id=str(payload["token_id"]) if payload.get("token_id") is not None else None,
            catalog_price=float(payload["catalog_price"]) if payload.get("catalog_price") is not None else None,
            live_quote=DiscoveryLiveQuote.from_dict(payload["live_quote"]) if payload.get("live_quote") is not None else None,
        )


@dataclass(frozen=True)
class DiscoveryMarket:
    id: str
    slug: str | None
    question: str | None
    condition_id: str | None
    event_id: str | None
    event_slug: str | None
    event_title: str | None
    category: str | None
    subcategory: str | None
    active: bool | None
    closed: bool | None
    accepting_orders: bool | None
    start_date: str | None
    end_date: str | None
    liquidity: float | None
    volume: float | None
    catalog_best_bid: float | None
    catalog_best_ask: float | None
    catalog_last_trade_price: float | None
    catalog_spread: float | None
    outcomes: tuple[DiscoveryOutcome, ...]
    tags: tuple[DiscoveryTag, ...]

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "DiscoveryMarket":
        return cls(
            id=str(payload["id"]),
            slug=str(payload["slug"]) if payload.get("slug") is not None else None,
            question=str(payload["question"]) if payload.get("question") is not None else None,
            condition_id=str(payload["condition_id"]) if payload.get("condition_id") is not None else None,
            event_id=str(payload["event_id"]) if payload.get("event_id") is not None else None,
            event_slug=str(payload["event_slug"]) if payload.get("event_slug") is not None else None,
            event_title=str(payload["event_title"]) if payload.get("event_title") is not None else None,
            category=str(payload["category"]) if payload.get("category") is not None else None,
            subcategory=str(payload["subcategory"]) if payload.get("subcategory") is not None else None,
            active=bool(payload["active"]) if payload.get("active") is not None else None,
            closed=bool(payload["closed"]) if payload.get("closed") is not None else None,
            accepting_orders=bool(payload["accepting_orders"]) if payload.get("accepting_orders") is not None else None,
            start_date=str(payload["start_date"]) if payload.get("start_date") is not None else None,
            end_date=str(payload["end_date"]) if payload.get("end_date") is not None else None,
            liquidity=float(payload["liquidity"]) if payload.get("liquidity") is not None else None,
            volume=float(payload["volume"]) if payload.get("volume") is not None else None,
            catalog_best_bid=float(payload["catalog_best_bid"]) if payload.get("catalog_best_bid") is not None else None,
            catalog_best_ask=float(payload["catalog_best_ask"]) if payload.get("catalog_best_ask") is not None else None,
            catalog_last_trade_price=float(payload["catalog_last_trade_price"]) if payload.get("catalog_last_trade_price") is not None else None,
            catalog_spread=float(payload["catalog_spread"]) if payload.get("catalog_spread") is not None else None,
            outcomes=tuple(DiscoveryOutcome.from_dict(item) for item in payload.get("outcomes", [])),
            tags=tuple(DiscoveryTag.from_dict(item) for item in payload.get("tags", [])),
        )


@dataclass(frozen=True)
class DiscoveryEvent:
    id: str
    slug: str | None
    title: str | None
    description: str | None
    category: str | None
    subcategory: str | None
    active: bool | None
    closed: bool | None
    start_date: str | None
    end_date: str | None
    liquidity: float | None
    volume: float | None
    tags: tuple[DiscoveryTag, ...]
    markets: tuple[DiscoveryMarket, ...]

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "DiscoveryEvent":
        return cls(
            id=str(payload["id"]),
            slug=str(payload["slug"]) if payload.get("slug") is not None else None,
            title=str(payload["title"]) if payload.get("title") is not None else None,
            description=str(payload["description"]) if payload.get("description") is not None else None,
            category=str(payload["category"]) if payload.get("category") is not None else None,
            subcategory=str(payload["subcategory"]) if payload.get("subcategory") is not None else None,
            active=bool(payload["active"]) if payload.get("active") is not None else None,
            closed=bool(payload["closed"]) if payload.get("closed") is not None else None,
            start_date=str(payload["start_date"]) if payload.get("start_date") is not None else None,
            end_date=str(payload["end_date"]) if payload.get("end_date") is not None else None,
            liquidity=float(payload["liquidity"]) if payload.get("liquidity") is not None else None,
            volume=float(payload["volume"]) if payload.get("volume") is not None else None,
            tags=tuple(DiscoveryTag.from_dict(item) for item in payload.get("tags", [])),
            markets=tuple(DiscoveryMarket.from_dict(item) for item in payload.get("markets", [])),
        )


@dataclass(frozen=True)
class DiscoverySearchResults:
    query: str
    events: tuple[DiscoveryEvent, ...]
    markets: tuple[DiscoveryMarket, ...]
    tags: tuple[DiscoveryTag, ...]
    profiles: tuple[DiscoveryProfile, ...]

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "DiscoverySearchResults":
        return cls(
            query=str(payload["query"]),
            events=tuple(DiscoveryEvent.from_dict(item) for item in payload.get("events", [])),
            markets=tuple(DiscoveryMarket.from_dict(item) for item in payload.get("markets", [])),
            tags=tuple(DiscoveryTag.from_dict(item) for item in payload.get("tags", [])),
            profiles=tuple(DiscoveryProfile.from_dict(item) for item in payload.get("profiles", [])),
        )


@dataclass(frozen=True)
class LicenseCatalog:
    service_url: str
    chain_id: int
    recipient_address: str
    token_address: str
    token_symbol: str
    token_decimals: int
    min_confirmations: int
    cycle_price_usdc: str
    billing_cycle_days: int
    features: tuple[str, ...]

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any], *, service_url: str) -> "LicenseCatalog":
        return cls(
            service_url=service_url.rstrip("/"),
            chain_id=int(payload["chain_id"]),
            recipient_address=str(payload["recipient_address"]),
            token_address=str(payload["token_address"]),
            token_symbol=str(payload["token_symbol"]),
            token_decimals=int(payload["token_decimals"]),
            min_confirmations=int(payload["min_confirmations"]),
            cycle_price_usdc=str(payload["cycle_price_usdc"]),
            billing_cycle_days=int(payload["billing_cycle_days"]),
            features=tuple(str(item) for item in payload.get("features", [])),
        )


@dataclass(frozen=True)
class PaymentRequest:
    service_url: str
    machine_fingerprint: str
    cycles: int
    chain_id: int
    recipient_address: str
    token_address: str
    token_symbol: str
    token_decimals: int
    amount_display: str
    amount_raw: int
    cycle_price_usdc: str
    billing_cycle_days: int
    features: tuple[str, ...]
    min_confirmations: int


@dataclass(frozen=True)
class ActivationResult:
    installed_path: str
    reused: bool
    tx_hash: str
    cycles: int
    claims: LicenseClaims
    payment_amount_display: str | None
    wallet_address: str | None


@dataclass(frozen=True)
class StartResult:
    ready: bool
    message: str
    license_status: LicenseStatus
    payment: PaymentRequest | None = None
    activation: ActivationResult | None = None
    session: SessionInfo | None = None
    prewarm: SessionPrewarmResult | None = None
