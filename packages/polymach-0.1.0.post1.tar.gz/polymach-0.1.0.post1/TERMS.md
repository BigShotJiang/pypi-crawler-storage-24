# Terms of Service

Last updated: March 9, 2026

These Terms of Service govern your use of the PolyMach software, hosted
services, release infrastructure, license activation flow, and related sites
and documentation that are made available by PolyMach.

By downloading, installing, activating, accessing, or using PolyMach, you agree
to these Terms.

If you do not agree, do not use PolyMach.

## 1. Scope

PolyMach currently includes:

- the public `polymach` Python SDK
- signed runtime binaries and release manifests
- the license and payment activation service
- documentation, examples, and related materials

The open-source repository is licensed under the MIT License. These Terms apply
in addition to the MIT License for use of the PolyMach runtime distribution,
license service, payment flow, and any related hosted services.

## 2. Software Tooling Only

PolyMach is software tooling only.

PolyMach is not:

- a broker
- an exchange
- a trading venue
- a custodian
- an investment adviser
- a fiduciary
- a law firm
- a tax adviser

PolyMach does not provide investment, legal, tax, accounting, compliance, or
trading advice.

You are solely responsible for every order, payment, strategy, workflow, agent,
automation, and deployment that uses PolyMach.

## 3. No Affiliation With Polymarket

PolyMach is an independent product and is not affiliated with, endorsed by,
sponsored by, or approved by Polymarket.

Any reference to Polymarket is descriptive only.

## 4. Eligibility And Compliance

You may use PolyMach only if you are legally permitted to do so.

You are solely responsible for determining whether your use of PolyMach and any
related venue, wallet, token, RPC provider, market, or strategy is lawful and
permitted in every relevant jurisdiction.

You are also solely responsible for complying with:

- venue terms
- API terms
- sanctions and export controls
- securities, derivatives, gaming, tax, AML, and KYC rules
- any other laws or regulations that apply to you, your systems, your users, or
  your agents

## 5. Agents, Automation, And Keys

You are fully responsible for the actions of any bot, script, workflow, model,
agent, orchestration layer, or autonomous system that uses PolyMach.

An action taken by your software or agent is treated as your action.

You are also solely responsible for:

- private keys
- seed phrases
- wallet security
- API credentials
- RPC credentials
- machine security
- server security
- prompt security
- local secrets
- license files

PolyMach is not responsible for losses caused by compromised keys, host
compromise, prompt injection, malicious dependencies, operator error, or agent
misbehavior.

## 6. Pricing, Billing, And Refunds

Unless PolyMach states otherwise at the time of purchase, the standard machine
license price is 50 USDC per machine per 30-day cycle.

The payment amount and cycle count returned by the PolyMach license service at
the time of activation control for a given purchase.

You may prepay multiple cycles in a single payment if the service permits it.

All payments are final.

There are no refunds, credits, chargebacks, reversals, or prorations except if
PolyMach expressly agrees otherwise in writing.

You are responsible for:

- sending the correct token on the correct chain
- using the correct recipient address returned by the service
- blockchain gas fees
- RPC fees
- exchange or wallet fees
- taxes and similar charges
- losses caused by sending funds to the wrong address, wrong chain, or wrong
  asset

If you submit an incorrect payment, PolyMach has no obligation to recover,
credit, or refund it.

PolyMach may change future pricing, billing rules, supported assets, supported
chains, or service features at any time on a prospective basis.

## 7. Machine Licenses

PolyMach licenses may be machine-bound, wallet-bound, or otherwise scoped by
the current activation flow.

A license may expire, be suspended, be replaced, or be denied if:

- the payment is invalid or insufficient
- the payment cannot be verified
- the machine fingerprint does not match the issued license
- the service detects abuse, tampering, duplication, or fraud
- PolyMach changes or discontinues the activation flow

PolyMach is not required to maintain backward compatibility with any specific
activation method, binary, or runtime distribution path.

## 8. Availability And Third-Party Dependencies

PolyMach depends on third-party systems outside PolyMach's control, including:

- blockchains
- RPC providers
- Polymarket infrastructure
- hosting providers
- package indexes
- GitHub or other artifact hosts
- wallet software
- web APIs and websocket services

PolyMach does not guarantee:

- uptime
- availability
- uninterrupted service
- successful runtime downloads
- venue access
- order acceptance
- execution quality
- data freshness
- compatibility with your system

Install, payment, activation, and runtime use may succeed or fail differently
depending on your network path, deployment environment, IP address, geography,
jurisdiction, or third-party service behavior.

## 9. Suspension And Termination

PolyMach may suspend, refuse, or terminate access to the hosted service or
license flow at any time, with or without notice, including if PolyMach
reasonably suspects:

- fraud
- abuse
- tampering
- security risk
- policy violations
- unlawful use
- attempts to bypass licensing or payment controls

You may stop using PolyMach at any time, but stopping use does not entitle you
to a refund.

## 10. Disclaimer Of Warranties

To the maximum extent permitted by law, PolyMach is provided on an "AS IS" and
"AS AVAILABLE" basis, without warranties of any kind, whether express, implied,
statutory, or otherwise.

This includes, without limitation, no warranty of:

- correctness
- profitability
- merchantability
- fitness for a particular purpose
- non-infringement
- legality
- data accuracy
- execution quality
- security
- latency
- uptime
- compatibility

## 11. Limitation Of Liability

To the maximum extent permitted by law, PolyMach and its operators will not be
liable for any direct, indirect, incidental, consequential, special, exemplary,
punitive, or other damages or losses arising out of or related to PolyMach.

This includes, without limitation:

- trading losses
- slippage
- missed fills
- partial fills
- stale or missing data
- failed payments
- failed activations
- loss of profits
- loss of revenue
- loss of business
- loss of reputation
- tax consequences
- regulatory consequences
- security incidents
- key compromise
- data loss

If liability cannot be excluded, the maximum aggregate liability of PolyMach and
its operators for any claim related to PolyMach will not exceed the amount you
paid directly to PolyMach for the specific 30-day billing cycle that gave rise
to the claim.

## 12. Indemnity

You agree to indemnify and hold harmless PolyMach and its operators from any
claims, liabilities, damages, judgments, losses, costs, and expenses, including
reasonable legal fees, arising out of or related to:

- your use of PolyMach
- your payments
- your trading activity
- your agents or automations
- your violation of law
- your violation of venue terms
- your breach of these Terms

## 13. Changes

PolyMach may update these Terms from time to time.

The updated version becomes effective when posted, unless stated otherwise.
Continuing to use PolyMach after the effective date means you accept the updated
Terms.

## 14. Contact

Questions about these Terms may be sent to:

`hello@polymach.io`
