from __future__ import annotations

import json
import os
import shutil
import statistics
import subprocess
import time
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path
from typing import Any, Callable, Mapping, TypeVar

from polymach import PolyMach
from polymach.models import QuoteStreamSnapshot


BTC_5M_SERIES_ID = "10684"
DEFAULT_USER_AGENT = "polymach-live-tests/0.1"
SIGNATURE_TYPE_MAP = {
    "0": "eoa",
    "1": "proxy",
    "2": "gnosis-safe",
}
T = TypeVar("T")


@dataclass(frozen=True)
class CommandResult:
    command: tuple[str, ...]
    returncode: int
    wall_ms: float
    stdout: str
    stderr: str

    def json_payload(self) -> Any:
        return json.loads(self.stdout)


@dataclass(frozen=True)
class Btc5mMarket:
    slug: str
    question: str
    condition_id: str
    yes_outcome: str
    no_outcome: str
    yes_token: str
    no_token: str
    secs_to_end: float


class ReportRecorder:
    def __init__(self, repo_root: Path) -> None:
        self._repo_root = repo_root
        self._payload: dict[str, Any] = {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "tests": {},
        }

    def record(self, name: str, payload: Mapping[str, Any]) -> None:
        self._payload["tests"][name] = dict(payload)

    def write(self) -> Path:
        out_dir = self._repo_root / "build" / "test-artifacts"
        out_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        out_path = out_dir / f"live-vs-official-{stamp}.json"
        out_path.write_text(json.dumps(self._payload, indent=2) + "\n")
        return out_path


class OfficialCli:
    def __init__(self, binary: Path, env: Mapping[str, str]) -> None:
        self._binary = binary
        self._env = dict(env)

    def run_json(self, *args: str, timeout: float = 30.0) -> tuple[Any, CommandResult]:
        command = [str(self._binary), "-o", "json", *[str(arg) for arg in args]]
        started = time.perf_counter()
        completed = subprocess.run(
            command,
            env=self._env,
            text=True,
            capture_output=True,
            timeout=timeout,
            check=False,
        )
        wall_ms = (time.perf_counter() - started) * 1000.0
        result = CommandResult(
            command=tuple(command),
            returncode=completed.returncode,
            wall_ms=wall_ms,
            stdout=completed.stdout.strip(),
            stderr=completed.stderr.strip(),
        )
        if completed.returncode != 0:
            raise RuntimeError(
                f"official CLI failed ({completed.returncode}): {' '.join(command)}\n"
                f"stdout={result.stdout}\nstderr={result.stderr}"
            )
        return result.json_payload(), result

    def markets_get(self, slug: str) -> tuple[dict[str, Any], CommandResult]:
        payload, result = self.run_json("markets", "get", slug)
        return dict(payload), result

    def midpoint(self, token_id: str) -> tuple[dict[str, Any], CommandResult]:
        payload, result = self.run_json("clob", "midpoint", token_id)
        return dict(payload), result

    def book(self, token_id: str) -> tuple[dict[str, Any], CommandResult]:
        payload, result = self.run_json("clob", "book", token_id)
        return dict(payload), result

    def last_trade(self, token_id: str) -> tuple[dict[str, Any], CommandResult]:
        payload, result = self.run_json("clob", "last-trade", token_id)
        return dict(payload), result

    def balance_collateral(self) -> tuple[dict[str, Any], CommandResult]:
        payload, result = self.run_json("clob", "balance", "--asset-type", "collateral")
        return dict(payload), result

    def balance_conditional(self, token_id: str) -> tuple[dict[str, Any], CommandResult]:
        payload, result = self.run_json(
            "clob",
            "balance",
            "--asset-type",
            "conditional",
            "--token",
            token_id,
        )
        return dict(payload), result

    def create_limit_buy(
        self,
        token_id: str,
        *,
        qty: float,
        price: float,
    ) -> tuple[dict[str, Any], CommandResult]:
        payload, result = self.run_json(
            "clob",
            "create-order",
            "--token",
            token_id,
            "--side",
            "buy",
            "--price",
            str(price),
            "--size",
            str(qty),
            "--order-type",
            "GTC",
        )
        return dict(payload), result

    def cancel(self, order_id: str) -> tuple[dict[str, Any], CommandResult]:
        payload, result = self.run_json("clob", "cancel", order_id)
        return dict(payload), result


def load_env_file(path: Path) -> dict[str, str]:
    loaded: dict[str, str] = {}
    for line in path.read_text().splitlines():
        raw = line.strip()
        if not raw or raw.startswith("#") or "=" not in raw:
            continue
        key, value = raw.split("=", 1)
        loaded[key] = value
    return loaded


def find_env_file(repo_root: Path) -> Path | None:
    explicit = os.environ.get("POLYMACH_TEST_ENV_FILE")
    if explicit:
        path = Path(explicit).expanduser()
        if path.exists():
            return path
        raise FileNotFoundError(f"POLYMACH_TEST_ENV_FILE points to missing file: {path}")
    candidates = [
        repo_root / ".env",
        repo_root.parent / ".env",
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return None


def resolve_polymach_binary(repo_root: Path) -> Path:
    explicit = os.environ.get("POLYMACH_BIN")
    if explicit:
        path = Path(explicit).expanduser()
        if path.exists():
            return path
        raise FileNotFoundError(f"POLYMACH_BIN points to missing file: {path}")
    sibling = repo_root.parent / "polymach-rs" / "target" / "release" / "polymach"
    if sibling.exists():
        return sibling
    debug = repo_root.parent / "polymach-rs" / "target" / "debug" / "polymach"
    if debug.exists():
        return debug
    which = shutil.which("polymach")
    if which:
        return Path(which)
    raise FileNotFoundError("unable to resolve polymach binary for live tests")


def resolve_official_binary() -> Path:
    explicit = os.environ.get("POLYMARKET_CLI_BIN")
    if explicit:
        path = Path(explicit).expanduser()
        if path.exists():
            return path
        raise FileNotFoundError(f"POLYMARKET_CLI_BIN points to missing file: {path}")
    which = shutil.which("polymarket")
    if which:
        return Path(which)
    raise FileNotFoundError("unable to resolve installed polymarket CLI")


def build_test_env(repo_root: Path) -> dict[str, str]:
    env = os.environ.copy()
    env_file = find_env_file(repo_root)
    if env_file is not None:
        env.update(load_env_file(env_file))
    env["POLYMACH_BIN"] = str(resolve_polymach_binary(repo_root))
    env.setdefault("POLYMACH_PERSISTENT", "1")
    return env


def build_official_env(base_env: Mapping[str, str]) -> dict[str, str]:
    env = dict(base_env)
    if "POLYMARKET_PRIVATE_KEY" not in env and "POLYMACH_POLYMARKET_PRIVATE_KEY" in env:
        env["POLYMARKET_PRIVATE_KEY"] = env["POLYMACH_POLYMARKET_PRIVATE_KEY"]
    if "POLYMARKET_SIGNATURE_TYPE" not in env:
        raw_sig = env.get("POLYMACH_POLYMARKET_SIGNATURE_TYPE")
        if raw_sig is not None:
            env["POLYMARKET_SIGNATURE_TYPE"] = SIGNATURE_TYPE_MAP.get(raw_sig, raw_sig)
    if "POLYMARKET_PRIVATE_KEY" not in env:
        raise RuntimeError("official CLI tests require POLYMARKET_PRIVATE_KEY or POLYMACH_POLYMARKET_PRIVATE_KEY")
    return env


def parse_jsonish_array(raw: Any) -> list[Any]:
    if raw is None:
        return []
    if isinstance(raw, list):
        return list(raw)
    if isinstance(raw, str):
        return list(json.loads(raw))
    raise TypeError(f"unsupported json-ish array type: {type(raw).__name__}")


def normalize_token_id(raw: Any) -> str:
    value = str(raw)
    if value.startswith("0x"):
        return str(int(value, 16))
    return value


def normalize_official_market(payload: Mapping[str, Any]) -> dict[str, Any]:
    normalized = dict(payload)
    normalized["outcomes"] = [str(item) for item in parse_jsonish_array(payload.get("outcomes"))]
    normalized["clobTokenIds"] = [
        normalize_token_id(item) for item in parse_jsonish_array(payload.get("clobTokenIds"))
    ]
    return normalized


def fetch_json(url: str) -> Any:
    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": DEFAULT_USER_AGENT,
            "Accept": "application/json",
        },
    )
    with urllib.request.urlopen(request, timeout=20) as response:
        return json.load(response)


def fetch_current_btc5m_market(
    gamma_api_url: str,
    *,
    min_secs_remaining: float,
) -> Btc5mMarket:
    now = datetime.now(timezone.utc)
    base = gamma_api_url.rstrip("/") + "/events"
    page_size = 200
    best_eligible: tuple[float, dict[str, Any]] | None = None
    best_any: tuple[float, dict[str, Any]] | None = None

    for page in range(12):
        params = urllib.parse.urlencode(
            [
                ("series_id", BTC_5M_SERIES_ID),
                ("active", "true"),
                ("closed", "false"),
                ("limit", str(page_size)),
                ("offset", str(page * page_size)),
            ]
        )
        payload = fetch_json(f"{base}?{params}")
        if not payload:
            break
        for event in payload:
            for market in event.get("markets") or []:
                slug = str(market.get("slug") or "")
                if not slug.startswith("btc-updown-5m-"):
                    continue
                if market.get("closed") is True or market.get("acceptingOrders") is False:
                    continue
                end_date = market.get("endDate")
                if not end_date:
                    continue
                secs_to_end = (
                    datetime.fromisoformat(str(end_date).replace("Z", "+00:00")) - now
                ).total_seconds()
                if secs_to_end <= 0:
                    continue
                if best_any is None or secs_to_end < best_any[0]:
                    best_any = (secs_to_end, market)
                if secs_to_end >= min_secs_remaining and (
                    best_eligible is None or secs_to_end < best_eligible[0]
                ):
                    best_eligible = (secs_to_end, market)
        if best_eligible is not None:
            break

    chosen = best_eligible or best_any
    if chosen is None:
        raise RuntimeError("unable to locate an active BTC 5-minute market")
    secs_to_end, market = chosen
    if secs_to_end < min_secs_remaining:
        raise RuntimeError(
            f"current BTC 5-minute market only has {secs_to_end:.1f}s remaining; "
            f"need at least {min_secs_remaining:.1f}s"
        )

    outcomes = parse_jsonish_array(market.get("outcomes"))
    token_ids = [normalize_token_id(item) for item in parse_jsonish_array(market.get("clobTokenIds"))]
    if len(outcomes) < 2 or len(token_ids) < 2:
        raise RuntimeError("current BTC 5-minute market is missing outcomes or token ids")

    return Btc5mMarket(
        slug=str(market["slug"]),
        question=str(market["question"]),
        condition_id=str(market["conditionId"]),
        yes_outcome=str(outcomes[0]),
        no_outcome=str(outcomes[1]),
        yes_token=token_ids[0],
        no_token=token_ids[1],
        secs_to_end=secs_to_end,
    )


def timed_call(fn: Callable[..., T], *args: Any, **kwargs: Any) -> tuple[T, float]:
    started = time.perf_counter()
    result = fn(*args, **kwargs)
    return result, (time.perf_counter() - started) * 1000.0


def percentile(values: list[float], q: float) -> float:
    ordered = sorted(values)
    if not ordered:
        raise ValueError("cannot compute percentile of empty values")
    if len(ordered) == 1:
        return ordered[0]
    idx = (len(ordered) - 1) * q
    lo = int(idx)
    hi = min(len(ordered) - 1, lo + 1)
    frac = idx - lo
    return ordered[lo] * (1.0 - frac) + ordered[hi] * frac


def summarize(values: list[float]) -> dict[str, float]:
    ordered = sorted(values)
    return {
        "count": float(len(ordered)),
        "min_ms": ordered[0],
        "p50_ms": percentile(ordered, 0.50),
        "p95_ms": percentile(ordered, 0.95),
        "max_ms": ordered[-1],
        "mean_ms": statistics.fmean(ordered),
    }


def top_of_book(payload: Mapping[str, Any]) -> tuple[float | None, float | None]:
    bids = payload.get("bids") or []
    asks = payload.get("asks") or []
    bid = max((float(level["price"]) for level in bids), default=None)
    ask = min((float(level["price"]) for level in asks), default=None)
    return bid, ask


def parse_optional_float(raw: Any) -> float | None:
    if raw is None:
        return None
    return float(raw)


def value_within_band(
    value: float | None,
    left: float | None,
    right: float | None,
    *,
    tolerance: float,
) -> bool:
    if value is None or left is None or right is None:
        return False
    low = min(left, right) - tolerance
    high = max(left, right) + tolerance
    return low <= value <= high


def max_allowance_value(payload: Mapping[str, Any]) -> float:
    allowances = payload.get("allowances") or {}
    if not allowances:
        return 0.0
    return max(float(Decimal(str(value))) for value in allowances.values())


def measure_stream(
    engine: PolyMach,
    token_id: str,
    *,
    count: int,
    interval_ms: int,
) -> dict[str, Any]:
    started = time.perf_counter()
    arrivals_ms: list[float] = []
    samples: list[dict[str, Any]] = []

    for snapshot in engine.market.stream(
        [token_id],
        interval_ms=interval_ms,
        include_last_trade=True,
        count=count,
    ):
        elapsed_ms = (time.perf_counter() - started) * 1000.0
        arrivals_ms.append(elapsed_ms)
        samples.append(_stream_snapshot_to_dict(snapshot, elapsed_ms))

    if not arrivals_ms:
        raise RuntimeError("polymach stream produced no snapshots")

    intervals = [
        arrivals_ms[idx] - arrivals_ms[idx - 1]
        for idx in range(1, len(arrivals_ms))
    ]
    payload: dict[str, Any] = {
        "first_snapshot_ms": arrivals_ms[0],
        "snapshot_count": len(arrivals_ms),
        "samples": samples[:5],
    }
    if intervals:
        payload["interval_summary"] = summarize(intervals)
    return payload


def _stream_snapshot_to_dict(snapshot: QuoteStreamSnapshot, observed_ms: float) -> dict[str, Any]:
    return {
        "timestamp": snapshot.timestamp,
        "observed_ms": observed_ms,
        "quotes": [
            {
                "token_id": quote.token_id,
                "midpoint": quote.midpoint,
                "bid": quote.bid,
                "ask": quote.ask,
                "last_trade": quote.last_trade,
            }
            for quote in snapshot.quotes
        ],
    }
