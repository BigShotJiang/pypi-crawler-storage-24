from __future__ import annotations

from polymach.bootstrap import DEFAULT_RELEASE_INDEX_URL, default_index_url


def test_default_index_url_uses_public_github_release() -> None:
    assert default_index_url({}, "0.1.0") == DEFAULT_RELEASE_INDEX_URL


def test_default_index_url_prefers_explicit_index_override() -> None:
    assert (
        default_index_url(
            {"POLYMACH_RELEASE_INDEX_URL": "https://downloads.example.com/index.json"},
            "0.1.0",
        )
        == "https://downloads.example.com/index.json"
    )


def test_default_index_url_supports_versioned_base_override() -> None:
    assert (
        default_index_url(
            {"POLYMACH_RELEASE_BASE_URL": "https://downloads.example.com/releases/{version}"},
            "0.1.0",
        )
        == "https://downloads.example.com/releases/0.1.0/index.json"
    )
