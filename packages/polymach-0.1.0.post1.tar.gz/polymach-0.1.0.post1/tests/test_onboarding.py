from __future__ import annotations

import json
from typing import Any, Mapping

import pytest

from polymach import LocalAccountSigner, PaymentRequiredError, PolyMach, SubmittedPayment
from polymach.models import (
    LicenseCatalog,
    LicenseClaims,
    LicenseStatus,
    MachineFingerprint,
    PaymentRequest,
    SessionInfo,
    SessionPrewarmResult,
)
from polymach.onboarding import LicenseServiceClient


def make_fingerprint() -> MachineFingerprint:
    return MachineFingerprint(
        version=1,
        product="polymach",
        os="linux",
        method="linux-machine-id",
        fingerprint="f" * 64,
    )


def make_license_status(*, valid: bool, message: str = "ok") -> LicenseStatus:
    return LicenseStatus(
        license_path="/tmp/license.json",
        fingerprint=make_fingerprint(),
        present=valid,
        valid=valid,
        public_key_configured=True,
        message=message,
        claims=(
            LicenseClaims(
                version=1,
                product="polymach",
                license_id="lic_123",
                issued_at=1,
                expires_at=None,
                machine_fingerprint=make_fingerprint().fingerprint,
                tier="subscription",
                features=("core",),
                wallet_address="0x1111111111111111111111111111111111111111",
                notes=None,
            )
            if valid
            else None
        ),
    )


class FakeRuntime:
    def __init__(self) -> None:
        self.env = {"POLYMACH_LICENSE_BASE_URL": "https://license.test"}
        self.closed = 0

    def close(self) -> None:
        self.closed += 1


class FakeSystem:
    def fingerprint(self) -> MachineFingerprint:
        return make_fingerprint()


class FakeLicense:
    def __init__(self, statuses: list[LicenseStatus]) -> None:
        self._statuses = list(statuses)
        self.installed_documents: list[dict[str, object]] = []

    def status(self) -> LicenseStatus:
        if len(self._statuses) > 1:
            return self._statuses.pop(0)
        return self._statuses[0]

    def install(self, source: str) -> str:
        with open(source, "r", encoding="utf-8") as handle:
            self.installed_documents.append(json.load(handle))
        return "/tmp/.polymach/license.json"


class FakeSession:
    def __init__(self) -> None:
        self.prewarm_calls: list[tuple[tuple[str, ...], bool, bool, bool]] = []

    def status(self) -> SessionInfo:
        return SessionInfo(
            pid=1234,
            host="https://clob.polymarket.com",
            chain_id=137,
            ws_enabled=True,
            warmed_tokens=1,
        )

    def prewarm(
        self,
        token_ids: list[str] | tuple[str, ...],
        *,
        quotes: bool,
        order_metadata: bool,
        last_trade: bool,
    ) -> SessionPrewarmResult:
        self.prewarm_calls.append((tuple(token_ids), quotes, order_metadata, last_trade))
        return SessionPrewarmResult(
            token_ids=tuple(token_ids),
            warmed_quotes=len(token_ids) if quotes else 0,
            warmed_order_metadata=len(token_ids) if order_metadata else 0,
            warmed_last_trade=len(token_ids) if last_trade else 0,
        )


class FakeService:
    def __init__(self) -> None:
        self.activate_calls: list[dict[str, object]] = []

    def payment_request(self, *, machine_fingerprint: str, cycles: int) -> PaymentRequest:
        return PaymentRequest(
            service_url="https://license.test",
            machine_fingerprint=machine_fingerprint,
            cycles=cycles,
            chain_id=137,
            recipient_address="0x2222222222222222222222222222222222222222",
            token_address="0x3333333333333333333333333333333333333333",
            token_symbol="USDC",
            token_decimals=6,
            amount_display=str(50 * cycles),
            amount_raw=50_000_000 * cycles,
            cycle_price_usdc="50",
            billing_cycle_days=30,
            features=("core",),
            min_confirmations=5,
        )

    def activate(
        self,
        *,
        tx_hash: str,
        machine_fingerprint: str,
        wallet_address: str | None = None,
        notes: str | None = None,
    ) -> dict[str, object]:
        self.activate_calls.append(
            {
                "tx_hash": tx_hash,
                "machine_fingerprint": machine_fingerprint,
                "wallet_address": wallet_address,
                "notes": notes,
            }
        )
        return {
            "license": {
                "claims": {
                    "version": 1,
                    "product": "polymach",
                    "license_id": "lic_abc",
                    "issued_at": 123,
                    "expires_at": None,
                    "machine_fingerprint": machine_fingerprint,
                    "tier": "subscription",
                    "features": ["core"],
                    "wallet_address": "0x1111111111111111111111111111111111111111",
                    "notes": "test",
                },
                "signature_base64": "ZmFrZQ==",
            },
            "payment": {
                "tx_hash": tx_hash,
                "payer_address": "0x1111111111111111111111111111111111111111",
                "amount_display": "100",
            },
            "cycles": 2,
            "reused": False,
        }


class FakePayer:
    def __init__(self) -> None:
        self.calls: list[dict[str, object]] = []

    def pay(
        self,
        payment: PaymentRequest,
        *,
        signer=None,
        private_key: str | None = None,
        gas_limit: int | None = None,
        gas_price_wei: int | None = None,
        replacement_attempts: int | None = None,
        replacement_gas_bump_percent: int | None = None,
        timeout_seconds: float = 180.0,
        poll_interval_seconds: float = 2.0,
    ) -> SubmittedPayment:
        self.calls.append(
            {
                "payment": payment,
                "signer": signer,
                "private_key": private_key,
                "gas_limit": gas_limit,
                "gas_price_wei": gas_price_wei,
                "replacement_attempts": replacement_attempts,
                "replacement_gas_bump_percent": replacement_gas_bump_percent,
                "timeout_seconds": timeout_seconds,
                "poll_interval_seconds": poll_interval_seconds,
            }
        )
        return SubmittedPayment(
            tx_hash="0x" + "2" * 64,
            sender_address="0x1111111111111111111111111111111111111111",
            recipient_address=payment.recipient_address,
            token_address=payment.token_address,
            chain_id=payment.chain_id,
            cycles=payment.cycles,
            amount_raw=payment.amount_raw,
            amount_display=payment.amount_display,
            gas_limit=65_000,
            gas_price_wei=30_000_000_000,
            nonce=7,
            receipt_block_number=123,
            confirmations=payment.min_confirmations,
        )


class FakeSigner:
    def __init__(self, address: str = "0x1111111111111111111111111111111111111111") -> None:
        self._address = address

    @property
    def address(self) -> str:
        return self._address

    def sign_transaction(self, transaction: Mapping[str, Any]) -> bytes:
        return b"fake-signed-transaction"


def build_fake_engine(*, valid: bool = False) -> tuple[PolyMach, FakeRuntime, FakeLicense, FakeSession, FakeService]:
    engine = PolyMach.__new__(PolyMach)
    runtime = FakeRuntime()
    license_api = FakeLicense(
        [make_license_status(valid=False, message="missing"), make_license_status(valid=True)]
        if not valid
        else [make_license_status(valid=True)]
    )
    session = FakeSession()
    service = FakeService()
    engine.runtime = runtime
    engine.system = FakeSystem()
    engine.session = session
    engine.license = license_api
    engine._license_service = lambda service_url=None: service
    return engine, runtime, license_api, session, service


def test_license_service_builds_exact_payment_request(monkeypatch: pytest.MonkeyPatch) -> None:
    client = LicenseServiceClient(env={"POLYMACH_LICENSE_BASE_URL": "https://license.test"})

    def fake_request(method: str, path: str, payload=None) -> dict[str, object]:
        assert method == "GET"
        assert path == "/v1/catalog"
        return {
            "chain_id": 137,
            "recipient_address": "0x2222222222222222222222222222222222222222",
            "token_address": "0x3333333333333333333333333333333333333333",
            "token_symbol": "USDC",
            "token_decimals": 6,
            "min_confirmations": 5,
            "cycle_price_usdc": "50",
            "billing_cycle_days": 30,
            "features": ["core"],
        }

    monkeypatch.setattr(client, "_request_json", fake_request)

    catalog = client.catalog()
    payment = client.payment_request(machine_fingerprint="abc123", cycles=3)

    assert isinstance(catalog, LicenseCatalog)
    assert payment.amount_display == "150"
    assert payment.amount_raw == 150_000_000
    assert payment.cycles == 3
    assert payment.cycle_price_usdc == "50"
    assert payment.chain_id == 137
    assert payment.machine_fingerprint == "abc123"


def test_start_returns_payment_request_when_license_is_missing() -> None:
    engine, _runtime, _license_api, _session, _service = build_fake_engine(valid=False)

    result = PolyMach.start(engine, cycles=2)

    assert result.ready is False
    assert result.payment is not None
    assert result.payment.amount_raw == 100_000_000
    assert result.payment.cycles == 2
    assert "payment required" in result.message


def test_start_activates_installs_and_prewarms() -> None:
    engine, runtime, license_api, session, service = build_fake_engine(valid=False)

    result = PolyMach.start(
        engine,
        tx_hash="0x" + "1" * 64,
        prewarm_tokens=["token-1"],
        prewarm_last_trade=True,
    )

    assert result.ready is True
    assert result.activation is not None
    assert result.activation.installed_path == "/tmp/.polymach/license.json"
    assert result.activation.tx_hash == "0x" + "1" * 64
    assert result.activation.cycles == 2
    assert license_api.installed_documents[0]["claims"]["license_id"] == "lic_abc"
    assert runtime.closed == 1
    assert session.prewarm_calls == [(("token-1",), True, True, True)]
    assert result.session is not None
    assert service.activate_calls[0]["tx_hash"] == "0x" + "1" * 64


def test_ensure_ready_raises_payment_required_error() -> None:
    engine, _runtime, _license_api, _session, _service = build_fake_engine(valid=False)

    with pytest.raises(PaymentRequiredError) as exc_info:
        PolyMach.ensure_ready(engine)

    assert exc_info.value.payment is not None
    assert exc_info.value.payment.amount_display == "50"


def test_pay_returns_submitted_payment() -> None:
    engine, _runtime, _license_api, _session, _service = build_fake_engine(valid=False)
    payer = FakePayer()
    engine._payment_sender = lambda rpc_url=None: payer

    submitted = PolyMach.pay(
        engine,
        private_key="0x" + "3" * 64,
        cycles=2,
        gas_limit=66_000,
        gas_price_wei=12,
    )

    assert submitted.tx_hash == "0x" + "2" * 64
    assert submitted.cycles == 2
    assert payer.calls[0]["private_key"] == "0x" + "3" * 64
    assert payer.calls[0]["signer"] is None
    assert payer.calls[0]["gas_limit"] == 66_000
    assert payer.calls[0]["gas_price_wei"] == 12


def test_pay_passes_optional_replacement_controls() -> None:
    engine, _runtime, _license_api, _session, _service = build_fake_engine(valid=False)
    payer = FakePayer()
    engine._payment_sender = lambda rpc_url=None: payer

    PolyMach.pay(
        engine,
        signer=FakeSigner(),
        replacement_attempts=2,
        replacement_gas_bump_percent=40,
    )

    assert payer.calls[0]["replacement_attempts"] == 2
    assert payer.calls[0]["replacement_gas_bump_percent"] == 40


def test_pay_and_start_submits_payment_then_activates() -> None:
    engine, runtime, license_api, session, service = build_fake_engine(valid=False)
    payer = FakePayer()
    engine._payment_sender = lambda rpc_url=None: payer
    signer = FakeSigner()

    result = PolyMach.pay_and_start(
        engine,
        signer=signer,
        cycles=2,
        prewarm_tokens=["token-1"],
    )

    assert result.ready is True
    assert result.activation is not None
    assert result.activation.tx_hash == "0x" + "2" * 64
    assert result.activation.cycles == 2
    assert payer.calls[0]["payment"].cycles == 2
    assert payer.calls[0]["signer"] is signer
    assert payer.calls[0]["private_key"] is None
    assert service.activate_calls[0]["tx_hash"] == "0x" + "2" * 64
    assert service.activate_calls[0]["wallet_address"] == "0x1111111111111111111111111111111111111111"
    assert runtime.closed == 1
    assert license_api.installed_documents[0]["claims"]["license_id"] == "lic_abc"
    assert session.prewarm_calls == [(("token-1",), True, True, False)]


def test_pay_and_start_can_resume_from_existing_tx_hash() -> None:
    engine, runtime, license_api, session, service = build_fake_engine(valid=False)
    payer = FakePayer()
    engine._payment_sender = lambda rpc_url=None: payer
    license_api._statuses = [
        make_license_status(valid=False, message="missing"),
        make_license_status(valid=False, message="missing"),
        make_license_status(valid=True),
    ]

    result = PolyMach.pay_and_start(
        engine,
        tx_hash="0x" + "7" * 64,
        wallet_address="0x9999999999999999999999999999999999999999",
        prewarm_tokens=["token-1"],
    )

    assert result.ready is True
    assert result.activation is not None
    assert result.activation.tx_hash == "0x" + "7" * 64
    assert payer.calls == []
    assert service.activate_calls[0]["tx_hash"] == "0x" + "7" * 64
    assert service.activate_calls[0]["wallet_address"] == "0x9999999999999999999999999999999999999999"
    assert runtime.closed == 1
    assert license_api.installed_documents[0]["claims"]["license_id"] == "lic_abc"
    assert session.prewarm_calls == [(("token-1",), True, True, False)]


def test_local_account_signer_redacts_key_in_repr() -> None:
    signer = LocalAccountSigner.from_private_key("0x" + "5" * 64)

    assert "5555" not in repr(signer)
    assert signer.address.startswith("0x")
