from __future__ import annotations

from collections.abc import Mapping
from typing import Any

import pytest
from eth_utils import keccak

from polymach.errors import PaymentPendingError, PolyMachError
from polymach.models import PaymentRequest
from polymach.payments import PolygonUsdcPayer, default_polygon_rpc_url, default_polygon_rpc_urls


def make_payment_request() -> PaymentRequest:
    return PaymentRequest(
        service_url="https://license.test",
        machine_fingerprint="f" * 64,
        cycles=1,
        chain_id=137,
        recipient_address="0x2222222222222222222222222222222222222222",
        token_address="0x3333333333333333333333333333333333333333",
        token_symbol="USDC",
        token_decimals=6,
        amount_display="50",
        amount_raw=50_000_000,
        cycle_price_usdc="50",
        billing_cycle_days=30,
        features=("core",),
        min_confirmations=3,
    )


class FakeSigner:
    def __init__(self) -> None:
        self.gas_prices: list[int] = []

    @property
    def address(self) -> str:
        return "0x1111111111111111111111111111111111111111"

    def sign_transaction(self, transaction: Mapping[str, Any]) -> bytes:
        gas_price = int(transaction["gasPrice"])
        self.gas_prices.append(gas_price)
        return gas_price.to_bytes(8, "big")


class SequencedWaitPayer(PolygonUsdcPayer):
    def __init__(self, responses: Mapping[str, list[Any]]) -> None:
        super().__init__(env={"POLYMACH_POLYGON_RPC_URLS": "https://rpc-a.test"})
        self._responses = {method: list(items) for method, items in responses.items()}

    def _rpc(self, method: str, params: list[Any]) -> Any:
        del params
        items = self._responses.get(method)
        if not items:
            raise AssertionError(f"unexpected rpc call: {method}")
        item = items.pop(0)
        if isinstance(item, Exception):
            raise item
        return item


class PendingPayPayer(PolygonUsdcPayer):
    def __init__(self) -> None:
        super().__init__(env={"POLYMACH_POLYGON_RPC_URLS": "https://rpc-a.test"})

    def _broadcast_raw_transaction(
        self,
        raw_transaction: bytes,
        *,
        timeout_seconds: float,
        poll_interval_seconds: float,
    ) -> str:
        del timeout_seconds, poll_interval_seconds
        return "0x" + keccak(raw_transaction).hex()

    def _rpc(self, method: str, params: list[Any]) -> Any:
        del params
        if method == "eth_chainId":
            return hex(137)
        if method == "eth_getTransactionCount":
            return hex(7)
        if method == "eth_getTransactionReceipt":
            return None
        raise AssertionError(f"unexpected rpc call: {method}")


class BroadcastFallbackPayer(PolygonUsdcPayer):
    def __init__(self) -> None:
        super().__init__(env={"POLYMACH_POLYGON_RPC_URLS": "https://rpc-a.test,https://rpc-b.test"})
        self.calls: list[tuple[str, str]] = []

    def _rpc_via(self, rpc_url: str, method: str, params: list[Any]) -> Any:
        self.calls.append((rpc_url, method))
        if rpc_url == "https://rpc-a.test":
            raise PolyMachError(f"{method} {rpc_url} failed (429): rate limited")
        raw_transaction = bytes.fromhex(str(params[0])[2:])
        return "0x" + keccak(raw_transaction).hex()


class ReplacementPayer(PolygonUsdcPayer):
    def __init__(self, *, confirmations_on_attempt: int) -> None:
        super().__init__(env={"POLYMACH_POLYGON_RPC_URLS": "https://rpc-a.test"})
        self._confirmations_on_attempt = confirmations_on_attempt
        self.broadcast_hashes: list[str] = []
        self.wait_attempts = 0

    def _broadcast_raw_transaction(
        self,
        raw_transaction: bytes,
        *,
        timeout_seconds: float,
        poll_interval_seconds: float,
    ) -> str:
        del timeout_seconds, poll_interval_seconds
        tx_hash = "0x" + keccak(raw_transaction).hex()
        self.broadcast_hashes.append(tx_hash)
        return tx_hash

    def _wait_for_confirmations(
        self,
        tx_hash: str,
        *,
        required_confirmations: int,
        timeout_seconds: float,
        poll_interval_seconds: float,
    ) -> tuple[dict[str, Any], int]:
        del timeout_seconds, poll_interval_seconds
        self.wait_attempts += 1
        if self.wait_attempts < self._confirmations_on_attempt:
            raise PaymentPendingError(
                f"pending {tx_hash}",
                tx_hash=tx_hash,
                confirmations=1,
                required_confirmations=required_confirmations,
            )
        return {"status": "0x1", "blockNumber": "0x64"}, required_confirmations

    def _rpc(self, method: str, params: list[Any]) -> Any:
        del params
        if method == "eth_chainId":
            return hex(137)
        if method == "eth_getTransactionCount":
            return hex(7)
        raise AssertionError(f"unexpected rpc call: {method}")


def test_default_polygon_rpc_urls_use_fallback_chain() -> None:
    assert default_polygon_rpc_urls({}) == (
        "https://polygon.publicnode.com",
        "https://1rpc.io/matic",
        "https://polygon-rpc.com",
    )
    assert default_polygon_rpc_url({}) == "https://polygon.publicnode.com"
    assert default_polygon_rpc_urls(
        {"POLYMACH_POLYGON_RPC_URLS": "https://rpc-a.test, https://rpc-b.test"}
    ) == ("https://rpc-a.test", "https://rpc-b.test")


def test_wait_for_confirmations_retries_transient_rpc_errors() -> None:
    payer = SequencedWaitPayer(
        {
            "eth_getTransactionReceipt": [
                PolyMachError("eth_getTransactionReceipt https://rpc-a.test failed (429): rate limited"),
                None,
                {"status": "0x1", "blockNumber": "0x64"},
            ],
            "eth_blockNumber": [
                PolyMachError("eth_blockNumber https://rpc-a.test failed (503): service unavailable"),
                "0x66",
            ],
        }
    )

    receipt, confirmations = payer._wait_for_confirmations(
        "0x" + "a" * 64,
        required_confirmations=3,
        timeout_seconds=0.1,
        poll_interval_seconds=0,
    )

    assert receipt["status"] == "0x1"
    assert confirmations == 3


def test_pay_timeout_raises_pending_error_with_recoverable_tx_hash() -> None:
    payer = PendingPayPayer()
    payment = make_payment_request()
    expected_tx_hash = "0x" + keccak((1).to_bytes(8, "big")).hex()

    with pytest.raises(PaymentPendingError) as exc_info:
        payer.pay(
            payment,
            signer=FakeSigner(),
            gas_limit=65_000,
            gas_price_wei=1,
            timeout_seconds=0.01,
            poll_interval_seconds=0.005,
        )

    assert exc_info.value.tx_hash == expected_tx_hash
    assert exc_info.value.required_confirmations == payment.min_confirmations
    assert "retry start(tx_hash=" in str(exc_info.value)


def test_broadcast_tries_secondary_rpc_after_transient_error() -> None:
    payer = BroadcastFallbackPayer()

    tx_hash = payer._broadcast_raw_transaction(
        b"\x05\x06\x07",
        timeout_seconds=0.1,
        poll_interval_seconds=0,
    )

    assert tx_hash == "0x" + keccak(b"\x05\x06\x07").hex()
    assert payer.calls == [
        ("https://rpc-a.test", "eth_sendRawTransaction"),
        ("https://rpc-b.test", "eth_sendRawTransaction"),
    ]


def test_pay_replaces_pending_transaction_with_bumped_gas_price() -> None:
    payer = ReplacementPayer(confirmations_on_attempt=2)
    signer = FakeSigner()

    submitted = payer.pay(
        make_payment_request(),
        signer=signer,
        gas_limit=65_000,
        gas_price_wei=100,
        replacement_attempts=1,
        replacement_gas_bump_percent=25,
        timeout_seconds=0.01,
        poll_interval_seconds=0.005,
    )

    assert signer.gas_prices == [100, 125]
    assert len(payer.broadcast_hashes) == 2
    assert submitted.tx_hash == payer.broadcast_hashes[-1]
    assert submitted.gas_price_wei == 125
    assert submitted.confirmations == 3


def test_pay_reports_all_attempted_tx_hashes_after_replacement_exhaustion() -> None:
    payer = ReplacementPayer(confirmations_on_attempt=99)
    signer = FakeSigner()

    with pytest.raises(PaymentPendingError) as exc_info:
        payer.pay(
            make_payment_request(),
            signer=signer,
            gas_limit=65_000,
            gas_price_wei=100,
            replacement_attempts=1,
            replacement_gas_bump_percent=25,
            timeout_seconds=0.01,
            poll_interval_seconds=0.005,
        )

    assert signer.gas_prices == [100, 125]
    assert exc_info.value.tx_hash == payer.broadcast_hashes[-1]
    assert exc_info.value.attempted_tx_hashes == tuple(payer.broadcast_hashes)
