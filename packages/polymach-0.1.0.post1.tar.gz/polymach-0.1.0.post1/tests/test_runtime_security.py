from __future__ import annotations

import io
import json
import subprocess

import pytest

from polymach import PolyMach
from polymach.runtime import PolyMachRuntime


def test_runtime_strips_wallet_private_key_from_subprocess_env() -> None:
    runtime = PolyMachRuntime(
        binary="/bin/echo",
        env={
            "POLYMACH_WALLET_PRIVATE_KEY": "0x" + "1" * 64,
            "POLYMACH_LICENSE_BASE_URL": "https://license.test",
        },
        persistent=False,
    )

    assert runtime.env["POLYMACH_WALLET_PRIVATE_KEY"].startswith("0x")
    assert "POLYMACH_WALLET_PRIVATE_KEY" not in runtime.subprocess_env
    assert runtime.subprocess_env["POLYMACH_LICENSE_BASE_URL"] == "https://license.test"


class _FakeSessionProcess:
    def __init__(self, payload: dict[str, object]) -> None:
        self.stdin = None
        self.stdout = io.StringIO(json.dumps(payload) + "\n")
        self.stderr = io.StringIO("")
        self._returncode: int | None = None
        self.terminated = False
        self.killed = False

    def poll(self) -> int | None:
        return self._returncode

    def terminate(self) -> None:
        self.terminated = True
        self._returncode = 0

    def kill(self) -> None:
        self.killed = True
        self._returncode = -9

    def wait(self, timeout: float | None = None) -> int:
        del timeout
        if self._returncode is None:
            self._returncode = 0
        return self._returncode


def test_non_persistent_session_status_uses_one_shot_session_handshake(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    payload = {
        "pid": 4242,
        "host": "https://clob.polymarket.com",
        "chain_id": 137,
        "ws_enabled": True,
        "warmed_tokens": 0,
    }
    captured: dict[str, object] = {}

    def fail_cli_fallback(self: PolyMachRuntime, method: str, params: dict[str, object]) -> list[str]:
        del self, method, params
        raise AssertionError("session.status should not use the CLI RPC fallback")

    def fake_popen(command: list[str], **kwargs: object) -> _FakeSessionProcess:
        captured["command"] = command
        captured["kwargs"] = kwargs
        process = _FakeSessionProcess(payload)
        captured["process"] = process
        return process

    monkeypatch.setattr(PolyMachRuntime, "_cli_args_for_rpc", fail_cli_fallback)
    monkeypatch.setattr("polymach.runtime.subprocess.Popen", fake_popen)

    client = PolyMach(
        binary="/bin/echo",
        env={"POLYMACH_LICENSE_BASE_URL": "https://license.test"},
        persistent=False,
    )

    status = client.session_status()

    assert status.pid == 4242
    assert status.host == "https://clob.polymarket.com"
    assert status.chain_id == 137
    assert status.ws_enabled is True
    assert status.warmed_tokens == 0
    assert captured["command"] == ["/bin/echo", "session", "serve"]
    assert captured["kwargs"]["stdin"] is subprocess.DEVNULL
    assert captured["kwargs"]["env"] == client.runtime.subprocess_env
    process = captured["process"]
    assert isinstance(process, _FakeSessionProcess)
    assert process.terminated is True
    assert process.killed is False
