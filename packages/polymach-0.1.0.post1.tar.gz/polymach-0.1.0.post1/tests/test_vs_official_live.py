from __future__ import annotations

from decimal import Decimal

import pytest

from polymach import PolyMach
from polymach.models import DiscoveryMarket, TimedLimitResponse

from .live_support import (
    OfficialCli,
    fetch_current_btc5m_market,
    max_allowance_value,
    normalize_official_market,
    parse_optional_float,
    timed_call,
    top_of_book,
    value_within_band,
    measure_stream,
    summarize,
)


def _gamma_api_url(test_env: dict[str, str]) -> str:
    return test_env.get("POLYMACH_POLYMARKET_GAMMA_API_URL", "https://gamma-api.polymarket.com")


def _outcome_by_name(market: DiscoveryMarket, outcome: str):
    for item in market.outcomes:
        if item.outcome.lower() == outcome.lower():
            return item
    raise AssertionError(f"missing outcome {outcome!r} in discovery payload")


@pytest.mark.live
def test_market_metadata_accuracy_vs_official_cli(
    engine: PolyMach,
    official_cli: OfficialCli,
    test_env: dict[str, str],
    record_case,
) -> None:
    market = fetch_current_btc5m_market(_gamma_api_url(test_env), min_secs_remaining=45.0)
    engine.prewarm([market.yes_token, market.no_token], last_trade=True)

    sdk_market, sdk_ms = timed_call(engine.discover.market, slug=market.slug, with_live=True)
    official_payload, official_result = official_cli.markets_get(market.slug)
    official_market = normalize_official_market(official_payload)

    sdk_yes = _outcome_by_name(sdk_market, market.yes_outcome)
    sdk_no = _outcome_by_name(sdk_market, market.no_outcome)

    assert sdk_market.slug == official_market["slug"] == market.slug
    assert sdk_market.question == official_market["question"] == market.question
    assert (sdk_market.condition_id or "").lower() == market.condition_id.lower()
    assert (sdk_market.condition_id or "").lower() == str(official_market["conditionId"]).lower()
    assert [sdk_yes.outcome, sdk_no.outcome] == official_market["outcomes"][:2]
    assert [sdk_yes.token_id, sdk_no.token_id] == official_market["clobTokenIds"][:2]
    assert sdk_market.accepting_orders is True
    assert bool(official_market["acceptingOrders"]) is True

    record_case(
        {
            "market": {
                "slug": market.slug,
                "question": market.question,
                "condition_id": market.condition_id,
                "yes_token": market.yes_token,
                "no_token": market.no_token,
                "secs_to_end": market.secs_to_end,
            },
            "sdk_latency_ms": sdk_ms,
            "official_latency_ms": official_result.wall_ms,
        }
    )


@pytest.mark.live
def test_balance_accuracy_vs_official_cli(
    engine: PolyMach,
    official_cli: OfficialCli,
    test_env: dict[str, str],
    record_case,
) -> None:
    market = fetch_current_btc5m_market(_gamma_api_url(test_env), min_secs_remaining=45.0)
    engine.prewarm([market.yes_token], quotes=True, order_metadata=True, last_trade=False)

    health, sdk_ms = timed_call(engine.account.health, token_id=market.yes_token)
    collateral_payload, collateral_result = official_cli.balance_collateral()
    token_payload, token_result = official_cli.balance_conditional(market.yes_token)

    official_collateral_balance = float(Decimal(str(collateral_payload["balance"])))
    official_token_balance = float(Decimal(str(token_payload["balance"])))

    assert abs(health.collateral_balance_usdc - official_collateral_balance) <= 0.01
    assert abs((health.token_balance or 0.0) - official_token_balance) <= 0.01

    record_case(
        {
            "market": {"slug": market.slug, "yes_token": market.yes_token},
            "sdk_latency_ms": sdk_ms,
            "official_collateral_latency_ms": collateral_result.wall_ms,
            "official_token_latency_ms": token_result.wall_ms,
            "sdk_balances": {
                "collateral_balance_usdc": health.collateral_balance_usdc,
                "collateral_allowance_usdc": health.collateral_allowance_usdc,
                "token_balance": health.token_balance,
                "token_allowance": health.token_allowance,
            },
            "official_balances": {
                "collateral_balance_usdc": official_collateral_balance,
                "collateral_allowance_max": max_allowance_value(collateral_payload),
                "token_balance": official_token_balance,
                "token_allowance_max": max_allowance_value(token_payload),
            },
        }
    )


@pytest.mark.live
def test_quote_accuracy_vs_official_cli(
    engine: PolyMach,
    official_cli: OfficialCli,
    test_env: dict[str, str],
    record_case,
) -> None:
    market = fetch_current_btc5m_market(_gamma_api_url(test_env), min_secs_remaining=45.0)
    engine.prewarm([market.yes_token], quotes=True, order_metadata=True, last_trade=True)

    before_midpoint_payload, before_midpoint_result = official_cli.midpoint(market.yes_token)
    before_book_payload, before_book_result = official_cli.book(market.yes_token)
    sdk_quote, sdk_quote_ms = timed_call(engine.market.quote, market.yes_token)
    sdk_midpoint, sdk_midpoint_ms = timed_call(engine.market.midpoint, market.yes_token)
    sdk_discovery, sdk_discovery_ms = timed_call(
        engine.discover.market,
        token_id=market.yes_token,
        with_live=True,
    )
    after_midpoint_payload, after_midpoint_result = official_cli.midpoint(market.yes_token)
    after_book_payload, after_book_result = official_cli.book(market.yes_token)
    official_last_trade_payload, official_last_trade_result = official_cli.last_trade(market.yes_token)

    sdk_yes = _outcome_by_name(sdk_discovery, market.yes_outcome)
    live_quote = sdk_yes.live_quote
    assert live_quote is not None

    before_midpoint = float(before_midpoint_payload["midpoint"])
    after_midpoint = float(after_midpoint_payload["midpoint"])
    before_bid, before_ask = top_of_book(before_book_payload)
    after_bid, after_ask = top_of_book(after_book_payload)
    official_last_trade = parse_optional_float(official_last_trade_payload.get("price"))

    assert value_within_band(
        sdk_quote.midpoint,
        before_midpoint,
        after_midpoint,
        tolerance=0.05,
    )
    assert value_within_band(sdk_quote.bid, before_bid, after_bid, tolerance=0.05)
    assert value_within_band(sdk_quote.ask, before_ask, after_ask, tolerance=0.05)
    assert abs(sdk_midpoint.midpoint - sdk_quote.midpoint) <= 0.05
    assert live_quote.midpoint is not None
    assert abs(live_quote.midpoint - sdk_quote.midpoint) <= 0.02
    if live_quote.last_trade is not None and official_last_trade is not None:
        assert abs(live_quote.last_trade - official_last_trade) <= 0.05

    record_case(
        {
            "market": {"slug": market.slug, "yes_token": market.yes_token},
            "sdk_latency_ms": {
                "quote": sdk_quote_ms,
                "midpoint": sdk_midpoint_ms,
                "discover_with_live": sdk_discovery_ms,
            },
            "official_latency_ms": {
                "midpoint_before": before_midpoint_result.wall_ms,
                "book_before": before_book_result.wall_ms,
                "midpoint_after": after_midpoint_result.wall_ms,
                "book_after": after_book_result.wall_ms,
                "last_trade": official_last_trade_result.wall_ms,
            },
            "sdk_quote": {
                "midpoint": sdk_quote.midpoint,
                "bid": sdk_quote.bid,
                "ask": sdk_quote.ask,
                "discover_live_midpoint": live_quote.midpoint,
                "discover_live_last_trade": live_quote.last_trade,
            },
            "official_quote_band": {
                "midpoint_before": before_midpoint,
                "midpoint_after": after_midpoint,
                "bid_before": before_bid,
                "bid_after": after_bid,
                "ask_before": before_ask,
                "ask_after": after_ask,
                "last_trade": official_last_trade,
            },
        }
    )


@pytest.mark.live
def test_stream_latency_vs_official_cli_polling(
    engine: PolyMach,
    official_cli: OfficialCli,
    test_env: dict[str, str],
    record_case,
) -> None:
    market = fetch_current_btc5m_market(_gamma_api_url(test_env), min_secs_remaining=45.0)
    engine.prewarm([market.yes_token], quotes=True, order_metadata=True, last_trade=True)

    stream_report = measure_stream(engine, market.yes_token, count=8, interval_ms=45)
    polling_samples: list[float] = []
    polling_payloads: list[float] = []
    for _ in range(6):
        payload, result = official_cli.midpoint(market.yes_token)
        polling_samples.append(result.wall_ms)
        polling_payloads.append(float(payload["midpoint"]))
    polling_summary = summarize(polling_samples)

    assert stream_report["snapshot_count"] == 8
    assert "interval_summary" in stream_report
    assert stream_report["interval_summary"]["p50_ms"] <= 125.0
    assert stream_report["interval_summary"]["p50_ms"] * 1.4 <= polling_summary["p50_ms"] + 1.0

    record_case(
        {
            "market": {"slug": market.slug, "yes_token": market.yes_token},
            "polymach_stream": stream_report,
            "official_polling": {
                "summary": polling_summary,
                "midpoints": polling_payloads,
            },
        }
    )


@pytest.mark.live
@pytest.mark.mutating
def test_limit_order_post_and_cancel_latency_vs_official_cli(
    engine: PolyMach,
    official_cli: OfficialCli,
    test_env: dict[str, str],
    record_case,
) -> None:
    market = fetch_current_btc5m_market(_gamma_api_url(test_env), min_secs_remaining=120.0)
    engine.prewarm([market.yes_token], quotes=True, order_metadata=True, last_trade=False)

    polymach_order_id: str | None = None
    official_order_id: str | None = None
    polymach_cancel_ms: float | None = None
    official_cancel_result = None
    official_cancel_wall_ms: float | None = None
    polymach_timed: TimedLimitResponse | None = None
    polymach_wall_ms: float | None = None
    official_create_wall_ms: float | None = None
    official_create_payload: dict[str, object] | None = None

    try:
        polymach_timed, polymach_wall_ms = timed_call(
            engine.orders.limit,
            "buy",
            market.yes_token,
            5.0,
            0.01,
            order_type="GTC",
            timed=True,
        )
        polymach_order_id = polymach_timed.receipt.order_id

        official_create_payload, official_create_result = official_cli.create_limit_buy(
            market.yes_token,
            qty=5.0,
            price=0.01,
        )
        official_create_wall_ms = official_create_result.wall_ms
        official_order_id = str(official_create_payload["order_id"])
        assert bool(official_create_payload["success"]) is True

    finally:
        if official_order_id is not None:
            official_cancel_payload, official_cancel_cmd = official_cli.cancel(official_order_id)
            official_cancel_result = official_cancel_payload
            official_cancel_wall_ms = official_cancel_cmd.wall_ms
        if polymach_order_id is not None:
            polymach_cancel_result, polymach_cancel_ms = timed_call(
                engine.orders.cancel,
                polymach_order_id,
            )
            assert polymach_cancel_result.canceled is True

    assert polymach_timed is not None
    assert polymach_wall_ms is not None
    assert official_create_wall_ms is not None
    assert polymach_cancel_ms is not None
    assert official_cancel_result is not None
    assert official_cancel_wall_ms is not None

    assert polymach_timed.receipt.qty == pytest.approx(5.0)
    assert polymach_timed.receipt.limit_price == pytest.approx(0.01)
    assert polymach_timed.timing.total_seconds * 1000.0 <= 350.0
    assert polymach_wall_ms < official_create_wall_ms
    assert polymach_cancel_ms <= 400.0
    assert polymach_cancel_ms < official_cancel_wall_ms * 1.25
    assert official_order_id in set(official_cancel_result.get("canceled") or [])

    record_case(
        {
            "market": {
                "slug": market.slug,
                "question": market.question,
                "yes_token": market.yes_token,
                "secs_to_end": market.secs_to_end,
            },
            "polymach_order": {
                "order_id": polymach_order_id,
                "wall_ms": polymach_wall_ms,
                "submit_ms": polymach_timed.timing.total_seconds * 1000.0,
                "http_ms": polymach_timed.timing.http_seconds * 1000.0,
                "build_sign_ms": polymach_timed.timing.build_sign_seconds * 1000.0,
                "cancel_ms": polymach_cancel_ms,
            },
            "official_order": {
                "order_id": official_order_id,
                "wall_ms": official_create_wall_ms,
                "cancel_ms": official_cancel_wall_ms,
                "payload": official_create_payload,
                "cancel_result": official_cancel_result,
            },
        }
    )
