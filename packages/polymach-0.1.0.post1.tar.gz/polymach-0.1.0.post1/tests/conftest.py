from __future__ import annotations

import os
from pathlib import Path

import pytest

from polymach import PolyMach

from .live_support import (
    OfficialCli,
    ReportRecorder,
    build_official_env,
    build_test_env,
    resolve_official_binary,
)


def pytest_configure(config: pytest.Config) -> None:
    config.addinivalue_line("markers", "live: requires live Polymarket and Gamma connectivity")
    config.addinivalue_line("markers", "mutating: places and cancels live orders")


def pytest_runtest_setup(item: pytest.Item) -> None:
    if "live" in item.keywords and os.environ.get("POLYMACH_RUN_LIVE_TESTS") != "1":
        pytest.skip("set POLYMACH_RUN_LIVE_TESTS=1 to run live comparison tests")
    if "mutating" in item.keywords and os.environ.get("POLYMACH_RUN_MUTATING_TESTS") != "1":
        pytest.skip("set POLYMACH_RUN_MUTATING_TESTS=1 to run live mutating tests")


@pytest.fixture(scope="session")
def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


@pytest.fixture(scope="session")
def test_env(repo_root: Path) -> dict[str, str]:
    return build_test_env(repo_root)


@pytest.fixture(scope="session")
def official_cli(test_env: dict[str, str]) -> OfficialCli:
    return OfficialCli(resolve_official_binary(), build_official_env(test_env))


@pytest.fixture(scope="session")
def engine(test_env: dict[str, str]) -> PolyMach:
    engine = PolyMach(
        binary=test_env.get("POLYMACH_BIN"),
        license_path=test_env.get("POLYMACH_LICENSE_PATH"),
        env=test_env,
        persistent=True,
    )
    status = engine.license_status()
    if not status.valid:
        pytest.skip(f"polymach license is not valid: {status.message}")
    yield engine
    engine.runtime.close()


@pytest.fixture(scope="session")
def report_recorder(repo_root: Path) -> ReportRecorder:
    recorder = ReportRecorder(repo_root)
    yield recorder
    path = recorder.write()
    print(f"\nlive comparison report: {path}")


@pytest.fixture
def record_case(report_recorder: ReportRecorder, request: pytest.FixtureRequest):
    def record(payload: dict[str, object]) -> None:
        report_recorder.record(request.node.nodeid, payload)

    return record
