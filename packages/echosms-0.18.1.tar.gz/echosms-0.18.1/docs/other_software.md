# Other software

Software that provides source code for acoustic scattering models of relevance to fisheries and plankton acoustics are listed below. A more general list of underwater acoustic modelling software is available
at the [Ocean Acoustics Library](https://oalib-acoustics.org/models-and-software/).

- [acousticTS](https://github.com/brandynlucca/acousticTS): R code for calculating scattering using the DCM, DWBA, SDWBA, SDWBA_curved, KRM, MSS model, as well as that of calibration spheres.
- [Coupled BEM acoustic](https://github.com/elavia/coupled_bem_acoustic): Julia code that calculates the TS of three-dimensional shapes with an included object (e.g., a swimbladder).
- [FishAcoustics](https://github.com/gavinmacaulay/FishAcoustics): Contains a Python module that implements the phase-tracking DWBA model.
- [gasbubbles](https://github.com/peter-urban/gasbubbles/tree/main): Contains Python code for scattering models relevant to gas bubbles. Uses echoSMs for some of its' models.
- [Hydrac](https://hydrac.readthedocs.io/overview.html): Contains Python code that implements several exact and approximate scattering models, including the DWBA and high-pass models. Hydrac is a package for computing suspended matter concentrations from backscatter.
- [KRM Model](https://www.fisheries.noaa.gov/data-tools/krm-model): A web page that uses the KRM model to estimate the TS of predefined or user-supplied shapes over a range of input parameters.
- [KRMr](https://github.com/SvenGastauer/KRMr): KRM model for fish in R.
- [Liquid spheroid](https://github.com/elavia/liquid_spheroid): Julia and C++ code to calculate the scattering by fluid prolate and oblate spheroids.
- [MM-BEM](https://marmoszy.github.io/mm-bem/mm-bem2.html), [github](https://github.com/marmoszy/mm-bem): Code in various languages/systems (e.g., C, Python, Matlab, Julia, BEMpp, gypsilab, and FreeFem) that implement the boundary element method for scattering and the method of fundamental solutions (MFS).
- [Prol_Spheroid](https://github.com/CRIMAC-WP4-Machine-learning/Prol_Spheroid): Python and Fortran code to calculate the scattering from liquid and gas-filled prolate spheroids.
- [scatmod](https://github.com/SvenGastauer/scatmod): Open source acoustic scattering models for fisheries acoustics. Python and R code for fluid spheres.
- [SDWBA Model](https://www.fisheries.noaa.gov/data-tools/sdwba-model): A web page that uses the SDWBA model to estimate the TS of predefined shapes over a range of input parameters.
- [SDWBA packages](https://github.com/ElOceanografo/SDWBA): Provides krill model data
- [SDWBA.jl](https://github.com/ElOceanografo/SDWBA.jl): Julia code that implements the SDWBA model
- [SDWBA.py](https://github.com/ElOceanografo/SDWBA.py): Unfinished Python code to implement the SDWBA model.
- [SDWBA.R](https://github.com/ElOceanografo/SDWBA.R): Untested R code that implements the SDWBA model.
- [SDWBA_TS](https://github.com/ccamlr/SDWBA_TS): Matlab code that implements the SDWBA model for Antarctic krill.
- [sphereTS](https://github.com/gavinmacaulay/SphereTS): Python code to calculate the TS of calibration spheres.
- [Standard sphere target strength calculator](https://www.fisheries.noaa.gov/data-tools/standard-sphere-target-strength-calculator): A web page that calculates the TS of calibration spheres.
- [tetrascatt](https://github.com/cran/tetrascatt/tree/master): R and C++ code that implements the DWBA model on arbitrary geometries.
- [ZooScatR](https://github.com/AustralianAntarcticDivision/ZooScatR): R code that implements the DWBA model.
