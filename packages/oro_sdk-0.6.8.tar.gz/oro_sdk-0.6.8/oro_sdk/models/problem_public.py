from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.problem_public_metadata import ProblemPublicMetadata


T = TypeVar("T", bound="ProblemPublic")


@_attrs_define
class ProblemPublic:
    """Public representation of a problem.

    Attributes:
        problem_id (UUID): Unique identifier for the problem
        suite_id (int): Parent suite ID
        metadata (ProblemPublicMetadata | Unset): Full problem metadata
    """

    problem_id: UUID
    suite_id: int
    metadata: ProblemPublicMetadata | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        problem_id = str(self.problem_id)

        suite_id = self.suite_id

        metadata: dict[str, Any] | Unset = UNSET
        if not isinstance(self.metadata, Unset):
            metadata = self.metadata.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "problem_id": problem_id,
                "suite_id": suite_id,
            }
        )
        if metadata is not UNSET:
            field_dict["metadata"] = metadata

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.problem_public_metadata import ProblemPublicMetadata

        d = dict(src_dict)
        problem_id = UUID(d.pop("problem_id"))

        suite_id = d.pop("suite_id")

        _metadata = d.pop("metadata", UNSET)
        metadata: ProblemPublicMetadata | Unset
        if isinstance(_metadata, Unset):
            metadata = UNSET
        else:
            metadata = ProblemPublicMetadata.from_dict(_metadata)

        problem_public = cls(
            problem_id=problem_id,
            suite_id=suite_id,
            metadata=metadata,
        )

        problem_public.additional_properties = d
        return problem_public

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
