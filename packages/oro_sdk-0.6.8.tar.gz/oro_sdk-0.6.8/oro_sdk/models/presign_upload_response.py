from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="PresignUploadResponse")


@_attrs_define
class PresignUploadResponse:
    """Response with presigned upload URL.

    Attributes:
        upload_url (str): Presigned S3 PUT URL
        results_s3_key (str): S3 key where the file will be stored
        expires_at (datetime.datetime): When the presigned URL expires
        method (str | Unset): HTTP method to use Default: 'PUT'.
    """

    upload_url: str
    results_s3_key: str
    expires_at: datetime.datetime
    method: str | Unset = "PUT"
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        upload_url = self.upload_url

        results_s3_key = self.results_s3_key

        expires_at = self.expires_at.isoformat()

        method = self.method

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "upload_url": upload_url,
                "results_s3_key": results_s3_key,
                "expires_at": expires_at,
            }
        )
        if method is not UNSET:
            field_dict["method"] = method

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        upload_url = d.pop("upload_url")

        results_s3_key = d.pop("results_s3_key")

        expires_at = isoparse(d.pop("expires_at"))

        method = d.pop("method", UNSET)

        presign_upload_response = cls(
            upload_url=upload_url,
            results_s3_key=results_s3_key,
            expires_at=expires_at,
            method=method,
        )

        presign_upload_response.additional_properties = d
        return presign_upload_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
