from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.validator_status import ValidatorStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.validator_current_agent import ValidatorCurrentAgent
    from ..models.validator_public_service_versions_type_0 import ValidatorPublicServiceVersionsType0


T = TypeVar("T", bound="ValidatorPublic")


@_attrs_define
class ValidatorPublic:
    """Public representation of a validator.

    Attributes:
        hotkey (str): Validator's SS58 address
        status (ValidatorStatus): Status of a validator.
        registered_at (datetime.datetime): When validator was registered
        last_claim_at (datetime.datetime | None | Unset): Last work claim time
        current_agent (None | Unset | ValidatorCurrentAgent): Agent currently being evaluated, if any
        service_versions (None | Unset | ValidatorPublicServiceVersionsType0): Docker image digests for validator stack
            services
    """

    hotkey: str
    status: ValidatorStatus
    registered_at: datetime.datetime
    last_claim_at: datetime.datetime | None | Unset = UNSET
    current_agent: None | Unset | ValidatorCurrentAgent = UNSET
    service_versions: None | Unset | ValidatorPublicServiceVersionsType0 = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.validator_current_agent import ValidatorCurrentAgent
        from ..models.validator_public_service_versions_type_0 import ValidatorPublicServiceVersionsType0

        hotkey = self.hotkey

        status = self.status.value

        registered_at = self.registered_at.isoformat()

        last_claim_at: None | str | Unset
        if isinstance(self.last_claim_at, Unset):
            last_claim_at = UNSET
        elif isinstance(self.last_claim_at, datetime.datetime):
            last_claim_at = self.last_claim_at.isoformat()
        else:
            last_claim_at = self.last_claim_at

        current_agent: dict[str, Any] | None | Unset
        if isinstance(self.current_agent, Unset):
            current_agent = UNSET
        elif isinstance(self.current_agent, ValidatorCurrentAgent):
            current_agent = self.current_agent.to_dict()
        else:
            current_agent = self.current_agent

        service_versions: dict[str, Any] | None | Unset
        if isinstance(self.service_versions, Unset):
            service_versions = UNSET
        elif isinstance(self.service_versions, ValidatorPublicServiceVersionsType0):
            service_versions = self.service_versions.to_dict()
        else:
            service_versions = self.service_versions

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "hotkey": hotkey,
                "status": status,
                "registered_at": registered_at,
            }
        )
        if last_claim_at is not UNSET:
            field_dict["last_claim_at"] = last_claim_at
        if current_agent is not UNSET:
            field_dict["current_agent"] = current_agent
        if service_versions is not UNSET:
            field_dict["service_versions"] = service_versions

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.validator_current_agent import ValidatorCurrentAgent
        from ..models.validator_public_service_versions_type_0 import ValidatorPublicServiceVersionsType0

        d = dict(src_dict)
        hotkey = d.pop("hotkey")

        status = ValidatorStatus(d.pop("status"))

        registered_at = isoparse(d.pop("registered_at"))

        def _parse_last_claim_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_claim_at_type_0 = isoparse(data)

                return last_claim_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        last_claim_at = _parse_last_claim_at(d.pop("last_claim_at", UNSET))

        def _parse_current_agent(data: object) -> None | Unset | ValidatorCurrentAgent:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                current_agent_type_0 = ValidatorCurrentAgent.from_dict(data)

                return current_agent_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | ValidatorCurrentAgent, data)

        current_agent = _parse_current_agent(d.pop("current_agent", UNSET))

        def _parse_service_versions(data: object) -> None | Unset | ValidatorPublicServiceVersionsType0:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                service_versions_type_0 = ValidatorPublicServiceVersionsType0.from_dict(data)

                return service_versions_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | ValidatorPublicServiceVersionsType0, data)

        service_versions = _parse_service_versions(d.pop("service_versions", UNSET))

        validator_public = cls(
            hotkey=hotkey,
            status=status,
            registered_at=registered_at,
            last_claim_at=last_claim_at,
            current_agent=current_agent,
            service_versions=service_versions,
        )

        validator_public.additional_properties = d
        return validator_public

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
