from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.pending_evaluation import PendingEvaluation
    from ..models.pending_evaluation_summary import PendingEvaluationSummary


T = TypeVar("T", bound="PendingEvaluationsResponse")


@_attrs_define
class PendingEvaluationsResponse:
    """Response for pending evaluations endpoint.

    Attributes:
        summary (PendingEvaluationSummary): Aggregate statistics for pending evaluations.
        items (list[PendingEvaluation]): Individual pending work items
    """

    summary: PendingEvaluationSummary
    items: list[PendingEvaluation]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        summary = self.summary.to_dict()

        items = []
        for items_item_data in self.items:
            items_item = items_item_data.to_dict()
            items.append(items_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "summary": summary,
                "items": items,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.pending_evaluation import PendingEvaluation
        from ..models.pending_evaluation_summary import PendingEvaluationSummary

        d = dict(src_dict)
        summary = PendingEvaluationSummary.from_dict(d.pop("summary"))

        items = []
        _items = d.pop("items")
        for items_item_data in _items:
            items_item = PendingEvaluation.from_dict(items_item_data)

            items.append(items_item)

        pending_evaluations_response = cls(
            summary=summary,
            items=items,
        )

        pending_evaluations_response.additional_properties = d
        return pending_evaluations_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
