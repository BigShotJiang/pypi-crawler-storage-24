from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

T = TypeVar("T", bound="AgentPublic")


@_attrs_define
class AgentPublic:
    """Public representation of an agent.

    Attributes:
        agent_id (UUID): Unique identifier for the agent
        miner_hotkey (str): Owner's hotkey
        agent_name (str): Human-readable name for the agent
        created_at (datetime.datetime): When the agent was created
    """

    agent_id: UUID
    miner_hotkey: str
    agent_name: str
    created_at: datetime.datetime
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        agent_id = str(self.agent_id)

        miner_hotkey = self.miner_hotkey

        agent_name = self.agent_name

        created_at = self.created_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agent_id": agent_id,
                "miner_hotkey": miner_hotkey,
                "agent_name": agent_name,
                "created_at": created_at,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        agent_id = UUID(d.pop("agent_id"))

        miner_hotkey = d.pop("miner_hotkey")

        agent_name = d.pop("agent_name")

        created_at = isoparse(d.pop("created_at"))

        agent_public = cls(
            agent_id=agent_id,
            miner_hotkey=miner_hotkey,
            agent_name=agent_name,
            created_at=created_at,
        )

        agent_public.additional_properties = d
        return agent_public

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
