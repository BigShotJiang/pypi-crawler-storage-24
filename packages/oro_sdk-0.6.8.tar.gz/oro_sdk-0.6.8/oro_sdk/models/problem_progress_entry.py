from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.validator_problem_result import ValidatorProblemResult


T = TypeVar("T", bound="ProblemProgressEntry")


@_attrs_define
class ProblemProgressEntry:
    """Progress entry for a single problem showing results from all validators.

    Attributes:
        problem_id (UUID): Problem ID
        category (None | str | Unset): Problem category
        validator_results (list[ValidatorProblemResult] | Unset): Results from each validator that evaluated this
            problem
    """

    problem_id: UUID
    category: None | str | Unset = UNSET
    validator_results: list[ValidatorProblemResult] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        problem_id = str(self.problem_id)

        category: None | str | Unset
        if isinstance(self.category, Unset):
            category = UNSET
        else:
            category = self.category

        validator_results: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.validator_results, Unset):
            validator_results = []
            for validator_results_item_data in self.validator_results:
                validator_results_item = validator_results_item_data.to_dict()
                validator_results.append(validator_results_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "problem_id": problem_id,
            }
        )
        if category is not UNSET:
            field_dict["category"] = category
        if validator_results is not UNSET:
            field_dict["validator_results"] = validator_results

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.validator_problem_result import ValidatorProblemResult

        d = dict(src_dict)
        problem_id = UUID(d.pop("problem_id"))

        def _parse_category(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        category = _parse_category(d.pop("category", UNSET))

        _validator_results = d.pop("validator_results", UNSET)
        validator_results: list[ValidatorProblemResult] | Unset = UNSET
        if _validator_results is not UNSET:
            validator_results = []
            for validator_results_item_data in _validator_results:
                validator_results_item = ValidatorProblemResult.from_dict(validator_results_item_data)

                validator_results.append(validator_results_item)

        problem_progress_entry = cls(
            problem_id=problem_id,
            category=category,
            validator_results=validator_results,
        )

        problem_progress_entry.additional_properties = d
        return problem_progress_entry

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
