from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="InvalidProblemIdError")


@_attrs_define
class InvalidProblemIdError:
    """400 - Problem ID is not valid for this suite.

    Attributes:
        detail (str): Error message describing what went wrong
        error_code (Literal['INVALID_PROBLEM_ID'] | Unset): Error code for programmatic handling Default:
            'INVALID_PROBLEM_ID'.
    """

    detail: str
    error_code: Literal["INVALID_PROBLEM_ID"] | Unset = "INVALID_PROBLEM_ID"
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        detail = self.detail

        error_code = self.error_code

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "detail": detail,
            }
        )
        if error_code is not UNSET:
            field_dict["error_code"] = error_code

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        detail = d.pop("detail")

        error_code = cast(Literal["INVALID_PROBLEM_ID"] | Unset, d.pop("error_code", UNSET))
        if error_code != "INVALID_PROBLEM_ID" and not isinstance(error_code, Unset):
            raise ValueError(f"error_code must match const 'INVALID_PROBLEM_ID', got '{error_code}'")

        invalid_problem_id_error = cls(
            detail=detail,
            error_code=error_code,
        )

        invalid_problem_id_error.additional_properties = d
        return invalid_problem_id_error

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
