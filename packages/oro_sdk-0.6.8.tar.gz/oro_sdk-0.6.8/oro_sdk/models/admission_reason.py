from enum import Enum


class AdmissionReason(str, Enum):
    BANNED = "BANNED"
    COOLDOWN = "COOLDOWN"
    INVALID_FILE = "INVALID_FILE"
    NOT_REGISTERED_ONCHAIN = "NOT_REGISTERED_ONCHAIN"
    NO_ACTIVE_SUITE = "NO_ACTIVE_SUITE"

    def __str__(self) -> str:
        return str(self.value)
