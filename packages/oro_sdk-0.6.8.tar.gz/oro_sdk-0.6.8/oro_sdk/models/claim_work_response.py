from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="ClaimWorkResponse")


@_attrs_define
class ClaimWorkResponse:
    """Response for successful work claim.

    Attributes:
        eval_run_id (UUID): Unique identifier for the evaluation run
        agent_version_id (UUID): Agent version to evaluate
        suite_id (int): Problem suite ID
        lease_expires_at (datetime.datetime): When the lease expires
        code_download_url (str): Presigned URL to download agent code
        chutes_access_token (None | str | Unset): Fresh Chutes access token for miner-funded inference
    """

    eval_run_id: UUID
    agent_version_id: UUID
    suite_id: int
    lease_expires_at: datetime.datetime
    code_download_url: str
    chutes_access_token: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        eval_run_id = str(self.eval_run_id)

        agent_version_id = str(self.agent_version_id)

        suite_id = self.suite_id

        lease_expires_at = self.lease_expires_at.isoformat()

        code_download_url = self.code_download_url

        chutes_access_token: None | str | Unset
        if isinstance(self.chutes_access_token, Unset):
            chutes_access_token = UNSET
        else:
            chutes_access_token = self.chutes_access_token

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "eval_run_id": eval_run_id,
                "agent_version_id": agent_version_id,
                "suite_id": suite_id,
                "lease_expires_at": lease_expires_at,
                "code_download_url": code_download_url,
            }
        )
        if chutes_access_token is not UNSET:
            field_dict["chutes_access_token"] = chutes_access_token

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        eval_run_id = UUID(d.pop("eval_run_id"))

        agent_version_id = UUID(d.pop("agent_version_id"))

        suite_id = d.pop("suite_id")

        lease_expires_at = isoparse(d.pop("lease_expires_at"))

        code_download_url = d.pop("code_download_url")

        def _parse_chutes_access_token(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        chutes_access_token = _parse_chutes_access_token(d.pop("chutes_access_token", UNSET))

        claim_work_response = cls(
            eval_run_id=eval_run_id,
            agent_version_id=agent_version_id,
            suite_id=suite_id,
            lease_expires_at=lease_expires_at,
            code_download_url=code_download_url,
            chutes_access_token=chutes_access_token,
        )

        claim_work_response.additional_properties = d
        return claim_work_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
