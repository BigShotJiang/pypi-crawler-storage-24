from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="SetTopResponse")


@_attrs_define
class SetTopResponse:
    """Response for set-top operation.

    Attributes:
        agent_version_id (UUID): New top agent version
        suite_id (int): Suite ID
        top_at (datetime.datetime): When this agent became top
        previous_top_agent_version_id (None | Unset | UUID): Previous top agent version (now marked was_top)
    """

    agent_version_id: UUID
    suite_id: int
    top_at: datetime.datetime
    previous_top_agent_version_id: None | Unset | UUID = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        agent_version_id = str(self.agent_version_id)

        suite_id = self.suite_id

        top_at = self.top_at.isoformat()

        previous_top_agent_version_id: None | str | Unset
        if isinstance(self.previous_top_agent_version_id, Unset):
            previous_top_agent_version_id = UNSET
        elif isinstance(self.previous_top_agent_version_id, UUID):
            previous_top_agent_version_id = str(self.previous_top_agent_version_id)
        else:
            previous_top_agent_version_id = self.previous_top_agent_version_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agent_version_id": agent_version_id,
                "suite_id": suite_id,
                "top_at": top_at,
            }
        )
        if previous_top_agent_version_id is not UNSET:
            field_dict["previous_top_agent_version_id"] = previous_top_agent_version_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        agent_version_id = UUID(d.pop("agent_version_id"))

        suite_id = d.pop("suite_id")

        top_at = isoparse(d.pop("top_at"))

        def _parse_previous_top_agent_version_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                previous_top_agent_version_id_type_0 = UUID(data)

                return previous_top_agent_version_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        previous_top_agent_version_id = _parse_previous_top_agent_version_id(
            d.pop("previous_top_agent_version_id", UNSET)
        )

        set_top_response = cls(
            agent_version_id=agent_version_id,
            suite_id=suite_id,
            top_at=top_at,
            previous_top_agent_version_id=previous_top_agent_version_id,
        )

        set_top_response.additional_properties = d
        return set_top_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
