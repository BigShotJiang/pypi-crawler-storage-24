from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.top_agent_response_policy_type_0 import TopAgentResponsePolicyType0


T = TypeVar("T", bound="TopAgentResponse")


@_attrs_define
class TopAgentResponse:
    """Response for top agent endpoint.

    Attributes:
        suite_id (int): Active suite ID
        computed_at (datetime.datetime): When this was computed
        top_agent_version_id (None | Unset | UUID): Top agent version ID
        top_miner_hotkey (None | str | Unset): Top miner's hotkey
        top_score (float | None | Unset): Top score
        policy (None | TopAgentResponsePolicyType0 | Unset): Hysteresis/decay params
        challenge_threshold (float | None | Unset): Score required to dethrone
        emission_weight (float | None | Unset): Current emission weight (1.0=full)
        margin (float | None | Unset): Current challenge margin fraction
    """

    suite_id: int
    computed_at: datetime.datetime
    top_agent_version_id: None | Unset | UUID = UNSET
    top_miner_hotkey: None | str | Unset = UNSET
    top_score: float | None | Unset = UNSET
    policy: None | TopAgentResponsePolicyType0 | Unset = UNSET
    challenge_threshold: float | None | Unset = UNSET
    emission_weight: float | None | Unset = UNSET
    margin: float | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.top_agent_response_policy_type_0 import TopAgentResponsePolicyType0

        suite_id = self.suite_id

        computed_at = self.computed_at.isoformat()

        top_agent_version_id: None | str | Unset
        if isinstance(self.top_agent_version_id, Unset):
            top_agent_version_id = UNSET
        elif isinstance(self.top_agent_version_id, UUID):
            top_agent_version_id = str(self.top_agent_version_id)
        else:
            top_agent_version_id = self.top_agent_version_id

        top_miner_hotkey: None | str | Unset
        if isinstance(self.top_miner_hotkey, Unset):
            top_miner_hotkey = UNSET
        else:
            top_miner_hotkey = self.top_miner_hotkey

        top_score: float | None | Unset
        if isinstance(self.top_score, Unset):
            top_score = UNSET
        else:
            top_score = self.top_score

        policy: dict[str, Any] | None | Unset
        if isinstance(self.policy, Unset):
            policy = UNSET
        elif isinstance(self.policy, TopAgentResponsePolicyType0):
            policy = self.policy.to_dict()
        else:
            policy = self.policy

        challenge_threshold: float | None | Unset
        if isinstance(self.challenge_threshold, Unset):
            challenge_threshold = UNSET
        else:
            challenge_threshold = self.challenge_threshold

        emission_weight: float | None | Unset
        if isinstance(self.emission_weight, Unset):
            emission_weight = UNSET
        else:
            emission_weight = self.emission_weight

        margin: float | None | Unset
        if isinstance(self.margin, Unset):
            margin = UNSET
        else:
            margin = self.margin

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "suite_id": suite_id,
                "computed_at": computed_at,
            }
        )
        if top_agent_version_id is not UNSET:
            field_dict["top_agent_version_id"] = top_agent_version_id
        if top_miner_hotkey is not UNSET:
            field_dict["top_miner_hotkey"] = top_miner_hotkey
        if top_score is not UNSET:
            field_dict["top_score"] = top_score
        if policy is not UNSET:
            field_dict["policy"] = policy
        if challenge_threshold is not UNSET:
            field_dict["challenge_threshold"] = challenge_threshold
        if emission_weight is not UNSET:
            field_dict["emission_weight"] = emission_weight
        if margin is not UNSET:
            field_dict["margin"] = margin

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.top_agent_response_policy_type_0 import TopAgentResponsePolicyType0

        d = dict(src_dict)
        suite_id = d.pop("suite_id")

        computed_at = isoparse(d.pop("computed_at"))

        def _parse_top_agent_version_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                top_agent_version_id_type_0 = UUID(data)

                return top_agent_version_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        top_agent_version_id = _parse_top_agent_version_id(d.pop("top_agent_version_id", UNSET))

        def _parse_top_miner_hotkey(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        top_miner_hotkey = _parse_top_miner_hotkey(d.pop("top_miner_hotkey", UNSET))

        def _parse_top_score(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        top_score = _parse_top_score(d.pop("top_score", UNSET))

        def _parse_policy(data: object) -> None | TopAgentResponsePolicyType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                policy_type_0 = TopAgentResponsePolicyType0.from_dict(data)

                return policy_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TopAgentResponsePolicyType0 | Unset, data)

        policy = _parse_policy(d.pop("policy", UNSET))

        def _parse_challenge_threshold(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        challenge_threshold = _parse_challenge_threshold(d.pop("challenge_threshold", UNSET))

        def _parse_emission_weight(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        emission_weight = _parse_emission_weight(d.pop("emission_weight", UNSET))

        def _parse_margin(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        margin = _parse_margin(d.pop("margin", UNSET))

        top_agent_response = cls(
            suite_id=suite_id,
            computed_at=computed_at,
            top_agent_version_id=top_agent_version_id,
            top_miner_hotkey=top_miner_hotkey,
            top_score=top_score,
            policy=policy,
            challenge_threshold=challenge_threshold,
            emission_weight=emission_weight,
            margin=margin,
        )

        top_agent_response.additional_properties = d
        return top_agent_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
