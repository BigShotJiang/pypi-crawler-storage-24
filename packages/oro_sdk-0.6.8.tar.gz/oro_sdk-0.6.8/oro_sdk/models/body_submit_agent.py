from __future__ import annotations

from collections.abc import Mapping
from io import BytesIO
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, File, Unset

T = TypeVar("T", bound="BodySubmitAgent")


@_attrs_define
class BodySubmitAgent:
    """
    Attributes:
        agent_name (str): Name for this agent (unique per miner)
        file (File): Python agent file (max 1MB)
        chutes_refresh_token (None | str | Unset): Chutes OAuth refresh token for miner-funded inference
    """

    agent_name: str
    file: File
    chutes_refresh_token: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        agent_name = self.agent_name

        file = self.file.to_tuple()

        chutes_refresh_token: None | str | Unset
        if isinstance(self.chutes_refresh_token, Unset):
            chutes_refresh_token = UNSET
        else:
            chutes_refresh_token = self.chutes_refresh_token

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agent_name": agent_name,
                "file": file,
            }
        )
        if chutes_refresh_token is not UNSET:
            field_dict["chutes_refresh_token"] = chutes_refresh_token

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("agent_name", (None, str(self.agent_name).encode(), "text/plain")))

        files.append(("file", self.file.to_tuple()))

        if not isinstance(self.chutes_refresh_token, Unset):
            if isinstance(self.chutes_refresh_token, str):
                files.append(("chutes_refresh_token", (None, str(self.chutes_refresh_token).encode(), "text/plain")))
            else:
                files.append(("chutes_refresh_token", (None, str(self.chutes_refresh_token).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        agent_name = d.pop("agent_name")

        file = File(payload=BytesIO(d.pop("file")))

        def _parse_chutes_refresh_token(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        chutes_refresh_token = _parse_chutes_refresh_token(d.pop("chutes_refresh_token", UNSET))

        body_submit_agent = cls(
            agent_name=agent_name,
            file=file,
            chutes_refresh_token=chutes_refresh_token,
        )

        body_submit_agent.additional_properties = d
        return body_submit_agent

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
