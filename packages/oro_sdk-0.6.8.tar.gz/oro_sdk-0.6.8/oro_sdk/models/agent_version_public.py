from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="AgentVersionPublic")


@_attrs_define
class AgentVersionPublic:
    """Public representation of an agent version.

    Attributes:
        agent_version_id (UUID): Unique identifier for this version
        agent_id (UUID): Parent agent ID
        agent_name (str): Agent name
        miner_hotkey (str): Owner's hotkey
        version_number (int): Version number within this agent (v1, v2, etc.)
        submitted_at (datetime.datetime): When this version was submitted
        suite_id (int | None | Unset): Suite this version was submitted for
        latest_final_score (float | None | Unset): Final score if eligible
    """

    agent_version_id: UUID
    agent_id: UUID
    agent_name: str
    miner_hotkey: str
    version_number: int
    submitted_at: datetime.datetime
    suite_id: int | None | Unset = UNSET
    latest_final_score: float | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        agent_version_id = str(self.agent_version_id)

        agent_id = str(self.agent_id)

        agent_name = self.agent_name

        miner_hotkey = self.miner_hotkey

        version_number = self.version_number

        submitted_at = self.submitted_at.isoformat()

        suite_id: int | None | Unset
        if isinstance(self.suite_id, Unset):
            suite_id = UNSET
        else:
            suite_id = self.suite_id

        latest_final_score: float | None | Unset
        if isinstance(self.latest_final_score, Unset):
            latest_final_score = UNSET
        else:
            latest_final_score = self.latest_final_score

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agent_version_id": agent_version_id,
                "agent_id": agent_id,
                "agent_name": agent_name,
                "miner_hotkey": miner_hotkey,
                "version_number": version_number,
                "submitted_at": submitted_at,
            }
        )
        if suite_id is not UNSET:
            field_dict["suite_id"] = suite_id
        if latest_final_score is not UNSET:
            field_dict["latest_final_score"] = latest_final_score

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        agent_version_id = UUID(d.pop("agent_version_id"))

        agent_id = UUID(d.pop("agent_id"))

        agent_name = d.pop("agent_name")

        miner_hotkey = d.pop("miner_hotkey")

        version_number = d.pop("version_number")

        submitted_at = isoparse(d.pop("submitted_at"))

        def _parse_suite_id(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        suite_id = _parse_suite_id(d.pop("suite_id", UNSET))

        def _parse_latest_final_score(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        latest_final_score = _parse_latest_final_score(d.pop("latest_final_score", UNSET))

        agent_version_public = cls(
            agent_version_id=agent_version_id,
            agent_id=agent_id,
            agent_name=agent_name,
            miner_hotkey=miner_hotkey,
            version_number=version_number,
            submitted_at=submitted_at,
            suite_id=suite_id,
            latest_final_score=latest_final_score,
        )

        agent_version_public.additional_properties = d
        return agent_version_public

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
