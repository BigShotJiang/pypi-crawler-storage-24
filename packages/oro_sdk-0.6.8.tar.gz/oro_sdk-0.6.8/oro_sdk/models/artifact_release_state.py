from enum import Enum


class ArtifactReleaseState(str, Enum):
    HIDDEN = "HIDDEN"
    RELEASED = "RELEASED"

    def __str__(self) -> str:
        return str(self.value)
