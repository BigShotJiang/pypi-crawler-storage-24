from enum import Enum


class TerminalStatus(str, Enum):
    FAILED = "FAILED"
    SUCCESS = "SUCCESS"
    TIMED_OUT = "TIMED_OUT"

    def __str__(self) -> str:
        return str(self.value)
