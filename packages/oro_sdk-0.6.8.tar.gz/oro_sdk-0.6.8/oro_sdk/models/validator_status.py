from enum import Enum


class ValidatorStatus(str, Enum):
    AVAILABLE = "available"
    EVALUATING = "evaluating"

    def __str__(self) -> str:
        return str(self.value)
