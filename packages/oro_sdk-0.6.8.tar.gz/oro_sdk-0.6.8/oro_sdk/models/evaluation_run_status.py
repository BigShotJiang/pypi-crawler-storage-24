from enum import Enum


class EvaluationRunStatus(str, Enum):
    CANCELLED = "CANCELLED"
    CLAIMED = "CLAIMED"
    FAILED = "FAILED"
    RUNNING = "RUNNING"
    STALE = "STALE"
    SUCCESS = "SUCCESS"
    TIMED_OUT = "TIMED_OUT"

    def __str__(self) -> str:
        return str(self.value)
