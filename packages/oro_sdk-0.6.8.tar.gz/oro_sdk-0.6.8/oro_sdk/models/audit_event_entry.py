from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.audit_event_entry_details_type_0 import AuditEventEntryDetailsType0


T = TypeVar("T", bound="AuditEventEntry")


@_attrs_define
class AuditEventEntry:
    """Audit event log entry.

    Attributes:
        event_id (UUID): Event ID
        action (str): Action performed
        target_type (str): Type of target entity
        target_id (str): Target entity ID
        actor_hotkey (str): Admin who performed the action
        created_at (datetime.datetime): When the event occurred
        reason (None | str | Unset): Reason provided
        details (AuditEventEntryDetailsType0 | None | Unset): Additional context
    """

    event_id: UUID
    action: str
    target_type: str
    target_id: str
    actor_hotkey: str
    created_at: datetime.datetime
    reason: None | str | Unset = UNSET
    details: AuditEventEntryDetailsType0 | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.audit_event_entry_details_type_0 import AuditEventEntryDetailsType0

        event_id = str(self.event_id)

        action = self.action

        target_type = self.target_type

        target_id = self.target_id

        actor_hotkey = self.actor_hotkey

        created_at = self.created_at.isoformat()

        reason: None | str | Unset
        if isinstance(self.reason, Unset):
            reason = UNSET
        else:
            reason = self.reason

        details: dict[str, Any] | None | Unset
        if isinstance(self.details, Unset):
            details = UNSET
        elif isinstance(self.details, AuditEventEntryDetailsType0):
            details = self.details.to_dict()
        else:
            details = self.details

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "event_id": event_id,
                "action": action,
                "target_type": target_type,
                "target_id": target_id,
                "actor_hotkey": actor_hotkey,
                "created_at": created_at,
            }
        )
        if reason is not UNSET:
            field_dict["reason"] = reason
        if details is not UNSET:
            field_dict["details"] = details

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.audit_event_entry_details_type_0 import AuditEventEntryDetailsType0

        d = dict(src_dict)
        event_id = UUID(d.pop("event_id"))

        action = d.pop("action")

        target_type = d.pop("target_type")

        target_id = d.pop("target_id")

        actor_hotkey = d.pop("actor_hotkey")

        created_at = isoparse(d.pop("created_at"))

        def _parse_reason(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        reason = _parse_reason(d.pop("reason", UNSET))

        def _parse_details(data: object) -> AuditEventEntryDetailsType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                details_type_0 = AuditEventEntryDetailsType0.from_dict(data)

                return details_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(AuditEventEntryDetailsType0 | None | Unset, data)

        details = _parse_details(d.pop("details", UNSET))

        audit_event_entry = cls(
            event_id=event_id,
            action=action,
            target_type=target_type,
            target_id=target_id,
            actor_hotkey=actor_hotkey,
            created_at=created_at,
            reason=reason,
            details=details,
        )

        audit_event_entry.additional_properties = d
        return audit_event_entry

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
