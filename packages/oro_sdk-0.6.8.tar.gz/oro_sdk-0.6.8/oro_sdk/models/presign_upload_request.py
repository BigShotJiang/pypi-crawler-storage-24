from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="PresignUploadRequest")


@_attrs_define
class PresignUploadRequest:
    """Request for presigned upload URL.

    Attributes:
        content_length (int): Size of the upload in bytes
        eval_run_id (UUID): Evaluation run ID
        problem_id (UUID): Problem ID
        content_type (str | Unset): Content type of the upload Default: 'application/json'.
    """

    content_length: int
    eval_run_id: UUID
    problem_id: UUID
    content_type: str | Unset = "application/json"
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        content_length = self.content_length

        eval_run_id = str(self.eval_run_id)

        problem_id = str(self.problem_id)

        content_type = self.content_type

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "content_length": content_length,
                "eval_run_id": eval_run_id,
                "problem_id": problem_id,
            }
        )
        if content_type is not UNSET:
            field_dict["content_type"] = content_type

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        content_length = d.pop("content_length")

        eval_run_id = UUID(d.pop("eval_run_id"))

        problem_id = UUID(d.pop("problem_id"))

        content_type = d.pop("content_type", UNSET)

        presign_upload_request = cls(
            content_length=content_length,
            eval_run_id=eval_run_id,
            problem_id=problem_id,
            content_type=content_type,
        )

        presign_upload_request.additional_properties = d
        return presign_upload_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
