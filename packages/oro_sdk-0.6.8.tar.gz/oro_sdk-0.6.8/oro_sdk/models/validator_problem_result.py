from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.problem_status import ProblemStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.validator_problem_result_score_components_type_0 import ValidatorProblemResultScoreComponentsType0


T = TypeVar("T", bound="ValidatorProblemResult")


@_attrs_define
class ValidatorProblemResult:
    """Result from a single validator for a specific problem.

    Attributes:
        validator_hotkey (str): Validator hotkey
        status (ProblemStatus): Status of problem evaluation.
        score (float | None | Unset): Problem score from this validator
        score_components (None | Unset | ValidatorProblemResultScoreComponentsType0): Score breakdown from this
            validator
        updated_at (datetime.datetime | None | Unset): Last update from this validator
    """

    validator_hotkey: str
    status: ProblemStatus
    score: float | None | Unset = UNSET
    score_components: None | Unset | ValidatorProblemResultScoreComponentsType0 = UNSET
    updated_at: datetime.datetime | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.validator_problem_result_score_components_type_0 import ValidatorProblemResultScoreComponentsType0

        validator_hotkey = self.validator_hotkey

        status = self.status.value

        score: float | None | Unset
        if isinstance(self.score, Unset):
            score = UNSET
        else:
            score = self.score

        score_components: dict[str, Any] | None | Unset
        if isinstance(self.score_components, Unset):
            score_components = UNSET
        elif isinstance(self.score_components, ValidatorProblemResultScoreComponentsType0):
            score_components = self.score_components.to_dict()
        else:
            score_components = self.score_components

        updated_at: None | str | Unset
        if isinstance(self.updated_at, Unset):
            updated_at = UNSET
        elif isinstance(self.updated_at, datetime.datetime):
            updated_at = self.updated_at.isoformat()
        else:
            updated_at = self.updated_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "validator_hotkey": validator_hotkey,
                "status": status,
            }
        )
        if score is not UNSET:
            field_dict["score"] = score
        if score_components is not UNSET:
            field_dict["score_components"] = score_components
        if updated_at is not UNSET:
            field_dict["updated_at"] = updated_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.validator_problem_result_score_components_type_0 import ValidatorProblemResultScoreComponentsType0

        d = dict(src_dict)
        validator_hotkey = d.pop("validator_hotkey")

        status = ProblemStatus(d.pop("status"))

        def _parse_score(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        score = _parse_score(d.pop("score", UNSET))

        def _parse_score_components(data: object) -> None | Unset | ValidatorProblemResultScoreComponentsType0:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                score_components_type_0 = ValidatorProblemResultScoreComponentsType0.from_dict(data)

                return score_components_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | ValidatorProblemResultScoreComponentsType0, data)

        score_components = _parse_score_components(d.pop("score_components", UNSET))

        def _parse_updated_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                updated_at_type_0 = isoparse(data)

                return updated_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        updated_at = _parse_updated_at(d.pop("updated_at", UNSET))

        validator_problem_result = cls(
            validator_hotkey=validator_hotkey,
            status=status,
            score=score,
            score_components=score_components,
            updated_at=updated_at,
        )

        validator_problem_result.additional_properties = d
        return validator_problem_result

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
