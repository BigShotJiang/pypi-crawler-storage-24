from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.code_analysis_error_violations_item import CodeAnalysisErrorViolationsItem


T = TypeVar("T", bound="CodeAnalysisError")


@_attrs_define
class CodeAnalysisError:
    """422 - Static analysis found issues in submitted code.

    Attributes:
        detail (str): Error message describing what went wrong
        error_code (Literal['CODE_ANALYSIS_ERROR'] | Unset): Error code for programmatic handling Default:
            'CODE_ANALYSIS_ERROR'.
        violations (list[CodeAnalysisErrorViolationsItem] | Unset): List of violations found (rule, severity, message,
            line)
    """

    detail: str
    error_code: Literal["CODE_ANALYSIS_ERROR"] | Unset = "CODE_ANALYSIS_ERROR"
    violations: list[CodeAnalysisErrorViolationsItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        detail = self.detail

        error_code = self.error_code

        violations: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.violations, Unset):
            violations = []
            for violations_item_data in self.violations:
                violations_item = violations_item_data.to_dict()
                violations.append(violations_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "detail": detail,
            }
        )
        if error_code is not UNSET:
            field_dict["error_code"] = error_code
        if violations is not UNSET:
            field_dict["violations"] = violations

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.code_analysis_error_violations_item import CodeAnalysisErrorViolationsItem

        d = dict(src_dict)
        detail = d.pop("detail")

        error_code = cast(Literal["CODE_ANALYSIS_ERROR"] | Unset, d.pop("error_code", UNSET))
        if error_code != "CODE_ANALYSIS_ERROR" and not isinstance(error_code, Unset):
            raise ValueError(f"error_code must match const 'CODE_ANALYSIS_ERROR', got '{error_code}'")

        _violations = d.pop("violations", UNSET)
        violations: list[CodeAnalysisErrorViolationsItem] | Unset = UNSET
        if _violations is not UNSET:
            violations = []
            for violations_item_data in _violations:
                violations_item = CodeAnalysisErrorViolationsItem.from_dict(violations_item_data)

                violations.append(violations_item)

        code_analysis_error = cls(
            detail=detail,
            error_code=error_code,
            violations=violations,
        )

        code_analysis_error.additional_properties = d
        return code_analysis_error

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
