"""ORO SDK - Official Python SDK for the ORO Bittensor Subnet API.

This SDK is auto-generated from the OpenAPI specification.
To regenerate: ./scripts/generate-python.sh

Example usage:

    # Public endpoints (no auth)
    from oro_sdk import Client
    from oro_sdk.api.public import get_leaderboard

    client = Client(base_url="https://api.oro.ai")
    leaderboard = get_leaderboard.sync(client=client)

    # Authenticated endpoints (validators/miners)
    from bittensor_wallet import Wallet
    from oro_sdk.bittensor_auth import BittensorAuthClient
    from oro_sdk.api.validator import claim_work

    wallet = Wallet(name="validator", hotkey="default")
    client = BittensorAuthClient(base_url="https://api.oro.ai", wallet=wallet)
    work = claim_work.sync(client=client)
"""

from .client import AuthenticatedClient, Client
from .bittensor_auth import (
    BittensorAuthClient,
    SigningTransport,
    AsyncSigningTransport,
    generate_auth_headers,
)
from .retry import (
    AsyncRetryTransport,
    RetryConfig,
    RetryContext,
    RetryTransport,
)
from ._generated_errors import *  # noqa: F403
from ._generated_errors import __all__ as _generated_exports
from .error_utils import (
    ALL_ERROR_TYPES,
    ErrorCategory,
    OroErrorCode,
    classify_error,
    classify_status,
    get_error_code,
    get_error_detail,
    is_error,
    is_transient,
    is_transient_status,
)

__version__ = "0.1.0"

__all__ = (
    "AuthenticatedClient",
    "Client",
    "BittensorAuthClient",
    "SigningTransport",
    "AsyncSigningTransport",
    "generate_auth_headers",
    "AsyncRetryTransport",
    "RetryConfig",
    "RetryContext",
    "RetryTransport",
    *_generated_exports,
    "ALL_ERROR_TYPES",
    "ErrorCategory",
    "OroErrorCode",
    "classify_error",
    "classify_status",
    "get_error_code",
    "get_error_detail",
    "is_error",
    "is_transient",
    "is_transient_status",
    "__version__",
)
