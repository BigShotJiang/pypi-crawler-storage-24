from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.pending_evaluations_response import PendingEvaluationsResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    suite_id: int | None | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_suite_id: int | None | Unset
    if isinstance(suite_id, Unset):
        json_suite_id = UNSET
    else:
        json_suite_id = suite_id
    params["suite_id"] = json_suite_id

    params["limit"] = limit

    params["offset"] = offset

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/public/evaluations/pending",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | PendingEvaluationsResponse | None:
    if response.status_code == 200:
        response_200 = PendingEvaluationsResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | PendingEvaluationsResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    suite_id: int | None | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> Response[HTTPValidationError | PendingEvaluationsResponse]:
    """Get pending evaluations

     Get all open work items awaiting validator evaluations, with queue summary.

    Args:
        suite_id (int | None | Unset): Filter by problem suite ID
        limit (int | Unset): Maximum items to return Default: 100.
        offset (int | Unset): Number of items to skip Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | PendingEvaluationsResponse]
    """

    kwargs = _get_kwargs(
        suite_id=suite_id,
        limit=limit,
        offset=offset,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    suite_id: int | None | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> HTTPValidationError | PendingEvaluationsResponse | None:
    """Get pending evaluations

     Get all open work items awaiting validator evaluations, with queue summary.

    Args:
        suite_id (int | None | Unset): Filter by problem suite ID
        limit (int | Unset): Maximum items to return Default: 100.
        offset (int | Unset): Number of items to skip Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | PendingEvaluationsResponse
    """

    return sync_detailed(
        client=client,
        suite_id=suite_id,
        limit=limit,
        offset=offset,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    suite_id: int | None | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> Response[HTTPValidationError | PendingEvaluationsResponse]:
    """Get pending evaluations

     Get all open work items awaiting validator evaluations, with queue summary.

    Args:
        suite_id (int | None | Unset): Filter by problem suite ID
        limit (int | Unset): Maximum items to return Default: 100.
        offset (int | Unset): Number of items to skip Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | PendingEvaluationsResponse]
    """

    kwargs = _get_kwargs(
        suite_id=suite_id,
        limit=limit,
        offset=offset,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    suite_id: int | None | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> HTTPValidationError | PendingEvaluationsResponse | None:
    """Get pending evaluations

     Get all open work items awaiting validator evaluations, with queue summary.

    Args:
        suite_id (int | None | Unset): Filter by problem suite ID
        limit (int | Unset): Maximum items to return Default: 100.
        offset (int | Unset): Number of items to skip Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | PendingEvaluationsResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            suite_id=suite_id,
            limit=limit,
            offset=offset,
        )
    ).parsed
