from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.eval_run_not_found_error import EvalRunNotFoundError
from ...models.evaluation_run_detail import EvaluationRunDetail
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    eval_run_id: UUID,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/public/evaluation-runs/{eval_run_id}".format(
            eval_run_id=quote(str(eval_run_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> EvalRunNotFoundError | EvaluationRunDetail | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = EvaluationRunDetail.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = EvalRunNotFoundError.from_dict(response.json())

        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[EvalRunNotFoundError | EvaluationRunDetail | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    eval_run_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[EvalRunNotFoundError | EvaluationRunDetail | HTTPValidationError]:
    """Get evaluation run details

     Get detailed information about a specific evaluation run.

    Args:
        eval_run_id (UUID): Evaluation run ID

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[EvalRunNotFoundError | EvaluationRunDetail | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        eval_run_id=eval_run_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    eval_run_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> EvalRunNotFoundError | EvaluationRunDetail | HTTPValidationError | None:
    """Get evaluation run details

     Get detailed information about a specific evaluation run.

    Args:
        eval_run_id (UUID): Evaluation run ID

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        EvalRunNotFoundError | EvaluationRunDetail | HTTPValidationError
    """

    return sync_detailed(
        eval_run_id=eval_run_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    eval_run_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[EvalRunNotFoundError | EvaluationRunDetail | HTTPValidationError]:
    """Get evaluation run details

     Get detailed information about a specific evaluation run.

    Args:
        eval_run_id (UUID): Evaluation run ID

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[EvalRunNotFoundError | EvaluationRunDetail | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        eval_run_id=eval_run_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    eval_run_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> EvalRunNotFoundError | EvaluationRunDetail | HTTPValidationError | None:
    """Get evaluation run details

     Get detailed information about a specific evaluation run.

    Args:
        eval_run_id (UUID): Evaluation run ID

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        EvalRunNotFoundError | EvaluationRunDetail | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            eval_run_id=eval_run_id,
            client=client,
        )
    ).parsed
