from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.agent_not_found_error import AgentNotFoundError
from ...models.agent_version_history_entry import AgentVersionHistoryEntry
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    agent_id: UUID,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/miner/agents/{agent_id}/versions".format(
            agent_id=quote(str(agent_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> AgentNotFoundError | HTTPValidationError | list[AgentVersionHistoryEntry] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = AgentVersionHistoryEntry.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 404:
        response_404 = AgentNotFoundError.from_dict(response.json())

        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[AgentNotFoundError | HTTPValidationError | list[AgentVersionHistoryEntry]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    agent_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[AgentNotFoundError | HTTPValidationError | list[AgentVersionHistoryEntry]]:
    """List agent versions

     List all versions of a specific agent owned by the miner.

    Args:
        agent_id (UUID): Agent ID

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AgentNotFoundError | HTTPValidationError | list[AgentVersionHistoryEntry]]
    """

    kwargs = _get_kwargs(
        agent_id=agent_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    agent_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> AgentNotFoundError | HTTPValidationError | list[AgentVersionHistoryEntry] | None:
    """List agent versions

     List all versions of a specific agent owned by the miner.

    Args:
        agent_id (UUID): Agent ID

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AgentNotFoundError | HTTPValidationError | list[AgentVersionHistoryEntry]
    """

    return sync_detailed(
        agent_id=agent_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    agent_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[AgentNotFoundError | HTTPValidationError | list[AgentVersionHistoryEntry]]:
    """List agent versions

     List all versions of a specific agent owned by the miner.

    Args:
        agent_id (UUID): Agent ID

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AgentNotFoundError | HTTPValidationError | list[AgentVersionHistoryEntry]]
    """

    kwargs = _get_kwargs(
        agent_id=agent_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    agent_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> AgentNotFoundError | HTTPValidationError | list[AgentVersionHistoryEntry] | None:
    """List agent versions

     List all versions of a specific agent owned by the miner.

    Args:
        agent_id (UUID): Agent ID

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AgentNotFoundError | HTTPValidationError | list[AgentVersionHistoryEntry]
    """

    return (
        await asyncio_detailed(
            agent_id=agent_id,
            client=client,
        )
    ).parsed
