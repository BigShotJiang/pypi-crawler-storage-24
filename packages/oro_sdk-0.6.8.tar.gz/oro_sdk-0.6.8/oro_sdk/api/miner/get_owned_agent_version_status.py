from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.agent_version_not_found_error import AgentVersionNotFoundError
from ...models.agent_version_status import AgentVersionStatus
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    agent_version_id: UUID,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/miner/agent-versions/{agent_version_id}".format(
            agent_version_id=quote(str(agent_version_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> AgentVersionNotFoundError | AgentVersionStatus | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = AgentVersionStatus.from_dict(response.json())

        return response_200

    if response.status_code == 404:
        response_404 = AgentVersionNotFoundError.from_dict(response.json())

        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[AgentVersionNotFoundError | AgentVersionStatus | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    agent_version_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[AgentVersionNotFoundError | AgentVersionStatus | HTTPValidationError]:
    """Get agent version status

     Get detailed status of a specific agent version owned by the miner.

    Args:
        agent_version_id (UUID): Agent version ID

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AgentVersionNotFoundError | AgentVersionStatus | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        agent_version_id=agent_version_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    agent_version_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> AgentVersionNotFoundError | AgentVersionStatus | HTTPValidationError | None:
    """Get agent version status

     Get detailed status of a specific agent version owned by the miner.

    Args:
        agent_version_id (UUID): Agent version ID

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AgentVersionNotFoundError | AgentVersionStatus | HTTPValidationError
    """

    return sync_detailed(
        agent_version_id=agent_version_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    agent_version_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> Response[AgentVersionNotFoundError | AgentVersionStatus | HTTPValidationError]:
    """Get agent version status

     Get detailed status of a specific agent version owned by the miner.

    Args:
        agent_version_id (UUID): Agent version ID

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AgentVersionNotFoundError | AgentVersionStatus | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        agent_version_id=agent_version_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    agent_version_id: UUID,
    *,
    client: AuthenticatedClient | Client,
) -> AgentVersionNotFoundError | AgentVersionStatus | HTTPValidationError | None:
    """Get agent version status

     Get detailed status of a specific agent version owned by the miner.

    Args:
        agent_version_id (UUID): Agent version ID

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AgentVersionNotFoundError | AgentVersionStatus | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            agent_version_id=agent_version_id,
            client=client,
        )
    ).parsed
