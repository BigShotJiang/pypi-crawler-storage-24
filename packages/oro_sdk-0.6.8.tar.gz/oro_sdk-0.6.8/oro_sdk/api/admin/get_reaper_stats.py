from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.reaper_stats_response import ReaperStatsResponse
from ...types import Response


def _get_kwargs() -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/admin/reaper/stats",
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> ReaperStatsResponse | None:
    if response.status_code == 200:
        response_200 = ReaperStatsResponse.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[ReaperStatsResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
) -> Response[ReaperStatsResponse]:
    """Get reaper service statistics

     Get statistics about the background reaper service.

    The reaper service runs periodically to clean up orphaned evaluation runs
    where validators have stopped reporting (crashed or disconnected).

    Stats are read from Redis (persisted by the active reaper instance) to ensure
    consistent visibility across all replicas.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ReaperStatsResponse]
    """

    kwargs = _get_kwargs()

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
) -> ReaperStatsResponse | None:
    """Get reaper service statistics

     Get statistics about the background reaper service.

    The reaper service runs periodically to clean up orphaned evaluation runs
    where validators have stopped reporting (crashed or disconnected).

    Stats are read from Redis (persisted by the active reaper instance) to ensure
    consistent visibility across all replicas.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ReaperStatsResponse
    """

    return sync_detailed(
        client=client,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
) -> Response[ReaperStatsResponse]:
    """Get reaper service statistics

     Get statistics about the background reaper service.

    The reaper service runs periodically to clean up orphaned evaluation runs
    where validators have stopped reporting (crashed or disconnected).

    Stats are read from Redis (persisted by the active reaper instance) to ensure
    consistent visibility across all replicas.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ReaperStatsResponse]
    """

    kwargs = _get_kwargs()

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
) -> ReaperStatsResponse | None:
    """Get reaper service statistics

     Get statistics about the background reaper service.

    The reaper service runs periodically to clean up orphaned evaluation runs
    where validators have stopped reporting (crashed or disconnected).

    Stats are read from Redis (persisted by the active reaper instance) to ensure
    consistent visibility across all replicas.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ReaperStatsResponse
    """

    return (
        await asyncio_detailed(
            client=client,
        )
    ).parsed
