from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.audit_events_response import AuditEventsResponse
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    action: None | str | Unset = UNSET,
    target_type: None | str | Unset = UNSET,
    target_id: None | str | Unset = UNSET,
    actor_hotkey: None | str | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_action: None | str | Unset
    if isinstance(action, Unset):
        json_action = UNSET
    else:
        json_action = action
    params["action"] = json_action

    json_target_type: None | str | Unset
    if isinstance(target_type, Unset):
        json_target_type = UNSET
    else:
        json_target_type = target_type
    params["target_type"] = json_target_type

    json_target_id: None | str | Unset
    if isinstance(target_id, Unset):
        json_target_id = UNSET
    else:
        json_target_id = target_id
    params["target_id"] = json_target_id

    json_actor_hotkey: None | str | Unset
    if isinstance(actor_hotkey, Unset):
        json_actor_hotkey = UNSET
    else:
        json_actor_hotkey = actor_hotkey
    params["actor_hotkey"] = json_actor_hotkey

    params["limit"] = limit

    params["offset"] = offset

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/admin/audit-events",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> AuditEventsResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = AuditEventsResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[AuditEventsResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    action: None | str | Unset = UNSET,
    target_type: None | str | Unset = UNSET,
    target_id: None | str | Unset = UNSET,
    actor_hotkey: None | str | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> Response[AuditEventsResponse | HTTPValidationError]:
    """Get audit events

     Retrieve audit events with optional filtering and pagination.

    Args:
        action (None | str | Unset): Filter by action type (e.g., BAN_MINER)
        target_type (None | str | Unset): Filter by target type
        target_id (None | str | Unset): Filter by target ID
        actor_hotkey (None | str | Unset): Filter by actor hotkey
        limit (int | Unset): Number of events to return Default: 100.
        offset (int | Unset): Offset for pagination Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AuditEventsResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        action=action,
        target_type=target_type,
        target_id=target_id,
        actor_hotkey=actor_hotkey,
        limit=limit,
        offset=offset,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    action: None | str | Unset = UNSET,
    target_type: None | str | Unset = UNSET,
    target_id: None | str | Unset = UNSET,
    actor_hotkey: None | str | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> AuditEventsResponse | HTTPValidationError | None:
    """Get audit events

     Retrieve audit events with optional filtering and pagination.

    Args:
        action (None | str | Unset): Filter by action type (e.g., BAN_MINER)
        target_type (None | str | Unset): Filter by target type
        target_id (None | str | Unset): Filter by target ID
        actor_hotkey (None | str | Unset): Filter by actor hotkey
        limit (int | Unset): Number of events to return Default: 100.
        offset (int | Unset): Offset for pagination Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AuditEventsResponse | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        action=action,
        target_type=target_type,
        target_id=target_id,
        actor_hotkey=actor_hotkey,
        limit=limit,
        offset=offset,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    action: None | str | Unset = UNSET,
    target_type: None | str | Unset = UNSET,
    target_id: None | str | Unset = UNSET,
    actor_hotkey: None | str | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> Response[AuditEventsResponse | HTTPValidationError]:
    """Get audit events

     Retrieve audit events with optional filtering and pagination.

    Args:
        action (None | str | Unset): Filter by action type (e.g., BAN_MINER)
        target_type (None | str | Unset): Filter by target type
        target_id (None | str | Unset): Filter by target ID
        actor_hotkey (None | str | Unset): Filter by actor hotkey
        limit (int | Unset): Number of events to return Default: 100.
        offset (int | Unset): Offset for pagination Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AuditEventsResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        action=action,
        target_type=target_type,
        target_id=target_id,
        actor_hotkey=actor_hotkey,
        limit=limit,
        offset=offset,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    action: None | str | Unset = UNSET,
    target_type: None | str | Unset = UNSET,
    target_id: None | str | Unset = UNSET,
    actor_hotkey: None | str | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> AuditEventsResponse | HTTPValidationError | None:
    """Get audit events

     Retrieve audit events with optional filtering and pagination.

    Args:
        action (None | str | Unset): Filter by action type (e.g., BAN_MINER)
        target_type (None | str | Unset): Filter by target type
        target_id (None | str | Unset): Filter by target ID
        actor_hotkey (None | str | Unset): Filter by actor hotkey
        limit (int | Unset): Number of events to return Default: 100.
        offset (int | Unset): Offset for pagination Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AuditEventsResponse | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            action=action,
            target_type=target_type,
            target_id=target_id,
            actor_hotkey=actor_hotkey,
            limit=limit,
            offset=offset,
        )
    ).parsed
