from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.cancel_request import CancelRequest
from ...models.cancel_response import CancelResponse
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    agent_version_id: UUID,
    *,
    body: CancelRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/admin/agent-versions/{agent_version_id}/cancel".format(
            agent_version_id=quote(str(agent_version_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> CancelResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = CancelResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[CancelResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    agent_version_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: CancelRequest,
) -> Response[CancelResponse | HTTPValidationError]:
    """Cancel evaluation of an agent version

     Cancel active evaluation runs for an agent version.

    Args:
        agent_version_id (UUID): Agent version ID
        body (CancelRequest): Request to cancel an agent version's evaluation.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CancelResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        agent_version_id=agent_version_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    agent_version_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: CancelRequest,
) -> CancelResponse | HTTPValidationError | None:
    """Cancel evaluation of an agent version

     Cancel active evaluation runs for an agent version.

    Args:
        agent_version_id (UUID): Agent version ID
        body (CancelRequest): Request to cancel an agent version's evaluation.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CancelResponse | HTTPValidationError
    """

    return sync_detailed(
        agent_version_id=agent_version_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    agent_version_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: CancelRequest,
) -> Response[CancelResponse | HTTPValidationError]:
    """Cancel evaluation of an agent version

     Cancel active evaluation runs for an agent version.

    Args:
        agent_version_id (UUID): Agent version ID
        body (CancelRequest): Request to cancel an agent version's evaluation.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CancelResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        agent_version_id=agent_version_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    agent_version_id: UUID,
    *,
    client: AuthenticatedClient | Client,
    body: CancelRequest,
) -> CancelResponse | HTTPValidationError | None:
    """Cancel evaluation of an agent version

     Cancel active evaluation runs for an agent version.

    Args:
        agent_version_id (UUID): Agent version ID
        body (CancelRequest): Request to cancel an agent version's evaluation.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CancelResponse | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            agent_version_id=agent_version_id,
            client=client,
            body=body,
        )
    ).parsed
