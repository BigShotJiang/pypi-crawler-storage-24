#!/usr/bin/env python3
"""
Analyse and/or coarse-grain trajectory (.dcd) frame by frame.
"""

# This software is provided under The Modified BSD-3-Clause License (Consistent with Python 3 licenses).
# Refer to and abide by the Copyright detailed in LICENSE file found in the root directory of the library!

##################################################
#                                                #
#  Shapespyer - soft matter structure generator  #
#                                                #
#  Author: Dr Andrey Brukhno (c) 2020 - 2025     #
#          Daresbury Laboratory, SCD, STFC/UKRI  #
#  Contrib: Dr Valeria Losasso (c) 2024          #
#           BSc Saul Beck (c) 2024               #
#                                                #
##################################################

##from __future__ import absolute_import

__author__ = "Andrey Brukhno"
__version__ = "0.2.4 (Beta)"

import sys, os
import argparse
import logging
from pathlib import Path
from numpy import zeros, arange, column_stack, sqrt, savetxt
from time import time

from shapes.cgmap.coarse_grainer import CoarseGrainer
from shapes.basics.globals import TINY
from shapes.basics.defaults import NL_INDENT
from shapes.basics.input import InputParser
from shapes.basics.functions import sec2hms  # timing
from shapes.basics.utils import LogConfiguration
# from shapes.basics.mendeleyev import Chemistry

from shapes.stage.protovector import Vec3
# from shapes.stage.protoatom import Atom
# from shapes.stage.protomolecule import Molecule
from shapes.stage.protomoleculeset import MoleculeSet
# from shapes.stage.protomolecularsystem import MolecularSystem

from shapes.ioports.iotraj import DCDTrajectory
# from shapes.ioports.ioframe import Frame, CellParameters
# from shapes.ioports.iotop import ITPTopology
# from shapes.ioports.iogro import groFile
# from shapes.ioports.iopdb import pdbFile

from shapes.basics.help import beauty #, help

logger = logging.getLogger("__main__")
# logger = LogConfiguration(level=logging.INFO, file_name="ana-trajectory.log").logger

def ana_traj(
        fpath_ref: str,
        fpath_trj: str,
        fpath_out: str,
        scheme: dict,
) -> None:
    """
    Calculate average densities of various types over a trajectory, which can be
    atomistic (AA) or coarse-grain (CG). In the case of atomistic trajectory one
    can convert it to coarse-grain representation and calculate CG densities in one go.

    Parameters
    ----------
    fpath_ref : str
        File path to the reference file (only .gro or .pdb formats)
    fpath_trj : str
        File path to the trajectory file (only .dcd format supported)
    fpath_out : str
        File path where the coarse-grained trajectory will be saved
    scheme : dict
        A dictionary specifying a set of options for the analysis

    """

    def save_histograms(histograms: list, grid: list, bname_inp: str, is_stderr: bool = False) -> None:
        htotals = {}
        hsquare = {}
        nframes = len(histograms)
        binmax  = 0
        for ih, hist in enumerate(histograms):
            if hist:
                for hkey in hist.keys():
                    if hkey not in htotals.keys():
                        binmax = max(binmax, len(hist[hkey]))
                        htotals.update({ hkey: hist[hkey] })
                        hsquare.update({ hkey: hist[hkey]**2 })
                    else:
                        htotals[hkey] += hist[hkey]
                        hsquare[hkey] += hist[hkey]**2
                # logger.debug(f"Histograms {ih} '{hist.keys()}'")
            else:
                logger.info(f"Histogram {ih} (None?) :{hist}")

        rmin = grid[0]
        rmax = grid[1]
        dbin = grid[2]
        dbin2 = dbin / 2.0
        if rmin < -TINY:
            nbins = binmax
        else:
            nbins = round((rmax - rmin) / dbin)
        drange = arange(0, nbins, dtype=float) * dbin + dbin2 + rmin

        if len(htotals.keys()) > 0:
            for hkey in htotals.keys():
                nframes =  float(nframes)
                htotals[hkey] /= nframes
                if is_stderr:
                    hsquare[hkey] /= nframes
                    hsquare[hkey] = sqrt(abs(hsquare[hkey] - htotals[hkey] ** 2))
                    fmtkey = "{:<9}".format(hkey)
                    header = '# bin  ' + fmtkey + '  std.error  std.deviation\n'
                    with open(bname_inp + '_' + hkey + '_avr.dat', 'wb') as fout:
                        fout.write(bytes(header,"ASCII"))
                        savetxt(fout,
                                column_stack((drange,
                                                htotals[hkey] +0.0,
                                                hsquare[hkey]/sqrt(nframes) + 0.0,
                                                hsquare[hkey] +0.0)),
                                fmt='%-0.3f %10.7f %10.7f %10.7f')
                else:
                    savetxt(bname_inp + '_' + hkey + '_avr.dat',
                            column_stack((drange, htotals[hkey] + 0.0)),
                            fmt='%-0.3f %10.7f')
    # end of save_histograms()

    def save_cluster_stats(clust_nums: list, 
                           bname_inp: str,
                           clust_name: str, 
                           file_suffix: str, 
                           nframes: int) -> None:
        # crange, counts = zip(*[ pcls for ncls in clust_nums for pcls in ncls])
        crange = [ pcls[0] for ncls in clust_nums for pcls in ncls ]
        crange = set(crange)
        totmax = max(crange)+1
        clust_max = []
        clust_nmx = []
        clust_amx = []
        chist_list = []
        for ncls in clust_nums:
            crange, counts = zip(*[ pcls for pcls in ncls])
            chist = zeros(totmax)
            chist[list(crange)] = counts
            chist_dict = { 'hcls_' + file_suffix : chist }
            chist_list.append(chist_dict)
            # AB: the largest cluster(s) analysis
            clust_max.append(crange[-1])
            clust_nmx.append(counts[-1])
            if len(crange) > 2:
                # AB: average size of the largest 3 clusters
                clust_sum = sum( [ crange[-i-1] * counts[-i-1] for i in range(3) ] )
                clust_amx.append( clust_sum / sum( counts[-3:] ) )

        fname = bname_inp  # + '_dmax' + str(cls_dmax) + '-' + str(ana_dmax)
        ngrid = [-0.5, totmax, 1]
        save_histograms(chist_list, ngrid, bname_inp)

        header = "# frame   cmax   #cmax   avr(max3) for " + clust_name + " clusters \n"
        with open(fname + '_xcls_' + file_suffix + '_evol.dat', 'wb') as fout:
            fout.write(bytes(header,"ASCII"))
            drange = arange(0, nframes, dtype=int)
            if len(clust_amx) == len(clust_max):
                savetxt(fout, column_stack((drange, 
                                            clust_max,
                                            clust_nmx,
                                            clust_amx)), 
                                            fmt='%-5d %7d %7d %10.3f')
            else:
                savetxt(fout, column_stack((drange, 
                                            clust_max, 
                                            clust_nmx)), 
                                            fmt='%-5d %7d %7d')
    # end of save_cluster_stats()
    
    def write_config(fname: str, 
                     molsets: list, 
                     boxdims: Vec3, 
                     header: str,
                     is_gro: bool,
                     ) -> None:
        from shapes.ioports import ioframe
        cell = ioframe.CellParameters()
        cell.dims_from_vec(boxdims)
        cell.angs_from_vec(Vec3(90.,90.,90.))

        out_data = dict()
        out_data.update({"header": header})
        out_data.update({"molsout": molsets})
        out_data.update({"simcell": cell})
        out_data.update({"lscale": 1.0})

        if is_gro:
            from shapes.ioports import iogro
            writer = iogro.groFile(fname + ".gro", "w")
            writer.writeOutMols(out_data)
        else:
            from shapes.ioports import iopdb
            out_data.update({"lscale": 10.0})
            writer = iopdb.pdbFile(fname + ".pdb", "w")
            writer.writeOutMols(out_data)
    # end of write_config()

    # ref_is_pdb = fpath_ref.lower().endswith(".pdb")
    ref_is_gro = fpath_ref.lower().endswith(".gro")
    ref_cg_ext = ".gro" if ref_is_gro else ".pdb"

    scheme_keys = scheme.keys()
    scheme_vals = scheme.values()

    res_names = ["ALL"] 
    spc_names = ["ALL"]
    ctr_names = ["ALL"]

    cgobj = None
    cgtrj = False
    if "cgobj" in scheme_keys:
        cgobj = scheme["cgobj"]
    if cgobj:
        res_names = list(cgobj.mapper.get_all_residues())
        if "cgtrj" in scheme_keys:
            cgtrj = scheme["cgtrj"]
    elif "rnames" in scheme_keys:
        res_names = scheme["rnames"]

    bname = os.path.splitext(fpath_trj)[0]
    ref_cg_out = bname + '_aa2cg' + ref_cg_ext
    if cgobj and cgtrj:
        if fpath_out:
            ref_cg_out = os.path.splitext(fpath_out)[0] + ref_cg_ext

    if "snames" in scheme_keys:
        spc_names = scheme["snames"]
        if len(spc_names[0]) == 0:
            spc_names = ''
    else:
        spc_names = res_names.copy()

    ctr_names = res_names.copy() # AB: residues used for centering the system (if origin is specified)
    wname = ""
    wpars = None
    if "wname" in scheme_keys:
        wname = scheme["wname"]
        if "wpars" in scheme_keys:
            wpars = scheme["wpars"]
        if len(wname)>0 and wname not in res_names:
            res_names.append(wname) # AB: add water to the list of residues to be read in (to include in density analysis)
            if wpars and wpars["dmax"] < 1.0:
                # convert to Angstroms since CG-ing is done on original DCD coordinates
                wpars["dmax"] *= 10.0

    origin = Vec3()
    if "origin" in scheme_keys:
        origin = scheme["origin"]
        if isinstance(origin, list):
            origin = Vec3(*origin)
        if isinstance(origin, tuple):
            origin = Vec3(*list(origin))

    logger.info(f"Residues {res_names} to be read from {fpath_ref} for density analysis ...")
    logger.info(f"Residues {ctr_names} to be centred at {origin} as the overall 'system' ...")
    if len(spc_names) > 0 and spc_names != ["ALL"]:
        logger.info(f"Residues {spc_names} to be included in sub-cluster analysis ...")
    else:
        logger.info(f"No sub-cluster analysis to be performed ...")

    grid = None
    if "grid" in scheme_keys:
        grid = scheme["grid"]

    cls_ana  = False
    cls_out  = False
    cls_dmax = 1.5
    ana_dmax = 1.5
    if "dmax" in scheme_keys:
        cls_dmax = scheme["dmax"][0]
        ana_dmax = scheme["dmax"][-1]
        cls_out  = scheme["clsout"]
        if len(scheme["dmax"]) < 2 or len(spc_names) < 1 or spc_names == ["ALL"]:
            ana_dmax = 0.0
            cls_out  = False
            cls_ana  = False
        else:
            cls_ana = True
            logger.info(f"Will perform cluster analysis for solutes in '{spc_names}' "
                        f"with dmax = {ana_dmax} nm ...")

    den_error = False
    den_names = None
    if "dtypes" in scheme_keys:
        if (isinstance(scheme["dtypes"],tuple) or
            isinstance(scheme["dtypes"],list)):
            if scheme["dtypes"][0] is not None:
                den_names = scheme["dtypes"]
        if den_names:
            if scheme["zbin"] > TINY:
                logger.info(f"Will calculate Z-densities: {den_names} ...")
            else:
                logger.info(f"Will calculate R-densities: {den_names} ...")
            den_error = 'nerr' in den_names
            if den_error:
                den_names.pop(den_names.index('nerr'))

    frames = []
    histograms = []
    # clust_tot_nums = []
    clust_int_nums = []
    clust_ext_nums = []

    if fpath_trj.endswith(".dcd"):

        # AB: this is irrelevant for now
        # ref_out = os.path.splitext(fpath_out)[0] + '_ref' + ref_cg_ext
        # cgobj.coarse_grain_structure(fpath_ref, ref_out)

        dcd_inp = DCDTrajectory(fpath=fpath_trj,
                                fpath_ref=fpath_ref,
                                mode="r",
                                #res_names = spc_names,
                                res_names = res_names,
                                tryMassElems=True)
        is_bilayer = False
        areas = None
        zdims = None
        z_min = 0.0
        z_max = 0.0
        z_mid = 0.0
        z_bin = scheme["zbin"]
        n_bin = 0
        # if den_names and z_bin > TINY:
        if z_bin > TINY:
            is_bilayer = True
            logger.info(f"Will treat the system as planar bilayer ...")

            areas, zdims = zip(*[(frame.cell_params.a * frame.cell_params.b * 0.01,
                                  frame.cell_params.c * 0.1) for frame in dcd_inp.frames])
            # Total number of bins based on z_max and bin_size
            z_min = min(zdims)
            z_max = max(zdims)
            n_bin = int(z_max / z_bin)
            if n_bin & 1:  # % 2 > 0:
                n_bin += 1
            z_max = z_bin * float(n_bin)  # produce nice output!
            z_mid = z_max * 0.5

        mframes = len(dcd_inp.frames)
        nframes = 0
        for iframe, (cell_params, coordinates) in enumerate(dcd_inp):
            if ( iframe < scheme["ifirst"] or
                (iframe - scheme["ifirst"]) % scheme["frqncy"] != 0):
                continue
            nframes += 1
            stime = time()

            logger.info(f"Processing frame {iframe} for {len(res_names)} "
                        f"residues {res_names} ...")

            box_out = Vec3(cell_params.a, cell_params.b, cell_params.c)
            cg_molsys = None
            if cgobj:
                if cgtrj:
                    molsys = dcd_inp.update_molsys(dcd_inp.frames[iframe],
                                                   is_MolPBC=True)
                    cg_molsys = cgobj.create_cg_system(
                        molsets=molsys.items,
                        box=box_out,  # Vec3(*box_out[:3]),
                        wpars=wpars,
                    )
                    molsys = cg_molsys.copy()
                    # if iframe == 0:
                    #     print(f"Compare(0): {cg_molsys.items[0][0][0].getRvec()} =?= "
                    #           f"{molsys.items[0][0][0].getRvec()}")
                    molsys.refreshScaled(rscale=0.1)
                    # if iframe == 0:
                    #     print(f"Compare(1): {cg_molsys.items[0][0][0].getRvec()} =?= "
                    #           f"{molsys.items[0][0][0].getRvec()}")
                else:
                    molsys = dcd_inp.update_molsys(dcd_inp.frames[iframe],
                                                   is_MolPBC=True, lscale=0.1)
                    for mset in molsys.items:
                        if wname not in mset.name:
                            for mol in mset.items:
                                cgobj.set_cgmol_elems(mol)
            else:
                # AB: is_MolPBC=True puts whole molecules back into the primary cell
                molsys = dcd_inp.update_molsys(dcd_inp.frames[iframe],
                                               is_MolPBC=True, lscale=0.1)

            box_out *= 0.1  # convert to nm
            solutes  = MoleculeSet(sname="Solutes")
            solnames = ""
            clsnames = ""
            for mset in molsys.items:
                if (mset.name in spc_names or
                    "ALL" in spc_names or
                    "All" in spc_names or
                    "all" in spc_names):
                    logger.debug(f"Adding solute '{mset.name}' (from '{spc_names}') "
                                 f"to the list for sub-cluster analysis ...")
                    clsnames += f"_{mset.name}"
                if (mset.name in ctr_names or
                    "ALL" in ctr_names or
                    "All" in ctr_names or
                    "all" in ctr_names):
                    logger.debug(f"Adding solute '{mset.name}' (from '{ctr_names}') "
                                 f"to the list for cluster to be centered ...")
                    solnames += f"_{mset.name}"
                    for mol in mset:
                        solutes.addItem(mol)
            solutes.name = solnames[1:]
            if cls_ana and len(clsnames) < 1:
                logger.warning(f"No solutes from list {spc_names} found in the system! "
                                "- no sub-cluster analysis will be done ...")
                cls_ana = False

            if not cls_ana and not den_names:
                logger.error("Inconsistent input: "
                             "neither sub-cluster analysis "
                             "nor density calculations will be performed ...")
                raise ValueError("Inconsistent input: "
                                 "neither sub-cluster analysis "
                                 "nor density calculations will be performed ...")

            if origin:
                logger.info(f"Elapsed time before moving solutes '{solutes.name}' =?= {ctr_names} "
                            f"of length {len(solutes.items)} "
                            f"to the origin = {origin}: "
                            f"{sec2hms(time()-stime)}")
                sstime = time()
                rcom, rcog = solutes.getRvecs(isupdate=True,
                                              box=box_out,
                                              isMolPBC = is_bilayer,
                                              dmax=cls_dmax,  # nm
                                              nmax=15)
                logger.info(f"Solutes Rcom(0) = {rcom}, Rcog = {rcog}")
                shift = origin - rcom
                molsys.moveBy(shift)
                rcom, rcog = solutes.getRvecs(isupdate=True)
                logger.info(f"Solutes Rcom(1) = {rcom}, Rcog = {rcog}")
                logger.info(f"Elapsed time moving solutes "
                            f"to the origin = {origin}: "
                            f"{sec2hms(time()-sstime)}")

            if iframe == 0 or iframe == mframes-1:
                write_config(
                    fname=bname + '_frm' + str(iframe) + '_org',
                    molsets=molsys.items,
                    boxdims=box_out,
                    header=f"Frame {iframe} moved to origin {origin}",
                    is_gro=ref_is_gro,
                )

            logger.info(f"Elapsed time preparing for density calculations: "
                  f"{sec2hms(time()-stime)}")

            area = 0.0
            if den_names:
                if z_bin > TINY:
                    grid[0] =-z_mid
                    grid[1] = z_mid
                    grid[2] = z_bin
                    area = areas[iframe]

                # if wname:
                #     res_names.append("WCG")

                histograms.append(
                    molsys.Densities(
                        rorg = origin,
                        grid = grid,
                        clist = res_names,
                        dlist = den_names,
                        is_cg = (cgobj is not None),
                        xy_area = area
                        #bname=bname + '_frm-' + str(iframe),
                        #be_verbose=True,
                    )
                )

            # if ana_dmax > TINY:
            if cls_ana:
                clsnames = ""
                # clusters_tot = MoleculeSet(sname="CLS-TOT")
                clusters_int = MoleculeSet(sname="CLS-INT")
                clusters_ext = MoleculeSet(sname="CLS-EXT")
                for mset in molsys.items:
                    if (mset.name in spc_names or
                        "ALL" in spc_names or
                        "All" in spc_names or
                        "all" in spc_names):
                        clsnames += f"_{mset.name}"
                        for mol in mset:
                            # clusters_tot.addItem(mol)
                            if is_bilayer:
                                vec1_z = mol.items[0].getRvec()[2]
                                vec2_z = mol.items[-1].getRvec()[2]
                                if vec2_z - vec1_z > TINY:
                                    clusters_int.addItem(mol)
                                else:
                                    clusters_ext.addItem(mol)
                            else:
                                # vecBone = mol.getBoneRvec()
                                vec1bone = mol.items[mol.getBoneExt()].getRvec().norm()
                                vec2bone = mol.items[mol.getBoneInt()].getRvec().norm()
                                vec1_org = mol.items[0].getRvec().norm() 
                                vec2_org = mol.items[-1].getRvec().norm() 
                                vec1_org = (vec1_org + vec1bone)*0.5
                                vec2_org = (vec2_org + vec2bone)*0.5
                                if vec2_org - vec1_org > TINY:
                                    clusters_int.addItem(mol)
                                else:
                                    clusters_ext.addItem(mol)
                # clusters_tot.name = 'CLS-TOT' + clsnames
                clusters_int.name = 'CLS-INT' + clsnames
                clusters_ext.name = 'CLS-EXT' + clsnames

                # sstime = time()
                # rcom, rcog = clusters_tot.getRvecs(isupdate=True,
                #                             box=box_out,
                #                             dmax=ana_dmax,
                #                             nmax=15)
                # clust_tot_nums.append(clusters_tot.clustnum)
                #
                # logger.info(f"Clusters Rcom(1) = {rcom}, Rcog = {rcog}")
                # logger.info(f"Elapsed time for cluster analysis "
                #             f"of solute {clsnames}: "
                #             f"{sec2hms(time()-sstime)}")
                #
                # if clusters_tot.maxcluster and cls_out:
                #     nmax = len(clusters_tot.maxcluster)
                #     mmax = len(clusters_tot.maxcluster[0])
                #     write_config(
                #         fname = bname + '_dmax' + str(cls_dmax) + '-' + str(ana_dmax) \
                #                 + '_xcls_tot' + clsnames + '_frm' + str(iframe) \
                #                 + '_nxm' + str(nmax) + 'x' + str(mmax),
                #         molsets = clusters_tot.maxcluster,
                #         boxdims = box_out,
                #         header = f"Largest tot. clusters "
                #                     f"of size {len(clusters_tot.maxcluster[0])} "
                #                     f"in molset '{clsnames[1:]}'",
                #         is_gro = ref_is_gro,
                #     )

                logger.info(f"Cluster analysis for '{clusters_int.name}' ... ")

                sstime = time()
                rcom, rcog = clusters_int.getRvecs(isupdate=True,
                                                box=box_out,
                                                dmax=ana_dmax,
                                                nmax=15)
                clust_int_nums.append(clusters_int.clustnum)
                
                logger.info(f"Clust-int Rcom(1) = {rcom}, Rcog = {rcog}")
                logger.info(f"Elapsed time for cluster analysis "
                            f"of '{clusters_int.name}' : "
                            f"{sec2hms(time()-sstime)}")
                
                if clusters_int.maxcluster and cls_out:
                    nmax = len(clusters_int.maxcluster)
                    mmax = len(clusters_int.maxcluster[0])
                    write_config(
                        fname = bname + '_dmax' + str(cls_dmax) + '-' + str(ana_dmax) \
                                + '_xcls_int' + clsnames + '_frm' + str(iframe) \
                                + '_nxm' + str(nmax) + 'x' + str(mmax),
                        molsets = clusters_int.maxcluster,
                        boxdims = box_out,
                        header = f"Largest int. clusters "
                                    f"of size {len(clusters_int.maxcluster[0]) } "
                                    f"in molset '{clsnames[1:]}'",
                        is_gro = ref_is_gro,
                    )

                logger.info(f"Cluster analysis for '{clusters_ext.name}' ... ")

                sstime = time()
                rcom, rcog = clusters_ext.getRvecs(isupdate=True,
                                            box=box_out,
                                            dmax=ana_dmax,
                                            nmax=15)
                clust_ext_nums.append(clusters_ext.clustnum)
                
                logger.info(f"Clust-ext Rcom(1) = {rcom}, Rcog = {rcog}")
                logger.info(f"Elapsed time for cluster analysis "
                            f"of '{clusters_ext.name}' : "
                            f"{sec2hms(time()-sstime)}")
                
                if clusters_ext.maxcluster and cls_out:
                    nmax = len(clusters_ext.maxcluster)
                    mmax = len(clusters_ext.maxcluster[0])
                    write_config(
                        fname = bname + '_dmax' + str(cls_dmax) + '-' + str(ana_dmax) \
                                + '_xcls_ext' + clsnames + '_frm' + str(iframe) \
                                + '_nxm' + str(nmax) + 'x' + str(mmax),
                        molsets = clusters_ext.maxcluster,
                        boxdims = box_out,
                        header = f"Largest ext. clusters "
                                    f"of size {len(clusters_ext.maxcluster[0]) } "
                                    f"in molset '{clsnames[1:]}'",
                        is_gro = ref_is_gro,
                    )

            if cgtrj:
                if iframe == 0:
                    #cell = dcd_inp.frames[iframe].cell_params
                    #cell = cell_params
                    # Write initial structure
                    out_is_gro = ref_cg_out.endswith(".gro")
                    if out_is_gro:
                        #cgobj._write_output(cg_molsys, box_out, ref_cg_out, 0.1)
                        cgobj._write_output(cg_molsys, cell_params, ref_cg_out, 0.1)
                    else:
                        #cgobj._write_output(cg_molsys, box_out, ref_cg_out, 1.0)
                        cgobj._write_output(cg_molsys, cell_params, ref_cg_out, 1.0)

                frame = cgobj._create_frame(cg_molsys, cell_params)
                frames.append(frame)

            logger.debug(f"Total time working on the frame: "
                         f"{sec2hms(time()-stime)}")

        if cgtrj:
            if not frames:
                raise RuntimeError("No frames processed - check input trajectory file")

            dcd_out = DCDTrajectory(fpath=fpath_out, mode="w")
            dcd_out.write(frames)
            dcd_out.close()

        # if len(clust_tot_nums) > 0:
        #     save_cluster_stats(clust_tot_nums, bname, clsnames[1:], 'tot' + clsnames, nframes)

        if len(clust_int_nums) > 0:
            bname_hcls = bname + '_dmax' + str(cls_dmax) + '-' + str(ana_dmax)
            save_cluster_stats(clust_int_nums, bname_hcls, clsnames[1:], 'int' + clsnames, nframes)

        if len(clust_ext_nums) > 0:
            bname_hcls = bname + '_dmax' + str(cls_dmax) + '-' + str(ana_dmax)
            save_cluster_stats(clust_ext_nums, bname_hcls, clsnames[1:], 'ext' + clsnames, nframes)

        if den_names and len(histograms) > 0:
            save_histograms(histograms, grid, bname, den_error)
            dcd_inp.save_cell_evolution(bname + '_cell_evol.dat')

        dcd_inp.close()

    else:
        raise ValueError("Unsupported trajectory format (not a .dcd trajectory)!")
# end of ana_traj()

# def list_of_strings(arg: str) -> list[str] or None:
#     from re import sub as re_sub
#     split = re_sub(r"[\[\]\(\)]", "", arg.strip()).split(",")
#     value = None
#     if len(split) > 0:
#         value = [var.strip() for var in split]
#     elif isinstance(arg, str):
#         value = [arg]
#     return value

# def list_of_floats(arg: str) -> list[float]:
#     return [float(x) for x in InputParser.list_of_strings(arg)]

def main(argv: list[str]=sys.argv):
    """
    Main function to handle command-line arguments and execute coarse-graining.
    """

    log_file = "ana-trajectory.log"
    logger = LogConfiguration(file_name=log_file).logger

    #LogConfiguration(level=logging.INFO, logger=logger)
    #logger = LogConfiguration(level=logging.INFO, file_name="ana-trajectory.log").logger

    sname = os.path.basename(argv[0])

    if len(argv) - 1 < 1:
        # AB: print help page if no arguments are given
        argv.append('-h')

    tb = beauty()

    parser = argparse.ArgumentParser(
        prog=sname,
        usage=tb.BOLD
              + sname
              + " [-v] -i <INP> -r <REF> [-o <OUT>] -d <DNAMES> [--snames <SNAMES>] [--rnames <SNAMES>] [extra options]"
              + tb.END,
        description="Calculate densities for an atomistic or coarse-grain "
                    "molecular system",
        epilog="End of help (nothing done)",
    )

    parser.add_argument(
        "-v", "--verbose", action="store_true",
        help="Enable verbose output for debugging"
    )

    parser.add_argument(
        "-i", "--inp",
        help="Path to the input trajectory file (*.dcd)"
    )
    parser.add_argument(
        "-r", "--ref",
        help="Path to the reference structure file (*.gro|*.pdb) "
             "if coarse-graining input trajectory (option --cg)"
    )
    parser.add_argument(
        "-o", "--out",
        help="Path to the output CG trajectory file (*.dcd)",
    )
    parser.add_argument(
        "-b", "--begin", default=0,
        help="Index of first frame to take from trajectory {0*}"
    )
    parser.add_argument(
        "-q", "--freq", default=1,
        help="Frequency of frames taken from trajectory (stride) {1*}"
    )
    # AB: no scope for this yet
    # parser.add_argument(
    #     "-a", "--anames", default="",
    #     help="List of density types"
    # )
    parser.add_argument(
        "-d", "--dtypes", # default="",
        help="List of density types {hist,nden,mden,nsld; 'mden,nsld'*}; if skipped, no density calculations are performed."
    )
    parser.add_argument(
        "--rnames", default="",
        help="List of solute residues to read from trajectory and include in density analysis {*}.\n" + \
             "Use '--wname' option to add water for density analysis.\n" + \
             "In the latter case only the list of solutes is used for centering the system at the origin."
    )
    parser.add_argument(
        "-s", "--snames", default="",
        help="List of solute residues to include in sub-cluster analysis {*} (only used if `--dmax` specifies two values)."
    )
    parser.add_argument(
        "--dmax", default=1.5, # default="",
        help="Max distance (nm) for global neighbour/cluster search used for centering the system at the origin {1.5*}. " + \
             "Giving two values (e.g. '1.6,0.6' or '[1.6,0.6]') invokes sub-cluster analysis for residues from '--snames' list."
    )
    parser.add_argument(
        "--clustout", action="store_true",
        help="Flag to output configurations for largest internal and external clusters (only used if `--dmax` specifies two values)."
    )
    parser.add_argument(
        "-z", "--zbin", default=-1.0,  #, action="store_true",
        help="Z-bin size {-1*}, if greater than zero then Z-densities are calculated"
    )
    parser.add_argument(
        "-g", "--grid", default=None,
        help="List of floats for R-grid: [min,max,bin] {*}"
    )
    parser.add_argument(
        "--origin", # default="",
        help="List of floats for origin: [X_o,Y_o,Z_o] {[0.,0.,0.]*}"
    )
    parser.add_argument(
        "-c", "--cg", action="store_true",
        help="Flag to turn coarse-graining on"
    )
    parser.add_argument(
        "-m", "--map",
        help="Path to .map AA-CG mapping file"
    )
    parser.add_argument(
        "-t", "--itp",
        help="Path to .itp topology file (requires --map)"
    )
    parser.add_argument(
        "-j", "--json",
        help="Path to .json AA-CG mapping file"
    )
    parser.add_argument(
        "-w", "--wname", default="",
        help="Water residue name {*}"
    )
    parser.add_argument(
        "-p", "--wnmap", default=4,
        help="Number of water molecules per CG bead {4*}"
    )
    parser.add_argument(
        "-n", "--wnmax", default=8,
        help="Max number of molecules for water neighbour search {8*}"
    )
    parser.add_argument(
        "--wdmax", default=0.47, #default=4.7,
        help="Max distance (nm) for water neighbour search {0.47*}"
    )

    args = parser.parse_args()

    log_config = LogConfiguration()
    if args.verbose:
        log_config.set_console_level(logging.WARNING)
        log_config.set_file_level(logging.DEBUG)
        # log_config.set_debug_formatting_for_files() # AB: uncomment to convert INFO into DEBUG
        logger.info("Verbose mode is ON (DEBUG level)")
    else:
        log_config.set_console_level(logging.ERROR)
        log_config.set_file_level(logging.INFO)
        logger.info("Verbose mode is OFF (INFO level)")

    # if args.verbose:
    #     logger = LogConfiguration(level=logging.DEBUG).logger
    #     #LogConfiguration(level=logging.DEBUG, logger=logger)
    #     logger.debug("Verbose (debug) output\n")
    #     print(f"\n Verbose (debug) output enabled.\n")
    # else:
    #     logger = LogConfiguration(level=logging.INFO).logger
    #     #LogConfiguration(level=logging.INFO, logger=logger)
    #     logger.info("Standard (info) output\n")
    #     print(f"\n Standard (info) output enabled.\n")

    if not args.inp or not args.ref:
        sys.exit(f"\nYou need to provide both input and reference structure files - "
                 f"use option '-h' for more details.\n")
    else:
        if args.inp and not args.inp[-4:] == ".dcd":
            sys.exit(f"\nInput file name must end with '.dcd' - "
                     f"use option '-h' for more details.\n")
        if args.ref and not args.ref[-4:] in {".gro", ".pdb"}:
            sys.exit(f"\nReference file name must end with '.gro' or '.pdb' - "
                     f"use option '-h' for more details.\n")

    if args.out and not args.out[-4:] == ".dcd":
        sys.exit(f"\nOutput file name must end with '.dcd' - "
                 f"use option '-h' for more details.\n")

    # if not args.dtypes:
    #     sys.exit(f"\nYou need to provide a list of density types from [mden,nden,nsld, hist] - "
    #              f"use option '-h' for more details.\n")

    if not args.rnames:
        sys.exit(f"\nYou need to provide a list of residues names - "
                 f"use option '-h' for more details.\n")
    logger.info(f"Specified residue names: {args.rnames}")

    if args.cg:
        if not args.json and not args.map:
            sys.exit(f"\nNeed to provide either .json file or .map file - "
                     f"use option '-h' for more details.\n")

        if args.json and (args.map or args.itp):
            raise Exception("\nERROR: You cannot provide both .json file "
                            "and .map files.")

        if args.itp and not args.map:
            raise Exception("\nERROR: You must provide either .map file "
                            "to be able to use .itp file.")

        if args.map and not args.itp:
            logger.warning("Only .map file provided - "
                  "bonds and angles details will be omitted.")

    dmax_inp = [1.5]
    if args.dmax:
        if isinstance(args.dmax,float):
            dmax_inp = [args.dmax]
        else:
            dmax_inp = InputParser.list_of_floats(args.dmax)
        
        if len(args.snames) < 1: 
            if len(dmax_inp) > 1:
                logger.warning(f"Two values in option `--dmax {dmax_inp}` "
                    f"while no solutes for sub-cluster search specified! "
                    f"{NL_INDENT}Using only the first value - for global cluster search ...")
                dmax_inp = [dmax_inp[0]]
        elif len(dmax_inp) == 1:
            raise Exception(f"\nERROR: Single dmax value {dmax_inp} (must be two values) "
                            f"when using option `--snames {args.snames}`!")

        for dmax in dmax_inp:
            if float(dmax) < 0.1:
                raise Exception("\nERROR: dmax cannot be set < 0.1 nm (1.0 A)")
            if float(dmax) > 3.0:
                raise Exception("\nERROR: dmax cannot be set > 3.0 nm (30.0 A)")
    if len(dmax_inp) > 2:
        raise Exception("\nERROR: dmax must be a single value or a pair of values!")

    wname = ""
    wpars = None
    if args.wname:
        wname = InputParser.list_of_strings(args.wname)
        #wname = list_of_strings(args.wname)
        #wname = str(args.wname)
        if args.cg and args.wnmap:
            if int(args.wnmap) > 6 or int(args.wnmap) < 2:
                raise Exception("\nERROR: wnmap must be in the interval [2,6]")
            if float(args.wdmax) < 0.25:
                raise Exception("\nERROR: wdmax cannot be set < 0.25 nm (2.5 A)")
            #if float(args.wdmax) > 6.0:
            if float(args.wdmax) > 0.6:
                raise Exception("\nERROR: wdmax cannot be set > 0.6 nm (6.0 A)")
            # wpars = {"name": str(args.wname),
            wpars = {"name": wname,  # InputParser.list_of_strings(args.wname),
                     "nmap": int(args.wnmap),
                     "nmax": int(args.wnmax),
                     "dmax": float(args.wdmax),
                    }
            logger.info(f"Extra options for CG water:{NL_INDENT}{wpars}")
                 # f" is_cg = {args.cg} / is_wnmap = {args.wnmap}")

    # Initialise CoarseGrainer
    cg = None
    if args.cg:
        if args.json:
            cg = CoarseGrainer(args.json)
        elif args.map:
            if args.itp:
                cg = CoarseGrainer(args.map, args.itp)
            else:
                cg = CoarseGrainer(args.map)
        if not cg:
            raise Exception("Failed to create CoarseGrainer object!")

    origin = None
    if args.origin is not None:
        origin = InputParser.list_of_floats(args.origin)
    else:
        origin = [0.,0.,0.]

    grid = None
    dtypes = None,
    if not args.dtypes:
        logger.info(f"No density types specified: {dtypes} - "
                    f"skipping density calculation ...")
        args.grid = None
    else:
        dtypes = InputParser.list_of_strings(args.dtypes)
        logger.info(f"Specified density types: {dtypes}")

        if float(args.zbin) > TINY:
            grid = ['-zmid', '+zmid', args.zbin]
            logger.info(f"Will use Z-grid: {grid} (nm)")
        elif args.grid:
            grid = InputParser.list_of_floats(args.grid)
            if grid[0] > grid[1]:
                grid1   = grid[0]
                grid[0] = grid[1]
                grid[1] = grid1
            logger.info(f"Will use R-grid: {grid} (nm)")
        elif dtypes:
            raise ValueError(f"\n{sname}:: "
                             f"Need to specify --grid or --zbin "
                             f"for density calculation!")

    schema = dict(
        ifirst = int(args.begin),
        frqncy = int(args.freq),
        dtypes = dtypes,
        rnames = InputParser.list_of_strings(args.rnames),
        snames = InputParser.list_of_strings(args.snames),
        dmax   = dmax_inp,
        clsout = args.clustout,
        origin = origin,
        grid  = grid,
        zbin  = float(args.zbin),
        wname = wname[0] if isinstance(wname, list) and len(wname) > 0 else wname,
        cgobj = cg,
        wpars = wpars,
        cgtrj = (args.out is not None),
    )

    # is_conf = ( Path(args.inp).suffix.lower() in ['.gro', '.pdb'] and
    #             Path(args.out).suffix.lower() in ['.gro', '.pdb'] )
    # is_traj = ( Path(args.inp).suffix.lower() == '.dcd' and
    #             Path(args.out).suffix.lower() == '.dcd' )

    is_conf = Path(args.inp).suffix.lower() in ['.gro', '.pdb']
    is_traj = Path(args.inp).suffix.lower() == '.dcd'

    if is_conf:
        raise Exception("Densities for single structure (.gro/.pdb) not supported!")
    elif is_traj:
        if args.ref:
            if Path(args.ref).suffix.lower() in ['.gro', '.pdb']:
                ana_traj(
                    fpath_ref=args.ref,
                    fpath_trj=args.inp,
                    fpath_out=args.out,
                    scheme=schema,
                )
            else:
                raise Exception(f"Unsupported reference structure file name: "
                                f"{args.ref}!")
        else:
            raise Exception(f"Please provide reference structure file name!"
                            f"{args.ref}!")
    else:
        raise Exception("One cannot coarse-grain structure into trajectory, "
                        "nor vice versa!")
# end of main()


if __name__ == "__main__":
   main()
   sys.exit(0)

# if __name__ == "__main__":
#     # main()
#     try:
#         main(sys.argv)
#     except Exception as e:
#         raise Exception(f"Could not execute '{sys.argv}'")
#         sys.exit(2)
