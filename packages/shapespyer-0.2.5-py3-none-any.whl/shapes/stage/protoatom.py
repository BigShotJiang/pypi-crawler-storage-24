"""
.. module:: protoatom
       :platform: Linux - tested, Windows [WSL Ubuntu] - tested
       :synopsis: contributes to the hierarchy of classes:
        Atom > AtomSet > Molecule > MoleculeSet > MolecularSystem

.. moduleauthor:: Dr Andrey Brukhno <andrey.brukhno[@]stfc.ac.uk>

The module contains class Atom(object)
"""

# This software is provided under The Modified BSD-3-Clause License (Consistent with Python 3 licenses).
# Refer to and abide by the Copyright detailed in LICENSE file found in the root directory of the library!

##################################################
#                                                #
#  Shapespyer - soft matter structure generator  #
#                                                #
#  Author: Dr Andrey Brukhno (c) 2020 - 2025     #
#          Daresbury Laboratory, SCD, STFC/UKRI  #
#                                                #
##################################################

##from __future__ import absolute_import
__author__ = "Andrey Brukhno"

#from math import sqrt, sin, cos #, acos
#from numpy import array, dot, sum #, cross, random, double
#from numpy.linalg import norm

import logging

from shapes.basics.functions import pbc #, pbc_rect, pbc_cube
from shapes.basics.mendeleyev import Chemistry
from shapes.stage.protovector import Vec3

logger = logging.getLogger("__main__")


class Atom(object):
    """
    Class **Atom** - defines attributes and methods of `atom` objects
    """

    def __init__(self,
                 aname : str = 'none',
                 atype : str = 'none',
                 amass : float = 1.0,
                 achrg : float = 0.0,
                 aindx : int = -1,
                 arvec : Vec3 = None,
                 verbose: bool = False
                 ) -> None:
        """
        Initialize an instance of :class:`Atom`.

        This method constructs an instance of :class:`Atom` 
        with the following initially set attributes.

        Parameters
        ----------
        aname : str
                Atom name - to appear in configuration file(s) 
                (default 'none').
        atype : str
                Atom type - to appear in topology file(s) 
                (default 'none').
        amass : float
                Atom mass {1 a.u.} - set by look up 
                in either periodic table or topology file(s)
        achrg : float
                Atom electrical charge {0 e} - set by look up 
                in either periodic table or topology file(s)
        aindx : int
                Atom index in AtomSet or :class:`Molecule` 
                object it belongs to.
        arvec : Vec3(x, y, z)
                3-vector with atom Cartesian coordinates
        verbose : bool
                Flag to toggle output verbosity 
                (for debugging purposes)
        """
        self.name = aname
        self.type = atype
        self.mass = amass
        self.chrg = achrg
        self.indx = aindx
        self.rvec = None
        self.setRvec(arvec, verbose)
        self.elem = None
        self.ecsl = 0.0
        self.isMassElem = False
        self.isElemCSL  = False

    def __del__(self):
        del self.rvec

    def __repr__(self):
        return '{self.__class__.__name__} => {{ index: {self.indx}, name: \'{self.name}\', type: \'{self.type}\', '\
               'mass: {self.mass}, charge: {self.chrg};\n rvec: {self.rvec} }}'.format(self=self)

    def copy(self):
        """
        Create a duplicate of the current atom.

        The returned object is a deep copy: all scalar attributes are
        reproduced and the position vector is copied.  Any element
        assignments or CSL values are also transferred.

        Returns
        -------
        Atom
            A new :class:`Atom` instance with identical properties.
        """
        new_atom = Atom(self.name, self.type,
                        self.mass, self.chrg,
                        self.indx, self.rvec.copy())
        new_atom.isMassElem = self.isMassElem
        if self.getElems():
            new_atom.elem = []
            for elem in self.elem:
                new_atom.elem.append(elem)
            if self.isElemCSL:
                new_atom.isElemCSL = True
                new_atom.ecsl = self.ecsl
        return new_atom

    def setIndex(self, aindx: int) -> None:
        """
        Set the numerical index of the atom within a container.

        Parameters
        ----------
        aindx : int
            New index value.
        """
        self.indx = aindx

    def getIndex(self) -> int:
        """
        Return the atom's current index.

        Returns
        -------
        int
            Index assigned to this atom instance.
        """
        return self.indx

    def setName(self, aname: str) -> None:
        """
        Assign a new name string to the atom.

        Parameters
        ----------
        aname : str
            Name to use for the atom (e.g. 'C1', 'H').
        """
        self.name = aname

    def getName(self) -> str:
        """
        Retrieve the atom's name.

        Returns
        -------
        str
            Name previously set for this atom.
        """
        return self.name

    def setType(self, atype: str) -> None:
        """
        Set the chemical type of the atom.

        Parameters
        ----------
        atype : str
            Type identifier used in topology files (e.g. 'C', 'O').
        """
        self.type = atype

    def getType(self) -> str:
        """
        Return the atom's chemical type string.

        Returns
        -------
        str
            Current type identifier.
        """
        return self.type

    def setElems(self, anames: list[str] | tuple[str] = None ) -> bool:
        """
        Assign element symbols to the atom and resolve periodic-table data.

        If ``anames`` is provided, each name is looked up via
        :func:`Chemistry.getElement`.  When ``anames`` is omitted the atom's
        current name is used.  The resulting element objects are stored in
        ``self.elem``.  Failure to resolve any name cancels the assignment.

        Parameters
        ----------
        anames : list[str] or tuple[str], optional
            Sequence of element name strings (e.g. ['C', 'H']).

        Returns
        -------
        bool
            ``True`` if all requested elements were resolved successfully,
            ``False`` otherwise.
        """
        if anames:
            self.elem = []
            for aname in anames:
                elem = Chemistry.getElement(aname[:2])
                if not elem:
                    self.elem = None
                    return False
                self.elem.append(elem)
            if len(self.elem) != len(anames):
                self.elem = None
                return False
        else:
            elem = Chemistry.getElement(self.name[:2])
            if elem:
                self.elem = [elem]
            else:
                self.elem = None
        return (self.elem is not None)

    def getElems(self) -> list:
        """
        Retrieve the list of element objects associated with this atom.

        Returns
        -------
        list
            List of element records, or ``None`` if not assigned.
        """
        return self.elem

    def setElemCSL(self, weights: list | tuple = None) -> bool:
        """
        Compute a CSL weight for the atom's elements.

        The CSL value is the weighted sum of element-specific constants
        stored in ``Chemistry.ecsl``.  If ``weights`` is not supplied each
        element is given equal weight.  The computed value is stored in
        ``self.ecsl`` and ``self.isElemCSL`` is toggled accordingly.

        Parameters
        ----------
        weights : list or tuple, optional
            Multipliers for each element; length must match ``self.elem``.
            Defaults to equal weighting.

        Returns
        -------
        bool
            ``True`` if a CSL value was successfully computed, 
            ``False`` otherwise.
        """
        self.isElemCSL = False
        if self.elem:
            if weights is None:
                weights = [1.0]*len(self.elem)
            self.ecsl = 0.0
            nset = 0
            for ie, elem in enumerate(self.elem):
                if elem in Chemistry.ecsl.keys():
                    self.ecsl += Chemistry.ecsl[elem] * weights[ie]
                    nset += 1
                else:
                    self.ecsl = 0.0
                    break
            self.isElemCSL = (self.ecsl != 0.0)
        if self.elem is None:
            elem = Chemistry.getElement(self.name[:2])
            if elem: # in Chemistry.ecsl.keys():
                self.elem = [elem]
                self.ecsl = Chemistry.ecsl[elem]
                self.isElemCSL = ( self.ecsl != 0.0 )
            else:
                self.ecsl = 0.0
        return self.isElemCSL

    def getElemCSL(self) -> float:
        """
        Return the atom's CSL constant.

        Returns
        -------
        float
            CSL value previously computed (0.0 if unset).
        """
        return self.ecsl

    def setMassElem(self) -> bool:
        """
        Attempts to assign atom masse from the periodic table (see module mendeleyev.Chemistry).
        If atom is not found in the periodic table (by the first one or two letters of its name),
        the atom mass remains the same, as it was prior to the call.

        Returns
        -------
        ``True``  - if the atom mass has been successfully (re-)set to the corresponding element's mass
        ``False`` - otherwise
        """
        # TODO: similar method for setting atom mass from topology / force-field
        atype = self.name
        if len(atype) > 1:
            atype = atype[0:2].capitalize()
            if atype not in Chemistry.etypes:
                atype = atype[0]
        self.isMassElem = False
        if atype in Chemistry.etypes:
            self.mass = Chemistry.etable[atype]['mau']
            self.isMassElem = True
        return self.isMassElem

    def setMass(self, amass: float) -> None:
        """
        Assign mass value to the atom.

        Parameters
        ----------
        amass : float
            Mass value in atomic mass units.
        """
        self.mass = amass

    def getMass(self) -> float:
        """
        Retrieve the atom's mass.

        Returns
        -------
        float
            Current mass in atomic units.
        """
        return self.mass

    def setCharge(self, achrg: float) -> None:
        """
        Set the electrical charge of the atom.

        Parameters
        ----------
        achrg : float
            Charge value in elementary charge units.
        """
        self.chrg = achrg

    def getCharge(self) -> float:
        """
        Obtain the atom's electric charge.

        Returns
        -------
        float
            Charge value in elementary charges.
        """
        return self.chrg

    # def setRvec(self, arvec: list * 3):
    #    self.rvec = Vec3(arvec[0], arvec[1], arvec[2])

    def setRvec(self, arvec=None, verbose: bool = False) -> None:
        """
        Assign a Cartesian position vector to the atom.

        Parameters
        ----------
        arvec : Vec3 or sequence, optional
            Vector to assign; may be a :class:`Vec3` or a length-3 iterable.
            If ``None`` the existing vector is left unchanged.
        verbose : bool, optional
            If True, log warning when assignment is skipped.
        """
        if arvec is not None:
            if isinstance(arvec,Vec3):
                self.rvec = arvec.copy()
            elif isinstance(arvec,list) and len(arvec) == 3:
                self.rvec = Vec3(*arvec)
            else:
                try:
                    iterator = iter(arvec)
                except TypeError:
                    logger.warning("Attempted to assign rvec='scalar' to atom - "
                                   "skipped!")
                else:
                    logger.info(f"Attempted to assign rvec=[]*{len(arvec)} to atom - "
                                f"use list [float, float, float] or Vec3(float, float, "
                                "float)")
        if verbose:
            logger.debug(f"Attempted to assign rvec=None "
                        f"to atom '{self.name}' - skipped!")

    def getRvec(self, verbose: bool = False) -> Vec3:
        """
        Return the atom's current position vector.

        Parameters
        ----------
        verbose : bool, optional
            If True, emit an informational message when the vector is unset.

        Returns
        -------
        Vec3
            The stored position vector (may be ``None``).
        """
        if self.rvec is None:
            logger.info("position vector not set yet - skipped!")
        return self.rvec

    def getRvecPBC(self, box: Vec3 = Vec3(1.0, 1.0, 1.0)) -> Vec3:
        """
        Return the position vector wrapped inside periodic boundaries.

        Parameters
        ----------
        box : Vec3, optional
            Dimensions of the periodic box. Defaults to unit cube.

        Returns
        -------
        Vec3
            Position vector modified by periodic boundary conditions.
        """
        return pbc(self.getRvec().copy(), box)

# end of class Atom
