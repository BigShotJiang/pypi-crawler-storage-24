"""
.. module:: protoatomset
       :platform: Linux - tested, Windows [WSL Ubuntu] - tested
       :synopsis: contributes to the hierarchy of classes:
        Atom > AtomSet > Molecule > MoleculeSet > MolecularSystem

.. moduleauthor:: Dr Andrey Brukhno <andrey.brukhno[@]stfc.ac.uk>

The module contains class AtomSet(Atom)
"""

# This software is provided under The Modified BSD-3-Clause License (Consistent with Python 3 licenses).
# Refer to and abide by the Copyright detailed in LICENSE file found in the root directory of the library!

##################################################
#                                                #
#  Shapespyer - soft matter structure generator  #
#                                                #
#  Author: Dr Andrey Brukhno (c) 2020 - 2025     #
#          Daresbury Laboratory, SCD, STFC/UKRI  #
#                                                #
##################################################

##from __future__ import absolute_import
__author__ = "Andrey Brukhno"


import logging

from shapes.basics.defaults import NL_INDENT
from shapes.basics.functions import pbc
from shapes.stage.protovector import Vec3
from shapes.stage.protoatom import Atom

logger = logging.getLogger("__main__")


class AtomSet(Atom):
    """
    Class **AtomSet** - defines attributes and methods for an `atom set` object.
    It extends :class:`Atom` by providing an iterable collection (list) of atoms,
    each with its own properties.

    **AtomSet** is also a *parent* class for :class:`Molecule` (see below).
    In contrast to Molecule, AtomSet does not assume any internal structure
    or bonding between atoms, so no intrinsic geometrical topology can be
    imposed within an AtomSet object.
    """
    def __init__(self,
                 aname  : str   = 'empty',
                 atype  : str   = 'empty',
                 amass  : float = 0.0,
                 achrg  : float = 0.0,
                 nitems : int   = 0,
                 atoms  : list  = None,
                 arvecs : list  = None,
                 aindx  : int   = -1,
                 isupdate: bool = False,
                 verbose : bool = False,
                 ) -> None:
        """
        Initialize an instance of :class:`AtomSet`.

        This method sets up :class:`AtomSet` by extending :class:`Atom` 
        to a collectioon of unconnected atoms, possibly of the same type.

        Most of the AtomSet attributes extend the :class:`Atom` attributes 
        appropriately 'promoted', e.g. by summation over all the atoms present 
        (see `mass`, `charge`, `rvec`).

        **NOTE 1:** AtomSet object can be initiated in four different scenarios:

        1) with a single atom (`atoms` = `Atom`), then `nitems` -> 1 (i.e. reset to 1),
        more atoms can be added and their positions (re-)set later on. In this case
        the created AtomSet object and all atom objects added to it can have distinct attributes.

        2) with a list of atoms (`atoms` = [`Atom`, `Atom`, ...],
        then `nitems` -> len(`atoms`)). In this case the created AtomSet object and all atom objects
        added to it can have distinct attributes.

        3) with a list of atom positions (`arvecs` = [`Vec3`, `Vec3`, ...] and `atoms = None`),
        then `nitems` -> len(`arvecs`) and all initially populated atoms will have the same attributes
        (i.e. `aname`, `atype`, `amass` and `achrg` as in the AtomSet initialisation call);
        more atoms can be added later on.

        4) if `atoms` = `None` and `arvecs` = `None`, while `nitems` > 0, then
        all initially populated atoms will have the same attributes (i.e. `aname`, `atype`,
        `amass` and `achrg` as in the AtomSet initialisation call); more atoms can be added
        and their positions (re-)set later on.

        **NOTE 2:** AtomSet *rvec* is equivalent to its center of mass (COM),
        see **getRvec()** and **getRcom()** methods, whereas *rcog* is the center
        of geometry (COG) which is equivalent to COM with masses of all atoms set
        to unity, see **getRcog()** and **getRvecs()** methods.

        Parameters
        ----------
        aname : str
                atom (set) name - *either* atom name 
                for the entire set *or* equivalent to 
                `resname` / `molname` for Molecule.
        atype : str
                atom (set) type - *either* atom type 
                for the entire set *or* equivalent to 
                `restype` / `moltype` for Molecule.
        amass : float
                atom set mass (a.u.) - sum of atom masses.
        achrg : float
                atom electrical charge (e) - sum of atom charges.
        nitems: int
                number of atoms to populate with the same attributes 
                (`atoms = None` and `arvecs = None`).
        atoms : list / Atom
                either list of Atom objects or a single Atom object 
                (then `nitems` -> `len(atoms)` or 1).
        arvecs : list
                list of *Vec3* objects holding atoms' Cartesian coordinates 
                (`atoms = None`, then `nitems` -> `len(arvecs)`).
        aindx : int
                atom set index in a higher level molecular (sub-) set 
                or system it belongs to.
        verbose : bool
                flag to toggle output verbosity 
                (for debugging purposes).
        """
        self.name = aname
        self.type = atype
        self.mass = amass
        self.chrg = achrg
        self.indx = aindx
        self.rvec = None
        self.rcog = None
        self.items = []
        self.nitems = 0
        self.isMassElems = False

        if atoms is not None:
            try:
                iterator = iter(atoms)
            except TypeError:  # non-iterable => add just one atom if it qualifies
                if isinstance(atoms, Atom):
                    self.items.append(atoms.copy())
            else:
                if isinstance(atoms[0], Atom):
                    for i in range(len(atoms)):
                        self.items.append(atoms[i].copy())
        elif arvecs is not None:
            if isinstance(arvecs, Vec3) or ( isinstance(arvecs, list) and
                len(arvecs)==3 and isinstance(arvecs[0], float) ):  # add just one atom if arvecs qualifies
                    self.items.append(Atom(aname, atype, amass, achrg, aindx=0,
                                           arvec=arvecs, verbose=verbose))
            elif isinstance(arvecs, list) and ( isinstance(arvecs[0], Vec3) or
                (isinstance(arvecs[0], list) and len(arvecs[0])==3 and
                 isinstance(arvecs[0][0], float)) ):
                    if nitems > len(arvecs) : nitems = len(arvecs)
                    for i in range(nitems):  # create a set of same atoms at different positions
                        self.items.append(Atom(aname, atype, amass, achrg, aindx=i,
                                               arvec=arvecs[i], verbose=verbose))
        else:  # create a set of same atoms with unspecified positions
            for i in range(nitems):
                self.items.append(Atom(aname, atype, amass, achrg, aindx=i, verbose=verbose))
        self.nitems = len(self.items)
        self.rvec = Vec3()
        self.rcog = Vec3()
        if isupdate:
            self.refresh()
        super(AtomSet, self).__init__(self.name, self.type, self.mass, self.chrg, aindx=0,
                                      arvec=self.rvec, verbose=verbose)
        # rcog = Vec3()
        # rcom = Vec3()
        # mass = 0.0
        # chrg = 0.0
        # ntot = 0
        # for i in range(self.nitems):
        #     if isinstance(self.items[i].getRvec(), Vec3):
        #         rcog += self.items[i].getRvec()
        #         rcom += self.items[i].getRvec() * self.items[i].getMass()
        #         mass += self.items[i].getMass()
        #         chrg += self.items[i].getCharge()
        #         ntot += 1
        #     elif verbose:
        #         print(f"{self.__class__.__name__}('{aname}', '{atype}'): "
        #               f"atom '{self.items[i].name}' "
        #               f"with undefined 'rvec' does not contribute to totals!")
        # if ntot < self.nitems and verbose:
        #     print(f"{self.__class__.__name__}('{aname}', '{atype}'): "
        #           f"{self.nitems-ntot} atoms incomplete and do not contribute totals!")
        # if ntot > 0:
        #     rcog /= float(ntot)
        # if mass > 0.0:
        #     rcom /= mass
        # elif verbose:
        #     print(f"{self.__class__.__name__}('{aname}', '{atype}'): "
        #           f"atom masses sum up to zero!")
        # super(AtomSet, self).__init__(self.name, self.type, self.mass, self.chrg, aindx=0,
        #                               arvec=self.rvec, verbose=verbose)
        # self.mass = mass
        # self.chrg = chrg
        # self.rcog = rcog
        # self.rvec = rcom
        self.bone_beg = 0
        self.bone_end = self.nitems-1
        if verbose:
            logger.debug(f"('{aname}', '{atype}'):"
                         f" Check: "
                         f" mass = {self.mass},"
                         f" charge = {self.chrg};"
                         f" beg = {self.bone_beg},"
                         f" end = {self.bone_end}{NL_INDENT}"
                         f" Rcom = {self.rvec}{NL_INDENT}"
                         f" Rcog = {self.rcog}")
    # end of Atom.__init__

    def __repr__(self):
        return "{self.__class__.__name__} => {{ name: '{self.name}', type: '{self.type}', " \
               "mass: {self.mass}, charge: {self.chrg}, nitems: {self.nitems};\n " \
               "rvec: {self.rvec};\n rcog: {self.rcog} }}".format(self=self)

    def __del__(self):
        while len(self.items) > 0:
            del self.items[len(self)-1]
        del self.items
        del self.rvec
        del self.rcog

    def __len__(self):
        return len(self.items)

    def __getitem__(self, i):
        return self.items[i]

    def __delslice__(self, i, j, isupdate=True, verbose=True):  # not the most efficient way (for the time being)
        if j < len(self.items)-1 and i < j:
            for k in range(len(self.items[i:j+1])):
                self.popItem(i, isupdate)
        elif verbose:
            logger.info(f"cannot remove items [{i}:{j}] "
                        f"outside range [0,{len(self.items)-1}] - skipped!" )

    def copy(self):
        """
        Generate a copy of the atom set.

        Each contained :class:`Atom` is duplicated with its own set of
        attributes.  The returned set preserves the mass, charge, element
        composition, and CSL state of the original.  Consistency between
        atom‑level CSL flags is checked and an exception raised if they
        conflict.

        Returns
        -------
        AtomSet
            A new instance containing copies of all atoms from ``self``.
        """
        new_items = []
        for atom in self.items:
            new_items.append(atom.copy())
        new_set = AtomSet(aname=self.name,
                          atype=self.type,
                          amass=self.mass,
                          achrg=self.chrg,
                          atoms=new_items,
                          )
        new_set.isMassElems = self.isMassElems
        new_set.isElemCSL = self.isElemCSL
        if new_set.isElemCSL:
            new_set.ecsl = self.ecsl
            for atom in self.items:
                if not (atom.elem and atom.isElemCSL):
                    new_set.ecsl = 0.0
                    new_set.isElemCSL = False
                    break
            if not new_set.isElemCSL:
                isElemALL = all([atm.elem is not None for atm in self.items])
                isElemCSL = all([atm.isElemCSL for atm in self.items])
                raise RuntimeError(f"AtomSet.copy(): "
                                   f"inconsistent isElemCSL state!"
                                   f"({self.isElemCSL} -> {isElemALL} / {isElemCSL})!\n"
                                   f"{[atm.isElemCSL for atm in self.items]}")
        return new_set

    def addItem(self, atom: Atom, isupdate: bool = True) -> None:
        """
        Append an atom to the atom set and, optionally, 
        update all cumulative properties.

        Parameters
        ----------
        atom : Atom
            Atom instance to add to the end of ``self.items``.
        isupdate : bool, optional
            If ``True`` (default), update aggregated attributes such as
            total mass, charge, center of mass and center of geometry.

        Returns
        -------
        None
        """
        self.items.append(atom)
        self.nitems = len(self.items)
        if isupdate:
            self.mass += atom.getMass()
            self.chrg += atom.getCharge()
            if atom.getRvec():
                if self.rvec:
                    self.rvec *= self.mass
                    self.rvec += atom.getRvec() * atom.getMass()
                    self.rvec /= self.mass
                    self.rcog *= self.nitems-1
                    self.rcog += atom.getRvec()
                    self.rcog /= self.nitems
                else:
                    self.rvec = atom.getRvec()
                    self.rcog = atom.getRvec()

    def popItem(self, indx: int, isupdate: bool = True) -> Atom:
        """
        Return the atom at a given index and
        then remove it from the atom set.

        The atom is removed from ``self.items``.  If ``isupdate`` is
        ``True`` the set's total mass, charge, center-of-mass, and
        center-of-geometry are recalculated to reflect the deletion.

        Parameters
        ----------
        indx : int
            Index of the atom to remove.
        isupdate : bool, optional
            Whether to update cumulative properties after removal.

        Returns
        -------
        Atom
            The removed atom instance.
        """
        self.nitems = len(self.items)
        if isupdate and self.nitems > 0:
            atom = self.items[indx]
            self.mass -= atom.getMass()
            self.chrg -= atom.getCharge()
            if atom.getRvec():
                if self.rvec:
                    self.rvec *= self.mass
                    self.rvec -= atom.getRvec() * atom.getMass()
                    self.rvec /= self.mass
                    self.rcog *= self.nitems
                    self.rcog -= atom.getRvec()
                    self.rcog /= self.nitems-1
        self.nitems -= 1
        return self.items.pop(indx)

    def setElemCSL(self,
                   sanames: list[list[str] | tuple[str]] | 
                            tuple[list[str] | tuple[str]] = None,
                   weights: list | tuple = None
                   ) -> bool:
        """
        Calculate *coherent scattering length* (CSL) for the atom set.

        The method attempts to assign a CSL weight to each atom 
        in the atom set and, if successful, sums them up to assign 
        a total CSL weight to the set itself. If setting CSL fails 
        for any atom, the method returns ``False`` and the overall 
        CSL is not updated.

        Parameters
        ----------
        sanames : list[list[str] | tuple[str]] | tuple[list[str] | tuple[str]],
                optional
            Subatom names for each atom in the set. If provided, must match
            the number of atoms in ``self.items``. Each element can be a list
            or tuple of strings representing subatomic components.
        weights : list or tuple, optional
            CSL weights corresponding to each atom. If provided, must match
            the number of atoms in ``self.items``.

        Returns
        -------
        bool
            ``True`` if CSL was successfully set for all atoms, ``False`` otherwise.

        """
        if not self.isElemCSL:
            if self.nitems > 0:
                subatom_names = None
                if isinstance(sanames, list) or isinstance(sanames, tuple):
                    if len(sanames) == self.nitems:
                        subatom_names = sanames
                    else:
                        subatom_names = [None] * self.nitems
                else:
                    subatom_names = [None] * self.nitems
                subatom_weights = None
                if isinstance(weights, list) or isinstance(weights, tuple):
                    if len(weights) == self.nitems:
                        subatom_weights = weights
                    else:
                        subatom_weights = [None]*self.nitems
                else:
                    subatom_weights = [None] * self.nitems
                isElemCSL = True
                for ia, atom in enumerate(self.items):
                    if not atom.isElemCSL:
                        if not atom.elem:
                            atom.setElems(subatom_names[ia])
                        isElemCSL = isElemCSL and atom.setElemCSL(subatom_weights[ia])
                    if not isElemCSL:
                        break
            self.isElemCSL = isElemCSL
        return self.isElemCSL

    def setBoneBeg(self, ib: int = 0) -> None:
        """
        Specify the bone vector starting atom index.

        The bone vector is defined by two atom indices ``bone_beg`` 
        and ``bone_end``. The method updates the beginning index 
        after validating it lies within the current item list.

        Parameters
        ----------
        ib : int, optional
            New beginning index (default ``0``).  
            Out-of-range values are mapped to ``0``.
        """
        if -1 < ib < len(self.items):
            self.bone_beg = ib
        else:
            self.bone_beg = 0

    def getBoneBeg(self) -> int:
        return self.bone_beg

    def setBoneEnd(self, ie: int = 0) -> None:
        """
        Specify the bone vector ending atom index.

        The bone vector is defined by two atom indices ``bone_beg`` 
        and ``bone_end``. The method updates the ending index 
        after validating it lies within the current item list.

        Parameters
        ----------
        ie : int, optional
            New ending index (default ``0``).  Values outside the valid
            range are mapped to ``len(self.items)-1``.
        """
        if -1 < ie < len(self.items):
            self.bone_end = ie
        else:
            self.bone_end = len(self.items) - 1

    def getBoneEnd(self) -> int:
        return self.bone_end

    def setMass(self, *args, **kwargs) -> None:
        """
        Recalculate the total mass of the atom set.

        Returns
        -------
        None
        """
        self.mass = 0.0
        self.nitems = len(self.items)
        if self.nitems > 0:
            for atom in self.items:
                self.mass += atom.getMass()

    def setMassElems(self) -> bool:
        """
        Attempts to assign atom masses from the periodic table.

        If any atom is not found in the periodic table,
        all atom masses are reset to 1.0 and the total mass 
        is set to ``self.nitems``.

        If successful, total mass of atom set is updated
        (``self.rvec`` and ``self.rcog`` will still need to be updated!).

        Returns
        -------
        ``True``  - if the total mass has been successfully (re-)set by summing up the corresponding elements' masses.
        ``False`` - otherwise.
        """
        # TODO: similar method for setting atom masses from topology / force-field
        success = False
        self.nitems = len(self.items)
        if self.nitems > 0:
            success = True
            mass = 0.0
            for atom in self.items:
                if not atom.setMassElem():
                    success = False
                    break
                mass += atom.getMass()
            if success:
                self.mass = mass
            else:
                for atom in self.items:
                    atom.setMass(1.0)
                self.mass = float(self.nitems)
        self.isMassElems = success
        return success

    def getMass(self, isupdate=False) -> float:
        if isupdate:
            self.setMass()
        return self.mass

    def setCharge(self, *args, **kwargs) -> None:
        """
        Compute the total electrical charge of the atom set.

        All atom charges in ``self.items`` are summed and the result is
        stored in ``self.chrg``.

        Returns
        -------
        None
        """
        self.chrg = 0.0
        self.nitems = len(self.items)
        if self.nitems > 0:
            for atom in self.items:
                self.chrg += atom.getCharge()

    def getCharge(self, isupdate=False) -> float:
        if isupdate:
            self.setCharge()
        return self.chrg

    def refresh(self, box: Vec3 = None) -> None:
        """
        Recalculate all cumulative quantities for the atom set.

        The method resets mass, charge, center-of-mass (``rvec``) and
        center-of-geometry (``rcog``).  If a PBC ``box`` is provided, 
        atomic positions are wrapped before accumulation.

        Parameters
        ----------
        box : Vec3, optional
            Periodic box dimensions used for wrapping atom coordinates.

        Returns
        -------
        None
        """
        self.mass = 0.0
        self.chrg = 0.0
        self.rvec = Vec3()
        self.rcog = Vec3()
        self.nitems = len(self.items)
        if self.nitems > 0:
            if box is not None:
                for atom in self.items:
                    self.mass += atom.getMass()
                    self.chrg += atom.getCharge()
                    atom.setRvec(atom.getRvecPBC(box))
                    self.rcog += atom.getRvec()
                    self.rvec += atom.getRvec() * atom.getMass()
                self.rvec /= self.mass
                self.rcog /= float(self.nitems)
            else:
                for atom in self.items:
                    self.mass += atom.getMass()
                    self.chrg += atom.getCharge()
                    self.rcog += atom.getRvec()
                    self.rvec += atom.getRvec() * atom.getMass()
                self.rvec /= self.mass
                self.rcog /= float(self.nitems)

    def updateRcom(self, box: Vec3 = None) -> None:
        """
        Recalculate the center-of-mass for the atom set.

        The routine recalculates ``self.rvec`` using current atom masses 
        and, optionally, applies PBC wrapping if ``box`` vector is supplied.  

        Parameters
        ----------
        box : Vec3, optional
            Simulation box for PBC wrapping positions before averaging.

        Returns
        -------
        None
        """
        if self.rvec is not None:
            del self.rvec
        # self.mass = 0.0
        self.nitems = len(self.items)
        if self.nitems > 0:
            self.rvec = Vec3()
            if box is not None:
                for atom in self.items:
                    # self.mass += atom.getMass()
                    self.rvec += pbc(atom.getRvec(), box) * atom.getMass()
                self.rvec /= self.mass
                self.rcog /= float(self.nitems)
            else:
                for atom in self.items:
                    # self.mass += atom.getMass()
                    self.rvec += atom.getRvec() * atom.getMass()
                self.rvec /= self.mass

    def getRvec(self, isupdate: bool = False, **kwargs) -> Vec3:
        """
        Return the center-of-mass vector for the atom set, 
        possibly recalculated.

        Parameters
        ----------
        isupdate : bool, optional
            If ``True`` COM is recalculated before returning.
        **kwargs
            Additional keyword arguments passed to :meth:`updateRcom`.

        Returns
        -------
        Vec3
            The center-of-mass vector stored in ``self.rvec``.
        """
        if isupdate:
            self.updateRcom(**kwargs)
        return self.rvec

    def getRcom(self, isupdate: bool = False, **kwargs) -> Vec3:
        """
        Alias for :meth:`getRvec`.

        Parameters
        ----------
        isupdate : bool, optional
            Passed through to :meth:`getRvec`.
        **kwargs
            Additional arguments forwarded to :meth:`getRvec`.

        Returns
        -------
        Vec3
            The center‑of‑mass vector.
        """
        return self.getRvec(isupdate, **kwargs)

    def updateRcog(self, box: Vec3 = None) -> None:
        """
        Recalculate the center-of-geometry vector for the atom set.

        The method averages atomic positions, upon optional PBC
        wrapping, and stores the result in ``self.rcog``.

        Parameters
        ----------
        box : Vec3, optional
            Periodic box used to wrap atom coordinates.

        Returns
        -------
        None
        """
        if self.rcog is not None:
            del self.rcog
        self.nitems = len(self.items)
        if self.nitems > 0:
            self.rcog = Vec3()
            # isAtomPBC = (box is not None)
            if box is not None:  # isAtomPBC:
                for atom in self.items:
                    # atom.setRvec(atom.getRvecPBC(box))
                    self.rcog += pbc(atom.getRvec(), box)
                self.rcog /= float(self.nitems)
            else:
                for atom in self.items:
                    self.rcog += atom.getRvec()
                self.rcog /= float(self.nitems)

    def getRcog(self, isupdate: bool = False, **kwargs) -> Vec3:
        """
        Return the center-of-geometry for the atom set, 
        possibly recalculated.

        Parameters
        ----------
        isupdate : bool, optional
            If ``True`` recalculates COG before returning.
        **kwargs
            Forwarded to :meth:`updateRcog`.

        Returns
        -------
        Vec3
            The stored center‑of‑geometry vector.
        """
        if isupdate:
            self.updateRcog(**kwargs)
        return self.rcog

    def updateRvecs(self, box: Vec3 = None) -> None:
        """
        Recalculate both COM and COG along with the total mass.

        Parameters
        ----------
        box : Vec3, optional
            Simulation box for PBC wrapping atomic positions.

        Returns
        -------
        None
        """
        if self.rcog is not None:
            del self.rcog
        if self.rvec is not None:
            del self.rvec
        self.nitems = len(self.items)
        if self.nitems > 0:
            self.mass = 0.0
            self.rvec = Vec3()
            self.rcog = Vec3()
            # isAtomPBC = (box is not None)
            if box is not None:  # isAtomPBC:
                for atom in self.items:
                    atom.setRvec(atom.getRvecPBC(box))
                    self.mass += atom.getMass()
                    self.rcog += atom.getRvec()
                    self.rvec += atom.getRvec() * atom.getMass()
                self.rvec /= self.mass
                self.rcog /= float(self.nitems)
                # print(f"{self.__class__.__name__}.updateRvecs(): "
                #       f"AtomSet {self.indx} "
                #       f"has been put back into box w.r.t. PBC ...")
            else:
                for atom in self.items:
                    self.mass += atom.getMass()
                    self.rcog += atom.getRvec()
                    self.rvec += atom.getRvec() * atom.getMass()
                self.rvec /= self.mass
                self.rcog /= float(self.nitems)

    def getRvecs(self, isupdate: bool = False, **kwargs) -> tuple[Vec3, Vec3]: 
        """
        Get both center-of-mass and center-of-geometry vectors.

        Parameters
        ----------
        isupdate : bool, optional
            Flag to invoke updating COM and COG vectors before returning.
        **kwargs
            Passed to :meth:`updateRvecs` if ``isupdate = True``.

        Returns
        -------
        tuple of Vec3
            (COM, COG) vectors.
        """
        if isupdate:
            self.updateRvecs(**kwargs)
        return self.rvec, self.rcog

    def getRvecBetween(self, i: int, j: int, verbose: bool = False) -> Vec3:
        """
        Calculate the vector between two atoms in the atom set.

        Parameters
        ----------
        i : int
            Index of the first atom.
        j : int
            Index of the second atom.
        verbose : bool, optional
            If ``True`` produce a warning when indices are out of range.

        Returns
        -------
        Vec3
            Vector from atom ``i`` to atom ``j`` (``None`` if invalid indices).
        """
        rvec = None  # Vec3()
        lmax = len(self.items)
        if -1 < j < lmax and -1 < i < lmax:
            rvec = ( self.items[j].getRvec(verbose) 
                 - self.items[i].getRvec(verbose) )
        elif verbose:
            logger.info("cannot calculate Rvec "
                        f"between items {i} & {j} "
                        f"outside range [0,{len(self.items)-1}]"
                        " - skipped!" )
        return rvec

    def getBoneRvec(self, verbose: bool = False) -> Vec3:
        """
        Return the bone vector defined by 
        the current ``bone_beg`` and ``bone_end`` atom indices.

        Parameters
        ----------
        verbose : bool, optional
            If ``True`` warn when the set contains no atoms.

        Returns
        -------
        Vec3
            Vector from ``bone_beg`` to ``bone_end`` (or ``None`` if empty).
        """
        rvec = None  # Vec3()
        if len(self.items) > 0:
            rvec = ( self.items[self.bone_end].getRvec(verbose) 
                 - self.items[self.bone_beg].getRvec(verbose) )
        elif verbose:
            logger.info("no items set yet - skipped!" )
        return rvec

    def moveBy(self, dvec: Vec3 = Vec3(), verbose: bool = False) -> None:
        """
        Translate the entire atom set by ``dvec`` 
        and update COM and COG accordingly.

        Parameters
        ----------
        dvec : Vec3, optional
            Displacement vector to apply to every atom (default zero).
        verbose : bool, optional
            If ``True`` log a message when input is not a Vec3.

        Returns
        -------
        None
        """
        from shapes.basics.globals import TINY
        if isinstance(dvec, Vec3):
            for atom in self.items:
                atom.setRvec(atom.getRvec() + dvec)
            self.rcog += dvec
            self.rvec += dvec
            # for testing / debugging only:
            # rcog = Vec3()
            # rvec = Vec3()
            # mass = 0.0
            # for atom in self.items:
            #     #atom.setRvec(atom.getRvec() + dvec)
            #     rcog += atom.getRvec()
            #     rvec += atom.getRvec() * atom.getMass()
            #     mass += atom.getMass()
            # rvec /= mass #self.mass
            # rcog /= float(len(self.items))
            # #self.updateRvecs()
            # if abs(self.rcog - rcog) + abs(self.rvec - rvec) + abs(self.mass - mass) > TINY:
            #     print(f"{self.__class__.__name__}.moveBy(): WARNING! Molecule {self.indx} "
            #           f"Dev(mass) = {abs(self.mass - mass)} @ |dVec| = {abs(dvec)} => "
            #           #f"Dev(mass) = {abs(self.mass - mass)} = {self.mass} - {mass} & "
            #           f"Dev(Rcom) = {abs(self.rvec - rvec)} & "
            #           f"Dev(Rcog) = {abs(self.rcog - rcog)}")
        elif verbose:
            logger.info(f"Input {dvec} does not qualify "
                        f"as Vec3(float, float, float) - skipped (no change)!")

    def setRvecAt(self, arvec=None, verbose: bool = False) -> None:
        """
        Translate the entire atom set so its COM moves to ``arvec``.

        The shift applied is ``arvec - self.rvec`` and the COG is updated
        accordingly.

        Parameters
        ----------
        arvec : Vec3
            Desired center‑of‑mass location.
        verbose : bool, optional
            If ``True`` log a warning when inputs are invalid.

        Returns
        -------
        None
        """
        if isinstance(arvec, Vec3) and isinstance(self.rvec, Vec3):
                self.moveBy(arvec-self.rvec, verbose)
        elif verbose:
            logger.info(f"Input {arvec} does not qualify "
                        f"as Vec3(float, float, float) - skipped (no change)!")

    def setRcogAt(self, arcog=None, verbose: bool = False) -> None:
        """
        Translate the atom set so its center of geometry moves to ``arcog``.

        Parameters
        ----------
        arcog : Vec3
            Desired center‑of‑geometry vector.
        verbose : bool, optional
            If ``True`` warn on invalid input types.

        Returns
        -------
        None
        """
        if isinstance(arcog, Vec3) and isinstance(self.rcog, Vec3):
                self.moveBy(arcog-self.rcog, verbose)
        elif verbose:
            logger.info(f"Input {arcog} does not qualify "
                        f"as Vec3(float, float, float) - skipped (no change)!")

    def setRvecForAtom(self, ai: int, arvec=None, verbose: bool = False) -> None:
        """
        Assign a new position to a single atom and update COM and COG.

        Parameters
        ----------
        ai : int
            Index of the atom to modify.
        arvec : Vec3
            New position vector for the atom.
        verbose : bool, optional
            If ``True`` log warnings when input is invalid.

        Returns
        -------
        None
        """
        if isinstance(arvec, Vec3):
            if isinstance(self.items[ai].getRvec(), Vec3):
                self.items[ai].setRvec(arvec, verbose)
                self.updateRvecs()
        elif verbose:
            logger.info(f"Input {arvec} for atom # {ai} does not qualify as Vec3(float,"
                        f" float, float) - skipped (no change)!")

    def setRvecsForAtoms(self, first: int, last: int, arvecs=None, verbose: bool = False) -> None:
        """
        Update positions of a contiguous slice of atoms and update COM and COG.

        Parameters
        ----------
        first : int
            Index of the first atom in the slice.
        last : int
            Index of the last atom in the slice.
        arvecs : list of Vec3
            New positions; length must be at least ``last-first+1``.
        verbose : bool, optional
            If ``True`` warn when inputs are malformed.

        Returns
        -------
        None
        """
        if isinstance(arvecs, list) and len(arvecs) >= (last - first + 1) and isinstance(arvecs[0], Vec3):
            for i in range(last - first + 1):
                self.items[first + i].setRvec(arvecs[i], verbose)
            self.updateRvecs()
        elif verbose:
            logger.info(f"Input {arvecs} for atoms # {first} ... {last} "
                        f"does not qualify as [Vec3(float, float, float)]*"
                        f"{last-first+1} - skipped (no change)!")

# end of class AtomSet
